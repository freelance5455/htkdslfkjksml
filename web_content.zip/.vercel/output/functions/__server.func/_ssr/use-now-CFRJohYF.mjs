import { i as __toESM } from "../_runtime.mjs";
import { J as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/use-now-CFRJohYF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var CONSTELLATIONS = {
	ori: {
		name: "Orion",
		note: "The easiest winter figure. The belt is three stars; follow it down to Sirius and up to Aldebaran."
	},
	uma: {
		name: "Ursa Major",
		note: "The Big Dipper is an asterism inside this larger constellation. The two outer bowl stars point at Polaris."
	},
	umi: {
		name: "Ursa Minor",
		note: "The Little Dipper. Polaris, at the end of the handle, barely moves."
	},
	cas: {
		name: "Cassiopeia",
		note: "A W (or M) on the other side of Polaris from the Dipper. It never sets from most of Europe and the northern US."
	},
	cyg: {
		name: "Cygnus",
		note: "The Northern Cross. Deneb marks the tail of the swan and one corner of the Summer Triangle."
	},
	lyr: {
		name: "Lyra",
		note: "A small harp dominated by Vega, the brightest star of northern summer."
	},
	aql: {
		name: "Aquila",
		note: "The eagle. Altair is flanked by a dimmer star on either side — a handy pattern."
	},
	sco: {
		name: "Scorpius",
		note: "A real scorpion shape, best seen low in the south from the northern hemisphere, overhead from much of the south."
	},
	leo: {
		name: "Leo",
		note: "A backwards question mark — the Sickle — ends at Regulus. Spring, for northern observers."
	},
	tau: {
		name: "Taurus",
		note: "Aldebaran marks the eye. The Pleiades, just beside it, are the tight little cluster that looks like a tiny dipper."
	},
	cma: {
		name: "Canis Major",
		note: "Home of Sirius, the brightest star in the night sky."
	},
	gem: {
		name: "Gemini",
		note: "The twins. Castor and Pollux are the two bright heads; Pollux is the slightly brighter, warmer one."
	},
	boo: {
		name: "Boötes",
		note: "Follow the arc of the Big Dipper's handle and you land on Arcturus: arc to Arcturus."
	},
	vir: {
		name: "Virgo",
		note: "Spica is the bright star you reach if you keep going past Arcturus: speed on to Spica."
	},
	aur: {
		name: "Auriga",
		note: "A pentagon of stars with Capella, a yellow star much like the Sun only far larger, at one corner."
	},
	peg: {
		name: "Pegasus",
		note: "The Great Square is the landmark of northern autumn evenings. It is big — wider than you expect."
	},
	and: {
		name: "Andromeda",
		note: "A chain of stars off one corner of the Square. The Andromeda Galaxy sits beside this line, visible as a faint smudge from a dark site."
	},
	per: {
		name: "Perseus",
		note: "Between Cassiopeia and Auriga. Algol, its famous star, dims for a few hours every three days — an eclipse, not a dying star."
	},
	cmi: {
		name: "Canis Minor",
		note: "Almost just Procyon, the little dog, forming a triangle with Sirius and Betelgeuse."
	},
	psa: {
		name: "Piscis Austrinus",
		note: "Far south, one bright star: Fomalhaut, the lonely autumn star."
	},
	cru: {
		name: "Crux",
		note: "The Southern Cross. Small, sharp, and never visible from most of Europe or the mainland US."
	},
	cen: {
		name: "Centaurus",
		note: "Alpha Centauri is the closest star system to the Sun, 4.4 light-years away. With Hadar it points toward the Cross."
	},
	eri: {
		name: "Eridanus",
		note: "A river of faint stars ending at Achernar, a bright southern beacon."
	},
	car: {
		name: "Carina",
		note: "Canopus, second brightest star in the sky, is too far south for most northern observers."
	}
};
var STARS = [
	{
		id: "betelgeuse",
		name: "Betelgeuse",
		ra: 5.919,
		dec: 7.407,
		mag: .5,
		con: "ori",
		tint: "rose",
		ly: 550,
		fact: "A red supergiant in Orion's shoulder. If it replaced the Sun, its surface would lie out past Mars. It will explode as a supernova — not this week."
	},
	{
		id: "bellatrix",
		name: "Bellatrix",
		ra: 5.419,
		dec: 6.35,
		mag: 1.64,
		con: "ori",
		tint: "blue",
		ly: 250,
		fact: "Orion's other shoulder. Much closer than the belt stars, which is a hint that the figure isn't a real group."
	},
	{
		id: "mintaka",
		name: "Mintaka",
		ra: 5.533,
		dec: -.299,
		mag: 2.23,
		con: "ori",
		tint: "blue",
		ly: 1200,
		fact: "The western star of the belt. It sits almost on the celestial equator, so it rises due east and sets due west everywhere on Earth."
	},
	{
		id: "alnilam",
		name: "Alnilam",
		ra: 5.603,
		dec: -1.202,
		mag: 1.69,
		con: "ori",
		tint: "blue",
		ly: 2e3,
		fact: "The middle belt star, and the farthest of the three. The belt looks flat. It isn't."
	},
	{
		id: "alnitak",
		name: "Alnitak",
		ra: 5.679,
		dec: -1.943,
		mag: 1.74,
		con: "ori",
		tint: "blue",
		ly: 1260,
		fact: "The eastern belt star. The Horsehead Nebula sits just south of it — photographic, not a naked-eye object."
	},
	{
		id: "rigel",
		name: "Rigel",
		ra: 5.242,
		dec: -8.202,
		mag: .13,
		con: "ori",
		tint: "blue",
		ly: 860,
		fact: "A blue supergiant, usually the brightest star in Orion. About 860 light-years away and tens of thousands of times more luminous than the Sun."
	},
	{
		id: "saiph",
		name: "Saiph",
		ra: 5.796,
		dec: -9.67,
		mag: 2.09,
		con: "ori",
		tint: "blue",
		ly: 650,
		fact: "Orion's fainter foot, opposite Rigel."
	},
	{
		id: "sirius",
		name: "Sirius",
		ra: 6.752,
		dec: -16.716,
		mag: -1.46,
		con: "cma",
		tint: "white",
		ly: 8.6,
		fact: "Brightest star of the night. Only 8.6 light-years away — the light you see left in the late 2010s. Follow Orion's belt down and left."
	},
	{
		id: "mirzam",
		name: "Mirzam",
		ra: 6.378,
		dec: -17.956,
		mag: 1.98,
		con: "cma",
		tint: "blue",
		ly: 500,
		fact: "Just west of Sirius. A preview of the Dog Star rising: when Mirzam clears the horizon, Sirius follows."
	},
	{
		id: "wezen",
		name: "Wezen",
		ra: 7.14,
		dec: -26.393,
		mag: 1.84,
		con: "cma",
		tint: "gold",
		ly: 1600,
		fact: "A supergiant in the big dog's hindquarters. Far more luminous than Sirius, and much farther, so it looks dimmer."
	},
	{
		id: "adhara",
		name: "Adhara",
		ra: 6.977,
		dec: -28.972,
		mag: 1.5,
		con: "cma",
		tint: "blue",
		ly: 430,
		fact: "Second brightest in Canis Major, often overlooked because Sirius is outrageous."
	},
	{
		id: "procyon",
		name: "Procyon",
		ra: 7.655,
		dec: 5.225,
		mag: .34,
		con: "cmi",
		tint: "gold",
		ly: 11.5,
		fact: "The little dog. With Sirius and Betelgeuse it makes the Winter Triangle."
	},
	{
		id: "aldebaran",
		name: "Aldebaran",
		ra: 4.599,
		dec: 16.509,
		mag: .85,
		con: "tau",
		tint: "amber",
		ly: 65,
		fact: "The bull's eye, an orange giant. It looks like it belongs to the Hyades cluster behind it. It doesn't — the cluster is almost twice as far."
	},
	{
		id: "elnath",
		name: "Elnath",
		ra: 5.438,
		dec: 28.608,
		mag: 1.65,
		con: "tau",
		tint: "blue",
		ly: 134,
		fact: "The tip of one horn, and also the traditional foot of Auriga. One star, two constellations, in the old maps."
	},
	{
		id: "alcyone",
		name: "Alcyone",
		ra: 3.791,
		dec: 24.105,
		mag: 2.87,
		con: "tau",
		tint: "blue",
		ly: 440,
		fact: "Brightest of the Pleiades. Most people see six stars there; a dark sky and steady eyes can find more."
	},
	{
		id: "capella",
		name: "Capella",
		ra: 5.278,
		dec: 45.998,
		mag: .08,
		con: "aur",
		tint: "gold",
		ly: 43,
		fact: "Sixth brightest star. Yellow-white, actually a pair of giant stars too close to split by eye."
	},
	{
		id: "menkalinan",
		name: "Menkalinan",
		ra: 5.992,
		dec: 44.947,
		mag: 1.9,
		con: "aur",
		tint: "white",
		ly: 81,
		fact: "The second star of Auriga, an eclipsing pair whose brightness dips are too slight to notice naked-eye."
	},
	{
		id: "castor",
		name: "Castor",
		ra: 7.576,
		dec: 31.888,
		mag: 1.58,
		con: "gem",
		tint: "white",
		ly: 51,
		fact: "The slightly dimmer twin. A telescope splits it; the system is actually six stars."
	},
	{
		id: "pollux",
		name: "Pollux",
		ra: 7.755,
		dec: 28.026,
		mag: 1.14,
		con: "gem",
		tint: "amber",
		ly: 34,
		fact: "The brighter twin, orange, and known to host a planet a couple of times Jupiter's mass."
	},
	{
		id: "alhena",
		name: "Alhena",
		ra: 6.628,
		dec: 16.399,
		mag: 1.9,
		con: "gem",
		tint: "white",
		ly: 109,
		fact: "Pollux's foot. The two twins are parallel lines, not a single connect-the-dots animal."
	},
	{
		id: "wasat",
		name: "Wasat",
		ra: 7.335,
		dec: 21.982,
		mag: 3.53,
		con: "gem",
		tint: "white",
		ly: 59,
		fact: "A dimmer star down Castor's side, useful for seeing that the twins are two lines."
	},
	{
		id: "dubhe",
		name: "Dubhe",
		ra: 11.062,
		dec: 61.751,
		mag: 1.79,
		con: "uma",
		tint: "amber",
		ly: 123,
		fact: "The lip of the Dipper's bowl closest to Polaris. With Merak, it is the pointer."
	},
	{
		id: "merak",
		name: "Merak",
		ra: 11.031,
		dec: 56.382,
		mag: 2.37,
		con: "uma",
		tint: "white",
		ly: 80,
		fact: "The other pointer. Draw a line from Merak through Dubhe and continue about five times that gap: Polaris."
	},
	{
		id: "phecda",
		name: "Phecda",
		ra: 11.897,
		dec: 53.695,
		mag: 2.44,
		con: "uma",
		tint: "white",
		ly: 83,
		fact: "The bottom inner corner of the bowl."
	},
	{
		id: "megrez",
		name: "Megrez",
		ra: 12.257,
		dec: 57.033,
		mag: 3.31,
		con: "uma",
		tint: "white",
		ly: 58,
		fact: "Where the handle meets the bowl. Faintest of the seven, and the one people lose first in a bright city sky."
	},
	{
		id: "alioth",
		name: "Alioth",
		ra: 12.9,
		dec: 55.96,
		mag: 1.76,
		con: "uma",
		tint: "white",
		ly: 83,
		fact: "The first handle star, and actually the brightest of the Dipper even though nobody remembers its name."
	},
	{
		id: "mizar",
		name: "Mizar",
		ra: 13.399,
		dec: 54.925,
		mag: 2.23,
		con: "uma",
		tint: "white",
		ly: 83,
		fact: "The middle of the handle. Sharp eyes split off Alcor, its companion — a classic eyesight test, and a real neighbor."
	},
	{
		id: "alkaid",
		name: "Alkaid",
		ra: 13.792,
		dec: 49.313,
		mag: 1.85,
		con: "uma",
		tint: "blue",
		ly: 104,
		fact: "The end of the handle. Arc from here away from the bowl and you bend toward Arcturus."
	},
	{
		id: "polaris",
		name: "Polaris",
		ra: 2.53,
		dec: 89.264,
		mag: 1.98,
		con: "umi",
		tint: "gold",
		ly: 430,
		fact: "The north pole star. It is not the brightest star in the sky — that rumor won't die — and it is not exactly at the pole. Close enough to navigate."
	},
	{
		id: "kochab",
		name: "Kochab",
		ra: 14.845,
		dec: 74.155,
		mag: 2.08,
		con: "umi",
		tint: "amber",
		ly: 131,
		fact: "The brighter of the two Guardians of the Pole, circling Polaris opposite the Dipper."
	},
	{
		id: "pherkad",
		name: "Pherkad",
		ra: 15.345,
		dec: 71.834,
		mag: 3.05,
		con: "umi",
		tint: "white",
		ly: 487,
		fact: "The other Guardian. The pair scoop around the pole all night."
	},
	{
		id: "schedar",
		name: "Schedar",
		ra: .675,
		dec: 56.537,
		mag: 2.24,
		con: "cas",
		tint: "amber",
		ly: 228,
		fact: "One end-star of Cassiopeia's W."
	},
	{
		id: "caph",
		name: "Caph",
		ra: .153,
		dec: 59.15,
		mag: 2.27,
		con: "cas",
		tint: "gold",
		ly: 55,
		fact: "The western end of the W. Much nearer than Schedar — another pattern that isn't a family."
	},
	{
		id: "gamcas",
		name: "Gamma Cassiopeiae",
		ra: .945,
		dec: 60.717,
		mag: 2.15,
		con: "cas",
		tint: "blue",
		ly: 610,
		fact: "The central peak of the W. It flares and fades over years; there is no single 'right' brightness."
	},
	{
		id: "ruchbah",
		name: "Ruchbah",
		ra: 1.43,
		dec: 60.235,
		mag: 2.68,
		con: "cas",
		tint: "white",
		ly: 99,
		fact: "The next star of the W, heading toward Perseus."
	},
	{
		id: "segin",
		name: "Segin",
		ra: 1.907,
		dec: 63.67,
		mag: 3.35,
		con: "cas",
		tint: "blue",
		ly: 440,
		fact: "The eastern end of the W."
	},
	{
		id: "vega",
		name: "Vega",
		ra: 18.615,
		dec: 38.784,
		mag: .03,
		con: "lyr",
		tint: "white",
		ly: 25,
		fact: "Overhead on northern summer evenings. About 25 light-years away, and one corner of the Summer Triangle."
	},
	{
		id: "sheliak",
		name: "Sheliak",
		ra: 18.835,
		dec: 33.363,
		mag: 3.52,
		con: "lyr",
		tint: "blue",
		ly: 960,
		fact: "A famous eclipsing pair. The small parallelogram under Vega hangs off this star."
	},
	{
		id: "sulafat",
		name: "Sulafat",
		ra: 18.982,
		dec: 32.69,
		mag: 3.25,
		con: "lyr",
		tint: "blue",
		ly: 620,
		fact: "The other end of Lyra's little parallelogram."
	},
	{
		id: "deneb",
		name: "Deneb",
		ra: 20.69,
		dec: 45.28,
		mag: 1.25,
		con: "cyg",
		tint: "white",
		ly: 2600,
		fact: "Looks similar to Vega. It is not. Deneb is thousands of light-years away and enormously more luminous — one of the great naked-eye lessons in distance."
	},
	{
		id: "sadr",
		name: "Sadr",
		ra: 20.37,
		dec: 40.257,
		mag: 2.23,
		con: "cyg",
		tint: "gold",
		ly: 1800,
		fact: "The heart of the cross, where the wings meet the body."
	},
	{
		id: "albireo",
		name: "Albireo",
		ra: 19.512,
		dec: 27.96,
		mag: 3.05,
		con: "cyg",
		tint: "amber",
		ly: 430,
		fact: "The swan's beak. A small telescope shows a gold star and a blue star — the prettiest double in the sky."
	},
	{
		id: "gienah",
		name: "Gienah",
		ra: 20.77,
		dec: 33.97,
		mag: 2.48,
		con: "cyg",
		tint: "amber",
		ly: 72,
		fact: "One wingtip of Cygnus."
	},
	{
		id: "deltacyg",
		name: "Delta Cygni",
		ra: 19.749,
		dec: 45.131,
		mag: 2.87,
		con: "cyg",
		tint: "blue",
		ly: 165,
		fact: "The other wingtip, up toward the north."
	},
	{
		id: "altair",
		name: "Altair",
		ra: 19.846,
		dec: 8.868,
		mag: .76,
		con: "aql",
		tint: "white",
		ly: 17,
		fact: "The southern corner of the Summer Triangle. Only 17 light-years away, and it spins so fast it is visibly squashed — if you could see the disk."
	},
	{
		id: "tarazed",
		name: "Tarazed",
		ra: 19.771,
		dec: 10.613,
		mag: 2.72,
		con: "aql",
		tint: "amber",
		ly: 395,
		fact: "The brighter of Altair's two flankers."
	},
	{
		id: "alshain",
		name: "Alshain",
		ra: 19.921,
		dec: 6.407,
		mag: 3.71,
		con: "aql",
		tint: "gold",
		ly: 45,
		fact: "The fainter flanker, south of Altair."
	},
	{
		id: "antares",
		name: "Antares",
		ra: 16.49,
		dec: -26.432,
		mag: 1.06,
		con: "sco",
		tint: "rose",
		ly: 550,
		fact: "Rival of Mars — the name means that. A red supergiant marking the scorpion's heart."
	},
	{
		id: "dschubba",
		name: "Dschubba",
		ra: 16.005,
		dec: -22.622,
		mag: 2.29,
		con: "sco",
		tint: "blue",
		ly: 440,
		fact: "The forehead of the scorpion, in the three-star head."
	},
	{
		id: "acrab",
		name: "Acrab",
		ra: 16.09,
		dec: -19.805,
		mag: 2.56,
		con: "sco",
		tint: "blue",
		ly: 530,
		fact: "The upper claw. The head is a small vertical line just west of Antares."
	},
	{
		id: "shaula",
		name: "Shaula",
		ra: 17.56,
		dec: -37.104,
		mag: 1.62,
		con: "sco",
		tint: "blue",
		ly: 570,
		fact: "The stinger. With a neighbor it makes the cat's eyes at the end of the curled tail."
	},
	{
		id: "sargas",
		name: "Sargas",
		ra: 17.622,
		dec: -42.998,
		mag: 1.86,
		con: "sco",
		tint: "gold",
		ly: 270,
		fact: "Down in the tail, far enough south that northern cities catch it only briefly."
	},
	{
		id: "regulus",
		name: "Regulus",
		ra: 10.139,
		dec: 11.967,
		mag: 1.36,
		con: "leo",
		tint: "blue",
		ly: 79,
		fact: "The heart of the lion, at the base of the Sickle. Almost on the ecliptic — the Moon and planets pass close."
	},
	{
		id: "algieba",
		name: "Algieba",
		ra: 10.333,
		dec: 19.842,
		mag: 2.08,
		con: "leo",
		tint: "amber",
		ly: 130,
		fact: "The brightest star in the mane. A fine double for a small telescope."
	},
	{
		id: "zosma",
		name: "Zosma",
		ra: 11.235,
		dec: 20.524,
		mag: 2.56,
		con: "leo",
		tint: "white",
		ly: 58,
		fact: "The lion's hip, where the body turns toward Denebola."
	},
	{
		id: "denebola",
		name: "Denebola",
		ra: 11.818,
		dec: 14.572,
		mag: 2.14,
		con: "leo",
		tint: "white",
		ly: 36,
		fact: "The tail. Regulus to Denebola is the length of the lion."
	},
	{
		id: "arcturus",
		name: "Arcturus",
		ra: 14.261,
		dec: 19.182,
		mag: -.05,
		con: "boo",
		tint: "amber",
		ly: 37,
		fact: "Brightest star of the northern hemisphere. Orange, and close. Arc the Dipper's handle to find it."
	},
	{
		id: "izar",
		name: "Izar",
		ra: 14.75,
		dec: 27.074,
		mag: 2.37,
		con: "boo",
		tint: "amber",
		ly: 202,
		fact: "On the way up the kite of Boötes. A celebrated double star."
	},
	{
		id: "nekkar",
		name: "Nekkar",
		ra: 15.032,
		dec: 40.391,
		mag: 3.49,
		con: "boo",
		tint: "gold",
		ly: 219,
		fact: "The top of the kite, toward the Dipper's handle."
	},
	{
		id: "spica",
		name: "Spica",
		ra: 13.42,
		dec: -11.161,
		mag: .98,
		con: "vir",
		tint: "blue",
		ly: 250,
		fact: "A hot blue star in Virgo. Keep the arc going past Arcturus and you run into it."
	},
	{
		id: "vindemiatrix",
		name: "Vindemiatrix",
		ra: 13.037,
		dec: 10.958,
		mag: 2.83,
		con: "vir",
		tint: "gold",
		ly: 110,
		fact: "The grape-gatherer, north of Spica, more useful as a stepping stone than as a sight."
	},
	{
		id: "alpheratz",
		name: "Alpheratz",
		ra: .14,
		dec: 29.091,
		mag: 2.07,
		con: "and",
		tint: "blue",
		ly: 97,
		fact: "Officially Andromeda's head, and also a corner of the Great Square of Pegasus. Maps share stars more often than you'd think."
	},
	{
		id: "scheat",
		name: "Scheat",
		ra: 23.063,
		dec: 28.083,
		mag: 2.44,
		con: "peg",
		tint: "rose",
		ly: 196,
		fact: "The northwest corner of the Square. A red giant that varies a little."
	},
	{
		id: "markab",
		name: "Markab",
		ra: 23.079,
		dec: 15.205,
		mag: 2.49,
		con: "peg",
		tint: "white",
		ly: 133,
		fact: "The southwest corner of the Square."
	},
	{
		id: "algenib",
		name: "Algenib",
		ra: .221,
		dec: 15.184,
		mag: 2.83,
		con: "peg",
		tint: "blue",
		ly: 390,
		fact: "The southeast corner. The Square is empty inside — that emptiness is part of how you recognize it."
	},
	{
		id: "mirach",
		name: "Mirach",
		ra: 1.162,
		dec: 35.621,
		mag: 2.07,
		con: "and",
		tint: "rose",
		ly: 197,
		fact: "The middle of Andromeda's chain. Step from Alpheratz to here to Almach."
	},
	{
		id: "almach",
		name: "Almach",
		ra: 2.065,
		dec: 42.33,
		mag: 2.1,
		con: "and",
		tint: "amber",
		ly: 350,
		fact: "The third star of the chain. A gold-and-blue double in any small telescope."
	},
	{
		id: "mirfak",
		name: "Mirfak",
		ra: 3.405,
		dec: 49.861,
		mag: 1.79,
		con: "per",
		tint: "gold",
		ly: 590,
		fact: "The brightest star of Perseus, in a rich field of the Milky Way."
	},
	{
		id: "algol",
		name: "Algol",
		ra: 3.136,
		dec: 40.956,
		mag: 2.12,
		con: "per",
		tint: "blue",
		ly: 90,
		fact: "The demon star. Every 2.87 days it dims for about ten hours as a companion crosses in front. Compare it with Mirfak."
	},
	{
		id: "fomalhaut",
		name: "Fomalhaut",
		ra: 22.961,
		dec: -29.622,
		mag: 1.16,
		con: "psa",
		tint: "white",
		ly: 25,
		fact: "A lonely bright star low in the south on northern autumn evenings. Surrounded by a dusty disk where a planet was imaged."
	},
	{
		id: "acrux",
		name: "Acrux",
		ra: 12.443,
		dec: -63.099,
		mag: .77,
		con: "cru",
		tint: "blue",
		ly: 320,
		fact: "The foot of the Southern Cross. Actually a multiple star of hot blue suns."
	},
	{
		id: "mimosa",
		name: "Mimosa",
		ra: 12.795,
		dec: -59.689,
		mag: 1.25,
		con: "cru",
		tint: "blue",
		ly: 280,
		fact: "The eastern arm of the Cross."
	},
	{
		id: "gacrux",
		name: "Gacrux",
		ra: 12.519,
		dec: -57.113,
		mag: 1.63,
		con: "cru",
		tint: "rose",
		ly: 89,
		fact: "The top of the Cross, and the red one. Color is how you remember which way is south: the long axis points toward the south celestial pole when the red star is up."
	},
	{
		id: "decrux",
		name: "Delta Crucis",
		ra: 12.252,
		dec: -58.749,
		mag: 2.79,
		con: "cru",
		tint: "blue",
		ly: 345,
		fact: "The western arm. The Cross is small — cover it with an outstretched hand."
	},
	{
		id: "rigil",
		name: "Alpha Centauri",
		ra: 14.66,
		dec: -60.834,
		mag: -.27,
		con: "cen",
		tint: "gold",
		ly: 4.37,
		fact: "Closest star system to the Sun. A pair that looks single, plus Proxima, a faint red dwarf that is the true nearest star. Point with Hadar toward the Cross."
	},
	{
		id: "hadar",
		name: "Hadar",
		ra: 14.064,
		dec: -60.373,
		mag: .61,
		con: "cen",
		tint: "blue",
		ly: 390,
		fact: "The other pointer to the Southern Cross. Much farther than Alpha Centauri, so another pair that only looks matched."
	},
	{
		id: "achernar",
		name: "Achernar",
		ra: 1.628,
		dec: -57.237,
		mag: .46,
		con: "eri",
		tint: "blue",
		ly: 139,
		fact: "The end of the river Eridanus. Ninth brightest star, and spinning so fast it is the flattest bright star we know."
	},
	{
		id: "canopus",
		name: "Canopus",
		ra: 6.399,
		dec: -52.696,
		mag: -.74,
		con: "car",
		tint: "gold",
		ly: 310,
		fact: "Second brightest star. Far south. If you can see Canopus and Sirius together, you are well into the southern sky."
	}
];
var LINES = [
	{
		a: "betelgeuse",
		b: "bellatrix",
		con: "ori"
	},
	{
		a: "bellatrix",
		b: "mintaka",
		con: "ori"
	},
	{
		a: "mintaka",
		b: "alnilam",
		con: "ori"
	},
	{
		a: "alnilam",
		b: "alnitak",
		con: "ori"
	},
	{
		a: "alnitak",
		b: "betelgeuse",
		con: "ori"
	},
	{
		a: "alnitak",
		b: "saiph",
		con: "ori"
	},
	{
		a: "saiph",
		b: "rigel",
		con: "ori"
	},
	{
		a: "rigel",
		b: "mintaka",
		con: "ori"
	},
	{
		a: "mirzam",
		b: "sirius",
		con: "cma"
	},
	{
		a: "sirius",
		b: "wezen",
		con: "cma"
	},
	{
		a: "wezen",
		b: "adhara",
		con: "cma"
	},
	{
		a: "adhara",
		b: "sirius",
		con: "cma"
	},
	{
		a: "aldebaran",
		b: "elnath",
		con: "tau"
	},
	{
		a: "aldebaran",
		b: "alcyone",
		con: "tau"
	},
	{
		a: "capella",
		b: "menkalinan",
		con: "aur"
	},
	{
		a: "menkalinan",
		b: "elnath",
		con: "aur"
	},
	{
		a: "elnath",
		b: "capella",
		con: "aur"
	},
	{
		a: "castor",
		b: "pollux",
		con: "gem"
	},
	{
		a: "castor",
		b: "wasat",
		con: "gem"
	},
	{
		a: "pollux",
		b: "alhena",
		con: "gem"
	},
	{
		a: "merak",
		b: "dubhe",
		con: "uma"
	},
	{
		a: "dubhe",
		b: "megrez",
		con: "uma"
	},
	{
		a: "megrez",
		b: "phecda",
		con: "uma"
	},
	{
		a: "phecda",
		b: "merak",
		con: "uma"
	},
	{
		a: "megrez",
		b: "alioth",
		con: "uma"
	},
	{
		a: "alioth",
		b: "mizar",
		con: "uma"
	},
	{
		a: "mizar",
		b: "alkaid",
		con: "uma"
	},
	{
		a: "polaris",
		b: "kochab",
		con: "umi"
	},
	{
		a: "kochab",
		b: "pherkad",
		con: "umi"
	},
	{
		a: "segin",
		b: "ruchbah",
		con: "cas"
	},
	{
		a: "ruchbah",
		b: "gamcas",
		con: "cas"
	},
	{
		a: "gamcas",
		b: "schedar",
		con: "cas"
	},
	{
		a: "schedar",
		b: "caph",
		con: "cas"
	},
	{
		a: "vega",
		b: "sheliak",
		con: "lyr"
	},
	{
		a: "vega",
		b: "sulafat",
		con: "lyr"
	},
	{
		a: "sheliak",
		b: "sulafat",
		con: "lyr"
	},
	{
		a: "deneb",
		b: "sadr",
		con: "cyg"
	},
	{
		a: "sadr",
		b: "albireo",
		con: "cyg"
	},
	{
		a: "deltacyg",
		b: "sadr",
		con: "cyg"
	},
	{
		a: "sadr",
		b: "gienah",
		con: "cyg"
	},
	{
		a: "tarazed",
		b: "altair",
		con: "aql"
	},
	{
		a: "altair",
		b: "alshain",
		con: "aql"
	},
	{
		a: "acrab",
		b: "dschubba",
		con: "sco"
	},
	{
		a: "dschubba",
		b: "antares",
		con: "sco"
	},
	{
		a: "antares",
		b: "shaula",
		con: "sco"
	},
	{
		a: "shaula",
		b: "sargas",
		con: "sco"
	},
	{
		a: "regulus",
		b: "algieba",
		con: "leo"
	},
	{
		a: "algieba",
		b: "zosma",
		con: "leo"
	},
	{
		a: "zosma",
		b: "denebola",
		con: "leo"
	},
	{
		a: "nekkar",
		b: "izar",
		con: "boo"
	},
	{
		a: "izar",
		b: "arcturus",
		con: "boo"
	},
	{
		a: "vindemiatrix",
		b: "spica",
		con: "vir"
	},
	{
		a: "scheat",
		b: "markab",
		con: "peg"
	},
	{
		a: "markab",
		b: "algenib",
		con: "peg"
	},
	{
		a: "algenib",
		b: "alpheratz",
		con: "peg"
	},
	{
		a: "alpheratz",
		b: "scheat",
		con: "peg"
	},
	{
		a: "alpheratz",
		b: "mirach",
		con: "and"
	},
	{
		a: "mirach",
		b: "almach",
		con: "and"
	},
	{
		a: "mirfak",
		b: "algol",
		con: "per"
	},
	{
		a: "gacrux",
		b: "acrux",
		con: "cru"
	},
	{
		a: "mimosa",
		b: "decrux",
		con: "cru"
	},
	{
		a: "rigil",
		b: "hadar",
		con: "cen"
	},
	{
		a: "dubhe",
		b: "polaris",
		con: "guide",
		guide: true
	},
	{
		a: "alnilam",
		b: "sirius",
		con: "guide",
		guide: true
	},
	{
		a: "alnilam",
		b: "aldebaran",
		con: "guide",
		guide: true
	},
	{
		a: "hadar",
		b: "acrux",
		con: "guide",
		guide: true
	},
	{
		a: "vega",
		b: "altair",
		con: "tri",
		guide: true
	},
	{
		a: "altair",
		b: "deneb",
		con: "tri",
		guide: true
	},
	{
		a: "deneb",
		b: "vega",
		con: "tri",
		guide: true
	}
];
var PLACES = [
	{
		id: "new-york",
		name: "New York",
		lat: 40.7,
		lon: -74
	},
	{
		id: "london",
		name: "London",
		lat: 51.5,
		lon: -.1
	},
	{
		id: "reykjavik",
		name: "Reykjavík",
		lat: 64.1,
		lon: -21.9
	},
	{
		id: "cairo",
		name: "Cairo",
		lat: 30,
		lon: 31.2
	},
	{
		id: "tokyo",
		name: "Tokyo",
		lat: 35.7,
		lon: 139.7
	},
	{
		id: "singapore",
		name: "Singapore",
		lat: 1.3,
		lon: 103.8
	},
	{
		id: "sydney",
		name: "Sydney",
		lat: -33.9,
		lon: 151.2
	},
	{
		id: "santiago",
		name: "Santiago",
		lat: -33.4,
		lon: -70.7
	}
];
function useNow(intervalMs = 2e4) {
	const [now, setNow] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		setNow(/* @__PURE__ */ new Date());
		const id = window.setInterval(() => setNow(/* @__PURE__ */ new Date()), intervalMs);
		return () => window.clearInterval(id);
	}, [intervalMs]);
	return now;
}
//#endregion
export { useNow as a, STARS as i, LINES as n, PLACES as r, CONSTELLATIONS as t };
