import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as usePortfolio } from "./router-Ddmv2GI8.mjs";
import { t as Shell } from "./shell-wztA7KjE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/meg-CWB9lELs.js
var import_jsx_runtime = require_jsx_runtime();
var LINKS = [
	{
		to: "/mozgasok",
		title: "Mozgások",
		text: "Vétel, eladás, osztalék, díj."
	},
	{
		to: "/beolvasas",
		title: "Beolvasás",
		text: "Lightyear PDF, kriptotárca, CSV és mentés."
	},
	{
		to: "/dijak",
		title: "Előfizetések",
		text: "Havi szivárgás forintban és dollárban."
	}
];
function Page() {
	const { loadSample, clearAll } = usePortfolio();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-serif text-3xl",
			children: "Még"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted",
			children: "Ami a telefon alján külön nem fért el."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-6 divide-y divide-line border-t border-line",
			children: LINKS.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: link.to,
				className: "flex min-h-16 flex-col justify-center py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-medium",
					children: link.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm text-muted",
					children: link.text
				})]
			}) }, link.to))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8 flex flex-wrap gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "btn btn-ghost",
				onClick: loadSample,
				children: "Minta újratöltése"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "btn btn-primary",
				onClick: () => confirm("Üres lapra cseréled a helyi adatot?") && clearAll(),
				children: "Üres lap"
			})]
		})
	] });
}
//#endregion
export { Page as component };
