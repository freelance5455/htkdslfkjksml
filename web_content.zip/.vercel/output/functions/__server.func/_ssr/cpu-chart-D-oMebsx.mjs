import { d as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as Tooltip, n as Area, r as ResponsiveContainer, t as AreaChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cpu-chart-D-oMebsx.js
var import_jsx_runtime = require_jsx_runtime();
function CpuChart({ points }) {
	const data = points.map((load, index) => ({
		index,
		load
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-36 w-full",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
			width: "100%",
			height: "100%",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
				data,
				margin: {
					top: 8,
					right: 0,
					left: 0,
					bottom: 0
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
					cursor: { stroke: "var(--color-line)" },
					content: ({ active, payload }) => {
						if (!active || !payload?.length) return null;
						const value = payload[0]?.value;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg border border-line bg-surface px-2 py-1 text-xs text-fg tabular-nums",
							children: [value, "%"]
						});
					}
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
					type: "monotone",
					dataKey: "load",
					stroke: "var(--color-fg)",
					fill: "var(--color-fg)",
					fillOpacity: .12,
					strokeWidth: 1.5,
					isAnimationActive: false,
					dot: false
				})]
			})
		})
	});
}
//#endregion
export { CpuChart };
