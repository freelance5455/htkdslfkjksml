import { i as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, x as require_react } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { D as todayIso, E as suggestTags, O as useFlock, a as HEALTH_PRESETS, d as compareSheep, i as HEALTH_KIND_LABEL, n as BREEDS, o as PENS, s as addDays, u as cn } from "./store-g4o8WGZx.mjs";
import { t as Input } from "./input-CkkIr1XO.mjs";
import { t as Button } from "./button-C77Erh3S.mjs";
import { n as NativeSelect, t as Field } from "./field-DxoiOhiJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/forms-z1jNLbZu.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("min-h-24 w-full rounded-lg border border-input bg-background px-3 py-2 text-base text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:opacity-40", className),
		...props
	});
}
function Chip({ active, children, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: cn("h-9 rounded-full px-3 text-sm", active ? "bg-primary text-primary-foreground" : "border border-border text-muted-foreground"),
		children
	});
}
function SheepForm({ sheepId, onSaved }) {
	const sheep = useFlock((s) => s.sheep);
	const saveSheep = useFlock((s) => s.saveSheep);
	const current = sheep.find((s) => s.id === sheepId);
	const [tag, setTag] = (0, import_react.useState)(current?.tag ?? "");
	const [name, setName] = (0, import_react.useState)(current?.name ?? "");
	const [sex, setSex] = (0, import_react.useState)(current?.sex ?? "ewe");
	const [birthDate, setBirthDate] = (0, import_react.useState)(current?.birthDate ?? "");
	const [breed, setBreed] = (0, import_react.useState)(current?.breed ?? "أولاد جلال");
	const [weight, setWeight] = (0, import_react.useState)(current?.weightKg != null ? String(current.weightKg) : "");
	const [status, setStatus] = (0, import_react.useState)(current?.status ?? "active");
	const [pen, setPen] = (0, import_react.useState)(current?.pen ?? "حظيرة 1");
	const [notes, setNotes] = (0, import_react.useState)(current?.notes ?? "");
	const [damId, setDamId] = (0, import_react.useState)(current?.damId ?? "");
	const [sireId, setSireId] = (0, import_react.useState)(current?.sireId ?? "");
	const [error, setError] = (0, import_react.useState)(null);
	const dams = sheep.filter((s) => s.sex === "ewe" && s.id !== sheepId).slice().sort(compareSheep);
	const sires = sheep.filter((s) => s.sex === "ram" && s.id !== sheepId).slice().sort(compareSheep);
	function onSubmit(e) {
		e.preventDefault();
		const weightKg = weight.trim() === "" ? current?.weightKg ?? null : Number(weight.replace(",", "."));
		const draft = {
			tag,
			name,
			sex,
			birthDate,
			breed,
			weightKg: weightKg != null && Number.isFinite(weightKg) ? weightKg : null,
			status,
			pen,
			notes,
			damId: damId || null,
			sireId: sireId || null
		};
		if (weight.trim() !== "" && (weightKg == null || !Number.isFinite(weightKg))) {
			setError("الوزن غير مفهوم");
			return;
		}
		const result = saveSheep(draft, sheepId);
		if ("error" in result) {
			setError(result.error);
			return;
		}
		onSaved?.(result.id);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		id: "sheep-form",
		onSubmit,
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "رقم الحلقة",
				htmlFor: "tag",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "tag",
					value: tag,
					onChange: (e) => setTag(e.target.value),
					placeholder: "مثلاً 21",
					autoComplete: "off",
					required: true
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "الاسم",
				htmlFor: "name",
				hint: "اختياري",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "name",
					value: name,
					onChange: (e) => setName(e.target.value),
					placeholder: "اسم تعرفه به"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "الجنس",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
						active: sex === "ewe",
						onClick: () => setSex("ewe"),
						children: "نعجة"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
						active: sex === "ram",
						onClick: () => setSex("ram"),
						children: "كبش"
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "تاريخ الميلاد",
				htmlFor: "birth",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "birth",
					type: "date",
					value: birthDate,
					max: todayIso(),
					onChange: (e) => setBirthDate(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
				label: "السلالة",
				htmlFor: "breed",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "breed",
					value: breed,
					onChange: (e) => setBreed(e.target.value),
					list: "breeds"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2",
					children: BREEDS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
						active: breed === item,
						onClick: () => setBreed(item),
						children: item
					}, item))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("datalist", {
				id: "breeds",
				children: BREEDS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: item }, item))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "الوزن الحالي",
				htmlFor: "weight",
				hint: "بالكيلوغرام، ويُضاف لسجل الأوزان",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "weight",
					inputMode: "decimal",
					value: weight,
					onChange: (e) => setWeight(e.target.value),
					placeholder: "48"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "الحالة",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(NativeSelect, {
					value: status,
					onChange: (v) => setStatus(v),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "active",
							children: "سليم"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "sick",
							children: "مريض"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "sold",
							children: "مبيع"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "dead",
							children: "نافق"
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
				label: "الحظيرة",
				htmlFor: "pen",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "pen",
					value: pen,
					onChange: (e) => setPen(e.target.value),
					list: "pens"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("datalist", {
					id: "pens",
					children: PENS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: item }, item))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "الأم",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(NativeSelect, {
					value: damId,
					onChange: setDamId,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "غير محددة"
					}), dams.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: s.id,
						children: s.name ? `${s.tag} · ${s.name}` : s.tag
					}, s.id))]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "الأب",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(NativeSelect, {
					value: sireId,
					onChange: setSireId,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "غير محدد"
					}), sires.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: s.id,
						children: s.name ? `${s.tag} · ${s.name}` : s.tag
					}, s.id))]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "ملاحظات",
				htmlFor: "notes",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					id: "notes",
					value: notes,
					onChange: (e) => setNotes(e.target.value),
					rows: 3
				})
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-danger",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				className: "w-full",
				children: "حفظ"
			})
		]
	});
}
function HealthForm({ defaultSheepId = null, onDone }) {
	const sheep = useFlock((s) => s.sheep);
	const addHealth = useFlock((s) => s.addHealth);
	const [date, setDate] = (0, import_react.useState)(todayIso());
	const [kind, setKind] = (0, import_react.useState)("treatment");
	const [sheepId, setSheepId] = (0, import_react.useState)(defaultSheepId ?? "");
	const [title, setTitle] = (0, import_react.useState)("");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [markSick, setMarkSick] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const options = (0, import_react.useMemo)(() => sheep.filter((s) => s.status === "active" || s.status === "sick").slice().sort(compareSheep), [sheep]);
	function onSubmit(e) {
		e.preventDefault();
		const result = addHealth({
			sheepId: sheepId || null,
			date,
			kind,
			title,
			notes,
			markSick: markSick && Boolean(sheepId)
		});
		if ("error" in result) {
			setError(result.error);
			return;
		}
		setTitle("");
		setNotes("");
		setMarkSick(false);
		setError(null);
		onDone?.();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit,
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "النوع",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2",
					children: Object.keys(HEALTH_KIND_LABEL).map((key) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
						active: kind === key,
						onClick: () => setKind(key),
						children: HEALTH_KIND_LABEL[key]
					}, key))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
				label: "ماذا تم",
				htmlFor: "health-title",
				error: error ?? void 0,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "health-title",
					value: title,
					onChange: (e) => setTitle(e.target.value),
					placeholder: "مثلاً طارد ديدان"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2",
					children: HEALTH_PRESETS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
						active: title === item,
						onClick: () => setTitle(item),
						children: item
					}, item))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "الرأس",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(NativeSelect, {
					value: sheepId,
					onChange: setSheepId,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "القطيع كله"
					}), options.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: s.id,
						children: s.name ? `${s.tag} · ${s.name}` : s.tag
					}, s.id))]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "التاريخ",
				htmlFor: "health-date",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "health-date",
					type: "date",
					value: date,
					onChange: (e) => setDate(e.target.value),
					required: true
				})
			}),
			sheepId ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex items-center gap-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					checked: markSick,
					onChange: (e) => setMarkSick(e.target.checked),
					className: "size-4 accent-[var(--foreground)]"
				}), "تعليم هذا الرأس مريضاً"]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "تفصيل",
				htmlFor: "health-notes",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					id: "health-notes",
					value: notes,
					onChange: (e) => setNotes(e.target.value),
					rows: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				children: "حفظ السجل"
			})
		]
	});
}
function BreedingForm({ defaultEweId, onDone }) {
	const sheep = useFlock((s) => s.sheep);
	const gestationDays = useFlock((s) => s.gestationDays);
	const addBreeding = useFlock((s) => s.addBreeding);
	const ewes = sheep.filter((s) => s.sex === "ewe" && (s.status === "active" || s.status === "sick")).slice().sort(compareSheep);
	const rams = sheep.filter((s) => s.sex === "ram" && (s.status === "active" || s.status === "sick")).slice().sort(compareSheep);
	const [eweId, setEweId] = (0, import_react.useState)(defaultEweId ?? ewes[0]?.id ?? "");
	const [ramId, setRamId] = (0, import_react.useState)("");
	const [matingDate, setMatingDate] = (0, import_react.useState)(todayIso());
	const [expectedDate, setExpectedDate] = (0, import_react.useState)(addDays(todayIso(), gestationDays));
	const [touched, setTouched] = (0, import_react.useState)(false);
	const [notes, setNotes] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	function changeMating(value) {
		setMatingDate(value);
		if (!touched && value) setExpectedDate(addDays(value, gestationDays));
	}
	function onSubmit(e) {
		e.preventDefault();
		const result = addBreeding({
			eweId,
			ramId: ramId || null,
			matingDate,
			expectedDate,
			notes
		});
		if ("error" in result) {
			setError(result.error);
			return;
		}
		setNotes("");
		setError(null);
		onDone?.();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit,
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "النعجة",
				error: error ?? void 0,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(NativeSelect, {
					value: eweId,
					onChange: setEweId,
					children: [ewes.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "لا نعاج في القطيع"
					}) : null, ewes.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: s.id,
						children: s.name ? `${s.tag} · ${s.name}` : s.tag
					}, s.id))]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "الكبش",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(NativeSelect, {
					value: ramId,
					onChange: setRamId,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "غير محدد"
					}), rams.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: s.id,
						children: s.name ? `${s.tag} · ${s.name}` : s.tag
					}, s.id))]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "تاريخ التلقيح",
				htmlFor: "mate-date",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "mate-date",
					type: "date",
					value: matingDate,
					onChange: (e) => changeMating(e.target.value),
					required: true
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "الولادة المتوقعة",
				htmlFor: "due-date",
				hint: `حساب افتراضي ${gestationDays} يوماً، ويمكن تعديله`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "due-date",
					type: "date",
					value: expectedDate,
					onChange: (e) => {
						setTouched(true);
						setExpectedDate(e.target.value);
					},
					required: true
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "ملاحظة",
				htmlFor: "breed-notes",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					id: "breed-notes",
					value: notes,
					onChange: (e) => setNotes(e.target.value),
					rows: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				disabled: !eweId,
				children: "حفظ التلقيح"
			})
		]
	});
}
function LambingForm({ breedingId, onDone }) {
	const sheep = useFlock((s) => s.sheep);
	const recordLambing = useFlock((s) => s.recordLambing);
	const [date, setDate] = (0, import_react.useState)(todayIso());
	const [count, setCount] = (0, import_react.useState)(1);
	const [rows, setRows] = (0, import_react.useState)(() => suggestTags(sheep, 1).map((tag) => ({
		tag,
		sex: "ewe"
	})));
	const [error, setError] = (0, import_react.useState)(null);
	function resize(next) {
		const n = Math.min(4, Math.max(1, next));
		setCount(n);
		setRows((prev) => {
			if (prev.length === n) return prev;
			if (prev.length > n) return prev.slice(0, n);
			const extra = suggestTags(sheep, n).slice(prev.length);
			return [...prev, ...extra.map((tag) => ({
				tag,
				sex: "ewe"
			}))];
		});
	}
	function onSubmit(e) {
		e.preventDefault();
		const result = recordLambing(breedingId, date, rows.slice(0, count));
		if ("error" in result) {
			setError(result.error);
			return;
		}
		onDone?.();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit,
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "تاريخ الولادة",
				htmlFor: "lamb-date",
				error: error ?? void 0,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "lamb-date",
					type: "date",
					value: date,
					max: todayIso(),
					onChange: (e) => setDate(e.target.value),
					required: true
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "عدد المواليد",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							size: "icon",
							onClick: () => resize(count - 1),
							"aria-label": "أنقص",
							children: "−"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-8 text-center text-lg font-semibold tabular-nums",
							children: count
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							size: "icon",
							onClick: () => resize(count + 1),
							"aria-label": "زد",
							children: "+"
						})
					]
				})
			}),
			rows.slice(0, count).map((row, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-[1fr_8rem] gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: `حلقة المولود ${index + 1}`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: row.tag,
						onChange: (e) => setRows((prev) => prev.map((item, i) => i === index ? {
							...item,
							tag: e.target.value
						} : item))
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "الجنس",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(NativeSelect, {
						value: row.sex,
						onChange: (v) => setRows((prev) => prev.map((item, i) => i === index ? {
							...item,
							sex: v
						} : item)),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "ewe",
							children: "أنثى"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "ram",
							children: "ذكر"
						})]
					})
				})]
			}, index)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				children: "تسجيل الولادة وإضافة المواليد"
			})
		]
	});
}
//#endregion
export { SheepForm as i, HealthForm as n, LambingForm as r, BreedingForm as t };
