import { o as __toESM } from "../_runtime.mjs";
import { i as fullName, r as formatScore } from "./calc-DDlXNlj6.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { P as require_jsx_runtime, _ as DialogTrigger$1, d as DialogClose, f as DialogContent$1, g as DialogTitle$1, h as DialogPortal$1, m as DialogOverlay$1, p as DialogDescription$1, u as Dialog$1 } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as Card } from "./card-n_ZyUc_C.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as listStudents, l as listSchools, r as createStudent, t as Skeleton, u as listStreams } from "./server-BRpT2GPU.mjs";
import { n as MentionBadge, t as DecisionBadge } from "./mention-badge-kWeo3_az.mjs";
import { a as Search, c as Plus, t as X } from "../_libs/lucide-react.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Button } from "./button-C0qE0jyX.mjs";
import { a as SelectTrigger, c as TableBody, d as TableHeader, f as TableRow, i as SelectItem, l as TableCell, n as Select, o as SelectValue, r as SelectContent, s as Table, t as Input, u as TableHead } from "./table-DKHBmBA9.mjs";
import { t as StudentForm } from "./student-form-DnG5GB3q.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/students-C23p8wYe.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Dialog = Dialog$1;
var DialogTrigger = DialogTrigger$1;
var DialogPortal = DialogPortal$1;
var DialogOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
	ref,
	className: cn("fixed inset-0 z-50 bg-ink/40 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props
}));
DialogOverlay.displayName = DialogOverlay$1.displayName;
var DialogContent = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
	ref,
	className: cn("fixed top-1/2 left-1/2 z-50 grid w-[calc(100%-2rem)] max-w-lg -translate-x-1/2 -translate-y-1/2 gap-4 rounded-xl bg-surface p-4 shadow-card duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute top-4 left-4 rounded-xs p-1 text-muted transition-opacity hover:text-fg focus:outline-none",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "إغلاق"
		})]
	})]
})] }));
DialogContent.displayName = DialogContent$1.displayName;
function DialogHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex flex-col gap-1.5 text-start", className),
		...props
	});
}
var DialogTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
	ref,
	className: cn("text-lg font-semibold text-fg", className),
	...props
}));
DialogTitle.displayName = DialogTitle$1.displayName;
var DialogDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
	ref,
	className: cn("text-sm text-muted", className),
	...props
}));
DialogDescription.displayName = DialogDescription$1.displayName;
function StudentsPage() {
	const navigate = useNavigate();
	const queryClient = useQueryClient();
	const [q, setQ] = (0, import_react.useState)("");
	const [streamId, setStreamId] = (0, import_react.useState)("all");
	const [decision, setDecision] = (0, import_react.useState)("all");
	const [open, setOpen] = (0, import_react.useState)(false);
	const filters = {
		q: q.trim() || void 0,
		streamId: streamId === "all" ? void 0 : Number(streamId),
		decision: decision === "all" ? void 0 : decision
	};
	const studentsQuery = useQuery({
		queryKey: ["students", filters],
		queryFn: () => listStudents({ data: filters })
	});
	const streamsQuery = useQuery({
		queryKey: ["streams"],
		queryFn: () => listStreams()
	});
	const schoolsQuery = useQuery({
		queryKey: ["schools"],
		queryFn: () => listSchools()
	});
	const createMutation = useMutation({
		mutationFn: createStudent,
		onSuccess: (created) => {
			toast.success(`تم تسجيل المترشح برقم ${created.examNumber}`);
			queryClient.invalidateQueries({ queryKey: ["students"] });
			queryClient.invalidateQueries({ queryKey: ["dashboard"] });
			setOpen(false);
			navigate({
				to: "/students/$id",
				params: { id: String(created.id) }
			});
		},
		onError: (err) => toast.error(err.message)
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-semibold",
					children: "المترشحون"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "سجل المترشحين لشهادة البكالوريا وإدارة ملفاتهم."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
					open,
					onOpenChange: setOpen,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "تسجيل مترشح"] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "مترشح جديد" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "يُولَّد رقم التسجيل تلقائياً. بعد الحفظ يمكن إدخال العلامات." })] }), streamsQuery.data && schoolsQuery.data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudentForm, {
						streams: streamsQuery.data,
						schools: schoolsQuery.data,
						submitLabel: "حفظ المترشح",
						pending: createMutation.isPending,
						onSubmit: (values) => createMutation.mutate({ data: values })
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-40" })] })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 md:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative md:col-span-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-1/2 right-3 size-4 -translate-y-1/2 text-subtle" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								className: "pr-9",
								placeholder: "بحث بالاسم أو رقم التسجيل",
								value: q,
								onChange: (e) => setQ(e.target.value)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: streamId,
							onValueChange: setStreamId,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "الشعبة" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "all",
								children: "كل الشعب"
							}), streamsQuery.data?.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: String(s.id),
								children: s.nameAr
							}, s.id))] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: decision,
							onValueChange: setDecision,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "الحسم" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "all",
									children: "كل الحالات"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "ناجح",
									children: "ناجح"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "راسب",
									children: "راسب"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "قيد الإدخال",
									children: "قيد الإدخال"
								})
							] })]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "overflow-hidden p-0",
				children: studentsQuery.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-2 p-4",
					children: Array.from({ length: 6 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-12" }, i))
				}) : !studentsQuery.data?.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "p-8 text-center text-sm text-muted",
					children: "لا يوجد مترشحون مطابقون للبحث."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "رقم التسجيل" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "المترشح" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "الشعبة" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "الثانوية" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "المعدل" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "التقدير" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "الحسم" })
				] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: studentsQuery.data.map((student) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, {
					className: "cursor-pointer",
					onClick: () => void navigate({
						to: "/students/$id",
						params: { id: String(student.id) }
					}),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							className: "font-medium tabular-nums",
							children: student.examNumber
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: fullName(student.lastName, student.firstName) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: student.streamName }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							className: "max-w-[12rem] truncate",
							children: student.schoolName
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							className: "tabular-nums",
							children: formatScore(student.average)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MentionBadge, {
							mention: student.mention,
							decision: student.decision
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DecisionBadge, { decision: student.decision }) })
					]
				}, student.id)) })] })
			})
		]
	});
}
//#endregion
export { StudentsPage as component };
