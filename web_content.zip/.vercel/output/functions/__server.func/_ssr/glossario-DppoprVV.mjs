import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as useStudy } from "./router-C-xQh0iG.mjs";
import { t as glossEntries } from "./glossary-ClGpQtp5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/glossario-DppoprVV.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Glossario() {
	const [q, setQ] = (0, import_react.useState)("");
	const asks = useStudy((s) => s.asks);
	const entries = (0, import_react.useMemo)(() => {
		const query = q.trim().toLowerCase();
		return glossEntries().filter((e) => {
			if (e.key.length < 4 && !e.note) return false;
			if (!query) return Boolean(e.note) || e.key.includes(" ");
			return e.key.includes(query) || e.ar.includes(q.trim());
		});
	}, [q]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-primary",
					children: "Dizionario"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-3xl font-semibold",
					children: "القاموس"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-muted",
					children: "من أي جملة في المنهج أو الامتحان اضغط الكلمة. هنا مصطلحات القيادة، وتحتُها الأسئلة التي حفظتها بعد الشرح."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: q,
				onChange: (e) => setQ(e.target.value),
				placeholder: "ابحث: precedenza، حزام، nebbia…",
				className: "min-h-11 w-full rounded-xl border border-line bg-surface px-3 outline-none focus:border-primary"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: entries.slice(0, 80).map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-2xl border border-line bg-surface px-3 py-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							dir: "ltr",
							lang: "it",
							className: "text-left text-lg font-semibold",
							children: e.key
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-base",
							children: e.ar
						}),
						e.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: e.note
						}) : null
					]
				}, e.key))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-2xl font-semibold",
				children: "أسئلتي المحفوظة"
			}), asks.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-muted",
				children: "لما تضغط كلمة وتطلب شرحًا ثم تحفظه، يظهر هنا."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 space-y-3",
				children: asks.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-2xl bg-warn px-3 py-3 text-warn-ink",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							dir: "ltr",
							lang: "it",
							className: "text-left font-semibold",
							children: a.word
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm",
							children: a.question
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed",
							children: a.answer
						})
					]
				}, a.id))
			})] })
		]
	});
}
//#endregion
export { Glossario as component };
