import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Play, c as LocateFixed, i as Plus, l as Hand, n as Volume2, o as Pause, s as Minus, t as VolumeX } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DqKdakFN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ctx = null;
var muted = false;
var lastHit = 0;
function setMuted(next) {
	muted = next;
	if (muted && ctx && ctx.state === "running") ctx.suspend();
	if (!muted && ctx && ctx.state === "suspended") ctx.resume();
}
function unlockAudio() {
	if (typeof window === "undefined") return;
	if (!ctx) ctx = new AudioContext();
	if (!muted && ctx.state === "suspended") ctx.resume();
}
function beep(freq, dur, gain, type, slide = 0) {
	if (!ctx || muted || ctx.state !== "running") return;
	const t = ctx.currentTime;
	const o = ctx.createOscillator();
	const g = ctx.createGain();
	o.type = type;
	o.frequency.setValueAtTime(Math.max(40, freq), t);
	const endFreq = Math.max(40, freq + slide);
	o.frequency.exponentialRampToValueAtTime(endFreq, t + dur);
	g.gain.setValueAtTime(gain, t);
	g.gain.exponentialRampToValueAtTime(1e-4, t + dur);
	o.connect(g);
	g.connect(ctx.destination);
	o.start(t);
	o.stop(t + dur + .02);
}
function playFling(speed) {
	const s = Math.min(1, speed / 700);
	beep(160 + s * 240, .11, .025 + s * .02, "sine", -70);
}
function playHit(speed) {
	if (!ctx || muted || ctx.state !== "running") return;
	const t = ctx.currentTime;
	if (t - lastHit < .05) return;
	lastHit = t;
	const s = Math.min(1, speed / 450);
	beep(78 + s * 50, .08, .022 + s * .028, "triangle", -36);
}
function playMerge() {
	beep(64, .2, .04, "sine", -28);
}
var STEP = 1 / 240;
var MAX_STEPS = 28;
var SLOP = .75;
var ESCAPE2 = 256e6;
var SPEED_CULL2 = 49e6;
var PRESET_LIST = [
	{
		id: "dust",
		label: "Dust",
		mass: 2.5,
		kind: "rock",
		color: "#a8aeb6",
		core: "#eef1f3"
	},
	{
		id: "moon",
		label: "Moon",
		mass: 26,
		kind: "rock",
		color: "#c4bbb0",
		core: "#f4f0ea"
	},
	{
		id: "planet",
		label: "Planet",
		mass: 150,
		kind: "rock",
		color: "#6f8f86",
		core: "#e7f1ed"
	},
	{
		id: "giant",
		label: "Giant",
		mass: 820,
		kind: "gas",
		color: "#8496aa",
		core: "#e8eef4"
	},
	{
		id: "star",
		label: "Star",
		mass: 7e3,
		kind: "star",
		color: "#f7f4ee",
		core: "#ffffff"
	},
	{
		id: "hole",
		label: "Hole",
		mass: 26e3,
		kind: "hole",
		color: "#050506",
		core: "#14161c"
	}
];
var PRESET_MAP = Object.fromEntries(PRESET_LIST.map((p) => [p.id, p]));
function getPreset(id) {
	return PRESET_MAP[id];
}
var SCENARIOS = [
	{
		id: "star",
		label: "1 star"
	},
	{
		id: "binary",
		label: "Binary"
	},
	{
		id: "eight",
		label: "Figure 8"
	},
	{
		id: "sling",
		label: "Slingshot"
	},
	{
		id: "system",
		label: "System"
	},
	{
		id: "swarm",
		label: "Swarm"
	}
];
function clamp(n, a, b) {
	return Math.max(a, Math.min(b, n));
}
function radiusFromMass(mass, kind) {
	return clamp(Math.cbrt(Math.max(mass, .001) / (kind === "hole" ? 12 : kind === "star" ? .62 : kind === "gas" ? .05 : .058)), kind === "hole" ? 10 : kind === "star" ? 16 : kind === "gas" ? 14 : 2.6, kind === "hole" ? 22 : kind === "star" ? 38 : kind === "gas" ? 54 : 36);
}
function emptySim() {
	return {
		bodies: [],
		g: 400,
		nextId: 1,
		time: 0,
		mode: "bounce",
		trails: true,
		emit: true,
		events: [],
		minSep: Infinity,
		maxSpeed: 0,
		acc: 0,
		step: 0
	};
}
function bodyFrom(id, presetId, x, y, vx, vy, overrides) {
	const p = PRESET_MAP[presetId];
	const mass = overrides?.mass ?? p.mass;
	const radius = overrides?.radius ?? radiusFromMass(mass, p.kind);
	return {
		id,
		preset: presetId,
		kind: p.kind,
		x,
		y,
		vx,
		vy,
		ax: 0,
		ay: 0,
		mass,
		radius,
		color: p.color,
		core: p.core,
		trail: /* @__PURE__ */ new Float32Array(560),
		trailWrite: 0,
		trailFill: 0
	};
}
function take(sim, preset, x, y, vx, vy, overrides) {
	return bodyFrom(sim.nextId++, preset, x, y, vx, vy, overrides);
}
function balance(bodies) {
	let m = 0;
	let cx = 0;
	let cy = 0;
	let px = 0;
	let py = 0;
	for (const b of bodies) {
		m += b.mass;
		cx += b.mass * b.x;
		cy += b.mass * b.y;
		px += b.mass * b.vx;
		py += b.mass * b.vy;
	}
	if (m <= 0) return;
	cx /= m;
	cy /= m;
	px /= m;
	py /= m;
	for (const b of bodies) {
		b.x -= cx;
		b.y -= cy;
		b.vx -= px;
		b.vy -= py;
	}
}
function mulberry32(seed) {
	let s = seed >>> 0;
	return () => {
		s = s + 1831565813 | 0;
		let t = Math.imul(s ^ s >>> 15, 1 | s);
		t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
var FIG8_S = 220;
var FIG8_M = 2200;
function buildScenario(sim, id) {
	if (id === "star") return [take(sim, "star", 0, 0, 0, 0)];
	if (id === "binary") {
		const m = 4600;
		const d = 300;
		const v = Math.sqrt(400 * m / (2 * d));
		const bodies = [take(sim, "star", -150, 0, 0, -v, {
			mass: m,
			radius: 20
		}), take(sim, "star", d / 2, 0, 0, v, {
			mass: m,
			radius: 20
		})];
		balance(bodies);
		return bodies;
	}
	if (id === "eight") {
		const vScale = FIG8_S / Math.sqrt(48400 * FIG8_S / (400 * FIG8_M));
		const bodies = [
			[
				.97000436,
				-.24308753,
				.466203685,
				.43236573
			],
			[
				-.97000436,
				.24308753,
				.466203685,
				.43236573
			],
			[
				0,
				0,
				-.93240737,
				-.86473146
			]
		].map(([x, y, vx, vy]) => take(sim, "planet", x * FIG8_S, y * FIG8_S, vx * vScale, vy * vScale, {
			mass: FIG8_M,
			radius: 7
		}));
		balance(bodies);
		return bodies;
	}
	if (id === "sling") {
		const bodies = [take(sim, "star", 0, 0, 0, 0, { mass: 14e3 }), take(sim, "moon", -720, 96, 188, 6, {
			mass: 14,
			radius: 6
		})];
		balance(bodies);
		return bodies;
	}
	if (id === "swarm") {
		const rng = mulberry32(42);
		const starMass = 9e3;
		const bodies = [take(sim, "star", 0, 0, 0, 0, { mass: starMass })];
		for (let i = 0; i < 8; i++) {
			const ang = rng() * Math.PI * 2;
			const r = 160 + rng() * 360;
			const mass = 6 + rng() * 40;
			const preset = mass < 14 ? "dust" : "moon";
			const v = Math.sqrt(400 * (starMass + mass) / r) * (.88 + rng() * .2);
			bodies.push(take(sim, preset, Math.cos(ang) * r, Math.sin(ang) * r, -Math.sin(ang) * v, Math.cos(ang) * v, { mass }));
		}
		balance(bodies);
		return bodies;
	}
	const starMass = 11e3;
	const bodies = [take(sim, "star", 0, 0, 0, 0, { mass: starMass })];
	for (const spec of [
		{
			preset: "planet",
			mass: 42,
			r: 150,
			ang: .4
		},
		{
			preset: "planet",
			mass: 68,
			r: 290,
			ang: 2.5
		},
		{
			preset: "giant",
			mass: 210,
			r: 620,
			ang: 4.5
		}
	]) {
		const v = Math.sqrt(400 * (starMass + spec.mass) / spec.r);
		const x = Math.cos(spec.ang) * spec.r;
		const y = Math.sin(spec.ang) * spec.r;
		bodies.push(take(sim, spec.preset, x, y, -Math.sin(spec.ang) * v, Math.cos(spec.ang) * v, { mass: spec.mass }));
	}
	balance(bodies);
	return bodies;
}
function loadScenario(sim, id) {
	sim.bodies = buildScenario(sim, id);
	sim.time = 0;
	sim.acc = 0;
	sim.step = 0;
	sim.events.length = 0;
	sim.minSep = Infinity;
	sim.maxSpeed = 0;
	computeAccel(sim);
}
function createSim() {
	const sim = emptySim();
	loadScenario(sim, "system");
	sim.emit = false;
	for (let i = 0; i < 100; i++) advanceSim(sim, 1 / 60, 1);
	sim.emit = true;
	sim.events.length = 0;
	return sim;
}
function clearBodies(sim) {
	sim.bodies.length = 0;
	sim.time = 0;
	sim.acc = 0;
	sim.step = 0;
	sim.events.length = 0;
	sim.minSep = Infinity;
	sim.maxSpeed = 0;
}
function addBody(sim, preset, x, y, vx, vy) {
	if (sim.bodies.length >= 40) return null;
	const speed = Math.hypot(vx, vy);
	if (speed > 1400) {
		const s = 1400 / speed;
		vx *= s;
		vy *= s;
	}
	const b = take(sim, preset, x, y, vx, vy);
	sim.bodies.push(b);
	computeAccel(sim);
	return b;
}
function removeBody(sim, id) {
	const i = sim.bodies.findIndex((b) => b.id === id);
	if (i >= 0) sim.bodies.splice(i, 1);
	computeAccel(sim);
}
function setBodyVelocity(sim, id, vx, vy) {
	const b = sim.bodies.find((body) => body.id === id);
	if (!b) return;
	const speed = Math.hypot(vx, vy);
	if (speed > 1400) {
		const s = 1400 / speed;
		vx *= s;
		vy *= s;
	}
	b.vx = vx;
	b.vy = vy;
	let max = 0;
	for (const body of sim.bodies) {
		const sp = body.vx * body.vx + body.vy * body.vy;
		if (sp > max) max = sp;
	}
	sim.maxSpeed = Math.sqrt(max);
}
function computeAccel(sim) {
	const bodies = sim.bodies;
	const n = bodies.length;
	let minSep = Infinity;
	let maxSpeed2 = 0;
	for (let i = 0; i < n; i++) {
		const b = bodies[i];
		b.ax = 0;
		b.ay = 0;
		const sp = b.vx * b.vx + b.vy * b.vy;
		if (sp > maxSpeed2) maxSpeed2 = sp;
	}
	sim.maxSpeed = Math.sqrt(maxSpeed2);
	const g = sim.g;
	const soft2 = 36;
	for (let i = 0; i < n; i++) {
		const a = bodies[i];
		for (let j = i + 1; j < n; j++) {
			const b = bodies[j];
			const dx = b.x - a.x;
			const dy = b.y - a.y;
			const d2 = dx * dx + dy * dy;
			const dist = Math.sqrt(d2);
			if (dist < minSep) minSep = dist;
			const inv = 1 / Math.sqrt(d2 + soft2);
			const s = g * (inv * inv * inv);
			const sax = s * b.mass * dx;
			const say = s * b.mass * dy;
			a.ax += sax;
			a.ay += say;
			b.ax -= s * a.mass * dx;
			b.ay -= s * a.mass * dy;
		}
	}
	sim.minSep = minSep;
}
function chooseSub(sim, step) {
	let n = 1;
	const speedStep = sim.maxSpeed * step;
	if (speedStep > 5) n = Math.ceil(speedStep / 5);
	const bodies = sim.bodies;
	for (let i = 0; i < bodies.length; i++) {
		const a = bodies[i];
		for (let j = i + 1; j < bodies.length; j++) {
			const b = bodies[j];
			const dx = b.x - a.x;
			const dy = b.y - a.y;
			const dist2 = dx * dx + dy * dy;
			if (dist2 > 4e4) continue;
			const dist = Math.sqrt(dist2) || .001;
			const dvx = b.vx - a.vx;
			const dvy = b.vy - a.vy;
			const closing = -((dx * dvx + dy * dvy) / dist);
			const rel = Math.hypot(dvx, dvy);
			const budget = Math.max(2.4, dist * .1);
			const need = Math.ceil(Math.max(closing, rel * .35) * step / budget);
			if (need > n) n = need;
		}
	}
	return clamp(n, 1, 8);
}
function cull(sim) {
	const bodies = sim.bodies;
	let w = 0;
	for (let i = 0; i < bodies.length; i++) {
		const b = bodies[i];
		if (Number.isFinite(b.x) && Number.isFinite(b.y) && Number.isFinite(b.vx) && Number.isFinite(b.vy) && b.x * b.x + b.y * b.y < ESCAPE2 && b.vx * b.vx + b.vy * b.vy < SPEED_CULL2) bodies[w++] = b;
	}
	bodies.length = w;
}
function mergePair(sim, i, j) {
	const bodies = sim.bodies;
	const a = bodies[i];
	const b = bodies[j];
	const big = a.mass >= b.mass ? a : b;
	const small = big === a ? b : a;
	const mass = a.mass + b.mass;
	const rel = Math.hypot(a.vx - b.vx, a.vy - b.vy);
	big.x = (a.x * a.mass + b.x * b.mass) / mass;
	big.y = (a.y * a.mass + b.y * b.mass) / mass;
	big.vx = (a.vx * a.mass + b.vx * b.mass) / mass;
	big.vy = (a.vy * a.mass + b.vy * b.mass) / mass;
	const prevKind = big.kind;
	const otherKind = small.kind;
	let kind = prevKind;
	if (prevKind === "hole" || otherKind === "hole" || mass >= 18e3) kind = "hole";
	else if (prevKind === "star" || otherKind === "star" || mass >= 3600) kind = "star";
	else if (prevKind === "gas" || otherKind === "gas" || mass >= 520) kind = "gas";
	else kind = "rock";
	if (kind !== prevKind) {
		const id = kind === "hole" ? "hole" : kind === "star" ? "star" : kind === "gas" ? "giant" : "planet";
		const p = PRESET_MAP[id];
		big.preset = id;
		big.color = p.color;
		big.core = p.core;
	}
	big.kind = kind;
	big.mass = mass;
	big.radius = radiusFromMass(mass, kind);
	const idx = bodies.indexOf(small);
	if (idx >= 0) bodies.splice(idx, 1);
	if (sim.emit && rel > 18) sim.events.push({
		type: "merge",
		x: big.x,
		y: big.y,
		speed: rel
	});
}
function bouncePair(sim, a, b) {
	let dx = b.x - a.x;
	let dy = b.y - a.y;
	let dist = Math.hypot(dx, dy);
	if (dist < 1e-6) {
		dx = 1;
		dy = 0;
		dist = 1;
	}
	const pen = a.radius + b.radius - dist;
	const nx = dx / dist;
	const ny = dy / dist;
	const invA = 1 / a.mass;
	const invB = 1 / b.mass;
	const inv = invA + invB;
	const corrMag = (pen - SLOP) / inv * 1;
	if (corrMag > 0) {
		a.x -= nx * corrMag * invA;
		a.y -= ny * corrMag * invA;
		b.x += nx * corrMag * invB;
		b.y += ny * corrMag * invB;
	}
	const rvn = (b.vx - a.vx) * nx + (b.vy - a.vy) * ny;
	if (rvn >= 0) return;
	const impact = -rvn;
	const j = (1 + (impact < 36 ? .25 : .86)) * impact / inv;
	a.vx -= j * nx * invA;
	a.vy -= j * ny * invA;
	b.vx += j * nx * invB;
	b.vy += j * ny * invB;
	if (sim.emit && impact > 26) sim.events.push({
		type: "bounce",
		x: (a.x + b.x) * .5,
		y: (a.y + b.y) * .5,
		speed: impact
	});
}
function resolveCollisions(sim) {
	const bodies = sim.bodies;
	const merging = sim.mode === "merge";
	const iterations = merging ? 3 : 5;
	for (let iter = 0; iter < iterations; iter++) {
		let bi = -1;
		let bj = -1;
		let best = SLOP;
		for (let i = 0; i < bodies.length; i++) {
			const a = bodies[i];
			for (let j = i + 1; j < bodies.length; j++) {
				const b = bodies[j];
				const dx = b.x - a.x;
				const dy = b.y - a.y;
				const dist = Math.hypot(dx, dy) || 1e-4;
				const pen = a.radius + b.radius - dist;
				if (pen > best) {
					best = pen;
					bi = i;
					bj = j;
				}
			}
		}
		if (bi < 0) return;
		if (merging) mergePair(sim, bi, bj);
		else bouncePair(sim, bodies[bi], bodies[bj]);
	}
}
function stepSim(sim, h) {
	const bodies = sim.bodies;
	for (let i = 0; i < bodies.length; i++) {
		const b = bodies[i];
		b.vx += b.ax * h * .5;
		b.vy += b.ay * h * .5;
		b.x += b.vx * h;
		b.y += b.vy * h;
	}
	resolveCollisions(sim);
	computeAccel(sim);
	const live = sim.bodies;
	for (let i = 0; i < live.length; i++) {
		const b = live[i];
		b.vx += b.ax * h * .5;
		b.vy += b.ay * h * .5;
	}
	cull(sim);
	sim.time += h;
}
function recordTrails(sim) {
	if (!sim.trails) return;
	const cap = 280;
	for (const b of sim.bodies) {
		if (b.trail.length < cap * 2) continue;
		const w = b.trailWrite;
		b.trail[w * 2] = b.x;
		b.trail[w * 2 + 1] = b.y;
		b.trailWrite = (w + 1) % cap;
		if (b.trailFill < cap) b.trailFill++;
	}
}
function advanceSim(sim, frameDt, timeScale) {
	sim.acc += Math.min(Math.max(frameDt, 0), .05) * Math.max(0, timeScale);
	let n = 0;
	while (sim.acc >= STEP && n < MAX_STEPS) {
		const sub = chooseSub(sim, STEP);
		const h = STEP / sub;
		for (let i = 0; i < sub; i++) stepSim(sim, h);
		sim.step += 1;
		if ((sim.step & 1) === 0) recordTrails(sim);
		sim.acc -= STEP;
		n += 1;
	}
	if (n >= MAX_STEPS) sim.acc = 0;
}
function energyOf(sim) {
	const bodies = sim.bodies;
	let e = 0;
	const soft2 = 36;
	for (let i = 0; i < bodies.length; i++) {
		const a = bodies[i];
		e += .5 * a.mass * (a.vx * a.vx + a.vy * a.vy);
		for (let j = i + 1; j < bodies.length; j++) {
			const b = bodies[j];
			const dx = b.x - a.x;
			const dy = b.y - a.y;
			const dist = Math.sqrt(dx * dx + dy * dy + soft2);
			e -= sim.g * a.mass * b.mass / dist;
		}
	}
	return e;
}
function forecast(sim, ghost, seconds = 2) {
	const bodies = sim.bodies.map((b) => ({
		...b,
		trail: b.trail,
		ax: 0,
		ay: 0
	}));
	let subjectId;
	if (ghost.id == null) {
		const born = bodyFrom(-1, ghost.preset, ghost.x, ghost.y, ghost.vx, ghost.vy);
		bodies.push(born);
		subjectId = -1;
	} else {
		const found = bodies.find((b) => b.id === ghost.id);
		if (!found) return [];
		found.vx = ghost.vx;
		found.vy = ghost.vy;
		subjectId = ghost.id;
	}
	const crowded = bodies.length > 18;
	const horizon = crowded ? 1.15 : seconds;
	const clone = {
		...sim,
		bodies,
		events: [],
		emit: false,
		trails: false,
		acc: 0,
		minSep: Infinity,
		maxSpeed: 0
	};
	computeAccel(clone);
	const subject = clone.bodies.find((b) => b.id === subjectId);
	if (!subject) return [];
	const path = [subject.x, subject.y];
	const slices = crowded ? 14 : 26;
	const slice = horizon / slices;
	for (let s = 0; s < slices; s++) {
		let left = slice;
		while (left > 1e-8) {
			const chunk = Math.min(.05, left);
			advanceSim(clone, chunk, 1);
			left -= chunk;
		}
		const b = clone.bodies.find((body) => body.id === subjectId);
		if (!b) break;
		path.push(b.x, b.y);
	}
	return path;
}
function frameOf(bodies, w, h) {
	if (bodies.length === 0) return {
		x: 0,
		y: 0,
		zoom: 1
	};
	if (bodies.length === 1) return {
		x: bodies[0].x,
		y: bodies[0].y,
		zoom: 1
	};
	let minX = Infinity;
	let maxX = -Infinity;
	let minY = Infinity;
	let maxY = -Infinity;
	for (const b of bodies) {
		minX = Math.min(minX, b.x - b.radius);
		maxX = Math.max(maxX, b.x + b.radius);
		minY = Math.min(minY, b.y - b.radius);
		maxY = Math.max(maxY, b.y + b.radius);
	}
	const bw = Math.max(120, maxX - minX);
	const bh = Math.max(120, maxY - minY);
	const zoom = clamp(Math.min((w - 72) / bw, (h - 200) / bh), .22, 2.2);
	return {
		x: (minX + maxX) / 2,
		y: (minY + maxY) / 2,
		zoom
	};
}
function formatSimTime(t) {
	const clamped = Math.max(0, t);
	const m = Math.floor(clamped / 60);
	const s = clamped - m * 60;
	const whole = Math.floor(s);
	const frac = Math.floor((s - whole) * 10);
	return `${m}:${whole.toString().padStart(2, "0")}.${frac}`;
}
function createStarfield(count, seed) {
	let s = seed >>> 0;
	const rnd = () => {
		s = s + 1831565813 | 0;
		let t = Math.imul(s ^ s >>> 15, 1 | s);
		t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
	const stars = [];
	for (let i = 0; i < count; i++) stars.push({
		u: rnd(),
		v: rnd(),
		r: rnd() < .92 ? .6 : 1.3,
		a: .18 + rnd() * .45,
		phase: rnd() * Math.PI * 2
	});
	return stars;
}
function darken(hex) {
	const n = Number.parseInt(hex.slice(1), 16);
	return `rgb(${Math.round((n >> 16 & 255) * .38)} ${Math.round((n >> 8 & 255) * .38)} ${Math.round((n & 255) * .38)})`;
}
function worldToScreen(x, y, view) {
	return {
		x: (x - view.camX) * view.zoom + view.w / 2 + view.shakeX,
		y: (y - view.camY) * view.zoom + view.h / 2 + view.shakeY
	};
}
function drawTrail(ctx, body, view, frac, alpha, width) {
	const count = Math.max(2, Math.floor(body.trailFill * frac));
	if (body.trailFill < 2 || count < 2) return;
	const start = (body.trailWrite - body.trailFill + 280) % 280;
	const from = body.trailFill - count;
	ctx.beginPath();
	let started = false;
	for (let i = from; i < body.trailFill; i++) {
		const idx = (start + i) % 280;
		const p = worldToScreen(body.trail[idx * 2], body.trail[idx * 2 + 1], view);
		if (!started) {
			ctx.moveTo(p.x, p.y);
			started = true;
		} else ctx.lineTo(p.x, p.y);
	}
	ctx.strokeStyle = hexAlpha(body.color, alpha);
	ctx.lineWidth = width;
	ctx.stroke();
}
function hexAlpha(hex, alpha) {
	const n = Number.parseInt(hex.slice(1), 16);
	return `rgba(${n >> 16 & 255}, ${n >> 8 & 255}, ${n & 255}, ${alpha})`;
}
function drawBody(ctx, body, view, time) {
	const p = worldToScreen(body.x, body.y, view);
	const r = Math.max(1.5, body.radius * view.zoom);
	if (p.x < -r * 6 || p.y < -r * 6 || p.x > view.w + r * 6 || p.y > view.h + r * 6) return;
	if (body.kind === "hole") {
		const lens = ctx.createRadialGradient(p.x, p.y, r, p.x, p.y, r * 5.2);
		lens.addColorStop(0, "rgba(0, 0, 0, 0)");
		lens.addColorStop(.45, "rgba(210, 216, 224, 0.06)");
		lens.addColorStop(1, "rgba(0, 0, 0, 0)");
		ctx.fillStyle = lens;
		ctx.beginPath();
		ctx.arc(p.x, p.y, r * 5.2, 0, Math.PI * 2);
		ctx.fill();
		ctx.save();
		ctx.translate(p.x, p.y);
		ctx.rotate(view.reduce ? .4 : time * .35 + body.id);
		ctx.scale(1, .36);
		ctx.beginPath();
		ctx.arc(0, 0, r * 2.35, 0, Math.PI * 2);
		ctx.strokeStyle = "rgba(214, 220, 228, 0.5)";
		ctx.lineWidth = 1.6;
		ctx.stroke();
		ctx.restore();
		ctx.beginPath();
		ctx.arc(p.x, p.y, r, 0, Math.PI * 2);
		ctx.fillStyle = "#050506";
		ctx.fill();
		ctx.lineWidth = 1;
		ctx.strokeStyle = "rgba(244, 244, 245, 0.72)";
		ctx.stroke();
		return;
	}
	if (body.kind === "star") {
		const pulse = view.reduce ? .42 : .34 + .08 * Math.sin(time * 1.5 + body.id);
		const glow = ctx.createRadialGradient(p.x, p.y, r * .2, p.x, p.y, r * 3.6);
		glow.addColorStop(0, `rgba(255, 252, 246, ${.22 + pulse * .35})`);
		glow.addColorStop(.4, "rgba(247, 244, 238, 0.08)");
		glow.addColorStop(1, "rgba(247, 244, 238, 0)");
		ctx.fillStyle = glow;
		ctx.beginPath();
		ctx.arc(p.x, p.y, r * 3.6, 0, Math.PI * 2);
		ctx.fill();
	}
	if (body.kind === "gas") {
		ctx.save();
		ctx.translate(p.x, p.y);
		ctx.rotate(-.45);
		ctx.scale(1, .34);
		ctx.beginPath();
		ctx.arc(0, 0, r * 1.72, 0, Math.PI * 2);
		ctx.strokeStyle = "rgba(232, 236, 241, 0.38)";
		ctx.lineWidth = Math.max(1, r * .06);
		ctx.stroke();
		ctx.restore();
	}
	const g = ctx.createRadialGradient(p.x - r * .34, p.y - r * .38, r * .08, p.x + r * .1, p.y + r * .15, r);
	g.addColorStop(0, body.core);
	g.addColorStop(.5, body.color);
	g.addColorStop(1, darken(body.color));
	ctx.beginPath();
	ctx.arc(p.x, p.y, r, 0, Math.PI * 2);
	ctx.fillStyle = g;
	ctx.fill();
	if (body.kind === "gas") {
		ctx.save();
		ctx.beginPath();
		ctx.arc(p.x, p.y, r, 0, Math.PI * 2);
		ctx.clip();
		ctx.fillStyle = "rgba(8, 10, 14, 0.2)";
		for (let i = -1; i <= 1; i++) ctx.fillRect(p.x - r, p.y + i * r * .42 - r * .07, r * 2, Math.max(1, r * .1));
		ctx.restore();
	}
}
function drawArrow(ctx, x0, y0, x1, y1) {
	const ang = Math.atan2(y1 - y0, x1 - x0);
	ctx.beginPath();
	ctx.moveTo(x0, y0);
	ctx.lineTo(x1, y1);
	const head = 9;
	ctx.moveTo(x1, y1);
	ctx.lineTo(x1 - head * Math.cos(ang - .45), y1 - head * Math.sin(ang - .45));
	ctx.moveTo(x1, y1);
	ctx.lineTo(x1 - head * Math.cos(ang + .45), y1 - head * Math.sin(ang + .45));
	ctx.stroke();
}
function renderScene(ctx, sim, view, extras) {
	const { dpr } = extras;
	ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
	ctx.clearRect(0, 0, view.w, view.h);
	ctx.fillStyle = "#0a0a0b";
	ctx.fillRect(0, 0, view.w, view.h);
	ctx.fillStyle = "#d5d8de";
	for (const star of extras.stars) {
		ctx.globalAlpha = view.reduce ? star.a : star.a * (.75 + .25 * Math.sin(sim.time * 1.3 + star.phase));
		ctx.beginPath();
		ctx.arc(star.u * view.w, star.v * view.h, star.r, 0, Math.PI * 2);
		ctx.fill();
	}
	ctx.globalAlpha = 1;
	const vignette = ctx.createRadialGradient(view.w / 2, view.h / 2, Math.min(view.w, view.h) * .35, view.w / 2, view.h / 2, Math.max(view.w, view.h) * .72);
	vignette.addColorStop(0, "rgba(0, 0, 0, 0)");
	vignette.addColorStop(1, "rgba(0, 0, 0, 0.38)");
	ctx.fillStyle = vignette;
	ctx.fillRect(0, 0, view.w, view.h);
	if (view.trails) {
		ctx.lineCap = "round";
		ctx.lineJoin = "round";
		for (const body of sim.bodies) {
			const width = Math.max(1, Math.min(2.6, body.radius * view.zoom * .14));
			drawTrail(ctx, body, view, 1, body.kind === "hole" ? .14 : .18, width);
			drawTrail(ctx, body, view, .28, body.kind === "hole" ? .35 : .55, width);
		}
	}
	if (extras.path && extras.path.length >= 4) {
		ctx.save();
		ctx.setLineDash([2, 7]);
		ctx.lineWidth = 1;
		ctx.strokeStyle = "rgba(244, 244, 245, 0.45)";
		ctx.beginPath();
		const p0 = worldToScreen(extras.path[0], extras.path[1], view);
		ctx.moveTo(p0.x, p0.y);
		for (let i = 2; i < extras.path.length; i += 2) {
			const p = worldToScreen(extras.path[i], extras.path[i + 1], view);
			ctx.lineTo(p.x, p.y);
		}
		ctx.stroke();
		ctx.restore();
	}
	for (const body of sim.bodies) drawBody(ctx, body, view, sim.time);
	if (extras.selectedId != null) {
		const body = sim.bodies.find((b) => b.id === extras.selectedId);
		if (body) {
			const p = worldToScreen(body.x, body.y, view);
			const r = Math.max(1.5, body.radius * view.zoom);
			ctx.beginPath();
			ctx.arc(p.x, p.y, r + 5, 0, Math.PI * 2);
			ctx.strokeStyle = "rgba(244, 244, 245, 0.8)";
			ctx.lineWidth = 1;
			ctx.stroke();
		}
	}
	ctx.fillStyle = "#f4f4f5";
	for (const spark of extras.sparks) {
		const p = worldToScreen(spark.x, spark.y, view);
		ctx.globalAlpha = Math.max(0, spark.life / spark.max) * .85;
		ctx.beginPath();
		ctx.arc(p.x, p.y, spark.r, 0, Math.PI * 2);
		ctx.fill();
	}
	ctx.globalAlpha = 1;
	if (sim.bodies.length >= 2) {
		let m = 0;
		let cx = 0;
		let cy = 0;
		for (const b of sim.bodies) {
			m += b.mass;
			cx += b.mass * b.x;
			cy += b.mass * b.y;
		}
		if (m > 0) {
			const p = worldToScreen(cx / m, cy / m, view);
			ctx.strokeStyle = "rgba(244, 244, 245, 0.35)";
			ctx.lineWidth = 1;
			ctx.beginPath();
			ctx.moveTo(p.x - 5, p.y);
			ctx.lineTo(p.x + 5, p.y);
			ctx.moveTo(p.x, p.y - 5);
			ctx.lineTo(p.x, p.y + 5);
			ctx.stroke();
		}
	}
	const drag = extras.drag;
	if (!drag) return;
	const a = worldToScreen(drag.x0, drag.y0, view);
	const b = worldToScreen(drag.x1, drag.y1, view);
	if (drag.kind === "new") {
		const r = Math.max(1.5, drag.radius * view.zoom);
		ctx.beginPath();
		ctx.arc(a.x, a.y, r, 0, Math.PI * 2);
		ctx.fillStyle = hexAlpha(drag.color, .35);
		ctx.fill();
		ctx.strokeStyle = "rgba(244, 244, 245, 0.7)";
		ctx.lineWidth = 1;
		ctx.setLineDash([3, 4]);
		ctx.stroke();
		ctx.setLineDash([]);
	}
	if (!drag.moved) return;
	ctx.strokeStyle = "rgba(244, 244, 245, 0.85)";
	ctx.lineWidth = 1.25;
	drawArrow(ctx, a.x, a.y, b.x, b.y);
	ctx.font = "12px ui-monospace, SFMono-Regular, Menlo, Consolas, monospace";
	ctx.fillStyle = "rgba(244, 244, 245, 0.86)";
	ctx.fillText(`${Math.round(drag.speed)}/s`, b.x + 10, b.y - 8);
}
var ZOOM_MIN = .22;
var ZOOM_MAX = 3.5;
var SETTINGS_KEY = "orrery-settings-v1";
var iconBtn = "inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-md border border-fg/15 bg-elevated text-fg transition-colors duration-150 ease-out hover:bg-subtle focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-fg/40 disabled:opacity-40";
var textBtn = "inline-flex h-11 shrink-0 items-center justify-center rounded-md border border-fg/15 bg-elevated px-3 text-sm font-medium text-fg transition-colors duration-150 ease-out hover:bg-subtle focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-fg/40 disabled:opacity-40";
function screenToWorld(sx, sy, camX, camY, zoom, w, h) {
	return {
		x: (sx - w / 2) / zoom + camX,
		y: (sy - h / 2) / zoom + camY
	};
}
function pickBody(bodies, x, y, zoom) {
	for (let i = bodies.length - 1; i >= 0; i--) {
		const b = bodies[i];
		const reach = Math.max(b.radius, 22 / zoom);
		if (Math.hypot(b.x - x, b.y - y) <= reach) return b;
	}
	return null;
}
function limitVelocity(vx, vy) {
	const speed = Math.hypot(vx, vy);
	if (speed <= 1400) return {
		vx,
		vy,
		speed
	};
	const s = 1400 / speed;
	return {
		vx: vx * s,
		vy: vy * s,
		speed: 1400
	};
}
function Orrery() {
	const canvasRef = (0, import_react.useRef)(null);
	const simRef = (0, import_react.useRef)(null);
	if (simRef.current == null) simRef.current = createSim();
	const sim = simRef.current;
	const camRef = (0, import_react.useRef)({
		x: 0,
		y: 0,
		zoom: 1,
		needsFit: true
	});
	const sizeRef = (0, import_react.useRef)(null);
	const reduceRef = (0, import_react.useRef)(false);
	const [preset, setPreset] = (0, import_react.useState)("planet");
	const [timeScale, setTimeScale] = (0, import_react.useState)(1);
	const [trails, setTrails] = (0, import_react.useState)(true);
	const [mode, setMode] = (0, import_react.useState)("bounce");
	const [mute, setMute] = (0, import_react.useState)(false);
	const [paused, setPaused] = (0, import_react.useState)(false);
	const [tool, setTool] = (0, import_react.useState)("throw");
	const [scenario, setScenario] = (0, import_react.useState)("system");
	const [selectedId, setSelectedId] = (0, import_react.useState)(null);
	const [notice, setNotice] = (0, import_react.useState)(null);
	const [count, setCount] = (0, import_react.useState)(sim.bodies.length);
	const [stats, setStats] = (0, import_react.useState)(() => ({
		count: sim.bodies.length,
		time: formatSimTime(sim.time),
		speed: "—",
		label: "Speed"
	}));
	const ui = (0, import_react.useRef)({
		preset,
		timeScale,
		trails,
		mode,
		paused,
		tool,
		selectedId,
		count
	});
	ui.current = {
		preset,
		timeScale,
		trails,
		mode,
		paused,
		tool,
		selectedId,
		count
	};
	const readStats = (0, import_react.useCallback)(() => {
		const live = simRef.current;
		if (!live) return {
			count: 0,
			time: "0:00.0",
			speed: "—",
			label: "—"
		};
		const sel = live.bodies.find((b) => b.id === ui.current.selectedId);
		return {
			count: live.bodies.length,
			time: formatSimTime(live.time),
			speed: sel ? `${Math.round(Math.hypot(sel.vx, sel.vy))}/s` : "—",
			label: sel ? getPreset(sel.preset).label : "Speed"
		};
	}, []);
	const publishStats = (0, import_react.useCallback)((nextCount) => {
		const next = readStats();
		setStats((prev) => prev.count === next.count && prev.time === next.time && prev.speed === next.speed && prev.label === next.label ? prev : next);
		if (nextCount != null) setCount(nextCount);
		else setCount(next.count);
	}, [readStats]);
	const fitCamera = (0, import_react.useCallback)((snapUser) => {
		const live = simRef.current;
		const size = sizeRef.current;
		if (!live || !size) {
			camRef.current.needsFit = true;
			return;
		}
		const framed = frameOf(live.bodies, size.w, size.h);
		camRef.current.x = framed.x;
		camRef.current.y = framed.y;
		camRef.current.zoom = framed.zoom;
		camRef.current.needsFit = false;
		if (snapUser) camRef.current.needsFit = false;
	}, []);
	const applyScenario = (0, import_react.useCallback)((id) => {
		const live = simRef.current;
		if (!live) return;
		loadScenario(live, id);
		setScenario(id);
		setSelectedId(null);
		fitCamera(true);
		publishStats(live.bodies.length);
	}, [fitCamera, publishStats]);
	const zoomBy = (0, import_react.useCallback)((factor) => {
		const cam = camRef.current;
		const size = sizeRef.current;
		const previous = cam.zoom;
		cam.zoom = clamp(previous * factor, ZOOM_MIN, ZOOM_MAX);
		if (!size) return;
		const before = screenToWorld(size.w / 2, size.h / 2, cam.x, cam.y, previous, size.w, size.h);
		const after = screenToWorld(size.w / 2, size.h / 2, cam.x, cam.y, cam.zoom, size.w, size.h);
		cam.x += before.x - after.x;
		cam.y += before.y - after.y;
	}, []);
	const noticeTimer = (0, import_react.useRef)(0);
	const flash = (0, import_react.useCallback)((message) => {
		setNotice(message);
		window.clearTimeout(noticeTimer.current);
		noticeTimer.current = window.setTimeout(() => setNotice(null), 2200);
	}, []);
	(0, import_react.useEffect)(() => {
		try {
			const raw = localStorage.getItem(SETTINGS_KEY);
			if (!raw) return;
			const parsed = JSON.parse(raw);
			if (typeof parsed.timeScale === "number") setTimeScale(clamp(parsed.timeScale, .2, 4));
			if (typeof parsed.trails === "boolean") setTrails(parsed.trails);
			if (parsed.mode === "bounce" || parsed.mode === "merge") setMode(parsed.mode);
			if (typeof parsed.mute === "boolean") setMute(parsed.mute);
			if (parsed.preset && PRESET_LIST.some((p) => p.id === parsed.preset)) setPreset(parsed.preset);
		} catch {}
	}, []);
	(0, import_react.useEffect)(() => {
		try {
			localStorage.setItem(SETTINGS_KEY, JSON.stringify({
				version: 1,
				timeScale,
				trails,
				mode,
				mute,
				preset
			}));
		} catch {}
	}, [
		timeScale,
		trails,
		mode,
		mute,
		preset
	]);
	(0, import_react.useEffect)(() => {
		setMuted(mute);
	}, [mute]);
	(0, import_react.useEffect)(() => {
		const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
		const apply = () => {
			reduceRef.current = mq.matches;
		};
		apply();
		mq.addEventListener("change", apply);
		return () => mq.removeEventListener("change", apply);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!simRef.current) return;
		window.__orrery = {
			ready: true,
			count: () => simRef.current?.bodies.length ?? 0,
			time: () => simRef.current?.time ?? 0,
			energy: () => simRef.current ? energyOf(simRef.current) : 0,
			bodies: () => simRef.current?.bodies.map((b) => ({
				id: b.id,
				preset: b.preset,
				x: b.x,
				y: b.y,
				vx: b.vx,
				vy: b.vy,
				mass: b.mass,
				r: b.radius
			})) ?? [],
			load: (id) => applyScenario(id),
			fling: (presetId, x, y, vx, vy) => {
				const current = simRef.current;
				if (!current) return null;
				const born = addBody(current, presetId, x, y, vx, vy);
				setScenario("");
				setSelectedId(born?.id ?? null);
				publishStats(current.bodies.length);
				return born?.id ?? null;
			}
		};
		return () => {
			delete window.__orrery;
		};
	}, [applyScenario, publishStats]);
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		const live = simRef.current;
		if (!canvas || !live) return;
		const stars = createStarfield(150, 11);
		const sparks = [];
		const sparkPool = [];
		let drag = null;
		let pinch = null;
		const pointers = /* @__PURE__ */ new Map();
		let trauma = 0;
		let raf = 0;
		let last = performance.now();
		let statAcc = 0;
		const resize = () => {
			const w = canvas.clientWidth;
			const h = canvas.clientHeight;
			sizeRef.current = {
				w,
				h
			};
			const dpr = Math.min(window.devicePixelRatio || 1, 2);
			const bw = Math.max(1, Math.round(w * dpr));
			const bh = Math.max(1, Math.round(h * dpr));
			if (canvas.width !== bw || canvas.height !== bh) {
				canvas.width = bw;
				canvas.height = bh;
			}
			if (camRef.current.needsFit && w > 0 && h > 0) {
				const framed = frameOf(live.bodies, w, h);
				camRef.current.x = framed.x;
				camRef.current.y = framed.y;
				camRef.current.zoom = framed.zoom;
				camRef.current.needsFit = false;
			}
			return dpr;
		};
		const localOf = (clientX, clientY) => {
			const rect = canvas.getBoundingClientRect();
			return {
				x: clientX - rect.left,
				y: clientY - rect.top,
				w: rect.width,
				h: rect.height
			};
		};
		const worldOf = (clientX, clientY) => {
			const local = localOf(clientX, clientY);
			const cam = camRef.current;
			return {
				...screenToWorld(local.x, local.y, cam.x, cam.y, cam.zoom, local.w, local.h),
				local
			};
		};
		const burst = (x, y, speed) => {
			const n = Math.min(16, 4 + Math.floor(speed / 90));
			for (let i = 0; i < n; i++) {
				const a = Math.random() * Math.PI * 2;
				const s = 18 + Math.random() * (30 + speed * .12);
				const life = .22 + Math.random() * .28;
				sparkPool.push({
					x,
					y,
					vx: Math.cos(a) * s,
					vy: Math.sin(a) * s,
					life,
					max: life,
					r: 1 + Math.random() * 1.4
				});
			}
			if (sparkPool.length > 180) sparkPool.splice(0, sparkPool.length - 180);
		};
		const onDown = (e) => {
			if (e.button !== 0 && e.button !== 1 && e.button !== 2) return;
			unlockAudio();
			canvas.setPointerCapture(e.pointerId);
			pointers.set(e.pointerId, {
				x: e.clientX,
				y: e.clientY
			});
			if (pointers.size >= 2) {
				drag = null;
				const pts = [...pointers.values()];
				pinch = {
					dist0: Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y) || 1,
					zoom0: camRef.current.zoom
				};
				return;
			}
			if (e.button === 1 || e.button === 2 || ui.current.tool === "pan") {
				drag = {
					type: "pan",
					lastX: e.clientX,
					lastY: e.clientY
				};
				return;
			}
			const world = worldOf(e.clientX, e.clientY);
			const hit = pickBody(live.bodies, world.x, world.y, camRef.current.zoom);
			if (hit) {
				setSelectedId(hit.id);
				drag = {
					type: "body",
					id: hit.id,
					x0: hit.x,
					y0: hit.y,
					x: world.x,
					y: world.y,
					sx0: e.clientX,
					sy0: e.clientY,
					moved: false
				};
			} else {
				setSelectedId(null);
				drag = {
					type: "new",
					id: null,
					x0: world.x,
					y0: world.y,
					x: world.x,
					y: world.y,
					sx0: e.clientX,
					sy0: e.clientY,
					moved: false
				};
			}
		};
		const updatePinch = () => {
			if (!pinch || pointers.size < 2) return;
			const pts = [...pointers.values()];
			const dist = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y) || 1;
			const midX = (pts[0].x + pts[1].x) / 2;
			const midY = (pts[0].y + pts[1].y) / 2;
			const local = localOf(midX, midY);
			const cam = camRef.current;
			const before = screenToWorld(local.x, local.y, cam.x, cam.y, cam.zoom, local.w, local.h);
			cam.zoom = clamp(pinch.zoom0 * (dist / pinch.dist0), ZOOM_MIN, ZOOM_MAX);
			const after = screenToWorld(local.x, local.y, cam.x, cam.y, cam.zoom, local.w, local.h);
			cam.x += before.x - after.x;
			cam.y += before.y - after.y;
		};
		const onMove = (e) => {
			if (!pointers.has(e.pointerId)) return;
			pointers.set(e.pointerId, {
				x: e.clientX,
				y: e.clientY
			});
			if (pointers.size >= 2) {
				updatePinch();
				return;
			}
			if (!drag) return;
			if (drag.type === "pan") {
				const cam = camRef.current;
				cam.x -= (e.clientX - drag.lastX) / cam.zoom;
				cam.y -= (e.clientY - drag.lastY) / cam.zoom;
				drag.lastX = e.clientX;
				drag.lastY = e.clientY;
				return;
			}
			const world = worldOf(e.clientX, e.clientY);
			drag.x = world.x;
			drag.y = world.y;
			if (Math.hypot(e.clientX - drag.sx0, e.clientY - drag.sy0) > 8) drag.moved = true;
		};
		const onUp = (e) => {
			pointers.delete(e.pointerId);
			if (pointers.size < 2) pinch = null;
			if (pointers.size >= 1) {
				drag = null;
				return;
			}
			const finished = drag;
			drag = null;
			if (!finished || finished.type === "pan") return;
			if (finished.type === "new") {
				let vx = 0;
				let vy = 0;
				if (finished.moved) {
					const limited = limitVelocity((finished.x - finished.x0) / 1, (finished.y - finished.y0) / 1);
					vx = limited.vx;
					vy = limited.vy;
				}
				const born = addBody(live, ui.current.preset, finished.x0, finished.y0, vx, vy);
				if (!born) {
					flash(`The field is full — 40 worlds is the limit.`);
					return;
				}
				setSelectedId(born.id);
				setScenario("");
				publishStats(live.bodies.length);
				if (finished.moved) {
					playFling(Math.hypot(vx, vy));
					if (!reduceRef.current) trauma = Math.min(1, trauma + .12);
				}
				return;
			}
			if (!finished.moved || finished.id == null) return;
			const body = live.bodies.find((b) => b.id === finished.id);
			if (!body) return;
			const limited = limitVelocity((finished.x - body.x) / 1, (finished.y - body.y) / 1);
			setBodyVelocity(live, body.id, limited.vx, limited.vy);
			playFling(limited.speed);
			if (!reduceRef.current) trauma = Math.min(1, trauma + .1);
			publishStats();
		};
		const onWheel = (e) => {
			e.preventDefault();
			const local = localOf(e.clientX, e.clientY);
			const cam = camRef.current;
			const before = screenToWorld(local.x, local.y, cam.x, cam.y, cam.zoom, local.w, local.h);
			cam.zoom = clamp(cam.zoom * Math.exp(-e.deltaY * .00115), ZOOM_MIN, ZOOM_MAX);
			const after = screenToWorld(local.x, local.y, cam.x, cam.y, cam.zoom, local.w, local.h);
			cam.x += before.x - after.x;
			cam.y += before.y - after.y;
		};
		const onKey = (e) => {
			const target = e.target;
			const tag = target?.tagName;
			if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT" || target?.isContentEditable) return;
			if (e.code === "Space") {
				e.preventDefault();
				setPaused((v) => !v);
				return;
			}
			if (e.code === "Backspace" || e.code === "Delete") {
				const id = ui.current.selectedId;
				if (id == null || !simRef.current) return;
				e.preventDefault();
				removeBody(simRef.current, id);
				setSelectedId(null);
				setScenario("");
				publishStats();
				return;
			}
			if (e.code.startsWith("Digit")) {
				const index = Number(e.code.slice(5)) - 1;
				if (index >= 0 && index < PRESET_LIST.length) setPreset(PRESET_LIST[index].id);
				return;
			}
			if (e.code === "BracketLeft") setTimeScale((v) => clamp(Math.round((v - .2) * 10) / 10, .2, 4));
			if (e.code === "BracketRight") setTimeScale((v) => clamp(Math.round((v + .2) * 10) / 10, .2, 4));
			if (e.code === "KeyT") setTrails((v) => !v);
			if (e.code === "KeyH") setTool((v) => v === "pan" ? "throw" : "pan");
			if (e.code === "KeyM") setMute((v) => !v);
			if (e.code === "KeyF") {
				const size = sizeRef.current;
				const current = simRef.current;
				if (!size || !current) return;
				const framed = frameOf(current.bodies, size.w, size.h);
				camRef.current.x = framed.x;
				camRef.current.y = framed.y;
				camRef.current.zoom = framed.zoom;
			}
			if (e.code === "Minus" || e.code === "NumpadSubtract") zoomBy(1 / 1.15);
			if (e.code === "Equal" || e.code === "NumpadAdd") zoomBy(1.15);
		};
		const frame = (now) => {
			const dt = Math.min(.05, (now - last) / 1e3);
			last = now;
			const dpr = resize();
			const size = sizeRef.current;
			const ctx = canvas.getContext("2d");
			if (!size || !ctx || size.w < 2 || size.h < 2) {
				raf = requestAnimationFrame(frame);
				return;
			}
			const holding = drag != null && drag.type !== "pan";
			const running = !ui.current.paused && !holding && !document.hidden;
			live.mode = ui.current.mode;
			live.trails = ui.current.trails;
			if (running) advanceSim(live, dt, ui.current.timeScale);
			for (const event of live.events) {
				burst(event.x, event.y, event.speed);
				if (!reduceRef.current) trauma = Math.min(1, trauma + Math.min(.5, event.speed / 900));
				if (event.type === "merge") playMerge();
				else playHit(event.speed);
			}
			live.events.length = 0;
			trauma = Math.max(0, trauma - dt * 1.7);
			for (let i = sparkPool.length - 1; i >= 0; i--) {
				const spark = sparkPool[i];
				spark.life -= dt;
				if (spark.life <= 0) {
					sparkPool.splice(i, 1);
					continue;
				}
				spark.x += spark.vx * dt;
				spark.y += spark.vy * dt;
			}
			sparks.length = 0;
			for (const spark of sparkPool) sparks.push(spark);
			if (ui.current.selectedId != null && !live.bodies.some((b) => b.id === ui.current.selectedId)) {
				ui.current.selectedId = null;
				setSelectedId(null);
			}
			let path = null;
			let dragDraw = null;
			const active = drag;
			if (active && active.type !== "pan") {
				const presetNow = getPreset(ui.current.preset);
				if (active.type === "new") {
					const limited = active.moved ? limitVelocity((active.x - active.x0) / 1, (active.y - active.y0) / 1) : {
						vx: 0,
						vy: 0,
						speed: 0
					};
					dragDraw = {
						kind: "new",
						x0: active.x0,
						y0: active.y0,
						x1: active.x,
						y1: active.y,
						color: presetNow.color,
						core: presetNow.core,
						radius: radiusFromMass(presetNow.mass, presetNow.kind),
						moved: active.moved,
						speed: limited.speed
					};
					if (active.moved) path = forecast(live, {
						id: null,
						x: active.x0,
						y: active.y0,
						vx: limited.vx,
						vy: limited.vy,
						preset: ui.current.preset
					});
				} else if (active.id != null) {
					const body = live.bodies.find((b) => b.id === active.id);
					if (body) {
						const limited = active.moved ? limitVelocity((active.x - body.x) / 1, (active.y - body.y) / 1) : {
							vx: body.vx,
							vy: body.vy,
							speed: Math.hypot(body.vx, body.vy)
						};
						dragDraw = {
							kind: "body",
							x0: body.x,
							y0: body.y,
							x1: active.moved ? active.x : body.x + body.vx * 1,
							y1: active.moved ? active.y : body.y + body.vy * 1,
							color: body.color,
							core: body.core,
							radius: body.radius,
							moved: active.moved,
							speed: limited.speed
						};
						if (active.moved) path = forecast(live, {
							id: body.id,
							x: body.x,
							y: body.y,
							vx: limited.vx,
							vy: limited.vy,
							preset: body.preset
						});
					}
				}
			}
			const shake = reduceRef.current ? 0 : trauma * trauma;
			const cam = camRef.current;
			renderScene(ctx, live, {
				w: size.w,
				h: size.h,
				camX: cam.x,
				camY: cam.y,
				zoom: cam.zoom,
				shakeX: shake * 14 * Math.sin(now * .061),
				shakeY: shake * 10 * Math.cos(now * .047),
				reduce: reduceRef.current,
				trails: ui.current.trails
			}, {
				stars,
				path,
				drag: dragDraw,
				selectedId: ui.current.selectedId,
				sparks,
				dpr
			});
			statAcc += dt;
			if (statAcc > .2) {
				statAcc = 0;
				const next = readStats();
				setStats((prev) => prev.count === next.count && prev.time === next.time && prev.speed === next.speed && prev.label === next.label ? prev : next);
				setCount((prev) => prev === next.count ? prev : next.count);
			}
			raf = requestAnimationFrame(frame);
		};
		resize();
		raf = requestAnimationFrame(frame);
		canvas.addEventListener("pointerdown", onDown);
		canvas.addEventListener("pointermove", onMove);
		canvas.addEventListener("pointerup", onUp);
		canvas.addEventListener("pointercancel", onUp);
		canvas.addEventListener("wheel", onWheel, { passive: false });
		const onContext = (e) => e.preventDefault();
		canvas.addEventListener("contextmenu", onContext);
		window.addEventListener("keydown", onKey);
		const ro = new ResizeObserver(() => resize());
		ro.observe(canvas);
		return () => {
			cancelAnimationFrame(raf);
			canvas.removeEventListener("pointerdown", onDown);
			canvas.removeEventListener("pointermove", onMove);
			canvas.removeEventListener("pointerup", onUp);
			canvas.removeEventListener("pointercancel", onUp);
			canvas.removeEventListener("wheel", onWheel);
			canvas.removeEventListener("contextmenu", onContext);
			window.removeEventListener("keydown", onKey);
			ro.disconnect();
		};
	}, [
		flash,
		publishStats,
		readStats,
		zoomBy
	]);
	const scaleLabel = timeScale < 1 ? `${timeScale.toFixed(2)}×` : `${timeScale.toFixed(timeScale < 10 ? 1 : 0)}×`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "relative h-dvh w-full overflow-hidden bg-bg text-fg select-none",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
			ref: canvasRef,
			className: clsx("absolute inset-0 h-full w-full touch-none", tool === "pan" ? "cursor-grab" : "cursor-crosshair"),
			"aria-label": "Orbital sandbox. Drag to fling a world."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pointer-events-none absolute inset-0 flex flex-col justify-between gap-3 p-3 sm:p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "pointer-events-none flex flex-col gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium tracking-wide text-muted",
								children: "Orbital sandbox"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "mt-1 font-display text-3xl leading-none tracking-tight text-fg sm:text-4xl",
								children: "Orrery"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start gap-3 sm:gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
								className: "flex gap-3 sm:gap-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-xs text-muted",
										children: "Bodies"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "font-mono text-sm tabular-nums text-fg",
										children: stats.count
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-xs text-muted",
										children: paused ? "Paused" : "Time"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "font-mono text-sm tabular-nums text-fg",
										children: stats.time
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-xs text-muted",
										children: stats.label
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "font-mono text-sm tabular-nums text-fg",
										children: stats.speed
									})] })
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: clsx(iconBtn, "pointer-events-auto"),
								"aria-label": mute ? "Unmute" : "Mute",
								"aria-pressed": mute,
								onClick: () => {
									unlockAudio();
									setMute((v) => !v);
								},
								children: mute ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, {
									className: "size-4",
									"aria-hidden": true
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, {
									className: "size-4",
									"aria-hidden": true
								})
							})]
						})]
					}), notice ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						role: "status",
						className: "w-fit rounded-md border border-fg/15 bg-elevated px-3 py-2 text-sm text-fg",
						children: notice
					}) : null]
				}),
				count === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pointer-events-none flex flex-1 items-center justify-center px-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "max-w-sm rounded-xl border border-fg/15 bg-elevated p-4 text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm leading-relaxed text-fg",
							children: "Drag to fling a world into the field."
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-xs leading-relaxed text-muted",
							children: "The arrow is one second of motion, before gravity bends it."
						})]
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "flex-1" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
					className: "pointer-events-auto mx-auto flex w-full max-w-3xl flex-col gap-2 rounded-xl border border-fg/15 bg-elevated p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "w-12 shrink-0 text-xs text-muted",
								children: "Mass"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "chip-row flex min-w-0 flex-1 gap-2 overflow-x-auto",
								role: "radiogroup",
								"aria-label": "Mass",
								children: PRESET_LIST.map((item, index) => {
									const on = preset === item.id;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										role: "radio",
										"aria-checked": on,
										className: clsx("h-11 shrink-0 rounded-full px-3 text-sm font-medium transition-colors duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-fg/40", on ? "bg-fg text-bg" : "border border-fg/15 bg-bg text-fg hover:bg-subtle"),
										onClick: () => setPreset(item.id),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "sr-only",
											children: [index + 1, " "]
										}), item.label]
									}, item.id);
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "w-12 shrink-0 text-xs text-muted",
								children: "Scene"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "chip-row flex min-w-0 flex-1 gap-2 overflow-x-auto",
								role: "radiogroup",
								"aria-label": "Scene",
								children: SCENARIOS.map((item) => {
									const on = scenario === item.id;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										role: "radio",
										"aria-checked": on,
										className: clsx("h-11 shrink-0 rounded-full px-3 text-sm font-medium transition-colors duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-fg/40", on ? "bg-fg text-bg" : "border border-fg/15 bg-bg text-fg hover:bg-subtle"),
										onClick: () => applyScenario(item.id),
										children: item.label
									}, item.id);
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex min-w-0 flex-1 items-center gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "w-12 shrink-0 text-xs text-muted",
										children: "Time"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: "time-slider min-w-0 flex-1",
										type: "range",
										min: .2,
										max: 4,
										step: .1,
										value: timeScale,
										"aria-label": "Time scale",
										onChange: (e) => setTimeScale(Number(e.target.value))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "w-12 shrink-0 text-right font-mono text-sm tabular-nums text-fg",
										children: scaleLabel
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: iconBtn,
								"aria-label": paused ? "Play" : "Pause",
								onClick: () => setPaused((v) => !v),
								children: paused ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
									className: "size-4",
									"aria-hidden": true
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, {
									className: "size-4",
									"aria-hidden": true
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: clsx(textBtn, trails && "bg-subtle"),
									"aria-pressed": trails,
									onClick: () => setTrails((v) => !v),
									children: "Trails"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex h-11 items-center gap-1 rounded-md border border-fg/15 bg-bg p-1",
									role: "radiogroup",
									"aria-label": "Collision",
									children: ["bounce", "merge"].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										role: "radio",
										"aria-checked": mode === item,
										className: clsx("h-full rounded-sm px-3 text-sm font-medium capitalize transition-colors duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-fg/40", mode === item ? "bg-fg text-bg" : "text-fg hover:bg-subtle"),
										onClick: () => setMode(item),
										children: item
									}, item))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: clsx(textBtn, tool === "pan" && "bg-fg text-bg hover:bg-fg"),
									"aria-pressed": tool === "pan",
									onClick: () => setTool((v) => v === "pan" ? "throw" : "pan"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hand, {
										className: "mr-1.5 size-4",
										"aria-hidden": true
									}), "Pan"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: iconBtn,
									"aria-label": "Zoom out",
									onClick: () => zoomBy(1 / 1.15),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, {
										className: "size-4",
										"aria-hidden": true
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: iconBtn,
									"aria-label": "Zoom in",
									onClick: () => zoomBy(1.15),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
										className: "size-4",
										"aria-hidden": true
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: iconBtn,
									"aria-label": "Frame all worlds",
									onClick: () => fitCamera(true),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LocateFixed, {
										className: "size-4",
										"aria-hidden": true
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: textBtn,
									disabled: selectedId == null,
									onClick: () => {
										const current = simRef.current;
										if (!current || selectedId == null) return;
										removeBody(current, selectedId);
										setSelectedId(null);
										setScenario("");
										publishStats();
									},
									children: "Remove"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: textBtn,
									onClick: () => {
										const current = simRef.current;
										if (!current) return;
										clearBodies(current);
										setScenario("");
										setSelectedId(null);
										publishStats(0);
									},
									children: "Clear"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs leading-relaxed text-faint",
							children: tool === "pan" ? "Drag to move the view. Scroll or pinch to zoom." : "Drag empty space to add a world. Drag a world to fling it. The arrow is one second of flight."
						})
					]
				})
			]
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Orrery, {});
}
//#endregion
export { Home as component };
