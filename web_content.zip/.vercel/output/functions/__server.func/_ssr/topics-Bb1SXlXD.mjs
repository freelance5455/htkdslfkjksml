import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { l as require_react_dom, v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as require_jsx_runtime, t as useInfiniteQuery } from "../_libs/react+tanstack__react-query.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as number, n as array, o as object, r as boolean, s as string, t as _enum } from "../_libs/zod.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { a as cn, i as Button, o as formatCount, r as ErrorBoundary } from "./router-D8sFVTug.mjs";
import { a as ThumbsUp, c as Play, d as Heart, i as Users, l as MessageCircle, m as Check, n as ZoomOut, o as Search, r as X, s as Rss, t as ZoomIn, u as LoaderCircle } from "../_libs/lucide-react.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/topics-Bb1SXlXD.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var import_react_dom = require_react_dom();
var TABS = [
	{
		id: "community",
		label: "Community",
		icon: Rss
	},
	{
		id: "following",
		label: "Following",
		icon: Users
	},
	{
		id: "search",
		label: "Search channels",
		icon: Search
	}
];
function DesktopNav({ tab, onTab }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
		className: "hidden w-56 shrink-0 flex-col gap-1 border-r border-border px-3 py-5 lg:flex",
		children: TABS.map((item) => {
			const Icon = item.icon;
			const active = tab === item.id;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => onTab(item.id),
				className: cn("flex h-11 items-center gap-3 rounded-xl px-3 text-sm font-medium transition-[background-color,color] duration-[var(--motion-quick)]", active ? "bg-secondary text-foreground" : "text-muted-foreground hover:bg-secondary/70 hover:text-foreground"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), item.label]
			}, item.id);
		})
	});
}
function BottomNav({ tab, onTab }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		className: "fixed inset-x-0 bottom-0 z-40 border-t border-border bg-background/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-sm lg:hidden",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "grid grid-cols-3",
			children: TABS.map((item) => {
				const Icon = item.icon;
				const active = tab === item.id;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onTab(item.id),
					className: cn("flex h-14 w-full flex-col items-center justify-center gap-1 px-1 text-[10px] font-medium leading-tight", active ? "text-foreground" : "text-muted-foreground"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" }), item.label]
				}) }, item.id);
			})
		})
	});
}
function PageFrame({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto flex h-dvh min-h-0 w-full max-w-6xl overflow-hidden",
		children
	});
}
function ChipBar({ items, value, onChange, ariaLabel }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		role: "tablist",
		"aria-label": ariaLabel,
		className: "flex gap-2 overflow-x-auto px-4 pb-3 pt-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden",
		children: items.map((item) => {
			const active = item.id === value;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				role: "tab",
				"aria-selected": active,
				onClick: () => onChange(item.id),
				className: cn("h-9 shrink-0 rounded-full px-3.5 text-xs font-medium transition-[background-color,color] duration-[var(--motion-quick)]", active ? "bg-accent text-accent-foreground" : "bg-secondary text-muted-foreground hover:text-foreground"),
				children: item.label
			}, item.id);
		})
	});
}
var badgeVariants = cva("inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium tracking-wide", {
	variants: { variant: {
		default: "border-transparent bg-secondary text-muted-foreground",
		accent: "border-transparent bg-accent text-accent-foreground",
		outline: "border-border text-muted-foreground"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
function useSentinel(ref, enabled, loadMore, rootMargin = "720px") {
	(0, import_react.useEffect)(() => {
		const node = ref.current;
		if (!node || !enabled) return;
		const io = new IntersectionObserver((entries) => {
			if (entries.some((e) => e.isIntersecting)) loadMore();
		}, { rootMargin });
		io.observe(node);
		return () => io.disconnect();
	}, [
		enabled,
		loadMore,
		ref,
		rootMargin
	]);
}
var POST_SORTS = [
	{
		id: "newest",
		label: "Newest to oldest"
	},
	{
		id: "oldest",
		label: "Oldest to newest"
	},
	{
		id: "popular",
		label: "Most popular to least popular"
	},
	{
		id: "unpopular",
		label: "Least popular to most popular"
	}
];
var POST_TYPES = [
	{
		id: "all",
		label: "All"
	},
	{
		id: "images",
		label: "Images"
	},
	{
		id: "videos",
		label: "Videos"
	},
	{
		id: "text",
		label: "Text"
	},
	{
		id: "polls",
		label: "Polls"
	}
];
function sortPosts(posts, sort) {
	const list = [...posts];
	if (sort === "oldest") return list.sort((a, b) => a.publishedAt - b.publishedAt);
	if (sort === "popular") return list.sort((a, b) => b.likeCount - a.likeCount || b.publishedAt - a.publishedAt);
	if (sort === "unpopular") return list.sort((a, b) => a.likeCount - b.likeCount || a.publishedAt - b.publishedAt);
	return list.sort((a, b) => b.publishedAt - a.publishedAt);
}
function sortComments(comments, sort) {
	const list = [...comments];
	if (sort === "oldest") return list.sort((a, b) => a.publishedAt - b.publishedAt);
	if (sort === "popular") return list.sort((a, b) => b.likeCount - a.likeCount || b.publishedAt - a.publishedAt);
	if (sort === "unpopular") return list.sort((a, b) => a.likeCount - b.likeCount || a.publishedAt - b.publishedAt);
	return list.sort((a, b) => b.publishedAt - a.publishedAt);
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var optionalString = string().optional().nullable();
var searchChannelsFn = createServerFn({ method: "POST" }).validator(object({
	query: string(),
	continuation: optionalString
})).handler(createSsrRpc("a290d10df71b420f8f7349b8755415d24d8a337df2428e267ca60b04ec700f5e"));
var getChannelFn = createServerFn({ method: "POST" }).validator(object({ id: string().min(1) })).handler(createSsrRpc("90e37794b753508efce0c276cbabd9deed7a76d19942eea954c9452679281e1e"));
var getChannelPostsFn = createServerFn({ method: "POST" }).validator(object({
	channelId: string().min(1),
	continuation: optionalString
})).handler(createSsrRpc("ac3f239e32e817830b127a58a6df7910bc5381003ef6e9879e7d73d1873bd972"));
var loadFeedPageFn = createServerFn({ method: "POST" }).validator(object({
	topic: string().default("all"),
	queryIndex: number().int().min(0).default(0),
	searchContinuation: optionalString,
	extraChannelIds: array(string()).max(500).default([]),
	channelCursors: array(object({
		id: string(),
		continuation: optionalString
	})).max(500).default([]),
	discover: boolean().default(true)
})).handler(createSsrRpc("459816b48cc9688e7062e7cb7d9ffb9f911e46a5c5be9635c49ac69bace32ff8"));
var getPostCommentsFn = createServerFn({ method: "POST" }).validator(object({
	postId: string().min(1),
	channelId: optionalString,
	commentParams: optionalString,
	continuation: optionalString,
	includeHidden: boolean().optional(),
	sort: _enum(["newest", "top"]).optional()
})).handler(createSsrRpc("04e056aac362061e2d1879651b22cb9166afd939180493363ca86ad0a9ad88d2"));
function AuthorLink({ comment }) {
	const inner = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: comment.authorThumbnail ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: comment.authorThumbnail,
		alt: "",
		loading: "lazy",
		decoding: "async",
		className: "size-8 shrink-0 rounded-full object-cover"
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "flex size-8 shrink-0 items-center justify-center rounded-full bg-muted text-xs",
		children: comment.author.slice(0, 1) || "?"
	}) });
	if (!comment.authorChannelId) return inner;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/channel/$channelId",
		params: { channelId: comment.authorChannelId },
		className: "shrink-0",
		"aria-label": comment.author,
		children: inner
	});
}
function CommentRow({ comment, post, sort }) {
	const [openReplies, setOpenReplies] = (0, import_react.useState)(false);
	const name = comment.authorChannelId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/channel/$channelId",
		params: { channelId: comment.authorChannelId },
		className: "truncate text-xs font-medium text-foreground",
		children: comment.author
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "truncate text-xs font-medium",
		children: comment.author
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "flex gap-2.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthorLink, { comment }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0 flex-1",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-1.5",
					children: [
						name,
						comment.isCreator ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: "Creator" }) : null,
						comment.isVerified ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: "outline",
							children: "Verified"
						}) : null,
						comment.hidden ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: "outline",
							children: "Hidden"
						}) : null,
						comment.publishedText ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[11px] text-muted-foreground",
							children: comment.publishedText
						}) : null
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 whitespace-pre-wrap break-words text-sm leading-relaxed",
					children: comment.text
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-1.5 flex flex-wrap items-center gap-3 text-xs text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-1 tabular-nums",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThumbsUp, { className: "size-3.5" }), comment.likeText || formatCount(comment.likeCount)]
					}), comment.hearted ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-1 text-primary",
						title: comment.heartedBy ? `Hearted by ${comment.heartedBy}` : "Hearted by the creator",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "size-3.5 fill-current" }), comment.heartedBy ? `Hearted by ${comment.heartedBy}` : "Creator heart"]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "size-3.5" }), "No heart"]
					})]
				}),
				comment.repliesContinuation || comment.replyCount > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "mt-1.5 min-h-11 text-xs font-medium text-muted-foreground hover:text-foreground",
					onClick: () => setOpenReplies((v) => !v),
					children: openReplies ? "Hide replies" : `Show ${comment.replyCount || ""} replies`.replace("  ", " ")
				}) : null,
				openReplies && comment.repliesContinuation ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2 border-l border-border pl-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommentList, {
						post,
						continuation: comment.repliesContinuation,
						nested: true,
						sort
					})
				}) : null
			]
		})]
	});
}
var MemoComment = (0, import_react.memo)(CommentRow);
function CommentList({ post, continuation, nested = false, sort }) {
	const sentinel = (0, import_react.useRef)(null);
	const apiSort = sort === "popular" || sort === "unpopular" ? "top" : "newest";
	const { data, isLoading, isError, refetch, hasNextPage, isFetchingNextPage, isFetching, fetchNextPage } = useInfiniteQuery({
		queryKey: [
			"comments",
			post.id,
			continuation ?? "root",
			apiSort
		],
		initialPageParam: continuation ?? null,
		queryFn: async ({ pageParam }) => getPostCommentsFn({ data: {
			postId: post.id,
			channelId: post.channelId,
			commentParams: post.commentParams,
			continuation: pageParam,
			includeHidden: true,
			sort: pageParam ? void 0 : apiSort
		} }),
		getNextPageParam: (last, pages) => {
			const token = last.continuation ?? last.hiddenContinuation ?? void 0;
			if (!token) return void 0;
			if (pages.some((p, i) => i < pages.length - 1 && (p.continuation === token || p.hiddenContinuation === token))) return void 0;
			return token;
		},
		retry: 1
	});
	const comments = (0, import_react.useMemo)(() => {
		const seen = /* @__PURE__ */ new Set();
		const list = [];
		for (const page of data?.pages ?? []) for (const c of page.comments) {
			if (seen.has(c.id)) continue;
			seen.add(c.id);
			list.push(c);
		}
		return sortComments(list, sort);
	}, [data, sort]);
	const totalText = data?.pages[0]?.totalText ?? "";
	const loadMore = (0, import_react.useCallback)(() => {
		if (hasNextPage && !isFetchingNextPage && !isFetching) fetchNextPage();
	}, [
		fetchNextPage,
		hasNextPage,
		isFetching,
		isFetchingNextPage
	]);
	useSentinel(sentinel, Boolean(hasNextPage && !isFetchingNextPage), loadMore, "360px");
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2 py-4 text-sm text-muted-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }), "Loading comments"]
	});
	if (isError) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "py-3 text-sm text-muted-foreground",
		children: [
			"Couldn’t load comments.",
			" ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "underline",
				onClick: () => refetch(),
				children: "Retry"
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: nested ? "space-y-3" : "space-y-4",
		children: [
			!nested && totalText ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium text-muted-foreground",
				children: totalText
			}) : null,
			comments.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "py-3 text-sm text-muted-foreground",
				children: "No public comments yet."
			}) : comments.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MemoComment, {
				comment: c,
				post,
				sort
			}, c.id)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: sentinel,
				className: "h-6"
			}),
			isFetchingNextPage ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-center py-2 text-muted-foreground",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" })
			}) : null
		]
	});
}
function CommentThread({ post }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [sort, setSort] = (0, import_react.useState)("newest");
	const count = post.replyText || formatCount(post.replyCount);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-3 border-t border-border pt-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			type: "button",
			variant: "ghost",
			size: "sm",
			className: "h-11 w-full justify-between px-1",
			onClick: () => setOpen((v) => !v),
			"aria-expanded": open,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Comments · ", count] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-muted-foreground",
				children: open ? "Hide" : "Show all"
			})]
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "-mx-4 mt-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChipBar, {
				ariaLabel: "Comment sort",
				items: POST_SORTS,
				value: sort,
				onChange: setSort
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommentList, {
					post,
					sort
				})
			})]
		}) : null]
	});
}
var MIN = .15;
var MAX = 80;
function MediaViewer({ src, onClose }) {
	const [scale, setScale] = (0, import_react.useState)(1);
	const [tx, setTx] = (0, import_react.useState)(0);
	const [ty, setTy] = (0, import_react.useState)(0);
	const dragging = (0, import_react.useRef)(false);
	const last = (0, import_react.useRef)({
		x: 0,
		y: 0
	});
	const pointers = (0, import_react.useRef)(/* @__PURE__ */ new Map());
	const pinch = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const prev = document.body.style.overflow;
		document.body.style.overflow = "hidden";
		const onKey = (e) => {
			if (e.key === "Escape") onClose();
		};
		window.addEventListener("keydown", onKey);
		return () => {
			document.body.style.overflow = prev;
			window.removeEventListener("keydown", onKey);
		};
	}, [onClose]);
	const clampScale = (n) => Math.min(MAX, Math.max(MIN, n));
	const onWheel = (0, import_react.useCallback)((e) => {
		e.preventDefault();
		const delta = e.deltaY > 0 ? .9 : 1.12;
		setScale((s) => clampScale(s * delta));
	}, []);
	const onPointerDown = (e) => {
		e.currentTarget.setPointerCapture(e.pointerId);
		pointers.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		});
		if (pointers.current.size === 1) {
			dragging.current = true;
			last.current = {
				x: e.clientX,
				y: e.clientY
			};
		} else if (pointers.current.size === 2) {
			const pts = [...pointers.current.values()];
			const dx = pts[0].x - pts[1].x;
			const dy = pts[0].y - pts[1].y;
			pinch.current = {
				dist: Math.hypot(dx, dy) || 1,
				scale
			};
		}
	};
	const onPointerMove = (e) => {
		if (!pointers.current.has(e.pointerId)) return;
		pointers.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		});
		if (pointers.current.size >= 2 && pinch.current) {
			const pts = [...pointers.current.values()];
			const dx = pts[0].x - pts[1].x;
			const dy = pts[0].y - pts[1].y;
			const dist = Math.hypot(dx, dy) || 1;
			setScale(clampScale(pinch.current.scale * (dist / pinch.current.dist)));
			return;
		}
		if (!dragging.current) return;
		const dx = e.clientX - last.current.x;
		const dy = e.clientY - last.current.y;
		last.current = {
			x: e.clientX,
			y: e.clientY
		};
		setTx((v) => v + dx);
		setTy((v) => v + dy);
	};
	const onPointerUp = (e) => {
		pointers.current.delete(e.pointerId);
		if (pointers.current.size < 2) pinch.current = null;
		if (pointers.current.size === 0) dragging.current = false;
	};
	const node = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-[80] flex touch-none flex-col bg-background",
		style: { background: "#000000" },
		onWheel,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pointer-events-auto absolute inset-x-0 top-0 z-10 flex items-center justify-between px-3 pt-[max(0.75rem,env(safe-area-inset-top))]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onClose,
				className: "flex size-11 items-center justify-center rounded-full bg-secondary text-foreground",
				"aria-label": "Close",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "flex size-11 items-center justify-center rounded-full bg-secondary text-foreground",
					onClick: () => setScale((s) => clampScale(s / 1.4)),
					"aria-label": "Zoom out",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZoomOut, { className: "size-5" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "flex size-11 items-center justify-center rounded-full bg-secondary text-foreground",
					onClick: () => setScale((s) => clampScale(s * 1.4)),
					"aria-label": "Zoom in",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZoomIn, { className: "size-5" })
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex min-h-0 flex-1 items-center justify-center overflow-hidden",
			onPointerDown,
			onPointerMove,
			onPointerUp,
			onPointerCancel: onPointerUp,
			onDoubleClick: () => {
				setScale((s) => s > 1.4 ? 1 : 3);
				if (scale > 1.4) {
					setTx(0);
					setTy(0);
				}
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src,
				alt: "",
				draggable: false,
				className: "max-h-none max-w-none select-none object-contain",
				style: {
					transform: `translate3d(${tx}px, ${ty}px, 0) scale(${scale})`,
					transformOrigin: "center center",
					willChange: "transform"
				}
			})
		})]
	});
	if (typeof document === "undefined") return null;
	return (0, import_react_dom.createPortal)(node, document.body);
}
var useSubscriptions = create()(persist((set, get) => ({
	channels: [],
	isSubscribed: (id) => get().channels.some((c) => c.id === id),
	subscribe: (channel) => set((state) => {
		if (state.channels.some((c) => c.id === channel.id)) return state;
		return { channels: [{
			...channel,
			subscribedAt: Date.now()
		}, ...state.channels] };
	}),
	unsubscribe: (id) => set((state) => ({ channels: state.channels.filter((c) => c.id !== id) })),
	toggle: (channel) => {
		if (get().isSubscribed(channel.id)) get().unsubscribe(channel.id);
		else get().subscribe(channel);
	}
}), {
	name: "community-subs-v2",
	merge: (persisted, current) => {
		const p = persisted;
		const channels = (p?.channels ?? current.channels).map((c, i) => ({
			...c,
			subscribedAt: typeof c.subscribedAt === "number" ? c.subscribedAt : Date.now() - i
		}));
		return {
			...current,
			...p,
			channels
		};
	}
}));
function SubscribeButton({ channel, size = "sm" }) {
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setReady(true), []);
	const isSubscribed = useSubscriptions((s) => s.isSubscribed(channel.id));
	const toggle = useSubscriptions((s) => s.toggle);
	const subscribed = ready && isSubscribed;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		type: "button",
		size,
		variant: subscribed ? "subscribed" : "subscribe",
		className: "shrink-0",
		onClick: (e) => {
			e.preventDefault();
			e.stopPropagation();
			toggle(channel);
		},
		"aria-pressed": subscribed,
		"aria-label": subscribed ? "Unsubscribe" : "Subscribe",
		children: subscribed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {}), "Subscribed"] }) : "Subscribe"
	});
}
function loadApi() {
	if (window.YT?.Player) return Promise.resolve(window.YT);
	return new Promise((resolve, reject) => {
		const existing = document.querySelector("script[src*=\"youtube.com/iframe_api\"]");
		const done = () => {
			if (window.YT?.Player) resolve(window.YT);
			else reject(/* @__PURE__ */ new Error("player"));
		};
		window.onYouTubeIframeAPIReady = done;
		if (!existing) {
			const tag = document.createElement("script");
			tag.src = "https://www.youtube.com/iframe_api";
			tag.async = true;
			tag.onerror = () => reject(/* @__PURE__ */ new Error("script"));
			document.head.appendChild(tag);
		}
		const t = window.setInterval(() => {
			if (window.YT?.Player) {
				window.clearInterval(t);
				done();
			}
		}, 80);
		window.setTimeout(() => {
			window.clearInterval(t);
			if (!window.YT?.Player) reject(/* @__PURE__ */ new Error("timeout"));
		}, 8e3);
	});
}
function forceQuality(player) {
	try {
		player.setPlaybackQualityRange?.("hd2160", "highres");
	} catch {}
	try {
		player.setPlaybackQuality?.("highres");
	} catch {}
	try {
		player.setPlaybackQuality?.("hd2160");
	} catch {}
}
function VideoPlayer({ videoId, title, onClose }) {
	const host = (0, import_react.useRef)(null);
	const player = (0, import_react.useRef)(null);
	const [fallback, setFallback] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const prev = document.body.style.overflow;
		document.body.style.overflow = "hidden";
		const onKey = (e) => {
			if (e.key === "Escape") onClose();
		};
		window.addEventListener("keydown", onKey);
		let cancelled = false;
		(async () => {
			try {
				const YT = await loadApi();
				if (cancelled || !host.current) return;
				player.current = new YT.Player(host.current, {
					videoId,
					width: "100%",
					height: "100%",
					playerVars: {
						autoplay: 1,
						rel: 0,
						modestbranding: 1,
						playsinline: 0,
						fs: 1,
						hd: 1,
						vq: "hd2160",
						controls: 1
					},
					events: {
						onReady: (e) => {
							forceQuality(e.target);
							try {
								e.target.playVideo();
							} catch {}
						},
						onStateChange: (e) => {
							if (e.data === 1) forceQuality(e.target);
						}
					}
				});
			} catch {
				if (!cancelled) setFallback(true);
			}
		})();
		return () => {
			cancelled = true;
			document.body.style.overflow = prev;
			window.removeEventListener("keydown", onKey);
			try {
				player.current?.destroy();
			} catch {}
			player.current = null;
		};
	}, [onClose, videoId]);
	const enterFs = () => {
		const root = document.getElementById("in-app-video");
		if (!root) return;
		const anyRoot = root;
		try {
			if (root.requestFullscreen) root.requestFullscreen();
			else anyRoot.webkitRequestFullscreen?.();
		} catch {}
	};
	const src = `https://www.youtube.com/embed/${encodeURIComponent(videoId)}?autoplay=1&rel=0&modestbranding=1&playsinline=0&fs=1&vq=hd2160&hd=1`;
	const node = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		id: "in-app-video",
		className: "fixed inset-0 z-[80] flex flex-col",
		style: { background: "#000000" },
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between gap-3 px-3 py-3 pt-[max(0.75rem,env(safe-area-inset-top))]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "min-w-0 flex-1 truncate text-sm font-medium",
					children: title || "Video"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "h-11 shrink-0 rounded-full bg-secondary px-4 text-sm font-medium",
					onClick: enterFs,
					children: "Full screen"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onClose,
					className: "flex size-11 shrink-0 items-center justify-center rounded-full bg-secondary",
					"aria-label": "Close",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "relative min-h-0 flex-1",
			style: { background: "#000000" },
			children: fallback ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
				title: title || "Video",
				className: "absolute inset-0 size-full border-0",
				src,
				allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share; fullscreen",
				allowFullScreen: true
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: host,
				className: "absolute inset-0 size-full"
			})
		})]
	});
	if (typeof document === "undefined") return null;
	return (0, import_react_dom.createPortal)(node, document.body);
}
function kindLabel(kind) {
	if (kind === "image") return "Image";
	if (kind === "poll") return "Poll";
	if (kind === "video") return "Video";
	if (kind === "quiz") return "Quiz";
	return "Post";
}
function PostCardInner({ post }) {
	const [openImage, setOpenImage] = (0, import_react.useState)(null);
	const [openVideo, setOpenVideo] = (0, import_react.useState)(false);
	const [expanded, setExpanded] = (0, import_react.useState)(false);
	const long = post.text.length > 280;
	const body = !expanded && long ? `${post.text.slice(0, 280).trim()}…` : post.text;
	const channel = {
		id: post.channelId,
		title: post.channelTitle,
		handle: post.channelHandle,
		description: "",
		thumbnail: post.channelThumbnail,
		subscriberCount: 0,
		subscriberText: "",
		videoCount: 0,
		videoText: "",
		verified: false,
		hasPostsTab: true
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "card-item overflow-hidden rounded-2xl border border-border bg-card p-4 sm:p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-start gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/channel/$channelId",
						params: { channelId: post.channelId },
						className: "shrink-0",
						children: post.channelThumbnail ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: post.channelThumbnail,
							alt: "",
							loading: "lazy",
							decoding: "async",
							className: "size-11 rounded-full object-cover"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex size-11 items-center justify-center rounded-full bg-muted text-sm font-medium",
							children: post.channelTitle.slice(0, 1)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex min-w-0 items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/channel/$channelId",
								params: { channelId: post.channelId },
								className: "truncate text-sm font-semibold text-foreground",
								children: post.channelTitle
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: kindLabel(post.kind) })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "truncate text-xs text-muted-foreground",
							children: [post.channelHandle ? `${post.channelHandle} · ` : "", post.publishedText]
						})]
					}),
					post.channelId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "shrink-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SubscribeButton, { channel })
					}) : null
				]
			}),
			body ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 whitespace-pre-wrap break-words text-pretty text-sm leading-relaxed text-foreground",
				children: [body, long ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "ml-1 font-medium text-muted-foreground underline-offset-2 hover:text-foreground hover:underline",
					onClick: () => setExpanded((v) => !v),
					children: expanded ? "Show less" : "Show more"
				}) : null]
			}) : null,
			post.images.length === 1 && post.images[0] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "mt-3 block w-full overflow-hidden rounded-xl bg-muted",
				onClick: () => setOpenImage(post.images[0].url),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: post.images[0].url,
					alt: "",
					loading: "lazy",
					decoding: "async",
					className: "max-h-[28rem] w-full object-cover"
				})
			}) : null,
			post.images.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("mt-3 grid gap-1 overflow-hidden rounded-xl", post.images.length === 2 ? "grid-cols-2" : "grid-cols-2 sm:grid-cols-3"),
				children: post.images.slice(0, 6).map((img, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "relative aspect-square overflow-hidden bg-muted",
					onClick: () => setOpenImage(img.url),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: img.url,
						alt: "",
						loading: "lazy",
						decoding: "async",
						className: "size-full object-cover"
					}), i === 5 && post.images.length > 6 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "absolute inset-0 flex items-center justify-center bg-background/70 text-sm font-medium",
						children: ["+", post.images.length - 6]
					}) : null]
				}, `${img.url}-${i}`))
			}) : null,
			post.poll ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-3 space-y-2",
				children: [post.poll.choices.map((choice) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: choice.imageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "w-full overflow-hidden rounded-xl border border-border bg-secondary text-left",
					onClick: () => setOpenImage(choice.imageUrl),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: choice.imageUrl,
						alt: "",
						loading: "lazy",
						decoding: "async",
						className: "h-28 w-full object-cover"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block px-3 py-2.5 text-sm break-words",
						children: choice.text
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rounded-xl border border-border bg-secondary px-3 py-2.5 text-sm break-words",
					children: choice.text
				}) }, choice.text)), post.poll.totalVotesText ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "px-1 text-xs text-muted-foreground",
					children: post.poll.totalVotesText
				}) : null]
			}) : null,
			post.video ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setOpenVideo(true),
				className: "relative mt-3 block w-full overflow-hidden rounded-xl bg-muted text-left",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: post.video.thumbnail,
						alt: "",
						loading: "lazy",
						decoding: "async",
						className: "aspect-video w-full object-cover"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "absolute inset-0 flex items-center justify-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex size-12 items-center justify-center rounded-full bg-background/80 text-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-5 fill-current" })
						})
					}),
					post.video.lengthText ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "absolute bottom-2 right-2 rounded-md bg-background/80 px-1.5 py-0.5 text-[11px] font-medium tabular-nums",
						children: post.video.lengthText
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block px-3 py-2 text-sm font-medium break-words",
						children: post.video.title
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "mt-4 flex items-center justify-between gap-3 text-xs text-muted-foreground",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-1.5 tabular-nums",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "size-3.5" }), post.likeText || "0"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-1.5 tabular-nums",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-3.5" }), post.replyText || post.replyCount || "0"]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBoundary, {
				fallbackTitle: "Comments failed to load",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommentThread, { post })
			}),
			openImage ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MediaViewer, {
				src: openImage,
				onClose: () => setOpenImage(null)
			}) : null,
			openVideo && post.video ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoPlayer, {
				videoId: post.video.id,
				title: post.video.title,
				onClose: () => setOpenVideo(false)
			}) : null
		]
	});
}
var PostCard = (0, import_react.memo)(PostCardInner);
function PostCardSkeleton() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-border bg-card p-4 sm:p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-11 animate-pulse rounded-full bg-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1 space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-3 w-40 animate-pulse rounded bg-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-3 w-24 animate-pulse rounded bg-muted" })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-3 w-full animate-pulse rounded bg-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-3 w-4/5 animate-pulse rounded bg-muted" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-3 h-48 animate-pulse rounded-xl bg-muted" })
		]
	});
}
var THRESHOLD = 72;
function PullToRefresh({ onRefresh, children, className }) {
	const startY = (0, import_react.useRef)(0);
	const pulling = (0, import_react.useRef)(false);
	const [offset, setOffset] = (0, import_react.useState)(0);
	const [refreshing, setRefreshing] = (0, import_react.useState)(false);
	const onTouchStart = (0, import_react.useCallback)((e) => {
		if (e.currentTarget.scrollTop > 4 || refreshing) return;
		pulling.current = true;
		startY.current = e.touches[0]?.clientY ?? 0;
	}, [refreshing]);
	const onTouchMove = (0, import_react.useCallback)((e) => {
		if (!pulling.current || refreshing) return;
		const dy = (e.touches[0]?.clientY ?? 0) - startY.current;
		if (dy <= 8) {
			setOffset(0);
			return;
		}
		setOffset(Math.min(dy * .38, 88));
	}, [refreshing]);
	const onTouchEnd = (0, import_react.useCallback)(async () => {
		if (!pulling.current) return;
		pulling.current = false;
		if (offset >= THRESHOLD && !refreshing) {
			setRefreshing(true);
			setOffset(52);
			try {
				await onRefresh();
			} catch {} finally {
				setRefreshing(false);
				setOffset(0);
			}
		} else setOffset(0);
	}, [
		offset,
		onRefresh,
		refreshing
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("scroll-pane relative min-h-0 flex-1 overflow-y-auto", className),
		style: { touchAction: "pan-y" },
		onTouchStart,
		onTouchMove,
		onTouchEnd,
		onTouchCancel: onTouchEnd,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pointer-events-none flex items-center justify-center overflow-hidden text-muted-foreground",
			style: {
				height: offset,
				transition: pulling.current ? "none" : "height var(--motion-fast) var(--ease-smooth-out)"
			},
			"aria-hidden": !refreshing && offset === 0,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: cn("size-5", (refreshing || offset > 24) && "animate-spin") })
		}), children]
	});
}
var TOPICS = [
	{
		id: "all",
		label: "All",
		kind: "all"
	},
	{
		id: "images",
		label: "Images",
		kind: "type"
	},
	{
		id: "polls",
		label: "Polls",
		kind: "type"
	},
	{
		id: "videos",
		label: "Videos",
		kind: "type"
	},
	{
		id: "text",
		label: "Text",
		kind: "type"
	},
	{
		id: "gaming",
		label: "Gaming",
		kind: "topic"
	},
	{
		id: "music",
		label: "Music",
		kind: "topic"
	},
	{
		id: "news",
		label: "News",
		kind: "topic"
	},
	{
		id: "tech",
		label: "Tech",
		kind: "topic"
	},
	{
		id: "sports",
		label: "Sports",
		kind: "topic"
	},
	{
		id: "comedy",
		label: "Comedy",
		kind: "topic"
	},
	{
		id: "education",
		label: "Education",
		kind: "topic"
	},
	{
		id: "food",
		label: "Food",
		kind: "topic"
	},
	{
		id: "fashion",
		label: "Fashion",
		kind: "topic"
	},
	{
		id: "science",
		label: "Science",
		kind: "topic"
	},
	{
		id: "travel",
		label: "Travel",
		kind: "topic"
	},
	{
		id: "finance",
		label: "Finance",
		kind: "topic"
	},
	{
		id: "anime",
		label: "Anime",
		kind: "topic"
	},
	{
		id: "podcasts",
		label: "Podcasts",
		kind: "topic"
	}
];
var TYPE_FILTER = {
	images: "image",
	polls: "poll",
	videos: "video",
	text: "text"
};
//#endregion
export { searchChannelsFn as _, POST_SORTS as a, useSubscriptions as b, PostCard as c, SubscribeButton as d, TOPICS as f, loadFeedPageFn as g, getChannelPostsFn as h, DesktopNav as i, PostCardSkeleton as l, getChannelFn as m, BottomNav as n, POST_TYPES as o, TYPE_FILTER as p, ChipBar as r, PageFrame as s, Badge as t, PullToRefresh as u, sortPosts as v, useSentinel as y };
