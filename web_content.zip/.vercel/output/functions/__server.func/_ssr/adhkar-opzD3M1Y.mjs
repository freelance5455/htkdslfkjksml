import { x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as BackButton } from "./back-button-DImimZOp.mjs";
import { l as toArabicDigits, r as TopBar, t as AppShell } from "./app-shell-C4IrQdCN.mjs";
import { r as adhkarLists, t as ADHKAR_GROUPS } from "./catalog-CjAfWU9w.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/adhkar-opzD3M1Y.js
var import_jsx_runtime = require_jsx_runtime();
function AdhkarHome() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
		title: "الأذكار والأدعية",
		back: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackButton, { href: "/" })
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6 px-4 py-4",
		children: [ADHKAR_GROUPS.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mb-2 text-sm font-semibold text-muted-foreground",
			children: g.title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "grid gap-2",
			children: g.ids.map((id) => {
				const list = adhkarLists.find((l) => l.id === id);
				if (!list) return null;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/adhkar/$listId",
					params: { listId: id },
					className: "flex items-center justify-between rounded-2xl bg-card px-4 py-3.5 shadow-[var(--shadow-border)]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block font-medium",
						children: list.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-xs text-muted-foreground",
						children: [toArabicDigits(list.items.length), " نص"]
					})] })
				}) }, id);
			})
		})] }, g.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "px-1 pb-4 text-[11px] leading-5 text-muted-foreground",
			children: "المصدر: حصن المسلم من أذكار الكتاب والسنة، لسعيد بن علي بن وهف القحطاني، مع أدعية قرآنية بنص المصحف."
		})]
	})] });
}
//#endregion
export { AdhkarHome as component };
