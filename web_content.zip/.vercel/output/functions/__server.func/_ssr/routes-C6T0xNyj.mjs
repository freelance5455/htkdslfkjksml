import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-C6T0xNyj.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var school = {
	authority: "T.C. Yenişehir Kaymakamlığı",
	name: "Yahya Günsür Mesleki ve Teknik Anadolu Lisesi",
	grade: "9-F",
	totalHours: 45,
	homeroom: "Çiğdem Bilir",
	issued: "11 Ekim 2026",
	issuedNote: "Yukarıdaki dersler 11/10/2026 tarihinde verilmiştir. Bilgilerinizi rica ederim.",
	principal: "Adem Çelik",
	principalTitle: "Okul Müdürü"
};
var periods = [
	{
		no: 1,
		start: "08:00",
		end: "08:40"
	},
	{
		no: 2,
		start: "08:50",
		end: "09:30"
	},
	{
		no: 3,
		start: "09:40",
		end: "10:20"
	},
	{
		no: 4,
		start: "10:30",
		end: "11:10"
	},
	{
		no: 5,
		start: "11:20",
		end: "12:00"
	},
	{
		no: 6,
		start: "12:40",
		end: "13:20"
	},
	{
		no: 7,
		start: "13:30",
		end: "14:10"
	},
	{
		no: 8,
		start: "14:20",
		end: "15:00"
	},
	{
		no: 9,
		start: "15:10",
		end: "15:50"
	},
	{
		no: 10,
		start: "15:55",
		end: "16:35"
	},
	{
		no: 11,
		start: "16:40",
		end: "17:20"
	}
];
var lunch = {
	after: 5,
	start: "12:00",
	end: "12:40",
	label: "Öğle arası"
};
var cigdem = "Çiğdem Bilir";
var hatice = "Hatice Cingöz";
var guzella = "Güzella Gökay";
var refah = "Refah Akış";
var kerim = "Kerim Eker";
var mustafa = "Mustafa Koç";
var hulyaKafali = "Hülya Kafalı";
var akif = "Akif Karaoğlan";
var adalet = "Adalet Çöçelli Satı";
var ahmet = "Ahmet Yıldırım";
var savas = "Savaş Tan";
var mehmet = "Mehmet Gölbol";
var gunes = "Güneş Zekioğulları";
var omer = "Ömer İl Faruk Yaşar";
var hulyaKarabulut = "Hülya Karabulut";
var workshopRoom = "B-4, B-5, B-…";
var courses = [
	{
		no: 1,
		code: "9 TEEA",
		name: "9 Temel Elektrik-Elektronik",
		hours: 8,
		place: "Temel Elektrik-Elektronik",
		teachers: [
			kerim,
			mehmet,
			mustafa
		],
		parentPlace: ""
	},
	{
		no: 2,
		code: "BESPR",
		name: "Beden Eğitimi ve Spor / Görsel Sanatlar",
		hours: 2,
		place: "",
		teachers: [adalet, hatice],
		parentPlace: ""
	},
	{
		no: 3,
		code: "BİY",
		name: "Biyoloji",
		hours: 2,
		place: "",
		teachers: [ahmet],
		parentPlace: ""
	},
	{
		no: 4,
		code: "COĞ",
		name: "Coğrafya",
		hours: 2,
		place: "",
		teachers: [omer],
		parentPlace: ""
	},
	{
		no: 5,
		code: "DVAB",
		name: "Din Kültürü ve Ahlak Bilgisi",
		hours: 2,
		place: "",
		teachers: [savas],
		parentPlace: ""
	},
	{
		no: 6,
		code: "ETEKR",
		name: "Teknik Resim",
		hours: 2,
		place: "",
		teachers: [mustafa],
		parentPlace: ""
	},
	{
		no: 7,
		code: "FİZ",
		name: "Fizik",
		hours: 2,
		place: "",
		teachers: [hulyaKarabulut],
		parentPlace: ""
	},
	{
		no: 8,
		code: "KİM",
		name: "Kimya",
		hours: 2,
		place: "",
		teachers: [hulyaKafali],
		parentPlace: ""
	},
	{
		no: 9,
		code: "MATS",
		name: "Matematik",
		hours: 5,
		place: "",
		teachers: [akif],
		parentPlace: ""
	},
	{
		no: 10,
		code: "MESG",
		name: "Mesleki Gelişim Atölyesi",
		hours: 2,
		place: "",
		teachers: [kerim],
		parentPlace: ""
	},
	{
		no: 11,
		code: "RHY",
		name: "Rehberlik ve Yönlendirme",
		hours: 1,
		place: "",
		teachers: [cigdem],
		parentPlace: ""
	},
	{
		no: 12,
		code: "SÇDÜEĞ",
		name: "Seçmeli Düşünme Eğitimi",
		hours: 1,
		place: "",
		teachers: [refah],
		parentPlace: ""
	},
	{
		no: 13,
		code: "SÇSPOR",
		name: "Seçmeli Spor Eğitimi",
		hours: 2,
		place: "",
		teachers: [hatice],
		parentPlace: ""
	},
	{
		no: 14,
		code: "SÇTDİN",
		name: "Seçmeli Temel Dini Bilgiler",
		hours: 1,
		place: "",
		teachers: [savas],
		parentPlace: ""
	},
	{
		no: 15,
		code: "TAR",
		name: "Tarih",
		hours: 2,
		place: "",
		teachers: [gunes],
		parentPlace: ""
	},
	{
		no: 16,
		code: "TDE",
		name: "Türk Dili ve Edebiyatı",
		hours: 5,
		place: "",
		teachers: [guzella],
		parentPlace: ""
	},
	{
		no: 17,
		code: "YDİL4",
		name: "Yabancı Dil",
		hours: 4,
		place: "",
		teachers: [cigdem],
		parentPlace: ""
	}
];
var byCode = new Map(courses.map((course) => [course.code, course]));
function courseByCode(code) {
	const course = byCode.get(code);
	if (!course) throw new Error(`Bilinmeyen ders kodu: ${code}`);
	return course;
}
function slot(code, teacher, room) {
	return room ? {
		code,
		teacher,
		room
	} : {
		code,
		teacher
	};
}
var empty = [null, null];
var days = [
	{
		id: "pazartesi",
		jsDay: 1,
		name: "Pazartesi",
		short: "Pzt",
		slots: [
			slot("YDİL4", cigdem),
			slot("YDİL4", cigdem),
			slot("SÇSPOR", hatice),
			slot("SÇSPOR", hatice),
			slot("RHY", cigdem),
			slot("TDE", guzella),
			slot("TDE", guzella),
			slot("SÇDÜEĞ", refah),
			slot("MESG", kerim),
			...empty
		]
	},
	{
		id: "sali",
		jsDay: 2,
		name: "Salı",
		short: "Sal",
		slots: [
			slot("TDE", guzella),
			slot("TDE", guzella),
			slot("TDE", guzella),
			slot("ETEKR", mustafa),
			slot("ETEKR", mustafa),
			slot("YDİL4", cigdem),
			slot("YDİL4", cigdem),
			slot("KİM", hulyaKafali),
			slot("KİM", hulyaKafali),
			...empty
		]
	},
	{
		id: "carsamba",
		jsDay: 3,
		name: "Çarşamba",
		short: "Çar",
		slots: [
			slot("MATS", akif),
			slot("MATS", akif),
			slot("BESPR", adalet),
			slot("BESPR", adalet),
			slot("BİY", ahmet),
			slot("BİY", ahmet),
			slot("DVAB", savas),
			slot("DVAB", savas),
			slot("SÇTDİN", savas),
			...empty
		]
	},
	{
		id: "persembe",
		jsDay: 4,
		name: "Perşembe",
		short: "Per",
		slots: [
			slot("9 TEEA", mehmet, workshopRoom),
			slot("9 TEEA", mehmet, workshopRoom),
			slot("9 TEEA", mehmet, workshopRoom),
			slot("9 TEEA", mehmet, workshopRoom),
			slot("9 TEEA", mehmet, workshopRoom),
			slot("9 TEEA", mehmet, workshopRoom),
			slot("9 TEEA", mehmet, workshopRoom),
			slot("9 TEEA", mehmet, workshopRoom),
			slot("MESG", kerim),
			...empty
		]
	},
	{
		id: "cuma",
		jsDay: 5,
		name: "Cuma",
		short: "Cum",
		slots: [
			slot("TAR", gunes),
			slot("TAR", gunes),
			slot("COĞ", omer),
			slot("COĞ", omer),
			slot("FİZ", hulyaKarabulut),
			slot("FİZ", hulyaKarabulut),
			slot("MATS", akif),
			slot("MATS", akif),
			slot("MATS", akif),
			...empty
		]
	}
];
var sourceNotes = [
	"Perşembe atölye satırında derslik belgede “B-4, B-5, B-” diye kesik görünüyor. Üçüncü kod tamamlanmadan bırakıldı.",
	"9 Temel Elektrik-Elektronik yer sütunu belgede “TEMEL ELEKTRİK-ELE…” diye kesiliyor. Görünen kısım yazıldı.",
	"Beden eğitimi dersinin adı belgede “BEDEN EĞİTİMİ VE SPOR / GÖRSEL SANATLAR /” diye bitiyor. Satır hücrede kesik olduğu için devamı eklenmedi.",
	"Türk Dili ve Edebiyatı adının yanında belgede bir yıldız var. Yıldızın açıklaması sayfada yok.",
	"Veli görüşme yeri sütunu belgede bütün dersler için boş.",
	"Perşembe atölyesinde hücrede Mehmet Gölbol yazılı. Dersin kayıtlı öğretmenleri Kerim Eker, Mehmet Gölbol ve Mustafa Koç.",
	"Çarşamba beden eğitiminde hücrede Adalet Çöçelli Satı yazılı. Dersin kayıtlı öğretmenleri Adalet Çöçelli Satı ve Hatice Cingöz."
];
function toMinutes(value) {
	const [hour, minute] = value.split(":").map(Number);
	return hour * 60 + minute;
}
function findFocus(now) {
	const weekday = now.getDay();
	const minutes = now.getHours() * 60 + now.getMinutes();
	const order = [
		1,
		2,
		3,
		4,
		5
	];
	const start = order.indexOf(weekday);
	const sequence = start === -1 ? order : [...order.slice(start), ...order.slice(0, start)];
	for (let index = 0; index < sequence.length; index += 1) {
		const jsDay = sequence[index];
		const day = days.find((item) => item.jsDay === jsDay);
		if (!day) continue;
		const isToday = index === 0 && jsDay === weekday;
		for (let periodIndex = 0; periodIndex < periods.length; periodIndex += 1) {
			const period = periods[periodIndex];
			const lesson = day.slots[periodIndex];
			if (!lesson) continue;
			const startMinute = toMinutes(period.start);
			const endMinute = toMinutes(period.end);
			if (isToday) {
				if (minutes >= startMinute && minutes < endMinute) return {
					kind: "now",
					day,
					period,
					slot: lesson
				};
				if (minutes < startMinute) return {
					kind: "next",
					day,
					period,
					slot: lesson
				};
			} else return {
				kind: "next",
				day,
				period,
				slot: lesson
			};
		}
	}
	return null;
}
function LessonBody({ slot }) {
	const course = courseByCode(slot.code);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-w-0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "font-semibold leading-snug text-ink",
				children: [course.name, course.code === "TDE" ? "*" : ""]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: slot.teacher
			}),
			slot.room ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm text-accent",
				children: ["Derslik ", slot.room]
			}) : null
		]
	});
}
function EmptyLesson() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: "Ders yok"
	});
}
function DersProgrami() {
	const [today, setToday] = (0, import_react.useState)(null);
	const [focusLabel, setFocusLabel] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const update = () => {
			const now = /* @__PURE__ */ new Date();
			setToday(now.getDay());
			const focus = findFocus(now);
			if (!focus) {
				setFocusLabel(null);
				return;
			}
			const course = courseByCode(focus.slot.code);
			const when = focus.kind === "now" ? "Şu an" : "Sıradaki ders";
			setFocusLabel(`${when}: ${focus.day.name}, ${focus.period.no}. ders, ${focus.period.start}–${focus.period.end}. ${course.name}, ${focus.slot.teacher}.`);
		};
		update();
		const timer = window.setInterval(update, 6e4);
		return () => window.clearInterval(timer);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-paper text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "border-b border-line bg-card",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-7xl px-4 py-8 md:px-8 md:py-10",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold tracking-widest text-accent uppercase",
							children: school.authority
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 max-w-3xl font-serif text-3xl leading-tight text-ink md:text-4xl",
							children: school.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "mt-4 text-lg font-semibold text-ink md:text-xl",
							children: [school.grade, " ders programı"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "mt-6 grid gap-3 sm:grid-cols-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-lg border border-line bg-quiet px-4 py-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-xs font-medium tracking-wide text-muted uppercase",
										children: "Sınıf öğretmeni"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "mt-1 font-semibold",
										children: school.homeroom
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-lg border border-line bg-quiet px-4 py-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-xs font-medium tracking-wide text-muted uppercase",
										children: "Toplam ders saati"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "mt-1 font-semibold",
										children: school.totalHours
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-lg border border-line bg-quiet px-4 py-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-xs font-medium tracking-wide text-muted uppercase",
										children: "Program tarihi"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "mt-1 font-semibold",
										children: school.issued
									})]
								})
							]
						}),
						focusLabel ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 rounded-lg border border-line bg-accent-soft px-4 py-3 text-sm leading-relaxed text-accent",
							children: focusLabel
						}) : null
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "no-print sticky top-0 z-10 border-b border-line bg-paper lg:hidden",
				"aria-label": "Günler",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto flex max-w-7xl gap-2 overflow-x-auto px-4 py-3",
					children: days.map((day) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: `#${day.id}`,
						className: "shrink-0 rounded-full border border-line bg-card px-4 py-2 text-sm font-semibold text-ink",
						children: [day.name, today === day.jsDay ? " · bugün" : ""]
					}, day.id))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto max-w-7xl px-4 py-6 md:px-8 md:py-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						"aria-labelledby": "hafta-baslik",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-4 flex items-end justify-between gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									id: "hafta-baslik",
									className: "font-serif text-2xl text-ink",
									children: "Haftalık program"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted",
									children: "Tam ders adları"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "hidden overflow-hidden rounded-xl border border-line bg-card lg:block",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
									className: "w-full border-collapse text-left",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("caption", {
											className: "sr-only",
											children: [school.grade, " sınıfının pazartesiden cumaya haftalık ders programı"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
											className: "bg-accent text-card",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												scope: "col",
												className: "w-28 px-3 py-3 text-sm font-semibold",
												children: "Saat"
											}), days.map((day) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("th", {
												scope: "col",
												className: "px-3 py-3 text-sm font-semibold",
												children: [day.name, today === day.jsDay ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "mt-1 block text-xs font-medium text-accent-soft",
													children: "Bugün"
												}) : null]
											}, day.id))]
										}) }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: periods.map((period, periodIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WeekRows, {
											periodIndex,
											today
										}, period.no)) })
									]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "space-y-8 lg:hidden",
								children: days.map((day) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
									id: day.id,
									className: "scroll-mt-20 overflow-hidden rounded-xl border border-line bg-card",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
										className: "border-b border-line bg-accent px-4 py-3 font-semibold text-card",
										children: [day.name, today === day.jsDay ? " · bugün" : ""]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", { children: periods.map((period, periodIndex) => {
										const lesson = day.slots[periodIndex];
										const showLunch = period.no === lunch.after;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid grid-cols-[5.5rem_1fr] gap-3 border-b border-line px-4 py-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-sm font-semibold tabular-nums",
													children: period.start
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs text-muted tabular-nums",
													children: period.end
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
													className: "mt-1 text-xs text-muted",
													children: [period.no, ". ders"]
												})
											] }), lesson ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LessonBody, { slot: lesson }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyLesson, {})]
										}), showLunch ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "border-b border-line bg-lunch px-4 py-2 text-sm font-medium text-ink",
											children: [
												lunch.label,
												" · ",
												lunch.start,
												"–",
												lunch.end
											]
										}) : null] }, period.no);
									}) })]
								}, day.id))
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mt-12",
						"aria-labelledby": "liste-baslik",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								id: "liste-baslik",
								className: "font-serif text-2xl text-ink",
								children: "Derslerin tam listesi"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 max-w-3xl text-sm leading-relaxed text-muted",
								children: "Belgedeki 17 dersin tamamı. Haftalık saatler, yer, öğretmenler ve veli görüşme yeri belgede nasıl duruyorsa öyle aktarıldı."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-5 hidden overflow-hidden rounded-xl border border-line bg-card md:block",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
									className: "w-full border-collapse text-left text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
										className: "bg-quiet text-muted",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-3 py-3 font-semibold",
												children: "No"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-3 py-3 font-semibold",
												children: "Kod"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-3 py-3 font-semibold",
												children: "Dersin adı"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-3 py-3 font-semibold",
												children: "Saat"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-3 py-3 font-semibold",
												children: "Yer"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-3 py-3 font-semibold",
												children: "Öğretmen"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-3 py-3 font-semibold",
												children: "Veli görüşme yeri"
											})
										] })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: courses.map((course) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "border-t border-line align-top",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-3 tabular-nums",
												children: course.no
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-3 whitespace-nowrap text-muted",
												children: course.code
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
												className: "px-3 py-3 font-semibold",
												children: [course.name, course.code === "TDE" ? "*" : ""]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-3 tabular-nums",
												children: course.hours
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-3",
												children: course.place || "—"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-3",
												children: course.teachers.join(", ")
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-3",
												children: course.parentPlace || "—"
											})
										]
									}, course.code)) })]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
								className: "mt-5 space-y-3 md:hidden",
								children: courses.map((course) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "rounded-xl border border-line bg-card px-4 py-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-xs font-medium tracking-wide text-muted uppercase",
											children: [
												course.no,
												". ders · ",
												course.code,
												" · ",
												course.hours,
												" saat"
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mt-1 font-semibold",
											children: [course.name, course.code === "TDE" ? "*" : ""]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-sm",
											children: course.teachers.join(", ")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mt-1 text-sm text-muted",
											children: ["Yer: ", course.place || "belirtilmemiş"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-sm text-muted",
											children: ["Veli görüşme yeri: ", course.parentPlace || "belirtilmemiş"]
										})
									]
								}, course.code))
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
						className: "mt-12 border-t border-line pt-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "max-w-3xl text-sm leading-relaxed",
								children: school.issuedNote
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-6 font-semibold",
								children: school.principal
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: school.principalTitle
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-8 text-sm font-semibold tracking-wide text-muted uppercase",
								children: "Belgeden aynen alınan notlar"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-3 max-w-3xl space-y-2 text-sm leading-relaxed text-muted",
								children: sourceNotes.map((note) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: note }, note))
							})
						]
					})
				]
			})
		]
	});
}
function WeekRows({ periodIndex, today }) {
	const period = periods[periodIndex];
	const showLunch = period.no === lunch.after;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
		className: "border-t border-line align-top",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("th", {
			scope: "row",
			className: "bg-quiet px-3 py-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-sm font-semibold tabular-nums",
					children: period.start
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-xs font-medium text-muted tabular-nums",
					children: period.end
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "mt-1 block text-xs font-medium text-muted",
					children: [period.no, ". ders"]
				})
			]
		}), days.map((day) => {
			const lesson = day.slots[periodIndex];
			const isToday = today === day.jsDay;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: isToday ? "bg-accent-soft px-3 py-3" : "px-3 py-3",
				children: lesson ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LessonBody, { slot: lesson }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyLesson, {})
			}, day.id);
		})]
	}), showLunch ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
		colSpan: 6,
		className: "border-t border-line bg-lunch px-3 py-2 text-sm font-medium",
		children: [
			lunch.label,
			" · ",
			lunch.start,
			"–",
			lunch.end
		]
	}) }) : null] });
}
var SplitComponent = DersProgrami;
//#endregion
export { SplitComponent as component };
