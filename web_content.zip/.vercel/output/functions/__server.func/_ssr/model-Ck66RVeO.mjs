import { n as createMiddleware } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/model-Ck66RVeO.js
/**
* Auth middleware for server functions — the standard way to get the caller's
* verified user id. When deployed the session cookie is same-origin and rides
* along automatically. In the live preview the client also forwards the bearer
* token (partitioned cookies) via the `.client` hook below — call sites do not
* thread it themselves.
*
*   import { createServerFn } from "@tanstack/react-start";
*   import { getSql } from "@/lib/db";
*   import { authMiddleware } from "@/lib/auth/middleware";
*
*   export const listTodos = createServerFn({ method: "GET" })
*     .middleware([authMiddleware])
*     .handler(async ({ context }) => {
*       const sql = await getSql();
*       return sql`select * from todos where user_id = ${context.userId}`;
*     });
*
* Signed out with auth on (live preview included) -> throws `UnauthorizedError`
* (see `verify.server.ts`). With auth disabled (`VITE_AUTH_ENABLED=false`, the
* shipped default) it resolves the shared dev user — but throws instead when a
* `DATABASE_URL` is also set, so an app without sign-in must not use this at
* all. On the auth-on path, use it on every server function that touches
* per-user data and scope every query by `context.userId`.
*/
var authMiddleware = createMiddleware({ type: "function" }).client(async ({ next }) => {
	const { getBearerToken } = await import("./client-BhcLuWvF.mjs").then((n) => n.n).then((n) => n.n);
	return next({ sendContext: { bearerToken: getBearerToken() ?? void 0 } });
}).server(async ({ next, context }) => {
	const { assertSameSiteRequest } = await import("./isolation.server-CGNg1r0B.mjs");
	const { requireUserId } = await import("./verify.server-CRd2zG0B.mjs");
	assertSameSiteRequest();
	return next({ context: { userId: await requireUserId(context.bearerToken) } });
});
var USER_RE = /^[A-Za-z0-9][A-Za-z0-9._-]{1,22}[A-Za-z0-9]$/;
var ROLES = [{
	id: "listener",
	label: "مستمع",
	hint: "حضور هادئ: متابعة وتفاعل"
}, {
	id: "creator",
	label: "صانع",
	hint: "صناعة ريلز وسيبلمنال ومسابقات"
}];
var POST_KINDS = {
	vent: {
		label: "فضفضة",
		hint: "كلام بلا قناع"
	},
	contest: {
		label: "مسابقة",
		hint: "سؤال، ودعوة للمشاركة"
	},
	info: {
		label: "معلومة",
		hint: "شيء يستحق أن يعرفه الجميع"
	},
	news: {
		label: "نشرة اخبارية",
		hint: "خبر قصير من يومك"
	},
	reel: {
		label: "ميم / ريل",
		hint: "صورة تظهر في شريط الريلز"
	},
	subliminal: {
		label: "سيبلمنال",
		hint: "عنوان ووصف ورابط إن وجد"
	}
};
var HOME_KINDS = [
	"vent",
	"contest",
	"info",
	"news"
];
var REACTIONS = [
	{
		id: "gleam",
		label: "بريق"
	},
	{
		id: "crown",
		label: "تاج"
	},
	{
		id: "feather",
		label: "ريشة"
	},
	{
		id: "gem",
		label: "ماسة"
	},
	{
		id: "moon",
		label: "هلال"
	},
	{
		id: "bloom",
		label: "ورد"
	}
];
var STICKERS = [
	{
		id: "cat",
		label: "قطة"
	},
	{
		id: "star",
		label: "نجمة"
	},
	{
		id: "clover",
		label: "برسيم"
	},
	{
		id: "note",
		label: "نغمة"
	},
	{
		id: "cup",
		label: "فنجان"
	},
	{
		id: "bird",
		label: "عصفور"
	},
	{
		id: "shell",
		label: "قوقعة"
	},
	{
		id: "sun",
		label: "شمس"
	}
];
function emailFor(username) {
	return `cg_${username.toLowerCase()}@cutegirls.app`;
}
function isRole(v) {
	return v === "listener" || v === "creator";
}
function isKind(v) {
	return v in POST_KINDS;
}
function isReaction(v) {
	return REACTIONS.some((r) => r.id === v);
}
function isSticker(v) {
	return STICKERS.some((s) => s.id === v);
}
function parseYoutubeChannel(input) {
	const trimmed = input.trim();
	if (!trimmed) return null;
	const withProto = /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
	let url;
	try {
		url = new URL(withProto);
	} catch {
		return null;
	}
	if (url.protocol !== "https:" && url.protocol !== "http:") return null;
	if (url.hostname.toLowerCase().replace(/^www\./, "").replace(/^m\./, "") !== "youtube.com") return null;
	const match = url.pathname.match(/^\/@([^/?#]+)$/);
	if (!match) return null;
	let handle = match[1];
	try {
		handle = decodeURIComponent(handle);
	} catch {
		return null;
	}
	if (!USER_RE.test(handle)) return null;
	return {
		url: `https://www.youtube.com/@${handle}`,
		handle
	};
}
function youtubeVideoId(input) {
	try {
		const url = new URL(input);
		const host = url.hostname.toLowerCase().replace(/^www\./, "").replace(/^m\./, "");
		if (host === "youtu.be") {
			const id = url.pathname.split("/").filter(Boolean)[0] ?? "";
			return /^[\w-]{6,20}$/.test(id) ? id : null;
		}
		if (host !== "youtube.com") return null;
		const v = url.searchParams.get("v");
		if (v && /^[\w-]{6,20}$/.test(v)) return v;
		return url.pathname.match(/^\/(?:shorts|embed|live)\/([\w-]{6,20})/)?.[1] ?? null;
	} catch {
		return null;
	}
}
function ago(iso) {
	const t = new Date(iso).getTime();
	if (!Number.isFinite(t)) return "";
	const seconds = Math.max(0, Math.round((Date.now() - t) / 1e3));
	if (seconds < 45) return "الآن";
	const minutes = Math.round(seconds / 60);
	if (minutes < 60) return `منذ ${minutes} د`;
	const hours = Math.round(minutes / 60);
	if (hours < 24) return `منذ ${hours} س`;
	const days = Math.round(hours / 24);
	if (days < 30) return `منذ ${days} ي`;
	return new Date(iso).toLocaleDateString("ar");
}
function roleLabel(role) {
	return role === "creator" ? "صانع" : "مستمع";
}
//#endregion
export { STICKERS as a, authMiddleware as c, isReaction as d, isRole as f, youtubeVideoId as g, roleLabel as h, ROLES as i, emailFor as l, parseYoutubeChannel as m, POST_KINDS as n, USER_RE as o, isSticker as p, REACTIONS as r, ago as s, HOME_KINDS as t, isKind as u };
