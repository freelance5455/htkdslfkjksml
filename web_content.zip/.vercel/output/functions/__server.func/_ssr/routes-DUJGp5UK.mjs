import { i as __toESM } from "../_runtime.mjs";
import { a as require_jsx_runtime, o as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { i as Download, n as RotateCcw, r as ImagePlus } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { i as SliderTrack, n as SliderRange, r as SliderThumb, t as Slider$1 } from "../_libs/@radix-ui/react-slider+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DUJGp5UK.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var variants = {
	primary: "bg-paper text-ink hover:bg-paper/90",
	quiet: "bg-field text-paper hover:bg-field/80",
	ghost: "border border-line bg-transparent text-paper hover:bg-field"
};
function Button({ variant = "primary", className, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: cn("btn inline-flex h-11 items-center justify-center gap-2 rounded-md px-4 text-sm font-medium whitespace-nowrap", "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-paper/40", "disabled:pointer-events-none disabled:opacity-40", variants[variant], className),
		...props
	});
}
function Slider({ value, min, max, step, label, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slider$1, {
		className: "relative flex h-11 w-full touch-none items-center select-none",
		min,
		max,
		step,
		value: [value],
		"aria-label": label,
		onValueChange: (next) => {
			const v = next[0];
			if (typeof v === "number") onChange(v);
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
			className: "relative h-1.5 w-full grow overflow-hidden rounded-full bg-field",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRange, { className: "absolute h-full bg-paper" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, { className: "slider-thumb focus-visible:ring-2 focus-visible:ring-paper/40 focus-visible:outline-none" })]
	});
}
var MAX_EDGE = 1080;
function fitSize(nw, nh, max = MAX_EDGE) {
	const longest = Math.max(nw, nh, 1);
	const scale = longest > max ? max / longest : 1;
	return {
		w: Math.max(1, Math.round(nw * scale)),
		h: Math.max(1, Math.round(nh * scale))
	};
}
function fontString(size, family) {
	if (family === "impact") return `400 ${size}px Anton, Impact, "Arial Black", sans-serif`;
	return `600 ${size}px Outfit, ui-sans-serif, system-ui, sans-serif`;
}
function wrapLine(ctx, text, maxW) {
	const words = text.split(/\s+/).filter(Boolean);
	if (words.length === 0) return [];
	const lines = [];
	let current = words[0];
	for (let i = 1; i < words.length; i++) {
		const word = words[i];
		const test = `${current} ${word}`;
		if (ctx.measureText(test).width <= maxW) current = test;
		else {
			lines.push(current);
			current = word;
		}
	}
	lines.push(current);
	return lines;
}
function layoutLayer(ctx, layer, width, height) {
	const raw = layer.uppercase ? layer.text.toUpperCase() : layer.text;
	if (!raw.trim()) return null;
	const maxW = Math.max(32, width * layer.maxWidth);
	let size = Math.max(12, width * layer.fontSize);
	const paragraphs = raw.split("\n");
	let lines = [];
	const spaced = ctx;
	for (let attempt = 0; attempt < 18; attempt++) {
		ctx.font = fontString(size, layer.family);
		if (spaced.letterSpacing !== void 0) spaced.letterSpacing = layer.family === "impact" ? `${Math.max(0, size * .015)}px` : "0px";
		lines = [];
		for (const para of paragraphs) {
			const wrapped = wrapLine(ctx, para, maxW);
			if (wrapped.length === 0) lines.push("");
			else lines.push(...wrapped);
		}
		const widest = Math.max(1, ...lines.map((line) => ctx.measureText(line || " ").width));
		const lineH = size * (layer.family === "impact" ? 1.08 : 1.24);
		const blockH = lines.length * lineH;
		const fitsWidth = widest <= maxW + 1;
		const fitsHeight = blockH <= height * .78;
		if (fitsWidth && fitsHeight || size <= 14) break;
		const widthScale = fitsWidth ? 1 : maxW / widest;
		const heightScale = fitsHeight ? 1 : height * .78 / blockH;
		size = Math.max(14, size * Math.min(widthScale, heightScale) * .96);
	}
	const lineH = size * (layer.family === "impact" ? 1.08 : 1.24);
	return {
		lines,
		size,
		lineH
	};
}
function renderMeme(ctx, spec) {
	const { width, height, image, fill, layers } = spec;
	ctx.clearRect(0, 0, width, height);
	ctx.imageSmoothingEnabled = true;
	ctx.imageSmoothingQuality = "high";
	if (image) ctx.drawImage(image, 0, 0, width, height);
	else {
		ctx.fillStyle = fill;
		ctx.fillRect(0, 0, width, height);
	}
	const hits = [];
	for (const layer of layers) {
		const laid = layoutLayer(ctx, layer, width, height);
		if (!laid) continue;
		const { lines, size, lineH } = laid;
		const centerX = layer.x * width;
		const centerY = layer.y * height;
		const blockH = lines.length * lineH;
		const fillColor = layer.tone === "light" ? "#f7f7f5" : "#141416";
		const strokeColor = layer.tone === "light" ? "#0a0a0c" : "#f7f7f5";
		const stroke = Math.max(0, size * layer.outline);
		if (layer.banner) {
			const barH = blockH + size * .85;
			const barY = Math.min(height - barH, Math.max(0, centerY - barH / 2));
			ctx.fillStyle = layer.tone === "light" ? "rgba(8,8,10,0.92)" : "rgba(243,241,236,0.94)";
			ctx.fillRect(0, barY, width, barH);
			hits.push({
				id: layer.id,
				x: 0,
				y: barY,
				w: width,
				h: barH
			});
		}
		ctx.font = fontString(size, layer.family);
		ctx.textAlign = "center";
		ctx.textBaseline = "middle";
		ctx.lineJoin = "round";
		ctx.miterLimit = 2;
		const top = centerY - blockH / 2;
		lines.forEach((line, index) => {
			const y = top + lineH * index + lineH / 2;
			if (!line) return;
			if (stroke > 0) {
				ctx.lineWidth = stroke;
				ctx.strokeStyle = strokeColor;
				ctx.strokeText(line, centerX, y);
			}
			ctx.fillStyle = fillColor;
			ctx.fillText(line, centerX, y);
		});
		if (!layer.banner) {
			const widest = Math.max(...lines.map((line) => ctx.measureText(line || " ").width), size);
			const pad = Math.max(28, size * .35);
			const boxW = Math.max(widest, size * 2) + pad * 2;
			const boxH = Math.max(blockH, size) + pad * 2;
			hits.push({
				id: layer.id,
				x: centerX - boxW / 2,
				y: centerY - boxH / 2,
				w: boxW,
				h: boxH
			});
		}
	}
	return hits;
}
function hitAt(hits, x, y) {
	for (let i = hits.length - 1; i >= 0; i--) {
		const hit = hits[i];
		if (x >= hit.x && y >= hit.y && x <= hit.x + hit.w && y <= hit.y + hit.h) return hit;
	}
	return null;
}
var impact = {
	fontSize: .078,
	outline: .2,
	tone: "light",
	family: "impact",
	uppercase: true,
	banner: false,
	maxWidth: .9,
	x: .5
};
var PRESETS = [
	{
		id: "classic",
		name: "Classic",
		detail: "Top setup, bottom punchline",
		layers: [{
			...impact,
			id: "top",
			label: "Top",
			text: "Me, five minutes ago",
			y: .11
		}, {
			...impact,
			id: "bottom",
			label: "Bottom",
			text: "I will start right now",
			y: .89
		}]
	},
	{
		id: "top",
		name: "Top line",
		detail: "One line, up high",
		layers: [{
			...impact,
			id: "top",
			label: "Top",
			text: "Plot twist",
			y: .12
		}]
	},
	{
		id: "bottom",
		name: "Bottom line",
		detail: "Punchline only",
		layers: [{
			...impact,
			id: "bottom",
			label: "Bottom",
			text: "Worth it",
			y: .88
		}]
	},
	{
		id: "center",
		name: "Center",
		detail: "One big shout",
		layers: [{
			...impact,
			id: "center",
			label: "Center",
			text: "Nice try",
			y: .5,
			fontSize: .12
		}]
	},
	{
		id: "stack",
		name: "Stacked",
		detail: "Two lines, lower half",
		layers: [{
			...impact,
			id: "a",
			label: "Line 1",
			text: "The plan",
			y: .74,
			fontSize: .07
		}, {
			...impact,
			id: "b",
			label: "Line 2",
			text: "The plan now",
			y: .89,
			fontSize: .084
		}]
	},
	{
		id: "split",
		name: "Split",
		detail: "Left label and right label",
		layers: [{
			...impact,
			id: "left",
			label: "Left",
			text: "Before",
			x: .25,
			y: .13,
			maxWidth: .44,
			fontSize: .062
		}, {
			...impact,
			id: "right",
			label: "Right",
			text: "After",
			x: .75,
			y: .13,
			maxWidth: .44,
			fontSize: .062
		}]
	},
	{
		id: "banner",
		name: "Caption bar",
		detail: "Modern bar along the bottom",
		layers: [{
			...impact,
			id: "caption",
			label: "Caption",
			text: "when the snack is right where you left it",
			y: .9,
			fontSize: .046,
			outline: 0,
			family: "plain",
			uppercase: false,
			banner: true,
			maxWidth: .88
		}]
	}
];
function copyLayers(layers) {
	return layers.map((layer) => ({ ...layer }));
}
function presetById(id) {
	return PRESETS.find((preset) => preset.id === id) ?? PRESETS[0];
}
var STARTERS = [
	{
		id: "cat",
		name: "Puzzled cat",
		tone: "light",
		kind: "image",
		src: "/starters/cat.jpg"
	},
	{
		id: "dog",
		name: "Head tilt",
		tone: "light",
		kind: "image",
		src: "/starters/dog.jpg"
	},
	{
		id: "frog",
		name: "Unimpressed frog",
		tone: "light",
		kind: "image",
		src: "/starters/frog.jpg"
	},
	{
		id: "duck",
		name: "Desk duck",
		tone: "light",
		kind: "image",
		src: "/starters/duck.jpg"
	},
	{
		id: "split",
		name: "Before and after",
		tone: "light",
		kind: "image",
		src: "/starters/split.jpg"
	},
	{
		id: "ink",
		name: "Ink",
		tone: "light",
		kind: "fill",
		color: "#141416"
	},
	{
		id: "paper",
		name: "Paper",
		tone: "dark",
		kind: "fill",
		color: "#f3f1ec"
	}
];
function starterById(id) {
	return STARTERS.find((starter) => starter.id === id) ?? STARTERS[0];
}
var MAX_UPLOAD = 15728640;
function clamp(n, min, max) {
	return Math.min(max, Math.max(min, n));
}
function pointFromEvent(canvas, clientX, clientY) {
	const rect = canvas.getBoundingClientRect();
	if (rect.width < 1 || rect.height < 1) return {
		x: 0,
		y: 0
	};
	return {
		x: (clientX - rect.left) / rect.width * canvas.width,
		y: (clientY - rect.top) / rect.height * canvas.height
	};
}
function MemeStudio() {
	const initial = PRESETS[0];
	const [presetId, setPresetId] = (0, import_react.useState)(initial.id);
	const [layers, setLayers] = (0, import_react.useState)(() => copyLayers(initial.layers));
	const [selectedId, setSelectedId] = (0, import_react.useState)(initial.layers[0].id);
	const [starterId, setStarterId] = (0, import_react.useState)(STARTERS[0].id);
	const [upload, setUpload] = (0, import_react.useState)(null);
	const [image, setImage] = (0, import_react.useState)(null);
	const [fill, setFill] = (0, import_react.useState)("#141416");
	const [size, setSize] = (0, import_react.useState)({
		w: 1080,
		h: 1080
	});
	const [status, setStatus] = (0, import_react.useState)("loading");
	const [error, setError] = (0, import_react.useState)(null);
	const [dropping, setDropping] = (0, import_react.useState)(false);
	const [fontTick, setFontTick] = (0, import_react.useState)(0);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [saved, setSaved] = (0, import_react.useState)(false);
	const canvasRef = (0, import_react.useRef)(null);
	const frameRef = (0, import_react.useRef)(null);
	const fileRef = (0, import_react.useRef)(null);
	const hitsRef = (0, import_react.useRef)([]);
	const layersRef = (0, import_react.useRef)(layers);
	const sizeRef = (0, import_react.useRef)(size);
	const selectedRef = (0, import_react.useRef)(selectedId);
	const dragRef = (0, import_react.useRef)(null);
	const frameReq = (0, import_react.useRef)(0);
	const pendingMove = (0, import_react.useRef)(null);
	layersRef.current = layers;
	sizeRef.current = size;
	selectedRef.current = selectedId;
	const starter = starterById(starterId);
	const preset = presetById(presetId);
	const selected = layers.find((layer) => layer.id === selectedId) ?? layers[0];
	const photoLabel = upload?.name ?? starter.name;
	const srcKey = upload ? upload.url : starter.kind === "image" ? starter.src : `fill:${starter.color}`;
	(0, import_react.useEffect)(() => {
		let alive = true;
		const bump = () => {
			if (alive) setFontTick((n) => n + 1);
		};
		document.fonts.ready.then(bump).catch(() => {});
		document.fonts.addEventListener("loadingdone", bump);
		document.fonts.load("400 96px Anton");
		document.fonts.load("600 64px Outfit");
		return () => {
			alive = false;
			document.fonts.removeEventListener("loadingdone", bump);
		};
	}, []);
	(0, import_react.useEffect)(() => {
		let cancel = false;
		if (!upload && starter.kind === "fill") {
			setImage(null);
			setFill(starter.color);
			setSize({
				w: 1080,
				h: 1080
			});
			setStatus("ready");
			return;
		}
		const src = upload?.url ?? (starter.kind === "image" ? starter.src : "");
		if (!src) return;
		setStatus("loading");
		const img = new Image();
		img.onload = () => {
			if (cancel) return;
			setImage(img);
			setFill("#141416");
			setSize(fitSize(img.naturalWidth, img.naturalHeight));
			setStatus("ready");
			setError(null);
		};
		img.onerror = () => {
			if (cancel) return;
			setImage(null);
			setFill("#141416");
			setSize({
				w: 1080,
				h: 1080
			});
			setStatus("ready");
			setError("Couldn't load that photo. Try a different one.");
		};
		img.src = src;
		return () => {
			cancel = true;
		};
	}, [
		srcKey,
		starter,
		upload
	]);
	(0, import_react.useEffect)(() => {
		if (status !== "ready") return;
		const canvas = canvasRef.current;
		if (!canvas) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		hitsRef.current = renderMeme(ctx, {
			width: canvas.width,
			height: canvas.height,
			image,
			fill,
			layers
		});
	}, [
		status,
		image,
		fill,
		layers,
		size,
		fontTick
	]);
	(0, import_react.useEffect)(() => {
		const frame = frameRef.current;
		const canvas = canvasRef.current;
		if (!frame || !canvas) return;
		const apply = () => {
			const rect = frame.getBoundingClientRect();
			if (rect.width < 2 || rect.height < 2) return;
			const scale = Math.min(rect.width / size.w, rect.height / size.h);
			canvas.style.width = `${Math.max(1, Math.floor(size.w * scale))}px`;
			canvas.style.height = `${Math.max(1, Math.floor(size.h * scale))}px`;
		};
		apply();
		const observer = new ResizeObserver(apply);
		observer.observe(frame);
		return () => observer.disconnect();
	}, [size.w, size.h]);
	(0, import_react.useEffect)(() => {
		function onKey(event) {
			if (event.target?.closest("input, textarea, button, a, [role='slider']")) return;
			const key = event.key;
			if (key !== "ArrowLeft" && key !== "ArrowRight" && key !== "ArrowUp" && key !== "ArrowDown") return;
			const id = selectedRef.current;
			const layer = layersRef.current.find((item) => item.id === id);
			if (!layer) return;
			event.preventDefault();
			const step = event.shiftKey ? .02 : .008;
			const x = layer.banner ? layer.x : clamp(layer.x + (key === "ArrowLeft" ? -step : key === "ArrowRight" ? step : 0), .06, .94);
			const y = clamp(layer.y + (key === "ArrowUp" ? -step : key === "ArrowDown" ? step : 0), .05, .95);
			setLayers((current) => current.map((item) => item.id === id ? {
				...item,
				x,
				y
			} : item));
		}
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, []);
	(0, import_react.useEffect)(() => {
		return () => {
			if (frameReq.current) cancelAnimationFrame(frameReq.current);
		};
	}, []);
	function applyPreset(id) {
		const next = presetById(id);
		const tone = upload ? null : starter.tone;
		setPresetId(next.id);
		setLayers(copyLayers(next.layers).map((layer) => tone ? {
			...layer,
			tone
		} : layer));
		setSelectedId(next.layers[0].id);
	}
	function chooseStarter(next) {
		if (upload) URL.revokeObjectURL(upload.url);
		setUpload(null);
		setStarterId(next.id);
		setLayers((current) => current.map((layer) => ({
			...layer,
			tone: next.tone
		})));
		setError(null);
	}
	function loadFile(file) {
		if (file.type && !file.type.startsWith("image/")) {
			setError("Use a JPG, PNG, or WebP.");
			return;
		}
		if (file.size > MAX_UPLOAD) {
			setError("That photo is larger than 15 MB.");
			return;
		}
		if (upload) URL.revokeObjectURL(upload.url);
		setUpload({
			url: URL.createObjectURL(file),
			name: file.name
		});
		setError(null);
	}
	function updateSelected(patch) {
		const id = selected.id;
		setLayers((current) => current.map((layer) => layer.id === id ? {
			...layer,
			...patch
		} : layer));
	}
	function onPointerDown(event) {
		const canvas = event.currentTarget;
		const point = pointFromEvent(canvas, event.clientX, event.clientY);
		const hit = hitAt(hitsRef.current, point.x, point.y);
		if (!hit) return;
		const layer = layersRef.current.find((item) => item.id === hit.id);
		if (!layer) return;
		event.preventDefault();
		canvas.setPointerCapture(event.pointerId);
		setSelectedId(layer.id);
		dragRef.current = {
			id: layer.id,
			pointerId: event.pointerId,
			startX: point.x,
			startY: point.y,
			origX: layer.x,
			origY: layer.y
		};
		canvas.style.cursor = "grabbing";
	}
	function onPointerMove(event) {
		const canvas = event.currentTarget;
		const point = pointFromEvent(canvas, event.clientX, event.clientY);
		const drag = dragRef.current;
		if (!drag || drag.pointerId !== event.pointerId) {
			canvas.style.cursor = hitAt(hitsRef.current, point.x, point.y) ? "grab" : "default";
			return;
		}
		const layer = layersRef.current.find((item) => item.id === drag.id);
		const { w, h } = sizeRef.current;
		const x = layer?.banner ? drag.origX : clamp(drag.origX + (point.x - drag.startX) / w, .06, .94);
		const y = clamp(drag.origY + (point.y - drag.startY) / h, .05, .95);
		pendingMove.current = {
			id: drag.id,
			x,
			y
		};
		if (frameReq.current) return;
		frameReq.current = requestAnimationFrame(() => {
			frameReq.current = 0;
			const next = pendingMove.current;
			if (!next) return;
			setLayers((current) => current.map((item) => item.id === next.id ? {
				...item,
				x: next.x,
				y: next.y
			} : item));
		});
	}
	function endDrag(event) {
		if (dragRef.current?.pointerId === event.pointerId) {
			dragRef.current = null;
			event.currentTarget.style.cursor = "grab";
		}
	}
	async function onDownload() {
		const canvas = canvasRef.current;
		if (!canvas || status !== "ready") return;
		setBusy(true);
		try {
			const blob = await new Promise((resolve) => canvas.toBlob(resolve, "image/png"));
			if (!blob) {
				setError("Couldn't export that image.");
				return;
			}
			const file = new File([blob], "punchline.png", { type: "image/png" });
			if (window.matchMedia("(pointer: coarse)").matches && navigator.canShare?.({ files: [file] })) try {
				await navigator.share({
					files: [file],
					title: "Punchline"
				});
				return;
			} catch (err) {
				if (err instanceof DOMException && err.name === "AbortError") return;
			}
			const url = URL.createObjectURL(blob);
			const link = document.createElement("a");
			link.href = url;
			link.download = "punchline.png";
			document.body.appendChild(link);
			link.click();
			link.remove();
			URL.revokeObjectURL(url);
			setSaved(true);
			window.setTimeout(() => setSaved(false), 1600);
		} finally {
			setBusy(false);
		}
	}
	const fontPx = Math.round(selected.fontSize * size.w);
	const outlinePx = Math.round(selected.fontSize * selected.outline * size.w);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-ink text-paper",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "sticky top-0 z-20 border-b border-line bg-ink",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "shell-pad mx-auto flex h-16 max-w-6xl items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-0 items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-9 shrink-0 place-items-center rounded-md bg-paper text-base font-semibold text-ink",
						children: "P"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "truncate text-lg leading-tight font-semibold tracking-tight",
							children: "Punchline"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "hidden text-sm leading-tight text-mute sm:block",
							children: "Meme studio"
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex shrink-0 items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "ghost",
						"aria-label": "Reset captions",
						onClick: () => applyPreset(presetId),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {
							className: "size-4",
							"aria-hidden": "true"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "hidden sm:inline",
							children: "Reset"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: onDownload,
						disabled: status !== "ready" || busy,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
							className: "size-4",
							"aria-hidden": "true"
						}), busy ? "Saving…" : saved ? "Saved" : "Download"]
					})]
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "shell-pad page-bottom mx-auto grid max-w-6xl gap-4 py-4 lg:grid-cols-[minmax(0,1fr)_22.5rem] lg:items-start lg:py-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "min-w-0 rounded-2xl bg-panel p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					ref: frameRef,
					className: "stage-frame relative overflow-hidden rounded-md bg-ink",
					onDragOver: (event) => {
						event.preventDefault();
						setDropping(true);
					},
					onDragLeave: (event) => {
						if (!event.currentTarget.contains(event.relatedTarget)) setDropping(false);
					},
					onDrop: (event) => {
						event.preventDefault();
						setDropping(false);
						const file = event.dataTransfer.files?.[0];
						if (file) loadFile(file);
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
							ref: canvasRef,
							id: "meme-canvas",
							width: size.w,
							height: size.h,
							"aria-label": "Meme preview",
							className: "absolute top-1/2 left-1/2 max-h-full max-w-full -translate-x-1/2 -translate-y-1/2 touch-none select-none",
							onPointerDown,
							onPointerMove,
							onPointerUp: endDrag,
							onPointerCancel: endDrag
						}),
						dropping ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "pointer-events-none absolute inset-0 grid place-items-center bg-ink/80",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium",
								children: "Drop photo"
							})
						}) : null,
						status === "loading" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "pointer-events-none absolute inset-x-0 bottom-3 text-center text-sm text-mute",
							children: "Loading photo…"
						}) : null
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-center text-sm text-mute",
					children: "Drag a caption to move it. Arrow keys nudge the selected line."
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "flex min-w-0 flex-col gap-5 rounded-2xl bg-panel p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-semibold",
							children: "Photo"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 truncate text-sm text-mute",
							children: photoLabel
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "quiet",
							className: "mt-3 w-full",
							onClick: () => fileRef.current?.click(),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, {
								className: "size-4",
								"aria-hidden": "true"
							}), "Upload photo"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							ref: fileRef,
							className: "sr-only",
							type: "file",
							accept: "image/jpeg,image/png,image/webp,image/gif",
							onChange: (event) => {
								const file = event.target.files?.[0];
								event.target.value = "";
								if (file) loadFile(file);
							}
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-scroll mt-3",
							children: STARTERS.map((item) => {
								const active = !upload && item.id === starterId;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-label": item.name,
									"aria-pressed": active,
									onClick: () => chooseStarter(item),
									className: cn("relative size-16 shrink-0 overflow-hidden rounded-md border", active ? "border-paper" : "border-line"),
									children: item.kind === "fill" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block size-full",
										style: { background: item.color }
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: item.src,
										alt: "",
										className: "size-full object-cover",
										draggable: false
									})
								}, item.id);
							})
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "border-t border-line pt-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-sm font-semibold",
								children: "Layout"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-mute",
								children: preset.detail
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-scroll mt-3",
								role: "group",
								"aria-label": "Meme layouts",
								children: PRESETS.map((item) => {
									const active = item.id === presetId;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"aria-pressed": active,
										onClick: () => applyPreset(item.id),
										className: cn("h-11 shrink-0 rounded-full px-4 text-sm font-medium", active ? "bg-paper text-ink" : "bg-field text-paper"),
										children: item.name
									}, item.id);
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "border-t border-line pt-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-semibold",
							children: "Captions"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 flex flex-col gap-3",
							children: layers.map((layer) => {
								const active = layer.id === selected.id;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: cn("text-sm font-medium", active ? "text-paper" : "text-mute"),
										children: layer.label
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
										value: layer.text,
										rows: 2,
										"aria-label": `${layer.label} caption`,
										placeholder: "Type a caption",
										onFocus: () => setSelectedId(layer.id),
										onChange: (event) => {
											const text = event.target.value;
											setSelectedId(layer.id);
											setLayers((current) => current.map((item) => item.id === layer.id ? {
												...item,
												text
											} : item));
										},
										className: cn("mt-1 w-full resize-none rounded-md border bg-ink px-3 py-3 text-base text-paper", "placeholder:text-faint focus-visible:ring-2 focus-visible:ring-paper/40 focus-visible:outline-none", active ? "border-paper" : "border-line")
									})]
								}, layer.id);
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "border-t border-line pt-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-baseline justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-sm font-semibold",
									children: "Style"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm text-mute",
									children: ["Editing ", selected.label.toLowerCase()]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mb-1 flex items-center justify-between text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-mute",
										id: "font-size-label",
										children: "Font size"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "tabular-nums",
										children: fontPx
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
									label: "Font size",
									min: .036,
									max: .16,
									step: .001,
									value: selected.fontSize,
									onChange: (fontSize) => updateSelected({ fontSize })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mb-1 flex items-center justify-between text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-mute",
										id: "outline-label",
										children: "Outline"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "tabular-nums",
										children: outlinePx
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
									label: "Outline",
									min: 0,
									max: .42,
									step: .005,
									value: selected.outline,
									onChange: (outline) => updateSelected({ outline })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-4 grid grid-cols-2 gap-2",
								role: "group",
								"aria-label": "Text color",
								children: [["light", "White"], ["dark", "Black"]].map(([tone, name]) => {
									const active = selected.tone === tone;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										"aria-pressed": active,
										onClick: () => updateSelected({ tone }),
										className: cn("flex h-11 items-center justify-center gap-2 rounded-md border text-sm font-medium", active ? "border-paper bg-field" : "border-line bg-transparent text-paper"),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: cn("size-4 rounded-full border", tone === "light" ? "border-line bg-paper" : "border-line-strong bg-ink"),
											"aria-hidden": "true"
										}), name]
									}, tone);
								})
							})
						]
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						role: "alert",
						className: "text-sm text-paper",
						children: error
					}) : null
				]
			})]
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MemeStudio, {});
}
//#endregion
export { Home as component };
