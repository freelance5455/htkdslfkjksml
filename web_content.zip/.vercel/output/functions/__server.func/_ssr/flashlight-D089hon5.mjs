import { i as __toESM } from "../_runtime.mjs";
import { q as require_react, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as FlashlightOff, s as Flashlight } from "../_libs/lucide-react.mjs";
import { n as ScreenBody, t as AppShell } from "./app-shell-BNnfZJ-W.mjs";
import { i as ScreenHeader } from "./screen-header-3v0iR4cd.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/flashlight-D089hon5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function FlashlightPage() {
	const [mode, setMode] = (0, import_react.useState)("off");
	const [message, setMessage] = (0, import_react.useState)(null);
	const [hasLed, setHasLed] = (0, import_react.useState)(null);
	const trackRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		return () => {
			stopTrack();
		};
	}, []);
	function stopTrack() {
		const track = trackRef.current;
		if (!track) return;
		try {
			track.applyConstraints({ advanced: [{ torch: false }] });
		} catch {}
		track.stop();
		trackRef.current = null;
	}
	async function tryLed(on) {
		if (!on) {
			stopTrack();
			return true;
		}
		if (!navigator.mediaDevices?.getUserMedia) {
			setHasLed(false);
			return false;
		}
		try {
			const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: "environment" } } });
			const track = stream.getVideoTracks()[0];
			if (!track) {
				stream.getTracks().forEach((t) => t.stop());
				setHasLed(false);
				return false;
			}
			if (!track.getCapabilities().torch) {
				track.stop();
				setHasLed(false);
				return false;
			}
			await track.applyConstraints({ advanced: [{ torch: true }] });
			trackRef.current = track;
			setHasLed(true);
			return true;
		} catch {
			setHasLed(false);
			return false;
		}
	}
	async function toggleLed() {
		if (mode === "led") {
			await tryLed(false);
			setMode("off");
			setMessage(null);
			return;
		}
		if (await tryLed(true)) {
			setMode("led");
			setMessage("LED torch is on");
		} else setMessage("No LED torch on this device. Use screen light instead.");
	}
	function toggleScreen() {
		if (mode === "led") tryLed(false);
		setMode((prev) => prev === "screen" ? "off" : "screen");
		setMessage(null);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ScreenBody, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScreenHeader, {
			title: "Flashlight",
			subtitle: "Uses the camera LED when available. Safe if this device has no flash."
		}),
		mode === "screen" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: toggleScreen,
			className: "fixed inset-0 z-40 bg-fg",
			"aria-label": "Turn screen light off"
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "rounded-card bg-surface px-[18px] py-8 text-center shadow-[var(--shadow-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => void toggleLed(),
					className: "mx-auto flex size-40 items-center justify-center rounded-full transition-colors duration-200 ease-out active:scale-[0.96]",
					style: { background: mode !== "off" && mode === "led" ? "rgba(245, 193, 74, 0.22)" : "var(--color-elevated)" },
					"aria-pressed": mode === "led",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "flex size-32 items-center justify-center rounded-full",
						style: { background: mode === "led" ? "var(--color-warning)" : "var(--color-elevated)" },
						children: mode === "led" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flashlight, { className: "size-14 text-fg" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FlashlightOff, { className: "size-14 text-muted" })
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-5 text-xl font-semibold text-fg",
					children: mode === "led" ? "Flashlight is ON" : mode === "screen" ? "Screen light is ON" : "Flashlight is OFF"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: hasLed === false ? "This device has no camera flash" : "Tap the button to toggle the LED"
				}),
				message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-primary",
					children: message
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: toggleScreen,
					className: "mt-6 inline-flex h-12 min-w-44 items-center justify-center rounded-2xl bg-elevated px-5 text-sm font-semibold text-fg transition-transform duration-150 ease-out active:scale-[0.96]",
					children: mode === "screen" ? "Turn screen light off" : "Use screen light"
				})
			]
		})
	] }) });
}
//#endregion
export { FlashlightPage as component };
