import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Settings } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-D8tQpLPy.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var DIGITS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
function clampBase(value) {
	if (!Number.isInteger(value)) return 2;
	return Math.min(36, Math.max(2, value));
}
/** Integer written in `base` (2–36). Zero is "0"; negatives keep a leading minus. */
function toBase(value, base) {
	const radix = clampBase(base);
	if (!Number.isFinite(value)) return "0";
	const n = Math.trunc(value);
	if (n === 0) return "0";
	const negative = n < 0;
	let rest = Math.abs(n);
	let out = "";
	while (rest > 0) {
		out = DIGITS[rest % radix] + out;
		rest = Math.floor(rest / radix);
	}
	return negative ? `-${out}` : out;
}
/** Parse a base-N numeral. Returns null when a digit does not belong to that base. */
function fromBase(text, base) {
	if (!Number.isInteger(base) || base < 2 || base > 36) return null;
	const raw = text.trim().toUpperCase();
	if (!raw) return null;
	const negative = raw.startsWith("-");
	const body = negative ? raw.slice(1) : raw;
	if (!body) return null;
	let value = 0;
	for (const char of body) {
		const digit = DIGITS.indexOf(char);
		if (digit < 0 || digit >= base) return null;
		value = value * base + digit;
	}
	return negative ? -value : value;
}
var STORAGE_KEY = "radix-counter-v2";
var LEGACY_KEY = "radix-counter-v1";
var DEFAULT_COLOR = "#fffdf8";
function seedItems() {
	return [
		"A",
		"B",
		"C",
		"D",
		"E"
	].map((name, index) => ({
		id: `seed-${index}`,
		name,
		value: 0,
		base: 6,
		step: 1,
		color: DEFAULT_COLOR
	}));
}
function nextName(items) {
	const used = new Set(items.map((item) => item.name));
	for (let i = 0; i < 26; i += 1) {
		const letter = String.fromCharCode(65 + i);
		if (!used.has(letter)) return letter;
	}
	let n = 1;
	while (used.has(`对象${n}`)) n += 1;
	return `对象${n}`;
}
function cleanColor(value) {
	return typeof value === "string" && /^#[0-9a-fA-F]{6}$/.test(value) ? value : DEFAULT_COLOR;
}
function cleanItem(row, fallbackBase) {
	if (typeof row.id !== "string" || typeof row.name !== "string") return null;
	if (typeof row.value !== "number" || !Number.isFinite(row.value)) return null;
	const name = row.name.trim().slice(0, 16);
	if (!name) return null;
	const base = Number.isInteger(row.base) ? row.base : fallbackBase;
	if (base < 2 || base > 36) return null;
	const step = Number.isInteger(row.step) && row.step >= 1 ? row.step : 1;
	return {
		id: row.id,
		name,
		value: Math.trunc(row.value),
		base,
		step,
		color: cleanColor(row.color)
	};
}
function readItems() {
	try {
		const raw = localStorage.getItem(STORAGE_KEY) ?? localStorage.getItem(LEGACY_KEY);
		if (!raw) return null;
		const data = JSON.parse(raw);
		if (!Array.isArray(data.items)) return null;
		const fallback = Number.isInteger(data.base) ? data.base : 6;
		return data.items.flatMap((item) => {
			const row = cleanItem(item ?? {}, fallback);
			return row ? [row] : [];
		});
	} catch {
		return null;
	}
}
function textOn(color) {
	const hex = color.slice(1);
	const r = Number.parseInt(hex.slice(0, 2), 16);
	const g = Number.parseInt(hex.slice(2, 4), 16);
	const b = Number.parseInt(hex.slice(4, 6), 16);
	return r * 299 + g * 587 + b * 114 > 15e4 ? "#211c16" : "#fff7f3";
}
function RadixCounter() {
	const [items, setItems] = (0, import_react.useState)(seedItems);
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	const [draftName, setDraftName] = (0, import_react.useState)("");
	const [editingId, setEditingId] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const saved = readItems();
		if (saved) setItems(saved);
		setHydrated(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		localStorage.setItem(STORAGE_KEY, JSON.stringify({ items }));
	}, [items, hydrated]);
	const editing = items.find((item) => item.id === editingId) ?? null;
	function stepItem(id, direction) {
		setItems((prev) => prev.map((item) => item.id === id ? {
			...item,
			value: item.value + direction * item.step
		} : item));
	}
	function addItem() {
		const name = draftName.trim().slice(0, 16) || nextName(items);
		setItems((prev) => [...prev, {
			id: crypto.randomUUID(),
			name,
			value: 0,
			base: 6,
			step: 1,
			color: DEFAULT_COLOR
		}]);
		setDraftName("");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto min-h-screen w-full max-w-lg px-4 py-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "/radix-counter.html",
				download: "index.html",
				className: "mb-4 inline-block text-xl font-semibold text-save underline",
				children: "下载 index.html"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mb-6 text-2xl font-semibold tracking-tight",
				children: "进制计数器"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-2",
				children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CounterRow, {
					item,
					onStep: (direction) => stepItem(item.id, direction),
					onOpen: () => setEditingId(item.id)
				}) }, item.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-4 flex gap-2",
				onSubmit: (event) => {
					event.preventDefault();
					addItem();
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: draftName,
					onChange: (event) => setDraftName(event.target.value.slice(0, 16)),
					placeholder: "新对象",
					"aria-label": "新对象名称",
					className: "h-12 min-w-0 flex-1 rounded-xl border border-line bg-surface-2 px-3 outline-none placeholder:text-muted focus:border-accent"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "h-12 shrink-0 rounded-xl bg-ink px-4 font-medium text-surface",
					children: "添加"
				})]
			}),
			editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemSettings, {
				item: editing,
				onClose: () => setEditingId(null),
				onSave: (next) => {
					setItems((prev) => prev.map((item) => item.id === editing.id ? {
						...item,
						...next
					} : item));
					setEditingId(null);
				},
				onDelete: () => {
					setItems((prev) => prev.filter((item) => item.id !== editing.id));
					setEditingId(null);
				}
			}) : null
		]
	});
}
function CounterRow({ item, onStep, onOpen }) {
	const written = toBase(item.value, item.base);
	const ink = textOn(item.color);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "flex items-center gap-2 rounded-card border border-line px-3 py-2",
		style: {
			backgroundColor: item.color,
			color: ink
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0 flex-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "truncate text-lg font-semibold",
				children: item.name
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs opacity-70",
				children: [item.base, "进制"]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex shrink-0 items-center gap-1.5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StepButton, {
					label: `${item.name} 减 ${item.step}`,
					onStep: () => onStep(-1),
					children: "−"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "digit-in inline-block min-w-8 text-center font-mono text-2xl tabular-nums",
					children: written
				}, written),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StepButton, {
					label: `${item.name} 加 ${item.step}`,
					onStep: () => onStep(1),
					tone: "accent",
					children: "+"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": `${item.name} 设置`,
					onClick: onOpen,
					className: "inline-flex size-11 items-center justify-center rounded-xl border border-line bg-surface text-ink",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "size-5" })
				})
			]
		})]
	});
}
function ItemSettings({ item, onClose, onSave, onDelete }) {
	const [name, setName] = (0, import_react.useState)(item.name);
	const [base, setBase] = (0, import_react.useState)(String(item.base));
	const [color, setColor] = (0, import_react.useState)(item.color);
	const [initial, setInitial] = (0, import_react.useState)(toBase(item.value, item.base));
	const [step, setStep] = (0, import_react.useState)(String(item.step));
	const [error, setError] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		function onKey(event) {
			if (event.key === "Escape") onClose();
		}
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [onClose]);
	function save() {
		const radix = Number(base);
		if (!Number.isInteger(radix) || radix < 2 || radix > 36) {
			setError(`进制请填 2 到 36 的整数`);
			return;
		}
		const value = fromBase(initial, radix);
		if (value === null) {
			setError("初始数值里有这个进制用不了的数码");
			return;
		}
		const inc = Number(step);
		if (!Number.isInteger(inc) || inc < 1) {
			setError("增量请填大于 0 的整数");
			return;
		}
		onSave({
			name: name.trim().slice(0, 16) || "未命名",
			base: radix,
			color: cleanColor(color),
			value,
			step: inc
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-20 flex items-end justify-center bg-ink/40 p-4 sm:items-center",
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			role: "dialog",
			"aria-modal": "true",
			"aria-label": `${item.name} 设置`,
			className: "w-full max-w-md rounded-card bg-surface-2 p-5 shadow-sm",
			onClick: (event) => event.stopPropagation(),
			onSubmit: (event) => {
				event.preventDefault();
				save();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-semibold",
					children: "设置"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-col gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "名称",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: name,
								"aria-label": "名称",
								onChange: (event) => setName(event.target.value.slice(0, 16)),
								className: "h-12 w-full rounded-xl border border-line bg-surface px-3 outline-none focus:border-accent"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "进制",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								inputMode: "numeric",
								"aria-label": "进制",
								value: base,
								onChange: (event) => setBase(event.target.value.replace(/[^\d]/g, "").slice(0, 2)),
								className: "h-12 w-full rounded-xl border border-line bg-surface px-3 font-mono text-lg outline-none focus:border-accent"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "颜色",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "color",
								"aria-label": "颜色",
								value: color,
								onChange: (event) => setColor(event.target.value),
								className: "h-12 w-full cursor-pointer rounded-xl border border-line bg-surface"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "初始数值",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								"aria-label": "初始数值",
								value: initial,
								onChange: (event) => setInitial(event.target.value.toUpperCase().slice(0, 16)),
								className: "h-12 w-full rounded-xl border border-line bg-surface px-3 font-mono text-lg outline-none focus:border-accent"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "增量",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								inputMode: "numeric",
								"aria-label": "增量",
								value: step,
								onChange: (event) => setStep(event.target.value.replace(/[^\d]/g, "").slice(0, 6)),
								className: "h-12 w-full rounded-xl border border-line bg-surface px-3 font-mono text-lg outline-none focus:border-accent"
							})
						})
					]
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-accent",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: "h-12 rounded-xl bg-ink font-medium text-surface",
						children: "保存"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onDelete,
						className: "h-12 rounded-xl border border-line font-medium",
						children: "删除"
					})]
				})
			]
		})
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-sm text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-1",
			children
		})]
	});
}
function StepButton({ label, onStep, children, tone = "ghost" }) {
	const onStepRef = (0, import_react.useRef)(onStep);
	onStepRef.current = onStep;
	const delayRef = (0, import_react.useRef)(null);
	const repeatRef = (0, import_react.useRef)(null);
	function stop() {
		if (delayRef.current) clearTimeout(delayRef.current);
		if (repeatRef.current) clearInterval(repeatRef.current);
		delayRef.current = null;
		repeatRef.current = null;
	}
	(0, import_react.useEffect)(() => stop, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-label": label,
		className: `inline-flex size-11 select-none items-center justify-center rounded-xl text-2xl leading-none touch-manipulation ${tone === "accent" ? "bg-accent text-accent-ink" : "border border-line bg-surface text-ink"}`,
		onContextMenu: (event) => event.preventDefault(),
		onPointerDown: (event) => {
			if (event.button !== 0) return;
			onStepRef.current();
			try {
				event.currentTarget.setPointerCapture(event.pointerId);
			} catch {}
			stop();
			delayRef.current = setTimeout(() => {
				repeatRef.current = setInterval(() => onStepRef.current(), 70);
			}, 360);
		},
		onPointerUp: stop,
		onPointerCancel: stop,
		children
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadixCounter, {});
}
//#endregion
export { Home as component };
