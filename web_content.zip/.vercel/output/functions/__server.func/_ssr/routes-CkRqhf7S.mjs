import { i as __toESM } from "../_runtime.mjs";
import { a as AlertDialogDescription, c as AlertDialogTitle, d as require_jsx_runtime, f as require_react, i as AlertDialogContent, l as AlertDialogTrigger, n as AlertDialogAction, o as AlertDialogOverlay, r as AlertDialogCancel, s as AlertDialogPortal, t as AlertDialog } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { A as EyeOff, B as CalendarClock, C as KeyRound, D as Fingerprint, E as HardDrive, F as Clock, H as Beaker, I as ChevronRight, L as ChevronLeft, M as Dices, N as Delete, O as FileText, P as Copy, R as CaseSensitive, S as LayoutGrid, T as Hourglass, U as ArrowLeftRight, V as Calculator, W as AlignJustify, _ as QrCode, a as Star, b as ListX, c as Shield, d as Search, f as ScanLine, g as Quote, h as RefreshCw, i as Thermometer, j as Download, k as Eye, l as Share2, m as Ruler, o as Space, p as Scale, r as Timer, s as Shuffle, t as Type, u as Settings, v as Percent, w as House, x as Link2, y as Palette, z as CalendarDays } from "../_libs/lucide-react.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CkRqhf7S.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var APP_VERSION = "1.0.0";
var APP_NAME = "XJOX Tools";
var CATEGORIES = [
	{
		id: "teks",
		name: "Teks",
		blurb: "Hitung, ubah, dan rapikan tulisan"
	},
	{
		id: "generator",
		name: "Generator",
		blurb: "UUID, sandi, angka, dan warna"
	},
	{
		id: "hitung",
		name: "Hitung",
		blurb: "Kalkulator, persen, dan satuan"
	},
	{
		id: "waktu",
		name: "Waktu",
		blurb: "Jam, timer, dan tanggal"
	},
	{
		id: "kode",
		name: "QR & tautan",
		blurb: "Kode QR dan pemeriksaan URL"
	},
	{
		id: "berkas",
		name: "Berkas",
		blurb: "Info berkas yang Anda pilih"
	}
];
var TOOLS = [
	{
		id: "text-count",
		category: "teks",
		name: "Penghitung teks",
		blurb: "Kata, karakter, kalimat, dan paragraf",
		icon: "type",
		keywords: "word count huruf"
	},
	{
		id: "text-case",
		category: "teks",
		name: "Ubah huruf",
		blurb: "Besar, kecil, judul, atau kalimat",
		icon: "case",
		keywords: "uppercase lowercase kapital"
	},
	{
		id: "text-space",
		category: "teks",
		name: "Rapikan spasi",
		blurb: "Hapus spasi dan tab berlebih",
		icon: "space",
		keywords: "trim whitespace"
	},
	{
		id: "text-blank",
		category: "teks",
		name: "Hapus baris kosong",
		blurb: "Buang baris yang hanya berisi spasi",
		icon: "blank",
		keywords: "empty line"
	},
	{
		id: "text-shuffle",
		category: "teks",
		name: "Acak teks",
		blurb: "Acak urutan kata atau baris",
		icon: "shuffle",
		keywords: "random shuffle"
	},
	{
		id: "text-reverse",
		category: "teks",
		name: "Balik teks",
		blurb: "Balik karakter, kata, atau baris",
		icon: "reverse",
		keywords: "reverse terbalik"
	},
	{
		id: "text-dedupe",
		category: "teks",
		name: "Hapus baris ganda",
		blurb: "Sisakan satu salinan tiap baris",
		icon: "dedupe",
		keywords: "duplicate unik"
	},
	{
		id: "gen-uuid",
		category: "generator",
		name: "UUID",
		blurb: "Identitas unik versi 4",
		icon: "uuid",
		keywords: "guid random id"
	},
	{
		id: "gen-password",
		category: "generator",
		name: "Kata sandi",
		blurb: "Sandi acak kriptografis, tidak disimpan",
		icon: "password",
		keywords: "password sandi"
	},
	{
		id: "gen-number",
		category: "generator",
		name: "Angka acak",
		blurb: "Bilangan dalam rentang yang Anda tentukan",
		icon: "number",
		keywords: "random number dadu"
	},
	{
		id: "gen-color",
		category: "generator",
		name: "Warna",
		blurb: "Kode HEX dan RGB",
		icon: "color",
		keywords: "hex rgb palet"
	},
	{
		id: "gen-lorem",
		category: "generator",
		name: "Teks pengisi",
		blurb: "Paragraf placeholder Indonesia atau lorem",
		icon: "lorem",
		keywords: "lorem ipsum dummy"
	},
	{
		id: "calc-basic",
		category: "hitung",
		name: "Kalkulator",
		blurb: "Tambah, kurang, kali, bagi, dan kurung",
		icon: "calc",
		keywords: "math calculator"
	},
	{
		id: "calc-length",
		category: "hitung",
		name: "Panjang",
		blurb: "Milimeter sampai mil",
		icon: "length",
		keywords: "meter km inci konversi"
	},
	{
		id: "calc-weight",
		category: "hitung",
		name: "Berat",
		blurb: "Gram, kilogram, ons, dan pon",
		icon: "weight",
		keywords: "kg gram lb"
	},
	{
		id: "calc-temp",
		category: "hitung",
		name: "Suhu",
		blurb: "Celsius, Fahrenheit, dan Kelvin",
		icon: "temp",
		keywords: "celcius fahrenheit"
	},
	{
		id: "calc-volume",
		category: "hitung",
		name: "Volume",
		blurb: "Liter, mililiter, dan satuan AS",
		icon: "volume",
		keywords: "liter galon cangkir"
	},
	{
		id: "calc-storage",
		category: "hitung",
		name: "Penyimpanan",
		blurb: "Biner 1024 atau desimal 1000",
		icon: "storage",
		keywords: "mb gb kb byte"
	},
	{
		id: "calc-percent",
		category: "hitung",
		name: "Persentase",
		blurb: "Bagian, porsi, dan perubahan",
		icon: "percent",
		keywords: "persen diskon"
	},
	{
		id: "time-clock",
		category: "waktu",
		name: "Jam digital",
		blurb: "Waktu perangkat dan zona waktu",
		icon: "clock",
		keywords: "jam clock"
	},
	{
		id: "time-stopwatch",
		category: "waktu",
		name: "Stopwatch",
		blurb: "Hitung maju dengan putaran",
		icon: "stopwatch",
		keywords: "stopwatch lap"
	},
	{
		id: "time-timer",
		category: "waktu",
		name: "Timer",
		blurb: "Hitung mundur dengan alarm",
		icon: "timer",
		keywords: "timer alarm pengingat"
	},
	{
		id: "time-diff",
		category: "waktu",
		name: "Selisih tanggal",
		blurb: "Jarak dua tanggal kalender",
		icon: "diff",
		keywords: "date difference"
	},
	{
		id: "time-until",
		category: "waktu",
		name: "Menuju tanggal",
		blurb: "Sisa hari dan jam menuju suatu saat",
		icon: "until",
		keywords: "countdown hari"
	},
	{
		id: "qr-make",
		category: "kode",
		name: "Buat QR",
		blurb: "Kode dari teks atau URL",
		icon: "qr",
		keywords: "qr code buat"
	},
	{
		id: "qr-scan",
		category: "kode",
		name: "Pindai QR",
		blurb: "Baca kode lewat kamera",
		icon: "scan",
		keywords: "scan kamera barcode"
	},
	{
		id: "url-check",
		category: "kode",
		name: "Periksa URL",
		blurb: "Validasi tautan sebelum dibuka",
		icon: "link",
		keywords: "url link tautan"
	},
	{
		id: "file-info",
		category: "berkas",
		name: "Info berkas",
		blurb: "Nama, jenis, dan ukuran berkas pilihan",
		icon: "file",
		keywords: "file ukuran dokumen"
	}
];
var DEFAULT_QUICK = [
	"text-count",
	"gen-password",
	"calc-basic",
	"qr-make"
];
var toolMap = new Map(TOOLS.map((tool) => [tool.id, tool]));
function getTool(id) {
	return toolMap.get(id);
}
function searchTools(query, category) {
	const q = query.trim().toLocaleLowerCase("id");
	return TOOLS.filter((tool) => {
		if (category && category !== "all" && tool.category !== category) return false;
		if (!q) return true;
		const cat = CATEGORIES.find((item) => item.id === tool.category);
		return `${tool.name} ${tool.blurb} ${tool.keywords} ${cat?.name ?? ""}`.toLocaleLowerCase("id").includes(q);
	});
}
function knownId(id) {
	return Boolean(getTool(id));
}
var usePrefs = create()(persist((set) => ({
	theme: "system",
	displayName: "",
	onboarded: false,
	favorites: [],
	recents: [],
	usage: {},
	calcHistory: [],
	recentFiles: [],
	setTheme: (theme) => set({ theme }),
	setDisplayName: (name) => set({ displayName: name.replace(/\s+/g, " ").slice(0, 40) }),
	finishOnboarding: () => set({ onboarded: true }),
	toggleFavorite: (id) => set((state) => ({ favorites: state.favorites.includes(id) ? state.favorites.filter((item) => item !== id) : [...state.favorites, id] })),
	touch: (id) => set((state) => ({
		usage: {
			...state.usage,
			[id]: (state.usage[id] ?? 0) + 1
		},
		recents: [{
			id,
			at: Date.now()
		}, ...state.recents.filter((item) => item.id !== id)].slice(0, 12)
	})),
	addCalcHistory: (item) => set((state) => ({ calcHistory: [item, ...state.calcHistory].slice(0, 30) })),
	clearCalcHistory: () => set({ calcHistory: [] }),
	clearUsage: () => set({
		recents: [],
		usage: {}
	}),
	addRecentFile: (file) => set((state) => ({ recentFiles: [file, ...state.recentFiles.filter((item) => !(item.name === file.name && item.size === file.size && item.lastModified === file.lastModified))].slice(0, 20) })),
	clearRecentFiles: () => set({ recentFiles: [] })
}), {
	name: "xjox-prefs",
	version: 1,
	partialize: (state) => ({
		theme: state.theme,
		displayName: state.displayName,
		onboarded: state.onboarded,
		favorites: state.favorites,
		recents: state.recents,
		usage: state.usage,
		calcHistory: state.calcHistory,
		recentFiles: state.recentFiles
	}),
	merge: (persisted, current) => {
		const saved = persisted ?? {};
		const favorites = (saved.favorites ?? []).filter((id) => knownId(id));
		const recents = (saved.recents ?? []).filter((item) => knownId(item.id) && Number.isFinite(item.at));
		const usage = {};
		for (const [key, value] of Object.entries(saved.usage ?? {})) if (knownId(key) && typeof value === "number" && Number.isFinite(value)) usage[key] = value;
		return {
			...current,
			...saved,
			favorites,
			recents,
			usage,
			calcHistory: Array.isArray(saved.calcHistory) ? saved.calcHistory.slice(0, 30) : [],
			recentFiles: Array.isArray(saved.recentFiles) ? saved.recentFiles.slice(0, 20) : [],
			displayName: typeof saved.displayName === "string" ? saved.displayName.slice(0, 40) : "",
			theme: saved.theme === "light" || saved.theme === "dark" || saved.theme === "system" ? saved.theme : "system",
			onboarded: Boolean(saved.onboarded)
		};
	}
}));
var useTimer = create((set) => ({
	endAt: null,
	totalMs: 0,
	running: false,
	fired: false,
	start: (ms) => set({
		endAt: Date.now() + ms,
		totalMs: ms,
		running: true,
		fired: false
	}),
	stop: () => set({
		running: false,
		endAt: null,
		fired: false,
		totalMs: 0
	}),
	acknowledge: () => set({
		fired: false,
		running: false,
		endAt: null
	})
}));
var sessionFiles = /* @__PURE__ */ new Map();
function rememberFile(id, file) {
	sessionFiles.set(id, file);
}
function recallFile(id) {
	return sessionFiles.get(id);
}
var ICONS = {
	type: Type,
	case: CaseSensitive,
	space: Space,
	blank: AlignJustify,
	shuffle: Shuffle,
	reverse: ArrowLeftRight,
	dedupe: ListX,
	uuid: Fingerprint,
	password: KeyRound,
	number: Dices,
	color: Palette,
	lorem: Quote,
	calc: Calculator,
	length: Ruler,
	weight: Scale,
	temp: Thermometer,
	volume: Beaker,
	storage: HardDrive,
	percent: Percent,
	clock: Clock,
	stopwatch: Timer,
	timer: Hourglass,
	diff: CalendarDays,
	until: CalendarClock,
	qr: QrCode,
	scan: ScanLine,
	link: Link2,
	file: FileText
};
function ToolIcon({ name, className }) {
	const Icon = ICONS[name];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
		className,
		strokeWidth: 1.75,
		"aria-hidden": "true"
	});
}
var NavContext = (0, import_react.createContext)(null);
function NavProvider({ value, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavContext.Provider, {
		value,
		children
	});
}
function useNav() {
	const nav = (0, import_react.useContext)(NavContext);
	if (!nav) throw new Error("Navigasi belum siap.");
	return nav;
}
async function copyText(text) {
	try {
		if (navigator.clipboard?.writeText) {
			await navigator.clipboard.writeText(text);
			return true;
		}
	} catch {}
	try {
		const area = document.createElement("textarea");
		area.value = text;
		area.setAttribute("readonly", "");
		area.style.position = "fixed";
		area.style.left = "-9999px";
		document.body.appendChild(area);
		area.select();
		const ok = document.execCommand("copy");
		area.remove();
		return ok;
	} catch {
		return false;
	}
}
async function shareText(title, text) {
	if (typeof navigator.share === "function") try {
		await navigator.share({
			title,
			text
		});
		return "shared";
	} catch (error) {
		if (error instanceof DOMException && error.name === "AbortError") return "cancelled";
	}
	return await copyText(text) ? "copied" : "failed";
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var ToastContext = (0, import_react.createContext)(() => {});
function useToast() {
	return (0, import_react.useContext)(ToastContext);
}
function ToastProvider({ children }) {
	const [message, setMessage] = (0, import_react.useState)(null);
	const timer = (0, import_react.useRef)(0);
	const push = (0, import_react.useCallback)((next) => {
		setMessage(next);
		window.clearTimeout(timer.current);
		timer.current = window.setTimeout(() => setMessage(null), 2400);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToastContext.Provider, {
		value: push,
		children: [children, message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pointer-events-none fixed inset-x-0 bottom-24 z-50 flex justify-center px-4 md:bottom-8",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "status",
				className: "rounded-control bg-ink px-4 py-3 text-sm font-medium text-canvas",
				children: message
			})
		}) : null]
	});
}
var buttonStyles = {
	primary: "bg-accent text-accent-ink",
	secondary: "bg-sunken text-ink",
	ghost: "bg-transparent text-ink",
	danger: "bg-danger text-danger-ink"
};
function Button({ variant = "primary", className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		...props,
		className: cn("inline-flex h-12 items-center justify-center gap-2 rounded-control px-4 text-sm font-semibold disabled:opacity-45 [&_svg]:size-4", buttonStyles[variant], className),
		children
	});
}
function IconButton({ label, pressed, className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-label": label,
		"aria-pressed": pressed,
		...props,
		className: cn("grid size-11 shrink-0 place-items-center rounded-control text-ink hover:bg-sunken disabled:opacity-40 [&_svg]:size-5", className),
		children
	});
}
function Logo({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("grid place-items-center rounded-control bg-accent text-accent-ink", className),
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
			viewBox: "0 0 32 32",
			className: "size-[54%]",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M8 8.5L24 23.5M24 8.5L8 23.5",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "3",
				strokeLinecap: "round"
			})
		})
	});
}
function Card({ children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: cn("rounded-card border border-line bg-card p-4", className),
		children
	});
}
function Field({ label, hint, error, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mb-1.5 block text-sm font-semibold text-ink",
				children: label
			}),
			children,
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-1.5 block text-sm text-danger",
				children: error
			}) : null,
			!error && hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-1.5 block text-sm text-mute",
				children: hint
			}) : null
		]
	});
}
var controlClass = "h-12 w-full rounded-control border border-line bg-card px-3 text-base text-ink outline-none focus-visible:border-accent";
function TextInput(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		...props,
		className: cn(controlClass, props.className)
	});
}
function TextArea(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		...props,
		className: cn("min-h-36 w-full resize-y rounded-control border border-line bg-card p-3 text-base leading-relaxed text-ink outline-none focus-visible:border-accent", props.className)
	});
}
function SelectInput(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
		...props,
		className: cn(controlClass, props.className)
	});
}
function SearchField({ value, onChange, label = "Cari alat" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "relative block",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "sr-only",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
				className: "pointer-events-none absolute top-1/2 left-3 size-5 -translate-y-1/2 text-mute",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value,
				onChange: (event) => onChange(event.target.value),
				placeholder: "Cari alat…",
				className: cn(controlClass, "pl-11"),
				type: "search",
				enterKeyHint: "search"
			})
		]
	});
}
function Segmented({ label, value, onChange, options }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		id: `${label}-seg`,
		className: "mb-1.5 text-sm font-semibold text-ink",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		role: "radiogroup",
		"aria-labelledby": `${label}-seg`,
		className: "flex gap-1 rounded-control bg-sunken p-1",
		children: options.map((option) => {
			const active = option.id === value;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				role: "radio",
				"aria-checked": active,
				onClick: () => onChange(option.id),
				className: cn("h-11 min-w-0 flex-1 rounded-control px-2 text-sm font-semibold", active ? "bg-card text-ink" : "text-mute"),
				children: option.label
			}, option.id);
		})
	})] });
}
function CheckRow({ label, checked, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "flex min-h-12 items-center gap-3 rounded-control border border-line bg-card px-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type: "checkbox",
			checked,
			onChange: (event) => onChange(event.target.checked),
			className: "size-5 accent-accent"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-sm font-medium",
			children: label
		})]
	});
}
function EmptyState({ title, body, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-card border border-dashed border-line px-4 py-8 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-base font-bold",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mx-auto mt-1 max-w-sm text-sm text-mute",
				children: body
			}),
			action ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children: action
			}) : null
		]
	});
}
function Output({ text, placeholder }) {
	if (!text) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "rounded-control border border-dashed border-line px-3 py-4 text-sm text-mute",
		children: placeholder
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
		className: "max-h-80 overflow-auto whitespace-pre-wrap break-words rounded-control bg-sunken p-3 font-mono text-sm leading-relaxed text-ink",
		children: text
	});
}
function ActionRow({ text, title = APP_NAME }) {
	const toast = useToast();
	const disabled = text.trim().length === 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid grid-cols-2 gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			disabled,
			onClick: () => {
				copyText(text).then((ok) => toast(ok ? "Disalin ke papan klip." : "Gagal menyalin."));
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {}), " Salin"]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			variant: "secondary",
			disabled,
			onClick: () => {
				shareText(title, text).then((result) => {
					if (result === "shared") toast("Dibagikan.");
					else if (result === "copied") toast("Berbagi tidak tersedia. Teks disalin.");
					else if (result === "failed") toast("Gagal membagikan.");
				});
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, {}), " Bagikan"]
		})]
	});
}
function ConfirmButton({ title, body, confirmLabel, onConfirm, children, danger = true }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialog, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTrigger, {
		asChild: true,
		children
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogOverlay, { className: "fixed inset-0 z-50 bg-ink/40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, {
		className: "fixed top-1/2 left-1/2 z-50 w-[min(100%-2rem,24rem)] -translate-x-1/2 -translate-y-1/2 rounded-card border border-line bg-card p-5 text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, {
				className: "text-lg font-bold",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, {
				className: "mt-2 text-sm text-mute",
				children: body
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						children: "Batal"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: danger ? "danger" : "primary",
						onClick: onConfirm,
						children: confirmLabel
					})
				})]
			})
		]
	})] })] });
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-w-0 rounded-card border border-line bg-card px-3 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "truncate text-xs font-medium text-mute",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "truncate text-lg font-bold tabular-nums",
			children: value
		})]
	});
}
function Notice({ children, tone = "muted" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: cn("text-sm", tone === "danger" ? "text-danger" : "text-mute"),
		role: tone === "danger" ? "alert" : void 0,
		children
	});
}
function ToolRow({ tool }) {
	const openTool = useNav().openTool;
	const favorite = usePrefs((state) => state.favorites.includes(tool.id));
	const toggleFavorite = usePrefs((state) => state.toggleFavorite);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-1 rounded-card border border-line bg-card pr-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => openTool(tool.id),
			className: "flex min-h-16 min-w-0 flex-1 items-center gap-3 px-3 py-2 text-left",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid size-11 shrink-0 place-items-center rounded-control bg-sunken text-ink",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolIcon, {
						name: tool.icon,
						className: "size-5"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block truncate font-semibold",
						children: tool.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block truncate text-sm text-mute",
						children: tool.blurb
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {
					className: "size-4 shrink-0 text-mute",
					"aria-hidden": "true"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
			label: favorite ? `Hapus ${tool.name} dari favorit` : `Jadikan ${tool.name} favorit`,
			pressed: favorite,
			onClick: () => toggleFavorite(tool.id),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: favorite ? "fill-accent text-accent" : "text-mute" })
		})]
	});
}
function ToolList({ tools, emptyTitle, emptyBody }) {
	if (tools.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
		title: emptyTitle,
		body: emptyBody
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "space-y-2",
		children: tools.map((tool) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolRow, { tool }) }, tool.id))
	});
}
function ToolsTab() {
	const [query, setQuery] = (0, import_react.useState)("");
	const [category, setCategory] = (0, import_react.useState)("all");
	const tools = (0, import_react.useMemo)(() => searchTools(query, category), [query, category]);
	const grouped = !query.trim() && category === "all";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex w-full max-w-3xl flex-col gap-4 px-4 pt-4 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-extrabold tracking-tight",
				children: "Alat"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-mute",
				children: [TOOLS.length, " alat, semuanya berjalan di perangkat ini."]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchField, {
				value: query,
				onChange: setQuery
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2 overflow-x-auto pb-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
					active: category === "all",
					onClick: () => setCategory("all"),
					children: "Semua"
				}), CATEGORIES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
					active: category === item.id,
					onClick: () => setCategory(item.id),
					children: item.name
				}, item.id))]
			}),
			grouped ? CATEGORIES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-bold",
					children: item.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolList, {
					tools: TOOLS.filter((tool) => tool.category === item.id),
					emptyTitle: "",
					emptyBody: ""
				})]
			}, item.id)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolList, {
				tools,
				emptyTitle: "Tidak ada alat",
				emptyBody: `Tidak ada yang cocok dengan “${query.trim() || "filter ini"}”.`
			})
		]
	});
}
function Chip({ active, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: `h-11 shrink-0 rounded-full px-4 text-sm font-semibold ${active ? "bg-accent text-accent-ink" : "border border-line bg-card text-ink"}`,
		children
	});
}
function FavoritesTab() {
	const favorites = usePrefs((state) => state.favorites);
	const setTab = useNav().setTab;
	const tools = favorites.map((id) => getTool(id)).filter((tool) => Boolean(tool));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex w-full max-w-3xl flex-col gap-4 px-4 pt-4 pb-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-2xl font-extrabold tracking-tight",
			children: "Favorit"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-mute",
			children: "Alat yang Anda sematkan."
		})] }), tools.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
			title: "Belum ada favorit",
			body: "Bintang pada sebuah alat supaya muncul di sini dan di beranda.",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => setTab("tools"),
				children: "Lihat alat"
			})
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolList, {
			tools,
			emptyTitle: "",
			emptyBody: ""
		})]
	});
}
function idsToTools(ids) {
	return ids.map((id) => getTool(id)).filter((tool) => Boolean(tool));
}
function greet(date, name) {
	const hour = date.getHours();
	const hello = hour < 11 ? "Selamat pagi" : hour < 15 ? "Selamat siang" : hour < 18 ? "Selamat sore" : "Selamat malam";
	return name ? `${hello}, ${name}` : hello;
}
function HomeTab() {
	const nav = useNav();
	const name = usePrefs((state) => state.displayName.trim());
	const favorites = usePrefs((state) => state.favorites);
	const recents = usePrefs((state) => state.recents);
	const usage = usePrefs((state) => state.usage);
	const [query, setQuery] = (0, import_react.useState)("");
	const [category, setCategory] = (0, import_react.useState)("all");
	const [now] = (0, import_react.useState)(() => /* @__PURE__ */ new Date());
	const filtering = query.trim().length > 0 || category !== "all";
	const results = (0, import_react.useMemo)(() => searchTools(query, category), [query, category]);
	const quick = (0, import_react.useMemo)(() => {
		const ranked = [...TOOLS].filter((tool) => (usage[tool.id] ?? 0) > 0).sort((a, b) => (usage[b.id] ?? 0) - (usage[a.id] ?? 0));
		return (ranked.length > 0 ? ranked.slice(0, 4) : idsToTools(DEFAULT_QUICK)).slice(0, 4);
	}, [usage]);
	const favoriteTools = idsToTools(favorites).slice(0, 4);
	const recentTools = recents.map((item) => getTool(item.id)).filter((tool) => Boolean(tool));
	const last = recentTools[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex w-full max-w-3xl flex-col gap-5 px-4 pt-4 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-mute capitalize",
					children: now.toLocaleDateString("id-ID", {
						weekday: "long",
						day: "numeric",
						month: "long"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 text-2xl font-extrabold tracking-tight",
					children: greet(now, name)
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
					label: "Pengaturan",
					onClick: () => nav.setTab("settings"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, {})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchField, {
				value: query,
				onChange: setQuery
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-3 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Alat",
						value: String(TOOLS.length)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Favorit",
						value: String(favorites.length)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Terakhir",
						value: last?.name ?? "—"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2 overflow-x-auto pb-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
					active: category === "all",
					onClick: () => setCategory("all"),
					children: "Semua"
				}), CATEGORIES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
					active: category === item.id,
					onClick: () => setCategory(item.id),
					children: item.name
				}, item.id))]
			}),
			filtering ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolList, {
				tools: results,
				emptyTitle: "Tidak ketemu",
				emptyBody: "Coba nama lain, misalnya sandi, suhu, atau QR."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-bold",
						children: "Akses cepat"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-2",
						children: quick.map((tool) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => nav.openTool(tool.id),
							className: "min-h-16 rounded-card border border-line bg-card px-3 py-3 text-left",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block font-semibold",
								children: tool.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-0.5 block text-sm text-mute",
								children: CATEGORIES.find((item) => item.id === tool.category)?.name
							})]
						}, tool.id))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-bold",
							children: "Favorit"
						}), favorites.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "h-11 px-2 text-sm font-semibold text-accent",
							onClick: () => nav.setTab("fav"),
							children: "Semua"
						}) : null]
					}), favoriteTools.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rounded-card border border-dashed border-line px-3 py-4 text-sm text-mute",
						children: "Belum ada. Bintangi alat yang sering dipakai."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-2",
						children: favoriteTools.map((tool) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolRow, { tool }) }, tool.id))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-bold",
						children: "Baru dipakai"
					}), recentTools.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-mute",
						children: "Alat yang dibuka akan tercatat di sini."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-2",
						children: recentTools.slice(0, 4).map((tool) => tool ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolRow, { tool }) }, tool.id) : null)
					})]
				})
			] })
		]
	});
}
function FilterChip({ active, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: `h-11 shrink-0 rounded-full px-4 text-sm font-semibold ${active ? "bg-accent text-accent-ink" : "border border-line bg-card text-ink"}`,
		children
	});
}
function formatNumber(n) {
	if (!Number.isFinite(n) || Object.is(n, -0)) {
		if (n === 0) return "0";
		return "Tidak valid";
	}
	const abs = Math.abs(n);
	if (n !== 0 && (abs >= 0xe8d4a51000 || abs < 1e-6)) return n.toExponential(6).replace(/\.?0+e/, "e").replace(".", ",");
	return (Math.round(n * 1e8) / 1e8).toLocaleString("id-ID", { maximumFractionDigits: 8 });
}
function formatExprNumber(n) {
	if (!Number.isFinite(n) || Object.is(n, -0)) return "0";
	const abs = Math.abs(n);
	if (n !== 0 && (abs >= 0xe8d4a51000 || abs < 1e-6)) {
		const [coeff, pow] = n.toExponential(8).split("e");
		if (!coeff || pow === void 0) return "0";
		const c = Number(coeff);
		const p = Number(pow);
		if (!Number.isFinite(c) || !Number.isFinite(p)) return "0";
		const asFixed = (c * 10 ** p).toFixed(8);
		if (asFixed.includes("e")) return "0";
		return asFixed.replace(/\.?0+$/, "");
	}
	const rounded = Math.round(n * 1e10) / 1e10;
	let s = String(rounded);
	if (s.includes("e")) s = rounded.toFixed(10).replace(/\.?0+$/, "");
	return s === "-0" ? "0" : s;
}
function prettifyExpr(expr) {
	return expr.replaceAll("*", "×").replaceAll("/", "÷").replaceAll("-", "−").replaceAll(".", ",");
}
function formatBytes(n) {
	if (!Number.isFinite(n) || n < 0) return "—";
	const units = [
		"B",
		"KiB",
		"MiB",
		"GiB",
		"TiB"
	];
	let v = n;
	let i = 0;
	while (v >= 1024 && i < units.length - 1) {
		v /= 1024;
		i += 1;
	}
	return `${v.toLocaleString("id-ID", { maximumFractionDigits: i === 0 ? 0 : 2 })} ${units[i]}`;
}
function formatWhen(ts, now = Date.now()) {
	const delta = Math.max(0, now - ts);
	const min = Math.floor(delta / 6e4);
	if (min < 1) return "Baru saja";
	if (min < 60) return `${min} menit lalu`;
	const hr = Math.floor(min / 60);
	if (hr < 24) return `${hr} jam lalu`;
	const day = Math.floor(hr / 24);
	if (day < 7) return `${day} hari lalu`;
	return new Date(ts).toLocaleDateString("id-ID", {
		day: "numeric",
		month: "short",
		year: "numeric"
	});
}
function formatClock(ms) {
	const sign = ms < 0 ? "-" : "";
	const total = Math.floor(Math.abs(ms) / 10);
	const cs = total % 100;
	const sec = Math.floor(total / 100) % 60;
	const min = Math.floor(total / 6e3) % 60;
	const hr = Math.floor(total / 36e4);
	const pad = (n, w = 2) => String(n).padStart(w, "0");
	return `${sign}${hr > 0 ? `${pad(hr)}:${pad(min)}:${pad(sec)}` : `${pad(min)}:${pad(sec)}`},${pad(cs)}`;
}
function formatDurationHms(totalSeconds) {
	const s = Math.max(0, Math.floor(totalSeconds));
	const h = Math.floor(s / 3600);
	const m = Math.floor(s % 3600 / 60);
	const sec = s % 60;
	const pad = (n) => String(n).padStart(2, "0");
	return `${pad(h)}:${pad(m)}:${pad(sec)}`;
}
function SettingsTab() {
	const nav = useNav();
	const theme = usePrefs((state) => state.theme);
	const setTheme = usePrefs((state) => state.setTheme);
	const name = usePrefs((state) => state.displayName);
	const setDisplayName = usePrefs((state) => state.setDisplayName);
	const favorites = usePrefs((state) => state.favorites);
	const toggleFavorite = usePrefs((state) => state.toggleFavorite);
	const recents = usePrefs((state) => state.recents);
	const clearUsage = usePrefs((state) => state.clearUsage);
	const clearCalcHistory = usePrefs((state) => state.clearCalcHistory);
	const clearRecentFiles = usePrefs((state) => state.clearRecentFiles);
	const calcCount = usePrefs((state) => state.calcHistory.length);
	const fileCount = usePrefs((state) => state.recentFiles.length);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex w-full max-w-3xl flex-col gap-4 px-4 pt-4 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-extrabold tracking-tight",
				children: "Pengaturan"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-mute",
				children: "Profil, tampilan, dan data lokal."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-bold",
						children: "Profil lokal"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mb-1.5 block text-sm font-semibold",
							children: "Nama"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							value: name,
							maxLength: 40,
							placeholder: "Nama panggilan",
							onChange: (event) => setDisplayName(event.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: "Nama hanya untuk sapaan di beranda. Tidak dikirim ke server." })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segmented, {
				label: "Tampilan",
				value: theme,
				onChange: (value) => setTheme(value),
				options: [
					{
						id: "system",
						label: "Sistem"
					},
					{
						id: "light",
						label: "Terang"
					},
					{
						id: "dark",
						label: "Gelap"
					}
				]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "flex items-center justify-between gap-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-bold",
					children: "Bahasa"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-mute",
					children: "Indonesia. Bahasa lain belum tersedia."
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "text-sm font-bold",
					children: [
						"Favorit (",
						favorites.length,
						")"
					]
				}), favorites.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: "Belum ada alat yang disematkan." }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: favorites.map((id) => {
					const tool = getTool(id);
					if (!tool) return null;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between gap-3 py-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "min-h-11 truncate text-left text-sm font-semibold",
							onClick: () => nav.openTool(id),
							children: tool.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							className: "h-11 px-3",
							onClick: () => toggleFavorite(id),
							children: "Lepas"
						})]
					}, id);
				}) })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "overflow-hidden rounded-card border border-line bg-card",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LinkRow, {
						label: "Riwayat penggunaan",
						detail: recents.length ? `${recents.length} alat` : "Kosong",
						onClick: () => nav.openDoc("history")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LinkRow, {
						label: "Bantuan",
						onClick: () => nav.openDoc("help")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LinkRow, {
						label: "Kebijakan privasi",
						onClick: () => nav.openDoc("privacy")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LinkRow, {
						label: "Tentang",
						detail: `Versi ${APP_VERSION}`,
						onClick: () => nav.openDoc("about")
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmButton, {
				title: "Hapus riwayat penggunaan?",
				body: "Daftar alat yang baru dipakai dan jumlah pemakaian dihapus. Favorit tetap ada.",
				confirmLabel: "Hapus",
				onConfirm: clearUsage,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					children: "Hapus riwayat penggunaan"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmButton, {
				title: "Hapus riwayat perhitungan?",
				body: `${calcCount} perhitungan lokal akan dihapus.`,
				confirmLabel: "Hapus",
				onConfirm: clearCalcHistory,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					children: "Hapus riwayat perhitungan"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmButton, {
				title: "Hapus daftar berkas?",
				body: `${fileCount} entri nama berkas akan dihapus. Berkas asli tidak diubah.`,
				confirmLabel: "Hapus",
				onConfirm: clearRecentFiles,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					children: "Hapus daftar berkas"
				})
			})
		]
	});
}
function LinkRow({ label, detail, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: "flex min-h-14 w-full items-center gap-3 border-b border-line px-4 text-left last:border-b-0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "flex-1 font-semibold",
				children: label
			}),
			detail ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm text-mute",
				children: detail
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {
				className: "size-4 text-mute",
				"aria-hidden": "true"
			})
		]
	});
}
function DocScreen({ id }) {
	const back = useNav().back;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rise mx-auto w-full max-w-3xl px-4 pt-2 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mb-4 flex items-center gap-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
					label: "Kembali",
					onClick: back,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-extrabold tracking-tight",
					children: id === "privacy" ? "Kebijakan privasi" : id === "help" ? "Bantuan" : id === "about" ? "Tentang" : "Riwayat penggunaan"
				})]
			}),
			id === "history" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistoryBody, {}) : null,
			id === "privacy" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrivacyBody, {}) : null,
			id === "help" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HelpBody, {}) : null,
			id === "about" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AboutBody, {}) : null
		]
	});
}
function HistoryBody() {
	const recents = usePrefs((state) => state.recents);
	const openTool = useNav().openTool;
	if (recents.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: "Belum ada alat yang dibuka." });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "space-y-2",
		children: recents.map((item) => {
			const tool = getTool(item.id);
			if (!tool) return null;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => openTool(item.id),
				className: "flex min-h-14 w-full items-center justify-between gap-3 rounded-card border border-line bg-card px-3 text-left",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-semibold",
					children: tool.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm text-mute",
					children: formatWhen(item.at)
				})]
			}) }, `${item.id}-${item.at}`);
		})
	});
}
function PrivacyBody() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 text-sm leading-relaxed text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [APP_NAME, " memproses data di perangkat Anda. Tidak ada akun, dan tidak ada isi alat yang dikirim ke server."] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Yang tersimpan secara lokal: nama panggilan, tema, favorit, riwayat alat yang dibuka, riwayat perhitungan, serta nama, jenis, dan ukuran berkas yang dipilih. Isi berkas dan kata sandi yang dibuat tidak disimpan." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Kamera hanya diminta saat Anda menekan Pindai, dan gambarnya tidak diunggah. Notifikasi hanya diminta saat timer dimulai. Papan klip hanya ditulis ketika Anda menekan Salin. Tautan hanya dibuka jika Anda menekan tombolnya." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Menghapus data situs di browser akan menghapus riwayat lokal. Anda juga bisa menghapusnya dari Pengaturan." })
		]
	});
}
function HelpBody() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 text-sm leading-relaxed",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Pilih alat dari Beranda atau tab Alat. Bintang menyimpannya sebagai favorit. Salin dan Bagikan memakai kemampuan perangkat." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Teks, generator, kalkulator, konversi, dan tanggal bekerja tanpa jaringan. Kata sandi memakai acak kriptografis dan tidak masuk riwayat." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "QR dibuat di perangkat. Pemindai meminta kamera; jika izin ditolak, alat lain tetap bisa dipakai. Tautan hasil pindai tidak dibuka sendiri." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Timer bisa menampilkan notifikasi jika diizinkan, dan tetap berbunyi di dalam aplikasi. Menutup tab menghentikan timer. Info berkas memakai pemilih berkas sistem; aplikasi tidak menghapus atau mengubah berkas." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Tombol % pada kalkulator berarti bagi 100. Diskon dan kenaikan ada di alat Persentase. Konversi penyimpanan membedakan dasar 1024 dan 1000 supaya angkanya tidak menyesatkan." })
		]
	});
}
function AboutBody() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 text-sm leading-relaxed",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-lg font-extrabold",
				children: APP_NAME
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Versi ", APP_VERSION] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Alat harian yang ringkas: teks, generator, hitung, waktu, QR, dan berkas. Semua berjalan di perangkat ini." })
		]
	});
}
var LENGTH_UNITS = [
	{
		id: "mm",
		label: "Milimeter",
		factor: .001
	},
	{
		id: "cm",
		label: "Sentimeter",
		factor: .01
	},
	{
		id: "m",
		label: "Meter",
		factor: 1
	},
	{
		id: "km",
		label: "Kilometer",
		factor: 1e3
	},
	{
		id: "in",
		label: "Inci",
		factor: .0254
	},
	{
		id: "ft",
		label: "Kaki",
		factor: .3048
	},
	{
		id: "yd",
		label: "Yard",
		factor: .9144
	},
	{
		id: "mi",
		label: "Mil",
		factor: 1609.344
	}
];
var WEIGHT_UNITS = [
	{
		id: "mg",
		label: "Miligram",
		factor: .001
	},
	{
		id: "g",
		label: "Gram",
		factor: 1
	},
	{
		id: "kg",
		label: "Kilogram",
		factor: 1e3
	},
	{
		id: "oz",
		label: "Ons (avdp)",
		factor: 28.349523125
	},
	{
		id: "lb",
		label: "Pon",
		factor: 453.59237
	}
];
/** Volume in milliliters. US customary units are labeled as such in the UI. */
var VOLUME_UNITS = [
	{
		id: "ml",
		label: "Mililiter",
		factor: 1
	},
	{
		id: "l",
		label: "Liter",
		factor: 1e3
	},
	{
		id: "tsp",
		label: "Sendok teh AS",
		factor: 4.92892159375
	},
	{
		id: "tbsp",
		label: "Sendok makan AS",
		factor: 14.78676478125
	},
	{
		id: "cup",
		label: "Cangkir AS",
		factor: 236.5882365
	},
	{
		id: "metric-cup",
		label: "Cangkir metrik",
		factor: 250
	},
	{
		id: "floz",
		label: "Ons cair AS",
		factor: 29.5735295625
	},
	{
		id: "gal",
		label: "Galon AS",
		factor: 3785.411784
	}
];
function convertByFactor(value, from, to) {
	if (!Number.isFinite(value) || !Number.isFinite(from) || !Number.isFinite(to) || to === 0) return {
		ok: false,
		error: "Konversi tidak valid."
	};
	const out = value * from / to;
	if (!Number.isFinite(out)) return {
		ok: false,
		error: "Hasil di luar jangkauan."
	};
	return {
		ok: true,
		value: out
	};
}
function convertUnit(value, units, fromId, toId) {
	const from = units.find((unit) => unit.id === fromId);
	const to = units.find((unit) => unit.id === toId);
	if (!from || !to) return {
		ok: false,
		error: "Satuan tidak dikenal."
	};
	return convertByFactor(value, from.factor, to.factor);
}
function convertTemp(value, from, to) {
	if (!Number.isFinite(value)) return {
		ok: false,
		error: "Angka tidak valid."
	};
	if (from === "K" && value < 0) return {
		ok: false,
		error: "Kelvin tidak boleh negatif."
	};
	if (from === "C" && value < -273.15) return {
		ok: false,
		error: "Suhu di bawah nol mutlak."
	};
	if (from === "F" && value < -459.67) return {
		ok: false,
		error: "Suhu di bawah nol mutlak."
	};
	let celsius = value;
	if (from === "F") celsius = (value - 32) * 5 / 9;
	if (from === "K") celsius = value - 273.15;
	let out = celsius;
	if (to === "F") out = celsius * 9 / 5 + 32;
	if (to === "K") out = celsius + 273.15;
	if (to === "K" && out < -1e-9) return {
		ok: false,
		error: "Suhu di bawah nol mutlak."
	};
	if (!Number.isFinite(out)) return {
		ok: false,
		error: "Hasil di luar jangkauan."
	};
	return {
		ok: true,
		value: out
	};
}
var STORAGE_UNITS = [
	{
		id: "B",
		labelSi: "B",
		labelIec: "B",
		exp: 0
	},
	{
		id: "K",
		labelSi: "kB",
		labelIec: "KiB",
		exp: 1
	},
	{
		id: "M",
		labelSi: "MB",
		labelIec: "MiB",
		exp: 2
	},
	{
		id: "G",
		labelSi: "GB",
		labelIec: "GiB",
		exp: 3
	},
	{
		id: "T",
		labelSi: "TB",
		labelIec: "TiB",
		exp: 4
	}
];
function convertStorage(value, from, to, base) {
	if (!Number.isFinite(value)) return {
		ok: false,
		error: "Angka tidak valid."
	};
	if (value < 0) return {
		ok: false,
		error: "Ukuran tidak boleh negatif."
	};
	const fromExp = STORAGE_UNITS.find((unit) => unit.id === from)?.exp;
	const toExp = STORAGE_UNITS.find((unit) => unit.id === to)?.exp;
	if (fromExp === void 0 || toExp === void 0) return {
		ok: false,
		error: "Satuan tidak dikenal."
	};
	const out = value * base ** fromExp / base ** toExp;
	if (!Number.isFinite(out)) return {
		ok: false,
		error: "Hasil di luar jangkauan."
	};
	return {
		ok: true,
		value: out
	};
}
function parseUserNumber(raw) {
	const t = raw.trim().replace(/\s/g, "");
	if (!t) return {
		ok: false,
		error: "Isi angkanya dulu."
	};
	const norm = t.replace(",", ".");
	if (!/^[+-]?(?:\d+(?:\.\d+)?|\.\d+)$/.test(norm)) return {
		ok: false,
		error: "Angka tidak valid."
	};
	const value = Number(norm);
	if (!Number.isFinite(value)) return {
		ok: false,
		error: "Angka di luar jangkauan."
	};
	return {
		ok: true,
		value
	};
}
function evaluateMath(input) {
	const s = input.replace(/×/g, "*").replace(/÷/g, "/").replace(/−/g, "-").replace(/\s+/g, "");
	if (!s) return {
		ok: false,
		error: "Masukkan perhitungan."
	};
	if (s.length > 120) return {
		ok: false,
		error: "Perhitungan terlalu panjang."
	};
	let i = 0;
	function peek() {
		return s[i];
	}
	function parseAdd() {
		let left = parseMul();
		while (peek() === "+" || peek() === "-") {
			const op = s[i++] ?? "+";
			const right = parseMul();
			left = op === "+" ? left + right : left - right;
		}
		return left;
	}
	function parseMul() {
		let left = parseUnary();
		while (peek() === "*" || peek() === "/") {
			const op = s[i++] ?? "*";
			const right = parseUnary();
			if (op === "/" && right === 0) throw new Error("Tidak bisa membagi dengan nol.");
			left = op === "*" ? left * right : left / right;
		}
		return left;
	}
	function parseUnary() {
		if (peek() === "+") {
			i += 1;
			return parseUnary();
		}
		if (peek() === "-") {
			i += 1;
			return -parseUnary();
		}
		return parsePostfix();
	}
	function parsePostfix() {
		let value = parsePrimary();
		while (peek() === "%") {
			i += 1;
			value /= 100;
		}
		return value;
	}
	function parsePrimary() {
		if (peek() === "(") {
			i += 1;
			const value = parseAdd();
			if (peek() !== ")") throw new Error("Tanda kurung belum ditutup.");
			i += 1;
			return value;
		}
		const ch = peek();
		if (ch === void 0 || !/[0-9.]/.test(ch)) throw new Error("Perhitungan belum selesai.");
		const start = i;
		let dots = 0;
		while (i < s.length && /[0-9.]/.test(s[i] ?? "")) {
			if (s[i] === ".") dots += 1;
			i += 1;
		}
		if (dots > 1) throw new Error("Angka desimal tidak valid.");
		const slice = s.slice(start, i);
		if (slice === ".") throw new Error("Angka desimal tidak valid.");
		const num = Number(slice);
		if (!Number.isFinite(num)) throw new Error("Angka tidak valid.");
		return num;
	}
	try {
		const value = parseAdd();
		if (i !== s.length) return {
			ok: false,
			error: "Ada bagian yang tidak dikenali."
		};
		if (!Number.isFinite(value)) return {
			ok: false,
			error: "Hasil tidak terhingga."
		};
		return {
			ok: true,
			value
		};
	} catch (error) {
		return {
			ok: false,
			error: error instanceof Error ? error.message : "Perhitungan gagal."
		};
	}
}
function percentOf(percent, base) {
	if (!Number.isFinite(percent) || !Number.isFinite(base)) return {
		ok: false,
		error: "Angka tidak valid."
	};
	return {
		ok: true,
		value: percent / 100 * base
	};
}
function whatPercent(part, whole) {
	if (!Number.isFinite(part) || !Number.isFinite(whole)) return {
		ok: false,
		error: "Angka tidak valid."
	};
	if (whole === 0) return {
		ok: false,
		error: "Pembagi tidak boleh nol."
	};
	return {
		ok: true,
		value: part / whole * 100
	};
}
function percentChange(from, to) {
	if (!Number.isFinite(from) || !Number.isFinite(to)) return {
		ok: false,
		error: "Angka tidak valid."
	};
	if (from === 0) return {
		ok: false,
		error: "Nilai awal tidak boleh nol."
	};
	return {
		ok: true,
		value: (to - from) / from * 100
	};
}
var OPS = /* @__PURE__ */ new Set([
	"+",
	"-",
	"*",
	"/"
]);
function trailingNumber(expr) {
	let i = expr.length - 1;
	if (expr[i] === "%") i -= 1;
	const end = i + 1;
	while (i >= 0 && /[0-9.]/.test(expr[i] ?? "")) i -= 1;
	if (end <= i + 1) return null;
	return {
		start: i + 1,
		text: expr.slice(i + 1, end)
	};
}
function toggleSign(expr) {
	if (!expr) return "-";
	let i = expr.length - 1;
	if (expr[i] === "%") i -= 1;
	const end = i + 1;
	while (i >= 0 && /[0-9.]/.test(expr[i] ?? "")) i -= 1;
	if (end === i + 1) return expr;
	if (expr[i] === "-") {
		const prev = expr[i - 1];
		if (prev === void 0 || prev === "(" || OPS.has(prev)) return expr.slice(0, i) + expr.slice(i + 1);
	}
	return expr.slice(0, i + 1) + "-" + expr.slice(i + 1);
}
function applyCalcKey(expr, key, justEval) {
	if (key === "clear") return {
		expr: "",
		justEval: false
	};
	if (key === "back") {
		if (justEval) return {
			expr: "",
			justEval: false
		};
		return {
			expr: expr.slice(0, -1),
			justEval: false
		};
	}
	if (key === "eq") {
		const before = expr;
		const res = evaluateMath(expr);
		if (!res.ok) return {
			expr,
			justEval: false,
			error: res.error
		};
		return {
			expr: formatExprNumber(res.value),
			justEval: true,
			history: {
				expr: before,
				value: res.value
			}
		};
	}
	if (key === "neg") return {
		expr: toggleSign(justEval ? expr : expr),
		justEval: false
	};
	if (expr.length > 80) return {
		expr,
		justEval: false,
		error: "Perhitungan terlalu panjang."
	};
	if (key === "%") {
		if (!expr || OPS.has(expr.at(-1) ?? "") || expr.endsWith("(") || expr.endsWith(".")) return {
			expr,
			justEval: false
		};
		if (expr.endsWith("%")) return {
			expr,
			justEval: false
		};
		return {
			expr: expr + "%",
			justEval: false
		};
	}
	if (key === "(") {
		if (justEval) return {
			expr: "(",
			justEval: false
		};
		if (expr && /[0-9)%]/.test(expr.at(-1) ?? "")) return {
			expr: `${expr}*(`,
			justEval: false
		};
		return {
			expr: `${expr}(`,
			justEval: false
		};
	}
	if (key === ")") {
		if ([...expr].filter((c) => c === "(").length - [...expr].filter((c) => c === ")").length <= 0) return {
			expr,
			justEval: false
		};
		const last = expr.at(-1) ?? "";
		if (!expr || OPS.has(last) || last === "(" || last === ".") return {
			expr,
			justEval: false
		};
		return {
			expr: `${expr})`,
			justEval: false
		};
	}
	if (OPS.has(key)) {
		if (!expr) {
			if (key === "-") return {
				expr: "-",
				justEval: false
			};
			return {
				expr: "",
				justEval: false
			};
		}
		const last = expr.at(-1) ?? "";
		if (OPS.has(last)) return {
			expr: expr.slice(0, -1) + key,
			justEval: false
		};
		if (last === "(" || last === ".") return {
			expr,
			justEval: false
		};
		return {
			expr: expr + key,
			justEval: false
		};
	}
	if (key === ".") {
		if (justEval) return {
			expr: "0.",
			justEval: false
		};
		if (trailingNumber(expr)?.text.includes(".")) return {
			expr,
			justEval: false
		};
		const tail = expr.at(-1) ?? "";
		if (!expr || OPS.has(tail) || tail === "(") return {
			expr: `${expr}0.`,
			justEval: false
		};
		if (tail === "%") return {
			expr: `${expr}*0.`,
			justEval: false
		};
		return {
			expr: `${expr}.`,
			justEval: false
		};
	}
	if (justEval) return {
		expr: key,
		justEval: false
	};
	const lastNum = trailingNumber(expr);
	if (lastNum?.text === "0" && (expr.length === lastNum.start + 1 || OPS.has(expr[lastNum.start - 1] ?? "") || expr[lastNum.start - 1] === "(")) return {
		expr: expr.slice(0, lastNum.start) + key,
		justEval: false
	};
	const tail = expr.at(-1) ?? "";
	if (tail === "%" || tail === ")") return {
		expr: `${expr}*${key}`,
		justEval: false
	};
	return {
		expr: expr + key,
		justEval: false
	};
}
var KEYS = [
	[
		{
			id: "clear",
			label: "C"
		},
		{
			id: "(",
			label: "("
		},
		{
			id: ")",
			label: ")"
		},
		{
			id: "back",
			label: "⌫"
		}
	],
	[
		{
			id: "7",
			label: "7"
		},
		{
			id: "8",
			label: "8"
		},
		{
			id: "9",
			label: "9"
		},
		{
			id: "/",
			label: "÷",
			op: true
		}
	],
	[
		{
			id: "4",
			label: "4"
		},
		{
			id: "5",
			label: "5"
		},
		{
			id: "6",
			label: "6"
		},
		{
			id: "*",
			label: "×",
			op: true
		}
	],
	[
		{
			id: "1",
			label: "1"
		},
		{
			id: "2",
			label: "2"
		},
		{
			id: "3",
			label: "3"
		},
		{
			id: "-",
			label: "−",
			op: true
		}
	],
	[
		{
			id: "neg",
			label: "±"
		},
		{
			id: "0",
			label: "0"
		},
		{
			id: ".",
			label: ","
		},
		{
			id: "+",
			label: "+",
			op: true
		}
	]
];
function CalcBasic() {
	const [expr, setExpr] = (0, import_react.useState)("");
	const [just, setJust] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const addCalcHistory = usePrefs((state) => state.addCalcHistory);
	const history = usePrefs((state) => state.calcHistory);
	const clearCalcHistory = usePrefs((state) => state.clearCalcHistory);
	function press(key) {
		const next = applyCalcKey(expr, key, just);
		setExpr(next.expr);
		setJust(next.justEval);
		setError(next.error ?? null);
		if (next.history) addCalcHistory({
			id: crypto.randomUUID(),
			expr: next.history.expr,
			result: formatNumber(next.history.value),
			at: Date.now()
		});
	}
	(0, import_react.useEffect)(() => {
		const onKey = (event) => {
			const target = event.target;
			if (target instanceof HTMLElement && (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.isContentEditable)) return;
			const key = /^[0-9]$/.test(event.key) ? event.key : {
				Enter: "eq",
				"=": "eq",
				Backspace: "back",
				Escape: "clear",
				",": ".",
				".": ".",
				"%": "%",
				"+": "+",
				"-": "-",
				"*": "*",
				"/": "/",
				x: "*",
				X: "*",
				"(": "(",
				")": ")"
			}[event.key];
			if (!key) return;
			event.preventDefault();
			press(key);
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	});
	const live = !just && expr ? evaluateMath(expr) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "min-h-10 text-right font-mono text-3xl break-all tabular-nums",
				children: expr ? prettifyExpr(expr) : "0"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 min-h-6 text-right font-mono text-sm text-mute tabular-nums",
				children: live?.ok ? `= ${formatNumber(live.value)}` : ""
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-right text-sm text-danger",
				children: error
			}) : null
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-4 gap-2",
			children: KEYS.flat().map((key) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => press(key.id),
				className: `h-14 rounded-control text-lg font-semibold tabular-nums ${key.op ? "bg-sunken text-accent" : "bg-card text-ink border border-line"}`,
				children: [key.id === "back" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Delete, {
					className: "mx-auto size-5",
					"aria-hidden": "true"
				}) : key.label, key.id === "back" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "sr-only",
					children: "Hapus"
				}) : null]
			}, key.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-4 gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => press("%"),
				className: "h-14 rounded-control border border-line bg-card text-lg font-semibold text-accent",
				children: "%"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => press("eq"),
				className: "col-span-3 h-14 rounded-control bg-accent text-lg font-bold text-accent-ink",
				children: "="
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: "Tombol % membagi angka dengan 100. Untuk diskon atau kenaikan, pakai alat Persentase." }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-sm font-bold",
				children: "Riwayat"
			}), history.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmButton, {
				title: "Hapus riwayat hitung?",
				body: "Semua perhitungan tersimpan di perangkat ini akan dihapus.",
				confirmLabel: "Hapus",
				onConfirm: clearCalcHistory,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					className: "h-11 px-3",
					children: "Hapus"
				})
			}) : null]
		}),
		history.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: "Belum ada perhitungan." }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-2",
			children: history.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => {
					setExpr(item.expr);
					setJust(false);
					setError(null);
				},
				className: "w-full rounded-card border border-line bg-card px-3 py-3 text-left",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block truncate font-mono text-sm text-mute",
					children: prettifyExpr(item.expr)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block font-mono text-lg tabular-nums",
					children: item.result
				})]
			}) }, item.id))
		})
	] });
}
function UnitPanel({ units, note }) {
	const [raw, setRaw] = (0, import_react.useState)("1");
	const [from, setFrom] = (0, import_react.useState)(units[0]?.id ?? "");
	const [to, setTo] = (0, import_react.useState)(units[1]?.id ?? units[0]?.id ?? "");
	const parsed = parseUserNumber(raw);
	const rows = parsed.ok ? units.map((unit) => ({
		unit,
		result: convertUnit(parsed.value, units, from, unit.id)
	})) : [];
	const chosen = rows.find((row) => row.unit.id === to);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "Nilai",
			error: raw.trim() && !parsed.ok ? parsed.ok ? null : parsed.error : null,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
				inputMode: "decimal",
				value: raw,
				onChange: (event) => setRaw(event.target.value)
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-[1fr_auto_1fr] items-end gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Dari",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectInput, {
						value: from,
						onChange: (event) => setFrom(event.target.value),
						children: units.map((unit) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: unit.id,
							children: unit.label
						}, unit.id))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "Tukar satuan",
					className: "mb-0 grid size-12 place-items-center rounded-control bg-sunken",
					onClick: () => {
						setFrom(to);
						setTo(from);
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeftRight, { className: "size-5" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Ke",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectInput, {
						value: to,
						onChange: (event) => setTo(event.target.value),
						children: units.map((unit) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: unit.id,
							children: unit.label
						}, unit.id))
					})
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium text-mute",
				children: "Hasil"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-3xl font-medium break-all tabular-nums",
				children: chosen?.result.ok ? formatNumber(chosen.result.value) : "—"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-mute",
				children: units.find((unit) => unit.id === to)?.label
			})
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: note }),
		parsed.ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-1",
			children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-center justify-between gap-3 rounded-control px-1 py-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-mute",
					children: row.unit.label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-mono tabular-nums",
					children: row.result.ok ? formatNumber(row.result.value) : "—"
				})]
			}, row.unit.id))
		}) : null
	] });
}
function CalcLength() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UnitPanel, {
		units: LENGTH_UNITS,
		note: "Faktor tetap: 1 inci = 2,54 cm, 1 mil = 1.609,344 m."
	});
}
function CalcWeight() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UnitPanel, {
		units: WEIGHT_UNITS,
		note: "Ons dan pon adalah avoirdupois (1 pon = 453,59237 g), bukan ons metrik."
	});
}
function CalcVolume() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UnitPanel, {
		units: VOLUME_UNITS,
		note: "Sendok, cangkir AS, ons cair, dan galon memakai ukuran Amerika Serikat. Cangkir metrik = 250 ml."
	});
}
var TEMPS = [
	{
		id: "C",
		label: "Celsius"
	},
	{
		id: "F",
		label: "Fahrenheit"
	},
	{
		id: "K",
		label: "Kelvin"
	}
];
function CalcTemp() {
	const [raw, setRaw] = (0, import_react.useState)("0");
	const [from, setFrom] = (0, import_react.useState)("C");
	const [to, setTo] = (0, import_react.useState)("F");
	const parsed = parseUserNumber(raw);
	const converted = parsed.ok ? convertTemp(parsed.value, from, to) : null;
	const rows = parsed.ok ? TEMPS.map((unit) => ({
		unit,
		result: convertTemp(parsed.value, from, unit.id)
	})) : [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "Nilai",
			error: parsed.ok || !raw.trim() ? null : parsed.error,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
				inputMode: "decimal",
				value: raw,
				onChange: (event) => setRaw(event.target.value)
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-2 gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Dari",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectInput, {
					value: from,
					onChange: (event) => setFrom(event.target.value),
					children: TEMPS.map((unit) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: unit.id,
						children: unit.label
					}, unit.id))
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Ke",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectInput, {
					value: to,
					onChange: (event) => setTo(event.target.value),
					children: TEMPS.map((unit) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: unit.id,
						children: unit.label
					}, unit.id))
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium text-mute",
				children: "Hasil"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-3xl font-medium tabular-nums",
				children: converted?.ok ? formatNumber(converted.value) : "—"
			}),
			converted && !converted.ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-danger",
				children: converted.error
			}) : null
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: "Nol mutlak ditolak: 0 K, −273,15 °C, atau −459,67 °F." }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-1",
			children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex justify-between gap-3 px-1 py-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-mute",
					children: row.unit.label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-mono tabular-nums",
					children: row.result.ok ? formatNumber(row.result.value) : row.result.error
				})]
			}, row.unit.id))
		})
	] });
}
function CalcStorage() {
	const [raw, setRaw] = (0, import_react.useState)("1");
	const [base, setBase] = (0, import_react.useState)(1024);
	const [from, setFrom] = (0, import_react.useState)("M");
	const [to, setTo] = (0, import_react.useState)("K");
	const parsed = parseUserNumber(raw);
	const label = (id) => {
		const unit = STORAGE_UNITS.find((item) => item.id === id);
		return base === 1024 ? unit?.labelIec : unit?.labelSi;
	};
	const converted = parsed.ok ? convertStorage(parsed.value, from, to, base) : null;
	const rows = parsed.ok ? STORAGE_UNITS.map((unit) => ({
		unit,
		result: convertStorage(parsed.value, from, unit.id, base)
	})) : [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segmented, {
			label: "Dasar hitung",
			value: String(base),
			onChange: (value) => setBase(value === "1000" ? 1e3 : 1024),
			options: [{
				id: "1024",
				label: "Biner 1024"
			}, {
				id: "1000",
				label: "Desimal 1000"
			}]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "Nilai",
			error: !parsed.ok && raw.trim() ? parsed.error : converted && !converted.ok ? converted.error : null,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
				inputMode: "decimal",
				value: raw,
				onChange: (event) => setRaw(event.target.value)
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-2 gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Dari",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectInput, {
					value: from,
					onChange: (event) => setFrom(event.target.value),
					children: STORAGE_UNITS.map((unit) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: unit.id,
						children: base === 1024 ? unit.labelIec : unit.labelSi
					}, unit.id))
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Ke",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectInput, {
					value: to,
					onChange: (event) => setTo(event.target.value),
					children: STORAGE_UNITS.map((unit) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: unit.id,
						children: base === 1024 ? unit.labelIec : unit.labelSi
					}, unit.id))
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium text-mute",
				children: "Hasil"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-3xl font-medium break-all tabular-nums",
				children: converted?.ok ? formatNumber(converted.value) : "—"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-mute",
				children: label(to)
			})
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: base === 1024 ? "Biner: 1 KiB = 1.024 B. Ini yang biasa dipakai sistem berkas." : "Desimal: 1 kB = 1.000 B. Ini yang sering dipakai produsen penyimpanan." }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-1",
			children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex justify-between gap-3 px-1 py-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-mute",
					children: base === 1024 ? row.unit.labelIec : row.unit.labelSi
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-mono tabular-nums",
					children: row.result.ok ? formatNumber(row.result.value) : "—"
				})]
			}, row.unit.id))
		})
	] });
}
function CalcPercent() {
	const [mode, setMode] = (0, import_react.useState)("of");
	const [a, setA] = (0, import_react.useState)("10");
	const [b, setB] = (0, import_react.useState)("200");
	const left = parseUserNumber(a);
	const right = parseUserNumber(b);
	let result = null;
	if (left.ok && right.ok) {
		if (mode === "of") result = percentOf(left.value, right.value);
		if (mode === "what") result = whatPercent(left.value, right.value);
		if (mode === "change") result = percentChange(left.value, right.value);
	}
	const labels = mode === "of" ? [
		"Persen",
		"Nilai dasar",
		"Hasil"
	] : mode === "what" ? [
		"Bagian",
		"Keseluruhan",
		"Persen"
	] : [
		"Nilai awal",
		"Nilai akhir",
		"Perubahan"
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segmented, {
			label: "Jenis",
			value: mode,
			onChange: setMode,
			options: [
				{
					id: "of",
					label: "X% dari Y"
				},
				{
					id: "what",
					label: "Porsi"
				},
				{
					id: "change",
					label: "Perubahan"
				}
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-2 gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: labels[0] ?? "",
				error: a.trim() && !left.ok ? left.error : null,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
					inputMode: "decimal",
					value: a,
					onChange: (event) => setA(event.target.value)
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: labels[1] ?? "",
				error: b.trim() && !right.ok ? right.error : null,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
					inputMode: "decimal",
					value: b,
					onChange: (event) => setB(event.target.value)
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium text-mute",
				children: labels[2]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-3xl font-medium tabular-nums",
				children: result?.ok ? `${formatNumber(result.value)}${mode === "of" ? "" : "%"}` : "—"
			}),
			result && !result.ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-danger",
				children: result.error
			}) : null
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: mode === "change" ? "Perubahan = (akhir − awal) / awal × 100. Nilai awal nol tidak dihitung." : mode === "what" ? "Porsi = bagian / keseluruhan × 100. Keseluruhan nol tidak dihitung." : "Contoh: 10% dari 200 = 20." })
	] });
}
function inspectUrl(raw) {
	const value = raw.trim();
	if (!value) return {
		ok: false,
		error: "Masukkan URL."
	};
	if (value.length > 2e3) return {
		ok: false,
		error: "URL terlalu panjang."
	};
	let url;
	try {
		url = new URL(value);
	} catch {
		return {
			ok: false,
			error: "Format URL tidak valid. Sertakan http:// atau https://."
		};
	}
	if (url.protocol !== "http:" && url.protocol !== "https:") return {
		ok: false,
		error: "Hanya tautan http dan https. Skema lain tidak dibuka."
	};
	const host = url.hostname.replace(/\.+$/, "");
	if (!host) return {
		ok: false,
		error: "Nama host kosong."
	};
	if (host !== "localhost" && !host.includes(".")) return {
		ok: false,
		error: "Nama host tidak lengkap."
	};
	const warnings = [];
	if (url.username || url.password) warnings.push("URL memuat nama pengguna atau sandi. Periksa sebelum membuka.");
	if (url.protocol === "http:") warnings.push("Tautan tidak terenkripsi (http).");
	if (/^\d{1,3}(\.\d{1,3}){3}$/.test(host) || host.includes(":")) warnings.push("Host berupa alamat IP, bukan nama domain.");
	if (host.includes("xn--")) warnings.push("Domain memakai punycode. Periksa ejaannya.");
	return {
		ok: true,
		href: url.href,
		protocol: url.protocol === "https:" ? "https" : "http",
		host,
		secure: url.protocol === "https:",
		warnings
	};
}
function cssColor(name, fallback) {
	return getComputedStyle(document.documentElement).getPropertyValue(name).trim() || fallback;
}
function QrMake() {
	const toast = useToast();
	const canvasRef = (0, import_react.useRef)(null);
	const [text, setText] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	const [ready, setReady] = (0, import_react.useState)(false);
	const report = text.trim() ? inspectUrl(text) : null;
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		const value = text.trim();
		if (!canvas) return;
		if (!value) {
			setReady(false);
			setError(null);
			canvas.getContext("2d")?.clearRect(0, 0, canvas.width, canvas.height);
			return;
		}
		if (value.length > 800) {
			setReady(false);
			setError("Teks terlalu panjang untuk satu QR. Maksimum 800 karakter.");
			return;
		}
		let cancel = false;
		setError(null);
		(async () => {
			try {
				const mod = await import("../_libs/qrcode.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()));
				const toCanvas = mod.toCanvas ?? mod.default?.toCanvas;
				if (!toCanvas) throw new Error("Pembuat QR tidak tersedia.");
				await toCanvas(canvas, value, {
					margin: 1,
					width: 280,
					errorCorrectionLevel: "M",
					color: {
						dark: cssColor("--color-ink", "#1a1916"),
						light: cssColor("--color-card", "#fffcf8")
					}
				});
				if (!cancel) setReady(true);
			} catch {
				if (!cancel) {
					setReady(false);
					setError("QR tidak bisa dibuat dari teks ini.");
				}
			}
		})();
		return () => {
			cancel = true;
		};
	}, [text]);
	async function pngBlob() {
		const canvas = canvasRef.current;
		if (!canvas || !ready) return null;
		return new Promise((resolve) => canvas.toBlob(resolve, "image/png"));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "Teks atau URL",
			error,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextArea, {
				value: text,
				onChange: (event) => setText(event.target.value),
				placeholder: "https:// atau teks apa pun",
				className: "min-h-24"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "grid place-items-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: canvasRef,
				width: 280,
				height: 280,
				className: `max-w-full ${ready ? "" : "hidden"}`,
				"aria-label": "Kode QR"
			}), !ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "py-16 text-sm text-mute",
				children: error ? "QR tidak ditampilkan." : "QR muncul setelah ada teks."
			}) : null]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: "Tautan di dalam QR tidak dibuka otomatis." }),
		report?.ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "space-y-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm",
					children: [
						"Terdeteksi tautan ",
						report.secure ? "aman" : "http",
						" ke ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold",
							children: report.host
						}),
						"."
					]
				}),
				report.warnings.map((warning) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: warning }, warning)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: report.href,
					target: "_blank",
					rel: "noopener noreferrer",
					className: "inline-flex h-12 items-center justify-center rounded-control bg-sunken px-4 text-sm font-semibold",
					children: "Buka tautan"
				})
			]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionRow, {
			text: text.trim(),
			title: "Teks QR"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-2 gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "secondary",
				disabled: !ready,
				onClick: () => {
					(async () => {
						const blob = await pngBlob();
						if (!blob) return toast("Gambar QR belum siap.");
						try {
							if (navigator.clipboard && "write" in navigator.clipboard && typeof ClipboardItem !== "undefined") {
								await navigator.clipboard.write([new ClipboardItem({ "image/png": blob })]);
								toast("Gambar disalin.");
								return;
							}
						} catch {}
						const copied = await copyText(text.trim());
						toast(copied ? "Gambar tidak bisa disalin. Teksnya disalin." : "Gagal menyalin gambar.");
					})();
				},
				children: "Salin gambar"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "secondary",
				disabled: !ready,
				onClick: () => {
					(async () => {
						const blob = await pngBlob();
						if (!blob) return toast("Gambar QR belum siap.");
						const url = URL.createObjectURL(blob);
						const link = document.createElement("a");
						link.href = url;
						link.download = "xjox-qr.png";
						link.click();
						URL.revokeObjectURL(url);
						toast("Gambar diunduh. Pilih folder lewat dialog unduhan bila muncul.");
					})();
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}), " Simpan PNG"]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "secondary",
			disabled: !ready,
			onClick: () => {
				(async () => {
					const blob = await pngBlob();
					if (!blob) return;
					const file = new File([blob], "xjox-qr.png", { type: "image/png" });
					if (navigator.share && navigator.canShare?.({ files: [file] })) try {
						await navigator.share({
							files: [file],
							title: "QR XJOX",
							text: text.trim()
						});
						toast("Dibagikan.");
						return;
					} catch (error) {
						if (error instanceof DOMException && error.name === "AbortError") return;
					}
					const result = await shareText("QR XJOX", text.trim());
					if (result === "shared") toast("Dibagikan.");
					else if (result === "copied") toast("Berbagi gambar tidak tersedia. Teks disalin.");
					else if (result === "failed") toast("Gagal membagikan.");
				})();
			},
			children: "Bagikan gambar"
		})
	] });
}
function QrScan() {
	const videoRef = (0, import_react.useRef)(null);
	const [phase, setPhase] = (0, import_react.useState)("idle");
	const [error, setError] = (0, import_react.useState)(null);
	const [result, setResult] = (0, import_react.useState)("");
	const streamRef = (0, import_react.useRef)(null);
	const alive = (0, import_react.useRef)(false);
	function stop() {
		alive.current = false;
		streamRef.current?.getTracks().forEach((track) => track.stop());
		streamRef.current = null;
		if (videoRef.current) videoRef.current.srcObject = null;
		setPhase("idle");
	}
	(0, import_react.useEffect)(() => () => stop(), []);
	async function start() {
		setError(null);
		setResult("");
		setPhase("starting");
		if (!navigator.mediaDevices?.getUserMedia) {
			setPhase("idle");
			setError("Browser ini tidak bisa membuka kamera.");
			return;
		}
		const attempts = [{ video: { facingMode: "environment" } }, { video: true }];
		let stream = null;
		let last;
		for (const constraints of attempts) try {
			stream = await navigator.mediaDevices.getUserMedia(constraints);
			break;
		} catch (cause) {
			last = cause;
			if (cause instanceof DOMException && (cause.name === "NotAllowedError" || cause.name === "PermissionDeniedError")) break;
		}
		if (!stream || !videoRef.current) {
			setPhase("idle");
			if (last instanceof DOMException && (last.name === "NotAllowedError" || last.name === "PermissionDeniedError")) setError("Izin kamera ditolak. Izinkan kamera di browser, lalu coba lagi. Tidak ada gambar yang dikirim ke server.");
			else if (last instanceof DOMException && last.name === "NotFoundError") setError("Kamera tidak ditemukan.");
			else setError("Kamera tidak bisa dibuka.");
			return;
		}
		streamRef.current = stream;
		videoRef.current.srcObject = stream;
		await videoRef.current.play();
		setPhase("scanning");
		const { default: jsQR } = await import("../_libs/jsqr.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()));
		const canvas = document.createElement("canvas");
		const ctx = canvas.getContext("2d", { willReadFrequently: true });
		alive.current = true;
		const tick = () => {
			if (!alive.current || !videoRef.current || !ctx) return;
			const video = videoRef.current;
			if (video.readyState >= 2 && video.videoWidth > 0) {
				const scale = Math.min(1, 640 / video.videoWidth);
				const width = Math.max(1, Math.floor(video.videoWidth * scale));
				const height = Math.max(1, Math.floor(video.videoHeight * scale));
				canvas.width = width;
				canvas.height = height;
				ctx.drawImage(video, 0, 0, width, height);
				const image = ctx.getImageData(0, 0, width, height);
				const code = jsQR(image.data, width, height, { inversionAttempts: "attemptBoth" });
				if (code?.data) {
					setResult(code.data);
					stop();
					return;
				}
			}
			window.setTimeout(tick, 150);
		};
		tick();
	}
	const report = result ? inspectUrl(result) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: "Kamera hanya menyala setelah Anda menekan tombol. Gambar tidak dikirim ke mana pun." }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "overflow-hidden rounded-card border border-line bg-sunken",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
				ref: videoRef,
				className: `aspect-[3/4] w-full object-cover ${phase === "scanning" ? "" : "hidden"}`,
				playsInline: true,
				muted: true
			}), phase !== "scanning" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid aspect-[3/4] place-items-center px-6 text-center text-sm text-mute",
				children: phase === "starting" ? "Menyalakan kamera…" : "Pratinjau kamera muncul di sini."
			}) : null]
		}),
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, {
			tone: "danger",
			children: error
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-2 gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => void start(),
				disabled: phase !== "idle",
				children: phase === "starting" ? "Menyiapkan…" : "Pindai"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "secondary",
				onClick: stop,
				disabled: phase === "idle",
				children: "Berhenti"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-medium text-mute",
			children: "Hasil"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 font-mono text-sm break-all",
			children: result || "Belum ada kode."
		})] }),
		report?.ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "space-y-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm",
					children: [
						"Tautan ke ",
						report.host,
						". Tidak dibuka otomatis."
					]
				}),
				report.warnings.map((warning) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: warning }, warning)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: report.href,
					target: "_blank",
					rel: "noopener noreferrer",
					className: "inline-flex h-12 items-center justify-center rounded-control bg-accent px-4 text-sm font-semibold text-accent-ink",
					children: "Buka tautan"
				})
			]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionRow, {
			text: result,
			title: "Hasil pindai QR"
		})
	] });
}
function UrlCheck() {
	const [raw, setRaw] = (0, import_react.useState)("");
	const report = raw.trim() ? inspectUrl(raw) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "URL",
			error: report && !report.ok ? report.error : null,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
				value: raw,
				onChange: (event) => setRaw(event.target.value),
				placeholder: "https://contoh.id",
				inputMode: "url",
				autoCapitalize: "none",
				autoCorrect: "off"
			})
		}),
		!raw.trim() ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: "Tempel tautan untuk diperiksa. Tidak ada yang dibuka sebelum Anda menekan tombol." }) : null,
		report?.ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "space-y-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm font-semibold",
					children: [
						report.secure ? "HTTPS" : "HTTP",
						" · ",
						report.host
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-sm break-all text-mute",
					children: report.href
				}),
				report.warnings.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: "Tidak ada peringatan dasar." }) : report.warnings.map((warning) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: warning }, warning)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: report.href,
					target: "_blank",
					rel: "noopener noreferrer",
					className: "inline-flex h-12 items-center justify-center rounded-control bg-accent px-4 text-sm font-semibold text-accent-ink",
					children: "Buka tautan"
				})
			]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionRow, {
			text: report?.ok ? report.href : "",
			title: "URL"
		})
	] });
}
var PREVIEW_LIMIT = 2e5;
function looksText(file) {
	if (file.type.startsWith("text/")) return true;
	if (file.type === "application/json" || file.type === "application/xml" || file.type === "image/svg+xml") return true;
	return /\.(txt|md|csv|json|xml|svg|log|css|html)$/i.test(file.name);
}
function describe(file) {
	return [
		`Nama: ${file.name}`,
		`Ukuran: ${formatBytes(file.size)} (${file.size.toLocaleString("id-ID")} byte)`,
		`Jenis: ${file.type || "tidak diketahui"}`,
		`Diubah: ${new Date(file.lastModified).toLocaleString("id-ID")}`
	].join("\n");
}
function FileInfo() {
	const toast = useToast();
	const recent = usePrefs((state) => state.recentFiles);
	const addRecentFile = usePrefs((state) => state.addRecentFile);
	const clearRecentFiles = usePrefs((state) => state.clearRecentFiles);
	const [activeId, setActiveId] = (0, import_react.useState)(null);
	const [preview, setPreview] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	const [reading, setReading] = (0, import_react.useState)(false);
	const active = activeId ? recallFile(activeId) : void 0;
	function take(file) {
		const id = crypto.randomUUID();
		rememberFile(id, file);
		addRecentFile({
			id,
			name: file.name,
			size: file.size,
			type: file.type,
			lastModified: file.lastModified,
			openedAt: Date.now()
		});
		setActiveId(id);
		setPreview(null);
		setError(null);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: "Berkas tidak diunggah. Daftar terbaru hanya menyimpan nama, jenis, dan ukuran di perangkat ini." }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "flex h-12 cursor-pointer items-center justify-center rounded-control bg-accent px-4 text-sm font-semibold text-accent-ink",
			children: ["Pilih berkas", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "file",
				className: "sr-only",
				onChange: (event) => {
					const file = event.target.files?.[0];
					event.target.value = "";
					if (file) take(file);
				}
			})]
		}),
		active ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "space-y-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-base font-bold break-all",
					children: active.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-mute",
					children: [
						"Ukuran ",
						formatBytes(active.size),
						" · ",
						active.size.toLocaleString("id-ID"),
						" byte"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-mute",
					children: ["Jenis ", active.type || "tidak diketahui"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-mute",
					children: ["Diubah ", new Date(active.lastModified).toLocaleString("id-ID")]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2 pt-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						onClick: () => {
							copyText(describe(active)).then((ok) => toast(ok ? "Info disalin." : "Gagal menyalin."));
						},
						children: "Salin info"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						onClick: () => {
							(async () => {
								if (navigator.share && navigator.canShare?.({ files: [active] })) try {
									await navigator.share({
										files: [active],
										title: active.name
									});
									toast("Berkas dibagikan.");
									return;
								} catch (cause) {
									if (cause instanceof DOMException && cause.name === "AbortError") return;
								}
								toast("Browser ini tidak mendukung berbagi berkas.");
							})();
						},
						children: "Bagikan"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					disabled: reading,
					onClick: () => {
						if (!looksText(active)) {
							setPreview(null);
							setError("Cuplikan hanya untuk berkas teks.");
							return;
						}
						if (active.size > PREVIEW_LIMIT) {
							setPreview(null);
							setError("Cuplikan hanya untuk berkas di bawah 200 KB.");
							return;
						}
						setReading(true);
						setError(null);
						active.text().then((value) => setPreview(value)).catch(() => setError("Isi berkas tidak bisa dibaca.")).finally(() => setReading(false));
					},
					children: reading ? "Membaca…" : "Tampilkan cuplikan teks"
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, {
					tone: "danger",
					children: error
				}) : null,
				preview !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
					className: "max-h-60 overflow-auto whitespace-pre-wrap break-words rounded-control bg-sunken p-3 font-mono text-xs",
					children: preview
				}) : null
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
			title: "Belum ada berkas",
			body: "Pilih berkas lewat pemilih sistem. Isinya tidak diubah dan tidak dihapus."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-sm font-bold",
				children: "Baru dibuka"
			}), recent.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmButton, {
				title: "Hapus daftar berkas?",
				body: "Hanya daftar nama di aplikasi yang dihapus. Berkas asli tidak tersentuh.",
				confirmLabel: "Hapus",
				onConfirm: () => {
					clearRecentFiles();
					setActiveId(null);
					setPreview(null);
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					className: "h-11 px-3",
					children: "Hapus daftar"
				})
			}) : null]
		}),
		recent.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: "Daftar masih kosong." }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-2",
			children: recent.map((item) => {
				const file = recallFile(item.id);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-card border border-line bg-card px-3 py-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-semibold break-all",
							children: item.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-mute",
							children: [
								formatBytes(item.size),
								" · ",
								formatWhen(item.openedAt)
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-mute",
							children: file ? "Masih bisa dibagikan pada sesi ini." : "Pilih ulang berkas jika ingin membagikannya lagi."
						})
					]
				}, item.id);
			})
		})
	] });
}
/** Uniform crypto random helpers. No Math.random. */
function randomIndex(span) {
	if (!Number.isSafeInteger(span) || span <= 0) throw new Error("Rentang acak tidak valid.");
	if (span === 1) return 0;
	if (span <= 4294967296) {
		const limit = Math.floor(4294967296 / span) * span;
		const buf = /* @__PURE__ */ new Uint32Array(1);
		while (true) {
			crypto.getRandomValues(buf);
			const n = buf[0] ?? 0;
			if (n < limit) return n % span;
		}
	}
	const limit = Math.floor(Number.MAX_SAFE_INTEGER / span) * span;
	const buf = /* @__PURE__ */ new Uint32Array(2);
	while (true) {
		crypto.getRandomValues(buf);
		const hi = (buf[0] ?? 0) & 2097151;
		const lo = buf[1] ?? 0;
		const n = hi * 4294967296 + lo;
		if (n < limit) return n % span;
	}
}
function randomUnit() {
	const buf = /* @__PURE__ */ new Uint32Array(1);
	crypto.getRandomValues(buf);
	return (buf[0] ?? 0) / 4294967296;
}
function shuffleInPlace(items) {
	for (let i = items.length - 1; i > 0; i--) {
		const j = randomIndex(i + 1);
		const tmp = items[i];
		items[i] = items[j];
		items[j] = tmp;
	}
	return items;
}
var LOWER = "abcdefghijklmnopqrstuvwxyz";
var UPPER = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
var DIGIT = "0123456789";
var SYMBOL = "!@#$%^&*()-_=+[]{};:,.?";
var AMBIGUOUS = /* @__PURE__ */ new Set([
	"0",
	"O",
	"o",
	"1",
	"l",
	"I",
	"|"
]);
function generateUuids(count) {
	if (!Number.isInteger(count) || count < 1 || count > 20) return {
		ok: false,
		error: "Jumlah UUID harus 1–20."
	};
	return {
		ok: true,
		ids: Array.from({ length: count }, () => crypto.randomUUID())
	};
}
function pool(source, avoidAmbiguous) {
	if (!avoidAmbiguous) return source;
	return [...source].filter((ch) => !AMBIGUOUS.has(ch)).join("");
}
function generatePassword(opts) {
	if (!Number.isInteger(opts.length) || opts.length < 4 || opts.length > 64) return {
		ok: false,
		error: "Panjang sandi 4–64 karakter."
	};
	const sets = [
		opts.lower ? pool(LOWER, opts.avoidAmbiguous) : "",
		opts.upper ? pool(UPPER, opts.avoidAmbiguous) : "",
		opts.digit ? pool(DIGIT, opts.avoidAmbiguous) : "",
		opts.symbol ? pool(SYMBOL, opts.avoidAmbiguous) : ""
	].filter((set) => set.length > 0);
	if (sets.length === 0) return {
		ok: false,
		error: "Pilih minimal satu jenis karakter."
	};
	if (opts.length < sets.length) return {
		ok: false,
		error: "Panjang terlalu pendek untuk semua jenis yang dipilih."
	};
	const all = sets.join("");
	const chars = sets.map((set) => set[randomIndex(set.length)] ?? "");
	while (chars.length < opts.length) chars.push(all[randomIndex(all.length)] ?? "");
	return {
		ok: true,
		password: shuffleInPlace(chars).join(""),
		bits: opts.length * Math.log2(all.length),
		charset: all.length
	};
}
function strengthLabel(bits) {
	if (bits < 40) return "Lemah";
	if (bits < 60) return "Sedang";
	if (bits < 80) return "Kuat";
	return "Sangat kuat";
}
function generateNumbers(opts) {
	if (!Number.isInteger(opts.count) || opts.count < 1 || opts.count > 20) return {
		ok: false,
		error: "Jumlah angka 1–20."
	};
	if (!Number.isFinite(opts.min) || !Number.isFinite(opts.max)) return {
		ok: false,
		error: "Batas tidak valid."
	};
	if (opts.min > opts.max) return {
		ok: false,
		error: "Nilai minimum lebih besar dari maksimum."
	};
	if (opts.integer) {
		if (!Number.isSafeInteger(opts.min) || !Number.isSafeInteger(opts.max)) return {
			ok: false,
			error: "Untuk bilangan bulat, isi batas bulat dalam jangkauan aman."
		};
		const span = opts.max - opts.min + 1;
		if (span > Number.MAX_SAFE_INTEGER) return {
			ok: false,
			error: "Rentang terlalu lebar."
		};
		return {
			ok: true,
			values: Array.from({ length: opts.count }, () => opts.min + randomIndex(span))
		};
	}
	return {
		ok: true,
		values: Array.from({ length: opts.count }, () => opts.min + randomUnit() * (opts.max - opts.min))
	};
}
function randomColor() {
	const bytes = /* @__PURE__ */ new Uint8Array(3);
	crypto.getRandomValues(bytes);
	const r = bytes[0] ?? 0;
	const g = bytes[1] ?? 0;
	const b = bytes[2] ?? 0;
	return {
		hex: `#${[
			r,
			g,
			b
		].map((n) => n.toString(16).padStart(2, "0")).join("")}`,
		r,
		g,
		b
	};
}
function inkForColor(r, g, b) {
	const chan = (c) => {
		const s = c / 255;
		return s <= .03928 ? s / 12.92 : ((s + .055) / 1.055) ** 2.4;
	};
	return .2126 * chan(r) + .7152 * chan(g) + .0722 * chan(b) > .42 ? "#1a1916" : "#fffcf8";
}
var ID_WORDS = [
	"angin",
	"pagi",
	"jalan",
	"kecil",
	"rumah",
	"langit",
	"daun",
	"batu",
	"pelan",
	"baru",
	"cerah",
	"tenang",
	"mesin",
	"kertas",
	"angka",
	"warna",
	"waktu",
	"ruang",
	"pintu",
	"jendela",
	"kerja",
	"ringkas",
	"bersih",
	"fokus",
	"alat",
	"tangan",
	"layar",
	"catatan",
	"langkah",
	"arah",
	"hujan",
	"tanah",
	"pohon",
	"sungai",
	"malam",
	"kota",
	"desa",
	"suara",
	"cahaya",
	"bayang",
	"rapi",
	"sederhana",
	"tepat",
	"hangat",
	"dingin",
	"luas",
	"jelas",
	"bidang",
	"garis",
	"titik"
];
var LOREM = "lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua enim ad minim veniam quis nostrud exercitation ullamco laboris nisi aliquip ex ea commodo consequat".split(" ");
function makePlaceholder(opts) {
	if (!Number.isInteger(opts.paragraphs) || opts.paragraphs < 1 || opts.paragraphs > 8) return {
		ok: false,
		error: "Jumlah paragraf 1–8."
	};
	if (!Number.isInteger(opts.sentences) || opts.sentences < 1 || opts.sentences > 8) return {
		ok: false,
		error: "Jumlah kalimat per paragraf 1–8."
	};
	const bank = opts.mode === "id" ? ID_WORDS : LOREM;
	const paragraphs = [];
	for (let p = 0; p < opts.paragraphs; p += 1) {
		const sentences = [];
		for (let s = 0; s < opts.sentences; s += 1) {
			const count = 6 + randomIndex(5);
			const words = [];
			for (let i = 0; i < count; i += 1) words.push(bank[randomIndex(bank.length)] ?? "kata");
			const first = words[0] ?? "kata";
			words[0] = first.charAt(0).toUpperCase() + first.slice(1);
			sentences.push(`${words.join(" ")}.`);
		}
		paragraphs.push(sentences.join(" "));
	}
	return {
		ok: true,
		text: paragraphs.join("\n\n")
	};
}
var PASSWORD_DEFAULT = {
	length: 16,
	lower: true,
	upper: true,
	digit: true,
	symbol: true,
	avoidAmbiguous: true
};
function GenUuid() {
	const [count, setCount] = (0, import_react.useState)(1);
	const [made, setMade] = (0, import_react.useState)(() => generateUuids(1));
	const text = made.ok ? made.ids.join("\n") : "";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "Jumlah",
			hint: "1 sampai 20.",
			error: made.ok ? null : made.error,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
				inputMode: "numeric",
				value: String(count),
				onChange: (event) => {
					const next = Number(event.target.value);
					setCount(Number.isFinite(next) ? next : 0);
				}
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			onClick: () => {
				const amount = Number(count);
				setMade(generateUuids(amount));
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {}), " Buat ulang"]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Output, {
			text,
			placeholder: "UUID muncul di sini."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionRow, {
			text,
			title: "UUID"
		})
	] });
}
function GenPassword() {
	const [opts, setOpts] = (0, import_react.useState)(PASSWORD_DEFAULT);
	const [made, setMade] = (0, import_react.useState)(() => generatePassword(PASSWORD_DEFAULT));
	const [visible, setVisible] = (0, import_react.useState)(false);
	const patch = (partial) => setOpts((current) => ({
		...current,
		...partial
	}));
	const password = made.ok ? made.password : "";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: "Sandi dibuat di perangkat dan tidak disimpan, termasuk tidak masuk riwayat." }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "Panjang",
			hint: "4–64. Tiap jenis yang dipilih pasti muncul.",
			error: made.ok ? null : made.error,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
				inputMode: "numeric",
				value: String(opts.length),
				onChange: (event) => patch({ length: Number(event.target.value) })
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckRow, {
					label: "Huruf kecil",
					checked: opts.lower,
					onChange: (lower) => patch({ lower })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckRow, {
					label: "Huruf besar",
					checked: opts.upper,
					onChange: (upper) => patch({ upper })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckRow, {
					label: "Angka",
					checked: opts.digit,
					onChange: (digit) => patch({ digit })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckRow, {
					label: "Simbol",
					checked: opts.symbol,
					onChange: (symbol) => patch({ symbol })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckRow, {
					label: "Hindari karakter mirip (0, O, 1, l)",
					checked: opts.avoidAmbiguous,
					onChange: (avoidAmbiguous) => patch({ avoidAmbiguous })
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			onClick: () => {
				const next = {
					...opts,
					length: Number(opts.length)
				};
				setOpts(next);
				setMade(generatePassword(next));
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {}), " Buat ulang"]
		}),
		made.ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: cnVisible(visible),
					children: visible ? made.password : "•".repeat(made.password.length)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "ghost",
					className: "h-11 shrink-0 px-3",
					onClick: () => setVisible((value) => !value),
					"aria-pressed": visible,
					children: [visible ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, {}), visible ? "Sembunyi" : "Lihat"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-sm text-mute",
				children: [
					strengthLabel(made.bits),
					" · sekitar ",
					Math.round(made.bits),
					" bit dari ",
					made.charset,
					" karakter."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 h-2 overflow-hidden rounded-full bg-sunken",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-full bg-accent",
					style: { width: `${Math.max(8, Math.min(100, made.bits))}%` }
				})
			})
		] }) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionRow, {
			text: password,
			title: "Kata sandi"
		})
	] });
}
function cnVisible(visible) {
	return visible ? "min-w-0 flex-1 font-mono text-lg break-all text-ink" : "min-w-0 flex-1 font-mono text-lg break-all tracking-widest text-ink";
}
function GenNumber() {
	const [minRaw, setMinRaw] = (0, import_react.useState)("1");
	const [maxRaw, setMaxRaw] = (0, import_react.useState)("100");
	const [count, setCount] = (0, import_react.useState)("5");
	const [integer, setInteger] = (0, import_react.useState)(true);
	const [error, setError] = (0, import_react.useState)(null);
	const [values, setValues] = (0, import_react.useState)(() => {
		const made = generateNumbers({
			min: 1,
			max: 100,
			count: 5,
			integer: true
		});
		return made.ok ? made.values : [];
	});
	const text = values.map((value) => integer ? String(value) : formatNumber(value)).join("\n");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-2 gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Minimum",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
					inputMode: "decimal",
					value: minRaw,
					onChange: (event) => setMinRaw(event.target.value)
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Maksimum",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
					inputMode: "decimal",
					value: maxRaw,
					onChange: (event) => setMaxRaw(event.target.value)
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "Jumlah",
			hint: "1–20. Batas ikut dalam hasil bilangan bulat.",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
				inputMode: "numeric",
				value: count,
				onChange: (event) => setCount(event.target.value)
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckRow, {
			label: "Bilangan bulat",
			checked: integer,
			onChange: setInteger
		}),
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, {
			tone: "danger",
			children: error
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			onClick: () => {
				const min = parseUserNumber(minRaw);
				const max = parseUserNumber(maxRaw);
				const amount = Number(count);
				if (!min.ok) return setError(min.error);
				if (!max.ok) return setError(max.error);
				if (!Number.isInteger(amount)) return setError("Jumlah harus bilangan bulat.");
				const made = generateNumbers({
					min: min.value,
					max: max.value,
					count: amount,
					integer
				});
				if (!made.ok) {
					setValues([]);
					setError(made.error);
					return;
				}
				setError(null);
				setValues(made.values);
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {}), " Buat angka"]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Output, {
			text,
			placeholder: "Angka acak muncul di sini."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionRow, {
			text,
			title: "Angka acak"
		})
	] });
}
function GenColor() {
	const [color, setColor] = (0, import_react.useState)(() => randomColor());
	const rgb = `rgb(${color.r}, ${color.g}, ${color.b})`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid h-40 place-items-center rounded-card border border-line font-mono text-lg font-medium",
			style: {
				backgroundColor: color.hex,
				color: inkForColor(color.r, color.g, color.b)
			},
			children: color.hex
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "font-mono text-sm",
			children: ["HEX ", color.hex]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-1 font-mono text-sm",
			children: [
				"RGB ",
				color.r,
				", ",
				color.g,
				", ",
				color.b
			]
		})] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			onClick: () => setColor(randomColor()),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {}), " Buat ulang"]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-2 sm:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionRow, {
				text: color.hex,
				title: "Warna HEX"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionRow, {
				text: rgb,
				title: "Warna RGB"
			})]
		})
	] });
}
function GenLorem() {
	const [mode, setMode] = (0, import_react.useState)("id");
	const [paragraphs, setParagraphs] = (0, import_react.useState)("2");
	const [sentences, setSentences] = (0, import_react.useState)("3");
	const [error, setError] = (0, import_react.useState)(null);
	const [text, setText] = (0, import_react.useState)(() => {
		const made = makePlaceholder({
			mode: "id",
			paragraphs: 2,
			sentences: 3
		});
		return made.ok ? made.text : "";
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: "Ini teks pengisi untuk tata letak, bukan konten bermakna." }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segmented, {
			label: "Bahasa pengisi",
			value: mode,
			onChange: setMode,
			options: [{
				id: "id",
				label: "Indonesia"
			}, {
				id: "lorem",
				label: "Lorem"
			}]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-2 gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Paragraf",
				hint: "1–8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
					inputMode: "numeric",
					value: paragraphs,
					onChange: (event) => setParagraphs(event.target.value)
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Kalimat",
				hint: "1–8 tiap paragraf",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
					inputMode: "numeric",
					value: sentences,
					onChange: (event) => setSentences(event.target.value)
				})
			})]
		}),
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, {
			tone: "danger",
			children: error
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			onClick: () => {
				const made = makePlaceholder({
					mode,
					paragraphs: Number(paragraphs),
					sentences: Number(sentences)
				});
				if (!made.ok) {
					setText("");
					setError(made.error);
					return;
				}
				setError(null);
				setText(made.text);
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {}), " Buat ulang"]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Output, {
			text,
			placeholder: "Teks pengisi muncul di sini."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionRow, {
			text,
			title: "Teks pengisi"
		})
	] });
}
var TEXT_LIMIT = 1e5;
function textLimitMessage(input) {
	if (input.length > 1e5) return `Teks terlalu panjang. Maksimum ${TEXT_LIMIT.toLocaleString("id-ID")} karakter.`;
	return null;
}
function textStats(input) {
	if (input.length === 0) return {
		chars: 0,
		charsNoSpace: 0,
		words: 0,
		lines: 0,
		paragraphs: 0,
		sentences: 0
	};
	const chars = Array.from(input);
	const charsNoSpace = chars.filter((ch) => !/\s/u.test(ch)).length;
	const words = input.trim() ? input.trim().split(/\s+/).length : 0;
	const lines = input.split(/\r?\n/).length;
	const paragraphs = input.split(/\r?\n\s*\r?\n/).map((part) => part.trim()).filter(Boolean).length;
	const sentences = input.trim() ? input.trim().split(/[.!?]+/u).map((part) => part.trim()).filter(Boolean).length : 0;
	return {
		chars: chars.length,
		charsNoSpace,
		words,
		lines,
		paragraphs,
		sentences
	};
}
function statsSummary(stats) {
	return [
		`${stats.words} kata`,
		`${stats.chars} karakter`,
		`${stats.charsNoSpace} tanpa spasi`,
		`${stats.sentences} kalimat`,
		`${stats.paragraphs} paragraf`,
		`${stats.lines} baris`
	].join(", ");
}
function changeCase(input, mode) {
	if (mode === "upper") return input.toLocaleUpperCase("id");
	if (mode === "lower") return input.toLocaleLowerCase("id");
	if (mode === "title") return input.toLocaleLowerCase("id").replace(/\p{L}[\p{L}\p{M}]*/gu, (word) => {
		const letters = Array.from(word);
		return (letters[0] ?? "").toLocaleUpperCase("id") + letters.slice(1).join("");
	});
	if (mode === "sentence") {
		const lower = input.toLocaleLowerCase("id");
		let cap = true;
		return Array.from(lower).map((ch) => {
			if (cap && /\p{L}/u.test(ch)) {
				cap = false;
				return ch.toLocaleUpperCase("id");
			}
			if (/[.!?]/.test(ch)) cap = true;
			return ch;
		}).join("");
	}
	return Array.from(input).map((ch) => {
		const up = ch.toLocaleUpperCase("id");
		const lo = ch.toLocaleLowerCase("id");
		if (up === lo) return ch;
		return ch === up ? lo : up;
	}).join("");
}
function removeExtraSpaces(input) {
	const text = input.split(/\r?\n/).map((line) => line.replace(/[ \t\f\v]+/g, " ").trim()).join("\n");
	return {
		text,
		removed: Math.max(0, input.length - text.length)
	};
}
function removeBlankLines(input) {
	const lines = input.split(/\r?\n/);
	const kept = lines.filter((line) => line.trim().length > 0);
	return {
		text: kept.join("\n"),
		removed: lines.length - kept.length
	};
}
function shuffleText(input, mode) {
	if (mode === "lines") {
		const lines = input.split(/\r?\n/);
		if (lines.filter((line) => line.length > 0).length < 2 && lines.length < 2) return {
			ok: false,
			error: "Butuh minimal dua baris untuk diacak."
		};
		if (lines.length < 2) return {
			ok: false,
			error: "Butuh minimal dua baris untuk diacak."
		};
		return {
			ok: true,
			text: shuffleInPlace([...lines]).join("\n")
		};
	}
	const words = input.trim().split(/\s+/).filter(Boolean);
	if (words.length < 2) return {
		ok: false,
		error: "Butuh minimal dua kata untuk diacak."
	};
	return {
		ok: true,
		text: shuffleInPlace([...words]).join(" ")
	};
}
function reverseText(input, mode) {
	if (mode === "chars") return Array.from(input).reverse().join("");
	if (mode === "words") return input.split(/(\s+)/).reverse().join("");
	return input.split(/\r?\n/).reverse().join("\n");
}
function dedupeLines(input, opts) {
	if (input.length === 0) return {
		text: "",
		removed: 0
	};
	const lines = input.split(/\r?\n/);
	const seen = /* @__PURE__ */ new Set();
	const out = [];
	let removed = 0;
	for (const line of lines) {
		const trimmed = opts.trim ? line.trim() : line;
		const key = opts.ignoreCase ? trimmed.toLocaleLowerCase("id") : trimmed;
		if (seen.has(key)) {
			removed += 1;
			continue;
		}
		seen.add(key);
		out.push(trimmed);
	}
	return {
		text: out.join("\n"),
		removed
	};
}
var SAMPLE = "  XJOX   Tools membantu\n\npekerjaan   harian.\nXJOX Tools\nXJOX Tools";
function useTextDraft() {
	const [input, setInput] = (0, import_react.useState)("");
	return {
		input,
		setInput,
		blocked: textLimitMessage(input)
	};
}
function Draft({ input, setInput, blocked }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-semibold",
					children: "Teks sumber"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					className: "h-11 px-3",
					onClick: () => setInput(SAMPLE),
					children: "Isi contoh"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextArea, {
				value: input,
				onChange: (event) => setInput(event.target.value),
				placeholder: "Ketik atau tempel teks…",
				spellCheck: true
			}),
			blocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, {
				tone: "danger",
				children: blocked
			}) : null
		]
	});
}
function TextCount() {
	const draft = useTextDraft();
	const stats = draft.blocked ? null : textStats(draft.input);
	const summary = stats ? statsSummary(stats) : "";
	const items = stats ? [
		["Karakter", stats.chars],
		["Tanpa spasi", stats.charsNoSpace],
		["Kata", stats.words],
		["Kalimat", stats.sentences],
		["Paragraf", stats.paragraphs],
		["Baris", stats.lines]
	] : [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Draft, { ...draft }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-2 gap-2 sm:grid-cols-3",
			children: items.map(([label, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "px-3 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs font-medium text-mute",
					children: label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-mono text-2xl font-medium tabular-nums",
					children: Number(value).toLocaleString("id-ID")
				})]
			}, String(label)))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionRow, {
			text: summary,
			title: "Penghitung teks"
		})
	] });
}
function TextCase() {
	const draft = useTextDraft();
	const [mode, setMode] = (0, import_react.useState)("upper");
	const output = draft.blocked ? "" : changeCase(draft.input, mode);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segmented, {
			label: "Bentuk huruf",
			value: mode,
			onChange: setMode,
			options: [
				{
					id: "upper",
					label: "BESAR"
				},
				{
					id: "lower",
					label: "kecil"
				},
				{
					id: "title",
					label: "Judul"
				},
				{
					id: "sentence",
					label: "Kalimat"
				},
				{
					id: "toggle",
					label: "Tukar"
				}
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Draft, { ...draft }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Output, {
			text: output,
			placeholder: "Hasil ubah huruf muncul di sini."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionRow, {
			text: output,
			title: "Ubah huruf"
		})
	] });
}
function TextSpace() {
	const draft = useTextDraft();
	const result = draft.blocked ? null : removeExtraSpaces(draft.input);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Draft, { ...draft }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: result ? result.removed > 0 ? `${result.removed} karakter spasi dihapus.` : "Tidak ada spasi berlebih." : null }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Output, {
			text: result?.text ?? "",
			placeholder: "Teks yang sudah dirapikan muncul di sini."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionRow, {
			text: result?.text ?? "",
			title: "Rapikan spasi"
		})
	] });
}
function TextBlank() {
	const draft = useTextDraft();
	const result = draft.blocked ? null : removeBlankLines(draft.input);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Draft, { ...draft }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: result ? result.removed > 0 ? `${result.removed} baris kosong dihapus.` : "Tidak ada baris kosong." : null }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Output, {
			text: result?.text ?? "",
			placeholder: "Teks tanpa baris kosong muncul di sini."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionRow, {
			text: result?.text ?? "",
			title: "Hapus baris kosong"
		})
	] });
}
function TextShuffle() {
	const draft = useTextDraft();
	const [mode, setMode] = (0, import_react.useState)("words");
	const [output, setOutput] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segmented, {
			label: "Yang diacak",
			value: mode,
			onChange: (next) => {
				setMode(next);
				setOutput("");
				setError(null);
			},
			options: [{
				id: "words",
				label: "Kata"
			}, {
				id: "lines",
				label: "Baris"
			}]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Draft, {
			input: draft.input,
			blocked: draft.blocked,
			setInput: (value) => {
				draft.setInput(value);
				setOutput("");
				setError(null);
			}
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			disabled: Boolean(draft.blocked),
			onClick: () => {
				const made = shuffleText(draft.input, mode);
				if (!made.ok) {
					setOutput("");
					setError(made.error);
					return;
				}
				setError(null);
				setOutput(made.text);
			},
			children: "Acak"
		}),
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, {
			tone: "danger",
			children: error
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: "Urutan kata menggabungkan spasi menjadi satu. Acak memakai sumber kriptografis." }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Output, {
			text: output,
			placeholder: "Tekan Acak untuk melihat hasil."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionRow, {
			text: output,
			title: "Acak teks"
		})
	] });
}
function TextReverse() {
	const draft = useTextDraft();
	const [mode, setMode] = (0, import_react.useState)("chars");
	const output = draft.blocked ? "" : reverseText(draft.input, mode);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segmented, {
			label: "Balik berdasarkan",
			value: mode,
			onChange: setMode,
			options: [
				{
					id: "chars",
					label: "Karakter"
				},
				{
					id: "words",
					label: "Kata"
				},
				{
					id: "lines",
					label: "Baris"
				}
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Draft, { ...draft }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Output, {
			text: output,
			placeholder: "Teks terbalik muncul di sini."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionRow, {
			text: output,
			title: "Balik teks"
		})
	] });
}
function TextDedupe() {
	const draft = useTextDraft();
	const [ignoreCase, setIgnoreCase] = (0, import_react.useState)(false);
	const [trim, setTrim] = (0, import_react.useState)(true);
	const result = draft.blocked ? null : dedupeLines(draft.input, {
		ignoreCase,
		trim
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex min-h-12 items-center gap-3 rounded-control border border-line bg-card px-3 text-sm font-medium",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					className: "size-5 accent-accent",
					checked: ignoreCase,
					onChange: (event) => setIgnoreCase(event.target.checked)
				}), "Abaikan huruf besar/kecil"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex min-h-12 items-center gap-3 rounded-control border border-line bg-card px-3 text-sm font-medium",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					className: "size-5 accent-accent",
					checked: trim,
					onChange: (event) => setTrim(event.target.checked)
				}), "Rapikan spasi di tepi baris"]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Draft, { ...draft }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: result ? `${result.removed} baris ganda dihapus.` : null }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Output, {
			text: result?.text ?? "",
			placeholder: "Baris unik muncul di sini."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionRow, {
			text: result?.text ?? "",
			title: "Hapus baris ganda"
		})
	] });
}
function parseDateInput(iso) {
	const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso.trim());
	if (!match) return null;
	const year = Number(match[1]);
	const month = Number(match[2]);
	const day = Number(match[3]);
	if (month < 1 || month > 12 || day < 1 || day > 31) return null;
	const date = new Date(year, month - 1, day);
	if (date.getFullYear() !== year || date.getMonth() !== month - 1 || date.getDate() !== day) return null;
	return date;
}
function parseTimeInput(value) {
	const match = /^(\d{2}):(\d{2})$/.exec(value.trim());
	if (!match) return null;
	const h = Number(match[1]);
	const m = Number(match[2]);
	if (h > 23 || m > 59) return null;
	return {
		h,
		m
	};
}
function utcDayNumber(date) {
	return Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()) / 864e5;
}
function calendarParts(earlier, later) {
	let years = later.getFullYear() - earlier.getFullYear();
	let months = later.getMonth() - earlier.getMonth();
	let daysPart = later.getDate() - earlier.getDate();
	if (daysPart < 0) {
		months -= 1;
		const prevMonthDays = new Date(later.getFullYear(), later.getMonth(), 0).getDate();
		daysPart += prevMonthDays;
	}
	if (months < 0) {
		years -= 1;
		months += 12;
	}
	return {
		years,
		months,
		daysPart
	};
}
function diffDates(aIso, bIso) {
	const a = parseDateInput(aIso);
	const b = parseDateInput(bIso);
	if (!a || !b) return {
		ok: false,
		error: "Tanggal tidak valid."
	};
	const days = utcDayNumber(b) - utcDayNumber(a);
	const parts = calendarParts(days >= 0 ? a : b, days >= 0 ? b : a);
	return {
		ok: true,
		days,
		absDays: Math.abs(days),
		...parts
	};
}
function countdownTo(dateIso, time, now = /* @__PURE__ */ new Date()) {
	const date = parseDateInput(dateIso);
	const clock = parseTimeInput(time);
	if (!date || !clock) return {
		ok: false,
		error: "Tanggal atau jam tidak valid."
	};
	const delta = new Date(date.getFullYear(), date.getMonth(), date.getDate(), clock.h, clock.m, 0, 0).getTime() - now.getTime();
	const past = delta < 0;
	const total = Math.floor(Math.abs(delta) / 1e3);
	return {
		ok: true,
		past,
		days: Math.floor(total / 86400),
		hours: Math.floor(total % 86400 / 3600),
		minutes: Math.floor(total % 3600 / 60),
		seconds: total % 60
	};
}
function zoneName(date) {
	const zone = Intl.DateTimeFormat().resolvedOptions().timeZone || "lokal";
	const offsetMin = -date.getTimezoneOffset();
	const sign = offsetMin >= 0 ? "+" : "−";
	const abs = Math.abs(offsetMin);
	return `${zone} (UTC${sign}${String(Math.floor(abs / 60)).padStart(2, "0")}:${String(abs % 60).padStart(2, "0")})`;
}
function TimeClock() {
	const [now, setNow] = (0, import_react.useState)(() => /* @__PURE__ */ new Date());
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => setNow(/* @__PURE__ */ new Date()), 250);
		return () => window.clearInterval(id);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "py-8 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-5xl font-medium tabular-nums",
				children: now.toLocaleTimeString("id-ID", {
					hour: "2-digit",
					minute: "2-digit",
					second: "2-digit",
					hourCycle: "h23"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-base font-semibold capitalize",
				children: now.toLocaleDateString("id-ID", {
					weekday: "long",
					day: "numeric",
					month: "long",
					year: "numeric"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-mute",
				children: zoneName(now)
			})
		]
	});
}
var useStopwatch = create((set, get) => ({
	running: false,
	startedAt: 0,
	accumulated: 0,
	laps: [],
	start: () => {
		if (get().running) return;
		set({
			running: true,
			startedAt: performance.now()
		});
	},
	pause: () => {
		const state = get();
		if (!state.running) return;
		set({
			running: false,
			accumulated: state.accumulated + performance.now() - state.startedAt
		});
	},
	reset: () => set({
		running: false,
		accumulated: 0,
		startedAt: 0,
		laps: []
	}),
	lap: () => {
		set({ laps: [get().elapsed(), ...get().laps].slice(0, 40) });
	},
	elapsed: () => {
		const state = get();
		return state.running ? state.accumulated + performance.now() - state.startedAt : state.accumulated;
	}
}));
function TimeStopwatch() {
	const running = useStopwatch((state) => state.running);
	const laps = useStopwatch((state) => state.laps);
	const start = useStopwatch((state) => state.start);
	const pause = useStopwatch((state) => state.pause);
	const reset = useStopwatch((state) => state.reset);
	const lap = useStopwatch((state) => state.lap);
	const [elapsed, setElapsed] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		let frame = 0;
		const tick = () => {
			setElapsed(useStopwatch.getState().elapsed());
			frame = window.requestAnimationFrame(tick);
		};
		frame = window.requestAnimationFrame(tick);
		return () => window.cancelAnimationFrame(frame);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
			className: "py-8 text-center",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-5xl font-medium tabular-nums",
				children: formatClock(elapsed)
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-3 gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					onClick: reset,
					children: "Atur ulang"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					onClick: lap,
					disabled: elapsed === 0,
					children: "Putaran"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: running ? pause : start,
					children: running ? "Jeda" : "Mulai"
				})
			]
		}),
		laps.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: "Putaran muncul di sini. Stopwatch tetap jalan saat Anda pindah alat." }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "space-y-2",
			children: laps.map((value, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex justify-between rounded-control bg-card px-3 py-3 font-mono text-sm tabular-nums",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-mute",
					children: ["Putaran ", laps.length - index]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatClock(value) })]
			}, `${value}-${index}`))
		})
	] });
}
var audioCtx = null;
function primeAudio() {
	const Ctx = window.AudioContext || window.webkitAudioContext;
	if (!Ctx) return;
	if (!audioCtx) audioCtx = new Ctx();
	if (audioCtx.state === "suspended") audioCtx.resume();
}
function ringTimer() {
	if (!audioCtx) return;
	const now = audioCtx.currentTime;
	for (let i = 0; i < 3; i += 1) {
		const osc = audioCtx.createOscillator();
		const gain = audioCtx.createGain();
		osc.type = "sine";
		osc.frequency.value = 880;
		osc.connect(gain);
		gain.connect(audioCtx.destination);
		const start = now + i * .42;
		gain.gain.setValueAtTime(1e-4, start);
		gain.gain.exponentialRampToValueAtTime(.12, start + .02);
		gain.gain.exponentialRampToValueAtTime(1e-4, start + .32);
		osc.start(start);
		osc.stop(start + .34);
	}
}
function TimeTimer() {
	const [hours, setHours] = (0, import_react.useState)("0");
	const [minutes, setMinutes] = (0, import_react.useState)("1");
	const [seconds, setSeconds] = (0, import_react.useState)("0");
	const [error, setError] = (0, import_react.useState)(null);
	const [note, setNote] = (0, import_react.useState)(null);
	const [left, setLeft] = (0, import_react.useState)(0);
	const running = useTimer((state) => state.running);
	const endAt = useTimer((state) => state.endAt);
	const totalMs = useTimer((state) => state.totalMs);
	const fired = useTimer((state) => state.fired);
	const start = useTimer((state) => state.start);
	const stop = useTimer((state) => state.stop);
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => {
			const state = useTimer.getState();
			if (state.running && state.endAt) setLeft(Math.max(0, state.endAt - Date.now()));
			else if (state.fired) setLeft(0);
		}, 200);
		return () => window.clearInterval(id);
	}, []);
	const progress = totalMs > 0 ? Math.max(0, Math.min(100, left / totalMs * 100)) : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "py-8 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-5xl font-medium tabular-nums",
					children: formatDurationHms(left / 1e3)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto mt-4 h-2 max-w-xs overflow-hidden rounded-full bg-sunken",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-full bg-accent",
						style: { width: `${running || fired ? progress : 0}%` }
					})
				}),
				fired ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm font-semibold text-accent",
					children: "Waktu habis."
				}) : null
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-3 gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Jam",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						inputMode: "numeric",
						value: hours,
						onChange: (event) => setHours(event.target.value),
						disabled: running
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Menit",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						inputMode: "numeric",
						value: minutes,
						onChange: (event) => setMinutes(event.target.value),
						disabled: running
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Detik",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						inputMode: "numeric",
						value: seconds,
						onChange: (event) => setSeconds(event.target.value),
						disabled: running
					})
				})
			]
		}),
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, {
			tone: "danger",
			children: error
		}) : null,
		note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: note }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: "Alarm berbunyi di aplikasi. Notifikasi hanya jika izin diberikan. Menutup tab menghentikan timer." }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-2 gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "secondary",
				onClick: stop,
				children: "Berhenti"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				disabled: running,
				onClick: () => {
					const h = Number(hours);
					const m = Number(minutes);
					const s = Number(seconds);
					if (![
						h,
						m,
						s
					].every((n) => Number.isInteger(n) && n >= 0)) {
						setError("Isi jam, menit, dan detik dengan bilangan bulat.");
						return;
					}
					if (h > 48 || m > 59 || s > 59) {
						setError("Maksimum 48 jam, dan menit serta detik di bawah 60.");
						return;
					}
					const total = (h * 3600 + m * 60 + s) * 1e3;
					if (total <= 0) {
						setError("Durasi harus lebih dari nol.");
						return;
					}
					setError(null);
					primeAudio();
					if (typeof Notification !== "undefined" && Notification.permission === "default") Notification.requestPermission().then((permission) => {
						setNote(permission === "granted" ? "Notifikasi diizinkan." : "Notifikasi ditolak. Alarm tetap berbunyi di dalam aplikasi.");
					});
					else if (typeof Notification !== "undefined" && Notification.permission === "denied") setNote("Notifikasi diblokir browser. Alarm tetap berbunyi di dalam aplikasi selama tab terbuka.");
					else if (typeof Notification === "undefined") setNote("Browser ini tidak punya notifikasi. Alarm tetap berbunyi di dalam aplikasi.");
					start(total);
					setLeft(total);
				},
				children: "Mulai"
			})]
		}),
		endAt && running ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Notice, { children: [
			"Selesai sekitar ",
			new Date(endAt).toLocaleTimeString("id-ID", {
				hour: "2-digit",
				minute: "2-digit"
			}),
			"."
		] }) : null
	] });
}
function TimeDiff() {
	const [from, setFrom] = (0, import_react.useState)("");
	const [to, setTo] = (0, import_react.useState)("");
	const result = from && to ? diffDates(from, to) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 sm:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Tanggal awal",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
					type: "date",
					value: from,
					onChange: (event) => setFrom(event.target.value)
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Tanggal akhir",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
					type: "date",
					value: to,
					onChange: (event) => setTo(event.target.value)
				})
			})]
		}),
		!from || !to ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: "Pilih kedua tanggal. Perhitungan memakai tanggal kalender, bukan jam." }) : null,
		result && !result.ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, {
			tone: "danger",
			children: result.error
		}) : null,
		result?.ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "space-y-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-mute",
					children: result.days === 0 ? "Kedua tanggal sama." : result.days > 0 ? "Tanggal akhir lebih kemudian." : "Tanggal akhir lebih dahulu."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-4xl font-medium tabular-nums",
					children: result.absDays.toLocaleString("id-ID")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold",
					children: "hari kalender"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-mute",
					children: [
						result.years,
						" tahun, ",
						result.months,
						" bulan, ",
						result.daysPart,
						" hari",
						result.absDays >= 7 ? ` · ${(result.absDays / 7).toLocaleString("id-ID", { maximumFractionDigits: 2 })} minggu` : ""
					]
				})
			]
		}) : null
	] });
}
function TimeUntil() {
	const [date, setDate] = (0, import_react.useState)("");
	const [time, setTime] = (0, import_react.useState)("00:00");
	const [now, setNow] = (0, import_react.useState)(() => /* @__PURE__ */ new Date());
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => setNow(/* @__PURE__ */ new Date()), 250);
		return () => window.clearInterval(id);
	}, []);
	const result = date ? countdownTo(date, time, now) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 sm:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Tanggal",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
					type: "date",
					value: date,
					onChange: (event) => setDate(event.target.value)
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Jam",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
					type: "time",
					value: time,
					onChange: (event) => setTime(event.target.value)
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Notice, { children: [
			"Zona waktu perangkat: ",
			zoneName(now),
			". Tautan atau tanggal tidak dibuka otomatis."
		] }),
		!date ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: "Pilih tanggal tujuan." }) : null,
		result && !result.ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, {
			tone: "danger",
			children: result.error
		}) : null,
		result?.ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm font-semibold",
			children: result.past ? "Waktu itu sudah lewat" : "Sisa waktu"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 grid grid-cols-4 gap-2 text-center",
			children: [
				["Hari", result.days],
				["Jam", result.hours],
				["Menit", result.minutes],
				["Detik", result.seconds]
			].map(([label, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "font-mono text-2xl font-medium tabular-nums",
				children: Number(value).toLocaleString("id-ID")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-xs text-mute",
				children: label
			})] }, String(label)))
		})] }) : null
	] });
}
function ToolFrame({ id, children }) {
	const tool = getTool(id);
	const nav = useNav();
	const favorite = usePrefs((state) => state.favorites.includes(id));
	const toggleFavorite = usePrefs((state) => state.toggleFavorite);
	if (!tool) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rise mx-auto flex w-full max-w-3xl flex-col gap-4 px-4 pt-2 pb-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "flex items-center gap-1",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
					label: "Kembali",
					onClick: nav.back,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "truncate text-xl font-extrabold tracking-tight",
						children: tool.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-sm text-mute",
						children: tool.blurb
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
					label: favorite ? "Hapus dari favorit" : "Jadikan favorit",
					pressed: favorite,
					onClick: () => toggleFavorite(id),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: favorite ? "fill-accent text-accent" : "text-mute" })
				})
			]
		}), children]
	});
}
function ToolScreen({ id }) {
	const body = screenFor(id);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolFrame, {
		id,
		children: body
	});
}
function screenFor(id) {
	switch (id) {
		case "text-count": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextCount, {});
		case "text-case": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextCase, {});
		case "text-space": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextSpace, {});
		case "text-blank": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextBlank, {});
		case "text-shuffle": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextShuffle, {});
		case "text-reverse": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextReverse, {});
		case "text-dedupe": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextDedupe, {});
		case "gen-uuid": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GenUuid, {});
		case "gen-password": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GenPassword, {});
		case "gen-number": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GenNumber, {});
		case "gen-color": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GenColor, {});
		case "gen-lorem": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GenLorem, {});
		case "calc-basic": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalcBasic, {});
		case "calc-length": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalcLength, {});
		case "calc-weight": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalcWeight, {});
		case "calc-temp": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalcTemp, {});
		case "calc-volume": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalcVolume, {});
		case "calc-storage": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalcStorage, {});
		case "calc-percent": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalcPercent, {});
		case "time-clock": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TimeClock, {});
		case "time-stopwatch": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TimeStopwatch, {});
		case "time-timer": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TimeTimer, {});
		case "time-diff": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TimeDiff, {});
		case "time-until": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TimeUntil, {});
		case "qr-make": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrMake, {});
		case "qr-scan": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrScan, {});
		case "url-check": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UrlCheck, {});
		case "file-info": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileInfo, {});
	}
}
var TABS = [
	{
		id: "home",
		label: "Beranda",
		icon: House
	},
	{
		id: "tools",
		label: "Alat",
		icon: LayoutGrid
	},
	{
		id: "fav",
		label: "Favorit",
		icon: Star
	},
	{
		id: "settings",
		label: "Pengaturan",
		icon: Settings
	}
];
function XjoxApp() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToastProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(XjoxRoot, {}) });
}
function XjoxRoot() {
	const [minDone, setMinDone] = (0, import_react.useState)(false);
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	const onboarded = usePrefs((state) => state.onboarded);
	const finishOnboarding = usePrefs((state) => state.finishOnboarding);
	useThemeBinder();
	(0, import_react.useEffect)(() => {
		const timer = window.setTimeout(() => setMinDone(true), 700);
		const unsub = usePrefs.persist.onFinishHydration(() => setHydrated(true));
		if (usePrefs.persist.hasHydrated()) setHydrated(true);
		return () => {
			window.clearTimeout(timer);
			unsub();
		};
	}, []);
	if (!minDone || !hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Splash, {});
	if (!onboarded) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Onboarding, { onDone: finishOnboarding });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {});
}
function useThemeBinder() {
	const theme = usePrefs((state) => state.theme);
	(0, import_react.useEffect)(() => {
		const apply = () => {
			const mode = usePrefs.getState().theme;
			const dark = mode === "dark" || mode === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches;
			const root = document.documentElement;
			root.classList.toggle("dark", dark);
			root.style.colorScheme = dark ? "dark" : "light";
			const meta = document.querySelector("meta[name=\"theme-color\"]");
			const canvas = getComputedStyle(root).getPropertyValue("--color-canvas").trim();
			if (meta && canvas) meta.setAttribute("content", canvas);
		};
		apply();
		const media = window.matchMedia("(prefers-color-scheme: dark)");
		media.addEventListener("change", apply);
		return () => media.removeEventListener("change", apply);
	}, [theme]);
}
function Splash() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid h-dvh place-items-center bg-canvas px-6 text-ink",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col items-center gap-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, { className: "size-16" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-3xl font-extrabold tracking-tight",
						children: "XJOX"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium text-mute",
						children: "Tools"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-1 w-24 overflow-hidden rounded-full bg-sunken",
					"aria-hidden": "true",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "splash-bar h-full rounded-full bg-accent" })
				})
			]
		})
	});
}
var STEPS = [
	{
		icon: LayoutGrid,
		title: "Alat harian, satu tempat",
		body: "Teks, sandi, satuan, jam, QR, dan berkas. Tidak perlu akun."
	},
	{
		icon: Shield,
		title: "Tetap di perangkat Anda",
		body: "Hitungan dan riwayat disimpan lokal. Kamera hanya dipakai saat memindai."
	},
	{
		icon: Star,
		title: "Sematkan yang sering dipakai",
		body: "Tandai favorit supaya alat penting menunggu di beranda."
	}
];
function Onboarding({ onDone }) {
	const [step, setStep] = (0, import_react.useState)(0);
	const current = STEPS[step] ?? STEPS[0];
	const Icon = current.icon;
	const last = step === STEPS.length - 1;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex h-dvh w-full max-w-md flex-col bg-canvas px-5 py-6 text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "h-11 self-end px-2 text-sm font-semibold text-mute",
				onClick: onDone,
				children: "Lewati"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-1 flex-col justify-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-14 place-items-center rounded-card bg-sunken text-ink",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
							className: "size-7",
							strokeWidth: 1.75,
							"aria-hidden": "true"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-6 text-3xl font-extrabold tracking-tight",
						children: current.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-base leading-relaxed text-mute",
						children: current.body
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-4 flex gap-2",
				"aria-hidden": "true",
				children: STEPS.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `h-1.5 flex-1 rounded-full ${index === step ? "bg-accent" : "bg-sunken"}` }, item.title))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => {
					if (last) onDone();
					else setStep((value) => value + 1);
				},
				children: last ? "Mulai" : "Lanjut"
			})
		]
	});
}
function Shell() {
	const [tab, setTabState] = (0, import_react.useState)("home");
	const [overlay, setOverlay] = (0, import_react.useState)(null);
	const touch = usePrefs((state) => state.touch);
	const fired = useTimer((state) => state.fired);
	const acknowledge = useTimer((state) => state.acknowledge);
	const scroller = (0, import_react.useRef)(null);
	const nav = (0, import_react.useMemo)(() => ({
		tab,
		overlay,
		setTab: (next) => {
			setTabState(next);
			setOverlay(null);
		},
		openTool: (id) => {
			touch(id);
			setOverlay({
				kind: "tool",
				id
			});
		},
		openDoc: (id) => setOverlay({
			kind: "doc",
			id
		}),
		back: () => setOverlay(null)
	}), [
		overlay,
		tab,
		touch
	]);
	(0, import_react.useEffect)(() => {
		scroller.current?.scrollTo(0, 0);
	}, [tab, overlay]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(NavProvider, {
		value: nav,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TimerWatcher, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "h-dvh overflow-hidden bg-canvas text-ink",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "#isi",
				className: "sr-only focus:not-sr-only focus:absolute focus:top-3 focus:left-3 focus:z-50 focus:rounded-control focus:bg-card focus:px-3 focus:py-2",
				children: "Loncat ke isi"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex h-full max-w-6xl",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "hidden w-64 shrink-0 flex-col border-r border-line px-4 py-5 md:flex",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-6 flex items-center gap-3 px-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, { className: "size-10" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-extrabold tracking-tight",
							children: APP_NAME
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-mute",
							children: "Data tetap di perangkat"
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "flex flex-1 flex-col gap-1",
						"aria-label": "Utama",
						children: TABS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavButton, {
							item,
							active: tab === item.id && !overlay,
							onClick: () => nav.setTab(item.id),
							wide: true
						}, item.id))
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-0 flex-1 flex-col",
					children: [
						fired ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-3 bg-accent px-4 py-3 text-accent-ink",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-semibold",
								children: "Timer selesai."
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "h-11 rounded-control bg-card px-3 text-sm font-semibold text-ink",
								onClick: acknowledge,
								children: "Tutup"
							})]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
							id: "isi",
							ref: scroller,
							className: "min-h-0 flex-1 overflow-y-auto",
							children: overlay?.kind === "tool" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolScreen, { id: overlay.id }) : overlay?.kind === "doc" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocScreen, { id: overlay.id }) : tab === "home" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeTab, {}) : tab === "tools" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolsTab, {}) : tab === "fav" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FavoritesTab, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsTab, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
							className: "grid grid-cols-4 border-t border-line bg-card pb-safe md:hidden",
							"aria-label": "Utama",
							children: TABS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavButton, {
								item,
								active: tab === item.id && !overlay,
								onClick: () => nav.setTab(item.id)
							}, item.id))
						})
					]
				})]
			})]
		})]
	});
}
function NavButton({ item, active, onClick, wide = false }) {
	const Icon = item.icon;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		"aria-current": active ? "page" : void 0,
		className: wide ? `flex h-12 items-center gap-3 rounded-control px-3 text-sm font-semibold ${active ? "bg-sunken text-ink" : "text-mute"}` : `flex min-h-14 flex-col items-center justify-center gap-1 text-xs font-semibold ${active ? "text-accent" : "text-mute"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
			className: "size-5",
			strokeWidth: 1.75,
			"aria-hidden": "true"
		}), item.label]
	});
}
function TimerWatcher() {
	const running = useTimer((state) => state.running);
	const endAt = useTimer((state) => state.endAt);
	(0, import_react.useEffect)(() => {
		if (!running || endAt == null) return;
		const delay = Math.max(0, endAt - Date.now());
		const id = window.setTimeout(() => {
			const state = useTimer.getState();
			if (!state.running || state.endAt !== endAt) return;
			useTimer.setState({
				running: false,
				fired: true
			});
			ringTimer();
			if (typeof Notification !== "undefined" && Notification.permission === "granted") try {
				new Notification(APP_NAME, { body: "Timer selesai." });
			} catch {}
		}, delay);
		return () => window.clearTimeout(id);
	}, [endAt, running]);
	return null;
}
var SplitComponent = XjoxApp;
//#endregion
export { SplitComponent as component };
