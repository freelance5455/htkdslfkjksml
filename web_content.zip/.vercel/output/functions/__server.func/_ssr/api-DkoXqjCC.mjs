import { i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { r as getSql } from "./db-BUCdTnQY.mjs";
import { c as authMiddleware, d as isReaction, f as isRole, l as emailFor, m as parseYoutubeChannel, o as USER_RE, p as isSticker, t as HOME_KINDS, u as isKind } from "./model-Ck66RVeO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/api-DkoXqjCC.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function fail(error) {
	return {
		ok: false,
		error
	};
}
function text(value, max, label) {
	if (typeof value !== "string") return fail(`${label} غير صالح`);
	const cleaned = value.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, "").trim();
	if (cleaned.length > max) return fail(`${label} أطول من المسموح`);
	return {
		ok: true,
		value: cleaned
	};
}
function jpeg(value, max) {
	if (value == null || value === "") return {
		ok: true,
		value: null
	};
	if (typeof value !== "string" || !value.startsWith("data:image/jpeg;base64,") || value.length > max) return fail("الصورة غير صالحة أو كبيرة");
	return {
		ok: true,
		value
	};
}
async function accountUsername(sql, userId) {
	return ((await sql`select email from "user" where id = ${userId} limit 1`)[0]?.email ?? "").match(/^cg_([a-z0-9._-]+)@cutegirls\.app$/)?.[1] ?? null;
}
async function loadGroups(sql, userId) {
	return (await sql`
    select g.slug, g.name, g.blurb, g.forced,
      (select count(*) from group_members m where m.group_slug = g.slug) as members,
      exists(select 1 from group_members m where m.group_slug = g.slug and m.user_id = ${userId}) as joined
    from groups g
    order by g.sort
  `).map((row) => ({
		slug: row.slug,
		name: row.name,
		blurb: row.blurb,
		forced: Boolean(row.forced),
		members: Number(row.members),
		joined: Boolean(row.joined)
	}));
}
async function profileByUser(sql, userId) {
	return (await sql`
    select user_id, username, youtube_url, bio, avatar, banner, role
    from profiles where user_id = ${userId} limit 1
  `)[0] ?? null;
}
function mapProfile(row, counts, viewer, isFollowing) {
	return {
		userId: row.user_id,
		username: row.username,
		youtubeUrl: row.youtube_url,
		bio: row.bio,
		avatar: row.avatar,
		banner: row.banner,
		role: row.role,
		followers: counts.followers,
		following: counts.following,
		isSelf: row.user_id === viewer,
		isFollowing
	};
}
async function countsFor(sql, userId) {
	const rows = await sql`
    select
      (select count(*) from follows where following_id = ${userId}) as followers,
      (select count(*) from follows where follower_id = ${userId}) as following
  `;
	return {
		followers: Number(rows[0]?.followers ?? 0),
		following: Number(rows[0]?.following ?? 0)
	};
}
async function hydrate(sql, me, rows) {
	if (rows.length === 0) return [];
	const ids = rows.map((row) => row.id);
	const ph = ids.map((_, i) => `$${i + 1}`).join(", ");
	const [reactionRows, mineRows, commentRows] = await Promise.all([
		sql.query(`select post_id, kind, count(*)::int as n from reactions where post_id in (${ph}) group by post_id, kind`, ids),
		sql.query(`select post_id, kind from reactions where post_id in (${ph}) and user_id = $${ids.length + 1}`, [...ids, me]),
		sql.query(`select post_id, count(*)::int as n from comments where post_id in (${ph}) group by post_id`, ids)
	]);
	const reactions = /* @__PURE__ */ new Map();
	for (const row of reactionRows) {
		const bag = reactions.get(row.post_id) ?? {};
		bag[row.kind] = Number(row.n);
		reactions.set(row.post_id, bag);
	}
	const mine = new Map(mineRows.map((row) => [row.post_id, row.kind]));
	const comments = new Map(commentRows.map((row) => [row.post_id, Number(row.n)]));
	return rows.map((row) => ({
		id: row.id,
		userId: row.user_id,
		username: row.username,
		avatar: row.avatar,
		role: row.role,
		kind: row.kind,
		title: row.title,
		body: row.body,
		media: row.media,
		link: row.link,
		groupSlug: row.group_slug,
		groupName: row.group_name,
		createdAt: String(row.created_at),
		commentCount: comments.get(row.id) ?? 0,
		reactions: reactions.get(row.id) ?? {},
		myReaction: mine.get(row.id) ?? null
	}));
}
var POST_SELECT = `
  select p.id, p.user_id, p.kind, p.title, p.body, p.media, p.link, p.group_slug,
         p.created_at::text as created_at,
         pr.username, pr.avatar, pr.role,
         g.name as group_name
  from posts p
  join profiles pr on pr.user_id = p.user_id
  left join groups g on g.slug = p.group_slug
`;
var getMe_createServerFn_handler = createServerRpc({
	id: "10df2081b84e6bdb90c5972b72a41a145c7bdd994b51265b17fc5c525dc0c5e5",
	name: "getMe",
	filename: "src/lib/cutegirls/api.ts"
}, (opts) => getMe.__executeServer(opts));
var getMe = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getMe_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	const bound = await accountUsername(sql, context.userId);
	const row = await profileByUser(sql, context.userId);
	if (row) await sql`
        insert into group_members (group_slug, user_id)
        values ('everyone', ${context.userId})
        on conflict do nothing
      `;
	return {
		profile: row ? mapProfile(row, await countsFor(sql, row.user_id), context.userId, false) : null,
		accountUsername: bound,
		groups: await loadGroups(sql, context.userId)
	};
});
var createProfile_createServerFn_handler = createServerRpc({
	id: "cf3a0f7fe9f59c5a6b493b6ac38790209e74bb78da907bf1aa3f322c33bc57fb",
	name: "createProfile",
	filename: "src/lib/cutegirls/api.ts"
}, (opts) => createProfile.__executeServer(opts));
var createProfile = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(createProfile_createServerFn_handler, async ({ context, data }) => {
	const body = data ?? {};
	const username = text(body.username, 24, "اسم الحساب");
	if (!username.ok) return username;
	if (!USER_RE.test(username.value)) return fail("اسم الحساب من 3 إلى 24 حرفاً: إنجليزي، أرقام، نقطة أو شرطة.");
	const channel = parseYoutubeChannel(typeof body.youtubeUrl === "string" ? body.youtubeUrl : "");
	if (!channel) return fail("ضع رابط القناة بصيغة youtube.com/@username");
	if (channel.handle.toLowerCase() !== username.value.toLowerCase()) return fail("اسم الحساب يجب أن يطابق اسم قناة يوتيوب بعد @");
	if (typeof body.role !== "string" || !isRole(body.role)) return fail("اختر مستمع أو صانع");
	const sql = await getSql();
	if (await profileByUser(sql, context.userId)) return { ok: true };
	const bound = await accountUsername(sql, context.userId);
	if (bound && bound !== username.value.toLowerCase()) return fail("اسم الحساب مرتبط بالدخول ولا يمكن تغييره");
	if (!bound) {
		if ((await sql`select id from "user" where lower(email) = ${emailFor(username.value)} and id <> ${context.userId} limit 1`).length) return fail("اسم الحساب مستخدم");
	}
	if ((await sql`
      select user_id from profiles where lower(username) = ${username.value.toLowerCase()} limit 1
    `).length) return fail("اسم الحساب مستخدم");
	await sql`
      insert into profiles (user_id, username, youtube_url, role)
      values (${context.userId}, ${username.value}, ${channel.url}, ${body.role})
    `;
	await sql`
      insert into group_members (group_slug, user_id)
      values ('everyone', ${context.userId})
      on conflict do nothing
    `;
	return { ok: true };
});
var updateProfile_createServerFn_handler = createServerRpc({
	id: "39cf130be790703c237a038b6c549f38b272569365bc9817364bce59f45793b0",
	name: "updateProfile",
	filename: "src/lib/cutegirls/api.ts"
}, (opts) => updateProfile.__executeServer(opts));
var updateProfile = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(updateProfile_createServerFn_handler, async ({ context, data }) => {
	const body = data ?? {};
	const bio = text(body.bio ?? "", 280, "النبذة");
	if (!bio.ok) return bio;
	if (typeof body.role !== "string" || !isRole(body.role)) return fail("اختر مستمع أو صانع");
	const avatar = jpeg(body.avatar, 22e4);
	if (!avatar.ok) return avatar;
	const banner = jpeg(body.banner, 42e4);
	if (!banner.ok) return banner;
	if (!(await (await getSql())`
      update profiles
      set bio = ${bio.value}, role = ${body.role}, avatar = ${avatar.value}, banner = ${banner.value}
      where user_id = ${context.userId}
      returning user_id
    `).length) return fail("أنشئ الملف أولاً");
	return { ok: true };
});
var getProfile_createServerFn_handler = createServerRpc({
	id: "9ed34ca46dbede165b4089b01ff2af92b04dec2b12682fb1e88200069b4a88a6",
	name: "getProfile",
	filename: "src/lib/cutegirls/api.ts"
}, (opts) => getProfile.__executeServer(opts));
var getProfile = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(getProfile_createServerFn_handler, async ({ context, data }) => {
	const username = text(data?.username, 24, "اسم الحساب");
	if (!username.ok) return username;
	const sql = await getSql();
	const row = (await sql`
      select user_id, username, youtube_url, bio, avatar, banner, role
      from profiles where lower(username) = ${username.value.toLowerCase()} limit 1
    `)[0];
	if (!row) return fail("لا يوجد حساب بهذا الاسم");
	const follow = await sql`
      select 1 as ok from follows
      where follower_id = ${context.userId} and following_id = ${row.user_id} limit 1
    `;
	return {
		ok: true,
		profile: mapProfile(row, await countsFor(sql, row.user_id), context.userId, follow.length > 0)
	};
});
var listConnections_createServerFn_handler = createServerRpc({
	id: "6b6a3b41325c8db750c6913d16bdc8966820059d5e06aa20d5d748ad4261a0c1",
	name: "listConnections",
	filename: "src/lib/cutegirls/api.ts"
}, (opts) => listConnections.__executeServer(opts));
var listConnections = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(listConnections_createServerFn_handler, async ({ data }) => {
	const body = data ?? {};
	const username = text(body.username, 24, "اسم الحساب");
	if (!username.ok) return username;
	const dir = body.dir === "following" ? "following" : body.dir === "followers" ? "followers" : null;
	if (!dir) return fail("اتجاه غير معروف");
	const sql = await getSql();
	const owner = await sql`
      select user_id from profiles where lower(username) = ${username.value.toLowerCase()} limit 1
    `;
	if (!owner[0]) return fail("لا يوجد حساب بهذا الاسم");
	return {
		ok: true,
		people: dir === "followers" ? await sql`
            select pr.username, pr.avatar, pr.role, pr.bio
            from follows f
            join profiles pr on pr.user_id = f.follower_id
            where f.following_id = ${owner[0].user_id}
            order by f.created_at desc
            limit 50
          ` : await sql`
            select pr.username, pr.avatar, pr.role, pr.bio
            from follows f
            join profiles pr on pr.user_id = f.following_id
            where f.follower_id = ${owner[0].user_id}
            order by f.created_at desc
            limit 50
          `
	};
});
var setFollow_createServerFn_handler = createServerRpc({
	id: "df5dcafd3f887ee02840e103643b9be57f8f56cc7bbec0aaa13cf6efe21b0f16",
	name: "setFollow",
	filename: "src/lib/cutegirls/api.ts"
}, (opts) => setFollow.__executeServer(opts));
var setFollow = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(setFollow_createServerFn_handler, async ({ context, data }) => {
	const body = data ?? {};
	const username = text(body.username, 24, "اسم الحساب");
	if (!username.ok) return username;
	const follow = Boolean(body.follow);
	const sql = await getSql();
	if (!await profileByUser(sql, context.userId)) return fail("أنشئ الملف أولاً");
	const target = await sql`
      select user_id from profiles where lower(username) = ${username.value.toLowerCase()} limit 1
    `;
	if (!target[0]) return fail("لا يوجد حساب بهذا الاسم");
	if (target[0].user_id === context.userId) return fail("لا يمكن متابعة نفسك");
	if (follow) await sql`
        insert into follows (follower_id, following_id)
        values (${context.userId}, ${target[0].user_id})
        on conflict do nothing
      `;
	else await sql`
        delete from follows
        where follower_id = ${context.userId} and following_id = ${target[0].user_id}
      `;
	return {
		ok: true,
		following: follow,
		followers: (await countsFor(sql, target[0].user_id)).followers
	};
});
var searchUsers_createServerFn_handler = createServerRpc({
	id: "574d44646e0ff73b3f2993f0ef9ac16edd28322867424896bb8998ef48adb0ac",
	name: "searchUsers",
	filename: "src/lib/cutegirls/api.ts"
}, (opts) => searchUsers.__executeServer(opts));
var searchUsers = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(searchUsers_createServerFn_handler, async ({ data }) => {
	const raw = text(data?.q ?? "", 40, "البحث");
	const q = raw.ok ? raw.value.replace(/[%_]/g, "") : "";
	const sql = await getSql();
	return {
		ok: true,
		people: q ? await sql`
          select username, avatar, role, bio from profiles
          where lower(username) like ${"%" + q.toLowerCase() + "%"}
          order by username
          limit 24
        ` : await sql`
          select username, avatar, role, bio from profiles
          order by created_at desc
          limit 12
        `
	};
});
var listPosts_createServerFn_handler = createServerRpc({
	id: "9542a8617c2ac7eb707b4e506da74d6221bb9e700e01fa09492261c903374c7c",
	name: "listPosts",
	filename: "src/lib/cutegirls/api.ts"
}, (opts) => listPosts.__executeServer(opts));
var listPosts = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(listPosts_createServerFn_handler, async ({ context, data }) => {
	const query = data ?? {};
	const sql = await getSql();
	const params = [];
	const conds = [];
	const add = (sqlText, value) => {
		if (value === void 0) conds.push(sqlText);
		else {
			params.push(value);
			conds.push(sqlText.replace("?", `$${params.length}`));
		}
	};
	if (query.surface === "home") {
		const kind = typeof query.kind === "string" && isKind(query.kind) && HOME_KINDS.includes(query.kind) ? query.kind : null;
		if (kind) add("p.kind = ?", kind);
		else add(`p.kind in (${HOME_KINDS.map((k) => `'${k}'`).join(", ")})`);
		if (query.scope === "following") {
			params.push(context.userId);
			const me = `$${params.length}`;
			conds.push(`(p.user_id = ${me} or p.user_id in (select following_id from follows where follower_id = ${me}))`);
		}
	} else if (query.surface === "reels") add("p.kind = 'reel'");
	else if (query.surface === "subliminals") add("p.kind = 'subliminal'");
	else if (query.surface === "group") {
		const slug = text(query.slug, 32, "المجموعة");
		if (!slug.ok) return slug;
		add("p.group_slug = ?", slug.value);
	} else if (query.surface === "user") {
		const username = text(query.username, 24, "اسم الحساب");
		if (!username.ok) return username;
		add("lower(pr.username) = ?", username.value.toLowerCase());
	} else return fail("عرض غير معروف");
	const rows = await sql.query(`${POST_SELECT} where ${conds.join(" and ")} order by p.created_at desc limit 30`, params);
	return {
		ok: true,
		posts: await hydrate(sql, context.userId, rows)
	};
});
var createPost_createServerFn_handler = createServerRpc({
	id: "6e60f4de17398fa6ba06a08fa18838a053a78899dfc1a94a14db7431637432e1",
	name: "createPost",
	filename: "src/lib/cutegirls/api.ts"
}, (opts) => createPost.__executeServer(opts));
var createPost = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(createPost_createServerFn_handler, async ({ context, data }) => {
	const body = data ?? {};
	if (typeof body.kind !== "string" || !isKind(body.kind)) return fail("نوع المنشور غير معروف");
	const title = text(body.title ?? "", 120, "العنوان");
	if (!title.ok) return title;
	const copy = text(body.body ?? "", 2e3, "النص");
	if (!copy.ok) return copy;
	const kind = body.kind;
	if ((kind === "contest" || kind === "news" || kind === "subliminal") && !title.value) return fail("العنوان مطلوب");
	if (kind !== "reel" && !copy.value) return fail("اكتب شيئاً قبل النشر");
	if (kind === "reel" && !copy.value && !title.value) {}
	const media = jpeg(body.media, kind === "reel" ? 52e4 : 42e4);
	if (!media.ok) return media;
	if (kind === "reel" && !media.value) return fail("أضف صورة الميم أو الريل");
	if (kind !== "reel" && kind !== "subliminal" && media.value) return fail("الصورة متاحة للريلز والسيبلمنال");
	let link = null;
	if (typeof body.link === "string" && body.link.trim()) {
		if (kind !== "subliminal") return fail("الرابط للسيبلمنال فقط");
		try {
			const url = new URL(body.link.trim());
			if (url.protocol !== "https:" && url.protocol !== "http:") return fail("الرابط غير صالح");
			link = url.toString().slice(0, 400);
		} catch {
			return fail("الرابط غير صالح");
		}
	}
	const sql = await getSql();
	if (!await profileByUser(sql, context.userId)) return fail("أنشئ الملف أولاً");
	let group = null;
	if (typeof body.groupSlug === "string" && body.groupSlug.trim()) {
		const slug = text(body.groupSlug, 32, "المجموعة");
		if (!slug.ok) return slug;
		if (!(await sql`
        select 1 as ok from group_members
        where group_slug = ${slug.value} and user_id = ${context.userId} limit 1
      `).length) return fail("انضم إلى المجموعة قبل النشر فيها");
		group = slug.value;
	}
	await sql`
      insert into posts (id, user_id, kind, title, body, media, link, group_slug)
      values (${crypto.randomUUID()}, ${context.userId}, ${kind}, ${title.value}, ${copy.value}, ${media.value}, ${link}, ${group})
    `;
	return { ok: true };
});
var deletePost_createServerFn_handler = createServerRpc({
	id: "38860f1f8afcd6ac8efd92bc29904b5d08857f59bba867350ec65396474aa30a",
	name: "deletePost",
	filename: "src/lib/cutegirls/api.ts"
}, (opts) => deletePost.__executeServer(opts));
var deletePost = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(deletePost_createServerFn_handler, async ({ context, data }) => {
	const id = text(data?.id, 80, "المنشور");
	if (!id.ok) return id;
	if (!(await (await getSql())`
      delete from posts where id = ${id.value} and user_id = ${context.userId} returning id
    `).length) return fail("لا يمكن حذف هذا المنشور");
	return { ok: true };
});
var setReaction_createServerFn_handler = createServerRpc({
	id: "4729df184b7216d7fd2bdfc5e8e9d78dddb2fff8d7d111ff9cf178ab58f299aa",
	name: "setReaction",
	filename: "src/lib/cutegirls/api.ts"
}, (opts) => setReaction.__executeServer(opts));
var setReaction = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(setReaction_createServerFn_handler, async ({ context, data }) => {
	const body = data ?? {};
	const id = text(body.postId, 80, "المنشور");
	if (!id.ok) return id;
	if (typeof body.kind !== "string" || !isReaction(body.kind)) return fail("لمسة غير معروفة");
	const sql = await getSql();
	if (!await profileByUser(sql, context.userId)) return fail("أنشئ الملف أولاً");
	if (!(await sql`select id from posts where id = ${id.value} limit 1`).length) return fail("المنشور غير موجود");
	if ((await sql`
      select kind from reactions where post_id = ${id.value} and user_id = ${context.userId} limit 1
    `)[0]?.kind === body.kind) await sql`delete from reactions where post_id = ${id.value} and user_id = ${context.userId}`;
	else await sql`
        insert into reactions (post_id, user_id, kind)
        values (${id.value}, ${context.userId}, ${body.kind})
        on conflict (post_id, user_id) do update set kind = excluded.kind
      `;
	const rows = await sql`
      select kind, count(*)::int as n from reactions where post_id = ${id.value} group by kind
    `;
	const mine = await sql`
      select kind from reactions where post_id = ${id.value} and user_id = ${context.userId} limit 1
    `;
	const reactions = {};
	for (const row of rows) reactions[row.kind] = Number(row.n);
	return {
		ok: true,
		reactions,
		myReaction: mine[0]?.kind ?? null
	};
});
var listComments_createServerFn_handler = createServerRpc({
	id: "3fb99b9f457e53f883694bd8e241e720476bc82c4ac0aa447b2508a13a457d02",
	name: "listComments",
	filename: "src/lib/cutegirls/api.ts"
}, (opts) => listComments.__executeServer(opts));
var listComments = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(listComments_createServerFn_handler, async ({ context, data }) => {
	const id = text(data?.postId, 80, "المنشور");
	if (!id.ok) return id;
	return {
		ok: true,
		comments: (await (await getSql())`
      select c.id, pr.username, pr.avatar, c.body, c.sticker, c.created_at::text as created_at, c.user_id
      from comments c
      join profiles pr on pr.user_id = c.user_id
      where c.post_id = ${id.value}
      order by c.created_at asc
      limit 80
    `).map((row) => ({
			id: row.id,
			username: row.username,
			avatar: row.avatar,
			body: row.body,
			sticker: row.sticker,
			createdAt: String(row.created_at),
			mine: row.user_id === context.userId
		}))
	};
});
var addComment_createServerFn_handler = createServerRpc({
	id: "2fa458101dd0d7e9b00b0efe794a35708b2222b8d0591e9b5d51a17f4fc638e9",
	name: "addComment",
	filename: "src/lib/cutegirls/api.ts"
}, (opts) => addComment.__executeServer(opts));
var addComment = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(addComment_createServerFn_handler, async ({ context, data }) => {
	const body = data ?? {};
	const postId = text(body.postId, 80, "المنشور");
	if (!postId.ok) return postId;
	const copy = text(body.body ?? "", 500, "التعليق");
	if (!copy.ok) return copy;
	const sticker = typeof body.sticker === "string" && body.sticker ? body.sticker : null;
	if (sticker && !isSticker(sticker)) return fail("ملصق غير معروف");
	if (!copy.value && !sticker) return fail("اكتب تعليقاً أو اختر ملصقاً");
	const sql = await getSql();
	if (!await profileByUser(sql, context.userId)) return fail("أنشئ الملف أولاً");
	if (!(await sql`select id from posts where id = ${postId.value} limit 1`).length) return fail("المنشور غير موجود");
	await sql`
      insert into comments (id, post_id, user_id, body, sticker)
      values (${crypto.randomUUID()}, ${postId.value}, ${context.userId}, ${copy.value}, ${sticker})
    `;
	return { ok: true };
});
var deleteComment_createServerFn_handler = createServerRpc({
	id: "d98ea40f758a0c2078be3bc1693b1e7af8781795d0d7bff4f1323f7723014dcb",
	name: "deleteComment",
	filename: "src/lib/cutegirls/api.ts"
}, (opts) => deleteComment.__executeServer(opts));
var deleteComment = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(deleteComment_createServerFn_handler, async ({ context, data }) => {
	const id = text(data?.id, 80, "التعليق");
	if (!id.ok) return id;
	if (!(await (await getSql())`
      delete from comments where id = ${id.value} and user_id = ${context.userId} returning id
    `).length) return fail("لا يمكن حذف هذا التعليق");
	return { ok: true };
});
var joinGroup_createServerFn_handler = createServerRpc({
	id: "945e2591eb18ce912a8a81a1ae424da6ca4326c0bd73040b2fbd3051de0f9e29",
	name: "joinGroup",
	filename: "src/lib/cutegirls/api.ts"
}, (opts) => joinGroup.__executeServer(opts));
var joinGroup = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(joinGroup_createServerFn_handler, async ({ context, data }) => {
	const slug = text(data?.slug, 32, "المجموعة");
	if (!slug.ok) return slug;
	const sql = await getSql();
	if (!await profileByUser(sql, context.userId)) return fail("أنشئ الملف أولاً");
	if (!(await sql`select slug from groups where slug = ${slug.value} limit 1`).length) return fail("المجموعة غير موجودة");
	await sql`
      insert into group_members (group_slug, user_id)
      values (${slug.value}, ${context.userId})
      on conflict do nothing
    `;
	return { ok: true };
});
var leaveGroup_createServerFn_handler = createServerRpc({
	id: "f296d5c5dbe0b9a848405a84e2eb794aa5451335c16da8828375bb5d5cf25b5c",
	name: "leaveGroup",
	filename: "src/lib/cutegirls/api.ts"
}, (opts) => leaveGroup.__executeServer(opts));
var leaveGroup = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(leaveGroup_createServerFn_handler, async ({ context, data }) => {
	const slug = text(data?.slug, 32, "المجموعة");
	if (!slug.ok) return slug;
	const sql = await getSql();
	const group = await sql`select forced from groups where slug = ${slug.value} limit 1`;
	if (!group.length) return fail("المجموعة غير موجودة");
	if (group[0].forced) return fail("هذه المجموعة شاملة ولا تُغادر");
	await sql`delete from group_members where group_slug = ${slug.value} and user_id = ${context.userId}`;
	return { ok: true };
});
var listGroupMembers_createServerFn_handler = createServerRpc({
	id: "3f4ab84a8464eed4bfa6af49416e9bba3471a6ea166a7ea7b3e0a56a5999869e",
	name: "listGroupMembers",
	filename: "src/lib/cutegirls/api.ts"
}, (opts) => listGroupMembers.__executeServer(opts));
var listGroupMembers = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(listGroupMembers_createServerFn_handler, async ({ data }) => {
	const slug = text(data?.slug, 32, "المجموعة");
	if (!slug.ok) return slug;
	return {
		ok: true,
		people: await (await getSql())`
      select pr.username, pr.avatar, pr.role, pr.bio
      from group_members m
      join profiles pr on pr.user_id = m.user_id
      where m.group_slug = ${slug.value}
      order by m.joined_at asc
      limit 48
    `
	};
});
//#endregion
export { addComment_createServerFn_handler, createPost_createServerFn_handler, createProfile_createServerFn_handler, deleteComment_createServerFn_handler, deletePost_createServerFn_handler, getMe_createServerFn_handler, getProfile_createServerFn_handler, joinGroup_createServerFn_handler, leaveGroup_createServerFn_handler, listComments_createServerFn_handler, listConnections_createServerFn_handler, listGroupMembers_createServerFn_handler, listPosts_createServerFn_handler, searchUsers_createServerFn_handler, setFollow_createServerFn_handler, setReaction_createServerFn_handler, updateProfile_createServerFn_handler };
