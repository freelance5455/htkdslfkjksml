import { n as FALLBACK_FX } from "./catalog-D0BjXlW4.mjs";
import { t as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-A6pJPYTF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/market.functions-atdlPpHr.js
var YAHOO_RE = /^[A-Z0-9.^=-]{1,24}$/;
var GECKO_RE = /^[a-z0-9-]{1,40}$/;
async function getJson(url, ms = 12e3) {
	const response = await fetch(url, {
		headers: {
			accept: "application/json",
			"user-agent": "Mozilla/5.0"
		},
		signal: AbortSignal.timeout(ms)
	});
	if (!response.ok) throw new Error(`${response.status}`);
	return response.json();
}
function isoDaysAgo(days) {
	const date = /* @__PURE__ */ new Date();
	date.setUTCDate(date.getUTCDate() - days);
	return date.toISOString().slice(0, 10);
}
function todayIso() {
	return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
}
function downsample(items, max) {
	if (items.length <= max) return items;
	const out = [];
	const step = (items.length - 1) / (max - 1);
	for (let i = 0; i < max; i += 1) out.push(items[Math.round(i * step)]);
	return out;
}
function asCurrency(value, fallback) {
	if (value === "EUR" || value === "USD" || value === "HUF" || value === "GBP") return value;
	if (value === "GBp" || value === "GBX") return "GBP";
	return fallback;
}
function scalePence(currency, price) {
	if (currency === "GBp" || currency === "GBX") return price / 100;
	return price;
}
async function loadFx(start) {
	const latest = await getJson("https://api.frankfurter.app/latest?from=USD&to=HUF,EUR,GBP");
	const historyRaw = await getJson(`https://api.frankfurter.app/${start}..${todayIso()}?from=USD&to=HUF,EUR,GBP`);
	const toFx = (rates) => {
		const usdHuf = rates?.HUF;
		const eurPerUsd = rates?.EUR;
		const gbpPerUsd = rates?.GBP;
		if (!usdHuf || !eurPerUsd || !gbpPerUsd) return null;
		return {
			usdHuf,
			eurHuf: usdHuf / eurPerUsd,
			gbpHuf: usdHuf / gbpPerUsd
		};
	};
	const fx = toFx(latest.rates) ?? FALLBACK_FX;
	const history = [];
	for (const [date, rates] of Object.entries(historyRaw.rates ?? {}).sort(([a], [b]) => a.localeCompare(b))) {
		const point = toFx(rates);
		if (!point) continue;
		history.push({
			date,
			...point
		});
	}
	return {
		fx,
		history: downsample(history, 90)
	};
}
function fxOn(history, date, fallback) {
	let best = null;
	for (const point of history) if (point.date <= date) best = point;
	else break;
	return best ?? history[0] ?? fallback;
}
function toUsd(price, currency, fx) {
	if (currency === "USD") return price;
	if (fx.usdHuf <= 0) return price;
	if (currency === "EUR") return price * fx.eurHuf / fx.usdHuf;
	if (currency === "GBP") return price * fx.gbpHuf / fx.usdHuf;
	return price / fx.usdHuf;
}
async function loadYahoo(ticker, range, fxHistory, fx) {
	const result = (await getJson(`https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(ticker)}?range=${range}&interval=${range === "5y" ? "1mo" : "1wk"}`)).chart?.result?.[0];
	if (!result?.meta) throw new Error("nincs jegyzés");
	const listed = result.meta.currency;
	const currency = asCurrency(listed, "USD");
	const price = scalePence(listed, result.meta.regularMarketPrice ?? 0);
	const stamps = result.timestamp ?? [];
	const closes = result.indicators?.quote?.[0]?.close ?? [];
	const history = [];
	for (let i = 0; i < stamps.length; i += 1) {
		const close = closes[i];
		if (close == null || !Number.isFinite(close)) continue;
		const date = (/* @__PURE__ */ new Date(stamps[i] * 1e3)).toISOString().slice(0, 10);
		const native = scalePence(listed, close);
		history.push({
			date,
			usd: toUsd(native, currency, fxOn(fxHistory, date, fx))
		});
	}
	return {
		price,
		currency,
		changePct: result.meta.regularMarketChangePercent ?? null,
		history: downsample(history, 80)
	};
}
async function loadGeckoQuotes(ids) {
	if (!ids.length) return {};
	const data = await getJson(`https://api.coingecko.com/api/v3/simple/price?ids=${ids.join(",")}&vs_currencies=usd&include_24hr_change=true`);
	const out = {};
	for (const id of ids) {
		const usd = data[id]?.usd;
		if (usd && usd > 0) out[id] = {
			usd,
			change: data[id]?.usd_24h_change ?? null
		};
	}
	return out;
}
async function loadGeckoHistory(id, days) {
	const data = await getJson(`https://api.coingecko.com/api/v3/coins/${encodeURIComponent(id)}/market_chart?vs_currency=usd&days=${days}`);
	const points = [];
	let last = "";
	for (const [ms, price] of data.prices ?? []) {
		if (!Number.isFinite(price)) continue;
		const date = new Date(ms).toISOString().slice(0, 10);
		if (date === last) {
			points[points.length - 1] = {
				date,
				usd: price
			};
			continue;
		}
		last = date;
		points.push({
			date,
			usd: price
		});
	}
	return downsample(points, 80);
}
async function pool(items, size, task) {
	let cursor = 0;
	await Promise.all(Array.from({ length: Math.min(size, items.length) }, async () => {
		while (cursor < items.length) {
			const index = cursor;
			cursor += 1;
			await task(items[index]);
		}
	}));
}
async function loadMarket(request) {
	const errors = [];
	const days = request.range === "6mo" ? 183 : request.range === "1y" ? 366 : 1826;
	let fx = FALLBACK_FX;
	let fxHistory = [];
	let fxLive = false;
	try {
		const loaded = await loadFx(isoDaysAgo(days));
		fx = loaded.fx;
		fxHistory = loaded.history;
		fxLive = true;
	} catch {
		errors.push("A forintárfolyam most nem frissült.");
	}
	const quotes = {};
	const history = {};
	const instruments = request.instruments.slice(0, 24);
	const geckoIds = [...new Set(instruments.map((item) => item.gecko).filter((id) => !!id && GECKO_RE.test(id)))];
	let geckoQuotes = {};
	if (geckoIds.length) try {
		geckoQuotes = await loadGeckoQuotes(geckoIds);
	} catch {
		errors.push("A kriptojegyzés most nem elérhető.");
	}
	await pool(instruments, 4, async (instrument) => {
		try {
			if (instrument.gecko && geckoQuotes[instrument.gecko]) {
				const quote = geckoQuotes[instrument.gecko];
				quotes[instrument.symbol] = {
					price: quote.usd,
					currency: "USD",
					changePct: quote.change
				};
				try {
					history[instrument.symbol] = await loadGeckoHistory(instrument.gecko, days);
				} catch {
					errors.push(`${instrument.symbol}: az árgörbe kimaradt.`);
				}
				return;
			}
			if (instrument.yahoo && YAHOO_RE.test(instrument.yahoo)) {
				const loaded = await loadYahoo(instrument.yahoo, request.range, fxHistory, fx);
				quotes[instrument.symbol] = {
					price: loaded.price,
					currency: loaded.currency,
					changePct: loaded.changePct
				};
				history[instrument.symbol] = loaded.history;
				return;
			}
		} catch {
			errors.push(`${instrument.symbol}: nincs élő ár.`);
		}
	});
	return {
		asOf: (/* @__PURE__ */ new Date()).toISOString(),
		fxLive,
		fx,
		quotes,
		history,
		fxHistory,
		errors: [...new Set(errors)].slice(0, 8)
	};
}
var RANGES = /* @__PURE__ */ new Set([
	"6mo",
	"1y",
	"5y"
]);
var CURRENCIES = /* @__PURE__ */ new Set([
	"HUF",
	"USD",
	"EUR",
	"GBP"
]);
function cleanRequest(input) {
	const data = input ?? {};
	return {
		range: RANGES.has(data.range) ? data.range : "1y",
		instruments: (Array.isArray(data.instruments) ? data.instruments : []).slice(0, 24).flatMap((item) => {
			if (!item || typeof item !== "object") return [];
			const row = item;
			const symbol = String(row.symbol ?? "").trim().toUpperCase().slice(0, 16);
			if (!/^[A-Z0-9]{1,16}$/.test(symbol)) return [];
			return [{
				symbol,
				currency: CURRENCIES.has(row.currency) ? row.currency : "USD",
				yahoo: typeof row.yahoo === "string" ? row.yahoo.toUpperCase().slice(0, 24) : void 0,
				gecko: typeof row.gecko === "string" ? row.gecko.toLowerCase().slice(0, 40) : void 0
			}];
		})
	};
}
var fetchMarket_createServerFn_handler = createServerRpc({
	id: "a6eda8ba56e67e5554ad9d89a791655f45c97cbd7c37c474b0f994145e7ab731",
	name: "fetchMarket",
	filename: "src/lib/market.functions.ts"
}, (opts) => fetchMarket.__executeServer(opts));
var fetchMarket = createServerFn({ method: "POST" }).validator(cleanRequest).handler(fetchMarket_createServerFn_handler, async ({ data }) => loadMarket(data));
//#endregion
export { fetchMarket_createServerFn_handler };
