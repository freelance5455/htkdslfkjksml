import { x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { l as Download } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/app-shell-BNnfZJ-W.js
var import_jsx_runtime = require_jsx_runtime();
function AppShell({ children, peek = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid min-h-dvh w-full max-w-6xl lg:grid-cols-[minmax(0,26.5rem)_minmax(0,1fr)] lg:gap-10 lg:px-8 lg:py-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative mx-auto flex min-h-dvh w-full max-w-md flex-col bg-bg lg:max-w-none lg:min-h-[44rem] lg:overflow-hidden lg:rounded-[2rem] lg:shadow-[var(--shadow-border),0_24px_80px_rgba(0,0,0,0.45)]",
				children
			}), peek ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "hidden flex-col justify-center lg:flex",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium uppercase tracking-widest text-primary",
						children: "Android project"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 max-w-md text-4xl font-semibold tracking-tight text-fg",
						children: "Vishal Tools, ready for Android Studio."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-md text-base leading-relaxed text-muted",
						children: "This preview uses your browser. The download is a real Kotlin + Jetpack Compose app you can open on your computer and build into an APK."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/studio",
						className: "mt-8 inline-flex h-12 w-fit items-center gap-2 rounded-2xl bg-primary px-5 text-sm font-semibold text-bg transition-transform duration-150 ease-out active:scale-[0.96]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), "Get Android Studio project"]
					})
				]
			}) : null]
		})
	});
}
function ScreenBody({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-1 flex-col px-5 pb-8 pt-4 lg:px-6 lg:pt-6",
		children
	});
}
//#endregion
export { ScreenBody as n, AppShell as t };
