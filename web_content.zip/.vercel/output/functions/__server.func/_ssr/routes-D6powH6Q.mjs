import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as PenLine, i as Square, o as Menu, r as Trash2, t as X } from "../_libs/lucide-react.mjs";
import { a as chamberById, i as MODEL, n as CHAMBERS, o as titleFrom, r as MAX_CHARS, s as previewPathPrefix } from "./router-DSeUOWEd.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-D6powH6Q.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STORAGE_KEY = "ardania.threads.v1";
function apiPath(path) {
	if (typeof window === "undefined") return path;
	const prefix = previewPathPrefix(window.location.hostname, window.location.pathname);
	return prefix ? `${prefix}${path}` : path;
}
function loadThreads() {
	try {
		const raw = localStorage.getItem(STORAGE_KEY);
		if (!raw) return [];
		const parsed = JSON.parse(raw);
		if (!Array.isArray(parsed)) return [];
		return parsed.filter((item) => item && typeof item.id === "string" && Array.isArray(item.messages));
	} catch {
		return [];
	}
}
function RichText({ text }) {
	const parts = text.split("```");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-3",
		children: parts.map((part, index) => {
			if (index % 2 === 1) {
				const breakAt = part.indexOf("\n");
				const code = (breakAt === -1 ? part : part.slice(breakAt + 1)).replace(/\n$/, "");
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
					className: "overflow-x-auto rounded-md bg-bg px-3 py-3 font-mono text-sm leading-relaxed text-fg",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: code })
				}, index);
			}
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Prose, { text: part }, index);
		})
	});
}
function inlineBits(text) {
	return text.split(/(\*\*[^*]+\*\*)/g).map((bit, index) => {
		if (bit.startsWith("**") && bit.endsWith("**")) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
			className: "font-medium text-fg",
			children: bit.slice(2, -2)
		}, index);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: bit }, index);
	});
}
function Prose({ text }) {
	const blocks = text.trim().split(/\n{2,}/).filter(Boolean);
	if (blocks.length === 0) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-3",
		children: blocks.map((block, index) => {
			const lines = block.split("\n");
			if (lines.every((line) => /^[-*]\s+/.test(line.trim()))) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-1.5 pl-4",
				children: lines.map((line, lineIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "list-disc text-pretty leading-relaxed",
					children: inlineBits(line.trim().replace(/^[-*]\s+/, ""))
				}, lineIndex))
			}, index);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-pretty leading-relaxed",
				children: inlineBits(block)
			}, index);
		})
	});
}
function ArdaniaStudio() {
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	const [threads, setThreads] = (0, import_react.useState)([]);
	const [activeId, setActiveId] = (0, import_react.useState)(null);
	const [chamber, setChamber] = (0, import_react.useState)("rada");
	const [draft, setDraft] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const [ready, setReady] = (0, import_react.useState)(null);
	const [navOpen, setNavOpen] = (0, import_react.useState)(false);
	const abortRef = (0, import_react.useRef)(null);
	const scrollerRef = (0, import_react.useRef)(null);
	const fieldRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const stored = loadThreads();
		setThreads(stored);
		setHydrated(true);
		const controller = new AbortController();
		fetch(apiPath("/api/ardania"), { signal: controller.signal }).then((res) => res.json()).then((body) => setReady(Boolean(body.ready))).catch(() => setReady(null));
		return () => controller.abort();
	}, []);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		localStorage.setItem(STORAGE_KEY, JSON.stringify(threads));
	}, [threads, hydrated]);
	const active = threads.find((item) => item.id === activeId) ?? null;
	const shownChamber = active ? active.chamber : chamber;
	const meta = chamberById(shownChamber);
	(0, import_react.useEffect)(() => {
		const node = scrollerRef.current;
		if (!node) return;
		node.scrollTop = node.scrollHeight;
	}, [active?.messages, busy]);
	const ordered = (0, import_react.useMemo)(() => [...threads].sort((a, b) => b.updatedAt - a.updatedAt), [threads]);
	function openThread(id) {
		const next = threads.find((item) => item.id === id);
		if (!next || busy) return;
		setActiveId(id);
		setChamber(next.chamber);
		setError(null);
		setNavOpen(false);
	}
	function startFresh(nextChamber = chamber) {
		if (busy) return;
		setActiveId(null);
		setChamber(nextChamber);
		setDraft("");
		setError(null);
		setNavOpen(false);
		fieldRef.current?.focus();
	}
	function pickChamber(next) {
		if (busy) return;
		if (active && active.messages.length > 0 && active.chamber !== next) {
			startFresh(next);
			return;
		}
		setChamber(next);
		setError(null);
	}
	function removeThread(id) {
		if (busy) return;
		setThreads((current) => current.filter((item) => item.id !== id));
		if (activeId === id) setActiveId(null);
	}
	function stop() {
		abortRef.current?.abort();
	}
	async function send(text) {
		const content = text.trim();
		if (!content || busy || content.length > 4e3) return;
		const threadId = activeId ?? crypto.randomUUID();
		const now = Date.now();
		const userMessage = {
			id: crypto.randomUUID(),
			role: "user",
			content,
			createdAt: now
		};
		const assistantId = crypto.randomUUID();
		const useChamber = active?.chamber ?? chamber;
		setThreads((current) => {
			if (!current.find((item) => item.id === threadId)) return [{
				id: threadId,
				title: titleFrom(content),
				chamber: useChamber,
				updatedAt: now,
				messages: [userMessage, {
					id: assistantId,
					role: "assistant",
					content: "",
					createdAt: now
				}]
			}, ...current];
			return current.map((item) => item.id === threadId ? {
				...item,
				updatedAt: now,
				messages: [
					...item.messages,
					userMessage,
					{
						id: assistantId,
						role: "assistant",
						content: "",
						createdAt: now
					}
				]
			} : item);
		});
		setActiveId(threadId);
		setDraft("");
		setBusy(true);
		setError(null);
		const history = [...(active?.messages ?? []).map((item) => ({
			role: item.role,
			content: item.content
		})), {
			role: "user",
			content
		}].filter((item) => item.content.trim());
		const controller = new AbortController();
		abortRef.current = controller;
		const writeAssistant = (value) => {
			setThreads((current) => current.map((item) => item.id !== threadId ? item : {
				...item,
				updatedAt: Date.now(),
				messages: item.messages.map((message) => message.id === assistantId ? {
					...message,
					content: value
				} : message)
			}));
		};
		try {
			const response = await fetch(apiPath("/api/ardania"), {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				signal: controller.signal,
				body: JSON.stringify({
					chamber: useChamber,
					messages: history.slice(-12)
				})
			});
			const body = await response.json().catch(() => null);
			if (!response.ok || !body?.text) throw new Error(body?.error || "Сервіс не відповів.");
			writeAssistant(body.text);
		} catch (reason) {
			if (controller.signal.aborted) setThreads((current) => current.map((item) => item.id !== threadId ? item : {
				...item,
				messages: item.messages.flatMap((message) => {
					if (message.id !== assistantId) return [message];
					if (!message.content.trim()) return [];
					return [message];
				})
			}));
			else {
				const message = reason instanceof Error ? reason.message : "Щось пішло не так.";
				setError(message);
				setThreads((current) => current.map((item) => item.id !== threadId ? item : {
					...item,
					messages: item.messages.filter((entry) => entry.id !== assistantId)
				}));
			}
		} finally {
			setBusy(false);
			abortRef.current = null;
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-dvh min-h-0 bg-bg text-fg",
		children: [
			navOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-label": "Закрити список",
				className: "fixed inset-0 z-20 bg-ink/70 lg:hidden",
				onClick: () => setNavOpen(false)
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "drawer fixed inset-y-0 left-0 z-30 flex w-80 flex-col border-r border-line bg-surface lg:static lg:translate-x-0 " + (navOpen ? "translate-x-0" : "-translate-x-full"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-3 px-5 pt-6 pb-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-3xl leading-none tracking-tight text-fg",
							children: "Ardania"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: "Власний сервіс мислення"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "grid size-11 place-items-center rounded-md text-muted lg:hidden",
							"aria-label": "Закрити",
							onClick: () => setNavOpen(false),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "px-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => startFresh(chamber),
							className: "flex h-11 w-full items-center justify-center gap-2 rounded-md bg-paper text-sm font-medium text-ink",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, { className: "size-4" }), "Нова розмова"]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 px-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium tracking-wide text-faint uppercase",
							children: "Палати"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-3 space-y-1",
							children: CHAMBERS.map((item) => {
								const selected = shownChamber === item.id && !active;
								const current = active?.chamber === item.id;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => pickChamber(item.id),
									className: "w-full rounded-md px-3 py-2.5 text-left " + (selected || current ? "bg-raised text-fg" : "text-muted hover:bg-raised/70"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-sm font-medium",
										children: item.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-0.5 block text-xs leading-snug text-faint",
										children: item.line
									})]
								}) }, item.id);
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 min-h-0 flex-1 overflow-y-auto px-3 pb-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "px-2 text-xs font-medium tracking-wide text-faint uppercase",
							children: "Розмови"
						}), ordered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "px-2 pt-3 text-sm text-faint",
							children: "Поки порожньо. Пам'ять лишається в цьому браузері."
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-2 space-y-1",
							children: ordered.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "group flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => openThread(item.id),
									className: "min-w-0 flex-1 rounded-md px-2 py-2 text-left " + (item.id === activeId ? "bg-raised" : "hover:bg-raised/70"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block truncate text-sm text-fg",
										children: item.title
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-0.5 block text-xs text-faint",
										children: chamberById(item.chamber).name
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-label": "Видалити розмову",
									onClick: () => removeThread(item.id),
									className: "grid size-11 shrink-0 place-items-center rounded-md text-faint opacity-100 lg:opacity-0 lg:group-hover:opacity-100",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
								})]
							}, item.id))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border-t border-line px-5 py-4 text-xs leading-relaxed text-faint",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium text-muted",
							children: "Сервіс Ardania"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1",
							children: [
								"Модель ",
								MODEL,
								". Відповідь до 700 токенів. Виклик лише після вашого запиту."
							]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "flex min-w-0 flex-1 flex-col",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "flex items-center gap-3 border-b border-line px-4 py-3 lg:px-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "grid size-11 place-items-center rounded-md border border-line lg:hidden",
								"aria-label": "Відкрити палати",
								onClick: () => setNavOpen(true),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate font-display text-xl leading-none tracking-tight",
									children: meta.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 truncate text-xs text-faint",
									children: meta.line
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "hidden text-xs text-faint sm:block",
								children: ready === false ? "Сервіс недоступний" : `${MODEL} · сервер Ardania`
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						ref: scrollerRef,
						className: "min-h-0 flex-1 overflow-y-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto flex w-full max-w-3xl flex-col gap-6 px-4 py-8 lg:px-8",
							children: [!active || active.messages.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
								className: "animate-rise pt-6 sm:pt-16",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-medium tracking-widest text-mist uppercase",
										children: "Ardania"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
										className: "mt-3 max-w-xl font-display text-4xl leading-tight tracking-tight text-balance sm:text-5xl",
										children: "Окремий голос, не чужий чат."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-4 max-w-xl text-base leading-relaxed text-pretty text-muted",
										children: "Три палати одного сервісу. Рада вирішує, Майстерня робить, Архів стискає. Розмова лишається лише на цьому пристрої."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-8 grid gap-3 sm:grid-cols-3",
										children: CHAMBERS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => pickChamber(item.id),
											className: "rounded-lg border px-4 py-4 text-left " + (shownChamber === item.id ? "border-mist bg-raised" : "border-line bg-surface hover:border-mist"),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "block font-display text-2xl tracking-tight",
												children: item.name
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "mt-2 block text-sm leading-snug text-muted",
												children: item.line
											})]
										}, item.id))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-8 space-y-2",
										children: meta.prompts.map((prompt) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => send(prompt),
											className: "block w-full rounded-lg border border-line bg-surface px-4 py-3 text-left text-sm leading-relaxed text-fg hover:border-mist",
											children: prompt
										}, prompt))
									})
								]
							}) : active.messages.map((message) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: "animate-rise " + (message.role === "user" ? "ml-auto max-w-xl" : "max-w-3xl"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mb-2 text-xs font-medium tracking-wide text-faint uppercase",
									children: message.role === "user" ? "Ви" : "Ardania"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: message.role === "user" ? "rounded-lg rounded-br-sm bg-raised px-4 py-3 text-sm sm:text-base" : "text-sm sm:text-base",
									children: message.role === "assistant" && !message.content ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "thinking",
										children: "Ardania думає"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RichText, { text: message.content })
								})]
							}, message.id)), error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "rounded-md border border-line bg-surface px-4 py-3 text-sm text-fg",
								role: "alert",
								children: error
							}) : null]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "border-t border-line px-4 py-4 lg:px-8",
						onSubmit: (event) => {
							event.preventDefault();
							send(draft);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto flex w-full max-w-3xl items-end gap-2 rounded-xl border border-line bg-surface p-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "sr-only",
									htmlFor: "ardania-draft",
									children: "Повідомлення для Ardania"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									id: "ardania-draft",
									ref: fieldRef,
									value: draft,
									rows: 1,
									maxLength: MAX_CHARS,
									placeholder: `Запит у палату «${meta.name}»`,
									onChange: (event) => setDraft(event.target.value),
									onKeyDown: (event) => {
										if (event.key === "Enter" && !event.shiftKey) {
											event.preventDefault();
											send(draft);
										}
									},
									className: "max-h-40 min-h-11 flex-1 resize-none bg-transparent px-2 py-2.5 text-base text-fg outline-none placeholder:text-faint"
								}),
								busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: stop,
									className: "grid size-11 shrink-0 place-items-center rounded-md bg-paper text-ink",
									"aria-label": "Зупинити",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, { className: "size-4" })
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "submit",
									disabled: !draft.trim(),
									className: "h-11 shrink-0 rounded-md bg-paper px-4 text-sm font-medium text-ink disabled:opacity-40",
									children: "Надіслати"
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mx-auto mt-2 w-full max-w-3xl text-xs text-faint",
							children: ["Enter надсилає. Shift+Enter — новий рядок.", draft.length > 3200 ? ` ${draft.length}/${MAX_CHARS}` : ""]
						})]
					})
				]
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArdaniaStudio, {});
}
//#endregion
export { Home as component };
