import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { a as useCurrentUserState, n as Splash } from "./splash-34x-4Cka.mjs";
import { S as Navigate } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-62Wnl_U0.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const { user, isPending } = useCurrentUserState();
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Splash, {});
	if (user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/dashboard" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/login" });
}
//#endregion
export { Home as component };
