import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { a as object, n as boolean, o as string, t as _enum } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/functions-D0funfs6.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var qualitySchema = _enum([
	"1080p",
	"720p",
	"480p"
]);
var previewSchema = object({ url: string().min(4).max(2e3) });
var prepareSchema = object({
	url: string().min(4).max(2e3),
	quality: qualitySchema,
	audioOnly: boolean()
});
var previewMediaFn_createServerFn_handler = createServerRpc({
	id: "e7d01a25bfa970a85e4bf5e88f2a40a5ded953ac99a614bac8b21b29a714e506",
	name: "previewMediaFn",
	filename: "src/lib/media/functions.ts"
}, (opts) => previewMediaFn.__executeServer(opts));
var previewMediaFn = createServerFn({ method: "POST" }).validator(previewSchema).handler(previewMediaFn_createServerFn_handler, async ({ data }) => {
	const { previewMedia } = await import("./cobalt.server-C5E8xqjA.mjs");
	return previewMedia(data.url);
});
var prepareMediaFn_createServerFn_handler = createServerRpc({
	id: "cd1439a5dacdafd8677543e183f937b980b23d6bb18858d29b8d9dfcf92a44ae",
	name: "prepareMediaFn",
	filename: "src/lib/media/functions.ts"
}, (opts) => prepareMediaFn.__executeServer(opts));
var prepareMediaFn = createServerFn({ method: "POST" }).validator(prepareSchema).handler(prepareMediaFn_createServerFn_handler, async ({ data }) => {
	const { prepareMedia } = await import("./cobalt.server-C5E8xqjA.mjs");
	return prepareMedia(data);
});
//#endregion
export { prepareMediaFn_createServerFn_handler, previewMediaFn_createServerFn_handler };
