import { g as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { t as AppShell } from "./shell-CGpvgZIy.mjs";
import { t as AvailabilityPage } from "./desk-pages-BQQTtJ_U.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/availability-BUuxNNxS.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = function AvailabilityRoute() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AvailabilityPage, {}) });
};
//#endregion
export { SplitComponent as component };
