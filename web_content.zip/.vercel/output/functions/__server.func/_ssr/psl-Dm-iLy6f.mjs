//#region node_modules/.nitro/vite/services/ssr/assets/psl-Dm-iLy6f.js
var TIER_IDS = [
	"gigachad",
	"chad",
	"stacy",
	"chadlite",
	"normie",
	"ltn",
	"sub3"
];
var TIER_META = {
	gigachad: {
		rank: "GigaChad",
		shortRank: "GigaChad",
		mogScore: 96,
		pslMin: 9,
		pslMax: 10,
		rarity: "Top 0.1%",
		blurb: "Cấu trúc xương huyền thoại. Rất hiếm trong dân số thực."
	},
	chad: {
		rank: "Chad",
		shortRank: "Chad",
		mogScore: 89,
		pslMin: 8,
		pslMax: 8.99,
		rarity: "Top 1–3%",
		blurb: "Harmony và dimorphism mức người mẫu. Nam."
	},
	stacy: {
		rank: "Stacy",
		shortRank: "Stacy",
		mogScore: 90,
		pslMin: 8,
		pslMax: 8.99,
		rarity: "Top 1–3%",
		blurb: "Tương đương Chad ở nữ. Harmony và dimorphism cao."
	},
	chadlite: {
		rank: "Chadlite / HTN",
		shortRank: "Chadlite",
		mogScore: 80,
		pslMin: 7,
		pslMax: 7.99,
		rarity: "Top 10–15%",
		blurb: "High tier normie. Rõ ràng hấp dẫn hơn trung bình."
	},
	normie: {
		rank: "MTN",
		shortRank: "MTN",
		mogScore: 64,
		pslMin: 6,
		pslMax: 6.99,
		rarity: "Giữa bell curve",
		blurb: "Mid tier normie. Mức phổ biến nhất ngoài đời."
	},
	ltn: {
		rank: "LTN",
		shortRank: "LTN",
		mogScore: 50,
		pslMin: 5,
		pslMax: 5.99,
		rarity: "Bottom 25%",
		blurb: "Low tier normie. Có deficit cấu trúc cần tập trung."
	},
	sub3: {
		rank: "Sub3",
		shortRank: "Sub3",
		mogScore: 35,
		pslMin: 0,
		pslMax: 4.99,
		rarity: "Bottom 5%",
		blurb: "Deficit rõ trên nhiều trục. Cần can thiệp có hệ thống."
	}
};
var TIER_ORDER = [
	"gigachad",
	"chad",
	"stacy",
	"chadlite",
	"normie",
	"ltn",
	"sub3"
];
function isTierId(value) {
	return TIER_IDS.includes(value);
}
function pslFromTier(tier) {
	const meta = TIER_META[tier];
	return clamp(round1(meta.mogScore / 10), meta.pslMin, meta.pslMax);
}
function formatPsl(n) {
	return n.toFixed(1);
}
function confidenceLabel(c) {
	if (c === "high") return "Cao";
	if (c === "medium") return "Trung bình";
	return "Thấp";
}
function clamp(n, min, max) {
	return Math.min(max, Math.max(min, n));
}
function round1(n) {
	return Math.round(n * 10) / 10;
}
function parseConfidence(raw) {
	const v = typeof raw === "string" ? raw.toLowerCase() : "";
	if (v === "high" || v === "medium" || v === "low") return v;
	return "medium";
}
//#endregion
export { isTierId as a, formatPsl as i, TIER_ORDER as n, parseConfidence as o, confidenceLabel as r, pslFromTier as s, TIER_META as t };
