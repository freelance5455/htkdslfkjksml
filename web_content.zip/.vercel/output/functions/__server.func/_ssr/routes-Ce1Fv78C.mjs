import { i as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, x as require_react } from "../_libs/@react-three/drei+[...].mjs";
import { n as Play, r as Pause } from "../_libs/lucide-react.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Ce1Fv78C.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
function orbitOmega(days) {
	if (days <= 0) return 0;
	const years = days / 365.25;
	return Math.PI * 2 / (26 * Math.sqrt(years));
}
var BODIES = [
	{
		id: "sun",
		name: "Sol",
		kind: "Estrela",
		blurb: "Anã amarela no centro do sistema. Concentra quase toda a massa e é a fonte de luz dos planetas.",
		diameter: "1,39 milhão de km",
		distance: "—",
		period: "—",
		day: "cerca de 25 dias no equador",
		moons: "—",
		radius: 2.15,
		orbit: 0,
		orbitDays: 0,
		phase: 0,
		inclination: 0,
		tilt: .13,
		spin: .06,
		view: 12,
		color: "#f0d8b0"
	},
	{
		id: "mercury",
		name: "Mercúrio",
		kind: "Planeta rochoso",
		blurb: "O menor e o mais próximo do Sol. Quase sem atmosfera, passa de um calor extremo à noite gelada.",
		diameter: "4.879 km",
		distance: "57,9 milhões de km",
		period: "88 dias",
		day: "59 dias",
		moons: "0",
		radius: .2,
		orbit: 5.55,
		orbitDays: 87.97,
		phase: .35,
		inclination: .12,
		tilt: 3e-4,
		spin: .22,
		view: 1.7,
		color: "#b7b2a8"
	},
	{
		id: "venus",
		name: "Vênus",
		kind: "Planeta rochoso",
		blurb: "Envolto em nuvens densas. Gira ao contrário dos outros planetas e tem o dia mais longo do sistema.",
		diameter: "12.104 km",
		distance: "108,2 milhões de km",
		period: "225 dias",
		day: "243 dias, retrógrado",
		moons: "0",
		radius: .36,
		orbit: 7.35,
		orbitDays: 224.7,
		phase: 1.55,
		inclination: .06,
		tilt: .05,
		spin: -.08,
		view: 2.7,
		color: "#e4d2ae",
		atmosphere: "#e6d3ae"
	},
	{
		id: "earth",
		name: "Terra",
		kind: "Planeta rochoso",
		blurb: "O único mundo conhecido com oceanos estáveis e vida. A Lua acompanha a órbita de perto.",
		diameter: "12.742 km",
		distance: "149,6 milhões de km",
		period: "365 dias",
		day: "24 horas",
		moons: "1",
		radius: .38,
		orbit: 9.25,
		orbitDays: 365.25,
		phase: 2.55,
		inclination: 0,
		tilt: .41,
		spin: .7,
		view: 2.9,
		color: "#7ea0c4",
		atmosphere: "#9ec4e4",
		clouds: true,
		moon: true
	},
	{
		id: "mars",
		name: "Marte",
		kind: "Planeta rochoso",
		blurb: "Deserto frio e avermelhado, com calotas polares e o maior vulcão do sistema solar.",
		diameter: "6.779 km",
		distance: "227,9 milhões de km",
		period: "687 dias",
		day: "24,6 horas",
		moons: "2",
		radius: .26,
		orbit: 11.55,
		orbitDays: 686.98,
		phase: 3.7,
		inclination: .08,
		tilt: .44,
		spin: .66,
		view: 2.15,
		color: "#c4744e",
		atmosphere: "#e0a07a"
	},
	{
		id: "jupiter",
		name: "Júpiter",
		kind: "Gigante gasoso",
		blurb: "O maior planeta. Faixas de nuvens e a Grande Mancha Vermelha, uma tempestade maior que a Terra.",
		diameter: "139.820 km",
		distance: "778 milhões de km",
		period: "11,9 anos",
		day: "9,9 horas",
		moons: "95 conhecidas",
		radius: 1.08,
		orbit: 16.7,
		orbitDays: 4332.6,
		phase: .85,
		inclination: .04,
		tilt: .05,
		spin: 1.25,
		view: 7.2,
		color: "#d2b48c",
		atmosphere: "#e7d2b0"
	},
	{
		id: "saturn",
		name: "Saturno",
		kind: "Gigante gasoso",
		blurb: "Reconhecido pelos anéis de gelo e rocha. É tão pouco denso que flutuaria se houvesse um oceano à escala.",
		diameter: "116.460 km",
		distance: "1,43 bilhão de km",
		period: "29,5 anos",
		day: "10,7 horas",
		moons: "mais de 140",
		radius: .9,
		orbit: 21.3,
		orbitDays: 10759,
		phase: 4.35,
		inclination: .07,
		tilt: .47,
		spin: 1.15,
		view: 8.4,
		color: "#e6d7b8",
		atmosphere: "#f0e4cc",
		ring: {
			inner: 1.28,
			outer: 2.12
		}
	},
	{
		id: "uranus",
		name: "Urano",
		kind: "Gigante de gelo",
		blurb: "Gira de lado, com o eixo quase deitado sobre a órbita. Um anel fino marca o equador.",
		diameter: "50.724 km",
		distance: "2,87 bilhões de km",
		period: "84 anos",
		day: "17,2 horas",
		moons: "28",
		radius: .56,
		orbit: 25.7,
		orbitDays: 30687,
		phase: 2.05,
		inclination: .05,
		tilt: 1.71,
		spin: .72,
		view: 4.3,
		color: "#b7ddd6",
		atmosphere: "#d5eeea",
		ring: {
			inner: .82,
			outer: .98
		}
	},
	{
		id: "neptune",
		name: "Netuno",
		kind: "Gigante de gelo",
		blurb: "O mais distante dos oito. Ventos fortíssimos e um azul profundo vindo do metano na atmosfera.",
		diameter: "49.244 km",
		distance: "4,50 bilhões de km",
		period: "165 anos",
		day: "16,1 horas",
		moons: "16",
		radius: .54,
		orbit: 29.7,
		orbitDays: 60190,
		phase: 5.15,
		inclination: .055,
		tilt: .49,
		spin: .78,
		view: 4.15,
		color: "#3d62b0",
		atmosphere: "#8eb0e4"
	}
];
var BODY_MAP = Object.fromEntries(BODIES.map((body) => [body.id, body]));
var ORBIT_LINE = "#8b93a3";
var SCENE_BG = "#07080c";
var SUN_LIGHT = "#fff3e2";
var BELT_COLOR = "#8a8175";
var ACCENT = "#d5d9e2";
var useSolar = create((set) => ({
	paused: false,
	speed: 1,
	selected: null,
	focusTick: 0,
	togglePaused: () => set((state) => ({ paused: !state.paused })),
	setPaused: (paused) => set({ paused }),
	setSpeed: (speed) => set({ speed }),
	select: (selected) => set((state) => ({
		selected,
		focusTick: state.focusTick + 1
	}))
}));
function formatSpeed(speed) {
	return `${speed >= 10 ? String(Math.round(speed)) : speed.toFixed(1).replace(".", ",")}×`;
}
var FACTS = [
	{
		key: "diameter",
		label: "Diâmetro"
	},
	{
		key: "distance",
		label: "Distância ao Sol"
	},
	{
		key: "period",
		label: "Órbita"
	},
	{
		key: "day",
		label: "Dia"
	},
	{
		key: "moons",
		label: "Luas"
	}
];
function Overlay() {
	const paused = useSolar((state) => state.paused);
	const speed = useSolar((state) => state.speed);
	const selected = useSolar((state) => state.selected);
	const togglePaused = useSolar((state) => state.togglePaused);
	const setSpeed = useSolar((state) => state.setSpeed);
	const select = useSolar((state) => state.select);
	const body = selected ? BODY_MAP[selected] : null;
	(0, import_react.useEffect)(() => {
		const onKey = (event) => {
			const target = event.target;
			if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement) return;
			if (event.code === "Space") {
				event.preventDefault();
				useSolar.getState().togglePaused();
			} else if (event.code === "Escape") useSolar.getState().select(null);
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "hud",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "sr-only",
				"aria-live": "polite",
				children: body ? `${body.name}. ${body.kind}.` : "Visão geral do sistema solar."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "topbar",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "brand",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mark",
						"aria-hidden": "true"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: "Órbita" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Observatório do sistema solar" })] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "controls",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "btn",
							onClick: () => select(null),
							"aria-pressed": selected === null,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "wide",
								children: "Visão geral"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "narrow",
								children: "Geral"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "speed",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "speed-label",
								children: ["Velocidade", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "tabular",
									children: formatSpeed(speed)
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "range",
								min: .25,
								max: 8,
								step: .05,
								value: speed,
								"aria-valuetext": formatSpeed(speed),
								onChange: (event) => setSpeed(Number(event.target.value))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "btn btn-primary",
							onClick: togglePaused,
							"aria-pressed": paused,
							children: [paused ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
								size: 16,
								"aria-hidden": "true"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, {
								size: 16,
								"aria-hidden": "true"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: paused ? "Retomar" : "Pausar" })]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "rail",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "panel nav",
					"aria-label": "Corpos do sistema solar",
					children: BODIES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "nav-btn",
						"aria-pressed": selected === item.id,
						onClick: () => select(item.id),
						children: item.name
					}, item.id))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "panel info",
					"aria-label": body ? body.name : "Sobre o sistema",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "info-body",
						children: [body ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "kicker",
								children: body.kind
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: body.name }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "blurb",
								children: body.blurb
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", { children: FACTS.map((fact) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: fact.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "tabular",
								children: body[fact.key]
							})] }, fact.key)) })
						] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "kicker",
								children: "Vista do conjunto"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Oito planetas" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "blurb",
								children: "Clique num mundo, ou escolha-o na lista, para a câmara se aproximar e o seguir na órbita."
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "note",
							children: "Tamanhos e distâncias estão comprimidos. O tempo é ilustrativo: a Terra completa uma volta em cerca de meio minuto a 1×."
						})]
					}, selected ?? "system")
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "hint",
				children: "Arraste para orbitar · pinça ou roda para aproximar · Espaço pausa · Esc visão geral"
			})
		]
	});
}
var routes_exports = /* @__PURE__ */ __exportAll({ component: () => Home });
function Home() {
	const [Scene, setScene] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let live = true;
		import("./scene-CIXq8UfA.mjs").then((mod) => {
			if (live) setScene(() => mod.SolarScene);
		});
		return () => {
			live = false;
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "shell",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "viewport",
			children: Scene ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scene, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "booting",
				children: "A preparar o observatório…"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Overlay, {})]
	});
}
//#endregion
export { BODIES as a, ORBIT_LINE as c, orbitOmega as d, BELT_COLOR as i, SCENE_BG as l, useSolar as n, BODY_MAP as o, ACCENT as r, routes_exports as t, SUN_LIGHT as u };
