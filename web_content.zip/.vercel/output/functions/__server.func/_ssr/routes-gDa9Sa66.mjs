import { i as __toESM } from "../_runtime.mjs";
import { I as require_jsx_runtime, L as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as create } from "../_libs/zustand.mjs";
import { a as Pause, i as RotateCcw, n as Volume2, t as VolumeX } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-gDa9Sa66.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var useGameStore = create(() => ({
	phase: "title",
	ready: false,
	health: 100,
	maxHealth: 100,
	ammo: 6,
	reserve: 24,
	reloading: false,
	score: 0,
	wave: 1,
	kills: 0,
	highScore: 0,
	bestWave: 0,
	hitmarkerAt: 0,
	hurtAt: 0,
	banner: "",
	muted: false,
	sensitivity: 1,
	aimAssist: true,
	newRecord: false
}));
function toggleMuted() {
	useGameStore.setState((s) => ({ muted: !s.muted }));
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 font-display font-medium tracking-wide transition-opacity duration-150 select-none focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent disabled:pointer-events-none disabled:opacity-40 active:scale-[0.98]", {
	variants: {
		variant: {
			default: "bg-accent text-accent-fg hover:opacity-90",
			secondary: "border border-border-strong bg-surface text-fg hover:bg-surface-2",
			ghost: "text-fg hover:bg-surface",
			danger: "bg-danger text-fg hover:opacity-90"
		},
		size: {
			sm: "h-10 rounded-sm px-3 text-sm",
			md: "h-11 rounded-md px-4 text-sm",
			lg: "h-12 rounded-lg px-6 text-base",
			xl: "h-14 rounded-xl px-8 text-lg",
			icon: "size-11 rounded-md"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "md"
	}
});
var Button = (0, import_react.forwardRef)(function Button({ className, variant, size, type = "button", ...props }, ref) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		ref,
		type,
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
});
function GameOverScreen({ onAgain, onQuit }) {
	const score = useGameStore((s) => s.score);
	const wave = useGameStore((s) => s.wave);
	const kills = useGameStore((s) => s.kills);
	const highScore = useGameStore((s) => s.highScore);
	const newRecord = useGameStore((s) => s.newRecord);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "absolute inset-0 z-30 flex items-end justify-center bg-bg/75 sm:items-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-[max(1.5rem,env(safe-area-inset-bottom))] w-full max-w-md rounded-xl border border-border bg-surface p-6 sm:mb-0",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-xs uppercase tracking-[0.3em] text-muted",
					children: "Fallen"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-1 font-display text-3xl text-fg",
					children: "Gallows Hollow keeps you"
				}),
				newRecord ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-accent",
					children: "A new ledger mark."
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "mt-5 grid grid-cols-3 gap-3 font-display",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-xs uppercase tracking-wide text-subtle",
							children: "Score"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "mt-1 text-xl tabular-nums text-fg",
							children: score.toLocaleString()
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-xs uppercase tracking-wide text-subtle",
							children: "Wave"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "mt-1 text-xl tabular-nums text-fg",
							children: wave
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-xs uppercase tracking-wide text-subtle",
							children: "Put down"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "mt-1 text-xl tabular-nums text-fg",
							children: kills
						})] })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-sm tabular-nums text-subtle",
					children: ["Best ", highScore.toLocaleString()]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-col gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						className: "w-full",
						onClick: onAgain,
						children: "Stand again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						className: "w-full",
						onClick: onQuit,
						children: "Town square"
					})]
				})
			]
		})
	});
}
function Hud({ onPause }) {
	const health = useGameStore((s) => s.health);
	const maxHealth = useGameStore((s) => s.maxHealth);
	const ammo = useGameStore((s) => s.ammo);
	const reserve = useGameStore((s) => s.reserve);
	const reloading = useGameStore((s) => s.reloading);
	const score = useGameStore((s) => s.score);
	const wave = useGameStore((s) => s.wave);
	const banner = useGameStore((s) => s.banner);
	const hitmarkerAt = useGameStore((s) => s.hitmarkerAt);
	const hurtAt = useGameStore((s) => s.hurtAt);
	const [now, setNow] = (0, import_react.useState)(() => 0);
	(0, import_react.useEffect)(() => {
		if (!hitmarkerAt && !hurtAt) return;
		const t = window.setInterval(() => setNow(performance.now()), 80);
		return () => clearInterval(t);
	}, [hitmarkerAt, hurtAt]);
	const hitOn = now - hitmarkerAt < 140 && hitmarkerAt > 0;
	const hurtFade = hurtAt > 0 ? Math.max(0, 1 - (now - hurtAt) / 450) : 0;
	const low = health < 35;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-none absolute inset-0 z-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 bg-danger transition-opacity duration-150",
				style: { opacity: Math.min(.45, hurtFade * .4 + (low ? .12 : 0)) }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute left-4 top-4 pt-[env(safe-area-inset-top)] sm:left-6 sm:top-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-display text-xs uppercase tracking-[0.28em] text-muted",
					children: ["Wave ", wave]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 font-display text-xl tabular-nums text-fg",
					children: score.toLocaleString()
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute right-4 top-4 pt-[env(safe-area-inset-top)] sm:right-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					size: "icon",
					className: "pointer-events-auto",
					"aria-label": "Pause",
					onClick: onPause,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-4" })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute left-1/2 top-5 w-40 -translate-x-1/2 pt-[env(safe-area-inset-top)] sm:w-56",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-2 overflow-hidden rounded-xs bg-health-track",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-full bg-health transition-[width] duration-150",
						style: { width: `${Math.max(0, health / maxHealth * 100)}%` }
					})
				})
			}),
			banner ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "absolute left-1/2 top-[18%] -translate-x-1/2 font-display text-2xl tracking-display text-balance text-fg",
				children: banner
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: cn("relative size-7", hitOn ? "opacity-100" : "opacity-80"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute left-1/2 top-0 h-2 w-px -translate-x-1/2 bg-accent" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute bottom-0 left-1/2 h-2 w-px -translate-x-1/2 bg-accent" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute left-0 top-1/2 h-px w-2 -translate-y-1/2 bg-accent" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute right-0 top-1/2 h-px w-2 -translate-y-1/2 bg-accent" }),
						hitOn ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute inset-0 rotate-45 border border-accent" }) : null
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute bottom-44 right-5 text-right sm:bottom-8 sm:right-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-xs uppercase tracking-[0.22em] text-muted",
						children: reloading ? "Reloading" : "Cylinder"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 flex justify-end gap-1.5",
						children: Array.from({ length: 6 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-2.5 rounded-full border border-border-strong", i < ammo ? "bg-accent" : "bg-transparent") }, i))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-display text-sm tabular-nums text-subtle",
						children: reserve
					})
				]
			})
		]
	});
}
function PauseScreen({ onResume, onQuit, onMute }) {
	const muted = useGameStore((s) => s.muted);
	const sensitivity = useGameStore((s) => s.sensitivity);
	const aimAssist = useGameStore((s) => s.aimAssist);
	const score = useGameStore((s) => s.score);
	const wave = useGameStore((s) => s.wave);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "absolute inset-0 z-30 flex items-end justify-center bg-bg/70 sm:items-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-[max(1.5rem,env(safe-area-inset-bottom))] w-full max-w-md rounded-xl border border-border bg-surface p-6 sm:mb-0",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-xs uppercase tracking-[0.3em] text-muted",
					children: "Paused"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-1 font-display text-3xl text-fg",
					children: "Hold fast"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 font-display text-sm tabular-nums text-subtle",
					children: [
						"Wave ",
						wave,
						" · ",
						score.toLocaleString()
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-6 block text-sm text-muted",
					children: ["Look sensitivity", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "range",
						min: .4,
						max: 2,
						step: .05,
						value: sensitivity,
						onChange: (e) => useGameStore.setState({ sensitivity: Number(e.target.value) }),
						className: "mt-2 w-full accent-accent"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-4 flex items-center gap-3 text-sm text-fg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: aimAssist,
						onChange: (e) => useGameStore.setState({ aimAssist: e.target.checked }),
						className: "size-4 accent-accent"
					}), "Aim assist"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-col gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						className: "w-full",
						onClick: onResume,
						children: "Resume"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "secondary",
							className: "flex-1",
							onClick: onMute,
							children: [muted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-4" }), muted ? "Unmute" : "Mute"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "secondary",
							className: "flex-1",
							onClick: onQuit,
							children: "Town square"
						})]
					})]
				})
			]
		})
	});
}
function useMobileLayout() {
	const [mobile, setMobile] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const update = () => {
			setMobile(window.matchMedia("(pointer: coarse)").matches || window.matchMedia("(max-width: 767px)").matches);
		};
		update();
		window.addEventListener("resize", update);
		return () => window.removeEventListener("resize", update);
	}, []);
	return mobile;
}
function TitleScreen({ ready, onStart, onMute }) {
	const highScore = useGameStore((s) => s.highScore);
	const bestWave = useGameStore((s) => s.bestWave);
	const muted = useGameStore((s) => s.muted);
	const mobile = useMobileLayout();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "absolute inset-0 z-20 flex flex-col justify-end bg-gradient-to-t from-bg via-bg/80 to-bg/25",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "absolute right-4 top-4 z-30 pt-[env(safe-area-inset-top)]",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "icon",
				"aria-label": muted ? "Unmute" : "Mute",
				onClick: onMute,
				children: muted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-5" })
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto w-full max-w-lg px-6 pb-[max(4.5rem,env(safe-area-inset-bottom))]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-xs uppercase tracking-[0.38em] text-muted",
					children: "Parish of 1879"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-display text-4xl font-semibold tracking-display text-balance text-fg sm:text-6xl",
					children: "Gallows Hollow"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-4 h-px w-16 bg-border-strong" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-md text-pretty text-sm leading-relaxed text-muted sm:text-base",
					children: "The dead have climbed out of the churchyard. You are the last sheriff. Hold the square with a six-shooter until the cylinder — or you — run dry."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap gap-x-6 gap-y-1 font-display text-sm tabular-nums text-subtle",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Best ", highScore.toLocaleString()] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Wave ", bestWave || "—"] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "xl",
					className: "mt-6 w-full sm:w-auto",
					disabled: !ready,
					onClick: onStart,
					children: ready ? "Enter Town" : "Loading…"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-pretty text-xs leading-relaxed text-subtle",
					children: mobile ? "Left stick to walk. Drag the right side to look. Fire and reload with the buttons." : "WASD to walk. Drag or mouse to look. Click or Space to fire. R reloads. Shift sprints. Esc pauses."
				})
			]
		})]
	});
}
function TouchControls({ onMove, onFire, onReload }) {
	if (!useMobileLayout()) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-none absolute inset-0 z-20",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stick, { onMove }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-label": "Reload",
				className: "pointer-events-auto absolute right-6 bottom-36 flex size-14 items-center justify-center rounded-full border border-border-strong bg-surface/80 text-fg",
				onPointerDown: (e) => {
					e.preventDefault();
					e.stopPropagation();
					onReload();
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-5" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-label": "Fire",
				className: "pointer-events-auto absolute bottom-20 right-5 flex size-20 items-center justify-center rounded-full border border-accent/40 bg-danger font-display text-sm tracking-wide text-fg",
				onPointerDown: (e) => {
					e.preventDefault();
					e.stopPropagation();
					onFire(true);
				},
				onPointerUp: (e) => {
					e.preventDefault();
					onFire(false);
				},
				onPointerCancel: () => onFire(false),
				onPointerLeave: () => onFire(false),
				children: "Fire"
			})
		]
	});
}
function Stick({ onMove }) {
	const baseRef = (0, import_react.useRef)(null);
	const pid = (0, import_react.useRef)(null);
	const [knob, setKnob] = (0, import_react.useState)({
		x: 0,
		y: 0
	});
	const apply = (clientX, clientY) => {
		const el = baseRef.current;
		if (!el) return;
		const rect = el.getBoundingClientRect();
		const cx = rect.left + rect.width / 2;
		const cy = rect.top + rect.height / 2;
		let dx = clientX - cx;
		let dy = clientY - cy;
		const max = rect.width / 2 - 10;
		const mag = Math.hypot(dx, dy);
		if (mag > max) {
			dx = dx / mag * max;
			dy = dy / mag * max;
		}
		setKnob({
			x: dx,
			y: dy
		});
		onMove(dx / max, -dy / max);
	};
	const reset = () => {
		pid.current = null;
		setKnob({
			x: 0,
			y: 0
		});
		onMove(0, 0);
	};
	const down = (e) => {
		e.preventDefault();
		e.stopPropagation();
		pid.current = e.pointerId;
		e.currentTarget.setPointerCapture(e.pointerId);
		apply(e.clientX, e.clientY);
	};
	const move = (e) => {
		if (pid.current !== e.pointerId) return;
		apply(e.clientX, e.clientY);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: baseRef,
		className: "pointer-events-auto absolute bottom-16 left-5 size-28 rounded-full border border-border-strong bg-surface/50",
		"aria-label": "Move",
		onPointerDown: down,
		onPointerMove: move,
		onPointerUp: reset,
		onPointerCancel: reset,
		style: { marginBottom: "env(safe-area-inset-bottom)" },
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cn("absolute size-12 rounded-full bg-accent/90"),
			style: {
				left: "50%",
				top: "50%",
				transform: `translate(-50%, -50%) translate(${knob.x}px, ${knob.y}px)`
			}
		})
	});
}
function GameApp() {
	const canvasRef = (0, import_react.useRef)(null);
	const engineRef = (0, import_react.useRef)(null);
	const lookId = (0, import_react.useRef)(null);
	const lastLook = (0, import_react.useRef)({
		x: 0,
		y: 0
	});
	const moved = (0, import_react.useRef)(0);
	const [bootError, setBootError] = (0, import_react.useState)(null);
	const phase = useGameStore((s) => s.phase);
	const ready = useGameStore((s) => s.ready);
	(0, import_react.useEffect)(() => {
		if (!canvasRef.current) return;
		let cancelled = false;
		let engine = null;
		import("./engine-Be9UHFo0.mjs").then(({ GameEngine }) => {
			if (cancelled || !canvasRef.current) return;
			engine = new GameEngine(canvasRef.current);
			engineRef.current = engine;
		}).catch((err) => {
			const message = err instanceof Error ? err.message : "The town failed to load.";
			setBootError(message);
		});
		return () => {
			cancelled = true;
			engine?.dispose();
			engineRef.current = null;
		};
	}, []);
	const start = () => engineRef.current?.start();
	const pause = () => engineRef.current?.pause();
	const resume = () => engineRef.current?.resume();
	const quit = () => engineRef.current?.quitToTitle();
	const mute = () => {
		toggleMuted();
		engineRef.current?.setMuted(useGameStore.getState().muted);
	};
	const onLookDown = (e) => {
		if (phase !== "playing") return;
		if (e.pointerType === "mouse" && e.button !== 0) return;
		lookId.current = e.pointerId;
		lastLook.current = {
			x: e.clientX,
			y: e.clientY
		};
		moved.current = 0;
		e.currentTarget.setPointerCapture(e.pointerId);
		engineRef.current?.tryPointerLock();
	};
	const onLookMove = (e) => {
		if (lookId.current !== e.pointerId) return;
		if (document.pointerLockElement) return;
		const dx = (e.clientX - lastLook.current.x) * 1.65;
		const dy = (e.clientY - lastLook.current.y) * 1.65;
		lastLook.current = {
			x: e.clientX,
			y: e.clientY
		};
		moved.current += Math.hypot(dx, dy);
		engineRef.current?.addLook(dx, dy);
	};
	const onLookUp = (e) => {
		if (lookId.current !== e.pointerId) return;
		lookId.current = null;
		if (document.pointerLockElement) return;
		if (moved.current < 14 && e.pointerType !== "touch") {
			engineRef.current?.setFireHeld(true);
			window.setTimeout(() => engineRef.current?.setFireHeld(false), 50);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "relative h-dvh w-full overflow-hidden bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: canvasRef,
				className: "absolute inset-0 size-full touch-none",
				onContextMenu: (e) => e.preventDefault()
			}),
			phase === "playing" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 z-[5] touch-none",
				onPointerDown: onLookDown,
				onPointerMove: onLookMove,
				onPointerUp: onLookUp,
				onPointerCancel: () => {
					lookId.current = null;
				}
			}) : null,
			phase === "playing" || phase === "paused" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hud, { onPause: pause }) : null,
			phase === "playing" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TouchControls, {
				onMove: (x, y) => engineRef.current?.setTouchMove(x, y),
				onFire: (held) => engineRef.current?.setFireHeld(held),
				onReload: () => engineRef.current?.queueReload()
			}) : null,
			phase === "title" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TitleScreen, {
				ready: ready && !bootError,
				onStart: start,
				onMute: mute
			}) : null,
			phase === "paused" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PauseScreen, {
				onResume: resume,
				onQuit: quit,
				onMute: mute
			}) : null,
			phase === "dead" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameOverScreen, {
				onAgain: start,
				onQuit: quit
			}) : null,
			bootError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 z-40 flex items-center justify-center bg-bg p-6 text-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-sm text-sm text-muted",
					children: bootError
				})
			}) : null
		]
	});
}
var routes_exports = /* @__PURE__ */ __exportAll({ component: () => Home });
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameApp, {});
}
//#endregion
export { useGameStore as n, routes_exports as t };
