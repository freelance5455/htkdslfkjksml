import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as Plane, i as Volume2, l as Activity, n as Wallet, o as RotateCcw, r as VolumeX, s as Radio, t as Zap } from "../_libs/lucide-react.mjs";
import { t as create } from "../_libs/zustand.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CiPPZMkt.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ctx = null;
var muted = false;
var master = null;
function ac() {
	if (typeof window === "undefined") return null;
	if (!ctx) {
		const Ctor = window.AudioContext || window.webkitAudioContext;
		if (!Ctor) return null;
		ctx = new Ctor();
		master = ctx.createGain();
		master.gain.value = .22;
		master.connect(ctx.destination);
	}
	return ctx;
}
function setMuted(next) {
	muted = next;
	if (master && ctx) master.gain.setTargetAtTime(next ? 0 : .22, ctx.currentTime, .05);
}
async function unlockAudio() {
	const c = ac();
	if (!c) return;
	if (c.state === "suspended") await c.resume();
}
function tone(freq, dur, type = "sine", gain = .12, slide) {
	if (muted) return;
	const c = ac();
	if (!c || !master) return;
	const o = c.createOscillator();
	const g = c.createGain();
	o.type = type;
	o.frequency.setValueAtTime(freq, c.currentTime);
	if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(20, slide), c.currentTime + dur);
	g.gain.setValueAtTime(gain, c.currentTime);
	g.gain.exponentialRampToValueAtTime(1e-4, c.currentTime + dur);
	o.connect(g);
	g.connect(master);
	o.start();
	o.stop(c.currentTime + dur + .02);
}
function playTakeoff() {
	tone(180, .35, "triangle", .08, 420);
}
function playTick() {
	tone(880, .04, "square", .03);
}
function playCash() {
	tone(520, .12, "sine", .1, 740);
	setTimeout(() => tone(780, .16, "sine", .08), 70);
}
function playCrash() {
	if (muted) return;
	const c = ac();
	if (!c || !master) return;
	const bufferSize = 2 * c.sampleRate * .28;
	const buffer = c.createBuffer(1, bufferSize, c.sampleRate);
	const data = buffer.getChannelData(0);
	for (let i = 0; i < bufferSize; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / bufferSize);
	const src = c.createBufferSource();
	src.buffer = buffer;
	const f = c.createBiquadFilter();
	f.type = "lowpass";
	f.frequency.setValueAtTime(900, c.currentTime);
	f.frequency.exponentialRampToValueAtTime(80, c.currentTime + .28);
	const g = c.createGain();
	g.gain.setValueAtTime(.28, c.currentTime);
	g.gain.exponentialRampToValueAtTime(1e-4, c.currentTime + .3);
	src.connect(f);
	f.connect(g);
	g.connect(master);
	src.start();
	tone(90, .4, "sine", .14, 40);
}
var GROWTH = .18;
var MAX_BET = 2e3;
var START_BANK = 5e3;
function hashString(str) {
	let h = 2166136261;
	for (let i = 0; i < str.length; i++) {
		h ^= str.charCodeAt(i);
		h = Math.imul(h, 16777619);
	}
	return h >>> 0;
}
function mulberry32(seed) {
	let a = seed >>> 0;
	return function rng() {
		a |= 0;
		a = a + 1831565813 | 0;
		let t = Math.imul(a ^ a >>> 15, 1 | a);
		t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
function sampleCrashPoint(rng) {
	const r = rng();
	if (r < .04) return 1;
	const crash = .96 / (1 - r);
	return Math.floor(Math.min(crash, 1e4) * 100) / 100;
}
function multiplierAt(elapsedSec) {
	return Math.exp(GROWTH * Math.max(0, elapsedSec));
}
function timeToReach(target) {
	if (target <= 1) return 0;
	return Math.log(target) / GROWTH;
}
function formatX(n) {
	if (!Number.isFinite(n)) return "1.00x";
	if (n >= 1e3) return `${n.toFixed(0)}x`;
	if (n >= 100) return `${n.toFixed(1)}x`;
	return `${n.toFixed(2)}x`;
}
function formatMoney(n) {
	return `${n < 0 ? "-" : ""}${Math.abs(n).toLocaleString(void 0, {
		minimumFractionDigits: 2,
		maximumFractionDigits: 2
	})}`;
}
function clampBet(n) {
	if (!Number.isFinite(n)) return 1;
	return Math.min(MAX_BET, Math.max(1, Math.round(n * 100) / 100));
}
function mean(xs) {
	if (xs.length === 0) return 2;
	return xs.reduce((a, b) => a + b, 0) / xs.length;
}
function percentile(xs, p) {
	if (xs.length === 0) return 2;
	const s = [...xs].sort((a, b) => a - b);
	return s[Math.min(s.length - 1, Math.max(0, Math.floor(p * (s.length - 1))))] ?? 2;
}
function computeSignal(history, rng) {
	const recent = history.slice(0, 24);
	const lows = recent.filter((x) => x < 2).length;
	const moons = recent.filter((x) => x >= 10).length;
	const avg = mean(recent.length ? recent : [
		1.8,
		2.1,
		1.4
	]);
	const p40 = percentile(recent.length ? recent : [
		1.5,
		2,
		3
	], .4);
	const roll = rng();
	let risk = "pulse";
	if (lows >= 6 && roll < .38) risk = "moon";
	else if (moons >= 3 && roll < .55) risk = "safe";
	else if (roll < .34) risk = "safe";
	else if (roll > .88) risk = "moon";
	let cashOut;
	if (risk === "safe") cashOut = 1.2 + rng() * .7;
	else if (risk === "pulse") cashOut = 1.85 + rng() * 1.7;
	else cashOut = 5 + rng() * 18;
	const stretch = 1.08 + rng() * .55;
	const flyTo = Math.max(cashOut * stretch, cashOut + .15 + rng() * .8);
	const varianceBoost = Math.min(.18, recent.length * .006);
	const baseConf = risk === "safe" ? .68 : risk === "pulse" ? .58 : .42;
	const streakAdj = lows >= 5 ? -.06 : avg < 2 ? .04 : 0;
	const confidence = Math.min(.86, Math.max(.38, baseConf + varianceBoost + streakAdj + (rng() - .5) * .08));
	const low = Math.max(1.05, cashOut * .82);
	const high = Math.max(flyTo, p40 * 1.1);
	return {
		flyTo: Math.floor(flyTo * 100) / 100,
		cashOut: Math.floor(cashOut * 100) / 100,
		confidence: Math.round(confidence * 100),
		risk,
		low: Math.floor(low * 100) / 100,
		high: Math.floor(high * 100) / 100
	};
}
function emptyBet(amount = 10) {
	return {
		amount: clampBet(amount),
		placed: false,
		autoCash: true,
		autoCashAt: 2,
		cashedAt: null,
		result: "idle",
		payout: 0
	};
}
function roundHash(room, round, salt) {
	return hashString(`${room}|${round}|${salt}`).toString(16).padStart(8, "0");
}
var STORAGE_KEY = "aeropulse-v1";
var MAX_HISTORY = 48;
function persistSlice(s) {
	try {
		localStorage.setItem(STORAGE_KEY, JSON.stringify({
			balance: s.balance,
			peakBalance: s.peakBalance,
			history: s.history.slice(0, MAX_HISTORY),
			roomCode: s.roomCode,
			muted: s.muted,
			autoPilot: s.autoPilot,
			salt: s.salt,
			round: s.round,
			hits: s.hits,
			misses: s.misses,
			bets: [{
				amount: s.bets[0].amount,
				autoCash: s.bets[0].autoCash
			}, {
				amount: s.bets[1].amount,
				autoCash: s.bets[1].autoCash
			}],
			shakeOff: s.shakeOff
		}));
	} catch {}
}
function newSalt() {
	return Math.random().toString(36).slice(2, 10);
}
function applyCash(slot, multiplier, balance) {
	const payout = Math.round(slot.amount * multiplier * 100) / 100;
	return {
		next: {
			...slot,
			cashedAt: multiplier,
			result: "win",
			payout,
			placed: false
		},
		balance: Math.round((balance + payout) * 100) / 100,
		payout
	};
}
var useGame = create((set, get) => ({
	phase: "idle",
	waitLeft: 5,
	elapsed: 0,
	multiplier: 1,
	crashAt: 1,
	round: 1,
	history: [],
	signal: null,
	balance: START_BANK,
	peakBalance: START_BANK,
	bets: [emptyBet(20), emptyBet(50)],
	live: false,
	muted: false,
	roomCode: "AERO-LIVE",
	salt: newSalt(),
	hash: "aero0001",
	autoPilot: true,
	started: false,
	lastProfit: 0,
	trauma: 0,
	shakeOff: false,
	hits: 0,
	misses: 0,
	hydrate: () => {
		if (typeof window === "undefined") return;
		try {
			const raw = localStorage.getItem(STORAGE_KEY);
			if (!raw) return;
			const d = JSON.parse(raw);
			set((s) => ({
				balance: typeof d.balance === "number" ? d.balance : s.balance,
				peakBalance: typeof d.peakBalance === "number" ? d.peakBalance : s.peakBalance,
				history: Array.isArray(d.history) ? d.history.slice(0, MAX_HISTORY) : s.history,
				roomCode: d.roomCode || s.roomCode,
				muted: Boolean(d.muted),
				autoPilot: d.autoPilot !== false,
				salt: d.salt || s.salt,
				round: typeof d.round === "number" ? d.round : s.round,
				hits: typeof d.hits === "number" ? d.hits : s.hits,
				misses: typeof d.misses === "number" ? d.misses : s.misses,
				shakeOff: Boolean(d.shakeOff),
				bets: [emptyBet(d.bets?.[0]?.amount ?? 20), emptyBet(d.bets?.[1]?.amount ?? 50)].map((b, i) => ({
					...b,
					autoCash: d.bets?.[i]?.autoCash !== false
				}))
			}));
			setMuted(Boolean(d.muted));
		} catch {}
	},
	startLive: () => {
		unlockAudio();
		if (get().phase !== "idle") {
			set({
				live: true,
				started: true
			});
			return;
		}
		beginWaiting(set, get);
		autoPlaceIfNeeded(set, get);
		set({
			live: true,
			started: true
		});
	},
	setMutedFlag: (v) => {
		setMuted(v);
		set({ muted: v });
		persistSlice(get());
	},
	setRoomCode: (v) => {
		set({ roomCode: v.slice(0, 24).toUpperCase() });
		persistSlice(get());
	},
	setShakeOff: (v) => {
		set({ shakeOff: v });
		persistSlice(get());
	},
	setAutoPilot: (v) => {
		set({ autoPilot: v });
		persistSlice(get());
	},
	setBetAmount: (slot, amount) => {
		set((s) => {
			const bets = [...s.bets];
			if (bets[slot].placed) return s;
			bets[slot] = {
				...bets[slot],
				amount
			};
			return { bets };
		});
	},
	toggleAutoCash: (slot) => {
		set((s) => {
			const bets = [...s.bets];
			bets[slot] = {
				...bets[slot],
				autoCash: !bets[slot].autoCash
			};
			return { bets };
		});
		persistSlice(get());
	},
	setAutoCashAt: (slot, v) => {
		set((s) => {
			const bets = [...s.bets];
			bets[slot] = {
				...bets[slot],
				autoCashAt: Math.max(1.01, v)
			};
			return { bets };
		});
	},
	placeBet: (slot) => {
		const s = get();
		if (s.phase !== "waiting") return;
		const b = s.bets[slot];
		if (b.placed) return;
		if (s.balance < b.amount) return;
		const bets = [...s.bets];
		bets[slot] = {
			...b,
			placed: true,
			cashedAt: null,
			result: "pending",
			payout: 0
		};
		set({
			bets,
			balance: Math.round((s.balance - b.amount) * 100) / 100
		});
	},
	cashOut: (slot) => {
		const s = get();
		if (s.phase !== "flying") return;
		const b = s.bets[slot];
		if (!b.placed || b.cashedAt !== null) return;
		const { next, balance, payout } = applyCash(b, s.multiplier, s.balance);
		const bets = [...s.bets];
		bets[slot] = next;
		playCash();
		set({
			bets,
			balance,
			peakBalance: Math.max(s.peakBalance, balance),
			lastProfit: payout - b.amount
		});
	},
	resetBank: () => {
		set({
			balance: START_BANK,
			peakBalance: START_BANK,
			lastProfit: 0,
			bets: [emptyBet(20), emptyBet(50)]
		});
		persistSlice(get());
	},
	tick: (dt) => {
		const s = get();
		if (s.started && s.phase === "idle") {
			beginWaiting(set, get);
			set({ live: true });
			return;
		}
		if (!s.live) return;
		const trauma = Math.max(0, s.trauma - dt * 2.4);
		if (s.phase === "waiting") {
			const waitLeft = s.waitLeft - dt;
			if (waitLeft <= 0) {
				playTakeoff();
				autoPlaceIfNeeded(set, get);
				set({
					phase: "flying",
					waitLeft: 0,
					elapsed: 0,
					multiplier: 1,
					trauma
				});
				return;
			}
			const prevSec = Math.ceil(s.waitLeft);
			const nextSec = Math.ceil(waitLeft);
			if (nextSec !== prevSec && nextSec > 0 && nextSec <= 3) playTick();
			set({
				waitLeft,
				trauma
			});
			return;
		}
		if (s.phase === "flying") {
			const elapsed = s.elapsed + dt;
			const multiplier = Math.floor(multiplierAt(elapsed) * 100) / 100;
			if (multiplier >= s.crashAt || elapsed >= timeToReach(s.crashAt)) {
				finishRound(set, get, s.crashAt);
				return;
			}
			autoCashIfNeeded(set, get, multiplier);
			set({
				elapsed,
				multiplier,
				trauma
			});
			return;
		}
		if (s.phase === "crashed") {
			const waitLeft = s.waitLeft - dt;
			if (waitLeft <= 0) {
				beginWaiting(set, get);
				return;
			}
			set({
				waitLeft,
				trauma
			});
		}
	}
}));
function beginWaiting(set, get) {
	const s = get();
	const round = s.history.reduce((m, h) => Math.max(m, h.id), 0) + 1;
	const rng = mulberry32(hashString(`${s.roomCode}:${round}:${s.salt}`));
	const crashAt = sampleCrashPoint(rng);
	const signal = computeSignal(s.history.map((h) => h.crash), rng);
	set({
		phase: "waiting",
		waitLeft: 5,
		elapsed: 0,
		multiplier: 1,
		crashAt,
		round,
		signal,
		hash: roundHash(s.roomCode, round, s.salt),
		bets: s.bets.map((b) => ({
			...b,
			placed: false,
			cashedAt: null,
			result: "idle",
			payout: 0,
			autoCashAt: s.autoPilot ? signal.cashOut : b.autoCashAt
		})),
		lastProfit: 0
	});
	autoPlaceIfNeeded(set, get);
}
function autoPlaceIfNeeded(set, get) {
	const s = get();
	if (!s.autoPilot) return;
	const bets = [...s.bets];
	let balance = s.balance;
	[0, 1].forEach((i) => {
		const idx = i;
		const b = bets[idx];
		if (b.placed) return;
		if (idx === 1) return;
		if (balance < b.amount) return;
		balance = Math.round((balance - b.amount) * 100) / 100;
		bets[idx] = {
			...b,
			placed: true,
			cashedAt: null,
			result: "pending",
			payout: 0,
			autoCash: true,
			autoCashAt: s.signal?.cashOut ?? b.autoCashAt
		};
	});
	set({
		bets,
		balance
	});
}
function autoCashIfNeeded(set, get, multiplier) {
	const s = get();
	let balance = s.balance;
	let changed = false;
	let lastProfit = s.lastProfit;
	const bets = s.bets.map((b) => {
		if (!b.placed || b.cashedAt !== null || !b.autoCash) return b;
		if (multiplier + 1e-4 < b.autoCashAt) return b;
		const { next, balance: bal, payout } = applyCash(b, multiplier, balance);
		balance = bal;
		lastProfit = payout - b.amount;
		changed = true;
		playCash();
		return next;
	});
	if (changed) set({
		bets,
		balance,
		peakBalance: Math.max(s.peakBalance, balance),
		lastProfit
	});
}
function finishRound(set, get, crashAt) {
	const s = get();
	playCrash();
	let profit = 0;
	const bets = s.bets.map((b) => {
		if (!b.placed) return {
			...b,
			result: "idle"
		};
		if (b.cashedAt !== null) {
			profit += b.payout - b.amount;
			return b;
		}
		profit -= b.amount;
		return {
			...b,
			placed: false,
			result: "lose",
			payout: 0
		};
	});
	const signalX = s.signal?.cashOut ?? 1.5;
	const hit = crashAt >= signalX;
	const record = {
		id: s.round,
		crash: crashAt,
		signal: signalX,
		hit,
		cashed: bets[0].cashedAt,
		profit
	};
	set({
		phase: "crashed",
		waitLeft: 2.4,
		multiplier: crashAt,
		elapsed: timeToReach(crashAt),
		bets,
		lastProfit: profit,
		history: [record, ...s.history].slice(0, MAX_HISTORY),
		hits: s.hits + (hit ? 1 : 0),
		misses: s.misses + (hit ? 0 : 1),
		trauma: s.shakeOff ? 0 : crashAt >= 10 ? .9 : crashAt <= 1.05 ? .55 : .7
	});
	persistSlice(get());
}
function FlightCanvas() {
	const wrapRef = (0, import_react.useRef)(null);
	const canvasRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		const wrap = wrapRef.current;
		if (!canvas || !wrap) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		let raf = 0;
		let running = true;
		let w = 0;
		let h = 0;
		let dpr = 1;
		const points = [];
		const trail = [];
		const particles = [];
		let lastPhase = useGame.getState().phase;
		let lastRound = useGame.getState().round;
		let flyOff = 0;
		const stars = Array.from({ length: 48 }, () => ({
			x: Math.random(),
			y: Math.random(),
			r: Math.random() * 1.2 + .3,
			a: Math.random() * .5 + .15,
			s: Math.random() * .08 + .02
		}));
		const resize = () => {
			const rect = wrap.getBoundingClientRect();
			dpr = Math.min(2, window.devicePixelRatio || 1);
			w = Math.max(1, Math.floor(rect.width));
			h = Math.max(1, Math.floor(rect.height));
			canvas.width = Math.floor(w * dpr);
			canvas.height = Math.floor(h * dpr);
			canvas.style.width = `${w}px`;
			canvas.style.height = `${h}px`;
			ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
		};
		const ro = new ResizeObserver(resize);
		ro.observe(wrap);
		resize();
		const origin = () => ({
			x: 56,
			y: h - 36
		});
		const plot = (elapsed, multiplier) => {
			const o = origin();
			const plotW = w - o.x - 28;
			const plotH = h - 56 - 20;
			const maxT = Math.max(elapsed, 8);
			const maxM = Math.max(multiplier, 2.2);
			return {
				x: o.x + elapsed / maxT * plotW,
				y: o.y - (multiplier - 1) / (maxM - 1) * plotH,
				plotW,
				plotH,
				maxT,
				maxM,
				o
			};
		};
		const burst = (x, y, n) => {
			for (let i = 0; i < n; i++) {
				const a = -Math.PI * .15 - Math.random() * Math.PI * .55;
				const sp = 40 + Math.random() * 220;
				particles.push({
					x,
					y,
					vx: Math.cos(a) * sp,
					vy: Math.sin(a) * sp,
					life: 0,
					max: .45 + Math.random() * .55,
					size: 1 + Math.random() * 2.4,
					hue: Math.random() < .7 ? 0 : 25
				});
			}
		};
		let last = performance.now();
		const loop = (now) => {
			if (!running) return;
			const dt = Math.min(.05, (now - last) / 1e3);
			last = now;
			const g = useGame.getState();
			if (g.round !== lastRound) {
				points.length = 0;
				trail.length = 0;
				particles.length = 0;
				flyOff = 0;
				lastRound = g.round;
			}
			if (g.phase !== lastPhase) {
				if (g.phase === "crashed") {
					const p = plot(g.elapsed, g.multiplier);
					burst(p.x, p.y, 36);
				}
				if (g.phase === "waiting") {
					points.length = 0;
					trail.length = 0;
					flyOff = 0;
				}
				lastPhase = g.phase;
			}
			if (g.phase === "flying") {
				const p = plot(g.elapsed, g.multiplier);
				const lastP = points[points.length - 1];
				if (!lastP || Math.hypot(p.x - lastP.x, p.y - lastP.y) > 1.2) {
					points.push({
						x: p.x,
						y: p.y
					});
					if (points.length > 420) points.shift();
				}
				trail.push({
					x: p.x,
					y: p.y
				});
				if (trail.length > 28) trail.shift();
				if (Math.random() < .55) particles.push({
					x: p.x - 8,
					y: p.y + 2,
					vx: -20 - Math.random() * 40,
					vy: (Math.random() - .5) * 24,
					life: 0,
					max: .35,
					size: 1.2,
					hue: 0
				});
			} else if (g.phase === "crashed") flyOff += dt;
			for (let i = particles.length - 1; i >= 0; i--) {
				const p = particles[i];
				if (!p) continue;
				p.life += dt;
				p.x += p.vx * dt;
				p.y += p.vy * dt;
				p.vy += 80 * dt;
				if (p.life >= p.max) particles.splice(i, 1);
			}
			const trauma = g.shakeOff ? 0 : g.trauma;
			const shake = trauma * trauma;
			const ox = shake ? (Math.random() * 2 - 1) * 10 * shake : 0;
			const oy = shake ? (Math.random() * 2 - 1) * 8 * shake : 0;
			ctx.clearRect(0, 0, w, h);
			ctx.save();
			ctx.translate(ox, oy);
			const sky = ctx.createLinearGradient(0, 0, 0, h);
			sky.addColorStop(0, "#0b1220");
			sky.addColorStop(.55, "#0a0e16");
			sky.addColorStop(1, "#07080c");
			ctx.fillStyle = sky;
			ctx.fillRect(0, 0, w, h);
			for (const st of stars) {
				st.x += st.s * dt * .015;
				if (st.x > 1) st.x -= 1;
				ctx.globalAlpha = st.a * (g.phase === "flying" ? 1 : .7);
				ctx.fillStyle = "#d9e4f7";
				ctx.beginPath();
				ctx.arc(st.x * w, st.y * h, st.r, 0, Math.PI * 2);
				ctx.fill();
			}
			ctx.globalAlpha = 1;
			const pnow = plot(Math.max(g.elapsed, .01), Math.max(g.multiplier, 1.01));
			ctx.strokeStyle = "rgba(238,241,246,0.06)";
			ctx.lineWidth = 1;
			const rows = 4;
			for (let i = 0; i <= rows; i++) {
				const y = pnow.o.y - i / rows * pnow.plotH;
				ctx.beginPath();
				ctx.moveTo(pnow.o.x, y);
				ctx.lineTo(w - 16, y);
				ctx.stroke();
				const m = 1 + (pnow.maxM - 1) * i / rows;
				ctx.fillStyle = "rgba(139,147,167,0.7)";
				ctx.font = "11px Rajdhani, sans-serif";
				ctx.textAlign = "left";
				ctx.fillText(`${m.toFixed(1)}x`, 10, y + 4);
			}
			const cols = 6;
			for (let i = 0; i <= cols; i++) {
				const x = pnow.o.x + i / cols * pnow.plotW;
				ctx.beginPath();
				ctx.moveTo(x, 16);
				ctx.lineTo(x, pnow.o.y);
				ctx.stroke();
			}
			ctx.strokeStyle = "rgba(238,241,246,0.16)";
			ctx.beginPath();
			ctx.moveTo(pnow.o.x, 16);
			ctx.lineTo(pnow.o.x, pnow.o.y);
			ctx.lineTo(w - 16, pnow.o.y);
			ctx.stroke();
			if (points.length > 1) {
				ctx.beginPath();
				ctx.moveTo(pnow.o.x, pnow.o.y);
				ctx.lineTo(points[0].x, points[0].y);
				for (const pt of points) ctx.lineTo(pt.x, pt.y);
				ctx.lineTo(points[points.length - 1].x, pnow.o.y);
				ctx.closePath();
				const fill = ctx.createLinearGradient(0, points[points.length - 1].y, 0, pnow.o.y);
				fill.addColorStop(0, "rgba(255,59,59,0.42)");
				fill.addColorStop(1, "rgba(255,59,59,0.02)");
				ctx.fillStyle = fill;
				ctx.fill();
				ctx.beginPath();
				ctx.moveTo(points[0].x, points[0].y);
				for (const pt of points) ctx.lineTo(pt.x, pt.y);
				ctx.strokeStyle = "#ff3b3b";
				ctx.lineWidth = 3;
				ctx.shadowColor = "#ff3b3b";
				ctx.shadowBlur = 12;
				ctx.stroke();
				ctx.shadowBlur = 0;
			}
			for (const p of particles) {
				const t = 1 - p.life / p.max;
				ctx.globalAlpha = t;
				ctx.fillStyle = p.hue === 0 ? "#ff6b6b" : "#ffd0c0";
				ctx.beginPath();
				ctx.arc(p.x, p.y, p.size * t, 0, Math.PI * 2);
				ctx.fill();
			}
			ctx.globalAlpha = 1;
			let planeX = pnow.o.x;
			let planeY = pnow.o.y;
			let angle = -.45;
			if (g.phase === "flying" && points.length) {
				const a = points[points.length - 1];
				const b = points[Math.max(0, points.length - 4)];
				planeX = a.x;
				planeY = a.y;
				angle = Math.atan2(a.y - b.y, a.x - b.x);
			} else if (g.phase === "crashed" && points.length) {
				const a = points[points.length - 1];
				const b = points[Math.max(0, points.length - 4)];
				angle = Math.atan2(a.y - b.y, a.x - b.x);
				const speed = 180 + flyOff * 240;
				planeX = a.x + Math.cos(angle) * speed * flyOff;
				planeY = a.y + Math.sin(angle) * speed * flyOff;
			}
			drawPlane(ctx, planeX, planeY, angle, g.phase === "crashed" ? Math.max(0, 1 - flyOff * .7) : 1);
			ctx.restore();
			raf = requestAnimationFrame(loop);
		};
		raf = requestAnimationFrame(loop);
		return () => {
			running = false;
			cancelAnimationFrame(raf);
			ro.disconnect();
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: wrapRef,
		className: "absolute inset-0",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
			ref: canvasRef,
			className: "h-full w-full"
		})
	});
}
function drawPlane(ctx, x, y, angle, alpha) {
	ctx.save();
	ctx.translate(x, y);
	ctx.rotate(angle);
	ctx.globalAlpha = alpha;
	ctx.shadowColor = "#ff3b3b";
	ctx.shadowBlur = 18;
	ctx.strokeStyle = "#fff5f5";
	ctx.lineWidth = 1.4;
	ctx.lineJoin = "round";
	ctx.fillStyle = "#ff2d2d";
	ctx.beginPath();
	ctx.moveTo(22, 0);
	ctx.quadraticCurveTo(10, -6, -16, -5);
	ctx.lineTo(-20, -11);
	ctx.lineTo(-22, -5);
	ctx.lineTo(-18, -1);
	ctx.lineTo(-22, 5);
	ctx.lineTo(-20, 10);
	ctx.lineTo(-16, 4);
	ctx.quadraticCurveTo(10, 5, 22, 0);
	ctx.closePath();
	ctx.fill();
	ctx.shadowBlur = 0;
	ctx.stroke();
	ctx.fillStyle = "#b81818";
	ctx.beginPath();
	ctx.moveTo(-1, 1);
	ctx.lineTo(-9, 12);
	ctx.lineTo(4, 2);
	ctx.closePath();
	ctx.fill();
	ctx.fillStyle = "#ffe4e4";
	ctx.beginPath();
	ctx.ellipse(8, -1, 3.6, 1.6, 0, 0, Math.PI * 2);
	ctx.fill();
	ctx.fillStyle = "#ffffff";
	ctx.beginPath();
	ctx.moveTo(22, 0);
	ctx.lineTo(14, -2.2);
	ctx.lineTo(14, 2.2);
	ctx.closePath();
	ctx.fill();
	ctx.restore();
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[opacity,transform,background-color] duration-150 ease-out disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 active:scale-[0.98] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-lift/50", {
	variants: {
		variant: {
			default: "bg-fg text-bg hover:opacity-90",
			lift: "bg-lift text-bg hover:opacity-90",
			crash: "bg-crash text-fg hover:opacity-90",
			outline: "border border-line bg-surface text-fg hover:bg-surface-2",
			ghost: "text-muted hover:text-fg hover:bg-surface-2"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 px-3 text-xs",
			lg: "h-12 px-5",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		"data-slot": "button",
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		...props
	});
}
function AviatorApp() {
	const hydrate = useGame((s) => s.hydrate);
	const tick = useGame((s) => s.tick);
	const started = useGame((s) => s.started);
	(0, import_react.useEffect)(() => {
		hydrate();
	}, [hydrate]);
	(0, import_react.useEffect)(() => {
		let raf = 0;
		let last = performance.now();
		const loop = (now) => {
			const dt = Math.min(.1, (now - last) / 1e3);
			last = now;
			tick(dt);
			raf = requestAnimationFrame(loop);
		};
		raf = requestAnimationFrame(loop);
		return () => cancelAnimationFrame(raf);
	}, [tick]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex min-h-dvh max-w-full flex-col overflow-x-hidden bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistoryStrip, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex w-full max-w-[1180px] flex-1 flex-col gap-3 p-3 pb-6 md:gap-3 md:p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid flex-1 gap-3 lg:grid-cols-[minmax(0,1.35fr)_292px] lg:grid-rows-[minmax(280px,1fr)_auto]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Playfield, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "lg:row-span-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignalPanel, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BetsRow, {})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "px-1 text-pretty text-center text-xs leading-relaxed text-faint",
					children: "AeroPulse is a paper-trade simulator. Real crash games are random and cannot be predicted — including this one. Play for the signal, not the payout."
				})]
			}),
			!started && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StartGate, {})
		]
	});
}
function TopBar() {
	const balance = useGame((s) => s.balance);
	const live = useGame((s) => s.live);
	const muted = useGame((s) => s.muted);
	const setMutedFlag = useGame((s) => s.setMutedFlag);
	const round = useGame((s) => s.round);
	const roomCode = useGame((s) => s.roomCode);
	const hash = useGame((s) => s.hash);
	const resetBank = useGame((s) => s.resetBank);
	const phase = useGame((s) => s.phase);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: "border-b border-line bg-surface",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex h-14 max-w-[1180px] items-center gap-2 px-3 md:gap-3 md:px-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "flex size-8 shrink-0 items-center justify-center rounded-md bg-crash text-fg",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plane, {
						className: "size-4",
						strokeWidth: 2.2
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 leading-tight",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-sm font-semibold tracking-wide",
						children: "AEROPULSE"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "hidden text-[11px] text-muted xs:block sm:block",
						children: "Live multiplier signal"
					})]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "ml-auto flex shrink-0 items-center gap-1 md:gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "hidden items-center gap-2 rounded-full border border-line bg-surface-2 px-3 py-1.5 text-[11px] text-muted lg:flex",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-1.5 rounded-full", live && phase !== "idle" ? "bg-lift animate-pulse" : "bg-faint") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium text-fg",
								children: roomCode
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-faint",
								children: "·"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "tabular-nums",
								children: ["#", round]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden font-mono text-[10px] text-faint md:inline",
								children: hash
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1.5 rounded-full border border-line bg-surface-2 px-3 py-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "size-3.5 text-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-sm font-semibold tabular-nums",
							children: formatMoney(balance)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						className: "size-10",
						"aria-label": muted ? "Unmute" : "Mute",
						onClick: () => setMutedFlag(!muted),
						children: muted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						className: "hidden size-10 sm:inline-flex",
						"aria-label": "Reset bank",
						onClick: resetBank,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" })
					})
				]
			})]
		})
	});
}
function HistoryStrip() {
	const history = useGame((s) => s.history);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "border-b border-line bg-bg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-[1180px] gap-1.5 overflow-x-auto px-3 py-2 md:px-4",
			children: [history.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs text-faint",
				children: "Waiting for the first round…"
			}), history.map((h, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: cn("shrink-0 rounded-full px-2.5 py-1 font-display text-xs font-semibold tabular-nums", h.crash < 2 && "bg-surface-2 text-muted", h.crash >= 2 && h.crash < 10 && "bg-lift/15 text-lift", h.crash >= 10 && "bg-crash/20 text-crash"),
				title: `Signal ${formatX(h.signal)} · ${h.hit ? "HIT" : "MISS"}`,
				children: formatX(h.crash)
			}, `${h.id}-${i}`))]
		})
	});
}
function Playfield() {
	const phase = useGame((s) => s.phase);
	const multiplier = useGame((s) => s.multiplier);
	const waitLeft = useGame((s) => s.waitLeft);
	const crashAt = useGame((s) => s.crashAt);
	const lastProfit = useGame((s) => s.lastProfit);
	const flying = phase === "flying";
	const crashed = phase === "crashed";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative min-h-[240px] overflow-hidden rounded-xl border border-line bg-surface md:min-h-[320px] lg:min-h-[360px] h-full",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FlightCanvas, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pointer-events-none absolute inset-0 flex flex-col items-center justify-center",
			children: [
				(phase === "waiting" || phase === "idle") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] uppercase tracking-[0.22em] text-muted",
							children: "Next round in"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-5xl font-semibold tabular-nums text-fg md:text-6xl",
							children: Math.max(0, waitLeft).toFixed(1)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: "Locking signal"
						})
					]
				}),
				flying && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-6xl font-semibold tabular-nums leading-none text-lift md:text-8xl",
					children: formatX(multiplier)
				}),
				crashed && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] uppercase tracking-[0.28em] text-crash",
							children: "Flew away"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-5xl font-semibold tabular-nums text-crash md:text-7xl",
							children: formatX(crashAt)
						}),
						lastProfit !== 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: cn("mt-2 font-display text-lg font-semibold tabular-nums", lastProfit > 0 ? "text-lift" : "text-muted"),
							children: [lastProfit > 0 ? "+" : "", formatMoney(lastProfit)]
						})
					]
				})
			]
		})]
	});
}
function SignalPanel() {
	const signal = useGame((s) => s.signal);
	const phase = useGame((s) => s.phase);
	const hits = useGame((s) => s.hits);
	const misses = useGame((s) => s.misses);
	const autoPilot = useGame((s) => s.autoPilot);
	const setAutoPilot = useGame((s) => s.setAutoPilot);
	const roomCode = useGame((s) => s.roomCode);
	const setRoomCode = useGame((s) => s.setRoomCode);
	const resetBank = useGame((s) => s.resetBank);
	const shakeOff = useGame((s) => s.shakeOff);
	const setShakeOff = useGame((s) => s.setShakeOff);
	const history = useGame((s) => s.history);
	const total = hits + misses;
	const rate = total === 0 ? 0 : Math.round(hits / total * 100);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-line bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, { className: "size-4 text-lift" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[11px] uppercase tracking-[0.18em]",
								children: "Next signal"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("rounded-full px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide", signal?.risk === "safe" && "bg-lift/15 text-lift", signal?.risk === "pulse" && "bg-surface-2 text-fg", signal?.risk === "moon" && "bg-crash/20 text-crash", !signal && "bg-surface-2 text-muted"),
							children: signal?.risk ?? "scan"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-5xl font-semibold leading-none tabular-nums text-fg",
						children: signal ? formatX(signal.flyTo) : "—.——"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted",
						children: [
							"Cash-out target",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display font-semibold tabular-nums text-lift",
								children: signal ? formatX(signal.cashOut) : "—"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-1 flex justify-between text-[11px] text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Confidence" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "tabular-nums",
								children: [signal?.confidence ?? 0, "%"]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-1.5 overflow-hidden rounded-full bg-surface-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-full rounded-full bg-lift transition-[width] duration-500",
								style: { width: `${signal?.confidence ?? 0}%` }
							})
						})]
					}),
					phase === "waiting" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 flex items-center gap-2 text-xs text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "size-3.5 text-lift" }), "Scanning round hash · place bets now"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-line bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 flex items-center gap-2 text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Activity, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[11px] uppercase tracking-[0.18em]",
							children: "Accuracy"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-3 gap-2 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "Hits",
								value: `${hits}`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "Miss",
								value: `${misses}`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "Rate",
								value: `${rate}%`
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 flex flex-wrap gap-1",
						children: history.slice(0, 12).map((h, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("h-1.5 flex-1 min-w-3 rounded-full", h.hit ? "bg-lift" : "bg-crash/70") }, `${h.id}-bar-${i}`))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-line bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-[11px] uppercase tracking-[0.18em] text-muted",
						htmlFor: "room",
						children: "Linked room"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "room",
						value: roomCode,
						onChange: (e) => setRoomCode(e.target.value),
						className: "mt-2 h-11 w-full rounded-md border border-line bg-surface-2 px-3 font-display text-sm tracking-wide text-fg outline-none focus:ring-2 focus:ring-lift/40",
						maxLength: 24,
						spellCheck: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-pretty text-xs text-faint",
						children: "Same room code + round produces the same crash seed in this simulator."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-col gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
								label: "Auto-pilot bets",
								on: autoPilot,
								onToggle: () => setAutoPilot(!autoPilot)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
								label: "Reduce shake",
								on: shakeOff,
								onToggle: () => setShakeOff(!shakeOff)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: resetBank,
								className: "flex h-11 items-center justify-between rounded-md px-1 text-sm text-muted sm:hidden",
								children: ["Reset bank", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" })]
							})
						]
					})
				]
			})
		]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-md bg-surface-2 px-2 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-lg font-semibold tabular-nums",
			children: value
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[10px] uppercase tracking-wide text-muted",
			children: label
		})]
	});
}
function ToggleRow({ label, on, onToggle }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: onToggle,
		className: "flex h-11 items-center justify-between rounded-md px-1 text-sm text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("relative h-6 w-10 rounded-full transition-colors", on ? "bg-lift" : "bg-surface-2"),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("absolute top-0.5 size-5 rounded-full bg-fg transition-transform", on ? "translate-x-4" : "translate-x-0.5") })
		})]
	});
}
function BetsRow() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-3 md:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BetCard, {
			slot: 0,
			label: "Bet A"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BetCard, {
			slot: 1,
			label: "Bet B"
		})]
	});
}
function BetCard({ slot, label }) {
	const bet = useGame((s) => s.bets[slot]);
	const phase = useGame((s) => s.phase);
	const setBetAmount = useGame((s) => s.setBetAmount);
	const placeBet = useGame((s) => s.placeBet);
	const cashOut = useGame((s) => s.cashOut);
	const toggleAutoCash = useGame((s) => s.toggleAutoCash);
	const setAutoCashAt = useGame((s) => s.setAutoCashAt);
	const multiplier = useGame((s) => s.multiplier);
	const balance = useGame((s) => s.balance);
	const [draft, setDraft] = (0, import_react.useState)(String(bet.amount));
	const [cashDraft, setCashDraft] = (0, import_react.useState)(String(bet.autoCashAt));
	(0, import_react.useEffect)(() => {
		setDraft(String(bet.amount));
	}, [bet.amount]);
	(0, import_react.useEffect)(() => {
		setCashDraft(String(bet.autoCashAt));
	}, [bet.autoCashAt]);
	const canBet = phase === "waiting" && !bet.placed && balance >= bet.amount;
	const canCash = phase === "flying" && bet.placed && bet.cashedAt === null;
	const livePayout = bet.placed && bet.cashedAt === null && phase === "flying" ? bet.amount * multiplier : bet.payout;
	const commitAmount = () => {
		const n = clampBet(Number(draft));
		setBetAmount(slot, n);
		setDraft(String(n));
	};
	const commitCash = () => {
		const n = Math.max(1.01, Number(cashDraft) || 2);
		setAutoCashAt(slot, Math.round(n * 100) / 100);
		setCashDraft(String(Math.round(n * 100) / 100));
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-line bg-surface p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-center justify-between",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] uppercase tracking-[0.18em] text-muted",
						children: label
					}),
					bet.result === "win" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-display text-sm font-semibold tabular-nums text-lift",
						children: ["+", formatMoney(bet.payout - bet.amount)]
					}),
					bet.result === "lose" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-display text-sm font-semibold tabular-nums text-crash",
						children: ["−", formatMoney(bet.amount)]
					}),
					bet.placed && bet.cashedAt === null && phase === "flying" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-sm font-semibold tabular-nums text-fg",
						children: formatMoney(livePayout)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 gap-2 sm:grid-cols-[minmax(0,1fr)_auto]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex h-11 min-w-0 items-center rounded-md border border-line bg-surface-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "h-11 w-11 text-lg text-muted",
							disabled: bet.placed,
							onClick: () => setBetAmount(slot, clampBet(bet.amount / 2)),
							"aria-label": "Halve bet",
							children: "−"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "h-11 min-w-0 flex-1 bg-transparent text-center font-display text-lg font-semibold tabular-nums outline-none",
							value: draft,
							disabled: bet.placed,
							inputMode: "decimal",
							onChange: (e) => setDraft(e.target.value),
							onBlur: commitAmount,
							"aria-label": `${label} amount`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "h-11 w-11 text-lg text-muted",
							disabled: bet.placed,
							onClick: () => setBetAmount(slot, clampBet(bet.amount * 2)),
							"aria-label": "Double bet",
							children: "+"
						})
					]
				}), canCash ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "lift",
					className: "w-full min-w-0 sm:min-w-[148px] sm:w-auto",
					onClick: () => cashOut(slot),
					children: ["Cash out ", formatX(multiplier)]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: bet.placed ? "outline" : "default",
					className: "w-full min-w-0 sm:min-w-[148px] sm:w-auto",
					disabled: !canBet,
					onClick: () => placeBet(slot),
					children: bet.placed ? "In play" : "Bet"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex items-center gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => toggleAutoCash(slot),
						className: "flex h-11 items-center gap-2 text-sm text-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("flex size-4 items-center justify-center rounded-sm border", bet.autoCash ? "border-lift bg-lift" : "border-line"),
								children: bet.autoCash && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full bg-bg" })
							}),
							"Auto ",
							formatX(bet.autoCashAt)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "h-11 w-24 rounded-md border border-line bg-surface-2 px-2 text-center font-display text-sm tabular-nums outline-none focus:ring-2 focus:ring-lift/40",
						value: cashDraft,
						onChange: (e) => setCashDraft(e.target.value),
						onBlur: commitCash,
						inputMode: "decimal",
						"aria-label": "Auto cash-out multiplier"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-faint",
						children: "x"
					})
				]
			})
		]
	});
}
function StartGate() {
	const startLive = useGame((s) => s.startLive);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-20 flex items-center justify-center bg-bg/80 p-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md rounded-xl border border-line bg-surface p-6 text-center shadow-[0_24px_80px_rgba(0,0,0,0.45)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mx-auto mb-4 flex size-12 items-center justify-center rounded-lg bg-crash",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plane, { className: "size-6" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl font-semibold tracking-tight",
					children: "AeroPulse"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-pretty text-sm leading-relaxed text-muted",
					children: "Link a room, read the next fly-to signal, and paper-trade the climb. Auto-pilot keeps calling cash-outs while the plane runs."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-6 w-full",
					size: "lg",
					onClick: startLive,
					children: "Start live feed"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-xs text-faint",
					children: [
						"Bank ",
						formatMoney(START_BANK),
						" · simulator only"
					]
				})
			]
		})
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AviatorApp, {});
}
//#endregion
export { Home as component };
