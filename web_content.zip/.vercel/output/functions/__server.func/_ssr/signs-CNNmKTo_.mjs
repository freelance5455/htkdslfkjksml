//#region node_modules/.nitro/vite/services/ssr/assets/signs-CNNmKTo_.js
var CATS = [
	{
		id: "pericolo",
		it: "Pericolo",
		ar: "خطر"
	},
	{
		id: "divieto",
		it: "Divieto",
		ar: "منع"
	},
	{
		id: "obbligo",
		it: "Obbligo",
		ar: "إلزام"
	},
	{
		id: "precedenza",
		it: "Precedenza",
		ar: "أولوية"
	},
	{
		id: "indicazione",
		it: "Indicazione",
		ar: "إرشاد"
	},
	{
		id: "orizzontale",
		it: "Orizzontale",
		ar: "أرضية"
	},
	{
		id: "semaforo",
		it: "Semaforo",
		ar: "إشارة ضوئية"
	},
	{
		id: "agenti",
		it: "Agenti",
		ar: "رجال المرور"
	},
	{
		id: "pannelli",
		it: "Pannelli",
		ar: "لوحات مكمّلة"
	},
	{
		id: "cantiere",
		it: "Cantiere",
		ar: "أعمال طريق"
	}
];
var SIGNS = [
	s("curva-dx", "pericolo", "Curva pericolosa a destra", "منحنى خطر لليمين", "Preannuncia una curva stretta a destra. Si rallenta prima di entrare.", "ينبّه إلى منحنى حاد يمينًا. خفّف السرعة قبل الدخول."),
	s("curva-sx", "pericolo", "Curva pericolosa a sinistra", "منحنى خطر لليسار", "Preannuncia una curva stretta a sinistra.", "ينبّه إلى منحنى حاد يسارًا."),
	s("doppia-dx", "pericolo", "Doppia curva, la prima a destra", "منحنيان، الأول لليمين", "Due curve vicine. La prima è a destra.", "منحنيان متتاليان. الأول إلى اليمين."),
	s("doppia-sx", "pericolo", "Doppia curva, la prima a sinistra", "منحنيان، الأول لليسار", "Due curve vicine. La prima è a sinistra.", "منحنيان متتاليان. الأول إلى اليسار."),
	s("dosso", "pericolo", "Dosso", "مطب / قمة مرتفعة", "Cambio di pendenza: la visibilità oltre il dosso è limitata. Vietato sorpassare se non si vede.", "تغيّر في الميل يخفي ما بعده. التجاوز ممنوع إن لم ترَ الطريق."),
	s("cunetta", "pericolo", "Cunetta", "منخفض مقعّر", "Avvallamento della strada. Si moderano velocità e sospensioni.", "هبوط ثم صعود. خفّف السرعة."),
	s("dissestata", "pericolo", "Strada deformata", "طريق مشوّه", "Fondo irregolare: buche o ondulazioni.", "سطح غير مستوٍ: حفر أو تموجات."),
	s("strettoia", "pericolo", "Strettoia simmetrica", "تضيّق من الجانبين", "La carreggiata si restringe dai due lati.", "الطريق يضيق من الجهتين."),
	s("strettoia-dx", "pericolo", "Strettoia asimmetrica a destra", "تضيّق من اليمين", "Il restringimento è sul lato destro.", "التضيّق من الجهة اليمنى."),
	s("discesa", "pericolo", "Discesa pericolosa", "منحدر خطر", "Forte pendenza in discesa. Usare marce basse, non abusare dei freni.", "نزول حاد. استخدم غيارًا منخفضًا ولا تُرهق الفرامل."),
	s("salita", "pericolo", "Salita ripida", "طلوع حاد", "Forte pendenza in salita.", "صعود شديد الانحدار."),
	s("sdrucciolevole", "pericolo", "Strada sdrucciolevole", "طريق زلق", "Fondo scivoloso per pioggia, ghiaccio, fango o foglie.", "الطريق ينزلق بسبب مطر أو جليد أو وحل."),
	s("bambini", "pericolo", "Bambini", "أطفال", "Possibile attraversamento di bambini, spesso vicino a scuole.", "احتمال عبور أطفال، غالبًا قرب المدارس."),
	s("pedoni", "pericolo", "Attraversamento pedonale", "عبور مشاة (خطر)", "Preavvisa un passaggio pedoni. Non è il segnale di ubicazione blu.", "ينبّه قبل ممر مشاة. ليس لوحة الموقع الزرقاء."),
	s("bici-pericolo", "pericolo", "Ciclisti", "درّاجون", "Possibile presenza o attraversamento di biciclette.", "احتمال وجود درّاجات أو عبورها."),
	s("animali", "pericolo", "Animali domestici vaganti", "حيوانات أليفة سائبة", "Attenzione ad animali da allevamento sulla strada.", "احذر حيوانات المزرعة على الطريق."),
	s("selvatici", "pericolo", "Animali selvatici", "حيوانات برية", "Attraversamento improvviso di fauna selvatica, tipico di boschi.", "عبور مفاجئ لحيوانات برية، شائع قرب الغابات."),
	s("lavori", "pericolo", "Lavori in corso", "أعمال على الطريق", "Cantiere o operai. È un triangolo bianco-rosso fisso, non il giallo temporaneo.", "ورشة أو عمال. المثلث أبيض بحافة حمراء، ليس الأصفر المؤقت."),
	s("massi", "pericolo", "Caduta massi", "تساقط صخور", "Da sinistra del disegno cadono sassi. Non fermarsi nella zona.", "صخور قد تسقط من الجانب. لا تقف في المنطقة."),
	s("ghiaia", "pericolo", "Materiale instabile sulla strada", "حصى سائب", "Ghiaia o pietrisco: rischio di sbandamento e di proiezione di sassi.", "حصى قد يسبب انزلاقًا أو تطاير حجارة."),
	s("banchina", "pericolo", "Banchina cedevole", "كتف غير ثابت", "Il bordo laterale non regge il peso del veicolo.", "كتف الطريق لا يتحمّل وزن السيارة."),
	s("passaggio-barriere", "pericolo", "Passaggio a livello con barriere", "مزلقان بحواجز", "Attraversamento ferroviario con barriere o semibarriere.", "تقاطع سكة حديد فيه حواجز."),
	s("passaggio-senza", "pericolo", "Passaggio a livello senza barriere", "مزلقان بلا حواجز", "Binari senza barriere. Fermarsi, guardare, ascoltare.", "قضبان بلا حواجز. قف وانظر واستمع."),
	s("croce", "pericolo", "Croce di Sant'Andrea", "صليب سكة الحديد", "Indica l'immediata vicinanza dei binari. Con una barra: un solo binario; doppia croce o pannello: più binari.", "يلصق قرب القضبان مباشرة. شريط واحد يعني سكة واحدة."),
	s("semaforo-pericolo", "pericolo", "Semaforo", "إشارة ضوئية قادمة", "Preavvisa un impianto semaforico, utile se è poco visibile.", "ينبّه إلى إشارة مرور قد لا تُرى مبكرًا."),
	s("intersezione", "pericolo", "Intersezione", "تقاطع", "Incrocio generico. Di norma vale la precedenza a destra, salvo segnali.", "تقاطع عام. الأصل إعطاء الأولوية لمن يأتي من اليمين ما لم توجد إشارة."),
	s("precedenza-incrocio", "pericolo", "Intersezione con diritto di precedenza", "تقاطع ولك الأولوية", "Il tratto verticale grosso è la tua strada: hai la precedenza sull'incrocio.", "الخط السميك هو طريقك: لك الأولوية في التقاطع."),
	s("confluenza-dx", "pericolo", "Confluenza da destra", "اندماج من اليمين", "Una strada secondaria si immette da destra.", "طريق فرعي يدخل من اليمين."),
	s("confluenza-sx", "pericolo", "Confluenza da sinistra", "اندماج من اليسار", "Una strada secondaria si immette da sinistra.", "طريق فرعي يدخل من اليسار."),
	s("vento", "pericolo", "Vento laterale", "ريح جانبية", "Raffiche di traverso, frequenti su viadotti e uscite di galleria.", "هبّات جانبية، شائعة على الجسور ومخارج الأنفاق."),
	s("doppio-senso", "pericolo", "Doppio senso di circolazione", "سير في الاتجاهين", "Finisce il senso unico e arriva traffico frontale.", "ينتهي الاتجاه الواحد ويبدأ القادم من الأمام."),
	s("altri", "pericolo", "Altri pericoli", "أخطار أخرى", "Pericolo non rappresentato dagli altri simboli. Leggere il pannello integrativo.", "خطر غير مرسوم بالرموز المعتادة. اقرأ اللوحة المكمّلة."),
	s("transito", "divieto", "Divieto di transito", "ممنوع المرور", "Vieta il transito ai veicoli nei due sensi. Non è il senso vietato.", "يمنع مرور المركبات في الاتجاهين. ليس «اتجاه ممنوع»."),
	s("senso-vietato", "divieto", "Senso vietato", "اتجاه ممنوع", "Disco rosso con barra bianca orizzontale: non entrare da questo lato. Dall'altro lato la strada è a senso unico.", "قرص أحمر بشريط أبيض أفقي: لا تدخل من هذه الجهة."),
	s("sorpasso", "divieto", "Divieto di sorpasso", "ممنوع التجاوز", "Vieta il sorpasso dei veicoli a motore, salvo i ciclomotori e i motocicli a due ruote in molti casi d'esame: il divieto riguarda il sorpasso di veicoli a motore diversi da quelli a due ruote e ciclomotori, secondo la figura classica (auto che sorpassa).", "يمنع تجاوز المركبات الآلية. انتبه لصيغ الامتحان: غالبًا يُستثنى تجاوز الدراجات النارية ذات العجلتين والدراجات البخارية الصغيرة بحسب نص السؤال."),
	s("fine-sorpasso", "divieto", "Fine del divieto di sorpasso", "نهاية منع التجاوز", "Bordo nero e barra diagonale: il divieto precedente termina. Non è un divieto nuovo.", "حافة سوداء وخط مائل: ينتهي المنع السابق. ليست إشارة منع جديدة."),
	s("limite-50", "divieto", "Limite di velocità 50 km/h", "حد 50 كم/س", "Non superare 50 km/h dal segnale fino a fine limite, incrocio o limite diverso.", "لا تتجاوز 50 من الإشارة حتى نهايتها أو تقاطع أو حد آخر."),
	s("limite-30", "divieto", "Limite di velocità 30 km/h", "حد 30 كم/س", "Limite massimo locale di 30 km/h.", "حد أقصى محلي 30 كم/س."),
	s("limite-90", "divieto", "Limite di velocità 90 km/h", "حد 90 كم/س", "Limite massimo locale di 90 km/h.", "حد أقصى محلي 90 كم/س."),
	s("limite-110", "divieto", "Limite di velocità 110 km/h", "حد 110 كم/س", "Limite massimo locale di 110 km/h.", "حد أقصى محلي 110 كم/س."),
	s("limite-130", "divieto", "Limite di velocità 130 km/h", "حد 130 كم/س", "Limite massimo locale di 130 km/h, tipico richiamo in autostrada.", "حد أقصى محلي 130، غالبًا تذكير على الأوتوسترادا."),
	s("fine-limite-50", "divieto", "Fine limite di 50", "نهاية حد 50", "Termina quel limite. Tornano i limiti generali della strada.", "ينتهي هذا الحد وتعود الحدود العامة لنوع الطريق."),
	s("sosta", "divieto", "Divieto di sosta", "ممنوع الوقوف", "Croce blu e rossa. La sosta è vietata, la fermata breve per far salire o scendere passeggeri è ancora consentita.", "صليب أزرق وأحمر. الوقوف الطويل ممنوع، والتوقف القصير لصعود أو نزول الركاب مسموح."),
	s("fermata", "divieto", "Divieto di fermata", "ممنوع التوقف", "Croce rossa. Vieta sia la fermata sia la sosta, salvo l'arresto imposto dal traffico.", "صليب أحمر. يمنع التوقف القصير والوقوف، إلا التوقف الذي تفرضه حركة السير."),
	s("clacson", "divieto", "Divieto di segnalazioni acustiche", "ممنوع البوق", "Non usare il clacson, salvo pericolo immediato.", "لا تستخدم البوق إلا لخطر داهم."),
	s("inversione", "divieto", "Divieto di inversione di marcia", "ممنوع الدوران للخلف", "Non fare inversione a U in quel tratto.", "ممنوع الالتفاف نصف دورة في هذا المقطع."),
	s("divieto-auto", "divieto", "Divieto di transito agli autoveicoli", "ممنوع السيارات", "Vieta il transito delle autovetture. Non riguarda necessariamente tutti i veicoli.", "يمنع مرور السيارات. ليس بالضرورة كل المركبات."),
	s("divieto-camion", "divieto", "Transito vietato agli autocarri", "ممنوع الشاحنات", "Vieta i veicoli merci indicati. Un pannello può precisare la massa.", "يمنع شاحنات البضائع. لوحة قد تحدد الوزن."),
	s("divieto-pedoni", "divieto", "Transito vietato ai pedoni", "ممنوع المشاة", "I pedoni non possono entrare.", "المشاة ممنوعون من الدخول."),
	s("divieto-bici", "divieto", "Transito vietato alle biciclette", "ممنوع الدراجات", "Le biciclette non possono transitare.", "الدراجات ممنوعة."),
	s("fine-divieti", "divieto", "Fine di tutti i divieti precedenti", "نهاية كل الممنوعات السابقة", "Termina i divieti locali iniziati prima. Non cancella i limiti generali di legge.", "تنهي الممنوعات المحلية السابقة. لا تلغي الحدود العامة في القانون."),
	s("dritto", "obbligo", "Direzione obbligatoria dritto", "اتجاه إجباري للأمام", "Si deve proseguire diritto.", "يجب متابعة السير للأمام."),
	s("destra", "obbligo", "Direzione obbligatoria a destra", "اتجاه إجباري لليمين", "Si deve svoltare a destra.", "يجب الانعطاف يمينًا."),
	s("sinistra", "obbligo", "Direzione obbligatoria a sinistra", "اتجاه إجباري لليسار", "Preavviso o obbligo di svolta a sinistra, secondo il disegno della freccia.", "يلزم بالاتجاه نحو اليسار."),
	s("dritto-destra", "obbligo", "Diritto o destra", "أمام أو يمين", "Consentite solo queste due direzioni.", "مسموح فقط هذان الاتجاهان."),
	s("passaggio-dx", "obbligo", "Passaggio obbligatorio a destra", "مرور إجباري عن اليمين", "L'ostacolo o lo spartitraffico si supera a destra.", "تتجاوز العائق أو الجزيرة من اليمين."),
	s("rotatoria", "obbligo", "Circolazione rotatoria", "دوران إلزامي", "Obbliga il senso della rotatoria, in Italia antiorario. Di solito è accompagnato dal dare precedenza a chi è già dentro.", "يلزم بالدوران عكس عقارب الساعة. غالبًا معه «أعطِ الأولوية» لمن داخل الدوار."),
	s("pedoni-obb", "obbligo", "Percorso pedonale", "ممر مشاة إجباري", "Via riservata ai pedoni.", "طريق مخصص للمشاة."),
	s("bici-obb", "obbligo", "Pista ciclabile", "مسار درّاجات إجباري", "Le biciclette devono usare questo percorso.", "الدراجات يجب أن تسلك هذا المسار."),
	s("catene", "obbligo", "Catene o pneumatici da neve", "سلاسل أو إطارات ثلج", "Obbligo di catene a bordo montabili, o gomme da neve, nel tratto.", "إلزام بسلاسل جاهزة للتركيب أو إطارات ثلجية في هذا المقطع."),
	s("vmin-30", "obbligo", "Velocità minima 30 km/h", "سرعة دنيا 30", "Disco blu: non scendere sotto i 30 km/h, salvo il traffico. Non è un limite massimo.", "قرص أزرق: لا تنزل تحت 30 إلا إذا أجبرتك الحركة. ليس حدًا أقصى."),
	s("dare", "precedenza", "Dare precedenza", "أعطِ الأولوية", "Triangolo rovesciato. Rallentare ed essere pronti a fermarsi. Lo stop completo non è sempre obbligatorio se la via è libera, ma la precedenza è degli altri.", "مثلث مقلوب. خفّف وكن مستعدًا للوقوف. الوقوف التام ليس دائمًا واجبًا إذا كان الطريق خاليًا، لكن الأولوية للآخرين."),
	s("stop", "precedenza", "Fermarsi e dare precedenza", "قف وأعطِ الأولوية", "Arresto completo sulla linea, anche se non arriva nessuno, poi dare precedenza.", "وقوف تام عند الخط حتى لو لم يأتِ أحد، ثم إعطاء الأولوية."),
	s("diritto", "precedenza", "Strada con diritto di precedenza", "طريق ذو أولوية", "Losanga gialla. Hai la precedenza negli incroci lungo questo tratto, fino al segnale di fine.", "معيّن أصفر. لك الأولوية في التقاطعات حتى إشارة النهاية."),
	s("fine-diritto", "precedenza", "Fine del diritto di precedenza", "نهاية حق الأولوية", "Termina la strada privilegiata. Torna la regola generale.", "تنتهي الأفضلية. تعود القاعدة العامة."),
	s("autostrada", "indicazione", "Inizio autostrada", "بداية أوتوسترادا", "Fondo verde. Inizia il regime autostradale: niente pedoni, biciclette, ciclomotori, animali, veicoli senza velocità sufficiente.", "خلفية خضراء. يبدأ نظام الطريق السريع: لا مشاة ولا دراجات ولا دراجات بخارية صغيرة."),
	s("fine-autostrada", "indicazione", "Fine autostrada", "نهاية أوتوسترادا", "Termina l'autostrada. Cambiano limiti e divieti.", "تنتهي الأوتوسترادا وتتغير الحدود والممنوعات."),
	s("ospedale", "indicazione", "Ospedale", "مستشفى", "Segnale blu di indicazione. Non dà da solo un limite, ma spesso la zona è sensibile al rumore.", "إرشاد أزرق. لا يضع وحده حد سرعة، لكن المكان حسّاس للضجيج."),
	s("soccorso", "indicazione", "Soccorso stradale", "إغاثة طريق", "Punto o direzione di assistenza ai veicoli.", "نقطة أو اتجاه مساعدة المركبات."),
	s("benzina", "indicazione", "Rifornimento", "وقود", "Distributore di carburante.", "محطة وقود."),
	s("parcheggio", "indicazione", "Parcheggio", "موقف", "Area dove la sosta è ammessa secondo le regole locali.", "مكان يُسمح فيه بالوقوف حسب القواعد المحلية."),
	s("abitato", "indicazione", "Inizio centro abitato", "بداية منطقة سكنية", "Pannello bianco con il nome. Di regola il limite diventa 50 km/h salvo diverso segnale.", "لوحة بيضاء بالاسم. الأصل أن الحد يصير 50 كم/س ما لم تُوجد إشارة أخرى."),
	s("fine-abitato", "indicazione", "Fine centro abitato", "نهاية منطقة سكنية", "Sbarra rossa sul nome. Finisce il limite urbano dei 50, tornano i limiti extraurbani.", "خط أحمر على الاسم. ينتهي حد الخمسين وتعود حدود خارج العمران."),
	s("senso-unico", "indicazione", "Senso unico", "اتجاه واحد", "Freccia bianca su fondo blu: il traffico scorre solo nel senso della freccia.", "سهم أبيض على أزرق: السير في اتجاه السهم فقط."),
	s("senza-uscita", "indicazione", "Strada senza uscita", "طريق مسدود", "Il fondo rosso in cima indica che non c'è sbocco.", "الأحمر في الأعلى يعني لا مخرج."),
	s("attraversamento", "indicazione", "Ubicazione attraversamento pedonale", "موقع ممر المشاة", "Quadrato blu: sei sull'attraversamento. Il triangolo invece è un preavviso.", "مربع أزرق: أنت عند الممر. المثلث مجرد إنذار مسبق."),
	s("preavviso", "indicazione", "Preavviso di direzione", "لوحة اتجاه مسبقة", "Su autostrada il fondo è verde; sulle extraurbane principali è blu; sulle altre strade è bianco.", "على الأوتوسترادا الخلفية خضراء، وعلى الطرق الرئيسية خارج العمران زرقاء، وعلى غيرها بيضاء."),
	s("continua", "orizzontale", "Striscia continua", "خط متصل", "Non si attraversa e non si sorpassa invadendola. Separa sensi o corsie in modo rigido.", "لا تقطعه ولا تتجاوز بعبوره."),
	s("discontinua", "orizzontale", "Striscia discontinua", "خط متقطع", "Si può superare per sorpassare o cambiare corsia se la manovra è sicura.", "يجوز تجاوزه للتجاوز أو تغيير المسلك إذا كانت المناورة آمنة."),
	s("doppia-continua", "orizzontale", "Doppia striscia continua", "خطان متصلان", "Divieto di attraversamento per entrambi i sensi.", "ممنوع العبور من الاتجاهين."),
	s("zebrato", "orizzontale", "Attraversamento pedonale", "خطوط المشاة", "Strisce dove i pedoni hanno precedenza quando attraversano. Non sostare sopra.", "خطوط يعبر عليها المشاة ولهم الأولوية. لا تقف فوقها."),
	s("stop-terra", "orizzontale", "Scritta STOP a terra", "كلمة STOP على الأرض", "Ribadisce l'obbligo di arresto. La linea trasversale continua è il punto di stop.", "تؤكد وجوب الوقوف. الخط العرضي هو مكان الوقوف."),
	s("freccia-suolo", "orizzontale", "Freccia direzionale", "سهم اتجاه على الأرض", "Obbliga la direzione della corsia. Non è un semplice consiglio.", "يلزم باتجاه المسلك. ليس مجرد نصيحة."),
	s("corsia-bus", "orizzontale", "Corsia riservata", "مسلك مخصص", "Scritta BUS o taxi: la corsia è riservata. Non circolare né sostare.", "كلمة BUS: المسلك مخصص. لا تسر فيه ولا تقف."),
	s("rosso", "semaforo", "Luce rossa", "ضوء أحمر", "Arresto prima della linea. Non impegnare l'incrocio.", "قف قبل الخط. لا تدخل التقاطع."),
	s("giallo", "semaforo", "Luce gialla fissa", "ضوء أصفر ثابت", "Come il braccio alzato dell'agente: fermarsi se si può farlo senza pericolo; se si è già dentro, sgomberare.", "مثل ذراع رجل المرور المرفوعة: قف إن أمكن بأمان؛ وإن كنت داخل التقاطع فأخله بسرعة."),
	s("verde", "semaforo", "Luce verde", "ضوء أخضر", "Si può passare se l'incrocio è libero. Il verde non autorizza a investire pedoni o a ignorare un agente.", "يمكنك المرور إذا كان التقاطع خاليًا. الأخضر لا يبيح دهس المشاة ولا مخالفة رجل المرور."),
	s("lampeggiante", "semaforo", "Giallo lampeggiante", "أصفر وامض", "Incrocio o pericolo da affrontare con prudenza. Valgono le regole di precedenza, non è un via libera assoluto.", "تعامل بحذر. تطبق قواعد الأولوية، وليس إذنًا مطلقًا بالمرور."),
	s("freccia-verde", "semaforo", "Freccia verde", "سهم أخضر", "Consente la marcia solo nella direzione della freccia.", "يسمح بالسير في اتجاه السهم فقط."),
	s("corsia-x", "semaforo", "Luce di corsia rossa a X", "إكس أحمر للمسلك", "La corsia è chiusa. Una freccia verde sopra la corsia la dichiara percorribile.", "المسلك مغلق. السهم الأخضر فوقه يعني أنه مفتوح."),
	s("agente-alt", "agenti", "Braccio alzato in verticale", "ذراع مرفوعة عموديًا", "Equivale al giallo fisso, non al rosso. Fermarsi se è sicuro; se l'incrocio è già impegnato, liberarlo subito.", "تعادل الأصفر الثابت لا الأحمر. قف إن كان آمنًا؛ وإن دخلت التقاطع فأخله فورًا."),
	s("agente-fronte", "agenti", "Braccia distese, visto di fronte", "ذراعان ممدودتان وأنت أمامه", "Chi vede il petto o la schiena deve fermarsi.", "من يرى صدره أو ظهره يجب أن يقف."),
	s("agente-profilo", "agenti", "Braccia distese, visto di lato", "ذراعان ممدودتان وأنت من جانبه", "Chi arriva dal fianco, in direzione parallela alle braccia, ha via libera.", "من يأتي من الجنب موازيًا للذراعين يمر."),
	s("pannello-distanza", "pannelli", "Pannello di distanza", "لوحة المسافة", "Indica fra quanti metri comincia il pericolo o il divieto. Esempio: 150 m.", "تبيّن بعد كم متر يبدأ الخطر أو المنع. مثال: 150 م."),
	s("pannello-estesa", "pannelli", "Pannello di estesa", "لوحة الامتداد", "Indica per quanti chilometri vale il segnale. Esempio: 3 km.", "تبيّن كم كيلومترًا تبقى الإشارة سارية. مثال: 3 كم."),
	s("pannello-ghiaccio", "pannelli", "Pannello integrativo", "لوحة مكمّلة", "Precisa il motivo o la categoria: ghiaccio, pioggia, autocarri, eccezione.", "تحدد السبب أو الفئة: جليد، مطر، شاحنات، استثناء."),
	s("pannello-orario", "pannelli", "Validità oraria", "سريان زمني", "Il segnale vale solo nelle ore e nei giorni scritti.", "الإشارة تسري فقط في الساعات والأيام المكتوبة."),
	s("cantiere", "cantiere", "Lavori temporanei", "أعمال مؤقتة", "Fondo giallo: segnaletica di cantiere, prevale su quella permanente contraddittoria vicina.", "خلفية صفراء: إشارة ورشة، وتغلّب الإشارة الدائمة المتعارضة القريبة."),
	s("deviazione", "cantiere", "Deviazione temporanea", "تحويلة مؤقتة", "Freccia gialla: percorso obbligato per il cantiere.", "سهم أصفر: مسار إجباري بسبب الأعمال."),
	s("coni", "cantiere", "Cono stradale", "قمع مروري", "Delimita la zona di lavori o un ostacolo temporaneo. Non si attraversa la fila di coni.", "يحدّد منطقة العمل أو عائقًا مؤقتًا. لا تقطع صف الأقماع.")
];
function s(id, cat, nameIt, nameAr, explainIt, explainAr) {
	return {
		id,
		cat,
		nameIt,
		nameAr,
		explainIt,
		explainAr
	};
}
function signById(id) {
	return SIGNS.find((x) => x.id === id);
}
//#endregion
export { SIGNS as n, signById as r, CATS as t };
