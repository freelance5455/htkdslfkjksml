import { a as LOCATION_MAP, c as ROLE_META, d as SUPPLIERS, f as UPGRADE_COST, i as CUSTOMER_META, l as STAFF_NAMES, n as loadSave, o as PRODUCTS, p as storeFootprint, r as writeSave, s as PRODUCT_MAP, u as STORE_LABELS } from "./routes-CPFWFcjq.mjs";
import { _ as SphereGeometry, a as DirectionalLight, c as HemisphereLight, d as PerspectiveCamera, f as PlaneGeometry, g as Scene, h as SRGBColorSpace, i as Color, l as Mesh, m as RepeatWrapping, n as BoxGeometry, o as Fog, p as PointLight, r as CanvasTexture, s as Group, t as WebGLRenderer, u as MeshStandardMaterial, v as Vector3 } from "../_libs/three.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/engine-D9NJmTdq.js
var GameAudio = class {
	ctx = null;
	master = null;
	sfx = null;
	music = null;
	sfxVol = .7;
	musicVol = .35;
	muted = false;
	musicTimer = 0;
	hum = null;
	humGain = null;
	unlock() {
		if (!this.ctx) {
			const C = window.AudioContext || window.webkitAudioContext;
			this.ctx = new C({ latencyHint: "interactive" });
			this.master = this.ctx.createGain();
			this.sfx = this.ctx.createGain();
			this.music = this.ctx.createGain();
			this.sfx.connect(this.master);
			this.music.connect(this.master);
			this.master.connect(this.ctx.destination);
			this.applyVol();
		}
		if (this.ctx.state === "suspended") this.ctx.resume();
		this.startHum();
	}
	applyVol() {
		if (!this.master || !this.sfx || !this.music || !this.ctx) return;
		const t = this.ctx.currentTime;
		this.master.gain.setTargetAtTime(this.muted ? 0 : 1, t, .02);
		this.sfx.gain.setTargetAtTime(this.sfxVol * this.sfxVol, t, .02);
		this.music.gain.setTargetAtTime(this.musicVol * this.musicVol * .45, t, .04);
	}
	startHum() {
		if (!this.ctx || !this.music || this.hum) return;
		const osc = this.ctx.createOscillator();
		const g = this.ctx.createGain();
		osc.type = "sine";
		osc.frequency.value = 92;
		g.gain.value = .04;
		const f = this.ctx.createBiquadFilter();
		f.type = "lowpass";
		f.frequency.value = 240;
		osc.connect(f);
		f.connect(g);
		g.connect(this.music);
		osc.start();
		this.hum = osc;
		this.humGain = g;
	}
	beep(freq, dur = .08, type = "square", gain = .08) {
		if (!this.ctx || !this.sfx) return;
		const t = this.ctx.currentTime;
		const o = this.ctx.createOscillator();
		const g = this.ctx.createGain();
		o.type = type;
		o.frequency.value = freq * (.97 + Math.random() * .06);
		g.gain.setValueAtTime(1e-4, t);
		g.gain.exponentialRampToValueAtTime(gain, t + .01);
		g.gain.exponentialRampToValueAtTime(1e-4, t + dur);
		o.connect(g);
		g.connect(this.sfx);
		o.start(t);
		o.stop(t + dur + .02);
		o.onended = () => {
			o.disconnect();
			g.disconnect();
		};
	}
	noise(dur = .12, gain = .05) {
		if (!this.ctx || !this.sfx) return;
		const n = this.ctx.createBuffer(1, this.ctx.sampleRate * dur, this.ctx.sampleRate);
		const d = n.getChannelData(0);
		for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / d.length);
		const src = this.ctx.createBufferSource();
		src.buffer = n;
		const g = this.ctx.createGain();
		g.gain.value = gain;
		const f = this.ctx.createBiquadFilter();
		f.type = "highpass";
		f.frequency.value = 400;
		src.connect(f);
		f.connect(g);
		g.connect(this.sfx);
		src.start();
		src.onended = () => {
			src.disconnect();
			g.disconnect();
			f.disconnect();
		};
	}
	register() {
		this.beep(880, .07, "square", .07);
		setTimeout(() => this.beep(1320, .09, "square", .06), 70);
	}
	scan() {
		this.beep(1400, .04, "square", .05);
	}
	coin() {
		this.beep(980, .08, "triangle", .07);
		setTimeout(() => this.beep(1320, .12, "triangle", .06), 80);
	}
	error() {
		this.beep(220, .14, "sawtooth", .05);
	}
	chime() {
		this.beep(523, .1, "sine", .05);
		setTimeout(() => this.beep(659, .12, "sine", .045), 90);
	}
	step() {
		this.noise(.05, .03);
	}
	trash() {
		this.noise(.1, .06);
	}
	tickMusic(dt) {
		this.musicTimer += dt;
		if (this.musicTimer < 2.4) return;
		this.musicTimer = 0;
		if (!this.ctx || !this.music) return;
		const notes = [
			262,
			330,
			392,
			330,
			294,
			392,
			440,
			392
		];
		const n = notes[Math.floor(Math.random() * notes.length)] ?? 330;
		const t = this.ctx.currentTime;
		const o = this.ctx.createOscillator();
		const g = this.ctx.createGain();
		o.type = "sine";
		o.frequency.value = n / 2;
		g.gain.setValueAtTime(1e-4, t);
		g.gain.exponentialRampToValueAtTime(.035, t + .04);
		g.gain.exponentialRampToValueAtTime(1e-4, t + .9);
		o.connect(g);
		g.connect(this.music);
		o.start(t);
		o.stop(t + 1);
	}
	dispose() {
		try {
			this.hum?.stop();
			this.hum?.disconnect();
			this.ctx?.close();
		} catch {}
		this.ctx = null;
		this.hum = null;
	}
};
var GAME_CODES = /* @__PURE__ */ new Set([
	"KeyW",
	"KeyA",
	"KeyS",
	"KeyD",
	"ArrowUp",
	"ArrowLeft",
	"ArrowDown",
	"ArrowRight",
	"ShiftLeft",
	"ShiftRight",
	"KeyE",
	"Space",
	"KeyF"
]);
function radialDeadzone(x, y, dz = .15) {
	const m = Math.hypot(x, y);
	if (m < dz) return {
		x: 0,
		y: 0
	};
	const scale = (m - dz) / (1 - dz) / m;
	return {
		x: x * scale,
		y: y * scale
	};
}
var Input = class {
	keys = /* @__PURE__ */ new Set();
	injected = null;
	stick = {
		x: 0,
		y: 0
	};
	look = {
		x: 0,
		y: 0
	};
	sprintTouch = false;
	interactHeld = false;
	interactWas = false;
	lookAcc = {
		x: 0,
		y: 0
	};
	enabled = true;
	attach(el) {
		const onDown = (e) => {
			if (!this.enabled) return;
			this.keys.add(e.code);
			if (GAME_CODES.has(e.code)) e.preventDefault();
		};
		const onUp = (e) => {
			this.keys.delete(e.code);
		};
		const clear = () => this.keys.clear();
		const onMouse = (e) => {
			if (!this.enabled) return;
			if (e.buttons === 1 || document.pointerLockElement === el) {
				this.lookAcc.x += e.movementX;
				this.lookAcc.y += e.movementY;
			}
		};
		window.addEventListener("keydown", onDown);
		window.addEventListener("keyup", onUp);
		window.addEventListener("blur", clear);
		document.addEventListener("visibilitychange", () => {
			if (document.hidden) clear();
		});
		el.addEventListener("mousemove", onMouse);
		return () => {
			window.removeEventListener("keydown", onDown);
			window.removeEventListener("keyup", onUp);
			el.removeEventListener("mousemove", onMouse);
		};
	}
	setKeys(codes) {
		this.injected = codes;
	}
	consumeLook() {
		const v = {
			x: this.lookAcc.x + this.look.x * 14,
			y: this.lookAcc.y + this.look.y * 14
		};
		this.lookAcc.x = 0;
		this.lookAcc.y = 0;
		return v;
	}
	sample() {
		const held = this.injected ? new Set(this.injected) : this.keys;
		let mx = this.stick.x;
		let my = -this.stick.y;
		if (held.has("KeyD") || held.has("ArrowRight")) mx += 1;
		if (held.has("KeyA") || held.has("ArrowLeft")) mx -= 1;
		if (held.has("KeyW") || held.has("ArrowUp")) my += 1;
		if (held.has("KeyS") || held.has("ArrowDown")) my -= 1;
		try {
			const pad = (navigator.getGamepads?.() ?? []).find((p) => p && p.mapping === "standard");
			if (pad) {
				const st = radialDeadzone(pad.axes[0] ?? 0, pad.axes[1] ?? 0);
				mx += st.x;
				my -= st.y;
				const look = radialDeadzone(pad.axes[2] ?? 0, pad.axes[3] ?? 0, .12);
				this.lookAcc.x += look.x * 18;
				this.lookAcc.y += look.y * 12;
				if (pad.buttons[0]?.pressed) this.interactHeld = true;
				if (pad.buttons[1]?.pressed) this.sprintTouch = true;
			}
		} catch {}
		const mag = Math.hypot(mx, my);
		if (mag > 1) {
			mx /= mag;
			my /= mag;
		}
		const interact = this.interactHeld || held.has("KeyE") || held.has("Space") || held.has("KeyF");
		const interactDown = interact && !this.interactWas;
		this.interactWas = interact;
		return {
			moveX: mx,
			moveY: my,
			lookX: 0,
			lookY: 0,
			sprint: this.sprintTouch || held.has("ShiftLeft") || held.has("ShiftRight"),
			interact,
			interactDown
		};
	}
};
var OPEN_H = 8;
var CLOSE_H = 22;
var TIME_SCALE = 3.1;
var PLAYER_R = .38;
function dist(a, b) {
	return Math.hypot(a.x - b.x, a.z - b.z);
}
function clamp(v, a, b) {
	return Math.max(a, Math.min(b, v));
}
function pick(arr) {
	return arr[Math.floor(Math.random() * arr.length)];
}
function collideSlide(x, z, dx, dz, boxes, r) {
	const blocked = (px, pz) => {
		for (const b of boxes) {
			const cx = clamp(px, b.minX, b.maxX);
			const cz = clamp(pz, b.minZ, b.maxZ);
			const ox = px - cx;
			const oz = pz - cz;
			if (ox * ox + oz * oz < r * r) return true;
		}
		return false;
	};
	let nx = x + dx;
	let nz = z + dz;
	if (blocked(nx, z)) nx = x;
	if (blocked(nx, nz)) nz = z;
	if (blocked(nx, nz)) {
		nx = x;
		nz = z;
	}
	return {
		x: nx,
		z: nz
	};
}
function clockStr(h) {
	const hh = Math.floor(h) % 24;
	const mm = Math.floor((h - Math.floor(h)) * 60);
	const ap = hh >= 12 ? "PM" : "AM";
	return `${(hh + 11) % 12 + 1}:${mm.toString().padStart(2, "0")} ${ap}`;
}
var Sim = class {
	s;
	colliders = [];
	checkouts = [];
	pallets = [];
	customers = [];
	grid = null;
	entrance = {
		x: 0,
		z: 10
	};
	warehouseZone = {
		minX: -8,
		maxX: 8,
		minZ: -12,
		maxZ: -7
	};
	camYaw = Math.PI;
	camPitch = -.32;
	speed = 0;
	spawnT = 0;
	dirtT = 0;
	eventT = 80;
	stepT = 0;
	toast = null;
	report = null;
	prompt = "";
	interactTarget = null;
	lastInteract = 0;
	footT = 0;
	trauma = 0;
	layoutReady = false;
	w = 18;
	d = 24;
	constructor(state) {
		this.s = state;
	}
	bindLayout(opts) {
		this.colliders = opts.colliders;
		this.checkouts = opts.checkouts;
		this.pallets = opts.pallets;
		this.grid = opts.grid;
		this.entrance = opts.entrance;
		this.warehouseZone = opts.warehouseZone;
		this.w = opts.w;
		this.d = opts.d;
		const fresh = !this.s.shelves.length;
		if (fresh) this.s.shelves = opts.shelves;
		else for (let i = 0; i < opts.shelves.length; i++) {
			const n = opts.shelves[i];
			const o = this.s.shelves[i];
			if (o) {
				o.x = n.x;
				o.z = n.z;
				o.rot = n.rot;
				o.kind = n.kind;
				o.capacity = n.capacity;
				o.w = n.w;
				o.d = n.d;
			} else this.s.shelves.push(n);
		}
		if (!this.layoutReady) {
			if (fresh) {
				this.s.player.x = opts.spawn.x;
				this.s.player.z = opts.spawn.z;
				this.s.player.yaw = opts.spawn.yaw;
			}
			this.camYaw = this.s.player.yaw;
			this.layoutReady = true;
		}
		if (!this.s.missions.length) this.rollMissions();
	}
	notify(text) {
		this.toast = {
			text,
			life: 3.2
		};
	}
	inWarehouse(x, z) {
		const b = this.warehouseZone;
		return x > b.minX && x < b.maxX && z > b.minZ && z < b.maxZ;
	}
	nearestShelf(x, z, max = 2.1) {
		let best = null;
		let bd = max;
		for (const sh of this.s.shelves) {
			const d = Math.hypot(sh.x - x, sh.z - z);
			if (d < bd) {
				bd = d;
				best = sh;
			}
		}
		return best;
	}
	nearestCheckout(x, z, max = 2) {
		let best = null;
		let bd = max;
		for (const c of this.checkouts) {
			const d = Math.hypot(c.x - x, c.z - z);
			if (d < bd) {
				bd = d;
				best = c;
			}
		}
		return best;
	}
	pathTo(x, z, tx, tz) {
		if (!this.grid) return [{
			x: tx,
			z: tz
		}];
		return this.grid.find(x, z, tx, tz);
	}
	step(dt, input) {
		const s = this.s;
		this.trauma = Math.max(0, this.trauma - dt * 1.8);
		if (this.toast) {
			this.toast.life -= dt;
			if (this.toast.life <= 0) this.toast = null;
		}
		if (s.storeOpen) {
			s.timeOfDay += dt * (TIME_SCALE / 60);
			if (s.timeOfDay >= CLOSE_H) this.closeDay();
		}
		this.updatePlayer(dt, input);
		this.updateOrders(dt);
		this.updateCustomers(dt);
		this.updateStaff(dt);
		this.updateWorld(dt);
		this.updateEvents(dt);
		this.updateMissions();
		this.refreshPrompt();
	}
	updatePlayer(dt, input) {
		const p = this.s.player;
		const fy = -Math.sin(this.camYaw);
		const fz = -Math.cos(this.camYaw);
		const rx = Math.cos(this.camYaw);
		const rz = -Math.sin(this.camYaw);
		const sprint = input.sprint && (Math.abs(input.moveX) > .1 || Math.abs(input.moveY) > .1);
		const max = sprint ? 6.1 : 3.55;
		const vx = (fy * input.moveY + rx * input.moveX) * max;
		const vz = (fz * input.moveY + rz * input.moveX) * max;
		this.speed = Math.hypot(vx, vz);
		if (this.speed > .12) {
			const next = collideSlide(p.x, p.z, vx * dt, vz * dt, this.colliders, PLAYER_R);
			p.x = next.x;
			p.z = next.z;
			p.yaw = Math.atan2(-vx, -vz);
			this.footT += dt * (sprint ? 5.5 : 3.6);
		}
		const { w, d } = storeFootprint(this.s.storeLevel);
		p.x = clamp(p.x, -w / 2 + .6, w / 2 - .6);
		p.z = clamp(p.z, -d / 2 + .6, d / 2 + 1.4);
		if (input.interactDown) this.tryInteract();
	}
	tryInteract() {
		const p = this.s.player;
		const t = this.interactTarget;
		if (!t) {
			this.notify("Nothing to use here.");
			return;
		}
		if (t.kind === "shelf") {
			const sh = this.s.shelves.find((x) => x.id === t.id);
			if (!sh) return;
			if (sh.broken) {
				if (this.s.money >= 80) {
					this.s.money -= 80;
					this.s.daily.expenses += 80;
					sh.broken = false;
					this.notify("Refrigerator repaired.");
				} else this.notify("Need $80 to repair.");
				return;
			}
			if (p.holding) {
				if (sh.productId && sh.productId !== p.holding.productId) {
					this.notify(`This bay is for ${PRODUCT_MAP[sh.productId].name}.`);
					return;
				}
				if (!sh.productId) sh.productId = p.holding.productId;
				const room = sh.capacity - sh.stock;
				const n = Math.min(room, p.holding.qty);
				if (n <= 0) {
					this.notify("Shelf is full.");
					return;
				}
				sh.stock += n;
				p.holding.qty -= n;
				if (p.holding.qty <= 0) p.holding = null;
				if (this.s.tutorial === 2) this.s.tutorial = 3;
				this.notify(`Stocked ${n} ${PRODUCT_MAP[sh.productId].name}.`);
				return;
			}
			if (sh.dirty > .4) {
				sh.dirty = 0;
				this.s.cleanliness = clamp(this.s.cleanliness + .04, 0, 1);
				this.notify("Shelf wiped down.");
				return;
			}
			this.notify(sh.stock ? `${PRODUCT_MAP[sh.productId ?? "bread"].name}: ${sh.stock} left` : "Empty bay.");
			return;
		}
		if (t.kind === "pallet") {
			if (p.holding) {
				this.s.warehouse[p.holding.productId] += p.holding.qty;
				this.notify("Crate returned to warehouse.");
				p.holding = null;
				return;
			}
			const ids = Object.keys(this.s.warehouse).filter((id) => this.s.warehouse[id] > 0 && this.s.unlocked[id]);
			if (!ids.length) {
				this.notify("Warehouse is empty. Place an order.");
				return;
			}
			const low = this.s.shelves.find((sh) => sh.productId && sh.stock < sh.capacity * .45);
			const pickId = low?.productId && this.s.warehouse[low.productId] > 0 ? low.productId : ids[0];
			const qty = Math.min(8, this.s.warehouse[pickId]);
			this.s.warehouse[pickId] -= qty;
			p.holding = {
				productId: pickId,
				qty
			};
			if (this.s.tutorial === 1) this.s.tutorial = 2;
			this.notify(`Picked ${qty} ${PRODUCT_MAP[pickId].name}.`);
			return;
		}
		if (t.kind === "checkout") {
			this.serveCheckout(t.id);
			return;
		}
		if (t.kind === "dirt") {
			this.s.cleanliness = clamp(this.s.cleanliness + .08, 0, 1);
			this.notify("Floor cleaned.");
		}
		if (t.kind === "thief") {
			const c = this.customers.find((x) => x.id === Number(t.id));
			if (c) {
				c.state = "flee";
				c.path = this.pathTo(c.x, c.z, this.entrance.x, this.entrance.z + 2);
				this.notify("Shoplifter stopped.");
				this.s.rating = clamp(this.s.rating + .05, 1, 5);
			}
		}
	}
	serveCheckout(laneId) {
		const c = this.customers.find((x) => x.state === "queue" && x.lane === laneId);
		if (!c) {
			this.notify("No one in this lane.");
			return;
		}
		if (!c.cart.length) {
			c.state = "leave";
			c.path = this.pathTo(c.x, c.z, this.entrance.x, this.entrance.z + 2);
			return;
		}
		const item = c.cart.shift();
		this.ringSale(c, item.productId, item.qty, item.price);
		if (!c.cart.length) this.finishSale(c);
		else this.notify(`Scanned ${PRODUCT_MAP[item.productId].name}.`);
		if (this.s.tutorial === 3) this.s.tutorial = 4;
	}
	ringSale(c, id, qty, price) {
		const total = price * qty;
		this.s.money += total;
		this.s.daily.revenue += total;
		this.s.daily.sold += qty;
		this.s.soldToday[id] += qty;
		this.s.xp += qty;
	}
	finishSale(c) {
		c.state = "leave";
		c.path = this.pathTo(c.x, c.z, this.entrance.x, this.entrance.z + 2);
		this.s.daily.served += 1;
		const waitPenalty = c.wait > 25 ? .15 : c.wait > 12 ? .05 : 0;
		c.satisfaction = clamp(c.satisfaction - waitPenalty, 0, 1);
		this.s.rating = clamp(this.s.rating * .97 + (1 + c.satisfaction * 4) * .03, 1, 5);
		this.notify("Receipt printed. Thanks for shopping.");
		this.trauma = Math.min(1, this.trauma + .12);
	}
	updateOrders(dt) {
		const speed = 1 + this.s.staff.filter((e) => e.role === "delivery").length * .35;
		for (const o of this.s.orders) {
			if (o.delayed && this.s.event?.kind === "delay") continue;
			o.eta -= dt * speed;
		}
		const done = this.s.orders.filter((o) => o.eta <= 0);
		this.s.orders = this.s.orders.filter((o) => o.eta > 0);
		for (const o of done) {
			const room = this.s.warehouseCap - this.warehouseUsed();
			const qty = Math.min(o.qty, Math.max(0, room));
			this.s.warehouse[o.productId] += qty;
			this.notify(`Delivery: ${qty} ${PRODUCT_MAP[o.productId].name}.`);
			if (this.s.tutorial === 0) this.s.tutorial = 1;
		}
	}
	warehouseUsed() {
		let n = 0;
		for (const id of PRODUCTS.map((p) => p.id)) n += this.s.warehouse[id];
		return n;
	}
	peakMul() {
		const h = this.s.timeOfDay;
		if (h >= 12 && h <= 13.5) return 1.55;
		if (h >= 17 && h <= 19.5) return 1.7;
		if (h < 9 || h > 20.5) return .45;
		return 1;
	}
	updateCustomers(dt) {
		const s = this.s;
		if (s.storeOpen) {
			const loc = LOCATION_MAP[s.location];
			const cap = 4 + s.storeLevel * 3 + Math.floor(s.rating);
			const festival = s.event?.kind === "festival" ? 1.5 : 1;
			const rate = (.22 + loc.traffic * .18) * this.peakMul() * festival * (s.rating / 3.5);
			this.spawnT += dt * rate;
			if (this.spawnT > 1 && this.customers.length < cap) {
				this.spawnT = 0;
				this.spawnCustomer();
			}
		}
		for (const c of this.customers) {
			c.anim += dt * (c.speed * 3.2);
			if (c.state === "pay") continue;
			if (c.state === "queue") {
				c.wait += dt;
				c.patience -= dt * (c.kind === "impatient" ? 1.6 : 1);
				if (c.patience <= 0) {
					c.state = "leave";
					c.satisfaction = .15;
					s.daily.lost += 1;
					s.rating = clamp(s.rating - .08, 1, 5);
					c.path = this.pathTo(c.x, c.z, this.entrance.x, this.entrance.z + 2);
					this.notify("A customer left the queue.");
				}
			}
			this.steer(c, dt);
			this.thinkCustomer(c, dt);
		}
		this.customers = this.customers.filter((c) => {
			if (c.state === "leave" && dist(c, this.entrance) < 1.4 && c.z > this.entrance.z - .2) return false;
			if (c.state === "flee" && dist(c, this.entrance) < 1.6) return false;
			return true;
		});
	}
	spawnCustomer() {
		const loc = this.s.location;
		const weights = [
			["budget", loc === "town" ? 3 : 1.4],
			["regular", 2.2],
			["rich", loc === "downtown" || loc === "business" ? 2.2 : .6],
			["impatient", loc === "downtown" || loc === "business" ? 2 : .8],
			["elderly", loc === "town" ? 1.8 : .7],
			["child", loc === "beach" ? 1.6 : .7]
		];
		const sum = weights.reduce((a, [, w]) => a + w, 0);
		let r = Math.random() * sum;
		let kind = "regular";
		for (const [k, w] of weights) {
			r -= w;
			if (r <= 0) {
				kind = k;
				break;
			}
		}
		const meta = CUSTOMER_META[kind];
		const unlocked = PRODUCTS.filter((p) => this.s.unlocked[p.id]);
		const n = kind === "child" ? 1 + (Math.random() < .4 ? 1 : 0) : kind === "rich" ? 4 + (Math.random() * 4 | 0) : 2 + (Math.random() * 4 | 0);
		const list = [];
		const prefer = loc === "beach" ? unlocked.filter((p) => p.id === "drinks" || p.category === "snacks") : unlocked;
		const pool = prefer.length ? prefer : unlocked;
		for (let i = 0; i < n; i++) {
			const p = pick(pool);
			if (list.some((l) => l.productId === p.id)) continue;
			if (kind === "budget" && p.sellPrice * this.s.sellMul[p.id] > p.buyPrice * 2.4) continue;
			const demand = p.demand * (this.s.demandMul[p.id] ?? 1);
			if (Math.random() > .35 + demand * .4) continue;
			list.push({
				productId: p.id,
				qty: 1 + (Math.random() * (kind === "rich" ? 3 : 2) | 0),
				got: 0
			});
		}
		if (!list.length && pool.length) {
			const p = pick(pool);
			list.push({
				productId: p.id,
				qty: 1,
				got: 0
			});
		}
		const c = {
			id: this.s.nextCustomer++,
			kind,
			x: this.entrance.x + (Math.random() - .5) * 1.2,
			z: this.entrance.z + 1.2,
			yaw: Math.PI,
			state: "enter",
			list,
			cart: [],
			target: null,
			path: this.pathTo(this.entrance.x, this.entrance.z + 1, 0, 0),
			wait: 0,
			patience: meta.patience * (.85 + Math.random() * .3),
			satisfaction: .7,
			speed: meta.speed * (this.s.event?.kind === "weather" ? .82 : 1),
			payMethod: kind === "rich" || Math.random() > .4 ? "card" : "cash",
			lane: null,
			anim: Math.random() * 10,
			shoplift: this.s.event?.kind === "shoplifter" && Math.random() < .35,
			color: meta.color,
			scale: meta.scale
		};
		if (this.s.event?.kind === "fire") c.state = "flee";
		this.customers.push(c);
	}
	thinkCustomer(c, dt) {
		if (c.state === "enter" && c.path.length <= 1) c.state = "seek";
		if (c.state === "flee") {
			if (!c.path.length) c.path = this.pathTo(c.x, c.z, this.entrance.x, this.entrance.z + 2);
			return;
		}
		if (c.state === "seek") {
			const need = c.list.find((l) => l.got < l.qty);
			if (!need) {
				this.sendToQueue(c);
				return;
			}
			const sh = this.findShelfFor(need.productId);
			if (!sh) {
				const alt = this.altBrand(need.productId);
				if (alt) {
					need.productId = alt;
					c.satisfaction -= .05;
					return;
				}
				need.got = need.qty;
				c.satisfaction -= .18;
				return;
			}
			const stand = this.standPoint(sh);
			if (dist(c, stand) < .85) {
				c.state = "take";
				c.wait = .55;
				c.target = {
					x: sh.x,
					z: sh.z
				};
				return;
			}
			if (c.path.length <= 1) c.path = this.pathTo(c.x, c.z, stand.x, stand.z);
		}
		if (c.state === "take") {
			c.wait -= dt;
			if (c.wait > 0) return;
			const need = c.list.find((l) => l.got < l.qty);
			if (!need) {
				c.state = "seek";
				return;
			}
			const sh = this.s.shelves.find((x) => x.productId === need.productId && x.stock > 0 && !x.broken);
			if (sh) {
				const take = Math.min(need.qty - need.got, sh.stock, 2);
				sh.stock -= take;
				need.got += take;
				const price = PRODUCT_MAP[need.productId].sellPrice * this.s.sellMul[need.productId];
				const existing = c.cart.find((i) => i.productId === need.productId);
				if (existing) existing.qty += take;
				else c.cart.push({
					productId: need.productId,
					qty: take,
					price
				});
				if (c.shoplift && Math.random() < .5) {
					c.state = "flee";
					c.path = this.pathTo(c.x, c.z, this.entrance.x, this.entrance.z + 2);
					this.notify("Someone is stealing!");
					this.s.daily.lost += 1;
					return;
				}
			} else {
				const alt = this.altBrand(need.productId);
				if (alt) need.productId = alt;
				else {
					need.got = need.qty;
					c.satisfaction -= .2;
				}
			}
			c.state = "seek";
		}
		if (c.state === "queue") {
			const lane = this.checkouts.find((l) => l.id === c.lane) ?? this.checkouts[0];
			if (!lane) return;
			const idx = this.customers.filter((x) => x.state === "queue" && x.lane === lane.id).sort((a, b) => a.id - b.id).indexOf(c);
			const slot = lane.queue[Math.min(idx, lane.queue.length - 1)] ?? {
				x: lane.x,
				z: lane.z - 1
			};
			if (dist(c, slot) > .35 && c.path.length <= 1) c.path = this.pathTo(c.x, c.z, slot.x, slot.z);
		}
	}
	sendToQueue(c) {
		let best = this.checkouts[0];
		let bestN = 999;
		for (const lane of this.checkouts) {
			const n = this.customers.filter((x) => x.lane === lane.id && (x.state === "queue" || x.state === "pay")).length;
			if (n < bestN) {
				bestN = n;
				best = lane;
			}
		}
		if (!best) {
			c.state = "leave";
			c.path = this.pathTo(c.x, c.z, this.entrance.x, this.entrance.z + 2);
			return;
		}
		c.lane = best.id;
		c.state = "queue";
		const slot = best.queue[Math.min(bestN, best.queue.length - 1)] ?? {
			x: best.x,
			z: best.z - 1
		};
		c.path = this.pathTo(c.x, c.z, slot.x, slot.z);
	}
	findShelfFor(id) {
		return this.s.shelves.find((s) => s.productId === id && s.stock > 0 && !s.broken);
	}
	altBrand(id) {
		const cat = PRODUCT_MAP[id].category;
		return this.s.shelves.find((s) => s.productId && PRODUCT_MAP[s.productId].category === cat && s.stock > 0 && s.productId !== id)?.productId ?? null;
	}
	standPoint(sh) {
		const dx = this.s.player.x - sh.x;
		const face = Math.abs(dx) > .2 ? Math.sign(dx) : 1;
		return {
			x: sh.x + face * .95,
			z: sh.z
		};
	}
	steer(c, dt) {
		if (!c.path.length) return;
		const t = c.path[0];
		const dx = t.x - c.x;
		const dz = t.z - c.z;
		const d = Math.hypot(dx, dz);
		if (d < .28) {
			c.path.shift();
			return;
		}
		const sp = c.speed;
		const nx = dx / d * sp * dt;
		const nz = dz / d * sp * dt;
		const next = collideSlide(c.x, c.z, nx, nz, this.colliders, .3);
		c.x = next.x;
		c.z = next.z;
		c.yaw = Math.atan2(-dx, -dz);
	}
	updateStaff(dt) {
		const cashiers = this.s.staff.filter((e) => e.role === "cashier");
		if (cashiers.length) for (const lane of this.checkouts) {
			const first = this.customers.filter((c) => c.state === "queue" && c.lane === lane.id).sort((a, b) => a.id - b.id)[0];
			if (!first || !first.cart.length) continue;
			first.wait += dt;
			const skill = .9 + cashiers[0].level * .25;
			if (first.wait > 1.1 / skill) {
				first.wait = 0;
				const item = first.cart.shift();
				this.ringSale(first, item.productId, item.qty, item.price);
				if (!first.cart.length) this.finishSale(first);
			}
		}
		for (const e of this.s.staff) {
			e.anim += dt * 4;
			e.speed = 1.7 + e.level * .15;
			if (e.role === "stocker") this.runStocker(e, dt);
			else if (e.role === "cleaner") this.runCleaner(e, dt);
			else if (e.role === "security") this.runSecurity(e, dt);
			else if (e.role === "cashier") {
				const lane = this.checkouts[0];
				if (lane) {
					e.target = {
						x: lane.x + .9,
						z: lane.z + .2
					};
					e.path = this.pathTo(e.x, e.z, e.target.x, e.target.z);
				}
			} else if (e.role === "manager") {
				if (!e.path.length) {
					const sh = pick(this.s.shelves);
					e.path = this.pathTo(e.x, e.z, sh.x + 1, sh.z);
				}
			} else if (e.role === "delivery") {
				if (!e.path.length) e.path = this.pathTo(e.x, e.z, this.warehouseZone.minX + 2, (this.warehouseZone.minZ + this.warehouseZone.maxZ) / 2);
			}
			this.steer(e, dt);
		}
	}
	runStocker(e, _dt) {
		if (e.holding) {
			const sh = this.s.shelves.find((s) => (s.productId === e.holding.productId || !s.productId) && s.stock < s.capacity && !s.broken);
			if (!sh) {
				this.s.warehouse[e.holding.productId] += e.holding.qty;
				e.holding = null;
				return;
			}
			const stand = this.standPoint(sh);
			if (dist(e, stand) < .9) {
				if (!sh.productId) sh.productId = e.holding.productId;
				if (sh.productId === e.holding.productId) {
					const n = Math.min(sh.capacity - sh.stock, e.holding.qty);
					sh.stock += n;
					e.holding.qty -= n;
					if (e.holding.qty <= 0) e.holding = null;
				}
				return;
			}
			if (e.path.length <= 1) e.path = this.pathTo(e.x, e.z, stand.x, stand.z);
			return;
		}
		const low = this.s.shelves.find((s) => s.productId && s.stock < s.capacity * .5 && this.s.warehouse[s.productId] > 0);
		if (!low?.productId) return;
		if (!this.inWarehouse(e.x, e.z)) {
			if (e.path.length <= 1) e.path = this.pathTo(e.x, e.z, (this.warehouseZone.minX + this.warehouseZone.maxX) / 2, (this.warehouseZone.minZ + this.warehouseZone.maxZ) / 2);
			return;
		}
		const qty = Math.min(8, this.s.warehouse[low.productId]);
		this.s.warehouse[low.productId] -= qty;
		e.holding = {
			productId: low.productId,
			qty
		};
	}
	runCleaner(e, dt) {
		const dirty = this.s.shelves.find((s) => s.dirty > .35);
		if (dirty) {
			if (dist(e, dirty) < 1.1) {
				dirty.dirty = Math.max(0, dirty.dirty - dt * .4);
				this.s.cleanliness = clamp(this.s.cleanliness + dt * .03, 0, 1);
				return;
			}
			if (e.path.length <= 1) e.path = this.pathTo(e.x, e.z, dirty.x + .9, dirty.z);
			return;
		}
		this.s.cleanliness = clamp(this.s.cleanliness + dt * .01, 0, 1);
		if (e.path.length <= 1) {
			const sh = pick(this.s.shelves);
			e.path = this.pathTo(e.x, e.z, sh.x + 1, sh.z);
		}
	}
	runSecurity(e, _dt) {
		const thief = this.customers.find((c) => c.shoplift && c.state === "flee");
		if (thief) {
			if (dist(e, thief) < .9) {
				thief.shoplift = false;
				thief.state = "queue";
				this.sendToQueue(thief);
				this.notify("Guard caught a thief.");
				return;
			}
			if (e.path.length <= 1) e.path = this.pathTo(e.x, e.z, thief.x, thief.z);
			return;
		}
		if (e.path.length <= 1) e.path = this.pathTo(e.x, e.z, (Math.random() - .5) * 8, (Math.random() - .5) * 8);
	}
	updateWorld(dt) {
		this.dirtT += dt;
		if (this.dirtT > 8) {
			this.dirtT = 0;
			this.s.cleanliness = clamp(this.s.cleanliness - .012 * this.customers.length * .04, .15, 1);
			const sh = this.s.shelves[Math.floor(Math.random() * this.s.shelves.length)];
			if (sh) sh.dirty = clamp(sh.dirty + .08, 0, 1);
		}
		if (this.s.event?.kind === "outage") this.s.cleanliness = clamp(this.s.cleanliness - dt * .01, .1, 1);
	}
	updateEvents(dt) {
		if (this.s.event) {
			this.s.event.t += dt;
			if (this.s.event.t >= this.s.event.dur) {
				this.notify(`${this.s.event.label} ended.`);
				this.s.event = null;
				for (const id of PRODUCTS.map((p) => p.id)) this.s.demandMul[id] = 1;
			}
			return;
		}
		if (!this.s.storeOpen) return;
		this.eventT -= dt;
		if (this.eventT > 0) return;
		this.eventT = 70 + Math.random() * 80;
		if (Math.random() > .55) return;
		const kind = pick([
			"demand",
			"delay",
			"weather",
			"festival",
			"outage",
			"fridge",
			"shoplifter",
			"fire"
		]);
		this.triggerEvent(kind);
	}
	triggerEvent(kind) {
		const meta = {
			fire: {
				label: "Fire alarm",
				dur: 18
			},
			outage: {
				label: "Power outage",
				dur: 22
			},
			delay: {
				label: "Delivery delay",
				dur: 30
			},
			demand: {
				label: "Demand spike",
				dur: 40
			},
			shoplifter: {
				label: "Shoplifter reported",
				dur: 28
			},
			weather: {
				label: "Bad weather",
				dur: 36
			},
			festival: {
				label: "Festival sale",
				dur: 50
			},
			fridge: {
				label: "Fridge breakdown",
				dur: 1
			}
		}[kind];
		this.s.event = {
			kind,
			t: 0,
			dur: meta.dur,
			label: meta.label
		};
		this.notify(meta.label);
		this.trauma = Math.min(1, this.trauma + .35);
		if (kind === "demand") {
			const p = pick(PRODUCTS.filter((x) => this.s.unlocked[x.id]));
			this.s.demandMul[p.id] = 2.2;
		}
		if (kind === "festival") for (const id of PRODUCTS.map((x) => x.id)) this.s.demandMul[id] = 1.4;
		if (kind === "fridge") {
			const fr = this.s.shelves.find((s) => s.kind === "fridge");
			if (fr) fr.broken = true;
			this.s.event = null;
			this.notify("A refrigerator broke down.");
		}
		if (kind === "fire") {
			for (const c of this.customers) {
				c.state = "flee";
				c.path = this.pathTo(c.x, c.z, this.entrance.x, this.entrance.z + 2);
			}
			this.s.storeOpen = false;
		}
		if (kind === "delay") for (const o of this.s.orders) o.delayed = true;
	}
	updateMissions() {
		for (const m of this.s.missions) {
			if (m.done) continue;
			if (m.kind === "sell") m.progress = this.s.daily.sold;
			if (m.kind === "earn") m.progress = Math.floor(this.s.daily.revenue);
			if (m.kind === "serve") m.progress = this.s.daily.served;
			if (m.kind === "rating") m.progress = +this.s.rating.toFixed(2);
			if (m.kind === "product" && m.productId) m.progress = this.s.soldToday[m.productId];
			if (m.kind === "rating" ? m.progress >= m.target : m.progress >= m.target) m.done = true;
		}
	}
	claimMission(id) {
		const m = this.s.missions.find((x) => x.id === id);
		if (!m || !m.done || m.claimed) return;
		m.claimed = true;
		this.s.money += m.rewardMoney;
		this.s.xp += m.rewardXp;
		this.notify(`Mission complete. +$${m.rewardMoney}`);
		this.unlockByXp();
	}
	unlockByXp() {
		for (const p of PRODUCTS) if (!this.s.unlocked[p.id] && (this.s.storeLevel >= p.unlockLevel || this.s.xp > p.unlockLevel * 80)) {
			this.s.unlocked[p.id] = true;
			this.notify(`Unlocked ${p.name}.`);
		}
	}
	rollMissions() {
		const p = pick(PRODUCTS.filter((p) => this.s.unlocked[p.id]));
		this.s.missions = [
			{
				id: "m1",
				title: "Move units",
				detail: "Sell 40 products today",
				kind: "sell",
				target: 40,
				progress: 0,
				rewardMoney: 220,
				rewardXp: 40,
				done: false,
				claimed: false
			},
			{
				id: "m2",
				title: "Till goal",
				detail: "Earn $1,200 revenue",
				kind: "earn",
				target: 1200,
				progress: 0,
				rewardMoney: 300,
				rewardXp: 50,
				done: false,
				claimed: false
			},
			{
				id: "m3",
				title: `Push ${p.name}`,
				detail: `Sell 16 ${p.name}`,
				kind: "product",
				productId: p.id,
				target: 16,
				progress: 0,
				rewardMoney: 180,
				rewardXp: 35,
				done: false,
				claimed: false
			}
		];
	}
	refreshPrompt() {
		const p = this.s.player;
		this.interactTarget = null;
		this.prompt = "";
		const thief = this.customers.find((c) => c.shoplift && dist(c, p) < 1.6);
		if (thief) {
			this.interactTarget = {
				kind: "thief",
				id: String(thief.id)
			};
			this.prompt = "Stop shoplifter";
			return;
		}
		const co = this.nearestCheckout(p.x, p.z, 1.8);
		if (co) {
			const q = this.customers.filter((c) => c.state === "queue" && c.lane === co.id).length;
			this.interactTarget = {
				kind: "checkout",
				id: co.id
			};
			this.prompt = q ? `Checkout · ${q} waiting` : "Checkout lane";
			return;
		}
		const sh = this.nearestShelf(p.x, p.z, 1.7);
		if (sh) {
			this.interactTarget = {
				kind: "shelf",
				id: sh.id
			};
			const name = sh.productId ? PRODUCT_MAP[sh.productId].name : "Empty bay";
			if (p.holding) this.prompt = `Stock ${PRODUCT_MAP[p.holding.productId].name}`;
			else if (sh.broken) this.prompt = "Repair refrigerator · $80";
			else this.prompt = `${name} · ${sh.stock}/${sh.capacity}`;
			return;
		}
		if (this.inWarehouse(p.x, p.z)) {
			this.interactTarget = {
				kind: "pallet",
				id: "wh"
			};
			this.prompt = p.holding ? "Return crate" : "Pick up crate";
			return;
		}
		if (this.s.cleanliness < .55) {
			this.interactTarget = {
				kind: "dirt",
				id: "floor"
			};
			this.prompt = "Clean floor";
		}
	}
	toggleOpen() {
		if (this.s.storeOpen) {
			this.s.storeOpen = false;
			this.notify("Store closed. Customers will finish and leave.");
			return;
		}
		this.s.storeOpen = true;
		if (this.s.timeOfDay < OPEN_H || this.s.timeOfDay >= CLOSE_H) this.s.timeOfDay = OPEN_H;
		this.notify("Doors are open.");
	}
	closeDay() {
		this.s.storeOpen = false;
		this.s.timeOfDay = CLOSE_H;
		const rent = LOCATION_MAP[this.s.location].rent * this.s.storeLevel;
		const power = 28 + this.s.storeLevel * 18 + this.s.shelves.filter((s) => s.kind === "fridge" || s.kind === "freezer").length * 6;
		const wages = this.s.staff.reduce((a, e) => a + ROLE_META[e.role].salary + (e.level - 1) * 12, 0);
		const expenses = rent + power + wages;
		this.s.money -= expenses;
		this.s.daily.expenses += expenses;
		const profit = this.s.daily.revenue - this.s.daily.expenses;
		this.report = {
			day: this.s.day,
			revenue: this.s.daily.revenue,
			expenses: this.s.daily.expenses,
			profit,
			sold: this.s.daily.sold,
			served: this.s.daily.served,
			lost: this.s.daily.lost,
			rating: this.s.rating,
			rent,
			power,
			wages
		};
		const mgr = this.s.staff.some((e) => e.role === "manager");
		this.s.rating = clamp(this.s.rating + (mgr ? .05 : 0) + (this.s.cleanliness - .5) * .1, 1, 5);
	}
	nextDay() {
		this.s.day += 1;
		this.s.timeOfDay = OPEN_H;
		this.s.daily = {
			revenue: 0,
			expenses: 0,
			sold: 0,
			served: 0,
			lost: 0
		};
		for (const id of PRODUCTS.map((p) => p.id)) this.s.soldToday[id] = 0;
		this.customers = [];
		this.s.event = null;
		this.report = null;
		this.rollMissions();
		this.unlockByXp();
		this.notify(`Day ${this.s.day} · ${LOCATION_MAP[this.s.location].name}`);
	}
	placeOrder(productId, qty, supplierId) {
		const p = PRODUCT_MAP[productId];
		const sup = SUPPLIERS.find((x) => x.id === supplierId) ?? SUPPLIERS[1];
		if (!this.s.unlocked[productId]) return "Product is locked.";
		if (qty < 1) return "Choose a quantity.";
		const mul = sup.specialty === "all" || sup.specialty === p.category || sup.specialty === "frozen" && p.shelf === "freezer" ? sup.priceMul : sup.priceMul * 1.12;
		const bulk = qty >= 40 ? sup.bulk : 1;
		const cost = +(p.buyPrice * qty * mul * bulk).toFixed(2);
		if (cost > this.s.money) return "Not enough cash.";
		if (this.warehouseUsed() + qty > this.s.warehouseCap) return "Warehouse is full.";
		this.s.money -= cost;
		this.s.daily.expenses += cost;
		const eta = sup.delayMin * (.7 + Math.random() * .5);
		this.s.orders.push({
			id: this.s.nextOrder++,
			productId,
			qty,
			supplierId: sup.id,
			cost,
			eta,
			delayed: false
		});
		this.notify(`Ordered ${qty} ${p.name} from ${sup.name}.`);
		return "";
	}
	hire(role) {
		const meta = ROLE_META[role];
		if (this.s.money < meta.hire) return "Not enough cash.";
		if (this.s.staff.filter((e) => e.role === role).length >= (role === "cashier" ? this.s.checkouts : 2)) return "No more slots for that role.";
		this.s.money -= meta.hire;
		this.s.daily.expenses += meta.hire;
		const name = pick(STAFF_NAMES.filter((n) => !this.s.staff.some((e) => e.name === n))) || pick(STAFF_NAMES);
		this.s.staff.push({
			id: this.s.nextStaff++,
			role,
			name,
			level: 1,
			x: this.s.player.x,
			z: this.s.player.z,
			yaw: 0,
			target: null,
			path: [],
			wait: 0,
			holding: null,
			anim: 0,
			speed: 1.7
		});
		this.notify(`Hired ${name} · ${meta.label}`);
		return "";
	}
	fire(id) {
		this.s.staff = this.s.staff.filter((e) => e.id !== id);
		this.notify("Employee released.");
	}
	train(id) {
		const e = this.s.staff.find((x) => x.id === id);
		if (!e) return "Missing staff.";
		const cost = 180 * e.level;
		if (this.s.money < cost) return "Not enough cash.";
		if (e.level >= 5) return "Already max level.";
		this.s.money -= cost;
		e.level += 1;
		this.notify(`${e.name} trained to Lv.${e.level}`);
		return "";
	}
	upgradeStore() {
		if (this.s.storeLevel >= 4) return "Already a hypermarket.";
		const cost = UPGRADE_COST[this.s.storeLevel] ?? 99999;
		if (this.s.money < cost) return `Need $${cost.toLocaleString()}.`;
		this.s.money -= cost;
		this.s.storeLevel += 1;
		this.s.checkouts = Math.min(4, this.s.storeLevel);
		this.s.warehouseCap += 80;
		for (const p of PRODUCTS) if (p.unlockLevel <= this.s.storeLevel) this.s.unlocked[p.id] = true;
		this.notify(`Upgraded to ${STORE_LABELS[this.s.storeLevel - 1]}.`);
		return "rebuild";
	}
	buyCheckout() {
		if (this.s.checkouts >= Math.min(4, this.s.storeLevel + 1)) return "No more lanes at this size.";
		if (this.s.money < 2500) return "Need $2,500.";
		this.s.money -= 2500;
		this.s.checkouts += 1;
		this.notify("New checkout installed.");
		return "rebuild";
	}
	buyLights() {
		if (this.s.lights >= 3) return "Lighting is maxed.";
		if (this.s.money < 1200) return "Need $1,200.";
		this.s.money -= 1200;
		this.s.lights += 1;
		this.s.rating = clamp(this.s.rating + .08, 1, 5);
		this.notify("Lighting improved.");
		return "";
	}
	buyDecor() {
		if (this.s.decor >= 3) return "Decor is maxed.";
		if (this.s.money < 1600) return "Need $1,600.";
		this.s.money -= 1600;
		this.s.decor += 1;
		this.s.rating = clamp(this.s.rating + .1, 1, 5);
		this.notify("Store dressed up.");
		return "";
	}
	expandWarehouse() {
		if (this.s.warehouseCap >= 600) return "Warehouse is maxed.";
		if (this.s.money < 2800) return "Need $2,800.";
		this.s.money -= 2800;
		this.s.warehouseCap += 120;
		this.notify("Warehouse expanded.");
		return "";
	}
	setLocation(id) {
		const loc = LOCATION_MAP[id];
		if (this.s.storeLevel < loc.unlockLevel) return `Requires ${STORE_LABELS[loc.unlockLevel - 1]}.`;
		if (this.s.location === id) return "Already here.";
		this.s.location = id;
		this.notify(`Relocated to ${loc.name}.`);
		return "";
	}
	setPrice(id, mul) {
		this.s.sellMul[id] = clamp(mul, .7, 1.8);
	}
	hud() {
		const hold = this.s.player.holding;
		const tut = this.s.tutorial === 0 ? "Order stock from the Orders panel, then open the doors." : this.s.tutorial === 1 ? "Walk to the warehouse (back of the store) and pick up a crate." : this.s.tutorial === 2 ? "Carry the crate to a matching shelf and stock it." : this.s.tutorial === 3 ? "Open the store and serve a customer at checkout (E)." : null;
		return {
			money: this.s.money,
			rating: this.s.rating,
			day: this.s.day,
			clock: clockStr(this.s.timeOfDay),
			open: this.s.storeOpen,
			prompt: this.prompt,
			holding: hold ? {
				...hold,
				name: PRODUCT_MAP[hold.productId].name
			} : null,
			cleanliness: this.s.cleanliness,
			customers: this.customers.length,
			queue: this.customers.filter((c) => c.state === "queue").length,
			event: this.s.event?.label ?? null,
			tutorial: this.s.seenHelp ? null : tut,
			interact: !!this.interactTarget,
			speed: this.speed,
			yaw: this.s.player.yaw,
			px: this.s.player.x,
			pz: this.s.player.z,
			storeLevel: this.s.storeLevel,
			location: this.s.location,
			xp: this.s.xp
		};
	}
};
function canvasTex(size, draw, repeat = 1) {
	const c = document.createElement("canvas");
	c.width = size;
	c.height = size;
	const ctx = c.getContext("2d");
	if (!ctx) return new CanvasTexture(c);
	draw(ctx, size);
	const t = new CanvasTexture(c);
	t.wrapS = t.wrapT = RepeatWrapping;
	t.repeat.set(repeat, repeat);
	t.colorSpace = SRGBColorSpace;
	t.anisotropy = 4;
	t.needsUpdate = true;
	return t;
}
function floorTex() {
	return canvasTex(256, (ctx, s) => {
		ctx.fillStyle = "#c9c2b4";
		ctx.fillRect(0, 0, s, s);
		const tile = s / 4;
		for (let y = 0; y < 4; y++) for (let x = 0; x < 4; x++) {
			const n = (x * 17 + y * 31) % 9 - 4;
			ctx.fillStyle = `rgb(${201 + n},${194 + n},${180 + n})`;
			ctx.fillRect(x * tile + 1, y * tile + 1, tile - 2, tile - 2);
		}
		ctx.strokeStyle = "rgba(150,140,128,0.55)";
		ctx.lineWidth = 2;
		for (let i = 0; i <= 4; i++) {
			ctx.beginPath();
			ctx.moveTo(i * tile, 0);
			ctx.lineTo(i * tile, s);
			ctx.stroke();
			ctx.beginPath();
			ctx.moveTo(0, i * tile);
			ctx.lineTo(s, i * tile);
			ctx.stroke();
		}
	}, 8);
}
function warehouseFloorTex() {
	return canvasTex(256, (ctx, s) => {
		ctx.fillStyle = "#8a8680";
		ctx.fillRect(0, 0, s, s);
		for (let i = 0; i < 80; i++) {
			ctx.fillStyle = `rgba(0,0,0,${.04 + Math.random() * .05})`;
			ctx.fillRect(Math.random() * s, Math.random() * s, 8 + Math.random() * 20, 2);
		}
		ctx.strokeStyle = "rgba(200,160,40,0.45)";
		ctx.lineWidth = 6;
		ctx.strokeRect(18, 18, s - 36, s - 36);
	}, 6);
}
function asphaltTex() {
	return canvasTex(256, (ctx, s) => {
		ctx.fillStyle = "#2a2c2e";
		ctx.fillRect(0, 0, s, s);
		for (let i = 0; i < 200; i++) {
			ctx.fillStyle = `rgba(255,255,255,${Math.random() * .05})`;
			ctx.fillRect(Math.random() * s, Math.random() * s, 2, 2);
		}
		ctx.fillStyle = "rgba(210,180,60,0.7)";
		ctx.fillRect(s / 2 - 4, 0, 8, s);
	}, 10);
}
function wallTex() {
	return canvasTex(256, (ctx, s) => {
		ctx.fillStyle = "#ece7dc";
		ctx.fillRect(0, 0, s, s);
		ctx.fillStyle = "#d8cfc0";
		ctx.fillRect(0, s * .82, s, s * .18);
		ctx.fillStyle = "#3a3f42";
		ctx.fillRect(0, s * .8, s, 6);
		for (let i = 0; i < 30; i++) {
			ctx.fillStyle = `rgba(0,0,0,${.015 + Math.random() * .02})`;
			ctx.fillRect(Math.random() * s, Math.random() * s * .8, 40, 3);
		}
	}, 4);
}
function ceilingTex() {
	return canvasTex(128, (ctx, s) => {
		ctx.fillStyle = "#dfe3e6";
		ctx.fillRect(0, 0, s, s);
		ctx.strokeStyle = "#c5ccd0";
		ctx.lineWidth = 3;
		ctx.strokeRect(2, 2, s - 4, s - 4);
	}, 12);
}
function metalTex() {
	return canvasTex(64, (ctx, s) => {
		const g = ctx.createLinearGradient(0, 0, s, 0);
		g.addColorStop(0, "#8b9298");
		g.addColorStop(.5, "#c5ccd2");
		g.addColorStop(1, "#8b9298");
		ctx.fillStyle = g;
		ctx.fillRect(0, 0, s, s);
	});
}
function productTex(name, hex) {
	return canvasTex(128, (ctx, s) => {
		ctx.fillStyle = hex;
		ctx.fillRect(0, 0, s, s);
		ctx.fillStyle = "rgba(0,0,0,0.18)";
		ctx.fillRect(0, s * .62, s, s * .38);
		ctx.fillStyle = "#f4f1ea";
		ctx.font = "bold 18px sans-serif";
		ctx.textAlign = "center";
		ctx.textBaseline = "middle";
		ctx.fillText(name.slice(0, 10).toUpperCase(), s / 2, s * .78);
		ctx.fillStyle = "rgba(255,255,255,0.28)";
		ctx.fillRect(8, 8, s - 16, 10);
	});
}
function hexColor(n) {
	return `#${n.toString(16).padStart(6, "0")}`;
}
var NavGrid = class {
	cell;
	ox;
	oz;
	cols;
	rows;
	walk;
	constructor(minX, minZ, maxX, maxZ, cell = .7) {
		this.cell = cell;
		this.ox = minX;
		this.oz = minZ;
		this.cols = Math.max(4, Math.ceil((maxX - minX) / cell));
		this.rows = Math.max(4, Math.ceil((maxZ - minZ) / cell));
		this.walk = new Uint8Array(this.cols * this.rows);
		this.walk.fill(1);
	}
	stamp(boxes, pad = .15) {
		for (const b of boxes) {
			const x0 = Math.max(0, Math.floor((b.minX - pad - this.ox) / this.cell));
			const z0 = Math.max(0, Math.floor((b.minZ - pad - this.oz) / this.cell));
			const x1 = Math.min(this.cols - 1, Math.floor((b.maxX + pad - this.ox) / this.cell));
			const z1 = Math.min(this.rows - 1, Math.floor((b.maxZ + pad - this.oz) / this.cell));
			for (let z = z0; z <= z1; z++) for (let x = x0; x <= x1; x++) this.walk[z * this.cols + x] = 0;
		}
	}
	world(i, j) {
		return {
			x: this.ox + (i + .5) * this.cell,
			z: this.oz + (j + .5) * this.cell
		};
	}
	cellAt(x, z) {
		return {
			i: Math.max(0, Math.min(this.cols - 1, Math.floor((x - this.ox) / this.cell))),
			j: Math.max(0, Math.min(this.rows - 1, Math.floor((z - this.oz) / this.cell)))
		};
	}
	isWalk(i, j) {
		if (i < 0 || j < 0 || i >= this.cols || j >= this.rows) return false;
		return this.walk[j * this.cols + i] === 1;
	}
	nearestWalk(x, z) {
		const c = this.cellAt(x, z);
		if (this.isWalk(c.i, c.j)) return {
			x,
			z
		};
		let best = 99;
		let bi = c.i;
		let bj = c.j;
		for (let r = 1; r < 8; r++) {
			for (let dj = -r; dj <= r; dj++) for (let di = -r; di <= r; di++) {
				if (!this.isWalk(c.i + di, c.j + dj)) continue;
				const d = Math.abs(di) + Math.abs(dj);
				if (d < best) {
					best = d;
					bi = c.i + di;
					bj = c.j + dj;
				}
			}
			if (best < 99) break;
		}
		return this.world(bi, bj);
	}
	find(sx, sz, tx, tz) {
		const a = this.cellAt(sx, sz);
		const b = this.cellAt(tx, tz);
		if (!this.isWalk(a.i, a.j)) {
			const n = this.nearestWalk(sx, sz);
			Object.assign(a, this.cellAt(n.x, n.z));
		}
		if (!this.isWalk(b.i, b.j)) {
			const n = this.nearestWalk(tx, tz);
			Object.assign(b, this.cellAt(n.x, n.z));
		}
		const start = a.j * this.cols + a.i;
		const goal = b.j * this.cols + b.i;
		if (start === goal) return [{
			x: tx,
			z: tz
		}];
		const cols = this.cols;
		const n = cols * this.rows;
		const came = new Int32Array(n).fill(-1);
		const gScore = new Float32Array(n).fill(1e9);
		const open = [start];
		gScore[start] = 0;
		const gi = goal % cols;
		const gj = goal / cols | 0;
		const h = (idx) => {
			const i = idx % cols;
			const j = idx / cols | 0;
			const dx = Math.abs(i - gi);
			const dz = Math.abs(j - gj);
			return dx + dz + (Math.SQRT2 - 2) * Math.min(dx, dz);
		};
		let found = false;
		let guard = 0;
		while (open.length && guard++ < 4e3) {
			let best = 0;
			let bf = 1e9;
			for (let k = 0; k < open.length; k++) {
				const idx = open[k];
				const f = gScore[idx] + h(idx);
				if (f < bf) {
					bf = f;
					best = k;
				}
			}
			const cur = open.splice(best, 1)[0];
			if (cur === goal) {
				found = true;
				break;
			}
			const ci = cur % cols;
			const cj = cur / cols | 0;
			for (let dj = -1; dj <= 1; dj++) for (let di = -1; di <= 1; di++) {
				if (!di && !dj) continue;
				const ni = ci + di;
				const nj = cj + dj;
				if (!this.isWalk(ni, nj)) continue;
				if (di && dj && (!this.isWalk(ci + di, cj) || !this.isWalk(ci, cj + dj))) continue;
				const nidx = nj * cols + ni;
				const step = di && dj ? Math.SQRT2 : 1;
				const ng = gScore[cur] + step;
				if (ng < gScore[nidx]) {
					gScore[nidx] = ng;
					came[nidx] = cur;
					if (!open.includes(nidx)) open.push(nidx);
				}
			}
		}
		if (!found) return [{
			x: tx,
			z: tz
		}];
		const rev = [{
			x: tx,
			z: tz
		}];
		let c = goal;
		while (c !== start && c !== -1) {
			rev.push(this.world(c % cols, c / cols | 0));
			c = came[c];
		}
		rev.reverse();
		return simplify(rev);
	}
};
function simplify(path) {
	if (path.length < 3) return path;
	const out = [path[0]];
	for (let i = 1; i < path.length - 1; i++) {
		const a = out[out.length - 1];
		const b = path[i];
		const c = path[i + 1];
		const abx = b.x - a.x;
		const abz = b.z - a.z;
		const bcx = c.x - b.x;
		const cross = abx * (c.z - b.z) - abz * bcx;
		if (Math.abs(cross) > .04) out.push(b);
	}
	out.push(path[path.length - 1]);
	return out;
}
function box(parent, mat, w, h, d, x, y, z, colliders, collide = false) {
	const m = new Mesh(new BoxGeometry(w, h, d), mat);
	m.position.set(x, y, z);
	m.castShadow = true;
	m.receiveShadow = true;
	parent.add(m);
	if (collide && colliders) colliders.push({
		minX: x - w / 2,
		maxX: x + w / 2,
		minZ: z - d / 2,
		maxZ: z + d / 2
	});
	return m;
}
function makeMats() {
	const ft = floorTex();
	const wt = wallTex();
	const ct = ceilingTex();
	const at = asphaltTex();
	const mt = metalTex();
	const wh = warehouseFloorTex();
	const products = /* @__PURE__ */ new Map();
	for (const p of PRODUCTS) {
		const tex = productTex(p.name, hexColor(p.color));
		products.set(p.id, new MeshStandardMaterial({
			map: tex,
			roughness: .55,
			metalness: .08
		}));
	}
	const mats = {
		floor: new MeshStandardMaterial({
			map: ft,
			roughness: .72,
			metalness: .04
		}),
		whFloor: new MeshStandardMaterial({
			map: wh,
			roughness: .85
		}),
		wall: new MeshStandardMaterial({
			map: wt,
			roughness: .8
		}),
		ceil: new MeshStandardMaterial({
			map: ct,
			roughness: .9
		}),
		asphalt: new MeshStandardMaterial({
			map: at,
			roughness: .95
		}),
		metal: new MeshStandardMaterial({
			map: mt,
			roughness: .35,
			metalness: .65
		}),
		dark: new MeshStandardMaterial({
			color: 2764852,
			roughness: .6
		}),
		wood: new MeshStandardMaterial({
			color: 9136404,
			roughness: .7
		}),
		glass: new MeshStandardMaterial({
			color: 10147048,
			transparent: true,
			opacity: .28,
			roughness: .05,
			metalness: .2
		}),
		white: new MeshStandardMaterial({
			color: 15265007,
			roughness: .45
		}),
		accent: new MeshStandardMaterial({
			color: 8244932,
			roughness: .4
		}),
		emit: new MeshStandardMaterial({
			color: 16052710,
			emissive: 16052710,
			emissiveIntensity: .85
		}),
		black: new MeshStandardMaterial({
			color: 1711392,
			roughness: .5
		}),
		green: new MeshStandardMaterial({
			color: 4880954,
			roughness: .8
		}),
		products
	};
	return {
		mats,
		dispose: () => {
			const list = [
				mats.floor,
				mats.whFloor,
				mats.wall,
				mats.ceil,
				mats.asphalt,
				mats.metal,
				mats.dark,
				mats.wood,
				mats.glass,
				mats.white,
				mats.accent,
				mats.emit,
				mats.black,
				mats.green,
				...products.values()
			];
			for (const m of list) {
				m.map?.dispose();
				m.dispose();
			}
			ft.dispose();
			wt.dispose();
			ct.dispose();
			at.dispose();
			mt.dispose();
			wh.dispose();
		}
	};
}
function buildWorld(level, checkoutsWanted, existing) {
	const { w, d } = storeFootprint(level);
	const hw = w / 2;
	const hd = d / 2;
	const { mats, dispose: disposeMats } = makeMats();
	const group = new Group();
	const colliders = [];
	const shelves = [];
	const checkouts = [];
	const pallets = [];
	const productBoxes = /* @__PURE__ */ new Map();
	const lights = [];
	const geoms = [];
	const wallH = 4.2;
	const warehouseDepth = 5.2;
	const whZ0 = -hd;
	const whZ1 = -hd + warehouseDepth;
	const shopZ0 = whZ1 + .4;
	const frontZ = hd - 2.2;
	box(group, mats.asphalt, 90, .08, 90, 0, -.06, 0);
	box(group, mats.green, 90, .05, 90, 0, -.04, -20);
	box(group, mats.floor, w, .12, d - warehouseDepth, 0, 0, (shopZ0 + hd) / 2 - .2);
	box(group, mats.whFloor, w, .12, warehouseDepth, 0, 0, (whZ0 + whZ1) / 2);
	const wall = (ww, wd, x, z) => box(group, mats.wall, ww, wallH, wd, x, wallH / 2, z, colliders, true);
	wall(w + .4, .35, 0, -hd);
	wall(.35, d, -hw, 0);
	wall(.35, d, hw, 0);
	const doorW = 3.6;
	wall((w - doorW) / 2, .28, -hw / 2 - doorW / 4, hd);
	wall((w - doorW) / 2, .28, hw / 2 + doorW / 4, hd);
	const glass = box(group, mats.glass, doorW, 3.1, .08, 0, 1.65, hd - .05);
	glass.castShadow = false;
	const ceil = box(group, mats.ceil, w, .12, d, 0, wallH, 0);
	ceil.castShadow = false;
	box(group, mats.dark, w - .4, .12, .2, 0, .12, whZ1);
	const sign = box(group, mats.accent, 7.4, .9, .12, 0, 3.55, hd + .2);
	sign.castShadow = false;
	const canvas = document.createElement("canvas");
	canvas.width = 1024;
	canvas.height = 128;
	const ctx = canvas.getContext("2d");
	if (ctx) {
		ctx.fillStyle = "#0b0f10";
		ctx.fillRect(0, 0, 1024, 128);
		ctx.fillStyle = "#7dcec4";
		ctx.font = "bold 72px Oswald, sans-serif";
		ctx.textAlign = "center";
		ctx.textBaseline = "middle";
		ctx.fillText("SUPER MARKET X", 512, 64);
	}
	const signTex = new CanvasTexture(canvas);
	signTex.colorSpace = SRGBColorSpace;
	const signMat = new MeshStandardMaterial({
		map: signTex,
		emissive: 8244932,
		emissiveIntensity: .25
	});
	const banner = new Mesh(new PlaneGeometry(7.2, .8), signMat);
	banner.position.set(0, 3.55, hd + .28);
	group.add(banner);
	for (let x = -hw + 1.6; x < hw - 1; x += 3.2) {
		const fixture = box(group, mats.emit, 2.4, .08, .5, x, 4, 0);
		fixture.castShadow = false;
		const pl = new PointLight(15921124, 2.4, 14, 2);
		pl.position.set(x, 3.6, 2);
		group.add(pl);
		lights.push(pl);
	}
	const hemi = new HemisphereLight(12113128, 3814444, .55);
	group.add(hemi);
	lights.push(hemi);
	const sun = new DirectionalLight(16773852, 1.15);
	sun.position.set(18, 28, 12);
	sun.castShadow = true;
	sun.shadow.mapSize.set(1024, 1024);
	sun.shadow.camera.near = 2;
	sun.shadow.camera.far = 70;
	sun.shadow.camera.left = -28;
	sun.shadow.camera.right = 28;
	sun.shadow.camera.top = 28;
	sun.shadow.camera.bottom = -28;
	group.add(sun);
	lights.push(sun);
	const lamp = (x, z) => {
		box(group, mats.dark, .12, 5.2, .12, x, 2.6, z);
		const cap = box(group, mats.emit, .7, .12, .7, x, 5.3, z);
		cap.castShadow = false;
	};
	lamp(-hw - 3, hd + 4);
	lamp(hw + 3, hd + 4);
	lamp(-hw - 3, -hd);
	lamp(hw + 3, -hd);
	const tree = (x, z) => {
		box(group, mats.wood, .28, 1.2, .28, x, .6, z);
		const crown = new Mesh(new SphereGeometry(1.1, 10, 8), mats.green);
		crown.position.set(x, 2.1, z);
		crown.castShadow = true;
		group.add(crown);
	};
	tree(-hw - 5, 4);
	tree(hw + 5, 6);
	tree(-hw - 6, -8);
	tree(hw + 6, -6);
	const nCheck = Math.min(4, Math.max(1, checkoutsWanted));
	const checkY = frontZ - 1.1;
	const span = Math.min(w - 6, nCheck * 3.6);
	const startX = -span / 2 + 1.6;
	for (let i = 0; i < nCheck; i++) {
		const x = startX + i * (span / Math.max(1, nCheck - 1 || 1));
		const cx = nCheck === 1 ? 0 : x;
		buildCheckout(group, mats, cx, checkY, colliders);
		const queue = [];
		for (let q = 0; q < 5; q++) queue.push({
			x: cx,
			z: checkY - 1.3 - q * 1.05
		});
		checkouts.push({
			id: `co${i}`,
			x: cx,
			z: checkY,
			queue
		});
	}
	const aisleZ0 = shopZ0 + 2.2;
	const aisleZ1 = checkY - 5.2;
	const aisleLen = Math.max(4.5, aisleZ1 - aisleZ0);
	const aisleMid = (aisleZ0 + aisleZ1) / 2;
	const aisleCount = 2 + level;
	const spacing = (w - 5.4) / (aisleCount + 1);
	const prev = existing ?? [];
	let shelfIdx = 0;
	const takeOrMake = (kind, x, z, rot, cap) => {
		const old = prev[shelfIdx];
		const starter = starterProduct(shelfIdx, kind, level);
		const slot = old ? {
			...old,
			x,
			z,
			rot,
			kind,
			capacity: cap
		} : {
			id: `sh${shelfIdx}`,
			kind,
			x,
			z,
			rot,
			w: kind === "produce" ? 1.8 : 1.5,
			d: kind === "gondola" ? aisleLen : 1.2,
			productId: starter,
			stock: starter ? Math.floor(cap * .7) : 0,
			capacity: cap,
			dirty: 0,
			broken: false
		};
		shelfIdx++;
		shelves.push(slot);
		return slot;
	};
	for (let a = 0; a < aisleCount; a++) {
		const x = -hw + 2.7 + spacing * (a + 1);
		const slot = takeOrMake("gondola", x, aisleMid, 0, 28);
		const gondola = buildGondola(group, mats, aisleLen, slot);
		productBoxes.set(slot.id, gondola);
		colliders.push({
			minX: x - .42,
			maxX: x + .42,
			minZ: aisleMid - aisleLen / 2,
			maxZ: aisleMid + aisleLen / 2
		});
	}
	const fridgeCount = 2 + Math.min(3, level);
	const fridgeZ = shopZ0 + 1.15;
	for (let i = 0; i < fridgeCount; i++) {
		const x = -hw + 2.2 + i * 2.15;
		if (x > hw - 2) break;
		const slot = takeOrMake("fridge", x, fridgeZ, 0, 18);
		const g = buildFridge(group, mats, slot);
		productBoxes.set(slot.id, g);
		colliders.push({
			minX: x - .85,
			maxX: x + .85,
			minZ: fridgeZ - .45,
			maxZ: fridgeZ + .45
		});
	}
	const freezeCount = 1 + Math.min(3, level);
	for (let i = 0; i < freezeCount; i++) {
		const x = hw - 2.4 - i * 2.1;
		const z = aisleMid - aisleLen / 4;
		const slot = takeOrMake("freezer", x, z, 0, 16);
		const g = buildFreezer(group, mats, slot);
		productBoxes.set(slot.id, g);
		colliders.push({
			minX: x - .85,
			maxX: x + .85,
			minZ: z - .7,
			maxZ: z + .7
		});
	}
	const produceCount = 1 + Math.min(2, level);
	for (let i = 0; i < produceCount; i++) {
		const x = -hw + 3.2 + i * 2.4;
		const z = checkY - 3.4;
		const slot = takeOrMake("produce", x, z, 0, 16);
		const g = buildProduce(group, mats, slot);
		productBoxes.set(slot.id, g);
		colliders.push({
			minX: x - .9,
			maxX: x + .9,
			minZ: z - .7,
			maxZ: z + .7
		});
	}
	if (level >= 2) {
		const x = hw - 2.6;
		const z = aisleMid + aisleLen / 4;
		const slot = takeOrMake("rack", x, z, 0, 22);
		const g = buildRack(group, mats, slot);
		productBoxes.set(slot.id, g);
		colliders.push({
			minX: x - .7,
			maxX: x + .7,
			minZ: z - 1.2,
			maxZ: z + 1.2
		});
	}
	const palN = 6 + level * 2;
	for (let i = 0; i < palN; i++) {
		const col = i % 6;
		const row = Math.floor(i / 6);
		const x = -hw + 1.8 + col * 2.4;
		const z = whZ0 + 1.4 + row * 1.8;
		pallets.push({
			id: `p${i}`,
			x,
			z
		});
		box(group, mats.wood, 1.2, .14, 1, x, .14, z);
	}
	box(group, mats.dark, 1.6, 1.1, .7, hw - 1.4, .55, whZ1 - 1.2, colliders, true);
	const dirtRoot = new Group();
	group.add(dirtRoot);
	const grid = new NavGrid(-hw + .4, -hd + .4, hw - .4, hd - .4, .7);
	grid.stamp(colliders, .08);
	const warehouseZone = {
		minX: -hw + .5,
		maxX: hw - .5,
		minZ: whZ0 + .4,
		maxZ: whZ1 - .2
	};
	return {
		group,
		colliders,
		shelves,
		checkouts,
		pallets,
		entrance: {
			x: 0,
			z: hd + .6
		},
		spawn: {
			x: 0,
			z: hd - 1.6,
			yaw: 0
		},
		warehouseZone,
		grid,
		w,
		d,
		lights,
		productBoxes,
		dirtRoot,
		banner,
		dispose: () => {
			group.traverse((obj) => {
				if (obj instanceof Mesh) obj.geometry.dispose();
			});
			for (const g of geoms) g.dispose();
			signTex.dispose();
			signMat.dispose();
			disposeMats();
		}
	};
}
function starterProduct(i, kind, level) {
	const pool = PRODUCTS.filter((p) => p.shelf === kind && p.unlockLevel <= level);
	if (!pool.length) {
		const any = PRODUCTS.filter((p) => p.unlockLevel <= level);
		return any[i % any.length]?.id ?? "bread";
	}
	return pool[i % pool.length].id;
}
function fillProducts(root, mats, slot, layout) {
	const wrap = new Group();
	wrap.name = "stock";
	root.add(wrap);
	const pid = slot.productId;
	if (!pid) return;
	const mat = mats.products.get(pid) ?? mats.white;
	const n = slot.capacity;
	if (layout === "bin") {
		const rows = 3;
		const cols = 4;
		let k = 0;
		for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
			if (k >= n) return;
			const m = new Mesh(new BoxGeometry(.22, .16, .22), mat);
			m.position.set((c - 1.5) * .32, .55 + r * .14, (Math.floor(k / 12) - .5) * .28);
			m.castShadow = true;
			wrap.add(m);
			k++;
		}
		return;
	}
	const layers = 4;
	const per = Math.ceil(n / layers);
	let k = 0;
	for (let layer = 0; layer < layers; layer++) for (let i = 0; i < per; i++) {
		if (k >= n) return;
		const m = new Mesh(new BoxGeometry(.2, .18, .16), mat);
		const along = (i / Math.max(1, per - 1) - .5) * (slot.d - .5);
		m.position.set(.12 * (k % 2 === 0 ? 1 : -1), .42 + layer * .38, along);
		m.castShadow = true;
		wrap.add(m);
		k++;
	}
}
function syncShelfVisual(slot, group) {
	if (!group) return;
	const stock = group.getObjectByName("stock");
	if (!stock) return;
	const vis = Math.round(slot.stock / Math.max(1, slot.capacity) * stock.children.length);
	stock.children.forEach((c, i) => {
		c.visible = i < vis && !slot.broken;
	});
}
function buildGondola(parent, mats, len, slot) {
	const g = new Group();
	g.position.set(slot.x, 0, slot.z);
	parent.add(g);
	box(g, mats.metal, .78, .12, len, 0, .12, 0);
	box(g, mats.dark, .06, 1.7, len, 0, .95, 0);
	for (const y of [
		.38,
		.76,
		1.14,
		1.52
	]) box(g, mats.metal, .72, .04, len - .1, 0, y, 0);
	fillProducts(g, mats, slot, "shelf");
	return g;
}
function buildFridge(parent, mats, slot) {
	const g = new Group();
	g.position.set(slot.x, 0, slot.z);
	parent.add(g);
	box(g, mats.white, 1.6, 2.1, .78, 0, 1.05, 0);
	const inner = new Mesh(new BoxGeometry(1.4, 1.7, .08), new MeshStandardMaterial({
		color: 10147048,
		transparent: true,
		opacity: .22,
		emissive: 8308960,
		emissiveIntensity: .35
	}));
	inner.position.set(0, 1.1, .4);
	g.add(inner);
	fillProducts(g, mats, slot, "shelf");
	return g;
}
function buildFreezer(parent, mats, slot) {
	const g = new Group();
	g.position.set(slot.x, 0, slot.z);
	parent.add(g);
	box(g, mats.white, 1.6, .95, 1.2, 0, .48, 0);
	const lid = new Mesh(new BoxGeometry(1.45, .05, 1.05), new MeshStandardMaterial({
		color: 11065582,
		transparent: true,
		opacity: .35,
		emissive: 7258336,
		emissiveIntensity: .2
	}));
	lid.position.set(0, 1, 0);
	g.add(lid);
	fillProducts(g, mats, slot, "bin");
	return g;
}
function buildProduce(parent, mats, slot) {
	const g = new Group();
	g.position.set(slot.x, 0, slot.z);
	parent.add(g);
	box(g, mats.wood, 1.8, .7, 1.2, 0, .35, 0);
	fillProducts(g, mats, slot, "bin");
	return g;
}
function buildRack(parent, mats, slot) {
	const g = new Group();
	g.position.set(slot.x, 0, slot.z);
	parent.add(g);
	box(g, mats.metal, 1.1, 2.2, 2.2, 0, 1.1, 0);
	fillProducts(g, mats, slot, "shelf");
	return g;
}
function buildCheckout(parent, mats, x, z, colliders) {
	box(parent, mats.dark, 2.2, .92, 1.15, x, .46, z, colliders, true);
	box(parent, mats.black, 1.4, .05, .45, x - .1, .94, z);
	box(parent, mats.accent, .35, .28, .28, x + .85, 1.12, z - .2);
	box(parent, mats.metal, .22, .9, .22, x + .9, .55, z + .4);
}
function makeCharacter(color, scale = 1, apron = false) {
	const g = new Group();
	g.scale.setScalar(scale);
	const bodyMat = new MeshStandardMaterial({
		color,
		roughness: .55
	});
	const skin = new MeshStandardMaterial({
		color: 14861480,
		roughness: .6
	});
	const dark = new MeshStandardMaterial({
		color: 1842978,
		roughness: .5
	});
	const body = new Mesh(new BoxGeometry(.42, .62, .28), bodyMat);
	body.position.y = .92;
	body.castShadow = true;
	g.add(body);
	if (apron) {
		const a = new Mesh(new BoxGeometry(.36, .4, .08), new MeshStandardMaterial({
			color: 8244932,
			roughness: .5
		}));
		a.position.set(0, .82, .16);
		g.add(a);
	}
	const head = new Mesh(new SphereGeometry(.16, 12, 10), skin);
	head.position.y = 1.38;
	head.castShadow = true;
	g.add(head);
	const hair = new Mesh(new SphereGeometry(.165, 10, 8), dark);
	hair.position.set(0, 1.46, -.02);
	hair.scale.set(1, .7, 1);
	g.add(hair);
	const legGeo = new BoxGeometry(.12, .42, .14);
	const l = new Mesh(legGeo, dark);
	l.position.set(-.11, .28, 0);
	l.name = "legL";
	l.castShadow = true;
	const r = new Mesh(legGeo, dark);
	r.position.set(.11, .28, 0);
	r.name = "legR";
	r.castShadow = true;
	g.add(l, r);
	const armGeo = new BoxGeometry(.1, .42, .1);
	const al = new Mesh(armGeo, bodyMat);
	al.position.set(-.28, .95, 0);
	al.name = "armL";
	const ar = new Mesh(armGeo, bodyMat);
	ar.position.set(.28, .95, 0);
	ar.name = "armR";
	g.add(al, ar);
	const hold = new Group();
	hold.name = "hold";
	hold.position.set(.28, .85, .28);
	hold.visible = false;
	const crate = new Mesh(new BoxGeometry(.32, .22, .28), new MeshStandardMaterial({ color: 12093770 }));
	hold.add(crate);
	g.add(hold);
	return g;
}
var _f = new Vector3();
var _cam = new Vector3();
var _look = new Vector3();
function createGame(canvas, hooks) {
	const sim = new Sim(loadSave());
	const input = new Input();
	const audio = new GameAudio();
	audio.sfxVol = sim.s.settings.sfx;
	audio.musicVol = sim.s.settings.music;
	audio.applyVol();
	const renderer = new WebGLRenderer({
		canvas,
		antialias: sim.s.settings.quality !== "low",
		powerPreference: "high-performance",
		alpha: false
	});
	renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, sim.s.settings.quality === "high" ? 2 : 1.5));
	renderer.setSize(canvas.clientWidth || 800, canvas.clientHeight || 450, false);
	renderer.shadowMap.enabled = sim.s.settings.quality !== "low";
	renderer.shadowMap.type = 2;
	renderer.outputColorSpace = SRGBColorSpace;
	renderer.toneMapping = 4;
	renderer.toneMappingExposure = 1.05;
	const scene = new Scene();
	scene.background = new Color(8888500);
	scene.fog = new Fog(8888500, 28, 72);
	const camera = new PerspectiveCamera(58, 16 / 9, .08, 120);
	camera.position.set(0, 4, 12);
	let world = buildWorld(sim.s.storeLevel, sim.s.checkouts, sim.s.shelves);
	scene.add(world.group);
	sim.bindLayout({
		colliders: world.colliders,
		checkouts: world.checkouts,
		pallets: world.pallets,
		shelves: world.shelves,
		grid: world.grid,
		entrance: world.entrance,
		warehouseZone: world.warehouseZone,
		spawn: world.spawn,
		w: world.w,
		d: world.d
	});
	const playerMesh = makeCharacter(2767426, 1, true);
	scene.add(playerMesh);
	const customerMeshes = /* @__PURE__ */ new Map();
	const staffMeshes = /* @__PURE__ */ new Map();
	const detachInput = input.attach(canvas);
	let running = false;
	let last = 0;
	let acc = 0;
	const FIXED = 1 / 60;
	let hudT = 0;
	let saveT = 0;
	let toastSeen = "";
	let lastReportDay = 0;
	let lastFoot = 0;
	const setQuality = (q) => {
		sim.s.settings.quality = q;
		renderer.shadowMap.enabled = q !== "low";
		renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, q === "high" ? 2 : q === "med" ? 1.5 : 1));
		const sun = world.lights.find((l) => l instanceof DirectionalLight);
		if (sun?.shadow) sun.shadow.mapSize.set(q === "high" ? 1024 : 512, q === "high" ? 1024 : 512);
	};
	const rebuild = () => {
		scene.remove(world.group);
		world.dispose();
		world = buildWorld(sim.s.storeLevel, sim.s.checkouts, sim.s.shelves);
		scene.add(world.group);
		sim.bindLayout({
			colliders: world.colliders,
			checkouts: world.checkouts,
			pallets: world.pallets,
			shelves: world.shelves,
			grid: world.grid,
			entrance: world.entrance,
			warehouseZone: world.warehouseZone,
			spawn: world.spawn,
			w: world.w,
			d: world.d
		});
		setQuality(sim.s.settings.quality);
	};
	const resize = () => {
		const w = canvas.clientWidth || 800;
		const h = canvas.clientHeight || 450;
		renderer.setSize(w, h, false);
		camera.aspect = w / Math.max(1, h);
		camera.updateProjectionMatrix();
	};
	resize();
	const ro = new ResizeObserver(resize);
	ro.observe(canvas);
	const syncActors = () => {
		const seenC = /* @__PURE__ */ new Set();
		for (const c of sim.customers) {
			seenC.add(c.id);
			let m = customerMeshes.get(c.id);
			if (!m) {
				m = makeCharacter(c.color, c.scale);
				customerMeshes.set(c.id, m);
				scene.add(m);
			}
			m.position.set(c.x, 0, c.z);
			m.rotation.y = c.yaw;
			bob(m, c.anim, c.state === "queue" || c.state === "take" ? 0 : 1);
			const hold = m.getObjectByName("hold");
			if (hold) hold.visible = c.cart.length > 0;
		}
		for (const [id, m] of customerMeshes) if (!seenC.has(id)) {
			scene.remove(m);
			customerMeshes.delete(id);
		}
		const seenS = /* @__PURE__ */ new Set();
		for (const e of sim.s.staff) {
			seenS.add(e.id);
			let m = staffMeshes.get(e.id);
			if (!m) {
				m = makeCharacter(roleColor(e.role), 1, e.role === "cashier");
				staffMeshes.set(e.id, m);
				scene.add(m);
			}
			m.position.set(e.x, 0, e.z);
			m.rotation.y = e.yaw;
			bob(m, e.anim, e.path.length ? 1 : 0);
			const hold = m.getObjectByName("hold");
			if (hold) hold.visible = !!e.holding;
		}
		for (const [id, m] of staffMeshes) if (!seenS.has(id)) {
			scene.remove(m);
			staffMeshes.delete(id);
		}
		for (const sh of sim.s.shelves) syncShelfVisual(sh, world.productBoxes.get(sh.id));
	};
	const updateCamera = (dt, actions) => {
		const look = input.consumeLook();
		sim.camYaw -= look.x * .0024;
		sim.camPitch -= look.y * .0022;
		sim.camPitch = Math.max(-1.05, Math.min(-.08, sim.camPitch));
		const p = sim.s.player;
		playerMesh.position.set(p.x, 0, p.z);
		playerMesh.rotation.y = p.yaw;
		bob(playerMesh, sim.footT, sim.speed > .2 ? 1 : 0);
		const hold = playerMesh.getObjectByName("hold");
		if (hold) hold.visible = !!p.holding;
		const fy = -Math.sin(sim.camYaw);
		const fz = -Math.cos(sim.camYaw);
		_f.set(fy, 0, fz);
		const dist = 6.4;
		_cam.set(p.x - _f.x * dist, 3.15, p.z - _f.z * dist);
		_cam.y += Math.sin(sim.camPitch + .4) * .2;
		const k = 1 - Math.exp(-8 * dt);
		camera.position.lerp(_cam, k);
		_look.set(p.x, 1.35, p.z);
		camera.lookAt(_look);
		if (sim.s.settings.shake && sim.trauma > .02) {
			const s = sim.trauma * sim.trauma;
			camera.position.x += (Math.random() - .5) * s * .18;
			camera.position.y += (Math.random() - .5) * s * .12;
		}
	};
	const lighting = () => {
		const h = sim.s.timeOfDay;
		const day = h > 6 && h < 20;
		const dusk = h > 17 && h < 19.5 ? (h - 17) / 2.5 : h >= 19.5 ? 1 : 0;
		const sky = day ? new Color().lerpColors(new Color(8888500), new Color(1712688), dusk) : new Color(856600);
		scene.background = sky;
		if (scene.fog) scene.fog.color.copy(sky);
		const sun = world.lights.find((l) => l instanceof DirectionalLight);
		if (sun) sun.intensity = day ? 1.15 * (1 - dusk * .75) : .08;
		const outage = sim.s.event?.kind === "outage" || sim.s.event?.kind === "fire";
		for (const l of world.lights) if (l instanceof PointLight) l.intensity = outage ? .15 : 2.2 + sim.s.lights * .4;
		renderer.toneMappingExposure = outage ? .45 : sim.s.event?.kind === "festival" ? 1.15 : 1.05;
	};
	const loop = (now) => {
		if (!running) return;
		if (!last) last = now;
		let dt = Math.min((now - last) / 1e3, .1);
		last = now;
		acc += dt;
		const actions = input.sample();
		let steps = 0;
		while (acc >= FIXED && steps < 5) {
			sim.step(FIXED, actions);
			acc -= FIXED;
			steps++;
		}
		updateCamera(dt, actions);
		syncActors();
		lighting();
		audio.tickMusic(dt);
		if (sim.speed > .4 && sim.footT - lastFoot > .42) {
			lastFoot = sim.footT;
			audio.step();
		}
		if (sim.toast && sim.toast.text !== toastSeen) {
			toastSeen = sim.toast.text;
			hooks.onToast(sim.toast.text);
			if (/Receipt|Scanned|Delivery/.test(sim.toast.text)) audio.register();
			else if (/Hired|Unlocked|Mission|Stocked/.test(sim.toast.text)) audio.coin();
			else if (/Fire|outage|thief|broke|left the queue/.test(sim.toast.text)) audio.error();
			else audio.chime();
		}
		if (sim.report && sim.report.day !== lastReportDay) {
			lastReportDay = sim.report.day;
			hooks.onDayEnd(sim.report);
		}
		hudT += dt;
		if (hudT > .08) {
			hudT = 0;
			hooks.onHud(sim.hud());
		}
		saveT += dt;
		if (saveT > 8) {
			saveT = 0;
			writeSave(sim.s);
		}
		renderer.render(scene, camera);
	};
	const onHide = () => {
		if (document.hidden) writeSave(sim.s);
		else if (audio.ctx?.state === "suspended") audio.ctx.resume();
	};
	document.addEventListener("visibilitychange", onHide);
	const start = () => {
		if (running) return;
		running = true;
		last = 0;
		audio.unlock();
		renderer.setAnimationLoop(loop);
	};
	const stop = () => {
		running = false;
		renderer.setAnimationLoop(null);
	};
	if (new URLSearchParams(window.location.search).has("qa") || false) window.__controlsTest = {
		getYaw: () => sim.s.player.yaw,
		getSpeed: () => sim.speed,
		getPos: () => ({
			x: sim.s.player.x,
			z: sim.s.player.z
		}),
		setKeys: (codes) => input.setKeys(codes),
		setSteer: (v) => {
			if (v > .2) input.setKeys(["KeyW", "KeyA"]);
			else if (v < -.2) input.setKeys(["KeyW", "KeyD"]);
			else input.setKeys(["KeyW"]);
		}
	};
	renderer.render(scene, camera);
	return {
		sim,
		input,
		audio,
		start,
		stop,
		setQuality,
		rebuild,
		dispose: () => {
			stop();
			writeSave(sim.s);
			detachInput();
			ro.disconnect();
			document.removeEventListener("visibilitychange", onHide);
			world.dispose();
			renderer.dispose();
			audio.dispose();
			delete window.__controlsTest;
		}
	};
}
function bob(g, t, amp) {
	const l = g.getObjectByName("legL");
	const r = g.getObjectByName("legR");
	if (l) l.rotation.x = Math.sin(t * 6) * .55 * amp;
	if (r) r.rotation.x = Math.sin(t * 6 + Math.PI) * .55 * amp;
	g.position.y = Math.abs(Math.sin(t * 6)) * .03 * amp;
}
function roleColor(role) {
	switch (role) {
		case "cashier": return 4025706;
		case "stocker": return 6969914;
		case "cleaner": return 5929610;
		case "security": return 2765636;
		case "delivery": return 5925434;
		default: return 4864602;
	}
}
//#endregion
export { createGame };
