import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { a as exportBackup, m as useBootstrap } from "./use-books-BtZpLk9U.mjs";
import { i as PageHeader, n as Card } from "./card-Bb_-PO54.mjs";
import { t as Button } from "./button-BiViDDnZ.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as downloadJson } from "./export-tWZA3qLh.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-LqOCs7TO.js
var import_jsx_runtime = require_jsx_runtime();
function SettingsPage() {
	const boot = useBootstrap();
	async function backup() {
		const data = await exportBackup();
		downloadJson(`MR-KHORASANI-Backup-${boot.data?.fiscalYear.code ?? "1405"}`, data);
		toast.success("پشتیبان دانلود شد");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		title: "تنظیمات",
		description: "شرکت، سال مالی، پشتیبان‌گیری و فضای ابری."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 lg:grid-cols-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-sm font-medium text-navy",
				children: "شرکت"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mt-4 space-y-2 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted",
							children: "نام"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: boot.data?.companyName })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted",
							children: "برند"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: boot.data?.companyNameEn })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted",
							children: "سال مالی"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: boot.data?.fiscalYear.name })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted",
							children: "بازه"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", { children: [
							boot.data?.fiscalYear.start_date,
							" — ",
							boot.data?.fiscalYear.end_date
						] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted",
							children: "واحد پول"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: "ریال ایران" })]
					})
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-medium text-navy",
					children: "پشتیبان و همگام‌سازی"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: "دفاتر روی فضای ابری (پایگاه داده امن) ذخیره می‌شوند. پشتیبان JSON شامل عملیات، اسناد، اشخاص و Audit Log است."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-5",
					onClick: backup,
					children: "دانلود پشتیبان"
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "lg:col-span-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-medium text-navy",
					children: "نقش‌ها"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: "در این نسخه هر کاربر دفاتر مستقل خود را دارد (مدیر سیستم). نقش‌های حسابدار، صندوقدار و ناظر برای استقرار چندکاربره شرکت قابل گسترش است."
				})]
			})
		]
	})] });
}
//#endregion
export { SettingsPage as component };
