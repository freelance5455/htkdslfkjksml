import { a as leagueById, i as leagueByEspn, o as openligaYear, s as seasonLabel, t as LEAGUES } from "./catalog-J4SrKMs0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/providers.server-Cwdrc15M.js
var ESPN = "https://site.api.espn.com/apis/site/v2/sports/soccer";
var SDB = "https://www.thesportsdb.com/api/v1/json/123/";
var OL = "https://api.openligadb.de";
var mem = /* @__PURE__ */ new Map();
function fromCache(key, ttl) {
	const hit = mem.get(key);
	if (!hit) return void 0;
	if (Date.now() - hit.at > ttl) return void 0;
	return hit.data;
}
function peekCache(key) {
	return mem.get(key)?.data;
}
function putCache(key, data) {
	mem.set(key, {
		at: Date.now(),
		data
	});
}
async function getJSON(url, ms = 12e3) {
	const ctrl = new AbortController();
	const timer = setTimeout(() => ctrl.abort(), ms);
	try {
		const res = await fetch(url, {
			signal: ctrl.signal,
			headers: { accept: "application/json" }
		});
		if (!res.ok) return null;
		return await res.json();
	} catch {
		return null;
	} finally {
		clearTimeout(timer);
	}
}
var sdbTail = Promise.resolve();
var sdbLast = 0;
function sdb(path) {
	const job = sdbTail.then(async () => {
		const wait = Math.max(0, 1100 - (Date.now() - sdbLast));
		if (wait) await new Promise((r) => setTimeout(r, wait));
		sdbLast = Date.now();
		return getJSON(SDB + path, 14e3);
	});
	sdbTail = job.then(() => void 0, () => void 0);
	return job;
}
async function directory() {
	const cached = fromCache("dir", 432e5);
	if (cached) return cached;
	const json = await getJSON("https://site.api.espn.com/apis/site/v2/leagues/dropdown?lang=en&region=us&sport=soccer&limit=500");
	const map = /* @__PURE__ */ new Map();
	for (const raw of json?.leagues ?? []) {
		const id = String(raw.id ?? "");
		const slug = String(raw.slug ?? "");
		if (!id || !slug) continue;
		const href = raw.logos?.[0]?.href ?? null;
		const logo = href && !href.includes("default-team-logo") ? href : null;
		map.set(id, {
			id,
			slug,
			name: String(raw.name ?? slug),
			logo
		});
	}
	if (map.size) putCache("dir", map);
	return map;
}
function num(value) {
	if (typeof value === "number" && Number.isFinite(value)) return value;
	if (typeof value === "string" && value.trim() !== "") {
		const n = Number(value);
		return Number.isFinite(n) ? n : null;
	}
	if (value && typeof value === "object" && "displayValue" in value) return num(value.displayValue);
	return null;
}
function str(value, fallback = "") {
	return typeof value === "string" && value.trim() ? value : fallback;
}
function leagueNumFromUid(uid) {
	return str(uid).match(/~l:(\d+)~/)?.[1] ?? null;
}
function namesFor(slug, dir, numericId) {
	const known = leagueByEspn(slug);
	if (known) return {
		ar: known.nameAr,
		en: known.nameEn,
		logo: known.logo,
		id: known.id,
		source: known.source
	};
	const fromNum = numericId ? dir.get(numericId) : void 0;
	const name = fromNum?.name || slug;
	return {
		ar: name,
		en: name,
		logo: fromNum?.logo ?? null,
		id: `espn:${slug}`,
		source: "espn"
	};
}
function espnFixture(event, dir, fallback) {
	const comp = event.competitions?.[0];
	if (!comp) return null;
	const competitors = comp.competitors ?? [];
	const homeRaw = competitors.find((c) => c.homeAway === "home") ?? competitors[0];
	const awayRaw = competitors.find((c) => c.homeAway === "away") ?? competitors[1];
	if (!homeRaw || !awayRaw) return null;
	const status = comp.status ?? event.status;
	const type = status?.type ?? {};
	const state = str(type.state, "pre");
	const statusKind = state === "in" ? "in" : state === "post" ? "post" : "pre";
	const numeric = leagueNumFromUid(event.uid) ?? leagueNumFromUid(comp.uid);
	const slug = (numeric ? dir.get(numeric) : void 0)?.slug ?? fallback?.id.replace(/^espn:/, "") ?? "";
	const names = slug ? namesFor(slug, dir, numeric) : fallback;
	if (!names) return null;
	const side = (raw) => {
		const team = raw.team ?? {};
		const logo = str(team.logo) || (team.logos?.[0]?.href ?? "") || null;
		return {
			id: str(team.id, str(raw.id, "0")),
			name: str(team.displayName, str(team.name, "Team")),
			short: str(team.abbreviation, str(team.shortDisplayName, "FC")).slice(0, 4),
			logo: logo || null,
			score: statusKind === "pre" ? null : num(raw.score)
		};
	};
	const venue = comp.venue;
	const clock = str(status?.displayClock ?? "");
	const detail = str(type.shortDetail, str(type.description, statusKind));
	return {
		id: str(event.id, str(comp.id)),
		leagueId: names.id,
		leagueNameAr: names.ar,
		leagueNameEn: names.en,
		leagueLogo: names.logo,
		kickoff: str(event.date, str(comp.date, (/* @__PURE__ */ new Date()).toISOString())),
		status: statusKind,
		statusText: statusKind === "in" && clock ? clock : detail,
		venue: venue?.fullName,
		source: "espn",
		home: side(homeRaw),
		away: side(awayRaw)
	};
}
async function scoreboard(slug, date) {
	const key = `sb:${slug}:${date ?? "next"}`;
	const hit = fromCache(key, date ? 9e4 : 12e4);
	if (hit) return hit;
	const json = await getJSON(`${ESPN}/${slug}/scoreboard${date ? `?dates=${date}&limit=100` : ""}`);
	if (json) putCache(key, json);
	return json;
}
async function dayFixtures(date) {
	const key = `day:${date}`;
	const hit = fromCache(key, 6e4);
	if (hit) return hit;
	const dir = await directory();
	const json = await getJSON(`${ESPN}/all/scoreboard?dates=${date}&limit=300`);
	const list = (json?.events ?? []).map((event) => espnFixture(event, dir)).filter((x) => Boolean(x));
	list.sort((a, b) => a.kickoff.localeCompare(b.kickoff));
	if (json) putCache(key, list);
	return list;
}
function rowFromEntry(entry, group) {
	const team = entry.team ?? {};
	const stats = entry.stats ?? [];
	const stat = (name) => {
		const found = stats.find((s) => s.name === name || s.abbreviation === name);
		if (!found) return 0;
		return num(found.displayValue ?? found.value) ?? 0;
	};
	const name = str(team.displayName, str(team.name));
	if (!name) return null;
	const logos = team.logos;
	const gf = stat("pointsFor");
	const ga = stat("pointsAgainst");
	const gdRaw = stats.find((s) => s.name === "pointDifferential");
	const gd = gdRaw ? num(String(gdRaw.displayValue ?? "").replace("+", "")) ?? gf - ga : gf - ga;
	return {
		rank: stat("rank") || 0,
		group,
		team: {
			id: str(team.id),
			name,
			short: str(team.abbreviation, name.slice(0, 3)).slice(0, 4),
			logo: logos?.[0]?.href ?? null
		},
		played: stat("gamesPlayed"),
		won: stat("wins"),
		draw: stat("ties"),
		lost: stat("losses"),
		gf,
		ga,
		gd,
		pts: stat("points")
	};
}
async function espnStandings(slug) {
	const key = `table:${slug}`;
	const hit = fromCache(key, 3e5);
	if (hit) return hit;
	const json = await getJSON(`https://site.api.espn.com/apis/v2/sports/soccer/${slug}/standings`);
	const season = str(json?.abbreviation ?? "");
	const children = json?.children ?? [];
	const groups = children.map((child) => {
		const entries = child.standings?.entries ?? [];
		const name = children.length > 1 ? str(child.name || child.abbreviation) : void 0;
		const rows = entries.map((entry) => rowFromEntry(entry, name || void 0)).filter((r) => Boolean(r)).sort((a, b) => a.rank - b.rank || b.pts - a.pts || b.gd - a.gd);
		return {
			name: name || void 0,
			rows
		};
	});
	const data = {
		season: str(children[0]?.name ?? (json?.season)?.displayName ?? season),
		groups: groups.filter((g) => g.rows.length)
	};
	if (json) putCache(key, data);
	return data;
}
async function espnNews(slugs) {
	const key = `news:${slugs.join(",")}`;
	const hit = fromCache(key, 6e5);
	if (hit) return hit;
	const batches = await Promise.all(slugs.map(async (slug) => {
		return ((await getJSON(`${ESPN}/${slug}/news?limit=6`))?.articles ?? []).map((article) => {
			const links = article.links;
			const images = article.images;
			return {
				id: str(article.id, str(article.headline)),
				title: str(article.headline, "News"),
				summary: str(article.description),
				url: links?.web?.href ?? "",
				image: images?.[0]?.url ?? null,
				published: str(article.published, (/* @__PURE__ */ new Date()).toISOString()),
				source: "ESPN",
				leagueId: leagueByEspn(slug)?.id ?? `espn:${slug}`
			};
		});
	}));
	const seen = /* @__PURE__ */ new Set();
	const stories = batches.flat().filter((story) => {
		if (!story.url || seen.has(story.title)) return false;
		seen.add(story.title);
		return true;
	}).sort((a, b) => b.published.localeCompare(a.published)).slice(0, 12);
	if (stories.length) putCache(key, stories);
	return stories;
}
function fixtureList(json, dir, fallback) {
	return (json?.events ?? []).map((event) => espnFixture(event, dir, fallback)).filter((x) => Boolean(x));
}
async function espnLeaders(slug, leagueId) {
	const key = `lead:${slug}`;
	const hit = fromCache(key, 18e5);
	if (hit) return hit;
	const json = await getJSON(`${ESPN}/${slug}/statistics`);
	const take = (name, kind) => {
		return ((json?.stats?.find((s) => s.name === name))?.leaders ?? []).slice(0, 15).map((leader) => {
			const athlete = leader.athlete ?? {};
			const team = athlete.team ?? leader.team ?? {};
			const logos = team.logos;
			return {
				id: str(athlete.id, str(leader.value)),
				name: str(athlete.displayName, "Player"),
				teamId: str(team.id),
				teamName: str(team.displayName, str(team.name, "")),
				teamLogo: logos?.[0]?.href ?? null,
				value: num(leader.value) ?? 0,
				detail: str(leader.displayValue),
				jersey: str(athlete.jersey) || void 0,
				kind
			};
		});
	};
	const data = {
		scorers: take("goalsLeaders", "goals"),
		assists: take("assistsLeaders", "assists")
	};
	if (json) putCache(key, data);
	return data;
}
function clubFromRow(row, def) {
	return {
		id: row.team.id,
		name: row.team.name,
		short: row.team.short,
		logo: row.team.logo,
		leagueId: def.id,
		leagueNameAr: def.nameAr,
		leagueNameEn: def.nameEn
	};
}
function sdbDate(event) {
	const stamp = str(event.strTimestamp);
	if (stamp) {
		const d = new Date(stamp);
		if (!Number.isNaN(d.getTime())) return d.toISOString();
	}
	const date = str(event.dateEvent);
	if (!date) return (/* @__PURE__ */ new Date()).toISOString();
	const time = str(event.strTime, "15:00:00").slice(0, 8);
	const d = /* @__PURE__ */ new Date(`${date}T${time}Z`);
	return Number.isNaN(d.getTime()) ? (/* @__PURE__ */ new Date()).toISOString() : d.toISOString();
}
function sdbFixture(event, def) {
	const home = str(event.strHomeTeam);
	const away = str(event.strAwayTeam);
	if (!home || !away) return null;
	const hs = num(event.intHomeScore);
	const as = num(event.intAwayScore);
	const statusText = str(event.strStatus, "Scheduled");
	const live = /live|half|progress/i.test(statusText);
	const finished = /finish|ft|full/i.test(statusText) || hs !== null && as !== null && !live;
	const status = live ? "in" : finished ? "post" : "pre";
	return {
		id: `sdb:${str(event.idEvent)}`,
		leagueId: def.id,
		leagueNameAr: def.nameAr,
		leagueNameEn: def.nameEn,
		leagueLogo: def.logo,
		kickoff: sdbDate(event),
		status,
		statusText: status === "post" ? "FT" : status === "in" ? statusText : statusText || "Scheduled",
		venue: str(event.strVenue) || void 0,
		source: "sportsdb",
		home: {
			id: `sdb:${str(event.idHomeTeam, home)}`,
			name: home,
			short: home.slice(0, 3).toUpperCase(),
			logo: str(event.strHomeTeamBadge) || null,
			score: status === "pre" ? null : hs
		},
		away: {
			id: `sdb:${str(event.idAwayTeam, away)}`,
			name: away,
			short: away.slice(0, 3).toUpperCase(),
			logo: str(event.strAwayTeamBadge) || null,
			score: status === "pre" ? null : as
		}
	};
}
async function loadSportsDb(def) {
	const season = seasonLabel(def);
	const empty = {
		id: def.id,
		nameAr: def.nameAr,
		nameEn: def.nameEn,
		countryAr: def.countryAr,
		countryEn: def.countryEn,
		region: def.region,
		logo: def.logo,
		source: "sportsdb",
		season,
		updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
		stale: false,
		partial: false,
		standings: [],
		results: [],
		upcoming: [],
		teams: [],
		scorers: [],
		assists: []
	};
	if (!def.sportsdbId) return {
		...empty,
		error: "missing id",
		noteAr: "هذه البطولة غير مربوطة بمصدر.",
		noteEn: "This competition has no data source."
	};
	const key = `sdb:${def.id}:${season}`;
	const fresh = fromCache(key, 6e5);
	if (fresh) return fresh;
	const [meta, table, next, past] = await Promise.all([
		sdb(`lookupleague.php?id=${def.sportsdbId}`),
		sdb(`lookuptable.php?l=${def.sportsdbId}&s=${season}`),
		sdb(`eventsnextleague.php?id=${def.sportsdbId}`),
		sdb(`eventspastleague.php?id=${def.sportsdbId}`)
	]);
	const badge = str(meta?.leagues?.[0]?.strBadge) || def.logo;
	const rows = (table?.table ?? []).map((row) => {
		const name = str(row.strTeam);
		if (!name) return null;
		const gf = num(row.intGoalsFor) ?? 0;
		const ga = num(row.intGoalsAgainst) ?? 0;
		return {
			rank: num(row.intRank) ?? 0,
			team: {
				id: `sdb:${str(row.idTeam, name)}`,
				name,
				short: name.slice(0, 3).toUpperCase(),
				logo: str(row.strTeamBadge || row.strBadge) || null
			},
			played: num(row.intPlayed) ?? 0,
			won: num(row.intWin) ?? 0,
			draw: num(row.intDraw) ?? 0,
			lost: num(row.intLoss) ?? 0,
			gf,
			ga,
			gd: num(row.intGoalDifference) ?? gf - ga,
			pts: num(row.intPoints) ?? 0
		};
	}).filter((r) => Boolean(r));
	const upcoming = (next?.events ?? []).map((e) => sdbFixture(e, {
		...def,
		logo: badge
	})).filter((x) => Boolean(x));
	const results = (past?.events ?? []).map((e) => sdbFixture(e, {
		...def,
		logo: badge
	})).filter((x) => Boolean(x));
	const partial = rows.length > 0 && rows.length < 10;
	const failed = !table && !next && !past;
	const staleHit = peekCache(key);
	if (failed && staleHit) return {
		...staleHit,
		stale: true,
		error: "stale"
	};
	const payload = {
		...empty,
		logo: badge,
		updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
		partial,
		standings: rows,
		results: results.slice(0, 20),
		upcoming: upcoming.slice(0, 20),
		teams: rows.map((row) => clubFromRow(row, def)),
		noteAr: failed ? "تعذر الاتصال بـ TheSportsDB. لا توجد بيانات حديثة لعرضها." : partial ? "المصدر المجاني يعيد أعلى المراكز فقط (غالباً 5). هذا ليس الجدول الكامل، ولن نكمل المراكز الناقصة." : rows.length ? void 0 : "لا يتوفر جدول لهذه البطولة من المصدر المجاني حالياً. المباريات تُعرض إن وصلت.",
		noteEn: failed ? "Could not reach TheSportsDB. No fresh data to show." : partial ? "The free source returns only the top places (usually 5). This is not a full table, and missing places are not invented." : rows.length ? void 0 : "No table is available from the free source right now. Matches are shown if they arrived.",
		error: failed ? "upstream" : void 0
	};
	if (!failed) putCache(key, payload);
	return payload;
}
function olFixture(match, def) {
	const final = match.matchResults?.find((r) => r.resultTypeID === 2);
	const half = match.matchResults?.find((r) => r.resultTypeID === 1);
	const start = new Date(match.matchDateTime).getTime();
	const now = Date.now();
	const live = !match.matchIsFinished && start < now && now - start < 9e6;
	const score = final ?? (live ? half : void 0);
	const status = match.matchIsFinished ? "post" : live ? "in" : start > now ? "pre" : "pre";
	const side = (team, points) => ({
		id: `ol:${team.teamId}`,
		name: team.teamName,
		short: team.shortName || team.teamName.slice(0, 3),
		logo: team.teamIconUrl || null,
		score: status === "pre" || points === void 0 ? null : points
	});
	return {
		id: `ol:${match.matchID}`,
		leagueId: def.id,
		leagueNameAr: def.nameAr,
		leagueNameEn: def.nameEn,
		leagueLogo: def.logo,
		kickoff: new Date(match.matchDateTime).toISOString(),
		status,
		statusText: status === "post" ? "FT" : status === "in" ? "LIVE" : "Scheduled",
		venue: match.location?.locationStadium,
		source: "openliga",
		home: side(match.team1, score?.pointsTeam1),
		away: side(match.team2, score?.pointsTeam2)
	};
}
async function loadOpenLiga(def) {
	const year = openligaYear();
	const season = `${year}/${year + 1}`;
	const base = {
		id: def.id,
		nameAr: def.nameAr,
		nameEn: def.nameEn,
		countryAr: def.countryAr,
		countryEn: def.countryEn,
		region: def.region,
		logo: def.logo,
		source: "openliga",
		season,
		updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
		stale: false,
		partial: false,
		standings: [],
		results: [],
		upcoming: [],
		teams: [],
		scorers: [],
		assists: []
	};
	if (!def.openliga) return {
		...base,
		error: "missing",
		noteAr: "لا يوجد مصدر.",
		noteEn: "No source."
	};
	const key = `ol:${def.openliga}:${year}`;
	const fresh = fromCache(key, 3e5);
	if (fresh) return fresh;
	const [table, matches] = await Promise.all([getJSON(`${OL}/getbltable/${def.openliga}/${year}`), getJSON(`${OL}/getmatchdata/${def.openliga}/${year}`)]);
	if (!table && !matches) {
		const stale = peekCache(key);
		if (stale) return {
			...stale,
			stale: true,
			error: "stale"
		};
		return {
			...base,
			error: "upstream",
			noteAr: "تعذر جلب OpenLigaDB.",
			noteEn: "OpenLigaDB could not be reached."
		};
	}
	const standings = (table ?? []).map((row, index) => {
		const name = str(row.teamName);
		if (!name) return null;
		const gf = num(row.goals) ?? 0;
		const ga = num(row.opponentGoals) ?? 0;
		return {
			rank: index + 1,
			team: {
				id: `ol:${str(row.teamId)}`,
				name,
				short: str(row.shortName, name.slice(0, 3)),
				logo: str(row.teamIconUrl) || null
			},
			played: num(row.matches) ?? 0,
			won: num(row.won) ?? 0,
			draw: num(row.draw) ?? 0,
			lost: num(row.lost) ?? 0,
			gf,
			ga,
			gd: num(row.goalDiff) ?? gf - ga,
			pts: num(row.points) ?? 0
		};
	}).filter((r) => Boolean(r)).sort((a, b) => b.pts - a.pts || b.gd - a.gd || b.gf - a.gf).map((row, i) => ({
		...row,
		rank: i + 1
	}));
	const fixtures = (matches ?? []).map((m) => olFixture(m, def));
	const now = Date.now();
	const results = fixtures.filter((f) => f.status === "post" && new Date(f.kickoff).getTime() <= now).slice(-25).reverse();
	const upcoming = fixtures.filter((f) => f.status !== "post").slice(0, 25);
	const goals = /* @__PURE__ */ new Map();
	for (const match of matches ?? []) {
		if (!match.matchIsFinished) continue;
		for (const goal of match.goals ?? []) {
			if (goal.isOwnGoal || !goal.goalGetterName) continue;
			const id = `olg:${goal.goalGetterID}`;
			const team = goal.scoringTeamId === match.team1.teamId ? match.team1 : match.team2;
			const prev = goals.get(id);
			if (prev) prev.value += 1;
			else goals.set(id, {
				id,
				name: goal.goalGetterName,
				teamId: `ol:${team.teamId}`,
				teamName: team.teamName,
				teamLogo: team.teamIconUrl || null,
				value: 1,
				detail: "",
				kind: "goals"
			});
		}
	}
	const scorers = [...goals.values()].sort((a, b) => b.value - a.value).slice(0, 15).map((s) => ({
		...s,
		detail: `${s.value}`
	}));
	const payload = {
		...base,
		standings,
		results,
		upcoming,
		teams: standings.map((row) => clubFromRow(row, def)),
		scorers,
		assists: [],
		noteAr: def.id === "dfb" ? "كأس خروج المغلوب. ترتيب النقاط من المصدر مباشرة، والمباريات هي المرجع الأدق." : void 0,
		noteEn: def.id === "dfb" ? "Knockout cup. The points table comes straight from the source; fixtures are the better reference." : void 0
	};
	putCache(key, payload);
	putCache(`ol-matches:${def.openliga}:${year}`, matches ?? []);
	return payload;
}
function defNames(def) {
	return {
		ar: def.nameAr,
		en: def.nameEn,
		logo: def.logo,
		id: def.id,
		source: def.source
	};
}
async function loadEspnLeague(def) {
	const slug = def.espn;
	const key = `league:${def.id}`;
	const fresh = fromCache(key, 18e4);
	if (fresh) return fresh;
	const dir = await directory();
	const [table, board, leaders] = await Promise.all([
		espnStandings(slug),
		scoreboard(slug),
		espnLeaders(slug, def.id)
	]);
	const names = defNames(def);
	let upcoming = fixtureList(board, dir, names);
	const calendar = ((board?.leagues)?.[0]?.calendar ?? []).map((iso) => iso.slice(0, 10).replace(/-/g, "")).filter((d) => /^\d{8}$/.test(d));
	const today = /* @__PURE__ */ new Date();
	const todayKey = `${today.getFullYear()}${String(today.getMonth() + 1).padStart(2, "0")}${String(today.getDate()).padStart(2, "0")}`;
	const pastDates = calendar.filter((d) => d < todayKey).slice(-3);
	const results = (await Promise.all(pastDates.map((d) => scoreboard(slug, d)))).flatMap((json) => fixtureList(json, dir, names)).filter((f) => f.status === "post").sort((a, b) => b.kickoff.localeCompare(a.kickoff)).slice(0, 24);
	upcoming = upcoming.filter((f) => f.status !== "post").sort((a, b) => a.kickoff.localeCompare(b.kickoff));
	const standings = table.groups.flatMap((g) => g.rows);
	const teams = standings.map((row) => clubFromRow(row, def));
	if (!teams.length) {
		const rawTeams = (await getJSON(`${ESPN}/${slug}/teams?limit=40`))?.sports?.[0]?.leagues?.[0]?.teams ?? [];
		for (const wrap of rawTeams) {
			const team = wrap.team;
			teams.push({
				id: str(team.id),
				name: str(team.displayName, str(team.name, "Team")),
				short: str(team.abbreviation, "FC"),
				logo: team.logos?.[0]?.href ?? null,
				leagueId: def.id,
				leagueNameAr: def.nameAr,
				leagueNameEn: def.nameEn
			});
		}
	}
	const failed = !board && !standings.length;
	if (failed) {
		const stale = peekCache(key);
		if (stale) return {
			...stale,
			stale: true,
			error: "stale"
		};
	}
	const payload = {
		id: def.id,
		nameAr: def.nameAr,
		nameEn: def.nameEn,
		countryAr: def.countryAr,
		countryEn: def.countryEn,
		region: def.region,
		logo: def.logo,
		source: "espn",
		season: table.season || seasonLabel(def),
		updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
		stale: false,
		partial: false,
		standings,
		results,
		upcoming: upcoming.slice(0, 30),
		teams,
		scorers: leaders.scorers,
		assists: leaders.assists,
		noteAr: standings.length ? void 0 : "لا يتوفر جدول ترتيب من ESPN لهذه النسخة حالياً. المباريات المعروضة حقيقية.",
		noteEn: standings.length ? void 0 : "ESPN has no standings for this edition right now. Listed matches are real.",
		error: failed ? "upstream" : void 0
	};
	if (!failed) putCache(key, payload);
	return payload;
}
async function loadLeague(id) {
	const known = leagueById(id);
	if (known?.source === "sportsdb") return loadSportsDb(known);
	if (known?.source === "openliga") return loadOpenLiga(known);
	if (known?.source === "espn" && known.espn) return loadEspnLeague(known);
	if (id.startsWith("espn:")) {
		const slug = id.slice(5);
		const found = [...(await directory()).values()].find((item) => item.slug === slug);
		return loadEspnLeague({
			id,
			nameAr: found?.name ?? slug,
			nameEn: found?.name ?? slug,
			countryAr: "",
			countryEn: "",
			region: "world",
			source: "espn",
			espn: slug,
			seasonKind: "split",
			logo: found?.logo ?? null
		});
	}
	return {
		id,
		nameAr: id,
		nameEn: id,
		countryAr: "",
		countryEn: "",
		region: "world",
		logo: null,
		source: "espn",
		season: "",
		updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
		stale: false,
		partial: false,
		standings: [],
		results: [],
		upcoming: [],
		teams: [],
		scorers: [],
		assists: [],
		error: "unknown",
		noteAr: "البطولة غير معرّفة.",
		noteEn: "Unknown competition."
	};
}
async function featuredSlates() {
	const ids = [
		"eng.1",
		"esp.1",
		"ita.1",
		"ger.1",
		"ksa.1",
		"uefa.champions",
		"caf.champions",
		"fra.1"
	];
	const dir = await directory();
	return (await Promise.all(ids.map(async (id) => {
		const def = leagueById(id);
		if (!def?.espn) return [];
		return fixtureList(await scoreboard(def.espn), dir, defNames(def)).filter((f) => f.status !== "post").slice(0, 4);
	}))).flat().sort((a, b) => a.kickoff.localeCompare(b.kickoff)).slice(0, 24);
}
async function loadHome(input) {
	const key = `home:${input.today}`;
	const cached = fromCache(key, 75e3);
	if (cached) return cached;
	try {
		const [today, tomorrow, upcoming, news, engTable, ksaTable, egyTable] = await Promise.all([
			dayFixtures(input.today),
			dayFixtures(input.tomorrow),
			featuredSlates(),
			espnNews([
				"eng.1",
				"esp.1",
				"ksa.1",
				"uefa.champions"
			]),
			espnStandings("eng.1"),
			espnStandings("ksa.1"),
			sdb(`lookuptable.php?l=4829&s=${seasonLabel(leagueById("egy"))}`)
		]);
		const live = [...today, ...tomorrow].filter((m) => m.status === "in");
		const pack = (id, table, partial = false) => {
			const def = leagueById(id);
			return {
				leagueId: id,
				nameAr: def.nameAr,
				nameEn: def.nameEn,
				season: table.season || seasonLabel(def),
				partial,
				rows: (table.groups[0]?.rows ?? []).slice(0, 6)
			};
		};
		const egyRows = (egyTable?.table ?? []).map((row) => {
			const name = str(row.strTeam);
			if (!name) return null;
			const gf = num(row.intGoalsFor) ?? 0;
			const ga = num(row.intGoalsAgainst) ?? 0;
			return {
				rank: num(row.intRank) ?? 0,
				team: {
					id: `sdb:${str(row.idTeam, name)}`,
					name,
					short: name.slice(0, 3).toUpperCase(),
					logo: str(row.strTeamBadge || row.strBadge) || null
				},
				played: num(row.intPlayed) ?? 0,
				won: num(row.intWin) ?? 0,
				draw: num(row.intDraw) ?? 0,
				lost: num(row.intLoss) ?? 0,
				gf,
				ga,
				gd: num(row.intGoalDifference) ?? gf - ga,
				pts: num(row.intPoints) ?? 0
			};
		}).filter((r) => Boolean(r));
		const tables = [
			pack("eng.1", engTable),
			pack("ksa.1", ksaTable),
			{
				leagueId: "egy",
				nameAr: "الدوري المصري",
				nameEn: "Egyptian Premier League",
				season: seasonLabel(leagueById("egy")),
				partial: egyRows.length > 0 && egyRows.length < 10,
				rows: egyRows.slice(0, 6)
			}
		].filter((table) => table.rows.length);
		const payload = {
			updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
			stale: false,
			today,
			tomorrow,
			live,
			upcoming,
			news,
			tables
		};
		putCache(key, payload);
		return payload;
	} catch {
		const stale = peekCache(key);
		if (stale) return {
			...stale,
			stale: true,
			error: "stale"
		};
		return {
			updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
			stale: true,
			today: [],
			tomorrow: [],
			live: [],
			upcoming: [],
			news: [],
			tables: [],
			error: "upstream"
		};
	}
}
async function loadBoard(dates) {
	const clean = dates.filter((d) => /^\d{8}$/.test(d)).slice(0, 7);
	try {
		const groups = await Promise.all(clean.map((d) => dayFixtures(d)));
		const seen = /* @__PURE__ */ new Set();
		const matches = groups.flat().filter((m) => {
			if (seen.has(m.id)) return false;
			seen.add(m.id);
			return true;
		});
		return {
			updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
			stale: false,
			matches
		};
	} catch {
		return {
			updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
			stale: true,
			matches: [],
			error: "upstream"
		};
	}
}
function headshot(id) {
	return `https://a.espncdn.com/i/headshots/soccer/players/full/${id}.png`;
}
async function loadTeam(leagueId, teamId) {
	const league = await loadLeague(leagueId);
	const club = league.teams.find((t) => t.id === teamId) ?? {
		id: teamId,
		name: teamId,
		short: "FC",
		logo: null,
		leagueId,
		leagueNameAr: league.nameAr,
		leagueNameEn: league.nameEn
	};
	const row = league.standings.find((r) => r.team.id === teamId);
	const matches = [...league.results, ...league.upcoming].filter((m) => m.home.id === teamId || m.away.id === teamId).sort((a, b) => a.kickoff.localeCompare(b.kickoff));
	const base = {
		club: row ? {
			...club,
			logo: club.logo || row.team.logo,
			name: row.team.name,
			short: row.team.short
		} : club,
		updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
		stale: league.stale,
		row,
		matches,
		squad: [],
		noteAr: league.noteAr,
		noteEn: league.noteEn
	};
	const def = leagueById(leagueId);
	if (!def?.espn || teamId.startsWith("sdb:") || teamId.startsWith("ol:")) {
		if (!matches.length && !row) {
			base.noteAr = "بيانات هذا النادي محدودة في المصدر المجاني.";
			base.noteEn = "This club has limited data on the free source.";
		}
		return base;
	}
	const [roster, schedule, info] = await Promise.all([
		getJSON(`${ESPN}/${def.espn}/teams/${teamId}/roster`),
		getJSON(`${ESPN}/${def.espn}/teams/${teamId}/schedule`),
		getJSON(`${ESPN}/${def.espn}/teams/${teamId}`)
	]);
	const teamInfo = info?.team;
	if (teamInfo) {
		base.club.record = str(teamInfo.record?.items?.[0]?.summary) || void 0;
		base.club.standing = str(teamInfo.standingSummary) || void 0;
		const next = teamInfo.nextEvent?.[0]?.name;
		base.club.next = next;
		const logos = teamInfo.logos;
		base.club.logo = logos?.[0]?.href ?? base.club.logo;
		base.club.name = str(teamInfo.displayName, base.club.name);
		base.club.short = str(teamInfo.abbreviation, base.club.short);
	}
	const goals = new Map(league.scorers.map((s) => [s.id, s.value]));
	const assists = new Map(league.assists.map((s) => [s.id, s.value]));
	base.squad = (roster?.athletes ?? []).map((athlete) => {
		const id = str(athlete.id);
		const pos = athlete.position;
		return {
			id,
			name: str(athlete.displayName, "Player"),
			teamId,
			teamName: base.club.name,
			teamLogo: base.club.logo,
			position: pos?.displayName || pos?.abbreviation || "",
			jersey: str(athlete.jersey),
			age: num(athlete.age) ?? void 0,
			nationality: str(athlete.citizenship) || void 0,
			leagueId,
			goals: goals.get(id),
			assists: assists.get(id),
			headshot: headshot(id)
		};
	});
	if (schedule?.events?.length) {
		const dir = await directory();
		const extra = schedule.events.map((event) => espnFixture(event, dir, defNames(def))).filter((x) => Boolean(x));
		const seen = new Set(base.matches.map((m) => m.id));
		for (const fixture of extra) if (!seen.has(fixture.id)) base.matches.push(fixture);
		base.matches.sort((a, b) => a.kickoff.localeCompare(b.kickoff));
	}
	if (!base.squad.length) {
		base.noteAr = base.noteAr ?? "قائمة اللاعبين غير متاحة من المصدر لهذا النادي.";
		base.noteEn = base.noteEn ?? "The squad list is not available from the source for this club.";
	}
	return base;
}
function timelineFrom(events) {
	return events.slice(0, 40).map((event) => {
		const type = event.type;
		const clock = event.clock;
		const team = event.team;
		const who = event.athletesInvolved?.[0]?.displayName;
		const label = [
			type?.text,
			who,
			str(event.text)
		].filter(Boolean).join(" · ");
		return {
			minute: clock?.displayValue || "",
			text: label || "Event",
			team: team?.displayName,
			scoring: Boolean(event.scoringPlay)
		};
	});
}
async function loadMatch(leagueId, eventId) {
	const league = await loadLeague(leagueId);
	const found = [...league.upcoming, ...league.results].find((m) => m.id === eventId) ?? null;
	const payload = {
		match: found ?? {
			id: eventId,
			leagueId,
			leagueNameAr: league.nameAr,
			leagueNameEn: league.nameEn,
			leagueLogo: league.logo,
			kickoff: (/* @__PURE__ */ new Date()).toISOString(),
			status: "pre",
			statusText: "",
			source: league.source,
			home: {
				id: "",
				name: "—",
				short: "—",
				logo: null,
				score: null
			},
			away: {
				id: "",
				name: "—",
				short: "—",
				logo: null,
				score: null
			}
		},
		updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
		stale: league.stale,
		stats: [],
		timeline: [],
		h2h: []
	};
	const def = leagueById(leagueId);
	if (def?.espn && !eventId.startsWith("sdb:") && !eventId.startsWith("ol:")) {
		const summary = await getJSON(`${ESPN}/${def.espn}/summary?event=${eventId}`);
		if (summary) {
			const comp = summary.header?.competitions?.[0];
			if (comp) {
				const dir = await directory();
				const fx = espnFixture({
					...comp,
					id: eventId,
					competitions: [comp],
					uid: comp.uid
				}, dir, defNames(def));
				if (fx) payload.match = {
					...fx,
					id: eventId,
					leagueId: def.id
				};
			}
			const teams = summary.boxscore?.teams ?? [];
			const home = teams.find((t) => t.homeAway === "home") ?? teams[0];
			const away = teams.find((t) => t.homeAway === "away") ?? teams[1];
			const stats = [];
			const homeStats = home?.statistics ?? [];
			const awayStats = away?.statistics ?? [];
			const awayMap = new Map(awayStats.map((s) => [s.name, s.displayValue ?? ""]));
			for (const stat of homeStats) {
				if (!stat.name) continue;
				stats.push({
					label: stat.label || stat.name,
					home: stat.displayValue || "—",
					away: awayMap.get(stat.name) || "—"
				});
			}
			payload.stats = stats.slice(0, 14);
			payload.timeline = timelineFrom(summary.keyEvents ?? []);
			const series = summary.seasonseries?.[0];
			payload.h2hSummary = str(series?.summary) || void 0;
			const seriesEvents = series?.events ?? [];
			const dir = await directory();
			payload.h2h = seriesEvents.map((event) => espnFixture(event, dir, defNames(def))).filter((x) => Boolean(x)).slice(0, 6);
		} else if (!found) {
			payload.error = "missing";
			payload.noteAr = "تعذر جلب تفاصيل المباراة.";
			payload.noteEn = "Match details could not be loaded.";
		}
		return payload;
	}
	if (def?.openliga && eventId.startsWith("ol:")) {
		const year = openligaYear();
		const match = (peekCache(`ol-matches:${def.openliga}:${year}`) ?? []).find((m) => `ol:${m.matchID}` === eventId);
		if (match) {
			payload.match = olFixture(match, def);
			payload.timeline = (match.goals ?? []).map((goal) => ({
				minute: `${goal.matchMinute}'`,
				text: `${goal.goalGetterName}${goal.isOwnGoal ? " (OG)" : ""}`,
				team: goal.scoringTeamId === match.team1.teamId ? match.team1.teamName : match.team2.teamName,
				scoring: true
			}));
		}
		payload.noteAr = "إحصائيات الاستحواذ غير متوفرة في OpenLigaDB.";
		payload.noteEn = "Possession stats are not provided by OpenLigaDB.";
	}
	if (!payload.match.home.name || payload.match.home.name === "—") {
		payload.noteAr = payload.noteAr ?? "التفاصيل المتقدمة غير متاحة لهذه المباراة من المصدر.";
		payload.noteEn = payload.noteEn ?? "Advanced details are not available for this match.";
	}
	return payload;
}
async function loadPlayer(leagueId, playerId, teamId) {
	const league = await loadLeague(leagueId);
	const scorer = [...league.scorers, ...league.assists].find((s) => s.id === playerId);
	if (teamId && leagueById(leagueId)?.espn && !playerId.startsWith("olg:")) {
		const found = (await loadTeam(leagueId, teamId)).squad.find((p) => p.id === playerId);
		if (found) return {
			player: {
				...found,
				goals: found.goals ?? (scorer?.kind === "goals" ? scorer.value : void 0),
				assists: found.assists ?? league.assists.find((s) => s.id === playerId)?.value
			},
			updatedAt: (/* @__PURE__ */ new Date()).toISOString()
		};
	}
	if (scorer) return {
		player: {
			id: scorer.id,
			name: scorer.name,
			teamId: scorer.teamId,
			teamName: scorer.teamName,
			teamLogo: scorer.teamLogo,
			position: "",
			jersey: scorer.jersey ?? "",
			leagueId,
			goals: league.scorers.find((s) => s.id === playerId)?.value,
			assists: league.assists.find((s) => s.id === playerId)?.value,
			headshot: playerId.startsWith("olg:") || playerId.startsWith("sdb:") ? null : headshot(playerId)
		},
		updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
		noteAr: "المعروض هو ما وفره المصدر فقط (أهداف/صناعات). لا تُخترع إحصائيات إضافية.",
		noteEn: "Only stats the source actually provided (goals/assists) are shown."
	};
	return {
		player: {
			id: playerId,
			name: "Player",
			teamId: teamId ?? "",
			teamName: "",
			teamLogo: null,
			position: "",
			jersey: "",
			leagueId,
			headshot: null
		},
		updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
		error: "missing",
		noteAr: "لا تتوفر بطاقة لهذا اللاعب في البيانات الحالية.",
		noteEn: "No player card is available in the current data."
	};
}
async function loadH2H(leagueId, teamA, teamB) {
	const [a, b] = await Promise.all([loadTeam(leagueId, teamA), loadTeam(leagueId, teamB)]);
	const matches = a.matches.filter((m) => m.home.id === teamB || m.away.id === teamB);
	const extra = b.matches.filter((m) => (m.home.id === teamA || m.away.id === teamA) && !matches.some((x) => x.id === m.id));
	const all = [...matches, ...extra].sort((x, y) => y.kickoff.localeCompare(x.kickoff)).slice(0, 8);
	return {
		matches: all,
		noteAr: all.length ? "مواجهات وجدت داخل مباريات المصدر المحمّلة، وليست أرشيفاً كاملاً لكل العصور." : "لا توجد مواجهات سابقة داخل المباريات المتاحة من المصدر.",
		noteEn: all.length ? "Meetings found inside loaded source fixtures, not a complete all-time archive." : "No previous meetings inside the fixtures available from the source."
	};
}
async function searchAll(query) {
	const q = query.trim();
	if (q.length < 2) return [];
	const local = LEAGUES.filter((l) => `${l.nameAr} ${l.nameEn} ${l.countryAr} ${l.countryEn}`.toLowerCase().includes(q.toLowerCase())).map((l) => ({
		kind: "league",
		id: l.id,
		title: l.nameEn,
		subtitle: l.countryEn,
		logo: l.logo
	}));
	const json = await getJSON(`https://site.api.espn.com/apis/common/v3/search?query=${encodeURIComponent(q)}&limit=8`);
	const remote = [];
	for (const item of json?.items ?? []) {
		if (item.sport && item.sport !== "soccer") continue;
		const type = str(item.type);
		if (type === "team") {
			const slug = str(item.defaultLeagueSlug || item.league);
			const league = leagueByEspn(slug);
			remote.push({
				kind: "team",
				id: str(item.id),
				leagueId: league?.id ?? (slug ? `espn:${slug}` : void 0),
				title: str(item.displayName),
				subtitle: league?.nameEn ?? slug,
				logo: `https://a.espncdn.com/i/teamlogos/soccer/500/${str(item.id)}.png`
			});
		} else if (type === "athlete" || type === "player") remote.push({
			kind: "player",
			id: str(item.id),
			leagueId: leagueByEspn(str(item.defaultLeagueSlug || item.league))?.id,
			title: str(item.displayName),
			subtitle: str(item.position) || "Player",
			logo: headshot(str(item.id))
		});
	}
	const seen = /* @__PURE__ */ new Set();
	return [...local, ...remote].filter((hit) => {
		const key = `${hit.kind}:${hit.id}`;
		if (seen.has(key)) return false;
		seen.add(key);
		return Boolean(hit.title);
	}).slice(0, 16);
}
function predictNote(lang) {
	return lang === "ar" ? "هذا توقع إحصائي مبني على الأهداف والترتيب الحالي فقط، وليس نتيجة مؤكدة." : "This is a statistical estimate from current goals and the table only, not a confirmed result.";
}
async function answerQuestion(input) {
	const today = /^\d{8}$/.test(input.today) ? input.today : `${(/* @__PURE__ */ new Date()).getFullYear()}${String((/* @__PURE__ */ new Date()).getMonth() + 1).padStart(2, "0")}${String((/* @__PURE__ */ new Date()).getDate()).padStart(2, "0")}`;
	const home = await loadHome({
		today,
		tomorrow: today
	});
	const q = input.question.toLowerCase();
	const matched = LEAGUES.find((l) => q.includes(l.nameEn.toLowerCase()) || input.question.includes(l.nameAr) || q.includes(l.id));
	const league = matched ? await loadLeague(matched.id) : null;
	const lines = [];
	lines.push(`Clock data time: ${home.updatedAt}`);
	lines.push("Today fixtures: " + (home.today.slice(0, 14).map((m) => `${m.home.name} ${m.home.score ?? "-"}-${m.away.score ?? "-"} ${m.away.name} (${m.statusText}, ${m.leagueNameEn})`).join("; ") || "none in the aggregated scoreboard"));
	lines.push("Live: " + (home.live.map((m) => `${m.home.name} ${m.home.score}-${m.away.score} ${m.away.name}`).join("; ") || "none"));
	if (league) {
		lines.push(`${league.nameEn} season ${league.season}: ` + league.standings.slice(0, 10).map((r) => `${r.rank}. ${r.team.name} ${r.pts}pts GD ${r.gd}`).join("; "));
		lines.push("Next: " + league.upcoming.slice(0, 6).map((m) => `${m.home.name} vs ${m.away.name} ${m.kickoff}`).join("; "));
		if (league.partial) lines.push("NOTE: table is partial from a free source, not the full league.");
	} else if (home.tables[0]) {
		const table = home.tables[0];
		lines.push(`${table.nameEn}: ` + table.rows.map((r) => `${r.rank} ${r.team.name} ${r.pts}`).join(", "));
	}
	const facts = lines.join("\n").slice(0, 6e3);
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		text: fallbackAnswer(input.lang, home, league),
		basedOn: "live",
		updatedAt: home.updatedAt
	};
	const langLine = input.lang === "ar" ? "أجب بالعربية." : "Answer in English.";
	try {
		const res = await fetch("https://api.x.ai/v1/chat/completions", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${apiKey}`
			},
			body: JSON.stringify({
				model: "grok-4.5",
				max_tokens: 450,
				temperature: .2,
				messages: [{
					role: "system",
					content: "You are the FOOTBALL AI PRO analyst. Use ONLY the facts in the user message. Never invent scores, tables, injuries, or lineups. If data is missing, say so. Label any forecast clearly as a prediction, separate from facts. " + langLine
				}, {
					role: "user",
					content: `FACTS:\n${facts}\n\nQUESTION:\n${input.question}`
				}]
			})
		});
		if (!res.ok) return {
			text: fallbackAnswer(input.lang, home, league),
			basedOn: "live",
			updatedAt: home.updatedAt
		};
		const text = (await res.json()).choices?.[0]?.message?.content?.trim();
		if (!text) return {
			text: fallbackAnswer(input.lang, home, league),
			basedOn: "live",
			updatedAt: home.updatedAt
		};
		return {
			text,
			basedOn: "live",
			updatedAt: home.updatedAt
		};
	} catch {
		return {
			text: fallbackAnswer(input.lang, home, league),
			basedOn: "live",
			updatedAt: home.updatedAt
		};
	}
}
function fallbackAnswer(lang, home, league) {
	if (lang === "en") {
		const live = home.live[0];
		const top = league?.standings[0] ?? home.tables[0]?.rows[0];
		return [
			live ? `Live: ${live.home.name} ${live.home.score}-${live.away.score} ${live.away.name}.` : "No live match in the current feed.",
			top ? `Table leader sample: ${top.team.name}, ${top.pts} pts.` : "No table loaded.",
			`${home.today.length} matches on today's scoreboard.`,
			predictNote("en")
		].join(" ");
	}
	const live = home.live[0];
	const top = league?.standings[0] ?? home.tables[0]?.rows[0];
	return [
		live ? `مباشر الآن: ${live.home.name} ${live.home.score}-${live.away.score} ${live.away.name}.` : "لا توجد مباراة مباشرة في التغذية الحالية.",
		top ? `متصدر العينة: ${top.team.name} برصيد ${top.pts} نقطة.` : "لا يوجد ترتيب محمّل.",
		`مباريات اليوم في اللوحة: ${home.today.length}.`,
		predictNote("ar")
	].join(" ");
}
//#endregion
export { answerQuestion, loadBoard, loadH2H, loadHome, loadLeague, loadMatch, loadPlayer, loadTeam, searchAll };
