import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Route$3 } from "./router-DCIqO0dN.mjs";
import { t as AlertOverlay } from "./panels-aiwxz-g9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/alert-B17NrR7W.js
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertOverlay, { look: Route$3.useSearch() });
}
//#endregion
export { Page as component };
