import { o as __toESM } from "../_runtime.mjs";
import { Z as require_react, b as Link, p as useRouterState, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as hasGateSessionMarker } from "./server-CMqOSf10.mjs";
import { S as Clapperboard, T as AudioLines, d as Plus, h as House, m as ImagePlus, n as X, r as Users, u as Search } from "../_libs/lucide-react.mjs";
import { r as signOut } from "./client-BhcLuWvF.mjs";
import { n as POST_KINDS, t as HOME_KINDS } from "./model-Ck66RVeO.mjs";
import { A as useCurrentUserState, C as primaryBtn, d as createPost, h as getMe, i as LoginScreen, k as useCurrentUser, l as Splash, m as fieldClass, o as Onboard, w as quietBtn } from "./auth-screens-DZe0plYT.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shell-DSe4icyb.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var useSalon = create((set) => ({
	tick: 0,
	bump: () => set((s) => ({ tick: s.tick + 1 })),
	compose: { open: false },
	openCompose: (opts) => set({ compose: {
		open: true,
		kind: opts?.kind,
		group: opts?.group ?? null
	} }),
	closeCompose: () => set({ compose: { open: false } })
}));
var subscribeToNothing = () => () => {};
var noGateSessionOnServer = () => false;
/**
* Minimal signed-in identity chip + sign-out. Restyle freely (see the
* `design-ui` skill). Sign-out is only shown when auth is enabled (the
* disabled-auth dev user has nothing to sign out of) and the session is not
* gate-materialized — behind the gate the next request signs the viewer
* straight back in, so a sign-out control there is a broken loop.
*/
function UserButton() {
	const user = useCurrentUser();
	const [signingOut, setSigningOut] = (0, import_react.useState)(false);
	const gateSession = (0, import_react.useSyncExternalStore)(subscribeToNothing, hasGateSessionMarker, noGateSessionOnServer);
	if (!user) return null;
	const label = user.displayName ?? user.primaryEmail ?? "Account";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2",
		children: [
			user.profileImageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: user.profileImageUrl,
				alt: "",
				className: "h-8 w-8 rounded-full object-cover"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid h-8 w-8 place-items-center rounded-full bg-black/10 text-sm font-medium dark:bg-white/20",
				children: label.charAt(0).toUpperCase()
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-medium",
				children: label
			}),
			!gateSession && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				disabled: signingOut,
				onClick: () => {
					setSigningOut(true);
					signOut().catch(() => setSigningOut(false));
				},
				className: "cursor-pointer text-sm underline-offset-4 opacity-70 hover:underline disabled:cursor-wait disabled:no-underline",
				children: signingOut ? "Signing out…" : "Sign out"
			})
		]
	});
}
async function compressImage(file, maxEdge, maxChars) {
	if (!file.type.startsWith("image/")) throw new Error("الملف ليس صورة");
	const bitmap = await createImageBitmap(file);
	try {
		let edge = maxEdge;
		let quality = .86;
		let last = "";
		for (let i = 0; i < 7; i += 1) {
			const scale = Math.min(1, edge / Math.max(bitmap.width, bitmap.height));
			const w = Math.max(1, Math.round(bitmap.width * scale));
			const h = Math.max(1, Math.round(bitmap.height * scale));
			const canvas = document.createElement("canvas");
			canvas.width = w;
			canvas.height = h;
			const ctx = canvas.getContext("2d");
			if (!ctx) throw new Error("تعذر معالجة الصورة");
			ctx.fillStyle = "#fffdfb";
			ctx.fillRect(0, 0, w, h);
			ctx.drawImage(bitmap, 0, 0, w, h);
			last = canvas.toDataURL("image/jpeg", quality);
			if (last.length <= maxChars) return last;
			quality = Math.max(.42, quality - .1);
			edge = Math.round(edge * .82);
		}
		if (last.length <= maxChars) return last;
		throw new Error("الصورة كبيرة حتى بعد الضغط");
	} finally {
		bitmap.close();
	}
}
function Composer({ groups }) {
	const compose = useSalon((s) => s.compose);
	const close = useSalon((s) => s.closeCompose);
	const bump = useSalon((s) => s.bump);
	const [kind, setKind] = (0, import_react.useState)("vent");
	const [title, setTitle] = (0, import_react.useState)("");
	const [body, setBody] = (0, import_react.useState)("");
	const [link, setLink] = (0, import_react.useState)("");
	const [media, setMedia] = (0, import_react.useState)(null);
	const [groupSlug, setGroupSlug] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	const [pending, setPending] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!compose.open) return;
		setKind(compose.kind ?? "vent");
		setGroupSlug(compose.group ?? "");
		setTitle("");
		setBody("");
		setLink("");
		setMedia(null);
		setError(null);
	}, [
		compose.open,
		compose.kind,
		compose.group
	]);
	if (!compose.open) return null;
	const kinds = compose.kind === "reel" || compose.kind === "subliminal" ? [compose.kind] : [...HOME_KINDS];
	const needsTitle = kind === "contest" || kind === "news" || kind === "subliminal";
	const needsImage = kind === "reel" || kind === "subliminal";
	async function onFile(file) {
		if (!file) return;
		setError(null);
		try {
			const data = await compressImage(file, kind === "reel" ? 1080 : 1400, kind === "reel" ? 5e5 : 4e5);
			setMedia(data);
		} catch (err) {
			setError(err instanceof Error ? err.message : "تعذر قراءة الصورة");
		}
	}
	async function onSubmit(event) {
		event.preventDefault();
		setPending(true);
		setError(null);
		try {
			const result = await createPost({ data: {
				kind,
				title,
				body,
				link,
				media,
				groupSlug: groupSlug || null
			} });
			if (!result.ok) {
				setError(result.error);
				return;
			}
			close();
			bump();
		} catch (err) {
			setError(err instanceof Error ? err.message : "تعذر النشر");
		} finally {
			setPending(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 grid place-items-end bg-ink/40 p-3 md:place-items-center",
		role: "presentation",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit,
			className: "max-h-dvh w-full max-w-lg overflow-y-auto rounded-3xl bg-paper p-5 shadow-lift",
			role: "dialog",
			"aria-labelledby": "compose-title",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-widest text-rose",
							children: "نشر"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							id: "compose-title",
							className: "font-display text-3xl",
							children: POST_KINDS[kind].label
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-mute",
							children: [POST_KINDS[kind].hint, ". يظهر للجميع."]
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-11 place-items-center rounded-full bg-ivory",
						onClick: close,
						"aria-label": "إغلاق",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 flex flex-wrap gap-2",
					children: kinds.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setKind(item),
						className: `min-h-11 rounded-full px-4 text-sm ${kind === item ? "bg-rose text-paper" : "bg-ivory text-ink"}`,
						children: POST_KINDS[item].label
					}, item))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 space-y-3",
					children: [
						needsTitle ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: `${fieldClass} h-12`,
							placeholder: kind === "contest" ? "سؤال المسابقة" : "العنوان",
							value: title,
							onChange: (e) => setTitle(e.target.value)
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							className: `${fieldClass} min-h-32 py-3`,
							placeholder: kind === "subliminal" ? "وصف السيبلمنال" : kind === "reel" ? "تعليق اختياري على الميم" : "اكتب هنا",
							value: body,
							onChange: (e) => setBody(e.target.value)
						}),
						kind === "subliminal" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: `${fieldClass} h-12`,
							dir: "ltr",
							placeholder: "https://youtube.com/watch?v=…",
							value: link,
							onChange: (e) => setLink(e.target.value)
						}) : null,
						needsImage ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex min-h-24 cursor-pointer flex-col items-center justify-center gap-2 rounded-3xl bg-ivory text-sm text-mute",
							children: [media ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: media,
								alt: "",
								className: "max-h-56 w-full rounded-3xl object-cover"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "size-5" }), kind === "reel" ? "صورة الميم أو الريل" : "غلاف اختياري"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "file",
								accept: "image/*",
								className: "sr-only",
								onChange: (e) => void onFile(e.target.files?.[0])
							})]
						}) : null,
						groups.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block space-y-1.5 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-mute",
								children: "أين يُنشر"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: `${fieldClass} h-12`,
								value: groupSlug,
								onChange: (e) => setGroupSlug(e.target.value),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "الساحة العامة"
								}), groups.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: group.slug,
									children: group.name
								}, group.slug))]
							})]
						}) : null,
						error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-rose",
							children: error
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: primaryBtn,
								type: "submit",
								disabled: pending,
								children: pending ? "يُنشر…" : "نشر"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: quietBtn,
								type: "button",
								onClick: close,
								children: "إلغاء"
							})]
						})
					]
				})
			]
		})
	});
}
var NAV = [
	{
		to: "/",
		label: "الساحة",
		icon: House
	},
	{
		to: "/reels",
		label: "ريلز",
		icon: Clapperboard
	},
	{
		to: "/subliminals",
		label: "سيبلمنال",
		icon: AudioLines
	},
	{
		to: "/groups",
		label: "المجموعات",
		icon: Users
	},
	{
		to: "/search",
		label: "بحث",
		icon: Search
	}
];
function Shell$1({ children }) {
	const { user, isPending } = useCurrentUserState();
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Splash, {});
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoginScreen, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Authed, { children });
}
function Authed({ children }) {
	const tick = useSalon((s) => s.tick);
	const [me, setMe] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let live = true;
		getMe().then((result) => {
			if (live) {
				setMe(result);
				setError(null);
			}
		}).catch((err) => {
			if (live) setError(err instanceof Error ? err.message : "تعذر التحميل");
		});
		return () => {
			live = false;
		};
	}, [tick]);
	if (error === "Unauthorized") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoginScreen, {});
	if (error) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-dvh place-items-center px-6 text-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl",
			children: "تعذر فتح الصالون"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-mute",
			children: error
		})] })
	});
	if (!me) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Splash, { label: "نقرأ بطاقتك" });
	if (!me.profile) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Onboard, {
		me,
		onDone: () => useSalon.getState().bump()
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, {
		me,
		children
	});
}
function Frame({ me, children }) {
	const path = useRouterState({ select: (s) => s.location.pathname });
	const openCompose = useSalon((s) => s.openCompose);
	const profile = me.profile;
	if (!profile) return null;
	const joined = me.groups.filter((group) => group.joined);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid min-h-dvh w-full max-w-6xl grid-cols-1 md:grid-cols-[15rem_minmax(0,1fr)] xl:grid-cols-[15rem_minmax(0,1fr)_17rem]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "sticky top-0 z-20 hidden h-dvh flex-col gap-6 px-4 py-6 md:flex",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						className: "px-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-widest text-rose",
							children: "SALON"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-3xl leading-none",
							children: "CUTEGIRLS"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "flex flex-col gap-1",
						children: [NAV.map((item) => {
							const active = item.to === "/" ? path === "/" : path.startsWith(item.to);
							const Icon = item.icon;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: item.to,
								className: `flex min-h-11 items-center gap-3 rounded-2xl px-3 text-sm ${active ? "bg-paper font-medium text-ink shadow-card" : "text-mute hover:bg-paper/70"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
									className: "size-4",
									strokeWidth: 1.75
								}), item.label]
							}, item.to);
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "mt-3 inline-flex min-h-11 items-center justify-center gap-2 rounded-full bg-rose px-4 text-sm font-medium text-paper",
							onClick: () => openCompose(),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "نشر"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-auto space-y-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/u/$username",
							params: { username: profile.username },
							className: "block truncate px-2 text-sm",
							children: ["@", profile.username]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserButton, {})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 px-4 pb-28 pt-4 md:px-2 md:pb-10 md:pt-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 flex items-center justify-between md:hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "font-display text-2xl",
						children: "CUTEGIRLS"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/search",
							search: { q: "" },
							"aria-label": "بحث",
							className: "grid size-11 place-items-center text-ink",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/u/$username",
							params: { username: profile.username },
							className: "text-sm text-rose",
							children: "حسابي"
						})]
					})]
				}), children]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "sticky top-0 hidden h-dvh flex-col gap-4 px-4 py-6 xl:flex",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/search",
						search: { q: "" },
						className: "flex min-h-11 items-center rounded-full bg-paper px-4 text-sm text-mute shadow-card",
						children: "بحث عن حساب"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-3xl bg-paper p-4 shadow-card",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-xl",
							children: "غرفك"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-3 space-y-2",
							children: joined.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/groups/$slug",
								params: { slug: group.slug },
								className: "flex min-h-11 items-center justify-between gap-2 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "truncate",
									children: group.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "tabular-nums text-mute",
									children: group.members
								})]
							}) }, group.slug))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-1 text-xs leading-6 text-mute",
						children: "المنشورات ظاهرة لكل من في الصالون. اسمك على البطاقة هو اسم قناتك."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-30 border-t border-ink/10 bg-paper/95 px-2 pt-1 pb-2 backdrop-blur md:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto grid max-w-lg grid-cols-5",
					children: [
						NAV.slice(0, 2).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavIcon, {
							item,
							path
						}, item.to)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "grid place-items-center",
							onClick: () => openCompose(),
							"aria-label": "نشر",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid size-11 place-items-center rounded-full bg-rose text-paper",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-5" })
							})
						}),
						NAV.slice(2, 4).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavIcon, {
							item,
							path
						}, item.to))
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Composer, { groups: joined })
		]
	});
}
function NavIcon({ item, path }) {
	const active = item.to === "/" ? path === "/" : path.startsWith(item.to);
	const Icon = item.icon;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: item.to,
		className: `grid min-h-12 place-items-center ${active ? "text-rose" : "text-mute"}`,
		"aria-label": item.label,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
			className: "size-5",
			strokeWidth: 1.75
		})
	});
}
//#endregion
export { useSalon as i, UserButton as n, compressImage as r, Shell$1 as t };
