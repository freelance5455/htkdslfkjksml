import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as Library, n as SquareCheckBig, o as BookOpenText, r as Signpost } from "../_libs/lucide-react.mjs";
import { a as useStudy, o as CREDIT } from "./router-C-xQh0iG.mjs";
import { t as CHAPTERS } from "./curriculum-BHBVcVfN.mjs";
import { t as QUESTIONS } from "./quiz-C2Kzqaia.mjs";
import { n as SIGNS } from "./signs-CNNmKTo_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-C_CuP85G.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const read = useStudy((s) => s.read.length);
	const learned = useStudy((s) => s.learned.length);
	const best = useStudy((s) => s.best);
	const exams = useStudy((s) => s.exams);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "border-b border-line pb-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-primary",
						children: "Teoria della patente B"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 text-4xl font-semibold leading-tight md:text-5xl",
						children: "الرخصة الإيطالية"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-2xl text-lg leading-relaxed text-muted",
						children: "المنهج كله بالإيطالي، وتحته المعنى بالعربي. الإشارات مرسومة باسمها وشرحها، وأسئلة صح أو خطأ على طريقة الامتحان. اضغط أي كلمة إيطالية إذا أردت معناها أو سؤالاً عنها."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-base font-semibold",
						children: CREDIT
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid grid-cols-3 gap-2 rounded-2xl border border-line bg-surface p-3 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						n: "30",
						label: "سؤالًا"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						n: "20",
						label: "دقيقة"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						n: "3",
						label: "أخطاء كحد أقصى"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Door, {
						to: "/manuale",
						icon: BookOpenText,
						kicker: "25 فصلًا",
						title: "المنهج",
						text: "من تعريفات الطريق حتى الإطارات والكحول والحوادث."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Door, {
						to: "/segnali",
						icon: Signpost,
						kicker: `${SIGNS.length} إشارة`,
						title: "الإشارات",
						text: "خطر، منع، إلزام، أولوية، أرضية، إشارات وأعمال."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Door, {
						to: "/esame",
						icon: SquareCheckBig,
						kicker: `${QUESTIONS.length} سؤالًا`,
						title: "الامتحان",
						text: "محاكاة 30 سؤالًا، أو تدريب حسب الفصل، مع الشرح بالعربي."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Door, {
						to: "/glossario",
						icon: Library,
						kicker: "اضغط الكلمة",
						title: "القاموس",
						text: "معنى الكلمة، وشرح إضافي إذا سألت، وأسئلة حفظتها."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
						label: "فصول مقروءة",
						value: `${read} / ${CHAPTERS.length}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
						label: "إشارات راجعتها",
						value: `${learned} / ${SIGNS.length}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
						label: "أفضل محاكاة",
						value: best === null ? "لم تبدأ" : `${best} / 30`,
						hint: exams ? `${exams} محاولة` : "النجاح من 27"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl bg-ink px-4 py-4 text-surface",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-semibold",
					children: "أرقام تسقط كثيرًا"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-3 space-y-2 text-sm leading-relaxed",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "السرعة: 50 داخل العمران، 90 ثانوي، 110 رئيسي، 130 أوتوسترادا. المطر: 110 و90 للأخيرين." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "حديث الرخصة 3 سنوات: 100 أوتوسترادا، 90 رئيسي، كحول صفر، نقاط مضاعفة، قدرة 105 كيلوواط و75 كيلوواط/طن." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "مسافة ثانية عند 130 حوالي 36 مترًا لا 15. تقدير الناشف: مربع عشرات السرعة." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "وقوف: 5 أمتار من التقاطع داخل المدينة، و15 مترًا من لوحة الحافلة إن لم تُرسم المساحة." })
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted md:hidden",
				children: CREDIT
			})
		]
	});
}
function Stat({ n, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-2xl font-semibold text-primary",
		children: n
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: label
	})] });
}
function Mini({ label, value, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-line bg-surface px-4 py-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xl font-semibold",
				children: value
			}),
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: hint
			}) : null
		]
	});
}
function Door({ to, icon: Icon, kicker, title, text }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		className: "rounded-2xl border border-line bg-surface p-4 transition hover:border-primary",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
				size: 20,
				className: "text-primary",
				"aria-hidden": true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-xs text-muted",
				children: kicker
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-2xl font-semibold",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm leading-relaxed text-muted",
				children: text
			})
		]
	});
}
//#endregion
export { Home as component };
