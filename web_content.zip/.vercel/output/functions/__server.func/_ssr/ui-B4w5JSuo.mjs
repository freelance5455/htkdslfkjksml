import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ui-B4w5JSuo.js
var import_jsx_runtime = require_jsx_runtime();
var btnGold = "inline-flex h-11 items-center justify-center gap-2 rounded-full bg-gold px-5 text-sm font-medium text-ink transition-colors duration-200 hover:bg-gold-2";
var btnGhost = "inline-flex h-11 items-center justify-center gap-2 rounded-full border border-line bg-transparent px-5 text-sm font-medium text-fg transition-colors duration-200 hover:border-gold hover:text-gold";
function Choice({ selected, locked, correct, wrong, children, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		disabled: locked && !selected,
		onClick,
		className: `w-full rounded-2xl border px-4 py-3 text-left text-base transition-colors duration-200 disabled:cursor-default ${correct ? "border-gold bg-surface-2 text-fg" : wrong ? "border-line bg-bg text-faint" : selected ? "border-gold text-fg" : "border-line text-fg hover:border-gold"}`,
		children
	});
}
//#endregion
export { btnGhost as n, btnGold as r, Choice as t };
