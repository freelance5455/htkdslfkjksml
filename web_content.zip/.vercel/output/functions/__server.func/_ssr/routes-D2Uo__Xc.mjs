import { i as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, q as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { _ as ChevronRight, a as Search, c as LocateFixed, d as Cloud, f as CloudSun, g as CloudDrizzle, h as CloudFog, i as Snowflake, l as Hash, m as CloudLightning, o as PawPrint, p as CloudRain, r as Sun, s as MapPin, t as Wind, u as Droplets, v as ChevronLeft } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-D2Uo__Xc.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var BRASILIA = "America/Sao_Paulo";
function clockParts(date, timeZone) {
	const full = new Intl.DateTimeFormat("pt-BR", {
		timeZone,
		hour: "2-digit",
		minute: "2-digit",
		second: "2-digit",
		weekday: "long",
		day: "numeric",
		month: "long",
		year: "numeric",
		hourCycle: "h23"
	}).formatToParts(date);
	const pick = (type) => full.find((part) => part.type === type)?.value ?? "";
	const monthShort = new Intl.DateTimeFormat("pt-BR", {
		timeZone,
		month: "short"
	}).format(date).replace(".", "");
	return {
		hour: pick("hour"),
		minute: pick("minute"),
		second: pick("second"),
		weekday: pick("weekday"),
		day: pick("day"),
		month: pick("month"),
		monthShort,
		year: pick("year")
	};
}
/** Civil date in a timezone, as YYYY-MM-DD. */
function zonedIso(date, timeZone) {
	return new Intl.DateTimeFormat("en-CA", {
		timeZone,
		year: "numeric",
		month: "2-digit",
		day: "2-digit"
	}).format(date);
}
function dateFromIso(iso) {
	const [year, month, day] = iso.split("-").map(Number);
	return new Date(year, month - 1, day, 12, 0, 0, 0);
}
function addDaysIso(iso, days) {
	const date = dateFromIso(iso);
	date.setDate(date.getDate() + days);
	return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}
function diffDays(fromIso, toIso) {
	const [y1, m1, d1] = fromIso.split("-").map(Number);
	const [y2, m2, d2] = toIso.split("-").map(Number);
	const start = Date.UTC(y1, m1 - 1, d1);
	const end = Date.UTC(y2, m2 - 1, d2);
	return Math.round((end - start) / 864e5);
}
function formatLongDate(iso) {
	return new Intl.DateTimeFormat("pt-BR", {
		weekday: "long",
		day: "numeric",
		month: "long"
	}).format(dateFromIso(iso));
}
function formatShortDate(iso) {
	return new Intl.DateTimeFormat("pt-BR", {
		day: "numeric",
		month: "short"
	}).format(dateFromIso(iso)).replace(".", "");
}
function isoWeek(iso) {
	const date = dateFromIso(iso);
	const utc = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
	const day = utc.getUTCDay() || 7;
	utc.setUTCDate(utc.getUTCDate() + 4 - day);
	const yearStart = new Date(Date.UTC(utc.getUTCFullYear(), 0, 1));
	const week = Math.ceil(((utc.getTime() - yearStart.getTime()) / 864e5 + 1) / 7);
	return {
		year: utc.getUTCFullYear(),
		week
	};
}
/** Monday–Sunday range containing this civil date. */
function weekBounds(iso) {
	const dow = dateFromIso(iso).getDay();
	const start = addDaysIso(iso, dow === 0 ? -6 : 1 - dow);
	return {
		start,
		end: addDaysIso(start, 6)
	};
}
function sentenceCase(value) {
	if (!value) return value;
	return value.charAt(0).toLocaleUpperCase("pt-BR") + value.slice(1);
}
function localTimeZone() {
	return Intl.DateTimeFormat().resolvedOptions().timeZone || "America/Sao_Paulo";
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl bg-paper px-3 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-medium tracking-wide text-muted uppercase",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 font-display text-2xl leading-none text-ink capitalize tabular-nums",
			children: value
		})]
	});
}
function ClockBoard({ now }) {
	const zone = BRASILIA;
	const parts = now ? clockParts(now, zone) : null;
	const here = localTimeZone();
	const local = now && here !== zone ? clockParts(now, here) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-card border border-line bg-card p-5 shadow-card sm:p-7 lg:col-span-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-baseline justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-muted",
					children: "Horário de Brasília"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted tabular-nums",
					children: parts ? `${parts.second}s` : "—"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 flex items-start font-display text-7xl leading-none text-ink tabular-nums sm:text-8xl",
				"aria-live": "off",
				children: parts ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: parts.hour }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "px-1 text-clay",
						"aria-hidden": "true",
						children: ":"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: parts.minute })
				] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-paper-deep",
					children: "00:00"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "sr-only",
				children: parts ? `${parts.hour} horas e ${parts.minute} minutos, ${parts.weekday}, ${parts.day} de ${parts.month} de ${parts.year}` : "Carregando horário"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 font-display text-2xl text-ink sm:text-3xl",
				children: parts ? sentenceCase(parts.weekday) : "—"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted",
				children: parts ? `${parts.day} de ${parts.month}` : "Sincronizando o relógio"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid grid-cols-2 gap-2 sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Data",
						value: parts ? `${parts.day} ${parts.monthShort}` : "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Minutos",
						value: parts ? parts.minute : "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Ano",
						value: parts ? parts.year : "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Segundos",
						value: parts ? parts.second : "—"
					})
				]
			}),
			local ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 text-sm text-muted",
				children: [
					"No seu fuso, agora são",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-medium text-ink tabular-nums",
						children: [
							local.hour,
							":",
							local.minute
						]
					}),
					"."
				]
			}) : null
		]
	});
}
function pad(value) {
	return String(value).padStart(2, "0");
}
function ymd(year, month, day) {
	return `${year}-${pad(month)}-${pad(day)}`;
}
/** Gregorian computus. Returns Easter Sunday as YYYY-MM-DD. */
function easterIso(year) {
	const a = year % 19;
	const b = Math.floor(year / 100);
	const c = year % 100;
	const d = Math.floor(b / 4);
	const e = b % 4;
	const f = Math.floor((b + 8) / 25);
	const g = Math.floor((b - f + 1) / 3);
	const h = (19 * a + b - d - g + 15) % 30;
	const i = Math.floor(c / 4);
	const k = c % 4;
	const l = (32 + 2 * e + 2 * i - h - k) % 7;
	const m = Math.floor((a + 11 * h + 22 * l) / 451);
	return ymd(year, Math.floor((h + l - 7 * m + 114) / 31), (h + l - 7 * m + 114) % 31 + 1);
}
function nthWeekday(year, monthIndex, weekday, nth) {
	const cursor = new Date(year, monthIndex, 1, 12);
	let seen = 0;
	while (cursor.getMonth() === monthIndex) {
		if (cursor.getDay() === weekday) {
			seen += 1;
			if (seen === nth) return ymd(year, monthIndex + 1, cursor.getDate());
		}
		cursor.setDate(cursor.getDate() + 1);
	}
	return ymd(year, monthIndex + 1, 1);
}
function holidaysForYear(year) {
	const easter = easterIso(year);
	return [
		{
			date: ymd(year, 1, 1),
			name: "Confraternização Universal",
			kind: "oficial",
			note: "Ano-novo. Feriado nacional."
		},
		{
			date: addDaysIso(easter, -48),
			name: "Segunda de Carnaval",
			kind: "festivo",
			note: "Ponto facultativo na maior parte do país."
		},
		{
			date: addDaysIso(easter, -47),
			name: "Terça de Carnaval",
			kind: "festivo",
			note: "Terça-feira gorda. O auge da folia."
		},
		{
			date: addDaysIso(easter, -2),
			name: "Sexta-feira Santa",
			kind: "oficial",
			note: "Paixão de Cristo. Feriado nacional."
		},
		{
			date: easter,
			name: "Páscoa",
			kind: "festivo",
			note: "Domingo de Páscoa."
		},
		{
			date: ymd(year, 4, 21),
			name: "Tiradentes",
			kind: "oficial",
			note: "Feriado nacional."
		},
		{
			date: ymd(year, 5, 1),
			name: "Dia do Trabalho",
			kind: "oficial",
			note: "Feriado nacional."
		},
		{
			date: nthWeekday(year, 4, 0, 2),
			name: "Dia das Mães",
			kind: "festivo",
			note: "Segundo domingo de maio."
		},
		{
			date: addDaysIso(easter, 60),
			name: "Corpus Christi",
			kind: "festivo",
			note: "Quinta-feira. Ponto facultativo em boa parte do Brasil."
		},
		{
			date: ymd(year, 6, 12),
			name: "Dia dos Namorados",
			kind: "festivo",
			note: "12 de junho, véspera de Santo Antônio."
		},
		{
			date: ymd(year, 6, 13),
			name: "Santo Antônio",
			kind: "festivo",
			note: "Abre o ciclo das festas juninas."
		},
		{
			date: ymd(year, 6, 24),
			name: "São João",
			kind: "festivo",
			note: "A grande noite das festas juninas."
		},
		{
			date: ymd(year, 6, 29),
			name: "São Pedro",
			kind: "festivo",
			note: "Encerra as festas juninas."
		},
		{
			date: nthWeekday(year, 7, 0, 2),
			name: "Dia dos Pais",
			kind: "festivo",
			note: "Segundo domingo de agosto."
		},
		{
			date: ymd(year, 9, 7),
			name: "Independência do Brasil",
			kind: "oficial",
			note: "Feriado nacional."
		},
		{
			date: ymd(year, 10, 12),
			name: "Nossa Senhora Aparecida",
			kind: "oficial",
			note: "Padroeira do Brasil. Também é Dia das Crianças."
		},
		{
			date: ymd(year, 10, 12),
			name: "Dia das Crianças",
			kind: "festivo",
			note: "Cai no mesmo dia de Nossa Senhora Aparecida."
		},
		{
			date: ymd(year, 11, 2),
			name: "Finados",
			kind: "oficial",
			note: "Feriado nacional."
		},
		{
			date: ymd(year, 11, 15),
			name: "Proclamação da República",
			kind: "oficial",
			note: "Feriado nacional."
		},
		{
			date: ymd(year, 11, 20),
			name: "Consciência Negra",
			kind: "oficial",
			note: "Feriado nacional desde 2024."
		},
		{
			date: ymd(year, 12, 24),
			name: "Véspera de Natal",
			kind: "festivo",
			note: "Noite de Natal. Ponto facultativo à tarde em muitos lugares."
		},
		{
			date: ymd(year, 12, 25),
			name: "Natal",
			kind: "oficial",
			note: "Feriado nacional."
		},
		{
			date: ymd(year, 12, 31),
			name: "Réveillon",
			kind: "festivo",
			note: "Véspera de Ano-Novo."
		}
	].sort((a, b) => a.date.localeCompare(b.date) || a.name.localeCompare(b.name, "pt-BR"));
}
function whenLabel(days) {
	if (days === 0) return "Hoje";
	if (days === 1) return "Amanhã";
	if (days > 1) return `Em ${days} dias`;
	if (days === -1) return "Ontem";
	return `Há ${Math.abs(days)} dias`;
}
var FILTERS = [
	{
		id: "todos",
		label: "Todos"
	},
	{
		id: "oficial",
		label: "Oficiais"
	},
	{
		id: "festivo",
		label: "Festivos"
	}
];
function HolidayBoard({ todayIso }) {
	const [filter, setFilter] = (0, import_react.useState)("todos");
	const year = todayIso ? Number(todayIso.slice(0, 4)) : null;
	const { list, next } = (0, import_react.useMemo)(() => {
		if (!todayIso || year === null) return {
			list: [],
			next: null
		};
		const visible = holidaysForYear(year).map((holiday) => ({
			holiday,
			days: diffDays(todayIso, holiday.date)
		})).filter((item) => filter === "todos" || item.holiday.kind === filter);
		let upcoming = visible.find((item) => item.days >= 0) ?? null;
		if (!upcoming) {
			const first = holidaysForYear(year + 1).find((holiday) => filter === "todos" || holiday.kind === filter);
			if (first) upcoming = {
				holiday: first,
				days: diffDays(todayIso, first.date)
			};
		}
		return {
			list: visible,
			next: upcoming
		};
	}, [
		filter,
		todayIso,
		year
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-card border border-line bg-card p-5 shadow-card sm:p-7",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm font-medium text-muted",
					children: ["Brasil", year ? ` · ${year}` : ""]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-1 text-3xl leading-none text-ink",
					children: "Feriados e datas festivas"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-1 rounded-full bg-paper p-1",
					role: "tablist",
					"aria-label": "Filtrar datas",
					children: FILTERS.map((item) => {
						const selected = filter === item.id;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							role: "tab",
							"aria-selected": selected,
							className: "min-h-11 rounded-full px-4 text-sm font-medium transition-colors " + (selected ? "bg-ink text-paper" : "text-ink hover:bg-card"),
							onClick: () => setFilter(item.id),
							children: item.label
						}, item.id);
					})
				})]
			}),
			next ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "mt-5 rounded-2xl bg-forest px-5 py-4 text-paper",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium text-paper/80",
						children: whenLabel(next.days)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-1 text-3xl leading-none",
						children: next.holiday.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2",
						children: sentenceCase(formatLongDate(next.holiday.date))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-paper/80",
						children: next.holiday.note
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 divide-y divide-line",
				children: list.map((item) => {
					const past = item.days < 0;
					const today = item.days === 0;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-start justify-between gap-3 py-3 " + (past ? "opacity-55" : ""),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-medium text-ink",
							children: [item.holiday.name, today ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-2 text-sm font-medium text-clay",
								children: "hoje"
							}) : null]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: sentenceCase(formatLongDate(item.holiday.date))
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-right",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "inline-flex rounded-full px-2 py-1 text-xs font-medium " + (item.holiday.kind === "oficial" ? "bg-paper text-forest" : "bg-paper text-clay"),
								children: item.holiday.kind === "oficial" ? "Oficial" : "Festivo"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs text-muted",
								children: todayIso ? whenLabel(item.days) : ""
							})]
						})]
					}, `${item.holiday.date}-${item.holiday.name}`);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "Oficiais são feriados nacionais. Festivos incluem carnaval, festas juninas e datas de calendário que o país comemora mesmo sem feriado em todo lugar."
			})
		]
	});
}
var DEFAULT_PLACE = {
	id: "sao-paulo",
	name: "São Paulo",
	admin: "SP",
	latitude: -23.5505,
	longitude: -46.6333,
	timezone: "America/Sao_Paulo"
};
var CAPITALS = [
	DEFAULT_PLACE,
	{
		id: "rio",
		name: "Rio de Janeiro",
		admin: "RJ",
		latitude: -22.9068,
		longitude: -43.1729,
		timezone: "America/Sao_Paulo"
	},
	{
		id: "brasilia",
		name: "Brasília",
		admin: "DF",
		latitude: -15.7939,
		longitude: -47.8828,
		timezone: "America/Sao_Paulo"
	},
	{
		id: "salvador",
		name: "Salvador",
		admin: "BA",
		latitude: -12.9777,
		longitude: -38.5016,
		timezone: "America/Bahia"
	},
	{
		id: "fortaleza",
		name: "Fortaleza",
		admin: "CE",
		latitude: -3.7172,
		longitude: -38.5433,
		timezone: "America/Fortaleza"
	},
	{
		id: "bh",
		name: "Belo Horizonte",
		admin: "MG",
		latitude: -19.9167,
		longitude: -43.9345,
		timezone: "America/Sao_Paulo"
	},
	{
		id: "manaus",
		name: "Manaus",
		admin: "AM",
		latitude: -3.119,
		longitude: -60.0217,
		timezone: "America/Manaus"
	},
	{
		id: "curitiba",
		name: "Curitiba",
		admin: "PR",
		latitude: -25.4284,
		longitude: -49.2733,
		timezone: "America/Sao_Paulo"
	},
	{
		id: "recife",
		name: "Recife",
		admin: "PE",
		latitude: -8.0476,
		longitude: -34.877,
		timezone: "America/Recife"
	},
	{
		id: "poa",
		name: "Porto Alegre",
		admin: "RS",
		latitude: -30.0346,
		longitude: -51.2177,
		timezone: "America/Sao_Paulo"
	},
	{
		id: "belem",
		name: "Belém",
		admin: "PA",
		latitude: -1.4558,
		longitude: -48.4902,
		timezone: "America/Belem"
	},
	{
		id: "goiania",
		name: "Goiânia",
		admin: "GO",
		latitude: -16.6869,
		longitude: -49.2648,
		timezone: "America/Sao_Paulo"
	},
	{
		id: "floripa",
		name: "Florianópolis",
		admin: "SC",
		latitude: -27.5949,
		longitude: -48.5482,
		timezone: "America/Sao_Paulo"
	},
	{
		id: "natal",
		name: "Natal",
		admin: "RN",
		latitude: -5.7793,
		longitude: -35.2009,
		timezone: "America/Fortaleza"
	},
	{
		id: "cuiaba",
		name: "Cuiabá",
		admin: "MT",
		latitude: -15.6014,
		longitude: -56.0979,
		timezone: "America/Cuiaba"
	},
	{
		id: "campo-grande",
		name: "Campo Grande",
		admin: "MS",
		latitude: -20.4697,
		longitude: -54.6201,
		timezone: "America/Campo_Grande"
	},
	{
		id: "vitoria",
		name: "Vitória",
		admin: "ES",
		latitude: -20.3155,
		longitude: -40.3128,
		timezone: "America/Sao_Paulo"
	},
	{
		id: "maceio",
		name: "Maceió",
		admin: "AL",
		latitude: -9.6498,
		longitude: -35.7089,
		timezone: "America/Maceio"
	},
	{
		id: "joao-pessoa",
		name: "João Pessoa",
		admin: "PB",
		latitude: -7.1195,
		longitude: -34.845,
		timezone: "America/Fortaleza"
	},
	{
		id: "teresina",
		name: "Teresina",
		admin: "PI",
		latitude: -5.0892,
		longitude: -42.8019,
		timezone: "America/Fortaleza"
	},
	{
		id: "sao-luis",
		name: "São Luís",
		admin: "MA",
		latitude: -2.5387,
		longitude: -44.2825,
		timezone: "America/Fortaleza"
	},
	{
		id: "aracaju",
		name: "Aracaju",
		admin: "SE",
		latitude: -10.9472,
		longitude: -37.0731,
		timezone: "America/Maceio"
	},
	{
		id: "palmas",
		name: "Palmas",
		admin: "TO",
		latitude: -10.2491,
		longitude: -48.3243,
		timezone: "America/Araguaina"
	},
	{
		id: "macapa",
		name: "Macapá",
		admin: "AP",
		latitude: .0349,
		longitude: -51.0694,
		timezone: "America/Belem"
	},
	{
		id: "boa-vista",
		name: "Boa Vista",
		admin: "RR",
		latitude: 2.8235,
		longitude: -60.6758,
		timezone: "America/Boa_Vista"
	},
	{
		id: "rio-branco",
		name: "Rio Branco",
		admin: "AC",
		latitude: -9.9754,
		longitude: -67.8249,
		timezone: "America/Rio_Branco"
	},
	{
		id: "porto-velho",
		name: "Porto Velho",
		admin: "RO",
		latitude: -8.7612,
		longitude: -63.9004,
		timezone: "America/Porto_Velho"
	}
];
var STORAGE_KEY = "agora-place";
function readSavedPlace() {
	if (typeof localStorage === "undefined") return null;
	try {
		const raw = localStorage.getItem(STORAGE_KEY);
		if (!raw) return null;
		const parsed = JSON.parse(raw);
		if (typeof parsed.name !== "string" || typeof parsed.latitude !== "number" || typeof parsed.longitude !== "number") return null;
		return {
			id: typeof parsed.id === "string" ? parsed.id : "saved",
			name: parsed.name,
			admin: typeof parsed.admin === "string" ? parsed.admin : "",
			latitude: parsed.latitude,
			longitude: parsed.longitude,
			timezone: typeof parsed.timezone === "string" ? parsed.timezone : "America/Sao_Paulo"
		};
	} catch {
		return null;
	}
}
function savePlace(place) {
	localStorage.setItem(STORAGE_KEY, JSON.stringify(place));
}
async function searchPlaces(query, signal) {
	const url = new URL("https://geocoding-api.open-meteo.com/v1/search");
	url.searchParams.set("name", query);
	url.searchParams.set("count", "6");
	url.searchParams.set("language", "pt");
	url.searchParams.set("format", "json");
	url.searchParams.set("countryCode", "BR");
	const response = await fetch(url, { signal });
	if (!response.ok) throw new Error("busca indisponível");
	return ((await response.json()).results ?? []).filter((item) => item.country_code === "BR" || item.country_code === void 0).filter((item) => typeof item.latitude === "number" && typeof item.longitude === "number" && item.name).map((item) => ({
		id: String(item.id ?? `${item.name}-${item.latitude}`),
		name: item.name ?? "Cidade",
		admin: item.admin1 ?? "",
		latitude: item.latitude,
		longitude: item.longitude,
		timezone: item.timezone || "America/Sao_Paulo"
	}));
}
async function placeFromCoords(latitude, longitude, signal) {
	const url = new URL("https://geocoding-api.open-meteo.com/v1/reverse");
	url.searchParams.set("latitude", String(latitude));
	url.searchParams.set("longitude", String(longitude));
	url.searchParams.set("language", "pt");
	const response = await fetch(url, { signal });
	if (!response.ok) return {
		id: "aqui",
		name: "Onde você está",
		admin: "",
		latitude,
		longitude,
		timezone: "auto"
	};
	const item = (await response.json()).results?.[0];
	return {
		id: String(item?.id ?? "aqui"),
		name: item?.name || "Onde você está",
		admin: item?.admin1 || "",
		latitude,
		longitude,
		timezone: item?.timezone || "auto"
	};
}
var SKY = {
	clear: {
		label: "Céu limpo",
		icon: Sun
	},
	fair: {
		label: "Quase limpo",
		icon: CloudSun
	},
	cloud: {
		label: "Nublado",
		icon: Cloud
	},
	fog: {
		label: "Neblina",
		icon: CloudFog
	},
	drizzle: {
		label: "Garoa",
		icon: CloudDrizzle
	},
	rain: {
		label: "Chuva",
		icon: CloudRain
	},
	heavy: {
		label: "Chuva forte",
		icon: CloudRain
	},
	storm: {
		label: "Trovoada",
		icon: CloudLightning
	},
	snow: {
		label: "Neve",
		icon: Snowflake
	}
};
function describeSky(kind) {
	return SKY[kind] ?? SKY.cloud;
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function safeZone(timezone) {
	try {
		new Intl.DateTimeFormat("pt-BR", { timeZone: timezone }).format(/* @__PURE__ */ new Date());
		return timezone;
	} catch {
		return "America/Sao_Paulo";
	}
}
var getForecast = createServerFn({ method: "GET" }).validator((input) => {
	const data = input;
	const latitude = Number(data?.latitude);
	const longitude = Number(data?.longitude);
	if (!Number.isFinite(latitude) || latitude < -90 || latitude > 90) throw new Error("latitude inválida");
	if (!Number.isFinite(longitude) || longitude < -180 || longitude > 180) throw new Error("longitude inválida");
	return {
		latitude,
		longitude,
		timezone: safeZone(typeof data?.timezone === "string" ? data.timezone : "America/Sao_Paulo")
	};
}).handler(createSsrRpc("4709b178a349db19f26fdf875764af9079bc77822d40134d4303c97b15750ee9"));
function WeatherBoard({ place, onPlace, now }) {
	const [forecast, setForecast] = (0, import_react.useState)(null);
	const [status, setStatus] = (0, import_react.useState)("loading");
	const [open, setOpen] = (0, import_react.useState)(false);
	const [query, setQuery] = (0, import_react.useState)("");
	const [results, setResults] = (0, import_react.useState)([]);
	const [searching, setSearching] = (0, import_react.useState)(false);
	const [locating, setLocating] = (0, import_react.useState)(false);
	const [locateError, setLocateError] = (0, import_react.useState)("");
	const [attempt, setAttempt] = (0, import_react.useState)(0);
	const panelRef = (0, import_react.useRef)(null);
	const listId = (0, import_react.useId)();
	(0, import_react.useEffect)(() => {
		const controller = new AbortController();
		setStatus("loading");
		getForecast({
			data: {
				latitude: place.latitude,
				longitude: place.longitude,
				timezone: place.timezone
			},
			signal: controller.signal
		}).then((data) => {
			setForecast(data);
			setStatus("ready");
		}).catch((error) => {
			if (error instanceof DOMException && error.name === "AbortError") return;
			setStatus("error");
		});
		return () => controller.abort();
	}, [
		place.latitude,
		place.longitude,
		attempt
	]);
	(0, import_react.useEffect)(() => {
		const trimmed = query.trim();
		if (trimmed.length < 2) {
			setResults([]);
			setSearching(false);
			return;
		}
		const controller = new AbortController();
		setSearching(true);
		const timer = window.setTimeout(() => {
			searchPlaces(trimmed, controller.signal).then((places) => {
				setResults(places);
				setSearching(false);
			}).catch((error) => {
				if (error instanceof DOMException && error.name === "AbortError") return;
				setResults([]);
				setSearching(false);
			});
		}, 280);
		return () => {
			controller.abort();
			window.clearTimeout(timer);
		};
	}, [query]);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		function onPointer(event) {
			if (!panelRef.current?.contains(event.target)) setOpen(false);
		}
		function onKey(event) {
			if (event.key === "Escape") setOpen(false);
		}
		window.addEventListener("mousedown", onPointer);
		window.addEventListener("keydown", onKey);
		return () => {
			window.removeEventListener("mousedown", onPointer);
			window.removeEventListener("keydown", onKey);
		};
	}, [open]);
	function choose(next) {
		savePlace(next);
		onPlace(next);
		setOpen(false);
		setQuery("");
		setLocateError("");
	}
	function locate() {
		if (!navigator.geolocation) {
			setLocateError("Este navegador não informa a localização.");
			return;
		}
		setLocating(true);
		setLocateError("");
		navigator.geolocation.getCurrentPosition((position) => {
			placeFromCoords(position.coords.latitude, position.coords.longitude).then((found) => {
				choose(found);
				setLocating(false);
			}).catch(() => {
				setLocating(false);
				setLocateError("Não achei o nome desse lugar.");
			});
		}, () => {
			setLocating(false);
			setLocateError("Permissão de localização negada.");
		}, {
			enableHighAccuracy: false,
			timeout: 8e3
		});
	}
	const sky = forecast ? describeSky(forecast.current.sky) : null;
	const SkyIcon = sky?.icon;
	const there = forecast && now && forecast.timezone !== "America/Sao_Paulo" ? clockParts(now, forecast.timezone) : null;
	const suggestions = query.trim().length >= 2 ? results : CAPITALS.slice(0, 8);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-card border border-line bg-card p-5 shadow-card sm:p-7",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-muted",
					children: "Clima"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-1 text-3xl leading-none text-ink",
					children: "Onde você quer olhar"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative",
					ref: panelRef,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "flex min-h-11 items-center gap-2 rounded-full border border-line bg-paper px-4 text-sm font-medium text-ink",
						"aria-expanded": open,
						"aria-controls": listId,
						onClick: () => setOpen((value) => !value),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {
								className: "size-4 text-clay",
								"aria-hidden": "true"
							}),
							place.name,
							place.admin ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted",
								children: place.admin
							}) : null
						]
					}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "absolute right-0 z-20 mt-2 w-72 rounded-2xl border border-line bg-card p-3 shadow-card",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex items-center gap-2 rounded-xl border border-line bg-paper px-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
									className: "size-4 text-muted",
									"aria-hidden": "true"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: query,
									onChange: (event) => setQuery(event.target.value),
									placeholder: "Buscar cidade",
									className: "h-11 w-full bg-transparent text-sm text-ink outline-none placeholder:text-muted",
									autoFocus: true
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "mt-2 flex min-h-11 w-full items-center gap-2 rounded-xl px-3 text-left text-sm font-medium text-forest hover:bg-paper",
								onClick: locate,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LocateFixed, {
									className: "size-4",
									"aria-hidden": "true"
								}), locating ? "Localizando…" : "Usar minha localização"]
							}),
							locateError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "px-3 pt-1 text-sm text-clay",
								children: locateError
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
								id: listId,
								className: "mt-2 max-h-64 overflow-auto",
								role: "listbox",
								children: [
									searching ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
										className: "px-3 py-2 text-sm text-muted",
										children: "Buscando…"
									}) : null,
									!searching && query.trim().length >= 2 && suggestions.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
										className: "px-3 py-2 text-sm text-muted",
										children: "Nenhuma cidade com esse nome."
									}) : null,
									suggestions.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										className: "flex min-h-11 w-full items-center justify-between rounded-xl px-3 text-left text-sm hover:bg-paper",
										onClick: () => choose(item),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-medium text-ink",
											children: item.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted",
											children: item.admin
										})]
									}) }, item.id))
								]
							})
						]
					}) : null]
				})]
			}),
			status === "error" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 rounded-2xl bg-paper px-4 py-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium text-ink",
						children: "O clima não respondeu agora."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "A previsão às vezes demora ou pede uma pausa. A cidade continua salva."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "mt-3 min-h-11 rounded-full bg-ink px-4 text-sm font-medium text-paper",
						onClick: () => setAttempt((value) => value + 1),
						children: "Tentar de novo"
					})
				]
			}) : null,
			status === "loading" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid gap-3 sm:grid-cols-5",
				"aria-hidden": "true",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-28 rounded-2xl bg-paper sm:col-span-2" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-28 rounded-2xl bg-paper sm:col-span-3" })]
			}) : null,
			status === "ready" && forecast && sky && SkyIcon ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap items-end justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex size-16 items-center justify-center rounded-3xl bg-paper text-clay",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkyIcon, {
								className: "size-8",
								"aria-hidden": "true"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-display text-6xl leading-none text-ink tabular-nums",
							children: [forecast.current.temperature, "°"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-ink",
							children: sky.label
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "flex flex-wrap gap-x-5 gap-y-1 text-sm text-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
								"Sensação ",
								forecast.current.apparent,
								"°"
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "inline-flex items-center gap-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Droplets, {
										className: "size-4",
										"aria-hidden": "true"
									}),
									forecast.current.humidity,
									"%"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "inline-flex items-center gap-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wind, {
										className: "size-4",
										"aria-hidden": "true"
									}),
									forecast.current.wind,
									" km/h"
								]
							}),
							there ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "tabular-nums",
								children: [
									"Lá são ",
									there.hour,
									":",
									there.minute
								]
							}) : null
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-6 grid grid-cols-5 gap-2",
					children: forecast.daily.map((day, index) => {
						const DayIcon = describeSky(day.sky).icon;
						const label = index === 0 ? "Hoje" : new Intl.DateTimeFormat("pt-BR", { weekday: "short" }).format(/* @__PURE__ */ new Date(`${day.date}T12:00:00`)).replace(".", "");
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-2xl bg-paper px-2 py-3 text-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-medium text-muted capitalize",
									children: label
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DayIcon, {
									className: "mx-auto mt-2 size-5 text-forest",
									"aria-hidden": "true"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2 text-sm font-medium text-ink tabular-nums",
									children: [day.max, "°"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted tabular-nums",
									children: [day.min, "°"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted tabular-nums",
									children: day.rainMm > 0 ? `${day.rainMm} mm` : "seco"
								})
							]
						}, day.date);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-4 text-xs text-muted",
					children: [
						"Previsão de ",
						forecast.source,
						". Chuva do dia em milímetros."
					]
				})
			] }) : null
		]
	});
}
var COLORS = [
	{
		name: "Amarelo-ipê",
		hex: "#e2b23a",
		line: "A cor que toma as ruas no fim do inverno seco."
	},
	{
		name: "Verde-mata",
		hex: "#1f6b45",
		line: "O verde fechado da floresta depois da chuva."
	},
	{
		name: "Terra-vermelha",
		hex: "#a33b24",
		line: "O chão do interior, quente e firme."
	},
	{
		name: "Azul-anil",
		hex: "#243f73",
		line: "O céu profundo de fim de tarde no planalto."
	},
	{
		name: "Rosa-ipê",
		hex: "#d46a8a",
		line: "As flores que pintam a cidade sem pedir licença."
	},
	{
		name: "Laranja-caju",
		hex: "#e07a2f",
		line: "Doce, ácido e impossível de ignorar."
	},
	{
		name: "Areia",
		hex: "#d8c4a0",
		line: "A cor da costa quando a maré baixa."
	},
	{
		name: "Jabuticaba",
		hex: "#3a2430",
		line: "Quase preto, brilhante, grudado no tronco."
	},
	{
		name: "Turquesa",
		hex: "#1f8a86",
		line: "Água rasa, clara o bastante para ver o fundo."
	},
	{
		name: "Dourado",
		hex: "#c8962e",
		line: "Luz baixa de fim de domingo."
	},
	{
		name: "Coral",
		hex: "#e26a52",
		line: "Quente, mas sem gritar."
	},
	{
		name: "Lavanda-do-cerrado",
		hex: "#7d6aa8",
		line: "O roxo discreto das flores do planalto."
	}
];
var ANIMALS = [
	{
		name: "Capivara",
		line: "A maior roedora do mundo, sempre perto d'água."
	},
	{
		name: "Onça-pintada",
		line: "O maior felino das Américas. Vive escondida na mata."
	},
	{
		name: "Arara-azul",
		line: "Azul inteira, barulhenta e fiel ao seu par."
	},
	{
		name: "Tucano",
		line: "O bico parece pesado, mas é leve e oco."
	},
	{
		name: "Bicho-preguiça",
		line: "Desce da árvore quase só para o que é inevitável."
	},
	{
		name: "Mico-leão-dourado",
		line: "Pequeno, laranja e símbolo da Mata Atlântica."
	},
	{
		name: "Lobo-guará",
		line: "Pernas longas de cerradão. Come fruta e também caça."
	},
	{
		name: "Tamanduá-bandeira",
		line: "Focinho de tubo e uma cauda que vira cobertor."
	},
	{
		name: "Boto-cor-de-rosa",
		line: "O golfinho de rio, rosado quando adulto."
	},
	{
		name: "Arara-canindé",
		line: "Azul por cima, amarela por baixo. Voa em casal."
	},
	{
		name: "Quati",
		line: "Nariz empinado e o hábito de investigar tudo."
	},
	{
		name: "Beija-flor",
		line: "Para no ar. O coração bate rápido demais para contar."
	},
	{
		name: "Tatu-bola",
		line: "Fecha o corpo numa bola quando se assusta."
	},
	{
		name: "Jacaré-açu",
		line: "O gigante da Amazônia. Fica imóvel até decidir."
	},
	{
		name: "Sabiá-laranjeira",
		line: "O pássaro da canção. Canta alto de madrugada."
	},
	{
		name: "Peixe-boi",
		line: "Manso, lento, herbívoro dos rios e do litoral."
	},
	{
		name: "Garça-branca",
		line: "Pesca parada, num pé só, como se tivesse tempo."
	},
	{
		name: "Macaco-prego",
		line: "Usa ferramenta e não perde uma fruta."
	},
	{
		name: "Anta",
		line: "O maior mamífero terrestre do Brasil. Gosta de lama."
	},
	{
		name: "Carcará",
		line: "Esperto, oportunista e dono de um grito inconfundível."
	},
	{
		name: "Tartaruga-marinha",
		line: "Volta à mesma praia onde nasceu, décadas depois."
	},
	{
		name: "Jaguatirica",
		line: "Pintada miúda, noturna, quase um fantasma do mato."
	},
	{
		name: "Flamingo",
		line: "Rosa por causa do que come. Anda em lagoas rasas."
	},
	{
		name: "Sucuri",
		line: "A serpente d'água. Abraça antes de decidir o resto."
	}
];
function hashString(value) {
	let hash = 2166136261;
	for (let index = 0; index < value.length; index += 1) {
		hash ^= value.charCodeAt(index);
		hash = Math.imul(hash, 16777619);
	}
	return hash >>> 0;
}
function mulberry32(seed) {
	let state = seed >>> 0;
	return () => {
		state = state + 1831565813 | 0;
		let t = Math.imul(state ^ state >>> 15, 1 | state);
		t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
function pick(random, list) {
	return list[Math.min(list.length - 1, Math.floor(random() * list.length))];
}
/** Same draw for everyone during a given ISO week. Changes only when the week changes. */
function drawForIso(iso) {
	const week = isoWeek(iso);
	const random = mulberry32(hashString(`agora:${`${week.year}-W${String(week.week).padStart(2, "0")}`}`));
	return {
		week,
		color: pick(random, COLORS),
		animal: pick(random, ANIMALS),
		number: 1 + Math.floor(random() * 99)
	};
}
function WeekBoard({ todayIso, weekOffset, onShift }) {
	const iso = todayIso ? addDaysIso(todayIso, weekOffset * 7) : null;
	const draw = iso ? drawForIso(iso) : null;
	const bounds = iso ? weekBounds(iso) : null;
	const current = weekOffset === 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "flex flex-col rounded-card border border-line bg-card shadow-card lg:col-span-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3 px-5 pt-5 sm:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium text-muted",
						children: "Carta da semana"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-1 text-3xl leading-none text-ink",
						children: draw ? `Semana ${draw.week.week}` : "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted",
						children: [bounds ? `${formatShortDate(bounds.start)} – ${formatShortDate(bounds.end)}` : "Calculando", draw ? ` · ${draw.week.year}` : ""]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "flex size-11 items-center justify-center rounded-full border border-line text-ink transition-colors hover:bg-paper",
						onClick: () => onShift(-1),
						"aria-label": "Semana anterior",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "flex size-11 items-center justify-center rounded-full border border-line text-ink transition-colors hover:bg-paper",
						onClick: () => onShift(1),
						"aria-label": "Próxima semana",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5" })
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-5 mt-4 h-2 rounded-full sm:mx-6",
				style: { backgroundColor: draw?.color.hex ?? "transparent" },
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "flex flex-1 flex-col gap-4 px-5 py-5 sm:px-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "size-12 shrink-0 rounded-2xl border border-line",
							style: { backgroundColor: draw?.color.hex },
							"aria-hidden": "true"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium tracking-wide text-muted uppercase",
								children: "Cor"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-xl leading-tight text-ink",
								children: draw?.color.name ?? "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: draw?.color.line
							})
						] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex size-12 shrink-0 items-center justify-center rounded-2xl bg-paper text-forest",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PawPrint, {
								className: "size-5",
								"aria-hidden": "true"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium tracking-wide text-muted uppercase",
								children: "Animal"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-xl leading-tight text-ink",
								children: draw?.animal.name ?? "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: draw?.animal.line
							})
						] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex size-12 shrink-0 items-center justify-center rounded-2xl bg-paper text-clay",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hash, {
								className: "size-5",
								"aria-hidden": "true"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium tracking-wide text-muted uppercase",
							children: "Número"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-4xl leading-none text-ink tabular-nums",
							children: draw ? String(draw.number).padStart(2, "0") : "—"
						})] })]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-auto border-t border-line px-5 py-3 text-sm text-muted sm:px-6",
				children: [
					current ? "O mesmo sorteio para todo o Brasil até domingo. Muda na segunda." : "Você está olhando outra semana. Volte para a de agora.",
					" ",
					!current ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "font-medium text-forest underline-offset-2 hover:underline",
						onClick: () => onShift(-weekOffset),
						children: "Esta semana"
					}) : null
				]
			})
		]
	});
}
function AgoraApp() {
	const [now, setNow] = (0, import_react.useState)(null);
	const [place, setPlace] = (0, import_react.useState)(DEFAULT_PLACE);
	const [weekOffset, setWeekOffset] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		const saved = readSavedPlace();
		if (saved) setPlace(saved);
		const tick = () => setNow(/* @__PURE__ */ new Date());
		tick();
		const id = window.setInterval(tick, 1e3);
		return () => window.clearInterval(id);
	}, []);
	const todayIso = now ? zonedIso(now, BRASILIA) : null;
	const week = todayIso ? isoWeek(todayIso) : null;
	const bounds = todayIso ? weekBounds(todayIso) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto min-h-screen max-w-5xl px-4 py-6 sm:px-6 sm:py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "border-t-4 border-clay",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex items-end justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold tracking-widest text-clay uppercase",
							children: "Edição de hoje"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-1 text-6xl leading-none text-ink italic sm:text-7xl",
							children: "Agora"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 max-w-md text-muted",
							children: "A data, os minutos, o ano, o clima e os feriados do Brasil — com uma cor, um animal e um número só desta semana."
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "hidden text-right text-sm text-muted sm:block",
						children: week ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							"Semana ",
							week.week,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums",
								children: bounds ? `${formatShortDate(bounds.start)} – ${formatShortDate(bounds.end)}` : ""
							})
						] }) : "Brasil"
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 grid items-stretch gap-4 lg:grid-cols-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClockBoard, { now }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WeekBoard, {
					todayIso,
					weekOffset,
					onShift: (delta) => setWeekOffset((value) => value + delta)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WeatherBoard, {
					place,
					onPlace: setPlace,
					now
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HolidayBoard, { todayIso })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "mt-8 flex flex-wrap items-center justify-between gap-2 pb-4 text-sm text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Relógio no fuso de Brasília." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "A carta da semana é a mesma para todo mundo." })]
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AgoraApp, {});
}
//#endregion
export { Home as component };
