import { w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as primaryBtn } from "./auth-screens-DZe0plYT.mjs";
import { i as useSalon, t as Shell$1 } from "./shell-DSe4icyb.mjs";
import { n as useMeId, t as FeedView } from "./use-me-id-BM_D2CRi.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/subliminals-DI_z8RUj.js
var import_jsx_runtime = require_jsx_runtime();
function SubliminalsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell$1, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shelf, {}) });
}
function Shelf() {
	const meId = useMeId();
	const openCompose = useSalon((s) => s.openCompose);
	if (!meId) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto w-full max-w-xl space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-widest text-rose",
					children: "رف هادئ"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-4xl",
					children: "سيبلمنال"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: primaryBtn,
					onClick: () => openCompose({ kind: "subliminal" }),
					children: "إضافة"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm leading-6 text-mute",
				children: "عنوان، وصف، ورابط إن أحببت. الكل يراه."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeedView, {
				meId,
				query: { surface: "subliminals" },
				variant: "subliminal",
				emptyTitle: "الرف فارغ",
				emptyBody: "أضف سيبلمنال بوصف واضح. يمكن ربط فيديو يوتيوب."
			})
		]
	});
}
//#endregion
export { SubliminalsPage as component };
