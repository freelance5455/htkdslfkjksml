import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as Settings, c as ImagePlus, i as Trash2, l as Download, n as Upload, o as Printer, s as Plus, t as X, u as Archive } from "../_libs/lucide-react.mjs";
import { a as DialogPortal, i as DialogOverlay, n as DialogClose, o as DialogTitle, r as DialogContent, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { t as create } from "../_libs/zustand.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-B8DecALf.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var DOCTOR_COLORS = [
	"#e15b12",
	"#c2412d",
	"#1d6aab",
	"#1f7a62",
	"#6d4ca3",
	"#8a7320",
	"#3a3f45",
	"#b43d78"
];
var UPPER_RIGHT = [
	18,
	17,
	16,
	15,
	14,
	13,
	12,
	11
];
var UPPER_LEFT = [
	21,
	22,
	23,
	24,
	25,
	26,
	27,
	28
];
var LOWER_RIGHT = [
	48,
	47,
	46,
	45,
	44,
	43,
	42,
	41
];
var LOWER_LEFT = [
	31,
	32,
	33,
	34,
	35,
	36,
	37,
	38
];
var UPPER_TEETH = [...UPPER_RIGHT, ...UPPER_LEFT];
var LOWER_TEETH = [...LOWER_RIGHT, ...LOWER_LEFT];
var TOOTH_ORDER = [...UPPER_TEETH, ...LOWER_TEETH];
var WORK_TYPES = [
	{
		id: "zirconia",
		label: "روکش زیرکونیا"
	},
	{
		id: "pfm",
		label: "روکش PFM"
	},
	{
		id: "implant-zirconia",
		label: "روکش ایمپلنت زیرکونیا"
	},
	{
		id: "implant-impression",
		label: "قالب ایمپلنت زیرکونیا"
	},
	{
		id: "post",
		label: "پست (NPG)"
	},
	{
		id: "layering",
		label: "انجام لایرینگ"
	},
	{
		id: "laminate",
		label: "لمینیت"
	},
	{
		id: "other",
		label: "سایر خدمات"
	}
];
var KNOWN_PRICES = {
	post: 6e5,
	"implant-impression": 2e6,
	layering: 35e4
};
var SHADES = [
	"A1",
	"A2",
	"A3",
	"A3.5",
	"B1",
	"B2",
	"B3",
	"C1",
	"C2",
	"D2",
	"Bleach",
	"سایر"
];
var DEFAULT_SETTINGS = {
	labName: "لابراتوار دندانسازی آرمان",
	manager: "محبی",
	card: "",
	sheba: "",
	defaultNote: "با تشکر از اعتماد شما"
};
var STORAGE_TEXT = 400;
var NOTE_TEXT = 2e3;
function uid(prefix) {
	return `${prefix}-${globalThis.crypto?.randomUUID?.().slice(0, 8) ?? Math.random().toString(36).slice(2, 10)}`;
}
function todayJalali() {
	return new Intl.DateTimeFormat("fa-IR-u-ca-persian", {
		year: "numeric",
		month: "2-digit",
		day: "2-digit"
	}).format(/* @__PURE__ */ new Date());
}
function jalaliYear() {
	return new Intl.DateTimeFormat("en-US-u-ca-persian", { year: "numeric" }).formatToParts(/* @__PURE__ */ new Date()).find((part) => part.type === "year")?.value ?? String((/* @__PURE__ */ new Date()).getFullYear());
}
function newInvoiceNo() {
	return `AR-${jalaliYear()}-${String(Date.now()).slice(-6)}`;
}
function faNum(value) {
	return Math.round(value).toLocaleString("fa-IR");
}
function toAsciiDigits(value) {
	return value.replace(/[۰-۹]/g, (digit) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(digit))).replace(/[٠-٩]/g, (digit) => String("٠١٢٣٤٥٦٧٨٩".indexOf(digit)));
}
function parseMoney(raw) {
	const ascii = toAsciiDigits(raw).replace(/[^\d]/g, "");
	if (!ascii) return "";
	return Math.min(Number(ascii), 1e9);
}
function parseQty(raw) {
	const n = Number(toAsciiDigits(raw).replace(/[^\d]/g, ""));
	if (!Number.isFinite(n) || n < 1) return 1;
	return Math.min(999, Math.floor(n));
}
function safeHex(value, fallback = DOCTOR_COLORS[0]) {
	return typeof value === "string" && /^#[0-9a-fA-F]{6}$/.test(value) ? value.toLowerCase() : fallback;
}
function clip(value, max) {
	return typeof value === "string" ? value.trim().slice(0, max) : "";
}
function isRecord(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
var TYPE_IDS = new Set(WORK_TYPES.map((type) => type.id));
function asType(value) {
	return typeof value === "string" && TYPE_IDS.has(value) ? value : "other";
}
function asTooth(value) {
	const n = typeof value === "number" ? value : typeof value === "string" && value ? Number(value) : NaN;
	return TOOTH_ORDER.includes(n) ? n : null;
}
function workLabel(type) {
	return WORK_TYPES.find((item) => item.id === type)?.label ?? "سایر خدمات";
}
function lineTitle(item) {
	const note = item.description.trim();
	const label = workLabel(item.type);
	if (!note) return label;
	if (item.type === "other") return note;
	return `${label} — ${note}`;
}
function lineAmount(item) {
	return (item.price === "" ? 0 : Math.max(0, item.price)) * Math.max(1, item.qty || 1);
}
function totals(items, discount) {
	const subtotal = items.reduce((sum, item) => sum + lineAmount(item), 0);
	const off = Math.min(Math.max(0, Number(discount) || 0), subtotal);
	return {
		subtotal,
		discount: off,
		total: Math.max(0, subtotal - off)
	};
}
function blankItem(tooth) {
	return {
		id: uid("i"),
		tooth,
		type: tooth == null ? "other" : "zirconia",
		shade: "",
		qty: 1,
		price: "",
		description: ""
	};
}
function applyTypeChange(item, type) {
	const prevKnown = KNOWN_PRICES[item.type];
	const nextKnown = KNOWN_PRICES[type];
	const untouched = item.price === "" || item.price === 0 || item.price === prevKnown;
	return {
		...item,
		type,
		price: untouched ? nextKnown ?? "" : item.price
	};
}
function blankDraft(settings) {
	return {
		invoiceNo: newInvoiceNo(),
		date: todayJalali(),
		patientName: "",
		doctorId: "",
		patientPhone: "",
		patientNotes: "",
		imageData: "",
		selectedTeeth: [],
		items: [],
		discount: 0,
		invoiceNotes: "",
		labCardNumber: settings.card,
		labShebaNumber: settings.sheba,
		savedId: null
	};
}
function compareItems(a, b) {
	if (a.tooth == null && b.tooth == null) return 0;
	if (a.tooth == null) return 1;
	if (b.tooth == null) return -1;
	return TOOTH_ORDER.indexOf(a.tooth) - TOOTH_ORDER.indexOf(b.tooth);
}
function syncItems(draft) {
	const kept = draft.items.filter((item) => item.tooth == null || draft.selectedTeeth.includes(item.tooth));
	const have = new Set(kept.flatMap((item) => item.tooth == null ? [] : [item.tooth]));
	const items = [...kept];
	for (const tooth of draft.selectedTeeth) if (!have.has(tooth)) items.push(blankItem(tooth));
	items.sort(compareItems);
	return {
		...draft,
		items
	};
}
function teethFromItems(items) {
	const have = new Set(items.flatMap((item) => item.tooth == null ? [] : [item.tooth]));
	return TOOTH_ORDER.filter((tooth) => have.has(tooth));
}
function formatPayId(raw) {
	const clean = raw.trim();
	if (!clean) return "—";
	const digits = toAsciiDigits(clean).replace(/[^\d]/g, "");
	if (digits.length === 16) return digits.replace(/(.{4})/g, "$1 ").trim();
	return clean;
}
function sanitizeSettings(value) {
	const raw = isRecord(value) ? value : {};
	return {
		labName: clip(raw.labName, 120) || DEFAULT_SETTINGS.labName,
		manager: clip(raw.manager, 80) || DEFAULT_SETTINGS.manager,
		card: clip(raw.card, 40),
		sheba: clip(raw.sheba, 40),
		defaultNote: clip(raw.defaultNote, NOTE_TEXT)
	};
}
function sanitizeImage(value) {
	if (typeof value !== "string") return "";
	if (!/^data:image\/(png|jpe?g|webp|gif);base64,/i.test(value)) return "";
	return value.length > 15e5 ? "" : value;
}
function sanitizeItem(value) {
	if (!isRecord(value)) return null;
	const qty = Number(value.qty);
	const price = value.price === "" || value.price == null ? "" : Number(value.price);
	return {
		id: clip(value.id, 40) || uid("i"),
		tooth: asTooth(value.tooth),
		type: asType(value.type),
		shade: clip(value.shade, 24),
		qty: Number.isFinite(qty) ? Math.max(1, Math.min(999, Math.floor(qty))) : 1,
		price: price === "" ? "" : Number.isFinite(price) ? Math.max(0, Math.min(1e9, price)) : "",
		description: clip(value.description, STORAGE_TEXT)
	};
}
function sanitizeDraft(value, settings, archive) {
	if (!isRecord(value)) return null;
	if (archive && typeof value.patientName !== "string") return null;
	const items = Array.isArray(value.items) ? value.items.map(sanitizeItem).filter((item) => item != null) : [];
	const selected = Array.isArray(value.selectedTeeth) ? value.selectedTeeth.map(asTooth).filter((tooth) => tooth != null) : teethFromItems(items);
	const discount = Number(value.discount);
	const savedId = clip(value.savedId, 40) || (archive ? uid("inv") : null);
	return {
		invoiceNo: clip(value.invoiceNo, 40) || newInvoiceNo(),
		date: clip(value.date, 40) || todayJalali(),
		patientName: clip(value.patientName, 120),
		doctorId: clip(value.doctorId, 40),
		patientPhone: clip(value.patientPhone, 40),
		patientNotes: clip(value.patientNotes, NOTE_TEXT),
		imageData: sanitizeImage(value.imageData),
		selectedTeeth: TOOTH_ORDER.filter((tooth) => selected.includes(tooth)),
		items,
		discount: Number.isFinite(discount) ? Math.max(0, discount) : 0,
		invoiceNotes: clip(value.invoiceNotes, NOTE_TEXT),
		labCardNumber: clip(value.labCardNumber, 40) || settings.card,
		labShebaNumber: clip(value.labShebaNumber, 40) || settings.sheba,
		savedId: savedId || null
	};
}
function sanitizeDoctor(value) {
	if (!isRecord(value)) return null;
	const name = clip(value.name, 120);
	if (!name) return null;
	return {
		id: clip(value.id, 40) || uid("doc"),
		name,
		color: safeHex(value.color)
	};
}
function parseBackup(data) {
	if (!isRecord(data)) return null;
	if (!Array.isArray(data.doctors) || !Array.isArray(data.invoices)) return null;
	const settings = sanitizeSettings(data.settings);
	const doctors = [];
	const seen = /* @__PURE__ */ new Set();
	for (const raw of data.doctors) {
		const doctor = sanitizeDoctor(raw);
		if (!doctor || seen.has(doctor.id)) continue;
		seen.add(doctor.id);
		doctors.push(doctor);
	}
	return {
		doctors,
		invoices: data.invoices.map((raw) => sanitizeDraft(raw, settings, true)).filter((invoice) => invoice != null),
		settings
	};
}
function fileToInvoiceImage(file) {
	if (!file.type.startsWith("image/")) return Promise.reject(/* @__PURE__ */ new Error("type"));
	if (file.size > 8388608) return Promise.reject(/* @__PURE__ */ new Error("size"));
	return new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.onerror = () => reject(/* @__PURE__ */ new Error("read"));
		reader.onload = () => {
			const source = String(reader.result ?? "");
			const img = new Image();
			img.onload = () => {
				const scale = Math.min(1, 1200 / Math.max(img.width, img.height));
				const canvas = document.createElement("canvas");
				canvas.width = Math.max(1, Math.round(img.width * scale));
				canvas.height = Math.max(1, Math.round(img.height * scale));
				const ctx = canvas.getContext("2d");
				if (!ctx) {
					reject(/* @__PURE__ */ new Error("canvas"));
					return;
				}
				ctx.fillStyle = "#ffffff";
				ctx.fillRect(0, 0, canvas.width, canvas.height);
				ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
				const url = canvas.toDataURL("image/jpeg", .72);
				if (url.length > 15e5) {
					reject(/* @__PURE__ */ new Error("size"));
					return;
				}
				resolve(url);
			};
			img.onerror = () => reject(/* @__PURE__ */ new Error("img"));
			img.src = source;
		};
		reader.readAsDataURL(file);
	});
}
function isMeaningfulDraft(draft) {
	return Boolean(draft.patientName.trim() || draft.items.length || draft.selectedTeeth.length || draft.patientNotes.trim());
}
function sameInvoice(a, b) {
	return JSON.stringify(a) === JSON.stringify(b);
}
var KEY = "armanInvoiceAppV2";
var EMPTY_DRAFT = {
	invoiceNo: "",
	date: "",
	patientName: "",
	doctorId: "",
	patientPhone: "",
	patientNotes: "",
	imageData: "",
	selectedTeeth: [],
	items: [],
	discount: 0,
	invoiceNotes: "",
	labCardNumber: "",
	labShebaNumber: "",
	savedId: null
};
var quotaNotified = false;
function isStep(value) {
	return value === 1 || value === 2 || value === 3 || value === 4;
}
function orderTeeth(teeth) {
	const picked = new Set(teeth.filter((tooth) => TOOTH_ORDER.includes(tooth)));
	return TOOTH_ORDER.filter((tooth) => picked.has(tooth));
}
var useInvoiceStore = create((set, get) => ({
	doctors: [],
	invoices: [],
	settings: DEFAULT_SETTINGS,
	draft: EMPTY_DRAFT,
	step: 1,
	view: "wizard",
	hydrated: false,
	storageWarning: null,
	clearWarning: () => set({ storageWarning: null }),
	persist: () => {
		const { doctors, invoices, settings, draft, step } = get();
		try {
			localStorage.setItem(KEY, JSON.stringify({
				doctors,
				invoices,
				settings,
				draft,
				step
			}));
			return true;
		} catch {
			if (!quotaNotified) {
				quotaNotified = true;
				set({ storageWarning: "فضای ذخیره این مرورگر پر شده. از دکمه پشتیبان یک فایل JSON بگیر." });
			}
			return false;
		}
	},
	hydrate: () => {
		if (get().hydrated) return;
		try {
			const raw = localStorage.getItem(KEY);
			if (!raw) {
				set({
					draft: blankDraft(DEFAULT_SETTINGS),
					hydrated: true
				});
				return;
			}
			const parsed = JSON.parse(raw);
			if (typeof parsed !== "object" || parsed === null) throw new Error("bad");
			const record = parsed;
			const settings = sanitizeSettings(record.settings);
			const backup = parseBackup({
				doctors: record.doctors ?? [],
				invoices: record.invoices ?? [],
				settings
			});
			const doctors = backup?.doctors ?? [];
			const invoices = backup?.invoices ?? [];
			let draft = sanitizeDraft(record.draft, settings, false) ?? blankDraft(settings);
			if (draft.doctorId && !doctors.some((doctor) => doctor.id === draft.doctorId)) draft = {
				...draft,
				doctorId: ""
			};
			set({
				doctors,
				invoices,
				settings,
				draft,
				step: isStep(record.step) ? record.step : 1,
				view: "wizard",
				hydrated: true
			});
		} catch {
			set({
				draft: blankDraft(DEFAULT_SETTINGS),
				hydrated: true
			});
		}
	},
	patchDraft: (partial) => {
		set((state) => ({ draft: {
			...state.draft,
			...partial
		} }));
		get().persist();
	},
	goTo: (step) => {
		if (step === 3) set((state) => ({
			step,
			draft: syncItems(state.draft)
		}));
		else set({ step });
		get().persist();
	},
	openArchive: () => set({ view: "archive" }),
	closeArchive: () => set({ view: "wizard" }),
	toggleTooth: (tooth) => {
		if (!TOOTH_ORDER.includes(tooth)) return;
		set((state) => {
			const selectedTeeth = state.draft.selectedTeeth.includes(tooth) ? state.draft.selectedTeeth.filter((item) => item !== tooth) : orderTeeth([...state.draft.selectedTeeth, tooth]);
			return { draft: {
				...state.draft,
				selectedTeeth
			} };
		});
		get().persist();
	},
	addTeeth: (teeth) => {
		set((state) => ({ draft: {
			...state.draft,
			selectedTeeth: orderTeeth([...state.draft.selectedTeeth, ...teeth])
		} }));
		get().persist();
	},
	setTeeth: (teeth) => {
		set((state) => ({ draft: {
			...state.draft,
			selectedTeeth: orderTeeth(teeth)
		} }));
		get().persist();
	},
	updateItem: (id, partial) => {
		set((state) => {
			const items = state.draft.items.map((item) => {
				if (item.id !== id) return item;
				if (partial.type && Object.keys(partial).length === 1) return applyTypeChange(item, partial.type);
				const next = {
					...item,
					...partial
				};
				next.qty = Math.max(1, Math.min(999, Math.floor(Number(next.qty) || 1)));
				if (next.price !== "") next.price = Math.max(0, Math.min(1e9, Number(next.price) || 0));
				if (next.tooth != null && !TOOTH_ORDER.includes(next.tooth)) next.tooth = null;
				next.description = clip(next.description, 400);
				next.shade = clip(next.shade, 24);
				return next;
			});
			const selectedTeeth = "tooth" in partial ? teethFromItems(items) : state.draft.selectedTeeth;
			return { draft: {
				...state.draft,
				items,
				selectedTeeth
			} };
		});
		get().persist();
	},
	removeItem: (id) => {
		set((state) => {
			const items = state.draft.items.filter((item) => item.id !== id);
			return { draft: {
				...state.draft,
				items,
				selectedTeeth: teethFromItems(items)
			} };
		});
		get().persist();
	},
	addService: () => {
		set((state) => ({ draft: {
			...state.draft,
			items: [...state.draft.items, blankItem(null)]
		} }));
		get().persist();
	},
	saveCurrent: () => {
		const state = get();
		const patientName = state.draft.patientName.trim();
		if (!patientName) return {
			ok: false,
			reason: "نام بیمار را وارد کن."
		};
		if (!state.draft.doctorId) return {
			ok: false,
			reason: "پزشک را انتخاب کن."
		};
		if (!state.draft.items.length) return {
			ok: false,
			reason: "حداقل یک خدمت به فاکتور اضافه کن."
		};
		const savedId = state.draft.savedId ?? uid("inv");
		const draft = {
			...state.draft,
			patientName,
			patientPhone: state.draft.patientPhone.trim(),
			patientNotes: state.draft.patientNotes.trim(),
			invoiceNotes: state.draft.invoiceNotes.trim(),
			savedId
		};
		set({
			draft,
			invoices: [draft, ...state.invoices.filter((invoice) => invoice.savedId !== savedId)]
		});
		if (!get().persist()) return {
			ok: false,
			reason: "فاکتور در حافظه ماند ولی مرورگر جا ندارد. همین حالا پشتیبان بگیر."
		};
		return {
			ok: true,
			invoiceNo: draft.invoiceNo
		};
	},
	startNew: () => {
		set((state) => ({
			draft: blankDraft(state.settings),
			step: 1,
			view: "wizard"
		}));
		get().persist();
	},
	loadInvoice: (id, edit) => {
		const invoice = get().invoices.find((item) => item.savedId === id);
		if (!invoice) return;
		set({
			draft: structuredClone(invoice),
			step: edit ? 1 : 4,
			view: "wizard"
		});
		get().persist();
	},
	deleteInvoice: (id) => {
		set((state) => {
			const deletingOpen = state.draft.savedId === id;
			return {
				invoices: state.invoices.filter((invoice) => invoice.savedId !== id),
				draft: deletingOpen ? blankDraft(state.settings) : state.draft,
				step: deletingOpen ? 1 : state.step,
				view: "archive"
			};
		});
		get().persist();
	},
	addDoctor: (name, color) => {
		const trimmed = name.trim();
		if (!trimmed) return {
			ok: false,
			reason: "نام پزشک را وارد کن."
		};
		const existing = get().doctors.find((doctor) => doctor.name.trim().toLocaleLowerCase("fa") === trimmed.toLocaleLowerCase("fa"));
		if (existing) {
			set((state) => ({ draft: {
				...state.draft,
				doctorId: existing.id
			} }));
			get().persist();
			return {
				ok: true,
				existed: true
			};
		}
		const doctor = {
			id: uid("doc"),
			name: trimmed.slice(0, 120),
			color: safeHex(color)
		};
		set((state) => ({
			doctors: [...state.doctors, doctor],
			draft: {
				...state.draft,
				doctorId: doctor.id
			}
		}));
		get().persist();
		return {
			ok: true,
			existed: false
		};
	},
	saveSettings: (settings) => {
		const next = sanitizeSettings(settings);
		set((state) => {
			const card = !state.draft.labCardNumber || state.draft.labCardNumber === state.settings.card ? next.card : state.draft.labCardNumber;
			const sheba = !state.draft.labShebaNumber || state.draft.labShebaNumber === state.settings.sheba ? next.sheba : state.draft.labShebaNumber;
			return {
				settings: next,
				draft: {
					...state.draft,
					labCardNumber: card,
					labShebaNumber: sheba
				}
			};
		});
		get().persist();
	},
	usePaymentAsDefault: () => {
		set((state) => ({ settings: {
			...state.settings,
			card: state.draft.labCardNumber.trim(),
			sheba: state.draft.labShebaNumber.trim()
		} }));
		get().persist();
	},
	exportPayload: () => {
		const { doctors, invoices, settings, draft } = get();
		let exported = invoices;
		if (draft.patientName.trim() || draft.items.length) {
			const copy = {
				...draft,
				savedId: draft.savedId ?? uid("inv")
			};
			exported = [copy, ...invoices.filter((invoice) => invoice.savedId !== draft.savedId && invoice.savedId !== copy.savedId)];
		}
		return {
			format: "arman-invoice-backup",
			version: 2,
			exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
			doctors,
			invoices: exported,
			settings
		};
	},
	replaceAll: (data) => {
		set({
			doctors: data.doctors,
			invoices: data.invoices,
			settings: data.settings,
			draft: blankDraft(data.settings),
			step: 1,
			view: "wizard"
		});
		return get().persist();
	}
}));
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function Button({ variant = "ghost", className, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: cn("inline-flex h-11 items-center justify-center gap-2 rounded-xl px-4 text-sm font-bold transition disabled:cursor-not-allowed disabled:opacity-50", variant === "primary" && "bg-primary text-on-primary", variant === "ghost" && "border border-line bg-surface text-ink", variant === "soft" && "bg-primary-soft text-primary-ink", variant === "danger" && "bg-danger-soft text-danger", className),
		...props
	});
}
function Field({ label, hint, required, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "flex min-w-0 flex-col gap-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "text-sm font-bold text-ink",
			children: [
				label,
				required ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-primary",
					children: " *"
				}) : null,
				hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "font-normal text-muted",
					children: [" ", hint]
				}) : null
			]
		}), children]
	});
}
var control = "h-11 w-full min-w-0 rounded-xl border border-line bg-surface px-3 text-ink outline-none";
function TextInput(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		...props,
		className: cn(control, props.className)
	});
}
function TextArea(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		...props,
		className: cn(control, "min-h-24 py-2", props.className)
	});
}
function SelectInput(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
		...props,
		className: cn(control, props.className)
	});
}
function Panel({ eyebrow, title, text, aside, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-3xl border border-line bg-surface p-4 shadow-sm sm:p-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-5 flex flex-wrap items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-extrabold text-primary",
					children: eyebrow
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-1 text-xl font-extrabold",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-pretty text-muted",
					children: text
				})
			] }), aside]
		}), children]
	});
}
function Modal({ open, onOpenChange, title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "no-print fixed inset-0 z-40 bg-ink/40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "no-print fixed inset-x-4 top-16 z-50 mx-auto max-h-[80vh] max-w-xl overflow-y-auto rounded-3xl border border-line bg-surface p-5 shadow-xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
					className: "text-lg font-extrabold",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
					className: "grid size-11 place-items-center rounded-xl bg-canvas",
					"aria-label": "بستن",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
				})]
			}), children]
		})] })
	});
}
function DoctorDialog({ open, onOpenChange }) {
	const addDoctor = useInvoiceStore((state) => state.addDoctor);
	const [name, setName] = (0, import_react.useState)("");
	const [color, setColor] = (0, import_react.useState)(DOCTOR_COLORS[0]);
	const [error, setError] = (0, import_react.useState)("");
	function save() {
		const result = addDoctor(name, color);
		if (!result.ok) {
			setError(result.reason);
			return;
		}
		setName("");
		setColor(DOCTOR_COLORS[0]);
		setError("");
		onOpenChange(false);
		toast.success(result.existed ? "این پزشک قبلاً ثبت شده بود و انتخاب شد." : "پزشک جدید ذخیره شد.");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		open,
		title: "ثبت پزشک جدید",
		onOpenChange: (next) => {
			if (!next) setError("");
			onOpenChange(next);
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "flex flex-col gap-4",
			onSubmit: (event) => {
				event.preventDefault();
				save();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "نام پزشک",
					required: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						value: name,
						onChange: (event) => setName(event.target.value),
						placeholder: "نام و نام خانوادگی پزشک",
						autoComplete: "off"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-sm font-bold",
						children: "رنگ نوار فاکتور این پزشک"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: DOCTOR_COLORS.map((swatch) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": `رنگ ${swatch}`,
							"aria-pressed": color === swatch,
							onClick: () => setColor(swatch),
							className: cn("size-9 rounded-full", color === swatch && "ring-2 ring-ink ring-offset-2"),
							style: { backgroundColor: swatch }
						}, swatch))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs text-muted",
						children: "رنگ فقط روی فاکتورهای همین پزشک می‌آید و قالب برنامه ثابت می‌ماند."
					})
				] }),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-danger",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-end gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						onClick: () => onOpenChange(false),
						children: "انصراف"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						variant: "primary",
						children: "ذخیره پزشک"
					})]
				})
			]
		})
	});
}
function SettingsDialog({ open, onOpenChange }) {
	const settings = useInvoiceStore((state) => state.settings);
	const saveSettings = useInvoiceStore((state) => state.saveSettings);
	const [labName, setLabName] = (0, import_react.useState)(settings.labName);
	const [manager, setManager] = (0, import_react.useState)(settings.manager);
	const [card, setCard] = (0, import_react.useState)(settings.card);
	const [sheba, setSheba] = (0, import_react.useState)(settings.sheba);
	const [defaultNote, setDefaultNote] = (0, import_react.useState)(settings.defaultNote);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		setLabName(settings.labName);
		setManager(settings.manager);
		setCard(settings.card);
		setSheba(settings.sheba);
		setDefaultNote(settings.defaultNote);
	}, [open, settings]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		open,
		onOpenChange,
		title: "تنظیمات لابراتوار",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "grid gap-4 sm:grid-cols-2",
			onSubmit: (event) => {
				event.preventDefault();
				saveSettings({
					labName,
					manager,
					card,
					sheba,
					defaultNote
				});
				toast.success("تنظیمات ذخیره شد.");
				onOpenChange(false);
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "نام لابراتوار",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						value: labName,
						onChange: (event) => setLabName(event.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "نام / امضای مدیریت",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						value: manager,
						onChange: (event) => setManager(event.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "شماره کارت",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						value: card,
						onChange: (event) => setCard(event.target.value),
						dir: "ltr",
						className: "text-left",
						inputMode: "numeric"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "شماره شبا",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						value: sheba,
						onChange: (event) => setSheba(event.target.value),
						dir: "ltr",
						className: "text-left",
						placeholder: "IR..."
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "sm:col-span-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "متن پیش‌فرض پایین فاکتور",
						hint: "(اختیاری)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							value: defaultNote,
							onChange: (event) => setDefaultNote(event.target.value),
							placeholder: "با تشکر از اعتماد شما"
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-end gap-2 sm:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						onClick: () => onOpenChange(false),
						children: "انصراف"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						variant: "primary",
						children: "ذخیره تنظیمات"
					})]
				})
			]
		})
	});
}
function ConfirmDialog({ open, title, body, confirmLabel, onConfirm, onOpenChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
		open,
		onOpenChange,
		title,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-pretty text-muted",
			children: body
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-5 flex justify-end gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => onOpenChange(false),
				children: "انصراف"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "danger",
				onClick: () => {
					onConfirm();
					onOpenChange(false);
				},
				children: confirmLabel
			})]
		})]
	});
}
function InvoiceSheet() {
	const draft = useInvoiceStore((state) => state.draft);
	const settings = useInvoiceStore((state) => state.settings);
	const doctor = useInvoiceStore((state) => state.doctors.find((item) => item.id === state.draft.doctorId) ?? null);
	const color = doctor ? safeHex(doctor.color) : void 0;
	const sum = totals(draft.items, draft.discount);
	const note = draft.invoiceNotes.trim() || settings.defaultNote || "—";
	const pad = Math.max(0, Math.min(2, 4 - draft.items.length));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "sheet",
		style: color ? { "--sheet-accent": color } : void 0,
		"aria-label": "پیش‌نمایش فاکتور قابل چاپ",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sheet-top",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "sheet-brand",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sheet-logo",
						children: "آ"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "sheet-lab",
						children: settings.labName
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "sheet-tagline",
						children: "ساخت و ترمیم روکش و خدمات لابراتواری دندان"
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "sheet-id",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: "فاکتور خدمات لابراتوار" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["شماره: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: draft.invoiceNo || "—" })] })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "sheet-meta",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "تاریخ" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: draft.date || "—" })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "پزشک" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: doctor?.name || "—" })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "مدیریت" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: settings.manager || "—" })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "تعداد دندان" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: faNum(draft.selectedTeeth.length) })] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "sheet-patient",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "نام بیمار: " }), draft.patientName || "—"] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "شماره تماس: " }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "num",
						children: draft.patientPhone || "—"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "دندان‌ها: " }), draft.selectedTeeth.length ? draft.selectedTeeth.join("، ") : "—"] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "توضیحات سفارش: " }), draft.patientNotes || "—"] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "sheet-table-wrap",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "ردیف" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "دندان" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "شرح خدمات / نوع روکش" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "رنگ" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "تعداد" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "قیمت واحد" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "جمع (تومان)" })
				] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [draft.items.length ? draft.items.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: faNum(index + 1) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "num",
						children: item.tooth ?? "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: lineTitle(item) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: item.shade || "—" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: faNum(item.qty) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "num",
						children: item.price === "" ? "—" : faNum(item.price)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "num",
						children: item.price === "" ? "—" : faNum(lineAmount(item))
					})
				] }, item.id)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					colSpan: 7,
					children: "خدمتی ثبت نشده است."
				}) }), Array.from({ length: pad }, (_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: " " }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: " " }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: " " }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: " " }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: " " }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: " " }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: " " })
				] }, `blank-${index}`))] })] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "sheet-bottom",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "sheet-pay",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", { children: "اطلاعات پرداخت" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "شماره کارت: " }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "num",
							children: formatPayId(draft.labCardNumber)
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "شماره شبا: " }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "num",
							children: draft.labShebaNumber.trim() || "—"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "توضیحات: " }), note] })
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "sheet-totals",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "جمع خدمات" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
							className: "num",
							children: [faNum(sum.subtotal), " تومان"]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تخفیف" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
							className: "num",
							children: [faNum(sum.discount), " تومان"]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "مبلغ قابل پرداخت" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
							className: "num",
							children: [faNum(sum.total), " تومان"]
						})] })
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "sheet-foot",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "امضای تحویل‌گیرنده: ................................" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["مهر و امضای لابراتوار: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: settings.manager })] })]
			})
		]
	});
}
var SLOT = 46;
var MID_GAP = 26;
var WIDTH = 820;
var LEFT = 52;
function point(index, which) {
	const x = LEFT + index * SLOT + (index >= 8 ? MID_GAP : 0);
	const t = index / 15;
	const bow = Math.sin(Math.PI * t);
	const y = which === "upper" ? 92 + bow * 112 : 438 - bow * 112;
	const fan = (t - .5) * 46;
	return {
		x,
		y,
		rot: which === "upper" ? fan : 180 + fan
	};
}
function kindOf(num) {
	const digit = num % 10;
	if (digit >= 6) return "molar";
	if (digit >= 4) return "premolar";
	if (digit === 3) return "canine";
	return "incisor";
}
function Shape({ kind }) {
	if (kind === "molar") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
		className: "tooth-face",
		x: "-16",
		y: "-18",
		width: "32",
		height: "36",
		rx: "8"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		className: "tooth-groove",
		d: "M -7 -8 L 7 8 M 7 -8 L -7 8"
	})] });
	if (kind === "premolar") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
		className: "tooth-face",
		x: "-12",
		y: "-16",
		width: "24",
		height: "32",
		rx: "8"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		className: "tooth-groove",
		d: "M 0 -10 L 0 10"
	})] });
	if (kind === "canine") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		className: "tooth-face",
		d: "M 0 -18 C 10 -16 12 -4 9 16 C 6 18 -6 18 -9 16 C -12 -4 -10 -16 0 -18 Z"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		className: "tooth-groove",
		d: "M 0 -8 L 0 10"
	})] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
		className: "tooth-face",
		x: "-8",
		y: "-16",
		width: "16",
		height: "32",
		rx: "6"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		className: "tooth-groove",
		d: "M -5 0 L 5 0"
	})] });
}
function Arch({ which, teeth, selected, onToggle }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: teeth.map((num, index) => {
		const { x, y, rot } = point(index, which);
		const on = selected.includes(num);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
			className: cn("tooth", on && "is-on"),
			transform: `translate(${x} ${y})`,
			tabIndex: 0,
			role: "button",
			"aria-pressed": on,
			"aria-label": `دندان ${num}`,
			onClick: () => onToggle(num),
			onKeyDown: (event) => {
				if (event.key === "Enter" || event.key === " ") {
					event.preventDefault();
					onToggle(num);
				}
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
				transform: `rotate(${rot})`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "-20",
					y: "-24",
					width: "40",
					height: "48",
					fill: "transparent"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shape, { kind: kindOf(num) })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				className: "tooth-label",
				y: which === "upper" ? -30 : 36,
				textAnchor: "middle",
				children: num
			})]
		}, num);
	}) });
}
function Odontogram({ selected, onToggle }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-w-0 max-w-full overflow-x-auto rounded-2xl border border-line bg-canvas",
		dir: "ltr",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			width: WIDTH,
			height: "520",
			viewBox: `0 0 ${WIDTH} 520`,
			role: "group",
			"aria-label": "نمودار دندان‌ها",
			className: "block touch-manipulation",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: "410",
					y1: "28",
					x2: "410",
					y2: "214",
					stroke: "var(--color-line)",
					strokeDasharray: "3 6"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: "410",
					y1: "318",
					x2: "410",
					y2: "492",
					stroke: "var(--color-line)",
					strokeDasharray: "3 6"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
					className: "arch-label",
					x: "410",
					y: "252",
					textAnchor: "middle",
					style: { direction: "rtl" },
					children: "فک بالا"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
					className: "arch-label",
					x: "410",
					y: "286",
					textAnchor: "middle",
					style: { direction: "rtl" },
					children: "فک پایین"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Arch, {
					which: "upper",
					teeth: UPPER_TEETH,
					selected,
					onToggle
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Arch, {
					which: "lower",
					teeth: LOWER_TEETH,
					selected,
					onToggle
				})
			]
		})
	});
}
function moneyText(value) {
	return value === "" ? "" : String(value);
}
function StagePatient() {
	const draft = useInvoiceStore((state) => state.draft);
	const doctors = useInvoiceStore((state) => state.doctors);
	const patchDraft = useInvoiceStore((state) => state.patchDraft);
	const goTo = useInvoiceStore((state) => state.goTo);
	const [doctorOpen, setDoctorOpen] = (0, import_react.useState)(false);
	const doctor = doctors.find((item) => item.id === draft.doctorId);
	async function onImage(file) {
		if (!file) return;
		try {
			patchDraft({ imageData: await fileToInvoiceImage(file) });
		} catch (error) {
			const reason = error instanceof Error ? error.message : "";
			toast.error(reason === "size" ? "حجم تصویر زیاد است؛ یکی کوچک‌تر انتخاب کن." : "این تصویر قابل استفاده نیست.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		eyebrow: "مرحله ۱ از ۴",
		title: "مشخصات بیمار و پزشک",
		text: "هر فاکتور برای یک بیمار است. نام بیمار و پزشک برای ادامه لازم‌اند.",
		aside: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "rounded-full bg-primary-soft px-3 py-1 text-xs font-bold text-primary-ink",
			children: draft.savedId ? "ذخیره‌شده" : "فاکتور جدید"
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "نام بیمار",
						required: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							value: draft.patientName,
							autoComplete: "off",
							placeholder: "نام و نام خانوادگی",
							onChange: (event) => patchDraft({ patientName: event.target.value })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "نام پزشک",
						required: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectInput, {
								value: draft.doctorId,
								onChange: (event) => patchDraft({ doctorId: event.target.value }),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "انتخاب پزشک"
								}), doctors.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: item.id,
									children: item.name
								}, item.id))]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "soft",
								onClick: () => setDoctorOpen(true),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "پزشک"]
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "تاریخ فاکتور",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							value: draft.date,
							onChange: (event) => patchDraft({ date: event.target.value })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "شماره تماس بیمار",
						hint: "(اختیاری)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							value: draft.patientPhone,
							inputMode: "tel",
							dir: "ltr",
							className: "text-left",
							placeholder: "09...",
							onChange: (event) => patchDraft({ patientPhone: event.target.value })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "شماره فاکتور",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							value: draft.invoiceNo,
							readOnly: true,
							dir: "ltr",
							className: "text-left"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-end gap-2 text-sm text-muted",
						children: doctor ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "mb-3 inline-flex items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "size-3.5 rounded-full",
									style: { backgroundColor: doctor.color }
								}),
								"رنگ فاکتور ",
								doctor.name
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mb-3",
							children: "اگر پزشک در فهرست نیست، اول ثبتش کن."
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "توضیحات سفارش",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextArea, {
								value: draft.patientNotes,
								placeholder: "توضیح مربوط به سفارش یا بیمار",
								onChange: (event) => patchDraft({ patientNotes: event.target.value })
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-3 rounded-2xl border border-dashed border-line bg-canvas p-4 sm:flex-row sm:items-center sm:justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "flex items-center gap-2 font-bold",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "size-4" }), " تصویر بیمار یا سفارش"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted",
									children: "اختیاری است و روی فاکتور چاپ نمی‌شود. برای مراجعه بعدی کنار همین فاکتور می‌ماند."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "mt-3 block max-w-full text-sm",
									type: "file",
									accept: "image/*",
									onChange: (event) => {
										onImage(event.target.files?.[0]);
										event.target.value = "";
									}
								})
							] }), draft.imageData ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: draft.imageData,
									alt: "پیش‌نمایش تصویر سفارش",
									className: "h-20 w-28 rounded-lg object-cover"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "danger",
									onClick: () => patchDraft({ imageData: "" }),
									children: "حذف"
								})]
							}) : null]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex items-center justify-between gap-3 border-t border-line pt-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: "موارد ستاره‌دار لازم‌اند."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "primary",
					onClick: () => {
						const name = draft.patientName.trim();
						if (!name) {
							toast.error("نام بیمار را وارد کن.");
							return;
						}
						if (!draft.doctorId) {
							toast.error("پزشک را انتخاب کن یا پزشک جدید ثبت کن.");
							return;
						}
						patchDraft({
							patientName: name,
							patientPhone: draft.patientPhone.trim(),
							patientNotes: draft.patientNotes.trim()
						});
						goTo(2);
					},
					children: "ادامه: انتخاب دندان‌ها"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DoctorDialog, {
				open: doctorOpen,
				onOpenChange: setDoctorOpen
			})
		]
	});
}
function StageTeeth() {
	const selected = useInvoiceStore((state) => state.draft.selectedTeeth);
	const toggleTooth = useInvoiceStore((state) => state.toggleTooth);
	const addTeeth = useInvoiceStore((state) => state.addTeeth);
	const setTeeth = useInvoiceStore((state) => state.setTeeth);
	const goTo = useInvoiceStore((state) => state.goTo);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		eyebrow: "مرحله ۲ از ۴",
		title: "دندان‌ها را انتخاب کن",
		text: "شماره‌ها سیستم FDI است: سمت چپ نمودار، راست بیمار است. اگر خدمت به دندان خاصی وصل نیست، بدون انتخاب ادامه بده.",
		aside: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "rounded-full bg-primary-soft px-3 py-1 text-xs font-bold text-primary-ink",
			children: [faNum(selected.length), " دندان"]
		}),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 md:grid-cols-[minmax(0,1fr)_18rem]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuadrantPad, {
						selected,
						onToggle: toggleTooth
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "hidden md:block",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Odontogram, {
							selected,
							onToggle: toggleTooth
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap items-center justify-center gap-4 text-xs text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-3.5 rounded border border-line bg-surface" }), "انتخاب‌نشده"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-3.5 rounded bg-primary" }), "انتخاب‌شده"]
						})]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "rounded-2xl border border-line p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-extrabold",
						children: "دندان‌های انتخاب‌شده"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "در مرحله بعد برای هر دندان نوع کار، رنگ و قیمت جدا می‌نویسی."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex items-center justify-between rounded-xl bg-canvas px-3 py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تعداد" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: faNum(selected.length) })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 flex max-h-40 min-h-12 flex-wrap gap-2 overflow-y-auto",
						dir: "ltr",
						children: selected.length ? selected.map((tooth) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "rounded-lg bg-primary-soft px-2 py-1 text-sm font-extrabold text-primary-ink",
							onClick: () => toggleTooth(tooth),
							children: [tooth, " ×"]
						}, tooth)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "هنوز دندانی انتخاب نشده."
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: () => addTeeth(UPPER_TEETH),
								children: "فک بالا"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: () => addTeeth(LOWER_TEETH),
								children: "فک پایین"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: () => setTeeth(TOOTH_ORDER),
								children: "همه"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: () => setTeeth([]),
								children: "پاک کردن"
							})
						]
					})
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 flex items-center justify-between gap-3 border-t border-line pt-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => goTo(1),
				children: "بازگشت"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "primary",
				onClick: () => goTo(3),
				children: "ادامه: نوع کار و قیمت"
			})]
		})]
	});
}
function QuadrantPad({ selected, onToggle }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid gap-3 md:hidden",
		dir: "ltr",
		children: [
			["بالا، راست بیمار", UPPER_RIGHT],
			["بالا، چپ بیمار", UPPER_LEFT],
			["پایین، راست بیمار", LOWER_RIGHT],
			["پایین، چپ بیمار", LOWER_LEFT]
		].map(([title, teeth]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-2xl border border-line bg-canvas p-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 text-xs font-bold text-muted",
				dir: "rtl",
				children: title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-4 gap-2",
				children: teeth.map((tooth) => {
					const on = selected.includes(tooth);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-pressed": on,
						onClick: () => onToggle(tooth),
						className: cn("h-11 rounded-xl border text-sm font-extrabold", on ? "border-primary bg-primary text-on-primary" : "border-line bg-surface text-ink"),
						children: tooth
					}, tooth);
				})
			})]
		}, title))
	});
}
function StageItems() {
	const draft = useInvoiceStore((state) => state.draft);
	const updateItem = useInvoiceStore((state) => state.updateItem);
	const removeItem = useInvoiceStore((state) => state.removeItem);
	const addService = useInvoiceStore((state) => state.addService);
	const patchDraft = useInvoiceStore((state) => state.patchDraft);
	const goTo = useInvoiceStore((state) => state.goTo);
	const sum = totals(draft.items, draft.discount);
	const missingPrice = draft.items.some((item) => item.price === "");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		eyebrow: "مرحله ۳ از ۴",
		title: "جزئیات سفارش و قیمت",
		text: "قیمت‌ها به تومان است. فقط پست، قالب ایمپلنت و لایرینگ قیمت پیشنهادی دارند؛ بقیه را خودت وارد کن.",
		aside: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "rounded-full bg-canvas px-3 py-1 text-xs font-bold",
			children: [faNum(draft.items.length), " ردیف"]
		}),
		children: [
			draft.items.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "hidden grid-cols-12 gap-2 px-1 text-xs font-bold text-muted md:grid",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "col-span-2",
							children: "دندان"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "col-span-3",
							children: "نوع کار"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "col-span-2",
							children: "رنگ"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "col-span-1",
							children: "تعداد"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "col-span-2",
							children: "قیمت واحد"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "col-span-1",
							children: "جمع"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "col-span-1",
							children: "حذف"
						})
					]
				}), draft.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemRow, {
					item,
					onChange: (partial) => updateItem(item.id, partial),
					onRemove: () => removeItem(item.id)
				}, item.id))]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-2xl border border-dashed border-line px-4 py-8 text-center text-sm text-muted",
				children: "هنوز ردیفی نیست. برگرد و دندان انتخاب کن، یا یک خدمت بدون شماره دندان اضافه کن."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "soft",
					onClick: addService,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "افزودن خدمت دیگر"]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 grid gap-4 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "تخفیف فاکتور (تومان)",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						value: draft.discount ? String(draft.discount) : "",
						inputMode: "numeric",
						dir: "ltr",
						className: "text-left tabular-nums",
						placeholder: "0",
						onChange: (event) => {
							const parsed = parseMoney(event.target.value);
							patchDraft({ discount: parsed === "" ? 0 : parsed });
						}
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "یادداشت روی فاکتور",
					hint: "(اختیاری)",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						value: draft.invoiceNotes,
						placeholder: "مثلاً زمان تحویل",
						onChange: (event) => patchDraft({ invoiceNotes: event.target.value })
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid gap-2 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Total, {
						label: "جمع خدمات",
						value: faNum(sum.subtotal)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Total, {
						label: "تخفیف",
						value: faNum(sum.discount)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Total, {
						label: "قابل پرداخت",
						value: faNum(sum.total),
						strong: true
					})
				]
			}),
			missingPrice ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-xs text-muted",
				children: "بعضی ردیف‌ها هنوز قیمت ندارند و در فاکتور با خط تیره می‌آیند."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex items-center justify-between gap-3 border-t border-line pt-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => goTo(2),
					children: "بازگشت"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "primary",
					onClick: () => {
						if (!draft.items.length) {
							toast.error("حداقل یک خدمت یا دندان اضافه کن.");
							return;
						}
						goTo(4);
						if (missingPrice) toast("بعضی ردیف‌ها هنوز قیمت ندارند.");
					},
					children: "ادامه: پیش‌نمایش فاکتور"
				})]
			})
		]
	});
}
function Total({ label, value, strong }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("rounded-2xl border border-line px-3 py-2", strong && "border-primary bg-primary-soft"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-lg font-extrabold tabular-nums",
			dir: "ltr",
			children: value
		})]
	});
}
function ItemRow({ item, onChange, onRemove }) {
	const shades = item.shade && !SHADES.includes(item.shade) ? [item.shade, ...SHADES] : SHADES;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-3 rounded-2xl border border-line p-3 md:grid-cols-12 md:items-start md:rounded-none md:border-x-0 md:border-t-0 md:px-1",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "md:col-span-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mb-1 block text-xs font-bold text-muted md:sr-only",
					children: "دندان"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectInput, {
					value: item.tooth ?? "",
					onChange: (event) => onChange({ tooth: event.target.value ? Number(event.target.value) : null }),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "—"
					}), TOOTH_ORDER.map((tooth) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: tooth,
						children: tooth
					}, tooth))]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2 md:col-span-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectInput, {
					value: item.type,
					"aria-label": "نوع کار",
					onChange: (event) => onChange({ type: event.target.value }),
					children: WORK_TYPES.map((type) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: type.id,
						children: type.label
					}, type.id))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
					value: item.description,
					placeholder: "توضیح دلخواه",
					"aria-label": "توضیح خدمت",
					onChange: (event) => onChange({ description: event.target.value })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "md:col-span-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mb-1 block text-xs font-bold text-muted md:sr-only",
					children: "رنگ"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectInput, {
					value: item.shade,
					onChange: (event) => onChange({ shade: event.target.value }),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "انتخاب رنگ"
					}), shades.map((shade) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: shade,
						children: shade
					}, shade))]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "md:col-span-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mb-1 block text-xs font-bold text-muted md:sr-only",
					children: "تعداد"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
					value: String(item.qty),
					inputMode: "numeric",
					dir: "ltr",
					className: "text-center tabular-nums",
					"aria-label": "تعداد",
					onChange: (event) => onChange({ qty: parseQty(event.target.value) })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "md:col-span-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mb-1 block text-xs font-bold text-muted md:sr-only",
					children: "قیمت واحد"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
					value: moneyText(item.price),
					inputMode: "numeric",
					dir: "ltr",
					className: "text-left tabular-nums",
					placeholder: "تومان",
					"aria-label": "قیمت واحد",
					onWheel: (event) => event.currentTarget.blur(),
					onChange: (event) => onChange({ price: parseMoney(event.target.value) })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "md:col-span-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted md:sr-only",
					children: "جمع"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "flex h-11 items-center text-sm font-extrabold tabular-nums",
					dir: "ltr",
					children: item.price === "" ? "—" : faNum(lineAmount(item))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "md:col-span-1",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "danger",
					className: "w-full px-0 md:w-11",
					"aria-label": "حذف ردیف",
					onClick: onRemove,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
				})
			})
		]
	});
}
function StageReview() {
	const draft = useInvoiceStore((state) => state.draft);
	const invoices = useInvoiceStore((state) => state.invoices);
	const doctor = useInvoiceStore((state) => state.doctors.find((item) => item.id === draft.doctorId) ?? null);
	const patchDraft = useInvoiceStore((state) => state.patchDraft);
	const saveCurrent = useInvoiceStore((state) => state.saveCurrent);
	const startNew = useInvoiceStore((state) => state.startNew);
	const goTo = useInvoiceStore((state) => state.goTo);
	const usePaymentAsDefault = useInvoiceStore((state) => state.usePaymentAsDefault);
	const sum = totals(draft.items, draft.discount);
	const [confirmNew, setConfirmNew] = (0, import_react.useState)(false);
	const saved = (0, import_react.useMemo)(() => invoices.find((invoice) => invoice.savedId && invoice.savedId === draft.savedId), [invoices, draft.savedId]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		eyebrow: "مرحله ۴ از ۴",
		title: "بررسی، ذخیره و چاپ",
		text: "پیش‌نمایش پایین همان چیزی است که روی برگه A4 چاپ می‌شود. اول ذخیره کن، بعد چاپ.",
		aside: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "rounded-full bg-primary-soft px-3 py-1 text-xs font-bold text-primary-ink",
			children: "آماده چاپ"
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-[minmax(0,1fr)_20rem]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-line p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-extrabold",
							children: "خلاصه سفارش"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "mt-3 grid gap-3 sm:grid-cols-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Summary, {
									label: "بیمار",
									value: draft.patientName || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Summary, {
									label: "پزشک",
									value: doctor?.name || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Summary, {
									label: "تاریخ",
									value: draft.date || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Summary, {
									label: "شماره",
									value: draft.invoiceNo || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Summary, {
									label: "دندان‌ها",
									value: draft.selectedTeeth.length ? draft.selectedTeeth.join("، ") : "بدون شماره"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Summary, {
									label: "مبلغ نهایی",
									value: `${faNum(sum.total)} تومان`
								})
							]
						}),
						draft.imageData ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: draft.imageData,
							alt: "تصویر همراه سفارش",
							className: "mt-4 h-28 rounded-xl object-cover"
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-xs text-pretty text-muted",
							children: "اطلاعات فقط روی همین دستگاه می‌ماند. برای جابه‌جایی، از دکمه پشتیبان فایل JSON بگیر."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-line p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mb-3 font-extrabold",
						children: "عملیات"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "شماره کارت لابراتوار",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
									value: draft.labCardNumber,
									dir: "ltr",
									className: "text-left",
									placeholder: "شماره کارت",
									onChange: (event) => patchDraft({ labCardNumber: event.target.value })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "شماره شبا",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
									value: draft.labShebaNumber,
									dir: "ltr",
									className: "text-left",
									placeholder: "IR...",
									onChange: (event) => patchDraft({ labShebaNumber: event.target.value })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: () => {
									usePaymentAsDefault();
									toast.success("شماره کارت و شبا برای فاکتورهای بعدی پیش‌فرض شد.");
								},
								children: "ثبت به عنوان پیش‌فرض پرداخت"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "primary",
								onClick: () => {
									const result = saveCurrent();
									if (!result.ok) toast.error(result.reason);
									else toast.success(`فاکتور ${result.invoiceNo} ذخیره شد.`);
								},
								children: "ذخیره فاکتور"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "primary",
								onClick: () => window.print(),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4" }), "چاپ یا ذخیره PDF"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: () => goTo(3),
								children: "ویرایش قیمت‌ها"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: () => {
									if (isMeaningfulDraft(draft) && (!saved || !sameInvoice(saved, draft))) setConfirmNew(true);
									else startNew();
								},
								children: "فاکتور جدید"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: draft.savedId ? `این فاکتور ذخیره شده: ${draft.invoiceNo}` : "هنوز ذخیره نشده است."
							}),
							draft.labCardNumber ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								dir: "ltr",
								children: formatPayId(draft.labCardNumber)
							}) : null
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => goTo(3),
					children: "بازگشت به قیمت‌ها"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmNew,
				title: "فاکتور جدید",
				body: "تغییرهای ذخیره‌نشده این فاکتور کنار گذاشته شود؟",
				confirmLabel: "کنار گذاشتن",
				onOpenChange: setConfirmNew,
				onConfirm: startNew
			})
		]
	});
}
function Summary({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-w-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-xs text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "font-bold break-words",
			children: value
		})]
	});
}
function ArchiveView() {
	const invoices = useInvoiceStore((state) => state.invoices);
	const doctors = useInvoiceStore((state) => state.doctors);
	const loadInvoice = useInvoiceStore((state) => state.loadInvoice);
	const deleteInvoice = useInvoiceStore((state) => state.deleteInvoice);
	const closeArchive = useInvoiceStore((state) => state.closeArchive);
	const [query, setQuery] = (0, import_react.useState)("");
	const [pendingId, setPendingId] = (0, import_react.useState)(null);
	const filtered = invoices.filter((invoice) => {
		const doctor = doctors.find((item) => item.id === invoice.doctorId);
		return `${invoice.patientName} ${invoice.invoiceNo} ${invoice.patientPhone} ${doctor?.name ?? ""}`.toLocaleLowerCase("fa").includes(query.trim().toLocaleLowerCase("fa"));
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		eyebrow: "بایگانی",
		title: "فاکتورهای ذخیره‌شده",
		text: "هر ردیف یک فاکتور جدا برای یک بیمار است. جستجو روی نام، شماره و پزشک کار می‌کند.",
		aside: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			onClick: closeArchive,
			children: "بازگشت به فاکتور"
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
				value: query,
				onChange: (event) => setQuery(event.target.value),
				placeholder: "جستجوی بیمار، پزشک یا شماره فاکتور"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 flex flex-col gap-3",
				children: filtered.length ? filtered.map((invoice) => {
					const doctor = doctors.find((item) => item.id === invoice.doctorId);
					const sum = totals(invoice.items, invoice.discount);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "flex flex-col gap-3 rounded-2xl border border-line p-3 sm:flex-row sm:items-center sm:justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex min-w-0 items-center gap-3",
							children: [invoice.imageData ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: invoice.imageData,
								alt: "",
								className: "size-14 rounded-lg object-cover"
							}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
									className: "font-extrabold",
									children: [
										invoice.patientName || "بدون نام",
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-bold text-muted",
											children: invoice.invoiceNo
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted",
									children: [
										"پزشک: ",
										doctor?.name || "—",
										" · ",
										invoice.date || "—",
										" · ",
										faNum(sum.total),
										" تومان"
									]
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									onClick: () => loadInvoice(invoice.savedId || "", false),
									children: "مشاهده / چاپ"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									onClick: () => loadInvoice(invoice.savedId || "", true),
									children: "ویرایش"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "danger",
									onClick: () => setPendingId(invoice.savedId),
									children: "حذف"
								})
							]
						})]
					}, invoice.savedId);
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rounded-2xl border border-dashed border-line px-4 py-10 text-center text-sm text-muted",
					children: invoices.length ? "چیزی با این جستجو پیدا نشد." : "هنوز فاکتوری ذخیره نشده است."
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: pendingId != null,
				title: "حذف فاکتور",
				body: "این فاکتور از حافظه همین مرورگر پاک شود؟",
				confirmLabel: "حذف",
				onOpenChange: (open) => {
					if (!open) setPendingId(null);
				},
				onConfirm: () => {
					if (pendingId) deleteInvoice(pendingId);
					toast.success("فاکتور حذف شد.");
				}
			})
		]
	});
}
var STEPS = [
	{
		n: 1,
		short: "بیمار",
		title: "اطلاعات بیمار"
	},
	{
		n: 2,
		short: "دندان",
		title: "انتخاب دندان"
	},
	{
		n: 3,
		short: "قیمت",
		title: "جزئیات و قیمت"
	},
	{
		n: 4,
		short: "چاپ",
		title: "فاکتور نهایی"
	}
];
function InvoiceApp() {
	const hydrated = useInvoiceStore((state) => state.hydrated);
	const hydrate = useInvoiceStore((state) => state.hydrate);
	const warning = useInvoiceStore((state) => state.storageWarning);
	const clearWarning = useInvoiceStore((state) => state.clearWarning);
	(0, import_react.useEffect)(() => {
		hydrate();
	}, [hydrate]);
	(0, import_react.useEffect)(() => {
		if (!warning) return;
		toast.error(warning);
		clearWarning();
	}, [warning, clearWarning]);
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-screen place-items-center px-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto grid size-14 place-items-center rounded-2xl bg-primary text-xl font-extrabold text-on-primary",
					children: "آ"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 font-bold",
					children: "فاکتورساز آرمان"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "در حال باز کردن پرونده‌ها…"
				})
			]
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {});
}
function Shell() {
	const step = useInvoiceStore((state) => state.step);
	const view = useInvoiceStore((state) => state.view);
	const openArchive = useInvoiceStore((state) => state.openArchive);
	const exportPayload = useInvoiceStore((state) => state.exportPayload);
	const replaceAll = useInvoiceStore((state) => state.replaceAll);
	const [settingsOpen, setSettingsOpen] = (0, import_react.useState)(false);
	const [pendingBackup, setPendingBackup] = (0, import_react.useState)(null);
	const fileRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		window.scrollTo(0, 0);
	}, [step, view]);
	function downloadBackup() {
		const payload = exportPayload();
		const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json;charset=utf-8" });
		const url = URL.createObjectURL(blob);
		const link = document.createElement("a");
		link.href = url;
		link.download = `arman-invoice-backup-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.json`;
		document.body.appendChild(link);
		link.click();
		link.remove();
		URL.revokeObjectURL(url);
		toast.success("فایل پشتیبان آماده شد. اطلاعات بیماران داخلش است.");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "no-print mx-auto flex w-full max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid size-12 place-items-center rounded-2xl bg-primary text-lg font-extrabold text-on-primary",
						children: "آ"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-xl font-extrabold leading-tight",
						children: "فاکتورساز آرمان"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: "لابراتوار دندانسازی · ثبت مرحله‌ای فاکتور"
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							"aria-label": "فاکتورهای ذخیره‌شده",
							onClick: openArchive,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Archive, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden sm:inline",
								children: "بایگانی"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							"aria-label": "دانلود پشتیبان",
							onClick: downloadBackup,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden sm:inline",
								children: "پشتیبان"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							"aria-label": "بازیابی نسخه",
							onClick: () => fileRef.current?.click(),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden sm:inline",
								children: "بازیابی"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							"aria-label": "تنظیمات",
							onClick: () => setSettingsOpen(true),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden sm:inline",
								children: "تنظیمات"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							ref: fileRef,
							className: "hidden",
							type: "file",
							accept: "application/json,.json",
							onChange: (event) => {
								const file = event.target.files?.[0];
								event.target.value = "";
								if (!file) return;
								file.text().then((text) => {
									try {
										const parsed = parseBackup(JSON.parse(text));
										if (!parsed) {
											toast.error("این فایل پشتیبان آرمان نیست.");
											return;
										}
										setPendingBackup(parsed);
									} catch {
										toast.error("فایل انتخاب‌شده قابل خواندن نیست.");
									}
								});
							}
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto flex w-full min-w-0 max-w-6xl flex-col gap-4 px-4 pb-16",
				children: [
					view === "wizard" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "no-print grid grid-cols-4 gap-2",
						"aria-label": "مراحل ثبت فاکتور",
						children: STEPS.map((item) => {
							const active = item.n === step;
							const done = item.n < step;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								"aria-current": active ? "step" : void 0,
								className: cn("flex min-w-0 items-center gap-2 rounded-2xl border px-2 py-2 sm:px-3", active && "border-primary bg-primary-soft text-primary-ink", done && "border-line bg-surface text-ink", !active && !done && "border-line bg-surface text-muted"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: cn("grid size-8 shrink-0 place-items-center rounded-full text-sm font-extrabold", active || done ? "bg-primary text-on-primary" : "bg-canvas text-muted"),
									children: faNum(item.n)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "truncate text-sm font-bold",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "sm:hidden",
										children: item.short
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "hidden sm:inline",
										children: item.title
									})]
								})]
							}, item.n);
						})
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "no-print flex flex-col gap-4",
						children: [
							view === "archive" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArchiveView, {}) : null,
							view === "wizard" && step === 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StagePatient, {}) : null,
							view === "wizard" && step === 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StageTeeth, {}) : null,
							view === "wizard" && step === 3 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StageItems, {}) : null,
							view === "wizard" && step === 4 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StageReview, {}) : null
						]
					}),
					view === "wizard" && step === 4 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sheet-frame",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InvoiceSheet, {})
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "no-print text-center text-xs text-muted",
						children: "اطلاعات در حافظه همین مرورگر می‌ماند. برای جابه‌جایی بین دستگاه‌ها فایل پشتیبان بگیر."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsDialog, {
				open: settingsOpen,
				onOpenChange: setSettingsOpen
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: pendingBackup != null,
				title: "بازیابی پشتیبان",
				body: "اطلاعات فعلی این مرورگر با فایل انتخاب‌شده عوض شود؟",
				confirmLabel: "جایگزینی",
				onOpenChange: (open) => {
					if (!open) setPendingBackup(null);
				},
				onConfirm: () => {
					if (!pendingBackup) return;
					const ok = replaceAll(pendingBackup);
					toast.success(ok ? "بازیابی انجام شد." : "بازیابی در حافظه ماند ولی فضای مرورگر کم است.");
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "no-print",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
					position: "bottom-center",
					dir: "rtl"
				})
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InvoiceApp, {});
}
//#endregion
export { Home as component };
