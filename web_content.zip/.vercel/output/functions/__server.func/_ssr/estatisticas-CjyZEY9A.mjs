import { w as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { D as useAppStore, S as getDayStatus, d as allProjectDates, x as getDayChecks } from "./store-CuJQmbYj.mjs";
import { t as PageHeader } from "./page-header-ueGZTDza.mjs";
import { i as CardTitle, n as CardContent, r as CardHeader, t as Card } from "./card-ML3_y2lP.mjs";
import { t as StatCard } from "./stat-card-ajAgjbVP.mjs";
import { a as CartesianGrid, i as Area, n as YAxis, o as ResponsiveContainer, r as XAxis, s as Tooltip, t as AreaChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/estatisticas-CjyZEY9A.js
var import_jsx_runtime = require_jsx_runtime();
function StatsPage() {
	const logs = useAppStore((s) => s.logs);
	const settings = useAppStore((s) => s.settings);
	const sessions = useAppStore((s) => s.sessions);
	const dates = allProjectDates();
	let skin = 0;
	let water = 0;
	let sleep = 0;
	let complete = 0;
	const series = dates.map((d, i) => {
		const log = logs[d];
		const c = getDayChecks(log, settings);
		if (c.skinCare) skin += 1;
		if (c.water) water += 1;
		if (c.sleep) sleep += 1;
		if (getDayStatus(log, settings) === "complete") complete += 1;
		return {
			day: i + 1,
			habitos: c.doneCount,
			agua: Math.min(settings.waterGoalMl, log?.waterMl ?? 0),
			sono: log?.sleepHours ?? 0
		};
	});
	const treinos = sessions.filter((s) => s.type !== "postura").length;
	const postura = sessions.filter((s) => s.type === "postura").length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "animate-in fade-in duration-300",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: "Consistência",
				title: "Estatísticas",
				subtitle: "Progresso por hábitos e sessões. Sem peso, sem medidas."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-5 grid grid-cols-2 gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Dias do projeto",
						value: `${complete} / 101`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Treinos realizados",
						value: treinos
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Sessões de postura",
						value: postura
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Dias com skin care",
						value: skin
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Dias com meta de água",
						value: water
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Dias com 8h de sono",
						value: sleep
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Dias completos",
						value: complete,
						className: "col-span-2"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "mb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Hábitos por dia" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
					className: "h-52 pt-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
						width: "100%",
						height: "100%",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
							data: series,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
									stroke: "rgb(42 32 56)",
									vertical: false
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
									dataKey: "day",
									tick: {
										fill: "#a39bb3",
										fontSize: 11
									},
									axisLine: false,
									tickLine: false
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
									tick: {
										fill: "#a39bb3",
										fontSize: 11
									},
									axisLine: false,
									tickLine: false,
									width: 28
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
									contentStyle: {
										background: "#14141e",
										border: "1px solid #2a2038",
										borderRadius: 12,
										fontSize: 12
									},
									labelFormatter: (v) => `Dia ${v}`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
									type: "monotone",
									dataKey: "habitos",
									stroke: "#c084fc",
									fill: "rgba(192,132,252,0.25)",
									strokeWidth: 2,
									name: "Hábitos"
								})
							]
						})
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Água (ml)" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
				className: "h-52 pt-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
					width: "100%",
					height: "100%",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
						data: series,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
								stroke: "rgb(42 32 56)",
								vertical: false
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
								dataKey: "day",
								tick: {
									fill: "#a39bb3",
									fontSize: 11
								},
								axisLine: false,
								tickLine: false
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
								tick: {
									fill: "#a39bb3",
									fontSize: 11
								},
								axisLine: false,
								tickLine: false,
								width: 36
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
								contentStyle: {
									background: "#14141e",
									border: "1px solid #2a2038",
									borderRadius: 12,
									fontSize: 12
								},
								labelFormatter: (v) => `Dia ${v}`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
								type: "monotone",
								dataKey: "agua",
								stroke: "#c084fc",
								fill: "rgba(192,132,252,0.2)",
								strokeWidth: 2,
								name: "ml"
							})
						]
					})
				})
			})] })
		]
	});
}
//#endregion
export { StatsPage as component };
