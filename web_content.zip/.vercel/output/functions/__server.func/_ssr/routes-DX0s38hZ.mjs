import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as object, n as array, o as string, t as _enum } from "../_libs/zod.mjs";
import { a as Timer, c as Power, d as Keyboard, f as Cpu, l as Mic, n as VolumeX, o as Shield, p as Activity, r as Volume2, s as Settings2, t as X, u as MicOff } from "../_libs/lucide-react.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DX0s38hZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var MessageSchema = object({
	role: _enum(["user", "assistant"]),
	content: string().max(4e3)
});
var AskSchema = object({
	prompt: string().min(1).max(2e3),
	history: array(MessageSchema).max(12),
	localTime: string().max(120)
});
var askJarvis = createServerFn({ method: "POST" }).validator((input) => AskSchema.parse(input)).handler(createSsrRpc("0fb2def1a5eb367be786db91199b5766958d15865db2d5d1635788c0b0c8d0c8"));
function normalize(input) {
	return input.toLowerCase().replace(/[?.!,]/g, " ").replace(/\s+/g, " ").trim();
}
var NUMBER_WORDS = {
	a: 1,
	an: 1,
	one: 1,
	two: 2,
	three: 3,
	four: 4,
	five: 5,
	six: 6,
	seven: 7,
	eight: 8,
	nine: 9,
	ten: 10,
	fifteen: 15,
	twenty: 20,
	thirty: 30,
	forty: 40,
	fortyfive: 45,
	forty_five: 45,
	sixty: 60
};
function parseAmount(raw) {
	if (/^\d+$/.test(raw)) return Number(raw);
	return NUMBER_WORDS[raw.replace("-", "_")] ?? NUMBER_WORDS[raw] ?? null;
}
function parseTimer(text) {
	const n = normalize(text);
	if (!/\b(timer|countdown|alarm)\b/.test(n)) return null;
	if (/\b(cancel|stop|clear|end|kill)\b/.test(n) && /\b(timer|countdown|alarm)\b/.test(n)) return 0;
	const combo = n.match(/(\d+|one|two|three|four|five|six|seven|eight|nine|ten|fifteen|twenty|thirty)\s*(hours?|hrs?|h)\s*(?:and\s*)?(\d+|one|two|three|four|five|six|seven|eight|nine|ten|fifteen|twenty|thirty)\s*(minutes?|mins?|m)\b/);
	if (combo) {
		const h = parseAmount(combo[1] ?? "");
		const m = parseAmount(combo[3] ?? "");
		if (h != null && m != null) return h * 3600 + m * 60;
	}
	const match = n.match(/(\d+|a|an|one|two|three|four|five|six|seven|eight|nine|ten|fifteen|twenty|thirty|forty|forty-five|sixty)\s*(seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h)\b/);
	if (!match) return /\b(timer|countdown)\b/.test(n) ? 60 : null;
	const amount = parseAmount(match[1] ?? "");
	if (amount == null) return null;
	const unit = match[2] ?? "minutes";
	if (/^s/.test(unit) && !/^m/.test(unit) && !/^h/.test(unit)) {
		if (unit.startsWith("sec") || unit === "s") return amount;
	}
	if (unit.startsWith("hour") || unit.startsWith("hr") || unit === "h") return amount * 3600;
	if (unit.startsWith("min") || unit === "m") return amount * 60;
	if (unit.startsWith("sec") || unit === "s") return amount;
	return amount * 60;
}
function formatDuration(seconds) {
	if (seconds < 60) return `${seconds} second${seconds === 1 ? "" : "s"}`;
	if (seconds % 3600 === 0) {
		const h = seconds / 3600;
		return `${h} hour${h === 1 ? "" : "s"}`;
	}
	if (seconds % 60 === 0) {
		const m = seconds / 60;
		return `${m} minute${m === 1 ? "" : "s"}`;
	}
	const m = Math.floor(seconds / 60);
	const s = seconds % 60;
	return `${m} minute${m === 1 ? "" : "s"} and ${s} second${s === 1 ? "" : "s"}`;
}
function parseLocalCommand(input, now = /* @__PURE__ */ new Date()) {
	const n = normalize(input);
	if (!n) return null;
	if (/^(clear|reset|wipe|new conversation|start over)( (chat|history|conversation))?$/.test(n) || n === "forget that") return { type: "clear" };
	if (/^(mute|be quiet|silence|stop talking|voice off)$/.test(n) || n === "stop speaking") return {
		type: "mute",
		muted: true,
		text: "Voice output muted, sir. I shall keep my replies on-screen."
	};
	if (/^(unmute|speak up|voice on|talk again)$/.test(n)) return {
		type: "mute",
		muted: false,
		text: "Voice output restored. A pleasure to be heard again, sir."
	};
	if (/^(wake word off|disable wake word|stop listening)$/.test(n)) return {
		type: "wake",
		enabled: false,
		text: "Wake word disabled. Tap the core or type when you need me."
	};
	if (/^(wake word on|enable wake word|listen for hey jarvis)$/.test(n)) return {
		type: "wake",
		enabled: true,
		text: "Wake word armed. Say Hey Jarvis whenever you are ready."
	};
	if (/^(hi|hello|hey|good morning|good afternoon|good evening)( (there|jarvis))?$/.test(n) || n === "hey jarvis") {
		const hour = now.getHours();
		return {
			type: "text",
			text: `${hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening"}, sir. J.A.R.V.I.S. at your service. How may I assist?`
		};
	}
	if (/who are you|what are you|your name|what is jarvis/.test(n)) return {
		type: "text",
		text: "I am J.A.R.V.I.S. — Just A Rather Very Intelligent System. Originally a gentleman's assistant for a rather busy inventor. These days, I am yours."
	};
	if (/^(thanks|thank you|cheers|appreciate it)\b/.test(n)) return {
		type: "text",
		text: "Always, sir. I do aim to please."
	};
	if (/\b(what('?s| is) the time|what time is it|current time|tell me the time)\b/.test(n) || n === "time") return {
		type: "time",
		text: `The time is ${new Intl.DateTimeFormat(void 0, {
			hour: "numeric",
			minute: "2-digit"
		}).format(now)}, sir.`
	};
	if (/\b(what('?s| is) (the )?(date|day)|what day is it|today'?s date)\b/.test(n) || n === "date") return {
		type: "time",
		text: `Today is ${new Intl.DateTimeFormat(void 0, {
			weekday: "long",
			month: "long",
			day: "numeric",
			year: "numeric"
		}).format(now)}, sir.`
	};
	const timer = parseTimer(n);
	if (timer != null) {
		if (timer === 0) return {
			type: "timer",
			text: "Timer cancelled, sir.",
			seconds: 0
		};
		return {
			type: "timer",
			text: `Timer set for ${formatDuration(timer)}. I shall alert you when it elapses, sir.`,
			seconds: timer
		};
	}
	if (/\b(run (a )?(diagnostic|diagnostics)|system (check|status)|diagnostics)\b/.test(n)) return {
		type: "diagnostics",
		text: "Primary systems check complete. Power, optics, comms, and cognitive mesh are all within nominal range, sir."
	};
	if (/\b(suit status|armor status|mark (42|43|44|50)|how is the suit)\b/.test(n)) return {
		type: "suit",
		text: "Gold-titanium hull integrity is excellent. Flight systems idle. Repulsors at 98%. I would advise against a low-altitude barrel roll, sir, but you do you."
	};
	return null;
}
var SpeakSchema = object({ text: string().min(1).max(800) });
var speakJarvis = createServerFn({ method: "POST" }).validator((input) => SpeakSchema.parse(input)).handler(createSsrRpc("6e8eda61e6740854cea1061e01f693f4837295cb55f010bf5a7473c8996a6fa4"));
var useJarvisStore = create()(persist((set) => ({
	messages: [],
	voiceOn: true,
	wakeOn: true,
	addMessage: (msg) => set((s) => ({ messages: [...s.messages, msg].slice(-40) })),
	clearMessages: () => set({ messages: [] }),
	setVoiceOn: (voiceOn) => set({ voiceOn }),
	setWakeOn: (wakeOn) => set({ wakeOn })
}), {
	name: "jarvis-os",
	partialize: (s) => ({
		messages: s.messages,
		voiceOn: s.voiceOn,
		wakeOn: s.wakeOn
	})
}));
function newId() {
	return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}
var SUGGESTIONS = [
	"What time is it?",
	"What's the weather?",
	"Set a 5 minute timer",
	"Run a diagnostic",
	"Suit status",
	"Tell me a joke"
];
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium transition-[opacity,transform,background-color,color,box-shadow] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/60 disabled:pointer-events-none disabled:opacity-40 active:not-disabled:scale-[0.96] [&_svg]:pointer-events-none [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-primary text-bg hover:opacity-90",
			ghost: "bg-transparent text-fg hover:bg-primary/10",
			outline: "bg-transparent text-primary shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-primary)_40%,transparent)] hover:bg-primary/10",
			hud: "bg-surface-2 text-fg shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-primary)_28%,transparent)] hover:bg-surface"
		},
		size: {
			default: "h-11 rounded-md px-4 text-base",
			sm: "h-9 rounded-sm px-3 text-sm",
			icon: "size-11 rounded-md",
			chip: "h-9 rounded-full px-3.5 text-sm"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		...props
	});
}
var LINES = [
	"INITIALIZING J.A.R.V.I.S.",
	"COGNITIVE MESH ………… ONLINE",
	"VOICE PRINT ……………… ARMED",
	"WAKE WORD ……………… HEY JARVIS",
	"ALL SYSTEMS ………… NOMINAL"
];
function BootScreen({ onDone }) {
	const [visible, setVisible] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		const timers = [];
		LINES.forEach((_, i) => {
			timers.push(window.setTimeout(() => setVisible(i + 1), 180 + i * 280));
		});
		timers.push(window.setTimeout(onDone, 180 + LINES.length * 280 + 420));
		return () => timers.forEach((t) => window.clearTimeout(t));
	}, [onDone]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-40 flex flex-col items-center justify-center gap-8 bg-bg px-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative grid size-28 place-items-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute inset-0 rounded-full border border-primary/40" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute inset-2 rounded-full border border-primary/25 orb-spin" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-10 rounded-full bg-primary/80 orb-pulse" })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "w-full max-w-sm font-mono text-sm tracking-wide text-primary",
			children: LINES.map((line, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: "boot-line py-1",
				style: {
					animationDelay: `${i * 80}ms`,
					opacity: i < visible ? 1 : 0
				},
				children: line
			}, line))
		})]
	});
}
function Panel({ children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("relative overflow-hidden rounded-lg bg-surface px-4 py-3 shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-primary)_22%,transparent)]", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "hud-corner tl" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "hud-corner tr" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "hud-corner bl" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "hud-corner br" }),
			children
		]
	});
}
function formatClock(seconds) {
	const m = Math.floor(seconds / 60);
	const s = seconds % 60;
	return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}
function TimerCard({ remaining, total }) {
	const pct = total > 0 ? Math.max(0, Math.min(1, remaining / total)) : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Timer, {
			className: "size-5 text-primary",
			strokeWidth: 1.75
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0 flex-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-xs tracking-widest text-muted uppercase",
				children: "Timer"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-2xl tabular-nums leading-tight text-fg",
				children: formatClock(remaining)
			})]
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-3 h-1 overflow-hidden rounded-full bg-primary/15",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "h-full bg-primary transition-[width] duration-300 ease-linear",
			style: { width: `${pct * 100}%` }
		})
	})] });
}
var SYSTEMS = [
	{
		label: "Power core",
		value: "NOMINAL"
	},
	{
		label: "Optics",
		value: "NOMINAL"
	},
	{
		label: "Comms mesh",
		value: "NOMINAL"
	},
	{
		label: "Voice print",
		value: "ARMED"
	},
	{
		label: "Wake word",
		value: "HEY JARVIS"
	}
];
function DiagnosticsCard() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-3 flex items-center gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Activity, {
			className: "size-4 text-primary",
			strokeWidth: 1.75
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-mono text-xs tracking-widest text-muted uppercase",
			children: "Systems check"
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "space-y-1.5",
		children: SYSTEMS.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "flex items-baseline justify-between gap-3 font-mono text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-muted",
				children: row.label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-primary tabular-nums",
				children: row.value
			})]
		}, row.label))
	})] });
}
var SUIT = [
	{
		label: "Hull",
		value: "GOLD-TITANIUM"
	},
	{
		label: "Integrity",
		value: "100%"
	},
	{
		label: "Repulsors",
		value: "98%"
	},
	{
		label: "Flight",
		value: "IDLE"
	}
];
function SuitCard() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-3 flex items-center gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, {
			className: "size-4 text-gold",
			strokeWidth: 1.75
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-mono text-xs tracking-widest text-muted uppercase",
			children: "Armor telemetry"
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "space-y-1.5",
		children: SUIT.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "flex items-baseline justify-between gap-3 font-mono text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-muted",
				children: row.label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-fg tabular-nums",
				children: row.value
			})]
		}, row.label))
	})] });
}
function MessageBubble({ message }) {
	const mine = message.role === "user";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex", mine ? "justify-end" : "justify-start"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("max-w-sm rounded-lg px-3.5 py-2.5 text-sm leading-snug sm:max-w-md", mine ? "rounded-br-xs bg-primary/15 text-fg" : "rounded-bl-xs bg-surface text-fg shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-primary)_18%,transparent)]"),
			children: [!mine ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mb-1 flex items-center gap-1.5 font-mono text-xs tracking-widest text-primary uppercase",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cpu, {
					className: "size-3",
					strokeWidth: 2
				}), "Jarvis"]
			}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: message.content })]
		})
	});
}
function JarvisOrb({ phase, compact, onPress, caption }) {
	const listening = phase === "listening";
	const speaking = phase === "speaking";
	const thinking = phase === "thinking";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: onPress,
			"aria-label": caption,
			className: cn("relative grid place-items-center rounded-full transition-[width,height,transform] duration-300 ease-out", compact ? "orb-size-compact" : "orb-size"),
			children: [listening ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "ripple absolute inset-0 rounded-full border border-primary/50" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "ripple absolute inset-0 rounded-full border border-primary/30 [animation-delay:600ms]" })] }) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
				viewBox: "0 0 200 200",
				className: cn("size-full", listening ? "orb-listen" : speaking ? "orb-speak" : ""),
				"aria-hidden": "true",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("defs", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("radialGradient", {
						id: "core",
						cx: "50%",
						cy: "50%",
						r: "50%",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
								offset: "0%",
								stopColor: "var(--color-fg)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
								offset: "35%",
								stopColor: "var(--color-primary)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
								offset: "70%",
								stopColor: "var(--color-primary-dim)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
								offset: "100%",
								stopColor: "var(--color-bg)"
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("radialGradient", {
						id: "gold",
						cx: "50%",
						cy: "42%",
						r: "55%",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
								offset: "0%",
								stopColor: "var(--color-fg)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
								offset: "45%",
								stopColor: "var(--color-gold)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
								offset: "100%",
								stopColor: "var(--color-bg)"
							})
						]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "100",
						cy: "100",
						r: "96",
						fill: "none",
						stroke: "currentColor",
						className: "text-primary/25",
						strokeWidth: "1"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("g", {
						className: thinking ? "orb-spin-fast origin-center" : "orb-spin origin-center",
						style: {
							transformBox: "fill-box",
							transformOrigin: "center"
						},
						children: Array.from({ length: 60 }).map((_, i) => {
							const a = i / 60 * Math.PI * 2;
							const inner = i % 5 === 0 ? 86 : 90;
							const outer = 94;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
								x1: 100 + Math.cos(a) * inner,
								y1: 100 + Math.sin(a) * inner,
								x2: 100 + Math.cos(a) * outer,
								y2: 100 + Math.sin(a) * outer,
								stroke: "currentColor",
								className: i % 5 === 0 ? "text-primary/80" : "text-primary/35",
								strokeWidth: i % 5 === 0 ? 1.4 : .8
							}, i);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "100",
						cy: "100",
						r: "78",
						fill: "none",
						stroke: "currentColor",
						className: "text-primary/40",
						strokeWidth: "1",
						strokeDasharray: "4 6"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
						className: "orb-spin-rev origin-center",
						style: {
							transformBox: "fill-box",
							transformOrigin: "center"
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: "100",
							cy: "100",
							r: "68",
							fill: "none",
							stroke: "currentColor",
							className: "text-primary/70",
							strokeWidth: "1.5",
							strokeDasharray: "28 120",
							strokeLinecap: "round"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: "100",
							cy: "100",
							r: "62",
							fill: "none",
							stroke: "currentColor",
							className: "text-primary/30",
							strokeWidth: "6",
							strokeDasharray: "2 14"
						})]
					}),
					thinking ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "100",
						cy: "100",
						r: "54",
						fill: "none",
						stroke: "currentColor",
						className: "text-primary orb-think",
						strokeWidth: "2",
						strokeDasharray: "40 160",
						strokeLinecap: "round"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "100",
						cy: "100",
						r: "54",
						fill: "none",
						stroke: "currentColor",
						className: "text-primary/50",
						strokeWidth: "1"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "100",
						cy: "100",
						r: "36",
						fill: "url(#gold)",
						opacity: "0.92"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "100",
						cy: "100",
						r: "26",
						fill: "var(--color-bg)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "100",
						cy: "100",
						r: "20",
						fill: "url(#core)",
						className: speaking || listening ? "orb-pulse" : ""
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "100",
						cy: "100",
						r: "8",
						fill: "var(--color-fg)",
						opacity: "0.9"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
						x1: "100",
						y1: "42",
						x2: "100",
						y2: "52",
						stroke: "currentColor",
						className: "text-primary/70",
						strokeWidth: "1.2"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
						x1: "100",
						y1: "148",
						x2: "100",
						y2: "158",
						stroke: "currentColor",
						className: "text-primary/70",
						strokeWidth: "1.2"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
						x1: "42",
						y1: "100",
						x2: "52",
						y2: "100",
						stroke: "currentColor",
						className: "text-primary/70",
						strokeWidth: "1.2"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
						x1: "148",
						y1: "100",
						x2: "158",
						y2: "100",
						stroke: "currentColor",
						className: "text-primary/70",
						strokeWidth: "1.2"
					})
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-mono text-xs tracking-widest text-primary uppercase",
			children: caption
		})]
	});
}
function getCtor() {
	if (typeof window === "undefined") return null;
	const w = window;
	return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null;
}
var WAKE_RE = /\b(?:hey|hi|ok|okay|yo)\s+(?:jarvis|jarvice|jarviss|jar vis|jarvys)\b/i;
function stripWakeWord(transcript) {
	return transcript.replace(WAKE_RE, " ").replace(/\s+/g, " ").trim();
}
function hasWakeWord(transcript) {
	return WAKE_RE.test(transcript);
}
function useJarvisSpeech({ enabled, onCommand, onWake, onPartial, paused }) {
	const [supported, setSupported] = (0, import_react.useState)(false);
	const [permission, setPermission] = (0, import_react.useState)("unknown");
	const [mode, setMode] = (0, import_react.useState)("off");
	const [error, setError] = (0, import_react.useState)(null);
	const recRef = (0, import_react.useRef)(null);
	const modeRef = (0, import_react.useRef)("off");
	const wantRef = (0, import_react.useRef)(false);
	const pausedRef = (0, import_react.useRef)(paused);
	const enabledRef = (0, import_react.useRef)(enabled);
	const callbacks = (0, import_react.useRef)({
		onCommand,
		onWake,
		onPartial
	});
	(0, import_react.useEffect)(() => {
		callbacks.current = {
			onCommand,
			onWake,
			onPartial
		};
	}, [
		onCommand,
		onWake,
		onPartial
	]);
	(0, import_react.useEffect)(() => {
		pausedRef.current = paused;
	}, [paused]);
	(0, import_react.useEffect)(() => {
		enabledRef.current = enabled;
	}, [enabled]);
	(0, import_react.useEffect)(() => {
		setSupported(Boolean(getCtor()));
	}, []);
	const setModeBoth = (0, import_react.useCallback)((next) => {
		modeRef.current = next;
		setMode(next);
	}, []);
	const stopRec = (0, import_react.useCallback)(() => {
		wantRef.current = false;
		const rec = recRef.current;
		if (!rec) return;
		try {
			rec.onend = null;
			rec.abort();
		} catch {}
		recRef.current = null;
	}, []);
	const startRec = (0, import_react.useCallback)((nextMode) => {
		const Ctor = getCtor();
		if (!Ctor) {
			setError("Voice engine unavailable in this browser, sir.");
			return false;
		}
		stopRec();
		wantRef.current = true;
		const rec = new Ctor();
		rec.continuous = nextMode === "standby";
		rec.interimResults = true;
		rec.lang = "en-US";
		rec.onstart = () => {
			setPermission("granted");
			setError(null);
		};
		rec.onerror = (ev) => {
			if (ev.error === "not-allowed") {
				setPermission("denied");
				setError("Microphone access denied. Typed commands still work, sir.");
				wantRef.current = false;
				setModeBoth("off");
				return;
			}
			if (ev.error === "no-speech") return;
			if (ev.error === "aborted") return;
			setError(ev.error);
		};
		rec.onresult = (ev) => {
			if (pausedRef.current) return;
			let interim = "";
			let finalText = "";
			for (let i = ev.resultIndex; i < ev.results.length; i++) {
				const piece = ev.results[i];
				if (!piece) continue;
				const t = piece[0]?.transcript ?? "";
				if (piece.isFinal) finalText += t;
				else interim += t;
			}
			const heard = (finalText || interim).trim();
			if (!heard) return;
			if (modeRef.current === "standby") {
				callbacks.current.onPartial(heard);
				if (hasWakeWord(heard) && finalText) {
					const rest = stripWakeWord(finalText);
					callbacks.current.onWake();
					if (rest.length > 1) {
						callbacks.current.onCommand(rest);
						setModeBoth("standby");
					} else setModeBoth("command");
				}
				return;
			}
			if (modeRef.current === "command") {
				callbacks.current.onPartial(heard);
				if (finalText.trim()) {
					const rest = stripWakeWord(finalText) || finalText.trim();
					callbacks.current.onCommand(rest);
					setModeBoth(enabledRef.current ? "standby" : "off");
				}
			}
		};
		rec.onend = () => {
			if (!wantRef.current) return;
			if (modeRef.current === "off") return;
			const resume = () => {
				const wantMode = modeRef.current;
				if (wantMode === "off" || !wantRef.current) return;
				const shouldBeContinuous = wantMode === "standby";
				if (rec.continuous === shouldBeContinuous) {
					try {
						rec.start();
					} catch {
						window.setTimeout(() => {
							try {
								rec.start();
							} catch {}
						}, 300);
					}
					return;
				}
				startRec(wantMode);
			};
			if (pausedRef.current) {
				window.setTimeout(() => {
					if (!wantRef.current || pausedRef.current || modeRef.current === "off") return;
					resume();
				}, 280);
				return;
			}
			resume();
		};
		recRef.current = rec;
		setModeBoth(nextMode);
		try {
			rec.start();
			return true;
		} catch {
			setError("Could not start the microphone, sir.");
			return false;
		}
	}, [setModeBoth, stopRec]);
	const armStandby = (0, import_react.useCallback)(() => {
		if (!enabledRef.current) return false;
		return startRec("standby");
	}, [startRec]);
	const listenForCommand = (0, import_react.useCallback)(() => {
		return startRec("command");
	}, [startRec]);
	const disarm = (0, import_react.useCallback)(() => {
		stopRec();
		setModeBoth("off");
	}, [stopRec, setModeBoth]);
	(0, import_react.useEffect)(() => {
		return () => stopRec();
	}, [stopRec]);
	(0, import_react.useEffect)(() => {
		if (!enabled && modeRef.current === "standby") disarm();
	}, [enabled, disarm]);
	return {
		supported,
		permission,
		mode,
		error,
		armStandby,
		listenForCommand,
		disarm
	};
}
function speakBrowser(text) {
	return new Promise((resolve) => {
		if (typeof window === "undefined" || !window.speechSynthesis) {
			resolve();
			return;
		}
		window.speechSynthesis.cancel();
		const utter = new SpeechSynthesisUtterance(text);
		const voices = window.speechSynthesis.getVoices();
		const pick = voices.find((v) => /en-GB/i.test(v.lang) && /male|daniel|george|malcolm|arthur|rishi/i.test(v.name)) || voices.find((v) => /en-GB/i.test(v.lang)) || voices.find((v) => /en-US/i.test(v.lang) && /male|david|alex|daniel/i.test(v.name)) || voices[0];
		if (pick) utter.voice = pick;
		utter.rate = 1.02;
		utter.pitch = .92;
		utter.onend = () => resolve();
		utter.onerror = () => resolve();
		window.speechSynthesis.speak(utter);
	});
}
function stopBrowserSpeech() {
	if (typeof window === "undefined") return;
	window.speechSynthesis?.cancel();
}
function greetingFor(date) {
	const h = date.getHours();
	if (h < 12) return "Good morning, sir.";
	if (h < 18) return "Good afternoon, sir.";
	return "Good evening, sir.";
}
function phaseCaption(phase, wakeOn, micOn) {
	if (phase === "listening") return "Listening";
	if (phase === "thinking") return "Processing";
	if (phase === "speaking") return "Speaking";
	if (micOn && wakeOn) return "Say Hey Jarvis";
	if (micOn) return "Tap to speak";
	return "Standby";
}
function Assistant() {
	const messages = useJarvisStore((s) => s.messages);
	const voiceOn = useJarvisStore((s) => s.voiceOn);
	const wakeOn = useJarvisStore((s) => s.wakeOn);
	const addMessage = useJarvisStore((s) => s.addMessage);
	const clearMessages = useJarvisStore((s) => s.clearMessages);
	const setVoiceOn = useJarvisStore((s) => s.setVoiceOn);
	const setWakeOn = useJarvisStore((s) => s.setWakeOn);
	const [booting, setBooting] = (0, import_react.useState)(true);
	const [phase, setPhase] = (0, import_react.useState)("idle");
	const [draft, setDraft] = (0, import_react.useState)("");
	const [partial, setPartial] = (0, import_react.useState)("");
	const [now, setNow] = (0, import_react.useState)(() => /* @__PURE__ */ new Date());
	const [settingsOpen, setSettingsOpen] = (0, import_react.useState)(false);
	const [composerOpen, setComposerOpen] = (0, import_react.useState)(false);
	const [timer, setTimer] = (0, import_react.useState)(null);
	const [micArmed, setMicArmed] = (0, import_react.useState)(false);
	const [banner, setBanner] = (0, import_react.useState)(null);
	const listRef = (0, import_react.useRef)(null);
	const audioRef = (0, import_react.useRef)(null);
	const busyRef = (0, import_react.useRef)(false);
	const inputRef = (0, import_react.useRef)(null);
	const paused = phase === "speaking" || phase === "thinking";
	const onPartial = (0, import_react.useCallback)((text) => setPartial(text), []);
	const handleCommandRef = (0, import_react.useRef)(() => {});
	const onWake = (0, import_react.useCallback)(() => {
		stopPlayback();
		setPhase("listening");
		setPartial("");
		setBanner(null);
	}, []);
	const speech = useJarvisSpeech({
		enabled: wakeOn && micArmed,
		paused,
		onCommand: (text) => handleCommandRef.current(text),
		onWake,
		onPartial
	});
	function stopPlayback() {
		stopBrowserSpeech();
		if (audioRef.current) {
			audioRef.current.pause();
			audioRef.current.src = "";
			audioRef.current = null;
		}
	}
	const speak = (0, import_react.useCallback)(async (text) => {
		if (!voiceOn) return;
		setPhase("speaking");
		try {
			const tts = await speakJarvis({ data: { text } });
			if (tts.ok) {
				await new Promise((resolve) => {
					const audio = new Audio(tts.audio);
					audioRef.current = audio;
					audio.onended = () => resolve();
					audio.onerror = () => resolve();
					audio.play().catch(() => resolve());
				});
				return;
			}
			await speakBrowser(text);
		} catch {
			await speakBrowser(text);
		} finally {
			if (audioRef.current) audioRef.current = null;
		}
	}, [voiceOn]);
	const handleCommand = (0, import_react.useCallback)(async (raw) => {
		const text = raw.replace(/\s+/g, " ").trim();
		if (!text || busyRef.current) return;
		busyRef.current = true;
		setPartial("");
		setComposerOpen(false);
		setDraft("");
		setBanner(null);
		stopPlayback();
		addMessage({
			id: newId(),
			role: "user",
			content: text
		});
		setPhase("thinking");
		const local = parseLocalCommand(text, /* @__PURE__ */ new Date());
		try {
			if (local?.type === "clear") {
				clearMessages();
				setTimer(null);
				const reply = "Conversation cleared, sir.";
				addMessage({
					id: newId(),
					role: "assistant",
					content: reply
				});
				await speak(reply);
				setPhase("idle");
				return;
			}
			if (local?.type === "mute") {
				setVoiceOn(!local.muted);
				addMessage({
					id: newId(),
					role: "assistant",
					content: local.text
				});
				if (!local.muted) await speak(local.text);
				setPhase("idle");
				return;
			}
			if (local?.type === "wake") {
				setWakeOn(local.enabled);
				addMessage({
					id: newId(),
					role: "assistant",
					content: local.text
				});
				await speak(local.text);
				setPhase("idle");
				return;
			}
			if (local?.type === "timer") {
				if (local.seconds === 0) setTimer(null);
				else setTimer({
					remaining: local.seconds,
					total: local.seconds
				});
				addMessage({
					id: newId(),
					role: "assistant",
					content: local.text,
					kind: "timer",
					seconds: local.seconds
				});
				await speak(local.text);
				setPhase("idle");
				return;
			}
			if (local) {
				addMessage({
					id: newId(),
					role: "assistant",
					content: local.text,
					kind: local.type === "diagnostics" || local.type === "suit" || local.type === "time" ? local.type : "text"
				});
				await speak(local.text);
				setPhase("idle");
				return;
			}
			const result = await askJarvis({ data: {
				prompt: text,
				history: useJarvisStore.getState().messages.filter((m) => m.role === "user" || m.role === "assistant").slice(-8).map((m) => ({
					role: m.role,
					content: m.content
				})).slice(0, -1),
				localTime: (/* @__PURE__ */ new Date()).toString()
			} });
			const reply = result.ok ? result.text : result.error;
			addMessage({
				id: newId(),
				role: "assistant",
				content: reply
			});
			await speak(reply);
			setPhase("idle");
		} catch {
			addMessage({
				id: newId(),
				role: "assistant",
				content: "Something went sideways in the mesh, sir. Try again."
			});
			setPhase("idle");
		} finally {
			busyRef.current = false;
		}
	}, [
		addMessage,
		clearMessages,
		setVoiceOn,
		setWakeOn,
		speak
	]);
	(0, import_react.useEffect)(() => {
		handleCommandRef.current = handleCommand;
	}, [handleCommand]);
	(0, import_react.useEffect)(() => {
		const t = window.setInterval(() => setNow(/* @__PURE__ */ new Date()), 1e3);
		return () => window.clearInterval(t);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!timer) return;
		const t = window.setInterval(() => {
			setTimer((cur) => {
				if (!cur) return null;
				if (cur.remaining <= 1) {
					window.setTimeout(() => {
						const msg = "Sir, your timer has elapsed.";
						addMessage({
							id: newId(),
							role: "assistant",
							content: msg,
							kind: "timer"
						});
						speak(msg);
					}, 0);
					return null;
				}
				return {
					...cur,
					remaining: cur.remaining - 1
				};
			});
		}, 1e3);
		return () => window.clearInterval(t);
	}, [
		timer,
		addMessage,
		speak
	]);
	(0, import_react.useEffect)(() => {
		const el = listRef.current;
		if (!el) return;
		el.scrollTop = el.scrollHeight;
	}, [
		messages.length,
		partial,
		timer
	]);
	(0, import_react.useEffect)(() => {
		try {
			if (sessionStorage.getItem("jarvis-booted") === "1") setBooting(false);
		} catch {}
	}, []);
	const finishBoot = (0, import_react.useCallback)(() => {
		setBooting(false);
		try {
			sessionStorage.setItem("jarvis-booted", "1");
		} catch {}
	}, []);
	const clock = (0, import_react.useMemo)(() => new Intl.DateTimeFormat(void 0, {
		hour: "numeric",
		minute: "2-digit"
	}).format(now), [now]);
	const greeting = (0, import_react.useMemo)(() => greetingFor(now), [now]);
	const compact = messages.length > 0 || Boolean(timer);
	const caption = phaseCaption(phase, wakeOn, micArmed && speech.mode !== "off");
	function onOrbPress() {
		stopPlayback();
		setBanner(null);
		if (phase === "listening") {
			speech.disarm();
			if (wakeOn && micArmed) speech.armStandby();
			setPhase("idle");
			setPartial("");
			return;
		}
		if (!speech.supported) {
			setComposerOpen(true);
			setBanner("Voice engine unavailable here, sir. Type a command.");
			window.setTimeout(() => inputRef.current?.focus(), 50);
			return;
		}
		if (speech.listenForCommand()) {
			setMicArmed(true);
			setPhase("listening");
			setPartial("");
		} else setComposerOpen(true);
	}
	function enableVoiceSystems() {
		if (speech.armStandby()) {
			setMicArmed(true);
			setWakeOn(true);
			setBanner(null);
		}
	}
	const last = messages[messages.length - 1];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "hud-grid relative flex min-h-dvh flex-col overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "scanlines pointer-events-none absolute inset-0 z-10" }),
			booting ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BootScreen, { onDone: finishBoot }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "relative z-20 flex items-center justify-between gap-3 px-4 pt-[max(0.75rem,env(safe-area-inset-top))] pb-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-xs tracking-widest text-primary uppercase",
						children: "J.A.R.V.I.S."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-xs tracking-widest text-muted",
						children: "MK.I  //  OS"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-sm tabular-nums text-fg",
						children: clock
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("mr-1 font-mono text-xs tracking-widest uppercase", phase === "listening" ? "text-primary" : "text-muted"),
							children: phase === "idle" ? "STBY" : phase === "listening" ? "LIVE" : phase === "thinking" ? "CPU" : "VOX"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							className: "size-11 text-muted hover:text-fg",
							"aria-label": "Settings",
							onClick: () => setSettingsOpen((v) => !v),
							children: settingsOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings2, { className: "size-5" })
						})]
					})
				]
			}),
			settingsOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative z-20 mx-4 mb-2 rounded-lg bg-surface p-3 shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-primary)_22%,transparent)]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsRow, {
							icon: voiceOn ? Volume2 : VolumeX,
							label: "Voice replies",
							on: voiceOn,
							onToggle: () => setVoiceOn(!voiceOn)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsRow, {
							icon: wakeOn ? Mic : MicOff,
							label: "Wake word \"Hey Jarvis\"",
							on: wakeOn,
							onToggle: () => {
								const next = !wakeOn;
								setWakeOn(next);
								if (next && micArmed) speech.armStandby();
								if (!next && speech.mode === "standby") speech.disarm();
							}
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							size: "sm",
							className: "mt-1 w-full",
							onClick: () => {
								clearMessages();
								setTimer(null);
								setSettingsOpen(false);
							},
							children: "Clear conversation"
						})
					]
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: listRef,
				className: "relative z-20 flex min-h-0 flex-1 flex-col gap-3 overflow-y-auto px-4 py-2",
				children: compact ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					messages.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageBubble, { message: m }),
							m.kind === "diagnostics" && m.role === "assistant" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DiagnosticsCard, {}) : null,
							m.kind === "suit" && m.role === "assistant" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SuitCard, {}) : null
						]
					}, m.id)),
					timer ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TimerCard, {
						remaining: timer.remaining,
						total: timer.total
					}) : null,
					phase === "listening" && partial ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-sm text-primary/80",
						children: partial
					}) : null,
					phase === "thinking" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "shimmer font-mono text-sm tracking-widest uppercase",
						children: "Working"
					}) : null
				] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-1 flex-col items-center justify-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-1 text-center text-2xl font-semibold tracking-tight text-fg sm:text-3xl",
						children: greeting
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-6 max-w-xs text-center text-sm text-muted",
						children: "J.A.R.V.I.S. at your service. Say Hey Jarvis, tap the core, or type a command."
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-20 flex flex-col items-center gap-4 px-4 pb-2 pt-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(JarvisOrb, {
						phase: phase === "boot" ? "idle" : phase,
						compact,
						onPress: onOrbPress,
						caption
					}),
					speech.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-sm text-center text-sm text-danger",
						children: speech.error
					}) : null,
					banner ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-sm text-center text-sm text-muted",
						children: banner
					}) : null,
					!micArmed && speech.supported ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						onClick: enableVoiceSystems,
						className: "rounded-full px-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Power, { className: "size-4" }), "Enable voice systems"]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "chip-row flex w-full max-w-lg gap-2 overflow-x-auto pb-1",
						children: SUGGESTIONS.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "hud",
							size: "chip",
							className: "shrink-0",
							onClick: () => void handleCommand(s),
							disabled: busyRef.current || phase === "thinking",
							children: s
						}, s))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "relative z-20 mx-auto flex w-full max-w-lg items-center gap-2 px-4 pb-[max(1rem,env(safe-area-inset-bottom))] pt-2",
				onSubmit: (e) => {
					e.preventDefault();
					const value = draft.trim();
					if (value) handleCommand(value);
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "ghost",
						size: "icon",
						className: "size-11 shrink-0 text-muted",
						"aria-label": composerOpen ? "Hide keyboard" : "Show keyboard",
						onClick: () => {
							setComposerOpen((v) => !v);
							window.setTimeout(() => inputRef.current?.focus(), 40);
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Keyboard, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: cn("flex min-h-11 flex-1 items-center rounded-xl bg-surface px-3 shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-primary)_22%,transparent)] transition-[opacity] duration-150", composerOpen || draft ? "opacity-100" : "opacity-90"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							ref: inputRef,
							value: draft,
							onChange: (e) => setDraft(e.target.value),
							placeholder: "Type a command",
							"aria-label": "Command",
							className: "h-11 w-full bg-transparent text-base text-fg outline-none placeholder:text-muted"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: phase === "listening" ? "default" : "hud",
						size: "icon",
						className: "size-12 shrink-0 rounded-full",
						"aria-label": "Talk",
						onClick: onOrbPress,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "size-5" })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "sr-only",
				"aria-live": "polite",
				children: last?.role === "assistant" ? last.content : partial
			})
		]
	});
}
function SettingsRow({ icon: Icon, label, on, onToggle }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: onToggle,
		className: "flex h-11 items-center justify-between gap-3 rounded-md px-2 text-left hover:bg-primary/10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex items-center gap-2 text-sm text-fg",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
				className: "size-4 text-primary",
				strokeWidth: 1.75
			}), label]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("relative h-6 w-11 rounded-full transition-colors duration-150", on ? "bg-primary" : "bg-primary/20"),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("absolute top-0.5 size-5 rounded-full bg-bg transition-transform duration-150", on ? "translate-x-5" : "translate-x-0.5") })
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Assistant, {});
}
//#endregion
export { Home as component };
