import { o as __toESM } from "../_runtime.mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { t as Button } from "./button-C0qE0jyX.mjs";
import { a as SelectTrigger, i as SelectItem, n as Select, o as SelectValue, r as SelectContent, t as Input } from "./table-DKHBmBA9.mjs";
import { t as Label } from "./label-CPX7BiMk.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/student-form-DnG5GB3q.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function StudentForm({ streams, schools, initial, submitLabel, pending, onSubmit }) {
	const [values, setValues] = (0, import_react.useState)({
		firstName: initial?.firstName ?? "",
		lastName: initial?.lastName ?? "",
		birthDate: initial?.birthDate ?? "2007-01-01",
		birthPlace: initial?.birthPlace ?? "",
		gender: initial?.gender ?? "male",
		schoolId: initial?.schoolId ?? schools[0]?.id ?? 0,
		streamId: initial?.streamId ?? streams[0]?.id ?? 0
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "grid gap-3 sm:grid-cols-2",
		onSubmit: (e) => {
			e.preventDefault();
			onSubmit(values);
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "lastName",
					children: "اللقب"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "lastName",
					required: true,
					value: values.lastName,
					onChange: (e) => setValues((v) => ({
						...v,
						lastName: e.target.value
					}))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "firstName",
					children: "الاسم"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "firstName",
					required: true,
					value: values.firstName,
					onChange: (e) => setValues((v) => ({
						...v,
						firstName: e.target.value
					}))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "birthDate",
					children: "تاريخ الميلاد"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "birthDate",
					type: "date",
					required: true,
					value: values.birthDate,
					onChange: (e) => setValues((v) => ({
						...v,
						birthDate: e.target.value
					}))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "birthPlace",
					children: "مكان الميلاد"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "birthPlace",
					required: true,
					value: values.birthPlace,
					onChange: (e) => setValues((v) => ({
						...v,
						birthPlace: e.target.value
					}))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "الجنس" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: values.gender,
					onValueChange: (gender) => setValues((v) => ({
						...v,
						gender
					})),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: "male",
						children: "ذكر"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: "female",
						children: "أنثى"
					})] })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "الشعبة" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: String(values.streamId),
					onValueChange: (id) => setValues((v) => ({
						...v,
						streamId: Number(id)
					})),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: streams.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: String(s.id),
						children: s.nameAr
					}, s.id)) })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1.5 sm:col-span-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "الثانوية" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: String(values.schoolId),
					onValueChange: (id) => setValues((v) => ({
						...v,
						schoolId: Number(id)
					})),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: schools.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
						value: String(s.id),
						children: [
							s.name,
							" — ",
							s.wilaya
						]
					}, s.id)) })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "sm:col-span-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					className: "w-full sm:w-auto",
					disabled: pending,
					children: pending ? "جاري الحفظ…" : submitLabel
				})
			})
		]
	});
}
//#endregion
export { StudentForm as t };
