import { n as create, t as persist } from "../_libs/zustand.mjs";
import { n as format, t as enAU } from "../_libs/date-fns.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/vault-store-CwqfT6q8.js
var TOKENS = {
	USDC: {
		id: "USDC",
		name: "USD Coin",
		decimals: 2,
		geckoId: "usd-coin"
	},
	USDT: {
		id: "USDT",
		name: "Tether",
		decimals: 2,
		geckoId: "tether"
	},
	ETH: {
		id: "ETH",
		name: "Ether",
		decimals: 6,
		geckoId: "ethereum"
	},
	SOL: {
		id: "SOL",
		name: "Solana",
		decimals: 4,
		geckoId: "solana"
	},
	BTC: {
		id: "BTC",
		name: "Bitcoin",
		decimals: 8,
		geckoId: "bitcoin"
	}
};
var NETWORKS = [
	{
		id: "base",
		name: "Base",
		shortName: "Base",
		addressType: "evm",
		tokens: ["USDC", "ETH"],
		feeAud: .04,
		hint: "Low fees, USDC-friendly"
	},
	{
		id: "ethereum",
		name: "Ethereum",
		shortName: "ETH",
		addressType: "evm",
		tokens: [
			"USDC",
			"USDT",
			"ETH"
		],
		feeAud: 4.5,
		hint: "Most wallets, higher gas"
	},
	{
		id: "arbitrum",
		name: "Arbitrum",
		shortName: "ARB",
		addressType: "evm",
		tokens: ["USDC", "ETH"],
		feeAud: .12,
		hint: "L2, cheap ETH transfers"
	},
	{
		id: "solana",
		name: "Solana",
		shortName: "SOL",
		addressType: "solana",
		tokens: ["USDC", "SOL"],
		feeAud: .02,
		hint: "Near-instant, tiny fees"
	},
	{
		id: "bitcoin",
		name: "Bitcoin",
		shortName: "BTC",
		addressType: "bitcoin",
		tokens: ["BTC"],
		feeAud: 2.4,
		hint: "BTC only"
	}
];
var NETWORK_BY_ID = Object.fromEntries(NETWORKS.map((n) => [n.id, n]));
var EVM_RE = /^0x[a-fA-F0-9]{40}$/;
var SOL_RE = /^[1-9A-HJ-NP-Za-km-z]{32,44}$/;
var BTC_LEGACY_RE = /^(bc1|[13])[a-zA-HJ-NP-Z0-9]{25,62}$/;
function validateAddress(address, type) {
	const value = address.trim();
	if (!value) return "Enter a wallet address.";
	if (type === "evm") return EVM_RE.test(value) ? null : "Use a 0x address (42 characters).";
	if (type === "solana") return SOL_RE.test(value) ? null : "That does not look like a Solana address.";
	return BTC_LEGACY_RE.test(value) ? null : "That does not look like a Bitcoin address.";
}
function shortenAddress(address, size = 4) {
	const value = address.trim();
	if (value.length <= size * 2 + 2) return value;
	return `${value.slice(0, size + (value.startsWith("0x") ? 2 : 0))}…${value.slice(-size)}`;
}
function generateTxId(type) {
	const bytes = crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(32));
	const hex = Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
	if (type === "evm") return `0x${hex}`;
	if (type === "bitcoin") return hex;
	const alphabet = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
	return Array.from(bytes, (b) => alphabet[b % 58]).join("");
}
function hasBrowserWallet(type) {
	if (typeof window === "undefined") return false;
	if (type === "solana") return Boolean(window.solana ?? window.phantom?.solana);
	if (type === "evm") return Boolean(window.ethereum);
	return false;
}
async function connectBrowserWallet(type) {
	if (type === "bitcoin") throw new Error("Paste a Bitcoin address — browser wallets are not wired for BTC yet.");
	if (type === "solana") {
		const provider = window.solana ?? window.phantom?.solana;
		if (!provider) throw new Error("No Solana wallet found. Paste your address instead.");
		return (await provider.connect()).publicKey.toString();
	}
	const eth = window.ethereum;
	if (!eth) throw new Error("No Ethereum wallet found. Paste your address instead.");
	const account = (await eth.request({ method: "eth_requestAccounts" }))[0];
	if (!account) throw new Error("No account was selected.");
	return account;
}
function roundAud(value) {
	return Math.round(value * 100) / 100;
}
function parseAud(input) {
	const trimmed = input.trim().replace(/,/g, "");
	if (!trimmed) return null;
	const value = Number(trimmed);
	if (!Number.isFinite(value) || value <= 0) return null;
	return roundAud(value);
}
function formatAud(value, opts) {
	const formatted = new Intl.NumberFormat("en-AU", {
		style: "currency",
		currency: "AUD",
		minimumFractionDigits: 2,
		maximumFractionDigits: 2
	}).format(Math.abs(value));
	if (!opts?.sign) return formatted;
	if (value > 0) return `+${formatted}`;
	if (value < 0) return `−${formatted}`;
	return formatted;
}
function formatToken(amount, token) {
	const decimals = TOKENS[token].decimals;
	return `${amount.toLocaleString("en-AU", {
		minimumFractionDigits: Math.min(2, decimals),
		maximumFractionDigits: decimals
	})} ${token}`;
}
function formatWhen(ts) {
	return format(ts, "dd/MM/yyyy, h:mm:ss aaa", { locale: enAU });
}
function audToToken(amountAud, audPerToken) {
	if (audPerToken <= 0) return 0;
	return amountAud / audPerToken;
}
function totals(earnings, payouts) {
	const earned = roundAud(earnings.reduce((sum, row) => sum + row.amountAud, 0));
	const cashed = roundAud(payouts.reduce((sum, row) => sum + row.amountAud, 0));
	return {
		earned,
		cashed,
		available: roundAud(earned - cashed)
	};
}
var useVault = create()(persist((set, get) => ({
	earnings: [],
	payouts: [],
	wallet: null,
	addEarning: ({ amountAud, source, note }) => {
		const row = {
			id: crypto.randomUUID(),
			amountAud: roundAud(amountAud),
			source: source.trim(),
			note: note.trim(),
			createdAt: Date.now()
		};
		set((state) => ({ earnings: [row, ...state.earnings] }));
		return row;
	},
	setWallet: (wallet) => set({ wallet }),
	cashOut: ({ amountAud, tokenAmount, feeAud }) => {
		const { wallet, earnings, payouts } = get();
		if (!wallet) throw new Error("Add a wallet before cashing out.");
		const { available } = totals(earnings, payouts);
		const amount = roundAud(amountAud);
		if (amount <= 0) throw new Error("Enter an amount to send.");
		if (amount > available) throw new Error("That is more than your available balance.");
		const network = NETWORK_BY_ID[wallet.network];
		const payout = {
			id: crypto.randomUUID(),
			amountAud: amount,
			tokenAmount,
			feeAud,
			token: wallet.token,
			network: wallet.network,
			walletAddress: wallet.address,
			txId: generateTxId(network.addressType),
			status: "pending",
			createdAt: Date.now()
		};
		set((state) => ({ payouts: [payout, ...state.payouts] }));
		return payout;
	},
	confirmPayout: (id) => set((state) => ({ payouts: state.payouts.map((row) => row.id === id ? {
		...row,
		status: "confirmed"
	} : row) }))
}), {
	name: "vault-earnings",
	skipHydration: true
}));
function selectTotals(state) {
	return totals(state.earnings, state.payouts);
}
//#endregion
export { connectBrowserWallet as a, formatWhen as c, selectTotals as d, shortenAddress as f, audToToken as i, hasBrowserWallet as l, validateAddress as m, NETWORK_BY_ID as n, formatAud as o, useVault as p, TOKENS as r, formatToken as s, NETWORKS as t, parseAud as u };
