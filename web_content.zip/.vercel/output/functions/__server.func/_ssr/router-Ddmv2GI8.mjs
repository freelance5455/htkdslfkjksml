import { i as __toESM } from "../_runtime.mjs";
import { a as findCatalog, n as FALLBACK_FX, r as __exportAll, t as CATALOG } from "./catalog-D0BjXlW4.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { _ as lazyRouteComponent, d as Scripts, f as HeadContent, g as Outlet, h as createRouter, v as createFileRoute, x as useRouter, y as createRootRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { r as TriangleAlert } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-Ddmv2GI8.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FALLBACK_MESSAGE = "Váratlan hiba. Érdemes újratölteni az oldalt.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 bg-bg px-6 text-center text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-clay",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-serif text-2xl",
				children: "Valami félresiklott"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-muted",
				children: errorMessage(error)
			})
		]
	});
}
/**
* Path-based preview hosts serve the dev server under `/{port_id}/` and strip
* that prefix before forwarding, so SSR sees `/` while the browser URL keeps the
* prefix. TanStack Start resets `basepath` on hydration, so a `rewrite` keeps
* client routing and generated links aligned with the public URL.
*/
var PATH_BASED_PREVIEW_HOSTS = /* @__PURE__ */ new Set([
	"preview.grok.genai.mil",
	"preview.grok.mil",
	"preview.grokgsac.com"
]);
var PORT_ID_PREFIX = /^\/hds-[a-z0-9]+-\d+-[a-z0-9]+(?=\/|$)/i;
function previewPathPrefix(hostname, pathname) {
	if (!PATH_BASED_PREVIEW_HOSTS.has(hostname.toLowerCase())) return void 0;
	return PORT_ID_PREFIX.exec(pathname)?.[0];
}
function prefixRewrite(prefix) {
	return {
		input: ({ url }) => {
			if (url.pathname === prefix) url.pathname = "/";
			else if (url.pathname.startsWith(`${prefix}/`)) url.pathname = url.pathname.slice(prefix.length);
			return url;
		},
		output: ({ url }) => {
			url.pathname = `${prefix}${url.pathname}`;
			return url;
		}
	};
}
function previewPathRewrite() {
	if (typeof window === "undefined") return void 0;
	const prefix = previewPathPrefix(window.location.hostname, window.location.pathname);
	return prefix ? prefixRewrite(prefix) : void 0;
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var RANGES = /* @__PURE__ */ new Set([
	"6mo",
	"1y",
	"5y"
]);
var CURRENCIES = /* @__PURE__ */ new Set([
	"HUF",
	"USD",
	"EUR",
	"GBP"
]);
function cleanRequest(input) {
	const data = input ?? {};
	return {
		range: RANGES.has(data.range) ? data.range : "1y",
		instruments: (Array.isArray(data.instruments) ? data.instruments : []).slice(0, 24).flatMap((item) => {
			if (!item || typeof item !== "object") return [];
			const row = item;
			const symbol = String(row.symbol ?? "").trim().toUpperCase().slice(0, 16);
			if (!/^[A-Z0-9]{1,16}$/.test(symbol)) return [];
			return [{
				symbol,
				currency: CURRENCIES.has(row.currency) ? row.currency : "USD",
				yahoo: typeof row.yahoo === "string" ? row.yahoo.toUpperCase().slice(0, 24) : void 0,
				gecko: typeof row.gecko === "string" ? row.gecko.toLowerCase().slice(0, 40) : void 0
			}];
		})
	};
}
var fetchMarket = createServerFn({ method: "POST" }).validator(cleanRequest).handler(createSsrRpc("a6eda8ba56e67e5554ad9d89a791655f45c97cbd7c37c474b0f994145e7ab731"));
/** Éves fogyasztóiár-index, KSH-nagyságrend. 2026 előzetes, nem hivatalos zárás. */
var ANNUAL = {
	2019: .034,
	2020: .033,
	2021: .051,
	2022: .145,
	2023: .176,
	2024: .037,
	2025: .044,
	2026: .038,
	2027: .035
};
function parseIso(iso) {
	if (!/^\d{4}-\d{2}-\d{2}$/.test(iso)) return null;
	const date = /* @__PURE__ */ new Date(`${iso}T00:00:00Z`);
	return Number.isNaN(date.getTime()) ? null : date;
}
/** 2020. január = 100, a hónap elején. */
function cpiIndex(iso) {
	const date = parseIso(iso);
	if (!date) return 100;
	if (date < /* @__PURE__ */ new Date("2019-01-01T00:00:00Z")) return 100;
	let index = 100 / Math.pow(1.034, 12);
	let year = 2019;
	let month = 1;
	const endYear = date.getUTCFullYear();
	const endMonth = date.getUTCMonth() + 1;
	let guard = 0;
	while ((year < endYear || year === endYear && month < endMonth) && guard < 240) {
		const annual = ANNUAL[year] ?? .03;
		index *= Math.pow(1 + annual, 1 / 12);
		month += 1;
		if (month === 13) {
			month = 1;
			year += 1;
		}
		guard += 1;
	}
	return index;
}
function inflationFactor(fromIso, toIso) {
	const from = cpiIndex(fromIso);
	const to = cpiIndex(toIso);
	if (from <= 0) return 1;
	return to / from;
}
function inflationLossPct(fromIso, toIso) {
	return (inflationFactor(fromIso, toIso) - 1) * 100;
}
function fxToHuf(currency, fx) {
	if (currency === "HUF") return 1;
	if (currency === "EUR") return fx.eurHuf;
	if (currency === "GBP") return fx.gbpHuf;
	return fx.usdHuf;
}
function unitPrice(holding, market) {
	if (holding.assetClass === "keszpenz") return 1;
	const quote = market.quotes[holding.symbol];
	if (quote && quote.price > 0) return quote.price;
	if (holding.manualPrice && holding.manualPrice > 0) return holding.manualPrice;
	const known = findCatalog(holding.symbol);
	if (known) return known.fallback;
	return holding.avgCost || 0;
}
function viewHolding(holding, market) {
	const fx = market.fx;
	const price = unitPrice(holding, market);
	const nowFx = fxToHuf(holding.currency, fx);
	const costFx = holding.costFxToHuf > 0 ? holding.costFxToHuf : nowFx;
	const native = holding.quantity * price;
	const huf = native * nowFx;
	const costHuf = holding.quantity * holding.avgCost * costFx;
	const pricePnlHuf = holding.quantity * (price - holding.avgCost) * costFx;
	const fxPnlHuf = holding.quantity * price * (nowFx - costFx);
	return {
		holding,
		price,
		native,
		huf,
		usd: fx.usdHuf > 0 ? huf / fx.usdHuf : 0,
		costHuf,
		pricePnlHuf,
		fxPnlHuf,
		totalPnlHuf: huf - costHuf
	};
}
function viewsOf(state, groupId) {
	return state.holdings.filter((holding) => !groupId || holding.groupId === groupId).map((holding) => viewHolding(holding, state.market));
}
function sumViews(rows) {
	return rows.reduce((acc, row) => {
		acc.huf += row.huf;
		acc.usd += row.usd;
		acc.costHuf += row.costHuf;
		acc.pricePnlHuf += row.pricePnlHuf;
		acc.fxPnlHuf += row.fxPnlHuf;
		return acc;
	}, {
		huf: 0,
		usd: 0,
		costHuf: 0,
		pricePnlHuf: 0,
		fxPnlHuf: 0
	});
}
function allocation(state, mode) {
	const rows = viewsOf(state);
	const map = /* @__PURE__ */ new Map();
	for (const row of rows) {
		const id = mode === "class" ? row.holding.assetClass : row.holding.groupId;
		const label = mode === "class" ? classLabel(row.holding.assetClass) : state.groups.find((group) => group.id === id)?.name ?? "Csoport nélkül";
		const prev = map.get(id) ?? {
			id,
			label,
			huf: 0,
			usd: 0
		};
		prev.huf += row.huf;
		prev.usd += row.usd;
		map.set(id, prev);
	}
	return [...map.values()].sort((a, b) => b.huf - a.huf);
}
function classLabel(assetClass) {
	if (assetClass === "etf") return "ETF";
	if (assetClass === "reszveny") return "Részvény";
	if (assetClass === "kripto") return "Kripto";
	return "Készpénz";
}
function toHuf(amount, currency, fx) {
	return amount * fxToHuf(currency, fx);
}
function monthlySubscriptionHuf(item, fx) {
	const huf = toHuf(item.amount, item.currency, fx);
	if (item.cadence === "heti") return huf * 52 / 12;
	if (item.cadence === "eves") return huf / 12;
	return huf;
}
function subscriptionTotals(items, fx) {
	const active = items.filter((item) => item.active);
	const monthly = active.reduce((sum, item) => sum + monthlySubscriptionHuf(item, fx), 0);
	const wasteful = active.filter((item) => item.wasteful).reduce((sum, item) => sum + monthlySubscriptionHuf(item, fx), 0);
	return {
		monthly,
		annual: monthly * 12,
		wastefulMonthly: wasteful,
		wastefulAnnual: wasteful * 12
	};
}
function goalCurrentHuf(goal, state) {
	return sumViews(viewsOf(state).filter((row) => goal.groupIds.length === 0 || goal.groupIds.includes(row.holding.groupId))).huf;
}
function goalTargetHuf(goal, state, today) {
	const nominal = toHuf(goal.target, goal.currency, state.market.fx);
	if (!goal.real) return nominal;
	return nominal * inflationFactor(state.inflationBase || state.capitalPlan.startDate, today);
}
function realHuf(nominal, base, today) {
	const factor = inflationFactor(base, today);
	if (factor <= 0) return nominal;
	return nominal / factor;
}
function nearest(series, date) {
	let best = null;
	for (const point of series) if (point.date <= date) best = point;
	else break;
	return best ?? series[0] ?? null;
}
function fxOn(market, date) {
	const point = nearest(market.fxHistory, date);
	if (!point) return market.fx;
	return {
		usdHuf: point.usdHuf,
		eurHuf: point.eurHuf,
		gbpHuf: point.gbpHuf
	};
}
function securityHufAt(holding, date, market) {
	if (holding.assetClass === "keszpenz") return null;
	const point = nearest(market.history[holding.symbol] ?? [], date);
	if (!point) return null;
	const fx = fxOn(market, date);
	if (fx.usdHuf <= 0) return null;
	return holding.quantity * point.usd * fx.usdHuf;
}
function cashHuf(state) {
	return sumViews(viewsOf(state).filter((row) => row.holding.assetClass === "keszpenz")).huf;
}
function capitalSeries(state, today) {
	const plan = state.capitalPlan;
	if (!/^\d{4}-\d{2}-\d{2}$/.test(plan.startDate)) return [];
	const start = /* @__PURE__ */ new Date(`${plan.startDate}T00:00:00`);
	const end = /* @__PURE__ */ new Date(`${today}T00:00:00`);
	if (Number.isNaN(start.getTime()) || start > end) return [];
	const cash = cashHuf(state);
	const points = [];
	const cursor = new Date(start.getFullYear(), start.getMonth(), 1);
	let index = 0;
	while (cursor <= end && index < 180) {
		const date = toIso(cursor);
		let securities = 0;
		let priced = 0;
		for (const holding of state.holdings) {
			const value = securityHufAt(holding, date, state.market);
			if (value == null) continue;
			securities += value;
			priced += 1;
		}
		points.push({
			date,
			toke: plan.initialHuf + index * plan.monthlyHuf,
			ertek: priced > 0 ? securities + cash : null
		});
		cursor.setMonth(cursor.getMonth() + 1);
		index += 1;
	}
	if (points.length) {
		const totals = sumViews(viewsOf(state));
		points[points.length - 1] = {
			...points[points.length - 1],
			date: today,
			ertek: totals.huf
		};
	}
	return points;
}
function classUsdSeries(state) {
	const classes = [
		"etf",
		"reszveny",
		"kripto"
	];
	const dates = /* @__PURE__ */ new Set();
	for (const holding of state.holdings) {
		if (holding.assetClass === "keszpenz") continue;
		for (const point of state.market.history[holding.symbol] ?? []) dates.add(point.date);
	}
	return [...dates].sort().map((date) => {
		const row = {
			date,
			etf: 0,
			reszveny: 0,
			kripto: 0
		};
		const seen = {
			etf: 0,
			reszveny: 0,
			kripto: 0
		};
		for (const holding of state.holdings) {
			if (holding.assetClass === "keszpenz") continue;
			const point = nearest(state.market.history[holding.symbol] ?? [], date);
			if (!point) continue;
			row[holding.assetClass] = (row[holding.assetClass] ?? 0) + holding.quantity * point.usd;
			seen[holding.assetClass] += 1;
		}
		for (const key of classes) if (!seen[key]) row[key] = null;
		return row;
	});
}
function investedToDate(plan, today) {
	if (!/^\d{4}-\d{2}-\d{2}$/.test(plan.startDate)) return plan.initialHuf;
	const start = /* @__PURE__ */ new Date(`${plan.startDate}T00:00:00`);
	const end = /* @__PURE__ */ new Date(`${today}T00:00:00`);
	if (Number.isNaN(start.getTime()) || end < start) return plan.initialHuf;
	const months = (end.getFullYear() - start.getFullYear()) * 12 + (end.getMonth() - start.getMonth());
	return plan.initialHuf + Math.max(0, months) * plan.monthlyHuf;
}
function yearsToTarget(present, monthly, target, annualReturnPct) {
	if (present >= target) return 0;
	if (target <= 0) return 0;
	const r = annualReturnPct / 100 / 12;
	if (monthly <= 0 && r <= 0) return null;
	if (Math.abs(r) < 1e-8) {
		if (monthly <= 0) return null;
		return (target - present) / monthly / 12;
	}
	const base = present + monthly / r;
	if (base <= 0) return null;
	const ratio = (target + monthly / r) / base;
	if (ratio <= 0) return null;
	const months = Math.log(ratio) / Math.log(1 + r);
	if (!Number.isFinite(months) || months < 0) return null;
	return months / 12;
}
function toIso(date) {
	const month = String(date.getMonth() + 1).padStart(2, "0");
	const day = String(date.getDate()).padStart(2, "0");
	return `${date.getFullYear()}-${month}-${day}`;
}
function addMonthsIso(iso, months) {
	const date = /* @__PURE__ */ new Date(`${iso}T00:00:00`);
	if (Number.isNaN(date.getTime())) return iso;
	date.setMonth(date.getMonth() + Math.round(months));
	return toIso(date);
}
function applyTrade(holdings, tx) {
	const index = holdings.findIndex((holding) => holding.symbol === tx.symbol && holding.groupId === tx.groupId && holding.assetClass === tx.assetClass);
	if (tx.side === "vetel") {
		if (index === -1) return [...holdings, {
			id: crypto.randomUUID(),
			symbol: tx.symbol,
			name: tx.name,
			assetClass: tx.assetClass,
			currency: tx.currency,
			groupId: tx.groupId,
			quantity: tx.quantity,
			avgCost: tx.price,
			costFxToHuf: tx.fxToHuf,
			yahoo: tx.yahoo,
			gecko: tx.gecko
		}];
		const current = holdings[index];
		const quantity = current.quantity + tx.quantity;
		const avgCost = quantity ? (current.quantity * current.avgCost + tx.quantity * tx.price) / quantity : 0;
		const costFx = quantity ? (current.quantity * current.costFxToHuf + tx.quantity * tx.fxToHuf) / quantity : tx.fxToHuf;
		return holdings.map((holding, i) => i === index ? {
			...current,
			quantity,
			avgCost,
			costFxToHuf: costFx,
			name: tx.name || current.name
		} : holding);
	}
	if (index === -1) return holdings;
	const current = holdings[index];
	const quantity = current.quantity - tx.quantity;
	if (quantity <= 1e-8) return holdings.filter((_, i) => i !== index);
	return holdings.map((holding, i) => i === index ? {
		...current,
		quantity
	} : holding);
}
function quotesFromCatalog() {
	const quotes = {};
	for (const item of CATALOG) quotes[item.symbol] = {
		price: item.fallback,
		currency: item.currency,
		changePct: null
	};
	return quotes;
}
var EMPTY_MARKET = {
	asOf: "",
	fxLive: false,
	fx: FALLBACK_FX,
	quotes: quotesFromCatalog(),
	history: {},
	fxHistory: [],
	errors: []
};
var SEED = {
	version: 1,
	sample: true,
	groups: [
		{
			id: "tbsz-2024",
			name: "TBSZ 2024",
			kind: "tbsz"
		},
		{
			id: "tbsz-2026",
			name: "TBSZ 2026",
			kind: "tbsz"
		},
		{
			id: "szabad",
			name: "Szabad számla",
			kind: "szabad"
		},
		{
			id: "kripto",
			name: "Kriptotárca",
			kind: "kripto"
		}
	],
	holdings: [
		{
			id: "h-vwce-24",
			symbol: "VWCE",
			name: "Vanguard FTSE All-World",
			assetClass: "etf",
			currency: "EUR",
			groupId: "tbsz-2024",
			quantity: 48,
			avgCost: 112,
			costFxToHuf: 370
		},
		{
			id: "h-sxr8-24",
			symbol: "SXR8",
			name: "iShares Core S&P 500",
			assetClass: "etf",
			currency: "EUR",
			groupId: "tbsz-2024",
			quantity: 8,
			avgCost: 520,
			costFxToHuf: 375
		},
		{
			id: "h-otp-24",
			symbol: "OTP",
			name: "OTP Bank",
			assetClass: "reszveny",
			currency: "HUF",
			groupId: "tbsz-2024",
			quantity: 120,
			avgCost: 16800,
			costFxToHuf: 1
		},
		{
			id: "h-vwce-26",
			symbol: "VWCE",
			name: "Vanguard FTSE All-World",
			assetClass: "etf",
			currency: "EUR",
			groupId: "tbsz-2026",
			quantity: 18,
			avgCost: 138,
			costFxToHuf: 360
		},
		{
			id: "h-rich-26",
			symbol: "RICHTER",
			name: "Richter Gedeon",
			assetClass: "reszveny",
			currency: "HUF",
			groupId: "tbsz-2026",
			quantity: 40,
			avgCost: 9100,
			costFxToHuf: 1
		},
		{
			id: "h-huf-26",
			symbol: "HUF",
			name: "Készpénz (HUF)",
			assetClass: "keszpenz",
			currency: "HUF",
			groupId: "tbsz-2026",
			quantity: 15e4,
			avgCost: 1,
			costFxToHuf: 1
		},
		{
			id: "h-eur-26",
			symbol: "EUR",
			name: "Készpénz (EUR)",
			assetClass: "keszpenz",
			currency: "EUR",
			groupId: "tbsz-2026",
			quantity: 80,
			avgCost: 1,
			costFxToHuf: 390
		},
		{
			id: "h-mol",
			symbol: "MOL",
			name: "MOL",
			assetClass: "reszveny",
			currency: "HUF",
			groupId: "szabad",
			quantity: 50,
			avgCost: 2850,
			costFxToHuf: 1
		},
		{
			id: "h-huf",
			symbol: "HUF",
			name: "Készpénz (HUF)",
			assetClass: "keszpenz",
			currency: "HUF",
			groupId: "szabad",
			quantity: 42e4,
			avgCost: 1,
			costFxToHuf: 1
		},
		{
			id: "h-eur",
			symbol: "EUR",
			name: "Készpénz (EUR)",
			assetClass: "keszpenz",
			currency: "EUR",
			groupId: "szabad",
			quantity: 1250,
			avgCost: 1,
			costFxToHuf: 410
		},
		{
			id: "h-usd",
			symbol: "USD",
			name: "Készpénz (USD)",
			assetClass: "keszpenz",
			currency: "USD",
			groupId: "szabad",
			quantity: 600,
			avgCost: 1,
			costFxToHuf: 350
		},
		{
			id: "h-btc",
			symbol: "BTC",
			name: "Bitcoin",
			assetClass: "kripto",
			currency: "USD",
			groupId: "kripto",
			quantity: .065,
			avgCost: 42e3,
			costFxToHuf: 400
		},
		{
			id: "h-eth",
			symbol: "ETH",
			name: "Ethereum",
			assetClass: "kripto",
			currency: "USD",
			groupId: "kripto",
			quantity: 1.15,
			avgCost: 1800,
			costFxToHuf: 365
		},
		{
			id: "h-sol",
			symbol: "SOL",
			name: "Solana",
			assetClass: "kripto",
			currency: "USD",
			groupId: "kripto",
			quantity: 22,
			avgCost: 70,
			costFxToHuf: 360
		}
	],
	transactions: [
		{
			id: "t1",
			date: "2023-02-15",
			side: "vetel",
			symbol: "VWCE",
			name: "Vanguard FTSE All-World",
			assetClass: "etf",
			currency: "EUR",
			groupId: "tbsz-2024",
			quantity: 48,
			price: 112,
			fxToHuf: 370,
			note: "TBSZ nyitás"
		},
		{
			id: "t2",
			date: "2023-06-01",
			side: "vetel",
			symbol: "OTP",
			name: "OTP Bank",
			assetClass: "reszveny",
			currency: "HUF",
			groupId: "tbsz-2024",
			quantity: 120,
			price: 16800,
			fxToHuf: 1,
			note: ""
		},
		{
			id: "t3",
			date: "2024-01-10",
			side: "vetel",
			symbol: "SXR8",
			name: "iShares Core S&P 500",
			assetClass: "etf",
			currency: "EUR",
			groupId: "tbsz-2024",
			quantity: 8,
			price: 520,
			fxToHuf: 375,
			note: ""
		},
		{
			id: "t4",
			date: "2024-11-02",
			side: "vetel",
			symbol: "BTC",
			name: "Bitcoin",
			assetClass: "kripto",
			currency: "USD",
			groupId: "kripto",
			quantity: .065,
			price: 42e3,
			fxToHuf: 400,
			note: "Saját tárca"
		},
		{
			id: "t5",
			date: "2025-03-20",
			side: "vetel",
			symbol: "VWCE",
			name: "Vanguard FTSE All-World",
			assetClass: "etf",
			currency: "EUR",
			groupId: "tbsz-2026",
			quantity: 18,
			price: 138,
			fxToHuf: 360,
			note: "Új TBSZ"
		},
		{
			id: "t6",
			date: "2026-01-15",
			side: "vetel",
			symbol: "SOL",
			name: "Solana",
			assetClass: "kripto",
			currency: "USD",
			groupId: "kripto",
			quantity: 22,
			price: 70,
			fxToHuf: 360,
			note: ""
		},
		{
			id: "t7",
			date: "2026-06-01",
			side: "osztalek",
			symbol: "OTP",
			name: "OTP Bank",
			assetClass: "reszveny",
			currency: "HUF",
			groupId: "tbsz-2024",
			quantity: 120,
			price: 690,
			fxToHuf: 1,
			note: "Osztalék a TBSZ-en"
		}
	],
	subscriptions: [
		{
			id: "s1",
			name: "Telekom mobil",
			amount: 8990,
			currency: "HUF",
			cadence: "havi",
			category: "Rezsi",
			nextDate: "2026-11-04",
			active: true,
			wasteful: false,
			note: ""
		},
		{
			id: "s2",
			name: "Edzőterem",
			amount: 14900,
			currency: "HUF",
			cadence: "havi",
			category: "Egészség",
			nextDate: "2026-11-01",
			active: true,
			wasteful: false,
			note: ""
		},
		{
			id: "s3",
			name: "Spotify",
			amount: 2190,
			currency: "HUF",
			cadence: "havi",
			category: "Szórakozás",
			nextDate: "2026-11-12",
			active: true,
			wasteful: false,
			note: ""
		},
		{
			id: "s4",
			name: "Netflix",
			amount: 3490,
			currency: "HUF",
			cadence: "havi",
			category: "Szórakozás",
			nextDate: "2026-11-18",
			active: true,
			wasteful: false,
			note: ""
		},
		{
			id: "s5",
			name: "YouTube Premium",
			amount: 3990,
			currency: "HUF",
			cadence: "havi",
			category: "Szórakozás",
			nextDate: "2026-11-09",
			active: true,
			wasteful: true,
			note: "Alig nyitom meg"
		},
		{
			id: "s6",
			name: "ChatGPT Plus",
			amount: 20,
			currency: "USD",
			cadence: "havi",
			category: "Szoftver",
			nextDate: "2026-11-03",
			active: true,
			wasteful: false,
			note: ""
		},
		{
			id: "s7",
			name: "iCloud+",
			amount: 1490,
			currency: "HUF",
			cadence: "havi",
			category: "Szoftver",
			nextDate: "2026-11-21",
			active: true,
			wasteful: false,
			note: ""
		},
		{
			id: "s8",
			name: "Régi VPN",
			amount: 9.99,
			currency: "USD",
			cadence: "havi",
			category: "Szoftver",
			nextDate: "2026-11-15",
			active: true,
			wasteful: true,
			note: "Van helyette más"
		},
		{
			id: "s9",
			name: "Biztosítás",
			amount: 86e3,
			currency: "HUF",
			cadence: "eves",
			category: "Biztosítás",
			nextDate: "2027-03-01",
			active: true,
			wasteful: false,
			note: ""
		}
	],
	goals: [
		{
			id: "g1",
			name: "Vésztartalék",
			target: 12e5,
			currency: "HUF",
			deadline: "",
			groupIds: ["szabad"],
			real: false,
			note: "A szabad számla készpénze és papírjai."
		},
		{
			id: "g2",
			name: "TBSZ vagyon",
			target: 2e7,
			currency: "HUF",
			deadline: "2030-12-31",
			groupIds: ["tbsz-2024", "tbsz-2026"],
			real: false,
			note: "A két lekötött számla együtt."
		},
		{
			id: "g3",
			name: "Önállóság",
			target: 8e7,
			currency: "HUF",
			deadline: "2038-01-01",
			groupIds: [],
			real: true,
			note: "A teljes vagyon, inflációval hízó cél."
		}
	],
	capitalPlan: {
		startDate: "2023-01-01",
		initialHuf: 25e5,
		monthlyHuf: 18e4
	},
	fire: {
		swrPct: 3.5,
		realReturnPct: 5,
		extraAnnualHuf: 36e5
	},
	inflationBase: "2023-01-01",
	market: EMPTY_MARKET
};
function emptyState() {
	return {
		...SEED,
		sample: false,
		groups: [{
			id: "szabad",
			name: "Szabad számla",
			kind: "szabad"
		}],
		holdings: [],
		transactions: [],
		subscriptions: [],
		goals: [],
		market: EMPTY_MARKET
	};
}
function asRecord(value) {
	if (!value || typeof value !== "object" || Array.isArray(value)) return null;
	return value;
}
function sanitizeState(raw) {
	const record = asRecord(raw);
	if (!record) return SEED;
	const groups = Array.isArray(record.groups) ? record.groups : SEED.groups;
	const holdings = Array.isArray(record.holdings) ? record.holdings : [];
	const transactions = Array.isArray(record.transactions) ? record.transactions : [];
	const subscriptions = Array.isArray(record.subscriptions) ? record.subscriptions : [];
	const goals = Array.isArray(record.goals) ? record.goals : [];
	const capital = asRecord(record.capitalPlan);
	const fire = asRecord(record.fire);
	const market = asRecord(record.market);
	return {
		version: 1,
		sample: Boolean(record.sample),
		groups,
		holdings,
		transactions,
		subscriptions,
		goals,
		capitalPlan: {
			startDate: typeof capital?.startDate === "string" ? capital.startDate : SEED.capitalPlan.startDate,
			initialHuf: Number(capital?.initialHuf ?? SEED.capitalPlan.initialHuf) || 0,
			monthlyHuf: Number(capital?.monthlyHuf ?? SEED.capitalPlan.monthlyHuf) || 0
		},
		fire: {
			swrPct: Number(fire?.swrPct ?? SEED.fire.swrPct) || 3.5,
			realReturnPct: Number(fire?.realReturnPct ?? SEED.fire.realReturnPct) || 0,
			extraAnnualHuf: Number(fire?.extraAnnualHuf ?? SEED.fire.extraAnnualHuf) || 0
		},
		inflationBase: typeof record.inflationBase === "string" ? record.inflationBase : SEED.inflationBase,
		market: market ? {
			...EMPTY_MARKET,
			...market,
			fx: {
				...FALLBACK_FX,
				...asRecord(market.fx) ?? {}
			},
			quotes: {
				...quotesFromCatalog(),
				...asRecord(market.quotes) ?? {}
			},
			history: asRecord(market.history) ?? {},
			fxHistory: Array.isArray(market.fxHistory) ? market.fxHistory : [],
			errors: []
		} : EMPTY_MARKET
	};
}
var KEY = "szamvetes.v1";
function mergeMarket(prev, next) {
	const history = { ...prev.history };
	for (const [symbol, points] of Object.entries(next.history)) if (points.length) history[symbol] = points;
	return {
		asOf: next.asOf || prev.asOf,
		fxLive: next.fxLive || prev.fxLive,
		fx: next.fxLive ? next.fx : prev.fx,
		quotes: {
			...prev.quotes,
			...next.quotes
		},
		history,
		fxHistory: next.fxHistory.length ? next.fxHistory : prev.fxHistory,
		errors: next.errors
	};
}
var Ctx = (0, import_react.createContext)(null);
function PortfolioProvider({ children }) {
	const [state, setState] = (0, import_react.useState)(SEED);
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	const [refreshing, setRefreshing] = (0, import_react.useState)(false);
	const [marketError, setMarketError] = (0, import_react.useState)(null);
	const [range, setRange] = (0, import_react.useState)("1y");
	const stateRef = (0, import_react.useRef)(state);
	const rangeRef = (0, import_react.useRef)(range);
	stateRef.current = state;
	rangeRef.current = range;
	const commit = (next) => {
		stateRef.current = next;
		setState(next);
	};
	(0, import_react.useEffect)(() => {
		const raw = localStorage.getItem(KEY);
		if (raw) try {
			commit(sanitizeState(JSON.parse(raw)));
		} catch {}
		setHydrated(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		localStorage.setItem(KEY, JSON.stringify(state));
	}, [state, hydrated]);
	const refresh = async () => {
		setRefreshing(true);
		setMarketError(null);
		try {
			const { instrumentsFrom } = await import("./catalog-D0BjXlW4.mjs").then((n) => n.i).then((n) => n.r);
			const snap = await fetchMarket({ data: {
				range: rangeRef.current,
				instruments: instrumentsFrom(stateRef.current.holdings)
			} });
			const current = stateRef.current;
			commit({
				...current,
				market: mergeMarket(current.market, snap)
			});
			setMarketError(snap.errors.length ? snap.errors.join(" ") : null);
		} catch (error) {
			setMarketError(error instanceof Error ? error.message : "Az árak nem frissültek.");
		} finally {
			setRefreshing(false);
		}
	};
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		let dead = false;
		setRefreshing(true);
		(async () => {
			try {
				const { instrumentsFrom } = await import("./catalog-D0BjXlW4.mjs").then((n) => n.i).then((n) => n.r);
				const snap = await fetchMarket({ data: {
					range,
					instruments: instrumentsFrom(stateRef.current.holdings)
				} });
				if (dead) return;
				const current = stateRef.current;
				commit({
					...current,
					market: mergeMarket(current.market, snap)
				});
				setMarketError(snap.errors.length ? snap.errors.join(" ") : null);
			} catch (error) {
				if (!dead) setMarketError(error instanceof Error ? error.message : "Az árak nem frissültek.");
			} finally {
				if (!dead) setRefreshing(false);
			}
		})();
		return () => {
			dead = true;
		};
	}, [hydrated, range]);
	const touch = (recipe) => {
		const next = recipe(stateRef.current);
		commit({
			...next,
			sample: false
		});
	};
	const api = {
		state,
		refreshing,
		marketError,
		range,
		setRange,
		refresh,
		saveHolding: (holding) => {
			const known = findCatalog(holding.symbol);
			const next = {
				...holding,
				symbol: holding.symbol.trim().toUpperCase(),
				name: holding.name.trim() || known?.name || holding.symbol,
				yahoo: holding.yahoo || known?.yahoo,
				gecko: holding.gecko || known?.gecko
			};
			touch((current) => {
				const exists = current.holdings.some((item) => item.id === next.id);
				return {
					...current,
					holdings: exists ? current.holdings.map((item) => item.id === next.id ? next : item) : [...current.holdings, next]
				};
			});
		},
		deleteHolding: (id) => touch((current) => ({
			...current,
			holdings: current.holdings.filter((item) => item.id !== id)
		})),
		saveGroup: (group) => touch((current) => ({
			...current,
			groups: current.groups.some((item) => item.id === group.id) ? current.groups.map((item) => item.id === group.id ? group : item) : [...current.groups, group]
		})),
		deleteGroup: (id) => {
			if (stateRef.current.holdings.some((item) => item.groupId === id)) return "A csoportban még van eszköz. Előbb mozgasd vagy töröld őket.";
			touch((current) => ({
				...current,
				groups: current.groups.filter((item) => item.id !== id),
				goals: current.goals.map((goal) => ({
					...goal,
					groupIds: goal.groupIds.filter((groupId) => groupId !== id)
				})),
				transactions: current.transactions.map((tx) => tx.groupId === id ? {
					...tx,
					groupId: current.groups.find((group) => group.id !== id)?.id ?? tx.groupId
				} : tx)
			}));
			return null;
		},
		saveTx: (tx, apply) => touch((current) => {
			const side = tx.side;
			const holdings = apply && (side === "vetel" || side === "eladas") ? applyTrade(current.holdings, {
				...tx,
				side
			}) : current.holdings;
			return {
				...current,
				transactions: [tx, ...current.transactions.filter((item) => item.id !== tx.id)],
				holdings
			};
		}),
		deleteTx: (id) => touch((current) => ({
			...current,
			transactions: current.transactions.filter((item) => item.id !== id)
		})),
		saveSub: (item) => touch((current) => ({
			...current,
			subscriptions: current.subscriptions.some((sub) => sub.id === item.id) ? current.subscriptions.map((sub) => sub.id === item.id ? item : sub) : [...current.subscriptions, item]
		})),
		deleteSub: (id) => touch((current) => ({
			...current,
			subscriptions: current.subscriptions.filter((item) => item.id !== id)
		})),
		saveGoal: (goal) => touch((current) => ({
			...current,
			goals: current.goals.some((item) => item.id === goal.id) ? current.goals.map((item) => item.id === goal.id ? goal : item) : [...current.goals, goal]
		})),
		deleteGoal: (id) => touch((current) => ({
			...current,
			goals: current.goals.filter((item) => item.id !== id)
		})),
		setPlan: (plan) => touch((current) => ({
			...current,
			capitalPlan: plan
		})),
		setFire: (fire) => touch((current) => ({
			...current,
			fire
		})),
		setInflationBase: (iso) => touch((current) => ({
			...current,
			inflationBase: iso
		})),
		importRows: (items, mode) => touch((current) => {
			const holdings = [...current.holdings];
			for (const { row, groupId } of items) {
				const known = findCatalog(row.symbol);
				const index = holdings.findIndex((holding) => holding.symbol === row.symbol && holding.groupId === groupId && holding.assetClass === row.assetClass);
				const fx = fxToHuf(row.currency, current.market.fx);
				if (index === -1) holdings.push({
					id: crypto.randomUUID(),
					symbol: row.symbol,
					name: row.name,
					assetClass: row.assetClass,
					currency: row.currency,
					groupId,
					quantity: row.quantity,
					avgCost: row.assetClass === "keszpenz" ? 1 : row.price ?? 0,
					costFxToHuf: fx,
					yahoo: known?.yahoo,
					gecko: known?.gecko
				});
				else if (mode === "csere") holdings[index] = {
					...holdings[index],
					quantity: row.quantity,
					name: row.name || holdings[index].name
				};
				else {
					const currentHolding = holdings[index];
					const price = row.price ?? currentHolding.avgCost;
					const quantity = currentHolding.quantity + row.quantity;
					const avgCost = quantity ? (currentHolding.quantity * currentHolding.avgCost + row.quantity * price) / quantity : currentHolding.avgCost;
					holdings[index] = {
						...currentHolding,
						quantity,
						avgCost
					};
				}
			}
			return {
				...current,
				holdings
			};
		}),
		upsertWallet: ({ chain, address, symbol, quantity, groupId }) => touch((current) => {
			const known = findCatalog(symbol);
			const price = current.market.quotes[symbol]?.price ?? known?.fallback ?? 0;
			const index = current.holdings.findIndex((holding) => holding.chain === chain && holding.walletAddress === address);
			if (index === -1) {
				const created = {
					id: crypto.randomUUID(),
					symbol,
					name: known?.name ?? symbol,
					assetClass: "kripto",
					currency: "USD",
					groupId,
					quantity,
					avgCost: price,
					costFxToHuf: current.market.fx.usdHuf,
					gecko: known?.gecko,
					chain,
					walletAddress: address
				};
				return {
					...current,
					holdings: [...current.holdings, created]
				};
			}
			return {
				...current,
				holdings: current.holdings.map((holding, i) => i === index ? {
					...holding,
					quantity,
					groupId
				} : holding)
			};
		}),
		loadSample: () => commit(SEED),
		clearAll: () => commit(emptyState()),
		dismissSample: () => commit({
			...stateRef.current,
			sample: false
		}),
		importBackup: (raw) => {
			commit({
				...sanitizeState(raw?.state ?? raw),
				sample: false
			});
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ctx.Provider, {
		value: api,
		children
	});
}
function usePortfolio() {
	const value = (0, import_react.useContext)(Ctx);
	if (!value) throw new Error("A portfólió környezet hiányzik.");
	return value;
}
var styles_default = "/assets/styles-DCY4AtLm.css";
var Route$7 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Számvetés" },
			{
				name: "theme-color",
				content: "#1d4736"
			},
			{
				name: "description",
				content: "Magyar portfóliókövető: TBSZ, ETF, részvény, kripto és előfizetés, forintban és dollárban."
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "hu",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PortfolioProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	})
});
var $$splitComponentImporter$6 = () => import("./routes-DigUSM1O.mjs");
var Route$6 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./beolvasas-GqIv96Fk.mjs");
var Route$5 = createFileRoute("/beolvasas")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./celok-2c4qv_68.mjs");
var Route$4 = createFileRoute("/celok")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./dijak-C9NZLyY3.mjs");
var Route$3 = createFileRoute("/dijak")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./eszkozok-CxIIXqwZ.mjs");
var Route$2 = createFileRoute("/eszkozok")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./meg-CWB9lELs.mjs");
var Route$1 = createFileRoute("/meg")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./mozgasok-BoigyY2V.mjs");
var Route = createFileRoute("/mozgasok")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var rootRouteChildren = {
	IndexRoute: Route$6.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$7
	}),
	BeolvasasRoute: Route$5.update({
		id: "/beolvasas",
		path: "/beolvasas",
		getParentRoute: () => Route$7
	}),
	CelokRoute: Route$4.update({
		id: "/celok",
		path: "/celok",
		getParentRoute: () => Route$7
	}),
	DijakRoute: Route$3.update({
		id: "/dijak",
		path: "/dijak",
		getParentRoute: () => Route$7
	}),
	EszkozokRoute: Route$2.update({
		id: "/eszkozok",
		path: "/eszkozok",
		getParentRoute: () => Route$7
	}),
	MegRoute: Route$1.update({
		id: "/meg",
		path: "/meg",
		getParentRoute: () => Route$7
	}),
	MozgasokRoute: Route.update({
		id: "/mozgasok",
		path: "/mozgasok",
		getParentRoute: () => Route$7
	})
};
var routeTree = Route$7._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		rewrite: previewPathRewrite(),
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { viewsOf as _, capitalSeries as a, inflationLossPct as b, goalCurrentHuf as c, monthlySubscriptionHuf as d, realHuf as f, viewHolding as g, toHuf as h, allocation as i, goalTargetHuf as l, sumViews as m, usePortfolio as n, classUsdSeries as o, subscriptionTotals as p, addMonthsIso as r, fxToHuf as s, router_exports as t, investedToDate as u, yearsToTarget as v, createSsrRpc as x, inflationFactor as y };
