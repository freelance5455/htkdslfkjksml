import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as Slot } from "../_libs/@radix-ui/react-primitive+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as getLeaguePrior, c as remainingGoalsDist, i as getLeagueAvgGoals, n as cdfFromPmf, o as initials, r as clamp, t as CONFIG } from "./math-DEeAY6PY.mjs";
import { i as Activity, n as RefreshCw, r as History } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as SwitchThumb, t as Switch$1 } from "../_libs/@radix-ui/react-switch+[...].mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-UfpOUemb.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[opacity,transform,background-color,box-shadow] duration-150 ease-[var(--ease-out-smooth)] disabled:pointer-events-none disabled:opacity-40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/40 active:scale-[0.98]", {
	variants: {
		variant: {
			default: "bg-accent text-accent-fg shadow-[var(--shadow-border)] hover:opacity-90",
			ghost: "bg-elevated text-fg shadow-[var(--shadow-border)] hover:bg-elevated/80",
			outline: "bg-transparent text-fg shadow-[var(--shadow-border)] hover:bg-elevated",
			live: "bg-live/15 text-live shadow-[0_0_0_1px_rgb(226_75_75/0.28)]",
			hot: "bg-hot/15 text-hot shadow-[0_0_0_1px_rgb(61_154_122/0.28)]"
		},
		size: {
			default: "h-10 px-4",
			sm: "h-8 px-3 text-xs",
			lg: "h-11 px-5",
			icon: "size-10"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
function Switch({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch$1, {
		className: cn("peer inline-flex h-6 w-10 shrink-0 items-center rounded-full bg-elevated shadow-[var(--shadow-border)] transition-colors data-[state=checked]:bg-accent", className),
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchThumb, { className: "pointer-events-none block size-5 translate-x-0.5 rounded-full bg-fg transition-transform data-[state=checked]:translate-x-4 data-[state=checked]:bg-accent-fg" })
	});
}
var KEY = "bolaCristal_history_v3";
function loadHistory() {
	try {
		return JSON.parse(localStorage.getItem(KEY) || "[]");
	} catch {
		return [];
	}
}
function saveHistory(items) {
	try {
		localStorage.setItem(KEY, JSON.stringify(items.slice(-200)));
	} catch {}
}
function brier(p, y) {
	return (p - y) * (p - y);
}
function computeOverRest(x) {
	const m = String(x.score || "").match(/(\d+)\s*[–\-]\s*(\d+)/);
	const goalsAtPred = m ? +m[1] + +m[2] : 0;
	if (!x.result) return null;
	return x.result.home + x.result.away > goalsAtPred ? 1 : 0;
}
var RAW = [
	{
		h: "Real Madrid",
		a: "Barcelona",
		sh: 2,
		sa: 2,
		m: 68,
		htH: 1,
		htA: 1,
		xgH: 1.85,
		xgA: 1.62,
		shH: 14,
		shA: 11,
		sotH: 6,
		sotA: 5,
		cH: 7,
		cA: 5,
		bcH: 4,
		bcA: 3,
		pH: 54,
		pA: 46,
		fH: 9,
		fA: 11,
		svH: 3,
		svA: 4,
		wH: 1,
		wA: 0,
		blH: 2,
		blA: 3,
		siH: 8,
		siA: 6,
		soH: 6,
		soA: 5,
		liga: "La Liga",
		attH: 45,
		attA: 32,
		dangH: 38,
		dangA: 22
	},
	{
		h: "Man City",
		a: "Liverpool",
		sh: 1,
		sa: 0,
		m: 55,
		htH: 1,
		htA: 0,
		xgH: 1.1,
		xgA: .55,
		shH: 9,
		shA: 5,
		sotH: 4,
		sotA: 2,
		cH: 6,
		cA: 2,
		bcH: 2,
		bcA: 1,
		pH: 62,
		pA: 38,
		fH: 7,
		fA: 10,
		svH: 2,
		svA: 3,
		wH: 0,
		wA: 0,
		blH: 1,
		blA: 2,
		siH: 5,
		siA: 3,
		soH: 4,
		soA: 2,
		liga: "Premier League",
		attH: 38,
		attA: 28,
		dangH: 30,
		dangA: 18
	},
	{
		h: "Bayern",
		a: "Dortmund",
		sh: 0,
		sa: 1,
		m: 72,
		htH: 0,
		htA: 0,
		xgH: 1.4,
		xgA: .9,
		shH: 12,
		shA: 8,
		sotH: 5,
		sotA: 4,
		cH: 8,
		cA: 3,
		bcH: 3,
		bcA: 2,
		pH: 58,
		pA: 42,
		fH: 8,
		fA: 12,
		svH: 3,
		svA: 4,
		wH: 1,
		wA: 1,
		blH: 3,
		blA: 2,
		siH: 7,
		siA: 4,
		soH: 5,
		soA: 4,
		liga: "Bundesliga",
		attH: 42,
		attA: 30,
		dangH: 35,
		dangA: 20
	},
	{
		h: "Benfica",
		a: "Porto",
		sh: 1,
		sa: 1,
		m: 78,
		htH: 1,
		htA: 0,
		xgH: 1.05,
		xgA: 1.15,
		shH: 10,
		shA: 11,
		sotH: 4,
		sotA: 5,
		cH: 5,
		cA: 6,
		bcH: 2,
		bcA: 3,
		pH: 48,
		pA: 52,
		fH: 14,
		fA: 13,
		svH: 4,
		svA: 3,
		wH: 0,
		wA: 0,
		blH: 2,
		blA: 2,
		siH: 6,
		siA: 7,
		soH: 4,
		soA: 4,
		liga: "Liga Portugal",
		attH: 35,
		attA: 38,
		dangH: 25,
		dangA: 28
	},
	{
		h: "PSG",
		a: "Marseille",
		sh: 2,
		sa: 0,
		m: 40,
		htH: null,
		htA: null,
		xgH: 1.7,
		xgA: .35,
		shH: 11,
		shA: 3,
		sotH: 5,
		sotA: 1,
		cH: 6,
		cA: 1,
		bcH: 3,
		bcA: 0,
		pH: 65,
		pA: 35,
		fH: 6,
		fA: 9,
		svH: 1,
		svA: 3,
		wH: 0,
		wA: 0,
		blH: 1,
		blA: 1,
		siH: 7,
		siA: 1,
		soH: 4,
		soA: 2,
		liga: "Ligue 1",
		attH: 40,
		attA: 20,
		dangH: 32,
		dangA: 12
	},
	{
		h: "Milan",
		a: "Inter",
		sh: 0,
		sa: 0,
		m: 32,
		htH: null,
		htA: null,
		xgH: .45,
		xgA: .5,
		shH: 4,
		shA: 5,
		sotH: 1,
		sotA: 2,
		cH: 2,
		cA: 3,
		bcH: 1,
		bcA: 1,
		pH: 47,
		pA: 53,
		fH: 5,
		fA: 6,
		svH: 2,
		svA: 1,
		wH: 0,
		wA: 0,
		blH: 1,
		blA: 1,
		siH: 2,
		siA: 3,
		soH: 2,
		soA: 2,
		liga: "Serie A",
		attH: 28,
		attA: 30,
		dangH: 18,
		dangA: 20
	}
];
function getExampleBundles() {
	return RAW.map((g, i) => {
		return {
			match: {
				id: `demo-${i}`,
				eventId: `demo-${i}`,
				homeTeam: { name: g.h },
				awayTeam: { name: g.a },
				score: { fullTime: {
					home: g.sh,
					away: g.sa
				} },
				htScore: {
					home: g.htH,
					away: g.htA
				},
				minute: g.m,
				minuteDisplay: String(g.m),
				league: g.liga,
				country: "",
				period: g.m <= 45 ? "1h" : "2h",
				source: "demo",
				events: []
			},
			stats: {
				xgH: g.xgH,
				xgA: g.xgA,
				xgotH: 0,
				xgotA: 0,
				xaH: 0,
				xaA: 0,
				shotsH: g.shH,
				shotsA: g.shA,
				sotH: g.sotH,
				sotA: g.sotA,
				cornersH: g.cH,
				cornersA: g.cA,
				foulsH: g.fH,
				foulsA: g.fA,
				bcH: g.bcH,
				bcA: g.bcA,
				possH: g.pH,
				possA: g.pA,
				savesH: g.svH,
				savesA: g.svA,
				woodH: g.wH,
				woodA: g.wA,
				blockedH: g.blH,
				blockedA: g.blA,
				offH: 0,
				offA: 0,
				yelH: 0,
				yelA: 0,
				redH: g.rH || 0,
				redA: g.rA || 0,
				shotsInH: g.siH,
				shotsInA: g.siA,
				shotsOutH: g.soH,
				shotsOutA: g.soA,
				attacksH: g.attH,
				attacksA: g.attA,
				dangerousH: g.dangH,
				dangerousA: g.dangA,
				touchesBoxH: g.dangH,
				touchesBoxA: g.dangA,
				crossesH: 0,
				crossesA: 0,
				clearancesH: 0,
				clearancesA: 0,
				duelsH: 0,
				duelsA: 0,
				passesH: 0,
				passesA: 0,
				accuratePassesH: 0,
				accuratePassesA: 0,
				tacklesH: 0,
				tacklesA: 0,
				interceptionsH: 0,
				interceptionsA: 0,
				sourceVerified: true,
				source: "demo",
				dataCompleteness: 80,
				half2: null
			}
		};
	});
}
var MODEL_LABEL = "Motor v15 · binomial negativa + Dixon-Coles";
function emptyPred() {
	return {
		has: false,
		level: "none",
		rec: "",
		analyst: null,
		verdict: null,
		predicted: "—",
		probability: 0,
		nextTeamAnyProb: 0,
		nextTeamOtherGoalProbH: 0,
		nextTeamOtherGoalProbA: 0,
		danger: 0,
		conf: 0,
		shrink: 1,
		reliability: 0,
		aligned: true,
		xgH: 0,
		xgA: 0,
		shotsH: 0,
		shotsA: 0,
		sotH: 0,
		sotA: 0,
		corH: 0,
		corA: 0,
		bcH: 0,
		bcA: 0,
		possH: 50,
		possA: 50,
		foulsH: 0,
		foulsA: 0,
		savesH: 0,
		savesA: 0,
		woodH: 0,
		woodA: 0,
		blockedH: 0,
		blockedA: 0,
		yelH: 0,
		yelA: 0,
		redH: 0,
		redA: 0,
		shotsInH: 0,
		shotsInA: 0,
		shotsOutH: 0,
		shotsOutA: 0,
		pressure: {
			home: 50,
			away: 50,
			diff: 0,
			dominant: "",
			intensity: .5,
			source: "none"
		},
		summary: "",
		nextReason: "",
		intensity: .5,
		momentum: 0,
		momentumSource: "none",
		momentumPoints: null,
		totalDanger: 0,
		expTotal: 0,
		expRem: 0,
		ouLines: CONFIG.OU_LINES.map((line) => ({
			line,
			over: 0,
			under: 100,
			done: false
		})),
		ouLinesHT: CONFIG.HT_OU_LINES.map((line) => ({
			line,
			over: null,
			under: null,
			done: false,
			missed: false,
			unknown: true,
			resolved: false
		})),
		ouLines2H: CONFIG.HT_OU_LINES.map((line) => ({
			line,
			over: null,
			under: null,
			done: false,
			missed: false,
			unknown: true,
			resolved: false
		})),
		bttsYes: 0,
		bttsNo: 100,
		bttsDone: false,
		pAny: 0,
		p0: 100,
		p1: 0,
		p2: 0,
		p3plus: 0,
		rateH: 0,
		rateA: 0,
		pressH: 0,
		pressA: 0,
		stillIn1H: false,
		htGoalsSoFar: null,
		htGoalsKnown: false,
		goals2HSoFar: null,
		rem1H: 0,
		rem2H: 0,
		timeWindows: CONFIG.TIME_WINDOWS.map((mins) => ({
			mins,
			prob: 0
		})),
		leagueAvgGoals: 2.7,
		model: MODEL_LABEL
	};
}
function computePressure(stats, team, minute) {
	const s = (h, a) => team === "home" ? h : a;
	const attacks = s(stats.attacksH, stats.attacksA);
	const dangerous = s(stats.dangerousH, stats.dangerousA);
	const shots = s(stats.shotsH, stats.shotsA);
	const sot = s(stats.sotH, stats.sotA);
	const corners = s(stats.cornersH, stats.cornersA);
	const bc = s(stats.bcH, stats.bcA);
	const possession = s(stats.possH, stats.possA);
	const xg = s(stats.xgH, stats.xgA);
	const xgot = s(stats.xgotH, stats.xgotA);
	const xa = s(stats.xaH, stats.xaA);
	const box = s(stats.touchesBoxH, stats.touchesBoxA);
	const shotsIn = s(stats.shotsInH, stats.shotsInA);
	const perMinute = Math.max(.01, minute);
	let total = Math.min(22, attacks / perMinute * 1) + Math.min(22, dangerous / perMinute * 2.2) + Math.min(14, shots / perMinute * 1.5) + Math.min(16, sot / perMinute * 3.2) + Math.min(8, corners / perMinute * 1.7) + Math.min(24, bc / perMinute * 5.5) + (possession - 38) * .22 + Math.min(20, xg / perMinute * 18) + Math.min(16, xgot / perMinute * 22) + Math.min(10, xa / perMinute * 14) + Math.min(14, box / perMinute * 1.8) + Math.min(12, shotsIn / perMinute * 2.4);
	if (bc >= 2 && sot >= 3) total *= 1.12;
	else if (bc >= 1 && sot >= 2) total *= 1.06;
	if (xgot >= .6 || xg >= 1) total *= 1.05;
	return clamp(total, 0, 100);
}
function computeIntensity(stats, minute) {
	const events = (stats.shotsH + stats.shotsA) * 1.15 + (stats.foulsH + stats.foulsA) * .7 + (stats.cornersH + stats.cornersA) * 1.1 + (stats.attacksH + stats.attacksA) * .9 + (stats.bcH + stats.bcA) * 2.4;
	return clamp((events / Math.max(1, minute) - .18) / .85, 0, 1);
}
var snaps = /* @__PURE__ */ new Map();
function computeMomentum(match, stats, graph) {
	if (graph && graph.length) {
		const recent = graph.slice(-8);
		const last = recent[recent.length - 1];
		const first = recent[0];
		const lastNorm = clamp((last.value || 0) / 100, -1, 1);
		const slope = recent.length > 1 ? clamp((last.value - first.value) / recent.length / 40, -1, 1) : 0;
		const combined = clamp(lastNorm * .6 + slope * .4, -1, 1);
		return {
			home: combined > 0 ? combined : 0,
			away: combined < 0 ? -combined : 0,
			points: graph.slice(-20),
			source: "api"
		};
	}
	const key = match.eventId || match.id;
	const prev = snaps.get(key);
	const now = Date.now();
	let homeMomentum = 0;
	let awayMomentum = 0;
	let usedDelta = false;
	if (prev && now - prev.t >= 5e3) {
		const dt = Math.max(1, (now - prev.t) / 6e4);
		const momentumH = (stats.bcH - prev.bcH) / dt * 2.2 + (stats.sotH - prev.sotH) / dt * .55 + (stats.shotsInH - prev.shotsInH) / dt * .25;
		const momentumA = (stats.bcA - prev.bcA) / dt * 2.2 + (stats.sotA - prev.sotA) / dt * .55 + (stats.shotsInA - prev.shotsInA) / dt * .25;
		homeMomentum = clamp(momentumH * .28, -1, 1);
		awayMomentum = clamp(momentumA * .28, -1, 1);
		usedDelta = true;
	}
	if (!usedDelta) {
		const scoreH = stats.bcH * .45 + stats.sotH * .25 + stats.shotsInH * .12;
		const total = scoreH + (stats.bcA * .45 + stats.sotA * .25 + stats.shotsInA * .12);
		if (total > .3) {
			const raw = (scoreH / total - .5) * 2 * clamp(total / 4, 0, 1);
			homeMomentum = raw > 0 ? raw : 0;
			awayMomentum = raw < 0 ? -raw : 0;
		}
	}
	snaps.set(key, {
		t: now,
		bcH: stats.bcH,
		bcA: stats.bcA,
		sotH: stats.sotH,
		sotA: stats.sotA,
		shotsInH: stats.shotsInH,
		shotsInA: stats.shotsInA
	});
	return {
		home: homeMomentum,
		away: awayMomentum,
		points: null,
		source: "local"
	};
}
function computeEventMomentum(events, minute) {
	const out = {
		homeRate: 1,
		awayRate: 1,
		pAnyBoost: 0,
		notes: []
	};
	if (!events.length || minute == null) return out;
	const goals = events.filter((e) => e.kind === "goal");
	const reds = events.filter((e) => e.kind === "red");
	const g8 = goals.filter((e) => minute - e.minute >= 0 && minute - e.minute <= 8);
	const g15 = goals.filter((e) => minute - e.minute >= 0 && minute - e.minute <= 15);
	if (g8.length) {
		out.pAnyBoost += .06 + .03 * Math.min(2, g8.length - 1);
		const last = g8[g8.length - 1];
		if (last.side === "home") {
			out.homeRate *= 1.08;
			out.awayRate *= 1.04;
		} else {
			out.awayRate *= 1.08;
			out.homeRate *= 1.04;
		}
		out.notes.push(`Golo aos ${last.minute}'`);
	} else if (g15.length) {
		out.pAnyBoost += .03;
		const last = g15[g15.length - 1];
		if (last.side === "home") out.homeRate *= 1.04;
		else out.awayRate *= 1.04;
		out.notes.push(`Golo aos ${last.minute}'`);
	}
	const r25 = reds.filter((e) => minute - e.minute >= 0 && minute - e.minute <= 25);
	if (r25.length) {
		const last = r25[r25.length - 1];
		out.pAnyBoost += .05;
		if (last.side === "home") {
			out.homeRate *= .82;
			out.awayRate *= 1.22;
		} else {
			out.awayRate *= .82;
			out.homeRate *= 1.22;
		}
		out.notes.push(`Vermelho ${last.side === "home" ? "casa" : "fora"} aos ${last.minute}'`);
	}
	out.homeRate = clamp(out.homeRate, .7, 1.35);
	out.awayRate = clamp(out.awayRate, .7, 1.35);
	out.pAnyBoost = clamp(out.pAnyBoost, 0, .15);
	return out;
}
function generateMatchSummary(match, analysis) {
	const home = match.homeTeam.name;
	const away = match.awayTeam.name;
	const score = `${match.score.fullTime.home}–${match.score.fullTime.away}`;
	const parts = [];
	if (analysis.pressureDiff > 18) parts.push(`${home} em pressão alta (${analysis.homePressure.toFixed(0)}%)`);
	else if (analysis.pressureDiff > 8) parts.push(`${home} domina a pressão`);
	else if (analysis.pressureDiff < -18) parts.push(`${away} em pressão alta (${analysis.awayPressure.toFixed(0)}%)`);
	else if (analysis.pressureDiff < -8) parts.push(`${away} domina a pressão`);
	else parts.push("Pressão equilibrada");
	if (analysis.dangerH > 1.5 && analysis.dangerA > 1.5) parts.push("Ambas criam perigo");
	else if (analysis.dangerH > 1.5) parts.push(`${home} mais perigoso`);
	else if (analysis.dangerA > 1.5) parts.push(`${away} mais perigoso`);
	if (analysis.intensity > .7) parts.push("Ritmo alto");
	else if (analysis.intensity < .25) parts.push("Jogo lento");
	if (match.minute > 75) parts.push("Fase final");
	if (analysis.nextTeam && analysis.nextProb >= 55) parts.push(`Próximo: ${analysis.nextTeam} ${analysis.nextProb.toFixed(0)}% se houver golo`);
	return `${score} · ${parts.join(" · ")}`;
}
function readCvCal() {
	if (typeof localStorage === "undefined") return null;
	try {
		const cv = JSON.parse(localStorage.getItem("bola_cv_cal") || "null");
		if (cv && (cv.n ?? 0) >= 12 && cv.b != null && Date.now() - (cv.at || 0) < 12096e5) return {
			a: Number(cv.a) || 0,
			b: Number(cv.b) || 1
		};
	} catch {}
	return null;
}
function predict(match, stats, graph) {
	if (!stats) return emptyPred();
	const minute = Math.min(120, Math.max(1, Number(match.minute) || 1));
	const rem = Math.max(0, (minute <= 90 ? 90 : minute <= 105 ? 105 : 120) - minute);
	const scoreH = match.score.fullTime.home || 0;
	const scoreA = match.score.fullTime.away || 0;
	const goalsSoFar = scoreH + scoreA;
	let homePressure = computePressure(stats, "home", minute);
	let awayPressure = computePressure(stats, "away", minute);
	const intensity = computeIntensity(stats, minute);
	const momentum = computeMomentum(match, stats, graph);
	const momentumDiff = momentum.home - momentum.away;
	const momentumSource = momentum.source;
	const momentumPoints = momentum.points;
	let pressureSource = "local";
	if (momentumSource === "api" && momentumPoints && momentumPoints.length >= 2) {
		const recent = momentumPoints.slice(-6);
		const avgVal = recent.reduce((s, pt) => s + (pt.value || 0), 0) / recent.length;
		const apiHomeShare = clamp(50 + avgVal * .45, 8, 92);
		const apiAwayShare = 100 - apiHomeShare;
		const apiStrength = clamp(Math.abs(avgVal) / 70, .25, 1);
		const baseLevel = (homePressure + awayPressure) / 2 || 40;
		const apiHome = baseLevel * (.5 + (apiHomeShare / 100 - .5) * apiStrength * 1.6);
		const apiAway = baseLevel * (.5 + (apiAwayShare / 100 - .5) * apiStrength * 1.6);
		homePressure = .35 * homePressure + .65 * clamp(apiHome, 0, 100);
		awayPressure = .35 * awayPressure + .65 * clamp(apiAway, 0, 100);
		pressureSource = "api";
	}
	const pressureDiff = homePressure - awayPressure;
	const dominantName = pressureDiff > 10 ? match.homeTeam.name : pressureDiff < -10 ? match.awayTeam.name : "";
	const dangerH = stats.bcH * .55 + stats.shotsInH * .12 + stats.sotH * .22 + stats.xgH * .35 + stats.xgotH * .25 + stats.touchesBoxH * .04;
	const dangerA = stats.bcA * .55 + stats.shotsInA * .12 + stats.sotA * .22 + stats.xgA * .35 + stats.xgotA * .25 + stats.touchesBoxA * .04;
	const totalDanger = dangerH + dangerA;
	const leagueAvg = getLeagueAvgGoals(match.league);
	const PRIOR_RATE_PER_MIN_H = leagueAvg * .53 / 90;
	const PRIOR_RATE_PER_MIN_A = leagueAvg * .47 / 90;
	const PRIOR_MINUTES = clamp(22 - minute * .12, 10, 22);
	const eff = Math.max(1, minute);
	const xgOrProxy = (xg, shots, sot, bc, shotsIn, xgot) => {
		if (xg > 0) return xg + .35 * Math.max(0, (xgot || 0) - xg * .5);
		if (xgot > 0) return xgot * 1.15;
		return .35 * bc + .12 * sot + .07 * shotsIn + .018 * Math.max(0, shots - sot - shotsIn);
	};
	const xgValH = xgOrProxy(stats.xgH, stats.shotsH, stats.sotH, stats.bcH, stats.shotsInH, stats.xgotH);
	const xgValA = xgOrProxy(stats.xgA, stats.shotsA, stats.sotA, stats.bcA, stats.shotsInA, stats.xgotA);
	const bayesRate = (xgVal, priorRate) => (xgVal + priorRate * PRIOR_MINUTES) / (eff + PRIOR_MINUTES);
	const baseRateH = bayesRate(xgValH, PRIOR_RATE_PER_MIN_H);
	const baseRateA = bayesRate(xgValA, PRIOR_RATE_PER_MIN_A);
	const alphaH = Math.max(.08, PRIOR_RATE_PER_MIN_H * PRIOR_MINUTES + xgValH);
	const alphaA = Math.max(.08, PRIOR_RATE_PER_MIN_A * PRIOR_MINUTES + xgValA);
	const totalPress = homePressure + awayPressure;
	const pressShareH = totalPress > 0 ? homePressure / totalPress : .5;
	const pressAmp = clamp(Math.abs(pressureDiff) / 40, 0, 1);
	let liveMultH = clamp(1 + (pressShareH - .5) * (1.15 + .45 * pressAmp), .68, 1.42);
	let liveMultA = clamp(1 + (1 - pressShareH - .5) * (1.15 + .45 * pressAmp), .68, 1.42);
	if (momentumSource === "api" && Math.abs(momentumDiff) > .15) {
		if (momentumDiff > 0) liveMultH *= 1.08;
		else liveMultA *= 1.08;
	}
	const intensityBoost = 1 + clamp(intensity - .45, 0, .35) * .18;
	liveMultH *= intensityBoost;
	liveMultA *= intensityBoost;
	let ctxH = 1, ctxA = 1;
	if (scoreH < scoreA && minute > 55) ctxH *= minute >= 75 ? 1.18 : 1.12;
	if (scoreA < scoreH && minute > 55) ctxA *= minute >= 75 ? 1.18 : 1.12;
	if (scoreH > scoreA && minute > 60) ctxH *= .88;
	if (scoreA > scoreH && minute > 60) ctxA *= .88;
	if (stats.redH > 0) {
		ctxH *= Math.pow(.78, stats.redH);
		ctxA *= Math.pow(1.18, stats.redH);
	}
	if (stats.redA > 0) {
		ctxA *= Math.pow(.78, stats.redA);
		ctxH *= Math.pow(1.18, stats.redA);
	}
	const evMom = computeEventMomentum(match.events || [], minute);
	ctxH = clamp(ctxH * evMom.homeRate, .55, 1.45);
	ctxA = clamp(ctxA * evMom.awayRate, .55, 1.45);
	const rateH = clamp(baseRateH * liveMultH * ctxH, 5e-4, .095);
	const rateA = clamp(baseRateA * liveMultA * ctxA, 5e-4, .095);
	const comb = rateH + rateA;
	const shareH = comb > 0 ? rateH / comb : .5;
	const shareA = 1 - shareH;
	const adjBetaH = alphaH / Math.max(rateH, 1e-6);
	const adjBetaA = alphaA / Math.max(rateA, 1e-6);
	const KMAX = CONFIG.DIST_KMAX;
	const distAt = (t) => {
		if (t <= 0) return {
			pmfTotal: [1],
			pH0: 1,
			pA0: 1,
			jointP00: 1
		};
		return remainingGoalsDist(alphaH, adjBetaH / (adjBetaH + t), alphaA, adjBetaA / (adjBetaA + t), KMAX);
	};
	const expRem = (rateH + rateA) * rem;
	const distRem = distAt(rem);
	let pAny01 = rem > 0 ? 1 - distRem.pmfTotal[0] : 0;
	let pAny = pAny01 * 100;
	const p0 = distRem.pmfTotal[0] * 100;
	const p1 = (distRem.pmfTotal[1] || 0) * 100;
	const p2 = (distRem.pmfTotal[2] || 0) * 100;
	const p3plus = Math.max(0, 100 - p0 - p1 - p2);
	const ouLines = CONFIG.OU_LINES.map((line) => {
		const need = Math.floor(line) + 1 - goalsSoFar;
		let over;
		if (need <= 0) over = 100;
		else if (rem <= 0) over = 0;
		else over = (1 - cdfFromPmf(distRem.pmfTotal, need - 1)) * 100;
		return {
			line,
			over: clamp(over, 0, 100),
			under: clamp(100 - over, 0, 100),
			done: need <= 0
		};
	});
	const HT_BOUNDARY = 45;
	const stillIn1H = minute <= HT_BOUNDARY;
	const htKnownFromApi = match.htScore.home != null && match.htScore.away != null;
	const htGoalsFromApi = htKnownFromApi ? (match.htScore.home ?? 0) + (match.htScore.away ?? 0) : null;
	const htGoalsSoFar = stillIn1H ? goalsSoFar : htGoalsFromApi;
	const htGoalsKnown = stillIn1H || htKnownFromApi;
	const rem1H = stillIn1H ? Math.max(0, HT_BOUNDARY - minute) : 0;
	const leagueHalfRate = Math.max(.35, leagueAvg * .5) / 45;
	const observedXgTotal = Math.max(0, xgValH + xgValA);
	const observedRate = minute > 0 ? observedXgTotal / minute : leagueHalfRate;
	const liveEvidenceWeight = clamp((minute - 8) / 37, 0, .72);
	const halfRateBase = leagueHalfRate * (1 - liveEvidenceWeight) + observedRate * liveEvidenceWeight;
	const halfRateTotal1H = clamp(halfRateBase * 45, .35, 3) / 45;
	const halfRateTotal2H = clamp(halfRateBase * 1.05 * 45, .35, 3.2) / 45;
	const halfShareH = clamp(.5 + (shareH - .5) * .65, .35, .65);
	const distForRates = (t, rH, rA, evidence) => {
		if (t <= 0) return {
			pmfTotal: [1],
			pH0: 1,
			pA0: 1,
			jointP00: 1
		};
		const aH = Math.max(1.2, evidence * .75 + 1.2);
		const aA = Math.max(1.2, evidence * .75 + 1.2);
		const bH = aH / Math.max(rH, 1e-6);
		const bA = aA / Math.max(rA, 1e-6);
		return remainingGoalsDist(aH, bH / (bH + t), aA, bA / (bA + t), CONFIG.DIST_KMAX);
	};
	const halfEvidence = clamp(2 + minute * .12 + observedXgTotal * 1.5, 2, 14);
	const dist1H = distForRates(rem1H, halfRateTotal1H * halfShareH, halfRateTotal1H * (1 - halfShareH), halfEvidence);
	const halfOuLine = (line, goalsDone, remMinutes, distObj, periodOver) => {
		if (goalsDone == null) return {
			line,
			over: null,
			under: null,
			done: false,
			missed: false,
			unknown: true,
			resolved: false
		};
		const need = Math.floor(line) + 1 - goalsDone;
		if (need <= 0) return {
			line,
			over: 100,
			under: 0,
			done: true,
			missed: false,
			unknown: false,
			resolved: true
		};
		if (periodOver || remMinutes <= 0) return {
			line,
			over: 0,
			under: 100,
			done: false,
			missed: true,
			unknown: false,
			resolved: true
		};
		const over = (1 - cdfFromPmf(distObj.pmfTotal, need - 1)) * 100;
		return {
			line,
			over: clamp(over, 0, 100),
			under: clamp(100 - over, 0, 100),
			done: false,
			missed: false,
			unknown: false,
			resolved: false
		};
	};
	const ouLinesHT = CONFIG.HT_OU_LINES.map((line) => halfOuLine(line, htGoalsSoFar, rem1H, dist1H, !stillIn1H));
	const goals2HSoFar = stillIn1H ? 0 : htGoalsKnown ? Math.max(0, goalsSoFar - (htGoalsSoFar ?? 0)) : null;
	const rem2H = stillIn1H ? 45 : rem;
	const dist2H = distForRates(rem2H, halfRateTotal2H * halfShareH, halfRateTotal2H * (1 - halfShareH), halfEvidence + 2);
	const ouLines2H = CONFIG.HT_OU_LINES.map((line) => halfOuLine(line, goals2HSoFar, rem2H, dist2H, false));
	const nextTeam = shareH >= shareA ? match.homeTeam.name : match.awayTeam.name;
	const nextShare = shareH >= shareA ? shareH : shareA;
	const nextProb = clamp(nextShare * 100, 0, 100);
	let nextReason = "Se houver outro golo, a divisão é equilibrada";
	if (Math.abs(nextProb - 50) >= 4) nextReason = nextProb > 68 ? `Se houver outro golo, ${nextTeam} tem a maior fatia (${nextProb.toFixed(0)}%)` : `Se houver outro golo, ${nextTeam} tem vantagem moderada (${nextProb.toFixed(0)}%)`;
	const bttsDone = scoreH > 0 && scoreA > 0;
	let bttsYes = bttsDone ? 100 : clamp((rem > 0 ? 1 - distRem.pH0 - distRem.pA0 + distRem.jointP00 : 0) * 100, 0, 99.5);
	const qualityNorm = clamp(totalDanger / 3.6, 0, 1);
	const xgNorm = clamp((xgValH + xgValA) / 2.6, 0, 1);
	const momentumNorm = clamp(Math.abs(momentumDiff) / .85, 0, 1);
	const pressureNorm = clamp(Math.abs(pressureDiff) / 38, 0, 1);
	const danger = clamp(100 * (.32 * intensity + .28 * qualityNorm + .18 * xgNorm + .12 * momentumNorm + .1 * pressureNorm), 0, 100);
	const sampleShots = clamp((stats.shotsH + stats.shotsA) / 14, 0, 1);
	const sampleBC = clamp((stats.bcH + stats.bcA) / 4.5, 0, 1);
	const sampleTime = clamp((minute - 12) / 55, 0, 1);
	const sampleXg = clamp((xgValH + xgValA) / 1.8, 0, 1);
	const volumeQ = clamp((stats.shotsH + stats.shotsA) / 16, 0, 1);
	const qualityQ = clamp(totalDanger / 3.5, 0, 1);
	const coherence = 1 - clamp(Math.abs(volumeQ - qualityQ) * .7, 0, .4);
	const conf = clamp(100 * (stats.sourceVerified ? 1 : .65) * coherence * (.27 * sampleShots + .2 * sampleBC + .25 * sampleTime + .16 * sampleXg + .12 * (momentumSource === "api" ? 1 : .45)), 0, 100);
	const shrink = clamp(.55 + .45 * (conf / 100), .55, 1);
	const cv = readCvCal();
	const calP = (p) => {
		let x = 50 + (p - 50) * shrink;
		if (cv) {
			const p01 = x / 100;
			const cv01 = clamp(cv.a + cv.b * p01, .01, .99);
			x = 100 * (.4 * p01 + .6 * cv01);
		}
		return x;
	};
	pAny = calP(pAny);
	pAny01 = pAny / 100;
	ouLines.forEach((o) => {
		if (!o.done && o.over != null) {
			o.over = clamp(calP(o.over), 0, 100);
			o.under = clamp(100 - o.over, 0, 100);
		}
	});
	if (!bttsDone) bttsYes = clamp(calP(bttsYes), 0, 99.5);
	const nextTeamAnyProbCal = clamp(pAny01 * nextShare * 100, 0, 100);
	let summary = generateMatchSummary(match, {
		homePressure,
		awayPressure,
		pressureDiff,
		dangerH,
		dangerA,
		intensity,
		nextTeam,
		nextProb,
		nextTeamAnyProb: nextTeamAnyProbCal,
		pAny
	});
	if (evMom.notes.length) summary += " · " + evMom.notes.join(" · ");
	return {
		has: true,
		level: "none",
		rec: "",
		analyst: null,
		verdict: null,
		predicted: nextTeam,
		probability: nextProb,
		nextTeamAnyProb: nextTeamAnyProbCal,
		nextTeamOtherGoalProbH: clamp(pAny01 * shareH * 100, 0, 100),
		nextTeamOtherGoalProbA: clamp(pAny01 * shareA * 100, 0, 100),
		danger,
		conf,
		shrink,
		reliability: 0,
		aligned: true,
		xgH: stats.xgH,
		xgA: stats.xgA,
		shotsH: stats.shotsH,
		shotsA: stats.shotsA,
		sotH: stats.sotH,
		sotA: stats.sotA,
		corH: stats.cornersH,
		corA: stats.cornersA,
		bcH: stats.bcH,
		bcA: stats.bcA,
		possH: stats.possH,
		possA: stats.possA,
		foulsH: stats.foulsH,
		foulsA: stats.foulsA,
		savesH: stats.savesH,
		savesA: stats.savesA,
		woodH: stats.woodH,
		woodA: stats.woodA,
		blockedH: stats.blockedH,
		blockedA: stats.blockedA,
		yelH: stats.yelH,
		yelA: stats.yelA,
		redH: stats.redH,
		redA: stats.redA,
		shotsInH: stats.shotsInH,
		shotsInA: stats.shotsInA,
		shotsOutH: stats.shotsOutH,
		shotsOutA: stats.shotsOutA,
		pressure: {
			home: homePressure,
			away: awayPressure,
			diff: pressureDiff,
			dominant: dominantName,
			intensity,
			source: pressureSource
		},
		summary,
		nextReason,
		intensity,
		momentum: momentumDiff,
		momentumSource,
		momentumPoints,
		totalDanger,
		expTotal: goalsSoFar + expRem,
		expRem,
		ouLines,
		ouLinesHT,
		ouLines2H,
		bttsYes,
		bttsNo: 100 - bttsYes,
		bttsDone,
		pAny,
		p0,
		p1,
		p2,
		p3plus,
		rateH,
		rateA,
		pressH: homePressure,
		pressA: awayPressure,
		stillIn1H,
		htGoalsSoFar,
		htGoalsKnown,
		goals2HSoFar,
		rem1H,
		rem2H,
		timeWindows: CONFIG.TIME_WINDOWS.map((mins) => {
			const t = Math.min(mins, rem);
			const raw = t > 0 ? (1 - distAt(t).pmfTotal[0]) * 100 : 0;
			return {
				mins,
				prob: calP(raw)
			};
		}),
		leagueAvgGoals: leagueAvg,
		model: MODEL_LABEL
	};
}
function classifyLevel(danger, probability, conf, pAny, ctx, highPrecision) {
	const H = CONFIG.HP;
	if (highPrecision) {
		if (ctx.minute < H.MIN_MINUTE) return {
			level: "none",
			rec: ""
		};
		if (!(ctx.totalShots >= H.MIN_SHOTS || ctx.totalXg >= H.MIN_XG || ctx.totalBc >= H.MIN_BC)) return {
			level: "none",
			rec: ""
		};
		if (conf < H.MIN_CONF) return {
			level: "none",
			rec: ""
		};
		if (H.REQUIRE_MOMENTUM_ALIGN && ctx.aligned === false && (probability || 0) < 68) return {
			level: "none",
			rec: ""
		};
	}
	const p = clamp(pAny, 0, 1);
	const d = clamp(danger / 100, 0, 1);
	const c = clamp(conf / 100, 0, 1);
	const edge = clamp(Math.abs((probability || 50) - 50) / 50, 0, 1);
	const evidence = .45 * p + .25 * d + .2 * c + .1 * edge;
	if (ctx.rem <= 0 || p < .55) return {
		level: "none",
		rec: ""
	};
	if (highPrecision) {
		if (evidence >= .7 && p >= .68 && d >= .55 && c >= .58) return {
			level: "hi",
			rec: "Sinal forte · evidência convergente"
		};
		if (evidence >= .6 && p >= .6 && d >= .42 && c >= .48) return {
			level: "med",
			rec: "Sinal moderado · evidência convergente"
		};
		return {
			level: "none",
			rec: ""
		};
	}
	if (evidence >= .72 && p >= .68) return {
		level: "hi",
		rec: "Sinal forte"
	};
	if (evidence >= .62 && p >= .6) return {
		level: "med",
		rec: "Sinal moderado"
	};
	return {
		level: "none",
		rec: ""
	};
}
function computeVerdict(pred, match) {
	if (!pred.has) return null;
	const minute = match.minute || 0;
	const rem = Math.max(0, minute <= 90 ? 90 - minute : minute <= 105 ? 105 - minute : 120 - minute);
	const shots = pred.shotsH + pred.shotsA;
	const xg = pred.xgH + pred.xgA;
	const p = clamp(pred.pAny / 100, 0, 1);
	const base = rem > 0 ? 1 - Math.exp(-getLeagueAvgGoals(match.league) * rem / 90) : 0;
	const lift = p - base;
	const fewData = minute < 25 || shots < 6 && xg < .5;
	let key = "baixa";
	let label = "Pouco provável haver golo";
	let short = "Golo pouco provável";
	if (p >= .7 && (lift >= .08 || p >= .85) && !fewData) {
		key = "alta";
		label = "Muito provável haver golo";
		short = "Golo muito provável";
	} else if (p >= .55) {
		key = "prov";
		label = "Provável haver golo";
		short = "Golo provável";
	} else if (p >= .4) {
		key = "inc";
		label = "Golo incerto";
		short = "Golo incerto";
	}
	const name = pred.predicted && pred.predicted !== "—" ? pred.predicted : null;
	const np = Math.round(pred.probability || 0);
	let nextText = "Próximo golo: equilibrado, sem favorito claro";
	let nextShort = "próx.: equilibrado";
	if (p < .4) {
		nextText = "Próximo golo: pouco provável que haja outro";
		nextShort = "";
	} else if (name && np >= 62) {
		nextText = `Próximo golo: ${name} (${np}% se houver golo)`;
		nextShort = `próx.: ${name} ${np}%`;
	} else if (name && np >= 55) {
		nextText = `Próximo golo: ligeira vantagem para ${name} (${np}%)`;
		nextShort = `próx.: ${name} ${np}%`;
	}
	return {
		key,
		label,
		short,
		nextText,
		nextShort,
		nextStrong: !!(name && np >= 62 && p >= .4),
		p,
		base,
		lift,
		fewData,
		rem
	};
}
function buildAnalystDecision(pred, match) {
	if (!pred.has) return {
		market: "—",
		probability: 0,
		level: "none",
		reason: "Sem dados"
	};
	const minute = match.minute || 0;
	const rem = Math.max(0, minute <= 90 ? 90 - minute : minute <= 105 ? 105 - minute : 120 - minute);
	const pAny = clamp(pred.pAny / 100, 0, 1);
	const volume = clamp((pred.shotsH + pred.shotsA) / 18, 0, 1);
	const quality = clamp((pred.xgH + pred.xgA) / 2.2 * .55 + (pred.sotH + pred.sotA) / 7 * .25 + (pred.bcH + pred.bcA) / 4 * .2, 0, 1);
	const pressure = clamp(Math.abs(pred.pressure.diff) / 35, 0, 1);
	const momentum = clamp(Math.abs(pred.momentum), 0, 1);
	const coherence = 1 - clamp(Math.abs(volume - quality) * .7, 0, .35);
	const evidence = clamp((.36 * quality + .22 * volume + .16 * pressure + .16 * momentum + .1 * clamp(pred.conf / 100, 0, 1)) * coherence, 0, 1);
	const candidates = [];
	const add = (market, prob, why, kind) => {
		if (prob == null || !Number.isFinite(prob)) return;
		const p = clamp(prob, 0, 100);
		const edge = Math.abs(p - 50) / 50;
		candidates.push({
			market,
			probability: p,
			why,
			score: p / 100 * .72 + edge * .12 + evidence * .12 + ({
				o05: 1,
				window: .94,
				o15: .9,
				btts: .86,
				o25: .8,
				next: .68
			}[kind] || .7) * .04,
			kind
		});
	};
	if (rem > 0 && pAny >= .6) add("O0.5 · golo restante", pred.pAny, `${Math.round(pred.pAny)}% de ≥1 golo no resto`, "o05");
	(pred.timeWindows || []).forEach((w) => {
		if (w.mins <= 12 && w.mins <= rem && w.prob >= 62 && evidence >= .42) add(`Golo nos próximos ${w.mins}'`, w.prob, `${Math.round(w.prob)}%`, "window");
	});
	(pred.ouLines || []).forEach((o) => {
		if (o.done || o.line < 1.5 || o.over == null) return;
		const minP = o.line === 1.5 ? 62 : o.line === 2.5 ? 65 : 68;
		const minEv = o.line === 1.5 ? .4 : .5;
		if (o.over >= minP && evidence >= minEv && rem >= (o.line === 1.5 ? 12 : 20)) add(`O${o.line} · jogo`, o.over, `${Math.round(o.over)}%`, o.line === 1.5 ? "o15" : "o25");
	});
	if (!pred.bttsDone && pred.bttsYes >= 62 && evidence >= .44) {
		if ((pred.xgH >= .3 || pred.bcH >= 1) && (pred.xgA >= .3 || pred.bcA >= 1)) add("BTTS · ambas marcam", pred.bttsYes, `${Math.round(pred.bttsYes)}%`, "btts");
	}
	if (rem > 0 && pAny >= .58 && pred.nextTeamAnyProb >= 38 && Math.abs(pred.probability - 50) >= 10 && evidence >= .48) add(`Próximo golo · ${pred.predicted}`, pred.nextTeamAnyProb, `prob. absoluta ${Math.round(pred.nextTeamAnyProb)}%`, "next");
	if (!candidates.length) return {
		market: "SEM SINAL",
		probability: 0,
		level: "none",
		reason: "Probabilidades abaixo do limiar.",
		evidence: Math.round(evidence * 100)
	};
	candidates.sort((a, b) => b.score - a.score);
	const top = candidates[0];
	const second = candidates[1];
	const separation = second ? top.score - second.score : 1;
	const strong = top.probability >= 68 && separation >= .025 && evidence >= .5;
	const moderate = top.probability >= 62 && separation >= .018 && evidence >= .4;
	const level = strong ? "hi" : moderate ? "med" : "none";
	if (level === "none") return {
		market: "SEM SINAL",
		probability: 0,
		level: "none",
		reason: "Mercados próximos ou evidência insuficiente.",
		evidence: Math.round(evidence * 100)
	};
	return {
		market: top.market,
		probability: top.probability,
		level,
		reason: top.why,
		evidence: Math.round(evidence * 100)
	};
}
function computeReliability(pred, match) {
	if (!pred.has) return 0;
	const minute = match.minute || 0;
	const shots = pred.shotsH + pred.shotsA;
	const xg = pred.xgH + pred.xgA;
	const bc = pred.bcH + pred.bcA;
	let s = 0;
	s += clamp(shots / 18, 0, 1) * 18;
	s += clamp(xg / 2.2, 0, 1) * 14;
	s += clamp(bc / 4, 0, 1) * 12;
	s += clamp((minute - 20) / 50, 0, 1) * 12;
	s += clamp(pred.conf / 100, 0, 1) * 16;
	s += clamp(pred.danger / 100, 0, 1) * 10;
	if (pred.momentumSource === "api") s += 8;
	else if (pred.momentumSource === "local") s += 3;
	s += clamp(Math.abs(pred.pressure.diff) / 35, 0, 1) * 6;
	s += clamp((pred.probability - 50) / 30, 0, 1) * 4;
	return clamp(Math.round(s), 0, 100);
}
function finalizePrediction(match, pred, highPrecision) {
	if (!pred.has) return pred;
	const totalShots = pred.shotsH + pred.shotsA;
	const totalXg = pred.xgH + pred.xgA;
	const totalBc = pred.bcH + pred.bcA;
	const minute = match.minute || 0;
	const rem = Math.max(0, (minute <= 90 ? 90 : minute <= 105 ? 105 : 120) - minute);
	const pressDiff = pred.pressure.diff;
	const predictedHome = pred.predicted === match.homeTeam.name;
	let aligned = true;
	if (highPrecision && CONFIG.HP.REQUIRE_MOMENTUM_ALIGN) {
		if (predictedHome && pressDiff < -CONFIG.HP.MIN_PRESSURE_DIFF) aligned = false;
		if (!predictedHome && pressDiff > CONFIG.HP.MIN_PRESSURE_DIFF) aligned = false;
		if (Math.abs(pressDiff) < 9 && pred.probability < 60) aligned = false;
	}
	const { level, rec } = classifyLevel(pred.danger, pred.probability, pred.conf, pred.pAny / 100, {
		minute,
		rem,
		totalShots,
		totalXg,
		totalBc,
		aligned
	}, highPrecision);
	pred.level = level;
	pred.rec = rec;
	pred.aligned = aligned;
	pred.reliability = computeReliability(pred, match);
	const d = buildAnalystDecision(pred, match);
	pred.analyst = d;
	if (d.market === "SEM SINAL") pred.rec = pred.level !== "none" ? pred.level === "hi" ? "Sinal forte · sem mercado claro" : "Sinal moderado · sem mercado claro" : "Sem sinal · sinais não convergem";
	else if (d.probability > 0) {
		pred.rec = `${d.market} · ${d.probability.toFixed(0)}%`;
		if (d.level === "hi" && pred.level !== "hi") pred.level = "hi";
		else if (d.level === "med" && (pred.level === "none" || pred.level === "lo")) pred.level = "med";
	}
	pred.verdict = computeVerdict(pred, match);
	return pred;
}
function computeSignalScore(match, p) {
	if (!p.has) return 0;
	const levelBoost = p.level === "hi" ? 18 : p.level === "med" ? 10 : p.level === "lo" ? 4 : 0;
	const raw = 100 * (.3 * clamp(p.danger / 100, 0, 1) + .25 * clamp(p.pAny / 100, 0, 1) + .15 * clamp(p.conf / 100, 0, 1) + .15 * clamp(p.intensity, 0, 1) + .15 * clamp(Math.abs(p.pressure.diff) / 40, 0, 1)) + levelBoost;
	return clamp(raw, 0, 100);
}
function scoreAndSort(items, highPrecision) {
	return items.slice().sort((a, b) => {
		const sa = computeSignalScore(a.match, a.pred);
		const sb = computeSignalScore(b.match, b.pred);
		if (highPrecision) {
			const ra = a.pred.reliability;
			const rb = b.pred.reliability;
			const fa = sa * .65 + ra * .35;
			const fb = sb * .65 + rb * .35;
			if (Math.abs(fb - fa) > .5) return fb - fa;
		}
		if (Math.abs(sb - sa) > .5) return sb - sa;
		const rank = {
			hi: 0,
			med: 1,
			lo: 2,
			none: 3
		};
		return (rank[a.pred.level] ?? 3) - (rank[b.pred.level] ?? 3);
	});
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var getLiveFeed = createServerFn({ method: "POST" }).handler(createSsrRpc("03680a4bc38a14268985ffe4b039daa8cdcd066f7c024322c3c45abd44d863b1"));
function buildItems(bundles, analystMode) {
	return scoreAndSort(bundles.map(({ match, stats, graph }) => {
		return {
			match,
			pred: finalizePrediction(match, predict(match, stats, graph ?? null), analystMode)
		};
	}), analystMode);
}
function readAnalystPref() {
	if (typeof localStorage === "undefined") return true;
	try {
		const v = localStorage.getItem("bola_mode99");
		if (v === "0") return false;
		if (v === "1") return true;
	} catch {}
	return true;
}
var useAppStore = create((set, get) => ({
	tab: "live",
	filter: "all",
	items: [],
	status: "idle",
	error: null,
	lastUpdate: null,
	selectedId: null,
	analystMode: true,
	fetching: false,
	setTab: (tab) => set({ tab }),
	setFilter: (filter) => set({ filter }),
	setSelected: (id) => set({ selectedId: id }),
	setAnalystMode: (on) => {
		try {
			localStorage.setItem("bola_mode99", on ? "1" : "0");
		} catch {}
		set({ analystMode: on });
		get().reclassify();
	},
	reclassify: () => {
		const { items, analystMode } = get();
		set({ items: scoreAndSort(items.map((it) => ({
			match: it.match,
			pred: finalizePrediction(it.match, { ...it.pred }, analystMode)
		})), analystMode) });
	},
	loadDemo: () => {
		const items = buildItems(getExampleBundles().map((b) => ({
			...b,
			graph: null
		})), get().analystMode);
		set({
			items,
			status: "demo",
			error: null,
			lastUpdate: Date.now(),
			selectedId: items[0]?.match.id ?? null
		});
	},
	refresh: async () => {
		if (get().fetching) return;
		set({
			fetching: true,
			status: get().items.length ? get().status : "loading",
			error: null
		});
		try {
			const res = await getLiveFeed();
			if (!res.ok) {
				if (!get().items.length) get().loadDemo();
				set({
					fetching: false,
					status: get().items.length ? get().status : "error",
					error: res.error || "Sem dados ao vivo"
				});
				return;
			}
			if (!res.items.length) {
				set({
					fetching: false,
					items: [],
					status: "ok",
					lastUpdate: res.fetchedAt,
					selectedId: null
				});
				return;
			}
			const items = buildItems(res.items, get().analystMode);
			const keep = get().selectedId;
			const selectedId = items.some((it) => it.match.id === keep) ? keep : items[0]?.match.id ?? null;
			set({
				items,
				status: "ok",
				error: null,
				lastUpdate: res.fetchedAt,
				selectedId,
				fetching: false
			});
		} catch (err) {
			if (!get().items.length) get().loadDemo();
			set({
				fetching: false,
				error: err instanceof Error ? err.message : "Falha na atualização",
				status: get().items.length ? get().status : "error"
			});
		}
	}
}));
function hydratePrefs() {
	useAppStore.setState({ analystMode: readAnalystPref() });
}
var FILTERS = [
	{
		id: "all",
		label: "Ao vivo"
	},
	{
		id: "goal",
		label: "Golo quente"
	},
	{
		id: "btts",
		label: "BTTS"
	},
	{
		id: "next",
		label: "Próx. golo"
	}
];
function itemMatchesFilter(it, filter) {
	if (filter === "all") return true;
	if (filter === "goal") return it.pred.verdict?.key === "alta";
	if (filter === "btts") return it.pred.has && !it.pred.bttsDone && it.pred.bttsYes >= 55;
	if (filter === "next") return it.pred.has && it.pred.probability >= 58 && it.pred.pAny >= 50;
	return true;
}
function fromItems(n, control) {
	const all = useAppStore.getState().items;
	return (control ? all.filter((it) => !it.pred.has || it.pred.level === "none").slice(0, n) : all.filter((it) => it.pred.has).slice(0, n)).map((it, idx) => ({
		id: Date.now() + idx,
		time: (/* @__PURE__ */ new Date()).toISOString(),
		eventId: it.match.eventId,
		minute: it.match.minute,
		minuteDisplay: it.match.minuteDisplay,
		score: `${it.match.score.fullTime.home}–${it.match.score.fullTime.away}`,
		home: it.match.homeTeam.name,
		away: it.match.awayTeam.name,
		league: it.match.league,
		level: control ? "none" : it.pred.level,
		pOver05: it.pred.pAny != null ? it.pred.pAny / 100 : null,
		pOver15: (() => {
			const o = it.pred.ouLines.find((x) => x.line === 1.5)?.over;
			return o != null ? o / 100 : null;
		})(),
		pOver25: (() => {
			const o = it.pred.ouLines.find((x) => x.line === 2.5)?.over;
			return o != null ? o / 100 : null;
		})(),
		pBtts: it.pred.bttsYes != null ? it.pred.bttsYes / 100 : null,
		nextTeam: it.pred.predicted,
		nextProb: it.pred.probability / 100,
		control,
		result: null
	}));
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-surface p-3 shadow-[var(--shadow-border)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-[10px] font-medium uppercase tracking-wide text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-1 font-mono text-lg font-bold tabular-nums",
			children: value
		})]
	});
}
function HistoryView() {
	const [rows, setRows] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		setRows(loadHistory());
	}, []);
	const refresh = () => setRows(loadHistory());
	const metrics = (0, import_react.useMemo)(() => {
		const scored = rows.filter((x) => x.result && x.pOver05 != null && !x.control);
		let hits = 0;
		const bs = [];
		scored.forEach((x) => {
			const y = computeOverRest(x) ?? 0;
			const p = x.pOver05 ?? .5;
			bs.push(brier(p, y));
			if (p >= .5 === !!y) hits++;
		});
		return {
			n: rows.length,
			resolved: scored.length,
			acc: scored.length ? `${(hits / scored.length * 100).toFixed(0)}%` : "—",
			brier: bs.length ? (bs.reduce((s, v) => s + v, 0) / bs.length).toFixed(3) : "—"
		};
	}, [rows]);
	const saveTop = () => {
		const extra = fromItems(3, false);
		if (!extra.length) return;
		saveHistory([...loadHistory(), ...extra]);
		refresh();
	};
	const saveControl = () => {
		const extra = fromItems(3, true);
		if (!extra.length) return;
		saveHistory([...loadHistory(), ...extra]);
		refresh();
	};
	const record = (id) => {
		const raw = window.prompt("Resultado final (ex.: 2-1)");
		if (!raw) return;
		const m = raw.match(/(\d+)\s*[-–—:xX]\s*(\d+)/);
		if (!m) return;
		saveHistory(loadHistory().map((x) => x.id === id ? {
			...x,
			result: {
				home: +m[1],
				away: +m[2]
			}
		} : x));
		refresh();
	};
	const clear = () => {
		if (!window.confirm("Apagar o histórico?")) return;
		saveHistory([]);
		refresh();
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-4xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight",
					children: "Histórico"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Guarda previsões, regista o resultado e mede Brier e acerto."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							onClick: saveTop,
							children: "Guardar top 3"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "ghost",
							onClick: saveControl,
							children: "Controlo"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "outline",
							onClick: clear,
							children: "Limpar"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-5 grid grid-cols-2 gap-2 sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Guardadas",
						value: String(metrics.n)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Resolvidas",
						value: String(metrics.resolved)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Acerto O0.5",
						value: metrics.acc
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Brier",
						value: metrics.brier
					})
				]
			}),
			!rows.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-2xl bg-surface px-6 py-16 text-center text-sm text-muted shadow-[var(--shadow-border)]",
				children: "Ainda sem previsões. Guarda o top 3 a partir dos jogos ao vivo."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto rounded-2xl bg-surface shadow-[var(--shadow-border)]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[640px] text-left text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "text-[11px] uppercase tracking-wide text-subtle",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3 font-medium",
								children: "Jogo"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3 font-medium",
								children: "Min"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3 font-medium",
								children: "O0.5"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3 font-medium",
								children: "Resultado"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "px-3 py-3 font-medium" })
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.slice().reverse().slice(0, 40).map((x) => {
						const y = x.result && x.pOver05 != null ? computeOverRest(x) : null;
						const hit = y != null && x.pOver05 != null ? x.pOver05 >= .5 === !!y : null;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-t border-border",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "px-3 py-2.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "font-medium",
										children: [
											x.home,
											" ",
											x.score,
											" ",
											x.away
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-[11px] text-muted",
										children: [x.league, x.control ? " · controlo" : ""]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2.5 font-mono tabular-nums text-muted",
									children: x.minuteDisplay || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2.5 font-mono tabular-nums",
									children: x.pOver05 != null ? `${Math.round(x.pOver05 * 100)}%` : "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "px-3 py-2.5 font-mono tabular-nums",
									children: [x.result ? `${x.result.home}-${x.result.away}` : "Pendente", hit === true ? " · ok" : hit === false ? " · miss" : ""]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2.5 text-right",
									children: !x.result ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										variant: "ghost",
										onClick: () => record(x.id),
										children: "Registar"
									}) : null
								})
							]
						}, x.id);
					}) })]
				})
			})
		]
	});
}
function TeamCrest({ name, src, size = "sm" }) {
	const [failed, setFailed] = (0, import_react.useState)(false);
	const dim = size === "md" ? "size-8" : "size-6";
	if (!src || failed) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn(dim, "inline-flex shrink-0 items-center justify-center rounded-full bg-elevated text-[9px] font-bold tracking-wide text-fg shadow-[var(--shadow-border)]"),
		children: initials(name)
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src,
		alt: "",
		width: size === "md" ? 32 : 24,
		height: size === "md" ? 32 : 24,
		className: cn(dim, "shrink-0 rounded-full bg-elevated object-contain p-0.5"),
		crossOrigin: "anonymous",
		onError: () => setFailed(true)
	});
}
function marketTone(v) {
	if (v == null) return "cool";
	if (v >= 70) return "hot";
	if (v >= 50) return "warm";
	return "cool";
}
function MarketChip({ label, value, done }) {
	const tone = done ? "hot" : marketTone(value);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: cn("inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-medium", tone === "hot" && "bg-hot/12 text-hot shadow-[0_0_0_1px_rgb(61_154_122/0.22)]", tone === "warm" && "bg-elevated text-warm shadow-[var(--shadow-border)]", tone === "cool" && "bg-elevated/70 text-muted shadow-[var(--shadow-border)]"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
			className: "font-mono font-semibold tabular-nums",
			children: done ? "já" : value == null ? "—" : `${Math.round(value)}%`
		})]
	});
}
function lineOf(lines, n) {
	return lines?.find((x) => x.line === n);
}
function MatchRow({ item, selected, onSelect }) {
	const { match, pred } = item;
	const gh = match.score.fullTime.home;
	const ga = match.score.fullTime.away;
	const isHt = match.period === "ht";
	const o05 = pred.pAny;
	const o15 = lineOf(pred.ouLines, 1.5);
	const btts = pred.bttsDone ? 100 : pred.bttsYes;
	const ht05 = lineOf(pred.ouLinesHT, .5);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: cn("overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-border)] transition-[box-shadow,background-color] duration-150", selected && "bg-elevated shadow-[0_0_0_1px_rgb(200_204_212/0.28)]"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: onSelect,
			className: "grid w-full grid-cols-[52px_minmax(0,1fr)_auto] items-center gap-3 px-3 py-3 text-left",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: cn("flex size-12 items-center justify-center rounded-full bg-bg font-mono text-[15px] font-semibold tabular-nums shadow-[var(--shadow-border)]", isHt ? "text-muted text-xs" : "text-live", String(match.minuteDisplay).length > 3 && "text-xs"),
					children: isHt ? "INT" : match.minuteDisplay
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex min-w-0 items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeamCrest, {
							name: match.homeTeam.name,
							src: match.homeTeam.logo
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "truncate text-[13.5px] font-semibold",
							children: match.homeTeam.name
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex min-w-0 items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeamCrest, {
							name: match.awayTeam.name,
							src: match.awayTeam.logo
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "truncate text-[13.5px] font-semibold",
							children: match.awayTeam.name
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-8 flex-col overflow-hidden rounded-[10px] bg-bg shadow-[var(--shadow-border)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
						className: cn("px-2.5 py-1 text-center font-mono text-lg font-bold tabular-nums", gh > ga && "text-accent"),
						children: gh
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
						className: cn("border-t border-border px-2.5 py-1 text-center font-mono text-lg font-bold tabular-nums", ga > gh && "text-accent"),
						children: ga
					})]
				})
			]
		}), pred.has && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap gap-1.5 px-3 pb-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarketChip, {
					label: "O0.5 resto",
					value: o05
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarketChip, {
					label: "O1.5",
					value: o15?.over,
					done: o15?.done
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarketChip, {
					label: "BTTS",
					value: btts,
					done: pred.bttsDone
				}),
				ht05 && !ht05.unknown ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarketChip, {
					label: "1H 0.5",
					value: ht05.over,
					done: ht05.done
				}) : null,
				pred.verdict?.key === "alta" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarketChip, {
					label: "Golo",
					value: Math.round(pred.verdict.p * 100)
				}) : null
			]
		})]
	});
}
var badgeVariants = cva("inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-semibold tracking-wide uppercase", {
	variants: { tone: {
		muted: "bg-elevated text-muted shadow-[var(--shadow-border)]",
		live: "bg-live/15 text-live",
		hot: "bg-hot/15 text-hot",
		accent: "bg-accent/15 text-accent",
		warn: "bg-warm/15 text-warm"
	} },
	defaultVariants: { tone: "muted" }
});
function Badge({ className, tone, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn(badgeVariants({ tone }), className),
		...props
	});
}
function tier(v) {
	if (v == null) return "cool";
	if (v >= 70) return "hot";
	if (v >= 50) return "warm";
	return "cool";
}
function Tile({ label, value, done, missed, unknown }) {
	const t = done ? "hot" : missed || unknown ? "cool" : tier(value);
	const text = unknown || value == null ? "—" : done ? "Já" : missed ? "Não" : `${Math.round(value)}%`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("rounded-lg bg-bg px-3 py-2.5 text-center shadow-[var(--shadow-border)]", t === "hot" && "bg-hot/12 shadow-[0_0_0_1px_rgb(61_154_122/0.22)]"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-[10px] font-medium text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cn("mt-1 font-mono text-lg font-bold tabular-nums", t === "hot" && "text-hot", t === "warm" && "text-warm", t === "cool" && "text-muted"),
			children: text
		})]
	});
}
function findLine(lines, n) {
	return lines?.find((x) => x.line === n);
}
function PressureMeter({ item }) {
	const p = item.pred.pressure;
	const total = p.home + p.away || 1;
	const homeW = p.home / total * 100;
	const pts = item.pred.momentumPoints;
	const W = 280;
	const H = 34;
	const MID = H / 2;
	let spark = null;
	if (pts && pts.length >= 2) {
		const vals = pts.map((pt) => Math.max(-1, Math.min(1, (pt.value || 0) / 100)));
		const step = W / (vals.length - 1);
		spark = vals.map((v, i) => `${(i * step).toFixed(1)},${(MID - v * 14).toFixed(1)}`).join(" ");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-bg p-3 shadow-[var(--shadow-border)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-2 flex items-center justify-between text-[11px] font-medium text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-fg",
						children: item.match.homeTeam.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: p.source === "api" ? "Momentum live" : "Pressão estimada" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.match.awayTeam.name })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative flex h-5 overflow-hidden rounded-full bg-elevated",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-full bg-hot/80 transition-[width] duration-500",
						style: { width: `${homeW}%` }
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-full flex-1 bg-muted/25" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-y-0 left-1/2 w-px bg-fg/25" })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex justify-between font-mono text-[11px] tabular-nums text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-hot",
						children: [p.home.toFixed(0), "%"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: p.dominant || "Equilíbrio" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [p.away.toFixed(0), "%"] })
				]
			}),
			spark ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
				viewBox: `0 0 ${W} ${H}`,
				className: "mt-2 h-8 w-full",
				preserveAspectRatio: "none",
				"aria-hidden": true,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: "0",
					y1: MID,
					x2: W,
					y2: MID,
					stroke: "currentColor",
					className: "text-border-strong"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", {
					points: spark,
					fill: "none",
					stroke: "currentColor",
					className: "text-hot",
					strokeWidth: "2"
				})]
			}) : null
		]
	});
}
function MatchDetail({ item }) {
	if (!item) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex h-full min-h-64 flex-col items-center justify-center rounded-2xl bg-surface px-6 text-center shadow-[var(--shadow-border)]",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: "Seleciona um jogo para ver mercados, pressão e a leitura do motor."
		})
	});
	const { match, pred } = item;
	const v = pred.verdict;
	const o15 = findLine(pred.ouLines, 1.5);
	const o25 = findLine(pred.ouLines, 2.5);
	const ht05 = findLine(pred.ouLinesHT, .5);
	const ht15 = findLine(pred.ouLinesHT, 1.5);
	const h205 = findLine(pred.ouLines2H, .5);
	const h215 = findLine(pred.ouLines2H, 1.5);
	const hero = pred.analyst?.market && pred.analyst.market !== "SEM SINAL" ? {
		label: pred.analyst.market,
		value: pred.analyst.probability
	} : {
		label: "O0.5 · golo restante",
		value: pred.pAny
	};
	const pair = (a, b, dec) => dec ? `${a.toFixed(2)} – ${b.toFixed(2)}` : `${Math.round(a)} – ${Math.round(b)}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-center justify-between gap-2 text-[11px] text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "truncate font-medium uppercase tracking-wide",
						children: match.league
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: match.source === "demo" ? "warn" : "live",
						children: match.source === "demo" ? "Exemplo" : "Ao vivo"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-[1fr_auto_1fr] items-center gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex min-w-0 items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeamCrest, {
								name: match.homeTeam.name,
								src: match.homeTeam.logo,
								size: "md"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate text-sm font-semibold",
								children: match.homeTeam.name
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-[10px] bg-bg px-3 py-1.5 text-center font-mono text-xl font-bold tabular-nums shadow-[var(--shadow-border)]",
							children: [
								match.score.fullTime.home,
								"–",
								match.score.fullTime.away
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex min-w-0 items-center justify-end gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate text-right text-sm font-semibold",
								children: match.awayTeam.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeamCrest, {
								name: match.awayTeam.name,
								src: match.awayTeam.logo,
								size: "md"
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex items-center justify-center gap-2 text-xs text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono font-semibold text-live tabular-nums",
						children: match.period === "ht" ? "Intervalo" : `${match.minuteDisplay}'`
					}), pred.reliability ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						"· fiabilidade ",
						pred.reliability,
						"%"
					] }) : null]
				})
			]
		}), pred.has ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between rounded-2xl bg-surface px-4 py-3 shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[11px] font-medium uppercase tracking-wide text-muted",
					children: "Leitura"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-0.5 text-sm font-semibold",
					children: hero.label
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-mono text-3xl font-bold tabular-nums text-accent",
					children: Number.isFinite(hero.value) ? `${Math.round(hero.value)}%` : "—"
				})]
			}),
			v ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("rounded-2xl bg-surface px-4 py-3 text-sm shadow-[var(--shadow-border)]", v.key === "alta" && "bg-hot/10 shadow-[0_0_0_1px_rgb(61_154_122/0.22)]"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "font-semibold",
						children: [
							v.label,
							" — ",
							Math.round(v.p * 100),
							"%",
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "ml-1 font-normal text-muted",
								children: [
									"(normal nesta liga: ",
									Math.round(v.base * 100),
									"%)"
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-1 text-muted",
						children: v.nextText
					}),
					v.fewData ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-1 text-xs text-warm",
						children: "Ainda poucos dados — leitura menos fiável."
					}) : null
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl bg-surface p-3 shadow-[var(--shadow-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[10px] font-medium text-muted",
							children: "Perigo"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "font-mono text-xl font-bold tabular-nums",
							children: [pred.danger.toFixed(0), "%"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 h-1 overflow-hidden rounded-full bg-elevated",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-full bg-live",
								style: { width: `${Math.min(100, pred.danger)}%` }
							})
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl bg-surface p-3 shadow-[var(--shadow-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[10px] font-medium text-muted",
							children: "Confiança"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "font-mono text-xl font-bold tabular-nums",
							children: [pred.conf.toFixed(0), "%"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 h-1 overflow-hidden rounded-full bg-elevated",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-full bg-hot",
								style: { width: `${Math.min(100, pred.conf)}%` }
							})
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PressureMeter, { item }),
			pred.summary ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-1 text-xs leading-relaxed text-muted",
				children: pred.summary
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mb-2 text-[11px] font-semibold uppercase tracking-wide text-subtle",
				children: "1.ª parte"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
					label: "O0.5",
					value: ht05?.over,
					done: ht05?.done,
					missed: ht05?.missed,
					unknown: ht05?.unknown
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
					label: "O1.5",
					value: ht15?.over,
					done: ht15?.done,
					missed: ht15?.missed,
					unknown: ht15?.unknown
				})]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mb-2 text-[11px] font-semibold uppercase tracking-wide text-subtle",
				children: "2.ª parte"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
					label: "O0.5",
					value: h205?.over,
					done: h205?.done,
					missed: h205?.missed,
					unknown: h205?.unknown
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
					label: "O1.5",
					value: h215?.over,
					done: h215?.done,
					missed: h215?.missed,
					unknown: h215?.unknown
				})]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mb-2 text-[11px] font-semibold uppercase tracking-wide text-subtle",
				children: "Jogo"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						label: "O0.5 resto",
						value: pred.pAny
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						label: "O1.5",
						value: o15?.over,
						done: o15?.done
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						label: "O2.5",
						value: o25?.over,
						done: o25?.done
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						label: "BTTS",
						value: pred.bttsYes,
						done: pred.bttsDone
					})
				]
			})] }),
			pred.timeWindows.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mb-2 text-[11px] font-semibold uppercase tracking-wide text-subtle",
				children: "Janela de golo"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-5 gap-1.5",
				children: pred.timeWindows.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
					label: `${w.mins}'`,
					value: w.prob
				}, w.mins))
			})] }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
				className: "rounded-2xl bg-surface px-4 py-3 shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
						className: "cursor-pointer text-xs font-semibold text-muted",
						children: "Estatísticas"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 grid grid-cols-3 gap-2",
						children: [
							["xG", pair(pred.xgH, pred.xgA, true)],
							["À baliza", pair(pred.sotH, pred.sotA)],
							["Remates", pair(pred.shotsH, pred.shotsA)],
							["Big chances", pair(pred.bcH, pred.bcA)],
							["Cantos", pair(pred.corH, pred.corA)],
							["Posse", `${Math.round(pred.possH)} – ${Math.round(pred.possA)}`]
						].map(([lab, val]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg bg-bg px-2 py-2 text-center shadow-[var(--shadow-border)]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[9px] uppercase tracking-wide text-muted",
								children: lab
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-0.5 font-mono text-xs font-semibold tabular-nums",
								children: val
							})]
						}, lab))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-[10px] leading-relaxed text-subtle",
						children: [
							pred.model,
							" · prior da liga ",
							pred.leagueAvgGoals.toFixed(2),
							" golos/jogo. Estimativa estatística, não garantia."
						]
					})
				]
			})
		] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "rounded-2xl bg-surface px-4 py-8 text-center text-sm text-muted shadow-[var(--shadow-border)]",
			children: "Ainda sem estatísticas suficientes para este jogo."
		})]
	});
}
function Skeleton({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("animate-pulse rounded-md bg-elevated shadow-[var(--shadow-border)]", className),
		...props
	});
}
function groupByLeague(items) {
	const groups = [];
	const idx = /* @__PURE__ */ new Map();
	for (const it of items) {
		const key = it.match.league || "Liga";
		if (!idx.has(key)) {
			idx.set(key, groups.length);
			groups.push({
				league: key,
				country: it.match.country,
				rows: []
			});
		}
		groups[idx.get(key)].rows.push(it);
	}
	return groups;
}
function LeagueHead({ league, country }) {
	const prior = getLeaguePrior(league);
	const parts = league.split(":");
	const name = parts.length > 1 ? parts.slice(1).join(":").trim() : league;
	const sub = country || (parts.length > 1 ? parts[0] : prior.code);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-3 px-1 pb-2 pt-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "flex size-8 items-center justify-center rounded-lg bg-elevated font-mono text-[10px] font-bold text-accent shadow-[var(--shadow-border)]",
			children: prior.code
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "truncate text-[15px] font-semibold tracking-tight",
				children: name
			}), sub ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-xs text-muted",
				children: sub
			}) : null]
		})]
	});
}
function LiveView() {
	const items = useAppStore((s) => s.items);
	const filter = useAppStore((s) => s.filter);
	const setFilter = useAppStore((s) => s.setFilter);
	const selectedId = useAppStore((s) => s.selectedId);
	const setSelected = useAppStore((s) => s.setSelected);
	const status = useAppStore((s) => s.status);
	const fetching = useAppStore((s) => s.fetching);
	const shown = items.filter((it) => itemMatchesFilter(it, filter));
	const groups = groupByLeague(shown);
	const selected = items.find((it) => it.match.id === selectedId) ?? shown[0] ?? null;
	const counts = Object.fromEntries(FILTERS.map((f) => [f.id, items.filter((it) => itemMatchesFilter(it, f.id)).length]));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-6xl gap-4 lg:grid-cols-[minmax(0,1fr)_400px] lg:items-start",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-end justify-between gap-3 px-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight",
					children: "Ao vivo"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-sm font-medium text-hot tabular-nums",
					children: [items.length, " jogos"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "-mx-1 mb-4 flex gap-2 overflow-x-auto px-1 pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden",
				children: FILTERS.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setFilter(f.id),
					className: cn("flex h-10 shrink-0 items-center gap-2 rounded-full px-3.5 text-xs font-semibold", filter === f.id ? "bg-accent text-accent-fg" : "bg-surface text-muted shadow-[var(--shadow-border)]"),
					children: [f.label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
						className: "font-mono tabular-nums",
						children: counts[f.id] ?? 0
					})]
				}, f.id))
			}),
			status === "loading" && !items.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-2",
				children: Array.from({ length: 6 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-[92px] rounded-xl" }, i))
			}) : !shown.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-2xl bg-surface px-6 py-16 text-center text-sm text-muted shadow-[var(--shadow-border)]",
				children: fetching ? "A carregar jogos ao vivo…" : "Nenhum jogo neste filtro agora."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-5",
				children: groups.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LeagueHead, {
					league: g.league,
					country: g.country
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-2",
					children: g.rows.map((it) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchRow, {
						item: it,
						selected: selected?.match.id === it.match.id,
						onSelect: () => setSelected(it.match.id)
					}, it.match.id))
				})] }, g.league))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 lg:hidden",
				children: selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchDetail, { item: selected }) : null
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
			className: "sticky top-4 hidden lg:block",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchDetail, { item: selected })
		})]
	});
}
function LogoMark() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className: "size-8",
		"aria-hidden": true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
				points: "16,2 28,10 28,22 16,30 4,22 4,10",
				fill: "#16181f",
				stroke: "#c8ccd4",
				strokeWidth: "1.4"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
				points: "16,7 23,11.5 23,20.5 16,25 9,20.5 9,11.5",
				fill: "#c8ccd4",
				opacity: "0.16"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "16",
				cy: "16",
				r: "3.2",
				fill: "#e24b4b"
			})
		]
	});
}
function AppShell() {
	const tab = useAppStore((s) => s.tab);
	const setTab = useAppStore((s) => s.setTab);
	const refresh = useAppStore((s) => s.refresh);
	const loadDemo = useAppStore((s) => s.loadDemo);
	const fetching = useAppStore((s) => s.fetching);
	const status = useAppStore((s) => s.status);
	const lastUpdate = useAppStore((s) => s.lastUpdate);
	const analystMode = useAppStore((s) => s.analystMode);
	const setAnalystMode = useAppStore((s) => s.setAnalystMode);
	const error = useAppStore((s) => s.error);
	const items = useAppStore((s) => s.items);
	(0, import_react.useEffect)(() => {
		hydratePrefs();
		refresh();
		const id = window.setInterval(() => void refresh(), CONFIG.UPDATE_INTERVAL);
		const onVis = () => {
			if (!document.hidden) refresh();
		};
		document.addEventListener("visibilitychange", onVis);
		return () => {
			window.clearInterval(id);
			document.removeEventListener("visibilitychange", onVis);
		};
	}, [refresh]);
	const statusLabel = status === "loading" ? "A carregar" : status === "demo" ? "Modo exemplo" : status === "error" ? "Sem ligação" : fetching ? "A atualizar" : `${items.length} ao vivo`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg pb-[calc(4.5rem+env(safe-area-inset-bottom))]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-20 border-b border-border bg-bg/92 backdrop-blur-md",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl items-center gap-3 px-4 py-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogoMark, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[15px] font-semibold tracking-tight",
								children: "Bola de Cristal"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-[11px] text-muted",
								children: [statusLabel, lastUpdate ? ` · ${new Date(lastUpdate).toLocaleTimeString()}` : ""]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon",
							variant: "ghost",
							onClick: () => void refresh(),
							"aria-label": "Atualizar",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: cn("size-4", fetching && "animate-spin") })
						})
					]
				})
			}),
			error && status !== "ok" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto max-w-6xl px-4 pt-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl bg-live/10 px-3 py-2 text-xs text-live shadow-[0_0_0_1px_rgb(226_75_75/0.22)]",
					children: [error, ". Podes usar o modo exemplo."]
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-6xl flex-wrap items-center gap-3 px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "ghost",
					onClick: loadDemo,
					children: "Carregar exemplo"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "ml-auto flex items-center gap-2 text-xs font-medium text-muted",
					children: ["Filtro analista", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
						checked: analystMode,
						onCheckedChange: setAnalystMode
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "px-4 pb-6",
				children: tab === "live" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveView, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistoryView, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-30 border-t border-border bg-bg/95 backdrop-blur-md",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto grid max-w-md grid-cols-2 px-4 pb-[env(safe-area-inset-bottom)] pt-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setTab("live"),
						className: cn("flex h-14 flex-col items-center justify-center gap-0.5 text-[11px] font-semibold", tab === "live" ? "text-accent" : "text-subtle"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Activity, { className: "size-5" }), "Ao vivo"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setTab("history"),
						className: cn("flex h-14 flex-col items-center justify-center gap-0.5 text-[11px] font-semibold", tab === "history" ? "text-accent" : "text-subtle"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, { className: "size-5" }), "Histórico"]
					})]
				})
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {});
}
//#endregion
export { Home as component };
