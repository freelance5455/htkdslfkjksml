import { i as __toESM } from "../_runtime.mjs";
import { L as require_react, v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Play, i as Settings, n as Volume2, o as Pause, s as ArrowLeft, t as VolumeX } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-VrWj-e67.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var GameAudio = class {
	ctx = null;
	master = null;
	sfx = null;
	ambience = null;
	muted = false;
	volume = .7;
	crowd = null;
	crowdGain = null;
	noiseBuf = null;
	unlock() {
		if (!this.ctx) {
			const AC = window.AudioContext || window.webkitAudioContext;
			this.ctx = new AC({ latencyHint: "interactive" });
			this.master = this.ctx.createGain();
			this.sfx = this.ctx.createGain();
			this.ambience = this.ctx.createGain();
			this.sfx.connect(this.master);
			this.ambience.connect(this.master);
			this.master.connect(this.ctx.destination);
			this.applyVolume();
			this.noiseBuf = this.makeNoise(1.5);
		}
		if (this.ctx.state === "suspended") this.ctx.resume();
		this.startCrowd();
	}
	resume() {
		if (this.ctx?.state === "suspended") this.ctx.resume();
	}
	setMuted(m) {
		this.muted = m;
		this.applyVolume();
	}
	setVolume(v) {
		this.volume = v;
		this.applyVolume();
	}
	applyVolume() {
		if (!this.master) return;
		const g = this.muted ? 0 : this.volume * this.volume;
		this.master.gain.setTargetAtTime(g, this.ctx.currentTime, .03);
	}
	makeNoise(seconds) {
		const ctx = this.ctx;
		const n = Math.floor(ctx.sampleRate * seconds);
		const buf = ctx.createBuffer(1, n, ctx.sampleRate);
		const d = buf.getChannelData(0);
		let last = 0;
		for (let i = 0; i < n; i++) {
			const white = Math.random() * 2 - 1;
			last = (last + .02 * white) / 1.02;
			d[i] = last * 3.5;
		}
		return buf;
	}
	startCrowd() {
		if (!this.ctx || !this.ambience || !this.noiseBuf || this.crowd) return;
		const src = this.ctx.createBufferSource();
		src.buffer = this.noiseBuf;
		src.loop = true;
		const filter = this.ctx.createBiquadFilter();
		filter.type = "lowpass";
		filter.frequency.value = 900;
		this.crowdGain = this.ctx.createGain();
		this.crowdGain.gain.value = .08;
		src.connect(filter);
		filter.connect(this.crowdGain);
		this.crowdGain.connect(this.ambience);
		src.start();
		this.crowd = src;
	}
	setExcitement(v) {
		if (!this.crowdGain || !this.ctx) return;
		this.crowdGain.gain.setTargetAtTime(.06 + v * .22, this.ctx.currentTime, .25);
	}
	tone(freq, dur, type, gain, delay = 0) {
		if (!this.ctx || !this.sfx) return;
		const t0 = this.ctx.currentTime + delay;
		const o = this.ctx.createOscillator();
		const g = this.ctx.createGain();
		o.type = type;
		o.frequency.setValueAtTime(freq, t0);
		g.gain.setValueAtTime(1e-4, t0);
		g.gain.exponentialRampToValueAtTime(gain, t0 + .02);
		g.gain.exponentialRampToValueAtTime(1e-4, t0 + dur);
		o.connect(g);
		g.connect(this.sfx);
		o.start(t0);
		o.stop(t0 + dur + .02);
	}
	noiseBurst(dur, gain, freq = 1200) {
		if (!this.ctx || !this.sfx || !this.noiseBuf) return;
		const t0 = this.ctx.currentTime;
		const src = this.ctx.createBufferSource();
		src.buffer = this.noiseBuf;
		const f = this.ctx.createBiquadFilter();
		f.type = "bandpass";
		f.frequency.value = freq;
		const g = this.ctx.createGain();
		g.gain.setValueAtTime(gain, t0);
		g.gain.exponentialRampToValueAtTime(1e-4, t0 + dur);
		src.connect(f);
		f.connect(g);
		g.connect(this.sfx);
		src.start(t0);
		src.stop(t0 + dur + .02);
	}
	kick(power = .6) {
		this.noiseBurst(.12, .18 + power * .2, 700 + power * 400);
		this.tone(90 + power * 40, .16, "sine", .22 + power * .15);
	}
	pass() {
		this.noiseBurst(.08, .12, 900);
		this.tone(140, .1, "sine", .12);
	}
	whistle() {
		this.tone(1480, .22, "sine", .12);
		this.tone(1480, .18, "sine", .1, .28);
	}
	longWhistle() {
		this.tone(1420, .7, "sine", .12);
	}
	goal() {
		this.setExcitement(1);
		this.tone(392, .18, "triangle", .14);
		this.tone(523, .2, "triangle", .12, .12);
		this.tone(659, .35, "triangle", .14, .24);
		this.noiseBurst(.4, .22, 500);
	}
	save() {
		this.noiseBurst(.1, .16, 400);
		this.tone(70, .12, "sine", .18);
	}
	ui() {
		this.tone(660, .06, "sine", .06);
	}
	catchBall() {
		this.noiseBurst(.06, .08, 500);
	}
};
var GAME_CODES = /* @__PURE__ */ new Set([
	"KeyW",
	"KeyA",
	"KeyS",
	"KeyD",
	"ArrowUp",
	"ArrowLeft",
	"ArrowDown",
	"ArrowRight",
	"ShiftLeft",
	"ShiftRight",
	"Space",
	"KeyJ",
	"KeyK",
	"KeyL",
	"KeyF",
	"KeyE",
	"KeyQ",
	"ControlLeft",
	"ControlRight",
	"Escape",
	"KeyP"
]);
function radialDeadzone(x, y, dz = .15) {
	const m = Math.hypot(x, y);
	if (m < dz) return {
		x: 0,
		y: 0
	};
	const scale = (m - dz) / (1 - dz) / m;
	return {
		x: x * scale,
		y: y * scale
	};
}
var Input = class {
	keys = /* @__PURE__ */ new Set();
	injected = null;
	stickX = 0;
	stickY = 0;
	touch = {
		sprint: false,
		pass: false,
		through: false,
		shoot: false,
		tackle: false,
		switchP: false
	};
	prevPass = false;
	prevThrough = false;
	prevShoot = false;
	prevTackle = false;
	prevSwitch = false;
	prevPause = false;
	attached = false;
	attach() {
		if (this.attached) return;
		this.attached = true;
		this.onKeyDown = this.onKeyDown.bind(this);
		this.onKeyUp = this.onKeyUp.bind(this);
		this.onBlur = this.onBlur.bind(this);
		window.addEventListener("keydown", this.onKeyDown);
		window.addEventListener("keyup", this.onKeyUp);
		window.addEventListener("blur", this.onBlur);
		document.addEventListener("visibilitychange", this.onBlur);
	}
	detach() {
		if (!this.attached) return;
		this.attached = false;
		window.removeEventListener("keydown", this.onKeyDown);
		window.removeEventListener("keyup", this.onKeyUp);
		window.removeEventListener("blur", this.onBlur);
		document.removeEventListener("visibilitychange", this.onBlur);
		this.keys.clear();
	}
	setKeys(codes) {
		this.injected = codes;
	}
	onKeyDown(e) {
		if (GAME_CODES.has(e.code)) e.preventDefault();
		this.keys.add(e.code);
	}
	onKeyUp(e) {
		this.keys.delete(e.code);
	}
	onBlur() {
		this.keys.clear();
	}
	held(code) {
		if (this.injected) return this.injected.includes(code);
		return this.keys.has(code);
	}
	samplePad() {
		const pads = navigator.getGamepads?.() ?? [];
		let x = 0;
		let y = 0;
		let sprint = false;
		let pass = false;
		let through = false;
		let shoot = false;
		let tackle = false;
		let switchP = false;
		let pause = false;
		for (const pad of pads) {
			if (!pad) continue;
			const st = radialDeadzone(pad.axes[0] ?? 0, pad.axes[1] ?? 0, .18);
			if (Math.hypot(st.x, st.y) > Math.hypot(x, y)) {
				x = st.x;
				y = st.y;
			}
			const b = pad.buttons;
			if (b[0]?.pressed) pass = true;
			if (b[1]?.pressed) shoot = true;
			if (b[2]?.pressed) through = true;
			if (b[3]?.pressed) switchP = true;
			if (b[5]?.pressed || (b[7]?.value ?? 0) > .4) sprint = true;
			if (b[4]?.pressed) tackle = true;
			if (b[9]?.pressed) pause = true;
			if (b[12]?.pressed) y -= 1;
			if (b[13]?.pressed) y += 1;
			if (b[14]?.pressed) x -= 1;
			if (b[15]?.pressed) x += 1;
		}
		return {
			x,
			y,
			sprint,
			pass,
			through,
			shoot,
			tackle,
			switchP,
			pause
		};
	}
	sample() {
		const pad = this.samplePad();
		let mx = 0;
		let my = 0;
		if (this.held("KeyA") || this.held("ArrowLeft")) mx -= 1;
		if (this.held("KeyD") || this.held("ArrowRight")) mx += 1;
		if (this.held("KeyW") || this.held("ArrowUp")) my -= 1;
		if (this.held("KeyS") || this.held("ArrowDown")) my += 1;
		mx += this.stickX + pad.x;
		my += this.stickY + pad.y;
		const mag = Math.hypot(mx, my);
		if (mag > 1) {
			mx /= mag;
			my /= mag;
		}
		const passDown = this.held("Space") || this.held("KeyJ") || this.touch.pass || pad.pass;
		const throughDown = this.held("KeyK") || this.touch.through || pad.through;
		const shootDown = this.held("KeyL") || this.held("KeyF") || this.touch.shoot || pad.shoot;
		const tackleDown = this.held("ControlLeft") || this.held("ControlRight") || this.touch.tackle || pad.tackle;
		const switchDown = this.held("KeyE") || this.held("KeyQ") || this.touch.switchP || pad.switchP;
		const pauseDown = this.held("Escape") || this.held("KeyP") || pad.pause;
		const actions = {
			moveX: mx,
			moveY: my,
			sprint: this.held("ShiftLeft") || this.held("ShiftRight") || this.touch.sprint || pad.sprint,
			pass: passDown && !this.prevPass,
			through: throughDown && !this.prevThrough,
			shoot: !shootDown && this.prevShoot,
			shootHeld: shootDown,
			tackle: tackleDown && !this.prevTackle,
			switchP: switchDown && !this.prevSwitch,
			pause: pauseDown && !this.prevPause
		};
		this.prevPass = passDown;
		this.prevThrough = throughDown;
		this.prevShoot = shootDown;
		this.prevTackle = tackleDown;
		this.prevSwitch = switchDown;
		this.prevPause = pauseDown;
		return actions;
	}
};
var clamp = (v, a, b) => Math.max(a, Math.min(b, v));
var lerp = (a, b, t) => a + (b - a) * t;
var len = (x, y) => Math.hypot(x, y);
function norm(x, y) {
	const l = Math.hypot(x, y);
	if (l < 1e-6) return [0, 0];
	return [x / l, y / l];
}
function lerpAngle(a, b, t) {
	let d = b - a;
	while (d > Math.PI) d -= Math.PI * 2;
	while (d < -Math.PI) d += Math.PI * 2;
	return a + d * t;
}
function rand(a, b) {
	return a + Math.random() * (b - a);
}
function poisson(lambda) {
	const L = Math.exp(-lambda);
	let k = 0;
	let p = 1;
	do {
		k += 1;
		p *= Math.random();
	} while (p > L);
	return k - 1;
}
var HALF_W = 105 / 2;
var GOAL_HALF = 3.66;
var STEP = 1 / 60;
var SKIN = [
	"#f3d2b5",
	"#e0b089",
	"#c68642",
	"#8d5524",
	"#5c3317",
	"#f6e0c8"
];
var HAIR = [
	"#1a120c",
	"#3b2314",
	"#6b4a2b",
	"#111111",
	"#4a2c12",
	"#c8b48a"
];
var FORM = {
	gk: [[-47.2, 0]],
	def: [
		[-33, -24],
		[-35, -8],
		[-35, 8],
		[-33, 24]
	],
	mid: [
		[-18, -16],
		[-22, 0],
		[-18, 16]
	],
	fwd: [
		[6, -22],
		[12, 0],
		[6, 22]
	]
};
function diffMul(d) {
	if (d === "amateur") return {
		ai: .72,
		acc: .55,
		press: .7,
		gk: .75
	};
	if (d === "world") return {
		ai: 1.12,
		acc: 1.05,
		press: 1.2,
		gk: 1.15
	};
	return {
		ai: .95,
		acc: .88,
		press: 1,
		gk: .95
	};
}
function makePlayer(id, team, def, slot, attack) {
	const s = def.squad[slot];
	const [bx, by] = homeSlot(s.role, slotRoleIndex(def, slot), attack);
	return {
		id,
		team,
		name: s.name,
		num: s.num,
		role: s.role,
		x: bx,
		y: by,
		px: bx,
		py: by,
		vx: 0,
		vy: 0,
		facing: attack > 0 ? 0 : Math.PI,
		stamina: 1,
		cooldown: 0,
		anim: Math.random() * 10,
		skin: Math.floor(Math.random() * SKIN.length),
		hair: Math.floor(Math.random() * HAIR.length)
	};
}
function slotRoleIndex(def, slot) {
	const role = def.squad[slot].role;
	let n = 0;
	for (let i = 0; i < slot; i++) if (def.squad[i].role === role) n++;
	return n;
}
function homeSlot(role, idx, attack) {
	const list = FORM[role];
	const [x, y] = list[Math.min(idx, list.length - 1)];
	return [x * attack, y];
}
function createMatch(home, away, opts) {
	const attack = [1, -1];
	const players = [];
	for (let i = 0; i < 11; i++) players.push(makePlayer(i, 0, home, i, attack[0]));
	for (let i = 0; i < 11; i++) players.push(makePlayer(11 + i, 1, away, i, attack[1]));
	const st = players.find((p) => p.team === (opts.userTeam === -1 ? 0 : opts.userTeam) && p.role === "fwd" && p.num === 9) ?? players[9];
	return {
		players,
		ball: {
			x: 0,
			y: 0,
			z: .22,
			vx: 0,
			vy: 0,
			vz: 0,
			px: 0,
			py: 0,
			pz: .22,
			owner: null,
			spin: 0,
			lastKicker: -1,
			lastKickT: 0
		},
		score: [0, 0],
		clock: 0,
		half: 1,
		phase: "kickoff",
		phaseT: 0,
		controlled: opts.userTeam === -1 ? -1 : st.id,
		userTeam: opts.userTeam,
		attack,
		event: "Kick off",
		eventT: 1.6,
		excitement: .2,
		trauma: 0,
		shootHold: 0,
		home,
		away,
		difficulty: opts.difficulty,
		practice: !!opts.practice,
		autoSwitch: opts.autoSwitch !== false,
		ended: false,
		lastScorer: 0
	};
}
function teamOf(m, t) {
	return t === 0 ? m.home : m.away;
}
function rating(m, p) {
	const tm = teamOf(m, p.team);
	if (p.role === "gk") return tm.def / 100;
	if (p.role === "def") return tm.def / 100;
	if (p.role === "mid") return tm.mid / 100;
	return tm.attack / 100;
}
function snapshotPrev(m) {
	for (const p of m.players) {
		p.px = p.x;
		p.py = p.y;
	}
	const b = m.ball;
	b.px = b.x;
	b.py = b.y;
	b.pz = b.z;
}
function formationTarget(m, p) {
	const atk = m.attack[p.team];
	const idx = m.players.filter((q) => q.team === p.team && q.role === p.role && q.id <= p.id).length - 1;
	let [x, y] = homeSlot(p.role, idx, atk);
	const ball = m.ball;
	const push = m.players.some((q) => q.team === p.team && m.ball.owner === q.id) ? 8 : -4;
	if (p.role !== "gk") {
		x += atk * push;
		x += clamp(ball.x * .22, -14, 14);
		y += clamp(ball.y * .16, -10, 10);
	} else {
		y = clamp(ball.y * .22, -8, 8);
		x = -47.2 * atk + atk * clamp(ball.x * atk > 20 ? 2 : 0, 0, 4);
	}
	x = clamp(x, -HALF_W + 1.5, HALF_W - 1.5);
	y = clamp(y, -32.5, 32.5);
	return [x, y];
}
function closestTo(m, team, x, y, skipId = -1, allowGk = true) {
	let best = null;
	let bestD = 1e9;
	for (const p of m.players) {
		if (skipId === p.id) continue;
		if (team !== "any" && p.team !== team) continue;
		if (!allowGk && p.role === "gk") continue;
		const d = (p.x - x) ** 2 + (p.y - y) ** 2;
		if (d < bestD) {
			bestD = d;
			best = p;
		}
	}
	return best;
}
function kickBall(m, p, vx, vy, vz) {
	const b = m.ball;
	b.owner = null;
	b.vx = vx;
	b.vy = vy;
	b.vz = vz;
	b.lastKicker = p.id;
	b.lastKickT = 0;
	p.cooldown = .28;
	b.spin += len(vx, vy) * .4;
}
function aimWorld(m, actions, p) {
	let ax = actions.moveX;
	let ay = actions.moveY;
	if (camFlip(m)) {
		ax = -ax;
		ay = -ay;
	}
	if (Math.hypot(ax, ay) < .28) {
		ax = Math.cos(p.facing);
		ay = Math.sin(p.facing);
	}
	return norm(ax, ay);
}
function camFlip(m) {
	if (m.userTeam !== 0 && m.userTeam !== 1) return false;
	return m.attack[m.userTeam] < 0;
}
function passTarget(m, p, ax, ay, through) {
	let best = null;
	let bestScore = -1e9;
	for (const q of m.players) {
		if (q.team !== p.team || q.id === p.id) continue;
		const dx = q.x - p.x;
		const dy = q.y - p.y;
		const d = Math.hypot(dx, dy);
		if (d < 2 || d > (through ? 48 : 32)) continue;
		const ndx = dx / d;
		const ndy = dy / d;
		const cone = ndx * ax + ndy * ay;
		if (cone < .15) continue;
		const fwd = (q.x - p.x) * m.attack[p.team];
		let open = 0;
		for (const o of m.players) {
			if (o.team === p.team) continue;
			const t = clamp(((o.x - p.x) * dx + (o.y - p.y) * dy) / (d * d), 0, 1);
			const cx = p.x + dx * t;
			const cy = p.y + dy * t;
			const od = Math.hypot(o.x - cx, o.y - cy);
			if (od < 3.5) open -= 4;
			else if (od < 7) open -= 1;
		}
		const score = cone * 12 + fwd * .15 + open - d * .08 + (through && q.role === "fwd" ? 3 : 0);
		if (score > bestScore) {
			bestScore = score;
			best = q;
		}
	}
	return best;
}
function doPass(m, p, ax, ay, through) {
	const t = passTarget(m, p, ax, ay, through);
	let vx, vy, vz;
	if (t) {
		const lead = through ? .35 : .12;
		const tx = t.x + t.vx * lead * 8;
		const ty = t.y + t.vy * lead * 8;
		const dx = tx - p.x;
		const dy = ty - p.y;
		const d = Math.hypot(dx, dy);
		const spd = through ? 18 + d * .18 : 12 + d * .22;
		vx = dx / d * spd;
		vy = dy / d * spd;
		vz = through ? 2.4 : .6;
		m.event = `${through ? "Through" : "Pass"} — ${t.name}`;
		m.eventT = 1.1;
	} else {
		const spd = through ? 20 : 14;
		vx = ax * spd;
		vy = ay * spd;
		vz = through ? 2.2 : .5;
	}
	kickBall(m, p, vx, vy, vz);
}
function doShot(m, p, ax, ay, power) {
	const gx = HALF_W * m.attack[p.team];
	const gy = clamp(m.ball.y * .3 + rand(-1.2, 1.2), -GOAL_HALF + .4, GOAL_HALF - .4);
	let dx = gx - p.x;
	let dy = gy - p.y;
	if (Math.hypot(ax, ay) > .35) {
		dx = ax;
		dy = ay;
	}
	const [nx, ny] = norm(dx, dy);
	const d = Math.hypot(gx - p.x, gy - p.y);
	const spread = (1.15 - diffMul(m.difficulty).acc * rating(m, p)) * (.35 + (1 - power) * .4) * (d > 22 ? 1.4 : 1);
	const ang = Math.atan2(ny, nx) + rand(-spread, spread);
	const spd = 16 + power * 14;
	kickBall(m, p, Math.cos(ang) * spd, Math.sin(ang) * spd, 1.2 + power * 2.4);
	m.event = `Shot — ${p.name}`;
	m.eventT = 1.2;
	m.trauma = Math.max(m.trauma, .35 + power * .4);
	m.excitement = Math.min(1, m.excitement + .35);
}
function switchPlayer(m, actions) {
	if (m.userTeam < 0) return;
	const team = m.userTeam;
	let ax = actions.moveX;
	let ay = actions.moveY;
	if (camFlip(m)) {
		ax = -ax;
		ay = -ay;
	}
	const cur = m.players[m.controlled];
	if (Math.hypot(ax, ay) > .35 && cur) {
		let best = null;
		let bestDot = -1e9;
		for (const p of m.players) {
			if (p.team !== team || p.id === cur.id || p.role === "gk") continue;
			const dx = p.x - cur.x;
			const dy = p.y - cur.y;
			const d = Math.hypot(dx, dy) || 1;
			const dot = dx / d * ax + dy / d * ay;
			if (dot > bestDot) {
				bestDot = dot;
				best = p;
			}
		}
		if (best) m.controlled = best.id;
		return;
	}
	const near = closestTo(m, team, m.ball.x, m.ball.y, -1, false);
	if (near) m.controlled = near.id;
}
function movePlayer(m, p, ax, ay, sprint, dt) {
	const r = rating(m, p);
	const maxWalk = (p.role === "gk" ? 6.4 : 7.1) * (.85 + r * .25);
	const maxSprint = (p.role === "gk" ? 8.2 : 10.6) * (.85 + r * .28);
	const canSprint = sprint && p.stamina > .06 && p.role !== "gk";
	const maxS = canSprint ? maxSprint : maxWalk;
	const acc = 36 * (.9 + r * .2);
	if (Math.hypot(ax, ay) > .08) {
		p.vx += ax * acc * dt;
		p.vy += ay * acc * dt;
		p.facing = lerpAngle(p.facing, Math.atan2(ay, ax), 1 - Math.exp(-10 * dt));
	} else {
		p.vx *= Math.exp(-8 * dt);
		p.vy *= Math.exp(-8 * dt);
	}
	const sp = Math.hypot(p.vx, p.vy);
	if (sp > maxS) {
		p.vx *= maxS / sp;
		p.vy *= maxS / sp;
	}
	p.x += p.vx * dt;
	p.y += p.vy * dt;
	p.x = clamp(p.x, -HALF_W - 1.2, HALF_W + 1.2);
	p.y = clamp(p.y, -35.2, 35.2);
	if (canSprint && sp > 6) p.stamina = Math.max(0, p.stamina - dt * .16);
	else p.stamina = Math.min(1, p.stamina + dt * .12);
	p.anim += sp * dt * 2.4;
	p.cooldown = Math.max(0, p.cooldown - dt);
}
function aiAct(m, p, dt) {
	const D = diffMul(m.difficulty);
	const b = m.ball;
	const atk = m.attack[p.team];
	const [tx0, ty0] = formationTarget(m, p);
	let tx = tx0;
	let ty = ty0;
	let sprint = false;
	let kick = null;
	const hasBall = b.owner === p.id;
	const teamHas = m.players.some((q) => q.team === p.team && b.owner === q.id);
	if (p.role === "gk") {
		tx = -HALF_W * atk + atk * 1.4;
		ty = clamp(b.y * .55, -GOAL_HALF - 1.5, GOAL_HALF + 1.5);
		if ((b.x - p.x) * atk < 0 && Math.abs(b.vx) > 8 && Math.abs(b.x) > 38) {
			const t = Math.abs((p.x - b.x) / (b.vx || 1));
			ty = clamp(b.y + b.vy * Math.min(t, .8), -GOAL_HALF - 2, GOAL_HALF + 2);
			sprint = true;
		}
		if (hasBall && p.cooldown <= 0) kick = "pass";
		if (!hasBall && Math.hypot(p.x - b.x, p.y - b.y) < 2.4 && b.z < 2.2) {}
	} else if (hasBall) {
		const goalX = HALF_W * atk;
		const distGoal = Math.hypot(goalX - p.x, -p.y);
		const inBox = p.x * atk > 30 && Math.abs(p.y) < 16 || distGoal < 18;
		tx = p.x + atk * 8;
		ty = p.y * .92;
		sprint = Math.random() < .35 * D.ai;
		if (p.cooldown <= 0) {
			if (inBox && Math.random() < .045 * D.acc) kick = "shot";
			else if (Math.random() < .028 * D.ai) kick = Math.random() < .35 ? "through" : "pass";
			else if (distGoal < 26 && Math.random() < .02) kick = "shot";
		}
	} else if (teamHas) {
		tx = tx0 + atk * 4;
		ty = ty0;
		const owner = m.players[b.owner];
		if (owner && p.role === "fwd") {
			tx = owner.x + atk * 10 + rand(-3, 3);
			ty = clamp(ty0 + rand(-4, 4), -30, 30);
			sprint = true;
		}
	} else {
		const presser = closestTo(m, p.team, b.x, b.y, -1, false);
		if (presser && presser.id === p.id) {
			tx = b.x + b.vx * .15;
			ty = b.y + b.vy * .15;
			sprint = true;
			if (Math.hypot(p.x - b.x, p.y - b.y) < 1.6 && Math.random() < .08 * D.press) kick = "tackle";
		} else {
			const mark = closestTo(m, p.team === 0 ? 1 : 0, p.x, p.y, -1, false);
			if (mark && p.role === "def") {
				tx = lerp(tx0, mark.x - atk * 2, .55);
				ty = lerp(ty0, mark.y, .5);
			}
		}
	}
	const dx = tx - p.x;
	const dy = ty - p.y;
	const d = Math.hypot(dx, dy);
	let ax = 0;
	let ay = 0;
	if (d > .4) {
		ax = dx / d;
		ay = dy / d;
		if (d < 2.2) {
			ax *= d / 2.2;
			ay *= d / 2.2;
		}
	}
	sprint = sprint && d > 6;
	return {
		ax,
		ay,
		sprint,
		kick
	};
}
function resolvePlayers(m) {
	const ps = m.players;
	for (let i = 0; i < ps.length; i++) for (let j = i + 1; j < ps.length; j++) {
		const a = ps[i];
		const b = ps[j];
		const dx = b.x - a.x;
		const dy = b.y - a.y;
		const d2 = dx * dx + dy * dy;
		const min = 1.35;
		if (d2 < min * min && d2 > 1e-6) {
			const d = Math.sqrt(d2);
			const pen = (min - d) * .5;
			const nx = dx / d;
			const ny = dy / d;
			a.x -= nx * pen;
			a.y -= ny * pen;
			b.x += nx * pen;
			b.y += ny * pen;
		}
	}
}
function updateBall(m, dt) {
	const b = m.ball;
	b.lastKickT += dt;
	if (b.owner !== null) {
		const p = m.players[b.owner];
		if (!p) b.owner = null;
		else {
			const hold = .78 + (p.role === "fwd" ? .08 : 0);
			b.x = p.x + Math.cos(p.facing) * hold;
			b.y = p.y + Math.sin(p.facing) * hold;
			b.z = .22;
			b.vx = p.vx;
			b.vy = p.vy;
			b.vz = 0;
			return;
		}
	}
	b.vz -= 18 * dt;
	b.x += b.vx * dt;
	b.y += b.vy * dt;
	b.z += b.vz * dt;
	if (b.z < .22) {
		b.z = .22;
		if (b.vz < 0) b.vz *= -.42;
		b.vx *= .82;
		b.vy *= .82;
	}
	b.vx *= Math.exp(-.55 * dt);
	b.vy *= Math.exp(-.55 * dt);
	b.spin += len(b.vx, b.vy) * dt * .8;
	if (Math.abs(b.y) > 34 && Math.abs(b.x) < 54.5) {
		b.y = clamp(b.y, -34, 34);
		b.vy *= -.35;
	}
}
function tryPickup(m) {
	const b = m.ball;
	if (b.owner !== null) return;
	if (b.lastKickT < .22) return;
	if (b.z > 1.6) return;
	const spd = len(b.vx, b.vy);
	let best = null;
	let bestD = 1.25;
	for (const p of m.players) {
		if (p.cooldown > 0) continue;
		const d = Math.hypot(p.x - b.x, p.y - b.y);
		if (d < (p.role === "gk" ? 1.7 : 1.15) && d < bestD) {
			bestD = d;
			best = p;
		}
	}
	if (!best) return;
	if (spd > 13 && best.role !== "gk") {
		const nx = (best.x - b.x) / (bestD || 1);
		const ny = (best.y - b.y) / (bestD || 1);
		b.vx += nx * 3;
		b.vy += ny * 3;
		b.vx *= .55;
		b.vy *= .55;
		return;
	}
	b.owner = best.id;
	b.vx = best.vx;
	b.vy = best.vy;
	if (m.userTeam === best.team && m.autoSwitch && m.userTeam >= 0 && best.role !== "gk") m.controlled = best.id;
}
function stealCheck(m, p) {
	const b = m.ball;
	if (b.owner === null || b.owner === p.id) return;
	const o = m.players[b.owner];
	if (!o || o.team === p.team) return;
	if (Math.hypot(p.x - b.x, p.y - b.y) > 1.35) return;
	const chance = .55 * (p.stamina + .3) * (1.1 - rating(m, o) * .4);
	if (Math.random() < chance) {
		b.owner = null;
		const [nx, ny] = norm(p.vx + rand(-1, 1), p.vy + rand(-1, 1));
		b.vx = nx * 6;
		b.vy = ny * 6;
		b.lastKickT = 0;
		o.cooldown = .25;
		m.event = `Tackle — ${p.name}`;
		m.eventT = .9;
	} else p.cooldown = .4;
}
function inGoal(b, side) {
	const line = HALF_W * side;
	return (side > 0 ? b.x > line : b.x < -line) && Math.abs(b.y) < 3.66 && b.z < 2.44;
}
function resetKickoff(m, kicking) {
	m.attack = m.half === 1 ? [1, -1] : [-1, 1];
	for (const p of m.players) {
		const idx = m.players.filter((q) => q.team === p.team && q.role === p.role && q.id <= p.id).length - 1;
		const [x, y] = homeSlot(p.role, idx, m.attack[p.team]);
		p.x = x;
		p.y = y;
		p.vx = 0;
		p.vy = 0;
		p.facing = m.attack[p.team] > 0 ? 0 : Math.PI;
		p.px = x;
		p.py = y;
	}
	m.ball.x = 0;
	m.ball.y = 0;
	m.ball.z = .22;
	m.ball.vx = 0;
	m.ball.vy = 0;
	m.ball.vz = 0;
	m.ball.owner = null;
	const kicker = m.players.find((p) => p.team === kicking && p.role === "fwd") ?? m.players[9];
	kicker.x = -1.2 * m.attack[kicking];
	kicker.y = 0;
	m.ball.owner = kicker.id;
	if (m.userTeam === kicking) m.controlled = kicker.id;
	m.phase = "kickoff";
	m.phaseT = 0;
}
function placeSetPiece(m, x, y, team) {
	m.ball.x = clamp(x, -HALF_W + .6, HALF_W - .6);
	m.ball.y = clamp(y, -33.4, 33.4);
	m.ball.z = .22;
	m.ball.vx = 0;
	m.ball.vy = 0;
	m.ball.vz = 0;
	const taker = closestTo(m, team, x, y, -1, Math.abs(x) > 45);
	if (taker) {
		taker.x = x - m.attack[team] * 1.2;
		taker.y = y;
		m.ball.owner = taker.id;
		if (m.userTeam === team) m.controlled = taker.id;
	}
	m.phase = "setpiece";
	m.phaseT = 0;
}
function checkBounds(m) {
	const b = m.ball;
	if (m.phase !== "play") return;
	if (inGoal(b, 1)) {
		score(m, m.attack[0] === 1 ? 0 : 1);
		return;
	}
	if (inGoal(b, -1)) {
		score(m, m.attack[0] === -1 ? 0 : 1);
		return;
	}
	if (Math.abs(b.x) > 52.5) {
		const teamLast = m.players[b.lastKicker]?.team ?? 0;
		b.x;
		const attackTeam = (m.attack[0] > 0 ? b.x > 0 : b.x < 0) ? 0 : 1;
		if (teamLast === attackTeam) {
			const gkTeam = 1 - attackTeam;
			placeSetPiece(m, (HALF_W - 8) * Math.sign(b.x), clamp(b.y, -8, 8), gkTeam);
			m.event = "Goal kick";
		} else {
			placeSetPiece(m, (HALF_W - .8) * Math.sign(b.x), Math.sign(b.y || 1) * 33.2, attackTeam);
			m.event = "Corner";
		}
		m.eventT = 1.4;
		return;
	}
	if (Math.abs(b.y) > 34) {
		const team = (m.players[b.lastKicker]?.team ?? 0) === 0 ? 1 : 0;
		placeSetPiece(m, clamp(b.x, -HALF_W + 2, HALF_W - 2), Math.sign(b.y) * 33.6, team);
		m.event = "Throw-in";
		m.eventT = 1.2;
	}
}
function score(m, team) {
	m.score[team] += 1;
	m.phase = "goal";
	m.phaseT = 0;
	const tm = team === 0 ? m.home : m.away;
	m.event = m.practice ? "GOAL" : `GOAL — ${tm.short}`;
	m.eventT = 2.5;
	m.trauma = 1;
	m.excitement = 1;
	m.ball.owner = null;
	m.lastScorer = team;
}
function stepMatch(m, actions, dt) {
	snapshotPrev(m);
	m.phaseT += dt;
	m.eventT = Math.max(0, m.eventT - dt);
	m.trauma = Math.max(0, m.trauma - dt * 1.6);
	m.excitement = lerp(m.excitement, m.phase === "play" ? .22 + Math.abs(m.ball.x) / 140 : .15, 1 - Math.exp(-1.2 * dt));
	if (m.phase === "fulltime") {
		m.ended = true;
		return;
	}
	if (m.phase === "halftime") {
		if (m.phaseT > 3.2) {
			m.half = 2;
			m.clock = 45;
			resetKickoff(m, 1);
			m.event = "Second half";
			m.eventT = 1.6;
		}
		return;
	}
	if (m.phase === "goal") {
		if (m.phaseT > 2.5) resetKickoff(m, 1 - m.lastScorer);
		return;
	}
	if (m.phase === "kickoff" && m.phaseT > 1.15) m.phase = "play";
	if (m.phase === "setpiece" && m.phaseT > .35) m.phase = "play";
	if (!m.practice && (m.phase === "play" || m.phase === "kickoff")) {
		m.clock += dt * (45 / 75);
		if (m.half === 1 && m.clock >= 45) {
			m.clock = 45;
			m.phase = "halftime";
			m.phaseT = 0;
			m.event = "Half time";
			m.eventT = 3;
			return;
		}
		if (m.half === 2 && m.clock >= 90) {
			m.clock = 90;
			m.phase = "fulltime";
			m.phaseT = 0;
			m.event = "Full time";
			m.eventT = 4;
			m.ended = true;
			return;
		}
	}
	if (m.userTeam >= 0 && actions.switchP) switchPlayer(m, actions);
	if (m.autoSwitch && m.userTeam >= 0 && m.phase === "play") {
		const owner = m.ball.owner !== null ? m.players[m.ball.owner] : null;
		if (owner && owner.team === m.userTeam && owner.role !== "gk" && owner.id !== m.controlled) {
			const me = m.players[m.controlled];
			if (!me || Math.hypot(me.x - m.ball.x, me.y - m.ball.y) > 16) m.controlled = owner.id;
		}
	}
	const user = m.userTeam >= 0 ? m.players[m.controlled] : void 0;
	let aimX = 0;
	let aimY = 0;
	if (user) {
		[aimX, aimY] = aimWorld(m, actions, user);
		if (actions.shootHeld) m.shootHold = Math.min(1, m.shootHold + dt * .9);
		else if (actions.shoot && m.ball.owner === user.id) {
			doShot(m, user, aimX, aimY, Math.max(.25, m.shootHold));
			m.shootHold = 0;
		} else if (!actions.shootHeld) m.shootHold = 0;
		if (actions.pass && m.ball.owner === user.id) doPass(m, user, aimX, aimY, false);
		if (actions.through && m.ball.owner === user.id) doPass(m, user, aimX, aimY, true);
		if (actions.tackle) stealCheck(m, user);
	} else m.shootHold = 0;
	for (const p of m.players) if (user && p.id === user.id) {
		let ax = actions.moveX;
		let ay = actions.moveY;
		if (camFlip(m)) {
			ax = -ax;
			ay = -ay;
		}
		movePlayer(m, p, ax, ay, actions.sprint, dt);
	} else {
		const a = aiAct(m, p, dt);
		movePlayer(m, p, a.ax, a.ay, a.sprint, dt);
		if (a.kick === "pass" && m.ball.owner === p.id) {
			const [nx, ny] = norm(m.attack[p.team], rand(-.4, .4));
			doPass(m, p, nx, ny, false);
		} else if (a.kick === "through" && m.ball.owner === p.id) {
			const [nx, ny] = norm(m.attack[p.team], rand(-.5, .5));
			doPass(m, p, nx, ny, true);
		} else if (a.kick === "shot" && m.ball.owner === p.id) doShot(m, p, m.attack[p.team], 0, rand(.55, .95));
		else if (a.kick === "tackle") stealCheck(m, p);
	}
	resolvePlayers(m);
	updateBall(m, dt);
	tryPickup(m);
	checkBounds(m);
}
function interpPlayer(p, a) {
	return {
		x: lerp(p.px, p.x, a),
		y: lerp(p.py, p.y, a)
	};
}
function interpBall(b, a) {
	return {
		x: lerp(b.px, b.x, a),
		y: lerp(b.py, b.y, a),
		z: lerp(b.pz, b.z, a)
	};
}
function skinColor(i) {
	return SKIN[i % SKIN.length];
}
function hairColor(i) {
	return HAIR[i % HAIR.length];
}
function createCam() {
	return {
		x: 0,
		y: 0,
		scale: 14,
		shakeX: 0,
		shakeY: 0
	};
}
function updateCam(cam, m, dt, w, h, demo) {
	const b = m.ball;
	camFlip(m);
	const targetX = b.x + b.vx * .18;
	const targetY = b.y + b.vy * .12;
	const k = 1 - Math.exp(-(demo ? 2.2 : 5.5) * dt);
	cam.x = lerp(cam.x, targetX, k);
	cam.y = lerp(cam.y, targetY, k);
	const fit = Math.min(w / (HALF_W * 2 + 18), h / (53.04 + 16));
	const zoom = demo ? fit * .92 : fit * 1.35;
	cam.scale = lerp(cam.scale, zoom, 1 - Math.exp(-3 * dt));
	const trauma = m.trauma * m.trauma;
	const t = performance.now() * .017;
	cam.shakeX = Math.sin(t * 37) * trauma * 10;
	cam.shakeY = Math.cos(t * 31) * trauma * 8;
}
function worldToScreen(cam, x, y, z, w, h, flip) {
	const fx = flip ? -x : x;
	const fy = flip ? -y : y;
	const cx = flip ? -cam.x : cam.x;
	const cy = flip ? -cam.y : cam.y;
	return {
		sx: (fx - cx) * cam.scale + w / 2 + cam.shakeX,
		sy: (fy - cy) * cam.scale * .78 - z * cam.scale * .85 + h / 2 + cam.shakeY,
		r: cam.scale
	};
}
function line(ctx, cam, x1, y1, x2, y2, w, h, flip) {
	const a = worldToScreen(cam, x1, y1, 0, w, h, flip);
	const b = worldToScreen(cam, x2, y2, 0, w, h, flip);
	ctx.moveTo(a.sx, a.sy);
	ctx.lineTo(b.sx, b.sy);
}
function ellipseAt(ctx, cam, x, y, rx, ry, w, h, flip) {
	const p = worldToScreen(cam, x, y, 0, w, h, flip);
	ctx.ellipse(p.sx, p.sy, rx * cam.scale, ry * cam.scale * .78, 0, 0, Math.PI * 2);
}
function drawWorld(ctx, m, cam, alpha, demo) {
	const w = ctx.canvas.width;
	const h = ctx.canvas.height;
	const flip = camFlip(m);
	ctx.fillStyle = "#0c1210";
	ctx.fillRect(0, 0, w, h);
	drawStadium(ctx, cam, w, h, flip, m.excitement);
	drawPitch(ctx, cam, w, h, flip);
	drawGoals(ctx, cam, w, h, flip);
	const order = m.players.map((p) => ({
		p,
		i: interpPlayer(p, alpha)
	})).sort((a, b) => a.i.y - b.i.y);
	const ball = interpBall(m.ball, alpha);
	let ballDrawn = false;
	for (const o of order) {
		if (!ballDrawn && o.i.y > ball.y) {
			drawBall(ctx, cam, ball, w, h, flip);
			ballDrawn = true;
		}
		drawPlayer(ctx, m, o.p, o.i.x, o.i.y, cam, w, h, flip, demo);
	}
	if (!ballDrawn) drawBall(ctx, cam, ball, w, h, flip);
	if (!demo) drawHud(ctx, m, cam, w, h, flip);
}
function drawStadium(ctx, cam, w, h, flip, excitement) {
	const pad = 18;
	const tl = worldToScreen(cam, -HALF_W - pad, -52, 0, w, h, flip);
	const br = worldToScreen(cam, HALF_W + pad, 52, 0, w, h, flip);
	ctx.fillStyle = "#15221c";
	ctx.fillRect(Math.min(tl.sx, br.sx), Math.min(tl.sy, br.sy), Math.abs(br.sx - tl.sx), Math.abs(br.sy - tl.sy));
	const rows = 5;
	for (let r = 0; r < rows; r++) {
		const y0 = -38 - r * 2.6;
		const y1 = 38 + r * 2.6;
		for (const y of [y0, y1]) {
			const a = worldToScreen(cam, -HALF_W - 10, y, 0, w, h, flip);
			const b = worldToScreen(cam, HALF_W + 10, y, 0, w, h, flip);
			const pulse = .55 + excitement * .35 + Math.sin(performance.now() * .004 + r) * .04;
			ctx.strokeStyle = `rgba(${40 + r * 12},${48 + r * 6},58, ${pulse})`;
			ctx.lineWidth = 7 - r;
			ctx.beginPath();
			ctx.moveTo(a.sx, a.sy);
			ctx.lineTo(b.sx, b.sy);
			ctx.stroke();
		}
	}
}
function drawPitch(ctx, cam, w, h, flip) {
	const stripes = 10;
	const sw = HALF_W * 2 / stripes;
	for (let i = 0; i < stripes; i++) {
		const x0 = -HALF_W + i * sw;
		const a = worldToScreen(cam, x0, -34, 0, w, h, flip);
		const b = worldToScreen(cam, x0 + sw, 34, 0, w, h, flip);
		ctx.fillStyle = i % 2 === 0 ? "#2f7a46" : "#2a6e40";
		ctx.fillRect(Math.min(a.sx, b.sx), Math.min(a.sy, b.sy), Math.abs(b.sx - a.sx), Math.abs(b.sy - a.sy));
	}
	ctx.strokeStyle = "rgba(255,255,255,0.82)";
	ctx.lineWidth = Math.max(1.2, cam.scale * .07);
	ctx.beginPath();
	line(ctx, cam, -HALF_W, -34, HALF_W, -34, w, h, flip);
	line(ctx, cam, HALF_W, -34, HALF_W, 34, w, h, flip);
	line(ctx, cam, HALF_W, 34, -HALF_W, 34, w, h, flip);
	line(ctx, cam, -HALF_W, 34, -HALF_W, -34, w, h, flip);
	line(ctx, cam, 0, -34, 0, 34, w, h, flip);
	ctx.stroke();
	ctx.beginPath();
	ellipseAt(ctx, cam, 0, 0, 9.15, 9.15, w, h, flip);
	ctx.stroke();
	ctx.beginPath();
	ellipseAt(ctx, cam, 0, 0, .35, .35, w, h, flip);
	ctx.fillStyle = "#fff";
	ctx.fill();
	for (const side of [-1, 1]) {
		const boxX = HALF_W * side;
		const p16 = boxX - 16.5 * side;
		const p6 = boxX - 5.5 * side;
		ctx.beginPath();
		line(ctx, cam, boxX, -20.16, p16, -20.16, w, h, flip);
		line(ctx, cam, p16, -20.16, p16, 20.16, w, h, flip);
		line(ctx, cam, p16, 20.16, boxX, 20.16, w, h, flip);
		ctx.stroke();
		ctx.beginPath();
		line(ctx, cam, boxX, -9.16, p6, -9.16, w, h, flip);
		line(ctx, cam, p6, -9.16, p6, 9.16, w, h, flip);
		line(ctx, cam, p6, 9.16, boxX, 9.16, w, h, flip);
		ctx.stroke();
		ctx.beginPath();
		ellipseAt(ctx, cam, boxX - 11 * side, 0, .28, .28, w, h, flip);
		ctx.fill();
		ctx.beginPath();
		ctx.strokeStyle = "rgba(255,255,255,0.7)";
		ellipseAt(ctx, cam, boxX - 11 * side, 0, 9.15, 9.15, w, h, flip);
		ctx.stroke();
		ctx.strokeStyle = "rgba(255,255,255,0.82)";
	}
}
function drawGoals(ctx, cam, w, h, flip) {
	for (const side of [-1, 1]) {
		const x = HALF_W * side;
		const depth = 2.4 * side;
		const posts = [
			[x, -GOAL_HALF],
			[x, GOAL_HALF],
			[x + depth, -GOAL_HALF],
			[x + depth, GOAL_HALF]
		];
		ctx.strokeStyle = "#f4f6f8";
		ctx.lineWidth = Math.max(2, cam.scale * .12);
		ctx.beginPath();
		for (const [px, py] of [
			[posts[0], posts[1]],
			[posts[0], posts[2]],
			[posts[1], posts[3]],
			[posts[2], posts[3]]
		]) line(ctx, cam, px[0], px[1], py[0], py[1], w, h, flip);
		ctx.stroke();
		ctx.strokeStyle = "rgba(230,240,255,0.28)";
		ctx.lineWidth = 1;
		ctx.beginPath();
		for (let i = 0; i <= 6; i++) {
			const yy = -GOAL_HALF + GOAL_HALF * 2 * i / 6;
			line(ctx, cam, x, yy, x + depth, yy, w, h, flip);
		}
		ctx.stroke();
	}
}
function kitCols(m, team) {
	return team === 0 ? m.home : m.away;
}
function drawPlayer(ctx, m, p, x, y, cam, w, h, flip, demo) {
	const g = worldToScreen(cam, x, y, 0, w, h, flip);
	const s = cam.scale;
	const selected = !demo && p.id === m.controlled && m.userTeam >= 0;
	const kit = kitCols(m, p.team);
	ctx.save();
	ctx.fillStyle = "rgba(0,0,0,0.28)";
	ctx.beginPath();
	ctx.ellipse(g.sx, g.sy + s * .08, s * .55, s * .22, 0, 0, Math.PI * 2);
	ctx.fill();
	if (selected) {
		ctx.strokeStyle = "rgba(255,255,255,0.9)";
		ctx.lineWidth = 2;
		ctx.beginPath();
		ctx.ellipse(g.sx, g.sy + s * .1, s * .72, s * .3, 0, 0, Math.PI * 2);
		ctx.stroke();
	}
	const fx = Math.cos(p.facing);
	const fy = Math.sin(p.facing);
	const head = worldToScreen(cam, x + fx * .22, y + fy * .22, 1.55, w, h, flip);
	const hip = worldToScreen(cam, x, y, .55, w, h, flip);
	const phase = p.anim;
	const leg = Math.sin(phase * 6.2) * .35;
	const l1 = worldToScreen(cam, x - fy * .18 + fx * leg, y + fx * .18 + fy * leg, .05, w, h, flip);
	const l2 = worldToScreen(cam, x + fy * .18 - fx * leg, y - fx * .18 - fy * leg, .05, w, h, flip);
	ctx.strokeStyle = kit.socks;
	ctx.lineWidth = Math.max(2, s * .16);
	ctx.lineCap = "round";
	ctx.beginPath();
	ctx.moveTo(hip.sx, hip.sy);
	ctx.lineTo(l1.sx, l1.sy);
	ctx.moveTo(hip.sx, hip.sy);
	ctx.lineTo(l2.sx, l2.sy);
	ctx.stroke();
	ctx.fillStyle = kit.shorts;
	ctx.beginPath();
	ctx.ellipse(hip.sx, hip.sy, s * .28, s * .2, 0, 0, Math.PI * 2);
	ctx.fill();
	const torso = worldToScreen(cam, x + fx * .08, y + fy * .08, 1.05, w, h, flip);
	ctx.fillStyle = kit.primary;
	ctx.beginPath();
	ctx.ellipse(torso.sx, torso.sy, s * .32, s * .38, 0, 0, Math.PI * 2);
	ctx.fill();
	if (kit.pattern === "stripe") {
		ctx.fillStyle = kit.secondary;
		ctx.fillRect(torso.sx - s * .08, torso.sy - s * .32, s * .16, s * .64);
	} else if (kit.pattern === "sash") {
		ctx.save();
		ctx.translate(torso.sx, torso.sy);
		ctx.rotate(.6);
		ctx.fillStyle = kit.secondary;
		ctx.fillRect(-s * .06, -s * .4, s * .12, s * .8);
		ctx.restore();
	} else if (kit.pattern === "hoop") {
		ctx.fillStyle = kit.secondary;
		ctx.fillRect(torso.sx - s * .3, torso.sy - s * .06, s * .6, s * .12);
	}
	ctx.fillStyle = skinColor(p.skin);
	ctx.beginPath();
	ctx.arc(head.sx, head.sy, s * .22, 0, Math.PI * 2);
	ctx.fill();
	ctx.fillStyle = hairColor(p.hair);
	ctx.beginPath();
	ctx.ellipse(head.sx, head.sy - s * .08, s * .2, s * .12, 0, 0, Math.PI * 2);
	ctx.fill();
	if (p.role === "gk") {
		ctx.strokeStyle = "#f0d24a";
		ctx.lineWidth = 1.4;
		ctx.stroke();
	}
	if (selected || s > 16) {
		ctx.font = `${Math.max(10, s * .42)}px "Segoe UI", sans-serif`;
		ctx.textAlign = "center";
		ctx.fillStyle = "rgba(8,10,12,0.7)";
		ctx.fillText(String(p.num), torso.sx, torso.sy + 4);
		ctx.fillStyle = "rgba(255,255,255,0.92)";
		ctx.fillText(String(p.num), torso.sx, torso.sy + 3);
	}
	if (selected) {
		ctx.font = `600 ${Math.max(11, s * .38)}px "Segoe UI", sans-serif`;
		ctx.textAlign = "center";
		ctx.fillStyle = "rgba(8,9,12,0.72)";
		ctx.fillRect(g.sx - 36, g.sy - s * 2.35, 72, 16);
		ctx.fillStyle = "#f3f4f6";
		ctx.fillText(p.name.toUpperCase(), g.sx, g.sy - s * 2.35 + 12);
	}
	ctx.restore();
}
function drawBall(ctx, cam, ball, w, h, flip) {
	const g = worldToScreen(cam, ball.x, ball.y, 0, w, h, flip);
	const p = worldToScreen(cam, ball.x, ball.y, ball.z, w, h, flip);
	const s = cam.scale;
	ctx.fillStyle = `rgba(0,0,0,${.22 + ball.z * .04})`;
	ctx.beginPath();
	ctx.ellipse(g.sx, g.sy, s * .28 + ball.z * .08, s * .12, 0, 0, Math.PI * 2);
	ctx.fill();
	ctx.fillStyle = "#f5f6f8";
	ctx.beginPath();
	ctx.arc(p.sx, p.sy, s * .22, 0, Math.PI * 2);
	ctx.fill();
	ctx.fillStyle = "#1a1c20";
	ctx.beginPath();
	ctx.arc(p.sx + s * .04, p.sy - s * .02, s * .07, 0, Math.PI * 2);
	ctx.fill();
	ctx.beginPath();
	ctx.arc(p.sx - s * .08, p.sy + s * .04, s * .06, 0, Math.PI * 2);
	ctx.fill();
}
function clockLabel(m) {
	return `${Math.min(90, Math.floor(m.clock))}:${Math.floor(m.clock % 1 * 60).toString().padStart(2, "0")}`;
}
function drawHud(ctx, m, cam, w, h, flip) {
	const pad = 16;
	ctx.save();
	const bw = Math.min(420, w - 32);
	const bx = (w - bw) / 2;
	roundRect(ctx, bx, pad, bw, 52, 14);
	ctx.fillStyle = "rgba(8,9,12,0.78)";
	ctx.fill();
	ctx.strokeStyle = "rgba(255,255,255,0.08)";
	ctx.stroke();
	ctx.font = "600 13px 'Segoe UI', sans-serif";
	ctx.fillStyle = "#8b919c";
	ctx.textAlign = "left";
	ctx.fillText(m.home.short, bx + 16, 38);
	ctx.textAlign = "right";
	ctx.fillText(m.away.short, bx + bw - 16, 38);
	ctx.textAlign = "center";
	ctx.fillStyle = "#f3f4f6";
	ctx.font = "700 22px 'Segoe UI', sans-serif";
	ctx.fillText(`${m.score[0]}  –  ${m.score[1]}`, bx + bw / 2, 42);
	ctx.font = "500 11px ui-monospace, monospace";
	ctx.fillStyle = "#5eaf7a";
	ctx.fillText(m.practice ? "PRACTICE" : `H${m.half}  ${clockLabel(m)}`, bx + bw / 2, 60);
	if (m.eventT > 0) {
		ctx.globalAlpha = clamp(m.eventT, 0, 1);
		ctx.font = "600 16px 'Segoe UI', sans-serif";
		ctx.fillStyle = "#f3f4f6";
		ctx.fillText(m.event, w / 2, 94);
		ctx.globalAlpha = 1;
	}
	drawRadar(ctx, m, 16, h - 108, 140, 88);
	const user = m.userTeam >= 0 ? m.players[m.controlled] : null;
	if (user) {
		ctx.fillStyle = "rgba(8,9,12,0.65)";
		roundRect(ctx, w - 150, h - 54, 134, 38, 10);
		ctx.fill();
		ctx.fillStyle = "#8b919c";
		ctx.font = "500 10px 'Segoe UI', sans-serif";
		ctx.textAlign = "left";
		ctx.fillText("STAMINA", w - 138, h - 38);
		ctx.fillStyle = "#1a1d26";
		ctx.fillRect(w - 138, h - 32, 110, 6);
		ctx.fillStyle = user.stamina > .25 ? "#5eaf7a" : "#d45b52";
		ctx.fillRect(w - 138, h - 32, 110 * user.stamina, 6);
	}
	if (m.shootHold > .04) {
		const pw = 160;
		ctx.fillStyle = "rgba(8,9,12,0.7)";
		roundRect(ctx, (w - pw) / 2, h * .62, pw, 14, 7);
		ctx.fill();
		ctx.fillStyle = "#5eaf7a";
		ctx.fillRect((w - pw) / 2 + 2, h * .62 + 2, 156 * m.shootHold, 10);
	}
	if (m.phase === "halftime" || m.phase === "fulltime" || m.phase === "goal") {
		ctx.fillStyle = "rgba(8,9,12,0.35)";
		ctx.fillRect(0, 0, w, h);
		ctx.font = "700 42px 'Segoe UI', sans-serif";
		ctx.textAlign = "center";
		ctx.fillStyle = "#f3f4f6";
		const title = m.phase === "goal" ? "GOAL" : m.phase === "halftime" ? "HALF TIME" : "FULL TIME";
		ctx.fillText(title, w / 2, h / 2 - 8);
		if (m.phase !== "goal") {
			ctx.font = "600 20px 'Segoe UI', sans-serif";
			ctx.fillText(`${m.home.short}  ${m.score[0]}  –  ${m.score[1]}  ${m.away.short}`, w / 2, h / 2 + 28);
		}
	}
	ctx.restore();
}
function drawRadar(ctx, m, x, y, rw, rh) {
	ctx.save();
	roundRect(ctx, x, y, rw, rh, 10);
	ctx.fillStyle = "rgba(8,12,10,0.72)";
	ctx.fill();
	ctx.strokeStyle = "rgba(255,255,255,0.12)";
	ctx.stroke();
	const ix = x + 8;
	const iy = y + 8;
	const iw = rw - 16;
	const ih = rh - 16;
	ctx.strokeStyle = "rgba(255,255,255,0.25)";
	ctx.strokeRect(ix, iy, iw, ih);
	ctx.beginPath();
	ctx.moveTo(ix + iw / 2, iy);
	ctx.lineTo(ix + iw / 2, iy + ih);
	ctx.stroke();
	const flip = camFlip(m);
	const toR = (wx, wy) => {
		const fx = flip ? -wx : wx;
		const fy = flip ? -wy : wy;
		return {
			rx: ix + (fx + HALF_W) / (HALF_W * 2) * iw,
			ry: iy + (fy + 34) / 68 * ih
		};
	};
	for (const p of m.players) {
		const { rx, ry } = toR(p.x, p.y);
		ctx.fillStyle = p.team === 0 ? "#e8eef5" : "#d45b52";
		if (p.id === m.controlled && m.userTeam >= 0) ctx.fillStyle = "#5eaf7a";
		ctx.beginPath();
		ctx.arc(rx, ry, p.id === m.controlled ? 3.2 : 2.2, 0, Math.PI * 2);
		ctx.fill();
	}
	const b = toR(m.ball.x, m.ball.y);
	ctx.fillStyle = "#fff";
	ctx.beginPath();
	ctx.arc(b.rx, b.ry, 2.4, 0, Math.PI * 2);
	ctx.fill();
	ctx.restore();
}
function roundRect(ctx, x, y, w, h, r) {
	const rr = Math.min(r, w / 2, h / 2);
	ctx.beginPath();
	ctx.moveTo(x + rr, y);
	ctx.arcTo(x + w, y, x + w, y + h, rr);
	ctx.arcTo(x + w, y + h, x, y + h, rr);
	ctx.arcTo(x, y + h, x, y, rr);
	ctx.arcTo(x, y, x + w, y, rr);
	ctx.closePath();
}
var GameEngine = class {
	canvas;
	ctx;
	input = new Input();
	audio = new GameAudio();
	match;
	cam = createCam();
	mode = "demo";
	running = false;
	raf = 0;
	acc = 0;
	last = 0;
	dpr = 1;
	onHud = null;
	onEnded = null;
	onGoal = null;
	onPauseChange = null;
	lastScore = [0, 0];
	paused = false;
	shakeOn = true;
	constructor(canvas, home, away) {
		this.canvas = canvas;
		const ctx = canvas.getContext("2d");
		if (!ctx) throw new Error("Canvas unsupported");
		this.ctx = ctx;
		this.match = createMatch(home, away, {
			userTeam: -1,
			difficulty: "pro"
		});
	}
	startDemo(home, away) {
		this.mode = "demo";
		this.match = createMatch(home, away, {
			userTeam: -1,
			difficulty: "pro"
		});
		this.lastScore = [0, 0];
		this.paused = false;
	}
	startLive(home, away, opts) {
		this.mode = "live";
		this.match = createMatch(home, away, {
			userTeam: opts.userTeam,
			difficulty: opts.difficulty,
			practice: opts.practice,
			autoSwitch: opts.autoSwitch
		});
		this.lastScore = [0, 0];
		this.paused = false;
		this.audio.whistle();
	}
	attach() {
		this.input.attach();
		this.resize();
		window.addEventListener("resize", this.resize);
		document.addEventListener("visibilitychange", this.onVis);
		this.running = true;
		this.last = performance.now();
		this.acc = 0;
		this.loop = this.loop.bind(this);
		this.raf = requestAnimationFrame(this.loop);
		this.installProbe();
	}
	detach() {
		this.running = false;
		cancelAnimationFrame(this.raf);
		this.input.detach();
		window.removeEventListener("resize", this.resize);
		document.removeEventListener("visibilitychange", this.onVis);
		if (window.__controlsTest) delete window.__controlsTest;
	}
	resize = () => {
		const parent = this.canvas.parentElement ?? document.body;
		const w = parent.clientWidth || window.innerWidth;
		const h = parent.clientHeight || window.innerHeight;
		this.dpr = Math.min(2, window.devicePixelRatio || 1);
		this.canvas.width = Math.max(1, Math.floor(w * this.dpr));
		this.canvas.height = Math.max(1, Math.floor(h * this.dpr));
		this.canvas.style.width = `${w}px`;
		this.canvas.style.height = `${h}px`;
	};
	onVis = () => {
		if (document.visibilityState === "visible") this.audio.resume();
		else this.input.keys.clear();
	};
	installProbe() {
		window.__controlsTest = {
			getYaw: () => {
				return this.match.players[this.match.controlled]?.facing ?? 0;
			},
			getSpeed: () => {
				const p = this.match.players[this.match.controlled];
				if (!p) return 0;
				return Math.hypot(p.vx, p.vy);
			},
			setKeys: (codes) => this.input.setKeys(codes),
			getPos: () => {
				const p = this.match.players[this.match.controlled];
				return {
					x: p?.x ?? 0,
					y: p?.y ?? 0
				};
			}
		};
	}
	loop = (now) => {
		if (!this.running) return;
		const raw = Math.min(.1, (now - this.last) / 1e3);
		this.last = now;
		if (!this.paused) {
			this.acc += raw;
			const idle = {
				moveX: 0,
				moveY: 0,
				sprint: false,
				pass: false,
				through: false,
				shoot: false,
				shootHeld: false,
				tackle: false,
				switchP: false,
				pause: false
			};
			while (this.acc >= STEP) {
				const actions = this.mode === "live" ? this.input.sample() : idle;
				if (actions.pause && this.mode === "live") {
					this.paused = true;
					this.onPauseChange?.(true);
					break;
				}
				const prevPhase = this.match.phase;
				stepMatch(this.match, actions, STEP);
				this.acc -= STEP;
				if (this.match.score[0] !== this.lastScore[0] || this.match.score[1] !== this.lastScore[1]) {
					this.lastScore = [this.match.score[0], this.match.score[1]];
					this.audio.goal();
					this.onGoal?.();
				}
				if (prevPhase !== "fulltime" && this.match.phase === "fulltime") {
					this.audio.longWhistle();
					this.onEnded?.(this.match);
				}
				if (this.match.phase === "halftime" && prevPhase !== "halftime") this.audio.whistle();
			}
		} else {
			this.acc = 0;
			if (this.input.sample().pause) {
				this.paused = false;
				this.onPauseChange?.(false);
			}
		}
		const alpha = this.paused ? 1 : this.acc / STEP;
		const cssW = this.canvas.width / this.dpr;
		const cssH = this.canvas.height / this.dpr;
		updateCam(this.cam, this.match, raw, cssW, cssH, this.mode === "demo");
		if (!this.shakeOn) {
			this.cam.shakeX = 0;
			this.cam.shakeY = 0;
		}
		this.ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
		drawWorld(this.ctx, this.match, this.cam, alpha, this.mode === "demo");
		this.audio.setExcitement(this.match.excitement);
		this.raf = requestAnimationFrame(this.loop);
	};
};
var ROLES = [
	"gk",
	"def",
	"def",
	"def",
	"def",
	"mid",
	"mid",
	"mid",
	"fwd",
	"fwd",
	"fwd"
];
var NUMS = [
	1,
	2,
	3,
	4,
	5,
	6,
	8,
	10,
	7,
	9,
	11
];
function squad(names) {
	return names.slice(0, 11).map((name, i) => ({
		name,
		num: NUMS[i],
		role: ROLES[i]
	}));
}
var TEAMS = [
	{
		id: "blancos",
		name: "Capital Blancos",
		short: "CBL",
		city: "Madrid",
		primary: "#f4f4f1",
		secondary: "#c9a227",
		shorts: "#f4f4f1",
		socks: "#f4f4f1",
		pattern: "solid",
		rating: 88,
		attack: 90,
		mid: 87,
		def: 86,
		squad: squad([
			"Courto",
			"Carva",
			"Milita",
			"Rudig",
			"Mendy",
			"Tchou",
			"Valver",
			"Belling",
			"Vini",
			"Mbappe",
			"Rodry"
		])
	},
	{
		id: "catalans",
		name: "Harbor Catalans",
		short: "HCA",
		city: "Barcelona",
		primary: "#a50044",
		secondary: "#004d98",
		shorts: "#004d98",
		socks: "#a50044",
		pattern: "stripe",
		rating: 86,
		attack: 88,
		mid: 89,
		def: 82,
		squad: squad([
			"Szczes",
			"Kounde",
			"Araujo",
			"Cubarsi",
			"Balde",
			"Pedri",
			"Gavi",
			"DeJong",
			"Yamal",
			"Lewand",
			"Raphin"
		])
	},
	{
		id: "northbank",
		name: "Northbank Scarlet",
		short: "NBS",
		city: "London",
		primary: "#ef0107",
		secondary: "#f2f2f2",
		shorts: "#f2f2f2",
		socks: "#ef0107",
		pattern: "solid",
		rating: 85,
		attack: 86,
		mid: 84,
		def: 84,
		squad: squad([
			"Raya",
			"White",
			"Saliba",
			"Gabriel",
			"Timber",
			"Rice",
			"Odega",
			"Havert",
			"Saka",
			"Jesus",
			"Martin"
		])
	},
	{
		id: "dockside",
		name: "Dockside Crimson",
		short: "DCR",
		city: "Liverpool",
		primary: "#c8102e",
		secondary: "#00b2a9",
		shorts: "#c8102e",
		socks: "#c8102e",
		pattern: "solid",
		rating: 87,
		attack: 89,
		mid: 85,
		def: 85,
		squad: squad([
			"Alisson",
			"Alexander",
			"VanDijk",
			"Konate",
			"Robert",
			"MacAll",
			"Szobos",
			"Jones",
			"Salah",
			"Nunez",
			"Diaz"
		])
	},
	{
		id: "seine",
		name: "Seine Royale",
		short: "SNR",
		city: "Paris",
		primary: "#002395",
		secondary: "#e30613",
		shorts: "#002395",
		socks: "#e30613",
		pattern: "sash",
		rating: 84,
		attack: 87,
		mid: 82,
		def: 81,
		squad: squad([
			"Donnar",
			"Hakimi",
			"Marqui",
			"Skrini",
			"Mendes",
			"Vitinh",
			"Ruiz",
			"Lee",
			"Dembele",
			"Barcol",
			"Kolo"
		])
	},
	{
		id: "alpine",
		name: "Alpine Bavaria",
		short: "ABV",
		city: "Munich",
		primary: "#dc052d",
		secondary: "#f2f2f2",
		shorts: "#dc052d",
		socks: "#dc052d",
		pattern: "hoop",
		rating: 85,
		attack: 86,
		mid: 85,
		def: 83,
		squad: squad([
			"Neuer",
			"Kimmich",
			"Upamec",
			"Kim",
			"Davies",
			"Goretz",
			"Musial",
			"Wirtz",
			"Sane",
			"Kane",
			"Olisem"
		])
	},
	{
		id: "canal",
		name: "Canal Inter",
		short: "CIN",
		city: "Milan",
		primary: "#010e80",
		secondary: "#0a0a0a",
		shorts: "#0a0a0a",
		socks: "#010e80",
		pattern: "stripe",
		rating: 86,
		attack: 84,
		mid: 85,
		def: 88,
		squad: squad([
			"Sommer",
			"DiLoren",
			"Acerbi",
			"Bastoni",
			"Dimarc",
			"Barella",
			"Calhan",
			"Mkhit",
			"Thuram",
			"Lautar",
			"Frates"
		])
	},
	{
		id: "piedmont",
		name: "Piedmont Stripe",
		short: "PST",
		city: "Turin",
		primary: "#f2f2f2",
		secondary: "#111111",
		shorts: "#111111",
		socks: "#f2f2f2",
		pattern: "stripe",
		rating: 82,
		attack: 81,
		mid: 82,
		def: 83,
		squad: squad([
			"Szczes2",
			"Danilo",
			"Bremer",
			"Gatti",
			"Cambias",
			"Locat",
			"Rabiot",
			"Koop",
			"Chiesa",
			"Vlahov",
			"Gonzal"
		])
	},
	{
		id: "lisbon",
		name: "Lisbon Lions",
		short: "LSL",
		city: "Lisbon",
		primary: "#006633",
		secondary: "#f2f2f2",
		shorts: "#006633",
		socks: "#f2f2f2",
		pattern: "solid",
		rating: 81,
		attack: 83,
		mid: 80,
		def: 79,
		squad: squad([
			"Costa",
			"Inacio",
			"Diomas",
			"St.Just",
			"Reis",
			"Hjulma",
			"Morita",
			"Fernan",
			"Gyoker",
			"Edwards",
			"Trinco"
		])
	},
	{
		id: "dam",
		name: "Dam Square",
		short: "DMS",
		city: "Amsterdam",
		primary: "#e30613",
		secondary: "#f2f2f2",
		shorts: "#f2f2f2",
		socks: "#e30613",
		pattern: "solid",
		rating: 80,
		attack: 82,
		mid: 81,
		def: 77,
		squad: squad([
			"Rulli",
			"Rensch",
			"Sutalo",
			"Marta",
			"Wijndal",
			"Hender",
			"Taylor",
			"Berghu",
			"Bergwi",
			"Brobbey",
			"Akpom"
		])
	},
	{
		id: "douro",
		name: "Douro Dragons",
		short: "DDR",
		city: "Porto",
		primary: "#003087",
		secondary: "#f2f2f2",
		shorts: "#003087",
		socks: "#f2f2f2",
		pattern: "sash",
		rating: 80,
		attack: 79,
		mid: 80,
		def: 81,
		squad: squad([
			"CostaP",
			"JoaoM",
			"Otavio",
			"Pepe",
			"Wendel",
			"Varela",
			"Eustaq",
			"PepeM",
			"Galeno",
			"Taremi",
			"Evanil"
		])
	},
	{
		id: "vesuvio",
		name: "Vesuvio Azzurro",
		short: "VAZ",
		city: "Naples",
		primary: "#12a0d7",
		secondary: "#f2f2f2",
		shorts: "#12a0d7",
		socks: "#12a0d7",
		pattern: "solid",
		rating: 83,
		attack: 84,
		mid: 82,
		def: 82,
		squad: squad([
			"Meret",
			"DiLore",
			"Rrahma",
			"JuanJ",
			"Oliver",
			"Anguis",
			"Lobots",
			"Politano",
			"Kvara",
			"Osimhen",
			"Raspad"
		])
	}
];
function teamById(id) {
	return TEAMS.find((t) => t.id === id) ?? TEAMS[0];
}
function otherTeam(id) {
	const rest = TEAMS.filter((t) => t.id !== id);
	return rest[Math.floor(Math.random() * rest.length)] ?? TEAMS[1];
}
var KEY = "fc28-save-v1";
var SETTINGS_KEY = "fc28-settings-v1";
var SAVE_VERSION = 1;
var defaultSettings = () => ({
	version: SAVE_VERSION,
	volume: .7,
	muted: false,
	shake: true,
	autoSwitch: true,
	difficulty: "pro"
});
function loadSettings() {
	if (typeof window === "undefined") return defaultSettings();
	try {
		const raw = localStorage.getItem(SETTINGS_KEY);
		if (!raw) return defaultSettings();
		const parsed = JSON.parse(raw);
		return {
			...defaultSettings(),
			...parsed,
			version: SAVE_VERSION
		};
	} catch {
		return defaultSettings();
	}
}
function saveSettings(s) {
	try {
		localStorage.setItem(SETTINGS_KEY, JSON.stringify({
			...s,
			version: SAVE_VERSION
		}));
	} catch {}
}
function roundRobin(ids) {
	const list = [...ids];
	if (list.length % 2 === 1) list.push("bye");
	const n = list.length;
	const rounds = n - 1;
	const half = n / 2;
	const out = [];
	const arr = [...list];
	for (let r = 0; r < rounds; r++) {
		for (let i = 0; i < half; i++) {
			const a = arr[i];
			const b = arr[n - 1 - i];
			if (a !== "bye" && b !== "bye") out.push(r % 2 === 0 ? {
				homeId: a,
				awayId: b,
				hg: null,
				ag: null
			} : {
				homeId: b,
				awayId: a,
				hg: null,
				ag: null
			});
		}
		const last = arr.pop();
		arr.splice(1, 0, last);
	}
	return out;
}
function newCareer(teamId) {
	return {
		version: SAVE_VERSION,
		teamId,
		week: 0,
		fixtures: roundRobin(TEAMS.map((t) => t.id))
	};
}
function loadCareer() {
	if (typeof window === "undefined") return null;
	try {
		const raw = localStorage.getItem(KEY);
		if (!raw) return null;
		const parsed = JSON.parse(raw);
		if (!parsed.teamId || !parsed.fixtures) return null;
		return {
			...parsed,
			version: SAVE_VERSION
		};
	} catch {
		return null;
	}
}
function saveCareer(c) {
	try {
		localStorage.setItem(KEY, JSON.stringify({
			...c,
			version: SAVE_VERSION
		}));
	} catch {}
}
function clearCareer() {
	try {
		localStorage.removeItem(KEY);
	} catch {}
}
function simScore(home, away) {
	const hs = (home.rating + home.attack * .4) / 140;
	const as = (away.rating + away.attack * .4) / 140;
	return [poisson(1.15 * hs + .25), poisson(1 * as)];
}
function standings(career) {
	const rows = /* @__PURE__ */ new Map();
	for (const t of TEAMS) rows.set(t.id, {
		id: t.id,
		team: t,
		p: 0,
		w: 0,
		d: 0,
		l: 0,
		gf: 0,
		ga: 0,
		gd: 0,
		pts: 0
	});
	for (const f of career.fixtures) {
		if (f.hg === null || f.ag === null) continue;
		const h = rows.get(f.homeId);
		const a = rows.get(f.awayId);
		if (!h || !a) continue;
		h.p++;
		a.p++;
		h.gf += f.hg;
		h.ga += f.ag;
		a.gf += f.ag;
		a.ga += f.hg;
		if (f.hg > f.ag) {
			h.w++;
			a.l++;
			h.pts += 3;
		} else if (f.hg < f.ag) {
			a.w++;
			h.l++;
			a.pts += 3;
		} else {
			h.d++;
			a.d++;
			h.pts += 1;
			a.pts += 1;
		}
	}
	for (const r of rows.values()) r.gd = r.gf - r.ga;
	return [...rows.values()].sort((a, b) => b.pts - a.pts || b.gd - a.gd || b.gf - a.gf);
}
function nextUserFixture(career) {
	return career.fixtures.find((f) => f.hg === null && (f.homeId === career.teamId || f.awayId === career.teamId)) ?? null;
}
function applyUserResult(career, hg, ag) {
	const next = structuredClone(career);
	const fx = next.fixtures.find((f) => f.hg === null && (f.homeId === next.teamId || f.awayId === next.teamId));
	if (fx) {
		fx.hg = hg;
		fx.ag = ag;
	}
	for (const f of next.fixtures) {
		if (f.hg !== null) continue;
		if (f.homeId === next.teamId || f.awayId === next.teamId) continue;
		const [h, a] = simScore(teamById(f.homeId), teamById(f.awayId));
		f.hg = h;
		f.ag = a;
	}
	next.week += 1;
	return next;
}
function KitBadge({ team, size = 44 }) {
	const stripe = team.pattern === "stripe";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "relative inline-flex shrink-0 items-center justify-center overflow-hidden rounded-lg border border-border",
		style: {
			width: size,
			height: size,
			background: team.primary
		},
		"aria-hidden": true,
		children: [stripe ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "absolute inset-y-0 left-1/3 w-1/3",
			style: { background: team.secondary }
		}) : team.pattern === "sash" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "absolute h-[140%] w-2 -rotate-45",
			style: { background: team.secondary }
		}) : team.pattern === "hoop" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "absolute inset-x-0 top-1/3 h-1/4",
			style: { background: team.secondary }
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "relative text-[10px] font-semibold tracking-wide",
			style: { color: team.shorts === team.primary ? team.secondary : "#0b0c0e" },
			children: team.short
		})]
	});
}
function TouchStick({ onChange }) {
	const ref = (0, import_react.useRef)(null);
	const pid = (0, import_react.useRef)(null);
	const [knob, setKnob] = (0, import_react.useState)({
		x: 0,
		y: 0
	});
	const update = (e) => {
		const el = ref.current;
		if (!el) return;
		const r = el.getBoundingClientRect();
		const cx = r.left + r.width / 2;
		const cy = r.top + r.height / 2;
		let dx = e.clientX - cx;
		let dy = e.clientY - cy;
		const max = r.width * .38;
		const m = Math.hypot(dx, dy);
		if (m > max) {
			dx = dx / m * max;
			dy = dy / m * max;
		}
		setKnob({
			x: dx,
			y: dy
		});
		onChange(dx / max, dy / max);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref,
		className: "relative h-28 w-28 touch-none rounded-full border border-border bg-surface/70",
		onPointerDown: (e) => {
			pid.current = e.pointerId;
			e.currentTarget.setPointerCapture(e.pointerId);
			update(e);
		},
		onPointerMove: (e) => {
			if (pid.current !== e.pointerId) return;
			update(e);
		},
		onPointerUp: (e) => {
			if (pid.current !== e.pointerId) return;
			pid.current = null;
			setKnob({
				x: 0,
				y: 0
			});
			onChange(0, 0);
		},
		onPointerCancel: () => {
			pid.current = null;
			setKnob({
				x: 0,
				y: 0
			});
			onChange(0, 0);
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "pointer-events-none absolute left-1/2 top-1/2 h-12 w-12 rounded-full bg-fg/80",
			style: { transform: `translate(calc(-50% + ${knob.x}px), calc(-50% + ${knob.y}px))` }
		})
	});
}
function ActionBtn({ label, onDown, onUp, accent }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: `h-14 min-w-14 touch-none rounded-full border px-3 text-center text-xs font-semibold uppercase tracking-wide ${accent ? "border-primary bg-primary text-primary-fg" : "border-border bg-surface/80 text-fg"}`,
		onPointerDown: (e) => {
			e.preventDefault();
			e.currentTarget.setPointerCapture(e.pointerId);
			onDown();
		},
		onPointerUp: () => onUp?.(),
		onPointerCancel: () => onUp?.(),
		children: label
	});
}
function GameRoot() {
	const canvasRef = (0, import_react.useRef)(null);
	const engineRef = (0, import_react.useRef)(null);
	const [screen, setScreen] = (0, import_react.useState)("boot");
	const [settings, setSettings] = (0, import_react.useState)(defaultSettings);
	const [career, setCareer] = (0, import_react.useState)(null);
	const [homeId, setHomeId] = (0, import_react.useState)(TEAMS[0].id);
	const [awayId, setAwayId] = (0, import_react.useState)(TEAMS[1].id);
	const [paused, setPaused] = (0, import_react.useState)(false);
	const [result, setResult] = (0, import_react.useState)(null);
	const [userHome, setUserHome] = (0, import_react.useState)(true);
	const fromCareerRef = (0, import_react.useRef)(false);
	const [ready, setReady] = (0, import_react.useState)(false);
	const home = teamById(homeId);
	const away = teamById(awayId);
	(0, import_react.useEffect)(() => {
		setSettings(loadSettings());
		setCareer(loadCareer());
		setReady(true);
	}, []);
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const a = TEAMS[0];
		const b = TEAMS[3];
		const eng = new GameEngine(canvas, a, b);
		engineRef.current = eng;
		eng.startDemo(a, otherTeam(a.id));
		eng.shakeOn = settings.shake;
		eng.onPauseChange = (v) => setPaused(v);
		eng.onEnded = (m) => {
			setResult({
				home: m.home,
				away: m.away,
				score: [m.score[0], m.score[1]]
			});
			setScreen("result");
		};
		eng.attach();
		return () => eng.detach();
	}, []);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		saveSettings(settings);
		const eng = engineRef.current;
		if (!eng) return;
		eng.audio.setMuted(settings.muted);
		eng.audio.setVolume(settings.volume);
		eng.shakeOn = settings.shake;
	}, [settings, ready]);
	const unlock = () => {
		engineRef.current?.audio.unlock();
		engineRef.current?.audio.setMuted(settings.muted);
		engineRef.current?.audio.setVolume(settings.volume);
		setScreen("menu");
	};
	const playMatch = (h, a, opts) => {
		const eng = engineRef.current;
		if (!eng) return;
		eng.audio.ui();
		fromCareerRef.current = !!opts.fromCareer;
		eng.startLive(h, a, {
			userTeam: opts.userTeam,
			difficulty: settings.difficulty,
			practice: opts.practice,
			autoSwitch: settings.autoSwitch
		});
		setUserHome(opts.userTeam === 0);
		setPaused(false);
		setScreen("match");
		setResult(null);
	};
	const backToMenu = () => {
		const eng = engineRef.current;
		if (!eng) return;
		eng.audio.ui();
		fromCareerRef.current = false;
		eng.startDemo(teamById(homeId), teamById(awayId));
		eng.paused = false;
		setPaused(false);
		setScreen("menu");
	};
	const finishCareerMatch = () => {
		if (!result || !career) {
			backToMenu();
			return;
		}
		const next = applyUserResult(career, result.score[0], result.score[1]);
		setCareer(next);
		saveCareer(next);
		fromCareerRef.current = false;
		setScreen("career");
		engineRef.current?.startDemo(teamById(next.teamId), otherTeam(next.teamId));
	};
	const table = (0, import_react.useMemo)(() => career ? standings(career) : [], [career]);
	const nextFx = career ? nextUserFixture(career) : null;
	const live = engineRef.current?.match;
	const fromCareer = fromCareerRef.current;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative h-dvh w-full overflow-hidden bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: canvasRef,
				className: "absolute inset-0 h-full w-full touch-none"
			}),
			screen === "boot" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute inset-0 z-20 flex flex-col items-center justify-center bg-bg/80 px-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-[0.35em] text-muted",
						children: "Football Club"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "mt-3 font-display text-6xl font-semibold tracking-tight text-fg md:text-7xl",
						children: ["FC ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-primary",
							children: "28"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: unlock,
						className: "mt-10 min-h-12 rounded-xl bg-fg px-8 text-sm font-semibold tracking-wide text-bg",
						children: "Tap to play"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 max-w-xs text-center text-xs leading-relaxed text-faint",
						children: "Runs entirely on this device. No internet, no extra pages."
					})
				]
			}),
			screen === "menu" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 z-10 flex flex-col justify-end bg-gradient-to-t from-bg via-bg/80 to-transparent p-5 pb-8 md:justify-center md:bg-none md:p-10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "md:max-w-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium uppercase tracking-[0.35em] text-muted",
							children: "Football Club"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "mt-2 font-display text-5xl font-semibold tracking-tight",
							children: ["FC ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-primary",
								children: "28"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
							className: "mt-8 flex flex-col gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuBtn, {
									label: "Kick Off",
									hint: "Pick sides and play",
									onClick: () => setScreen("kickoff")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuBtn, {
									label: "Career",
									hint: "Season with your club",
									onClick: () => setScreen(career ? "career" : "career-pick")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuBtn, {
									label: "Practice",
									hint: "Free play, no clock",
									onClick: () => playMatch(home, away, {
										userTeam: 0,
										practice: true
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuBtn, {
									label: "Settings",
									hint: "Audio, difficulty, camera",
									onClick: () => setScreen("settings"),
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "size-4" })
								})
							]
						})
					]
				})
			}),
			screen === "kickoff" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				title: "Kick Off",
				onBack: () => setScreen("menu"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-6 md:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeamPicker, {
						label: "You",
						selected: homeId,
						onPick: setHomeId
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeamPicker, {
						label: "Opponent",
						selected: awayId,
						onPick: setAwayId
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "mt-6 min-h-12 w-full rounded-xl bg-fg text-sm font-semibold text-bg",
					onClick: () => playMatch(home, away, { userTeam: 0 }),
					children: "Enter match"
				})]
			}),
			screen === "career-pick" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "Choose club",
				onBack: () => setScreen("menu"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 gap-2 sm:grid-cols-3",
					children: TEAMS.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							const c = newCareer(t.id);
							setCareer(c);
							saveCareer(c);
							setHomeId(t.id);
							setScreen("career");
						},
						className: "flex min-h-16 items-center gap-3 rounded-xl border border-border bg-surface-2 px-3 text-left",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KitBadge, { team: t }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-sm font-medium",
							children: t.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs text-muted",
							children: [t.rating, " OVR"]
						})] })]
					}, t.id))
				})
			}),
			screen === "career" && career && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				title: "Career",
				onBack: () => setScreen("menu"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-4 flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KitBadge, {
							team: teamById(career.teamId),
							size: 52
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-lg font-semibold",
							children: teamById(career.teamId).name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted",
							children: [
								"Week ",
								Math.min(career.week + 1, 11),
								" · ",
								table.find((r) => r.id === career.teamId)?.pts ?? 0,
								" pts"
							]
						})] })]
					}),
					nextFx ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-border bg-surface-2 p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-wide text-muted",
								children: "Next match"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-base font-medium",
								children: [
									teamById(nextFx.homeId).short,
									" vs ",
									teamById(nextFx.awayId).short
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "mt-4 min-h-12 w-full rounded-xl bg-fg text-sm font-semibold text-bg",
								onClick: () => {
									const uh = nextFx.homeId === career.teamId ? 0 : 1;
									playMatch(teamById(nextFx.homeId), teamById(nextFx.awayId), {
										userTeam: uh,
										fromCareer: true
									});
								},
								children: "Play match"
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rounded-xl border border-border bg-surface-2 p-4 text-sm text-muted",
						children: "Season complete."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 overflow-hidden rounded-xl border border-border",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full text-left text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "bg-surface-2 text-xs uppercase tracking-wide text-muted",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 font-medium",
										children: "Club"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-2 py-2 font-medium",
										children: "P"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-2 py-2 font-medium",
										children: "GD"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 font-medium",
										children: "Pts"
									})
								] })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: table.map((row, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: row.id === career.teamId ? "bg-primary/15 text-fg" : "text-muted",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "px-3 py-1.5",
										children: [
											i + 1,
											". ",
											row.team.short
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-1.5 tabular-nums",
										children: row.p
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-2 py-1.5 tabular-nums",
										children: row.gd
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3 py-1.5 font-medium tabular-nums text-fg",
										children: row.pts
									})
								]
							}, row.id)) })]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "mt-4 text-xs text-muted underline-offset-4 hover:text-fg",
						onClick: () => {
							clearCareer();
							setCareer(null);
							setScreen("career-pick");
						},
						children: "New career"
					})
				]
			}),
			screen === "settings" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				title: "Settings",
				onBack: () => setScreen("menu"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center justify-between gap-4 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm",
							children: "Audio"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "rounded-lg border border-border bg-surface-2 p-2",
							onClick: () => setSettings((s) => ({
								...s,
								muted: !s.muted
							})),
							"aria-label": settings.muted ? "Unmute" : "Mute",
							children: settings.muted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-4" })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center justify-between gap-4 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm",
							children: "Volume"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "range",
							min: 0,
							max: 1,
							step: .05,
							value: settings.volume,
							onChange: (e) => setSettings((s) => ({
								...s,
								volume: Number(e.target.value)
							})),
							className: "w-40 accent-primary"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center justify-between gap-4 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm",
							children: "Screen shake"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
							on: settings.shake,
							onChange: (v) => setSettings((s) => ({
								...s,
								shake: v
							}))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center justify-between gap-4 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm",
							children: "Auto switch"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
							on: settings.autoSwitch,
							onChange: (v) => setSettings((s) => ({
								...s,
								autoSwitch: v
							}))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-2 text-sm",
							children: "Difficulty"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-3 gap-2",
							children: [
								"amateur",
								"pro",
								"world"
							].map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setSettings((s) => ({
									...s,
									difficulty: d
								})),
								className: `min-h-11 rounded-lg border text-xs font-medium capitalize ${settings.difficulty === d ? "border-fg bg-fg text-bg" : "border-border bg-surface-2 text-fg"}`,
								children: d === "world" ? "World class" : d
							}, d))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-xs leading-relaxed text-faint",
						children: "Move WASD or stick · Sprint Shift · Pass Space/J · Through K · Shoot hold L · Switch E · Tackle Ctrl"
					})
				]
			}),
			screen === "match" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "absolute right-3 top-3 z-10 flex size-11 items-center justify-center rounded-xl border border-border bg-surface/80 text-fg",
					onClick: () => {
						const eng = engineRef.current;
						if (eng) {
							eng.paused = true;
							setPaused(true);
						}
					},
					"aria-label": "Pause",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pointer-events-none absolute bottom-3 left-0 right-0 z-10 hidden px-4 text-center text-[11px] text-muted md:block",
					children: "WASD move · Shift sprint · J pass · K through · Hold L shoot · E switch · Ctrl tackle"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute inset-x-0 bottom-4 z-10 flex items-end justify-between px-4 md:hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TouchStick, { onChange: (x, y) => {
						const eng = engineRef.current;
						if (!eng) return;
						eng.input.stickX = x;
						eng.input.stickY = y;
					} }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-3 gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionBtn, {
								label: "Spr",
								onDown: () => {
									if (engineRef.current) engineRef.current.input.touch.sprint = true;
								},
								onUp: () => {
									if (engineRef.current) engineRef.current.input.touch.sprint = false;
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionBtn, {
								label: "Sw",
								onDown: () => {
									if (engineRef.current) engineRef.current.input.touch.switchP = true;
								},
								onUp: () => {
									if (engineRef.current) engineRef.current.input.touch.switchP = false;
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionBtn, {
								label: "Tkl",
								onDown: () => {
									if (engineRef.current) engineRef.current.input.touch.tackle = true;
								},
								onUp: () => {
									if (engineRef.current) engineRef.current.input.touch.tackle = false;
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionBtn, {
								label: "Thru",
								onDown: () => {
									if (engineRef.current) engineRef.current.input.touch.through = true;
								},
								onUp: () => {
									if (engineRef.current) engineRef.current.input.touch.through = false;
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionBtn, {
								label: "Pass",
								onDown: () => {
									if (engineRef.current) engineRef.current.input.touch.pass = true;
								},
								onUp: () => {
									if (engineRef.current) engineRef.current.input.touch.pass = false;
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionBtn, {
								label: "Shot",
								accent: true,
								onDown: () => {
									if (engineRef.current) engineRef.current.input.touch.shoot = true;
								},
								onUp: () => {
									if (engineRef.current) engineRef.current.input.touch.shoot = false;
								}
							})
						]
					})]
				}),
				paused && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute inset-0 z-20 flex items-center justify-center bg-bg/70 p-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "w-full max-w-sm rounded-3xl border border-border bg-surface p-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-xl font-semibold",
								children: "Paused"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted",
								children: live ? `${live.home.short} ${live.score[0]} – ${live.score[1]} ${live.away.short}` : ""
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-6 flex flex-col gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "min-h-12 rounded-xl bg-fg text-sm font-semibold text-bg",
									onClick: () => {
										if (engineRef.current) engineRef.current.paused = false;
										setPaused(false);
									},
									children: "Resume"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "min-h-12 rounded-xl border border-border text-sm font-medium",
									onClick: backToMenu,
									children: "Quit to menu"
								})]
							})
						]
					})
				})
			] }),
			screen === "result" && result && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 z-20 flex items-center justify-center bg-bg/75 p-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-md rounded-3xl border border-border bg-surface p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-[0.25em] text-muted",
							children: "Full time"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex items-center justify-between gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KitBadge, { team: result.home }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm font-medium",
										children: result.home.short
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "font-display text-3xl font-semibold tabular-nums",
									children: [
										result.score[0],
										" – ",
										result.score[1]
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm font-medium",
										children: result.away.short
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KitBadge, { team: result.away })]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-center text-sm text-muted",
							children: (() => {
								const you = userHome ? result.score[0] : result.score[1];
								const them = userHome ? result.score[1] : result.score[0];
								if (you > them) return "Win";
								if (you < them) return "Defeat";
								return "Draw";
							})()
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 flex flex-col gap-2",
							children: [fromCareer && career ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "min-h-12 rounded-xl bg-fg text-sm font-semibold text-bg",
								onClick: finishCareerMatch,
								children: "Save to career"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "min-h-12 rounded-xl bg-fg text-sm font-semibold text-bg",
								onClick: backToMenu,
								children: "Menu"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "min-h-12 rounded-xl border border-border text-sm font-medium",
								onClick: () => playMatch(result.home, result.away, {
									userTeam: userHome ? 0 : 1,
									fromCareer
								}),
								children: "Replay"
							})]
						})
					]
				})
			})
		]
	});
}
function MenuBtn({ label, hint, onClick, icon }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: "flex min-h-14 items-center justify-between rounded-2xl border border-border bg-surface/85 px-4 text-left",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "block text-sm font-semibold",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs text-muted",
			children: hint
		})] }), icon ?? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4 text-muted" })]
	});
}
function Panel({ title, onBack, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "absolute inset-0 z-10 overflow-y-auto bg-bg/92 p-4 md:p-8",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-3xl pb-10",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-6 flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onBack,
					className: "flex size-11 items-center justify-center rounded-xl border border-border bg-surface",
					"aria-label": "Back",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl font-semibold",
					children: title
				})]
			}), children]
		})
	});
}
function TeamPicker({ label, selected, onPick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mb-2 text-xs uppercase tracking-wide text-muted",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid max-h-72 grid-cols-1 gap-1 overflow-y-auto pr-1",
		children: TEAMS.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => onPick(t.id),
			className: `flex min-h-12 items-center gap-3 rounded-xl border px-3 text-left ${selected === t.id ? "border-fg bg-fg text-bg" : "border-border bg-surface-2"}`,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KitBadge, {
					team: t,
					size: 36
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "flex-1 text-sm font-medium",
					children: t.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs tabular-nums opacity-70",
					children: t.rating
				})
			]
		}, t.id))
	})] });
}
function Toggle({ on, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		role: "switch",
		"aria-checked": on,
		onClick: () => onChange(!on),
		className: `h-7 w-12 rounded-full border border-border p-0.5 ${on ? "bg-primary" : "bg-surface-2"}`,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `block size-6 rounded-full bg-fg transition-transform ${on ? "translate-x-5" : ""}` })
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameRoot, {});
}
//#endregion
export { Home as component };
