import { Et as array, Ft as string, Mt as object, jt as number, kt as literal, wt as _enum } from "../_libs/@better-auth/core+[...].mjs";
import { r as getSql } from "./db-tLzPr0oC.mjs";
import { i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { t as authMiddleware } from "./middleware-BmVBojIc.mjs";
import { f as jalaliYearOf, g as uid, h as todayIso, o as fiscalBounds, p as padSeq } from "./format-c9GA3s0l.mjs";
import { a as splitBalance, i as buildJournalLines, n as CHART, r as CODES, t as AccountingError } from "./engine-DpqNPzjs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/actions-Diqky2eM.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function num(v) {
	if (v == null || v === "") return 0;
	const n = typeof v === "number" ? v : Number(v);
	return Number.isFinite(n) ? n : 0;
}
function fail(e) {
	if (e instanceof AccountingError) throw e;
	throw e;
}
async function loadBooks(sql, userId) {
	const accounts = await sql`select * from accounts where user_id = ${userId}`;
	const cash = await sql`select * from cash_accounts where user_id = ${userId}`;
	const accountsById = /* @__PURE__ */ new Map();
	const accountsByCode = /* @__PURE__ */ new Map();
	for (const a of accounts) {
		const row = {
			id: a.id,
			code: a.code,
			name: a.name,
			level: a.level,
			parentId: a.parent_id,
			groupCode: a.group_code,
			nature: a.nature,
			isPostable: a.is_postable,
			isActive: a.is_active,
			floatingType: a.floating_type
		};
		accountsById.set(row.id, row);
		accountsByCode.set(row.code, row);
	}
	const cashById = /* @__PURE__ */ new Map();
	for (const c of cash) cashById.set(c.id, {
		id: c.id,
		accountId: c.account_id,
		name: c.name,
		kind: c.kind,
		bankName: c.bank_name,
		accountNumber: c.account_number,
		isActive: c.is_active
	});
	return {
		accountsById,
		accountsByCode,
		cashById
	};
}
async function audit(sql, userId, action, entity, entityId, extra) {
	await sql`insert into audit_logs (id, user_id, actor_id, actor_name, action, entity, entity_id, old_value, new_value, reason)
    values (${uid()}, ${userId}, ${userId}, ${extra?.actorName ?? null}, ${action}, ${entity}, ${entityId ?? null},
      ${extra?.old ? JSON.stringify(extra.old) : null}, ${extra?.next ? JSON.stringify(extra.next) : null}, ${extra?.reason ?? null})`;
}
async function currentFy(sql, userId) {
	const rows = await sql`select * from fiscal_years where user_id = ${userId} and is_current = true limit 1`;
	if (!rows[0]) throw new AccountingError("سال مالی فعال یافت نشد.");
	return rows[0];
}
async function ensureDay(sql, userId, fyId, date) {
	const existing = await sql`
    select id, status from fiscal_days where user_id = ${userId} and day_date = ${date}::date`;
	if (existing[0]) return existing[0];
	const id = uid();
	await sql`insert into fiscal_days (id, user_id, fiscal_year_id, day_date, status)
    values (${id}, ${userId}, ${fyId}, ${date}::date, 'open')`;
	return {
		id,
		status: "open"
	};
}
function assertDateInFy(date, fy) {
	if (date < fy.start_date || date > fy.end_date) throw new AccountingError("تاریخ خارج از سال مالی جاری است.");
}
async function insertPosted(sql, userId, input, journalType) {
	const fy = await currentFy(sql, userId);
	assertDateInFy(input.date, fy);
	const day = await ensureDay(sql, userId, fy.id, input.date);
	if (day.status === "closed" && journalType !== "adjustment" && journalType !== "reversal") throw new AccountingError("این روز بسته است. اصلاح فقط با سند اصلاحی مجاز است.");
	const books = await loadBooks(sql, userId);
	const lines = buildJournalLines(input, books);
	const opId = uid();
	const jvId = uid();
	const seqOp = await sql`
    update sequences set last_value = last_value + 1
    where user_id = ${userId} and fiscal_year_id = ${fy.id} and kind = 'op'
    returning last_value`;
	const seqJv = await sql`
    update sequences set last_value = last_value + 1
    where user_id = ${userId} and fiscal_year_id = ${fy.id} and kind = 'jv'
    returning last_value`;
	const opNo = `OP-${fy.code}-${padSeq(seqOp[0]?.last_value ?? 1)}`;
	const jvNo = `JV-${fy.code}-${padSeq(seqJv[0]?.last_value ?? 1)}`;
	const extra = JSON.stringify({
		checkNumber: input.checkNumber,
		checkDueDate: input.checkDueDate,
		checkBankName: input.checkBankName,
		cashPortion: input.cashPortion,
		cogsAmount: input.cogsAmount,
		freightAmount: input.freightAmount
	});
	if (lines.reduce((s, l) => s + l.debit, 0) !== lines.reduce((s, l) => s + l.credit, 0)) throw new AccountingError("کنترل توازن ناموفق بود.");
	const lineJson = JSON.stringify(lines.map((l, i) => ({
		id: uid(),
		line_no: i + 1,
		account_id: l.accountId,
		party_id: l.partyId ?? "",
		cash_account_id: l.cashAccountId ?? "",
		debit: l.debit,
		credit: l.credit,
		description: l.description ?? input.description ?? ""
	})));
	await sql.query(`with ins_op as (
        insert into operations (id, user_id, fiscal_year_id, day_id, number, op_type, op_date, description, party_id,
          cash_account_id, dest_cash_account_id, amount, status, journal_id, original_id, extra_json, created_by)
        values ($1,$2,$3,$4,$5,$6,$7::date,$8,$9,$10,$11,$12,'posted',$13,$14,$15,$2)
        returning id
      ),
      ins_jv as (
        insert into journals (id, user_id, fiscal_year_id, day_id, number, journal_date, description, journal_type,
          operation_id, original_journal_id, status, created_by)
        values ($13,$2,$3,$4,$16,$7::date,$8,$17,$1,$18,'posted',$2)
        returning id
      ),
      ins_lines as (
        insert into journal_lines (id, user_id, journal_id, line_no, account_id, party_id, cash_account_id, debit, credit, description)
        select x.id, $2, $13, x.line_no, x.account_id, nullif(x.party_id, ''), nullif(x.cash_account_id, ''), x.debit, x.credit, x.description
        from json_to_recordset($19::json) as x(id text, line_no int, account_id text, party_id text, cash_account_id text, debit numeric, credit numeric, description text)
        returning id
      )
      select 1`, [
		opId,
		userId,
		fy.id,
		day.id,
		opNo,
		input.opType,
		input.date,
		input.description || null,
		input.partyId || null,
		input.cashAccountId || null,
		input.destCashAccountId || null,
		amt(input),
		jvId,
		input.originalId || null,
		extra,
		jvNo,
		journalType,
		input.originalId || null,
		lineJson
	]);
	if (input.opType === "check_receive" || input.opType === "check_pay") await sql`insert into checks (id, user_id, number, kind, party_id, bank_name, amount, issue_date, due_date, status, operation_id)
      values (${uid()}, ${userId}, ${input.checkNumber || opNo}, ${input.opType === "check_receive" ? "receivable" : "payable"},
        ${input.partyId || null}, ${input.checkBankName || null}, ${amt(input)}, ${input.date}::date,
        ${input.checkDueDate || input.date}::date, ${input.opType === "check_receive" ? "in_hand" : "issued"}, ${opId})`;
	await audit(sql, userId, "Create", "operation", opId, { next: {
		opNo,
		jvNo,
		type: input.opType,
		amount: amt(input)
	} });
	return {
		operationId: opId,
		journalId: jvId,
		operationNumber: opNo,
		journalNumber: jvNo,
		lines
	};
}
function amt(input) {
	if (input.lines?.length) return input.lines.reduce((s, l) => s + l.debit, 0);
	return Math.round(input.amount || 0);
}
async function seedIfNeeded(sql, userId) {
	if ((await sql`select seeded from company_settings where user_id = ${userId}`)[0]?.seeded) {
		await ensureDay(sql, userId, (await currentFy(sql, userId)).id, todayIso());
		return;
	}
	await sql`delete from journal_lines where user_id = ${userId}`;
	await sql`delete from journals where user_id = ${userId}`;
	await sql`delete from operations where user_id = ${userId}`;
	await sql`delete from checks where user_id = ${userId}`;
	await sql`delete from daily_closings where user_id = ${userId}`;
	await sql`delete from fiscal_days where user_id = ${userId}`;
	await sql`delete from sequences where user_id = ${userId}`;
	await sql`delete from cash_accounts where user_id = ${userId}`;
	await sql`delete from parties where user_id = ${userId}`;
	await sql`delete from accounts where user_id = ${userId}`;
	await sql`delete from fiscal_years where user_id = ${userId}`;
	const today = todayIso();
	const year = jalaliYearOf(today);
	const bounds = fiscalBounds(year);
	const fyId = uid();
	await sql`insert into company_settings (user_id, company_name, company_name_en, seeded)
    values (${userId}, 'بازرگانی خراسانی', 'MR,KHORASANI', false)
    on conflict (user_id) do nothing`;
	await sql`insert into fiscal_years (id, user_id, code, name, start_date, end_date, status, is_current)
    values (${fyId}, ${userId}, ${String(year)}, ${"سال مالی " + year}, ${bounds.start}::date, ${bounds.end}::date, 'open', true)`;
	await sql`insert into sequences (user_id, fiscal_year_id, kind, last_value) values
    (${userId}, ${fyId}, 'op', 0), (${userId}, ${fyId}, 'jv', 0)`;
	const idByCode = /* @__PURE__ */ new Map();
	for (const def of CHART) {
		const id = uid();
		idByCode.set(def.code, id);
		const parent = def.parent ? idByCode.get(def.parent) ?? null : null;
		await sql`insert into accounts (id, user_id, code, name, level, parent_id, group_code, nature, is_postable, is_active, floating_type)
      values (${id}, ${userId}, ${def.code}, ${def.name}, ${def.level}, ${parent}, ${def.group}, ${def.nature},
        ${Boolean(def.postable)}, true, ${def.floating ?? "none"})`;
	}
	const cashId = uid();
	const bank1 = uid();
	const bank2 = uid();
	const petty = uid();
	await sql`insert into cash_accounts (id, user_id, account_id, name, kind, bank_name, account_number) values
    (${cashId}, ${userId}, ${idByCode.get(CODES.CASH)}, 'صندوق اصلی', 'cash', null, null),
    (${bank1}, ${userId}, ${idByCode.get(CODES.BANK_MELI)}, 'بانک ملی — جاری شرکت', 'bank', 'بانک ملی', '۰۱۰۸۴۲۲۹۳۳'),
    (${bank2}, ${userId}, ${idByCode.get(CODES.BANK_MELLAT)}, 'بانک ملت — جاری شرکت', 'bank', 'بانک ملت', '۴۵۷۸۱۲۳۰۰۱'),
    (${petty}, ${userId}, ${idByCode.get(CODES.PETTY)}, 'تنخواه گردان دفتر', 'petty', null, null)`;
	const parties = [
		{
			id: uid(),
			code: "C-001",
			name: "فروشگاه زنجیره‌ای سپهر",
			kind: "customer",
			phone: "021-88901234",
			address: "تهران، سعادت‌آباد"
		},
		{
			id: uid(),
			code: "C-002",
			name: "شرکت آریا صنعت",
			kind: "customer",
			phone: "021-44556677",
			address: "کرج، شهرک صنعتی"
		},
		{
			id: uid(),
			code: "C-003",
			name: "بازرگانی پارس کالا",
			kind: "customer",
			phone: "031-32221100",
			address: "اصفهان"
		},
		{
			id: uid(),
			code: "C-004",
			name: "کلینیک نور",
			kind: "customer",
			phone: "021-22001122",
			address: "تهران، نیاوران"
		},
		{
			id: uid(),
			code: "S-001",
			name: "صنایع کاسپین",
			kind: "supplier",
			phone: "013-33334455",
			address: "رشت"
		},
		{
			id: uid(),
			code: "S-002",
			name: "پخش البرز",
			kind: "supplier",
			phone: "026-33550011",
			address: "کرج"
		},
		{
			id: uid(),
			code: "E-001",
			name: "واحد منابع انسانی",
			kind: "employee",
			phone: "021-1000",
			address: "دفتر مرکزی"
		},
		{
			id: uid(),
			code: "H-001",
			name: "شریک — خراسانی",
			kind: "shareholder",
			phone: "021-1001",
			address: "دفتر مرکزی"
		}
	];
	for (const p of parties) await sql`insert into parties (id, user_id, code, name, kind, phone, address) values
      (${p.id}, ${userId}, ${p.code}, ${p.name}, ${p.kind}, ${p.phone}, ${p.address})`;
	const cust = (code) => parties.find((p) => p.code === code).id;
	const shift = (n) => {
		const d = /* @__PURE__ */ new Date();
		d.setDate(d.getDate() + n);
		const z = (v) => String(v).padStart(2, "0");
		return `${d.getFullYear()}-${z(d.getMonth() + 1)}-${z(d.getDate())}`;
	};
	const post = (input, jt = "auto") => insertPosted(sql, userId, input, jt);
	await post({
		opType: "opening",
		date: bounds.start < today ? bounds.start : today,
		amount: 0,
		description: "سند افتتاحیه سال مالی — مانده حساب‌های دائمی",
		lines: [
			{
				accountId: idByCode.get(CODES.CASH),
				debit: 8e7,
				credit: 0,
				cashAccountId: cashId
			},
			{
				accountId: idByCode.get(CODES.BANK_MELI),
				debit: 35e8,
				credit: 0,
				cashAccountId: bank1
			},
			{
				accountId: idByCode.get(CODES.BANK_MELLAT),
				debit: 12e8,
				credit: 0,
				cashAccountId: bank2
			},
			{
				accountId: idByCode.get(CODES.PETTY),
				debit: 2e7,
				credit: 0,
				cashAccountId: petty
			},
			{
				accountId: idByCode.get(CODES.INVENTORY),
				debit: 8e8,
				credit: 0
			},
			{
				accountId: idByCode.get(CODES.AR),
				debit: 15e7,
				credit: 0,
				partyId: cust("C-001")
			},
			{
				accountId: idByCode.get(CODES.AP),
				debit: 0,
				credit: 9e7,
				partyId: cust("S-001")
			},
			{
				accountId: idByCode.get(CODES.CAPITAL),
				debit: 0,
				credit: 566e7
			}
		]
	}, "opening");
	await post({
		opType: "sale_cash",
		date: shift(-9),
		amount: 42e6,
		description: "فروش نقدی فاکتور ۱۲۴۰",
		cashAccountId: cashId,
		partyId: cust("C-004")
	});
	await post({
		opType: "sale_credit",
		date: shift(-8),
		amount: 186e6,
		description: "فروش نسیه فاکتور ۱۲۴۱",
		partyId: cust("C-001")
	});
	await post({
		opType: "purchase_credit",
		date: shift(-8),
		amount: 95e6,
		description: "خرید کالا از کاسپین",
		partyId: cust("S-001")
	});
	await post({
		opType: "receipt",
		date: shift(-7),
		amount: 8e7,
		description: "دریافت بابت فاکتور قبلی",
		partyId: cust("C-001"),
		cashAccountId: bank1
	});
	await post({
		opType: "expense_cash",
		date: shift(-6),
		amount: 25e6,
		description: "اجاره دفتر مهر",
		cashAccountId: bank1,
		expenseAccountId: idByCode.get("610201")
	});
	await post({
		opType: "sale_mixed",
		date: shift(-5),
		amount: 12e7,
		cashPortion: 4e7,
		description: "فروش ترکیبی فاکتور ۱۲۴۴",
		partyId: cust("C-002"),
		cashAccountId: bank2
	});
	await post({
		opType: "payment",
		date: shift(-4),
		amount: 4e7,
		description: "پرداخت علی‌الحساب به کاسپین",
		partyId: cust("S-001"),
		cashAccountId: bank1
	});
	await post({
		opType: "transfer",
		date: shift(-3),
		amount: 15e6,
		description: "انتقال بانک ملی به صندوق",
		cashAccountId: bank1,
		destCashAccountId: cashId
	});
	await post({
		opType: "sale_cash",
		date: shift(-2),
		amount: 675e5,
		description: "فروش بانکی فاکتور ۱۲۴۸",
		cashAccountId: bank2,
		partyId: cust("C-003")
	});
	await post({
		opType: "check_receive",
		date: shift(-2),
		amount: 5e7,
		description: "چک دریافتی سررسید ۱۰ روزه",
		partyId: cust("C-002"),
		checkNumber: "784512",
		checkDueDate: shift(10),
		checkBankName: "صادرات"
	});
	await post({
		opType: "petty_fund",
		date: shift(-1),
		amount: 8e6,
		description: "شارژ تنخواه",
		cashAccountId: cashId
	});
	await post({
		opType: "expense_cash",
		date: shift(-1),
		amount: 42e5,
		description: "قبض برق و اینترنت",
		cashAccountId: petty,
		expenseAccountId: idByCode.get("610301")
	});
	await post({
		opType: "sale_credit",
		date: today,
		amount: 98e6,
		description: "فروش نسیه امروز — فاکتور ۱۲۵۰",
		partyId: cust("C-003")
	});
	await post({
		opType: "receipt",
		date: today,
		amount: 35e6,
		description: "دریافت نقدی از کلینیک نور",
		partyId: cust("C-004"),
		cashAccountId: cashId
	});
	await post({
		opType: "purchase_cash",
		date: today,
		amount: 22e6,
		description: "خرید نقدی ملزومات",
		cashAccountId: bank1,
		partyId: cust("S-002")
	});
	await post({
		opType: "income",
		date: today,
		amount: 65e5,
		description: "درآمد خدمات مشاوره",
		cashAccountId: bank2,
		incomeAccountId: idByCode.get(CODES.SERVICES),
		partyId: cust("C-002")
	});
	await sql`update company_settings set seeded = true where user_id = ${userId}`;
	await audit(sql, userId, "Create", "fiscal_year", fyId, { next: {
		year,
		seeded: true
	} });
}
var postingSchema = object({
	opType: string(),
	date: string(),
	amount: number().optional().default(0),
	description: string().optional().default(""),
	partyId: string().optional(),
	cashAccountId: string().optional(),
	destCashAccountId: string().optional(),
	expenseAccountId: string().optional(),
	incomeAccountId: string().optional(),
	cogsAmount: number().optional(),
	cashPortion: number().optional(),
	discountAmount: number().optional(),
	freightAmount: number().optional(),
	checkNumber: string().optional(),
	checkDueDate: string().optional(),
	checkBankName: string().optional(),
	originalId: string().optional(),
	reason: string().optional(),
	lines: array(object({
		accountId: string(),
		debit: number(),
		credit: number(),
		partyId: string().nullable().optional(),
		cashAccountId: string().nullable().optional(),
		description: string().optional()
	})).optional()
});
var bootstrapCompany_createServerFn_handler = createServerRpc({
	id: "b17171d118c03f345380aefb6192cba4fc956da4ddacd432fd5ffc061e66d9d8",
	name: "bootstrapCompany",
	filename: "src/lib/accounting/actions.ts"
}, (opts) => bootstrapCompany.__executeServer(opts));
var bootstrapCompany = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(bootstrapCompany_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	await seedIfNeeded(sql, context.userId);
	const settings = await sql`
      select company_name, company_name_en from company_settings where user_id = ${context.userId}`;
	const fy = await currentFy(sql, context.userId);
	const day = await ensureDay(sql, context.userId, fy.id, todayIso());
	const accounts = await sql`
      select id, code, name, level, group_code, nature, is_postable, floating_type from accounts where user_id = ${context.userId} order by code`;
	const parties = await sql`
      select id, code, name, kind, phone, address, is_active from parties where user_id = ${context.userId} and is_active = true order by code`;
	const cash = await sql`
      select id, account_id, name, kind, bank_name, account_number from cash_accounts where user_id = ${context.userId} and is_active = true`;
	return {
		companyName: settings[0]?.company_name ?? "بازرگانی خراسانی",
		companyNameEn: settings[0]?.company_name_en ?? "MR,KHORASANI",
		fiscalYear: fy,
		today: todayIso(),
		todayStatus: day.status,
		accounts: accounts.map((a) => ({
			id: a.id,
			code: a.code,
			name: a.name,
			level: a.level,
			groupCode: a.group_code,
			nature: a.nature,
			isPostable: a.is_postable,
			floatingType: a.floating_type
		})),
		parties,
		cashAccounts: cash.map((c) => ({
			id: c.id,
			accountId: c.account_id,
			name: c.name,
			kind: c.kind,
			bankName: c.bank_name,
			accountNumber: c.account_number,
			isActive: true
		}))
	};
});
var postOperation_createServerFn_handler = createServerRpc({
	id: "2f40991a98b10c634c64ed969a544af2daf6495ab91d8b7102c2ed699ccdaff9",
	name: "postOperation",
	filename: "src/lib/accounting/actions.ts"
}, (opts) => postOperation.__executeServer(opts));
var postOperation = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((raw) => postingSchema.parse(raw)).handler(postOperation_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	await seedIfNeeded(sql, context.userId);
	try {
		const jt = data.opType === "manual" ? "manual" : data.opType === "adjustment" ? "adjustment" : data.opType === "reversal" ? "reversal" : "auto";
		return await insertPosted(sql, context.userId, data, jt);
	} catch (e) {
		fail(e);
	}
});
var previewJournal_createServerFn_handler = createServerRpc({
	id: "4f7a1315656d533e400176f69b676894af00f45e108949573d18ccfe09d41a56",
	name: "previewJournal",
	filename: "src/lib/accounting/actions.ts"
}, (opts) => previewJournal.__executeServer(opts));
var previewJournal = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((raw) => postingSchema.parse(raw)).handler(previewJournal_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	await seedIfNeeded(sql, context.userId);
	const books = await loadBooks(sql, context.userId);
	try {
		const lines = buildJournalLines(data, books);
		const debit = lines.reduce((s, l) => s + l.debit, 0);
		const credit = lines.reduce((s, l) => s + l.credit, 0);
		return {
			lines,
			debit,
			credit,
			balanced: debit === credit
		};
	} catch (e) {
		fail(e);
	}
});
var listOperations_createServerFn_handler = createServerRpc({
	id: "afc7e31cde469331850f487d32b31e6f375d1d96b512112a2706d452d0931087",
	name: "listOperations",
	filename: "src/lib/accounting/actions.ts"
}, (opts) => listOperations.__executeServer(opts));
var listOperations = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((raw) => object({
	from: string().optional(),
	to: string().optional(),
	opType: string().optional(),
	status: string().optional(),
	q: string().optional()
}).parse(raw ?? {})).handler(listOperations_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	await seedIfNeeded(sql, context.userId);
	const from = data.from || "1900-01-01";
	const to = data.to || "2100-01-01";
	const rows = await sql`select o.id, o.number, o.op_type, o.op_date::text, o.description, o.party_id, p.name as party_name,
        o.cash_account_id, o.dest_cash_account_id, o.amount::text, o.status, o.journal_id, j.number as journal_number,
        o.original_id, o.created_at::text, d.status as day_status
      from operations o
      left join parties p on p.id = o.party_id
      left join journals j on j.id = o.journal_id
      join fiscal_days d on d.id = o.day_id
      where o.user_id = ${context.userId}
        and o.op_date between ${from}::date and ${to}::date
        and (${data.opType ?? null}::text is null or o.op_type = ${data.opType ?? null})
        and (${data.status ?? null}::text is null or o.status = ${data.status ?? null})
      order by o.op_date desc, o.created_at desc
      limit 400`;
	const q = (data.q ?? "").trim();
	return rows.filter((r) => {
		if (!q) return true;
		return `${r.number} ${r.description ?? ""} ${r.party_name ?? ""} ${r.journal_number ?? ""} ${r.amount}`.toLowerCase().includes(q.toLowerCase());
	}).map((r) => ({
		id: r.id,
		number: r.number,
		opType: r.op_type,
		opDate: r.op_date,
		description: r.description,
		partyId: r.party_id,
		partyName: r.party_name,
		cashAccountId: r.cash_account_id,
		destCashAccountId: r.dest_cash_account_id,
		amount: num(r.amount),
		status: r.status,
		journalId: r.journal_id,
		journalNumber: r.journal_number,
		originalId: r.original_id,
		createdAt: r.created_at,
		dayStatus: r.day_status
	}));
});
var softDeleteOperation_createServerFn_handler = createServerRpc({
	id: "c7abc9a404128450aed6bc278d0f8101071be4baed60436d3ab188474c70114e",
	name: "softDeleteOperation",
	filename: "src/lib/accounting/actions.ts"
}, (opts) => softDeleteOperation.__executeServer(opts));
var softDeleteOperation = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((raw) => object({
	id: string(),
	reason: string().min(2)
}).parse(raw)).handler(softDeleteOperation_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const op = (await sql`
      select id, status, journal_id, day_id, number from operations where id = ${data.id} and user_id = ${context.userId}`)[0];
	if (!op) throw new AccountingError("عملیات یافت نشد.");
	if ((await sql`select status from fiscal_days where id = ${op.day_id} and user_id = ${context.userId}`)[0]?.status === "closed") throw new AccountingError("روز بسته است. حذف مستقیم مجاز نیست — از سند اصلاحی استفاده کنید.");
	if (op.status === "deleted") throw new AccountingError("این رکورد قبلاً حذف منطقی شده است.");
	await sql`update operations set status = 'deleted', deleted_at = now(), deleted_by = ${context.userId}, delete_reason = ${data.reason}
      where id = ${op.id} and user_id = ${context.userId}`;
	if (op.journal_id) await sql`update journals set status = 'deleted' where id = ${op.journal_id} and user_id = ${context.userId}`;
	await audit(sql, context.userId, "Delete", "operation", op.id, {
		old: {
			number: op.number,
			status: op.status
		},
		reason: data.reason
	});
	return { ok: true };
});
var reverseOperation_createServerFn_handler = createServerRpc({
	id: "767044ebf1177a667f0886068fb30316d1aece19b8f3ea59575fd5330fdba654",
	name: "reverseOperation",
	filename: "src/lib/accounting/actions.ts"
}, (opts) => reverseOperation.__executeServer(opts));
var reverseOperation = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((raw) => object({
	id: string(),
	reason: string().min(2)
}).parse(raw)).handler(reverseOperation_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	await seedIfNeeded(sql, context.userId);
	const op = (await sql`
      select id, journal_id, op_type, amount::text, description from operations where id = ${data.id} and user_id = ${context.userId}`)[0];
	if (!op?.journal_id) throw new AccountingError("سند مرتبط یافت نشد.");
	const lines = await sql`
      select account_id, party_id, cash_account_id, debit::text, credit::text, description from journal_lines
      where journal_id = ${op.journal_id} and user_id = ${context.userId} order by line_no`;
	const result = await insertPosted(sql, context.userId, {
		opType: "reversal",
		date: todayIso(),
		amount: num(op.amount),
		description: `برگشت ${op.description ?? ""} — ${data.reason}`,
		originalId: op.id,
		reason: data.reason,
		lines: lines.map((l) => ({
			accountId: l.account_id,
			debit: num(l.debit),
			credit: num(l.credit),
			partyId: l.party_id,
			cashAccountId: l.cash_account_id,
			description: l.description ?? void 0
		}))
	}, "reversal");
	await sql`update operations set status = 'reversed' where id = ${op.id} and user_id = ${context.userId}`;
	await audit(sql, context.userId, "Create Adjustment", "operation", result.operationId, {
		old: { original: op.id },
		reason: data.reason
	});
	return result;
});
var getDashboard_createServerFn_handler = createServerRpc({
	id: "6f3789d99d7c3c8ec8c34c7ac8b95ff3740fd585d26eebab0fcb516633690a81",
	name: "getDashboard",
	filename: "src/lib/accounting/actions.ts"
}, (opts) => getDashboard.__executeServer(opts));
var getDashboard = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getDashboard_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	await seedIfNeeded(sql, context.userId);
	const today = todayIso();
	const fy = await currentFy(sql, context.userId);
	const day = await ensureDay(sql, context.userId, fy.id, today);
	const bal = await sql`
      select a.code, a.name, a.nature, a.group_code, coalesce(sum(jl.debit),0)::text as debit, coalesce(sum(jl.credit),0)::text as credit
      from accounts a
      left join journal_lines jl on jl.account_id = a.id
      left join journals j on j.id = jl.journal_id and j.status = 'posted' and j.user_id = a.user_id
      where a.user_id = ${context.userId} and a.is_postable = true
      group by a.code, a.name, a.nature, a.group_code`;
	const byCode = Object.fromEntries(bal.map((b) => [b.code, num(b.debit) - num(b.credit)]));
	const cash = byCode[CODES.CASH] ?? 0;
	const bank = (byCode[CODES.BANK_MELI] ?? 0) + (byCode[CODES.BANK_MELLAT] ?? 0);
	const petty = byCode[CODES.PETTY] ?? 0;
	const ar = byCode[CODES.AR] ?? 0;
	const ap = -(byCode[CODES.AP] ?? 0);
	const notesRec = byCode[CODES.NOTES_REC] ?? 0;
	const notesPay = -(byCode[CODES.NOTES_PAY] ?? 0);
	const income = bal.filter((b) => b.group_code === "income").reduce((s, b) => s + (num(b.credit) - num(b.debit)), 0);
	const cogs = bal.filter((b) => b.group_code === "cogs").reduce((s, b) => s + (num(b.debit) - num(b.credit)), 0);
	const expense = bal.filter((b) => b.group_code === "expense").reduce((s, b) => s + (num(b.debit) - num(b.credit)), 0);
	const todayOps = await sql`
      select op_type, amount::text from operations
      where user_id = ${context.userId} and op_date = ${today}::date and status = 'posted'`;
	const sumType = (...types) => todayOps.filter((o) => types.includes(o.op_type)).reduce((s, o) => s + num(o.amount), 0);
	const salesToday = sumType("sale_cash", "sale_credit", "sale_mixed") - sumType("sale_return", "sale_discount");
	const receiptsToday = sumType("receipt", "receipt_other", "check_collect");
	const paymentsToday = sumType("payment", "payment_other");
	const expenseToday = sumType("expense_cash", "expense_payable", "payroll", "petty_settle");
	const series = await sql`
      select op_date::text as d, op_type, amount::text
      from operations
      where user_id = ${context.userId} and status = 'posted' and op_date >= (current_date - 13)
      order by op_date`;
	const byDay = {};
	for (let i = 13; i >= 0; i -= 1) {
		const dt = /* @__PURE__ */ new Date();
		dt.setDate(dt.getDate() - i);
		const z = (v) => String(v).padStart(2, "0");
		const key = `${dt.getFullYear()}-${z(dt.getMonth() + 1)}-${z(dt.getDate())}`;
		byDay[key] = {
			sales: 0,
			receipts: 0,
			payments: 0,
			expense: 0
		};
	}
	for (const r of series) {
		const bucket = byDay[r.d];
		if (!bucket) continue;
		const a = num(r.amount);
		if ([
			"sale_cash",
			"sale_credit",
			"sale_mixed"
		].includes(r.op_type)) bucket.sales += a;
		if (r.op_type === "sale_return") bucket.sales -= a;
		if ([
			"receipt",
			"receipt_other",
			"check_collect"
		].includes(r.op_type)) bucket.receipts += a;
		if (["payment", "payment_other"].includes(r.op_type)) bucket.payments += a;
		if ([
			"expense_cash",
			"expense_payable",
			"payroll"
		].includes(r.op_type)) bucket.expense += a;
	}
	const topAr = await sql`
      select p.name, coalesce(sum(jl.debit - jl.credit),0)::text as bal
      from parties p
      join journal_lines jl on jl.party_id = p.id
      join journals j on j.id = jl.journal_id and j.status = 'posted'
      join accounts a on a.id = jl.account_id and a.code = ${CODES.AR}
      where p.user_id = ${context.userId}
      group by p.name
      having coalesce(sum(jl.debit - jl.credit),0) > 0
      order by coalesce(sum(jl.debit - jl.credit),0) desc
      limit 5`;
	const topAp = await sql`
      select p.name, coalesce(sum(jl.credit - jl.debit),0)::text as bal
      from parties p
      join journal_lines jl on jl.party_id = p.id
      join journals j on j.id = jl.journal_id and j.status = 'posted'
      join accounts a on a.id = jl.account_id and a.code = ${CODES.AP}
      where p.user_id = ${context.userId}
      group by p.name
      having coalesce(sum(jl.credit - jl.debit),0) > 0
      order by coalesce(sum(jl.credit - jl.debit),0) desc
      limit 5`;
	return {
		today,
		todayStatus: day.status,
		fiscalYear: fy.code,
		cash,
		bank,
		petty,
		liquid: cash + bank + petty,
		ar,
		ap,
		notesRec,
		notesPay,
		salesToday,
		receiptsToday,
		paymentsToday,
		expenseToday,
		netCashToday: receiptsToday - paymentsToday - expenseToday,
		income,
		cogs,
		expense,
		gross: income - cogs,
		net: income - cogs - expense,
		series: Object.entries(byDay).map(([date, v]) => ({
			date,
			...v
		})),
		topDebtors: topAr.map((r) => ({
			name: r.name,
			amount: num(r.bal)
		})),
		topCreditors: topAp.map((r) => ({
			name: r.name,
			amount: num(r.bal)
		}))
	};
});
var getTrialBalance_createServerFn_handler = createServerRpc({
	id: "4176684392e6c0dc152c73a603699c26cc688bde4f9e7a22a76dc0d8efccad1c",
	name: "getTrialBalance",
	filename: "src/lib/accounting/actions.ts"
}, (opts) => getTrialBalance.__executeServer(opts));
var getTrialBalance = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((raw) => object({
	from: string(),
	to: string()
}).parse(raw ?? {
	from: "1900-01-01",
	to: "2100-01-01"
})).handler(getTrialBalance_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	await seedIfNeeded(sql, context.userId);
	const mapped = (await sql`select a.id, a.code, a.name, a.level, a.group_code, a.nature,
        coalesce(sum(case when j.journal_date < ${data.from}::date then jl.debit else 0 end),0)::text as open_d,
        coalesce(sum(case when j.journal_date < ${data.from}::date then jl.credit else 0 end),0)::text as open_c,
        coalesce(sum(case when j.journal_date between ${data.from}::date and ${data.to}::date then jl.debit else 0 end),0)::text as turn_d,
        coalesce(sum(case when j.journal_date between ${data.from}::date and ${data.to}::date then jl.credit else 0 end),0)::text as turn_c
      from accounts a
      left join journal_lines jl on jl.account_id = a.id
      left join journals j on j.id = jl.journal_id and j.status = 'posted' and j.user_id = a.user_id
      where a.user_id = ${context.userId} and a.is_postable = true
      group by a.id, a.code, a.name, a.level, a.group_code, a.nature
      order by a.code`).map((r) => {
		const openRaw = r.nature === "debit" ? num(r.open_d) - num(r.open_c) : num(r.open_c) - num(r.open_d);
		const open = splitBalance(r.nature, openRaw);
		const endRaw = r.nature === "debit" ? num(r.open_d) + num(r.turn_d) - num(r.open_c) - num(r.turn_c) : num(r.open_c) + num(r.turn_c) - num(r.open_d) - num(r.turn_d);
		const end = splitBalance(r.nature, endRaw);
		return {
			accountId: r.id,
			code: r.code,
			name: r.name,
			level: r.level,
			groupCode: r.group_code,
			openingDebit: open.debit,
			openingCredit: open.credit,
			turnoverDebit: num(r.turn_d),
			turnoverCredit: num(r.turn_c),
			balanceDebit: end.debit,
			balanceCredit: end.credit
		};
	});
	const totals = mapped.reduce((s, r) => {
		s.openingDebit += r.openingDebit;
		s.openingCredit += r.openingCredit;
		s.turnoverDebit += r.turnoverDebit;
		s.turnoverCredit += r.turnoverCredit;
		s.balanceDebit += r.balanceDebit;
		s.balanceCredit += r.balanceCredit;
		return s;
	}, {
		openingDebit: 0,
		openingCredit: 0,
		turnoverDebit: 0,
		turnoverCredit: 0,
		balanceDebit: 0,
		balanceCredit: 0
	});
	return {
		rows: mapped.filter((r) => r.openingDebit || r.openingCredit || r.turnoverDebit || r.turnoverCredit || r.balanceDebit || r.balanceCredit),
		totals,
		difference: totals.balanceDebit - totals.balanceCredit
	};
});
var getStatements_createServerFn_handler = createServerRpc({
	id: "d3ccb8c08da24132f8d986950a25b1b05fdcfc1dceb076f71ba68d0a94d4065c",
	name: "getStatements",
	filename: "src/lib/accounting/actions.ts"
}, (opts) => getStatements.__executeServer(opts));
var getStatements = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((raw) => object({
	from: string(),
	to: string()
}).parse(raw)).handler(getStatements_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	await seedIfNeeded(sql, context.userId);
	const rows = await sql`
      select a.code, a.name, a.group_code, a.nature, coalesce(sum(jl.debit),0)::text as d, coalesce(sum(jl.credit),0)::text as c
      from accounts a
      left join journal_lines jl on jl.account_id = a.id
      left join journals j on j.id = jl.journal_id and j.status = 'posted' and j.user_id = a.user_id
        and j.journal_date between ${data.from}::date and ${data.to}::date
      where a.user_id = ${context.userId} and a.is_postable = true
      group by a.code, a.name, a.group_code, a.nature
      order by a.code`;
	const pick = (g) => rows.filter((r) => r.group_code === g).map((r) => {
		const raw = r.nature === "credit" ? num(r.c) - num(r.d) : num(r.d) - num(r.c);
		return {
			code: r.code,
			name: r.name,
			amount: raw
		};
	}).filter((r) => r.amount !== 0);
	const asOf = await sql`
      select a.code, a.name, a.group_code, a.nature, coalesce(sum(jl.debit),0)::text as d, coalesce(sum(jl.credit),0)::text as c
      from accounts a
      left join journal_lines jl on jl.account_id = a.id
      left join journals j on j.id = jl.journal_id and j.status = 'posted' and j.user_id = a.user_id
        and j.journal_date <= ${data.to}::date
      where a.user_id = ${context.userId} and a.is_postable = true
      group by a.code, a.name, a.group_code, a.nature
      order by a.code`;
	const pickAsOf = (groups) => asOf.filter((r) => groups.includes(r.group_code)).map((r) => {
		const raw = r.nature === "credit" ? num(r.c) - num(r.d) : num(r.d) - num(r.c);
		return {
			code: r.code,
			name: r.name,
			amount: raw,
			group: r.group_code
		};
	}).filter((r) => r.amount !== 0);
	const income = pick("income");
	const cogs = pick("cogs");
	const expense = pick("expense");
	const incomeSum = income.reduce((s, r) => s + r.amount, 0);
	const cogsSum = cogs.reduce((s, r) => s + r.amount, 0);
	const expSum = expense.reduce((s, r) => s + r.amount, 0);
	const net = incomeSum - cogsSum - expSum;
	const ops = await sql`
      select op_type, amount::text from operations
      where user_id = ${context.userId} and status = 'posted' and op_date between ${data.from}::date and ${data.to}::date`;
	const sum = (...t) => ops.filter((o) => t.includes(o.op_type)).reduce((s, o) => s + num(o.amount), 0);
	return {
		pnl: {
			income,
			cogs,
			expense,
			incomeSum,
			cogsSum,
			expSum,
			gross: incomeSum - cogsSum,
			net
		},
		balanceSheet: {
			assets: pickAsOf(["asset", "contra"]),
			liabilities: pickAsOf(["liability"]),
			equity: pickAsOf(["equity"]),
			net
		},
		cashFlow: {
			receipts: sum("receipt", "receipt_other", "sale_cash", "check_collect", "income", "capital_in", "advance"),
			payments: sum("payment", "payment_other", "purchase_cash", "expense_cash", "payroll", "draw", "prepay"),
			transfers: sum("transfer", "petty_fund")
		}
	};
});
var getJournalBook_createServerFn_handler = createServerRpc({
	id: "65d6920c01932e71a936b1ce1e587c3f087b0275360337293cc85d0fe2ae67ba",
	name: "getJournalBook",
	filename: "src/lib/accounting/actions.ts"
}, (opts) => getJournalBook.__executeServer(opts));
var getJournalBook = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((raw) => object({
	from: string(),
	to: string(),
	accountId: string().optional()
}).parse(raw)).handler(getJournalBook_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	await seedIfNeeded(sql, context.userId);
	return (await sql`select j.id as journal_id, j.number, j.journal_date::text, j.description as jdesc, j.journal_type, j.status,
        jl.line_no, a.code, a.name as aname, p.name as party_name, jl.debit::text, jl.credit::text, jl.description as ldesc,
        o.number as op_number
      from journals j
      join journal_lines jl on jl.journal_id = j.id
      join accounts a on a.id = jl.account_id
      left join parties p on p.id = jl.party_id
      left join operations o on o.id = j.operation_id
      where j.user_id = ${context.userId}
        and j.journal_date between ${data.from}::date and ${data.to}::date
        and (${data.accountId ?? null}::text is null or jl.account_id = ${data.accountId ?? null})
      order by j.journal_date, j.number, jl.line_no`).map((r) => ({
		journalId: r.journal_id,
		number: r.number,
		date: r.journal_date,
		journalDescription: r.jdesc,
		journalType: r.journal_type,
		status: r.status,
		lineNo: r.line_no,
		accountCode: r.code,
		accountName: r.aname,
		partyName: r.party_name,
		debit: num(r.debit),
		credit: num(r.credit),
		lineDescription: r.ldesc,
		operationNumber: r.op_number
	}));
});
var getLedger_createServerFn_handler = createServerRpc({
	id: "9dfea3d1ac26375e364b9e3a9da5b2ea214ed03ca5070706cb8ee8feb0876598",
	name: "getLedger",
	filename: "src/lib/accounting/actions.ts"
}, (opts) => getLedger.__executeServer(opts));
var getLedger = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((raw) => object({
	accountId: string(),
	from: string(),
	to: string(),
	partyId: string().optional()
}).parse(raw)).handler(getLedger_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	await seedIfNeeded(sql, context.userId);
	const acc = await sql`
      select name, code, nature from accounts where id = ${data.accountId} and user_id = ${context.userId}`;
	if (!acc[0]) throw new AccountingError("حساب یافت نشد.");
	const open = await sql`
      select coalesce(sum(jl.debit),0)::text as d, coalesce(sum(jl.credit),0)::text as c
      from journal_lines jl join journals j on j.id = jl.journal_id
      where jl.user_id = ${context.userId} and j.status = 'posted' and jl.account_id = ${data.accountId}
        and j.journal_date < ${data.from}::date
        and (${data.partyId ?? null}::text is null or jl.party_id = ${data.partyId ?? null})`;
	const lines = await sql`select j.journal_date::text as date, j.number, coalesce(jl.description, j.description) as description,
        p.name as party_name, jl.debit::text, jl.credit::text
      from journal_lines jl
      join journals j on j.id = jl.journal_id
      left join parties p on p.id = jl.party_id
      where jl.user_id = ${context.userId} and j.status = 'posted' and jl.account_id = ${data.accountId}
        and j.journal_date between ${data.from}::date and ${data.to}::date
        and (${data.partyId ?? null}::text is null or jl.party_id = ${data.partyId ?? null})
      order by j.journal_date, j.number`;
	const openingRaw = acc[0].nature === "debit" ? num(open[0]?.d) - num(open[0]?.c) : num(open[0]?.c) - num(open[0]?.d);
	let running = acc[0].nature === "debit" ? num(open[0]?.d) - num(open[0]?.c) : num(open[0]?.c) - num(open[0]?.d);
	const mapped = lines.map((l) => {
		const d = num(l.debit);
		const c = num(l.credit);
		running += acc[0].nature === "debit" ? d - c : c - d;
		return {
			...l,
			debit: d,
			credit: c,
			balance: running
		};
	});
	return {
		account: acc[0],
		opening: openingRaw,
		lines: mapped,
		turnoverDebit: mapped.reduce((s, l) => s + l.debit, 0),
		turnoverCredit: mapped.reduce((s, l) => s + l.credit, 0),
		closing: running
	};
});
var getPartyCard_createServerFn_handler = createServerRpc({
	id: "d718e69966ba6e3609a08c87f1ea4a822452b158dcdaef57c063d2dee71b4095",
	name: "getPartyCard",
	filename: "src/lib/accounting/actions.ts"
}, (opts) => getPartyCard.__executeServer(opts));
var getPartyCard = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getPartyCard_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	await seedIfNeeded(sql, context.userId);
	return (await sql`select p.id, p.code, p.name, p.kind, p.phone, p.address,
        max(o.op_date)::text as last_date,
        count(distinct o.id)::int as op_count,
        coalesce(sum(case when o.op_type in ('sale_cash','sale_credit','sale_mixed') and o.status='posted' then o.amount else 0 end),0)::text as sales,
        coalesce(sum(case when o.op_type in ('purchase_cash','purchase_credit') and o.status='posted' then o.amount else 0 end),0)::text as purchases,
        coalesce(sum(case when o.op_type in ('receipt','receipt_other') and o.status='posted' then o.amount else 0 end),0)::text as receipts,
        coalesce(sum(case when o.op_type in ('payment','payment_other') and o.status='posted' then o.amount else 0 end),0)::text as payments,
        coalesce((select sum(jl.debit - jl.credit) from journal_lines jl join journals j on j.id = jl.journal_id join accounts a on a.id = jl.account_id
          where jl.party_id = p.id and j.status='posted' and a.code = ${CODES.AR}),0)::text as ar,
        coalesce((select sum(jl.credit - jl.debit) from journal_lines jl join journals j on j.id = jl.journal_id join accounts a on a.id = jl.account_id
          where jl.party_id = p.id and j.status='posted' and a.code = ${CODES.AP}),0)::text as ap
      from parties p
      left join operations o on o.party_id = p.id and o.user_id = p.user_id
      where p.user_id = ${context.userId}
      group by p.id, p.code, p.name, p.kind, p.phone, p.address
      order by p.code`).map((r) => ({
		id: r.id,
		code: r.code,
		name: r.name,
		kind: r.kind,
		phone: r.phone,
		address: r.address,
		lastDate: r.last_date,
		opCount: r.op_count,
		sales: num(r.sales),
		purchases: num(r.purchases),
		receipts: num(r.receipts),
		payments: num(r.payments),
		ar: num(r.ar),
		ap: num(r.ap)
	}));
});
var createParty_createServerFn_handler = createServerRpc({
	id: "17b5f43257ceabf2a3d1f74a5ed48d1ff5ab937bcf29d87881517237de559e16",
	name: "createParty",
	filename: "src/lib/accounting/actions.ts"
}, (opts) => createParty.__executeServer(opts));
var createParty = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((raw) => object({
	name: string().min(2),
	kind: string(),
	phone: string().optional(),
	address: string().optional()
}).parse(raw)).handler(createParty_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	await seedIfNeeded(sql, context.userId);
	const n = await sql`select count(*)::int as c from parties where user_id = ${context.userId}`;
	const code = `${data.kind.slice(0, 1).toUpperCase()}-${String((n[0]?.c ?? 0) + 1).padStart(3, "0")}`;
	const id = uid();
	await sql`insert into parties (id, user_id, code, name, kind, phone, address)
      values (${id}, ${context.userId}, ${code}, ${data.name}, ${data.kind}, ${data.phone ?? null}, ${data.address ?? null})`;
	await audit(sql, context.userId, "Create", "party", id, { next: data });
	return {
		id,
		code
	};
});
var createAccount_createServerFn_handler = createServerRpc({
	id: "b710651212a1e2007e74cb393707a0e91886be772dec3e5f2bad672acc4cc6f9",
	name: "createAccount",
	filename: "src/lib/accounting/actions.ts"
}, (opts) => createAccount.__executeServer(opts));
var createAccount = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((raw) => object({
	code: string().min(1),
	name: string().min(2),
	parentCode: string(),
	nature: _enum(["debit", "credit"]),
	groupCode: string(),
	floatingType: string().optional()
}).parse(raw)).handler(createAccount_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	await seedIfNeeded(sql, context.userId);
	const parent = await sql`
      select id, level from accounts where user_id = ${context.userId} and code = ${data.parentCode}`;
	if (!parent[0]) throw new AccountingError("حساب والد یافت نشد.");
	if (parent[0].level >= 4) throw new AccountingError("عمیق‌تر از سطح تفصیلی مجاز نیست.");
	const id = uid();
	await sql`insert into accounts (id, user_id, code, name, level, parent_id, group_code, nature, is_postable, is_active, floating_type)
      values (${id}, ${context.userId}, ${data.code}, ${data.name}, ${parent[0].level + 1}, ${parent[0].id},
        ${data.groupCode}, ${data.nature}, true, true, ${data.floatingType ?? "none"})`;
	await audit(sql, context.userId, "Modify Account", "account", id, { next: data });
	return { id };
});
var listChecks_createServerFn_handler = createServerRpc({
	id: "dbfdfed2b201cac2d05b3b62e58f34517cb35b10967b22956f1e8ce7365eb1d5",
	name: "listChecks",
	filename: "src/lib/accounting/actions.ts"
}, (opts) => listChecks.__executeServer(opts));
var listChecks = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listChecks_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	await seedIfNeeded(sql, context.userId);
	return (await sql`select c.id, c.number, c.kind, p.name as party_name, c.bank_name, c.amount::text, c.issue_date::text, c.due_date::text, c.status, c.operation_id
      from checks c left join parties p on p.id = c.party_id
      where c.user_id = ${context.userId} order by c.due_date nulls last`).map((r) => ({
		...r,
		amount: num(r.amount)
	}));
});
var updateCheckStatus_createServerFn_handler = createServerRpc({
	id: "b78b167ed15dac59c6ca6063c92a58c828edf05041ca38992cc1e6588bc5d7a0",
	name: "updateCheckStatus",
	filename: "src/lib/accounting/actions.ts"
}, (opts) => updateCheckStatus.__executeServer(opts));
var updateCheckStatus = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((raw) => object({
	id: string(),
	status: string()
}).parse(raw)).handler(updateCheckStatus_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	await sql`update checks set status = ${data.status} where id = ${data.id} and user_id = ${context.userId}`;
	await audit(sql, context.userId, "Edit", "check", data.id, { next: { status: data.status } });
	return { ok: true };
});
var closeDay_createServerFn_handler = createServerRpc({
	id: "057ce5c93319c547649a994043cadf333d3ce4cd40afca7446294531306c1f75",
	name: "closeDay",
	filename: "src/lib/accounting/actions.ts"
}, (opts) => closeDay.__executeServer(opts));
var closeDay = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((raw) => object({
	date: string(),
	confirm: literal(true)
}).parse(raw)).handler(closeDay_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	await seedIfNeeded(sql, context.userId);
	const fy = await currentFy(sql, context.userId);
	const day = await ensureDay(sql, context.userId, fy.id, data.date);
	if (day.status === "closed") throw new AccountingError("این روز قبلاً بسته شده است.");
	const unbalanced = await sql`
      select j.number, coalesce(sum(jl.debit),0)::text as d, coalesce(sum(jl.credit),0)::text as c
      from journals j join journal_lines jl on jl.journal_id = j.id
      where j.user_id = ${context.userId} and j.day_id = ${day.id} and j.status = 'posted'
      group by j.number
      having coalesce(sum(jl.debit),0) <> coalesce(sum(jl.credit),0)`;
	if (unbalanced.length) throw new AccountingError(`اسناد نامتوازن: ${unbalanced.map((u) => u.number).join("، ")}`);
	if (((await sql`
      select count(*)::int as n from operations
      where user_id = ${context.userId} and day_id = ${day.id} and status = 'posted'
        and op_type in ('receipt','payment','sale_cash','expense_cash','income')
        and cash_account_id is null`)[0]?.n ?? 0) > 0) throw new AccountingError("دریافت/پرداخت بدون منبع مالی وجود دارد.");
	const ops = await sql`select number, op_type, amount::text, description from operations where user_id = ${context.userId} and day_id = ${day.id} and status = 'posted'`;
	const pkg = {
		date: data.date,
		fiscalYear: fy.code,
		operations: ops,
		closedAt: (/* @__PURE__ */ new Date()).toISOString()
	};
	const { jy, jm, jd } = (await import("./format-c9GA3s0l.mjs").then((n) => n.d).then((n) => n.d)).isoToJalali(data.date);
	const backupName = `MR-KHORASANI-Backup-${jy}-${String(jm).padStart(2, "0")}-${String(jd).padStart(2, "0")}`;
	const closeId = uid();
	await sql`insert into daily_closings (id, user_id, day_id, closed_by, package_json, backup_name)
      values (${closeId}, ${context.userId}, ${day.id}, ${context.userId}, ${JSON.stringify(pkg)}, ${backupName})`;
	await sql`update fiscal_days set status = 'closed' where id = ${day.id} and user_id = ${context.userId}`;
	await audit(sql, context.userId, "Close Day", "fiscal_day", day.id, { next: {
		date: data.date,
		closeId,
		backupName
	} });
	return {
		closeId,
		backupName,
		package: pkg
	};
});
var requestReopenDay_createServerFn_handler = createServerRpc({
	id: "cc3f002a9d1d889f4203156090b31890050a4150e75fd72523535c322d0efc0a",
	name: "requestReopenDay",
	filename: "src/lib/accounting/actions.ts"
}, (opts) => requestReopenDay.__executeServer(opts));
var requestReopenDay = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((raw) => object({
	date: string(),
	phrase: string()
}).parse(raw)).handler(requestReopenDay_createServerFn_handler, async ({ context, data }) => {
	if (data.phrase.trim() !== "بازگشایی") throw new AccountingError("برای تأیید، عبارت «بازگشایی» را وارد کنید.");
	const sql = await getSql();
	const day = await sql`
      select id, status from fiscal_days where user_id = ${context.userId} and day_date = ${data.date}::date`;
	if (!day[0] || day[0].status !== "closed") throw new AccountingError("روز بسته‌ای برای این تاریخ نیست.");
	await sql`update fiscal_days set status = 'open' where id = ${day[0].id} and user_id = ${context.userId}`;
	await audit(sql, context.userId, "Reopen Day", "fiscal_day", day[0].id, { reason: "درخواست اصلاح روز بسته‌شده" });
	return { ok: true };
});
var exportBackup_createServerFn_handler = createServerRpc({
	id: "f02e4fb688ea8253870c9f61b3e4703f28ac6c12ed0b113be33614675c003444",
	name: "exportBackup",
	filename: "src/lib/accounting/actions.ts"
}, (opts) => exportBackup.__executeServer(opts));
var exportBackup = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(exportBackup_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	await seedIfNeeded(sql, context.userId);
	const operations = await sql`select * from operations where user_id = ${context.userId}`;
	const journals = await sql`select * from journals where user_id = ${context.userId}`;
	const lines = await sql`select * from journal_lines where user_id = ${context.userId}`;
	const accounts = await sql`select * from accounts where user_id = ${context.userId}`;
	const parties = await sql`select * from parties where user_id = ${context.userId}`;
	const checks = await sql`select * from checks where user_id = ${context.userId}`;
	const auditLogs = await sql`select * from audit_logs where user_id = ${context.userId} order by occurred_at desc limit 2000`;
	const closings = await sql`select id, backup_name, closed_at::text from daily_closings where user_id = ${context.userId}`;
	await audit(sql, context.userId, "Backup", "system", void 0);
	return {
		generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
		operations,
		journals,
		lines,
		accounts,
		parties,
		checks,
		auditLogs,
		closings
	};
});
var listAudit_createServerFn_handler = createServerRpc({
	id: "a473d9b520b2e50d5e82e73094726c709ba8d9bcfe5fca899574b53ecdbb2c4e",
	name: "listAudit",
	filename: "src/lib/accounting/actions.ts"
}, (opts) => listAudit.__executeServer(opts));
var listAudit = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listAudit_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	await seedIfNeeded(sql, context.userId);
	return await sql`select id, action, entity, entity_id, occurred_at::text, old_value, new_value, reason
      from audit_logs where user_id = ${context.userId} order by occurred_at desc limit 300`;
});
var getHealth_createServerFn_handler = createServerRpc({
	id: "7c64d01489f987a27055d573a33cdb93a677f94c502bc9b986733041af1c142a",
	name: "getHealth",
	filename: "src/lib/accounting/actions.ts"
}, (opts) => getHealth.__executeServer(opts));
var getHealth = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getHealth_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	await seedIfNeeded(sql, context.userId);
	const today = todayIso();
	const ops = await sql`select count(*)::int as n from operations where user_id = ${context.userId} and op_date = ${today}::date and status='posted'`;
	const jv = await sql`select count(*)::int as n from journals where user_id = ${context.userId} and status='posted'`;
	const unbal = await sql`
      select count(*)::int as n from (
        select j.id from journals j join journal_lines jl on jl.journal_id = j.id
        where j.user_id = ${context.userId} and j.status='posted'
        group by j.id having sum(jl.debit) <> sum(jl.credit)
      ) t`;
	const openDays = await sql`select count(*)::int as n from fiscal_days where user_id = ${context.userId} and status='open'`;
	const closedDays = await sql`select count(*)::int as n from fiscal_days where user_id = ${context.userId} and status='closed'`;
	const lastBackup = await sql`
      select backup_name, closed_at::text from daily_closings where user_id = ${context.userId} order by closed_at desc limit 1`;
	const auditN = await sql`select count(*)::int as n from audit_logs where user_id = ${context.userId}`;
	return {
		opsToday: ops[0]?.n ?? 0,
		journals: jv[0]?.n ?? 0,
		unbalanced: unbal[0]?.n ?? 0,
		openDays: openDays[0]?.n ?? 0,
		closedDays: closedDays[0]?.n ?? 0,
		lastBackup: lastBackup[0] ?? null,
		auditEvents: auditN[0]?.n ?? 0,
		syncPending: 0
	};
});
var searchBooks_createServerFn_handler = createServerRpc({
	id: "89a1fa688e5f88be1087b8efe2596b904628ece0f2e9ef689896d61c87f4b4ee",
	name: "searchBooks",
	filename: "src/lib/accounting/actions.ts"
}, (opts) => searchBooks.__executeServer(opts));
var searchBooks = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((raw) => object({ q: string() }).parse(raw)).handler(searchBooks_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	await seedIfNeeded(sql, context.userId);
	const q = `%${data.q}%`;
	const parties = await sql`
      select id, name, code from parties where user_id = ${context.userId} and (name ilike ${q} or code ilike ${q}) limit 8`;
	const ops = await sql`
      select id, number, description from operations where user_id = ${context.userId} and (number ilike ${q} or description ilike ${q}) limit 8`;
	const acc = await sql`
      select id, code, name from accounts where user_id = ${context.userId} and (code ilike ${q} or name ilike ${q}) limit 8`;
	return [
		...parties.map((p) => ({
			id: p.id,
			title: `${p.code} — ${p.name}`,
			kind: "شخص",
			to: "/parties"
		})),
		...ops.map((o) => ({
			id: o.id,
			title: `${o.number} ${o.description ?? ""}`,
			kind: "عملیات",
			to: "/operations"
		})),
		...acc.map((a) => ({
			id: a.id,
			title: `${a.code} ${a.name}`,
			kind: "حساب",
			to: "/accounts"
		}))
	];
});
//#endregion
export { bootstrapCompany_createServerFn_handler, closeDay_createServerFn_handler, createAccount_createServerFn_handler, createParty_createServerFn_handler, exportBackup_createServerFn_handler, getDashboard_createServerFn_handler, getHealth_createServerFn_handler, getJournalBook_createServerFn_handler, getLedger_createServerFn_handler, getPartyCard_createServerFn_handler, getStatements_createServerFn_handler, getTrialBalance_createServerFn_handler, listAudit_createServerFn_handler, listChecks_createServerFn_handler, listOperations_createServerFn_handler, postOperation_createServerFn_handler, previewJournal_createServerFn_handler, requestReopenDay_createServerFn_handler, reverseOperation_createServerFn_handler, searchBooks_createServerFn_handler, softDeleteOperation_createServerFn_handler, updateCheckStatus_createServerFn_handler };
