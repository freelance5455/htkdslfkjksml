import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { a as isTierId, o as parseConfidence, s as pslFromTier, t as TIER_META } from "./psl-Dm-iLy6f.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/score-psl-DPTGCqog.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var ENDPOINT = "https://moggedupapp.com/api/mogger-test";
var MAX_B64 = 18e5;
var scorePsl_createServerFn_handler = createServerRpc({
	id: "b38f1a296fbcb56253d2cd7f8562e90041c38beccff3d28b12dee38f26eba5c5",
	name: "scorePsl",
	filename: "src/lib/score-psl.ts"
}, (opts) => scorePsl.__executeServer(opts));
var scorePsl = createServerFn({ method: "POST" }).validator((input) => {
	if (!input || typeof input !== "object") throw new Error("INVALID");
	const imageBase64 = input.imageBase64;
	if (typeof imageBase64 !== "string" || imageBase64.length < 32) throw new Error("INVALID");
	if (imageBase64.length > MAX_B64) throw new Error("INVALID");
	return { imageBase64 };
}).handler(scorePsl_createServerFn_handler, async ({ data }) => {
	const controller = new AbortController();
	const timer = setTimeout(() => controller.abort(), 55e3);
	try {
		const res = await fetch(ENDPOINT, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Accept: "application/json",
				Origin: "https://moggedupapp.com",
				Referer: "https://moggedupapp.com/tools/psl-score",
				"User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1"
			},
			body: JSON.stringify({
				imageBase64: data.imageBase64,
				hp: ""
			}),
			signal: controller.signal
		});
		let body = {};
		try {
			body = await res.json();
		} catch {
			body = {};
		}
		if (res.status === 429) return {
			ok: false,
			code: "RATE_LIMIT",
			message: "Quá nhiều lượt chấm. Đợi một lúc rồi thử lại."
		};
		if (!res.ok) {
			if (body.error === "NO_FACE_DETECTED") return {
				ok: false,
				code: "NO_FACE",
				message: "Không nhận ra khuôn mặt. Chụp chính diện, đủ sáng, mắt nhìn camera."
			};
			return {
				ok: false,
				code: "FAILED",
				message: "Không chấm được điểm. Thử ảnh khác, rõ mặt hơn."
			};
		}
		const tierRaw = typeof body.tier === "string" ? body.tier.toLowerCase() : "";
		if (!isTierId(tierRaw)) return {
			ok: false,
			code: "FAILED",
			message: "Máy chủ không trả về rank hợp lệ. Thử lại với ảnh khác."
		};
		const tier = tierRaw;
		const meta = TIER_META[tier];
		const markers = Array.isArray(body.markers) ? body.markers.filter((m) => typeof m === "string" && m.trim().length > 0) : [];
		const psl = resolveNumericPsl(body, tier);
		return {
			ok: true,
			tier,
			rank: meta.rank,
			psl,
			pslMin: meta.pslMin,
			pslMax: meta.pslMax,
			mogScore: meta.mogScore,
			rarity: meta.rarity,
			confidence: parseConfidence(body.confidence),
			markers
		};
	} catch {
		return {
			ok: false,
			code: "NETWORK",
			message: "Không kết nối được máy chấm điểm. Kiểm tra mạng rồi thử lại."
		};
	} finally {
		clearTimeout(timer);
	}
});
function resolveNumericPsl(body, tier) {
	const fromPsl = typeof body.psl === "number" && Number.isFinite(body.psl) ? body.psl : null;
	const fromScore = typeof body.score === "number" && Number.isFinite(body.score) ? body.score : null;
	const raw = fromPsl ?? (fromScore !== null ? fromScore > 10 ? fromScore / 10 : fromScore : null);
	if (raw === null) return pslFromTier(tier);
	const meta = TIER_META[tier];
	const clamped = Math.min(meta.pslMax, Math.max(meta.pslMin, raw));
	return Math.round(clamped * 10) / 10;
}
//#endregion
export { scorePsl_createServerFn_handler };
