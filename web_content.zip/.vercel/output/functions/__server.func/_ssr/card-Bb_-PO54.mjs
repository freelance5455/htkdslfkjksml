import { t as cn } from "./utils-C_uf36nf.mjs";
import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { l as formatRial, u as formatRialCompact } from "./format-c9GA3s0l.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/card-Bb_-PO54.js
var import_jsx_runtime = require_jsx_runtime();
function PageHeader({ eyebrow, title, description, actions }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-6 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			eyebrow ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-1 text-[11px] tracking-[0.22em] text-gold uppercase",
				children: eyebrow
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-semibold tracking-tight text-navy",
				children: title
			}),
			description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 max-w-2xl text-sm text-muted",
				children: description
			}) : null
		] }), actions ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-wrap gap-2 no-print",
			children: actions
		}) : null]
	});
}
function Money({ value, compact = false, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("tabular", className),
		dir: "ltr",
		children: compact ? formatRialCompact(value) : formatRial(value)
	});
}
function StatCard({ label, value, hint, gold = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("rounded-[22px] border p-4 shadow-[var(--shadow-card)]", gold ? "border-gold/40 bg-navy text-cream" : "border-line bg-paper"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("text-[11px] tracking-wide", gold ? "text-gold-2" : "text-muted"),
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("mt-2 text-lg font-semibold tabular", gold ? "text-gold-2" : "text-navy"),
				children: value
			}),
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("mt-1 text-[11px]", gold ? "text-cream/50" : "text-muted"),
				children: hint
			}) : null
		]
	});
}
function SkeletonGrid({ n = 6 }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-2 gap-3 lg:grid-cols-5",
		children: Array.from({ length: n }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-24 animate-pulse rounded-[22px] bg-secondary" }, i))
	});
}
function Card({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("rounded-[24px] border border-line bg-paper p-5 shadow-[var(--shadow-card)]", className),
		...props
	});
}
function Badge({ className, tone = "default", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center rounded-full px-2.5 py-0.5 text-[11px] font-medium", {
			default: "bg-secondary text-ink",
			gold: "bg-gold/15 text-navy",
			ok: "bg-success/12 text-success",
			warn: "bg-warn/12 text-warn",
			danger: "bg-danger/12 text-danger",
			navy: "bg-navy text-cream"
		}[tone], className),
		...props
	});
}
//#endregion
export { SkeletonGrid as a, PageHeader as i, Card as n, StatCard as o, Money as r, Badge as t };
