import { t as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-A6pJPYTF.mjs";
import { a as object, o as string } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/speak-DFdSzUdT.js
var SpeakSchema = object({ text: string().min(1).max(800) });
var speakJarvis_createServerFn_handler = createServerRpc({
	id: "6e8eda61e6740854cea1061e01f693f4837295cb55f010bf5a7473c8996a6fa4",
	name: "speakJarvis",
	filename: "src/lib/jarvis/speak.ts"
}, (opts) => speakJarvis.__executeServer(opts));
var speakJarvis = createServerFn({ method: "POST" }).validator((input) => SpeakSchema.parse(input)).handler(speakJarvis_createServerFn_handler, async ({ data }) => {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "voice-offline"
	};
	const spoken = data.text.slice(0, 600);
	try {
		const res = await fetch("https://api.x.ai/v1/tts", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${apiKey}`
			},
			body: JSON.stringify({
				text: spoken,
				voice_id: "leo",
				language: "en"
			})
		});
		if (!res.ok) return {
			ok: false,
			error: `tts-${res.status}`
		};
		const buf = Buffer.from(await res.arrayBuffer());
		if (buf.byteLength < 200) return {
			ok: false,
			error: "tts-empty"
		};
		return {
			ok: true,
			audio: `data:audio/mpeg;base64,${buf.toString("base64")}`
		};
	} catch {
		return {
			ok: false,
			error: "tts-network"
		};
	}
});
//#endregion
export { speakJarvis_createServerFn_handler };
