import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as signIn } from "./client-B40BzJxt.mjs";
import { t as GROK_PROVIDERS } from "./server-zc5mqedF.mjs";
import { t as SignInGate } from "./gates-LnRAiBUB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-SQ3UiNZG.js
var import_jsx_runtime = require_jsx_runtime();
function Login() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-dvh place-items-center px-6 py-12",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-serif text-[13px] text-brass-deep",
					children: "RentDirect"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-serif mt-1 text-3xl font-semibold tracking-tight text-ink",
					children: "Sign in"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-ink-soft",
					children: "Post rooms, reveal owner numbers, and earn when a listing you shared gets rented."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6 space-y-2.5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SignInGate, {
						fallback: GROK_PROVIDERS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => signIn(p.providerId, { callbackURL: "/" }),
							className: "flex min-h-11 w-full items-center justify-center rounded-md border border-line bg-card px-4 text-sm font-medium text-ink transition-opacity hover:bg-paper-alt",
							children: ["Continue with ", p.label]
						}, p.providerId)),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-ink-soft",
							children: "You're already signed in."
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							search: { tab: "browse" },
							className: "mt-3 inline-flex min-h-11 items-center text-sm font-medium text-brass-deep underline-offset-4 hover:underline",
							children: "Back to rooms"
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					search: { tab: "browse" },
					className: "mt-8 inline-block text-sm text-ink-soft underline-offset-4 hover:underline",
					children: "Browse without posting"
				})
			]
		})
	});
}
//#endregion
export { Login as component };
