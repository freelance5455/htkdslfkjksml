import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { n as platformLabel } from "./format-Ci0m3vzz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/analyze-DJHI94L_.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var SYSTEM_PROMPT = `You are the lead gaming account appraiser for Bruno Gaming, the premier eFootball community in Myanmar. You specialize in accurate, realistic market valuation in Myanmar Kyats (MMK) for eFootball 2025/2026.

Return ONLY a JSON object. No markdown, no code fences, no extra commentary.

JSON shape:
{
  "tier": 1 | 2 | 3 | 4,
  "tierLabel": "short Burmese label",
  "paidCards": [{"name": "string", "skill": "optional skill", "note": "short Burmese"}],
  "freeCards": [{"name": "string", "note": "short Burmese"}],
  "managers": [{"name": "string", "note": "short Burmese"}],
  "priceMin": number,
  "priceMax": number,
  "coinAddMmk": number,
  "deadLinkPenaltyPct": number,
  "finalMin": number,
  "finalMax": number,
  "marketAnalysis": "2-4 sentences Burmese",
  "strategyPoints": ["Burmese bullets for the user's buy or sell intent"],
  "warnings": ["Burmese warnings if any"],
  "confidence": "high" | "medium" | "low",
  "summary": "one-sentence Burmese verdict"
}

All prose fields MUST be natural, professional Burmese (Myanmar). Card names stay in Latin script as printed in-game.

=======================================================
CRITICAL MYANMAR MARKET PRICING RULES (MANDATORY):
=======================================================

1. THE "FREE EPIC" RULE (ZERO TO NEGLIGIBLE VALUE):
   - FREE cards (Daily Penalty, Free Chance Deals, Free Double Boosters, Anniversary gifts, NC, POTW, Highlight) have virtually ZERO extra market value because every player gets them for free.
   - Known FREE Double Booster Epics include:
     Costacurta, Cannavaro, Kahn, Ribery, Saviola, Drogba, Inzaghi, Forlan, Romario, Batistuta, Sneijder (Free), Cole, Arteta, Scholes, Nakata, Cafu, Ronaldinho/Rivaldo (Free 103), Roberto Carlos (Free 103), Zambrotta, Beckenbauer, Serginho, Del Piero, Dida, Rooney, Casillas, Puyol (Free 102), Denilson, Bale (Free 102), Beckham (Free 102), Adams, Bergkamp, Figo, Guardiola (Free 100), Iniesta, Safee Sali, Owen, Torres, Van der Vaart, Hazard, Lewandowski (Free 102), Aubameyang, and similar event/free boosters.
   - BENCHMARK: A squad full of 102-106 rated Free Double Booster Epics with Strength ~3114 sells for ONLY 20,000–26,000 MMK. Do NOT appraise free-only squads at 50k or 100k.

2. THE "PAID EPIC / BOOSTER" RULE (REAL VALUE):
   Real account value is driven by PAID 150-box draws, Treasure Link, and Special Skill Epics:
   - Treasure Link (Rio Ferdinand Aerial Fort, Van Basten, Puyol, Sneijder 98, Koller)
   - Meta skills: Blitz Curler (Messi, Son, Salah, Chiesa), Bullet Header (Ronaldo, Haaland), Fortress, Momentum Dribbling, Phenomenal Finishing, Edged Crossing
   - High-end paid boosters / Big Time: Messi 2015/2022/2009, Ronaldinho, Vieira, Gullit, Rummenigge, Rijkaard, Makelele, Pirlo, Shevchenko, Cruyff, Maldini, Nesta, Cech, Schmeichel
   - Paid booster managers (Fabio Capello, Pep Guardiola 88, Xabi Alonso 88, Ten Hag) add about 10,000–15,000 MMK each

3. MYANMAR TIER VALUATIONS (2025/2026):
   - Tier 1 Free/standard: Strength 3100–3150, mostly free epics/POTW → 15,000–26,000 MMK
   - Tier 2 Mid: Strength 3150–3220, 1–3 paid booster epics → 50,000–70,000 MMK
   - Tier 3 High: Strength 3220–3280, 4–6 top paid boosters + paid manager → 75,000–100,000 MMK
   - Tier 4 Whale: Strength 3300+, full paid double booster XI → 130,000–250,000+ MMK

4. COINS: 1,000 coins in balance = +20,000 MMK. Put that add-on in coinAddMmk, then include it in finalMin/finalMax.

5. GOOGLE LINK ERROR (DEAD LINK):
   If dead link is YES: apply 50%–75% penalty. Set deadLinkPenaltyPct (50–75). finalMin/finalMax MUST already include the penalty. Add a strong warning.

6. SCREENSHOTS:
   Read every attached screenshot carefully. Split cards into paid vs free. If a card is ambiguous, say so in the note and do not inflate the price.
   If no screenshots: confidence "low", empty card lists, strength/coins-only estimate, and a warning that screenshots are required for a real appraisal.

7. Be conservative. Myanmar buyers punish overpricing. Prefer the lower half of a tier when paid cards are few or mostly free lookalikes.
`;
function buildUserPrompt(input) {
	const intentBlock = input.intent === "buy" ? `USER INTENT: BUYING
strategyPoints must cover:
- Fair buying price in MMK
- Maximum safety cap
- Why the account is cheap or expensive (call out free-event cards)
- Buyer safety: Konami ID, 2-step verification, clean Google link` : `USER INTENT: SELLING
strategyPoints must cover:
- Target asking price in MMK
- Quick-sell price
- Which paid epics/managers to put in the post title
- Negotiation buffer`;
	return `အကောင့်အချက်အလက်များ:
- Platform: ${input.platformLabel}
- Team Collective Strength: ${input.strength || "မဖော်ပြထားပါ"}
- eFootball Coins: ${input.coins || "0"} Coins
- Screenshots attached: ${input.imageCount}
- Google Link Error (Dead Link): ${input.hasLinkError ? "ဟုတ်ပါသည် (၅၀% မှ ၇၅% စျေးလျှော့တွက်ပေးပါ)" : "မပါရှိပါ (သန့်ရှင်းသော အကောင့်)"}

${intentBlock}

စခရင်ရှော့ပါ ကတ်များကို Free vs Paid ခွဲပြီး မြန်မာစျေးကွက်ပေါက်စျေးအမှန်ကို JSON ဖြင့်သာ ပြန်ပါ။`;
}
var MODEL = "grok-4.5";
var MAX_IMAGES = 6;
var MAX_B64_CHARS = 18e5;
function asNumber(value, fallback = 0) {
	const n = typeof value === "number" ? value : Number(value);
	return Number.isFinite(n) ? n : fallback;
}
function asString(value, fallback = "") {
	return typeof value === "string" ? value : fallback;
}
function asCards(value) {
	if (!Array.isArray(value)) return [];
	return value.map((item) => {
		if (!item || typeof item !== "object") return null;
		const rec = item;
		const name = asString(rec.name).trim();
		if (!name) return null;
		return {
			name,
			skill: asString(rec.skill).trim() || void 0,
			note: asString(rec.note).trim()
		};
	}).filter((c) => c !== null).slice(0, 24);
}
function extractJson(text) {
	const trimmed = text.trim();
	const raw = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/i)?.[1]?.trim() ?? trimmed;
	const start = raw.indexOf("{");
	const end = raw.lastIndexOf("}");
	if (start < 0 || end <= start) throw new Error("no-json");
	return JSON.parse(raw.slice(start, end + 1));
}
function normalizeAppraisal(raw) {
	const rec = raw && typeof raw === "object" ? raw : {};
	const tierNum = Math.min(4, Math.max(1, Math.round(asNumber(rec.tier, 1))));
	const confidenceRaw = asString(rec.confidence, "medium");
	const confidence = confidenceRaw === "high" || confidenceRaw === "low" ? confidenceRaw : "medium";
	const priceMin = Math.max(0, asNumber(rec.priceMin));
	const priceMax = Math.max(priceMin, asNumber(rec.priceMax, priceMin));
	const finalMin = Math.max(0, asNumber(rec.finalMin, priceMin));
	const finalMax = Math.max(finalMin, asNumber(rec.finalMax, priceMax));
	return {
		tier: tierNum,
		tierLabel: asString(rec.tierLabel, `Tier ${tierNum}`),
		paidCards: asCards(rec.paidCards),
		freeCards: asCards(rec.freeCards),
		managers: asCards(rec.managers),
		priceMin,
		priceMax,
		coinAddMmk: Math.max(0, asNumber(rec.coinAddMmk)),
		deadLinkPenaltyPct: Math.min(90, Math.max(0, asNumber(rec.deadLinkPenaltyPct))),
		finalMin,
		finalMax,
		marketAnalysis: asString(rec.marketAnalysis),
		strategyPoints: Array.isArray(rec.strategyPoints) ? rec.strategyPoints.map((s) => asString(s).trim()).filter(Boolean).slice(0, 8) : [],
		warnings: Array.isArray(rec.warnings) ? rec.warnings.map((s) => asString(s).trim()).filter(Boolean).slice(0, 6) : [],
		confidence,
		summary: asString(rec.summary)
	};
}
function validateInput(input) {
	if (input.intent !== "buy" && input.intent !== "sell") throw new Error("invalid-intent");
	if (![
		"mobile",
		"pc",
		"console"
	].includes(input.platform)) throw new Error("invalid-platform");
	const images = Array.isArray(input.images) ? input.images.slice(0, MAX_IMAGES) : [];
	for (const img of images) {
		if (!img?.data || img.data.length > MAX_B64_CHARS) throw new Error("image-too-large");
		if (!String(img.mimeType || "").startsWith("image/")) throw new Error("invalid-image");
	}
	return {
		intent: input.intent,
		platform: input.platform,
		strength: String(input.strength ?? "").slice(0, 16),
		coins: String(input.coins ?? "").slice(0, 16),
		hasLinkError: Boolean(input.hasLinkError),
		images
	};
}
async function callXai(messages, apiKey) {
	const res = await fetch("https://api.x.ai/v1/chat/completions", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		body: JSON.stringify({
			model: MODEL,
			temperature: .2,
			max_tokens: 1800,
			messages
		}),
		signal: AbortSignal.timeout(9e4)
	});
	if (!res.ok) {
		const errText = await res.text().catch(() => "");
		throw new Error(`xai-${res.status}:${errText.slice(0, 180)}`);
	}
	return (await res.json()).choices?.[0]?.message?.content ?? "";
}
var analyzeAccount_createServerFn_handler = createServerRpc({
	id: "6d51885f3d3dbdaa04c44ff29f7ce33dff85945ba32b6be4cba32716407c1cc9",
	name: "analyzeAccount",
	filename: "src/lib/analyze.ts"
}, (opts) => analyzeAccount.__executeServer(opts));
var analyzeAccount = createServerFn({ method: "POST" }).validator((input) => validateInput(input)).handler(analyzeAccount_createServerFn_handler, async ({ data }) => {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "unavailable"
	};
	if (data.images.length === 0 && !data.strength.trim()) return {
		ok: false,
		error: "need-input"
	};
	const content = [{
		type: "text",
		text: buildUserPrompt({
			intent: data.intent,
			platformLabel: platformLabel(data.platform),
			strength: data.strength.trim() || "မဖော်ပြထားပါ",
			coins: data.coins.trim() || "0",
			hasLinkError: data.hasLinkError,
			imageCount: data.images.length
		})
	}];
	data.images.forEach((img, index) => {
		content.push({
			type: "image_url",
			image_url: {
				url: `data:${img.mimeType};base64,${img.data}`,
				detail: index < 3 ? "high" : "low"
			}
		});
	});
	const messages = [{
		role: "system",
		content: SYSTEM_PROMPT
	}, {
		role: "user",
		content
	}];
	try {
		let text = await callXai(messages, apiKey);
		if (!text.trim()) return {
			ok: false,
			error: "empty"
		};
		try {
			return {
				ok: true,
				appraisal: normalizeAppraisal(extractJson(text)),
				raw: text
			};
		} catch {
			const repair = await callXai([{
				role: "system",
				content: "Convert the following appraisal into the required JSON object only."
			}, {
				role: "user",
				content: text.slice(0, 6e3)
			}], apiKey);
			return {
				ok: true,
				appraisal: normalizeAppraisal(extractJson(repair)),
				raw: repair
			};
		}
	} catch (err) {
		const message = err instanceof Error ? err.message : "unknown";
		if (message.startsWith("xai-429") || message.startsWith("xai-5")) return {
			ok: false,
			error: "busy"
		};
		if (message.includes("Timeout") || message.includes("aborted")) return {
			ok: false,
			error: "timeout"
		};
		return {
			ok: false,
			error: "failed"
		};
	}
});
//#endregion
export { analyzeAccount_createServerFn_handler };
