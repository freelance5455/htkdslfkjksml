import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as NyalaGate } from "./nyala-gate-DLLoNCea.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-NAPinwJ2.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NyalaGate, {});
}
//#endregion
export { Home as component };
