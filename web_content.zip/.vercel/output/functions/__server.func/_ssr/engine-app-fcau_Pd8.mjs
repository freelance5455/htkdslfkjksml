import { i as __toESM } from "../_runtime.mjs";
import { G as require_jsx_runtime, K as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as Volume2, n as Wrench, o as Settings2, r as VolumeX, s as KeyRound, t as X } from "../_libs/lucide-react.mjs";
import { _ as SphereGeometry, a as CircleGeometry, c as Group, d as Mesh, f as MeshBasicMaterial, g as Scene, h as PointLight, i as BoxGeometry, l as HemisphereLight, m as PerspectiveCamera, n as WebGLRenderer, o as CylinderGeometry, p as MeshStandardMaterial, r as Box3, s as DirectionalLight, t as mergeGeometries, u as Matrix4, v as Vector3 } from "../_libs/three.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/engine-app-fcau_Pd8.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var LANGS = [
	"en",
	"ko",
	"ja",
	"ru",
	"ar"
];
var LANG_LABEL = {
	en: "English",
	ko: "한국어",
	ja: "日本語",
	ru: "Русский",
	ar: "العربية"
};
var en = {
	title: "Engine Maker",
	close: "Close maker",
	soundOn: "Turn sound on",
	soundOff: "Turn sound off",
	ignStart: "Start engine",
	ignCrank: "Cranking…",
	ignStop: "Stop engine",
	deadT: "Engine blown",
	deadD: "You downshifted too far and over-revved the engine.",
	fix: "Repair",
	clutch: "Clutch",
	brake: "Brake",
	gas: "Gas",
	twin: "Twin engine (2 running at once)",
	hLayout: "Cylinders / layout",
	hDim: "Dimensions",
	bore: "Bore",
	stroke: "Stroke",
	hFuel: "Fuel",
	fuelGas: "Gasoline",
	fuelDsl: "Diesel",
	hInduct: "Intake / boost",
	carb: "Carburetor",
	turbo: "Turbocharger",
	sc: "Supercharger",
	hExh: "Exhaust",
	xStock: "Stock muffler",
	xSport: "Sport",
	xStraight: "Straight pipe",
	xOpen: "Open (racing)",
	pop: "Popcorn / crackle on lift-off",
	hEcu: "ECU tuning",
	ecu: "ECU tuning",
	map: "Fuel / ignition map",
	lim: "Rev limiter",
	bst: "Boost pressure",
	hBg: "Background",
	hSnd: "Sound",
	vol: "Volume",
	hCol: "Engine color",
	hLang: "Language",
	single: "Single",
	flat: "Flat",
	inl: "Inline",
	rpmRed: "rpm  /  redline",
	overrev: "Over-rev",
	blown: "Blown",
	stall: "Engine off — press Start",
	msgClutch: "Press the clutch to start in gear",
	grind: "Gear grind — press the clutch",
	hint: "Clutch in, select 1st, gas, ease the clutch out",
	keys: "Space gas · B brake · C clutch · Q/E gears · K start",
	drag: "Drag the engine to orbit it",
	diesel: "Diesel",
	langPick: "Language",
	auto: "Auto",
	install: "On your phone",
	installBtn: "Install app",
	installIos: "iPhone: tap Share, then Add to Home Screen.",
	installReady: "Installed on this device.",
	share: "Share link",
	shared: "Share sheet opened",
	copied: "Link copied"
};
var TX = {
	en,
	ko: {
		title: "엔진 메이커",
		close: "메이커 닫기",
		soundOn: "소리 켜기",
		soundOff: "소리 끄기",
		ignStart: "시동 걸기",
		ignCrank: "시동 거는 중…",
		ignStop: "시동 끄기",
		deadT: "엔진 파손",
		deadD: "기어를 너무 낮게 내려 과회전했어요.",
		fix: "수리하기",
		clutch: "클러치",
		brake: "브레이크",
		gas: "가속",
		twin: "트윈 엔진 (2개 동시 작동)",
		hLayout: "기통 / 배열",
		hDim: "치수",
		bore: "보어",
		stroke: "스트로크",
		hFuel: "연료",
		fuelGas: "가솔린",
		fuelDsl: "디젤",
		hInduct: "흡기 / 과급",
		carb: "카뷰레터",
		turbo: "터보차저",
		sc: "슈퍼차저",
		hExh: "배기",
		xStock: "순정 머플러",
		xSport: "스포츠",
		xStraight: "직관",
		xOpen: "오픈 (레이싱)",
		pop: "팝콘 / 크래클 (감속 시)",
		hEcu: "ECU 튜닝",
		ecu: "ECU 튜닝",
		map: "연료·점화 맵",
		lim: "레브 리미터",
		bst: "부스트 압력",
		hBg: "배경 색상",
		hSnd: "사운드",
		vol: "볼륨",
		hCol: "엔진 색상",
		hLang: "언어",
		single: "단기통",
		flat: "플랫",
		inl: "인라인",
		rpmRed: "rpm  /  레드라인",
		overrev: "과회전",
		blown: "파손",
		stall: "시동 꺼짐 — 시동 버튼",
		msgClutch: "클러치를 밟고 시동을 거세요",
		grind: "기어 갈림 — 클러치를 밟으세요",
		hint: "클러치 → 1단 → 가속 → 클러치를 놓기",
		keys: "Space 가속 · B 브레이크 · C 클러치 · Q/E 기어 · K 시동",
		drag: "엔진을 끌어 돌려 보세요",
		diesel: "디젤",
		langPick: "언어",
		auto: "자동",
		install: "휴대폰에 설치",
		installBtn: "앱 설치",
		installIos: "iPhone: 공유 → 홈 화면에 추가.",
		installReady: "이 기기에 설치됨.",
		share: "링크 공유",
		shared: "공유 창이 열렸습니다",
		copied: "링크를 복사했습니다"
	},
	ja: {
		title: "エンジンメーカー",
		close: "閉じる",
		soundOn: "サウンド ON",
		soundOff: "サウンド OFF",
		ignStart: "エンジン始動",
		ignCrank: "始動中…",
		ignStop: "エンジン停止",
		deadT: "エンジン破損",
		deadD: "ギアを落としすぎてオーバーレブしました。",
		fix: "修理",
		clutch: "クラッチ",
		brake: "ブレーキ",
		gas: "アクセル",
		twin: "ツインエンジン（2基同時）",
		hLayout: "気筒数 / 配列",
		hDim: "寸法",
		bore: "ボア",
		stroke: "ストローク",
		hFuel: "燃料",
		fuelGas: "ガソリン",
		fuelDsl: "ディーゼル",
		hInduct: "吸気 / 過給",
		carb: "キャブレター",
		turbo: "ターボ",
		sc: "スーパーチャージャー",
		hExh: "排気",
		xStock: "純正マフラー",
		xSport: "スポーツ",
		xStraight: "ストレート",
		xOpen: "オープン（レーシング）",
		pop: "ポップコーン / クラックル",
		hEcu: "ECUチューニング",
		ecu: "ECUチューニング",
		map: "燃料・点火マップ",
		lim: "レブリミッター",
		bst: "ブースト圧",
		hBg: "背景色",
		hSnd: "サウンド",
		vol: "音量",
		hCol: "エンジン色",
		hLang: "言語",
		single: "単気筒",
		flat: "水平対向",
		inl: "直列",
		rpmRed: "rpm  /  レッドライン",
		overrev: "オーバーレブ",
		blown: "破損",
		stall: "エンジン停止 — 始動ボタン",
		msgClutch: "クラッチを踏んで始動してください",
		grind: "ギア鳴り — クラッチを踏んでください",
		hint: "クラッチ → 1速 → アクセル → クラッチを戻す",
		keys: "Space アクセル · B ブレーキ · C クラッチ · Q/E ギア · K 始動",
		drag: "ドラッグでエンジンを回す",
		diesel: "ディーゼル",
		langPick: "言語",
		auto: "自動",
		install: "スマホに追加",
		installBtn: "アプリをインストール",
		installIos: "iPhone: 共有 → ホーム画面に追加。",
		installReady: "この端末に追加済み。",
		share: "リンクを共有",
		shared: "共有シートを開きました",
		copied: "リンクをコピーしました"
	},
	ru: {
		title: "Конструктор двигателей",
		close: "Закрыть",
		soundOn: "Включить звук",
		soundOff: "Выключить звук",
		ignStart: "Запустить",
		ignCrank: "Запуск…",
		ignStop: "Заглушить",
		deadT: "Двигатель разрушен",
		deadD: "Слишком низкая передача — двигатель перекручен.",
		fix: "Починить",
		clutch: "Сцепление",
		brake: "Тормоз",
		gas: "Газ",
		twin: "Двойной двигатель (2 сразу)",
		hLayout: "Цилиндры / компоновка",
		hDim: "Размеры",
		bore: "Диаметр",
		stroke: "Ход поршня",
		hFuel: "Топливо",
		fuelGas: "Бензин",
		fuelDsl: "Дизель",
		hInduct: "Впуск / наддув",
		carb: "Карбюратор",
		turbo: "Турбо",
		sc: "Нагнетатель",
		hExh: "Выхлоп",
		xStock: "Штатный глушитель",
		xSport: "Спорт",
		xStraight: "Прямоток",
		xOpen: "Открытый",
		pop: "Попкорн / треск при сбросе",
		hEcu: "Тюнинг ЭБУ",
		ecu: "Тюнинг ЭБУ",
		map: "Карта топлива / зажигания",
		lim: "Ограничитель",
		bst: "Давление наддува",
		hBg: "Цвет фона",
		hSnd: "Звук",
		vol: "Громкость",
		hCol: "Цвет двигателя",
		hLang: "Язык",
		single: "Один цилиндр",
		flat: "Оппозит",
		inl: "Рядный",
		rpmRed: "об/мин  /  отсечка",
		overrev: "Перекрут",
		blown: "Разрушен",
		stall: "Двигатель заглох — кнопка запуска",
		msgClutch: "Выжмите сцепление для запуска",
		grind: "Скрежет коробки — выжмите сцепление",
		hint: "Сцепление → 1 → газ → отпустить сцепление",
		keys: "Space газ · B тормоз · C сцепление · Q/E передачи · K запуск",
		drag: "Потяните двигатель, чтобы повернуть",
		diesel: "Дизель",
		langPick: "Язык",
		auto: "Авто",
		install: "На телефон",
		installBtn: "Установить",
		installIos: "iPhone: «Поделиться», затем «На экран Домой».",
		installReady: "Установлено на этом устройстве.",
		share: "Поделиться ссылкой",
		shared: "Окно отправки открыто",
		copied: "Ссылка скопирована"
	},
	ar: {
		title: "صانع المحركات",
		close: "إغلاق",
		soundOn: "تشغيل الصوت",
		soundOff: "إيقاف الصوت",
		ignStart: "تشغيل المحرك",
		ignCrank: "جارٍ التشغيل…",
		ignStop: "إيقاف المحرك",
		deadT: "المحرك تعطّل",
		deadD: "أنزلت غيارًا منخفضًا جدًا فتجاوز المحرك حدّه.",
		fix: "إصلاح",
		clutch: "القابض",
		brake: "الفرامل",
		gas: "الوقود",
		twin: "محرك مزدوج (يعملان معًا)",
		hLayout: "الأسطوانات / الترتيب",
		hDim: "الأبعاد",
		bore: "قطر الأسطوانة",
		stroke: "شوط المكبس",
		hFuel: "الوقود",
		fuelGas: "بنزين",
		fuelDsl: "ديزل",
		hInduct: "السحب / الشحن",
		carb: "مكربن",
		turbo: "شاحن توربيني",
		sc: "شاحن ميكانيكي",
		hExh: "العادم",
		xStock: "كاتم أصلي",
		xSport: "رياضي",
		xStraight: "ماسورة مباشرة",
		xOpen: "مفتوح (سباق)",
		pop: "فرقعة عند رفع القدم",
		hEcu: "ضبط ECU",
		ecu: "ضبط وحدة التحكم",
		map: "خريطة الوقود / الإشعال",
		lim: "محدد الدوران",
		bst: "ضغط الشحن",
		hBg: "لون الخلفية",
		hSnd: "الصوت",
		vol: "مستوى الصوت",
		hCol: "لون المحرك",
		hLang: "اللغة",
		single: "أحادي",
		flat: "مسطّح",
		inl: "خطي",
		rpmRed: "دورة/د  /  الحد",
		overrev: "دوران زائد",
		blown: "تعطّل",
		stall: "المحرك متوقف — زر التشغيل",
		msgClutch: "اضغط القابض ثم شغّل",
		grind: "احتكاك التروس — اضغط القابض",
		hint: "القابض ← الأول ← الوقود ← ارفع القابض",
		keys: "Space وقود · B فرامل · C قابض · Q/E غيار · K تشغيل",
		drag: "اسحب المحرك لتدويره",
		diesel: "ديزل",
		langPick: "اللغة",
		auto: "تلقائي",
		install: "على الهاتف",
		installBtn: "تثبيت التطبيق",
		installIos: "آيفون: مشاركة ثم إضافة إلى الشاشة الرئيسية.",
		installReady: "مثبّت على هذا الجهاز.",
		share: "مشاركة الرابط",
		shared: "فُتحت نافذة المشاركة",
		copied: "تم نسخ الرابط"
	}
};
function copy(lang) {
	return TX[lang] ?? en;
}
function isRtl(lang) {
	return lang === "ar";
}
var LAYOUTS = [
	"single",
	"v2",
	"f2",
	"i2",
	"v3",
	"i3",
	"f3",
	"v4",
	"i4",
	"f4",
	"i5",
	"v6",
	"v8",
	"v10",
	"v12",
	"w12"
];
var COLORS = [
	"#7b8494",
	"#c0392b",
	"#2f6fd0",
	"#c9a227"
];
var CYL = {
	single: 1,
	v2: 2,
	f2: 2,
	i2: 2,
	v3: 3,
	i3: 3,
	f3: 3,
	v4: 4,
	i4: 4,
	f4: 4,
	i5: 5,
	v6: 6,
	v8: 8,
	v10: 10,
	v12: 12,
	w12: 12
};
function defaultSpec() {
	return {
		twin: false,
		ecu: false,
		map: 10,
		lim: 0,
		bst: 10,
		exh: "stock",
		pop: false,
		fuel: "gas",
		type: "i4",
		bore: 82,
		stroke: 86,
		carb: false,
		turbo: false,
		sc: false,
		color: COLORS[0]
	};
}
var EXH$1 = [
	"stock",
	"sport",
	"straight",
	"open"
];
function sanitize(input) {
	const d = defaultSpec();
	if (!input || typeof input !== "object") return d;
	const o = input;
	const type = LAYOUTS.includes(o.type) ? o.type : d.type;
	const fuel = o.fuel === "dsl" ? "dsl" : "gas";
	const exh = EXH$1.includes(o.exh) ? o.exh : d.exh;
	const color = COLORS.includes(o.color) ? o.color : d.color;
	const num = (v, min, max, fallback) => {
		const n = typeof v === "number" ? v : Number(v);
		if (!Number.isFinite(n)) return fallback;
		return Math.min(max, Math.max(min, n));
	};
	return {
		twin: !!o.twin,
		ecu: !!o.ecu,
		map: num(o.map, 0, 30, d.map),
		lim: num(o.lim, -10, 20, d.lim),
		bst: num(o.bst, 0, 50, d.bst),
		exh,
		pop: !!o.pop,
		fuel,
		type,
		bore: num(o.bore, 50, 110, d.bore),
		stroke: num(o.stroke, 50, 110, d.stroke),
		carb: fuel === "dsl" ? false : !!o.carb,
		turbo: !!o.turbo,
		sc: !!o.sc,
		color
	};
}
function createLive() {
	return {
		rpm: 0,
		thr: 0,
		pedal: 0,
		brake: 0,
		brk: 0,
		gear: 0,
		spd: 0,
		dead: false,
		deadT: 0,
		stopT: 0,
		stall: true,
		crank: 0,
		cut: false,
		cutT: 0,
		rel: false,
		limCd: 0,
		clu: 0,
		cin: 0,
		grind: 0,
		msg: 0
	};
}
var D = Math.PI / 180;
function layout(t, b) {
	const n = CYL[t];
	const sp = b * 1.15;
	const o = [];
	for (let i = 0; i < n; i++) {
		let x = (i - (n - 1) / 2) * sp;
		let bk = 0;
		let p = i * 2 * Math.PI / n;
		if (t[0] === "v") {
			bk = (i % 2 ? 1 : -1) * 45 * D;
			if (t === "v2") {
				x = (i - .5) * .4;
				p = 0;
			} else x = (i - (n - 1) / 2) * b * (n > 3 ? .85 : 1);
			if (t === "v4") p = i === 1 || i === 2 ? Math.PI : 0;
			if (n > 4) {
				const q = Math.floor(i / 2);
				x = (q - (n / 4 - .5)) * (b + .45) + (i % 2 ? .2 : -.2);
				p = n === 8 ? [
					0,
					90,
					270,
					180
				][q] * D : q * 4 * Math.PI / n;
			}
		}
		if (t[0] === "f") {
			bk = (i % 2 ? 1 : -1) * 90 * D;
			if (t === "f2") {
				x = (i - .5) * .5;
				p = i ? Math.PI : 0;
			} else if (t === "f4") {
				p = [
					0,
					Math.PI,
					Math.PI,
					0
				][i];
				x = (Math.floor(i / 2) - .5) * sp + (i % 2 ? .2 : -.2);
			} else p += i % 2 ? Math.PI : 0;
		}
		if (t === "i2") p = i * Math.PI;
		if (t === "i4") p = [
			0,
			Math.PI,
			Math.PI,
			0
		][i];
		if (t === "w12") {
			const row = Math.floor(i / 3);
			const bn = i % 3;
			bk = (bn - 1) * 60 * D;
			x = (row - 1.5) * (b + .45) + (bn - 1) * b * .4;
			p = [
				0,
				Math.PI,
				Math.PI,
				0
			][row];
		}
		o.push({
			x,
			bk,
			p
		});
	}
	return o;
}
function curve(spec) {
	const n = CYL[spec.type];
	const cc = (spec.twin ? 2 : 1) * n * (Math.PI / 4) * (spec.bore / 10) ** 2 * (spec.stroke / 10);
	const red = (spec.fuel === "dsl" ? 5200 - (spec.stroke - 50) * 30 : 9500 - (spec.stroke - 50) * 60) * (spec.ecu ? 1 + spec.lim / 100 : 1);
	return {
		cc,
		n,
		red: Math.max(1800, red)
	};
}
var EXH_PWR = {
	stock: 1,
	sport: 1.03,
	straight: 1.05,
	open: 1.07
};
function perf(spec, rpm) {
	const e = curve(spec);
	const x = rpm / e.red;
	let pk = e.cc * .07 * (1 + .15 * (spec.bore / spec.stroke - 1));
	if (spec.carb) pk *= .94;
	if (spec.ecu) pk *= 1 + spec.map / 100;
	if (spec.fuel === "dsl") pk *= .75;
	pk *= EXH_PWR[spec.exh];
	let m = 1;
	const bf = spec.ecu ? 1 + spec.bst / 100 : 1;
	if (spec.turbo) m *= 1 + .35 * bf * Math.min(1, Math.max(0, (x - .25) / .4));
	if (spec.sc) m *= 1 + .22 * bf;
	const hp = Math.max(0, x * (1.4 - .4 * x)) * pk * m;
	return {
		hp,
		tq: hp * 7121 / Math.max(rpm, 1),
		cc: e.cc,
		red: e.red
	};
}
function layoutName(id, tr) {
	if (id === "single") return tr.single;
	if (id === "w12") return "W12";
	const n = id.slice(1);
	if (id.startsWith("v")) return `V${n}`;
	if (id.startsWith("f")) return `${tr.flat} ${n}`;
	return `${tr.inl} ${n}`;
}
function engineTitle(spec, tr) {
	const bits = [layoutName(spec.type, tr)];
	if (spec.fuel === "dsl") bits.push(tr.diesel);
	if (spec.ecu) bits.push("ECU");
	if (spec.twin) bits.push("×2");
	if (spec.turbo) bits.push("T");
	if (spec.sc) bits.push("SC");
	if (spec.carb) bits.push("CARB");
	return bits.join("  ");
}
var BGS = [
	"",
	"#000000",
	"#1b1e24",
	"#e9edf2",
	"#0d2b45",
	"#3a0f12",
	"#12351f"
];
function MakerPanel({ tr, lang, spec, volume, bg, onClose, onLang, onSpec, onVolume, onBg, pwa }) {
	const opts = [
		["carb", tr.carb],
		["turbo", tr.turbo],
		["sc", tr.sc]
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "z-20 flex w-full flex-col overflow-y-auto border-line bg-panel p-4 md:w-80 md:border-l max-md:fixed max-md:inset-x-0 max-md:bottom-0 max-md:max-h-[68dvh] max-md:rounded-t-2xl max-md:border-t",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-2 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-bold tracking-wide",
					children: tr.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "grid size-11 place-items-center rounded-lg",
					onClick: onClose,
					"aria-label": tr.close,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, { title: tr.hLayout }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-1.5",
				children: LAYOUTS.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-pressed": spec.type === id,
					className: chip(spec.type === id),
					onClick: () => onSpec({ type: id }),
					children: layoutName(id, tr)
				}, id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				"aria-pressed": spec.twin,
				className: `mt-1.5 ${chip(spec.twin, true)}`,
				onClick: () => onSpec({ twin: !spec.twin }),
				children: [spec.twin ? "✓  " : "", tr.twin]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, { title: tr.hDim }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
				label: tr.bore,
				value: `${spec.bore} mm`,
				min: 50,
				max: 110,
				v: spec.bore,
				onChange: (bore) => onSpec({ bore })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
				label: tr.stroke,
				value: `${spec.stroke} mm`,
				min: 50,
				max: 110,
				v: spec.stroke,
				onChange: (stroke) => onSpec({ stroke })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, { title: tr.hFuel }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-pressed": spec.fuel === "gas",
					className: chip(spec.fuel === "gas"),
					onClick: () => onSpec({ fuel: "gas" }),
					children: tr.fuelGas
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-pressed": spec.fuel === "dsl",
					className: chip(spec.fuel === "dsl"),
					onClick: () => onSpec({
						fuel: "dsl",
						carb: false
					}),
					children: tr.fuelDsl
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, { title: tr.hInduct }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-col gap-1.5",
				children: opts.filter(([k]) => !(k === "carb" && spec.fuel === "dsl")).map(([k, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					"aria-pressed": spec[k],
					className: chip(spec[k], true),
					onClick: () => onSpec({ [k]: !spec[k] }),
					children: [spec[k] ? "✓  " : "", label]
				}, k))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, { title: tr.hExh }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-1.5",
				children: [
					["stock", tr.xStock],
					["sport", tr.xSport],
					["straight", tr.xStraight],
					["open", tr.xOpen]
				].map(([k, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-pressed": spec.exh === k,
					className: chip(spec.exh === k),
					onClick: () => onSpec({
						exh: k,
						pop: k === "stock" ? spec.pop : true
					}),
					children: label
				}, k))
			}),
			spec.fuel !== "dsl" && spec.exh !== "stock" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				"aria-pressed": spec.pop,
				className: `mt-1.5 ${chip(spec.pop, true)}`,
				onClick: () => onSpec({ pop: !spec.pop }),
				children: [spec.pop ? "✓  " : "", tr.pop]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, { title: tr.hEcu }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				"aria-pressed": spec.ecu,
				className: chip(spec.ecu, true),
				onClick: () => onSpec({ ecu: !spec.ecu }),
				children: [spec.ecu ? "✓  " : "", tr.ecu]
			}),
			spec.ecu && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
						label: tr.map,
						value: `+${spec.map}%`,
						min: 0,
						max: 30,
						v: spec.map,
						onChange: (map) => onSpec({ map })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
						label: tr.lim,
						value: `${spec.lim > 0 ? "+" : ""}${spec.lim}%`,
						min: -10,
						max: 20,
						v: spec.lim,
						onChange: (lim) => onSpec({ lim })
					}),
					(spec.turbo || spec.sc) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
						label: tr.bst,
						value: `+${spec.bst}%`,
						min: 0,
						max: 50,
						v: spec.bst,
						onChange: (bst) => onSpec({ bst })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, { title: tr.hLang }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-1.5",
				children: LANGS.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-pressed": lang === l,
					className: chip(lang === l),
					onClick: () => onLang(l),
					children: LANG_LABEL[l]
				}, l))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, { title: tr.hBg }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [BGS.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": c || tr.auto,
					"aria-pressed": bg === c,
					className: `size-8 rounded-full border-2 ${c ? "" : "swatch-auto"} ${bg === c ? "border-accent" : "border-line"}`,
					style: c ? { background: c } : void 0,
					onClick: () => onBg(c)
				}, c || "auto")), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "color",
					"aria-label": tr.hBg,
					value: bg || "#101216",
					className: "size-8 cursor-pointer border-0 bg-transparent p-0",
					onChange: (e) => onBg(e.target.value)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, { title: tr.hSnd }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
				label: tr.vol,
				value: `${Math.round(volume * 100)}%`,
				min: 0,
				max: 100,
				v: Math.round(volume * 100),
				onChange: (v) => onVolume(v / 100)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, { title: tr.install }),
			pwa.installed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: tr.installReady
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-1.5",
				children: [pwa.canInstall && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: chip(true, true),
					onClick: pwa.onInstall,
					children: tr.installBtn
				}), pwa.ios && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: tr.installIos
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: `mt-1.5 ${chip(false, true)}`,
				onClick: pwa.onShare,
				children: tr.share
			}),
			pwa.shareNote === "copied" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-muted",
				children: tr.copied
			}),
			pwa.shareNote === "shared" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-muted",
				children: tr.shared
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, { title: tr.hCol }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2 pb-2",
				children: COLORS.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": c,
					"aria-pressed": spec.color === c,
					className: `size-8 rounded-full border-2 ${spec.color === c ? "border-accent" : "border-line"}`,
					style: { background: c },
					onClick: () => onSpec({ color: c })
				}, c))
			})
		]
	});
}
function Section({ title }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
		className: "mt-4 mb-1.5 text-xs font-semibold tracking-widest text-muted uppercase",
		children: title
	});
}
function chip(on, wide = false) {
	return `${wide ? "w-full text-left" : ""} rounded-lg border px-2 py-2 text-sm ${on ? "border-accent bg-accent font-semibold text-accent-fg" : "border-line bg-chip text-fg"}`;
}
function Slider({ label, value, min, max, v, onChange }) {
	const id = `sl-${label.replace(/\s+/g, "-")}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		htmlFor: id,
		className: "mt-1.5 block text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "mb-0.5 flex justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-muted",
				children: value
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			id,
			type: "range",
			min,
			max,
			value: v,
			onChange: (e) => onChange(Number(e.target.value))
		})]
	});
}
function isStandalone() {
	return window.matchMedia("(display-mode: standalone)").matches || "standalone" in navigator && Boolean(navigator.standalone);
}
function isIosDevice() {
	const ua = navigator.userAgent;
	return /iphone|ipad|ipod/i.test(ua) || navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1;
}
function usePwa() {
	const [canInstall, setCanInstall] = (0, import_react.useState)(false);
	const [installed, setInstalled] = (0, import_react.useState)(false);
	const [ios, setIos] = (0, import_react.useState)(false);
	const [shareNote, setShareNote] = (0, import_react.useState)("");
	const [promptEvent, setPromptEvent] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const standalone = isStandalone();
		setInstalled(standalone);
		setIos(isIosDevice() && !standalone);
		if ("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js", {
			scope: "/",
			updateViaCache: "none"
		}).catch(() => {});
		const onPrompt = (event) => {
			event.preventDefault();
			setPromptEvent(event);
			setCanInstall(true);
		};
		const onInstalled = () => {
			setInstalled(true);
			setCanInstall(false);
			setPromptEvent(null);
		};
		window.addEventListener("beforeinstallprompt", onPrompt);
		window.addEventListener("appinstalled", onInstalled);
		return () => {
			window.removeEventListener("beforeinstallprompt", onPrompt);
			window.removeEventListener("appinstalled", onInstalled);
		};
	}, []);
	async function install() {
		if (!promptEvent) return;
		await promptEvent.prompt();
		const choice = await promptEvent.userChoice;
		setPromptEvent(null);
		setCanInstall(false);
		if (choice.outcome === "accepted") setInstalled(true);
	}
	async function share() {
		const url = `${window.location.origin}/`;
		const payload = {
			title: "Engine Maker",
			text: "Engine Maker 1.0",
			url
		};
		if (navigator.share) try {
			await navigator.share(payload);
			setShareNote("shared");
			return;
		} catch {
			return;
		}
		try {
			await navigator.clipboard.writeText(url);
			setShareNote("copied");
		} catch {
			setShareNote("");
		}
	}
	return {
		canInstall,
		installed,
		ios,
		shareNote,
		install,
		share
	};
}
var KN = 44;
var GC = [
	30,
	70,
	110
];
var YT = 36;
var YM = 84;
var YB = 132;
var clamp = (v, a, b) => Math.min(b, Math.max(a, v));
var slot = (g) => g ? {
	x: GC[g - 1 >> 1],
	y: g % 2 ? YT : YB
} : {
	x: GC[1],
	y: YM
};
function Shifter({ gear, onShift }) {
	const track = (0, import_react.useRef)(null);
	const [pos, setPos] = (0, import_react.useState)(() => slot(0));
	const [drag, setDrag] = (0, import_react.useState)(false);
	const posRef = (0, import_react.useRef)(pos);
	posRef.current = pos;
	(0, import_react.useEffect)(() => {
		if (!drag) setPos(slot(gear));
	}, [gear, drag]);
	function move(px, py) {
		let { x, y } = posRef.current;
		if (Math.abs(y - YM) > 8) {
			y = clamp(py, YT, YB);
			if (Math.abs(y - YM) <= 8) y = YM;
		} else {
			const nc = GC.find((c) => Math.abs(x - c) < 8);
			if (nc !== void 0 && Math.abs(py - YM) > 12) {
				x = nc;
				y = clamp(py, YT, YB);
			} else {
				x = clamp(px, GC[0], GC[2]);
				y = YM;
				const c = GC.find((col) => Math.abs(x - col) < 8);
				if (c !== void 0) x = c;
			}
		}
		const next = {
			x,
			y
		};
		posRef.current = next;
		setPos(next);
	}
	function pointer(e) {
		const r = track.current.getBoundingClientRect();
		move(e.clientX - r.left, e.clientY - r.top);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: track,
		className: "shifter relative shrink-0 rounded-xl border border-line bg-panel",
		onPointerDown: (e) => {
			track.current?.setPointerCapture(e.pointerId);
			setDrag(true);
			pointer(e);
		},
		onPointerMove: (e) => {
			if (drag) pointer(e);
		},
		onPointerUp: () => {
			if (!drag) return;
			setDrag(false);
			const ci = GC.indexOf(posRef.current.x);
			let g = 0;
			if (ci >= 0) {
				if (posRef.current.y <= 42) g = ci * 2 + 1;
				else if (posRef.current.y >= 126) g = ci * 2 + 2;
			}
			const snapped = slot(onShift(g));
			posRef.current = snapped;
			setPos(snapped);
		},
		onPointerCancel: () => setDrag(false),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute h-1.5 rounded-sm bg-line",
				style: {
					left: GC[0] - 3,
					top: 81,
					width: GC[2] - GC[0] + 6
				}
			}),
			GC.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute w-1.5 rounded-sm bg-line",
				style: {
					left: c - 3,
					top: 33,
					height: 102
				}
			}, c)),
			Array.from({ length: 6 }, (_, i) => i + 1).map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "absolute w-4 -translate-x-1/2 text-center text-xs font-semibold text-muted",
				style: {
					left: GC[g - 1 >> 1],
					top: g % 2 ? 6 : 148
				},
				children: g
			}, g)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `knob absolute grid size-11 place-items-center rounded-full bg-accent text-base font-bold text-accent-fg shadow-md ${drag ? "transition-none" : ""}`,
				style: {
					left: pos.x - KN / 2,
					top: pos.y - KN / 2
				},
				children: gear || "N"
			})
		]
	});
}
var evn = (n, j) => Array.from({ length: n }, (_, i) => i ? (i + (i % 2 ? j : -j)) / n : 0);
var SCH = {
	single: [0],
	v2: [0, .375],
	f2: [0, .5],
	i2: [0, .25],
	v3: [
		0,
		.3,
		.67
	],
	i3: [
		0,
		1 / 3,
		2 / 3
	],
	f3: [
		0,
		1 / 3,
		2 / 3
	],
	v4: [
		0,
		.2,
		.5,
		.7
	],
	i4: [
		0,
		.25,
		.5,
		.75
	],
	f4: [
		0,
		.23,
		.5,
		.73
	],
	i5: [
		0,
		.2,
		.4,
		.6,
		.8
	],
	v6: [
		0,
		.14,
		.33,
		.47,
		.67,
		.81
	],
	v8: [
		0,
		.12,
		.27,
		.37,
		.5,
		.62,
		.77,
		.87
	],
	v10: evn(10, .12),
	v12: evn(12, 0),
	w12: evn(12, .05)
};
var TIM = {
	single: [
		.8,
		.5,
		1.2
	],
	v2: [
		.9,
		.9,
		1
	],
	f2: [
		1,
		.6,
		.9
	],
	i2: [
		1.3,
		.6,
		1.1
	],
	v3: [
		1,
		.7,
		1
	],
	i3: [
		1.15,
		.5,
		1.2
	],
	f3: [
		.95,
		.8,
		.9
	],
	v4: [
		1.05,
		.6,
		.8
	],
	i4: [
		1.3,
		.5,
		1
	],
	f4: [
		.9,
		.9,
		.85
	],
	i5: [
		1.15,
		.6,
		1
	],
	v6: [
		1,
		.7,
		.9
	],
	v8: [
		.75,
		1,
		1.2
	],
	v10: [
		1.05,
		.8,
		.8
	],
	v12: [
		1.2,
		.5,
		.7
	],
	w12: [
		1.1,
		.7,
		.8
	]
};
var EXH = {
	stock: [
		.7,
		.8,
		0,
		.35,
		1.1
	],
	sport: [
		1.1,
		1,
		.2,
		.5,
		1
	],
	straight: [
		1.5,
		1.15,
		.4,
		.7,
		.9
	],
	open: [
		2.2,
		1.3,
		.7,
		.95,
		.7
	]
};
var EngineAudio = class {
	getSpec;
	getLive;
	ac = null;
	mg = null;
	cmp = null;
	tOsc = null;
	tG = null;
	sOsc = null;
	sG = null;
	gB = null;
	gG = null;
	bq = null;
	bqG = null;
	nbuf = null;
	on = false;
	vol = .7;
	spool = 0;
	prevThr = 0;
	nextBov = 0;
	PH = [0, 0];
	BP = [0, 0];
	EN = [0, 0];
	AM = [1, 1];
	CK = [0, 0];
	lp = 0;
	n1 = 0;
	constructor(getSpec, getLive) {
		this.getSpec = getSpec;
		this.getLive = getLive;
	}
	get enabled() {
		return this.on;
	}
	setVolume(v) {
		this.vol = v;
		if (this.mg) this.mg.gain.value = v * .85;
	}
	toggle() {
		this.ensure();
		if (!this.ac) return this.on;
		this.on = !this.on;
		if (this.on) this.ac.resume();
		else this.ac.suspend();
		return this.on;
	}
	ensure() {
		if (this.ac) {
			if (this.ac.state === "suspended" && this.on) this.ac.resume();
			return;
		}
		const ac = new (window.AudioContext || window.webkitAudioContext)();
		this.ac = ac;
		const cmp = ac.createDynamicsCompressor();
		cmp.threshold.value = -14;
		cmp.knee.value = 16;
		cmp.ratio.value = 4;
		cmp.attack.value = .004;
		cmp.release.value = .18;
		const mg = ac.createGain();
		mg.gain.value = this.vol * .85;
		cmp.connect(mg);
		mg.connect(ac.destination);
		this.cmp = cmp;
		this.mg = mg;
		const sp = ac.createScriptProcessor(2048, 0, 1);
		sp.onaudioprocess = (e) => this.process(e);
		sp.connect(cmp);
		const tOsc = ac.createOscillator();
		const tG = ac.createGain();
		tG.gain.value = 0;
		tOsc.connect(tG);
		tG.connect(cmp);
		tOsc.start();
		this.tOsc = tOsc;
		this.tG = tG;
		const sOsc = ac.createOscillator();
		sOsc.type = "sawtooth";
		const sf = ac.createBiquadFilter();
		sf.type = "lowpass";
		sf.frequency.value = 3500;
		const sG = ac.createGain();
		sG.gain.value = 0;
		sOsc.connect(sf);
		sf.connect(sG);
		sG.connect(cmp);
		sOsc.start();
		this.sOsc = sOsc;
		this.sG = sG;
		const nbuf = ac.createBuffer(1, ac.sampleRate, ac.sampleRate);
		const d = nbuf.getChannelData(0);
		for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
		this.nbuf = nbuf;
		const gs = ac.createBufferSource();
		gs.buffer = nbuf;
		gs.loop = true;
		const gB = ac.createBiquadFilter();
		gB.type = "bandpass";
		gB.frequency.value = 700;
		gB.Q.value = 1.5;
		const gG = ac.createGain();
		gG.gain.value = 0;
		gs.connect(gB);
		gB.connect(gG);
		gG.connect(cmp);
		gs.start();
		this.gB = gB;
		this.gG = gG;
		const bq = ac.createOscillator();
		bq.type = "sawtooth";
		const bpf = ac.createBiquadFilter();
		bpf.type = "bandpass";
		bpf.frequency.value = 2e3;
		bpf.Q.value = 10;
		const bqG = ac.createGain();
		bqG.gain.value = 0;
		bq.connect(bpf);
		bpf.connect(bqG);
		bqG.connect(cmp);
		bq.start();
		this.bq = bq;
		this.bqG = bqG;
	}
	process(e) {
		const ac = this.ac;
		if (!ac) return;
		const o = e.outputBuffer.getChannelData(0);
		const spec = this.getSpec();
		const live = this.getLive();
		const sr = ac.sampleRate;
		const c = curve(spec);
		const rpm = live.dead || live.stall ? 0 : live.rpm;
		const x = Math.min(1.3, rpm / c.red);
		const sch = SCH[spec.type];
		const tm = TIM[spec.type];
		const dz = spec.fuel === "dsl";
		const th = .4 + .6 * live.thr;
		const ex = EXH[spec.exh];
		const bf = (90 + rpm * .025) * (70 / spec.bore) * tm[0] * (dz ? .65 : 1);
		const dec = Math.exp(-1 / (sr * (.012 + .02 / (1 + rpm / 2e3)) * tm[2] * (dz ? .9 : 1) * ex[4]));
		const k = 1 - Math.exp(-6.283 * (dz ? 180 + rpm * .45 : 250 + rpm * .7) * (.6 + .4 * live.thr) * ex[0] / sr);
		const kd = Math.exp(-1 / (sr * .0015));
		const ir = spec.carb ? .6 * x : 0;
		const step = rpm > 0 ? rpm / 120 / sr : 0;
		const nv = spec.twin ? 2 : 1;
		for (let i = 0; i < o.length; i++) {
			let v = 0;
			let tk = 0;
			const nz = Math.random() * 2 - 1;
			for (let w = 0; w < nv; w++) {
				const pv = this.PH[w];
				const dt2 = w ? 1.015 : 1;
				this.PH[w] = pv + step * dt2;
				if (this.PH[w] >= 1) this.PH[w] = this.PH[w] - 1;
				const ph = this.PH[w];
				if (rpm > 0 && !live.cut) for (let j = 0; j < sch.length; j++) {
					const q = sch[j];
					if (ph < pv ? q > pv || q <= ph : q > pv && q <= ph) {
						this.EN[w] = 1;
						this.BP[w] = 0;
						this.AM[w] = ((dz ? .6 : .75) + (dz ? .4 : .25) * Math.random()) * (live.rel ? 1.7 : 1);
						live.rel = false;
						this.CK[w] = 1;
						break;
					}
				}
				this.EN[w] = this.EN[w] * dec;
				this.CK[w] = this.CK[w] * kd;
				this.BP[w] = this.BP[w] + 6.283 * bf * dt2 / sr;
				const bp = this.BP[w];
				const env = this.EN[w];
				const amp = this.AM[w];
				v += dz ? (Math.sin(bp) + .35 * Math.sin(bp * 3.1) + nz * .9) * env * amp : (Math.sin(bp) + (tm[1] + ex[2]) * Math.sin(bp * 2.01) + ex[2] * .6 * Math.sin(bp * 3.02) + nz * ex[3]) * env * amp;
				tk += this.CK[w];
			}
			this.lp += (v - this.lp) * k;
			this.n1 += (Math.random() * 2 - 1 - this.n1) * .04;
			o[i] = rpm > 0 ? (this.lp * .9 + this.n1 * ir + (dz ? nz * tk * .3 : 0)) * th * ex[1] * (nv > 1 ? .85 : 1) : 0;
		}
	}
	update(dt) {
		const ac = this.ac;
		if (!ac || !this.on || !this.tOsc || !this.tG || !this.sOsc || !this.sG || !this.bq || !this.bqG || !this.gG || !this.gB) return;
		const spec = this.getSpec();
		const live = this.getLive();
		const c = curve(spec);
		const x = Math.min(1.2, live.rpm / c.red);
		const t = ac.currentTime;
		this.bqG.gain.setTargetAtTime(live.brake > .5 && live.spd > 2 ? Math.min(.05, live.spd / 30 * .05) * (.7 + .3 * Math.random()) : 0, t, .05);
		this.bq.frequency.setTargetAtTime(1400 + live.spd * 15, t, .1);
		if (live.dead) {
			this.tG.gain.setTargetAtTime(0, t, .05);
			this.sG.gain.setTargetAtTime(0, t, .05);
			const sp = live.spd;
			this.gG.gain.setTargetAtTime(Math.min(.3, sp / 25 * .3) * (.6 + .4 * Math.random()), t, .05);
			this.gB.frequency.setTargetAtTime(300 + sp * 30, t, .1);
			if (Math.random() < dt * sp * .25) this.clank(t);
			return;
		}
		this.gG.gain.setTargetAtTime(0, t, .05);
		const tgt = spec.turbo && live.rpm > 50 ? Math.min(1, Math.max(0, (x - .15) / .6)) * (.25 + .75 * live.thr) : 0;
		this.spool += (tgt - this.spool) * Math.min(1, dt * (tgt > this.spool ? 1.2 : 2.5));
		this.tOsc.frequency.setTargetAtTime(900 + 4200 * this.spool, t, .05);
		this.tG.gain.setTargetAtTime(spec.turbo ? .05 * this.spool * this.spool * (spec.ecu ? 1 + spec.bst / 150 : 1) + .004 * this.spool : 0, t, .05);
		if (spec.turbo && this.spool > .45 && this.prevThr > .6 && live.thr < .3 && t > this.nextBov) {
			this.bov(t);
			this.nextBov = t + 1;
		}
		this.prevThr = live.thr;
		this.sOsc.frequency.setTargetAtTime(150 + live.rpm * .45, t, .05);
		this.sG.gain.setTargetAtTime(spec.sc && live.rpm > 50 ? .035 * (.35 + x * .65) * (.5 + .5 * live.thr) : 0, t, .05);
	}
	bov(t) {
		if (!this.ac || !this.nbuf || !this.cmp) return;
		const s = this.ac.createBufferSource();
		s.buffer = this.nbuf;
		const h = this.ac.createBiquadFilter();
		h.type = "bandpass";
		h.frequency.value = 3200;
		h.Q.value = .8;
		const g = this.ac.createGain();
		g.gain.setValueAtTime(.4, t);
		g.gain.exponentialRampToValueAtTime(.001, t + .6);
		s.connect(h);
		h.connect(g);
		g.connect(this.cmp);
		s.start(t);
		s.stop(t + .7);
	}
	clank(t) {
		if (!this.ac || !this.cmp) return;
		const oc = this.ac.createOscillator();
		const gc = this.ac.createGain();
		oc.type = "square";
		oc.frequency.value = 250 + Math.random() * 1400;
		gc.gain.setValueAtTime(.1, t);
		gc.gain.exponentialRampToValueAtTime(.001, t + .1);
		oc.connect(gc);
		gc.connect(this.cmp);
		oc.start(t);
		oc.stop(t + .12);
	}
	grind() {
		if (!this.ac || !this.on) return;
		const t = this.ac.currentTime;
		for (let i = 0; i < 9; i++) this.clank(t + i * .025);
	}
	starter() {
		if (!this.ac || !this.on || !this.cmp) return;
		const t = this.ac.currentTime;
		const o = this.ac.createOscillator();
		const f = this.ac.createBiquadFilter();
		const g = this.ac.createGain();
		o.type = "sawtooth";
		o.frequency.value = 58;
		f.type = "lowpass";
		f.frequency.value = 420;
		g.gain.value = 0;
		o.connect(f);
		f.connect(g);
		g.connect(this.cmp);
		o.start(t);
		for (let i = 0; i < 14; i++) {
			const tt = t + i * .065;
			g.gain.setValueAtTime(.2, tt);
			g.gain.linearRampToValueAtTime(.03, tt + .05);
		}
		g.gain.setValueAtTime(0, t + .91);
		o.stop(t + .95);
	}
	boom() {
		if (!this.ac || !this.on || !this.cmp || !this.nbuf) return;
		const t = this.ac.currentTime;
		const nz = (f0, f1, ty, gn, d) => {
			const s = this.ac.createBufferSource();
			s.buffer = this.nbuf;
			s.loop = true;
			const fl = this.ac.createBiquadFilter();
			fl.type = ty;
			fl.frequency.setValueAtTime(f0, t);
			if (f1) fl.frequency.exponentialRampToValueAtTime(f1, t + d);
			const g = this.ac.createGain();
			g.gain.setValueAtTime(gn, t);
			g.gain.exponentialRampToValueAtTime(.001, t + d);
			s.connect(fl);
			fl.connect(g);
			g.connect(this.cmp);
			s.start(t);
			s.stop(t + d + .1);
		};
		nz(1800, 120, "lowpass", 1, 1.4);
		nz(3500, 400, "highpass", .12, 1.2);
		const o = this.ac.createOscillator();
		const og = this.ac.createGain();
		o.frequency.setValueAtTime(110, t);
		o.frequency.exponentialRampToValueAtTime(30, t + .5);
		og.gain.setValueAtTime(1.2, t);
		og.gain.exponentialRampToValueAtTime(.001, t + .6);
		o.connect(og);
		og.connect(this.cmp);
		o.start(t);
		o.stop(t + .7);
		for (let i = 0; i < 6; i++) {
			const tt = t + .05 + i * .11 + Math.random() * .05;
			this.clank(tt);
		}
	}
	pop(delay = 0) {
		if (!this.ac || !this.on || !this.cmp || !this.nbuf) return;
		const t = this.ac.currentTime + delay;
		const sn = this.ac.createBufferSource();
		sn.buffer = this.nbuf;
		const f = this.ac.createBiquadFilter();
		f.type = "bandpass";
		f.frequency.value = 500 + Math.random() * 900;
		f.Q.value = .7;
		const g = this.ac.createGain();
		g.gain.setValueAtTime(.5 + Math.random() * .4, t);
		g.gain.exponentialRampToValueAtTime(.001, t + .09);
		sn.connect(f);
		f.connect(g);
		g.connect(this.cmp);
		sn.start(t, Math.random() * .5);
		sn.stop(t + .12);
	}
};
var PG = new SphereGeometry(.3, 8, 6);
var VIS = .1;
function M(color, metal = .4, rough = .5) {
	return new MeshStandardMaterial({
		color,
		metalness: metal,
		roughness: rough
	});
}
function cyl(rt, rb, h, mat, seg = 24) {
	return new Mesh(new CylinderGeometry(rt, rb, h, seg), mat);
}
function ax(m) {
	m.rotation.z = Math.PI / 2;
	return m;
}
function bakeMerge(root) {
	root.updateMatrixWorld(true);
	const inv = new Matrix4().copy(root.matrixWorld).invert();
	const buckets = /* @__PURE__ */ new Map();
	const found = [];
	root.traverse((obj) => {
		const mesh = obj;
		if (!mesh.isMesh || mesh.userData.live) return;
		let p = mesh.parent;
		while (p && p !== root) {
			if (p.userData.live) return;
			p = p.parent;
		}
		found.push(mesh);
	});
	for (const mesh of found) {
		const mat = mesh.material;
		if (Array.isArray(mat)) continue;
		const g = mesh.geometry.clone();
		g.applyMatrix4(new Matrix4().multiplyMatrices(inv, mesh.matrixWorld));
		let b = buckets.get(mat);
		if (!b) {
			b = {
				geos: [],
				meshes: []
			};
			buckets.set(mat, b);
		}
		b.geos.push(g);
		b.meshes.push(mesh);
	}
	for (const [mat, b] of buckets) {
		if (b.meshes.length < 2) {
			for (const g of b.geos) g.dispose();
			continue;
		}
		const merged = (() => {
			try {
				return mergeGeometries(b.geos);
			} catch {
				return null;
			}
		})();
		for (const g of b.geos) g.dispose();
		if (!merged) continue;
		for (const m of b.meshes) {
			m.geometry.dispose();
			m.removeFromParent();
		}
		root.add(new Mesh(merged, mat));
	}
}
function buildUnit(spec) {
	const engine = new Group();
	const b = spec.bore / 50;
	const r = spec.stroke / 100;
	const L = r * 3;
	const journals = layout(spec.type, b);
	const cm = M(spec.color, .35, .45);
	const steel = M("#c4cad4", .55, .32);
	const dark = M("#2a2e35", .45, .5);
	const xs = journals.map((c) => c.x);
	const x0 = Math.min(...xs) - .5 * b - .3;
	const x1 = Math.max(...xs) + .5 * b + .3;
	const crank = new Group();
	const sh = ax(cyl(.16, .16, x1 - x0 + .4, steel));
	sh.position.x = (x0 + x1) / 2;
	crank.add(sh);
	for (const c of journals) {
		const cs = Math.cos(c.p);
		const sn = Math.sin(c.p);
		const pin = ax(cyl(.13, .13, .4, steel));
		pin.position.set(c.x, r * cs, r * sn);
		crank.add(pin);
		for (const dx of [-.2, .2]) {
			const w = new Mesh(new BoxGeometry(.08, r + .3, .4), dark);
			w.position.set(c.x + dx, r * cs / 2, r * sn / 2);
			w.rotation.x = c.p;
			crank.add(w);
		}
	}
	const fr = Math.max(.9, r + .4);
	const fw = ax(cyl(fr, fr, .25, steel, 32));
	fw.position.x = x1 + .3;
	crank.add(fw);
	const mk = new Mesh(new BoxGeometry(.28, .2, .12), M("#e8590c"));
	mk.position.set(x1 + .3, fr * .75, 0);
	crank.add(mk);
	engine.add(crank);
	const glass = new MeshStandardMaterial({
		color: spec.color,
		transparent: true,
		opacity: .16,
		metalness: .3,
		roughness: .45,
		depthWrite: false
	});
	const cc = ax(cyl(r + .55, r + .55, x1 - x0, glass));
	cc.position.x = (x0 + x1) / 2;
	engine.add(cc);
	const sump = new Mesh(new BoxGeometry(x1 - x0 + .2, r + .45, (r + .55) * 1.7), dark);
	sump.position.set((x0 + x1) / 2, -r * .35, 0);
	engine.add(sump);
	const top = r + L + .3 * b;
	const s0 = L - r - .4 * b;
	const len = top - s0;
	const linerMat = new MeshStandardMaterial({
		color: spec.color,
		transparent: true,
		opacity: .22,
		side: 2,
		metalness: .3,
		roughness: .45,
		depthWrite: false
	});
	const cyls = [];
	const dz = spec.fuel === "dsl";
	for (const c of journals) {
		const g = new Group();
		g.position.x = c.x;
		g.rotation.x = c.bk;
		const ln = cyl(b / 2 + .1, b / 2 + .1, len, linerMat, 24);
		ln.position.y = s0 + len / 2;
		g.add(ln);
		for (let k = 1; k < 5; k++) {
			const f = cyl(b / 2 + .2, b / 2 + .2, .04, cm, 24);
			f.position.y = s0 + len * k / 5.5;
			g.add(f);
		}
		const hd = cyl(b / 2 + .15, b / 2 + .15, .4 * b, cm, 24);
		hd.position.y = top + .2 * b;
		g.add(hd);
		const pl = cyl(dz ? .09 : .06, dz ? .09 : .06, .45, dz ? M("#d9480f") : steel, 10);
		pl.position.y = top + .4 * b + .2;
		g.add(pl);
		engine.add(g);
		const pg = new Group();
		pg.position.x = c.x;
		pg.rotation.x = c.bk;
		const pm = cyl(b / 2 - .03, b / 2 - .03, .6 * b, steel, 20);
		pm.position.y = -.05 * b;
		pg.add(pm);
		const rg = cyl(b / 2 - .01, b / 2 - .01, .04, dark, 20);
		rg.position.y = .15 * b;
		pg.add(rg);
		pg.add(ax(cyl(.07, .07, .3, dark, 10)));
		engine.add(pg);
		const rod = new Mesh(new BoxGeometry(.12, L, .09), dark);
		rod.userData.live = true;
		engine.add(rod);
		cyls.push({
			c,
			pg,
			rod,
			prevStroke: 0
		});
	}
	const spin = [];
	const spinner = (parent, x, y0, rad, col) => {
		const g = new Group();
		g.position.set(x, y0, 0);
		g.add(new Mesh(new BoxGeometry(.08, rad * 1.8, .14), M(col)));
		g.add(new Mesh(new BoxGeometry(.08, .14, rad * 1.8), M(col)));
		parent.add(g);
		spin.push(g);
		return g;
	};
	let yStack = top + .7 * b;
	let hot = null;
	if (spec.sc) {
		const g = new Group();
		const bd = new Mesh(new BoxGeometry(1.8, .8, 1.1), M("#3a4049", .5, .4));
		g.add(bd);
		for (let k = -1; k <= 1; k++) {
			const f = new Mesh(new BoxGeometry(.08, .86, 1.16), steel);
			f.position.x = k * .55;
			g.add(f);
		}
		const pu = ax(cyl(.38, .38, .16, steel));
		pu.position.x = 1.05;
		g.add(pu);
		spinner(g, 1.15, 0, .3, "#e8590c");
		g.position.set((x0 + x1) / 2, yStack + .45, 0);
		engine.add(g);
		yStack += 1.05;
	}
	if (spec.carb) {
		const g = new Group();
		g.add(cyl(.5, .5, .6, M("#c9a227", .6, .35)));
		const fl = cyl(.9, .9, .3, steel, 28);
		fl.position.y = .5;
		g.add(fl);
		const th = ax(cyl(.18, .18, 1.1, steel, 12));
		th.position.y = -.1;
		g.add(th);
		g.position.set((x0 + x1) / 2, yStack + .45, 0);
		engine.add(g);
		yStack += 1.1;
	}
	if (spec.turbo) {
		const g = new Group();
		g.position.set((x0 + x1) / 2, .15, r + 1.35);
		hot = new MeshStandardMaterial({
			color: "#8a3412",
			emissive: 16731392,
			emissiveIntensity: 0,
			metalness: .4,
			roughness: .5
		});
		const t = ax(cyl(.75, .5, .8, hot));
		t.position.x = .6;
		const cp = ax(cyl(.5, .7, .7, steel));
		cp.position.x = -.6;
		const st = ax(cyl(.1, .1, .5, dark, 10));
		g.add(t, cp, st);
		spinner(g, 1.02, 0, .5, "#ffd8a8");
		spinner(g, -.97, 0, .55, "#9ec5ff");
		const p1 = cyl(.16, .16, 1.1, M("#6b7280", .5, .5), 12);
		p1.rotation.x = Math.PI / 2;
		p1.position.set(.6, 0, -.55);
		const p2 = cyl(.14, .14, 1.1, M("#2f6fd0", .4, .4), 12);
		p2.rotation.x = Math.PI / 2;
		p2.position.set(-.6, .1, -.55);
		g.add(p1, p2);
		engine.add(g);
	}
	const ey = -.15;
	const ez = -(r + .95);
	const header = ax(cyl(.16, .16, x1 - x0, M("#8a5a2b", .5, .5)));
	header.position.set((x0 + x1) / 2, ey, ez);
	engine.add(header);
	const cf = {
		stock: [
			.5,
			2.2,
			"#555b66"
		],
		sport: [
			.36,
			2,
			"#aeb6c2"
		],
		straight: [
			.24,
			2,
			"#b9c0cb"
		],
		open: [
			.2,
			.9,
			"#9aa3b0"
		]
	}[spec.exh];
	const muff = ax(cyl(Number(cf[0]), Number(cf[0]), Number(cf[1]), M(String(cf[2]), .6, .35)));
	muff.position.set(x1 + .3 + Number(cf[1]) / 2, ey, ez);
	engine.add(muff);
	const tipM = ax(cyl(spec.exh === "open" ? .34 : Number(cf[0]) * .7, Number(cf[0]) * .7, .35, M("#d5dae2", .8, .25)));
	tipM.position.set(x1 + .3 + Number(cf[1]) + .1, ey, ez);
	engine.add(tipM);
	const tip = new Vector3(x1 + .3 + Number(cf[1]) + .3, ey, ez);
	const fx = new Group();
	engine.add(fx);
	const lt = new PointLight(16733440, 0, 8);
	lt.position.set((x0 + x1) / 2, top, 0);
	engine.add(lt);
	fx.userData.light = lt;
	const sparkMat = new MeshBasicMaterial({
		color: 16774872,
		transparent: true,
		opacity: 0,
		depthWrite: false,
		toneMapped: false
	});
	const spark = new Mesh(new SphereGeometry(.09, 8, 6), sparkMat);
	spark.userData.live = true;
	spark.visible = false;
	fx.add(spark);
	fx.userData.spark = spark;
	const pool = [];
	for (let i = 0; i < 28; i++) {
		const mat = new MeshBasicMaterial({
			color: 16777215,
			transparent: true,
			opacity: 0,
			depthWrite: false,
			toneMapped: false
		});
		const m = new Mesh(PG, mat);
		m.userData.live = true;
		m.visible = false;
		fx.add(m);
		pool.push(m);
	}
	for (const c of cyls) {
		bakeMerge(c.pg);
		c.pg.userData.live = true;
	}
	for (const s of spin) {
		bakeMerge(s);
		s.userData.live = true;
	}
	bakeMerge(crank);
	crank.userData.live = true;
	bakeMerge(engine);
	return {
		root: engine,
		crank,
		cyl: cyls,
		spin,
		hot,
		tip,
		fx,
		r,
		L,
		top,
		pool
	};
}
function disposeTree(root) {
	const geos = /* @__PURE__ */ new Set();
	const mats = /* @__PURE__ */ new Set();
	root.traverse((o) => {
		const m = o;
		if (m.geometry && m.geometry !== PG) geos.add(m.geometry);
		const mat = m.material;
		if (!mat) return;
		if (Array.isArray(mat)) mat.forEach((x) => mats.add(x));
		else mats.add(mat);
	});
	geos.forEach((g) => g.dispose());
	mats.forEach((m) => m.dispose());
}
var EngineScene = class {
	renderer;
	scene = new Scene();
	camera = new PerspectiveCamera(35, 1, .1, 100);
	root = new Group();
	shadow;
	units = [];
	holder = null;
	pt = [];
	flow = [];
	fly = null;
	blown = false;
	yaw = -.62;
	pitch = .18;
	ang = 0;
	constructor(canvas) {
		this.renderer = new WebGLRenderer({
			canvas,
			antialias: true,
			alpha: true
		});
		this.renderer.setPixelRatio(Math.min(devicePixelRatio || 1, 2));
		this.renderer.setClearColor(0, 0);
		this.scene.add(new HemisphereLight(16777215, 5595248, 1.05));
		const dl = new DirectionalLight(16777215, 1.25);
		dl.position.set(5, 8, 6);
		this.scene.add(dl);
		const dl2 = new DirectionalLight(11189247, .45);
		dl2.position.set(-6, 2, -4);
		this.scene.add(dl2);
		this.root.rotation.order = "YXZ";
		this.scene.add(this.root);
		const shadow = new Mesh(new CircleGeometry(1, 40), new MeshBasicMaterial({
			color: 0,
			transparent: true,
			opacity: .28
		}));
		shadow.rotation.x = -Math.PI / 2;
		this.shadow = shadow;
		this.scene.add(shadow);
		this.applyPose();
	}
	resize() {
		const canvas = this.renderer.domElement;
		const w = canvas.clientWidth || 1;
		const h = canvas.clientHeight || 1;
		this.renderer.setSize(w, h, false);
		this.camera.aspect = w / h;
		const portrait = w / h < 1;
		const z = portrait ? 9.4 / (w / h) * .66 : 9.4;
		this.camera.position.set(0, z * (portrait ? .2 : .22), z);
		this.camera.lookAt(0, portrait ? -.25 : -.4, 0);
		this.camera.updateProjectionMatrix();
	}
	orbit(dx, dy) {
		this.yaw -= dx * .008;
		this.pitch = Math.min(.9, Math.max(-.35, this.pitch + dy * .006));
		this.applyPose();
	}
	resetView() {
		this.yaw = -.62;
		this.pitch = .18;
		this.applyPose();
	}
	applyPose() {
		this.root.rotation.y = this.yaw;
		this.root.rotation.x = this.pitch;
	}
	rebuild(spec) {
		if (this.holder) {
			this.root.remove(this.holder);
			disposeTree(this.holder);
		}
		this.pt = [];
		this.flow = [];
		this.fly = null;
		this.blown = false;
		this.root.position.x = 0;
		const a = buildUnit(spec);
		const holder = new Group();
		holder.add(a.root);
		this.units = [a];
		if (spec.twin) {
			const b = buildUnit(spec);
			const box = new Box3().setFromObject(a.root);
			const dz = box.max.z - box.min.z + .85;
			b.root.position.z = -dz;
			holder.add(b.root);
			this.units.push(b);
		}
		const box = new Box3().setFromObject(holder);
		const size = box.getSize(new Vector3());
		const center = box.getCenter(new Vector3());
		holder.position.copy(center).negate();
		this.root.scale.setScalar(9.15 / Math.max(.001, size.length()));
		this.root.add(holder);
		this.holder = holder;
		this.root.updateMatrixWorld(true);
		const wb = new Box3().setFromObject(this.root);
		const span = Math.max(wb.max.x - wb.min.x, wb.max.z - wb.min.z);
		this.shadow.position.y = wb.min.y + .02;
		this.shadow.scale.setScalar(Math.max(1.2, span * .42));
	}
	blow() {
		if (!this.holder || this.blown) return;
		this.blown = true;
		const seen = /* @__PURE__ */ new Set();
		this.holder.traverse((o) => {
			const m = o.material;
			if (!m) return;
			const list = Array.isArray(m) ? m : [m];
			for (const mat of list) {
				if (seen.has(mat)) continue;
				seen.add(mat);
				const sm = mat;
				if (sm.color) sm.color.multiplyScalar(.4);
			}
		});
		const unit = this.units[0];
		if (!unit || unit.cyl.length === 0) return;
		const cyl = unit.cyl[Math.floor(Math.random() * unit.cyl.length)];
		const a = cyl.c.bk;
		const rnd = Math.random;
		this.fly = {
			cyl,
			v: new Vector3((rnd() - .5) * 3, Math.cos(a) * 16, Math.sin(a) * 16),
			rv: new Vector3((rnd() - .5) * 4, Math.cos(a) * 10, Math.sin(a) * 10)
		};
	}
	flame() {
		for (const u of this.units) {
			const n = 3;
			for (let i = 0; i < n; i++) this.puffAt(u, true, true);
		}
	}
	puffAt(unit, fire, exhaust) {
		if (this.pt.length > 120) return;
		const mat = new MeshBasicMaterial({
			color: fire ? 16738816 : 3355443,
			transparent: true,
			opacity: fire ? .9 : .55,
			toneMapped: false
		});
		const m = new Mesh(PG, mat);
		if (exhaust) {
			m.position.copy(unit.tip);
			m.position.y += (Math.random() - .5) * .1;
			m.scale.setScalar(.35 + Math.random() * .25);
			unit.fx.add(m);
			this.pt.push({
				m,
				f: true,
				t: 0,
				l: .15 + Math.random() * .15,
				v: new Vector3(3 + Math.random() * 5, Math.random() - .5, Math.random() - .5)
			});
			return;
		}
		const src = unit.fx.userData.light?.position ?? new Vector3();
		m.position.set(src.x + (Math.random() - .5) * 2.2, src.y + Math.random() * .4, src.z + (Math.random() - .5) * 1.4);
		m.scale.setScalar(fire ? .5 + Math.random() * .5 : .5 + Math.random() * .7);
		unit.fx.add(m);
		this.pt.push({
			m,
			f: fire,
			t: 0,
			l: fire ? .5 + Math.random() * .4 : 2 + Math.random() * 2.5,
			v: new Vector3((Math.random() - .5) * (fire ? 5 : 1.2), (fire ? 3 : 1.6) + Math.random() * (fire ? 4 : 1.2), (Math.random() - .5) * (fire ? 5 : 1.2))
		});
	}
	advance(dt, live, spec) {
		const rpm = live.dead ? Math.min(live.rpm, 2500) : live.rpm;
		this.ang += dt * (rpm / 60) * Math.PI * 2 * VIS;
		for (const u of this.units) this.pose(u);
		const red = Math.max(1, curve(spec).red);
		for (const u of this.units) {
			if (u.hot) u.hot.emissiveIntensity = live.stall ? 0 : Math.min(1.4, live.rpm / red * .9);
			const light = u.fx.userData.light;
			if (light) light.intensity = live.dead ? Math.max(0, 6 * (1 - live.deadT / 1.3)) : 0;
		}
		this.cycle(dt, live, spec);
		this.fx(dt, live);
		this.renderer.render(this.scene, this.camera);
	}
	pose(u) {
		u.crank.rotation.x = this.ang;
		const { r, L } = u;
		for (const item of u.cyl) {
			if (this.fly && this.fly.cyl === item) continue;
			const { c, pg, rod } = item;
			const th = this.ang + c.p;
			const a = c.bk;
			const v = r * Math.sin(th - a);
			const s = r * Math.cos(th - a) + Math.sqrt(Math.max(0, L * L - v * v));
			const py = r * Math.cos(th);
			const pz = r * Math.sin(th);
			const Py = s * Math.cos(a);
			const Pz = s * Math.sin(a);
			pg.position.y = Py;
			pg.position.z = Pz;
			rod.position.set(c.x, (py + Py) / 2, (pz + Pz) / 2);
			rod.rotation.x = Math.atan2(Pz - pz, Py - py);
		}
		for (const g of u.spin) g.rotation.x = this.ang * 4;
	}
	mod4(n) {
		const t = Math.PI * 4;
		return (n % t + t) % t;
	}
	grab(u) {
		for (const m of u.pool) if (!m.visible) return m;
		return null;
	}
	cycle(dt, live, spec) {
		const running = !live.stall && !live.dead && live.rpm > 45;
		const gas = spec.fuel !== "dsl";
		let spawned = 0;
		for (const u of this.units) {
			const spark = u.fx.userData.spark;
			for (const item of u.cyl) {
				const stroke = this.mod4(this.ang + item.c.p - item.c.bk);
				const prev = item.prevStroke;
				item.prevStroke = stroke;
				if (!running) continue;
				if (stroke > .35 && stroke < 2.55 && spawned < 3 && this.flow.length < 36 && Math.random() < dt * (1.1 + live.rpm / 4500)) {
					if (this.spit(u, item, "air")) spawned++;
					if (gas && spawned < 3 && Math.random() < .42 && this.spit(u, item, "fuel")) spawned++;
				}
				if (prev < Math.PI * 2 && stroke >= Math.PI * 2) {
					this.spit(u, item, "burn");
					if (spark && gas) {
						const a = item.c.bk;
						const y = u.top * Math.cos(a);
						const z = u.top * Math.sin(a);
						spark.position.set(item.c.x, y * .92, z * .92);
						spark.visible = true;
						spark.material.opacity = gas ? .95 : .35;
						spark.scale.setScalar(1);
						u.fx.userData.sparkT = .07;
					}
				}
				if (stroke > Math.PI * 3.05 && stroke < Math.PI * 3.8 && spawned < 3 && this.flow.length < 36 && Math.random() < dt * (.7 + live.rpm / 5500)) {
					if (this.spit(u, item, "exh")) spawned++;
				}
			}
			if (spark) {
				let left = Number(u.fx.userData.sparkT) || 0;
				if (!running) left = 0;
				left -= dt;
				u.fx.userData.sparkT = left;
				const mat = spark.material;
				if (left <= 0 || !gas) {
					spark.visible = false;
					mat.opacity = 0;
				} else mat.opacity = .9 * (left / .07);
			}
		}
		for (let i = this.flow.length - 1; i >= 0; i--) {
			const p = this.flow[i];
			p.t += dt;
			const mat = p.m.material;
			if (p.t > p.l) {
				p.m.visible = false;
				mat.opacity = 0;
				this.flow.splice(i, 1);
				continue;
			}
			p.m.position.addScaledVector(p.v, dt);
			const u = p.t / p.l;
			mat.opacity = (p.kind === "burn" ? .72 : p.kind === "exh" ? .4 : .55) * (1 - u);
			if (p.kind === "exh") p.m.scale.multiplyScalar(1 + dt * .8);
		}
	}
	spit(u, item, kind) {
		const m = this.grab(u);
		if (!m) return false;
		const a = item.c.bk;
		const crownY = item.pg.position.y + Math.cos(a) * .28;
		const crownZ = item.pg.position.z + Math.sin(a) * .28;
		const hy = u.top * Math.cos(a);
		const hz = u.top * Math.sin(a);
		const mat = m.material;
		let life = .28;
		let scale = .09;
		const v = new Vector3();
		if (kind === "air" || kind === "fuel") {
			m.position.set(item.c.x + (kind === "fuel" ? .12 : .22), hy + Math.cos(a) * .35, hz + Math.sin(a) * .35);
			v.set(item.c.x - m.position.x, crownY - m.position.y, crownZ - m.position.z);
			const len = Math.max(.001, v.length());
			v.multiplyScalar((kind === "fuel" ? 1.6 : 1.35) / len);
			mat.color.setHex(kind === "fuel" ? 15227148 : 7651580);
			life = .22 + Math.random() * .08;
			scale = kind === "fuel" ? .08 : .13;
		} else if (kind === "burn") {
			m.position.set(item.c.x, hy * .78 + crownY * .22, hz * .78 + crownZ * .22);
			v.set((Math.random() - .5) * .25, (Math.random() - .5) * .25, (Math.random() - .5) * .25);
			mat.color.setHex(16761165);
			life = .1;
			scale = .2;
		} else {
			m.position.set(item.c.x, crownY, crownZ);
			v.set((Math.random() - .5) * .3, -Math.cos(a) * .6, -Math.sin(a) * .6 - 1.1);
			mat.color.setHex(Math.random() < .45 ? 12730636 : 9278878);
			life = .28;
			scale = .12;
		}
		m.visible = true;
		m.scale.setScalar(scale);
		mat.opacity = .6;
		this.flow.push({
			m,
			t: 0,
			l: life,
			v,
			kind
		});
		return true;
	}
	fx(dt, live) {
		if (!live.dead) this.root.position.x = 0;
		else {
			const t = live.deadT;
			const sp = live.spd;
			this.root.position.x = t < .7 ? (Math.random() - .5) * .35 * (1 - t / .7) : sp > .5 ? (Math.random() - .5) * Math.min(.12, sp * .006) : 0;
			if (t < .8 && this.units[0]) {
				for (let i = 0; i < 4; i++) this.puffAt(this.units[0], true, false);
				this.puffAt(this.units[0], false, false);
			} else if (this.units[0]) {
				const q = Math.max(0, 1 - live.stopT / 8);
				if (Math.random() < (.15 + live.spd / 30) * q) this.puffAt(this.units[0], false, false);
				if (live.spd > 1 && Math.random() < Math.min(.5, live.spd / 40)) this.puffAt(this.units[0], true, false);
			}
			const f = this.fly;
			if (f) {
				f.cyl.pg.position.addScaledVector(f.v, dt);
				f.v.y -= 25 * dt;
				f.cyl.pg.rotation.z += dt * 7;
				f.cyl.rod.position.addScaledVector(f.rv, dt);
				f.rv.y -= 25 * dt;
				f.cyl.rod.rotation.z += dt * 4;
			}
		}
		for (let i = this.pt.length - 1; i >= 0; i--) {
			const p = this.pt[i];
			p.t += dt;
			if (p.t > p.l) {
				p.m.removeFromParent();
				p.m.material.dispose();
				this.pt.splice(i, 1);
				continue;
			}
			p.m.position.addScaledVector(p.v, dt);
			const u = p.t / p.l;
			const mat = p.m.material;
			if (p.f) {
				mat.color.setHSL(.08 * (1 - u), 1, .5 - .3 * u);
				mat.opacity = .9 * (1 - u);
			} else {
				p.v.y *= 1 - dt * .3;
				p.m.scale.multiplyScalar(1 + dt * .5);
				mat.opacity = .55 * (1 - u);
			}
		}
	}
};
var RAT = [
	0,
	13,
	9,
	6.6,
	5.1,
	4.1,
	3.4
];
var IDLE = 900;
function step(live, spec, dt, hooks) {
	const e = curve(spec);
	const g = live.gear;
	const R = RAT[g] ?? 0;
	const M = 500 * (spec.twin ? 1.4 : 1);
	live.brake += (live.brk - live.brake) * Math.min(1, dt * 10);
	live.grind = Math.max(0, live.grind - dt);
	live.msg = Math.max(0, live.msg - dt);
	live.clu += (live.cin - live.clu) * Math.min(1, dt * (live.cin ? 10 : 2.2));
	if (live.dead) {
		live.deadT += dt;
		live.thr *= Math.exp(-dt * 8);
		live.spd = Math.max(0, live.spd - dt * (1 + 6e-4 * live.spd * live.spd + live.brake * 9));
		if (live.spd < .3) live.stopT += dt;
		const tg = g ? Math.min(2500, live.spd * R * 31.8 * .3) : 0;
		live.rpm += (tg - live.rpm) * Math.min(1, dt * 3);
		return;
	}
	live.thr += (live.pedal - live.thr) * Math.min(1, dt * (8 + (spec.ecu ? spec.map * .4 : 0)));
	const drag = .3 + 6e-4 * live.spd * live.spd;
	const cr = live.spd * R * 31.8;
	const en = g ? Math.min(1, Math.max(0, (.75 - live.clu) / .5)) : 0;
	if (live.stall) {
		if (live.crank > 0) {
			live.crank -= dt;
			live.rpm += (260 - live.rpm) * Math.min(1, dt * 10);
			if (live.crank <= 0) {
				live.stall = false;
				live.rpm = 1300;
				live.cut = false;
			}
		} else live.rpm *= Math.exp(-dt * 8);
		if (live.stall) {
			live.spd = Math.max(0, live.spd - dt * (drag + live.brake * 9 + en * R * .4));
			return;
		}
	}
	const top = en > .5 ? Math.max(live.rpm, cr) : live.rpm;
	if (live.cut) {
		live.cutT -= dt;
		if (live.cutT <= 0) {
			live.cut = false;
			live.rel = true;
			live.limCd = .025 + Math.random() * .035;
		}
	} else {
		live.limCd -= dt;
		if (top >= e.red && live.thr > .3 && live.limCd <= 0) {
			live.cut = true;
			live.cutT = .05 + Math.random() * .04;
			hooks.limit();
		}
	}
	const thr = live.cut ? 0 : top >= e.red * 1.01 ? 0 : live.thr;
	const tg = IDLE + thr * (e.red * 1.1 - IDLE);
	const follow = tg > live.rpm ? live.rpm > e.red * .8 ? 9 : 4 : live.cut ? .45 : 1.6;
	const rF = live.rpm + (tg - live.rpm) * Math.min(1, dt * follow);
	if (en <= 0) {
		live.rpm = rF;
		live.spd = Math.max(0, live.spd - dt * ((g ? .3 : .6) + 6e-4 * live.spd * live.spd + live.brake * 9));
		return;
	}
	const p = perf(spec, Math.max(live.rpm, IDLE));
	const tqE = p.tq * (.08 + .92 * thr);
	const df = live.rpm - cr;
	if (en > .9 && Math.abs(df) < 250) {
		if (cr > e.red * 1.3) {
			blow(live, hooks);
			return;
		}
		const a = thr * p.tq * R / (.3 * M) - drag - (thr < .05 ? .6 * (live.rpm / e.red) * R / 8 : 0) - live.brake * 9 - (live.cut ? 2.5 : 0);
		live.spd = Math.max(0, live.spd + Math.min(a, 14) * dt);
		const c2 = live.spd * R * 31.8;
		live.rpm += (c2 - live.rpm) * Math.min(1, dt * 10);
		if (c2 < 300 && live.rpm < 350 && thr < .2) live.stall = true;
	} else {
		const a = en * (df > 0 ? Math.max(-1, Math.min(1, df / 1500)) * Math.min(14, tqE * R / (.3 * M)) : Math.max(-1, df / 1500) * 6) - drag - live.brake * 9;
		live.spd = Math.max(0, live.spd + a * dt);
		const launch = live.spd < 3 && thr > .15 ? .28 : 1;
		live.rpm = rF + (Math.max(cr, 0) - rF) * Math.min(1, dt * 8 * en * launch);
		if (live.rpm > e.red * 1.3) {
			blow(live, hooks);
			return;
		}
		if (en > .9 && live.rpm < 300 && thr < .2) live.stall = true;
	}
}
function blow(live, hooks) {
	if (live.dead) return;
	live.dead = true;
	live.deadT = 0;
	live.stopT = 0;
	live.pedal = 0;
	hooks.blow();
}
function tryShift(live, g) {
	if (g === live.gear || g === 0 || live.clu > .6 || live.stall || live.spd < .5) {
		live.gear = g;
		return {
			gear: g,
			grind: false
		};
	}
	live.grind = 1.5;
	return {
		gear: live.gear,
		grind: true
	};
}
function ignite(live) {
	if (live.dead) return "busy";
	if (!live.stall) {
		live.stall = true;
		live.crank = 0;
		return "stop";
	}
	if (live.crank > 0) return "busy";
	if (live.gear && live.clu < .7) {
		live.msg = 1.8;
		return "need-clutch";
	}
	live.crank = .9;
	return "crank";
}
var Runtime = class {
	live = createLive();
	spec;
	scene;
	audio;
	raf = 0;
	last = 0;
	acc = 0;
	hooks;
	onKeyDown;
	onKeyUp;
	onBlur;
	constructor(canvas, spec, hooks) {
		this.spec = spec;
		this.hooks = hooks;
		this.scene = new EngineScene(canvas);
		this.audio = new EngineAudio(() => this.spec, () => this.live);
		this.scene.rebuild(spec);
		this.scene.resize();
		this.onKeyDown = (e) => this.keyDown(e);
		this.onKeyUp = (e) => this.keyUp(e);
		this.onBlur = () => this.release();
		window.addEventListener("keydown", this.onKeyDown);
		window.addEventListener("keyup", this.onKeyUp);
		window.addEventListener("blur", this.onBlur);
	}
	start() {
		this.last = performance.now();
		const loop = (now) => {
			const dt = Math.min(.1, (now - this.last) / 1e3);
			this.last = now;
			this.acc += dt;
			const h = 1 / 60;
			let n = 0;
			while (this.acc >= h && n < 4) {
				step(this.live, this.spec, h, {
					blow: () => this.onBlow(),
					limit: () => this.onLimit()
				});
				this.acc -= h;
				n++;
			}
			this.crackle(dt);
			this.audio.update(dt);
			this.scene.advance(dt, this.live, this.spec);
			this.raf = requestAnimationFrame(loop);
		};
		this.raf = requestAnimationFrame(loop);
	}
	stop() {
		cancelAnimationFrame(this.raf);
		window.removeEventListener("keydown", this.onKeyDown);
		window.removeEventListener("keyup", this.onKeyUp);
		window.removeEventListener("blur", this.onBlur);
	}
	resize() {
		this.scene.resize();
	}
	setSpec(spec) {
		this.spec = spec;
		if (this.live.dead) {
			this.live.dead = false;
			this.live.deadT = 0;
			this.live.stopT = 0;
			this.live.stall = true;
			this.live.rpm = 0;
			this.live.crank = 0;
			this.live.pedal = 0;
			this.live.thr = 0;
			this.live.gear = 0;
			this.hooks.onDead(false);
			this.hooks.onGear(0);
		}
		this.scene.rebuild(spec);
	}
	repair() {
		this.live.dead = false;
		this.live.deadT = 0;
		this.live.stopT = 0;
		this.live.stall = true;
		this.live.rpm = 0;
		this.live.crank = 0;
		this.live.pedal = 0;
		this.live.thr = 0;
		this.live.gear = 0;
		this.live.cut = false;
		this.hooks.onDead(false);
		this.hooks.onGear(0);
		this.scene.rebuild(this.spec);
	}
	shift(g) {
		if (tryShift(this.live, g).grind) this.audio.grind();
		this.hooks.onGear(this.live.gear);
		return this.live.gear;
	}
	ignition() {
		if (ignite(this.live) === "crank") this.audio.starter();
	}
	onBlow() {
		this.scene.blow();
		this.audio.boom();
		this.hooks.onDead(true);
	}
	onLimit() {
		const spec = this.spec;
		if (this.live.dead || !spec.pop || spec.fuel === "dsl" || spec.exh === "stock") return;
		this.scene.flame();
		const n = (spec.exh === "open" ? 3 : spec.exh === "straight" ? 2 : 1) + Math.floor(Math.random() * 2);
		for (let i = 0; i < n; i++) this.audio.pop(i * .025 + Math.random() * .02);
	}
	crackle(dt) {
		const spec = this.spec;
		const live = this.live;
		if (live.dead || !spec.pop || spec.fuel === "dsl" || spec.exh === "stock") return;
		if (live.thr > .15 || live.rpm < 2500 || live.stall) return;
		const rate = {
			sport: 4,
			straight: 7,
			open: 10
		}[spec.exh] * (live.rpm / curve(spec).red);
		if (Math.random() < dt * rate) {
			this.scene.flame();
			this.audio.pop();
		}
	}
	typingTarget(e) {
		const tag = e.target?.tagName;
		return tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT";
	}
	keyDown(e) {
		if (e.repeat || this.typingTarget(e)) return;
		const c = e.code;
		if (c === "KeyC" || c === "ShiftLeft" || c === "ShiftRight") this.live.cin = 1;
		if (c === "KeyB" || c === "ArrowDown") {
			this.live.brk = 1;
			e.preventDefault();
		}
		if (c === "Space" || c === "ArrowUp") {
			this.live.pedal = 1;
			e.preventDefault();
		}
		if (c === "KeyE") this.shift(Math.min(6, this.live.gear + 1));
		if (c === "KeyQ") this.shift(Math.max(0, this.live.gear - 1));
		if (c === "KeyK") this.ignition();
	}
	keyUp(e) {
		const c = e.code;
		if (c === "KeyC" || c === "ShiftLeft" || c === "ShiftRight") this.live.cin = 0;
		if (c === "KeyB" || c === "ArrowDown") this.live.brk = 0;
		if (c === "Space" || c === "ArrowUp") this.live.pedal = 0;
	}
	release() {
		this.live.cin = 0;
		this.live.brk = 0;
		this.live.pedal = 0;
	}
};
var SPEC_KEY = "em_spec";
var LANG_KEY = "em_lang";
var BG_KEY = "em_bg";
var VOL_KEY = "em_vol";
function readJSON(key) {
	try {
		const raw = localStorage.getItem(key);
		return raw ? JSON.parse(raw) : null;
	} catch {
		return null;
	}
}
function applyBg(color) {
	const root = document.documentElement;
	const keys = [
		"--color-fg",
		"--color-panel",
		"--color-line",
		"--color-muted",
		"--color-chip"
	];
	if (!color) {
		root.removeAttribute("data-forced");
		root.style.removeProperty("--color-bg");
		keys.forEach((k) => root.style.removeProperty(k));
		root.style.colorScheme = "";
		return;
	}
	const n = Number.parseInt(color.slice(1), 16);
	const light = (.299 * (n >> 16) + .587 * (n >> 8 & 255) + .114 * (n & 255)) / 255 > .55;
	const pal = light ? [
		"#15181d",
		"#ffffff",
		"#c9ced6",
		"#5b6370",
		"#f3f5f8"
	] : [
		"#e8eaee",
		"#1a1d23",
		"#2d323b",
		"#8b93a1",
		"#23272f"
	];
	root.setAttribute("data-forced", "1");
	root.style.setProperty("--color-bg", color);
	keys.forEach((k, i) => root.style.setProperty(k, pal[i]));
	root.style.colorScheme = light ? "light" : "dark";
}
function EngineApp() {
	const canvasRef = (0, import_react.useRef)(null);
	const rtRef = (0, import_react.useRef)(null);
	const langRef = (0, import_react.useRef)("en");
	const [spec, setSpec] = (0, import_react.useState)(() => {
		const saved = sanitize(readJSON(SPEC_KEY));
		if (saved.type === "v12" && saved.fuel === "dsl") {
			const next = {
				...saved,
				fuel: "gas"
			};
			try {
				localStorage.setItem(SPEC_KEY, JSON.stringify(next));
			} catch {}
			return next;
		}
		return saved;
	});
	const [lang, setLang] = (0, import_react.useState)(() => {
		const saved = localStorage.getItem(LANG_KEY);
		return LANGS.includes(saved) ? saved : "en";
	});
	const [askLang, setAskLang] = (0, import_react.useState)(() => !localStorage.getItem(LANG_KEY));
	const [open, setOpen] = (0, import_react.useState)(() => window.innerWidth > 960);
	const [gear, setGear] = (0, import_react.useState)(0);
	const [dead, setDead] = (0, import_react.useState)(false);
	const [sound, setSound] = (0, import_react.useState)(false);
	const [volume, setVolume] = (0, import_react.useState)(() => {
		const n = Number(localStorage.getItem(VOL_KEY));
		return Number.isFinite(n) ? Math.min(1, Math.max(0, n)) : .7;
	});
	const [bg, setBg] = (0, import_react.useState)(() => localStorage.getItem(BG_KEY) ?? "");
	const [fail, setFail] = (0, import_react.useState)("");
	const titleRef = (0, import_react.useRef)(null);
	const ccRef = (0, import_react.useRef)(null);
	const hpRef = (0, import_react.useRef)(null);
	const tqRef = (0, import_react.useRef)(null);
	const spdRef = (0, import_react.useRef)(null);
	const gearRef = (0, import_react.useRef)(null);
	const barRef = (0, import_react.useRef)(null);
	const statRef = (0, import_react.useRef)(null);
	const ignRef = (0, import_react.useRef)(null);
	const gasRef = (0, import_react.useRef)(null);
	const brakeRef = (0, import_react.useRef)(null);
	const clutchRef = (0, import_react.useRef)(null);
	langRef.current = lang;
	const tr = copy(lang);
	const pwa = usePwa();
	(0, import_react.useEffect)(() => {
		applyBg(bg);
	}, [bg]);
	(0, import_react.useEffect)(() => {
		document.documentElement.lang = lang;
	}, [lang]);
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		let rt;
		try {
			rt = new Runtime(canvas, spec, {
				onDead: setDead,
				onGear: setGear
			});
			rt.audio.setVolume(volume);
		} catch (err) {
			setFail(err instanceof Error ? err.message : "WebGL unavailable");
			return;
		}
		rtRef.current = rt;
		rt.start();
		let raf = 0;
		const paint = () => {
			const live = rt.live;
			const s = rt.spec;
			const c = copy(langRef.current);
			const p = perf(s, live.rpm);
			const k = .08 + .92 * live.thr;
			const red = curve(s).red;
			if (titleRef.current) titleRef.current.textContent = engineTitle(s, c);
			if (ccRef.current) ccRef.current.textContent = `${Math.round(p.cc)} cc`;
			if (hpRef.current) hpRef.current.textContent = `${Math.round(p.hp * k)} hp`;
			if (tqRef.current) tqRef.current.textContent = `${Math.round(p.tq * k)} N·m`;
			if (spdRef.current) spdRef.current.textContent = String(Math.round(live.spd * 3.6));
			if (gearRef.current) gearRef.current.textContent = live.gear ? String(live.gear) : "N";
			if (barRef.current) {
				barRef.current.style.width = `${Math.min(100, live.rpm / red * 100)}%`;
				barRef.current.style.background = live.rpm > red * .92 ? "var(--color-danger)" : "var(--color-accent)";
			}
			if (statRef.current) {
				const bits = [`${Math.round(live.rpm)} ${c.rpmRed} ${Math.round(red)}`];
				if (live.dead) bits.push(c.blown);
				else if (live.rpm > red * 1.08) bits.push(c.overrev);
				if (live.stall) bits.push(live.crank > 0 ? c.ignCrank : c.stall);
				if (live.msg > 0) bits.push(c.msgClutch);
				if (live.grind > 0) bits.push(c.grind);
				statRef.current.textContent = bits.join("   ");
			}
			if (ignRef.current) ignRef.current.childNodes[1] && (ignRef.current.lastChild.textContent = live.stall ? live.crank > 0 ? c.ignCrank : c.ignStart : c.ignStop);
			gasRef.current?.style.setProperty("--t", live.thr.toFixed(2));
			gasRef.current?.classList.toggle("border-accent", live.pedal > 0);
			gasRef.current?.classList.toggle("text-accent", live.pedal > 0);
			brakeRef.current?.classList.toggle("border-danger", live.brk > 0);
			brakeRef.current?.classList.toggle("text-danger", live.brk > 0);
			clutchRef.current?.classList.toggle("border-clutch", live.cin > 0);
			clutchRef.current?.classList.toggle("text-clutch", live.cin > 0);
			raf = requestAnimationFrame(paint);
		};
		raf = requestAnimationFrame(paint);
		const stage = canvas.parentElement;
		const ro = new ResizeObserver(() => rt.resize());
		if (stage) ro.observe(stage);
		const drag = {
			x: 0,
			y: 0,
			on: false
		};
		const down = (e) => {
			drag.on = true;
			drag.x = e.clientX;
			drag.y = e.clientY;
			canvas.setPointerCapture(e.pointerId);
		};
		const move = (e) => {
			if (!drag.on) return;
			rt.scene.orbit(e.clientX - drag.x, e.clientY - drag.y);
			drag.x = e.clientX;
			drag.y = e.clientY;
		};
		const up = () => {
			drag.on = false;
		};
		canvas.addEventListener("pointerdown", down);
		canvas.addEventListener("pointermove", move);
		canvas.addEventListener("pointerup", up);
		canvas.addEventListener("pointercancel", up);
		canvas.addEventListener("dblclick", () => rt.scene.resetView());
		return () => {
			cancelAnimationFrame(raf);
			ro.disconnect();
			canvas.removeEventListener("pointerdown", down);
			canvas.removeEventListener("pointermove", move);
			canvas.removeEventListener("pointerup", up);
			canvas.removeEventListener("pointercancel", up);
			rt.stop();
			rtRef.current = null;
		};
	}, []);
	function patch(p) {
		setSpec((prev) => {
			const next = sanitize({
				...prev,
				...p
			});
			rtRef.current?.setSpec(next);
			try {
				localStorage.setItem(SPEC_KEY, JSON.stringify(next));
			} catch {}
			return next;
		});
	}
	function chooseLang(l) {
		setLang(l);
		setAskLang(false);
		try {
			localStorage.setItem(LANG_KEY, l);
		} catch {}
	}
	function hold(ref, v) {
		const live = rtRef.current?.live;
		if (live) live[ref] = v;
	}
	const dir = isRtl(lang) ? "rtl" : "ltr";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		dir,
		className: "flex h-dvh overflow-hidden bg-bg font-sans text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative min-h-0 min-w-0 flex-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
						ref: canvasRef,
						className: "stage-canvas"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between gap-2 px-3 pt-[max(0.75rem,env(safe-area-inset-top))]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "pointer-events-none min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-display text-base leading-none font-bold tracking-[0.12em] sm:text-lg sm:tracking-[0.14em]",
								children: ["ENGINE MAKER ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-accent",
									children: "1.0"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 hidden text-xs text-muted sm:block",
								children: tr.drag
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "pointer-events-auto flex shrink-0 flex-wrap justify-end gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									"aria-label": open ? tr.close : tr.title,
									className: "inline-flex min-h-11 items-center gap-1.5 rounded-xl bg-accent px-3 text-sm font-semibold text-accent-fg",
									onClick: () => setOpen((v) => !v),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings2, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "max-sm:sr-only",
										children: open ? tr.close : tr.title
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									"aria-label": sound ? tr.soundOff : tr.soundOn,
									className: "inline-flex min-h-11 items-center gap-1.5 rounded-xl border border-line bg-panel/90 px-3 text-sm font-semibold backdrop-blur",
									onClick: () => {
										const on = rtRef.current?.audio.toggle() ?? false;
										setSound(on);
									},
									children: [sound ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "max-sm:sr-only",
										children: sound ? tr.soundOff : tr.soundOn
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									ref: ignRef,
									type: "button",
									"aria-label": tr.ignStart,
									className: "inline-flex min-h-11 items-center gap-1.5 rounded-xl border border-line bg-panel/90 px-3 text-sm font-semibold backdrop-blur",
									onClick: () => rtRef.current?.ignition(),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "max-sm:sr-only",
										children: tr.ignStart
									})]
								})
							]
						})]
					}),
					fail && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "absolute top-24 left-3 rounded-lg border border-danger bg-panel px-3 py-2 text-sm text-danger",
						children: fail
					}),
					dead && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "blow-card absolute left-1/2 z-10 flex -translate-x-1/2 -translate-y-1/2 flex-col items-center gap-2 rounded-2xl border-2 border-danger bg-panel px-4 py-4 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-2xl font-bold text-danger",
								children: tr.deadT
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: tr.deadD
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "inline-flex min-h-11 items-center gap-1.5 rounded-lg bg-danger px-4 font-semibold text-accent-fg",
								onClick: () => rtRef.current?.repair(),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wrench, { className: "size-4" }), tr.fix]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
						className: "hud pointer-events-none absolute start-2 z-[1] w-[min(12.5rem,46vw)] rounded-xl border border-line bg-panel/75 px-2 py-1.5 shadow-sm backdrop-blur-sm top-[max(3.2rem,calc(env(safe-area-inset-top)+2.7rem))]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-baseline justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
									ref: titleRef,
									className: "truncate text-sm font-bold tracking-wide",
									children: engineTitle(spec, tr)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									ref: ccRef,
									className: "shrink-0 text-[11px] text-muted"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-0.5 flex gap-2 text-[11px] text-muted",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { ref: hpRef }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { ref: tqRef })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-1 flex items-end gap-1.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
										ref: spdRef,
										className: "font-display text-2xl leading-none font-bold",
										children: "0"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "pb-0.5 text-[10px] text-muted",
										children: "km/h"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
										ref: gearRef,
										className: "ms-auto font-display text-xl leading-none font-bold",
										children: "N"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1 h-1 overflow-hidden rounded-full bg-line",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
									ref: barRef,
									className: "block h-full w-0 bg-accent"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								ref: statRef,
								className: "mt-0.5 truncate text-[10px] text-muted"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-0.5 hidden truncate text-[10px] text-fg md:block",
								children: tr.hint
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-0.5 hidden truncate text-[10px] text-muted lg:block",
								children: tr.keys
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
						className: "dock pointer-events-none absolute inset-x-2 bottom-2 flex items-end gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "pointer-events-auto",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shifter, {
								gear,
								onShift: (g) => rtRef.current?.shift(g) ?? g
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "pointer-events-auto ms-auto flex items-end gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pedal, {
									btnRef: clutchRef,
									label: tr.clutch,
									onDown: () => hold("cin", 1),
									onUp: () => hold("cin", 0)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pedal, {
									btnRef: brakeRef,
									label: tr.brake,
									onDown: () => hold("brk", 1),
									onUp: () => hold("brk", 0)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									ref: gasRef,
									type: "button",
									className: "ped ped-gas h-36 w-20 rounded-2xl border border-line text-xs font-bold",
									onPointerDown: (e) => {
										e.currentTarget.setPointerCapture(e.pointerId);
										hold("pedal", 1);
									},
									onPointerUp: () => hold("pedal", 0),
									onPointerCancel: () => hold("pedal", 0),
									children: tr.gas
								})
							]
						})]
					})
				]
			}),
			open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MakerPanel, {
				tr,
				lang,
				spec,
				volume,
				bg,
				onClose: () => setOpen(false),
				onLang: chooseLang,
				onSpec: patch,
				onVolume: (v) => {
					setVolume(v);
					rtRef.current?.audio.setVolume(v);
					try {
						localStorage.setItem(VOL_KEY, String(v));
					} catch {}
				},
				onBg: (c) => {
					setBg(c);
					try {
						localStorage.setItem(BG_KEY, c);
					} catch {}
				},
				pwa: {
					canInstall: pwa.canInstall,
					installed: pwa.installed,
					ios: pwa.ios,
					shareNote: pwa.shareNote,
					onInstall: () => {
						pwa.install();
					},
					onShare: () => {
						pwa.share();
					}
				}
			}),
			askLang && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-30 grid place-items-center bg-black/60 p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-xs rounded-2xl border border-line bg-panel p-4 text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-3 text-sm font-semibold",
						children: tr.langPick
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-2",
						children: LANGS.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "min-h-11 rounded-xl border border-line bg-chip text-base font-semibold",
							onClick: () => chooseLang(l),
							children: LANG_LABEL[l]
						}, l))
					})]
				})
			})
		]
	});
}
function Pedal({ label, btnRef, onDown, onUp }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		ref: btnRef,
		type: "button",
		className: "ped h-28 w-16 rounded-2xl border border-line text-xs font-bold",
		onPointerDown: (e) => {
			e.currentTarget.setPointerCapture(e.pointerId);
			onDown();
		},
		onPointerUp: onUp,
		onPointerCancel: onUp,
		children: label
	});
}
//#endregion
export { EngineApp };
