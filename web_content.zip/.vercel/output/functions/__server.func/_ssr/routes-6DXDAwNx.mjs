import { S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Check, s as ArrowUpRight } from "../_libs/lucide-react.mjs";
import { i as useVespera } from "./router-D7Hr81ml.mjs";
import { _ as toAltAz, a as formatCivil, c as formatLat, g as skyInstant, n as compass, p as lstHours, t as bodiesAt, v as twilight } from "./astro-2CYvScwN.mjs";
import { t as LESSONS } from "./lessons-DkJWLy0d.mjs";
import { n as btnGhost, r as btnGold } from "./ui-B4w5JSuo.mjs";
import { a as useNow, i as STARS, r as PLACES, t as CONSTELLATIONS } from "./use-now-CFRJohYF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-6DXDAwNx.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const done = useVespera((s) => s.done);
	const quizBest = useVespera((s) => s.quizBest);
	const next = LESSONS.find((l) => !done.includes(l.id)) ?? LESSONS[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid items-end gap-10 lg:grid-cols-[1.35fr_0.75fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase tracking-widest text-gold",
					children: "Naked eye · six lessons"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 max-w-xl text-5xl leading-[1.05] text-fg md:text-6xl",
					children: "Learn the night sky by watching it move."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-xl text-lg text-muted",
					children: "A horizon chart with real stars and planets, three labs, and a short course. No telescope, and no myth standing in for an explanation."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/sky",
						search: {},
						className: btnGold,
						children: "Open the sky"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/lessons/$id",
						params: { id: next.id },
						className: btnGhost,
						children: done.length === 0 ? "Start the course" : done.length === LESSONS.length ? "Review the course" : "Continue"
					})]
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tonight, {})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-14 flex items-baseline justify-between gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-2xl text-fg",
				children: "The path"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-faint tabular-nums",
				children: [
					done.length,
					" of ",
					LESSONS.length,
					quizBest != null ? ` · quiz ${quizBest}/10` : ""
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "mt-2 border-b border-line",
			children: LESSONS.map((lesson, i) => {
				const complete = done.includes(lesson.id);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "border-t border-line",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/lessons/$id",
						params: { id: lesson.id },
						className: "group flex items-baseline gap-4 py-5 sm:gap-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "w-8 font-display text-xl text-gold tabular-nums",
								children: String(i + 1).padStart(2, "0")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block font-display text-2xl text-fg group-hover:text-gold",
									children: lesson.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 block text-sm text-muted",
									children: lesson.lede
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "hidden shrink-0 text-xs uppercase tracking-widest text-faint sm:inline",
								children: [lesson.minutes, " min"]
							}),
							complete ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
								className: "size-5 shrink-0 text-gold",
								"aria-label": "Done"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
								className: "size-5 shrink-0 text-faint transition-colors group-hover:text-gold",
								"aria-hidden": true
							})
						]
					})
				}, lesson.id);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-8 max-w-xl text-sm text-faint",
			children: "The chart defaults to 40°N and a longitude guessed from your clock. If Polaris isn't where the lesson says, change the city — the angle is the lesson."
		})
	] });
}
function Tonight() {
	const now = useNow();
	const lat = useVespera((s) => s.lat);
	const lon = useVespera((s) => s.lon);
	const custom = useVespera((s) => s.custom);
	const placeId = useVespera((s) => s.placeId);
	const ready = useVespera((s) => s.ready);
	if (!now || !ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "rounded-2xl border border-line bg-surface p-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs uppercase tracking-widest text-gold",
			children: "Right now"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-sm text-muted",
			children: "Matching the chart to your clock."
		})]
	});
	const when = skyInstant(lon, custom, now);
	const lst = lstHours(when, lon);
	const sun = bodiesAt(when)[0];
	const sunAlt = toAltAz(sun.ra, sun.dec, lat, lst).alt;
	const note = twilight(sunAlt);
	const up = STARS.map((s) => ({
		...s,
		...toAltAz(s.ra, s.dec, lat, lst)
	})).filter((s) => s.alt > 20 && s.mag < 1.8).sort((a, b) => b.alt - a.alt).slice(0, 3);
	const cons = /* @__PURE__ */ new Map();
	for (const s of STARS) {
		const alt = toAltAz(s.ra, s.dec, lat, lst).alt;
		if (alt > 25) cons.set(s.con, Math.max(cons.get(s.con) ?? 0, alt));
	}
	const figures = [...cons.entries()].sort((a, b) => b[1] - a[1]).slice(0, 3).map(([id]) => CONSTELLATIONS[id]?.name).filter(Boolean);
	const place = placeId === "guess" ? `${formatLat(lat)} · longitude from your clock` : placeId === "custom" ? formatLat(lat) : PLACES.find((p) => p.id === placeId)?.name ?? formatLat(lat);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "rounded-2xl border border-line bg-surface p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs uppercase tracking-widest text-gold",
				children: "On the chart"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 font-display text-2xl text-fg",
				children: formatCivil(when, lon)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: place
			}),
			note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-fg",
				children: note
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-fg",
				children: "Full dark. The bright patterns are fair game."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-4 space-y-2",
				children: [up.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-baseline justify-between gap-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-fg",
						children: s.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-faint tabular-nums",
						children: [
							s.alt.toFixed(0),
							"° ",
							compass(s.az)
						]
					})]
				}, s.id)), up.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "text-sm text-muted",
					children: "No bright star is high. Try a different hour, or a darker definition of “high.”"
				})]
			}),
			figures.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 text-sm text-muted",
				children: [
					"Figures up: ",
					figures.join(", "),
					"."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/sky",
				search: {},
				className: "mt-4 inline-flex text-sm text-gold",
				children: "Adjust time and place"
			})
		]
	});
}
//#endregion
export { Home as component };
