import { i as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, x as require_react } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as Route$4 } from "./router-JV23dvxm.mjs";
import { O as useFlock, h as formatInt, k as useHydrated, r as FILTERS, t as AppShell, u as cn, x as matchesFilter } from "./store-g4o8WGZx.mjs";
import { n as SheepCard, r as sortSheep } from "./sheep-bits-ABYC-5qN.mjs";
import { t as Input } from "./input-CkkIr1XO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/flock-Cp0kXgaW.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function FlockPage() {
	const { f = "all" } = Route$4.useSearch();
	const navigate = Route$4.useNavigate();
	const hydrated = useHydrated();
	const sheep = useFlock((s) => s.sheep);
	const breeding = useFlock((s) => s.breeding);
	const [q, setQ] = (0, import_react.useState)("");
	const query = q.trim();
	const list = sortSheep(sheep.filter((s) => {
		if (!matchesFilter(s, breeding, f)) return false;
		if (!query) return true;
		return `${s.tag} ${s.name} ${s.breed} ${s.pen}`.includes(query);
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "القطيع",
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/sheep/new",
			className: "text-sm font-medium",
			children: "إضافة"
		}),
		children: !hydrated ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: "يُفتح السجل…"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: q,
					onChange: (e) => setQ(e.target.value),
					placeholder: "رقم، اسم، سلالة، أو حظيرة",
					"aria-label": "بحث"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-2 overflow-x-auto pb-1",
					children: FILTERS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => navigate({ search: { f: item.id } }),
						className: cn("h-9 shrink-0 rounded-full px-3 text-sm", f === item.id ? "bg-primary text-primary-foreground" : "border border-border text-muted-foreground"),
						children: item.label
					}, item.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted-foreground tabular-nums",
					children: [formatInt(list.length), " رأس"]
				}),
				sheep.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "القطيع فارغ. أضف أول رأس من زر الإضافة."
				}) : list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "لا نتائج."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-col gap-2",
					children: list.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheepCard, {
						sheep: s,
						breeding
					}, s.id))
				})
			]
		})
	});
}
//#endregion
export { FlockPage as component };
