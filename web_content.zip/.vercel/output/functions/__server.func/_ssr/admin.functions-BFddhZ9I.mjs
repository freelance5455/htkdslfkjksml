import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.functions-BFddhZ9I.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var EXPECTED = "5a0fa0761f8a636d285c7c517054f098427da9ef031a72158bfb102583208905";
var MAX_FAILS = 5;
var LOCK_MS = 6e5;
var SESSION_MS = 36e5;
var sessions = /* @__PURE__ */ new Map();
var fails = 0;
var lockedUntil = 0;
async function digest(password) {
	const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(`yooyyaa-admin-v1|${password}`));
	return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}
function same(a, b) {
	if (a.length !== b.length) return false;
	let n = 0;
	for (let i = 0; i < a.length; i += 1) n |= a.charCodeAt(i) ^ b.charCodeAt(i);
	return n === 0;
}
function token() {
	const bytes = /* @__PURE__ */ new Uint8Array(32);
	crypto.getRandomValues(bytes);
	return [...bytes].map((b) => b.toString(16).padStart(2, "0")).join("");
}
function passwordField(input) {
	if (!input || typeof input !== "object" || !("password" in input)) throw new Error("invalid");
	const password = input.password;
	if (typeof password !== "string" || password.length < 1 || password.length > 200) throw new Error("invalid");
	return password;
}
function tokenField(input) {
	if (!input || typeof input !== "object" || !("token" in input)) throw new Error("invalid");
	const value = input.token;
	if (typeof value !== "string" || value.length < 16 || value.length > 200) throw new Error("invalid");
	return value;
}
var adminLogin_createServerFn_handler = createServerRpc({
	id: "000d385d830f5d5b96c837e7c7a8e8a7e0fd34937fdaaf440ed137665146fadf",
	name: "adminLogin",
	filename: "src/lib/yooyyaa/admin.functions.ts"
}, (opts) => adminLogin.__executeServer(opts));
var adminLogin = createServerFn({ method: "POST" }).validator((input) => ({ password: passwordField(input) })).handler(adminLogin_createServerFn_handler, async ({ data }) => {
	const now = Date.now();
	if (now < lockedUntil) return {
		ok: false,
		lockedForMs: lockedUntil - now,
		attemptsLeft: 0
	};
	if (!same(await digest(data.password), EXPECTED)) {
		fails += 1;
		if (fails >= MAX_FAILS) {
			lockedUntil = now + LOCK_MS;
			fails = 0;
			return {
				ok: false,
				lockedForMs: LOCK_MS,
				attemptsLeft: 0
			};
		}
		return {
			ok: false,
			lockedForMs: 0,
			attemptsLeft: MAX_FAILS - fails
		};
	}
	fails = 0;
	lockedUntil = 0;
	const key = token();
	const expiresAt = now + SESSION_MS;
	sessions.set(key, expiresAt);
	return {
		ok: true,
		token: key,
		expiresAt
	};
});
var adminCheck_createServerFn_handler = createServerRpc({
	id: "26f64bc26b0ebda10e78df52bdee5b0f9122b8e4857462585dd8b69dbafe77e9",
	name: "adminCheck",
	filename: "src/lib/yooyyaa/admin.functions.ts"
}, (opts) => adminCheck.__executeServer(opts));
var adminCheck = createServerFn({ method: "POST" }).validator((input) => ({ token: tokenField(input) })).handler(adminCheck_createServerFn_handler, async ({ data }) => {
	const exp = sessions.get(data.token);
	if (!exp || exp < Date.now()) {
		sessions.delete(data.token);
		return { ok: false };
	}
	return {
		ok: true,
		expiresAt: exp
	};
});
//#endregion
export { adminCheck_createServerFn_handler, adminLogin_createServerFn_handler };
