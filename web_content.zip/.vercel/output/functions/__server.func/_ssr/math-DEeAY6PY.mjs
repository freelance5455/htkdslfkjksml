//#region node_modules/.nitro/vite/services/ssr/assets/math-DEeAY6PY.js
var CONFIG = {
	UPDATE_INTERVAL: 2e4,
	STATS_CONCURRENCY: 4,
	MAX_LIVE: 40,
	OU_LINES: [
		.5,
		1.5,
		2.5,
		3.5,
		4.5
	],
	HT_OU_LINES: [
		.5,
		1.5,
		2.5
	],
	TIME_WINDOWS: [
		5,
		10,
		15,
		20,
		30
	],
	DIST_KMAX: 14,
	DIXON_COLES_RHO: -.08,
	HP: {
		MIN_MINUTE: 28,
		MIN_SHOTS: 7,
		MIN_XG: .65,
		MIN_BC: 1,
		MIN_CONF: 38,
		MIN_PRESSURE_DIFF: 10,
		REQUIRE_MOMENTUM_ALIGN: true
	}
};
var LEAGUE_GOAL_PRIORS = [
	{
		k: [
			"bundesliga",
			"germany",
			"alemanha"
		],
		avg: 3.2,
		code: "GER"
	},
	{
		k: [
			"eredivisie",
			"netherlands",
			"holanda"
		],
		avg: 3.15,
		code: "NED"
	},
	{
		k: ["mls", "major league soccer"],
		avg: 2.95,
		code: "USA"
	},
	{
		k: ["champions league", "liga dos campeões"],
		avg: 2.88,
		code: "UCL"
	},
	{
		k: [
			"premier league",
			"england",
			"inglaterra"
		],
		avg: 2.82,
		code: "ENG"
	},
	{
		k: [
			"liga mx",
			"mexico",
			"méxico"
		],
		avg: 2.8,
		code: "MEX"
	},
	{
		k: ["europa league"],
		avg: 2.75,
		code: "UEL"
	},
	{
		k: [
			"serie a",
			"italy",
			"itália"
		],
		avg: 2.68,
		code: "ITA"
	},
	{
		k: ["championship"],
		avg: 2.62,
		code: "ENG"
	},
	{
		k: [
			"ligue 1",
			"france",
			"frança"
		],
		avg: 2.6,
		code: "FRA"
	},
	{
		k: [
			"liga portugal",
			"primeira liga",
			"portugal"
		],
		avg: 2.58,
		code: "POR"
	},
	{
		k: [
			"la liga",
			"laliga",
			"primera division",
			"primera división",
			"spain",
			"espanha"
		],
		avg: 2.55,
		code: "ESP"
	},
	{
		k: [
			"super lig",
			"turkey",
			"turquia"
		],
		avg: 2.9,
		code: "TUR"
	},
	{
		k: [
			"brasileirão",
			"brasileirao",
			"brazil",
			"brasil"
		],
		avg: 2.35,
		code: "BRA"
	},
	{
		k: ["argentina", "liga profesional"],
		avg: 2.3,
		code: "ARG"
	}
];
var DEFAULT_LEAGUE_AVG_GOALS = 2.7;
function getLeaguePrior(leagueName) {
	const n = (leagueName || "").toLowerCase();
	for (const row of LEAGUE_GOAL_PRIORS) if (row.k.some((kw) => n.includes(kw))) return row;
	return {
		k: [],
		avg: DEFAULT_LEAGUE_AVG_GOALS,
		code: "INT"
	};
}
function getLeagueAvgGoals(leagueName) {
	return getLeaguePrior(leagueName).avg;
}
function clamp(v, lo, hi) {
	return Math.max(lo, Math.min(hi, v));
}
function num(v) {
	if (v == null) return 0;
	if (typeof v === "number") return Number.isFinite(v) ? v : 0;
	const n = parseFloat(String(v).replace("%", "").trim());
	return Number.isFinite(n) ? n : 0;
}
var LANCZOS_G = 7;
var LANCZOS_COEF = [
	.9999999999998099,
	676.5203681218851,
	-1259.1392167224028,
	771.3234287776531,
	-176.6150291621406,
	12.507343278686905,
	-.13857109526572012,
	9984369578019572e-21,
	1.5056327351493116e-7
];
function lgamma(x) {
	if (x < .5) return Math.log(Math.PI / Math.sin(Math.PI * x)) - lgamma(1 - x);
	x -= 1;
	let a = LANCZOS_COEF[0];
	const t = x + LANCZOS_G + .5;
	for (let i = 1; i < 9; i++) a += LANCZOS_COEF[i] / (x + i);
	return .5 * Math.log(2 * Math.PI) + (x + .5) * Math.log(t) - t + Math.log(a);
}
function negBinomPMF(k, r, p) {
	if (k < 0) return 0;
	if (r <= 0 || p <= 0) return k === 0 ? 1 : 0;
	if (p >= 1) return k === 0 ? 1 : 0;
	const logP = lgamma(k + r) - lgamma(r) - lgamma(k + 1) + r * Math.log(p) + k * Math.log(1 - p);
	return Math.exp(logP);
}
function cdfFromPmf(pmf, k) {
	if (k < 0) return 0;
	let s = 0;
	for (let i = 0; i <= Math.min(k, pmf.length - 1); i++) s += pmf[i];
	return Math.min(1, s);
}
function remainingGoalsDist(rH, pH, rA, pA, kMax) {
	const pmfH = [];
	const pmfA = [];
	for (let i = 0; i <= kMax; i++) {
		pmfH[i] = negBinomPMF(i, rH, pH);
		pmfA[i] = negBinomPMF(i, rA, pA);
	}
	const meanH = pH > 0 ? rH * (1 - pH) / pH : 0;
	const meanA = pA > 0 ? rA * (1 - pA) / pA : 0;
	const RHO = CONFIG.DIXON_COLES_RHO;
	const tau = (x, y) => {
		if (x === 0 && y === 0) return 1 - meanH * meanA * RHO;
		if (x === 0 && y === 1) return 1 + meanH * RHO;
		if (x === 1 && y === 0) return 1 + meanA * RHO;
		if (x === 1 && y === 1) return 1 - RHO;
		return 1;
	};
	let normTotal = 0;
	for (let i = 0; i <= kMax; i++) for (let j = 0; j <= kMax; j++) {
		let v = pmfH[i] * pmfA[j];
		if (i <= 1 && j <= 1) v *= tau(i, j);
		normTotal += v;
	}
	if (normTotal <= 0) normTotal = 1;
	const pmfTotal = new Array(kMax + 1).fill(0);
	let jointP00 = 0;
	for (let i = 0; i <= kMax; i++) for (let j = 0; j <= kMax; j++) {
		let v = pmfH[i] * pmfA[j];
		if (i <= 1 && j <= 1) v *= tau(i, j);
		v /= normTotal;
		if (i === 0 && j === 0) jointP00 = v;
		const k = i + j;
		if (k <= kMax) pmfTotal[k] += v;
	}
	return {
		pmfTotal,
		pH0: pmfH[0],
		pA0: pmfA[0],
		jointP00
	};
}
function initials(name) {
	const parts = name.replace(/[^A-Za-zÀ-ÿ0-9 ]/g, " ").trim().split(/\s+/).filter(Boolean);
	if (!parts.length) return "•";
	if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
	return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}
//#endregion
export { getLeaguePrior as a, remainingGoalsDist as c, getLeagueAvgGoals as i, cdfFromPmf as n, initials as o, clamp as r, num as s, CONFIG as t };
