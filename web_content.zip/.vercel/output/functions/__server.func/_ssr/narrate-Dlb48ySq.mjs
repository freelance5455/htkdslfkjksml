import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { i as norm, o as sameName, s as uid, t as clamp } from "./text-CqN-AAxZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/narrate-Dlb48ySq.js
var DEFAULT_BOUNDARIES = "Sin sexo explícito. Si hay violencia, se narra con contención y sin recrearse en el daño. Nada de contenido sexual que involucre a menores.";
function blankCharacter(partial) {
	return {
		id: uid(),
		name: "",
		role: "",
		appearance: "",
		personality: "",
		voice: "",
		knowledge: "",
		motivations: "",
		limits: "",
		goal: "",
		secret: "",
		mood: "Expectante",
		agenda: "Sigue con su propia vida.",
		place: "",
		opinion: 0,
		bondNote: "",
		origin: "forjado",
		weight: "principal",
		...partial
	};
}
function createCampaign(input) {
	const now = Date.now();
	const places = input.places.map((place) => ({
		id: uid(),
		name: place.name.trim(),
		note: place.note.trim()
	})).filter((place) => place.name);
	const cast = input.cast.map((character) => ({
		...character,
		name: character.name.trim(),
		place: character.place.trim() || places[0]?.name || ""
	})).filter((character) => character.name && !sameName(character.name, input.oc.name));
	return {
		id: uid(),
		title: input.title.trim() || input.universe.trim() || "Partida sin título",
		createdAt: now,
		updatedAt: now,
		universe: input.universe.trim(),
		premise: input.premise.trim(),
		tone: input.tone.trim(),
		rules: input.rules.trim(),
		boundaries: input.boundaries.trim() || "Sin sexo explícito. Si hay violencia, se narra con contención y sin recrearse en el daño. Nada de contenido sexual que involucre a menores.",
		prose: input.prose,
		autonomy: input.autonomy,
		clock: {
			day: 1,
			minute: 540,
			label: "mañana"
		},
		places,
		oc: {
			name: input.oc.name.trim(),
			pronouns: input.oc.pronouns.trim(),
			appearance: input.oc.appearance.trim(),
			voice: input.oc.voice.trim(),
			background: input.oc.background.trim(),
			goal: input.oc.goal.trim(),
			trait: input.oc.trait.trim()
		},
		cast,
		scene: {
			place: places[0]?.name ?? "",
			atmosphere: "",
			summary: "",
			present: []
		},
		threads: [],
		entries: [],
		memories: [],
		chronicle: [],
		undo: null
	};
}
function snapshot(campaign) {
	const { undo: _undo, ...rest } = campaign;
	return rest;
}
function ensurePlace(places, name, note = "") {
	const trimmed = name.trim();
	if (!trimmed) return places;
	if (places.some((place) => sameName(place.name, trimmed))) return places;
	return [...places, {
		id: uid(),
		name: trimmed,
		note: note.trim()
	}];
}
function appendKnowledge(current, extra) {
	const next = extra.trim();
	if (!next) return current;
	if (norm(current).includes(norm(next))) return current;
	return (current.trim() ? `${current.trim()}\n${next}` : next).slice(0, 700);
}
function isOc(campaign, name) {
	return sameName(name, campaign.oc.name);
}
function touchCharacter(campaign, cast, update) {
	if (isOc(campaign, update.nombre)) return cast;
	const index = cast.findIndex((character) => sameName(character.name, update.nombre));
	if (index === -1) return [...cast, blankCharacter({
		name: update.nombre,
		role: "Presencia surgida en la escena",
		knowledge: update.conocimiento,
		motivations: update.motivo,
		goal: update.motivo,
		mood: update.animo || "Indefinido",
		agenda: update.agenda || "Acaba de entrar en la historia.",
		place: update.lugar || campaign.scene.place,
		opinion: update.opinion,
		bondNote: update.vinculo,
		origin: "surgido",
		weight: "menor"
	})];
	const current = cast[index];
	const next = {
		...current,
		mood: update.animo || current.mood,
		place: update.lugar || current.place,
		agenda: update.agenda || current.agenda,
		opinion: clamp(current.opinion + update.opinion, -5, 5),
		knowledge: appendKnowledge(current.knowledge, update.conocimiento),
		bondNote: update.vinculo || current.bondNote,
		goal: update.motivo || current.goal,
		motivations: update.motivo || current.motivations
	};
	return cast.map((character, i) => i === index ? next : character);
}
function capEntries(entries) {
	if (entries.length <= 180) return entries;
	return [...entries.slice(0, 2), ...entries.slice(-160)];
}
function capMemories(memories) {
	if (memories.length <= 48) return memories;
	const newest = memories.slice(-8);
	const older = memories.slice(0, -8);
	older.sort((a, b) => b.importance - a.importance || b.at - a.at);
	return [...older.slice(0, 40), ...newest];
}
function applyNarration(campaign, result, meta) {
	const now = Date.now();
	let places = campaign.places;
	for (const place of result.lugaresNuevos) places = ensurePlace(places, place.nombre, place.nota);
	const scenePlace = result.escena.lugar || campaign.scene.place;
	places = ensurePlace(places, scenePlace);
	let cast = campaign.cast;
	for (const update of result.personajes) cast = touchCharacter({
		...campaign,
		scene: {
			...campaign.scene,
			place: scenePlace
		}
	}, cast, update);
	const namedPresent = result.escena.presentes.filter((name) => !isOc(campaign, name));
	cast = cast.map((character) => {
		if (namedPresent.some((name) => sameName(name, character.name)) && scenePlace) return {
			...character,
			place: scenePlace
		};
		return character;
	});
	const present = [campaign.oc.name, ...cast.filter((character) => scenePlace && sameName(character.place, scenePlace)).map((character) => character.name)].filter((name, index, all) => name && all.findIndex((other) => sameName(other, name)) === index);
	const entries = [...campaign.entries];
	if ((meta.mode === "turno" || meta.mode === "apertura") && meta.playerText.trim()) entries.push({
		id: uid(),
		at: now,
		kind: "jugador",
		speaker: campaign.oc.name,
		text: meta.playerText.trim()
	});
	for (const beat of result.beats) entries.push({
		id: uid(),
		at: now,
		kind: beat.kind,
		speaker: beat.kind === "narracion" ? null : beat.speaker,
		text: beat.text
	});
	const minutes = result.reloj.minutos || (meta.mode === "aliento" ? 20 : 8);
	let minute = campaign.clock.minute + minutes;
	let day = campaign.clock.day;
	while (minute >= 1440) {
		minute -= 1440;
		day += 1;
	}
	const memories = [...campaign.memories, ...result.memorias.map((memory) => ({
		id: uid(),
		at: now,
		summary: memory.resumen,
		importance: memory.importancia,
		who: memory.quienes
	}))];
	const chronicle = [...campaign.chronicle, ...result.fueraDeEscena.map((event) => ({
		id: uid(),
		at: now,
		summary: event.resumen,
		who: event.quienes,
		seen: false
	}))].slice(-40);
	return {
		...campaign,
		updatedAt: now,
		places,
		cast,
		clock: {
			day,
			minute,
			label: result.reloj.etiqueta || campaign.clock.label
		},
		scene: {
			place: scenePlace,
			atmosphere: result.escena.atmosfera || campaign.scene.atmosphere,
			summary: result.escena.resumen || campaign.scene.summary,
			present
		},
		threads: result.hilos.length > 0 ? result.hilos : campaign.threads,
		entries: capEntries(entries),
		memories: capMemories(memories),
		chronicle,
		undo: snapshot(campaign)
	};
}
function restoreUndo(campaign) {
	if (!campaign.undo) return null;
	return {
		...campaign.undo,
		undo: null,
		updatedAt: Date.now()
	};
}
function addManualMemory(campaign, summary) {
	const text = summary.trim();
	if (!text) return campaign;
	return {
		...campaign,
		updatedAt: Date.now(),
		memories: capMemories([...campaign.memories, {
			id: uid(),
			at: Date.now(),
			summary: text.slice(0, 280),
			importance: 3,
			who: []
		}])
	};
}
function markChronicleSeen(campaign) {
	if (!campaign.chronicle.some((event) => !event.seen)) return campaign;
	return {
		...campaign,
		chronicle: campaign.chronicle.map((event) => ({
			...event,
			seen: true
		}))
	};
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var MODES = [
	"apertura",
	"turno",
	"aliento"
];
function asRecord(value) {
	if (value && typeof value === "object" && !Array.isArray(value)) return value;
	return null;
}
function requireCampaign(value) {
	const row = asRecord(value);
	const oc = asRecord(row?.oc);
	if (!row || typeof row.id !== "string" || !oc || typeof oc.name !== "string" || !oc.name.trim()) throw new Error("La partida está incompleta.");
	if (JSON.stringify(row).length > 35e4) throw new Error("Esta partida pesa demasiado para enviarla de una vez.");
	return row;
}
var narrateTurn = createServerFn({ method: "POST" }).validator((input) => {
	const row = asRecord(input);
	const mode = row?.mode;
	if (typeof mode !== "string" || !MODES.includes(mode)) throw new Error("Modo de escena desconocido.");
	const playerText = typeof row?.playerText === "string" ? row.playerText.trim().slice(0, 2e3) : "";
	if (mode === "turno" && !playerText) throw new Error("Escribe lo que hace o dice tu personaje.");
	return {
		mode,
		playerText,
		campaign: requireCampaign(row?.campaign)
	};
}).handler(createSsrRpc("57fd8acbd7c97a77f45101ad275354659756248ad5c78bfb3593cd7709914a7e"));
var suggestCast = createServerFn({ method: "POST" }).validator((input) => {
	const row = asRecord(input);
	const premise = typeof row?.premise === "string" ? row.premise.trim().slice(0, 1200) : "";
	if (premise.length < 12) throw new Error("Cuéntame un poco más la premisa antes de forjar el reparto.");
	return {
		universe: typeof row?.universe === "string" ? row.universe.slice(0, 200) : "",
		premise,
		tone: typeof row?.tone === "string" ? row.tone.slice(0, 240) : "",
		rules: typeof row?.rules === "string" ? row.rules.slice(0, 600) : "",
		ocName: typeof row?.ocName === "string" ? row.ocName.slice(0, 80) : "",
		boundaries: typeof row?.boundaries === "string" ? row.boundaries.slice(0, 400) : ""
	};
}).handler(createSsrRpc("92ad00fdca5d729191d03733730f538c395f17c4a729464f663ef6551936f2bd"));
//#endregion
export { createCampaign as a, restoreUndo as c, blankCharacter as i, suggestCast as l, addManualMemory as n, markChronicleSeen as o, applyNarration as r, narrateTurn as s, DEFAULT_BOUNDARIES as t };
