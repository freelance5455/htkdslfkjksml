//#region node_modules/.nitro/vite/services/ssr/assets/export-tWZA3qLh.js
function downloadCsv(filename, headers, rows) {
	const esc = (v) => `"${String(v).replaceAll("\"", "\"\"")}"`;
	const csv = [headers.map(esc).join(","), ...rows.map((r) => r.map(esc).join(","))].join("\n");
	const blob = new Blob(["﻿" + csv], { type: "text/csv;charset=utf-8;" });
	const a = document.createElement("a");
	a.href = URL.createObjectURL(blob);
	a.download = filename.endsWith(".csv") ? filename : `${filename}.csv`;
	a.click();
	URL.revokeObjectURL(a.href);
}
function downloadJson(filename, data) {
	const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
	const a = document.createElement("a");
	a.href = URL.createObjectURL(blob);
	a.download = filename.endsWith(".json") ? filename : `${filename}.json`;
	a.click();
	URL.revokeObjectURL(a.href);
}
function printReport() {
	window.print();
}
//#endregion
export { downloadJson as n, printReport as r, downloadCsv as t };
