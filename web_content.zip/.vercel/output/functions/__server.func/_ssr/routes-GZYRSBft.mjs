import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as require_jsx_runtime, t as useInfiniteQuery } from "../_libs/react+tanstack__react-query.mjs";
import { a as cn, i as Button, o as formatCount, r as ErrorBoundary } from "./router-D8sFVTug.mjs";
import { f as ChevronRight, o as Search, p as ChevronLeft, r as X, u as LoaderCircle } from "../_libs/lucide-react.mjs";
import { _ as searchChannelsFn, a as POST_SORTS, b as useSubscriptions, c as PostCard, d as SubscribeButton, f as TOPICS, g as loadFeedPageFn, i as DesktopNav, l as PostCardSkeleton, n as BottomNav, o as POST_TYPES, p as TYPE_FILTER, r as ChipBar, s as PageFrame, t as Badge, u as PullToRefresh, v as sortPosts, y as useSentinel } from "./topics-Bb1SXlXD.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-GZYRSBft.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CategoryBar({ value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChipBar, {
		ariaLabel: "Categories",
		items: TOPICS.map((t) => ({
			id: t.id,
			label: t.label
		})),
		value,
		onChange
	});
}
function ChannelCard({ channel }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "rounded-2xl border border-border bg-card p-3",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/channel/$channelId",
				params: { channelId: channel.id },
				className: "flex min-w-0 flex-1 items-start gap-3",
				children: [channel.thumbnail ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: channel.thumbnail,
					alt: "",
					className: "size-14 shrink-0 rounded-full object-cover"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "flex size-14 shrink-0 items-center justify-center rounded-full bg-muted text-lg font-medium",
					children: channel.title.slice(0, 1)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "min-w-0 flex-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block truncate font-medium text-foreground",
							children: channel.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "mt-0.5 block truncate text-xs text-muted-foreground",
							children: [channel.handle ? `${channel.handle} · ` : "", channel.subscriberText || `${formatCount(channel.subscriberCount)} subscribers`]
						}),
						channel.subscriberCount === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1.5 inline-flex",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: "outline",
								children: "0 subscribers"
							})
						}) : null
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "shrink-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SubscribeButton, { channel })
			})]
		})
	});
}
function ChannelCardSkeleton() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex gap-3 rounded-2xl border border-border bg-card p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-14 animate-pulse rounded-full bg-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex-1 space-y-2 pt-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-3.5 w-40 animate-pulse rounded bg-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-3 w-28 animate-pulse rounded bg-muted" })]
		})]
	});
}
function FollowingList({ onSearch }) {
	const channels = useSubscriptions((s) => s.channels);
	const sorted = (0, import_react.useMemo)(() => [...channels].sort((a, b) => (b.subscribedAt ?? 0) - (a.subscribedAt ?? 0)), [channels]);
	const [index, setIndex] = (0, import_react.useState)(0);
	const startX = (0, import_react.useRef)(0);
	if (sorted.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-border bg-card px-6 py-12 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-lg font-semibold",
				children: "No subscriptions yet"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mx-auto mt-2 max-w-sm text-sm text-muted-foreground",
				children: "Subscribe to any channel. This tab lists them one at a time, newest subscription first."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-5",
				onClick: onSearch,
				children: "Search channels"
			})
		]
	});
	const safeIndex = Math.min(index, sorted.length - 1);
	const channel = sorted[safeIndex];
	const go = (dir) => {
		setIndex((i) => Math.min(sorted.length - 1, Math.max(0, i + dir)));
	};
	const onTouchStart = (e) => {
		startX.current = e.touches[0]?.clientX ?? 0;
	};
	const onTouchEnd = (e) => {
		const dx = (e.changedTouches[0]?.clientX ?? startX.current) - startX.current;
		if (dx > 48) go(-1);
		if (dx < -48) go(1);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-[70dvh] flex-col",
		onTouchStart,
		onTouchEnd,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mb-3 px-1 text-xs text-muted-foreground",
				children: [
					safeIndex + 1,
					" of ",
					sorted.length,
					" · most recently subscribed first"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex min-h-0 flex-1 flex-col justify-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChannelCard, { channel })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					variant: "outline",
					className: "flex-1",
					disabled: safeIndex === 0,
					onClick: () => go(-1),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, {}), "Previous"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					variant: "outline",
					className: "flex-1",
					disabled: safeIndex >= sorted.length - 1,
					onClick: () => go(1),
					children: ["Next", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {})]
				})]
			})
		]
	});
}
var Input = import_react.forwardRef(({ className, type, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		className: cn("flex h-11 w-full rounded-xl border border-border bg-secondary px-4 text-base text-foreground shadow-none transition-[border-color,box-shadow] duration-[var(--motion-quick)] placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50", className),
		ref,
		...props
	});
});
Input.displayName = "Input";
function useDebounced(value, ms) {
	const [v, setV] = (0, import_react.useState)(value);
	(0, import_react.useEffect)(() => {
		const t = setTimeout(() => setV(value), ms);
		return () => clearTimeout(t);
	}, [value, ms]);
	return v;
}
function SearchPanel({ autoFocus }) {
	const [q, setQ] = (0, import_react.useState)("");
	const debounced = useDebounced(q.trim(), 280);
	const inputRef = (0, import_react.useRef)(null);
	const sentinel = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		if (autoFocus) inputRef.current?.focus();
	}, [autoFocus]);
	const { data, isLoading, isError, hasNextPage, isFetchingNextPage, isFetching, fetchNextPage } = useInfiniteQuery({
		queryKey: ["channel-search", debounced],
		enabled: debounced.length > 0,
		initialPageParam: null,
		queryFn: async ({ pageParam }) => searchChannelsFn({ data: {
			query: debounced,
			continuation: pageParam
		} }),
		getNextPageParam: (last, pages) => {
			const token = last.continuation ?? void 0;
			if (!token) return void 0;
			if (pages.some((p, i) => i < pages.length - 1 && p.continuation === token)) return;
			return token;
		},
		retry: 1
	});
	const channels = (0, import_react.useMemo)(() => {
		const seen = /* @__PURE__ */ new Set();
		const list = [];
		for (const page of data?.pages ?? []) {
			if (page.resolved && !seen.has(page.resolved.id)) {
				seen.add(page.resolved.id);
				list.push(page.resolved);
			}
			for (const ch of page.channels) {
				if (seen.has(ch.id)) continue;
				seen.add(ch.id);
				list.push(ch);
			}
		}
		return list;
	}, [data]);
	const loadMore = (0, import_react.useCallback)(() => {
		if (hasNextPage && !isFetchingNextPage && !isFetching) fetchNextPage();
	}, [
		fetchNextPage,
		hasNextPage,
		isFetching,
		isFetchingNextPage
	]);
	useSentinel(sentinel, Boolean(hasNextPage && !isFetchingNextPage), loadMore);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative px-4 pb-3 pt-1",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute left-7 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					ref: inputRef,
					value: q,
					onChange: (e) => setQ(e.target.value),
					placeholder: "Search any channel, @handle, or ID",
					className: "pl-10 pr-11 text-base",
					enterKeyHint: "search",
					autoCapitalize: "none",
					autoCorrect: "off",
					spellCheck: false,
					"aria-label": "Search YouTube channels"
				}),
				q ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "absolute right-7 top-1/2 flex size-8 -translate-y-1/2 items-center justify-center rounded-full text-muted-foreground hover:text-foreground",
					onClick: () => {
						setQ("");
						inputRef.current?.focus();
					},
					"aria-label": "Clear search",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
				}) : null
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "scroll-pane min-h-0 flex-1 overflow-y-auto px-4 pb-28",
			children: !debounced ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-1 py-8 text-sm text-muted-foreground",
				children: "Find literally any channel — including ones with zero subscribers and channels that have never posted to Community."
			}) : isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-2",
				children: Array.from({ length: 6 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChannelCardSkeleton, {}, i))
			}) : isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-1 py-8 text-sm text-muted-foreground",
				children: "Couldn’t reach YouTube. Try another search."
			}) : channels.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "px-1 py-8 text-sm text-muted-foreground",
				children: [
					"No channels matched “",
					debounced,
					"”. Try an @handle or channel ID."
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [
					channels.map((ch) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChannelCard, { channel: ch }, ch.id)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						ref: sentinel,
						className: "h-8"
					}),
					isFetchingNextPage ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex justify-center py-4 text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" })
					}) : null,
					!hasNextPage ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "py-4 text-center text-xs text-muted-foreground",
						children: "Showing every public match YouTube returned."
					}) : null
				]
			})
		})]
	});
}
function useCommunityFeed(opts) {
	const query = useInfiniteQuery({
		queryKey: [
			"feed",
			opts.topic,
			opts.subscribedIds.join(",")
		],
		enabled: opts.enabled,
		initialPageParam: {
			queryIndex: 0,
			searchContinuation: null,
			cursors: opts.subscribedIds.map((id) => ({
				id,
				continuation: null
			}))
		},
		queryFn: async ({ pageParam }) => {
			return loadFeedPageFn({ data: {
				topic: opts.topic,
				queryIndex: pageParam.queryIndex,
				searchContinuation: pageParam.searchContinuation,
				extraChannelIds: [],
				channelCursors: pageParam.cursors.slice(0, 400),
				discover: true
			} });
		},
		getNextPageParam: (last, pages) => {
			const prev = pages.at(-2);
			if (prev && prev.queryIndex === last.queryIndex && prev.searchContinuation === last.searchContinuation && JSON.stringify(prev.nextCursors) === JSON.stringify(last.nextCursors)) return {
				queryIndex: last.queryIndex + 1,
				searchContinuation: null,
				cursors: last.nextCursors
			};
			return {
				queryIndex: last.queryIndex,
				searchContinuation: last.searchContinuation,
				cursors: last.nextCursors
			};
		},
		retry: 1,
		refetchOnMount: false,
		throwOnError: false
	});
	const channels = (0, import_react.useMemo)(() => {
		const seen = /* @__PURE__ */ new Set();
		const list = [];
		for (const page of query.data?.pages ?? []) for (const ch of page.channels) {
			if (seen.has(ch.id)) continue;
			seen.add(ch.id);
			list.push(ch);
		}
		return list;
	}, [query.data]);
	const posts = (0, import_react.useMemo)(() => {
		const seen = /* @__PURE__ */ new Set();
		const list = [];
		for (const page of query.data?.pages ?? []) for (const post of page.posts) {
			if (seen.has(post.id)) continue;
			seen.add(post.id);
			list.push(post);
		}
		const fromType = opts.type !== "all" ? TYPE_FILTER[opts.type] : void 0;
		const fromTopic = TYPE_FILTER[opts.topic];
		const kind = fromType ?? fromTopic;
		const typed = kind ? list.filter((p) => p.kind === kind) : list;
		return sortPosts(typed, opts.sort);
	}, [
		opts.sort,
		opts.topic,
		opts.type,
		query.data
	]);
	return {
		...query,
		posts,
		channels
	};
}
function Home() {
	const [tab, setTab] = (0, import_react.useState)("community");
	const [topic, setTopic] = (0, import_react.useState)("all");
	const [type, setType] = (0, import_react.useState)("all");
	const [sort, setSort] = (0, import_react.useState)("newest");
	const feed = useCommunityFeed({
		topic,
		type,
		sort,
		subscribedIds: useSubscriptions((s) => s.channels).map((c) => c.id),
		enabled: tab === "community"
	});
	const sentinel = (0, import_react.useRef)(null);
	const { posts, isLoading, isFetching, isFetchingNextPage, isError, hasNextPage, fetchNextPage, refetch } = feed;
	const loadMore = (0, import_react.useCallback)(() => {
		if (hasNextPage && !isFetchingNextPage && !isFetching) fetchNextPage();
	}, [
		fetchNextPage,
		hasNextPage,
		isFetching,
		isFetchingNextPage
	]);
	useSentinel(sentinel, tab === "community" && Boolean(hasNextPage && !isFetchingNextPage), loadMore);
	const onRefresh = (0, import_react.useCallback)(async () => {
		await refetch();
	}, [refetch]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PageFrame, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DesktopNav, {
			tab,
			onTab: setTab
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex h-full min-h-0 min-w-0 flex-1 flex-col overflow-hidden",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-30 border-b border-border bg-background/95 backdrop-blur-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "min-w-0 flex-1",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "truncate font-display text-base font-semibold tracking-tight lg:text-xl",
							children: tab === "search" ? "Search channels" : tab === "following" ? "Following" : "Community"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						size: "icon",
						variant: tab === "search" ? "default" : "muted",
						onClick: () => setTab("search"),
						"aria-label": "Search",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {})
					})]
				}), tab === "community" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CategoryBar, {
						value: topic,
						onChange: setTopic
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChipBar, {
						ariaLabel: "Post type",
						items: POST_TYPES,
						value: type,
						onChange: setType
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChipBar, {
						ariaLabel: "Sort posts",
						items: POST_SORTS,
						value: sort,
						onChange: setSort
					})
				] }) : null]
			}), tab === "search" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchPanel, { autoFocus: true }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PullToRefresh, {
				onRefresh: tab === "community" ? onRefresh : async () => void 0,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto w-full max-w-2xl px-4 pb-28 pt-4 lg:pb-10",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ErrorBoundary, { children: [
						tab === "following" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FollowingList, { onSearch: () => setTab("search") }) : isLoading || posts.length === 0 && isFetching ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-3",
							children: Array.from({ length: 4 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PostCardSkeleton, {}, i))
						}) : isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
							title: "Couldn’t load posts",
							body: "Swipe down to try again.",
							actionLabel: "Retry",
							onAction: () => refetch()
						}) : posts.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
							title: "No posts in this view",
							body: "This filter is still filling. Try All or another type."
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-3",
							children: posts.map((post) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PostCard, { post }, post.id))
						}),
						tab === "community" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							ref: sentinel,
							className: "h-10"
						}) : null,
						tab === "community" && isFetchingNextPage ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex items-center justify-center py-6 text-muted-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-5 animate-spin" })
						}) : null
					] })
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BottomNav, {
			tab,
			onTab: setTab
		})
	] });
}
function EmptyState({ title, body, actionLabel, onAction }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-border bg-card px-6 py-12 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-lg font-semibold",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mx-auto mt-2 max-w-sm text-sm text-muted-foreground",
				children: body
			}),
			actionLabel && onAction ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-5",
				onClick: onAction,
				children: actionLabel
			}) : null
		]
	});
}
//#endregion
export { Home as component };
