//#region node_modules/.nitro/vite/services/ssr/assets/model-CryEHs3X.js
var defaultSettings = {
	fontScale: "md",
	hideAfter: 0,
	showJoins: false,
	showLikes: false,
	modsOnly: false,
	blocked: "",
	ttsChat: false,
	ttsGifts: false,
	sound: false,
	voice: "mix",
	likeGoal: 5e3,
	followGoal: 20,
	coinGoal: 1e3
};
var luna = {
	name: "luna.mods",
	nick: "Luna",
	role: "mod"
};
var kai = {
	name: "kai.sub",
	nick: "Kai",
	role: "sub"
};
var nico = {
	name: "nico.rivera",
	nick: "Nico",
	role: "viewer"
};
var sofi = {
	name: "sofi.beats",
	nick: "Sofi",
	role: "fan"
};
var mara = {
	name: "mara.live",
	nick: "Mara",
	role: "viewer"
};
var theo = {
	name: "theo.jpg",
	nick: "Theo",
	role: "viewer"
};
var SEED = [
	{
		id: "seed-viewers",
		ts: 0,
		kind: "viewers",
		count: 186
	},
	{
		id: "seed-c1",
		ts: 0,
		kind: "chat",
		user: nico,
		text: "hola desde CDMX, se escucha clarísimo"
	},
	{
		id: "seed-f1",
		ts: 0,
		kind: "follow",
		user: sofi
	},
	{
		id: "seed-c2",
		ts: 0,
		kind: "chat",
		user: luna,
		text: "recuerda el sorteo a las 9, dejo la pregunta fija"
	},
	{
		id: "seed-g1",
		ts: 0,
		kind: "gift",
		user: kai,
		gift: "Rosa",
		diamonds: 1,
		repeat: 5
	},
	{
		id: "seed-c3",
		ts: 0,
		kind: "chat",
		user: mara,
		text: "¿a qué hora cierran las preguntas?"
	},
	{
		id: "seed-like",
		ts: 0,
		kind: "like",
		user: theo,
		count: 42,
		total: 1280
	},
	{
		id: "seed-c4",
		ts: 0,
		kind: "chat",
		user: sofi,
		text: "!baile cuando lleguemos a 200"
	},
	{
		id: "seed-s1",
		ts: 0,
		kind: "share",
		user: theo
	},
	{
		id: "seed-g2",
		ts: 0,
		kind: "gift",
		user: nico,
		gift: "Galaxia",
		diamonds: 1e3,
		repeat: 1
	}
];
var CAST = [
	luna,
	kai,
	nico,
	sofi,
	mara,
	theo,
	{
		name: "vale.23",
		nick: "Vale",
		role: "viewer"
	}
];
var LINES = [
	"esa transición estuvo brutal",
	"saludos a Monterrey, primera vez aquí",
	"jajaja no puede ser",
	"¿cuál es el siguiente tema?",
	"se fue un segundo el audio, ya volvió",
	"te sigo desde el live de ayer",
	"!hola desde Guadalajara",
	"pon la cámara más cerca",
	"¿hacen dueto hoy?",
	"me quedo, esto está bueno",
	"el chat va rapidísimo",
	"manda saludos a mi hermana",
	"¿a qué hora el sorteo?",
	"!lights otra vez",
	"ya compartí el live"
];
var GIFTS = [
	{
		gift: "Rosa",
		diamonds: 1
	},
	{
		gift: "Corazón",
		diamonds: 5
	},
	{
		gift: "Helado",
		diamonds: 10
	},
	{
		gift: "Dona",
		diamonds: 30
	},
	{
		gift: "Perfume",
		diamonds: 20
	},
	{
		gift: "León",
		diamonds: 299
	},
	{
		gift: "Cohete",
		diamonds: 500
	}
];
function emptyStats() {
	return {
		viewers: 0,
		likes: 0,
		follows: 0,
		shares: 0,
		coins: 0,
		ranks: []
	};
}
function applyStats(stats, event) {
	if (event.kind === "viewers") return {
		...stats,
		viewers: event.count
	};
	if (event.kind === "like") {
		const likes = event.total ? Math.max(stats.likes, event.total) : stats.likes + event.count;
		return {
			...stats,
			likes
		};
	}
	if (event.kind === "follow") return {
		...stats,
		follows: stats.follows + 1
	};
	if (event.kind === "share") return {
		...stats,
		shares: stats.shares + 1
	};
	if (event.kind === "gift") {
		const coins = event.diamonds * Math.max(1, event.repeat);
		const prev = stats.ranks.find((row) => row.name === event.user.name);
		const ranks = [...stats.ranks.filter((row) => row.name !== event.user.name), {
			name: event.user.name,
			nick: event.user.nick,
			role: event.user.role,
			coins: (prev?.coins ?? 0) + coins
		}].sort((a, b) => b.coins - a.coins).slice(0, 12);
		return {
			...stats,
			coins: stats.coins + coins,
			ranks
		};
	}
	return stats;
}
function summarize(events) {
	return events.reduce(applyStats, emptyStats());
}
function formatCount(n) {
	return new Intl.NumberFormat("es-MX").format(Math.max(0, Math.round(n)));
}
function blockedWords(raw) {
	return raw.split(",").map((part) => part.trim().toLowerCase()).filter(Boolean);
}
function isChatVisible(event, settings, hidden) {
	if (event.kind === "viewers" || event.kind === "sync" || event.kind === "status") return false;
	if (!("user" in event)) return false;
	if (hidden.includes(event.user.name)) return false;
	if (event.kind === "like") return settings.showLikes;
	if (event.kind === "join") return settings.showJoins;
	if (event.kind === "chat") {
		if (settings.modsOnly && event.user.role !== "mod" && event.user.role !== "sub") return false;
		const text = event.text.toLowerCase();
		if (blockedWords(settings.blocked).some((word) => text.includes(word))) return false;
		return true;
	}
	return event.kind === "gift" || event.kind === "follow" || event.kind === "share";
}
function nextDemo(viewers) {
	const id = `d-${Math.random().toString(36).slice(2, 10)}`;
	const ts = Date.now();
	const user = CAST[Math.floor(Math.random() * CAST.length)];
	const roll = Math.random();
	if (roll < .58) return {
		viewers,
		event: {
			id,
			ts,
			kind: "chat",
			user,
			text: LINES[Math.floor(Math.random() * LINES.length)]
		}
	};
	if (roll < .74) {
		const gift = GIFTS[Math.floor(Math.random() * GIFTS.length)];
		const repeat = gift.diamonds === 1 && Math.random() > .5 ? 1 + Math.floor(Math.random() * 8) : 1;
		return {
			viewers,
			event: {
				id,
				ts,
				kind: "gift",
				user,
				gift: gift.gift,
				diamonds: gift.diamonds,
				repeat
			}
		};
	}
	if (roll < .84) return {
		viewers,
		event: {
			id,
			ts,
			kind: "follow",
			user
		}
	};
	if (roll < .9) return {
		viewers,
		event: {
			id,
			ts,
			kind: "share",
			user
		}
	};
	if (roll < .95) return {
		viewers,
		event: {
			id,
			ts,
			kind: "join",
			user
		}
	};
	return {
		viewers,
		event: {
			id,
			ts,
			kind: "like",
			user,
			count: 5 + Math.floor(Math.random() * 40)
		}
	};
}
function driftViewers(viewers) {
	const delta = [
		-4,
		-2,
		1,
		3,
		6,
		9
	][Math.floor(Math.random() * 6)];
	const count = Math.max(12, viewers + delta);
	return {
		id: `v-${Date.now().toString(36)}`,
		ts: Date.now(),
		kind: "viewers",
		count
	};
}
function sampleGift() {
	return {
		id: `t-${Math.random().toString(36).slice(2, 10)}`,
		ts: Date.now(),
		kind: "gift",
		user: kai,
		gift: "León",
		diamonds: 299,
		repeat: 1
	};
}
function sampleChat() {
	return {
		id: `t-${Math.random().toString(36).slice(2, 10)}`,
		ts: Date.now(),
		kind: "chat",
		user: luna,
		text: "esto es una prueba de comentario para el overlay"
	};
}
function normalizeUsername(input) {
	const trimmed = input.trim();
	const raw = (trimmed.match(/tiktok\.com\/@([^/?#\s]+)/i)?.[1] ?? trimmed).replace(/^@+/, "").replace(/\/live$/i, "");
	if (!/^[a-zA-Z0-9._]{2,24}$/.test(raw)) return null;
	return raw;
}
//#endregion
export { emptyStats as a, nextDemo as c, sampleGift as d, summarize as f, driftViewers as i, normalizeUsername as l, applyStats as n, formatCount as o, defaultSettings as r, isChatVisible as s, SEED as t, sampleChat as u };
