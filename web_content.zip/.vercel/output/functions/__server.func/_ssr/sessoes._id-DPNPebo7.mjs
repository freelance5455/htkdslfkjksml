import { w as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { D as useAppStore, a as SESSION_TYPE_LABEL, g as formatDuration, v as formatLongDate } from "./store-CuJQmbYj.mjs";
import { t as PageHeader } from "./page-header-ueGZTDza.mjs";
import { t as Card } from "./card-ML3_y2lP.mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { T as ArrowLeft } from "../_libs/lucide-react.mjs";
import { o as Button, r as Route$1 } from "./router-0AvkMag6.mjs";
import { t as Badge } from "./badge-Ct6gxEJd.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/sessoes._id-DPNPebo7.js
var import_jsx_runtime = require_jsx_runtime();
function SessionDetailPage() {
	const { id } = Route$1.useParams();
	const session = useAppStore((s) => s.sessions.find((x) => x.id === id));
	if (!session) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted-foreground",
		children: "Sessão não encontrada."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		asChild: true,
		variant: "outline",
		className: "mt-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/sessoes",
			children: "Voltar"
		})
	})] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "animate-in fade-in duration-300",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				variant: "ghost",
				size: "sm",
				className: "-ml-2 mb-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/sessoes",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, {}), " Sessões"]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: formatLongDate(session.date),
				title: SESSION_TYPE_LABEL[session.type],
				subtitle: session.title,
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					tone: "success",
					children: "Concluído"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] text-muted-foreground uppercase",
						children: "Duração"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-lg font-semibold tabular-nums",
						children: formatDuration(session.durationSec)
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] text-muted-foreground uppercase",
						children: "Séries"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-mono text-lg font-semibold tabular-nums",
						children: [
							session.exercises.reduce((a, e) => a + e.completedSets, 0),
							"/",
							session.exercises.reduce((a, e) => a + e.sets, 0)
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-3",
				children: session.exercises.map((ex) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-display font-semibold",
								children: ex.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs tabular-nums text-primary",
								children: [
									ex.completedSets,
									"/",
									ex.sets
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: [
								ex.sets,
								" × ",
								ex.reps,
								ex.load ? ` · carga ${ex.load}` : ""
							]
						}),
						ex.setLogs.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-2 space-y-1 text-xs text-muted-foreground",
							children: ex.setLogs.map((log, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
								"Série ",
								i + 1,
								": ",
								log.reps,
								log.load ? ` · ${log.load}` : ""
							] }, i))
						}) : null
					]
				}, ex.id))
			}),
			session.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "mt-4 p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] text-muted-foreground uppercase",
					children: "Observações"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm whitespace-pre-wrap",
					children: session.notes
				})]
			}) : null
		]
	});
}
//#endregion
export { SessionDetailPage as component };
