import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { A as Clock3, C as FileText, D as Delete, E as DoorClosed, O as Crown, S as Flower2, T as Droplets, _ as Map, b as Gem, c as Sun, d as Shirt, f as Shield, g as Moon, h as PenLine, i as Umbrella, j as BookOpen, k as Compass, l as Star, m as Scale, n as VolumeX, o as TreePine, p as ScrollText, r as Volume2, s as Telescope, t as X, u as Stamp, v as Lamp, w as Feather, x as Frame, y as KeyRound } from "../_libs/lucide-react.mjs";
import { a as DialogOverlay, i as DialogDescription, n as DialogClose, o as DialogPortal, r as DialogContent, s as DialogTitle, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Dx5IjlFZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var WINGS = [
	{
		id: "foyer",
		name: "The Foyer",
		range: [1, 10],
		motto: "Brass, candles, and first impressions"
	},
	{
		id: "library",
		name: "The Library",
		range: [11, 20],
		motto: "Ink, indexes, and quiet"
	},
	{
		id: "conservatory",
		name: "The Conservatory",
		range: [21, 30],
		motto: "Glass, water, and leaves"
	},
	{
		id: "observatory",
		name: "The Observatory",
		range: [31, 40],
		motto: "The dome and the dark"
	},
	{
		id: "vault",
		name: "The Vault",
		range: [41, 50],
		motto: "Iron, oaths, and the last door"
	}
];
function wingFor(n) {
	return WINGS.find((w) => n >= w.range[0] && n <= w.range[1]) ?? WINGS[0];
}
function h(id, label, x, y, icon, text, note) {
	return {
		id,
		label,
		x,
		y,
		icon,
		text,
		note
	};
}
function room(n, wing, name, line, hotspots, lock, hints, yieldLine) {
	return {
		n,
		wing,
		name,
		line,
		hotspots,
		lock,
		hints,
		yield: yieldLine
	};
}
var ROOMS = [
	room(1, "foyer", "The Welcome Hall", "The house expects you to look before you touch a lock.", [
		h("frames", "Three frames", 28, 42, "frame", "West to east the little frames are marked I, III, and V. A plate under them reads: the door wants those numerals, in that order, with no spaces.", "Frames, west to east: I, III, V."),
		h("mat", "Welcome mat", 42, 74, "scroll", "The mat says only WELCOME. Someone has penciled beneath it: not the word — the frames.", "The mat is a decoy. Use the frames."),
		h("candle", "Single candle", 62, 48, "lamp", "One candle, freshly lit. It throws light onto the frames and nowhere else that matters.", "One candle. The frames hold the code.")
	], {
		kind: "code",
		answer: "135",
		prompt: "A three-digit brass plate. Roman numerals count as ordinary digits."
	}, [
		"The three frames are Roman numerals. Read them from west to east.",
		"I is 1, III is 3, V is 5.",
		"Enter 135."
	], "The welcome lock gives way. The house has noticed you."),
	room(2, "foyer", "The Cloakroom", "Hooks, tags, and the smell of wet wool.", [
		h("hooks", "Coat hooks", 30, 40, "shirt", "Three hooks, west to east. A scarf tagged 4, a hat tagged 8, a single glove tagged 2. The cloak-check sign says they are filed in the order they hang.", "Tags west to east: 4, 8, 2."),
		h("sign", "Cloak sign", 58, 36, "scroll", "“Numbers, not names. West to east. The lock has no patience for the empty fourth hook.”", "Read the tags west to east. Ignore the empty hook."),
		h("stand", "Boot tray", 40, 72, "stamp", "Two boots and a puddle. Nothing numbered. The hooks are the filing system.", "Boots are not part of the code.")
	], {
		kind: "code",
		answer: "482",
		prompt: "The cloak check wants its filing number."
	}, [
		"Read the hanging tags from west to east.",
		"Scarf 4, hat 8, glove 2.",
		"Enter 482."
	], "The cloakroom latch slips. Your coat was never the point."),
	room(3, "foyer", "Candle Alcove", "Wax on the stone, and a mirror that will not flatter.", [h("mirror", "Looking glass", 34, 42, "frame", "The glass is old and slightly cruel. Across it, in a careful hand, the letters read THGIL. A thumb-smudge note underneath: the mirror writes backwards.", "Mirror shows THGIL. Read it forwards."), h("sconce", "Sconce pair", 60, 46, "lamp", "Two sconces, both out. Between them a scrap: “Not the wax. The thing the wax is spent to make.”", "The answer is what a candle is spent to make.")], {
		kind: "word",
		answer: "LIGHT",
		prompt: "Five letters. The mirror has them, in the wrong direction."
	}, [
		"Read the mirror’s letters from right to left, the way a reflection must be undone.",
		"THGIL reversed is a five-letter word.",
		"Enter LIGHT."
	], "The alcove brightens, though no new candle was lit."),
	room(4, "foyer", "The Stopped Clock", "A grandfather clock that refused the rest of the evening.", [h("clock", "Clock face", 36, 40, "clock", "The hands have stopped at 7:30. The second hand rests on twelve, as if ashamed of itself. There is no date window.", "The clock stopped at 7:30."), h("card", "Dinner card", 58, 58, "file", "“The lock drops the colon. It keeps the hour and the minutes as three digits, and it does not want a leading zero.”", "Hour then minutes, three digits, no colon.")], {
		kind: "code",
		answer: "730",
		prompt: "The stopped time, written the way the card insists."
	}, [
		"Use the stopped time, not the second hand.",
		"7:30 becomes three digits with the colon removed.",
		"Enter 730."
	], "Something in the case clicks, though the hands do not move."),
	room(5, "foyer", "Calling Cards", "A silver tray, and more names than the house still uses.", [h("tray", "Card tray", 40, 58, "file", "Most of the cards are blank on the back. One, face up, reads: “Five letters. The person who was invited — not the person who lives here.”", "Five letters: the invited one, not the resident."), h("bell", "Visitor bell", 24, 44, "gem", "A brass bell with a cracked clapper. Engraved under the rim: “Ring for the one who does not have a key.”", "The bell is for someone without a key.")], {
		kind: "word",
		answer: "GUEST",
		prompt: "Five letters on the tray’s little plate."
	}, [
		"The house wants the short word for a visitor.",
		"It begins with G. Not VISITOR — that is too long.",
		"Enter GUEST."
	], "The tray’s plate turns. You were expected, in the loose sense."),
	room(6, "foyer", "The Creaking Stair", "Twelve steps, and a house that complains about four of them.", [h("steps", "The flight", 34, 46, "compass", "You count the flight twice to be sure. Twelve steps, from the foyer tile to the landing.", "Twelve steps in the flight."), h("note", "Tacked note", 58, 40, "scroll", "“Four of them complain underfoot. The lock is not the noisy ones and not the quiet ones. It is their sum.”", "Add the twelve steps to the four that creak.")], {
		kind: "code",
		answer: "16",
		prompt: "A short sum. Two digits."
	}, [
		"The note wants a sum, not a difference.",
		"Twelve steps plus four creaking ones.",
		"Enter 16."
	], "The noisiest step goes quiet as the bolt slides."),
	room(7, "foyer", "Three Portraits", "The same sitter, three times, refusing to agree about the year.", [h("portraits", "The sitter", 40, 40, "frame", "Three canvases of one face. The plaques read Young, Prime, and Elder. A brass strip beneath all three: “Hang a life in the order it is lived.”", "Order a life as it is lived: young, then prime, then elder."), h("ribbon", "Hanging ribbon", 64, 56, "stamp", "The ribbon that should have numbered them has fallen. It says only: earliest self first.", "Earliest self first.")], {
		kind: "order",
		prompt: "Tap the ages in the order a life is lived.",
		steps: [
			{
				id: "elder",
				label: "Elder"
			},
			{
				id: "young",
				label: "Young"
			},
			{
				id: "prime",
				label: "Prime"
			}
		],
		answer: [
			"young",
			"prime",
			"elder"
		]
	}, [
		"Start with the youngest portrait.",
		"Young, then the middle years, then the oldest.",
		"Tap Young, Prime, Elder."
	], "The three faces settle into a single story. The door agrees."),
	room(8, "foyer", "Umbrella Stand", "A ceramic stand, and a doorman’s idea of arithmetic.", [h("stand", "The stand", 36, 62, "umbrella", "Five umbrellas, left to right as they lean: black, black, tartan, black, ivory. The tartan and the ivory are the only ones with any color in them.", "Five umbrellas. Two are not black: tartan and ivory."), h("slip", "Doorman’s slip", 60, 42, "file", "“Enter how many umbrellas there are, then how many are not black. One number, two digits, in that order.”", "First the total, then the count that are not black.")], {
		kind: "code",
		answer: "52",
		prompt: "Two digits, in the order the slip describes."
	}, [
		"Count all of them first.",
		"Five umbrellas, and two that are not black.",
		"Enter 52."
	], "The stand rings like a bell. Somewhere, a coat is relieved."),
	room(9, "foyer", "The Threshold Mat", "Letters kicked out of order by too many arrivals.", [h("tiles", "Letter tiles", 42, 70, "stamp", "Five loose tiles on the mat, in this order: T, E, N, R, E. A stitched border reads: the only word a threshold respects.", "Tiles: T E N R E. One word a door understands."), h("scuff", "Scuff mark", 24, 48, "pen", "Someone has written in the dust: “Same letters. Not a name. The verb of arriving.”", "Rearrange T, E, N, R, E into the verb of arriving.")], {
		kind: "word",
		answer: "ENTER",
		prompt: "Five letters, using each tile once."
	}, [
		"The tiles are an anagram of a common doorway word.",
		"It begins with E and ends with R.",
		"Enter ENTER."
	], "The mat lies flat. The next room is no longer a rumor."),
	room(10, "foyer", "Builder’s Receipt", "The foyer ends where the materials were listed.", [
		h("knocker", "Door knocker", 66, 44, "gem", "The knocker is solid brass, warm from other people’s hands. A scratch on the back says “first.”", "The knocker is brass, and it comes first."),
		h("invite", "Invitation", 28, 56, "scroll", "An invitation still sealed. The seal is red wax, and a clerk has written “second” along the flap.", "The invitation’s seal is wax. It comes second."),
		h("sample", "Timber sample", 46, 38, "tree", "A palm-sized block of oak, tagged “from the stair” and “third.”", "The stair sample is oak. It comes third.")
	], {
		kind: "dials",
		prompt: "Set knocker, invitation, and stair in the order the tags insist.",
		dials: [
			{
				id: "knocker",
				label: "Knocker",
				options: [
					"Oak",
					"Brass",
					"Wax"
				]
			},
			{
				id: "invite",
				label: "Invitation",
				options: [
					"Brass",
					"Oak",
					"Wax"
				]
			},
			{
				id: "stair",
				label: "Stair",
				options: [
					"Wax",
					"Brass",
					"Oak"
				]
			}
		],
		answer: [
			"Brass",
			"Wax",
			"Oak"
		]
	}, [
		"Each object is tagged with a material and a place in line.",
		"Brass first, wax second, oak third.",
		"Set the dials to Brass, Wax, Oak."
	], "The foyer’s last bolt rolls back. Ink waits on the other side."),
	room(11, "library", "Quiet Threshold", "A sign asks for the only thing a closed book can use.", [h("sign", "Please sign", 32, 40, "scroll", "The painted sign once said PLEASE ____ QUIETLY. A child has finished the blank in pencil, pressing hard: READ.", "The blank was filled in pencil: READ."), h("stool", "Reading stool", 56, 66, "book", "A low stool, a dent in the cushion the size of a patient person. No other word is written here.", "The stool is only a stool. The sign has the word.")], {
		kind: "word",
		answer: "READ",
		prompt: "Four letters. The pencil already confessed."
	}, [
		"Look at the word the child wrote in the blank.",
		"Four letters, a thing you do with a book.",
		"Enter READ."
	], "The library accepts the password it has been asking for all along."),
	room(12, "library", "The Open Drawer", "Three drawers, and only one of them slightly ashamed.", [h("drawers", "Card drawers", 36, 50, "file", "The drawers are labeled in a steady hand. Poetry 300. Drama 310. Novels 314. The novels drawer sits a finger’s width open. The others are flush.", "The open drawer is Novels, numbered 314."), h("slip", "Request slip", 62, 40, "pen", "“The book you came for is the only drawer that could not quite shut. The lock wants that drawer’s number.”", "Use the number of the drawer that is ajar.")], {
		kind: "code",
		answer: "314",
		prompt: "The number of the drawer that would not shut."
	}, [
		"Ignore the shut drawers.",
		"Novels is the open one, labeled 314.",
		"Enter 314."
	], "The drawer sighs shut, and the door does the opposite."),
	room(13, "library", "Black Ribbon", "One volume the house will not say aloud.", [h("book", "Ribboned book", 30, 46, "book", "A black ribbon marks a thick play. The title page is torn. Tucked inside is a library card: “Title begins with MAC and ends with BETH. One word. Do not read it aloud in the theatre.”", "The card: begins with MAC, ends with BETH."), h("plaque", "Theatre plaque", 58, 38, "frame", "“The Scottish play. The lock will take the name the actors will not.”", "The lock wants the play’s real name.")], {
		kind: "word",
		answer: "MACBETH",
		prompt: "One word. The card has both ends of it."
	}, [
		"Join the beginning on the card to the ending on the card.",
		"MAC + BETH, one word.",
		"Enter MACBETH."
	], "The ribbon slides free. Nobody in the room says the title."),
	room(14, "library", "The Fiction Shelf", "Dewey, in a house that otherwise prefers riddles.", [h("spines", "Three spines", 34, 44, "book", "Three numbers on three spines. 821. 822. 823. A penciled key on the shelf lip: poetry 821, drama 822, English fiction 823.", "821 poetry, 822 drama, 823 English fiction."), h("request", "Reader’s request", 60, 62, "file", "“English fiction, not poetry, not drama. The lock is that shelf number and nothing cleverer.”", "The request is for English fiction: 823.")], {
		kind: "code",
		answer: "823",
		prompt: "The shelf the request actually names."
	}, [
		"Match the request — English fiction — to the penciled key.",
		"Fiction is 823. Poetry and drama are the other two.",
		"Enter 823."
	], "A novel-sized gap appears where the bolt used to be."),
	room(15, "library", "Silent Tiles", "Six letters that have been sitting in the wrong word.", [h("tiles", "Desk tiles", 42, 60, "stamp", "Scrabble-thick tiles spell SILENT, left to right. Under the rack: “Same six letters. Not this word — the one this room requires of you before a book will speak.”", "Tiles spell SILENT. Same letters, the room’s real rule."), h("rule", "House rule", 24, 40, "scroll", "Framed above the desk, with the first word worn almost away: “______, then speak.” The blank is six letters and an anagram of the tiles.", "Anagram of SILENT. The verb before speak.")], {
		kind: "word",
		answer: "LISTEN",
		prompt: "Six letters. Every tile, once."
	}, [
		"Rearrange S, I, L, E, N, T into the verb that means to hear.",
		"It is not ENLIST and not TINSEL. It is what you do with your ears.",
		"Enter LISTEN."
	], "The tiles go quiet, which is their way of agreeing."),
	room(16, "library", "The Blue Row", "Five spines, and one of them refusing the palette.", [h("row", "The row", 40, 44, "book", "A tight row of blue cloth bindings. One volume is red and pulled out a thumb’s width. The endpaper note says: pull the volume that breaks the row of blue, and give the lock its title.", "The red book is the one that breaks the blue row.")], {
		kind: "pick",
		prompt: "Choose the volume the note is pointing at.",
		options: [
			{
				id: "azure",
				label: "Azure Atlas",
				detail: "Blue cloth. Flush with the row."
			},
			{
				id: "poems",
				label: "Bluebound Poems",
				detail: "Blue cloth. Flush with the row."
			},
			{
				id: "crimson",
				label: "The Crimson Index",
				detail: "Red cloth, pulled slightly out."
			},
			{
				id: "navy",
				label: "Navy Nights",
				detail: "Blue cloth. Flush with the row."
			},
			{
				id: "cobalt",
				label: "Cobalt Tales",
				detail: "Blue cloth. Flush with the row."
			}
		],
		answer: "crimson"
	}, [
		"The note wants the book that is not blue.",
		"Only one spine is red, and it sits proud of the row.",
		"Choose The Crimson Index."
	], "The red book slides home. The door takes the hint."),
	room(17, "library", "Torn Page", "The answer was circled, and then the page left.", [h("book", "Open book", 38, 58, "book", "The book is open to a ragged stub. In the margin of the page that remains: “Circled on page forty-two, and then torn out. The lock does not want the sentence. It wants the page.”", "The circled answer was on page 42. The lock wants the page."), h("stub", "Page stub", 62, 42, "feather", "The stub still shows the printed number 42 at its corner, half a fingernail wide.", "The stub is numbered 42.")], {
		kind: "code",
		answer: "42",
		prompt: "The page number, nothing else."
	}, [
		"Ignore the missing sentence.",
		"The page number is forty-two.",
		"Enter 42."
	], "A page-thin gap opens beside the jamb."),
	room(18, "library", "Dates of Death", "Three cards, three endings, one correct shelf order.", [h("cards", "Author cards", 36, 48, "file", "Three catalog cards, written plainly. Austen, died 1817. Dickens, died 1870. Woolf, died 1941. The shelf tape says: earliest death first.", "Austen 1817, Dickens 1870, Woolf 1941. Earliest death first.")], {
		kind: "order",
		prompt: "Tap the authors from the earliest death to the latest.",
		steps: [
			{
				id: "woolf",
				label: "Woolf, 1941"
			},
			{
				id: "austen",
				label: "Austen, 1817"
			},
			{
				id: "dickens",
				label: "Dickens, 1870"
			}
		],
		answer: [
			"austen",
			"dickens",
			"woolf"
		]
	}, [
		"Use the years on the cards, not fame and not alphabet.",
		"1817 comes before 1870, which comes before 1941.",
		"Tap Austen, Dickens, Woolf."
	], "The cards square themselves. The lock respects chronology."),
	room(19, "library", "Ink Recipe", "A true black, measured in drops.", [h("recipe", "Recipe card", 30, 46, "feather", "“A library black is soot, then vinegar, then oak gall.” The ingredients are named in that order and no other.", "Order of ingredients: soot, vinegar, oak gall."), h("drops", "Drop counts", 58, 58, "drop", "A second card, spotted: “Three drops, then one, then two — in the order the recipe names them.”", "Three, then one, then two, matching the recipe’s order.")], {
		kind: "dials",
		prompt: "Set the drops: soot, vinegar, gall.",
		dials: [
			{
				id: "soot",
				label: "Soot",
				options: [
					"0",
					"1",
					"2",
					"3",
					"4"
				]
			},
			{
				id: "vinegar",
				label: "Vinegar",
				options: [
					"0",
					"1",
					"2",
					"3",
					"4"
				]
			},
			{
				id: "gall",
				label: "Gall",
				options: [
					"0",
					"1",
					"2",
					"3",
					"4"
				]
			}
		],
		answer: [
			"3",
			"1",
			"2"
		]
	}, [
		"The recipe names soot, then vinegar, then gall.",
		"The drops are three, one, and two in that same order.",
		"Set the dials to 3, 1, 2."
	], "The ink darkens. So does the gap around the door, and then it opens."),
	room(20, "library", "The Catalog", "The word for the list that points at every other word.", [h("card", "Blank catalog", 40, 50, "file", "A blank catalog card titled, in small print, “the map of a book.” Beneath: “Five letters. Not the table of contents. The list at the back that sends you to a page.”", "Five letters. The list at the back of a book."), h("stamp", "Library stamp", 64, 38, "stamp", "The stamp’s only legible ring of text: “INDEX CASE — ASK HERE.”", "The stamp says INDEX.")], {
		kind: "word",
		answer: "INDEX",
		prompt: "Five letters. The map of a book."
	}, [
		"It is the list at the back, not the table of contents.",
		"The stamp already uses the word.",
		"Enter INDEX."
	], "Every card in the case seems to exhale. The library lets you go."),
	room(21, "conservatory", "Under Glass", "Warm air, wet stone, and a word split across two panes.", [h("left", "Left pane", 28, 36, "frame", "Scratched into the left pane, large and childish: GR", "Left pane: GR"), h("right", "Right pane", 52, 40, "flower", "The right pane finishes it: EEN. A smudge below adds: one word, the plain color of the room.", "Right pane: EEN. Together, a color.")], {
		kind: "word",
		answer: "GREEN",
		prompt: "Four letters, split across the two panes."
	}, [
		"Read the left pane, then the right.",
		"GR followed by EEN.",
		"Enter GREEN."
	], "Condensation draws a clean line around the door."),
	room(22, "conservatory", "Watering Tags", "Three plants, three opinions about thirst.", [h("tags", "Pot tags", 40, 60, "flower", "Fern: “Water me first. I sulk.” Orchid: “Second. A sip, not a bath.” Cactus: “Last. I remember deserts.”", "Fern first, orchid second, cactus last.")], {
		kind: "order",
		prompt: "Tap the plants in the order they ask to be watered.",
		steps: [
			{
				id: "cactus",
				label: "Cactus"
			},
			{
				id: "fern",
				label: "Fern"
			},
			{
				id: "orchid",
				label: "Orchid"
			}
		],
		answer: [
			"fern",
			"orchid",
			"cactus"
		]
	}, [
		"The fern insists on being first.",
		"Fern, then orchid, then cactus.",
		"Tap Fern, Orchid, Cactus."
	], "A drip somewhere agrees, and the latch agrees with the drip."),
	room(23, "conservatory", "Living and Silk", "The lock does not count what never grew.", [h("bed", "Flower bed", 36, 62, "flower", "You count them slowly. Three lilies. Four violets. A bowl of roses that shine the way only silk shines.", "Three lilies, four violets, and silk roses."), h("note", "Gardener’s note", 62, 42, "scroll", "“Silk is not a flower the lock will count. Add only what is alive.”", "Add the living flowers. Skip the silk roses.")], {
		kind: "code",
		answer: "7",
		prompt: "One digit. Living blooms only."
	}, [
		"Leave the silk roses out of the sum.",
		"Three lilies plus four violets.",
		"Enter 7."
	], "The silk roses do not move. The door does."),
	room(24, "conservatory", "Heights by the Door", "The gardener measures as she walks in.", [h("pots", "Three pots", 38, 64, "flower", "From the door inward the pots stand five inches, then three inches, then one inch. Their plants are identical. Only the heights differ.", "Heights from the door inward: 5, then 3, then 1."), h("tape", "Cloth tape", 64, 44, "scale", "“Record the heights in the order you pass them walking in. One number. No spaces.”", "Write 5, 3, and 1 as one number.")], {
		kind: "code",
		answer: "531",
		prompt: "Three digits, door inward."
	}, [
		"Start at the door and walk inward.",
		"Five inches, then three, then one.",
		"Enter 531."
	], "The smallest pot seems to nod. The bolt certainly does."),
	room(25, "conservatory", "The Wet Fern", "One plant is being loved too hard.", [h("bench", "Potting bench", 40, 58, "drop", "A note under a watering can: “Stop watering the one with yellowed lower leaves and wet soil. Name that plant to the lock.”", "Stop the plant with yellow lower leaves and wet soil.")], {
		kind: "pick",
		prompt: "Which plant should you stop watering?",
		options: [
			{
				id: "fern",
				label: "Fern",
				detail: "Lower leaves yellow. Soil wet to the touch."
			},
			{
				id: "orchid",
				label: "Orchid",
				detail: "Firm leaves. Soil barely damp."
			},
			{
				id: "ivy",
				label: "Ivy",
				detail: "Evenly green. Soil damp, not soggy."
			},
			{
				id: "cactus",
				label: "Cactus",
				detail: "Plump pads. Soil dry."
			}
		],
		answer: "fern"
	}, [
		"Match the note: yellowed lower leaves, and soil that is already wet.",
		"The orchid, ivy, and cactus do not match both symptoms.",
		"Choose the Fern."
	], "You leave the can where it is. The door, grateful, opens."),
	room(26, "conservatory", "Brass Genus", "The old gardeners would not use the common name.", [h("tag", "Rose tag", 34, 56, "flower", "A brass tag wired to a rose cane. It does not say rose. It is stamped, in capitals: ROSA.", "The tag is stamped ROSA."), h("book", "Garden book", 60, 40, "book", "“Give the lock the genus, the word on the brass, not the word you use in the kitchen.”", "The lock wants the stamped genus, not “rose.”")], {
		kind: "word",
		answer: "ROSA",
		prompt: "Four letters, as stamped."
	}, [
		"Read the brass tag, not the common name.",
		"Four letters, all capitals on the tag.",
		"Enter ROSA."
	], "The cane taps the glass once. The latch answers."),
	room(27, "conservatory", "The Year Panes", "Four panes, engraved with the only order a year knows.", [h("panes", "Season panes", 36, 40, "sun", "Four glass panes, each engraved with a season: Spring, Summer, Autumn, Winter. Etched along the sill: “Turn them as the year turns. Begin where the year begins.”", "Order the seasons as the year turns, starting with spring.")], {
		kind: "order",
		prompt: "Tap the seasons from the start of the year.",
		steps: [
			{
				id: "winter",
				label: "Winter"
			},
			{
				id: "summer",
				label: "Summer"
			},
			{
				id: "spring",
				label: "Spring"
			},
			{
				id: "autumn",
				label: "Autumn"
			}
		],
		answer: [
			"spring",
			"summer",
			"autumn",
			"winter"
		]
	}, [
		"The year in this house begins in spring, not winter.",
		"Spring, summer, autumn, winter.",
		"Tap Spring, Summer, Autumn, Winter."
	], "The panes fog in order, and the door clears."),
	room(28, "conservatory", "Orchid Mix", "Bark, moss, and a clay the orchid will not forgive.", [h("slate", "Mix slate", 32, 48, "pen", "“For orchids: two parts bark, one part moss, zero parts clay.” The words are in that order, which is also the order of the dials.", "Bark 2, moss 1, clay 0."), h("bin", "Clay bin", 62, 64, "drop", "The clay bin has a paper hat that says ONLY ZERO. Someone was tired of drowned orchids.", "Clay must be zero.")], {
		kind: "dials",
		prompt: "Set parts of bark, moss, and clay.",
		dials: [
			{
				id: "bark",
				label: "Bark",
				options: [
					"0",
					"1",
					"2",
					"3"
				]
			},
			{
				id: "moss",
				label: "Moss",
				options: [
					"0",
					"1",
					"2",
					"3"
				]
			},
			{
				id: "clay",
				label: "Clay",
				options: [
					"0",
					"1",
					"2",
					"3"
				]
			}
		],
		answer: [
			"2",
			"1",
			"0"
		]
	}, [
		"Read the slate in dial order: bark, moss, clay.",
		"Two, one, and zero.",
		"Set the dials to 2, 1, 0."
	], "The mix smells like a forest that has forgiven you. The door opens."),
	room(29, "conservatory", "South Pane", "Not clear glass. The color of old honey, and a ledger that refuses poetry.", [h("pane", "South pane", 30, 38, "sun", "The pane is honey-colored and warm. No word is written on the glass itself.", "The pane is honey-colored. The name is not on the glass."), h("ledger", "Glazier’s ledger", 58, 56, "file", "A line item, underlined twice: “South pane — AMBER. The lock takes the ledger’s word, not a guess at the color.”", "The ledger names the pane AMBER.")], {
		kind: "word",
		answer: "AMBER",
		prompt: "Five letters, copied from the ledger."
	}, [
		"Do not invent a synonym for the color.",
		"The ledger’s word is five letters and starts with A.",
		"Enter AMBER."
	], "The honey light shifts. The way out is no longer tinted shut."),
	room(30, "conservatory", "The Bed Slate", "The conservatory’s last sum is a list, not a riddle.", [h("beds", "The beds", 34, 64, "flower", "You count what the slate will ask about. Two lilies are open. One fern has unfurled. Four buds are still shut.", "Two open lilies, one unfurled fern, four shut buds."), h("slate", "Slate", 60, 42, "pen", "“Write the counts in the order the bed tag would say them: lilies, ferns, buds. One number.”", "Order: lilies, then ferns, then buds.")], {
		kind: "code",
		answer: "214",
		prompt: "Three counts, in slate order."
	}, [
		"Take the counts from the beds, in the slate’s order.",
		"Lilies 2, ferns 1, buds 4.",
		"Enter 214."
	], "Glass ticks as it cools. The wing of leaves is behind you."),
	room(31, "observatory", "Full Turn", "The dome, and the number of degrees in a circle it knows by heart.", [h("plaque", "Dome plaque", 36, 42, "compass", "“A full turn of the dome. Not a half, not a quarter. The lock wants that turn in degrees.”", "The lock wants a full turn of the dome, in degrees."), h("ring", "Brass ring", 60, 58, "scope", "The ring is engraved all the way around: 360 small ticks, and a zero that is also the end.", "The ring has 360 ticks.")], {
		kind: "code",
		answer: "360",
		prompt: "Degrees in one full turn."
	}, [
		"A full circle, not a half.",
		"The ring is marked with that many ticks.",
		"Enter 360."
	], "The dome shifts one polite degree and the door does the rest."),
	room(32, "observatory", "The White Disc", "A phase drawn so simply a child could name it.", [h("disc", "Phase card", 40, 44, "moon", "The card shows one complete white disc, no shadow on it. Caption: “Name this phase. Four letters. Not the new moon — the opposite.”", "A complete bright disc. Four letters. The opposite of new.")], {
		kind: "word",
		answer: "FULL",
		prompt: "Four letters. The phase on the card."
	}, [
		"The disc is complete and bright.",
		"The opposite of a new moon, in four letters.",
		"Enter FULL."
	], "Moonlight, or a good imitation, finds the crack in the door."),
	room(33, "observatory", "Blinking Signal", "Four named stars, and a log for anyone who blinked.", [h("log", "Signal log", 32, 56, "star", "The night log is blunt: “If you blinked: Vega, Altair, Polaris, Vega. In that order, and Vega bookends the rest.”", "Signal order: Vega, Altair, Polaris, Vega."), h("lamp", "Signal lamp", 62, 40, "lamp", "A shuttered lamp aimed at the dome. A tag: “You may watch it again. The log will not change its mind.”", "The lamp repeats the log. Vega, Altair, Polaris, Vega.")], {
		kind: "signal",
		prompt: "Watch the signal, or trust the log, then repeat it.",
		pads: [
			{
				id: "altair",
				label: "Altair"
			},
			{
				id: "vega",
				label: "Vega"
			},
			{
				id: "deneb",
				label: "Deneb"
			},
			{
				id: "polaris",
				label: "Polaris"
			}
		],
		answer: [
			"vega",
			"altair",
			"polaris",
			"vega"
		]
	}, [
		"The log lists four names, and the last repeats the first.",
		"Vega, then Altair, then Polaris, then Vega again. Deneb is silent.",
		"Tap Vega, Altair, Polaris, Vega."
	], "The lamp shutters once, satisfied, and the door answers in kind."),
	room(34, "observatory", "Dome Mark", "Hours and degrees, with the letters left on the floor.", [h("plaque", "Coordinate plaque", 34, 42, "compass", "“Dome mark. Right ascension 5h. Declination +12°.” Nothing else is numbered.", "5 hours, and 12 degrees."), h("note", "Observer’s note", 60, 60, "pen", "“The lock wants hours then degrees, as digits only. Drop the letters and the sign. One number.”", "Hours then degrees, digits only: 5 then 12.")], {
		kind: "code",
		answer: "512",
		prompt: "Hours, then degrees, digits only."
	}, [
		"Take the 5 from the hours and the 12 from the degrees.",
		"Drop the h, the plus, and the degree mark.",
		"Enter 512."
	], "A gear the size of a plate turns over. The way on is open."),
	room(35, "observatory", "Leaving the Sun", "Three lights you could actually see, in the order a traveler would meet them.", [h("chart", "Tonight’s chart", 38, 46, "sun", "“Visible tonight, and named as a traveler leaving the Sun would meet them: Venus, then Mars, then Jupiter. Mercury is not on the list. Neither is the Sun.”", "From the Sun outward: Venus, Mars, Jupiter.")], {
		kind: "order",
		prompt: "Tap the three in the order a traveler leaving the Sun would meet them.",
		steps: [
			{
				id: "jupiter",
				label: "Jupiter"
			},
			{
				id: "venus",
				label: "Venus"
			},
			{
				id: "mars",
				label: "Mars"
			}
		],
		answer: [
			"venus",
			"mars",
			"jupiter"
		]
	}, [
		"Start nearest the Sun and move outward.",
		"Venus, then Mars, then Jupiter.",
		"Tap Venus, Mars, Jupiter."
	], "The chart pins flutter. The door unpins itself."),
	room(36, "observatory", "The Hunter", "Three stars in a row, and a name worn thin.", [h("chart", "Belt chart", 40, 44, "star", "Three stars in a short straight belt. The caption has worn down to ORI_N. Five letters. Underneath, in fresher pencil: “the hunter.”", "Five letters. ORI, then a missing letter, then N. The hunter.")], {
		kind: "word",
		answer: "ORION",
		prompt: "Five letters. The worn caption, completed."
	}, [
		"The caption is the constellation of the hunter.",
		"ORI, then O, then N.",
		"Enter ORION."
	], "The belt brightens by the width of a thought. The bolt fades."),
	room(37, "observatory", "Eight Minutes", "How long the light has been traveling to reach this roof.", [h("plaque", "Sun plaque", 36, 46, "sun", "“Sunlight takes about eight minutes to reach this roof. The lock wants that count of minutes, and it wants nothing about the distance.”", "Eight minutes. The lock wants the count."), h("clock", "Minute glass", 62, 60, "clock", "A tiny glass, labeled MINUTES, with the numeral 8 etched in the stand. It is not running.", "The stand is etched with 8.")], {
		kind: "code",
		answer: "8",
		prompt: "The minutes, as a single digit."
	}, [
		"The plaque and the glass agree.",
		"The number of minutes is eight.",
		"Enter 8."
	], "Eight quiet minutes seem to pass at once. The door is simply open."),
	room(38, "observatory", "Meteor Note", "Season, hour, and the direction a patient person faces.", [h("note", "Meteor note", 34, 48, "star", "“The shower favors winter, late evening, looking north. Set the dome for that and stop improvising.”", "Winter, late evening, facing north."), h("margin", "Margin figure", 60, 36, "clock", "In the margin, the only hour circled is 22. The other hours are crossed out.", "The circled hour is 22.")], {
		kind: "dials",
		prompt: "Set season, hour, and facing.",
		dials: [
			{
				id: "season",
				label: "Season",
				options: [
					"Spring",
					"Summer",
					"Autumn",
					"Winter"
				]
			},
			{
				id: "hour",
				label: "Hour",
				options: [
					"20",
					"21",
					"22",
					"23"
				]
			},
			{
				id: "facing",
				label: "Facing",
				options: [
					"East",
					"South",
					"West",
					"North"
				]
			}
		],
		answer: [
			"Winter",
			"22",
			"North"
		]
	}, [
		"The note names the season and the direction. The margin names the hour.",
		"Winter, hour 22, facing north.",
		"Set Winter, 22, North."
	], "A streak of light that is only a reflection crosses the dome. The door is done waiting."),
	room(39, "observatory", "Stolen Sun", "The day the moon took a bite it did not give back until evening.", [h("log", "Observer’s log", 32, 56, "moon", "“The log cries out for the day the moon stole the sun. Not a moon alone, and not a sun left in peace.”", "Choose the day the moon stole the sun.")], {
		kind: "pick",
		prompt: "Which sketch is the day the log describes?",
		options: [
			{
				id: "sun",
				label: "Clear sun",
				detail: "A whole sun. Nothing crosses it."
			},
			{
				id: "crescent",
				label: "Crescent",
				detail: "A sliver of moon in an empty sky."
			},
			{
				id: "eclipse",
				label: "Covered sun",
				detail: "A dark disc bites into the sun."
			},
			{
				id: "full",
				label: "Whole moon",
				detail: "The moon is complete. The sun is not in the sketch."
			}
		],
		answer: "eclipse"
	}, [
		"The moon is stealing the sun, so both are involved.",
		"A dark disc over the sun, not a moon by itself.",
		"Choose Covered sun."
	], "The room dims and then thinks better of it. The door stands open."),
	room(40, "observatory", "Overhead", "The last word the dome asks is the point directly above you.", [h("mark", "Crown mark", 42, 28, "star", "At the crown of the dome, a small brass arrow points straight up at itself. The plate reads: “The point of the sky directly overhead. Six letters. It begins with Z.”", "Six letters, begins with Z. The point directly overhead.")], {
		kind: "word",
		answer: "ZENITH",
		prompt: "Six letters. Straight overhead."
	}, [
		"It is the overhead point of the sky, and it starts with Z.",
		"Not NADIR — that is under your feet.",
		"Enter ZENITH."
	], "The arrow loosens. Below it, the last stair of this wing is yours."),
	room(41, "vault", "The Deed", "The year the house changed hands, cut into iron.", [h("deed", "Deed snippet", 36, 50, "file", "A deed under glass. One line is not faded: “Transferred, 1947.” The rest is legalese about drains.", "The transfer year is 1947."), h("iron", "Iron lintel", 62, 36, "shield", "Cut into the lintel: “The vault was sealed in the year the house changed hands.”", "The seal year is the year on the deed.")], {
		kind: "code",
		answer: "1947",
		prompt: "Four digits. The year of the transfer."
	}, [
		"The lintel points you at the deed.",
		"The deed says 1947.",
		"Enter 1947."
	], "Iron, which does not like to hurry, hurries anyway."),
	room(42, "vault", "Three Keys", "Yellow, grey, and clear, in the order the ledger signed them.", [h("ledger", "Maker’s ledger", 34, 48, "key", "“Use them as the maker signed the ledger: the yellow brass, the grey iron, then the clear glass.”", "Order: brass, then iron, then glass.")], {
		kind: "order",
		prompt: "Tap the keys in the order the maker signed them.",
		steps: [
			{
				id: "glass",
				label: "Glass"
			},
			{
				id: "brass",
				label: "Brass"
			},
			{
				id: "iron",
				label: "Iron"
			}
		],
		answer: [
			"brass",
			"iron",
			"glass"
		]
	}, [
		"Follow the ledger, not the order the keys are hanging.",
		"Brass, then iron, then glass.",
		"Tap Brass, Iron, Glass."
	], "Three teeth catch three tumblers. The door is persuaded."),
	room(43, "vault", "The Balance", "A scale, a weight, and a lock that likes multiples.", [h("scale", "The scale", 38, 58, "scale", "A brass weight marked 8 sits in one pan. The other pan is empty and a little smug. The beam is level anyway, which the house does not explain.", "The weight is marked 8."), h("note", "Clerk’s note", 62, 42, "scroll", "“The lock is twice the weight that balances the chest.”", "Twice the marked weight.")], {
		kind: "code",
		answer: "16",
		prompt: "Twice the weight. Two digits."
	}, [
		"Read the number on the weight, then double it.",
		"Eight doubled.",
		"Enter 16."
	], "The empty pan dips, theatrical. The door is less theatrical, and open."),
	room(44, "vault", "Wax Stamps", "Three stamps, still speaking Latin numerals.", [h("stamps", "Three stamps", 40, 52, "stamp", "Three wax stamps in a row, left to right: IV, VIII, and II. The wax is the same crimson as the foyer’s invitations.", "Left to right: IV, VIII, II."), h("margin", "Margin note", 24, 38, "pen", "“Translate each stamp into an ordinary numeral and set the wheels left to right.”", "Turn the Roman stamps into ordinary numbers, left to right.")], {
		kind: "dials",
		prompt: "Set the three wheels from the stamps.",
		dials: [
			{
				id: "left",
				label: "Left",
				options: [
					"2",
					"4",
					"6",
					"8"
				]
			},
			{
				id: "middle",
				label: "Middle",
				options: [
					"6",
					"8",
					"2",
					"4"
				]
			},
			{
				id: "right",
				label: "Right",
				options: [
					"8",
					"2",
					"4",
					"6"
				]
			}
		],
		answer: [
			"4",
			"8",
			"2"
		]
	}, [
		"IV is 4, VIII is 8, II is 2.",
		"Left to right, that is 4, then 8, then 2.",
		"Set the wheels to 4, 8, 2."
	], "The stamps cool. The wheels stay where you put them, and the door moves."),
	room(45, "vault", "The Oath", "The only rule posted where a voice would be rude.", [h("sign", "Posted oath", 40, 40, "shield", "The vowels have been lifted off the sign, leaving S_L_NC_. A footnote says: seven letters, put the vowels back in order — I, then E, then E.", "Skeleton S_L_NC_. Vowels in order: I, E, E.")], {
		kind: "word",
		answer: "SILENCE",
		prompt: "Seven letters. Restore the vowels in the order the footnote gives."
	}, [
		"The consonants left on the sign are S, L, N, C, with a gap after S, after L, and at the end.",
		"Put back I, then E, then E.",
		"Enter SILENCE."
	], "You do not say the word aloud. The lock hears it anyway."),
	room(46, "vault", "First Primes", "A chalkboard, and a card for anyone who was told that 1 counts.", [h("board", "Chalkboard", 32, 44, "pen", "“A prime can only be divided by 1 and itself. The lock wants the first three primes, concatenated into one number. 1 is not a prime.”", "First three primes, as one number. 1 does not count."), h("card", "Primer card", 60, 60, "file", "The card is a patient list. “2 is prime. 4 is not. 3 is prime. 9 is not. 5 is prime.” It stops there.", "The primes on the card, in order: 2, 3, 5.")], {
		kind: "code",
		answer: "235",
		prompt: "The first three primes, written as one number."
	}, [
		"Use the primer card if the chalkboard feels stern. Skip the composites.",
		"The primes it names, in the order written, are 2, 3, and 5.",
		"Enter 235."
	], "Chalk dust settles in the shape of an open door. Convenient."),
	room(47, "vault", "Four Doors", "One of them has been a painting this whole time.", [h("note", "Builder’s note", 30, 46, "door", "“The real way is the one that is not a door. Hinges are a confession. A gap at the floor is a confession. Paint is a costume.”", "Choose the one that is not really a door.")], {
		kind: "pick",
		prompt: "Which one is not a door?",
		options: [
			{
				id: "oak",
				label: "Oak",
				detail: "Real hinges. A dark gap at the floor."
			},
			{
				id: "iron",
				label: "Iron",
				detail: "Cold, heavy, and it has a lock of its own."
			},
			{
				id: "mural",
				label: "Painted arch",
				detail: "A mural. No hinge, and no gap at the floor."
			},
			{
				id: "glass",
				label: "Glass",
				detail: "You can see the stone room beyond the frame."
			}
		],
		answer: "mural"
	}, [
		"Look for the one with no hinge and no gap.",
		"The painted arch is only paint.",
		"Choose Painted arch."
	], "The painting was a painting. The real door, elsewhere, unlocks."),
	room(48, "vault", "The Mason’s L", "The house number, cut the old way.", [h("stone", "Cut stone", 42, 48, "crown", "A single enormous letter is cut into the stone: L. Nothing else. No word, no date.", "The stone is cut with L."), h("note", "Mason’s note", 24, 66, "scroll", "“The house number, as I cut it. The lock wants it in ordinary numerals. L, and only L.”", "L is the house number. The lock wants ordinary numerals.")], {
		kind: "code",
		answer: "50",
		prompt: "What the mason’s L is worth."
	}, [
		"L is a Roman numeral.",
		"L means fifty.",
		"Enter 50."
	], "Fifty, said plainly at last. Two doors remain, counting this one as already tired."),
	room(49, "vault", "The Small Dark", "Not the key. Not the lock. The place they meet.", [h("plate", "Riddle plate", 38, 46, "key", "“I am not the key and not the lock. I am the small dark the key must find. Seven letters. I begin with KEY.”", "Seven letters, begins with KEY. The small dark a key finds.")], {
		kind: "word",
		answer: "KEYHOLE",
		prompt: "Seven letters. It begins with KEY."
	}, [
		"It is the opening the key is made for, seven letters.",
		"KEY plus a four-letter word for an opening.",
		"Enter KEYHOLE."
	], "You fit, metaphorically. The bolt does too, in reverse."),
	room(50, "vault", "The Builder’s Ledger", "Seven lines. The first letter of each is the last word the house wants.", [h("ledger", "Seven lines", 40, 48, "scroll", "The builder left seven lines and asked for their first letters, in order. For the guest who learned the frames. Remember the page, not the pride. Every leaf turns toward the glass. East of the moon the dome still turns. Do not speak inside the iron room. Open nothing by forcing it. Mercy, in the end, for the locksmith.", "First letters, in order: F, R, E, E, D, O, M."), h("seal", "Last seal", 64, 64, "stamp", "A wax seal with no emblem. Scratched beside it: “Seven letters. The thing the locks were for.”", "Seven letters from the line initials. The thing the locks were for.")], {
		kind: "word",
		answer: "FREEDOM",
		prompt: "Seven letters. The first letter of each line, in order."
	}, [
		"Take only the first letter of each of the seven lines.",
		"F, R, E, E, D, O, M.",
		"Enter FREEDOM."
	], "The fiftieth lock opens. The house, for once, does not ask for anything back.")
];
function assertRooms(list) {
	const problems = [];
	if (list.length !== 50) problems.push(`expected 50 rooms, got ${list.length}`);
	list.forEach((r, i) => {
		if (r.n !== i + 1) problems.push(`index ${i} is room ${r.n}`);
		if (r.hints.length !== 3 || r.hints.some((h) => !h.trim())) problems.push(`room ${r.n} hints`);
		if (r.hotspots.length < 1) problems.push(`room ${r.n} hotspots`);
		const ids = /* @__PURE__ */ new Set();
		for (const spot of r.hotspots) {
			if (ids.has(spot.id)) problems.push(`room ${r.n} dup spot ${spot.id}`);
			ids.add(spot.id);
			if (spot.x < 8 || spot.x > 78 || spot.y < 24 || spot.y > 80) problems.push(`room ${r.n} spot ${spot.id} out of range`);
		}
		const lock = r.lock;
		if (lock.kind === "code" && !/^\d+$/.test(lock.answer)) problems.push(`room ${r.n} code`);
		if (lock.kind === "word" && !/^[A-Z]+$/.test(lock.answer)) problems.push(`room ${r.n} word`);
		if (lock.kind === "order") {
			const stepIds = new Set(lock.steps.map((s) => s.id));
			if (lock.answer.length < 2 || lock.answer.some((id) => !stepIds.has(id))) problems.push(`room ${r.n} order`);
		}
		if (lock.kind === "dials") {
			if (lock.dials.length !== lock.answer.length) problems.push(`room ${r.n} dial length`);
			lock.dials.forEach((d, di) => {
				if (!d.options.includes(lock.answer[di] ?? "")) problems.push(`room ${r.n} dial ${di}`);
			});
			if (lock.dials.map((d) => d.options[0]).every((v, di) => v === lock.answer[di])) problems.push(`room ${r.n} dials start open`);
		}
		if (lock.kind === "pick" && !lock.options.some((o) => o.id === lock.answer)) problems.push(`room ${r.n} pick`);
		if (lock.kind === "signal") {
			const pads = new Set(lock.pads.map((p) => p.id));
			if (lock.answer.length < 2 || lock.answer.some((id) => !pads.has(id))) problems.push(`room ${r.n} signal`);
		}
	});
	if (problems.length) throw new Error(`Fifty Locks room data: ${problems.join("; ")}`);
}
assertRooms(ROOMS);
function roomByNumber(n) {
	return ROOMS[n - 1] ?? ROOMS[0];
}
function emptyAttempt(lock) {
	return {
		code: "",
		word: "",
		order: [],
		dials: lock.kind === "dials" ? lock.dials.map(() => 0) : [],
		pick: null,
		signal: []
	};
}
function isCorrect(lock, attempt) {
	switch (lock.kind) {
		case "code": return attempt.code === lock.answer;
		case "word": return attempt.word.toUpperCase().replace(/[^A-Z]/g, "") === lock.answer;
		case "order": return attempt.order.length === lock.answer.length && attempt.order.every((id, i) => id === lock.answer[i]);
		case "dials": return lock.dials.every((dial, i) => dial.options[attempt.dials[i] ?? -1] === lock.answer[i]);
		case "pick": return attempt.pick === lock.answer;
		case "signal": return attempt.signal.length === lock.answer.length && attempt.signal.every((id, i) => id === lock.answer[i]);
		default: return false;
	}
}
var KEY = "fifty-locks-save-v1";
function freshSave() {
	return {
		version: 1,
		frontier: 1,
		viewing: 1,
		elapsedMs: 0,
		hints: {},
		seen: [],
		mute: false,
		started: false
	};
}
function clamp(n, min, max, fallback) {
	return Math.min(max, Math.max(min, typeof n === "number" && Number.isFinite(n) ? Math.trunc(n) : fallback));
}
function loadSave() {
	try {
		const raw = localStorage.getItem(KEY);
		if (!raw) return freshSave();
		const parsed = JSON.parse(raw);
		if (parsed.version !== 1) return freshSave();
		const base = freshSave();
		const hints = {};
		if (parsed.hints && typeof parsed.hints === "object") {
			for (const [k, v] of Object.entries(parsed.hints)) if (/^\d+$/.test(k) && typeof v === "number" && v > 0) hints[k] = Math.min(3, Math.trunc(v));
		}
		const seen = Array.isArray(parsed.seen) ? parsed.seen.filter((s) => typeof s === "string").slice(0, 400) : [];
		return {
			...base,
			frontier: clamp(parsed.frontier, 1, 51, 1),
			viewing: clamp(parsed.viewing, 1, 50, 1),
			elapsedMs: Math.max(0, Number(parsed.elapsedMs) || 0),
			hints,
			seen,
			mute: Boolean(parsed.mute),
			started: Boolean(parsed.started)
		};
	} catch {
		return freshSave();
	}
}
function writeSave(save) {
	try {
		const next = {
			...save,
			version: 1,
			viewing: Math.min(save.viewing, Math.min(save.frontier, 50))
		};
		localStorage.setItem(KEY, JSON.stringify(next));
	} catch {}
}
function formatDuration(ms) {
	const total = Math.max(0, Math.floor(ms / 1e3));
	const h = Math.floor(total / 3600);
	const m = Math.floor(total % 3600 / 60);
	const s = total % 60;
	const pad = (n) => String(n).padStart(2, "0");
	if (h > 0) return `${h}:${pad(m)}:${pad(s)}`;
	return `${m}:${pad(s)}`;
}
var ctx = null;
var master = null;
var muted = false;
function context() {
	if (ctx) return ctx;
	const AC = window.AudioContext || window.webkitAudioContext;
	if (!AC) return null;
	ctx = new AC();
	master = ctx.createGain();
	master.gain.value = muted ? 0 : .18;
	master.connect(ctx.destination);
	return ctx;
}
function unlockAudio() {
	const audio = context();
	if (audio && audio.state === "suspended") audio.resume();
}
function resumeAudio() {
	if (ctx && ctx.state === "suspended") ctx.resume();
}
function setAudioMuted(next) {
	muted = next;
	if (!ctx || !master) return;
	master.gain.setTargetAtTime(next ? 0 : .18, ctx.currentTime, .02);
}
function tone(freq, when, dur, type, gain) {
	if (!ctx || !master) return;
	const osc = ctx.createOscillator();
	const amp = ctx.createGain();
	osc.type = type;
	osc.frequency.setValueAtTime(freq, when);
	amp.gain.setValueAtTime(1e-4, when);
	amp.gain.exponentialRampToValueAtTime(gain, when + .015);
	amp.gain.exponentialRampToValueAtTime(1e-4, when + dur);
	osc.connect(amp);
	amp.connect(master);
	osc.start(when);
	osc.stop(when + dur + .02);
	osc.onended = () => {
		osc.disconnect();
		amp.disconnect();
	};
}
function playSfx(kind) {
	const audio = context();
	if (!audio || !master || muted || audio.state !== "running") return;
	const t = audio.currentTime + .01;
	if (kind === "tick") tone(740, t, .05, "sine", .2);
	if (kind === "note") tone(520, t, .09, "triangle", .18);
	if (kind === "hint") {
		tone(494, t, .1, "sine", .16);
		tone(740, t + .09, .12, "sine", .14);
	}
	if (kind === "fail") tone(140, t, .16, "square", .08);
	if (kind === "open") {
		tone(392, t, .12, "triangle", .18);
		tone(494, t + .1, .12, "triangle", .18);
		tone(587, t + .2, .18, "triangle", .16);
		tone(784, t + .32, .28, "sine", .14);
	}
}
var ICONS = {
	frame: Frame,
	scroll: ScrollText,
	shirt: Shirt,
	umbrella: Umbrella,
	clock: Clock3,
	lamp: Lamp,
	book: BookOpen,
	feather: Feather,
	flower: Flower2,
	drop: Droplets,
	sun: Sun,
	moon: Moon,
	star: Star,
	scope: Telescope,
	key: KeyRound,
	scale: Scale,
	shield: Shield,
	file: FileText,
	crown: Crown,
	gem: Gem,
	tree: TreePine,
	compass: Compass,
	stamp: Stamp,
	pen: PenLine,
	door: DoorClosed
};
function EscapeGame() {
	const [phase, setPhase] = (0, import_react.useState)("title");
	const [save, setSave] = (0, import_react.useState)(() => freshSave());
	const [ready, setReady] = (0, import_react.useState)(false);
	const [mapOpen, setMapOpen] = (0, import_react.useState)(false);
	const [menuOpen, setMenuOpen] = (0, import_react.useState)(false);
	const [confirmReset, setConfirmReset] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const loaded = loadSave();
		setSave(loaded);
		setAudioMuted(loaded.mute);
		setReady(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		writeSave(save);
		setAudioMuted(save.mute);
	}, [save, ready]);
	(0, import_react.useEffect)(() => {
		if (phase !== "play" || save.frontier > 50) return;
		const id = window.setInterval(() => {
			if (document.visibilityState !== "visible") return;
			setSave((s) => ({
				...s,
				elapsedMs: s.elapsedMs + 1e3
			}));
		}, 1e3);
		return () => window.clearInterval(id);
	}, [phase, save.frontier]);
	(0, import_react.useEffect)(() => {
		const onVis = () => {
			if (document.visibilityState === "visible") resumeAudio();
		};
		document.addEventListener("visibilitychange", onVis);
		return () => document.removeEventListener("visibilitychange", onVis);
	}, []);
	function toggleMute() {
		unlockAudio();
		setSave((s) => ({
			...s,
			mute: !s.mute
		}));
	}
	function begin(mode) {
		unlockAudio();
		if (mode === "new") {
			setSave((s) => ({
				...freshSave(),
				mute: s.mute,
				started: true
			}));
			setPhase("play");
			return;
		}
		if (save.frontier > 50) {
			setPhase("victory");
			return;
		}
		setSave((s) => ({
			...s,
			started: true,
			viewing: Math.min(s.frontier, 50)
		}));
		setPhase("play");
	}
	function resetRun() {
		unlockAudio();
		setSave((s) => ({
			...freshSave(),
			mute: s.mute,
			started: true
		}));
		setConfirmReset(false);
		setMenuOpen(false);
		setMapOpen(false);
		setPhase("play");
	}
	if (phase === "title") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TitleScreen, {
		save,
		onContinue: () => begin("continue"),
		onNew: () => begin("new"),
		onMute: toggleMute
	});
	if (phase === "victory") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Victory, {
		save,
		onAgain: resetRun,
		onMute: toggleMute
	});
	const room = roomByNumber(save.viewing);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
		room,
		save,
		setSave,
		mapOpen,
		setMapOpen,
		menuOpen,
		setMenuOpen,
		confirmReset,
		setConfirmReset,
		onMute: toggleMute,
		onTitle: () => {
			setMenuOpen(false);
			setPhase("title");
		},
		onReset: resetRun,
		onVictory: () => setPhase("victory")
	});
}
function TitleScreen({ save, onContinue, onNew, onMute }) {
	const hasRun = save.started && (save.frontier > 1 || save.elapsedMs > 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "grid min-h-dvh bg-walnut text-cream md:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "relative min-h-80 md:min-h-dvh",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoomScene, {
					wing: "foyer",
					open: false,
					hotspots: [],
					selected: null,
					seen: [],
					onSelect: () => {}
				})
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "flex items-center px-6 py-10 md:px-12",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto w-full max-w-md",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-widest text-brass uppercase",
						children: "A house puzzle"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-3 font-display text-5xl text-cream",
						children: "Fifty Locks"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-sm text-mist",
						children: "Fifty rooms, one after another. Examine what was left behind, open the lock, and step through."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-6 space-y-2 text-sm text-cream",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Tap the room. Read what you find." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Open the lock, then the next door." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Ask the house if you stall. The third hint names the answer." })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex flex-col gap-3",
						children: [hasRun ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-brass",
							onClick: onContinue,
							children: save.frontier > 50 ? "Return to the last door" : `Continue · room ${Math.min(save.frontier, 50)}`
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-ghost",
							onClick: onNew,
							children: "Start over"
						})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-brass",
							onClick: onNew,
							children: "Begin at the first door"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "btn btn-ghost self-start",
							onClick: onMute,
							"aria-label": save.mute ? "Unmute" : "Mute",
							children: [save.mute ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { "aria-hidden": true }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { "aria-hidden": true }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: save.mute ? "Sound off" : "Sound on" })]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-8 text-sm text-mist",
						children: "Progress stays on this device."
					})
				]
			})
		})]
	});
}
function Victory({ save, onAgain, onMute }) {
	const hints = Object.values(save.hints).reduce((sum, n) => sum + n, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-dvh place-items-center bg-walnut px-6 py-12 text-cream",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-widest text-brass uppercase",
					children: "Outside"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 font-display text-5xl",
					children: "The house lets you go"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-mist",
					children: "The street air is ordinary, which is the point. Fifty locks, and none of them yours anymore."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "mt-8 grid grid-cols-2 gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Time",
						value: formatDuration(save.elapsedMs)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Hints asked",
						value: String(hints)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 flex flex-col gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-brass",
						onClick: onAgain,
						children: "Walk the house again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "btn btn-ghost self-start",
						onClick: onMute,
						children: [save.mute ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { "aria-hidden": true }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { "aria-hidden": true }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: save.mute ? "Sound off" : "Sound on" })]
					})]
				})
			]
		})
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-line bg-surface px-4 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-xs tracking-widest text-mist uppercase",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "mt-1 font-display text-3xl text-cream tabular-nums",
			children: value
		})]
	});
}
function Play({ room, save, setSave, mapOpen, setMapOpen, menuOpen, setMenuOpen, confirmReset, setConfirmReset, onMute, onTitle, onReset, onVictory }) {
	const lock = room.lock;
	const [attempt, setAttempt] = (0, import_react.useState)(() => emptyAttempt(lock));
	const [selected, setSelected] = (0, import_react.useState)(null);
	const [justSolved, setJustSolved] = (0, import_react.useState)(false);
	const [notice, setNotice] = (0, import_react.useState)(null);
	const [misses, setMisses] = (0, import_react.useState)(0);
	const [shake, setShake] = (0, import_react.useState)(0);
	const [signalLit, setSignalLit] = (0, import_react.useState)(null);
	const [signalBusy, setSignalBusy] = (0, import_react.useState)(false);
	const orderRef = (0, import_react.useRef)([]);
	const signalRef = (0, import_react.useRef)([]);
	const watchRef = (0, import_react.useRef)(0);
	(0, import_react.useEffect)(() => {
		setAttempt(emptyAttempt(room.lock));
		orderRef.current = [];
		signalRef.current = [];
		watchRef.current += 1;
		setSelected(null);
		setJustSolved(false);
		setNotice(null);
		setMisses(0);
		setSignalLit(null);
		setSignalBusy(false);
	}, [room.n, room.lock]);
	const open = room.n < save.frontier || justSolved;
	const wing = wingFor(room.n);
	const revealed = save.hints[String(room.n)] ?? 0;
	const spot = room.hotspots.find((item) => item.id === selected) ?? null;
	const seenHere = room.hotspots.filter((item) => save.seen.includes(`${room.n}:${item.id}`));
	const furthest = Math.min(save.frontier, 50);
	function inspect(id) {
		unlockAudio();
		playSfx("note");
		setSelected(id);
		const key = `${room.n}:${id}`;
		setSave((s) => s.seen.includes(key) ? s : {
			...s,
			seen: [...s.seen, key]
		});
	}
	function resolve(ok) {
		if (ok) {
			playSfx("open");
			setJustSolved(true);
			setNotice(null);
			setSave((s) => ({
				...s,
				frontier: Math.max(s.frontier, room.n + 1),
				started: true
			}));
			return;
		}
		playSfx("fail");
		setMisses((m) => m + 1);
		setNotice(misses + 1 >= 3 ? "The lock refuses. The house will hint, if you ask." : "The lock refuses.");
		setShake((k) => k + 1);
		if (lock.kind === "order" || lock.kind === "signal") {
			orderRef.current = [];
			signalRef.current = [];
			setAttempt((a) => ({
				...a,
				order: [],
				signal: []
			}));
		}
	}
	function submit() {
		if (open) return;
		unlockAudio();
		resolve(isCorrect(lock, attempt));
	}
	function clearOrder() {
		orderRef.current = [];
		setAttempt((a) => ({
			...a,
			order: []
		}));
		setNotice(null);
	}
	function pushOrder(id) {
		if (lock.kind !== "order" || open) return;
		if (orderRef.current.includes(id)) return;
		const order = [...orderRef.current, id];
		orderRef.current = order;
		setAttempt((a) => ({
			...a,
			order
		}));
		setNotice(null);
		if (order.length === lock.answer.length) {
			const ok = order.every((step, i) => step === lock.answer[i]);
			if (!ok) orderRef.current = [];
			resolve(ok);
		} else playSfx("tick");
	}
	function pushSignal(id) {
		if (lock.kind !== "signal" || open || signalBusy) return;
		const signal = [...signalRef.current, id];
		signalRef.current = signal;
		setAttempt((a) => ({
			...a,
			signal
		}));
		setNotice(null);
		if (signal.length === lock.answer.length) {
			const ok = signal.every((step, i) => step === lock.answer[i]);
			if (!ok) signalRef.current = [];
			resolve(ok);
		} else playSfx("tick");
	}
	function watchSignal() {
		if (lock.kind !== "signal" || open) return;
		unlockAudio();
		const seq = lock.answer;
		const token = ++watchRef.current;
		signalRef.current = [];
		setAttempt((a) => ({
			...a,
			signal: []
		}));
		setSignalBusy(true);
		setNotice(null);
		let i = 0;
		const tick = () => {
			if (watchRef.current !== token) return;
			if (i >= seq.length) {
				setSignalLit(null);
				setSignalBusy(false);
				return;
			}
			setSignalLit(seq[i] ?? null);
			window.setTimeout(() => {
				if (watchRef.current !== token) return;
				setSignalLit(null);
				i += 1;
				window.setTimeout(tick, 160);
			}, 480);
		};
		tick();
	}
	function askHint() {
		unlockAudio();
		playSfx("hint");
		setSave((s) => {
			const cur = s.hints[String(room.n)] ?? 0;
			if (cur >= 3) return s;
			return {
				...s,
				hints: {
					...s.hints,
					[String(room.n)]: cur + 1
				}
			};
		});
	}
	function goOn() {
		unlockAudio();
		playSfx("tick");
		if (save.frontier > 50 && room.n === 50) {
			onVictory();
			return;
		}
		setSave((s) => ({
			...s,
			viewing: Math.min(s.frontier, 50)
		}));
	}
	let onward = "Enter the next room";
	if (save.frontier > 50 && room.n === 50) onward = "Step outside";
	else if (room.n + 1 < save.frontier) onward = `Return to room ${furthest}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-dvh flex-col bg-walnut text-cream",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center gap-2 border-b border-line px-4 py-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-widest text-brass uppercase",
							children: "Fifty Locks"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-display text-lg tabular-nums",
							children: [
								room.n,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-mist",
									children: " / 50"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mx-2 text-mist",
									children: "·"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-base",
									children: formatDuration(save.elapsedMs)
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-ghost btn-icon",
						onClick: () => setMapOpen(true),
						"aria-label": "House map",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Map, { "aria-hidden": true })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-ghost btn-icon",
						onClick: onMute,
						"aria-label": save.mute ? "Unmute" : "Mute",
						children: save.mute ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { "aria-hidden": true }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { "aria-hidden": true })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-ghost",
						onClick: () => setMenuOpen(true),
						children: "Menu"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-4 pt-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex gap-0.5",
						"aria-hidden": true,
						children: ROOMS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `h-1 min-w-0 flex-1 rounded-full ${item.n < save.frontier ? "bg-brass" : item.n === room.n ? "bg-cream" : "bg-line"}` }, item.n))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-xs tracking-widest text-brass uppercase",
						children: wing.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-3xl text-cream",
						children: room.name
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-h-0 flex-1 flex-col md:grid md:grid-cols-[minmax(0,1.35fr)_minmax(20rem,26rem)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex min-h-72 flex-1 flex-col md:min-h-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoomScene, {
						wing: room.wing,
						open,
						hotspots: room.hotspots,
						selected,
						seen: save.seen.filter((key) => key.startsWith(`${room.n}:`)).map((key) => key.split(":")[1] ?? ""),
						onSelect: inspect,
						card: spot ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "note-card",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-xl text-ink",
									children: spot.label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn btn-ink btn-icon",
									onClick: () => setSelected(null),
									"aria-label": "Close note",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { "aria-hidden": true })
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm leading-relaxed text-ink",
								children: spot.text
							})]
						}) : room.n === 1 && !open && seenHere.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "absolute bottom-4 left-4 rounded-full bg-paper px-3 py-2 text-sm text-ink",
							children: "Tap an object in the room."
						}) : null
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "border-t border-line px-4 py-4 md:overflow-y-auto md:border-t-0 md:border-l",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-mist",
							children: room.line
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "mt-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-xs tracking-widest text-brass uppercase",
								children: "Journal"
							}), seenHere.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-mist",
								children: "Nothing noted yet. Examine the room."
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-2 space-y-2",
								children: seenHere.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: "w-full rounded-lg border border-line bg-surface px-3 py-2 text-left text-sm",
									onClick: () => inspect(item.id),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-brass",
										children: item.label
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-0.5 block text-cream",
										children: item.note
									})]
								}) }, item.id))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: `mt-4 rounded-xl bg-paper p-4 text-ink ${shake ? "lock-shake" : ""}`,
							children: [open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-2xl",
									children: "The lock is open"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm leading-relaxed",
									children: justSolved ? room.yield : "You have already opened this one."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn btn-ink mt-4 w-full",
									onClick: goOn,
									children: onward
								})
							] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LockControls, {
								lock,
								attempt,
								setAttempt,
								signalLit,
								signalBusy,
								onSubmit: submit,
								onOrder: pushOrder,
								onSignal: pushSignal,
								onWatch: watchSignal,
								onClearOrder: clearOrder,
								onEdit: () => setNotice(null)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								role: "status",
								className: "mt-3 min-h-5 text-sm text-wax",
								children: open ? "" : notice ?? ""
							})]
						}, shake),
						!open && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "mt-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-xs tracking-widest text-brass uppercase",
									children: "Hints"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn btn-ghost",
									onClick: askHint,
									disabled: revealed >= 3,
									children: revealed >= 3 ? "No further hints" : "Ask the house"
								})]
							}), revealed === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-mist",
								children: "Three hints. The last one names the answer."
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
								className: "mt-2 space-y-2",
								children: room.hints.slice(0, revealed).map((hint, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "rounded-lg border border-line bg-surface px-3 py-2 text-sm text-cream",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-brass tabular-nums",
										children: [i + 1, ". "]
									}), hint]
								}, hint))
							})]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HouseMap, {
				open: mapOpen,
				onOpenChange: setMapOpen,
				frontier: save.frontier,
				viewing: room.n,
				onPick: (n) => {
					setSave((s) => ({
						...s,
						viewing: n
					}));
					setMapOpen(false);
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: menuOpen,
				onOpenChange: setMenuOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-40 bg-walnut/80" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "fixed top-1/2 left-1/2 z-50 w-[min(24rem,calc(100%-2rem))] -translate-x-1/2 -translate-y-1/2 rounded-2xl border border-line bg-surface p-5 text-cream",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
							className: "font-display text-2xl",
							children: "House menu"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
							className: "mt-2 text-sm text-mist",
							children: "Leaving for the front door keeps your progress."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 flex flex-col gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn btn-brass",
									onClick: onTitle,
									children: "Front door"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn btn-ghost",
									onClick: () => setConfirmReset(true),
									children: "Start over"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
									className: "btn btn-ghost",
									children: "Close"
								})
							]
						})
					]
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: confirmReset,
				onOpenChange: setConfirmReset,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-40 bg-walnut/80" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "fixed top-1/2 left-1/2 z-50 w-[min(24rem,calc(100%-2rem))] -translate-x-1/2 -translate-y-1/2 rounded-2xl border border-line bg-surface p-5 text-cream",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
							className: "font-display text-2xl",
							children: "Start over?"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
							className: "mt-2 text-sm text-mist",
							children: "This forgets the room you have reached, the journal, and the clock."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 flex flex-col gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-brass",
								onClick: onReset,
								children: "Forget this run"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
								className: "btn btn-ghost",
								children: "Keep going"
							})]
						})
					]
				})] })
			})
		]
	});
}
function RoomScene({ wing, open, hotspots, selected, seen, onSelect, card }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "scene flex-1",
		"data-wing": wing,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "scene-wall" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "scene-floor" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "scene-board" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "scene-window" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "scene-shelf" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "scene-rug" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `scene-door ${open ? "open" : ""}`,
				"aria-hidden": true,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {})
				]
			}),
			hotspots.map((item) => {
				const Icon = ICONS[item.icon];
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "hotspot",
					style: {
						["--x"]: item.x,
						["--y"]: item.y
					},
					"data-on": selected === item.id,
					onClick: () => onSelect(item.id),
					"aria-pressed": selected === item.id,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
						"aria-hidden": true,
						className: `size-5 ${seen.includes(item.id) ? "text-brass" : "text-cream"}`
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: item.label })]
				}, item.id);
			}),
			card
		]
	});
}
function LockControls({ lock, attempt, setAttempt, signalLit, signalBusy, onSubmit, onOrder, onSignal, onWatch, onClearOrder, onEdit }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-2xl",
			children: "The lock"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm leading-relaxed",
			children: lock.prompt
		}),
		lock.kind === "code" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeLock, {
			length: lock.answer.length,
			value: attempt.code,
			onChange: (code) => {
				onEdit();
				setAttempt((a) => ({
					...a,
					code
				}));
			},
			onSubmit
		}),
		lock.kind === "word" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "mt-4",
			onSubmit: (event) => {
				event.preventDefault();
				onSubmit();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block text-xs tracking-widest text-brass-deep uppercase",
					htmlFor: "word-lock",
					children: [lock.answer.length, " letters"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					id: "word-lock",
					value: attempt.word,
					autoComplete: "off",
					autoCorrect: "off",
					autoCapitalize: "characters",
					spellCheck: false,
					maxLength: lock.answer.length,
					onChange: (event) => {
						onEdit();
						setAttempt((a) => ({
							...a,
							word: event.target.value.toUpperCase().replace(/[^A-Z]/g, "")
						}));
					},
					className: "mt-2 w-full rounded-lg border border-brass-deep bg-paper-dim px-3 py-3 text-center font-display text-2xl tracking-widest text-ink uppercase"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "btn btn-ink mt-4 w-full",
					disabled: attempt.word.length !== lock.answer.length,
					children: "Try the lock"
				})
			]
		}),
		lock.kind === "order" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-2",
				children: lock.steps.map((step) => {
					const pos = attempt.order.indexOf(step.id);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "btn btn-ink justify-between",
						onClick: () => onOrder(step.id),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: step.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums text-brass",
							children: pos >= 0 ? pos + 1 : ""
						})]
					}, step.id);
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "btn btn-ghost mt-3 w-full border-line text-ink",
				onClick: onClearOrder,
				children: "Reset order"
			})]
		}),
		lock.kind === "dials" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 grid gap-3",
			children: [lock.dials.map((dial, index) => {
				const value = dial.options[attempt.dials[index] ?? 0] ?? dial.options[0];
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "btn btn-ink justify-between",
					onClick: () => {
						onEdit();
						setAttempt((a) => {
							const dials = [...a.dials];
							dials[index] = ((dials[index] ?? 0) + 1) % dial.options.length;
							return {
								...a,
								dials
							};
						});
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: dial.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-xl text-brass",
						children: value
					})]
				}, dial.id);
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "btn btn-brass",
				onClick: onSubmit,
				children: "Try the lock"
			})]
		}),
		lock.kind === "pick" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 grid gap-2",
			children: [lock.options.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: `rounded-lg border px-3 py-3 text-left ${attempt.pick === option.id ? "border-brass-deep bg-paper-dim" : "border-line bg-paper"}`,
				onClick: () => {
					onEdit();
					setAttempt((a) => ({
						...a,
						pick: option.id
					}));
				},
				"aria-pressed": attempt.pick === option.id,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block font-medium",
					children: option.label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-1 block text-sm opacity-80",
					children: option.detail
				})]
			}, option.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "btn btn-ink mt-2",
				onClick: onSubmit,
				disabled: !attempt.pick,
				children: "Try the lock"
			})]
		}),
		lock.kind === "signal" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn btn-ink w-full",
					onClick: onWatch,
					disabled: signalBusy,
					children: signalBusy ? "Watching…" : "Watch the signal"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 min-h-6 text-center text-sm tracking-wide text-ink",
					children: attempt.signal.map((id) => lock.pads.find((pad) => pad.id === id)?.label ?? id).join(" · ") || "Repeat the flashes."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 grid grid-cols-2 gap-2",
					children: lock.pads.map((pad) => {
						const lit = signalLit === pad.id;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: `btn btn-ink ${lit ? "bg-brass text-ink" : ""}`,
							onClick: () => onSignal(pad.id),
							disabled: signalBusy,
							children: pad.label
						}, pad.id);
					})
				})
			]
		})
	] });
}
function CodeLock({ length, value, onChange, onSubmit }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-center gap-2",
				"aria-hidden": true,
				children: Array.from({ length }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex h-12 w-10 items-center justify-center rounded-lg bg-paper-dim font-display text-2xl text-ink tabular-nums",
					children: value[i] ?? ""
				}, i))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid grid-cols-3 gap-2",
				children: [
					[
						"1",
						"2",
						"3",
						"4",
						"5",
						"6",
						"7",
						"8",
						"9"
					].map((key) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-ink",
						onClick: () => {
							if (value.length >= length) return;
							onChange(value + key);
							playSfx("tick");
						},
						children: key
					}, key)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-ghost border-line text-ink",
						onClick: () => onChange(""),
						children: "Clear"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-ink",
						onClick: () => {
							if (value.length >= length) return;
							onChange(value + "0");
							playSfx("tick");
						},
						children: "0"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-ghost border-line text-ink",
						onClick: () => onChange(value.slice(0, -1)),
						"aria-label": "Backspace",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Delete, { "aria-hidden": true })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "btn btn-brass mt-3 w-full",
				onClick: onSubmit,
				disabled: value.length !== length,
				children: "Try the lock"
			})
		]
	});
}
function HouseMap({ open, onOpenChange, frontier, viewing, onPick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-40 bg-walnut/80" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "fixed top-1/2 left-1/2 z-50 max-h-[min(40rem,calc(100%-2rem))] w-[min(36rem,calc(100%-2rem))] -translate-x-1/2 -translate-y-1/2 overflow-y-auto rounded-2xl border border-line bg-surface p-5 text-cream",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
					className: "font-display text-2xl",
					children: "The house"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
					className: "mt-1 text-sm text-mist",
					children: "Open rooms can be revisited. Locked rooms wait."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
					className: "btn btn-ghost btn-icon",
					"aria-label": "Close map",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { "aria-hidden": true })
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 space-y-5",
				children: WINGS.map((wing) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-xs tracking-widest text-brass uppercase",
						children: wing.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-mist",
						children: wing.motto
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 grid grid-cols-5 gap-2",
						children: ROOMS.filter((item) => item.wing === wing.id).map((item) => {
							const locked = item.n > frontier;
							const current = item.n === viewing;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								disabled: locked,
								onClick: () => onPick(item.n),
								className: `btn min-w-0 px-0 tabular-nums ${current ? "btn-brass" : locked ? "btn-ghost" : "btn-ghost border-brass text-brass"}`,
								"aria-label": `${locked ? "Locked room" : "Room"} ${item.n}, ${item.name}`,
								children: item.n
							}, item.n);
						})
					})
				] }, wing.id))
			})]
		})] })
	});
}
var SplitComponent = EscapeGame;
//#endregion
export { SplitComponent as component };
