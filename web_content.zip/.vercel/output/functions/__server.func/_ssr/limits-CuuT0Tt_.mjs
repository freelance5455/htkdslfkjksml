//#region node_modules/.nitro/vite/services/ssr/assets/limits-CuuT0Tt_.js
var RUN_TIMEOUT_MS = 8e3;
var PYTHON_LOAD_TIMEOUT_MS = 25e3;
var AI_MAX_CODE_CHARS = 12e3;
var SKIP_ZIP_PARTS = [
	"node_modules/",
	".git/",
	"__MACOSX/",
	".ds_store",
	"dist/",
	"build/",
	".next/",
	"vendor/"
];
function shouldSkipZipPath(path) {
	const lower = path.toLowerCase();
	return SKIP_ZIP_PARTS.some((part) => lower.includes(part));
}
function utf8Bytes(text) {
	return new TextEncoder().encode(text).length;
}
//#endregion
export { utf8Bytes as a, shouldSkipZipPath as i, PYTHON_LOAD_TIMEOUT_MS as n, RUN_TIMEOUT_MS as r, AI_MAX_CODE_CHARS as t };
