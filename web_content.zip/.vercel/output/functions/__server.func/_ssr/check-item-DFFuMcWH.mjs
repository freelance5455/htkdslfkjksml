import { w as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { f as cn } from "./store-CuJQmbYj.mjs";
import { x as Check } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/check-item-DFFuMcWH.js
var import_jsx_runtime = require_jsx_runtime();
function CheckItem({ checked, label, hint, onToggle, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: onToggle,
		className: cn("flex w-full items-center gap-3 rounded-xl px-1 py-2.5 text-left transition-colors hover:bg-accent/50", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("flex size-6 shrink-0 items-center justify-center rounded-md border transition-[background-color,border-color,box-shadow]", checked ? "animate-check-pop border-primary bg-primary text-primary-foreground" : "border-border bg-transparent text-transparent"),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
				className: "size-3.5",
				strokeWidth: 3
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "min-w-0 flex-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: cn("block text-sm font-medium", checked ? "text-muted-foreground line-through" : "text-foreground"),
				children: label
			}), hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block text-xs text-muted-foreground",
				children: hint
			}) : null]
		})]
	});
}
//#endregion
export { CheckItem as t };
