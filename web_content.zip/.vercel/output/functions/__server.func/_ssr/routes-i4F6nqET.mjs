import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { n as platformLabel, t as formatRange } from "./format-Ci0m3vzz.mjs";
import { a as Trash2, c as Shield, d as ImagePlus, f as Copy, h as ArrowLeftRight, i as TriangleAlert, l as LoaderCircle, m as ChevronDown, n as X, o as Store, p as Coins, r as Upload, s as ShoppingCart, t as Zap, u as Info } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-i4F6nqET.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function Badge({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold text-accent shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-accent)_40%,transparent)] bg-accent/10", className),
		...props
	});
}
function BrandHeader() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "mb-6 flex flex-col items-center text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-4 flex items-center gap-1.5 font-display text-xs font-semibold uppercase tracking-[0.22em] text-accent",
				children: "eFootball 2025 / 2026"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex size-12 items-center justify-center rounded-[var(--radius-lg)] bg-accent text-accent-fg shadow-[var(--shadow-lift)]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, {
						className: "size-6",
						strokeWidth: 2.2,
						"aria-hidden": true
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-left",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-3xl font-semibold tracking-tight text-fg",
						children: "Bruno Gaming"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-xs font-medium uppercase tracking-[0.18em] text-muted",
						children: "Pro Account Appraisal"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, {
				className: "size-3",
				"aria-hidden": true
			}), "မြန်မာ့ eFootball စျေးကွက်ပေါက်စျေး"] })
		]
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 font-medium select-none transition-[opacity,transform,background-color,box-shadow,color] duration-150 ease-[var(--ease-out)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-40 active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			primary: "bg-accent text-accent-fg hover:opacity-90",
			secondary: "bg-surface-2 text-fg shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]",
			ghost: "text-muted hover:text-fg hover:bg-surface-2",
			danger: "bg-danger/15 text-danger hover:bg-danger/25"
		},
		size: {
			sm: "h-9 px-3 text-sm rounded-[var(--radius-sm)]",
			md: "h-11 px-4 text-sm rounded-[var(--radius-md)]",
			lg: "h-12 w-full px-5 text-base rounded-[var(--radius-md)]",
			icon: "size-11 rounded-[var(--radius-md)]"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
function Button({ className, variant, size, asChild, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		type: asChild ? void 0 : type,
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
function ImageDropzone({ files, previews, onAdd, onRemove, onClear }) {
	const inputRef = (0, import_react.useRef)(null);
	const atCap = files.length >= 6;
	function pick() {
		if (atCap) return;
		inputRef.current?.click();
	}
	function handleFiles(list) {
		const incoming = Array.from(list).filter((f) => f.type.startsWith("image/"));
		if (incoming.length === 0) return;
		const room = 6 - files.length;
		onAdd(incoming.slice(0, room));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-2 flex items-center justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-muted",
			children: "Squad & Players စခရင်ရှော့"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "rounded-full bg-accent/10 px-2.5 py-0.5 font-display text-xs font-semibold tabular-nums text-accent",
			children: [
				files.length,
				"/",
				6
			]
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("rounded-[var(--radius-lg)] bg-bg p-3 shadow-[var(--shadow-border)] transition-[box-shadow] duration-150", "focus-within:ring-2 focus-within:ring-ring"),
		onDragOver: (e) => {
			e.preventDefault();
		},
		onDrop: (e) => {
			e.preventDefault();
			if (e.dataTransfer.files) handleFiles(e.dataTransfer.files);
		},
		children: [files.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: pick,
			className: "flex w-full flex-col items-center justify-center rounded-[var(--radius-md)] px-3 py-6 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mb-2 flex size-11 items-center justify-center rounded-full bg-surface-2 text-accent",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, {
						className: "size-5",
						"aria-hidden": true
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm font-bold text-fg",
					children: "စခရင်ရှော့ပုံများ တင်ရန်နှိပ်ပါ"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-1 text-xs text-muted",
					children: "Main Squad, Subs, Reserve & Epic ကတ်များ · အများဆုံး ၆ ပုံ"
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-3 gap-2",
			children: previews.map((src, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative aspect-video overflow-hidden rounded-[var(--radius-sm)] bg-surface-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src,
					alt: `screenshot ${idx + 1}`,
					className: "size-full object-cover outline outline-1 -outline-offset-1 outline-fg/10"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onRemove(idx),
					className: "absolute top-1 right-1 flex size-8 items-center justify-center rounded-full bg-danger text-fg",
					"aria-label": "ပုံဖျက်ရန်",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" })
				})]
			}, `${files[idx]?.name}-${idx}`))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 flex items-center justify-between border-t border-border pt-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "ghost",
				size: "sm",
				onClick: pick,
				disabled: atCap,
				className: "text-accent hover:text-accent",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "size-3.5" }), "ပုံထပ်ထည့်မည်"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "ghost",
				size: "sm",
				onClick: onClear,
				className: "text-danger hover:text-danger",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" }), "အားလုံးဖျက်မည်"]
			})]
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			ref: inputRef,
			type: "file",
			accept: "image/*",
			multiple: true,
			className: "sr-only",
			onChange: (e) => {
				if (e.target.files) handleFiles(e.target.files);
				e.target.value = "";
			}
		})]
	})] });
}
function CardList({ title, items, tone }) {
	if (items.length === 0) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
		className: "mb-2 text-xs font-bold uppercase tracking-wider text-muted",
		children: title
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "space-y-1.5",
		children: items.map((card) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: cn("rounded-[var(--radius-sm)] bg-surface-2 px-3 py-2", tone === "paid" ? "shadow-[inset_3px_0_0_var(--color-accent)]" : "opacity-80"),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-baseline justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm font-bold text-fg",
					children: card.name
				}), card.skill ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-display text-xs tracking-wide text-accent",
					children: card.skill
				}) : null]
			}), card.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-0.5 text-xs text-muted",
				children: card.note
			}) : null]
		}, card.name))
	})] });
}
function ResultPanel({ appraisal, intent, timestamp, onCopy, onClose }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "rounded-[var(--radius-2xl)] bg-surface p-1 shadow-[var(--shadow-border)]",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-[calc(var(--radius-2xl)-4px)] bg-bg p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 flex items-start justify-between gap-3 border-b border-border pb-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-base font-bold text-fg",
						children: "AI တွက်ချက်မှုရလဒ်"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: timestamp
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "secondary",
							size: "sm",
							onClick: onCopy,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-3.5" }), "Copy"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							className: "size-9",
							onClick: onClose,
							"aria-label": "ပိတ်မည်",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-2 flex flex-wrap items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "rounded-full bg-accent/15 px-2.5 py-0.5 font-display text-xs font-semibold tracking-wide text-accent",
								children: [
									"TIER ",
									appraisal.tier,
									" · ",
									appraisal.tierLabel
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs text-muted",
								children: [
									intent === "buy" ? "ဝယ်ယူသူအတွက်" : "ရောင်းချသူအတွက်",
									" ·",
									" ",
									appraisal.confidence === "high" ? "ယုံကြည်မှု မြင့်" : appraisal.confidence === "low" ? "ယုံကြည်မှု နိမ့်" : "ယုံကြည်မှု အလယ်အလတ်"
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-3xl font-semibold tracking-tight text-fg tabular-nums",
							children: formatRange(appraisal.finalMin, appraisal.finalMax)
						}),
						appraisal.summary ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: appraisal.summary
						}) : null
					]
				}),
				appraisal.deadLinkPenaltyPct > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 flex gap-2 rounded-[var(--radius-md)] bg-danger/10 px-3 py-2.5 text-sm text-danger",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
						className: "mt-0.5 size-4 shrink-0",
						"aria-hidden": true
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"Google Dead Link ကြောင့် ",
						appraisal.deadLinkPenaltyPct,
						"% လျော့တွက်ထားသည်။"
					] })]
				}) : null,
				appraisal.warnings.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex gap-2 rounded-[var(--radius-md)] bg-surface-2 px-3 py-2 text-sm text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
						className: "mt-0.5 size-4 shrink-0 text-accent",
						"aria-hidden": true
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: w })]
				}, w)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardList, {
							title: "စျေးရရှိမည့် Paid / Special Skill",
							items: appraisal.paidCards,
							tone: "paid"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardList, {
							title: "စျေးမရသော Free Booster / Event",
							items: appraisal.freeCards,
							tone: "free"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardList, {
							title: "Managers",
							items: appraisal.managers,
							tone: "paid"
						})
					]
				}),
				appraisal.coinAddMmk > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-xs text-muted",
					children: [
						"Coins တန်ဖိုး ထည့်တွက်ပြီး:",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-display tabular-nums text-fg",
							children: [
								"+",
								appraisal.coinAddMmk.toLocaleString("en-US"),
								" MMK"
							]
						})
					]
				}) : null,
				appraisal.marketAnalysis ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
						className: "mb-1.5 text-xs font-bold uppercase tracking-wider text-muted",
						children: "စျေးကွက်အခြေအနေ"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-fg",
						children: appraisal.marketAnalysis
					})]
				}) : null,
				appraisal.strategyPoints.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
						className: "mb-2 text-xs font-bold uppercase tracking-wider text-muted",
						children: intent === "buy" ? "ဝယ်ယူသူအတွက် အကြံပြုချက်" : "ရောင်းချသူအတွက် အကြံပြုချက်"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "space-y-1.5",
						children: appraisal.strategyPoints.map((point, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-start gap-2 text-sm text-fg",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-[var(--radius-xs)] bg-surface-2 font-display text-xs text-accent",
								children: i + 1
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: point })]
						}, point))
					})]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex items-center justify-between border-t border-border pt-3 text-xs text-subtle",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Myanmar Market Engine" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display tracking-wide",
						children: "Bruno Gaming"
					})]
				})
			]
		})
	});
}
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("h-11 w-full rounded-[var(--radius-md)] bg-bg px-3.5 text-sm text-fg shadow-[var(--shadow-border)] placeholder:text-subtle transition-[box-shadow] duration-150 ease-[var(--ease-out)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring", className),
		...props
	});
}
function Label({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		className: cn("mb-2 flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-muted", className),
		...props
	});
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var MAX_IMAGES = 6;
var MAX_B64_CHARS = 18e5;
function validateInput(input) {
	if (input.intent !== "buy" && input.intent !== "sell") throw new Error("invalid-intent");
	if (![
		"mobile",
		"pc",
		"console"
	].includes(input.platform)) throw new Error("invalid-platform");
	const images = Array.isArray(input.images) ? input.images.slice(0, MAX_IMAGES) : [];
	for (const img of images) {
		if (!img?.data || img.data.length > MAX_B64_CHARS) throw new Error("image-too-large");
		if (!String(img.mimeType || "").startsWith("image/")) throw new Error("invalid-image");
	}
	return {
		intent: input.intent,
		platform: input.platform,
		strength: String(input.strength ?? "").slice(0, 16),
		coins: String(input.coins ?? "").slice(0, 16),
		hasLinkError: Boolean(input.hasLinkError),
		images
	};
}
var analyzeAccount = createServerFn({ method: "POST" }).validator((input) => validateInput(input)).handler(createSsrRpc("6d51885f3d3dbdaa04c44ff29f7ce33dff85945ba32b6be4cba32716407c1cc9"));
var MAX_EDGE = 1280;
var JPEG_QUALITY = .72;
var MAX_SOURCE_BYTES = 12582912;
function blobToBase64(blob) {
	return new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.onload = () => {
			const result = String(reader.result ?? "");
			const comma = result.indexOf(",");
			resolve(comma >= 0 ? result.slice(comma + 1) : result);
		};
		reader.onerror = () => reject(reader.error ?? /* @__PURE__ */ new Error("read failed"));
		reader.readAsDataURL(blob);
	});
}
async function compressImage(file) {
	if (!file.type.startsWith("image/")) throw new Error("image-only");
	if (file.size > MAX_SOURCE_BYTES) throw new Error("too-large");
	const bitmap = await createImageBitmap(file);
	const scale = Math.min(1, MAX_EDGE / Math.max(bitmap.width, bitmap.height));
	const width = Math.max(1, Math.round(bitmap.width * scale));
	const height = Math.max(1, Math.round(bitmap.height * scale));
	const canvas = document.createElement("canvas");
	canvas.width = width;
	canvas.height = height;
	const ctx = canvas.getContext("2d");
	if (!ctx) {
		bitmap.close();
		throw new Error("canvas");
	}
	ctx.drawImage(bitmap, 0, 0, width, height);
	bitmap.close();
	return {
		mimeType: "image/jpeg",
		data: await blobToBase64(await new Promise((resolve, reject) => {
			canvas.toBlob((b) => b ? resolve(b) : reject(/* @__PURE__ */ new Error("encode")), "image/jpeg", JPEG_QUALITY);
		}))
	};
}
function appraisalToText(appraisal, intent, platform) {
	const lines = [
		"Bruno Gaming — eFootball Account Appraisal",
		`Intent: ${intent === "buy" ? "Buy" : "Sell"} · ${platformLabel(platform)}`,
		`Tier ${appraisal.tier} · ${appraisal.tierLabel}`,
		`ပေါက်စျေး: ${formatRange(appraisal.finalMin, appraisal.finalMax)}`
	];
	if (appraisal.summary) lines.push(appraisal.summary);
	if (appraisal.paidCards.length) {
		lines.push("", "Paid / Special Skill:");
		for (const c of appraisal.paidCards) lines.push(`- ${c.name}${c.skill ? ` (${c.skill})` : ""}${c.note ? ` — ${c.note}` : ""}`);
	}
	if (appraisal.freeCards.length) {
		lines.push("", "Free / Event (စျေးမရ):");
		for (const c of appraisal.freeCards) lines.push(`- ${c.name}${c.note ? ` — ${c.note}` : ""}`);
	}
	if (appraisal.managers.length) {
		lines.push("", "Managers:");
		for (const c of appraisal.managers) lines.push(`- ${c.name}${c.note ? ` — ${c.note}` : ""}`);
	}
	if (appraisal.marketAnalysis) lines.push("", "စျေးကွက်:", appraisal.marketAnalysis);
	if (appraisal.strategyPoints.length) {
		lines.push("", "အကြံပြုချက်:");
		appraisal.strategyPoints.forEach((p, i) => lines.push(`${i + 1}. ${p}`));
	}
	if (appraisal.warnings.length) {
		lines.push("", "သတိပေးချက်:");
		for (const w of appraisal.warnings) lines.push(`- ${w}`);
	}
	lines.push("", "— Bruno Gaming");
	return lines.join("\n");
}
var ERRORS = {
	unavailable: "AI ဝန်ဆောင်မှု ယာယီမရရှိပါ။ ခဏနေမှ ပြန်ကြိုးစားပါ။",
	"need-input": "စခရင်ရှော့ပုံ (သို့) Strength ထည့်သွင်းပေးပါ။",
	empty: "AI ထံမှ အချက်အလက် ရယူ၍ မရပါ။",
	busy: "ဆာဗာအလုပ်များနေပါသည်။ ခဏနေမှ ပြန်ကြိုးစားပါ။",
	timeout: "အချိန်ပြည့်သွားပါသည်။ ပုံအရေအတွက် လျှော့ပြီး ပြန်စမ်းပါ။",
	failed: "တွက်ချက်၍ မရပါ။ အင်တာနက်ချိတ်ဆက်မှု စစ်ဆေးပါ။",
	"too-large": "ပုံအရွယ်အစား ကြီးလွန်းပါသည်။",
	"image-only": "ဓာတ်ပုံဖိုင်များသာ တင်ပေးပါ။"
};
var LOADING_STEPS = [
	"ပုံများ ဖတ်နေသည်...",
	"ကတ်များ ခွဲနေသည်...",
	"ပေါက်စျေး ချိန်နေသည်..."
];
var STORAGE_KEY = "bruno_last_appraisal";
function Calculator() {
	const [intent, setIntent] = (0, import_react.useState)("buy");
	const [platform, setPlatform] = (0, import_react.useState)("mobile");
	const [strength, setStrength] = (0, import_react.useState)("");
	const [coins, setCoins] = (0, import_react.useState)("");
	const [hasLinkError, setHasLinkError] = (0, import_react.useState)(false);
	const [files, setFiles] = (0, import_react.useState)([]);
	const [previews, setPreviews] = (0, import_react.useState)([]);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [loadingStep, setLoadingStep] = (0, import_react.useState)(0);
	const [result, setResult] = (0, import_react.useState)(null);
	const resultRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		try {
			const raw = localStorage.getItem(STORAGE_KEY);
			if (!raw) return;
			const parsed = JSON.parse(raw);
			if (parsed?.appraisal?.finalMin != null) setResult(parsed);
		} catch {}
	}, []);
	(0, import_react.useEffect)(() => {
		const urls = files.map((f) => URL.createObjectURL(f));
		setPreviews(urls);
		return () => urls.forEach((u) => URL.revokeObjectURL(u));
	}, [files]);
	(0, import_react.useEffect)(() => {
		if (!loading) return;
		setLoadingStep(0);
		const id = window.setInterval(() => {
			setLoadingStep((s) => (s + 1) % LOADING_STEPS.length);
		}, 2200);
		return () => window.clearInterval(id);
	}, [loading]);
	const canSubmit = (0, import_react.useMemo)(() => files.length > 0 || strength.trim().length > 0, [files.length, strength]);
	function addFiles(incoming) {
		setFiles((prev) => {
			const room = 6 - prev.length;
			if (room <= 0) {
				toast.error(`အများဆုံး 6 ပုံသာ တင်ခွင့်ရှိပါသည်။`);
				return prev;
			}
			if (incoming.length > room) toast.error(`အများဆုံး 6 ပုံသာဖြစ်၍ ပထမ ${room} ပုံကိုသာ ထည့်ထားသည်။`);
			return prev.concat(incoming.slice(0, room));
		});
	}
	async function onAnalyze() {
		if (!canSubmit) {
			toast.error(ERRORS["need-input"]);
			return;
		}
		setLoading(true);
		try {
			const images = [];
			for (const file of files) images.push(await compressImage(file));
			const response = await analyzeAccount({ data: {
				intent,
				platform,
				strength: strength.trim(),
				coins: coins.trim(),
				hasLinkError,
				images
			} });
			if (!response.ok) {
				toast.error(ERRORS[response.error] ?? ERRORS.failed);
				return;
			}
			const next = {
				appraisal: response.appraisal,
				intent,
				platform,
				timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString("my-MM", {
					hour: "2-digit",
					minute: "2-digit"
				})
			};
			setResult(next);
			try {
				localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
			} catch {}
			window.setTimeout(() => {
				resultRef.current?.scrollIntoView({
					behavior: "smooth",
					block: "start"
				});
			}, 50);
		} catch (err) {
			const msg = err instanceof Error ? err.message : "";
			toast.error(ERRORS[msg] ?? ERRORS.failed);
		} finally {
			setLoading(false);
		}
	}
	async function copyResult() {
		if (!result) return;
		const text = appraisalToText(result.appraisal, result.intent, result.platform);
		try {
			await navigator.clipboard.writeText(text);
			toast.success("ရလဒ်အား ကူးယူပြီးပါပြီ");
		} catch {
			toast.error("Copy လုပ်၍ မရပါ");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "mb-6 rounded-[var(--radius-2xl)] bg-surface p-5 shadow-[var(--shadow-border)]",
		onSubmit: (e) => {
			e.preventDefault();
			onAnalyze();
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeftRight, {
					className: "size-3.5 text-accent",
					"aria-hidden": true
				}), "ရည်ရွယ်ချက်"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-1 rounded-[var(--radius-lg)] bg-bg p-1 shadow-[var(--shadow-border)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setIntent("buy"),
						className: cn("flex h-11 items-center justify-center gap-1.5 rounded-[var(--radius-md)] text-sm font-bold transition-[background-color,color] duration-150", intent === "buy" ? "bg-accent/15 text-accent" : "text-muted hover:text-fg"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingCart, {
							className: "size-4",
							"aria-hidden": true
						}), "ဝယ်ယူမည်"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setIntent("sell"),
						className: cn("flex h-11 items-center justify-center gap-1.5 rounded-[var(--radius-md)] text-sm font-bold transition-[background-color,color] duration-150", intent === "sell" ? "bg-accent/15 text-accent" : "text-muted hover:text-fg"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Store, {
							className: "size-4",
							"aria-hidden": true
						}), "ရောင်းချမည်"]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "platform",
					children: "Platform"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						id: "platform",
						value: platform,
						onChange: (e) => setPlatform(e.target.value),
						className: "h-11 w-full appearance-none rounded-[var(--radius-md)] bg-bg px-3.5 pr-10 text-sm text-fg shadow-[var(--shadow-border)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "mobile",
								children: "Mobile (Android / iOS)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "pc",
								children: "PC (Steam)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "console",
								children: "Console (PlayStation / Xbox)"
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
						className: "pointer-events-none absolute top-1/2 right-3.5 size-4 -translate-y-1/2 text-muted",
						"aria-hidden": true
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageDropzone, {
					files,
					previews,
					onAdd: addFiles,
					onRemove: (i) => setFiles((prev) => prev.filter((_, idx) => idx !== i)),
					onClear: () => setFiles([])
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-5 grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
					htmlFor: "strength",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, {
						className: "size-3.5 text-accent",
						"aria-hidden": true
					}), "Strength"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "strength",
					type: "number",
					inputMode: "numeric",
					min: 0,
					placeholder: "3180",
					value: strength,
					onChange: (e) => setStrength(e.target.value)
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
					htmlFor: "coins",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Coins, {
						className: "size-3.5 text-accent",
						"aria-hidden": true
					}), "eFo Coins"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "coins",
					type: "number",
					inputMode: "numeric",
					min: 0,
					placeholder: "500",
					value: coins,
					onChange: (e) => setCoins(e.target.value)
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: cn("mb-6 flex cursor-pointer items-start gap-3 rounded-[var(--radius-lg)] px-3.5 py-3 transition-[background-color,box-shadow] duration-150", hasLinkError ? "bg-danger/15 shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-danger)_55%,transparent)]" : "bg-danger/10 shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-danger)_25%,transparent)]"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					className: "mt-0.5 size-5 accent-[var(--color-danger)]",
					checked: hasLinkError,
					onChange: (e) => setHasLinkError(e.target.checked)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "flex items-center gap-1.5 text-sm font-bold text-danger",
					children: "Google Link Error (Dead Link) ပါဝင်သည်"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-0.5 block text-xs text-muted",
					children: "ဂျီးလင့်ပါပါက စျေးကွက်ပေါက်စျေး ၅၀% မှ ၈၀% အထိ လျော့ကျသည်။"
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				size: "lg",
				disabled: loading,
				children: loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
					className: "size-5 animate-spin",
					"aria-hidden": true
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: LOADING_STEPS[loadingStep] })] }) : "ပေါက်စျေး စစ်ဆေးတွက်ချက်မည်"
			})
		]
	}), result ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: resultRef,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultPanel, {
			appraisal: result.appraisal,
			intent: result.intent,
			timestamp: `${result.timestamp} တွင် တွက်ချက်သည်`,
			onCopy: () => void copyResult(),
			onClose: () => setResult(null)
		})
	}) : null] });
}
var TIERS = [
	{
		tier: "T1",
		range: "15k – 26k",
		note: "Free epic / POTW အများစု"
	},
	{
		tier: "T2",
		range: "50k – 70k",
		note: "Paid epic ၁–၃ ကတ်"
	},
	{
		tier: "T3",
		range: "75k – 100k",
		note: "Paid ၄–၆ + manager"
	},
	{
		tier: "T4",
		range: "130k – 250k+",
		note: "Full paid booster XI"
	}
];
function MarketGuide() {
	const [open, setOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mb-5 rounded-[var(--radius-xl)] bg-surface p-4 shadow-[var(--shadow-border)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			className: "flex w-full items-center justify-between gap-3 text-left",
			onClick: () => setOpen((v) => !v),
			"aria-expanded": open,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "flex items-center gap-2 text-sm font-bold text-fg",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
					className: "size-4 text-accent",
					"aria-hidden": true
				}), "ပေါက်စျေးတွက်ချက်မှု စံနှုန်းများ"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
				className: cn("size-4 text-muted transition-transform duration-200 ease-[var(--ease-out)]", open && "rotate-180"),
				"aria-hidden": true
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cn("grid transition-[grid-template-rows,opacity] duration-200 ease-[var(--ease-out)]", open ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 space-y-3 border-t border-border pt-3 text-sm text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-bold text-fg",
								children: "Free Double Booster Epics"
							}),
							" ",
							"(Costacurta, Cannavaro, Kahn, Ribery, Saviola, Daily Penalty / Event ကတ်များ) — အကောင့်အပြည့်ပါသော်လည်း စျေးမရပါ။ ပေါက်စျေး",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-bold text-fg",
								children: "15,000 – 26,000 MMK"
							}),
							" သာရှိသည်။"
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-bold text-accent",
								children: "Paid Booster & Special Skills"
							}),
							" ",
							"(Treasure Link Ferdinand, Blitz Curler, Bullet Header, Big Time, Capello) ငွေသုံးဖွင့်ရသော ကတ်များမှသာ",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-bold text-fg",
								children: "65,000 – 150,000+ MMK"
							}),
							" ရရှိသည်။"
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "grid grid-cols-2 gap-2",
							children: TIERS.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "rounded-[var(--radius-md)] bg-surface-2 px-3 py-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-baseline justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-display text-xs font-semibold tracking-wide text-accent",
										children: row.tier
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-display text-xs tabular-nums text-fg",
										children: row.range
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-0.5 text-xs text-muted",
									children: row.note
								})]
							}, row.tier))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs",
							children: "1,000 coins = +20,000 MMK · Google Dead Link ရှိပါက စျေး 50–75% လျော့သည်။"
						})
					]
				})
			})
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto w-full max-w-lg overflow-x-hidden px-4 pt-6 pb-16 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrandHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarketGuide, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calculator, {})
		]
	});
}
//#endregion
export { Home as component };
