import { i as __toESM } from "../_runtime.mjs";
import { S as require_jsx_runtime, Y as require_react, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as opinionLabel, r as formatClock } from "./text-CqN-AAxZ.mjs";
import { a as Trash2, c as Plus, d as Feather, l as Hourglass, m as BookOpen, n as Users, o as Send, p as ChevronLeft, r as Undo2, s as ScrollText, t as X } from "../_libs/lucide-react.mjs";
import { a as Segmented, n as Field, o as useForge, s as useHydrated, t as Button } from "./ui-buLXhEze.mjs";
import { c as restoreUndo, i as blankCharacter, n as addManualMemory, o as markChronicleSeen, r as applyNarration, s as narrateTurn } from "./narrate-Dlb48ySq.mjs";
import { n as Route } from "./router-Delx-kdG.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/partida._id-Buq5P3Dk.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PROSE = [
	{
		id: "breve",
		label: "Breve"
	},
	{
		id: "equilibrada",
		label: "Media"
	},
	{
		id: "literaria",
		label: "Literaria"
	}
];
var AUTONOMY = [
	{
		id: "contenida",
		label: "Contenida"
	},
	{
		id: "viva",
		label: "Viva"
	},
	{
		id: "impredecible",
		label: "Abierta"
	}
];
function Dossier({ campaign, tab, onChange }) {
	if (tab === "escena") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SceneTab, {
		campaign,
		onChange
	});
	if (tab === "gente") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PeopleTab, {
		campaign,
		onChange
	});
	if (tab === "memoria") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MemoryTab, {
		campaign,
		onChange
	});
	if (tab === "cronica") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChronicleTab, { campaign });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorldTab, {
		campaign,
		onChange
	});
}
function SceneTab({ campaign, onChange }) {
	const [threads, setThreads] = (0, import_react.useState)(campaign.threads.join("\n"));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-mist",
				children: formatClock(campaign.clock)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Lugar de la escena",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "rf-field",
					value: campaign.scene.place,
					onChange: (event) => onChange({
						...campaign,
						scene: {
							...campaign.scene,
							place: event.target.value
						}
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Atmósfera",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "rf-field",
					value: campaign.scene.atmosphere,
					onChange: (event) => onChange({
						...campaign,
						scene: {
							...campaign.scene,
							atmosphere: event.target.value
						}
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Lo que está pasando",
				hint: "El narrador lo usa como continuidad. Cámbialo si se desvió.",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: "rf-field",
					value: campaign.scene.summary,
					onChange: (event) => onChange({
						...campaign,
						scene: {
							...campaign.scene,
							summary: event.target.value
						}
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium",
					children: "En este lugar"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "flex flex-wrap gap-2",
					children: [campaign.scene.present.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "text-sm text-mist",
						children: "Nadie, todavía."
					}) : null, campaign.scene.present.map((name) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "rounded-full bg-soot px-3 py-1 text-sm text-parchment",
						children: name
					}, name))]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Hilos abiertos",
				hint: "Uno por línea.",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: "rf-field",
					value: threads,
					onChange: (event) => setThreads(event.target.value),
					onBlur: () => onChange({
						...campaign,
						threads: threads.split("\n").map((line) => line.trim()).filter(Boolean).slice(0, 6)
					})
				})
			})
		]
	});
}
function PeopleTab({ campaign, onChange }) {
	const [openId, setOpenId] = (0, import_react.useState)(null);
	const updateCast = (cast) => onChange({
		...campaign,
		cast
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "grid gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-serif text-xl",
					children: "Tu personaje"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-mist",
					children: [
						"Solo tú hablas y actúas por ",
						campaign.oc.name || "tu OC",
						"."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Nombre",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "rf-field",
						value: campaign.oc.name,
						onChange: (event) => onChange({
							...campaign,
							oc: {
								...campaign.oc,
								name: event.target.value
							}
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Pronombres",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "rf-field",
						value: campaign.oc.pronouns,
						onChange: (event) => onChange({
							...campaign,
							oc: {
								...campaign.oc,
								pronouns: event.target.value
							}
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Qué busca",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: "rf-field",
						value: campaign.oc.goal,
						onChange: (event) => onChange({
							...campaign,
							oc: {
								...campaign.oc,
								goal: event.target.value
							}
						})
					})
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "grid gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-serif text-xl",
						children: "Los demás"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "quiet",
						onClick: () => {
							const next = blankCharacter({ place: campaign.scene.place });
							updateCast([...campaign.cast, next]);
							setOpenId(next.id);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
							className: "size-4",
							"aria-hidden": "true"
						}), "Alguien más"]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-mist",
					children: "La ficha es de dirección. Tu personaje no sabe un secreto hasta que la escena lo revela."
				}),
				campaign.cast.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-mist",
					children: "Aún no hay nadie más en el mundo."
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid gap-2",
					children: campaign.cast.map((character) => {
						const open = openId === character.id;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rf-card p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "flex min-h-11 w-full items-center justify-between gap-3 text-left",
								"aria-expanded": open,
								onClick: () => setOpenId(open ? null : character.id),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block font-medium",
									children: character.name || "Sin nombre"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-sm text-mist",
									children: [
										character.mood || "Sin ánimo",
										" · ",
										opinionLabel(character.opinion),
										" · ",
										character.place || "sin lugar"
									]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm text-mist",
									children: character.weight === "principal" ? "Principal" : "Menor"
								})]
							}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 grid gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetFields, {
									character,
									places: campaign.places.map((place) => place.name),
									onChange: (next) => updateCast(campaign.cast.map((item) => item.id === character.id ? next : item))
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "danger",
									onClick: () => updateCast(campaign.cast.filter((item) => item.id !== character.id)),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {
										className: "size-4",
										"aria-hidden": "true"
									}), "Quitar del mundo"]
								})]
							}) : null]
						}, character.id);
					})
				})
			]
		})]
	});
}
function SheetFields({ character, places, onChange }) {
	const text = (key, label, long = false) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
		label,
		children: long ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
			className: "rf-field",
			value: String(character[key] ?? ""),
			onChange: (event) => onChange({
				...character,
				[key]: event.target.value
			})
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			className: "rf-field",
			value: String(character[key] ?? ""),
			onChange: (event) => onChange({
				...character,
				[key]: event.target.value
			})
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-3",
		children: [
			text("name", "Nombre"),
			text("role", "Rol"),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Peso en la historia",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 gap-1 rounded-xl bg-soot p-1",
					children: ["principal", "menor"].map((weight) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-pressed": character.weight === weight,
						className: character.weight === weight ? "min-h-11 rounded-lg bg-panel-2 text-parchment" : "min-h-11 rounded-lg text-mist",
						onClick: () => onChange({
							...character,
							weight
						}),
						children: weight === "principal" ? "Principal" : "Menor"
					}, weight))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
				label: "Dónde está",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "rf-field",
					list: `places-${character.id}`,
					value: character.place,
					onChange: (event) => onChange({
						...character,
						place: event.target.value
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("datalist", {
					id: `places-${character.id}`,
					children: places.map((place) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: place }, place))
				})]
			}),
			text("mood", "Ánimo"),
			text("agenda", "Qué hace cuando no estás", true),
			text("personality", "Personalidad", true),
			text("voice", "Voz"),
			text("appearance", "Apariencia", true),
			text("knowledge", "Qué sabe", true),
			text("motivations", "Qué lo mueve", true),
			text("goal", "Objetivo ahora", true),
			text("limits", "Qué no hará", true),
			text("secret", "Secreto", true),
			text("bondNote", "Vínculo contigo", true),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-mist",
				children: [
					"Opinión sobre ti: ",
					opinionLabel(character.opinion),
					" (",
					character.opinion,
					")"
				]
			})
		]
	});
}
function MemoryTab({ campaign, onChange }) {
	const [draft, setDraft] = (0, import_react.useState)("");
	const items = [...campaign.memories].reverse();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-mist",
				children: "Hechos que el narrador debe respetar. Puedes clavar uno sin llamar a la IA."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "grid gap-2",
				onSubmit: (event) => {
					event.preventDefault();
					onChange(addManualMemory(campaign, draft));
					setDraft("");
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Hecho para recordar",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: "rf-field",
						value: draft,
						onChange: (event) => setDraft(event.target.value)
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					disabled: !draft.trim(),
					children: "Clavar en la memoria"
				})]
			}),
			items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-mist",
				children: "La memoria está en blanco."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid gap-2",
				children: items.map((memory) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rf-card flex items-start justify-between gap-3 p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-mist",
							children: memory.importance === 3 ? "Clave · " : ""
						}), memory.summary]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "inline-flex size-11 shrink-0 items-center justify-center text-mist",
						"aria-label": "Olvidar este hecho",
						onClick: () => onChange({
							...campaign,
							memories: campaign.memories.filter((item) => item.id !== memory.id)
						}),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
					})]
				}, memory.id))
			})
		]
	});
}
function ChronicleTab({ campaign }) {
	const items = [...campaign.chronicle].reverse();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-mist",
				children: "Lo que ocurre sin tu personaje. No es lo que tu OC sabe: es la vida del mundo cuando no mira."
			}),
			items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-mist",
				children: "Todavía no se ha movido nada lejos de ti."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid gap-2",
				children: items.map((event) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rf-card p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm",
						children: event.summary
					}), event.who.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-mist",
						children: event.who.join(", ")
					}) : null]
				}, event.id))
			})
		]
	});
}
function WorldTab({ campaign, onChange }) {
	const set = (patch) => onChange({
		...campaign,
		...patch
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Título",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "rf-field",
					value: campaign.title,
					onChange: (event) => set({ title: event.target.value })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Universo",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "rf-field",
					value: campaign.universe,
					onChange: (event) => set({ universe: event.target.value })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Premisa",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: "rf-field",
					value: campaign.premise,
					onChange: (event) => set({ premise: event.target.value })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Tono",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: "rf-field",
					value: campaign.tone,
					onChange: (event) => set({ tone: event.target.value })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Reglas del mundo",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: "rf-field",
					value: campaign.rules,
					onChange: (event) => set({ rules: event.target.value })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Límites",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: "rf-field",
					value: campaign.boundaries,
					onChange: (event) => set({ boundaries: event.target.value })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segmented, {
				label: "Prosa",
				value: campaign.prose,
				options: PROSE,
				onChange: (prose) => set({ prose })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segmented, {
				label: "Autonomía del mundo",
				value: campaign.autonomy,
				options: AUTONOMY,
				onChange: (autonomy) => set({ autonomy })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: "Lugares"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "ghost",
						onClick: () => set({ places: [...campaign.places, {
							id: crypto.randomUUID(),
							name: "",
							note: ""
						}] }),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
							className: "size-4",
							"aria-hidden": "true"
						}), "Lugar"]
					})]
				}), campaign.places.map((place) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "rf-field",
						"aria-label": "Nombre del lugar",
						value: place.name,
						onChange: (event) => set({ places: campaign.places.map((item) => item.id === place.id ? {
							...item,
							name: event.target.value
						} : item) })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "rf-field",
						"aria-label": "Nota del lugar",
						placeholder: "Qué se siente ahí",
						value: place.note,
						onChange: (event) => set({ places: campaign.places.map((item) => item.id === place.id ? {
							...item,
							note: event.target.value
						} : item) })
					})]
				}, place.id))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Reloj",
				hint: "Día y minuto del día, de 0 a 1439. No llama al narrador.",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "rf-field tabular-nums",
						type: "number",
						min: 1,
						"aria-label": "Día",
						value: campaign.clock.day,
						onChange: (event) => set({ clock: {
							...campaign.clock,
							day: Math.max(1, Number(event.target.value) || 1)
						} })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "rf-field tabular-nums",
						type: "number",
						min: 0,
						max: 1439,
						"aria-label": "Minuto del día",
						value: campaign.clock.minute,
						onChange: (event) => set({ clock: {
							...campaign.clock,
							minute: Math.min(1439, Math.max(0, Number(event.target.value) || 0))
						} })
					})]
				})
			})
		]
	});
}
var TABS = [
	{
		id: "escena",
		label: "Escena",
		icon: Feather
	},
	{
		id: "gente",
		label: "Gente",
		icon: Users
	},
	{
		id: "memoria",
		label: "Memoria",
		icon: BookOpen
	},
	{
		id: "cronica",
		label: "Crónica",
		icon: ScrollText
	},
	{
		id: "mundo",
		label: "Mundo",
		icon: Hourglass
	}
];
function Play({ id }) {
	const campaign = useForge((state) => state.campaigns.find((item) => item.id === id));
	const upsert = useForge((state) => state.upsert);
	const [tab, setTab] = (0, import_react.useState)("escena");
	const [mobileOpen, setMobileOpen] = (0, import_react.useState)(false);
	const [text, setText] = (0, import_react.useState)("");
	const [openingLine, setOpeningLine] = (0, import_react.useState)("");
	const [withLine, setWithLine] = (0, import_react.useState)(false);
	const [pending, setPending] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const [note, setNote] = (0, import_react.useState)(null);
	const scroller = (0, import_react.useRef)(null);
	const lock = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		const node = scroller.current;
		if (!node) return;
		node.scrollTop = node.scrollHeight;
	}, [campaign?.entries.length, pending]);
	if (!campaign) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-dvh max-w-lg flex-col justify-center gap-3 px-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-serif text-3xl",
				children: "Esta partida no está aquí"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-mist",
				children: "Solo vive en el dispositivo donde se forjó."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				className: "inline-flex min-h-11 items-center text-ember",
				children: "Volver a la biblioteca"
			})
		]
	});
	const unread = campaign.chronicle.filter((event) => !event.seen).length;
	const started = campaign.entries.length > 0;
	function selectTab(next) {
		setTab(next);
		setMobileOpen(true);
		if (next !== "cronica") return;
		const latest = useForge.getState().campaigns.find((item) => item.id === id);
		if (!latest) return;
		const seen = markChronicleSeen(latest);
		if (seen !== latest) upsert(seen);
	}
	async function run(mode, playerText) {
		if (lock.current) return;
		const latest = useForge.getState().campaigns.find((item) => item.id === id);
		if (!latest) return;
		if (mode === "turno" && !playerText.trim()) return;
		lock.current = true;
		setPending(true);
		setError(null);
		setNote(null);
		try {
			const response = await narrateTurn({ data: {
				mode,
				playerText: playerText.trim(),
				campaign: {
					...latest,
					undo: null
				}
			} });
			if (!response.ok) {
				setError(response.error);
				return;
			}
			upsert(applyNarration(latest, response.result, {
				mode,
				playerText: playerText.trim()
			}));
			if (mode === "turno") setText("");
			if (mode === "apertura") {
				setOpeningLine("");
				setWithLine(false);
			}
			if (mode === "aliento" && response.result.beats.length === 0) setNote("Pasó algo fuera de la vista de tu personaje. Está en la crónica.");
		} catch (err) {
			setError(err instanceof Error ? err.message : "No se pudo contactar al narrador.");
		} finally {
			lock.current = false;
			setPending(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-dvh flex-col bg-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center gap-1 border-b border-line pr-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					"aria-label": "Biblioteca",
					className: "inline-flex size-11 items-center justify-center text-mist",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, {
						className: "size-5",
						"aria-hidden": "true"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1 py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate font-medium",
						children: campaign.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "truncate text-sm text-mist tabular-nums",
						children: [campaign.scene.place ? `${campaign.scene.place} · ` : "", formatClock(campaign.clock)]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-h-0 flex-1 lg:grid lg:grid-cols-[minmax(0,1fr)_22rem]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "flex min-h-0 min-w-0 flex-col",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						ref: scroller,
						className: "min-h-0 flex-1 overflow-y-auto px-4 py-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto grid w-full max-w-2xl gap-6",
							children: [
								!started ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid gap-3 py-8",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-serif text-3xl text-parchment",
										children: "La historia aún no arde."
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "max-w-prose text-mist",
										children: "Encender la escena llama al narrador una sola vez. Tu personaje no hablará por su cuenta."
									})]
								}) : null,
								campaign.entries.map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TranscriptLine, {
									entry,
									ocName: campaign.oc.name
								}, entry.id)),
								pending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-mist",
									children: "El narrador escucha…"
								}) : null
							]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "rf-dock border-t border-line px-4 pt-3 lg:pb-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto grid w-full max-w-2xl gap-2",
							children: [
								error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-ember",
									role: "alert",
									children: error
								}) : null,
								note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-mist",
									children: note
								}) : null,
								!started ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid gap-2",
									children: [withLine ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
										className: "rf-field",
										maxLength: 2e3,
										placeholder: `Primer gesto de ${campaign.oc.name}`,
										value: openingLine,
										onChange: (event) => setOpeningLine(event.target.value)
									}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											disabled: pending,
											onClick: () => void run("apertura", openingLine),
											children: "Encender la escena"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											variant: "ghost",
											disabled: pending,
											onClick: () => setWithLine((value) => !value),
											children: withLine ? "Sin gesto inicial" : "Entrar con una acción"
										})]
									})]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
									className: "grid gap-2",
									onSubmit: (event) => {
										event.preventDefault();
										run("turno", text);
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "grid gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "sr-only",
											children: ["Acción o diálogo de ", campaign.oc.name]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
											className: "rf-field",
											rows: 3,
											maxLength: 2e3,
											placeholder: `Qué hace o dice ${campaign.oc.name}`,
											value: text,
											disabled: pending,
											onChange: (event) => setText(event.target.value),
											onKeyDown: (event) => {
												if (event.key === "Enter" && !event.shiftKey) {
													event.preventDefault();
													run("turno", text);
												}
											}
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap gap-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												type: "submit",
												disabled: pending || !text.trim(),
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, {
													className: "size-4",
													"aria-hidden": "true"
												}), "Decirlo"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												variant: "quiet",
												disabled: pending,
												onClick: () => void run("aliento", ""),
												children: "El mundo sigue"
											}),
											campaign.undo ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												variant: "ghost",
												disabled: pending,
												onClick: () => {
													const restored = restoreUndo(campaign);
													if (restored) upsert(restored);
												},
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Undo2, {
													className: "size-4",
													"aria-hidden": "true"
												}), "Deshacer latido"]
											}) : null
										]
									})]
								})
							]
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "hidden min-h-0 flex-col gap-4 overflow-y-auto border-l border-line px-4 py-4 lg:flex",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabRow, {
						tab,
						unread,
						onSelect: selectTab
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dossier, {
						campaign,
						tab,
						onChange: upsert
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "rf-nav fixed inset-x-0 bottom-0 z-10 grid grid-cols-5 border-t border-line bg-ink lg:hidden",
				children: TABS.map((item) => {
					const Icon = item.icon;
					const active = mobileOpen && tab === item.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: active ? "flex min-h-12 flex-col items-center justify-center text-ember" : "flex min-h-12 flex-col items-center justify-center text-mist",
						onClick: () => active ? setMobileOpen(false) : selectTab(item.id),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: "size-5",
								"aria-hidden": "true"
							}), item.id === "cronica" && unread > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute -top-1 -right-2 size-2 rounded-full bg-ember" }) : null]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs",
							children: item.label
						})]
					}, item.id);
				})
			}),
			mobileOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-20 overflow-y-auto bg-ink px-4 pt-3 pb-8 lg:hidden",
				role: "dialog",
				"aria-modal": "true",
				"aria-label": tab,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-serif text-2xl capitalize",
						children: tab
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "inline-flex size-11 items-center justify-center",
						"aria-label": "Cerrar",
						onClick: () => setMobileOpen(false),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dossier, {
					campaign,
					tab,
					onChange: upsert
				})]
			}) : null
		]
	});
}
function TabRow({ tab, unread, onSelect }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-wrap gap-1",
		children: TABS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			"aria-pressed": tab === item.id,
			className: tab === item.id ? "min-h-11 rounded-full bg-panel-2 px-3 text-sm text-parchment" : "min-h-11 rounded-full px-3 text-sm text-mist",
			onClick: () => onSelect(item.id),
			children: [item.label, item.id === "cronica" && unread > 0 ? ` · ${unread}` : ""]
		}, item.id))
	});
}
function TranscriptLine({ entry, ocName }) {
	if (entry.kind === "jugador") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "ml-auto max-w-[92%] text-right",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-ember",
			children: ocName
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-serif text-lg leading-relaxed text-parchment",
			children: entry.text
		})]
	});
	if (entry.kind === "dialogo") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "max-w-[92%]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-ember",
			children: entry.speaker
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-serif text-lg leading-relaxed text-parchment",
			children: entry.text
		})]
	});
	if (entry.kind === "aparte") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "max-w-prose",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-mist",
			children: "Llega de forma indirecta"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-serif text-lg leading-relaxed text-mist italic",
			children: entry.text
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "max-w-prose font-serif text-lg leading-relaxed text-parchment",
		children: entry.text
	});
}
function PartidaRoute() {
	const { id } = Route.useParams();
	if (!useHydrated()) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "flex min-h-dvh items-center px-5",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "font-serif text-3xl",
			children: ["Role", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-ember",
				children: "forge"
			})]
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { id });
}
//#endregion
export { PartidaRoute as component };
