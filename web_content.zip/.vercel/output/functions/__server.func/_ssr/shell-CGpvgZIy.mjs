import { i as __toESM } from "../_runtime.mjs";
import { _ as require_react, g as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { b as Link, p as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as Award, S as ChartColumn, T as BookOpen, a as Sparkles, d as PanelLeftClose, h as LayoutDashboard, i as Sun, m as LifeBuoy, n as Users, o as Settings, p as Moon, t as X, u as PanelLeftOpen, v as History, w as CalendarCheck } from "../_libs/lucide-react.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { a as DialogOverlay, i as DialogDescription, n as DialogClose, o as DialogPortal, r as DialogContent, s as DialogTitle, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shell-CGpvgZIy.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var MONTHS = [
	"January",
	"February",
	"March",
	"April",
	"May",
	"June",
	"July",
	"August",
	"September",
	"October",
	"November",
	"December"
];
var WEEKDAYS = [
	"Sunday",
	"Monday",
	"Tuesday",
	"Wednesday",
	"Thursday",
	"Friday",
	"Saturday"
];
function utcTodayIso(now = /* @__PURE__ */ new Date()) {
	return now.toISOString().slice(0, 10);
}
function addDays(iso, days) {
	const [y, m, d] = iso.split("-").map(Number);
	const dt = new Date(Date.UTC(y, m - 1, d));
	dt.setUTCDate(dt.getUTCDate() + days);
	return dt.toISOString().slice(0, 10);
}
function nextWeekdayOnOrAfter(target, today = utcTodayIso()) {
	const [y, m, d] = today.split("-").map(Number);
	return addDays(today, (target - new Date(Date.UTC(y, m - 1, d)).getUTCDay() + 7) % 7);
}
function weekdayName(iso) {
	const [y, m, d] = iso.split("-").map(Number);
	return WEEKDAYS[new Date(Date.UTC(y, m - 1, d)).getUTCDay()] ?? "";
}
function formatLong(iso) {
	const [y, m, d] = iso.split("-").map(Number);
	return `${weekdayName(iso)}, ${MONTHS[m - 1]} ${d}, ${y}`;
}
function formatShort(iso) {
	const [, m, d] = iso.split("-").map(Number);
	return `${MONTHS[m - 1].slice(0, 3)} ${d}`;
}
function weekLabelFor(meetingDate) {
	const [y, m, d] = meetingDate.split("-").map(Number);
	const start = addDays(meetingDate, -((new Date(Date.UTC(y, m - 1, d)).getUTCDay() + 6) % 7));
	const end = addDays(start, 6);
	const [sy, sm, sd] = start.split("-").map(Number);
	const [ey, em, ed] = end.split("-").map(Number);
	if (sm === em) return `${MONTHS[sm - 1]} ${sd}–${ed}`;
	if (sy === ey) return `${MONTHS[sm - 1]} ${sd} – ${MONTHS[em - 1]} ${ed}`;
	return `${MONTHS[sm - 1]} ${sd}, ${sy} – ${MONTHS[em - 1]} ${ed}, ${ey}`;
}
function formatTime(hm) {
	const [hRaw, minRaw] = hm.split(":");
	const h = Number(hRaw);
	const min = Number(minRaw);
	const suffix = h >= 12 ? "p.m." : "a.m.";
	return `${h % 12 || 12}:${String(min).padStart(2, "0")} ${suffix}`;
}
function addMinutes(hm, mins) {
	const [h, m] = hm.split(":").map(Number);
	const total = h * 60 + m + mins;
	const hh = (Math.floor(total / 60) % 24 + 24) % 24;
	const mm = (total % 60 + 60) % 60;
	return `${String(hh).padStart(2, "0")}:${String(mm).padStart(2, "0")}`;
}
function partStatus(date, assigneeId, today) {
	if (!assigneeId) return "unassigned";
	return date < today ? "completed" : "pending";
}
function fullName(member) {
	return `${member.firstName} ${member.lastName}`;
}
function initials(member) {
	return `${member.firstName.charAt(0)}${member.lastName.charAt(0)}`.toUpperCase();
}
function privilegeLabel(privilege) {
	if (privilege === "elder") return "Elder";
	if (privilege === "servant") return "Ministerial servant";
	if (privilege === "unbaptized") return "Unbaptized publisher";
	return "Publisher";
}
function statusLabel(status) {
	if (status === "completed") return "Completed";
	if (status === "pending") return "Pending";
	return "Unassigned";
}
var SKILL_META = {
	chairman: {
		label: "Chairman",
		group: "Platform",
		blurb: "Presides, offers opening comments, and keeps the meeting on time."
	},
	prayer: {
		label: "Prayer",
		group: "Platform",
		blurb: "Opening or closing prayer."
	},
	treasures: {
		label: "Treasures talk",
		group: "Treasures",
		blurb: "Ten-minute talk from the week’s Bible reading."
	},
	gems: {
		label: "Spiritual gems",
		group: "Treasures",
		blurb: "Questions, comments, and gems from the reading."
	},
	reading: {
		label: "Bible reading",
		group: "Treasures",
		blurb: "Four-minute reading, clear and unhurried."
	},
	initial: {
		label: "Starting a conversation",
		group: "Ministry",
		blurb: "Student part for the initial conversation."
	},
	return: {
		label: "Following up",
		group: "Ministry",
		blurb: "Student part for a return visit."
	},
	study: {
		label: "Making disciples",
		group: "Ministry",
		blurb: "Student part for a Bible study demonstration."
	},
	talk: {
		label: "Student talk",
		group: "Ministry",
		blurb: "Short student talk from the platform."
	},
	assistant: {
		label: "Assistant",
		group: "Ministry",
		blurb: "Householder or partner for a student assignment."
	},
	living: {
		label: "Living as Christians",
		group: "Living",
		blurb: "Talk or discussion that applies the week’s theme."
	},
	cbs: {
		label: "Bible study conductor",
		group: "Living",
		blurb: "Conducts the Congregation Bible study."
	},
	reader: {
		label: "Bible study reader",
		group: "Living",
		blurb: "Reads the study paragraphs."
	}
};
function avatarTone(id) {
	const n = [...id].reduce((sum, ch) => sum + ch.charCodeAt(0), 0);
	const tones = [
		"bg-sidebar text-on-navy",
		"bg-royal text-on-royal",
		"bg-cyan text-sidebar"
	];
	return tones[n % tones.length] ?? tones[0];
}
var buttonVariants = {
	primary: "bg-royal text-on-royal shadow-card hover:brightness-110",
	navy: "bg-sidebar text-on-navy hover:bg-sidebar-2",
	ghost: "bg-transparent text-ink hover:bg-soft",
	soft: "bg-soft text-ink hover:bg-line",
	danger: "bg-danger/10 text-danger hover:bg-danger/15"
};
function Button({ variant = "primary", static: isStatic, className, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: cn("tap inline-flex h-11 items-center justify-center gap-2 rounded-full px-4 text-sm font-semibold", "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan focus-visible:ring-offset-2 focus-visible:ring-offset-canvas", "disabled:opacity-50", !isStatic && "active:scale-[0.96]", buttonVariants[variant], className),
		...props
	});
}
function Card({ className, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: cn("min-w-0 max-w-full rounded-3xl border border-line bg-card shadow-card", className),
		children
	});
}
function Avatar({ member, size = "md" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("grid shrink-0 place-items-center rounded-2xl font-semibold", size === "lg" ? "size-14 text-lg" : size === "sm" ? "size-8 text-xs" : "size-10 text-sm", avatarTone(member.id)),
		"aria-hidden": true,
		children: initials(member)
	});
}
function StatusPill({ status }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: cn("inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-semibold", {
			completed: "bg-good-soft text-good",
			pending: "bg-royal/10 text-royal",
			unassigned: "bg-warn-soft text-warn"
		}[status]),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("size-1.5 rounded-full", status === "completed" && "bg-good", status === "pending" && "bg-royal", status === "unassigned" && "bg-warn"),
			"aria-hidden": true
		}), statusLabel(status)]
	});
}
function PageIntro({ eyebrow, title, lede, actions }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "mb-6 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-2xl",
			children: [
				eyebrow ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 text-xs font-semibold tracking-[0.16em] text-royal uppercase",
					children: eyebrow
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-3xl text-ink sm:text-4xl",
					children: title
				}),
				lede ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted sm:text-base",
					children: lede
				}) : null
			]
		}), actions ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-wrap gap-2",
			children: actions
		}) : null]
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block text-sm font-medium text-ink",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-1.5 block",
			children: label
		}), children]
	});
}
var fieldClass = "h-11 w-full rounded-2xl border border-line bg-canvas px-3 text-sm text-ink outline-none transition focus:border-royal focus:ring-4 focus:ring-royal/15";
function Modal({ open, onOpenChange, title, description, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-50 bg-sidebar/55 backdrop-blur-sm" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "fixed top-1/2 left-1/2 z-50 max-h-[min(88dvh,820px)] w-[min(100%-1.5rem,36rem)] -translate-x-1/2 -translate-y-1/2 overflow-y-auto rounded-3xl border border-line bg-card p-5 shadow-lift sm:p-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex items-start justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
					className: "font-display text-2xl text-ink",
					children: title
				}), description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
					className: "mt-1 text-sm text-muted",
					children: description
				}) : null] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
					className: "tap grid size-10 place-items-center rounded-full text-muted hover:bg-soft hover:text-ink",
					"aria-label": "Close",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
				})]
			}), children]
		})] })
	});
}
function skillOf(member, skill) {
	return member.skills[skill] ?? 0;
}
function loadOf(history, memberId) {
	return history.reduce((total, assignment) => {
		const primary = assignment.assigneeId === memberId ? 1 : 0;
		const assist = assignment.assistantId === memberId ? .4 : 0;
		return total + primary + assist;
	}, 0);
}
function isEligible(member, slot) {
	if (slot.used.has(member.id)) return false;
	if (member.availability === "away") return false;
	if (member.awayDates.includes(slot.date)) return false;
	if (slot.who === "brother" && member.gender !== "brother") return false;
	if (!slot.allowUnbaptized && member.privilege === "unbaptized") return false;
	if (skillOf(member, slot.skill) < 45) return false;
	return true;
}
function rankFor(members, slot) {
	const ranked = [];
	for (const member of members) {
		if (!isEligible(member, slot)) continue;
		const skill = skillOf(member, slot.skill);
		const load = loadOf(slot.history, member.id);
		let score = skill - load * 12;
		if (member.availability === "limited") score -= 7;
		if (slot.preferElder && member.privilege === "elder") score += 16;
		if (slot.preferElder && member.privilege !== "elder") score -= 4;
		const label = SKILL_META[slot.skill].label.toLowerCase();
		const loadNote = load < .5 ? "No recent parts, which keeps the schedule fair." : load < 2 ? "A light recent schedule." : "Capable, though they have carried more parts lately.";
		const elderNote = slot.preferElder && member.privilege === "elder" ? " An elder is preferred here." : "";
		ranked.push({
			member,
			score,
			reason: `${fullName(member)} is rated ${Math.round(skill)} for ${label}. ${loadNote}${elderNote}`
		});
	}
	ranked.sort((a, b) => b.score - a.score || a.member.lastName.localeCompare(b.member.lastName) || a.member.firstName.localeCompare(b.member.firstName));
	return ranked;
}
function place(meetingId, date, draft, members, history, made, used, preset) {
	const prior = [...history, ...made];
	let assignee = preset?.assignee ?? null;
	let assistant = preset?.assistant ?? null;
	let reason = preset?.reason?.trim() ?? "";
	if (assignee && !isEligible(assignee, {
		date,
		skill: draft.skill,
		who: draft.who,
		allowUnbaptized: draft.allowUnbaptized,
		used
	})) {
		assignee = null;
		assistant = null;
		reason = "";
	}
	if (!assignee) {
		const ranked = rankFor(members, {
			date,
			skill: draft.skill,
			who: draft.who,
			allowUnbaptized: draft.allowUnbaptized,
			preferElder: draft.preferElder,
			used,
			history: prior
		});
		assignee = ranked[0]?.member ?? null;
		reason = ranked[0]?.reason ?? "No qualified publisher is available for this part.";
	} else if (!reason) reason = `${fullName(assignee)} is a strong fit for ${draft.title}.`;
	if (assignee) used.add(assignee.id);
	if (draft.needsAssistant && draft.assistantSkill) {
		if (assistant && !isEligible(assistant, {
			date,
			skill: draft.assistantSkill,
			who: draft.assistantWho,
			allowUnbaptized: draft.assistantAllowUnbaptized,
			used
		})) assistant = null;
		if (!assistant) assistant = rankFor(members, {
			date,
			skill: draft.assistantSkill,
			who: draft.assistantWho,
			allowUnbaptized: draft.assistantAllowUnbaptized,
			preferElder: false,
			used,
			history: prior
		})[0]?.member ?? null;
		if (assistant) {
			used.add(assistant.id);
			if (!reason.includes(fullName(assistant))) reason = `${reason} Assistant: ${fullName(assistant)}.`;
		} else if (assignee) reason = `${reason} An assistant is still needed.`;
	} else assistant = null;
	return {
		...draft,
		id: `${meetingId}-${draft.order}`,
		meetingId,
		assigneeId: assignee?.id ?? null,
		assistantId: assistant?.id ?? null,
		reason
	};
}
function arrangeParts(meetingId, date, drafts, members, history, picks = []) {
	const byName = new Map(members.map((member) => [fullName(member).toLowerCase(), member]));
	const pickById = new Map(picks.map((pick) => [pick.partId, pick]));
	const used = /* @__PURE__ */ new Set();
	const made = [];
	for (const draft of [...drafts].sort((a, b) => a.order - b.order)) {
		const id = `${meetingId}-${draft.order}`;
		const pick = pickById.get(id);
		const preset = pick ? {
			assignee: byName.get(pick.assignee.trim().toLowerCase()) ?? null,
			assistant: pick.assistant ? byName.get(pick.assistant.trim().toLowerCase()) ?? null : null,
			reason: pick.reason
		} : void 0;
		made.push(place(meetingId, date, draft, members, history, made, used, preset));
	}
	return made;
}
function toDraft(assignment) {
	const { id: _id, meetingId: _meetingId, assigneeId: _assigneeId, assistantId: _assistantId, reason: _reason, ...draft } = assignment;
	return draft;
}
function nextReplacement(assignment, date, members, meetingAssignments, history, slot) {
	if (slot === "assistant" && !assignment.assistantSkill) return null;
	const used = /* @__PURE__ */ new Set();
	for (const item of meetingAssignments) {
		if (item.assigneeId) used.add(item.assigneeId);
		if (item.assistantId) used.add(item.assistantId);
	}
	const current = slot === "assignee" ? assignment.assigneeId : assignment.assistantId;
	if (current) used.delete(current);
	const top = rankFor(members, {
		date,
		skill: slot === "assignee" ? assignment.skill : assignment.assistantSkill,
		who: slot === "assignee" ? assignment.who : assignment.assistantWho,
		allowUnbaptized: slot === "assignee" ? assignment.allowUnbaptized : assignment.assistantAllowUnbaptized,
		preferElder: slot === "assignee" ? assignment.preferElder : false,
		used,
		history
	}).filter((row) => row.member.id !== current)[0];
	if (!top) return null;
	return {
		id: top.member.id,
		reason: top.reason
	};
}
var WEEKS = [
	{
		theme: "Let Your Light Shine",
		reading: "Matthew 5:14–16",
		songs: [
			51,
			65,
			78
		],
		summary: "A simple week on letting quiet, steady faith be visible.",
		treasuresTitle: "A lamp is not hidden",
		treasuresDetail: "Matthew 5:14, 15 — why a disciple does not conceal what they have learned.",
		gemsDetail: "Gems in Matthew 5:16. How does good conduct open a conversation?",
		ministry: [
			{
				title: "Starting a conversation",
				detail: "Offer a thought from Matthew 5:14 to a neighbour.",
				durationMin: 3,
				skill: "initial"
			},
			{
				title: "Following up",
				detail: "Return to someone who enjoyed a verse about hope.",
				durationMin: 4,
				skill: "return"
			},
			{
				title: "Making disciples",
				detail: "Study how Jesus’ disciples let their light shine.",
				durationMin: 5,
				skill: "study"
			}
		],
		livingTitle: "Light that does not draw attention to us",
		livingDetail: "A practical discussion for the workplace and the family.",
		livingDuration: 15,
		cbsDetail: "Congregation Bible study. Conductor and reader."
	},
	{
		theme: "The Peace of God",
		reading: "Philippians 4:4–9",
		songs: [
			3,
			40,
			109
		],
		summary: "Joy, prayer, and the peace that guards heart and mind.",
		treasuresTitle: "Rejoice in the Lord always",
		treasuresDetail: "Philippians 4:4 — joy that does not depend on the week going well.",
		gemsDetail: "Gems in Philippians 4:6, 7. What does it mean for peace to guard us?",
		ministry: [
			{
				title: "Starting a conversation",
				detail: "Share a scripture that has brought you calm.",
				durationMin: 3,
				skill: "initial"
			},
			{
				title: "Following up",
				detail: "Show how prayer can be part of an ordinary day.",
				durationMin: 4,
				skill: "return"
			},
			{
				title: "Student talk",
				detail: "“The peace of God” — a short, warm talk.",
				durationMin: 5,
				skill: "talk"
			}
		],
		livingTitle: "Guarding heart and mind",
		livingDetail: "What we rehearse, watch, and pray about during a hard week.",
		livingDuration: 15,
		cbsDetail: "Congregation Bible study on prayer and peace of mind."
	},
	{
		theme: "Faithful in Little",
		reading: "Luke 16:10–12",
		songs: [
			22,
			88,
			134
		],
		summary: "Small assignments are where reliability is proved.",
		treasuresTitle: "Faithful with a very little",
		treasuresDetail: "Luke 16:10 — why the small part on the programme matters.",
		gemsDetail: "Gems in Luke 16:11, 12. What “true riches” are in view?",
		ministry: [
			{
				title: "Starting a conversation",
				detail: "A brief, sincere introduction at the door.",
				durationMin: 3,
				skill: "initial"
			},
			{
				title: "Following up",
				detail: "Build on a conversation about honesty.",
				durationMin: 4,
				skill: "return"
			},
			{
				title: "Making disciples",
				detail: "Help a student see the value of small acts of faith.",
				durationMin: 5,
				skill: "study"
			}
		],
		livingTitle: "Reliable in the assignments no one applauds",
		livingDetail: "Preparation, punctuality, and a willing spirit.",
		livingDuration: 15,
		cbsDetail: "Congregation Bible study. Keep the paragraphs moving."
	},
	{
		theme: "Love Builds Up",
		reading: "1 Corinthians 8:1–3",
		songs: [
			12,
			97,
			141
		],
		summary: "Knowledge is useful. Love is what builds the congregation.",
		treasuresTitle: "Knowledge puffs up, love builds up",
		treasuresDetail: "1 Corinthians 8:1 — how to handle what we know with tenderness.",
		gemsDetail: "Gems in 1 Corinthians 8:2, 3. Who is “known by God”?",
		ministry: [
			{
				title: "Starting a conversation",
				detail: "Begin with kindness rather than a correction.",
				durationMin: 3,
				skill: "initial"
			},
			{
				title: "Following up",
				detail: "Continue a conversation without pressing.",
				durationMin: 4,
				skill: "return"
			},
			{
				title: "Student talk",
				detail: "“Love that leaves room for a person to grow.”",
				durationMin: 5,
				skill: "talk"
			}
		],
		livingTitle: "Speech that builds the congregation",
		livingDetail: "Comments, counsel, and everyday conversation.",
		livingDuration: 15,
		cbsDetail: "Congregation Bible study emphasizing application."
	},
	{
		theme: "Walk Worthily",
		reading: "Ephesians 4:1–6",
		songs: [
			15,
			58,
			127
		],
		summary: "Humility, patience, and the unity the meeting should feel.",
		treasuresTitle: "Walk worthy of the calling",
		treasuresDetail: "Ephesians 4:1, 2 — humility and patience as a way of walking.",
		gemsDetail: "Gems in Ephesians 4:3–6. What holds a congregation together?",
		ministry: [
			{
				title: "Starting a conversation",
				detail: "Invite someone to consider a life of peace.",
				durationMin: 3,
				skill: "initial"
			},
			{
				title: "Following up",
				detail: "Review a scripture about patience.",
				durationMin: 4,
				skill: "return"
			},
			{
				title: "Making disciples",
				detail: "A calm Bible study on unity in the home.",
				durationMin: 5,
				skill: "study"
			}
		],
		livingTitle: "Making room for one another",
		livingDetail: "How the midweek meeting trains us to be lowly of mind.",
		livingDuration: 15,
		cbsDetail: "Congregation Bible study. Leave time for comments."
	},
	{
		theme: "A Gentle Answer",
		reading: "Proverbs 15:1–4",
		songs: [
			33,
			72,
			118
		],
		summary: "Tone matters as much as the point we are making.",
		treasuresTitle: "A gentle answer turns away rage",
		treasuresDetail: "Proverbs 15:1 — the ministry begins with the sound of our voice.",
		gemsDetail: "Gems in Proverbs 15:2–4. The tongue that heals.",
		ministry: [
			{
				title: "Starting a conversation",
				detail: "Answer a sharp remark without matching it.",
				durationMin: 3,
				skill: "initial"
			},
			{
				title: "Following up",
				detail: "Return with a softer, clearer explanation.",
				durationMin: 4,
				skill: "return"
			},
			{
				title: "Student talk",
				detail: "“Words that heal” from Proverbs 15:4.",
				durationMin: 5,
				skill: "talk"
			}
		],
		livingTitle: "The tone of our comments",
		livingDetail: "At the meeting, in the car, and at home afterward.",
		livingDuration: 15,
		cbsDetail: "Congregation Bible study conducted at a gentle pace."
	},
	{
		theme: "Hope That Does Not Disappoint",
		reading: "Romans 5:1–5",
		songs: [
			8,
			45,
			101
		],
		summary: "Endurance, approved character, and a hope we can explain.",
		treasuresTitle: "We have been declared righteous",
		treasuresDetail: "Romans 5:1, 2 — peace with God and the hope we stand in.",
		gemsDetail: "Gems in Romans 5:3–5. Why can tribulation produce hope?",
		ministry: [
			{
				title: "Starting a conversation",
				detail: "Offer a reason for hope to someone who is tired.",
				durationMin: 3,
				skill: "initial"
			},
			{
				title: "Following up",
				detail: "Share how endurance has shaped your faith.",
				durationMin: 4,
				skill: "return"
			},
			{
				title: "Making disciples",
				detail: "Study Romans 5:5 and the love of God.",
				durationMin: 5,
				skill: "study"
			}
		],
		livingTitle: "When the week has been heavy",
		livingDetail: "A congregation discussion on endurance without complaint.",
		livingDuration: 15,
		cbsDetail: "Congregation Bible study. Reader keeps a steady pace."
	},
	{
		theme: "Serve with a Complete Heart",
		reading: "1 Chronicles 28:9, 10",
		songs: [
			28,
			81,
			136
		],
		summary: "A willing heart is the qualification that matters most.",
		treasuresTitle: "Serve Him with a complete heart",
		treasuresDetail: "1 Chronicles 28:9 — devotion that Jehovah sees before the assignment does.",
		gemsDetail: "Gems in 1 Chronicles 28:10. “Be courageous and act.”",
		ministry: [
			{
				title: "Starting a conversation",
				detail: "Speak from conviction, not from a script only.",
				durationMin: 3,
				skill: "initial"
			},
			{
				title: "Following up",
				detail: "Help someone see that willingness matters.",
				durationMin: 4,
				skill: "return"
			},
			{
				title: "Student talk",
				detail: "“A complete heart in a small assignment.”",
				durationMin: 5,
				skill: "talk"
			}
		],
		livingTitle: "Courage to accept the next part",
		livingDetail: "Encouragement for newer publishers and students.",
		livingDuration: 15,
		cbsDetail: "Congregation Bible study to close the month."
	}
];
function member(id, firstName, lastName, gender, privilege, availability, phone, note, skills) {
	return {
		id,
		firstName,
		lastName,
		gender,
		privilege,
		availability,
		awayDates: [],
		phone,
		note,
		skills
	};
}
function baseMembers() {
	return [
		member("m-daniel", "Daniel", "Okonkwo", "brother", "elder", "available", "(555) 013-2044", "Coordinator. Steady with treasures talks and the Bible study.", {
			chairman: 96,
			prayer: 92,
			treasures: 94,
			gems: 93,
			reading: 88,
			living: 90,
			cbs: 96,
			reader: 86
		}),
		member("m-marcus", "Marcus", "Hale", "brother", "elder", "available", "(555) 014-1180", "Gives clear spiritual gems and is glad to take prayer.", {
			chairman: 90,
			prayer: 94,
			treasures: 88,
			gems: 95,
			reading: 84,
			living: 86,
			cbs: 91,
			reader: 80
		}),
		member("m-caleb", "Caleb", "Mensah", "brother", "elder", "limited", "(555) 010-7742", "Shift work some weeks. Excellent Bible study conductor.", {
			chairman: 88,
			prayer: 86,
			treasures: 90,
			gems: 84,
			reading: 82,
			living: 89,
			cbs: 93,
			reader: 78
		}),
		member("m-joel", "Joel", "Adeyemi", "brother", "servant", "available", "(555) 017-3308", "Ministerial servant. Reliable chairman when an elder is away.", {
			chairman: 78,
			prayer: 84,
			treasures: 80,
			gems: 74,
			reading: 86,
			living: 82,
			reader: 88,
			talk: 70
		}),
		member("m-james", "James", "Whitfield", "brother", "servant", "available", "(555) 016-2291", "Strong reader. Enjoys helping students prepare.", {
			prayer: 76,
			reading: 93,
			living: 72,
			reader: 90,
			initial: 68,
			return: 66,
			assistant: 74,
			talk: 71
		}),
		member("m-elijah", "Elijah", "Brooks", "brother", "publisher", "available", "(555) 015-8820", "Baptized last year. Growing quickly in student parts.", {
			prayer: 62,
			reading: 84,
			initial: 80,
			return: 77,
			study: 70,
			talk: 74,
			assistant: 76,
			reader: 68
		}),
		member("m-samuel", "Samuel", "Park", "brother", "publisher", "available", "(555) 012-4409", "Prefer midweek student parts to public talks for now.", {
			reading: 79,
			initial: 74,
			return: 73,
			study: 69,
			assistant: 71,
			prayer: 58
		}),
		member("m-noah", "Noah", "Clarke", "brother", "unbaptized", "available", "(555) 018-9055", "Unbaptized publisher. Ready for the Bible reading and student parts.", {
			reading: 76,
			initial: 72,
			return: 60,
			assistant: 82
		}),
		member("m-owen", "Owen", "Reid", "brother", "publisher", "away", "(555) 011-6627", "Visiting family through the end of the month.", {
			reading: 70,
			prayer: 64,
			initial: 66,
			return: 64,
			talk: 60,
			assistant: 63
		}),
		member("m-grace", "Grace", "Okonkwo", "sister", "publisher", "available", "(555) 013-7781", "Natural assistant. Students ask her to practice with them.", {
			initial: 88,
			return: 86,
			study: 90,
			assistant: 95,
			talk: 70
		}),
		member("m-hannah", "Hannah", "Brooks", "sister", "publisher", "available", "(555) 014-6620", "Excellent Bible study demonstrations.", {
			initial: 78,
			return: 84,
			study: 93,
			assistant: 86,
			talk: 68
		}),
		member("m-amelia", "Amelia", "Chen", "sister", "publisher", "available", "(555) 019-2214", "Warm initial conversations. Happy to assist.", {
			initial: 90,
			return: 76,
			study: 72,
			assistant: 88
		}),
		member("m-sofia", "Sofia", "Alvarez", "sister", "publisher", "limited", "(555) 010-3488", "Available most weeks, traveling one Wednesday a month.", {
			initial: 74,
			return: 80,
			study: 77,
			assistant: 83,
			talk: 64
		}),
		member("m-ruth", "Ruth", "Adeyemi", "sister", "publisher", "available", "(555) 017-1194", "Kind householder. Newer to giving the student part herself.", {
			initial: 62,
			return: 66,
			assistant: 91,
			study: 60
		}),
		member("m-miriam", "Miriam", "Hale", "sister", "publisher", "available", "(555) 016-5502", "Reliable partner for return visits.", {
			initial: 70,
			return: 88,
			study: 75,
			assistant: 89
		}),
		member("m-leah", "Leah", "Park", "sister", "unbaptized", "available", "(555) 012-7730", "Unbaptized publisher. Enjoys assisting her brother.", {
			initial: 64,
			assistant: 80,
			return: 55
		}),
		member("m-esther", "Esther", "Mensah", "sister", "publisher", "available", "(555) 018-4416", "Away the first week of the new schedule for a family appointment.", {
			initial: 81,
			return: 79,
			study: 84,
			assistant: 77,
			talk: 66
		}),
		member("m-naomi", "Naomi", "Whitfield", "sister", "publisher", "available", "(555) 015-2088", "Thoughtful student talks when the part calls for one.", {
			initial: 73,
			return: 75,
			study: 80,
			talk: 86,
			assistant: 78
		})
	];
}
function draftPart(order, section, title, detail, durationMin, skill, who, allowUnbaptized, preferElder, needsAssistant, assistantSkill, assistantWho, assistantAllowUnbaptized) {
	return {
		order,
		section,
		title,
		detail,
		durationMin,
		skill,
		who,
		allowUnbaptized,
		preferElder,
		needsAssistant,
		assistantSkill,
		assistantWho,
		assistantAllowUnbaptized
	};
}
function draftsFor(week) {
	const [first, second, third] = week.ministry;
	return [
		draftPart(1, "opening", "Chairman and opening comments", "Preside, introduce the theme, and keep each part on time.", 3, "chairman", "brother", false, true, false, null, "any", true),
		draftPart(2, "treasures", week.treasuresTitle, week.treasuresDetail, 10, "treasures", "brother", false, true, false, null, "any", true),
		draftPart(3, "treasures", "Spiritual gems", week.gemsDetail, 10, "gems", "brother", false, true, false, null, "any", true),
		draftPart(4, "treasures", "Bible reading", week.reading, 4, "reading", "brother", true, false, false, null, "any", true),
		draftPart(5, "ministry", first.title, first.detail, first.durationMin, first.skill, "any", true, false, true, "assistant", "any", true),
		draftPart(6, "ministry", second.title, second.detail, second.durationMin, second.skill, "any", true, false, true, "assistant", "any", true),
		draftPart(7, "ministry", third.title, third.detail, third.durationMin, third.skill, third.skill === "talk" ? "any" : "any", true, false, third.skill !== "talk", third.skill === "talk" ? null : "assistant", "any", true),
		draftPart(8, "living", week.livingTitle, week.livingDetail, week.livingDuration, "living", "brother", false, false, false, null, "any", true),
		draftPart(9, "living", "Congregation Bible study", week.cbsDetail, 30, "cbs", "brother", false, true, true, "reader", "brother", false),
		draftPart(10, "closing", "Closing prayer", "A brief prayer after the concluding song.", 3, "prayer", "brother", false, false, false, null, "any", true)
	];
}
function buildDemo(today = utcTodayIso()) {
	const upcoming = nextWeekdayOnOrAfter(3, today);
	const dates = [
		-4,
		-3,
		-2,
		-1,
		0,
		1,
		2,
		3
	].map((offset) => addDays(upcoming, offset * 7));
	const members = baseMembers();
	const esther = members.find((item) => item.id === "m-esther");
	const caleb = members.find((item) => item.id === "m-caleb");
	const sofia = members.find((item) => item.id === "m-sofia");
	if (esther) esther.awayDates = [dates[4]];
	if (caleb) caleb.awayDates = [dates[4], dates[6]];
	if (sofia) sofia.awayDates = [dates[5]];
	const meetings = dates.map((date, index) => {
		const week = WEEKS[index] ?? WEEKS[0];
		return {
			id: `meet-${date}`,
			date,
			theme: week.theme,
			reading: week.reading,
			songs: week.songs,
			weekLabel: weekLabelFor(date),
			summary: week.summary
		};
	});
	let history = [];
	const assignments = [];
	dates.forEach((date, index) => {
		const week = WEEKS[index] ?? WEEKS[0];
		const arranged = arrangeParts(`meet-${date}`, date, draftsFor(week), members, history);
		if (index < 4) {
			history = history.concat(arranged);
			assignments.push(...arranged);
			return;
		}
		if (index === 4) {
			const opened = arranged.map((assignment) => {
				if (assignment.order === 6 || assignment.order === 7 || assignment.order === 9) return {
					...assignment,
					assigneeId: null,
					assistantId: null,
					reason: "Still open. Arrange with AI or choose a publisher."
				};
				return assignment;
			});
			assignments.push(...opened);
			history = history.concat(opened);
			return;
		}
		assignments.push(...arranged.map((assignment) => ({
			...toDraft(assignment),
			id: assignment.id,
			meetingId: assignment.meetingId,
			assigneeId: null,
			assistantId: null,
			reason: "Not arranged yet."
		})));
	});
	return {
		congregation: "Northside Congregation",
		meetingTime: "19:00",
		meetingWeekday: "Wednesday",
		members,
		meetings,
		assignments,
		activities: [
			{
				id: "act-1",
				at: `${dates[3]}T23:10:00.000Z`,
				title: "Midweek meeting completed",
				detail: `${WEEKS[3].theme} is now in the assignment record.`,
				tone: "done"
			},
			{
				id: "act-2",
				at: `${dates[4]}T13:00:00.000Z`,
				title: "Workbook week is ready",
				detail: `${meetings[4]?.weekLabel} · ${WEEKS[4].theme}. Three parts are still open.`,
				tone: "edit"
			},
			{
				id: "act-3",
				at: `${addDays(dates[4], -1)}T16:20:00.000Z`,
				title: "Availability updated",
				detail: "Esther Mensah is away for the coming meeting. Caleb Mensah is away that week as well.",
				tone: "member"
			},
			{
				id: "act-4",
				at: `${addDays(dates[4], -2)}T18:05:00.000Z`,
				title: "Treasures talk confirmed",
				detail: "A brother is in place for the treasures talk. Ministry parts still need students.",
				tone: "ai"
			}
		]
	};
}
var demo = buildDemo();
function activity(partial) {
	return {
		id: `act-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`,
		at: partial.at ?? (/* @__PURE__ */ new Date()).toISOString(),
		title: partial.title,
		detail: partial.detail,
		tone: partial.tone
	};
}
var useMinistry = create()(persist((set) => ({
	...demo,
	theme: "light",
	collapsed: false,
	arrangeRequested: false,
	focusMeetingId: null,
	lastArrangement: null,
	setTheme: (theme) => set({ theme }),
	toggleCollapsed: () => set((state) => ({ collapsed: !state.collapsed })),
	requestArrange: () => set({ arrangeRequested: true }),
	focusMeeting: (id) => set({ focusMeetingId: id }),
	updateSettings: (patch) => set((state) => ({
		congregation: patch.congregation?.trim() || state.congregation,
		meetingTime: patch.meetingTime || state.meetingTime,
		activities: [activity({
			title: "Settings saved",
			detail: "Congregation details were updated.",
			tone: "edit"
		}), ...state.activities].slice(0, 24)
	})),
	addActivity: (item) => set((state) => ({ activities: [activity(item), ...state.activities].slice(0, 24) })),
	saveMember: (member) => set((state) => {
		const exists = state.members.some((item) => item.id === member.id);
		return {
			members: exists ? state.members.map((item) => item.id === member.id ? member : item) : [member, ...state.members],
			activities: [activity({
				title: exists ? "Member updated" : "Member added",
				detail: fullName(member),
				tone: "member"
			}), ...state.activities].slice(0, 24)
		};
	}),
	removeMember: (id) => set((state) => {
		const person = state.members.find((item) => item.id === id);
		return {
			members: state.members.filter((item) => item.id !== id),
			assignments: state.assignments.map((assignment) => ({
				...assignment,
				assigneeId: assignment.assigneeId === id ? null : assignment.assigneeId,
				assistantId: assignment.assistantId === id ? null : assignment.assistantId,
				reason: assignment.assigneeId === id || assignment.assistantId === id ? "Opened because the publisher was removed." : assignment.reason
			})),
			activities: person ? [activity({
				title: "Member removed",
				detail: `${fullName(person)} was taken off the roster. Their open parts were cleared.`,
				tone: "member"
			}), ...state.activities].slice(0, 24) : state.activities
		};
	}),
	toggleAway: (memberId, date) => set((state) => ({ members: state.members.map((member) => {
		if (member.id !== memberId) return member;
		const away = member.awayDates.includes(date) ? member.awayDates.filter((item) => item !== date) : [...member.awayDates, date];
		return {
			...member,
			awayDates: away
		};
	}) })),
	setAvailability: (memberId, availability) => set((state) => ({ members: state.members.map((member) => member.id === memberId ? {
		...member,
		availability
	} : member) })),
	setSkill: (memberId, skill, value) => set((state) => ({ members: state.members.map((member) => member.id === memberId ? {
		...member,
		skills: {
			...member.skills,
			[skill]: value
		}
	} : member) })),
	applyMeeting: (meetingId, next, note) => set((state) => ({
		assignments: [...state.assignments.filter((item) => item.meetingId !== meetingId), ...next].sort((a, b) => a.meetingId.localeCompare(b.meetingId) || a.order - b.order),
		lastArrangement: note,
		activities: note ? [activity({
			title: note.source === "grok" ? "AI arrangement applied" : "Arrangement applied",
			detail: note.summary,
			tone: "ai"
		}), ...state.activities].slice(0, 24) : state.activities
	})),
	patchAssignment: (id, patch, item) => set((state) => ({
		assignments: state.assignments.map((assignment) => assignment.id === id ? {
			...assignment,
			...patch
		} : assignment),
		activities: item ? [activity(item), ...state.activities].slice(0, 24) : state.activities
	})),
	resetDemo: () => set((state) => ({
		...buildDemo(),
		theme: state.theme,
		collapsed: state.collapsed,
		arrangeRequested: false,
		focusMeetingId: null,
		lastArrangement: null
	}))
}), {
	name: "ministryflow",
	storage: createJSONStorage(() => localStorage),
	skipHydration: true,
	partialize: (state) => ({
		congregation: state.congregation,
		meetingTime: state.meetingTime,
		meetingWeekday: state.meetingWeekday,
		theme: state.theme,
		collapsed: state.collapsed,
		members: state.members,
		meetings: state.meetings,
		assignments: state.assignments,
		activities: state.activities,
		lastArrangement: state.lastArrangement
	})
}));
function blankMember() {
	return {
		id: `m-${Date.now().toString(36)}`,
		firstName: "",
		lastName: "",
		gender: "brother",
		privilege: "publisher",
		availability: "available",
		awayDates: [],
		skills: {
			reading: 60,
			initial: 60,
			assistant: 60
		},
		phone: "",
		note: ""
	};
}
var NAV = [
	{
		to: "/",
		label: "Dashboard",
		icon: LayoutDashboard,
		mobile: "Dashboard"
	},
	{
		to: "/planner",
		label: "AI Meeting Planner",
		icon: Sparkles,
		mobile: "Planner"
	},
	{
		to: "/workbook",
		label: "JW Workbook",
		icon: BookOpen,
		mobile: "Workbook"
	},
	{
		to: "/members",
		label: "Members",
		icon: Users,
		mobile: "Members"
	},
	{
		to: "/skills",
		label: "Abilities & Skills",
		icon: Award,
		mobile: null
	},
	{
		to: "/history",
		label: "Assignment History",
		icon: History,
		mobile: null
	},
	{
		to: "/availability",
		label: "Availability",
		icon: CalendarCheck,
		mobile: null
	},
	{
		to: "/reports",
		label: "Reports",
		icon: ChartColumn,
		mobile: null
	},
	{
		to: "/help",
		label: "Help Centre",
		icon: LifeBuoy,
		mobile: null
	},
	{
		to: "/settings",
		label: "Settings",
		icon: Settings,
		mobile: null
	}
];
function isActive(pathname, to) {
	if (to === "/") return pathname === "/";
	return pathname === to || pathname.startsWith(`${to}/`);
}
function AppShell({ children }) {
	const pathname = useRouterState({ select: (state) => state.location.pathname });
	const collapsed = useMinistry((state) => state.collapsed);
	const toggleCollapsed = useMinistry((state) => state.toggleCollapsed);
	const congregation = useMinistry((state) => state.congregation);
	const meetingTime = useMinistry((state) => state.meetingTime);
	const meetingWeekday = useMinistry((state) => state.meetingWeekday);
	const theme = useMinistry((state) => state.theme);
	const setTheme = useMinistry((state) => state.setTheme);
	const [more, setMore] = (0, import_react.useState)(false);
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const pending = useMinistry.persist.rehydrate();
		Promise.resolve(pending).finally(() => setReady(true));
	}, []);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		document.documentElement.classList.toggle("dark", theme === "dark");
	}, [ready, theme]);
	(0, import_react.useEffect)(() => {
		setMore(false);
	}, [pathname]);
	const page = NAV.find((item) => isActive(pathname, item.to));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-canvas text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: cn("fixed inset-y-0 left-0 z-30 hidden flex-col bg-sidebar text-on-navy transition-[width] duration-200 ease-out lg:flex", collapsed ? "w-[92px]" : "w-[272px]"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: cn("flex items-center gap-3 px-4 pt-6", collapsed && "justify-center px-3"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-11 shrink-0 place-items-center rounded-2xl bg-cyan font-display text-xl text-sidebar",
							children: "M"
						}), collapsed ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block font-display text-xl leading-none",
								children: "MinistryFlow"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-1 inline-flex rounded-full bg-cyan/15 px-2 py-0.5 text-[10px] font-semibold tracking-[0.14em] text-cyan uppercase",
								children: "AI"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "mt-8 flex-1 space-y-1 overflow-y-auto px-3",
						"aria-label": "Primary",
						children: NAV.map((item) => {
							const active = isActive(pathname, item.to);
							const Icon = item.icon;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: item.to,
								title: item.label,
								className: cn("tap flex h-11 items-center gap-3 rounded-2xl px-3 text-sm font-medium text-on-navy/75 transition-colors hover:bg-on-navy/8 hover:text-on-navy", active && "bg-on-navy/12 text-on-navy shadow-[inset_3px_0_0_0_var(--color-cyan)]", collapsed && "justify-center px-0"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
									className: cn("size-5 shrink-0", active && "text-cyan"),
									strokeWidth: 1.75
								}), collapsed ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "truncate",
									children: item.label
								})]
							}, item.to);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: toggleCollapsed,
						className: "tap m-3 flex h-11 items-center justify-center gap-2 rounded-2xl text-sm text-on-navy/70 hover:bg-on-navy/8 hover:text-on-navy",
						children: [collapsed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PanelLeftOpen, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PanelLeftClose, { className: "size-5" }), collapsed ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Collapse" })]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("transition-[padding] duration-200 ease-out", collapsed ? "lg:pl-[92px]" : "lg:pl-[272px]"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
					className: "sticky top-0 z-20 border-b border-line/80 bg-canvas/80 backdrop-blur-xl",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto flex h-16 max-w-6xl items-center justify-between gap-3 px-4 sm:px-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-sm font-semibold text-ink",
								children: page?.label ?? "MinistryFlow"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "truncate text-xs text-muted",
								children: [
									congregation,
									" · ",
									meetingWeekday,
									" ",
									formatTime(meetingTime)
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setTheme(theme === "dark" ? "light" : "dark"),
							className: "tap grid size-11 place-items-center rounded-full border border-line bg-card text-ink shadow-card",
							"aria-label": theme === "dark" ? "Switch to light mode" : "Switch to dark mode",
							children: theme === "dark" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "size-4" })
						})]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "mx-auto w-full max-w-6xl px-4 pt-6 pb-28 sm:px-6 lg:pb-12",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "rise-in min-w-0",
						children
					}, pathname)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-40 border-t border-line bg-card/90 px-1 pt-1 backdrop-blur-xl lg:hidden",
				style: { paddingBottom: "max(0.4rem, env(safe-area-inset-bottom))" },
				"aria-label": "Mobile",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "grid grid-cols-5",
					children: [NAV.filter((item) => item.mobile).map((item) => {
						const active = isActive(pathname, item.to);
						const Icon = item.icon;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: item.to,
							className: cn("flex min-h-14 flex-col items-center justify-center gap-1 rounded-2xl text-[11px] font-medium", active ? "text-royal" : "text-muted"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: "size-5",
								strokeWidth: 1.75
							}), item.mobile]
						}) }, item.to);
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setMore(true),
						className: "flex min-h-14 w-full flex-col items-center justify-center gap-1 rounded-2xl text-[11px] font-medium text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, {
							className: "size-5",
							strokeWidth: 1.75
						}), "More"]
					}) })]
				})
			}),
			more ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-50 lg:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "absolute inset-0 bg-sidebar/55",
					"aria-label": "Close menu",
					onClick: () => setMore(false)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute inset-x-0 bottom-0 rounded-t-3xl border border-line bg-card p-4 shadow-lift",
					style: { paddingBottom: "max(1.25rem, env(safe-area-inset-bottom))" },
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-2xl",
							children: "More"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "grid size-10 place-items-center rounded-full hover:bg-soft",
							onClick: () => setMore(false),
							"aria-label": "Close",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-2",
						children: NAV.filter((item) => !item.mobile).map((item) => {
							const Icon = item.icon;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: item.to,
								className: "flex h-14 items-center gap-3 rounded-2xl bg-soft px-3 text-sm font-medium",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4 text-royal" }), item.label]
							}, item.to);
						})
					})]
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				theme,
				position: "top-center"
			})
		]
	});
}
//#endregion
export { privilegeLabel as C, utcTodayIso as E, partStatus as S, useMinistry as T, formatTime as _, Field as a, loadOf as b, SKILL_META as c, arrangeParts as d, blankMember as f, formatShort as g, formatLong as h, Card as i, StatusPill as l, fieldClass as m, Avatar as n, Modal as o, cn as p, Button as r, PageIntro as s, AppShell as t, addMinutes as u, fullName as v, toDraft as w, nextReplacement as x, isEligible as y };
