//#region node_modules/.nitro/vite/services/ssr/assets/calc-DDlXNlj6.js
function toNumber(value, fallback = 0) {
	if (typeof value === "number" && Number.isFinite(value)) return value;
	if (typeof value === "string" && value.trim()) {
		const n = Number(value);
		if (Number.isFinite(n)) return n;
	}
	return fallback;
}
function mentionFromAverage(average) {
	if (average >= 16) return {
		mention: "امتياز",
		decision: "ناجح",
		tone: "excellence"
	};
	if (average >= 14) return {
		mention: "جيد جداً",
		decision: "ناجح",
		tone: "very-good"
	};
	if (average >= 12) return {
		mention: "جيد",
		decision: "ناجح",
		tone: "good"
	};
	if (average >= 10) return {
		mention: "قريب من الجيد",
		decision: "ناجح",
		tone: "fair"
	};
	return {
		mention: "بدون تقدير",
		decision: "راسب",
		tone: "fail"
	};
}
function formatScore(value) {
	if (value == null || Number.isNaN(value)) return "—";
	return value.toFixed(2);
}
function formatPercent(value) {
	return `${value.toFixed(1)}٪`;
}
function fullName(lastName, firstName) {
	return `${lastName} ${firstName}`.trim();
}
function genderLabel(gender) {
	return gender === "female" ? "أنثى" : "ذكر";
}
function candidateNoun(gender) {
	return gender === "female" ? "المترشحة" : "المترشح";
}
//#endregion
export { genderLabel as a, fullName as i, formatPercent as n, mentionFromAverage as o, formatScore as r, toNumber as s, candidateNoun as t };
