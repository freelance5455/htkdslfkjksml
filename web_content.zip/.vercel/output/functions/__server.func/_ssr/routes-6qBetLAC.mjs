import { i as __toESM } from "../_runtime.mjs";
import { G as require_jsx_runtime, K as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Shield, c as Pause, l as Crosshair, n as Volume2, o as RotateCcw, r as Trophy, s as Play, t as VolumeX } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-6qBetLAC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var BUILDINGS = [
	{
		x: -16,
		z: -8,
		hw: 5.2,
		hd: 4.2,
		h: 6.2,
		wall: "#ffc857",
		roof: "#e07a3d"
	},
	{
		x: 15,
		z: -15,
		hw: 6.2,
		hd: 4.4,
		h: 4.6,
		wall: "#2ec4b6",
		roof: "#146870"
	},
	{
		x: 12,
		z: 13,
		hw: 4.6,
		hd: 5.4,
		h: 5.4,
		wall: "#ff6b6b",
		roof: "#c43b4a"
	},
	{
		x: -15,
		z: 13,
		hw: 6.4,
		hd: 4.2,
		h: 4.2,
		wall: "#7c6bf0",
		roof: "#3d348b"
	},
	{
		x: 0,
		z: -20,
		hw: 3.3,
		hd: 3.3,
		h: 12,
		wall: "#ff8c42",
		roof: "#ffd166"
	},
	{
		x: 22,
		z: 1,
		hw: 3.4,
		hd: 3.6,
		h: 3.4,
		wall: "#7dce6a",
		roof: "#2f7a38"
	},
	{
		x: -4,
		z: 1,
		hw: 2.6,
		hd: 2.6,
		h: 3.1,
		wall: "#f4e1c1",
		roof: "#c4894f"
	},
	{
		x: 6,
		z: -6,
		hw: 2.2,
		hd: 2.4,
		h: 2.6,
		wall: "#f2d0a9",
		roof: "#bc6c25"
	}
];
var CRATES = [
	{
		x: 3.2,
		z: 7.2,
		hw: .7,
		hd: .7,
		h: 1.15,
		wall: "#c9854a",
		roof: "#a86b32",
		crate: true
	},
	{
		x: 4.6,
		z: 7.4,
		hw: .55,
		hd: .55,
		h: .9,
		wall: "#b87333",
		roof: "#8c5a2b",
		crate: true
	},
	{
		x: 3.6,
		z: 8.6,
		hw: .5,
		hd: .5,
		h: .85,
		wall: "#d8a15d",
		roof: "#a86b32",
		crate: true
	},
	{
		x: -8,
		z: -16,
		hw: .8,
		hd: .8,
		h: 1.2,
		wall: "#c9854a",
		roof: "#8c5a2b",
		crate: true
	},
	{
		x: 18,
		z: 10,
		hw: .7,
		hd: .7,
		h: 1.1,
		wall: "#b87333",
		roof: "#8c5a2b",
		crate: true
	}
];
var BLOCKS = [...BUILDINGS, ...CRATES];
var INF_SPAWNS = [
	[-24, -2],
	[19, -4],
	[-22, 4],
	[8, 22],
	[0, -10],
	[10, -22],
	[-9, -22],
	[27, -10]
];
var TANK_SPAWNS = [
	[-22, -16],
	[20, 18],
	[-24, 8]
];
function emptyPad() {
	return {
		moveX: 0,
		moveY: 0,
		lookX: 0,
		lookY: 0,
		fire: false,
		sprint: false,
		queueEnter: false,
		queueReload: false,
		queuePause: false
	};
}
var initialHud = {
	ready: false,
	phase: "menu",
	mode: "tank",
	hp: 100,
	hpMax: 100,
	tankHp: 340,
	tankMax: 340,
	tankAlive: true,
	mag: 30,
	magMax: 30,
	reloading: false,
	cannon: 1,
	score: 0,
	best: 0,
	wave: 1,
	left: 0,
	banner: "",
	hit: 0,
	hurt: 0,
	nearTank: false,
	x: 0,
	z: 26,
	yaw: 0,
	blips: [],
	shield: 0
};
function Fortpanzer() {
	const canvasRef = (0, import_react.useRef)(null);
	const mapRef = (0, import_react.useRef)(null);
	const padRef = (0, import_react.useRef)(emptyPad());
	const apiRef = (0, import_react.useRef)(null);
	const [hud, setHud] = (0, import_react.useState)(initialHud);
	const [soundOn, setSoundOn] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		if (!canvasRef.current) return;
		let gone = false;
		let api = null;
		import("./mountGame-DxjvIgvi.mjs").then(({ mountGame }) => {
			if (gone || !canvasRef.current) return;
			api = mountGame(canvasRef.current, {
				pad: padRef.current,
				onHud: (next) => setHud({
					...next,
					blips: next.blips.slice()
				})
			});
			apiRef.current = api;
			setSoundOn(api.soundOn());
		});
		return () => {
			gone = true;
			api?.dispose();
			apiRef.current = null;
		};
	}, []);
	(0, import_react.useEffect)(() => {
		const canvas = mapRef.current;
		if (!canvas || !hud.ready || hud.phase === "menu") return;
		drawMap(canvas, hud);
	}, [hud]);
	const now = Date.now();
	const hitHot = now - hud.hit < 140;
	const hurtHot = now - hud.hurt < 320;
	const low = hud.mode === "foot" && hud.hp > 0 && hud.hp / hud.hpMax < .3;
	const playing = hud.phase === "play";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "relative h-dvh w-full overflow-hidden bg-ink text-foam select-none",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: canvasRef,
				className: "absolute inset-0 h-full w-full touch-none"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `hurt-vignette pointer-events-none absolute inset-0 transition-opacity duration-150 ${hurtHot || low ? "opacity-80" : "opacity-0"}` }),
			playing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CrosshairMark, { hot: hitHot }),
			hud.ready && hud.phase !== "menu" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hud, {
				hud,
				mapRef,
				soundOn,
				onSound: () => toggleSound(apiRef, setSoundOn),
				onPause: () => apiRef.current?.togglePause()
			}),
			playing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TouchLayer, {
				padRef,
				mode: hud.mode,
				near: hud.nearTank,
				tankAlive: hud.tankAlive
			}),
			hud.phase === "menu" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, {
				ready: hud.ready,
				best: hud.best,
				onStart: () => apiRef.current?.start(),
				soundOn,
				onSound: () => toggleSound(apiRef, setSoundOn)
			}),
			hud.phase === "pause" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Overlay, {
				kicker: "Pause",
				title: "Kurz verschnaufen",
				body: "Der Panzer wartet. Die Insel nicht lange.",
				action: "Weiter",
				icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "h-5 w-5" }),
				onAction: () => apiRef.current?.togglePause()
			}),
			hud.phase === "down" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Overlay, {
				kicker: `Welle ${hud.wave}`,
				title: "Ausgeschaltet",
				body: `Punkte ${hud.score} · Bestwert ${hud.best}`,
				action: "Nochmal",
				icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "h-5 w-5" }),
				onAction: () => apiRef.current?.start()
			})
		]
	});
}
function toggleSound(apiRef, setSoundOn) {
	const on = apiRef.current?.toggleSound();
	if (typeof on === "boolean") setSoundOn(on);
}
function Menu({ ready, best, onStart, soundOn, onSound }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "absolute inset-0 flex flex-col justify-between p-4 md:p-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start justify-between gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold tracking-widest text-sun",
				children: "INSEL-SHOOTER"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-5xl leading-none text-foam drop-shadow-md md:text-7xl",
				children: "FORTPANZER"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SoundButton, {
				on: soundOn,
				onClick: onSound
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto w-full max-w-lg rounded-3xl bg-ink/85 p-5 shadow-xl md:p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-base leading-relaxed text-foam",
					children: "Zu Fuß feuern, in den Panzer steigen, Wellen überstehen."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-4 grid gap-2 text-sm text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crosshair, { className: "h-4 w-4 text-sun" }), "WASD, Maus oder Stick. Rechtsklick ziehen zielt ohne Mausfang."]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "h-4 w-4 text-sun" }), "Im Panzer: W Gas, S zurück, A links, D rechts. E aussteigen."]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trophy, { className: "h-4 w-4 text-sun" }),
								"Bestwert ",
								best
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					disabled: !ready,
					onClick: onStart,
					className: "mt-5 flex h-14 w-full items-center justify-center rounded-2xl bg-sun text-lg font-bold text-ink disabled:opacity-60",
					children: ready ? "Start" : "Insel wird aufgebaut"
				})
			]
		})]
	});
}
function Hud({ hud, mapRef, soundOn, onSound, onPause }) {
	const hpPct = Math.max(0, Math.min(100, hud.hp / hud.hpMax * 100));
	const tankPct = Math.max(0, Math.min(100, hud.tankHp / hud.tankMax * 100));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-none absolute inset-0 p-3 md:p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-44 md:w-56",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
							label: "Leben",
							value: hpPct,
							tone: "coral",
							text: `${Math.ceil(hud.hp)}`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
								label: hud.tankAlive ? "Panzer" : "Panzer zerstört",
								value: hud.tankAlive ? tankPct : 0,
								tone: "sun",
								text: hud.tankAlive ? `${Math.ceil(hud.tankHp)}` : "—"
							})
						}),
						hud.shield > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs font-semibold text-foam",
							children: "Schutz aktiv"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
						ref: mapRef,
						width: 180,
						height: 180,
						className: "h-24 w-24 rounded-full border-2 border-foam/40 bg-ink/70 md:h-28 md:w-28"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "pointer-events-auto flex flex-col gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
							label: "Pause",
							onClick: onPause,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "h-5 w-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SoundButton, {
							on: soundOn,
							onClick: onSound
						})]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute left-1/2 top-3 -translate-x-1/2 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs font-semibold tracking-widest text-muted",
						children: ["WELLE ", hud.wave]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl leading-none text-foam",
						children: hud.score
					}),
					hud.banner && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 rounded-full bg-ink/80 px-3 py-1 text-sm font-bold text-sun",
						children: hud.banner
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute bottom-4 left-1/2 flex -translate-x-1/2 flex-col items-center gap-1",
				children: [hud.mode === "tank" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-full bg-ink/75 px-3 py-1 text-xs font-semibold text-foam",
					children: "Im Panzer · E aussteigen"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-2 w-28 overflow-hidden rounded-full bg-ink/80",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-full bg-sun",
						style: { width: `${Math.round(hud.cannon * 100)}%` }
					})
				})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "rounded-full bg-ink/75 px-3 py-1 text-xs font-semibold text-foam",
					children: [hud.reloading ? "Lädt…" : `Munition ${hud.mag}`, hud.nearTank ? " · E einsteigen" : ""]
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "hidden text-xs text-foam/80 md:block",
					children: "Linksklick Feuer · Rechtsklick ziehen zielen · Shift Sprint"
				})]
			})
		]
	});
}
function Bar({ label, value, text, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-1 flex items-center justify-between text-xs font-semibold",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-foam",
			children: text
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-2 overflow-hidden rounded-full bg-ink/80",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: tone === "sun" ? "h-full bg-sun" : "h-full bg-coral",
			style: { width: `${value}%` }
		})
	})] });
}
function CrosshairMark({ hot }) {
	const color = hot ? "bg-coral" : "bg-foam";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-none absolute left-1/2 top-1/2 h-8 w-8 -translate-x-1/2 -translate-y-1/2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `absolute left-1/2 top-0 h-2 w-0.5 -translate-x-1/2 ${color}` }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `absolute bottom-0 left-1/2 h-2 w-0.5 -translate-x-1/2 ${color}` }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `absolute left-0 top-1/2 h-0.5 w-2 -translate-y-1/2 ${color}` }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `absolute right-0 top-1/2 h-0.5 w-2 -translate-y-1/2 ${color}` })
		]
	});
}
function Overlay({ kicker, title, body, action, icon, onAction }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "absolute inset-0 flex items-center justify-center bg-ink/55 p-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-sm rounded-3xl bg-ink p-6 text-center shadow-xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold tracking-widest text-sun",
					children: kicker
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-1 font-display text-4xl text-foam",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: body
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: onAction,
					className: "mt-5 inline-flex h-12 items-center justify-center gap-2 rounded-2xl bg-sun px-6 font-bold text-ink",
					children: [icon, action]
				})
			]
		})
	});
}
function SoundButton({ on, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
		label: on ? "Ton aus" : "Ton an",
		onClick,
		children: on ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "h-5 w-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "h-5 w-5" })
	});
}
function IconButton({ label, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-label": label,
		onClick,
		className: "flex h-11 w-11 items-center justify-center rounded-2xl bg-ink/80 text-foam",
		children
	});
}
function TouchLayer({ padRef, mode, near, tankAlive }) {
	const look = (0, import_react.useRef)(null);
	const [knob, setKnob] = (0, import_react.useState)({
		x: 0,
		y: 0
	});
	const baseRef = (0, import_react.useRef)(null);
	const stickId = (0, import_react.useRef)(null);
	function setStick(clientX, clientY) {
		const base = baseRef.current;
		if (!base) return;
		const rect = base.getBoundingClientRect();
		const cx = rect.left + rect.width / 2;
		const cy = rect.top + rect.height / 2;
		let dx = clientX - cx;
		let dy = clientY - cy;
		const max = rect.width / 2;
		const mag = Math.hypot(dx, dy) || 1;
		const clamped = Math.min(mag, max);
		dx = dx / mag * clamped;
		dy = dy / mag * clamped;
		setKnob({
			x: dx,
			y: dy
		});
		const nx = dx / max;
		const ny = -dy / max;
		const m = Math.hypot(nx, ny);
		const dz = .16;
		const pad = padRef.current;
		if (!pad) return;
		if (m < dz) {
			pad.moveX = 0;
			pad.moveY = 0;
			pad.sprint = false;
		} else {
			const s = (m - dz) / .84 / m;
			pad.moveX = nx * s;
			pad.moveY = ny * s;
			pad.sprint = m > .92;
		}
	}
	function clearStick() {
		stickId.current = null;
		setKnob({
			x: 0,
			y: 0
		});
		const pad = padRef.current;
		if (!pad) return;
		pad.moveX = 0;
		pad.moveY = 0;
		pad.sprint = false;
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "touch-controls pointer-events-none absolute inset-0 md:hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-auto absolute top-0 right-0 bottom-28 left-1/2",
				onPointerDown: (e) => {
					look.current = {
						id: e.pointerId,
						x: e.clientX,
						y: e.clientY
					};
					e.currentTarget.setPointerCapture(e.pointerId);
				},
				onPointerMove: (e) => {
					if (!look.current || look.current.id !== e.pointerId || !padRef.current) return;
					padRef.current.lookX += e.clientX - look.current.x;
					padRef.current.lookY += e.clientY - look.current.y;
					look.current = {
						id: e.pointerId,
						x: e.clientX,
						y: e.clientY
					};
				},
				onPointerUp: () => {
					look.current = null;
				},
				onPointerCancel: () => {
					look.current = null;
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: baseRef,
				className: "pointer-events-auto absolute bottom-6 left-4 z-20 h-32 w-32 rounded-full border-2 border-foam/50 bg-ink/45",
				onPointerDown: (e) => {
					stickId.current = e.pointerId;
					e.currentTarget.setPointerCapture(e.pointerId);
					setStick(e.clientX, e.clientY);
				},
				onPointerMove: (e) => {
					if (stickId.current !== e.pointerId) return;
					setStick(e.clientX, e.clientY);
				},
				onPointerUp: clearStick,
				onPointerCancel: clearStick,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute left-1/2 top-1/2 h-14 w-14 rounded-full bg-foam/90",
					style: { transform: `translate(calc(-50% + ${knob.x}px), calc(-50% + ${knob.y}px))` }
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-auto absolute right-4 bottom-6 z-20 flex items-end gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoundButton, {
						label: mode === "tank" ? "Aussteigen" : near || tankAlive ? "Panzer" : "Kein Panzer",
						onPointerDown: () => {
							if (padRef.current) padRef.current.queueEnter = true;
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "h-6 w-6" })
					}), mode === "foot" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoundButton, {
						label: "Nachladen",
						onPointerDown: () => {
							if (padRef.current) padRef.current.queueReload = true;
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "h-6 w-6" })
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "Feuer",
					className: "flex h-20 w-20 items-center justify-center rounded-full bg-coral text-sm font-bold text-foam",
					onPointerDown: (e) => {
						e.currentTarget.setPointerCapture(e.pointerId);
						if (padRef.current) padRef.current.fire = true;
					},
					onPointerUp: () => {
						if (padRef.current) padRef.current.fire = false;
					},
					onPointerCancel: () => {
						if (padRef.current) padRef.current.fire = false;
					},
					children: "Feuer"
				})]
			})
		]
	});
}
function RoundButton({ label, onPointerDown, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-label": label,
		onPointerDown: (e) => {
			e.stopPropagation();
			onPointerDown();
		},
		className: "flex h-14 w-14 items-center justify-center rounded-full bg-ink/80 text-foam",
		children
	});
}
var BLIP = {
	inf: "#ff5a36",
	badtank: "#c084fc",
	tank: "#3d7eff"
};
function drawMap(canvas, hud) {
	const ctx = canvas.getContext("2d");
	if (!ctx) return;
	const w = canvas.width;
	const h = canvas.height;
	ctx.clearRect(0, 0, w, h);
	ctx.fillStyle = "#143024";
	ctx.beginPath();
	ctx.arc(w / 2, h / 2, w / 2 - 2, 0, Math.PI * 2);
	ctx.fill();
	const scale = (w / 2 - 10) / 37;
	const toX = (x) => w / 2 + x * scale;
	const toY = (z) => h / 2 + z * scale;
	ctx.fillStyle = "rgba(255,255,255,0.22)";
	for (const b of BLOCKS) {
		if (b.crate) continue;
		ctx.fillRect(toX(b.x - b.hw), toY(b.z - b.hd), b.hw * 2 * scale, b.hd * 2 * scale);
	}
	for (const blip of hud.blips) {
		ctx.fillStyle = BLIP[blip.k];
		ctx.beginPath();
		ctx.arc(toX(blip.x), toY(blip.z), blip.k === "inf" ? 3.5 : 5, 0, Math.PI * 2);
		ctx.fill();
	}
	const px = toX(hud.x);
	const py = toY(hud.z);
	ctx.fillStyle = "#ffb703";
	ctx.beginPath();
	ctx.arc(px, py, 5, 0, Math.PI * 2);
	ctx.fill();
	const fx = -Math.sin(hud.yaw);
	const fz = -Math.cos(hud.yaw);
	ctx.strokeStyle = "#f4f7fb";
	ctx.lineWidth = 2;
	ctx.beginPath();
	ctx.moveTo(px, py);
	ctx.lineTo(px + fx * 12, py + fz * 12);
	ctx.stroke();
}
var routes_exports = /* @__PURE__ */ __exportAll({ component: () => SplitComponent });
var SplitComponent = Fortpanzer;
//#endregion
export { TANK_SPAWNS as i, BLOCKS as n, INF_SPAWNS as r, routes_exports as t };
