import { o as __toESM } from "../_runtime.mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as Card } from "./card-n_ZyUc_C.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { l as listSchools, n as createSchool, t as Skeleton } from "./server-BRpT2GPU.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Button } from "./button-C0qE0jyX.mjs";
import { a as SelectTrigger, c as TableBody, d as TableHeader, f as TableRow, i as SelectItem, l as TableCell, n as Select, o as SelectValue, r as SelectContent, s as Table, t as Input, u as TableHead } from "./table-DKHBmBA9.mjs";
import { t as Label } from "./label-CPX7BiMk.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/schools-C6lnwlUb.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var WILAYAS = [
	"أدرار",
	"الشلف",
	"الأغواط",
	"أم البواقي",
	"باتنة",
	"بجاية",
	"بسكرة",
	"بشار",
	"البليدة",
	"البويرة",
	"تمنراست",
	"تبسة",
	"تلمسان",
	"تيارت",
	"تيزي وزو",
	"الجزائر",
	"الجلفة",
	"جيجل",
	"سطيف",
	"سعيدة",
	"سكيكدة",
	"سيدي بلعباس",
	"عنابة",
	"قالمة",
	"قسنطينة",
	"المدية",
	"مستغانم",
	"المسيلة",
	"معسكر",
	"ورقلة",
	"وهران",
	"البيض",
	"إليزي",
	"برج بوعريريج",
	"بومرداس",
	"الطارف",
	"تيندوف",
	"تيسمسيلت",
	"الوادي",
	"خنشلة",
	"سوق أهراس",
	"تيبازة",
	"ميلة",
	"عين الدفلى",
	"النعامة",
	"عين تموشنت",
	"غرداية",
	"غليزان"
];
function SchoolsPage() {
	const queryClient = useQueryClient();
	const [name, setName] = (0, import_react.useState)("");
	const [wilaya, setWilaya] = (0, import_react.useState)("الجزائر");
	const schoolsQuery = useQuery({
		queryKey: ["schools"],
		queryFn: () => listSchools()
	});
	const createMutation = useMutation({
		mutationFn: createSchool,
		onSuccess: () => {
			toast.success("أُضيفت الثانوية إلى السجل");
			setName("");
			queryClient.invalidateQueries({ queryKey: ["schools"] });
		},
		onError: (err) => toast.error(err.message)
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-semibold",
				children: "الثانويات"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "مرجع المؤسسات المرتبطة بملفات المترشحين حسب الولاية."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-base font-semibold",
				children: "إضافة ثانوية"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-4 grid gap-3 sm:grid-cols-[1fr_12rem_auto]",
				onSubmit: (e) => {
					e.preventDefault();
					createMutation.mutate({ data: {
						name,
						wilaya
					} });
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "school-name",
							children: "اسم الثانوية"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "school-name",
							required: true,
							minLength: 3,
							value: name,
							onChange: (e) => setName(e.target.value),
							placeholder: "ثانوية…"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "الولاية" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: wilaya,
							onValueChange: setWilaya,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: WILAYAS.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: w,
								children: w
							}, w)) })]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-end",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							className: "w-full sm:w-auto",
							disabled: createMutation.isPending,
							children: "إضافة"
						})
					})
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "overflow-hidden p-0",
				children: schoolsQuery.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-2 p-4",
					children: Array.from({ length: 5 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10" }, i))
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "الثانوية" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "الولاية" })] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: schoolsQuery.data?.map((school) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
					className: "font-medium",
					children: school.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: school.wilaya })] }, school.id)) })] })
			})
		]
	});
}
//#endregion
export { SchoolsPage as component };
