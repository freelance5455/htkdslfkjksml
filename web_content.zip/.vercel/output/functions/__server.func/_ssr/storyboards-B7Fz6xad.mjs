import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as useProjects, o as useStory, s as visibleProjects } from "./use-projects-B0rAf6PZ.mjs";
import { t as format } from "../_libs/date-fns.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/storyboards-B7Fz6xad.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Library() {
	const ready = useProjects();
	const projects = useStory((state) => state.projects);
	const pruneEmpty = useStory((state) => state.pruneEmpty);
	const remove = useStory((state) => state.remove);
	(0, import_react.useEffect)(() => {
		if (ready) pruneEmpty();
	}, [ready, pruneEmpty]);
	const list = visibleProjects(projects);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-widest text-muted uppercase",
					children: "My storyboards"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl font-medium tracking-tight",
					children: "Storyboard tersimpan"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/create",
					className: "inline-flex min-h-11 items-center rounded-md bg-accent px-4 text-sm font-medium text-accent-fg",
					children: "Create storyboard"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-xl text-sm text-muted",
				children: "Tersimpan di browser ini. Buka lagi untuk regenerate scene tanpa upload ulang."
			}),
			!ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Memuat…"
			}) : null,
			ready && list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Belum ada storyboard."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid gap-3 sm:grid-cols-2",
				children: list.map((project) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "grid gap-3 rounded-xl border border-line bg-surface p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/storyboards/$id",
						params: { id: project.id },
						className: "grid gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "frame-4-5 overflow-hidden rounded-md bg-bg",
							children: project.scenes.find((scene) => scene.imageDataUrl)?.imageDataUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: project.scenes.find((scene) => scene.imageDataUrl)?.imageDataUrl ?? "",
								alt: "",
								className: "h-full w-full object-contain"
							}) : project.refs[0] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: project.refs[0].dataUrl,
								alt: "",
								className: "h-full w-full object-contain"
							}) : null
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "grid gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium",
								children: project.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-sm text-muted",
								children: [
									project.category,
									" · ",
									project.campaign,
									" · ",
									format(project.updatedAt, "d MMM yyyy, HH:mm")
								]
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "text-left text-sm text-muted underline",
						onClick: () => remove(project.id),
						children: "Hapus"
					})]
				}, project.id))
			})
		]
	});
}
//#endregion
export { Library as component };
