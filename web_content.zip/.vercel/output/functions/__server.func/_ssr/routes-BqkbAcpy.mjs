import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { r as require_jsx_runtime, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { n as CONNECTOR_TOKEN_READY_EVENT } from "./types-D3FEuKtl.mjs";
import { i as redirectToLoginIfRequired, n as isFramed } from "./login-BxQ-E10E.mjs";
import { _ as CalendarDays, a as Search, c as NotebookPen, d as Inbox, f as FolderOpen, g as Calendar, h as Camera, i as Trash2, l as MessageCircle, m as FileText, n as Users, o as Plus, p as FolderClosed, s as Paperclip, t as X, u as MapPin, v as ArrowUp } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BqkbAcpy.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var getConnectorReadiness = createServerFn({ method: "POST" }).handler(createSsrRpc("ac303419f3bd6f94ee837f95e91005a600278deed4876cb96a25aa0d69185951"));
var READINESS_PROBE_DELAYS_MS = [
	1e3,
	2e3,
	3e3,
	5e3
];
var READINESS_PROBE_MAX_TOTAL_MS = 18e4;
function readinessProbeDelayMs(attempt) {
	return READINESS_PROBE_DELAYS_MS[Math.min(Math.max(attempt, 0), READINESS_PROBE_DELAYS_MS.length - 1)];
}
function readinessProbeExhausted(startedAtMs, nowMs) {
	return nowMs - startedAtMs >= READINESS_PROBE_MAX_TOTAL_MS;
}
var READINESS_PROBE_TIMEOUT_MS = 1e4;
function withTimeout(promise, ms) {
	return new Promise((resolve) => {
		const timer = setTimeout(() => resolve(null), ms);
		const settle = (value) => {
			clearTimeout(timer);
			resolve(value);
		};
		promise.then(settle, () => settle(null));
	});
}
async function isConnectorReady() {
	return (await withTimeout(getConnectorReadiness(), READINESS_PROBE_TIMEOUT_MS))?.ready === true;
}
/**
* While `waiting` is true (a connector call returned `pending`), probes the
* server for the connector token and calls `refetch` once it is present. The
* probe is a header check on the app's own server — it never reaches the gate.
* A `connector-token-ready` bridge event from the Grok preview chrome triggers
* `refetch` immediately. A top-level page (download/export, local dev, the
* sandbox's own `npm run preview`) is not framed by any preview, so no token
* can ever arrive: the hook reports `not_embedded` without probing. Any framed
* page probes, even when the parent origin cannot be resolved (empty referrer,
* no `ancestorOrigins`): the token comes through the preview proxy, and the
* bridge event is only the faster signal.
*/
function useRefetchWhenConnectorReady(waiting, refetch) {
	const refetchRef = (0, import_react.useRef)(refetch);
	const [timedOut, setTimedOut] = (0, import_react.useState)(false);
	const [notEmbedded, setNotEmbedded] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		refetchRef.current = refetch;
	}, [refetch]);
	(0, import_react.useEffect)(() => {
		if (!waiting) return;
		if (!isFramed()) {
			setNotEmbedded(true);
			return () => setNotEmbedded(false);
		}
		let cancelled = false;
		let refetching = false;
		let attempt = 0;
		let timer;
		const startedAt = Date.now();
		const runRefetch = async () => {
			if (refetching) return;
			refetching = true;
			try {
				await refetchRef.current();
			} catch {} finally {
				refetching = false;
			}
		};
		const schedule = () => {
			timer = setTimeout(probe, readinessProbeDelayMs(attempt));
			attempt += 1;
		};
		const probe = async () => {
			if (cancelled || readinessProbeExhausted(startedAt, Date.now())) return;
			const ready = await isConnectorReady();
			if (cancelled) return;
			if (ready) await runRefetch();
			if (!cancelled) schedule();
		};
		const onTokenReady = () => {
			runRefetch();
		};
		const deadline = setTimeout(() => {
			if (!cancelled) setTimedOut(true);
		}, READINESS_PROBE_MAX_TOTAL_MS);
		window.addEventListener(CONNECTOR_TOKEN_READY_EVENT, onTokenReady);
		schedule();
		return () => {
			cancelled = true;
			clearTimeout(deadline);
			if (timer !== void 0) clearTimeout(timer);
			window.removeEventListener(CONNECTOR_TOKEN_READY_EVENT, onTokenReady);
			setTimedOut(false);
		};
	}, [waiting]);
	if (!waiting) return "idle";
	if (notEmbedded) return "not_embedded";
	return timedOut ? "timed_out" : "waiting";
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function uid() {
	if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
	return `id_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}
var seedNotes = [{
	id: "welcome-note",
	title: "What Mira can see",
	body: "Mira uses Grok plus the Google Drive, Gmail, and Calendar connectors you enable in Grok.\n\nFrom this phone, Mira only sees files, photos, contacts, or a location you explicitly share in a message. It cannot silently read texts, call logs, or your full storage — that is a platform limit of web apps, not a missing toggle.\n\nTry: “Brief me for today” or attach a file and ask for a summary.",
	updatedAt: Date.now()
}];
var useAppStore = create()(persist((set, get) => ({
	tab: "ask",
	messages: [],
	notes: seedNotes,
	deviceFiles: [],
	draft: "",
	setTab: (tab) => set({ tab }),
	setDraft: (draft) => set({ draft }),
	addMessage: (message) => {
		const id = message.id ?? uid();
		const next = {
			id,
			role: message.role,
			content: message.content,
			sources: message.sources,
			createdAt: Date.now()
		};
		set({ messages: [...get().messages, next].slice(-60) });
		return id;
	},
	updateMessage: (id, patch) => set({ messages: get().messages.map((m) => m.id === id ? {
		...m,
		...patch
	} : m) }),
	clearChat: () => set({ messages: [] }),
	addNote: (title, body) => set({ notes: [{
		id: uid(),
		title: title.trim() || "Untitled",
		body,
		updatedAt: Date.now()
	}, ...get().notes] }),
	updateNote: (id, patch) => set({ notes: get().notes.map((n) => n.id === id ? {
		...n,
		...patch,
		title: patch.title?.trim() || n.title,
		updatedAt: Date.now()
	} : n) }),
	removeNote: (id) => set({ notes: get().notes.filter((n) => n.id !== id) }),
	addDeviceFiles: (files) => {
		const created = files.map((file) => ({
			...file,
			id: uid(),
			addedAt: Date.now()
		}));
		set({ deviceFiles: [...created, ...get().deviceFiles].slice(0, 24) });
		return created;
	},
	removeDeviceFile: (id) => set({ deviceFiles: get().deviceFiles.filter((f) => f.id !== id) })
}), {
	name: "mira-assistant-v1",
	partialize: (state) => ({
		messages: state.messages,
		notes: state.notes
	})
}));
var askMira = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("aec57251f15771aaec0c20a3ce45c971e4681551268e15917ccf6d6f7b7e1c20"));
var buttonVariants = cva("inline-flex items-center justify-center gap-2 font-medium select-none transition-[transform,opacity,background-color,box-shadow] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/40 disabled:pointer-events-none disabled:opacity-40 active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			primary: "bg-accent text-accent-fg",
			secondary: "bg-raised text-fg shadow-[var(--shadow-border)]",
			ghost: "bg-transparent text-fg hover:bg-raised",
			muted: "bg-surface text-muted"
		},
		size: {
			sm: "h-9 rounded-md px-3 text-sm",
			md: "h-11 rounded-lg px-4 text-sm",
			icon: "size-11 rounded-lg",
			pill: "h-9 rounded-full px-3.5 text-sm"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
function Badge({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center rounded-full bg-raised px-2.5 py-1 text-xs font-medium text-muted shadow-[var(--shadow-border)]", className),
		...props
	});
}
function inline(text, keyPrefix) {
	return text.split(/(\*\*[^*]+\*\*|`[^`]+`)/g).map((part, i) => {
		const key = `${keyPrefix}-${i}`;
		if (part.startsWith("**") && part.endsWith("**")) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
			className: "font-medium text-fg",
			children: part.slice(2, -2)
		}, key);
		if (part.startsWith("`") && part.endsWith("`")) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
			className: "rounded-sm bg-raised px-1 py-0.5 font-mono text-[0.85em] text-fg",
			children: part.slice(1, -1)
		}, key);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Fragment, { children: part }, key);
	});
}
function RichText({ text }) {
	const blocks = text.split(/\n{2,}/);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-3 text-[0.95rem] leading-relaxed text-fg",
		children: blocks.map((block, i) => {
			const lines = block.split("\n");
			if (lines.every((l) => /^\s*[-*]\s+/.test(l) || l.trim() === "")) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-1.5 pl-4",
				children: lines.filter((l) => l.trim()).map((line, j) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "list-disc marker:text-muted",
					children: inline(line.replace(/^\s*[-*]\s+/, ""), `${i}-${j}`)
				}, j))
			}, i);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "whitespace-pre-wrap",
				children: inline(block, String(i))
			}, i);
		})
	});
}
async function readPickedFile(file) {
	const mime = file.type || "application/octet-stream";
	if (mime.startsWith("image/")) {
		const dataUrl = await toDataUrl(file, 12e5);
		return {
			name: file.name,
			mime,
			size: file.size,
			dataUrl
		};
	}
	if (mime.startsWith("text/") || mime === "application/json" || mime === "application/csv" || /\.(md|json|csv|txt|ts|tsx|js|jsx|py|html|css)$/i.test(file.name)) {
		const text = (await file.text()).slice(0, 2e4);
		return {
			name: file.name,
			mime,
			size: file.size,
			text
		};
	}
	try {
		const text = await file.text();
		if (text && !text.includes("\0")) return {
			name: file.name,
			mime,
			size: file.size,
			text: text.slice(0, 2e4)
		};
	} catch {}
	return {
		name: file.name,
		mime,
		size: file.size
	};
}
function toDataUrl(file, maxBytes) {
	return new Promise((resolve, reject) => {
		if (file.size > maxBytes) {
			reject(/* @__PURE__ */ new Error("That image is too large. Pick one under 1 MB."));
			return;
		}
		const reader = new FileReader();
		reader.onload = () => resolve(String(reader.result ?? ""));
		reader.onerror = () => reject(/* @__PURE__ */ new Error("Could not read that file."));
		reader.readAsDataURL(file);
	});
}
async function pickContacts() {
	const nav = navigator;
	if (!nav.contacts?.select) return null;
	return (await nav.contacts.select([
		"name",
		"email",
		"tel"
	], { multiple: true })).map((row) => ({
		name: row.name?.[0],
		email: row.email?.[0],
		tel: row.tel?.[0]
	}));
}
function greeting(now = /* @__PURE__ */ new Date()) {
	const hour = now.getHours();
	if (hour < 5) return "Still up";
	if (hour < 12) return "Good morning";
	if (hour < 17) return "Good afternoon";
	if (hour < 21) return "Good evening";
	return "Good night";
}
function formatBytes(size) {
	if (size < 1024) return `${size} B`;
	if (size < 1048576) return `${Math.round(size / 1024)} KB`;
	return `${(size / 1048576).toFixed(1)} MB`;
}
function formatWhen(iso) {
	if (!iso) return void 0;
	const date = new Date(iso);
	if (Number.isNaN(date.getTime())) return iso;
	return new Intl.DateTimeFormat(void 0, {
		weekday: "short",
		month: "short",
		day: "numeric",
		hour: "numeric",
		minute: "2-digit"
	}).format(date);
}
var PROMPTS = [
	"Brief me for today",
	"What did I miss in email?",
	"Find the latest file I worked on",
	"What's free this afternoon?"
];
function ChatPane() {
	const messages = useAppStore((s) => s.messages);
	const addMessage = useAppStore((s) => s.addMessage);
	const addDeviceFiles = useAppStore((s) => s.addDeviceFiles);
	const draft = useAppStore((s) => s.draft);
	const setDraft = useAppStore((s) => s.setDraft);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [pending, setPending] = (0, import_react.useState)([]);
	const [location, setLocation] = (0, import_react.useState)(null);
	const [contacts, setContacts] = (0, import_react.useState)([]);
	const scroller = (0, import_react.useRef)(null);
	const fileRef = (0, import_react.useRef)(null);
	const photoRef = (0, import_react.useRef)(null);
	const empty = messages.length === 0;
	(0, import_react.useEffect)(() => {
		const el = scroller.current;
		if (!el) return;
		el.scrollTop = el.scrollHeight;
	}, [messages, busy]);
	async function send(text) {
		const content = (text ?? draft).trim();
		if (!content && pending.length === 0) return;
		if (busy) return;
		addMessage({
			role: "user",
			content: content || "Look at what I attached."
		});
		setDraft("");
		const attachments = pending.map((f) => ({
			name: f.name,
			mime: f.mime,
			text: f.text,
			dataUrl: f.dataUrl
		}));
		setPending([]);
		setBusy(true);
		const history = [...useAppStore.getState().messages.map((m) => ({
			role: m.role,
			content: m.content
		}))];
		try {
			const result = await askMira({ data: {
				messages: history,
				attachments: attachments.length ? attachments : void 0,
				location: location ?? void 0,
				contacts: contacts.length ? contacts : void 0,
				timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
				nowISO: (/* @__PURE__ */ new Date()).toISOString()
			} });
			if (result.loginRequired) redirectToLoginIfRequired({
				ok: false,
				data: null,
				loginRequired: true,
				loginUrl: result.loginUrl
			});
			if (!result.ok) {
				addMessage({
					role: "assistant",
					content: result.error ?? "Something went wrong. Try again."
				});
				return;
			}
			addMessage({
				role: "assistant",
				content: result.text,
				sources: result.sources
			});
			if (result.pending) toast("Still connecting to your Grok data. Ask again in a moment.");
		} catch (error) {
			addMessage({
				role: "assistant",
				content: error instanceof Error ? error.message : "Could not reach Mira. Try again."
			});
		} finally {
			setBusy(false);
			setLocation(null);
			setContacts([]);
		}
	}
	async function onFiles(list) {
		if (!list?.length) return;
		try {
			const read = await Promise.all(Array.from(list).slice(0, 4).map(readPickedFile));
			const created = addDeviceFiles(read);
			setPending((prev) => [...prev, ...created].slice(0, 6));
		} catch (error) {
			toast(error instanceof Error ? error.message : "Could not read that file.");
		}
	}
	function shareLocation() {
		if (!navigator.geolocation) {
			toast("Location is not available on this device.");
			return;
		}
		navigator.geolocation.getCurrentPosition((pos) => {
			setLocation({
				lat: pos.coords.latitude,
				lng: pos.coords.longitude
			});
			toast("Location attached to the next message.");
		}, () => toast("Location permission was denied."), {
			enableHighAccuracy: false,
			timeout: 8e3
		});
	}
	async function shareContacts() {
		try {
			const picked = await pickContacts();
			if (picked === null) {
				toast("Contact picking is not supported in this browser.");
				return;
			}
			setContacts(picked);
			toast(`${picked.length} contact${picked.length === 1 ? "" : "s"} attached.`);
		} catch {
			toast("Could not read contacts.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref: scroller,
			className: "min-h-0 flex-1 overflow-y-auto px-4 pb-4",
			children: empty ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "stagger-in mx-auto flex max-w-lg flex-col gap-6 pt-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium tracking-wide text-muted",
						children: greeting()
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display mt-2 text-[2.15rem] leading-[1.15] tracking-[-0.03em] text-fg",
						children: "What do you need from your files, mail, or day?"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-prose text-sm leading-relaxed text-muted",
						children: "Mira reads Drive, Gmail, and Calendar when those are connected in Grok. Files, photos, contacts, and location from this phone only come through if you attach them."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: PROMPTS.map((prompt) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => void send(prompt),
							className: "rounded-full bg-raised px-3.5 py-2 text-left text-sm text-fg shadow-[var(--shadow-border)] transition-transform duration-150 ease-out active:scale-[0.96]",
							children: prompt
						}, prompt))
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-lg flex-col gap-5 pt-4",
				children: [messages.map((message) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: cn("flex flex-col gap-2", message.role === "user" ? "items-end" : "items-start"),
					children: [message.role === "user" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "max-w-[88%] rounded-xl rounded-br-md bg-raised px-3.5 py-2.5 text-[0.95rem] leading-relaxed text-fg shadow-[var(--shadow-border)]",
						children: message.content
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RichText, { text: message.content }), message.sources && message.sources.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-1.5",
						children: message.sources.slice(0, 6).map((source, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, { children: [
							source.kind,
							" · ",
							source.title
						] }, `${source.title}-${i}`))
					}) : null]
				}, message.id)), busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "shimmer text-sm font-medium",
					children: "Looking through your sources…"
				}) : null]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-3 pb-2 pt-1",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-lg rounded-xl bg-surface p-2 shadow-[var(--shadow-border)]",
					children: [
						pending.length > 0 || location || contacts.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-2 flex flex-wrap gap-1.5 px-1",
							children: [
								pending.map((file) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
									className: "gap-1",
									children: [file.name, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "ml-0.5",
										"aria-label": `Remove ${file.name}`,
										onClick: () => setPending((prev) => prev.filter((f) => f.id !== file.id)),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3" })
									})]
								}, file.id)),
								location ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, { children: ["Location", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "ml-1",
									onClick: () => setLocation(null),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3" })
								})] }) : null,
								contacts.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, { children: [
									contacts.length,
									" contacts",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "ml-1",
										onClick: () => setContacts([]),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3" })
									})
								] }) : null
							]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-end gap-1.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex gap-0.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										variant: "ghost",
										size: "icon",
										className: "size-10",
										"aria-label": "Attach files",
										onClick: () => fileRef.current?.click(),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Paperclip, { className: "size-4" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										variant: "ghost",
										size: "icon",
										className: "size-10",
										"aria-label": "Take a photo",
										onClick: () => photoRef.current?.click(),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "size-4" })
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									value: draft,
									onChange: (e) => setDraft(e.target.value),
									onKeyDown: (e) => {
										if (e.key === "Enter" && !e.shiftKey) {
											e.preventDefault();
											send();
										}
									},
									rows: 1,
									placeholder: "Ask Mira…",
									className: "mb-1 max-h-32 min-h-10 flex-1 resize-none bg-transparent py-2.5 text-[0.95rem] text-fg outline-none placeholder:text-faint"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									size: "icon",
									className: "size-10 rounded-lg",
									"aria-label": "Send",
									disabled: busy || !draft.trim() && pending.length === 0,
									onClick: () => void send(),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, { className: "size-4" })
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1 px-1 pb-0.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: shareLocation,
									className: "inline-flex h-8 items-center gap-1.5 rounded-md px-2 text-xs text-muted transition-colors duration-150 hover:text-fg",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3.5" }), "Location"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => void shareContacts(),
									className: "inline-flex h-8 items-center gap-1.5 rounded-md px-2 text-xs text-muted transition-colors duration-150 hover:text-fg",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-3.5" }), "Contacts"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => fileRef.current?.click(),
									className: "inline-flex h-8 items-center gap-1.5 rounded-md px-2 text-xs text-muted transition-colors duration-150 hover:text-fg",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderOpen, { className: "size-3.5" }), "Files"]
								})
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					ref: fileRef,
					type: "file",
					multiple: true,
					className: "hidden",
					onChange: (e) => {
						onFiles(e.target.files);
						e.target.value = "";
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					ref: photoRef,
					type: "file",
					accept: "image/*",
					capture: "environment",
					className: "hidden",
					onChange: (e) => {
						onFiles(e.target.files);
						e.target.value = "";
					}
				})
			]
		})]
	});
}
var getBriefing = createServerFn({ method: "POST" }).validator((input) => input ?? {}).handler(createSsrRpc("16a5e8b6887b4e937f4d464f4d1d31bab72680bba822362be6c8750d53762ea9"));
var searchDrive = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("27ee31456390aef78aa73bd415071afea4376c89006407e34289e17cb04a8c96"));
var listDriveFolder = createServerFn({ method: "POST" }).validator((input) => input ?? {}).handler(createSsrRpc("ed18be3040306256ea0d137744126fa190e9574d1b90e77b372dc0063c2f0ba9"));
function ConnectorState({ pack, label }) {
	if (pack.pending) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "text-sm text-muted",
		children: [
			"Connecting to ",
			label.toLowerCase(),
			"…"
		]
	});
	const error = pack.error;
	if (!error && pack.ok) return null;
	const kind = error?.kind ?? "error";
	const message = error?.message ?? `Could not load ${label.toLowerCase()}.`;
	if (kind === "login") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3 rounded-xl bg-raised p-4 shadow-[var(--shadow-border)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm leading-relaxed text-fg",
			children: message
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "sm",
			className: "self-start",
			onClick: () => redirectToLoginIfRequired({
				ok: false,
				data: null,
				loginRequired: true,
				loginUrl: pack.loginUrl
			}),
			children: "Continue with Grok"
		})]
	});
	if (kind === "not_connected") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "rounded-xl bg-raised p-4 shadow-[var(--shadow-border)]",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-sm leading-relaxed text-fg",
			children: [
				"Connect ",
				label,
				" in Grok to load this here. Open your Grok connectors, grant access, then come back."
			]
		})
	});
	if (kind === "pending") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: "Connecting to your data…"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: message
	});
}
function Skeleton({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("animate-pulse rounded-md bg-raised", className),
		...props
	});
}
function Section({ icon: Icon, title, pack, empty, onAsk }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4 text-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-medium text-fg",
					children: title
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConnectorState, {
				pack,
				label: title
			}),
			pack.ok && pack.items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: empty
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-2",
				children: pack.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onAsk(item),
					className: "flex w-full flex-col gap-0.5 rounded-xl bg-raised px-4 py-3 text-left shadow-[var(--shadow-border)] transition-transform duration-150 ease-out active:scale-[0.98]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm font-medium text-fg",
						children: item.title
					}), item.subtitle || item.extra ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted",
						children: formatWhen(item.extra) ?? item.subtitle
					}) : null]
				}) }, item.id))
			})
		]
	});
}
function TodayPane() {
	const setTab = useAppStore((s) => s.setTab);
	const setDraft = useAppStore((s) => s.setDraft);
	const query = useQuery({
		queryKey: ["briefing"],
		queryFn: () => getBriefing({ data: { nowISO: (/* @__PURE__ */ new Date()).toISOString() } })
	});
	useRefetchWhenConnectorReady(Boolean(query.data?.calendar.pending || query.data?.drive.pending || query.data?.mail.pending), () => query.refetch());
	function askAbout(prefix, item) {
		setDraft(`${prefix} ${item.title}`);
		setTab("ask");
	}
	if (query.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4 px-4 pt-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-8 w-40" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-24 w-full rounded-xl" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-24 w-full rounded-xl" })
		]
	});
	if (query.isError || !query.data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "px-4 pt-6 text-sm text-muted",
		children: "Could not load today. Pull this tab again in a moment."
	});
	const data = query.data;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex w-full max-w-lg flex-col gap-8 overflow-y-auto px-4 pb-8 pt-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "stagger-in",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-muted",
					children: "Today"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display mt-1 text-3xl tracking-[-0.03em] text-fg",
					children: "Your briefing"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					"Brief me for today",
					"What's next on my calendar?",
					"Summarize new mail"
				].map((prompt) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => {
						setDraft(prompt);
						setTab("ask");
					},
					className: "rounded-full bg-raised px-3.5 py-2 text-sm text-fg shadow-[var(--shadow-border)] transition-transform duration-150 active:scale-[0.96]",
					children: prompt
				}, prompt))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
				icon: Calendar,
				title: "Calendar",
				pack: data.calendar,
				empty: "No upcoming events in the next week.",
				onAsk: (item) => askAbout("Tell me about this event:", item)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
				icon: FileText,
				title: "Recent files",
				pack: data.drive,
				empty: "No recent Drive files.",
				onAsk: (item) => askAbout("Open and summarize this file:", item)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
				icon: Inbox,
				title: "Mail",
				pack: data.mail,
				empty: "No recent mail, or Gmail is not connected yet.",
				onAsk: (item) => askAbout("Summarize this email:", item)
			})
		]
	});
}
function LibraryPane() {
	const deviceFiles = useAppStore((s) => s.deviceFiles);
	const removeDeviceFile = useAppStore((s) => s.removeDeviceFile);
	const setTab = useAppStore((s) => s.setTab);
	const setDraft = useAppStore((s) => s.setDraft);
	const [query, setQuery] = (0, import_react.useState)("");
	const [submitted, setSubmitted] = (0, import_react.useState)("");
	const folder = useQuery({
		queryKey: ["drive-root"],
		queryFn: () => listDriveFolder({ data: {} })
	});
	const search = useQuery({
		queryKey: ["drive-search", submitted],
		queryFn: () => searchDrive({ data: { query: submitted } }),
		enabled: submitted.length > 0
	});
	const pack = submitted ? search.data : folder.data;
	useRefetchWhenConnectorReady(Boolean(pack?.pending || folder.data?.pending), () => {
		folder.refetch();
		if (submitted) search.refetch();
	});
	const loading = submitted ? search.isLoading : folder.isLoading;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex w-full max-w-lg flex-col gap-6 overflow-y-auto px-4 pb-8 pt-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-muted",
					children: "Library"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display mt-1 text-3xl tracking-[-0.03em] text-fg",
					children: "Files you can reach"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-prose text-sm leading-relaxed text-muted",
					children: "Cloud files come from Google Drive through Grok. Phone files stay on this device until you attach them to a question."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex gap-2",
				onSubmit: (e) => {
					e.preventDefault();
					setSubmitted(query.trim());
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex h-11 flex-1 items-center gap-2 rounded-lg bg-raised px-3 shadow-[var(--shadow-border)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 text-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: query,
						onChange: (e) => setQuery(e.target.value),
						placeholder: "Search Drive",
						className: "h-full w-full bg-transparent text-sm text-fg outline-none placeholder:text-faint"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					size: "md",
					children: "Search"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-sm font-medium text-fg",
					children: "On this device"
				}), deviceFiles.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Nothing attached yet. Use Files or Camera in Ask to add something from this phone."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex flex-col gap-2",
					children: deviceFiles.map((file) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center gap-3 rounded-xl bg-raised px-3 py-2.5 shadow-[var(--shadow-border)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "min-w-0 flex-1 text-left",
							onClick: () => {
								setDraft(`Summarize or explain ${file.name}`);
								setTab("ask");
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-sm font-medium text-fg",
								children: file.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: formatBytes(file.size)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": `Remove ${file.name}`,
							className: "flex size-10 items-center justify-center rounded-md text-muted hover:text-fg",
							onClick: () => removeDeviceFile(file.id),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
						})]
					}, file.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-sm font-medium text-fg",
					children: submitted ? "Drive results" : "Drive"
				}), loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-16 w-full rounded-xl" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-16 w-full rounded-xl" })] }) : pack ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConnectorState, {
						pack,
						label: "Google Drive"
					}),
					pack.ok && pack.items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "No files matched."
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "flex flex-col gap-2",
						children: pack.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "flex w-full flex-col gap-0.5 rounded-xl bg-raised px-4 py-3 text-left shadow-[var(--shadow-border)] transition-transform duration-150 active:scale-[0.98]",
							onClick: () => {
								setDraft(`Read and summarize this Drive file: ${item.title}`);
								setTab("ask");
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm font-medium text-fg",
								children: item.title
							}), item.subtitle ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted",
								children: item.subtitle
							}) : null]
						}) }, item.id))
					})
				] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Open this tab from Grok to load Drive."
				})]
			})
		]
	});
}
function NotesPane() {
	const notes = useAppStore((s) => s.notes);
	const addNote = useAppStore((s) => s.addNote);
	const updateNote = useAppStore((s) => s.updateNote);
	const removeNote = useAppStore((s) => s.removeNote);
	const setTab = useAppStore((s) => s.setTab);
	const setDraft = useAppStore((s) => s.setDraft);
	const [activeId, setActiveId] = (0, import_react.useState)(notes[0]?.id ?? null);
	const active = notes.find((n) => n.id === activeId) ?? notes[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex w-full max-w-lg flex-1 flex-col gap-4 overflow-y-auto px-4 pb-8 pt-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-muted",
					children: "Notes"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display mt-1 text-3xl tracking-[-0.03em] text-fg",
					children: "Kept on this phone"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "icon",
					"aria-label": "New note",
					onClick: () => {
						addNote("New note", "");
						const latest = useAppStore.getState().notes[0];
						setActiveId(latest?.id ?? null);
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm leading-relaxed text-muted",
				children: "Notes live in this browser. They are not uploaded unless you ask Mira about one."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2 overflow-x-auto pb-1",
				children: notes.map((note) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setActiveId(note.id),
					className: note.id === active?.id ? "h-9 shrink-0 rounded-full bg-accent px-3.5 text-sm font-medium text-accent-fg" : "h-9 shrink-0 rounded-full bg-raised px-3.5 text-sm text-muted shadow-[var(--shadow-border)]",
					children: note.title || "Untitled"
				}, note.id))
			}),
			active ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-h-0 flex-1 flex-col gap-3 rounded-xl bg-raised p-3 shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: active.title,
						onChange: (e) => updateNote(active.id, { title: e.target.value }),
						className: "h-11 rounded-lg bg-surface px-3 text-base font-medium text-fg outline-none",
						placeholder: "Title"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: active.body,
						onChange: (e) => updateNote(active.id, { body: e.target.value }),
						className: "min-h-48 flex-1 resize-none rounded-lg bg-surface px-3 py-3 text-sm leading-relaxed text-fg outline-none placeholder:text-faint",
						placeholder: "Write something to keep…"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "secondary",
							className: "flex-1",
							onClick: () => {
								setDraft(`Use this note titled “${active.title}”:\n\n${active.body}`);
								setTab("ask");
							},
							children: "Ask Mira"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							"aria-label": "Delete note",
							onClick: () => {
								removeNote(active.id);
								setActiveId(useAppStore.getState().notes[0]?.id ?? null);
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
						})]
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "No notes yet."
			})
		]
	});
}
var TABS = [
	{
		id: "ask",
		label: "Ask",
		icon: MessageCircle
	},
	{
		id: "today",
		label: "Today",
		icon: CalendarDays
	},
	{
		id: "library",
		label: "Library",
		icon: FolderClosed
	},
	{
		id: "notes",
		label: "Notes",
		icon: NotebookPen
	}
];
function AppShell() {
	const tab = useAppStore((s) => s.tab);
	const setTab = useAppStore((s) => s.setTab);
	const clearChat = useAppStore((s) => s.clearChat);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex h-[100dvh] w-full max-w-lg flex-col bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center justify-between px-4 pb-2",
				style: { paddingTop: "max(0.75rem, env(safe-area-inset-top))" },
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-2xl tracking-[-0.03em] text-fg",
					children: "Mira"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: "Personal assistant"
				})] }), tab === "ask" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: clearChat,
					className: "h-10 rounded-lg px-3 text-sm text-muted transition-colors duration-150 hover:text-fg",
					children: "Clear"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-faint",
					children: "On-device + Grok"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "flex min-h-0 flex-1 flex-col overflow-hidden",
				children: [
					tab === "ask" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChatPane, {}) : null,
					tab === "today" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TodayPane, {}) : null,
					tab === "library" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LibraryPane, {}) : null,
					tab === "notes" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotesPane, {}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "grid grid-cols-4 border-t border-border bg-bg px-2 pt-1",
				style: { paddingBottom: "max(0.4rem, env(safe-area-inset-bottom))" },
				children: TABS.map((item) => {
					const Icon = item.icon;
					const active = tab === item.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setTab(item.id),
						className: cn("flex min-h-12 flex-col items-center justify-center gap-1 rounded-lg text-[0.7rem] font-medium transition-colors duration-150", active ? "text-fg" : "text-muted"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
							className: "size-5",
							strokeWidth: active ? 2.2 : 1.8
						}), item.label]
					}, item.id);
				})
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {});
}
//#endregion
export { Home as component };
