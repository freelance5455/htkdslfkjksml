import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as useVespera } from "./router-D7Hr81ml.mjs";
import { n as lessonById } from "./lessons-DkJWLy0d.mjs";
import { n as btnGhost, t as Choice } from "./ui-B4w5JSuo.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/quiz-BWajSHN3.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var QUIZ = [
	{
		prompt: "Which star is brighter?",
		options: [
			"Magnitude 3.0",
			"Magnitude 0.5",
			"They are equal — magnitude is distance"
		],
		answer: 1,
		why: "Brighter stars have smaller magnitudes. 0.5 beats 3.0 by a wide margin, about ten times the light.",
		lesson: "light"
	},
	{
		prompt: "A light-year measures…",
		options: [
			"How long a star lives",
			"How far light travels in one year",
			"The time between solstices"
		],
		answer: 1,
		why: "It is a distance: about 9.5 trillion kilometers. Stars “being light-years away” means their light is that old when it arrives.",
		lesson: "light"
	},
	{
		prompt: "You measure Polaris at 51° above the horizon. Your latitude is about…",
		options: [
			"51°N",
			"39°N",
			"51°S"
		],
		answer: 0,
		why: "North of the equator, the pole star's altitude is your latitude. London sits near 51°N, which is why the Dipper never sets there.",
		lesson: "dome"
	},
	{
		prompt: "Stars rise in the east because…",
		options: [
			"The sky is a sphere that rotates west to east",
			"Earth rotates toward the east, so the sky seems to drift west",
			"The Sun pushes the star field every evening"
		],
		answer: 1,
		why: "The ground moves east under you. The stars are effectively still, on human timescales. The drift you see is your horizon turning.",
		lesson: "dome"
	},
	{
		prompt: "A crescent moon happens because…",
		options: [
			"Earth's shadow is covering the rest",
			"You see only part of the Moon's sunlit face",
			"The Moon's own light is weaker that week"
		],
		answer: 1,
		why: "Earth's shadow is a lunar eclipse, and only at full moon. Phases are the viewing angle on a ball that is always half lit.",
		lesson: "moon"
	},
	{
		prompt: "A solar eclipse can only happen at…",
		options: [
			"Full moon",
			"First quarter",
			"New moon"
		],
		answer: 2,
		why: "The Moon has to stand between you and the Sun, which is the new-moon geometry — and it also has to cross the plane of Earth's orbit, which is why most new moons are not eclipses.",
		lesson: "moon"
	},
	{
		prompt: "Which planet can stand highest at midnight?",
		options: [
			"Mercury",
			"Venus",
			"Jupiter"
		],
		answer: 2,
		why: "Mercury and Venus stay near the Sun in our sky. Jupiter, orbiting outside Earth, can rise at sunset and ride all night when it is at opposition.",
		lesson: "worlds"
	},
	{
		prompt: "The stars of a constellation are usually…",
		options: [
			"Born together and bound by gravity into that shape",
			"At very different distances, aligned only from here",
			"Planets that settled into a picture"
		],
		answer: 1,
		why: "Orion's shoulder and Orion's belt are not neighbors. A few groups, like much of the Big Dipper, really are related — that is the exception.",
		lesson: "patterns"
	},
	{
		prompt: "Northern summer happens when…",
		options: [
			"Earth is nearest the Sun",
			"The northern hemisphere tilts toward the Sun",
			"The Sun's output peaks in June"
		],
		answer: 1,
		why: "Earth is nearest the Sun in early January. June heat is longer days and a higher noon sun, both from the 23.4° tilt.",
		lesson: "seasons"
	},
	{
		prompt: "A full moon rises around…",
		options: [
			"Sunrise",
			"Noon",
			"Sunset"
		],
		answer: 2,
		why: "Full moon means the Moon is opposite the Sun. When the Sun sets, the full moon is rising. It is up all night and sets around sunrise.",
		lesson: "moon"
	}
];
function QuizPage() {
	const setQuizBest = useVespera((s) => s.setQuizBest);
	const quizBest = useVespera((s) => s.quizBest);
	const [step, setStep] = (0, import_react.useState)(0);
	const [picked, setPicked] = (0, import_react.useState)(null);
	const [correct, setCorrect] = (0, import_react.useState)(0);
	const [misses, setMisses] = (0, import_react.useState)([]);
	const [done, setDone] = (0, import_react.useState)(false);
	const q = QUIZ[step];
	function choose(i) {
		if (picked != null || !q) return;
		setPicked(i);
		if (i === q.answer) setCorrect((c) => c + 1);
		else setMisses((m) => m.includes(q.lesson) ? m : [...m, q.lesson]);
	}
	function next() {
		if (step + 1 >= QUIZ.length) {
			setQuizBest(correct);
			setDone(true);
			return;
		}
		setStep((s) => s + 1);
		setPicked(null);
	}
	function retry() {
		setStep(0);
		setPicked(null);
		setCorrect(0);
		setMisses([]);
		setDone(false);
	}
	if (done) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs uppercase tracking-widest text-gold",
				children: "Score"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
				className: "mt-2 text-5xl text-fg tabular-nums",
				children: [
					correct,
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-faint",
						children: ["/ ", QUIZ.length]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-muted",
				children: correct >= 8 ? "You can trust yourself outside. Take the chart and check one thing tonight: where the full-ish Moon sits relative to sunset." : "A miss is a lesson you haven't worn in yet. The notes below point back at the path."
			}),
			quizBest != null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm text-faint",
				children: [
					"Best so far: ",
					quizBest,
					" / ",
					QUIZ.length
				]
			}),
			misses.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-6 space-y-2",
				children: misses.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/lessons/$id",
					params: { id },
					className: "text-gold",
					children: ["Review ", lessonById(id)?.title ?? id]
				}) }, id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: `${btnGhost} mt-8`,
				onClick: retry,
				children: "Try again"
			})
		]
	});
	if (!q) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs uppercase tracking-widest text-gold",
				children: [
					"Question ",
					step + 1,
					" of ",
					QUIZ.length
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 h-1 overflow-hidden rounded-full bg-surface-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-full bg-gold",
					style: { width: `${step / QUIZ.length * 100}%` }
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-6 text-3xl text-fg md:text-4xl",
				children: q.prompt
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 grid gap-3",
				children: q.options.map((opt, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
					selected: picked === i,
					locked: picked != null,
					correct: picked != null && i === q.answer,
					wrong: picked === i && i !== q.answer,
					onClick: () => choose(i),
					children: opt
				}, opt))
			}),
			picked != null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-fg",
					children: q.why
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: `inline-flex h-11 items-center justify-center gap-2 rounded-full bg-gold px-5 text-sm font-medium text-ink transition-colors duration-200 hover:bg-gold-2 mt-4`,
					onClick: next,
					children: step + 1 === QUIZ.length ? "See the score" : "Next"
				})]
			})
		]
	});
}
//#endregion
export { QuizPage as component };
