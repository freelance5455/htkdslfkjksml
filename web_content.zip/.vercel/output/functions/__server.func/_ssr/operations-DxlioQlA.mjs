import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as useOperations, d as softDeleteOperation, l as reverseOperation, v as useInvalidateBooks } from "./use-books-BtZpLk9U.mjs";
import { i as OP_LABELS, s as formatJalali } from "./format-c9GA3s0l.mjs";
import { i as PageHeader, r as Money, t as Badge } from "./card-Bb_-PO54.mjs";
import { t as Button } from "./button-BiViDDnZ.mjs";
import { n as Input } from "./input-CAg20-g-.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/operations-DxlioQlA.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function OperationsPage() {
	const [q, setQ] = (0, import_react.useState)("");
	const { data = [], isLoading } = useOperations({ q });
	const invalidate = useInvalidateBooks();
	async function onDelete(id, locked) {
		if (locked) {
			toast.error("روز بسته است. فقط سند اصلاحی مجاز است.");
			return;
		}
		const reason = window.prompt("دلیل حذف منطقی؟");
		if (!reason) return;
		try {
			await softDeleteOperation({ data: {
				id,
				reason
			} });
			toast.success("حذف منطقی شد. ردپا در حسابرسی باقی ماند.");
			invalidate();
		} catch (e) {
			toast.error(e instanceof Error ? e.message : "خطا");
		}
	}
	async function onReverse(id) {
		const reason = window.prompt("دلیل سند برگشتی / اصلاحی؟");
		if (!reason) return;
		try {
			const res = await reverseOperation({ data: {
				id,
				reason
			} });
			toast.success(`سند اصلاحی ${res.journalNumber} صادر شد`);
			invalidate();
		} catch (e) {
			toast.error(e instanceof Error ? e.message : "خطا");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "عملیات روزانه",
			description: "هر ردیف یک رویداد عملیاتی است. سند دوبل به‌صورت خودکار ساخته می‌شود. حذف فیزیکی وجود ندارد.",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/operations/new",
				className: "inline-flex h-11 items-center rounded-[10px] bg-gold px-4 text-sm text-navy",
				children: "عملیات جدید"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
			value: q,
			onChange: (e) => setQ(e.target.value),
			placeholder: "جستجو در شماره، شرح، شخص…",
			className: "mb-4 max-w-md"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-x-auto rounded-[24px] border border-line bg-paper",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full min-w-[720px] text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "text-xs text-muted",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 text-right font-medium",
							children: "شماره"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 text-right font-medium",
							children: "تاریخ"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 text-right font-medium",
							children: "نوع"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 text-right font-medium",
							children: "شخص"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 text-left font-medium",
							children: "مبلغ"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 text-right font-medium",
							children: "سند"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 text-right font-medium",
							children: "وضعیت"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "px-4 py-3" })
					] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					colSpan: 8,
					className: "px-4 py-10 text-center text-muted",
					children: "در حال بارگذاری…"
				}) }) : null, data.map((op) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-t border-line",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-3 font-medium text-navy",
							children: op.number
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-3",
							children: formatJalali(op.opDate)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-3",
							children: OP_LABELS[op.opType]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-3",
							children: op.partyName ?? "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-3 text-left",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
								value: op.amount,
								compact: true
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-3",
							children: op.journalNumber ?? "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
							className: "px-4 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: op.status === "posted" ? "ok" : op.status === "deleted" ? "danger" : "warn",
								children: op.status === "posted" ? "ثبت‌شده" : op.status === "deleted" ? "حذف منطقی" : "برگشت‌خورده"
							}), op.dayStatus === "closed" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: "navy",
								className: "mr-1",
								children: "روز بسته"
							}) : null]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-3",
							children: op.status === "posted" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "outline",
									onClick: () => onDelete(op.id, op.dayStatus === "closed"),
									children: "حذف"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "ghost",
									onClick: () => onReverse(op.id),
									children: "اصلاحی"
								})]
							}) : null
						})
					]
				}, op.id))] })]
			})
		})
	] });
}
//#endregion
export { OperationsPage as component };
