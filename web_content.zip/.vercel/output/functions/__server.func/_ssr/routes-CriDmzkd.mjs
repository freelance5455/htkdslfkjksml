import { i as __toESM } from "../_runtime.mjs";
import { S as require_jsx_runtime, Y as require_react, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as formatClock } from "./text-CqN-AAxZ.mjs";
import { i as PageHeader, o as useForge, r as InstallHint, s as useHydrated, t as Button } from "./ui-buLXhEze.mjs";
import { n as formatDistanceToNow, t as es } from "../_libs/date-fns.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CriDmzkd.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Library() {
	const hydrated = useHydrated();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-dvh w-full max-w-3xl flex-col gap-6 px-4 py-2 pb-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, { action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/nueva",
				className: "inline-flex min-h-11 items-center rounded-xl bg-ember px-4 text-sm font-medium text-ink",
				children: "Nueva partida"
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "max-w-xl font-serif text-4xl leading-tight text-parchment",
					children: "Tú eres una sola voz. El mundo tiene las demás."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-xl text-mist",
					children: "Interpretas a tu personaje. Los otros recuerdan, mienten y siguen con su vida cuando no estás."
				})]
			}),
			hydrated ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shelf, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-mist",
				children: "Abriendo la biblioteca…"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InstallHint, {})
		]
	});
}
function Shelf() {
	const campaigns = useForge((state) => state.campaigns);
	const remove = useForge((state) => state.remove);
	const [armed, setArmed] = (0, import_react.useState)(null);
	const ordered = [...campaigns].sort((a, b) => b.updatedAt - a.updatedAt);
	if (ordered.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rf-card grid gap-3 p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-serif text-2xl",
				children: "Aún no hay partidas"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-mist",
				children: "Forja un mundo en este dispositivo. Cada partida se guarda aquí, no en una cuenta."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/nueva",
				className: "inline-flex min-h-11 w-fit items-center text-ember",
				children: "Empezar una forja"
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "grid gap-3",
		children: ordered.map((campaign) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "rf-card grid gap-3 p-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/partida/$id",
				params: { id: campaign.id },
				className: "grid gap-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl",
						children: campaign.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-ember",
						children: campaign.universe || "Sin universo"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "line-clamp-3 text-sm text-parchment",
						children: campaign.scene.summary || "La primera escena todavía no se ha encendido."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-mist tabular-nums",
						children: [
							formatClock(campaign.clock),
							" · ",
							formatDistanceToNow(campaign.updatedAt, {
								addSuffix: true,
								locale: es
							})
						]
					})
				]
			}), armed === campaign.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "danger",
					onClick: () => remove(campaign.id),
					children: "Borrar de este dispositivo"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					onClick: () => setArmed(null),
					children: "Conservar"
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				className: "w-fit px-0",
				onClick: () => setArmed(campaign.id),
				children: "Borrar"
			})]
		}, campaign.id))
	});
}
var SplitComponent = Library;
//#endregion
export { SplitComponent as component };
