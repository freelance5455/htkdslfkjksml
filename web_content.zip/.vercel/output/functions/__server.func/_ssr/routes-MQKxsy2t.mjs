import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Plus, c as Check, i as RotateCcw, o as Moon, r as Timer, s as Dumbbell, t as X } from "../_libs/lucide-react.mjs";
import { a as startOfWeek, i as isSameDay, n as parseISO, o as addDays, r as format, t as tr } from "../_libs/date-fns.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-MQKxsy2t.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function vibrate(pattern = 12) {
	if (typeof navigator !== "undefined" && typeof navigator.vibrate === "function") navigator.vibrate(pattern);
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 font-medium select-none transition-[transform,background-color,color,opacity] duration-150 ease-out focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary disabled:pointer-events-none disabled:opacity-40 active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			primary: "bg-primary text-primary-fg hover:bg-primary/90",
			secondary: "bg-raised text-fg shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]",
			ghost: "text-muted hover:text-fg hover:bg-raised",
			danger: "bg-danger text-fg"
		},
		size: {
			md: "h-11 px-5 rounded-lg text-sm",
			lg: "h-12 w-full rounded-xl px-6 text-base",
			icon: "size-11 rounded-lg",
			pill: "h-9 px-3 rounded-full text-xs tracking-wide"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
function emptySets(session, lastWeight, lastReps) {
	const sets = {};
	for (const ex of session.exercises) sets[ex.id] = Array.from({ length: ex.sets }, () => ({
		weight: lastWeight[ex.id] ?? "",
		reps: lastReps[ex.id] ?? "",
		done: false
	}));
	return sets;
}
function createLog(date, session, lastWeight, lastReps) {
	return {
		date,
		kind: session.kind,
		active: false,
		completed: false,
		cardioDone: false,
		sets: emptySets(session, lastWeight, lastReps)
	};
}
function shouldRest(session, exerciseId, index) {
	const ex = session.exercises.find((e) => e.id === exerciseId);
	if (!ex) return false;
	return index < ex.sets - 1;
}
var useGymStore = create()(persist((set, get) => ({
	logs: {},
	lastWeight: {},
	lastReps: {},
	variants: {},
	restTimer: null,
	ensureLog: (date, session) => {
		const existing = get().logs[date];
		if (existing && existing.kind === session.kind) return existing;
		const created = createLog(date, session, get().lastWeight, get().lastReps);
		set((s) => ({ logs: {
			...s.logs,
			[date]: created
		} }));
		return created;
	},
	startSession: (date, session) => {
		const log = get().logs[date] ?? createLog(date, session, get().lastWeight, get().lastReps);
		set((s) => ({ logs: {
			...s.logs,
			[date]: {
				...log,
				active: true,
				completed: false,
				startedAt: log.startedAt ?? Date.now()
			}
		} }));
	},
	completeSession: (date) => {
		set((s) => {
			const log = s.logs[date];
			if (!log) return s;
			return {
				restTimer: null,
				logs: {
					...s.logs,
					[date]: {
						...log,
						active: false,
						completed: true,
						finishedAt: Date.now()
					}
				}
			};
		});
	},
	resetSession: (date, session) => {
		set((s) => ({
			restTimer: null,
			logs: {
				...s.logs,
				[date]: createLog(date, session, s.lastWeight, s.lastReps)
			}
		}));
	},
	updateSet: (date, session, exerciseId, index, patch) => {
		set((s) => {
			const log = s.logs[date] ?? createLog(date, session, s.lastWeight, s.lastReps);
			const nextSets = (log.sets[exerciseId] ?? []).map((row, i) => i === index ? {
				...row,
				...patch
			} : row);
			const row = nextSets[index];
			const lastWeight = { ...s.lastWeight };
			const lastReps = { ...s.lastReps };
			if (row?.weight) lastWeight[exerciseId] = row.weight;
			if (row?.reps) lastReps[exerciseId] = row.reps;
			let restTimer = s.restTimer;
			if (patch.done === true && shouldRest(session, exerciseId, index)) {
				const ex = session.exercises.find((e) => e.id === exerciseId);
				if (ex) restTimer = {
					total: ex.restSec,
					remaining: ex.restSec,
					exerciseId,
					label: `${ex.name} · set ${index + 2}`
				};
			}
			if (patch.done === false && restTimer?.exerciseId === exerciseId) restTimer = null;
			return {
				lastWeight,
				lastReps,
				restTimer,
				logs: {
					...s.logs,
					[date]: {
						...log,
						active: true,
						completed: false,
						startedAt: log.startedAt ?? Date.now(),
						sets: {
							...log.sets,
							[exerciseId]: nextSets
						}
					}
				}
			};
		});
	},
	toggleCardio: (date, session) => {
		set((s) => {
			const log = s.logs[date] ?? createLog(date, session, s.lastWeight, s.lastReps);
			return { logs: {
				...s.logs,
				[date]: {
					...log,
					active: true,
					startedAt: log.startedAt ?? Date.now(),
					cardioDone: !log.cardioDone
				}
			} };
		});
	},
	setVariant: (exerciseId, index) => {
		set((s) => ({ variants: {
			...s.variants,
			[exerciseId]: index
		} }));
	},
	tickTimer: () => {
		set((s) => {
			if (!s.restTimer) return s;
			const remaining = s.restTimer.remaining - 1;
			if (remaining <= 0) return { restTimer: null };
			return { restTimer: {
				...s.restTimer,
				remaining
			} };
		});
	},
	skipTimer: () => set({ restTimer: null }),
	addTimer: (sec) => {
		set((s) => {
			if (!s.restTimer) return s;
			return { restTimer: {
				...s.restTimer,
				remaining: s.restTimer.remaining + sec,
				total: Math.max(s.restTimer.total, s.restTimer.remaining + sec)
			} };
		});
	}
}), {
	name: "salon-4gun",
	storage: createJSONStorage(() => localStorage),
	partialize: (s) => ({
		logs: s.logs,
		lastWeight: s.lastWeight,
		lastReps: s.lastReps,
		variants: s.variants
	}),
	skipHydration: true
}));
var R = 52;
var C = 2 * Math.PI * R;
function RestTimer() {
	const timer = useGymStore((s) => s.restTimer);
	const tickTimer = useGymStore((s) => s.tickTimer);
	const skipTimer = useGymStore((s) => s.skipTimer);
	const addTimer = useGymStore((s) => s.addTimer);
	(0, import_react.useEffect)(() => {
		if (!timer) return;
		const id = window.setInterval(() => {
			const current = useGymStore.getState().restTimer;
			if (current && current.remaining <= 1) vibrate([
				70,
				40,
				70
			]);
			tickTimer();
		}, 1e3);
		return () => window.clearInterval(id);
	}, [timer?.exerciseId, tickTimer]);
	if (!timer) return null;
	const progress = timer.remaining / timer.total;
	const m = Math.floor(timer.remaining / 60);
	const s = timer.remaining % 60;
	const clock = `${m}:${String(s).padStart(2, "0")}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-x-0 bottom-24 z-40 px-4",
		role: "dialog",
		"aria-label": "Dinlenme süresi",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-md items-center gap-4 rounded-3xl bg-raised p-4 shadow-[var(--shadow-border)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative size-24 shrink-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
					viewBox: "0 0 120 120",
					className: "size-full -rotate-90",
					"aria-hidden": "true",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "60",
						cy: "60",
						r: R,
						fill: "none",
						stroke: "currentColor",
						className: "text-border",
						strokeWidth: "6"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "60",
						cy: "60",
						r: R,
						fill: "none",
						stroke: "currentColor",
						className: "text-primary",
						strokeWidth: "6",
						strokeLinecap: "round",
						strokeDasharray: C,
						strokeDashoffset: C * (1 - progress),
						style: { transition: "stroke-dashoffset 1s linear" }
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute inset-0 flex items-center justify-center font-display text-xl tabular-nums leading-none text-fg",
					children: clock
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-[0.16em] text-muted",
						children: "Dinlen"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 truncate text-sm text-fg",
						children: timer.label
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							variant: "secondary",
							size: "pill",
							onClick: () => addTimer(30),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5" }), "30 sn"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							variant: "ghost",
							size: "pill",
							onClick: skipTimer,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" }), "Atla"]
						})]
					})
				]
			})]
		})
	});
}
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("h-11 w-full rounded-lg bg-raised px-3 text-center text-sm text-fg tabular-nums shadow-[var(--shadow-border)] outline-none transition-[box-shadow] duration-150 placeholder:text-subtle focus-visible:shadow-[var(--shadow-border-hover)]", className),
		...props
	});
}
var CARDIO_NOTE = "Amaç maksimum kalori yakmak değil — ağırlık performansını öldürmeden ekstra enerji harcamak. Aynı tempoda rahatladıkça süreyi uzatırız.";
var PROGRAM = {
	1: {
		kind: "upper-a",
		weekday: 1,
		dayName: "Pazartesi",
		shortName: "Pzt",
		code: "UA",
		title: "Upper A",
		kicker: "Üst vücut + kardiyo",
		blurb: "Göğüs, sırt, omuz ve kol. Treadmill ile kapanış.",
		duration: "70 dk",
		isTraining: true,
		exercises: [
			{
				id: "ua-bench",
				name: "Bench Press",
				sets: 3,
				reps: "6–8",
				restSec: 120,
				target: "Göğüs"
			},
			{
				id: "ua-lat",
				name: "Lat Pulldown",
				sets: 3,
				reps: "8–12",
				restSec: 90,
				target: "Sırt"
			},
			{
				id: "ua-incline-db",
				name: "Incline Dumbbell Press",
				sets: 3,
				reps: "8–12",
				restSec: 90,
				target: "Göğüs"
			},
			{
				id: "ua-row",
				name: "Seated Cable Row",
				sets: 3,
				reps: "8–12",
				restSec: 90,
				target: "Sırt"
			},
			{
				id: "ua-raise",
				name: "Lateral Raise",
				sets: 3,
				reps: "12–20",
				restSec: 60,
				target: "Omuz"
			},
			{
				id: "ua-pushdown",
				name: "Triceps Pushdown",
				sets: 2,
				reps: "10–15",
				restSec: 60,
				target: "Triceps"
			},
			{
				id: "ua-curl",
				name: "Dumbbell Curl",
				sets: 2,
				reps: "10–15",
				restSec: 60,
				target: "Biceps"
			}
		],
		cardio: {
			duration: "20–25 dk",
			durationHint: "Kısa tempolu yürüyüş",
			incline: "5–7 / 12",
			inclineRange: [5, 7],
			inclineMax: 12,
			speed: "4–5 km/s",
			note: CARDIO_NOTE
		}
	},
	2: {
		kind: "lower-a",
		weekday: 2,
		dayName: "Salı",
		shortName: "Sal",
		code: "LA",
		title: "Lower A",
		kicker: "Bacak · squat odaklı",
		blurb: "Ağır squat varyasyonu, arka zincir ve izolasyon.",
		duration: "55 dk",
		isTraining: true,
		exercises: [
			{
				id: "la-squat",
				name: "Squat",
				variants: ["Squat", "Hack Squat"],
				sets: 3,
				reps: "6–10",
				restSec: 150,
				target: "Quad"
			},
			{
				id: "la-rdl",
				name: "Romanian Deadlift",
				sets: 3,
				reps: "8–10",
				restSec: 120,
				target: "Hamstring"
			},
			{
				id: "la-press",
				name: "Leg Press",
				sets: 3,
				reps: "10–15",
				restSec: 90,
				target: "Quad"
			},
			{
				id: "la-curl",
				name: "Leg Curl",
				sets: 3,
				reps: "10–15",
				restSec: 75,
				target: "Hamstring"
			},
			{
				id: "la-ext",
				name: "Leg Extension",
				sets: 2,
				reps: "12–15",
				restSec: 60,
				target: "Quad"
			},
			{
				id: "la-calf",
				name: "Calf Raise",
				sets: 3,
				reps: "10–15",
				restSec: 60,
				target: "Baldır"
			}
		]
	},
	3: {
		kind: "rest",
		weekday: 3,
		dayName: "Çarşamba",
		shortName: "Çar",
		code: "OFF",
		title: "Dinlenme",
		kicker: "Tamamen off",
		blurb: "Kaslar salonda kırılır, dinlenmede büyür.",
		duration: "—",
		isTraining: false,
		exercises: []
	},
	4: {
		kind: "upper-b",
		weekday: 4,
		dayName: "Perşembe",
		shortName: "Per",
		code: "UB",
		title: "Upper B",
		kicker: "Üst vücut + kardiyo",
		blurb: "Incline pres ve çekiş odaklı ikinci üst gün.",
		duration: "75 dk",
		isTraining: true,
		exercises: [
			{
				id: "ub-incline",
				name: "Incline Bench Press",
				sets: 3,
				reps: "6–10",
				restSec: 120,
				target: "Göğüs"
			},
			{
				id: "ub-lat",
				name: "Lat Pulldown",
				variants: ["Lat Pulldown", "Pull-up"],
				sets: 3,
				reps: "8–12",
				restSec: 90,
				target: "Sırt"
			},
			{
				id: "ub-chest",
				name: "Machine Chest Press",
				sets: 3,
				reps: "8–12",
				restSec: 90,
				target: "Göğüs"
			},
			{
				id: "ub-row",
				name: "Chest-Supported Row",
				sets: 3,
				reps: "8–12",
				restSec: 90,
				target: "Sırt"
			},
			{
				id: "ub-raise",
				name: "Lateral Raise",
				sets: 3,
				reps: "12–20",
				restSec: 60,
				target: "Omuz"
			},
			{
				id: "ub-oh",
				name: "Overhead Triceps Extension",
				sets: 2,
				reps: "10–15",
				restSec: 60,
				target: "Triceps"
			},
			{
				id: "ub-curl",
				name: "Incline Dumbbell Curl",
				sets: 2,
				reps: "10–15",
				restSec: 60,
				target: "Biceps"
			}
		],
		cardio: {
			duration: "25–35 dk",
			durationHint: "Biraz daha uzun yürüyüş",
			incline: "5–7 / 12",
			inclineRange: [5, 7],
			inclineMax: 12,
			speed: "4–5 km/s",
			note: CARDIO_NOTE
		}
	},
	5: {
		kind: "rest",
		weekday: 5,
		dayName: "Cuma",
		shortName: "Cum",
		code: "OFF",
		title: "Dinlenme",
		kicker: "Tamamen off",
		blurb: "Yarın yok — sonraki seans cumartesi Lower B.",
		duration: "—",
		isTraining: false,
		exercises: []
	},
	6: {
		kind: "lower-b",
		weekday: 6,
		dayName: "Cumartesi",
		shortName: "Cmt",
		code: "LB",
		title: "Lower B",
		kicker: "Bacak · hacim odaklı",
		blurb: "Hack / split squat, unilateral iş ve izolasyon.",
		duration: "55 dk",
		isTraining: true,
		exercises: [
			{
				id: "lb-hack",
				name: "Hack Squat",
				variants: ["Hack Squat", "Leg Press"],
				sets: 3,
				reps: "8–12",
				restSec: 120,
				target: "Quad"
			},
			{
				id: "lb-rdl",
				name: "Romanian Deadlift",
				sets: 3,
				reps: "8–12",
				restSec: 120,
				target: "Hamstring"
			},
			{
				id: "lb-split",
				name: "Bulgarian Split Squat",
				sets: 2,
				reps: "8–12",
				restSec: 90,
				target: "Quad",
				perSide: true
			},
			{
				id: "lb-curl",
				name: "Seated Leg Curl",
				sets: 3,
				reps: "10–15",
				restSec: 75,
				target: "Hamstring"
			},
			{
				id: "lb-ext",
				name: "Leg Extension",
				sets: 2,
				reps: "12–15",
				restSec: 60,
				target: "Quad"
			},
			{
				id: "lb-calf",
				name: "Seated Calf Raise",
				sets: 3,
				reps: "10–15",
				restSec: 60,
				target: "Baldır"
			}
		]
	},
	0: {
		kind: "rest",
		weekday: 0,
		dayName: "Pazar",
		shortName: "Paz",
		code: "OFF",
		title: "Dinlenme",
		kicker: "Haftayı kapat",
		blurb: "Yarın Upper A ile yeni hafta başlar.",
		duration: "—",
		isTraining: false,
		exercises: []
	}
};
var WEEK_RHYTHM = [
	{
		code: "UA",
		label: "Upper"
	},
	{
		code: "LA",
		label: "Lower"
	},
	{
		code: "OFF",
		label: "Dinlen"
	},
	{
		code: "UB",
		label: "Upper"
	},
	{
		code: "OFF",
		label: "Dinlen"
	},
	{
		code: "LB",
		label: "Lower"
	},
	{
		code: "OFF",
		label: "Dinlen"
	}
];
function sessionForDate(date) {
	return PROGRAM[date.getDay()] ?? PROGRAM[0];
}
function nextTraining(from) {
	for (let i = 1; i <= 7; i += 1) {
		const d = new Date(from);
		d.setDate(from.getDate() + i);
		const session = sessionForDate(d);
		if (session.isTraining) return session;
	}
	return PROGRAM[1];
}
function formatRest(sec) {
	if (sec < 60) return `${sec} sn`;
	const m = Math.floor(sec / 60);
	const s = sec % 60;
	return s === 0 ? `${m} dk` : `${m}:${String(s).padStart(2, "0")}`;
}
function parseWeight(value) {
	const n = Number(value.replace(",", "."));
	return Number.isFinite(n) ? n : 0;
}
function sessionVolume(sets) {
	return sets.reduce((sum, set) => {
		if (!set.done) return sum;
		const reps = Number(set.reps);
		return sum + parseWeight(set.weight) * (Number.isFinite(reps) ? reps : 0);
	}, 0);
}
function WeekStrip({ days, selected, today, onSelect }) {
	const logs = useGymStore((s) => s.logs);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-7 gap-1.5",
		role: "tablist",
		"aria-label": "Haftalık program",
		children: days.map((day) => {
			const key = format(day, "yyyy-MM-dd");
			const session = sessionForDate(day);
			const isSelected = isSameDay(day, selected);
			const isToday = isSameDay(day, today);
			const completed = Boolean(logs[key]?.completed);
			const isRest = !session.isTraining;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				role: "tab",
				"aria-selected": isSelected,
				onClick: () => onSelect(day),
				className: cn("flex min-h-20 min-w-0 w-full flex-col items-center justify-between rounded-xl px-0.5 py-2 transition-[background-color,box-shadow,color] duration-150", isSelected ? "bg-primary text-primary-fg" : "bg-surface text-muted shadow-[var(--shadow-border)]"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs font-medium",
						children: session.shortName
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("font-display text-lg leading-none tabular-nums", isSelected ? "text-primary-fg" : "text-fg"),
						children: format(day, "d")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "flex h-4 items-center text-xs font-semibold tracking-wide",
						children: completed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
							className: "size-3",
							strokeWidth: 2.5
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn(isRest && !isSelected && "text-subtle"),
							children: session.code
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("mt-1 size-1 rounded-full", isToday && !isSelected ? "bg-accent" : "bg-transparent") })
				]
			}, key);
		})
	});
}
function dateFromKey(key) {
	return parseISO(`${key}T12:00:00`);
}
function todayKey() {
	return format(/* @__PURE__ */ new Date(), "yyyy-MM-dd");
}
function weekDates(anchor) {
	const start = startOfWeek(anchor, { weekStartsOn: 1 });
	return Array.from({ length: 7 }, (_, i) => addDays(start, i));
}
function GymApp() {
	const [selectedKey, setSelectedKey] = (0, import_react.useState)(todayKey);
	const [today, setToday] = (0, import_react.useState)(todayKey);
	const logs = useGymStore((s) => s.logs);
	(0, import_react.useEffect)(() => {
		const key = todayKey();
		setToday(key);
		setSelectedKey(key);
		useGymStore.persist.rehydrate();
	}, []);
	const selected = (0, import_react.useMemo)(() => dateFromKey(selectedKey), [selectedKey]);
	const days = (0, import_react.useMemo)(() => weekDates(selected), [selectedKey]);
	const session = (0, import_react.useMemo)(() => sessionForDate(selected), [selectedKey]);
	const log = logs[selectedKey];
	const isToday = selectedKey === today;
	const weekDone = days.filter((d) => {
		const key = format(d, "yyyy-MM-dd");
		return sessionForDate(d).isTraining && logs[key]?.completed;
	}).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto min-h-dvh max-w-md overflow-x-hidden pb-28",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-20 flex items-end justify-between bg-bg/95 px-4 pb-3 pt-4 backdrop-blur-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-2xl leading-none tracking-tight text-fg",
					children: "SALON"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs text-muted",
					children: "4 gün · Upper / Lower"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-right",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-display text-lg tabular-nums leading-none text-fg",
						children: [
							weekDone,
							"/",
							4
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted",
						children: "bu hafta"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "px-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WeekStrip, {
						days,
						selected,
						today: dateFromKey(today),
						onSelect: (d) => setSelectedKey(format(d, "yyyy-MM-dd"))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rhythm, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SessionHero, {
						session,
						date: selected,
						isToday,
						log
					}),
					session.isTraining ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrainingBody, {
						dateKey: selectedKey,
						session,
						log
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RestBody, { from: selected })
				]
			}),
			session.isTraining ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SessionDock, {
				dateKey: selectedKey,
				session,
				log
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RestTimer, {})
		]
	});
}
function Rhythm() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "rise-in mt-5 text-center text-xs tracking-wide text-subtle",
		children: WEEK_RHYTHM.map((d, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [i > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mx-1.5 text-border",
			children: "→"
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: d.code === "OFF" ? "text-subtle" : "text-muted",
			children: d.label
		})] }, `${d.code}-${i}`))
	});
}
function SessionHero({ session, date, isToday, log }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rise-in stagger-1 mt-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs font-medium uppercase tracking-[0.18em] text-muted",
				children: [
					isToday ? "Bugün" : format(date, "d MMMM", { locale: tr }),
					" · ",
					session.dayName
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-display mt-2 text-fg uppercase",
				children: session.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-sm text-sm text-muted",
				children: session.blurb
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetaChip, { children: session.kicker }),
					session.isTraining ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetaChip, { children: session.duration }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetaChip, { children: "Salon yok" }),
					log?.completed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetaChip, {
						accent: true,
						children: "Tamamlandı"
					}) : null
				]
			})
		]
	});
}
function MetaChip({ children, accent = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex h-8 items-center rounded-full px-3 text-xs font-medium", accent ? "bg-accent/15 text-accent" : "bg-surface text-muted shadow-[var(--shadow-border)]"),
		children
	});
}
function RestBody({ from }) {
	const next = nextTraining(from);
	const week = weekDates(from);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rise-in stagger-2 mt-8 space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-3xl bg-surface p-5 shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex size-11 items-center justify-center rounded-lg bg-raised text-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-4 font-display text-xl tracking-tight text-fg",
						children: "Bugün salona gitmiyorsun"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-relaxed text-muted",
						children: "Bu da programın parçası. Protein, uyku, su. İsteğe bağlı kısa yürüyüş — koşu bandına çıkmana gerek yok."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-3xl bg-surface p-5 shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-[0.16em] text-muted",
						children: "Sıradaki"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 font-display text-2xl tracking-tight text-fg",
						children: next.dayName
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							next.title,
							" · ",
							next.kicker
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-3xl bg-surface p-5 shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-[0.16em] text-muted",
					children: "Haftalık ritim"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 space-y-2",
					children: week.map((d) => {
						const s = sessionForDate(d);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between gap-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted",
								children: s.shortName
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: cn("truncate", s.isTraining ? "text-fg" : "text-subtle"),
								children: [s.title, s.cardio ? " + kardiyo" : ""]
							})]
						}, format(d, "yyyy-MM-dd"));
					})
				})]
			})
		]
	});
}
function TrainingBody({ dateKey, session, log }) {
	const totalSets = session.exercises.reduce((n, ex) => n + ex.sets, 0) + (session.cardio ? 1 : 0);
	const doneSets = (log ? session.exercises.reduce((n, ex) => n + (log.sets[ex.id]?.filter((s) => s.done).length ?? 0), 0) : 0) + (log?.cardioDone ? 1 : 0);
	const volume = log ? session.exercises.reduce((n, ex) => n + sessionVolume(log.sets[ex.id] ?? []), 0) : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-8 space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-end justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-[0.16em] text-muted",
					children: "Hareketler"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-subtle tabular-nums",
					children: [
						doneSets,
						"/",
						totalSets,
						" set",
						volume > 0 ? ` · ${Math.round(volume)} kg hacim` : ""
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-1.5 w-24 overflow-hidden rounded-full bg-raised",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-full rounded-full bg-accent transition-[width] duration-200 ease-out",
						style: { width: `${totalSets === 0 ? 0 : doneSets / totalSets * 100}%` }
					})
				})]
			}),
			session.exercises.map((exercise, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExerciseCard, {
				dateKey,
				session,
				exercise,
				log,
				index: i
			}, exercise.id)),
			session.cardio ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardioCard, {
				dateKey,
				session,
				cardio: session.cardio,
				log
			}) : null
		]
	});
}
function ExerciseCard({ dateKey, session, exercise, log, index }) {
	const variants = useGymStore((s) => s.variants);
	const setVariant = useGymStore((s) => s.setVariant);
	const updateSet = useGymStore((s) => s.updateSet);
	const lastWeight = useGymStore((s) => s.lastWeight[exercise.id]);
	const variantIndex = variants[exercise.id] ?? 0;
	const name = exercise.variants?.[variantIndex] ?? exercise.name;
	const sets = log?.sets[exercise.id];
	const doneCount = sets?.filter((s) => s.done).length ?? 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: cn("rise-in rounded-3xl bg-surface p-4 shadow-[var(--shadow-border)]", `stagger-${Math.min(index + 2, 8)}`),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tabular-nums text-subtle",
							children: String(index + 1).padStart(2, "0")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-1 font-display text-lg leading-tight tracking-tight text-fg",
							children: name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-xs text-muted",
							children: [
								exercise.sets,
								" × ",
								exercise.reps,
								exercise.perSide ? " / bacak" : "",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mx-1.5 text-border",
									children: "·"
								}),
								exercise.target,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mx-1.5 text-border",
									children: "·"
								}),
								formatRest(exercise.restSec),
								" dinlenme"
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "pt-1 text-xs tabular-nums text-muted",
					children: [
						doneCount,
						"/",
						exercise.sets
					]
				})]
			}),
			exercise.variants ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 grid grid-cols-2 gap-1 rounded-xl bg-raised p-1",
				children: exercise.variants.map((label, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setVariant(exercise.id, i),
					className: cn("h-9 rounded-lg text-xs font-medium transition-colors duration-150", variantIndex === i ? "bg-surface text-fg shadow-[var(--shadow-border)]" : "text-muted"),
					children: label
				}, label))
			}) : null,
			lastWeight && !sets?.some((s) => s.weight) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-xs text-subtle",
				children: [
					"Son: ",
					lastWeight,
					" kg"
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-3 space-y-2",
				children: Array.from({ length: exercise.sets }, (_, setIndex) => {
					const row = sets?.[setIndex] ?? {
						weight: lastWeight ?? "",
						reps: "",
						done: false
					};
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "grid grid-cols-[2rem_1fr_1fr_2.75rem] items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-center text-xs tabular-nums text-subtle",
								children: setIndex + 1
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "sr-only",
								htmlFor: `${exercise.id}-${setIndex}-kg`,
								children: [
									name,
									" set ",
									setIndex + 1,
									" kilo"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: `${exercise.id}-${setIndex}-kg`,
								inputMode: "decimal",
								placeholder: "kg",
								value: row.weight,
								onChange: (e) => updateSet(dateKey, session, exercise.id, setIndex, { weight: e.target.value })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "sr-only",
								htmlFor: `${exercise.id}-${setIndex}-reps`,
								children: [
									name,
									" set ",
									setIndex + 1,
									" tekrar"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: `${exercise.id}-${setIndex}-reps`,
								inputMode: "numeric",
								placeholder: "tek.",
								value: row.reps,
								onChange: (e) => updateSet(dateKey, session, exercise.id, setIndex, { reps: e.target.value })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": `Set ${setIndex + 1} tamamlandı`,
								"aria-pressed": row.done,
								onClick: () => {
									vibrate(row.done ? 8 : 18);
									updateSet(dateKey, session, exercise.id, setIndex, { done: !row.done });
								},
								className: cn("flex size-11 items-center justify-center rounded-lg transition-colors duration-150", row.done ? "bg-accent text-primary-fg" : "bg-raised text-subtle shadow-[var(--shadow-border)]"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
									className: "size-4",
									strokeWidth: 2.5
								})
							})
						]
					}, setIndex);
				})
			})
		]
	});
}
function CardioCard({ dateKey, session, cardio, log }) {
	const toggleCardio = useGymStore((s) => s.toggleCardio);
	const done = Boolean(log?.cardioDone);
	const ticks = Array.from({ length: cardio.inclineMax }, (_, i) => i + 1);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rise-in stagger-8 rounded-3xl bg-surface p-4 shadow-[var(--shadow-border)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-[0.16em] text-muted",
						children: "Kardiyo"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-1 font-display text-lg tracking-tight text-fg",
						children: "Treadmill"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-xs text-muted",
						children: [
							cardio.duration,
							" · ",
							cardio.speed,
							" · eğim ",
							cardio.incline
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "Kardiyo tamamlandı",
					"aria-pressed": done,
					onClick: () => {
						vibrate(done ? 8 : 18);
						toggleCardio(dateKey, session);
					},
					className: cn("flex size-11 shrink-0 items-center justify-center rounded-lg transition-colors duration-150", done ? "bg-accent text-primary-fg" : "bg-raised text-subtle shadow-[var(--shadow-border)]"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
						className: "size-4",
						strokeWidth: 2.5
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mb-2 text-xs text-subtle",
					children: [
						"Eğim skalası (1–",
						cardio.inclineMax,
						")"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-12 gap-1",
					children: ticks.map((n) => {
						const active = n >= cardio.inclineRange[0] && n <= cardio.inclineRange[1];
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col items-center gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: cn("h-7 w-full rounded-sm", active ? "bg-primary" : "bg-raised") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("h-3 text-xs tabular-nums", active ? "text-fg" : "text-subtle"),
								children: n === 1 || n === cardio.inclineRange[0] || n === cardio.inclineRange[1] || n === cardio.inclineMax ? n : ""
							})]
						}, n);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm leading-relaxed text-muted",
				children: cardio.note
			})
		]
	});
}
function SessionDock({ dateKey, session, log }) {
	const startSession = useGymStore((s) => s.startSession);
	const completeSession = useGymStore((s) => s.completeSession);
	const resetSession = useGymStore((s) => s.resetSession);
	const started = Boolean(log?.active || log?.completed);
	const completed = Boolean(log?.completed);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-x-0 bottom-0 z-30 border-t border-border/80 bg-bg/95 px-4 pt-3 pb-3 backdrop-blur-sm",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto flex max-w-md items-center gap-2",
			children: completed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "button",
				variant: "secondary",
				className: "flex-1",
				onClick: () => resetSession(dateKey, session),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), "Sıfırla"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "flex flex-1 items-center justify-center gap-2 text-sm text-accent",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }), "Seans bitti"]
			})] }) : started ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "ghost",
				size: "icon",
				"aria-label": "Seansı sıfırla",
				onClick: () => resetSession(dateKey, session),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "button",
				size: "lg",
				className: "flex-1",
				onClick: () => completeSession(dateKey),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dumbbell, { className: "size-4" }), "Antrenmanı bitir"]
			})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "button",
				size: "lg",
				onClick: () => startSession(dateKey, session),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Timer, { className: "size-4" }), "Antrenmana başla"]
			})
		})
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GymApp, {});
}
//#endregion
export { Home as component };
