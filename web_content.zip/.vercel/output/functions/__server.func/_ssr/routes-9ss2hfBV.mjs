import { o as __toESM } from "../_runtime.mjs";
import { a as require_jsx_runtime, i as useQueryClient, n as useQuery, o as require_react, t as useMutation } from "../_libs/react+tanstack__react-query.mjs";
import { v as Link, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as getServerFnById, i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { n as UserButton, r as useCurrentUserState } from "./gates-LnRAiBUB.mjs";
import { a as computeOwnerCommission, c as fmtMoney, d as safeFileName, f as telHref, i as computeCommission, l as getStoredReferral, m as waHref, n as authMiddleware, o as computeRenterCommission, p as toNumber, r as captureReferral, s as downloadTextFile, t as areaPin, u as gmapsHref } from "./rooms-model-vkd-sanX.mjs";
import { a as MessageCircle, c as Lock, i as Phone, l as LayoutList, n as Trash2, o as Map, r as Share2, s as MapPinned, u as Download } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as Route$2 } from "./router-B87PuXjv.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-9ss2hfBV.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function asKind(v) {
	return v === "fixed" ? "fixed" : "percent";
}
var listRooms = createServerFn({ method: "GET" }).handler(createSsrRpc("52c2ed81cbe0b3dfe8bb9d9916d27eb903bffdbd45a6149fafd59b387d7e52b6"));
var listMyRooms = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("f9937666c001e2bd903d189d0e01ae04e18e63ebde4a2e9096d9634a33f26be8"));
var createRoom = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const title = String(input.title || "").trim();
	const location = String(input.location || "").trim();
	const phone = String(input.phone || "").trim();
	if (!title) throw new Error("Title is required.");
	if (!location) throw new Error("Pick an area for this room.");
	if (!phone) throw new Error("Owner phone is required.");
	const rent = toNumber(input.rent);
	if (rent < 0) throw new Error("Rent must be zero or more.");
	return {
		title: title.slice(0, 120),
		location: location.slice(0, 120),
		rent,
		currency: String(input.currency || "").trim().slice(0, 12),
		deposit: Math.max(0, toNumber(input.deposit)),
		availableFrom: String(input.availableFrom || "").trim().slice(0, 80),
		phone: phone.slice(0, 40),
		whatsapp: String(input.whatsapp || "").trim().slice(0, 40),
		description: String(input.description || "").trim().slice(0, 2e3),
		commissionType: asKind(String(input.commissionType)),
		commissionValue: Math.max(0, toNumber(input.commissionValue)),
		renterCommissionType: asKind(String(input.renterCommissionType)),
		renterCommissionValue: Math.max(0, toNumber(input.renterCommissionValue))
	};
}).handler(createSsrRpc("214a817ad94b80eb9ff1050573bbbb5b192dee7b2e345046acb55bed64b704ce"));
var getRoomContact = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => ({
	roomId: String(input.roomId || ""),
	referrerId: input.referrerId ? String(input.referrerId) : null
})).handler(createSsrRpc("49632de4bd84b45145dbb9a65f3993836f03d4b1cd025c301cc484773c55d588"));
var deleteRoom = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((roomId) => String(roomId || "")).handler(createSsrRpc("d5475b9ac8a1da002804217be4c7b57dfc63fe11e5f9e1b278e96723a040ee43"));
var reopenRoom = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((roomId) => String(roomId || "")).handler(createSsrRpc("dfd9567548e8bc28fad50c432f19b2015233f7206befba62d7457243d019fefe"));
var listLeadsForRoom = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((roomId) => String(roomId || "")).handler(createSsrRpc("38f0cf1d5acc95c4ff47d1df294a6e290e691b3f274790ba0054e2e4eb21154d"));
var confirmRented = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => ({
	roomId: String(input.roomId || ""),
	referrerId: input.referrerId ? String(input.referrerId) : null
})).handler(createSsrRpc("91e22eeec88c0fcee3e9995304684012e6aece21061f2aa8cd64d64152f789a7"));
var listMyCommissions = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("8fcfe99380eab88423ff3e930be2e16062a113b7007a6a34bd05afea8e4fe851"));
var listRoomCommissions = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((roomId) => String(roomId || "")).handler(createSsrRpc("2a6b7c5fdaa9bccbeb428b9c7a94803ba975ff404c917c93e2076d7ffcb3a090"));
var markCommissionPaid = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((commissionId) => toNumber(commissionId)).handler(createSsrRpc("a3c988054409db2b89c732f250457de5b700e3fc83acc60388b4188eaf49d378"));
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function isUnauthorized(err) {
	if (!err || typeof err !== "object") return false;
	const e = err;
	return e.status === 401 || e.message === "Unauthorized";
}
function errorMessage(err, fallback = "Something went wrong. Try again.") {
	if (err instanceof Error && err.message) return err.message;
	if (err && typeof err === "object" && "message" in err && typeof err.message === "string") return err.message;
	return fallback;
}
function shorten(area) {
	return area.length > 18 ? `${area.slice(0, 16)}…` : area;
}
function BrowseAreaMap({ groups, onSelect }) {
	const pins = (0, import_react.useMemo)(() => groups.map((g) => ({
		...g,
		...areaPin(g.area)
	})), [groups]);
	if (!pins.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 600 320",
		className: "block w-full rounded-md border border-line bg-paper-alt",
		role: "img",
		"aria-label": "Area map",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
			x: "300",
			y: "160",
			textAnchor: "middle",
			fill: "currentColor",
			className: "fill-ink-soft text-[13px]",
			children: "No available rooms to map yet."
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 600 320",
		className: "block w-full rounded-md border border-line bg-paper-alt",
		role: "img",
		"aria-label": "Rooms grouped by area",
		children: pins.map((p) => {
			const r = 12 + Math.min(p.count, 8) * 3;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
				className: "cursor-pointer",
				transform: `translate(${p.x},${p.y})`,
				onClick: () => onSelect(p.area),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						r,
						className: "fill-brass/85 stroke-brass-deep",
						strokeWidth: "1"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
						y: "4",
						textAnchor: "middle",
						className: "fill-white text-[10px] font-bold",
						children: p.count
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
						y: r + 14,
						textAnchor: "middle",
						className: "fill-ink text-[10px]",
						children: shorten(p.area)
					})
				]
			}, p.area);
		})
	});
}
function PickAreaMap({ groups, picked, onPickExisting }) {
	const pins = (0, import_react.useMemo)(() => groups.map((g) => ({
		...g,
		...areaPin(g.area)
	})), [groups]);
	const extra = picked && !groups.some((g) => g.area === picked) ? {
		area: picked,
		...areaPin(picked)
	} : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 600 320",
		className: "block w-full rounded-md border border-line bg-paper-alt",
		role: "img",
		"aria-label": "Pick an area",
		children: [pins.map((p) => {
			const selected = p.area === picked;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
				className: "cursor-pointer",
				transform: `translate(${p.x},${p.y})`,
				onClick: () => onPickExisting(p.area),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					r: 10 + Math.min(p.count, 8) * 2,
					className: cn(selected ? "fill-brass-deep" : "fill-ink-soft/45", "stroke-brass-deep"),
					strokeWidth: selected ? 2 : 1
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
					y: "24",
					textAnchor: "middle",
					className: "fill-ink text-[10px]",
					children: shorten(p.area)
				})]
			}, p.area);
		}), extra ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
			transform: `translate(${extra.x},${extra.y})`,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				r: "12",
				className: "fill-brass-deep stroke-brass-deep",
				strokeWidth: "2"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				y: "24",
				textAnchor: "middle",
				className: "fill-ink text-[10px]",
				children: shorten(extra.area)
			})]
		}) : null]
	});
}
function StatusPill({ tone, children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center rounded-full px-2 py-0.5 text-[11px] font-semibold", {
			available: "bg-green-bg text-green",
			paid: "bg-green-bg text-green",
			rented: "bg-rust-bg text-rust",
			pending: "bg-rust-bg text-rust"
		}[tone], className),
		children
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 font-semibold transition-opacity duration-(--motion-quick) ease-(--ease-out) focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brass disabled:pointer-events-none disabled:opacity-45", {
	variants: {
		variant: {
			ink: "bg-ink text-paper border border-ink hover:opacity-90",
			brass: "bg-brass text-white border border-brass hover:opacity-90",
			secondary: "bg-transparent text-ink border border-line font-medium hover:bg-paper-alt",
			ghost: "bg-transparent text-ink-soft border-0 font-medium hover:text-ink"
		},
		size: {
			default: "min-h-11 px-4 text-sm rounded-md",
			sm: "min-h-10 px-3 text-[13px] rounded-sm"
		}
	},
	defaultVariants: {
		variant: "ink",
		size: "default"
	}
});
var Button = (0, import_react.forwardRef)(function Button({ className, variant, size, type = "button", ...props }, ref) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		ref,
		type,
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
});
function FlyerCard({ room, isOwner, signedIn, onCall, onWhatsApp, onShare, onDownload }) {
	const commission = computeCommission(room);
	const ownerAmt = computeOwnerCommission(room);
	const renterAmt = computeRenterCommission(room);
	const commLabel = `Share this room, earn ${fmtMoney(commission, room.currency)}` + (renterAmt > 0 ? ` (${fmtMoney(ownerAmt, room.currency)} from owner + ${fmtMoney(renterAmt, room.currency)} from renter)` : "");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "relative rounded-lg border border-line bg-card p-5 pt-5 shadow-[var(--shadow-border)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				"aria-hidden": "true",
				className: "absolute -top-1.5 left-1/2 size-2.5 -translate-x-1/2 rounded-full bg-brass shadow-[0_1px_2px_rgba(0,0,0,.25)]"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, {
				tone: room.status === "rented" ? "rented" : "available",
				className: "absolute top-3.5 right-3.5",
				children: room.status === "rented" ? "Rented" : "Available"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-serif pr-16 text-[19px] font-semibold leading-snug text-ink",
				children: room.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-0.5 text-[13px] text-ink-soft",
				children: [
					room.location,
					room.availableFrom ? ` · from ${room.availableFrom}` : "",
					isOwner ? " · your listing" : ""
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 font-semibold text-brass-deep tabular-nums",
				children: [
					fmtMoney(room.rent, room.currency),
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-[12.5px] font-normal text-ink-soft",
						children: ["/ month", room.deposit ? ` · deposit ${fmtMoney(room.deposit, room.currency)}` : ""]
					})
				]
			}),
			room.description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 line-clamp-3 text-[13.5px] text-ink/85",
				children: room.description
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 inline-block rounded-full bg-paper-alt px-2 py-0.5 text-[11.5px] text-brass-deep",
				children: commLabel
			}),
			renterAmt > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-[11px] text-ink-soft",
				children: [
					"Heads up: a ",
					fmtMoney(renterAmt, room.currency),
					" finder's fee applies to the renter if you take this room."
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-wrap gap-2 border-t border-dashed border-line pt-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						className: "min-w-0 flex-1",
						size: "sm",
						onClick: onCall,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-3.5" }),
							"Call owner",
							!signedIn ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-3 opacity-70" }) : null
						]
					}),
					room.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						className: "min-w-0 flex-1",
						size: "sm",
						variant: "secondary",
						onClick: onWhatsApp,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-3.5" }),
							"WhatsApp",
							!signedIn ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-3 opacity-70" }) : null
						]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						className: "min-w-0 flex-1",
						size: "sm",
						variant: "secondary",
						onClick: onShare,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "size-3.5" }), "Share & earn"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						className: cn(buttonVariants({
							variant: "secondary",
							size: "sm"
						}), "min-w-0 flex-1"),
						href: gmapsHref(room.location),
						target: "_blank",
						rel: "noopener noreferrer",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPinned, { className: "size-3.5" }), "Google Maps"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						className: "min-w-0 flex-1",
						size: "sm",
						variant: "secondary",
						onClick: onDownload,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-3.5" }), "Flyer"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "basis-full text-[11px] text-ink-soft",
						children: "Numbers stay hidden until you tap to contact — sign in required."
					})
				]
			})
		]
	});
}
var fieldClass = "w-full min-h-11 rounded-sm border border-line bg-card px-3 py-2 text-sm text-ink placeholder:text-ink-soft/80 focus-visible:outline-2 focus-visible:outline-offset-1 focus-visible:outline-brass disabled:opacity-50";
var Input = (0, import_react.forwardRef)(function Input({ className, ...props }, ref) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		ref,
		className: cn(fieldClass, className),
		...props
	});
});
var Textarea = (0, import_react.forwardRef)(function Textarea({ className, ...props }, ref) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		ref,
		className: cn(fieldClass, "min-h-24 py-2.5", className),
		...props
	});
});
var NativeSelect = (0, import_react.forwardRef)(function NativeSelect({ className, ...props }, ref) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
		ref,
		className: cn(fieldClass, className),
		...props
	});
});
function FieldLabel({ htmlFor, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		htmlFor,
		className: "mb-1.5 block text-[12.5px] font-medium text-ink-soft",
		children
	});
}
function Skeleton({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: cn("animate-pulse rounded-md bg-ink/10", className) });
}
function BrowseView({ rooms, loading, userId, signedIn }) {
	const navigate = useNavigate();
	const [query, setQuery] = (0, import_react.useState)("");
	const [mode, setMode] = (0, import_react.useState)("list");
	const [referral, setReferral] = (0, import_react.useState)({
		ref: null,
		room: null
	});
	(0, import_react.useEffect)(() => {
		setReferral(getStoredReferral());
	}, []);
	const filtered = (0, import_react.useMemo)(() => {
		const q = query.trim().toLowerCase();
		if (!q) return rooms;
		return rooms.filter((r) => (r.title || "").toLowerCase().includes(q) || (r.location || "").toLowerCase().includes(q));
	}, [rooms, query]);
	const groups = (0, import_react.useMemo)(() => {
		const map = {};
		rooms.filter((r) => r.status !== "rented").forEach((r) => {
			const area = (r.location || "Unspecified").trim();
			map[area] = (map[area] || 0) + 1;
		});
		return Object.entries(map).map(([area, count]) => ({
			area,
			count
		}));
	}, [rooms]);
	const reveal = useMutation({
		mutationFn: async (vars) => {
			const stored = getStoredReferral();
			const referrerId = stored.ref && stored.room === vars.roomId ? stored.ref : null;
			return {
				...await getRoomContact({ data: {
					roomId: vars.roomId,
					referrerId
				} }),
				kind: vars.kind
			};
		},
		onSuccess: (contact) => {
			if (contact.kind === "call") {
				window.location.href = telHref(contact.phone);
				return;
			}
			if (!contact.whatsapp) {
				toast("This owner did not add a WhatsApp number.");
				return;
			}
			const msg = `Hi, I'm interested in the room: ${contact.title}`;
			window.open(waHref(contact.whatsapp, msg), "_blank", "noopener");
		},
		onError: (err) => {
			if (isUnauthorized(err)) {
				toast("Sign in to view this owner's contact info.");
				navigate({ to: "/login" });
				return;
			}
			toast(errorMessage(err));
		}
	});
	function requireSignIn(action) {
		if (signedIn) return true;
		toast(`Sign in to ${action}.`);
		navigate({ to: "/login" });
		return false;
	}
	async function shareRoom(room) {
		if (!requireSignIn("get your personal referral link")) return;
		if (!userId) return;
		const url = `${window.location.origin}${window.location.pathname}?ref=${encodeURIComponent(userId)}&room=${encodeURIComponent(room.id)}`;
		try {
			if (navigator.share) {
				await navigator.share({
					title: room.title,
					url,
					text: `Room listing: ${room.title}`
				});
				return;
			}
		} catch (err) {
			if (err instanceof Error && err.name === "AbortError") return;
		}
		try {
			await navigator.clipboard.writeText(url);
			toast("Referral link copied — share it to earn commission.");
		} catch {
			toast(url);
		}
	}
	function downloadFlyer(room) {
		const lines = [
			room.title,
			room.location + (room.availableFrom ? ` · available from ${room.availableFrom}` : ""),
			`${fmtMoney(room.rent, room.currency)}/month${room.deposit ? ` · deposit ${fmtMoney(room.deposit, room.currency)}` : ""}`,
			"",
			room.description || "",
			"",
			`Map: ${gmapsHref(room.location)}`,
			"",
			"Contact details are private — open this listing in RentDirect and sign in to reveal them."
		];
		downloadTextFile(`${safeFileName(room.title)}.txt`, lines.join("\n"));
		toast("Flyer downloaded.");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		referral.ref ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-4.5 rounded-sm border border-green bg-green-bg px-3.5 py-2.5 text-[13.5px] text-green",
			children: "You're viewing this via a shared link — calling or messaging an owner credits whoever shared it with you."
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-4.5 flex gap-2.5",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				id: "search-input",
				value: query,
				onChange: (e) => setQuery(e.target.value),
				placeholder: "Search by title or area…",
				"aria-label": "Search rooms"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-3.5 flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "sm",
				variant: mode === "list" ? "brass" : "secondary",
				onClick: () => setMode("list"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutList, { className: "size-3.5" }), "List"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "sm",
				variant: mode === "map" ? "brass" : "secondary",
				onClick: () => setMode("map"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Map, { className: "size-3.5" }), "Map"]
			})]
		}),
		mode === "map" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4.5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 rounded-sm bg-paper-alt px-3 py-2.5 text-[13px] text-ink-soft",
				children: "Grouped by the area text owners entered — an approximate overview, not a real geographic map. Tap a pin to filter the list."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrowseAreaMap, {
				groups,
				onSelect: (area) => {
					setQuery(area);
					setMode("list");
				}
			})]
		}) : null,
		mode === "list" && loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-1 gap-4.5 sm:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" })]
		}) : null,
		mode === "list" && !loading ? filtered.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-1 gap-4.5 sm:grid-cols-2",
			children: filtered.map((room) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FlyerCard, {
				room,
				isOwner: Boolean(userId && room.ownerId === userId),
				signedIn,
				onCall: () => {
					if (!requireSignIn("view this owner's contact info")) return;
					reveal.mutate({
						roomId: room.id,
						kind: "call"
					});
				},
				onWhatsApp: () => {
					if (!requireSignIn("view this owner's contact info")) return;
					reveal.mutate({
						roomId: room.id,
						kind: "wa"
					});
				},
				onShare: () => void shareRoom(room),
				onDownload: () => downloadFlyer(room)
			}, room.id))
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "px-0 py-8 text-center text-sm text-ink-soft",
			children: rooms.length ? "No rooms match that search." : "No rooms posted yet. Be the first — switch to \"List a room\"."
		}) : null
	] });
}
function EarningsView({ rows, signedIn, loading }) {
	const pending = rows.filter((c) => c.status !== "paid").reduce((s, c) => s + c.amount, 0);
	const paid = rows.filter((c) => c.status === "paid").reduce((s, c) => s + c.amount, 0);
	const currencies = new Set(rows.map((c) => c.currency).filter(Boolean));
	const currency = currencies.size === 1 ? [...currencies][0] : "";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		!signedIn ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-4 rounded-sm bg-paper-alt px-3 py-2.5 text-[13px] text-ink-soft",
			children: "Sign in to see your referral links and earnings."
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-5.5 grid grid-cols-2 gap-3.5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-md border border-line bg-card p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-serif text-[26px] font-semibold tabular-nums",
					children: loading ? "—" : fmtMoney(pending, currency)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-0.5 text-xs text-ink-soft",
					children: "Pending commission"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-md border border-line bg-card p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-serif text-[26px] font-semibold tabular-nums",
					children: loading ? "—" : fmtMoney(paid, currency)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-0.5 text-xs text-ink-soft",
					children: "Paid out"
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "rounded-lg border border-line bg-card p-5.5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-serif mb-4 text-[19px] font-semibold",
					children: "Your commissions"
				}),
				loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-24" }) : null,
				!loading && signedIn && rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "py-8 text-center text-sm text-ink-soft",
					children: "No referrals yet. Share a room's link from the Browse tab to start earning."
				}) : null,
				!loading && rows.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full border-collapse text-[13.5px]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "border-b border-line px-1.5 py-2 text-left text-xs font-medium text-ink-soft",
							children: "Room"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "border-b border-line px-1.5 py-2 text-left text-xs font-medium text-ink-soft",
							children: "Amount"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "border-b border-line px-1.5 py-2 text-left text-xs font-medium text-ink-soft",
							children: "Status"
						})
					] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "border-b border-line px-1.5 py-2.5",
							children: c.roomTitle || c.roomId
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "border-b border-line px-1.5 py-2.5 tabular-nums",
							children: fmtMoney(c.amount, c.currency)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "border-b border-line px-1.5 py-2.5",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, {
								tone: c.status === "paid" ? "paid" : "pending",
								children: c.status
							})
						})
					] }, c.id)) })]
				}) : null
			]
		})
	] });
}
function ListView({ rooms, mine, signedIn, loadingMine }) {
	const qc = useQueryClient();
	const [picked, setPicked] = (0, import_react.useState)("");
	const [posting, setPosting] = (0, import_react.useState)(false);
	const groups = (0, import_react.useMemo)(() => {
		const map = {};
		rooms.forEach((r) => {
			const area = (r.location || "").trim();
			if (area) map[area] = (map[area] || 0) + 1;
		});
		return Object.entries(map).map(([area, count]) => ({
			area,
			count
		}));
	}, [rooms]);
	async function onSubmit(e) {
		e.preventDefault();
		if (!signedIn) {
			toast("Sign in to post a listing.");
			return;
		}
		const location = picked.trim();
		if (!location) {
			toast("Tap a pin or type an area name.");
			return;
		}
		const fd = new FormData(e.currentTarget);
		const num = (key) => {
			const v = String(fd.get(key) || "").trim();
			return v === "" ? 0 : Number(v);
		};
		setPosting(true);
		try {
			await createRoom({ data: {
				title: String(fd.get("title") || ""),
				location,
				rent: num("rent"),
				currency: String(fd.get("currency") || ""),
				deposit: num("deposit"),
				availableFrom: String(fd.get("availableFrom") || ""),
				phone: String(fd.get("phone") || ""),
				whatsapp: String(fd.get("whatsapp") || ""),
				description: String(fd.get("description") || ""),
				commissionType: fd.get("commissionType") === "fixed" ? "fixed" : "percent",
				commissionValue: num("commissionValue"),
				renterCommissionType: fd.get("renterCommissionType") === "fixed" ? "fixed" : "percent",
				renterCommissionValue: num("renterCommissionValue")
			} });
			toast("Listing posted.");
			e.currentTarget.reset();
			setPicked("");
			await Promise.all([qc.invalidateQueries({ queryKey: ["rooms"] }), qc.invalidateQueries({ queryKey: ["my-rooms"] })]);
		} catch (err) {
			toast(errorMessage(err, "Couldn't post listing — try again."));
		} finally {
			setPosting(false);
		}
	}
	function downloadCsv() {
		if (!mine.length) {
			toast("You have no listings to download yet.");
			return;
		}
		const esc = (v) => `"${String(v ?? "").replace(/"/g, "\"\"")}"`;
		const header = [
			"Title",
			"Area",
			"Rent",
			"Currency",
			"Deposit",
			"Available from",
			"Status",
			"Phone",
			"WhatsApp",
			"Description"
		];
		const rows = mine.map((r) => [
			r.title,
			r.location,
			r.rent,
			r.currency,
			r.deposit,
			r.availableFrom,
			r.status,
			r.phone,
			r.whatsapp,
			r.description
		].map(esc).join(","));
		downloadTextFile("my-rentdirect-listings.csv", `\uFEFF${header.map(esc).join(",")}\n${rows.join("\n")}`);
		toast("Listings downloaded.");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mb-6.5 rounded-lg border border-line bg-card p-5.5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-serif mb-4 text-[19px] font-semibold",
				children: "Post a room"
			}),
			!signedIn ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-4 rounded-sm bg-paper-alt px-3 py-2.5 text-[13px] text-ink-soft",
				children: "Sign in to post a listing and get a trackable referral link."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
							htmlFor: "f-title",
							children: "Title"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "f-title",
							name: "title",
							required: true,
							placeholder: "e.g. Sunny single room near campus",
							disabled: !signedIn
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
								htmlFor: "f-area",
								children: "Room area"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-2 rounded-sm bg-paper-alt px-3 py-2.5 text-[13px] text-ink-soft",
								children: "Tap an existing area pin, or type a neighborhood. No street address needed."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PickAreaMap, {
								groups,
								picked,
								onPickExisting: setPicked
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "f-area",
								className: "mt-2",
								value: picked,
								onChange: (e) => setPicked(e.target.value),
								placeholder: "e.g. Thamel, Kathmandu",
								disabled: !signedIn
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-[13px] font-semibold text-ink-soft",
								children: picked ? `Picked: ${picked}` : "No area picked yet"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3.5 grid grid-cols-1 gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
							htmlFor: "f-rent",
							children: "Rent (per month)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "f-rent",
							name: "rent",
							type: "number",
							min: 0,
							step: "0.01",
							required: true,
							placeholder: "e.g. 8000",
							disabled: !signedIn
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
							htmlFor: "f-currency",
							children: "Currency"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "f-currency",
							name: "currency",
							defaultValue: "NPR",
							placeholder: "e.g. NPR, USD, INR",
							disabled: !signedIn
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3.5 grid grid-cols-1 gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
							htmlFor: "f-deposit",
							children: "Deposit (optional)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "f-deposit",
							name: "deposit",
							type: "number",
							min: 0,
							step: "0.01",
							placeholder: "e.g. 8000",
							disabled: !signedIn
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
							htmlFor: "f-available",
							children: "Available from (optional)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "f-available",
							name: "availableFrom",
							placeholder: "e.g. Oct 1, or 'now'",
							disabled: !signedIn
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3.5 grid grid-cols-1 gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
							htmlFor: "f-phone",
							children: "Owner phone (for Call)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "f-phone",
							name: "phone",
							required: true,
							placeholder: "+977 98XXXXXXXX",
							disabled: !signedIn
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
							htmlFor: "f-whatsapp",
							children: "WhatsApp number (optional)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "f-whatsapp",
							name: "whatsapp",
							placeholder: "Include country code",
							disabled: !signedIn
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-3.5 rounded-sm bg-paper-alt px-3 py-2.5 text-[13px] text-ink-soft",
						children: "Your number is never shown in full on Browse. Signed-in members reveal it only when they tap Call or WhatsApp."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
							htmlFor: "f-desc",
							children: "Description"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							id: "f-desc",
							name: "description",
							rows: 3,
							placeholder: "Room size, amenities, house rules…",
							disabled: !signedIn
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3.5 grid grid-cols-1 gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
							htmlFor: "f-comm-type",
							children: "Commission from owner (you)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(NativeSelect, {
							id: "f-comm-type",
							name: "commissionType",
							defaultValue: "percent",
							disabled: !signedIn,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "percent",
								children: "% of first month's rent"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "fixed",
								children: "Fixed amount"
							})]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
							htmlFor: "f-comm-value",
							children: "Amount you pay"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "f-comm-value",
							name: "commissionValue",
							type: "number",
							min: 0,
							step: "0.01",
							required: true,
							placeholder: "e.g. 10",
							defaultValue: "10",
							disabled: !signedIn
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3.5 grid grid-cols-1 gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
							htmlFor: "f-comm-type-renter",
							children: "Commission from renter (optional)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(NativeSelect, {
							id: "f-comm-type-renter",
							name: "renterCommissionType",
							defaultValue: "percent",
							disabled: !signedIn,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "percent",
								children: "% of first month's rent"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "fixed",
								children: "Fixed amount"
							})]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
							htmlFor: "f-comm-value-renter",
							children: "Amount the renter pays"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "f-comm-value-renter",
							name: "renterCommissionValue",
							type: "number",
							min: 0,
							step: "0.01",
							placeholder: "e.g. 0",
							disabled: !signedIn
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-4 rounded-sm bg-paper-alt px-3 py-2.5 text-[13px] text-ink-soft",
						children: "If you set a renter-side amount, it's shown upfront on the listing so the renter knows before they call — both amounts go to whoever referred the successful rental."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						variant: "brass",
						disabled: !signedIn || posting,
						children: posting ? "Posting…" : "Post listing"
					})
				]
			})
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-lg border border-line bg-card p-5.5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-serif mb-4 text-[19px] font-semibold",
				children: "Your listings"
			}),
			signedIn ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "sm",
				variant: "secondary",
				className: "mb-3.5",
				onClick: downloadCsv,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-3.5" }), "Download listings (CSV)"]
			}) : null,
			loadingMine ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-24" }) : null,
			!loadingMine && signedIn && mine.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "py-8 text-center text-sm text-ink-soft",
				children: "You haven't posted any rooms yet."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-3",
				children: mine.map((room) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MyListingCard, { room }, room.id))
			})
		]
	})] });
}
function MyListingCard({ room }) {
	const qc = useQueryClient();
	const [pickerOpen, setPickerOpen] = (0, import_react.useState)(false);
	const commission = computeCommission(room);
	const renterAmt = computeRenterCommission(room);
	const leadsQuery = useQuery({
		queryKey: ["leads", room.id],
		queryFn: () => listLeadsForRoom({ data: room.id }),
		enabled: pickerOpen
	});
	const commQuery = useQuery({
		queryKey: ["room-commissions", room.id],
		queryFn: () => listRoomCommissions({ data: room.id })
	});
	const invalidate = () => Promise.all([
		qc.invalidateQueries({ queryKey: ["rooms"] }),
		qc.invalidateQueries({ queryKey: ["my-rooms"] }),
		qc.invalidateQueries({ queryKey: ["room-commissions", room.id] }),
		qc.invalidateQueries({ queryKey: ["my-commissions"] })
	]);
	async function onDelete() {
		if (!window.confirm("Delete this listing? This can't be undone.")) return;
		try {
			await deleteRoom({ data: room.id });
			toast("Listing deleted.");
			await invalidate();
		} catch (err) {
			toast(errorMessage(err, "Couldn't delete — try again."));
		}
	}
	async function onReopen() {
		try {
			await reopenRoom({ data: room.id });
			toast("Listing reopened.");
			await invalidate();
		} catch (err) {
			toast(errorMessage(err, "Couldn't reopen — try again."));
		}
	}
	const [chosen, setChosen] = (0, import_react.useState)("");
	async function onConfirm() {
		try {
			const result = await confirmRented({ data: {
				roomId: room.id,
				referrerId: chosen || null
			} });
			toast(result.createdCommission ? "Marked as rented — commission created." : "Marked as rented.");
			setPickerOpen(false);
			await invalidate();
		} catch (err) {
			toast(errorMessage(err, "Something went wrong. Try again."));
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-md border border-line bg-card px-4 py-3.5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-baseline justify-between gap-2.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
					className: "font-serif text-base font-semibold",
					children: room.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, {
					tone: room.status === "rented" ? "rented" : "available",
					children: room.status === "rented" ? "Rented" : "Available"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-[12.5px] text-ink-soft",
				children: [
					room.location,
					" · ",
					fmtMoney(room.rent, room.currency),
					"/mo · total referral commission",
					" ",
					fmtMoney(commission, room.currency),
					renterAmt > 0 ? ` (${fmtMoney(renterAmt, room.currency)} billed to renter)` : ""
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2.5 flex flex-wrap gap-2",
				children: [room.status === "rented" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "secondary",
					onClick: () => void onReopen(),
					children: "Reopen listing"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "brass",
					onClick: () => {
						setPickerOpen((v) => !v);
						setChosen("");
					},
					children: "Mark as rented"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					variant: "secondary",
					onClick: () => void onDelete(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" }), "Delete"]
				})]
			}),
			pickerOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 border-t border-line pt-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-1.5 text-[12.5px] text-ink-soft",
					children: "Who found this room?"
				}), leadsQuery.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[12.5px] text-ink-soft",
					children: "Loading referrals…"
				}) : leadsQuery.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[12.5px] text-ink-soft",
					children: "Could not load referrals. Try again."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex min-h-11 items-center gap-2 text-[13.5px] font-normal text-ink",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "radio",
								name: `lead-${room.id}`,
								checked: chosen === "",
								onChange: () => setChosen("")
							}), "Direct — not via a referral"]
						}),
						(leadsQuery.data ?? []).map((lead) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex min-h-11 items-center gap-2 text-[13.5px] font-normal text-ink",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "radio",
									name: `lead-${room.id}`,
									checked: chosen === lead.referrerId,
									onChange: () => setChosen(lead.referrerId)
								}),
								"Referred by ",
								lead.name
							]
						}, lead.referrerId)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2.5 flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "brass",
								onClick: () => void onConfirm(),
								children: "Confirm rented"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "secondary",
								onClick: () => setPickerOpen(false),
								children: "Cancel"
							})]
						})
					]
				})]
			}) : null,
			(commQuery.data ?? []).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex items-center justify-between rounded-sm bg-paper-alt px-2.5 py-2 text-[13px]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Referral commission: ", fmtMoney(c.amount, c.currency)] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, {
						tone: c.status === "paid" ? "paid" : "pending",
						children: c.status
					}), c.status !== "paid" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "ghost",
						className: "min-h-8 px-2 text-xs",
						onClick: async () => {
							try {
								await markCommissionPaid({ data: c.id });
								toast("Marked as paid.");
								await qc.invalidateQueries({ queryKey: ["room-commissions", room.id] });
								await qc.invalidateQueries({ queryKey: ["my-commissions"] });
							} catch (err) {
								toast(errorMessage(err));
							}
						},
						children: "Mark paid"
					}) : null]
				})]
			}, c.id))
		]
	});
}
function Home() {
	const { tab, ref, room } = Route$2.useSearch();
	const navigate = Route$2.useNavigate();
	const { user, isPending } = useCurrentUserState();
	const signedIn = Boolean(user);
	(0, import_react.useEffect)(() => {
		captureReferral(ref, room);
	}, [ref, room]);
	const roomsQuery = useQuery({
		queryKey: ["rooms"],
		queryFn: () => listRooms()
	});
	const mineQuery = useQuery({
		queryKey: ["my-rooms", user?.id],
		queryFn: () => listMyRooms(),
		enabled: signedIn
	});
	const earnQuery = useQuery({
		queryKey: ["my-commissions", user?.id],
		queryFn: () => listMyCommissions(),
		enabled: signedIn,
		retry: (count, err) => !isUnauthorized(err) && count < 2
	});
	function setTab(next) {
		navigate({ search: (prev) => ({
			...prev,
			tab: next
		}) });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "sticky top-0 z-20 border-b border-line bg-paper/95 backdrop-blur-sm",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-5xl px-5 pt-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "font-serif text-[26px] font-semibold tracking-tight",
						children: ["Rent", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
							className: "italic text-brass-deep",
							children: "Direct"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-0.5 text-[13.5px] text-ink-soft",
						children: "Call the owner yourself. Earn when a room you shared gets rented."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex min-h-8 items-center",
						children: isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-8 w-28 animate-pulse rounded-full bg-ink/10" }) : user ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserButton, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/login",
							className: "inline-flex min-h-11 items-center rounded-md border border-line px-3 text-sm font-medium text-ink hover:bg-paper-alt",
							children: "Sign in"
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "mt-4 flex gap-1 overflow-x-auto",
					"aria-label": "Main",
					children: [
						["browse", "Browse rooms"],
						["list", "List a room"],
						["earnings", "My referrals & earnings"]
					].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setTab(id),
						className: cn("mr-5 shrink-0 border-b-2 px-1 py-2.5 text-[14.5px] font-medium whitespace-nowrap", tab === id ? "border-brass text-ink" : "border-transparent text-ink-soft hover:text-ink"),
						children: label
					}, id))
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto max-w-5xl px-5 pt-6 pb-20",
			children: [
				tab === "browse" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrowseView, {
					rooms: roomsQuery.data ?? [],
					loading: roomsQuery.isLoading,
					userId: user?.id ?? null,
					signedIn
				}) : null,
				tab === "list" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListView, {
					rooms: roomsQuery.data ?? [],
					mine: mineQuery.data ?? [],
					signedIn,
					loadingMine: signedIn && mineQuery.isLoading
				}) : null,
				tab === "earnings" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EarningsView, {
					rows: earnQuery.data ?? [],
					signedIn,
					loading: signedIn && earnQuery.isLoading
				}) : null
			]
		})]
	});
}
//#endregion
export { Home as component };
