import { o as __toESM } from "../_runtime.mjs";
import { Z as require_react, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as getServerFnById, i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { C as Cat, _ as Flower2, b as Coffee, c as Sparkles, f as Music, g as Gem, h as House, l as Shell, o as Sun, p as Moon, r as Users, s as Star, t as Youtube, v as Feather, w as Bird, x as Clover, y as Crown } from "../_libs/lucide-react.mjs";
import { t as authClient } from "./client-BhcLuWvF.mjs";
import { c as authMiddleware, h as roleLabel, i as ROLES, l as emailFor, m as parseYoutubeChannel, n as POST_KINDS, o as USER_RE } from "./model-Ck66RVeO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth-screens-DZe0plYT.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var getMe = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("10df2081b84e6bdb90c5972b72a41a145c7bdd994b51265b17fc5c525dc0c5e5"));
var createProfile = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(createSsrRpc("cf3a0f7fe9f59c5a6b493b6ac38790209e74bb78da907bf1aa3f322c33bc57fb"));
var updateProfile = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(createSsrRpc("39cf130be790703c237a038b6c549f38b272569365bc9817364bce59f45793b0"));
var getProfile = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(createSsrRpc("9ed34ca46dbede165b4089b01ff2af92b04dec2b12682fb1e88200069b4a88a6"));
var listConnections = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(createSsrRpc("6b6a3b41325c8db750c6913d16bdc8966820059d5e06aa20d5d748ad4261a0c1"));
var setFollow = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(createSsrRpc("df5dcafd3f887ee02840e103643b9be57f8f56cc7bbec0aaa13cf6efe21b0f16"));
var searchUsers = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(createSsrRpc("574d44646e0ff73b3f2993f0ef9ac16edd28322867424896bb8998ef48adb0ac"));
var listPosts = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(createSsrRpc("9542a8617c2ac7eb707b4e506da74d6221bb9e700e01fa09492261c903374c7c"));
var createPost = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(createSsrRpc("6e60f4de17398fa6ba06a08fa18838a053a78899dfc1a94a14db7431637432e1"));
var deletePost = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(createSsrRpc("38860f1f8afcd6ac8efd92bc29904b5d08857f59bba867350ec65396474aa30a"));
var setReaction = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(createSsrRpc("4729df184b7216d7fd2bdfc5e8e9d78dddb2fff8d7d111ff9cf178ab58f299aa"));
var listComments = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(createSsrRpc("3fb99b9f457e53f883694bd8e241e720476bc82c4ac0aa447b2508a13a457d02"));
var addComment = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(createSsrRpc("2fa458101dd0d7e9b00b0efe794a35708b2222b8d0591e9b5d51a17f4fc638e9"));
var deleteComment = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(createSsrRpc("d98ea40f758a0c2078be3bc1693b1e7af8781795d0d7bff4f1323f7723014dcb"));
var joinGroup = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(createSsrRpc("945e2591eb18ce912a8a81a1ae424da6ca4326c0bd73040b2fbd3051de0f9e29"));
var leaveGroup = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(createSsrRpc("f296d5c5dbe0b9a848405a84e2eb794aa5451335c16da8828375bb5d5cf25b5c"));
var listGroupMembers = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(createSsrRpc("3f4ab84a8464eed4bfa6af49416e9bba3471a6ea166a7ea7b3e0a56a5999869e"));
var ICONS = {
	gleam: Sparkles,
	crown: Crown,
	feather: Feather,
	gem: Gem,
	moon: Moon,
	bloom: Flower2,
	cat: Cat,
	star: Star,
	clover: Clover,
	note: Music,
	cup: Coffee,
	bird: Bird,
	shell: Shell,
	sun: Sun,
	users: Users,
	house: House
};
function MarkIcon({ name, className }) {
	const Icon = ICONS[name] ?? Sparkles;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
		className: className ?? "size-4",
		strokeWidth: 1.75,
		"aria-hidden": "true"
	});
}
function Avatar({ src, name, className }) {
	const frame = className ?? "size-11 text-base";
	if (src) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src,
		alt: "",
		className: `${frame} rounded-full object-cover`
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `${frame} grid place-items-center rounded-full bg-rose/10 font-display text-rose`,
		children: (name || "?").slice(0, 1).toUpperCase()
	});
}
function RolePill({ role }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: role === "creator" ? "rounded-full bg-rose px-2.5 py-0.5 text-xs font-medium text-paper" : "rounded-full bg-rose/10 px-2.5 py-0.5 text-xs font-medium text-rose",
		children: roleLabel(role)
	});
}
function KindPill({ kind }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "text-xs font-medium tracking-wide text-rose",
		children: POST_KINDS[kind].label
	});
}
var fieldClass = "w-full rounded-2xl bg-ivory px-4 text-base text-ink shadow-card outline-none placeholder:text-mute focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-rose";
var primaryBtn = "inline-flex min-h-11 items-center justify-center gap-2 rounded-full bg-rose px-5 text-sm font-medium text-paper transition-opacity hover:opacity-90 disabled:cursor-wait disabled:opacity-50";
var quietBtn = "inline-flex min-h-11 items-center justify-center gap-2 rounded-full bg-paper px-5 text-sm font-medium text-ink shadow-card transition-[box-shadow] hover:shadow-lift disabled:cursor-wait disabled:opacity-50";
function EmptyNote({ title, body }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-3xl bg-paper px-6 py-10 text-center shadow-card",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-2xl text-ink",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mx-auto mt-2 max-w-sm text-sm leading-6 text-mute",
			children: body
		})]
	});
}
function SkeletonCard() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "animate-pulse rounded-3xl bg-paper p-5 shadow-card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-11 rounded-full bg-ivory" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-3 w-28 rounded-full bg-ivory" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-3 w-16 rounded-full bg-ivory" })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-4 h-3 w-full rounded-full bg-ivory" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-2 h-3 w-4/5 rounded-full bg-ivory" })
		]
	});
}
/**
* Current user + loading state. Same behavior in live preview and when deployed:
*   - Auth enabled -> the real signed-in user; `user` is `null` while
*                            the session resolves (`isPending: true`) and when
*                            signed out (`isPending: false`). Session comes from
*                            Better Auth `useSession()` → `/api/auth/get-session`
*                            (cookie when deployed; bearer in live preview).
*   - Auth disabled (`VITE_AUTH_ENABLED=false`) -> `DEV_USER`, never pending.
*
* Protect a route by waiting out `isPending` before acting on `user` —
* redirecting on `user: null` alone bounces signed-in visitors to sign-in on
* every hard reload:
*
*   import { RedirectToSignIn } from "@/lib/auth/gates";
*   const { user, isPending } = useCurrentUserState();
*   if (isPending) return null;              // still resolving — don't redirect yet
*   if (!user) return <RedirectToSignIn />;  // definitely signed out
*
* `authEnabled` is a module-level constant fixed at load, so the guarded hook
* call keeps a stable hook order across every render of a given component.
*/
function useCurrentUserState() {
	return useSessionUserState();
}
function useSessionUserState() {
	const { data, isPending } = authClient.useSession();
	const id = data?.user.id;
	const displayName = data?.user.name ?? null;
	const primaryEmail = data?.user.email ?? null;
	const profileImageUrl = data?.user.image ?? null;
	const user = (0, import_react.useMemo)(() => id ? {
		id,
		displayName,
		primaryEmail,
		profileImageUrl,
		isDevFallback: false
	} : null, [
		id,
		displayName,
		primaryEmail,
		profileImageUrl
	]);
	return (0, import_react.useMemo)(() => ({
		user,
		isPending
	}), [user, isPending]);
}
/**
* Convenience view of `useCurrentUserState().user` for display (e.g.
* `user?.displayName ?? "Guest"`). NOTE: `null` means *loading OR signed out* —
* for redirects/guards use `useCurrentUserState()` and check `isPending`.
*/
function useCurrentUser() {
	return useCurrentUserState().user;
}
var BEARER_KEY = "grok-auth.bearer-token";
var DRAFT_KEY = "cg-draft";
function rememberToken(token) {
	if (!token || typeof window === "undefined") return;
	window.sessionStorage.setItem(BEARER_KEY, token);
}
async function authPost(path, body) {
	const res = await fetch(`/api/auth/${path}`, {
		method: "POST",
		headers: { "content-type": "application/json" },
		credentials: "include",
		body: JSON.stringify(body)
	});
	rememberToken(res.headers.get("set-auth-token"));
	const payload = await res.json().catch(() => ({}));
	return {
		ok: res.ok,
		status: res.status,
		payload
	};
}
function mapAuthError(status, payload, mode) {
	const code = payload.code ?? "";
	if (code.includes("PASSWORD_TOO_SHORT")) return "كلمة المرور قصيرة. ثمانية أحرف على الأقل.";
	if (code.includes("USER_ALREADY") || status === 422) return "اسم الحساب مستخدم. جرّب اسماً آخر أو سجّل الدخول.";
	if (status === 401 || code.includes("INVALID") || code.includes("PASSWORD")) return mode === "in" ? "اسم الحساب أو كلمة المرور غير صحيحة." : "تعذر إنشاء الحساب.";
	return mode === "in" ? "تعذر الدخول." : payload.message || "تعذر إنشاء الحساب.";
}
function saveDraft(draft) {
	if (typeof window === "undefined") return;
	window.sessionStorage.setItem(DRAFT_KEY, JSON.stringify(draft));
}
function readDraft() {
	if (typeof window === "undefined") return null;
	try {
		const raw = window.sessionStorage.getItem(DRAFT_KEY);
		if (!raw) return null;
		const parsed = JSON.parse(raw);
		if (!parsed.username || !parsed.youtubeUrl || !parsed.role) return null;
		return parsed;
	} catch {
		return null;
	}
}
function clearDraft() {
	if (typeof window === "undefined") return;
	window.sessionStorage.removeItem(DRAFT_KEY);
}
async function signUpAccount(draft, password) {
	saveDraft(draft);
	const res = await authPost("sign-up/email", {
		email: emailFor(draft.username),
		password,
		name: draft.username
	});
	if (!res.ok) return {
		ok: false,
		error: mapAuthError(res.status, res.payload, "up")
	};
	const profile = await createProfile({ data: {
		username: draft.username,
		youtubeUrl: draft.youtubeUrl,
		role: draft.role
	} });
	if (profile.ok) clearDraft();
	window.location.assign("/");
	return profile.ok ? { ok: true } : {
		ok: false,
		error: profile.error
	};
}
async function signInAccount(username, password) {
	const res = await authPost("sign-in/email", {
		email: emailFor(username),
		password
	});
	if (!res.ok) return {
		ok: false,
		error: mapAuthError(res.status, res.payload, "in")
	};
	window.location.assign("/");
	return { ok: true };
}
function Splash({ label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-dvh place-items-center px-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-widest text-mute",
					children: "SALON"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-display text-5xl text-ink",
					children: "CUTEGIRLS"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-mute",
					children: label ?? "نجهّز الصالون"
				})
			]
		})
	});
}
function LoginScreen() {
	const [mode, setMode] = (0, import_react.useState)("up");
	const [username, setUsername] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [confirm, setConfirm] = (0, import_react.useState)("");
	const [youtubeUrl, setYoutubeUrl] = (0, import_react.useState)("");
	const [role, setRole] = (0, import_react.useState)("listener");
	const [error, setError] = (0, import_react.useState)(null);
	const [pending, setPending] = (0, import_react.useState)(false);
	async function onSubmit(event) {
		event.preventDefault();
		setError(null);
		const name = username.trim();
		if (!USER_RE.test(name)) {
			setError("اسم الحساب من 3 إلى 24 حرفاً إنجليزياً، ويطابق اسم يوتيوب.");
			return;
		}
		if (password.length < 8) {
			setError("كلمة المرور ثمانية أحرف على الأقل.");
			return;
		}
		if (mode === "up") {
			if (password !== confirm) {
				setError("كلمتا المرور غير متطابقتين.");
				return;
			}
			const channel = parseYoutubeChannel(youtubeUrl);
			if (!channel) {
				setError("ضع رابط القناة هكذا: youtube.com/@username");
				return;
			}
			if (channel.handle.toLowerCase() !== name.toLowerCase()) {
				setError("اسم الحساب يجب أن يكون نفس الاسم بعد @ في يوتيوب.");
				return;
			}
		}
		setPending(true);
		try {
			const result = mode === "up" ? await signUpAccount({
				username: name,
				youtubeUrl,
				role
			}, password) : await signInAccount(name, password);
			if (!result.ok) setError(result.error);
		} catch (err) {
			setError(err instanceof Error ? err.message : "تعذر إتمام الطلب");
		} finally {
			setPending(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto grid min-h-dvh w-full max-w-6xl items-stretch gap-8 px-4 py-8 md:grid-cols-2 md:px-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "flex flex-col justify-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-widest text-rose",
					children: "CUTEGIRLS"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 max-w-md font-display text-4xl leading-tight text-ink md:text-5xl",
					children: "صالون هادئ، باسم قناتك"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-md text-sm leading-7 text-mute",
					children: "سجّل باسم يوتيوب نفسه. المنشورات ظاهرة للجميع، والمجموعة الشاملة مفتوحة لك منذ اللحظة الأولى."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit,
					className: "mt-8 max-w-md space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2 rounded-full bg-paper p-1 shadow-card",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: `min-h-11 rounded-full text-sm ${mode === "up" ? "bg-rose text-paper" : "text-mute"}`,
								onClick: () => setMode("up"),
								children: "حساب جديد"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: `min-h-11 rounded-full text-sm ${mode === "in" ? "bg-rose text-paper" : "text-mute"}`,
								onClick: () => setMode("in"),
								children: "دخول"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block space-y-1.5 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-mute",
								children: "اسم الحساب"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: `${fieldClass} h-12`,
								autoComplete: "username",
								dir: "ltr",
								placeholder: "yourchannel",
								value: username,
								onChange: (e) => setUsername(e.target.value)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block space-y-1.5 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-mute",
								children: "كلمة المرور"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: `${fieldClass} h-12`,
								type: "password",
								autoComplete: mode === "up" ? "new-password" : "current-password",
								dir: "ltr",
								value: password,
								onChange: (e) => setPassword(e.target.value)
							})]
						}),
						mode === "up" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block space-y-1.5 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-mute",
									children: "تأكيد كلمة المرور"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: `${fieldClass} h-12`,
									type: "password",
									autoComplete: "new-password",
									dir: "ltr",
									value: confirm,
									onChange: (e) => setConfirm(e.target.value)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block space-y-1.5 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-mute",
									children: "رابط قناة يوتيوب"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: `${fieldClass} h-12`,
									dir: "ltr",
									placeholder: "https://youtube.com/@yourchannel",
									value: youtubeUrl,
									onChange: (e) => setYoutubeUrl(e.target.value)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
									className: "text-sm text-mute",
									children: "الدور"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-2 gap-2",
									children: ROLES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => setRole(item.id),
										className: `min-h-20 rounded-3xl px-3 py-3 text-start shadow-card ${role === item.id ? "bg-rose text-paper" : "bg-paper text-ink"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block font-display text-xl",
											children: item.label
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `mt-1 block text-xs leading-5 ${role === item.id ? "text-paper/80" : "text-mute"}`,
											children: item.hint
										})]
									}, item.id))
								})]
							})
						] }) : null,
						error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-rose",
							children: error
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: `${primaryBtn} w-full`,
							type: "submit",
							disabled: pending,
							children: pending ? "لحظات…" : mode === "up" ? "إنشاء الحساب" : "دخول"
						})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "hidden flex-col justify-end rounded-3xl bg-ink p-8 text-paper md:flex",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-widest text-paper/60",
					children: "A QUIET ROOM"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 max-w-sm font-display text-4xl leading-tight",
					children: "فضفضة، مسابقة، معلومة، أو نشرة."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-8 space-y-4 text-sm leading-6 text-paper/75",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "لمسات بدل الإعجاب المعتاد: بريق، تاج، ريشة، ماسة، هلال، ورد." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "ملصقات داخل التعليقات، وشريط للريلز، ورف للسيبلمنال." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "أربع غرف: الشاملة، العائلة البيولوجية، اليانديري، والخاطب." })
					]
				})
			]
		})]
	});
}
function Onboard({ me, onDone }) {
	const [username, setUsername] = (0, import_react.useState)(me.accountUsername ?? "");
	const [youtubeUrl, setYoutubeUrl] = (0, import_react.useState)("");
	const [role, setRole] = (0, import_react.useState)("listener");
	const [error, setError] = (0, import_react.useState)(null);
	const [pending, setPending] = (0, import_react.useState)(false);
	const locked = Boolean(me.accountUsername);
	(0, import_react.useEffect)(() => {
		const draft = readDraft();
		if (!draft) return;
		if (!me.accountUsername || draft.username.toLowerCase() === me.accountUsername) {
			setUsername(draft.username);
			setYoutubeUrl(draft.youtubeUrl);
			setRole(draft.role);
		}
	}, [me.accountUsername]);
	async function onSubmit(event) {
		event.preventDefault();
		setPending(true);
		setError(null);
		try {
			const result = await createProfile({ data: {
				username: username.trim(),
				youtubeUrl,
				role
			} });
			if (!result.ok) {
				setError(result.error);
				return;
			}
			clearDraft();
			onDone();
		} catch (err) {
			setError(err instanceof Error ? err.message : "تعذر حفظ الملف");
		} finally {
			setPending(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-dvh w-full max-w-lg flex-col justify-center px-4 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-widest text-rose",
				children: "الملف"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-4xl",
				children: "أكمل بطاقتك"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm leading-6 text-mute",
				children: "الاسم الظاهر للناس هو اسم قناتك. من يزور حسابك يجد رابط يوتيوب."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit,
				className: "mt-6 space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block space-y-1.5 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-mute",
							children: "اسم الحساب"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: `${fieldClass} h-12`,
							dir: "ltr",
							value: username,
							readOnly: locked,
							onChange: (e) => setUsername(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block space-y-1.5 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-1.5 text-mute",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Youtube, {
								className: "size-4",
								"aria-hidden": "true"
							}), "رابط القناة"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: `${fieldClass} h-12`,
							dir: "ltr",
							placeholder: "https://youtube.com/@name",
							value: youtubeUrl,
							onChange: (e) => setYoutubeUrl(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-2",
						children: ROLES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setRole(item.id),
							className: `min-h-16 rounded-3xl px-3 text-start ${role === item.id ? "bg-rose text-paper" : "bg-paper text-ink shadow-card"}`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display text-xl",
								children: item.label
							})
						}, item.id))
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-rose",
						children: error
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: `${primaryBtn} w-full`,
						disabled: pending,
						type: "submit",
						children: pending ? "نحفظ…" : "دخول الصالون"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-center text-xs text-mute",
						children: "ستنضم تلقائياً إلى الجماعة الشاملة."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: `${quietBtn} mt-4`,
				onClick: () => void import("./client-BhcLuWvF.mjs").then((n) => n.n).then((n) => n.n).then((m) => m.signOut("/login")),
				children: "خروج"
			})
		]
	});
}
//#endregion
export { useCurrentUserState as A, primaryBtn as C, setReaction as D, setFollow as E, updateProfile as O, listPosts as S, searchUsers as T, joinGroup as _, MarkIcon as a, listConnections as b, SkeletonCard as c, createPost as d, deleteComment as f, getProfile as g, getMe as h, LoginScreen as i, useCurrentUser as k, Splash as l, fieldClass as m, EmptyNote as n, Onboard as o, deletePost as p, KindPill as r, RolePill as s, Avatar as t, addComment as u, leaveGroup as v, quietBtn as w, listGroupMembers as x, listComments as y };
