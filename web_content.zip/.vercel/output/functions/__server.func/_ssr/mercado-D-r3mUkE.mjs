//#region node_modules/.nitro/vite/services/ssr/assets/mercado-D-r3mUkE.js
var FONTE_EVENTOS = "https://login-abc-03-default-rtdb.firebaseio.com/bot/dados/eventos.json";
var ODD_MIN = 1.01;
var ODD_MAX = 80;
var MARGEM_MIN = .98;
var MARGEM_MAX = 1.25;
var HIST_MAX = 120;
var LIGAS = {
	"ita.1": "Serie A",
	"eng.1": "Premier League",
	"esp.1": "La Liga",
	"ger.1": "Bundesliga",
	"fra.1": "Ligue 1",
	"por.1": "Liga Portugal",
	"por.2": "Liga Portugal 2",
	"uefa.champions": "Champions League",
	"uefa.europa": "Europa League",
	"uefa.nations": "Nations League",
	"uefa.euro": "Euro",
	"bra.1": "Brasileirão",
	"bra.2": "Série B",
	"arg.1": "Liga Profesional",
	"ned.1": "Eredivisie",
	"usa.1": "MLS",
	"sco.1": "Scottish Premiership",
	"gre.1": "Super League",
	"per.1": "Liga 1 Peru",
	"col.1": "Liga BetPlay",
	"nor.1": "Eliteserien",
	"tur.1": "Süper Lig",
	"chn.1": "Super Liga China",
	"chi.1": "Primera Chile",
	"eng.fa": "FA Cup",
	"mex.1": "Liga MX",
	"bel.1": "Jupiler Pro League",
	"ksa.1": "Saudi Pro League",
	"jpn.1": "J1 League",
	"nbl": "NBL",
	"nba": "NBA",
	"atp": "ATP",
	"wta": "WTA"
};
function semAcentos(t) {
	return t.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
}
function numPt(n, casas = 2) {
	return n.toFixed(casas).replace(".", ",");
}
function nomeLiga(codigo) {
	const chave = String(codigo || "").trim();
	if (LIGAS[chave]) return LIGAS[chave];
	if (!chave) return "Competição";
	return chave.replace(/\./g, " · ").toUpperCase();
}
function normalizarDesporto(valor) {
	const d = semAcentos(String(valor || "futebol").trim());
	if (d.includes("basquete") || d.includes("basket")) return "basquete";
	if (d.includes("tenis") || d.includes("tennis")) return "tenis";
	return "futebol";
}
function rotuloDesporto(d) {
	if (d === "basquete") return "Basquete";
	if (d === "tenis") return "Tênis";
	return "Futebol";
}
function parseInicioMs(texto) {
	const t = String(texto ?? "").trim();
	const m = t.match(/^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})(?::(\d{2}))?(?:\.\d+)?\s*(Z|[+-]\d{2}(?::?\d{2})?)?$/i);
	if (!m) {
		const n = Date.parse(t);
		return Number.isFinite(n) ? n : NaN;
	}
	const [, y, mo, d, h, mi, s, tz] = m;
	let ms = Date.UTC(Number(y), Number(mo) - 1, Number(d), Number(h), Number(mi), Number(s || 0));
	if (tz && tz.toUpperCase() !== "Z") {
		const sinal = tz[0] === "-" ? -1 : 1;
		const dig = tz.slice(1).replace(":", "");
		const minutos = Number(dig.slice(0, 2)) * 60 + (dig.length > 2 ? Number(dig.slice(2, 4)) : 0);
		ms -= sinal * minutos * 6e4;
	}
	return ms;
}
function formatarDataHora(d) {
	const p = (n) => String(n).padStart(2, "0");
	return `${p(d.getDate())}/${p(d.getMonth() + 1)} · ${p(d.getHours())}:${p(d.getMinutes())}`;
}
function numOdd(v) {
	if (typeof v === "number") return Number.isFinite(v) && v >= ODD_MIN && v <= ODD_MAX ? v : null;
	if (typeof v !== "string") return null;
	const n = Number.parseFloat(v.trim().replace(",", "."));
	return Number.isFinite(n) && n >= ODD_MIN && n <= ODD_MAX ? n : null;
}
function lerOdds(e) {
	let casa = numOdd(e.odd_casa);
	let empate = numOdd(e.odd_empate);
	let fora = numOdd(e.odd_fora);
	if (typeof e.odds === "string" && e.odds.includes(":")) for (const parte of e.odds.split(";")) {
		const [k, v] = parte.split(":");
		const n = numOdd(v);
		if (!n || !k) continue;
		if (k.trim() === "odd_casa" && casa == null) casa = n;
		if (k.trim() === "odd_empate" && empate == null) empate = n;
		if (k.trim() === "odd_fora" && fora == null) fora = n;
	}
	return {
		casa,
		empate,
		fora
	};
}
function clamp01(n) {
	return Math.max(0, Math.min(1, n));
}
function jogoTerminado(e) {
	const st = String(e.estado_codigo || "").toUpperCase();
	return e.terminado === true || e.terminado === "true" || /FULL_TIME|FINISHED|ENDED|FINAL|STATUS_AFTER/.test(st);
}
function classificarFase(e) {
	if (jogoTerminado(e)) return "final";
	const st = String(e.estado_codigo || "").toUpperCase();
	if (!st || st === "STATUS_SCHEDULED" || /PROGRAMADO|AGENDADO/.test(st)) return "agendado";
	if (/POSTPONED|CANCEL|SUSPENDED|ABANDONED|DELAYED|FORFEIT/.test(st)) return "outro";
	return "live";
}
function lerMinuto(e) {
	if (String(e.estado_codigo || "").toUpperCase().includes("HALFTIME")) return "INT";
	const campos = [
		e.minuto,
		e.minutos,
		e.minuto_atual,
		e.relogio,
		e.clock,
		e.display_clock,
		e.displayClock,
		e.tempo_jogo,
		e.tempo,
		e.minute,
		e.estado
	];
	for (const c of campos) {
		if (c == null || c === "") continue;
		const t = String(c).trim();
		let m = t.match(/^(\d{1,3})\s*['’′]?(?:\s*\+\s*(\d{1,2})\s*['’′]?)?$/);
		if (m) return `${m[1]}'${m[2] ? `+${m[2]}` : ""}`;
		m = t.match(/^(\d{1,3}):\d{2}$/);
		if (m) return `${m[1]}'`;
	}
	return null;
}
function parNumero(c, f) {
	if (c == null || c === "" || f == null || f === "") return null;
	const nc = Number(c);
	const nf = Number(f);
	if (!Number.isFinite(nc) || !Number.isFinite(nf) || nc < 0 || nf < 0) return null;
	return {
		casa: nc,
		fora: nf
	};
}
function campo(e, chave) {
	return e[chave];
}
function lerPlacar(e) {
	const home = e.homeScore;
	const away = e.awayScore;
	const score = e.score;
	const pares = [
		[e.golos_casa, e.golos_fora],
		[e.golos_casa_final, e.golos_fora_final],
		[e.pontuacao_casa, e.pontuacao_fora],
		[e.score_casa, e.score_fora],
		[e.resultado_casa, e.resultado_fora],
		[e.home_score, e.away_score],
		[e.placar_casa, e.placar_fora],
		[home && typeof home === "object" ? campo(home, "current") : null, away && typeof away === "object" ? campo(away, "current") : null],
		[score && typeof score === "object" ? campo(score, "home") : null, score && typeof score === "object" ? campo(score, "away") : null]
	];
	for (const [c, f] of pares) {
		const p = parNumero(c, f);
		if (p) return p;
	}
	return null;
}
/** Mercado completo e margem da casa dentro do intervalo aceite. Sem isto, o jogo não existe no painel. */
function avaliarMercado(desporto, casaNome, foraNome, oddsIn) {
	const doisLados = desporto !== "futebol";
	const { casa, empate, fora } = oddsIn;
	if (casa == null || fora == null) return "sem-odds";
	if (!doisLados && empate == null) return "sem-odds";
	const margem = (doisLados ? [1 / casa, 1 / fora] : [
		1 / casa,
		1 / empate,
		1 / fora
	]).reduce((a, b) => a + b, 0);
	if (margem < MARGEM_MIN || margem > MARGEM_MAX) return "margem";
	const candidatos = [{
		lado: "casa",
		nome: casaNome,
		odd: casa,
		prob: 1 / casa / margem * 100
	}, {
		lado: "fora",
		nome: foraNome,
		odd: fora,
		prob: 1 / fora / margem * 100
	}];
	if (!doisLados && empate != null) candidatos.push({
		lado: "empate",
		nome: "Empate",
		odd: empate,
		prob: 1 / empate / margem * 100
	});
	const ordenados = [...candidatos].sort((a, b) => b.prob - a.prob || a.odd - b.odd);
	const melhor = ordenados[0];
	const segundo = ordenados[1];
	if (!melhor || !segundo) return "sem-odds";
	const prob = Math.round(melhor.prob);
	const segundoProb = Math.round(segundo.prob);
	const gap = prob - segundoProb;
	const probEmpate = doisLados ? null : Math.round(1 / empate / margem * 100);
	const falhas = falhasBlindado(melhor, prob, gap, margem, segundoProb, probEmpate);
	const score = indiceBlindagem(prob, gap, margem, segundoProb, melhor.odd, probEmpate, melhor.lado);
	let nivel = "lista";
	if (falhas.length === 0 && score >= 80) nivel = "blindado";
	else if (passaFirme(melhor, prob, gap, margem, segundoProb, probEmpate)) nivel = "firme";
	const motivos = [
		`Mercado dá ${prob}% ao favorito`,
		`Folga de ${gap} pts sobre ${segundo.nome} (${segundoProb}%)`,
		`Margem da casa ${numPt((margem - 1) * 100, 1)}%`
	];
	const probs = {
		casa: Math.round(1 / casa / margem * 100),
		empate: probEmpate,
		fora: Math.round(1 / fora / margem * 100)
	};
	return {
		lado: melhor.lado,
		nome: melhor.nome,
		tipoAposta: melhor.lado === "empate" ? "Resultado final" : "Vencedor do jogo",
		odd: melhor.odd,
		prob,
		gap,
		segundoNome: segundo.nome,
		segundoProb,
		margem,
		score,
		nivel,
		motivos,
		falhas,
		odds: {
			casa,
			empate: doisLados ? null : empate,
			fora
		},
		probs
	};
}
function falhasBlindado(melhor, prob, gap, margem, segundoProb, probEmpate) {
	const falhas = [];
	if (melhor.lado === "empate") falhas.push("O favorito é o empate — nunca é selo");
	if (prob < 76) falhas.push("Probabilidade abaixo de 76%");
	if (gap < 52) falhas.push("Folga curta para o 2.º resultado");
	if (melhor.odd < 1.12 || melhor.odd > 1.38) falhas.push("Odd fora da faixa 1,12–1,38");
	if (margem < 1.02 || margem > 1.14) falhas.push("Margem da casa fora de 2%–14%");
	if (segundoProb > 20) falhas.push("O 2.º resultado ainda pesa");
	if (probEmpate != null && probEmpate > 16) falhas.push("Empate demasiado vivo");
	return falhas;
}
function passaFirme(melhor, prob, gap, margem, segundoProb, probEmpate) {
	if (melhor.lado === "empate") return false;
	if (prob < 66 || gap < 36) return false;
	if (melhor.odd < 1.1 || melhor.odd > 1.55) return false;
	if (margem < 1.01 || margem > 1.16) return false;
	if (segundoProb > 28) return false;
	if (probEmpate != null && probEmpate > 24) return false;
	return true;
}
function indiceBlindagem(prob, gap, margem, segundoProb, odd, probEmpate, lado) {
	const pPart = clamp01((prob - 50) / 35) * 46;
	const gPart = clamp01(gap / 65) * 28;
	let mPart = 4;
	if (margem >= 1.02 && margem <= 1.12) mPart = 16;
	else if (margem >= 1 && margem <= 1.16) mPart = 10;
	let pen = 0;
	if (lado === "empate") pen += 30;
	if (segundoProb > 22) pen += 12;
	if (probEmpate != null && probEmpate > 18) pen += 10;
	if (odd < 1.12) pen += 8;
	if (odd > 1.45) pen += 14;
	if (margem > 1.16 || margem < 1.01) pen += 8;
	return Math.max(0, Math.min(100, Math.round(pPart + gPart + mPart + 10 - pen)));
}
function comoRegisto(valor) {
	if (!valor || typeof valor !== "object" || Array.isArray(valor)) return null;
	return valor;
}
function processar(dados, agora = Date.now()) {
	const rel = {
		recebidos: 0,
		comOdds: 0,
		semOdds: 0,
		margemInvalida: 0,
		dadosInvalidos: 0,
		duplicados: 0,
		foraDeCartaz: 0,
		jogos: [],
		finais: {},
		estados: {}
	};
	if (!dados || typeof dados !== "object") return rel;
	const vistos = /* @__PURE__ */ new Set();
	const rank = {
		agendado: 0,
		outro: 0,
		live: 1,
		final: 2
	};
	for (const bruto of Object.values(dados)) {
		const e = comoRegisto(bruto);
		if (!e) {
			rel.dadosInvalidos++;
			continue;
		}
		rel.recebidos++;
		const casa = String(e.equipa_casa || "").trim();
		const fora = String(e.equipa_fora || "").trim();
		if (!casa || !fora || casa === fora || !e.inicio) {
			rel.dadosInvalidos++;
			continue;
		}
		const inicioMs = parseInicioMs(e.inicio);
		if (!Number.isFinite(inicioMs)) {
			rel.dadosInvalidos++;
			continue;
		}
		const desporto = normalizarDesporto(e.desporto);
		const id = `${casa}|${fora}|${String(e.inicio)}`;
		const fase = classificarFase(e);
		const placar = lerPlacar(e);
		if (fase === "final" && placar) rel.finais[id] = placar;
		const anterior = rel.estados[id];
		if (!anterior || rank[fase] >= rank[anterior.fase]) rel.estados[id] = {
			fase,
			minuto: fase === "live" ? lerMinuto(e) : null,
			placar: fase === "agendado" ? null : placar,
			desporto
		};
		const avaliado = avaliarMercado(desporto, casa, fora, lerOdds(e));
		if (avaliado === "sem-odds") {
			rel.semOdds++;
			continue;
		}
		if (avaliado === "margem") {
			rel.margemInvalida++;
			continue;
		}
		rel.comOdds++;
		if (vistos.has(id)) {
			rel.duplicados++;
			continue;
		}
		vistos.add(id);
		if (fase !== "agendado" || inicioMs <= agora) {
			rel.foraDeCartaz++;
			continue;
		}
		const codigo = String(e.liga || "").trim();
		const tipoJogo = String(e.competicao || e["competição"] || "").trim() || (codigo ? nomeLiga(codigo) : "Competição");
		rel.jogos.push({
			id,
			inicio: String(e.inicio),
			inicioMs,
			liga: codigo || tipoJogo,
			ligaNome: codigo ? nomeLiga(codigo) : tipoJogo,
			desporto,
			desportoLabel: rotuloDesporto(desporto),
			equipaCasa: casa,
			equipaFora: fora,
			tipoJogo,
			categoria: String(e.categoria || ""),
			sets: String(e.sets || ""),
			sinal: avaliado
		});
	}
	return rel;
}
function filtrarJogos(jogos, filtros, agora = Date.now()) {
	const termo = semAcentos(filtros.termo.trim());
	const hoje = inicioDoDia(new Date(agora));
	const lista = jogos.filter((j) => {
		if (filtros.modo === "blindado" && j.sinal.nivel !== "blindado") return false;
		if (filtros.modo === "firme" && j.sinal.nivel === "lista") return false;
		if (filtros.desporto && j.desporto !== filtros.desporto) return false;
		if (filtros.liga && j.liga !== filtros.liga) return false;
		if (!passaData(j.inicioMs, filtros.data, hoje)) return false;
		if (!termo) return true;
		return semAcentos(`${j.equipaCasa} ${j.equipaFora} ${j.tipoJogo} ${j.sinal.nome}`).includes(termo);
	});
	lista.sort((a, b) => {
		if (filtros.ordem === "cedo") return a.inicioMs - b.inicioMs || b.sinal.score - a.sinal.score;
		return b.sinal.score - a.sinal.score || a.inicioMs - b.inicioMs;
	});
	return lista;
}
function inicioDoDia(d) {
	return new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
}
function passaData(inicioMs, filtro, hojeMs) {
	if (!filtro) return true;
	const dia = inicioDoDia(new Date(inicioMs));
	const diff = Math.round((dia - hojeMs) / 864e5);
	if (filtro === "hoje") return diff === 0;
	if (filtro === "amanha") return diff === 1;
	if (filtro === "semana") return diff >= 0 && diff < 7;
	return true;
}
function avaliarPalpite(item, placar) {
	if (placar.casa === placar.fora) {
		if (item.lado === "empate") return "ganhou";
		if (item.desporto !== "futebol") return "empurrou";
		return "perdeu";
	}
	if (item.lado === "casa") return placar.casa > placar.fora ? "ganhou" : "perdeu";
	if (item.lado === "fora") return placar.fora > placar.casa ? "ganhou" : "perdeu";
	return "perdeu";
}
function fundirHistorico(rel, historico, agora = Date.now()) {
	const next = historico.map((h) => ({ ...h }));
	const porId = new Map(next.map((h) => [h.id, h]));
	for (const jogo of rel.jogos) {
		if (jogo.sinal.nivel === "lista") continue;
		const existente = porId.get(jogo.id);
		if (!existente) {
			const item = {
				id: jogo.id,
				inicio: jogo.inicio,
				liga: jogo.ligaNome,
				tipoJogo: jogo.tipoJogo,
				desporto: jogo.desporto,
				equipaCasa: jogo.equipaCasa,
				equipaFora: jogo.equipaFora,
				palpiteNome: jogo.sinal.nome,
				lado: jogo.sinal.lado,
				tipoAposta: jogo.sinal.tipoAposta,
				prob: jogo.sinal.prob,
				oddUsada: jogo.sinal.odd,
				nivel: jogo.sinal.nivel,
				score: jogo.sinal.score,
				status: "pendente",
				resultado: null,
				registadoEm: agora
			};
			next.unshift(item);
			porId.set(jogo.id, item);
			continue;
		}
		if (existente.status !== "pendente") continue;
		existente.prob = jogo.sinal.prob;
		existente.oddUsada = jogo.sinal.odd;
		existente.palpiteNome = jogo.sinal.nome;
		existente.lado = jogo.sinal.lado;
		existente.tipoAposta = jogo.sinal.tipoAposta;
		existente.nivel = jogo.sinal.nivel;
		existente.score = jogo.sinal.score;
	}
	for (const h of next) {
		if (h.status !== "pendente") continue;
		const r = rel.finais[h.id];
		if (!r) continue;
		h.status = avaliarPalpite(h, r);
		h.resultado = r;
	}
	next.sort((a, b) => b.registadoEm - a.registadoEm);
	return next.slice(0, HIST_MAX);
}
function statsHistorico(historico, soBlindados = false) {
	let won = 0;
	let lost = 0;
	let pend = 0;
	let push = 0;
	for (const h of historico) {
		if (soBlindados && h.nivel !== "blindado") continue;
		if (h.status === "ganhou") won++;
		else if (h.status === "perdeu") lost++;
		else if (h.status === "empurrou") push++;
		else pend++;
	}
	const resolvidos = won + lost;
	const taxa = resolvidos ? Math.round(won / resolvidos * 100) : null;
	return {
		total: won + lost + pend + push,
		won,
		lost,
		pend,
		push,
		taxa,
		resolvidos
	};
}
function minutoEstimado(inicioMs, agora = Date.now()) {
	const dec = Math.floor((agora - inicioMs) / 6e4);
	if (dec < 1) return "1'";
	if (dec <= 45) return `${dec}'`;
	if (dec <= 60) return "INT";
	const m = dec - 15;
	return m <= 90 ? `${m}'` : "90'+";
}
var JANELA_LIVE = {
	futebol: 78e5,
	basquete: 102e5,
	tenis: 132e5
};
function estadoVisual(h, info, agora = Date.now()) {
	if (h.status === "ganhou") return {
		tipo: "won",
		minuto: null,
		placar: h.resultado
	};
	if (h.status === "perdeu") return {
		tipo: "lost",
		minuto: null,
		placar: h.resultado
	};
	if (h.status === "empurrou") return {
		tipo: "push",
		minuto: null,
		placar: h.resultado
	};
	const inicioMs = parseInicioMs(h.inicio);
	if (info?.fase === "live") return {
		tipo: "live",
		minuto: h.desporto === "futebol" ? info.minuto || minutoEstimado(inicioMs, agora) : info.minuto || "ao vivo",
		placar: info.placar
	};
	if ((!info || info.fase === "agendado") && Number.isFinite(inicioMs)) {
		const decorrido = agora - inicioMs;
		if (decorrido >= 0 && decorrido <= JANELA_LIVE[h.desporto]) return {
			tipo: "live",
			minuto: h.desporto === "futebol" ? minutoEstimado(inicioMs, agora) : "ao vivo",
			placar: null
		};
	}
	return {
		tipo: "pend",
		minuto: null,
		placar: null
	};
}
//#endregion
export { fundirHistorico as a, processar as c, formatarDataHora as i, statsHistorico as l, estadoVisual as n, nomeLiga as o, filtrarJogos as r, numPt as s, FONTE_EVENTOS as t };
