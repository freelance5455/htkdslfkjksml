import { w as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { f as cn } from "./store-CuJQmbYj.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/badge-Ct6gxEJd.js
var import_jsx_runtime = require_jsx_runtime();
function Badge({ className, tone = "default", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center rounded-full px-2.5 py-0.5 text-[11px] font-medium tracking-wide", tone === "default" && "bg-secondary text-secondary-foreground", tone === "primary" && "bg-primary/15 text-primary", tone === "success" && "bg-success/15 text-success", tone === "muted" && "bg-muted text-muted-foreground", className),
		...props
	});
}
//#endregion
export { Badge as t };
