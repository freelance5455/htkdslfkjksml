import { b as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as AppShell } from "./store-g4o8WGZx.mjs";
import { i as SheepForm } from "./forms-z1jNLbZu.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/new-sjaqNnmR.js
var import_jsx_runtime = require_jsx_runtime();
function NewSheepPage() {
	const navigate = useNavigate();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "رأس جديد",
		backTo: "/flock",
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "submit",
			form: "sheep-form",
			className: "text-sm font-medium",
			children: "حفظ"
		}),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheepForm, { onSaved: (id) => {
			navigate({
				to: "/sheep/$id",
				params: { id }
			});
		} })
	});
}
//#endregion
export { NewSheepPage as component };
