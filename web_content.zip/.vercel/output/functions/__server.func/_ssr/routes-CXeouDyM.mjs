import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { A as Check, C as History, D as Dumbbell, E as Flag, F as Bell, I as Banknote, L as Award, M as CalendarDays, N as Briefcase, O as CircleHelp, P as Bookmark, S as House, T as FolderOpen, _ as Newspaper, a as User, b as Menu, c as SquarePlus, d as Settings2, f as Send, g as Play, h as Plus, i as Users, j as ChartColumn, k as ChevronLeft, l as Shuffle, m as Save, n as VolumeX, o as Trophy, p as Search, r as Volume2, t as X, u as Shirt, v as Minus, w as Heart, x as Landmark, y as MessageCircle } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CXeouDyM.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SHIELD = "M50 5 L95 20 L95 62 Q95 100 50 115 Q5 100 5 62 L5 20 Z";
function ClubLogo({ team, size = 48, className }) {
	const id = "c" + team.id.replace(/[^a-z0-9]/g, "");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 100 120",
		width: size,
		height: Math.round(size * 1.2),
		className,
		"aria-hidden": true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("clipPath", {
				id,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: SHIELD })
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: SHIELD,
				fill: team.c1,
				stroke: "rgba(255,255,255,0.28)",
				strokeWidth: "2.4"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
				clipPath: "url(#" + id + ")",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "5",
						y: "5",
						width: "90",
						height: "110",
						fill: team.c1
					}),
					team.pattern === "ss" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
							x: "20",
							y: "5",
							width: "12",
							height: "110",
							fill: team.c2
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
							x: "44",
							y: "5",
							width: "12",
							height: "110",
							fill: team.c2
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
							x: "68",
							y: "5",
							width: "12",
							height: "110",
							fill: team.c2
						})
					] }),
					team.pattern === "sd" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M5 20 L95 115 L80 115 L5 35 Z",
						fill: team.c2
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M20 5 L95 85 L95 70 L35 5 Z",
						fill: team.c2
					})] }),
					team.pattern === "sh" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "5",
						y: "55",
						width: "90",
						height: "60",
						fill: team.c2
					}),
					team.pattern === "sc" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "44",
						y: "5",
						width: "12",
						height: "110",
						fill: team.c2
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "5",
						y: "52",
						width: "90",
						height: "12",
						fill: team.c2
					})] }),
					(team.pattern === "c" || team.pattern === "cr") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "50",
						cy: "52",
						r: "22",
						fill: team.c2
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: SHIELD,
				fill: "none",
				stroke: "rgba(0,0,0,0.35)",
				strokeWidth: "1.2"
			}),
			team.emblem === "star" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
				points: "50,28 54,40 67,40 56,48 60,60 50,52 40,60 44,48 33,40 46,40",
				fill: team.c2
			}),
			team.emblem === "crown" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M34 52 L34 40 L42 48 L50 34 L58 48 L66 40 L66 52 Z",
				fill: team.c2
			}),
			team.emblem === "eagle" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M50 34 C40 40 32 46 30 54 C40 50 44 52 50 60 C56 52 60 50 70 54 C68 46 60 40 50 34 Z",
				fill: team.c2
			}),
			team.emblem === "lion" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M42 38 C42 30 58 30 58 38 L60 50 C60 58 40 58 40 50 Z",
				fill: team.c2
			})
		]
	});
}
var SAVE_PREFIX = "fc_career_";
var POSITIONS = [
	{
		id: "GK",
		tr: "Kaleci",
		group: "Kaleci"
	},
	{
		id: "RB",
		tr: "Sag Bek",
		group: "Defans"
	},
	{
		id: "RWB",
		tr: "Sag Kanat Bek",
		group: "Defans"
	},
	{
		id: "CB",
		tr: "Stoper",
		group: "Defans"
	},
	{
		id: "LB",
		tr: "Sol Bek",
		group: "Defans"
	},
	{
		id: "LWB",
		tr: "Sol Kanat Bek",
		group: "Defans"
	},
	{
		id: "CDM",
		tr: "Defansif Orta Saha",
		group: "Orta"
	},
	{
		id: "CM",
		tr: "Merkez Orta Saha",
		group: "Orta"
	},
	{
		id: "CAM",
		tr: "Ofansif Orta Saha",
		group: "Orta"
	},
	{
		id: "RM",
		tr: "Sag Kanat Orta",
		group: "Orta"
	},
	{
		id: "LM",
		tr: "Sol Kanat Orta",
		group: "Orta"
	},
	{
		id: "RW",
		tr: "Sag Kanat",
		group: "Hucum"
	},
	{
		id: "LW",
		tr: "Sol Kanat",
		group: "Hucum"
	},
	{
		id: "CF",
		tr: "Geri Cekilmis Forvet",
		group: "Hucum"
	},
	{
		id: "ST",
		tr: "Santrafor",
		group: "Hucum"
	}
];
var POS_TR = Object.fromEntries(POSITIONS.map((p) => [p.id, p.tr]));
var COUNTRIES = [
	{
		id: "ENG",
		name: "England",
		flag: "ENG"
	},
	{
		id: "ESP",
		name: "Spain",
		flag: "ESP"
	},
	{
		id: "FRA",
		name: "France",
		flag: "FRA"
	},
	{
		id: "GER",
		name: "Germany",
		flag: "GER"
	},
	{
		id: "ITA",
		name: "Italy",
		flag: "ITA"
	},
	{
		id: "NED",
		name: "Netherlands",
		flag: "NED"
	},
	{
		id: "POR",
		name: "Portugal",
		flag: "POR"
	},
	{
		id: "BRA",
		name: "Brazil",
		flag: "BRA"
	},
	{
		id: "ARG",
		name: "Argentina",
		flag: "ARG"
	},
	{
		id: "TUR",
		name: "Turkiye",
		flag: "TUR"
	},
	{
		id: "AZE",
		name: "Azerbaijan",
		flag: "AZE"
	},
	{
		id: "BEL",
		name: "Belgium",
		flag: "BEL"
	},
	{
		id: "CRO",
		name: "Croatia",
		flag: "CRO"
	},
	{
		id: "DEN",
		name: "Denmark",
		flag: "DEN"
	},
	{
		id: "SWE",
		name: "Sweden",
		flag: "SWE"
	},
	{
		id: "NOR",
		name: "Norway",
		flag: "NOR"
	},
	{
		id: "POL",
		name: "Poland",
		flag: "POL"
	},
	{
		id: "JPN",
		name: "Japan",
		flag: "JPN"
	},
	{
		id: "KOR",
		name: "Korea",
		flag: "KOR"
	},
	{
		id: "USA",
		name: "USA",
		flag: "USA"
	},
	{
		id: "MEX",
		name: "Mexico",
		flag: "MEX"
	},
	{
		id: "MAR",
		name: "Morocco",
		flag: "MAR"
	},
	{
		id: "SEN",
		name: "Senegal",
		flag: "SEN"
	},
	{
		id: "NGA",
		name: "Nigeria",
		flag: "NGA"
	},
	{
		id: "GHA",
		name: "Ghana",
		flag: "GHA"
	}
];
var COUNTRY_NAME = Object.fromEntries(COUNTRIES.map((c) => [c.id, c.name]));
var ATTRIBUTE_GROUPS = [
	{
		id: "phy",
		tr: "Fiziksel",
		keys: [
			{
				key: "pace",
				tr: "Hiz"
			},
			{
				key: "acceleration",
				tr: "Ivme"
			},
			{
				key: "agility",
				tr: "Ceviklik"
			},
			{
				key: "balance",
				tr: "Denge"
			},
			{
				key: "jumping",
				tr: "Sicrama"
			},
			{
				key: "stamina",
				tr: "Dayaniklilik"
			},
			{
				key: "strength",
				tr: "Guc"
			},
			{
				key: "reactions",
				tr: "Reaksiyon"
			}
		]
	},
	{
		id: "tec",
		tr: "Teknik",
		keys: [
			{
				key: "ballControl",
				tr: "Top Kontrolu"
			},
			{
				key: "dribbling",
				tr: "Dribling"
			},
			{
				key: "firstTouch",
				tr: "Ilk Dokunus"
			},
			{
				key: "passing",
				tr: "Pas"
			},
			{
				key: "crossing",
				tr: "Orta"
			},
			{
				key: "heading",
				tr: "Kafa"
			},
			{
				key: "longShots",
				tr: "Uzaktan Sut"
			},
			{
				key: "volleys",
				tr: "Vole"
			},
			{
				key: "curve",
				tr: "Falso"
			},
			{
				key: "freeKick",
				tr: "Serbest Vurus"
			},
			{
				key: "penalties",
				tr: "Penalti"
			},
			{
				key: "longPassing",
				tr: "Uzun Pas"
			}
		]
	},
	{
		id: "men",
		tr: "Zihinsel",
		keys: [
			{
				key: "vision",
				tr: "Gorus"
			},
			{
				key: "composure",
				tr: "Sogukkanlilik"
			},
			{
				key: "decisions",
				tr: "Karar"
			},
			{
				key: "concentration",
				tr: "Konsantrasyon"
			},
			{
				key: "aggression",
				tr: "Agresiflik"
			},
			{
				key: "workRate",
				tr: "Is Bitirme"
			},
			{
				key: "teamwork",
				tr: "Takim Oyunu"
			},
			{
				key: "leadership",
				tr: "Liderlik"
			},
			{
				key: "flair",
				tr: "Yetenek Gosterisi"
			}
		]
	},
	{
		id: "def",
		tr: "Defans",
		keys: [
			{
				key: "tackling",
				tr: "Mudahale"
			},
			{
				key: "standingTackle",
				tr: "Ayakta Mudahale"
			},
			{
				key: "slidingTackle",
				tr: "Kayarak Mudahale"
			},
			{
				key: "interceptions",
				tr: "Top Kesme"
			},
			{
				key: "marking",
				tr: "Markaj"
			},
			{
				key: "defensiveAwareness",
				tr: "Defansif Farkindalik"
			}
		]
	},
	{
		id: "att",
		tr: "Hucum",
		keys: [
			{
				key: "finishing",
				tr: "Bitiricilik"
			},
			{
				key: "shotPower",
				tr: "Sut Gucu"
			},
			{
				key: "offTheBall",
				tr: "Topsuz Kosu"
			},
			{
				key: "attackPosition",
				tr: "Hucum Pozisyonu"
			},
			{
				key: "weakFoot",
				tr: "Zayif Ayak"
			}
		]
	},
	{
		id: "gk",
		tr: "Kalecilik",
		keys: [
			{
				key: "gkDiving",
				tr: "Kurtaris"
			},
			{
				key: "gkHandling",
				tr: "Top Tutma"
			},
			{
				key: "gkKicking",
				tr: "Uzaklastirma"
			},
			{
				key: "gkReflexes",
				tr: "Refleks"
			},
			{
				key: "gkPositioning",
				tr: "Kaleci Pozisyonu"
			}
		]
	}
];
var ALL_ATTRS = ATTRIBUTE_GROUPS.flatMap((g) => g.keys.map((k) => k.key));
var ALLOC_ATTRS = [
	"pace",
	"acceleration",
	"agility",
	"stamina",
	"strength",
	"jumping",
	"ballControl",
	"dribbling",
	"passing",
	"finishing",
	"firstTouch",
	"crossing",
	"shotPower",
	"heading",
	"vision",
	"composure",
	"decisions",
	"concentration",
	"workRate",
	"tackling",
	"interceptions",
	"marking",
	"defensiveAwareness",
	"standingTackle"
];
var ATTR_TR = Object.fromEntries(ATTRIBUTE_GROUPS.flatMap((g) => g.keys.map((k) => [k.key, k.tr])));
var POS_WEIGHTS = {
	GK: {
		gkDiving: 5,
		gkHandling: 5,
		gkReflexes: 5,
		gkPositioning: 4,
		gkKicking: 2,
		reactions: 3,
		composure: 2
	},
	CB: {
		marking: 4,
		tackling: 4,
		heading: 3,
		strength: 3,
		defensiveAwareness: 4,
		jumping: 2,
		composure: 2,
		passing: 1
	},
	RB: {
		pace: 3,
		stamina: 3,
		tackling: 3,
		crossing: 2,
		defensiveAwareness: 3,
		marking: 2,
		passing: 2,
		acceleration: 2
	},
	LB: {
		pace: 3,
		stamina: 3,
		tackling: 3,
		crossing: 2,
		defensiveAwareness: 3,
		marking: 2,
		passing: 2,
		acceleration: 2
	},
	RWB: {
		pace: 4,
		stamina: 4,
		crossing: 3,
		dribbling: 2,
		tackling: 2,
		passing: 2,
		acceleration: 2
	},
	LWB: {
		pace: 4,
		stamina: 4,
		crossing: 3,
		dribbling: 2,
		tackling: 2,
		passing: 2,
		acceleration: 2
	},
	CDM: {
		tackling: 4,
		interceptions: 4,
		passing: 3,
		stamina: 3,
		defensiveAwareness: 3,
		strength: 2,
		decisions: 2,
		marking: 2
	},
	CM: {
		passing: 4,
		stamina: 3,
		vision: 3,
		ballControl: 3,
		decisions: 3,
		tackling: 2,
		longPassing: 2,
		workRate: 2
	},
	CAM: {
		vision: 4,
		passing: 4,
		ballControl: 3,
		dribbling: 3,
		finishing: 2,
		composure: 2,
		flair: 2,
		longShots: 2
	},
	RM: {
		pace: 4,
		crossing: 3,
		dribbling: 3,
		passing: 3,
		stamina: 3,
		acceleration: 2,
		ballControl: 2
	},
	LM: {
		pace: 4,
		crossing: 3,
		dribbling: 3,
		passing: 3,
		stamina: 3,
		acceleration: 2,
		ballControl: 2
	},
	RW: {
		pace: 4,
		dribbling: 4,
		finishing: 3,
		crossing: 3,
		acceleration: 3,
		ballControl: 2,
		flair: 2
	},
	LW: {
		pace: 4,
		dribbling: 4,
		finishing: 3,
		crossing: 3,
		acceleration: 3,
		ballControl: 2,
		flair: 2
	},
	CF: {
		finishing: 4,
		ballControl: 3,
		vision: 3,
		offTheBall: 3,
		passing: 3,
		dribbling: 2,
		composure: 2,
		shotPower: 2
	},
	ST: {
		finishing: 5,
		shotPower: 4,
		offTheBall: 4,
		attackPosition: 3,
		heading: 3,
		pace: 3,
		composure: 2,
		strength: 2
	}
};
var ARCHETYPES = [
	{
		id: "box",
		tr: "Kutu Kutuya Orta Saha",
		pos: ["CM", "CDM"]
	},
	{
		id: "play",
		tr: "Oyun Kurucu",
		pos: ["CAM", "CM"]
	},
	{
		id: "winger",
		tr: "Kanat Oyuncusu",
		pos: [
			"LW",
			"RW",
			"LM",
			"RM"
		]
	},
	{
		id: "inside",
		tr: "Ic Forvet",
		pos: [
			"LW",
			"RW",
			"CF"
		]
	},
	{
		id: "target",
		tr: "Pivot Forvet",
		pos: ["ST", "CF"]
	},
	{
		id: "poacher",
		tr: "Golcu",
		pos: ["ST", "CF"]
	},
	{
		id: "press",
		tr: "Pres Forveti",
		pos: [
			"ST",
			"CF",
			"LW",
			"RW"
		]
	},
	{
		id: "destroyer",
		tr: "Top Kapici",
		pos: ["CDM", "CM"]
	},
	{
		id: "deep",
		tr: "Derin Oyun Kurucu",
		pos: ["CDM", "CM"]
	},
	{
		id: "wingback",
		tr: "Ofansif Bek",
		pos: [
			"LB",
			"RB",
			"LWB",
			"RWB"
		]
	},
	{
		id: "stopper",
		tr: "Kesici Stoper",
		pos: ["CB"]
	},
	{
		id: "sweeper",
		tr: "Supurucu Kaleci",
		pos: ["GK"]
	}
];
var PERSONALITIES = [
	{
		id: "professional",
		tr: "Profesyonel"
	},
	{
		id: "ambitious",
		tr: "Hirslı"
	},
	{
		id: "loyal",
		tr: "Sadik"
	},
	{
		id: "fiery",
		tr: "Atesli"
	},
	{
		id: "calm",
		tr: "Sakin"
	},
	{
		id: "determined",
		tr: "Kararli"
	}
];
var TRAINING_FOCI = [
	{
		id: "balanced",
		tr: "Dengeli",
		attrs: [
			"ballControl",
			"passing",
			"decisions",
			"stamina"
		]
	},
	{
		id: "attack",
		tr: "Hucum",
		attrs: [
			"finishing",
			"shotPower",
			"offTheBall",
			"dribbling"
		]
	},
	{
		id: "defense",
		tr: "Defans",
		attrs: [
			"tackling",
			"interceptions",
			"marking",
			"defensiveAwareness"
		]
	},
	{
		id: "physical",
		tr: "Fiziksel",
		attrs: [
			"strength",
			"stamina",
			"pace",
			"jumping"
		]
	},
	{
		id: "tech",
		tr: "Teknik",
		attrs: [
			"dribbling",
			"ballControl",
			"firstTouch",
			"passing"
		]
	},
	{
		id: "mental",
		tr: "Zihinsel",
		attrs: [
			"vision",
			"composure",
			"decisions",
			"concentration"
		]
	},
	{
		id: "recover",
		tr: "Toparlanma",
		attrs: []
	}
];
var INTENSITY = {
	low: {
		tr: "Dusuk",
		mult: .6,
		fatigue: 8
	},
	mid: {
		tr: "Orta",
		mult: 1,
		fatigue: 18
	},
	high: {
		tr: "Yuksek",
		mult: 1.6,
		fatigue: 30
	}
};
var HOMES = [
	{
		id: 0,
		tr: "Kiralik Daire",
		cost: 0
	},
	{
		id: 1,
		tr: "Sehir Dairesi",
		cost: 25e4
	},
	{
		id: 2,
		tr: "Banliyo Evi",
		cost: 8e5
	},
	{
		id: 3,
		tr: "Luks Malikane",
		cost: 3e6
	}
];
var CARS = [
	{
		id: 0,
		tr: "Araba Yok",
		cost: 0
	},
	{
		id: 1,
		tr: "Ikinci El",
		cost: 8e3
	},
	{
		id: 2,
		tr: "Spor Araba",
		cost: 9e4
	},
	{
		id: 3,
		tr: "Luks Sedan",
		cost: 25e4
	},
	{
		id: 4,
		tr: "Super Spor Koleksiyon",
		cost: 15e5
	}
];
var ACHIEVEMENTS = [
	{
		id: "first_match",
		tr: "Ilk Mac",
		desc: "Ilk macina cik"
	},
	{
		id: "first_goal",
		tr: "Ilk Gol",
		desc: "Ilk golunu at"
	},
	{
		id: "first_post",
		tr: "Ilk Paylasim",
		desc: "Sosyal paylasim yap"
	},
	{
		id: "1k",
		tr: "1K Takipci",
		desc: "1000 takipciye ulas"
	},
	{
		id: "verified",
		tr: "Dogrulanmis",
		desc: "10.000 takipciye ulas"
	},
	{
		id: "motm",
		tr: "Macin Adami",
		desc: "MOTM ol"
	},
	{
		id: "first_dm",
		tr: "Sosyal Kelebek",
		desc: "Ilk DM'ini gonder"
	},
	{
		id: "story",
		tr: "Hikaye Anlaticisi",
		desc: "Hikaye paylas"
	},
	{
		id: "married",
		tr: "Aile Babasi",
		desc: "Evlen"
	},
	{
		id: "mansion",
		tr: "Luks Hayat",
		desc: "Malikane al"
	}
];
var SCENES = [
	{
		id: "goal",
		tr: "GOL"
	},
	{
		id: "train",
		tr: "Antrenman"
	},
	{
		id: "matchday",
		tr: "Mac Gunu"
	},
	{
		id: "team",
		tr: "Takim"
	},
	{
		id: "life",
		tr: "Yasam"
	},
	{
		id: "deal",
		tr: "Anlasma"
	},
	{
		id: "cup",
		tr: "Kupa"
	},
	{
		id: "sign",
		tr: "Imza"
	},
	{
		id: "press",
		tr: "Basin"
	}
];
function attrCost(from, to) {
	if (to <= from) return 0;
	let c = 0;
	for (let v = from; v < to; v++) if (v < 65) c += 1;
	else if (v < 75) c += 2;
	else if (v < 85) c += 3;
	else c += 5;
	return c;
}
function fmtNum(n) {
	if (n >= 1e6) return (n / 1e6).toFixed(n >= 1e7 ? 0 : 1).replace(".0", "") + "M";
	if (n >= 1e4) return Math.round(n / 1e3) + "B";
	if (n >= 1e3) return (n / 1e3).toFixed(1).replace(".0", "") + "B";
	return String(Math.round(n));
}
function fmtMoney(n) {
	const abs = Math.abs(n);
	const sign = n < 0 ? "-" : "";
	if (abs >= 1e6) return sign + "£" + (abs / 1e6).toFixed(abs >= 1e7 ? 0 : 1).replace(".0", "") + "M";
	if (abs >= 1e3) return sign + "£" + Math.round(abs / 1e3) + "B";
	return sign + "£" + Math.round(abs);
}
function fmtFee(n) {
	if (n <= 0) return "Bedelsiz";
	if (n >= 1e6) return "€" + (n / 1e6).toFixed(n >= 1e7 ? 0 : 1).replace(".0", "") + "M";
	return "€" + Math.round(n / 1e3) + "B";
}
function cardTier(ovr) {
	if (ovr >= 90) return "legend";
	if (ovr >= 85) return "icon";
	if (ovr >= 78) return "gold";
	if (ovr >= 70) return "silver";
	return "bronze";
}
function attrColor(v) {
	if (v >= 90) return "var(--stat-legend)";
	if (v >= 80) return "var(--stat-gold)";
	if (v >= 70) return "var(--stat-ok)";
	if (v >= 60) return "var(--stat-mid)";
	return "var(--stat-low)";
}
function ratingColor(r) {
	if (r >= 8.5) return "var(--stat-legend)";
	if (r >= 7.5) return "var(--stat-gold)";
	if (r >= 6.5) return "var(--stat-ok)";
	if (r >= 5.5) return "var(--stat-mid)";
	return "var(--stat-low)";
}
function ageFromDob(dob, date) {
	const a = /* @__PURE__ */ new Date(dob + "T00:00:00");
	const b = /* @__PURE__ */ new Date(date + "T00:00:00");
	let age = b.getFullYear() - a.getFullYear();
	const m = b.getMonth() - a.getMonth();
	if (m < 0 || m === 0 && b.getDate() < a.getDate()) age -= 1;
	return age;
}
function addDays(iso, days) {
	const d = /* @__PURE__ */ new Date(iso + "T00:00:00");
	d.setDate(d.getDate() + days);
	const y = d.getFullYear();
	const m = String(d.getMonth() + 1).padStart(2, "0");
	const day = String(d.getDate()).padStart(2, "0");
	return y + "-" + m + "-" + day;
}
function trDate(iso) {
	const [y, m, d] = iso.split("-");
	return d + "." + m + "." + y;
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function PlayerCard({ player, date, compact }) {
	const tier = cardTier(player.overall);
	const age = ageFromDob(player.dob, date);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("relative overflow-hidden text-black shadow-[0_18px_40px_rgba(0,0,0,0.35)]", compact ? "rounded-[18px] p-3" : "rounded-[28px] p-4 sm:p-5", "card-" + tier),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute -right-4 top-2 font-display text-[88px] leading-none text-black/10",
				children: player.number
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-display text-[11px] uppercase tracking-[0.22em] text-black/55",
						children: tier
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: cn("font-display leading-none tracking-tight", compact ? "text-2xl" : "text-3xl sm:text-4xl"),
						children: player.displayName
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-1 text-[12px] font-medium text-black/65",
						children: [
							POS_TR[player.pos],
							" · ",
							COUNTRY_NAME[player.nat] || player.nat,
							" · ",
							age,
							" yas"
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-right",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: cn("font-display tabular-nums leading-none", compact ? "text-4xl" : "text-5xl"),
						children: player.overall
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[10px] font-semibold uppercase tracking-[0.18em] text-black/55",
						children: "OVR"
					})]
				})]
			}),
			!compact && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex gap-4 text-[12px] font-medium text-black/70",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["POT ", player.potential] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [player.height, " cm"] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: player.foot === "left" ? "Sol ayak" : "Sag ayak" })
				]
			})
		]
	});
}
function Btn({ tone = "ghost", className, children, ...rest }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: cn("inline-flex min-h-11 items-center justify-center gap-2 rounded-[12px] px-4 text-[15px] font-medium transition-colors duration-150 ease-out active:scale-[0.98]", tone === "primary" && "bg-accent text-accent-fg hover:bg-fg", tone === "ghost" && "bg-bg-soft text-fg hover:bg-bg-hover hairline", tone === "soft" && "bg-pitch-dim text-fg hover:bg-bg-hover", tone === "danger" && "bg-danger/15 text-danger hover:bg-danger/25", className),
		...rest,
		children
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-1.5 block text-[12px] font-medium uppercase tracking-[0.14em] text-muted",
			children: label
		}), children]
	});
}
function Input(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		...props,
		className: cn("h-11 w-full rounded-[12px] border border-line bg-bg-elev px-3 text-[15px] text-fg outline-none placeholder:text-subtle focus:border-line-strong", props.className)
	});
}
function Select(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
		...props,
		className: cn("h-11 w-full rounded-[12px] border border-line bg-bg-elev px-3 text-[15px] text-fg outline-none focus:border-line-strong", props.className)
	});
}
function StatBar({ label, value, max = 100, tone }) {
	const pct = Math.max(0, Math.min(100, value / max * 100));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-1 flex items-baseline justify-between text-[12px]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "tabular-nums text-fg",
			children: Math.round(value)
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-1.5 overflow-hidden rounded-full bg-bg-hover",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "h-full rounded-full",
			style: {
				width: pct + "%",
				background: tone || "var(--color-pitch)"
			}
		})
	})] });
}
function Panel({ children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: cn("rounded-[28px] bg-bg-elev p-4 hairline sm:p-5", className),
		children
	});
}
function Modal({ open, title, children, onClose }) {
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-end justify-center bg-black/60 p-3 sm:items-center",
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md rounded-[28px] bg-bg-elev p-5 hairline fade-up",
			onClick: (e) => e.stopPropagation(),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-3 font-display text-2xl",
				children: title
			}), children]
		})
	});
}
function t(rows) {
	return rows.map(([id, name, leagueId, power, c1, c2, pattern, emblem]) => ({
		id,
		name,
		leagueId,
		country: LEAGUES.find((l) => l.id === leagueId)?.country ?? "",
		power,
		c1,
		c2,
		pattern,
		emblem
	}));
}
var LEAGUES = [
	{
		id: "eng-prem",
		name: "Premier Division",
		country: "England",
		prestige: 5
	},
	{
		id: "eng-champ",
		name: "Championship",
		country: "England",
		prestige: 3
	},
	{
		id: "eng-l1",
		name: "National League One",
		country: "England",
		prestige: 2
	},
	{
		id: "eng-l2",
		name: "National League Two",
		country: "England",
		prestige: 1
	},
	{
		id: "esp-1",
		name: "Primera Division",
		country: "Spain",
		prestige: 5
	},
	{
		id: "esp-2",
		name: "Segunda Division",
		country: "Spain",
		prestige: 3
	},
	{
		id: "ger-1",
		name: "Bundesliga",
		country: "Germany",
		prestige: 5
	},
	{
		id: "ger-2",
		name: "2. Bundesliga",
		country: "Germany",
		prestige: 3
	},
	{
		id: "ita-1",
		name: "Serie A",
		country: "Italy",
		prestige: 5
	},
	{
		id: "ita-2",
		name: "Serie B",
		country: "Italy",
		prestige: 3
	},
	{
		id: "fra-1",
		name: "Ligue 1",
		country: "France",
		prestige: 5
	},
	{
		id: "fra-2",
		name: "Ligue 2",
		country: "France",
		prestige: 3
	},
	{
		id: "tur-1",
		name: "Super Lig",
		country: "Turkiye",
		prestige: 4
	},
	{
		id: "tur-2",
		name: "1. Lig",
		country: "Turkiye",
		prestige: 2
	},
	{
		id: "aze-1",
		name: "Premyer Liqa",
		country: "Azerbaijan",
		prestige: 2
	},
	{
		id: "aze-2",
		name: "Birinci Divizion",
		country: "Azerbaijan",
		prestige: 1
	},
	{
		id: "ned-1",
		name: "Eredivisie",
		country: "Netherlands",
		prestige: 4
	},
	{
		id: "por-1",
		name: "Primeira Liga",
		country: "Portugal",
		prestige: 4
	},
	{
		id: "bra-1",
		name: "Serie A",
		country: "Brazil",
		prestige: 4
	},
	{
		id: "arg-1",
		name: "Primera Division",
		country: "Argentina",
		prestige: 4
	},
	{
		id: "usa-1",
		name: "Major League",
		country: "USA",
		prestige: 3
	},
	{
		id: "bel-1",
		name: "Pro League",
		country: "Belgium",
		prestige: 3
	},
	{
		id: "sco-1",
		name: "Premiership",
		country: "Scotland",
		prestige: 3
	}
];
var TEAMS = t([
	[
		"man-sky",
		"Manchester Sky",
		"eng-prem",
		92,
		"#6CABDD",
		"#1C2C5B",
		"ss",
		"star"
	],
	[
		"man-red",
		"Manchester Red",
		"eng-prem",
		90,
		"#DA291C",
		"#FBE122",
		"s"
	],
	[
		"lon-gun",
		"London Gunners",
		"eng-prem",
		89,
		"#EF0107",
		"#9C824A",
		"s"
	],
	[
		"mer-red",
		"Merseyside Reds",
		"eng-prem",
		86,
		"#C8102E",
		"#00B2A9",
		"s"
	],
	[
		"lon-royal",
		"London Royal Blues",
		"eng-prem",
		85,
		"#034694",
		"#DBA111",
		"s"
	],
	[
		"n-lon-w",
		"North London Whites",
		"eng-prem",
		84,
		"#132257",
		"#FFFFFF",
		"s"
	],
	[
		"new-mag",
		"Newcastle Magpies",
		"eng-prem",
		83,
		"#241F20",
		"#FFFFFF",
		"ss"
	],
	[
		"bir-vil",
		"Birmingham Villans",
		"eng-prem",
		82,
		"#670E36",
		"#95BFE5",
		"s"
	],
	[
		"lon-ham",
		"London Hammers",
		"eng-prem",
		80,
		"#7A263A",
		"#1BB1E7",
		"s"
	],
	[
		"mer-blu",
		"Merseyside Blues",
		"eng-prem",
		79,
		"#003399",
		"#FFFFFF",
		"s"
	],
	[
		"bri-sea",
		"Brighton Seagulls",
		"eng-prem",
		77,
		"#0057B8",
		"#FFFFFF",
		"ss"
	],
	[
		"wol-wol",
		"Wolverhampton Wolves",
		"eng-prem",
		76,
		"#FDB913",
		"#231F20",
		"s"
	],
	[
		"not-for",
		"Nottingham Forest",
		"eng-prem",
		75,
		"#DD0000",
		"#FFFFFF",
		"s"
	],
	[
		"lon-eag",
		"London Eagles",
		"eng-prem",
		75,
		"#1B458F",
		"#C4122E",
		"sd"
	],
	[
		"lon-cot",
		"London Cottagers",
		"eng-prem",
		74,
		"#000000",
		"#FFFFFF",
		"s"
	],
	[
		"lon-bee",
		"London Bees",
		"eng-prem",
		74,
		"#E30613",
		"#FBB800",
		"ss"
	],
	[
		"lei-fox",
		"Leicester Foxes",
		"eng-prem",
		73,
		"#003090",
		"#FDBE11",
		"s"
	],
	[
		"bou-che",
		"Bournemouth Cherries",
		"eng-prem",
		72,
		"#DA291C",
		"#000000",
		"ss"
	],
	[
		"she-bla",
		"Sheffield Blades",
		"eng-prem",
		71,
		"#EE2737",
		"#000000",
		"ss"
	],
	[
		"ips-blu",
		"Ipswich Blues",
		"eng-prem",
		70,
		"#003399",
		"#FFFFFF",
		"s"
	],
	[
		"lee-whi",
		"Leeds Whites",
		"eng-champ",
		68,
		"#FFCD00",
		"#1D428A",
		"s"
	],
	[
		"sou-sai",
		"Southampton Saints",
		"eng-champ",
		67,
		"#D71920",
		"#130C0E",
		"ss"
	],
	[
		"nor-can",
		"Norwich Canaries",
		"eng-champ",
		66,
		"#FFF200",
		"#00A650",
		"s"
	],
	[
		"sun-cat",
		"Sunderland Cats",
		"eng-champ",
		66,
		"#EB172B",
		"#FFFFFF",
		"ss"
	],
	[
		"mid-bro",
		"Middlesbrough",
		"eng-champ",
		65,
		"#E11B22",
		"#FFFFFF",
		"s"
	],
	[
		"cov-sky",
		"Coventry Sky Blues",
		"eng-champ",
		64,
		"#69B3E7",
		"#1D428A",
		"s"
	],
	[
		"wba-thr",
		"West Brom Throstles",
		"eng-champ",
		64,
		"#122F67",
		"#FFFFFF",
		"ss"
	],
	[
		"hul-tig",
		"Hull Tigers",
		"eng-champ",
		63,
		"#F5A12D",
		"#000000",
		"s"
	],
	[
		"sto-pot",
		"Stoke Potters",
		"eng-champ",
		63,
		"#E03A3E",
		"#FFFFFF",
		"ss"
	],
	[
		"mil-lio",
		"Millwall Lions",
		"eng-champ",
		62,
		"#001F5B",
		"#FFFFFF",
		"s"
	],
	[
		"pre-lil",
		"Preston Lilywhites",
		"eng-champ",
		62,
		"#002F6C",
		"#FFFFFF",
		"s"
	],
	[
		"bri-rob",
		"Bristol Robins",
		"eng-champ",
		61,
		"#E21A23",
		"#FFFFFF",
		"s"
	],
	[
		"swa-swa",
		"Swansea Swans",
		"eng-champ",
		61,
		"#FFFFFF",
		"#000000",
		"s"
	],
	[
		"car-blu",
		"Cardiff Bluebirds",
		"eng-champ",
		60,
		"#0070B5",
		"#FFFFFF",
		"s"
	],
	[
		"wat-hor",
		"Watford Hornets",
		"eng-champ",
		60,
		"#FBEE23",
		"#11210C",
		"s"
	],
	[
		"qpr-hoo",
		"QPR Hoops",
		"eng-champ",
		59,
		"#1D5BA4",
		"#FFFFFF",
		"ss"
	],
	[
		"bur-cla",
		"Burnley Clarets",
		"eng-champ",
		59,
		"#6C1D45",
		"#99D6EA",
		"s"
	],
	[
		"por-blu",
		"Portsmouth Blue",
		"eng-champ",
		58,
		"#001489",
		"#FFFFFF",
		"s"
	],
	[
		"der-ram",
		"Derby Rams",
		"eng-champ",
		58,
		"#FFFFFF",
		"#000000",
		"s"
	],
	[
		"ply-arg",
		"Plymouth Argyle",
		"eng-champ",
		57,
		"#1A4731",
		"#FFFFFF",
		"s"
	],
	[
		"rea-roy",
		"Reading Royals",
		"eng-l1",
		56,
		"#004494",
		"#FFFFFF",
		"s"
	],
	[
		"bla-sea",
		"Blackpool Seasiders",
		"eng-l1",
		55,
		"#F68712",
		"#FFFFFF",
		"s"
	],
	[
		"wig-lat",
		"Wigan Latics",
		"eng-l1",
		55,
		"#1D6CB4",
		"#FFFFFF",
		"s"
	],
	[
		"bar-tyk",
		"Barnsley Tykes",
		"eng-l1",
		54,
		"#E41B23",
		"#FFFFFF",
		"s"
	],
	[
		"rot-mil",
		"Rotherham Millers",
		"eng-l1",
		54,
		"#C8102E",
		"#FFFFFF",
		"s"
	],
	[
		"cha-add",
		"Charlton Addicks",
		"eng-l1",
		54,
		"#D4021D",
		"#FFFFFF",
		"s"
	],
	[
		"bol-wan",
		"Bolton Wanderers",
		"eng-l1",
		53,
		"#FFFFFF",
		"#263473",
		"s"
	],
	[
		"pet-pos",
		"Peterborough Posh",
		"eng-l1",
		53,
		"#0054A4",
		"#FFFFFF",
		"s"
	],
	[
		"oxf-uni",
		"Oxford United",
		"eng-l1",
		52,
		"#FDB913",
		"#000000",
		"s"
	],
	[
		"lin-imp",
		"Lincoln Imps",
		"eng-l1",
		52,
		"#C41E3A",
		"#FFFFFF",
		"ss"
	],
	[
		"cam-uni",
		"Cambridge United",
		"eng-l1",
		51,
		"#F7B500",
		"#000000",
		"s"
	],
	[
		"shr-tow",
		"Shrewsbury Town",
		"eng-l1",
		51,
		"#FFD200",
		"#0033A0",
		"s"
	],
	[
		"wyc-wan",
		"Wycombe Wanderers",
		"eng-l1",
		50,
		"#78B22A",
		"#0033A0",
		"s"
	],
	[
		"bur-alb",
		"Burton Albion",
		"eng-l1",
		50,
		"#FDB913",
		"#000000",
		"s"
	],
	[
		"wre-xha",
		"Wrexham",
		"eng-l2",
		52,
		"#C8102E",
		"#FFFFFF",
		"s"
	],
	[
		"sto-cou",
		"Stockport County",
		"eng-l2",
		49,
		"#0047AB",
		"#FFFFFF",
		"s"
	],
	[
		"man-tow",
		"Mansfield Town",
		"eng-l2",
		48,
		"#FDB913",
		"#0033A0",
		"s"
	],
	[
		"not-cou",
		"Notts County",
		"eng-l2",
		48,
		"#000000",
		"#FFFFFF",
		"ss"
	],
	[
		"bra-cit",
		"Bradford City",
		"eng-l2",
		47,
		"#8B2500",
		"#FDB913",
		"s"
	],
	[
		"mad-bla",
		"Madrid Blancos",
		"esp-1",
		93,
		"#FFFFFF",
		"#FEBE10",
		"s",
		"crown"
	],
	[
		"bar-bla",
		"Barcelona Blaugrana",
		"esp-1",
		91,
		"#A50044",
		"#004D98",
		"ss"
	],
	[
		"mad-roj",
		"Madrid Rojiblancos",
		"esp-1",
		88,
		"#CE3524",
		"#FFFFFF",
		"ss"
	],
	[
		"bil-lio",
		"Bilbao Lions",
		"esp-1",
		82,
		"#EE2523",
		"#FFFFFF",
		"ss"
	],
	[
		"san-seb",
		"San Sebastian",
		"esp-1",
		81,
		"#0067B1",
		"#FFFFFF",
		"s"
	],
	[
		"vil-yel",
		"Villarreal Yellow",
		"esp-1",
		80,
		"#FFE667",
		"#005CA8",
		"s"
	],
	[
		"sev-rw",
		"Sevilla Red-Whites",
		"esp-1",
		79,
		"#D21033",
		"#FFFFFF",
		"s"
	],
	[
		"bet-ver",
		"Betis Verdiblancos",
		"esp-1",
		78,
		"#0BB363",
		"#FFFFFF",
		"ss"
	],
	[
		"val-bat",
		"Valencia Bats",
		"esp-1",
		77,
		"#EE3524",
		"#FFFFFF",
		"s"
	],
	[
		"gir-red",
		"Girona Reds",
		"esp-1",
		76,
		"#CD2534",
		"#FFFFFF",
		"ss"
	],
	[
		"osa-una",
		"Osasuna",
		"esp-1",
		74,
		"#D91A2A",
		"#002B5C",
		"s"
	],
	[
		"cel-sky",
		"Celta Sky",
		"esp-1",
		73,
		"#8AC5E2",
		"#E32219",
		"s"
	],
	[
		"ray-val",
		"Rayo Vallecano",
		"esp-1",
		72,
		"#FFFFFF",
		"#E20613",
		"ss"
	],
	[
		"mal-orc",
		"Mallorca",
		"esp-1",
		71,
		"#E20613",
		"#000000",
		"s"
	],
	[
		"get-blu",
		"Getafe Blue",
		"esp-1",
		70,
		"#004F9F",
		"#C90C0F",
		"s"
	],
	[
		"ala-ves",
		"Alaves",
		"esp-1",
		69,
		"#004B9D",
		"#FFFFFF",
		"ss"
	],
	[
		"las-pal",
		"Las Palmas",
		"esp-1",
		68,
		"#FFD100",
		"#0066B3",
		"s"
	],
	[
		"bar-esp",
		"Barcelona Espanyol",
		"esp-1",
		68,
		"#0072CE",
		"#FFFFFF",
		"ss"
	],
	[
		"val-lid",
		"Valladolid",
		"esp-1",
		66,
		"#7B2D8E",
		"#FFFFFF",
		"ss"
	],
	[
		"rac-san",
		"Racing Santander",
		"esp-2",
		64,
		"#0072CE",
		"#FFFFFF",
		"s"
	],
	[
		"lev-ant",
		"Levante",
		"esp-2",
		63,
		"#B1040E",
		"#0055A5",
		"ss"
	],
	[
		"mal-cos",
		"Malaga Costa",
		"esp-2",
		63,
		"#0066B3",
		"#E30613",
		"ss"
	],
	[
		"gra-nad",
		"Granada",
		"esp-2",
		62,
		"#E20613",
		"#FFFFFF",
		"ss"
	],
	[
		"spo-gij",
		"Sporting Gijon",
		"esp-2",
		62,
		"#E20613",
		"#FFFFFF",
		"ss"
	],
	[
		"zar-goz",
		"Zaragoza",
		"esp-2",
		61,
		"#FFFFFF",
		"#0038A8",
		"s"
	],
	[
		"dep-cor",
		"Deportivo La Coruna",
		"esp-2",
		61,
		"#0070B5",
		"#FFFFFF",
		"ss"
	],
	[
		"ovi-edo",
		"Oviedo",
		"esp-2",
		60,
		"#003DA5",
		"#FFFFFF",
		"s"
	],
	[
		"eib-ar",
		"Eibar",
		"esp-2",
		60,
		"#6B0F2B",
		"#005CA8",
		"ss"
	],
	[
		"hue-sca",
		"Huesca",
		"esp-2",
		59,
		"#E20613",
		"#003DA5",
		"ss"
	],
	[
		"cad-iz",
		"Cadiz",
		"esp-2",
		59,
		"#FDE100",
		"#003DA5",
		"s"
	],
	[
		"elc-he",
		"Elche",
		"esp-2",
		58,
		"#FFFFFF",
		"#007A33",
		"s"
	],
	[
		"alb-ace",
		"Albacete",
		"esp-2",
		58,
		"#FFFFFF",
		"#000000",
		"s"
	],
	[
		"bur-gos",
		"Burgos",
		"esp-2",
		57,
		"#FFFFFF",
		"#000000",
		"s"
	],
	[
		"alm-eri",
		"Almeria",
		"esp-2",
		57,
		"#E20613",
		"#FFFFFF",
		"ss"
	],
	[
		"mir-and",
		"Mirandes",
		"esp-2",
		56,
		"#E20613",
		"#000000",
		"s"
	],
	[
		"mun-red",
		"Munich Red",
		"ger-1",
		93,
		"#DC052D",
		"#FFFFFF",
		"s",
		"star"
	],
	[
		"lev-kus",
		"Leverkusen",
		"ger-1",
		86,
		"#E32219",
		"#000000",
		"s"
	],
	[
		"dor-yel",
		"Dortmund Yellow",
		"ger-1",
		86,
		"#FDE100",
		"#000000",
		"s"
	],
	[
		"lei-bul",
		"Leipzig Bulls",
		"ger-1",
		83,
		"#E30613",
		"#FFFFFF",
		"s"
	],
	[
		"stu-gar",
		"Stuttgart",
		"ger-1",
		80,
		"#FFFFFF",
		"#E30613",
		"ss"
	],
	[
		"fra-eag",
		"Frankfurt Eagles",
		"ger-1",
		79,
		"#E1000F",
		"#000000",
		"s"
	],
	[
		"hof-fen",
		"Hoffenheim",
		"ger-1",
		77,
		"#1C63B7",
		"#FFFFFF",
		"s"
	],
	[
		"fre-bur",
		"Freiburg",
		"ger-1",
		76,
		"#E30613",
		"#000000",
		"s"
	],
	[
		"wol-fsb",
		"Wolfsburg",
		"ger-1",
		75,
		"#65B32E",
		"#FFFFFF",
		"s"
	],
	[
		"bre-men",
		"Bremen",
		"ger-1",
		74,
		"#1D995A",
		"#FFFFFF",
		"s"
	],
	[
		"uni-ber",
		"Union Berlin",
		"ger-1",
		73,
		"#EB1923",
		"#F7E300",
		"s"
	],
	[
		"gla-db",
		"Gladbach",
		"ger-1",
		73,
		"#000000",
		"#FFFFFF",
		"ss"
	],
	[
		"mai-nz",
		"Mainz",
		"ger-1",
		72,
		"#C3102E",
		"#FFFFFF",
		"s"
	],
	[
		"aug-sbu",
		"Augsburg",
		"ger-1",
		71,
		"#C3102E",
		"#0077C0",
		"s"
	],
	[
		"boc-hum",
		"Bochum",
		"ger-1",
		69,
		"#005CA9",
		"#FFFFFF",
		"s"
	],
	[
		"hei-den",
		"Heidenheim",
		"ger-1",
		68,
		"#E30613",
		"#003DA5",
		"s"
	],
	[
		"st-pau",
		"St. Pauli",
		"ger-1",
		68,
		"#E30613",
		"#FFFFFF",
		"ss"
	],
	[
		"hol-kie",
		"Holstein Kiel",
		"ger-1",
		66,
		"#005CA9",
		"#E30613",
		"s"
	],
	[
		"ham-sv",
		"Hamburg SV",
		"ger-2",
		72,
		"#005CA9",
		"#FFFFFF",
		"s"
	],
	[
		"her-ber",
		"Hertha Berlin",
		"ger-2",
		68,
		"#005CA9",
		"#FFFFFF",
		"ss"
	],
	[
		"kol-n",
		"Koln",
		"ger-2",
		67,
		"#E30613",
		"#FFFFFF",
		"s"
	],
	[
		"for-dus",
		"Fortuna Dusseldorf",
		"ger-2",
		65,
		"#E30613",
		"#FFFFFF",
		"ss"
	],
	[
		"kai-ser",
		"Kaiserslautern",
		"ger-2",
		64,
		"#E30613",
		"#FFFFFF",
		"s"
	],
	[
		"han-96",
		"Hannover 96",
		"ger-2",
		64,
		"#007A33",
		"#000000",
		"s"
	],
	[
		"kar-sc",
		"Karlsruhe SC",
		"ger-2",
		63,
		"#005CA9",
		"#FFFFFF",
		"s"
	],
	[
		"nur-nbg",
		"Nurnberg",
		"ger-2",
		63,
		"#C3102E",
		"#FFFFFF",
		"s"
	],
	[
		"pad-erb",
		"Paderborn",
		"ger-2",
		62,
		"#005CA9",
		"#000000",
		"s"
	],
	[
		"dar-mst",
		"Darmstadt",
		"ger-2",
		61,
		"#005CA9",
		"#FFFFFF",
		"s"
	],
	[
		"gre-fur",
		"Greuther Furth",
		"ger-2",
		60,
		"#007A33",
		"#FFFFFF",
		"s"
	],
	[
		"bra-uns",
		"Braunschweig",
		"ger-2",
		59,
		"#FDE100",
		"#005CA9",
		"s"
	],
	[
		"mil-ner",
		"Milano Nerazzurri",
		"ita-1",
		90,
		"#010E80",
		"#000000",
		"ss",
		"star"
	],
	[
		"mil-ros",
		"Milano Rossoneri",
		"ita-1",
		86,
		"#FB090B",
		"#000000",
		"ss"
	],
	[
		"tor-bia",
		"Torino Bianconeri",
		"ita-1",
		86,
		"#000000",
		"#FFFFFF",
		"ss"
	],
	[
		"nap-azz",
		"Napoli Azzurri",
		"ita-1",
		85,
		"#12A0D7",
		"#FFFFFF",
		"s"
	],
	[
		"ber-gam",
		"Bergamo",
		"ita-1",
		83,
		"#1E71B8",
		"#000000",
		"ss"
	],
	[
		"rom-gia",
		"Roma Giallorossi",
		"ita-1",
		82,
		"#8E1F2F",
		"#F0BC42",
		"s"
	],
	[
		"rom-cel",
		"Roma Biancocelesti",
		"ita-1",
		80,
		"#87D8F7",
		"#FFFFFF",
		"ss"
	],
	[
		"fir-vio",
		"Firenze Viola",
		"ita-1",
		79,
		"#482E92",
		"#FFFFFF",
		"s"
	],
	[
		"bol-ogna",
		"Bologna",
		"ita-1",
		78,
		"#A21A23",
		"#1A1A1A",
		"ss"
	],
	[
		"tor-gra",
		"Torino Granata",
		"ita-1",
		76,
		"#8B1A1A",
		"#FFFFFF",
		"s"
	],
	[
		"udi-ne",
		"Udine",
		"ita-1",
		74,
		"#000000",
		"#FFFFFF",
		"ss"
	],
	[
		"gen-oa",
		"Genoa",
		"ita-1",
		73,
		"#C8102E",
		"#002F6C",
		"ss"
	],
	[
		"emp-oli",
		"Empoli",
		"ita-1",
		71,
		"#005CA9",
		"#FFFFFF",
		"s"
	],
	[
		"par-ma",
		"Parma",
		"ita-1",
		71,
		"#FDE100",
		"#005CA9",
		"s"
	],
	[
		"cag-lia",
		"Cagliari",
		"ita-1",
		70,
		"#A21A23",
		"#005CA9",
		"s"
	],
	[
		"ver-ona",
		"Verona",
		"ita-1",
		69,
		"#FDE100",
		"#005CA9",
		"s"
	],
	[
		"com-o",
		"Como",
		"ita-1",
		69,
		"#003DA5",
		"#FFFFFF",
		"s"
	],
	[
		"lec-ce",
		"Lecce",
		"ita-1",
		68,
		"#FDE100",
		"#C8102E",
		"ss"
	],
	[
		"ven-ezia",
		"Venezia",
		"ita-1",
		67,
		"#000000",
		"#F07A22",
		"s"
	],
	[
		"mon-za",
		"Monza",
		"ita-1",
		66,
		"#C8102E",
		"#FFFFFF",
		"s"
	],
	[
		"sas-suo",
		"Sassuolo",
		"ita-2",
		70,
		"#007A33",
		"#000000",
		"s"
	],
	[
		"sal-ern",
		"Salernitana",
		"ita-2",
		65,
		"#8B1A1A",
		"#FFFFFF",
		"s"
	],
	[
		"sam-pd",
		"Sampdoria",
		"ita-2",
		64,
		"#005CA9",
		"#FFFFFF",
		"s"
	],
	[
		"pal-erm",
		"Palermo",
		"ita-2",
		64,
		"#E4007C",
		"#000000",
		"ss"
	],
	[
		"cre-mon",
		"Cremonese",
		"ita-2",
		63,
		"#C8102E",
		"#9B1B30",
		"s"
	],
	[
		"pis-a",
		"Pisa",
		"ita-2",
		62,
		"#005CA9",
		"#000000",
		"ss"
	],
	[
		"spe-zia",
		"La Spezia",
		"ita-2",
		61,
		"#FFFFFF",
		"#000000",
		"s"
	],
	[
		"bar-i",
		"Bari",
		"ita-2",
		61,
		"#FFFFFF",
		"#C8102E",
		"s"
	],
	[
		"cat-anz",
		"Catanzaro",
		"ita-2",
		60,
		"#FDE100",
		"#C8102E",
		"s"
	],
	[
		"ces-ena",
		"Cesena",
		"ita-2",
		60,
		"#FFFFFF",
		"#000000",
		"s"
	],
	[
		"bre-sci",
		"Brescia",
		"ita-2",
		59,
		"#005CA9",
		"#FFFFFF",
		"s"
	],
	[
		"mod-ena",
		"Modena",
		"ita-2",
		58,
		"#FDE100",
		"#005CA9",
		"s"
	],
	[
		"par-sg",
		"Paris SG",
		"fra-1",
		92,
		"#004170",
		"#DA291C",
		"s",
		"star"
	],
	[
		"mon-aco",
		"Monaco",
		"fra-1",
		82,
		"#E30613",
		"#FFFFFF",
		"sd"
	],
	[
		"mar-sei",
		"Marseille",
		"fra-1",
		80,
		"#2FAEEA",
		"#FFFFFF",
		"s"
	],
	[
		"lil-le",
		"Lille",
		"fra-1",
		79,
		"#E30613",
		"#002F6C",
		"s"
	],
	[
		"lyo-n",
		"Lyon",
		"fra-1",
		78,
		"#003DA5",
		"#C8102E",
		"s"
	],
	[
		"nic-e",
		"Nice",
		"fra-1",
		77,
		"#C8102E",
		"#000000",
		"ss"
	],
	[
		"len-s",
		"Lens",
		"fra-1",
		76,
		"#FDE100",
		"#C8102E",
		"s"
	],
	[
		"ren-nes",
		"Rennes",
		"fra-1",
		75,
		"#C8102E",
		"#000000",
		"s"
	],
	[
		"rei-ms",
		"Reims",
		"fra-1",
		73,
		"#C8102E",
		"#FFFFFF",
		"s"
	],
	[
		"tou-lou",
		"Toulouse",
		"fra-1",
		72,
		"#5A2D82",
		"#FFFFFF",
		"s"
	],
	[
		"mon-pel",
		"Montpellier",
		"fra-1",
		71,
		"#F07A22",
		"#005CA9",
		"s"
	],
	[
		"str-asb",
		"Strasbourg",
		"fra-1",
		71,
		"#005CA9",
		"#FFFFFF",
		"s"
	],
	[
		"bre-st",
		"Brest",
		"fra-1",
		70,
		"#C8102E",
		"#FFFFFF",
		"s"
	],
	[
		"nan-tes",
		"Nantes",
		"fra-1",
		69,
		"#FDE100",
		"#007A33",
		"s"
	],
	[
		"aux-err",
		"Auxerre",
		"fra-1",
		68,
		"#FFFFFF",
		"#005CA9",
		"s"
	],
	[
		"ang-ers",
		"Angers",
		"fra-1",
		67,
		"#FFFFFF",
		"#000000",
		"ss"
	],
	[
		"hav-re",
		"Le Havre",
		"fra-1",
		67,
		"#005CA9",
		"#82C341",
		"s"
	],
	[
		"st-eti",
		"Saint-Etienne",
		"fra-1",
		66,
		"#007A33",
		"#FFFFFF",
		"s"
	],
	[
		"bor-dx",
		"Bordeaux",
		"fra-2",
		64,
		"#002F6C",
		"#FFFFFF",
		"s"
	],
	[
		"met-z",
		"Metz",
		"fra-2",
		63,
		"#8B1A1A",
		"#FFFFFF",
		"s"
	],
	[
		"bas-tia",
		"Bastia",
		"fra-2",
		61,
		"#005CA9",
		"#FFFFFF",
		"s"
	],
	[
		"gui-nga",
		"Guingamp",
		"fra-2",
		60,
		"#C8102E",
		"#000000",
		"s"
	],
	[
		"ami-ens",
		"Amiens",
		"fra-2",
		59,
		"#FFFFFF",
		"#000000",
		"s"
	],
	[
		"cle-rmt",
		"Clermont",
		"fra-2",
		59,
		"#C8102E",
		"#005CA9",
		"s"
	],
	[
		"gre-nob",
		"Grenoble",
		"fra-2",
		58,
		"#005CA9",
		"#FFFFFF",
		"s"
	],
	[
		"par-fc",
		"Paris FC",
		"fra-2",
		58,
		"#005CA9",
		"#FFFFFF",
		"s"
	],
	[
		"cae-n",
		"Caen",
		"fra-2",
		57,
		"#C8102E",
		"#005CA9",
		"s"
	],
	[
		"rod-ez",
		"Rodez",
		"fra-2",
		56,
		"#C8102E",
		"#FDE100",
		"s"
	],
	[
		"ist-asl",
		"Istanbul Aslanlar",
		"tur-1",
		83,
		"#FDB913",
		"#C8102E",
		"s",
		"lion"
	],
	[
		"ist-kan",
		"Istanbul Kanaryalar",
		"tur-1",
		81,
		"#FDE100",
		"#002F6C",
		"s"
	],
	[
		"ist-kar",
		"Istanbul Kartallar",
		"tur-1",
		80,
		"#000000",
		"#FFFFFF",
		"s",
		"eagle"
	],
	[
		"trb-fir",
		"Trabzon Firtina",
		"tur-1",
		78,
		"#6CB33F",
		"#5B2C8E",
		"sh"
	],
	[
		"ist-tur",
		"Istanbul Turuncu",
		"tur-1",
		75,
		"#F07A22",
		"#002F6C",
		"s"
	],
	[
		"ada-sim",
		"Adana Simsekler",
		"tur-1",
		72,
		"#F07A22",
		"#002F6C",
		"s"
	],
	[
		"sam-kb",
		"Samsun Kirmizi-Beyaz",
		"tur-1",
		71,
		"#C8102E",
		"#FFFFFF",
		"s"
	],
	[
		"kas-lac",
		"Kasimpasa Lacivert",
		"tur-1",
		70,
		"#002F6C",
		"#FFFFFF",
		"s"
	],
	[
		"ant-akr",
		"Antalya Akrepler",
		"tur-1",
		70,
		"#C8102E",
		"#FFFFFF",
		"s"
	],
	[
		"ala-yld",
		"Alanya Yildizlari",
		"tur-1",
		69,
		"#F07A22",
		"#007A33",
		"s"
	],
	[
		"kon-yes",
		"Konya Yesil",
		"tur-1",
		69,
		"#007A33",
		"#FFFFFF",
		"s"
	],
	[
		"kay-sk",
		"Kayseri Sari-Kirmizi",
		"tur-1",
		68,
		"#FDE100",
		"#C8102E",
		"s"
	],
	[
		"gaz-sah",
		"Gaziantep Sahinler",
		"tur-1",
		67,
		"#C8102E",
		"#000000",
		"s"
	],
	[
		"siv-yig",
		"Sivas Yigidolar",
		"tur-1",
		67,
		"#C8102E",
		"#FFFFFF",
		"s"
	],
	[
		"riz-kar",
		"Rize Karadeniz",
		"tur-1",
		66,
		"#007A33",
		"#005CA9",
		"s"
	],
	[
		"izm-goz",
		"Izmir Goztepe",
		"tur-1",
		66,
		"#FDE100",
		"#C8102E",
		"s"
	],
	[
		"eyu-mor",
		"Eyup Mor-Beyaz",
		"tur-1",
		65,
		"#5B2C8E",
		"#FFFFFF",
		"s"
	],
	[
		"bod-mav",
		"Bodrum Mavi",
		"tur-1",
		64,
		"#005CA9",
		"#FFFFFF",
		"s"
	],
	[
		"ank-guc",
		"Ankara Gucu",
		"tur-2",
		62,
		"#FDE100",
		"#000000",
		"s"
	],
	[
		"koc-ael",
		"Kocaeli",
		"tur-2",
		60,
		"#007A33",
		"#000000",
		"s"
	],
	[
		"bur-yes",
		"Bursa Yesil",
		"tur-2",
		60,
		"#007A33",
		"#FFFFFF",
		"s"
	],
	[
		"sak-arya",
		"Sakarya",
		"tur-2",
		58,
		"#007A33",
		"#000000",
		"s"
	],
	[
		"ban-dir",
		"Bandirma",
		"tur-2",
		57,
		"#C8102E",
		"#FFFFFF",
		"s"
	],
	[
		"erz-rum",
		"Erzurum",
		"tur-2",
		57,
		"#005CA9",
		"#FFFFFF",
		"s"
	],
	[
		"bol-u",
		"Bolu",
		"tur-2",
		56,
		"#C8102E",
		"#FFFFFF",
		"s"
	],
	[
		"man-isa",
		"Manisa",
		"tur-2",
		56,
		"#000000",
		"#FFFFFF",
		"s"
	],
	[
		"ank-genc",
		"Ankara Gencler",
		"tur-2",
		55,
		"#C8102E",
		"#000000",
		"s"
	],
	[
		"umr-aniye",
		"Umraniye",
		"tur-2",
		54,
		"#C8102E",
		"#FFFFFF",
		"s"
	],
	[
		"baki-qar",
		"Baki Qartal",
		"aze-1",
		68,
		"#005CA9",
		"#FFFFFF",
		"s",
		"eagle"
	],
	[
		"baki-nef",
		"Baki Neftci",
		"aze-1",
		66,
		"#000000",
		"#FFFFFF",
		"s"
	],
	[
		"baki-sab",
		"Baki Sabah",
		"aze-1",
		64,
		"#87CEEB",
		"#FFFFFF",
		"s"
	],
	[
		"baki-zir",
		"Baki Zira",
		"aze-1",
		62,
		"#F07A22",
		"#FFFFFF",
		"s"
	],
	[
		"sum-qay",
		"Sumqayit",
		"aze-1",
		60,
		"#8B1A1A",
		"#FFFFFF",
		"s"
	],
	[
		"tov-tur",
		"Tovuz Turan",
		"aze-1",
		58,
		"#C8102E",
		"#005CA9",
		"s"
	],
	[
		"nax-ara",
		"Naxcivan Araz",
		"aze-1",
		57,
		"#C8102E",
		"#007A33",
		"s"
	],
	[
		"baki-sbl",
		"Baki Sabail",
		"aze-1",
		56,
		"#005CA9",
		"#FFFFFF",
		"s"
	],
	[
		"sam-axi",
		"Samaxi",
		"aze-1",
		55,
		"#007A33",
		"#FFFFFF",
		"s"
	],
	[
		"gnc-kap",
		"Gence Kapaz",
		"aze-1",
		54,
		"#FDE100",
		"#005CA9",
		"s"
	],
	[
		"lok-bat",
		"Lokbatan",
		"aze-2",
		50,
		"#005CA9",
		"#FFFFFF",
		"s"
	],
	[
		"min-gac",
		"Mingacevir",
		"aze-2",
		49,
		"#C8102E",
		"#FFFFFF",
		"s"
	],
	[
		"zaq-ata",
		"Zaqatala",
		"aze-2",
		48,
		"#007A33",
		"#FFFFFF",
		"s"
	],
	[
		"sek-i",
		"Seki",
		"aze-2",
		47,
		"#5B2C8E",
		"#FFFFFF",
		"s"
	],
	[
		"imi-sli",
		"Imisli",
		"aze-2",
		47,
		"#F07A22",
		"#FFFFFF",
		"s"
	],
	[
		"gnc-2",
		"Gence-2",
		"aze-2",
		46,
		"#FDE100",
		"#005CA9",
		"s"
	],
	[
		"nef-2",
		"Neftci-2",
		"aze-2",
		46,
		"#000000",
		"#FFFFFF",
		"s"
	],
	[
		"sab-2",
		"Sabah-2",
		"aze-2",
		45,
		"#87CEEB",
		"#FFFFFF",
		"s"
	],
	[
		"ein-roo",
		"Eindhoven Rood",
		"ned-1",
		84,
		"#C8102E",
		"#FFFFFF",
		"s"
	],
	[
		"ams-wit",
		"Amsterdam Wit",
		"ned-1",
		82,
		"#D2122E",
		"#FFFFFF",
		"s"
	],
	[
		"rot-zui",
		"Rotterdam Zuid",
		"ned-1",
		78,
		"#C8102E",
		"#FFFFFF",
		"s"
	],
	[
		"alk-maar",
		"Alkmaar",
		"ned-1",
		76,
		"#C8102E",
		"#FFFFFF",
		"s"
	],
	[
		"twe-nte",
		"Twente",
		"ned-1",
		75,
		"#C8102E",
		"#FFFFFF",
		"s"
	],
	[
		"utr-cht",
		"Utrecht",
		"ned-1",
		73,
		"#C8102E",
		"#FFFFFF",
		"s"
	],
	[
		"hee-vee",
		"Heerenveen",
		"ned-1",
		71,
		"#005CA9",
		"#FFFFFF",
		"s"
	],
	[
		"nij-meg",
		"Nijmegen",
		"ned-1",
		70,
		"#C8102E",
		"#007A33",
		"s"
	],
	[
		"dev-ent",
		"Deventer",
		"ned-1",
		69,
		"#FDE100",
		"#000000",
		"s"
	],
	[
		"sit-tar",
		"Sittard",
		"ned-1",
		67,
		"#FDE100",
		"#007A33",
		"s"
	],
	[
		"rot-spa",
		"Rotterdam Sparta",
		"ned-1",
		67,
		"#C8102E",
		"#FFFFFF",
		"s"
	],
	[
		"gro-nin",
		"Groningen",
		"ned-1",
		66,
		"#007A33",
		"#FFFFFF",
		"s"
	],
	[
		"zwo-lle",
		"Zwolle",
		"ned-1",
		65,
		"#005CA9",
		"#FFFFFF",
		"s"
	],
	[
		"alm-elo",
		"Almelo",
		"ned-1",
		64,
		"#C8102E",
		"#FFFFFF",
		"s"
	],
	[
		"waa-lwk",
		"Waalwijk",
		"ned-1",
		63,
		"#FDE100",
		"#005CA9",
		"s"
	],
	[
		"alm-ere",
		"Almere",
		"ned-1",
		62,
		"#C8102E",
		"#005CA9",
		"s"
	],
	[
		"lis-agu",
		"Lisboa Aguias",
		"por-1",
		86,
		"#C8102E",
		"#FFFFFF",
		"s",
		"eagle"
	],
	[
		"por-dra",
		"Porto Dragoes",
		"por-1",
		85,
		"#003DA5",
		"#FFFFFF",
		"s"
	],
	[
		"lis-leo",
		"Lisboa Leoes",
		"por-1",
		85,
		"#007A33",
		"#FFFFFF",
		"s",
		"lion"
	],
	[
		"bra-ars",
		"Braga Arsenalistas",
		"por-1",
		78,
		"#C8102E",
		"#FFFFFF",
		"s"
	],
	[
		"gui-mar",
		"Guimaraes",
		"por-1",
		74,
		"#FFFFFF",
		"#000000",
		"s"
	],
	[
		"fam-ali",
		"Famalicao",
		"por-1",
		71,
		"#005CA9",
		"#FFFFFF",
		"s"
	],
	[
		"mor-eir",
		"Moreirense",
		"por-1",
		70,
		"#007A33",
		"#FFFFFF",
		"s"
	],
	[
		"aco-san",
		"Acores Santa",
		"por-1",
		69,
		"#C8102E",
		"#FFFFFF",
		"s"
	],
	[
		"gil-vic",
		"Gil Vicente",
		"por-1",
		68,
		"#C8102E",
		"#005CA9",
		"s"
	],
	[
		"est-orl",
		"Estoril",
		"por-1",
		67,
		"#FDE100",
		"#000000",
		"s"
	],
	[
		"cas-pia",
		"Casa Pia",
		"por-1",
		66,
		"#000000",
		"#FFFFFF",
		"s"
	],
	[
		"vil-con",
		"Vila do Conde",
		"por-1",
		65,
		"#005CA9",
		"#C8102E",
		"ss"
	],
	[
		"aro-uca",
		"Arouca",
		"por-1",
		64,
		"#FDE100",
		"#005CA9",
		"s"
	],
	[
		"mad-nac",
		"Madeira Nacional",
		"por-1",
		63,
		"#000000",
		"#FFFFFF",
		"ss"
	],
	[
		"ama-dor",
		"Amadora",
		"por-1",
		62,
		"#C8102E",
		"#FFFFFF",
		"s"
	],
	[
		"boa-vis",
		"Boavista",
		"por-1",
		62,
		"#000000",
		"#FFFFFF",
		"sc"
	],
	[
		"ver-pau",
		"Verdao Paulista",
		"bra-1",
		84,
		"#007A33",
		"#FFFFFF",
		"s"
	],
	[
		"rub-car",
		"Rubro-Negro Carioca",
		"bra-1",
		83,
		"#C8102E",
		"#000000",
		"ss"
	],
	[
		"est-car",
		"Estrela Carioca",
		"bra-1",
		82,
		"#C8102E",
		"#000000",
		"s"
	],
	[
		"lea-cea",
		"Leao do Ceara",
		"bra-1",
		78,
		"#C8102E",
		"#000000",
		"s"
	],
	[
		"col-gau",
		"Colorado Gaucho",
		"bra-1",
		78,
		"#C8102E",
		"#FFFFFF",
		"s"
	],
	[
		"tri-pau",
		"Tricolor Paulista",
		"bra-1",
		80,
		"#C8102E",
		"#000000",
		"ss"
	],
	[
		"rap-min",
		"Raposa Mineira",
		"bra-1",
		77,
		"#005CA9",
		"#FFFFFF",
		"s"
	],
	[
		"tri-bah",
		"Tricolor da Bahia",
		"bra-1",
		76,
		"#005CA9",
		"#C8102E",
		"s"
	],
	[
		"tim-pau",
		"Timao Paulista",
		"bra-1",
		81,
		"#000000",
		"#FFFFFF",
		"s"
	],
	[
		"gal-min",
		"Galo Mineiro",
		"bra-1",
		79,
		"#000000",
		"#FFFFFF",
		"s"
	],
	[
		"tri-gau",
		"Tricolor Gaucho",
		"bra-1",
		77,
		"#005CA9",
		"#000000",
		"s"
	],
	[
		"gig-col",
		"Gigante da Colina",
		"bra-1",
		76,
		"#000000",
		"#FFFFFF",
		"s"
	],
	[
		"tri-lar",
		"Tricolor das Laranjeiras",
		"bra-1",
		75,
		"#C8102E",
		"#007A33",
		"s"
	],
	[
		"fur-par",
		"Furacao Paranaense",
		"bra-1",
		74,
		"#C8102E",
		"#000000",
		"s"
	],
	[
		"mas-bru",
		"Massa Bruta",
		"bra-1",
		73,
		"#000000",
		"#FFFFFF",
		"s"
	],
	[
		"juv-ade",
		"Juventude",
		"bra-1",
		70,
		"#007A33",
		"#FFFFFF",
		"s"
	],
	[
		"mil-ba",
		"Millonario Buenos Aires",
		"arg-1",
		84,
		"#005CA9",
		"#FFFFFF",
		"s"
	],
	[
		"xen-ba",
		"Xeneize Buenos Aires",
		"arg-1",
		83,
		"#003DA5",
		"#FDE100",
		"s"
	],
	[
		"aca-ave",
		"Academia Avellaneda",
		"arg-1",
		80,
		"#82C341",
		"#FFFFFF",
		"s"
	],
	[
		"roj-ave",
		"Rojo Avellaneda",
		"arg-1",
		79,
		"#C8102E",
		"#FFFFFF",
		"s"
	],
	[
		"cue-ba",
		"Cuervo Buenos Aires",
		"arg-1",
		76,
		"#C8102E",
		"#005CA9",
		"s"
	],
	[
		"for-lin",
		"Fortin Liniers",
		"arg-1",
		75,
		"#005CA9",
		"#C8102E",
		"s"
	],
	[
		"tal-cor",
		"Talleres Cordoba",
		"arg-1",
		74,
		"#003DA5",
		"#FFFFFF",
		"s"
	],
	[
		"pin-lp",
		"Pincha La Plata",
		"arg-1",
		74,
		"#C8102E",
		"#FFFFFF",
		"ss"
	],
	[
		"lep-ros",
		"Leproso Rosario",
		"arg-1",
		73,
		"#C8102E",
		"#005CA9",
		"s"
	],
	[
		"can-ros",
		"Canalla Rosario",
		"arg-1",
		73,
		"#005CA9",
		"#FDE100",
		"s"
	],
	[
		"gra-lan",
		"Granate Lanus",
		"arg-1",
		72,
		"#6B1A2A",
		"#FFFFFF",
		"s"
	],
	[
		"bic-pat",
		"Bicho La Paternal",
		"arg-1",
		71,
		"#C8102E",
		"#FFFFFF",
		"s"
	],
	[
		"glo-ba",
		"Globo Buenos Aires",
		"arg-1",
		70,
		"#C8102E",
		"#FFFFFF",
		"s"
	],
	[
		"hal-flo",
		"Halcon Florencio",
		"arg-1",
		69,
		"#C8102E",
		"#000000",
		"s"
	],
	[
		"pir-cor",
		"Pirata Cordoba",
		"arg-1",
		68,
		"#005CA9",
		"#C8102E",
		"s"
	],
	[
		"tom-men",
		"Tomba Mendoza",
		"arg-1",
		67,
		"#005CA9",
		"#FDE100",
		"s"
	],
	[
		"mia-pnk",
		"Miami Pink",
		"usa-1",
		80,
		"#F7B5CD",
		"#000000",
		"s"
	],
	[
		"la-blk",
		"Los Angeles Black",
		"usa-1",
		78,
		"#000000",
		"#C4A15A",
		"s"
	],
	[
		"la-gal",
		"Los Angeles Galaxy",
		"usa-1",
		76,
		"#00245D",
		"#C4A15A",
		"s"
	],
	[
		"sea-eme",
		"Seattle Emerald",
		"usa-1",
		75,
		"#5D9732",
		"#005CA9",
		"s"
	],
	[
		"col-cre",
		"Columbus Crew",
		"usa-1",
		74,
		"#FDE100",
		"#000000",
		"s"
	],
	[
		"cin-ora",
		"Cincinnati Orange",
		"usa-1",
		73,
		"#F07A22",
		"#005CA9",
		"s"
	],
	[
		"phi-uni",
		"Philadelphia Union",
		"usa-1",
		73,
		"#002F6C",
		"#C4A15A",
		"s"
	],
	[
		"atl-uni",
		"Atlanta United",
		"usa-1",
		72,
		"#A32035",
		"#000000",
		"s"
	],
	[
		"por-tim",
		"Portland Timbers",
		"usa-1",
		72,
		"#004812",
		"#C4A15A",
		"s"
	],
	[
		"nyc-ity",
		"New York City",
		"usa-1",
		71,
		"#6CABDD",
		"#002F6C",
		"s"
	],
	[
		"ny-bul",
		"New York Bulls",
		"usa-1",
		70,
		"#C8102E",
		"#FFFFFF",
		"s"
	],
	[
		"aus-fc",
		"Austin FC",
		"usa-1",
		70,
		"#00B140",
		"#000000",
		"s"
	],
	[
		"nas-sc",
		"Nashville SC",
		"usa-1",
		69,
		"#FDE100",
		"#002F6C",
		"s"
	],
	[
		"tor-nor",
		"Toronto North",
		"usa-1",
		68,
		"#C8102E",
		"#6B1A2A",
		"s"
	],
	[
		"orl-cit",
		"Orlando City",
		"usa-1",
		68,
		"#5B2C8E",
		"#C4A15A",
		"s"
	],
	[
		"cha-fc",
		"Charlotte FC",
		"usa-1",
		67,
		"#005CA9",
		"#FFFFFF",
		"s"
	],
	[
		"bru-bla",
		"Brugge Blauw",
		"bel-1",
		80,
		"#005CA9",
		"#000000",
		"s"
	],
	[
		"uni-sg",
		"Union Sint-Gillis",
		"bel-1",
		78,
		"#FDE100",
		"#005CA9",
		"s"
	],
	[
		"bru-paa",
		"Brussels Paars",
		"bel-1",
		77,
		"#5B2C8E",
		"#FFFFFF",
		"s"
	],
	[
		"gen-bla",
		"Genk Blauw",
		"bel-1",
		76,
		"#005CA9",
		"#FFFFFF",
		"s"
	],
	[
		"ant-wer",
		"Antwerpen",
		"bel-1",
		75,
		"#C8102E",
		"#FFFFFF",
		"s"
	],
	[
		"gen-t",
		"Gent",
		"bel-1",
		74,
		"#005CA9",
		"#FFFFFF",
		"s"
	],
	[
		"lui-roo",
		"Luik Rood",
		"bel-1",
		73,
		"#C8102E",
		"#FFFFFF",
		"s"
	],
	[
		"bru-gro",
		"Brugge Groen",
		"bel-1",
		72,
		"#007A33",
		"#000000",
		"s"
	],
	[
		"mec-hel",
		"Mechelen",
		"bel-1",
		70,
		"#FDE100",
		"#C8102E",
		"s"
	],
	[
		"cha-ler",
		"Charleroi",
		"bel-1",
		69,
		"#000000",
		"#FFFFFF",
		"ss"
	],
	[
		"wes-ter",
		"Westerlo",
		"bel-1",
		68,
		"#FDE100",
		"#005CA9",
		"s"
	],
	[
		"sin-tru",
		"Sint-Truiden",
		"bel-1",
		67,
		"#FDE100",
		"#005CA9",
		"s"
	],
	[
		"leu-ven",
		"Leuven",
		"bel-1",
		66,
		"#FFFFFF",
		"#005CA9",
		"s"
	],
	[
		"kor-trk",
		"Kortrijk",
		"bel-1",
		65,
		"#C8102E",
		"#FFFFFF",
		"s"
	],
	[
		"bee-rsc",
		"Beerschot",
		"bel-1",
		64,
		"#5B2C8E",
		"#FFFFFF",
		"s"
	],
	[
		"den-lee",
		"Denderleeuw",
		"bel-1",
		63,
		"#005CA9",
		"#000000",
		"s"
	],
	[
		"gla-gro",
		"Glasgow Groen",
		"sco-1",
		82,
		"#007A33",
		"#FFFFFF",
		"s"
	],
	[
		"gla-bla",
		"Glasgow Blauw",
		"sco-1",
		81,
		"#003DA5",
		"#C8102E",
		"s"
	],
	[
		"edi-har",
		"Edinburgh Hart",
		"sco-1",
		72,
		"#8B1A1A",
		"#FFFFFF",
		"s"
	],
	[
		"abe-rde",
		"Aberdeen",
		"sco-1",
		71,
		"#C8102E",
		"#FFFFFF",
		"s"
	],
	[
		"edi-hib",
		"Edinburgh Hibernian",
		"sco-1",
		70,
		"#007A33",
		"#FFFFFF",
		"s"
	],
	[
		"dun-utd",
		"Dundee United",
		"sco-1",
		68,
		"#F07A22",
		"#000000",
		"s"
	],
	[
		"pai-sley",
		"Paisley",
		"sco-1",
		66,
		"#000000",
		"#FFFFFF",
		"ss"
	],
	[
		"mot-wel",
		"Motherwell",
		"sco-1",
		65,
		"#F07A22",
		"#8B1A1A",
		"s"
	],
	[
		"kil-mar",
		"Kilmarnock",
		"sco-1",
		64,
		"#005CA9",
		"#FFFFFF",
		"s"
	],
	[
		"dun-dee",
		"Dundee",
		"sco-1",
		63,
		"#002F6C",
		"#FFFFFF",
		"s"
	],
	[
		"din-gwa",
		"Dingwall",
		"sco-1",
		61,
		"#003DA5",
		"#C8102E",
		"s"
	],
	[
		"per-th",
		"Perth",
		"sco-1",
		60,
		"#005CA9",
		"#FFFFFF",
		"s"
	]
]);
var TEAM_BY_ID = Object.fromEntries(TEAMS.map((x) => [x.id, x]));
function teamsInLeague(leagueId) {
	return TEAMS.filter((x) => x.leagueId === leagueId);
}
function hashSeed(s) {
	let h = 2166136261;
	for (let i = 0; i < s.length; i++) {
		h ^= s.charCodeAt(i);
		h = Math.imul(h, 16777619);
	}
	return h >>> 0;
}
function mulberry32(a) {
	let t = a >>> 0;
	return function rand() {
		t += 1831565813;
		let x = Math.imul(t ^ t >>> 15, 1 | t);
		x ^= x + Math.imul(x ^ x >>> 7, 61 | x);
		return ((x ^ x >>> 14) >>> 0) / 4294967296;
	};
}
function pick(rng, arr) {
	return arr[Math.floor(rng() * arr.length)];
}
function irand(rng, min, max) {
	return min + Math.floor(rng() * (max - min + 1));
}
function clamp(n, a, b) {
	return Math.max(a, Math.min(b, n));
}
function uid(prefix = "id") {
	return prefix + "_" + Math.random().toString(36).slice(2, 10);
}
var NPC = [
	{
		username: "fabio_wire",
		displayName: "Fabio Romano",
		bio: "Here we go.",
		verified: true,
		followers: 124e5,
		following: 210,
		hue: 210,
		npc: true,
		role: "media"
	},
	{
		username: "goalzone",
		displayName: "GoalZone",
		bio: "Gol arsivi.",
		verified: true,
		followers: 82e5,
		following: 40,
		hue: 12,
		npc: true,
		role: "media"
	},
	{
		username: "skypitch",
		displayName: "Sky Pitch News",
		bio: "Breaking.",
		verified: true,
		followers: 61e5,
		following: 80,
		hue: 200,
		npc: true,
		role: "media"
	},
	{
		username: "pitchside",
		displayName: "Pitchside FC",
		bio: "The game.",
		verified: true,
		followers: 44e5,
		following: 12,
		hue: 30,
		npc: true,
		role: "media"
	},
	{
		username: "uclnights",
		displayName: "Night of Cups",
		bio: "Avrupa geceleri.",
		verified: true,
		followers: 9e6,
		following: 8,
		hue: 250,
		npc: true,
		role: "media"
	},
	{
		username: "skillreel",
		displayName: "433 Reel",
		bio: "Ayak bilegi.",
		verified: true,
		followers: 15e6,
		following: 3,
		hue: 0,
		npc: true,
		role: "media"
	},
	{
		username: "bleach_pitch",
		displayName: "Terrace Report",
		bio: "POV: 90+3",
		verified: true,
		followers: 72e5,
		following: 20,
		hue: 18,
		npc: true,
		role: "media"
	},
	{
		username: "transferguru",
		displayName: "Transfer Guru",
		bio: "Medical done.",
		verified: true,
		followers: 31e5,
		following: 400,
		hue: 160,
		npc: true,
		role: "media"
	},
	{
		username: "tacticalmind",
		displayName: "Tactical Mind",
		bio: "4-3-3 evrimi.",
		verified: true,
		followers: 12e5,
		following: 90,
		hue: 190,
		npc: true,
		role: "media"
	},
	{
		username: "ballonwire",
		displayName: "Ballon Wire",
		bio: "Shortlist.",
		verified: true,
		followers: 24e5,
		following: 15,
		hue: 45,
		npc: true,
		role: "media"
	},
	{
		username: "terrace_talk",
		displayName: "Terrace Talk",
		bio: "Away days.",
		verified: true,
		followers: 89e4,
		following: 300,
		hue: 140,
		npc: true,
		role: "fan"
	},
	{
		username: "ultrasvoice",
		displayName: "Ultras Voice",
		bio: "TIFO.",
		verified: true,
		followers: 64e4,
		following: 50,
		hue: 355,
		npc: true,
		role: "fan"
	},
	{
		username: "statsman",
		displayName: "StatsMan",
		bio: "xG yalan soylemez.",
		verified: true,
		followers: 18e5,
		following: 22,
		hue: 175,
		npc: true,
		role: "media"
	}
];
var CAPTIONS = {
	goal: [
		"Aglar sarsildi. Isi bitirdik.",
		"Bir an. Bir vurus. Uc puan.",
		"Bu gece bunun icin oynuyoruz."
	],
	train: [
		"Sabah seansi. Detaylar onemli.",
		"Ter, tekrar, ritim.",
		"Sessiz gunler, gurultulu maclar."
	],
	matchday: [
		"Forma sirtta. Stad isiklari.",
		"Mac gunu. Nefes tut.",
		"Tunel. Grovl. Islik."
	],
	team: [
		"Soyunma odasi. Kardeslik.",
		"Biz. Sadece biz.",
		"Hafta ici is, pazar odul."
	],
	life: [
		"Saha disi, kafa ici.",
		"Sehir sessiz, kafa degil.",
		"Kisa bir nefes."
	],
	deal: [
		"Kalem, kagit, gelecek.",
		"Yeni sayfa.",
		"Imza atildi."
	],
	cup: [
		"Gumus parliyor.",
		"Bir gece, bir kupa.",
		"Final havasi."
	],
	sign: [
		"Hos geldin, yeni adres.",
		"Forma numarasi hazir.",
		"Bu sehir, bu renkler."
	],
	press: [
		"Mikrofonlar, ayni soru.",
		"Sahada konusulur.",
		"Basin gunu."
	]
};
function initSocial(player) {
	const me = {
		id: "me",
		username: slug(player.displayName),
		displayName: player.displayName,
		bio: player.pos + " · " + player.nat,
		verified: false,
		followers: 240 + player.overall * 12,
		following: 48,
		hue: 150,
		npc: false
	};
	const users = [me, ...NPC.map((n, i) => ({
		...n,
		id: "npc_" + i
	}))];
	const posts = NPC.slice(0, 6).map((n, i) => ({
		id: uid("p"),
		userId: "npc_" + i,
		scene: [
			"matchday",
			"goal",
			"press",
			"train",
			"cup",
			"deal"
		][i % 6],
		caption: n.bio + " " + ([
			"Here we go.",
			"Top 10 this week.",
			"Title race.",
			"The debate.",
			"Cup nights.",
			"Skill reel."
		][i % 6] || ""),
		likes: 12e3 + i * 4300,
		liked: false,
		comments: [{
			userId: "npc_10",
			text: "Bu sezon baska."
		}, {
			userId: "npc_11",
			text: "Tribun bunu bekliyordu."
		}],
		week: 1,
		time: "2sa",
		location: "",
		hashtags: ["football", "matchday"],
		mentions: [],
		saved: false
	}));
	return {
		setup: false,
		username: me.username,
		displayName: me.displayName,
		bio: me.bio,
		hue: 150,
		verified: false,
		followers: me.followers,
		followingCount: 48,
		posts,
		stories: [
			{
				id: uid("s"),
				userId: "me",
				scene: "life",
				text: "Hazirlik",
				seen: false
			},
			{
				id: uid("s"),
				userId: "npc_0",
				scene: "deal",
				text: "Incoming...",
				seen: false
			},
			{
				id: uid("s"),
				userId: "npc_7",
				scene: "sign",
				text: "Medical",
				seen: false
			}
		],
		users,
		activity: [],
		threads: [{
			userId: "npc_0",
			unread: 1,
			messages: [{
				id: uid("m"),
				from: "them",
				text: "Sakin ol, dogru adimlari konusuruz.",
				time: "1sa"
			}]
		}],
		followingIds: [
			"npc_0",
			"npc_1",
			"npc_7"
		],
		savedIds: []
	};
}
function slug(s) {
	return s.toLowerCase().replace(/[^a-z0-9]+/g, "").slice(0, 16) || "player";
}
function weeklySocial(state) {
	const social = structuredClone(state.social);
	const n = 1 + (Math.random() > .5 ? 1 : 0);
	const lines = [
		{
			u: 0,
			t: "Here we go. Transfer news incoming.",
			sc: "deal"
		},
		{
			u: 1,
			t: "Top 10 goals of the week.",
			sc: "goal"
		},
		{
			u: 2,
			t: "BREAKING: title race heats up.",
			sc: "press"
		},
		{
			u: 3,
			t: "The GOAT debate continues.",
			sc: "press"
		},
		{
			u: 4,
			t: "The cup nights we live for.",
			sc: "cup"
		},
		{
			u: 5,
			t: "Skill moves that broke ankles.",
			sc: "train"
		},
		{
			u: 6,
			t: "POV: you scored in the 90th minute.",
			sc: "goal"
		},
		{
			u: 7,
			t: "Medical completed. Announcement soon.",
			sc: "sign"
		},
		{
			u: 8,
			t: "Why the modern 4-3-3 is evolving.",
			sc: "press"
		},
		{
			u: 9,
			t: "30-man shortlist incoming.",
			sc: "press"
		},
		{
			u: 10,
			t: "Away days hit different.",
			sc: "matchday"
		},
		{
			u: 11,
			t: "TIFO tonight is MASSIVE.",
			sc: "cup"
		},
		{
			u: 12,
			t: "xG doesn't lie.",
			sc: "press"
		}
	];
	for (let i = 0; i < n; i++) {
		const L = pick(Math.random, lines);
		social.posts.unshift({
			id: uid("p"),
			userId: "npc_" + L.u,
			scene: L.sc,
			caption: L.t,
			likes: irand(Math.random, 4e3, 18e4),
			liked: false,
			comments: [{
				userId: "npc_10",
				text: "Bu dogru."
			}],
			week: state.week,
			time: "Az once",
			location: "",
			hashtags: ["football"],
			mentions: [],
			saved: false
		});
	}
	if (social.posts.length > 40) social.posts = social.posts.slice(0, 40);
	if (Math.random() < .35) {
		social.activity.unshift({
			id: uid("a"),
			kind: "follow",
			userId: "npc_" + irand(Math.random, 0, 12),
			text: "seni takip etmeye basladi",
			unread: true,
			week: state.week
		});
		social.followers += irand(Math.random, 8, 80);
	}
	return social;
}
function composePost(state, scene, caption, hashtags, mentions) {
	const social = structuredClone(state.social);
	const reach = estimateReach(social.followers, scene);
	social.posts.unshift({
		id: uid("p"),
		userId: "me",
		scene,
		caption,
		likes: Math.round(reach * .08),
		liked: false,
		comments: [],
		week: state.week,
		time: "Az once",
		location: TEAM_BY_ID[state.clubId]?.name || "",
		hashtags,
		mentions,
		saved: false
	});
	social.followers += Math.round(reach * .01);
	return social;
}
function estimateReach(followers, scene) {
	const m = scene === "goal" ? 2.4 : scene === "cup" ? 1.8 : scene === "matchday" ? 1.4 : 1;
	return Math.round(followers * (.12 + Math.random() * .25) * m);
}
function reachLabel(n, followers) {
	const r = n / Math.max(1, followers);
	if (r > .7) return "Viral";
	if (r > .35) return "Yuksek";
	if (r > .15) return "Iyi";
	return "Sinirli";
}
function captionsFor(scene, last) {
	const base = CAPTIONS[scene] || CAPTIONS.life;
	if (scene === "goal" && last && last.goals > 0) return [last.goals + " gol. Is bitti.", ...base];
	return base;
}
function dmReply(text, role) {
	const t = text.toLowerCase();
	if (/selam|merhaba|hey|sa\b/.test(t)) return pick(Math.random, [
		"Selam, nasilsin?",
		"Iyidir, saha sonrasi yaz.",
		"Hey. Hazir misin?"
	]);
	if (/tesekkur|sagol|saol/.test(t)) return "Rica ederim.";
	if (/antrenman|idman/.test(t)) return pick(Math.random, ["Sabah seansinda gorusuruz.", "Yuk yuksek, gel."]);
	if (/mac|gol|form/.test(t)) return pick(Math.random, [
		"Form yerindeyse is biter.",
		"Gol zaten gelecek.",
		"Mac gunu konusuruz."
	]);
	if (/kabul|red|teklif|transfer|kulup/.test(t) && (role === "agent" || role === "manager")) return pick(Math.random, [
		"Numaralari konusuruz.",
		"Sakin ol, dogru kulubu bekleyelim.",
		"Bu teklif ciddi."
	]);
	if (/maas|para|sozlesme/.test(t) && role === "agent") return "Butceyi ben hesaplarim. Sen sahaya bak.";
	if (/\?/.test(t)) return "Dusunecegim. Sonra donerim.";
	if (/harika|efsane|aslan|god/.test(t)) return pick(Math.random, ["Tesekkurler.", "Saha konusur."]);
	if (role === "agent") return "Sen futboluna odaklan.";
	if (role === "manager") return "Antrenmana odaklan.";
	if (role === "teammate") return "Aynen kanka.";
	if (role === "fan") return "MUAZZAM.";
	return pick(Math.random, [
		"Tamamdir.",
		"Gorusuruz.",
		"Not ettim."
	]);
}
var ctx = null;
var master = null;
var enabled = true;
function getCtx() {
	if (typeof window === "undefined") return null;
	if (!ctx) {
		const AC = window.AudioContext || window.webkitAudioContext;
		if (!AC) return null;
		ctx = new AC({ latencyHint: "interactive" });
		master = ctx.createGain();
		master.gain.value = .18;
		master.connect(ctx.destination);
	}
	if (ctx.state === "suspended") ctx.resume();
	return ctx;
}
function unlockSound() {
	const c = getCtx();
	if (c && c.state === "suspended") c.resume();
}
function setSoundEnabled(on) {
	enabled = on;
	try {
		localStorage.setItem("fc_sound", on ? "1" : "0");
	} catch {}
}
function isSoundEnabled() {
	if (typeof window === "undefined") return true;
	try {
		if (localStorage.getItem("fc_sound") === "0") return false;
	} catch {}
	return enabled;
}
function beep(freq, dur, type, vol = .4, slide = 0) {
	if (!isSoundEnabled()) return;
	const c = getCtx();
	if (!c || !master) return;
	const t = c.currentTime;
	const o = c.createOscillator();
	const g = c.createGain();
	const f = c.createBiquadFilter();
	o.type = type;
	o.frequency.setValueAtTime(freq, t);
	if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(40, freq + slide), t + dur);
	f.type = "lowpass";
	f.frequency.value = 2400;
	g.gain.setValueAtTime(1e-4, t);
	g.gain.exponentialRampToValueAtTime(vol, t + .012);
	g.gain.exponentialRampToValueAtTime(1e-4, t + dur);
	o.connect(f);
	f.connect(g);
	g.connect(master);
	o.start(t);
	o.stop(t + dur + .02);
}
var Sound = {
	click() {
		beep(720, .05, "square", .22);
	},
	tap() {
		beep(520, .04, "triangle", .18);
	},
	pop() {
		beep(880, .08, "sine", .28, 200);
	},
	follow() {
		beep(660, .07, "sine", .24);
		setTimeout(() => beep(990, .09, "sine", .2), 70);
	},
	milestone() {
		beep(523, .12, "sine", .3);
		setTimeout(() => beep(659, .12, "sine", .28), 90);
		setTimeout(() => beep(784, .18, "sine", .3), 180);
	},
	kick() {
		beep(140, .12, "sine", .5, -80);
	},
	whistle() {
		beep(1800, .22, "square", .12);
	},
	goal() {
		beep(392, .1, "triangle", .32);
		setTimeout(() => beep(523, .12, "triangle", .3), 80);
		setTimeout(() => beep(659, .2, "triangle", .34), 170);
	},
	success() {
		beep(880, .08, "sine", .24);
		setTimeout(() => beep(1174, .12, "sine", .22), 80);
	},
	fail() {
		beep(220, .16, "sawtooth", .18, -80);
	},
	card() {
		beep(240, .14, "square", .2);
	},
	dm() {
		beep(1040, .06, "sine", .2);
		setTimeout(() => beep(1320, .08, "sine", .16), 60);
	}
};
var NAMES = {
	ENG: {
		first: [
			"Jack",
			"Harry",
			"Mason",
			"Callum",
			"Jamie",
			"Oliver",
			"Noah",
			"Theo",
			"Reece",
			"Jude",
			"Cole",
			"Marcus",
			"Declan",
			"Bukayo",
			"Phil"
		],
		last: [
			"Walker",
			"Rice",
			"Palmer",
			"Foden",
			"Kane",
			"Sterling",
			"Mount",
			"James",
			"Shaw",
			"White",
			"Gordon",
			"Watkins",
			"Wilson",
			"Trippier",
			"Pope"
		]
	},
	ESP: {
		first: [
			"Carlos",
			"Pablo",
			"Diego",
			"Alvaro",
			"Sergio",
			"Iker",
			"Unai",
			"Mikel",
			"Pedri",
			"Ferran",
			"Dani",
			"Rodri",
			"Gavi",
			"Nico",
			"Aymeric"
		],
		last: [
			"Garcia",
			"Rodriguez",
			"Hernandez",
			"Gonzalez",
			"Fernandez",
			"Lopez",
			"Martinez",
			"Sanchez",
			"Perez",
			"Ruiz",
			"Diaz",
			"Moreno",
			"Alonso",
			"Navas",
			"Torres"
		]
	},
	FRA: {
		first: [
			"Hugo",
			"Kylian",
			"Antoine",
			"NGolo",
			"Paul",
			"Karim",
			"Ousmane",
			"Eduardo",
			"Aurelien",
			"Warren",
			"Randal",
			"Bradley",
			"Mike",
			"Theo",
			"Kingsley"
		],
		last: [
			"Mbappe",
			"Griezmann",
			"Kante",
			"Pogba",
			"Benzema",
			"Dembele",
			"Camavinga",
			"Tchouameni",
			"Zaire",
			"Kolo",
			"Barcola",
			"Maignan",
			"Hernandez",
			"Coman",
			"Nkunku"
		]
	},
	GER: {
		first: [
			"Manuel",
			"Joshua",
			"Jamal",
			"Leroy",
			"Thomas",
			"Leon",
			"Kai",
			"Florian",
			"Niclas",
			"Serge",
			"Antonio",
			"Mats",
			"Ilkay",
			"Toni",
			"Marco"
		],
		last: [
			"Neuer",
			"Kimmich",
			"Musiala",
			"Sane",
			"Muller",
			"Goretzka",
			"Havertz",
			"Wirtz",
			"Fullkrug",
			"Gnabry",
			"Rudiger",
			"Hummels",
			"Gundogan",
			"Kroos",
			"Reus"
		]
	},
	ITA: {
		first: [
			"Gianluigi",
			"Federico",
			"Nicolo",
			"Alessandro",
			"Lorenzo",
			"Ciro",
			"Giacomo",
			"Sandro",
			"Giorgio",
			"Marco",
			"Andrea",
			"Matteo",
			"Davide",
			"Stefano",
			"Riccardo"
		],
		last: [
			"Donnarumma",
			"Chiesa",
			"Barella",
			"Bastoni",
			"Insigne",
			"Immobile",
			"Raspadori",
			"Tonali",
			"Chiellini",
			"Verratti",
			"Pirlo",
			"Darmian",
			"Frattesi",
			"Sensi",
			"Orsolini"
		]
	},
	NED: {
		first: [
			"Virgil",
			"Frenkie",
			"Memphis",
			"Cody",
			"Xavi",
			"Matthijs",
			"Denzel",
			"Steven",
			"Daley",
			"Jurrien",
			"Ryan",
			"Wout",
			"Teun",
			"Quincy",
			"Noa"
		],
		last: [
			"van Dijk",
			"de Jong",
			"Depay",
			"Gakpo",
			"Simons",
			"de Ligt",
			"Dumfries",
			"Bergwijn",
			"Blind",
			"Timber",
			"Gravenberch",
			"Weghorst",
			"Koopmeiners",
			"Promes",
			"Lang"
		]
	},
	POR: {
		first: [
			"Cristiano",
			"Bruno",
			"Bernardo",
			"Diogo",
			"Rafael",
			"Joao",
			"Ruben",
			"Goncalo",
			"Pedro",
			"Nuno",
			"Ricardo",
			"Andre",
			"Renato",
			"Otavio",
			"Vitinha"
		],
		last: [
			"Ronaldo",
			"Fernandes",
			"Silva",
			"Jota",
			"Leao",
			"Cancelo",
			"Dias",
			"Ramos",
			"Neto",
			"Mendes",
			"Pereira",
			"Gomes",
			"Sanches",
			"Carvalho",
			"Ferreira"
		]
	},
	BRA: {
		first: [
			"Neymar",
			"Vinicius",
			"Rodrygo",
			"Casemiro",
			"Alisson",
			"Marquinhos",
			"Endrick",
			"Raphinha",
			"Gabriel",
			"Richarlison",
			"Lucas",
			"Thiago",
			"Ederson",
			"Danilo",
			"Antony"
		],
		last: [
			"Junior",
			"Goes",
			"Santos",
			"Becker",
			"Jesus",
			"Martinelli",
			"Magalhaes",
			"Silva",
			"Oliveira",
			"Pereira",
			"Costa",
			"Almeida",
			"Rocha",
			"Nascimento",
			"Souza"
		]
	},
	ARG: {
		first: [
			"Lionel",
			"Julian",
			"Lautaro",
			"Enzo",
			"Alexis",
			"Emiliano",
			"Cristian",
			"Nicolas",
			"Angel",
			"Paulo",
			"Lisandro",
			"Exequiel",
			"Giovani",
			"Leandro",
			"Rodrigo"
		],
		last: [
			"Messi",
			"Alvarez",
			"Martinez",
			"Fernandez",
			"Mac Allister",
			"Romero",
			"Otamendi",
			"Di Maria",
			"Dybala",
			"Tagliafico",
			"Palacios",
			"Lo Celso",
			"De Paul",
			"Paredes",
			"Correa"
		]
	},
	TUR: {
		first: [
			"Hakan",
			"Cengiz",
			"Kerem",
			"Arda",
			"Irfan",
			"Ozan",
			"Ugurcan",
			"Cenk",
			"Yusuf",
			"Baris",
			"Ferdi",
			"Ismail",
			"Abdulkadir",
			"Kenan",
			"Orkun"
		],
		last: [
			"Calhanoglu",
			"Under",
			"Akturkoglu",
			"Guler",
			"Kahveci",
			"Tufan",
			"Cakir",
			"Tosun",
			"Yazici",
			"Yilmaz",
			"Kadioglu",
			"Yuksek",
			"Omur",
			"Yildiz",
			"Kokcu"
		]
	},
	AZE: {
		first: [
			"Mahir",
			"Ramil",
			"Emin",
			"Tural",
			"Elvin",
			"Vugar",
			"Araz",
			"Renat",
			"Namik",
			"Farid",
			"Javid",
			"Ruslan",
			"Orkhan",
			"Sabuhi",
			"Kamran"
		],
		last: [
			"Emreli",
			"Sheydayev",
			"Mahmudov",
			"Huseynov",
			"Mustafayev",
			"Aliyev",
			"Mammadov",
			"Dadashov",
			"Qurbanov",
			"Ismayilov",
			"Hasanov",
			"Nadirov",
			"Badalov",
			"Ahmadov",
			"Karimov"
		]
	},
	BEL: {
		first: [
			"Thibaut",
			"Kevin",
			"Romelu",
			"Eden",
			"Youri",
			"Axel",
			"Leandro",
			"Amadou",
			"Jeremy",
			"Dries",
			"Toby",
			"Jan",
			"Hans",
			"Michy",
			"Charles"
		],
		last: [
			"Courtois",
			"De Bruyne",
			"Lukaku",
			"Hazard",
			"Tielemans",
			"Witsel",
			"Trossard",
			"Onana",
			"Doku",
			"Mertens",
			"Alderweireld",
			"Vertonghen",
			"Vanaken",
			"Batshuayi",
			"De Ketelaere"
		]
	},
	CRO: {
		first: [
			"Luka",
			"Ivan",
			"Mario",
			"Josko",
			"Marcelo",
			"Andrej",
			"Borna",
			"Mateo",
			"Nikola",
			"Ante",
			"Duje",
			"Dominik",
			"Josip",
			"Bruno",
			"Lovro"
		],
		last: [
			"Modric",
			"Perisic",
			"Pasalic",
			"Gvardiol",
			"Brozovic",
			"Kramaric",
			"Sosa",
			"Kovacic",
			"Vlasic",
			"Rebic",
			"Caleta",
			"Livakovic",
			"Juranovic",
			"Petkovic",
			"Majer"
		]
	},
	DEN: {
		first: [
			"Christian",
			"Pierre",
			"Kasper",
			"Rasmus",
			"Andreas",
			"Joakim",
			"Jonas",
			"Victor",
			"Mikkel",
			"Mathias",
			"Simon",
			"Thomas",
			"Martin",
			"Jesper",
			"Yussuf"
		],
		last: [
			"Eriksen",
			"Hojbjerg",
			"Schmeichel",
			"Hojlund",
			"Christensen",
			"Maehle",
			"Wind",
			"Kristiansen",
			"Damsgaard",
			"Jensen",
			"Kjaer",
			"Delaney",
			"Braithwaite",
			"Lindstrom",
			"Poulsen"
		]
	},
	SWE: {
		first: [
			"Zlatan",
			"Dejan",
			"Alexander",
			"Emil",
			"Victor",
			"Ludwig",
			"Kristoffer",
			"Robin",
			"Jens",
			"Mattias",
			"Sebastian",
			"Albin",
			"Gustaf",
			"Filip",
			"Isak"
		],
		last: [
			"Ibrahimovic",
			"Kulusevski",
			"Isak",
			"Forsberg",
			"Lindelof",
			"Augustinsson",
			"Olsson",
			"Olsen",
			"Stryger",
			"Svanberg",
			"Larsson",
			"Ekdal",
			"Nilsson",
			"Helander",
			"Kiese"
		]
	},
	NOR: {
		first: [
			"Erling",
			"Martin",
			"Alexander",
			"Martin",
			"Sander",
			"Kristoffer",
			"Andreas",
			"Morten",
			"Ola",
			"Fredrik",
			"Jorgen",
			"Leo",
			"Oscar",
			"Tobias",
			"Patrick"
		],
		last: [
			"Haaland",
			"Odegaard",
			"Sorloth",
			"Dahlin",
			"Berge",
			"Ajer",
			"Hanche",
			"Thorsby",
			"Nyland",
			"Aursnes",
			"Strand",
			"Ostigard",
			"Bob",
			"Bjornebye",
			"Berg"
		]
	},
	POL: {
		first: [
			"Robert",
			"Wojciech",
			"Piotr",
			"Arkadiusz",
			"Jakub",
			"Grzegorz",
			"Kamil",
			"Bartosz",
			"Sebastian",
			"Przemyslaw",
			"Karol",
			"Nicola",
			"Mateusz",
			"Tomasz",
			"Lukasz"
		],
		last: [
			"Lewandowski",
			"Szczesny",
			"Zielinski",
			"Milik",
			"Kiwior",
			"Krychowiak",
			"Grosicki",
			"Bereszynski",
			"Szymanski",
			"Frankowski",
			"Swiderski",
			"Zalewski",
			"Puchacz",
			"Kedziora",
			"Skorupski"
		]
	},
	JPN: {
		first: [
			"Takefusa",
			"Kaoru",
			"Wataru",
			"Takehiro",
			"Daichi",
			"Takumi",
			"Junya",
			"Ritsu",
			"Yuto",
			"Maya",
			"Hiroki",
			"Ao",
			"Keito",
			"Yukinari",
			"Koki"
		],
		last: [
			"Kubo",
			"Mitoma",
			"Endo",
			"Tomiyasu",
			"Kamada",
			"Minamino",
			"Ito",
			"Doan",
			"Nagatomo",
			"Yoshida",
			"Sakai",
			"Tanaka",
			"Nakamura",
			"Sugawara",
			"Machida"
		]
	},
	KOR: {
		first: [
			"Son",
			"Kim",
			"Lee",
			"Hwang",
			"Cho",
			"Jung",
			"Park",
			"Kang",
			"Oh",
			"Hong",
			"Nam",
			"Seo",
			"Min",
			"Woo",
			"Jae"
		],
		last: [
			"Heung-min",
			"Min-jae",
			"Kang-in",
			"Hee-chan",
			"Gue-sung",
			"Woo-young",
			"Ji-sung",
			"In-beom",
			"Hyun-gyu",
			"Chul",
			"Tae-hee",
			"Young-woo",
			"Jae-sung",
			"Sung-yueng",
			"Sung-min"
		]
	},
	USA: {
		first: [
			"Christian",
			"Weston",
			"Tyler",
			"Giovanni",
			"Timothy",
			"Yun",
			"Sergino",
			"Antonee",
			"Walker",
			"Brenden",
			"Ricardo",
			"Matt",
			"Zack",
			"Jordan",
			"Miles"
		],
		last: [
			"Pulisic",
			"McKennie",
			"Adams",
			"Reyna",
			"Weah",
			"Musah",
			"Dest",
			"Robinson",
			"Zimmerman",
			"Aaronson",
			"Pepi",
			"Turner",
			"Steffen",
			"Morris",
			"Robinson"
		]
	},
	MEX: {
		first: [
			"Hirving",
			"Raul",
			"Edson",
			"Guillermo",
			"Jesus",
			"Hector",
			"Andres",
			"Cesar",
			"Uriel",
			"Luis",
			"Diego",
			"Santiago",
			"Erick",
			"Johan",
			"Roberto"
		],
		last: [
			"Lozano",
			"Jimenez",
			"Alvarez",
			"Ochoa",
			"Corona",
			"Herrera",
			"Guardado",
			"Montes",
			"Antuna",
			"Chavez",
			"Lainez",
			"Gimenez",
			"Gutierrez",
			"Vasquez",
			"Alvarado"
		]
	},
	MAR: {
		first: [
			"Achraf",
			"Hakim",
			"Yassine",
			"Sofyan",
			"Noussair",
			"Azzedine",
			"Youssef",
			"Romain",
			"Nayef",
			"Selim",
			"Amine",
			"Ilias",
			"Sofiane",
			"Abde",
			"Bilal"
		],
		last: [
			"Hakimi",
			"Ziyech",
			"Bounou",
			"Amrabat",
			"Mazraoui",
			"Ounahi",
			"En-Nesyri",
			"Saiss",
			"Aguerd",
			"Amallah",
			"Harit",
			"Chair",
			"Boufal",
			"Ezzalzouli",
			"El Khannouss"
		]
	},
	SEN: {
		first: [
			"Sadio",
			"Kalidou",
			"Edouard",
			"Ismaila",
			"Iliman",
			"Nicolas",
			"Boulaye",
			"Cheikhou",
			"Pape",
			"Krepin",
			"Famara",
			"Abdoulaye",
			"Ibrahima",
			"Pathé",
			"Moussa"
		],
		last: [
			"Mane",
			"Koulibaly",
			"Mendy",
			"Sarr",
			"Ndiaye",
			"Jackson",
			"Dia",
			"Kouyate",
			"Sarr",
			"Diatta",
			"Diedhiou",
			"Diallo",
			"Konate",
			"Ciss",
			"Niakhate"
		]
	},
	NGA: {
		first: [
			"Victor",
			"Wilfred",
			"Alex",
			"Kelechi",
			"Samuel",
			"Ademola",
			"Joe",
			"Calvin",
			"Taiwo",
			"Victor",
			"William",
			"Semi",
			"Kenneth",
			"Ahmed",
			"Moses"
		],
		last: [
			"Osimhen",
			"Ndidi",
			"Iwobi",
			"Iheanacho",
			"Chukwueze",
			"Lookman",
			"Gomez",
			"Bassey",
			"Awoniyi",
			"Boniface",
			"Troost-Ekong",
			"Ajayi",
			"Omeruo",
			"Musa",
			"Simon"
		]
	},
	GHA: {
		first: [
			"Mohammed",
			"Thomas",
			"Jordan",
			"Inaki",
			"Antoine",
			"Kamaldeen",
			"Daniel",
			"Alexander",
			"Andre",
			"Osman",
			"Joseph",
			"Richmond",
			"Felix",
			"Baba",
			"Tariq"
		],
		last: [
			"Kudus",
			"Partey",
			"Ayew",
			"Williams",
			"Semenyo",
			"Sulemana",
			"Amartey",
			"Djiku",
			"Ayew",
			"Bukari",
			"Paintsil",
			"Boakye",
			"Afena",
			"Rahman",
			"Lamptey"
		]
	},
	SCO: {
		first: [
			"Andrew",
			"John",
			"Scott",
			"Callum",
			"Ryan",
			"James",
			"Kieran",
			"Stuart",
			"Billy",
			"Kenny",
			"Lewis",
			"Craig",
			"Aaron",
			"Liam",
			"Greg"
		],
		last: [
			"Robertson",
			"McGinn",
			"McTominay",
			"McGregor",
			"Christie",
			"Forrest",
			"Tierney",
			"Armstrong",
			"Gilmour",
			"McLean",
			"Ferguson",
			"Gordon",
			"Hickey",
			"Cooper",
			"Taylor"
		]
	}
};
var MANAGER_FIRST = [
	"Pep",
	"Carlo",
	"Jurgen",
	"Mikel",
	"Diego",
	"Erik",
	"Antonio",
	"Unai",
	"Luciano",
	"Roberto",
	"Mauricio",
	"Xabi",
	"Thomas",
	"Vincent",
	"Arne"
];
var MANAGER_LAST = [
	"Guardiola",
	"Ancelotti",
	"Klopp",
	"Arteta",
	"Simeone",
	"ten Hag",
	"Conte",
	"Emery",
	"Spalletti",
	"De Zerbi",
	"Pochettino",
	"Alonso",
	"Tuchel",
	"Kompany",
	"Slot"
];
var AGENT_FIRST = [
	"Jorge",
	"Mino",
	"Jonathan",
	"Kia",
	"Paulo",
	"Volkan",
	"Hasan",
	"Pini"
];
var AGENT_LAST = [
	"Mendes",
	"Raiola",
	"Barnett",
	"Joorabchian",
	"Futre",
	"Demirel",
	"Yildirim",
	"Zahavi"
];
var PARTNER_FIRST = [
	"Elif",
	"Sofia",
	"Maya",
	"Lara",
	"Aylin",
	"Nina",
	"Elena",
	"Clara",
	"Leyla",
	"Amelia",
	"Nora",
	"Iris"
];
function blankAttrs(base = 55) {
	const a = {};
	for (const k of ALL_ATTRS) a[k] = base;
	return a;
}
function calcOverall(pos, attrs) {
	const w = POS_WEIGHTS[pos] || POS_WEIGHTS.CM;
	let sum = 0;
	let tot = 0;
	for (const [k, weight] of Object.entries(w)) {
		sum += (attrs[k] ?? 55) * weight;
		tot += weight;
	}
	const extra = ((attrs.stamina ?? 55) + (attrs.reactions ?? 55) + (attrs.composure ?? 55)) / 3;
	const raw = tot ? sum / tot : 55;
	return clamp(Math.round(raw * .88 + extra * .12), 40, 99);
}
function squad(id, rows, nats = ["ENG"]) {
	return rows.map((r, i) => ({
		id: id + "_" + i,
		first: r[0],
		last: r[1],
		pos: r[2],
		ovr: r[3],
		age: 22 + i * 3 % 12,
		nat: nats[i % nats.length] ?? "ENG"
	}));
}
var TEAM_SQUADS = {
	"man-sky": squad("man-sky", [
		[
			"Edersson",
			"",
			"GK",
			88
		],
		[
			"Kyle",
			"Walkers",
			"RB",
			84
		],
		[
			"Ruben",
			"Dias",
			"CB",
			87
		],
		[
			"John",
			"Stones",
			"CB",
			85
		],
		[
			"Josko",
			"Gvardiol",
			"LB",
			85
		],
		[
			"Rodri",
			"",
			"CDM",
			89
		],
		[
			"Kevin",
			"De Bruyn",
			"CAM",
			90
		],
		[
			"Bernardo",
			"Silva",
			"CM",
			87
		],
		[
			"Phil",
			"Foden",
			"LW",
			87
		],
		[
			"Erling",
			"Hollan",
			"ST",
			91
		],
		[
			"Jeremy",
			"Doku",
			"LW",
			84
		],
		[
			"Jack",
			"Grealish",
			"LW",
			82
		],
		[
			"Mateo",
			"Kovacic",
			"CM",
			84
		],
		[
			"Nathan",
			"Ake",
			"CB",
			82
		],
		[
			"Stefan",
			"Ortega",
			"GK",
			82
		]
	], [
		"BRA",
		"ENG",
		"POR",
		"ENG",
		"CRO",
		"ESP",
		"BEL",
		"POR",
		"ENG",
		"NOR",
		"BEL",
		"ENG",
		"CRO",
		"NED",
		"GER"
	]),
	"man-red": squad("man-red", [
		[
			"Andre",
			"Onan",
			"GK",
			82
		],
		[
			"Diogo",
			"Dalot",
			"RB",
			82
		],
		[
			"Lisandro",
			"Martines",
			"CB",
			84
		],
		[
			"Raphael",
			"Varan",
			"CB",
			85
		],
		[
			"Luke",
			"Shaw",
			"LB",
			82
		],
		[
			"Casemiro",
			"",
			"CDM",
			85
		],
		[
			"Bruno",
			"Fernandes",
			"CAM",
			87
		],
		[
			"Mason",
			"Mount",
			"CM",
			82
		],
		[
			"Marcus",
			"Rashford",
			"LW",
			84
		],
		[
			"Rasmus",
			"Hojlund",
			"ST",
			82
		],
		[
			"Alejandro",
			"Garnacho",
			"LW",
			81
		],
		[
			"Antony",
			"Santos",
			"RW",
			80
		],
		[
			"Christian",
			"Eriksen",
			"CAM",
			82
		],
		[
			"Victor",
			"Lindelof",
			"CB",
			80
		],
		[
			"Altay",
			"Bayindir",
			"GK",
			78
		]
	], [
		"CMR",
		"POR",
		"ARG",
		"FRA",
		"ENG",
		"BRA",
		"POR",
		"ENG",
		"ENG",
		"DEN",
		"ARG",
		"BRA",
		"DEN",
		"SWE",
		"TUR"
	]),
	"lon-gun": squad("lon-gun", [
		[
			"David",
			"Raya",
			"GK",
			84
		],
		[
			"Ben",
			"White",
			"RB",
			82
		],
		[
			"William",
			"Saliba",
			"CB",
			86
		],
		[
			"Gabriel",
			"Magalhaes",
			"CB",
			86
		],
		[
			"Oleksandr",
			"Zinchenko",
			"LB",
			81
		],
		[
			"Declan",
			"Rice",
			"CDM",
			86
		],
		[
			"Martin",
			"Odegaard",
			"CAM",
			87
		],
		[
			"Kai",
			"Havertz",
			"CAM",
			84
		],
		[
			"Bukayo",
			"Saka",
			"RW",
			86
		],
		[
			"Gabriel",
			"Jesus",
			"ST",
			83
		],
		[
			"Gabriel",
			"Martinelli",
			"LW",
			84
		],
		[
			"Leandro",
			"Trossard",
			"LW",
			82
		],
		[
			"Thomas",
			"Partey",
			"CDM",
			83
		],
		[
			"Jurrien",
			"Timber",
			"RB",
			82
		],
		[
			"Aaron",
			"Ramsdale",
			"GK",
			82
		]
	], [
		"ESP",
		"ENG",
		"FRA",
		"BRA",
		"UKR",
		"ENG",
		"NOR",
		"GER",
		"ENG",
		"BRA",
		"BRA",
		"BEL",
		"GHA",
		"NED",
		"ENG"
	]),
	"mer-red": squad("mer-red", [
		[
			"Alison",
			"Becker",
			"GK",
			88
		],
		[
			"Trent",
			"Alexander",
			"RB",
			86
		],
		[
			"Virgil",
			"van Dijki",
			"CB",
			88
		],
		[
			"Ibrahima",
			"Konate",
			"CB",
			84
		],
		[
			"Andy",
			"Robertson",
			"LB",
			85
		],
		[
			"Wataru",
			"Endo",
			"CDM",
			81
		],
		[
			"Alexis",
			"Mac Allister",
			"CM",
			85
		],
		[
			"Dominik",
			"Szoboszlai",
			"CAM",
			85
		],
		[
			"Mohamed",
			"Sala",
			"RW",
			88
		],
		[
			"Darwin",
			"Nunez",
			"ST",
			83
		],
		[
			"Luis",
			"Diaz",
			"LW",
			85
		],
		[
			"Cody",
			"Gakpo",
			"LW",
			83
		],
		[
			"Ryan",
			"Gravenberch",
			"CM",
			82
		],
		[
			"Joe",
			"Gomez",
			"CB",
			80
		],
		[
			"Caoimhin",
			"Kelleher",
			"GK",
			80
		]
	], [
		"BRA",
		"ENG",
		"NED",
		"FRA",
		"SCO",
		"JPN",
		"ARG",
		"HUN",
		"EGY",
		"URU",
		"COL",
		"NED",
		"NED",
		"ENG",
		"IRL"
	]),
	"lon-royal": squad("lon-royal", [
		[
			"Robert",
			"Sanchez",
			"GK",
			82
		],
		[
			"Reece",
			"James",
			"RB",
			85
		],
		[
			"Thiago",
			"Silva",
			"CB",
			84
		],
		[
			"Levi",
			"Colwill",
			"CB",
			82
		],
		[
			"Marc",
			"Cucurella",
			"LB",
			82
		],
		[
			"Moises",
			"Caicedo",
			"CDM",
			84
		],
		[
			"Enzo",
			"Fernandez",
			"CM",
			84
		],
		[
			"Cole",
			"Palmer",
			"CAM",
			85
		],
		[
			"Raheem",
			"Sterling",
			"LW",
			83
		],
		[
			"Nicolas",
			"Jackson",
			"ST",
			82
		],
		[
			"Noni",
			"Madueke",
			"RW",
			80
		],
		[
			"Conor",
			"Gallagher",
			"CM",
			82
		],
		[
			"Mykhailo",
			"Mudryk",
			"LW",
			80
		],
		[
			"Benoit",
			"Badiashile",
			"CB",
			80
		],
		[
			"Djordje",
			"Petrovic",
			"GK",
			78
		]
	]),
	"n-lon-w": squad("n-lon-w", [
		[
			"Guglielmo",
			"Vicario",
			"GK",
			82
		],
		[
			"Pedro",
			"Porro",
			"RB",
			83
		],
		[
			"Cristian",
			"Romero",
			"CB",
			86
		],
		[
			"Micky",
			"van de Ven",
			"CB",
			83
		],
		[
			"Destiny",
			"Udogie",
			"LB",
			82
		],
		[
			"Yves",
			"Bissouma",
			"CDM",
			82
		],
		[
			"James",
			"Maddison",
			"CAM",
			85
		],
		[
			"Pape",
			"Sarr",
			"CM",
			81
		],
		[
			"Son",
			"Heung-min",
			"LW",
			86
		],
		[
			"Richarlison",
			"",
			"ST",
			82
		],
		[
			"Brennan",
			"Johnson",
			"RW",
			81
		],
		[
			"Dejan",
			"Kulusevski",
			"CAM",
			83
		],
		[
			"Pierre-Emile",
			"Hojbjerg",
			"CDM",
			81
		],
		[
			"Radu",
			"Dragusin",
			"CB",
			78
		],
		[
			"Fraser",
			"Forster",
			"GK",
			78
		]
	]),
	"new-mag": squad("new-mag", [
		[
			"Nick",
			"Pope",
			"GK",
			84
		],
		[
			"Kieran",
			"Trippier",
			"RB",
			83
		],
		[
			"Fabian",
			"Schar",
			"CB",
			82
		],
		[
			"Sven",
			"Botman",
			"CB",
			82
		],
		[
			"Dan",
			"Burn",
			"LB",
			78
		],
		[
			"Bruno",
			"Guimaraes",
			"CM",
			84
		],
		[
			"Joelinton",
			"",
			"CM",
			82
		],
		[
			"Joe",
			"Willock",
			"CM",
			80
		],
		[
			"Anthony",
			"Gordon",
			"LW",
			82
		],
		[
			"Alexander",
			"Isak",
			"ST",
			84
		],
		[
			"Miguel",
			"Almiron",
			"RW",
			80
		],
		[
			"Sean",
			"Longstaff",
			"CM",
			79
		],
		[
			"Jamaal",
			"Lascelles",
			"CB",
			78
		],
		[
			"Callum",
			"Wilson",
			"ST",
			82
		],
		[
			"Martin",
			"Dubravka",
			"GK",
			78
		]
	]),
	"bir-vil": squad("bir-vil", [
		[
			"Emiliano",
			"Martinez",
			"GK",
			85
		],
		[
			"Matty",
			"Cash",
			"RB",
			80
		],
		[
			"Ezri",
			"Konsa",
			"CB",
			82
		],
		[
			"Pau",
			"Torres",
			"CB",
			82
		],
		[
			"Lucas",
			"Digne",
			"LB",
			80
		],
		[
			"Boubacar",
			"Kamara",
			"CDM",
			82
		],
		[
			"Douglas",
			"Luiz",
			"CM",
			83
		],
		[
			"John",
			"McGinn",
			"CM",
			82
		],
		[
			"Leon",
			"Bailey",
			"RW",
			82
		],
		[
			"Ollie",
			"Watkins",
			"ST",
			84
		],
		[
			"Moussa",
			"Diaby",
			"RW",
			82
		],
		[
			"Youri",
			"Tielemans",
			"CM",
			82
		],
		[
			"Diego",
			"Carlos",
			"CB",
			80
		],
		[
			"Jhon",
			"Duran",
			"ST",
			78
		],
		[
			"Robin",
			"Olsen",
			"GK",
			78
		]
	]),
	"mad-bla": squad("mad-bla", [
		[
			"Thibaut",
			"Courtois",
			"GK",
			89
		],
		[
			"Dani",
			"Carvajal",
			"RB",
			85
		],
		[
			"Antonio",
			"Rudiger",
			"CB",
			86
		],
		[
			"Eder",
			"Militao",
			"CB",
			84
		],
		[
			"Ferland",
			"Mendy",
			"LB",
			83
		],
		[
			"Aurelien",
			"Tchouameni",
			"CDM",
			84
		],
		[
			"Federico",
			"Valverde",
			"CM",
			87
		],
		[
			"Jude",
			"Bellingham",
			"CAM",
			89
		],
		[
			"Vinicius",
			"Junior",
			"LW",
			89
		],
		[
			"Kylian",
			"Mbappe",
			"ST",
			91
		],
		[
			"Rodrygo",
			"Goes",
			"RW",
			86
		],
		[
			"Luka",
			"Modric",
			"CM",
			87
		],
		[
			"Eduardo",
			"Camavinga",
			"CM",
			84
		],
		[
			"Dani",
			"Ceballos",
			"CM",
			80
		],
		[
			"Andriy",
			"Lunin",
			"GK",
			80
		]
	], [
		"BEL",
		"ESP",
		"GER",
		"BRA",
		"FRA",
		"FRA",
		"URU",
		"ENG",
		"BRA",
		"FRA",
		"BRA",
		"CRO",
		"FRA",
		"ESP",
		"UKR"
	]),
	"bar-bla": squad("bar-bla", [
		[
			"Marc-Andre",
			"ter Stegen",
			"GK",
			86
		],
		[
			"Jules",
			"Kounde",
			"RB",
			84
		],
		[
			"Ronald",
			"Araujo",
			"CB",
			86
		],
		[
			"Pau",
			"Cubarsi",
			"CB",
			80
		],
		[
			"Alejandro",
			"Balde",
			"LB",
			82
		],
		[
			"Frenkie",
			"de Jong",
			"CM",
			85
		],
		[
			"Pedri",
			"",
			"CM",
			86
		],
		[
			"Ilkay",
			"Gundogan",
			"CAM",
			85
		],
		[
			"Lamine",
			"Yamal",
			"RW",
			87
		],
		[
			"Robert",
			"Lewandowski",
			"ST",
			88
		],
		[
			"Raphinha",
			"",
			"LW",
			84
		],
		[
			"Ferran",
			"Torres",
			"RW",
			82
		],
		[
			"Oriol",
			"Romeu",
			"CDM",
			80
		],
		[
			"Andreas",
			"Christensen",
			"CB",
			82
		],
		[
			"Inaki",
			"Pena",
			"GK",
			80
		]
	]),
	"mad-roj": squad("mad-roj", [
		[
			"Jan",
			"Oblak",
			"GK",
			87
		],
		[
			"Nahuel",
			"Molina",
			"RB",
			81
		],
		[
			"Jose Maria",
			"Gimenez",
			"CB",
			84
		],
		[
			"Robin",
			"Le Normand",
			"CB",
			83
		],
		[
			"Reinildo",
			"Mandava",
			"LB",
			80
		],
		[
			"Koke",
			"",
			"CM",
			83
		],
		[
			"Rodrigo",
			"De Paul",
			"CM",
			83
		],
		[
			"Pablo",
			"Barrios",
			"CM",
			80
		],
		[
			"Antoine",
			"Griezmann",
			"CF",
			86
		],
		[
			"Alvaro",
			"Morata",
			"ST",
			83
		],
		[
			"Samuel",
			"Lino",
			"LW",
			80
		],
		[
			"Marcos",
			"Llorente",
			"RB",
			82
		],
		[
			"Stefan",
			"Savic",
			"CB",
			82
		],
		[
			"Angel",
			"Correa",
			"CF",
			80
		],
		[
			"Horatiu",
			"Moldovan",
			"GK",
			78
		]
	]),
	"mun-red": squad("mun-red", [
		[
			"Manuel",
			"Neuer",
			"GK",
			87
		],
		[
			"Joshua",
			"Kimmich",
			"RB",
			87
		],
		[
			"Dayot",
			"Upamecano",
			"CB",
			84
		],
		[
			"Kim",
			"Min-jae",
			"CB",
			82
		],
		[
			"Alphonso",
			"Davies",
			"LB",
			85
		],
		[
			"Leon",
			"Goretzka",
			"CM",
			84
		],
		[
			"Konrad",
			"Laimer",
			"CM",
			82
		],
		[
			"Jamal",
			"Musiala",
			"CAM",
			86
		],
		[
			"Leroy",
			"Sane",
			"RW",
			85
		],
		[
			"Harry",
			"Kane",
			"ST",
			89
		],
		[
			"Thomas",
			"Muller",
			"CAM",
			85
		],
		[
			"Kingsley",
			"Coman",
			"LW",
			84
		],
		[
			"Eric",
			"Dier",
			"CB",
			78
		],
		[
			"Raphael",
			"Guerreiro",
			"LB",
			82
		],
		[
			"Sven",
			"Ulreich",
			"GK",
			78
		]
	]),
	"dor-yel": squad("dor-yel", [
		[
			"Gregor",
			"Kobel",
			"GK",
			85
		],
		[
			"Julian",
			"Ryerson",
			"RB",
			80
		],
		[
			"Nico",
			"Schlotterbeck",
			"CB",
			83
		],
		[
			"Mats",
			"Hummels",
			"CB",
			82
		],
		[
			"Ramy",
			"Bensebaini",
			"LB",
			80
		],
		[
			"Emre",
			"Can",
			"CDM",
			82
		],
		[
			"Marcel",
			"Sabitzer",
			"CM",
			82
		],
		[
			"Julian",
			"Brandt",
			"CAM",
			84
		],
		[
			"Karim",
			"Adeyemi",
			"LW",
			81
		],
		[
			"Serhou",
			"Guirassy",
			"ST",
			84
		],
		[
			"Donyell",
			"Malen",
			"RW",
			82
		],
		[
			"Marco",
			"Reus",
			"CAM",
			84
		],
		[
			"Salih",
			"Ozcan",
			"CDM",
			78
		],
		[
			"Niklas",
			"Sule",
			"CB",
			82
		],
		[
			"Alexander",
			"Meyer",
			"GK",
			78
		]
	]),
	"mil-ner": squad("mil-ner", [
		[
			"Yann",
			"Sommer",
			"GK",
			85
		],
		[
			"Denzel",
			"Dumfries",
			"RB",
			83
		],
		[
			"Alessandro",
			"Bastoni",
			"CB",
			85
		],
		[
			"Francesco",
			"Acerbi",
			"CB",
			82
		],
		[
			"Federico",
			"Dimarco",
			"LB",
			83
		],
		[
			"Nicolo",
			"Barella",
			"CM",
			86
		],
		[
			"Hakan",
			"Calhanoglu",
			"CDM",
			85
		],
		[
			"Henrikh",
			"Mkhitaryan",
			"CM",
			82
		],
		[
			"Lautaro",
			"Martinez",
			"ST",
			87
		],
		[
			"Marcus",
			"Thuram",
			"ST",
			84
		],
		[
			"Alexis",
			"Sanchez",
			"CF",
			80
		],
		[
			"Matteo",
			"Darmian",
			"RB",
			80
		],
		[
			"Stefan",
			"de Vrij",
			"CB",
			82
		],
		[
			"Davide",
			"Frattesi",
			"CM",
			82
		],
		[
			"Emil",
			"Audero",
			"GK",
			78
		]
	]),
	"mil-ros": squad("mil-ros", [
		[
			"Mike",
			"Maignan",
			"GK",
			85
		],
		[
			"Davide",
			"Calabria",
			"RB",
			81
		],
		[
			"Fikayo",
			"Tomori",
			"CB",
			84
		],
		[
			"Malick",
			"Thiaw",
			"CB",
			80
		],
		[
			"Theo",
			"Hernandez",
			"LB",
			85
		],
		[
			"Ismael",
			"Bennacer",
			"CDM",
			82
		],
		[
			"Tijjani",
			"Reijnders",
			"CM",
			82
		],
		[
			"Ruben",
			"Loftus-Cheek",
			"CAM",
			83
		],
		[
			"Rafael",
			"Leao",
			"LW",
			85
		],
		[
			"Olivier",
			"Giroud",
			"ST",
			82
		],
		[
			"Christian",
			"Pulisic",
			"RW",
			83
		],
		[
			"Yunus",
			"Musah",
			"CM",
			79
		],
		[
			"Simon",
			"Kjaer",
			"CB",
			80
		],
		[
			"Noah",
			"Okafor",
			"LW",
			78
		],
		[
			"Marco",
			"Sportiello",
			"GK",
			78
		]
	]),
	"tor-bia": squad("tor-bia", [
		[
			"Wojciech",
			"Szczesny",
			"GK",
			84
		],
		[
			"Andrea",
			"Cambiaso",
			"RB",
			80
		],
		[
			"Gleison",
			"Bremer",
			"CB",
			86
		],
		[
			"Federico",
			"Gatti",
			"CB",
			80
		],
		[
			"Alex",
			"Sandro",
			"LB",
			80
		],
		[
			"Manuel",
			"Locatelli",
			"CM",
			82
		],
		[
			"Adrien",
			"Rabiot",
			"CM",
			83
		],
		[
			"Weston",
			"McKennie",
			"CM",
			80
		],
		[
			"Federico",
			"Chiesa",
			"RW",
			84
		],
		[
			"Dusan",
			"Vlahovic",
			"ST",
			85
		],
		[
			"Kenan",
			"Yildiz",
			"CAM",
			78
		],
		[
			"Filip",
			"Kostic",
			"LB",
			82
		],
		[
			"Danilo",
			"Silva",
			"CB",
			82
		],
		[
			"Arkadiusz",
			"Milik",
			"ST",
			80
		],
		[
			"Mattia",
			"Perin",
			"GK",
			80
		]
	]),
	"nap-azz": squad("nap-azz", [
		[
			"Alex",
			"Meret",
			"GK",
			82
		],
		[
			"Giovanni",
			"Di Lorenzo",
			"RB",
			83
		],
		[
			"Amir",
			"Rrahmani",
			"CB",
			83
		],
		[
			"Kim",
			"Min-jae",
			"CB",
			84
		],
		[
			"Mathias",
			"Olivera",
			"LB",
			80
		],
		[
			"Stanislav",
			"Lobotka",
			"CDM",
			84
		],
		[
			"Andre-Frank",
			"Anguissa",
			"CM",
			83
		],
		[
			"Piotr",
			"Zielinski",
			"CAM",
			84
		],
		[
			"Matteo",
			"Politano",
			"RW",
			82
		],
		[
			"Victor",
			"Osimhen",
			"ST",
			86
		],
		[
			"Khvicha",
			"Kvaratskhelia",
			"LW",
			85
		],
		[
			"Jesper",
			"Lindstrom",
			"RW",
			78
		],
		[
			"Giacomo",
			"Raspadori",
			"CF",
			80
		],
		[
			"Juan",
			"Jesus",
			"CB",
			80
		],
		[
			"Pierluigi",
			"Gollini",
			"GK",
			78
		]
	]),
	"par-sg": squad("par-sg", [
		[
			"Gianluigi",
			"Donnarumma",
			"GK",
			87
		],
		[
			"Achraf",
			"Hakimi",
			"RB",
			85
		],
		[
			"Marquinhos",
			"",
			"CB",
			85
		],
		[
			"Milan",
			"Skriniar",
			"CB",
			82
		],
		[
			"Lucas",
			"Hernandez",
			"LB",
			82
		],
		[
			"Vitinha",
			"",
			"CDM",
			84
		],
		[
			"Manuel",
			"Ugarte",
			"CDM",
			82
		],
		[
			"Warren",
			"Zaire-Emery",
			"CM",
			83
		],
		[
			"Ousmane",
			"Dembele",
			"RW",
			85
		],
		[
			"Kylian",
			"Mbappe",
			"ST",
			91
		],
		[
			"Bradley",
			"Barcola",
			"LW",
			81
		],
		[
			"Randal",
			"Kolo Muani",
			"ST",
			82
		],
		[
			"Lee",
			"Kang-in",
			"CAM",
			82
		],
		[
			"Danilo",
			"Pereira",
			"CB",
			80
		],
		[
			"Keylor",
			"Navas",
			"GK",
			80
		]
	]),
	"mon-aco": squad("mon-aco", [
		[
			"Philipp",
			"Kohn",
			"GK",
			80
		],
		[
			"Vanderson",
			"",
			"RB",
			80
		],
		[
			"Guillermo",
			"Maripan",
			"CB",
			82
		],
		[
			"Mohamed",
			"Salisu",
			"CB",
			80
		],
		[
			"Caio",
			"Henrique",
			"LB",
			80
		],
		[
			"Youssouf",
			"Fofana",
			"CDM",
			83
		],
		[
			"Denis",
			"Zakaria",
			"CM",
			83
		],
		[
			"Aleksandr",
			"Golovin",
			"CAM",
			84
		],
		[
			"Maghnes",
			"Akliouche",
			"CAM",
			80
		],
		[
			"Folarin",
			"Balogun",
			"ST",
			82
		],
		[
			"Takumi",
			"Minamino",
			"LW",
			80
		],
		[
			"Eliesse",
			"Ben Seghir",
			"LW",
			78
		],
		[
			"Soungoutou",
			"Magassa",
			"CDM",
			78
		],
		[
			"Thilo",
			"Kehrer",
			"CB",
			80
		],
		[
			"Radoslaw",
			"Majecki",
			"GK",
			78
		]
	]),
	"mar-sei": squad("mar-sei", [
		[
			"Pau",
			"Lopez",
			"GK",
			82
		],
		[
			"Jonathan",
			"Clauss",
			"RB",
			82
		],
		[
			"Chancel",
			"Mbemba",
			"CB",
			82
		],
		[
			"Leonardo",
			"Balerdi",
			"CB",
			80
		],
		[
			"Renan",
			"Lodi",
			"LB",
			80
		],
		[
			"Valentin",
			"Rongier",
			"CM",
			82
		],
		[
			"Jordan",
			"Veretout",
			"CM",
			82
		],
		[
			"Amine",
			"Harit",
			"CAM",
			82
		],
		[
			"Pierre-Emerick",
			"Aubameyang",
			"ST",
			82
		],
		[
			"Ismaila",
			"Sarr",
			"RW",
			81
		],
		[
			"Iliman",
			"Ndiaye",
			"LW",
			80
		],
		[
			"Azzedine",
			"Ounahi",
			"CM",
			80
		],
		[
			"Samuel",
			"Gigot",
			"CB",
			80
		],
		[
			"Faris",
			"Moumbagna",
			"ST",
			78
		],
		[
			"Ruben",
			"Blanco",
			"GK",
			78
		]
	]),
	"lyo-n": squad("lyo-n", [
		[
			"Anthony",
			"Lopes",
			"GK",
			82
		],
		[
			"Clinton",
			"Mata",
			"RB",
			78
		],
		[
			"Duje",
			"Caleta-Car",
			"CB",
			82
		],
		[
			"Jake",
			"O'Brien",
			"CB",
			78
		],
		[
			"Nicolas",
			"Tagliafico",
			"LB",
			80
		],
		[
			"Maxence",
			"Caqueret",
			"CM",
			82
		],
		[
			"Corentin",
			"Tolisso",
			"CM",
			82
		],
		[
			"Rayan",
			"Cherki",
			"CAM",
			80
		],
		[
			"Alexandre",
			"Lacazette",
			"ST",
			82
		],
		[
			"Ernest",
			"Nuamah",
			"LW",
			78
		],
		[
			"Ainsley",
			"Maitland-Niles",
			"RB",
			78
		],
		[
			"Mama",
			"Balde",
			"RW",
			78
		],
		[
			"Orel",
			"Mangala",
			"CDM",
			78
		],
		[
			"Remy",
			"Riou",
			"GK",
			78
		],
		[
			"Said",
			"Benrahma",
			"LW",
			78
		]
	]),
	"ist-asl": squad("ist-asl", [
		[
			"Fernando",
			"Muslera",
			"GK",
			82
		],
		[
			"Sacha",
			"Boey",
			"RB",
			82
		],
		[
			"Davinson",
			"Sanchez",
			"CB",
			82
		],
		[
			"Victor",
			"Nelsson",
			"CB",
			80
		],
		[
			"Angelino",
			"",
			"LB",
			82
		],
		[
			"Lucas",
			"Torreira",
			"CDM",
			83
		],
		[
			"Kerem",
			"Demirbay",
			"CM",
			82
		],
		[
			"Dries",
			"Mertens",
			"CAM",
			82
		],
		[
			"Hakim",
			"Ziyech",
			"RW",
			84
		],
		[
			"Mauro",
			"Icardi",
			"ST",
			85
		],
		[
			"Kerem",
			"Akturkoglu",
			"LW",
			83
		],
		[
			"Baris",
			"Alper Yilmaz",
			"RW",
			80
		],
		[
			"Sergio",
			"Oliveira",
			"CM",
			80
		],
		[
			"Abdulkerim",
			"Bardakci",
			"CB",
			78
		],
		[
			"Gunay",
			"Guvenc",
			"GK",
			78
		]
	], [
		"URU",
		"FRA",
		"COL",
		"DEN",
		"ESP",
		"URU",
		"GER",
		"BEL",
		"MAR",
		"ARG",
		"TUR",
		"TUR",
		"POR",
		"TUR",
		"TUR"
	]),
	"ist-kan": squad("ist-kan", [
		[
			"Dominik",
			"Livakovic",
			"GK",
			82
		],
		[
			"Bright",
			"Osayi-Samuel",
			"RB",
			82
		],
		[
			"Alexander",
			"Djiku",
			"CB",
			82
		],
		[
			"Ferdi",
			"Kadioglu",
			"LB",
			82
		],
		[
			"Ismail",
			"Yuksek",
			"CDM",
			80
		],
		[
			"Fred",
			"",
			"CM",
			83
		],
		[
			"Irfan Can",
			"Kahveci",
			"CAM",
			82
		],
		[
			"Sebastian",
			"Szymanski",
			"CAM",
			83
		],
		[
			"Dusan",
			"Tadic",
			"RW",
			83
		],
		[
			"Edin",
			"Dzeko",
			"ST",
			83
		],
		[
			"Cengiz",
			"Under",
			"RW",
			81
		],
		[
			"Yusuf",
			"Kahveci",
			"CM",
			78
		],
		[
			"Jayden",
			"Oosterwolde",
			"LB",
			78
		],
		[
			"Leonardo",
			"Bonucci",
			"CB",
			80
		],
		[
			"Irfan Can",
			"Egribayat",
			"GK",
			78
		]
	]),
	"ist-kar": squad("ist-kar", [
		[
			"Mert",
			"Gunok",
			"GK",
			81
		],
		[
			"Jonas",
			"Svensson",
			"RB",
			79
		],
		[
			"Omar",
			"Colley",
			"CB",
			80
		],
		[
			"Necip",
			"Uysal",
			"CB",
			78
		],
		[
			"Arthur",
			"Masuaku",
			"LB",
			80
		],
		[
			"Gedson",
			"Fernandes",
			"CM",
			80
		],
		[
			"Salih",
			"Ucan",
			"CM",
			79
		],
		[
			"Rachid",
			"Ghezzal",
			"CAM",
			80
		],
		[
			"Cenk",
			"Tosun",
			"ST",
			79
		],
		[
			"Vincent",
			"Aboubakar",
			"ST",
			81
		],
		[
			"Semih",
			"Kilicsoy",
			"ST",
			76
		],
		[
			"Alex",
			"Oxlade-Chamberlain",
			"CM",
			80
		],
		[
			"Daniel",
			"Amartey",
			"CB",
			78
		],
		[
			"Bakhtiyor",
			"Zaynutdinov",
			"LB",
			78
		],
		[
			"Ersin",
			"Destanoglu",
			"GK",
			78
		]
	]),
	"trb-fir": squad("trb-fir", [
		[
			"Ugurcan",
			"Cakir",
			"GK",
			83
		],
		[
			"Jens",
			"Stryger",
			"RB",
			78
		],
		[
			"Stefano",
			"Denswil",
			"CB",
			79
		],
		[
			"Taha",
			"Tepe",
			"CB",
			76
		],
		[
			"Eren",
			"Elmali",
			"LB",
			78
		],
		[
			"Berat",
			"Ozdemir",
			"CDM",
			78
		],
		[
			"Enis",
			"Bardhi",
			"CM",
			81
		],
		[
			"Edin",
			"Visca",
			"RW",
			82
		],
		[
			"Anastasios",
			"Bakasetas",
			"CAM",
			82
		],
		[
			"Paul",
			"Onuachu",
			"ST",
			82
		],
		[
			"Trezeguet",
			"",
			"LW",
			81
		],
		[
			"Thomas",
			"Meunier",
			"RB",
			80
		],
		[
			"Batista",
			"Mendy",
			"CB",
			78
		],
		[
			"Ozan",
			"Tufan",
			"CM",
			78
		],
		[
			"Ugurcan",
			"Cakir",
			"GK",
			83
		]
	]),
	"bil-lio": squad("bil-lio", [
		[
			"Unai",
			"Simon",
			"GK",
			85
		],
		[
			"Oscar",
			"de Marcos",
			"RB",
			78
		],
		[
			"Dani",
			"Vivian",
			"CB",
			82
		],
		[
			"Aitor",
			"Paredes",
			"CB",
			78
		],
		[
			"Yuri",
			"Berchiche",
			"LB",
			79
		],
		[
			"Mikel",
			"Vesga",
			"CDM",
			78
		],
		[
			"Mikel",
			"Merino",
			"CM",
			84
		],
		[
			"Oihan",
			"Sancet",
			"CAM",
			82
		],
		[
			"Inaki",
			"Williams",
			"RW",
			82
		],
		[
			"Gorka",
			"Guruzeta",
			"ST",
			79
		],
		[
			"Nico",
			"Williams",
			"LW",
			82
		],
		[
			"Alex",
			"Berenguer",
			"RW",
			78
		],
		[
			"Inigo",
			"Ruiz de Galarreta",
			"CM",
			78
		],
		[
			"Yeray",
			"Alvarez",
			"CB",
			80
		],
		[
			"Julen",
			"Agirrezabala",
			"GK",
			76
		]
	]),
	"san-seb": squad("san-seb", [
		[
			"Alex",
			"Remiro",
			"GK",
			84
		],
		[
			"Hamari",
			"Traore",
			"RB",
			79
		],
		[
			"Igor",
			"Zubeldia",
			"CB",
			80
		],
		[
			"Robin",
			"Le Normand",
			"CB",
			82
		],
		[
			"Aihen",
			"Munoz",
			"LB",
			78
		],
		[
			"Martin",
			"Zubimendi",
			"CDM",
			84
		],
		[
			"Mikel",
			"Merino",
			"CM",
			83
		],
		[
			"Brais",
			"Mendez",
			"CAM",
			82
		],
		[
			"Takefusa",
			"Kubo",
			"RW",
			83
		],
		[
			"Mikel",
			"Oyarzabal",
			"CF",
			83
		],
		[
			"Ander",
			"Barrenetxea",
			"LW",
			80
		],
		[
			"Benat",
			"Turrientes",
			"CM",
			78
		],
		[
			"Jon",
			"Pacheco",
			"CB",
			78
		],
		[
			"Umar",
			"Sadiq",
			"ST",
			80
		],
		[
			"Andoni",
			"Zubiaurre",
			"GK",
			72
		]
	]),
	"vil-yel": squad("vil-yel", [
		[
			"Filip",
			"Jorgensen",
			"GK",
			82
		],
		[
			"Kiko",
			"Femenia",
			"RB",
			78
		],
		[
			"Raul",
			"Albiol",
			"CB",
			80
		],
		[
			"Logan",
			"Costa",
			"CB",
			78
		],
		[
			"Alfonso",
			"Pedraza",
			"LB",
			79
		],
		[
			"Dani",
			"Parejo",
			"CM",
			83
		],
		[
			"Etienne",
			"Capoue",
			"CDM",
			80
		],
		[
			"Alex",
			"Baena",
			"CAM",
			83
		],
		[
			"Yeremy",
			"Pino",
			"RW",
			80
		],
		[
			"Gerard",
			"Moreno",
			"ST",
			83
		],
		[
			"Alexander",
			"Sorloth",
			"ST",
			82
		],
		[
			"Manu",
			"Trigueros",
			"CM",
			78
		],
		[
			"Jorge",
			"Cuenca",
			"CB",
			78
		],
		[
			"Aissa",
			"Mandi",
			"CB",
			80
		],
		[
			"Pepe",
			"Reina",
			"GK",
			76
		]
	])
};
function displayName(p) {
	return (p.first + " " + p.last).trim();
}
var FALLBACK_POS = [
	"GK",
	"GK",
	"RB",
	"CB",
	"CB",
	"CB",
	"LB",
	"CDM",
	"CM",
	"CM",
	"CAM",
	"RM",
	"LM",
	"RW",
	"LW",
	"ST",
	"ST",
	"CF"
];
function generateSquad(teamId) {
	const existing = TEAM_SQUADS[teamId];
	if (existing && existing.length >= 14) return existing.map((p) => ({ ...p }));
	const team = TEAM_BY_ID[teamId];
	const rng = mulberry32(hashSeed(teamId + "_squad"));
	const pool = NAMES[team?.country === "Turkiye" ? "TUR" : team?.country === "England" ? "ENG" : countryNat(team?.country)] || NAMES.ENG;
	const out = [];
	for (let i = 0; i < 16; i++) {
		const pos = FALLBACK_POS[i] ?? pick(rng, POSITIONS).id;
		const ovr = clampOvr(team?.power ?? 62, pos, rng);
		out.push({
			id: teamId + "_g" + i,
			first: pick(rng, pool.first),
			last: pick(rng, pool.last),
			pos,
			ovr,
			age: irand(rng, 18, 34),
			nat: pool === NAMES.ENG ? "ENG" : Object.keys(NAMES).find((k) => NAMES[k] === pool) || "ENG"
		});
	}
	return out;
}
function countryNat(c) {
	return {
		Spain: "ESP",
		Germany: "GER",
		Italy: "ITA",
		France: "FRA",
		Turkiye: "TUR",
		Azerbaijan: "AZE",
		Netherlands: "NED",
		Portugal: "POR",
		Brazil: "BRA",
		Argentina: "ARG",
		USA: "USA",
		Belgium: "BEL",
		Scotland: "SCO",
		England: "ENG"
	}[c || ""] || "ENG";
}
function clampOvr(power, pos, rng) {
	const jitter = Math.floor(rng() * 10) - 5;
	const gkBias = pos === "GK" ? -2 : 0;
	return Math.max(48, Math.min(92, power - 6 + jitter + gkBias));
}
function computeRole(playerOvr, teamPower, form) {
	const gap = playerOvr + (form - 60) * .08 - teamPower;
	if (gap >= -4) return "starter";
	if (gap >= -11) return "rotation";
	return "bench";
}
function defaultDraft() {
	return {
		firstName: "Arda",
		lastName: "Yilmaz",
		displayName: "A. Yilmaz",
		nat: "TUR",
		nat2: "",
		dob: "2005-03-12",
		foot: "right",
		pos: "CAM",
		pos2: "",
		height: 178,
		weight: 72,
		number: 10,
		archetype: "play",
		personality: "ambitious",
		attrs: blankAttrs(55),
		points: 30
	};
}
function buildPlayer(d) {
	const rng = mulberry32(Date.now() % 1e6);
	const attrs = {
		...blankAttrs(55),
		...d.attrs
	};
	for (const k of ALL_ATTRS) if (attrs[k] == null) attrs[k] = 55;
	const overall = calcOverall(d.pos, attrs);
	const potential = clamp(overall + irand(rng, 15, 30), overall + 4, 95);
	return {
		firstName: d.firstName.trim() || "Oyuncu",
		lastName: d.lastName.trim() || "Yeni",
		displayName: d.displayName.trim() || (d.firstName[0] || "O") + ". " + (d.lastName || "Yeni"),
		nat: d.nat,
		nat2: d.nat2,
		dob: d.dob,
		foot: d.foot,
		pos: d.pos,
		pos2: d.pos2,
		height: d.height,
		weight: d.weight,
		number: d.number,
		archetype: d.archetype || ARCHETYPES[0].id,
		personality: d.personality,
		attrs,
		overall,
		potential,
		growthRate: .75 + rng() * .5,
		peakAge: irand(rng, 27, 31),
		injurySusceptibility: .3 + rng() * .5,
		professionalism: {
			professional: 88,
			ambitious: 74,
			loyal: 80,
			fiery: 62,
			calm: 78,
			determined: 84
		}[d.personality],
		consistency: .5 + rng() * .4,
		fitness: 100,
		morale: 75,
		form: 60,
		fatigue: 10,
		happiness: 75,
		energy: 100,
		stress: 20,
		confidence: 65,
		popularity: 20,
		reputation: 25
	};
}
function wageFor(ovr, teamPower) {
	return Math.round((Math.max(0, ovr - 48) * 420 + teamPower * 70) / 50) * 50;
}
function generateFixtures(teamIds) {
	const ids = teamIds.slice();
	if (ids.length % 2 === 1) ids.push("BYE");
	const n = ids.length;
	const rounds = n - 1;
	const half = n / 2;
	const rotating = ids.slice(1);
	const fixtures = [];
	for (let r = 0; r < rounds; r++) {
		const round = [ids[0], ...rotating];
		for (let i = 0; i < half; i++) {
			const a = round[i];
			const b = round[n - 1 - i];
			if (a === "BYE" || b === "BYE") continue;
			const home = r % 2 === 0 ? a : b;
			const away = r % 2 === 0 ? b : a;
			fixtures.push({
				week: r + 1,
				home,
				away
			});
		}
		rotating.unshift(rotating.pop());
	}
	const firstHalf = fixtures.slice();
	const offset = rounds;
	for (const f of firstHalf) fixtures.push({
		week: f.week + offset,
		home: f.away,
		away: f.home
	});
	return fixtures;
}
function emptyTable(ids) {
	return ids.map((teamId) => ({
		teamId,
		played: 0,
		won: 0,
		drawn: 0,
		lost: 0,
		gf: 0,
		ga: 0,
		pts: 0
	}));
}
function startCareer(player, clubId, slot) {
	const team = TEAM_BY_ID[clubId];
	const leagueId = team.leagueId;
	const ids = teamsInLeague(leagueId).map((c) => c.id);
	const rng = mulberry32(slot * 999 + player.overall * 13);
	const wage = wageFor(player.overall, team.power);
	const role = computeRole(player.overall, team.power, player.form);
	return {
		slot,
		version: 25,
		player,
		clubId,
		leagueId,
		season: "2026/27",
		date: "2026-08-15",
		week: 1,
		seasonIndex: 0,
		seasonStats: {
			apps: 0,
			starts: 0,
			goals: 0,
			assists: 0,
			shots: 0,
			keyPasses: 0,
			tackles: 0,
			minutes: 0,
			yellowCards: 0,
			redCards: 0,
			motm: 0,
			ratingSum: 0,
			avgRating: 0
		},
		careerHistory: [{
			week: 1,
			season: "2026/27",
			text: player.displayName + ", " + team.name + " ile anlasti."
		}],
		trophies: [],
		awards: [],
		news: [{
			id: uid("n"),
			week: 1,
			title: "Yeni imza",
			body: team.name + ", " + player.displayName + " ile sozlesme imzaladi.",
			kind: "club"
		}],
		teammates: generateSquad(clubId),
		manager: {
			first: pick(rng, MANAGER_FIRST),
			last: pick(rng, MANAGER_LAST),
			trust: irand(rng, 55, 70),
			style: pick(rng, [
				"4-3-3",
				"4-2-3-1",
				"3-5-2",
				"4-4-2"
			])
		},
		finances: {
			balance: Math.round(wage * 8),
			weeklyWage: wage,
			monthlyIncome: 0,
			monthlyExpenses: 400
		},
		contract: {
			years: 3,
			weeklyWage: wage,
			appearanceBonus: 1500,
			goalBonus: 5e3,
			assistBonus: 2500,
			signedWeek: 1
		},
		agent: {
			first: pick(rng, AGENT_FIRST),
			last: pick(rng, AGENT_LAST),
			cut: 8
		},
		training: {
			focus: "balanced",
			intensity: "mid"
		},
		transferInterest: [],
		notifications: ["Kariyer basladi. Ilk antrenmanini planla."],
		achievements: [],
		worldTransfers: [],
		life: {
			home: 0,
			car: 0,
			relationship: "single",
			partnerName: "",
			togetherWeeks: 0,
			kids: 0,
			family: 50,
			friends: 45,
			business: 0,
			events: [{
				week: 1,
				text: "Kiralik daireye yerlestin."
			}]
		},
		injury: null,
		lastResult: null,
		social: initSocial(player),
		socialLastEvent: "",
		fixtures: generateFixtures(ids),
		table: emptyTable(ids),
		matchLog: [],
		role,
		offers: []
	};
}
function slotKey(slot) {
	return SAVE_PREFIX + slot;
}
function listSlots() {
	return [
		0,
		1,
		2
	].map((slot) => {
		const raw = safeGet(slotKey(slot));
		if (!raw) return {
			slot,
			occupied: false
		};
		try {
			const s = JSON.parse(raw).state;
			if (!s?.player) return {
				slot,
				occupied: false
			};
			return {
				slot,
				occupied: true,
				name: s.player.displayName,
				club: s.clubId,
				ovr: s.player.overall,
				week: s.week,
				season: s.season
			};
		} catch {
			return {
				slot,
				occupied: false
			};
		}
	});
}
function loadSlot(slot) {
	const raw = safeGet(slotKey(slot));
	if (!raw) return null;
	try {
		const s = JSON.parse(raw).state;
		if (!s?.player) return null;
		s.slot = slot;
		s.version = 25;
		return s;
	} catch {
		return null;
	}
}
function saveSlot(state) {
	const payload = JSON.stringify({
		slot: state.slot,
		version: 25,
		state
	});
	try {
		localStorage.setItem(slotKey(state.slot), payload);
		return true;
	} catch {
		return false;
	}
}
function clearSlot(slot) {
	try {
		localStorage.removeItem(slotKey(slot));
	} catch {}
}
function safeGet(key) {
	try {
		return localStorage.getItem(key);
	} catch {
		return null;
	}
}
var STARS = [
	{
		name: "Lionel Messa",
		pos: "RW",
		ovr: 88,
		age: 37,
		nat: "ARG"
	},
	{
		name: "Kyliam Mbappi",
		pos: "ST",
		ovr: 91,
		age: 25,
		nat: "FRA"
	},
	{
		name: "Erling Hollan",
		pos: "ST",
		ovr: 91,
		age: 24,
		nat: "NOR"
	},
	{
		name: "Jude Bellingam",
		pos: "CAM",
		ovr: 89,
		age: 21,
		nat: "ENG"
	},
	{
		name: "Vinicius Junior",
		pos: "LW",
		ovr: 89,
		age: 24,
		nat: "BRA"
	},
	{
		name: "Kevin De Bruyn",
		pos: "CAM",
		ovr: 90,
		age: 33,
		nat: "BEL"
	},
	{
		name: "Kylian Mbappe",
		pos: "ST",
		ovr: 91,
		age: 25,
		nat: "FRA"
	},
	{
		name: "Rodri",
		pos: "CDM",
		ovr: 89,
		age: 28,
		nat: "ESP"
	},
	{
		name: "Harry Kane",
		pos: "ST",
		ovr: 89,
		age: 31,
		nat: "ENG"
	},
	{
		name: "Thibaut Courtois",
		pos: "GK",
		ovr: 89,
		age: 32,
		nat: "BEL"
	},
	{
		name: "Virgil van Dijki",
		pos: "CB",
		ovr: 88,
		age: 33,
		nat: "NED"
	},
	{
		name: "Mohamed Sala",
		pos: "RW",
		ovr: 88,
		age: 32,
		nat: "EGY"
	},
	{
		name: "Robert Lewandowski",
		pos: "ST",
		ovr: 88,
		age: 36,
		nat: "POL"
	},
	{
		name: "Alison Becker",
		pos: "GK",
		ovr: 88,
		age: 32,
		nat: "BRA"
	},
	{
		name: "Lamine Yamal",
		pos: "RW",
		ovr: 87,
		age: 17,
		nat: "ESP"
	},
	{
		name: "Pedri",
		pos: "CM",
		ovr: 86,
		age: 21,
		nat: "ESP"
	},
	{
		name: "Florian Wirtz",
		pos: "CAM",
		ovr: 88,
		age: 21,
		nat: "GER"
	},
	{
		name: "Jamal Musiala",
		pos: "CAM",
		ovr: 86,
		age: 21,
		nat: "GER"
	},
	{
		name: "Bukayo Saka",
		pos: "RW",
		ovr: 86,
		age: 23,
		nat: "ENG"
	},
	{
		name: "Phil Foden",
		pos: "LW",
		ovr: 87,
		age: 24,
		nat: "ENG"
	},
	{
		name: "Martin Odegaard",
		pos: "CAM",
		ovr: 87,
		age: 25,
		nat: "NOR"
	},
	{
		name: "Bruno Fernandes",
		pos: "CAM",
		ovr: 87,
		age: 30,
		nat: "POR"
	},
	{
		name: "Federico Valverde",
		pos: "CM",
		ovr: 87,
		age: 26,
		nat: "URU"
	},
	{
		name: "Nicolo Barella",
		pos: "CM",
		ovr: 86,
		age: 27,
		nat: "ITA"
	},
	{
		name: "Lautaro Martinez",
		pos: "ST",
		ovr: 87,
		age: 27,
		nat: "ARG"
	},
	{
		name: "Victor Osimhen",
		pos: "ST",
		ovr: 86,
		age: 25,
		nat: "NGA"
	},
	{
		name: "Khvicha Kvaratskhelia",
		pos: "LW",
		ovr: 85,
		age: 23,
		nat: "GEO"
	},
	{
		name: "Rafael Leao",
		pos: "LW",
		ovr: 85,
		age: 25,
		nat: "POR"
	},
	{
		name: "Cole Palmer",
		pos: "CAM",
		ovr: 85,
		age: 22,
		nat: "ENG"
	},
	{
		name: "Declan Rice",
		pos: "CDM",
		ovr: 86,
		age: 25,
		nat: "ENG"
	},
	{
		name: "William Saliba",
		pos: "CB",
		ovr: 86,
		age: 23,
		nat: "FRA"
	},
	{
		name: "Ruben Dias",
		pos: "CB",
		ovr: 87,
		age: 27,
		nat: "POR"
	},
	{
		name: "Antonio Rudiger",
		pos: "CB",
		ovr: 86,
		age: 31,
		nat: "GER"
	},
	{
		name: "Trent Alexander",
		pos: "RB",
		ovr: 86,
		age: 26,
		nat: "ENG"
	},
	{
		name: "Achraf Hakimi",
		pos: "RB",
		ovr: 85,
		age: 25,
		nat: "MAR"
	},
	{
		name: "Alphonso Davies",
		pos: "LB",
		ovr: 85,
		age: 24,
		nat: "CAN"
	},
	{
		name: "Theo Hernandez",
		pos: "LB",
		ovr: 85,
		age: 26,
		nat: "FRA"
	},
	{
		name: "Edersson",
		pos: "GK",
		ovr: 88,
		age: 31,
		nat: "BRA"
	},
	{
		name: "Jan Oblak",
		pos: "GK",
		ovr: 87,
		age: 31,
		nat: "SVN"
	},
	{
		name: "Gianluigi Donnarumma",
		pos: "GK",
		ovr: 87,
		age: 25,
		nat: "ITA"
	},
	{
		name: "Antoine Griezmann",
		pos: "CF",
		ovr: 86,
		age: 33,
		nat: "FRA"
	},
	{
		name: "Son Heung-min",
		pos: "LW",
		ovr: 86,
		age: 32,
		nat: "KOR"
	},
	{
		name: "Hakan Calhanoglu",
		pos: "CDM",
		ovr: 85,
		age: 30,
		nat: "TUR"
	},
	{
		name: "Mauro Icardi",
		pos: "ST",
		ovr: 85,
		age: 31,
		nat: "ARG"
	},
	{
		name: "Dušan Vlahovic",
		pos: "ST",
		ovr: 85,
		age: 24,
		nat: "SRB"
	},
	{
		name: "Alexander Isak",
		pos: "ST",
		ovr: 84,
		age: 25,
		nat: "SWE"
	},
	{
		name: "Ollie Watkins",
		pos: "ST",
		ovr: 84,
		age: 28,
		nat: "ENG"
	},
	{
		name: "Marcus Rashford",
		pos: "LW",
		ovr: 84,
		age: 26,
		nat: "ENG"
	},
	{
		name: "Gabriel Martinelli",
		pos: "LW",
		ovr: 84,
		age: 23,
		nat: "BRA"
	},
	{
		name: "Rodrygo Goes",
		pos: "RW",
		ovr: 86,
		age: 23,
		nat: "BRA"
	}
];
var ATTACK = [
	{
		id: "shot",
		label: "Sut Cek",
		attr: "finishing",
		success: "Aglar sarsildi.",
		fail: "Kaleci tuttu.",
		tone: "goal",
		onSuccess: {
			goals: 1,
			shots: 1
		},
		onFail: { shots: 1 }
	},
	{
		id: "thru",
		label: "Ara Pasi",
		attr: "passing",
		success: "Kilit pas, gol pozisyonu.",
		fail: "Pas kesildi.",
		tone: "key",
		onSuccess: {
			assists: 1,
			keyPasses: 1
		}
	},
	{
		id: "drib",
		label: "Top Sur",
		attr: "dribbling",
		success: "Iki adami gecti.",
		fail: "Topu kaptirdi.",
		tone: "key",
		onSuccess: { shots: 1 },
		onFail: { concede: 0 }
	},
	{
		id: "cross",
		label: "Orta Yap",
		attr: "crossing",
		success: "Muthisem orta, kafa golü.",
		fail: "Orta disari.",
		tone: "goal",
		onSuccess: {
			assists: 1,
			keyPasses: 1
		}
	}
];
var DEFENSE = [
	{
		id: "stand",
		label: "Ayakta Mudahale",
		attr: "standingTackle",
		success: "Topu temiz kaptin.",
		fail: "Gectiler.",
		tone: "key",
		onSuccess: { tackles: 1 },
		onFail: { concede: 1 }
	},
	{
		id: "slide",
		label: "Kayarak Mudahale",
		attr: "slidingTackle",
		success: "Kayarak kesti.",
		fail: "Gec kaldin, sari kart.",
		tone: "warn",
		onSuccess: { tackles: 1 },
		onFail: {
			yellow: 1,
			concede: 1
		}
	},
	{
		id: "pos",
		label: "Pozisyon Al",
		attr: "defensiveAwareness",
		success: "Hucumu yavaslattin.",
		fail: "Bosluk biraktin.",
		tone: "key"
	},
	{
		id: "foul",
		label: "Taktik Faul",
		attr: "aggression",
		success: "Faul, tehlike bitti.",
		fail: "Sari kart.",
		tone: "warn",
		onFail: { yellow: 1 }
	}
];
var MID = [
	{
		id: "give",
		label: "Veren-Alan",
		attr: "passing",
		success: "Temiz pas zinciri.",
		fail: "Pas geri donmedi.",
		tone: "key",
		onSuccess: { keyPasses: 1 }
	},
	{
		id: "carry",
		label: "Top Sur",
		attr: "dribbling",
		success: "Ortaya tasidi.",
		fail: "Pres altinda kaybetti.",
		tone: "key"
	},
	{
		id: "safe",
		label: "Guvenli Pas",
		attr: "passing",
		success: "Top korundu.",
		fail: "Geri pas kisa kaldi.",
		tone: "key"
	},
	{
		id: "long",
		label: "Ara Pasi",
		attr: "longPassing",
		success: "Derinlemesine pas.",
		fail: "Uzun pas israf.",
		tone: "key",
		onSuccess: { keyPasses: 1 }
	}
];
function startChance(trust, role) {
	const base = clamp(trust / 100 * 1.25, .12, .97);
	if (role === "starter") return clamp(base + .18, .35, .97);
	if (role === "rotation") return clamp(base, .22, .8);
	return clamp(base * .45, .12, .4);
}
function pickMoments(count, seed) {
	const rng = mulberry32(seed);
	const out = [];
	for (let i = 0; i < count; i++) {
		const minute = 4 + Math.floor((i + rng()) / count * 84);
		const r = rng();
		const zone = r < .38 ? "attack" : r < .7 ? "mid" : "defense";
		const opts = shuffle(zone === "attack" ? ATTACK : zone === "defense" ? DEFENSE : MID, rng).slice(0, 3 + (rng() > .5 ? 1 : 0));
		const prompt = zone === "attack" ? "Ceza sahasina girdin. Ne yaparsin?" : zone === "defense" ? "Rakip hucumda. Mudahele et." : "Orta sahada top sende.";
		out.push({
			minute,
			zone,
			prompt,
			options: opts
		});
	}
	return out.sort((a, b) => a.minute - b.minute);
}
function shuffle(arr, rng) {
	const a = arr.slice();
	for (let i = a.length - 1; i > 0; i--) {
		const j = Math.floor(rng() * (i + 1));
		const t = a[i];
		a[i] = a[j];
		a[j] = t;
	}
	return a;
}
function chanceOf(attr, form, fatigue) {
	return clamp(attr / 100 * .72 + form / 100 * .2 - fatigue / 200 * .1 + .08, .12, .92);
}
function expectedGoals(homePow, awayPow, home) {
	const ratio = homePow / Math.max(1, awayPow);
	return clamp((home ? 1.45 : 1.15) * Math.pow(ratio, 1.15), .4, 3.4);
}
function poissonLike(lambda, rng) {
	let n = 0;
	const limit = 8;
	for (let i = 0; i < limit; i++) if (rng() < lambda / (i + 1.6)) n++;
	return n;
}
function simAutoMatch(state, homeId, awayId, cup = false) {
	const rng = mulberry32(state.week * 997 + hash(homeId + awayId));
	const home = TEAM_BY_ID[homeId];
	const away = TEAM_BY_ID[awayId];
	const hp = (home?.power ?? 70) + (state.clubId === homeId ? (state.player.form - 60) * .05 : 0);
	const ap = (away?.power ?? 70) + (state.clubId === awayId ? (state.player.form - 60) * .05 : 0);
	let hg = poissonLike(expectedGoals(hp, ap, true), rng);
	let ag = poissonLike(expectedGoals(ap, hp, false), rng);
	const meHome = state.clubId === homeId;
	const role = state.role;
	const starts = role === "starter" || role === "rotation" && rng() < .55;
	const minutes = starts ? irand(rng, 72, 94) : role === "bench" ? irand(rng, 8, 28) : irand(rng, 35, 70);
	const pos = state.player.pos;
	let goals = 0;
	let assists = 0;
	let shots = 0;
	let keyPasses = 0;
	let tackles = 0;
	const att = state.player.attrs;
	const finishP = (att.finishing ?? 55) / 140;
	if (isFwd(pos) && minutes > 20 && rng() < finishP) {
		goals = rng() < .22 ? 2 : 1;
		shots = goals + irand(rng, 1, 3);
		if (meHome) hg = Math.max(hg, goals);
		else ag = Math.max(ag, goals);
	} else if (minutes > 25) {
		shots = irand(rng, 0, isFwd(pos) ? 4 : 2);
		if (rng() < (att.passing ?? 55) / 180) assists = 1;
		keyPasses = irand(rng, 0, 3);
		tackles = irand(rng, 0, isDef(pos) ? 5 : 2);
	}
	let rating = 6.2 + (state.player.form - 60) * .015 + (starts ? .3 : -.2);
	rating += goals * .7 + assists * .4 + (shots > 2 ? .15 : 0);
	const won = meHome && hg > ag || !meHome && ag > hg;
	const draw = hg === ag;
	if (won) rating += .25;
	if (draw) rating += .05;
	rating = clamp(Math.round(rating * 10) / 10, 4.8, 9.7);
	const yellow = rng() < .12;
	const red = rng() < .015;
	const motm = rating >= 8.3 && (goals > 0 || assists > 0 || rating >= 8.8);
	return {
		week: state.week,
		home: homeId,
		away: awayId,
		hg,
		ag,
		rating,
		goals,
		assists,
		minutes,
		motm,
		yellow,
		red,
		shots,
		keyPasses,
		tackles,
		role,
		cup
	};
}
function applyResultToTable(table, homeId, awayId, hg, ag) {
	const next = table.map((r) => ({ ...r }));
	const h = next.find((r) => r.teamId === homeId);
	const a = next.find((r) => r.teamId === awayId);
	if (!h || !a) return next;
	h.played++;
	a.played++;
	h.gf += hg;
	h.ga += ag;
	a.gf += ag;
	a.ga += hg;
	if (hg > ag) {
		h.won++;
		h.pts += 3;
		a.lost++;
	} else if (ag > hg) {
		a.won++;
		a.pts += 3;
		h.lost++;
	} else {
		h.drawn++;
		a.drawn++;
		h.pts++;
		a.pts++;
	}
	return next;
}
function isFwd(p) {
	return p === "ST" || p === "CF" || p === "LW" || p === "RW";
}
function isDef(p) {
	return p === "CB" || p === "LB" || p === "RB" || p === "CDM" || p === "LWB" || p === "RWB";
}
function hash(s) {
	let h = 0;
	for (let i = 0; i < s.length; i++) h = h * 31 + s.charCodeAt(i) | 0;
	return Math.abs(h);
}
var AMBIENT = [
	"Orta sahada tempo dustu.",
	"Tribunler ritim tutuyor.",
	"Korner bayragi kalkti.",
	"Hoca kenardan bagiriyor.",
	"Pres yukseldi.",
	"Top disari, aut vurusu.",
	"Hava topu... stoper cikardi.",
	"Hizli cikis denendi."
];
function logLife(state, text) {
	state.life.events.unshift({
		week: state.week,
		text
	});
	state.life.events = state.life.events.slice(0, 10);
}
function rest(state) {
	const s = structuredClone(state);
	s.player.energy = clamp(s.player.energy + 20, 0, 100);
	s.player.fatigue = clamp(s.player.fatigue - 15, 0, 100);
	s.player.happiness = clamp(s.player.happiness + 2, 0, 100);
	logLife(s, "Dinlendin.");
	return s;
}
function familyVisit(state) {
	const s = structuredClone(state);
	s.life.family = clamp(s.life.family + 8, 0, 100);
	s.player.happiness = clamp(s.player.happiness + 6, 0, 100);
	logLife(s, "Aile ziyareti.");
	return s;
}
function friendsOut(state) {
	const s = structuredClone(state);
	s.life.friends = clamp(s.life.friends + 8, 0, 100);
	s.player.happiness = clamp(s.player.happiness + 5, 0, 100);
	logLife(s, "Arkadaslarla bulustun.");
	return s;
}
function gym(state) {
	const s = structuredClone(state);
	s.player.fitness = clamp(s.player.fitness + 5, 0, 100);
	s.player.energy = clamp(s.player.energy - 8, 0, 100);
	s.player.stress = clamp(s.player.stress - 5, 0, 100);
	logLife(s, "Spor salonu.");
	return s;
}
function spend(state, cost, apply, label) {
	if (state.finances.balance < cost) return "Yetersiz bakiye.";
	const s = structuredClone(state);
	s.finances.balance -= cost;
	apply(s);
	logLife(s, label);
	return s;
}
function party(state) {
	return spend(state, 2e4, (s) => {
		s.player.happiness = clamp(s.player.happiness + 12, 0, 100);
		s.player.popularity = clamp(s.player.popularity + 2, 0, 100);
	}, "Parti verdin.");
}
function vacation(state) {
	return spend(state, 5e4, (s) => {
		s.player.happiness = clamp(s.player.happiness + 15, 0, 100);
		s.player.stress = clamp(s.player.stress - 25, 0, 100);
		s.player.energy = clamp(s.player.energy + 20, 0, 100);
	}, "Tatile ciktin.");
}
function donate(state) {
	return spend(state, 1e4, (s) => {
		s.player.reputation = clamp(s.player.reputation + 2, 0, 100);
		s.player.happiness = clamp(s.player.happiness + 5, 0, 100);
	}, "Bagis yaptin.");
}
function invest(state) {
	return spend(state, 2e5, (s) => {
		const add = irand(Math.random, 5e3, 15e3);
		s.finances.monthlyIncome += add;
		s.life.business += 1;
	}, "Is yatirimi.");
}
function buyHome(state, level) {
	const h = HOMES[level];
	if (!h) return "Gecersiz.";
	if (state.life.home >= level) return "Zaten bu seviyede.";
	return spend(state, h.cost, (s) => {
		s.life.home = level;
		if (level >= 3 && !s.achievements.includes("mansion")) s.achievements.push("mansion");
	}, h.tr + " alindi.");
}
function buyCar(state, level) {
	const c = CARS[level];
	if (!c) return "Gecersiz.";
	if (state.life.car >= level) return "Zaten bu seviyede.";
	return spend(state, c.cost, (s) => {
		s.life.car = level;
	}, c.tr + " alindi.");
}
function startDating(state) {
	const s = structuredClone(state);
	s.life.relationship = "dating";
	s.life.partnerName = pick(Math.random, PARTNER_FIRST);
	s.life.togetherWeeks = 0;
	logLife(s, s.life.partnerName + " ile tanistin.");
	return s;
}
function propose(state) {
	const s = structuredClone(state);
	if (Math.random() < .85) {
		s.life.relationship = "engaged";
		logLife(s, "Evlenme teklifi kabul edildi.");
	} else {
		s.player.happiness = clamp(s.player.happiness - 8, 0, 100);
		logLife(s, "Teklif reddedildi. Zaman lazim.");
	}
	return s;
}
function marry(state) {
	const s = structuredClone(state);
	s.life.relationship = "married";
	s.player.happiness = clamp(s.player.happiness + 12, 0, 100);
	if (!s.achievements.includes("married")) s.achievements.push("married");
	logLife(s, "Evlendiniz.");
	return s;
}
function breakUp(state) {
	const s = structuredClone(state);
	s.life.relationship = "single";
	s.life.partnerName = "";
	s.player.happiness = clamp(s.player.happiness - 10, 0, 100);
	logLife(s, "Ayrildiniz.");
	return s;
}
function haveChild(state) {
	const s = structuredClone(state);
	s.life.kids += 1;
	s.player.happiness = clamp(s.player.happiness + 15, 0, 100);
	s.player.stress = clamp(s.player.stress + 10, 0, 100);
	logLife(s, "Cocuk sahibi oldunuz.");
	return s;
}
function weeklyLife(state) {
	const s = structuredClone(state);
	if (s.life.relationship !== "single") s.life.togetherWeeks += 1;
	if (Math.random() < .3) {
		const roll = Math.random();
		if (roll < .25) {
			s.player.popularity = clamp(s.player.popularity + 1, 0, 100);
			logLife(s, "Taraftarlar seni destekliyor.");
		} else if (roll < .5) {
			s.player.reputation = clamp(s.player.reputation + 1, 0, 100);
			logLife(s, "Basin senden bahsetti.");
		} else if (roll < .75) {
			const bonus = irand(Math.random, 1e3, 5e3);
			s.finances.balance += bonus;
			logLife(s, "Sponsor teklifi: £" + bonus);
		} else if (s.life.relationship !== "single") {
			s.player.happiness = clamp(s.player.happiness + 3, 0, 100);
			logLife(s, "Partnerinle kaliteli zaman.");
		}
	}
	if (Math.random() < .15 && !s.injury) {
		s.injury = {
			name: pick(Math.random, [
				"Kasik agrisi",
				"Burkulma",
				"Hafif zorlanma"
			]),
			weeksLeft: 1
		};
		s.player.fitness = clamp(s.player.fitness - 12, 20, 100);
		logLife(s, "Hafif sakatlik: " + s.injury.name);
		s.news.unshift({
			id: uid("n"),
			week: s.week,
			title: "Sakatlik uyarisi",
			body: s.player.displayName + " " + s.injury.name.toLowerCase() + " ile idman kacti.",
			kind: "life"
		});
	}
	return s;
}
function applyTraining(state) {
	const s = structuredClone(state);
	const focus = TRAINING_FOCI.find((f) => f.id === s.training.focus) || TRAINING_FOCI[0];
	const inten = INTENSITY[s.training.intensity];
	const ageMult = ageFromDob(s.player.dob, s.date) < s.player.peakAge ? 1.3 : .5;
	if (focus.id !== "recover") {
		for (const key of focus.attrs) if (Math.random() < .15 * inten.mult) {
			const scaled = Math.max(1, Math.round((Math.random() < .5 ? 1 : 2) * (ageMult > 1 ? 1 : 1) * ageMult * s.player.growthRate * (inten.mult >= 1 ? 1 : .8)));
			const cur = s.player.attrs[key] ?? 55;
			if (cur < s.player.potential && cur < 94) s.player.attrs[key] = clamp(cur + scaled, 1, 99);
		}
	}
	s.player.fatigue = clamp(s.player.fatigue + (focus.id === "recover" ? -20 : inten.fatigue), 0, 100);
	s.player.fitness = clamp(s.player.fitness + 8, 0, 100);
	s.player.fatigue = clamp(s.player.fatigue - 25, 0, 100);
	s.player.energy = clamp(s.player.energy + 30, 0, 100);
	s.player.stress = clamp(s.player.stress - 5, 0, 100);
	s.player.overall = calcOverall(s.player.pos, s.player.attrs);
	return s;
}
function currentFixture(state) {
	return state.fixtures.find((f) => f.week === state.week && (f.home === state.clubId || f.away === state.clubId));
}
function applyMatchResult(state, res) {
	const s = structuredClone(state);
	s.lastResult = res;
	s.matchLog.unshift(res);
	s.table = applyResultToTable(s.table, res.home, res.away, res.hg, res.ag);
	const meHome = res.home === s.clubId;
	const gf = meHome ? res.hg : res.ag;
	const ga = meHome ? res.ag : res.hg;
	const won = gf > ga;
	const draw = gf === ga;
	s.seasonStats.apps += 1;
	if (res.minutes >= 60) s.seasonStats.starts += 1;
	s.seasonStats.goals += res.goals;
	s.seasonStats.assists += res.assists;
	s.seasonStats.shots += res.shots;
	s.seasonStats.keyPasses += res.keyPasses;
	s.seasonStats.tackles += res.tackles;
	s.seasonStats.minutes += res.minutes;
	s.seasonStats.ratingSum += res.rating;
	s.seasonStats.avgRating = Math.round(s.seasonStats.ratingSum / s.seasonStats.apps * 10) / 10;
	if (res.yellow) s.seasonStats.yellowCards += 1;
	if (res.red) s.seasonStats.redCards += 1;
	if (res.motm) s.seasonStats.motm += 1;
	s.finances.balance += s.contract.appearanceBonus;
	s.finances.balance += res.goals * s.contract.goalBonus;
	s.finances.balance += res.assists * s.contract.assistBonus;
	s.player.form = clamp(s.player.form + (res.rating - 6.5) * 3, 20, 99);
	s.player.morale = clamp(s.player.morale + (won ? 6 : draw ? 1 : -5) + res.goals * 2, 10, 100);
	s.player.confidence = clamp(s.player.confidence + (res.rating - 6.8) * 2, 10, 100);
	s.player.fatigue = clamp(s.player.fatigue + 12, 0, 100);
	const deltaTrust = res.rating >= 7.5 ? 3 : res.rating >= 6.5 ? 1 : -3;
	s.manager.trust = clamp(s.manager.trust + deltaTrust, 5, 99);
	s.role = computeRole(s.player.overall, TEAM_BY_ID[s.clubId]?.power ?? 70, s.player.form);
	const opp = TEAM_BY_ID[meHome ? res.away : res.home];
	s.news.unshift({
		id: uid("n"),
		week: s.week,
		title: TEAM_BY_ID[res.home]?.name + " " + res.hg + "-" + res.ag + " " + TEAM_BY_ID[res.away]?.name,
		body: s.player.displayName + " " + res.minutes + " dk, reyting " + res.rating.toFixed(1) + (res.goals ? ", " + res.goals + " gol" : "") + (opp ? ". Rakip: " + opp.name : ""),
		kind: "match"
	});
	s.careerHistory.unshift({
		week: s.week,
		season: s.season,
		text: (won ? "Galibiyet" : draw ? "Beraberlik" : "Maglubiyet") + " " + res.hg + "-" + res.ag
	});
	if (!s.achievements.includes("first_match")) s.achievements.push("first_match");
	if (res.goals > 0 && !s.achievements.includes("first_goal")) s.achievements.push("first_goal");
	if (res.motm && !s.achievements.includes("motm")) s.achievements.push("motm");
	if (s.social.setup) {
		s.social.followers += Math.round(40 + res.rating * 12 + res.goals * 80);
		if (s.social.followers >= 1e3 && !s.achievements.includes("1k")) s.achievements.push("1k");
		if (s.social.followers >= 1e4) {
			s.social.verified = true;
			if (!s.achievements.includes("verified")) s.achievements.push("verified");
		}
	}
	s.news = s.news.slice(0, 40);
	s.matchLog = s.matchLog.slice(0, 60);
	return s;
}
function simRestOfLeague(state) {
	const s = structuredClone(state);
	const weekFx = s.fixtures.filter((f) => f.week === s.week);
	for (const f of weekFx) {
		if (f.home === s.clubId || f.away === s.clubId) continue;
		const rngRes = simAutoMatch({
			...s,
			clubId: "___"
		}, f.home, f.away);
		s.table = applyResultToTable(s.table, f.home, f.away, rngRes.hg, rngRes.ag);
	}
	return s;
}
function worldTransfers(state) {
	const n = irand(Math.random, 2, 5);
	const out = [];
	for (let i = 0; i < n; i++) {
		const star = pick(Math.random, STARS);
		const from = pick(Math.random, TEAMS);
		let to = pick(Math.random, TEAMS);
		let guard = 0;
		while (to.id === from.id && guard++ < 8) to = pick(Math.random, TEAMS);
		const fee = Math.random() < .08 ? 0 : Math.round((star.ovr - 70) * 4e6 * (.8 + Math.random()));
		out.push({
			id: uid("wt"),
			week: state.week,
			name: star.name,
			pos: star.pos,
			ovr: star.ovr,
			age: star.age,
			nat: star.nat,
			fromId: from.id,
			toId: to.id,
			fee,
			rumor: Math.random() < .3,
			record: fee >= 15e7
		});
	}
	return out;
}
function maybeInterest(state) {
	const s = structuredClone(state);
	if (Math.random() < .1) {
		const stronger = TEAMS.filter((t) => t.power > (TEAM_BY_ID[s.clubId]?.power ?? 70) && t.id !== s.clubId);
		if (stronger.length) {
			const club = pick(Math.random, stronger);
			s.transferInterest.unshift({
				teamId: club.id,
				week: s.week
			});
			s.news.unshift({
				id: uid("n"),
				week: s.week,
				title: club.name + " seni izliyor",
				body: "Scout raporlari " + s.player.displayName + " icin olumlu.",
				kind: "transfer"
			});
		}
	}
	if (s.player.overall >= 68 && s.player.form >= 55 && Math.random() < .1) {
		const club = pick(Math.random, TEAMS.filter((t) => t.id !== s.clubId));
		s.offers.unshift({
			id: uid("of"),
			teamId: club.id,
			kind: Math.random() < .3 ? "loan" : "transfer",
			fee: Math.round(s.player.overall * 12e4 * (.6 + Math.random())),
			wage: Math.round(wageFor(s.player.overall, club.power) * (1.05 + Math.random() * .3)),
			years: 3,
			managerName: club.name + " menajeri",
			week: s.week,
			status: "open"
		});
		s.news.unshift({
			id: uid("n"),
			week: s.week,
			title: "Menajer DM atti",
			body: club.name + " teklif gonderdi.",
			kind: "transfer"
		});
		if (s.social.threads) s.social.threads.unshift({
			userId: "offer_" + club.id,
			unread: 1,
			messages: [{
				id: uid("m"),
				from: "them",
				text: "Merhaba, " + club.name + " adina yaziyorum. " + (Math.random() < .3 ? "Kiralik" : "Transfer") + " teklifimiz var. Konusalim mi?",
				time: "Az once"
			}]
		});
	}
	s.transferInterest = s.transferInterest.slice(0, 12);
	s.offers = s.offers.slice(0, 10);
	return s;
}
function acceptOffer(state, offerId) {
	const s = structuredClone(state);
	const offer = s.offers.find((o) => o.id === offerId);
	if (!offer) return s;
	offer.status = "accepted";
	const team = TEAM_BY_ID[offer.teamId];
	if (!team) return s;
	s.clubId = team.id;
	s.leagueId = team.leagueId;
	s.teammates = generateSquad(team.id);
	s.contract.weeklyWage = offer.wage;
	s.contract.years = offer.years;
	s.contract.signedWeek = s.week;
	s.finances.weeklyWage = offer.wage;
	s.role = computeRole(s.player.overall, team.power, s.player.form);
	s.table = teamsInLeague(team.leagueId).map((t) => t.id).map((teamId) => ({
		teamId,
		played: 0,
		won: 0,
		drawn: 0,
		lost: 0,
		gf: 0,
		ga: 0,
		pts: 0
	}));
	s.careerHistory.unshift({
		week: s.week,
		season: s.season,
		text: team.name + " transferi tamam."
	});
	s.news.unshift({
		id: uid("n"),
		week: s.week,
		title: "Imza atildi",
		body: s.player.displayName + " " + team.name + " formasini giyiyor.",
		kind: "transfer"
	});
	return s;
}
function declineOffer(state, offerId) {
	const s = structuredClone(state);
	s.offers = s.offers.map((o) => o.id === offerId ? {
		...o,
		status: "declined"
	} : o);
	return s;
}
function endSeasonIfNeeded(state) {
	const maxWeek = state.fixtures.reduce((m, f) => Math.max(m, f.week), 1);
	if (state.week < maxWeek) return state;
	const s = structuredClone(state);
	const sorted = [...s.table].sort((a, b) => b.pts - a.pts || b.gf - b.ga - (a.gf - a.ga));
	const me = sorted.findIndex((r) => r.teamId === s.clubId);
	const champ = TEAM_BY_ID[sorted[0]?.teamId || ""];
	if (me === 0 && champ) s.trophies.push({
		id: uid("tr"),
		name: (TEAM_BY_ID[s.clubId] ? s.leagueId : "Lig") + " sampiyonlugu",
		season: s.season,
		team: TEAM_BY_ID[s.clubId]?.name || ""
	});
	s.seasonIndex += 1;
	const start = 2026 + s.seasonIndex;
	s.season = start + "/" + String(start + 1).slice(2);
	s.week = 1;
	s.date = start + "-08-15";
	s.seasonStats = {
		apps: 0,
		starts: 0,
		goals: 0,
		assists: 0,
		shots: 0,
		keyPasses: 0,
		tackles: 0,
		minutes: 0,
		yellowCards: 0,
		redCards: 0,
		motm: 0,
		ratingSum: 0,
		avgRating: 0
	};
	s.table = teamsInLeague(s.leagueId).map((t) => t.id).map((teamId) => ({
		teamId,
		played: 0,
		won: 0,
		drawn: 0,
		lost: 0,
		gf: 0,
		ga: 0,
		pts: 0
	}));
	s.news.unshift({
		id: uid("n"),
		week: 1,
		title: "Yeni sezon",
		body: s.season + " basliyor. Gecen sene lig sirasi: " + (me + 1) + ".",
		kind: "club"
	});
	return s;
}
function wrapWeek(state) {
	let s = simRestOfLeague(state);
	s.worldTransfers = [...worldTransfers(s), ...s.worldTransfers].slice(0, 40);
	s = maybeInterest(s);
	s = weeklyLife(s);
	s.social = weeklySocial(s);
	s.finances.balance += s.finances.weeklyWage;
	if (s.week % 4 === 0) {
		s.finances.balance += s.finances.monthlyIncome;
		s.finances.balance -= s.finances.monthlyExpenses;
	}
	s.week += 1;
	s.date = addDays(s.date, 7);
	s.role = computeRole(s.player.overall, TEAM_BY_ID[s.clubId]?.power ?? 70, s.player.form);
	s = endSeasonIfNeeded(s);
	s.notifications = ["Hafta " + s.week + " · " + s.date, ...s.notifications].slice(0, 12);
	return s;
}
function preparePlay(state) {
	let s = applyTraining(state);
	if (s.injury) {
		s.injury.weeksLeft -= 1;
		if (s.injury.weeksLeft <= 0) s.injury = null;
	}
	return s;
}
function advanceWeek(state) {
	let s = preparePlay(state);
	const fx = currentFixture(s);
	let result;
	if (fx && !s.injury) {
		result = simAutoMatch(s, fx.home, fx.away, !!fx.cup);
		s = applyMatchResult(s, result);
	}
	s = wrapWeek(s);
	return {
		state: s,
		result
	};
}
function lowMidClubs() {
	const pool = TEAMS.filter((t) => t.power >= 52 && t.power <= 78);
	const out = [];
	const used = /* @__PURE__ */ new Set();
	let n = 0;
	while (out.length < 3 && n < 40) {
		n++;
		const t = pick(Math.random, pool);
		if (!used.has(t.id)) {
			used.add(t.id);
			out.push(t.id);
		}
	}
	return out;
}
var toastN = 1;
var useGame = create((set, get) => ({
	hydrated: false,
	screen: "menu",
	view: "panel",
	drawer: false,
	sound: true,
	draft: defaultDraft(),
	createStep: 1,
	offers: [],
	career: null,
	toast: null,
	savedFlash: false,
	pendingMatch: null,
	hydrate: () => {
		unlockSound();
		set({
			hydrated: true,
			sound: isSoundEnabled(),
			offers: lowMidClubs()
		});
	},
	setScreen: (screen) => set({
		screen,
		drawer: false
	}),
	setView: (view) => set({
		view,
		drawer: false
	}),
	setDrawer: (drawer) => set({ drawer }),
	toggleSound: () => {
		const next = !get().sound;
		setSoundEnabled(next);
		set({ sound: next });
	},
	setDraft: (p) => {
		const draft = {
			...get().draft,
			...p
		};
		if (p.pos) {
			const ok = ARCHETYPES.filter((a) => a.pos.includes(p.pos));
			if (ok.length && !ok.some((a) => a.id === draft.archetype)) draft.archetype = ok[0].id;
		}
		set({ draft });
	},
	setStep: (createStep) => set({ createStep }),
	shuffleClubs: () => set({ offers: lowMidClubs() }),
	startFromClub: (clubId, slot) => {
		const career = startCareer(buildPlayer(get().draft), clubId, slot);
		saveSlot(career);
		set({
			career,
			screen: "career",
			view: "panel",
			createStep: 1
		});
	},
	load: (slot) => {
		const career = loadSlot(slot);
		if (!career) return;
		set({
			career,
			screen: "career",
			view: "panel"
		});
	},
	save: () => {
		const c = get().career;
		if (!c) return;
		saveSlot(c);
		set({ savedFlash: true });
		setTimeout(() => set({ savedFlash: false }), 1400);
	},
	quit: () => {
		const c = get().career;
		if (c) saveSlot(c);
		set({
			career: null,
			screen: "menu",
			view: "panel",
			drawer: false
		});
	},
	setTraining: (focus, intensity) => {
		const c = get().career;
		if (!c) return;
		set({ career: {
			...c,
			training: {
				focus,
				intensity
			}
		} });
	},
	weekAdvance: (autoMatch) => {
		const c = get().career;
		if (!c) return;
		const fx = currentFixture(c);
		if (!autoMatch && fx && !c.injury) {
			set({
				career: preparePlay(c),
				pendingMatch: {
					home: fx.home,
					away: fx.away
				},
				screen: "match"
			});
			return;
		}
		const out = advanceWeek(c);
		saveSlot(out.state);
		const res = out.result;
		const gd = res ? res.home === out.state.clubId ? res.hg - res.ag : res.ag - res.hg : 0;
		set({
			career: out.state,
			toast: res ? {
				id: toastN++,
				text: TEAM_BY_ID[res.home]?.name + " " + res.hg + "-" + res.ag + " " + TEAM_BY_ID[res.away]?.name,
				kind: gd > 0 ? "ok" : gd < 0 ? "bad" : "ok"
			} : {
				id: toastN++,
				text: "Hafta ilerledi",
				kind: "ok"
			}
		});
	},
	finishPlayedMatch: (res) => {
		const c = get().career;
		if (!c) return;
		const s = wrapWeek(applyMatchResult(c, res));
		saveSlot(s);
		set({
			career: s,
			screen: "career",
			view: "panel",
			pendingMatch: null
		});
	},
	setCareer: (career) => {
		set({ career });
		saveSlot(career);
	},
	takeOffer: (id, yes) => {
		const c = get().career;
		if (!c) return;
		const next = yes ? acceptOffer(c, id) : declineOffer(c, id);
		saveSlot(next);
		set({ career: next });
	},
	flash: (text, kind) => set({ toast: {
		id: toastN++,
		text,
		kind
	} })
}));
function suggestedSlot() {
	const empty = listSlots().find((s) => !s.occupied);
	return empty ? empty.slot : 0;
}
var HUES = [
	150,
	210,
	12,
	280,
	32,
	190
];
function Avatar({ hue, size = 40, letter }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid place-items-center rounded-full font-display text-white",
		style: {
			width: size,
			height: size,
			background: "linear-gradient(135deg, hsl(" + hue + " 45% 38%), hsl(" + (hue + 40) % 360 + " 50% 22%))",
			fontSize: size * .38
		},
		children: letter.slice(0, 1).toUpperCase()
	});
}
function sceneBg(scene) {
	const map = {
		goal: "linear-gradient(160deg,#14301f,#0b0c0b 70%)",
		train: "linear-gradient(160deg,#1c2418,#0b0c0b 70%)",
		matchday: "linear-gradient(160deg,#1a2030,#0b0c0b 70%)",
		team: "linear-gradient(160deg,#241818,#0b0c0b 70%)",
		life: "linear-gradient(160deg,#201c18,#0b0c0b 70%)",
		deal: "linear-gradient(160deg,#1c1c20,#0b0c0b 70%)",
		cup: "linear-gradient(160deg,#2a2414,#0b0c0b 70%)",
		sign: "linear-gradient(160deg,#182018,#0b0c0b 70%)",
		press: "linear-gradient(160deg,#1a1a22,#0b0c0b 70%)"
	};
	return map[scene] || map.life;
}
function Footballgram({ onBack }) {
	const { career, setCareer } = useGame();
	const [tab, setTab] = (0, import_react.useState)("home");
	const [threadId, setThreadId] = (0, import_react.useState)(null);
	const [storyI, setStoryI] = (0, import_react.useState)(null);
	const [burst, setBurst] = (0, import_react.useState)(null);
	const [analytics, setAnalytics] = (0, import_react.useState)(null);
	if (!career) return null;
	const social = career.social;
	const users = (0, import_react.useMemo)(() => Object.fromEntries(social.users.map((u) => [u.id, u])), [social.users]);
	if (!social.setup) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Setup, { onBack });
	function patch(next) {
		setCareer({
			...career,
			social: next
		});
	}
	function like(id) {
		Sound.pop();
		patch({
			...social,
			posts: social.posts.map((p) => p.id === id ? {
				...p,
				liked: !p.liked,
				likes: p.likes + (p.liked ? -1 : 1)
			} : p)
		});
	}
	const me = users.me;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex min-h-dvh max-w-lg flex-col bg-black text-white",
		children: [
			tab !== "thread" && storyI == null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center justify-between px-4 py-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onBack,
						className: "text-[13px] text-white/60",
						children: "Kariyer"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "gram-wordmark text-[28px] leading-none",
						children: "Footballgram"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "relative grid size-10 place-items-center",
							onClick: () => {
								Sound.tap();
								setTab("activity");
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { size: 18 }), social.activity.some((a) => a.unread) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute right-1.5 top-1.5 size-2 rounded-full bg-[#e14b6a]" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "relative grid size-10 place-items-center",
							onClick: () => {
								Sound.dm();
								setTab("dm");
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { size: 18 }), social.threads.some((t) => t.unread) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute right-1.5 top-1.5 size-2 rounded-full bg-[#e14b6a]" })]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-h-0 flex-1 overflow-y-auto pb-16",
				children: [
					tab === "home" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "no-scrollbar flex gap-3 overflow-x-auto px-3 pb-3",
						children: social.stories.map((st, i) => {
							const u = users[st.userId];
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "w-16 shrink-0 text-center",
								onClick: () => {
									Sound.tap();
									setStoryI(i);
									if (!career.achievements.includes("story")) setCareer({
										...career,
										achievements: [...career.achievements, "story"]
									});
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mx-auto grid size-16 place-items-center rounded-full p-[2px] " + (st.seen ? "bg-white/20" : "story-ring"),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid size-full place-items-center rounded-full bg-black",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
											hue: u?.hue || 150,
											letter: u?.displayName || "?",
											size: 52
										})
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-1 truncate text-[11px] text-white/70",
									children: st.userId === "me" ? "Hikayen" : u?.username
								})]
							}, st.id);
						})
					}), social.posts.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PostCard, {
						post: p,
						user: users[p.userId],
						onLike: () => like(p.id),
						onDouble: () => {
							setBurst(p.id);
							if (!p.liked) like(p.id);
							setTimeout(() => setBurst(null), 500);
						},
						burst: burst === p.id,
						onSave: () => patch({
							...social,
							savedIds: social.savedIds.includes(p.id) ? social.savedIds.filter((x) => x !== p.id) : [...social.savedIds, p.id],
							posts: social.posts.map((x) => x.id === p.id ? {
								...x,
								saved: !x.saved
							} : x)
						}),
						onComment: (text) => {
							patch({
								...social,
								posts: social.posts.map((x) => x.id === p.id ? {
									...x,
									comments: [...x.comments, {
										userId: "me",
										text
									}]
								} : x)
							});
						},
						onAnalytics: p.userId === "me" ? () => setAnalytics(p.id) : void 0
					}, p.id))] }),
					tab === "search" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchTab, {
						social,
						users
					}),
					tab === "compose" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Compose, { onShare: (scene, caption, tags, ments) => {
						Sound.follow();
						const next = composePost(career, scene, caption, tags, ments);
						const ach = career.achievements.includes("first_post") ? career.achievements : [...career.achievements, "first_post"];
						setCareer({
							...career,
							social: next,
							achievements: ach
						});
						setTab("home");
					} }),
					tab === "activity" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "px-4 py-2",
						children: [social.activity.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-white/50",
							children: "Sessizlik. Paylasim yap."
						}), social.activity.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3 border-b border-white/10 py-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
									hue: users[a.userId]?.hue || 0,
									letter: users[a.userId]?.username || "?"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex-1 text-[14px]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-medium",
											children: users[a.userId]?.username
										}),
										" ",
										a.text
									]
								}),
								a.unread && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-[#e14b6a]" })
							]
						}, a.id))]
					}),
					tab === "profile" && me && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfileTab, {
						me,
						social,
						onEdit: (u, d, b) => {
							patch({
								...social,
								username: u,
								displayName: d,
								bio: b,
								users: social.users.map((x) => x.id === "me" ? {
									...x,
									username: u,
									displayName: d,
									bio: b
								} : x)
							});
						}
					}),
					tab === "dm" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: social.threads.map((th) => {
						const u = users[th.userId] || {
							username: th.userId.replace("offer_", ""),
							displayName: th.userId,
							hue: 200
						};
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "flex w-full items-center gap-3 px-4 py-3 text-left",
							onClick: () => {
								Sound.tap();
								setThreadId(th.userId);
								setTab("thread");
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
									hue: u.hue || 200,
									letter: u.displayName
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-medium",
										children: u.displayName
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "truncate text-[13px] text-white/50",
										children: th.messages[th.messages.length - 1]?.text
									})]
								}),
								th.unread > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid size-5 place-items-center rounded-full bg-[#e14b6a] text-[11px]",
									children: th.unread
								})
							]
						}, th.userId);
					}) }),
					tab === "thread" && threadId && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Thread, {
						social,
						threadId,
						users,
						onBack: () => setTab("dm"),
						onSend: (text) => {
							const ach = career.achievements.includes("first_dm") ? career.achievements : [...career.achievements, "first_dm"];
							const threads = social.threads.map((th) => th.userId === threadId ? {
								...th,
								unread: 0,
								messages: [...th.messages, {
									id: Math.random().toString(36).slice(2),
									from: "me",
									text,
									time: "Az once"
								}]
							} : th);
							setCareer({
								...career,
								social: {
									...social,
									threads
								},
								achievements: ach
							});
							const u = users[threadId];
							const reply = dmReply(text, u?.role);
							const delay = 900 + Math.random() * 1400;
							setTimeout(() => {
								const cur = useGame.getState().career;
								if (!cur) return;
								Sound.dm();
								const ths = cur.social.threads.map((th) => th.userId === threadId ? {
									...th,
									messages: [...th.messages, {
										id: Math.random().toString(36).slice(2),
										from: "them",
										text: reply,
										time: "Az once"
									}]
								} : th);
								setCareer({
									...cur,
									social: {
										...cur.social,
										threads: ths
									}
								});
							}, delay);
						}
					})
				]
			}),
			tab !== "thread" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-20 mx-auto flex max-w-lg justify-around border-t border-white/10 bg-black/95 py-2",
				children: [
					["home", House],
					["search", Search],
					["compose", SquarePlus],
					["activity", Heart],
					["profile", User]
				].map(([id, Ic]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "grid size-11 place-items-center",
					onClick: () => {
						Sound.tap();
						setTab(id);
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ic, {
						size: 22,
						className: tab === id ? "text-white" : "text-white/45"
					})
				}, id))
			}),
			storyI != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StoryViewer, {
				stories: social.stories,
				index: storyI,
				users,
				onClose: () => setStoryI(null),
				onIndex: setStoryI
			}),
			analytics && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-40 bg-black/80 p-5",
				onClick: () => setAnalytics(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto mt-16 max-w-sm rounded-3xl bg-[#161616] p-5",
					onClick: (e) => e.stopPropagation(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 flex items-center gap-2 font-medium",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartColumn, { size: 16 }), " Analitik"]
					}), [
						"Gosterim",
						"Erisilen",
						"Begeni",
						"Yorum",
						"Profil ziyareti",
						"Yeni takipci"
					].map((k, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between py-1.5 text-[14px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-white/50",
							children: k
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: fmtNum(400 + i * 180) })]
					}, k))]
				})
			})
		]
	});
}
function PostCard({ post, user, onLike, onDouble, burst, onSave, onComment, onAnalytics }) {
	const [c, setC] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "border-b border-white/10 pb-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 px-3 py-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
					hue: user?.hue || 0,
					letter: user?.displayName || "?",
					size: 32
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1 text-[14px] font-medium",
						children: [user?.username, user?.verified && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
							size: 12,
							className: "text-sky-400"
						})]
					}), post.location && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[11px] text-white/45",
						children: post.location
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "relative block h-72 w-full",
				style: { background: sceneBg(post.scene) },
				onDoubleClick: onDouble,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute inset-0 grid place-items-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-display text-5xl uppercase tracking-wide text-white/90",
							children: post.scene
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 text-[13px] text-white/55",
							children: "cift dokun, begen"
						})]
					})
				}), burst && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "heart-burst pointer-events-none absolute inset-0 grid place-items-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, {
						size: 72,
						fill: "white"
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-1 px-2 pt-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-10 place-items-center",
						onClick: onLike,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, {
							size: 22,
							fill: post.liked ? "#e14b6a" : "none",
							className: post.liked ? "text-[#e14b6a]" : ""
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-10 place-items-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { size: 22 })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-10 place-items-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { size: 20 })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "flex-1" }),
					onAnalytics && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-10 place-items-center",
						onClick: onAnalytics,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartColumn, { size: 18 })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-10 place-items-center",
						onClick: onSave,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, {
							size: 20,
							fill: post.saved ? "white" : "none"
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-4 text-[14px] font-medium",
				children: [fmtNum(post.likes), " begeni"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-4 pt-1 text-[14px]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-medium",
						children: [user?.username, " "]
					}),
					post.caption,
					post.hashtags.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-sky-400",
						children: [" #", h]
					}, h))
				]
			}),
			post.comments.slice(0, 2).map((cmt, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-4 text-[13px] text-white/70",
				children: cmt.text
			}, i)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-4 pt-1 text-[11px] uppercase tracking-wide text-white/35",
				children: post.time
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("form", {
				className: "mt-1 flex gap-2 px-4",
				onSubmit: (e) => {
					e.preventDefault();
					if (!c.trim()) return;
					onComment(c.trim());
					setC("");
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: c,
					onChange: (e) => setC(e.target.value),
					placeholder: "Yorum ekle...",
					className: "h-9 flex-1 bg-transparent text-[14px] outline-none placeholder:text-white/30"
				})
			})
		]
	});
}
function SearchTab({ social, users }) {
	const [q, setQ] = (0, import_react.useState)("");
	const tags = [
		"matchday",
		"goal",
		"ucl",
		"transfer",
		"training"
	];
	const grid = [...social.posts].sort((a, b) => b.likes - a.likes).slice(0, 9);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-3 py-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: q,
				onChange: (e) => setQ(e.target.value),
				placeholder: "Ara",
				className: "h-10 w-full rounded-xl bg-white/10 px-3 text-[14px] outline-none"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 flex flex-wrap gap-2",
				children: tags.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "rounded-full bg-white/10 px-3 py-1 text-[12px]",
					children: ["#", t]
				}, t))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 grid grid-cols-3 gap-1",
				children: grid.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "aspect-square",
					style: { background: sceneBg(p.scene) }
				}, p.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 text-[12px] uppercase tracking-[0.14em] text-white/40",
				children: "Onerilen"
			}),
			social.users.filter((u) => u.id !== "me").slice(0, 6).map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3 py-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
						hue: u.hue,
						letter: u.displayName
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[14px]",
							children: u.username
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-[12px] text-white/45",
							children: [fmtNum(u.followers), " takipci"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[12px] text-sky-400",
						children: "Takip et"
					})
				]
			}, u.id)),
			q && Object.values(users).filter((u) => u && u.username.includes(q.toLowerCase())).length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-white/40",
				children: "Sonuc yok."
			})
		]
	});
}
function Compose({ onShare }) {
	const career = useGame((s) => s.career);
	const [scene, setScene] = (0, import_react.useState)("matchday");
	const [caption, setCaption] = (0, import_react.useState)("");
	const [tags, setTags] = (0, import_react.useState)([]);
	const reach = estimateReach(career.social.followers, scene);
	const templates = captionsFor(scene, career.lastResult);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-4 py-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-3 font-medium",
				children: "Olustur"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-3 gap-2",
				children: SCENES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setScene(s.id),
					className: "rounded-xl py-3 text-[12px] " + (scene === s.id ? "bg-white text-black" : "bg-white/10"),
					children: s.tr
				}, s.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 h-36 rounded-2xl",
				style: { background: sceneBg(scene) }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 flex flex-wrap gap-2",
				children: templates.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "rounded-full bg-white/10 px-3 py-1 text-[12px]",
					onClick: () => setCaption(t),
					children: "Sablon"
				}, t))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				value: caption,
				onChange: (e) => setCaption(e.target.value),
				rows: 3,
				className: "mt-3 w-full rounded-xl bg-white/10 p-3 text-[14px] outline-none",
				placeholder: "Caption"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 flex flex-wrap gap-2",
				children: [
					"goal",
					"matchday",
					"training",
					"team",
					"career",
					"weekend"
				].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setTags((x) => x.includes(t) ? x.filter((i) => i !== t) : x.length < 5 ? [...x, t] : x),
					className: "rounded-full px-3 py-1 text-[12px] " + (tags.includes(t) ? "bg-white text-black" : "bg-white/10"),
					children: ["#", t]
				}, t))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 text-[13px] text-white/50",
				children: [
					"Tahmini erisim: ",
					reachLabel(reach, career.social.followers),
					" · ",
					TEAM_BY_ID[career.clubId]?.name
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				tone: "primary",
				className: "mt-4 w-full",
				onClick: () => onShare(scene, caption || templates[0], tags, []),
				children: "Paylas"
			})
		]
	});
}
function ProfileTab({ me, social, onEdit }) {
	const [edit, setEdit] = (0, import_react.useState)(false);
	const [u, setU] = (0, import_react.useState)(me.username);
	const [d, setD] = (0, import_react.useState)(me.displayName);
	const [b, setB] = (0, import_react.useState)(me.bio);
	const mine = social.posts.filter((p) => p.userId === "me");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-4 py-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
					hue: social.hue,
					letter: me.displayName,
					size: 96
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-1 justify-around text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-display text-2xl",
							children: mine.length
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] text-white/50",
							children: "Gonderi"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-display text-2xl",
							children: fmtNum(social.followers)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] text-white/50",
							children: "Takipci"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-display text-2xl",
							children: social.followingCount
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] text-white/50",
							children: "Takip"
						})] })
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 font-medium",
				children: [
					me.displayName,
					" ",
					social.verified && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
						size: 14,
						className: "inline text-sky-400"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-[13px] text-white/55",
				children: ["@", me.username]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-[14px]",
				children: me.bio
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					onClick: () => setEdit(true),
					children: "Profili duzenle"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, { children: "Olustur" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 grid grid-cols-3 gap-1",
				children: mine.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "aspect-square",
					style: { background: sceneBg(p.scene) }
				}, p.id))
			}),
			edit && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-40 grid place-items-center bg-black/70 p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-sm rounded-3xl bg-[#161616] p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: u,
							onChange: (e) => setU(e.target.value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: d,
								onChange: (e) => setD(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: b,
								onChange: (e) => setB(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 grid grid-cols-2 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
								onClick: () => setEdit(false),
								children: "Vazgec"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
								tone: "primary",
								onClick: () => {
									onEdit(slug(u), d, b.slice(0, 80));
									setEdit(false);
								},
								children: "Kaydet"
							})]
						})
					]
				})
			})
		]
	});
}
function Thread({ social, threadId, users, onBack, onSend }) {
	const [t, setT] = (0, import_react.useState)("");
	const th = social.threads.find((x) => x.userId === threadId);
	const u = users[threadId];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-[70vh] flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 px-2 py-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-10 place-items-center",
						onClick: onBack,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
						hue: u?.hue || 200,
						letter: u?.displayName || "?",
						size: 32
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[14px] font-medium",
						children: u?.displayName || "Sohbet"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[11px] text-white/45",
						children: "Cevrimici"
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex-1 space-y-2 overflow-y-auto px-3 py-2",
				children: th?.messages.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "max-w-[80%] rounded-2xl px-3 py-2 text-[14px] " + (m.from === "me" ? "ml-auto bg-[#1b4f9c]" : "bg-white/10"),
					children: m.text
				}, m.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-1 px-3",
				children: [
					"Selam",
					"Antrenmanda gorusuruz",
					"Tesekkurler",
					"Mac gunu hazirim"
				].map((q) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "rounded-full bg-white/10 px-3 py-1 text-[12px]",
					onClick: () => onSend(q),
					children: q
				}, q))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("form", {
				className: "flex gap-2 p-3",
				onSubmit: (e) => {
					e.preventDefault();
					if (!t.trim()) return;
					onSend(t.trim());
					setT("");
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: t,
					onChange: (e) => setT(e.target.value),
					className: "h-11 flex-1 rounded-full bg-white/10 px-4 text-[14px] outline-none",
					placeholder: "Mesaj"
				})
			})
		]
	});
}
function StoryViewer({ stories, index, users, onClose, onIndex }) {
	const st = stories[index];
	(0, import_react.useEffect)(() => {
		const t = setTimeout(() => {
			if (index < stories.length - 1) onIndex(index + 1);
			else onClose();
		}, 5e3);
		return () => clearTimeout(t);
	}, [
		index,
		onClose,
		onIndex,
		stories.length
	]);
	if (!st) return null;
	const u = users[st.userId];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-50 bg-black",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-1 px-3 pt-3",
				children: stories.map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-0.5 flex-1 overflow-hidden rounded bg-white/25",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-full bg-white",
						style: {
							width: i < index ? "100%" : i === index ? "100%" : "0%",
							animation: i === index ? "storybar 5s linear" : void 0
						}
					})
				}, i))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("style", { children: `@keyframes storybar { from { width: 0% } to { width: 100% } }` }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 px-4 py-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
						hue: u?.hue || 0,
						letter: u?.displayName || "?",
						size: 28
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1 text-[13px]",
						children: [u?.username, " · 5sn"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onClose,
						children: "Kapat"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-4 mt-6 h-[70vh] overflow-hidden rounded-3xl",
				style: { background: sceneBg(st.scene) },
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "absolute inset-y-0 left-0 w-1/3",
						onClick: () => index > 0 ? onIndex(index - 1) : onClose()
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "absolute inset-y-0 right-0 w-2/3",
						onClick: () => index < stories.length - 1 ? onIndex(index + 1) : onClose()
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex h-full flex-col items-center justify-center p-6 text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-display text-6xl uppercase",
							children: st.scene
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 text-lg",
							children: st.text
						})]
					})
				]
			})
		]
	});
}
function Setup({ onBack }) {
	const { career, setCareer } = useGame();
	const [step, setStep] = (0, import_react.useState)(1);
	const [u, setU] = (0, import_react.useState)(career?.social.username || "player");
	const [d, setD] = (0, import_react.useState)(career?.player.displayName || "");
	const [b, setB] = (0, import_react.useState)("Saha ve hayat.");
	const [hue, setHue] = (0, import_react.useState)(150);
	if (!career) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex min-h-dvh max-w-lg flex-col bg-black px-5 py-6 text-white",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "text-[13px] text-white/50",
				onClick: onBack,
				children: "Geri"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "gram-wordmark mt-6 text-4xl",
				children: "Footballgram"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-white/50",
				children: [
					"Adim ",
					step,
					"/5"
				]
			}),
			step === 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-8 block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-[12px] uppercase tracking-[0.14em] text-white/40",
					children: "Kullanici adi"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: u,
					onChange: (e) => setU(e.target.value.toLowerCase()),
					className: "mt-2 h-12 w-full border-b border-white/20 bg-transparent text-lg outline-none"
				})]
			}),
			step === 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-8 block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-[12px] uppercase tracking-[0.14em] text-white/40",
					children: "Gorunen ad"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: d,
					onChange: (e) => setD(e.target.value),
					className: "mt-2 h-12 w-full border-b border-white/20 bg-transparent text-lg outline-none"
				})]
			}),
			step === 3 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-8 block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-[12px] uppercase tracking-[0.14em] text-white/40",
					children: "Biyografi"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: b,
					maxLength: 80,
					onChange: (e) => setB(e.target.value),
					className: "mt-2 h-12 w-full border-b border-white/20 bg-transparent text-lg outline-none"
				})]
			}),
			step === 4 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[12px] uppercase tracking-[0.14em] text-white/40",
					children: "Avatar rengi"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 flex gap-3",
					children: HUES.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setHue(h),
						className: "rounded-full " + (hue === h ? "ring-2 ring-white" : ""),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
							hue: h,
							letter: d,
							size: 48
						})
					}, h))
				})]
			}),
			step === 5 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
						hue,
						letter: d,
						size: 96
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 font-display text-3xl",
						children: d
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-white/50",
						children: ["@", slug(u)]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-white/60",
						children: b
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				tone: "primary",
				className: "mt-auto",
				onClick: () => {
					Sound.click();
					if (step < 5) setStep(step + 1);
					else {
						const username = slug(u);
						setCareer({
							...career,
							social: {
								...career.social,
								setup: true,
								username,
								displayName: d,
								bio: b,
								hue,
								users: career.social.users.map((x) => x.id === "me" ? {
									...x,
									username,
									displayName: d,
									bio: b,
									hue
								} : x)
							}
						});
					}
				},
				children: step < 5 ? "Devam" : "Hesabi ac"
			})
		]
	});
}
var NAV = [
	{
		cat: "Oyuncu",
		items: [
			{
				id: "panel",
				label: "Panel",
				icon: House
			},
			{
				id: "profile",
				label: "Oyuncu profili",
				icon: User
			},
			{
				id: "attributes",
				label: "Ozellikler",
				icon: Shirt
			},
			{
				id: "stats",
				label: "Istatistikler",
				icon: Newspaper
			}
		]
	},
	{
		cat: "Saha",
		items: [
			{
				id: "training",
				label: "Antrenman",
				icon: Dumbbell
			},
			{
				id: "matches",
				label: "Maclar",
				icon: Flag
			},
			{
				id: "calendar",
				label: "Takvim",
				icon: CalendarDays
			},
			{
				id: "club",
				label: "Kulup",
				icon: Landmark
			},
			{
				id: "manager",
				label: "Menajer",
				icon: Briefcase
			},
			{
				id: "teammates",
				label: "Takim arkadaslari",
				icon: Users
			}
		]
	},
	{
		cat: "Kariyer",
		items: [
			{
				id: "transfers",
				label: "Transferler",
				icon: Newspaper
			},
			{
				id: "agent",
				label: "Menajer ajani",
				icon: Briefcase
			},
			{
				id: "contract",
				label: "Sozlesme",
				icon: Shirt
			},
			{
				id: "finance",
				label: "Finans",
				icon: Banknote
			},
			{
				id: "national",
				label: "Milli takim",
				icon: Flag
			},
			{
				id: "trophies",
				label: "Kupalar",
				icon: Trophy
			},
			{
				id: "history",
				label: "Kariyer gecmisi",
				icon: History
			}
		]
	},
	{
		cat: "Yasam",
		items: [{
			id: "life",
			label: "Yasam",
			icon: Heart
		}, {
			id: "social",
			label: "Sosyal medya",
			icon: Newspaper
		}]
	}
];
function Career() {
	const { career, view, drawer, setDrawer, setView, setScreen, save, savedFlash, quit, weekAdvance } = useGame();
	const [quitOpen, setQuitOpen] = (0, import_react.useState)(false);
	if (!career) return null;
	if (view === "social") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footballgram, { onBack: () => setView("panel") });
	const club = TEAM_BY_ID[career.clubId];
	const title = NAV.flatMap((n) => n.items).find((i) => i.id === view)?.label || "Panel";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-30 flex items-center gap-3 border-b border-line bg-bg/95 px-3 py-2.5 backdrop-blur",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Menu",
						className: "grid size-11 place-items-center rounded-[12px] bg-bg-soft",
						onClick: () => {
							Sound.tap();
							setDrawer(true);
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { size: 18 })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-display text-xl leading-none",
							children: title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "truncate text-[12px] text-muted",
							children: [
								club?.name,
								" · Hafta ",
								career.week,
								" · ",
								trDate(career.date)
							]
						})]
					}),
					club && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClubLogo, {
						team: club,
						size: 28
					})
				]
			}),
			drawer && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-40 flex",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "flex h-full w-[86%] max-w-sm flex-col bg-bg-elev slide-in",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between px-4 py-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-display text-2xl",
								children: "Futbol Kariyeri"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "grid size-10 place-items-center",
								onClick: () => setDrawer(false),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 18 })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "min-h-0 flex-1 overflow-y-auto px-2 pb-4",
							children: NAV.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "px-3 pb-1 text-[11px] uppercase tracking-[0.18em] text-subtle",
									children: g.cat
								}), g.items.map((it) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => {
										Sound.tap();
										setView(it.id);
									},
									className: "flex w-full items-center gap-3 rounded-[12px] px-3 py-2.5 text-left " + (view === it.id ? "bg-bg-hover" : ""),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(it.icon, {
										size: 16,
										className: "text-muted"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: it.label })]
								}, it.id))]
							}, g.cat))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-3 gap-2 border-t border-line p-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
									className: "px-2 text-[13px]",
									onClick: () => {
										Sound.success();
										save();
									},
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { size: 14 }),
										" ",
										savedFlash ? "Kaydedildi" : "Kaydet"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
									className: "px-2 text-[13px]",
									onClick: () => {
										Sound.tap();
										setDrawer(false);
										setScreen("settings");
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings2, { size: 14 }), " Ayarlar"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
									tone: "danger",
									className: "px-2 text-[13px]",
									onClick: () => {
										Sound.tap();
										setQuitOpen(true);
									},
									children: "Cik"
								})
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "flex-1 bg-black/50",
					"aria-label": "Kapat",
					onClick: () => setDrawer(false)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-lg px-4 py-4",
				children: [
					view === "panel" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dash, {
						career,
						onAdvance: weekAdvance
					}),
					view === "profile" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Profile, { career }),
					view === "attributes" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Attrs, { career }),
					view === "stats" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stats, { career }),
					view === "training" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Training, { career }),
					view === "matches" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Matches, { career }),
					view === "calendar" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { career }),
					view === "club" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Club, { career }),
					view === "manager" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ManagerV, { career }),
					view === "teammates" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Teammates, { career }),
					view === "transfers" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Transfers, { career }),
					view === "agent" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AgentV, { career }),
					view === "contract" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContractV, { career }),
					view === "finance" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FinanceV, { career }),
					view === "national" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(National, { career }),
					view === "trophies" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trophies, { career }),
					view === "history" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistoryV, { career }),
					view === "life" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LifeV, { career })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
				open: quitOpen,
				title: "Kariyerden cik",
				onClose: () => setQuitOpen(false),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[15px] text-muted",
					children: "Kayit guncellenecek ve ana menuye doneceksin."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						onClick: () => setQuitOpen(false),
						children: "Vazgec"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						tone: "danger",
						onClick: () => {
							Sound.click();
							quit();
						},
						children: "Cik"
					})]
				})]
			})
		]
	});
}
function Dash({ career, onAdvance }) {
	const club = TEAM_BY_ID[career.clubId];
	const league = LEAGUES.find((l) => l.id === career.leagueId);
	const fx = currentFixture(career);
	const pos = [...career.table].sort((a, b) => b.pts - a.pts || b.gf - a.gf).findIndex((r) => r.teamId === career.clubId) + 1;
	const opp = fx ? TEAM_BY_ID[fx.home === career.clubId ? fx.away : fx.home] : null;
	const home = fx?.home === career.clubId;
	const roleLabel = career.role === "starter" ? "Ilk 11" : career.role === "rotation" ? "Rotasyon" : "Yedek";
	const news = career.news.slice(0, 5);
	const transfers = career.worldTransfers.slice(0, 3);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 fade-up",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerCard, {
				player: career.player,
				date: career.date
			}),
			career.injury && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-[16px] bg-danger/15 px-4 py-3 text-[14px] text-danger",
				children: [
					"Sakatlik: ",
					career.injury.name,
					" · ",
					career.injury.weeksLeft,
					" hafta"
				]
			}),
			club && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClubLogo, {
					team: club,
					size: 42
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-display text-2xl leading-none",
						children: club.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-[13px] text-muted",
						children: [
							league?.name,
							" · ",
							pos,
							". sira"
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniStat, {
						label: "Form",
						v: career.player.form
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniStat, {
						label: "Moral",
						v: career.player.morale
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniStat, {
						label: "Performans",
						v: career.seasonStats.avgRating * 10,
						sub: career.seasonStats.avgRating.toFixed(1)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniStat, {
						label: "Yorgunluk",
						v: career.player.fatigue
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-[12px] uppercase tracking-[0.16em] text-muted",
				children: "Siradaki mac"
			}), fx && opp ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-display text-2xl",
						children: home ? "Ic saha" : "Dis saha"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClubLogo, {
						team: opp,
						size: 36
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[15px] text-muted",
					children: opp.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						tone: "primary",
						onClick: () => {
							Sound.whistle();
							onAdvance(false);
						},
						children: "Maci oyna"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						onClick: () => {
							Sound.click();
							onAdvance(true);
						},
						children: "Haftayi ilerlet"
					})]
				})
			] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted",
					children: "Bu hafta lig maci yok."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					className: "mt-3 w-full",
					onClick: () => onAdvance(true),
					children: "Haftayi ilerlet"
				})]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[12px] uppercase tracking-[0.16em] text-muted",
					children: "Menajer"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-1 font-display text-2xl",
					children: [
						career.manager.first,
						" ",
						career.manager.last
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-[13px] text-muted",
					children: [
						roleLabel,
						" · ",
						career.manager.style
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatBar, {
						label: "Guven",
						value: career.manager.trust
					})
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[12px] text-muted",
					children: "Bakiye"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-display text-2xl tabular-nums",
					children: fmtMoney(career.finances.balance)
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[12px] text-muted",
					children: "Takipci"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-display text-2xl tabular-nums",
					children: career.social.followers.toLocaleString("tr-TR")
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-2 text-[12px] uppercase tracking-[0.16em] text-muted",
				children: "Dunya transferleri"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2",
				children: [transfers.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-2 text-[13px]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "truncate",
						children: t.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums text-ok",
						children: fmtFee(t.fee)
					})]
				}, t.id)), !transfers.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-muted",
					children: "Henuz yok."
				})]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-2 text-[12px] uppercase tracking-[0.16em] text-muted",
				children: "Haberler"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3",
				children: news.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-medium",
					children: n.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[13px] text-muted",
					children: n.body
				})] }, n.id))
			})] })
		]
	});
}
function MiniStat({ label, v, sub }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-[18px] bg-bg-elev p-3 hairline",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-[12px] text-muted",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "font-display text-2xl tabular-nums",
				children: sub ?? Math.round(v)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 h-1 overflow-hidden rounded-full bg-bg-hover",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-full bg-pitch",
					style: { width: Math.max(4, Math.min(100, v)) + "%" }
				})
			})
		]
	});
}
function Profile({ career }) {
	const p = career.player;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerCard, {
			player: p,
			date: career.date
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			className: "grid grid-cols-2 gap-3 text-[14px]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					k: "Ad",
					v: p.firstName + " " + p.lastName
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					k: "Mevki",
					v: POS_TR[p.pos]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					k: "Yas",
					v: String(ageFromDob(p.dob, career.date))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					k: "Uyruk",
					v: p.nat + (p.nat2 ? " / " + p.nat2 : "")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					k: "Boy / kilo",
					v: p.height + " cm · " + p.weight + " kg"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					k: "Ayak",
					v: p.foot === "left" ? "Sol" : "Sag"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					k: "Forma",
					v: "#" + p.number
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					k: "Potansiyel",
					v: String(p.potential)
				})
			]
		})]
	});
}
function Row({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "text-[12px] text-muted",
		children: k
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: v })] });
}
function Attrs({ career }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid gap-4",
		children: ATTRIBUTE_GROUPS.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-3 font-display text-xl",
			children: g.tr
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-2",
			children: g.keys.map((k) => {
				const v = career.player.attrs[k.key] ?? 55;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-36 truncate text-[13px] text-muted",
							children: ATTR_TR[k.key]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-1.5 flex-1 overflow-hidden rounded-full bg-bg-hover",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-full",
								style: {
									width: v + "%",
									background: attrColor(v)
								}
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-8 text-right font-display tabular-nums",
							style: { color: attrColor(v) },
							children: v
						})
					]
				}, k.key);
			})
		})] }, g.id))
	});
}
function Stats({ career }) {
	const s = career.seasonStats;
	const items = [
		["Mac", s.apps],
		["Gol", s.goals],
		["Asist", s.assists],
		["Ort. reyting", s.avgRating.toFixed(1)],
		["Sari", s.yellowCards],
		["Kirmizi", s.redCards],
		["MOTM", s.motm],
		["Dakika", s.minutes]
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-2 gap-2",
		children: items.map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-[12px] text-muted",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "font-display text-3xl tabular-nums",
			children: v
		})] }, k))
	});
}
function Training({ career }) {
	const { setTraining } = useGame();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "font-display text-xl",
			children: "Odak"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 grid gap-2",
			children: TRAINING_FOCI.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => {
					Sound.tap();
					setTraining(f.id, career.training.intensity);
				},
				className: "rounded-[14px] px-3 py-3 text-left hairline " + (career.training.focus === f.id ? "bg-accent text-accent-fg" : "bg-bg-soft"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-medium",
					children: f.tr
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[12px] opacity-70",
					children: f.attrs.length ? f.attrs.map((a) => ATTR_TR[a]).join(", ") : "Yorgunluk duser"
				})]
			}, f.id))
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "font-display text-xl",
			children: "Yogunluk"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 grid grid-cols-3 gap-2",
			children: [
				"low",
				"mid",
				"high"
			].map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				tone: career.training.intensity === k ? "primary" : "ghost",
				onClick: () => setTraining(career.training.focus, k),
				children: INTENSITY[k].tr
			}, k))
		})] })]
	});
}
function Matches({ career }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-2",
		children: [career.matchLog.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, { children: "Henuz mac yok." }), career.matchLog.map((m, i) => {
			const home = TEAM_BY_ID[m.home];
			const away = TEAM_BY_ID[m.away];
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "flex items-center gap-3",
				children: [
					home && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClubLogo, {
						team: home,
						size: 28
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1 text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "font-display text-2xl tabular-nums",
							children: [
								m.hg,
								" - ",
								m.ag
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-[12px] text-muted",
							children: [
								m.minutes,
								" dk · ",
								m.goals,
								"G ",
								m.assists,
								"A"
							]
						})]
					}),
					away && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClubLogo, {
						team: away,
						size: 28
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "w-10 text-right font-display text-xl tabular-nums",
						style: { color: ratingColor(m.rating) },
						children: m.rating.toFixed(1)
					})
				]
			}, i);
		})]
	});
}
function Calendar({ career }) {
	const upcoming = career.fixtures.filter((f) => f.week >= career.week && (f.home === career.clubId || f.away === career.clubId)).slice(0, 8);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid gap-2",
		children: upcoming.map((f) => {
			const opp = TEAM_BY_ID[f.home === career.clubId ? f.away : f.home];
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "flex items-center gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "w-16 text-[12px] text-muted",
						children: ["Hafta ", f.week]
					}),
					opp && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClubLogo, {
						team: opp,
						size: 28
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1",
						children: [
							f.home === career.clubId ? "vs" : "@",
							" ",
							opp?.name
						]
					})
				]
			}, f.week + f.home);
		})
	});
}
function Club({ career }) {
	const club = TEAM_BY_ID[career.clubId];
	const table = [...career.table].sort((a, b) => b.pts - a.pts || b.gf - a.gf);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [club && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			className: "flex items-center gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClubLogo, {
				team: club,
				size: 56
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "font-display text-3xl",
				children: club.name
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-muted",
				children: club.country
			})] })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-2 font-display text-xl",
			children: "Puan durumu"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-1",
			children: table.map((r, i) => {
				const t = TEAM_BY_ID[r.teamId];
				const me = r.teamId === career.clubId;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 rounded-[10px] px-2 py-1.5 text-[13px] " + (me ? "bg-bg-hover" : ""),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-5 tabular-nums text-muted",
							children: i + 1
						}),
						t && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClubLogo, {
							team: t,
							size: 18
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "min-w-0 flex-1 truncate",
							children: t?.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-8 text-right tabular-nums",
							children: r.played
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-8 text-right font-medium tabular-nums",
							children: r.pts
						})
					]
				}, r.teamId);
			})
		})] })]
	});
}
function ManagerV({ career }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "font-display text-3xl",
			children: [
				career.manager.first,
				" ",
				career.manager.last
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-muted",
			children: career.manager.style
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatBar, {
				label: "Guven",
				value: career.manager.trust
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-3 text-[14px] text-muted",
			children: ["Rolun: ", career.role === "starter" ? "Ilk 11" : career.role === "rotation" ? "Rotasyon" : "Yedek"]
		})
	] });
}
function Teammates({ career }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid gap-2",
		children: career.teammates.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			className: "flex items-center gap-3 py-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "w-10 font-display text-lg text-muted",
					children: p.pos
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: displayName(p) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-[12px] text-muted",
						children: [
							p.nat,
							" · ",
							p.age,
							" yas"
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-display text-2xl tabular-nums",
					children: p.ovr
				})
			]
		}, p.id))
	});
}
function Transfers({ career }) {
	const { takeOffer } = useGame();
	const confirmed = career.worldTransfers.filter((t) => !t.rumor).slice(0, 30);
	const rumors = career.worldTransfers.filter((t) => t.rumor).slice(0, 20);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-2 font-display text-xl",
					children: "Sana ilgi"
				}),
				career.transferInterest.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-muted",
					children: "Suan izleyen kulup yok."
				}),
				career.transferInterest.map((i) => {
					const t = TEAM_BY_ID[i.teamId];
					const lg = LEAGUES.find((l) => l.id === t?.leagueId);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 py-2",
						children: [t && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClubLogo, {
							team: t,
							size: 28
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: t?.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[12px] text-muted",
							children: lg?.name
						})] })]
					}, i.teamId + i.week);
				})
			] }),
			career.offers.filter((o) => o.status === "open").map((o) => {
				const t = TEAM_BY_ID[o.teamId];
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[12px] uppercase tracking-[0.14em] text-muted",
						children: o.kind === "loan" ? "Kiralik" : "Transfer"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-1 flex items-center gap-3",
						children: [t && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClubLogo, {
							team: t,
							size: 36
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-display text-2xl",
							children: t?.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-[13px] text-muted",
							children: [
								fmtFee(o.fee),
								" · ",
								fmtMoney(o.wage),
								"/hafta"
							]
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							tone: "primary",
							onClick: () => takeOffer(o.id, true),
							children: "Kabul et"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							onClick: () => takeOffer(o.id, false),
							children: "Reddet"
						})]
					})
				] }, o.id);
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-2 font-display text-xl",
				children: "Onaylanan transferler"
			}), confirmed.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-t border-line py-2 first:border-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: t.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums text-ok",
						children: fmtFee(t.fee)
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-[12px] text-muted",
					children: [
						TEAM_BY_ID[t.fromId]?.name,
						" → ",
						TEAM_BY_ID[t.toId]?.name,
						" · ",
						t.pos,
						" ",
						t.ovr,
						t.record ? " · REKOR" : ""
					]
				})]
			}, t.id))] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-2 font-display text-xl text-warn",
				children: "Soylentiler"
			}), rumors.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "py-1 text-[13px] text-muted",
				children: [
					t.name,
					": ",
					TEAM_BY_ID[t.fromId]?.name,
					" → ",
					TEAM_BY_ID[t.toId]?.name
				]
			}, t.id))] })
		]
	});
}
function AgentV({ career }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "font-display text-3xl",
		children: [
			career.agent.first,
			" ",
			career.agent.last
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "mt-2 text-muted",
		children: [
			"Kesinti %",
			career.agent.cut,
			". Teklifler transferler sekmesinde."
		]
	})] });
}
function ContractV({ career }) {
	const c = career.contract;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		className: "grid gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
				k: "Sure",
				v: c.years + " yil"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
				k: "Haftalik maas",
				v: fmtMoney(c.weeklyWage)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
				k: "Mac primi",
				v: fmtMoney(c.appearanceBonus)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
				k: "Gol primi",
				v: fmtMoney(c.goalBonus)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
				k: "Asist primi",
				v: fmtMoney(c.assistBonus)
			})
		]
	});
}
function FinanceV({ career }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-muted",
			children: "Bakiye"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "font-display text-4xl tabular-nums",
			children: fmtMoney(career.finances.balance)
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
				k: "Haftalik maas",
				v: fmtMoney(career.finances.weeklyWage)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					k: "Aylik gelir",
					v: fmtMoney(career.finances.monthlyIncome)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					k: "Aylik gider",
					v: fmtMoney(career.finances.monthlyExpenses)
				})
			})
		] })]
	});
}
function National({ career }) {
	const called = career.player.overall >= 74 && career.player.form >= 58;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "font-display text-2xl",
		children: [career.player.nat, " milli takim"]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-2 text-muted",
		children: called ? "Formun yeterli. Kamp kadrosuna aday gosterildin." : "Henuz kadroya cagrilmadi. Form ve reytingi yukselt."
	})] });
}
function Trophies({ career }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-2",
		children: [
			career.trophies.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, { children: "Dolap bos. Sabir." }),
			career.trophies.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trophy, { size: 18 }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: t.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-[12px] text-muted",
					children: [
						t.season,
						" · ",
						t.team
					]
				})] })]
			}, t.id)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-2 font-display text-xl",
				children: "Basarimlar"
			}), ACHIEVEMENTS.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between py-1.5 text-[14px]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: a.tr }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: career.achievements.includes(a.id) ? "text-ok" : "text-subtle",
					children: career.achievements.includes(a.id) ? "Acildi" : "Kilitli"
				})]
			}, a.id))] })
		]
	});
}
function HistoryV({ career }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid gap-2",
		children: career.careerHistory.map((h, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-[12px] text-muted",
			children: [
				h.season,
				" · Hafta ",
				h.week
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: h.text })] }, i))
	});
}
function LifeV({ career }) {
	const { setCareer, flash } = useGame();
	const apply = (r) => {
		if (typeof r === "string") {
			Sound.fail();
			flash(r, "bad");
			return;
		}
		Sound.success();
		setCareer(r);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniStat, {
						label: "Mutluluk",
						v: career.player.happiness
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniStat, {
						label: "Enerji",
						v: career.player.energy
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniStat, {
						label: "Stres",
						v: career.player.stress
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniStat, {
						label: "Yas",
						v: ageFromDob(career.player.dob, career.date),
						sub: String(ageFromDob(career.player.dob, career.date))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "font-display text-xl",
				children: "Ev"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 grid gap-2",
				children: HOMES.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					disabled: career.life.home >= h.id,
					onClick: () => apply(buyHome(career, h.id)),
					className: "flex items-center justify-between rounded-[12px] bg-bg-soft px-3 py-2 text-left hairline disabled:opacity-50",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: h.tr }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[13px] text-muted",
						children: h.cost ? fmtMoney(h.cost) : "Baslangic"
					})]
				}, h.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "font-display text-xl",
				children: "Araba"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 grid gap-2",
				children: CARS.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					disabled: career.life.car >= h.id,
					onClick: () => apply(buyCar(career, h.id)),
					className: "flex items-center justify-between rounded-[12px] bg-bg-soft px-3 py-2 text-left hairline disabled:opacity-50",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: h.tr }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[13px] text-muted",
						children: h.cost ? fmtMoney(h.cost) : "-"
					})]
				}, h.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-display text-xl",
					children: "Iliski"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-muted",
					children: career.life.relationship === "single" ? "Yalniz" : career.life.partnerName + " · " + career.life.relationship + " · " + career.life.togetherWeeks + " hafta"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap gap-2",
					children: [
						career.life.relationship === "single" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							onClick: () => apply(startDating(career)),
							children: "Birini tanis"
						}),
						career.life.relationship === "dating" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							onClick: () => apply(propose(career)),
							children: "Evlenme teklifi et"
						}),
						career.life.relationship === "engaged" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							onClick: () => apply(marry(career)),
							children: "Evlen"
						}),
						career.life.relationship === "married" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							onClick: () => apply(haveChild(career)),
							children: "Cocuk sahibi ol"
						}),
						career.life.relationship !== "single" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							tone: "danger",
							onClick: () => apply(breakUp(career)),
							children: "Ayril"
						})
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "font-display text-xl",
				children: "Aktivite"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid grid-cols-2 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						onClick: () => apply(rest(career)),
						children: "Dinlen"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						onClick: () => apply(familyVisit(career)),
						children: "Aile ziyareti"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						onClick: () => apply(friendsOut(career)),
						children: "Arkadaslar"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						onClick: () => apply(gym(career)),
						children: "Spor salonu"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						onClick: () => apply(party(career)),
						children: "Parti · £20B"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						onClick: () => apply(vacation(career)),
						children: "Tatil · £50B"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						onClick: () => apply(donate(career)),
						children: "Bagis · £10B"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						onClick: () => apply(invest(career)),
						children: "Yatirim · £200B"
					})
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-2 font-display text-xl",
				children: "Olaylar"
			}), career.life.events.map((e, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-t border-line py-2 text-[14px] first:border-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-muted",
					children: [
						"H",
						e.week,
						" · "
					]
				}), e.text]
			}, i))] })
		]
	});
}
function Create() {
	const { draft, setDraft, createStep, setStep, setScreen } = useGame();
	const ovr = calcOverall(draft.pos, draft.attrs);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto min-h-dvh max-w-lg px-4 pb-28 pt-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "text-[13px] text-muted",
				onClick: () => {
					Sound.tap();
					if (createStep > 1) setStep(createStep - 1);
					else setScreen("menu");
				},
				children: "Geri"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex items-end justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-4xl tracking-tight",
					children: "Oyuncu olustur"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "tabular-nums text-muted",
					children: [
						"Adim ",
						createStep,
						"/4"
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 flex gap-1.5",
				children: [
					1,
					2,
					3,
					4
				].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-1 flex-1 rounded-full " + (n <= createStep ? "bg-accent" : "bg-bg-hover") }, n))
			}),
			createStep === 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid gap-3 fade-up",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Ad",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: draft.firstName,
							onChange: (e) => setDraft({ firstName: e.target.value })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Soyad",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: draft.lastName,
							onChange: (e) => setDraft({ lastName: e.target.value })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Gorunen ad",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: draft.displayName,
							onChange: (e) => setDraft({ displayName: e.target.value })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Uyruk",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
								value: draft.nat,
								onChange: (e) => setDraft({ nat: e.target.value }),
								children: COUNTRIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: c.id,
									children: c.name
								}, c.id))
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Ikinci uyruk",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: draft.nat2,
								onChange: (e) => setDraft({ nat2: e.target.value }),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "Yok"
								}), COUNTRIES.filter((c) => c.id !== draft.nat).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: c.id,
									children: c.name
								}, c.id))]
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Dogum tarihi",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								min: "1981-10-01",
								max: "2010-10-01",
								value: draft.dob,
								onChange: (e) => setDraft({ dob: e.target.value })
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Ayak",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: draft.foot,
								onChange: (e) => setDraft({ foot: e.target.value }),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "right",
									children: "Sag"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "left",
									children: "Sol"
								})]
							})
						})]
					})
				]
			}),
			createStep === 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 fade-up",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-[12px] uppercase tracking-[0.14em] text-muted",
						children: "Mevki"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-3 gap-2",
						children: POSITIONS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								Sound.tap();
								setDraft({ pos: p.id });
							},
							className: "rounded-[12px] px-2 py-3 text-left hairline " + (draft.pos === p.id ? "bg-accent text-accent-fg" : "bg-bg-soft"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-display text-lg leading-none",
								children: p.id
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1 text-[11px] opacity-70",
								children: p.tr
							})]
						}, p.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid grid-cols-2 gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Ikinci mevki",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: draft.pos2,
									onChange: (e) => setDraft({ pos2: e.target.value }),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "Yok"
									}), POSITIONS.filter((p) => p.id !== draft.pos).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: p.id,
										children: [
											p.id,
											" · ",
											p.tr
										]
									}, p.id))]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Forma no",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									min: 1,
									max: 99,
									value: draft.number,
									onChange: (e) => setDraft({ number: Math.max(1, Math.min(99, Number(e.target.value) || 1)) })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Boy (cm)",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									min: 160,
									max: 210,
									value: draft.height,
									onChange: (e) => setDraft({ height: Math.max(160, Math.min(210, Number(e.target.value) || 160)) })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Kilo (kg)",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									min: 55,
									max: 110,
									value: draft.weight,
									onChange: (e) => setDraft({ weight: Math.max(55, Math.min(110, Number(e.target.value) || 55)) })
								})
							})
						]
					})
				]
			}),
			createStep === 3 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 fade-up",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-[12px] uppercase tracking-[0.14em] text-muted",
						children: "Oyun tarzi"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-2",
						children: ARCHETYPES.filter((a) => a.pos.includes(draft.pos)).map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								Sound.tap();
								setDraft({ archetype: a.id });
							},
							className: "rounded-[16px] px-4 py-3 text-left hairline " + (draft.archetype === a.id ? "bg-accent text-accent-fg" : "bg-bg-soft"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-medium",
								children: a.tr
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[12px] opacity-70",
								children: a.pos.join(" · ")
							})]
						}, a.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 mt-5 text-[12px] uppercase tracking-[0.14em] text-muted",
						children: "Kişilik"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-2",
						children: PERSONALITIES.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								Sound.tap();
								setDraft({ personality: p.id });
							},
							className: "rounded-[12px] px-3 py-3 hairline " + (draft.personality === p.id ? "bg-accent text-accent-fg" : "bg-bg-soft"),
							children: p.tr
						}, p.id))
					})
				]
			}),
			createStep === 4 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 fade-up",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 flex items-end justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[12px] uppercase tracking-[0.14em] text-muted",
							children: "Puan dagit"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "font-display text-3xl tabular-nums",
							children: [draft.points, " puan"]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-right",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[12px] text-muted",
								children: "GEN"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-display text-3xl tabular-nums",
								children: ovr
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-3 text-[13px] text-muted",
						children: "Her ozellik 55 baslar. 85 tavan. Yuksek degerler daha pahali."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-2",
						children: ALLOC_ATTRS.map((key) => {
							const v = draft.attrs[key] ?? 55;
							const up = attrCost(v, v + 1);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 rounded-[16px] bg-bg-soft px-3 py-2 hairline",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0 flex-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "truncate text-[14px]",
											children: ATTR_TR[key] || key
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "h-1 overflow-hidden rounded-full bg-bg-hover",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "h-full bg-pitch",
												style: { width: (v - 40) / 45 * 100 + "%" }
											})
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "w-8 text-center font-display text-xl tabular-nums",
										children: v
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "grid size-10 place-items-center rounded-[10px] bg-bg-elev",
										onClick: () => {
											if (v <= 55) return;
											Sound.tap();
											const refund = attrCost(v - 1, v);
											setDraft({
												attrs: {
													...draft.attrs,
													[key]: v - 1
												},
												points: draft.points + refund
											});
										},
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { size: 14 })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "grid size-10 place-items-center rounded-[10px] bg-bg-elev",
										onClick: () => {
											if (v >= 85 || draft.points < up) return;
											Sound.tap();
											setDraft({
												attrs: {
													...draft.attrs,
													[key]: v + 1
												},
												points: draft.points - up
											});
										},
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 14 })
									})
								]
							}, key);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "mt-3 text-[13px] text-muted underline",
						onClick: () => setDraft({
							attrs: blankAttrs(55),
							points: 30
						}),
						children: "Sifirla"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-x-0 bottom-0 z-20 border-t border-line bg-bg/95 px-4 py-3 backdrop-blur",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto max-w-lg",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						tone: "primary",
						className: "h-12 w-full",
						onClick: () => {
							Sound.click();
							if (createStep < 4) setStep(createStep + 1);
							else useGame.getState().setScreen("team");
						},
						children: createStep < 4 ? "Devam" : "Kulup sec"
					})
				})
			})
		]
	});
}
var REAL = 45;
var MATCH_MIN = 90;
function MatchPlay() {
	const { career, pendingMatch, finishPlayedMatch, setScreen } = useGame();
	const canvasRef = (0, import_react.useRef)(null);
	const [ended, setEnded] = (0, import_react.useState)(null);
	const [minute, setMinute] = (0, import_react.useState)(0);
	const [log, setLog] = (0, import_react.useState)([]);
	const [moment, setMoment] = (0, import_react.useState)(null);
	const [benchMsg, setBenchMsg] = (0, import_react.useState)(null);
	const live = (0, import_react.useRef)({
		hg: 0,
		ag: 0,
		goals: 0,
		assists: 0,
		shots: 0,
		keyPasses: 0,
		tackles: 0,
		yellow: false,
		red: false,
		minutesPlayed: 0,
		onPitch: false
	});
	const paused = (0, import_react.useRef)(false);
	const startRef = (0, import_react.useRef)(0);
	const momentsRef = (0, import_react.useRef)([]);
	const fired = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	const doneRef = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		if (!career || !pendingMatch) return;
		Sound.whistle();
		const chance = startChance(career.manager.trust, career.role);
		const starts = Math.random() < chance && career.role !== "bench";
		const benchMin = irand(Math.random, 35, 78);
		live.current.onPitch = starts;
		momentsRef.current = pickMoments(irand(Math.random, 15, 20), career.week * 17 + career.player.overall);
		startRef.current = performance.now();
		paused.current = false;
		pushLog(starts ? "Mac basladi. Ilk 11'densin." : "Yedek kulubesindesin.", starts ? "goal" : "key", 0);
		const home = TEAM_BY_ID[pendingMatch.home];
		const away = TEAM_BY_ID[pendingMatch.away];
		const meHome = pendingMatch.home === career.clubId;
		const hp = home?.power ?? 70;
		const ap = away?.power ?? 70;
		const xgH = expectedGoals(hp, ap, true);
		const xgA = expectedGoals(ap, hp, false);
		const balls = Array.from({ length: 22 }, (_, i) => ({
			x: i < 11 ? .28 + Math.random() * .2 : .52 + Math.random() * .2,
			y: .12 + i % 11 * .07,
			tx: .5,
			ty: .5
		}));
		const ball = {
			x: .5,
			y: .5,
			tx: .5,
			ty: .5
		};
		let raf = 0;
		let lastAmbient = 0;
		const loop = (now) => {
			const cnv = canvasRef.current;
			if (!cnv) {
				raf = requestAnimationFrame(loop);
				return;
			}
			const ctx = cnv.getContext("2d");
			if (!ctx) return;
			const dpr = Math.min(2, window.devicePixelRatio || 1);
			const w = cnv.clientWidth;
			const h = cnv.clientHeight;
			if (cnv.width !== Math.floor(w * dpr)) {
				cnv.width = Math.floor(w * dpr);
				cnv.height = Math.floor(h * dpr);
			}
			ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
			drawPitch(ctx, w, h);
			if (!paused.current && !doneRef.current) {
				const elapsed = (now - startRef.current) / 1e3;
				const m = Math.min(MATCH_MIN, elapsed / REAL * MATCH_MIN);
				setMinute(Math.floor(m));
				if (live.current.onPitch) live.current.minutesPlayed = Math.floor(m) - (starts ? 0 : benchMin);
				if (!starts && !live.current.onPitch && m >= benchMin) {
					live.current.onPitch = true;
					setBenchMsg("Hoca seni cagirdi!");
					Sound.success();
					pushLog("Oyuna girdin.", "goal", Math.floor(m));
					setTimeout(() => setBenchMsg(null), 1800);
				}
				if (now - lastAmbient > 3500 + Math.random() * 3e3) {
					lastAmbient = now;
					pushLog(AMBIENT[Math.floor(Math.random() * AMBIENT.length)], "key", Math.floor(m));
				}
				if (Math.random() < .004) {
					if (Math.random() < xgH / 90) {
						live.current.hg += 1;
						Sound.goal();
						pushLog((home?.name || "Ev") + " gol!", meHome ? "goal" : "concede", Math.floor(m));
					} else if (Math.random() < xgA / 90) {
						live.current.ag += 1;
						pushLog((away?.name || "Dep") + " gol!", meHome ? "concede" : "goal", Math.floor(m));
					}
				}
				for (const mom of momentsRef.current) if (live.current.onPitch && m >= mom.minute && !fired.current.has(mom.minute)) {
					fired.current.add(mom.minute);
					paused.current = true;
					setMoment(mom);
					break;
				}
				ball.x += (ball.tx - ball.x) * .04;
				ball.y += (ball.ty - ball.y) * .04;
				if (Math.random() < .02) {
					ball.tx = .18 + Math.random() * .64;
					ball.ty = .12 + Math.random() * .76;
				}
				balls.forEach((p, i) => {
					if (Math.random() < .03) {
						p.tx = clamp(p.x + (Math.random() - .5) * .12, i < 11 ? .12 : .4, i < 11 ? .6 : .88);
						p.ty = clamp(p.y + (Math.random() - .5) * .1, .08, .92);
					}
					p.x += (p.tx - p.x) * .05;
					p.y += (p.ty - p.y) * .05;
					const col = i < 11 ? meHome ? "#6ea0d4" : "#d46a62" : meHome ? "#d46a62" : "#6ea0d4";
					const me = live.current.onPitch && i === 9;
					ctx.beginPath();
					ctx.arc(p.x * w, p.y * h, me ? 8 : 5.5, 0, Math.PI * 2);
					ctx.fillStyle = me ? "#d6ead6" : col;
					ctx.fill();
					if (me) {
						ctx.fillStyle = "#0b0c0b";
						ctx.font = "700 9px Barlow Condensed, sans-serif";
						ctx.textAlign = "center";
						ctx.fillText("SEN", p.x * w, p.y * h - 12);
					}
				});
				const g = ctx.createRadialGradient(ball.x * w, ball.y * h, 0, ball.x * w, ball.y * h, 16);
				g.addColorStop(0, "rgba(255,255,255,0.9)");
				g.addColorStop(1, "rgba(255,255,255,0)");
				ctx.fillStyle = g;
				ctx.beginPath();
				ctx.arc(ball.x * w, ball.y * h, 16, 0, Math.PI * 2);
				ctx.fill();
				ctx.beginPath();
				ctx.arc(ball.x * w, ball.y * h, 5, 0, Math.PI * 2);
				ctx.fillStyle = "#f4f1ea";
				ctx.fill();
				if (m >= MATCH_MIN) {
					finish();
					return;
				}
			} else balls.forEach((p, i) => {
				const col = i < 11 ? "#6ea0d4" : "#d46a62";
				ctx.beginPath();
				ctx.arc(p.x * w, p.y * h, 5.5, 0, Math.PI * 2);
				ctx.fillStyle = col;
				ctx.fill();
			});
			raf = requestAnimationFrame(loop);
		};
		raf = requestAnimationFrame(loop);
		return () => cancelAnimationFrame(raf);
	}, []);
	function pushLog(t, kind, min) {
		setLog((l) => [{
			t,
			kind,
			min
		}, ...l].slice(0, 24));
	}
	function choose(opt) {
		if (!career || !moment) return;
		const attr = career.player.attrs[opt.attr] ?? 55;
		const ok = Math.random() < chanceOf(attr, career.player.form, career.player.fatigue);
		const L = live.current;
		if (ok) {
			Sound.success();
			if (opt.onSuccess?.goals) {
				L.goals += opt.onSuccess.goals;
				L.shots += opt.onSuccess.shots || 1;
				if (pendingMatch?.home === career.clubId) L.hg += 1;
				else L.ag += 1;
				Sound.goal();
			}
			if (opt.onSuccess?.assists) L.assists += opt.onSuccess.assists;
			if (opt.onSuccess?.shots) L.shots += opt.onSuccess.shots;
			if (opt.onSuccess?.keyPasses) L.keyPasses += opt.onSuccess.keyPasses;
			if (opt.onSuccess?.tackles) L.tackles += opt.onSuccess.tackles;
			pushLog(opt.success, opt.tone === "goal" ? "goal" : "key", moment.minute);
		} else {
			Sound.fail();
			if (opt.onFail?.shots) L.shots += opt.onFail.shots;
			if (opt.onFail?.yellow) {
				L.yellow = true;
				Sound.card();
			}
			if (opt.onFail?.concede) {
				if (pendingMatch?.home === career.clubId) L.ag += 1;
				else L.hg += 1;
			}
			pushLog(opt.fail, opt.tone === "warn" ? "warn" : "miss", moment.minute);
		}
		setMoment(null);
		paused.current = false;
		startRef.current += 0;
	}
	function finish() {
		if (!career || !pendingMatch || doneRef.current) return;
		doneRef.current = true;
		const L = live.current;
		const mins = Math.max(0, L.onPitch ? Math.max(L.minutesPlayed, 8) : 0);
		let rating = 6.1 + L.goals * .7 + L.assists * .4 + (L.shots > 2 ? .15 : 0);
		if (!L.onPitch) rating = 5.5;
		rating = clamp(Math.round(rating * 10) / 10, 4.8, 9.8);
		const res = {
			week: career.week,
			home: pendingMatch.home,
			away: pendingMatch.away,
			hg: L.hg,
			ag: L.ag,
			rating,
			goals: L.goals,
			assists: L.assists,
			minutes: mins,
			motm: rating >= 8.4,
			yellow: L.yellow,
			red: L.red,
			shots: L.shots,
			keyPasses: L.keyPasses,
			tackles: L.tackles,
			role: career.role
		};
		paused.current = true;
		setEnded(res);
		Sound.whistle();
	}
	if (!career || !pendingMatch) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "p-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
			onClick: () => setScreen("career"),
			children: "Geri"
		})
	});
	const home = TEAM_BY_ID[pendingMatch.home];
	const away = TEAM_BY_ID[pendingMatch.away];
	const L = live.current;
	if (ended) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex min-h-dvh max-w-lg flex-col justify-center px-5 py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-center text-[12px] uppercase tracking-[0.2em] text-muted",
				children: "Mac sonu"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex items-center justify-center gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClubLogo, {
						team: home,
						size: 48
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "font-display text-6xl tabular-nums",
						children: [
							ended.hg,
							"-",
							ended.ag
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClubLogo, {
						team: away,
						size: 48
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 text-center font-display text-4xl tabular-nums",
				style: { color: ratingColor(ended.rating) },
				children: ended.rating.toFixed(1)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 grid grid-cols-3 gap-2 text-center",
				children: [
					["Gol", ended.goals],
					["Asist", ended.assists],
					["Sut", ended.shots],
					["Kilit pas", ended.keyPasses],
					["Mudahale", ended.tackles],
					["Dakika", ended.minutes]
				].map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-[16px] bg-bg-elev py-3 hairline",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[11px] text-muted",
						children: k
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-display text-2xl tabular-nums",
						children: v
					})]
				}, String(k)))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				tone: "primary",
				className: "mt-8 h-12",
				onClick: () => finishPlayedMatch(ended),
				children: "Kariyere don"
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col bg-bg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between px-3 py-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClubLogo, {
							team: home,
							size: 24
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-display text-2xl tabular-nums",
							children: [
								L.hg,
								"-",
								L.ag
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClubLogo, {
							team: away,
							size: 24
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "font-display text-xl tabular-nums",
					children: [Math.min(90, minute), "'"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-3 overflow-hidden rounded-[18px]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
					ref: canvasRef,
					className: "block h-[42vh] w-full touch-none"
				}), benchMsg && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute inset-x-4 top-4 rounded-[14px] bg-accent px-3 py-2 text-center text-accent-fg",
					children: benchMsg
				})]
			}),
			moment && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-3 mt-3 rounded-[22px] bg-bg-elev p-4 hairline",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-[12px] uppercase tracking-[0.16em] text-muted",
						children: [moment.minute, ". dakika"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-1 font-display text-2xl",
						children: moment.prompt
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 grid gap-2",
						children: moment.options.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							className: "justify-start",
							onClick: () => choose(o),
							children: o.label
						}, o.id))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "min-h-0 flex-1 overflow-y-auto px-3 py-3",
				children: log.map((l, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border-l-2 py-1 pl-3 text-[13px] " + (l.kind === "goal" ? "border-ok text-ok" : l.kind === "concede" ? "border-danger text-danger" : l.kind === "miss" ? "border-warn text-warn" : l.kind === "warn" ? "border-warn text-warn" : "border-line text-muted"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "tabular-nums",
						children: [l.min, "' "]
					}), l.t]
				}, i))
			})
		]
	});
}
function drawPitch(ctx, w, h) {
	const g = ctx.createLinearGradient(0, 0, 0, h);
	g.addColorStop(0, "#1b4a32");
	g.addColorStop(1, "#123526");
	ctx.fillStyle = g;
	ctx.fillRect(0, 0, w, h);
	for (let i = 0; i < 8; i++) {
		ctx.fillStyle = i % 2 ? "rgba(255,255,255,0.025)" : "rgba(0,0,0,0.04)";
		ctx.fillRect(w / 8 * i, 0, w / 8, h);
	}
	ctx.strokeStyle = "rgba(245,245,240,0.55)";
	ctx.lineWidth = 1.4;
	const pad = 10;
	ctx.strokeRect(pad, pad, w - 20, h - 20);
	ctx.beginPath();
	ctx.moveTo(w / 2, pad);
	ctx.lineTo(w / 2, h - pad);
	ctx.stroke();
	ctx.beginPath();
	ctx.arc(w / 2, h / 2, h * .14, 0, Math.PI * 2);
	ctx.stroke();
	ctx.beginPath();
	ctx.arc(w / 2, h / 2, 2.4, 0, Math.PI * 2);
	ctx.fillStyle = "rgba(245,245,240,0.8)";
	ctx.fill();
	const bw = w * .5;
	const bh = h * .36;
	const boxH = h * .16;
	ctx.strokeRect(pad, (h - bh) / 2, bw * .22, bh);
	ctx.strokeRect(w - pad - bw * .22, (h - bh) / 2, bw * .22, bh);
	ctx.strokeRect(pad, (h - boxH) / 2, bw * .08, boxH);
	ctx.strokeRect(w - pad - bw * .08, (h - boxH) / 2, bw * .08, boxH);
	ctx.beginPath();
	ctx.arc(pad + bw * .16, h / 2, 2, 0, Math.PI * 2);
	ctx.arc(w - pad - bw * .16, h / 2, 2, 0, Math.PI * 2);
	ctx.fill();
}
function Menu$1() {
	const { sound, toggleSound, setScreen, load } = useGame();
	const slots = (0, import_react.useMemo)(() => listSlots(), []);
	const latest = [...slots].reverse().find((s) => s.occupied) || slots.find((s) => s.occupied);
	const club = latest?.club ? TEAM_BY_ID[latest.club] : void 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "pitch-bg relative min-h-dvh",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex min-h-dvh max-w-lg flex-col px-5 pb-8 pt-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[11px] uppercase tracking-[0.22em] text-muted",
						children: "v25 · TR"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": sound ? "Sesi kapat" : "Sesi ac",
						className: "grid size-11 place-items-center rounded-full bg-bg-soft hairline",
						onClick: () => {
							Sound.tap();
							toggleSound();
						},
						children: sound ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { size: 18 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { size: 18 })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-1 flex-col justify-center py-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[12px] font-medium uppercase tracking-[0.28em] text-pitch",
							children: "Oyuncu kariyer modu"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "mt-2 font-display text-[56px] leading-[0.88] tracking-tight sm:text-[72px]",
							children: [
								"FUTBOL",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								"KARİYERİ"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-[34ch] text-[15px] leading-relaxed text-muted",
							children: "Sifirdan bir isim ol. Liglerde ilerle, stad isiklarinda oyna, transfer tekliflerini oku."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex flex-col gap-2.5",
							children: [
								latest?.occupied && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
									tone: "primary",
									className: "h-14 justify-between px-5",
									onClick: () => {
										Sound.click();
										load(latest.slot);
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "flex items-center gap-3",
										children: [club && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClubLogo, {
											team: club,
											size: 28
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-left",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "block text-[11px] uppercase tracking-[0.16em] opacity-70",
												children: "Kariyere devam et"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "block font-display text-xl leading-none",
												children: latest.name
											})]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { size: 16 })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
									className: "h-12 justify-start",
									onClick: () => {
										Sound.click();
										setScreen("create");
									},
									children: "Yeni kariyer"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
									className: "h-12 justify-start",
									onClick: () => {
										Sound.click();
										setScreen("load");
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderOpen, { size: 16 }), " Kariyer yukle"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-3 gap-2.5",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
											className: "h-12 px-2 text-[13px]",
											onClick: () => {
												Sound.tap();
												setScreen("achievements");
											},
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { size: 15 }), " Basarim"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
											className: "h-12 px-2 text-[13px]",
											onClick: () => {
												Sound.tap();
												setScreen("howto");
											},
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleHelp, { size: 15 }), " Nasil"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
											className: "h-12 px-2 text-[13px]",
											onClick: () => {
												Sound.tap();
												setScreen("settings");
											},
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings2, { size: 15 }), " Ayarlar"]
										})
									]
								})
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-center text-[12px] text-subtle",
					children: "Kayitlar bu cihazda tutulur · 3 yuva"
				})
			]
		})
	});
}
function TeamSelect() {
	const { draft, offers, shuffleClubs, startFromClub, setScreen, setStep } = useGame();
	const [picked, setPicked] = (0, import_react.useState)(null);
	const ovr = calcOverall(draft.pos, draft.attrs);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto min-h-dvh max-w-lg px-4 pb-28 pt-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "text-[13px] text-muted",
				onClick: () => {
					Sound.tap();
					setStep(4);
					setScreen("create");
				},
				children: "Geri"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-4xl tracking-tight",
				children: "Ilk kulubun"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-[15px] text-muted",
				children: "Uc teklif. Gucune gore haftalik maas belirlenir."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 grid gap-3",
				children: offers.map((id) => {
					const t = TEAM_BY_ID[id];
					if (!t) return null;
					const league = LEAGUES.find((l) => l.id === t.leagueId);
					const wage = wageFor(ovr, t.power);
					const on = picked === id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							Sound.tap();
							setPicked(id);
						},
						className: "rounded-[28px] p-4 text-left hairline " + (on ? "bg-accent text-accent-fg" : "bg-bg-elev"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClubLogo, {
										team: t,
										size: 44
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0 flex-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "font-display text-2xl leading-none",
											children: t.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-1 text-[12px] " + (on ? "opacity-70" : "text-muted"),
											children: [
												t.country,
												" · ",
												league?.name
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-right",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "font-display text-2xl tabular-nums",
											children: t.power
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[10px] uppercase tracking-[0.14em] " + (on ? "opacity-70" : "text-muted"),
											children: "Guc"
										})]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3 h-1.5 overflow-hidden rounded-full bg-black/20",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full bg-pitch",
									style: { width: t.power + "%" }
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 text-[13px] " + (on ? "opacity-80" : "text-muted"),
								children: [
									"Teklif edilen maas ",
									fmtMoney(wage),
									" / hafta"
								]
							})
						]
					}, id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				className: "mt-4 w-full",
				onClick: () => {
					Sound.pop();
					shuffleClubs();
					setPicked(null);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shuffle, { size: 16 }), " Karistir"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "mt-4 text-[13px] text-muted",
				children: [
					draft.displayName,
					" · ",
					draft.pos,
					" · GEN ",
					ovr
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-x-0 bottom-0 z-20 border-t border-line bg-bg/95 px-4 py-3 backdrop-blur",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto max-w-lg",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						tone: "primary",
						className: "h-12 w-full",
						disabled: !picked,
						onClick: () => {
							if (!picked) return;
							Sound.success();
							startFromClub(picked, suggestedSlot());
						},
						children: "Kariyere basla"
					})
				})
			})
		]
	});
}
function GameApp() {
	const { hydrated, hydrate, screen, toast, sound, toggleSound, setScreen, load } = useGame();
	(0, import_react.useEffect)(() => {
		hydrate();
		const on = () => unlockSound();
		window.addEventListener("pointerdown", on, { once: true });
		document.addEventListener("visibilitychange", () => {
			if (document.visibilityState === "visible") unlockSound();
		});
		return () => window.removeEventListener("pointerdown", on);
	}, [hydrate]);
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid min-h-dvh place-items-center bg-bg text-muted",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "font-display text-3xl tracking-tight text-fg",
			children: "FUTBOL KARİYERİ"
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: [
			screen === "menu" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu$1, {}),
			screen === "create" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Create, {}),
			screen === "team" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeamSelect, {}),
			screen === "career" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Career, {}),
			screen === "match" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchPlay, {}),
			screen === "load" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadScreen, {}),
			screen === "achievements" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AchievementsScreen, {}),
			screen === "howto" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HowTo, {}),
			screen === "settings" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsScreen, {}),
			toast && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none fixed inset-x-0 top-4 z-50 flex justify-center px-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rounded-full px-4 py-2 text-[14px] hairline " + (toast.kind === "bad" ? "bg-danger/20 text-danger" : "bg-bg-elev text-fg"),
					children: toast.text
				})
			})
		]
	});
	function LoadScreen() {
		const slots = listSlots();
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meta, {
			title: "Kariyer yukle",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3",
				children: slots.map((s) => {
					const club = s.club ? TEAM_BY_ID[s.club] : void 0;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-8 font-display text-2xl text-muted",
							children: s.slot + 1
						}), s.occupied ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							club && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClubLogo, {
								team: club,
								size: 32
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-medium",
									children: s.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-[12px] text-muted",
									children: [
										club?.name,
										" · OVR ",
										s.ovr,
										" · ",
										s.season,
										" H",
										s.week
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
								tone: "primary",
								onClick: () => {
									Sound.click();
									load(s.slot);
								},
								children: "Yukle"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
								tone: "danger",
								onClick: () => {
									clearSlot(s.slot);
									setScreen("menu");
									setScreen("load");
								},
								children: "Sil"
							})
						] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-muted",
							children: "Bos yuva"
						})]
					}, s.slot);
				})
			})
		});
	}
	function AchievementsScreen() {
		const career = useGame.getState().career;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meta, {
			title: "Basarimlar",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-2",
				children: ACHIEVEMENTS.map((a) => {
					const on = career?.achievements.includes(a.id);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-medium",
							children: a.tr
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[13px] text-muted",
							children: a.desc
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: on ? "text-ok" : "text-subtle",
							children: on ? "Acildi" : "Kilitli"
						})]
					}, a.id);
				})
			})
		});
	}
	function HowTo() {
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meta, {
			title: "Nasil oynanir",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "grid gap-3 text-[15px] leading-relaxed text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Oyuncu olustur, 30 puani ozelliklere dagit, bir kulup sec." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Her hafta antrenman yap. Mac gununde sahaya cik veya simule et." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Mac icinde anlik kararlar reytingini, gol ve asistini belirler." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Footballgram'da paylas, DM at, takipci kas. Yasaminda ev, araba ve iliski yonet." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Guclu form, daha iyi teklifler demek. Menajer guveni ilk 11'e giden yoldur." })
				]
			})
		});
	}
	function SettingsScreen() {
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meta, {
			title: "Ayarlar",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "grid gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-center justify-between",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: "Dil" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[13px] text-muted",
							children: "Turkce"
						})] })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: "Ses efektleri" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[13px] text-muted",
							children: sound ? "Acik" : "Kapali"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							onClick: () => {
								Sound.tap();
								toggleSound();
							},
							children: sound ? "Kapat" : "Ac"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[13px] text-muted",
						children: "Otomatik kayit her hafta ilerlemede calisir. 3 yuva, surum 25."
					})
				]
			})
		});
	}
}
function Meta({ title, children }) {
	const setScreen = useGame((s) => s.setScreen);
	const career = useGame((s) => s.career);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto min-h-dvh max-w-lg px-4 py-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "text-[13px] text-muted",
				onClick: () => {
					Sound.tap();
					setScreen(career ? "career" : "menu");
				},
				children: "Geri"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-4xl tracking-tight",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5",
				children
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameApp, {});
}
//#endregion
export { Home as component };
