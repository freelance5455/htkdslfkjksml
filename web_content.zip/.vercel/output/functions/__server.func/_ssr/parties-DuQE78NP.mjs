import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { i as createParty, v as useInvalidateBooks, x as useParties } from "./use-books-BtZpLk9U.mjs";
import { a as PARTY_LABELS, s as formatJalali } from "./format-c9GA3s0l.mjs";
import { i as PageHeader, n as Card, r as Money, t as Badge } from "./card-Bb_-PO54.mjs";
import { t as Button } from "./button-BiViDDnZ.mjs";
import { n as Input, t as Field } from "./input-CAg20-g-.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/parties-DuQE78NP.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PartiesPage() {
	const { data = [] } = useParties();
	const invalidate = useInvalidateBooks();
	const [open, setOpen] = (0, import_react.useState)(false);
	const [name, setName] = (0, import_react.useState)("");
	const [kind, setKind] = (0, import_react.useState)("customer");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [address, setAddress] = (0, import_react.useState)("");
	async function save() {
		try {
			await createParty({ data: {
				name,
				kind,
				phone,
				address
			} });
			toast.success("شخص ثبت شد");
			setOpen(false);
			setName("");
			invalidate();
		} catch (e) {
			toast.error(e instanceof Error ? e.message : "خطا");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "اشخاص",
			description: "مشتری، تأمین‌کننده و سایر تفصیلی‌های شناور — بدون تکرار در کدینگ حساب.",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "gold",
				onClick: () => setOpen(true),
				children: "شخص جدید"
			})
		}),
		open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "mb-5 grid gap-3 sm:grid-cols-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "نام",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: name,
						onChange: (e) => setName(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "نوع",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						value: kind,
						onChange: (e) => setKind(e.target.value),
						className: "h-11 w-full rounded-[10px] border border-line bg-paper px-3 text-sm",
						children: Object.entries(PARTY_LABELS).map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: k,
							children: v
						}, k))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "تلفن",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: phone,
						onChange: (e) => setPhone(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "آدرس",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: address,
						onChange: (e) => setAddress(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "sm:col-span-2 flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: save,
						children: "ثبت"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						onClick: () => setOpen(false),
						children: "انصراف"
					})]
				})
			]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-3 sm:grid-cols-2",
			children: data.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-medium text-navy",
						children: p.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted",
						children: p.code
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: PARTY_LABELS[p.kind] ?? p.kind })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid grid-cols-2 gap-2 text-xs",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["فروش / خرید", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-1 text-sm",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
								value: p.sales || p.purchases,
								compact: true
							})
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["مانده", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-1 text-sm",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
								value: p.ar || p.ap,
								compact: true
							})
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["آخرین تراکنش: ", p.lastDate ? formatJalali(p.lastDate) : "—"] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["تعداد عملیات: ", p.opCount] })
					]
				})]
			}, p.id))
		})
	] });
}
//#endregion
export { PartiesPage as component };
