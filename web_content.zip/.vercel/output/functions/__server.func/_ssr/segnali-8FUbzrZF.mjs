import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as useStudy } from "./router-C-xQh0iG.mjs";
import { n as RoadSign, t as ItText } from "./road-sign-_-tGVxDe.mjs";
import { n as SIGNS, t as CATS } from "./signs-CNNmKTo_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/segnali-8FUbzrZF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Segnali() {
	const [cat, setCat] = (0, import_react.useState)("all");
	const [q, setQ] = (0, import_react.useState)("");
	const [open, setOpen] = (0, import_react.useState)(null);
	const learned = useStudy((s) => s.learned);
	const toggle = useStudy((s) => s.toggleLearned);
	const list = (0, import_react.useMemo)(() => {
		const query = q.trim().toLowerCase();
		return SIGNS.filter((s) => cat === "all" ? true : s.cat === cat).filter((s) => {
			if (!query) return true;
			return s.nameIt.toLowerCase().includes(query) || s.nameAr.includes(query) || s.explainAr.includes(query);
		});
	}, [cat, q]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-primary",
					children: "Segnaletica"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-3xl font-semibold",
					children: "الإشارات"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-muted",
					children: "اسم إيطالي، اسم عربي، وشرح للاثنين. الرسم تعليمي بشكل الإشارة الرسمي."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: q,
				onChange: (e) => setQ(e.target.value),
				placeholder: "ابحث: توقف، sorpasso، أولوية…",
				className: "min-h-11 w-full rounded-xl border border-line bg-surface px-3 outline-none focus:border-primary"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2 overflow-x-auto pb-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
					on: cat === "all",
					onClick: () => setCat("all"),
					children: "الكل"
				}), CATS.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
					on: cat === c.id,
					onClick: () => setCat(c.id),
					children: c.ar
				}, c.id))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid grid-cols-2 gap-3 sm:grid-cols-3",
				children: list.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setOpen(s),
					className: "h-full w-full rounded-2xl border border-line bg-surface p-3 text-right",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoadSign, {
							id: s.id,
							className: "mx-auto h-24 w-24"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							dir: "ltr",
							lang: "it",
							className: "mt-2 block text-left text-sm font-semibold",
							children: s.nameIt
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 block text-sm text-muted",
							children: s.nameAr
						})
					]
				}) }, s.id))
			}),
			list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted",
				children: "لا توجد إشارة بهذا البحث."
			}) : null,
			open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-40 flex items-end justify-center bg-ink/40 md:items-center",
				role: "presentation",
				onClick: () => setOpen(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-h-screen w-full overflow-y-auto rounded-t-2xl bg-surface p-4 md:max-w-lg md:rounded-2xl",
					onClick: (e) => e.stopPropagation(),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoadSign, {
							id: open.id,
							className: "mx-auto h-40 w-40"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItText, {
							text: open.nameIt,
							className: "mt-3 text-2xl font-semibold"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-1 text-xl font-semibold",
							children: open.nameAr
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItText, { text: open.explainIt }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "rounded-xl bg-soft px-3 py-3 leading-relaxed",
								children: open.explainAr
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "min-h-11 rounded-full bg-primary px-4 text-primary-fg",
								onClick: () => toggle(open.id),
								children: learned.includes(open.id) ? "محفوظة في مراجعتي" : "علّمها كمُراجعة"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "min-h-11 rounded-full border border-line px-4",
								onClick: () => setOpen(null),
								children: "إغلاق"
							})]
						})
					]
				})
			}) : null
		]
	});
}
function Chip({ children, on, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: `min-h-11 shrink-0 rounded-full px-3 text-sm ${on ? "bg-primary text-primary-fg" : "border border-line bg-surface"}`,
		children
	});
}
//#endregion
export { Segnali as component };
