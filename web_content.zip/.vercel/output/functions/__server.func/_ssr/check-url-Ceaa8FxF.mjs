import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { i as string, r as object } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/check-url-Ceaa8FxF.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var checkUrlHealth_createServerFn_handler = createServerRpc({
	id: "4c4eb8872214c81e1a792ddd5c3b8ae4ea56b02a8894d5be3588ea1e9c714cf8",
	name: "checkUrlHealth",
	filename: "src/lib/check-url.ts"
}, (opts) => checkUrlHealth.__executeServer(opts));
var checkUrlHealth = createServerFn({ method: "POST" }).validator(object({ url: string().min(1).max(2e3) })).handler(checkUrlHealth_createServerFn_handler, async ({ data }) => {
	const started = Date.now();
	let url = data.url.trim();
	if (!/^https?:\/\//i.test(url)) url = `https://${url}`;
	try {
		const parsed = new URL(url);
		if (parsed.protocol !== "http:" && parsed.protocol !== "https:") return {
			ok: false,
			status: 0,
			ms: 0,
			checkedAt: Date.now(),
			error: "bad protocol"
		};
		const controller = new AbortController();
		const timer = setTimeout(() => controller.abort(), 8e3);
		const res = await fetch(parsed.toString(), {
			method: "GET",
			redirect: "follow",
			signal: controller.signal,
			headers: {
				"User-Agent": "LakshaWatch/1.0 (uptime-monitor)",
				Accept: "text/html,application/json;q=0.9,*/*;q=0.8"
			}
		});
		clearTimeout(timer);
		return {
			ok: res.ok,
			status: res.status,
			ms: Date.now() - started,
			checkedAt: Date.now()
		};
	} catch (err) {
		return {
			ok: false,
			status: 0,
			ms: Date.now() - started,
			checkedAt: Date.now(),
			error: err instanceof Error ? err.message : "failed"
		};
	}
});
//#endregion
export { checkUrlHealth_createServerFn_handler };
