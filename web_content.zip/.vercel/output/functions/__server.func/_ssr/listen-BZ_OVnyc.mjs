import { i as __toESM } from "../_runtime.mjs";
import { B as require_react, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as Download, f as Play, p as Pause } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as BackButton } from "./back-button-DImimZOp.mjs";
import { i as audioEngine, l as toArabicDigits, o as downloadSurahAyahs, r as TopBar, s as getReciter, t as AppShell, u as useAppStore } from "./app-shell-C4IrQdCN.mjs";
import { o as libraryBooks, r as adhkarLists, s as loadQuran, u as quranMeta } from "./catalog-CjAfWU9w.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/listen-BZ_OVnyc.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ListenPage() {
	const reciterId = useAppStore((s) => s.settings.reciterId);
	const setReciter = useAppStore((s) => s.setReciter);
	const downloaded = useAppStore((s) => s.downloadedSurahs);
	const markDownloaded = useAppStore((s) => s.markDownloaded);
	const [tab, setTab] = (0, import_react.useState)("quran");
	const [status, setStatus] = (0, import_react.useState)(audioEngine.status);
	const [busyId, setBusyId] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => audioEngine.subscribe(setStatus), []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
			title: "الاستماع",
			back: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackButton, { href: "/" })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-4 pt-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "block text-xs text-muted-foreground",
					children: "القارئ"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: "mt-1 h-11 w-full rounded-xl border border-border bg-card px-3 text-sm",
					value: reciterId,
					onChange: (e) => setReciter(e.target.value),
					children: [
						"alafasy",
						"husary",
						"sudais",
						"minshawi"
					].map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: id,
						children: getReciter(id).name
					}, id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 grid grid-cols-3 gap-1 rounded-2xl bg-surface p-1",
					children: [
						["quran", "القرآن"],
						["adhkar", "الأذكار"],
						["library", "المكتبة"]
					].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setTab(id),
						className: `h-10 rounded-xl text-sm ${tab === id ? "bg-card text-foreground shadow-sm" : "text-muted-foreground"}`,
						children: label
					}, id))
				})
			]
		}),
		tab === "quran" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-2 divide-y divide-border px-2 pb-6",
			children: quranMeta.surahs.map((s) => {
				const playing = status.surahId === s.id && status.playing;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center gap-2 px-3 py-2.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-8 text-sm text-muted-foreground",
							children: toArabicDigits(s.id)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex-1 font-quran",
							children: s.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "tap-lg size-10 text-accent",
							"aria-label": "تنزيل",
							disabled: busyId === s.id,
							onClick: () => {
								(async () => {
									setBusyId(s.id);
									try {
										const surah = (await loadQuran()).find((x) => x.id === s.id);
										if (!surah) return;
										const n = await downloadSurahAyahs(getReciter(reciterId), surah);
										markDownloaded(s.id);
										toast(n ? `حُفظت ${toArabicDigits(n)} آية` : "تعذر التنزيل");
									} finally {
										setBusyId(null);
									}
								})();
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: `mx-auto size-4 ${downloaded.includes(s.id) ? "opacity-100" : "opacity-50"}` })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "tap-lg size-10 text-accent",
							onClick: () => {
								(async () => {
									if (playing) {
										audioEngine.toggle();
										return;
									}
									const surah = (await loadQuran()).find((x) => x.id === s.id);
									if (!surah) return;
									const first = surah.ayahs[0];
									await audioEngine.playAyah({
										surahId: surah.id,
										ayah: first.n,
										global: first.g,
										title: surah.name,
										reciterId,
										continueSurah: surah
									});
								})();
							},
							children: playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "mx-auto size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "mx-auto size-4" })
						})
					]
				}, s.id);
			})
		}) : null,
		tab === "adhkar" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-3 space-y-2 px-4 pb-6",
			children: adhkarLists.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "flex w-full items-center justify-between rounded-2xl bg-card px-4 py-3.5 text-right shadow-[var(--shadow-border)]",
				onClick: () => {
					const text = l.items.map((i) => i.text).join("\n\n");
					if (!audioEngine.speak(text.slice(0, 4e3), l.title)) toast("قراءة الجهاز غير متاحة");
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: l.title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4 text-accent" })]
			}) }, l.id))
		}) : null,
		tab === "library" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-3 space-y-2 px-4 pb-6",
			children: libraryBooks.filter((b) => !b.comingSoon).map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "flex w-full items-center justify-between rounded-2xl bg-card px-4 py-3.5 text-right shadow-[var(--shadow-border)]",
				onClick: () => {
					const text = b.sections[0]?.body ?? "";
					if (!audioEngine.speak(text.slice(0, 4e3), b.title)) toast("قراءة الجهاز غير متاحة");
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block",
					children: b.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-muted-foreground",
					children: "قراءة الجهاز للنص المتوفر"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4 text-accent" })]
			}) }, b.id))
		}) : null
	] });
}
//#endregion
export { ListenPage as component };
