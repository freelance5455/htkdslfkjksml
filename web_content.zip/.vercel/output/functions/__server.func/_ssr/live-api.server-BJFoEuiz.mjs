import { a as emptyStats, d as sampleGift, l as normalizeUsername, n as applyStats, t as SEED, u as sampleChat } from "./model-CryEHs3X.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/live-api.server-BJFoEuiz.js
function state() {
	const g = globalThis;
	if (!g.__onda) g.__onda = {
		rooms: /* @__PURE__ */ new Map(),
		active: null
	};
	return g.__onda;
}
function roomIdOk(id) {
	return /^[a-zA-Z0-9-]{8,80}$/.test(id);
}
function ensureRoom(id) {
	if (!roomIdOk(id)) return null;
	const bag = state();
	const existing = bag.rooms.get(id);
	if (existing) return existing;
	if (bag.rooms.size > 40) {
		const oldest = [...bag.rooms.values()].sort((a, b) => a.createdAt - b.createdAt)[0];
		if (oldest) bag.rooms.delete(oldest.id);
	}
	const room = {
		id,
		mode: "demo",
		username: "",
		stats: emptyStats(),
		recent: [],
		subscribers: /* @__PURE__ */ new Set(),
		primed: false,
		lastStatus: null,
		createdAt: Date.now()
	};
	bag.rooms.set(id, room);
	return room;
}
function fanout(room, event) {
	for (const send of room.subscribers) try {
		send(event);
	} catch {
		room.subscribers.delete(send);
	}
}
function publish(room, event) {
	if (event.kind === "status") {
		room.lastStatus = event;
		fanout(room, event);
		return;
	}
	if (event.kind === "sync") {
		fanout(room, event);
		return;
	}
	room.stats = applyStats(room.stats, event);
	if (!(event.kind === "viewers" || event.kind === "like")) {
		const without = room.recent.filter((item) => item.id !== event.id);
		without.push({
			...event,
			replay: void 0
		});
		room.recent = without.slice(-80);
	}
	fanout(room, event);
}
function subscribe(room, send) {
	room.subscribers.add(send);
	send({
		id: `sync-${room.id}`,
		ts: Date.now(),
		kind: "sync",
		viewers: room.stats.viewers,
		likes: room.stats.likes,
		follows: room.stats.follows,
		shares: room.stats.shares,
		coins: room.stats.coins,
		ranks: room.stats.ranks
	});
	if (room.lastStatus) send(room.lastStatus);
	for (const event of room.recent) send({
		...event,
		replay: true
	});
	return () => {
		room.subscribers.delete(send);
	};
}
function resetRoom(room) {
	room.stats = emptyStats();
	room.recent = [];
	room.primed = false;
	room.mode = "demo";
	room.username = "";
	room.lastStatus = null;
}
async function dropConnection(roomId) {
	const bag = state();
	if (!bag.active) return;
	if (roomId && bag.active.roomId !== roomId) return;
	const current = bag.active;
	bag.active = null;
	try {
		await current.connection.disconnect();
	} catch {}
}
function setActive(roomId, connection) {
	state().active = {
		roomId,
		connection
	};
}
function isCurrent(roomId, connection) {
	const active = state().active;
	return active?.roomId === roomId && active.connection === connection;
}
var ROLES = /* @__PURE__ */ new Set([
	"viewer",
	"mod",
	"sub",
	"fan"
]);
function person(input) {
	if (!input || typeof input !== "object") return null;
	const row = input;
	const name = typeof row.name === "string" ? row.name.slice(0, 32) : "";
	const nick = typeof row.nick === "string" ? row.nick.slice(0, 32) : name;
	const role = ROLES.has(row.role) ? row.role : "viewer";
	if (!/^[a-zA-Z0-9._]{2,32}$/.test(name)) return null;
	const avatar = typeof row.avatar === "string" && row.avatar.startsWith("https://") ? row.avatar.slice(0, 400) : void 0;
	return {
		name,
		nick: nick || name,
		role,
		avatar
	};
}
function sanitizeEvent(input) {
	if (!input || typeof input !== "object") return null;
	const row = input;
	const id = typeof row.id === "string" ? row.id.slice(0, 40) : "";
	if (!/^[a-zA-Z0-9_-]{4,40}$/.test(id)) return null;
	const ts = typeof row.ts === "number" && Number.isFinite(row.ts) ? row.ts : Date.now();
	const kind = row.kind;
	if (kind === "viewers") return {
		id,
		ts,
		kind: "viewers",
		count: typeof row.count === "number" ? Math.max(0, Math.min(5e6, Math.round(row.count))) : 0
	};
	const user = person(row.user);
	if (!user) return null;
	if (kind === "chat" && typeof row.text === "string") {
		const text = row.text.replace(/\s+/g, " ").trim().slice(0, 280);
		if (!text) return null;
		return {
			id,
			ts,
			kind: "chat",
			user,
			text
		};
	}
	if (kind === "gift" && typeof row.gift === "string") {
		const gift = row.gift.replace(/\s+/g, " ").trim().slice(0, 40);
		const diamonds = typeof row.diamonds === "number" ? Math.max(0, Math.min(1e5, Math.round(row.diamonds))) : 1;
		const repeat = typeof row.repeat === "number" ? Math.max(1, Math.min(999, Math.round(row.repeat))) : 1;
		if (!gift) return null;
		return {
			id,
			ts,
			kind: "gift",
			user,
			gift,
			diamonds,
			repeat
		};
	}
	if (kind === "follow" || kind === "share" || kind === "join") return {
		id,
		ts,
		kind,
		user
	};
	if (kind === "like") return {
		id,
		ts,
		kind: "like",
		user,
		count: typeof row.count === "number" ? Math.max(1, Math.min(1e4, Math.round(row.count))) : 1,
		total: typeof row.total === "number" ? Math.max(0, Math.min(5e7, Math.round(row.total))) : void 0
	};
	return null;
}
function statusEvent(phase, message) {
	return {
		id: `st-${Date.now().toString(36)}`,
		ts: Date.now(),
		kind: "status",
		phase,
		message
	};
}
function rec(value) {
	return value && typeof value === "object" ? value : null;
}
function str(value) {
	return typeof value === "string" && value.trim() ? value.trim() : void 0;
}
function num(value) {
	if (typeof value === "bigint") return Number(value);
	if (typeof value === "number" && Number.isFinite(value)) return value;
	if (typeof value === "string" && value.trim() && Number.isFinite(Number(value))) return Number(value);
	const row = rec(value);
	if (row && typeof row.low === "number") return (typeof row.high === "number" ? row.high : 0) * 4294967296 + (row.low >>> 0);
}
function httpsUrl(value) {
	const direct = str(value);
	if (direct?.startsWith("https://")) return direct;
	const row = rec(value);
	const list = row?.url ?? row?.urls ?? row?.urlList;
	if (!Array.isArray(list)) return void 0;
	const found = list.find((item) => typeof item === "string" && item.startsWith("https://"));
	return typeof found === "string" ? found : void 0;
}
function roleOf(user) {
	if (user.isModerator === true) return "mod";
	const badges = user.badges ?? user.badgeList ?? user.userBadges;
	const text = JSON.stringify(badges ?? "").toLowerCase();
	if (text.includes("moderator") || text.includes("admin")) return "mod";
	if (text.includes("subscriber") || text.includes("superfan") || text.includes("super fan")) return "sub";
	const follow = num(rec(user.followInfo)?.followStatus ?? user.followStatus);
	if (follow && follow > 0) return "fan";
	return "viewer";
}
function personFrom(data) {
	const row = rec(data);
	const user = rec(row?.user) ?? row ?? {};
	const nick = (str(user.nickname) || str(user.nickName) || str(user.uniqueId) || "viewer").slice(0, 32);
	const name = (str(user.uniqueId) || str(user.displayId) || nick).replace(/[^\w.]/g, "").slice(0, 32) || "viewer";
	const avatar = httpsUrl(user.profilePictureUrl) || httpsUrl(user.avatarThumb) || httpsUrl(user.avatarMedium) || httpsUrl(user.profilePicture);
	return {
		name: name || "viewer",
		nick,
		role: roleOf(user),
		avatar
	};
}
function explain(error) {
	const name = error instanceof Error ? error.name : "";
	const message = error instanceof Error ? error.message : "No se pudo conectar.";
	if (name === "UserOfflineError" || /offline|not (be )?live|isn't live|is not live/i.test(message)) return "Esa cuenta no está en vivo ahora mismo.";
	if (/rate.?limit|429/i.test(message) || name === "SignatureRateLimitError") return "El servicio que firma la conexión está saturado. Prueba en un minuto o pega una clave de Euler Stream antes de conectar.";
	if (/room id|not found|couldn't find|does not exist/i.test(message)) return "No encontré un live con ese usuario. Revisa el @ o espera a que empiece a emitir.";
	if (/timeout|timed out|ENOTFOUND|ECONN|fetch failed|network/i.test(message)) return "No hubo respuesta de TikTok desde aquí. Revisa el usuario o inténtalo de nuevo.";
	return message.replace(/\s+/g, " ").slice(0, 180);
}
function chatText(row) {
	const direct = str(row.comment) || (typeof row.content === "string" ? str(row.content) : void 0);
	if (direct) return direct;
	const pieces = rec(rec(row.common)?.displayText)?.pieces;
	if (!Array.isArray(pieces)) return void 0;
	return pieces.map((piece) => {
		const item = rec(piece);
		return str(item?.stringValue) || str(item?.text) || "";
	}).join("").trim() || void 0;
}
function gid(prefix) {
	return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`;
}
async function connectTikTok(room, username, signApiKey) {
	room.mode = "live";
	room.username = username;
	publish(room, statusEvent("connecting", `Buscando el live de @${username}…`));
	await dropConnection();
	let connection;
	try {
		connection = new (await (import("../_libs/tiktok-live-connector.mjs").then((n) => n.t))).TikTokLiveConnection(username, {
			processInitialData: true,
			fetchRoomInfoOnConnect: false,
			enableExtendedGiftInfo: false,
			signApiKey: signApiKey || void 0
		});
	} catch (error) {
		room.mode = "demo";
		publish(room, statusEvent("error", explain(error)));
		return;
	}
	setActive(room.id, connection);
	let lastJoin = 0;
	let ready = false;
	connection.on("chat", (data) => {
		if (!isCurrent(room.id, connection)) return;
		const row = rec(data);
		const text = row ? chatText(row) : void 0;
		if (!text) return;
		const user = personFrom(data);
		const last = room.recent[room.recent.length - 1];
		if (last?.kind === "chat" && last.user.name === user.name && last.text === text) return;
		publish(room, {
			id: gid("c"),
			ts: Date.now(),
			kind: "chat",
			user,
			text: text.slice(0, 280)
		});
	});
	connection.on("gift", (data) => {
		if (!isCurrent(room.id, connection)) return;
		const row = rec(data) ?? {};
		const details = rec(row.giftDetails) ?? {};
		const extra = rec(row.extendedGiftInfo) ?? {};
		if ((num(details.giftType) ?? num(row.giftType) ?? 0) === 1 && row.repeatEnd !== true) return;
		const giftId = num(row.giftId);
		const gift = str(details.giftName) || str(details.name) || str(extra.name) || str(extra.giftName) || (giftId ? `Regalo ${giftId}` : "Regalo");
		const diamonds = num(details.diamondCount) ?? num(extra.diamondCount) ?? num(extra.diamond_count) ?? num(row.diamondCount) ?? 1;
		const repeat = Math.max(1, Math.round(num(row.repeatCount) ?? 1));
		publish(room, {
			id: gid("g"),
			ts: Date.now(),
			kind: "gift",
			user: personFrom(data),
			gift,
			diamonds: Math.max(0, Math.round(diamonds)),
			repeat
		});
	});
	connection.on("follow", (data) => {
		if (!isCurrent(room.id, connection)) return;
		publish(room, {
			id: gid("f"),
			ts: Date.now(),
			kind: "follow",
			user: personFrom(data)
		});
	});
	connection.on("share", (data) => {
		if (!isCurrent(room.id, connection)) return;
		publish(room, {
			id: gid("s"),
			ts: Date.now(),
			kind: "share",
			user: personFrom(data)
		});
	});
	connection.on("member", (data) => {
		if (!isCurrent(room.id, connection)) return;
		const now = Date.now();
		if (now - lastJoin < 2500) return;
		lastJoin = now;
		publish(room, {
			id: gid("j"),
			ts: now,
			kind: "join",
			user: personFrom(data)
		});
	});
	connection.on("like", (data) => {
		if (!isCurrent(room.id, connection)) return;
		const row = rec(data) ?? {};
		const count = Math.max(1, Math.round(num(row.likeCount) ?? 1));
		const total = num(row.totalLikeCount);
		publish(room, {
			id: gid("l"),
			ts: Date.now(),
			kind: "like",
			user: personFrom(data),
			count,
			total: total ? Math.round(total) : void 0
		});
	});
	connection.on("roomUser", (data) => {
		if (!isCurrent(room.id, connection)) return;
		const count = num(rec(data)?.viewerCount);
		if (count && count > 0) publish(room, {
			id: gid("v"),
			ts: Date.now(),
			kind: "viewers",
			count: Math.round(count)
		});
	});
	connection.on("streamEnd", () => {
		if (!isCurrent(room.id, connection)) return;
		publish(room, statusEvent("error", "El live terminó."));
		dropConnection(room.id);
	});
	connection.on("disconnected", () => {
		if (!isCurrent(room.id, connection)) return;
		publish(room, statusEvent("error", "Se cortó la conexión con el live."));
	});
	connection.on("error", (error) => {
		if (!ready || !isCurrent(room.id, connection)) return;
		publish(room, statusEvent("error", explain(rec(error)?.exception ?? error)));
	});
	try {
		const state = await Promise.race([connection.connect(), new Promise((_, reject) => {
			setTimeout(() => reject(/* @__PURE__ */ new Error("timeout")), 25e3);
		})]);
		if (!isCurrent(room.id, connection)) {
			await connection.disconnect();
			return;
		}
		ready = true;
		publish(room, statusEvent("live", `Leyendo el chat de @${username}${state.roomId ? ` · sala ${state.roomId}` : ""}.`));
	} catch (error) {
		if (isCurrent(room.id, connection)) {
			room.mode = "demo";
			publish(room, statusEvent("error", explain(error)));
			await dropConnection(room.id);
		}
	}
}
async function handlePost(request) {
	let body;
	try {
		body = await request.json();
	} catch {
		return Response.json({
			ok: false,
			error: "JSON inválido"
		}, { status: 400 });
	}
	const row = body && typeof body === "object" ? body : {};
	const room = ensureRoom(typeof row.roomId === "string" ? row.roomId : "");
	if (!room) return Response.json({
		ok: false,
		error: "Sala inválida"
	}, { status: 400 });
	const action = row.action;
	if (action === "prime") {
		if (!room.primed && room.mode !== "live") {
			for (const event of SEED) publish(room, event);
			room.primed = true;
		}
		return Response.json({
			ok: true,
			mode: room.mode
		});
	}
	if (action === "push") {
		if (room.mode === "live") return Response.json({
			ok: false,
			error: "En vivo"
		}, { status: 409 });
		const event = sanitizeEvent(row.event);
		if (!event) return Response.json({
			ok: false,
			error: "Evento inválido"
		}, { status: 400 });
		publish(room, event);
		return Response.json({ ok: true });
	}
	if (action === "inject") {
		publish(room, (row.kind === "chat" ? "chat" : "gift") === "chat" ? sampleChat() : sampleGift());
		return Response.json({ ok: true });
	}
	if (action === "stop") {
		await dropConnection(room.id);
		resetRoom(room);
		publish(room, statusEvent("demo", "Volviste a la sala demo."));
		return Response.json({ ok: true });
	}
	if (action === "start") {
		const username = normalizeUsername(typeof row.username === "string" ? row.username : "");
		if (!username) return Response.json({
			ok: false,
			error: "Usuario inválido"
		}, { status: 400 });
		const signApiKey = typeof row.signApiKey === "string" ? row.signApiKey.trim().slice(0, 200) : "";
		resetRoom(room);
		room.mode = "live";
		connectTikTok(room, username, signApiKey || void 0);
		return Response.json({ ok: true });
	}
	return Response.json({
		ok: false,
		error: "Acción desconocida"
	}, { status: 400 });
}
function handleGet(request) {
	const room = ensureRoom(new URL(request.url).searchParams.get("room") ?? "");
	if (!room) return Response.json({
		ok: false,
		error: "Sala inválida"
	}, { status: 400 });
	const encoder = new TextEncoder();
	let unsubscribe = () => {};
	const stream = new ReadableStream({
		start(controller) {
			const send = (event) => {
				try {
					controller.enqueue(encoder.encode(`data: ${JSON.stringify(event)}\n\n`));
				} catch {
					unsubscribe();
				}
			};
			unsubscribe = subscribe(room, send);
			const ping = setInterval(() => {
				try {
					controller.enqueue(encoder.encode(`: ping\n\n`));
				} catch {
					clearInterval(ping);
					unsubscribe();
				}
			}, 15e3);
			const close = () => {
				clearInterval(ping);
				unsubscribe();
				try {
					controller.close();
				} catch {}
			};
			request.signal.addEventListener("abort", close);
		},
		cancel() {
			unsubscribe();
		}
	});
	return new Response(stream, { headers: {
		"content-type": "text/event-stream; charset=utf-8",
		"cache-control": "no-cache, no-transform",
		connection: "keep-alive",
		"x-accel-buffering": "no"
	} });
}
//#endregion
export { handleGet, handlePost };
