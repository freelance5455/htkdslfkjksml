import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { A as FileCode, B as AlignLeft, C as Image, D as FileText, E as FolderOpen, F as ClipboardPaste, H as AlignCenter, I as Check, L as CalendarClock, M as Ellipsis, N as Download, O as FileStack, P as Copy, R as BookOpen, S as IndentDecrease, T as Highlighter, V as AlignRight, _ as List, a as Underline, b as Italic, c as Strikethrough, d as Scissors, f as Save, g as Palette, h as Printer, i as Undo2, j as Eye, k as FilePlus, l as Share2, m as Redo2, n as ZoomOut, o as Type, p as Rows3, r as X, t as ZoomIn, u as Search, v as ListOrdered, w as ImagePlus, x as IndentIncrease, y as Link2, z as Bold } from "../_libs/lucide-react.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as Drawer } from "../_libs/vaul.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Cz98g5NX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function escapeHtml(value) {
	return value.replace(/[&<>"']/g, (char) => `&#${char.charCodeAt(0)};`);
}
function safeFilename(name, ext) {
	return `${name.replace(/[^\w\s-]+/g, "").trim().replace(/\s+/g, "-").slice(0, 64) || "document"}.${ext}`;
}
function countText(html) {
	const text = html.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
	if (!text) return {
		words: 0,
		chars: 0
	};
	return {
		words: text.split(" ").length,
		chars: text.length
	};
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 font-sans font-medium select-none transition-[transform,background-color,color,opacity] duration-150 ease-out focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent disabled:pointer-events-none disabled:opacity-40 active:scale-[0.96]", {
	variants: {
		variant: {
			primary: "bg-accent text-accent-fg",
			chrome: "bg-chrome text-chrome-fg",
			outline: "bg-paper text-ink ring-1 ring-inset ring-line",
			ghost: "bg-transparent text-ink",
			danger: "bg-brick text-accent-fg"
		},
		size: {
			sm: "h-9 rounded-md px-3 text-sm",
			md: "h-11 rounded-lg px-4 text-sm",
			lg: "h-12 rounded-lg px-5 text-base",
			icon: "size-11 rounded-md"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, type = "button", ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
	ref,
	type,
	className: cn(buttonVariants({
		variant,
		size
	}), className),
	...props
}));
Button.displayName = "Button";
var DEFAULT_TITLE = "WordPad Features";
var DEFAULT_HTML = `<h1>WordPad Features</h1>
<p class="lede">A school-friendly map of every main WordPad command. Edit this page, then tap Convert to Link to share it as a URL.</p>
<h2>File</h2>
<ol>
<li><strong>New</strong> — Creates a new document.</li>
<li><strong>Open</strong> — Opens an existing document.</li>
<li><strong>Save</strong> — Saves the document.</li>
<li><strong>Save As</strong> — Saves the document with a new name or location.</li>
<li><strong>Print</strong> — Prints the document.</li>
<li><strong>Print Preview</strong> — Shows how the document will look when printed.</li>
</ol>
<h2>Clipboard and editing</h2>
<ol start="7">
<li><strong>Cut</strong> — Removes selected text and places it on the clipboard.</li>
<li><strong>Copy</strong> — Copies selected text to the clipboard.</li>
<li><strong>Paste</strong> — Inserts copied or cut text.</li>
<li><strong>Undo</strong> — Reverses the last action.</li>
<li><strong>Redo</strong> — Restores an action that was undone.</li>
</ol>
<h2>Font and paragraph</h2>
<ol start="12">
<li><strong>Font</strong> — Changes the typeface of text.</li>
<li><strong>Font Size</strong> — Changes the size of text.</li>
<li><strong>Bold</strong> — Makes text darker and thicker.</li>
<li><strong>Italic</strong> — Slants the text.</li>
<li><strong>Underline</strong> — Places a line below text.</li>
<li><strong>Text Color</strong> — Changes the color of text.</li>
<li><strong>Text Highlighting</strong> — Highlights text.</li>
<li><strong>Text Alignment</strong> — Aligns text to the left, center, or right.</li>
<li><strong>Bullets</strong> — Creates a bulleted list.</li>
<li><strong>Line Spacing</strong> — Adjusts the space between lines.</li>
</ol>
<h2>Insert and view</h2>
<ol start="22">
<li><strong>Insert Picture</strong> — Adds a picture to the document.</li>
<li><strong>Insert Date and Time</strong> — Inserts the current date and/or time.</li>
<li><strong>Find</strong> — Searches for specific words or text.</li>
<li><strong>Page Setup</strong> — Sets paper size, margins, and page orientation.</li>
<li><strong>Zoom</strong> — Makes the document appear larger or smaller on screen.</li>
</ol>
<h2>File formats</h2>
<ul>
<li><strong>RTF</strong> — Rich Text Format</li>
<li><strong>TXT</strong> — Plain text</li>
<li><strong>DOCX</strong> — Word document (on some versions)</li>
<li><strong>ODT</strong> — OpenDocument Text (on some versions)</li>
</ul>
<p>Microsoft removed WordPad from Windows 11 version 24H2 and later, so newer Windows installations may not have it. PadLink keeps the same tools in the browser — including PNG, PDF, and a shareable link.</p>
<h2>Parts of the window</h2>
<ul>
<li><strong>Title bar</strong> — Shows the document name.</li>
<li><strong>Quick Access toolbar</strong> — New, Open, Save, Undo, Redo.</li>
<li><strong>Ribbon</strong> — Home and View commands.</li>
<li><strong>Home tab</strong> — Clipboard, font, paragraph, and insert tools.</li>
<li><strong>View tab</strong> — Zoom, word wrap, and ruler.</li>
<li><strong>Ruler</strong> — Margins and indents.</li>
<li><strong>Document area</strong> — Where you type.</li>
<li><strong>Status bar</strong> — Zoom and document info.</li>
</ul>`;
var WINDOW_PARTS = [
	{
		name: "Title bar",
		role: "Shows the document name and window controls."
	},
	{
		name: "Quick Access",
		role: "New, Open, Save, Undo, and Redo sit here for one-tap use."
	},
	{
		name: "Ribbon",
		role: "The command strip. Home holds writing tools; View holds zoom."
	},
	{
		name: "Home tab",
		role: "Clipboard, font, paragraph, and insert groups."
	},
	{
		name: "View tab",
		role: "Zoom, word wrap, and ruler."
	},
	{
		name: "Ruler",
		role: "Sets left and right margins on the page."
	},
	{
		name: "Document area",
		role: "The page where you type, format, and drop pictures."
	},
	{
		name: "Status bar",
		role: "Word count, save state, and zoom."
	}
];
var FONTS = [
	"Source Serif 4",
	"Georgia",
	"Times New Roman",
	"Instrument Sans",
	"Arial",
	"Calibri",
	"Verdana",
	"Courier New"
];
var FONT_SIZES = [
	"12",
	"14",
	"16",
	"18",
	"20",
	"24",
	"32",
	"40"
];
var INK_COLORS = [
	{
		name: "Ink",
		value: "#1c1917"
	},
	{
		name: "Navy",
		value: "#1e3a5f"
	},
	{
		name: "Forest",
		value: "#2f5d4e"
	},
	{
		name: "Brick",
		value: "#9b3d32"
	},
	{
		name: "Sepia",
		value: "#5c4d3c"
	},
	{
		name: "Cream",
		value: "#faf8f5"
	}
];
var HIGHLIGHTS = [
	{
		name: "Sage",
		value: "#dce8e2"
	},
	{
		name: "Sky",
		value: "#d4e0ea"
	},
	{
		name: "Rose",
		value: "#edd8d6"
	},
	{
		name: "Sand",
		value: "#efe6d2"
	},
	{
		name: "Linen",
		value: "#e7e0d4"
	},
	{
		name: "Clear",
		value: "transparent"
	}
];
var SPACING = [
	{
		name: "1.0",
		value: "1.15"
	},
	{
		name: "1.15",
		value: "1.3"
	},
	{
		name: "1.5",
		value: "1.5"
	},
	{
		name: "2.0",
		value: "2"
	}
];
function ToolBtn({ label, active, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-label": label,
		title: label,
		"aria-pressed": active,
		onMouseDown: (event) => event.preventDefault(),
		onClick,
		className: cn("inline-flex size-11 shrink-0 items-center justify-center rounded-md text-ink/80 transition-[background-color,color,transform] duration-150 ease-out active:scale-[0.96]", active ? "bg-accent/12 text-accent" : "hover:bg-ink/6"),
		children
	});
}
function SlideRow({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "slide-row flex gap-0.5 overflow-x-auto overscroll-x-contain px-2 pb-1",
		children
	});
}
function FormatToolbar({ flags, tray, zoom, onTray, onExec, onFont, onSize, onColor, onHighlight, onSpacing, onPicture, onDate, onFind, onZoomIn, onZoomOut, onZoomSet, onPageSetup, onPrint, onPrintPreview }) {
	const toggle = (next) => onTray(tray === next ? null : next);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border-b border-line bg-surface",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SlideRow, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolBtn, {
					label: "Bold",
					active: flags.bold,
					onClick: () => onExec("bold"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bold, {
						className: "size-4",
						strokeWidth: 2.25
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolBtn, {
					label: "Italic",
					active: flags.italic,
					onClick: () => onExec("italic"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Italic, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolBtn, {
					label: "Underline",
					active: flags.underline,
					onClick: () => onExec("underline"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Underline, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolBtn, {
					label: "Strikethrough",
					onClick: () => onExec("strikeThrough"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Strikethrough, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mx-1 my-3 w-px shrink-0 bg-line" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolBtn, {
					label: "Font",
					active: tray === "font",
					onClick: () => toggle("font"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Type, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolBtn, {
					label: "Font size",
					active: tray === "size",
					onClick: () => toggle("size"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-sans text-xs font-semibold",
						children: "Tt"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolBtn, {
					label: "Text color",
					active: tray === "color",
					onClick: () => toggle("color"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Palette, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolBtn, {
					label: "Highlight",
					active: tray === "highlight",
					onClick: () => toggle("highlight"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Highlighter, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mx-1 my-3 w-px shrink-0 bg-line" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolBtn, {
					label: "Align left",
					onClick: () => onExec("justifyLeft"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlignLeft, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolBtn, {
					label: "Align center",
					onClick: () => onExec("justifyCenter"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlignCenter, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolBtn, {
					label: "Align right",
					onClick: () => onExec("justifyRight"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlignRight, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolBtn, {
					label: "Bullets",
					onClick: () => onExec("insertUnorderedList"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolBtn, {
					label: "Numbered list",
					onClick: () => onExec("insertOrderedList"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListOrdered, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolBtn, {
					label: "Line spacing",
					active: tray === "spacing",
					onClick: () => toggle("spacing"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rows3, { className: "size-4" })
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SlideRow, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolBtn, {
					label: "Insert picture",
					onClick: onPicture,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolBtn, {
					label: "Insert date and time",
					onClick: onDate,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarClock, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolBtn, {
					label: "Find",
					onClick: onFind,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolBtn, {
					label: "Zoom out",
					onClick: onZoomOut,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZoomOut, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolBtn, {
					label: "Zoom in",
					onClick: onZoomIn,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZoomIn, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolBtn, {
					label: "Zoom",
					active: tray === "zoom",
					onClick: () => toggle("zoom"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-sans text-xs font-semibold tabular-nums",
						children: [zoom, "%"]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolBtn, {
					label: "Page setup",
					onClick: onPageSetup,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileStack, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolBtn, {
					label: "Print",
					onClick: onPrint,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolBtn, {
					label: "Print preview",
					onClick: onPrintPreview,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mx-1 my-3 w-px shrink-0 bg-line" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolBtn, {
					label: "Cut",
					onClick: () => onExec("cut"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scissors, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolBtn, {
					label: "Copy",
					onClick: () => onExec("copy"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolBtn, {
					label: "Paste",
					onClick: () => onExec("paste"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardPaste, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolBtn, {
					label: "Increase indent",
					onClick: () => onExec("indent"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IndentIncrease, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolBtn, {
					label: "Decrease indent",
					onClick: () => onExec("outdent"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IndentDecrease, { className: "size-4" })
				})
			] }),
			tray ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2 overflow-x-auto border-t border-line px-3 py-2",
				children: [
					tray === "font" ? FONTS.map((font) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
						onClick: () => onFont(font),
						style: { fontFamily: font },
						children: font
					}, font)) : null,
					tray === "size" ? FONT_SIZES.map((size) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
						onClick: () => onSize(size),
						children: size
					}, size)) : null,
					tray === "color" ? INK_COLORS.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Swatch, {
						label: c.name,
						color: c.value,
						onClick: () => onColor(c.value)
					}, c.name)) : null,
					tray === "highlight" ? HIGHLIGHTS.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Swatch, {
						label: c.name,
						color: c.value === "transparent" ? "#fffdf8" : c.value,
						onClick: () => onHighlight(c.value)
					}, c.name)) : null,
					tray === "spacing" ? SPACING.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
						onClick: () => onSpacing(s.value),
						children: s.name
					}, s.name)) : null,
					tray === "zoom" ? [
						75,
						100,
						125,
						150,
						200
					].map((z) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Chip, {
						onClick: () => onZoomSet(z),
						children: [z, "%"]
					}, z)) : null
				]
			}) : null
		]
	});
}
function Chip({ onClick, children, style }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onMouseDown: (event) => event.preventDefault(),
		onClick,
		style,
		className: "h-9 shrink-0 rounded-md bg-paper px-3 font-sans text-sm text-ink ring-1 ring-inset ring-line transition-transform duration-150 active:scale-[0.96]",
		children
	});
}
function Swatch({ label, color, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		"aria-label": label,
		title: label,
		onMouseDown: (event) => event.preventDefault(),
		onClick,
		className: "flex h-9 shrink-0 items-center gap-2 rounded-md bg-paper px-2 ring-1 ring-inset ring-line transition-transform duration-150 active:scale-[0.96]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "size-4 rounded-sm ring-1 ring-inset ring-ink/15",
			style: { background: color }
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-sans text-xs text-ink",
			children: label
		})]
	});
}
function Ruler({ marginPx }) {
	const ticks = Array.from({ length: 13 }, (_, i) => i);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative h-7 border-b border-line bg-surface",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute inset-y-0 bg-accent/10",
				style: {
					left: 0,
					width: marginPx
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute inset-y-0 bg-accent/10",
				style: {
					right: 0,
					width: marginPx
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex h-full items-end px-1",
				children: ticks.map((tick) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "absolute bottom-1 left-0 font-mono text-xs text-muted",
						children: tick
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute bottom-0 left-0 h-2 w-px bg-line" })]
				}, tick))
			})
		]
	});
}
function BottomSheet({ open, onOpenChange, title, description, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Drawer.Root, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Drawer.Portal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Drawer.Overlay, { className: "fixed inset-0 z-50 bg-ink/40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Drawer.Content, {
			className: "fixed inset-x-0 bottom-0 z-50 flex max-h-[88dvh] flex-col rounded-t-xl bg-surface outline-none",
			"aria-describedby": description ? void 0 : void 0,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mt-3 h-1 w-10 rounded-full bg-line" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Drawer.Title, {
					className: "px-5 pt-4 font-sans text-lg font-semibold tracking-tight text-ink",
					children: title
				}),
				description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Drawer.Description, {
					className: "px-5 pt-1 text-sm text-muted",
					children: description
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Drawer.Description, {
					className: "sr-only",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "sheet-bottom overflow-y-auto px-5 pt-4",
					children
				})
			]
		})] })
	});
}
function DownloadSheet({ open, onOpenChange, busy, onPick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BottomSheet, {
		open,
		onOpenChange,
		title: "Download",
		description: "Save this page as PNG, PDF, or text.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-col gap-2",
			children: [
				{
					id: "pdf",
					title: "PDF",
					hint: "Print-ready pages for school or sharing",
					icon: FileText
				},
				{
					id: "png",
					title: "PNG",
					hint: "A full-page image of the document",
					icon: Image
				},
				{
					id: "txt",
					title: "Plain text",
					hint: "TXT without formatting",
					icon: Download
				},
				{
					id: "html",
					title: "HTML",
					hint: "Keeps headings, lists, and colors",
					icon: FileCode
				}
			].map((opt) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				disabled: busy !== null,
				onClick: () => onPick(opt.id),
				className: "flex min-h-14 items-center gap-3 rounded-lg bg-paper px-3 py-3 text-left ring-1 ring-inset ring-line transition-transform duration-150 active:scale-[0.96] disabled:opacity-50",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "flex size-11 items-center justify-center rounded-md bg-accent/10 text-accent",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(opt.icon, {
							className: "size-5",
							strokeWidth: 1.75
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-sans text-sm font-medium text-ink",
							children: opt.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-sm text-muted",
							children: opt.hint
						})]
					}),
					busy === opt.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs font-medium text-accent",
						children: "Saving…"
					}) : null
				]
			}, opt.id))
		})
	});
}
function LinkSheet({ open, onOpenChange, url, copied, onCopy, onShare, canShare }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BottomSheet, {
		open,
		onOpenChange,
		title: "Convert to link",
		description: "Anyone with this URL opens the same document.",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-lg bg-paper px-3 py-3 ring-1 ring-inset ring-line",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "break-all font-mono text-xs leading-relaxed text-ink/80",
					children: url || "Preparing link…"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-col gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					className: "w-full",
					onClick: onCopy,
					disabled: !url,
					children: [copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" }), copied ? "Copied" : "Copy link"]
				}), canShare ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					className: "w-full",
					onClick: onShare,
					disabled: !url,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "size-4" }), "Share"]
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 flex items-start gap-2 text-sm text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link2, { className: "mt-0.5 size-4 shrink-0 text-accent" }), "The link stores this page in the URL. No account needed."]
			})
		]
	});
}
function LearnSheet({ open, onOpenChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BottomSheet, {
		open,
		onOpenChange,
		title: "WordPad window",
		description: "Names and jobs of each part — plus how PadLink maps them.",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "overflow-hidden rounded-lg bg-paper ring-1 ring-inset ring-line",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "bg-chrome px-3 py-2 text-center font-sans text-xs font-medium text-chrome-fg",
					children: "Title bar"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-1 bg-chrome/90 px-2 py-1.5",
					children: [[
						"New",
						"Open",
						"Save"
					].map((label) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-sm bg-chrome-fg/10 px-2 py-1 font-sans text-xs text-chrome-fg",
						children: label
					}, label)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "ml-auto font-sans text-xs text-chrome-fg/70",
						children: "Quick Access"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-3 border-b border-line bg-surface px-3 py-2 font-sans text-xs",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold text-accent",
							children: "Home"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted",
							children: "View"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-auto text-muted",
							children: "Ribbon"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "border-b border-line bg-surface px-3 py-1.5 font-mono text-xs text-muted",
					children: "0 ——— ruler ——— 6 in"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex h-20 items-center justify-center bg-paper font-sans text-xs text-muted",
					children: "Document area"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-between bg-surface px-3 py-1.5 font-sans text-xs text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Status bar" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Zoom" })]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-4 flex flex-col gap-3",
			children: WINDOW_PARTS.map((part) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex flex-col gap-0.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-sans text-sm font-medium text-ink",
					children: part.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm text-muted",
					children: part.role
				})]
			}, part.name))
		})]
	});
}
function PageSetupSheet({ open, onOpenChange, orientation, margin, size, onOrientation, onMargin, onSize }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BottomSheet, {
		open,
		onOpenChange,
		title: "Page setup",
		description: "Paper size, orientation, and margins.",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Orientation",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Seg, {
					value: orientation,
					onChange: onOrientation,
					options: [{
						id: "portrait",
						label: "Portrait"
					}, {
						id: "landscape",
						label: "Landscape"
					}]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Paper",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Seg, {
					value: size,
					onChange: onSize,
					options: [{
						id: "a4",
						label: "A4"
					}, {
						id: "letter",
						label: "Letter"
					}]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Margins",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Seg, {
					value: margin,
					onChange: onMargin,
					options: [
						{
							id: "narrow",
							label: "Narrow"
						},
						{
							id: "normal",
							label: "Normal"
						},
						{
							id: "wide",
							label: "Wide"
						}
					]
				})
			})
		]
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-2 font-sans text-xs font-medium uppercase tracking-wider text-muted",
			children: label
		}), children]
	});
}
function Seg({ value, onChange, options }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("grid gap-2 rounded-lg bg-paper p-1 ring-1 ring-inset ring-line", options.length > 2 ? "grid-cols-3" : "grid-cols-2"),
		children: options.map((opt) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: () => onChange(opt.id),
			className: cn("h-11 rounded-md font-sans text-sm font-medium transition-colors duration-150", value === opt.id ? "bg-accent text-accent-fg" : "text-ink"),
			children: opt.label
		}, opt.id))
	});
}
function bytesToB64url(bytes) {
	let bin = "";
	for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
	return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}
function b64urlToBytes(token) {
	const b64 = (token + "=".repeat((4 - token.length % 4) % 4)).replace(/-/g, "+").replace(/_/g, "/");
	const bin = atob(b64);
	const out = new Uint8Array(bin.length);
	for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
	return out;
}
async function gzipB64(text) {
	const bytes = new TextEncoder().encode(text);
	const stream = new Blob([bytes]).stream().pipeThrough(new CompressionStream("gzip"));
	const buf = await new Response(stream).arrayBuffer();
	return bytesToB64url(new Uint8Array(buf));
}
async function gunzipB64(token) {
	const bytes = b64urlToBytes(token);
	const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream("gzip"));
	const buf = await new Response(stream).arrayBuffer();
	return new TextDecoder().decode(buf);
}
async function encodePad(doc) {
	const json = JSON.stringify(doc);
	try {
		if (typeof CompressionStream !== "undefined") return `p1.${await gzipB64(json)}`;
	} catch {}
	return `r1.${encodeURIComponent(json)}`;
}
async function decodePad(token) {
	try {
		if (token.startsWith("p1.")) {
			const json = await gunzipB64(token.slice(3));
			return JSON.parse(json);
		}
		if (token.startsWith("r1.")) return JSON.parse(decodeURIComponent(token.slice(3)));
	} catch {
		return null;
	}
	return null;
}
function readTokenFromLocation() {
	const hash = window.location.hash.replace(/^#/, "");
	if (hash.startsWith("d=")) return decodeURIComponent(hash.slice(2));
	const fromHash = new URLSearchParams(hash).get("d");
	if (fromHash) return fromHash;
	return new URLSearchParams(window.location.search).get("d");
}
function buildShareUrl(token) {
	const url = new URL(window.location.href);
	url.search = "";
	url.hash = `d=${token}`;
	return url.toString();
}
var STORAGE_KEY = "padlink:doc";
function saveLocal(doc) {
	try {
		localStorage.setItem(STORAGE_KEY, JSON.stringify(doc));
	} catch {}
}
function loadLocal() {
	try {
		const raw = localStorage.getItem(STORAGE_KEY);
		if (!raw) return null;
		const parsed = JSON.parse(raw);
		if (parsed && parsed.v === 1 && typeof parsed.h === "string") return parsed;
	} catch {
		return null;
	}
	return null;
}
var PAPER = "#fffdf8";
function concatBytes(chunks) {
	const total = chunks.reduce((n, c) => n + c.length, 0);
	const out = new Uint8Array(total);
	let offset = 0;
	for (const chunk of chunks) {
		out.set(chunk, offset);
		offset += chunk.length;
	}
	return out;
}
function downloadBlob(blob, filename) {
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = filename;
	document.body.appendChild(a);
	a.click();
	a.remove();
	setTimeout(() => URL.revokeObjectURL(url), 1500);
}
function canvasToJpeg(canvas, quality = .84) {
	return new Promise((resolve, reject) => {
		canvas.toBlob(async (blob) => {
			if (!blob) {
				reject(/* @__PURE__ */ new Error("Could not encode image"));
				return;
			}
			resolve(new Uint8Array(await blob.arrayBuffer()));
		}, "image/jpeg", quality);
	});
}
function sliceCanvas(source, pageHeight) {
	const pages = [];
	const width = source.width;
	let y = 0;
	while (y < source.height) {
		const height = Math.min(pageHeight, source.height - y);
		const slice = document.createElement("canvas");
		slice.width = width;
		slice.height = height;
		const ctx = slice.getContext("2d");
		if (!ctx) break;
		ctx.fillStyle = PAPER;
		ctx.fillRect(0, 0, width, height);
		ctx.drawImage(source, 0, y, width, height, 0, 0, width, height);
		pages.push(slice);
		y += height;
	}
	return pages.length ? pages : [source];
}
function jpegPagesToPdf(pages) {
	const enc = new TextEncoder();
	const nl = (s) => enc.encode(s);
	const makeObj = (n, content) => concatBytes([
		nl(`${n} 0 obj\n`),
		content,
		nl("\nendobj\n")
	]);
	const a4w = 595.28;
	const a4h = 841.89;
	const kids = pages.map((_, i) => `${3 + i * 3} 0 R`).join(" ");
	const objs = [makeObj(1, nl("<< /Type /Catalog /Pages 2 0 R >>")), makeObj(2, nl(`<< /Type /Pages /Count ${pages.length} /Kids [${kids}] >>`))];
	pages.forEach((page, i) => {
		const pageNo = 3 + i * 3;
		const imgNo = pageNo + 1;
		const contentNo = pageNo + 2;
		const landscape = page.w > page.h * 1.05;
		const pw = landscape ? a4h : a4w;
		const ph = landscape ? a4w : a4h;
		const scale = Math.min(pw / page.w, ph / page.h);
		const dw = page.w * scale;
		const dh = page.h * scale;
		const ox = (pw - dw) / 2;
		const oy = (ph - dh) / 2;
		const stream = `q\n${dw.toFixed(2)} 0 0 ${dh.toFixed(2)} ${ox.toFixed(2)} ${oy.toFixed(2)} cm\n/Im0 Do\nQ\n`;
		const streamBytes = nl(stream);
		objs.push(makeObj(pageNo, nl(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${pw} ${ph}] /Resources << /XObject << /Im0 ${imgNo} 0 R >> >> /Contents ${contentNo} 0 R >>`)));
		objs.push(makeObj(imgNo, concatBytes([
			nl(`<< /Type /XObject /Subtype /Image /Width ${page.w} /Height ${page.h} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${page.jpeg.length} >>\nstream\n`),
			page.jpeg,
			nl("\nendstream")
		])));
		objs.push(makeObj(contentNo, nl(`<< /Length ${streamBytes.length} >>\nstream\n${stream}endstream`)));
	});
	const header = nl("%PDF-1.4\n%\n");
	let offset = header.length;
	const xrefOffsets = [0];
	const body = [header];
	for (const obj of objs) {
		xrefOffsets.push(offset);
		body.push(obj);
		offset += obj.length;
	}
	const xrefStart = offset;
	const pad = (n) => String(n).padStart(10, "0");
	let xref = `xref\n0 ${objs.length + 1}\n0000000000 65535 f \n`;
	for (let i = 1; i <= objs.length; i++) xref += `${pad(xrefOffsets[i])} 00000 n \n`;
	const trailer = `trailer\n<< /Size ${objs.length + 1} /Root 1 0 R >>\nstartxref\n${xrefStart}\n%%EOF\n`;
	body.push(nl(xref + trailer));
	return concatBytes(body);
}
async function capturePaper(el) {
	const { default: html2canvas } = await import("../_libs/html2canvas.mjs").then((n) => n.t);
	return html2canvas(el, {
		scale: 2,
		backgroundColor: PAPER,
		useCORS: true,
		logging: false,
		onclone(doc) {
			doc.querySelectorAll("mark.pad-find").forEach((mark) => {
				const span = doc.createElement("span");
				span.innerHTML = mark.innerHTML;
				mark.replaceWith(span);
			});
		}
	});
}
async function downloadPng(el, title) {
	const canvas = await capturePaper(el);
	await new Promise((resolve, reject) => {
		canvas.toBlob((blob) => {
			if (!blob) {
				reject(/* @__PURE__ */ new Error("Could not build PNG"));
				return;
			}
			downloadBlob(blob, safeFilename(title, "png"));
			resolve();
		}, "image/png");
	});
}
async function downloadPdf(el, title) {
	const canvas = await capturePaper(el);
	const slices = sliceCanvas(canvas, Math.round(canvas.width * (841.89 / 595.28)));
	const pages = [];
	for (const slice of slices) pages.push({
		jpeg: await canvasToJpeg(slice),
		w: slice.width,
		h: slice.height
	});
	const pdf = jpegPagesToPdf(pages);
	downloadBlob(new Blob([pdf], { type: "application/pdf" }), safeFilename(title, "pdf"));
}
function downloadTxt(html, title) {
	const text = html.replace(/<br\s*\/?>/gi, "\n").replace(/<\/p>/gi, "\n\n").replace(/<\/h[1-6]>/gi, "\n\n").replace(/<\/li>/gi, "\n").replace(/<[^>]+>/g, "").replace(/&nbsp;/g, " ").replace(/&/g, "&").replace(/</g, "<").replace(/>/g, ">").replace(/\n{3,}/g, "\n\n").trim();
	downloadBlob(new Blob([text], { type: "text/plain;charset=utf-8" }), safeFilename(title, "txt"));
}
function downloadHtml(html, title) {
	const doc = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>${title.replace(/</g, "")}</title>
<style>
  body { margin: 0; background: #e7e0d4; color: #1c1917; font: 16px/1.65 "Source Serif 4", Georgia, serif; }
  main { max-width: 42rem; margin: 2rem auto; background: #fffdf8; padding: 2rem 1.5rem; }
  h1,h2 { font-family: "Instrument Sans", system-ui, sans-serif; }
</style>
</head>
<body>
<main>
${html}
</main>
</body>
</html>`;
	downloadBlob(new Blob([doc], { type: "text/html;charset=utf-8" }), safeFilename(title, "html"));
}
var MARGIN = {
	narrow: 16,
	normal: 28,
	wide: 44
};
function PadApp() {
	const editorRef = (0, import_react.useRef)(null);
	const paperRef = (0, import_react.useRef)(null);
	const fileRef = (0, import_react.useRef)(null);
	const rangeRef = (0, import_react.useRef)(null);
	const [title, setTitle] = (0, import_react.useState)(DEFAULT_TITLE);
	const [docKey, setDocKey] = (0, import_react.useState)(0);
	const [startHtml, setStartHtml] = (0, import_react.useState)(DEFAULT_HTML);
	const [dirty, setDirty] = (0, import_react.useState)(false);
	const [saved, setSaved] = (0, import_react.useState)(true);
	const [zoom, setZoom] = (0, import_react.useState)(100);
	const [tray, setTray] = (0, import_react.useState)(null);
	const [flags, setFlags] = (0, import_react.useState)({
		bold: false,
		italic: false,
		underline: false
	});
	const [findOpen, setFindOpen] = (0, import_react.useState)(false);
	const [findQuery, setFindQuery] = (0, import_react.useState)("");
	const [findCount, setFindCount] = (0, import_react.useState)(0);
	const [downloadOpen, setDownloadOpen] = (0, import_react.useState)(false);
	const [linkOpen, setLinkOpen] = (0, import_react.useState)(false);
	const [learnOpen, setLearnOpen] = (0, import_react.useState)(false);
	const [pageOpen, setPageOpen] = (0, import_react.useState)(false);
	const [previewOpen, setPreviewOpen] = (0, import_react.useState)(false);
	const [fileOpen, setFileOpen] = (0, import_react.useState)(false);
	const [shareUrl, setShareUrl] = (0, import_react.useState)("");
	const [copied, setCopied] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(null);
	const [fromLink, setFromLink] = (0, import_react.useState)(false);
	const [showTip, setShowTip] = (0, import_react.useState)(true);
	const [canShare, setCanShare] = (0, import_react.useState)(false);
	const [htmlTick, setHtmlTick] = (0, import_react.useState)(0);
	const [page, setPage] = (0, import_react.useState)({
		size: "a4",
		orientation: "portrait",
		margin: "normal"
	});
	const currentHtml = () => editorRef.current?.innerHTML ?? startHtml;
	const stats = (0, import_react.useMemo)(() => countText(editorRef.current?.innerHTML ?? startHtml), [
		htmlTick,
		startHtml,
		docKey
	]);
	const restore = (0, import_react.useCallback)(() => {
		const range = rangeRef.current;
		const editor = editorRef.current;
		if (!range || !editor) return;
		const selection = window.getSelection();
		if (!selection) return;
		selection.removeAllRanges();
		selection.addRange(range);
		editor.focus();
	}, []);
	const exec = (0, import_react.useCallback)((cmd, value) => {
		restore();
		if (cmd === "paste") {
			(async () => {
				try {
					const text = await navigator.clipboard.readText();
					document.execCommand("insertText", false, text);
					setDirty(true);
					setSaved(false);
					setHtmlTick((n) => n + 1);
				} catch {
					toast("Use a long-press or Ctrl+V to paste");
				}
			})();
			return;
		}
		document.execCommand("styleWithCSS", false, "true");
		document.execCommand(cmd, false, value);
		setDirty(true);
		setSaved(false);
		setHtmlTick((n) => n + 1);
	}, [restore]);
	const applyFontSize = (px) => {
		restore();
		document.execCommand("styleWithCSS", false, "true");
		document.execCommand("fontSize", false, "7");
		editorRef.current?.querySelectorAll("font[size=\"7\"], span[style*=\"font-size: xxx-large\"]").forEach((node) => {
			const el = node;
			el.removeAttribute("size");
			el.style.fontSize = `${px}px`;
		});
		setDirty(true);
		setSaved(false);
	};
	const applySpacing = (value) => {
		restore();
		const selection = window.getSelection();
		if (!selection || selection.rangeCount === 0) return;
		let node = selection.anchorNode;
		if (node && node.nodeType === Node.TEXT_NODE) node = node.parentElement;
		const block = node?.closest("p, li, h1, h2, h3, div");
		if (block instanceof HTMLElement) block.style.lineHeight = value;
		setDirty(true);
		setSaved(false);
	};
	const insertDate = () => {
		restore();
		const formatted = new Intl.DateTimeFormat(void 0, {
			dateStyle: "medium",
			timeStyle: "short"
		}).format(/* @__PURE__ */ new Date());
		document.execCommand("insertText", false, formatted);
		setDirty(true);
		setSaved(false);
	};
	const insertPicture = () => {
		const input = document.createElement("input");
		input.type = "file";
		input.accept = "image/*";
		input.onchange = () => {
			const file = input.files?.[0];
			if (!file) return;
			const reader = new FileReader();
			reader.onload = () => {
				restore();
				const src = String(reader.result ?? "");
				document.execCommand("insertHTML", false, `<img src="${src}" alt="" />`);
				setDirty(true);
				setSaved(false);
				setHtmlTick((n) => n + 1);
			};
			reader.readAsDataURL(file);
		};
		input.click();
	};
	const loadDoc = (doc, asLink = false) => {
		setTitle(doc.t || "WordPad Features");
		setStartHtml(doc.h || "<p></p>");
		setDocKey((k) => k + 1);
		setDirty(false);
		setSaved(true);
		setFromLink(asLink);
		setFindOpen(false);
		setTray(null);
	};
	(0, import_react.useEffect)(() => {
		setCanShare(typeof navigator !== "undefined" && typeof navigator.share === "function");
		let cancelled = false;
		(async () => {
			const token = readTokenFromLocation();
			if (token) {
				const doc = await decodePad(token);
				if (doc && !cancelled) {
					loadDoc(doc, true);
					setShowTip(false);
					return;
				}
			}
			const local = loadLocal();
			if (local && !cancelled) loadDoc(local);
		})();
		return () => {
			cancelled = true;
		};
	}, []);
	(0, import_react.useEffect)(() => {
		const onSel = () => {
			const selection = window.getSelection();
			if (!selection || selection.rangeCount === 0) return;
			if (!editorRef.current?.contains(selection.anchorNode)) return;
			rangeRef.current = selection.getRangeAt(0).cloneRange();
			try {
				setFlags({
					bold: document.queryCommandState("bold"),
					italic: document.queryCommandState("italic"),
					underline: document.queryCommandState("underline")
				});
			} catch {}
		};
		document.addEventListener("selectionchange", onSel);
		return () => document.removeEventListener("selectionchange", onSel);
	}, []);
	(0, import_react.useEffect)(() => {
		const id = window.setTimeout(() => {
			saveLocal({
				v: 1,
				t: title,
				h: currentHtml()
			});
			setSaved(true);
		}, 700);
		return () => window.clearTimeout(id);
	}, [
		title,
		htmlTick,
		docKey
	]);
	const clearFindMarks = () => {
		const root = editorRef.current;
		if (!root) return;
		root.querySelectorAll("mark.pad-find").forEach((mark) => {
			const text = document.createTextNode(mark.textContent ?? "");
			mark.replaceWith(text);
		});
		root.normalize();
	};
	const runFind = (query) => {
		clearFindMarks();
		const root = editorRef.current;
		if (!root || !query.trim()) {
			setFindCount(0);
			return;
		}
		const needle = query.trim();
		const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
		const hits = [];
		while (walker.nextNode()) {
			const node = walker.currentNode;
			const lower = node.data.toLowerCase();
			const q = needle.toLowerCase();
			let idx = lower.indexOf(q);
			while (idx !== -1) {
				hits.push({
					node,
					start: idx
				});
				idx = lower.indexOf(q, idx + q.length);
			}
		}
		for (let i = hits.length - 1; i >= 0; i--) {
			const hit = hits[i];
			if (hit.start + needle.length > hit.node.data.length) continue;
			const range = document.createRange();
			range.setStart(hit.node, hit.start);
			range.setEnd(hit.node, hit.start + needle.length);
			const mark = document.createElement("mark");
			mark.className = "pad-find";
			range.surroundContents(mark);
		}
		setFindCount(hits.length);
		root.querySelector("mark.pad-find")?.scrollIntoView({
			block: "center",
			behavior: "smooth"
		});
	};
	const confirmNew = () => {
		if (dirty && !window.confirm("Start a new document? Unsaved edits stay on this device until you convert to a link or download.")) return;
		loadDoc({
			v: 1,
			t: "Untitled",
			h: "<p><br></p>"
		});
		setDirty(false);
		toast("New document");
	};
	const saveFile = (asNew = false) => {
		let name = title;
		if (asNew) {
			const next = window.prompt("Save as", title);
			if (!next) return;
			name = next;
			setTitle(next);
		}
		downloadHtml(currentHtml(), name);
		setSaved(true);
		setDirty(false);
		toast("Saved HTML file");
	};
	const openFile = async (file) => {
		const raw = await file.text();
		let html = raw;
		const lower = file.name.toLowerCase();
		if (lower.endsWith(".txt") || file.type === "text/plain") html = `<p>${escapeHtml(raw).replace(/\n\n/g, "</p><p>").replace(/\n/g, "<br/>")}</p>`;
		else if (lower.endsWith(".rtf")) html = `<p>${escapeHtml(raw.replace(/\\par[d]?/g, "\n").replace(/\\'[0-9a-fA-F]{2}/g, "").replace(/\\[a-z]+-?\d* ?/g, "").replace(/[{}]/g, "")).replace(/\n+/g, "</p><p>")}</p>`;
		else {
			const body = raw.match(/<body[^>]*>([\s\S]*?)<\/body>/i);
			if (body?.[1]) html = body[1];
		}
		loadDoc({
			v: 1,
			t: file.name.replace(/\.[^.]+$/, ""),
			h: html
		});
		toast("Opened " + file.name);
	};
	const convertToLink = async () => {
		setLinkOpen(true);
		setCopied(false);
		try {
			const url = buildShareUrl(await encodePad({
				v: 1,
				t: title,
				h: currentHtml()
			}));
			if (url.length > 28e3) {
				toast("This document is too long for a link. Download PDF instead.");
				setShareUrl("");
				return;
			}
			window.history.replaceState(null, "", url);
			setShareUrl(url);
			setDirty(false);
		} catch {
			toast("Could not build a link. Try downloading PDF.");
			setShareUrl("");
		}
	};
	const copyLink = async () => {
		if (!shareUrl) return;
		try {
			await navigator.clipboard.writeText(shareUrl);
		} catch {
			const area = document.createElement("textarea");
			area.value = shareUrl;
			document.body.appendChild(area);
			area.select();
			document.execCommand("copy");
			area.remove();
		}
		setCopied(true);
		toast("Link copied");
	};
	const shareNative = async () => {
		if (!shareUrl || !navigator.share) return;
		try {
			await navigator.share({
				title,
				url: shareUrl,
				text: title
			});
		} catch {}
	};
	const handleDownload = async (kind) => {
		const paper = paperRef.current;
		if (!paper) return;
		setBusy(kind);
		const prevZoom = paper.style.zoom;
		paper.style.zoom = "1";
		try {
			if (kind === "png") await downloadPng(paper, title);
			else if (kind === "pdf") await downloadPdf(paper, title);
			else if (kind === "txt") downloadTxt(currentHtml(), title);
			else downloadHtml(currentHtml(), title);
			toast(`Downloaded ${kind.toUpperCase()}`);
		} catch (err) {
			console.error(err);
			toast("Download failed. Try Print and save as PDF.");
		} finally {
			paper.style.zoom = prevZoom;
			setBusy(null);
		}
	};
	const marginPx = MARGIN[page.margin];
	const paperMax = page.orientation === "landscape" ? page.size === "a4" ? "max-w-4xl" : "max-w-4xl" : page.size === "letter" ? "max-w-2xl" : "max-w-2xl";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-dvh flex-col overflow-hidden bg-bg text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				position: "top-center",
				toastOptions: {
					className: "font-sans",
					style: {
						background: "var(--color-chrome)",
						color: "var(--color-chrome-fg)",
						border: "none"
					}
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "safe-top shrink-0 bg-chrome text-chrome-fg",
				"data-print-hide": true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1 px-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": "File menu",
								"aria-expanded": fileOpen,
								onClick: () => setFileOpen((v) => !v),
								className: "inline-flex size-11 items-center justify-center rounded-md text-chrome-fg transition-transform duration-150 active:scale-[0.96]",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ellipsis, { className: "size-5" })
							}), fileOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "absolute left-1 top-12 z-40 w-44 overflow-hidden rounded-lg bg-surface py-1 text-ink shadow-sheet",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuItem, {
										icon: FilePlus,
										label: "New",
										onClick: () => {
											setFileOpen(false);
											confirmNew();
										}
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuItem, {
										icon: FolderOpen,
										label: "Open",
										onClick: () => {
											setFileOpen(false);
											fileRef.current?.click();
										}
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuItem, {
										icon: Save,
										label: "Save",
										onClick: () => {
											setFileOpen(false);
											saveFile(false);
										}
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuItem, {
										icon: Save,
										label: "Save as",
										onClick: () => {
											setFileOpen(false);
											saveFile(true);
										}
									})
								]
							}) : null]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: title,
							onChange: (e) => {
								setTitle(e.target.value);
								setDirty(true);
								setSaved(false);
							},
							"aria-label": "Document title",
							className: "min-w-0 flex-1 bg-transparent py-3 text-center font-sans text-base font-medium tracking-tight text-chrome-fg outline-none"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": "Undo",
							onMouseDown: (e) => e.preventDefault(),
							onClick: () => exec("undo"),
							className: "inline-flex size-11 items-center justify-center rounded-md transition-transform duration-150 active:scale-[0.96]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Undo2, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": "Redo",
							onMouseDown: (e) => e.preventDefault(),
							onClick: () => exec("redo"),
							className: "inline-flex size-11 items-center justify-center rounded-md transition-transform duration-150 active:scale-[0.96]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Redo2, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": "WordPad window guide",
							onClick: () => setLearnOpen(true),
							className: "inline-flex size-11 items-center justify-center rounded-md transition-transform duration-150 active:scale-[0.96]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "size-5" })
						})
					]
				})
			}),
			showTip ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex shrink-0 items-center gap-2 border-b border-line bg-accent/10 px-3 py-2",
				"data-print-hide": true,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link2, { className: "size-4 shrink-0 text-accent" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "flex-1 text-sm text-ink",
						children: fromLink ? "Opened from a shared link. Edit, then convert again to send your version." : "This note is ready. Convert to Link copies a URL that opens the same page."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Dismiss tip",
						onClick: () => setShowTip(false),
						className: "inline-flex size-9 items-center justify-center rounded-md text-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				"data-print-hide": true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormatToolbar, {
					flags,
					tray,
					zoom,
					onTray: setTray,
					onExec: exec,
					onFont: (name) => exec("fontName", name),
					onSize: applyFontSize,
					onColor: (c) => exec("foreColor", c),
					onHighlight: (c) => exec("hiliteColor", c),
					onSpacing: applySpacing,
					onPicture: insertPicture,
					onDate: insertDate,
					onFind: () => {
						setFindOpen(true);
						setTimeout(() => document.getElementById("pad-find")?.focus(), 30);
					},
					onZoomIn: () => setZoom((z) => Math.min(200, z + 25)),
					onZoomOut: () => setZoom((z) => Math.max(75, z - 25)),
					onZoomSet: setZoom,
					onPageSetup: () => setPageOpen(true),
					onPrint: () => window.print(),
					onPrintPreview: () => setPreviewOpen(true)
				})
			}),
			findOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex shrink-0 items-center gap-2 border-b border-line bg-surface px-3 py-2",
				"data-print-hide": true,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "pad-find",
						value: findQuery,
						onChange: (e) => {
							setFindQuery(e.target.value);
							runFind(e.target.value);
						},
						placeholder: "Find text",
						className: "h-11 min-w-0 flex-1 rounded-md bg-paper px-3 font-sans text-base text-ink outline-none ring-1 ring-inset ring-line"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-sans text-xs tabular-nums text-muted",
						children: findCount
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Close find",
						onClick: () => {
							setFindOpen(false);
							setFindQuery("");
							clearFindMarks();
						},
						className: "inline-flex size-11 items-center justify-center rounded-md",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "min-h-0 flex-1 overflow-y-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cn("mx-auto px-3 py-4", paperMax),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						ref: paperRef,
						className: cn("overflow-hidden rounded-xl bg-paper shadow-paper", page.orientation === "landscape" ? "min-h-72" : "min-h-96"),
						style: { zoom: zoom / 100 },
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ruler, { marginPx }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							ref: editorRef,
							contentEditable: true,
							suppressContentEditableWarning: true,
							role: "textbox",
							"aria-label": "Document",
							spellCheck: true,
							className: "pad-editor",
							style: { padding: marginPx },
							dangerouslySetInnerHTML: { __html: startHtml },
							onInput: () => {
								setDirty(true);
								setSaved(false);
								setHtmlTick((n) => n + 1);
							}
						}, docKey)]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "safe-bottom shrink-0 border-t border-line bg-surface",
				"data-print-hide": true,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between px-4 py-1 font-sans text-xs text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "tabular-nums",
						children: [
							stats.words,
							" words · ",
							stats.chars,
							" characters"
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: saved ? "Saved on device" : "Editing" })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2 px-3 pb-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						onClick: () => setDownloadOpen(true),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), "Download"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: convertToLink,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link2, { className: "size-4" }), "Convert to Link"]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: fileRef,
				type: "file",
				accept: ".txt,.html,.htm,.rtf,.md,text/plain,text/html",
				className: "hidden",
				onChange: (e) => {
					const file = e.target.files?.[0];
					if (file) openFile(file);
					e.target.value = "";
				}
			}),
			fileOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-label": "Close menu",
				className: "fixed inset-0 z-30 cursor-default",
				onClick: () => setFileOpen(false)
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DownloadSheet, {
				open: downloadOpen,
				onOpenChange: setDownloadOpen,
				busy,
				onPick: (kind) => void handleDownload(kind)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LinkSheet, {
				open: linkOpen,
				onOpenChange: setLinkOpen,
				url: shareUrl,
				copied,
				onCopy: () => void copyLink(),
				onShare: () => void shareNative(),
				canShare
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LearnSheet, {
				open: learnOpen,
				onOpenChange: setLearnOpen
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageSetupSheet, {
				open: pageOpen,
				onOpenChange: setPageOpen,
				orientation: page.orientation,
				margin: page.margin,
				size: page.size,
				onOrientation: (orientation) => setPage((p) => ({
					...p,
					orientation
				})),
				onMargin: (margin) => setPage((p) => ({
					...p,
					margin
				})),
				onSize: (size) => setPage((p) => ({
					...p,
					size
				}))
			}),
			previewOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-50 flex flex-col bg-bg/95",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between px-3 py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-sans text-sm font-medium",
						children: "Print preview"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "outline",
							onClick: () => window.print(),
							children: "Print"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "ghost",
							onClick: () => setPreviewOpen(false),
							children: "Close"
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex-1 overflow-auto p-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-2xl bg-paper p-8 shadow-paper",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mb-4 font-sans text-xl font-semibold",
							children: title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "pad-editor",
							dangerouslySetInnerHTML: { __html: currentHtml() }
						})]
					})
				})]
			}) : null
		]
	});
}
function MenuItem({ icon: Icon, label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: "flex w-full items-center gap-2 px-3 py-2.5 text-left font-sans text-sm text-ink hover:bg-ink/5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4 text-muted" }), label]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PadApp, {});
}
//#endregion
export { Home as component };
