import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/video-8zONtqMR.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var DURATIONS = /* @__PURE__ */ new Set([
	6,
	8,
	10
]);
var ASPECTS = /* @__PURE__ */ new Set([
	"16:9",
	"9:16",
	"1:1"
]);
var RESOLUTIONS = /* @__PURE__ */ new Set(["480p", "720p"]);
var MODELS = /* @__PURE__ */ new Set(["lite", "studio"]);
var starts = [];
var refines = [];
var polls = [];
function allow(bucket, limit, windowMs) {
	const now = Date.now();
	while (bucket.length && now - bucket[0] > windowMs) bucket.shift();
	if (bucket.length >= limit) return false;
	bucket.push(now);
	return true;
}
function errorText(body, fallback) {
	if (!body || typeof body !== "object") return fallback;
	const record = body;
	if (typeof record.error === "string" && record.error.trim()) return record.error.trim();
	if (record.error && typeof record.error === "object") {
		const message = record.error.message;
		if (typeof message === "string" && message.trim()) return message.trim();
	}
	if (typeof record.message === "string" && record.message.trim()) return record.message.trim();
	return fallback;
}
function friendlyHttp(status, body) {
	if (status === 401 || status === 403) return "No se pudo autorizar la generación.";
	if (status === 402) return "No hay créditos suficientes para esta toma.";
	if (status === 429) return "Demasiadas solicitudes. Espera un momento.";
	const detail = errorText(body, "");
	if (detail) return detail;
	return `El servicio respondió con un error (${status}).`;
}
async function xai(path, init) {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		status: 0,
		error: "Ahora mismo no se puede generar video en este espacio.",
		body: null
	};
	try {
		const res = await fetch(`https://api.x.ai${path}`, {
			method: init?.method ?? "GET",
			headers: {
				Authorization: `Bearer ${apiKey}`,
				...init?.body ? { "Content-Type": "application/json" } : {}
			},
			body: init?.body ? JSON.stringify(init.body) : void 0,
			signal: AbortSignal.timeout(4e4)
		});
		const text = await res.text();
		let body = null;
		if (text) try {
			body = JSON.parse(text);
		} catch {
			body = { message: text.slice(0, 280) };
		}
		if (!res.ok) return {
			ok: false,
			status: res.status,
			error: friendlyHttp(res.status, body),
			body
		};
		return {
			ok: true,
			status: res.status,
			error: "",
			body
		};
	} catch {
		return {
			ok: false,
			status: 0,
			error: "No hubo respuesta del servicio de video. Inténtalo otra vez.",
			body: null
		};
	}
}
function cleanImage(raw) {
	const value = raw.trim();
	if (!value) return "";
	if (value.length > 12e5) throw new Error("La foto es demasiado pesada. Prueba con una más pequeña.");
	if (value.startsWith("https://")) return value;
	if (/^data:image\/(jpeg|png|webp);base64,/i.test(value)) return value;
	throw new Error("La foto debe ser un enlace https o una imagen JPG, PNG o WebP.");
}
function asStart(input) {
	const prompt = typeof input.prompt === "string" ? input.prompt.trim() : "";
	if (prompt.length < 3 || prompt.length > 1e3) throw new Error("La escena debe tener entre 3 y 1000 caracteres.");
	if (!DURATIONS.has(input.duration)) throw new Error("Elige 6, 8 o 10 segundos.");
	if (!ASPECTS.has(input.aspectRatio)) throw new Error("Elige una relación de aspecto.");
	if (!RESOLUTIONS.has(input.resolution)) throw new Error("Elige una resolución.");
	if (!MODELS.has(input.model)) throw new Error("Elige un modelo.");
	return {
		prompt,
		duration: input.duration,
		aspectRatio: input.aspectRatio,
		resolution: input.resolution,
		model: input.model,
		sound: Boolean(input.sound),
		imageUrl: cleanImage(typeof input.imageUrl === "string" ? input.imageUrl : "")
	};
}
var studioStatus_createServerFn_handler = createServerRpc({
	id: "de201c99413a36c9bdf85deed5ef18d705c1ac8fde8f538e538525a074db11d8",
	name: "studioStatus",
	filename: "src/lib/video.ts"
}, (opts) => studioStatus.__executeServer(opts));
var studioStatus = createServerFn({ method: "GET" }).handler(studioStatus_createServerFn_handler, async () => {
	return { available: Boolean(process.env.XAI_API_KEY) };
});
var refineScene_createServerFn_handler = createServerRpc({
	id: "4ee2ed0f937c128e2b6f3e1d5e96aa093828cccdee18070b24433c0bc58ec3e9",
	name: "refineScene",
	filename: "src/lib/video.ts"
}, (opts) => refineScene.__executeServer(opts));
var refineScene = createServerFn({ method: "POST" }).validator((input) => {
	const idea = input.idea.trim();
	if (idea.length < 3 || idea.length > 1e3) throw new Error("Escribe una idea un poco más larga antes de afinarla.");
	return { idea };
}).handler(refineScene_createServerFn_handler, async ({ data }) => {
	if (!allow(refines, 8, 6e5)) return {
		ok: false,
		error: "Has afinado varias ideas seguidas. Espera unos minutos."
	};
	const result = await xai("/v1/chat/completions", {
		method: "POST",
		body: {
			model: "grok-4.5",
			max_tokens: 220,
			temperature: .6,
			messages: [{
				role: "system",
				content: "Eres director de fotografía. Reescribe la idea como una sola descripción de plano para un generador de video. Español concreto: encuadre, movimiento de cámara, luz y un detalle de ambiente. Una sola toma, sin lista, sin título, sin comillas. Máximo 500 caracteres. No inventes marcas ni personas famosas. Devuelve solo el texto del plano."
			}, {
				role: "user",
				content: data.idea
			}]
		}
	});
	if (!result.ok) return {
		ok: false,
		error: result.error
	};
	const prompt = result.body.choices?.[0]?.message?.content?.trim() ?? "";
	if (!prompt) return {
		ok: false,
		error: "No pude afinar esa idea."
	};
	return {
		ok: true,
		prompt: prompt.slice(0, 1e3)
	};
});
var startVideo_createServerFn_handler = createServerRpc({
	id: "f0614f37822e8605ff0ce162c1d7cf6610a18a722082e25e1ad47e42c2b0a3e4",
	name: "startVideo",
	filename: "src/lib/video.ts"
}, (opts) => startVideo.__executeServer(opts));
var startVideo = createServerFn({ method: "POST" }).validator((input) => asStart(input)).handler(startVideo_createServerFn_handler, async ({ data }) => {
	if (!process.env.XAI_API_KEY) return {
		ok: false,
		error: "Ahora mismo no se puede generar video en este espacio."
	};
	if (!allow(starts, 5, 6e5)) return {
		ok: false,
		error: "Has generado varias tomas seguidas. Espera unos minutos para cuidar los créditos."
	};
	const payload = {
		model: data.model === "studio" ? "grok-imagine-video-1.5" : "grok-imagine-video-1.5-lite",
		prompt: data.prompt,
		duration: data.duration,
		aspect_ratio: data.aspectRatio,
		resolution: data.resolution,
		generate_audio: data.sound
	};
	if (data.imageUrl) payload.image = { url: data.imageUrl };
	const result = await xai("/v1/videos/generations", {
		method: "POST",
		body: payload
	});
	if (!result.ok) return {
		ok: false,
		error: result.error
	};
	const requestId = result.body?.request_id;
	if (!requestId) return {
		ok: false,
		error: "El servicio no devolvió una solicitud."
	};
	return {
		ok: true,
		requestId
	};
});
var pollVideo_createServerFn_handler = createServerRpc({
	id: "05d73e7963645371137940c4245d56b717a2bab48d2c85fbc33df8f0a000ab41",
	name: "pollVideo",
	filename: "src/lib/video.ts"
}, (opts) => pollVideo.__executeServer(opts));
var pollVideo = createServerFn({ method: "POST" }).validator((input) => {
	const requestId = input.requestId.trim();
	if (!/^[a-zA-Z0-9_-]{8,128}$/.test(requestId)) throw new Error("Solicitud no válida.");
	return { requestId };
}).handler(pollVideo_createServerFn_handler, async ({ data }) => {
	if (!allow(polls, 40, 6e4)) return {
		ok: true,
		status: "pending"
	};
	const result = await xai(`/v1/videos/${data.requestId}`);
	if (!result.ok) return {
		ok: false,
		status: "error",
		error: result.error
	};
	const body = result.body ?? {};
	const status = (body.status ?? "pending").toLowerCase();
	const url = typeof body.video?.url === "string" ? body.video.url : typeof body.url === "string" ? body.url : "";
	if (status === "done" && url.startsWith("https://")) return {
		ok: true,
		status: "done",
		url
	};
	if (status === "failed" || status === "expired" || status === "error" || status === "cancelled") return {
		ok: false,
		status,
		error: errorText(body, "La toma no se pudo completar.")
	};
	return {
		ok: true,
		status: "pending"
	};
});
//#endregion
export { pollVideo_createServerFn_handler, refineScene_createServerFn_handler, startVideo_createServerFn_handler, studioStatus_createServerFn_handler };
