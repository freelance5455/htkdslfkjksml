import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { g as ChevronLeft, h as ChevronRight } from "../_libs/lucide-react.mjs";
import { t as format } from "../_libs/date-fns.mjs";
import { O as weekDays, S as parseDay, T as shiftDay, i as usePlanner, k as cn, v as useTodayKey, y as dayKey } from "./router-CQnHyG8o.mjs";
import { n as Card, o as IconButton, r as CardTitle, s as PageHeader } from "./primitives-DM2UCvsE.mjs";
import { t as CheckList } from "./check-list-Bim0RNJK.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/week-BfSpNrwa.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function WeekView() {
	const today = useTodayKey();
	const [cursor, setCursor] = (0, import_react.useState)(null);
	const active = cursor ?? today;
	if (!active || !today) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		section: "week",
		title: "Week",
		lede: "Opening the week."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WeekPage, {
		anchor: active,
		today,
		onAnchor: setCursor
	});
}
function WeekPage({ anchor, today, onAnchor }) {
	const days = weekDays(parseDay(anchor));
	const weekId = dayKey(days[0] ?? parseDay(anchor));
	const week = usePlanner((s) => s.weeks[weekId]);
	const patchWeek = usePlanner((s) => s.patchWeek);
	const habits = usePlanner((s) => s.habits);
	const toggleHabit = usePlanner((s) => s.toggleHabit);
	const log = {
		focus: week?.focus ?? "",
		priorities: week?.priorities ?? [],
		dayNotes: week?.dayNotes ?? {},
		worked: week?.worked ?? "",
		carry: week?.carry ?? ""
	};
	const start = days[0] ?? parseDay(anchor);
	const end = days[6] ?? start;
	const thisWeek = dayKey(weekDays(parseDay(today))[0] ?? parseDay(today));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			section: "week",
			title: `${format(start, "d MMM")} – ${format(end, "d MMM")}`,
			lede: "What you are protecting this week.",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
					label: "Previous week",
					onClick: () => onAnchor(shiftDay(weekId, -7)),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, {
						className: "size-5",
						strokeWidth: 1.6
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
					label: "Next week",
					onClick: () => onAnchor(shiftDay(weekId, 7)),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {
						className: "size-5",
						strokeWidth: 1.6
					})
				})]
			})
		}),
		weekId !== thisWeek ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "mb-4 text-sm font-medium text-accent",
			onClick: () => onAnchor(null),
			children: "This week"
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Focus" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					value: log.focus,
					onChange: (event) => patchWeek(weekId, (w) => ({
						...w,
						focus: event.target.value
					})),
					placeholder: "If the week only did one thing well, what would it be?",
					rows: 3,
					className: "min-h-20 w-full resize-none bg-transparent font-display text-xl leading-snug outline-none placeholder:font-sans placeholder:text-base placeholder:text-muted"
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Priorities" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckList, {
					items: log.priorities,
					placeholder: "A weekly priority",
					onChange: (priorities) => patchWeek(weekId, (w) => ({
						...w,
						priorities
					}))
				})] }),
				habits.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Habits" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "habit-grid mb-2 items-center text-center text-xs text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}), days.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn(dayKey(d) === today && "text-ink"),
							children: format(d, "EEEEE")
						}, dayKey(d)))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "grid gap-2",
						children: habits.map((habit) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "habit-grid items-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate text-sm",
								children: habit.name
							}), days.map((d) => {
								const key = dayKey(d);
								const on = !!habit.checks[key];
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-label": `${habit.name} on ${format(d, "EEEE")}`,
									"aria-pressed": on,
									onClick: () => toggleHabit(habit.id, key),
									className: "grid h-11 w-full min-w-0 place-items-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "size-4 rounded-full border-2",
										style: {
											borderColor: habit.color,
											background: on ? habit.color : "transparent"
										}
									})
								}, key);
							})]
						}, habit.id))
					})
				] }) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Days" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-3",
					children: days.map((d) => {
						const key = dayKey(d);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "grid gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("text-sm font-medium", key === today ? "text-accent" : "text-muted"),
								children: format(d, "EEEE d")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: log.dayNotes[key] ?? "",
								onChange: (event) => patchWeek(weekId, (w) => ({
									...w,
									dayNotes: {
										...w.dayNotes,
										[key]: event.target.value
									}
								})),
								placeholder: "A note for this day",
								className: "h-11 w-full rounded-lg border border-line bg-card px-3 text-base outline-none placeholder:text-muted focus-visible:border-accent"
							})]
						}, key);
					})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 md:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "What worked" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: log.worked,
						onChange: (event) => patchWeek(weekId, (w) => ({
							...w,
							worked: event.target.value
						})),
						placeholder: "Keep it specific.",
						rows: 4,
						className: "min-h-24 w-full resize-none bg-transparent text-base outline-none placeholder:text-muted"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Carry forward" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: log.carry,
						onChange: (event) => patchWeek(weekId, (w) => ({
							...w,
							carry: event.target.value
						})),
						placeholder: "What still wants a place next week?",
						rows: 4,
						className: "min-h-24 w-full resize-none bg-transparent text-base outline-none placeholder:text-muted"
					})] })]
				})
			]
		})
	] });
}
var SplitComponent = WeekView;
//#endregion
export { SplitComponent as component };
