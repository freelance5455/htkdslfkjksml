import { i as __toESM } from "../_runtime.mjs";
import { q as require_react, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Settings, c as Radar, d as House, f as Download, i as Shield, l as Plus, m as Activity, o as Server, p as Copy, r as Trash2, s as RefreshCw, t as Waypoints, u as Link2 } from "../_libs/lucide-react.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { a as ResponsiveContainer, i as Bar, n as YAxis, o as Tooltip, r as XAxis, t as BarChart } from "../_libs/recharts+[...].mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CtPNSLW3.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function Panel({ className, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: cn("rounded-lg border border-border bg-surface p-4", className),
		children
	});
}
function Button({ variant = "primary", className, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: cn("inline-flex h-11 items-center justify-center gap-2 rounded-md px-4 text-sm font-semibold transition-opacity disabled:opacity-50", variant === "primary" && "bg-primary text-primary-ink", variant === "ghost" && "border border-border bg-bg-raised text-fg", variant === "danger" && "border border-border bg-bg-raised text-accent", className),
		...props
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "flex flex-col gap-1.5 text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-muted",
			children: label
		}), children]
	});
}
var inputClass = "h-11 w-full rounded-md border border-border bg-bg px-3 text-base text-fg outline-none focus:border-primary";
function pingTone(ms) {
	if (ms == null) return "text-muted";
	if (ms < 80) return "text-primary";
	if (ms < 180) return "text-fg";
	return "text-accent";
}
var DNS_CATALOG = [
	{
		id: "cloudflare",
		name: "Cloudflare",
		provider: "Cloudflare",
		primary: "1.1.1.1",
		secondary: "1.0.0.1",
		region: "جهانی",
		pubg: "Anycast نزدیک؛ انتخاب پیش‌فرض بازی",
		note: "بدون فیلتر محتوا. معمولاً کم‌تاخیرترین رزولور عمومی است.",
		doh: "https://cloudflare-dns.com/dns-query",
		dot: "one.one.one.one",
		gaming: true,
		filter: "هیچ"
	},
	{
		id: "cloudflare-malware",
		name: "Cloudflare بدافزار",
		provider: "Cloudflare",
		primary: "1.1.1.2",
		secondary: "1.0.0.2",
		region: "جهانی",
		pubg: "مثل ۱.۱.۱.۱ با سد دامنه‌های مخرب",
		note: "برای بازی معمولاً لازم نیست؛ اگر دامنه‌ای باز نشد به نسخهٔ بدون فیلتر برگرد.",
		doh: "https://security.cloudflare-dns.com/dns-query",
		dot: "security.cloudflare-dns.com",
		gaming: false,
		filter: "بدافزار"
	},
	{
		id: "cloudflare-family",
		name: "Cloudflare خانواده",
		provider: "Cloudflare",
		primary: "1.1.1.3",
		secondary: "1.0.0.3",
		region: "جهانی",
		pubg: "فیلتر خانواده؛ برای پابجی توصیه نمی‌شود",
		note: "ممکن است بعضی سرویس‌ها را ببندد.",
		doh: "https://family.cloudflare-dns.com/dns-query",
		dot: "family.cloudflare-dns.com",
		gaming: false,
		filter: "خانوادگی"
	},
	{
		id: "google",
		name: "Google",
		provider: "Google Public DNS",
		primary: "8.8.8.8",
		secondary: "8.8.4.4",
		region: "جهانی",
		pubg: "پایدار و جهانی؛ خط مبنا برای مقایسه",
		note: "رزولور عمومی گوگل. لاگ سیاست خودش را دارد.",
		doh: "https://dns.google/resolve",
		dot: "dns.google",
		gaming: true,
		filter: "هیچ"
	},
	{
		id: "quad9",
		name: "Quad9",
		provider: "Quad9",
		primary: "9.9.9.9",
		secondary: "149.112.112.112",
		region: "جهانی",
		pubg: "جایگزین پیشنهادی بعد از خاموشی Mullvad DNS",
		note: "دامنه‌های مخرب را سد می‌کند. از نوامبر ۲۰۲۶ سرویس عمومی Mullvad خاموش است.",
		doh: "https://dns.quad9.net/dns-query",
		dot: "dns.quad9.net",
		gaming: true,
		filter: "بدافزار"
	},
	{
		id: "quad9-raw",
		name: "Quad9 بدون فیلتر",
		provider: "Quad9",
		primary: "9.9.9.10",
		secondary: "149.112.112.10",
		region: "جهانی",
		pubg: "همان شبکه بدون سد بدافزار",
		note: "اگر نسخهٔ محافظ چیزی را بسته باشد این را امتحان کن.",
		doh: "https://dns10.quad9.net/dns-query",
		dot: "dns10.quad9.net",
		gaming: true,
		filter: "هیچ"
	},
	{
		id: "opendns",
		name: "OpenDNS",
		provider: "Cisco",
		primary: "208.67.222.222",
		secondary: "208.67.220.220",
		region: "آمریکا",
		pubg: "لبهٔ آمریکا؛ برای کلاستر اروپا معمولاً دور است",
		note: "محافظت فیشینگ سیسکو.",
		doh: "https://doh.opendns.com/dns-query",
		gaming: false,
		filter: "بدافزار"
	},
	{
		id: "opendns-family",
		name: "OpenDNS FamilyShield",
		provider: "Cisco",
		primary: "208.67.222.123",
		secondary: "208.67.220.123",
		region: "آمریکا",
		pubg: "فیلتر خانواده",
		note: "برای بازی مناسب نیست.",
		doh: "https://doh.familyshield.opendns.com/dns-query",
		gaming: false,
		filter: "خانوادگی"
	},
	{
		id: "adguard",
		name: "AdGuard",
		provider: "AdGuard",
		primary: "94.140.14.14",
		secondary: "94.140.15.15",
		region: "جهانی",
		pubg: "تبلیغ‌گیر؛ گاهی مسیر بازی را هم لمس می‌کند",
		note: "اگر لابی دیر بالا آمد، رزولور بدون فیلتر را بگذار.",
		doh: "https://dns.adguard-dns.com/dns-query",
		dot: "dns.adguard-dns.com",
		gaming: false,
		filter: "تبلیغ"
	},
	{
		id: "adguard-family",
		name: "AdGuard خانواده",
		provider: "AdGuard",
		primary: "94.140.14.15",
		secondary: "94.140.15.16",
		region: "جهانی",
		pubg: "فیلتر خانواده",
		note: "سد محتوا دارد.",
		doh: "https://dns-family.adguard-dns.com/dns-query",
		dot: "dns-family.adguard-dns.com",
		gaming: false,
		filter: "خانوادگی"
	},
	{
		id: "controld",
		name: "Control D",
		provider: "Control D",
		primary: "76.76.2.0",
		secondary: "76.76.10.0",
		region: "جهانی",
		pubg: "رزولور آزاد بدون پروفایل شخصی",
		note: "نسخهٔ رایگان بدون فیلتر. پروفایل پولی را خودت به‌صورت سفارشی اضافه کن.",
		doh: "https://freedns.controld.com/p0",
		gaming: true,
		filter: "هیچ"
	},
	{
		id: "cleanbrowsing",
		name: "CleanBrowsing امنیت",
		provider: "CleanBrowsing",
		primary: "185.228.168.9",
		secondary: "185.228.169.9",
		region: "اروپا",
		pubg: "اروپا، با سد فیشینگ",
		note: "فیلتر امنیتی سبک.",
		doh: "https://doh.cleanbrowsing.org/doh/security-filter/",
		gaming: false,
		filter: "بدافزار"
	},
	{
		id: "cleanbrowsing-family",
		name: "CleanBrowsing خانواده",
		provider: "CleanBrowsing",
		primary: "185.228.168.168",
		secondary: "185.228.169.168",
		region: "اروپا",
		pubg: "فیلتر خانواده",
		note: "برای بازی توصیه نمی‌شود.",
		doh: "https://doh.cleanbrowsing.org/doh/family-filter/",
		gaming: false,
		filter: "خانوادگی"
	},
	{
		id: "verisign",
		name: "Verisign",
		provider: "Verisign",
		primary: "64.6.64.6",
		secondary: "64.6.65.6",
		region: "آمریکا",
		pubg: "پایدار، بیشتر آمریکا",
		note: "بدون فیلتر محتوا.",
		gaming: true,
		filter: "هیچ"
	},
	{
		id: "comodo",
		name: "Comodo Secure",
		provider: "Comodo",
		primary: "8.26.56.26",
		secondary: "8.20.247.20",
		region: "آمریکا",
		pubg: "امنیتی، نه بهینهٔ بازی",
		note: "دامنه‌های مخرب را سد می‌کند.",
		gaming: false,
		filter: "بدافزار"
	},
	{
		id: "neustar",
		name: "Neustar",
		provider: "Neustar",
		primary: "156.154.70.1",
		secondary: "156.154.71.1",
		region: "آمریکا",
		pubg: "لبهٔ آمریکا",
		note: "رزولور عمومی UltraDNS / Neustar.",
		gaming: false,
		filter: "هیچ"
	},
	{
		id: "dns-sb",
		name: "DNS.SB",
		provider: "DNS.SB",
		primary: "185.222.222.222",
		secondary: "45.11.45.11",
		region: "جهانی",
		pubg: "حریم‌خصوصی‌محور و بدون فیلتر",
		note: "گزینهٔ تمیز برای مقایسه با کلادفلر.",
		doh: "https://doh.dns.sb/dns-query",
		gaming: true,
		filter: "هیچ"
	},
	{
		id: "dnswatch",
		name: "DNS.WATCH",
		provider: "DNS.WATCH",
		primary: "84.200.69.80",
		secondary: "84.200.70.40",
		region: "اروپا",
		pubg: "آلمان؛ مسیر اروپا",
		note: "بدون سانسور و بدون لاگ ادعایی خود سرویس.",
		gaming: true,
		filter: "هیچ"
	},
	{
		id: "uncensored",
		name: "UncensoredDNS",
		provider: "UncensoredDNS",
		primary: "91.239.100.100",
		secondary: "89.233.43.71",
		region: "اروپا",
		pubg: "دانمارک",
		note: "رزولور اروپایی بدون فیلتر.",
		gaming: true,
		filter: "هیچ"
	},
	{
		id: "dns4eu",
		name: "DNS4EU",
		provider: "DNS4EU",
		primary: "86.54.11.13",
		secondary: "86.54.11.213",
		region: "اروپا",
		pubg: "اروپا، نسخهٔ بدون فیلتر",
		note: "سرویس اروپایی. نسخهٔ تبلیغ‌گیر جداست و اینجا نیست.",
		doh: "https://unfiltered.joindns4.eu/dns-query",
		dot: "unfiltered.joindns4.eu",
		gaming: true,
		filter: "هیچ"
	},
	{
		id: "yandex",
		name: "Yandex",
		provider: "Yandex",
		primary: "77.88.8.8",
		secondary: "77.88.8.1",
		region: "روسیه",
		pubg: "نزدیک مسیر شمال / شرق اروپا",
		note: "حالت پایه بدون فیلتر خانواده.",
		gaming: true,
		filter: "هیچ"
	},
	{
		id: "alidns",
		name: "AliDNS",
		provider: "Alibaba",
		primary: "223.5.5.5",
		secondary: "223.6.6.6",
		region: "آسیا",
		pubg: "چین / آسیا؛ بازیکن‌ها برای کلاستر آسیا مقایسه می‌کنند",
		note: "DNS رجیستر سرور پابجی را قفل نمی‌کند؛ فقط نام‌ها را از لبهٔ نزدیک‌تر حل می‌کند.",
		doh: "https://dns.alidns.com/resolve",
		dot: "dns.alidns.com",
		gaming: true,
		filter: "هیچ"
	},
	{
		id: "dnspod",
		name: "DNSPod",
		provider: "Tencent",
		primary: "119.29.29.29",
		secondary: "119.28.28.28",
		region: "آسیا",
		pubg: "رزولور تنسنت، ناشر پابجی موبایل",
		note: "نزدیکی به اکوسیستم تنسنت به معنی انتخاب سرور بازی نیست.",
		doh: "https://doh.pub/dns-query",
		dot: "dot.pub",
		gaming: true,
		filter: "هیچ"
	},
	{
		id: "dns114",
		name: "114DNS",
		provider: "114DNS",
		primary: "114.114.114.114",
		secondary: "114.114.115.115",
		region: "آسیا",
		pubg: "چین",
		note: "رزولور عمومی قدیمی چین.",
		gaming: true,
		filter: "هیچ"
	},
	{
		id: "cnnic",
		name: "CNNIC",
		provider: "CNNIC",
		primary: "1.2.4.8",
		secondary: "210.2.4.8",
		region: "آسیا",
		pubg: "چین",
		note: "رزولور SDNS.",
		gaming: false,
		filter: "هیچ"
	},
	{
		id: "baidu",
		name: "Baidu",
		provider: "Baidu",
		primary: "180.76.76.76",
		region: "آسیا",
		pubg: "چین",
		note: "فقط آدرس اصلی عمومی.",
		gaming: false,
		filter: "هیچ"
	},
	{
		id: "onedns",
		name: "OneDNS",
		provider: "OneDNS",
		primary: "117.50.11.11",
		secondary: "117.50.22.22",
		region: "آسیا",
		pubg: "چین",
		note: "رزولور عمومی چینی.",
		gaming: false,
		filter: "هیچ"
	},
	{
		id: "he",
		name: "Hurricane Electric",
		provider: "Hurricane Electric",
		primary: "74.82.42.42",
		region: "آمریکا",
		pubg: "آمریکا؛ اغلب دور",
		note: "یک آدرس، بدون ثانویهٔ رسمی در این فهرست.",
		gaming: false,
		filter: "هیچ"
	},
	{
		id: "level3",
		name: "Level 3",
		provider: "Level 3",
		primary: "4.2.2.1",
		secondary: "4.2.2.2",
		region: "آمریکا",
		pubg: "کلاسیک آمریکایی",
		note: "از رزولورهای قدیمی و هنوز منتشر.",
		gaming: false,
		filter: "هیچ"
	},
	{
		id: "centurylink",
		name: "CenturyLink",
		provider: "CenturyLink",
		primary: "209.244.0.3",
		secondary: "209.244.0.4",
		region: "آمریکا",
		pubg: "آمریکا",
		note: "رزولور عمومی Level 3 / CenturyLink.",
		gaming: false,
		filter: "هیچ"
	},
	{
		id: "shecan",
		name: "شکن",
		provider: "Shecan",
		primary: "178.22.122.100",
		secondary: "185.51.200.2",
		region: "ایران",
		pubg: "نزدیک‌ترین رزولور عمومی داخل ایران",
		note: "فیلتر ملی را دور نمی‌زند و همان قواعد را اعمال می‌کند. برای وای‌فای یا Private DNS با نام free.shecan.ir.",
		dot: "free.shecan.ir",
		gaming: true,
		filter: "هیچ"
	},
	{
		id: "begzar",
		name: "بگذر",
		provider: "Begzar",
		primary: "185.55.226.26",
		secondary: "185.55.225.25",
		region: "ایران",
		pubg: "رزولور ایرانی برای مقایسه با شکن",
		note: "آدرس اصلی روی dns2.begzar.ir دیده شده. اگر پاسخ نداد حذفش کن و DNS خودت را اضافه کن.",
		gaming: true,
		filter: "هیچ"
	}
];
var REGION_FILTERS = [
	"همه",
	"بازی",
	"ایران",
	"آسیا",
	"اروپا",
	"آمریکا",
	"جهانی",
	"روسیه"
];
function dnsPair(entry) {
	return [entry.primary, entry.secondary].filter(Boolean).join(", ");
}
function findDns(id, customs) {
	return DNS_CATALOG.find((item) => item.id === id) ?? customs.find((item) => item.id === id) ?? DNS_CATALOG[0];
}
function recommendIds(countryCode) {
	if (countryCode === "IR") return [
		"shecan",
		"begzar",
		"cloudflare",
		"dnspod",
		"alidns",
		"google"
	];
	if (countryCode && [
		"CN",
		"HK",
		"TW",
		"SG",
		"MY",
		"TH",
		"VN",
		"ID",
		"PH"
	].includes(countryCode)) return [
		"alidns",
		"dnspod",
		"dns114",
		"cloudflare",
		"google"
	];
	if (countryCode && [
		"DE",
		"NL",
		"FR",
		"GB",
		"SE",
		"PL",
		"IT",
		"ES",
		"FI",
		"NO",
		"DK",
		"AT",
		"CH"
	].includes(countryCode)) return [
		"cloudflare",
		"quad9-raw",
		"dns-sb",
		"dns4eu",
		"google",
		"dnswatch"
	];
	if (countryCode && [
		"US",
		"CA",
		"MX"
	].includes(countryCode)) return [
		"cloudflare",
		"google",
		"quad9-raw",
		"verisign",
		"dns-sb"
	];
	return [
		"cloudflare",
		"google",
		"quad9-raw",
		"dns-sb",
		"adguard",
		"opendns"
	];
}
var IPV4 = /^(25[0-5]|2[0-4]\d|1?\d?\d)(\.(25[0-5]|2[0-4]\d|1?\d?\d)){3}$/;
function isIpv4(value) {
	return IPV4.test(value.trim());
}
function isPrivateIpv4(value) {
	const parts = value.split(".").map(Number);
	if (parts.length !== 4 || parts.some((n) => Number.isNaN(n))) return false;
	const [a, b] = parts;
	if (a === 10 || a === 127) return true;
	if (a === 192 && b === 168) return true;
	if (a === 172 && b >= 16 && b <= 31) return true;
	return false;
}
var CLUSTERS = [
	{
		id: "me",
		title: "خاورمیانه",
		hint: "معمولاً دبی یا بحرین. برای ایران رایج‌ترین خوشه است، نه تضمین.",
		codes: [
			"IR",
			"IQ",
			"AE",
			"SA",
			"QA",
			"KW",
			"BH",
			"OM",
			"JO",
			"LB",
			"SY",
			"YE",
			"TR",
			"EG",
			"IL",
			"PS"
		]
	},
	{
		id: "asia",
		title: "آسیا",
		hint: "اغلب سنگاپور. رزولور چینی فقط مسیر نام را عوض می‌کند.",
		codes: [
			"SG",
			"MY",
			"ID",
			"TH",
			"VN",
			"PH",
			"HK",
			"TW",
			"CN",
			"MO",
			"KH",
			"LA",
			"MM"
		]
	},
	{
		id: "krjp",
		title: "کره و ژاپن",
		hint: "سئول یا توکیو.",
		codes: ["KR", "JP"]
	},
	{
		id: "in",
		title: "جنوب آسیا",
		hint: "اغلب بمبئی.",
		codes: [
			"IN",
			"PK",
			"BD",
			"LK",
			"NP"
		]
	},
	{
		id: "eu",
		title: "اروپا",
		hint: "فرانکفورت یا آمستردام.",
		codes: [
			"DE",
			"NL",
			"FR",
			"GB",
			"SE",
			"PL",
			"IT",
			"ES",
			"FI",
			"NO",
			"DK",
			"AT",
			"CH",
			"BE",
			"CZ",
			"RO",
			"UA",
			"HU",
			"PT",
			"IE",
			"GR",
			"BG",
			"HR",
			"SK",
			"LT",
			"LV",
			"EE",
			"LU",
			"SI"
		]
	},
	{
		id: "na",
		title: "آمریکای شمالی",
		hint: "ویرجینیا یا ساحل غرب.",
		codes: [
			"US",
			"CA",
			"MX"
		]
	},
	{
		id: "sa",
		title: "آمریکای جنوبی",
		hint: "اغلب سائوپائولو.",
		codes: [
			"BR",
			"AR",
			"CL",
			"CO",
			"PE",
			"VE",
			"UY",
			"EC"
		]
	},
	{
		id: "oc",
		title: "اقیانوسیه",
		hint: "سیدنی.",
		codes: ["AU", "NZ"]
	},
	{
		id: "af",
		title: "آفریقا",
		hint: "اغلب به اروپا یا خاورمیانه نزدیک می‌شود.",
		codes: [
			"ZA",
			"NG",
			"KE",
			"MA",
			"DZ",
			"TN",
			"GH",
			"ET"
		]
	}
];
var FA_COUNTRY = {
	IR: "ایران",
	IQ: "عراق",
	AE: "امارات",
	SA: "عربستان",
	QA: "قطر",
	KW: "کویت",
	BH: "بحرین",
	OM: "عمان",
	JO: "اردن",
	LB: "لبنان",
	SY: "سوریه",
	YE: "یمن",
	TR: "ترکیه",
	EG: "مصر",
	DE: "آلمان",
	NL: "هلند",
	FR: "فرانسه",
	GB: "بریتانیا",
	SE: "سوئد",
	PL: "لهستان",
	IT: "ایتالیا",
	ES: "اسپانیا",
	FI: "فنلاند",
	NO: "نروژ",
	DK: "دانمارک",
	AT: "اتریش",
	CH: "سوئیس",
	US: "آمریکا",
	CA: "کانادا",
	MX: "مکزیک",
	SG: "سنگاپور",
	MY: "مالزی",
	ID: "اندونزی",
	TH: "تایلند",
	VN: "ویتنام",
	PH: "فیلیپین",
	HK: "هنگ‌کنگ",
	TW: "تایوان",
	CN: "چین",
	KR: "کره",
	JP: "ژاپن",
	IN: "هند",
	PK: "پاکستان",
	BR: "برزیل",
	AU: "استرالیا",
	RU: "روسیه",
	UA: "اوکراین"
};
function countryFa(code, fallback) {
	if (!code) return fallback || "نامشخص";
	return FA_COUNTRY[code] ?? fallback ?? code;
}
function clusterFor(code) {
	if (!code) return null;
	return CLUSTERS.find((item) => item.codes.includes(code)) ?? null;
}
var REGISTER_NOTE = "رجیستر را خود پابجی با UDP و موقعیت شبکه انتخاب می‌کند. این درخت خوشهٔ محتمل را از کشور خروجی اینترنتت نشان می‌دهد، نه سروری که بازی قفل کرده باشد. DNS آن را عوض نمی‌کند.";
var useRange = create()(persist((set) => ({
	mode: "both",
	dnsId: "cloudflare",
	wgId: null,
	profiles: [],
	customs: [],
	operator: {
		name: "محمد طیب بهزادی شریف",
		device: "REDMI 14C",
		fps: 40
	},
	pings: {},
	paths: {},
	geo: null,
	setMode: (mode) => set({ mode }),
	selectDns: (dnsId) => set({ dnsId }),
	selectWg: (wgId) => set({ wgId }),
	addProfile: (profile) => set((state) => ({
		profiles: [profile, ...state.profiles].slice(0, 12),
		wgId: profile.id
	})),
	removeProfile: (id) => set((state) => ({
		profiles: state.profiles.filter((item) => item.id !== id),
		wgId: state.wgId === id ? null : state.wgId
	})),
	addCustom: (entry) => set((state) => ({
		customs: [entry, ...state.customs].slice(0, 30),
		dnsId: entry.id
	})),
	removeCustom: (id) => set((state) => ({
		customs: state.customs.filter((item) => item.id !== id),
		dnsId: state.dnsId === id ? "cloudflare" : state.dnsId
	})),
	setOperator: (patch) => set((state) => ({ operator: {
		...state.operator,
		...patch
	} })),
	setPing: (id, ms) => set((state) => ({ pings: {
		...state.pings,
		[id]: {
			ms,
			at: Date.now()
		}
	} })),
	setPath: (id, ms) => set((state) => ({ paths: {
		...state.paths,
		[id]: {
			ms,
			at: Date.now()
		}
	} })),
	setGeo: (geo) => set({ geo: geo ? {
		...geo,
		at: Date.now()
	} : null })
}), {
	name: "sharif-range-v1",
	skipHydration: true
}));
var MODE_LABEL = {
	dns: "فقط DNS",
	wg: "فقط وایرگارد",
	both: "ترکیب هر دو"
};
function Dashboard({ onNavigate }) {
	const mode = useRange((s) => s.mode);
	const dnsId = useRange((s) => s.dnsId);
	const customs = useRange((s) => s.customs);
	const wgId = useRange((s) => s.wgId);
	const profiles = useRange((s) => s.profiles);
	const pings = useRange((s) => s.pings);
	const geo = useRange((s) => s.geo);
	const operator = useRange((s) => s.operator);
	const [mounted, setMounted] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setMounted(true);
	}, []);
	const dns = findDns(dnsId, customs);
	const profile = profiles.find((item) => item.id === wgId);
	const ping = pings[dns.id];
	const suggestions = recommendIds(geo?.countryCode).map((id) => DNS_CATALOG.find((item) => item.id === id)).filter((item) => item != null);
	const chart = DNS_CATALOG.map((item) => {
		const hit = pings[item.id];
		if (!hit || hit.ms == null) return null;
		return {
			name: item.name,
			ms: hit.ms
		};
	}).filter((item) => item != null).sort((a, b) => a.ms - b.ms).slice(0, 8);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "اپراتور"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-1 text-2xl font-extrabold",
					children: operator.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-sm text-muted",
					children: [
						"حالت فعال: ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-fg",
							children: MODE_LABEL[mode]
						}),
						geo ? ` · خروجی از ${countryFa(geo.countryCode, geo.country)}` : ""
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Waypoints, { className: "size-4 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm",
								children: "رزولور"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 font-semibold",
							children: dns.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							dir: "ltr",
							className: "mt-1 text-start font-mono text-sm text-muted",
							children: dnsPair(dns)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: `mt-2 font-mono text-sm ${pingTone(ping?.ms)}`,
							children: ping?.ms != null ? `${ping.ms} ms` : "هنوز سنجیده نشده"
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "size-4 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm",
								children: "وایرگارد"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 font-semibold",
							children: profile ? profile.name : "کانفیگی نیست"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: profile ? "روی دستگاه ذخیره شده" : "کانفیگ خریداری‌شده را اضافه کن"
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Activity, { className: "size-4 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm",
								children: "دستگاه"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 font-mono text-sm text-primary",
							children: operator.device
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-muted",
							children: [operator.fps, " FPS در پابجی · پروفایل ثبت‌شده"]
						})
					] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-semibold",
					children: "نزدیک به موقعیت تو"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					className: "h-9 px-3",
					onClick: () => onNavigate("tree"),
					children: "درخت رجیستر"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 flex gap-2 overflow-x-auto pb-1",
				children: suggestions.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => {
						useRange.getState().selectDns(item.id);
						onNavigate("dns");
					},
					className: "min-w-36 shrink-0 rounded-md border border-border bg-bg-raised px-3 py-3 text-start",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-sm font-semibold",
						children: item.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 block text-xs text-muted",
						children: item.region
					})]
				}, item.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-semibold",
					children: "تاخیر DoH رزولورها"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "میلی‌ثانیه تا خود رزولور، نه پینگ UDP سرور بازی."
				}),
				mounted && chart.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					dir: "ltr",
					className: "mt-3 h-52 w-full",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
						width: "100%",
						height: "100%",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
							data: chart,
							margin: {
								top: 8,
								right: 8,
								left: 0,
								bottom: 0
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
									dataKey: "name",
									tick: {
										fill: "var(--color-muted)",
										fontSize: 11
									},
									interval: 0,
									angle: -25,
									height: 56,
									textAnchor: "end"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
									tick: {
										fill: "var(--color-muted)",
										fontSize: 11
									},
									width: 36
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
									cursor: { fill: "transparent" },
									contentStyle: {
										background: "var(--color-bg-raised)",
										border: "1px solid var(--color-border)",
										borderRadius: 12,
										color: "var(--color-fg)"
									}
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
									dataKey: "ms",
									fill: "var(--color-primary)",
									radius: [
										6,
										6,
										0,
										0
									]
								})
							]
						})
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm text-muted",
					children: "از برگهٔ DNS یک دور پینگ بگیر تا نمودار پر شود."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => onNavigate("dns"),
					children: "سنجش DNS"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					onClick: () => onNavigate("link"),
					children: "ساخت پروفایل ترکیب"
				})]
			})
		]
	});
}
var PATH_BEACONS = [
	{
		id: "google-edge",
		name: "لبهٔ گوگل",
		region: "جهانی",
		url: "https://www.gstatic.com/generate_204",
		kind: "opaque"
	},
	{
		id: "cf-edge",
		name: "لبهٔ کلادفلر",
		region: "جهانی",
		url: "https://www.cloudflare.com/cdn-cgi/trace",
		kind: "opaque"
	},
	{
		id: "ms-edge",
		name: "لبهٔ مایکروسافت",
		region: "جهانی",
		url: "https://www.msftconnecttest.com/connecttest.txt",
		kind: "opaque"
	},
	{
		id: "ali-edge",
		name: "AliDNS",
		region: "آسیا",
		url: "https://dns.alidns.com/resolve",
		kind: "doh"
	},
	{
		id: "tencent-edge",
		name: "DNSPod تنسنت",
		region: "آسیا",
		url: "https://doh.pub/dns-query",
		kind: "doh"
	}
];
function withTimeout(signal, ms) {
	const ctrl = new AbortController();
	const timer = setTimeout(() => ctrl.abort(), ms);
	const onAbort = () => ctrl.abort();
	signal?.addEventListener("abort", onAbort);
	ctrl.signal.addEventListener("abort", () => {
		clearTimeout(timer);
		signal?.removeEventListener("abort", onAbort);
	});
	return ctrl.signal;
}
async function measureDoH(doh, signal) {
	const started = performance.now();
	try {
		const url = new URL(doh);
		url.searchParams.set("name", "pubgmobile.com");
		url.searchParams.set("type", "A");
		url.searchParams.set("ct", String(Date.now()));
		const headers = {};
		if (doh.includes("dns-query") || doh.includes("freedns.controld.com") || doh.includes("cleanbrowsing.org")) headers.Accept = "application/dns-json";
		const res = await fetch(url.toString(), {
			signal: withTimeout(signal, 5e3),
			cache: "no-store",
			headers
		});
		if (!res.ok) return null;
		await res.arrayBuffer();
		return Math.max(1, Math.round(performance.now() - started));
	} catch {
		return null;
	}
}
async function measureOpaque(url, signal) {
	const started = performance.now();
	try {
		await fetch(`${url}${url.includes("?") ? "&" : "?"}ct=${Date.now()}`, {
			mode: "no-cors",
			cache: "no-store",
			signal: withTimeout(signal, 5e3)
		});
		return Math.max(1, Math.round(performance.now() - started));
	} catch {
		return null;
	}
}
async function measureBeacon(beacon, signal) {
	if (beacon.kind === "doh") return measureDoH(beacon.url, signal);
	return measureOpaque(beacon.url, signal);
}
async function fetchGeo(signal) {
	const local = withTimeout(signal, 6e3);
	try {
		const res = await fetch("https://get.geojs.io/v1/ip/geo.json", {
			signal: local,
			cache: "no-store"
		});
		if (res.ok) {
			const data = await res.json();
			if (data.country_code) return {
				ip: String(data.ip ?? ""),
				country: String(data.country ?? ""),
				countryCode: String(data.country_code),
				city: String(data.city ?? "")
			};
		}
	} catch {}
	try {
		const res = await fetch("https://ipwho.is/", {
			signal: withTimeout(signal, 6e3),
			cache: "no-store"
		});
		if (!res.ok) return null;
		const data = await res.json();
		if (!data.success || !data.country_code) return null;
		return {
			ip: String(data.ip ?? ""),
			country: String(data.country ?? ""),
			countryCode: String(data.country_code),
			city: String(data.city ?? "")
		};
	} catch {
		return null;
	}
}
async function copyText(text) {
	try {
		await navigator.clipboard.writeText(text);
		return;
	} catch {}
	const area = document.createElement("textarea");
	area.value = text;
	area.setAttribute("readonly", "true");
	area.style.position = "fixed";
	area.style.opacity = "0";
	document.body.appendChild(area);
	area.select();
	document.execCommand("copy");
	area.remove();
}
function downloadText(filename, text, type = "text/plain;charset=utf-8") {
	const blob = new Blob([text], { type });
	const url = URL.createObjectURL(blob);
	const link = document.createElement("a");
	link.href = url;
	link.download = filename;
	document.body.appendChild(link);
	link.click();
	link.remove();
	URL.revokeObjectURL(url);
}
function DnsPanel() {
	const dnsId = useRange((s) => s.dnsId);
	const customs = useRange((s) => s.customs);
	const pings = useRange((s) => s.pings);
	const selectDns = useRange((s) => s.selectDns);
	const addCustom = useRange((s) => s.addCustom);
	const removeCustom = useRange((s) => s.removeCustom);
	const setPing = useRange((s) => s.setPing);
	const [query, setQuery] = (0, import_react.useState)("");
	const [filter, setFilter] = (0, import_react.useState)("همه");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [progress, setProgress] = (0, import_react.useState)("");
	const [openForm, setOpenForm] = (0, import_react.useState)(false);
	const [draft, setDraft] = (0, import_react.useState)({
		name: "",
		primary: "",
		secondary: "",
		note: ""
	});
	const list = (0, import_react.useMemo)(() => {
		const all = [...customs, ...DNS_CATALOG];
		const q = query.trim().toLowerCase();
		return all.filter((item) => {
			if (filter === "بازی" && !item.gaming) return false;
			if (filter !== "همه" && filter !== "بازی" && item.region !== filter) return false;
			if (!q) return true;
			return [
				item.name,
				item.provider,
				item.primary,
				item.secondary,
				item.note,
				item.pubg
			].join(" ").toLowerCase().includes(q);
		});
	}, [
		customs,
		filter,
		query
	]);
	async function scan(entries) {
		const targets = entries.filter((item) => item.doh);
		if (targets.length === 0) {
			toast("این رزولورها مسیر DoH برای سنجش مرورگر ندارند.");
			return;
		}
		setBusy(true);
		let index = 0;
		for (const item of targets) {
			index += 1;
			setProgress(`${index} از ${targets.length}`);
			const ms = await measureDoH(item.doh);
			setPing(item.id, ms);
		}
		setProgress("");
		setBusy(false);
		toast("سنجش تمام شد");
	}
	function saveCustom() {
		const primary = draft.primary.trim();
		const secondary = draft.secondary.trim();
		if (!draft.name.trim()) {
			toast.error("نام را بنویس");
			return;
		}
		if (!isIpv4(primary) || secondary && !isIpv4(secondary)) {
			toast.error("آدرس IPv4 معتبر نیست");
			return;
		}
		if (isPrivateIpv4(primary) || secondary && isPrivateIpv4(secondary)) toast("آدرس خصوصی است و فقط داخل شبکهٔ خودت جواب می‌دهد");
		const entry = {
			id: `custom-${crypto.randomUUID()}`,
			name: draft.name.trim(),
			provider: "سفارشی",
			primary,
			secondary: secondary || void 0,
			region: "جهانی",
			pubg: "رزولور خودت",
			note: draft.note.trim() || "اضافه‌شده روی همین دستگاه",
			gaming: true,
			filter: "هیچ"
		};
		addCustom(entry);
		setDraft({
			name: "",
			primary: "",
			secondary: "",
			note: ""
		});
		setOpenForm(false);
		toast("DNS اضافه شد و انتخاب شد");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xl font-extrabold",
						children: "کاتالوگ DNS"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "فقط رزولورهای عمومی شناخته‌شده. Mullvad DNS از نوامبر ۲۰۲۶ خاموش است. پینگ، تاخیر HTTPS تا خود رزولور است نه ICMP بازی."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: () => scan(list),
						disabled: busy,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: busy ? "spin size-4" : "size-4" }), busy ? progress : "پینگ همین فهرست"]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: query,
					onChange: (event) => setQuery(event.target.value),
					placeholder: "نام، آی‌پی یا توضیح",
					className: `${inputClass} mt-4`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 flex gap-2 overflow-x-auto pb-1",
					children: REGION_FILTERS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setFilter(item),
						className: `h-10 shrink-0 rounded-md px-3 text-sm ${filter === item ? "bg-primary text-primary-ink" : "border border-border bg-bg-raised text-muted"}`,
						children: item
					}, item))
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "ghost",
					onClick: () => setOpenForm((value) => !value),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "DNS خودم"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					onClick: () => scan(DNS_CATALOG.filter((item) => item.gaming)),
					disabled: busy,
					children: "فقط مناسب بازی"
				})]
			}),
			openForm && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "grid gap-3 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "نام",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: draft.name,
							onChange: (event) => setDraft({
								...draft,
								name: event.target.value
							}),
							className: "h-11 w-full rounded-md border border-border bg-bg px-3 text-base text-fg outline-none focus:border-primary"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "اصلی",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							dir: "ltr",
							value: draft.primary,
							onChange: (event) => setDraft({
								...draft,
								primary: event.target.value
							}),
							className: `h-11 w-full rounded-md border border-border bg-bg px-3 text-base text-fg outline-none focus:border-primary text-start font-mono`
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "ثانویه، اختیاری",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							dir: "ltr",
							value: draft.secondary,
							onChange: (event) => setDraft({
								...draft,
								secondary: event.target.value
							}),
							className: `h-11 w-full rounded-md border border-border bg-bg px-3 text-base text-fg outline-none focus:border-primary text-start font-mono`
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "یادداشت",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: draft.note,
							onChange: (event) => setDraft({
								...draft,
								note: event.target.value
							}),
							className: "h-11 w-full rounded-md border border-border bg-bg px-3 text-base text-fg outline-none focus:border-primary"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "sm:col-span-2",
						onClick: saveCustom,
						children: "ذخیره و انتخاب"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3",
				children: [list.map((item) => {
					const hit = pings[item.id];
					const selected = dnsId === item.id;
					const custom = item.id.startsWith("custom-");
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: `rounded-lg border p-4 ${selected ? "border-primary bg-surface" : "border-border bg-bg-raised"}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => selectDns(item.id),
									className: "min-w-0 flex-1 text-start",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "flex flex-wrap items-center gap-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-semibold",
												children: item.name
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "rounded-sm bg-bg px-2 py-0.5 text-xs text-muted",
												children: item.region
											}),
											item.gaming && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs text-primary",
												children: "بازی"
											}),
											selected && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs text-primary",
												children: "انتخاب شده"
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										dir: "ltr",
										className: "mt-2 block text-start font-mono text-sm",
										children: dnsPair(item)
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-end",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: `font-mono text-lg ${pingTone(hit?.ms)}`,
										children: hit ? hit.ms == null ? "—" : hit.ms : "–"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted",
										children: item.doh ? "ms DoH" : "بدون DoH"
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-fg",
								children: item.pubg
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted",
								children: item.note
							}),
							hit?.ms != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3 h-1.5 overflow-hidden rounded-sm bg-bg",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "bar-in h-full bg-primary",
									style: { width: `${Math.max(8, Math.min(100, 100 - hit.ms / 4))}%` }
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex flex-wrap gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										variant: "ghost",
										className: "h-10 px-3",
										onClick: async () => {
											await copyText(dnsPair(item));
											toast("آدرس کپی شد");
										},
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" }), "کپی"]
									}),
									item.dot && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "ghost",
										className: "h-10 px-3",
										onClick: async () => {
											await copyText(item.dot);
											toast("نام Private DNS کپی شد");
										},
										children: "Private DNS"
									}),
									item.doh && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "ghost",
										className: "h-10 px-3",
										disabled: busy,
										onClick: () => scan([item]),
										children: "پینگ"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "ghost",
										className: "h-10 px-3",
										onClick: () => selectDns(item.id),
										children: "انتخاب"
									}),
									custom && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										variant: "danger",
										className: "h-10 px-3",
										onClick: () => removeCustom(item.id),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" }), "حذف"]
									})
								]
							})
						]
					}, item.id);
				}), list.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, { children: "چیزی با این فیلتر پیدا نشد." })]
			})
		]
	});
}
var KEY_RE = /^[A-Za-z0-9+/]{43}=$/;
function parseWg(raw) {
	const errors = [];
	const map = {};
	let section = "";
	for (const line of raw.split(/\r?\n/)) {
		const trimmed = line.trim();
		if (!trimmed || trimmed.startsWith("#") || trimmed.startsWith(";")) continue;
		const header = trimmed.match(/^\[(.+)]$/);
		if (header) {
			section = header[1].trim().toLowerCase();
			continue;
		}
		const kv = trimmed.match(/^([^=]+)=(.*)$/);
		if (!kv || !section) continue;
		const key = `${section}.${kv[1].trim().toLowerCase()}`;
		if (map[key] === void 0) map[key] = kv[2].trim();
	}
	const privateKey = map["interface.privatekey"];
	const publicKey = map["peer.publickey"];
	if (!privateKey) errors.push("PrivateKey داخل [Interface] نیست.");
	else if (!KEY_RE.test(privateKey)) errors.push("PrivateKey شکل کلید WireGuard را ندارد.");
	if (!publicKey) errors.push("PublicKey داخل [Peer] نیست.");
	else if (!KEY_RE.test(publicKey)) errors.push("PublicKey نامعتبر است.");
	if (!map["interface.address"]) errors.push("Address نیست.");
	if (!map["peer.endpoint"]) errors.push("Endpoint نیست.");
	return {
		privateKey,
		address: map["interface.address"],
		dns: map["interface.dns"],
		mtu: map["interface.mtu"],
		publicKey,
		endpoint: map["peer.endpoint"],
		allowedIps: map["peer.allowedips"],
		keepalive: map["peer.persistentkeepalive"],
		errors
	};
}
function maskKey(value) {
	if (!value) return "—";
	if (value.length < 10) return "••••";
	return `${value.slice(0, 4)}…${value.slice(-4)}`;
}
function applyDns(raw, dnsValue) {
	const lines = raw.replace(/\r\n/g, "\n").split("\n");
	let section = "none";
	let wrote = false;
	const out = [];
	const flush = () => {
		if (section === "interface" && !wrote) {
			out.push(`DNS = ${dnsValue}`);
			wrote = true;
		}
	};
	for (const line of lines) {
		const trimmed = line.trim();
		if (/^\[/.test(trimmed)) {
			flush();
			section = trimmed.toLowerCase() === "[interface]" ? "interface" : "other";
			out.push(line);
			continue;
		}
		if (section === "interface" && /^dns\s*=/i.test(trimmed)) {
			if (!wrote) {
				out.push(`DNS = ${dnsValue}`);
				wrote = true;
			}
			continue;
		}
		out.push(line);
	}
	flush();
	return `${out.join("\n").replace(/\n{3,}/g, "\n\n").trim()}\n`;
}
function confForMode(raw, dnsValue, mode) {
	if (mode === "both") return applyDns(raw, dnsValue);
	return raw.endsWith("\n") ? raw : `${raw}\n`;
}
function endpointHost(endpoint) {
	if (!endpoint) return "وایرگارد";
	return endpoint.replace(/:\d+$/, "");
}
var MODE_COPY = {
	dns: "فقط رزولور اعمال می‌شود. تونل را روشن نکن. DNS خریده‌شدهٔ داخل وایرگارد دست نمی‌خورد.",
	wg: "فایل همان‌طور که خریدی می‌ماند، شامل DNS خودش اگر داشته باشد. رزولور انتخابی جداگانه اعمال نمی‌شود.",
	both: "DNS انتخابی داخل [Interface] نوشته می‌شود تا تونل همان رزولور را استفاده کند. لازم نیست جداگانه DNS گوشی را عوض کنی."
};
function LinkPanel() {
	const mode = useRange((s) => s.mode);
	const dnsId = useRange((s) => s.dnsId);
	const customs = useRange((s) => s.customs);
	const wgId = useRange((s) => s.wgId);
	const profiles = useRange((s) => s.profiles);
	const [armed, setArmed] = (0, import_react.useState)(false);
	const dns = findDns(dnsId, customs);
	const profile = profiles.find((item) => item.id === wgId) ?? null;
	const pair = dnsPair(dns);
	const output = (0, import_react.useMemo)(() => {
		if (!profile) return "";
		return confForMode(profile.raw, pair, mode);
	}, [
		mode,
		pair,
		profile
	]);
	const needsWg = mode !== "dns";
	function arm() {
		if (needsWg && !profile) {
			toast.error("اول یک کانفیگ وایرگارد انتخاب کن");
			return;
		}
		if (needsWg && profile && parseWg(profile.raw).errors.length) {
			toast.error("کانفیگ انتخاب‌شده ناقص است");
			return;
		}
		setArmed(true);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl font-extrabold",
					children: "ترکیب و اعمال"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: MODE_COPY[mode]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted",
					children: "این برنامه تونل را بالا نمی‌آورد و DNS سیستم را عوض نمی‌کند. مرورگر، و بستهٔ وبی که به APK تبدیل شود، اجازهٔ VpnService اندروید را ندارد. پروفایل را می‌سازد؛ اعمال با تنظیمات گوشی یا اپ رسمی WireGuard است."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-4 w-full",
					onClick: arm,
					children: "بستن پروفایل"
				})
			] }),
			armed && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "rise",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-primary",
						children: "پروفایل مسلح شد — هنوز روی سیستم اعمال نشده"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
						className: "mt-3 list-decimal space-y-2 ps-5 text-sm",
						children: [
							mode !== "wg" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
								"رزولور ",
								dns.name,
								":",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									dir: "ltr",
									className: "font-mono",
									children: pair
								}),
								dns.dot ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
									". در اندروید: تنظیمات، شبکه، Private DNS، نام میزبان",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										dir: "ltr",
										className: "font-mono",
										children: dns.dot
									}),
									"."
								] }) : ". اگر نام DoT ندارد، وای‌فای را استاتیک کن و همین دو آدرس را در DNS بگذار. این فقط همان وای‌فای است."
							] }),
							mode === "dns" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "وایرگارد را خاموش بگذار تا DNS گوشی دست‌نخورده بماند." }),
							mode === "wg" && profile && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
								"فایل اصلی «",
								profile.name,
								"» را در اپ WireGuard وارد کن و تونل را از همان‌جا روشن کن."
							] }),
							mode === "both" && profile && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "فایل ترکیب‌شده را دانلود کن. خط DNS داخل Interface همان رزولور انتخابی است. در WireGuard ایمپورت کن و سوئیچ تونل را آنجا بزن." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "پابجی را بعد از اعمال باز کن. رجیستر سرور را این صفحه تضمین نمی‌کند." })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap gap-2",
						children: [
							mode !== "wg" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								onClick: async () => {
									await copyText(pair);
									toast("DNS کپی شد");
								},
								children: "کپی DNS"
							}),
							dns.dot && mode !== "wg" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								onClick: async () => {
									await copyText(dns.dot);
									toast("نام Private DNS کپی شد");
								},
								children: "کپی Private DNS"
							}),
							needsWg && profile && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								onClick: () => {
									downloadText(`${profile.name.replace(/\s+/g, "-")}.conf`, output);
									toast("فایل کانفیگ دانلود شد");
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), "دانلود conf"]
							})
						]
					}),
					needsWg && output && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
						dir: "ltr",
						className: "mt-4 max-h-64 overflow-auto rounded-md bg-bg p-3 text-start font-mono text-xs leading-relaxed text-fg",
						children: output.replace(/PrivateKey\s*=\s*\S+/i, "PrivateKey = ••••")
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-semibold",
					children: "بسته برای گوشی"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "فایل زیپ یک نسخهٔ آفلاین از همین کنسول است. اگر آن را به APK وب‌ویو تبدیل کنی، ظاهر برنامه را داری ولی همچنان باید DNS را در تنظیمات و وایرگارد را در اپ رسمی روشن کنی."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "/sharif-range.zip",
					download: true,
					className: "mt-4 inline-flex h-11 items-center justify-center rounded-md border border-border bg-bg-raised px-4 text-sm font-semibold",
					children: "دانلود زیپ"
				})
			] })
		]
	});
}
function RegisterPanel() {
	const geo = useRange((s) => s.geo);
	const paths = useRange((s) => s.paths);
	const setGeo = useRange((s) => s.setGeo);
	const setPath = useRange((s) => s.setPath);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const active = clusterFor(geo?.countryCode);
	async function read() {
		setBusy(true);
		const place = await fetchGeo();
		setGeo(place);
		if (!place) toast.error("موقعیت شبکه خوانده نشد");
		for (const beacon of PATH_BEACONS) {
			const ms = await measureBeacon(beacon);
			setPath(beacon.id, ms);
		}
		setBusy(false);
		toast(place ? "نقطهٔ شبکه به‌روز شد" : "فقط مسیرها سنجیده شد");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl font-extrabold",
					children: "درخت رجیستر"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: REGISTER_NOTE
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: read,
					disabled: busy,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radar, { className: busy ? "spin size-4" : "size-4" }), busy ? "در حال خواندن" : "خواندن رجیستر"]
				})]
			}), geo && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-md border border-border bg-bg-raised p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: "کشور خروجی"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 font-semibold",
							children: countryFa(geo.countryCode, geo.country)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-md border border-border bg-bg-raised p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: "شهر تقریبی"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 font-semibold",
							children: geo.city || "—"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-md border border-border bg-bg-raised p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: "IP خروجی"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							dir: "ltr",
							className: "mt-1 text-start font-mono text-sm",
							children: geo.ip || "—"
						})]
					})
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-semibold",
				children: "خوشه‌های پابجی"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "relative mt-4 border-s border-line ps-5",
				children: CLUSTERS.map((cluster) => {
					const on = active?.id === cluster.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "relative mb-3 last:mb-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `absolute -start-[1.4rem] top-4 size-3 rounded-full ${on ? "bg-primary" : "bg-line"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `rounded-md border p-3 ${on ? "border-primary bg-bg-raised" : "border-border"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-semibold",
									children: cluster.title
								}), on && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-primary",
									children: "رجیستر محتمل"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted",
								children: cluster.hint
							})]
						})]
					}, cluster.id);
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-semibold",
					children: "تاخیر مسیرهای وب"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "این‌ها لبهٔ HTTPS هستند، نه پورت UDP بازی. برای مقایسهٔ مسیر به درد می‌خورند."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 flex flex-col gap-2",
					children: PATH_BEACONS.map((beacon) => {
						const hit = paths[beacon.id];
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-3 rounded-md bg-bg-raised px-3 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold",
								children: beacon.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: beacon.region
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: `font-mono ${pingTone(hit?.ms)}`,
								children: hit ? hit.ms == null ? "بدون پاسخ" : `${hit.ms} ms` : "—"
							})]
						}, beacon.id);
					})
				})
			] })
		]
	});
}
function Splash({ operator, onEnter }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center bg-bg px-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hud-grid pointer-events-none absolute inset-0 opacity-70" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rise relative flex w-full max-w-md flex-col items-center text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative mb-8 size-36",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 rounded-full border border-line" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-4 rounded-full border border-line" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-8 rounded-full border border-primary" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "radar-sweep absolute inset-0 rounded-full" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 m-auto size-2 rounded-full bg-primary" })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "خوش آمدید"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 text-3xl font-extrabold leading-tight",
					children: operator.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 font-mono text-sm text-primary",
					children: [
						operator.device,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted",
							children: " · "
						}),
						operator.fps,
						" FPS",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted",
							children: " · PUBG"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-6 w-full space-y-2 text-start text-sm text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "rounded-md border border-border bg-surface px-3 py-2",
							children: "پروفایل اپراتور بارگذاری شد"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "rounded-md border border-border bg-surface px-3 py-2",
							children: "کاتالوگ رزولورهای عمومی آماده است"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "rounded-md border border-border bg-surface px-3 py-2",
							children: "وایرگارد فقط روی همین دستگاه می‌ماند"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-8 w-full",
					onClick: onEnter,
					children: "ورود به رنج"
				})
			]
		})]
	});
}
function WgPanel() {
	const profiles = useRange((s) => s.profiles);
	const wgId = useRange((s) => s.wgId);
	const addProfile = useRange((s) => s.addProfile);
	const removeProfile = useRange((s) => s.removeProfile);
	const selectWg = useRange((s) => s.selectWg);
	const [name, setName] = (0, import_react.useState)("");
	const [raw, setRaw] = (0, import_react.useState)("");
	function save(text, label) {
		const trimmed = text.trim();
		if (trimmed.length < 20 || trimmed.length > 2e4) {
			toast.error("متن کانفیگ خالی یا بیش از حد بلند است");
			return;
		}
		const parsed = parseWg(trimmed);
		if (parsed.errors.length) {
			toast.error(parsed.errors[0]);
			return;
		}
		const profileName = (label || name).trim() || endpointHost(parsed.endpoint);
		addProfile({
			id: crypto.randomUUID(),
			name: profileName,
			raw: trimmed,
			createdAt: Date.now()
		});
		setRaw("");
		setName("");
		toast("کانفیگ ذخیره شد. کلید خصوصی از این دستگاه خارج نمی‌شود.");
	}
	async function onFile(file) {
		if (file.size > 64e3) {
			toast.error("فایل بزرگ‌تر از حد کانفیگ است");
			return;
		}
		save(await file.text(), file.name.replace(/\.conf$/i, ""));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl font-extrabold",
					children: "وایرگارد"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "کانفیگی که خریدی را بچسبان یا فایل .conf را بیاور. هیچ‌چیز به سرور این برنامه فرستاده نمی‌شود و فقط در حافظهٔ همین مرورگر می‌ماند."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "نام پروفایل",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: name,
								onChange: (event) => setName(event.target.value),
								placeholder: "مثلاً سرور فرانکفورت",
								className: inputClass
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "متن کانفیگ",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								dir: "ltr",
								value: raw,
								onChange: (event) => setRaw(event.target.value),
								placeholder: "[Interface]\nPrivateKey = \nAddress = 10.0.0.2/32\n\n[Peer]\nPublicKey = \nEndpoint = host:51820\nAllowedIPs = 0.0.0.0/0",
								className: `${inputClass} h-40 py-3 text-start font-mono text-sm`
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: () => save(raw),
								children: "ذخیرهٔ کانفیگ"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "inline-flex h-11 cursor-pointer items-center justify-center rounded-md border border-border bg-bg-raised px-4 text-sm font-semibold",
								children: ["انتخاب فایل", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "file",
									accept: ".conf,text/plain",
									className: "sr-only",
									onChange: (event) => {
										const file = event.target.files?.[0];
										if (file) onFile(file);
										event.target.value = "";
									}
								})]
							})]
						})
					]
				})
			] }),
			profiles.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-semibold",
				children: "هنوز کانفیگی نیست"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "بعد از خرید، خروجی WireGuard را همین‌جا وارد کن. نمونهٔ داخل کادر کلید واقعی نیست."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-col gap-3",
				children: profiles.map((profile) => {
					const parsed = parseWg(profile.raw);
					const selected = wgId === profile.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: `rounded-lg border p-4 ${selected ? "border-primary bg-surface" : "border-border bg-bg-raised"}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-semibold",
									children: profile.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									dir: "ltr",
									className: "mt-1 text-start font-mono text-sm text-muted",
									children: parsed.endpoint || "بدون Endpoint"
								})] }), selected && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-primary",
									children: "فعال در پروفایل"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
								className: "mt-3 grid gap-2 text-sm sm:grid-cols-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-muted",
										children: "Address"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										dir: "ltr",
										className: "text-start font-mono",
										children: parsed.address || "—"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-muted",
										children: "DNS داخل فایل"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										dir: "ltr",
										className: "text-start font-mono",
										children: parsed.dns || "ندارد"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-muted",
										children: "کلید خصوصی"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										dir: "ltr",
										className: "text-start font-mono",
										children: maskKey(parsed.privateKey)
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-muted",
										children: "AllowedIPs"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										dir: "ltr",
										className: "text-start font-mono",
										children: parsed.allowedIps || "—"
									})] })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex flex-wrap gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									className: "h-10 px-3",
									onClick: () => selectWg(profile.id),
									children: "انتخاب"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "danger",
									className: "h-10 px-3",
									onClick: () => removeProfile(profile.id),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" }), "حذف"]
								})]
							})
						]
					}, profile.id);
				})
			})
		]
	});
}
var TABS = [
	{
		id: "home",
		label: "خانه",
		icon: House
	},
	{
		id: "dns",
		label: "DNS",
		icon: Server
	},
	{
		id: "tree",
		label: "رجیستر",
		icon: Waypoints
	},
	{
		id: "wg",
		label: "وایرگارد",
		icon: Shield
	},
	{
		id: "link",
		label: "ترکیب",
		icon: Link2
	}
];
var MODES = [
	{
		id: "dns",
		label: "فقط DNS",
		hint: "فقط رزولور. تونل دست نمی‌خورد."
	},
	{
		id: "wg",
		label: "فقط وایرگارد",
		hint: "کانفیگ خریداری‌شده، بدون دستکاری DNS."
	},
	{
		id: "both",
		label: "ترکیب هر دو",
		hint: "همان وایرگارد، با DNS انتخابی داخل تونل."
	}
];
function RangeApp() {
	const [tab, setTab] = (0, import_react.useState)("home");
	const [splash, setSplash] = (0, import_react.useState)(true);
	const [settings, setSettings] = (0, import_react.useState)(false);
	const mode = useRange((s) => s.mode);
	const setMode = useRange((s) => s.setMode);
	const operator = useRange((s) => s.operator);
	const setOperator = useRange((s) => s.setOperator);
	const active = MODES.find((item) => item.id === mode) ?? MODES[2];
	(0, import_react.useEffect)(() => {
		useRange.persist.rehydrate();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				position: "top-center",
				toastOptions: { style: {
					background: "var(--color-surface)",
					color: "var(--color-fg)",
					border: "1px solid var(--color-border)",
					fontFamily: "var(--font-sans)"
				} }
			}),
			splash && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Splash, {
				operator,
				onEnter: () => setSplash(false)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-20 border-b border-border bg-bg/95 backdrop-blur",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-5xl items-center justify-between gap-3 px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: "RANGE"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "truncate text-lg font-extrabold",
							children: "شریف‌رنج"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-end",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-mono text-xs text-primary",
								children: operator.device
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted",
								children: [operator.fps, " FPS · PUBG"]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": "مشخصات دستگاه",
							onClick: () => setSettings(true),
							className: "inline-flex size-11 items-center justify-center rounded-md border border-border bg-bg-raised",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "size-4" })
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto flex w-full max-w-5xl flex-col gap-4 px-4 pt-4 pb-28",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						role: "radiogroup",
						"aria-label": "حالت اتصال",
						className: "grid grid-cols-3 gap-1 rounded-lg border border-border bg-bg-raised p-1",
						children: MODES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							role: "radio",
							"aria-checked": mode === item.id,
							onClick: () => setMode(item.id),
							className: cn("h-11 rounded-md px-1 text-sm font-semibold", mode === item.id ? "bg-primary text-primary-ink" : "text-muted"),
							children: item.label
						}, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: active.hint
					}),
					tab === "home" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dashboard, { onNavigate: setTab }),
					tab === "dns" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DnsPanel, {}),
					tab === "tree" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RegisterPanel, {}),
					tab === "wg" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WgPanel, {}),
					tab === "link" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LinkPanel, {})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-30 border-t border-border bg-bg-raised/95 backdrop-blur",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto flex max-w-3xl pb-[max(0.25rem,env(safe-area-inset-bottom))]",
					children: TABS.map((item) => {
						const Icon = item.icon;
						const on = tab === item.id;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setTab(item.id),
							className: cn("flex h-16 flex-1 flex-col items-center justify-center gap-1 text-xs", on ? "text-primary" : "text-muted"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" }), item.label]
						}, item.id);
					})
				})
			}),
			settings && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsSheet, {
				operator,
				onClose: () => setSettings(false),
				onSave: (next) => {
					setOperator(next);
					setSettings(false);
				}
			})
		]
	});
}
function SettingsSheet({ operator, onClose, onSave }) {
	const [draft, setDraft] = (0, import_react.useState)(operator);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-40 flex items-end justify-center bg-bg/80 sm:items-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			className: "m-4 w-full max-w-md",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-extrabold",
					children: "مشخصات دستگاه"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "این پروفایل نمایشی است، نه اسپوف برای بازی."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-col gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "نام",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: draft.name,
								onChange: (event) => setDraft({
									...draft,
									name: event.target.value
								}),
								className: inputClass
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "دستگاه",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								dir: "ltr",
								value: draft.device,
								onChange: (event) => setDraft({
									...draft,
									device: event.target.value
								}),
								className: `${inputClass} text-start font-mono`
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "فریم هدف در پابجی",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								dir: "ltr",
								inputMode: "numeric",
								value: draft.fps,
								onChange: (event) => setDraft({
									...draft,
									fps: Number(event.target.value) || 0
								}),
								className: `${inputClass} text-start font-mono`
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "flex-1",
						onClick: () => {
							const fps = Math.min(144, Math.max(1, Math.round(draft.fps)));
							onSave({
								name: draft.name.trim() || operator.name,
								device: draft.device.trim() || operator.device,
								fps
							});
						},
						children: "ذخیره"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						className: "flex-1",
						onClick: onClose,
						children: "بستن"
					})]
				})
			]
		})
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RangeApp, {});
}
//#endregion
export { Home as component };
