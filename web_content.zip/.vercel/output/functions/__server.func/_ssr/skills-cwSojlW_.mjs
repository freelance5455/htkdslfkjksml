import { i as __toESM } from "../_runtime.mjs";
import { _ as require_react, g as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { C as privilegeLabel, T as useMinistry, c as SKILL_META, i as Card, p as cn, s as PageIntro, t as AppShell, v as fullName } from "./shell-CGpvgZIy.mjs";
import { t as SKILL_IDS } from "./types-djekE3oG.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/skills-cwSojlW_.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SkillsPage() {
	const members = useMinistry((state) => state.members);
	const setSkill = useMinistry((state) => state.setSkill);
	const [active, setActive] = (0, import_react.useState)("treasures");
	const meta = SKILL_META[active];
	const ranked = [...members].map((member) => ({
		member,
		value: member.skills[active] ?? 0
	})).sort((a, b) => b.value - a.value || a.member.lastName.localeCompare(b.member.lastName));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
			eyebrow: "Abilities",
			title: "Abilities & skills",
			lede: "See who can carry each part, and adjust a rating when someone has grown."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-3 sm:grid-cols-2 xl:grid-cols-3",
			children: SKILL_IDS.map((skill) => {
				const qualified = members.filter((member) => (member.skills[skill] ?? 0) >= 70).length;
				const average = Math.round(members.reduce((sum, member) => sum + (member.skills[skill] ?? 0), 0) / Math.max(members.length, 1));
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setActive(skill),
					className: cn("tap rounded-3xl border bg-card p-4 text-left shadow-card", active === skill ? "border-royal" : "border-line"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold tracking-wide text-royal uppercase",
							children: SKILL_META[skill].group
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-1 font-sans text-lg font-semibold tracking-normal",
							children: SKILL_META[skill].label
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: SKILL_META[skill].blurb
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 h-2 overflow-hidden rounded-full bg-soft",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-full rounded-full bg-royal",
								style: { width: `${average}%` }
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-xs text-muted tabular-nums",
							children: [
								qualified,
								" qualified · average ",
								average
							]
						})
					]
				}, skill);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "mt-5 p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-3xl",
					children: meta.label
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: meta.blurb
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-5 space-y-4",
					children: ranked.map(({ member, value }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-1 flex items-center justify-between gap-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 truncate font-semibold",
							children: [fullName(member), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-2 font-normal text-muted",
								children: privilegeLabel(member.privilege)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums text-muted",
							children: value
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "range",
						min: 0,
						max: 100,
						value,
						"aria-label": `${meta.label} for ${fullName(member)}`,
						onChange: (event) => setSkill(member.id, active, Number(event.target.value)),
						className: "w-full accent-royal"
					})] }, member.id))
				})
			]
		})
	] });
}
var SplitComponent = function SkillsRoute() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkillsPage, {}) });
};
//#endregion
export { SplitComponent as component };
