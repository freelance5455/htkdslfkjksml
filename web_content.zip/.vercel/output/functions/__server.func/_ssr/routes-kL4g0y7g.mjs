import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Plus, c as ChevronRight, i as Trash2, l as ChevronLeft, n as Users, o as Package, s as House, t as Wallet, u as CalendarDays } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-kL4g0y7g.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var KEY = "doce_confeito_v1";
var EMPTY = {
	stock: [],
	clients: [],
	orders: [],
	cash: [],
	activities: []
};
var db = EMPTY;
var listeners = /* @__PURE__ */ new Set();
var hydrated = false;
function emit() {
	if (typeof localStorage !== "undefined") localStorage.setItem(KEY, JSON.stringify(db));
	listeners.forEach((l) => l());
}
function subscribe(l) {
	listeners.add(l);
	return () => listeners.delete(l);
}
function get() {
	return db;
}
function uid() {
	return crypto.randomUUID();
}
function dateKey(d = /* @__PURE__ */ new Date()) {
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function parseDate(s) {
	const [y, m, d] = s.split("-").map(Number);
	return new Date(y, (m || 1) - 1, d || 1);
}
function fmtLong(s) {
	return parseDate(s).toLocaleDateString("pt-BR", {
		day: "numeric",
		month: "long",
		year: "numeric"
	});
}
function fmtShort(s) {
	return parseDate(s).toLocaleDateString("pt-BR", {
		day: "numeric",
		month: "short"
	});
}
function money(n) {
	return (Number(n) || 0).toLocaleString("pt-BR", {
		style: "currency",
		currency: "BRL"
	});
}
function troco(day) {
	const vendas = day.moves.filter((m) => m.kind === "venda").reduce((s, m) => s + m.amount, 0);
	const compras = day.moves.filter((m) => m.kind === "compra").reduce((s, m) => s + m.amount, 0);
	return day.initial + vendas - compras;
}
function lucro(day) {
	if (day.counted == null) return null;
	return day.counted - day.initial;
}
function orderPhrase(lines) {
	if (!lines.length) return "sem itens";
	const bits = lines.map((l) => `${l.qty} ${l.name}`);
	if (bits.length === 1) return bits[0];
	return `${bits.slice(0, -1).join(", ")}, mais ${bits[bits.length - 1]}`;
}
function hydrate() {
	if (hydrated || typeof localStorage === "undefined") return;
	hydrated = true;
	try {
		const raw = localStorage.getItem(KEY);
		if (raw) {
			const parsed = JSON.parse(raw);
			db = {
				stock: Array.isArray(parsed.stock) ? parsed.stock : [],
				clients: Array.isArray(parsed.clients) ? parsed.clients : [],
				orders: Array.isArray(parsed.orders) ? parsed.orders : [],
				cash: Array.isArray(parsed.cash) ? parsed.cash : [],
				activities: Array.isArray(parsed.activities) ? parsed.activities : []
			};
			listeners.forEach((l) => l());
		}
	} catch {
		db = EMPTY;
	}
}
function useDB() {
	const data = (0, import_react.useSyncExternalStore)(subscribe, get, get);
	(0, import_react.useEffect)(() => {
		hydrate();
	}, []);
	return data;
}
function update(fn) {
	const next = {
		stock: db.stock.map((x) => ({ ...x })),
		clients: db.clients.map((x) => ({ ...x })),
		orders: db.orders.map((x) => ({
			...x,
			lines: x.lines.map((l) => ({ ...l }))
		})),
		cash: db.cash.map((x) => ({
			...x,
			moves: x.moves.map((m) => ({ ...m }))
		})),
		activities: db.activities.map((x) => ({ ...x }))
	};
	fn(next);
	db = next;
	emit();
}
function openCash(date, initial) {
	update((d) => {
		if (d.cash.some((c) => !c.closed)) return;
		if (d.cash.some((c) => c.date === date)) return;
		d.cash.unshift({
			date,
			initial,
			moves: [],
			closed: false,
			counted: null
		});
	});
}
function addMove(date, kind, amount, note) {
	update((d) => {
		const day = d.cash.find((c) => c.date === date && !c.closed);
		if (!day || amount <= 0) return;
		day.moves.unshift({
			id: uid(),
			kind,
			amount,
			note: note.trim(),
			at: (/* @__PURE__ */ new Date()).toISOString()
		});
	});
}
function removeMove(date, id) {
	update((d) => {
		const day = d.cash.find((c) => c.date === date && !c.closed);
		if (!day) return;
		day.moves = day.moves.filter((m) => m.id !== id);
	});
}
function closeCash(date, counted) {
	update((d) => {
		const day = d.cash.find((c) => c.date === date && !c.closed);
		if (!day) return;
		day.closed = true;
		day.counted = counted;
	});
}
function reopenCash(date) {
	update((d) => {
		if (d.cash.some((c) => !c.closed)) return;
		const day = d.cash.find((c) => c.date === date);
		if (!day) return;
		day.closed = false;
		day.counted = null;
	});
}
function saveClient(input) {
	const name = input.name.trim();
	if (!name) return;
	update((d) => {
		if (input.id) {
			const c = d.clients.find((x) => x.id === input.id);
			if (c) {
				c.name = name;
				c.phone = input.phone.trim();
			}
		} else d.clients.unshift({
			id: uid(),
			name,
			phone: input.phone.trim(),
			status: "ok"
		});
	});
}
function setClientStatus(id, status) {
	update((d) => {
		const c = d.clients.find((x) => x.id === id);
		if (c) c.status = status;
	});
}
function deleteClient(id) {
	update((d) => {
		d.clients = d.clients.filter((c) => c.id !== id);
		d.orders = d.orders.filter((o) => o.clientId !== id);
	});
}
function saveStock(input) {
	const name = input.name.trim();
	if (!name) return;
	update((d) => {
		if (input.id) {
			const s = d.stock.find((x) => x.id === input.id);
			if (s) {
				s.name = name;
				s.qty = input.qty;
				s.unit = input.unit.trim() || "un";
				s.kind = input.kind;
			}
		} else d.stock.unshift({
			id: uid(),
			name,
			qty: input.qty,
			unit: input.unit.trim() || "un",
			kind: input.kind
		});
	});
}
function adjustStock(id, delta) {
	update((d) => {
		const s = d.stock.find((x) => x.id === id);
		if (!s) return;
		s.qty = Math.max(0, Math.round((s.qty + delta) * 1e3) / 1e3);
	});
}
function deleteStock(id) {
	update((d) => {
		d.stock = d.stock.filter((s) => s.id !== id);
	});
}
function addOrder(clientId, lines, total) {
	if (!clientId || !lines.length) return;
	update((d) => {
		d.orders.unshift({
			id: uid(),
			clientId,
			lines: lines.map((l) => ({ ...l })),
			total,
			status: "pendente",
			date: dateKey()
		});
		const client = d.clients.find((c) => c.id === clientId);
		if (client) client.status = "pendente";
		for (const line of lines) {
			const item = d.stock.find((s) => s.id === line.stockId);
			if (item) item.qty = Math.max(0, Math.round((item.qty - line.qty) * 1e3) / 1e3);
		}
	});
}
function deliverOrder(id) {
	update((d) => {
		const order = d.orders.find((o) => o.id === id);
		if (!order) return;
		order.status = "entregue";
		if (!d.orders.some((o) => o.clientId === order.clientId && o.status === "pendente")) {
			const client = d.clients.find((c) => c.id === order.clientId);
			if (client && client.status === "pendente") client.status = "ok";
		}
	});
}
function deleteOrder(id) {
	update((d) => {
		const order = d.orders.find((o) => o.id === id);
		if (!order) return;
		if (order.status === "pendente") for (const line of order.lines) {
			const item = d.stock.find((s) => s.id === line.stockId);
			if (item) item.qty = Math.round((item.qty + line.qty) * 1e3) / 1e3;
		}
		d.orders = d.orders.filter((o) => o.id !== id);
		if (!d.orders.some((o) => o.clientId === order.clientId && o.status === "pendente")) {
			const client = d.clients.find((c) => c.id === order.clientId);
			if (client && client.status === "pendente") client.status = "ok";
		}
	});
}
function saveActivity(input) {
	const title = input.title.trim();
	if (!title) return;
	update((d) => {
		if (input.id) {
			const a = d.activities.find((x) => x.id === input.id);
			if (a) {
				a.title = title;
				a.date = input.date;
				a.time = input.time;
				a.type = input.type;
				a.category = input.category;
				a.notes = input.notes.trim();
			}
		} else d.activities.unshift({
			id: uid(),
			title,
			date: input.date,
			time: input.time,
			type: input.type,
			category: input.category,
			notes: input.notes.trim(),
			done: false
		});
	});
}
function toggleActivity(id) {
	update((d) => {
		const a = d.activities.find((x) => x.id === id);
		if (a) a.done = !a.done;
	});
}
function deleteActivity(id) {
	update((d) => {
		d.activities = d.activities.filter((a) => a.id !== id);
	});
}
var STATUS = [
	{
		id: "ok",
		label: "OK"
	},
	{
		id: "devendo",
		label: "Devendo"
	},
	{
		id: "pendente",
		label: "Pedido pendente"
	}
];
function statusClass(s) {
	if (s === "ok") return "bg-good/10 text-good";
	if (s === "devendo") return "bg-blush text-primary";
	return "bg-gold/15 text-gold";
}
function DoceApp() {
	const [tab, setTab] = (0, import_react.useState)("inicio");
	const db = useDB();
	const today = dateKey();
	const open = db.cash.find((c) => !c.closed) ?? null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto min-h-dvh max-w-lg pb-28",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "px-5 pt-6 pb-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-xl text-wine",
					children: "Doce Confeito"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: fmtLong(today)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "px-4",
				children: [
					tab === "inicio" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Inicio, {
						db,
						open,
						today,
						go: setTab
					}),
					tab === "caixa" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Caixa, {
						db,
						open,
						today
					}),
					tab === "clientes" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clientes, { db }),
					tab === "estoque" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Estoque, { db }),
					tab === "agenda" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Agenda, {
						db,
						today
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-30 border-t border-line bg-paper/95 backdrop-blur",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto grid max-w-lg grid-cols-5 pb-[env(safe-area-inset-bottom)]",
					children: [
						[
							"inicio",
							"Início",
							House
						],
						[
							"caixa",
							"Caixa",
							Wallet
						],
						[
							"clientes",
							"Clientes",
							Users
						],
						[
							"estoque",
							"Estoque",
							Package
						],
						[
							"agenda",
							"Agenda",
							CalendarDays
						]
					].map(([id, label, Icon]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setTab(id),
						className: `flex min-h-16 flex-col items-center justify-center gap-1 text-xs ${tab === id ? "font-semibold text-primary" : "text-muted"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
							size: 20,
							strokeWidth: tab === id ? 2.4 : 1.8
						}), label]
					}, id))
				})
			})
		]
	});
}
function Inicio({ db, open, today, go }) {
	const todayActs = db.activities.filter((a) => a.date === today && !a.done).sort((a, b) => (a.time || "99").localeCompare(b.time || "99"));
	const pending = db.orders.filter((o) => o.status === "pendente");
	const low = db.stock.filter((s) => s.qty <= 2);
	const closedToday = db.cash.find((c) => c.date === today && c.closed);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 text-3xl text-wine",
				children: "Hoje na loja"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => go("caixa"),
				className: "card w-full text-left",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold tracking-wide text-muted uppercase",
					children: "Fluxo de caixa"
				}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 font-display text-2xl text-wine",
					children: money(troco(open))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						"Troco em caixa · aberto em ",
						fmtLong(open.date),
						" · inicial ",
						money(open.initial)
					]
				})] }) : closedToday ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 font-display text-2xl text-good",
					children: ["Lucro ", money(lucro(closedToday) ?? 0)]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Caixa de hoje já fechado"
				})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-base",
					children: "Caixa ainda não aberto. Toque para começar o dia."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => go("clientes"),
					className: "card text-left",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: "Pedidos pendentes"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl text-wine",
						children: pending.length
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => go("estoque"),
					className: "card text-left",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: "Estoque baixo"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl text-wine",
						children: low.length
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-2 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl text-wine",
					children: "Agenda de hoje"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "text-sm font-semibold text-primary",
					onClick: () => go("agenda"),
					children: "Ver tudo"
				})]
			}), todayActs.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "card text-sm text-muted",
				children: "Nada marcado para hoje."
			}) : todayActs.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "card mb-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-semibold",
					children: a.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						a.time || "Sem horário",
						" · ",
						a.type
					]
				})]
			}, a.id))] })
		]
	});
}
function Caixa({ db, open, today }) {
	const [date, setDate] = (0, import_react.useState)(today);
	const [initial, setInitial] = (0, import_react.useState)("");
	const [sheet, setSheet] = (0, import_react.useState)(null);
	const [amount, setAmount] = (0, import_react.useState)("");
	const [note, setNote] = (0, import_react.useState)("");
	const [counted, setCounted] = (0, import_react.useState)("");
	const history = db.cash.filter((c) => c.closed);
	function submitOpen(e) {
		e.preventDefault();
		const value = Number(initial.replace(",", "."));
		if (!date || Number.isNaN(value) || value < 0) return;
		openCash(date, value);
		setInitial("");
	}
	function submitMove(e) {
		e.preventDefault();
		if (!open || !sheet || sheet === "fechar") return;
		const value = Number(amount.replace(",", "."));
		if (!value || value <= 0) return;
		addMove(open.date, sheet, value, note);
		setAmount("");
		setNote("");
		setSheet(null);
	}
	function submitClose(e) {
		e.preventDefault();
		if (!open) return;
		const value = Number(counted.replace(",", "."));
		if (Number.isNaN(value) || value < 0) return;
		closeCash(open.date, value);
		setCounted("");
		setSheet(null);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-2 mb-1 text-3xl text-wine",
			children: "Caixa"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-4 text-sm text-muted",
			children: "Abre de manhã e fecha à noite. O lucro é o que tem agora menos o caixa inicial."
		}),
		!open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: submitOpen,
			className: "card space-y-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-semibold text-wine",
					children: "Abrir fluxo de caixa"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block text-sm font-semibold text-wine",
					children: ["Dia", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field mt-1",
						type: "date",
						value: date,
						onChange: (e) => setDate(e.target.value),
						required: true
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block text-sm font-semibold text-wine",
					children: ["Caixa inicial (R$)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field mt-1",
						inputMode: "decimal",
						placeholder: "0,00",
						value: initial,
						onChange: (e) => setInitial(e.target.value),
						required: true
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "btn",
					type: "submit",
					children: "Abrir caixa"
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "space-y-3",
			children: [
				open.date !== today && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "rounded-2xl bg-blush px-4 py-3 text-sm text-wine",
					children: [
						"Este caixa é de ",
						fmtLong(open.date),
						". Feche para começar o de hoje."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "card",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold tracking-wide text-muted uppercase",
							children: "Troco em caixa"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-4xl text-wine",
							children: money(troco(open))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-muted",
							children: [
								"Inicial ",
								money(open.initial),
								" · ",
								fmtLong(open.date)
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 grid grid-cols-2 gap-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
								"Compras",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: money(open.moves.filter((m) => m.kind === "compra").reduce((s, m) => s + m.amount, 0)) })
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
								"Vendas",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: money(open.moves.filter((m) => m.kind === "venda").reduce((s, m) => s + m.amount, 0)) })
							] })]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn",
						onClick: () => setSheet("compra"),
						children: "Compra"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn-ghost",
						onClick: () => setSheet("venda"),
						children: "Venda"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn",
					onClick: () => setSheet("fechar"),
					children: "Fechar caixa"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: open.moves.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "py-6 text-center text-sm text-muted",
					children: "Nenhuma compra ou venda ainda."
				}) : open.moves.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "card mb-2 flex items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold",
						children: m.note || (m.kind === "compra" ? "Compra de ingredientes" : "Venda")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: m.kind === "compra" ? "Saída" : "Entrada"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-right",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: m.kind === "compra" ? "font-semibold text-primary" : "font-semibold text-good",
							children: [
								m.kind === "compra" ? "−" : "+",
								" ",
								money(m.amount)
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "text-xs text-muted",
							onClick: () => removeMove(open.date, m.id),
							children: "Apagar"
						})]
					})]
				}, m.id)) })
			]
		}),
		history.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-2 text-xl text-wine",
				children: "Dias fechados"
			}), history.map((day) => {
				const gain = lucro(day) ?? 0;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "card mb-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-semibold capitalize",
							children: fmtLong(day.date)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: [
								"Inicial ",
								money(day.initial),
								" · fechou com ",
								money(day.counted ?? 0)
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: gain >= 0 ? "font-semibold text-good" : "font-semibold text-primary",
							children: [gain >= 0 ? "+" : "", money(gain)]
						})]
					}), !db.cash.some((c) => !c.closed) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "mt-2 text-sm font-semibold text-primary",
						onClick: () => reopenCash(day.date),
						children: "Reabrir este dia"
					})]
				}, day.date);
			})]
		}),
		sheet === "compra" || sheet === "venda" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
			title: sheet === "compra" ? "Compra de ingredientes" : "Venda / entrada",
			onClose: () => setSheet(null),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: submitMove,
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm font-semibold text-wine",
						children: ["Valor (R$)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field mt-1",
							inputMode: "decimal",
							value: amount,
							onChange: (e) => setAmount(e.target.value),
							required: true,
							autoFocus: true
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm font-semibold text-wine",
						children: ["O que foi", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field mt-1",
							value: note,
							onChange: (e) => setNote(e.target.value),
							placeholder: sheet === "compra" ? "Ex: leite condensado" : "Ex: encomenda de trufas"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn",
						type: "submit",
						children: "Lançar"
					})
				]
			})
		}) : null,
		sheet === "fechar" && open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
			title: "Fechar caixa",
			onClose: () => setSheet(null),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: submitClose,
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							"Conte o dinheiro que tem agora. O lucro do dia é esse valor menos o caixa inicial (",
							money(open.initial),
							")."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm font-semibold text-wine",
						children: ["Quanto tem agora no caixa?", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field mt-1",
							inputMode: "decimal",
							value: counted,
							onChange: (e) => setCounted(e.target.value),
							required: true,
							autoFocus: true
						})]
					}),
					counted !== "" && !Number.isNaN(Number(counted.replace(",", "."))) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-display text-2xl text-wine",
						children: ["Lucro ", money(Number(counted.replace(",", ".")) - open.initial)]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn",
						type: "submit",
						children: "Fechar o dia"
					})
				]
			})
		}) : null
	] });
}
function Clientes({ db }) {
	const [part, setPart] = (0, import_react.useState)("pessoas");
	const [clientSheet, setClientSheet] = (0, import_react.useState)(false);
	const [editId, setEditId] = (0, import_react.useState)(null);
	const [name, setName] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [statusFor, setStatusFor] = (0, import_react.useState)(null);
	const [wizard, setWizard] = (0, import_react.useState)(false);
	function openNew() {
		setEditId(null);
		setName("");
		setPhone("");
		setClientSheet(true);
	}
	function openEdit(id) {
		const c = db.clients.find((x) => x.id === id);
		if (!c) return;
		setEditId(id);
		setName(c.name);
		setPhone(c.phone);
		setClientSheet(true);
	}
	function submitClient(e) {
		e.preventDefault();
		saveClient({
			id: editId ?? void 0,
			name,
			phone
		});
		setClientSheet(false);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-2 mb-3 flex items-end justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl text-wine",
				children: "Clientes"
			}), part === "pessoas" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "btn w-auto px-4",
				onClick: openNew,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 18 }), " Novo"]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "btn w-auto px-4",
				onClick: () => setWizard(true),
				disabled: !db.clients.length,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 18 }), " Pedido"]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: part === "pessoas" ? "pill on" : "pill",
				onClick: () => setPart("pessoas"),
				children: "Clientes"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: part === "pedidos" ? "pill on" : "pill",
				onClick: () => setPart("pedidos"),
				children: "Pedidos"
			})]
		}),
		part === "pessoas" && (db.clients.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "card text-sm text-muted",
			children: "Nenhum cliente ainda. Comece pelo nome. O telefone é opcional."
		}) : db.clients.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "card mb-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate font-semibold",
						children: c.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: c.phone || "Sem telefone"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: `shrink-0 rounded-full px-3 py-2 text-xs font-bold ${statusClass(c.status)}`,
					onClick: () => setStatusFor(c.id),
					children: STATUS.find((s) => s.id === c.status)?.label
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn-ghost",
					onClick: () => openEdit(c.id),
					children: "Editar"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn-ghost",
					onClick: () => {
						if (confirm("Apagar este cliente e os pedidos dele?")) deleteClient(c.id);
					},
					children: "Apagar"
				})]
			})]
		}, c.id))),
		part === "pedidos" && (db.orders.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "card text-sm text-muted",
			children: "Nenhum pedido. O pedido pega o cliente salvo e os itens do estoque."
		}) : db.orders.map((o) => {
			const client = db.clients.find((c) => c.id === o.clientId);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "card mb-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold text-muted uppercase",
						children: o.status === "pendente" ? "Pedido pendente" : "Entregue"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 font-semibold",
						children: ["Pedido para ", client?.name || "cliente"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm",
						children: orderPhrase(o.lines)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-display text-xl text-wine",
						children: money(o.total)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: fmtShort(o.date)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex gap-2",
						children: [o.status === "pendente" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn",
							onClick: () => deliverOrder(o.id),
							children: "Entregue"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn-ghost",
							onClick: () => {
								if (confirm("Apagar este pedido?")) deleteOrder(o.id);
							},
							children: "Apagar"
						})]
					})
				]
			}, o.id);
		})),
		clientSheet && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
			title: editId ? "Editar cliente" : "Novo cliente",
			onClose: () => setClientSheet(false),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: submitClient,
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm font-semibold text-wine",
						children: ["Nome", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field mt-1",
							value: name,
							onChange: (e) => setName(e.target.value),
							required: true,
							autoFocus: true
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm font-semibold text-wine",
						children: ["Telefone (opcional)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field mt-1",
							type: "tel",
							value: phone,
							onChange: (e) => setPhone(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn",
						type: "submit",
						children: "Salvar"
					})
				]
			})
		}),
		statusFor && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
			title: "Situação do cliente",
			onClose: () => setStatusFor(null),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-2",
				children: STATUS.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn-ghost justify-start",
					onClick: () => {
						setClientStatus(statusFor, s.id);
						setStatusFor(null);
					},
					children: s.label
				}, s.id))
			})
		}),
		wizard && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PedidoWizard, {
			db,
			onClose: () => setWizard(false)
		})
	] });
}
function PedidoWizard({ db, onClose }) {
	const [step, setStep] = (0, import_react.useState)("cliente");
	const [clientId, setClientId] = (0, import_react.useState)(db.clients[0]?.id ?? "");
	const [lines, setLines] = (0, import_react.useState)([]);
	const [stockId, setStockId] = (0, import_react.useState)(db.stock[0]?.id ?? "");
	const [qty, setQty] = (0, import_react.useState)("1");
	const [total, setTotal] = (0, import_react.useState)("");
	function addLine() {
		const item = db.stock.find((s) => s.id === stockId);
		const n = Number(qty.replace(",", "."));
		if (!item || !n || n <= 0) return;
		setLines((prev) => {
			if (prev.find((l) => l.stockId === item.id)) return prev.map((l) => l.stockId === item.id ? {
				...l,
				qty: l.qty + n
			} : l);
			return [...prev, {
				stockId: item.id,
				name: item.name,
				qty: n
			}];
		});
		setQty("1");
		setStep("mais");
	}
	function finish(e) {
		e.preventDefault();
		const value = Number(total.replace(",", "."));
		if (Number.isNaN(value) || value < 0 || !lines.length) return;
		addOrder(clientId, lines, value);
		onClose();
	}
	const client = db.clients.find((c) => c.id === clientId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
		title: "Adicionar pedido",
		onClose,
		children: [
			step === "cliente" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block text-sm font-semibold text-wine",
					children: ["De quem é o pedido?", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: "field mt-1",
						value: clientId,
						onChange: (e) => setClientId(e.target.value),
						children: db.clients.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: c.id,
							children: c.name
						}, c.id))
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn",
					onClick: () => setStep("item"),
					disabled: !clientId,
					children: "Continuar"
				})]
			}),
			step === "item" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-3",
				children: db.stock.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Cadastre o estoque antes. O pedido escolhe o que já está lá."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm font-semibold text-wine",
						children: ["O que vai querer?", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: "field mt-1",
							value: stockId,
							onChange: (e) => setStockId(e.target.value),
							children: db.stock.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
								value: s.id,
								children: [
									s.name,
									" (",
									s.qty,
									" ",
									s.unit,
									")"
								]
							}, s.id))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm font-semibold text-wine",
						children: ["Quantos?", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field mt-1",
							inputMode: "decimal",
							value: qty,
							onChange: (e) => setQty(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn",
						onClick: addLine,
						children: "Adicionar"
					})
				] })
			}),
			step === "mais" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm",
						children: [
							"Pedido para ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: client?.name }),
							": ",
							orderPhrase(lines)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl text-wine",
						children: "Quer mais alguma coisa?"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn",
						onClick: () => setStep("item"),
						children: "Sim, quero mais"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn-ghost",
						onClick: () => setStep("valor"),
						children: "Não, é só isso"
					})
				]
			}),
			step === "valor" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: finish,
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm",
						children: [
							"Pedido para ",
							client?.name,
							", ",
							orderPhrase(lines),
							"."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm font-semibold text-wine",
						children: ["Valor (R$)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field mt-1",
							inputMode: "decimal",
							value: total,
							onChange: (e) => setTotal(e.target.value),
							required: true,
							autoFocus: true
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn",
						type: "submit",
						children: "Salvar pedido pendente"
					})
				]
			})
		]
	});
}
function Estoque({ db }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [editId, setEditId] = (0, import_react.useState)(null);
	const [name, setName] = (0, import_react.useState)("");
	const [qty, setQty] = (0, import_react.useState)("0");
	const [unit, setUnit] = (0, import_react.useState)("un");
	const [kind, setKind] = (0, import_react.useState)("trufa");
	function startNew() {
		setEditId(null);
		setName("");
		setQty("0");
		setUnit("un");
		setKind("trufa");
		setOpen(true);
	}
	function startEdit(id) {
		const s = db.stock.find((x) => x.id === id);
		if (!s) return;
		setEditId(id);
		setName(s.name);
		setQty(String(s.qty));
		setUnit(s.unit);
		setKind(s.kind);
		setOpen(true);
	}
	function submit(e) {
		e.preventDefault();
		const n = Number(qty.replace(",", "."));
		if (Number.isNaN(n) || n < 0) return;
		saveStock({
			id: editId ?? void 0,
			name,
			qty: n,
			unit,
			kind
		});
		setOpen(false);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-2 mb-4 flex items-end justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl text-wine",
				children: "Estoque"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Qualquer ingrediente ou trufa, com a quantidade."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "btn w-auto px-4",
				onClick: startNew,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 18 }), " Item"]
			})]
		}),
		db.stock.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "card text-sm text-muted",
			children: "Nada no estoque. Exemplo: leite condensado, creme de leite, trufa de chocolate."
		}),
		[
			{
				id: "trufa",
				label: "Trufas"
			},
			{
				id: "ingrediente",
				label: "Ingredientes"
			},
			{
				id: "outro",
				label: "Outros"
			}
		].map((g) => {
			const items = db.stock.filter((s) => s.kind === g.id);
			if (!items.length) return null;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-2 text-lg text-wine",
					children: g.label
				}), items.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "card mb-2 flex items-center gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate font-semibold",
								children: s.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: `text-sm ${s.qty <= 2 ? "text-primary" : "text-muted"}`,
								children: [
									s.qty,
									" ",
									s.unit
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "iconbtn",
							onClick: () => adjustStock(s.id, -1),
							"aria-label": "Diminuir",
							children: "−"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "iconbtn",
							onClick: () => adjustStock(s.id, 1),
							"aria-label": "Aumentar",
							children: "+"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "text-sm font-semibold text-primary",
							onClick: () => startEdit(s.id),
							children: "Editar"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": "Apagar",
							className: "text-muted",
							onClick: () => {
								if (confirm("Apagar este item?")) deleteStock(s.id);
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { size: 18 })
						})
					]
				}, s.id))]
			}, g.id);
		}),
		open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
			title: editId ? "Editar item" : "Novo item",
			onClose: () => setOpen(false),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: submit,
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm font-semibold text-wine",
						children: ["Nome", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field mt-1",
							value: name,
							onChange: (e) => setName(e.target.value),
							placeholder: "Trufa de chocolate",
							required: true,
							autoFocus: true
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm font-semibold text-wine",
						children: ["Tipo", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "field mt-1",
							value: kind,
							onChange: (e) => setKind(e.target.value),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "trufa",
									children: "Trufa"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "ingrediente",
									children: "Ingrediente"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "outro",
									children: "Outro"
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm font-semibold text-wine",
							children: ["Quantidade", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field mt-1",
								inputMode: "decimal",
								value: qty,
								onChange: (e) => setQty(e.target.value),
								required: true
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm font-semibold text-wine",
							children: ["Unidade", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field mt-1",
								value: unit,
								onChange: (e) => setUnit(e.target.value),
								placeholder: "un, g, ml"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn",
						type: "submit",
						children: "Salvar"
					})
				]
			})
		})
	] });
}
function Agenda({ db, today }) {
	const [mode, setMode] = (0, import_react.useState)("day");
	const [cursor, setCursor] = (0, import_react.useState)(today);
	const [sheet, setSheet] = (0, import_react.useState)(false);
	const [edit, setEdit] = (0, import_react.useState)(null);
	const [title, setTitle] = (0, import_react.useState)("");
	const [date, setDate] = (0, import_react.useState)(today);
	const [time, setTime] = (0, import_react.useState)("");
	const [type, setType] = (0, import_react.useState)("Tarefa");
	const [category, setCategory] = (0, import_react.useState)("Empresa");
	const [notes, setNotes] = (0, import_react.useState)("");
	function shift(n) {
		const d = parseDate(cursor);
		if (mode === "month") d.setMonth(d.getMonth() + n);
		else d.setDate(d.getDate() + n * (mode === "week" ? 7 : 1));
		setCursor(dateKey(d));
	}
	function openNew(day = cursor, t = "") {
		setEdit(null);
		setTitle("");
		setDate(day);
		setTime(t);
		setType("Tarefa");
		setCategory("Empresa");
		setNotes("");
		setSheet(true);
	}
	function openEdit(a) {
		setEdit(a);
		setTitle(a.title);
		setDate(a.date);
		setTime(a.time);
		setType(a.type);
		setCategory(a.category);
		setNotes(a.notes);
		setSheet(true);
	}
	function submit(e) {
		e.preventDefault();
		saveActivity({
			id: edit?.id,
			title,
			date,
			time,
			type,
			category,
			notes
		});
		setSheet(false);
	}
	const dayItems = db.activities.filter((a) => a.date === cursor).sort((a, b) => (a.time || "99").localeCompare(b.time || "99"));
	const monthCells = (0, import_react.useMemo)(() => {
		const d = parseDate(cursor);
		const first = new Date(d.getFullYear(), d.getMonth(), 1);
		const start = new Date(first);
		start.setDate(1 - first.getDay());
		return Array.from({ length: 42 }, (_, i) => {
			const x = new Date(start);
			x.setDate(start.getDate() + i);
			return dateKey(x);
		});
	}, [cursor]);
	const week = (0, import_react.useMemo)(() => {
		const d = parseDate(cursor);
		const start = new Date(d);
		start.setDate(d.getDate() - d.getDay());
		return Array.from({ length: 7 }, (_, i) => {
			const x = new Date(start);
			x.setDate(start.getDate() + i);
			return dateKey(x);
		});
	}, [cursor]);
	const titleText = mode === "day" ? parseDate(cursor).toLocaleDateString("pt-BR", {
		weekday: "short",
		day: "numeric",
		month: "short"
	}) : parseDate(cursor).toLocaleDateString("pt-BR", {
		month: "long",
		year: "numeric"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-2 mb-3 flex items-end justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl text-wine",
				children: "Agenda"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "btn w-auto px-4",
				onClick: () => openNew(),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 18 }), " Novo"]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-3 flex gap-2",
			children: [
				["day", "Dia"],
				["week", "Semana"],
				["month", "Mês"]
			].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: mode === id ? "pill on" : "pill",
				onClick: () => setMode(id),
				children: label
			}, id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-3 flex items-center justify-between",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "iconbtn",
					onClick: () => shift(-1),
					"aria-label": "Anterior",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { size: 18 })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-lg capitalize text-wine",
					children: titleText
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "iconbtn",
					onClick: () => shift(1),
					"aria-label": "Próximo",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { size: 18 })
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "mb-3 text-sm font-semibold text-primary",
			onClick: () => setCursor(today),
			children: "Ir para hoje"
		}),
		mode === "month" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-7 gap-1",
			children: [[
				"D",
				"S",
				"T",
				"Q",
				"Q",
				"S",
				"S"
			].map((d, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "py-1 text-center text-xs text-muted",
				children: d
			}, d + i)), monthCells.map((key) => {
				const count = db.activities.filter((a) => a.date === key).length;
				const outside = parseDate(key).getMonth() !== parseDate(cursor).getMonth();
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => {
						setCursor(key);
						setMode("day");
					},
					className: `min-h-12 rounded-xl border text-sm ${key === cursor ? "border-primary bg-primary text-paper" : "border-line bg-paper text-ink"} ${outside ? "opacity-40" : ""}`,
					children: [parseDate(key).getDate(), count > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 block text-xs leading-none",
						children: count
					})]
				}, key);
			})]
		}),
		mode === "week" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-7 gap-1",
			children: week.map((key, i) => {
				const items = db.activities.filter((a) => a.date === key);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => {
						setCursor(key);
						setMode("day");
					},
					className: "min-h-28 rounded-xl border border-line bg-paper p-1 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
							className: "text-xs text-wine",
							children: [
								"DOM",
								"SEG",
								"TER",
								"QUA",
								"QUI",
								"SEX",
								"SÁB"
							][i]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-xs text-muted",
							children: parseDate(key).getDate()
						}),
						items.slice(0, 3).map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 block truncate rounded bg-blush px-1 text-xs text-wine",
							children: a.title
						}, a.id))
					]
				}, key);
			})
		}),
		mode === "day" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [dayItems.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "card text-sm text-muted",
			children: "Nada neste dia."
		}), dayItems.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "card mb-2 flex gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "checkbox",
				className: "mt-1 size-5 accent-primary",
				checked: a.done,
				onChange: () => toggleActivity(a.id),
				"aria-label": "Concluir"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: `font-semibold ${a.done ? "text-muted line-through" : ""}`,
						children: a.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							a.time || "Sem horário",
							" · ",
							a.type,
							" · ",
							a.category
						]
					}),
					a.notes && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm",
						children: a.notes
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "text-sm font-semibold text-primary",
							onClick: () => openEdit(a),
							children: "Editar"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "text-sm text-muted",
							onClick: () => {
								if (confirm("Apagar esta atividade?")) deleteActivity(a.id);
							},
							children: "Apagar"
						})]
					})
				]
			})]
		}, a.id))] }),
		sheet && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
			title: edit ? "Editar" : "Nova atividade",
			onClose: () => setSheet(false),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: submit,
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: type === "Tarefa" ? "pill on" : "pill",
							onClick: () => setType("Tarefa"),
							children: "Tarefa"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: type === "Compromisso" ? "pill on" : "pill",
							onClick: () => setType("Compromisso"),
							children: "Compromisso"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm font-semibold text-wine",
						children: ["Título", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field mt-1",
							value: title,
							onChange: (e) => setTitle(e.target.value),
							required: true,
							autoFocus: true
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm font-semibold text-wine",
							children: ["Data", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field mt-1",
								type: "date",
								value: date,
								onChange: (e) => setDate(e.target.value),
								required: true
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm font-semibold text-wine",
							children: ["Horário", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field mt-1",
								type: "time",
								value: time,
								onChange: (e) => setTime(e.target.value)
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm font-semibold text-wine",
						children: ["Categoria", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "field mt-1",
							value: category,
							onChange: (e) => setCategory(e.target.value),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Empresa" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Faculdade" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Clientes" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Pessoal" })
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm font-semibold text-wine",
						children: ["Anotação", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							className: "field mt-1 min-h-20",
							value: notes,
							onChange: (e) => setNotes(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn",
						type: "submit",
						children: "Salvar"
					})
				]
			})
		})
	] });
}
function Sheet({ title, onClose, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-40 flex items-end justify-center bg-ink/40",
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-h-[90dvh] w-full max-w-lg overflow-auto rounded-t-3xl bg-paper p-5 pb-8",
			onClick: (e) => e.stopPropagation(),
			role: "dialog",
			"aria-modal": "true",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mb-4 h-1 w-10 rounded-full bg-line" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-2xl text-wine",
						children: title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "iconbtn",
						onClick: onClose,
						"aria-label": "Fechar",
						children: "×"
					})]
				}),
				children
			]
		})
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DoceApp, {});
}
//#endregion
export { Home as component };
