import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as DialogOverlay, i as DialogDescription, n as DialogClose, o as DialogPortal, r as DialogContent, s as DialogTitle, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { t as X } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/format-Bbm5TEoT.js
var import_jsx_runtime = require_jsx_runtime();
function Modal({ open, title, description, onClose, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: (next) => !next && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-50 bg-ink/40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "fixed inset-x-0 bottom-0 z-50 max-h-screen overflow-y-auto bg-surface p-4 outline-none sm:inset-auto sm:top-1/2 sm:left-1/2 sm:w-full sm:max-w-lg sm:-translate-x-1/2 sm:-translate-y-1/2 sm:rounded-2xl sm:border sm:border-line sm:p-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex items-start justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
					className: "font-serif text-2xl",
					children: title
				}), description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
					className: "mt-1 text-sm text-muted",
					children: description
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
					className: "sr-only",
					children: title
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
					className: "grid size-11 place-items-center rounded-lg text-muted hover:text-ink",
					"aria-label": "Bezárás",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
				})]
			}), children]
		})] })
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-1 block text-sm text-muted",
			children: label
		}), children]
	});
}
function Segmented({ value, options, onChange, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "inline-flex flex-wrap rounded-lg border border-line bg-surface p-1",
		role: "tablist",
		"aria-label": label,
		children: options.map((option) => {
			const on = option.id === value;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				role: "tab",
				"aria-selected": on,
				onClick: () => onChange(option.id),
				className: `h-9 rounded-md px-3 text-sm ${on ? "bg-pine text-on-pine" : "text-muted"}`,
				children: option.label
			}, option.id);
		})
	});
}
function formatNumber(value, digits = 0) {
	if (!Number.isFinite(value)) return "—";
	const negative = value < 0;
	const [whole, fraction] = Math.abs(value).toFixed(digits).split(".");
	const grouped = whole.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
	const body = digits > 0 ? `${grouped},${fraction}` : grouped;
	return negative ? `-${body}` : body;
}
function moneyDigits(currency, value) {
	if (currency === "HUF") return Math.abs(value) >= 100 ? 0 : 2;
	if (Math.abs(value) >= 1e3) return 0;
	if (Math.abs(value) >= 1) return 2;
	return 4;
}
function formatMoney(value, currency, digits) {
	const d = digits ?? moneyDigits(currency, value);
	const suffix = currency === "HUF" ? "Ft" : currency;
	return `${formatNumber(value, d)} ${suffix}`;
}
function formatQty(value) {
	if (!Number.isFinite(value)) return "—";
	const text = formatNumber(value, value >= 100 ? 2 : value >= 1 ? 4 : 8);
	if (!text.includes(",")) return text;
	return text.replace(/0+$/, "").replace(/,$/, "");
}
function formatPct(value) {
	if (!Number.isFinite(value)) return "—";
	return `${value > 0 ? "+" : ""}${formatNumber(value, 1)}%`;
}
function formatDay(iso) {
	const match = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso);
	if (!match) return iso;
	return `${match[1]}. ${match[2]}. ${match[3]}.`;
}
function formatWhen(iso) {
	const date = new Date(iso);
	if (Number.isNaN(date.getTime())) return "még nem frissült";
	return new Intl.DateTimeFormat("hu-HU", {
		month: "short",
		day: "numeric",
		hour: "2-digit",
		minute: "2-digit"
	}).format(date);
}
function compactHuf(value) {
	const sign = value < 0 ? "−" : "";
	const abs = Math.abs(value);
	if (abs >= 1e6) return `${sign}${formatNumber(abs / 1e6, 1)} M Ft`;
	if (abs >= 1e4) return `${sign}${formatNumber(abs / 1e3, 0)} e Ft`;
	return `${sign}${formatNumber(abs, 0)} Ft`;
}
function pnlClass(value) {
	if (value > .5) return "text-pine";
	if (value < -.5) return "text-clay";
	return "text-muted";
}
var CLASS_LABEL = {
	etf: "ETF",
	reszveny: "Részvény",
	kripto: "Kripto",
	keszpenz: "Készpénz"
};
var KIND_LABEL = {
	tbsz: "TBSZ",
	szabad: "Szabad számla",
	kripto: "Kriptotárca",
	egyeb: "Egyéb"
};
var SIDE_LABEL = {
	vetel: "Vétel",
	eladas: "Eladás",
	osztalek: "Osztalék",
	dij: "Díj"
};
function todayIso() {
	const now = /* @__PURE__ */ new Date();
	const month = String(now.getMonth() + 1).padStart(2, "0");
	const day = String(now.getDate()).padStart(2, "0");
	return `${now.getFullYear()}-${month}-${day}`;
}
function uid() {
	return crypto.randomUUID();
}
//#endregion
export { SIDE_LABEL as a, formatDay as c, formatPct as d, formatQty as f, uid as g, todayIso as h, Modal as i, formatMoney as l, pnlClass as m, Field as n, Segmented as o, formatWhen as p, KIND_LABEL as r, compactHuf as s, CLASS_LABEL as t, formatNumber as u };
