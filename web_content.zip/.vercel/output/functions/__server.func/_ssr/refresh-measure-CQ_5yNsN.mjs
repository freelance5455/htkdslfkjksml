import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, Y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { V as useAppStore, a as Button, h as Notice, j as formatWhen } from "./ui-CJMJB--P.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/refresh-measure-CQ_5yNsN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var webglCache = null;
function browserLabel(ua) {
	if (/Edg\//.test(ua)) return "Edge";
	if (/SamsungBrowser\//.test(ua)) return "Samsung Internet";
	if (/CriOS\//.test(ua)) return "Chrome on iOS";
	if (/Chrome\//.test(ua)) return "Chrome";
	if (/Firefox\//.test(ua)) return "Firefox";
	if (/Safari\//.test(ua)) return "Safari";
	return "This browser";
}
function readWebgl() {
	if (webglCache) return webglCache;
	try {
		const canvas = document.createElement("canvas");
		const gl = canvas.getContext("webgl") ?? canvas.getContext("experimental-webgl");
		if (!gl || !(gl instanceof WebGLRenderingContext)) {
			webglCache = {
				ok: false,
				vendor: null,
				renderer: null
			};
			return webglCache;
		}
		const ext = gl.getExtension("WEBGL_debug_renderer_info");
		const vendor = ext ? String(gl.getParameter(ext.UNMASKED_VENDOR_WEBGL)) : String(gl.getParameter(gl.VENDOR));
		const renderer = ext ? String(gl.getParameter(ext.UNMASKED_RENDERER_WEBGL)) : String(gl.getParameter(gl.RENDERER));
		gl.getExtension("WEBGL_lose_context")?.loseContext();
		webglCache = {
			ok: true,
			vendor,
			renderer
		};
		return webglCache;
	} catch {
		webglCache = {
			ok: false,
			vendor: null,
			renderer: null
		};
		return webglCache;
	}
}
function storageProbe() {
	try {
		const key = "__ff_probe";
		localStorage.setItem(key, "1");
		localStorage.removeItem(key);
		return true;
	} catch {
		return false;
	}
}
function readNet() {
	const connection = navigator.connection;
	if (!connection) return null;
	return {
		effectiveType: connection.effectiveType,
		saveData: connection.saveData,
		downlink: typeof connection.downlink === "number" ? connection.downlink : void 0
	};
}
function readDeviceSnapshot(battery, batterySupported) {
	const nav = navigator;
	const brands = nav.userAgentData?.brands?.map((brand) => `${brand.brand} ${brand.version}`).join(", ") ?? null;
	return {
		browser: browserLabel(navigator.userAgent),
		ua: navigator.userAgent,
		platform: nav.userAgentData?.platform || navigator.platform || "Unknown platform",
		mobile: typeof nav.userAgentData?.mobile === "boolean" ? nav.userAgentData.mobile : null,
		brands,
		cores: typeof navigator.hardwareConcurrency === "number" ? navigator.hardwareConcurrency : null,
		memoryGb: typeof nav.deviceMemory === "number" ? nav.deviceMemory : null,
		screenLabel: `${window.screen.width} × ${window.screen.height}`,
		dpr: window.devicePixelRatio || 1,
		webgl: readWebgl(),
		online: navigator.onLine,
		net: readNet(),
		battery,
		batterySupported,
		storage: null,
		standalone: window.matchMedia("(display-mode: standalone)").matches,
		wakeLock: "wakeLock" in navigator,
		localStorage: storageProbe()
	};
}
function useDeviceSnapshot() {
	const [snap, setSnap] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		let battery = null;
		const connection = navigator.connection;
		const apply = (nextBattery, supported) => {
			if (cancelled) return;
			setSnap(readDeviceSnapshot(nextBattery, supported));
		};
		const onBattery = () => {
			if (!battery) return;
			apply({
				level: battery.level,
				charging: battery.charging
			}, true);
		};
		const onNet = () => apply(battery ? {
			level: battery.level,
			charging: battery.charging
		} : null, Boolean(battery) || supportedGuess);
		let supportedGuess = false;
		apply(null, false);
		const getBattery = navigator.getBattery;
		if (typeof getBattery === "function") {
			supportedGuess = true;
			getBattery.call(navigator).then((manager) => {
				if (cancelled) return;
				battery = manager;
				manager.addEventListener("levelchange", onBattery);
				manager.addEventListener("chargingchange", onBattery);
				apply({
					level: manager.level,
					charging: manager.charging
				}, true);
			}).catch(() => apply(null, true));
		}
		if (navigator.storage?.estimate) navigator.storage.estimate().then((estimate) => {
			if (cancelled) return;
			setSnap((current) => current ? {
				...current,
				storage: {
					usage: estimate.usage,
					quota: estimate.quota
				}
			} : current);
		});
		window.addEventListener("online", onNet);
		window.addEventListener("offline", onNet);
		connection?.addEventListener?.("change", onNet);
		return () => {
			cancelled = true;
			window.removeEventListener("online", onNet);
			window.removeEventListener("offline", onNet);
			connection?.removeEventListener?.("change", onNet);
			if (battery) {
				battery.removeEventListener("levelchange", onBattery);
				battery.removeEventListener("chargingchange", onBattery);
			}
		};
	}, []);
	return snap;
}
function measureRefresh(durationMs = 1200) {
	return new Promise((resolve) => {
		if (typeof requestAnimationFrame !== "function" || document.visibilityState === "hidden") {
			resolve(null);
			return;
		}
		let frames = 0;
		let start = 0;
		let settled = false;
		const finish = (value) => {
			if (settled) return;
			settled = true;
			resolve(value);
		};
		const step = (now) => {
			if (document.visibilityState === "hidden") {
				finish(null);
				return;
			}
			if (!start) {
				start = now;
				requestAnimationFrame(step);
				return;
			}
			frames += 1;
			if (now - start < durationMs) {
				requestAnimationFrame(step);
				return;
			}
			const elapsed = now - start;
			if (elapsed < 500 || frames < 8) {
				finish(null);
				return;
			}
			const rawHz = frames * 1e3 / elapsed;
			const nearest = [
				30,
				48,
				60,
				90,
				120,
				144,
				165
			].reduce((best, rate) => Math.abs(rate - rawHz) < Math.abs(best - rawHz) ? rate : best);
			const snapped = Math.abs(nearest - rawHz) <= 3;
			finish({
				displayHz: snapped ? nearest : Math.round(rawHz),
				rawHz: Math.round(rawHz * 10) / 10,
				frames,
				at: Date.now(),
				snapped
			});
		};
		requestAnimationFrame(step);
	});
}
function RefreshMeasure() {
	const sample = useAppStore((state) => state.refreshSample);
	const setRefresh = useAppStore((state) => state.setRefresh);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const [when, setWhen] = (0, import_react.useState)(null);
	async function run() {
		setBusy(true);
		setError(null);
		const result = await measureRefresh();
		setBusy(false);
		if (!result) {
			setError("Sample failed. Keep this tab in the foreground and try again.");
			return;
		}
		setRefresh(result);
		setWhen(formatWhen(result.at));
	}
	const stamped = sample ? when ?? formatWhen(sample.at) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-semibold tracking-widest text-faint uppercase",
			children: "This page"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-4xl font-semibold tabular-nums",
			children: sample ? `${sample.displayHz} Hz` : "—"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted",
			children: sample ? sample.snapped ? `Estimated display refresh, snapped to a common rate. Raw sample ${sample.rawHz} Hz from ${sample.frames} frames.` : `Rough page estimate ${sample.rawHz} Hz from ${sample.frames} frames. It did not sit on a common panel rate.` : "Not measured yet. This does not read the game."
		}),
		stamped && sample ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-1 text-xs text-faint",
			children: [
				"Sampled ",
				stamped,
				". Source: requestAnimationFrame on this page."
			]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => void run(),
				disabled: busy,
				children: busy ? "Measuring…" : sample ? "Measure again" : "Measure this page"
			})
		}),
		busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted",
			children: "Keep this tab visible for about a second."
		}) : null,
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, {
				tone: "warn",
				children: error
			})
		}) : null
	] });
}
//#endregion
export { useDeviceSnapshot as n, RefreshMeasure as t };
