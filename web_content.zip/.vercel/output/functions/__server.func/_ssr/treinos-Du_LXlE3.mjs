import { w as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { D as useAppStore, O as weekdayFromDate, a as SESSION_TYPE_LABEL, f as cn, l as WEEKDAYS, u as WEEKDAY_LABEL } from "./store-CuJQmbYj.mjs";
import { t as PageHeader } from "./page-header-ueGZTDza.mjs";
import { t as Card } from "./card-ML3_y2lP.mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as ChevronRight } from "../_libs/lucide-react.mjs";
import { t as Badge } from "./badge-Ct6gxEJd.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/treinos-Du_LXlE3.js
var import_jsx_runtime = require_jsx_runtime();
function TreinosPage() {
	const workouts = useAppStore((s) => s.workouts);
	const todayKey = weekdayFromDate(/* @__PURE__ */ new Date());
	const active = useAppStore((s) => s.activeSession);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "animate-in fade-in duration-300",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			kicker: "Semana",
			title: "Treinos",
			subtitle: "Muay Thai, força e recuperação. Postura fica na aba própria."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-3",
			children: WEEKDAYS.map((day) => {
				const w = workouts[day];
				const isToday = day === todayKey;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/treinos/$day",
					params: { day },
					className: "block",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: cn("flex items-center gap-4 p-4 transition-colors hover:border-primary/40", isToday && "glow-ring"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "w-16 shrink-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] font-medium tracking-wide text-muted-foreground uppercase",
									children: WEEKDAY_LABEL[day].slice(0, 3)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-lg font-semibold leading-tight",
									children: WEEKDAY_LABEL[day]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap items-center gap-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-medium",
												children: SESSION_TYPE_LABEL[w.type]
											}),
											isToday ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
												tone: "primary",
												children: "Hoje"
											}) : null,
											active?.dayKey === day ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
												tone: "success",
												children: "Em andamento"
											}) : null
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-muted-foreground",
										children: w.subtitle
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-0.5 text-xs text-muted-foreground",
										children: [w.exercises.length, " exercícios"]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4 text-muted-foreground" })
						]
					})
				}, day);
			})
		})]
	});
}
//#endregion
export { TreinosPage as component };
