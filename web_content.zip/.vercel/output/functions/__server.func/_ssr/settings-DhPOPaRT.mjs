import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, Y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as WIDGETS, F as isFpsTarget, H as useRuntime, I as presetLabel, M as freshState, U as useSelectedGame, V as useAppStore, _ as PageHeader, a as Button, b as THEMES, c as DETAIL, d as GRAPHICS, f as MOTIONS, g as PRESETS, h as Notice, k as formatBytes, m as NEEDS_NATIVE, n as ACCENTS, o as CARD_STYLES, r as BACKGROUNDS, s as DENSITIES, t as AA, u as Field, v as Panel, w as WORKS_NOW, y as SCALE } from "./ui-CJMJB--P.mjs";
import { f as ArrowUp, p as ArrowDown } from "../_libs/lucide-react.mjs";
import { o as stopClicker } from "./router-DG3Pqbtv.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-DhPOPaRT.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function isRecord(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
function asString(value, max, fallback = "") {
	return typeof value === "string" ? value.slice(0, max) : fallback;
}
function asBool(value, fallback = false) {
	return typeof value === "boolean" ? value : fallback;
}
function asNumber(value, min, max, fallback) {
	if (typeof value !== "number" || !Number.isFinite(value)) return fallback;
	return Math.min(max, Math.max(min, value));
}
function oneOf(value, allowed, fallback) {
	return typeof value === "string" && allowed.includes(value) ? value : fallback;
}
function readGame(value) {
	if (!isRecord(value) || typeof value.id !== "string" || typeof value.name !== "string") return null;
	const name = value.name.trim().slice(0, 60);
	if (!name) return null;
	const target = typeof value.fpsTarget === "number" && isFpsTarget(value.fpsTarget) ? value.fpsTarget : 60;
	const image = typeof value.image === "string" && value.image.startsWith("data:image/") && value.image.length < 4e5 ? value.image : null;
	return {
		id: value.id.slice(0, 80),
		name,
		launchUrl: asString(value.launchUrl, 500),
		notes: asString(value.notes, 2e3),
		image,
		preset: oneOf(value.preset, PRESETS, "balanced"),
		graphics: oneOf(value.graphics, GRAPHICS, "medium"),
		fpsTarget: target,
		resolutionScale: oneOf(value.resolutionScale, SCALE, "native"),
		shadows: oneOf(value.shadows, DETAIL, "low"),
		effects: oneOf(value.effects, DETAIL, "low"),
		aa: oneOf(value.aa, AA, "fxaa"),
		vsync: value.vsync === "off" ? "off" : "on"
	};
}
function readPoints(value) {
	if (!Array.isArray(value)) return [];
	return value.slice(0, 12).flatMap((point) => {
		if (!isRecord(point) || typeof point.id !== "string") return [];
		return [{
			id: point.id.slice(0, 80),
			label: asString(point.label, 40, "Point"),
			x: asNumber(point.x, 0, 100, 50),
			y: asNumber(point.y, 0, 100, 50),
			delayMs: Math.round(asNumber(point.delayMs, 50, 6e4, 500))
		}];
	});
}
function readClicker(value, fallback) {
	if (!isRecord(value)) return fallback;
	const points = readPoints(value.points);
	return {
		intervalMs: Math.round(asNumber(value.intervalMs, 50, 6e4, fallback.intervalMs)),
		repeat: Math.round(asNumber(value.repeat, 0, 9999, fallback.repeat)),
		durationSec: Math.round(asNumber(value.durationSec, 0, 86400, fallback.durationSec)),
		mode: value.mode === "sequence" ? "sequence" : "single",
		points: points.length > 0 ? points : fallback.points
	};
}
function exportBackup(state) {
	return {
		app: "frameforge-booyah",
		version: 1,
		exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
		state
	};
}
function parseBackup(raw) {
	if (!isRecord(raw)) return {
		ok: false,
		error: "That file is not a FrameForge backup."
	};
	if (raw.app !== "frameforge-booyah" || raw.version !== 1 || !isRecord(raw.state)) return {
		ok: false,
		error: "This file is not a FrameForge BOOYAH v1 backup."
	};
	const base = freshState();
	const state = raw.state;
	if (!Array.isArray(state.games)) return {
		ok: false,
		error: "The backup is missing the game list."
	};
	const games = state.games.map(readGame).filter((game) => game !== null);
	if (games.length !== state.games.length) return {
		ok: false,
		error: "One of the saved games could not be read."
	};
	const ids = new Set(games.map((game) => game.id));
	if (ids.size !== games.length) return {
		ok: false,
		error: "The backup has duplicate game ids."
	};
	const selected = typeof state.selectedGameId === "string" && ids.has(state.selectedGameId) ? state.selectedGameId : games[0]?.id ?? null;
	const rawWidgets = Array.isArray(state.widgets) ? state.widgets : null;
	const widgets = rawWidgets ? WIDGETS.map((widget) => {
		const found = rawWidgets.find((item) => isRecord(item) && item.id === widget.id);
		return {
			id: widget.id,
			visible: found && isRecord(found) ? asBool(found.visible, true) : true
		};
	}) : base.widgets;
	const ordered = [];
	if (rawWidgets) for (const item of rawWidgets) {
		if (!isRecord(item) || typeof item.id !== "string") continue;
		const known = WIDGETS.find((widget) => widget.id === item.id);
		if (!known || ordered.some((widget) => widget.id === known.id)) continue;
		ordered.push({
			id: known.id,
			visible: asBool(item.visible, true)
		});
	}
	for (const widget of widgets) if (!ordered.some((item) => item.id === widget.id)) ordered.push(widget);
	const fpsLogs = Array.isArray(state.fpsLogs) ? state.fpsLogs.slice(0, 200).flatMap((entry) => {
		if (!isRecord(entry) || typeof entry.id !== "string" || typeof entry.measuredFps !== "number") return [];
		if (!isFpsTarget(entry.targetFps)) return [];
		const measured = Math.round(entry.measuredFps);
		if (measured < 1 || measured > 1e3) return [];
		return [{
			id: entry.id.slice(0, 80),
			gameId: typeof entry.gameId === "string" && ids.has(entry.gameId) ? entry.gameId : null,
			measuredFps: measured,
			targetFps: entry.targetFps,
			refreshHz: typeof entry.refreshHz === "number" ? entry.refreshHz : null,
			note: asString(entry.note, 200),
			at: asNumber(entry.at, 0, 9e15, Date.now())
		}];
	}) : [];
	const compares = Array.isArray(state.compares) ? state.compares.slice(0, 100).flatMap((entry) => {
		if (!isRecord(entry) || typeof entry.id !== "string" || typeof entry.measuredFps !== "number") return [];
		const measured = Math.round(entry.measuredFps);
		if (measured < 1 || measured > 1e3) return [];
		return [{
			id: entry.id.slice(0, 80),
			label: asString(entry.label, 60, "Untitled run"),
			gameId: typeof entry.gameId === "string" && ids.has(entry.gameId) ? entry.gameId : null,
			preset: asString(entry.preset, 40, "Custom"),
			measuredFps: measured,
			targetFps: asNumber(entry.targetFps, 1, 1e3, 60),
			note: asString(entry.note, 200),
			at: asNumber(entry.at, 0, 9e15, Date.now())
		}];
	}) : [];
	const notes = Array.isArray(state.notes) ? state.notes.slice(0, 100).flatMap((entry) => {
		if (!isRecord(entry) || typeof entry.id !== "string") return [];
		const title = asString(entry.title, 80).trim();
		if (!title) return [];
		return [{
			id: entry.id.slice(0, 80),
			title,
			body: asString(entry.body, 2e3),
			gameId: typeof entry.gameId === "string" && ids.has(entry.gameId) ? entry.gameId : null,
			at: asNumber(entry.at, 0, 9e15, Date.now())
		}];
	}) : [];
	const clickPresets = Array.isArray(state.clickPresets) ? state.clickPresets.slice(0, 30).flatMap((entry) => {
		if (!isRecord(entry) || typeof entry.id !== "string") return [];
		const name = asString(entry.name, 40).trim();
		if (!name) return [];
		return [{
			id: entry.id.slice(0, 80),
			name,
			...readClicker(entry, base.clicker)
		}];
	}) : base.clickPresets;
	let refreshSample = null;
	if (isRecord(state.refreshSample) && typeof state.refreshSample.displayHz === "number") refreshSample = {
		displayHz: Math.round(asNumber(state.refreshSample.displayHz, 1, 300, 60)),
		rawHz: asNumber(state.refreshSample.rawHz, 1, 300, state.refreshSample.displayHz),
		frames: Math.round(asNumber(state.refreshSample.frames, 0, 1e5, 0)),
		at: asNumber(state.refreshSample.at, 0, 9e15, Date.now()),
		snapped: asBool(state.refreshSample.snapped)
	};
	const thermal = {};
	if (isRecord(state.thermal)) {
		for (const [key, value] of Object.entries(state.thermal)) if (typeof value === "boolean") thermal[key.slice(0, 40)] = value;
	}
	const tutorialsSeen = {};
	if (isRecord(state.tutorialsSeen)) {
		for (const [key, value] of Object.entries(state.tutorialsSeen)) if (typeof value === "boolean") tutorialsSeen[key.slice(0, 40)] = value;
	}
	const session = isRecord(state.session) ? {
		running: asBool(state.session.running),
		startedAt: typeof state.session.startedAt === "number" ? state.session.startedAt : null,
		accumulatedMs: Math.max(0, asNumber(state.session.accumulatedMs, 0, 0xe8d4a51000, 0))
	} : base.session;
	return {
		ok: true,
		data: {
			theme: oneOf(state.theme, THEMES, "dark"),
			accent: oneOf(state.accent, ACCENTS.map((item) => item.id), "crimson"),
			background: oneOf(state.background, BACKGROUNDS.map((item) => item.id), "graphite"),
			density: oneOf(state.density, DENSITIES, "comfortable"),
			motion: oneOf(state.motion, MOTIONS, "subtle"),
			cardStyle: oneOf(state.cardStyle, CARD_STYLES, "poster"),
			keepAwake: asBool(state.keepAwake),
			widgets: ordered,
			selectedGameId: selected,
			games,
			session,
			fpsLogs,
			compares,
			notes,
			clicker: readClicker(state.clicker, base.clicker),
			clickPresets,
			refreshSample,
			thermal,
			tutorialsSeen
		}
	};
}
function SettingsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "stack",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				id: "customize",
				kicker: "Customize",
				title: "Settings",
				subtitle: "Appearance, home layout, and the data stored in this browser. No account."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Appearance, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Widgets, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OverlayPreview, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataPanel, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InstallPanel, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Limits, {})
		]
	});
}
function Appearance() {
	const theme = useAppStore((state) => state.theme);
	const accent = useAppStore((state) => state.accent);
	const background = useAppStore((state) => state.background);
	const density = useAppStore((state) => state.density);
	const motion = useAppStore((state) => state.motion);
	const cardStyle = useAppStore((state) => state.cardStyle);
	const keepAwake = useAppStore((state) => state.keepAwake);
	const setTheme = useAppStore((state) => state.setTheme);
	const setAccent = useAppStore((state) => state.setAccent);
	const setBackground = useAppStore((state) => state.setBackground);
	const setDensity = useAppStore((state) => state.setDensity);
	const setMotion = useAppStore((state) => state.setMotion);
	const setCardStyle = useAppStore((state) => state.setCardStyle);
	const setKeepAwake = useAppStore((state) => state.setKeepAwake);
	const wakeSupported = useWakeSupport();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
		id: "appearance",
		title: "Appearance",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "stack",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
					label: "Theme",
					value: theme,
					options: THEMES.map((id) => ({
						id,
						label: id === "system" ? "System" : id === "dark" ? "Dark" : "Light"
					})),
					onChange: setTheme
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
					label: "Background",
					value: background,
					options: BACKGROUNDS.map((item) => ({
						id: item.id,
						label: item.label
					})),
					onChange: setBackground
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 text-sm font-semibold",
					children: "Accent"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2",
					children: ACCENTS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-pressed": accent === item.id,
						onClick: () => setAccent(item.id),
						className: `min-h-11 rounded-lg px-3 text-sm font-semibold ${accent === item.id ? "bg-primary text-primary-fg" : "bg-surface-2"}`,
						children: item.label
					}, item.id))
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
					label: "Density",
					value: density,
					options: DENSITIES.map((id) => ({
						id,
						label: id === "compact" ? "Compact" : "Comfortable"
					})),
					onChange: setDensity
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
					label: "Animation",
					value: motion,
					options: MOTIONS.map((id) => ({
						id,
						label: id === "off" ? "Off" : id === "full" ? "Full" : "Subtle"
					})),
					onChange: setMotion
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
					label: "Game cards",
					value: cardStyle,
					options: [{
						id: "poster",
						label: "Poster"
					}, {
						id: "row",
						label: "Row"
					}],
					onChange: setCardStyle
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex min-h-11 items-start gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						className: "mt-1 size-5",
						checked: keepAwake,
						disabled: wakeSupported === false,
						onChange: (event) => setKeepAwake(event.target.checked)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-sm font-semibold",
						children: "Keep the screen awake during a session"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-sm text-muted",
						children: wakeSupported === false ? "Not available in this version." : "Uses the Screen Wake Lock API only while the session timer is running and this tab is visible."
					})] })]
				})
			]
		})
	});
}
function Widgets() {
	const widgets = useAppStore((state) => state.widgets);
	const setVisible = useAppStore((state) => state.setWidgetVisible);
	const move = useAppStore((state) => state.moveWidget);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
		id: "widgets",
		title: "Home widgets",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "stack",
			children: widgets.map((widget, index) => {
				const meta = WIDGETS.find((item) => item.id === widget.id);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center gap-2 rounded-lg bg-surface-2 p-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex min-h-11 min-w-0 flex-1 items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								className: "size-5",
								checked: widget.visible,
								onChange: (event) => setVisible(widget.id, event.target.checked)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-sm font-semibold",
									children: meta?.label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-xs text-faint",
									children: meta?.detail
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							className: "px-2",
							"aria-label": `Move ${meta?.label} up`,
							disabled: index === 0,
							onClick: () => move(widget.id, -1),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							className: "px-2",
							"aria-label": `Move ${meta?.label} down`,
							disabled: index === widgets.length - 1,
							onClick: () => move(widget.id, 1),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, { className: "size-4" })
						})
					]
				}, widget.id);
			})
		})
	});
}
function OverlayPreview() {
	const game = useSelectedGame();
	const logs = useAppStore((state) => state.fpsLogs);
	const sample = useAppStore((state) => state.refreshSample);
	const last = logs.find((entry) => game ? entry.gameId === game.id : true);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		id: "overlay",
		title: "Performance overlay",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 text-sm font-semibold",
				children: "Preview only. Not a system overlay."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl bg-bg p-4 shadow-[var(--shadow-ring)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold tracking-widest text-primary uppercase",
						children: "Preview"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: game?.name ?? "No profile selected"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-3 grid grid-cols-3 gap-2 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-xs text-faint",
								children: "Target"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "font-display text-2xl font-semibold tabular-nums",
								children: game ? game.fpsTarget : "—"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-xs text-faint",
								children: "Measured"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "font-display text-2xl font-semibold tabular-nums",
								children: last ? last.measuredFps : "—"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-xs text-faint",
								children: "Refresh"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "font-display text-2xl font-semibold tabular-nums",
								children: sample ? sample.displayHz : "—"
							})] })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-xs text-faint",
						children: [
							game ? `${presetLabel(game.preset)} preset saved on the profile.` : "Select a profile to fill the target.",
							" ",
							last ? "Measured value is your last manual log." : "No manual FPS log yet.",
							" Frame generation unavailable in this version."
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted",
				children: "A real overlay on top of other apps needs a native Android implementation. This mockup never leaves this page."
			})
		]
	});
}
function DataPanel() {
	const storageMode = useRuntime((state) => state.storageMode);
	const replaceState = useAppStore((state) => state.replaceState);
	const restoreDefaults = useAppStore((state) => state.restoreDefaults);
	const resetAll = useAppStore((state) => state.resetAll);
	const [bytes, setBytes] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const update = () => {
			const state = useAppStore.getState();
			const payload = exportBackup({
				theme: state.theme,
				accent: state.accent,
				background: state.background,
				density: state.density,
				motion: state.motion,
				cardStyle: state.cardStyle,
				keepAwake: state.keepAwake,
				widgets: state.widgets,
				selectedGameId: state.selectedGameId,
				games: state.games,
				session: state.session,
				fpsLogs: state.fpsLogs,
				compares: state.compares,
				notes: state.notes,
				clicker: state.clicker,
				clickPresets: state.clickPresets,
				refreshSample: state.refreshSample,
				thermal: state.thermal,
				tutorialsSeen: state.tutorialsSeen
			});
			setBytes(new Blob([JSON.stringify(payload)]).size);
		};
		update();
		return useAppStore.subscribe(update);
	}, []);
	const [message, setMessage] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	const [pendingFile, setPendingFile] = (0, import_react.useState)(null);
	const [confirmImport, setConfirmImport] = (0, import_react.useState)(false);
	const [confirmDefaults, setConfirmDefaults] = (0, import_react.useState)(false);
	const [confirmReset, setConfirmReset] = (0, import_react.useState)(false);
	function download() {
		const payload = exportBackup(useAppStore.getState());
		const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
		const url = URL.createObjectURL(blob);
		const link = document.createElement("a");
		link.href = url;
		link.download = "frameforge-booyah.json";
		link.click();
		URL.revokeObjectURL(url);
		setError(null);
		setMessage("Backup file downloaded. It stays on this device unless you share it.");
	}
	async function applyImport() {
		if (!pendingFile) return;
		if (pendingFile.size > 15e5) {
			setError("That file is too large to import.");
			return;
		}
		try {
			const text = await pendingFile.text();
			const parsed = parseBackup(JSON.parse(text));
			if (!parsed.ok) {
				setError(parsed.error);
				setMessage(null);
				return;
			}
			stopClicker("Stopped because a backup was imported.");
			replaceState(parsed.data);
			setMessage("Backup imported on this device. Previous data in this browser was replaced.");
			setError(null);
			setPendingFile(null);
			setConfirmImport(false);
		} catch {
			setError("Could not read that JSON file.");
			setMessage(null);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
		id: "data",
		title: "Data",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "stack",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Profiles, logs, presets, and appearance are stored in this browser with localStorage. Nothing is uploaded, and basic use does not need an account. Clearing site data in the browser, or Reset all data below, removes it. A private tab may drop it when the tab closes."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						"Storage status: ",
						storageMode === "local" ? "saving on this device" : storageMode === "memory" ? "memory only for this tab" : storageMode === "unreadable" ? "saved data could not be read" : "checking",
						". Current backup size about ",
						bytes == null ? "…" : formatBytes(bytes),
						"."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: download,
						children: "Export JSON"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "inline-flex min-h-11 items-center rounded-lg bg-surface-2 px-4 text-sm font-semibold",
						children: ["Choose backup", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "sr-only",
							type: "file",
							accept: "application/json,.json",
							onChange: (event) => {
								setPendingFile(event.target.files?.[0] ?? null);
								setConfirmImport(false);
								setError(null);
								event.target.value = "";
							}
						})]
					})]
				}),
				pendingFile ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm",
					children: ["Selected ", pendingFile.name]
				}) : null,
				pendingFile && !confirmImport ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "quiet",
					onClick: () => setConfirmImport(true),
					children: "Import and replace saved data"
				}) : null,
				confirmImport ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => void applyImport(),
						children: "Replace saved data"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "quiet",
						onClick: () => setConfirmImport(false),
						children: "Cancel"
					})]
				}) : null,
				confirmDefaults ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => {
							restoreDefaults();
							setConfirmDefaults(false);
							setMessage("Appearance, widgets, and the clicker setup were restored. Games and logs were kept.");
						},
						children: "Confirm restore"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "quiet",
						onClick: () => setConfirmDefaults(false),
						children: "Cancel"
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "quiet",
					onClick: () => setConfirmDefaults(true),
					children: "Restore defaults"
				}),
				confirmReset ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => {
							stopClicker("Stopped because data was reset.");
							resetAll();
							setConfirmReset(false);
							setMessage("All FrameForge data in this browser was reset.");
						},
						children: "Confirm reset all data"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "quiet",
						onClick: () => setConfirmReset(false),
						children: "Cancel"
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "quiet",
					onClick: () => setConfirmReset(true),
					children: "Reset all data"
				}),
				message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, {
					tone: "ok",
					children: message
				}) : null,
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, {
					tone: "warn",
					children: error
				}) : null
			]
		})
	});
}
function InstallPanel() {
	const [standalone, setStandalone] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		setStandalone(window.matchMedia("(display-mode: standalone)").matches);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
		id: "install",
		title: "Add to the Android home screen",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "stack text-sm text-muted",
			children: [
				standalone ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-semibold text-ok",
					children: "This session is already running from the home screen."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "This session is running in a browser tab." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
					className: "list-decimal space-y-2 pl-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Publish the app from the Grok builder, then open the public link in Android Chrome." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Tap the Chrome menu, the three dots." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Tap Install app or Add to Home screen." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Confirm. Launch FrameForge from the icon like any other app." })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Samsung Internet has its own menu item for adding a page to the home screen. The preview inside chat may not offer install. Use the published link in the phone's browser." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "This is an installable web app. It is not an Android APK, and it does not need root." })
			]
		})
	});
}
function Limits() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		id: "limits",
		title: "What this version can do",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-display text-base font-semibold",
				children: "Works now"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-2 list-disc space-y-2 pl-5 text-sm text-muted",
				children: WORKS_NOW.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: item }, item))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-4 font-display text-base font-semibold",
				children: "Needs a native Android app"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-2 list-disc space-y-2 pl-5 text-sm text-muted",
				children: NEEDS_NATIVE.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: item }, item))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-muted",
				children: "No Steam, no Lossless Scaling, no paid API, no subscription, and no account are required for what this page actually does."
			})
		]
	});
}
function Choice({ label, value, options, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
		label,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-wrap gap-2",
			children: options.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-pressed": value === option.id,
				onClick: () => onChange(option.id),
				className: `min-h-11 rounded-lg px-3 text-sm font-semibold capitalize ${value === option.id ? "bg-primary text-primary-fg" : "bg-surface-2"}`,
				children: option.label
			}, option.id))
		})
	});
}
function useWakeSupport() {
	const [supported, setSupported] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		setSupported("wakeLock" in navigator);
	}, []);
	return supported;
}
var SplitComponent = SettingsPage;
//#endregion
export { SplitComponent as component };
