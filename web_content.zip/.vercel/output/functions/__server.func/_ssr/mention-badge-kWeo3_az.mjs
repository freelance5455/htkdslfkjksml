import { o as mentionFromAverage } from "./calc-DDlXNlj6.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/mention-badge-kWeo3_az.js
var import_jsx_runtime = require_jsx_runtime();
var badgeVariants = cva("inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium", {
	variants: { variant: {
		default: "bg-primary/10 text-primary",
		excellence: "bg-primary text-primary-fg",
		"very-good": "bg-accent/15 text-accent",
		good: "bg-success/10 text-success",
		fair: "bg-warn/10 text-warn",
		fail: "bg-danger/10 text-danger",
		muted: "bg-surface-2 text-muted"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
var mentionTone = {
	امتياز: "excellence",
	"جيد جداً": "very-good",
	جيد: "good",
	"قريب من الجيد": "fair",
	"بدون تقدير": "fail"
};
function MentionBadge({ mention, decision, average }) {
	if (average != null) {
		const computed = mentionFromAverage(average);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
			variant: computed.tone,
			children: computed.mention
		});
	}
	if (!mention && !decision) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		variant: "muted",
		children: "قيد الإدخال"
	});
	if (decision === "راسب") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		variant: "fail",
		children: mention ?? "راسب"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		variant: mentionTone[mention ?? ""] ?? "default",
		children: mention
	});
}
function DecisionBadge({ decision }) {
	if (!decision) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		variant: "muted",
		children: "غير محسوم"
	});
	if (decision === "ناجح") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		variant: "good",
		children: "ناجح"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		variant: "fail",
		children: "راسب"
	});
}
//#endregion
export { MentionBadge as n, DecisionBadge as t };
