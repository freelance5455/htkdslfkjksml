//#region node_modules/.nitro/vite/services/ssr/assets/recipe-CSjsxg-s.js
var GRADES = [
	"neutral",
	"cinematic",
	"warm",
	"cool",
	"mono",
	"bleach",
	"noir",
	"vivid",
	"fade",
	"teal"
];
var MUSICS = [
	"none",
	"pulse",
	"air",
	"drift",
	"keys"
];
var GRADE_LABEL = {
	neutral: "Natural",
	cinematic: "Cinematic",
	warm: "Warm",
	cool: "Cool",
	mono: "Monochrome",
	bleach: "Bleach bypass",
	noir: "Noir",
	vivid: "Vivid",
	fade: "Faded",
	teal: "Teal"
};
var MUSIC_LABEL = {
	none: "No added score",
	pulse: "Pulse",
	air: "Air",
	drift: "Drift",
	keys: "Keys"
};
var GRADE_FILTER = {
	neutral: "",
	cinematic: "contrast(1.12) saturate(0.88) sepia(0.14)",
	warm: "sepia(0.32) saturate(1.18) contrast(1.04) brightness(1.04)",
	cool: "saturate(0.82) hue-rotate(14deg) contrast(1.06) brightness(0.96)",
	mono: "grayscale(1) contrast(1.12)",
	bleach: "saturate(0.4) contrast(1.22) brightness(1.08)",
	noir: "grayscale(1) contrast(1.38) brightness(0.9)",
	vivid: "saturate(1.5) contrast(1.08)",
	fade: "contrast(0.88) brightness(1.08) saturate(0.72) sepia(0.18)",
	teal: "saturate(1.12) contrast(1.1) hue-rotate(-8deg) sepia(0.12)"
};
var MAX_OUTPUT_SECONDS = 40;
function num(value, fallback, min, max) {
	const n = typeof value === "number" ? value : typeof value === "string" ? Number(value) : NaN;
	if (!Number.isFinite(n)) return fallback;
	return Math.min(max, Math.max(min, n));
}
function flag(value, fallback) {
	if (typeof value === "boolean") return value;
	return fallback;
}
function clampRecipe(input) {
	const grade = GRADES.includes(input?.grade) ? input?.grade : "neutral";
	const music = MUSICS.includes(input?.music) ? input?.music : "none";
	let trimStart = num(input?.trimStart, 0, 0, .85);
	let trimEnd = num(input?.trimEnd, 1, .05, 1);
	if (trimEnd <= trimStart + .05) trimEnd = Math.min(1, trimStart + .15);
	if (trimStart >= trimEnd) trimStart = Math.max(0, trimEnd - .15);
	let titleStart = num(input?.titleStart, .08, 0, .9);
	let titleEnd = num(input?.titleEnd, .42, .05, 1);
	if (titleEnd <= titleStart) titleEnd = Math.min(1, titleStart + .2);
	const captions = [];
	if (Array.isArray(input?.captions)) for (const item of input.captions) {
		if (!item || typeof item !== "object") continue;
		const text = String(item.text ?? "").trim().slice(0, 80);
		if (!text) continue;
		let start = num(item.start, .1, 0, .95);
		let end = num(item.end, .4, .05, 1);
		if (end <= start) end = Math.min(1, start + .15);
		captions.push({
			text,
			start,
			end
		});
		if (captions.length === 4) break;
	}
	const startSec = input?.trimStartSec;
	const endSec = input?.trimEndSec;
	return {
		summary: String(input?.summary ?? "").trim().slice(0, 180),
		title: String(input?.title ?? "").trim().slice(0, 60),
		subtitle: String(input?.subtitle ?? "").trim().slice(0, 80),
		grade,
		speed: Math.round(num(input?.speed, 1, .5, 2) * 100) / 100,
		trimStart,
		trimEnd,
		trimStartSec: typeof startSec === "number" && Number.isFinite(startSec) ? Math.max(0, startSec) : null,
		trimEndSec: typeof endSec === "number" && Number.isFinite(endSec) ? Math.max(0, endSec) : null,
		brightness: num(input?.brightness, 1, .8, 1.25),
		contrast: num(input?.contrast, 1, .8, 1.35),
		saturation: num(input?.saturation, 1, 0, 1.7),
		vignette: num(input?.vignette, 0, 0, .8),
		grain: num(input?.grain, 0, 0, .5),
		letterbox: flag(input?.letterbox, false),
		zoom: num(input?.zoom, 1, 1, 1.18),
		fadeIn: num(input?.fadeIn, 0, 0, 1.4),
		fadeOut: num(input?.fadeOut, 0, 0, 1.6),
		titleStart,
		titleEnd,
		captions,
		music,
		musicGain: music === "none" ? 0 : num(input?.musicGain, .12, 0, .22),
		sourceGain: num(input?.sourceGain, 1, 0, 1),
		blur: num(input?.blur, 0, 0, 2.5)
	};
}
var NEUTRAL_RECIPE = clampRecipe({
	grade: "neutral",
	speed: 1,
	music: "none",
	sourceGain: 1
});
function windowFor(recipe, duration) {
	const safe = Number.isFinite(duration) && duration > 0 ? duration : 1;
	let start = recipe.trimStart * safe;
	let end = recipe.trimEnd * safe;
	if (recipe.trimStartSec != null) start = recipe.trimStartSec;
	if (recipe.trimEndSec != null) end = recipe.trimEndSec;
	start = Math.min(Math.max(0, start), Math.max(0, safe - .35));
	end = Math.min(safe, Math.max(start + .35, end));
	const maxSpan = MAX_OUTPUT_SECONDS * recipe.speed;
	const capped = end - start > maxSpan;
	if (capped) end = start + maxSpan;
	return {
		start,
		end,
		capped
	};
}
function frameFilter(recipe) {
	return `${GRADE_FILTER[recipe.grade]} brightness(${recipe.brightness}) contrast(${recipe.contrast}) saturate(${recipe.saturation}) blur(${recipe.blur}px)`.trim();
}
function formatTime(seconds) {
	if (!Number.isFinite(seconds) || seconds < 0) seconds = 0;
	const whole = Math.floor(seconds);
	return `${Math.floor(whole / 60)}:${String(whole % 60).padStart(2, "0")}`;
}
function summarize(recipe) {
	const bits = [`${GRADE_LABEL[recipe.grade]} grade`];
	if (recipe.speed < .99) bits.push("slowed");
	if (recipe.speed > 1.05) bits.push("sped up");
	if (recipe.letterbox) bits.push("film bars");
	if (recipe.title) bits.push(`title “${recipe.title}”`);
	if (recipe.captions.length) bits.push("captions");
	if (recipe.music !== "none") bits.push(`${MUSIC_LABEL[recipe.music]} score`);
	if (recipe.sourceGain === 0) bits.push("original audio muted");
	const line = bits.join(", ");
	return `${line.charAt(0).toUpperCase()}${line.slice(1)}.`;
}
function quotes(prompt) {
	const found = [];
	const re = /[“"]([^”"]{1,80})[”"]/g;
	let match;
	while (match = re.exec(prompt)) {
		const text = match[1]?.trim();
		if (text) found.push(text);
	}
	return found;
}
function spreadCaptions(lines) {
	if (!lines.length) return [];
	const span = .7 / lines.length;
	return lines.slice(0, 4).map((text, index) => {
		const start = .12 + index * span;
		return {
			text,
			start,
			end: Math.min(.92, start + span * .86)
		};
	});
}
function pickGrade(text) {
	if (/noir|chiaroscuro/.test(text)) return "noir";
	if (/black and white|black & white|black-and-white|\bb&w\b|monochrome|grayscale|grey ?scale/.test(text)) return "mono";
	if (/teal/.test(text)) return "teal";
	if (/bleach|washed out/.test(text)) return "bleach";
	if (/golden|warm|sunset|summer|cozy|amber/.test(text)) return "warm";
	if (/cold|cool|winter|blue hour|icy|moonlit|moon light/.test(text)) return "cool";
	if (/vivid|punchy|saturated|\bpop\b|hype/.test(text)) return "vivid";
	if (/vintage|retro|faded|pastel|dream/.test(text)) return "fade";
	if (/cinematic|trailer|film|movie|anamorphic|letterbox/.test(text)) return "cinematic";
	return "neutral";
}
function interpretPrompt(prompt) {
	const text = prompt.toLowerCase();
	const quoted = quotes(prompt);
	let grade = pickGrade(text);
	let speed = 1;
	if (/time-?lapse|hyperlapse|hyper speed/.test(text)) speed = 2;
	else if (/fast|quick|hype|energetic|snappy|tight cut/.test(text)) speed = 1.4;
	else if (/slow-?mo|slow motion|slo-mo/.test(text)) speed = .5;
	else if (/dreamy|dream|linger|gentle|a little slower|bit slower|slower|\bslow\b/.test(text)) speed = .75;
	let music = "none";
	if (/no music|without music|mute the (music|score)|no score/.test(text)) music = "none";
	else if (/piano|keys|bells/.test(text)) music = "keys";
	else if (/upbeat|hype|punchy beat|party|energetic|pulse/.test(text)) music = "pulse";
	else if (/airy|ambient|soft score|dream/.test(text)) music = "air";
	else if (/cinematic|trailer|epic|orchestr|score|film music/.test(text)) music = "drift";
	let sourceGain = 1;
	if (!/no music|without music|mute the (music|score)/.test(text) && /mute|no sound|silent|no audio/.test(text)) {
		sourceGain = 0;
		if (!/score|music/.test(text)) music = "none";
	}
	const wantsCaption = /caption|subtitle|lower third|on-screen text/.test(text);
	const wantsTitle = /title|called|headline/.test(text);
	let title = "";
	let captions = [];
	if (wantsCaption && !wantsTitle) captions = spreadCaptions(quoted);
	else if (quoted.length) {
		title = quoted[0] ?? "";
		if (wantsCaption) captions = spreadCaptions(quoted.length > 1 ? quoted.slice(1) : quoted);
	}
	let letterbox = /letterbox|cinematic|trailer|widescreen|film bars|anamorphic/.test(text);
	let vignette = 0;
	let grain = 0;
	let zoom = 1;
	if (grade === "noir") vignette = .62;
	if (grade === "cinematic" || /trailer/.test(text)) {
		letterbox = true;
		vignette = Math.max(vignette, .38);
		grain = .14;
		zoom = 1.08;
	}
	if (/grain|vintage|retro|film/.test(text)) grain = Math.max(grain, .22);
	if (/vignette|dark edges/.test(text)) vignette = Math.max(vignette, .5);
	if (/push-?in|ken burns|slow zoom|zoom/.test(text)) zoom = Math.max(zoom, 1.1);
	if (grade === "fade" || /dream/.test(text)) {
		grain = Math.max(grain, .1);
		zoom = Math.max(zoom, 1.06);
	}
	let fadeIn = .35;
	let fadeOut = .55;
	if (/no fade|hard cut|don't fade|do not fade/.test(text)) {
		fadeIn = 0;
		fadeOut = 0;
	}
	let trimStart = 0;
	let trimEnd = 1;
	let trimStartSec = null;
	let trimEndSec = null;
	const skipSeconds = text.match(/skip (?:the )?first (\d+(?:\.\d+)?)\s*(?:s|sec|seconds)?/);
	const onlyFirst = text.match(/only (?:the )?first (\d+(?:\.\d+)?)\s*(?:s|sec|seconds)?/);
	if (skipSeconds?.[1]) trimStartSec = Number(skipSeconds[1]);
	if (onlyFirst?.[1]) trimEndSec = Number(onlyFirst[1]);
	if (/skip (?:the )?(?:intro|start|beginning|opening)/.test(text)) trimStart = .08;
	if (/cut (?:the )?(?:end|ending|outro)|drop the end/.test(text)) trimEnd = .88;
	if (/only the ending|just the end|last part/.test(text)) trimStart = Math.max(trimStart, .55);
	let blur = 0;
	if (/soft focus|dreamy|dream|hazy|haze/.test(text)) blur = .6;
	let brightness = 1;
	let contrast = 1;
	if (/darker|dimmer/.test(text)) brightness = .9;
	if (/brighter|lighter/.test(text)) brightness = 1.08;
	if (/high contrast|contrasty/.test(text)) contrast = 1.16;
	if (/flat|low contrast/.test(text)) contrast = .9;
	const drafted = clampRecipe({
		grade,
		speed,
		music,
		sourceGain,
		title,
		captions,
		letterbox,
		vignette,
		grain,
		zoom,
		fadeIn,
		fadeOut,
		trimStart,
		trimEnd,
		trimStartSec,
		trimEndSec,
		blur,
		brightness,
		contrast
	});
	const recipe = drafted.grade !== "neutral" || drafted.speed !== 1 || drafted.title.length > 0 || drafted.captions.length > 0 || drafted.music !== "none" || drafted.sourceGain === 0 || drafted.letterbox || drafted.trimStart > 0 || drafted.trimEnd < 1 || drafted.trimStartSec != null || drafted.trimEndSec != null ? drafted : clampRecipe({
		...drafted,
		grade: "cinematic",
		letterbox: true,
		vignette: .36,
		grain: .12,
		zoom: 1.06,
		fadeIn: .4,
		fadeOut: .6
	});
	return {
		...recipe,
		summary: summarize(recipe)
	};
}
function recipeNotes(recipe, duration) {
	const { start, end } = windowFor(recipe, duration);
	const notes = [
		GRADE_LABEL[recipe.grade],
		recipe.speed === 1 ? "Normal pace" : `${recipe.speed.toFixed(2)}× pace`,
		`${formatTime(start)}–${formatTime(end)}`,
		MUSIC_LABEL[recipe.music]
	];
	if (recipe.sourceGain === 0) notes.push("Clip muted");
	if (recipe.title) notes.push(`“${recipe.title}”`);
	return notes;
}
//#endregion
export { interpretPrompt as a, frameFilter as i, clampRecipe as n, recipeNotes as o, formatTime as r, windowFor as s, NEUTRAL_RECIPE as t };
