import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { y as useJournalBook } from "./use-books-BtZpLk9U.mjs";
import { h as todayIso, s as formatJalali } from "./format-c9GA3s0l.mjs";
import { i as PageHeader, r as Money, t as Badge } from "./card-Bb_-PO54.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/journals-C0qHI6NS.js
var import_jsx_runtime = require_jsx_runtime();
function JournalsPage() {
	const { data = [] } = useJournalBook("2026-03-21", todayIso());
	const grouped = /* @__PURE__ */ new Map();
	for (const row of data) {
		const list = grouped.get(row.journalId) ?? [];
		list.push(row);
		grouped.set(row.journalId, list);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		title: "اسناد حسابداری",
		description: "هر سند حداقل دو ردیف متوازن دارد. مسیر ردیابی: گزارش → حساب → سند → عملیات → کاربر."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-3",
		children: [...grouped.values()].map((lines) => {
			const head = lines[0];
			const d = lines.reduce((s, l) => s + l.debit, 0);
			const c = lines.reduce((s, l) => s + l.credit, 0);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-[22px] border border-line bg-paper p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-medium text-navy",
						children: head.number
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-xs text-muted",
						children: [
							formatJalali(head.date),
							" · ",
							head.journalDescription,
							" · ",
							head.operationNumber
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: head.status === "posted" ? "ok" : "danger",
							children: head.status
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: d === c ? "ok" : "danger",
							children: d === c ? "متوازن" : "نامتوازن"
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("table", {
					className: "mt-3 w-full text-xs",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: lines.map((l, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t border-line",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "py-2",
								children: [
									l.accountCode,
									" ",
									l.accountName
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2",
								children: l.partyName
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 text-left",
								children: l.debit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
									value: l.debit,
									compact: true
								}) : ""
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 text-left",
								children: l.credit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
									value: l.credit,
									compact: true
								}) : ""
							})
						]
					}, i)) })
				})]
			}, head.journalId);
		})
	})] });
}
//#endregion
export { JournalsPage as component };
