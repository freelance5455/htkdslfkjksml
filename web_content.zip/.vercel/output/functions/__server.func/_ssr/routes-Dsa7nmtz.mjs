import { i as __toESM } from "../_runtime.mjs";
import { R as require_react, v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as Settings2, c as ScrollText, d as Mic, f as Download, i as ShieldAlert, l as Radio, m as Bot, n as Trash2, o as Send, p as Command, r as Square, s as Search, u as Network } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Dsa7nmtz.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function uid() {
	return crypto.randomUUID().replace(/-/g, "").slice(0, 16);
}
function formatRelative(ts) {
	const delta = Date.now() - ts;
	const min = Math.round(delta / 6e4);
	if (Math.abs(min) < 1) return "just now";
	if (Math.abs(min) < 60) return `${min}m ago`;
	const hrs = Math.round(min / 60);
	if (Math.abs(hrs) < 24) return `${hrs}h ago`;
	return `${Math.round(hrs / 24)}d ago`;
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium transition-colors transition-transform duration-150 ease-out disabled:pointer-events-none disabled:opacity-40 active:scale-[0.98] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/50", {
	variants: {
		variant: {
			default: "bg-accent text-accent-fg hover:bg-accent/90",
			secondary: "bg-elevated text-fg border border-border hover:border-border-strong",
			ghost: "text-muted hover:text-fg hover:bg-elevated",
			danger: "bg-danger text-fg hover:bg-danger/90",
			outline: "border border-border text-fg hover:bg-elevated"
		},
		size: {
			default: "h-11 px-4 text-sm rounded-[12px]",
			sm: "h-9 px-3 text-sm rounded-[10px]",
			lg: "h-12 px-5 text-base rounded-[14px]",
			icon: "size-11 rounded-[12px]",
			"icon-sm": "size-9 rounded-[10px]"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
	ref,
	className: cn(buttonVariants({
		variant,
		size
	}), className),
	...props
}));
Button.displayName = "Button";
function Badge({ className, tone = "muted", children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium tracking-wide", {
			muted: "bg-elevated text-muted border-border",
			ok: "bg-ok/15 text-ok border-ok/25",
			warn: "bg-warn/15 text-warn border-warn/25",
			danger: "bg-danger/15 text-danger border-danger/25",
			accent: "bg-accent/15 text-accent border-accent/25"
		}[tone], className),
		children
	});
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var askFrieren = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("c4ce772559c0b417e31670dcb4486b978892238fc53563cba9efe209ef13f2c4"));
var now = () => Date.now();
var seedMemories = [{
	id: "m_local",
	content: "FRIEREN is local-first. Consequential actions require explicit confirmation.",
	kind: "fact",
	importance: .9,
	tags: ["safety", "policy"],
	source: "system",
	createdAt: now()
}, {
	id: "m_wake",
	content: "The default wake word is frieren.",
	kind: "preference",
	importance: .6,
	tags: ["voice"],
	source: "system",
	createdAt: now()
}];
var seedNodes = [
	{
		id: "n_frieren",
		label: "FRIEREN",
		kind: "project",
		description: "Local orchestration kernel and command center.",
		createdAt: now()
	},
	{
		id: "n_memory",
		label: "Memory engine",
		kind: "concept",
		description: "Explicit remember / recall / forget. Nothing is silently stored.",
		createdAt: now()
	},
	{
		id: "n_android",
		label: "Device tools",
		kind: "concept",
		description: "Allowlisted capabilities with dry-run and approval gates.",
		createdAt: now()
	}
];
var seedEdges = [{
	id: "e1",
	sourceId: "n_frieren",
	targetId: "n_memory",
	relation: "uses"
}, {
	id: "e2",
	sourceId: "n_frieren",
	targetId: "n_android",
	relation: "uses"
}];
var seedAgents = [
	{
		name: "Planner",
		role: "planner",
		status: "idle"
	},
	{
		name: "Memory",
		role: "memory",
		status: "idle"
	},
	{
		name: "Verifier",
		role: "verifier",
		status: "idle"
	},
	{
		name: "Android",
		role: "android",
		status: "idle"
	},
	{
		name: "Researcher",
		role: "researcher",
		status: "idle"
	}
];
var welcome = {
	id: "msg_hello",
	role: "frieren",
	text: "Ready. This client is local-first and does not embed an API key. Ask for status, remember something, create a task, or speak with the wake word frieren.",
	createdAt: now(),
	status: "completed"
};
var initial = () => ({
	memories: seedMemories,
	tasks: [],
	nodes: seedNodes,
	edges: seedEdges,
	messages: [welcome],
	audit: [],
	recovery: [],
	approvals: [],
	agents: seedAgents,
	granted: [
		"notification",
		"clipboard",
		"tts",
		"battery"
	],
	dryRun: true,
	wakeWord: "frieren",
	voiceArmed: false,
	timeline: []
});
var useFrieren = create()(persist((set, get) => ({
	...initial(),
	remember: (content, kind = "note", tags = []) => {
		const rec = {
			id: uid(),
			content: content.trim(),
			kind,
			importance: .5,
			tags,
			source: "user",
			createdAt: now()
		};
		set({ memories: [rec, ...get().memories] });
		return rec;
	},
	forget: (id) => set({ memories: get().memories.filter((m) => m.id !== id) }),
	recall: (query) => {
		const q = query.toLowerCase();
		return get().memories.filter((m) => m.content.toLowerCase().includes(q) || m.tags.some((t) => t.includes(q)) || m.kind.includes(q)).sort((a, b) => b.importance - a.importance);
	},
	createTask: (title, opts) => {
		const t = {
			id: uid(),
			title: title.trim(),
			description: opts?.description ?? "",
			priority: opts?.priority ?? "normal",
			status: "pending",
			attempts: 0,
			maxAttempts: 3,
			createdAt: now(),
			updatedAt: now()
		};
		set({ tasks: [t, ...get().tasks] });
		return t;
	},
	setTaskStatus: (id, status, extra) => set({ tasks: get().tasks.map((t) => t.id === id ? {
		...t,
		status,
		updatedAt: now(),
		result: extra?.result,
		error: extra?.error
	} : t) }),
	runReadyTasks: () => {
		const ready = get().tasks.filter((t) => t.status === "pending");
		const done = [];
		for (const t of ready) {
			const next = {
				...t,
				status: "completed",
				attempts: t.attempts + 1,
				updatedAt: now(),
				result: "Executed locally after confirmation."
			};
			done.push(next);
		}
		new Set(done.map((d) => d.id));
		set({
			tasks: get().tasks.map((t) => done.find((d) => d.id === t.id) ?? t),
			timeline: [...get().timeline, ...done.map((d) => ({
				id: uid(),
				label: d.title,
				status: "completed",
				detail: "Task executed after confirmation.",
				at: now()
			}))]
		});
		return done;
	},
	upsertNode: (label, kind = "note", description = "") => {
		const existing = get().nodes.find((n) => n.label.toLowerCase() === label.trim().toLowerCase());
		if (existing) {
			const updated = {
				...existing,
				kind,
				description: description || existing.description
			};
			set({ nodes: get().nodes.map((n) => n.id === existing.id ? updated : n) });
			return updated;
		}
		const node = {
			id: uid(),
			label: label.trim(),
			kind,
			description,
			createdAt: now()
		};
		set({ nodes: [node, ...get().nodes] });
		return node;
	},
	addEdge: (sourceId, targetId, relation = "related_to") => {
		if (sourceId === targetId) return null;
		const { nodes, edges } = get();
		if (!nodes.some((n) => n.id === sourceId) || !nodes.some((n) => n.id === targetId)) return null;
		const dup = edges.find((e) => e.sourceId === sourceId && e.targetId === targetId && e.relation === relation);
		if (dup) return dup;
		const edge = {
			id: uid(),
			sourceId,
			targetId,
			relation
		};
		set({ edges: [...edges, edge] });
		return edge;
	},
	deleteNode: (id) => set({
		nodes: get().nodes.filter((n) => n.id !== id),
		edges: get().edges.filter((e) => e.sourceId !== id && e.targetId !== id)
	}),
	addMessage: (msg) => {
		const full = {
			id: msg.id ?? uid(),
			createdAt: now(),
			...msg
		};
		set({ messages: [...get().messages, full] });
		return full;
	},
	patchMessage: (id, patch) => set({ messages: get().messages.map((m) => m.id === id ? {
		...m,
		...patch
	} : m) }),
	logAudit: (message, status) => set({ audit: [...get().audit, {
		id: uid(),
		message,
		status,
		at: now()
	}].slice(-200) }),
	grant: (cap) => {
		if (get().granted.includes(cap)) return;
		set({ granted: [...get().granted, cap] });
	},
	revoke: (cap) => set({ granted: get().granted.filter((c) => c !== cap) }),
	setDryRun: (v) => set({ dryRun: v }),
	setVoiceArmed: (v) => set({ voiceArmed: v }),
	addRecovery: (item) => set({ recovery: [{
		id: uid(),
		createdAt: now(),
		...item
	}, ...get().recovery] }),
	removeRecovery: (id) => set({ recovery: get().recovery.filter((r) => r.id !== id) }),
	addApproval: (item) => {
		const rec = {
			id: uid(),
			createdAt: now(),
			...item
		};
		set({ approvals: [rec, ...get().approvals] });
		return rec;
	},
	removeApproval: (id) => set({ approvals: get().approvals.filter((a) => a.id !== id) }),
	addTimeline: (item) => set({ timeline: [...get().timeline, {
		id: uid(),
		at: now(),
		...item
	}].slice(-80) }),
	setAgentStatus: (name, status, objective) => set({ agents: get().agents.map((a) => a.name === name ? {
		...a,
		status,
		lastObjective: objective ?? a.lastObjective
	} : a) }),
	resetDemo: () => set(initial())
}), { name: "frieren-command-center" }));
function systemStatus() {
	const s = useFrieren.getState();
	const taskStats = {};
	for (const t of s.tasks) taskStats[t.status] = (taskStats[t.status] ?? 0) + 1;
	return {
		memory: s.memories.length,
		knowledge: {
			nodes: s.nodes.length,
			edges: s.edges.length
		},
		tasks: taskStats,
		agents: s.agents.length,
		auditEvents: s.audit.length,
		voice: s.voiceArmed,
		dryRun: s.dryRun,
		granted: s.granted,
		recovery: s.recovery.length,
		approvals: s.approvals.length
	};
}
var KINDS$2 = [
	"fact",
	"preference",
	"event",
	"task",
	"skill",
	"note"
];
var PRIORITIES$1 = [
	"low",
	"normal",
	"high",
	"urgent"
];
var CAPS$1 = [
	"notification",
	"clipboard",
	"tts",
	"battery",
	"open_url",
	"call",
	"message",
	"volume"
];
function kindFrom(text) {
	return KINDS$2.find((k) => text.toLowerCase().includes(k)) ?? "note";
}
function routeCommand(raw, confirmed = false) {
	const text = raw.trim();
	if (!text) return {
		status: "failed",
		message: "Empty command."
	};
	const low = text.toLowerCase();
	const store = useFrieren.getState();
	if (low === "status" || low === "system status" || low === "frieren status") {
		const s = systemStatus();
		return {
			status: "completed",
			message: [
				"Command center status",
				`Memory ${s.memory}  ·  Graph ${s.knowledge.nodes}/${s.knowledge.edges}`,
				`Tasks ${JSON.stringify(s.tasks)}`,
				`Agents ${s.agents}  ·  Audit ${s.auditEvents}`,
				`Voice ${s.voice ? "armed" : "idle"}  ·  Dry-run ${s.dryRun ? "on" : "off"}`,
				`Granted: ${s.granted.join(", ") || "none"}`
			].join("\n"),
			data: s
		};
	}
	if (low.startsWith("remember ")) {
		const content = text.slice(9).trim();
		if (!content) return {
			status: "failed",
			message: "Nothing to remember."
		};
		const rec = store.remember(content, kindFrom(content));
		return {
			status: "completed",
			message: `Memory saved (${rec.kind}). I will not silently store ordinary chat.`,
			data: { memory_id: rec.id }
		};
	}
	if (low.startsWith("forget ")) {
		const q = text.slice(7).trim();
		const hits = store.recall(q);
		if (!hits.length) return {
			status: "failed",
			message: `No memory matched “${q}”.`
		};
		store.forget(hits[0].id);
		return {
			status: "completed",
			message: `Forgot: ${hits[0].content}`
		};
	}
	if (low.startsWith("recall ") || low.startsWith("memories")) {
		const q = low.startsWith("recall ") ? text.slice(7).trim() : "";
		const hits = q ? store.recall(q) : store.memories.slice(0, 8);
		if (!hits.length) return {
			status: "completed",
			message: "No memories yet."
		};
		return {
			status: "completed",
			message: hits.map((h) => `· ${h.content}`).join("\n")
		};
	}
	if (low.startsWith("create task ")) {
		const rest = text.slice(12).trim();
		const pri = PRIORITIES$1.find((p) => rest.toLowerCase().startsWith(p + " ")) ?? "normal";
		const title = PRIORITIES$1.includes(pri) && rest.toLowerCase().startsWith(pri) ? rest.slice(pri.length).trim() : rest;
		if (!title) return {
			status: "failed",
			message: "Task title cannot be empty."
		};
		const t = store.createTask(title, { priority: pri });
		return {
			status: "completed",
			message: `Task created · ${t.priority} · ${t.title}`,
			data: { task_id: t.id }
		};
	}
	if (low.startsWith("run ready tasks") || low === "run tasks") {
		const ready = store.tasks.filter((t) => t.status === "pending");
		if (!ready.length) return {
			status: "completed",
			message: "No ready tasks."
		};
		if (!confirmed) return {
			status: "needs_confirmation",
			message: `Confirmation required before executing ${ready.length} ready task${ready.length === 1 ? "" : "s"}.`,
			pendingConfirm: {
				kind: "run_tasks",
				payload: ready.map((t) => t.id).join(",")
			}
		};
		const done = store.runReadyTasks();
		return {
			status: "completed",
			message: `Executed ${done.length} task${done.length === 1 ? "" : "s"} after confirmation.`
		};
	}
	if (low.startsWith("link ") || low.startsWith("relate ")) {
		const parts = text.replace(/^(link|relate)\s+/i, "").split(/\s+(?:to|and|->)\s+/i);
		if (parts.length < 2) return {
			status: "failed",
			message: "Use: link A to B"
		};
		const a = store.upsertNode(parts[0]);
		const b = store.upsertNode(parts[1]);
		store.addEdge(a.id, b.id, "related_to");
		return {
			status: "completed",
			message: `Linked ${a.label} → ${b.label}`
		};
	}
	if (low.startsWith("note ") || low.startsWith("graph ")) {
		const label = text.replace(/^(note|graph)\s+/i, "").trim();
		return {
			status: "completed",
			message: `Graph node: ${store.upsertNode(label, "note").label}`
		};
	}
	const capMatch = CAPS$1.find((c) => low.includes(c.replace("_", " ")) || low.includes(c));
	if (capMatch && (low.startsWith("notify") || low.startsWith("toast") || low.startsWith("speak") || low.startsWith("say ") || low.startsWith("clipboard") || low.startsWith("copy ") || low.startsWith("battery") || low.startsWith("open ") || low.startsWith("call ") || low.startsWith("sms ") || low.startsWith("message ") || low.startsWith("volume"))) {
		if (!store.granted.includes(capMatch)) return {
			status: "failed",
			message: `Capability not granted: ${capMatch}. Open System → Tools to grant it.`
		};
		if ((capMatch === "call" || capMatch === "message" || capMatch === "open_url" || capMatch === "volume") && !confirmed) return {
			status: "needs_confirmation",
			message: `Approval required for ${capMatch}.`,
			pendingConfirm: {
				kind: "android",
				payload: text
			}
		};
		return {
			status: "completed",
			message: `${store.dryRun ? "Dry-run" : "Executed"}: ${capMatch} — ${text}. Consequential tools never run silently.`
		};
	}
	return null;
}
function formatPlan(text) {
	return [
		"Accepted for planning. I will not claim this ran.",
		"Plan:",
		"1. Understand the request",
		`2. Select allowlisted tools for: ${text.slice(0, 80)}`,
		"3. Pause on consequential steps for your approval",
		"4. Verify results, then report"
	].join("\n");
}
function useVoice(onHeard) {
	const [listening, setListening] = (0, import_react.useState)(false);
	const recRef = (0, import_react.useRef)(null);
	function toggle() {
		const SR = typeof window !== "undefined" && (window.SpeechRecognition || window.webkitSpeechRecognition);
		if (!SR) {
			onHeard("");
			return;
		}
		if (listening) {
			recRef.current?.stop();
			setListening(false);
			return;
		}
		const rec = new SR();
		rec.lang = "en-US";
		rec.interimResults = false;
		rec.onresult = (e) => {
			onHeard(e.results[0]?.[0]?.transcript ?? "");
		};
		rec.onend = () => setListening(false);
		rec.start();
		recRef.current = rec;
		setListening(true);
	}
	return {
		listening,
		toggle
	};
}
function CommandView() {
	const messages = useFrieren((s) => s.messages);
	const addMessage = useFrieren((s) => s.addMessage);
	const patchMessage = useFrieren((s) => s.patchMessage);
	const logAudit = useFrieren((s) => s.logAudit);
	const runReady = useFrieren((s) => s.runReadyTasks);
	const wakeWord = useFrieren((s) => s.wakeWord);
	const setVoiceArmed = useFrieren((s) => s.setVoiceArmed);
	const addTimeline = useFrieren((s) => s.addTimeline);
	const timeline = useFrieren((s) => s.timeline);
	const recovery = useFrieren((s) => s.recovery);
	const approvals = useFrieren((s) => s.approvals);
	const removeRecovery = useFrieren((s) => s.removeRecovery);
	const removeApproval = useFrieren((s) => s.removeApproval);
	const addApproval = useFrieren((s) => s.addApproval);
	const [draft, setDraft] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const scroller = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		scroller.current?.scrollTo({
			top: scroller.current.scrollHeight,
			behavior: "smooth"
		});
	}, [messages.length]);
	async function submit(text, confirmed = false) {
		const value = text.trim();
		if (!value || busy) return;
		setDraft("");
		addMessage({
			role: "user",
			text: value
		});
		const routed = routeCommand(value, confirmed);
		if (routed) {
			addMessage({
				role: routed.status === "needs_confirmation" ? "approval" : "frieren",
				text: routed.message,
				status: routed.status,
				data: routed.data,
				pendingConfirm: routed.pendingConfirm
			});
			logAudit(routed.message, routed.status);
			if (routed.pendingConfirm?.kind === "android") addApproval({
				tool: routed.pendingConfirm.payload,
				reason: routed.message
			});
			return;
		}
		setBusy(true);
		const thinking = addMessage({
			role: "frieren",
			text: "Thinking…",
			status: "accepted"
		});
		const ctx = JSON.stringify(systemStatus());
		try {
			const res = await askFrieren({ data: {
				prompt: value,
				context: ctx
			} });
			if (res.ok) {
				patchMessage(thinking.id, {
					text: res.text,
					status: "completed"
				});
				logAudit("brain reply", "completed");
			} else {
				patchMessage(thinking.id, {
					text: `${formatPlan(value)}\n\n${res.error}`,
					status: "accepted"
				});
				logAudit("brain unavailable — plan accepted", "accepted");
			}
		} catch {
			patchMessage(thinking.id, {
				text: formatPlan(value),
				status: "accepted"
			});
		} finally {
			setBusy(false);
		}
	}
	const voice = useVoice((said) => {
		if (!said) {
			addMessage({
				role: "system",
				text: "Voice is unavailable in this browser. Type instead, or install the Android package."
			});
			return;
		}
		if (said.toLowerCase().includes(wakeWord)) {
			setVoiceArmed(true);
			submit(said.replace(new RegExp(wakeWord, "ig"), "").replace(/^[,.\s]+/, "") || said);
		} else addMessage({
			role: "system",
			text: `Heard “${said}”. Prefix with the wake word “${wakeWord}” to send.`
		});
	});
	function confirm(kind, payload, id) {
		if (kind === "run_tasks") {
			const done = runReady();
			patchMessage(id, {
				status: "completed",
				pendingConfirm: void 0,
				text: `Executed ${done.length} task${done.length === 1 ? "" : "s"} after confirmation.`,
				role: "frieren"
			});
			logAudit("ready tasks executed", "completed");
		} else {
			patchMessage(id, {
				status: "completed",
				pendingConfirm: void 0,
				text: `Approved: ${payload}. Dry-run still applies unless you disable it in System.`,
				role: "frieren"
			});
			addTimeline({
				label: "Android",
				status: "approved",
				detail: payload
			});
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-0 flex-col",
		children: [
			(recovery.length > 0 || approvals.length > 0) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2 border-b border-border px-4 py-3",
				children: [recovery.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl bg-elevated px-3 py-2.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium",
							children: "Interrupted run"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted",
							children: [
								"Step ",
								r.step,
								" · ",
								r.reason
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								onClick: () => {
									addTimeline({
										label: "Recovery",
										status: "resumed",
										detail: r.id
									});
									removeRecovery(r.id);
								},
								children: "Resume"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "secondary",
								onClick: () => removeRecovery(r.id),
								children: "Discard"
							})]
						})
					]
				}, r.id)), approvals.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-warn/30 bg-elevated px-3 py-2.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "flex items-center gap-2 text-sm font-medium",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "size-4 text-warn" }), "Pending approval"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: a.reason
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								onClick: () => removeApproval(a.id),
								children: "Approve"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "secondary",
								onClick: () => removeApproval(a.id),
								children: "Deny"
							})]
						})
					]
				}, a.id))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				ref: scroller,
				className: "min-h-0 flex-1 space-y-3 overflow-y-auto px-4 py-4",
				children: [messages.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: cn("max-w-[92%] rounded-2xl px-4 py-3 text-sm leading-relaxed", m.role === "user" ? "ml-auto bg-accent text-accent-fg" : m.role === "approval" ? "border border-warn/35 bg-elevated" : m.role === "system" ? "bg-surface text-muted" : "bg-surface"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
							className: "mb-1 flex items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display text-[13px] tracking-wide text-current/80",
								children: m.role === "user" ? "You" : m.role === "approval" ? "Approval" : m.role === "system" ? "System" : "FRIEREN"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("text-[11px] tabular-nums", m.role === "user" ? "text-accent-fg/70" : "text-subtle"),
								children: formatRelative(m.createdAt)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "whitespace-pre-wrap",
							children: m.text
						}),
						m.pendingConfirm && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: m.role === "user" ? "secondary" : "default",
								onClick: () => confirm(m.pendingConfirm.kind, m.pendingConfirm.payload, m.id),
								children: "Approve"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "secondary",
								onClick: () => patchMessage(m.id, {
									pendingConfirm: void 0,
									status: "failed",
									text: "Denied. Nothing was executed."
								}),
								children: "Deny"
							})]
						})
					]
				}, m.id)), timeline.slice(-4).map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "px-1 text-xs text-subtle",
					children: [
						t.label,
						" · ",
						t.status,
						" — ",
						t.detail
					]
				}, t.id))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "border-t border-border bg-bg/80 p-3 backdrop-blur-sm",
				onSubmit: (e) => {
					e.preventDefault();
					submit(draft);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-end gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "sr-only",
							htmlFor: "frieren-input",
							children: "Ask FRIEREN"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							id: "frieren-input",
							rows: 1,
							value: draft,
							onChange: (e) => setDraft(e.target.value),
							onKeyDown: (e) => {
								if (e.key === "Enter" && !e.shiftKey) {
									e.preventDefault();
									submit(draft);
								}
							},
							placeholder: "Ask FRIEREN…",
							className: "max-h-32 min-h-11 flex-1 resize-none rounded-[14px] border border-border bg-elevated px-3.5 py-2.5 text-sm text-fg placeholder:text-subtle focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/40"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							size: "icon",
							variant: voice.listening ? "danger" : "secondary",
							"aria-label": voice.listening ? "Stop listening" : "Voice",
							onClick: () => voice.toggle(),
							children: voice.listening ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							size: "icon",
							disabled: busy || !draft.trim(),
							"aria-label": "Send",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-4" })
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 flex items-center gap-2 px-1 text-[11px] text-subtle",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: "accent",
							children: "Phase 80"
						}),
						"Local kernel · confirmation-gated · wake word ",
						wakeWord
					]
				})]
			})
		]
	});
}
var Input = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
	ref,
	className: cn("h-11 w-full rounded-[12px] border border-border bg-elevated px-3.5 text-sm text-fg placeholder:text-subtle", "transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/40", className),
	...props
}));
Input.displayName = "Input";
var Textarea = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
	ref,
	className: cn("min-h-24 w-full rounded-[12px] border border-border bg-elevated px-3.5 py-2.5 text-sm text-fg placeholder:text-subtle", "transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/40", className),
	...props
}));
Textarea.displayName = "Textarea";
var KINDS$1 = [
	"concept",
	"person",
	"place",
	"project",
	"event",
	"note"
];
function GraphView() {
	const nodes = useFrieren((s) => s.nodes);
	const edges = useFrieren((s) => s.edges);
	const upsertNode = useFrieren((s) => s.upsertNode);
	const addEdge = useFrieren((s) => s.addEdge);
	const deleteNode = useFrieren((s) => s.deleteNode);
	const [label, setLabel] = (0, import_react.useState)("");
	const [kind, setKind] = (0, import_react.useState)("concept");
	const [from, setFrom] = (0, import_react.useState)(nodes[0]?.id ?? "");
	const [to, setTo] = (0, import_react.useState)(nodes[1]?.id ?? "");
	const layout = (0, import_react.useMemo)(() => {
		const n = nodes.length || 1;
		return nodes.map((node, i) => {
			const angle = i / n * Math.PI * 2 - Math.PI / 2;
			const r = 38;
			return {
				...node,
				x: 50 + Math.cos(angle) * r,
				y: 50 + Math.sin(angle) * r
			};
		});
	}, [nodes]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-0 flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative mx-4 mt-4 h-56 overflow-hidden rounded-2xl bg-surface",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
					viewBox: "0 0 100 100",
					className: "size-full",
					children: [edges.map((e) => {
						const a = layout.find((n) => n.id === e.sourceId);
						const b = layout.find((n) => n.id === e.targetId);
						if (!a || !b) return null;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
							x1: a.x,
							y1: a.y,
							x2: b.x,
							y2: b.y,
							stroke: "currentColor",
							className: "text-border-strong",
							strokeWidth: "0.6"
						}, e.id);
					}), layout.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: n.x,
						cy: n.y,
						r: "5.2",
						className: "fill-accent/25 stroke-accent",
						strokeWidth: "0.6"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
						x: n.x,
						y: n.y + 9,
						textAnchor: "middle",
						className: "fill-muted",
						fontSize: "3.4",
						children: n.label.slice(0, 16)
					})] }, n.id))]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "space-y-2 px-4 py-3",
				onSubmit: (e) => {
					e.preventDefault();
					if (!label.trim()) return;
					upsertNode(label, kind);
					setLabel("");
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: label,
					onChange: (e) => setLabel(e.target.value),
					placeholder: "Add a node…"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-1.5",
					children: [KINDS$1.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setKind(k),
						className: kind === k ? "rounded-full bg-accent px-3 py-1 text-xs font-medium text-accent-fg" : "rounded-full bg-elevated px-3 py-1 text-xs text-muted",
						children: k
					}, k)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						size: "sm",
						className: "ml-auto",
						children: "Add"
					})]
				})]
			}),
			nodes.length >= 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 px-4 pb-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: "h-11 flex-1 rounded-[12px] border border-border bg-elevated px-2 text-sm",
						value: from,
						onChange: (e) => setFrom(e.target.value),
						children: nodes.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: n.id,
							children: n.label
						}, n.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-subtle",
						children: "to"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: "h-11 flex-1 rounded-[12px] border border-border bg-elevated px-2 text-sm",
						value: to,
						onChange: (e) => setTo(e.target.value),
						children: nodes.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: n.id,
							children: n.label
						}, n.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "secondary",
						onClick: () => addEdge(from, to, "related_to"),
						children: "Link"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "min-h-0 flex-1 space-y-2 overflow-y-auto px-4 pb-4",
				children: nodes.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-start justify-between gap-3 rounded-2xl bg-surface px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium",
							children: n.label
						}),
						n.description && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: n.description
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							className: "mt-2",
							children: n.kind
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "ghost",
						onClick: () => deleteNode(n.id),
						children: "Remove"
					})]
				}, n.id))
			})
		]
	});
}
var KINDS = [
	"note",
	"fact",
	"preference",
	"event",
	"skill",
	"task"
];
function MemoryView() {
	const memories = useFrieren((s) => s.memories);
	const remember = useFrieren((s) => s.remember);
	const forget = useFrieren((s) => s.forget);
	const [q, setQ] = (0, import_react.useState)("");
	const [draft, setDraft] = (0, import_react.useState)("");
	const [kind, setKind] = (0, import_react.useState)("note");
	const shown = q ? memories.filter((m) => m.content.toLowerCase().includes(q.toLowerCase()) || m.tags.some((t) => t.includes(q.toLowerCase()))) : memories;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-0 flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3 border-b border-border px-4 py-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex flex-col gap-2",
				onSubmit: (e) => {
					e.preventDefault();
					if (!draft.trim()) return;
					remember(draft, kind);
					setDraft("");
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: draft,
					onChange: (e) => setDraft(e.target.value),
					placeholder: "Remember something explicitly…"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-1.5",
					children: [KINDS.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setKind(k),
						className: kind === k ? "rounded-full bg-accent px-3 py-1 text-xs font-medium text-accent-fg" : "rounded-full bg-elevated px-3 py-1 text-xs text-muted",
						children: k
					}, k)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						size: "sm",
						className: "ml-auto",
						children: "Remember"
					})]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-3 left-3 size-4 text-subtle" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "pl-9",
					value: q,
					onChange: (e) => setQ(e.target.value),
					placeholder: "Recall…"
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
			className: "min-h-0 flex-1 space-y-2 overflow-y-auto px-4 py-3",
			children: [shown.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: "rounded-2xl bg-surface px-4 py-8 text-center text-sm text-muted",
				children: "Memory is explicit. Nothing is stored from ordinary chat."
			}), shown.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "rounded-2xl bg-surface px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm leading-relaxed",
						children: m.content
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Forget",
						className: "mt-0.5 text-subtle hover:text-danger",
						onClick: () => forget(m.id),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: m.kind }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[11px] tabular-nums text-subtle",
						children: formatRelative(m.createdAt)
					})]
				})]
			}, m.id))]
		})]
	});
}
function Switch({ checked, onCheckedChange, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		role: "switch",
		"aria-checked": checked,
		"aria-label": label,
		onClick: () => onCheckedChange(!checked),
		className: cn("relative h-7 w-12 shrink-0 rounded-full border transition-colors", checked ? "border-accent bg-accent" : "border-border bg-elevated"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("absolute top-0.5 size-5 rounded-full bg-fg shadow-sm transition-transform", checked ? "left-6" : "left-0.5") })
	});
}
var CAPS = [
	{
		id: "notification",
		label: "Notifications",
		risk: "low"
	},
	{
		id: "clipboard",
		label: "Clipboard",
		risk: "low"
	},
	{
		id: "tts",
		label: "Speech",
		risk: "low"
	},
	{
		id: "battery",
		label: "Battery",
		risk: "low"
	},
	{
		id: "open_url",
		label: "Open URL",
		risk: "high"
	},
	{
		id: "call",
		label: "Calls",
		risk: "high"
	},
	{
		id: "message",
		label: "Messages",
		risk: "high"
	},
	{
		id: "volume",
		label: "Volume",
		risk: "high"
	}
];
function SystemView() {
	const granted = useFrieren((s) => s.granted);
	const grant = useFrieren((s) => s.grant);
	const revoke = useFrieren((s) => s.revoke);
	const dryRun = useFrieren((s) => s.dryRun);
	const setDryRun = useFrieren((s) => s.setDryRun);
	const agents = useFrieren((s) => s.agents);
	const audit = useFrieren((s) => s.audit);
	const addRecovery = useFrieren((s) => s.addRecovery);
	const resetDemo = useFrieren((s) => s.resetDemo);
	const stats = systemStatus();
	async function probeBattery() {
		try {
			const nav = navigator;
			if (!nav.getBattery) {
				useFrieren.getState().addMessage({
					role: "system",
					text: "Battery API is not available here. The Android package can read it via the allowlisted tool."
				});
				return;
			}
			const b = await nav.getBattery();
			useFrieren.getState().addMessage({
				role: "frieren",
				text: `Battery ${(b.level * 100).toFixed(0)}%.`,
				status: "completed"
			});
		} catch {
			useFrieren.getState().addMessage({
				role: "system",
				text: "Battery probe failed."
			});
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-0 flex-1 space-y-4 overflow-y-auto px-4 py-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-lg",
						children: "Install Android package"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Signed debug APK of the FRIEREN command center. Sideload it, then enable unknown sources if asked."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, { className: "size-5 text-accent" })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "/frieren.apk",
					download: "FRIEREN.apk",
					className: "mt-4 inline-flex",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), "Download APK"]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-lg",
						children: "Kernel"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-3 grid grid-cols-2 gap-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-subtle",
								children: "Memory"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "tabular-nums font-medium",
								children: stats.memory
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-subtle",
								children: "Graph"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
								className: "tabular-nums font-medium",
								children: [
									stats.knowledge.nodes,
									"/",
									stats.knowledge.edges
								]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-subtle",
								children: "Agents"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "tabular-nums font-medium",
								children: stats.agents
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-subtle",
								children: "Audit"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "tabular-nums font-medium",
								children: stats.auditEvents
							})] })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium",
							children: "Dry-run tools"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: "Device actions are simulated until you turn this off."
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: dryRun,
							onCheckedChange: setDryRun,
							label: "Dry-run"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-lg",
						children: "Tools / permissions"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 space-y-2",
						children: CAPS.map((c) => {
							const on = granted.includes(c.id);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center justify-between gap-3 rounded-xl bg-elevated px-3 py-2.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm",
									children: c.label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
									tone: c.risk === "high" ? "warn" : "muted",
									children: [c.risk, " risk"]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
									checked: on,
									onCheckedChange: (v) => v ? grant(c.id) : revoke(c.id),
									label: c.label
								})]
							}, c.id);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-3 w-full",
						variant: "secondary",
						onClick: () => void probeBattery(),
						children: "Probe battery"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-lg",
					children: "Agents"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 space-y-2",
					children: agents.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between rounded-xl bg-elevated px-3 py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm",
							children: a.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: a.status === "idle" ? "muted" : "accent",
							children: a.status
						})]
					}, a.name))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-lg",
							children: "Audit"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "ghost",
							onClick: () => addRecovery({
								step: 2,
								reason: "Simulated interrupted execution for recovery practice."
							}),
							children: "Simulate recovery"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-3 space-y-2",
						children: [audit.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "text-sm text-muted",
							children: "No commands recorded yet."
						}), [...audit].reverse().slice(0, 12).map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-start justify-between gap-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: e.message }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "shrink-0 text-[11px] tabular-nums text-subtle",
								children: formatRelative(e.at)
							})]
						}, e.id))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-4 w-full",
						variant: "secondary",
						onClick: resetDemo,
						children: "Reset local kernel"
					})
				]
			})
		]
	});
}
var PRIORITIES = [
	"urgent",
	"high",
	"normal",
	"low"
];
function toneFor(status) {
	if (status === "completed") return "ok";
	if (status === "failed") return "danger";
	if (status === "running") return "accent";
	if (status === "blocked") return "warn";
	return "muted";
}
function TasksView() {
	const tasks = useFrieren((s) => s.tasks);
	const createTask = useFrieren((s) => s.createTask);
	const setTaskStatus = useFrieren((s) => s.setTaskStatus);
	const runReadyTasks = useFrieren((s) => s.runReadyTasks);
	const addMessage = useFrieren((s) => s.addMessage);
	const [title, setTitle] = (0, import_react.useState)("");
	const [priority, setPriority] = (0, import_react.useState)("normal");
	const [confirmRun, setConfirmRun] = (0, import_react.useState)(false);
	const ready = tasks.filter((t) => t.status === "pending");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-0 flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3 border-b border-border px-4 py-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "flex flex-col gap-2",
					onSubmit: (e) => {
						e.preventDefault();
						if (!title.trim()) return;
						createTask(title, { priority });
						setTitle("");
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: title,
						onChange: (e) => setTitle(e.target.value),
						placeholder: "Create a task…"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-1.5",
						children: [PRIORITIES.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setPriority(p),
							className: priority === p ? "rounded-full bg-accent px-3 py-1 text-xs font-medium text-accent-fg" : "rounded-full bg-elevated px-3 py-1 text-xs text-muted",
							children: p
						}, p)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							size: "sm",
							className: "ml-auto",
							children: "Create"
						})]
					})]
				}),
				ready.length > 0 && !confirmRun && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "secondary",
					className: "w-full",
					onClick: () => setConfirmRun(true),
					children: [
						"Run ",
						ready.length,
						" ready task",
						ready.length === 1 ? "" : "s"
					]
				}),
				confirmRun && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-warn/30 bg-elevated p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm",
						children: "Confirmation required before executing ready tasks."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							onClick: () => {
								const done = runReadyTasks();
								setConfirmRun(false);
								addMessage({
									role: "frieren",
									text: `Executed ${done.length} task${done.length === 1 ? "" : "s"} after confirmation.`,
									status: "completed"
								});
							},
							children: "Confirm run"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "secondary",
							onClick: () => setConfirmRun(false),
							children: "Cancel"
						})]
					})]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
			className: "min-h-0 flex-1 space-y-2 overflow-y-auto px-4 py-3",
			children: [tasks.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: "rounded-2xl bg-surface px-4 py-8 text-center text-sm text-muted",
				children: "No tasks yet. Ready tasks never run without confirmation."
			}), tasks.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "rounded-2xl bg-surface px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: t.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] tabular-nums text-subtle",
						children: formatRelative(t.updatedAt)
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: toneFor(t.status),
						children: t.status
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap gap-1.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: t.priority }),
						t.status === "pending" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "ghost",
							onClick: () => setTaskStatus(t.id, "cancelled"),
							children: "Cancel"
						}),
						t.status === "failed" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "ghost",
							onClick: () => setTaskStatus(t.id, "pending"),
							children: "Retry"
						})
					]
				})]
			}, t.id))]
		})]
	});
}
var TABS = [
	{
		id: "command",
		label: "Command",
		icon: Command
	},
	{
		id: "memory",
		label: "Memory",
		icon: ScrollText
	},
	{
		id: "tasks",
		label: "Tasks",
		icon: Bot
	},
	{
		id: "graph",
		label: "Graph",
		icon: Network
	},
	{
		id: "system",
		label: "System",
		icon: Settings2
	}
];
function FrierenShell() {
	const [tab, setTab] = (0, import_react.useState)("command");
	const dryRun = useFrieren((s) => s.dryRun);
	const recovery = useFrieren((s) => s.recovery);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-dvh justify-center bg-bg text-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex w-full max-w-lg flex-col border-border md:my-6 md:min-h-[min(860px,calc(100dvh-3rem))] md:rounded-[28px] md:border md:shadow-[var(--shadow-panel)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "flex items-center justify-between gap-3 border-b border-border px-5 pt-[max(1rem,env(safe-area-inset-top))] pb-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] tracking-[0.22em] text-subtle uppercase",
						children: "Local kernel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-[28px] leading-none tracking-tight",
						children: "FRIEREN"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-right",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: "Phase 80"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "flex items-center justify-end gap-1.5 text-[11px] text-subtle",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("inline-block size-1.5 rounded-full", recovery.length ? "bg-warn" : "bg-ok") }), dryRun ? "dry-run" : "live tools"]
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
					className: "flex min-h-0 flex-1 flex-col",
					children: [
						tab === "command" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandView, {}),
						tab === "memory" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MemoryView, {}),
						tab === "tasks" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TasksView, {}),
						tab === "graph" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraphView, {}),
						tab === "system" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SystemView, {})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "grid grid-cols-5 border-t border-border pb-[max(0.5rem,env(safe-area-inset-bottom))]",
					children: TABS.map((t) => {
						const Icon = t.icon;
						const active = tab === t.id;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setTab(t.id),
							className: cn("flex min-h-14 flex-col items-center justify-center gap-1 text-[11px]", active ? "text-accent" : "text-subtle"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: "size-4",
								strokeWidth: active ? 2.2 : 1.7
							}), t.label]
						}, t.id);
					})
				})
			]
		})
	});
}
function Home() {
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setReady(true), []);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-dvh items-end bg-bg px-6 pb-24 text-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] tracking-[0.22em] text-subtle uppercase",
				children: "Local kernel"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl tracking-tight",
				children: "FRIEREN"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "Waking the command center…"
			})
		] })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FrierenShell, {});
}
//#endregion
export { Home as component };
