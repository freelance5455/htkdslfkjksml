import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/explain.functions-BPf_0m61.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var cache = /* @__PURE__ */ new Map();
var explainWord_createServerFn_handler = createServerRpc({
	id: "b1c8f4c3d6ff3a3ac5c919917ccd322b44d77ceb087509d9f6747f11b9ba9c33",
	name: "explainWord",
	filename: "src/lib/explain.functions.ts"
}, (opts) => explainWord.__executeServer(opts));
var explainWord = createServerFn({ method: "POST" }).validator((input) => {
	const word = (input?.word ?? "").trim().slice(0, 80);
	if (!word) throw new Error("الكلمة فاضية");
	return {
		word,
		question: (input?.question ?? "").trim().slice(0, 320),
		context: (input?.context ?? "").trim().slice(0, 500)
	};
}).handler(explainWord_createServerFn_handler, async ({ data }) => {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "الشرح الذكي مش متاح دلوقتي. القاموس الثابت لسه شغال."
	};
	const key = `${data.word.toLowerCase()}|${data.question}|${data.context}`;
	const hit = cache.get(key);
	if (hit) return {
		ok: true,
		text: hit
	};
	const prompt = [
		"أنت مدرّس نظرية الرخصة الإيطالية (patente B) لطالب عربي.",
		"اشرح الكلمة أو العبارة الإيطالية بلغة عربية فصيحة سهلة.",
		"لو فيه سؤال، جاوبه مباشرة.",
		"التزم بقواعد Codice della Strada كما تُدرَّس لامتحان 2026: 30 سؤال صح/خطأ، 20 دقيقة، أقصى 3 أخطاء.",
		"لا تخترع أرقام مواد قانونية إن لم تكن متأكدًا. 120 كلمة كحد أقصى.",
		`الكلمة: ${data.word}`,
		data.context ? `الجملة: ${data.context}` : "",
		data.question ? `سؤال الطالب: ${data.question}` : "لا يوجد سؤال إضافي. أعطِ المعنى وأهم استعمال في سياق القيادة."
	].filter(Boolean).join("\n");
	try {
		const res = await fetch("https://api.x.ai/v1/chat/completions", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${apiKey}`
			},
			body: JSON.stringify({
				model: "grok-4.5",
				temperature: .2,
				max_tokens: 420,
				messages: [{
					role: "user",
					content: prompt
				}]
			})
		});
		if (!res.ok) return {
			ok: false,
			error: "تعذّر الشرح الآن. جرّب بعد لحظة."
		};
		const text = (await res.json()).choices?.[0]?.message?.content?.trim() ?? "";
		if (!text) return {
			ok: false,
			error: "ما وصلنيش شرح. جرّب صياغة ثانية."
		};
		if (cache.size > 200) cache.clear();
		cache.set(key, text);
		return {
			ok: true,
			text
		};
	} catch {
		return {
			ok: false,
			error: "انقطع الاتصال أثناء الشرح."
		};
	}
});
//#endregion
export { explainWord_createServerFn_handler };
