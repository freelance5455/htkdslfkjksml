//#region node_modules/.nitro/vite/services/ssr/assets/types-djekE3oG.js
var SKILL_IDS = [
	"chairman",
	"prayer",
	"treasures",
	"gems",
	"reading",
	"initial",
	"return",
	"study",
	"talk",
	"assistant",
	"living",
	"cbs",
	"reader"
];
//#endregion
export { SKILL_IDS as t };
