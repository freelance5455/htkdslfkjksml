import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/use-projects-B0rAf6PZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var DB_NAME = "storyboard-ai";
var STORE = "projects";
function openDb() {
	return new Promise((resolve, reject) => {
		const req = indexedDB.open(DB_NAME, 1);
		req.onupgradeneeded = () => {
			const db = req.result;
			if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE, { keyPath: "id" });
		};
		req.onsuccess = () => resolve(req.result);
		req.onerror = () => reject(req.error);
	});
}
async function idbAll() {
	const db = await openDb();
	return new Promise((resolve, reject) => {
		const req = db.transaction(STORE, "readonly").objectStore(STORE).getAll();
		req.onsuccess = () => resolve(req.result ?? []);
		req.onerror = () => reject(req.error);
	});
}
async function idbPut(project) {
	const db = await openDb();
	return new Promise((resolve, reject) => {
		const tx = db.transaction(STORE, "readwrite");
		tx.objectStore(STORE).put(project);
		tx.oncomplete = () => resolve();
		tx.onerror = () => reject(tx.error);
	});
}
async function idbDelete(id) {
	const db = await openDb();
	return new Promise((resolve, reject) => {
		const tx = db.transaction(STORE, "readwrite");
		tx.objectStore(STORE).delete(id);
		tx.oncomplete = () => resolve();
		tx.onerror = () => reject(tx.error);
	});
}
var KEY = "storyboard-ai-prefs";
var DEFAULT_PREFS = {
	sceneCount: 6,
	style: "Natural Smartphone",
	aspect: "9:16",
	consistencyLock: true
};
function readPrefs() {
	if (typeof localStorage === "undefined") return DEFAULT_PREFS;
	try {
		const raw = localStorage.getItem(KEY);
		if (!raw) return DEFAULT_PREFS;
		const parsed = JSON.parse(raw);
		const aspect = parsed.aspect === "1:1" || parsed.aspect === "4:5" || parsed.aspect === "16:9" || parsed.aspect === "9:16" ? parsed.aspect : "9:16";
		return {
			sceneCount: typeof parsed.sceneCount === "number" && parsed.sceneCount >= 3 && parsed.sceneCount <= 10 ? parsed.sceneCount : 6,
			style: typeof parsed.style === "string" && parsed.style ? parsed.style : DEFAULT_PREFS.style,
			aspect,
			consistencyLock: parsed.consistencyLock !== false
		};
	} catch {
		return DEFAULT_PREFS;
	}
}
function writePrefs(prefs) {
	localStorage.setItem(KEY, JSON.stringify(prefs));
}
var saveTimer = 0;
function scheduleSave(project) {
	window.clearTimeout(saveTimer);
	saveTimer = window.setTimeout(() => {
		idbPut(project);
	}, 350);
}
function emptyProject() {
	const prefs = readPrefs();
	const now = Date.now();
	return {
		id: crypto.randomUUID(),
		name: "Storyboard baru",
		createdAt: now,
		updatedAt: now,
		refs: [],
		category: "Hardbox",
		customCategory: "",
		campaign: "New Product",
		customCampaign: "",
		story: "",
		sceneCount: prefs.sceneCount,
		style: prefs.style,
		customStyle: "",
		aspect: prefs.aspect,
		consistencyLock: prefs.consistencyLock,
		profile: "",
		productName: "",
		scenes: [],
		phase: "draft",
		statusNote: "",
		planError: null
	};
}
function isPrunable(project) {
	return project.refs.length === 0 && project.scenes.length === 0 && !project.story.trim() && !project.customCategory.trim() && !project.customCampaign.trim() && project.name === "Storyboard baru";
}
var loading = null;
var useStory = create((set, get) => ({
	ready: false,
	projects: [],
	async load() {
		if (get().ready) return;
		if (loading) return loading;
		loading = (async () => {
			try {
				const projects = await idbAll();
				projects.sort((a, b) => b.updatedAt - a.updatedAt);
				if (!get().ready) set({
					projects,
					ready: true
				});
			} catch {
				if (!get().ready) set({
					projects: [],
					ready: true
				});
			} finally {
				loading = null;
			}
		})();
		return loading;
	},
	createBlank() {
		const project = emptyProject();
		set({ projects: [project, ...get().projects.filter((item) => item.id !== project.id)] });
		idbPut(project);
		return project;
	},
	patch(id, recipe, flush = false) {
		const current = get().projects.find((item) => item.id === id);
		if (!current) return;
		const next = recipe(current);
		next.updatedAt = Date.now();
		set({ projects: get().projects.map((item) => item.id === id ? next : item) });
		if (flush) {
			window.clearTimeout(saveTimer);
			idbPut(next);
		} else scheduleSave(next);
	},
	remove(id) {
		set({ projects: get().projects.filter((item) => item.id !== id) });
		idbDelete(id);
	},
	pruneEmpty() {
		const cutoff = Date.now() - 6e4;
		const drop = get().projects.filter((project) => isPrunable(project) && project.updatedAt < cutoff);
		if (!drop.length) return;
		const dropIds = new Set(drop.map((project) => project.id));
		set({ projects: get().projects.filter((project) => !dropIds.has(project.id)) });
		for (const project of drop) idbDelete(project.id);
	},
	clearAll() {
		const ids = get().projects.map((item) => item.id);
		set({ projects: [] });
		for (const id of ids) idbDelete(id);
	}
}));
function visibleProjects(projects) {
	return projects.filter((project) => project.refs.length > 0 || project.scenes.length > 0 || project.story.trim());
}
function mapScene(project, sceneId, recipe) {
	return {
		...project,
		scenes: project.scenes.map((scene) => scene.id === sceneId ? recipe(scene) : scene)
	};
}
function useProjects() {
	const ready = useStory((state) => state.ready);
	const load = useStory((state) => state.load);
	(0, import_react.useEffect)(() => {
		load();
	}, [load]);
	return ready;
}
//#endregion
export { useProjects as a, writePrefs as c, readPrefs as i, idbPut as n, useStory as o, mapScene as r, visibleProjects as s, DEFAULT_PREFS as t };
