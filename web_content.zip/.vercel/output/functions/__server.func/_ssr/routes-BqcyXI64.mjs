import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as ChevronDown, D as BatteryMedium, E as Bell, S as Clock, T as CalendarClock, _ as Mail, b as Download, c as SkipForward, d as Play, f as Pause, g as MapPin, h as MessageCircle, i as Vibrate, l as Signal, m as Moon, n as Wifi, o as Smartphone, p as Music, r as VolumeX, s as SlidersHorizontal, t as X, u as RotateCw, v as Layers, w as Calendar, x as CloudSun, y as Flashlight } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BqcyXI64.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var IMPORTANCE_ORDER = [
	"min",
	"low",
	"default",
	"high",
	"max"
];
var IMPORTANCE_LABEL = {
	min: "Senyap",
	low: "Rendah",
	default: "Biasa",
	high: "Tinggi",
	max: "Mendesak"
};
var IMPORTANCE_HELP = {
	min: "Tanpa suara. Masuk bagian Diam dan tidak tampil di layar kunci.",
	low: "Tanpa suara. Hanya ikon di bilah status.",
	default: "Berbunyi sekali dan masuk panel notifikasi.",
	high: "Heads-up mengambang di atas layar.",
	max: "Layar penuh. Menembus jangan ganggu jika saluran mengizinkan."
};
var PRIVACY_LABEL = {
	public: "Tampilkan isi",
	private: "Sembunyikan isi",
	secret: "Rahasia"
};
var STYLE_LABEL = {
	standard: "Standar",
	bigtext: "Teks panjang",
	inbox: "Kotak masuk",
	chat: "Obrolan",
	progress: "Progres",
	media: "Media"
};
var REPEAT_LABEL = {
	once: "Sekali",
	daily: "Setiap hari",
	weekdays: "Hari kerja",
	weekly: "Mingguan"
};
var DND_LABEL = {
	off: "Mati",
	priority: "Prioritas",
	alarms: "Alarm",
	total: "Total"
};
var ICONS = [
	"message",
	"mail",
	"calendar",
	"clock",
	"cloud",
	"music",
	"download",
	"map",
	"bell"
];
var SEED_CHANNELS = [
	{
		id: "umum",
		name: "Umum",
		description: "Notifikasi biasa yang tidak masuk kelompok lain.",
		importance: "default",
		sound: true,
		vibrate: true,
		showBadge: true,
		privacy: "private",
		bypassDnd: false,
		system: true
	},
	{
		id: "obrolan",
		name: "Obrolan",
		description: "Pesan langsung. Muncul mengambang.",
		importance: "high",
		sound: true,
		vibrate: true,
		showBadge: true,
		privacy: "private",
		bypassDnd: false
	},
	{
		id: "pengingat",
		name: "Pengingat",
		description: "Jadwal dan kebiasaan.",
		importance: "default",
		sound: true,
		vibrate: true,
		showBadge: true,
		privacy: "public",
		bypassDnd: false
	},
	{
		id: "media",
		name: "Media",
		description: "Pemutaran yang berjalan terus, tanpa suara notifikasi.",
		importance: "low",
		sound: false,
		vibrate: false,
		showBadge: false,
		privacy: "public",
		bypassDnd: false
	},
	{
		id: "sistem",
		name: "Sistem",
		description: "Status latar. Masuk bagian Diam.",
		importance: "min",
		sound: false,
		vibrate: false,
		showBadge: false,
		privacy: "secret",
		bypassDnd: false,
		system: true
	},
	{
		id: "alarm",
		name: "Alarm",
		description: "Mendesak. Menembus jangan ganggu.",
		importance: "max",
		sound: true,
		vibrate: true,
		showBadge: true,
		privacy: "public",
		bypassDnd: true,
		system: true
	}
];
var DEFAULT_SETTINGS = {
	dnd: "off",
	dndStart: "22:00",
	dndEnd: "07:00",
	dndScheduleOn: false,
	mute: false,
	vibrateDevice: true,
	browserNotify: false,
	battery: 76
};
function uid() {
	return crypto.randomUUID();
}
function blankDraft() {
	return {
		appName: "Lonceng",
		icon: "bell",
		channelId: "pengingat",
		title: "",
		body: "",
		style: "standard",
		bigText: "",
		inboxText: "",
		chat: [],
		progress: 40,
		actions: [{
			id: "a1",
			label: ""
		}, {
			id: "a2",
			label: ""
		}],
		override: false,
		importance: "default",
		ongoing: false,
		headsUp: false,
		sound: true,
		vibrate: true,
		privacy: "private",
		repeat: "once"
	};
}
var TEMPLATES = [
	{
		id: "blank",
		name: "Kosong",
		draft: blankDraft()
	},
	{
		id: "chat",
		name: "Pesan",
		draft: {
			...blankDraft(),
			appName: "Pesan",
			icon: "message",
			channelId: "obrolan",
			title: "Raka",
			body: "Sampai di lobi, atau aku naik saja?",
			style: "chat",
			chat: [{
				id: "c1",
				author: "Raka",
				text: "Sudah di parkir."
			}, {
				id: "c2",
				author: "Raka",
				text: "Sampai di lobi, atau aku naik saja?"
			}],
			actions: [{
				id: "a1",
				label: "Balas"
			}, {
				id: "a2",
				label: "Tandai dibaca"
			}]
		}
	},
	{
		id: "meet",
		name: "Rapat",
		draft: {
			...blankDraft(),
			appName: "Kalender",
			icon: "calendar",
			channelId: "pengingat",
			title: "Tinjauan desain",
			body: "Mulai 15 menit lagi · Ruang Melati",
			style: "standard",
			actions: [{
				id: "a1",
				label: "Tunda"
			}, {
				id: "a2",
				label: "Gabung"
			}]
		}
	},
	{
		id: "water",
		name: "Pengingat",
		draft: {
			...blankDraft(),
			appName: "Jam",
			icon: "clock",
			channelId: "pengingat",
			title: "Minum air",
			body: "Sudah dua jam sejak gelas terakhir.",
			style: "bigtext",
			bigText: "Sudah dua jam sejak gelas terakhir. Isi ulang sebelum rapat berikutnya.",
			actions: [{
				id: "a1",
				label: "Sudah"
			}]
		}
	},
	{
		id: "file",
		name: "Unduhan",
		draft: {
			...blankDraft(),
			appName: "Berkas",
			icon: "download",
			channelId: "media",
			title: "Laporan-Q3.pdf",
			body: "64% · 18 MB dari 28 MB",
			style: "progress",
			progress: 64,
			ongoing: true,
			actions: [{
				id: "a1",
				label: "Jeda"
			}, {
				id: "a2",
				label: "Batal"
			}]
		}
	},
	{
		id: "song",
		name: "Musik",
		draft: {
			...blankDraft(),
			appName: "Lagu",
			icon: "music",
			channelId: "media",
			title: "Hujan di Juni",
			body: "Stereo Malam",
			style: "media",
			ongoing: true,
			actions: []
		}
	},
	{
		id: "alarm",
		name: "Alarm",
		draft: {
			...blankDraft(),
			appName: "Jam",
			icon: "clock",
			channelId: "alarm",
			title: "Bangun",
			body: "06.30 · Hari kerja",
			style: "standard",
			ongoing: true,
			actions: [{
				id: "a1",
				label: "Tunda"
			}]
		}
	}
];
var SEED_SHADE = [
	{
		id: "seed-pesan",
		appName: "Pesan",
		icon: "message",
		channelId: "obrolan",
		title: "Raka",
		body: "Sampai di lobi, atau aku naik saja?",
		style: "chat",
		bigText: "",
		inbox: [],
		chat: [{
			id: "s1",
			author: "Raka",
			text: "Sudah di parkir."
		}, {
			id: "s2",
			author: "Raka",
			text: "Sampai di lobi, atau aku naik saja?"
		}],
		progress: 0,
		actions: [{
			id: "sa1",
			label: "Balas"
		}, {
			id: "sa2",
			label: "Tandai dibaca"
		}],
		importance: "high",
		ongoing: false,
		headsUp: true,
		sound: true,
		vibrate: true,
		privacy: "private",
		shownAt: 0,
		expanded: false,
		playing: false
	},
	{
		id: "seed-kalender",
		appName: "Kalender",
		icon: "calendar",
		channelId: "pengingat",
		title: "Tinjauan desain",
		body: "10.00 · Ruang Melati · 4 orang",
		style: "standard",
		bigText: "",
		inbox: [],
		chat: [],
		progress: 0,
		actions: [{
			id: "ka1",
			label: "Tunda"
		}, {
			id: "ka2",
			label: "Gabung"
		}],
		importance: "default",
		ongoing: false,
		headsUp: false,
		sound: true,
		vibrate: true,
		privacy: "public",
		shownAt: 0,
		expanded: false,
		playing: false
	},
	{
		id: "seed-berkas",
		appName: "Berkas",
		icon: "download",
		channelId: "media",
		title: "Laporan-Q3.pdf",
		body: "64% · 18 MB dari 28 MB",
		style: "progress",
		bigText: "",
		inbox: [],
		chat: [],
		progress: 64,
		actions: [{
			id: "ba1",
			label: "Jeda"
		}, {
			id: "ba2",
			label: "Batal"
		}],
		importance: "low",
		ongoing: true,
		headsUp: false,
		sound: false,
		vibrate: false,
		privacy: "public",
		shownAt: 0,
		expanded: false,
		playing: false
	}
];
function channelById(channels, id) {
	return channels.find((channel) => channel.id === id) ?? channels[0] ?? SEED_CHANNELS[0];
}
function materialize(draft, channel) {
	const importance = draft.override ? draft.importance : channel.importance;
	const sound = draft.override ? draft.sound : channel.sound;
	const vibrate = draft.override ? draft.vibrate : channel.vibrate;
	const privacy = draft.override ? draft.privacy : channel.privacy;
	const headsUp = importance === "max" || (draft.override ? draft.headsUp : importance === "high");
	const inbox = draft.inboxText.split("\n").map((line) => line.trim()).filter(Boolean).slice(0, 6);
	return {
		appName: draft.appName.trim() || "Aplikasi",
		icon: draft.icon,
		channelId: channel.id,
		title: draft.title.trim(),
		body: draft.body.trim(),
		style: draft.style,
		bigText: (draft.bigText || draft.body).trim(),
		inbox,
		chat: draft.chat.filter((line) => line.text.trim()),
		progress: Math.min(100, Math.max(0, draft.progress)),
		actions: draft.actions.map((action) => ({
			id: action.id,
			label: action.label.trim()
		})).filter((action) => action.label).slice(0, 3),
		importance,
		ongoing: draft.ongoing || draft.style === "media",
		headsUp,
		sound,
		vibrate,
		privacy
	};
}
function shadeFromPayload(payload, now, scheduleId) {
	return {
		...payload,
		id: uid(),
		scheduleId,
		shownAt: now,
		expanded: false,
		playing: payload.style === "media"
	};
}
function draftFromSchedule(schedule) {
	return {
		appName: schedule.appName,
		icon: schedule.icon,
		channelId: schedule.channelId,
		title: schedule.title,
		body: schedule.body,
		style: schedule.style,
		bigText: schedule.bigText,
		inboxText: schedule.inbox.join("\n"),
		chat: schedule.chat.map((line) => ({ ...line })),
		progress: schedule.progress,
		actions: schedule.actions.map((action) => ({ ...action })),
		override: schedule.override,
		importance: schedule.importance,
		ongoing: schedule.ongoing,
		headsUp: schedule.headsUp,
		sound: schedule.sound,
		vibrate: schedule.vibrate,
		privacy: schedule.privacy,
		repeat: schedule.repeat
	};
}
function minutesOf(hhmm) {
	const [h, m] = hhmm.split(":").map((part) => Number(part));
	if (!Number.isFinite(h) || !Number.isFinite(m)) return 0;
	return h * 60 + m;
}
function inQuietHours(now, start, end) {
	const date = new Date(now);
	const cur = date.getHours() * 60 + date.getMinutes();
	const from = minutesOf(start);
	const to = minutesOf(end);
	if (from === to) return false;
	if (from < to) return cur >= from && cur < to;
	return cur >= from || cur < to;
}
function effectiveDnd(settings, now) {
	if (settings.dnd !== "off") return settings.dnd;
	if (now > 0 && settings.dndScheduleOn && inQuietHours(now, settings.dndStart, settings.dndEnd)) return "priority";
	return "off";
}
function gate(importance, channel, dnd) {
	if (dnd === "off") return {
		ok: true,
		reason: ""
	};
	if (dnd === "priority" && (importance === "high" || importance === "max" || channel.bypassDnd)) return {
		ok: true,
		reason: ""
	};
	if (dnd === "alarms" && (importance === "max" || channel.bypassDnd)) return {
		ok: true,
		reason: ""
	};
	if (dnd === "total" && importance === "max" && channel.bypassDnd) return {
		ok: true,
		reason: ""
	};
	return {
		ok: false,
		reason: dnd === "total" ? "Diblokir jangan ganggu total" : dnd === "alarms" ? "Hanya alarm yang boleh masuk" : "Diblokir — hanya prioritas"
	};
}
function isSilent(importance) {
	return importance === "min" || importance === "low";
}
function step(from, repeat) {
	if (repeat === "daily") return from + 864e5;
	if (repeat === "weekly") return from + 6048e5;
	if (repeat === "weekdays") {
		const next = new Date(from);
		next.setDate(next.getDate() + 1);
		let guard = 0;
		while ((next.getDay() === 0 || next.getDay() === 6) && guard < 4) {
			next.setDate(next.getDate() + 1);
			guard += 1;
		}
		return next.getTime();
	}
	return null;
}
function nextFire(fireAt, repeat, now) {
	if (repeat === "once") return null;
	let cursor = fireAt;
	for (let i = 0; i < 400; i += 1) {
		const next = step(cursor, repeat);
		if (next == null) return null;
		cursor = next;
		if (cursor > now) return cursor;
	}
	return null;
}
function formatClock(ts) {
	return new Intl.DateTimeFormat("id-ID", {
		hour: "2-digit",
		minute: "2-digit"
	}).format(ts);
}
function formatDate(ts) {
	return new Intl.DateTimeFormat("id-ID", {
		weekday: "long",
		day: "numeric",
		month: "long"
	}).format(ts);
}
function formatWhen(ts) {
	return new Intl.DateTimeFormat("id-ID", {
		weekday: "short",
		day: "numeric",
		month: "short",
		hour: "2-digit",
		minute: "2-digit"
	}).format(ts);
}
function countdown(fireAt, now) {
	const sec = Math.max(0, Math.round((fireAt - now) / 1e3));
	const h = Math.floor(sec / 3600);
	const m = Math.floor(sec % 3600 / 60);
	const s = sec % 60;
	if (h > 0) return `${h} j ${m} m`;
	if (m > 0) return `${m} m ${String(s).padStart(2, "0")} d`;
	return `${s} d`;
}
function ago(ts, now) {
	if (!ts || !now) return "baru saja";
	const sec = Math.max(0, Math.round((now - ts) / 1e3));
	if (sec < 15) return "baru saja";
	if (sec < 60) return `${sec} dtk lalu`;
	const mins = Math.round(sec / 60);
	if (mins < 60) return `${mins} mnt lalu`;
	const hours = Math.round(mins / 60);
	if (hours < 24) return `${hours} jam lalu`;
	return `${Math.round(hours / 24)} hr lalu`;
}
function toLocalInput(ts) {
	const date = new Date(ts);
	const pad = (n) => String(n).padStart(2, "0");
	return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
}
var HISTORY_LABEL = {
	shown: "Muncul",
	dismissed: "Ditutup",
	snoozed: "Ditunda",
	suppressed: "Diblokir",
	cleared: "Dibersihkan",
	missed: "Terlewat",
	action: "Aksi"
};
var ctx = null;
function context() {
	if (typeof window === "undefined") return null;
	const Ctor = window.AudioContext || window.webkitAudioContext;
	if (!Ctor) return null;
	ctx ??= new Ctor();
	return ctx;
}
function unlockAudio() {
	const audio = context();
	if (!audio) return;
	audio.resume().catch(() => void 0);
}
function playChime(importance) {
	try {
		const audio = context();
		if (!audio) return;
		audio.resume();
		(importance === "max" ? [
			784,
			988,
			784,
			1174
		] : importance === "high" ? [659, 880] : [523, 659]).forEach((freq, index) => {
			const osc = audio.createOscillator();
			const gain = audio.createGain();
			osc.type = "sine";
			osc.frequency.value = freq;
			osc.connect(gain);
			gain.connect(audio.destination);
			const start = audio.currentTime + index * .13;
			gain.gain.setValueAtTime(1e-4, start);
			gain.gain.exponentialRampToValueAtTime(.05, start + .02);
			gain.gain.exponentialRampToValueAtTime(1e-4, start + .2);
			osc.start(start);
			osc.stop(start + .22);
		});
	} catch {}
}
function browserNotify(title, body, tag) {
	try {
		if (typeof Notification === "undefined" || Notification.permission !== "granted") return;
		new Notification(title, {
			body,
			tag
		});
	} catch {}
}
function pulse(pattern) {
	try {
		navigator.vibrate?.(pattern);
	} catch {}
}
var LATE_MS = 216e5;
var DND_CYCLE = [
	"off",
	"priority",
	"alarms",
	"total"
];
function cloneSeed() {
	return {
		shade: SEED_SHADE.map((item) => ({
			...item,
			inbox: [...item.inbox],
			chat: item.chat.map((line) => ({ ...line })),
			actions: item.actions.map((action) => ({ ...action }))
		})),
		schedules: [],
		channels: SEED_CHANNELS.map((channel) => ({ ...channel })),
		settings: { ...DEFAULT_SETTINGS },
		history: [],
		booted: false
	};
}
function runtime() {
	return {
		now: 0,
		banner: null,
		alarmId: null,
		flash: null,
		announce: "",
		editNonce: 0,
		editId: null
	};
}
function pushHistory(history, entry) {
	return [entry, ...history].slice(0, 60);
}
function deliver(state, draft, now, scheduleId) {
	const channel = channelById(state.channels, draft.channelId);
	if (!channel) return {
		state,
		shown: false
	};
	const payload = materialize(draft, channel);
	if (!payload.title) return {
		state,
		shown: false
	};
	const dnd = effectiveDnd(state.settings, now);
	const decision = gate(payload.importance, channel, dnd);
	if (!decision.ok) return {
		shown: false,
		state: {
			...state,
			now,
			flash: {
				text: decision.reason,
				until: now + 2400
			},
			announce: decision.reason,
			history: pushHistory(state.history, {
				id: uid(),
				at: now,
				title: payload.title,
				appName: payload.appName,
				result: "suppressed",
				note: decision.reason
			})
		}
	};
	const item = shadeFromPayload(payload, now, scheduleId);
	const shade = [item, ...state.shade.filter((existing) => !scheduleId || existing.scheduleId !== scheduleId)].slice(0, 14);
	const wantsBanner = item.importance === "max" || item.headsUp && item.importance !== "min" && item.importance !== "low";
	const audible = !state.settings.mute && item.sound && channel.sound && dnd !== "total" && item.importance !== "min" && item.importance !== "low";
	if (audible) playChime(item.importance);
	if (audible && state.settings.vibrateDevice && item.vibrate && channel.vibrate) pulse(item.importance === "max" ? [
		180,
		70,
		180,
		70,
		280
	] : [
		30,
		40,
		30
	]);
	if (state.settings.browserNotify) browserNotify(item.title, item.body || item.appName, item.scheduleId ?? item.id);
	return {
		shown: true,
		state: {
			...state,
			now,
			shade,
			banner: wantsBanner ? {
				id: item.id,
				until: now + 4600
			} : state.banner,
			alarmId: item.importance === "max" ? item.id : state.alarmId,
			announce: `${item.appName}: ${item.title}`,
			flash: {
				text: "Muncul di panel",
				until: now + 2200
			},
			history: pushHistory(state.history, {
				id: uid(),
				at: now,
				title: item.title,
				appName: item.appName,
				result: "shown"
			})
		}
	};
}
var useNotifStore = create()(persist((set, get) => ({
	...cloneSeed(),
	...runtime(),
	tick: (now) => {
		const current = get();
		let next = {
			...current,
			now
		};
		let fired = false;
		const schedules = current.schedules.map((schedule) => {
			if (!schedule.enabled || schedule.fireAt > now) return schedule;
			fired = true;
			const late = now - schedule.fireAt;
			if (schedule.repeat === "once" && late > LATE_MS) {
				next = {
					...next,
					history: pushHistory(next.history, {
						id: uid(),
						at: now,
						title: schedule.title,
						appName: schedule.appName,
						result: "missed",
						note: "Lewat dari enam jam"
					})
				};
				return {
					...schedule,
					enabled: false
				};
			}
			next = deliver(next, draftFromSchedule(schedule), now, schedule.id).state;
			const upcoming = nextFire(schedule.fireAt, schedule.repeat, now);
			if (!upcoming) return {
				...schedule,
				enabled: false
			};
			return {
				...schedule,
				fireAt: upcoming,
				enabled: true
			};
		});
		const banner = next.banner && next.banner.until > now ? next.banner : null;
		const flash = next.flash && next.flash.until > now ? next.flash : null;
		if (!fired && banner === current.banner && flash === current.flash) {
			set({ now });
			return;
		}
		set({
			...next,
			schedules,
			banner,
			flash,
			now
		});
	},
	ensureBoot: (now) => {
		const state = get();
		if (state.booted) return;
		const demo = {
			id: "boot-minum",
			appName: "Jam",
			icon: "clock",
			channelId: "pengingat",
			title: "Minum air",
			body: "Sudah waktunya isi ulang gelas.",
			style: "bigtext",
			bigText: "Sudah waktunya isi ulang gelas. Jadwal ini dibuat otomatis supaya kamu bisa melihat hitung mundur.",
			inbox: [],
			chat: [],
			progress: 0,
			actions: [{
				id: "boot-a",
				label: "Sudah"
			}],
			override: false,
			importance: "default",
			ongoing: false,
			headsUp: false,
			sound: true,
			vibrate: true,
			privacy: "public",
			repeat: "once",
			enabled: true,
			fireAt: now + 18e4
		};
		set({
			booted: true,
			schedules: [demo, ...state.schedules.filter((item) => item.id !== demo.id)]
		});
	},
	present: (draft) => {
		const now = Date.now();
		const result = deliver({
			...get(),
			now
		}, draft, now);
		set(result.state);
		return result.shown ? result.state.announce : null;
	},
	scheduleDraft: (draft, fireAt, existingId) => {
		const channel = channelById(get().channels, draft.channelId);
		if (!channel) return "Saluran tidak ditemukan.";
		const payload = materialize(draft, channel);
		if (!payload.title) return "Isi judul notifikasi.";
		if (!Number.isFinite(fireAt)) return "Waktu tidak valid.";
		const schedule = {
			...draft,
			...payload,
			inbox: payload.inbox,
			id: existingId ?? uid(),
			fireAt,
			enabled: true,
			repeat: draft.repeat,
			override: draft.override
		};
		set((state) => ({
			schedules: existingId ? state.schedules.map((item) => item.id === existingId ? schedule : item) : [schedule, ...state.schedules],
			editId: null,
			flash: {
				text: existingId ? "Jadwal diperbarui" : "Masuk jadwal",
				until: Date.now() + 1600
			}
		}));
		return null;
	},
	dismiss: (id) => {
		const item = get().shade.find((entry) => entry.id === id);
		if (!item || item.ongoing) return;
		const now = Date.now();
		set((state) => ({
			shade: state.shade.filter((entry) => entry.id !== id),
			banner: state.banner?.id === id ? null : state.banner,
			alarmId: state.alarmId === id ? null : state.alarmId,
			history: pushHistory(state.history, {
				id: uid(),
				at: now,
				title: item.title,
				appName: item.appName,
				result: "dismissed"
			})
		}));
	},
	stopOngoing: (id) => {
		set((state) => ({ shade: state.shade.map((item) => item.id === id ? {
			...item,
			ongoing: false
		} : item) }));
		get().dismiss(id);
	},
	snooze: (id, ms, label) => {
		const item = get().shade.find((entry) => entry.id === id);
		if (!item) return;
		const now = Date.now();
		const schedule = {
			id: uid(),
			appName: item.appName,
			icon: item.icon,
			channelId: item.channelId,
			title: item.title,
			body: item.body,
			style: item.style,
			bigText: item.bigText,
			inbox: item.inbox,
			chat: item.chat,
			progress: item.progress,
			actions: item.actions,
			override: true,
			importance: item.importance,
			ongoing: item.ongoing,
			headsUp: item.headsUp,
			sound: item.sound,
			vibrate: item.vibrate,
			privacy: item.privacy,
			repeat: "once",
			enabled: true,
			fireAt: now + ms
		};
		set((state) => ({
			schedules: [schedule, ...state.schedules],
			shade: state.shade.filter((entry) => entry.id !== id),
			banner: state.banner?.id === id ? null : state.banner,
			alarmId: state.alarmId === id ? null : state.alarmId,
			flash: {
				text: `Ditunda ${label}`,
				until: now + 1800
			},
			history: pushHistory(state.history, {
				id: uid(),
				at: now,
				title: item.title,
				appName: item.appName,
				result: "snoozed",
				note: label
			})
		}));
	},
	toggleExpand: (id) => {
		set((state) => ({ shade: state.shade.map((item) => item.id === id ? {
			...item,
			expanded: !item.expanded
		} : item) }));
	},
	togglePlay: (id) => {
		set((state) => ({ shade: state.shade.map((item) => item.id === id ? {
			...item,
			playing: !item.playing
		} : item) }));
	},
	reply: (id, text) => {
		const trimmed = text.trim();
		if (!trimmed) return;
		const now = Date.now();
		set((state) => ({
			shade: state.shade.map((item) => item.id === id ? {
				...item,
				body: trimmed,
				chat: [...item.chat, {
					id: uid(),
					author: "Saya",
					text: trimmed
				}],
				expanded: true
			} : item),
			flash: {
				text: "Balasan terkirim",
				until: now + 1600
			},
			history: pushHistory(state.history, {
				id: uid(),
				at: now,
				title: trimmed,
				appName: state.shade.find((item) => item.id === id)?.appName ?? "Pesan",
				result: "action",
				note: "Balas"
			})
		}));
	},
	runAction: (id, label) => {
		const key = label.toLowerCase();
		if (key === "tunda") {
			get().snooze(id, 9e5, "15 menit");
			return;
		}
		if (key === "batal") {
			get().stopOngoing(id);
			return;
		}
		if (key === "jeda") {
			const now = Date.now();
			set((state) => ({
				shade: state.shade.map((item) => item.id === id ? {
					...item,
					playing: false,
					body: "Dijeda"
				} : item),
				flash: {
					text: "Unduhan dijeda",
					until: now + 1600
				}
			}));
			return;
		}
		const item = get().shade.find((entry) => entry.id === id);
		const now = Date.now();
		set((state) => ({
			flash: {
				text: `Aksi “${label}” dikirim`,
				until: now + 1700
			},
			history: pushHistory(state.history, {
				id: uid(),
				at: now,
				title: item?.title ?? label,
				appName: item?.appName ?? "Aplikasi",
				result: "action",
				note: label
			})
		}));
	},
	patchSettings: (patch) => {
		set((state) => ({ settings: {
			...state.settings,
			...patch
		} }));
	},
	cycleDnd: () => {
		set((state) => {
			const dnd = DND_CYCLE[(DND_CYCLE.indexOf(state.settings.dnd) + 1) % DND_CYCLE.length] ?? "off";
			return { settings: {
				...state.settings,
				dnd
			} };
		});
	},
	addChannel: (channel) => {
		const name = channel.name.trim();
		if (!name) return;
		set((state) => ({ channels: [...state.channels, {
			...channel,
			name,
			id: uid()
		}] }));
	},
	updateChannel: (id, patch) => {
		set((state) => ({ channels: state.channels.map((channel) => channel.id === id ? {
			...channel,
			...patch,
			id: channel.id
		} : channel) }));
	},
	removeChannel: (id) => {
		const channel = get().channels.find((item) => item.id === id);
		if (!channel || channel.system) return;
		set((state) => ({
			channels: state.channels.filter((item) => item.id !== id),
			schedules: state.schedules.map((item) => item.channelId === id ? {
				...item,
				channelId: "umum"
			} : item)
		}));
	},
	removeSchedule: (id) => {
		set((state) => ({
			schedules: state.schedules.filter((item) => item.id !== id),
			editId: state.editId === id ? null : state.editId
		}));
	},
	toggleSchedule: (id) => {
		set((state) => ({ schedules: state.schedules.map((item) => item.id === id ? {
			...item,
			enabled: !item.enabled
		} : item) }));
	},
	requestEdit: (id) => {
		set({
			editId: id,
			editNonce: Date.now()
		});
	},
	clearShade: () => {
		const now = Date.now();
		set((state) => ({
			shade: state.shade.filter((item) => item.ongoing),
			banner: null,
			alarmId: null,
			history: pushHistory(state.history, {
				id: uid(),
				at: now,
				title: "Panel",
				appName: "Lonceng",
				result: "cleared"
			})
		}));
	},
	resetAll: () => {
		set({
			...cloneSeed(),
			...runtime(),
			booted: true,
			now: get().now
		});
	}
}), {
	name: "lonceng-v1",
	storage: createJSONStorage(() => localStorage),
	skipHydration: true,
	partialize: (state) => ({
		shade: state.shade,
		schedules: state.schedules,
		channels: state.channels,
		settings: state.settings,
		history: state.history,
		booted: state.booted
	})
}));
function useNotifEngine() {
	(0, import_react.useEffect)(() => {
		let cancel = false;
		const boot = async () => {
			try {
				await useNotifStore.persist.rehydrate();
			} catch {}
			if (cancel) return;
			const now = Date.now();
			useNotifStore.getState().ensureBoot(now);
			useNotifStore.getState().tick(now);
		};
		boot();
		const id = window.setInterval(() => {
			useNotifStore.getState().tick(Date.now());
		}, 1e3);
		const unlock = () => unlockAudio();
		window.addEventListener("pointerdown", unlock);
		return () => {
			cancel = true;
			window.clearInterval(id);
			window.removeEventListener("pointerdown", unlock);
		};
	}, []);
}
var APP_ICONS = {
	message: MessageCircle,
	mail: Mail,
	calendar: Calendar,
	clock: Clock,
	cloud: CloudSun,
	music: Music,
	download: Download,
	map: MapPin,
	bell: Bell
};
function AppGlyph({ icon, lively = false, className }) {
	const Icon = APP_ICONS[icon];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("grid size-10 shrink-0 place-items-center rounded-full", lively ? "bg-primary text-primary-fg" : "bg-surface-3 text-primary", className),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
			className: "size-5",
			"aria-hidden": "true"
		})
	});
}
function NotifCard({ item, now, interactive = true, onToggle, onDismiss, onStop, onSnooze, onAction, onReply, onTogglePlay }) {
	const [dx, setDx] = (0, import_react.useState)(0);
	const [origin, setOrigin] = (0, import_react.useState)(null);
	const [reply, setReply] = (0, import_react.useState)("");
	const [replyOpen, setReplyOpen] = (0, import_react.useState)(false);
	const lively = item.importance === "high" || item.importance === "max" || item.icon === "message";
	function pointerDown(event) {
		if (!interactive || item.ongoing) return;
		setOrigin(event.clientX);
	}
	function pointerMove(event) {
		if (origin == null) return;
		setDx(event.clientX - origin);
	}
	function pointerUp() {
		if (origin != null && Math.abs(dx) > 96) onDismiss?.();
		setOrigin(null);
		setDx(0);
	}
	function act(label) {
		if (label.toLowerCase() === "balas") {
			setReplyOpen(true);
			if (!item.expanded) onToggle?.();
			return;
		}
		onAction?.(label);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "overflow-hidden rounded-lg border border-line bg-surface-2 text-fg shadow-sm",
		style: {
			transform: dx ? `translateX(${dx}px)` : void 0,
			opacity: dx ? 1 - Math.min(Math.abs(dx) / 280, .45) : 1
		},
		onPointerDown: pointerDown,
		onPointerMove: pointerMove,
		onPointerUp: pointerUp,
		onPointerCancel: pointerUp,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-3 p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppGlyph, {
						icon: item.icon,
						lively
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-xs text-muted",
									children: item.appName
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ml-auto shrink-0 text-xs text-faint",
									children: ago(item.shownAt, now)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "truncate font-display text-sm font-semibold",
								children: item.title
							}),
							item.style !== "chat" || !item.expanded ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: cn("text-sm text-muted", item.expanded ? "" : "line-clamp-2"),
								children: item.body
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex shrink-0 flex-col items-end gap-1",
						children: [interactive ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "grid size-8 place-items-center rounded-full text-muted",
							"aria-label": item.ongoing ? "Hentikan notifikasi berjalan" : "Tutup notifikasi",
							onClick: () => item.ongoing ? onStop?.() : onDismiss?.(),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
						}) : null, interactive ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "grid size-8 place-items-center rounded-full text-muted",
							"aria-expanded": item.expanded,
							"aria-label": item.expanded ? "Ciutkan" : "Luaskan",
							onClick: onToggle,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: cn("size-4 transition-transform", item.expanded && "rotate-180") })
						}) : null]
					})
				]
			}),
			item.style === "progress" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-3 pb-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-1.5 overflow-hidden rounded-full bg-surface-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-full rounded-full bg-primary",
						style: { width: `${item.progress}%` }
					})
				})
			}) : null,
			item.style === "media" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 px-3 pb-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-11 place-items-center rounded-full bg-primary text-primary-fg",
						"aria-label": item.playing ? "Jeda" : "Putar",
						onClick: onTogglePlay,
						children: item.playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-11 place-items-center rounded-full bg-surface-3 text-fg",
						"aria-label": "Berikutnya",
						onClick: () => onAction?.("Berikutnya"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkipForward, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted",
						children: item.playing ? "Memutar" : "Dijeda"
					})
				]
			}) : null,
			(item.importance === "high" || item.importance === "max") && !item.expanded ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-3 pb-3 text-xs text-accent",
				children: IMPORTANCE_LABEL[item.importance]
			}) : null,
			item.expanded ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 border-t border-line px-3 py-3",
				children: [
					item.style === "bigtext" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-fg",
						children: item.bigText
					}) : null,
					item.style === "inbox" && item.inbox.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-1 text-sm text-fg",
						children: item.inbox.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "truncate",
							children: line
						}, line))
					}) : null,
					item.style === "chat" && item.chat.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-2",
						children: item.chat.map((line) => {
							const mine = line.author === "Saya";
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: cn("flex", mine ? "justify-end" : "justify-start"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: cn("max-w-[85%] rounded-md px-3 py-2", mine ? "bg-primary text-primary-fg" : "bg-surface-3 text-fg"),
									children: [!mine ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-semibold",
										children: line.author
									}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm",
										children: line.text
									})]
								})
							}, line.id);
						})
					}) : null,
					item.actions.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: item.actions.map((action) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "min-h-11 rounded-md bg-surface-3 px-3 text-sm font-semibold text-primary",
							onClick: () => act(action.label),
							children: action.label
						}, action.id))
					}) : null,
					replyOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "flex gap-2",
						onSubmit: (event) => {
							event.preventDefault();
							onReply?.(reply);
							setReply("");
							setReplyOpen(false);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: reply,
							onChange: (event) => setReply(event.target.value),
							placeholder: "Balas",
							"aria-label": "Balas pesan",
							className: "min-h-11 min-w-0 flex-1 rounded-md border border-line bg-bg px-3 text-sm text-fg"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							className: "min-h-11 rounded-md bg-primary px-3 text-sm font-semibold text-primary-fg",
							children: "Kirim"
						})]
					}) : null,
					interactive && onSnooze ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: [
							[3e5, "5 mnt"],
							[9e5, "15 mnt"],
							[36e5, "1 jam"]
						].map(([ms, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "min-h-11 rounded-md border border-line px-3 text-xs text-muted",
							onClick: () => onSnooze(Number(ms), String(label)),
							children: ["Tunda ", label]
						}, label))
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-faint",
						children: [item.ongoing ? "Berjalan terus · tidak bisa digeser" : "Geser untuk menutup", isSilent(item.importance) ? " · diam" : ""]
					})
				]
			}) : null
		]
	});
}
function Button({ variant = "primary", className, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: cn("inline-flex min-h-11 items-center justify-center gap-2 rounded-md px-4 text-sm font-semibold transition-transform duration-150 ease-out active:not-disabled:scale-[0.96] disabled:cursor-not-allowed disabled:opacity-50", variant === "primary" && "bg-primary text-primary-fg", variant === "secondary" && "bg-surface-3 text-fg", variant === "ghost" && "border border-line bg-transparent text-fg", variant === "danger" && "bg-accent text-primary-fg", className),
		...props
	});
}
function Switch({ checked, onChange, label, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		role: "switch",
		"aria-checked": checked,
		onClick: () => onChange(!checked),
		className: "flex min-h-11 w-full items-center justify-between gap-4 py-1 text-left",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "block text-sm text-fg",
			children: label
		}), hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mt-0.5 block text-xs text-muted",
			children: hint
		}) : null] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("relative h-7 w-12 shrink-0 rounded-full p-0.5 transition-colors", checked ? "bg-primary" : "bg-surface-3"),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("block size-6 rounded-full transition-transform", checked ? "translate-x-5 bg-primary-fg" : "translate-x-0 bg-fg") })
		})]
	});
}
function Field({ label, children, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mb-1.5 block text-sm font-medium text-fg",
				children: label
			}),
			children,
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-1.5 block text-xs text-muted",
				children: hint
			}) : null
		]
	});
}
function Panel({ title, children, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-lg border border-line bg-surface p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-3 flex items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-base font-semibold text-fg",
				children: title
			}), action]
		}), children]
	});
}
var controlClass = "w-full rounded-md border border-line bg-surface-2 px-3 py-3 text-sm text-fg placeholder:text-faint";
var TIMING = [
	{
		id: "10s",
		label: "10 dtk",
		ms: 1e4
	},
	{
		id: "30s",
		label: "30 dtk",
		ms: 3e4
	},
	{
		id: "1m",
		label: "1 mnt",
		ms: 6e4
	},
	{
		id: "5m",
		label: "5 mnt",
		ms: 3e5
	},
	{
		id: "1h",
		label: "1 jam",
		ms: 36e5
	},
	{
		id: "at",
		label: "Jam tertentu"
	}
];
function fireAtFor(timing, at) {
	const preset = TIMING.find((item) => item.id === timing);
	if (preset?.ms) return Date.now() + preset.ms;
	const parsed = new Date(at).getTime();
	return Number.isFinite(parsed) ? parsed : Date.now() + 6e4;
}
function Composer() {
	const channels = useNotifStore((state) => state.channels);
	const editNonce = useNotifStore((state) => state.editNonce);
	const editId = useNotifStore((state) => state.editId);
	const present = useNotifStore((state) => state.present);
	const scheduleDraft = useNotifStore((state) => state.scheduleDraft);
	const [draft, setDraft] = (0, import_react.useState)(TEMPLATES[1]?.draft ?? blankDraft());
	const [timing, setTiming] = (0, import_react.useState)("10s");
	const [at, setAt] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const [author, setAuthor] = (0, import_react.useState)("");
	const [line, setLine] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		setAt(toLocalInput(Date.now() + 36e5));
	}, []);
	(0, import_react.useEffect)(() => {
		if (!editNonce || !editId) return;
		const schedule = useNotifStore.getState().schedules.find((item) => item.id === editId);
		if (!schedule) return;
		setDraft(draftFromSchedule(schedule));
		setTiming("at");
		setAt(toLocalInput(schedule.fireAt));
		setError("");
		window.scrollTo({
			top: 0,
			behavior: "smooth"
		});
	}, [editNonce, editId]);
	function patch(partial) {
		setDraft((current) => ({
			...current,
			...partial
		}));
		setError("");
	}
	function applyTemplate(id) {
		const template = TEMPLATES.find((item) => item.id === id);
		if (!template) return;
		setDraft({
			...template.draft,
			actions: template.draft.actions.map((action) => ({ ...action })),
			chat: template.draft.chat.map((entry) => ({ ...entry }))
		});
		setError("");
	}
	const channel = channelById(channels, draft.channelId);
	const preview = {
		...materialize(draft.title.trim() ? draft : {
			...draft,
			title: draft.title || "Judul notifikasi"
		}, channel),
		id: "preview",
		shownAt: 0,
		expanded: true,
		playing: draft.style === "media"
	};
	function showNow() {
		if (!draft.title.trim()) {
			setError("Isi judul notifikasi.");
			return;
		}
		present(draft);
	}
	function schedule(nextTiming = timing, asNew = false) {
		if (!draft.title.trim()) {
			setError("Isi judul notifikasi.");
			return;
		}
		const message = scheduleDraft(draft, fireAtFor(nextTiming, at), asNew ? null : editId);
		if (message) setError(message);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "space-y-4",
		onSubmit: (event) => {
			event.preventDefault();
			schedule();
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "Templat",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-2 overflow-x-auto pb-1",
					children: TEMPLATES.map((template) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => applyTemplate(template.id),
						className: "min-h-11 shrink-0 rounded-full border border-line bg-surface-2 px-4 text-sm text-fg",
						children: template.name
					}, template.id))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "Pengirim",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Nama aplikasi",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: draft.appName,
							onChange: (event) => patch({ appName: event.target.value }),
							className: controlClass,
							maxLength: 32,
							required: true
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: ICONS.map((icon) => {
							const Icon = APP_ICONS[icon];
							const selected = draft.icon === icon;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": icon,
								"aria-pressed": selected,
								onClick: () => patch({ icon }),
								className: cn("grid size-11 place-items-center rounded-full", selected ? "bg-primary text-primary-fg" : "bg-surface-3 text-fg"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" })
							}, icon);
						})
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "Isi",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Saluran",
							hint: "Di Android, suara dan prioritas biasanya diatur di saluran, bukan per notifikasi.",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								value: draft.channelId,
								onChange: (event) => patch({ channelId: event.target.value }),
								className: controlClass,
								children: channels.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
									value: item.id,
									children: [
										item.name,
										" · ",
										IMPORTANCE_LABEL[item.importance]
									]
								}, item.id))
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Judul",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: draft.title,
								onChange: (event) => patch({ title: event.target.value }),
								className: controlClass,
								maxLength: 80,
								placeholder: "Misalnya, Minum air",
								required: true
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Pesan",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								value: draft.body,
								onChange: (event) => patch({ body: event.target.value }),
								className: cn(controlClass, "min-h-24 resize-y"),
								maxLength: 240,
								placeholder: "Teks singkat di kartu"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-2 text-sm font-medium",
							children: "Gaya"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-2 gap-2 sm:grid-cols-3",
							children: Object.keys(STYLE_LABEL).map((style) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-pressed": draft.style === style,
								onClick: () => patch({ style }),
								className: cn("min-h-11 rounded-md px-2 text-sm", draft.style === style ? "bg-primary text-primary-fg" : "bg-surface-3 text-fg"),
								children: STYLE_LABEL[style]
							}, style))
						})] }),
						draft.style === "bigtext" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Teks panjang",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								value: draft.bigText,
								onChange: (event) => patch({ bigText: event.target.value }),
								className: cn(controlClass, "min-h-28 resize-y"),
								maxLength: 500
							})
						}) : null,
						draft.style === "inbox" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Baris kotak masuk",
							hint: "Satu baris untuk satu item.",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								value: draft.inboxText,
								onChange: (event) => patch({ inboxText: event.target.value }),
								className: cn(controlClass, "min-h-28 resize-y"),
								placeholder: "Andi: catatan rapat\nSari: undangan"
							})
						}) : null,
						draft.style === "chat" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [draft.chat.map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-2 rounded-md bg-surface-2 px-3 py-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-semibold",
											children: entry.author
										}),
										" · ",
										entry.text
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "min-h-11 shrink-0 text-xs text-accent",
									onClick: () => patch({ chat: draft.chat.filter((item) => item.id !== entry.id) }),
									children: "Hapus"
								})]
							}, entry.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-2 sm:grid-cols-[8rem_1fr_auto]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: author,
										onChange: (event) => setAuthor(event.target.value),
										placeholder: "Nama",
										"aria-label": "Nama pengirim",
										className: controlClass
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: line,
										onChange: (event) => setLine(event.target.value),
										placeholder: "Pesan",
										"aria-label": "Isi pesan",
										className: controlClass
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "secondary",
										onClick: () => {
											if (!line.trim()) return;
											patch({ chat: [...draft.chat, {
												id: crypto.randomUUID(),
												author: author.trim() || "Teman",
												text: line.trim()
											}] });
											setLine("");
										},
										children: "Tambah"
									})
								]
							})]
						}) : null,
						draft.style === "progress" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: `Progres ${draft.progress}%`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "range",
								min: 0,
								max: 100,
								value: draft.progress,
								onChange: (event) => patch({ progress: Number(event.target.value) }),
								className: "range w-full"
							})
						}) : null
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				title: "Perilaku Android",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
						checked: draft.override,
						onChange: (override) => patch({ override }),
						label: "Timpa saluran",
						hint: draft.override ? "Kepentingan, suara, dan privasi diatur di sini." : `Mengikuti saluran ${channel?.name ?? ""}: ${channel ? IMPORTANCE_LABEL[channel.importance] : ""}.`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: cn("mt-3 grid gap-3", !draft.override && "opacity-50"),
						inert: !draft.override,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-5 gap-1",
								children: IMPORTANCE_ORDER.map((level) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-pressed": draft.importance === level,
									onClick: () => patch({
										importance: level,
										headsUp: level === "high" || level === "max"
									}),
									className: cn("min-h-11 rounded-md px-1 text-xs font-semibold", draft.importance === level ? "bg-primary text-primary-fg" : "bg-surface-3 text-fg"),
									children: IMPORTANCE_LABEL[level]
								}, level))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: IMPORTANCE_HELP[draft.override ? draft.importance : channel?.importance ?? "default"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
								checked: draft.headsUp,
								onChange: (headsUp) => patch({ headsUp }),
								label: "Muncul mengambang (heads-up)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
								checked: draft.sound,
								onChange: (sound) => patch({ sound }),
								label: "Suara"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
								checked: draft.vibrate,
								onChange: (vibrate) => patch({ vibrate }),
								label: "Getar"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-2 text-sm font-medium",
								children: "Layar kunci"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-3 gap-2",
								children: Object.keys(PRIVACY_LABEL).map((privacy) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-pressed": draft.privacy === privacy,
									onClick: () => patch({ privacy }),
									className: cn("min-h-11 rounded-md px-2 text-xs", draft.privacy === privacy ? "bg-primary text-primary-fg" : "bg-surface-3 text-fg"),
									children: PRIVACY_LABEL[privacy]
								}, privacy))
							})] })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: draft.ongoing,
							onChange: (ongoing) => patch({ ongoing }),
							label: "Berjalan terus",
							hint: "Tidak bisa digeser. Cocok untuk unduhan, navigasi, atau alarm."
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "Tombol aksi",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-2",
					children: [draft.actions.map((action, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: action.label,
						"aria-label": `Aksi ${index + 1}`,
						placeholder: index === 0 ? "Balas" : "Tunda",
						maxLength: 24,
						onChange: (event) => {
							patch({ actions: draft.actions.map((item) => item.id === action.id ? {
								...item,
								label: event.target.value
							} : item) });
						},
						className: controlClass
					}, action.id)), draft.actions.length < 3 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						onClick: () => patch({ actions: [...draft.actions, {
							id: crypto.randomUUID(),
							label: ""
						}] }),
						children: "Tambah aksi"
					}) : null]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				title: "Kapan muncul",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-3 gap-2",
						children: TIMING.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-pressed": timing === item.id,
							onClick: () => setTiming(item.id),
							className: cn("min-h-11 rounded-md px-2 text-sm", timing === item.id ? "bg-primary text-primary-fg" : "bg-surface-3 text-fg"),
							children: item.label
						}, item.id))
					}),
					timing === "at" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "datetime-local",
						value: at,
						onChange: (event) => setAt(event.target.value),
						className: cn(controlClass, "mt-3"),
						"aria-label": "Waktu kemunculan"
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Ulangi",
						hint: "Pengulangan mengikuti jam pertama kali notifikasi muncul.",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							value: draft.repeat,
							onChange: (event) => patch({ repeat: event.target.value }),
							className: cn(controlClass, "mt-3"),
							children: Object.keys(REPEAT_LABEL).map((repeat) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: repeat,
								children: REPEAT_LABEL[repeat]
							}, repeat))
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "Pratinjau kartu",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotifCard, {
					item: preview,
					now: 0,
					interactive: false
				})
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-accent",
				children: error
			}) : null,
			editId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-primary",
				children: "Mengedit jadwal yang sudah ada."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						className: "col-span-2",
						onClick: () => schedule("10s", true),
						children: "Uji dalam 10 detik"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						onClick: showNow,
						children: "Tampilkan sekarang"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						children: editId ? "Simpan jadwal" : "Jadwalkan"
					})
				]
			})
		]
	});
}
function statusIcons(items) {
	const names = [];
	for (const item of items) {
		if (isSilent(item.importance)) continue;
		if (!names.includes(item.appName)) names.push(item.appName);
	}
	return names.slice(0, 3);
}
function Phone() {
	const [face, setFace] = (0, import_react.useState)("shade");
	const [light, setLight] = (0, import_react.useState)(false);
	const [spin, setSpin] = (0, import_react.useState)(false);
	const [saver, setSaver] = (0, import_react.useState)(false);
	const now = useNotifStore((state) => state.now);
	const shade = useNotifStore((state) => state.shade);
	const settings = useNotifStore((state) => state.settings);
	const banner = useNotifStore((state) => state.banner);
	const alarmId = useNotifStore((state) => state.alarmId);
	const flash = useNotifStore((state) => state.flash);
	const cycleDnd = useNotifStore((state) => state.cycleDnd);
	const patchSettings = useNotifStore((state) => state.patchSettings);
	const dismiss = useNotifStore((state) => state.dismiss);
	const stopOngoing = useNotifStore((state) => state.stopOngoing);
	const snooze = useNotifStore((state) => state.snooze);
	const toggleExpand = useNotifStore((state) => state.toggleExpand);
	const togglePlay = useNotifStore((state) => state.togglePlay);
	const reply = useNotifStore((state) => state.reply);
	const runAction = useNotifStore((state) => state.runAction);
	const clearShade = useNotifStore((state) => state.clearShade);
	const dnd = effectiveDnd(settings, now);
	const alerting = shade.filter((item) => !isSilent(item.importance));
	const silent = shade.filter((item) => isSilent(item.importance));
	const bannerItem = shade.find((item) => item.id === banner?.id);
	const alarm = shade.find((item) => item.id === alarmId);
	const clock = now > 0 ? formatClock(now) : "––:––";
	function renderCard(item) {
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotifCard, {
			item,
			now,
			onToggle: () => toggleExpand(item.id),
			onDismiss: () => dismiss(item.id),
			onStop: () => stopOngoing(item.id),
			onSnooze: (ms, label) => snooze(item.id, ms, label),
			onAction: (label) => runAction(item.id, label),
			onReply: (text) => reply(item.id, text),
			onTogglePlay: () => togglePlay(item.id)
		}, item.id);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto w-phone max-w-full",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex h-phone w-full flex-col rounded-phone border border-line bg-surface-2 p-2 shadow-lg",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative flex min-h-0 flex-1 flex-col overflow-hidden rounded-lg bg-bg",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "wallpaper absolute inset-0" }),
					light ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-fg/80" }) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "relative z-10 flex h-10 w-full items-center justify-between px-4 text-xs text-fg",
						onClick: () => setFace((value) => value === "shade" ? "lock" : "shade"),
						"aria-label": face === "shade" ? "Tutup panel, buka layar kunci" : "Buka panel notifikasi",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium tabular-nums",
								children: clock
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute left-1/2 h-1.5 w-14 -translate-x-1/2 rounded-full bg-surface-3" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1",
								children: [
									statusIcons(shade).map((name) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "size-1.5 rounded-full bg-primary",
										title: name
									}, name)),
									dnd !== "off" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, {
										className: "size-3.5",
										"aria-label": "Jangan ganggu"
									}) : null,
									settings.mute ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, {
										className: "size-3.5",
										"aria-label": "Senyap"
									}) : null,
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wifi, {
										className: "size-3.5",
										"aria-hidden": "true"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Signal, {
										className: "size-3.5",
										"aria-hidden": "true"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BatteryMedium, {
										className: "size-4",
										"aria-hidden": "true"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "tabular-nums",
										children: saver ? settings.battery - 1 : settings.battery
									})
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative z-10 min-h-0 flex-1",
						children: [
							face === "lock" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex h-full flex-col px-4 pb-4 pt-6",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-center font-display text-5xl font-semibold tabular-nums text-fg",
										children: clock
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-center text-sm text-muted",
										children: now > 0 ? formatDate(now) : "Selasa"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-6 space-y-2 overflow-y-auto",
										children: shade.filter((item) => item.privacy !== "secret").length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "rounded-lg bg-surface/80 px-3 py-4 text-center text-sm text-muted",
											children: "Tidak ada yang ditampilkan di layar kunci."
										}) : shade.filter((item) => item.privacy !== "secret").map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => setFace("shade"),
											className: "flex w-full items-center gap-3 rounded-lg bg-surface/80 p-3 text-left",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppGlyph, {
												icon: item.icon,
												className: "size-8",
												lively: item.importance === "max"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "min-w-0",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "block text-xs text-muted",
													children: item.appName
												}), item.privacy === "private" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "block text-sm text-fg",
													children: "Konten sensitif disembunyikan"
												}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "block truncate text-sm font-semibold text-fg",
													children: item.title
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "block truncate text-xs text-muted",
													children: item.body
												})] })]
											})]
										}, item.id))
									})
								]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "shade-scrim flex h-full flex-col",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-3 gap-2 p-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
												on: dnd !== "off",
												icon: Moon,
												label: DND_LABEL[dnd],
												onClick: cycleDnd
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
												on: settings.mute,
												icon: VolumeX,
												label: settings.mute ? "Senyap" : "Suara",
												onClick: () => patchSettings({ mute: !settings.mute })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
												on: settings.vibrateDevice,
												icon: Vibrate,
												label: "Getar",
												onClick: () => patchSettings({ vibrateDevice: !settings.vibrateDevice })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
												on: light,
												icon: Flashlight,
												label: "Senter",
												onClick: () => setLight((value) => !value)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
												on: spin,
												icon: RotateCw,
												label: spin ? "Otomatis" : "Terkunci",
												onClick: () => setSpin((value) => !value)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
												on: saver,
												icon: BatteryMedium,
												label: "Hemat",
												onClick: () => setSaver((value) => !value)
											})
										]
									}),
									dnd !== "off" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "px-3 pb-2 text-center text-xs text-primary",
										children: [
											"Jangan ganggu ",
											DND_LABEL[dnd].toLowerCase(),
											settings.dnd === "off" && settings.dndScheduleOn ? " · dari jadwal" : ""
										]
									}) : null,
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-h-0 flex-1 space-y-3 overflow-y-auto px-3 pb-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
													className: "font-display text-sm font-semibold",
													children: "Notifikasi"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													onClick: clearShade,
													className: "min-h-11 px-2 text-xs font-semibold text-primary",
													children: "Bersihkan"
												})]
											}),
											alerting.length === 0 && silent.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "rounded-lg border border-line bg-surface/70 px-3 py-6 text-center text-sm text-muted",
												children: "Panel kosong. Buat notifikasi di studio, atau uji dalam 10 detik."
											}) : null,
											alerting.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "space-y-2",
												children: alerting.map(renderCard)
											}) : null,
											silent.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs font-semibold tracking-wide text-faint",
													children: "Diam"
												}), silent.map(renderCard)]
											}) : null
										]
									})
								]
							}),
							bannerItem && face === "shade" && alarm?.id !== bannerItem.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "drop-in absolute inset-x-2 top-2 z-20",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotifCard, {
									item: {
										...bannerItem,
										expanded: false
									},
									now,
									onToggle: () => toggleExpand(bannerItem.id),
									onDismiss: () => dismiss(bannerItem.id),
									onStop: () => stopOngoing(bannerItem.id),
									onAction: (label) => runAction(bannerItem.id, label)
								})
							}) : null,
							alarm && face === "shade" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "absolute inset-0 z-30 flex flex-col justify-end bg-bg/95 p-5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-semibold text-accent",
										children: "Alarm"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "mt-2 font-display text-4xl font-semibold text-fg",
										children: alarm.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm text-muted",
										children: alarm.body
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-6 grid gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "min-h-11 rounded-md bg-primary font-semibold text-primary-fg",
											onClick: () => snooze(alarm.id, 3e5, "5 menit"),
											children: "Tunda 5 menit"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "min-h-11 rounded-md bg-surface-3 font-semibold text-fg",
											onClick: () => stopOngoing(alarm.id),
											children: "Matikan"
										})]
									})
								]
							}) : null,
							flash ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "absolute inset-x-6 bottom-4 z-40 rounded-full bg-fg px-3 py-2 text-center text-xs font-semibold text-primary-fg",
								children: flash.text
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "relative z-10 flex h-5 items-center justify-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-1 w-24 rounded-full bg-fg/30" })
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2 px-1 pt-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-pressed": face === "shade",
					onClick: () => setFace("shade"),
					className: cn("min-h-11 rounded-md text-sm font-semibold", face === "shade" ? "bg-primary text-primary-fg" : "bg-surface-3 text-fg"),
					children: "Panel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-pressed": face === "lock",
					onClick: () => setFace("lock"),
					className: cn("min-h-11 rounded-md text-sm font-semibold", face === "lock" ? "bg-primary text-primary-fg" : "bg-surface-3 text-fg"),
					children: "Layar kunci"
				})]
			})]
		})
	});
}
function Tile({ on, icon: Icon, label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		"aria-pressed": on,
		onClick,
		className: cn("flex min-h-14 flex-col items-center justify-center gap-1 rounded-lg px-1 py-2 text-xs font-medium", on ? "bg-primary text-primary-fg" : "bg-surface-3 text-fg"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
			className: "size-4",
			"aria-hidden": "true"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "max-w-full truncate",
			children: label
		})]
	});
}
function SchedulePanel() {
	const schedules = useNotifStore((state) => state.schedules);
	const now = useNotifStore((state) => state.now);
	const channels = useNotifStore((state) => state.channels);
	const toggleSchedule = useNotifStore((state) => state.toggleSchedule);
	const removeSchedule = useNotifStore((state) => state.removeSchedule);
	const requestEdit = useNotifStore((state) => state.requestEdit);
	const ordered = [...schedules].sort((a, b) => Number(b.enabled) - Number(a.enabled) || a.fireAt - b.fireAt);
	if (ordered.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
		title: "Jadwal",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: "Belum ada jadwal. Di studio, pilih waktu lalu tekan Jadwalkan. Selama pratinjau terbuka, Lonceng akan memunculkannya sendiri."
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-3",
		children: ordered.map((item) => {
			const channel = channels.find((entry) => entry.id === item.channelId);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-lg border border-line bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppGlyph, {
						icon: item.icon,
						lively: item.importance === "high" || item.importance === "max"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted",
								children: [item.appName, channel ? ` · ${channel.name}` : ""]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "truncate font-display text-base font-semibold",
								children: item.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-sm text-muted",
								children: item.body
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-sm text-primary",
								children: [
									item.enabled ? now > 0 ? `${countdown(item.fireAt, now)} · ${formatWhen(item.fireAt)}` : "Menghitung…" : "Dimatikan",
									" · ",
									REPEAT_LABEL[item.repeat]
								]
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "secondary",
							onClick: () => requestEdit(item.id),
							children: "Ubah"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							onClick: () => toggleSchedule(item.id),
							children: item.enabled ? "Matikan" : "Aktifkan"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							onClick: () => removeSchedule(item.id),
							children: "Hapus"
						})
					]
				})]
			}, item.id);
		})
	});
}
function ChannelPanel() {
	const channels = useNotifStore((state) => state.channels);
	const addChannel = useNotifStore((state) => state.addChannel);
	const updateChannel = useNotifStore((state) => state.updateChannel);
	const removeChannel = useNotifStore((state) => state.removeChannel);
	const [name, setName] = (0, import_react.useState)("");
	const [importance, setImportance] = (0, import_react.useState)("default");
	const [bypass, setBypass] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
			title: "Saluran baru",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Nama",
						hint: "Seperti di pengaturan aplikasi Android: tiap saluran punya suara dan kepentingan sendiri.",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: name,
							onChange: (event) => setName(event.target.value),
							className: controlClass,
							maxLength: 32
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImportancePicker, {
						value: importance,
						onChange: setImportance
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
						checked: bypass,
						onChange: setBypass,
						label: "Tembus jangan ganggu"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => {
							if (!name.trim()) return;
							addChannel({
								name,
								description: "Saluran buatan.",
								importance,
								sound: importance !== "min" && importance !== "low",
								vibrate: importance !== "min" && importance !== "low",
								showBadge: importance !== "min",
								privacy: importance === "min" ? "secret" : "private",
								bypassDnd: bypass
							});
							setName("");
							setBypass(false);
						},
						children: "Tambah saluran"
					})
				]
			})
		}), channels.map((channel) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChannelCard, {
			channel,
			onChange: (patch) => updateChannel(channel.id, patch),
			onRemove: channel.system ? void 0 : () => removeChannel(channel.id)
		}, channel.id))]
	});
}
function ChannelCard({ channel, onChange, onRemove }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-lg border border-line bg-surface p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-display text-base font-semibold",
					children: channel.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: channel.description
				})] }), onRemove ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onRemove,
					className: "min-h-11 text-sm text-accent",
					children: "Hapus"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-faint",
					children: "Bawaan"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImportancePicker, {
					value: channel.importance,
					onChange: (importance) => onChange({ importance })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
						checked: channel.sound,
						onChange: (sound) => onChange({ sound }),
						label: "Suara"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
						checked: channel.vibrate,
						onChange: (vibrate) => onChange({ vibrate }),
						label: "Getar"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
						checked: channel.showBadge,
						onChange: (showBadge) => onChange({ showBadge }),
						label: "Lencana ikon"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
						checked: channel.bypassDnd,
						onChange: (bypassDnd) => onChange({ bypassDnd }),
						label: "Tembus jangan ganggu"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 grid grid-cols-3 gap-2",
				children: Object.keys(PRIVACY_LABEL).map((privacy) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-pressed": channel.privacy === privacy,
					onClick: () => onChange({ privacy }),
					className: cn("min-h-11 rounded-md px-1 text-xs", channel.privacy === privacy ? "bg-primary text-primary-fg" : "bg-surface-3 text-fg"),
					children: PRIVACY_LABEL[privacy]
				}, privacy))
			})
		]
	});
}
function ImportancePicker({ value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-5 gap-1",
		children: IMPORTANCE_ORDER.map((level) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-pressed": value === level,
			onClick: () => onChange(level),
			className: cn("min-h-11 rounded-md px-1 text-xs font-semibold", value === level ? "bg-primary text-primary-fg" : "bg-surface-3 text-fg"),
			children: IMPORTANCE_LABEL[level]
		}, level))
	});
}
function SettingsPanel() {
	const settings = useNotifStore((state) => state.settings);
	const patchSettings = useNotifStore((state) => state.patchSettings);
	const history = useNotifStore((state) => state.history);
	const now = useNotifStore((state) => state.now);
	const resetAll = useNotifStore((state) => state.resetAll);
	const [armed, setArmed] = (0, import_react.useState)(false);
	const [perm, setPerm] = (0, import_react.useState)("");
	async function enableBrowser() {
		try {
			if (typeof Notification === "undefined") {
				setPerm("Peramban ini tidak mendukung notifikasi perangkat.");
				return;
			}
			if (await Notification.requestPermission() === "granted") {
				patchSettings({ browserNotify: true });
				setPerm("Diizinkan. Notifikasi perangkat muncul selagi halaman ini terbuka.");
				return;
			}
			patchSettings({ browserNotify: false });
			setPerm("Izin ditolak. Panel di dalam telepon tetap berjalan.");
		} catch {
			setPerm("Pratinjau tidak mengizinkan notifikasi perangkat. Panel telepon tetap berjalan.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				title: "Jangan ganggu",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-2",
						children: Object.keys(DND_LABEL).map((mode) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-pressed": settings.dnd === mode,
							onClick: () => patchSettings({ dnd: mode }),
							className: cn("min-h-11 rounded-md px-2 text-sm", settings.dnd === mode ? "bg-primary text-primary-fg" : "bg-surface-3 text-fg"),
							children: DND_LABEL[mode]
						}, mode))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-xs text-muted",
						children: "Prioritas melewatkan yang tinggi dan mendesak. Alarm hanya mendesak. Total menutup semuanya, kecuali saluran alarm yang menembus."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: settings.dndScheduleOn,
							onChange: (dndScheduleOn) => patchSettings({ dndScheduleOn }),
							label: "Jadwal otomatis",
							hint: "Di luar mode manual, jendela ini memakai prioritas."
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Mulai",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "time",
								value: settings.dndStart,
								onChange: (event) => patchSettings({ dndStart: event.target.value }),
								className: controlClass
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Selesai",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "time",
								value: settings.dndEnd,
								onChange: (event) => patchSettings({ dndEnd: event.target.value }),
								className: controlClass
							})
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				title: "Perangkat",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
						checked: settings.mute,
						onChange: (mute) => patchSettings({ mute }),
						label: "Mode senyap",
						hint: "Mematikan nada di panel. Getar bisa tetap hidup."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
						checked: settings.vibrateDevice,
						onChange: (vibrateDevice) => patchSettings({ vibrateDevice }),
						label: "Getar perangkat"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
						checked: settings.browserNotify,
						onChange: (browserNotify) => {
							if (browserNotify) enableBrowser();
							else patchSettings({ browserNotify: false });
						},
						label: "Notifikasi perangkat",
						hint: "Muncul di sistem saat izin diberikan dan tab ini masih terbuka. Panel Android di samping selalu aktif di dalam aplikasi."
					}),
					perm ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs text-muted",
						children: perm
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "Riwayat",
				children: history.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Belum ada. Tampilkan atau jadwalkan notifikasi untuk mengisi riwayat."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-2",
					children: history.slice(0, 20).map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-start justify-between gap-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block truncate font-medium",
								children: entry.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "block truncate text-xs text-muted",
								children: [
									HISTORY_LABEL[entry.result],
									entry.note ? ` · ${entry.note}` : "",
									" · ",
									entry.appName
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "shrink-0 text-xs text-faint",
							children: ago(entry.at, now)
						})]
					}, entry.id))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				title: "Setel ulang",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 text-sm text-muted",
					children: "Mengembalikan saluran bawaan, contoh panel, dan menghapus jadwal di perangkat ini."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: armed ? "danger" : "ghost",
					onClick: () => {
						if (!armed) {
							setArmed(true);
							return;
						}
						resetAll();
						setArmed(false);
					},
					children: armed ? "Yakin, setel ulang" : "Setel ulang"
				})]
			})
		]
	});
}
var TABS = [
	{
		id: "studio",
		label: "Buat",
		icon: Bell
	},
	{
		id: "jadwal",
		label: "Jadwal",
		icon: CalendarClock
	},
	{
		id: "saluran",
		label: "Saluran",
		icon: Layers
	},
	{
		id: "atur",
		label: "Atur",
		icon: SlidersHorizontal
	},
	{
		id: "layar",
		label: "Layar",
		icon: Smartphone
	}
];
function Home() {
	useNotifEngine();
	const [tab, setTab] = (0, import_react.useState)("studio");
	const editNonce = useNotifStore((state) => state.editNonce);
	const flash = useNotifStore((state) => state.flash);
	const shadeCount = useNotifStore((state) => state.shade.length);
	const now = useNotifStore((state) => state.now);
	const next = useNotifStore((state) => state.schedules.filter((item) => item.enabled).slice().sort((a, b) => a.fireAt - b.fireAt)[0]);
	(0, import_react.useEffect)(() => {
		if (editNonce) setTab("studio");
	}, [editNonce]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto min-h-dvh w-full max-w-6xl px-4 pb-28 pt-6 lg:pb-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "sr-only",
				"aria-live": "polite",
				children: flash?.text ?? ""
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-start gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid size-12 shrink-0 place-items-center rounded-lg bg-primary text-primary-fg",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, {
						className: "size-6",
						"aria-hidden": "true"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold tracking-widest text-primary",
							children: "ANDROID"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-3xl font-semibold leading-none",
							children: "Lonceng"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 max-w-xl text-sm text-muted",
							children: "Susun notifikasi seperti di Android: saluran, prioritas, layar kunci, dan jam berapa ia muncul."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-faint",
							children: [
								shadeCount,
								" di panel",
								next && now > 0 ? ` · berikutnya ${next.title} dalam ${countdown(next.fireAt, now)}` : ""
							]
						}),
						flash ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm font-semibold text-primary",
							children: flash.text
						}) : null
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid items-start gap-6 lg:grid-cols-[minmax(0,1fr)_auto]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "fixed inset-x-0 bottom-0 z-30 border-t border-line bg-surface px-2 py-2 lg:static lg:border-0 lg:bg-transparent lg:p-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mx-auto grid max-w-lg grid-cols-5 gap-1 lg:flex lg:max-w-none",
							children: TABS.map((item) => {
								const Icon = item.icon;
								const active = tab === item.id;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									"aria-current": active ? "page" : void 0,
									onClick: () => setTab(item.id),
									className: cn("flex min-h-11 flex-col items-center justify-center gap-0.5 rounded-md px-1 text-xs font-semibold lg:flex-row lg:gap-2 lg:px-3", active ? "bg-primary text-primary-fg" : "text-muted", item.id === "layar" && "lg:hidden"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
										className: "size-4",
										"aria-hidden": "true"
									}), item.label]
								}, item.id);
							})
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4",
						children: [
							tab === "studio" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Composer, {}) : null,
							tab === "jadwal" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SchedulePanel, {}) : null,
							tab === "saluran" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChannelPanel, {}) : null,
							tab === "atur" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsPanel, {}) : null,
							tab === "layar" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "lg:hidden",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {})
							}) : null,
							tab === "layar" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "hidden text-sm text-muted lg:block",
								children: "Telepon ada di samping. Ketuk jam di bilah status untuk berganti layar kunci dan panel."
							}) : null
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
					className: "sticky top-4 hidden lg:block",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {})
				})]
			})
		]
	});
}
//#endregion
export { Home as component };
