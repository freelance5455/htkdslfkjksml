import { i as __toESM } from "../_runtime.mjs";
import { y as require_jsx_runtime, z as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as Delete, a as Star, c as Plus, d as PhoneOff, f as PhoneMissed, g as Grid3x3, h as MicOff, l as Phone, m as Mic, n as Volume2, o as Settings2, p as PhoneIncoming, r as Users, s as Search, t as VolumeX, u as PhoneOutgoing, v as Clock3, y as AudioLines } from "../_libs/lucide-react.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { i as fallbackMissed, n as buildSummaryPrompt, o as greetingFor, r as buildSystemPrompt, s as wrapUpLine, t as SAMPLE_CALLER_LINES } from "./prompts-DWlqwQ_V.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as isToday, r as format, t as isYesterday } from "../_libs/date-fns.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CW-yV3eO.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function formatDuration(totalSec) {
	const sec = Math.max(0, Math.floor(totalSec));
	const m = Math.floor(sec / 60);
	const s = sec % 60;
	if (m >= 60) {
		const h = Math.floor(m / 60);
		const rm = m % 60;
		return `${h}:${String(rm).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
	}
	return `${m}:${String(s).padStart(2, "0")}`;
}
function formatDurationLabel(totalSec) {
	const sec = Math.max(0, Math.floor(totalSec));
	if (sec < 60) return `${sec} sec`;
	const m = Math.round(sec / 60);
	return m === 1 ? "1 minute" : `${m} minutes`;
}
function formatCallWhen(ts) {
	const d = new Date(ts);
	if (isToday(d)) return format(d, "h:mm a");
	if (isYesterday(d)) return "Yesterday";
	return format(d, "d MMM");
}
function formatFullWhen(ts) {
	return format(new Date(ts), "d MMM yyyy · h:mm a");
}
function dayGroupLabel(ts) {
	const d = new Date(ts);
	if (isToday(d)) return "Today";
	if (isYesterday(d)) return "Yesterday";
	return format(d, "EEEE, d MMM");
}
function initials(name) {
	const parts = name.trim().split(/\s+/).filter(Boolean);
	if (parts.length === 0) return "?";
	if (parts[0] === "Unknown") return "?";
	if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
	return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}
function newId() {
	if (typeof crypto !== "undefined" && crypto.randomUUID) return crypto.randomUUID();
	return `id_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}
function Avatar({ name, size = "md" }) {
	const unknown = !name || name === "Unknown";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("grid shrink-0 place-items-center rounded-full bg-muted font-medium text-accent", size === "sm" && "size-9 text-xs", size === "md" && "size-11 text-sm", size === "lg" && "size-16 text-lg", size === "xl" && "size-24 text-2xl"),
		"aria-hidden": true,
		children: unknown ? "?" : initials(name)
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 font-medium transition-transform duration-150 ease-out select-none focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/70 disabled:pointer-events-none disabled:opacity-40 active:scale-[0.98]", {
	variants: {
		variant: {
			primary: "bg-accent text-accent-foreground",
			ghost: "bg-transparent text-foreground hover:bg-muted",
			muted: "bg-muted text-foreground",
			outline: "border border-border bg-transparent text-foreground",
			danger: "bg-destructive text-destructive-foreground",
			success: "bg-success text-success-foreground",
			dark: "bg-foreground text-background"
		},
		size: {
			sm: "h-9 rounded-sm px-3 text-sm",
			md: "h-11 rounded-md px-4 text-sm",
			lg: "h-12 rounded-lg px-5 text-[0.9375rem]",
			xl: "h-14 rounded-lg px-6 text-base",
			icon: "size-11 rounded-full",
			pill: "h-10 rounded-full px-4 text-sm"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
function Button({ className, variant, size, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
var EMERGENCY = /* @__PURE__ */ new Set([
	"911",
	"112",
	"999",
	"000",
	"100",
	"101",
	"102",
	"108",
	"1091",
	"190",
	"110"
]);
function digitsOnly(value) {
	return value.replace(/\D/g, "");
}
function normalizeNumber(value) {
	const trimmed = value.trim();
	if (!trimmed) return "";
	const plus = trimmed.startsWith("+");
	const digits = digitsOnly(trimmed);
	return plus ? `+${digits}` : digits;
}
function last10(value) {
	return digitsOnly(value).slice(-10);
}
function numbersMatch(a, b) {
	const da = digitsOnly(a);
	const db = digitsOnly(b);
	if (!da || !db) return false;
	if (da === db) return true;
	return last10(da) === last10(db) && last10(da).length >= 7;
}
function isEmergencyNumber(value) {
	const d = digitsOnly(value);
	if (!d) return false;
	if (EMERGENCY.has(d)) return true;
	if (d.startsWith("911") && d.length <= 4) return true;
	return false;
}
function formatPhone(value) {
	const n = value.trim();
	if (!n) return "";
	const d = digitsOnly(n);
	if (n.startsWith("+91") && d.length === 12) return `+91 ${d.slice(2, 7)} ${d.slice(7)}`;
	if (n.startsWith("+") && d.length > 4) return `+${d.slice(0, d.length - 10)} ${d.slice(-10, -5)} ${d.slice(-5)}`.replace(/\s+/g, " ");
	if (d.length === 10) return `${d.slice(0, 5)} ${d.slice(5)}`;
	return n;
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var getAiStatus = createServerFn({ method: "POST" }).handler(createSsrRpc("c2b71ab994a8d1ee84d621e29674fed647d9ace14433d69cc4015ed6da34eb4c"));
var converseWithLisa = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("0a03cbdef44ff1a18d34c724b14dc805e664ee1c48f88a8111cf926649ab20fd"));
var summarizeCall = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("fbc3d15f5d1d2ae184a76bddd4279c84e115fcb1717e55cd77593a92919fbe6a"));
var speakLisa = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("5b218b4c6adcf0c3ffa8a44d0e88e5b3e0f8257af1d928981aa1604b2a54d693"));
var day = 864e5;
function atHoursAgo(h) {
	return Date.now() - h * 60 * 60 * 1e3;
}
var seedContacts = [
	{
		id: "c-rahul",
		name: "Rahul",
		number: "+919876543210",
		company: "Delivery",
		policy: "lisa_may",
		favorite: true
	},
	{
		id: "c-john",
		name: "John",
		number: "+919123456789",
		policy: "lisa_may",
		favorite: true
	},
	{
		id: "c-priya",
		name: "Priya Sharma",
		number: "+919988776655",
		company: "Family",
		policy: "always_myself",
		favorite: true
	},
	{
		id: "c-mehta",
		name: "Dr. Mehta",
		number: "+918800112233",
		company: "Clinic",
		policy: "never_lisa"
	},
	{
		id: "c-office",
		name: "Office Front Desk",
		number: "+912240001200",
		company: "Work",
		policy: "lisa_may"
	},
	{
		id: "c-amira",
		name: "Amira Khan",
		number: "+917738849901",
		policy: "lisa_may"
	}
];
var seedCalls = [
	{
		id: "call-delivery",
		contactId: "c-rahul",
		name: "Rahul",
		number: "+919876543210",
		direction: "incoming",
		handler: "lisa",
		startedAt: atHoursAgo(5),
		endedAt: atHoursAgo(5) + 247e3,
		durationSec: 247,
		summaryId: "sum-delivery",
		hasMessage: false
	},
	{
		id: "call-appt",
		contactId: "c-office",
		name: "Office Front Desk",
		number: "+912240001200",
		direction: "incoming",
		handler: "lisa",
		startedAt: atHoursAgo(26),
		endedAt: atHoursAgo(26) + 188e3,
		durationSec: 188,
		summaryId: "sum-appt",
		hasMessage: true,
		important: true
	},
	{
		id: "call-priya",
		contactId: "c-priya",
		name: "Priya Sharma",
		number: "+919988776655",
		direction: "incoming",
		handler: "user",
		startedAt: atHoursAgo(8),
		endedAt: atHoursAgo(8) + 734e3,
		durationSec: 734
	},
	{
		id: "call-missed",
		name: "Unknown",
		number: "+917000011122",
		direction: "missed",
		handler: "user",
		startedAt: atHoursAgo(2),
		durationSec: 0
	},
	{
		id: "call-out",
		contactId: "c-john",
		name: "John",
		number: "+919123456789",
		direction: "outgoing",
		handler: "user",
		startedAt: atHoursAgo(30),
		endedAt: atHoursAgo(30) + 381e3,
		durationSec: 381
	},
	{
		id: "call-old",
		contactId: "c-amira",
		name: "Amira Khan",
		number: "+917738849901",
		direction: "incoming",
		handler: "lisa",
		startedAt: Date.now() - 3 * day,
		endedAt: Date.now() - 3 * day + 121e3,
		durationSec: 121,
		summaryId: "sum-amira",
		hasMessage: true
	}
];
var seedSummaries = [
	{
		id: "sum-delivery",
		callId: "call-delivery",
		caller: "Rahul",
		number: "+919876543210",
		durationLabel: "4 minutes",
		reason: "Delivery update",
		summary: "Rahul called to say the delivery is expected tomorrow afternoon.",
		importantInfo: "Delivery arriving tomorrow afternoon.",
		urgency: "normal",
		message: "No additional message.",
		people: ["Rahul", "ANZ"],
		dates: ["tomorrow"],
		times: ["afternoon"],
		locations: [],
		requests: [],
		promises: ["Delivery expected tomorrow afternoon"],
		createdAt: atHoursAgo(5)
	},
	{
		id: "sum-appt",
		callId: "call-appt",
		caller: "Office Front Desk",
		number: "+912240001200",
		durationLabel: "3 minutes",
		reason: "Appointment changed",
		summary: "The office called to move ANZ’s appointment from Monday to Wednesday at 4 PM.",
		importantInfo: "New appointment: Wednesday at 4 PM.",
		urgency: "high",
		message: "Please confirm the Wednesday 4 PM slot.",
		people: ["ANZ"],
		dates: ["Wednesday"],
		times: ["4 PM"],
		locations: [],
		requests: ["Confirm the new appointment time"],
		promises: [],
		createdAt: atHoursAgo(26)
	},
	{
		id: "sum-amira",
		callId: "call-old",
		caller: "Amira Khan",
		number: "+917738849901",
		durationLabel: "2 minutes",
		reason: "Callback request",
		summary: "Amira asked ANZ to call her back this evening.",
		importantInfo: "Wants a callback tonight.",
		urgency: "normal",
		message: "Please call Amira back tonight.",
		people: ["Amira Khan"],
		dates: [],
		times: ["tonight"],
		locations: [],
		requests: ["Call back tonight"],
		promises: [],
		createdAt: Date.now() - 3 * day
	}
];
var seedMessages = [{
	id: "msg-appt",
	callId: "call-appt",
	caller: "Office Front Desk",
	number: "+912240001200",
	text: "Please confirm the Wednesday 4 PM appointment.",
	at: atHoursAgo(26)
}, {
	id: "msg-amira",
	callId: "call-old",
	caller: "Amira Khan",
	number: "+917738849901",
	text: "Please call Amira back tonight.",
	at: Date.now() - 3 * day
}];
var defaultSettings = {
	ownerName: "ANZ",
	confirmBeforeLisaHandles: true,
	unknownCallers: "ask",
	knownContacts: "ask",
	aiProvider: "xai",
	voiceId: "luna",
	speakingSpeed: 1,
	personality: "professional",
	maxAiCallMinutes: 5,
	saveTranscripts: false,
	saveSummaries: true,
	saveRecordings: false,
	autoDeleteDays: 30,
	lisaIntegrationEnabled: false,
	syncSummaries: true
};
function modeAllows(mode) {
	if (mode === "never") return {
		allowed: false,
		auto: false
	};
	if (mode === "allow") return {
		allowed: true,
		auto: true
	};
	return {
		allowed: true,
		auto: false
	};
}
var useAppStore = create()(persist((set, get) => ({
	tab: "keypad",
	overlay: { kind: "none" },
	settings: defaultSettings,
	contacts: seedContacts,
	calls: seedCalls,
	summaries: seedSummaries,
	transcripts: [],
	messages: seedMessages,
	events: [],
	live: null,
	search: "",
	hydrated: false,
	setTab: (tab) => set({
		tab,
		overlay: { kind: "none" }
	}),
	setOverlay: (overlay) => set({ overlay }),
	setSearch: (search) => set({ search }),
	updateSettings: (patch) => set((s) => ({ settings: {
		...s.settings,
		...patch
	} })),
	addContact: (c) => {
		const id = c.id ?? newId();
		const contact = {
			id,
			name: c.name.trim() || "No name",
			number: normalizeNumber(c.number),
			company: c.company,
			policy: c.policy ?? "lisa_may",
			favorite: c.favorite
		};
		set((s) => ({ contacts: [contact, ...s.contacts] }));
		return id;
	},
	updateContact: (id, patch) => set((s) => ({ contacts: s.contacts.map((c) => c.id === id ? {
		...c,
		...patch
	} : c) })),
	deleteContact: (id) => set((s) => ({ contacts: s.contacts.filter((c) => c.id !== id) })),
	resolveCaller: (number) => {
		const n = normalizeNumber(number);
		const contact = get().contacts.find((c) => numbersMatch(c.number, n));
		if (contact) return {
			contact,
			name: contact.name,
			known: true
		};
		return {
			name: "Unknown",
			known: false
		};
	},
	decideLisaAccess: ({ number, known, policy }) => {
		if (isEmergencyNumber(number)) return {
			allowed: false,
			auto: false
		};
		if (policy === "always_myself" || policy === "never_lisa") return {
			allowed: false,
			auto: false
		};
		const mode = known ? get().settings.knownContacts : get().settings.unknownCallers;
		const base = modeAllows(mode);
		if (policy === "lisa_may" && known && mode === "never") return {
			allowed: false,
			auto: false
		};
		if (get().settings.confirmBeforeLisaHandles) return {
			allowed: base.allowed,
			auto: false
		};
		return base;
	},
	ringIncoming: ({ number, name, contactId }) => {
		const resolved = get().resolveCaller(number);
		const contact = contactId ? get().contacts.find((c) => c.id === contactId) ?? resolved.contact : resolved.contact;
		const display = name || contact?.name || resolved.name;
		const known = Boolean(contact);
		const emergency = isEmergencyNumber(number);
		const live = {
			id: newId(),
			status: "ringing",
			direction: "incoming",
			name: display,
			number: normalizeNumber(number),
			contactId: contact?.id,
			known,
			startedAt: Date.now(),
			muted: false,
			speaker: true,
			lisaStatus: "idle",
			turns: [],
			livePartial: "",
			emergency
		};
		const access = get().decideLisaAccess({
			number,
			known,
			policy: contact?.policy
		});
		get().pushEvent("call_started", {
			name: display,
			number: live.number,
			direction: "incoming"
		});
		if (!emergency && access.auto && access.allowed) {
			live.status = "lisa";
			live.connectedAt = Date.now();
			live.lisaStatus = "speaking";
			set({
				live,
				overlay: { kind: "active" }
			});
			get().pushEvent("lisa_handling", {
				name: display,
				number: live.number
			});
			return;
		}
		set({
			live,
			overlay: { kind: "incoming" }
		});
	},
	rejectIncoming: () => {
		const live = get().live;
		if (!live || live.status !== "ringing") return;
		const rec = {
			id: live.id,
			contactId: live.contactId,
			name: live.name,
			number: live.number,
			direction: "missed",
			handler: "user",
			startedAt: live.startedAt,
			endedAt: Date.now(),
			durationSec: 0,
			emergency: live.emergency
		};
		set((s) => ({
			live: null,
			overlay: { kind: "none" },
			calls: [rec, ...s.calls]
		}));
		get().pushEvent("call_ended", {
			name: live.name,
			result: "rejected"
		});
	},
	answerIncoming: () => {
		const live = get().live;
		if (!live || live.status !== "ringing") return;
		set({
			live: {
				...live,
				status: "active",
				connectedAt: Date.now()
			},
			overlay: { kind: "active" }
		});
	},
	lisaHandleIncoming: () => {
		const live = get().live;
		if (!live || live.status !== "ringing" && live.status !== "active") return;
		if (live.emergency) return;
		if (!get().decideLisaAccess({
			number: live.number,
			known: live.known,
			policy: get().contacts.find((c) => c.id === live.contactId)?.policy
		}).allowed) return;
		set({
			live: {
				...live,
				status: "lisa",
				connectedAt: live.connectedAt ?? Date.now(),
				lisaStatus: "speaking"
			},
			overlay: { kind: "active" }
		});
		get().pushEvent("lisa_handling", {
			name: live.name,
			number: live.number
		});
	},
	placeOutgoing: (number) => {
		const n = normalizeNumber(number);
		if (!n) return;
		const resolved = get().resolveCaller(n);
		const emergency = isEmergencyNumber(n);
		const live = {
			id: newId(),
			status: "active",
			direction: "outgoing",
			name: resolved.name === "Unknown" ? n : resolved.name,
			number: n,
			contactId: resolved.contact?.id,
			known: resolved.known,
			startedAt: Date.now(),
			connectedAt: Date.now(),
			muted: false,
			speaker: true,
			lisaStatus: "idle",
			turns: [],
			livePartial: "",
			emergency
		};
		set({
			live,
			overlay: { kind: "active" }
		});
		get().pushEvent("call_started", {
			name: live.name,
			number: n,
			direction: "outgoing"
		});
	},
	endCall: () => {
		const live = get().live;
		if (!live) return null;
		const endedAt = Date.now();
		const start = live.connectedAt ?? live.startedAt;
		const durationSec = live.status === "ringing" ? 0 : Math.max(0, Math.round((endedAt - start) / 1e3));
		const direction = live.status === "ringing" && live.direction === "incoming" ? "missed" : live.direction;
		const rec = {
			id: live.id,
			contactId: live.contactId,
			name: live.name,
			number: live.number,
			direction,
			handler: live.status === "lisa" ? "lisa" : "user",
			startedAt: live.startedAt,
			endedAt,
			durationSec,
			emergency: live.emergency,
			important: live.emergency
		};
		set((s) => ({
			live: null,
			overlay: { kind: "none" },
			calls: [rec, ...s.calls.filter((c) => c.id !== rec.id)]
		}));
		get().pushEvent("call_ended", {
			name: rec.name,
			handler: rec.handler,
			duration: String(durationSec)
		});
		return rec;
	},
	takeOver: () => {
		const live = get().live;
		if (!live || live.status !== "lisa") return;
		set({ live: {
			...live,
			status: "active",
			lisaStatus: "idle",
			livePartial: ""
		} });
	},
	toggleMute: () => {
		const live = get().live;
		if (!live) return;
		set({ live: {
			...live,
			muted: !live.muted
		} });
	},
	toggleSpeaker: () => {
		const live = get().live;
		if (!live) return;
		set({ live: {
			...live,
			speaker: !live.speaker
		} });
	},
	setLisaStatus: (lisaStatus) => {
		const live = get().live;
		if (!live) return;
		set({ live: {
			...live,
			lisaStatus
		} });
	},
	addTurn: (turn) => {
		const live = get().live;
		if (!live) return;
		set({ live: {
			...live,
			turns: [...live.turns, turn],
			livePartial: ""
		} });
	},
	setLivePartial: (livePartial) => {
		const live = get().live;
		if (!live) return;
		set({ live: {
			...live,
			livePartial
		} });
	},
	persistTranscriptIfEnabled: (callId, turns) => {
		if (!get().settings.saveTranscripts) return;
		if (turns.length === 0) return;
		const t = {
			id: newId(),
			callId,
			turns
		};
		set((s) => ({ transcripts: [t, ...s.transcripts.filter((x) => x.callId !== callId)] }));
	},
	saveSummary: (summary) => {
		if (!get().settings.saveSummaries) return;
		set((s) => ({
			summaries: [summary, ...s.summaries.filter((x) => x.callId !== summary.callId)],
			calls: s.calls.map((c) => c.id === summary.callId ? {
				...c,
				summaryId: summary.id,
				hasMessage: summary.message !== "No additional message.",
				important: c.important || summary.urgency === "high" || summary.urgency === "emergency"
			} : c)
		}));
		get().pushEvent("summary_created", {
			caller: summary.caller,
			reason: summary.reason
		});
	},
	saveMessage: (msg) => {
		set((s) => ({
			messages: [msg, ...s.messages],
			calls: s.calls.map((c) => c.id === msg.callId ? {
				...c,
				hasMessage: true
			} : c)
		}));
		get().pushEvent("message_taken", {
			caller: msg.caller,
			text: msg.text
		});
	},
	markImportant: (callId, important) => set((s) => ({ calls: s.calls.map((c) => c.id === callId ? {
		...c,
		important
	} : c) })),
	deleteAllAiData: () => set((s) => ({
		summaries: [],
		transcripts: [],
		messages: [],
		calls: s.calls.map((c) => ({
			...c,
			summaryId: void 0,
			hasMessage: false
		}))
	})),
	pruneExpired: () => {
		const days = get().settings.autoDeleteDays;
		if (!days) return;
		const cutoff = Date.now() - days * 24 * 60 * 60 * 1e3;
		set((s) => {
			const summaries = s.summaries.filter((x) => x.createdAt >= cutoff);
			const keepSummary = new Set(summaries.map((x) => x.id));
			return {
				summaries,
				transcripts: s.transcripts.filter((t) => {
					return (s.calls.find((c) => c.id === t.callId)?.startedAt ?? 0) >= cutoff;
				}),
				messages: s.messages.filter((m) => m.at >= cutoff),
				calls: s.calls.map((c) => c.summaryId && !keepSummary.has(c.summaryId) ? {
					...c,
					summaryId: void 0
				} : c)
			};
		});
	},
	pushEvent: (type, payload) => {
		if (!get().settings.lisaIntegrationEnabled) return;
		const ev = {
			id: newId(),
			type,
			at: Date.now(),
			payload
		};
		set((s) => ({ events: [ev, ...s.events].slice(0, 40) }));
	}
}), {
	name: "lisa-call-v1",
	partialize: (s) => ({
		tab: s.tab,
		settings: s.settings,
		contacts: s.contacts,
		calls: s.calls,
		summaries: s.summaries,
		transcripts: s.transcripts,
		messages: s.messages,
		events: s.events
	}),
	onRehydrateStorage: () => (state) => {
		state?.pruneExpired();
	}
}));
function getRecognitionCtor() {
	if (typeof window === "undefined") return null;
	const w = window;
	return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null;
}
function pickFemaleVoice() {
	if (typeof window === "undefined" || !window.speechSynthesis) return null;
	const voices = window.speechSynthesis.getVoices();
	return voices.find((v) => /female|samantha|victoria|karen|zira|google uk english female/i.test(v.name)) ?? voices.find((v) => v.lang.startsWith("en")) ?? voices[0] ?? null;
}
function isEcho(heard, lastLisa) {
	const a = heard.toLowerCase().replace(/[^\w\s]/g, "").trim();
	const b = lastLisa.toLowerCase().replace(/[^\w\s]/g, "").trim();
	if (!a || a.length < 6) return false;
	if (!b) return false;
	if (b.includes(a) && a.split(" ").length <= 8) return true;
	const words = a.split(/\s+/);
	return words.filter((w) => w.length > 3 && b.includes(w)).length >= Math.max(3, Math.ceil(words.length * .7));
}
var greetedCalls = /* @__PURE__ */ new Set();
function useLisaSession() {
	const live = useAppStore((s) => s.live);
	const settings = useAppStore((s) => s.settings);
	const addTurn = useAppStore((s) => s.addTurn);
	const setLisaStatus = useAppStore((s) => s.setLisaStatus);
	const setLivePartial = useAppStore((s) => s.setLivePartial);
	const persistTranscriptIfEnabled = useAppStore((s) => s.persistTranscriptIfEnabled);
	const saveSummary = useAppStore((s) => s.saveSummary);
	const saveMessage = useAppStore((s) => s.saveMessage);
	const endCall = useAppStore((s) => s.endCall);
	const [micSupported, setMicSupported] = (0, import_react.useState)(false);
	const [micError, setMicError] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const busyRef = (0, import_react.useRef)(false);
	const audioRef = (0, import_react.useRef)(null);
	const recogRef = (0, import_react.useRef)(null);
	const wantListen = (0, import_react.useRef)(false);
	const speakingRef = (0, import_react.useRef)(false);
	const lastLisaRef = (0, import_react.useRef)("");
	const abortSpeak = (0, import_react.useRef)(() => {});
	const wrapping = (0, import_react.useRef)(false);
	const liveRef = (0, import_react.useRef)(live);
	liveRef.current = live;
	const stopAudio = (0, import_react.useCallback)(() => {
		abortSpeak.current();
		audioRef.current?.pause();
		audioRef.current = null;
		if (typeof window !== "undefined") window.speechSynthesis?.cancel();
		speakingRef.current = false;
	}, []);
	const stopRecog = (0, import_react.useCallback)(() => {
		wantListen.current = false;
		try {
			recogRef.current?.abort();
		} catch {}
	}, []);
	const stopAll = (0, import_react.useCallback)(() => {
		stopRecog();
		stopAudio();
	}, [stopAudio, stopRecog]);
	const browserSpeak = (0, import_react.useCallback)((text, speed, onDone) => {
		if (typeof window === "undefined" || !window.speechSynthesis) {
			onDone();
			return;
		}
		const u = new SpeechSynthesisUtterance(text);
		u.rate = speed;
		u.pitch = 1.05;
		const voice = pickFemaleVoice();
		if (voice) u.voice = voice;
		u.onend = onDone;
		u.onerror = onDone;
		window.speechSynthesis.speak(u);
	}, []);
	const speak = (0, import_react.useCallback)(async (text) => {
		speakingRef.current = true;
		lastLisaRef.current = text;
		setLisaStatus("speaking");
		const speed = Math.min(1.2, Math.max(.8, settings.speakingSpeed));
		await new Promise((resolve) => {
			let settled = false;
			const done = () => {
				if (settled) return;
				settled = true;
				speakingRef.current = false;
				resolve();
			};
			abortSpeak.current = () => {
				audioRef.current?.pause();
				audioRef.current = null;
				window.speechSynthesis?.cancel();
				done();
			};
			(async () => {
				const cloud = await speakLisa({ data: {
					text,
					voiceId: settings.voiceId
				} });
				if (cloud.ok) {
					const audio = new Audio(`data:${cloud.mime};base64,${cloud.audio}`);
					audio.playbackRate = speed;
					audioRef.current = audio;
					audio.onended = done;
					audio.onerror = () => browserSpeak(text, speed, done);
					try {
						await audio.play();
					} catch {
						browserSpeak(text, speed, done);
					}
				} else browserSpeak(text, speed, done);
			})();
		});
	}, [
		browserSpeak,
		setLisaStatus,
		settings.speakingSpeed,
		settings.voiceId
	]);
	const finalizeLisa = (0, import_react.useCallback)(async (snap, rec) => {
		persistTranscriptIfEnabled(rec.id, snap.turns);
		const durationLabel = formatDurationLabel(rec.durationSec);
		const callerTurns = snap.turns.filter((t) => t.role === "caller");
		let summary;
		if (callerTurns.length === 0) summary = {
			id: newId(),
			callId: rec.id,
			caller: snap.name,
			number: snap.number,
			durationLabel,
			reason: "No conversation",
			summary: "The call ended before the caller said anything Lisa could record.",
			importantInfo: "None noted.",
			urgency: "low",
			message: "No additional message.",
			people: [],
			dates: [],
			times: [],
			locations: [],
			requests: [],
			promises: [],
			createdAt: Date.now()
		};
		else {
			const result = await summarizeCall({ data: {
				prompt: buildSummaryPrompt({
					ownerName: settings.ownerName,
					callerName: snap.name,
					callerNumber: snap.number,
					durationLabel,
					turns: snap.turns
				}),
				durationLabel,
				callerName: snap.name,
				callerNumber: snap.number
			} });
			const base = result.ok ? result.summary : {
				reason: "Conversation",
				summary: `${snap.name} called. A detailed summary could not be generated.`,
				importantInfo: "None noted.",
				urgency: "normal",
				message: "No additional message.",
				people: [],
				dates: [],
				times: [],
				locations: [],
				requests: [],
				promises: []
			};
			summary = {
				id: newId(),
				callId: rec.id,
				caller: snap.name,
				number: snap.number,
				durationLabel,
				...base,
				createdAt: Date.now()
			};
		}
		saveSummary(summary);
		if (summary.message && summary.message !== "No additional message.") saveMessage({
			id: newId(),
			callId: rec.id,
			caller: snap.name,
			number: snap.number,
			text: summary.message,
			at: Date.now()
		});
		return summary;
	}, [
		persistTranscriptIfEnabled,
		saveMessage,
		saveSummary,
		settings.ownerName
	]);
	const hangUpLisa = (0, import_react.useCallback)(async () => {
		stopAll();
		const snap = useAppStore.getState().live;
		const rec = endCall();
		if (snap && rec && rec.handler === "lisa") {
			await finalizeLisa(snap, rec);
			useAppStore.getState().setOverlay({
				kind: "call-detail",
				callId: rec.id
			});
		}
	}, [
		endCall,
		finalizeLisa,
		stopAll
	]);
	const submitCallerText = (0, import_react.useCallback)(async (raw) => {
		const text = raw.trim();
		if (!text) return;
		const current = useAppStore.getState().live;
		if (!current || current.status !== "lisa" || busyRef.current) return;
		if (isEcho(text, lastLisaRef.current)) return;
		if (speakingRef.current) stopAudio();
		addTurn({
			role: "caller",
			text,
			at: Date.now()
		});
		busyRef.current = true;
		setBusy(true);
		setLisaStatus("thinking");
		if (Date.now() - (current.connectedAt ?? current.startedAt) > settings.maxAiCallMinutes * 60 * 1e3 && !wrapping.current) {
			wrapping.current = true;
			const line = wrapUpLine(settings.ownerName);
			addTurn({
				role: "lisa",
				text: line,
				at: Date.now()
			});
			await speak(line);
			busyRef.current = false;
			setBusy(false);
			await hangUpLisa();
			return;
		}
		const latest = useAppStore.getState().live;
		const result = await converseWithLisa({ data: {
			system: buildSystemPrompt({
				settings,
				callerName: current.name,
				callerNumber: current.number,
				known: current.known
			}),
			turns: latest?.turns ?? current.turns,
			callerText: text
		} });
		const still = useAppStore.getState().live;
		if (!still || still.id !== current.id || still.status !== "lisa") {
			busyRef.current = false;
			setBusy(false);
			return;
		}
		addTurn({
			role: "lisa",
			text: result.data.reply,
			at: Date.now()
		});
		if (result.data.extracted.message) saveMessage({
			id: newId(),
			callId: current.id,
			caller: current.name,
			number: current.number,
			text: result.data.extracted.message,
			at: Date.now()
		});
		await speak(result.data.reply);
		busyRef.current = false;
		setBusy(false);
		if (result.data.shouldEndCall || result.data.extracted.urgency === "emergency") {
			await hangUpLisa();
			return;
		}
		setLisaStatus("listening");
	}, [
		addTurn,
		hangUpLisa,
		saveMessage,
		setLisaStatus,
		settings,
		speak,
		stopAudio
	]);
	const startListening = (0, import_react.useCallback)(async () => {
		const Ctor = getRecognitionCtor();
		if (!Ctor) {
			setMicSupported(false);
			return;
		}
		setMicSupported(true);
		wantListen.current = true;
		setLisaStatus("listening");
		try {
			const rec = new Ctor();
			rec.continuous = true;
			rec.interimResults = true;
			rec.lang = "en-US";
			rec.onresult = (ev) => {
				let interim = "";
				let finalText = "";
				for (let i = ev.resultIndex; i < ev.results.length; i++) {
					const piece = ev.results[i];
					if (!piece) continue;
					if (piece.isFinal) finalText += piece[0].transcript;
					else interim += piece[0].transcript;
				}
				if (interim) setLivePartial(interim);
				const heard = finalText.trim();
				if (!heard) return;
				if (speakingRef.current) {
					if (!isEcho(heard, lastLisaRef.current)) stopAudio();
					else return;
				}
				submitCallerText(heard);
			};
			rec.onerror = (ev) => {
				if (ev.error === "not-allowed") setMicError("Microphone permission denied. Type as the caller instead.");
				else if (ev.error !== "aborted" && ev.error !== "no-speech") setMicError("Sorry, I didn't catch that.");
			};
			rec.onend = () => {
				if (wantListen.current && liveRef.current?.status === "lisa") try {
					rec.start();
				} catch {}
			};
			recogRef.current = rec;
			rec.start();
		} catch {
			setMicError("Microphone is unavailable. Type as the caller instead.");
		}
	}, [
		setLisaStatus,
		setLivePartial,
		stopAudio,
		submitCallerText
	]);
	(0, import_react.useEffect)(() => {
		setMicSupported(Boolean(getRecognitionCtor()));
	}, []);
	(0, import_react.useEffect)(() => {
		if (!live || live.status !== "lisa") {
			stopAll();
			return;
		}
		if (greetedCalls.has(live.id)) return;
		greetedCalls.add(live.id);
		wrapping.current = false;
		const line = greetingFor({
			ownerName: settings.ownerName,
			known: live.known,
			callerName: live.name,
			personality: settings.personality
		});
		addTurn({
			role: "lisa",
			text: line,
			at: Date.now()
		});
		(async () => {
			await speak(line);
			const still = useAppStore.getState().live;
			if (still?.id === live.id && still.status === "lisa") await startListening();
		})();
	}, [
		addTurn,
		live?.id,
		live?.status,
		settings.ownerName,
		settings.personality,
		speak,
		startListening,
		stopAll
	]);
	(0, import_react.useEffect)(() => () => stopAll(), [stopAll]);
	return {
		micSupported,
		micError,
		busy,
		submitCallerText,
		startListening,
		stopAll,
		hangUpLisa,
		onEmptyListen: (0, import_react.useCallback)(() => {
			const current = useAppStore.getState().live;
			if (!current || current.status !== "lisa") return;
			addTurn({
				role: "lisa",
				text: fallbackMissed(),
				at: Date.now()
			});
			speak(fallbackMissed());
		}, [addTurn, speak])
	};
}
function statusLabel(status, lisaStatus) {
	if (status === "lisa") {
		if (lisaStatus === "listening") return "Listening…";
		if (lisaStatus === "thinking") return "Thinking…";
		if (lisaStatus === "speaking") return "Speaking…";
		return "Lisa is on the line";
	}
	return "On call";
}
function ActiveCall() {
	const live = useAppStore((s) => s.live);
	const contacts = useAppStore((s) => s.contacts);
	const endCall = useAppStore((s) => s.endCall);
	const takeOver = useAppStore((s) => s.takeOver);
	const toggleMute = useAppStore((s) => s.toggleMute);
	const toggleSpeaker = useAppStore((s) => s.toggleSpeaker);
	const lisaHandleIncoming = useAppStore((s) => s.lisaHandleIncoming);
	const decideLisaAccess = useAppStore((s) => s.decideLisaAccess);
	const session = useLisaSession();
	const [typed, setTyped] = (0, import_react.useState)("");
	const [elapsed, setElapsed] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		if (!live) return;
		const tick = () => {
			const start = live.connectedAt ?? live.startedAt;
			setElapsed(Math.max(0, Math.floor((Date.now() - start) / 1e3)));
		};
		tick();
		const id = setInterval(tick, 1e3);
		return () => clearInterval(id);
	}, [live]);
	if (!live || live.status !== "active" && live.status !== "lisa") return null;
	const isLisa = live.status === "lisa";
	const contact = contacts.find((c) => c.id === live.contactId);
	const access = decideLisaAccess({
		number: live.number,
		known: live.known,
		policy: contact?.policy
	});
	const canHandOff = !isLisa && access.allowed && !live.emergency && live.direction === "incoming";
	const label = statusLabel(live.status, live.lisaStatus);
	async function onEnd() {
		if (isLisa) await session.hangUpLisa();
		else endCall();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "absolute inset-0 z-50 flex flex-col bg-background px-5 pt-[max(1.25rem,env(safe-area-inset-top))] pb-[max(1.25rem,env(safe-area-inset-bottom))]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-center text-[0.7rem] font-medium tracking-[0.22em] text-muted-foreground uppercase",
				children: isLisa ? "Lisa is handling your call" : "Lisa Call"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 flex flex-col items-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
						name: live.name,
						size: "lg"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-4 text-2xl font-medium tracking-tight",
						children: live.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: formatPhone(live.number)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 font-mono text-sm tabular-nums text-subtle",
						children: formatDuration(elapsed)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: isLisa && (live.lisaStatus === "thinking" || live.lisaStatus === "listening") ? "lisa-shimmer mt-2 text-sm" : "mt-2 text-sm text-accent",
						children: label
					}),
					live.emergency ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs text-warn",
						children: "Emergency call — Lisa will not intervene."
					}) : null
				]
			}),
			isLisa ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 min-h-0 flex-1 space-y-2 overflow-y-auto rounded-lg bg-card px-3 py-3",
				children: [live.turns.map((t, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: t.role === "lisa" ? "pr-6" : "pl-6 text-right",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[0.65rem] tracking-wide text-subtle uppercase",
						children: t.role === "lisa" ? "Lisa" : live.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm leading-snug",
						children: t.text
					})]
				}, `${t.at}-${i}`)), live.livePartial ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "pl-6 text-right text-sm text-muted-foreground italic",
					children: live.livePartial
				}) : null]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 flex-1",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-lg bg-card px-4 py-3 text-sm leading-relaxed text-muted-foreground",
					children: "This is a local call session. Cellular voice audio is not available in the browser — mute and speaker are on-device controls only."
				})
			}),
			isLisa ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 space-y-2",
				children: [
					live.turns.filter((t) => t.role === "caller").length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex gap-2 overflow-x-auto pb-1",
						children: SAMPLE_CALLER_LINES.slice(0, 3).map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							disabled: session.busy,
							onClick: () => void session.submitCallerText(line),
							className: "shrink-0 rounded-full border border-border px-3 py-2 text-left text-xs text-muted-foreground",
							children: line
						}, line))
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "flex gap-2",
						onSubmit: (e) => {
							e.preventDefault();
							const v = typed.trim();
							if (!v) return;
							setTyped("");
							session.submitCallerText(v);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: typed,
							onChange: (e) => setTyped(e.target.value),
							placeholder: session.micSupported ? "Speak, or type as the caller" : "Type as the caller",
							className: "h-11 flex-1 rounded-md border border-border bg-muted px-3 text-sm outline-none placeholder:text-subtle focus:ring-2 focus:ring-ring/50"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							disabled: session.busy || !typed.trim(),
							size: "md",
							children: "Send"
						})]
					}),
					session.micError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-warn",
						children: session.micError
					}) : null
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex items-center justify-center gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: toggleMute,
						className: "flex size-14 flex-col items-center justify-center rounded-full bg-muted text-foreground",
						"aria-label": live.muted ? "Unmute" : "Mute",
						children: live.muted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MicOff, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: toggleSpeaker,
						className: "flex size-14 flex-col items-center justify-center rounded-full bg-muted text-foreground",
						"aria-label": live.speaker ? "Speaker off" : "Speaker on",
						children: live.speaker ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "size-5" })
					}),
					isLisa ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "muted",
						className: "h-14 rounded-full px-5",
						onClick: takeOver,
						children: "Take Over"
					}) : canHandOff ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "primary",
						className: "h-14 rounded-full px-5",
						onClick: lisaHandleIncoming,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AudioLines, { className: "size-4" }), "Lisa"]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "danger",
						size: "icon",
						className: "size-16",
						onClick: () => void onEnd(),
						"aria-label": "End call",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneOff, { className: "size-7" })
					})
				]
			})
		]
	});
}
function LisaMark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className: cn("size-8", className),
		"aria-hidden": true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "32",
				height: "32",
				rx: "8",
				className: "fill-card"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "9",
				y: "7",
				width: "5.5",
				height: "18",
				rx: "1.4",
				className: "fill-accent"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "9",
				y: "19.5",
				width: "14",
				height: "5.5",
				rx: "1.4",
				className: "fill-accent"
			})
		]
	});
}
var TABS = [
	{
		id: "keypad",
		label: "Keypad",
		icon: Grid3x3
	},
	{
		id: "recents",
		label: "Recents",
		icon: Clock3
	},
	{
		id: "contacts",
		label: "Contacts",
		icon: Users
	},
	{
		id: "ai",
		label: "AI Calls",
		icon: AudioLines
	},
	{
		id: "settings",
		label: "Settings",
		icon: Settings2
	}
];
function StatusBar() {
	const [now, setNow] = (0, import_react.useState)(() => /* @__PURE__ */ new Date());
	(0, import_react.useEffect)(() => {
		const t = setInterval(() => setNow(/* @__PURE__ */ new Date()), 15e3);
		return () => clearInterval(t);
	}, []);
	const time = now.toLocaleTimeString([], {
		hour: "numeric",
		minute: "2-digit"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between px-6 pt-[max(0.6rem,env(safe-area-inset-top))] pb-1 text-xs text-muted-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "tabular-nums font-medium text-foreground/80",
			children: time
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex items-center gap-1.5",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "inline-block h-2 w-4 rounded-[2px] border border-foreground/50",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "ml-[1px] mt-[1px] block h-1.5 w-2.5 rounded-[1px] bg-foreground/70" })
			})
		})]
	});
}
function PhoneFrame({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-dvh bg-studio",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "relative mx-auto flex min-h-dvh w-full max-w-[430px] flex-col overflow-hidden bg-background lg:min-h-[min(100dvh,900px)] lg:my-4 lg:rounded-[2rem] lg:border lg:border-border lg:shadow-soft",
			children
		})
	});
}
function PhoneShell({ tab, onTab, children, hideTabs }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBar, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex-1 overflow-y-auto",
			children
		}),
		!hideTabs ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			className: "grid grid-cols-5 border-t border-border bg-background pb-[max(0.4rem,env(safe-area-inset-bottom))] pt-1",
			children: TABS.map((t) => {
				const Icon = t.icon;
				const active = tab === t.id;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onTab(t.id),
					className: cn("flex min-h-12 flex-col items-center justify-center gap-0.5 text-[0.65rem] tracking-wide", active ? "text-accent" : "text-subtle"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
						className: "size-[1.15rem]",
						strokeWidth: active ? 2.2 : 1.8
					}), t.label]
				}, t.id);
			})
		}) : null
	] });
}
function ScreenHeader({ title, subtitle, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-end justify-between px-5 pt-3 pb-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-2 flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LisaMark, { className: "size-7" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-[0.7rem] font-medium tracking-[0.18em] text-muted-foreground uppercase",
					children: "Lisa Call"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-[1.75rem] leading-tight font-medium tracking-tight",
				children: title
			}),
			subtitle ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: subtitle
			}) : null
		] }), action]
	});
}
var FILTERS = [
	"Handled",
	"Summaries",
	"Messages",
	"Important"
];
function AiCallsView() {
	const calls = useAppStore((s) => s.calls);
	const summaries = useAppStore((s) => s.summaries);
	const messages = useAppStore((s) => s.messages);
	const setOverlay = useAppStore((s) => s.setOverlay);
	const [filter, setFilter] = (0, import_react.useState)("Handled");
	const lisaCalls = (0, import_react.useMemo)(() => calls.filter((c) => c.handler === "lisa"), [calls]);
	const important = (0, import_react.useMemo)(() => calls.filter((c) => c.important || c.emergency), [calls]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScreenHeader, {
			title: "AI Calls",
			subtitle: "Lisa-handled conversations"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex gap-2 overflow-x-auto px-5 pb-4",
			children: FILTERS.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setFilter(f),
				className: filter === f ? "h-9 shrink-0 rounded-full bg-foreground px-3 text-sm text-background" : "h-9 shrink-0 rounded-full bg-muted px-3 text-sm text-muted-foreground",
				children: f
			}, f))
		}),
		filter === "Messages" ? messages.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: "No messages yet. When Lisa takes one, it appears here." }) : messages.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => setOverlay({
				kind: "call-detail",
				callId: m.callId
			}),
			className: "flex w-full gap-3 px-5 py-3 text-left hover:bg-muted/60",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, { name: m.caller }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: m.caller
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-sm text-muted-foreground",
						children: m.text
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-subtle",
						children: formatCallWhen(m.at)
					})
				]
			})]
		}, m.id)) : null,
		filter === "Summaries" ? summaries.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: "Summaries are saved after Lisa-handled calls, if enabled in Privacy." }) : summaries.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => setOverlay({
				kind: "call-detail",
				callId: s.callId
			}),
			className: "flex w-full gap-3 px-5 py-3 text-left hover:bg-muted/60",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, { name: s.caller }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: s.caller
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UrgencyBadge, { urgency: s.urgency })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: s.reason
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-0.5 line-clamp-2 text-xs text-subtle",
						children: s.summary
					})
				]
			})]
		}, s.id)) : null,
		filter === "Handled" ? lisaCalls.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: "No Lisa-handled calls yet. Ring a demo incoming call from the keypad." }) : lisaCalls.map((c) => {
			const sum = summaries.find((s) => s.callId === c.id);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setOverlay({
					kind: "call-detail",
					callId: c.id
				}),
				className: "flex w-full items-center gap-3 px-5 py-3 text-left hover:bg-muted/60",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, { name: c.name }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: c.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground",
							children: [
								formatPhone(c.number),
								" · ",
								formatDurationLabel(c.durationSec),
								sum ? " · Summary" : "",
								c.hasMessage ? " · Message" : ""
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-subtle",
						children: formatCallWhen(c.startedAt)
					})
				]
			}, c.id);
		}) : null,
		filter === "Important" ? important.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: "Mark a call important, or let Lisa flag high-urgency ones." }) : important.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => setOverlay({
				kind: "call-detail",
				callId: c.id
			}),
			className: "flex w-full items-center gap-3 px-5 py-3 text-left hover:bg-muted/60",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, { name: c.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-medium",
					children: c.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted-foreground",
					children: [
						c.emergency ? "Emergency" : "Important",
						" · ",
						formatPhone(c.number)
					]
				})]
			})]
		}, c.id)) : null
	] });
}
function Empty({ text }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "px-5 text-sm leading-relaxed text-muted-foreground",
		children: text
	});
}
function UrgencyBadge({ urgency }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `text-[0.65rem] tracking-wide uppercase ${urgency === "emergency" || urgency === "high" ? "text-destructive" : urgency === "low" ? "text-subtle" : "text-accent"}`,
		children: urgency
	});
}
var POLICY_LABEL = {
	always_myself: "Always you",
	lisa_may: "Lisa may handle",
	never_lisa: "Never Lisa"
};
function ContactsView() {
	const contacts = useAppStore((s) => s.contacts);
	const search = useAppStore((s) => s.search);
	const setSearch = useAppStore((s) => s.setSearch);
	const setOverlay = useAppStore((s) => s.setOverlay);
	const q = search.trim().toLowerCase();
	const filtered = contacts.filter((c) => {
		if (!q) return true;
		return c.name.toLowerCase().includes(q) || c.number.includes(q) || (c.company ?? "").toLowerCase().includes(q);
	});
	const favs = filtered.filter((c) => c.favorite);
	const rest = filtered.filter((c) => !c.favorite);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScreenHeader, {
			title: "Contacts",
			subtitle: `${contacts.length} on this device`,
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-label": "Add contact",
				onClick: () => setOverlay({ kind: "new-contact" }),
				className: "grid size-11 place-items-center rounded-full bg-muted text-accent",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-5" })
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "px-5 pb-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex h-11 items-center gap-2 rounded-md bg-muted px-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 text-subtle" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: search,
					onChange: (e) => setSearch(e.target.value),
					placeholder: "Search name or number",
					className: "h-full w-full bg-transparent text-sm outline-none placeholder:text-subtle"
				})]
			})
		}),
		filtered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "px-5 text-sm text-muted-foreground",
			children: "No contacts match."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [favs.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mb-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
				className: "flex items-center gap-1.5 px-5 pb-2 text-xs tracking-wide text-subtle uppercase",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "size-3" }), " Favorites"]
			}), favs.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactRow, {
				name: c.name,
				number: c.number,
				meta: POLICY_LABEL[c.policy],
				onClick: () => setOverlay({
					kind: "contact",
					contactId: c.id
				})
			}, c.id))]
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [favs.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "px-5 pb-2 text-xs tracking-wide text-subtle uppercase",
			children: "All"
		}) : null, rest.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactRow, {
			name: c.name,
			number: c.number,
			meta: `${c.company ? `${c.company} · ` : ""}${POLICY_LABEL[c.policy]}`,
			onClick: () => setOverlay({
				kind: "contact",
				contactId: c.id
			})
		}, c.id))] })] })
	] });
}
function ContactRow({ name, number, meta, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: "flex w-full items-center gap-3 px-5 py-3 text-left hover:bg-muted/60",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, { name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "truncate font-medium",
				children: name
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted-foreground",
				children: [
					formatPhone(number),
					" · ",
					meta
				]
			})]
		})]
	});
}
function IncomingCall() {
	const live = useAppStore((s) => s.live);
	const contacts = useAppStore((s) => s.contacts);
	const answerIncoming = useAppStore((s) => s.answerIncoming);
	const lisaHandleIncoming = useAppStore((s) => s.lisaHandleIncoming);
	const rejectIncoming = useAppStore((s) => s.rejectIncoming);
	const decideLisaAccess = useAppStore((s) => s.decideLisaAccess);
	if (!live || live.status !== "ringing") return null;
	const contact = contacts.find((c) => c.id === live.contactId);
	const showLisa = decideLisaAccess({
		number: live.number,
		known: live.known,
		policy: contact?.policy
	}).allowed && !live.emergency;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "absolute inset-0 z-50 flex flex-col bg-background px-6 pt-[max(1.5rem,env(safe-area-inset-top))] pb-[max(1.5rem,env(safe-area-inset-bottom))]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-center text-[0.7rem] font-medium tracking-[0.22em] text-muted-foreground uppercase",
				children: "Lisa Call"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-center text-sm text-muted-foreground",
				children: "Incoming call"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-1 flex-col items-center justify-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative mb-8 size-24",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "ring-soft absolute inset-0 rounded-full border border-accent/40" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "ring-soft absolute -inset-3 rounded-full border border-accent/25 [animation-delay:400ms]" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
								name: live.name,
								size: "xl"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-3xl font-medium tracking-tight",
						children: live.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-muted-foreground",
						children: formatPhone(live.number)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-xs tracking-wide text-subtle uppercase",
						children: live.emergency ? "Emergency — Lisa will not handle this" : live.known ? "Known contact" : "Unknown caller"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [
					showLisa ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "primary",
						size: "xl",
						className: "w-full",
						onClick: lisaHandleIncoming,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AudioLines, { className: "size-5" }), "Lisa Handles"]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "success",
							size: "xl",
							onClick: answerIncoming,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-5" }), "Answer"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "danger",
							size: "xl",
							onClick: rejectIncoming,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneOff, { className: "size-5" }), "Reject"]
						})]
					}),
					!showLisa && contact?.policy === "always_myself" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-center text-xs text-muted-foreground",
						children: "This contact is set to always answer yourself."
					}) : null
				]
			})
		]
	});
}
var KEYS = [
	{
		d: "1",
		l: ""
	},
	{
		d: "2",
		l: "ABC"
	},
	{
		d: "3",
		l: "DEF"
	},
	{
		d: "4",
		l: "GHI"
	},
	{
		d: "5",
		l: "JKL"
	},
	{
		d: "6",
		l: "MNO"
	},
	{
		d: "7",
		l: "PQRS"
	},
	{
		d: "8",
		l: "TUV"
	},
	{
		d: "9",
		l: "WXYZ"
	},
	{
		d: "*",
		l: ""
	},
	{
		d: "0",
		l: "+"
	},
	{
		d: "#",
		l: ""
	}
];
function KeypadView() {
	const [digits, setDigits] = (0, import_react.useState)("");
	const placeOutgoing = useAppStore((s) => s.placeOutgoing);
	const setOverlay = useAppStore((s) => s.setOverlay);
	const display = digits.startsWith("+") ? formatPhone(digits) || digits : digits;
	const emergency = isEmergencyNumber(digits);
	function press(k) {
		setDigits((d) => {
			if (k === "+") return d.startsWith("+") ? d : `+${d}`;
			return (d + k).slice(0, 18);
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-full flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScreenHeader, {
			title: "Keypad",
			subtitle: "Place a call, or demo an incoming ring",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setOverlay({ kind: "demo-ring" }),
				className: "flex size-11 items-center justify-center rounded-full bg-muted text-accent",
				"aria-label": "Simulate incoming call",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneIncoming, { className: "size-5" })
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-1 flex-col justify-end px-5 pb-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-2 min-h-16 text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[1.85rem] leading-tight font-medium tracking-wide break-all",
						children: display || /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-subtle",
							children: "Enter a number"
						})
					}), emergency ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs text-warn",
						children: "Emergency numbers are never handled by Lisa."
					}) : digits ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "mt-2 text-sm text-accent",
						onClick: () => {
							setOverlay({
								kind: "new-contact",
								number: digits
							});
						},
						children: "Add contact"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "mt-2 text-sm text-muted-foreground",
						onClick: () => setOverlay({ kind: "demo-ring" }),
						children: "Ring a demo call"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto grid w-full max-w-xs grid-cols-3 gap-x-4 gap-y-3 py-3",
					children: KEYS.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => press(k.d),
						onContextMenu: (e) => {
							if (k.d === "0") {
								e.preventDefault();
								press("+");
							}
						},
						className: "flex h-[4.25rem] flex-col items-center justify-center rounded-full bg-muted active:scale-95",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[1.7rem] leading-none font-medium",
							children: k.d
						}), k.l ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 text-[0.62rem] tracking-[0.18em] text-muted-foreground",
							children: k.l
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-1 h-3" })]
					}, k.d))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 mb-1 flex items-center justify-center gap-10",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-12" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "success",
							size: "icon",
							className: "size-16",
							disabled: !digits,
							"aria-label": "Call",
							onClick: () => placeOutgoing(digits),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-7 fill-current" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": "Delete",
							className: "grid size-12 place-items-center text-muted-foreground disabled:opacity-0",
							disabled: !digits,
							onClick: () => setDigits((d) => d.slice(0, -1)),
							onContextMenu: (e) => {
								e.preventDefault();
								setDigits("");
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Delete, { className: "size-6" })
						})
					]
				})
			]
		})]
	});
}
function Sheet({ title, onClose, children, wide }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "absolute inset-0 z-40 flex flex-col justify-end",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-label": "Close",
			className: "absolute inset-0 bg-studio/70",
			onClick: onClose
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("relative z-10 flex max-h-[90%] flex-col rounded-t-2xl border-t border-border bg-card shadow-soft", wide && "max-h-[94%]"),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mt-3 h-1 w-10 rounded-full bg-border" }),
				title ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between px-5 pt-3 pb-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-medium tracking-tight",
						children: title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onClose,
						className: "text-sm text-muted-foreground",
						children: "Close"
					})]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-y-auto px-5 pt-2 pb-[max(1.5rem,env(safe-area-inset-bottom))]",
					children
				})
			]
		})]
	});
}
var POLICY_OPTIONS = [
	{
		id: "always_myself",
		label: "Always answer myself",
		hint: "Lisa never picks up"
	},
	{
		id: "lisa_may",
		label: "Lisa may handle",
		hint: "Follows the known-contact setting"
	},
	{
		id: "never_lisa",
		label: "Never allow Lisa",
		hint: "Blocked from AI handling"
	}
];
function OverlayHost() {
	const overlay = useAppStore((s) => s.overlay);
	const setOverlay = useAppStore((s) => s.setOverlay);
	const close = () => setOverlay({ kind: "none" });
	if (overlay.kind === "none" || overlay.kind === "incoming" || overlay.kind === "active") return null;
	if (overlay.kind === "call-detail") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CallDetail, {
		callId: overlay.callId,
		onClose: close
	});
	if (overlay.kind === "contact") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactDetail, {
		contactId: overlay.contactId,
		onClose: close
	});
	if (overlay.kind === "new-contact") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NewContact, {
		number: overlay.number,
		onClose: close
	});
	if (overlay.kind === "demo-ring") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DemoRing, { onClose: close });
	if (overlay.kind === "capabilities") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Capabilities, { onClose: close });
	if (overlay.kind === "confirm-delete") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDelete, { onClose: close });
	return null;
}
function CallDetail({ callId, onClose }) {
	const call = useAppStore((s) => s.calls.find((c) => c.id === callId));
	const summary = useAppStore((s) => s.summaries.find((x) => x.callId === callId));
	const transcript = useAppStore((s) => s.transcripts.find((x) => x.callId === callId));
	const messages = useAppStore((s) => s.messages.filter((m) => m.callId === callId));
	const markImportant = useAppStore((s) => s.markImportant);
	const placeOutgoing = useAppStore((s) => s.placeOutgoing);
	if (!call) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
		title: "Call",
		onClose,
		wide: true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3 pb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
					name: call.name,
					size: "lg"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-lg font-medium",
						children: call.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: formatPhone(call.number)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-subtle",
						children: formatFullWhen(call.startedAt)
					})
				] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex flex-wrap gap-2 text-xs text-muted-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Chip, { children: [
						call.direction,
						" · ",
						formatDuration(call.durationSec)
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, { children: call.handler === "lisa" ? "Lisa-handled" : "You answered" }),
					summary ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, { children: "Summary saved" }) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-5 flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "success",
					className: "flex-1",
					onClick: () => {
						onClose();
						placeOutgoing(call.number);
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-4" }), "Call"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "muted",
					onClick: () => markImportant(call.id, !call.important),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: call.important ? "size-4 fill-current text-warn" : "size-4" })
				})]
			}),
			summary ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-5 space-y-3 rounded-lg bg-muted px-4 py-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-sm font-medium tracking-wide uppercase",
							children: "Call summary"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UrgencyBadge, { urgency: summary.urgency })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						k: "Caller",
						v: summary.caller
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						k: "Duration",
						v: summary.durationLabel
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						k: "Reason",
						v: summary.reason
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						k: "Summary",
						v: summary.summary
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						k: "Important information",
						v: summary.importantInfo
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						k: "Message",
						v: summary.message
					}),
					summary.people.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						k: "People",
						v: summary.people.join(", ")
					}) : null,
					summary.dates.length || summary.times.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						k: "When",
						v: [...summary.dates, ...summary.times].join(" · ")
					}) : null,
					summary.locations.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						k: "Locations",
						v: summary.locations.join(", ")
					}) : null
				]
			}) : call.handler === "lisa" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-4 text-sm text-muted-foreground",
				children: "No saved summary. Turn on “Save call summaries” in Settings to keep them."
			}) : null,
			messages.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 rounded-md border border-border px-3 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-wide text-subtle uppercase",
					children: "Message"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm",
					children: m.text
				})]
			}, m.id)),
			transcript ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mb-2 text-xs tracking-wide text-subtle uppercase",
					children: "Transcript"
				}), transcript.turns.map((t, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mb-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-subtle",
						children: [t.role === "lisa" ? "Lisa" : call.name, ": "]
					}), t.text]
				}, `${t.at}-${i}`))]
			}) : null
		]
	});
}
function Field({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-[0.65rem] tracking-wide text-subtle uppercase",
		children: k
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm leading-relaxed",
		children: v
	})] });
}
function Chip({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "rounded-full bg-muted px-2.5 py-1",
		children
	});
}
function ContactDetail({ contactId, onClose }) {
	const contact = useAppStore((s) => s.contacts.find((c) => c.id === contactId));
	const updateContact = useAppStore((s) => s.updateContact);
	const deleteContact = useAppStore((s) => s.deleteContact);
	const placeOutgoing = useAppStore((s) => s.placeOutgoing);
	const ringIncoming = useAppStore((s) => s.ringIncoming);
	if (!contact) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
		title: contact.name,
		onClose,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-4 text-muted-foreground",
				children: formatPhone(contact.number)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-5 grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "success",
					onClick: () => {
						onClose();
						placeOutgoing(contact.number);
					},
					children: "Call"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "muted",
					onClick: () => {
						onClose();
						ringIncoming({
							number: contact.number,
							contactId: contact.id
						});
					},
					children: "Demo ring"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 text-xs tracking-wide text-subtle uppercase",
				children: "Lisa handling"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-2",
				children: POLICY_OPTIONS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => updateContact(contact.id, { policy: p.id }),
					className: contact.policy === p.id ? "w-full rounded-md border border-accent bg-muted px-3 py-3 text-left" : "w-full rounded-md border border-border px-3 py-3 text-left",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm",
						children: p.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-subtle",
						children: p.hint
					})]
				}, p.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm",
					children: "Favorite"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: contact.favorite ? "primary" : "muted",
					size: "sm",
					onClick: () => updateContact(contact.id, { favorite: !contact.favorite }),
					children: contact.favorite ? "On" : "Off"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				className: "mt-6 w-full text-destructive",
				onClick: () => {
					deleteContact(contact.id);
					onClose();
				},
				children: "Delete contact"
			})
		]
	});
}
function NewContact({ number, onClose }) {
	const addContact = useAppStore((s) => s.addContact);
	const updateContact = useAppStore((s) => s.updateContact);
	const contacts = useAppStore((s) => s.contacts);
	const [name, setName] = (0, import_react.useState)("");
	const [num, setNum] = (0, import_react.useState)(number ?? "");
	const [policy, setPolicy] = (0, import_react.useState)("lisa_may");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
		title: "New contact",
		onClose,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mb-3 block text-sm",
				children: ["Name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: name,
					onChange: (e) => setName(e.target.value),
					className: "mt-1 h-11 w-full rounded-md border border-border bg-muted px-3 outline-none"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mb-3 block text-sm",
				children: ["Number", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: num,
					onChange: (e) => setNum(e.target.value),
					className: "mt-1 h-11 w-full rounded-md border border-border bg-muted px-3 outline-none"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 text-xs tracking-wide text-subtle uppercase",
				children: "Lisa handling"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-2",
				children: POLICY_OPTIONS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setPolicy(p.id),
					className: policy === p.id ? "w-full rounded-md border border-accent bg-muted px-3 py-2 text-left text-sm" : "w-full rounded-md border border-border px-3 py-2 text-left text-sm",
					children: p.label
				}, p.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-5 w-full",
				disabled: !num.trim(),
				onClick: () => {
					const existing = contacts.find((c) => !c.name && c.number.replace(/\D/g, "") === num.replace(/\D/g, ""));
					if (existing) updateContact(existing.id, {
						name: name || "No name",
						policy
					});
					else addContact({
						name: name || "No name",
						number: num,
						policy
					});
					onClose();
				},
				children: "Save"
			})
		]
	});
}
function DemoRing({ onClose }) {
	const contacts = useAppStore((s) => s.contacts);
	const ringIncoming = useAppStore((s) => s.ringIncoming);
	function ring(number, name, contactId) {
		onClose();
		ringIncoming({
			number,
			name,
			contactId
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
		title: "Simulate incoming call",
		onClose,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-4 text-sm text-muted-foreground",
				children: "Demo a ring so you can try Answer, Lisa Handles, or Reject. This is not a cellular call."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => ring("+917000011122", "Unknown"),
				className: "mb-2 flex w-full items-center gap-3 rounded-md border border-border px-3 py-3 text-left",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, { name: "Unknown" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-medium",
					children: "Unknown caller"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "+91 70000 11122"
				})] })]
			}),
			contacts.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => ring(c.number, c.name, c.id),
				className: "mb-2 flex w-full items-center gap-3 rounded-md border border-border px-3 py-3 text-left",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, { name: c.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-medium",
					children: c.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: formatPhone(c.number)
				})] })]
			}, c.id))
		]
	});
}
function Capabilities({ onClose }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
		title: "Platform limits",
		onClose,
		wide: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4 pb-4 text-sm leading-relaxed text-muted-foreground",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-foreground",
					children: "Lisa Call is built on what Android’s public Telecom APIs actually allow — not on hidden or rooted tricks."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-foreground",
					children: "What a default dialer can do"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					"With ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-foreground",
						children: "ROLE_DIALER"
					}),
					" and",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-foreground",
						children: "InCallService"
					}),
					", an app can show incoming and active call UI, answer, reject, mute, speaker, hold, DTMF, contacts, and the system call log."
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-foreground",
					children: "What it cannot do"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					"Third-party apps — including the default phone app — do not receive the cellular (GSM/IMS) voice stream. There is no public API to inject text-to-speech into the uplink or to transcribe the remote caller from that call. The ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-foreground",
						children: "VOICE_CALL"
					}),
					" ",
					"audio source is reserved for privileged system components. Pixel Call Screen uses private Play services APIs that other apps cannot use."
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-foreground",
					children: "Supported architecture for Lisa talking"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					"1. Self-managed ConnectionService / VoIP, where the app owns the media path.",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
					"2. A telephony bridge (Lisa’s number or a CPaaS conference) sitting in the audio path.",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
					"3. This app: you (or a VoIP caller) speak; Lisa listens with speech-to-text and replies with text-to-speech. That loop is real."
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-foreground",
					children: "Emergency"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Emergency numbers stay on Android’s emergency-call path. Lisa never auto-handles them." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "This preview is the product you can use now. A native APK still cannot legally or technically put Lisa on a live SIM call without a media-path partner." })
			]
		})
	});
}
function ConfirmDelete({ onClose }) {
	const deleteAllAiData = useAppStore((s) => s.deleteAllAiData);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
		title: "Delete AI call data",
		onClose,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-4 text-sm leading-relaxed text-muted-foreground",
			children: "This removes summaries, transcripts, and messages. Call rows stay in Recents without AI details. This cannot be undone."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "danger",
			className: "w-full",
			onClick: () => {
				deleteAllAiData();
				toast("AI call data deleted");
				onClose();
			},
			children: "Delete all AI call data"
		})]
	});
}
function DirectionIcon({ call }) {
	if (call.direction === "missed") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneMissed, { className: "size-3.5 text-destructive" });
	if (call.direction === "outgoing") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneOutgoing, { className: "size-3.5 text-success" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneIncoming, { className: "size-3.5 text-muted-foreground" });
}
function RecentsView() {
	const calls = useAppStore((s) => s.calls);
	const setOverlay = useAppStore((s) => s.setOverlay);
	const placeOutgoing = useAppStore((s) => s.placeOutgoing);
	const groups = /* @__PURE__ */ new Map();
	for (const c of calls) {
		const key = dayGroupLabel(c.startedAt);
		const list = groups.get(key) ?? [];
		list.push(c);
		groups.set(key, list);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScreenHeader, {
		title: "Recents",
		subtitle: "Calls on this device"
	}), calls.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "px-5 text-sm text-muted-foreground",
		children: "No calls yet."
	}) : [...groups.entries()].map(([label, list]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mb-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "px-5 pb-2 text-xs tracking-wide text-subtle uppercase",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: list.map((call) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => call.summaryId || call.handler === "lisa" ? setOverlay({
				kind: "call-detail",
				callId: call.id
			}) : placeOutgoing(call.number),
			className: "flex w-full items-center gap-3 px-5 py-3 text-left hover:bg-muted/60",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, { name: call.name }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate font-medium",
							children: call.name === "Unknown" ? formatPhone(call.number) : call.name
						}), call.handler === "lisa" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-1 rounded-full bg-muted px-2 py-0.5 text-[0.65rem] text-accent",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AudioLines, { className: "size-3" }), "Lisa"]
						}) : null]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-0.5 flex items-center gap-1.5 text-xs text-muted-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DirectionIcon, { call }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: call.direction === "missed" ? "Missed" : call.direction === "outgoing" ? "Outgoing" : "Incoming" }),
							call.durationSec > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["· ", formatDuration(call.durationSec)] }) : null,
							call.summaryId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "· Summary" }) : null
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs tabular-nums text-subtle",
					children: formatCallWhen(call.startedAt)
				})
			]
		}) }, call.id)) })]
	}, label))] });
}
function Switch({ checked, onChange, disabled, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		role: "switch",
		"aria-checked": checked,
		"aria-label": label,
		disabled,
		onClick: () => onChange(!checked),
		className: cn("relative h-7 w-12 shrink-0 rounded-full transition-colors duration-150", checked ? "bg-accent" : "bg-border", disabled && "opacity-40"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("absolute top-0.5 left-0.5 size-6 rounded-full bg-foreground shadow-sm transition-transform duration-150", checked ? "translate-x-5 bg-accent-foreground" : "translate-x-0") })
	});
}
function SettingsView() {
	const settings = useAppStore((s) => s.settings);
	const updateSettings = useAppStore((s) => s.updateSettings);
	const events = useAppStore((s) => s.events);
	const setOverlay = useAppStore((s) => s.setOverlay);
	const [aiOn, setAiOn] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let alive = true;
		getAiStatus().then((r) => {
			if (alive) setAiOn(r.available);
		});
		return () => {
			alive = false;
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScreenHeader, {
				title: "Settings",
				subtitle: "Calling, AI, privacy"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				title: "Calling",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Default phone app",
						hint: "ROLE_DIALER is an Android system role. Not available in this browser.",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-subtle",
							children: "Browser"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Confirm before Lisa handles",
						hint: "Always show Answer / Lisa Handles / Reject first.",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: settings.confirmBeforeLisaHandles,
							onChange: (v) => updateSettings({ confirmBeforeLisaHandles: v }),
							label: "Confirm before Lisa handles"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Unknown callers",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
							value: settings.unknownCallers,
							onChange: (v) => updateSettings({ unknownCallers: v }),
							options: [
								["never", "Never"],
								["ask", "Ask me first"],
								["allow", "Always"]
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Known contacts",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
							value: settings.knownContacts,
							onChange: (v) => updateSettings({ knownContacts: v }),
							options: [
								["never", "Never let Lisa handle"],
								["ask", "Ask me first"],
								["allow", "Allow Lisa"]
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-5 pt-1 text-xs text-subtle",
						children: "Per-contact rules in Contacts override these. Emergency numbers are never auto-handled."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				title: "AI",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "AI provider",
						hint: aiOn === false ? "xAI is unavailable in this environment." : "xAI Grok — key stays on the server.",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
							value: settings.aiProvider,
							onChange: (v) => updateSettings({ aiProvider: v }),
							options: [["xai", "xAI Grok"], ["lisa_assistant", "Lisa assistant (later)"]]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Voice",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
							value: settings.voiceId,
							onChange: (v) => updateSettings({ voiceId: v }),
							options: [
								["luna", "Luna"],
								["carina", "Carina"],
								["eve", "Eve"],
								["iris", "Iris"],
								["ara", "Ara"]
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: `Speaking speed  ${settings.speakingSpeed.toFixed(2)}x`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "range",
							min: .85,
							max: 1.15,
							step: .05,
							value: settings.speakingSpeed,
							onChange: (e) => updateSettings({ speakingSpeed: Number(e.target.value) }),
							className: "w-28 accent-accent"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Personality",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
							value: settings.personality,
							onChange: (v) => updateSettings({ personality: v }),
							options: [
								["professional", "Professional"],
								["warm", "Warm"],
								["concise", "Concise"]
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Max AI call duration",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
							value: String(settings.maxAiCallMinutes),
							onChange: (v) => updateSettings({ maxAiCallMinutes: Number(v) }),
							options: [
								["2", "2 min"],
								["5", "5 min"],
								["10", "10 min"],
								["15", "15 min"]
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Answers for",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: settings.ownerName,
							onChange: (e) => updateSettings({ ownerName: e.target.value }),
							className: "h-9 w-28 rounded-sm border border-border bg-muted px-2 text-sm outline-none"
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				title: "Privacy",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Save AI call transcripts",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: settings.saveTranscripts,
							onChange: (v) => updateSettings({ saveTranscripts: v }),
							label: "Save transcripts"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Save call summaries",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: settings.saveSummaries,
							onChange: (v) => updateSettings({ saveSummaries: v }),
							label: "Save summaries"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Save recordings",
						hint: "Off. Android does not give third-party apps the cellular voice stream, and this app does not record calls.",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: false,
							onChange: () => void 0,
							disabled: true,
							label: "Save recordings"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Auto-delete AI data",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
							value: String(settings.autoDeleteDays),
							onChange: (v) => updateSettings({ autoDeleteDays: Number(v) }),
							options: [
								["0", "Never"],
								["7", "7 days"],
								["30", "30 days"],
								["90", "90 days"]
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "px-5 pt-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							className: "w-full",
							onClick: () => setOverlay({ kind: "confirm-delete" }),
							children: "Delete all AI call data"
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				title: "Lisa integration",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Enable Lisa connection",
						hint: "Talks to com.lisa.assistant through a private, non-exported channel when both apps are installed.",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: settings.lisaIntegrationEnabled,
							onChange: (v) => updateSettings({ lisaIntegrationEnabled: v }),
							label: "Enable Lisa connection"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Connection status",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-subtle",
							children: settings.lisaIntegrationEnabled ? "Waiting for Lisa assistant" : "Off"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Sync call summaries",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: settings.syncSummaries,
							onChange: (v) => updateSettings({ syncSummaries: v }),
							disabled: !settings.lisaIntegrationEnabled,
							label: "Sync summaries"
						})
					}),
					settings.lisaIntegrationEnabled && events.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "px-5 pt-2 text-xs text-muted-foreground",
						children: events.slice(0, 5).map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "border-t border-border py-2",
							children: e.type.replaceAll("_", " ")
						}, e.id))
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
				title: "Platform",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "px-5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "muted",
						className: "w-full",
						onClick: () => setOverlay({ kind: "capabilities" }),
						children: "What Android actually allows"
					})
				})
			})
		]
	});
}
function Section({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mb-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "px-5 pb-2 text-xs tracking-[0.16em] text-subtle uppercase",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "divide-y divide-border border-y border-border bg-card",
			children
		})]
	});
}
function Row({ label, hint, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-3 px-5 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0 flex-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm",
				children: label
			}), hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-0.5 text-xs leading-snug text-subtle",
				children: hint
			}) : null]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "shrink-0",
			children
		})]
	});
}
function Select({ value, onChange, options }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
		value,
		onChange: (e) => onChange(e.target.value),
		className: "h-9 max-w-[11rem] rounded-sm border border-border bg-muted px-2 text-sm outline-none",
		children: options.map(([v, l]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
			value: v,
			children: l
		}, v))
	});
}
function LisaCallApp() {
	const [ready, setReady] = (0, import_react.useState)(false);
	const tab = useAppStore((s) => s.tab);
	const setTab = useAppStore((s) => s.setTab);
	const overlay = useAppStore((s) => s.overlay);
	const live = useAppStore((s) => s.live);
	(0, import_react.useEffect)(() => {
		const unsub = useAppStore.persist.onFinishHydration(() => setReady(true));
		if (useAppStore.persist.hasHydrated()) setReady(true);
		useAppStore.getState().pruneExpired();
		return unsub;
	}, []);
	const onCall = overlay.kind === "incoming" || overlay.kind === "active" || live?.status === "ringing" || live?.status === "active" || live?.status === "lisa";
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneFrame, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-1 flex-col items-center justify-center gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LisaMark, { className: "size-12" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: "Lisa Call"
		})]
	}) });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PhoneFrame, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PhoneShell, {
			tab,
			onTab: setTab,
			hideTabs: onCall,
			children: [
				tab === "keypad" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeypadView, {}) : null,
				tab === "recents" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RecentsView, {}) : null,
				tab === "contacts" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactsView, {}) : null,
				tab === "ai" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AiCallsView, {}) : null,
				tab === "settings" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsView, {}) : null
			]
		}),
		overlay.kind === "incoming" || live?.status === "ringing" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IncomingCall, {}) : null,
		overlay.kind === "active" || live?.status === "active" || live?.status === "lisa" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActiveCall, {}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OverlayHost, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
			theme: "dark",
			position: "top-center",
			toastOptions: { classNames: { toast: "bg-card text-foreground border border-border" } }
		})
	] });
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LisaCallApp, {});
}
//#endregion
export { Home as component };
