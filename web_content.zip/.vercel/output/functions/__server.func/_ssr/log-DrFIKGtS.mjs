import { i as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, x as require_react } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { O as useFlock, h as formatInt, i as HEALTH_KIND_LABEL, k as useHydrated, m as formatDate, t as AppShell, u as cn, w as sheepName } from "./store-g4o8WGZx.mjs";
import { t as Card } from "./card-DKPDfbAA.mjs";
import { t as Button } from "./button-C77Erh3S.mjs";
import { n as HealthForm, t as BreedingForm } from "./forms-z1jNLbZu.mjs";
import { i as TabsTrigger$1, n as TabsContent$1, r as TabsList$1, t as Tabs$1 } from "../_libs/radix-ui__react-tabs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/log-DrFIKGtS.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Tabs({ ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tabs$1, { ...props });
}
function TabsList({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsList$1, {
		className: cn("grid grid-cols-2 rounded-xl bg-secondary p-1", className),
		...props
	});
}
function TabsTrigger({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger$1, {
		className: cn("h-10 rounded-lg text-sm font-medium text-muted-foreground transition-colors duration-150 data-[state=active]:bg-card data-[state=active]:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring", className),
		...props
	});
}
function TabsContent({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent$1, {
		className: cn("mt-4 outline-none", className),
		...props
	});
}
function LogPage() {
	const hydrated = useHydrated();
	const sheep = useFlock((s) => s.sheep);
	const health = useFlock((s) => s.health);
	const breeding = useFlock((s) => s.breeding);
	const removeHealth = useFlock((s) => s.removeHealth);
	const removeBreeding = useFlock((s) => s.removeBreeding);
	const [showHealth, setShowHealth] = (0, import_react.useState)(false);
	const [showBreed, setShowBreed] = (0, import_react.useState)(false);
	const healthRows = health.slice().sort((a, b) => a.date < b.date ? 1 : -1);
	const breedRows = breeding.slice().sort((a, b) => a.matingDate < b.matingDate ? 1 : -1);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "السجلات",
		children: !hydrated ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: "يُفتح السجل…"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
			defaultValue: "health",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
					value: "health",
					children: "الصحة"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
					value: "breeding",
					children: "التناسل"
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
					value: "health",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-4",
						children: [
							showHealth ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HealthForm, { onDone: () => setShowHealth(false) }) }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: () => setShowHealth(true),
								children: "تسجيل علاج أو تطعيم"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm leading-normal text-muted-foreground",
								children: "سجل شخصي للمتابعة، وليس استشارة بيطرية."
							}),
							healthRows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground",
								children: "لا سجلات صحية بعد."
							}) : healthRows.map((h) => {
								const who = sheep.find((s) => s.id === h.sheepId);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "border-b border-border pb-3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-start justify-between gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-medium",
												children: h.title
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-sm text-muted-foreground",
												children: [
													HEALTH_KIND_LABEL[h.kind],
													" · ",
													formatDate(h.date)
												]
											}),
											who ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
												to: "/sheep/$id",
												params: { id: who.id },
												className: "text-sm",
												children: sheepName(who, "")
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-sm",
												children: "القطيع كله"
											}),
											h.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-1 text-sm whitespace-pre-wrap text-muted-foreground",
												children: h.notes
											}) : null
										] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "text-sm text-muted-foreground",
											onClick: () => removeHealth(h.id),
											children: "حذف"
										})]
									})
								}, h.id);
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
					value: "breeding",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-4",
						children: [showBreed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BreedingForm, { onDone: () => setShowBreed(false) }) }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => setShowBreed(true),
							children: "تسجيل تلقيح"
						}), breedRows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: "لا تلقيحات بعد."
						}) : breedRows.map((b) => {
							const ewe = sheep.find((s) => s.id === b.eweId);
							const ram = sheep.find((s) => s.id === b.ramId);
							const label = b.result === "pending" ? "حمل قائم" : b.result === "lambed" ? `ولادة · ${formatInt(b.lambCount ?? 0)}` : "حمل مفقود";
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "border-b border-border pb-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-medium",
											children: label
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-sm text-muted-foreground",
											children: [
												"تلقيح ",
												formatDate(b.matingDate),
												b.result === "pending" ? ` · ولادة ${formatDate(b.expectedDate)}` : b.closedDate ? ` · أُغلق ${formatDate(b.closedDate)}` : ""
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-sm",
											children: [
												ewe ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
													to: "/sheep/$id",
													params: { id: ewe.id },
													children: ["نعجة ", sheepName(ewe, "")]
												}) : "نعجة محذوفة",
												" · ",
												ram ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
													to: "/sheep/$id",
													params: { id: ram.id },
													children: ["كبش ", sheepName(ram, "")]
												}) : "كبش غير محدد"
											]
										}),
										b.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 text-sm text-muted-foreground",
											children: b.notes
										}) : null
									] }), b.result !== "pending" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "text-sm text-muted-foreground",
										onClick: () => removeBreeding(b.id),
										children: "حذف"
									}) : null]
								})
							}, b.id);
						})]
					})
				})
			]
		})
	});
}
//#endregion
export { LogPage as component };
