import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { x as useParties } from "./use-books-BtZpLk9U.mjs";
import { s as formatJalali } from "./format-c9GA3s0l.mjs";
import { i as PageHeader, n as Card, o as StatCard, r as Money, t as Badge } from "./card-Bb_-PO54.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/crm-COAyrCU7.js
var import_jsx_runtime = require_jsx_runtime();
function CrmPage() {
	const { data = [] } = useParties();
	const customers = data.filter((p) => p.kind === "customer");
	const active = customers.filter((p) => p.opCount > 0);
	const highAr = customers.filter((p) => p.ar > 5e7);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "باشگاه مشتریان",
			description: "ارزش مشتری، مانده، رفتار پرداخت و آخرین معامله — متصل به دفتر معین."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-5 grid grid-cols-2 gap-3 lg:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "مشتریان",
					value: customers.length
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "فعال",
					value: active.length
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "مانده بالا",
					value: highAr.length
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "فروش تجمعی",
					value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
						value: customers.reduce((s, p) => s + p.sales, 0),
						compact: true
					})
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-3",
			children: customers.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-start justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-medium text-navy",
						children: p.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-xs text-muted",
						children: [
							p.code,
							" · ",
							p.phone,
							" · ",
							p.address
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: p.ar > 8e7 ? "warn" : "ok",
						children: p.ar > 8e7 ? "ریسک وصول" : "سالم"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid grid-cols-2 gap-3 text-xs sm:grid-cols-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["فروش ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-1 text-sm",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
								value: p.sales,
								compact: true
							})
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["دریافت ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-1 text-sm",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
								value: p.receipts,
								compact: true
							})
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["مانده بدهکار ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-1 text-sm",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
								value: p.ar,
								compact: true
							})
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["آخرین خرید ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-1 text-sm",
							children: p.lastDate ? formatJalali(p.lastDate) : "—"
						})] })
					]
				})]
			}, p.id))
		})
	] });
}
//#endregion
export { CrmPage as component };
