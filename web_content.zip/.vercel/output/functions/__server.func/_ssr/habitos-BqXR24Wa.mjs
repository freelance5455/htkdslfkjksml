import { w as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { E as toDateKey } from "./store-CuJQmbYj.mjs";
import { t as PageHeader } from "./page-header-ueGZTDza.mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as CalendarDays } from "../_libs/lucide-react.mjs";
import { o as Button } from "./router-0AvkMag6.mjs";
import { t as DayChecklist } from "./day-checklist-BPquXlsy.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/habitos-BqXR24Wa.js
var import_jsx_runtime = require_jsx_runtime();
function HabitsPage() {
	const date = toDateKey(/* @__PURE__ */ new Date());
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "animate-in fade-in duration-300",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			kicker: "Hoje",
			title: "Hábitos",
			subtitle: "Checklist do dia. Cada data guarda o próprio registro.",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				variant: "outline",
				size: "sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/calendario",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarDays, {}), " Calendário"]
				})
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DayChecklist, { date })]
	});
}
//#endregion
export { HabitsPage as component };
