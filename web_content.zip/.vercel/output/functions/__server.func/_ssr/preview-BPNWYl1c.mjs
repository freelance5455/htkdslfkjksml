import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as aspectFrameClass } from "./prompts-C2oS8e1R.mjs";
import { n as Route } from "./router-BlmjsFDF.mjs";
import { a as useProjects, o as useStory } from "./use-projects-B0rAf6PZ.mjs";
import { t as Button } from "./button-ZNEObmRA.mjs";
import { n as downloadScenesZip } from "./download-BEVDFjl1.mjs";
import { n as SwitchThumb, t as Switch } from "../_libs/@radix-ui/react-switch+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/preview-BPNWYl1c.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Flag({ label, checked, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "flex min-h-11 items-center justify-between gap-3 rounded-md border border-line bg-surface px-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-sm font-medium",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
			checked,
			onCheckedChange: onChange,
			className: "relative h-7 w-12 shrink-0 rounded-full bg-faint data-[state=checked]:bg-ink",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchThumb, { className: "block size-5 translate-x-1 rounded-full bg-surface transition-transform duration-150 data-[state=checked]:translate-x-6" })
		})]
	});
}
function PreviewBoard({ project }) {
	const [showNumber, setShowNumber] = (0, import_react.useState)(true);
	const [showTitle, setShowTitle] = (0, import_react.useState)(true);
	const columns = project.scenes.length === 9 ? "grid-cols-3" : "grid-cols-2";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-widest text-muted uppercase",
					children: "Storyboard preview"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl font-medium tracking-tight",
					children: project.name
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/storyboards/$id",
					params: { id: project.id },
					className: "text-sm font-medium underline",
					children: "Kembali ke editor"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flag, {
					label: "Show scene number",
					checked: showNumber,
					onChange: setShowNumber
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flag, {
					label: "Show scene title",
					checked: showTitle,
					onChange: setShowTitle
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `grid gap-2 ${columns}`,
				children: project.scenes.map((scene, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/storyboards/$id",
					params: { id: project.id },
					hash: `scene-${scene.id}`,
					className: "overflow-hidden rounded-md border border-line bg-surface",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `bg-bg ${aspectFrameClass(project.aspect)}`,
						children: scene.imageDataUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: scene.imageDataUrl,
							alt: "",
							className: "h-full w-full object-contain"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex h-full items-center justify-center text-xs text-muted",
							children: "Belum ada gambar"
						})
					}), showNumber || showTitle ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "px-2 py-2 text-xs leading-snug",
						children: [showNumber ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-medium tabular-nums",
							children: [String(index + 1).padStart(2, "0"), " "]
						}) : null, showTitle ? scene.title : null]
					}) : null]
				}, scene.id))
			})
		]
	});
}
function PreviewPage() {
	const { id } = Route.useParams();
	const ready = useProjects();
	const project = useStory((state) => state.projects.find((item) => item.id === id));
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: "Memuat storyboard…"
	});
	if (!project || project.scenes.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Belum ada scene untuk ditampilkan." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/storyboards/$id",
			params: { id },
			className: "text-sm font-medium underline",
			children: "Kembali"
		})]
	});
	const hasImages = project.scenes.some((scene) => scene.imageDataUrl);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewBoard, { project }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "secondary",
			className: "w-full sm:w-fit",
			disabled: !hasImages,
			onClick: () => void downloadScenesZip(project.scenes, "storyboard.zip"),
			children: "Download all"
		})]
	});
}
//#endregion
export { PreviewPage as component };
