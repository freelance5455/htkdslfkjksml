import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { f as cn } from "./router-CboP5aV-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/star-photo-CYdE_HDR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TONES = [
	{
		bg: "#1a1612",
		fg: "#e8e0d4"
	},
	{
		bg: "#14181c",
		fg: "#d9ddd8"
	},
	{
		bg: "#1c1414",
		fg: "#eadfd6"
	},
	{
		bg: "#121614",
		fg: "#d7e0d8"
	},
	{
		bg: "#181410",
		fg: "#efe6d6"
	},
	{
		bg: "#101418",
		fg: "#d5dce4"
	},
	{
		bg: "#161210",
		fg: "#e6d8cc"
	},
	{
		bg: "#121210",
		fg: "#e8e4dc"
	}
];
function hash(s) {
	let h = 2166136261;
	for (let i = 0; i < s.length; i++) {
		h ^= s.charCodeAt(i);
		h = Math.imul(h, 16777619);
	}
	return h >>> 0;
}
function initialsOf(name) {
	const parts = name.replace(/[().,]/g, " ").split(/\s+/).filter(Boolean);
	if (parts.length === 0) return "?";
	if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
	return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}
function portraitTone(seed) {
	return TONES[hash(seed) % TONES.length];
}
var cache = /* @__PURE__ */ new Map();
var AGE_KEY = "stardex-wiki-photos";
function loadLocal() {
	try {
		const raw = localStorage.getItem(AGE_KEY);
		if (!raw) return {};
		return JSON.parse(raw);
	} catch {
		return {};
	}
}
function saveLocal(map) {
	try {
		localStorage.setItem(AGE_KEY, JSON.stringify(map));
	} catch {}
}
async function fetchWikiThumb(wikiTitle) {
	if (cache.has(wikiTitle)) return cache.get(wikiTitle) ?? null;
	const local = loadLocal();
	if (local[wikiTitle] !== void 0) {
		cache.set(wikiTitle, local[wikiTitle] || null);
		return local[wikiTitle] || null;
	}
	try {
		const title = encodeURIComponent(wikiTitle.replace(/ /g, "_"));
		const res = await fetch(`https://en.wikipedia.org/api/rest_v1/page/summary/${title}`, { headers: { accept: "application/json" } });
		if (!res.ok) {
			cache.set(wikiTitle, null);
			local[wikiTitle] = "";
			saveLocal(local);
			return null;
		}
		const src = (await res.json()).thumbnail?.source ?? null;
		cache.set(wikiTitle, src);
		local[wikiTitle] = src ?? "";
		saveLocal(local);
		return src;
	} catch {
		cache.set(wikiTitle, null);
		return null;
	}
}
function Portrait({ name, seed, className }) {
	const tone = portraitTone(seed);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex h-full w-full items-end p-3", className),
		style: { background: tone.bg },
		"aria-hidden": true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-display text-3xl font-medium leading-none tracking-tight",
			style: { color: tone.fg },
			children: initialsOf(name)
		})
	});
}
function StarPhoto({ star, className, sizes = "160px" }) {
	const [remote, setRemote] = (0, import_react.useState)(star.photo);
	const [failed, setFailed] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setRemote(star.photo);
		setFailed(false);
		if (star.customPhotoUrl || star.photo) return;
		let alive = true;
		fetchWikiThumb(star.wiki || star.name).then((src) => {
			if (alive && src) setRemote(src);
		});
		return () => {
			alive = false;
		};
	}, [
		star.customPhotoUrl,
		star.photo,
		star.wiki,
		star.name
	]);
	const src = star.customPhotoUrl || (!failed ? remote : null);
	if (!src) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portrait, {
		name: star.name,
		seed: star.slug,
		className
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src,
		alt: "",
		sizes,
		loading: "lazy",
		decoding: "async",
		referrerPolicy: "no-referrer",
		className: cn("h-full w-full object-cover", className),
		onError: () => {
			setFailed(true);
			setRemote(null);
		}
	});
}
//#endregion
export { StarPhoto as t };
