import { o as mentionFromAverage, s as toNumber } from "./calc-DDlXNlj6.mjs";
import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { a as number, n as _enum, o as object, r as array, s as string, t as number$1 } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/server-DAUlM2i5.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var _0002_bac_default = "-- ديوان تسيير شهادة البكالوريا — مرجع الشعب والمواد، الثانويات، المترشحون، العلامات، النتائج\n\ncreate table if not exists streams (\n  id serial primary key,\n  code text not null unique,\n  name_ar text not null\n);\n\ncreate table if not exists subjects (\n  id serial primary key,\n  code text not null unique,\n  name_ar text not null\n);\n\ncreate table if not exists stream_subjects (\n  stream_id int not null references streams (id) on delete cascade,\n  subject_id int not null references subjects (id) on delete cascade,\n  coefficient numeric(4,1) not null,\n  primary key (stream_id, subject_id)\n);\n\ncreate table if not exists schools (\n  id serial primary key,\n  name text not null,\n  wilaya text not null,\n  created_at timestamptz not null default now()\n);\n\ncreate table if not exists exam_sessions (\n  id serial primary key,\n  year int not null,\n  kind text not null,\n  label_ar text not null,\n  unique (year, kind)\n);\n\ncreate table if not exists students (\n  id serial primary key,\n  exam_number text not null unique,\n  first_name text not null,\n  last_name text not null,\n  birth_date date not null,\n  birth_place text not null,\n  gender text not null,\n  school_id int not null references schools (id),\n  stream_id int not null references streams (id),\n  session_id int not null references exam_sessions (id),\n  created_at timestamptz not null default now()\n);\n\ncreate table if not exists grades (\n  id serial primary key,\n  student_id int not null references students (id) on delete cascade,\n  subject_id int not null references subjects (id),\n  score numeric(4,2) not null check (score >= 0 and score <= 20),\n  unique (student_id, subject_id)\n);\n\ncreate table if not exists results (\n  student_id int primary key references students (id) on delete cascade,\n  average numeric(5,2) not null,\n  mention text not null,\n  decision text not null,\n  certificate_number text unique,\n  issued_at timestamptz\n);\n\ncreate index if not exists students_stream_id_idx on students (stream_id);\ncreate index if not exists students_school_id_idx on students (school_id);\ncreate index if not exists students_session_id_idx on students (session_id);\ncreate index if not exists students_last_name_idx on students (last_name);\ncreate index if not exists results_decision_idx on results (decision);\ncreate index if not exists results_mention_idx on results (mention);\n\ninsert into streams (code, name_ar) values\n  ('SCI', 'علوم تجريبية'),\n  ('MATH', 'رياضيات'),\n  ('TM', 'تقني رياضي'),\n  ('GE', 'تسيير واقتصاد'),\n  ('LIT', 'آداب وفلسفة'),\n  ('LANG', 'لغات أجنبية');\n\ninsert into subjects (code, name_ar) values\n  ('MATH', 'الرياضيات'),\n  ('PHY', 'الفيزياء والكيمياء'),\n  ('SNV', 'علوم الطبيعة والحياة'),\n  ('AR', 'اللغة العربية'),\n  ('FR', 'اللغة الفرنسية'),\n  ('EN', 'اللغة الإنجليزية'),\n  ('DE', 'اللغة الألمانية'),\n  ('HG', 'التاريخ والجغرافيا'),\n  ('ISL', 'العلوم الإسلامية'),\n  ('PHIL', 'الفلسفة'),\n  ('SPORT', 'التربية البدنية'),\n  ('GMF', 'التسيير المحاسبي والمالي'),\n  ('ECO', 'الاقتصاد والمناجمنت'),\n  ('LAW', 'القانون'),\n  ('TECH', 'التكنولوجيا');\n\ninsert into stream_subjects (stream_id, subject_id, coefficient)\nselect s.id, sub.id, v.coef\nfrom (values\n  ('SCI', 'MATH', 5.0), ('SCI', 'PHY', 5.0), ('SCI', 'SNV', 6.0), ('SCI', 'AR', 3.0),\n  ('SCI', 'FR', 2.0), ('SCI', 'EN', 2.0), ('SCI', 'HG', 2.0), ('SCI', 'ISL', 2.0),\n  ('SCI', 'PHIL', 2.0), ('SCI', 'SPORT', 1.0),\n  ('MATH', 'MATH', 7.0), ('MATH', 'PHY', 6.0), ('MATH', 'SNV', 2.0), ('MATH', 'AR', 3.0),\n  ('MATH', 'FR', 2.0), ('MATH', 'EN', 2.0), ('MATH', 'HG', 2.0), ('MATH', 'ISL', 2.0),\n  ('MATH', 'PHIL', 2.0), ('MATH', 'SPORT', 1.0),\n  ('TM', 'MATH', 6.0), ('TM', 'PHY', 6.0), ('TM', 'TECH', 7.0), ('TM', 'AR', 2.0),\n  ('TM', 'FR', 2.0), ('TM', 'EN', 2.0), ('TM', 'HG', 2.0), ('TM', 'ISL', 2.0),\n  ('TM', 'PHIL', 2.0), ('TM', 'SPORT', 1.0),\n  ('GE', 'GMF', 6.0), ('GE', 'ECO', 5.0), ('GE', 'MATH', 5.0), ('GE', 'LAW', 2.0),\n  ('GE', 'HG', 3.0), ('GE', 'AR', 3.0), ('GE', 'FR', 2.0), ('GE', 'EN', 2.0),\n  ('GE', 'ISL', 2.0), ('GE', 'PHIL', 2.0), ('GE', 'SPORT', 1.0),\n  ('LIT', 'AR', 6.0), ('LIT', 'PHIL', 6.0), ('LIT', 'HG', 4.0), ('LIT', 'FR', 3.0),\n  ('LIT', 'EN', 3.0), ('LIT', 'ISL', 2.0), ('LIT', 'MATH', 2.0), ('LIT', 'SPORT', 1.0),\n  ('LANG', 'AR', 3.0), ('LANG', 'FR', 5.0), ('LANG', 'EN', 5.0), ('LANG', 'DE', 4.0),\n  ('LANG', 'PHIL', 2.0), ('LANG', 'HG', 2.0), ('LANG', 'ISL', 2.0), ('LANG', 'MATH', 2.0),\n  ('LANG', 'SPORT', 1.0)\n) as v(stream_code, subject_code, coef)\njoin streams s on s.code = v.stream_code\njoin subjects sub on sub.code = v.subject_code;\n\ninsert into schools (name, wilaya) values\n  ('ثانوية الأمير عبد القادر', 'الجزائر'),\n  ('ثانوية ابن خلدون', 'وهران'),\n  ('ثانوية الإخوة عباس', 'قسنطينة'),\n  ('ثانوية مولود معمري', 'تيزي وزو'),\n  ('ثانوية العقيد لطفي', 'وهران'),\n  ('ثانوية عائشة أم المؤمنين', 'سطيف');\n\ninsert into exam_sessions (year, kind, label_ar) values\n  (2025, 'normale', 'الدورة العادية — جوان 2025');\n\ninsert into students (\n  exam_number, first_name, last_name, birth_date, birth_place, gender,\n  school_id, stream_id, session_id\n)\nselect\n  v.exam_number, v.first_name, v.last_name, v.birth_date::date, v.birth_place, v.gender,\n  sch.id, st.id, ses.id\nfrom (values\n  ('2025-100001', 'ياسين', 'بن عمر', '2007-03-12', 'الجزائر', 'male', 'ثانوية الأمير عبد القادر', 'SCI'),\n  ('2025-100002', 'أمينة', 'بوزيد', '2007-07-21', 'وهران', 'female', 'ثانوية ابن خلدون', 'SCI'),\n  ('2025-100003', 'محمد', 'لخضر', '2006-11-04', 'قسنطينة', 'male', 'ثانوية الإخوة عباس', 'SCI'),\n  ('2025-100004', 'سارة', 'مرابط', '2007-01-18', 'تيزي وزو', 'female', 'ثانوية مولود معمري', 'MATH'),\n  ('2025-100005', 'كريم', 'حداد', '2007-05-09', 'وهران', 'male', 'ثانوية العقيد لطفي', 'MATH'),\n  ('2025-100006', 'ندى', 'بلقاسم', '2006-09-30', 'سطيف', 'female', 'ثانوية عائشة أم المؤمنين', 'MATH'),\n  ('2025-100007', 'علي', 'بن صالح', '2007-02-14', 'الجزائر', 'male', 'ثانوية الأمير عبد القادر', 'GE'),\n  ('2025-100008', 'ليلى', 'عثماني', '2007-08-02', 'وهران', 'female', 'ثانوية ابن خلدون', 'GE'),\n  ('2025-100009', 'حمزة', 'قريشي', '2006-12-19', 'قسنطينة', 'male', 'ثانوية الإخوة عباس', 'GE'),\n  ('2025-100010', 'فاطمة الزهراء', 'بن عيسى', '2007-04-25', 'تيزي وزو', 'female', 'ثانوية مولود معمري', 'LIT'),\n  ('2025-100011', 'رضا', 'مسعودي', '2007-06-11', 'وهران', 'male', 'ثانوية العقيد لطفي', 'LIT'),\n  ('2025-100012', 'إيناس', 'شريف', '2006-10-07', 'سطيف', 'female', 'ثانوية عائشة أم المؤمنين', 'LIT'),\n  ('2025-100013', 'يوسف', 'عباسي', '2007-03-03', 'الجزائر', 'male', 'ثانوية الأمير عبد القادر', 'LANG'),\n  ('2025-100014', 'مريم', 'تواتي', '2007-09-16', 'وهران', 'female', 'ثانوية ابن خلدون', 'LANG'),\n  ('2025-100015', 'عادل', 'بوطالب', '2006-08-28', 'قسنطينة', 'male', 'ثانوية الإخوة عباس', 'TM'),\n  ('2025-100016', 'خديجة', 'عماري', '2007-01-05', 'تيزي وزو', 'female', 'ثانوية مولود معمري', 'TM'),\n  ('2025-100017', 'إسماعيل', 'زروال', '2007-05-22', 'الجزائر', 'male', 'ثانوية الأمير عبد القادر', 'SCI'),\n  ('2025-100018', 'هدى', 'بن عيسى', '2006-07-13', 'سطيف', 'female', 'ثانوية عائشة أم المؤمنين', 'MATH')\n) as v(exam_number, first_name, last_name, birth_date, birth_place, gender, school_name, stream_code)\njoin schools sch on sch.name = v.school_name\njoin streams st on st.code = v.stream_code\ncross join exam_sessions ses;\n\ninsert into grades (student_id, subject_id, score)\nselect\n  s.id,\n  ss.subject_id,\n  round(\n    least(20, greatest(2,\n      t.target + ((((ss.subject_id * 5) + (s.id * 3)) % 9) - 4) * 0.55\n    ))::numeric,\n    2\n  )\nfrom students s\njoin stream_subjects ss on ss.stream_id = s.stream_id\njoin (values\n  ('2025-100001', 16.80),\n  ('2025-100002', 14.40),\n  ('2025-100003', 11.20),\n  ('2025-100004', 17.10),\n  ('2025-100005', 13.10),\n  ('2025-100006', 8.60),\n  ('2025-100007', 15.40),\n  ('2025-100008', 12.30),\n  ('2025-100009', 8.40),\n  ('2025-100010', 16.70),\n  ('2025-100011', 11.10),\n  ('2025-100012', 13.50),\n  ('2025-100013', 14.90),\n  ('2025-100014', 10.20),\n  ('2025-100015', 15.80),\n  ('2025-100016', 12.10),\n  ('2025-100017', 18.10),\n  ('2025-100018', 10.40)\n) as t(exam_number, target) on t.exam_number = s.exam_number;\n\ninsert into results (student_id, average, mention, decision, certificate_number, issued_at)\nselect\n  s.id,\n  a.avg,\n  case\n    when a.avg >= 16 then 'امتياز'\n    when a.avg >= 14 then 'جيد جداً'\n    when a.avg >= 12 then 'جيد'\n    when a.avg >= 10 then 'قريب من الجيد'\n    else 'بدون تقدير'\n  end,\n  case when a.avg >= 10 then 'ناجح' else 'راسب' end,\n  case when a.avg >= 10 then 'BAC/2025/' || lpad(s.id::text, 5, '0') else null end,\n  case when a.avg >= 10 then now() else null end\nfrom students s\njoin (\n  select\n    g.student_id,\n    round(\n      (sum(g.score * ss.coefficient) / nullif(sum(ss.coefficient), 0))::numeric,\n      2\n    ) as avg\n  from grades g\n  join students st on st.id = g.student_id\n  join stream_subjects ss\n    on ss.stream_id = st.stream_id and ss.subject_id = g.subject_id\n  group by g.student_id\n) a on a.student_id = s.id;\n";
/**
* Migration bookkeeping shared by the two appliers — `scripts/migrate.mjs`
* (deploy, `readdir`) and `src/lib/db.ts` (PGLite preview, `import.meta.glob`).
*
* Applied files are keyed by BASENAME, so the same file applies once no matter
* which directory it is globbed from. That is what makes the auth schema safe to
* copy from `migrations/auth/` into `migrations/` when an app turns sign-in on:
* a database that already has `0001_auth.sql` will not re-run it.
*
* Neither applier descends into subdirectories, so `migrations/auth/*.sql` is
* out of scope for both until it is copied up.
*/
/**
* The `_migrations` key for a migration path (or bare filename).
* @param {string} path
* @returns {string}
*/
function migrationName(path) {
	return path.split("/").pop() ?? path;
}
/**
* @param {string} path
* @returns {boolean}
*/
function isMigrationFile(path) {
	return path.endsWith(".sql");
}
/**
* Migrations in `paths` that are not yet in `applied`, in apply order.
* Non-`.sql` entries (a `readdir` also yields `migrations/auth/`) are dropped.
* @param {Iterable<string>} paths
* @param {Iterable<string>} applied
* @returns {Array<{ name: string, path: string }>}
*/
function pendingMigrations(paths, applied) {
	const done = new Set(applied);
	return [...paths].filter(isMigrationFile).map((path) => ({
		name: migrationName(path),
		path
	})).sort((a, b) => a.name.localeCompare(b.name)).filter(({ name }) => !done.has(name));
}
var rawDatabaseUrl = typeof process !== "undefined" ? process.env.DATABASE_URL : void 0;
var databaseUrl = rawDatabaseUrl && rawDatabaseUrl.trim() ? rawDatabaseUrl : void 0;
/**
* Active backend: real **Neon** when `DATABASE_URL` is set (deployed / configured
* sandbox), otherwise a local embedded **PGLite** (Postgres compiled to WASM) so
* the app has a working database even with nothing configured — the live preview
* included. Swap in Neon later by just setting `DATABASE_URL`; no code changes.
*/
var dbSource = databaseUrl ? "neon" : "pglite";
/**
* Init state lives on globalThis as promises: dev HMR creates new instances of
* this module, and two instances racing module-level state would open a second
* pool or run two concurrent PGLite migration passes (whose duplicate
* `_migrations` insert rejects — and would get memoized, poisoning every later
* `getSql()`). A failed init clears its slot so the next call retries.
*/
var globalRef = globalThis;
/**
* Result-type parity: Postgres sends every value as text plus a type OID — the
* JS value is the DRIVER's parsing choice, and pg and PGLite disagree (pg:
* int8 -> string, date -> local-midnight Date; PGLite: int8 -> BigInt, which
* JSON.stringify rejects, date -> UTC Date). Normalize both so preview and
* production return identical, JSON-safe shapes:
*   int8/bigint (incl. count(*)) -> number (past 2^53 loses precision — cast
*                                   `::text` if you ever need huge integers)
*   date                         -> 'YYYY-MM-DD' string
*   interval                     -> Postgres interval text
* numeric already comes back as a string on both (arbitrary precision).
*/
var OID_INT8 = 20;
var OID_DATE = 1082;
var OID_INTERVAL = 1186;
var identity = (v) => v;
/** Wrap a query runner in the tagged-template + `.query()` `Sql` surface. */
function toSql(run) {
	const sql = (async (strings, ...values) => {
		let text = strings[0];
		for (let i = 0; i < values.length; i += 1) text += `$${i + 1}${strings[i + 1]}`;
		return run(text, values);
	});
	sql.query = (text, params = []) => run(text, params);
	return sql;
}
function createNeonSql() {
	globalRef.__pgSqlPromise__ ??= (async () => {
		const { Pool, types } = await import("../_libs/pg.mjs").then((n) => n.t);
		types.setTypeParser(OID_INT8, Number);
		types.setTypeParser(OID_DATE, identity);
		types.setTypeParser(OID_INTERVAL, identity);
		const pool = new Pool({ connectionString: databaseUrl });
		return toSql(async (text, params) => {
			return (await pool.query(text, params)).rows;
		});
	})().catch((err) => {
		globalRef.__pgSqlPromise__ = void 0;
		throw err;
	});
	return globalRef.__pgSqlPromise__;
}
async function createPgliteSql() {
	globalRef.__pgliteInstance__ ??= (async () => {
		const { PGlite } = await import("../_libs/electric-sql__pglite.mjs").then((n) => n.t);
		const pg = new PGlite({ parsers: {
			[OID_INT8]: Number,
			[OID_DATE]: identity,
			[OID_INTERVAL]: identity
		} });
		await pg.waitReady;
		await pg.exec("create table if not exists _migrations (name text primary key, applied_at timestamptz not null default now())");
		return pg;
	})().catch((err) => {
		globalRef.__pgliteInstance__ = void 0;
		throw err;
	});
	const pg = await globalRef.__pgliteInstance__;
	const migrate = async () => {
		const migrations = /* #__PURE__ */ Object.assign({ "/migrations/0002_bac.sql": _0002_bac_default });
		const done = (await pg.query("select name from _migrations")).rows.map((r) => r.name);
		for (const { name, path } of pendingMigrations(Object.keys(migrations), done)) await pg.transaction(async (tx) => {
			await tx.exec(migrations[path]);
			await tx.query("insert into _migrations (name) values ($1)", [name]);
		});
	};
	const pass = (globalRef.__pgliteMigrateChain__ ?? Promise.resolve()).catch(() => void 0).then(migrate);
	globalRef.__pgliteMigrateChain__ = pass;
	await pass;
	return toSql(async (text, params) => {
		return (await pg.query(text, params)).rows;
	});
}
var sqlPromise = null;
async function createSql() {
	if (typeof window !== "undefined") throw new Error("@/lib/db is server-only — call getSql() from a createServerFn handler or a server route loader, never from client code.");
	return dbSource === "neon" ? createNeonSql() : createPgliteSql();
}
/**
* Get the shared, **server-only** SQL client. Neon when `DATABASE_URL` is set,
* otherwise the local PGLite fallback. Memoized — safe to call per request.
*
* Schema comes from `migrations/*.sql`, auto-applied before the first query on
* both backends — define tables there, never inline in server functions.
*/
function getSql() {
	sqlPromise ??= createSql().catch((err) => {
		sqlPromise = null;
		throw err;
	});
	return sqlPromise;
}
/**
* Finish DB bootstrap before the server handles traffic.
*
* - **PGLite** (preview / no `DATABASE_URL`): open the in-memory DB and apply
*   `migrations/*.sql`. Idempotent — concurrent callers share one promise.
* - **Neon**: no-op (pool is created lazily on first query).
*
* Vite `configureServer` awaits this at dev startup; production imports of this
* module kick it off immediately (see bottom of file).
*/
function ensureDbReady() {
	if (dbSource !== "pglite") return Promise.resolve();
	return getSql().then(() => void 0);
}
var globalBoot = globalThis;
if (typeof window === "undefined" && dbSource === "pglite") globalBoot.__pgBootstrapPromise__ ??= ensureDbReady().catch((err) => {
	globalBoot.__pgBootstrapPromise__ = void 0;
	console.error("[db] PGLite bootstrap failed:", err);
	throw err;
});
function asDecision(value) {
	if (value === "ناجح" || value === "راسب") return value;
	return null;
}
function asGender(value) {
	return value === "female" ? "female" : "male";
}
function mapStudent(row) {
	return {
		id: row.id,
		examNumber: row.exam_number,
		firstName: row.first_name,
		lastName: row.last_name,
		gender: asGender(row.gender),
		schoolName: row.school_name,
		wilaya: row.wilaya,
		streamName: row.stream_name,
		streamId: row.stream_id,
		sessionLabel: row.session_label,
		average: row.average == null ? null : toNumber(row.average),
		mention: row.mention,
		decision: asDecision(row.decision),
		certificateNumber: row.certificate_number
	};
}
var STUDENT_SELECT = `
  select
    s.id,
    s.exam_number,
    s.first_name,
    s.last_name,
    s.gender,
    sch.name as school_name,
    sch.wilaya,
    st.name_ar as stream_name,
    st.id as stream_id,
    ses.label_ar as session_label,
    r.average,
    r.mention,
    r.decision,
    r.certificate_number
  from students s
  join schools sch on sch.id = s.school_id
  join streams st on st.id = s.stream_id
  join exam_sessions ses on ses.id = s.session_id
  left join results r on r.student_id = s.id
`;
async function recomputeResult(studentId) {
	const sql = await getSql();
	const row = (await sql.query(`select
       round((sum(g.score * ss.coefficient) / nullif(sum(ss.coefficient), 0))::numeric, 2) as avg,
       (select count(*)::int from stream_subjects where stream_id = s.stream_id) as expected,
       count(g.subject_id)::int as filled
     from students s
     left join stream_subjects ss on ss.stream_id = s.stream_id
     left join grades g on g.student_id = s.id and g.subject_id = ss.subject_id
     where s.id = $1
     group by s.id, s.stream_id`, [studentId]))[0];
	if (!row || row.avg == null || row.filled !== row.expected) {
		await sql.query(`delete from results where student_id = $1`, [studentId]);
		return null;
	}
	const average = toNumber(row.avg);
	const { mention, decision } = mentionFromAverage(average);
	const existing = await sql.query(`select certificate_number from results where student_id = $1`, [studentId]);
	const keepNumber = decision === "ناجح" ? existing[0]?.certificate_number ?? null : null;
	await sql.query(`insert into results (student_id, average, mention, decision, certificate_number, issued_at)
     values ($1, $2, $3, $4, $5, case when $5 is not null then now() else null end)
     on conflict (student_id) do update set
       average = excluded.average,
       mention = excluded.mention,
       decision = excluded.decision,
       certificate_number = excluded.certificate_number,
       issued_at = case
         when excluded.certificate_number is null then null
         when results.certificate_number is not null then results.issued_at
         else now()
       end`, [
		studentId,
		average.toFixed(2),
		mention,
		decision,
		keepNumber
	]);
	return {
		average,
		mention,
		decision,
		certificateNumber: keepNumber
	};
}
var listStreams_createServerFn_handler = createServerRpc({
	id: "9475f68f37106d41bba5fba3f60185a50fa216c332b7369d612d4b2e64d94ac2",
	name: "listStreams",
	filename: "src/lib/bac/server.ts"
}, (opts) => listStreams.__executeServer(opts));
var listStreams = createServerFn({ method: "GET" }).handler(listStreams_createServerFn_handler, async () => {
	return (await (await getSql()).query(`select id, code, name_ar from streams order by id`)).map((r) => ({
		id: r.id,
		code: r.code,
		nameAr: r.name_ar
	}));
});
var listSchools_createServerFn_handler = createServerRpc({
	id: "dcdeddd960647df7bcbd70c09bcdadd8a24617122d8a49c555a6de6432bc0560",
	name: "listSchools",
	filename: "src/lib/bac/server.ts"
}, (opts) => listSchools.__executeServer(opts));
var listSchools = createServerFn({ method: "GET" }).handler(listSchools_createServerFn_handler, async () => {
	return (await (await getSql()).query(`select id, name, wilaya from schools order by wilaya, name`)).map((r) => ({
		id: r.id,
		name: r.name,
		wilaya: r.wilaya
	}));
});
var listSessions_createServerFn_handler = createServerRpc({
	id: "ec3bca5de6ec7dfcf13f9c29c1578e1c2d79a1fbfc3dffc45fa4d3a9f09a6896",
	name: "listSessions",
	filename: "src/lib/bac/server.ts"
}, (opts) => listSessions.__executeServer(opts));
var listSessions = createServerFn({ method: "GET" }).handler(listSessions_createServerFn_handler, async () => {
	return (await (await getSql()).query(`select id, year, kind, label_ar from exam_sessions order by year desc, id`)).map((r) => ({
		id: r.id,
		year: r.year,
		kind: r.kind,
		labelAr: r.label_ar
	}));
});
var getDashboard_createServerFn_handler = createServerRpc({
	id: "06f85f4c1a22b004f246384759d6530c08a62b5d0ddf3f0377cfb5eb293253d6",
	name: "getDashboard",
	filename: "src/lib/bac/server.ts"
}, (opts) => getDashboard.__executeServer(opts));
var getDashboard = createServerFn({ method: "GET" }).handler(getDashboard_createServerFn_handler, async () => {
	const sql = await getSql();
	const [totals] = await sql.query(`select
         (select count(*)::int from students) as candidates,
         (select count(*)::int from results where decision = 'ناجح') as passed,
         (select count(*)::int from results where decision = 'راسب') as failed,
         (select count(*)::int from students s left join results r on r.student_id = s.id where r.student_id is null) as pending,
         (select count(*)::int from results where mention = 'امتياز') as excellence,
         (select label_ar from exam_sessions order by year desc, id desc limit 1) as session_label`);
	const candidates = totals?.candidates ?? 0;
	const passed = totals?.passed ?? 0;
	const mentions = await sql.query(`select mention, count(*)::int as count from results group by mention order by min(average) desc`);
	const streams = await sql.query(`select
         st.name_ar as stream_name,
         count(s.id)::int as candidates,
         count(r.student_id) filter (where r.decision = 'ناجح')::int as passed
       from streams st
       left join students s on s.stream_id = st.id
       left join results r on r.student_id = s.id
       group by st.id, st.name_ar
       order by st.id`);
	const top = await sql.query(`${STUDENT_SELECT}
       where r.decision = 'ناجح'
       order by r.average desc, s.last_name
       limit 5`);
	return {
		candidates,
		passed,
		failed: totals?.failed ?? 0,
		pending: totals?.pending ?? 0,
		passRate: candidates ? passed / candidates * 100 : 0,
		excellence: totals?.excellence ?? 0,
		mentions: mentions.map((m) => ({
			mention: m.mention,
			count: m.count
		})),
		streams: streams.map((s) => ({
			streamName: s.stream_name,
			candidates: s.candidates,
			passed: s.passed,
			passRate: s.candidates ? s.passed / s.candidates * 100 : 0
		})),
		topStudents: top.map(mapStudent),
		sessionLabel: totals?.session_label ?? "دورة البكالوريا"
	};
});
var listFilterSchema = object({
	q: string().optional(),
	streamId: number().int().positive().optional(),
	schoolId: number().int().positive().optional(),
	decision: _enum([
		"ناجح",
		"راسب",
		"قيد الإدخال"
	]).optional()
});
var listStudents_createServerFn_handler = createServerRpc({
	id: "e9ce8e93f59e96b17f4fe674bee589493ca9760f369ccf67666ddb35296892dc",
	name: "listStudents",
	filename: "src/lib/bac/server.ts"
}, (opts) => listStudents.__executeServer(opts));
var listStudents = createServerFn({ method: "GET" }).validator(listFilterSchema).handler(listStudents_createServerFn_handler, async ({ data }) => {
	const sql = await getSql();
	const clauses = ["1=1"];
	const params = [];
	if (data.q?.trim()) {
		params.push(`%${data.q.trim()}%`);
		clauses.push(`(s.exam_number ilike $${params.length} or s.first_name ilike $${params.length} or s.last_name ilike $${params.length} or (s.last_name || ' ' || s.first_name) ilike $${params.length})`);
	}
	if (data.streamId) {
		params.push(data.streamId);
		clauses.push(`s.stream_id = $${params.length}`);
	}
	if (data.schoolId) {
		params.push(data.schoolId);
		clauses.push(`s.school_id = $${params.length}`);
	}
	if (data.decision === "قيد الإدخال") clauses.push(`r.student_id is null`);
	else if (data.decision) {
		params.push(data.decision);
		clauses.push(`r.decision = $${params.length}`);
	}
	return (await sql.query(`${STUDENT_SELECT}
       where ${clauses.join(" and ")}
       order by s.last_name, s.first_name`, params)).map(mapStudent);
});
var listResults_createServerFn_handler = createServerRpc({
	id: "9a1fe0f59c8a7b3a8fce374b0d1f25c2ff114ed88938891115203c2a7798bcbf",
	name: "listResults",
	filename: "src/lib/bac/server.ts"
}, (opts) => listResults.__executeServer(opts));
var listResults = createServerFn({ method: "GET" }).validator(listFilterSchema).handler(listResults_createServerFn_handler, async ({ data }) => {
	const sql = await getSql();
	const clauses = ["r.student_id is not null"];
	const params = [];
	if (data.q?.trim()) {
		params.push(`%${data.q.trim()}%`);
		clauses.push(`(s.exam_number ilike $${params.length} or s.first_name ilike $${params.length} or s.last_name ilike $${params.length})`);
	}
	if (data.streamId) {
		params.push(data.streamId);
		clauses.push(`s.stream_id = $${params.length}`);
	}
	if (data.schoolId) {
		params.push(data.schoolId);
		clauses.push(`s.school_id = $${params.length}`);
	}
	if (data.decision === "ناجح" || data.decision === "راسب") {
		params.push(data.decision);
		clauses.push(`r.decision = $${params.length}`);
	}
	return (await sql.query(`${STUDENT_SELECT}
       where ${clauses.join(" and ")}
       order by r.average desc nulls last, s.last_name`, params)).map(mapStudent);
});
var getStudent_createServerFn_handler = createServerRpc({
	id: "d5e3c26bcb0cec5275f60bd57911215da6f4408a38d049f475ccdd255ecdc8de",
	name: "getStudent",
	filename: "src/lib/bac/server.ts"
}, (opts) => getStudent.__executeServer(opts));
var getStudent = createServerFn({ method: "GET" }).validator(object({ id: number$1() })).handler(getStudent_createServerFn_handler, async ({ data }) => {
	const sql = await getSql();
	const row = (await sql.query(`select
         s.id, s.exam_number, s.first_name, s.last_name, s.gender,
         s.birth_date, s.birth_place, s.school_id, s.session_id,
         sch.name as school_name, sch.wilaya,
         st.name_ar as stream_name, st.id as stream_id,
         ses.label_ar as session_label,
         r.average, r.mention, r.decision, r.certificate_number
       from students s
       join schools sch on sch.id = s.school_id
       join streams st on st.id = s.stream_id
       join exam_sessions ses on ses.id = s.session_id
       left join results r on r.student_id = s.id
       where s.id = $1`, [data.id]))[0];
	if (!row) return null;
	const mapped = (await sql.query(`select
         ss.subject_id,
         sub.name_ar,
         ss.coefficient,
         g.score
       from stream_subjects ss
       join subjects sub on sub.id = ss.subject_id
       left join grades g on g.subject_id = ss.subject_id and g.student_id = $1
       where ss.stream_id = $2
       order by ss.coefficient desc, sub.name_ar`, [data.id, row.stream_id])).map((g) => ({
		subjectId: g.subject_id,
		nameAr: g.name_ar,
		coefficient: toNumber(g.coefficient),
		score: g.score == null ? null : toNumber(g.score)
	}));
	return {
		...mapStudent(row),
		birthDate: row.birth_date,
		birthPlace: row.birth_place,
		schoolId: row.school_id,
		sessionId: row.session_id,
		grades: mapped,
		totalCoefficient: mapped.reduce((sum, g) => sum + g.coefficient, 0)
	};
});
var studentInput = object({
	firstName: string().trim().min(2).max(80),
	lastName: string().trim().min(2).max(80),
	birthDate: string().regex(/^\d{4}-\d{2}-\d{2}$/),
	birthPlace: string().trim().min(2).max(80),
	gender: _enum(["male", "female"]),
	schoolId: number$1(),
	streamId: number$1(),
	sessionId: number$1().optional()
});
var createStudent_createServerFn_handler = createServerRpc({
	id: "13e7c780c54639e8e96bfb8c4385f57c4dd7181ac7ba77a02709a9daf28e7368",
	name: "createStudent",
	filename: "src/lib/bac/server.ts"
}, (opts) => createStudent.__executeServer(opts));
var createStudent = createServerFn({ method: "POST" }).validator(studentInput).handler(createStudent_createServerFn_handler, async ({ data }) => {
	const sql = await getSql();
	const [session] = data.sessionId ? await sql.query(`select id, year from exam_sessions where id = $1`, [data.sessionId]) : await sql.query(`select id, year from exam_sessions order by year desc, id desc limit 1`);
	if (!session) throw new Error("لا توجد دورة امتحان مسجّلة");
	const [next] = await sql.query(`select coalesce(max(id), 0)::int + 1 as n from students`);
	const examNumber = `${session.year}-${String(1e5 + (next?.n ?? 1)).slice(-6)}`;
	return {
		id: (await sql.query(`insert into students (
         exam_number, first_name, last_name, birth_date, birth_place, gender,
         school_id, stream_id, session_id
       ) values ($1,$2,$3,$4,$5,$6,$7,$8,$9)
       returning id`, [
			examNumber,
			data.firstName,
			data.lastName,
			data.birthDate,
			data.birthPlace,
			data.gender,
			data.schoolId,
			data.streamId,
			session.id
		]))[0].id,
		examNumber
	};
});
var updateStudent_createServerFn_handler = createServerRpc({
	id: "4059c6a0efae7f6d29f93551cb7574116b36b80470e8bf271fe258faf2b26c70",
	name: "updateStudent",
	filename: "src/lib/bac/server.ts"
}, (opts) => updateStudent.__executeServer(opts));
var updateStudent = createServerFn({ method: "POST" }).validator(studentInput.extend({ id: number$1() })).handler(updateStudent_createServerFn_handler, async ({ data }) => {
	const sql = await getSql();
	await sql.query(`update students set
         first_name = $2, last_name = $3, birth_date = $4, birth_place = $5,
         gender = $6, school_id = $7, stream_id = $8
       where id = $1`, [
		data.id,
		data.firstName,
		data.lastName,
		data.birthDate,
		data.birthPlace,
		data.gender,
		data.schoolId,
		data.streamId
	]);
	await sql.query(`delete from grades g
       using students s
       where g.student_id = s.id and s.id = $1
         and g.subject_id not in (
           select subject_id from stream_subjects where stream_id = s.stream_id
         )`, [data.id]);
	await recomputeResult(data.id);
	return { ok: true };
});
var deleteStudent_createServerFn_handler = createServerRpc({
	id: "5c6d5e25fa5c09cb14cc4416f0866469ca121af3f940293c17899b14c972508d",
	name: "deleteStudent",
	filename: "src/lib/bac/server.ts"
}, (opts) => deleteStudent.__executeServer(opts));
var deleteStudent = createServerFn({ method: "POST" }).validator(object({ id: number$1() })).handler(deleteStudent_createServerFn_handler, async ({ data }) => {
	await (await getSql()).query(`delete from students where id = $1`, [data.id]);
	return { ok: true };
});
var saveGrades_createServerFn_handler = createServerRpc({
	id: "8df3ed271276bc39937e46a56539d876ade58f0d26b05115ba08b8d7ce1cb0c5",
	name: "saveGrades",
	filename: "src/lib/bac/server.ts"
}, (opts) => saveGrades.__executeServer(opts));
var saveGrades = createServerFn({ method: "POST" }).validator(object({
	studentId: number$1(),
	grades: array(object({
		subjectId: number$1(),
		score: number$1().min(0).max(20)
	}))
})).handler(saveGrades_createServerFn_handler, async ({ data }) => {
	const sql = await getSql();
	const allowed = await sql.query(`select ss.subject_id
       from stream_subjects ss
       join students s on s.stream_id = ss.stream_id
       where s.id = $1`, [data.studentId]);
	const allowedIds = new Set(allowed.map((r) => r.subject_id));
	for (const grade of data.grades) {
		if (!allowedIds.has(grade.subjectId)) continue;
		const score = Math.round(grade.score * 100) / 100;
		await sql.query(`insert into grades (student_id, subject_id, score)
         values ($1, $2, $3)
         on conflict (student_id, subject_id) do update set score = excluded.score`, [
			data.studentId,
			grade.subjectId,
			score.toFixed(2)
		]);
	}
	return {
		ok: true,
		result: await recomputeResult(data.studentId)
	};
});
var issueCertificate_createServerFn_handler = createServerRpc({
	id: "06ab3a35b1bf0afd89f4d7ecf689209f2b0dac973a3de7835226b7a4cf6cb8aa",
	name: "issueCertificate",
	filename: "src/lib/bac/server.ts"
}, (opts) => issueCertificate.__executeServer(opts));
var issueCertificate = createServerFn({ method: "POST" }).validator(object({ studentId: number$1() })).handler(issueCertificate_createServerFn_handler, async ({ data }) => {
	const sql = await getSql();
	const [row] = await sql.query(`select r.decision, r.certificate_number, ses.year
       from results r
       join students s on s.id = r.student_id
       join exam_sessions ses on ses.id = s.session_id
       where r.student_id = $1`, [data.studentId]);
	if (!row || row.decision !== "ناجح") throw new Error("لا يمكن إصدار الشهادة إلا للمترشح الناجح بعد اكتمال العلامات");
	if (row.certificate_number) return { certificateNumber: row.certificate_number };
	const number = `BAC/${row.year}/${String(data.studentId).padStart(5, "0")}`;
	await sql.query(`update results
       set certificate_number = $2, issued_at = now()
       where student_id = $1`, [data.studentId, number]);
	return { certificateNumber: number };
});
var createSchool_createServerFn_handler = createServerRpc({
	id: "1c26f6040edfe1a3f8f06a72ad2014b58c9c81e612665ac3ffc14cc68f8621cf",
	name: "createSchool",
	filename: "src/lib/bac/server.ts"
}, (opts) => createSchool.__executeServer(opts));
var createSchool = createServerFn({ method: "POST" }).validator(object({
	name: string().trim().min(3).max(120),
	wilaya: string().trim().min(2).max(40)
})).handler(createSchool_createServerFn_handler, async ({ data }) => {
	return { id: (await (await getSql()).query(`insert into schools (name, wilaya) values ($1, $2) returning id`, [data.name, data.wilaya]))[0].id };
});
//#endregion
export { createSchool_createServerFn_handler, createStudent_createServerFn_handler, deleteStudent_createServerFn_handler, getDashboard_createServerFn_handler, getStudent_createServerFn_handler, issueCertificate_createServerFn_handler, listResults_createServerFn_handler, listSchools_createServerFn_handler, listSessions_createServerFn_handler, listStreams_createServerFn_handler, listStudents_createServerFn_handler, saveGrades_createServerFn_handler, updateStudent_createServerFn_handler };
