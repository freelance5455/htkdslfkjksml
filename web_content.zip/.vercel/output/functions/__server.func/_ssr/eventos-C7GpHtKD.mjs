import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { t as FONTE_EVENTOS } from "./mercado-D-r3mUkE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/eventos-C7GpHtKD.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
async function pedir(ms) {
	const ctrl = new AbortController();
	const relogio = setTimeout(() => ctrl.abort(), ms);
	try {
		const resposta = await fetch(FONTE_EVENTOS, {
			signal: ctrl.signal,
			cache: "no-store",
			headers: { accept: "application/json" }
		});
		if (!resposta.ok) throw new Error(`HTTP ${resposta.status}`);
		return await resposta.json();
	} finally {
		clearTimeout(relogio);
	}
}
var obterEventos_createServerFn_handler = createServerRpc({
	id: "7a13a978ebe2a53a89112bdbfa61ed9e4a5275d9219fecb789c9a77eb8855a72",
	name: "obterEventos",
	filename: "src/lib/eventos.ts"
}, (opts) => obterEventos.__executeServer(opts));
var obterEventos = createServerFn({ method: "GET" }).handler(obterEventos_createServerFn_handler, async () => {
	let ultimo;
	for (let i = 0; i < 2; i++) try {
		return await pedir(i === 0 ? 12e3 : 8e3) ?? null;
	} catch (erro) {
		ultimo = erro;
	}
	const msg = ultimo instanceof Error ? ultimo.message : "sem resposta";
	throw new Error(msg.includes("abort") ? "ligação expirou" : msg);
});
//#endregion
export { obterEventos_createServerFn_handler };
