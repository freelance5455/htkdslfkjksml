import { i as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, q as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as History, i as PenLine, n as SquarePen, o as Download, r as RotateCcw } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-C0F9qXSI.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var generateApp = createServerFn({ method: "POST" }).validator((input) => {
	const brief = input.brief?.trim() ?? "";
	if (brief.length < 2 || brief.length > 4e3) throw new Error("Buyruq 2 dan 4000 belgigacha bo‘lsin.");
	return {
		brief,
		previousHtml: input.previousHtml?.slice(0, 1e5)
	};
}).handler(createSsrRpc("90073ec6aa25d1ea64f59d22344d2ce9fd4459e49cb25ad0afedb21bbae48303"));
var STARTERS = [
	{
		label: "Do‘kon",
		brief: "O‘zbekcha kichik bozor ilovasi: 8 ta mahsulot, qidiruv, savat va jami summa. Narxlar so‘mda. Mahsulot qo‘shish va olib tashlash ishlasin."
	},
	{
		label: "Kun tartibi",
		brief: "Kunlik reja: vazifa qo‘shish, belgilash, o‘chirish. Bugungi sana ko‘rinsin. Ma’lumot shu brauzerda saqlansin."
	},
	{
		label: "Menyu",
		brief: "Choyxona menyusi: taomlar bo‘limlari, narx, tanlangan taomlar ro‘yxati va hisob. Dizayn iliq, qog‘ozdek."
	},
	{
		label: "Viktorina",
		brief: "O‘zbekiston haqida 8 savollik viktorina. Har savolda 4 variant, oxirida ball va qayta boshlash."
	},
	{
		label: "Moliya",
		brief: "Oddiy xarajat daftari: kirim va chiqim qo‘shish, qoldiq, oxirgi 10 yozuv. So‘mda hisoblansin."
	},
	{
		label: "Eslatma",
		brief: "Rangli eslatmalar doskasi: yangi eslatma, tahrir, o‘chirish. Ma’lumot sahifani yangilaganda ham qolsin."
	}
];
var STORAGE_KEY = "cheksiz-shelf";
function readShelf() {
	try {
		const raw = localStorage.getItem(STORAGE_KEY);
		if (!raw) return [];
		const parsed = JSON.parse(raw);
		return Array.isArray(parsed) ? parsed.slice(0, 8) : [];
	} catch {
		return [];
	}
}
function titleOf(html, brief) {
	const title = html.match(/<title>([^<]{1,80})<\/title>/i)?.[1]?.trim();
	if (title) return title;
	return brief.slice(0, 42);
}
function Studio() {
	const [brief, setBrief] = (0, import_react.useState)(STARTERS[0].brief);
	const [note, setNote] = (0, import_react.useState)("");
	const [html, setHtml] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const [shelf, setShelf] = (0, import_react.useState)([]);
	const [showShelf, setShowShelf] = (0, import_react.useState)(false);
	const [frameKey, setFrameKey] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		setShelf(readShelf());
	}, []);
	const title = (0, import_react.useMemo)(() => html ? titleOf(html, brief) : "Hali sahifa yo‘q", [html, brief]);
	function persist(next) {
		const list = [next, ...readShelf().filter((item) => item.id !== next.id)].slice(0, 8);
		localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
		setShelf(list);
	}
	async function run(instruction, previous) {
		const text = instruction.trim();
		if (text.length < 2 || busy) return;
		setBusy(true);
		setError("");
		try {
			const result = await generateApp({ data: {
				brief: text,
				previousHtml: previous
			} });
			if (!result.ok) {
				setError(result.error);
				return;
			}
			setHtml(result.html);
			setFrameKey((n) => n + 1);
			setNote("");
			persist({
				id: crypto.randomUUID(),
				title: titleOf(result.html, text),
				brief: text,
				html: result.html
			});
		} catch {
			setError("Ulanish uzildi. Yana bir marta bosing.");
		} finally {
			setBusy(false);
		}
	}
	function download() {
		if (!html) return;
		const blob = new Blob([html], { type: "text/html;charset=utf-8" });
		const url = URL.createObjectURL(blob);
		const link = document.createElement("a");
		link.href = url;
		link.download = `${title.replace(/[^\p{L}\p{N}]+/gu, "-").replace(/^-|-$/g, "") || "ilova"}.html`;
		link.click();
		URL.revokeObjectURL(url);
	}
	function reset() {
		setHtml("");
		setNote("");
		setError("");
		setBrief("");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto grid min-h-screen w-full max-w-6xl grid-cols-1 gap-4 px-4 py-4 lg:grid-cols-[22rem_minmax(0,1fr)] lg:px-6 lg:py-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "flex min-w-0 flex-col gap-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "px-1 pt-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium tracking-widest text-copper uppercase",
							children: "Ustaxona"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-5xl leading-none font-medium text-ink",
							children: "Cheksiz"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 max-w-xs text-sm leading-relaxed text-muted",
							children: "Veb-ilovani so‘zlab bering. Kredit yo‘q — har safar yasash tugmasini bosing."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex w-full gap-2 overflow-x-auto pb-1",
					children: STARTERS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setBrief(item.brief),
						className: "shrink-0 rounded-full border border-line bg-paper px-3 py-2 text-sm text-ink",
						children: item.label
					}, item.label))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex flex-col gap-2 rounded-card border border-line bg-paper p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-2 text-sm font-medium",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, {
								className: "size-4 text-copper",
								"aria-hidden": "true"
							}), "Nima yasaymiz"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							value: brief,
							onChange: (event) => setBrief(event.target.value),
							rows: 7,
							placeholder: "Masalan: oilaviy taomlar daftari, retsept qo‘shish va qidiruv bilan.",
							className: "min-h-36 resize-none bg-transparent text-sm leading-relaxed outline-none"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							disabled: busy || brief.trim().length < 2,
							onClick: () => run(brief),
							className: "inline-flex h-12 items-center justify-center rounded-full bg-copper px-4 text-sm font-medium text-copper-ink disabled:opacity-50",
							children: busy ? "Terilmoqda…" : "Yasash"
						})
					]
				}),
				html ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex flex-col gap-2 rounded-card border border-line bg-paper p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-2 text-sm font-medium",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SquarePen, {
								className: "size-4 text-copper",
								"aria-hidden": "true"
							}), "Shu ilovani o‘zgartirish"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							value: note,
							onChange: (event) => setNote(event.target.value),
							rows: 3,
							placeholder: "Masalan: tun rejimini qo‘sh, tugmalarni kattaroq qil.",
							className: "resize-none bg-transparent text-sm leading-relaxed outline-none"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							disabled: busy || note.trim().length < 2,
							onClick: () => run(note, html),
							className: "inline-flex h-11 items-center justify-center rounded-full border border-ink px-4 text-sm font-medium disabled:opacity-50",
							children: "Qo‘llash"
						})
					]
				}) : null,
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-card border border-line bg-paper px-3 py-2 text-sm text-copper",
					role: "alert",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: download,
							disabled: !html,
							className: "inline-flex h-11 items-center gap-2 rounded-full border border-line bg-paper px-4 text-sm disabled:opacity-40",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
								className: "size-4",
								"aria-hidden": "true"
							}), "HTML"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setShowShelf((open) => !open),
							className: "inline-flex h-11 items-center gap-2 rounded-full border border-line bg-paper px-4 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, {
								className: "size-4",
								"aria-hidden": "true"
							}), "Javon"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: reset,
							className: "inline-flex h-11 items-center gap-2 rounded-full border border-line bg-paper px-4 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {
								className: "size-4",
								"aria-hidden": "true"
							}), "Toza"]
						})
					]
				}),
				showShelf ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex flex-col gap-2",
					children: shelf.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "text-sm text-muted",
						children: "Hali saqlangan ilova yo‘q."
					}) : shelf.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							setHtml(item.html);
							setBrief(item.brief);
							setFrameKey((n) => n + 1);
							setError("");
						},
						className: "w-full rounded-card border border-line bg-paper px-3 py-3 text-left",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-sm font-medium",
							children: item.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 block truncate text-xs text-muted",
							children: item.brief
						})]
					}) }, item.id))
				}) : null
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "flex min-h-[70vh] min-w-0 flex-col overflow-hidden rounded-card border border-line bg-ink",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3 px-4 py-3 text-copper-ink",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate font-display text-lg",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "shrink-0 text-xs tracking-wide text-line uppercase",
					children: "Ko‘rinish"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative min-h-0 flex-1 bg-paper",
				children: [html ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
					title,
					sandbox: "allow-scripts allow-forms",
					srcDoc: html,
					className: "h-full min-h-[70vh] w-full bg-paper"
				}, frameKey) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex h-full min-h-[70vh] flex-col justify-end p-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-4xl leading-tight text-ink",
						children: "Bo‘sh stanok."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 max-w-sm text-sm leading-relaxed text-muted",
						children: "Chapdan buyruq yozing yoki tayyor namunani bosing. Tayyor sahifa shu yerda ochiladi."
					})]
				}), busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute inset-x-0 top-0 h-1 overflow-hidden bg-line",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "bar-slide h-full w-1/3 bg-copper" })
				}) : null]
			})]
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Studio, {});
}
//#endregion
export { Home as component };
