import { i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { B as string, I as number, L as object, O as _enum } from "../_libs/@better-auth/core+[...].mjs";
import { r as getSql } from "./db-CuoF86Vo.mjs";
import { a as clip, i as authMiddleware, o as giftById, s as makeCode } from "./ids-CYIMMUy6.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/functions-BwDZ-6qR.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var peerIdSchema = string().regex(/^[a-zA-Z0-9_-]{1,64}$/);
function num(value) {
	const n = typeof value === "number" ? value : Number(value);
	return Number.isFinite(n) ? n : 0;
}
function asMode(value) {
	return value === "voice" ? "voice" : "video";
}
async function ensureProfile(sql, userId, hint) {
	const name = clip(hint ?? "", 32);
	await sql`
    insert into profiles (user_id, display_name, coins)
    values (${userId}, ${name || "Penonton"}, ${800})
    on conflict (user_id) do nothing
  `;
	if (name) await sql`
      update profiles
      set display_name = ${name}
      where user_id = ${userId} and display_name = 'Penonton'
    `;
	const row = (await sql`
    select p.display_name, p.bio, p.coins, p.earned,
      (p.claimed_on = current_date) as claimed_today,
      (select count(*)::int from follows f where f.host_id = p.user_id) as followers,
      (select count(*)::int from follows f where f.follower_id = p.user_id) as following
    from profiles p
    where p.user_id = ${userId}
  `)[0];
	return {
		displayName: row?.display_name ?? "Penonton",
		bio: row?.bio ?? "",
		coins: num(row?.coins),
		earned: num(row?.earned),
		claimedToday: Boolean(row?.claimed_today),
		followers: num(row?.followers),
		following: num(row?.following)
	};
}
async function liveCards(sql) {
	return (await sql`
    select r.id, r.title, r.topic, r.mode, r.hearts, r.gifts_value, r.host_id,
      p.display_name as host_name,
      (select count(*)::int from room_presence v
        where v.room_id = r.id and v.last_seen > now() - make_interval(secs => 15)) as viewers
    from live_rooms r
    join profiles p on p.user_id = r.host_id
    where r.status = 'live' and r.last_seen > now() - make_interval(secs => 20)
    order by r.gifts_value desc, r.hearts desc, r.started_at desc
    limit 40
  `).map((row) => ({
		id: row.id,
		title: row.title,
		topic: row.topic,
		mode: asMode(row.mode),
		hearts: num(row.hearts),
		giftsValue: num(row.gifts_value),
		viewers: num(row.viewers),
		hostId: row.host_id,
		hostName: row.host_name
	}));
}
function mapMessage(row) {
	const kind = row.kind === "gift" || row.kind === "system" ? row.kind : "chat";
	return {
		id: num(row.id),
		userId: row.user_id,
		name: row.display_name,
		kind,
		body: row.body,
		giftId: row.gift_id
	};
}
async function loadBattle(sql, battleId) {
	if (!battleId) return null;
	const row = (await sql`
    select id, room_a, room_b, name_a, name_b, score_a, score_b,
      extract(epoch from ends_at)::int as ends_at
    from battles where id = ${battleId}
  `)[0];
	if (!row) return null;
	return {
		id: row.id,
		roomA: row.room_a,
		roomB: row.room_b,
		nameA: row.name_a,
		nameB: row.name_b,
		scoreA: num(row.score_a),
		scoreB: num(row.score_b),
		endsAt: num(row.ends_at)
	};
}
var hintSchema = object({ displayName: string().max(80).optional() });
var lobbyState_createServerFn_handler = createServerRpc({
	id: "1857cf39fef8195636a677f3ed98c904fe4346da275e6b4405e9d15003bcca32",
	name: "lobbyState",
	filename: "src/lib/live/functions.ts"
}, (opts) => lobbyState.__executeServer(opts));
var lobbyState = createServerFn({ method: "POST" }).validator((input) => hintSchema.parse(input ?? {})).middleware([authMiddleware]).handler(lobbyState_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const me = await ensureProfile(sql, context.userId, data.displayName);
	const live = await liveCards(sql);
	const followed = await sql`
      select host_id from follows where follower_id = ${context.userId}
    `;
	const ids = new Set(followed.map((row) => row.host_id));
	return {
		ok: true,
		data: {
			me,
			live,
			following: live.filter((room) => ids.has(room.hostId)),
			board: live.slice(0, 10)
		}
	};
});
var profileSchema = object({
	displayName: string().max(80),
	bio: string().max(400)
});
var saveProfile_createServerFn_handler = createServerRpc({
	id: "ea1fe0e18872284f64518730be508cc99827dd456e333b29feb280cf42b511cd",
	name: "saveProfile",
	filename: "src/lib/live/functions.ts"
}, (opts) => saveProfile.__executeServer(opts));
var saveProfile = createServerFn({ method: "POST" }).validator((input) => profileSchema.parse(input)).middleware([authMiddleware]).handler(saveProfile_createServerFn_handler, async ({ context, data }) => {
	const displayName = clip(data.displayName, 32);
	const bio = clip(data.bio, 140);
	if (displayName.length < 2) return {
		ok: false,
		error: "Nama minimal 2 huruf."
	};
	const sql = await getSql();
	await ensureProfile(sql, context.userId);
	await sql`
      update profiles
      set display_name = ${displayName}, bio = ${bio}
      where user_id = ${context.userId}
    `;
	return {
		ok: true,
		data: await ensureProfile(sql, context.userId)
	};
});
var claimDaily_createServerFn_handler = createServerRpc({
	id: "c8e0806ce9b2a948a9cff2134d37f03e7475379d6a93896f087464b23abb1220",
	name: "claimDaily",
	filename: "src/lib/live/functions.ts"
}, (opts) => claimDaily.__executeServer(opts));
var claimDaily = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(claimDaily_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	await ensureProfile(sql, context.userId);
	if (!(await sql`
      update profiles
      set coins = coins + ${120}, claimed_on = current_date
      where user_id = ${context.userId}
        and (claimed_on is null or claimed_on < current_date)
      returning user_id
    `).length) return {
		ok: false,
		error: "Koin harian sudah diambil."
	};
	return {
		ok: true,
		data: await ensureProfile(sql, context.userId)
	};
});
var cashOut_createServerFn_handler = createServerRpc({
	id: "58f789622eba1ff4fc719a7e2f9ac07c55b0ee859f6c7f332a790050e8a54dc6",
	name: "cashOut",
	filename: "src/lib/live/functions.ts"
}, (opts) => cashOut.__executeServer(opts));
var cashOut = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(cashOut_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	await ensureProfile(sql, context.userId);
	if (!(await sql`
      update profiles
      set coins = coins + earned, earned = 0
      where user_id = ${context.userId} and earned > 0
      returning user_id
    `).length) return {
		ok: false,
		error: "Belum ada hasil untuk ditukar."
	};
	return {
		ok: true,
		data: await ensureProfile(sql, context.userId)
	};
});
var createSchema = object({
	title: string().max(200),
	topic: string().max(40),
	mode: _enum(["video", "voice"])
});
var createRoom_createServerFn_handler = createServerRpc({
	id: "81050f335a97708ab78d0c5ea575590a9d81a5be60d8be495c4f4b94efb02635",
	name: "createRoom",
	filename: "src/lib/live/functions.ts"
}, (opts) => createRoom.__executeServer(opts));
var createRoom = createServerFn({ method: "POST" }).validator((input) => createSchema.parse(input)).middleware([authMiddleware]).handler(createRoom_createServerFn_handler, async ({ context, data }) => {
	const title = clip(data.title, 60);
	const topic = clip(data.topic, 24) || "Ngobrol";
	if (title.length < 2) return {
		ok: false,
		error: "Judul siaran minimal 2 huruf."
	};
	const sql = await getSql();
	const me = await ensureProfile(sql, context.userId);
	await sql`
      update live_rooms set status = 'ended'
      where host_id = ${context.userId} and status = 'live'
    `;
	let id = "";
	for (let attempt = 0; attempt < 5; attempt += 1) {
		const next = makeCode(6);
		if (!(await sql`select id from live_rooms where id = ${next}`).length) {
			id = next;
			break;
		}
	}
	if (!id) return {
		ok: false,
		error: "Gagal membuat ruang. Coba lagi."
	};
	await sql`
      insert into live_rooms (id, host_id, host_peer, title, topic, mode)
      values (${id}, ${context.userId}, '', ${title}, ${topic}, ${data.mode})
    `;
	await sql`
      insert into room_messages (room_id, user_id, display_name, kind, body)
      values (${id}, ${context.userId}, ${me.displayName}, 'system', ${"Siaran dimulai"})
    `;
	return {
		ok: true,
		data: { id }
	};
});
var roomSchema = object({ roomId: string().regex(/^[a-z0-9]{4,12}$/) });
var endRoom_createServerFn_handler = createServerRpc({
	id: "08a0d39ec48d97ae1898f6d9562facded7a78a24eb72ae8bf86accb0ae844ff9",
	name: "endRoom",
	filename: "src/lib/live/functions.ts"
}, (opts) => endRoom.__executeServer(opts));
var endRoom = createServerFn({ method: "POST" }).validator((input) => roomSchema.parse(input)).middleware([authMiddleware]).handler(endRoom_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	if (!(await sql`
      update live_rooms set status = 'ended'
      where id = ${data.roomId} and host_id = ${context.userId} and status = 'live'
      returning id
    `).length) return {
		ok: false,
		error: "Siaran tidak ditemukan."
	};
	await sql`
      insert into room_messages (room_id, user_id, display_name, kind, body)
      select ${data.roomId}, ${context.userId}, display_name, 'system', 'Siaran selesai'
      from profiles where user_id = ${context.userId}
    `;
	return {
		ok: true,
		data: { ended: true }
	};
});
var pulseSchema = object({
	roomId: string().regex(/^[a-z0-9]{4,12}$/),
	afterId: number().int().min(0).max(1e9),
	peerId: peerIdSchema,
	displayName: string().max(80).optional()
});
var pulseRoom_createServerFn_handler = createServerRpc({
	id: "bdc354fee66346cc9cd17f1992b90a6574de9cc043c9e12a06d7768f98c95214",
	name: "pulseRoom",
	filename: "src/lib/live/functions.ts"
}, (opts) => pulseRoom.__executeServer(opts));
var pulseRoom = createServerFn({ method: "POST" }).validator((input) => pulseSchema.parse(input)).middleware([authMiddleware]).handler(pulseRoom_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const me = await ensureProfile(sql, context.userId, data.displayName);
	const found = (await sql`
      select r.id, r.title, r.topic, r.mode, r.hearts, r.gifts_value, r.pinned,
        r.host_id, r.host_peer, r.status, r.battle_id,
        extract(epoch from r.started_at)::int as started_at,
        p.display_name as host_name, p.bio as host_bio
      from live_rooms r
      join profiles p on p.user_id = r.host_id
      where r.id = ${data.roomId}
    `)[0];
	if (!found) return {
		ok: true,
		data: {
			me,
			following: false,
			room: null,
			messages: [],
			battle: null
		}
	};
	const live = found.status === "live";
	if (live && found.host_id === context.userId) {
		await sql`
        update live_rooms
        set last_seen = now(), host_peer = ${data.peerId}
        where id = ${data.roomId} and host_id = ${context.userId} and status = 'live'
      `;
		found.host_peer = data.peerId;
	}
	if (live) await sql`
        insert into room_presence (room_id, user_id, display_name, last_seen)
        values (${data.roomId}, ${context.userId}, ${me.displayName}, now())
        on conflict (room_id, user_id)
        do update set last_seen = now(), display_name = excluded.display_name
      `;
	const viewers = await sql`
      select display_name,
        (select count(*)::int from room_presence
          where room_id = ${data.roomId} and last_seen > now() - make_interval(secs => 15)) as n
      from room_presence
      where room_id = ${data.roomId} and last_seen > now() - make_interval(secs => 15)
      order by last_seen desc
      limit 8
    `;
	const followRows = await sql`
      select host_id from follows
      where follower_id = ${context.userId} and host_id = ${found.host_id}
    `;
	const fanRows = await sql`
      select count(*)::int as n from follows where host_id = ${found.host_id}
    `;
	const messages = await sql`
      select id, user_id, display_name, kind, body, gift_id
      from room_messages
      where room_id = ${data.roomId} and id > ${data.afterId}
      order by id asc
      limit 80
    `;
	const snap = (await sql`
      select hearts, gifts_value, pinned, host_peer from live_rooms where id = ${data.roomId}
    `)[0];
	const room = {
		id: found.id,
		title: found.title,
		topic: found.topic,
		mode: asMode(found.mode),
		hearts: num(snap?.hearts ?? found.hearts),
		giftsValue: num(snap?.gifts_value ?? found.gifts_value),
		pinned: snap?.pinned ?? found.pinned,
		hostId: found.host_id,
		hostName: found.host_name,
		hostBio: found.host_bio,
		hostPeer: snap?.host_peer || found.host_peer,
		viewerCount: num(viewers[0]?.n),
		viewerNames: viewers.map((row) => row.display_name),
		followerCount: num(fanRows[0]?.n),
		live,
		startedAt: num(found.started_at)
	};
	return {
		ok: true,
		data: {
			me,
			following: followRows.length > 0,
			room,
			messages: messages.map(mapMessage),
			battle: await loadBattle(sql, found.battle_id)
		}
	};
});
var chatSchema = object({
	roomId: string().regex(/^[a-z0-9]{4,12}$/),
	body: string().max(500)
});
var sendChat_createServerFn_handler = createServerRpc({
	id: "41a6dfb39dd82316e96658b150eb945629f275d86aeb7b4df7ac271379ab982f",
	name: "sendChat",
	filename: "src/lib/live/functions.ts"
}, (opts) => sendChat.__executeServer(opts));
var sendChat = createServerFn({ method: "POST" }).validator((input) => chatSchema.parse(input)).middleware([authMiddleware]).handler(sendChat_createServerFn_handler, async ({ context, data }) => {
	const body = clip(data.body, 200);
	if (!body) return {
		ok: false,
		error: "Pesan kosong."
	};
	const sql = await getSql();
	const me = await ensureProfile(sql, context.userId);
	if (!(await sql`
      select id from live_rooms where id = ${data.roomId} and status = 'live'
    `).length) return {
		ok: false,
		error: "Siaran sudah selesai."
	};
	const row = (await sql`
      insert into room_messages (room_id, user_id, display_name, kind, body)
      values (${data.roomId}, ${context.userId}, ${me.displayName}, 'chat', ${body})
      returning id, user_id, display_name, kind, body, gift_id
    `)[0];
	if (!row) return {
		ok: false,
		error: "Pesan gagal dikirim."
	};
	return {
		ok: true,
		data: mapMessage(row)
	};
});
var pinSchema = object({
	roomId: string().regex(/^[a-z0-9]{4,12}$/),
	text: string().max(300)
});
var pinNote_createServerFn_handler = createServerRpc({
	id: "478ff23a04d4f595517fa6bdf6b34cd0c9ceb95dede77cdc6a348b7739e1f532",
	name: "pinNote",
	filename: "src/lib/live/functions.ts"
}, (opts) => pinNote.__executeServer(opts));
var pinNote = createServerFn({ method: "POST" }).validator((input) => pinSchema.parse(input)).middleware([authMiddleware]).handler(pinNote_createServerFn_handler, async ({ context, data }) => {
	const text = clip(data.text, 120);
	const updated = await (await getSql())`
      update live_rooms set pinned = ${text}
      where id = ${data.roomId} and host_id = ${context.userId} and status = 'live'
      returning pinned
    `;
	if (!updated.length) return {
		ok: false,
		error: "Hanya kreator yang bisa menyematkan."
	};
	return {
		ok: true,
		data: { pinned: updated[0]?.pinned ?? "" }
	};
});
var heartSchema = object({
	roomId: string().regex(/^[a-z0-9]{4,12}$/),
	count: number().int().min(1).max(20)
});
var addHearts_createServerFn_handler = createServerRpc({
	id: "43eff0ba91e333764e74cefd481849fac6c9406107fec0b77ec99d05cb6783ba",
	name: "addHearts",
	filename: "src/lib/live/functions.ts"
}, (opts) => addHearts.__executeServer(opts));
var addHearts = createServerFn({ method: "POST" }).validator((input) => heartSchema.parse(input)).middleware([authMiddleware]).handler(addHearts_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	await ensureProfile(sql, context.userId);
	const updated = await sql`
      update live_rooms
      set hearts = hearts + ${data.count}
      where id = ${data.roomId} and status = 'live'
      returning hearts
    `;
	if (!updated.length) return {
		ok: false,
		error: "Siaran sudah selesai."
	};
	return {
		ok: true,
		data: { hearts: num(updated[0]?.hearts) }
	};
});
var giftSchema = object({
	roomId: string().regex(/^[a-z0-9]{4,12}$/),
	giftId: string().max(24)
});
var sendGift_createServerFn_handler = createServerRpc({
	id: "c0353ff57305e06427917b0f4473c5eb1cc89e91a8c2d1476987cfe96e4cc329",
	name: "sendGift",
	filename: "src/lib/live/functions.ts"
}, (opts) => sendGift.__executeServer(opts));
var sendGift = createServerFn({ method: "POST" }).validator((input) => giftSchema.parse(input)).middleware([authMiddleware]).handler(sendGift_createServerFn_handler, async ({ context, data }) => {
	const gift = giftById(data.giftId);
	if (!gift) return {
		ok: false,
		error: "Hadiah tidak dikenal."
	};
	const sql = await getSql();
	const me = await ensureProfile(sql, context.userId);
	const room = (await sql`
      select host_id, battle_id from live_rooms
      where id = ${data.roomId} and status = 'live'
    `)[0];
	if (!room) return {
		ok: false,
		error: "Siaran sudah selesai."
	};
	if (!(await sql`
      update profiles
      set coins = coins - ${gift.coins}
      where user_id = ${context.userId} and coins >= ${gift.coins}
      returning user_id
    `).length) return {
		ok: false,
		error: "Koin tidak cukup."
	};
	await sql`
      update profiles set earned = earned + ${gift.coins}
      where user_id = ${room.host_id}
    `;
	await sql`
      update live_rooms
      set gifts_value = gifts_value + ${gift.coins}
      where id = ${data.roomId}
    `;
	if (room.battle_id) await sql`
        update battles
        set score_a = score_a + case when room_a = ${data.roomId} then ${gift.coins} else 0 end,
            score_b = score_b + case when room_b = ${data.roomId} then ${gift.coins} else 0 end
        where id = ${room.battle_id} and ends_at > now()
      `;
	const row = (await sql`
      insert into room_messages (room_id, user_id, display_name, kind, body, gift_id)
      values (${data.roomId}, ${context.userId}, ${me.displayName}, 'gift', ${gift.name}, ${gift.id})
      returning id, user_id, display_name, kind, body, gift_id
    `)[0];
	if (!row) return {
		ok: false,
		error: "Hadiah gagal dicatat."
	};
	return {
		ok: true,
		data: {
			message: mapMessage(row),
			me: await ensureProfile(sql, context.userId)
		}
	};
});
var followSchema = object({ hostId: string().min(1).max(80) });
var toggleFollow_createServerFn_handler = createServerRpc({
	id: "257901b049235494144122b1eb988d48d5f5a52615858b2f70117d62dae264c3",
	name: "toggleFollow",
	filename: "src/lib/live/functions.ts"
}, (opts) => toggleFollow.__executeServer(opts));
var toggleFollow = createServerFn({ method: "POST" }).validator((input) => followSchema.parse(input)).middleware([authMiddleware]).handler(toggleFollow_createServerFn_handler, async ({ context, data }) => {
	if (data.hostId === context.userId) return {
		ok: false,
		error: "Tidak bisa mengikuti diri sendiri."
	};
	const sql = await getSql();
	await ensureProfile(sql, context.userId);
	if (!(await sql`
      select user_id from profiles where user_id = ${data.hostId}
    `).length) return {
		ok: false,
		error: "Kreator tidak ditemukan."
	};
	if ((await sql`
      select host_id from follows
      where follower_id = ${context.userId} and host_id = ${data.hostId}
    `).length) {
		await sql`
        delete from follows
        where follower_id = ${context.userId} and host_id = ${data.hostId}
      `;
		return {
			ok: true,
			data: { following: false }
		};
	}
	await sql`
      insert into follows (follower_id, host_id)
      values (${context.userId}, ${data.hostId})
      on conflict do nothing
    `;
	return {
		ok: true,
		data: { following: true }
	};
});
var startBattle_createServerFn_handler = createServerRpc({
	id: "3b9ab1cc033ef4ac947607d47d147afd120e53d7bbd78ed1d5632a7c62073910",
	name: "startBattle",
	filename: "src/lib/live/functions.ts"
}, (opts) => startBattle.__executeServer(opts));
var startBattle = createServerFn({ method: "POST" }).validator((input) => roomSchema.parse(input)).middleware([authMiddleware]).handler(startBattle_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const me = await ensureProfile(sql, context.userId);
	const rooms = await sql`
      select battle_id from live_rooms
      where id = ${data.roomId} and host_id = ${context.userId} and status = 'live'
    `;
	if (!rooms.length) return {
		ok: false,
		error: "Hanya kreator yang bisa membuka duel."
	};
	const currentId = rooms[0]?.battle_id;
	if (currentId) {
		const current = await loadBattle(sql, currentId);
		if (current && current.endsAt * 1e3 > Date.now()) return {
			ok: true,
			data: current
		};
	}
	let id = "";
	for (let attempt = 0; attempt < 5; attempt += 1) {
		const next = makeCode(5);
		if (!(await sql`select id from battles where id = ${next}`).length) {
			id = next;
			break;
		}
	}
	if (!id) return {
		ok: false,
		error: "Gagal membuat kode duel."
	};
	await sql`
      insert into battles (id, room_a, host_a, name_a, ends_at)
      values (${id}, ${data.roomId}, ${context.userId}, ${me.displayName}, now() + make_interval(secs => 90))
    `;
	await sql`
      update live_rooms set battle_id = ${id}
      where id = ${data.roomId} and host_id = ${context.userId}
    `;
	await sql`
      insert into room_messages (room_id, user_id, display_name, kind, body)
      values (${data.roomId}, ${context.userId}, ${me.displayName}, 'system', ${`Duel dibuka. Kode ${id}`})
    `;
	const battle = await loadBattle(sql, id);
	if (!battle) return {
		ok: false,
		error: "Duel gagal dibuka."
	};
	return {
		ok: true,
		data: battle
	};
});
var joinBattleSchema = object({
	roomId: string().regex(/^[a-z0-9]{4,12}$/),
	code: string().max(12)
});
var joinBattle_createServerFn_handler = createServerRpc({
	id: "ecdd288ba5812d34e1b04b88ddc4e71030bc304615f4b8c81c3dec1bf9567aa1",
	name: "joinBattle",
	filename: "src/lib/live/functions.ts"
}, (opts) => joinBattle.__executeServer(opts));
var joinBattle = createServerFn({ method: "POST" }).validator((input) => joinBattleSchema.parse(input)).middleware([authMiddleware]).handler(joinBattle_createServerFn_handler, async ({ context, data }) => {
	const code = data.code.trim().toLowerCase();
	if (!/^[a-z0-9]{4,8}$/.test(code)) return {
		ok: false,
		error: "Kode duel tidak valid."
	};
	const sql = await getSql();
	const me = await ensureProfile(sql, context.userId);
	if (!(await sql`
      select id from live_rooms
      where id = ${data.roomId} and host_id = ${context.userId} and status = 'live'
    `).length) return {
		ok: false,
		error: "Buka siaranmu dulu, lalu masukkan kode."
	};
	const battle = (await sql`
      select id, room_a, room_b, host_a from battles
      where id = ${code} and ends_at > now()
    `)[0];
	if (!battle) return {
		ok: false,
		error: "Kode duel tidak ada atau sudah habis."
	};
	if (battle.room_a === data.roomId) return {
		ok: false,
		error: "Itu kode panggungmu sendiri."
	};
	if (battle.room_b && battle.room_b !== data.roomId) return {
		ok: false,
		error: "Duel ini sudah punya lawan."
	};
	await sql`
      update battles
      set room_b = ${data.roomId}, host_b = ${context.userId}, name_b = ${me.displayName},
          ends_at = now() + make_interval(secs => 90)
      where id = ${code} and (room_b is null or room_b = ${data.roomId})
    `;
	await sql`
      update live_rooms set battle_id = ${code}
      where id = ${data.roomId} and host_id = ${context.userId}
    `;
	await sql`
      insert into room_messages (room_id, user_id, display_name, kind, body)
      values (${data.roomId}, ${context.userId}, ${me.displayName}, 'system', ${`Masuk duel ${code}`})
    `;
	await sql`
      insert into room_messages (room_id, user_id, display_name, kind, body)
      values (${battle.room_a}, ${context.userId}, ${me.displayName}, 'system', ${`${me.displayName} masuk duel`})
    `;
	const view = await loadBattle(sql, code);
	if (!view) return {
		ok: false,
		error: "Duel gagal disambungkan."
	};
	return {
		ok: true,
		data: view
	};
});
//#endregion
export { addHearts_createServerFn_handler, cashOut_createServerFn_handler, claimDaily_createServerFn_handler, createRoom_createServerFn_handler, endRoom_createServerFn_handler, joinBattle_createServerFn_handler, lobbyState_createServerFn_handler, pinNote_createServerFn_handler, pulseRoom_createServerFn_handler, saveProfile_createServerFn_handler, sendChat_createServerFn_handler, sendGift_createServerFn_handler, startBattle_createServerFn_handler, toggleFollow_createServerFn_handler };
