import { o as __toESM } from "../_runtime.mjs";
import { a as require_jsx_runtime, o as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { _ as Gamepad2, a as PhoneOff, b as Clock, c as Mic, d as MessageCircle, f as Lock, g as Hand, h as Headphones, i as Plus, l as MicOff, m as HeadphoneOff, o as Music, p as House, r as Radio, s as Moon, t as Users, u as MessagesSquare, v as Copy, x as BookOpen, y as Coffee } from "../_libs/lucide-react.mjs";
import { n as Route$1 } from "./router-CHXC7k7M.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { i as SliderTrack, n as SliderRange, r as SliderThumb, t as Slider } from "../_libs/@radix-ui/react-slider+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BC62IhDF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var MIC_CONSTRAINTS = {
	echoCancellation: true,
	noiseSuppression: true,
	autoGainControl: true,
	channelCount: 1
};
var shared = null;
var users = 0;
function retainAudio() {
	users += 1;
	if (!shared || shared.state === "closed") shared = new AudioContext();
	shared.resume();
	return shared;
}
function releaseAudio() {
	users = Math.max(0, users - 1);
	if (users === 0 && shared) {
		shared.close();
		shared = null;
	}
}
async function requestMic() {
	const stream = await navigator.mediaDevices.getUserMedia({
		audio: MIC_CONSTRAINTS,
		video: false
	});
	for (const track of stream.getAudioTracks()) track.contentHint = "speech";
	return stream;
}
function micErrorMessage(error) {
	const name = error instanceof DOMException ? error.name : "";
	if (name === "NotAllowedError" || name === "PermissionDeniedError") return "تم رفض الميكروفون. يمكنك الاستماع، أو السماح به من إعدادات المتصفح.";
	if (name === "NotFoundError" || name === "DevicesNotFoundError") return "لم نعثر على ميكروفون. وضع الاستماع ما زال متاحاً.";
	if (name === "NotReadableError" || name === "TrackStartError") return "الميكروفون مستخدم في تطبيق آخر.";
	return "تعذّر فتح الميكروفون. يمكنك البقاء مستمعاً.";
}
function playChime(kind) {
	let held = false;
	try {
		const ctx = retainAudio();
		held = true;
		const osc = ctx.createOscillator();
		const gain = ctx.createGain();
		osc.type = "sine";
		osc.frequency.value = kind === "join" ? 523.25 : 349.23;
		const now = ctx.currentTime;
		gain.gain.setValueAtTime(1e-4, now);
		gain.gain.exponentialRampToValueAtTime(.035, now + .02);
		gain.gain.exponentialRampToValueAtTime(1e-4, now + .28);
		osc.connect(gain);
		gain.connect(ctx.destination);
		osc.start(now);
		osc.stop(now + .3);
		osc.onended = () => releaseAudio();
	} catch {
		if (held) releaseAudio();
	}
}
function useAudioLevel(stream, active) {
	const [snap, setSnap] = (0, import_react.useState)({
		level: 0,
		speaking: false
	});
	(0, import_react.useEffect)(() => {
		if (!stream || !active || stream.getAudioTracks().length === 0) {
			setSnap({
				level: 0,
				speaking: false
			});
			return;
		}
		let ctx;
		try {
			ctx = retainAudio();
		} catch {
			setSnap({
				level: 0,
				speaking: false
			});
			return;
		}
		let source;
		try {
			source = ctx.createMediaStreamSource(stream);
		} catch {
			releaseAudio();
			setSnap({
				level: 0,
				speaking: false
			});
			return;
		}
		const analyser = ctx.createAnalyser();
		analyser.fftSize = 256;
		analyser.smoothingTimeConstant = .7;
		source.connect(analyser);
		const bins = new Uint8Array(analyser.frequencyBinCount);
		let raf = 0;
		let last = 0;
		let speaking = false;
		let level = 0;
		const tick = (now) => {
			raf = requestAnimationFrame(tick);
			if (now - last < 100) return;
			last = now;
			analyser.getByteFrequencyData(bins);
			let sum = 0;
			const end = Math.min(bins.length, 32);
			for (let i = 2; i < end; i += 1) sum += bins[i];
			const nextLevel = sum / ((end - 2) * 255);
			const nextSpeaking = speaking ? nextLevel > .07 : nextLevel > .14;
			if (nextSpeaking !== speaking || Math.abs(nextLevel - level) > .05) {
				speaking = nextSpeaking;
				level = nextLevel;
				setSnap({
					level,
					speaking
				});
			}
		};
		raf = requestAnimationFrame(tick);
		return () => {
			cancelAnimationFrame(raf);
			source.disconnect();
			releaseAudio();
		};
	}, [stream, active]);
	return snap;
}
var ROOMS = [
	{
		id: "dar",
		title: "الدار الكبيرة",
		blurb: "الصالة العامة. ادخل، سلّم، وخلّ الصوت يجمع الحاضرين.",
		topic: "مفتوحة للكل",
		icon: "home"
	},
	{
		id: "qahwa",
		title: "قهوة المساء",
		blurb: "حديث على مهل. مناسب بعد العشاء، بلا استعجال وبلا ضجيج.",
		topic: "سهر هادئ",
		icon: "coffee"
	},
	{
		id: "dirasa",
		title: "رواق الدراسة",
		blurb: "مراجعة وأسئلة. افتح الميكروفون حين يحين دورك، وأبقه مغلقاً وأنت تركز.",
		topic: "تركيز",
		icon: "book"
	},
	{
		id: "malab",
		title: "ملعب الألعاب",
		blurb: "قبل المباراة وبعدها. نسّقوا الفريق وتكلموا وأنتم تلعبون.",
		topic: "ألعاب",
		icon: "game"
	},
	{
		id: "studio",
		title: "الاستوديو",
		blurb: "موسيقى ومقاطع. شغّل شيئاً عندك وتحدّثوا عنه. السماعات أفضل هنا.",
		topic: "موسيقى",
		icon: "music"
	},
	{
		id: "nqaash",
		title: "حلقة النقاش",
		blurb: "رأي ورأي مقابل. ارفع يدك وتناوبوا حتى يبقى الصوت واضحاً.",
		topic: "نقاش",
		icon: "talk"
	},
	{
		id: "dz",
		title: "أهل الجزائر",
		blurb: "وناس بالدارجة والفصحى. من وهران إلى عنابة، الباب مفتوح.",
		topic: "الجزائر",
		icon: "dz"
	},
	{
		id: "hadi",
		title: "الغرفة الهادئة",
		blurb: "صوت خافت لمن يعملون جنباً إلى جنب. الكلام عند الحاجة فقط.",
		topic: "عمل مشترك",
		icon: "moon"
	}
];
function isPrivateId(id) {
	return /^prv-[A-Z0-9]{4}$/.test(id);
}
function makePrivateId() {
	const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
	let code = "";
	for (let i = 0; i < 4; i += 1) code += alphabet[Math.floor(Math.random() * 32)];
	return `prv-${code}`;
}
function normalizeCode(raw) {
	const trimmed = raw.trim().toUpperCase().replace(/\s+/g, "");
	const body = trimmed.startsWith("PRV-") ? trimmed.slice(4) : trimmed;
	if (!/^[A-Z0-9]{4}$/.test(body)) return null;
	return `prv-${body}`;
}
function privateRoom(id) {
	return {
		id,
		title: "غرفة خاصة",
		blurb: "من يملك الرمز يدخل معك. تختفي الغرفة من الصالة حين يغادرها الجميع.",
		topic: "خاصة",
		icon: "home"
	};
}
function findRoom(id) {
	if (!id) return ROOMS[0];
	return ROOMS.find((room) => room.id === id) ?? (isPrivateId(id) ? privateRoom(id) : ROOMS[0]);
}
function cleanName(raw) {
	return raw.replace(/[\u0000-\u001F\u007F]/g, "").trim().slice(0, 24);
}
function initials(name) {
	const parts = name.trim().split(/\s+/).filter(Boolean);
	const take = (part) => {
		const ch = [...part][0] ?? "";
		return /[a-z]/i.test(ch) ? ch.toUpperCase() : ch;
	};
	if (!parts.length) return "•";
	if (parts.length === 1) return take(parts[0]);
	return `${take(parts[0])}${take(parts[1])}`;
}
function privateCode(id) {
	return id.replace(/^prv-/, "");
}
async function fetchPresence(ids) {
	const pairs = await Promise.all(ids.map(async (id) => {
		const empty = {
			count: 0,
			names: []
		};
		try {
			const res = await fetch(`/api/rtc?room=${encodeURIComponent(id)}&watch=1`);
			if (!res.ok) return [id, empty];
			const peers = (await res.json()).peers ?? [];
			const names = peers.map((peer) => (peer.name ?? "").trim()).filter((name) => name.length > 0).slice(0, 3);
			return [id, {
				count: peers.length,
				names
			}];
		} catch {
			return [id, empty];
		}
	}));
	return Object.fromEntries(pairs);
}
var FAST_POLL_MS = 400;
var IDLE_POLL_MS = 2e3;
var PING_INTERVAL_MS = 2e3;
var STALL_MS = 1e4;
var MAX_RECOVERY_ATTEMPTS = 3;
var SIGNAL_RETRY_DELAYS_MS = [250, 750];
function defaultIceServers() {
	return [{ urls: ["stun:stun.l.google.com:19302", "stun:stun.cloudflare.com:3478"] }];
}
var P2PRoom = class {
	opts;
	peers = /* @__PURE__ */ new Map();
	/** Per-remote-peer signal delivery chains (order-preserving). */
	signalQueues = /* @__PURE__ */ new Map();
	localStream;
	silentTrack = null;
	silentCtx = null;
	cursor = 0;
	pollTimer = null;
	pingTimer = null;
	closed = false;
	everPolled = false;
	lastPeersFingerprint = "";
	constructor(opts) {
		this.opts = opts;
		this.localStream = opts.localStream ?? null;
	}
	/**
	* The first poll IS the join: it registers this peer and returns the
	* roster. A failed first poll (cold DB, offline tab) must not strand the
	* room: the loop and timers start regardless and the next poll retries.
	*/
	async join() {
		try {
			await this.pollOnce();
		} catch {}
		if (this.closed) return;
		this.schedulePoll(this.anyPairConnecting() ? FAST_POLL_MS : IDLE_POLL_MS);
		this.pingTimer = setInterval(() => {
			this.pingAll();
			this.watchdog();
		}, PING_INTERVAL_MS);
	}
	/** Swap the microphone. A silent track holds the audio m-line, so this does not renegotiate. */
	setLocalStream(stream) {
		this.localStream = stream;
		const track = this.localTrack();
		if (!track) return;
		for (const slot of this.peers.values()) {
			const sender = slot.pc.getSenders().find((s) => s.track?.kind === "audio");
			if (sender && sender.track !== track) sender.replaceTrack(track);
		}
	}
	close() {
		this.closed = true;
		if (this.pollTimer) clearTimeout(this.pollTimer);
		if (this.pingTimer) clearInterval(this.pingTimer);
		for (const slot of this.peers.values()) slot.pc.close();
		this.peers.clear();
		this.silentTrack?.stop();
		this.silentTrack = null;
		this.silentCtx?.close();
		this.silentCtx = null;
		fetch("/api/rtc", {
			method: "POST",
			headers: { "content-type": "application/json" },
			body: JSON.stringify({
				op: "leave",
				room: this.opts.room,
				peer: this.opts.selfId
			}),
			keepalive: true
		}).catch(() => {});
	}
	/** Send on the unreliable game-state channel (drops stale packets). */
	broadcast(data) {
		const wire = JSON.stringify({
			t: "d",
			d: data
		});
		for (const slot of this.peers.values()) if (slot.state?.readyState === "open") slot.state.send(wire);
	}
	/** Send reliably (ordered) to one peer, or to all when peerId is omitted. */
	send(data, peerId) {
		const wire = JSON.stringify({
			t: "d",
			d: data
		});
		const targets = peerId ? [this.peers.get(peerId)] : [...this.peers.values()];
		for (const slot of targets) if (slot?.reliable?.readyState === "open") slot.reliable.send(wire);
	}
	peerList() {
		return [...this.peers.values()].map((s) => ({ ...s.info }));
	}
	localTrack() {
		const live = this.localStream?.getAudioTracks().find((t) => t.readyState === "live");
		if (live) return live;
		try {
			return this.ensureSilentTrack();
		} catch {
			return null;
		}
	}
	ensureSilentTrack() {
		if (this.silentTrack && this.silentTrack.readyState === "live") return this.silentTrack;
		const ctx = new AudioContext();
		const osc = ctx.createOscillator();
		const gain = ctx.createGain();
		gain.gain.value = 0;
		const dest = ctx.createMediaStreamDestination();
		osc.connect(gain);
		gain.connect(dest);
		osc.start();
		ctx.resume();
		const track = dest.stream.getAudioTracks()[0];
		if (!track) {
			ctx.close();
			throw new Error("silent audio track unavailable");
		}
		this.silentCtx = ctx;
		this.silentTrack = track;
		return track;
	}
	outgoingStream(track) {
		if (this.localStream?.getAudioTracks().includes(track)) return this.localStream;
		return new MediaStream([track]);
	}
	preferOpus(pc) {
		const caps = RTCRtpSender.getCapabilities?.("audio");
		if (!caps) return;
		const opus = caps.codecs.filter((c) => c.mimeType.toLowerCase() === "audio/opus");
		if (!opus.length) return;
		const rest = caps.codecs.filter((c) => c.mimeType.toLowerCase() !== "audio/opus");
		const tr = pc.getTransceivers().find((t) => t.receiver.track?.kind === "audio" || t.sender.track?.kind === "audio");
		try {
			tr?.setCodecPreferences([...opus, ...rest]);
		} catch {}
	}
	/** Put our mic (or silence) on the audio transceiver before an answer is created. */
	async ensureSendAudio(pc) {
		const track = this.localTrack();
		if (!track) return;
		const sender = pc.getSenders().find((s) => s.track?.kind === "audio");
		if (sender) {
			if (sender.track !== track) await sender.replaceTrack(track);
			return;
		}
		const transceiver = pc.getTransceivers().find((t) => t.receiver.track?.kind === "audio");
		if (transceiver) {
			await transceiver.sender.replaceTrack(track);
			return;
		}
		pc.addTrack(track, this.outgoingStream(track));
	}
	schedulePoll(delay) {
		if (this.closed) return;
		if (this.pollTimer) clearTimeout(this.pollTimer);
		this.pollTimer = setTimeout(() => void this.poll(), delay);
	}
	anyPairConnecting() {
		for (const s of this.peers.values()) {
			if (s.terminal) continue;
			if (s.info.connectionState !== "connected") return true;
		}
		return false;
	}
	async pollOnce() {
		const params = new URLSearchParams({
			room: this.opts.room,
			peer: this.opts.selfId,
			name: this.opts.name ?? "",
			since: String(this.cursor)
		});
		const res = await fetch(`/api/rtc?${params}`);
		if (this.closed) return;
		if (!res.ok) throw new Error(`signaling poll failed: ${res.status}`);
		const body = await res.json();
		if (this.closed) return;
		if (!this.everPolled) {
			this.everPolled = true;
			this.opts.onConnected?.();
		}
		this.reconcileRoster(body.peers);
		const roster = new Set(body.peers.map((p) => p.id));
		for (const sig of body.signals) {
			this.cursor = Math.max(this.cursor, sig.id);
			await this.onSignal(sig.from, sig.kind, sig.payload, roster);
			if (this.closed) return;
		}
	}
	async poll() {
		if (this.closed) return;
		try {
			await this.pollOnce();
		} catch {}
		this.schedulePoll(this.anyPairConnecting() ? FAST_POLL_MS : IDLE_POLL_MS);
	}
	reconcileRoster(peers) {
		const alive = new Set(peers.map((p) => p.id));
		for (const p of peers) {
			if (p.id === this.opts.selfId) continue;
			const existing = this.peers.get(p.id);
			if (existing) existing.info.name = p.name;
			else this.connectTo(p.id, p.name, this.opts.selfId > p.id);
		}
		for (const [id, slot] of this.peers) if (!alive.has(id)) {
			slot.pc.close();
			this.peers.delete(id);
			this.opts.onRemoteStream?.(id, null);
		}
		this.emitPeers();
	}
	connectTo(peerId, name, initiator) {
		if (this.closed) return null;
		const pc = new RTCPeerConnection({ iceServers: this.opts.iceServers ?? defaultIceServers() });
		const slot = {
			pc,
			makingOffer: false,
			ignoreOffer: false,
			pendingCandidates: [],
			lastProgressAt: Date.now(),
			recoveryAttempts: 0,
			info: {
				id: peerId,
				name,
				connectionState: pc.connectionState,
				candidateType: null,
				rttMs: null
			}
		};
		this.peers.set(peerId, slot);
		pc.onicecandidate = (e) => {
			if (e.candidate) this.sendSignal(peerId, "ice", e.candidate.toJSON());
		};
		pc.onconnectionstatechange = () => {
			slot.info.connectionState = pc.connectionState;
			if (pc.connectionState === "connecting" || pc.connectionState === "connected") slot.lastProgressAt = Date.now();
			if (pc.connectionState === "connected") {
				slot.recoveryAttempts = 0;
				slot.terminal = false;
				this.readCandidateType(slot);
			}
			this.emitPeers();
			if (pc.connectionState === "failed") pc.restartIce();
			if (pc.connectionState === "failed" || pc.connectionState === "disconnected") this.schedulePoll(FAST_POLL_MS);
		};
		pc.onnegotiationneeded = async () => {
			try {
				slot.makingOffer = true;
				await pc.setLocalDescription();
				await this.sendSignal(peerId, "offer", pc.localDescription.toJSON());
			} catch {} finally {
				slot.makingOffer = false;
			}
		};
		pc.ondatachannel = (e) => this.attachChannel(slot, e.channel);
		pc.ontrack = (ev) => {
			if (ev.track.kind !== "audio") return;
			const stream = ev.streams[0] ?? new MediaStream([ev.track]);
			this.opts.onRemoteStream?.(peerId, stream);
			if (ev.track.muted) ev.track.onunmute = () => this.opts.onRemoteStream?.(peerId, stream);
		};
		if (initiator) {
			try {
				const track = this.localTrack();
				if (track) {
					pc.addTrack(track, this.outgoingStream(track));
					this.preferOpus(pc);
				}
			} catch (err) {
				console.warn("[p2p] audio sender skipped", err);
			}
			this.attachChannel(slot, pc.createDataChannel("state", {
				ordered: false,
				maxRetransmits: 0
			}));
			this.attachChannel(slot, pc.createDataChannel("reliable", { ordered: true }));
		}
		return slot;
	}
	attachChannel(slot, channel) {
		if (channel.label === "state") slot.state = channel;
		else slot.reliable = channel;
		channel.onopen = () => {
			slot.lastProgressAt = Date.now();
			if (channel.label === "reliable") this.opts.onReliableOpen?.(slot.info.id);
		};
		channel.onmessage = (e) => {
			let msg;
			try {
				msg = JSON.parse(e.data);
			} catch {
				return;
			}
			if (msg.t === "ping") {
				if (slot.state?.readyState === "open") slot.state.send(JSON.stringify({ t: "pong" }));
			} else if (msg.t === "pong") {
				if (slot.pingSentAt) {
					slot.info.rttMs = Math.round(performance.now() - slot.pingSentAt);
					slot.pingSentAt = void 0;
					this.emitPeers();
				}
			} else this.opts.onMessage?.(slot.info.id, msg.d, channel.label === "state" ? "state" : "reliable");
		};
	}
	/** Apply buffered ICE candidates once a remote description is in place. */
	async flushPendingCandidates(slot) {
		while (slot.pendingCandidates.length > 0) {
			const candidate = slot.pendingCandidates.shift();
			try {
				await slot.pc.addIceCandidate(candidate);
			} catch (err) {
				if (!slot.ignoreOffer) console.warn("[p2p] addIceCandidate failed:", err);
			}
			if (this.closed) return;
		}
	}
	async onSignal(from, kind, payload, roster) {
		if (this.closed) return;
		let slot = this.peers.get(from);
		if (!slot) {
			if (!roster.has(from)) return;
			const created = this.connectTo(from, "", false);
			if (!created) return;
			slot = created;
		}
		const polite = this.opts.selfId < from;
		try {
			if (kind === "offer" || kind === "answer") {
				const description = payload;
				const collision = kind === "offer" && (slot.makingOffer || slot.pc.signalingState !== "stable");
				slot.ignoreOffer = !polite && collision;
				if (slot.ignoreOffer) return;
				try {
					await slot.pc.setRemoteDescription(description);
				} catch (err) {
					if (kind !== "offer" || slot.recreatedForOffer) throw err;
					const attempts = slot.recoveryAttempts;
					const name = slot.info.name;
					slot.pc.close();
					this.peers.delete(from);
					this.opts.onRemoteStream?.(from, null);
					const fresh = this.connectTo(from, name, false);
					if (!fresh) return;
					fresh.recoveryAttempts = attempts;
					fresh.recreatedForOffer = true;
					slot = fresh;
					await slot.pc.setRemoteDescription(description);
				}
				if (this.closed) return;
				await this.flushPendingCandidates(slot);
				if (this.closed) return;
				if (kind === "offer") {
					await this.ensureSendAudio(slot.pc);
					if (this.closed) return;
					await slot.pc.setLocalDescription();
					if (this.closed) return;
					await this.sendSignal(from, "answer", slot.pc.localDescription.toJSON());
				}
			} else if (kind === "ice") {
				const candidate = payload;
				if (!slot.pc.remoteDescription) {
					slot.pendingCandidates.push(candidate);
					return;
				}
				try {
					await slot.pc.addIceCandidate(candidate);
				} catch (err) {
					if (!slot.ignoreOffer) console.warn("[p2p] addIceCandidate failed:", err);
				}
			}
		} catch {}
	}
	/**
	* Signals are serialized per remote peer (a candidate must never overtake
	* its SDP into the DB) and retried on failure with short backoff.
	*/
	sendSignal(to, kind, payload) {
		const next = (this.signalQueues.get(to) ?? Promise.resolve()).then(() => this.postSignal(to, kind, payload));
		this.signalQueues.set(to, next.catch(() => {}));
		return next;
	}
	async postSignal(to, kind, payload) {
		for (let attempt = 0;; attempt++) {
			if (this.closed) return;
			try {
				const res = await fetch("/api/rtc", {
					method: "POST",
					headers: { "content-type": "application/json" },
					body: JSON.stringify({
						op: "signal",
						room: this.opts.room,
						from: this.opts.selfId,
						to,
						kind,
						payload
					})
				});
				if (res.ok) return;
				throw new Error(`signal POST failed: ${res.status}`);
			} catch (err) {
				if (attempt >= SIGNAL_RETRY_DELAYS_MS.length) {
					console.warn(`[p2p] signal ${kind} to ${to} failed after retries`, err);
					return;
				}
				await new Promise((r) => setTimeout(r, SIGNAL_RETRY_DELAYS_MS[attempt]));
			}
		}
	}
	pingAll() {
		const wire = JSON.stringify({ t: "ping" });
		for (const slot of this.peers.values()) {
			if (slot.state?.readyState !== "open") continue;
			const stale = slot.pingSentAt !== void 0 && performance.now() - slot.pingSentAt > 2 * PING_INTERVAL_MS;
			if (slot.pingSentAt === void 0 || stale) {
				slot.pingSentAt = performance.now();
				slot.state.send(wire);
			}
		}
	}
	/**
	* Stuck-pair recovery, piggybacked on the ping interval. A pair that has
	* made no progress for STALL_MS gets rebuilt by the dialer with a FRESH
	* RTCPeerConnection (new DTLS identity — fixes the suspend/resume
	* fingerprint wedge). After MAX_RECOVERY_ATTEMPTS the pair is terminal:
	* visible to the app as its last connectionState, ignored by fast-poll.
	*/
	watchdog() {
		if (this.closed) return;
		const now = Date.now();
		for (const [peerId, slot] of this.peers) {
			const live = slot.pc.connectionState;
			if (live !== slot.info.connectionState) {
				slot.info.connectionState = live;
				if (live === "connecting" || live === "connected") slot.lastProgressAt = now;
				this.emitPeers();
			}
			if (slot.terminal || live === "connected") continue;
			if (now - slot.lastProgressAt <= STALL_MS) continue;
			if (slot.recoveryAttempts >= MAX_RECOVERY_ATTEMPTS) {
				slot.terminal = true;
				this.emitPeers();
				continue;
			}
			slot.recoveryAttempts += 1;
			slot.lastProgressAt = now;
			if (this.opts.selfId > peerId) {
				const { name } = slot.info;
				const attempts = slot.recoveryAttempts;
				slot.pc.close();
				this.peers.delete(peerId);
				this.opts.onRemoteStream?.(peerId, null);
				const fresh = this.connectTo(peerId, name, true);
				if (fresh) fresh.recoveryAttempts = attempts;
				this.schedulePoll(FAST_POLL_MS);
			}
		}
	}
	async readCandidateType(slot) {
		try {
			const stats = await slot.pc.getStats();
			let selected;
			stats.forEach((s) => {
				if (s.type === "candidate-pair" && s.nominated) selected = s;
			});
			const localId = selected?.localCandidateId;
			if (localId) {
				const local = stats.get(localId);
				slot.info.candidateType = local?.candidateType ?? null;
				this.emitPeers();
			}
		} catch {}
	}
	emitPeers() {
		const list = this.peerList();
		const fingerprint = JSON.stringify(list.map((p) => [
			p.id,
			p.name,
			p.connectionState,
			p.candidateType,
			p.rttMs
		]));
		if (fingerprint === this.lastPeersFingerprint) return;
		this.lastPeersFingerprint = fingerprint;
		this.opts.onPeersChanged?.(list);
	}
};
function isLine(value) {
	if (!value || typeof value !== "object") return false;
	const v = value;
	return typeof v.id === "string" && v.id.length > 0 && v.id.length <= 48 && typeof v.from === "string" && v.from.length <= 64 && typeof v.name === "string" && v.name.length <= 64 && typeof v.text === "string" && v.text.length > 0 && v.text.length <= 400 && typeof v.at === "number" && Number.isFinite(v.at);
}
function parseWire(data) {
	if (!data || typeof data !== "object") return null;
	const v = data;
	if (v.type === "chat" && isLine(v.line)) return {
		type: "chat",
		line: v.line
	};
	if (v.type === "hand" && typeof v.up === "boolean") return {
		type: "hand",
		up: v.up
	};
	if (v.type === "mute" && typeof v.muted === "boolean") return {
		type: "mute",
		muted: v.muted
	};
	if (v.type === "hello" && typeof v.hand === "boolean" && Array.isArray(v.lines)) return {
		type: "hello",
		hand: v.hand,
		muted: typeof v.muted === "boolean" ? v.muted : false,
		lines: v.lines.filter(isLine).slice(0, 30)
	};
	return null;
}
function mergeLines(prev, extra) {
	const map = new Map(prev.map((line) => [line.id, line]));
	for (const line of extra) map.set(line.id, line);
	return [...map.values()].sort((a, b) => a.at - b.at).slice(-80);
}
function useVoiceSession(options) {
	const { roomId, name, localStream, micHot } = options;
	const [selfId] = (0, import_react.useState)(() => `p-${Math.random().toString(36).slice(2, 10)}`);
	const [peers, setPeers] = (0, import_react.useState)([]);
	const [joined, setJoined] = (0, import_react.useState)(false);
	const [streams, setStreams] = (0, import_react.useState)({});
	const [lines, setLines] = (0, import_react.useState)([]);
	const [hands, setHands] = (0, import_react.useState)({});
	const [mutes, setMutes] = (0, import_react.useState)({});
	const [handUp, setHandUpState] = (0, import_react.useState)(false);
	const roomRef = (0, import_react.useRef)(null);
	const handRef = (0, import_react.useRef)(false);
	const linesRef = (0, import_react.useRef)([]);
	const nameRef = (0, import_react.useRef)(name);
	const micRef = (0, import_react.useRef)(micHot);
	const initialStream = (0, import_react.useRef)(localStream);
	handRef.current = handUp;
	linesRef.current = lines;
	nameRef.current = name;
	micRef.current = micHot;
	(0, import_react.useEffect)(() => {
		const p2p = new P2PRoom({
			room: roomId,
			selfId,
			name,
			localStream: initialStream.current,
			onPeersChanged: setPeers,
			onConnected: () => setJoined(true),
			onRemoteStream: (peerId, stream) => {
				setStreams((prev) => {
					if (!stream) {
						if (!(peerId in prev)) return prev;
						const next = { ...prev };
						delete next[peerId];
						return next;
					}
					if (prev[peerId] === stream) return prev;
					return {
						...prev,
						[peerId]: stream
					};
				});
			},
			onReliableOpen: (peerId) => {
				p2p.send({
					type: "hello",
					hand: handRef.current,
					muted: !micRef.current,
					lines: linesRef.current.slice(-30)
				}, peerId);
			},
			onMessage: (from, data) => {
				const msg = parseWire(data);
				if (!msg) return;
				if (msg.type === "chat") setLines((prev) => mergeLines(prev, [msg.line]));
				else if (msg.type === "hand") setHands((prev) => ({
					...prev,
					[from]: msg.up
				}));
				else if (msg.type === "mute") setMutes((prev) => ({
					...prev,
					[from]: msg.muted
				}));
				else {
					setHands((prev) => ({
						...prev,
						[from]: msg.hand
					}));
					setMutes((prev) => ({
						...prev,
						[from]: msg.muted
					}));
					if (msg.lines.length) setLines((prev) => mergeLines(prev, msg.lines));
				}
			}
		});
		roomRef.current = p2p;
		p2p.join();
		return () => {
			roomRef.current = null;
			p2p.close();
		};
	}, [
		roomId,
		selfId,
		name
	]);
	(0, import_react.useEffect)(() => {
		roomRef.current?.setLocalStream(localStream);
	}, [localStream]);
	(0, import_react.useEffect)(() => {
		roomRef.current?.send({
			type: "mute",
			muted: !micHot
		});
	}, [micHot]);
	(0, import_react.useEffect)(() => {
		const alive = new Set(peers.map((peer) => peer.id));
		setHands((prev) => {
			let changed = false;
			const next = {};
			for (const [id, up] of Object.entries(prev)) if (alive.has(id) && up) next[id] = true;
			else changed = true;
			return changed ? next : prev;
		});
		setMutes((prev) => {
			let changed = false;
			const next = {};
			for (const [id, muted] of Object.entries(prev)) if (alive.has(id)) next[id] = muted;
			else changed = true;
			return changed ? next : prev;
		});
		setStreams((prev) => {
			let changed = false;
			const next = { ...prev };
			for (const id of Object.keys(next)) if (!alive.has(id)) {
				delete next[id];
				changed = true;
			}
			return changed ? next : prev;
		});
	}, [peers]);
	return {
		selfId,
		peers,
		joined,
		streams,
		lines,
		hands,
		mutes,
		handUp,
		sendChat: (0, import_react.useCallback)((text) => {
			const clean = text.replace(/\s+/g, " ").trim().slice(0, 400);
			if (!clean) return false;
			const line = {
				id: `${selfId}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`,
				from: selfId,
				name: nameRef.current,
				text: clean,
				at: Date.now()
			};
			setLines((prev) => mergeLines(prev, [line]));
			roomRef.current?.send({
				type: "chat",
				line
			});
			return true;
		}, [selfId]),
		setHandUp: (0, import_react.useCallback)((up) => {
			setHandUpState(up);
			handRef.current = up;
			roomRef.current?.send({
				type: "hand",
				up
			});
		}, [])
	};
}
var timeFmt = new Intl.DateTimeFormat("ar-DZ", {
	hour: "2-digit",
	minute: "2-digit"
});
function RoomView({ room, name, initialStream, initialNote, onLeave }) {
	const [stream, setStream] = (0, import_react.useState)(initialStream);
	const [note, setNote] = (0, import_react.useState)(initialNote);
	const [muted, setMuted] = (0, import_react.useState)(false);
	const [ptt, setPtt] = (0, import_react.useState)(false);
	const [held, setHeld] = (0, import_react.useState)(false);
	const [deaf, setDeaf] = (0, import_react.useState)(false);
	const [chatOpen, setChatOpen] = (0, import_react.useState)(false);
	const [draft, setDraft] = (0, import_react.useState)("");
	const [volumes, setVolumes] = (0, import_react.useState)({});
	const [openVolume, setOpenVolume] = (0, import_react.useState)(null);
	const [soundLocked, setSoundLocked] = (0, import_react.useState)(false);
	const [seen, setSeen] = (0, import_react.useState)(0);
	const streamRef = (0, import_react.useRef)(initialStream);
	const scrollerRef = (0, import_react.useRef)(null);
	const lastChat = (0, import_react.useRef)(0);
	streamRef.current = stream;
	const micHot = Boolean(stream) && !muted && (!ptt || held);
	const session = useVoiceSession({
		roomId: room.id,
		name,
		localStream: stream,
		micHot
	});
	(0, import_react.useEffect)(() => {
		const current = stream?.getAudioTracks()[0];
		if (current) current.enabled = micHot;
	}, [stream, micHot]);
	(0, import_react.useEffect)(() => {
		return () => {
			streamRef.current?.getTracks().forEach((track) => track.stop());
		};
	}, []);
	(0, import_react.useEffect)(() => {
		const onKey = (event) => {
			const target = event.target;
			const typing = target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement || Boolean(target?.isContentEditable);
			if (event.code === "KeyM" && event.type === "keydown" && !event.repeat && !typing && !ptt) {
				event.preventDefault();
				setMuted((value) => !value);
			}
			if (ptt && event.code === "Space" && !typing) {
				event.preventDefault();
				setHeld(event.type === "keydown");
			}
		};
		window.addEventListener("keydown", onKey);
		window.addEventListener("keyup", onKey);
		return () => {
			window.removeEventListener("keydown", onKey);
			window.removeEventListener("keyup", onKey);
		};
	}, [ptt]);
	const seenPeers = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const ids = new Set(session.peers.filter((peer) => peer.connectionState === "connected").map((peer) => peer.id));
		if (seenPeers.current === null) {
			seenPeers.current = ids;
			return;
		}
		let joined = false;
		let left = false;
		for (const id of ids) if (!seenPeers.current.has(id)) joined = true;
		for (const id of seenPeers.current) if (!ids.has(id)) left = true;
		seenPeers.current = ids;
		if (joined) playChime("join");
		else if (left) playChime("leave");
	}, [session.peers]);
	(0, import_react.useEffect)(() => {
		const wide = window.matchMedia("(min-width: 1024px)");
		const mark = () => {
			if (wide.matches || chatOpen) setSeen(session.lines.length);
		};
		mark();
		wide.addEventListener("change", mark);
		return () => wide.removeEventListener("change", mark);
	}, [chatOpen, session.lines.length]);
	(0, import_react.useEffect)(() => {
		const el = scrollerRef.current;
		if (!el) return;
		el.scrollTop = el.scrollHeight;
	}, [session.lines, chatOpen]);
	const count = session.peers.length + 1;
	const unread = Math.max(0, session.lines.length - seen);
	const failed = session.peers.some((peer) => peer.connectionState === "failed" || peer.connectionState === "disconnected");
	async function enableMic() {
		try {
			const next = await requestMic();
			setStream((prev) => {
				prev?.getTracks().forEach((track) => track.stop());
				return next;
			});
			setNote(null);
			setMuted(false);
		} catch (error) {
			setNote(micErrorMessage(error));
		}
	}
	function submitChat() {
		const now = Date.now();
		if (now - lastChat.current < 400) return;
		if (!session.sendChat(draft)) return;
		lastChat.current = now;
		setDraft("");
	}
	async function copyLink() {
		const url = `${window.location.origin}/?r=${room.id}`;
		try {
			await navigator.clipboard.writeText(url);
			toast("تم نسخ رابط الغرفة");
		} catch {
			toast(url);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-dvh flex-col bg-bg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-1 shrink-0 bg-primary" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex shrink-0 items-center gap-2 border-b border-border px-3 py-3 sm:gap-3 sm:px-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: onLeave,
						className: "inline-flex h-11 shrink-0 items-center gap-2 rounded-xl border border-border px-3 text-sm transition-transform duration-150 active:scale-[0.96]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneOff, {
							className: "size-4",
							"aria-hidden": "true"
						}), "الغرف"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "truncate font-display text-xl leading-tight",
							children: room.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "truncate text-sm text-muted",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "tabular-nums",
									dir: "ltr",
									children: [
										count,
										"/",
										8
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [" · ", session.joined ? "متصل بالصالة" : "جارٍ الدخول…"] }),
								isPrivateId(room.id) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									dir: "ltr",
									className: "ms-1 text-primary",
									children: privateCode(room.id)
								}) : null
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => void copyLink(),
						className: "grid size-11 shrink-0 place-items-center rounded-xl border border-border transition-transform duration-150 active:scale-[0.96]",
						"aria-label": "نسخ رابط الغرفة",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-h-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: cn("flex min-h-0 min-w-0 flex-1 flex-col", chatOpen && "hidden lg:flex"),
					"aria-label": "الحاضرون",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-h-0 flex-1 overflow-y-auto px-4 py-6",
						children: [
							session.peers.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mx-auto mb-8 max-w-sm text-center text-sm text-muted",
								children: "أنت أول الحاضرين. انسخ الرابط وافتحه من جهاز آخر ليبدأ الصوت."
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
								className: "mx-auto grid w-full max-w-lg grid-cols-2 gap-4 sm:grid-cols-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonOrb, {
									id: session.selfId,
									name,
									you: true,
									stream,
									analyse: micHot,
									hand: session.handUp,
									muted: !micHot,
									subtitle: stream ? micHot ? "أنت تتحدث" : "مكتوم" : "مستمع"
								}), session.peers.map((peer) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonOrb, {
									id: peer.id,
									name: peer.name || "ضيف",
									stream: session.streams[peer.id] ?? null,
									analyse: Boolean(session.streams[peer.id]),
									hand: session.hands[peer.id],
									muted: session.mutes[peer.id],
									subtitle: peerSubtitle(peer),
									volume: deaf ? 0 : volumes[peer.id] ?? 1,
									expanded: openVolume === peer.id,
									onToggle: () => setOpenVolume((current) => current === peer.id ? null : peer.id),
									onVolume: (value) => setVolumes((prev) => ({
										...prev,
										[peer.id]: value
									}))
								}, peer.id))]
							}),
							failed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mx-auto mt-8 max-w-sm text-center text-sm text-muted",
								children: "بعض الأجهزة لم تصل مباشرة. غالباً الشبكة تمنع المسار الصوتي بينها."
							}) : null
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex shrink-0 justify-center gap-2 px-4 pb-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "inline-flex rounded-full bg-surface p-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-pressed": !ptt,
								onClick: () => {
									setPtt(false);
									setHeld(false);
								},
								className: cn("h-10 rounded-full px-4 text-sm transition-colors", !ptt ? "bg-surface-2 text-fg" : "text-muted"),
								children: "مفتوح"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-pressed": ptt,
								onClick: () => {
									setPtt(true);
									setHeld(false);
									setMuted(false);
								},
								className: cn("h-10 rounded-full px-4 text-sm transition-colors", ptt ? "bg-surface-2 text-fg" : "text-muted"),
								children: "اضغط للتحدث"
							})]
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: cn("min-h-0 min-w-0 flex-col border-border bg-surface", chatOpen ? "flex flex-1 lg:w-80 lg:flex-none lg:border-s" : "hidden lg:flex lg:w-80 lg:shrink-0 lg:border-s"),
					"aria-label": "دردشة الغرفة",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "border-b border-border px-4 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-lg",
								children: "الدردشة"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: "تختفي الرسائل بمغادرة الغرفة"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							ref: scrollerRef,
							className: "flex min-h-0 flex-1 flex-col gap-3 overflow-y-auto px-4 py-4",
							children: session.lines.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: "كن أول من يسلّم. الصوت يبقى الأساس."
							}) : session.lines.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChatBubble, {
								line,
								mine: line.from === session.selfId
							}, line.id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							className: "flex gap-2 border-t border-border p-3",
							onSubmit: (event) => {
								event.preventDefault();
								submitChat();
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: draft,
								onChange: (event) => setDraft(event.target.value),
								maxLength: 400,
								placeholder: "اكتب رسالة",
								className: "h-12 min-w-0 flex-1 rounded-2xl border border-border bg-bg px-4 text-base text-fg outline-none placeholder:text-muted"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "submit",
								className: "h-12 shrink-0 rounded-2xl bg-primary px-4 text-sm font-semibold text-primary-fg transition-transform duration-150 active:scale-[0.96]",
								children: "إرسال"
							})]
						})
					]
				})]
			}),
			(note || soundLocked) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "shrink-0 border-t border-border bg-surface px-4 py-2 text-center text-sm text-muted",
				children: [soundLocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "text-primary",
					onClick: () => unlockSound(setSoundLocked),
					children: "اضغط لتشغيل صوت الغرفة"
				}) : note, note && !stream ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "ms-2 text-primary",
					onClick: () => void enableMic(),
					children: "إعادة المحاولة"
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "shrink-0 border-t border-border px-3 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-3xl items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-pressed": micHot,
								"aria-label": ptt ? "اضغط مع الاستمرار للتحدث" : micHot ? "كتم الميكروفون" : "فتح الميكروفون",
								onPointerDown: (event) => {
									if (!ptt) return;
									event.currentTarget.setPointerCapture(event.pointerId);
									setHeld(true);
								},
								onPointerUp: () => ptt && setHeld(false),
								onPointerCancel: () => setHeld(false),
								onContextMenu: (event) => ptt && event.preventDefault(),
								onClick: () => {
									if (ptt) return;
									if (!stream) {
										enableMic();
										return;
									}
									setMuted((value) => !value);
								},
								className: cn("grid size-14 touch-none place-items-center rounded-full transition-transform duration-150 active:scale-[0.96]", micHot ? "bg-primary text-primary-fg" : "bg-surface-2 text-fg"),
								children: micHot ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "size-6" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MicOff, { className: "size-6" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DockButton, {
								label: deaf ? "السماعات متوقفة" : "إيقاف السماعات",
								pressed: deaf,
								onClick: () => setDeaf((value) => !value),
								children: deaf ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadphoneOff, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Headphones, { className: "size-5" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DockButton, {
								label: session.handUp ? "اخفض يدك" : "ارفع يدك",
								pressed: session.handUp,
								onClick: () => session.setHandUp(!session.handUp),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hand, { className: "size-5" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DockButton, {
								label: "الدردشة",
								pressed: chatOpen,
								className: "relative lg:hidden",
								onClick: () => setChatOpen((value) => !value),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-5" }), unread > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-2 left-2 size-2 rounded-full bg-primary" }) : null]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onLeave,
						className: "inline-flex h-12 items-center gap-2 rounded-2xl border border-border px-4 text-sm transition-transform duration-150 active:scale-[0.96]",
						children: "مغادرة"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-center text-xs text-muted",
					children: ["السماعات تمنع الصدى.", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "hidden md:inline",
						children: [
							" M للكتم",
							ptt ? "، والمسافة للتحدث" : "",
							"."
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RemoteStage, {
				streams: session.streams,
				volumes,
				deaf,
				onBlocked: () => setSoundLocked(true)
			})
		]
	});
}
function peerSubtitle(peer) {
	if (peer.connectionState === "connected") return peer.rttMs != null ? `${peer.rttMs} ms` : "متصل";
	if (peer.connectionState === "failed") return "تعذّر المسار";
	if (peer.connectionState === "disconnected") return "انقطع";
	return "يتم الاتصال";
}
function PersonOrb({ id, name, you, stream, analyse, hand, muted, subtitle, volume, expanded, onToggle, onVolume }) {
	const { level, speaking } = useAudioLevel(stream, analyse);
	const body = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: cn("relative grid size-20 place-items-center rounded-full border-2 bg-surface font-display text-2xl", speaking ? "speaking-ring border-live" : "border-border"),
			children: [
				initials(name),
				muted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "absolute -bottom-1 -left-1 grid size-7 place-items-center rounded-full bg-surface-2 text-fg",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MicOff, {
						className: "size-3.5",
						"aria-hidden": "true"
					})
				}) : null,
				hand ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "absolute -top-1 -right-1 grid size-7 place-items-center rounded-full bg-primary text-primary-fg",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hand, {
						className: "size-3.5",
						"aria-hidden": "true"
					})
				}) : null
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mt-3 max-w-full truncate text-sm font-medium",
			children: name
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "text-xs text-muted",
			dir: subtitle.endsWith("ms") ? "ltr" : void 0,
			children: [you ? "أنت" : subtitle, you ? ` · ${subtitle}` : ""]
		}),
		you ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mt-2 h-1 w-16 overflow-hidden rounded-full bg-border",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block h-full bg-live",
				style: { width: `${Math.round(level * 100)}%` }
			})
		}) : null
	] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "flex flex-col items-center text-center",
		"data-peer": id,
		children: [onToggle ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: onToggle,
			className: "flex flex-col items-center",
			"aria-expanded": expanded,
			children: body
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-col items-center",
			children: body
		}), expanded && onVolume ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 w-full px-1",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slider, {
				dir: "ltr",
				min: 0,
				max: 1,
				step: .05,
				value: [volume ?? 1],
				onValueChange: (value) => onVolume(value[0] ?? 0),
				className: "relative flex h-6 touch-none items-center",
				"aria-label": `صوت ${name}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
					className: "relative h-1 grow rounded-full bg-border",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRange, { className: "absolute h-full rounded-full bg-primary" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, { className: "block size-4 rounded-full bg-primary" })]
			})
		}) : null]
	});
}
function ChatBubble({ line, mine }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: cn("max-w-xs rounded-2xl px-3 py-2", mine ? "self-start bg-primary text-primary-fg" : "self-end bg-bg text-fg"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-xs opacity-80",
			children: [mine ? "أنت" : line.name, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "ms-2 tabular-nums",
				dir: "ltr",
				children: timeFmt.format(line.at)
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			dir: "auto",
			className: "text-sm leading-6",
			children: line.text
		})]
	});
}
function DockButton({ children, label, pressed, onClick, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-pressed": pressed,
		"aria-label": label,
		onClick,
		className: cn("grid size-12 place-items-center rounded-2xl border border-border transition-transform duration-150 active:scale-[0.96]", pressed ? "bg-surface-2 text-primary" : "text-fg", className),
		children
	});
}
function RemoteStage({ streams, volumes, deaf, onBlocked }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "sr-only",
		"aria-hidden": "true",
		children: Object.entries(streams).map(([id, stream]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RemoteAudio, {
			stream,
			volume: deaf ? 0 : volumes[id] ?? 1,
			onBlocked
		}, id))
	});
}
function RemoteAudio({ stream, volume, onBlocked }) {
	const ref = (0, import_react.useRef)(null);
	const blocked = (0, import_react.useRef)(onBlocked);
	blocked.current = onBlocked;
	(0, import_react.useEffect)(() => {
		const el = ref.current;
		if (!el) return;
		el.srcObject = stream;
		el.volume = volume;
		el.play().catch(() => blocked.current());
	}, [stream]);
	(0, import_react.useEffect)(() => {
		if (ref.current) ref.current.volume = volume;
	}, [volume]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("audio", {
		ref,
		autoPlay: true,
		playsInline: true
	});
}
function unlockSound(done) {
	document.querySelectorAll("audio").forEach((node) => {
		node.play().catch(() => void 0);
	});
	done(false);
}
var ICONS = {
	home: House,
	coffee: Coffee,
	book: BookOpen,
	game: Gamepad2,
	music: Music,
	talk: MessagesSquare,
	dz: Radio,
	moon: Moon
};
var POINTS = [
	{
		title: "مباشر بينكم",
		body: "الصوت يسافر من جهاز إلى جهاز. لا نحفظ المكالمات."
	},
	{
		title: "حتى ٨ أشخاص",
		body: "غرفة صغيرة تبقى مفهومة. إذا امتلأت اختر غيرها."
	},
	{
		title: "بلا حساب",
		body: "اسم ظاهر فقط داخل الغرفة. لا بريد ولا كلمة سر."
	}
];
function useAlgiersClock() {
	const [label, setLabel] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		const fmt = new Intl.DateTimeFormat("ar-DZ", {
			hour: "2-digit",
			minute: "2-digit",
			timeZone: "Africa/Algiers"
		});
		const tick = () => setLabel(fmt.format(/* @__PURE__ */ new Date()));
		tick();
		const id = setInterval(tick, 3e4);
		return () => clearInterval(id);
	}, []);
	return label;
}
async function copyRoomLink(roomId) {
	const url = `${window.location.origin}/?r=${roomId}`;
	try {
		await navigator.clipboard.writeText(url);
		toast("تم نسخ رابط الغرفة");
	} catch {
		toast(url);
	}
}
function LoungeApp({ entryRoom }) {
	const [name, setName] = (0, import_react.useState)("");
	const [nameHint, setNameHint] = (0, import_react.useState)(null);
	const [selectedId, setSelectedId] = (0, import_react.useState)(() => findRoom(entryRoom).id);
	const [presence, setPresence] = (0, import_react.useState)(null);
	const [code, setCode] = (0, import_react.useState)("");
	const [codeHint, setCodeHint] = (0, import_react.useState)(null);
	const [entering, setEntering] = (0, import_react.useState)(false);
	const [session, setSession] = (0, import_react.useState)(null);
	const nameRef = (0, import_react.useRef)(null);
	const clock = useAlgiersClock();
	(0, import_react.useEffect)(() => {
		const saved = localStorage.getItem("ousimdz-name");
		if (saved) setName(saved);
	}, []);
	(0, import_react.useEffect)(() => {
		if (session) return;
		let stop = false;
		const ids = ROOMS.map((room) => room.id);
		if (isPrivateId(selectedId)) ids.push(selectedId);
		const tick = async () => {
			const next = await fetchPresence(ids);
			if (!stop) setPresence(next);
		};
		tick();
		const timer = setInterval(() => {
			if (document.visibilityState === "hidden") return;
			tick();
		}, 4e3);
		return () => {
			stop = true;
			clearInterval(timer);
		};
	}, [session, selectedId]);
	const active = (0, import_react.useMemo)(() => findRoom(selectedId), [selectedId]);
	const activeCount = presence?.[active.id]?.count;
	const full = (activeCount ?? 0) >= 8;
	async function enter(room) {
		const cleaned = cleanName(name);
		if (!cleaned) {
			setNameHint("اكتب اسمك أولاً حتى يعرفك من في الغرفة.");
			nameRef.current?.focus();
			return;
		}
		if ((presence?.[room.id]?.count ?? 0) >= 8) return;
		setEntering(true);
		setNameHint(null);
		localStorage.setItem("ousimdz-name", cleaned);
		setName(cleaned);
		let stream = null;
		let note = null;
		try {
			stream = await requestMic();
		} catch (error) {
			note = micErrorMessage(error);
		}
		setSession({
			room,
			stream,
			note
		});
		setEntering(false);
	}
	if (session) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
		position: "top-center",
		dir: "rtl",
		theme: "dark",
		toastOptions: { style: {
			background: "var(--color-surface)",
			color: "var(--color-fg)",
			border: "1px solid var(--color-border)",
			fontFamily: "inherit"
		} }
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoomView, {
		room: session.room,
		name: cleanName(name),
		initialStream: session.stream,
		initialNote: session.note,
		onLeave: () => setSession(null)
	})] });
	const names = presence?.[active.id]?.names ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex h-dvh w-full max-w-6xl flex-col px-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				position: "top-center",
				dir: "rtl",
				theme: "dark",
				toastOptions: { style: {
					background: "var(--color-surface)",
					color: "var(--color-fg)",
					border: "1px solid var(--color-border)",
					fontFamily: "inherit"
				} }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-1 shrink-0 bg-primary" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex shrink-0 flex-col gap-4 py-4 sm:flex-row sm:items-center sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-11 shrink-0 place-items-center rounded-2xl bg-primary font-display text-lg font-semibold text-primary-fg",
						children: "DZ"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl leading-none tracking-wide",
						children: "OUSIMDZ"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "دردشة صوتية عربية مجانية"
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "hidden items-center gap-2 text-sm text-muted sm:flex",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, {
								className: "size-4",
								"aria-hidden": "true"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "الجزائر" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums text-fg",
								dir: "ltr",
								children: clock || "—"
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "min-w-0 flex-1 sm:w-56 sm:flex-none",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "sr-only",
							children: "اسمك في الغرفة"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							ref: nameRef,
							value: name,
							maxLength: 24,
							placeholder: "اسمك في الغرفة",
							autoComplete: "nickname",
							onChange: (event) => {
								setName(event.target.value);
								if (nameHint) setNameHint(null);
							},
							className: "h-12 w-full rounded-2xl border border-border bg-surface px-4 text-base text-fg outline-none placeholder:text-muted"
						})]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid min-h-0 flex-1 gap-4 lg:grid-cols-2 lg:pb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "min-h-0 overflow-y-auto lg:pe-1",
					"aria-label": "الغرف",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-3 flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "font-display text-lg",
								children: "الغرف"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted",
								children: ["حدّ الغرفة ", 8]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "flex flex-col gap-2",
							children: [isPrivateId(active.id) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoomButton, {
								room: active,
								selected: true,
								count: activeCount,
								onSelect: () => setSelectedId(active.id)
							}) }) : null, ROOMS.map((room, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "rise",
								style: { animationDelay: `${index * 40}ms` },
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoomButton, {
									room,
									selected: room.id === active.id,
									count: presence?.[room.id]?.count,
									onSelect: () => setSelectedId(room.id)
								})
							}, room.id))]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							className: "mt-4 rounded-card border border-border bg-surface p-3",
							onSubmit: (event) => {
								event.preventDefault();
								const id = normalizeCode(code);
								if (!id) {
									setCodeHint("الرمز أربعة أحرف، مثل K7MQ.");
									return;
								}
								setCodeHint(null);
								setSelectedId(id);
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "flex items-center gap-2 text-sm font-medium",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, {
											className: "size-4 text-primary",
											"aria-hidden": "true"
										}), "غرفة بالرمز"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => {
											const id = makePrivateId();
											setSelectedId(id);
											setCode(privateCode(id));
											setCodeHint(null);
										},
										className: "inline-flex h-11 items-center gap-1 rounded-xl px-3 text-sm text-primary transition-transform duration-150 active:scale-[0.96]",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
											className: "size-4",
											"aria-hidden": "true"
										}), "جديدة"]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-2 flex gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: code,
										onChange: (event) => setCode(event.target.value.toUpperCase()),
										placeholder: "K7MQ",
										maxLength: 8,
										dir: "ltr",
										className: "h-12 min-w-0 flex-1 rounded-xl border border-border bg-bg px-3 text-center font-display text-lg tracking-widest text-fg uppercase outline-none placeholder:text-muted",
										"aria-label": "رمز الغرفة الخاصة"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "submit",
										className: "h-12 shrink-0 rounded-xl bg-surface-2 px-4 text-sm font-medium transition-transform duration-150 active:scale-[0.96]",
										children: "افتح"
									})]
								}),
								codeHint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-primary",
									children: codeHint
								}) : null
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "hidden min-h-0 flex-col justify-between overflow-y-auto rounded-card border border-border bg-surface p-6 shadow-card lg:flex",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-primary",
							children: active.topic
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-2 font-display text-4xl leading-tight",
							children: active.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 max-w-md text-muted",
							children: active.blurb
						}),
						isPrivateId(active.id) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 font-display text-3xl tracking-widest text-primary",
							dir: "ltr",
							children: privateCode(active.id)
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 text-sm text-muted",
							children: presence === null ? "نتحقّق من الحضور…" : names.length ? `في الداخل: ${names.join("، ")}` : "لا أحد في الداخل بعد. كن أول الصوت."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm tabular-nums text-fg",
							dir: "ltr",
							children: [
								activeCount ?? "–",
								" / ",
								8
							]
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mb-5 grid gap-3",
							children: POINTS.map((point) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex gap-3 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-0.5 size-1.5 shrink-0 rounded-full bg-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-medium",
									children: [point.title, ". "]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted",
									children: point.body
								})] })]
							}, point.title))
						}),
						nameHint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-3 text-sm text-primary",
							children: nameHint
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								disabled: entering || full,
								onClick: () => void enter(active),
								className: "inline-flex h-12 flex-1 items-center justify-center gap-2 rounded-2xl bg-primary px-5 font-semibold text-primary-fg transition-transform duration-150 disabled:opacity-50 active:scale-[0.96]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, {
									className: "size-5",
									"aria-hidden": "true"
								}), entering ? "جارٍ فتح الميكروفون…" : full ? "الغرفة ممتلئة" : "ادخل وتحدّث"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => void copyRoomLink(active.id),
								className: "grid size-12 place-items-center rounded-2xl border border-border text-fg transition-transform duration-150 active:scale-[0.96]",
								"aria-label": "نسخ رابط الغرفة",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-5" })
							})]
						})
					] })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "shrink-0 border-t border-border py-3 lg:hidden",
				children: [nameHint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 text-sm text-primary",
					children: nameHint
				}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						disabled: entering || full,
						onClick: () => void enter(active),
						className: "inline-flex h-12 min-w-0 flex-1 items-center justify-center gap-2 rounded-2xl bg-primary px-4 font-semibold text-primary-fg transition-transform duration-150 disabled:opacity-50 active:scale-[0.96]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, {
							className: "size-5 shrink-0",
							"aria-hidden": "true"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "truncate",
							children: entering ? "لحظة…" : full ? "ممتلئة" : `ادخل ${active.title}`
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => void copyRoomLink(active.id),
						className: "grid size-12 shrink-0 place-items-center rounded-2xl border border-border",
						"aria-label": "نسخ رابط الغرفة",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-5" })
					})]
				})]
			})
		]
	});
}
function RoomButton({ room, selected, count, onSelect }) {
	const Icon = isPrivateId(room.id) ? Lock : ICONS[room.icon];
	const full = (count ?? 0) >= 8;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: onSelect,
		"aria-pressed": selected,
		className: cn("flex w-full items-center gap-3 rounded-2xl border px-3 py-2.5 text-start transition-colors duration-200", "active:scale-[0.96]", selected ? "border-primary bg-surface-2" : "border-transparent bg-surface"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "grid size-11 shrink-0 place-items-center rounded-xl bg-bg text-primary",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
				className: "size-5",
				"aria-hidden": "true"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "min-w-0 flex-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "flex items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "truncate font-medium",
					children: room.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: cn("shrink-0 text-xs tabular-nums", full ? "text-primary" : "text-muted"),
					dir: "ltr",
					children: [
						count === void 0 ? "–" : count,
						"/",
						8
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-0.5 block truncate text-sm text-muted",
				children: selected ? room.blurb : room.topic
			})]
		})]
	});
}
function Home() {
	const { r } = Route$1.useSearch();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoungeApp, { entryRoom: r });
}
//#endregion
export { Home as component };
