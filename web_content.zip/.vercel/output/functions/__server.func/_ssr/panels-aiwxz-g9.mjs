import { o as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as emptyStats, f as summarize, n as applyStats, s as isChatVisible } from "./model-CryEHs3X.mjs";
import { n as GoalMeter, t as ChatLine } from "./bits-DB9gFqO2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/panels-aiwxz-g9.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function useOverlayBody() {
	(0, import_react.useEffect)(() => {
		document.body.dataset.overlay = "true";
		return () => {
			delete document.body.dataset.overlay;
		};
	}, []);
}
function useOverlayFeed(room) {
	const [feed, setFeed] = (0, import_react.useState)([]);
	const [stats, setStats] = (0, import_react.useState)(emptyStats());
	(0, import_react.useEffect)(() => {
		const onMessage = (event) => {
			if (event.origin !== window.location.origin) return;
			const data = event.data;
			if (!data || data.source !== "onda") return;
			if (data.snapshot) setFeed(data.snapshot);
			if (data.stats) setStats(data.stats);
			else if (data.snapshot) setStats(summarize(data.snapshot));
			if (data.event) {
				const incoming = data.event;
				if (incoming.kind === "status" || incoming.kind === "sync") return;
				setFeed((current) => current.some((item) => item.id === incoming.id) ? current : [...current, incoming].slice(-180));
				setStats((current) => applyStats(current, incoming));
			}
		};
		window.addEventListener("message", onMessage);
		let source = null;
		if (!(window.parent !== window) && room) {
			source = new EventSource(`/api/live?room=${encodeURIComponent(room)}`);
			source.onmessage = (message) => {
				const incoming = JSON.parse(message.data);
				if (incoming.kind === "status") return;
				if (incoming.kind === "sync") {
					setStats({
						viewers: incoming.viewers,
						likes: incoming.likes,
						follows: incoming.follows,
						shares: incoming.shares,
						coins: incoming.coins,
						ranks: incoming.ranks
					});
					return;
				}
				setFeed((current) => current.some((item) => item.id === incoming.id) ? current : [...current, incoming].slice(-180));
				if (!incoming.replay) setStats((current) => applyStats(current, incoming));
			};
		}
		return () => {
			window.removeEventListener("message", onMessage);
			source?.close();
		};
	}, [room]);
	return {
		feed,
		stats
	};
}
function lookFrom(search) {
	return {
		showJoins: search.joins,
		showLikes: search.likes,
		modsOnly: search.mods,
		blocked: search.blocked
	};
}
function ChatOverlay({ look }) {
	useOverlayBody();
	const { feed } = useOverlayFeed(look.room);
	const [now, setNow] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => setNow(Date.now()), 1e3);
		return () => window.clearInterval(id);
	}, []);
	const settings = lookFrom(look);
	const lines = feed.filter((event) => {
		if (!isChatVisible(event, settings, [])) return false;
		if (!look.hide || !event.ts || !now) return true;
		return now - event.ts < look.hide * 1e3;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "flex min-h-dvh flex-col justify-end p-3",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-col",
			children: lines.slice(-12).map((event) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChatLine, {
				event,
				scale: look.scale
			}, event.id))
		})
	});
}
function AlertOverlay({ look }) {
	useOverlayBody();
	const { feed } = useOverlayFeed(look.room);
	const [now, setNow] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => setNow(Date.now()), 400);
		return () => window.clearInterval(id);
	}, []);
	const gift = [...feed].reverse().find((event) => event.kind === "gift");
	const visible = gift && gift.kind === "gift" && (!gift.ts || !now || now - gift.ts < 6e3) ? gift : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "flex min-h-dvh items-end p-4",
		children: visible ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "onda-rise rounded-lg border border-line bg-surface px-4 py-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [visible.user.nick, " envió"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-4xl text-hot",
					children: visible.gift
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "tabular-nums text-fg",
					children: [
						visible.repeat > 1 ? `×${visible.repeat} · ` : "",
						visible.diamonds * visible.repeat,
						" monedas"
					]
				})
			] })
		}, visible.id) : null
	});
}
function GoalOverlay({ look, metric, goal }) {
	useOverlayBody();
	const { stats } = useOverlayFeed(look.room);
	const value = metric === "likes" ? stats.likes : metric === "follows" ? stats.follows : stats.coins;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "flex min-h-dvh items-end p-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "w-full max-w-xl rounded-lg border border-line bg-surface p-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoalMeter, {
				label: metric === "likes" ? "Likes" : metric === "follows" ? "Follows" : "Monedas",
				value,
				goal,
				large: true
			})
		})
	});
}
function RankOverlay({ look }) {
	useOverlayBody();
	const { stats } = useOverlayFeed(look.room);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "flex min-h-dvh items-start p-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "w-full max-w-sm rounded-lg border border-line bg-surface p-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-2xl text-fg",
				children: "Top regalos"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
				className: "mt-3 flex flex-col gap-2",
				children: [stats.ranks.slice(0, 5).map((row, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center gap-3 text-fg",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `w-6 tabular-nums font-semibold ${index === 0 ? "text-signal" : "text-muted"}`,
							children: index + 1
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "min-w-0 flex-1 truncate",
							children: row.nick
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums text-sm text-muted",
							children: row.coins
						})
					]
				}, row.name)), stats.ranks.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "text-sm text-muted",
					children: "Aún no hay regalos."
				}) : null]
			})]
		})
	});
}
//#endregion
export { RankOverlay as i, ChatOverlay as n, GoalOverlay as r, AlertOverlay as t };
