import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as Download, i as Plus, o as ChevronRight, r as Settings, s as ChevronLeft, t as X } from "../_libs/lucide-react.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
import { a as DialogOverlay, i as DialogDescription, n as DialogClose, o as DialogPortal, r as DialogContent, s as DialogTitle, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BjtyPwm5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var defaultSettings = {
	name: "",
	place: "",
	dailyHours: 8,
	dailyWage: 0
};
var MONTHS = [
	"जनवरी",
	"फरवरी",
	"मार्च",
	"अप्रैल",
	"मई",
	"जून",
	"जुलाई",
	"अगस्त",
	"सितंबर",
	"अक्टूबर",
	"नवंबर",
	"दिसंबर"
];
var WEEKDAYS_SHORT = [
	"रवि",
	"सोम",
	"मंगल",
	"बुध",
	"गुरु",
	"शुक्र",
	"शनि"
];
var WEEKDAYS = [
	"रविवार",
	"सोमवार",
	"मंगलवार",
	"बुधवार",
	"गुरुवार",
	"शुक्रवार",
	"शनिवार"
];
function round1(n) {
	return Math.round(n * 10) / 10;
}
function clampHours(n) {
	if (!Number.isFinite(n)) return 0;
	return round1(Math.min(24, Math.max(0, n)));
}
function parseLoose(raw) {
	const n = Number(raw);
	return Number.isFinite(n) ? n : 0;
}
function sanitizeDecimal(raw) {
	const [whole, ...rest] = raw.replace(/[^\d.]/g, "").split(".");
	if (rest.length === 0) return whole.slice(0, 2);
	return `${whole.slice(0, 2)}.${rest.join("").slice(0, 1)}`;
}
function sanitizeInt(raw) {
	return raw.replace(/[^\d]/g, "").slice(0, 7);
}
function formatHours(n) {
	const r = round1(n);
	return Number.isInteger(r) ? String(r) : r.toFixed(1);
}
function hoursPhrase(n) {
	const label = formatHours(n);
	return label === "1" ? "1 घंटा" : `${label} घंटे`;
}
function inr(n) {
	return new Intl.NumberFormat("en-IN", {
		style: "currency",
		currency: "INR",
		maximumFractionDigits: 0
	}).format(Math.round(n));
}
function dayEarning(hoursWorked, settings) {
	if (settings.dailyHours <= 0 || settings.dailyWage <= 0 || hoursWorked <= 0) return 0;
	return Math.round(hoursWorked / settings.dailyHours * settings.dailyWage);
}
function summarize(entries, settings) {
	let daysWorked = 0;
	let daysOff = 0;
	let hoursWorked = 0;
	let hoursMissed = 0;
	let advance = 0;
	let earned = 0;
	for (const entry of entries) {
		if (entry.hoursWorked > 0) daysWorked += 1;
		else daysOff += 1;
		hoursWorked = round1(hoursWorked + entry.hoursWorked);
		hoursMissed = round1(hoursMissed + entry.hoursMissed);
		advance += entry.advance;
		earned += dayEarning(entry.hoursWorked, settings);
	}
	return {
		daysMarked: entries.length,
		daysWorked,
		daysOff,
		hoursWorked,
		hoursMissed,
		advance,
		earned,
		remaining: earned - advance
	};
}
function toMonth(d) {
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}
function todayISO(d = /* @__PURE__ */ new Date()) {
	return `${toMonth(d)}-${String(d.getDate()).padStart(2, "0")}`;
}
function shiftMonth(ym, delta) {
	const [y, m] = ym.split("-").map(Number);
	return toMonth(new Date(y, (m || 1) - 1 + delta, 1));
}
function formatMonth(ym) {
	const [y, m] = ym.split("-").map(Number);
	if (!y || !m || m < 1 || m > 12) return ym;
	return `${MONTHS[m - 1]} ${y}`;
}
function parseISODate(iso) {
	const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso);
	if (!match) return null;
	const y = Number(match[1]);
	const mo = Number(match[2]);
	const d = Number(match[3]);
	const dt = new Date(y, mo - 1, d);
	if (dt.getFullYear() !== y || dt.getMonth() !== mo - 1 || dt.getDate() !== d) return null;
	return dt;
}
function weekdayShort(iso) {
	const dt = parseISODate(iso);
	return dt ? WEEKDAYS_SHORT[dt.getDay()] : "";
}
function formatEntryDate(iso) {
	const dt = parseISODate(iso);
	if (!dt) return iso;
	return `${dt.getDate()} ${MONTHS[dt.getMonth()]}, ${WEEKDAYS[dt.getDay()]}`;
}
function formatLongDate(date) {
	return `${date.getDate()} ${MONTHS[date.getMonth()]} ${date.getFullYear()}`;
}
function dayNumber(iso) {
	const dt = parseISODate(iso);
	return dt ? String(dt.getDate()) : "";
}
function dayBadge(entry, dailyHours) {
	if (entry.hoursWorked <= 0) return {
		label: "छुट्टी",
		tone: "copper"
	};
	if (dailyHours > 0 && entry.hoursWorked > dailyHours + .05) return {
		label: "ज़्यादा घंटे",
		tone: "stamp"
	};
	if (dailyHours > 0 && entry.hoursWorked + .05 < dailyHours) return {
		label: "कम घंटे",
		tone: "ink"
	};
	return {
		label: "पूरा दिन",
		tone: "stamp"
	};
}
function groupByMonth(entries) {
	const map = /* @__PURE__ */ new Map();
	for (const entry of entries) {
		const month = entry.date.slice(0, 7);
		const list = map.get(month);
		if (list) list.push(entry);
		else map.set(month, [entry]);
	}
	return [...map.entries()].sort((a, b) => a[0] < b[0] ? -1 : 1).map(([month, list]) => ({
		month,
		entries: list.slice().sort((a, b) => a.date < b.date ? -1 : 1)
	}));
}
function isEntry(value) {
	if (!value || typeof value !== "object") return false;
	const entry = value;
	return typeof entry.id === "string" && typeof entry.date === "string" && typeof entry.hoursWorked === "number" && typeof entry.hoursMissed === "number" && typeof entry.advance === "number" && typeof entry.note === "string" && parseISODate(entry.date) !== null;
}
function cleanSettings(value) {
	const raw = value && typeof value === "object" ? value : {};
	const dailyHours = typeof raw.dailyHours === "number" && raw.dailyHours > 0 ? Math.min(16, round1(raw.dailyHours)) : defaultSettings.dailyHours;
	const dailyWage = typeof raw.dailyWage === "number" && raw.dailyWage >= 0 ? Math.min(1e7, Math.round(raw.dailyWage)) : 0;
	return {
		name: typeof raw.name === "string" ? raw.name.slice(0, 40) : "",
		place: typeof raw.place === "string" ? raw.place.slice(0, 40) : "",
		dailyHours,
		dailyWage
	};
}
var FONT = "\"Noto Sans Devanagari\", sans-serif";
var DISPLAY = "\"Tiro Devanagari Hindi\", \"Noto Sans Devanagari\", serif";
function el(tag, css, text) {
	const node = document.createElement(tag);
	node.style.cssText = css;
	if (text !== void 0) node.textContent = text;
	return node;
}
function clip(text, max) {
	const trimmed = text.trim();
	if (!trimmed) return "—";
	if (trimmed.length <= max) return trimmed;
	return `${trimmed.slice(0, max - 1)}…`;
}
function buildPage(args, section, pageNo, pageCount) {
	const root = el("div", `box-sizing:border-box;width:720px;padding:28px 28px 24px 32px;background:#fbf7ef;color:#1c1914;font-family:${FONT};font-size:14px;line-height:1.45;border-left:8px solid #8d342c;`);
	const head = el("div", "display:flex;justify-content:space-between;gap:16px;align-items:flex-start;");
	const titles = el("div", "min-width:0;");
	titles.append(el("div", `font-family:${DISPLAY};font-size:32px;line-height:1.1;`, "मेरी हाजिरी"));
	titles.append(el("div", "margin-top:4px;font-size:16px;font-weight:700;", section.monthLabel));
	if (pageCount > 1) titles.append(el("div", "margin-top:2px;color:#6f675c;font-size:12px;", `पन्ना ${pageNo} / ${pageCount}`));
	head.append(titles);
	const seal = el("div", "width:58px;height:58px;border:2px solid #146047;border-radius:50%;display:flex;align-items:center;justify-content:center;flex:none;");
	const sealInner = el("div", `width:46px;height:46px;border:1px solid #146047;border-radius:50%;display:flex;align-items:center;justify-content:center;color:#146047;font-family:${DISPLAY};font-size:18px;`, "हा");
	seal.append(sealInner);
	head.append(seal);
	root.append(head);
	const who = el("div", "margin-top:14px;font-size:14px;");
	who.append(el("div", "", `नाम: ${args.name.trim() || "________________"}`));
	who.append(el("div", "margin-top:2px;", `जगह: ${args.place.trim() || "________________"}`));
	who.append(el("div", "margin-top:2px;color:#6f675c;", `पूरे दिन के घंटे: ${formatHours(args.settings.dailyHours)} · पूरे दिन की मज़दूरी: ${args.settings.dailyWage > 0 ? inr(args.settings.dailyWage) : "नहीं लिखी"}`));
	root.append(who);
	const rows = [
		["काम के दिन", String(section.summary.daysWorked)],
		["छुट्टी के दिन", String(section.summary.daysOff)],
		["घंटे किए", formatHours(section.summary.hoursWorked)],
		["घंटे नहीं किए", formatHours(section.summary.hoursMissed)],
		["एडवांस लिया", inr(section.summary.advance)]
	];
	if (args.settings.dailyWage > 0) {
		rows.push(["कुल मज़दूरी", inr(section.summary.earned)]);
		rows.push([section.summary.remaining >= 0 ? "नहीं लिया (बाकी)" : "एडवांस ज़्यादा", inr(Math.abs(section.summary.remaining))]);
	}
	const summary = el("table", "width:100%;border-collapse:collapse;margin:14px 0 16px;background:#f4efe4;");
	for (const [label, value] of rows) {
		const tr = document.createElement("tr");
		const left = el("td", "padding:5px 10px;color:#6f675c;width:55%;", label);
		const right = el("td", "padding:5px 10px;text-align:right;font-weight:700;", value);
		tr.append(left, right);
		summary.append(tr);
	}
	root.append(summary);
	const table = el("table", "width:100%;border-collapse:collapse;table-layout:fixed;");
	const colgroup = document.createElement("colgroup");
	for (const width of [
		"24%",
		"14%",
		"14%",
		"18%",
		"30%"
	]) {
		const col = document.createElement("col");
		col.style.width = width;
		colgroup.append(col);
	}
	table.append(colgroup);
	const header = document.createElement("tr");
	for (const [index, label] of [
		"तारीख",
		"काम",
		"नहीं",
		"एडवांस",
		"नोट"
	].entries()) {
		const th = el("th", `padding:7px 6px;background:#146047;color:#fbf7ef;font-size:12px;font-weight:700;text-align:${index === 0 || index === 4 ? "left" : "right"};`, label);
		header.append(th);
	}
	table.append(header);
	for (const entry of section.entries) {
		const tr = document.createElement("tr");
		[
			formatEntryDate(entry.date),
			formatHours(entry.hoursWorked),
			formatHours(entry.hoursMissed),
			entry.advance ? inr(entry.advance) : "—",
			clip(entry.note, 28)
		].forEach((text, index) => {
			tr.append(el("td", `padding:6px;border-bottom:1px solid #e3d7c3;font-size:12px;vertical-align:top;text-align:${index === 0 || index === 4 ? "left" : "right"};`, text));
		});
		table.append(tr);
	}
	const total = document.createElement("tr");
	[
		"जोड़",
		formatHours(section.summary.hoursWorked),
		formatHours(section.summary.hoursMissed),
		inr(section.summary.advance),
		""
	].forEach((text, index) => {
		total.append(el("td", `padding:7px 6px;background:#efe6d6;font-size:12px;font-weight:700;text-align:${index === 0 ? "left" : "right"};`, text));
	});
	table.append(total);
	root.append(table);
	const sign = el("div", "display:flex;justify-content:space-between;gap:24px;margin-top:22px;font-size:13px;");
	sign.append(el("div", "", "मज़दूर के हस्ताक्षर ________"));
	sign.append(el("div", "", "मालिक के हस्ताक्षर ________"));
	root.append(sign);
	root.append(el("div", "margin-top:10px;color:#6f675c;font-size:11px;", `तैयार: ${formatLongDate(args.preparedOn)} · नहीं लिया = मज़दूरी − एडवांस`));
	return root;
}
async function paint(node) {
	const host = el("div", "position:fixed;left:0;top:0;z-index:20;width:720px;background:#fbf7ef;pointer-events:none;");
	host.append(node);
	document.body.append(host);
	try {
		if (document.fonts?.ready) await document.fonts.ready;
		const { domToPng } = await import("../_libs/modern-screenshot.mjs").then((n) => n.t);
		return await domToPng(host, {
			scale: 2,
			backgroundColor: "#fbf7ef",
			width: 720
		});
	} finally {
		host.remove();
	}
}
function imageSize(url) {
	return new Promise((resolve, reject) => {
		const img = new Image();
		img.onload = () => resolve({
			w: img.naturalWidth,
			h: img.naturalHeight
		});
		img.onerror = () => reject(/* @__PURE__ */ new Error("pdf-image"));
		img.src = url;
	});
}
async function downloadHajiriPdf(args) {
	const { jsPDF } = await import("../_libs/jspdf.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()));
	const pdf = new jsPDF({
		unit: "mm",
		format: "a4"
	});
	const pageW = pdf.internal.pageSize.getWidth();
	const pageH = pdf.internal.pageSize.getHeight();
	const margin = 8;
	const maxW = pageW - 16;
	const maxH = pageH - 16;
	const count = args.sections.length;
	for (let index = 0; index < count; index += 1) {
		const section = args.sections[index];
		const url = await paint(buildPage(args, section, index + 1, count));
		const { w, h } = await imageSize(url);
		if (index > 0) pdf.addPage();
		const scale = Math.min(maxW / w, maxH / h);
		const drawW = w * scale;
		const drawH = h * scale;
		const x = margin + (maxW - drawW) / 2;
		pdf.addImage(url, "PNG", x, margin, drawW, drawH);
	}
	pdf.save(args.filename);
}
var memory = /* @__PURE__ */ new Map();
var safeStorage = {
	getItem: (key) => {
		try {
			if (typeof localStorage === "undefined") return memory.get(key) ?? null;
			return localStorage.getItem(key);
		} catch {
			return memory.get(key) ?? null;
		}
	},
	setItem: (key, value) => {
		try {
			if (typeof localStorage === "undefined") {
				memory.set(key, value);
				return;
			}
			localStorage.setItem(key, value);
		} catch {
			memory.set(key, value);
		}
	},
	removeItem: (key) => {
		try {
			if (typeof localStorage === "undefined") {
				memory.delete(key);
				return;
			}
			localStorage.removeItem(key);
		} catch {
			memory.delete(key);
		}
	}
};
function newId() {
	if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
	return `id-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}
function normalize(draft) {
	return {
		id: draft.id && draft.id.length > 0 ? draft.id : newId(),
		date: draft.date,
		hoursWorked: clampHours(draft.hoursWorked),
		hoursMissed: clampHours(draft.hoursMissed),
		advance: Math.max(0, Math.min(1e7, Math.round(draft.advance) || 0)),
		note: draft.note.trim().slice(0, 180)
	};
}
var useHajiri = create()(persist((set, get) => ({
	settings: defaultSettings,
	entries: [],
	setSettings: (patch) => {
		set({ settings: cleanSettings({
			...get().settings,
			...patch
		}) });
	},
	upsertEntry: (draft) => {
		const next = normalize(draft);
		set({ entries: [...get().entries.filter((entry) => entry.id !== next.id && entry.date !== next.date), next] });
	},
	removeEntry: (id) => {
		set({ entries: get().entries.filter((entry) => entry.id !== id) });
	},
	clearEntries: () => set({ entries: [] })
}), {
	name: "meri-hajiri-v1",
	storage: createJSONStorage(() => safeStorage),
	merge: (persisted, current) => {
		const saved = persisted ?? {};
		const entries = Array.isArray(saved.entries) ? saved.entries.filter(isEntry) : [];
		return {
			...current,
			settings: cleanSettings(saved.settings),
			entries
		};
	}
}));
function fieldsFrom(worked, missed, advance, note) {
	return {
		worked: formatHours(worked),
		missed: formatHours(missed),
		advance: advance ? String(advance) : "",
		note
	};
}
function EntryDialog({ initialDate, onClose, onSaved }) {
	const settings = useHajiri((state) => state.settings);
	const upsertEntry = useHajiri((state) => state.upsertEntry);
	const removeEntry = useHajiri((state) => state.removeEntry);
	const existing = useHajiri.getState().entries.find((entry) => entry.date === initialDate);
	const start = existing ? fieldsFrom(existing.hoursWorked, existing.hoursMissed, existing.advance, existing.note) : fieldsFrom(settings.dailyHours, 0, 0, "");
	const [date, setDate] = (0, import_react.useState)(initialDate);
	const [editingId, setEditingId] = (0, import_react.useState)(existing?.id);
	const [worked, setWorked] = (0, import_react.useState)(start.worked);
	const [missed, setMissed] = (0, import_react.useState)(start.missed);
	const [advance, setAdvance] = (0, import_react.useState)(start.advance);
	const [note, setNote] = (0, import_react.useState)(start.note);
	const [error, setError] = (0, import_react.useState)("");
	const [confirmDel, setConfirmDel] = (0, import_react.useState)(false);
	function loadDate(next) {
		setDate(next);
		setError("");
		setConfirmDel(false);
		const found = useHajiri.getState().entries.find((entry) => entry.date === next);
		if (found) {
			setEditingId(found.id);
			const filled = fieldsFrom(found.hoursWorked, found.hoursMissed, found.advance, found.note);
			setWorked(filled.worked);
			setMissed(filled.missed);
			setAdvance(filled.advance);
			setNote(filled.note);
			return;
		}
		setEditingId(void 0);
		const blank = fieldsFrom(useHajiri.getState().settings.dailyHours, 0, 0, "");
		setWorked(blank.worked);
		setMissed(blank.missed);
		setAdvance(blank.advance);
		setNote(blank.note);
	}
	function applyPreset(kind) {
		const hours = settings.dailyHours;
		if (kind === "full") {
			setWorked(formatHours(hours));
			setMissed("0");
		} else if (kind === "half") {
			const half = round1(hours / 2);
			setWorked(formatHours(half));
			setMissed(formatHours(round1(hours - half)));
		} else {
			setWorked("0");
			setMissed(formatHours(hours));
		}
	}
	function bumpWorked(delta) {
		const next = clampHours(parseLoose(worked) + delta);
		setWorked(formatHours(next));
		setMissed(formatHours(clampHours(Math.max(0, round1(settings.dailyHours - next)))));
	}
	function commitWorked() {
		const next = clampHours(parseLoose(worked));
		setWorked(formatHours(next));
		setMissed(formatHours(clampHours(Math.max(0, round1(settings.dailyHours - next)))));
	}
	const workedN = clampHours(parseLoose(worked));
	const missedN = clampHours(parseLoose(missed));
	const half = round1(settings.dailyHours / 2);
	const preset = workedN === 0 && missedN === settings.dailyHours ? "off" : Math.abs(workedN - half) < .05 && Math.abs(missedN - round1(settings.dailyHours - half)) < .05 ? "half" : Math.abs(workedN - settings.dailyHours) < .05 && missedN === 0 ? "full" : "";
	function save() {
		if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
			setError("तारीख चुनो।");
			return;
		}
		upsertEntry({
			id: editingId,
			date,
			hoursWorked: workedN,
			hoursMissed: missedN,
			advance: parseLoose(advance),
			note
		});
		onSaved(date);
	}
	const earning = dayEarning(workedN, settings);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (open) => !open && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-40 bg-ink/40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "sheet sheet-in fixed inset-x-0 bottom-0 z-50 rounded-t-card border border-line bg-sheet p-4 sm:inset-x-auto sm:bottom-auto sm:left-1/2 sm:top-1/2 sm:w-full sm:max-w-md sm:-translate-x-1/2 sm:-translate-y-1/2 sm:rounded-card sm:p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mb-3 h-1 w-10 rounded-full bg-line sm:hidden" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
						className: "font-display text-3xl leading-none",
						children: "हाजिरी भरो"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
						className: "mt-2 text-sm text-muted",
						children: "एक दिन का हिसाब। तारीख बदल कर दूसरा दिन भी लिख सकते हो।"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
						className: "inline-flex size-11 shrink-0 items-center justify-center rounded-full",
						"aria-label": "बंद करो",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-4 grid gap-4",
					onSubmit: (event) => {
						event.preventDefault();
						save();
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "grid gap-1 text-sm font-medium",
							children: ["तारीख", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "h-12 rounded-card border border-line bg-sheet px-3 text-base font-normal",
								type: "date",
								value: date,
								onChange: (event) => loadDate(event.target.value),
								required: true
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-3 gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PresetButton, {
									active: preset === "full",
									label: "पूरा दिन",
									hint: hoursPhrase(settings.dailyHours),
									onClick: () => applyPreset("full")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PresetButton, {
									active: preset === "half",
									label: "आधा दिन",
									hint: hoursPhrase(half),
									onClick: () => applyPreset("half")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PresetButton, {
									active: preset === "off",
									label: "छुट्टी",
									hint: "0 काम",
									onClick: () => applyPreset("off")
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
							label: "कितने घंटे काम किया",
							value: worked,
							onChange: (value) => setWorked(sanitizeDecimal(value)),
							onBlur: commitWorked,
							onStep: bumpWorked,
							step: .5
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
							label: "कितने घंटे नहीं किया",
							hint: "घंटे बदलो तो यह अपने आप भरता है। बाद में बदल भी सकते हो।",
							value: missed,
							onChange: (value) => setMissed(sanitizeDecimal(value)),
							onBlur: () => setMissed(formatHours(clampHours(parseLoose(missed)))),
							onStep: (delta) => setMissed(formatHours(clampHours(parseLoose(missed) + delta))),
							step: .5
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
							label: "एडवांस लिया (₹)",
							value: advance,
							onChange: (value) => setAdvance(sanitizeInt(value)),
							onBlur: () => setAdvance(advance ? String(Math.round(parseLoose(advance))) : ""),
							onStep: (delta) => setAdvance(String(Math.max(0, Math.round(parseLoose(advance) + delta)))),
							step: 100,
							placeholder: "0"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "grid gap-1 text-sm font-medium",
							children: ["नोट, ज़रूरी नहीं", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								className: "min-h-20 rounded-card border border-line bg-sheet px-3 py-2 text-base font-normal",
								value: note,
								maxLength: 180,
								placeholder: "जैसे आधा दिन बारिश",
								onChange: (event) => setNote(event.target.value)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "rounded-card bg-stamp-soft px-3 py-3 text-sm",
							children: settings.dailyWage > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["इस दिन की मज़दूरी ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold text-stamp",
								children: inr(earning)
							})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "सेटिंग में पूरे दिन की मज़दूरी लिखोगे तो बाकी पैसा अपने आप निकलेगा।" })
						}),
						error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium text-copper",
							role: "alert",
							children: error
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "btn-stamp h-12 text-base",
							type: "submit",
							children: editingId ? "बदलाव सेव करो" : "सेव करो"
						}),
						editingId && !confirmDel ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "h-11 text-sm font-medium text-copper",
							type: "button",
							onClick: () => setConfirmDel(true),
							children: "इस दिन का हिसाब मिटाओ"
						}) : null,
						editingId && confirmDel ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "btn-line h-12",
								type: "button",
								onClick: () => setConfirmDel(false),
								children: "रहने दो"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "btn-copper h-12",
								type: "button",
								onClick: () => {
									removeEntry(editingId);
									onClose();
								},
								children: "हाँ, मिटाओ"
							})]
						}) : null
					]
				})
			]
		})] })
	});
}
function PresetButton({ active, label, hint, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		"aria-pressed": active,
		onClick,
		className: active ? "h-14 rounded-card border-2 border-stamp bg-stamp-soft text-stamp" : "h-14 rounded-card border-2 border-line bg-sheet text-ink",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "block text-sm font-semibold",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "block text-xs",
			children: hint
		})]
	});
}
function Stepper({ label, hint, value, placeholder, step, onChange, onBlur, onStep }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-1",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-medium",
				children: label
			}),
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs text-muted",
				children: hint
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn-line size-12 text-xl",
						type: "button",
						onClick: () => onStep(-step),
						"aria-label": `${label} घटाओ`,
						children: "−"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "h-12 min-w-0 flex-1 rounded-card border border-line bg-sheet px-3 text-center text-lg font-semibold tabular-nums",
						inputMode: "decimal",
						value,
						placeholder,
						onChange: (event) => onChange(event.target.value),
						onBlur
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn-line size-12 text-xl",
						type: "button",
						onClick: () => onStep(step),
						"aria-label": `${label} बढ़ाओ`,
						children: "+"
					})
				]
			})
		]
	});
}
function SettingsDialog({ onClose }) {
	const settings = useHajiri((state) => state.settings);
	const setSettings = useHajiri((state) => state.setSettings);
	const count = useHajiri((state) => state.entries.length);
	const clearEntries = useHajiri((state) => state.clearEntries);
	const [hours, setHours] = (0, import_react.useState)(formatHours(settings.dailyHours));
	const [wage, setWage] = (0, import_react.useState)(settings.dailyWage ? String(settings.dailyWage) : "");
	const [confirmClear, setConfirmClear] = (0, import_react.useState)(false);
	function commitHours(raw) {
		const next = Math.min(16, Math.max(1, clampHours(parseLoose(raw) || 8)));
		const safe = next < 1 ? 1 : next;
		setHours(formatHours(safe));
		setSettings({ dailyHours: safe });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (open) => !open && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-40 bg-ink/40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "sheet sheet-in fixed inset-x-0 bottom-0 z-50 rounded-t-card border border-line bg-sheet p-4 sm:inset-x-auto sm:bottom-auto sm:left-1/2 sm:top-1/2 sm:w-full sm:max-w-md sm:-translate-x-1/2 sm:-translate-y-1/2 sm:rounded-card sm:p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mb-3 h-1 w-10 rounded-full bg-line sm:hidden" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
						className: "font-display text-3xl leading-none",
						children: "नाम और मज़दूरी"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
						className: "mt-2 text-sm text-muted",
						children: "आधे घंटे पर आधी मज़दूरी गिनी जाएगी। नहीं लिया = मज़दूरी − एडवांस।"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
						className: "inline-flex size-11 shrink-0 items-center justify-center rounded-full",
						"aria-label": "बंद करो",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "grid gap-1 text-sm font-medium",
							children: ["आपका नाम", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "h-12 rounded-card border border-line bg-sheet px-3 text-base font-normal",
								value: settings.name,
								maxLength: 40,
								placeholder: "जैसे रमेश",
								onChange: (event) => setSettings({ name: event.target.value })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "grid gap-1 text-sm font-medium",
							children: ["काम या जगह", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "h-12 rounded-card border border-line bg-sheet px-3 text-base font-normal",
								value: settings.place,
								maxLength: 40,
								placeholder: "जैसे साईट, दुकान",
								onChange: (event) => setSettings({ place: event.target.value })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm font-medium",
								children: "पूरे दिन के घंटे"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										className: "btn-line size-12 text-xl",
										type: "button",
										"aria-label": "घंटे घटाओ",
										onClick: () => commitHours(String(parseLoose(hours) - 1)),
										children: "−"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: "h-12 min-w-0 flex-1 rounded-card border border-line bg-sheet px-3 text-center text-lg font-semibold tabular-nums",
										inputMode: "decimal",
										value: hours,
										onChange: (event) => setHours(sanitizeDecimal(event.target.value)),
										onBlur: () => commitHours(hours)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										className: "btn-line size-12 text-xl",
										type: "button",
										"aria-label": "घंटे बढ़ाओ",
										onClick: () => commitHours(String(parseLoose(hours) + 1)),
										children: "+"
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "grid gap-1 text-sm font-medium",
							children: ["पूरे दिन की मज़दूरी (₹)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "h-12 rounded-card border border-line bg-sheet px-3 text-base tabular-nums",
								inputMode: "numeric",
								placeholder: "जैसे 800",
								value: wage,
								onChange: (event) => {
									const next = sanitizeInt(event.target.value);
									setWage(next);
									setSettings({ dailyWage: next ? Number(next) : 0 });
								}
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "हिसाब सिर्फ इसी फ़ोन में रहता है। फ़ोन बदलो या डेटा मिटाओ तो हिसाब चला जाएगा — PDF निकाल कर रख लो।"
						}),
						count > 0 && !confirmClear ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "h-11 text-sm font-medium text-copper",
							type: "button",
							onClick: () => setConfirmClear(true),
							children: "सारी हाजिरी मिटाओ"
						}) : null,
						confirmClear ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2 rounded-card bg-copper-soft p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm",
								children: "यह वापस नहीं आएगा। नाम और मज़दूरी रह जाएगी। PDF पहले निकाल लो।"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "btn-line h-12",
									type: "button",
									onClick: () => setConfirmClear(false),
									children: "रहने दो"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "btn-copper h-12",
									type: "button",
									onClick: () => {
										clearEntries();
										setConfirmClear(false);
										onClose();
									},
									children: "हाँ, मिटा दो"
								})]
							})]
						}) : null
					]
				})
			]
		})] })
	});
}
function HajiriApp() {
	const settings = useHajiri((state) => state.settings);
	const entries = useHajiri((state) => state.entries);
	const [ready, setReady] = (0, import_react.useState)(false);
	const [month, setMonth] = (0, import_react.useState)("");
	const [today, setToday] = (0, import_react.useState)("");
	const [entryOpen, setEntryOpen] = (0, import_react.useState)(false);
	const [settingsOpen, setSettingsOpen] = (0, import_react.useState)(false);
	const [draftDate, setDraftDate] = (0, import_react.useState)("");
	const [session, setSession] = (0, import_react.useState)(0);
	const [pdfBusy, setPdfBusy] = (0, import_react.useState)(false);
	const [pdfNote, setPdfNote] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		setToday(todayISO());
		setMonth(todayISO().slice(0, 7));
		const unsub = useHajiri.persist.onFinishHydration(() => setReady(true));
		if (useHajiri.persist.hasHydrated()) setReady(true);
		return unsub;
	}, []);
	const monthEntries = (0, import_react.useMemo)(() => entries.filter((entry) => month && entry.date.startsWith(month)).slice().sort((a, b) => a.date < b.date ? 1 : -1), [entries, month]);
	const summary = (0, import_react.useMemo)(() => summarize(monthEntries, settings), [monthEntries, settings]);
	const hasOther = entries.some((entry) => month && !entry.date.startsWith(month));
	const todayFilled = Boolean(today && entries.some((entry) => entry.date === today));
	const wageSet = settings.dailyWage > 0;
	const who = [settings.name, settings.place].filter(Boolean).join(" · ");
	function openDate(iso) {
		setDraftDate(iso);
		setSession((value) => value + 1);
		setEntryOpen(true);
		setPdfNote("");
	}
	async function exportPdf(scope) {
		const printable = (scope === "month" ? [{
			month,
			entries: monthEntries.slice().sort((a, b) => a.date < b.date ? -1 : 1)
		}] : groupByMonth(entries)).filter((section) => section.entries.length > 0);
		if (printable.length === 0 || pdfBusy) return;
		setPdfBusy(true);
		setPdfNote("");
		try {
			await downloadHajiriPdf({
				filename: scope === "month" ? `hajiri-${month}.pdf` : "hajiri-poori-kitab.pdf",
				name: settings.name,
				place: settings.place,
				settings,
				preparedOn: /* @__PURE__ */ new Date(),
				sections: printable.map((section) => ({
					monthLabel: formatMonth(section.month),
					entries: section.entries,
					summary: summarize(section.entries, settings)
				}))
			});
			setPdfNote("PDF डाउनलोड हो गई।");
		} catch {
			setPdfNote("PDF नहीं बन पाई। एक बार और दबाओ।");
		} finally {
			setPdfBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "dock-pad min-h-screen",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto w-full max-w-5xl px-5 py-5 sm:px-8 sm:py-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex size-14 shrink-0 items-center justify-center rounded-full border border-stamp",
						"aria-hidden": "true",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex size-11 items-center justify-center rounded-full border border-stamp font-display text-lg leading-none text-stamp",
							children: "हा"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-3xl leading-none sm:text-4xl",
							children: "मेरी हाजिरी"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 truncate text-sm text-muted",
							children: who || "दिन, घंटे और एडवांस का हिसाब"
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 grid items-start gap-4 lg:grid-cols-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
						className: "book lg:sticky lg:top-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "px-4 py-4",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "inline-flex size-11 items-center justify-center rounded-full border border-line",
											"aria-label": "पिछला महीना",
											disabled: !month,
											onClick: () => setMonth((value) => shiftMonth(value, -1)),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-center",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-display text-2xl leading-tight",
												children: month ? formatMonth(month) : "…"
											}), today && month && month !== today.slice(0, 7) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												className: "text-sm font-semibold text-stamp",
												onClick: () => setMonth(today.slice(0, 7)),
												children: "आज पर जाओ"
											}) : null]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "inline-flex size-11 items-center justify-center rounded-full border border-line",
											"aria-label": "अगला महीना",
											disabled: !month,
											onClick: () => setMonth((value) => shiftMonth(value, 1)),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5" })
										})
									]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 border-t border-line",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										label: "दिन काम",
										value: ready ? String(summary.daysWorked) : "—"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										label: "दिन छुट्टी",
										value: ready ? String(summary.daysOff) : "—"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										label: "घंटे काम",
										value: ready ? formatHours(summary.hoursWorked) : "—"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										label: "घंटे नहीं",
										value: ready ? formatHours(summary.hoursMissed) : "—"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "border-r border-line px-4 py-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-muted",
										children: "एडवांस लिया"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-xl font-semibold tabular-nums text-copper",
										children: ready ? inr(summary.advance) : "—"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "px-4 py-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-muted",
										children: summary.remaining < 0 && wageSet ? "एडवांस ज़्यादा" : "नहीं लिया"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: `mt-1 text-xl font-semibold tabular-nums ${summary.remaining < 0 && wageSet ? "text-copper" : "text-stamp"}`,
										children: ready && wageSet ? inr(Math.abs(summary.remaining)) : "—"
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-3 border-t border-line px-4 py-4",
								children: [
									wageSet ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-sm text-muted",
										children: [
											"मज़दूरी ",
											inr(summary.earned),
											" − एडवांस ",
											inr(summary.advance),
											" = बाकी ",
											inr(summary.remaining)
										]
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-muted",
										children: "बाकी निकालने के लिए पूरे दिन की मज़दूरी लिखो।"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										className: "btn-line inline-flex h-12 items-center justify-center gap-2",
										type: "button",
										onClick: () => setSettingsOpen(true),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "size-5" }), "नाम और मज़दूरी"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										className: "btn-stamp inline-flex h-12 items-center justify-center gap-2",
										type: "button",
										disabled: !ready || monthEntries.length === 0 || pdfBusy,
										onClick: () => exportPdf("month"),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-5" }), "इस महीने का PDF"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										className: "btn-line inline-flex h-12 items-center justify-center gap-2",
										type: "button",
										disabled: !ready || entries.length === 0 || pdfBusy,
										onClick: () => exportPdf("book"),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-5" }), "पूरी किताब का PDF"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-muted",
										role: "status",
										children: pdfNote || "हिसाब इसी फ़ोन में सेव होता है।"
									})
								]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "book lg:col-span-2",
						"aria-label": "इस महीने की हाजिरी",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-3 border-b border-line px-4 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-2xl leading-none",
								children: "रजिस्टर"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								className: "btn-stamp hidden h-11 items-center gap-2 px-4 lg:inline-flex",
								type: "button",
								disabled: !ready,
								onClick: () => openDate(today || todayISO()),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-5" }), todayFilled ? "आज बदलो" : "आज भरो"]
							})]
						}), !ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "px-4 py-8 text-sm text-muted",
							children: "हिसाब खुल रहा है…"
						}) : monthEntries.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "px-4 py-10 text-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-3xl",
								children: "अभी खाली है"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mx-auto mt-2 max-w-xs text-sm text-muted",
								children: hasOther ? "इस महीने कुछ नहीं भरा। ऊपर तीर से दूसरा महीना खोलो।" : "आज की हाजिरी भरो दबाकर पहला दिन लिखो। घंटे, छुट्टी और एडवांस एक साथ रहेंगे।"
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: monthEntries.map((entry) => {
							const badge = dayBadge(entry, settings.dailyHours);
							const tone = badge.tone === "stamp" ? "bg-stamp-soft text-stamp" : badge.tone === "copper" ? "bg-copper-soft text-copper" : "bg-paper text-ink";
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "border-b border-line last:border-b-0",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: `flex w-full items-center gap-3 px-4 py-3 text-left ${entry.date === today ? "bg-stamp-soft" : ""}`,
									onClick: () => openDate(entry.date),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "w-12 shrink-0 text-center",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block font-display text-3xl leading-none",
											children: dayNumber(entry.date)
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs text-muted",
											children: weekdayShort(entry.date)
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "min-w-0 flex-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "flex flex-wrap items-center gap-2",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: `rounded-full px-2 py-0.5 text-xs font-semibold ${tone}`,
														children: badge.label
													}),
													entry.date === today ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-xs font-semibold text-stamp",
														children: "आज"
													}) : null,
													entry.advance > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "text-sm font-medium text-copper",
														children: ["एडवांस ", inr(entry.advance)]
													}) : null
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "mt-1 block text-sm text-muted",
												children: [
													hoursPhrase(entry.hoursWorked),
													" काम · ",
													hoursPhrase(entry.hoursMissed),
													" नहीं"
												]
											}),
											entry.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "mt-0.5 block truncate text-sm",
												children: entry.note
											}) : null
										]
									})]
								})
							}, entry.id);
						}) })]
					})]
				})]
			}),
			ready && !entryOpen && !settingsOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "dock lg:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					className: "btn-stamp inline-flex h-12 w-full items-center justify-center gap-2",
					type: "button",
					onClick: () => openDate(today || todayISO()),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-5" }), todayFilled ? "आज की हाजिरी बदलो" : "आज की हाजिरी भरो"]
				})
			}) : null,
			entryOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntryDialog, {
				initialDate: draftDate,
				onClose: () => setEntryOpen(false),
				onSaved: (date) => {
					setMonth(date.slice(0, 7));
					setEntryOpen(false);
				}
			}, session) : null,
			settingsOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsDialog, { onClose: () => setSettingsOpen(false) }) : null,
			pdfBusy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pdf-cover",
				role: "status",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-3xl",
					children: "PDF बन रही है…"
				})
			}) : null
		]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border-b border-line px-4 py-3 odd:border-r",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-2xl font-semibold tabular-nums leading-none",
			children: value
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HajiriApp, {});
}
//#endregion
export { Home as component };
