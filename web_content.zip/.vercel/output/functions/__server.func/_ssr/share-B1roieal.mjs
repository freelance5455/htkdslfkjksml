//#region node_modules/.nitro/vite/services/ssr/assets/share-B1roieal.js
async function shareText(title, text) {
	const payload = `${title}\n\n${text}\n\n— رفيق`;
	try {
		if (navigator.share) {
			await navigator.share({
				title,
				text: payload
			});
			return;
		}
	} catch {
		return;
	}
	await navigator.clipboard.writeText(payload);
}
//#endregion
export { shareText as t };
