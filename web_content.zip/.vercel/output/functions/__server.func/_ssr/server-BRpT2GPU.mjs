import { t as cn } from "./utils-C_uf36nf.mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as number, n as _enum, o as object, r as array, s as string, t as number$1 } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/server-BRpT2GPU.js
var import_jsx_runtime = require_jsx_runtime();
function Skeleton({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("animate-pulse rounded-sm bg-surface-2", className),
		...props
	});
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var listStreams = createServerFn({ method: "GET" }).handler(createSsrRpc("9475f68f37106d41bba5fba3f60185a50fa216c332b7369d612d4b2e64d94ac2"));
var listSchools = createServerFn({ method: "GET" }).handler(createSsrRpc("dcdeddd960647df7bcbd70c09bcdadd8a24617122d8a49c555a6de6432bc0560"));
createServerFn({ method: "GET" }).handler(createSsrRpc("ec3bca5de6ec7dfcf13f9c29c1578e1c2d79a1fbfc3dffc45fa4d3a9f09a6896"));
var getDashboard = createServerFn({ method: "GET" }).handler(createSsrRpc("06f85f4c1a22b004f246384759d6530c08a62b5d0ddf3f0377cfb5eb293253d6"));
var listFilterSchema = object({
	q: string().optional(),
	streamId: number().int().positive().optional(),
	schoolId: number().int().positive().optional(),
	decision: _enum([
		"ناجح",
		"راسب",
		"قيد الإدخال"
	]).optional()
});
var listStudents = createServerFn({ method: "GET" }).validator(listFilterSchema).handler(createSsrRpc("e9ce8e93f59e96b17f4fe674bee589493ca9760f369ccf67666ddb35296892dc"));
var listResults = createServerFn({ method: "GET" }).validator(listFilterSchema).handler(createSsrRpc("9a1fe0f59c8a7b3a8fce374b0d1f25c2ff114ed88938891115203c2a7798bcbf"));
var getStudent = createServerFn({ method: "GET" }).validator(object({ id: number$1() })).handler(createSsrRpc("d5e3c26bcb0cec5275f60bd57911215da6f4408a38d049f475ccdd255ecdc8de"));
var studentInput = object({
	firstName: string().trim().min(2).max(80),
	lastName: string().trim().min(2).max(80),
	birthDate: string().regex(/^\d{4}-\d{2}-\d{2}$/),
	birthPlace: string().trim().min(2).max(80),
	gender: _enum(["male", "female"]),
	schoolId: number$1(),
	streamId: number$1(),
	sessionId: number$1().optional()
});
var createStudent = createServerFn({ method: "POST" }).validator(studentInput).handler(createSsrRpc("13e7c780c54639e8e96bfb8c4385f57c4dd7181ac7ba77a02709a9daf28e7368"));
var updateStudent = createServerFn({ method: "POST" }).validator(studentInput.extend({ id: number$1() })).handler(createSsrRpc("4059c6a0efae7f6d29f93551cb7574116b36b80470e8bf271fe258faf2b26c70"));
var deleteStudent = createServerFn({ method: "POST" }).validator(object({ id: number$1() })).handler(createSsrRpc("5c6d5e25fa5c09cb14cc4416f0866469ca121af3f940293c17899b14c972508d"));
var saveGrades = createServerFn({ method: "POST" }).validator(object({
	studentId: number$1(),
	grades: array(object({
		subjectId: number$1(),
		score: number$1().min(0).max(20)
	}))
})).handler(createSsrRpc("8df3ed271276bc39937e46a56539d876ade58f0d26b05115ba08b8d7ce1cb0c5"));
var issueCertificate = createServerFn({ method: "POST" }).validator(object({ studentId: number$1() })).handler(createSsrRpc("06ab3a35b1bf0afd89f4d7ecf689209f2b0dac973a3de7835226b7a4cf6cb8aa"));
var createSchool = createServerFn({ method: "POST" }).validator(object({
	name: string().trim().min(3).max(120),
	wilaya: string().trim().min(2).max(40)
})).handler(createSsrRpc("1c26f6040edfe1a3f8f06a72ad2014b58c9c81e612665ac3ffc14cc68f8621cf"));
//#endregion
export { getDashboard as a, listResults as c, listStudents as d, saveGrades as f, deleteStudent as i, listSchools as l, createSchool as n, getStudent as o, updateStudent as p, createStudent as r, issueCertificate as s, Skeleton as t, listStreams as u };
