import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as useStudy, r as Route$4 } from "./router-C-xQh0iG.mjs";
import { n as RoadSign, t as ItText } from "./road-sign-_-tGVxDe.mjs";
import { t as CHAPTERS } from "./curriculum-BHBVcVfN.mjs";
import { t as QUESTIONS } from "./quiz-C2Kzqaia.mjs";
import { r as signById } from "./signs-CNNmKTo_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/esame-CswFHwYr.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Esame() {
	const { ch } = Route$4.useSearch();
	const wrongIds = useStudy((s) => s.wrong);
	const rememberWrong = useStudy((s) => s.rememberWrong);
	const forgetWrong = useStudy((s) => s.forgetWrong);
	const recordExam = useStudy((s) => s.recordExam);
	const [mode, setMode] = (0, import_react.useState)("exam");
	const [phase, setPhase] = (0, import_react.useState)("hub");
	const [items, setItems] = (0, import_react.useState)([]);
	const [index, setIndex] = (0, import_react.useState)(0);
	const [picks, setPicks] = (0, import_react.useState)({});
	const [show, setShow] = (0, import_react.useState)(false);
	const [left, setLeft] = (0, import_react.useState)(1200);
	const finished = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		if (ch) start("practice", ch);
	}, [ch]);
	(0, import_react.useEffect)(() => {
		if (phase !== "run" || mode !== "exam") return;
		const id = window.setInterval(() => {
			setLeft((s) => {
				if (s <= 1) {
					window.clearInterval(id);
					return 0;
				}
				return s - 1;
			});
		}, 1e3);
		return () => window.clearInterval(id);
	}, [phase, mode]);
	(0, import_react.useEffect)(() => {
		if (phase === "run" && mode === "exam" && left === 0) finish();
	}, [
		left,
		phase,
		mode
	]);
	const current = items[index];
	const correctCount = items.filter((q) => picks[q.id] === q.ok).length;
	function start(next, chapter) {
		let pool = QUESTIONS;
		if (next === "practice" && chapter) pool = QUESTIONS.filter((q) => q.ch === chapter);
		if (next === "wrong") pool = QUESTIONS.filter((q) => wrongIds.includes(q.id));
		const taken = next === "exam" ? shuffle(pool).slice(0, 30) : shuffle(pool);
		finished.current = false;
		setMode(next);
		setItems(taken);
		setIndex(0);
		setPicks({});
		setShow(false);
		setLeft(1200);
		setPhase(taken.length ? "run" : "hub");
	}
	function choose(value) {
		if (!current) return;
		setPicks((p) => ({
			...p,
			[current.id]: value
		}));
		if (mode !== "exam") setShow(true);
	}
	function finish() {
		if (finished.current) return;
		finished.current = true;
		const wrong = items.filter((q) => picks[q.id] !== q.ok).map((q) => q.id);
		const rightIds = items.filter((q) => picks[q.id] === q.ok).map((q) => q.id);
		rememberWrong(wrong);
		rightIds.forEach((id) => forgetWrong(id));
		if (mode === "exam") recordExam(items.filter((q) => picks[q.id] === q.ok).length);
		setPhase("result");
	}
	const mm = String(Math.floor(left / 60)).padStart(2, "0");
	const ss = String(left % 60).padStart(2, "0");
	if (phase === "hub") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-primary",
					children: "Quiz vero o falso"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-3xl font-semibold",
					children: "الامتحان"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-2xl text-muted",
					children: "الامتحان الرسمي 30 عبارة صح أو خطأ في 20 دقيقة، والنجاح بأقل من 4 أخطاء. الأسئلة هنا بأسلوب الامتحان ومكتوبة على القانون، وليست نسخة حرفية من قائمة الوزارة."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => start("exam"),
					className: "rounded-2xl bg-primary p-4 text-right text-primary-fg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-2xl font-semibold",
						children: "محاكاة"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 block text-sm",
						children: "30 سؤالًا · 20 دقيقة · بلا شرح حتى النهاية"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => start("wrong"),
					className: "rounded-2xl border border-line bg-surface p-4 text-right",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-2xl font-semibold",
						children: "أخطائي"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "mt-1 block text-sm text-muted",
						children: [wrongIds.length, " سؤالًا محفوظًا من المحاولات"]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-lg font-semibold",
				children: "تدريب فوري حسب الفصل"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-2 grid gap-2 sm:grid-cols-2",
				children: [CHAPTERS.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => start("practice", c.n),
					className: "w-full rounded-xl border border-line bg-surface px-3 py-3 text-right",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm text-muted",
						children: c.n
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 block font-semibold",
						children: c.titleAr
					})]
				}) }, c.n)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => start("practice"),
					className: "w-full rounded-xl border border-line bg-soft px-3 py-3 text-right font-semibold text-primary",
					children: "كل الأسئلة بشرح فوري"
				}) })]
			})] })
		]
	});
	if (phase === "result") {
		const passed = mode === "exam" ? correctCount >= 27 : correctCount === items.length;
		const misses = items.filter((q) => picks[q.id] !== q.ok);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-primary",
					children: mode === "exam" ? "Simulazione" : "Allenamento"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-3xl font-semibold",
					children: passed && mode === "exam" ? "ناجح" : mode === "exam" ? "لم تنجح" : "نتيجة التدريب"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-4xl font-semibold text-primary",
					children: [
						correctCount,
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xl text-muted",
							children: ["/ ", items.length]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted",
					children: mode === "exam" ? passed ? "ثلاثة أخطاء أو أقل. هذا مستوى النجاح في الامتحان الرسمي." : "النجاح يحتاج 27 إجابة صحيحة على الأقل. راجع الشرح تحت." : "الإجابات الخاطئة انضافت إلى خانة أخطائي."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-3",
					children: misses.map((q) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-2xl border border-line bg-surface p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItText, { text: q.it }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted",
								children: q.ar
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 text-sm",
								children: [
									"الصحيح: ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: q.ok ? "صح" : "خطأ" }),
									picks[q.id] === void 0 ? " · تركتها فارغة" : ""
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 rounded-xl bg-soft px-3 py-2 text-sm leading-relaxed",
								children: q.whyAr
							})
						]
					}, q.id))
				}),
				misses.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-2xl bg-soft px-3 py-3",
					children: "لا أخطاء في هذه الجولة."
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setPhase("hub"),
					className: "min-h-11 rounded-full bg-ink px-4 text-surface",
					children: "العودة لقائمة الامتحان"
				})
			]
		});
	}
	if (!current) return null;
	const picked = picks[current.id];
	const sign = current.signId ? signById(current.signId) : void 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						index + 1,
						" / ",
						items.length
					]
				}), mode === "exam" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: `font-semibold ${left < 60 ? "text-accent" : "text-ink"}`,
					children: [
						mm,
						":",
						ss
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "شرح بعد كل إجابة"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-2 overflow-hidden rounded-full bg-line",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-full bg-primary",
					style: { width: `${(index + 1) / items.length * 100}%` }
				})
			}),
			current.signId ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border border-line bg-surface p-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoadSign, {
					id: current.signId,
					className: "mx-auto h-36 w-36"
				}), sign ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-center text-sm text-muted",
					children: sign.nameAr
				}) : null]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItText, {
				text: current.it,
				className: "text-xl font-semibold"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-xl bg-soft px-3 py-3 leading-relaxed",
				children: current.ar
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Answer, {
					on: picked === true,
					tone: "good",
					label: "Vero · صح",
					onClick: () => choose(true)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Answer, {
					on: picked === false,
					tone: "bad",
					label: "Falso · خطأ",
					onClick: () => choose(false)
				})]
			}),
			show && picked !== void 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `rounded-2xl px-3 py-3 ${picked === current.ok ? "bg-soft" : "bg-warn text-warn-ink"}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold",
						children: picked === current.ok ? "إجابة صحيحة" : "إجابة خاطئة"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm",
						children: ["الصحيح: ", current.ok ? "صح / Vero" : "خطأ / Falso"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-relaxed",
						children: current.whyAr
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "min-h-11 rounded-full border border-line px-4",
						onClick: () => {
							setShow(false);
							setIndex((n) => Math.max(0, n - 1));
						},
						disabled: index === 0,
						children: "السابق"
					}),
					index < items.length - 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "min-h-11 rounded-full bg-primary px-4 text-primary-fg",
						onClick: () => {
							setShow(false);
							setIndex((n) => n + 1);
						},
						children: "التالي"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "min-h-11 rounded-full bg-ink px-4 text-surface",
						onClick: finish,
						children: "إنهاء وتصحيح"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "min-h-11 rounded-full px-4 text-muted",
						onClick: () => setPhase("hub"),
						children: "خروج"
					})
				]
			}),
			mode === "exam" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dots, {
				items,
				picks,
				index,
				jump: (n) => {
					setIndex(n);
					setShow(false);
				}
			}) : null
		]
	});
}
function Answer({ label, on, onClick, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: `min-h-14 rounded-2xl text-lg font-semibold ${on ? tone === "good" ? "bg-primary text-primary-fg" : "bg-accent text-accent-fg" : "border border-line bg-surface"}`,
		children: label
	});
}
function Dots({ items, picks, index, jump }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-wrap gap-1",
		children: items.map((q, n) => {
			const filled = picks[q.id] !== void 0;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => jump(n),
				className: `h-9 w-9 rounded-full text-xs ${n === index ? "bg-ink text-surface" : filled ? "bg-soft text-primary" : "border border-line"}`,
				children: n + 1
			}, q.id);
		})
	});
}
function shuffle(list) {
	const a = [...list];
	for (let i = a.length - 1; i > 0; i--) {
		const j = Math.floor(Math.random() * (i + 1));
		const tmp = a[i];
		a[i] = a[j];
		a[j] = tmp;
	}
	return a;
}
//#endregion
export { Esame as component };
