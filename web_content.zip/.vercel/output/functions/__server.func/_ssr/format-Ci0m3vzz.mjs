//#region node_modules/.nitro/vite/services/ssr/assets/format-Ci0m3vzz.js
function formatMmk(value) {
	return `${Math.round(Number.isFinite(value) ? value : 0).toLocaleString("en-US")} MMK`;
}
function formatRange(min, max) {
	if (min === max) return formatMmk(min);
	return `${formatMmk(min)} – ${formatMmk(max)}`;
}
function platformLabel(id) {
	switch (id) {
		case "pc": return "PC (Steam)";
		case "console": return "Console (PlayStation / Xbox)";
		default: return "Mobile (Android / iOS)";
	}
}
//#endregion
export { platformLabel as n, formatRange as t };
