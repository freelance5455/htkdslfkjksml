import { i as __toESM } from "../_runtime.mjs";
import { R as require_react, y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as ArrowDownUp, i as History, n as Sun, r as Moon } from "../_libs/lucide-react.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { t as Decimal } from "../_libs/decimal.js.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BL1TlbwC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
Decimal.set({
	precision: 24,
	rounding: Decimal.ROUND_HALF_UP,
	toExpNeg: -12,
	toExpPos: 21,
	modulo: Decimal.ROUND_FLOOR
});
function D(value) {
	if (value instanceof Decimal) return value;
	if (typeof value === "number") {
		if (!Number.isFinite(value)) throw new Error("non-finite");
		return new Decimal(value.toString());
	}
	return new Decimal(value);
}
var PI = Decimal.acos(D(-1));
var E = Decimal.exp(D(1));
var PHI = D(1).plus(D(5).sqrt()).div(2);
var TAU = PI.mul(2);
var LN2 = Decimal.ln(D(2));
var SQRT2 = D(2).sqrt();
var SPEED_OF_LIGHT = D("299792458");
var GRAVITY = D("9.80665");
var PLANCK = D("6.62607015e-34");
var AVOGADRO = D("6.02214076e23");
var CalcError = class extends Error {
	code;
	constructor(code, message) {
		super(message);
		this.code = code;
		this.name = "CalcError";
	}
};
var ERROR_LABEL = {
	div0: "Cannot divide by zero",
	domain: "Invalid input",
	overflow: "Overflow",
	syntax: "Syntax error",
	bit: "Invalid for this base"
};
function tidy(x) {
	if (!x.isFinite()) throw new CalcError("overflow", "Overflow");
	const nearest = x.toDecimalPlaces(0, Decimal.ROUND_HALF_UP);
	if (x.minus(nearest).abs().lt("1e-14")) return nearest;
	return x;
}
function toRadians(x, angle) {
	if (angle === "deg") return x.mul(PI).div(180);
	if (angle === "grad") return x.mul(PI).div(200);
	return x;
}
function fromRadians(x, angle) {
	if (angle === "deg") return x.mul(180).div(PI);
	if (angle === "grad") return x.mul(200).div(PI);
	return x;
}
function requireDomain(ok, message = "Invalid input") {
	if (!ok) throw new CalcError("domain", message);
}
function applyUnary(fn, x, angle) {
	switch (fn) {
		case "sin": return tidy(Decimal.sin(toRadians(x, angle)));
		case "cos": return tidy(Decimal.cos(toRadians(x, angle)));
		case "tan": {
			const c = tidy(Decimal.cos(toRadians(x, angle)));
			requireDomain(!c.eq(0), "Undefined");
			return tidy(Decimal.sin(toRadians(x, angle)).div(c));
		}
		case "asin":
			requireDomain(x.abs().lte(1));
			return tidy(fromRadians(Decimal.asin(x), angle));
		case "acos":
			requireDomain(x.abs().lte(1));
			return tidy(fromRadians(Decimal.acos(x), angle));
		case "atan": return tidy(fromRadians(Decimal.atan(x), angle));
		case "sinh": return Decimal.sinh(x);
		case "cosh": return Decimal.cosh(x);
		case "tanh": return Decimal.tanh(x);
		case "asinh": return Decimal.asinh(x);
		case "acosh":
			requireDomain(x.gte(1));
			return Decimal.acosh(x);
		case "atanh":
			requireDomain(x.abs().lt(1));
			return Decimal.atanh(x);
		case "sec": {
			const c = tidy(Decimal.cos(toRadians(x, angle)));
			requireDomain(!c.eq(0), "Undefined");
			return D(1).div(c);
		}
		case "csc": {
			const s = tidy(Decimal.sin(toRadians(x, angle)));
			requireDomain(!s.eq(0), "Undefined");
			return D(1).div(s);
		}
		case "cot": {
			const s = tidy(Decimal.sin(toRadians(x, angle)));
			requireDomain(!s.eq(0), "Undefined");
			return tidy(Decimal.cos(toRadians(x, angle))).div(s);
		}
		case "asec":
			requireDomain(x.abs().gte(1));
			return tidy(fromRadians(Decimal.acos(D(1).div(x)), angle));
		case "acsc":
			requireDomain(x.abs().gte(1));
			return tidy(fromRadians(Decimal.asin(D(1).div(x)), angle));
		case "acot":
			if (x.eq(0)) return tidy(fromRadians(PI.div(2), angle));
			return tidy(fromRadians(Decimal.atan(D(1).div(x)), angle));
		case "sech": {
			const c = Decimal.cosh(x);
			requireDomain(!c.eq(0));
			return D(1).div(c);
		}
		case "csch": {
			const s = Decimal.sinh(x);
			requireDomain(!s.eq(0));
			return D(1).div(s);
		}
		case "coth": {
			const s = Decimal.sinh(x);
			requireDomain(!s.eq(0));
			return Decimal.cosh(x).div(s);
		}
		case "ln":
			requireDomain(x.gt(0));
			return Decimal.ln(x);
		case "log":
			requireDomain(x.gt(0));
			return Decimal.log(x, 10);
		case "log2":
			requireDomain(x.gt(0));
			return Decimal.log(x, 2);
		case "exp": return Decimal.exp(x);
		case "exp10": return D(10).pow(x);
		case "exp2": return D(2).pow(x);
		case "sqrt":
			requireDomain(x.gte(0));
			return x.sqrt();
		case "cbrt": return cubeRoot(x);
		case "sq": return x.mul(x);
		case "cube": return x.mul(x).mul(x);
		case "inv":
			requireDomain(!x.eq(0), "Cannot divide by zero");
			return D(1).div(x);
		case "abs": return x.abs();
		case "floor": return x.floor();
		case "ceil": return x.ceil();
		case "round": return x.toDecimalPlaces(0, Decimal.ROUND_HALF_UP);
		case "frac": return x.minus(x.trunc());
		case "fact": return factorial(x);
		case "sign": return D(x.cmp(0));
		case "rand": return D(Math.random().toString());
		case "toDeg": return fromRadians(toRadians(x, angle), "deg");
		case "toRad": return toRadians(x, angle);
		case "toGrad": return fromRadians(toRadians(x, angle), "grad");
		case "percent": return x.div(100);
		case "neg": return x.neg();
		default: throw new CalcError("domain", "Unknown function");
	}
}
function cubeRoot(x) {
	if (x.eq(0)) return D(0);
	return D(x.isNeg() ? -1 : 1).mul(x.abs().pow(D(1).div(3)));
}
function factorial(n) {
	if (!n.isInteger()) throw new CalcError("domain", "Integer required");
	if (n.isNeg()) throw new CalcError("domain", "Invalid input");
	if (n.gt(1e3)) throw new CalcError("overflow", "Overflow");
	let r = D(1);
	const top = n.toNumber();
	for (let i = 2; i <= top; i++) r = r.mul(i);
	return r;
}
function nCr(n, r) {
	if (!n.isInteger() || !r.isInteger()) throw new CalcError("domain", "Integer required");
	if (n.isNeg() || r.isNeg() || r.gt(n)) throw new CalcError("domain", "Invalid input");
	if (r.gt(n.minus(r))) r = n.minus(r);
	let result = D(1);
	const rk = r.toNumber();
	for (let i = 1; i <= rk; i++) result = result.mul(n.minus(i).plus(1)).div(i);
	return result;
}
function nPr(n, r) {
	if (!n.isInteger() || !r.isInteger()) throw new CalcError("domain", "Integer required");
	if (n.isNeg() || r.isNeg() || r.gt(n)) throw new CalcError("domain", "Invalid input");
	let result = D(1);
	const rk = r.toNumber();
	for (let i = 0; i < rk; i++) result = result.mul(n.minus(i));
	return result;
}
function gcdDec(a, b) {
	if (!a.isInteger() || !b.isInteger()) throw new CalcError("domain", "Integer required");
	let x = a.abs();
	let y = b.abs();
	while (!y.eq(0)) {
		const t = y;
		y = x.mod(y);
		x = t;
	}
	return x;
}
function lcmDec(a, b) {
	if (a.eq(0) || b.eq(0)) return D(0);
	return a.abs().mul(b.abs()).div(gcdDec(a, b));
}
function applyBinary(op, a, b) {
	switch (op) {
		case "add": return a.plus(b);
		case "sub": return a.minus(b);
		case "mul": return a.mul(b);
		case "div":
			if (b.eq(0)) throw new CalcError("div0", "Cannot divide by zero");
			return a.div(b);
		case "pow":
			if (a.eq(0) && b.lte(0)) throw new CalcError("domain", "Invalid input");
			if (a.isNeg() && !b.isInteger()) throw new CalcError("domain", "Invalid input");
			return a.pow(b);
		case "root": {
			if (b.eq(0)) throw new CalcError("div0", "Cannot divide by zero");
			const inv = D(1).div(b);
			if (a.isNeg() && !inv.isInteger()) throw new CalcError("domain", "Invalid input");
			if (a.isNeg()) return applyUnary("neg", a.abs().pow(inv), "rad");
			return a.pow(inv);
		}
		case "mod":
			if (b.eq(0)) throw new CalcError("div0", "Cannot divide by zero");
			return a.mod(b);
		case "nCr": return nCr(a, b);
		case "nPr": return nPr(a, b);
		case "logy":
			if (a.lte(0) || a.eq(1) || b.lte(0)) throw new CalcError("domain", "Invalid input");
			return Decimal.log(b, a);
		case "gcd": return gcdDec(a, b);
		case "lcm": return lcmDec(a, b);
		default: throw new CalcError("syntax", "Unknown operator");
	}
}
function constantValue(name) {
	switch (name) {
		case "pi": return PI;
		case "e": return E;
		case "phi": return PHI;
		case "tau": return TAU;
		case "sqrt2": return SQRT2;
		case "ln2": return LN2;
		case "c": return SPEED_OF_LIGHT;
		case "g": return GRAVITY;
		case "h": return PLANCK;
		case "NA": return AVOGADRO;
	}
}
function applyPercent(x, pendingLeft, op) {
	if (pendingLeft && (op === "add" || op === "sub")) return pendingLeft.mul(x).div(100);
	return x.div(100);
}
var PREC = {
	add: 1,
	sub: 1,
	mul: 2,
	div: 2,
	mod: 2,
	gcd: 2,
	lcm: 2,
	pow: 3,
	root: 3,
	nCr: 3,
	nPr: 3,
	logy: 3
};
var RIGHT_ASSOC = /* @__PURE__ */ new Set(["pow", "root"]);
function evaluateTokens(tokens, leftToRight) {
	if (tokens.length === 0) return D(0);
	return evalRpn(leftToRight ? toRpnLeft(tokens) : toRpn(tokens));
}
function toRpn(tokens) {
	const out = [];
	const ops = [];
	for (const tok of tokens) if (tok.t === "n") out.push(tok);
	else if (tok.t === "b") {
		while (ops.length) {
			const top = ops[ops.length - 1];
			if (!top || top.t !== "b") break;
			const pTop = PREC[top.v];
			const pCur = PREC[tok.v];
			const right = RIGHT_ASSOC.has(tok.v);
			if (pTop > pCur || pTop === pCur && !right) out.push(ops.pop());
			else break;
		}
		ops.push(tok);
	} else if (tok.t === "lp") ops.push(tok);
	else if (tok.t === "rp") {
		let found = false;
		while (ops.length) {
			const top = ops.pop();
			if (top.t === "lp") {
				found = true;
				break;
			}
			out.push(top);
		}
		if (!found) throw new CalcError("syntax", "Mismatched parentheses");
	}
	while (ops.length) {
		const top = ops.pop();
		if (top.t === "lp" || top.t === "rp") throw new CalcError("syntax", "Mismatched parentheses");
		out.push(top);
	}
	return out;
}
function toRpnLeft(tokens) {
	const out = [];
	const ops = [];
	for (const tok of tokens) if (tok.t === "n") out.push(tok);
	else if (tok.t === "b") {
		while (ops.length && ops[ops.length - 1]?.t === "b") out.push(ops.pop());
		ops.push(tok);
	} else if (tok.t === "lp") ops.push(tok);
	else if (tok.t === "rp") {
		let found = false;
		while (ops.length) {
			const top = ops.pop();
			if (top.t === "lp") {
				found = true;
				break;
			}
			out.push(top);
		}
		if (!found) throw new CalcError("syntax", "Mismatched parentheses");
	}
	while (ops.length) {
		const top = ops.pop();
		if (top.t === "lp" || top.t === "rp") throw new CalcError("syntax", "Mismatched parentheses");
		out.push(top);
	}
	return out;
}
function evalRpn(rpn) {
	const stack = [];
	for (const tok of rpn) if (tok.t === "n") stack.push(D(tok.v));
	else if (tok.t === "b") {
		const b = stack.pop();
		const a = stack.pop();
		if (a === void 0 || b === void 0) throw new CalcError("syntax", "Syntax error");
		stack.push(applyBinary(tok.v, a, b));
	}
	if (stack.length !== 1 || !stack[0]) throw new CalcError("syntax", "Syntax error");
	return stack[0];
}
function lastNumberInTokens(tokens) {
	for (let i = tokens.length - 1; i >= 0; i--) {
		const tok = tokens[i];
		if (tok?.t === "n") return D(tok.v);
	}
	return null;
}
function lastBinaryOp(tokens) {
	for (let i = tokens.length - 1; i >= 0; i--) {
		const tok = tokens[i];
		if (tok?.t === "b") return tok.v;
	}
	return null;
}
function parenDepth(tokens) {
	let d = 0;
	for (const tok of tokens) if (tok.t === "lp") d++;
	else if (tok.t === "rp") d--;
	return d;
}
function tokensToExpr(tokens) {
	const bits = [];
	for (const tok of tokens) if (tok.t === "n") bits.push(tok.v);
	else if (tok.t === "b") bits.push(opSym(tok.v));
	else if (tok.t === "lp") bits.push("(");
	else bits.push(")");
	return bits.join(" ").replace(/\(\s+/g, "(").replace(/\s+\)/g, ")").replace(/\s+\^\s+/g, "^");
}
function opSym(op) {
	return {
		add: "+",
		sub: "−",
		mul: "×",
		div: "÷",
		pow: "^",
		root: "ʸ√",
		mod: "mod",
		nCr: "C",
		nPr: "P",
		logy: "log",
		gcd: "gcd",
		lcm: "lcm"
	}[op];
}
var GROUP = new Intl.NumberFormat("en-US");
function formatDecimal(value, digits = 12) {
	if (!value.isFinite()) return "Error";
	const snapped = snapNearInteger(value);
	const abs = snapped.abs();
	if (abs.eq(0)) return "0";
	const tooBig = abs.gte(D(10).pow(digits));
	const tooSmall = abs.lt(D(10).pow(1 - digits));
	if (tooBig || tooSmall) return tidyExp(snapped.toExponential(Math.max(1, digits - 1), Decimal.ROUND_HALF_UP));
	const sig = snapped.toSignificantDigits(digits, Decimal.ROUND_HALF_UP);
	let raw = sig.toFixed();
	if (raw.includes("e") || raw.includes("E")) return tidyExp(sig.toExponential(digits - 1, Decimal.ROUND_HALF_UP));
	if (raw.includes(".")) raw = raw.replace(/(\.\d*?)0+$/, "$1").replace(/\.$/, "");
	return groupInt(raw);
}
function snapNearInteger(value) {
	const nearest = value.toDecimalPlaces(0, Decimal.ROUND_HALF_UP);
	if (value.minus(nearest).abs().lt("1e-14")) return nearest;
	return value;
}
function tidyExp(exp) {
	const [mant, rest] = exp.split(/e/i);
	if (!mant || rest === void 0) return exp;
	return `${mant.replace(/(\.\d*?)0+$/, "$1").replace(/\.$/, "")}e${rest.startsWith("-") || rest.startsWith("+") ? rest[0] : "+"}${rest.replace(/^[+-]/, "").replace(/^0+/, "") || "0"}`;
}
function groupInt(raw) {
	const neg = raw.startsWith("-");
	const [intPart, frac] = (neg ? raw.slice(1) : raw).split(".");
	const grouped = GROUP.format(Number(intPart));
	const out = frac !== void 0 ? `${grouped}.${frac}` : grouped;
	return neg ? `−${out}` : out;
}
function stripGrouping(display) {
	return display.replace(/,/g, "").replace(/−/g, "-");
}
function parseDisplay(display) {
	const raw = stripGrouping(display).trim();
	if (!raw || raw === "-" || raw === "." || raw === "-.") return D(0);
	return D(raw);
}
function formatLive(entry) {
	if (!entry) return "0";
	if (entry.includes("e") || entry.includes("E")) {
		const [mant, rest] = entry.split(/e/i);
		const sign = (rest ?? "").startsWith("-") ? "−" : "";
		const ed = (rest ?? "").replace(/^[+-]/, "") || "0";
		return `${formatLive(mant ?? "0")}e${sign || "+"}${ed}`;
	}
	const neg = entry.startsWith("-");
	const [intPart, frac] = (neg ? entry.slice(1) : entry).split(".");
	const grouped = (intPart || "0").replace(/\B(?=(\d{3})+(?!\d))/g, ",");
	const out = frac !== void 0 ? `${grouped}.${frac}` : grouped;
	return neg ? `−${out}` : out;
}
var initialEngine = () => ({
	tokens: [],
	entry: "0",
	entering: false,
	overwrite: true,
	ee: false,
	display: "0",
	expression: "",
	error: null,
	memory: "0",
	history: [],
	angle: "deg",
	second: false,
	hyp: false,
	lastOp: null
});
function reduce(state, action, leftToRight) {
	try {
		switch (action.type) {
			case "digit": return inputDigit(clearErr(state), action.digit);
			case "dot": return inputDot(clearErr(state));
			case "ee": return inputEE(clearErr(state));
			case "op": return inputOp(clearErr(state), action.op, leftToRight);
			case "unary": return inputUnary(clearErr(state), action.fn);
			case "const": return inputConst(clearErr(state), action.name);
			case "equals": return inputEquals(clearErr(state), leftToRight);
			case "clear": return inputClear(state);
			case "allClear": return {
				...initialEngine(),
				memory: state.memory,
				history: state.history,
				angle: state.angle
			};
			case "backspace": return inputBackspace(clearErr(state));
			case "sign": return inputSign(clearErr(state));
			case "percent": return inputPercent(clearErr(state));
			case "lparen": return inputLParen(clearErr(state));
			case "rparen": return inputRParen(clearErr(state), leftToRight);
			case "memoryClear": return {
				...state,
				memory: "0"
			};
			case "memoryRecall": return setEntry(clearErr(state), state.memory, true);
			case "memoryAdd": return {
				...state,
				memory: D(state.memory).plus(currentValue(state)).toString()
			};
			case "memorySub": return {
				...state,
				memory: D(state.memory).minus(currentValue(state)).toString()
			};
			case "memoryStore": return {
				...state,
				memory: currentValue(state).toString()
			};
			case "toggleSecond": return {
				...state,
				second: !state.second
			};
			case "toggleHyp": return {
				...state,
				hyp: !state.hyp
			};
			case "cycleAngle": {
				const next = state.angle === "deg" ? "rad" : state.angle === "rad" ? "grad" : "deg";
				return {
					...state,
					angle: next,
					second: false
				};
			}
			case "setAngle": return {
				...state,
				angle: action.angle
			};
			case "load": return setEntry({
				...clearErr(state),
				tokens: [],
				expression: action.expr ?? "",
				lastOp: null
			}, action.value, true);
			case "clearHistory": return {
				...state,
				history: []
			};
			case "clearError": return clearErr(state);
			default: return state;
		}
	} catch (err) {
		return fail(state, err);
	}
}
function clearErr(state) {
	if (!state.error) return state;
	return {
		...state,
		error: null
	};
}
function fail(state, err) {
	const message = err instanceof CalcError ? ERROR_LABEL[err.code] : err instanceof Error ? err.message : "Error";
	return {
		...state,
		error: message,
		display: "Error",
		overwrite: true,
		entering: false
	};
}
function currentValue(state) {
	return parseDisplay(state.entry);
}
function paint(state, extra = {}) {
	const next = {
		...state,
		...extra
	};
	if (extra.expression === void 0) next.expression = next.tokens.length > 0 ? tokensToExpr(next.tokens) : next.expression;
	if (!next.error) try {
		next.display = next.entering && !next.overwrite ? formatLive(next.entry) : formatDecimal(D(stripGrouping(next.entry)));
	} catch {
		next.display = next.entry;
	}
	return next;
}
function setEntry(state, value, overwrite) {
	const dec = D(value);
	return paint(state, {
		entry: dec.toString(),
		display: formatDecimal(dec),
		overwrite,
		entering: !overwrite,
		ee: false,
		error: null
	});
}
function inputDigit(state, digit) {
	if (state.overwrite || !state.entering) return paint(state, {
		entry: digit,
		entering: true,
		overwrite: false,
		ee: false,
		expression: state.tokens.length ? void 0 : ""
	});
	if (state.ee) {
		const [mant, exp = ""] = splitEE(state.entry);
		const sign = exp.startsWith("-") ? "-" : exp.startsWith("+") ? "+" : "";
		const body = exp.replace(/^[+-]/, "");
		const nextExp = (body === "0" ? "" : body) + digit;
		if (nextExp.length > 6) return state;
		return paint(state, { entry: `${mant}e${sign}${nextExp || "0"}` });
	}
	const raw = stripGrouping(state.entry);
	if (raw.replace("-", "").replace(".", "").length >= 18) return state;
	if (raw === "0") return paint(state, { entry: digit });
	if (raw === "-0") return paint(state, { entry: `-${digit}` });
	return paint(state, { entry: raw + digit });
}
function inputDot(state) {
	if (state.ee) return state;
	if (state.overwrite || !state.entering) return paint(state, {
		entry: "0.",
		entering: true,
		overwrite: false
	});
	const raw = stripGrouping(state.entry);
	if (raw.includes(".")) return state;
	return paint(state, { entry: raw + "." });
}
function inputEE(state) {
	if (state.overwrite || !state.entering) return paint(state, {
		entry: "1e0",
		entering: true,
		overwrite: false,
		ee: true
	});
	if (state.entry.includes("e") || state.entry.includes("E")) return paint(state, { ee: true });
	return paint(state, {
		entry: `${stripGrouping(state.entry)}e0`,
		ee: true
	});
}
function splitEE(entry) {
	const idx = entry.toLowerCase().lastIndexOf("e");
	if (idx < 0) return [entry, ""];
	return [entry.slice(0, idx), entry.slice(idx + 1)];
}
function commitEntry(state) {
	const last = state.tokens[state.tokens.length - 1];
	if (last?.t === "n" && !state.entering && state.overwrite) return state;
	if (last?.t === "rp") return state;
	const value = currentValue(state).toString();
	return {
		...state,
		tokens: [...state.tokens, {
			t: "n",
			v: value
		}],
		entering: false,
		overwrite: true,
		ee: false
	};
}
function inputOp(state, op, _ltr) {
	let next = state;
	const last = next.tokens[next.tokens.length - 1];
	if (last?.t === "b" && (next.overwrite || !next.entering)) {
		const tokens = [...next.tokens];
		tokens[tokens.length - 1] = {
			t: "b",
			v: op
		};
		return paint({
			...next,
			tokens,
			lastOp: {
				op,
				operand: next.entry
			}
		});
	}
	if (!(last?.t === "rp" && (next.overwrite || !next.entering))) next = commitEntry(next);
	return paint({
		...next,
		tokens: [...next.tokens, {
			t: "b",
			v: op
		}],
		overwrite: true,
		entering: false,
		lastOp: {
			op,
			operand: next.entry
		}
	});
}
function inputUnary(state, fn) {
	const result = applyUnary(mapHyp(fn, state.hyp), currentValue(state), state.angle);
	return setEntry({
		...state,
		hyp: false,
		second: false
	}, result.toString(), true);
}
function mapHyp(fn, hyp) {
	if (!hyp) return fn;
	return {
		sin: "sinh",
		cos: "cosh",
		tan: "tanh",
		asin: "asinh",
		acos: "acosh",
		atan: "atanh",
		sec: "sech",
		csc: "csch",
		cot: "coth"
	}[fn] ?? fn;
}
function inputConst(state, name) {
	const v = constantValue(name);
	return setEntry({
		...state,
		second: false
	}, v.toString(), true);
}
function inputEquals(state, leftToRight) {
	if (state.lastOp && state.tokens.length === 0 && state.overwrite && !state.entering) return finish(state, evaluateTokens([
		{
			t: "n",
			v: currentValue(state).toString()
		},
		{
			t: "b",
			v: state.lastOp.op
		},
		{
			t: "n",
			v: state.lastOp.operand
		}
	], leftToRight), `${formatDecimal(currentValue(state))} ${opLabel(state.lastOp.op)} ${formatDecimal(D(state.lastOp.operand))}`);
	let tokens = state.tokens;
	const last = tokens[tokens.length - 1];
	if (!last || last.t === "b" || last.t === "lp") tokens = [...tokens, {
		t: "n",
		v: currentValue(state).toString()
	}];
	else if (state.entering) tokens = [...tokens, {
		t: "n",
		v: currentValue(state).toString()
	}];
	while (parenDepth(tokens) > 0) tokens = [...tokens, { t: "rp" }];
	if (tokens.length === 0) return paint(state, {
		overwrite: true,
		entering: false
	});
	const expr = tokensToExpr(tokens);
	const result = evaluateTokens(tokens, leftToRight);
	const operand = lastNumberInTokens(tokens);
	const op = lastBinaryOp(tokens);
	return finish(state, result, expr, op && operand ? {
		op,
		operand: operand.toString()
	} : state.lastOp);
}
function opLabel(op) {
	return {
		add: "+",
		sub: "−",
		mul: "×",
		div: "÷",
		pow: "^",
		root: "ʸ√",
		mod: "mod",
		nCr: "nCr",
		nPr: "nPr",
		logy: "log",
		gcd: "gcd",
		lcm: "lcm"
	}[op];
}
function finish(state, result, expr, lastOp = state.lastOp) {
	const formatted = formatDecimal(result);
	const item = {
		id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
		expression: expr,
		result: formatted,
		at: Date.now()
	};
	return paint(state, {
		tokens: [],
		entry: result.toString(),
		display: formatted,
		expression: expr,
		overwrite: true,
		entering: false,
		ee: false,
		error: null,
		lastOp,
		history: [item, ...state.history].slice(0, 50)
	});
}
function inputClear(state) {
	if (state.error) return paint({
		...state,
		error: null,
		entry: "0",
		overwrite: true,
		entering: false,
		ee: false
	});
	if (state.entering && state.entry !== "0") return paint(state, {
		entry: "0",
		entering: false,
		overwrite: true,
		ee: false
	});
	return {
		...initialEngine(),
		memory: state.memory,
		history: state.history,
		angle: state.angle
	};
}
function inputBackspace(state) {
	if (state.overwrite || !state.entering) return state;
	const raw = stripGrouping(state.entry);
	if (state.ee) {
		const [mant, exp = ""] = splitEE(raw);
		const sign = exp.startsWith("-") ? "-" : "";
		const body = exp.replace(/^[+-]/, "");
		if (body.length <= 1) return paint(state, {
			entry: mant,
			ee: false
		});
		return paint(state, { entry: `${mant}e${sign}${body.slice(0, -1)}` });
	}
	const next = raw.slice(0, -1);
	if (!next || next === "-" || next === "-0") return paint(state, {
		entry: "0",
		entering: false,
		overwrite: true
	});
	return paint(state, { entry: next });
}
function inputSign(state) {
	if (state.ee) {
		const [mant, exp = "0"] = splitEE(stripGrouping(state.entry));
		const body = exp.replace(/^[+-]/, "") || "0";
		return paint(state, { entry: `${mant}e${exp.startsWith("-") ? "+" : "-"}${body}` });
	}
	const raw = stripGrouping(state.entry);
	if (raw.startsWith("-")) return paint(state, { entry: raw.slice(1) || "0" });
	if (raw === "0") return paint(state, {
		entry: "-0",
		entering: true,
		overwrite: false
	});
	return paint(state, {
		entry: `-${raw}`,
		entering: true,
		overwrite: false
	});
}
function inputPercent(state) {
	const left = lastNumberInTokens(state.tokens);
	const op = lastBinaryOp(state.tokens);
	return setEntry(state, applyPercent(currentValue(state), left, op).toString(), true);
}
function inputLParen(state) {
	const last = state.tokens[state.tokens.length - 1];
	let tokens = state.tokens;
	if (last?.t === "n" || last?.t === "rp") tokens = [...tokens, {
		t: "b",
		v: "mul"
	}];
	if (state.entering && !state.overwrite) tokens = [
		...tokens,
		{
			t: "n",
			v: currentValue(state).toString()
		},
		{
			t: "b",
			v: "mul"
		}
	];
	return paint({
		...state,
		tokens: [...tokens, { t: "lp" }],
		entry: "0",
		overwrite: true,
		entering: false,
		ee: false
	});
}
function inputRParen(state, _leftToRight) {
	if (parenDepth(state.tokens) <= 0) return state;
	let next = state;
	const last = next.tokens[next.tokens.length - 1];
	if (!last || last.t === "b" || last.t === "lp" || next.entering) next = commitEntry(next);
	return paint({
		...next,
		tokens: [...next.tokens, { t: "rp" }],
		overwrite: true,
		entering: false
	});
}
function memoryActive(state) {
	try {
		return !D(state.memory).eq(0);
	} catch {
		return false;
	}
}
function canClearEntry(state) {
	return Boolean(state.error || state.entering && state.entry !== "0" || state.display !== "0");
}
function maskFor(wordSize) {
	return (1n << BigInt(wordSize)) - 1n;
}
function wrapBits(value, wordSize) {
	return value & maskFor(wordSize);
}
function toSigned(value, wordSize) {
	const masked = wrapBits(value, wordSize);
	if (masked & 1n << BigInt(wordSize - 1)) return masked - (1n << BigInt(wordSize));
	return masked;
}
function applyBitOp(op, a, b, wordSize) {
	const mask = maskFor(wordSize);
	const x = a & mask;
	const y = b & mask;
	const w = BigInt(wordSize);
	switch (op) {
		case "and": return x & y;
		case "or": return x | y;
		case "xor": return x ^ y;
		case "nand": return ~(x & y) & mask;
		case "nor": return ~(x | y) & mask;
		case "xnor": return ~(x ^ y) & mask;
		case "lsh": return x << (y < 0n ? 0n : y > w ? w : y) & mask;
		case "rsh": return x >> (y < 0n ? 0n : y > w ? w : y);
		case "rol": {
			const s = (y % w + w) % w;
			return (x << s | x >> w - s) & mask;
		}
		case "ror": {
			const s = (y % w + w) % w;
			return (x >> s | x << w - s) & mask;
		}
	}
}
function bitNot(value, wordSize) {
	return ~value & maskFor(wordSize);
}
var BASE_DIGITS = {
	2: "01",
	8: "01234567",
	10: "0123456789",
	16: "0123456789ABCDEF"
};
function isDigitForBase(ch, base) {
	return BASE_DIGITS[base].includes(ch.toUpperCase());
}
function parseBase(entry, base) {
	const raw = entry.replace(/\s+/g, "").replace(/−/g, "-");
	if (!raw || raw === "-" || raw === "+") return 0n;
	try {
		if (base === 10) return BigInt(raw);
		const neg = raw.startsWith("-");
		const body = (neg ? raw.slice(1) : raw).toUpperCase();
		if (!body) return 0n;
		const n = BigInt(basePrefix(base) + body);
		return neg ? -n : n;
	} catch {
		throw new CalcError("bit", "Invalid number");
	}
}
function basePrefix(base) {
	if (base === 2) return "0b";
	if (base === 8) return "0o";
	if (base === 16) return "0x";
	return "";
}
function formatProgEntry(value, base, wordSize, signed) {
	const masked = wrapBits(value, wordSize);
	if (base === 10) return (signed ? toSigned(masked, wordSize) : masked).toString(10);
	const digits = masked.toString(base).toUpperCase();
	if (base === 2) return group(digits.padStart(wordSize, "0"), 4);
	if (base === 16) return group(digits.padStart(Math.ceil(wordSize / 4), "0"), 4);
	return digits;
}
function group(s, n) {
	const parts = [];
	for (let i = s.length; i > 0; i -= n) parts.unshift(s.slice(Math.max(0, i - n), i));
	return parts.join(" ");
}
function toggleBit(value, index, wordSize) {
	if (index < 0 || index >= wordSize) return wrapBits(value, wordSize);
	return wrapBits(value ^ 1n << BigInt(index), wordSize);
}
function u(id, label, toBase) {
	return {
		id,
		label,
		toBase
	};
}
var CATEGORIES = [
	{
		id: "length",
		label: "Length",
		units: [
			u("m", "Meters", 1),
			u("km", "Kilometers", 1e3),
			u("cm", "Centimeters", .01),
			u("mm", "Millimeters", .001),
			u("um", "Micrometers", 1e-6),
			u("nm", "Nanometers", 1e-9),
			u("mi", "Miles", 1609.344),
			u("yd", "Yards", .9144),
			u("ft", "Feet", .3048),
			u("in", "Inches", .0254),
			u("nmi", "Nautical miles", 1852),
			u("ly", "Light years", 9460730472580800),
			u("au", "Astronomical units", 149597870700)
		]
	},
	{
		id: "area",
		label: "Area",
		units: [
			u("m2", "Square meters", 1),
			u("km2", "Square kilometers", 1e6),
			u("cm2", "Square centimeters", 1e-4),
			u("mm2", "Square millimeters", 1e-6),
			u("ha", "Hectares", 1e4),
			u("ac", "Acres", 4046.8564224),
			u("mi2", "Square miles", 2589988.110336),
			u("ft2", "Square feet", .09290304),
			u("in2", "Square inches", 64516e-8)
		]
	},
	{
		id: "volume",
		label: "Volume",
		units: [
			u("m3", "Cubic meters", 1),
			u("l", "Liters", .001),
			u("ml", "Milliliters", 1e-6),
			u("gal", "US gallons", .003785411784),
			u("qt", "US quarts", .000946352946),
			u("pt", "US pints", .000473176473),
			u("cup", "US cups", .0002365882365),
			u("floz", "US fl oz", 295735295625e-16),
			u("tbsp", "Tablespoons", 1478676478125e-17),
			u("tsp", "Teaspoons", 492892159375e-17),
			u("impgal", "Imperial gallons", .00454609),
			u("ft3", "Cubic feet", .028316846592),
			u("in3", "Cubic inches", 16387064e-12)
		]
	},
	{
		id: "mass",
		label: "Mass",
		units: [
			u("kg", "Kilograms", 1),
			u("g", "Grams", .001),
			u("mg", "Milligrams", 1e-6),
			u("t", "Metric tons", 1e3),
			u("lb", "Pounds", .45359237),
			u("oz", "Ounces", .028349523125),
			u("st", "Stone", 6.35029318),
			u("ton", "US tons", 907.18474),
			u("ukton", "Imperial tons", 1016.0469088)
		]
	},
	{
		id: "temperature",
		label: "Temperature",
		temperature: true,
		units: [
			{
				id: "C",
				label: "Celsius",
				kind: "C"
			},
			{
				id: "F",
				label: "Fahrenheit",
				kind: "F"
			},
			{
				id: "K",
				label: "Kelvin",
				kind: "K"
			}
		]
	},
	{
		id: "speed",
		label: "Speed",
		units: [
			u("mps", "Meters/second", 1),
			u("kph", "Kilometers/hour", 1 / 3.6),
			u("mph", "Miles/hour", .44704),
			u("fps", "Feet/second", .3048),
			u("knot", "Knots", .514444444),
			u("c", "Speed of light", 299792458)
		]
	},
	{
		id: "time",
		label: "Time",
		units: [
			u("s", "Seconds", 1),
			u("ms", "Milliseconds", .001),
			u("us", "Microseconds", 1e-6),
			u("ns", "Nanoseconds", 1e-9),
			u("min", "Minutes", 60),
			u("h", "Hours", 3600),
			u("d", "Days", 86400),
			u("wk", "Weeks", 604800),
			u("yr", "Years", 31557600)
		]
	},
	{
		id: "data",
		label: "Data",
		units: [
			u("b", "Bits", 1),
			u("B", "Bytes", 8),
			u("kb", "Kilobits", 1e3),
			u("kib", "Kibibits", 1024),
			u("KB", "Kilobytes", 8e3),
			u("KiB", "Kibibytes", 8192),
			u("MB", "Megabytes", 8e6),
			u("MiB", "Mebibytes", 8388608),
			u("GB", "Gigabytes", 8e9),
			u("GiB", "Gibibytes", 8 * 1024 ** 3),
			u("TB", "Terabytes", 8e12),
			u("TiB", "Tebibytes", 8 * 1024 ** 4)
		]
	},
	{
		id: "energy",
		label: "Energy",
		units: [
			u("J", "Joules", 1),
			u("kJ", "Kilojoules", 1e3),
			u("cal", "Calories", 4.184),
			u("kcal", "Kilocalories", 4184),
			u("Wh", "Watt hours", 3600),
			u("kWh", "Kilowatt hours", 36e5),
			u("eV", "Electronvolts", 1602176634e-28),
			u("btu", "BTU", 1055.05585262)
		]
	},
	{
		id: "power",
		label: "Power",
		units: [
			u("W", "Watts", 1),
			u("kW", "Kilowatts", 1e3),
			u("MW", "Megawatts", 1e6),
			u("hp", "Horsepower", 745.69987158227),
			u("btuh", "BTU/hour", .29307107017222)
		]
	},
	{
		id: "pressure",
		label: "Pressure",
		units: [
			u("Pa", "Pascals", 1),
			u("kPa", "Kilopascals", 1e3),
			u("bar", "Bar", 1e5),
			u("atm", "Atmospheres", 101325),
			u("psi", "PSI", 6894.757293168),
			u("torr", "Torr", 133.322368421),
			u("mmHg", "mmHg", 133.322368421)
		]
	},
	{
		id: "angle",
		label: "Angle",
		units: [
			u("rad", "Radians", 1),
			u("deg", "Degrees", Math.PI / 180),
			u("grad", "Gradians", Math.PI / 200),
			u("arcmin", "Arcminutes", Math.PI / 10800),
			u("arcsec", "Arcseconds", Math.PI / 648e3),
			u("turn", "Turns", Math.PI * 2)
		]
	},
	{
		id: "frequency",
		label: "Frequency",
		units: [
			u("Hz", "Hertz", 1),
			u("kHz", "Kilohertz", 1e3),
			u("MHz", "Megahertz", 1e6),
			u("GHz", "Gigahertz", 1e9),
			u("rpm", "RPM", 1 / 60)
		]
	},
	{
		id: "force",
		label: "Force",
		units: [
			u("N", "Newtons", 1),
			u("kN", "Kilonewtons", 1e3),
			u("lbf", "Pound-force", 4.4482216152605),
			u("kgf", "Kilogram-force", 9.80665),
			u("dyn", "Dynes", 1e-5)
		]
	},
	{
		id: "fuel",
		label: "Fuel economy",
		units: [
			u("lp100", "L/100 km", 1),
			u("mpgUS", "MPG (US)", 0),
			u("mpgUK", "MPG (UK)", 0),
			u("kpl", "km/L", 0)
		]
	}
];
function isTemp(u) {
	return "kind" in u;
}
function toKelvin(value, kind) {
	if (kind === "K") return value;
	if (kind === "C") return value + 273.15;
	return (value - 32) * 5 / 9 + 273.15;
}
function fromKelvin(k, kind) {
	if (kind === "K") return k;
	if (kind === "C") return k - 273.15;
	return (k - 273.15) * 9 / 5 + 32;
}
var MPG_US_PER_LP100 = 235.214583;
var MPG_UK_PER_LP100 = 282.480936;
var KPL_PER_LP100 = 100;
function convertValue(value, categoryId, fromId, toId) {
	const cat = CATEGORIES.find((c) => c.id === categoryId);
	if (!cat) return value;
	const from = cat.units.find((x) => x.id === fromId);
	const to = cat.units.find((x) => x.id === toId);
	if (!from || !to) return value;
	if (cat.temperature && isTemp(from) && isTemp(to)) return fromKelvin(toKelvin(value, from.kind), to.kind);
	if (cat.id === "fuel") return fromLp100(toLp100(value, fromId), toId);
	if (!isTemp(from) && !isTemp(to)) return value * from.toBase / to.toBase;
	return value;
}
function toLp100(value, id) {
	if (id === "lp100") return value;
	if (value === 0) return 0;
	if (id === "mpgUS") return MPG_US_PER_LP100 / value;
	if (id === "mpgUK") return MPG_UK_PER_LP100 / value;
	if (id === "kpl") return KPL_PER_LP100 / value;
	return value;
}
function fromLp100(lp100, id) {
	if (id === "lp100") return lp100;
	if (lp100 === 0) return 0;
	if (id === "mpgUS") return MPG_US_PER_LP100 / lp100;
	if (id === "mpgUK") return MPG_UK_PER_LP100 / lp100;
	if (id === "kpl") return KPL_PER_LP100 / lp100;
	return lp100;
}
var initialProg = () => ({
	value: "0",
	entry: "0",
	entering: false,
	overwrite: true,
	pendingOp: null,
	pendingValue: null,
	base: 10,
	wordSize: 64,
	signed: true
});
var initialConvert = () => ({
	category: "length",
	fromId: "m",
	toId: "ft",
	input: "1"
});
function asBig(s) {
	try {
		return BigInt(s);
	} catch {
		return 0n;
	}
}
function paintProg(p, value) {
	const wrapped = wrapBits(value, p.wordSize);
	const entry = formatProgEntry(wrapped, p.base, p.wordSize, p.signed);
	return {
		...p,
		value: wrapped.toString(),
		entry,
		overwrite: true,
		entering: false
	};
}
var useCalc = create()(persist((set, get) => ({
	...initialEngine(),
	mode: "basic",
	theme: "amoled",
	panel: "none",
	prog: initialProg(),
	convert: initialConvert(),
	dispatch: (action) => {
		const s = get();
		set(reduce(s, action, s.mode === "basic"));
	},
	setMode: (mode) => {
		const s = get();
		if (mode === "programmer" && s.mode !== "programmer") {
			const n = Number(s.entry);
			const v = Number.isFinite(n) ? BigInt(Math.trunc(n)) : 0n;
			set({
				mode,
				panel: "none",
				prog: paintProg({ ...s.prog }, v)
			});
			return;
		}
		set({
			mode,
			panel: "none"
		});
	},
	setTheme: (theme) => set({ theme }),
	setPanel: (panel) => set({ panel }),
	progDigit: (d) => {
		const p = get().prog;
		if (!isDigitForBase(d, p.base)) return;
		if (p.overwrite || !p.entering) {
			const entry = d;
			set({ prog: {
				...p,
				entry,
				entering: true,
				overwrite: false,
				value: parseBase(entry, p.base).toString()
			} });
			return;
		}
		const raw = p.entry.replace(/\s+/g, "");
		if (raw.replace("-", "").length >= 64) return;
		const entry = raw === "0" ? d : raw + d;
		set({ prog: {
			...p,
			entry,
			value: parseBase(entry, p.base).toString()
		} });
	},
	progOp: (op) => {
		const p = get().prog;
		const value = wrapBits(asBig(p.value), p.wordSize);
		set({ prog: {
			...p,
			pendingOp: op,
			pendingValue: value.toString(),
			overwrite: true,
			entering: false
		} });
	},
	progNot: () => {
		const p = get().prog;
		set({ prog: paintProg(p, bitNot(asBig(p.value), p.wordSize)) });
	},
	progEquals: () => {
		const p = get().prog;
		if (!p.pendingOp || p.pendingValue === null) return;
		set({ prog: {
			...paintProg(p, applyBitOp(p.pendingOp, asBig(p.pendingValue), asBig(p.value), p.wordSize)),
			pendingOp: p.pendingOp,
			pendingValue: p.value
		} });
	},
	progClear: () => set({ prog: {
		...get().prog,
		...initialProg(),
		base: get().prog.base,
		wordSize: get().prog.wordSize,
		signed: get().prog.signed
	} }),
	progBackspace: () => {
		const p = get().prog;
		if (p.overwrite || !p.entering) return;
		const next = p.entry.replace(/\s+/g, "").slice(0, -1) || "0";
		set({ prog: {
			...p,
			entry: next,
			value: parseBase(next, p.base).toString(),
			entering: next !== "0",
			overwrite: next === "0"
		} });
	},
	progSign: () => {
		const p = get().prog;
		set({ prog: paintProg(p, -asBig(p.value)) });
	},
	setBase: (base) => {
		const p = get().prog;
		set({ prog: paintProg({
			...p,
			base
		}, asBig(p.value)) });
	},
	setWordSize: (wordSize) => {
		const p = get().prog;
		set({ prog: paintProg({
			...p,
			wordSize
		}, asBig(p.value)) });
	},
	toggleSigned: () => {
		const p = get().prog;
		set({ prog: paintProg({
			...p,
			signed: !p.signed
		}, asBig(p.value)) });
	},
	flipBit: (index) => {
		const p = get().prog;
		set({ prog: paintProg(p, toggleBit(asBig(p.value), index, p.wordSize)) });
	},
	setCategory: (category) => {
		const c = get().convert;
		const cat = CATEGORIES.find((x) => x.id === category);
		const fromId = cat?.units[0]?.id ?? "m";
		const toId = cat?.units[1]?.id ?? cat?.units[0]?.id ?? "ft";
		set({ convert: {
			...c,
			category,
			fromId,
			toId
		} });
	},
	setFromUnit: (fromId) => set({ convert: {
		...get().convert,
		fromId
	} }),
	setToUnit: (toId) => set({ convert: {
		...get().convert,
		toId
	} }),
	swapUnits: () => {
		const c = get().convert;
		set({ convert: {
			...c,
			fromId: c.toId,
			toId: c.fromId,
			input: String(convertValue(Number(c.input) || 0, c.category, c.fromId, c.toId))
		} });
	},
	convertDigit: (d) => {
		const c = get().convert;
		const next = c.input === "0" ? d : c.input + d;
		set({ convert: {
			...c,
			input: next
		} });
	},
	convertDot: () => {
		const c = get().convert;
		if (c.input.includes(".")) return;
		set({ convert: {
			...c,
			input: c.input + "."
		} });
	},
	convertBackspace: () => {
		const c = get().convert;
		const next = c.input.slice(0, -1) || "0";
		set({ convert: {
			...c,
			input: next
		} });
	},
	convertClear: () => set({ convert: {
		...get().convert,
		input: "0"
	} }),
	convertSign: () => {
		const c = get().convert;
		if (c.input.startsWith("-")) set({ convert: {
			...c,
			input: c.input.slice(1) || "0"
		} });
		else if (c.input !== "0") set({ convert: {
			...c,
			input: `-${c.input}`
		} });
	},
	hasMemory: () => memoryActive(get()),
	clearLabel: () => canClearEntry(get()) ? "C" : "AC"
}), {
	name: "calculator",
	partialize: (s) => ({
		theme: s.theme,
		mode: s.mode,
		angle: s.angle,
		memory: s.memory,
		history: s.history,
		prog: {
			base: s.prog.base,
			wordSize: s.prog.wordSize,
			signed: s.prog.signed
		},
		convert: {
			category: s.convert.category,
			fromId: s.convert.fromId,
			toId: s.convert.toId
		}
	}),
	merge: (persisted, current) => {
		const p = persisted ?? {};
		return {
			...current,
			theme: p.theme ?? current.theme,
			mode: p.mode ?? current.mode,
			angle: p.angle ?? current.angle,
			memory: p.memory ?? current.memory,
			history: p.history ?? current.history,
			prog: {
				...current.prog,
				...p.prog ?? {}
			},
			convert: {
				...current.convert,
				...p.convert ?? {}
			}
		};
	}
}));
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var MODES = [
	{
		id: "basic",
		label: "Basic"
	},
	{
		id: "scientific",
		label: "Scientific"
	},
	{
		id: "programmer",
		label: "Programmer"
	},
	{
		id: "converter",
		label: "Convert"
	}
];
function Header() {
	const mode = useCalc((s) => s.mode);
	const theme = useCalc((s) => s.theme);
	const panel = useCalc((s) => s.panel);
	const setMode = useCalc((s) => s.setMode);
	const setTheme = useCalc((s) => s.setTheme);
	const setPanel = useCalc((s) => s.setPanel);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "flex flex-col gap-4 pt-[max(0.5rem,env(safe-area-inset-top))]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-sans text-xl font-semibold tracking-tight text-fg",
				children: "Calculator"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": theme === "amoled" ? "Switch to paper theme" : "Switch to AMOLED theme",
					className: "flex size-11 items-center justify-center rounded-md text-muted transition-[color,transform] duration-[var(--motion-quick)] ease-[var(--ease-out)] hover:text-fg active:scale-[0.96]",
					onClick: () => setTheme(theme === "amoled" ? "paper" : "amoled"),
					children: theme === "amoled" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, {
						className: "size-5",
						strokeWidth: 1.75
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, {
						className: "size-5",
						strokeWidth: 1.75
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "History",
					"aria-pressed": panel === "history",
					className: cn("flex size-11 items-center justify-center rounded-md transition-[color,transform] duration-[var(--motion-quick)] ease-[var(--ease-out)] hover:text-fg active:scale-[0.96]", panel === "history" ? "text-fg" : "text-muted"),
					onClick: () => setPanel(panel === "history" ? "none" : "history"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, {
						className: "size-5",
						strokeWidth: 1.75
					})
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			"aria-label": "Calculator mode",
			className: "flex gap-1 overflow-x-auto rounded-lg bg-surface p-1 [box-shadow:var(--shadow-key)]",
			children: MODES.map((m) => {
				const active = mode === m.id;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setMode(m.id),
					className: cn("min-h-10 flex-1 rounded-md px-3 text-sm font-medium whitespace-nowrap transition-[background-color,color,transform] duration-[var(--motion-quick)] ease-[var(--ease-out)] active:scale-[0.98]", active ? "bg-accent text-accent-fg" : "text-muted hover:text-fg"),
					children: m.label
				}, m.id);
			})
		})]
	});
}
function Display() {
	const mode = useCalc((s) => s.mode);
	const display = useCalc((s) => s.display);
	const expression = useCalc((s) => s.expression);
	const error = useCalc((s) => s.error);
	const angle = useCalc((s) => s.angle);
	const second = useCalc((s) => s.second);
	const hyp = useCalc((s) => s.hyp);
	const memory = useCalc((s) => s.memory);
	const prog = useCalc((s) => s.prog);
	const convert = useCalc((s) => s.convert);
	const text = (0, import_react.useMemo)(() => {
		if (mode === "programmer") try {
			return formatProgEntry(BigInt(prog.value), prog.base, prog.wordSize, prog.signed);
		} catch {
			return prog.entry;
		}
		if (mode === "converter") return convert.input.replace("-", "−");
		return display;
	}, [
		mode,
		display,
		prog,
		convert.input
	]);
	const sub = (0, import_react.useMemo)(() => {
		if (mode === "programmer") return `${{
			2: "BIN",
			8: "OCT",
			10: "DEC",
			16: "HEX"
		}[prog.base]} · ${prog.wordSize}-bit${prog.signed ? " signed" : ""}`;
		if (mode === "converter") {
			const n = Number(convert.input);
			if (!Number.isFinite(n)) return "";
			const out = convertValue(n, convert.category, convert.fromId, convert.toId);
			try {
				return `= ${formatDecimal(D(out.toString()))} ${convert.toId}`;
			} catch {
				return `= ${out} ${convert.toId}`;
			}
		}
		return expression;
	}, [
		mode,
		expression,
		prog,
		convert
	]);
	const size = text.length > 16 ? "text-3xl sm:text-4xl" : text.length > 10 ? "text-4xl sm:text-5xl" : "text-5xl sm:text-6xl";
	function copy() {
		const raw = text.replace(/,/g, "").replace(/−/g, "-").replace(/\s/g, "");
		navigator.clipboard?.writeText(raw).then(() => toast("Copied"), () => {});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "flex flex-col px-1 pt-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex min-h-6 flex-wrap items-center gap-2 text-xs font-medium tracking-wide text-muted",
				children: [
					mode === "scientific" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "uppercase",
						children: angle
					}) : null,
					second ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "2nd" }) : null,
					hyp ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "HYP" }) : null,
					(() => {
						try {
							return memory !== "0" && memory !== "";
						} catch {
							return false;
						}
					})() && mode !== "converter" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "M" }) : null,
					mode === "programmer" && prog.pendingOp ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "uppercase",
						children: prog.pendingOp
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "min-h-6 truncate text-right font-mono text-sm text-muted",
				title: sub,
				children: error ?? sub
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: copy,
				"aria-label": "Copy result",
				className: cn("mt-1 w-full truncate text-right font-mono font-medium leading-tight tracking-display text-fg [overflow-wrap:anywhere]", size),
				children: text
			})
		]
	});
}
var keyVariants = cva("relative flex touch-manipulation select-none items-center justify-center rounded-key px-1 font-sans font-medium outline-none [box-shadow:var(--shadow-key)] transition-[transform,background-color,box-shadow,color] duration-[var(--motion-quick)] ease-[var(--ease-out)] focus-visible:ring-2 focus-visible:ring-ring active:scale-[0.96] disabled:opacity-40", {
	variants: {
		variant: {
			digit: "bg-key text-fg hover:[box-shadow:var(--shadow-key-hover)]",
			fn: "bg-key-fn text-fg text-sm hover:[box-shadow:var(--shadow-key-hover)]",
			op: "bg-key-op text-fg hover:[box-shadow:var(--shadow-key-hover)]",
			eq: "bg-accent text-accent-fg hover:opacity-90",
			ghost: "bg-transparent text-muted [box-shadow:none] hover:text-fg",
			active: "bg-accent text-accent-fg"
		},
		wide: {
			true: "col-span-2",
			false: ""
		},
		size: {
			md: "min-h-11 text-base",
			lg: "min-h-16 text-xl"
		}
	},
	defaultVariants: {
		variant: "digit",
		wide: false,
		size: "md"
	}
});
function KeyButton({ label, sub, variant, wide, size, ariaLabel, onPress, className, disabled }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-label": ariaLabel ?? label,
		disabled,
		className: cn(keyVariants({
			variant,
			wide,
			size
		}), className),
		onPointerDown: (e) => {
			if (e.button !== 0) return;
			e.preventDefault();
			onPress();
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex flex-col items-center leading-none",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "tabular-nums",
				children: label
			}), sub ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-0.5 text-2xs font-normal text-muted",
				children: sub
			}) : null]
		})
	});
}
function MemoryBar() {
	const dispatch = useCalc((s) => s.dispatch);
	const hasMemory = useCalc((s) => s.hasMemory());
	const clearLabel = useCalc((s) => s.clearLabel());
	if (useCalc((s) => s.mode) === "converter") return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid grid-cols-6 gap-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: clearLabel,
				variant: "fn",
				ariaLabel: clearLabel === "C" ? "Clear" : "All clear",
				onPress: () => dispatch({ type: clearLabel === "C" ? "clear" : "allClear" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "MC",
				variant: "fn",
				ariaLabel: "Memory clear",
				disabled: !hasMemory,
				onPress: () => dispatch({ type: "memoryClear" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "MR",
				variant: "fn",
				ariaLabel: "Memory recall",
				disabled: !hasMemory,
				onPress: () => dispatch({ type: "memoryRecall" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "M+",
				variant: "fn",
				ariaLabel: "Memory add",
				onPress: () => dispatch({ type: "memoryAdd" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "M−",
				variant: "fn",
				ariaLabel: "Memory subtract",
				onPress: () => dispatch({ type: "memorySub" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "MS",
				variant: "fn",
				ariaLabel: "Memory store",
				onPress: () => dispatch({ type: "memoryStore" })
			})
		]
	});
}
function BasicKeypad() {
	const dispatch = useCalc((s) => s.dispatch);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid grid-cols-4 gap-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "⌫",
				variant: "fn",
				size: "lg",
				ariaLabel: "Backspace",
				onPress: () => dispatch({ type: "backspace" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "±",
				variant: "fn",
				size: "lg",
				ariaLabel: "Toggle sign",
				onPress: () => dispatch({ type: "sign" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "%",
				variant: "fn",
				size: "lg",
				ariaLabel: "Percent",
				onPress: () => dispatch({ type: "percent" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "÷",
				variant: "op",
				size: "lg",
				ariaLabel: "Divide",
				onPress: () => dispatch({
					type: "op",
					op: "div"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "7",
				size: "lg",
				onPress: () => dispatch({
					type: "digit",
					digit: "7"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "8",
				size: "lg",
				onPress: () => dispatch({
					type: "digit",
					digit: "8"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "9",
				size: "lg",
				onPress: () => dispatch({
					type: "digit",
					digit: "9"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "×",
				variant: "op",
				size: "lg",
				ariaLabel: "Multiply",
				onPress: () => dispatch({
					type: "op",
					op: "mul"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "4",
				size: "lg",
				onPress: () => dispatch({
					type: "digit",
					digit: "4"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "5",
				size: "lg",
				onPress: () => dispatch({
					type: "digit",
					digit: "5"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "6",
				size: "lg",
				onPress: () => dispatch({
					type: "digit",
					digit: "6"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "−",
				variant: "op",
				size: "lg",
				ariaLabel: "Subtract",
				onPress: () => dispatch({
					type: "op",
					op: "sub"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "1",
				size: "lg",
				onPress: () => dispatch({
					type: "digit",
					digit: "1"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "2",
				size: "lg",
				onPress: () => dispatch({
					type: "digit",
					digit: "2"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "3",
				size: "lg",
				onPress: () => dispatch({
					type: "digit",
					digit: "3"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "+",
				variant: "op",
				size: "lg",
				ariaLabel: "Add",
				onPress: () => dispatch({
					type: "op",
					op: "add"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "0",
				wide: true,
				size: "lg",
				onPress: () => dispatch({
					type: "digit",
					digit: "0"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: ".",
				size: "lg",
				ariaLabel: "Decimal",
				onPress: () => dispatch({ type: "dot" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "=",
				variant: "eq",
				size: "lg",
				ariaLabel: "Equals",
				onPress: () => dispatch({ type: "equals" })
			})
		]
	});
}
function ScientificKeypad() {
	const dispatch = useCalc((s) => s.dispatch);
	const second = useCalc((s) => s.second);
	const hyp = useCalc((s) => s.hyp);
	const angle = useCalc((s) => s.angle);
	const setPanel = useCalc((s) => s.setPanel);
	const panel = useCalc((s) => s.panel);
	function unary(normal, alt) {
		dispatch({
			type: "unary",
			fn: second ? alt : normal
		});
	}
	const sin = hyp ? second ? "sinh⁻¹" : "sinh" : second ? "sin⁻¹" : "sin";
	const cos = hyp ? second ? "cosh⁻¹" : "cosh" : second ? "cos⁻¹" : "cos";
	const tan = hyp ? second ? "tanh⁻¹" : "tanh" : second ? "tan⁻¹" : "tan";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid grid-cols-5 gap-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "2nd",
				variant: second ? "active" : "fn",
				ariaLabel: "Second functions",
				onPress: () => dispatch({ type: "toggleSecond" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: angle.toUpperCase(),
				variant: "fn",
				ariaLabel: "Cycle angle unit",
				onPress: () => dispatch({ type: "cycleAngle" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "HYP",
				variant: hyp ? "active" : "fn",
				ariaLabel: "Hyperbolic",
				onPress: () => dispatch({ type: "toggleHyp" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "More",
				variant: panel === "more" ? "active" : "fn",
				onPress: () => setPanel(panel === "more" ? "none" : "more")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "⌫",
				variant: "fn",
				ariaLabel: "Backspace",
				onPress: () => dispatch({ type: "backspace" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: sin,
				variant: "fn",
				onPress: () => unary(hyp ? "sinh" : "sin", hyp ? "asinh" : "asin")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: cos,
				variant: "fn",
				onPress: () => unary(hyp ? "cosh" : "cos", hyp ? "acosh" : "acos")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: tan,
				variant: "fn",
				onPress: () => unary(hyp ? "tanh" : "tan", hyp ? "atanh" : "atan")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: second ? "10ˣ" : "log",
				variant: "fn",
				onPress: () => unary("log", "exp10")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: second ? "eˣ" : "ln",
				variant: "fn",
				onPress: () => unary("ln", "exp")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: second ? "x³" : "x²",
				variant: "fn",
				onPress: () => unary("sq", "cube")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: second ? "∛x" : "√x",
				variant: "fn",
				onPress: () => unary("sqrt", "cbrt")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: second ? "ʸ√x" : "xʸ",
				variant: "fn",
				onPress: () => dispatch({
					type: "op",
					op: second ? "root" : "pow"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "1/x",
				variant: "fn",
				onPress: () => dispatch({
					type: "unary",
					fn: "inv"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "n!",
				variant: "fn",
				ariaLabel: "Factorial",
				onPress: () => dispatch({
					type: "unary",
					fn: "fact"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: second ? "φ" : "π",
				variant: "fn",
				onPress: () => dispatch({
					type: "const",
					name: second ? "phi" : "pi"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: second ? "τ" : "e",
				variant: "fn",
				onPress: () => dispatch({
					type: "const",
					name: second ? "tau" : "e"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "(",
				variant: "fn",
				onPress: () => dispatch({ type: "lparen" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: ")",
				variant: "fn",
				onPress: () => dispatch({ type: "rparen" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "÷",
				variant: "op",
				ariaLabel: "Divide",
				onPress: () => dispatch({
					type: "op",
					op: "div"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "nCr",
				variant: "fn",
				onPress: () => dispatch({
					type: "op",
					op: "nCr"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "7",
				onPress: () => dispatch({
					type: "digit",
					digit: "7"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "8",
				onPress: () => dispatch({
					type: "digit",
					digit: "8"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "9",
				onPress: () => dispatch({
					type: "digit",
					digit: "9"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "×",
				variant: "op",
				ariaLabel: "Multiply",
				onPress: () => dispatch({
					type: "op",
					op: "mul"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "nPr",
				variant: "fn",
				onPress: () => dispatch({
					type: "op",
					op: "nPr"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "4",
				onPress: () => dispatch({
					type: "digit",
					digit: "4"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "5",
				onPress: () => dispatch({
					type: "digit",
					digit: "5"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "6",
				onPress: () => dispatch({
					type: "digit",
					digit: "6"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "−",
				variant: "op",
				ariaLabel: "Subtract",
				onPress: () => dispatch({
					type: "op",
					op: "sub"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "EE",
				variant: "fn",
				ariaLabel: "Scientific notation",
				onPress: () => dispatch({ type: "ee" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "1",
				onPress: () => dispatch({
					type: "digit",
					digit: "1"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "2",
				onPress: () => dispatch({
					type: "digit",
					digit: "2"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "3",
				onPress: () => dispatch({
					type: "digit",
					digit: "3"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "+",
				variant: "op",
				ariaLabel: "Add",
				onPress: () => dispatch({
					type: "op",
					op: "add"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "±",
				variant: "fn",
				ariaLabel: "Toggle sign",
				onPress: () => dispatch({ type: "sign" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "0",
				onPress: () => dispatch({
					type: "digit",
					digit: "0"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: ".",
				ariaLabel: "Decimal",
				onPress: () => dispatch({ type: "dot" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "%",
				variant: "fn",
				ariaLabel: "Percent",
				onPress: () => dispatch({ type: "percent" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
				label: "=",
				variant: "eq",
				ariaLabel: "Equals",
				onPress: () => dispatch({ type: "equals" })
			})
		]
	});
}
var BASES = [
	{
		id: 16,
		label: "HEX"
	},
	{
		id: 10,
		label: "DEC"
	},
	{
		id: 8,
		label: "OCT"
	},
	{
		id: 2,
		label: "BIN"
	}
];
var SIZES = [
	{
		id: 8,
		label: "BYTE"
	},
	{
		id: 16,
		label: "WORD"
	},
	{
		id: 32,
		label: "DWORD"
	},
	{
		id: 64,
		label: "QWORD"
	}
];
var HEX = [
	"A",
	"B",
	"C",
	"D",
	"E",
	"F"
];
function ProgrammerPad() {
	const prog = useCalc((s) => s.prog);
	const setBase = useCalc((s) => s.setBase);
	const setWordSize = useCalc((s) => s.setWordSize);
	const toggleSigned = useCalc((s) => s.toggleSigned);
	const flipBit = useCalc((s) => s.flipBit);
	const progDigit = useCalc((s) => s.progDigit);
	const progOp = useCalc((s) => s.progOp);
	const progNot = useCalc((s) => s.progNot);
	const progEquals = useCalc((s) => s.progEquals);
	const progClear = useCalc((s) => s.progClear);
	const progBackspace = useCalc((s) => s.progBackspace);
	const progSign = useCalc((s) => s.progSign);
	let bits = 0n;
	try {
		bits = BigInt(prog.value);
	} catch {
		bits = 0n;
	}
	const hexOn = prog.base >= 16;
	const octOn = prog.base >= 8;
	const decOn = prog.base >= 10;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-4 gap-1 rounded-lg bg-surface p-1 [box-shadow:var(--shadow-key)]",
				children: BASES.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setBase(b.id),
					className: cn("min-h-10 rounded-md text-sm font-medium transition-[background-color,color] duration-[var(--motion-quick)] ease-[var(--ease-out)]", prog.base === b.id ? "bg-accent text-accent-fg" : "text-muted hover:text-fg"),
					children: b.label
				}, b.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-5 gap-1 rounded-lg bg-surface p-1 [box-shadow:var(--shadow-key)]",
				children: [SIZES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setWordSize(s.id),
					className: cn("min-h-10 rounded-md text-xs font-medium transition-[background-color,color] duration-[var(--motion-quick)] ease-[var(--ease-out)]", prog.wordSize === s.id ? "bg-accent text-accent-fg" : "text-muted hover:text-fg"),
					children: s.label
				}, s.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: toggleSigned,
					className: cn("min-h-10 rounded-md text-xs font-medium transition-[background-color,color] duration-[var(--motion-quick)] ease-[var(--ease-out)]", prog.signed ? "bg-accent text-accent-fg" : "text-muted hover:text-fg"),
					children: "±"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BitView, {
				value: bits,
				wordSize: prog.wordSize,
				onToggle: flipBit
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-5 gap-2",
				children: [[
					"lsh",
					"rsh",
					"or",
					"xor",
					"not"
				].map((op) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
					label: op.toUpperCase(),
					variant: "fn",
					onPress: () => op === "not" ? progNot() : progOp(op)
				}, op)), [
					"and",
					"nand",
					"nor",
					"rol",
					"ror"
				].map((op) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
					label: op.toUpperCase(),
					variant: "fn",
					onPress: () => progOp(op)
				}, op))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-4 gap-2",
				children: [
					HEX.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
						label: h,
						variant: "fn",
						disabled: !hexOn,
						onPress: () => progDigit(h)
					}, h)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
						label: "AC",
						variant: "fn",
						onPress: progClear
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
						label: "⌫",
						variant: "fn",
						ariaLabel: "Backspace",
						onPress: progBackspace
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
						label: "7",
						disabled: !octOn,
						onPress: () => progDigit("7")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
						label: "8",
						disabled: !decOn,
						onPress: () => progDigit("8")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
						label: "9",
						disabled: !decOn,
						onPress: () => progDigit("9")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
						label: "NOR",
						variant: "fn",
						onPress: () => progOp("nor")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
						label: "4",
						onPress: () => progDigit("4"),
						disabled: !octOn
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
						label: "5",
						onPress: () => progDigit("5"),
						disabled: !octOn
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
						label: "6",
						onPress: () => progDigit("6"),
						disabled: !octOn
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
						label: "XOR",
						variant: "fn",
						onPress: () => progOp("xor")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
						label: "1",
						onPress: () => progDigit("1")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
						label: "2",
						onPress: () => progDigit("2"),
						disabled: !octOn
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
						label: "3",
						onPress: () => progDigit("3"),
						disabled: !octOn
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
						label: "AND",
						variant: "fn",
						onPress: () => progOp("and")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
						label: "±",
						variant: "fn",
						onPress: progSign
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
						label: "0",
						onPress: () => progDigit("0")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
						label: "NOT",
						variant: "fn",
						onPress: progNot
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
						label: "=",
						variant: "eq",
						onPress: progEquals
					})
				]
			})
		]
	});
}
function BitView({ value, wordSize, onToggle }) {
	const bits = Array.from({ length: wordSize }, (_, i) => {
		const index = wordSize - 1 - i;
		return {
			index,
			on: (value >> BigInt(index) & 1n) === 1n
		};
	});
	const groups = [];
	for (let i = 0; i < bits.length; i += 8) groups.push(bits.slice(i, i + 8));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg bg-surface p-3 font-mono text-xs [box-shadow:var(--shadow-key)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-2 text-2xs tracking-wide text-muted uppercase",
			children: "Bits"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-col gap-2",
			children: groups.map((g, gi) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "w-6 text-muted",
					children: g[0]?.index
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-1 flex-wrap gap-px",
					children: g.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": `Bit ${b.index} ${b.on ? "on" : "off"}`,
						onClick: () => onToggle(b.index),
						className: cn("flex h-7 min-w-0 flex-1 items-center justify-center rounded-xs text-2xs transition-[background-color,color] duration-[var(--motion-quick)] ease-[var(--ease-out)]", b.on ? "bg-accent text-accent-fg" : "bg-key text-muted"),
						children: b.on ? "1" : "0"
					}, b.index))
				})]
			}, gi))
		})]
	});
}
function ConverterPanel() {
	const convert = useCalc((s) => s.convert);
	const setCategory = useCalc((s) => s.setCategory);
	const setFromUnit = useCalc((s) => s.setFromUnit);
	const setToUnit = useCalc((s) => s.setToUnit);
	const swapUnits = useCalc((s) => s.swapUnits);
	const convertDigit = useCalc((s) => s.convertDigit);
	const convertDot = useCalc((s) => s.convertDot);
	const convertBackspace = useCalc((s) => s.convertBackspace);
	const convertClear = useCalc((s) => s.convertClear);
	const convertSign = useCalc((s) => s.convertSign);
	const cat = CATEGORIES.find((c) => c.id === convert.category) ?? CATEGORIES[0];
	const n = Number(convert.input);
	const out = Number.isFinite(n) ? convertValue(n, convert.category, convert.fromId, convert.toId) : 0;
	let outLabel = String(out);
	try {
		outLabel = formatDecimal(D(out.toString()));
	} catch {}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-1 overflow-x-auto pb-1",
				children: CATEGORIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setCategory(c.id),
					className: cn("min-h-10 shrink-0 rounded-md px-3 text-sm font-medium transition-[background-color,color] duration-[var(--motion-quick)] ease-[var(--ease-out)]", convert.category === c.id ? "bg-accent text-accent-fg" : "bg-key-fn text-muted hover:text-fg"),
					children: c.label
				}, c.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg bg-surface p-4 [box-shadow:var(--shadow-key)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "mb-2 block text-xs font-medium tracking-wide text-muted uppercase",
						children: "From"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						value: convert.fromId,
						onChange: (e) => setFromUnit(e.target.value),
						className: "mb-4 min-h-11 w-full rounded-md bg-key px-3 font-sans text-sm text-fg outline-none [box-shadow:var(--shadow-key)] focus:ring-2 focus:ring-ring",
						children: cat.units.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: u.id,
							children: u.label
						}, u.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-4 flex justify-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": "Swap units",
							onClick: swapUnits,
							className: "flex size-11 items-center justify-center rounded-md bg-key text-fg transition-[transform] duration-[var(--motion-quick)] ease-[var(--ease-out)] active:scale-[0.96] [box-shadow:var(--shadow-key)]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDownUp, {
								className: "size-4",
								strokeWidth: 1.75
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "mb-2 block text-xs font-medium tracking-wide text-muted uppercase",
						children: "To"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						value: convert.toId,
						onChange: (e) => setToUnit(e.target.value),
						className: "mb-3 min-h-11 w-full rounded-md bg-key px-3 font-sans text-sm text-fg outline-none [box-shadow:var(--shadow-key)] focus:ring-2 focus:ring-ring",
						children: cat.units.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: u.id,
							children: u.label
						}, u.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-2xl font-medium tracking-tight text-fg",
						children: outLabel
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-4 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
						label: "AC",
						variant: "fn",
						onPress: convertClear
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
						label: "⌫",
						variant: "fn",
						onPress: convertBackspace
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
						label: "±",
						variant: "fn",
						onPress: convertSign
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
						label: ".",
						variant: "fn",
						onPress: convertDot
					}),
					[
						"7",
						"8",
						"9",
						"4",
						"5",
						"6",
						"1",
						"2",
						"3"
					].map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
						label: d,
						onPress: () => convertDigit(d)
					}, d)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
						label: "0",
						wide: true,
						onPress: () => convertDigit("0")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
						label: "00",
						variant: "fn",
						onPress: () => convertDigit("00")
					})
				]
			})
		]
	});
}
var UNARIES = [
	{
		label: "sec",
		fn: "sec"
	},
	{
		label: "csc",
		fn: "csc"
	},
	{
		label: "cot",
		fn: "cot"
	},
	{
		label: "sec⁻¹",
		fn: "asec"
	},
	{
		label: "csc⁻¹",
		fn: "acsc"
	},
	{
		label: "cot⁻¹",
		fn: "acot"
	},
	{
		label: "log₂",
		fn: "log2"
	},
	{
		label: "2ˣ",
		fn: "exp2"
	},
	{
		label: "|x|",
		fn: "abs"
	},
	{
		label: "floor",
		fn: "floor"
	},
	{
		label: "ceil",
		fn: "ceil"
	},
	{
		label: "round",
		fn: "round"
	},
	{
		label: "frac",
		fn: "frac"
	},
	{
		label: "sign",
		fn: "sign"
	},
	{
		label: "rand",
		fn: "rand"
	},
	{
		label: "→deg",
		fn: "toDeg"
	},
	{
		label: "→rad",
		fn: "toRad"
	},
	{
		label: "→grad",
		fn: "toGrad"
	}
];
var BINS = [
	{
		label: "mod",
		op: "mod"
	},
	{
		label: "gcd",
		op: "gcd"
	},
	{
		label: "lcm",
		op: "lcm"
	},
	{
		label: "logᵧ",
		op: "logy"
	}
];
var CONSTS = [
	{
		label: "π",
		name: "pi"
	},
	{
		label: "e",
		name: "e"
	},
	{
		label: "φ",
		name: "phi"
	},
	{
		label: "τ",
		name: "tau"
	},
	{
		label: "√2",
		name: "sqrt2"
	},
	{
		label: "ln2",
		name: "ln2"
	},
	{
		label: "c",
		name: "c"
	},
	{
		label: "g",
		name: "g"
	},
	{
		label: "h",
		name: "h"
	},
	{
		label: "Nₐ",
		name: "NA"
	}
];
function MoreSheet() {
	const panel = useCalc((s) => s.panel);
	const setPanel = useCalc((s) => s.setPanel);
	const dispatch = useCalc((s) => s.dispatch);
	const open = panel === "more";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("overflow-hidden transition-[grid-template-rows,opacity] duration-[var(--motion-fast)] ease-[var(--ease-out)]", open ? "grid grid-rows-[1fr] opacity-100" : "grid grid-rows-[0fr] opacity-0"),
		"aria-hidden": !open,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "min-h-0 overflow-hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 rounded-lg bg-surface p-3 [box-shadow:var(--shadow-key)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium text-fg",
							children: "More functions"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "min-h-10 px-2 text-sm text-muted hover:text-fg",
							onClick: () => setPanel("none"),
							children: "Close"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-xs font-medium tracking-wide text-muted uppercase",
						children: "Functions"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-4 grid grid-cols-4 gap-2 sm:grid-cols-6",
						children: UNARIES.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
							label: u.label,
							variant: "fn",
							onPress: () => {
								dispatch({
									type: "unary",
									fn: u.fn
								});
								setPanel("none");
							}
						}, u.fn))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-xs font-medium tracking-wide text-muted uppercase",
						children: "Two-value"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-4 grid grid-cols-4 gap-2",
						children: BINS.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
							label: b.label,
							variant: "op",
							onPress: () => {
								dispatch({
									type: "op",
									op: b.op
								});
								setPanel("none");
							}
						}, b.op))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-xs font-medium tracking-wide text-muted uppercase",
						children: "Constants"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-5 gap-2",
						children: CONSTS.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
							label: c.label,
							variant: "fn",
							onPress: () => {
								dispatch({
									type: "const",
									name: c.name
								});
								setPanel("none");
							}
						}, c.name))
					})
				]
			})
		})
	});
}
function HistoryPanel({ variant }) {
	const history = useCalc((s) => s.history);
	const panel = useCalc((s) => s.panel);
	const setPanel = useCalc((s) => s.setPanel);
	const dispatch = useCalc((s) => s.dispatch);
	if (variant === "overlay" && !(variant === "side" || panel === "history")) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: cn(variant === "side" ? "hidden w-80 shrink-0 border-l border-border lg:flex lg:flex-col" : "fixed inset-0 z-20 flex flex-col bg-bg/95 lg:hidden"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between px-5 py-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-base font-semibold tracking-tight",
				children: "History"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [history.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "min-h-10 px-2 text-sm text-muted hover:text-fg",
					onClick: () => dispatch({ type: "clearHistory" }),
					children: "Clear"
				}) : null, variant === "overlay" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "min-h-10 px-2 text-sm text-muted hover:text-fg",
					onClick: () => setPanel("none"),
					children: "Close"
				}) : null]
			})]
		}), history.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "px-5 text-sm text-muted",
			children: "Results you evaluate will appear here. Tap one to reuse it."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "flex-1 overflow-y-auto px-3 pb-6",
			children: history.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "flex w-full flex-col items-end rounded-md px-3 py-3 text-right transition-[background-color] duration-[var(--motion-quick)] ease-[var(--ease-out)] hover:bg-surface",
				onClick: () => {
					dispatch({
						type: "load",
						value: item.result.replace(/,/g, "").replace(/−/g, "-"),
						expr: item.expression
					});
					setPanel("none");
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-mono text-xs text-muted",
					children: item.expression
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-mono text-lg font-medium text-fg",
					children: item.result
				})]
			}) }, item.id))
		})]
	});
}
function isTypingTarget(el) {
	if (!(el instanceof HTMLElement)) return false;
	const tag = el.tagName;
	return tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT" || el.isContentEditable;
}
function useCalculatorKeyboard() {
	(0, import_react.useEffect)(() => {
		function onKey(e) {
			if (isTypingTarget(e.target)) return;
			const s = useCalc.getState();
			const k = e.key;
			if (s.mode === "converter") {
				if (/^[0-9]$/.test(k)) {
					e.preventDefault();
					s.convertDigit(k);
					return;
				}
				if (k === ".") {
					e.preventDefault();
					s.convertDot();
					return;
				}
				if (k === "Backspace") {
					e.preventDefault();
					s.convertBackspace();
					return;
				}
				if (k === "Escape") {
					e.preventDefault();
					s.convertClear();
					return;
				}
				return;
			}
			if (s.mode === "programmer") {
				if (/^[0-9a-fA-F]$/.test(k)) {
					e.preventDefault();
					s.progDigit(k.toUpperCase());
					return;
				}
				if (k === "Enter" || k === "=") {
					e.preventDefault();
					s.progEquals();
					return;
				}
				if (k === "Backspace") {
					e.preventDefault();
					s.progBackspace();
					return;
				}
				if (k === "Escape") {
					e.preventDefault();
					s.progClear();
					return;
				}
				if (k === "&") {
					e.preventDefault();
					s.progOp("and");
					return;
				}
				if (k === "|") {
					e.preventDefault();
					s.progOp("or");
					return;
				}
				if (k === "^") {
					e.preventDefault();
					s.progOp("xor");
					return;
				}
				if (k === "~") {
					e.preventDefault();
					s.progNot();
					return;
				}
				return;
			}
			if (/^[0-9]$/.test(k)) {
				e.preventDefault();
				s.dispatch({
					type: "digit",
					digit: k
				});
				return;
			}
			if (k === ".") {
				e.preventDefault();
				s.dispatch({ type: "dot" });
				return;
			}
			if (k === "+") {
				e.preventDefault();
				s.dispatch({
					type: "op",
					op: "add"
				});
				return;
			}
			if (k === "-") {
				e.preventDefault();
				s.dispatch({
					type: "op",
					op: "sub"
				});
				return;
			}
			if (k === "*" || k === "x" || k === "X") {
				e.preventDefault();
				s.dispatch({
					type: "op",
					op: "mul"
				});
				return;
			}
			if (k === "/") {
				e.preventDefault();
				s.dispatch({
					type: "op",
					op: "div"
				});
				return;
			}
			if (k === "%") {
				e.preventDefault();
				s.dispatch({ type: "percent" });
				return;
			}
			if (k === "Enter" || k === "=") {
				e.preventDefault();
				s.dispatch({ type: "equals" });
				return;
			}
			if (k === "Backspace") {
				e.preventDefault();
				s.dispatch({ type: "backspace" });
				return;
			}
			if (k === "Escape") {
				e.preventDefault();
				s.dispatch({ type: "clear" });
				return;
			}
			if (k === "(") {
				e.preventDefault();
				s.dispatch({ type: "lparen" });
				return;
			}
			if (k === ")") {
				e.preventDefault();
				s.dispatch({ type: "rparen" });
				return;
			}
			if (k === "^") {
				e.preventDefault();
				s.dispatch({
					type: "op",
					op: "pow"
				});
				return;
			}
			if (k === "p" && s.mode === "scientific") {
				e.preventDefault();
				s.dispatch({
					type: "const",
					name: "pi"
				});
			}
		}
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, []);
}
function CalculatorApp() {
	const mode = useCalc((s) => s.mode);
	const theme = useCalc((s) => s.theme);
	useCalculatorKeyboard();
	(0, import_react.useEffect)(() => {
		document.documentElement.dataset.theme = theme;
		const meta = document.querySelector("meta[name=\"theme-color\"]");
		if (meta) meta.setAttribute("content", theme === "amoled" ? "#000000" : "#e8e6e1");
	}, [theme]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex min-h-dvh max-w-6xl",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex w-full max-w-xl flex-1 flex-col px-4 pb-[max(1rem,env(safe-area-inset-bottom))] sm:px-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-1 flex-col",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Display, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 flex flex-col gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MemoryBar, {}),
								mode === "basic" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BasicKeypad, {}) : null,
								mode === "scientific" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoreSheet, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScientificKeypad, {})] }) : null,
								mode === "programmer" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgrammerPad, {}) : null,
								mode === "converter" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConverterPanel, {}) : null
							]
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistoryPanel, { variant: "side" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistoryPanel, { variant: "overlay" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				theme: theme === "amoled" ? "dark" : "light",
				position: "bottom-center",
				toastOptions: { className: "font-sans text-sm bg-surface text-fg border-border" }
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalculatorApp, {});
}
//#endregion
export { Home as component };
