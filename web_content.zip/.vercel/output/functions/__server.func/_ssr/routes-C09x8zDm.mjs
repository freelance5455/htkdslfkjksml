import { i as __toESM } from "../_runtime.mjs";
import { a as looksLikeUrl, i as extractYoutubeId, l as youtubeThumbnail, n as QUALITIES, r as detectPlatform, s as normalizeUrl, t as PLATFORM_LABEL } from "./detect-BxYQJ91H.mjs";
import { J as require_react, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as object, n as boolean, o as string, t as _enum } from "../_libs/zod.mjs";
import { a as ImageDown, c as CircleAlert, i as LoaderCircle, l as Check, o as Download, r as Trash2, s as ClipboardPaste, t as X, u as AudioLines } from "../_libs/lucide-react.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-C09x8zDm.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var qualitySchema = _enum([
	"1080p",
	"720p",
	"480p"
]);
var previewSchema = object({ url: string().min(4).max(2e3) });
var prepareSchema = object({
	url: string().min(4).max(2e3),
	quality: qualitySchema,
	audioOnly: boolean()
});
var previewMediaFn = createServerFn({ method: "POST" }).validator(previewSchema).handler(createSsrRpc("e7d01a25bfa970a85e4bf5e88f2a40a5ded953ac99a614bac8b21b29a714e506"));
var prepareMediaFn = createServerFn({ method: "POST" }).validator(prepareSchema).handler(createSsrRpc("cd1439a5dacdafd8677543e183f937b980b23d6bb18858d29b8d9dfcf92a44ae"));
var KEY = "puro-history-v1";
var MAX = 12;
function canUseStorage() {
	return typeof window !== "undefined" && typeof localStorage !== "undefined";
}
function loadHistory() {
	if (!canUseStorage()) return [];
	try {
		const raw = localStorage.getItem(KEY);
		if (!raw) return [];
		const parsed = JSON.parse(raw);
		if (!Array.isArray(parsed)) return [];
		return parsed.slice(0, MAX);
	} catch {
		return [];
	}
}
function saveHistory(items) {
	if (!canUseStorage()) return;
	try {
		localStorage.setItem(KEY, JSON.stringify(items.slice(0, MAX)));
	} catch {}
}
function pushHistory(items, next) {
	const item = {
		...next,
		id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
		at: Date.now()
	};
	const updated = [item, ...items.filter((entry) => !(entry.url === item.url && entry.audioOnly === item.audioOnly))].slice(0, MAX);
	saveHistory(updated);
	return updated;
}
function clearHistory() {
	saveHistory([]);
	return [];
}
function proxyUrl(sourceUrl, filename) {
	return `/api/file?${new URLSearchParams({
		src: sourceUrl,
		name: filename
	}).toString()}`;
}
async function fetchSource(sourceUrl, filename, signal) {
	try {
		const direct = await fetch(sourceUrl, {
			signal,
			headers: { Accept: "*/*" }
		});
		if (direct.ok) return direct;
	} catch (error) {
		if (signal?.aborted) throw error;
	}
	return fetch(proxyUrl(sourceUrl, filename), {
		signal,
		headers: { Accept: "*/*" }
	});
}
function guessTotal(response) {
	const length = Number(response.headers.get("content-length") || response.headers.get("estimated-content-length") || 0);
	return Number.isFinite(length) && length > 0 ? length : 0;
}
async function blobFromResponse(response, onProgress, signal) {
	const total = guessTotal(response);
	if (!response.body) {
		const blob = await response.blob();
		onProgress?.({
			loaded: blob.size,
			total: blob.size,
			ratio: 1
		});
		return blob;
	}
	const reader = response.body.getReader();
	const chunks = [];
	let loaded = 0;
	const abort = () => {
		reader.cancel();
	};
	signal?.addEventListener("abort", abort, { once: true });
	try {
		while (true) {
			if (signal?.aborted) throw new DOMException("Aborted", "AbortError");
			const { done, value } = await reader.read();
			if (done) break;
			if (value) {
				const copy = new Uint8Array(value.byteLength);
				copy.set(value);
				chunks.push(copy);
				loaded += value.byteLength;
				onProgress?.({
					loaded,
					total,
					ratio: total ? Math.min(.99, loaded / total) : 0
				});
			}
		}
	} finally {
		signal?.removeEventListener("abort", abort);
	}
	const blob = new Blob(chunks, { type: response.headers.get("content-type") || void 0 });
	onProgress?.({
		loaded: blob.size,
		total: total || blob.size,
		ratio: 1
	});
	return blob;
}
function triggerAnchorDownload(href, filename) {
	const anchor = document.createElement("a");
	anchor.href = href;
	anchor.download = filename;
	anchor.rel = "noopener";
	anchor.style.display = "none";
	document.body.appendChild(anchor);
	anchor.click();
	anchor.remove();
}
async function shareOrDownload(blob, filename, mime, mode) {
	const type = blob.type && blob.type !== "application/octet-stream" ? blob.type : mime;
	const file = new File([blob], filename, { type });
	if (mode === "gallery") {
		const payload = {
			files: [file],
			title: filename
		};
		if (typeof navigator.canShare === "function" && navigator.canShare(payload)) {
			await navigator.share(payload);
			return "shared";
		}
	}
	const objectUrl = URL.createObjectURL(blob);
	try {
		triggerAnchorDownload(objectUrl, filename);
	} finally {
		window.setTimeout(() => URL.revokeObjectURL(objectUrl), 3e4);
	}
	return "downloaded";
}
async function saveMediaFile(options) {
	const { sourceUrl, filename, mime, mode, onProgress, signal } = options;
	try {
		const response = await fetchSource(sourceUrl, filename, signal);
		if (!response.ok) throw new Error(`HTTP ${response.status}`);
		return await shareOrDownload(await blobFromResponse(response, onProgress, signal), filename, mime, mode);
	} catch (error) {
		if (signal?.aborted) throw error;
		if (mode === "download") {
			triggerAnchorDownload(sourceUrl, filename);
			onProgress?.({
				loaded: 1,
				total: 1,
				ratio: 1
			});
			return "downloaded";
		}
		throw error;
	}
}
var PLATFORM_HINTS = [
	"youtube",
	"tiktok",
	"instagram"
];
function formatTime(at) {
	try {
		return new Intl.DateTimeFormat("pt-BR", {
			hour: "2-digit",
			minute: "2-digit"
		}).format(new Date(at));
	} catch {
		return "";
	}
}
function PuroApp() {
	const [url, setUrl] = (0, import_react.useState)("");
	const [quality, setQuality] = (0, import_react.useState)("720p");
	const [audioOnly, setAudioOnly] = (0, import_react.useState)(false);
	const [status, setStatus] = (0, import_react.useState)("idle");
	const [message, setMessage] = (0, import_react.useState)(null);
	const [progress, setProgress] = (0, import_react.useState)(0);
	const [title, setTitle] = (0, import_react.useState)(null);
	const [author, setAuthor] = (0, import_react.useState)(null);
	const [thumbnail, setThumbnail] = (0, import_react.useState)(null);
	const [history, setHistory] = (0, import_react.useState)([]);
	const [pasteHint, setPasteHint] = (0, import_react.useState)(null);
	const [standalone, setStandalone] = (0, import_react.useState)(false);
	const installPromptRef = (0, import_react.useRef)(null);
	const abortRef = (0, import_react.useRef)(null);
	const previewSeq = (0, import_react.useRef)(0);
	const inputRef = (0, import_react.useRef)(null);
	const platform = (0, import_react.useMemo)(() => detectPlatform(url), [url]);
	const youtubeId = (0, import_react.useMemo)(() => platform === "youtube" ? extractYoutubeId(url) : null, [platform, url]);
	const busy = status === "preparing" || status === "saving";
	(0, import_react.useEffect)(() => {
		setHistory(loadHistory());
		const standaloneMode = window.matchMedia("(display-mode: standalone)").matches || Boolean(navigator.standalone);
		setStandalone(standaloneMode);
		const onInstallPrompt = (event) => {
			event.preventDefault();
			installPromptRef.current = event;
		};
		window.addEventListener("beforeinstallprompt", onInstallPrompt);
		return () => window.removeEventListener("beforeinstallprompt", onInstallPrompt);
	}, []);
	(0, import_react.useEffect)(() => {
		const trimmed = url.trim();
		if (!trimmed) {
			setTitle(null);
			setAuthor(null);
			setThumbnail(null);
			setMessage(null);
			if (status === "preview" || status === "error" || status === "success") setStatus("idle");
			return;
		}
		if (youtubeId) setThumbnail(youtubeThumbnail(youtubeId));
		if (!looksLikeUrl(trimmed) || !platform) {
			if (trimmed.length > 12) {
				setStatus("error");
				setMessage("Cole um link do YouTube, TikTok ou Instagram.");
			}
			return;
		}
		const seq = ++previewSeq.current;
		const handle = window.setTimeout(() => {
			(async () => {
				try {
					const result = await previewMediaFn({ data: { url: normalizeUrl(trimmed) } });
					if (seq !== previewSeq.current) return;
					if (result.ok) {
						setTitle(result.title);
						setAuthor(result.author ?? null);
						setThumbnail(result.thumbnail ?? (youtubeId ? youtubeThumbnail(youtubeId) : null));
						setMessage(null);
						setStatus((current) => current === "saving" || current === "preparing" ? current : "preview");
					} else if (status !== "saving" && status !== "preparing") setMessage(result.message);
				} catch {
					if (seq !== previewSeq.current) return;
				}
			})();
		}, 380);
		return () => window.clearTimeout(handle);
	}, [
		url,
		platform,
		youtubeId
	]);
	function selectQuality(next) {
		setQuality(next);
		setAudioOnly(false);
		if (status === "success" || status === "error") {
			setStatus(title ? "preview" : "idle");
			setMessage(null);
		}
	}
	function toggleAudio() {
		setAudioOnly((value) => !value);
		if (status === "success" || status === "error") {
			setStatus(title ? "preview" : "idle");
			setMessage(null);
		}
	}
	async function addChromeShortcut() {
		const promptEvent = installPromptRef.current;
		if (promptEvent) {
			await promptEvent.prompt();
			installPromptRef.current = null;
			toast.success("Atalho pronto no Chrome");
			return;
		}
		const appUrl = `${window.location.origin}/`;
		try {
			await navigator.clipboard.writeText(appUrl);
		} catch {}
		const opened = window.open(appUrl, "_blank", "noopener,noreferrer");
		toast.message(opened ? "Abra a aba nova no Chrome → menu ⋮ → Adicionar à tela inicial." : "No Chrome: menu ⋮ → Adicionar à tela inicial / Criar atalho.");
	}
	async function handlePaste() {
		try {
			const text = await navigator.clipboard.readText();
			if (!text.trim()) {
				setPasteHint("A área de transferência está vazia.");
				return;
			}
			setUrl(text.trim());
			setPasteHint(null);
			inputRef.current?.focus();
		} catch {
			setPasteHint("Toque no campo e cole o link.");
			inputRef.current?.focus();
		}
	}
	function cancelInFlight() {
		abortRef.current?.abort();
		abortRef.current = null;
		setStatus(title ? "preview" : "idle");
		setProgress(0);
		setMessage(null);
	}
	async function runDownload(mode) {
		const trimmed = url.trim();
		if (!trimmed) {
			setStatus("error");
			setMessage("Cole um link para começar.");
			inputRef.current?.focus();
			return;
		}
		if (!detectPlatform(trimmed)) {
			setStatus("error");
			setMessage("Cole um link do YouTube, TikTok ou Instagram.");
			return;
		}
		abortRef.current?.abort();
		const controller = new AbortController();
		abortRef.current = controller;
		setStatus("preparing");
		setMessage(audioOnly ? "Preparando o MP3…" : "Preparando o vídeo sem marca d'água…");
		setProgress(0);
		try {
			const prepared = await prepareMediaFn({ data: {
				url: normalizeUrl(trimmed),
				quality,
				audioOnly
			} });
			if (controller.signal.aborted) return;
			if (!prepared.ok) {
				setStatus("error");
				setMessage(prepared.message);
				toast.error(prepared.message);
				return;
			}
			setTitle(prepared.title);
			setAuthor(prepared.author ?? null);
			setThumbnail(prepared.thumbnail ?? null);
			setStatus("saving");
			setMessage(mode === "gallery" ? "Salvando na galeria…" : "Baixando arquivo…");
			const result = await saveMediaFile({
				sourceUrl: prepared.downloadUrl,
				filename: prepared.filename,
				mime: prepared.mime,
				mode,
				signal: controller.signal,
				onProgress: (info) => setProgress(info.ratio)
			});
			if (controller.signal.aborted) return;
			setProgress(1);
			setStatus("success");
			setMessage(result === "shared" ? "Pronto. Escolha Salvar vídeo na folha de compartilhamento." : mode === "gallery" ? "Arquivo baixado. Abra na galeria para guardar." : audioOnly ? "MP3 salvo no dispositivo." : "Vídeo salvo no dispositivo.");
			toast.success(audioOnly ? "Áudio pronto" : "Download concluído");
			setHistory((items) => pushHistory(items, {
				url: normalizeUrl(trimmed),
				title: prepared.title,
				platform: prepared.platform,
				thumbnail: prepared.thumbnail,
				filename: prepared.filename,
				audioOnly: prepared.audioOnly,
				quality: prepared.quality
			}));
		} catch (error) {
			if (controller.signal.aborted) return;
			const failed = error instanceof Error && error.name === "AbortError" ? "Download cancelado." : "Falha ao salvar o arquivo. Tente de novo.";
			setStatus("error");
			setMessage(failed);
			toast.error(failed);
		} finally {
			if (abortRef.current === controller) abortRef.current = null;
		}
	}
	function reuseItem(item) {
		setUrl(item.url);
		setQuality(item.quality);
		setAudioOnly(item.audioOnly);
		setTitle(item.title);
		setThumbnail(item.thumbnail ?? null);
		setStatus("preview");
		setMessage(null);
		window.scrollTo({
			top: 0,
			behavior: "smooth"
		});
	}
	const showPreview = Boolean(platform && (thumbnail || title));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "puro-shell mx-auto flex min-h-dvh w-full max-w-md flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				theme: "dark",
				position: "top-center",
				duration: 2800,
				toastOptions: { className: "!bg-elevated !text-fg !border !border-border !shadow-none !rounded-md" }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "puro-enter flex items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-xs font-medium tracking-[0.28em] text-subtle uppercase",
					children: "downloader"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 font-display text-4xl font-semibold tracking-tight text-fg",
					children: "puro"
				})] }), standalone ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-1 flex size-11 items-center justify-center rounded-lg bg-elevated shadow-[var(--shadow-border)]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "relative block size-4 rounded-full border-2 border-fg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute inset-[5px] rounded-full bg-fg" })
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => void addChromeShortcut(),
					"aria-label": "Adicionar atalho no Chrome",
					title: "Adicionar atalho no Chrome",
					className: "mb-1 flex size-11 items-center justify-center rounded-lg bg-elevated shadow-[var(--shadow-border)] transition-transform duration-150 active:scale-[0.96]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "relative block size-4 rounded-full border-2 border-fg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute inset-[5px] rounded-full bg-fg" })
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "puro-enter puro-enter-delay-1 mt-3 max-w-[34ch] text-sm leading-relaxed text-muted",
				children: "Cole um link do YouTube, TikTok ou Instagram. Vídeo sem marca d'água, ou só o áudio em MP3."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-6 flex flex-col gap-5",
				onSubmit: (event) => {
					event.preventDefault();
					runDownload("download");
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "puro-enter puro-enter-delay-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								htmlFor: "puro-url",
								className: "mb-2 block text-xs font-medium tracking-wide text-subtle",
								children: "Link"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2 rounded-xl bg-surface p-2 shadow-[var(--shadow-border)]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									ref: inputRef,
									id: "puro-url",
									name: "url",
									type: "url",
									inputMode: "url",
									autoCapitalize: "off",
									autoCorrect: "off",
									autoComplete: "off",
									spellCheck: false,
									placeholder: "Cole o link aqui",
									value: url,
									onChange: (event) => {
										setUrl(event.target.value);
										setPasteHint(null);
										if (status === "success" || status === "error") {
											setStatus("idle");
											setMessage(null);
										}
									},
									className: cn("min-h-12 min-w-0 flex-1 rounded-md bg-transparent px-3 text-base text-fg", "placeholder:text-subtle outline-none")
								}), url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-label": "Limpar link",
									onClick: () => {
										setUrl("");
										setPasteHint(null);
										inputRef.current?.focus();
									},
									className: "flex size-12 shrink-0 items-center justify-center rounded-md text-muted transition-colors duration-150 hover:bg-elevated hover:text-fg active:scale-[0.96]",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {
										className: "size-4",
										strokeWidth: 1.75
									})
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => void handlePaste(),
									className: "flex min-h-12 shrink-0 items-center gap-1.5 rounded-md bg-elevated px-3.5 text-sm font-medium text-fg transition-transform duration-150 active:scale-[0.96]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardPaste, {
										className: "size-4",
										strokeWidth: 1.75
									}), "Colar"]
								})]
							}),
							pasteHint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-xs text-muted",
								children: pasteHint
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3 flex gap-2",
								children: PLATFORM_HINTS.map((item) => {
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: cn("inline-flex min-h-8 items-center rounded-full px-3 text-xs font-medium transition-colors duration-150", platform === item ? "bg-accent text-accent-fg" : "bg-elevated text-subtle"),
										children: PLATFORM_LABEL[item]
									}, item);
								})
							})
						]
					}),
					showPreview ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-border)]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative aspect-video bg-elevated",
							children: [thumbnail ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: thumbnail,
								alt: "",
								className: "size-full object-cover outline outline-1 -outline-offset-1 outline-fg/10"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "puro-shimmer size-full" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "absolute inset-x-0 bottom-0 bg-gradient-to-t from-bg/90 to-transparent p-4 pt-10",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-[11px] font-medium tracking-wide text-muted uppercase",
										children: [platform ? PLATFORM_LABEL[platform] : "", audioOnly ? " · MP3" : ` · ${quality}`]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 line-clamp-2 text-sm font-medium text-fg",
										children: title || "Prévia do vídeo"
									}),
									author ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-0.5 truncate text-xs text-subtle",
										children: author
									}) : null
								]
							})]
						})
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
						className: "puro-enter puro-enter-delay-3 min-w-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
								className: "mb-2 text-xs font-medium tracking-wide text-subtle",
								children: "Qualidade"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								role: "radiogroup",
								"aria-label": "Qualidade do vídeo",
								className: "grid grid-cols-3 gap-2",
								children: QUALITIES.map((option) => {
									const selected = !audioOnly && quality === option;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										role: "radio",
										"aria-checked": selected,
										onClick: () => selectQuality(option),
										className: cn("min-h-12 rounded-md text-sm font-medium select-none", "transition-[background-color,color,transform,opacity] duration-150 ease-out", "active:scale-[0.96] touch-manipulation", selected ? "bg-accent text-accent-fg" : "bg-elevated text-muted", audioOnly && "opacity-50"),
										children: option
									}, option);
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-xs leading-relaxed text-subtle",
								children: "Se a qualidade não existir no original, o Puro baixa a melhor disponível."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						"aria-pressed": audioOnly,
						onClick: toggleAudio,
						className: cn("flex min-h-12 w-full items-center justify-between rounded-xl px-4 text-left select-none", "shadow-[var(--shadow-border)] transition-[background-color,transform] duration-150 ease-out", "active:scale-[0.98] touch-manipulation", audioOnly ? "bg-accent text-accent-fg" : "bg-surface text-fg"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AudioLines, {
								className: "size-4",
								strokeWidth: 1.75
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm font-medium",
								children: "Só áudio (MP3)"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("relative h-6 w-11 rounded-full transition-colors duration-150", audioOnly ? "bg-accent-fg/20" : "bg-elevated"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("absolute top-0.5 left-0.5 size-5 rounded-full bg-fg transition-transform duration-150 ease-out", audioOnly && "translate-x-5 bg-accent-fg") })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "submit",
							disabled: busy,
							className: cn("flex min-h-14 w-full items-center justify-center gap-2 rounded-xl bg-accent px-4", "text-sm font-semibold text-accent-fg select-none touch-manipulation", "transition-transform duration-150 ease-out active:scale-[0.98]", "disabled:opacity-60"),
							children: [busy && !audioOnly ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
								className: "size-4 animate-spin",
								strokeWidth: 1.75
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
								className: "size-4",
								strokeWidth: 1.75
							}), audioOnly ? "Baixar MP3" : "Baixar vídeo"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							disabled: busy,
							onClick: () => void runDownload("gallery"),
							className: cn("flex min-h-14 w-full items-center justify-center gap-2 rounded-xl bg-surface px-4", "text-sm font-medium text-fg shadow-[var(--shadow-border)] select-none touch-manipulation", "transition-transform duration-150 ease-out active:scale-[0.98]", "disabled:opacity-60"),
							children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
								className: "size-4 animate-spin",
								strokeWidth: 1.75
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageDown, {
								className: "size-4",
								strokeWidth: 1.75
							}), "Salvar na galeria"]
						})]
					})
				]
			}),
			status !== "idle" && message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				role: "status",
				"aria-live": "polite",
				className: cn("mt-5 rounded-xl px-4 py-3 shadow-[var(--shadow-border)]", status === "error" && "bg-surface", status === "success" && "bg-surface", (status === "preparing" || status === "saving") && "bg-surface", status === "preview" && "hidden"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-3",
					children: [
						status === "error" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, {
							className: "mt-0.5 size-4 shrink-0 text-danger",
							strokeWidth: 1.75
						}) : status === "success" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
							className: "mt-0.5 size-4 shrink-0 text-success",
							strokeWidth: 1.75
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
							className: "mt-0.5 size-4 shrink-0 animate-spin text-muted",
							strokeWidth: 1.75
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm leading-relaxed text-fg",
								children: message
							}), status === "saving" || status === "preparing" && progress > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3 h-1 overflow-hidden rounded-full bg-elevated",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full rounded-full bg-accent transition-[width] duration-150 ease-out",
									style: { width: `${Math.max(6, Math.round(progress * 100))}%` }
								})
							}) : null]
						}),
						busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: cancelInFlight,
							className: "min-h-10 shrink-0 rounded-md px-2 text-xs font-medium text-muted",
							children: "Cancelar"
						}) : null
					]
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xs font-medium tracking-wide text-subtle uppercase",
						children: "Recentes"
					}), history.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setHistory(clearHistory()),
						className: "flex min-h-10 items-center gap-1.5 rounded-md px-2 text-xs font-medium text-subtle transition-colors duration-150 hover:text-fg",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {
							className: "size-3.5",
							strokeWidth: 1.75
						}), "Limpar"]
					}) : null]
				}), history.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-subtle",
					children: "Seus downloads aparecem aqui, neste aparelho."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 flex flex-col gap-2",
					children: history.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => reuseItem(item),
						className: "flex min-h-14 w-full items-center gap-3 rounded-xl bg-surface p-2 pr-3 text-left shadow-[var(--shadow-border)] transition-transform duration-150 active:scale-[0.99]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "relative size-12 shrink-0 overflow-hidden rounded-md bg-elevated",
							children: item.thumbnail ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: item.thumbnail,
								alt: "",
								className: "size-full object-cover"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex size-full items-center justify-center text-[10px] text-subtle",
								children: PLATFORM_LABEL[item.platform].slice(0, 2)
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "line-clamp-1 text-sm font-medium text-fg",
								children: item.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "mt-0.5 block text-xs text-subtle",
								children: [
									PLATFORM_LABEL[item.platform],
									" · ",
									item.audioOnly ? "MP3" : item.quality,
									" · ",
									formatTime(item.at)
								]
							})]
						})]
					}) }, item.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-10 text-center text-[11px] leading-relaxed text-subtle",
				children: "Baixe só o que você tem direito de copiar. O Puro não guarda os arquivos na nuvem."
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PuroApp, {});
}
//#endregion
export { Home as component };
