import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Moon, c as Layers, d as Calendar, f as BookOpen, i as Palette, l as Instagram, o as Mail, p as ArrowUpRight, r as Sun, s as Linkedin, t as Youtube, u as Frame } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CzVorVb4.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var profile = {
	name: "Avery Solis",
	kicker: "Designer & photographer",
	bio: "Quiet products, coastal light, and notes on making things that last.",
	place: "Lisbon · Pacific coast",
	status: "Open for a spring project",
	avatar: "/avatar.jpg"
};
var links = [
	{
		href: "https://www.are.na/",
		title: "Harbor House",
		hint: "Identity, type, and a house by the water",
		icon: Palette,
		featured: true
	},
	{
		href: "https://read.cv/",
		title: "Selected work",
		hint: "A short shelf of recent projects",
		icon: Layers
	},
	{
		href: "https://substack.com/",
		title: "Field notes",
		hint: "The Sunday letter on making",
		icon: BookOpen
	},
	{
		href: "https://cal.com/",
		title: "Book a studio call",
		hint: "Thirty minutes, no deck required",
		icon: Calendar
	},
	{
		href: "https://www.printeditions.com/",
		title: "Print shop",
		hint: "Coastal studies, small editions",
		icon: Frame
	}
];
var socials = [
	{
		href: "https://instagram.com/",
		label: "Instagram",
		kind: "instagram"
	},
	{
		href: "https://x.com/",
		label: "X",
		kind: "x"
	},
	{
		href: "https://youtube.com/",
		label: "YouTube",
		kind: "youtube"
	},
	{
		href: "https://www.linkedin.com/",
		label: "LinkedIn",
		kind: "linkedin"
	},
	{
		href: "mailto:hello@averysolis.studio",
		label: "Email",
		kind: "mail"
	}
];
var THEME_KEY = "solis-theme";
function XIcon() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		className: "size-5",
		"aria-hidden": "true",
		fill: "currentColor",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M14.7 10.3 22.2 2h-1.8l-6.5 7.2L8.7 2H2l8 11.2L2 22h1.8l7-7.8L15.3 22H22l-7.3-11.7Zm-2.5 2.8-.8-1.1L4.5 3.3h2.8l5.2 7.1.8 1.1 6.7 9.2h-2.8l-5.5-7.6Z" })
	});
}
function SocialGlyph({ kind }) {
	const className = "size-5";
	if (kind === "instagram") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Instagram, {
		className,
		"aria-hidden": "true"
	});
	if (kind === "youtube") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Youtube, {
		className,
		"aria-hidden": "true"
	});
	if (kind === "linkedin") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Linkedin, {
		className,
		"aria-hidden": "true"
	});
	if (kind === "mail") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, {
		className,
		"aria-hidden": "true"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(XIcon, {});
}
function resolvedDark() {
	const stored = localStorage.getItem(THEME_KEY);
	if (stored === "dark") return true;
	if (stored === "light") return false;
	return window.matchMedia("(prefers-color-scheme: dark)").matches;
}
function ThemeToggle() {
	const [dark, setDark] = (0, import_react.useState)(null);
	(0, import_react.useLayoutEffect)(() => {
		setDark(resolvedDark());
	}, []);
	function toggle() {
		const next = !resolvedDark();
		document.documentElement.setAttribute("data-theme", next ? "dark" : "light");
		localStorage.setItem(THEME_KEY, next ? "dark" : "light");
		setDark(next);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick: toggle,
		"aria-label": dark ? "Switch to light theme" : "Switch to dark theme",
		"aria-pressed": dark === true,
		className: "theme-btn grid size-11 place-items-center rounded-full border border-line bg-card text-ink",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "relative size-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "theme-glyph theme-sun absolute inset-0 grid place-items-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, {
					className: "size-5",
					"aria-hidden": "true"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "theme-glyph theme-moon grid size-5 place-items-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, {
					className: "size-5",
					"aria-hidden": "true"
				})
			})]
		})
	});
}
function BioPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "relative min-h-dvh",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "halo pointer-events-none absolute inset-x-0 top-0 h-80" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mx-auto flex w-full max-w-md flex-col px-5 pt-5 pb-28",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rise flex justify-end",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThemeToggle, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "mt-3 flex flex-col items-center text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "rise",
							style: { animationDelay: "60ms" },
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: profile.avatar,
								alt: "Illustrated portrait of Avery Solis",
								width: 512,
								height: 512,
								className: "avatar size-32 rounded-full object-cover ring-4 ring-card"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "rise mt-6 text-xs font-medium tracking-widest text-accent uppercase",
							style: { animationDelay: "120ms" },
							children: profile.kicker
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "rise mt-2 font-display text-5xl leading-none font-medium tracking-tight text-balance",
							style: { animationDelay: "180ms" },
							children: profile.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "rise mt-3 max-w-xs text-base leading-relaxed text-pretty text-muted",
							style: { animationDelay: "240ms" },
							children: profile.bio
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "rise mt-3 inline-flex items-center gap-2 text-sm text-ink",
							style: { animationDelay: "300ms" },
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "size-1.5 rounded-full bg-accent",
								"aria-hidden": "true"
							}), profile.status]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					"aria-label": "Social",
					className: "rise mt-6 flex items-center justify-center gap-2.5",
					style: { animationDelay: "360ms" },
					children: socials.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: item.href,
						target: item.kind === "mail" ? void 0 : "_blank",
						rel: item.kind === "mail" ? void 0 : "noreferrer noopener",
						"aria-label": item.label,
						className: "social grid size-11 place-items-center rounded-full border border-line bg-card text-ink",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SocialGlyph, { kind: item.kind })
					}, item.label))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-7 flex flex-col gap-3",
					children: links.map((link, index) => {
						const Icon = link.icon;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "rise",
							style: { animationDelay: `${420 + index * 70}ms` },
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: link.href,
								target: "_blank",
								rel: "noreferrer noopener",
								className: `link-card flex min-h-16 items-center gap-3.5 rounded-3xl border border-line bg-card px-3.5 py-3 ${link.featured ? "is-featured" : ""}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "grid size-11 shrink-0 place-items-center rounded-2xl bg-paper text-accent",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
											className: "size-5",
											"aria-hidden": "true"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "min-w-0 flex-1 text-left",
										children: [
											link.featured ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "block text-xs font-medium tracking-widest text-accent uppercase",
												children: "Featured"
											}) : null,
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "block truncate text-base font-medium text-ink",
												children: link.title
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "block truncate text-sm text-muted",
												children: link.hint
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
										className: "chev size-4 shrink-0 text-muted",
										"aria-hidden": "true"
									})
								]
							})
						}, link.title);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rise mt-8 text-center text-sm text-muted",
					style: { animationDelay: "780ms" },
					children: profile.place
				})
			]
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BioPage, {});
}
//#endregion
export { Home as component };
