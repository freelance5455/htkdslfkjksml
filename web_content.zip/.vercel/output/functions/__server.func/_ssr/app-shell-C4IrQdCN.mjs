import { i as __toESM } from "../_runtime.mjs";
import { B as require_react, f as useRouterState, x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as Heart, a as Square, f as Play, g as Library, o as Sparkles, p as Pause, w as BookOpen, y as Ellipsis } from "../_libs/lucide-react.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/app-shell-C4IrQdCN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function applyChrome(settings) {
	if (typeof document === "undefined") return;
	const root = document.documentElement;
	const dark = settings.theme === "dark" || settings.theme === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches;
	root.classList.toggle("dark", dark);
	root.classList.toggle("large-ui", settings.largeDisplay);
	root.style.colorScheme = dark ? "dark" : "light";
}
var useAppStore = create()(persist((set, get) => ({
	settings: {
		theme: "system",
		fontScale: 1,
		quranScale: 1.15,
		largeDisplay: false,
		reciterId: "alafasy"
	},
	lastReading: null,
	lastBook: null,
	favorites: [],
	bookmarks: [],
	dhikrProgress: {},
	downloadedSurahs: [],
	setTheme: (theme) => set((s) => {
		const settings = {
			...s.settings,
			theme
		};
		applyChrome(settings);
		return { settings };
	}),
	setFontScale: (fontScale) => set((s) => ({ settings: {
		...s.settings,
		fontScale
	} })),
	setQuranScale: (quranScale) => set((s) => ({ settings: {
		...s.settings,
		quranScale
	} })),
	setLargeDisplay: (largeDisplay) => set((s) => {
		const settings = {
			...s.settings,
			largeDisplay
		};
		applyChrome(settings);
		return { settings };
	}),
	setReciter: (reciterId) => set((s) => ({ settings: {
		...s.settings,
		reciterId
	} })),
	setLastReading: (lastReading) => set({ lastReading }),
	setLastBook: (lastBook) => set({ lastBook }),
	toggleFavorite: (item) => set((s) => {
		return { favorites: s.favorites.some((f) => f.id === item.id) ? s.favorites.filter((f) => f.id !== item.id) : [{
			...item,
			createdAt: Date.now()
		}, ...s.favorites] };
	}),
	isFavorite: (id) => get().favorites.some((f) => f.id === id),
	addBookmark: (item) => set((s) => ({ bookmarks: [{
		id: item.id ?? `bm-${Date.now()}`,
		label: item.label,
		href: item.href,
		createdAt: Date.now()
	}, ...s.bookmarks].slice(0, 80) })),
	removeBookmark: (id) => set((s) => ({ bookmarks: s.bookmarks.filter((b) => b.id !== id) })),
	bumpDhikr: (id, max) => set((s) => {
		const current = s.dhikrProgress[id] ?? 0;
		const next = current >= max ? 0 : current + 1;
		return { dhikrProgress: {
			...s.dhikrProgress,
			[id]: next
		} };
	}),
	resetDhikr: (id) => set((s) => ({ dhikrProgress: {
		...s.dhikrProgress,
		[id]: 0
	} })),
	resetListDhikr: (ids) => set((s) => {
		const next = { ...s.dhikrProgress };
		for (const id of ids) next[id] = 0;
		return { dhikrProgress: next };
	}),
	markDownloaded: (surahId) => set((s) => ({ downloadedSurahs: s.downloadedSurahs.includes(surahId) ? s.downloadedSurahs : [...s.downloadedSurahs, surahId] }))
}), {
	name: "rafeeq",
	partialize: (s) => ({
		settings: s.settings,
		lastReading: s.lastReading,
		lastBook: s.lastBook,
		favorites: s.favorites,
		bookmarks: s.bookmarks,
		dhikrProgress: s.dhikrProgress,
		downloadedSurahs: s.downloadedSurahs
	}),
	onRehydrateStorage: () => (state) => {
		if (state) applyChrome(state.settings);
	}
}));
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var AR = "٠١٢٣٤٥٦٧٨٩";
function toArabicDigits(value) {
	return String(value).replace(/\d/g, (d) => AR[Number(d)] ?? d);
}
function normalizeArabic(input) {
	return input.replace(/[\u064B-\u065F\u0670\u06D6-\u06ED\u0640]/g, "").replace(/[إأآٱا]/g, "ا").replace(/ى/g, "ي").replace(/ؤ/g, "و").replace(/ئ/g, "ي").replace(/ة/g, "ه").replace(/[^\u0600-\u06FFa-zA-Z0-9\s]/g, " ").replace(/\s+/g, " ").trim();
}
var ITEMS = [
	{
		to: "/quran",
		label: "القرآن",
		icon: BookOpen,
		match: (p) => p === "/" || p.startsWith("/quran")
	},
	{
		to: "/adhkar",
		label: "الأذكار",
		icon: Sparkles,
		match: (p) => p.startsWith("/adhkar")
	},
	{
		to: "/library",
		label: "المكتبة",
		icon: Library,
		match: (p) => p.startsWith("/library")
	},
	{
		to: "/favorites",
		label: "المفضلة",
		icon: Heart,
		match: (p) => p.startsWith("/favorites")
	},
	{
		to: "/more",
		label: "المزيد",
		icon: Ellipsis,
		match: (p) => p.startsWith("/more") || p.startsWith("/listen") || p.startsWith("/search")
	}
];
function BottomNav() {
	const path = useRouterState({ select: (s) => s.location.pathname });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		className: "fixed inset-x-0 bottom-0 z-40 border-t border-border bg-paper/95 backdrop-blur-md",
		style: { paddingBottom: "env(safe-area-inset-bottom)" },
		"aria-label": "التنقل الرئيسي",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mx-auto grid max-w-lg grid-cols-5",
			children: ITEMS.map((item) => {
				const active = item.match(path);
				const Icon = item.icon;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: item.to,
					className: cn("flex flex-col items-center justify-center gap-1 py-2.5 text-[11px] font-medium transition-colors duration-[var(--motion-quick)]", active ? "text-accent" : "text-muted-foreground"),
					"aria-current": active ? "page" : void 0,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
						className: "size-5",
						strokeWidth: active ? 2.2 : 1.7
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.label })]
				}) }, item.to);
			})
		})
	});
}
var RECITERS = [
	{
		id: "alafasy",
		name: "مشاري راشد العفاسي",
		everyayah: "Alafasy_128kbps",
		islamic: "ar.alafasy"
	},
	{
		id: "husary",
		name: "محمود خليل الحصري",
		everyayah: "Husary_128kbps",
		islamic: "ar.husary"
	},
	{
		id: "sudais",
		name: "عبد الرحمن السديس",
		everyayah: "Abdurrahmaan_As-Sudais_192kbps",
		islamic: "ar.abdurrahmaansudais"
	},
	{
		id: "minshawi",
		name: "محمد صديق المنشاوي",
		everyayah: "Minshawy_Murattal_128kbps",
		islamic: "ar.minshawi"
	}
];
function getReciter(id) {
	return RECITERS.find((r) => r.id === id) ?? RECITERS[0];
}
function ayahAudioUrls(reciter, surahId, ayah, global) {
	const s = String(surahId).padStart(3, "0");
	const a = String(ayah).padStart(3, "0");
	return [`https://everyayah.com/data/${reciter.everyayah}/${s}${a}.mp3`, `https://cdn.islamic.network/quran/audio/128/${reciter.islamic}/${global}.mp3`];
}
var CACHE = "rafeeq-audio-v1";
async function cachedUrl(urls) {
	if (typeof caches === "undefined") return urls[0];
	try {
		const cache = await caches.open(CACHE);
		for (const url of urls) if (await cache.match(url)) return url;
	} catch {}
	return urls[0];
}
async function downloadUrls(urls) {
	if (typeof caches === "undefined") return false;
	const cache = await caches.open(CACHE);
	for (const url of urls) try {
		const res = await fetch(url, { mode: "cors" });
		if (res.ok) {
			await cache.put(url, res);
			return true;
		}
	} catch {
		continue;
	}
	return false;
}
async function downloadSurahAyahs(reciter, surah, onProgress) {
	let ok = 0;
	for (let i = 0; i < surah.ayahs.length; i++) {
		const a = surah.ayahs[i];
		if (await downloadUrls(ayahAudioUrls(reciter, surah.id, a.n, a.g))) ok += 1;
		onProgress?.(i + 1, surah.ayahs.length);
	}
	return ok;
}
var AudioEngine = class {
	audio = typeof Audio !== "undefined" ? new Audio() : null;
	listeners = /* @__PURE__ */ new Set();
	queue = [];
	index = 0;
	repeats = 1;
	remaining = 1;
	reciter = RECITERS[0];
	status = {
		playing: false,
		surahId: null,
		ayah: null,
		title: "",
		repeatLeft: 0,
		mode: "idle"
	};
	onAyah = null;
	constructor() {
		if (!this.audio) return;
		this.audio.preload = "auto";
		this.audio.addEventListener("ended", () => this.next());
		this.audio.addEventListener("error", () => this.fallbackOrNext());
	}
	subscribe(fn) {
		this.listeners.add(fn);
		fn(this.status);
		return () => {
			this.listeners.delete(fn);
		};
	}
	setAyahHandler(fn) {
		this.onAyah = fn;
	}
	emit() {
		for (const fn of this.listeners) fn(this.status);
		this.syncMedia();
	}
	syncMedia() {
		if (typeof navigator === "undefined" || !navigator.mediaSession) return;
		navigator.mediaSession.metadata = new MediaMetadata({
			title: this.status.title || "رفيق",
			artist: this.reciter.name,
			album: "القرآن الكريم"
		});
		navigator.mediaSession.playbackState = this.status.playing ? "playing" : "paused";
	}
	setReciter(id) {
		this.reciter = getReciter(id);
	}
	pause() {
		this.audio?.pause();
		this.status = {
			...this.status,
			playing: false
		};
		this.emit();
	}
	toggle() {
		if (!this.audio) return;
		if (this.status.playing) this.pause();
		else this.audio.play().then(() => {
			this.status = {
				...this.status,
				playing: true
			};
			this.emit();
		});
	}
	stop() {
		if (this.audio) {
			this.audio.pause();
			this.audio.removeAttribute("src");
		}
		this.queue = [];
		this.status = {
			playing: false,
			surahId: null,
			ayah: null,
			title: "",
			repeatLeft: 0,
			mode: "idle"
		};
		this.emit();
	}
	async playAyah(opts) {
		this.setReciter(opts.reciterId);
		this.repeats = Math.max(1, opts.repeat ?? 1);
		this.remaining = this.repeats;
		if (opts.continueSurah) this.queue = opts.continueSurah.ayahs.filter((a) => a.n >= opts.ayah).map((a) => ({
			surahId: opts.surahId,
			ayah: a.n,
			global: a.g,
			title: `${opts.title} — ${a.n}`
		}));
		else this.queue = [{
			surahId: opts.surahId,
			ayah: opts.ayah,
			global: opts.global,
			title: opts.title
		}];
		this.index = 0;
		this.status.mode = opts.continueSurah ? "surah" : "ayah";
		await this.loadCurrent();
	}
	async loadCurrent() {
		const item = this.queue[this.index];
		if (!item || !this.audio) return;
		const urls = ayahAudioUrls(this.reciter, item.surahId, item.ayah, item.global);
		this.audio.dataset.fallbacks = JSON.stringify(urls.slice(1));
		this.audio.src = await cachedUrl(urls);
		this.status = {
			playing: true,
			surahId: item.surahId,
			ayah: item.ayah,
			title: item.title,
			repeatLeft: this.remaining,
			mode: this.status.mode
		};
		this.onAyah?.(item.surahId, item.ayah);
		this.emit();
		try {
			await this.audio.play();
		} catch {
			this.status = {
				...this.status,
				playing: false
			};
			this.emit();
		}
	}
	async fallbackOrNext() {
		if (!this.audio) return;
		const raw = this.audio.dataset.fallbacks;
		if (raw) {
			const list = JSON.parse(raw);
			if (list.length) {
				this.audio.dataset.fallbacks = JSON.stringify(list.slice(1));
				this.audio.src = list[0];
				try {
					await this.audio.play();
					return;
				} catch {}
			}
		}
		this.next();
	}
	next() {
		this.remaining -= 1;
		if (this.remaining > 0) {
			this.loadCurrent();
			return;
		}
		this.remaining = this.repeats;
		this.index += 1;
		if (this.index >= this.queue.length) {
			this.stop();
			return;
		}
		this.loadCurrent();
	}
	speak(text, title) {
		if (typeof window === "undefined" || !window.speechSynthesis) return false;
		this.pause();
		window.speechSynthesis.cancel();
		const u = new SpeechSynthesisUtterance(text);
		u.lang = "ar-SA";
		u.rate = .9;
		u.onend = () => {
			this.status = {
				playing: false,
				surahId: null,
				ayah: null,
				title: "",
				repeatLeft: 0,
				mode: "idle"
			};
			this.emit();
		};
		this.status = {
			playing: true,
			surahId: null,
			ayah: null,
			title,
			repeatLeft: 1,
			mode: "speech"
		};
		this.emit();
		window.speechSynthesis.speak(u);
		return true;
	}
	stopSpeech() {
		if (typeof window !== "undefined") window.speechSynthesis?.cancel();
	}
};
var audioEngine = new AudioEngine();
function PlayerBar() {
	const [status, setStatus] = (0, import_react.useState)(audioEngine.status);
	(0, import_react.useEffect)(() => audioEngine.subscribe(setStatus), []);
	if (status.mode === "idle") return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("fixed inset-x-0 z-30 mx-auto max-w-lg px-3", "bottom-[calc(4.25rem+env(safe-area-inset-bottom))]"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-3 rounded-2xl border border-border bg-accent px-3 py-2.5 text-accent-foreground shadow-[var(--shadow-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "tap-lg flex size-10 items-center justify-center rounded-full bg-accent-foreground/15",
					onClick: () => audioEngine.toggle(),
					"aria-label": status.playing ? "إيقاف مؤقت" : "تشغيل",
					children: status.playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-5 ms-0.5" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-sm font-medium",
						children: status.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-[11px] opacity-80",
						children: [status.mode === "speech" ? "قراءة الجهاز" : "تلاوة", status.ayah ? ` · آية ${status.ayah}` : ""]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "tap-lg flex size-10 items-center justify-center rounded-full hover:bg-accent-foreground/10",
					onClick: () => {
						audioEngine.stopSpeech();
						audioEngine.stop();
					},
					"aria-label": "إيقاف",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, { className: "size-4" })
				})
			]
		})
	});
}
function AppShell({ children, full = false }) {
	const settings = useAppStore((s) => s.settings);
	(0, import_react.useEffect)(() => {
		const root = document.documentElement;
		const dark = settings.theme === "dark" || settings.theme === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches;
		root.classList.toggle("dark", dark);
		root.classList.toggle("large-ui", settings.largeDisplay);
		const mq = window.matchMedia("(prefers-color-scheme: dark)");
		const onChange = () => {
			if (useAppStore.getState().settings.theme === "system") document.documentElement.classList.toggle("dark", mq.matches);
		};
		mq.addEventListener("change", onChange);
		return () => mq.removeEventListener("change", onChange);
	}, [settings.theme, settings.largeDisplay]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto min-h-dvh max-w-lg bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: full ? "" : "safe-bottom",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerBar, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BottomNav, {})
		]
	});
}
function TopBar({ title, action, back }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-20 flex items-center gap-2 border-b border-border bg-background/90 px-3 py-2.5 backdrop-blur-md",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex size-11 items-center justify-center",
				children: back
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "flex-1 text-center text-base font-semibold",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex size-11 items-center justify-center",
				children: action
			})
		]
	});
}
//#endregion
export { cn as a, normalizeArabic as c, audioEngine as i, toArabicDigits as l, RECITERS as n, downloadSurahAyahs as o, TopBar as r, getReciter as s, AppShell as t, useAppStore as u };
