import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as Slot } from "../_libs/@radix-ui/react-primitive+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { _ as Check, a as Square, b as Bell, c as Settings, d as NotebookPen, f as Mic, g as ChevronLeft, h as Clock, i as StickyNote, l as Send, m as Focus, o as Sparkles, p as ListTodo, r as Trash2, s as ShoppingBag, t as UserRound, u as Plus, v as Calendar, y as Calculator } from "../_libs/lucide-react.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { a as isTomorrow, c as addMinutes, d as addDays, i as nextDay, l as startOfDay, n as setMinutes, o as isToday, r as setHours, s as addWeeks, t as setSeconds, u as addHours } from "../_libs/date-fns.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as SwitchThumb, t as Switch$1 } from "../_libs/@radix-ui/react-switch+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DJC7IW_g.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var askGrok = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("45fa6e0b190ce19650091744e8f19e6f28d1755841078e62174c799ba69fbf04"));
var WORD_NUM = {
	a: 1,
	an: 1,
	one: 1,
	two: 2,
	three: 3,
	four: 4,
	five: 5,
	six: 6,
	seven: 7,
	eight: 8,
	nine: 9,
	ten: 10,
	eleven: 11,
	twelve: 12,
	thirteen: 13,
	fourteen: 14,
	fifteen: 15,
	twenty: 20,
	thirty: 30,
	forty: 40,
	fortyfive: 45,
	forty_five: 45,
	sixty: 60,
	ninety: 90
};
var WEEKDAYS = {
	sunday: 0,
	monday: 1,
	tuesday: 2,
	wednesday: 3,
	thursday: 4,
	friday: 5,
	saturday: 6
};
function parseNumberToken(raw) {
	const t = raw.trim().toLowerCase().replaceAll("-", "_").replaceAll(" ", "_");
	if (t in WORD_NUM) return WORD_NUM[t];
	const n = Number.parseFloat(raw);
	return Number.isFinite(n) ? n : null;
}
function parseDurationMs(text) {
	const t = text.toLowerCase();
	if (/\bhalf\s+an\s+hour\b/.test(t) || /\bhalf\s+hour\b/.test(t)) return 18e5;
	if (/\ban?\s+hour\s+and\s+a\s+half\b/.test(t)) return 54e5;
	if (/\bquarter\s+(?:of\s+an?\s+)?hour\b/.test(t)) return 9e5;
	const m = t.match(/\b(\d+(?:\.\d+)?|an?|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|fifteen|twenty|thirty|forty|forty[-\s]?five|sixty|ninety)\s*(seconds?|secs?|s|minutes?|mins?|min|m|hours?|hrs?|h|days?)\b/);
	if (!m) return null;
	const n = parseNumberToken(m[1] ?? "");
	if (n == null) return null;
	const unit = m[2] ?? "minutes";
	if (unit.startsWith("s") && unit !== "sixty") return Math.round(n * 1e3);
	if (unit.startsWith("h") || unit.startsWith("hr")) return Math.round(n * 36e5);
	if (unit.startsWith("d")) return Math.round(n * 864e5);
	return Math.round(n * 6e4);
}
function parseClock(text) {
	const t = text.toLowerCase();
	if (/\bnoon\b/.test(t) || /\bmidday\b/.test(t)) return {
		hour: 12,
		minute: 0
	};
	if (/\bmidnight\b/.test(t)) return {
		hour: 0,
		minute: 0
	};
	const ampm = t.match(/\b(?:at\s+)?(\d{1,2})(?:[:.](\d{2}))?\s*(a\.?m\.?|p\.?m\.?)\b/);
	if (ampm) {
		let hour = Number(ampm[1]);
		const minute = Number(ampm[2] ?? 0);
		const mer = (ampm[3] ?? "").replaceAll(".", "");
		if (mer.startsWith("p") && hour < 12) hour += 12;
		if (mer.startsWith("a") && hour === 12) hour = 0;
		if (hour > 23 || minute > 59) return null;
		return {
			hour,
			minute
		};
	}
	const oclock = t.match(/\b(?:at\s+)?(\d{1,2})\s+o'?clock\b/);
	if (oclock) {
		const hour = Number(oclock[1]);
		if (hour > 23) return null;
		return {
			hour: hour <= 7 ? hour + 12 : hour,
			minute: 0
		};
	}
	const at = t.match(/\bat\s+(\d{1,2})(?:[:.](\d{2}))?\b/);
	if (at) {
		let hour = Number(at[1]);
		const minute = Number(at[2] ?? 0);
		if (hour <= 7) hour += 12;
		if (hour === 24) hour = 0;
		if (hour > 23 || minute > 59) return null;
		return {
			hour,
			minute
		};
	}
	const hm = t.match(/\b(\d{1,2})[:.](\d{2})\b/);
	if (hm) {
		const hour = Number(hm[1]);
		const minute = Number(hm[2]);
		if (hour > 23 || minute > 59) return null;
		return {
			hour,
			minute
		};
	}
	return null;
}
function applyClock(base, clock) {
	return setSeconds(setMinutes(setHours(base, clock.hour), clock.minute), 0);
}
function weekdayDate(now, name, next) {
	const day = WEEKDAYS[name];
	if (day == null) return now;
	if (!next && now.getDay() === day) return startOfDay(now);
	return startOfDay(nextDay(now, day));
}
function parseWhen(text, now = /* @__PURE__ */ new Date()) {
	const t = text.toLowerCase();
	const clock = parseClock(t);
	const inRel = t.match(/\bin\s+(\d+(?:\.\d+)?|an?|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|fifteen|twenty|thirty)\s*(seconds?|secs?|minutes?|mins?|min|hours?|hrs?|days?|weeks?)\b/);
	if (inRel) {
		const n = parseNumberToken(inRel[1] ?? "");
		if (n == null) return null;
		const unit = inRel[2] ?? "minutes";
		let d = now;
		if (unit.startsWith("s") && !unit.startsWith("se")) {}
		if (unit.startsWith("week")) d = addWeeks(now, n);
		else if (unit.startsWith("d")) d = addDays(now, n);
		else if (unit.startsWith("h")) d = addHours(now, n);
		else if (unit.startsWith("s")) d = new Date(now.getTime() + n * 1e3);
		else d = addMinutes(now, n);
		return d;
	}
	if (/\bhalf\s+an\s+hour\b/.test(t) && /\bin\b/.test(t)) return addMinutes(now, 30);
	let day = now;
	let dayTouched = false;
	if (/\btomorrow\b/.test(t)) {
		day = addDays(startOfDay(now), 1);
		dayTouched = true;
	} else if (/\btonight\b/.test(t) || /\bthis\s+evening\b/.test(t)) {
		day = startOfDay(now);
		dayTouched = true;
		const withClock = applyClock(day, clock ?? {
			hour: 19,
			minute: 0
		});
		if (withClock.getTime() <= now.getTime()) return addDays(withClock, 1);
		return withClock;
	} else if (/\bthis\s+morning\b/.test(t)) {
		day = startOfDay(now);
		dayTouched = true;
		return applyClock(day, clock ?? {
			hour: 9,
			minute: 0
		});
	} else if (/\bthis\s+afternoon\b/.test(t)) {
		day = startOfDay(now);
		dayTouched = true;
		return applyClock(day, clock ?? {
			hour: 15,
			minute: 0
		});
	} else if (/\btoday\b/.test(t)) {
		day = startOfDay(now);
		dayTouched = true;
	}
	const wd = t.match(/\b(next\s+)?(sunday|monday|tuesday|wednesday|thursday|friday|saturday)\b/);
	if (wd) {
		day = weekdayDate(now, wd[2] ?? "monday", Boolean(wd[1]));
		dayTouched = true;
	}
	if (clock) {
		let result = applyClock(dayTouched ? day : now, clock);
		if (result.getTime() <= now.getTime()) result = addDays(result, 1);
		return result;
	}
	if (dayTouched) return applyClock(day, {
		hour: 9,
		minute: 0
	});
	return null;
}
var WHEN_STRIP = /\b(?:at|@)\s+\d{1,2}(?:[:.]\d{2})?\s*(?:a\.?m\.?|p\.?m\.?)?|\b\d{1,2}[:.]\d{2}\s*(?:a\.?m\.?|p\.?m\.?)?|\b\d{1,2}\s*(?:a\.?m\.?|p\.?m\.?)\b|\bin\s+(?:\d+(?:\.\d+)?|an?|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|fifteen|twenty|thirty)\s*(?:seconds?|secs?|minutes?|mins?|min|hours?|hrs?|days?|weeks?)\b|\b(?:today|tomorrow|tonight|this\s+(?:morning|afternoon|evening)|next\s+)?(?:sunday|monday|tuesday|wednesday|thursday|friday|saturday)?\b|\b(?:noon|midnight|midday|o'?clock)\b|\bhalf\s+an\s+hour\b/gi;
function stripWhen(text) {
	return text.replace(WHEN_STRIP, " ").replace(/\b(on|at|for|this|next|in)\s*$/gi, "").replace(/\s+/g, " ").trim();
}
function formatWhen(ts, now = Date.now()) {
	const d = new Date(ts);
	const sameDay = new Date(ts).toDateString() === new Date(now).toDateString();
	const tomorrow = new Date(now + 864e5).toDateString() === d.toDateString();
	const time = d.toLocaleTimeString([], {
		hour: "numeric",
		minute: "2-digit"
	});
	if (sameDay) return time;
	if (tomorrow) return `tomorrow ${time}`;
	return `${d.toLocaleDateString([], {
		weekday: "short",
		month: "short",
		day: "numeric"
	})} ${time}`;
}
function formatClock(hour, minute) {
	const d = /* @__PURE__ */ new Date();
	d.setHours(hour, minute, 0, 0);
	return d.toLocaleTimeString([], {
		hour: "numeric",
		minute: "2-digit"
	});
}
function msToClock(ms) {
	const total = Math.max(0, Math.ceil(ms / 1e3));
	const h = Math.floor(total / 3600);
	const m = Math.floor(total % 3600 / 60);
	const s = total % 60;
	if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
	return `${m}:${String(s).padStart(2, "0")}`;
}
function greeting(now = /* @__PURE__ */ new Date(), name = "") {
	const h = now.getHours();
	const who = name.trim() ? `, ${name.trim()}` : "";
	if (h < 5) return `Still early${who}.`;
	if (h < 12) return `Good morning${who}.`;
	if (h < 17) return `Good afternoon${who}.`;
	if (h < 21) return `Good evening${who}.`;
	return `Good night${who}.`;
}
function composeBriefing(input) {
	const now = input.now ?? Date.now();
	const openTasks = input.tasks.filter((t) => !t.done);
	const dueToday = openTasks.filter((t) => t.dueAt && isToday(t.dueAt));
	const todayRems = input.reminders.filter((r) => !r.done && r.at >= now).sort((a, b) => a.at - b.at).filter((r) => isToday(r.at));
	const events = input.events.filter((e) => e.startAt >= startOfDay(now).getTime()).sort((a, b) => a.startAt - b.startAt);
	const todayEvents = events.filter((e) => isToday(e.startAt));
	const running = input.timers.filter((t) => t.status === "running");
	const shopOpen = input.lists.find((l) => l.name.toLowerCase().includes("shop"))?.items.filter((i) => !i.done).length ?? 0;
	const bits = [];
	if (running[0]) {
		const left = running[0].endsAt - now;
		bits.push(`Timer ${msToClock(left)} remaining.`);
	}
	if (todayEvents[0]) bits.push(`Next up: ${todayEvents[0].title} at ${formatWhen(todayEvents[0].startAt, now)}.`);
	else if (todayRems[0]) bits.push(`Next reminder: ${todayRems[0].title} at ${formatWhen(todayRems[0].at, now)}.`);
	if (dueToday.length) bits.push(`${dueToday.length} task${dueToday.length === 1 ? "" : "s"} due today.`);
	else if (openTasks.length) bits.push(`${openTasks.length} open task${openTasks.length === 1 ? "" : "s"}.`);
	if (shopOpen) bits.push(`${shopOpen} on shopping.`);
	if (events.filter((e) => isTomorrow(e.startAt)).length) bits.push(`${events.filter((e) => isTomorrow(e.startAt)).length} on tomorrow.`);
	if (!bits.length) return "Your board is clear. Tell me what to capture.";
	return bits.join(" ");
}
function parseActionBlock(text) {
	const match = text.match(/```action\s*([\s\S]*?)```/i);
	if (!match) return {
		clean: text.trim(),
		intent: null
	};
	const clean = text.replace(match[0], "").trim();
	try {
		const raw = JSON.parse(match[1] ?? "");
		switch (String(raw.type ?? "")) {
			case "add_task": return {
				clean,
				intent: {
					type: "add_task",
					title: String(raw.title ?? "Task"),
					dueAt: typeof raw.dueAt === "number" ? raw.dueAt : null
				}
			};
			case "add_note": return {
				clean,
				intent: {
					type: "add_note",
					title: String(raw.title ?? "Note"),
					body: String(raw.body ?? "")
				}
			};
			case "add_reminder": return {
				clean,
				intent: {
					type: "add_reminder",
					title: String(raw.title ?? "Reminder"),
					at: typeof raw.at === "number" ? raw.at : Date.now() + 36e5
				}
			};
			case "add_list_item": return {
				clean,
				intent: {
					type: "add_list_item",
					list: String(raw.list ?? "Shopping"),
					item: String(raw.item ?? "")
				}
			};
			case "add_event": return {
				clean,
				intent: {
					type: "add_event",
					title: String(raw.title ?? "Event"),
					startAt: typeof raw.startAt === "number" ? raw.startAt : Date.now() + 36e5,
					place: String(raw.place ?? "")
				}
			};
			case "message": return {
				clean,
				intent: {
					type: "message",
					name: String(raw.name ?? ""),
					body: String(raw.body ?? ""),
					kind: raw.kind === "email" ? "email" : "sms"
				}
			};
			default: return {
				clean,
				intent: null
			};
		}
	} catch {
		return {
			clean,
			intent: null
		};
	}
}
function canListen() {
	if (typeof window === "undefined") return false;
	return "SpeechRecognition" in window || "webkitSpeechRecognition" in window;
}
function makeRecog() {
	const C = window.SpeechRecognition ?? window.webkitSpeechRecognition;
	if (!C) return null;
	return new C();
}
function startListening(onText) {
	const rec = makeRecog();
	if (!rec) return () => {};
	rec.lang = typeof navigator !== "undefined" ? navigator.language : "en-US";
	rec.continuous = false;
	rec.interimResults = true;
	rec.onresult = (ev) => {
		const last = ev.results[Object.keys(ev.results).length - 1];
		if (!last) return;
		const alt = last[0];
		onText(alt?.transcript ?? "", Boolean(last.isFinal));
	};
	rec.onerror = () => {};
	rec.start();
	return () => {
		try {
			rec.abort();
		} catch {}
	};
}
function speak(text) {
	if (typeof window === "undefined") return;
	if (!("speechSynthesis" in window)) return;
	window.speechSynthesis.cancel();
	const u = new SpeechSynthesisUtterance(text);
	u.rate = 1.02;
	u.pitch = 1;
	u.lang = navigator.language || "en-US";
	window.speechSynthesis.speak(u);
}
function stopSpeaking() {
	if (typeof window === "undefined") return;
	if ("speechSynthesis" in window) window.speechSynthesis.cancel();
}
function beep() {
	if (typeof window === "undefined") return;
	try {
		const ctx = new AudioContext();
		const osc = ctx.createOscillator();
		const gain = ctx.createGain();
		osc.type = "sine";
		osc.frequency.value = 880;
		gain.gain.value = .05;
		osc.connect(gain);
		gain.connect(ctx.destination);
		osc.start();
		gain.gain.exponentialRampToValueAtTime(1e-4, ctx.currentTime + .6);
		osc.stop(ctx.currentTime + .65);
	} catch {}
}
async function notify(title, body) {
	if (typeof window === "undefined" || !("Notification" in window)) return;
	let perm = Notification.permission;
	if (perm === "default") try {
		perm = await Notification.requestPermission();
	} catch {
		return;
	}
	if (perm !== "granted") return;
	try {
		new Notification(title, { body });
	} catch {}
}
function vibrate(ms = 240) {
	if (typeof navigator !== "undefined" && navigator.vibrate) navigator.vibrate(ms);
}
var UNIT = {
	km: {
		family: "length",
		toBase: 1e3
	},
	kilometer: {
		family: "length",
		toBase: 1e3
	},
	kilometers: {
		family: "length",
		toBase: 1e3
	},
	m: {
		family: "length",
		toBase: 1
	},
	meter: {
		family: "length",
		toBase: 1
	},
	meters: {
		family: "length",
		toBase: 1
	},
	metre: {
		family: "length",
		toBase: 1
	},
	metres: {
		family: "length",
		toBase: 1
	},
	cm: {
		family: "length",
		toBase: .01
	},
	mm: {
		family: "length",
		toBase: .001
	},
	mile: {
		family: "length",
		toBase: 1609.344
	},
	miles: {
		family: "length",
		toBase: 1609.344
	},
	mi: {
		family: "length",
		toBase: 1609.344
	},
	yard: {
		family: "length",
		toBase: .9144
	},
	yards: {
		family: "length",
		toBase: .9144
	},
	ft: {
		family: "length",
		toBase: .3048
	},
	foot: {
		family: "length",
		toBase: .3048
	},
	feet: {
		family: "length",
		toBase: .3048
	},
	in: {
		family: "length",
		toBase: .0254
	},
	inch: {
		family: "length",
		toBase: .0254
	},
	inches: {
		family: "length",
		toBase: .0254
	},
	kg: {
		family: "mass",
		toBase: 1
	},
	kilogram: {
		family: "mass",
		toBase: 1
	},
	kilograms: {
		family: "mass",
		toBase: 1
	},
	g: {
		family: "mass",
		toBase: .001
	},
	gram: {
		family: "mass",
		toBase: .001
	},
	grams: {
		family: "mass",
		toBase: .001
	},
	lb: {
		family: "mass",
		toBase: .453592
	},
	lbs: {
		family: "mass",
		toBase: .453592
	},
	pound: {
		family: "mass",
		toBase: .453592
	},
	pounds: {
		family: "mass",
		toBase: .453592
	},
	oz: {
		family: "mass",
		toBase: .0283495
	},
	ounce: {
		family: "mass",
		toBase: .0283495
	},
	ounces: {
		family: "mass",
		toBase: .0283495
	},
	l: {
		family: "volume",
		toBase: 1
	},
	liter: {
		family: "volume",
		toBase: 1
	},
	liters: {
		family: "volume",
		toBase: 1
	},
	litre: {
		family: "volume",
		toBase: 1
	},
	litres: {
		family: "volume",
		toBase: 1
	},
	ml: {
		family: "volume",
		toBase: .001
	},
	gal: {
		family: "volume",
		toBase: 3.78541
	},
	gallon: {
		family: "volume",
		toBase: 3.78541
	},
	gallons: {
		family: "volume",
		toBase: 3.78541
	},
	cup: {
		family: "volume",
		toBase: .236588
	},
	cups: {
		family: "volume",
		toBase: .236588
	},
	c: {
		family: "temp",
		toBase: 1
	},
	f: {
		family: "temp",
		toBase: 1
	},
	celsius: {
		family: "temp",
		toBase: 1
	},
	fahrenheit: {
		family: "temp",
		toBase: 1
	}
};
function convertUnits(value, fromRaw, toRaw) {
	const from = normalizeUnit(fromRaw);
	const to = normalizeUnit(toRaw);
	const a = UNIT[from];
	const b = UNIT[to];
	if (!a || !b || a.family !== b.family) return null;
	if (a.family === "temp") {
		const c = from.startsWith("f") ? (value - 32) * 5 / 9 : value;
		return `${trimNum(to.startsWith("f") ? c * 9 / 5 + 32 : c)}°${to.startsWith("f") ? "F" : "C"}`;
	}
	return `${trimNum(value * a.toBase / b.toBase)} ${toRaw}`;
}
function normalizeUnit(u) {
	return u.toLowerCase().replace(/[^a-z]/g, "");
}
function parseConvert(text) {
	const m = text.toLowerCase().match(/(?:convert\s+)?(-?\d+(?:\.\d+)?)\s*([a-z°]+)\s+(?:to|in|into)\s+([a-z°]+)/i);
	if (!m) return null;
	return {
		value: Number(m[1]),
		from: m[2] ?? "",
		to: m[3] ?? ""
	};
}
var OPS = /* @__PURE__ */ new Set([
	"+",
	"-",
	"*",
	"/",
	"%",
	"^",
	"(",
	")"
]);
function evalMath(expression) {
	const raw = expression.toLowerCase().replace(/what(?:'s| is)|calculate|compute|equals?/g, " ").replace(/plus/g, "+").replace(/minus/g, "-").replace(/times|multiplied by|x/g, "*").replace(/divided by|over/g, "/").replace(/to the power of/g, "^").trim();
	const tip = raw.match(/tip\s+(\d+(?:\.\d+)?)\s*%\s*(?:on|of|for)?\s*(\d+(?:\.\d+)?)/);
	if (tip) {
		const pct = Number(tip[1]);
		const bill = Number(tip[2]);
		const amount = bill * pct / 100;
		return `Tip ${trimNum(amount)} · total ${trimNum(bill + amount)}`;
	}
	const split = raw.match(/split\s+(\d+(?:\.\d+)?)\s+(?:between|across|for|by)\s+(\d+)/);
	if (split) {
		const total = Number(split[1]);
		const n = Number(split[2]);
		if (n === 0) return null;
		return `${trimNum(total / n)} each`;
	}
	const pctOf = raw.match(/(\d+(?:\.\d+)?)\s*(?:%|percent)\s*(?:of)\s*(-?\d+(?:\.\d+)?)/);
	if (pctOf) return trimNum(Number(pctOf[1]) / 100 * Number(pctOf[2]));
	const ofPct = raw.match(/(-?\d+(?:\.\d+)?)\s*(?:%|percent)/);
	if (ofPct && !/[+\-*/]/.test(raw.replace(ofPct[0], ""))) return null;
	const expr = raw.replace(/[^0-9+\-*/%^().\s]/g, "");
	if (!expr.trim()) return null;
	try {
		const result = evaluate(expr);
		if (!Number.isFinite(result)) return null;
		return trimNum(result);
	} catch {
		return null;
	}
}
function evaluate(input) {
	const rpn = toRpn(tokenize(input));
	const stack = [];
	for (const tok of rpn) {
		if (typeof tok === "number") {
			stack.push(tok);
			continue;
		}
		const b = stack.pop();
		const a = stack.pop();
		if (a == null || b == null) throw new Error("bad expr");
		switch (tok) {
			case "+":
				stack.push(a + b);
				break;
			case "-":
				stack.push(a - b);
				break;
			case "*":
				stack.push(a * b);
				break;
			case "/":
				if (b === 0) throw new Error("div0");
				stack.push(a / b);
				break;
			case "%":
				stack.push(a % b);
				break;
			case "^":
				stack.push(a ** b);
				break;
			default: throw new Error("op");
		}
	}
	if (stack.length !== 1) throw new Error("stack");
	return stack[0];
}
function tokenize(input) {
	const out = [];
	let i = 0;
	while (i < input.length) {
		const ch = input[i];
		if (ch === " ") {
			i += 1;
			continue;
		}
		if (ch === "-" && (out.length === 0 || typeof out[out.length - 1] === "string" && out[out.length - 1] !== ")")) {
			i += 1;
			let n = "";
			while (i < input.length && /[0-9.]/.test(input[i])) {
				n += input[i];
				i += 1;
			}
			if (!n) throw new Error("num");
			out.push(-Number(n));
			continue;
		}
		if (/[0-9.]/.test(ch)) {
			let n = "";
			while (i < input.length && /[0-9.]/.test(input[i])) {
				n += input[i];
				i += 1;
			}
			out.push(Number(n));
			continue;
		}
		if (OPS.has(ch)) {
			out.push(ch);
			i += 1;
			continue;
		}
		throw new Error("tok");
	}
	return out;
}
function toRpn(tokens) {
	const prec = {
		"+": 1,
		"-": 1,
		"*": 2,
		"/": 2,
		"%": 2,
		"^": 3
	};
	const out = [];
	const ops = [];
	for (const tok of tokens) {
		if (typeof tok === "number") {
			out.push(tok);
			continue;
		}
		if (tok === "(") {
			ops.push(tok);
			continue;
		}
		if (tok === ")") {
			while (ops.length && ops[ops.length - 1] !== "(") out.push(ops.pop());
			ops.pop();
			continue;
		}
		while (ops.length && ops[ops.length - 1] !== "(" && (prec[ops[ops.length - 1]] ?? 0) >= (prec[tok] ?? 0)) out.push(ops.pop());
		ops.push(tok);
	}
	while (ops.length) out.push(ops.pop());
	return out;
}
function trimNum(n) {
	const r = Math.round(n * 1e3) / 1e3;
	return Number.isInteger(r) ? String(r) : String(r);
}
function looksLikeMath(text) {
	const t = text.toLowerCase();
	if (/\b(percent|%|plus|minus|times|divided|tip|split)\b/.test(t)) return true;
	if (/^\s*[\d(].*[+\-*/^x×÷].*\d/.test(t)) return true;
	if (/\bwhat(?:'s| is)\s+\d/.test(t) && /[+\-*/%]|percent/.test(t)) return true;
	return false;
}
var OPEN_MAP = [
	{
		keys: [
			"task",
			"todo",
			"to-do",
			"to do"
		],
		module: "tasks"
	},
	{
		keys: [
			"note",
			"notes",
			"memo"
		],
		module: "notes"
	},
	{
		keys: ["reminder", "reminders"],
		module: "reminders"
	},
	{
		keys: [
			"calendar",
			"schedule",
			"agenda",
			"event"
		],
		module: "calendar"
	},
	{
		keys: ["timer", "stopwatch"],
		module: "timer"
	},
	{
		keys: [
			"list",
			"lists",
			"shopping",
			"grocer"
		],
		module: "lists"
	},
	{
		keys: [
			"contact",
			"people",
			"phonebook",
			"address book"
		],
		module: "people"
	},
	{
		keys: [
			"draft",
			"message",
			"sms",
			"email"
		],
		module: "drafts"
	},
	{
		keys: ["focus", "pomodoro"],
		module: "focus"
	},
	{
		keys: [
			"calc",
			"calculator",
			"convert"
		],
		module: "calc"
	},
	{
		keys: ["journal", "diary"],
		module: "journal"
	},
	{
		keys: ["setting", "preference"],
		module: "settings"
	},
	{
		keys: [
			"chat",
			"talk",
			"conversation",
			"history"
		],
		module: "talk"
	},
	{
		keys: ["home", "start"],
		module: "home"
	}
];
function norm(s) {
	return s.toLowerCase().replace(/[’]/g, "'").replace(/\s+/g, " ").trim();
}
function lead(t, re) {
	return t.replace(re, "").replace(/^[\s,.:;-]+/, "").trim();
}
function titleCaseList(name) {
	const n = name.trim();
	if (!n) return "Shopping";
	return n.replace(/\b\w/g, (c) => c.toUpperCase());
}
function matchContact(name, contacts) {
	const q = name.toLowerCase();
	return contacts.find((c) => c.name.toLowerCase() === q || c.name.toLowerCase().startsWith(q) || c.name.toLowerCase().includes(q));
}
function matchList(name, lists) {
	const q = name.toLowerCase();
	return lists.find((l) => l.name.toLowerCase() === q || l.name.toLowerCase().includes(q) || q.includes(l.name.toLowerCase()));
}
function parseUtterance(input, ctx) {
	const original = input.trim();
	const t = norm(original);
	if (!t) return {
		type: "unknown",
		text: original
	};
	if (/^(help|what can you do|commands|how do you work)\b/.test(t)) return { type: "help" };
	if (/^(hi|hello|hey|yo|good (morning|afternoon|evening|night)|what's up|howdy)\b/.test(t) && t.split(" ").length <= 4) return { type: "greet" };
	if (/\b(what's on( my)? (today|plate|day|calendar|agenda)|brief( me|ing)?|today'?s (plan|agenda|brief)|what do i have)\b/.test(t)) return { type: "briefing" };
	if (/^(think|ask grok|research)\b/.test(t) || t.startsWith("think:") || t.startsWith("think ")) return {
		type: "think",
		prompt: lead(original, /^(think:|think|ask grok|research)\s*/i) || original
	};
	const open = t.match(/^(open|show|go to|launch|take me to)\s+(.+)$/);
	if (open) {
		const rest = open[2] ?? "";
		for (const row of OPEN_MAP) if (row.keys.some((k) => rest.includes(k))) return {
			type: "open",
			module: row.module
		};
	}
	if (/\b(stop|cancel|clear|kill)\s+(the\s+)?(timer|focus)\b/.test(t) || /^stop timer\b/.test(t)) {
		if (t.includes("focus")) return { type: "stop_focus" };
		return { type: "cancel_timer" };
	}
	if (/\b(stop|end|cancel)\s+(the\s+)?(focus|pomodoro)\b/.test(t) || /^stop focus\b/.test(t)) return { type: "stop_focus" };
	if (/\b(start|begin|run)\s+(a\s+)?(\d+\s+minute\s+)?(focus|pomodoro)/.test(t) || /^(focus|pomodoro)\b/.test(t)) {
		const dur = parseDurationMs(t);
		return {
			type: "start_focus",
			minutes: (dur ? Math.round(dur / 6e4) : 25) || 25
		};
	}
	if (/\b(timer|countdown|stopwatch)\b/.test(t) || /^(time|time me)\b/.test(t) || /\bset (a |an )?timer\b/.test(t)) {
		const ms = parseDurationMs(t) ?? (/\bhour\b/.test(t) ? 36e5 : null);
		if (ms && ms > 0) return {
			type: "set_timer",
			ms,
			label: stripWhen(t.replace(/\b(set|start|begin|create|a|an|the|timer|countdown|for|please)\b/g, " ")) || "Timer"
		};
	}
	if (/\b(wake me|alarm)\b/.test(t)) {
		const when = parseWhen(t);
		const clock = parseClock(t);
		if (clock) {
			const label = stripWhen(t.replace(/\b(wake me|set|an?|alarm|for|at|to)\b/g, " ")) || "Alarm";
			return {
				type: "set_alarm",
				hour: clock.hour,
				minute: clock.minute,
				label
			};
		}
		if (when) return {
			type: "set_alarm",
			hour: when.getHours(),
			minute: when.getMinutes(),
			label: stripWhen(t.replace(/\b(wake me|set|an?|alarm|for|at|to)\b/g, " ")) || "Alarm"
		};
	}
	const conv = parseConvert(t);
	if (conv || /\bconvert\b/.test(t)) {
		if (conv) return {
			type: "convert",
			value: conv.value,
			from: conv.from,
			to: conv.to
		};
	}
	if (looksLikeMath(t) || /^(what(?:'s| is)|calculate|compute)\s+[\d(]/.test(t)) return {
		type: "calculate",
		expression: original
	};
	const call = t.match(/^(call|dial|ring)\s+(.+)$/);
	if (call) return {
		type: "call",
		name: (call[2] ?? "").trim()
	};
	const sms = t.match(/^(text|message|sms|whatsapp)\s+(\w+)(?:\s+(?:that|saying|:)\s+(.+))?$/);
	if (sms) return {
		type: "message",
		name: sms[2] ?? "",
		body: (sms[3] ?? "").trim(),
		kind: "sms"
	};
	const sms2 = t.match(/^(text|message|sms)\s+(.+?)\s+(that|saying|:)\s+(.+)$/);
	if (sms2) return {
		type: "message",
		name: sms2[2] ?? "",
		body: (sms2[4] ?? "").trim(),
		kind: "sms"
	};
	const em = t.match(/^e-?mail\s+(.+?)\s+(that|saying|:)\s+(.+)$/);
	if (em) return {
		type: "message",
		name: em[1] ?? "",
		body: (em[3] ?? "").trim(),
		kind: "email"
	};
	const addPerson = t.match(/^(add|save|create)\s+(contact|person)\s+(.+)$/);
	if (addPerson) {
		const rest = addPerson[3] ?? "";
		const phone = rest.match(/(\+?\d[\d\s.-]{6,}\d)/);
		const email = rest.match(/([\w.+-]+@[\w.-]+\.\w+)/);
		return {
			type: "add_contact",
			name: rest.replace(phone?.[0] ?? "", "").replace(email?.[0] ?? "", "").replace(/\b(phone|number|email|named?)\b/g, "").trim() || rest,
			phone: phone?.[1] ?? "",
			email: email?.[1] ?? ""
		};
	}
	const findP = t.match(/^(find|show|who is|lookup|look up)\s+(contact\s+)?(.+)$/);
	if (findP && matchContact(findP[3] ?? "", ctx.contacts)) return {
		type: "find_contact",
		name: findP[3] ?? ""
	};
	if (/\b(remind me|set a reminder|reminder to|ping me|don't forget)\b/.test(t)) {
		const when = parseWhen(t);
		let title = t.replace(/^(please\s+)?(remind me to|remind me|set a reminder to|set a reminder|reminder to|ping me to|don't forget to|don't forget)\s*/i, "").trim();
		title = stripWhen(title) || "Reminder";
		if (when) return {
			type: "add_reminder",
			title,
			at: when.getTime()
		};
		if (/\b(at|in|tomorrow|tonight|today|monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b/.test(t)) {
			const fallback = Date.now() + 36e5;
			return {
				type: "add_reminder",
				title,
				at: fallback
			};
		}
		return {
			type: "add_task",
			title,
			dueAt: null
		};
	}
	if (/\b(schedule|appointment|meeting|calendar event|add event|put on (my )?calendar)\b/.test(t)) {
		const when = parseWhen(t) ?? new Date(Date.now() + 36e5);
		let title = t.replace(/^(please\s+)?(schedule|add|create|put|book)\s+(an?\s+)?(appointment|meeting|event)?\s*(for|with)?\s*/i, "").replace(/\bon (my )?calendar\b/g, "").trim();
		title = stripWhen(title) || "Event";
		const placeM = t.match(/\bat\s+(?!(\d))([a-z0-9 .'-]{2,40})$/);
		return {
			type: "add_event",
			title,
			startAt: when.getTime(),
			place: placeM?.[2] ?? ""
		};
	}
	const addToList = t.match(/^(?:add|put|buy)\s+(.+?)\s+to(?:\s+my)?\s+(shopping(?: list)?|grocer(?:y|ies)(?: list)?|[\w ]+ list)$/);
	if (addToList) {
		const item = addToList[1] ?? "";
		let listName = addToList[2] ?? "shopping";
		listName = listName.replace(/\s+list$/, "");
		if (listName.startsWith("grocer")) listName = "Shopping";
		if (listName === "shopping") listName = "Shopping";
		return {
			type: "add_list_item",
			list: titleCaseList(listName),
			item
		};
	}
	if (/^(add|buy)\s+.+\s+to\s+/.test(t) === false && /^(add|buy)\s+.+$/.test(t) && /\b(milk|eggs|bread|rice|coffee|fruit|veg)\b/.test(t)) return {
		type: "add_list_item",
		list: "Shopping",
		item: t.replace(/^(add|buy)\s+/, "")
	};
	const newList = t.match(/^(create|new|make|start)\s+(a\s+)?(list)\s+(called |named )?(.+)$/);
	if (newList) return {
		type: "create_list",
		name: titleCaseList(newList[5] ?? "List")
	};
	if (ctx.lists.length) {
		const toExisting = t.match(/^(?:add|put)\s+(.+?)\s+to(?:\s+my)?\s+(.+)$/);
		if (toExisting) {
			const found = matchList(toExisting[2] ?? "", ctx.lists);
			if (found) return {
				type: "add_list_item",
				list: found.name,
				item: toExisting[1] ?? ""
			};
		}
	}
	if (/^(note|jot|memo|remember that|write down|capture)\b/.test(t)) {
		const body = lead(original, /^(please\s+)?(note down|note that|note:|note|jot down|jot|memo:|memo|remember that|write down|capture)\s*/i);
		const [first, ...rest] = body.split(/[:\-–—]/);
		if (rest.length) return {
			type: "add_note",
			title: (first ?? "Note").trim(),
			body: rest.join(":").trim()
		};
		return {
			type: "add_note",
			title: body.split(" ").slice(0, 6).join(" ") || "Note",
			body
		};
	}
	if (/^(journal|dear diary|today i)\b/.test(t)) return {
		type: "journal",
		body: lead(original, /^(journal:?|dear diary,?)\s*/i) || original
	};
	if (/\b(mark|complete|check off|tick|finish|done with)\b/.test(t) || /^(done|finish)\s+/.test(t)) {
		const q = t.replace(/^(please\s+)?(mark|complete|check off|tick|finish|done with|done)\s+/i, "").replace(/\b(as )?(done|complete|completed|finished)\b/g, "").replace(/\b(task|todo|item)\b/g, "").trim();
		if (q) return {
			type: "complete_task",
			query: q
		};
	}
	if (/^(show|list|what are)\s+(my )?(tasks|todos|to-dos|reminders)/.test(t) || t === "tasks" || t === "my tasks") {
		if (t.includes("reminder")) return {
			type: "open",
			module: "reminders"
		};
		return { type: "list_tasks" };
	}
	const search = t.match(/^(find|search|look for)\s+(notes? |tasks? )?(about |on |for )?(.+)$/);
	if (search) return {
		type: "search",
		query: search[4] ?? ""
	};
	if (/^(add|create|new)\s+(a\s+)?(task|todo|to-do)\b/.test(t) || /^todo\b/.test(t)) {
		let title = lead(original, /^(please\s+)?((add|create|new)\s+(a\s+)?(task|todo|to-do)|todo)\s*(to|:)?\s*/i);
		const when = parseWhen(t);
		title = stripWhen(title) || title;
		return {
			type: "add_task",
			title: title || "New task",
			dueAt: when ? when.getTime() : null
		};
	}
	if (/^(i need to|i have to|i must|i should)\b/.test(t)) {
		const title = lead(original, /^(i need to|i have to|i must|i should)\s*/i);
		const when = parseWhen(t);
		return {
			type: "add_task",
			title: stripWhen(title) || title,
			dueAt: when ? when.getTime() : null
		};
	}
	if (/^(add|create)\s+/.test(t) && !/\b(contact|person|list|event|note)\b/.test(t)) {
		const title = lead(original, /^(add|create)\s+(a\s+)?/i);
		const when = parseWhen(t);
		return {
			type: "add_task",
			title: stripWhen(title) || title,
			dueAt: when ? when.getTime() : null
		};
	}
	if (/\?$/.test(t) || /^(who|what|when|where|why|how|explain|write|draft|rewrite|summarize|translate)\b/.test(t)) return {
		type: "think",
		prompt: original
	};
	return {
		type: "unknown",
		text: original
	};
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function nid() {
	if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
	return `id_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}
var emptyStorage = {
	getItem: () => null,
	setItem: () => {},
	removeItem: () => {}
};
function findByName(items, q) {
	const n = q.toLowerCase().trim();
	return items.find((i) => i.name.toLowerCase() === n) ?? items.find((i) => i.name.toLowerCase().includes(n) || n.includes(i.name.toLowerCase()));
}
var useLumen = create()(persist((set, get) => ({
	hydrated: false,
	module: "home",
	settings: {
		name: "",
		voiceReplies: false,
		thinkOnline: false
	},
	tasks: [],
	notes: [],
	reminders: [],
	events: [],
	timers: [],
	alarms: [],
	lists: [{
		id: nid(),
		name: "Shopping",
		items: []
	}],
	contacts: [],
	drafts: [],
	journal: [],
	messages: [],
	lastResult: "",
	focus: null,
	now: Date.now(),
	setHydrated: (v) => set({ hydrated: v }),
	setModule: (m) => set({ module: m }),
	setNow: (n) => set({ now: n }),
	patchSettings: (p) => set({ settings: {
		...get().settings,
		...p
	} }),
	addTask: (title, dueAt) => {
		const task = {
			id: nid(),
			title,
			done: false,
			dueAt,
			createdAt: Date.now()
		};
		set({ tasks: [task, ...get().tasks] });
		return task;
	},
	toggleTask: (id) => set({ tasks: get().tasks.map((t) => t.id === id ? {
		...t,
		done: !t.done
	} : t) }),
	removeTask: (id) => set({ tasks: get().tasks.filter((t) => t.id !== id) }),
	completeTaskByQuery: (q) => {
		const n = q.toLowerCase();
		const hit = get().tasks.find((t) => !t.done && t.title.toLowerCase().includes(n));
		if (!hit) return null;
		set({ tasks: get().tasks.map((t) => t.id === hit.id ? {
			...t,
			done: true
		} : t) });
		return hit;
	},
	addNote: (title, body) => {
		const note = {
			id: nid(),
			title,
			body,
			createdAt: Date.now(),
			updatedAt: Date.now(),
			pinned: false
		};
		set({ notes: [note, ...get().notes] });
		return note;
	},
	removeNote: (id) => set({ notes: get().notes.filter((n) => n.id !== id) }),
	addReminder: (title, at) => {
		const rem = {
			id: nid(),
			title,
			at,
			done: false,
			notified: false
		};
		set({ reminders: [rem, ...get().reminders] });
		return rem;
	},
	toggleReminder: (id) => set({ reminders: get().reminders.map((r) => r.id === id ? {
		...r,
		done: !r.done
	} : r) }),
	markReminderNotified: (id) => set({ reminders: get().reminders.map((r) => r.id === id ? {
		...r,
		notified: true
	} : r) }),
	addEvent: (title, startAt, place) => {
		const ev = {
			id: nid(),
			title,
			startAt,
			place
		};
		set({ events: [ev, ...get().events] });
		return ev;
	},
	removeEvent: (id) => set({ events: get().events.filter((e) => e.id !== id) }),
	startTimer: (ms, label) => {
		const timer = {
			id: nid(),
			label,
			durationMs: ms,
			endsAt: Date.now() + ms,
			status: "running",
			remainingMs: ms
		};
		set({ timers: [timer, ...get().timers.filter((t) => t.status !== "done").slice(0, 4)] });
		return timer;
	},
	pauseTimer: (id) => set({ timers: get().timers.map((t) => t.id === id && t.status === "running" ? {
		...t,
		status: "paused",
		remainingMs: Math.max(0, t.endsAt - Date.now())
	} : t) }),
	resumeTimer: (id) => set({ timers: get().timers.map((t) => t.id === id && t.status === "paused" ? {
		...t,
		status: "running",
		endsAt: Date.now() + t.remainingMs
	} : t) }),
	cancelTimers: () => set({ timers: get().timers.map((t) => ({
		...t,
		status: "done"
	})) }),
	finishTimer: (id) => set({ timers: get().timers.map((t) => t.id === id ? {
		...t,
		status: "done",
		remainingMs: 0
	} : t) }),
	addAlarm: (hour, minute, label) => {
		const alarm = {
			id: nid(),
			hour,
			minute,
			label,
			enabled: true,
			lastFiredKey: ""
		};
		set({ alarms: [alarm, ...get().alarms] });
		return alarm;
	},
	toggleAlarm: (id) => set({ alarms: get().alarms.map((a) => a.id === id ? {
		...a,
		enabled: !a.enabled
	} : a) }),
	markAlarmFired: (id, key) => set({ alarms: get().alarms.map((a) => a.id === id ? {
		...a,
		lastFiredKey: key
	} : a) }),
	ensureList: (name) => {
		const existing = findByName(get().lists, name);
		if (existing) return existing;
		const list = {
			id: nid(),
			name,
			items: []
		};
		set({ lists: [...get().lists, list] });
		return list;
	},
	addListItem: (listName, item) => {
		let lists = get().lists;
		let list = findByName(lists, listName);
		if (!list) {
			list = {
				id: nid(),
				name: listName,
				items: []
			};
			lists = [...lists, list];
		}
		const next = lists.map((l) => l.id === list.id ? {
			...l,
			items: [...l.items, {
				id: nid(),
				text: item,
				done: false
			}]
		} : l);
		set({ lists: next });
		return {
			list: next.find((l) => l.id === list.id),
			item
		};
	},
	toggleListItem: (listId, itemId) => set({ lists: get().lists.map((l) => l.id === listId ? {
		...l,
		items: l.items.map((i) => i.id === itemId ? {
			...i,
			done: !i.done
		} : i)
	} : l) }),
	addContact: (name, phone, email) => {
		const c = {
			id: nid(),
			name,
			phone,
			email,
			note: ""
		};
		set({ contacts: [c, ...get().contacts] });
		return c;
	},
	removeContact: (id) => set({ contacts: get().contacts.filter((c) => c.id !== id) }),
	addDraft: (d) => {
		const draft = {
			...d,
			id: nid(),
			createdAt: Date.now()
		};
		set({ drafts: [draft, ...get().drafts] });
		return draft;
	},
	removeDraft: (id) => set({ drafts: get().drafts.filter((d) => d.id !== id) }),
	addJournal: (body) => {
		const e = {
			id: nid(),
			body,
			createdAt: Date.now()
		};
		set({ journal: [e, ...get().journal] });
		return e;
	},
	startFocus: (minutes) => set({ focus: {
		running: true,
		minutes,
		endsAt: Date.now() + minutes * 6e4
	} }),
	stopFocus: () => set({ focus: null }),
	pushMessage: (m) => set({ messages: [...get().messages, {
		...m,
		id: nid(),
		at: Date.now()
	}].slice(-80) }),
	replaceAll: (data) => set({ ...data }),
	execute: (intent) => executeIntent(intent, get, set),
	submit: (text) => {
		const s = get();
		s.pushMessage({
			role: "user",
			text
		});
		const intent = parseUtterance(text, {
			lists: s.lists,
			contacts: s.contacts,
			tasks: s.tasks
		});
		if (intent.type === "think" || intent.type === "unknown" && get().settings.thinkOnline) {
			set({
				lastResult: "Thinking…",
				module: "talk"
			});
			return {
				intent,
				result: {
					text: "Thinking…",
					open: "talk"
				}
			};
		}
		const result = executeIntent(intent, get, set);
		get().pushMessage({
			role: "lumen",
			text: result.text,
			open: result.open
		});
		set({
			lastResult: result.text,
			module: result.open ?? get().module
		});
		return {
			intent,
			result
		};
	}
}), {
	name: "lumen.v1",
	storage: createJSONStorage(() => typeof window === "undefined" ? emptyStorage : localStorage),
	partialize: (s) => ({
		settings: s.settings,
		tasks: s.tasks,
		notes: s.notes,
		reminders: s.reminders,
		events: s.events,
		timers: s.timers,
		alarms: s.alarms,
		lists: s.lists,
		contacts: s.contacts,
		drafts: s.drafts,
		journal: s.journal,
		messages: s.messages.slice(-40),
		focus: s.focus
	})
}));
function executeIntent(intent, get, _set) {
	const s = get();
	switch (intent.type) {
		case "help": return {
			text: "I work on this device. Try: set a timer for 5 minutes · remind me to call Maya at 7pm · add milk to shopping · note the gate code is 4411 · schedule dentist Friday at 3pm · call Sam · text Priya I will be late · what's 18% of 64 · convert 10 km to miles · start a 25 minute focus session · what's on today. Prefix with “think” for Grok when you have a connection.",
			open: "talk"
		};
		case "greet": return { text: `${composeBriefing(s)} What should we do?` };
		case "briefing": return {
			text: composeBriefing(s),
			open: "home"
		};
		case "open": return {
			text: `Opening ${intent.module}.`,
			open: intent.module
		};
		case "add_task": {
			s.addTask(intent.title, intent.dueAt);
			const when = intent.dueAt ? ` · due ${formatWhen(intent.dueAt)}` : "";
			return {
				text: `Task added: ${intent.title}${when}.`,
				open: "tasks"
			};
		}
		case "complete_task": {
			const hit = s.completeTaskByQuery(intent.query);
			if (!hit) return {
				text: `I could not find an open task matching “${intent.query}”.`,
				open: "tasks"
			};
			return {
				text: `Marked done: ${hit.title}.`,
				open: "tasks"
			};
		}
		case "list_tasks": {
			const open = s.tasks.filter((t) => !t.done);
			if (!open.length) return {
				text: "No open tasks.",
				open: "tasks"
			};
			return {
				text: `Open tasks: ${open.slice(0, 8).map((t) => t.title).join(" · ")}.`,
				open: "tasks"
			};
		}
		case "add_note":
			s.addNote(intent.title, intent.body);
			return {
				text: `Noted: ${intent.title}.`,
				open: "notes"
			};
		case "search": {
			const q = intent.query.toLowerCase();
			const notes = s.notes.filter((n) => `${n.title} ${n.body}`.toLowerCase().includes(q));
			const tasks = s.tasks.filter((t) => t.title.toLowerCase().includes(q));
			if (!notes.length && !tasks.length) return { text: `Nothing local matching “${intent.query}”.` };
			return {
				text: `Found ${[notes.length ? `${notes.length} note${notes.length === 1 ? "" : "s"}` : "", tasks.length ? `${tasks.length} task${tasks.length === 1 ? "" : "s"}` : ""].filter(Boolean).join(" and ")}.`,
				open: notes.length ? "notes" : "tasks"
			};
		}
		case "add_reminder":
			s.addReminder(intent.title, intent.at);
			return {
				text: `Reminder set: ${intent.title} · ${formatWhen(intent.at)}.`,
				open: "reminders"
			};
		case "add_event":
			s.addEvent(intent.title, intent.startAt, intent.place);
			return {
				text: `On the calendar: ${intent.title} · ${formatWhen(intent.startAt)}${intent.place ? ` · ${intent.place}` : ""}.`,
				open: "calendar"
			};
		case "set_timer":
			s.startTimer(intent.ms, intent.label);
			return {
				text: `Timer running · ${msToClock(intent.ms)}.`,
				open: "timer"
			};
		case "cancel_timer":
			s.cancelTimers();
			return {
				text: "Timer cleared.",
				open: "timer"
			};
		case "set_alarm":
			s.addAlarm(intent.hour, intent.minute, intent.label);
			return {
				text: `Alarm for ${formatClock(intent.hour, intent.minute)}.`,
				open: "timer"
			};
		case "add_list_item":
			s.addListItem(intent.list, intent.item);
			return {
				text: `Added ${intent.item} to ${intent.list}.`,
				open: "lists"
			};
		case "create_list":
			s.ensureList(intent.name);
			return {
				text: `List ready: ${intent.name}.`,
				open: "lists"
			};
		case "call": {
			const c = findByName(s.contacts, intent.name);
			if (!c) {
				s.addContact(intent.name, "", "");
				return {
					text: `I do not have a number for ${intent.name}. Saved a contact — add a phone in People, then tell me to call again.`,
					open: "people"
				};
			}
			if (!c.phone) return {
				text: `${c.name} has no number yet.`,
				open: "people"
			};
			return {
				text: `Calling ${c.name}.`,
				open: "people",
				href: `tel:${c.phone.replace(/\s/g, "")}`
			};
		}
		case "message": {
			const c = findByName(s.contacts, intent.name);
			const addr = intent.kind === "email" ? c?.email ?? "" : c?.phone ?? "";
			s.addDraft({
				kind: intent.kind,
				toName: c?.name ?? intent.name,
				toAddress: addr,
				subject: "",
				body: intent.body
			});
			if (!addr) return {
				text: `Draft saved for ${c?.name ?? intent.name}, but I still need a ${intent.kind === "email" ? "email" : "number"}.`,
				open: "drafts"
			};
			const href = intent.kind === "email" ? `mailto:${addr}?body=${encodeURIComponent(intent.body)}` : `sms:${addr.replace(/\s/g, "")}?body=${encodeURIComponent(intent.body)}`;
			return {
				text: `Draft ready for ${c?.name ?? intent.name}.`,
				open: "drafts",
				href
			};
		}
		case "add_contact":
			s.addContact(intent.name, intent.phone, intent.email);
			return {
				text: `Saved ${intent.name}.`,
				open: "people"
			};
		case "find_contact": {
			const c = findByName(s.contacts, intent.name);
			if (!c) return {
				text: `No one named ${intent.name} yet.`,
				open: "people"
			};
			return {
				text: `${c.name}${c.phone ? ` · ${c.phone}` : ""}${c.email ? ` · ${c.email}` : ""}.`,
				open: "people"
			};
		}
		case "start_focus":
			s.startFocus(intent.minutes);
			return {
				text: `Focus · ${intent.minutes} minutes. I will keep the board quiet.`,
				open: "focus"
			};
		case "stop_focus":
			s.stopFocus();
			return {
				text: "Focus session ended.",
				open: "focus"
			};
		case "calculate": {
			const out = evalMath(intent.expression);
			if (!out) return {
				text: "I could not read that calculation.",
				open: "calc"
			};
			return {
				text: out,
				open: "calc"
			};
		}
		case "convert": {
			const out = convertUnits(intent.value, intent.from, intent.to);
			if (!out) return {
				text: "I cannot convert those units on device.",
				open: "calc"
			};
			return {
				text: `${intent.value} ${intent.from} is ${out}.`,
				open: "calc"
			};
		}
		case "journal":
			s.addJournal(intent.body);
			return {
				text: "Written in the journal.",
				open: "journal"
			};
		case "think": return {
			text: intent.prompt,
			open: "talk"
		};
		case "unknown": return {
			text: "I stay on this device, so I need a clear action. Try a timer, reminder, task, note, list, or “what's on today”. Prefix with “think” for Grok.",
			open: "talk"
		};
	}
}
function exportPayload() {
	const s = useLumen.getState();
	return {
		settings: s.settings,
		tasks: s.tasks,
		notes: s.notes,
		reminders: s.reminders,
		events: s.events,
		lists: s.lists,
		contacts: s.contacts,
		drafts: s.drafts,
		journal: s.journal,
		alarms: s.alarms
	};
}
function Badge({ className, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center rounded-full bg-card-2 px-2.5 py-1 text-xs font-medium text-muted", className),
		children
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium transition-[opacity,transform,background-color,color,box-shadow] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/70 disabled:pointer-events-none disabled:opacity-40 active:not-disabled:scale-[0.96] [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground shadow-[var(--shadow-border)] hover:opacity-90",
			secondary: "bg-card text-foreground shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]",
			ghost: "bg-transparent text-foreground hover:bg-card",
			outline: "bg-transparent text-foreground shadow-[var(--shadow-border)] hover:bg-card",
			danger: "bg-danger text-foreground hover:opacity-90"
		},
		size: {
			default: "h-11 rounded-md px-4 text-sm",
			sm: "h-9 rounded-sm px-3 text-sm",
			lg: "h-12 rounded-lg px-5 text-base",
			icon: "size-11 rounded-md",
			pill: "h-11 rounded-full px-4 text-sm"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var Input = import_react.forwardRef(({ className, type, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
	type,
	ref,
	className: cn("flex h-11 w-full rounded-md bg-card px-3 text-base text-foreground shadow-[var(--shadow-border)] placeholder:text-subtle", "transition-[box-shadow] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/70", "disabled:cursor-not-allowed disabled:opacity-40", className),
	...props
}));
Input.displayName = "Input";
function Switch({ checked, onCheckedChange, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "flex min-h-11 items-center justify-between gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-sm text-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch$1, {
			checked,
			onCheckedChange,
			className: cn("relative h-6 w-10 rounded-full bg-card-2 shadow-[var(--shadow-border)] transition-colors duration-150", "data-[state=checked]:bg-primary"),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchThumb, { className: "block size-5 translate-x-0.5 rounded-full bg-foreground transition-transform duration-150 data-[state=checked]:translate-x-[18px] data-[state=checked]:bg-primary-foreground" })
		})]
	});
}
var Textarea = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
	ref,
	className: cn("flex min-h-28 w-full rounded-lg bg-card px-3 py-3 text-base text-foreground shadow-[var(--shadow-border)] placeholder:text-subtle", "transition-[box-shadow] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/70", className),
	...props
}));
Textarea.displayName = "Textarea";
var TITLES = {
	talk: "Talk",
	tasks: "Tasks",
	notes: "Notes",
	reminders: "Reminders",
	calendar: "Calendar",
	timer: "Time",
	lists: "Lists",
	people: "People",
	drafts: "Drafts",
	focus: "Focus",
	calc: "Numbers",
	journal: "Journal",
	settings: "Settings"
};
function ModuleFrame({ module, onBack }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "flex min-h-0 flex-1 flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "flex shrink-0 items-center gap-2 px-3 pt-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "icon",
				onClick: onBack,
				"aria-label": "Back",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl tracking-tight",
				children: TITLES[module]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-h-0 flex-1 overflow-y-auto px-4 pb-4 pt-3",
			children: [
				module === "talk" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TalkPanel, {}),
				module === "tasks" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TasksPanel, {}),
				module === "notes" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotesPanel, {}),
				module === "reminders" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RemindersPanel, {}),
				module === "calendar" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarPanel, {}),
				module === "timer" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TimerPanel, {}),
				module === "lists" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListsPanel, {}),
				module === "people" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PeoplePanel, {}),
				module === "drafts" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DraftsPanel, {}),
				module === "focus" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FocusPanel, {}),
				module === "calc" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalcPanel, {}),
				module === "journal" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(JournalPanel, {}),
				module === "settings" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsPanel, {})
			]
		})]
	});
}
function FieldRow({ onSubmit, placeholder }) {
	const [v, setV] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "mb-4 flex gap-2",
		onSubmit: (e) => {
			e.preventDefault();
			const t = v.trim();
			if (!t) return;
			onSubmit(t);
			setV("");
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
			value: v,
			onChange: (e) => setV(e.target.value),
			placeholder
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			type: "submit",
			size: "icon",
			"aria-label": "Add",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" })
		})]
	});
}
function Empty({ text }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "py-10 text-center text-sm text-muted",
		children: text
	});
}
function TalkPanel() {
	const messages = useLumen((s) => s.messages);
	if (!messages.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: "Nothing in the log yet. Speak from the dock below." });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
		className: "flex flex-col gap-3",
		children: messages.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
			className: cn("max-w-[92%] rounded-xl px-3.5 py-2.5 text-sm leading-relaxed", m.role === "user" ? "ml-auto bg-primary text-primary-foreground" : "bg-card shadow-[var(--shadow-border)] text-foreground"),
			children: m.text
		}, m.id))
	});
}
function TasksPanel() {
	const tasks = useLumen((s) => s.tasks);
	const addTask = useLumen((s) => s.addTask);
	const toggleTask = useLumen((s) => s.toggleTask);
	const removeTask = useLumen((s) => s.removeTask);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldRow, {
		placeholder: "Add a task",
		onSubmit: (t) => addTask(t, null)
	}), !tasks.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: "No tasks. Tell Lumen “add buy groceries”." }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "flex flex-col gap-2",
		children: tasks.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "flex items-center gap-3 rounded-xl bg-card px-3 py-2.5 shadow-[var(--shadow-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => toggleTask(t.id),
					className: cn("flex size-7 shrink-0 items-center justify-center rounded-full shadow-[var(--shadow-border)]", t.done ? "bg-success text-background" : "bg-card-2 text-muted"),
					"aria-label": t.done ? "Mark open" : "Mark done",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: cn("text-sm", t.done && "text-muted line-through"),
						children: t.title
					}), t.dueAt ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: formatWhen(t.dueAt)
					}) : null]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "size-11 text-muted",
					onClick: () => removeTask(t.id),
					"aria-label": "Delete",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "mx-auto size-4" })
				})
			]
		}, t.id))
	})] });
}
function NotesPanel() {
	const notes = useLumen((s) => s.notes);
	const addNote = useLumen((s) => s.addNote);
	const removeNote = useLumen((s) => s.removeNote);
	const [body, setBody] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "mb-4 flex flex-col gap-2",
		onSubmit: (e) => {
			e.preventDefault();
			const t = body.trim();
			if (!t) return;
			addNote(t.split(" ").slice(0, 6).join(" "), t);
			setBody("");
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
			value: body,
			onChange: (e) => setBody(e.target.value),
			placeholder: "A note to keep on this device"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			type: "submit",
			className: "self-end",
			children: "Save note"
		})]
	}), !notes.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: "No notes yet. “Note the wifi is harbor-guest”." }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "flex flex-col gap-2",
		children: notes.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "rounded-xl bg-card p-4 shadow-[var(--shadow-border)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-medium",
					children: n.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "size-11 text-muted",
					onClick: () => removeNote(n.id),
					"aria-label": "Delete",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "mx-auto size-4" })
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 whitespace-pre-wrap text-sm text-muted",
				children: n.body
			})]
		}, n.id))
	})] });
}
function RemindersPanel() {
	const reminders = useLumen((s) => s.reminders);
	const toggleReminder = useLumen((s) => s.toggleReminder);
	const addReminder = useLumen((s) => s.addReminder);
	const sorted = (0, import_react.useMemo)(() => [...reminders].sort((a, b) => a.at - b.at), [reminders]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldRow, {
		placeholder: "Title — uses +1 hour if no time",
		onSubmit: (t) => addReminder(t, Date.now() + 36e5)
	}), !sorted.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: "No reminders. “Remind me to stretch at 7pm”." }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "flex flex-col gap-2",
		children: sorted.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "flex items-center gap-3 rounded-xl bg-card px-3 py-3 shadow-[var(--shadow-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "size-4 text-muted" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: cn("text-sm", r.done && "text-muted line-through"),
						children: r.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-xs tabular-nums text-muted",
						children: formatWhen(r.at)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: r.done ? "secondary" : "outline",
					onClick: () => toggleReminder(r.id),
					children: r.done ? "Open" : "Done"
				})
			]
		}, r.id))
	})] });
}
function CalendarPanel() {
	const events = useLumen((s) => s.events);
	const addEvent = useLumen((s) => s.addEvent);
	const removeEvent = useLumen((s) => s.removeEvent);
	const sorted = (0, import_react.useMemo)(() => [...events].sort((a, b) => a.startAt - b.startAt), [events]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldRow, {
		placeholder: "New event in one hour",
		onSubmit: (t) => addEvent(t, Date.now() + 36e5, "")
	}), !sorted.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: "Calendar is empty. “Schedule dentist Friday at 3pm”." }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "flex flex-col gap-2",
		children: sorted.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "flex items-start gap-3 rounded-xl bg-card p-4 shadow-[var(--shadow-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "mt-0.5 size-4 text-muted" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm",
							children: e.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-xs tabular-nums text-muted",
							children: formatWhen(e.startAt)
						}),
						e.place ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: e.place
						}) : null
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "size-11 text-muted",
					onClick: () => removeEvent(e.id),
					"aria-label": "Delete",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "mx-auto size-4" })
				})
			]
		}, e.id))
	})] });
}
function TimerPanel() {
	const timers = useLumen((s) => s.timers);
	const alarms = useLumen((s) => s.alarms);
	const now = useLumen((s) => s.now);
	const startTimer = useLumen((s) => s.startTimer);
	const pauseTimer = useLumen((s) => s.pauseTimer);
	const resumeTimer = useLumen((s) => s.resumeTimer);
	const cancelTimers = useLumen((s) => s.cancelTimers);
	const addAlarm = useLumen((s) => s.addAlarm);
	const toggleAlarm = useLumen((s) => s.toggleAlarm);
	const live = timers.filter((t) => t.status !== "done");
	const [alarm, setAlarm] = (0, import_react.useState)("07:00");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 text-xs font-medium uppercase tracking-wide text-muted",
				children: "Timers"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex flex-wrap gap-2",
				children: [[
					1,
					5,
					10,
					25
				].map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "secondary",
					size: "sm",
					onClick: () => startTimer(m * 6e4, `${m} min`),
					children: [m, " min"]
				}, m)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					size: "sm",
					onClick: cancelTimers,
					children: "Clear"
				})]
			}),
			!live.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "No running timer."
			}) : live.map((t) => {
				const left = t.status === "running" ? t.endsAt - now : t.remainingMs;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-2 rounded-xl bg-card p-4 shadow-[var(--shadow-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-3xl tabular-nums tracking-tight",
							children: msToClock(left)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: t.label
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 flex gap-2",
							children: t.status === "running" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "secondary",
								onClick: () => pauseTimer(t.id),
								children: "Pause"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								onClick: () => resumeTimer(t.id),
								children: "Resume"
							})
						})
					]
				}, t.id);
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 text-xs font-medium uppercase tracking-wide text-muted",
				children: "Alarms"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mb-3 flex gap-2",
				onSubmit: (e) => {
					e.preventDefault();
					const [h, m] = alarm.split(":").map(Number);
					addAlarm(h ?? 7, m ?? 0, "Alarm");
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "time",
					value: alarm,
					onChange: (e) => setAlarm(e.target.value)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					children: "Add"
				})]
			}),
			!alarms.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "No alarms. “Wake me at 6:30”."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-2",
				children: alarms.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center justify-between gap-3 rounded-xl bg-card px-3 py-2 shadow-[var(--shadow-border)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex min-w-0 items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-4 shrink-0 text-muted" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono tabular-nums",
								children: [
									String(a.hour).padStart(2, "0"),
									":",
									String(a.minute).padStart(2, "0")
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate text-sm text-muted",
								children: a.label
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: a.enabled ? "default" : "secondary",
						onClick: () => toggleAlarm(a.id),
						children: a.enabled ? "On" : "Off"
					})]
				}, a.id))
			})
		] })]
	});
}
function ListsPanel() {
	const lists = useLumen((s) => s.lists);
	const addListItem = useLumen((s) => s.addListItem);
	const toggleListItem = useLumen((s) => s.toggleListItem);
	const ensureList = useLumen((s) => s.ensureList);
	const [active, setActive] = (0, import_react.useState)(lists[0]?.id ?? "");
	const list = lists.find((l) => l.id === active) ?? lists[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-3 flex flex-wrap gap-2",
		children: [lists.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "sm",
			variant: l.id === list?.id ? "default" : "secondary",
			onClick: () => setActive(l.id),
			children: l.name
		}, l.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "sm",
			variant: "outline",
			onClick: () => ensureList(`List ${lists.length + 1}`),
			children: "New list"
		})]
	}), list ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldRow, {
		placeholder: `Add to ${list.name}`,
		onSubmit: (t) => addListItem(list.name, t)
	}), !list.items.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: `Nothing on ${list.name}. “Add milk to shopping”.` }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "flex flex-col gap-2",
		children: list.items.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => toggleListItem(list.id, i.id),
			className: "flex min-h-11 w-full items-center gap-3 rounded-xl bg-card px-3 text-left shadow-[var(--shadow-border)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: cn("flex size-5 items-center justify-center rounded-full shadow-[var(--shadow-border)]", i.done ? "bg-success" : "bg-card-2"),
				children: i.done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3 text-background" }) : null
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: cn("text-sm", i.done && "text-muted line-through"),
				children: i.text
			})]
		}) }, i.id))
	})] }) : null] });
}
function PeoplePanel() {
	const contacts = useLumen((s) => s.contacts);
	const addContact = useLumen((s) => s.addContact);
	const removeContact = useLumen((s) => s.removeContact);
	const [name, setName] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "mb-4 grid gap-2",
		onSubmit: (e) => {
			e.preventDefault();
			if (!name.trim()) return;
			addContact(name.trim(), phone.trim(), email.trim());
			setName("");
			setPhone("");
			setEmail("");
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: name,
				onChange: (e) => setName(e.target.value),
				placeholder: "Name"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: phone,
				onChange: (e) => setPhone(e.target.value),
				placeholder: "Phone",
				inputMode: "tel"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: email,
				onChange: (e) => setEmail(e.target.value),
				placeholder: "Email",
				inputMode: "email"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				children: "Save person"
			})
		]
	}), !contacts.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: "No people yet. “Add contact Maya 5550100”." }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "flex flex-col gap-2",
		children: contacts.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "rounded-xl bg-card p-4 shadow-[var(--shadow-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, { className: "size-4 text-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: c.name
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "size-11 text-muted",
						onClick: () => removeContact(c.id),
						"aria-label": "Delete",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "mx-auto size-4" })
					})]
				}),
				c.phone ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 font-mono text-sm text-muted",
					children: c.phone
				}) : null,
				c.email ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: c.email
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap gap-2",
					children: [
						c.phone ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: `tel:${c.phone.replace(/\s/g, "")}`,
								children: "Call"
							})
						}) : null,
						c.phone ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "secondary",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: `sms:${c.phone.replace(/\s/g, "")}`,
								children: "Text"
							})
						}) : null,
						c.email ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "outline",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: `mailto:${c.email}`,
								children: "Email"
							})
						}) : null
					]
				})
			]
		}, c.id))
	})] });
}
function DraftsPanel() {
	const drafts = useLumen((s) => s.drafts);
	const removeDraft = useLumen((s) => s.removeDraft);
	if (!drafts.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: "No drafts. “Text Sam I will be late”." });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "flex flex-col gap-2",
		children: drafts.map((d) => {
			const href = d.kind === "email" ? `mailto:${d.toAddress}?subject=${encodeURIComponent(d.subject)}&body=${encodeURIComponent(d.body)}` : `sms:${d.toAddress.replace(/\s/g, "")}?body=${encodeURIComponent(d.body)}`;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "rounded-xl bg-card p-4 shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-wide text-muted",
						children: d.kind === "email" ? "Email" : "Message"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-medium",
						children: d.toName
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 whitespace-pre-wrap text-sm text-muted",
						children: d.body || "Empty body"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex gap-2",
						children: [d.toAddress ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href,
								children: "Send"
							})
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-warn",
							children: "Missing address"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "ghost",
							onClick: () => removeDraft(d.id),
							children: "Discard"
						})]
					})
				]
			}, d.id);
		})
	});
}
function FocusPanel() {
	const focus = useLumen((s) => s.focus);
	const now = useLumen((s) => s.now);
	const startFocus = useLumen((s) => s.startFocus);
	const stopFocus = useLumen((s) => s.stopFocus);
	const left = focus?.running ? focus.endsAt - now : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center py-8 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-5xl tabular-nums tracking-tight",
				children: focus?.running ? msToClock(left) : "25:00"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: focus?.running ? "Stay with the work." : "A quiet 25 minutes."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 flex gap-2",
				children: focus?.running ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: stopFocus,
					children: "End session"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => startFocus(25),
					children: "Start 25"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					onClick: () => startFocus(50),
					children: "Start 50"
				})] })
			})
		]
	});
}
function CalcPanel() {
	const [expr, setExpr] = (0, import_react.useState)("");
	const [out, setOut] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: expr,
				onChange: (e) => setExpr(e.target.value),
				placeholder: "18% of 64 · 10 km to miles · 12 * 8",
				onKeyDown: (e) => {
					if (e.key === "Enter") {
						const conv = expr.match(/(-?\d+(?:\.\d+)?)\s*([a-z°]+)\s+to\s+([a-z°]+)/i);
						if (conv) {
							setOut(convertUnits(Number(conv[1]), conv[2] ?? "", conv[3] ?? "") ?? "Cannot convert");
							return;
						}
						setOut(evalMath(expr) ?? "Cannot read that");
					}
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => {
					const conv = expr.match(/(-?\d+(?:\.\d+)?)\s*([a-z°]+)\s+to\s+([a-z°]+)/i);
					if (conv) {
						setOut(convertUnits(Number(conv[1]), conv[2] ?? "", conv[3] ?? "") ?? "Cannot convert");
						return;
					}
					setOut(evalMath(expr) ?? "Cannot read that");
				},
				children: "Calculate"
			}),
			out ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-3xl tabular-nums",
				children: out
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Tip, split, percent, and unit conversion all run on this device."
			})
		]
	});
}
function JournalPanel() {
	const journal = useLumen((s) => s.journal);
	const addJournal = useLumen((s) => s.addJournal);
	const [body, setBody] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "mb-4 flex flex-col gap-2",
		onSubmit: (e) => {
			e.preventDefault();
			if (!body.trim()) return;
			addJournal(body.trim());
			setBody("");
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
			value: body,
			onChange: (e) => setBody(e.target.value),
			placeholder: "What happened today"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			type: "submit",
			className: "self-end",
			children: "Write"
		})]
	}), !journal.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: "The journal is empty. “Journal today I shipped the draft”." }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "flex flex-col gap-2",
		children: journal.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "rounded-xl bg-card p-4 shadow-[var(--shadow-border)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: new Date(e.createdAt).toLocaleString()
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 whitespace-pre-wrap text-sm",
				children: e.body
			})]
		}, e.id))
	})] });
}
function SettingsPanel() {
	const settings = useLumen((s) => s.settings);
	const patchSettings = useLumen((s) => s.patchSettings);
	const replaceAll = useLumen((s) => s.replaceAll);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 text-xs font-medium uppercase tracking-wide text-muted",
				children: "You"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: settings.name,
				onChange: (e) => patchSettings({ name: e.target.value }),
				placeholder: "What should Lumen call you"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-xl bg-card px-4 py-3 shadow-[var(--shadow-border)]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
					checked: settings.voiceReplies,
					onCheckedChange: (v) => patchSettings({ voiceReplies: v }),
					label: "Speak replies"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl bg-card px-4 py-3 shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
					checked: settings.thinkOnline,
					onCheckedChange: (v) => patchSettings({ thinkOnline: v }),
					label: "Use Grok for open questions"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs text-muted",
					children: "Commands always run on device. Grok is only for “think …”."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					onClick: () => {
						const blob = new Blob([JSON.stringify(exportPayload(), null, 2)], { type: "application/json" });
						const url = URL.createObjectURL(blob);
						const a = document.createElement("a");
						a.href = url;
						a.download = "lumen-board.json";
						a.click();
						URL.revokeObjectURL(url);
					},
					children: "Export board"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "inline-flex h-11 items-center justify-center rounded-md bg-card text-sm font-medium shadow-[var(--shadow-border)]",
					children: ["Import board", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "file",
						accept: "application/json",
						className: "sr-only",
						onChange: async (e) => {
							const file = e.target.files?.[0];
							if (!file) return;
							try {
								const data = JSON.parse(await file.text());
								replaceAll(data);
							} catch {}
						}
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Lumen stores everything in this browser. Call, text, and email buttons open the phone when a number exists."
			})
		]
	});
}
var APPS = [
	{
		id: "tasks",
		label: "Tasks",
		Icon: ListTodo
	},
	{
		id: "notes",
		label: "Notes",
		Icon: StickyNote
	},
	{
		id: "reminders",
		label: "Remind",
		Icon: Bell
	},
	{
		id: "calendar",
		label: "Plan",
		Icon: Calendar
	},
	{
		id: "timer",
		label: "Time",
		Icon: Clock
	},
	{
		id: "lists",
		label: "Lists",
		Icon: ShoppingBag
	},
	{
		id: "people",
		label: "People",
		Icon: UserRound
	},
	{
		id: "focus",
		label: "Focus",
		Icon: Focus
	},
	{
		id: "calc",
		label: "Numbers",
		Icon: Calculator
	},
	{
		id: "journal",
		label: "Journal",
		Icon: NotebookPen
	},
	{
		id: "talk",
		label: "Talk",
		Icon: Sparkles
	},
	{
		id: "settings",
		label: "Settings",
		Icon: Settings
	}
];
var CHIPS = [
	"Set a 5 minute timer",
	"Remind me to stretch at 7pm",
	"Add milk to shopping",
	"What's on today"
];
function LumenShell() {
	const module = useLumen((s) => s.module);
	const setModule = useLumen((s) => s.setModule);
	const setNow = useLumen((s) => s.setNow);
	const now = useLumen((s) => s.now);
	const settings = useLumen((s) => s.settings);
	const lastResult = useLumen((s) => s.lastResult);
	const timers = useLumen((s) => s.timers);
	const reminders = useLumen((s) => s.reminders);
	const alarms = useLumen((s) => s.alarms);
	const focus = useLumen((s) => s.focus);
	const finishTimer = useLumen((s) => s.finishTimer);
	const markReminderNotified = useLumen((s) => s.markReminderNotified);
	const markAlarmFired = useLumen((s) => s.markAlarmFired);
	const stopFocus = useLumen((s) => s.stopFocus);
	const pushMessage = useLumen((s) => s.pushMessage);
	const execute = useLumen((s) => s.execute);
	const submit = useLumen((s) => s.submit);
	const [draft, setDraft] = (0, import_react.useState)("");
	const [listening, setListening] = (0, import_react.useState)(false);
	const [thinking, setThinking] = (0, import_react.useState)(false);
	const stopListen = (0, import_react.useRef)(null);
	const inputRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => setNow(Date.now()), 250);
		return () => window.clearInterval(id);
	}, [setNow]);
	(0, import_react.useEffect)(() => {
		for (const t of timers) if (t.status === "running" && t.endsAt <= Date.now()) {
			finishTimer(t.id);
			beep();
			vibrate();
			notify("Lumen", `${t.label} is done.`);
			toast("Timer finished");
			if (useLumen.getState().settings.voiceReplies) speak("Time is up.");
		}
		for (const r of reminders) if (!r.done && !r.notified && r.at <= Date.now()) {
			markReminderNotified(r.id);
			beep();
			vibrate();
			notify("Lumen", r.title);
			toast(r.title);
			if (useLumen.getState().settings.voiceReplies) speak(r.title);
		}
		const d = /* @__PURE__ */ new Date();
		const key = `${d.toDateString()}-${d.getHours()}-${d.getMinutes()}`;
		for (const a of alarms) if (a.enabled && a.hour === d.getHours() && a.minute === d.getMinutes() && a.lastFiredKey !== key) {
			markAlarmFired(a.id, key);
			beep();
			vibrate();
			notify("Lumen", a.label);
			toast(`Alarm · ${a.label}`);
		}
		if (focus?.running && focus.endsAt <= Date.now()) {
			stopFocus();
			beep();
			toast("Focus session complete");
		}
	}, [
		now,
		timers,
		reminders,
		alarms,
		focus,
		finishTimer,
		markReminderNotified,
		markAlarmFired,
		stopFocus
	]);
	async function run(text) {
		const trimmed = text.trim();
		if (!trimmed || thinking) return;
		setDraft("");
		stopSpeaking();
		const { intent, result } = submit(trimmed);
		if (intent.type === "think" || intent.type === "unknown" && useLumen.getState().settings.thinkOnline) {
			setThinking(true);
			const snap = snapshotText();
			try {
				const res = await askGrok({ data: {
					prompt: trimmed,
					snapshot: snap
				} });
				if (res.ok && res.text) {
					const parsed = parseActionBlock(res.text);
					if (parsed.intent) execute(parsed.intent);
					const reply = parsed.clean || res.text;
					pushMessage({
						role: "lumen",
						text: reply,
						open: "talk"
					});
					useLumen.setState({
						lastResult: reply,
						module: "talk"
					});
					if (useLumen.getState().settings.voiceReplies) speak(reply);
					return;
				}
				throw new Error(res.ok ? "empty" : res.error);
			} catch {
				if (intent.type === "unknown") {
					const local = execute(intent);
					pushMessage({
						role: "lumen",
						text: local.text,
						open: local.open
					});
					useLumen.setState({
						lastResult: local.text,
						module: local.open ?? "talk"
					});
					if (useLumen.getState().settings.voiceReplies) speak(local.text);
				} else {
					const fallback = "Grok is not reachable. I can still run timers, tasks, notes, and the rest on this device.";
					pushMessage({
						role: "lumen",
						text: fallback,
						open: "talk"
					});
					useLumen.setState({
						lastResult: fallback,
						module: "talk"
					});
					if (useLumen.getState().settings.voiceReplies) speak(fallback);
				}
			} finally {
				setThinking(false);
			}
			return;
		}
		if (result.href) window.location.href = result.href;
		if (settings.voiceReplies) speak(result.text);
	}
	function toggleMic() {
		if (listening) {
			stopListen.current?.();
			stopListen.current = null;
			setListening(false);
			return;
		}
		if (!canListen()) {
			toast("Voice input is not available in this browser.");
			inputRef.current?.focus();
			return;
		}
		setListening(true);
		stopListen.current = startListening((text, final) => {
			setDraft(text);
			if (final) {
				setListening(false);
				stopListen.current = null;
				run(text);
			}
		});
	}
	const clock = new Date(now);
	const timeLabel = clock.toLocaleTimeString([], {
		hour: "numeric",
		minute: "2-digit"
	});
	const dateLabel = clock.toLocaleDateString([], {
		weekday: "long",
		month: "long",
		day: "numeric"
	});
	const running = timers.find((t) => t.status === "running");
	const nextRem = reminders.filter((r) => !r.done && r.at >= now).sort((a, b) => a.at - b.at)[0];
	const tasks = useLumen((s) => s.tasks);
	const messages = useLumen((s) => s.messages);
	const openTasks = tasks.filter((t) => !t.done).length;
	const brief = composeBriefing({
		tasks,
		reminders,
		events: useLumen.getState().events,
		timers,
		alarms,
		lists: useLumen.getState().lists,
		now
	});
	const dock = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "shrink-0 bg-background px-4 pb-[max(0.75rem,env(safe-area-inset-bottom))] pt-2",
		onSubmit: (e) => {
			e.preventDefault();
			run(draft);
		},
		children: [lastResult ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-2 line-clamp-2 rounded-xl bg-card px-3.5 py-2 text-sm text-foreground shadow-[var(--shadow-border)]",
			children: thinking ? "Thinking…" : lastResult
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-end gap-2 rounded-2xl bg-card p-2 shadow-[var(--shadow-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "sr-only",
					htmlFor: "lumen-command",
					children: "Tell Lumen"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					id: "lumen-command",
					ref: inputRef,
					value: draft,
					onChange: (e) => setDraft(e.target.value),
					placeholder: "Tell Lumen…",
					autoComplete: "off",
					className: "h-11 min-w-0 flex-1 bg-transparent px-3 text-base text-foreground placeholder:text-subtle focus:outline-none"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					size: "icon",
					variant: listening ? "default" : "secondary",
					onClick: toggleMic,
					"aria-label": listening ? "Stop listening" : "Voice input",
					children: listening ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					size: "icon",
					disabled: thinking,
					"aria-label": "Send",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-4" })
				})
			]
		})]
	});
	const home = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "min-h-0 flex-1 overflow-y-auto px-5 pb-4 pt-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: dateLabel
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				suppressHydrationWarning: true,
				className: "font-display text-6xl leading-none tracking-tight",
				children: timeLabel
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				suppressHydrationWarning: true,
				className: "mt-4 font-display text-2xl italic text-foreground/90",
				children: greeting(clock, settings.name)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-prose text-sm leading-relaxed text-muted",
				children: brief
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 flex flex-wrap gap-2",
				children: CHIPS.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => void run(c),
					className: "min-h-11 rounded-full bg-card px-3.5 text-left text-sm text-muted shadow-[var(--shadow-border)]",
					children: c
				}, c))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid grid-cols-2 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Widget, {
						label: "Tasks",
						value: `${openTasks} open`,
						onClick: () => setModule("tasks")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Widget, {
						label: "Timer",
						value: running ? msToClock(running.endsAt - now) : "Idle",
						mono: true,
						onClick: () => setModule("timer")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Widget, {
						label: "Next",
						value: nextRem ? `${nextRem.title} · ${formatWhen(nextRem.at, now)}` : "No reminder",
						onClick: () => setModule("reminders")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Widget, {
						label: "Focus",
						value: focus?.running ? msToClock(focus.endsAt - now) : "Ready",
						mono: Boolean(focus?.running),
						onClick: () => setModule("focus")
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8 text-xs font-medium uppercase tracking-wide text-muted",
				children: "Board"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 grid grid-cols-3 gap-2",
				children: APPS.map((app) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setModule(app.id),
					className: "flex min-h-24 flex-col items-start justify-between rounded-xl bg-card p-3 text-left shadow-[var(--shadow-border)] transition-[box-shadow,transform] duration-150 ease-out hover:shadow-[var(--shadow-border-hover)] active:scale-[0.96]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(app.Icon, { className: "size-4 text-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm font-medium",
						children: app.label
					})]
				}, app.id))
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-background",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
			theme: "dark",
			position: "top-center"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid min-h-dvh w-full max-w-6xl lg:grid-cols-[28rem_minmax(0,1fr)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "relative flex h-dvh flex-col overflow-hidden bg-background",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "flex items-center justify-between px-5 pt-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: "On device" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "size-11 text-muted",
							onClick: () => setModule("settings"),
							"aria-label": "Settings",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "mx-auto size-4" })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative flex min-h-0 flex-1 flex-col",
						children: [home, module !== "home" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute inset-0 z-10 flex flex-col bg-background lg:hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModuleFrame, {
								module,
								onBack: () => setModule("home")
							})
						}) : null]
					}),
					dock
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
				className: "hidden h-dvh flex-col border-l border-border lg:flex",
				children: module !== "home" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModuleFrame, {
					module,
					onBack: () => setModule("home")
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-h-0 flex-1 flex-col px-8 py-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium uppercase tracking-wide text-muted",
							children: "Talk"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-2 font-display text-3xl tracking-tight",
							children: "Tell Lumen what to do."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 max-w-md text-sm leading-relaxed text-muted",
							children: "Timers, reminders, notes, lists, calls, and drafts all stay on this device. Open questions can use Grok if you prefix with “think”."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8 min-h-0 flex-1 overflow-y-auto",
							children: !messages.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: "No conversation yet."
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
								className: "flex flex-col gap-3",
								children: messages.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
									className: cn("max-w-md rounded-xl px-3.5 py-2.5 text-sm leading-relaxed", m.role === "user" ? "bg-primary text-primary-foreground" : "bg-card text-foreground shadow-[var(--shadow-border)]"),
									children: m.text
								}, m.id))
							})
						})
					]
				})
			})]
		})]
	});
}
function Widget({ label, value, onClick, mono }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: "min-h-24 rounded-xl bg-card p-3.5 text-left shadow-[var(--shadow-border)] transition-[box-shadow,transform] duration-150 ease-out hover:shadow-[var(--shadow-border-hover)] active:scale-[0.96]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs uppercase tracking-wide text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: cn("mt-2 text-sm leading-snug", mono && "font-mono text-xl tabular-nums"),
			children: value
		})]
	});
}
function snapshotText() {
	const s = useLumen.getState();
	const tasks = s.tasks.filter((t) => !t.done).slice(0, 8).map((t) => t.title).join("; ");
	const rems = s.reminders.filter((r) => !r.done).slice(0, 5).map((r) => `${r.title} @ ${new Date(r.at).toISOString()}`).join("; ");
	const people = s.contacts.map((c) => c.name).join(", ");
	const lists = s.lists.map((l) => `${l.name}: ${l.items.filter((i) => !i.done).map((i) => i.text).join(", ")}`).join(" | ");
	return `tasks: ${tasks || "none"}\nreminders: ${rems || "none"}\npeople: ${people || "none"}\nlists: ${lists || "none"}`;
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LumenShell, {});
}
//#endregion
export { Home as component };
