import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Shuffle, c as Pause, d as Keyboard, i as Sparkles, l as Mouse, n as Volume2, o as RotateCcw, s as Play, t as VolumeX, u as Map } from "../_libs/lucide-react.mjs";
import { C as Points, D as SphereGeometry, E as Scene, O as TorusGeometry, S as PointLight, T as SRGBColorSpace, _ as MeshStandardMaterial, a as CanvasTexture, b as PerspectiveCamera, c as DirectionalLight, d as Group, f as HemisphereLight, g as MeshLambertMaterial, h as MeshBasicMaterial, i as BufferGeometry, l as Float32BufferAttribute, m as Mesh, n as BoxGeometry, o as CircleGeometry, p as InstancedMesh, r as BufferAttribute, s as Color, t as WebGLRenderer, u as Fog, v as Object3D, w as PointsMaterial, x as PlaneGeometry, y as OctahedronGeometry } from "../_libs/three.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-0vdQGi16.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** Tiny synthesized cues. Unlocked from the start gesture. */
var Sfx = class {
	ctx = null;
	muted = false;
	unlock() {
		if (typeof window === "undefined") return;
		const AC = window.AudioContext || window.webkitAudioContext;
		if (!AC) return;
		if (!this.ctx) this.ctx = new AC();
		if (this.ctx.state === "suspended") this.ctx.resume();
	}
	tone(freq, dur, type, gain, delay = 0) {
		if (!this.ctx || this.muted || gain <= 0) return;
		const t = this.ctx.currentTime + delay;
		const osc = this.ctx.createOscillator();
		const amp = this.ctx.createGain();
		osc.type = type;
		osc.frequency.setValueAtTime(freq, t);
		amp.gain.setValueAtTime(1e-4, t);
		amp.gain.exponentialRampToValueAtTime(Math.max(2e-4, gain), t + .018);
		amp.gain.exponentialRampToValueAtTime(1e-4, t + dur);
		osc.connect(amp);
		amp.connect(this.ctx.destination);
		osc.start(t);
		osc.stop(t + dur + .02);
	}
	click() {
		this.tone(540, .07, "sine", .04);
	}
	pickup() {
		this.tone(620, .1, "sine", .06);
		this.tone(930, .14, "triangle", .045, .05);
	}
	bump() {
		this.tone(78, .09, "triangle", .05);
		this.tone(140, .05, "sine", .02, .01);
	}
	step() {
		const f = 120 + Math.random() * 36;
		this.tone(f, .045, "sine", .018);
	}
	near() {
		this.tone(784, .12, "sine", .02);
		this.tone(988, .16, "sine", .016, .08);
	}
	win() {
		[
			523.25,
			659.25,
			783.99,
			1046.5
		].forEach((f, i) => {
			this.tone(f, .28, "sine", .06, i * .09);
			this.tone(f * 2, .18, "triangle", .02, i * .09 + .02);
		});
	}
};
/** Grid maze + circle collision. Axis-aligned hedges, separate-axis slide. */
var CELL = 2.5;
var PLAYER_RADIUS = .34;
var EYE = 1.62;
var WALK_SPEED = 4.55;
var SPRINT_SPEED = 7.15;
var DIRS = [
	[1, 0],
	[-1, 0],
	[0, 1],
	[0, -1]
];
function mulberry32(seed) {
	let a = seed >>> 0;
	return () => {
		a |= 0;
		a = a + 1831565813 | 0;
		let t = Math.imul(a ^ a >>> 15, 1 | a);
		t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
function isWall(maze, x, z) {
	if (x < 0 || z < 0 || x >= maze.w || z >= maze.h) return true;
	return maze.walls[z * maze.w + x] === 1;
}
function cellCenter(cell) {
	return {
		x: (cell.x + .5) * CELL,
		z: (cell.z + .5) * CELL
	};
}
/** yaw 0 faces world −Z. +yaw turns the nose toward −X (CCW about +Y). */
function basis(yaw) {
	return {
		fx: -Math.sin(yaw),
		fz: -Math.cos(yaw),
		rx: Math.cos(yaw),
		rz: -Math.sin(yaw)
	};
}
/** FPS strafe wish direction. inputF > 0 forward, inputR > 0 strafe right. */
function wishVelocity(yaw, inputF, inputR) {
	const b = basis(yaw);
	return {
		x: b.fx * inputF + b.rx * inputR,
		z: b.fz * inputF + b.rz * inputR
	};
}
function preferredYaw(maze, cell) {
	const { x, z } = cell;
	if (!isWall(maze, x, z - 1)) return 0;
	if (!isWall(maze, x + 1, z)) return -Math.PI / 2;
	if (!isWall(maze, x, z + 1)) return Math.PI;
	if (!isWall(maze, x - 1, z)) return Math.PI / 2;
	return 0;
}
/** Torus hole along Z by default. Rotate π/2 when the entrance is on X. */
function gateRotY(maze) {
	const { x, z } = maze.exit;
	if (!isWall(maze, x - 1, z) || !isWall(maze, x + 1, z)) return Math.PI / 2;
	return 0;
}
function shuffle(items, rng) {
	const arr = items.slice();
	for (let i = arr.length - 1; i > 0; i--) {
		const j = rng() * (i + 1) | 0;
		const tmp = arr[i];
		arr[i] = arr[j];
		arr[j] = tmp;
	}
	return arr;
}
function generateMaze(seed, rooms = 7) {
	const rng = mulberry32(seed);
	const w = rooms * 2 + 1;
	const h = rooms * 2 + 1;
	const walls = new Uint8Array(w * h);
	walls.fill(1);
	const seen = new Uint8Array(rooms * rooms);
	const stack = [[0, 0]];
	seen[0] = 1;
	walls[1 * w + 1] = 0;
	while (stack.length) {
		const [i, j] = stack[stack.length - 1];
		const options = [];
		for (const [di, dj] of DIRS) {
			const ni = i + di;
			const nj = j + dj;
			if (ni < 0 || nj < 0 || ni >= rooms || nj >= rooms) continue;
			if (seen[nj * rooms + ni]) continue;
			options.push([
				ni,
				nj,
				di,
				dj
			]);
		}
		if (!options.length) {
			stack.pop();
			continue;
		}
		const pick = options[rng() * options.length | 0];
		const ni = pick[0];
		const nj = pick[1];
		const di = pick[2];
		const dj = pick[3];
		const x = i * 2 + 1;
		const z = j * 2 + 1;
		walls[(z + dj) * w + (x + di)] = 0;
		walls[(z + 2 * dj) * w + (x + 2 * di)] = 0;
		seen[nj * rooms + ni] = 1;
		stack.push([ni, nj]);
	}
	const start = {
		x: 1,
		z: 1
	};
	const exit = {
		x: w - 2,
		z: h - 2
	};
	const floors = [];
	for (let z = 1; z < h - 1; z++) for (let x = 1; x < w - 1; x++) {
		if (walls[z * w + x]) continue;
		floors.push({
			x,
			z
		});
	}
	const degree = (c) => {
		let n = 0;
		for (const [dx, dz] of DIRS) if (!isWall({
			seed,
			w,
			h,
			walls,
			start,
			exit,
			pickups: []
		}, c.x + dx, c.z + dz)) n++;
		return n;
	};
	const far = (c, min) => Math.abs(c.x - start.x) + Math.abs(c.z - start.z) > min && !(c.x === exit.x && c.z === exit.z);
	const dead = shuffle(floors.filter((c) => degree(c) === 1 && far(c, 2)), rng);
	const pickups = [];
	for (const c of dead) {
		if (pickups.length >= 8) break;
		pickups.push(c);
	}
	const rest = shuffle(floors.filter((c) => far(c, 4) && !pickups.some((p) => p.x === c.x && p.z === c.z) && degree(c) >= 2), rng);
	for (const c of rest) {
		if (pickups.length >= 10) break;
		if (pickups.some((p) => Math.abs(p.x - c.x) + Math.abs(p.z - c.z) < 4)) continue;
		pickups.push(c);
	}
	return {
		seed,
		w,
		h,
		walls,
		start,
		exit,
		pickups
	};
}
function circleHits(maze, px, pz, radius) {
	const skin = radius - .006;
	if (skin <= 0) return false;
	const r2 = skin * skin;
	const minX = Math.floor((px - radius) / CELL);
	const maxX = Math.floor((px + radius) / CELL);
	const minZ = Math.floor((pz - radius) / CELL);
	const maxZ = Math.floor((pz + radius) / CELL);
	for (let z = minZ; z <= maxZ; z++) for (let x = minX; x <= maxX; x++) {
		if (!isWall(maze, x, z)) continue;
		const nx = Math.max(x * CELL, Math.min(px, (x + 1) * CELL));
		const nz = Math.max(z * CELL, Math.min(pz, (z + 1) * CELL));
		const dx = px - nx;
		const dz = pz - nz;
		if (dx * dx + dz * dz < r2) return true;
	}
	return false;
}
function depenetrate(maze, x, z, radius) {
	if (!circleHits(maze, x, z, radius)) return {
		x,
		z
	};
	for (let i = 1; i <= 18; i++) {
		const s = i * .045;
		const tries = [
			[s, 0],
			[-s, 0],
			[0, s],
			[0, -s],
			[s, s],
			[s, -s],
			[-s, s],
			[-s, -s]
		];
		for (const [dx, dz] of tries) if (!circleHits(maze, x + dx, z + dz, radius)) return {
			x: x + dx,
			z: z + dz
		};
	}
	return {
		x,
		z
	};
}
/**
* Substepped circle move. X then Z so corridors slide instead of sticking.
* Steps stay under the radius so a fast frame cannot tunnel a hedge.
*/
function moveCircle(maze, px, pz, dx, dz, radius) {
	let x = px;
	let z = pz;
	if (circleHits(maze, x, z, radius)) {
		const freed = depenetrate(maze, x, z, radius);
		x = freed.x;
		z = freed.z;
	}
	const steps = Math.max(1, Math.ceil(Math.hypot(dx, dz) / .12));
	const sx = dx / steps;
	const sz = dz / steps;
	let blockedX = false;
	let blockedZ = false;
	for (let i = 0; i < steps; i++) {
		const nx = x + sx;
		if (!circleHits(maze, nx, z, radius)) x = nx;
		else blockedX = true;
		const nz = z + sz;
		if (!circleHits(maze, x, nz, radius)) z = nz;
		else blockedZ = true;
	}
	return {
		x,
		z,
		blockedX,
		blockedZ
	};
}
/** Reveal open cells a few steps ahead, never through hedges. */
function revealAround(maze, px, pz, visited) {
	const sx = Math.floor(px / CELL);
	const sz = Math.floor(pz / CELL);
	if (sx < 0 || sz < 0 || sx >= maze.w || sz >= maze.h) return;
	const w = maze.w;
	const seen = new Uint8Array(maze.w * maze.h);
	const q = [[
		sx,
		sz,
		0
	]];
	seen[sz * w + sx] = 1;
	let qi = 0;
	while (qi < q.length) {
		const [x, z, d] = q[qi++];
		if (isWall(maze, x, z)) continue;
		visited[z * w + x] = 1;
		if (d >= 4) continue;
		for (const [dx, dz] of DIRS) {
			const nx = x + dx;
			const nz = z + dz;
			if (nx < 0 || nz < 0 || nx >= maze.w || nz >= maze.h) continue;
			const k = nz * w + nx;
			if (seen[k] || isWall(maze, nx, nz)) continue;
			seen[k] = 1;
			q.push([
				nx,
				nz,
				d + 1
			]);
		}
	}
}
function mapCellVisible(maze, x, z, visited) {
	if (!isWall(maze, x, z)) return visited[z * maze.w + x] === 1;
	for (const [dx, dz] of DIRS) {
		const nx = x + dx;
		const nz = z + dz;
		if (nx < 0 || nz < 0 || nx >= maze.w || nz >= maze.h) continue;
		if (!isWall(maze, nx, nz) && visited[nz * maze.w + nx]) return true;
	}
	return false;
}
function formatTime(ms) {
	const total = Math.max(0, ms) / 1e3;
	const m = Math.floor(total / 60);
	const s = total - m * 60;
	const whole = Math.floor(s);
	const tenth = Math.floor((s - whole) * 10);
	return `${m}:${String(whole).padStart(2, "0")}.${tenth}`;
}
var SAVE_KEY = "sunbloom-v1";
var HEDGE = [
	"#215c38",
	"#2a7344",
	"#327e4c",
	"#1b5132",
	"#3b8b56"
];
var CAPS = [
	"#8ed07a",
	"#a6db90",
	"#7bc46e",
	"#b7e4a4"
];
var PARTICLE_MAX = 80;
function loadSave() {
	try {
		const raw = localStorage.getItem(SAVE_KEY);
		if (!raw) return {
			v: 1,
			best: null,
			muted: false
		};
		const parsed = JSON.parse(raw);
		if (!parsed || parsed.v !== 1) return {
			v: 1,
			best: null,
			muted: false
		};
		return {
			v: 1,
			best: parsed.best && typeof parsed.best.ms === "number" ? parsed.best : null,
			muted: Boolean(parsed.muted)
		};
	} catch {
		return {
			v: 1,
			best: null,
			muted: false
		};
	}
}
function glowTexture() {
	const canvas = document.createElement("canvas");
	canvas.width = 64;
	canvas.height = 64;
	const g = canvas.getContext("2d");
	if (!g) return new CanvasTexture(canvas);
	const grd = g.createRadialGradient(32, 32, 0, 32, 32, 32);
	grd.addColorStop(0, "rgba(255,255,255,1)");
	grd.addColorStop(.35, "rgba(255,244,210,0.85)");
	grd.addColorStop(1, "rgba(255,244,210,0)");
	g.fillStyle = grd;
	g.fillRect(0, 0, 64, 64);
	const tex = new CanvasTexture(canvas);
	tex.colorSpace = SRGBColorSpace;
	return tex;
}
var MazeEngine = class {
	canvas;
	map;
	onHud;
	sfx = new Sfx();
	renderer;
	scene = new Scene();
	camera;
	clockT = { now: 0 };
	keys = /* @__PURE__ */ new Set();
	reduceMotion;
	detach = [];
	dummy = new Object3D();
	color = new Color();
	particles = [];
	particlePos;
	particleCol;
	points;
	px = 0;
	pz = 0;
	yaw = 0;
	pitch = -.08;
	maze;
	visited;
	alive = [];
	world = null;
	gemMesh = null;
	haloMesh = null;
	ringA = null;
	ringB = null;
	disc = null;
	phase = "menu";
	timeMs = 0;
	collected = 0;
	velX = 0;
	velZ = 0;
	axisX = 0;
	axisY = 0;
	lastInputR = 0;
	sprinting = false;
	bob = 0;
	trauma = 0;
	stepAcc = 0;
	nearAcc = 0;
	hudAcc = 0;
	hudDirty = true;
	baseYaw = 0;
	worldT = 0;
	lastBump = -10;
	qaOverride = null;
	wasLocked = false;
	touchLayout = false;
	best;
	newBest = false;
	perfect = false;
	disposed = false;
	raf = 0;
	lastFrame = 0;
	resizeObs = null;
	constructor(canvas, map, onHud) {
		this.canvas = canvas;
		this.map = map;
		this.onHud = onHud;
		const save = loadSave();
		this.best = save.best;
		this.sfx.muted = save.muted;
		this.reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		this.renderer = new WebGLRenderer({
			canvas,
			antialias: true,
			alpha: false,
			powerPreference: "high-performance"
		});
		this.renderer.outputColorSpace = SRGBColorSpace;
		this.renderer.toneMapping = 4;
		this.renderer.toneMappingExposure = 1.05;
		this.renderer.shadowMap.enabled = true;
		this.renderer.shadowMap.type = 2;
		this.renderer.setClearColor(12970491, 1);
		this.scene.background = new Color(12970491);
		this.scene.fog = new Fog(13955581, 12, 34);
		this.camera = new PerspectiveCamera(75, 1, .08, 80);
		const hemi = new HemisphereLight(16774879, 9420664, 1.15);
		this.scene.add(hemi);
		const sun = new DirectionalLight(16775920, 2.35);
		sun.position.set(16, 28, 10);
		sun.castShadow = true;
		const shadowCam = sun.shadow.camera;
		sun.shadow.mapSize.set(1024, 1024);
		shadowCam.near = 2;
		shadowCam.far = 70;
		shadowCam.left = -28;
		shadowCam.right = 28;
		shadowCam.top = 28;
		shadowCam.bottom = -28;
		sun.shadow.bias = -4e-4;
		sun.shadow.normalBias = .035;
		this.scene.add(sun);
		this.scene.add(sun.target);
		sun.target.position.set(18, 0, 18);
		const sunBall = new Mesh(new SphereGeometry(2.4, 16, 12), new MeshBasicMaterial({ color: 16769690 }));
		sunBall.position.set(-8, 18, -10);
		this.scene.add(sunBall);
		this.addClouds();
		this.particlePos = /* @__PURE__ */ new Float32Array(240);
		this.particleCol = /* @__PURE__ */ new Float32Array(240);
		for (let i = 0; i < PARTICLE_MAX; i++) {
			this.particles.push({
				x: 0,
				y: -40,
				z: 0,
				vx: 0,
				vy: 0,
				vz: 0,
				life: 0,
				max: 1,
				r: 1,
				g: 1,
				b: 1
			});
			this.particlePos[i * 3 + 1] = -40;
		}
		const pgeo = new BufferGeometry();
		pgeo.setAttribute("position", new BufferAttribute(this.particlePos, 3));
		pgeo.setAttribute("color", new BufferAttribute(this.particleCol, 3));
		const tex = glowTexture();
		this.points = new Points(pgeo, new PointsMaterial({
			size: .22,
			map: tex,
			transparent: true,
			depthWrite: false,
			vertexColors: true,
			sizeAttenuation: true
		}));
		this.scene.add(this.points);
		const seed = Math.random() * 2147483647 | 0;
		this.maze = generateMaze(seed);
		this.visited = new Uint8Array(this.maze.w * this.maze.h);
		this.buildWorld(this.maze);
		this.resetRun();
		this.bind(window, "keydown", this.onKeyDown);
		this.bind(window, "keyup", this.onKeyUp);
		this.bind(window, "blur", () => this.keys.clear());
		this.bind(document, "visibilitychange", () => {
			if (document.hidden) this.keys.clear();
		});
		this.bind(document, "mousemove", this.onMouseMove);
		this.bind(document, "pointerlockchange", this.onLockChange);
		this.bind(canvas, "contextmenu", (e) => e.preventDefault());
		this.resizeObs = new ResizeObserver(() => this.resize());
		this.resizeObs.observe(canvas);
		this.resize();
		this.lastFrame = performance.now();
		this.raf = requestAnimationFrame(this.frame);
		this.emit();
	}
	get speed() {
		return Math.hypot(this.velX, this.velZ);
	}
	setTouchLayout(on) {
		this.touchLayout = on;
	}
	setMoveAxis(x, y) {
		this.axisX = Math.max(-1, Math.min(1, x));
		this.axisY = Math.max(-1, Math.min(1, y));
	}
	lookBy(dx, dy, sens = .0042) {
		if (this.phase !== "play") return;
		this.yaw -= dx * sens;
		this.pitch -= dy * sens;
		this.pitch = Math.max(-1.3, Math.min(1.3, this.pitch));
	}
	setKeys(codes) {
		this.qaOverride = new Set(codes);
		if (this.phase === "menu" || this.phase === "paused") {
			this.phase = "play";
			this.hudDirty = true;
		}
	}
	beginFromMenu() {
		this.sfx.unlock();
		this.sfx.click();
		if (this.phase === "won" || this.phase === "menu") this.resetRun();
		this.phase = "play";
		this.hudDirty = true;
		this.emit();
		this.lockPointer();
	}
	resume() {
		if (this.phase !== "paused") return;
		this.sfx.unlock();
		this.sfx.click();
		this.phase = "play";
		this.hudDirty = true;
		this.emit();
		this.lockPointer();
	}
	pause() {
		if (this.phase !== "play") return;
		this.phase = "paused";
		this.hudDirty = true;
		this.wasLocked = false;
		if (document.pointerLockElement) document.exitPointerLock();
		this.emit();
	}
	toMenu() {
		this.sfx.click();
		this.resetRun();
		this.phase = "menu";
		this.wasLocked = false;
		if (document.pointerLockElement) document.exitPointerLock();
		this.hudDirty = true;
		this.emit();
	}
	retry(newSeed) {
		this.sfx.unlock();
		this.sfx.click();
		const seed = newSeed ? Math.random() * 2147483647 | 0 : this.maze.seed;
		if (newSeed || this.phase === "won") {
			this.maze = generateMaze(seed);
			this.visited = new Uint8Array(this.maze.w * this.maze.h);
			this.buildWorld(this.maze);
		}
		this.resetRun();
		this.phase = "play";
		this.hudDirty = true;
		this.emit();
		this.lockPointer();
	}
	toggleMute() {
		this.sfx.muted = !this.sfx.muted;
		if (!this.sfx.muted) {
			this.sfx.unlock();
			this.sfx.click();
		}
		this.persist();
		this.hudDirty = true;
		this.emit();
	}
	lockPointer() {
		if (this.touchLayout || this.qaOverride) return;
		const node = this.canvas;
		try {
			const pending = node.requestPointerLock?.({ unadjustedMovement: true });
			Promise.resolve(pending).catch(() => {
				try {
					node.requestPointerLock?.();
				} catch {}
			});
		} catch {
			try {
				node.requestPointerLock?.();
			} catch {}
		}
	}
	dispose() {
		this.disposed = true;
		cancelAnimationFrame(this.raf);
		this.resizeObs?.disconnect();
		for (const off of this.detach) off();
		this.detach.length = 0;
		this.clearWorld();
		this.points.geometry.dispose();
		this.points.material.dispose();
		this.renderer.dispose();
	}
	bind(target, type, fn) {
		target.addEventListener(type, fn);
		this.detach.push(() => target.removeEventListener(type, fn));
	}
	onKeyDown = (event) => {
		const e = event;
		if (!this.qaOverride) this.keys.add(e.code);
		if (e.code === "Escape" && this.phase === "play") this.pause();
		if (e.code.startsWith("Arrow") || e.code === "Space") e.preventDefault();
	};
	onKeyUp = (event) => {
		const e = event;
		this.keys.delete(e.code);
	};
	onMouseMove = (event) => {
		const e = event;
		if (this.phase !== "play") return;
		if (document.pointerLockElement !== this.canvas) return;
		this.lookBy(e.movementX, e.movementY, .00215);
	};
	onLockChange = () => {
		if (document.pointerLockElement === this.canvas) {
			this.wasLocked = true;
			return;
		}
		if (this.wasLocked && this.phase === "play" && !this.qaOverride) {
			this.wasLocked = false;
			this.phase = "paused";
			this.hudDirty = true;
		}
	};
	held(code) {
		if (this.qaOverride) return this.qaOverride.has(code);
		return this.keys.has(code);
	}
	readInput() {
		let f = 0;
		let r = 0;
		if (this.held("KeyW") || this.held("ArrowUp")) f += 1;
		if (this.held("KeyS") || this.held("ArrowDown")) f -= 1;
		if (this.held("KeyD") || this.held("ArrowRight")) r += 1;
		if (this.held("KeyA") || this.held("ArrowLeft")) r -= 1;
		r += this.axisX;
		f += this.axisY;
		const mag = Math.hypot(f, r);
		if (mag > 1) {
			f /= mag;
			r /= mag;
		}
		const sprint = this.held("ShiftLeft") || this.held("ShiftRight");
		return {
			f,
			r,
			sprint,
			pushing: mag > .08
		};
	}
	resetRun() {
		const spawn = cellCenter(this.maze.start);
		this.px = spawn.x;
		this.pz = spawn.z;
		this.baseYaw = preferredYaw(this.maze, this.maze.start);
		this.yaw = this.baseYaw;
		this.pitch = -.08;
		this.velX = 0;
		this.velZ = 0;
		this.timeMs = 0;
		this.collected = 0;
		this.alive = this.maze.pickups.map(() => true);
		this.visited.fill(0);
		this.newBest = false;
		this.perfect = false;
		this.trauma = 0;
		this.stepAcc = 0;
		this.nearAcc = 0;
		revealAround(this.maze, this.px, this.pz, this.visited);
	}
	persist() {
		const data = {
			v: 1,
			best: this.best,
			muted: this.sfx.muted
		};
		try {
			localStorage.setItem(SAVE_KEY, JSON.stringify(data));
		} catch {}
	}
	snapshot() {
		return {
			phase: this.phase,
			time: this.timeMs,
			collected: this.collected,
			total: this.maze.pickups.length,
			best: this.best,
			seed: this.maze.seed,
			muted: this.sfx.muted,
			newBest: this.newBest,
			perfect: this.perfect
		};
	}
	emit() {
		if (this.disposed) return;
		this.onHud(this.snapshot());
	}
	resize() {
		const w = this.canvas.clientWidth || 1;
		const h = this.canvas.clientHeight || 1;
		this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
		this.renderer.setSize(w, h, false);
		this.camera.aspect = w / Math.max(1, h);
		this.camera.updateProjectionMatrix();
	}
	frame = (now) => {
		if (this.disposed) return;
		const dt = Math.min(.05, (now - this.lastFrame) / 1e3);
		this.lastFrame = now;
		this.worldT += dt;
		this.update(dt);
		this.renderer.render(this.scene, this.camera);
		this.raf = requestAnimationFrame(this.frame);
	};
	update(dt) {
		if (this.phase === "play") {
			const input = this.readInput();
			this.lastInputR = input.r;
			this.sprinting = input.sprint && input.pushing;
			const max = this.sprinting ? SPRINT_SPEED : WALK_SPEED;
			const wish = wishVelocity(this.yaw, input.f, input.r);
			const rate = input.pushing ? 16 : 12;
			const k = 1 - Math.exp(-rate * dt);
			this.velX += (wish.x * max - this.velX) * k;
			this.velZ += (wish.z * max - this.velZ) * k;
			const speedBefore = Math.hypot(this.velX, this.velZ);
			const step = moveCircle(this.maze, this.px, this.pz, this.velX * dt, this.velZ * dt, PLAYER_RADIUS);
			if (step.blockedX) this.velX = 0;
			if (step.blockedZ) this.velZ = 0;
			if ((step.blockedX || step.blockedZ) && input.pushing && speedBefore > 1.15 && this.worldT - this.lastBump > .24) {
				this.lastBump = this.worldT;
				this.trauma = Math.min(1, this.trauma + .32);
				this.sfx.bump();
				this.burst(this.px, .35, this.pz, "#f0b429", 5);
			}
			this.px = step.x;
			this.pz = step.z;
			if (Math.hypot(this.velX, this.velZ) > 1.3) {
				this.stepAcc += dt;
				const interval = this.sprinting ? .32 : .46;
				if (this.stepAcc >= interval) {
					this.stepAcc = 0;
					this.sfx.step();
				}
			} else this.stepAcc = 0;
			this.collect();
			this.checkExit(dt);
			revealAround(this.maze, this.px, this.pz, this.visited);
			this.timeMs += dt * 1e3;
		}
		this.animateProps();
		this.stepParticles(dt);
		this.applyCamera(dt);
		if (this.phase === "play" || this.phase === "paused") this.drawMap();
		this.hudAcc += dt;
		if (this.hudDirty || this.phase === "play" && this.hudAcc > .1) {
			this.hudAcc = 0;
			this.hudDirty = false;
			this.emit();
		}
	}
	collect() {
		const r2 = .5184;
		for (let i = 0; i < this.maze.pickups.length; i++) {
			if (!this.alive[i]) continue;
			const c = cellCenter(this.maze.pickups[i]);
			const dx = this.px - c.x;
			const dz = this.pz - c.z;
			if (dx * dx + dz * dz > r2) continue;
			this.alive[i] = false;
			this.collected += 1;
			this.hudDirty = true;
			this.sfx.pickup();
			this.burst(c.x, .8, c.z, "#f0b429", 14);
		}
	}
	checkExit(dt) {
		if (this.phase !== "play") return;
		const c = cellCenter(this.maze.exit);
		const dx = this.px - c.x;
		const dz = this.pz - c.z;
		const dist = Math.hypot(dx, dz);
		if (dist < 5.5) {
			this.nearAcc += dt;
			if (this.nearAcc > 1.35) {
				this.nearAcc = 0;
				this.sfx.near();
			}
		}
		if (dist > .78) return;
		this.phase = "won";
		this.velX = 0;
		this.velZ = 0;
		this.perfect = this.collected === this.maze.pickups.length;
		this.newBest = !this.best || this.timeMs < this.best.ms;
		if (this.newBest) {
			this.best = {
				ms: this.timeMs,
				gems: this.collected,
				total: this.maze.pickups.length
			};
			this.persist();
		}
		this.sfx.win();
		this.burst(c.x, 1.3, c.z, "#ff6b4a", 28);
		this.burst(c.x, 1.1, c.z, "#f0b429", 20);
		this.wasLocked = false;
		if (document.pointerLockElement) document.exitPointerLock();
		this.hudDirty = true;
	}
	animateProps() {
		const t = this.worldT;
		if (this.gemMesh && this.haloMesh) {
			for (let i = 0; i < this.maze.pickups.length; i++) {
				const c = cellCenter(this.maze.pickups[i]);
				const bob = .78 + Math.sin(t * 2.1 + i) * .12;
				const s = this.alive[i] ? 1 : 1e-4;
				this.dummy.position.set(c.x, bob, c.z);
				this.dummy.rotation.set(t * .7, t * 1.4 + i, 0);
				this.dummy.scale.setScalar(s);
				this.dummy.updateMatrix();
				this.gemMesh.setMatrixAt(i, this.dummy.matrix);
				const halo = 1 + Math.sin(t * 3 + i) * .08;
				this.dummy.scale.setScalar(this.alive[i] ? halo : 1e-4);
				this.dummy.rotation.set(0, 0, 0);
				this.dummy.updateMatrix();
				this.haloMesh.setMatrixAt(i, this.dummy.matrix);
			}
			this.gemMesh.instanceMatrix.needsUpdate = true;
			this.haloMesh.instanceMatrix.needsUpdate = true;
		}
		if (this.ringA) this.ringA.rotation.z = t * .7;
		if (this.ringB) this.ringB.rotation.z = -t * 1.15;
		if (this.disc) {
			const mat = this.disc.material;
			mat.opacity = .28 + Math.sin(t * 2.4) * .08;
		}
	}
	applyCamera(dt) {
		const reduce = this.reduceMotion;
		const speed = Math.hypot(this.velX, this.velZ);
		const moving = speed > .4 && this.phase === "play";
		if (moving && !reduce) this.bob += dt * (this.sprinting ? 11.5 : 9.2);
		const mag = !reduce && moving ? Math.min(1, speed / WALK_SPEED) : 0;
		const bobY = Math.sin(this.bob) * .045 * mag;
		const bobX = Math.cos(this.bob * .5) * .018 * mag;
		this.trauma = Math.max(0, this.trauma - dt * 2.5);
		const sh = reduce ? 0 : this.trauma * this.trauma;
		const shakeX = Math.sin(this.worldT * 41) * sh * .05;
		const shakeY = Math.cos(this.worldT * 33) * sh * .032;
		let yaw = this.yaw;
		let pitch = this.pitch;
		if (this.phase === "menu" && !reduce) {
			yaw = this.baseYaw + Math.sin(this.worldT * .42) * .45;
			pitch = -.12 + Math.sin(this.worldT * .31) * .04;
		}
		const b = wishVelocity(yaw, 0, 1);
		const lean = reduce ? 0 : -this.lastInputR * .028 * (moving ? 1 : 0);
		this.camera.rotation.order = "YXZ";
		this.camera.rotation.y = yaw;
		this.camera.rotation.x = pitch;
		this.camera.rotation.z = lean;
		this.camera.position.set(this.px + b.x * bobX + shakeX, EYE + bobY + shakeY, this.pz + b.z * bobX);
		const targetFov = this.sprinting && moving && !reduce ? 84 : 75;
		if (Math.abs(this.camera.fov - targetFov) > .04) {
			this.camera.fov += (targetFov - this.camera.fov) * (1 - Math.exp(-6 * dt));
			this.camera.updateProjectionMatrix();
		}
	}
	burst(x, y, z, hex, count) {
		this.color.set(hex);
		for (let n = 0; n < count; n++) {
			let slot = this.particles.findIndex((p) => p.life <= 0);
			if (slot < 0) slot = n % PARTICLE_MAX;
			const p = this.particles[slot];
			const ang = Math.random() * Math.PI * 2;
			const up = 1.2 + Math.random() * 2.4;
			const spd = .8 + Math.random() * 2.2;
			p.x = x;
			p.y = y;
			p.z = z;
			p.vx = Math.cos(ang) * spd;
			p.vz = Math.sin(ang) * spd;
			p.vy = up;
			p.life = .45 + Math.random() * .35;
			p.max = p.life;
			p.r = this.color.r;
			p.g = this.color.g;
			p.b = this.color.b;
		}
	}
	stepParticles(dt) {
		const pos = this.particlePos;
		const col = this.particleCol;
		for (let i = 0; i < PARTICLE_MAX; i++) {
			const p = this.particles[i];
			if (p.life > 0) {
				p.life -= dt;
				p.vy -= 4.5 * dt;
				p.x += p.vx * dt;
				p.y += p.vy * dt;
				p.z += p.vz * dt;
				if (p.y < .08) {
					p.y = .08;
					p.vy *= -.35;
					p.vx *= .7;
					p.vz *= .7;
				}
			}
			const k = p.life > 0 ? p.life / p.max : 0;
			pos[i * 3] = p.life > 0 ? p.x : 0;
			pos[i * 3 + 1] = p.life > 0 ? p.y : -40;
			pos[i * 3 + 2] = p.life > 0 ? p.z : 0;
			col[i * 3] = p.r * k;
			col[i * 3 + 1] = p.g * k;
			col[i * 3 + 2] = p.b * k;
		}
		const geo = this.points.geometry;
		geo.getAttribute("position").needsUpdate = true;
		geo.getAttribute("color").needsUpdate = true;
	}
	drawMap() {
		const ctx = this.map.getContext("2d");
		if (!ctx) return;
		const S = this.map.width || 384;
		if (this.map.height !== S) this.map.height = S;
		const maze = this.maze;
		const pad = 16;
		const inner = S - 32;
		const cw = inner / maze.w;
		const ch = inner / maze.h;
		ctx.clearRect(0, 0, S, S);
		ctx.fillStyle = "#163026";
		ctx.fillRect(0, 0, S, S);
		for (let z = 0; z < maze.h; z++) for (let x = 0; x < maze.w; x++) {
			if (!mapCellVisible(maze, x, z, this.visited)) continue;
			ctx.fillStyle = maze.walls[z * maze.w + x] === 1 ? "#2f7d4a" : "#f4ead4";
			ctx.fillRect(pad + x * cw, pad + z * ch, cw + .6, ch + .6);
		}
		for (let i = 0; i < maze.pickups.length; i++) {
			if (!this.alive[i]) continue;
			const p = maze.pickups[i];
			if (!this.visited[p.z * maze.w + p.x]) continue;
			ctx.fillStyle = "#e6a817";
			ctx.beginPath();
			ctx.arc(pad + (p.x + .5) * cw, pad + (p.z + .5) * ch, Math.max(2.5, cw * .16), 0, Math.PI * 2);
			ctx.fill();
		}
		if (this.visited[maze.exit.z * maze.w + maze.exit.x] === 1) {
			ctx.strokeStyle = "#ff6b4a";
			ctx.lineWidth = 3;
			ctx.beginPath();
			ctx.arc(pad + (maze.exit.x + .5) * cw, pad + (maze.exit.z + .5) * ch, cw * .28, 0, Math.PI * 2);
			ctx.stroke();
		}
		const px = pad + this.px / CELL * cw;
		const py = pad + this.pz / CELL * ch;
		ctx.save();
		ctx.translate(px, py);
		ctx.rotate(-this.yaw);
		ctx.fillStyle = "#1a2e24";
		ctx.beginPath();
		ctx.moveTo(0, -9);
		ctx.lineTo(6.5, 7);
		ctx.lineTo(-6.5, 7);
		ctx.closePath();
		ctx.fill();
		ctx.fillStyle = "#f0b429";
		ctx.beginPath();
		ctx.moveTo(0, -6.5);
		ctx.lineTo(4.2, 5);
		ctx.lineTo(-4.2, 5);
		ctx.closePath();
		ctx.fill();
		ctx.restore();
	}
	addClouds() {
		const mat = new MeshLambertMaterial({ color: 16777215 });
		const geo = new BoxGeometry(1, 1, 1);
		for (const [x, y, z, s] of [
			[
				-6,
				14,
				-6,
				7.5
			],
			[
				22,
				15,
				4,
				6
			],
			[
				8,
				16,
				26,
				8
			],
			[
				30,
				14.5,
				22,
				5.5
			],
			[
				-2,
				15.5,
				24,
				6.5
			]
		]) {
			const g = new Group();
			for (const [px, py, pz, sx, sy, sz] of [
				[
					0,
					0,
					0,
					1,
					.55,
					.8
				],
				[
					.7,
					.1,
					.1,
					.7,
					.42,
					.6
				],
				[
					-.65,
					.05,
					.05,
					.62,
					.4,
					.55
				]
			]) {
				const m = new Mesh(geo, mat);
				m.position.set(px, py, pz);
				m.scale.set(sx, sy, sz);
				g.add(m);
			}
			g.position.set(x, y, z);
			g.scale.setScalar(s);
			this.scene.add(g);
		}
	}
	clearWorld() {
		if (!this.world) return;
		this.scene.remove(this.world);
		const mats = /* @__PURE__ */ new Set();
		this.world.traverse((obj) => {
			const mesh = obj;
			if (mesh.geometry) mesh.geometry.dispose();
			const material = mesh.material;
			if (!material) return;
			const list = Array.isArray(material) ? material : [material];
			for (const m of list) mats.add(m);
		});
		for (const m of mats) m.dispose();
		this.world = null;
		this.gemMesh = null;
		this.haloMesh = null;
		this.ringA = null;
		this.ringB = null;
		this.disc = null;
	}
	buildWorld(maze) {
		this.clearWorld();
		const group = new Group();
		this.world = group;
		const width = maze.w * CELL;
		const depth = maze.h * CELL;
		const floorGeo = new PlaneGeometry(width, depth, maze.w, maze.h);
		floorGeo.rotateX(-Math.PI / 2);
		const colors = [];
		const pos = floorGeo.attributes.position;
		for (let i = 0; i < pos.count; i++) {
			const wx = pos.getX(i) + width / 2;
			const wz = pos.getZ(i) + depth / 2;
			let cx = Math.floor(wx / CELL);
			let cz = Math.floor(wz / CELL);
			cx = Math.max(0, Math.min(maze.w - 1, cx));
			cz = Math.max(0, Math.min(maze.h - 1, cz));
			const wall = maze.walls[cz * maze.w + cx] === 1;
			const exit = cx === maze.exit.x && cz === maze.exit.z;
			const start = cx === maze.start.x && cz === maze.start.z;
			if (exit) this.color.set("#f7d9a8");
			else if (start) this.color.set("#f4e7c4");
			else if (wall) this.color.set("#b7d7a2");
			else this.color.set(i % 3 === 0 ? "#e5f6cf" : "#d4eebc");
			colors.push(this.color.r, this.color.g, this.color.b);
		}
		floorGeo.setAttribute("color", new Float32BufferAttribute(colors, 3));
		const floor = new Mesh(floorGeo, new MeshStandardMaterial({
			vertexColors: true,
			roughness: 1,
			metalness: 0
		}));
		floor.position.set(width / 2, -.02, depth / 2);
		floor.receiveShadow = true;
		group.add(floor);
		let wallCount = 0;
		for (let i = 0; i < maze.walls.length; i++) if (maze.walls[i]) wallCount++;
		const box = new BoxGeometry(1, 1, 1);
		const hedgeMat = new MeshStandardMaterial({
			color: 16777215,
			roughness: .92,
			metalness: 0
		});
		const capMat = new MeshStandardMaterial({
			color: 16777215,
			roughness: .88,
			metalness: 0
		});
		const hedges = new InstancedMesh(box, hedgeMat, wallCount);
		const caps = new InstancedMesh(box, capMat, wallCount);
		hedges.castShadow = true;
		hedges.receiveShadow = true;
		caps.castShadow = true;
		let n = 0;
		for (let z = 0; z < maze.h; z++) for (let x = 0; x < maze.w; x++) {
			if (!maze.walls[z * maze.w + x]) continue;
			const hgt = 2.25 + (x * 13 + z * 7 + maze.seed) % 5 * .14;
			this.dummy.position.set((x + .5) * CELL, hgt / 2, (z + .5) * CELL);
			this.dummy.rotation.set(0, 0, 0);
			this.dummy.scale.set(1.02, hgt, 1.02);
			this.dummy.updateMatrix();
			hedges.setMatrixAt(n, this.dummy.matrix);
			this.color.set(HEDGE[(x + z * 3) % HEDGE.length]);
			hedges.setColorAt(n, this.color);
			this.dummy.position.set((x + .5) * CELL, hgt - .02, (z + .5) * CELL);
			this.dummy.scale.set(.78, .36, .78);
			this.dummy.updateMatrix();
			caps.setMatrixAt(n, this.dummy.matrix);
			this.color.set(CAPS[(x * 2 + z) % CAPS.length]);
			caps.setColorAt(n, this.color);
			n++;
		}
		hedges.instanceMatrix.needsUpdate = true;
		caps.instanceMatrix.needsUpdate = true;
		if (hedges.instanceColor) hedges.instanceColor.needsUpdate = true;
		if (caps.instanceColor) caps.instanceColor.needsUpdate = true;
		hedges.computeBoundingSphere();
		caps.computeBoundingSphere();
		group.add(hedges);
		group.add(caps);
		const gemGeo = new OctahedronGeometry(.24, 0);
		const gemMat = new MeshStandardMaterial({
			color: 15774761,
			emissive: 12880402,
			emissiveIntensity: .55,
			roughness: .32,
			metalness: .05
		});
		const gems = new InstancedMesh(gemGeo, gemMat, Math.max(1, maze.pickups.length));
		gems.count = maze.pickups.length;
		const haloGeo = new SphereGeometry(.42, 8, 6);
		const haloMat = new MeshBasicMaterial({
			color: 16770984,
			transparent: true,
			opacity: .38,
			depthWrite: false
		});
		const halos = new InstancedMesh(haloGeo, haloMat, Math.max(1, maze.pickups.length));
		halos.count = maze.pickups.length;
		this.gemMesh = gems;
		this.haloMesh = halos;
		group.add(gems);
		group.add(halos);
		const exit = cellCenter(maze.exit);
		const rot = gateRotY(maze);
		const gate = new Group();
		gate.position.set(exit.x, 0, exit.z);
		gate.rotation.y = rot;
		const ringMat = new MeshStandardMaterial({
			color: 16769690,
			emissive: 15774761,
			emissiveIntensity: .85,
			roughness: .35
		});
		const ring = new Mesh(new TorusGeometry(.86, .075, 5, 14), ringMat);
		ring.position.y = 1.15;
		ring.castShadow = true;
		const innerMat = new MeshStandardMaterial({
			color: 16761264,
			emissive: 16739146,
			emissiveIntensity: .7,
			roughness: .4
		});
		const ring2 = new Mesh(new TorusGeometry(.58, .045, 5, 12), innerMat);
		ring2.position.y = 1.15;
		const discMat = new MeshBasicMaterial({
			color: 16773577,
			transparent: true,
			opacity: .34,
			side: 2,
			depthWrite: false
		});
		const disc = new Mesh(new CircleGeometry(.5, 14), discMat);
		disc.position.y = 1.15;
		const pad = new Mesh(new CircleGeometry(.7, 14), new MeshStandardMaterial({
			color: 16243112,
			roughness: 1
		}));
		pad.rotation.x = -Math.PI / 2;
		pad.position.y = .025;
		const light = new PointLight(16761165, 6, 7, 2);
		light.position.y = 1.3;
		gate.add(ring, ring2, disc, pad, light);
		group.add(gate);
		this.ringA = ring;
		this.ringB = ring2;
		this.disc = disc;
		this.scene.add(group);
		this.animateProps();
	}
};
function wantsTouchLayout() {
	if (typeof window === "undefined") return false;
	return window.matchMedia("(pointer: coarse)").matches || window.innerWidth < 860;
}
var INITIAL = {
	phase: "menu",
	time: 0,
	collected: 0,
	total: 0,
	best: null,
	seed: 0,
	muted: false,
	newBest: false,
	perfect: false
};
function SunMark() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "grid size-12 shrink-0 place-items-center rounded-full bg-gold",
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-4 rounded-full bg-cream" })
	});
}
function Stick({ onChange }) {
	const base = (0, import_react.useRef)(null);
	const drag = (0, import_react.useRef)(false);
	const [knob, setKnob] = (0, import_react.useState)({
		x: 0,
		y: 0
	});
	function fromEvent(e) {
		const el = base.current;
		if (!el) return;
		const r = el.getBoundingClientRect();
		const max = r.width / 2;
		let dx = e.clientX - (r.left + r.width / 2);
		let dy = e.clientY - (r.top + r.height / 2);
		const len = Math.hypot(dx, dy) || 1;
		const clamped = Math.min(max, len);
		dx = dx / len * clamped;
		dy = dy / len * clamped;
		setKnob({
			x: dx,
			y: dy
		});
		onChange(dx / max, -dy / max);
	}
	function end() {
		drag.current = false;
		setKnob({
			x: 0,
			y: 0
		});
		onChange(0, 0);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: base,
		className: "absolute bottom-8 left-6 z-20 size-32 rounded-full border border-cream/50 bg-ink/35",
		style: { touchAction: "none" },
		onPointerDown: (e) => {
			drag.current = true;
			e.currentTarget.setPointerCapture(e.pointerId);
			e.stopPropagation();
			fromEvent(e);
		},
		onPointerMove: (e) => {
			if (drag.current) fromEvent(e);
		},
		onPointerUp: end,
		onPointerCancel: end,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "absolute left-1/2 top-1/2 size-14 rounded-full bg-cream shadow-md",
			style: { transform: `translate(calc(-50% + ${knob.x}px), calc(-50% + ${knob.y}px))` }
		})
	});
}
function MazeGame() {
	const viewRef = (0, import_react.useRef)(null);
	const mapRef = (0, import_react.useRef)(null);
	const engineRef = (0, import_react.useRef)(null);
	const lookId = (0, import_react.useRef)(null);
	const lookLast = (0, import_react.useRef)({
		x: 0,
		y: 0
	});
	const [hud, setHud] = (0, import_react.useState)(INITIAL);
	const [touch, setTouch] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const canvas = viewRef.current;
		const map = mapRef.current;
		if (!canvas || !map) return;
		const engine = new MazeEngine(canvas, map, setHud);
		engineRef.current = engine;
		window.__controlsTest = {
			getYaw: () => engine.yaw,
			getSpeed: () => engine.speed,
			getPos: () => ({
				x: engine.px,
				z: engine.pz
			}),
			setKeys: (codes) => engine.setKeys(codes)
		};
		return () => {
			engine.dispose();
			engineRef.current = null;
			delete window.__controlsTest;
		};
	}, []);
	(0, import_react.useEffect)(() => {
		const apply = () => {
			const on = wantsTouchLayout();
			setTouch(on);
			engineRef.current?.setTouchLayout(on);
		};
		apply();
		window.addEventListener("resize", apply);
		return () => window.removeEventListener("resize", apply);
	}, []);
	function onShellClick(e) {
		if (e.target.closest("button, a")) return;
		if (hud.phase === "play") engineRef.current?.lockPointer();
	}
	const playing = hud.phase === "play" || hud.phase === "paused";
	const seedLabel = hud.seed ? hud.seed.toString(36) : "—";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "relative h-dvh w-full overflow-hidden bg-sky text-ink",
		onClick: onShellClick,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: viewRef,
				className: "absolute inset-0 h-full w-full touch-none"
			}),
			hud.phase === "play" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute top-1/2 left-1/2 z-10 -translate-x-1/2 -translate-y-1/2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "crosshair" })
			}),
			touch && hud.phase === "play" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-y-0 right-0 z-10 w-3/5",
				style: { touchAction: "none" },
				onPointerDown: (e) => {
					lookId.current = e.pointerId;
					lookLast.current = {
						x: e.clientX,
						y: e.clientY
					};
					e.currentTarget.setPointerCapture(e.pointerId);
				},
				onPointerMove: (e) => {
					if (lookId.current !== e.pointerId) return;
					const dx = e.clientX - lookLast.current.x;
					const dy = e.clientY - lookLast.current.y;
					lookLast.current = {
						x: e.clientX,
						y: e.clientY
					};
					engineRef.current?.lookBy(dx, dy);
				},
				onPointerUp: () => {
					lookId.current = null;
				},
				onPointerCancel: () => {
					lookId.current = null;
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `safe-hud pointer-events-none absolute inset-x-0 top-0 z-30 flex items-start justify-between gap-2 ${playing ? "" : "hidden"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pointer-events-auto flex min-w-0 items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": hud.phase === "paused" ? "เล่นต่อ" : "หยุด",
							className: "grid size-11 shrink-0 place-items-center rounded-full bg-ink text-cream",
							onClick: (e) => {
								e.stopPropagation();
								if (hud.phase === "paused") engineRef.current?.resume();
								else engineRef.current?.pause();
							},
							children: hud.phase === "paused" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "chip min-w-0 rounded-full px-3 py-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "truncate font-display text-base leading-none font-semibold tabular-nums",
								children: [formatTime(hud.time), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-ink-soft",
									children: [
										" ",
										"· ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "hud-pop inline-block text-ink",
											children: hud.collected
										}, hud.collected),
										"/",
										hud.total
									]
								})]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": hud.muted ? "เปิดเสียง" : "ปิดเสียง",
							className: "grid size-11 shrink-0 place-items-center rounded-full chip text-ink",
							onClick: (e) => {
								e.stopPropagation();
								engineRef.current?.toggleMute();
							},
							children: hud.muted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-5" })
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "chip w-24 shrink-0 overflow-hidden rounded-2xl sm:w-44",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1 px-2 pt-1.5 text-xs font-bold text-leaf sm:px-3 sm:pt-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Map, { className: "size-3.5" }), "แผนที่"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
							ref: mapRef,
							width: 384,
							height: 384,
							className: "aspect-square w-full"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "px-2 pb-1.5 text-center text-xs font-semibold text-ink-soft tabular-nums sm:px-3 sm:pb-2",
							children: ["#", seedLabel]
						})
					]
				})]
			}),
			touch && hud.phase === "play" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stick, { onChange: (x, y) => engineRef.current?.setMoveAxis(x, y) }),
			hud.phase === "play" && hud.time < 6500 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: `pointer-events-none absolute inset-x-0 z-30 px-4 text-center ${touch ? "bottom-44" : "bottom-6"}`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "chip inline-block rounded-full px-4 py-2 text-sm font-semibold text-ink",
					children: touch ? "จอยซ้ายเดิน · ลากฝั่งขวาเพื่อหันมอง" : "WASD เดิน · เมาส์หันมอง · Shift วิ่ง"
				})
			}),
			hud.phase === "menu" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 z-40 flex items-center justify-center p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "panel max-h-full w-full max-w-md overflow-y-auto p-6 sm:p-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SunMark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-bold tracking-widest text-leaf",
								children: "SUNBLOOM"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "font-display text-4xl leading-snug font-bold sm:text-5xl",
								children: "สวนแสง"
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-pretty text-ink-soft",
							children: "เขาวงกตพุ่มไม้โลว์โพลี มุมมองบุคคลที่หนึ่ง เก็บผลแสงระหว่างทาง แล้วเดินเข้าประตูทองเพื่อออกจากสวน"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "mt-6 flex h-12 w-full items-center justify-center rounded-full bg-leaf text-base font-bold text-cream",
							onClick: () => engineRef.current?.beginFromMenu(),
							children: "เริ่มเดิน"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "mt-6 grid gap-3 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Keyboard, { className: "size-5 shrink-0 text-leaf" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "WASD หรือลูกศรเดิน · Shift วิ่ง · กำแพงจะเลื่อนตัว ไม่ดูดติด" })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mouse, { className: "size-5 shrink-0 text-leaf" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "คลิกเพื่อล็อกเมาส์แล้วหันมอง จอสัมผัสใช้จอยกับลากนิ้ว" })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-5 shrink-0 text-gold-deep" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "มินิแมปเปิดเฉพาะทางที่สำรวจแล้ว ไม่จำเป็นต้องเก็บผลแสงครบ" })]
								})
							]
						}),
						hud.best && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-5 text-sm font-semibold text-ink-soft tabular-nums",
							children: [
								"สถิติที่ดีที่สุด ",
								formatTime(hud.best.ms),
								" · ผลแสง ",
								hud.best.gems,
								"/",
								hud.best.total
							]
						})
					]
				})
			}),
			hud.phase === "paused" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 z-40 flex items-center justify-center bg-ink/25 p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "panel w-full max-w-sm p-6 sm:p-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-3xl font-bold",
							children: "พักสายตา"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-ink-soft tabular-nums",
							children: ["เวลาเดินไปแล้ว ", formatTime(hud.time)]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 grid gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: "flex h-12 items-center justify-center gap-2 rounded-full bg-leaf font-bold text-cream",
									onClick: () => engineRef.current?.resume(),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-5" }), "เล่นต่อ"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: "flex h-12 items-center justify-center gap-2 rounded-full border border-line bg-cream-2 font-bold",
									onClick: () => engineRef.current?.retry(false),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-5" }), "เริ่มแผนที่นี้ใหม่"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "flex h-12 items-center justify-center gap-2 rounded-full border border-line bg-cream-2 font-bold",
									onClick: () => engineRef.current?.toMenu(),
									children: "กลับเมนู"
								})
							]
						})
					]
				})
			}),
			hud.phase === "won" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 z-40 flex items-center justify-center bg-ink/20 p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "panel w-full max-w-sm p-6 text-center sm:p-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-bold tracking-widest text-leaf",
							children: "ทางออก"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-1 font-display text-4xl leading-snug font-bold",
							children: "ออกจากสวนแล้ว"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 font-display text-3xl font-bold tabular-nums",
							children: formatTime(hud.time)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 font-semibold text-ink-soft tabular-nums",
							children: [
								"ผลแสง ",
								hud.collected,
								"/",
								hud.total,
								hud.perfect ? " · เก็บครบ" : ""
							]
						}),
						hud.newBest && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 inline-block rounded-full bg-gold px-3 py-1 text-sm font-bold text-ink",
							children: "สถิติใหม่"
						}),
						!hud.newBest && hud.best && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-sm text-ink-soft tabular-nums",
							children: ["สถิติ ", formatTime(hud.best.ms)]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 grid gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "flex h-12 items-center justify-center gap-2 rounded-full bg-leaf font-bold text-cream",
								onClick: () => engineRef.current?.retry(true),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shuffle, { className: "size-5" }), "สุ่มเขาวงกตใหม่"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "flex h-12 items-center justify-center gap-2 rounded-full border border-line bg-cream-2 font-bold",
								onClick: () => engineRef.current?.retry(false),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-5" }), "เล่นแผนที่นี้อีกครั้ง"]
							})]
						})
					]
				})
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MazeGame, {});
}
//#endregion
export { Home as component };
