import { i as __toESM } from "../_runtime.mjs";
import { B as require_react, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as Bookmark, _ as Heart } from "../_libs/lucide-react.mjs";
import { t as BackButton } from "./back-button-DImimZOp.mjs";
import { r as TopBar, t as AppShell, u as useAppStore } from "./app-shell-C4IrQdCN.mjs";
import { t as TextLink } from "./text-link-CJNQ8wl3.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/favorites-g3t0Kue9.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function FavoritesPage() {
	const [tab, setTab] = (0, import_react.useState)("fav");
	const favorites = useAppStore((s) => s.favorites);
	const bookmarks = useAppStore((s) => s.bookmarks);
	const removeBookmark = useAppStore((s) => s.removeBookmark);
	const toggleFavorite = useAppStore((s) => s.toggleFavorite);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
			title: "المفضلة والعلامات",
			back: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackButton, { href: "/" })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-4 mt-3 grid grid-cols-2 gap-1 rounded-2xl bg-surface p-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: `h-10 rounded-xl text-sm ${tab === "fav" ? "bg-card" : "text-muted-foreground"}`,
				onClick: () => setTab("fav"),
				children: "المفضلة"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: `h-10 rounded-xl text-sm ${tab === "marks" ? "bg-card" : "text-muted-foreground"}`,
				onClick: () => setTab("marks"),
				children: "العلامات"
			})]
		}),
		tab === "fav" ? favorites.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
			icon: Heart,
			text: "لم تحفظ شيئًا بعد. أضف آية أو ذكرًا أو صفحة من متن."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-2 px-4 py-4",
			children: favorites.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "rounded-2xl bg-card p-4 shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TextLink, {
					href: f.href,
					className: "block",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-sage",
							children: labelKind(f.kind)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 font-medium",
							children: f.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 line-clamp-3 text-sm leading-7 text-muted-foreground",
							children: f.text
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "mt-2 text-xs text-muted-foreground",
					onClick: () => toggleFavorite(f),
					children: "إزالة"
				})]
			}, f.id))
		}) : bookmarks.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
			icon: Bookmark,
			text: "ضع علامة على موضع قراءة لتعود إليه لاحقًا."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-2 px-4 py-4",
			children: bookmarks.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-center gap-2 rounded-2xl bg-card px-4 py-3 shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextLink, {
					href: b.href,
					className: "flex-1",
					children: b.label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "text-xs text-muted-foreground",
					onClick: () => removeBookmark(b.id),
					children: "حذف"
				})]
			}, b.id))
		})
	] });
}
function labelKind(k) {
	if (k === "ayah") return "آية";
	if (k === "dhikr") return "ذكر";
	if (k === "dua") return "دعاء";
	if (k === "hadith") return "حديث";
	return "متن";
}
function Empty({ icon: Icon, text }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-8 py-16 text-center text-sm text-muted-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "mx-auto mb-3 size-8 opacity-40" }), text]
	});
}
//#endregion
export { FavoritesPage as component };
