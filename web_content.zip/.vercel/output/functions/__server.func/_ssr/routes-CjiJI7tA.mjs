import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { f as cn, l as LETTERS, s as useStars, u as groupByLetter } from "./router-CboP5aV-.mjs";
import { t as AppShell } from "./app-shell-Dk04OjoX.mjs";
import { t as StarPhoto } from "./star-photo-CYdE_HDR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CjiJI7tA.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AzJumper({ present, active, onJump }) {
	const railRef = (0, import_react.useRef)(null);
	const letterFromPoint = (0, import_react.useCallback)((clientY) => {
		const rail = railRef.current;
		if (!rail) return;
		const buttons = [...rail.querySelectorAll("[data-letter]")];
		if (buttons.length === 0) return;
		let closest = buttons[0];
		let best = Infinity;
		for (const btn of buttons) {
			const r = btn.getBoundingClientRect();
			const mid = r.top + r.height / 2;
			const d = Math.abs(mid - clientY);
			if (d < best) {
				best = d;
				closest = btn;
			}
		}
		const letter = closest.dataset.letter;
		if (letter) onJump(letter);
	}, [onJump]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: railRef,
		className: "az-rail pointer-events-auto sticky top-28 z-20 flex h-[min(72vh,36rem)] w-6 shrink-0 flex-col justify-between py-1 select-none",
		onPointerDown: (e) => {
			e.currentTarget.setPointerCapture(e.pointerId);
			letterFromPoint(e.clientY);
		},
		onPointerMove: (e) => {
			if (e.currentTarget.hasPointerCapture(e.pointerId)) letterFromPoint(e.clientY);
		},
		role: "navigation",
		"aria-label": "Jump to letter",
		children: LETTERS.map((letter) => {
			const enabled = present.has(letter);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"data-letter": letter,
				disabled: !enabled,
				onClick: () => enabled && onJump(letter),
				className: cn("flex h-full min-h-0 items-center justify-center text-[10px] font-medium leading-none", enabled ? "text-foreground" : "text-subtle/50", active === letter && enabled && "text-ivory"),
				"aria-label": `Jump to ${letter}`,
				children: letter
			}, letter);
		})
	});
}
function StarCard({ star }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/star/$slug",
		params: { slug: star.slug },
		className: cn("star-card group block rounded-lg outline-none", "focus-visible:ring-2 focus-visible:ring-ring"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative aspect-portrait overflow-hidden rounded-lg bg-card shadow-[var(--shadow-border)] transition-[box-shadow] duration-150 group-hover:shadow-[var(--shadow-border-hover)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StarPhoto, {
					star,
					className: "transition-transform duration-500 ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-[1.03]"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-gradient-to-t from-ink/80 via-ink/10 to-transparent" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute inset-x-0 bottom-0 p-2.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display text-lg font-medium leading-tight tracking-tight text-paper",
						children: star.name
					}), star.counts.total > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-0.5 text-xs tabular-nums text-ivory/80",
						children: [
							star.counts.total,
							" ",
							star.counts.total === 1 ? "file" : "files"
						]
					}) : null]
				}),
				star.favorite ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute right-2 top-2 size-1.5 rounded-full bg-ivory" }) : null
			]
		})
	});
}
function Home() {
	const stars = useStars();
	const [query, setQuery] = (0, import_react.useState)("");
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [active, setActive] = (0, import_react.useState)("A");
	const filtered = (0, import_react.useMemo)(() => {
		const q = query.trim().toLowerCase();
		return stars.filter((s) => {
			if (filter === "library" && s.counts.total === 0) return false;
			if (filter === "saved" && !s.favorite) return false;
			if (q && !s.name.toLowerCase().includes(q)) return false;
			return true;
		});
	}, [
		stars,
		query,
		filter
	]);
	const groups = (0, import_react.useMemo)(() => groupByLetter(filtered), [filtered]);
	const present = (0, import_react.useMemo)(() => new Set(groups.keys()), [groups]);
	function jump(letter) {
		setActive(letter);
		document.getElementById(`letter-${letter}`)?.scrollIntoView({
			behavior: "smooth",
			block: "start"
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		search: query,
		onSearch: setQuery,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-6xl gap-1 px-3 pb-16 pt-4 sm:px-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-5 flex flex-wrap items-end justify-between gap-3 pr-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground",
							children: "Performers"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-4xl font-medium tracking-tight sm:text-5xl",
							children: "The roster"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: [filtered.length.toLocaleString(), " profiles"]
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex rounded-lg bg-secondary p-1",
						children: [
							["all", "All"],
							["library", "Filed"],
							["saved", "Saved"]
						].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setFilter(id),
							className: `h-9 rounded-md px-3 text-sm ${filter === id ? "bg-card text-foreground" : "text-muted-foreground"}`,
							children: label
						}, id))
					})]
				}), filtered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "py-20 text-center text-sm text-muted-foreground",
					children: "No matches."
				}) : LETTERS.filter((L) => groups.has(L)).map((letter) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					id: `letter-${letter}`,
					className: "scroll-mt-28 mb-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "sticky top-[4.5rem] z-10 mb-3 bg-background/90 py-1 font-display text-3xl font-medium backdrop-blur-sm",
						children: letter
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-2 sm:grid-cols-3 sm:gap-3 md:grid-cols-4 lg:grid-cols-5",
						children: groups.get(letter).map((star) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StarCard, { star }, star.slug))
					})]
				}, letter))]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AzJumper, {
				present,
				active,
				onJump: jump
			})]
		})
	});
}
//#endregion
export { Home as component };
