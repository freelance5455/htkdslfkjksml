import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Info, c as ArrowRight, i as ShieldAlert, n as Shield, o as ExternalLink, r as ShieldCheck, s as Check, t as TriangleAlert } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as formatDistanceToNow } from "../_libs/date-fns.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BPwkw-Mn.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STALKERWARE = [
	"mspy",
	"flexispy",
	"hoverwatch",
	"thetruthspy",
	"cocospy",
	"spyic",
	"umobix",
	"kidsguard",
	"xnspy",
	"spyera",
	"pctattletale",
	"mobilespy",
	"highster",
	"spyfone",
	"letmespy",
	"theonespy",
	"spyhuman",
	"ikeymonitor",
	"spyzie",
	"mobistealth",
	"spybubble",
	"copy9",
	"ispyoo",
	"catwatchful",
	"webwatcher",
	"teensafe",
	"spyphone",
	"androidspy"
];
var MODDED = [
	"gbwhatsapp",
	"fmwhatsapp",
	"yowhatsapp",
	"ogwhatsapp",
	"whatsappplus",
	"whatsappgb",
	"instapro",
	"instagram++",
	"snapchat++",
	"youtubevanced",
	"fminstagram"
];
var BAD_CLEANERS = [
	"cleanmaster",
	"dubatterysaver",
	"duspeedbooster",
	"cmsecurity",
	"cheetahmobile"
];
var TRUSTED = /* @__PURE__ */ new Set([
	"whatsapp",
	"whatsappmessenger",
	"whatsappbusiness",
	"instagram",
	"chrome",
	"googlechrome",
	"safari",
	"gmail",
	"googlemaps",
	"maps",
	"youtube",
	"signal",
	"telegram",
	"bitwarden",
	"1password",
	"onepassword",
	"photos",
	"settings",
	"messages",
	"googlemessages",
	"playstore",
	"googleplay",
	"appstore",
	"firefox",
	"edge",
	"microsoftedge",
	"outlook",
	"slack",
	"zoom",
	"netflix",
	"spotify",
	"uber",
	"paypal",
	"amazon",
	"facebook",
	"messenger",
	"files",
	"camera",
	"phone",
	"contacts",
	"calendar",
	"notes",
	"findmy",
	"icloud"
]);
var PERMISSION_FLAGS = [
	{
		id: "access",
		label: "Accessibility — it can see and tap the screen",
		severity: "risk",
		detail: "Accessibility is the tool stalkerware uses to read chats and stay hidden. Turn it off, then remove the app."
	},
	{
		id: "admin",
		label: "Device administrator — hard to uninstall",
		severity: "risk",
		detail: "Remove the administrator right in system settings, then uninstall. Harmful apps use it so the Delete button does nothing."
	},
	{
		id: "sms",
		label: "Read or send text messages",
		severity: "risk",
		detail: "That can catch login codes and send texts on your bill. A game, cleaner, or “update” does not need it."
	},
	{
		id: "install",
		label: "Install unknown apps",
		severity: "risk",
		detail: "It can put more apps on the phone. Turn that permission off and delete the app that asked."
	},
	{
		id: "hidden",
		label: "The icon disappeared after install",
		severity: "risk",
		detail: "A hidden icon is a stalkerware habit. Search settings for the name, revoke administrator, and uninstall."
	},
	{
		id: "overlay",
		label: "Display over other apps",
		severity: "review",
		detail: "Some launchers need this. A cleaner or a random tool can use it to cover the screen with a fake login."
	},
	{
		id: "notify",
		label: "Read notifications from other apps",
		severity: "review",
		detail: "Notification access can read private messages. Only a tool you deliberately chose, like a watch or a car display, should have it."
	}
];
var RANK$1 = {
	clear: 0,
	info: 1,
	review: 2,
	risk: 3
};
function norm(value) {
	return value.toLowerCase().replace(/[^a-z0-9+]/g, "");
}
function includesName(query, name) {
	const needle = norm(name);
	return needle.length >= 4 && query.includes(needle);
}
function assessAppName(raw) {
	const query = raw.trim();
	if (query.length < 2) return null;
	const n = norm(query);
	if (!n) return null;
	if (TRUSTED.has(n)) return {
		severity: "clear",
		title: "Official name, nothing flagged",
		detail: `${query.trim()} matches a well-known app. Install it only from the App Store or Play Store. Modded copies — Plus, GB, FM, gold — are a common place for hidden malware.`,
		steps: ["Confirm the publisher in the store listing.", "If you sideloaded a copy, delete it and install the official one."],
		percent: 99
	};
	const stalker = STALKERWARE.find((name) => includesName(n, name));
	if (stalker) return {
		severity: "risk",
		title: "Known surveillance app",
		detail: `“${query.trim()}” matches ${stalker}, a product built to watch a phone: messages, location, photos, or all three. Security researchers and regulators have treated this family as stalkerware.`,
		steps: [
			"Uninstall it. If it will not leave, revoke Device admin and Accessibility first.",
			"Change mail, banking, and Apple or Google passwords from a different device.",
			"If someone else installed it, that is a safety issue, not only a phone issue."
		],
		percent: 18
	};
	if (MODDED.some((name) => n.includes(norm(name)))) return {
		severity: "risk",
		title: "Modded app — a common malware costume",
		detail: "Copies of WhatsApp, Instagram, Snapchat, and YouTube with Plus, GB, FM, or similar in the name are not the official app. The extra features are often bundled with spyware or adware.",
		steps: [
			"Delete the modded app.",
			"Install the official one from the store.",
			"Change the account password, and turn on two-step verification."
		],
		percent: 20
	};
	if (BAD_CLEANERS.some((name) => n.includes(name))) return {
		severity: "risk",
		title: "Unwanted cleaner, not real protection",
		detail: "This name belongs to a cleaner family that stores have removed over ads and data collection. A copy you find now is not protecting the phone.",
		steps: ["Uninstall it.", "On Android, rely on Play Protect. On iPhone, rely on the system itself."],
		percent: 22
	};
	if (/(viruscleaner|phonebooster|speedbooster|rambooster|junkcleaner|supercleaner|memorybooster|antivirusbooster|phonecleaner|batterysaver)/.test(n)) return {
		severity: "review",
		title: "Cleaner name — often adware",
		detail: "Names like booster, junk cleaner, and virus cleaner are a usual costume for annoying or harmful apps. The phone already knows how to free space.",
		steps: ["If it did not come from the phone maker or the official store, uninstall it.", "Ignore any screen that says the phone is badly infected and demands a download."],
		percent: 64
	};
	if (/(freewifipassword|wifihack|hackwifi|credithack|freerecharge|freeairtime|winiphone)/.test(n)) return {
		severity: "risk",
		title: "Too-good-to-be-true tool",
		detail: "Apps that promise free Wi-Fi passwords, free airtime, or a prize are a standard way to steal accounts or install more software.",
		steps: ["Delete it without opening it.", "If you already signed in, change that password from another device."],
		percent: 16
	};
	if (/(stalkerware|keylogger|keylog|hiddencamera|stealthmonitor)/.test(n)) return {
		severity: "risk",
		title: "Name says it is for spying",
		detail: "Anything sold as a hidden camera, keylogger, or stealth monitor does not belong on a phone you want to keep private.",
		steps: ["Uninstall it.", "Check Accessibility and device administrator for leftovers."],
		percent: 18
	};
	if (n.includes("spy")) return {
		severity: "review",
		title: "The name suggests spying",
		detail: "If this is a game or a book, you can ignore this note. If it is a tracker, a “family safety” tool you did not install, or something that hides its icon, treat it as stalkerware.",
		steps: ["Open the store page and read who publishes it.", "Remove it if you cannot explain why it is installed."],
		percent: 58
	};
	return {
		severity: "clear",
		title: "Nothing in the catalog flags this name",
		detail: "Aegis does not have a record of this name as a known harmful app. That is not a guarantee. What it asks to access matters more than a clean name.",
		steps: ["Check the permissions below against what the phone actually shows.", "Install only from the official store."],
		percent: null
	};
}
function combineAssessment(assessment, flagIds) {
	const flags = PERMISSION_FLAGS.filter((flag) => flagIds.includes(flag.id));
	if (!assessment && !flags.length) return null;
	const flagSeverity = flags.reduce((worst, flag) => RANK$1[flag.severity] > RANK$1[worst] ? flag.severity : worst, "clear");
	const base = assessment ?? {
		severity: "clear",
		title: "Permissions you reported",
		detail: "You have not searched a name yet. These are the permissions you said the app has.",
		steps: [],
		percent: null
	};
	if (!flags.length) return base;
	const flagPercent = flagSeverity === "risk" ? 20 : flagSeverity === "review" ? 66 : base.percent;
	if (RANK$1[flagSeverity] < RANK$1[base.severity]) return {
		...base,
		steps: [...base.steps, ...flags.map((flag) => flag.detail)]
	};
	const lead = flags.find((flag) => flag.severity === flagSeverity) ?? flags[0];
	const percent = base.percent == null ? flagPercent : Math.min(base.percent, flagPercent ?? base.percent);
	return {
		severity: RANK$1[flagSeverity] > RANK$1[base.severity] ? flagSeverity : base.severity,
		title: flagSeverity === "risk" ? "Dangerous permission reported" : flagSeverity === "review" && base.severity === "clear" ? "Permission worth checking" : base.title,
		detail: [lead?.detail, base.detail].filter(Boolean).join(" "),
		steps: [...base.steps, ...flags.map((flag) => flag.detail)],
		percent
	};
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function toneText(score) {
	if (score >= 90) return "text-pine";
	if (score >= 70) return "text-ink";
	return "text-clay";
}
function toneBar(score) {
	if (score >= 90) return "bg-pine";
	if (score >= 70) return "bg-ink";
	return "bg-clay";
}
function useCountUp(target) {
	const [value, setValue] = (0, import_react.useState)(target);
	const from = (0, import_react.useRef)(target);
	(0, import_react.useEffect)(() => {
		const startValue = from.current;
		from.current = target;
		if (window.matchMedia("(prefers-reduced-motion: reduce)").matches || startValue === target) {
			setValue(target);
			return;
		}
		const begun = performance.now();
		let frame = 0;
		const tick = (now) => {
			const t = Math.min(1, (now - begun) / 700);
			const eased = 1 - (1 - t) ** 3;
			setValue(Math.round(startValue + (target - startValue) * eased));
			if (t < 1) frame = requestAnimationFrame(tick);
		};
		frame = requestAnimationFrame(tick);
		return () => cancelAnimationFrame(frame);
	}, [target]);
	return value;
}
function PercentLockup({ value, large = false }) {
	const shown = useCountUp(value);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		"aria-label": `${value}% secured`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: cn("block font-display tabular-nums leading-none", large ? "text-7xl sm:text-8xl" : "text-5xl", toneText(value)),
			children: [shown, "%"]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("mt-1 block font-display leading-none text-ink italic", large ? "text-4xl sm:text-5xl" : "text-3xl"),
			children: "secured"
		})]
	});
}
function Meter({ label, score }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-w-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-baseline justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm text-muted",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: cn("font-display text-lg tabular-nums", score == null ? "text-muted" : "text-ink"),
				children: score == null ? "—" : `${score}%`
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2 h-1.5 overflow-hidden rounded-full bg-card",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("h-full rounded-full transition-[width] duration-700 ease-out", score == null ? "bg-line" : toneBar(score)),
				style: { width: score == null ? "0%" : `${score}%` }
			})
		})]
	});
}
var EXAMPLES = [
	"mSpy",
	"GBWhatsApp",
	"WhatsApp",
	"Super Cleaner"
];
function AppsPanel({ query, onQuery, flagIds, onToggleFlag, assessment }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl text-ink",
				children: "Could this app be harmful?"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-xl text-sm leading-relaxed text-muted",
				children: "Search a name or a package. Aegis compares it with known stalkerware, modded apps, and fake cleaners. Then match the permissions against what the phone actually shows."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-5 block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "sr-only",
					children: "App name"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: query,
					onChange: (event) => onQuery(event.target.value),
					placeholder: "App name or package",
					className: "h-12 w-full rounded-2xl bg-card px-4 text-base text-ink shadow-card outline-none placeholder:text-muted"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 flex flex-wrap gap-2",
				children: EXAMPLES.map((example) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onQuery(example),
					className: "h-10 rounded-full bg-paper-deep px-3 text-sm text-ink hover:bg-mist",
					children: example
				}, example))
			}),
			assessment ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
				className: cn("mt-5 rounded-3xl p-2 shadow-card", assessment.severity === "risk" ? "bg-clay-soft" : "bg-card"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl bg-card px-5 py-5",
					children: [
						assessment.percent != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PercentLockup, { value: assessment.percent }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-3xl text-ink italic",
							children: "No score yet"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-4 text-base font-medium text-ink",
							children: assessment.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed text-muted",
							children: assessment.detail
						}),
						assessment.steps.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
							className: "mt-4 grid gap-2",
							children: assessment.steps.map((step, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "text-sm leading-relaxed text-ink",
								children: step
							}, `${index}-${step}`))
						}) : null
					]
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 text-sm text-muted",
				children: "Try a name, or tick the permissions you see on the phone."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-10 font-display text-2xl text-ink",
				children: "Permissions on the phone"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-xl text-sm leading-relaxed text-muted",
				children: "Open the app’s settings and tick anything that is turned on. A normal camera or map app will not need the ones marked as dangerous."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 grid gap-2",
				children: PERMISSION_FLAGS.map((flag) => {
					const on = flagIds.includes(flag.id);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						"aria-pressed": on,
						onClick: () => onToggleFlag(flag.id),
						className: cn("flex min-h-11 w-full items-center gap-3 rounded-2xl px-4 py-3 text-left text-sm shadow-card", on && flag.severity === "risk" && "bg-clay text-paper", on && flag.severity !== "risk" && "bg-ink text-paper", !on && "bg-card text-ink"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("grid size-5 shrink-0 place-items-center rounded-full border", on ? "border-paper" : "border-line"),
							"aria-hidden": "true",
							children: on ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
								className: "size-3",
								strokeWidth: 2.5
							}) : null
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: flag.label })]
					}) }, flag.id);
				})
			})
		]
	});
}
var QUESTIONS = [
	{
		id: "lock",
		platforms: "all",
		prompt: "Does this device require a PIN, password, or biometrics to unlock?",
		riskIfYes: false,
		detail: "Set a lock. Without one, anyone holding the phone can install something, and some harmful apps are put there by a person who briefly has the device.",
		weight: 16
	},
	{
		id: "updates",
		platforms: "all",
		prompt: "Are system updates installed, with nothing important waiting?",
		riskIfYes: false,
		detail: "Install the update. Harmful apps often rely on bugs that the current system version has already closed.",
		weight: 16
	},
	{
		id: "unknown",
		platforms: "all",
		prompt: "Is there an app here you do not remember installing?",
		riskIfYes: true,
		detail: "Remove it. If it refuses to uninstall, it may have device-administrator rights. That is a common way stalkerware stays on a phone.",
		weight: 20
	},
	{
		id: "booster",
		platforms: "all",
		prompt: "Is a cleaner, booster, or “virus remover” app installed?",
		riskIfYes: true,
		detail: "Uninstall it. Phones do not need cleaner apps. That costume is a usual way adware gets in. Use Play Protect or the iPhone’s own system instead.",
		weight: 14
	},
	{
		id: "sideload-android",
		platforms: ["android"],
		prompt: "Do you install apps from outside the Play Store — files, links, or “unknown sources”?",
		riskIfYes: true,
		detail: "Turn installation from unknown sources off when you are finished. Most harmful Android apps arrive as a downloaded file, not from the store.",
		weight: 18
	},
	{
		id: "access",
		platforms: ["android"],
		prompt: "Does an app you do not fully trust have Accessibility or Device admin turned on?",
		riskIfYes: true,
		detail: "Turn those off, then uninstall the app. Accessibility can read the screen and tap buttons for you. Surveillance apps depend on it.",
		weight: 22
	},
	{
		id: "play",
		platforms: ["android"],
		prompt: "Is Google Play Protect turned on?",
		riskIfYes: false,
		detail: "Open the Play Store, tap your picture, then Play Protect, and turn scanning on. That is the real on-device check for harmful apps.",
		weight: 12
	},
	{
		id: "profile",
		platforms: ["ios"],
		prompt: "Is there a profile, or an app from outside the App Store, that you did not choose?",
		riskIfYes: true,
		detail: "Remove unknown profiles in Settings → General → VPN & Device Management. A profile you did not install can watch traffic or push extra apps.",
		weight: 20
	},
	{
		id: "jailbreak",
		platforms: ["ios"],
		prompt: "Is this iPhone jailbroken, or are you unsure?",
		riskIfYes: true,
		detail: "A jailbreak turns off core protections. If you did not do it on purpose, restore the phone or ask someone you trust for help.",
		weight: 18
	},
	{
		id: "apple-id",
		platforms: ["ios"],
		prompt: "Do you recognize every device signed in with your Apple ID?",
		riskIfYes: false,
		detail: "Check Settings → your name. Sign out of anything unfamiliar, then change the Apple ID password.",
		weight: 12
	},
	{
		id: "extensions",
		platforms: ["computer"],
		prompt: "Does the browser have an extension you do not remember adding?",
		riskIfYes: true,
		detail: "Remove it. An unknown extension can read pages, including mail and banking. On a computer, that is a common stand-in for a virus.",
		weight: 16
	},
	{
		id: "defender",
		platforms: ["computer"],
		prompt: "Is built-in protection on — Windows Security, or the protection that comes with the Mac?",
		riskIfYes: false,
		detail: "Turn it on and let a scan finish. You do not need a second cleaner suite beside it.",
		weight: 16
	},
	{
		id: "attachment",
		platforms: ["computer"],
		prompt: "Have you opened an installer or document that arrived in an unexpected email?",
		riskIfYes: true,
		detail: "Run the built-in scan, and change important passwords from a device you trust. Unexpected attachments are still how most computer viruses travel.",
		weight: 14
	}
];
function questionsFor(os) {
	return QUESTIONS.filter((question) => question.platforms === "all" || question.platforms.includes(os));
}
function isRiskyAnswer(question, answer) {
	return question.riskIfYes ? answer === "yes" : answer === "no";
}
function CheckupPanel({ report, os, answers, onAnswer, devicePercent, framed }) {
	const questions = questionsFor(os ?? "computer");
	if (!report) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl text-ink",
				children: "What the scan can see"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-xl text-sm leading-relaxed text-muted",
				children: "A website cannot list the other apps on a phone or walk the whole storage. No browser can — that wall is what stops a page from being the virus. Aegis checks what is actually visible, then asks you the rest."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-6 divide-y divide-line border-t border-line",
				children: [
					["Connection", "Whether this page is on a protected link."],
					["Browser", "Whether it is current enough to have recent security fixes."],
					["Network", "Whether a site can see a private address from this browser."],
					["Your answers", "Lock screen, updates, unknown apps, and store protections."]
				].map(([title, detail]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium text-ink",
						children: title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: detail
					})]
				}, title))
			})
		]
	});
	const issues = report.checks.filter((check) => check.severity === "risk" || check.severity === "review");
	const notes = report.checks.filter((check) => check.severity === "info");
	const passes = report.checks.filter((check) => check.severity === "clear");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-baseline justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl text-ink",
					children: "What turned up"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						report.environment.detail,
						" · ",
						formatDistanceToNow(report.at, { addSuffix: true })
					]
				})]
			}),
			framed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted",
				children: "Opened inside another page. The checks still describe this browser."
			}) : null,
			issues.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm leading-relaxed text-muted",
				children: "Nothing in the browser checks needs a fix. The percentage can still move when you answer the device questions below."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-4 divide-y divide-line border-t border-line",
				children: [issues.map((check) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Finding, {
					severity: check.severity,
					title: check.title,
					detail: check.detail
				}, check.id)), notes.map((check) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Finding, {
					severity: check.severity,
					title: check.title,
					detail: check.detail
				}, check.id))]
			}),
			passes.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
				className: "mt-4 border-t border-line",
				open: issues.length === 0,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("summary", {
					className: "cursor-pointer py-3 text-sm font-medium text-ink",
					children: [
						passes.length,
						" check",
						passes.length === 1 ? "" : "s",
						" passed"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "divide-y divide-line",
					children: passes.map((check) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Finding, {
						severity: check.severity,
						title: check.title,
						detail: check.detail
					}, check.id))
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-end justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl text-ink",
						children: "The part a browser cannot see"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 max-w-xl text-sm leading-relaxed text-muted",
						children: [
							"These answers change the device percentage. ",
							questions.length,
							" questions for",
							" ",
							report.environment.osLabel,
							"."
						]
					})] }), devicePercent != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-display text-xl text-ink",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "tabular-nums",
								children: [devicePercent, "%"]
							}),
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "italic",
								children: "secured"
							})
						]
					}) : null]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 divide-y divide-line border-t border-line",
					children: questions.map((question) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuestionRow, {
						question,
						answer: answers[question.id],
						onAnswer
					}, question.id))
				})]
			})
		]
	});
}
function Finding({ severity, title, detail }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "grid grid-cols-[auto_minmax(0,1fr)] gap-3 py-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { severity }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium text-ink",
				children: title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm leading-relaxed text-muted",
				children: detail
			})]
		})]
	});
}
function Mark({ severity }) {
	const className = "mt-0.5 size-5";
	if (severity === "risk") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, {
		className: cn(className, "text-clay"),
		"aria-hidden": "true"
	});
	if (severity === "review") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
		className: cn(className, "text-ink"),
		"aria-hidden": "true"
	});
	if (severity === "info") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
		className: cn(className, "text-muted"),
		"aria-hidden": "true"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, {
		className: cn(className, "text-pine"),
		"aria-hidden": "true"
	});
}
function QuestionRow({ question, answer, onAnswer }) {
	const risky = answer ? isRiskyAnswer(question, answer) : false;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "py-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium text-ink",
				children: question.prompt
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
					question,
					choice: "yes",
					answer,
					onAnswer
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
					question,
					choice: "no",
					answer,
					onAnswer
				})]
			}),
			answer && risky ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm leading-relaxed text-clay",
				children: question.detail
			}) : null
		]
	});
}
function Choice({ question, choice, answer, onAnswer }) {
	const selected = answer === choice;
	const risky = isRiskyAnswer(question, choice);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-pressed": selected,
		onClick: () => onAnswer(question.id, choice),
		className: cn("h-11 min-w-16 rounded-full px-4 text-sm font-medium transition-colors duration-200", selected && risky && "bg-clay text-paper", selected && !risky && "bg-pine text-paper", !selected && "bg-paper-deep text-ink"),
		children: choice === "yes" ? "Yes" : "No"
	});
}
var HIGH = /* @__PURE__ */ new Set([
	"exe",
	"scr",
	"bat",
	"cmd",
	"com",
	"pif",
	"msi",
	"dll",
	"vbs",
	"vbe",
	"jse",
	"wsf",
	"wsh",
	"ps1",
	"reg",
	"lnk",
	"hta",
	"cpl",
	"msc",
	"jar",
	"apk",
	"xapk",
	"apks",
	"dex",
	"elf"
]);
var SCRIPT = /* @__PURE__ */ new Set([
	"js",
	"sh",
	"command"
]);
var MACRO = /* @__PURE__ */ new Set([
	"docm",
	"xlsm",
	"pptm",
	"dotm",
	"xltm",
	"potm"
]);
var DISK = /* @__PURE__ */ new Set([
	"iso",
	"img",
	"dmg",
	"pkg"
]);
var LOOKS_SAFE = /* @__PURE__ */ new Set([
	"jpg",
	"jpeg",
	"png",
	"gif",
	"webp",
	"pdf",
	"txt",
	"mp4",
	"mov",
	"mp3",
	"heic",
	"csv",
	"doc",
	"docx",
	"xls",
	"xlsx",
	"ppt",
	"pptx",
	"html",
	"htm"
]);
var FULL_READ = 8388608;
function starts(bytes, magic) {
	if (bytes.length < magic.length) return false;
	return magic.every((value, index) => bytes[index] === value);
}
function sniff(head) {
	if (starts(head, [77, 90])) return "pe";
	if (starts(head, [
		127,
		69,
		76,
		70
	])) return "elf";
	if (head.length >= 4 && head[0] === 80 && head[1] === 75 && (head[2] === 3 || head[2] === 5 || head[2] === 7)) return "zip";
	if (starts(head, [
		37,
		80,
		68,
		70
	])) return "pdf";
	if (starts(head, [
		137,
		80,
		78,
		71
	])) return "png";
	if (starts(head, [
		255,
		216,
		255
	])) return "jpg";
	if (starts(head, [
		71,
		73,
		70
	])) return "gif";
	if (starts(head, [
		82,
		73,
		70,
		70
	]) && head.length > 12 && head[8] === 87 && head[9] === 69 && head[10] === 66 && head[11] === 80) return "webp";
	if (starts(head, [
		82,
		97,
		114,
		33
	])) return "rar";
	if (starts(head, [
		55,
		122,
		188,
		175,
		39,
		28
	])) return "7z";
	if (starts(head, [
		100,
		101,
		120,
		10
	])) return "dex";
	if (starts(head, [
		202,
		254,
		186,
		190
	])) return "class";
	if (starts(head, [
		254,
		237,
		250,
		206
	]) || starts(head, [
		254,
		237,
		250,
		207
	]) || starts(head, [
		206,
		250,
		237,
		254
	]) || starts(head, [
		207,
		250,
		237,
		254
	])) return "macho";
	if (starts(head, [
		208,
		207,
		17,
		224
	])) return "ole";
	if (head.length >= 2 && head[0] === 35 && head[1] === 33) return "script";
	return "unknown";
}
function baseName(name) {
	return name.split(/[/\\]/).pop() || name;
}
function extension(name) {
	const parts = baseName(name).split(".");
	if (parts.length < 2) return "";
	return parts[parts.length - 1]?.toLowerCase() ?? "";
}
function signalsFromName(name) {
	const signals = [];
	const parts = baseName(name).split(".");
	if (parts.length < 2) {
		signals.push({
			severity: "info",
			text: "There is no file extension. Judge it by where it came from, not by a missing name."
		});
		return signals;
	}
	const ext = parts[parts.length - 1]?.toLowerCase() ?? "";
	const disguised = parts.slice(0, -1).map((part) => part.toLowerCase()).some((part) => LOOKS_SAFE.has(part)) && (HIGH.has(ext) || SCRIPT.has(ext) || MACRO.has(ext));
	if (disguised) signals.push({
		severity: "risk",
		text: `The name is a disguise. It looks harmless, but “.${ext}” can run a program. Do not open it.`
	});
	if (HIGH.has(ext) && !disguised) {
		const android = ext === "apk" || ext === "xapk" || ext === "apks";
		signals.push({
			severity: "risk",
			text: android ? "This is an Android install file. Harmful apps usually arrive this way, outside the Play Store. Install it only when you trust the publisher, and check the name in Apps first." : `“.${ext}” can install or run a program. Open it only if you asked for this exact file and you know who sent it.`
		});
	}
	if (SCRIPT.has(ext) && !disguised) signals.push({
		severity: "review",
		text: "This is a script. It is fine if you wrote it, and a common virus shape if a stranger sent it."
	});
	if (MACRO.has(ext)) signals.push({
		severity: "review",
		text: "This Office file can contain macros, which are small programs. Do not enable macros unless you were expecting the file."
	});
	if (DISK.has(ext)) signals.push({
		severity: "review",
		text: "Disk images can start an installer as soon as they open. Continue only if you meant to download this."
	});
	if (ext === "html" || ext === "htm" || ext === "svg") signals.push({
		severity: "info",
		text: "Opening this in a browser can run code. That is normal for a page you saved, and a trick if it arrived as an invoice or a receipt."
	});
	return signals;
}
function executableKind(kind) {
	return kind === "pe" || kind === "elf" || kind === "dex" || kind === "macho" || kind === "script" || kind === "class";
}
function signalsFromKind(name, kind) {
	if (kind === "unknown") return [];
	const ext = extension(name);
	if ([
		"jpg",
		"jpeg",
		"png",
		"gif",
		"webp",
		"pdf",
		"txt",
		"mp3",
		"heic",
		"csv"
	].includes(ext) && (executableKind(kind) || kind === "zip")) return [{
		severity: "risk",
		text: `The name says “.${ext || "file"}”, but the contents are ${kind === "zip" ? "a package, often an app" : kind === "script" ? "a script" : "a program"}. Do not open it.`
	}];
	return [];
}
var EICAR_MARK = "EICAR-STANDARD-ANTIVIRUS-TEST-FILE";
function textOf(bytes) {
	try {
		return new TextDecoder("utf-8", { fatal: false }).decode(bytes);
	} catch {
		return "";
	}
}
function contentSignals(text, kind, ext) {
	const signals = [];
	if (/invoke-expression|\bpowershell\b[^\n]{0,80}-encodedcommand|\bpowershell\b[^\n]{0,40}\s-e(?:n|nc)\b/i.test(text)) signals.push({
		severity: "risk",
		text: "Contains an encoded PowerShell command, a common way harmful files hide what they run."
	});
	if (/wscript\.shell|shell\.application|adodb\.stream/i.test(text)) signals.push({
		severity: "risk",
		text: "Contains a Windows script that can start programs."
	});
	if (/eval\s*\([\s\S]{0,80}atob\s*\(|function\s*\(\s*\)\s*\{\s*return\s*atob/i.test(text) || /eval\s*\(/.test(text) && /fromcharcode|atob\s*\(/i.test(text)) signals.push({
		severity: "risk",
		text: "Contains hidden script built to conceal what it runs."
	});
	if (/\b(?:curl|wget)\b[^\n|]{0,160}\|\s*(?:ba)?sh\b/i.test(text) || /base64\s+-d[^\n|]{0,120}\|\s*(?:ba)?sh/i.test(text)) signals.push({
		severity: "risk",
		text: "Contains a command that downloads a program and runs it immediately."
	});
	if ((MACRO.has(ext) || kind === "ole") && /autoopen|auto_open|document_open/i.test(text)) signals.push({
		severity: "risk",
		text: "This document tries to run code as soon as it opens."
	});
	return signals;
}
function walkZip(bytes) {
	const entries = [];
	if (bytes.byteLength < 30) return entries;
	const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
	let offset = 0;
	while (offset + 30 <= bytes.length && entries.length < 60) {
		if (view.getUint32(offset, true) !== 67324752) break;
		const flags = view.getUint16(offset + 6, true);
		const method = view.getUint16(offset + 8, true);
		const compressed = view.getUint32(offset + 18, true);
		const uncompressed = view.getUint32(offset + 22, true);
		const nameLen = view.getUint16(offset + 26, true);
		const extraLen = view.getUint16(offset + 28, true);
		const nameStart = offset + 30;
		if (nameStart + nameLen > bytes.length) break;
		const name = textOf(bytes.subarray(nameStart, nameStart + nameLen));
		const dataStart = nameStart + nameLen + extraLen;
		if (flags & 8 && compressed === 0) {
			entries.push({
				name,
				method,
				data: null,
				uncompressed
			});
			break;
		}
		if (dataStart > bytes.length) break;
		const dataEnd = Math.min(bytes.length, dataStart + compressed);
		const complete = dataEnd === dataStart + compressed;
		entries.push({
			name,
			method,
			data: complete ? bytes.subarray(dataStart, dataEnd) : null,
			uncompressed
		});
		if (!complete) break;
		offset = dataEnd;
	}
	return entries;
}
async function inflateRaw(data) {
	const Stream = globalThis.DecompressionStream;
	if (!Stream || data.byteLength === 0 || data.byteLength > 15e5) return null;
	try {
		const copy = data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength);
		const stream = new Blob([copy]).stream().pipeThrough(new Stream("deflate-raw"));
		const buf = await new Response(stream).arrayBuffer();
		if (buf.byteLength > 6291456) return null;
		return new Uint8Array(buf);
	} catch {
		return null;
	}
}
async function packageSignals(bytes, ext, kind) {
	if (kind !== "zip" && ext !== "apk" && ext !== "xapk" && ext !== "apks" && ext !== "zip") return [];
	const entries = walkZip(bytes);
	if (!entries.length) return [];
	const signals = [];
	const interesting = entries.filter((entry) => /AndroidManifest\.xml$/i.test(entry.name) || /assets\/.+\.(dex|jar|apk|exe|so)$/i.test(entry.name) || /(^|\/)classes\d*\.dex$/i.test(entry.name));
	let corpus = "";
	for (const entry of interesting) {
		if (/assets\/.+\.(dex|jar|apk|exe)$/i.test(entry.name)) signals.push({
			severity: "risk",
			text: `Hidden program inside the package (${entry.name}). Ordinary apps do not hide an installer there.`
		});
		if (!entry.data) continue;
		if (entry.method === 0) corpus += `\n${textOf(entry.data)}`;
		else if (entry.method === 8 && entry.uncompressed < 4194304) {
			const inflated = await inflateRaw(entry.data);
			if (inflated) corpus += `\n${textOf(inflated)}`;
		}
	}
	corpus += `\n${textOf(bytes.subarray(0, Math.min(bytes.length, 4e5)))}`;
	const hit = [
		{
			id: "BIND_ACCESSIBILITY_SERVICE",
			severity: "risk",
			text: "This package can use Accessibility, which lets it read the screen and control other apps. Stalkerware depends on that."
		},
		{
			id: "BIND_DEVICE_ADMIN",
			severity: "risk",
			text: "This package asks to be a device administrator, which makes it hard to remove."
		},
		{
			id: "RECEIVE_SMS",
			severity: "review",
			text: "It can read incoming text messages, including login codes."
		},
		{
			id: "SEND_SMS",
			severity: "review",
			text: "It can send text messages from the phone."
		},
		{
			id: "REQUEST_INSTALL_PACKAGES",
			severity: "review",
			text: "It can ask the phone to install other apps."
		}
	].filter((perm) => corpus.includes(perm.id));
	for (const perm of hit) signals.push({
		severity: perm.severity,
		text: perm.text
	});
	if (hit.filter((perm) => perm.id.includes("SMS") || perm.id.includes("INSTALL")).length >= 2) signals.push({
		severity: "risk",
		text: "Several high-risk permissions show up together. That pattern is typical of a harmful app, not a normal tool."
	});
	return signals;
}
function summarize(signals, drill) {
	if (drill) return {
		severity: "info",
		title: "Harmless test file recognized"
	};
	if (signals.some((signal) => signal.severity === "risk")) return {
		severity: "risk",
		title: "Harmful pattern found"
	};
	if (signals.some((signal) => signal.severity === "review")) return {
		severity: "review",
		title: "Look before you open it"
	};
	if (signals.some((signal) => signal.severity === "info")) return {
		severity: "info",
		title: "No threat pattern, with a note"
	};
	return {
		severity: "clear",
		title: "No harmful pattern"
	};
}
async function sha256(bytes) {
	try {
		const copy = bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
		const digest = await crypto.subtle.digest("SHA-256", copy);
		return [...new Uint8Array(digest)].map((value) => value.toString(16).padStart(2, "0")).join("");
	} catch {
		return null;
	}
}
function reportFrom(name, size, signals, extra) {
	const drill = extra.drill ?? false;
	const summary = summarize(signals, drill);
	return {
		id: crypto.randomUUID(),
		name,
		size,
		sha256: extra.sha256 ?? null,
		partial: extra.partial ?? false,
		severity: summary.severity,
		title: summary.title,
		signals: drill ? [{
			severity: "info",
			text: "This is the industry test file used to prove a scanner is working. It is harmless, and it is not a virus on your device."
		}] : signals,
		drill
	};
}
function scanFileName(name) {
	const trimmed = name.trim();
	return reportFrom(trimmed || "untitled", null, signalsFromName(trimmed), {});
}
function eicarFile() {
	const text = [
		"X5O!P%@AP[4\\PZX54(P^)7CC)7}$",
		"EIC",
		"AR-",
		"STANDARD-",
		"ANTIVIRUS-",
		"TEST-",
		"FILE!$H+H*"
	].join("");
	return new File([text], "eicar-test.com", { type: "application/octet-stream" });
}
async function scanFile(file) {
	const nameSignals = signalsFromName(file.name);
	const partial = file.size > FULL_READ;
	const headBlob = partial ? file.slice(0, 524288) : file;
	const head = new Uint8Array(await headBlob.arrayBuffer());
	let sample = head;
	if (partial) {
		const tail = new Uint8Array(await file.slice(Math.max(0, file.size - 262144)).arrayBuffer());
		sample = new Uint8Array(head.length + tail.length);
		sample.set(head, 0);
		sample.set(tail, head.length);
	}
	const kind = sniff(head);
	const text = textOf(sample);
	const drill = text.includes(EICAR_MARK);
	const signals = [
		...nameSignals,
		...signalsFromKind(file.name, kind),
		...contentSignals(text, kind, extension(file.name)),
		...await packageSignals(head, extension(file.name), kind)
	];
	if (partial) signals.push({
		severity: "info",
		text: "This file is large, so only the beginning and the end were read on this device."
	});
	const hash = !partial && file.size <= 16777216 ? await sha256(head) : null;
	return reportFrom(file.name, file.size, signals, {
		sha256: hash,
		partial,
		drill
	});
}
function formatBytes(size) {
	if (size < 1024) return `${size} B`;
	if (size < 1048576) return `${Math.max(1, Math.round(size / 1024))} KB`;
	const mb = size / 1048576;
	return `${mb >= 10 ? Math.round(mb) : mb.toFixed(1)} MB`;
}
var BRANDS = [
	"paypal",
	"google",
	"apple",
	"microsoft",
	"amazon",
	"instagram",
	"whatsapp",
	"facebook",
	"netflix",
	"chase",
	"wellsfargo",
	"binance",
	"coinbase",
	"icloud",
	"outlook",
	"dropbox",
	"adobe",
	"linkedin",
	"tiktok",
	"telegram",
	"stripe",
	"venmo",
	"gmail",
	"dhl",
	"fedex"
];
var SHORTENERS = /* @__PURE__ */ new Set([
	"bit.ly",
	"tinyurl.com",
	"t.co",
	"goo.gl",
	"ow.ly",
	"is.gd",
	"cutt.ly",
	"tiny.cc",
	"rb.gy",
	"rebrand.ly",
	"buff.ly"
]);
var RANK = {
	clear: 0,
	info: 1,
	review: 2,
	risk: 3
};
function fold(value) {
	return value.toLowerCase().replace(/0/g, "o").replace(/1/g, "l").replace(/3/g, "e").replace(/5/g, "s").replace(/rn/g, "m");
}
function oneExtraIsDouble(longer, shorter) {
	for (let i = 0; i < longer.length; i += 1) if (longer.slice(0, i) + longer.slice(i + 1) === shorter) {
		const extra = longer[i];
		return extra === longer[i - 1] || extra === longer[i + 1];
	}
	return false;
}
function brandInside(label, brand) {
	if (!brand || label === brand || !label.includes(brand)) return false;
	if (label.startsWith(brand) && label.length - brand.length <= 14) return true;
	if (label.endsWith(brand)) {
		const extra = label.slice(0, -brand.length);
		return /[-.]|(login|secure|account|verify|update|signin|support)/.test(extra);
	}
	return false;
}
function lookalike(label, brand) {
	if (!label || label === brand) return false;
	const folded = fold(label);
	const foldedBrand = fold(brand);
	if (folded === foldedBrand) return label !== brand;
	if (Math.abs(folded.length - foldedBrand.length) !== 1) return false;
	if (folded.length > foldedBrand.length) return oneExtraIsDouble(folded, foldedBrand);
	return foldedBrand.length >= 6 && oneExtraIsDouble(foldedBrand, folded);
}
function splitHost(host) {
	const parts = host.toLowerCase().replace(/\.$/, "").split(".").filter(Boolean);
	const pair = parts.slice(-2).join(".");
	if ((/* @__PURE__ */ new Set([
		"co.uk",
		"com.au",
		"co.in",
		"com.br",
		"co.jp",
		"co.za",
		"com.mx"
	])).has(pair) && parts.length >= 3) return {
		label: parts[parts.length - 3] ?? "",
		subs: parts.slice(0, -3)
	};
	if (parts.length < 2) return {
		label: parts[0] ?? "",
		subs: []
	};
	return {
		label: parts[parts.length - 2] ?? "",
		subs: parts.slice(0, -2)
	};
}
function worst(signals) {
	return signals.reduce((best, signal) => RANK[signal.severity] > RANK[best] ? signal.severity : best, "clear");
}
function inspectLink(raw) {
	const input = raw.trim();
	if (!input) return null;
	const id = crypto.randomUUID();
	if (/^(javascript|data|file|blob):/i.test(input)) return {
		id,
		input,
		severity: "risk",
		title: "This link can run code",
		signals: [{
			severity: "risk",
			text: "The address is not a normal website. Do not open it. Links like this are used to run a script or a local file."
		}]
	};
	let url;
	try {
		url = new URL(input.includes("://") ? input : `https://${input}`);
	} catch {
		return {
			id,
			input,
			severity: "review",
			title: "Not a usable link",
			signals: [{
				severity: "review",
				text: "This could not be read as a web address. If it arrived in a text or email you were not expecting, do not open it."
			}]
		};
	}
	const signals = [];
	const host = url.hostname.toLowerCase();
	if (url.username || url.password) signals.push({
		severity: "risk",
		text: "The address hides the real site behind an @ sign. Everything before the @ is a disguise. Do not open it."
	});
	if (/^\d{1,3}(\.\d{1,3}){3}$/.test(host) || host.includes(":")) signals.push({
		severity: "review",
		text: "The site is a raw network address, not a name. Banks and stores do not ask you to sign in that way."
	});
	if (host.includes("xn--")) signals.push({
		severity: "review",
		text: "The address uses lookalike letters (punycode). Read it carefully before you type a password."
	});
	if (url.protocol === "http:") signals.push({
		severity: "review",
		text: "The link is not encrypted. Do not enter a password or download an app from it."
	});
	const { label, subs } = splitHost(host);
	const foldedLabel = fold(label);
	const siteIsKnown = BRANDS.includes(label);
	for (const brand of BRANDS) {
		if (!siteIsKnown) {
			for (const sub of subs) if (fold(sub) === fold(brand)) signals.push({
				severity: "risk",
				text: `“${brand}” is only a subdomain. The real site is “${label}”. This is a common sign-in trap.`
			});
		}
		if (!label || label === brand) continue;
		if (label.length >= 4 && lookalike(label, brand)) signals.push({
			severity: "risk",
			text: `“${label}” is a lookalike of ${brand}. The real site would use the exact name. Do not sign in.`
		});
		else if (brandInside(foldedLabel, fold(brand))) signals.push({
			severity: "risk",
			text: `The address borrows the name “${brand}” inside a longer word. Treat it as a fake unless you typed it yourself.`
		});
	}
	if (SHORTENERS.has(host)) signals.push({
		severity: "review",
		text: "This is a short link. It hides where you will actually land. If a stranger sent it, do not open it."
	});
	const tld = host.split(".").pop() ?? "";
	if ([
		"zip",
		"mov",
		"tk",
		"ml",
		"ga",
		"gq",
		"cf"
	].includes(tld)) signals.push({
		severity: "review",
		text: `The ending “.${tld}” is often used to dress up a download or a throwaway site. Confirm you asked for this link.`
	});
	if (!signals.length) {
		const known = BRANDS.find((brand) => label === brand);
		return {
			id,
			input,
			severity: "clear",
			title: known ? "Name matches the real one" : "Nothing in the address looks disguised",
			signals: [{
				severity: "clear",
				text: known ? `The main name is exactly “${known}”. Still read the full address before you sign in — a path or a page can still be misleading.` : "Aegis did not see a lookalike name, a hidden @ sign, or a code link. That is not proof the page is honest."
			}]
		};
	}
	const severity = worst(signals);
	return {
		id,
		input,
		severity,
		title: severity === "risk" ? "Do not open this link" : severity === "review" ? "Check this link before opening" : "Link note",
		signals
	};
}
function FilesPanel({ files, links, onFiles, onLinks, filesPercent }) {
	const [over, setOver] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(null);
	const [name, setName] = (0, import_react.useState)("");
	const [link, setLink] = (0, import_react.useState)("");
	async function take(list) {
		const batch = [...list].slice(0, 8);
		if (!batch.length) return;
		setBusy(`Reading ${batch.length === 1 ? batch[0].name : `${batch.length} files`}`);
		const next = [];
		for (const file of batch) {
			setBusy(`Reading ${file.name}`);
			next.push(await scanFile(file));
		}
		onFiles([...next, ...files].slice(0, 12));
		setBusy(null);
	}
	function addName(value) {
		const trimmed = value.trim();
		if (!trimmed) return;
		onFiles([scanFileName(trimmed), ...files].slice(0, 12));
		setName("");
	}
	function addLink(value) {
		const report = inspectLink(value);
		if (!report) return;
		onLinks([report, ...links].slice(0, 12));
		setLink("");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl text-ink",
					children: "Files and links"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-xl text-sm leading-relaxed text-muted",
					children: "Drop a download, type a suspicious name, or paste a link. Scanning happens on this device. Nothing is uploaded."
				})] }), filesPercent != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PercentLockup, { value: filesPercent }) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				onDragOver: (event) => {
					event.preventDefault();
					setOver(true);
				},
				onDragLeave: () => setOver(false),
				onDrop: (event) => {
					event.preventDefault();
					setOver(false);
					if (event.dataTransfer.files.length) take(event.dataTransfer.files);
				},
				className: cn("mt-5 rounded-3xl bg-card px-5 py-8 text-center shadow-card", over && "bg-mist"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl text-ink",
						children: "Drop files here"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mx-auto mt-2 max-w-sm text-sm text-muted",
						children: "On a phone, use the button. Photos, APKs, documents, and installers are all fine."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "mt-5 inline-flex h-12 cursor-pointer items-center rounded-full bg-pine px-5 text-sm font-medium text-paper hover:bg-pine-deep",
						children: ["Choose files", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "file",
							multiple: true,
							className: "sr-only",
							onChange: (event) => {
								if (event.target.files) take(event.target.files);
								event.target.value = "";
							}
						})]
					}),
					busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm text-pine",
						children: busy
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: (event) => {
						event.preventDefault();
						addName(name);
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "block text-sm font-medium text-ink",
						htmlFor: "file-name",
						children: "File name"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "file-name",
							value: name,
							onChange: (event) => setName(event.target.value),
							placeholder: "Invoice.pdf.exe",
							className: "h-12 min-w-0 flex-1 rounded-2xl bg-card px-4 text-base text-ink shadow-card outline-none placeholder:text-muted"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							className: "h-12 rounded-full bg-ink px-4 text-sm font-medium text-paper",
							children: "Check"
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: (event) => {
						event.preventDefault();
						addLink(link);
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "block text-sm font-medium text-ink",
						htmlFor: "link-name",
						children: "Link"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "link-name",
							value: link,
							onChange: (event) => setLink(event.target.value),
							placeholder: "https://…",
							inputMode: "url",
							className: "h-12 min-w-0 flex-1 rounded-2xl bg-card px-4 text-base text-ink shadow-card outline-none placeholder:text-muted"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							className: "h-12 rounded-full bg-ink px-4 text-sm font-medium text-paper",
							children: "Check"
						})]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => addName("Invoice.pdf.exe"),
						className: "h-10 rounded-full bg-paper-deep px-3 text-sm text-ink",
						children: "Invoice.pdf.exe"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => addLink("https://paypa1.com/signin"),
						className: "h-10 rounded-full bg-paper-deep px-3 text-sm text-ink",
						children: "paypa1.com"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => void take([eicarFile()]),
						className: "h-10 rounded-full bg-paper-deep px-3 text-sm text-ink",
						children: "Harmless test file"
					})
				]
			}),
			files.length + links.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-sm text-muted",
				children: "A clear result means no harmful pattern in the name or the bytes we could read. It is not a promise about files still sitting in a folder you did not open."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-6 grid gap-3",
				children: [files.map((file) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCard, { file }, file.id)), links.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-2xl bg-card px-4 py-4 shadow-card",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VerdictHead, {
						severity: item.severity,
						title: item.title,
						eyebrow: item.input,
						drill: false
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignalList, { signals: item.signals })]
				}, item.id))]
			}),
			files.length + links.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => {
					onFiles([]);
					onLinks([]);
				},
				className: "mt-4 h-11 text-sm text-muted hover:text-ink",
				children: "Clear results"
			}) : null
		]
	});
}
function FileCard({ file }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "rounded-2xl bg-card px-4 py-4 shadow-card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VerdictHead, {
				severity: file.severity,
				title: file.title,
				eyebrow: file.name,
				drill: Boolean(file.drill)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-xs text-muted",
				children: [file.size == null ? "Name only" : formatBytes(file.size), file.partial ? " · partial read" : ""]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignalList, { signals: file.signals }),
			file.sha256 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-xs leading-relaxed text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono break-all",
						children: file.sha256
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						className: "mt-1 flex items-center gap-1 text-pine",
						href: `https://www.virustotal.com/gui/file/${file.sha256}`,
						target: "_blank",
						rel: "noreferrer",
						children: ["Look up this fingerprint", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, {
							className: "size-3.5",
							"aria-hidden": "true"
						})]
					}),
					"Opens VirusTotal with the fingerprint only, not the file."
				]
			}) : null
		]
	});
}
function VerdictHead({ severity, title, eyebrow, drill }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid grid-cols-[auto_minmax(0,1fr)] gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(drill ? ShieldCheck : severity === "risk" ? ShieldAlert : severity === "review" ? TriangleAlert : ShieldCheck, {
			className: cn("mt-0.5 size-5", drill ? "text-pine" : severity === "risk" ? "text-clay" : severity === "review" ? "text-ink" : "text-pine"),
			"aria-hidden": "true"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "truncate text-xs text-muted",
				children: eyebrow
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium text-ink",
				children: title
			})]
		})]
	});
}
function SignalList({ signals }) {
	if (!signals.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-2 text-sm leading-relaxed text-muted",
		children: "Nothing in the name matched a harmful pattern."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "mt-2 grid gap-2",
		children: signals.map((signal) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
			className: "text-sm leading-relaxed text-muted",
			children: signal.text
		}, signal.text))
	});
}
function readBrowser(ua = navigator.userAgent) {
	for (const [re, name] of [
		[/Edg\/(\d+)/, "Edge"],
		[/OPR\/(\d+)/, "Opera"],
		[/CriOS\/(\d+)/, "Chrome"],
		[/FxiOS\/(\d+)/, "Firefox"],
		[/Firefox\/(\d+)/, "Firefox"],
		[/Chrome\/(\d+)/, "Chrome"],
		[/Version\/(\d+).+Safari\//, "Safari"]
	]) {
		const match = ua.match(re);
		if (match) return {
			name,
			major: Number(match[1])
		};
	}
	const brand = (navigator.userAgentData?.brands)?.find((item) => !/not.a.brand/i.test(item.brand) && !/chromium/i.test(item.brand));
	if (brand) {
		const major = Number(brand.version);
		return {
			name: brand.brand,
			major: Number.isFinite(major) ? major : null
		};
	}
	return {
		name: "This browser",
		major: null
	};
}
function detectEnvironment() {
	const ua = navigator.userAgent || "";
	const platform = navigator.platform || "";
	const touch = navigator.maxTouchPoints > 1;
	const iPad = /iPad/.test(ua) || platform === "MacIntel" && touch;
	const iPhone = /iPhone|iPod/.test(ua);
	const android = /Android/i.test(ua);
	let os = "computer";
	let osLabel = "Computer";
	if (iPad) {
		os = "ios";
		osLabel = "iPad";
	} else if (iPhone) {
		os = "ios";
		osLabel = "iPhone";
	} else if (android) {
		os = "android";
		osLabel = "Android";
	} else if (/Win/.test(platform)) osLabel = "Windows";
	else if (/Mac/.test(platform)) osLabel = "Mac";
	else if (/CrOS/.test(ua)) osLabel = "Chromebook";
	else if (/Linux/.test(platform) || /Linux/.test(ua)) osLabel = "Linux";
	const shortSide = Math.min(screen.width, screen.height);
	let form = "computer";
	if (iPad) form = "tablet";
	else if (os !== "computer") form = shortSide >= 700 ? "tablet" : "phone";
	const browser = readBrowser(ua);
	const browserLabel = browser.major ? `${browser.name} ${browser.major}` : browser.name;
	const memory = navigator.deviceMemory;
	const connection = navigator.connection;
	const bits = [osLabel, browserLabel];
	if (typeof memory === "number" && memory > 0) bits.push(`about ${memory} GB memory`);
	if (connection?.effectiveType) bits.push(connection.effectiveType);
	if (!navigator.onLine) bits.push("offline");
	return {
		os,
		form,
		osLabel,
		browserLabel,
		detail: bits.join(" · ")
	};
}
function pageIsFramed() {
	try {
		return window.self !== window.top;
	} catch {
		return true;
	}
}
function found(id, title, detail, severity, points) {
	return {
		id,
		title,
		detail,
		severity,
		points
	};
}
function withTimeout(work, ms, fallback) {
	return new Promise((resolve) => {
		const timer = setTimeout(() => resolve(fallback), ms);
		work.then((value) => {
			clearTimeout(timer);
			resolve(value);
		}, () => {
			clearTimeout(timer);
			resolve(fallback);
		});
	});
}
async function checkSecure() {
	const host = location.hostname;
	const local = host === "localhost" || host === "127.0.0.1" || host === "::1" || host === "[::1]";
	if (!window.isSecureContext) return found("secure", "Connection is not protected", "This page is not on a secure connection. On a phone or computer, don’t sign in or install apps from plain http sites, especially on public Wi-Fi.", "risk", 34);
	if (local) return found("secure", "Secure local session", "The browser treats this page as secure because it is local. On the public web, use the same rule: look for the lock before you sign in or install anything.", "clear", 0);
	return found("secure", "Connection is protected", "This page is on HTTPS, so a network cannot casually read it. That is the right baseline. It is not a scan of the rest of the device.", "clear", 0);
}
function browserAge(name, major) {
	const compared = name === "Opera" ? major + 14 : major;
	const row = {
		Chrome: [120, 131],
		Edge: [120, 131],
		Firefox: [122, 132],
		Safari: [17, 18]
	}[name === "Opera" ? "Chrome" : name];
	if (!row) return null;
	const [riskBelow, reviewBelow] = row;
	if (compared < riskBelow) return {
		severity: "risk",
		points: 18,
		phrase: "well behind on security fixes"
	};
	if (compared < reviewBelow) return {
		severity: "review",
		points: 8,
		phrase: "old enough that newer fixes are missing"
	};
	return null;
}
async function checkBrowser() {
	const browser = readBrowser();
	if (browser.major == null) return found("browser", "Browser version hidden", "This browser did not share a version number. If it is the one that came with the phone, check the store or system settings for an update.", "info", 0);
	const age = browserAge(browser.name, browser.major);
	if (!age) return found("browser", `${browser.name} ${browser.major} is current enough`, "An old browser is how a lot of “just a link” attacks still land. This one is inside a reasonable window. Keep automatic updates on.", "clear", 0);
	return found("browser", `${browser.name} ${browser.major} is ${age.phrase}`, "Update it in the App Store, Play Store, or the browser’s own menu. Security fixes ship with those updates, and harmful pages count on people skipping them.", age.severity, age.points);
}
function isPrivateLan(ip) {
	if (ip.startsWith("10.")) return true;
	if (ip.startsWith("192.168.")) return true;
	if (/^172\.(1[6-9]|2\d|3[0-1])\./.test(ip)) return true;
	if (ip.startsWith("fe80:")) return true;
	return false;
}
async function checkWebRtc() {
	const RTC = window.RTCPeerConnection;
	if (!RTC) return found("webrtc", "No local-network leak from this page", "This browser does not offer the network check harmful pages sometimes use to see a private address.", "clear", 0);
	const ips = /* @__PURE__ */ new Set();
	let pc = null;
	try {
		const foundIps = await withTimeout(new Promise((resolve) => {
			pc = new RTC({ iceServers: [] });
			const connection = pc;
			connection.createDataChannel("aegis");
			connection.onicecandidate = (event) => {
				if (!event.candidate) {
					resolve(ips);
					return;
				}
				const match = event.candidate.candidate.match(/([0-9]{1,3}(?:\.[0-9]{1,3}){3})|([a-zA-Z0-9.-]+\.local)/);
				if (match) ips.add(match[0]);
			};
			connection.createOffer().then((offer) => connection.setLocalDescription(offer));
			setTimeout(() => resolve(ips), 1200);
		}), 1600, ips);
		const lan = [...foundIps].filter(isPrivateLan);
		if (lan.length) return found("webrtc", "A private network address is visible", `A website can see a local address (${lan[0]}) from this browser. That helps a hostile page map the network you are on. Updating the browser usually hides it.`, "review", 8);
		return found("webrtc", "Local network address stays hidden", [...foundIps].some((ip) => ip.endsWith(".local")) ? "The browser offered only a random stand-in name, not your real network address. That is what you want." : "Nothing in this check exposed a private network address.", "clear", 0);
	} catch {
		return found("webrtc", "Network check skipped", "This browser blocked the local-network check. That is fine — the rest of the scan still counts.", "info", 0);
	} finally {
		pc?.close();
	}
}
async function queryPermission(name) {
	try {
		if (!navigator.permissions?.query) return "unknown";
		return (await navigator.permissions.query({ name })).state;
	} catch {
		return "unknown";
	}
}
async function checkPermissions() {
	const names = [
		"camera",
		"microphone",
		"geolocation",
		"notifications",
		"clipboard-read"
	];
	const granted = [];
	for (const name of names) if (await queryPermission(name) === "granted") granted.push(name);
	if (!granted.length) return found("permissions", "This page has no sensitive access", "Camera, microphone, location, notifications, and clipboard are not granted here. Aegis does not need them. Other sites are managed in the browser’s settings — a page cannot list those for you.", "clear", 0);
	return found("permissions", "This page already has access", `Granted to Aegis: ${granted.map((name) => name === "clipboard-read" ? "clipboard" : name).join(", ")}. This checkup does not use them. If you did not mean to allow that, revoke it in the browser’s site settings. Access given to other sites has to be reviewed there.`, "info", 0);
}
async function checkPasskeys() {
	if (window.isSecureContext && "PublicKeyCredential" in window) return found("passkeys", "Passkeys are available", "This device can use passkeys. They are harder to steal than a login code sent by text. Prefer them for mail, banking, and your Apple or Google account.", "clear", 0);
	return found("passkeys", "Passkeys are not available here", "A current phone browser can use passkeys. They are not a virus check, but they close the kind of text-message theft harmful apps aim for.", "info", 0);
}
async function checkCookies() {
	try {
		document.cookie = "aegis_probe=1; SameSite=Lax; path=/";
		const ok = document.cookie.includes("aegis_probe=");
		document.cookie = "aegis_probe=; Max-Age=0; path=/";
		if (!ok) return found("cookies", "Cookies are blocked", "This browser is refusing cookies. That is a privacy choice, not a sign of a virus. Some sign-in protections will not work until you allow them for sites you trust.", "info", 0);
	} catch {
		return found("cookies", "Cookies could not be checked", "The browser did not answer a cookie test. It does not change the rest of the result.", "info", 0);
	}
	return found("cookies", "Site storage works", "The browser can store a normal site cookie. Aegis uses that only if you stay on this page — the checkup result is kept on this device.", "clear", 0);
}
var CHECK_LABELS = [
	{
		id: "secure",
		label: "Secure connection"
	},
	{
		id: "browser",
		label: "Browser is current"
	},
	{
		id: "webrtc",
		label: "Network address privacy"
	},
	{
		id: "permissions",
		label: "Access this page holds"
	},
	{
		id: "passkeys",
		label: "Passkeys"
	},
	{
		id: "cookies",
		label: "Site storage"
	}
];
var RUNNERS = {
	secure: checkSecure,
	browser: checkBrowser,
	webrtc: checkWebRtc,
	permissions: checkPermissions,
	passkeys: checkPasskeys,
	cookies: checkCookies
};
function getCheckSpecs() {
	return CHECK_LABELS.map((item) => ({
		id: item.id,
		label: item.label,
		run: RUNNERS[item.id]
	}));
}
async function runSpec(spec) {
	try {
		return await spec.run();
	} catch {
		return found(spec.id, spec.label, "This check could not finish in this browser. The rest of the scan still counts.", "info", 0);
	}
}
function clampScore(points) {
	return Math.max(0, Math.min(100, 100 - points));
}
function devicePercent(browser, answers, questions) {
	const answered = questions.filter((question) => answers[question.id]);
	if (!answered.length) return browser;
	let got = 0;
	let total = 0;
	for (const question of answered) {
		total += question.weight;
		const answer = answers[question.id];
		if (answer && !isRiskyAnswer(question, answer)) got += question.weight;
	}
	const audit = total === 0 ? browser : Math.round(got / total * 100);
	return Math.round(browser * .45 + audit * .55);
}
function securedLabel(score) {
	if (score >= 97) return "Highly secured";
	if (score >= 90) return "Secured";
	if (score >= 75) return "Mostly secured";
	if (score >= 50) return "Partly secured";
	return "Not well secured";
}
function listPercent(items) {
	if (!items.length) return null;
	const scores = items.map((severity) => severity === "risk" ? 18 : severity === "review" ? 62 : severity === "info" ? 90 : 100);
	return Math.min(...scores);
}
function filesPercent(files, links) {
	return listPercent([...files.filter((file) => !file.drill).map((file) => file.severity), ...links.map((link) => link.severity)]);
}
function SecuredHero({ percent, caption, running, step, doneIds, device, apps, files, onScan }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "rounded-3xl bg-card p-2 shadow-card",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "rounded-2xl bg-paper px-5 py-6 sm:px-8 sm:py-8",
			children: running ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScanProgress, {
				step,
				doneIds
			}) : percent == null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Intro, { onScan }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Result, {
				percent,
				caption,
				device,
				apps,
				files,
				onScan
			})
		})
	});
}
function Intro({ onScan }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-medium tracking-widest text-pine uppercase",
			children: "For every device"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-3 max-w-xl font-display text-4xl leading-tight text-ink sm:text-5xl",
			children: "Is this device safe to trust?"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 max-w-xl text-base leading-relaxed text-muted",
			children: "Aegis checks the browser, the apps you ask about, and the files you choose. When the scan finishes you get a percentage — 90% secured, 99% secured, or lower when something needs a decision."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: onScan,
			className: "mt-6 inline-flex h-12 items-center gap-2 rounded-full bg-pine pr-4 pl-5 text-base font-medium text-paper transition-colors duration-200 hover:bg-pine-deep",
			children: ["Scan this device", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
				className: "size-4",
				"aria-hidden": "true"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 text-sm text-muted",
			children: "Works on iPhone, Android, and computers. Files never leave the device."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
			className: "mt-8 grid gap-4 border-t border-line pt-6 sm:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Promise$1, {
					title: "Device",
					text: "Connection, browser age, and the questions only you can answer."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Promise$1, {
					title: "Apps",
					text: "Stalkerware, modded apps, and fake cleaners — by name."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Promise$1, {
					title: "Files",
					text: "Disguised names, programs pretending to be photos, risky links."
				})
			]
		})
	] });
}
function Promise$1({ title, text }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm font-medium text-ink",
		children: title
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-1 text-sm leading-relaxed text-muted",
		children: text
	})] });
}
function ScanProgress({ step, doneIds }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-medium tracking-widest text-pine uppercase",
			children: "Scanning"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-3 font-display text-4xl text-ink",
			children: "Checking this device"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 max-w-lg text-base text-muted",
			children: "These are real checks this browser can run. Aegis will not invent a virus to scare you."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-6 divide-y divide-line",
			"aria-live": "polite",
			children: CHECK_LABELS.map((item) => {
				const done = doneIds.includes(item.id);
				const active = step === item.label;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center gap-3 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("grid size-6 place-items-center rounded-full", done ? "bg-mist text-pine" : "bg-paper-deep text-transparent"),
						"aria-hidden": "true",
						children: done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
							className: "size-3.5",
							strokeWidth: 2.5
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full bg-line" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: cn("text-sm", done || active ? "text-ink" : "text-muted"),
						children: [item.label, active && !done ? "…" : ""]
					})]
				}, item.id);
			})
		})
	] });
}
function Result({ percent, caption, device, apps, files, onScan }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start justify-between gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium tracking-widest text-pine uppercase",
				children: "Device result"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onScan,
				className: "inline-flex h-11 items-center rounded-full px-3 text-sm font-medium text-pine hover:bg-mist",
				children: "Scan again"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 grid items-end gap-8 sm:grid-cols-[minmax(0,1fr)_15rem]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PercentLockup, {
					value: percent,
					large: true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-base text-ink",
					children: securedLabel(percent)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 max-w-md text-sm leading-relaxed text-muted",
					children: caption
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
						label: "Device",
						score: device
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
						label: "Apps",
						score: apps
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
						label: "Files",
						score: files
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6 h-2 overflow-hidden rounded-full bg-paper-deep",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("h-full rounded-full bg-pine transition-[width] duration-700 ease-out", percent < 70 && "bg-clay", percent >= 70 && percent < 90 && "bg-ink"),
				style: { width: `${percent}%` }
			})
		})
	] });
}
function Wordmark() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "grid size-11 place-items-center rounded-2xl bg-pine text-paper shadow-card",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, {
				className: "size-5",
				"aria-hidden": "true"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "block font-display text-xl leading-none text-ink",
			children: "Aegis"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mt-1 block text-sm text-muted",
			children: "Device security"
		})] })]
	});
}
var STORAGE_KEY = "aegis-checkup-v1";
function Home() {
	const [tab, setTab] = (0, import_react.useState)("device");
	const [env, setEnv] = (0, import_react.useState)(null);
	const [framed, setFramed] = (0, import_react.useState)(false);
	const [report, setReport] = (0, import_react.useState)(null);
	const [running, setRunning] = (0, import_react.useState)(false);
	const [step, setStep] = (0, import_react.useState)(null);
	const [doneIds, setDoneIds] = (0, import_react.useState)([]);
	const [answers, setAnswers] = (0, import_react.useState)({});
	const [files, setFiles] = (0, import_react.useState)([]);
	const [links, setLinks] = (0, import_react.useState)([]);
	const [appQuery, setAppQuery] = (0, import_react.useState)("");
	const [flagIds, setFlagIds] = (0, import_react.useState)([]);
	const [loaded, setLoaded] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setEnv(detectEnvironment());
		setFramed(pageIsFramed());
		try {
			const raw = localStorage.getItem(STORAGE_KEY);
			if (raw) {
				const saved = JSON.parse(raw);
				if (saved.report) setReport(saved.report);
				if (saved.answers) setAnswers(saved.answers);
				if (saved.files) setFiles(saved.files);
				if (saved.links) setLinks(saved.links);
				if (typeof saved.appQuery === "string") setAppQuery(saved.appQuery);
				if (saved.flagIds) setFlagIds(saved.flagIds);
			}
		} catch {}
		setLoaded(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!loaded) return;
		const saved = {
			report,
			answers,
			files,
			links,
			appQuery,
			flagIds
		};
		localStorage.setItem(STORAGE_KEY, JSON.stringify(saved));
	}, [
		loaded,
		report,
		answers,
		files,
		links,
		appQuery,
		flagIds
	]);
	const runScan = (0, import_react.useCallback)(async () => {
		setTab("device");
		setRunning(true);
		setDoneIds([]);
		const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		const checks = [];
		for (const spec of getCheckSpecs()) {
			setStep(spec.label);
			checks.push(await runSpec(spec));
			setDoneIds((current) => [...current, spec.id]);
			if (!reduce) await new Promise((resolve) => setTimeout(resolve, 140));
		}
		const environment = detectEnvironment();
		setEnv(environment);
		const score = clampScore(checks.reduce((sum, check) => sum + check.points, 0));
		setReport({
			at: Date.now(),
			environment,
			checks,
			score
		});
		setStep(null);
		setRunning(false);
	}, []);
	const questions = questionsFor(env?.os ?? report?.environment.os ?? "computer");
	const device = report ? devicePercent(report.score, answers, questions) : null;
	const assessment = (0, import_react.useMemo)(() => combineAssessment(assessAppName(appQuery), flagIds), [appQuery, flagIds]);
	const apps = assessment?.percent ?? null;
	const fileScore = filesPercent(files, links);
	const caption = !report ? "" : Object.keys(answers).length === 0 ? "Browser checkup only. The questions under Device can raise or lower this." : "Browser checkup plus the device questions you answered.";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto min-h-screen max-w-3xl px-4 pt-6 pb-16 sm:px-6 sm:pt-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mb-6 flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wordmark, {}), env ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-full bg-card px-3 py-2 text-sm text-ink shadow-card",
					children: env.osLabel
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Phone or computer"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecuredHero, {
				percent: device,
				caption,
				running,
				step,
				doneIds,
				device,
				apps,
				files: fileScore,
				onScan: () => void runScan()
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 grid grid-cols-3 gap-1 rounded-2xl bg-paper-deep p-1",
				role: "tablist",
				children: [
					["device", "Device"],
					["apps", "Apps"],
					["files", "Files"]
				].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					role: "tab",
					"aria-selected": tab === id,
					onClick: () => setTab(id),
					className: cn("h-11 rounded-xl text-sm font-medium", tab === id ? "bg-card text-ink shadow-card" : "text-muted"),
					children: label
				}, id))
			}),
			tab === "device" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckupPanel, {
				report,
				os: env?.os ?? report?.environment.os ?? null,
				answers,
				onAnswer: (id, value) => setAnswers((current) => ({
					...current,
					[id]: value
				})),
				devicePercent: device,
				framed
			}) : null,
			tab === "apps" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppsPanel, {
				query: appQuery,
				onQuery: setAppQuery,
				flagIds,
				onToggleFlag: (id) => setFlagIds((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id]),
				assessment
			}) : null,
			tab === "files" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilesPanel, {
				files,
				links,
				onFiles: setFiles,
				onLinks: setLinks,
				filesPercent: fileScore
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "mt-12 border-t border-line pt-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-xl text-sm leading-relaxed text-muted",
					children: "90% and above means nothing Aegis could see looks harmful. A lower number always names the reason. This is a checkup, not a replacement for Play Protect or the protections built into the phone."
				})
			})
		]
	});
}
//#endregion
export { Home as component };
