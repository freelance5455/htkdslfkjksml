import { g as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { t as AppShell } from "./shell-CGpvgZIy.mjs";
import { a as SettingsPage } from "./desk-pages-BQQTtJ_U.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-DxuxJqzt.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = function SettingsRoute() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsPage, {}) });
};
//#endregion
export { SplitComponent as component };
