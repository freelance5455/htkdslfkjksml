import { n as useGameStore } from "./routes-gDa9Sa66.mjs";
import { C as TorusGeometry, S as SphereGeometry, T as Vector3, _ as PointLight, a as ConeGeometry, b as SRGBColorSpace, c as FogExp2, d as Mesh, f as MeshBasicMaterial, g as PlaneGeometry, h as PerspectiveCamera, i as Color, l as Group, m as MeshStandardMaterial, n as BoxGeometry, o as CylinderGeometry, p as MeshLambertMaterial, r as CanvasTexture, s as DirectionalLight, t as WebGLRenderer, u as HemisphereLight, v as Raycaster, w as Vector2, x as Scene, y as RepeatWrapping } from "../_libs/three.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/engine-Be9UHFo0.js
function noiseBuffer(ctx, seconds) {
	const n = Math.floor(ctx.sampleRate * seconds);
	const buf = ctx.createBuffer(1, n, ctx.sampleRate);
	const data = buf.getChannelData(0);
	for (let i = 0; i < n; i++) data[i] = Math.random() * 2 - 1;
	return buf;
}
var GameAudio = class {
	bus = null;
	noise = null;
	muted = false;
	lastStep = 0;
	unlock() {
		if (!this.bus) {
			const ctx = new (window.AudioContext || window.webkitAudioContext)({ latencyHint: "interactive" });
			const master = ctx.createGain();
			const sfx = ctx.createGain();
			sfx.gain.value = .9;
			master.gain.value = this.muted ? 0 : .7;
			sfx.connect(master);
			master.connect(ctx.destination);
			this.bus = {
				ctx,
				master,
				sfx
			};
			this.noise = noiseBuffer(ctx, .4);
		}
		if (this.bus.ctx.state === "suspended") this.bus.ctx.resume();
	}
	resume() {
		if (this.bus?.ctx.state === "suspended") this.bus.ctx.resume();
	}
	setMuted(muted) {
		this.muted = muted;
		if (!this.bus) return;
		this.bus.master.gain.setTargetAtTime(muted ? 0 : .7, this.bus.ctx.currentTime, .02);
	}
	env(gain, peak, attack, decay) {
		if (!this.bus) return;
		const t = this.bus.ctx.currentTime;
		gain.gain.setValueAtTime(1e-4, t);
		gain.gain.exponentialRampToValueAtTime(peak, t + attack);
		gain.gain.exponentialRampToValueAtTime(1e-4, t + attack + decay);
	}
	gunshot() {
		const bus = this.bus;
		if (!bus || !this.noise) return;
		const t = bus.ctx.currentTime;
		const src = bus.ctx.createBufferSource();
		src.buffer = this.noise;
		src.playbackRate.value = .9 + Math.random() * .25;
		const filter = bus.ctx.createBiquadFilter();
		filter.type = "lowpass";
		filter.frequency.setValueAtTime(2400, t);
		filter.frequency.exponentialRampToValueAtTime(280, t + .14);
		const g = bus.ctx.createGain();
		this.env(g, .9, .004, .16);
		src.connect(filter);
		filter.connect(g);
		g.connect(bus.sfx);
		src.start(t);
		src.stop(t + .2);
		const osc = bus.ctx.createOscillator();
		osc.type = "sine";
		osc.frequency.setValueAtTime(130 + Math.random() * 20, t);
		osc.frequency.exponentialRampToValueAtTime(38, t + .18);
		const og = bus.ctx.createGain();
		this.env(og, .55, .003, .18);
		osc.connect(og);
		og.connect(bus.sfx);
		osc.start(t);
		osc.stop(t + .22);
	}
	empty() {
		const bus = this.bus;
		if (!bus) return;
		const t = bus.ctx.currentTime;
		const osc = bus.ctx.createOscillator();
		osc.type = "square";
		osc.frequency.value = 190;
		const g = bus.ctx.createGain();
		this.env(g, .12, .001, .05);
		osc.connect(g);
		g.connect(bus.sfx);
		osc.start(t);
		osc.stop(t + .06);
	}
	reload() {
		const bus = this.bus;
		if (!bus) return;
		const t = bus.ctx.currentTime;
		for (let i = 0; i < 3; i++) {
			const osc = bus.ctx.createOscillator();
			osc.type = "triangle";
			osc.frequency.value = 420 - i * 70;
			const g = bus.ctx.createGain();
			const start = t + i * .09;
			g.gain.setValueAtTime(1e-4, start);
			g.gain.exponentialRampToValueAtTime(.18, start + .01);
			g.gain.exponentialRampToValueAtTime(1e-4, start + .08);
			osc.connect(g);
			g.connect(bus.sfx);
			osc.start(start);
			osc.stop(start + .1);
		}
	}
	hit() {
		const bus = this.bus;
		if (!bus || !this.noise) return;
		const t = bus.ctx.currentTime;
		const src = bus.ctx.createBufferSource();
		src.buffer = this.noise;
		const filter = bus.ctx.createBiquadFilter();
		filter.type = "lowpass";
		filter.frequency.value = 900;
		const g = bus.ctx.createGain();
		this.env(g, .35, .002, .08);
		src.connect(filter);
		filter.connect(g);
		g.connect(bus.sfx);
		src.start(t);
		src.stop(t + .1);
	}
	hurt() {
		const bus = this.bus;
		if (!bus) return;
		const t = bus.ctx.currentTime;
		const osc = bus.ctx.createOscillator();
		osc.type = "sawtooth";
		osc.frequency.setValueAtTime(180, t);
		osc.frequency.exponentialRampToValueAtTime(70, t + .22);
		const g = bus.ctx.createGain();
		this.env(g, .18, .01, .22);
		const filter = bus.ctx.createBiquadFilter();
		filter.type = "lowpass";
		filter.frequency.value = 500;
		osc.connect(filter);
		filter.connect(g);
		g.connect(bus.sfx);
		osc.start(t);
		osc.stop(t + .25);
	}
	groan() {
		const bus = this.bus;
		if (!bus) return;
		const t = bus.ctx.currentTime;
		const osc = bus.ctx.createOscillator();
		osc.type = "sawtooth";
		osc.frequency.setValueAtTime(90 + Math.random() * 40, t);
		osc.frequency.exponentialRampToValueAtTime(55, t + .5);
		const filter = bus.ctx.createBiquadFilter();
		filter.type = "lowpass";
		filter.frequency.value = 280;
		const g = bus.ctx.createGain();
		this.env(g, .1, .04, .45);
		osc.connect(filter);
		filter.connect(g);
		g.connect(bus.sfx);
		osc.start(t);
		osc.stop(t + .55);
	}
	kill() {
		const bus = this.bus;
		if (!bus) return;
		const t = bus.ctx.currentTime;
		const osc = bus.ctx.createOscillator();
		osc.type = "sine";
		osc.frequency.setValueAtTime(70, t);
		osc.frequency.exponentialRampToValueAtTime(32, t + .28);
		const g = bus.ctx.createGain();
		this.env(g, .28, .01, .28);
		osc.connect(g);
		g.connect(bus.sfx);
		osc.start(t);
		osc.stop(t + .3);
	}
	wave() {
		const bus = this.bus;
		if (!bus) return;
		const t = bus.ctx.currentTime;
		const osc = bus.ctx.createOscillator();
		osc.type = "triangle";
		osc.frequency.setValueAtTime(220, t);
		osc.frequency.exponentialRampToValueAtTime(330, t + .35);
		const g = bus.ctx.createGain();
		this.env(g, .16, .02, .4);
		osc.connect(g);
		g.connect(bus.sfx);
		osc.start(t);
		osc.stop(t + .42);
	}
	footstep(now) {
		if (now - this.lastStep < .38) return;
		this.lastStep = now;
		const bus = this.bus;
		if (!bus || !this.noise) return;
		const t = bus.ctx.currentTime;
		const src = bus.ctx.createBufferSource();
		src.buffer = this.noise;
		src.playbackRate.value = .5 + Math.random() * .2;
		const filter = bus.ctx.createBiquadFilter();
		filter.type = "lowpass";
		filter.frequency.value = 500;
		const g = bus.ctx.createGain();
		this.env(g, .08, .005, .07);
		src.connect(filter);
		filter.connect(g);
		g.connect(bus.sfx);
		src.start(t);
		src.stop(t + .09);
	}
};
var GAME_KEYS = /* @__PURE__ */ new Set([
	"KeyW",
	"KeyA",
	"KeyS",
	"KeyD",
	"ArrowUp",
	"ArrowDown",
	"ArrowLeft",
	"ArrowRight",
	"Space",
	"ShiftLeft",
	"ShiftRight",
	"KeyR",
	"Escape",
	"KeyF"
]);
function radialDeadzone(x, y, dz = .16) {
	const m = Math.hypot(x, y);
	if (m < dz) return {
		x: 0,
		y: 0
	};
	const scale = (m - dz) / (1 - dz) / m;
	return {
		x: x * scale,
		y: y * scale
	};
}
function clampMag(x, y) {
	const m = Math.hypot(x, y);
	if (m <= 1) return {
		x,
		y
	};
	return {
		x: x / m,
		y: y / m
	};
}
var Input = class {
	keys = /* @__PURE__ */ new Set();
	injected = /* @__PURE__ */ new Set();
	touchMoveX = 0;
	touchMoveY = 0;
	fireHeld = false;
	lookX = 0;
	lookY = 0;
	reloadQueued = false;
	pauseQueued = false;
	bound = false;
	onKeyDown = (e) => {
		if (GAME_KEYS.has(e.code)) e.preventDefault();
		this.keys.add(e.code);
		if (e.code === "KeyR") this.reloadQueued = true;
		if (e.code === "Escape") this.pauseQueued = true;
	};
	onKeyUp = (e) => {
		this.keys.delete(e.code);
	};
	onBlur = () => {
		this.keys.clear();
		this.fireHeld = false;
	};
	attach() {
		if (this.bound) return;
		this.bound = true;
		window.addEventListener("keydown", this.onKeyDown);
		window.addEventListener("keyup", this.onKeyUp);
		window.addEventListener("blur", this.onBlur);
		document.addEventListener("visibilitychange", this.onBlur);
	}
	detach() {
		if (!this.bound) return;
		this.bound = false;
		window.removeEventListener("keydown", this.onKeyDown);
		window.removeEventListener("keyup", this.onKeyUp);
		window.removeEventListener("blur", this.onBlur);
		document.removeEventListener("visibilitychange", this.onBlur);
		this.keys.clear();
	}
	addLook(dx, dy) {
		this.lookX += dx;
		this.lookY += dy;
	}
	setInjected(codes) {
		this.injected.clear();
		for (const c of codes) this.injected.add(c);
	}
	queueReload() {
		this.reloadQueued = true;
	}
	queuePause() {
		this.pauseQueued = true;
	}
	sample() {
		const down = this.injected.size ? this.injected : this.keys;
		let moveX = this.touchMoveX;
		let moveY = this.touchMoveY;
		if (down.has("KeyA") || down.has("ArrowLeft")) moveX -= 1;
		if (down.has("KeyD") || down.has("ArrowRight")) moveX += 1;
		if (down.has("KeyW") || down.has("ArrowUp")) moveY += 1;
		if (down.has("KeyS") || down.has("ArrowDown")) moveY -= 1;
		let padFire = false;
		const pads = typeof navigator !== "undefined" ? navigator.getGamepads?.() : null;
		if (pads) for (const pad of pads) {
			if (!pad || pad.mapping !== "standard") continue;
			const ls = radialDeadzone(pad.axes[0] ?? 0, pad.axes[1] ?? 0);
			moveX += ls.x;
			moveY -= ls.y;
			const rs = radialDeadzone(pad.axes[2] ?? 0, pad.axes[3] ?? 0, .12);
			this.lookX += rs.x * 14;
			this.lookY += rs.y * 14;
			if (pad.buttons[7]?.pressed || pad.buttons[0]?.pressed) padFire = true;
			if (pad.buttons[2]?.pressed) this.reloadQueued = true;
			if (pad.buttons[9]?.pressed) this.pauseQueued = true;
		}
		const move = clampMag(moveX, moveY);
		const lookDx = this.lookX;
		const lookDy = this.lookY;
		this.lookX = 0;
		this.lookY = 0;
		const fire = this.fireHeld || padFire || down.has("Space") || down.has("KeyF");
		const reload = this.reloadQueued;
		const pause = this.pauseQueued;
		this.reloadQueued = false;
		this.pauseQueued = false;
		return {
			moveX: move.x,
			moveY: move.y,
			lookDx,
			lookDy,
			fire,
			reload,
			sprint: down.has("ShiftLeft") || down.has("ShiftRight"),
			pause
		};
	}
};
var EYE = 1.62;
var RADIUS$1 = .38;
var WALK = 4.35;
var SPRINT = 6.5;
var ACCEL = 22;
function resolveCircleAabb(x, z, r, box) {
	const cx = Math.min(box.maxX, Math.max(box.minX, x));
	const cz = Math.min(box.maxZ, Math.max(box.minZ, z));
	let dx = x - cx;
	let dz = z - cz;
	const d2 = dx * dx + dz * dz;
	if (d2 >= r * r) return {
		x,
		z
	};
	if (d2 < 1e-8) {
		const left = x - box.minX;
		const right = box.maxX - x;
		const near = z - box.minZ;
		const far = box.maxZ - z;
		const m = Math.min(left, right, near, far);
		if (m === left) return {
			x: box.minX - r,
			z
		};
		if (m === right) return {
			x: box.maxX + r,
			z
		};
		if (m === near) return {
			x,
			z: box.minZ - r
		};
		return {
			x,
			z: box.maxZ + r
		};
	}
	const d = Math.sqrt(d2);
	const k = (r - d) / d;
	return {
		x: x + dx * k,
		z: z + dz * k
	};
}
var Player = class {
	yaw = 0;
	pitch = 0;
	x = 0;
	y = EYE;
	z = 12;
	vx = 0;
	vz = 0;
	dist = 0;
	invuln = 0;
	health = 100;
	pos = new Vector3();
	reset() {
		this.yaw = 0;
		this.pitch = 0;
		this.x = 0;
		this.z = 12;
		this.vx = 0;
		this.vz = 0;
		this.dist = 0;
		this.invuln = 0;
		this.health = 100;
	}
	get speed() {
		return Math.hypot(this.vx, this.vz);
	}
	look(dx, dy) {
		const s = .0022;
		this.yaw -= dx * s;
		this.pitch -= dy * s;
		const lim = Math.PI / 2 - .02;
		if (this.pitch > lim) this.pitch = lim;
		if (this.pitch < -lim) this.pitch = -lim;
	}
	update(dt, actions, colliders) {
		this.look(actions.lookDx, actions.lookDy);
		if (this.invuln > 0) this.invuln -= dt;
		const fx = -Math.sin(this.yaw);
		const fz = -Math.cos(this.yaw);
		const rx = Math.cos(this.yaw);
		const rz = -Math.sin(this.yaw);
		const wishX = rx * actions.moveX + fx * actions.moveY;
		const wishZ = rz * actions.moveX + fz * actions.moveY;
		const wishMag = Math.hypot(wishX, wishZ);
		const maxSpeed = actions.sprint ? SPRINT : WALK;
		let wx = 0;
		let wz = 0;
		if (wishMag > 1e-4) {
			wx = wishX / wishMag * maxSpeed;
			wz = wishZ / wishMag * maxSpeed;
		}
		if (wishMag > .05) {
			this.vx += (wx - this.vx) * Math.min(1, ACCEL * dt);
			this.vz += (wz - this.vz) * Math.min(1, ACCEL * dt);
		} else {
			const damp = Math.exp(-10 * dt);
			this.vx *= damp;
			this.vz *= damp;
			if (Math.hypot(this.vx, this.vz) < .02) {
				this.vx = 0;
				this.vz = 0;
			}
		}
		this.x += this.vx * dt;
		this.z += this.vz * dt;
		for (const box of colliders) {
			const n = resolveCircleAabb(this.x, this.z, RADIUS$1, box);
			this.x = n.x;
			this.z = n.z;
		}
		this.dist += this.speed * dt;
		this.pos.set(this.x, this.y, this.z);
	}
	applyToCamera(camera, bob, shake, extraPitch = 0) {
		const bobY = Math.sin(this.dist * 9) * bob;
		camera.position.set(this.x + shake.x, EYE + bobY + shake.y, this.z + shake.z);
		camera.rotation.order = "YXZ";
		camera.rotation.y = this.yaw;
		camera.rotation.x = this.pitch + extraPitch;
		camera.rotation.z = shake.x * .4;
	}
};
function mulberry32(seed) {
	let a = seed;
	return () => {
		a |= 0;
		a = a + 1831565813 | 0;
		let t = Math.imul(a ^ a >>> 15, 1 | a);
		t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
function canvasTexture(size, paint) {
	const c = document.createElement("canvas");
	c.width = c.height = size;
	const ctx = c.getContext("2d");
	if (!ctx) throw new Error("No 2D context");
	paint(ctx, mulberry32(size * 17 + 91));
	const tex = new CanvasTexture(c);
	tex.wrapS = RepeatWrapping;
	tex.wrapT = RepeatWrapping;
	tex.colorSpace = SRGBColorSpace;
	tex.anisotropy = 4;
	tex.needsUpdate = true;
	return tex;
}
var cache = null;
function getTextures() {
	if (cache) return cache;
	cache = {
		dirt: canvasTexture(256, (ctx, rnd) => {
			ctx.fillStyle = "#3d3428";
			ctx.fillRect(0, 0, 256, 256);
			for (let i = 0; i < 5200; i++) {
				const r = 70 + rnd() * 55;
				const g = 54 + rnd() * 36;
				const b = 36 + rnd() * 22;
				ctx.fillStyle = `rgba(${r | 0},${g | 0},${b | 0},${.18 + rnd() * .35})`;
				ctx.fillRect(rnd() * 256, rnd() * 256, 1 + rnd() * 3, 1 + rnd() * 2);
			}
		}),
		wood: canvasTexture(256, (ctx, rnd) => {
			ctx.fillStyle = "#5a4330";
			ctx.fillRect(0, 0, 256, 256);
			for (let x = 0; x < 256; x++) {
				const wobble = Math.sin(x * .08) * 8;
				ctx.strokeStyle = `rgba(${40 + rnd() * 30},${26 + rnd() * 16},${14 + rnd() * 10},${.35 + rnd() * .25})`;
				ctx.beginPath();
				ctx.moveTo(x, 0);
				ctx.lineTo(x + wobble, 256);
				ctx.stroke();
			}
			for (let i = 0; i < 40; i++) {
				ctx.fillStyle = `rgba(20,12,8,${.15 + rnd() * .2})`;
				ctx.fillRect(rnd() * 256, rnd() * 256, 2 + rnd() * 8, 8 + rnd() * 28);
			}
		}),
		plaster: canvasTexture(256, (ctx, rnd) => {
			ctx.fillStyle = "#c9c0ad";
			ctx.fillRect(0, 0, 256, 256);
			for (let i = 0; i < 3e3; i++) {
				ctx.fillStyle = `rgba(${180 + rnd() * 40},${170 + rnd() * 30},${150 + rnd() * 20},${.12 + rnd() * .2})`;
				ctx.fillRect(rnd() * 256, rnd() * 256, 1 + rnd() * 2, 1 + rnd() * 2);
			}
		}),
		stone: canvasTexture(256, (ctx, rnd) => {
			ctx.fillStyle = "#6a6560";
			ctx.fillRect(0, 0, 256, 256);
			for (let i = 0; i < 80; i++) {
				const x = rnd() * 256;
				const y = rnd() * 256;
				const w = 18 + rnd() * 40;
				const h = 12 + rnd() * 22;
				ctx.fillStyle = `rgba(${90 + rnd() * 40},${86 + rnd() * 30},${78 + rnd() * 24},0.7)`;
				ctx.fillRect(x, y, w, h);
				ctx.strokeStyle = "rgba(30,28,24,0.35)";
				ctx.strokeRect(x, y, w, h);
			}
		}),
		metal: canvasTexture(128, (ctx, rnd) => {
			ctx.fillStyle = "#3a3a38";
			ctx.fillRect(0, 0, 128, 128);
			for (let i = 0; i < 800; i++) {
				const v = 40 + rnd() * 50;
				ctx.fillStyle = `rgba(${v},${v},${v - 4},0.4)`;
				ctx.fillRect(rnd() * 128, rnd() * 128, 1, 1);
			}
		})
	};
	return cache;
}
function disposeTextures() {
	if (!cache) return;
	cache.dirt.dispose();
	cache.wood.dispose();
	cache.plaster.dispose();
	cache.stone.dispose();
	cache.metal.dispose();
	cache = null;
}
function makeSign(title, bg = "#4a3020", fg = "#e6dcc8") {
	const c = document.createElement("canvas");
	c.width = 256;
	c.height = 128;
	const ctx = c.getContext("2d");
	if (!ctx) throw new Error("No 2D context");
	ctx.fillStyle = bg;
	ctx.fillRect(0, 0, 256, 128);
	ctx.strokeStyle = "#2a1c12";
	ctx.lineWidth = 8;
	ctx.strokeRect(4, 4, 248, 120);
	ctx.fillStyle = fg;
	ctx.font = "700 42px Palatino, serif";
	ctx.textAlign = "center";
	ctx.textBaseline = "middle";
	ctx.fillText(title, 128, 64);
	const tex = new CanvasTexture(c);
	tex.colorSpace = SRGBColorSpace;
	tex.needsUpdate = true;
	return tex;
}
var Weapon = class {
	group = new Group();
	ammo = 6;
	reserve = 24;
	reloading = false;
	recoil = 0;
	reloadT = 0;
	cooldown = 0;
	kickZ = 0;
	flash = 0;
	sway = new Vector2();
	cylinder;
	flashMesh;
	flashLight;
	geos = [];
	mats = [];
	constructor() {
		const tex = getTextures();
		const metal = new MeshStandardMaterial({
			map: tex.metal,
			color: 2894890,
			metalness: .85,
			roughness: .35
		});
		const blued = new MeshStandardMaterial({
			color: 1711134,
			metalness: .9,
			roughness: .28
		});
		const grip = new MeshStandardMaterial({
			map: tex.wood,
			color: 7031344,
			roughness: .7,
			metalness: .05
		});
		this.mats.push(metal, blued, grip);
		const geo = (g) => {
			this.geos.push(g);
			return g;
		};
		const barrel = new Mesh(geo(new CylinderGeometry(.018, .02, .38, 8)), blued);
		barrel.rotation.x = Math.PI / 2;
		barrel.position.set(0, .04, -.28);
		this.group.add(barrel);
		const frame = new Mesh(geo(new BoxGeometry(.055, .09, .18)), metal);
		frame.position.set(0, .01, -.02);
		this.group.add(frame);
		this.cylinder = new Mesh(geo(new CylinderGeometry(.045, .045, .07, 10)), metal);
		this.cylinder.rotation.z = Math.PI / 2;
		this.cylinder.position.set(0, .03, .02);
		this.group.add(this.cylinder);
		const hammer = new Mesh(geo(new BoxGeometry(.02, .045, .04)), metal);
		hammer.position.set(0, .07, .08);
		this.group.add(hammer);
		const gripMesh = new Mesh(geo(new BoxGeometry(.045, .13, .07)), grip);
		gripMesh.position.set(0, -.07, .1);
		gripMesh.rotation.x = .35;
		this.group.add(gripMesh);
		const guard = new Mesh(geo(new TorusGeometry(.035, .006, 6, 10, Math.PI)), metal);
		guard.rotation.y = Math.PI / 2;
		guard.position.set(0, -.03, .05);
		this.group.add(guard);
		const sight = new Mesh(geo(new BoxGeometry(.01, .025, .02)), blued);
		sight.position.set(0, .07, -.44);
		this.group.add(sight);
		const flashMat = new MeshBasicMaterial({
			color: 16770720,
			transparent: true,
			opacity: 0,
			depthWrite: false
		});
		this.mats.push(flashMat);
		this.flashMesh = new Mesh(geo(new SphereGeometry(.05, 8, 8)), flashMat);
		this.flashMesh.position.set(0, .04, -.48);
		this.group.add(this.flashMesh);
		this.flashLight = new PointLight(16765056, 0, 3, 2);
		this.flashLight.position.set(0, .04, -.48);
		this.group.add(this.flashLight);
		this.group.position.set(.26, -.24, -.48);
		this.group.rotation.set(.06, .18, -.08);
	}
	reset() {
		this.ammo = 6;
		this.reserve = 24;
		this.reloading = false;
		this.reloadT = 0;
		this.cooldown = 0;
		this.recoil = 0;
	}
	tryFire() {
		if (this.reloading || this.cooldown > 0) return "blocked";
		if (this.ammo <= 0) return "empty";
		this.ammo -= 1;
		this.cooldown = .38;
		this.recoil = .085;
		this.kickZ = .06;
		this.flash = .05;
		this.cylinder.rotation.x += Math.PI / 3;
		return "shot";
	}
	beginReload() {
		if (this.reloading || this.ammo >= 6 || this.reserve <= 0) return false;
		this.reloading = true;
		this.reloadT = 2.05;
		return true;
	}
	update(dt, moving, lookDx, lookDy) {
		if (this.cooldown > 0) this.cooldown -= dt;
		if (this.flash > 0) {
			this.flash -= dt;
			const on = this.flash > 0;
			this.flashMesh.material.opacity = on ? .95 : 0;
			this.flashLight.intensity = on ? 4 : 0;
		}
		if (this.reloading) {
			this.reloadT -= dt;
			const p = 1 - this.reloadT / 2.05;
			this.group.rotation.x = .06 + Math.sin(p * Math.PI) * .55;
			this.cylinder.rotation.x += dt * 8;
			if (this.reloadT <= 0) {
				const need = 6 - this.ammo;
				const take = Math.min(need, this.reserve);
				this.ammo += take;
				this.reserve -= take;
				this.reloading = false;
				this.group.rotation.x = .06;
			}
		} else {
			this.recoil *= Math.exp(-10 * dt);
			this.kickZ *= Math.exp(-12 * dt);
		}
		this.sway.x += (lookDx * -.0012 - this.sway.x) * Math.min(1, 8 * dt);
		this.sway.y += (lookDy * -.001 - this.sway.y) * Math.min(1, 8 * dt);
		const bob = Math.sin(moving * 9) * .012 * Math.min(1, moving);
		this.group.position.set(.26 + this.sway.x, -.24 + bob - this.recoil * .4, -.48 + this.kickZ);
		if (!this.reloading) this.group.rotation.set(.06 + this.recoil, .18 + this.sway.x * .4, -.08);
	}
	addReserve(n) {
		this.reserve = Math.min(60, this.reserve + n);
	}
	dispose() {
		for (const g of this.geos) g.dispose();
		for (const m of this.mats) m.dispose();
	}
};
function aabb(x, z, w, d, h) {
	return {
		minX: x - w / 2,
		maxX: x + w / 2,
		minY: 0,
		maxY: h,
		minZ: z - d / 2,
		maxZ: z + d / 2
	};
}
function buildWorld(scene) {
	const tex = getTextures();
	const colliders = [];
	const hitMeshes = [];
	const lanterns = [];
	const geos = [];
	const mats = [];
	const extras = [];
	const wood = new MeshLambertMaterial({
		map: tex.wood,
		color: 12888194
	});
	const darkWood = new MeshLambertMaterial({
		map: tex.wood,
		color: 6967612
	});
	const plaster = new MeshLambertMaterial({
		map: tex.plaster,
		color: 14537663
	});
	const stone = new MeshLambertMaterial({ map: tex.stone });
	const dirt = new MeshLambertMaterial({
		map: tex.dirt,
		color: 10126440
	});
	const roof = new MeshLambertMaterial({ color: 3811874 });
	const iron = new MeshLambertMaterial({
		map: tex.metal,
		color: 4868680
	});
	const glow = new MeshBasicMaterial({ color: 16756832 });
	const windowMat = new MeshBasicMaterial({ color: 14719560 });
	mats.push(wood, darkWood, plaster, stone, dirt, roof, iron, glow, windowMat);
	tex.dirt.repeat.set(18, 18);
	tex.wood.repeat.set(2, 2);
	const track = (g) => {
		geos.push(g);
		return g;
	};
	const box = (w, h, d) => track(new BoxGeometry(w, h, d));
	const cyl = (rt, rb, h, seg = 8) => track(new CylinderGeometry(rt, rb, h, seg));
	const addMesh = (geo, mat, x, y, z, solid) => {
		const m = new Mesh(geo, mat);
		m.position.set(x, y, z);
		m.castShadow = false;
		m.receiveShadow = false;
		scene.add(m);
		hitMeshes.push(m);
		if (solid) colliders.push(aabb(x, z, solid.w, solid.d, solid.h));
		return m;
	};
	scene.background = new Color(1052172);
	scene.fog = new FogExp2(1052172, .024);
	const hemi = new HemisphereLight(12897760, 3023896, .72);
	scene.add(hemi);
	const moon = new DirectionalLight(15002613, .48);
	moon.position.set(-20, 40, -10);
	scene.add(moon);
	const moonBall = new Mesh(track(new SphereGeometry(5, 16, 16)), new MeshBasicMaterial({ color: 15264472 }));
	mats.push(moonBall.material);
	moonBall.position.set(-48, 56, -70);
	scene.add(moonBall);
	const ground = addMesh(track(new PlaneGeometry(120, 120)), dirt, 0, 0, 0);
	ground.rotation.x = -Math.PI / 2;
	tex.dirt.wrapS = tex.dirt.wrapT = RepeatWrapping;
	const wallH = 3.2;
	const bound = 24;
	addMesh(box(50, wallH, .6), darkWood, 0, wallH / 2, -24, {
		w: 50,
		d: .8,
		h: wallH
	});
	addMesh(box(50, wallH, .6), darkWood, 0, wallH / 2, bound, {
		w: 50,
		d: .8,
		h: wallH
	});
	addMesh(box(.6, wallH, 48), darkWood, -24, wallH / 2, 0, {
		w: .8,
		d: 48,
		h: wallH
	});
	addMesh(box(.6, wallH, 48), darkWood, bound, wallH / 2, 0, {
		w: .8,
		d: 48,
		h: wallH
	});
	const building = (x, z, w, d, h, mat) => {
		addMesh(box(w, h, d), mat, x, h / 2, z, {
			w,
			d,
			h
		});
		const roofMesh = addMesh(track(new ConeGeometry(Math.max(w, d) * .72, 1.6, 4)), roof, x, h + .7, z);
		roofMesh.rotation.y = Math.PI / 4;
		const win = box(.5, .7, .08);
		const faces = [
			[
				x,
				1.6,
				z + d / 2 + .02,
				0
			],
			[
				x,
				1.6,
				z - d / 2 - .02,
				Math.PI
			],
			[
				x + w / 2 + .02,
				1.6,
				z,
				Math.PI / 2
			],
			[
				x - w / 2 - .02,
				1.6,
				z,
				-Math.PI / 2
			]
		];
		for (const [wx, wy, wz, rot] of faces) {
			const m = addMesh(win, windowMat, wx, wy, wz);
			m.rotation.y = rot;
		}
	};
	building(0, -18.5, 10, 8, 6.2, plaster);
	addMesh(box(2.2, 5.5, 2.2), plaster, 0, 9.2, -18.5);
	const spire = addMesh(track(new ConeGeometry(1.4, 3.2, 4)), roof, 0, 13.4, -18.5);
	spire.rotation.y = Math.PI / 4;
	addMesh(box(.12, 1.1, .12), wood, 0, 15.2, -18.5);
	addMesh(box(.7, .12, .12), wood, 0, 15.45, -18.5);
	const churchSign = makeSign("CHURCH", "#3d3a34", "#ece4d4");
	extras.push(churchSign);
	const csMat = new MeshBasicMaterial({ map: churchSign });
	mats.push(csMat);
	addMesh(box(2.4, 1.1, .08), csMat, 0, 3.4, -14.4);
	building(16.5, -6, 9, 7, 5.2, darkWood);
	addMesh(box(9.4, 2.2, .3), wood, 16.5, 6.2, -2.55);
	const saloonSign = makeSign("SALOON", "#4a2418", "#e8d7b8");
	extras.push(saloonSign);
	const ssMat = new MeshBasicMaterial({ map: saloonSign });
	mats.push(ssMat);
	addMesh(box(3.4, 1.3, .1), ssMat, 16.5, 4.4, -2.4);
	building(-16.5, -7, 8, 7, 4.4, wood);
	building(-16, 8, 7.5, 6.5, 4.1, darkWood);
	building(16, 9, 8, 7, 4.6, wood);
	building(-7, 18, 8, 6, 4, wood);
	building(6.5, 18.5, 7, 5.5, 3.8, darkWood);
	building(-16.5, -16, 7, 6, 4.2, wood);
	const shSign = makeSign("SHERIFF", "#2c2418", "#d8cbb0");
	extras.push(shSign);
	const shMat = new MeshBasicMaterial({ map: shSign });
	mats.push(shMat);
	addMesh(box(2.8, 1.1, .08), shMat, -16.5, 3.2, -12.9);
	addMesh(cyl(.12, .14, 4.2, 6), darkWood, -1.4, 2.1, 0);
	addMesh(cyl(.12, .14, 4.2, 6), darkWood, 1.4, 2.1, 0);
	addMesh(box(3.2, .22, .22), darkWood, 0, 4.2, 0);
	addMesh(box(2.6, .16, 2.2), darkWood, 0, .1, 0);
	addMesh(cyl(.025, .025, 1.5, 5), iron, 0, 3.35, 0);
	const noose = addMesh(track(new TorusGeometry(.16, .025, 6, 10)), iron, 0, 2.5, 0);
	noose.rotation.x = Math.PI / 2;
	addMesh(cyl(.7, .78, .9, 10), stone, 5.5, .45, 5, {
		w: 1.5,
		d: 1.5,
		h: 1.1
	});
	addMesh(box(.1, 1.4, .1), darkWood, 5.1, 1.4, 5);
	addMesh(box(.1, 1.4, .1), darkWood, 5.9, 1.4, 5);
	addMesh(box(1.1, .1, .1), darkWood, 5.5, 2.1, 5);
	const barrelGeo = cyl(.32, .32, .72, 8);
	const crateGeo = box(.7, .7, .7);
	[
		[-4, 6],
		[-5.2, 6.5],
		[8, -4],
		[9, -3.4],
		[-8, -2],
		[3, -8],
		[11, 4],
		[-10, 4]
	].forEach(([x, z], i) => {
		if (i % 2 === 0) addMesh(barrelGeo, darkWood, x, .36, z, {
			w: .7,
			d: .7,
			h: .8
		});
		else addMesh(crateGeo, wood, x, .35, z, {
			w: .75,
			d: .75,
			h: .75
		});
	});
	addMesh(box(2.8, .7, 1.4), wood, -6, .7, -8, {
		w: 2.9,
		d: 1.5,
		h: 1.2
	});
	addMesh(track(new TorusGeometry(.42, .08, 6, 10)), darkWood, -7.1, .42, -8.7);
	addMesh(track(new TorusGeometry(.42, .08, 6, 10)), darkWood, -4.9, .42, -8.7);
	addMesh(track(new TorusGeometry(.42, .08, 6, 10)), darkWood, -7.1, .42, -7.3);
	addMesh(track(new TorusGeometry(.42, .08, 6, 10)), darkWood, -4.9, .42, -7.3);
	const stoneGeo = box(.35, .9, .12);
	for (let row = 0; row < 3; row++) for (let col = 0; col < 5; col++) {
		const head = addMesh(stoneGeo, stone, 12 + col * 1.5 + row % 2 * .3, .45, 13 + row * 1.7, {
			w: .4,
			d: .25,
			h: .9
		});
		head.rotation.y = (Math.random() - .5) * .25;
		head.rotation.z = (Math.random() - .5) * .12;
	}
	addMesh(box(8.5, .9, .12), iron, 15, .45, 11.6, {
		w: 8.5,
		d: .2,
		h: .9
	});
	for (const [x, z] of [
		[-10, 0],
		[10, -1],
		[-3, 10]
	]) addMesh(cyl(.08, .09, 1.2, 6), darkWood, x, .6, z);
	[
		[-9, -9],
		[9, -9],
		[-9, 9],
		[9, 9]
	].forEach(([x, z], i) => {
		addMesh(cyl(.08, .1, 2.6, 6), darkWood, x, 1.3, z);
		addMesh(track(new SphereGeometry(.14, 8, 8)), glow, x, 2.7, z);
		if (i < 4) {
			const light = new PointLight(16756832, 3.1, 16, 2);
			light.position.set(x, 2.7, z);
			scene.add(light);
			lanterns.push(light);
		}
	});
	return {
		colliders,
		hitMeshes,
		spawnPoints: [
			new Vector3(14, 0, 14),
			new Vector3(-14, 0, 14),
			new Vector3(14, 0, -10),
			new Vector3(-14, 0, -10),
			new Vector3(0, 0, 18),
			new Vector3(18, 0, 0),
			new Vector3(-18, 0, 2),
			new Vector3(8, 0, 16)
		],
		lanterns,
		dispose: () => {
			for (const g of geos) g.dispose();
			for (const m of mats) m.dispose();
			for (const t of extras) t.dispose();
		}
	};
}
var MAX = 16;
var RADIUS = .36;
var CLOTH = [
	3813928,
	2896680,
	4206632,
	2371624,
	3682348
];
var SKIN = [
	9079408,
	8025184,
	7236184,
	9471596
];
function makeRig(cloth, skin, geos) {
	const g = new Group();
	const box = (w, h, d) => {
		const geo = new BoxGeometry(w, h, d);
		geos.push(geo);
		return geo;
	};
	const torso = new Mesh(box(.4, .58, .24), cloth);
	torso.position.y = 1.08;
	g.add(torso);
	const head = new Mesh(box(.24, .26, .24), skin);
	head.position.y = 1.5;
	head.name = "head";
	g.add(head);
	const eyeMat = new MeshBasicMaterial({ color: 3803144 });
	const eyeL = new Mesh(box(.05, .04, .04), eyeMat);
	const eyeR = eyeL.clone();
	eyeL.position.set(-.06, 1.52, .12);
	eyeR.position.set(.06, 1.52, .12);
	g.add(eyeL, eyeR);
	const armL = new Group();
	const armR = new Group();
	const armMeshL = new Mesh(box(.1, .52, .1), skin);
	const armMeshR = new Mesh(box(.1, .52, .1), skin);
	armMeshL.position.y = -.22;
	armMeshR.position.y = -.22;
	armL.add(armMeshL);
	armR.add(armMeshR);
	armL.position.set(-.26, 1.28, 0);
	armR.position.set(.26, 1.28, 0);
	g.add(armL, armR);
	const legL = new Group();
	const legR = new Group();
	const legMeshL = new Mesh(box(.14, .7, .14), cloth);
	const legMeshR = new Mesh(box(.14, .7, .14), cloth);
	legMeshL.position.y = -.32;
	legMeshR.position.y = -.32;
	legL.add(legMeshL);
	legR.add(legMeshR);
	legL.position.set(-.12, .72, 0);
	legR.position.set(.12, .72, 0);
	g.add(legL, legR);
	g.traverse((o) => {
		o.castShadow = false;
	});
	return {
		mesh: g,
		head,
		armL,
		armR,
		legL,
		legR
	};
}
var ZombieHorde = class {
	pool = [];
	geos = [];
	extraMats = [];
	targets = [];
	constructor(scene) {
		for (let i = 0; i < MAX; i++) {
			const bodyMat = new MeshLambertMaterial({ color: CLOTH[i % CLOTH.length] });
			const skinMat = new MeshLambertMaterial({ color: SKIN[i % SKIN.length] });
			const rig = makeRig(bodyMat, skinMat, this.geos);
			rig.mesh.visible = false;
			rig.mesh.userData.zombieIndex = i;
			rig.mesh.traverse((o) => {
				o.userData.zombieIndex = i;
			});
			scene.add(rig.mesh);
			this.targets.push(rig.mesh);
			this.pool.push({
				alive: false,
				x: 0,
				z: 0,
				hp: 0,
				maxHp: 100,
				speed: 1.4,
				yaw: 0,
				attackCd: 0,
				phase: Math.random() * Math.PI * 2,
				dying: 0,
				flash: 0,
				mesh: rig.mesh,
				head: rig.head,
				armL: rig.armL,
				armR: rig.armR,
				legL: rig.legL,
				legR: rig.legR,
				bodyMat,
				skinMat
			});
		}
	}
	get aliveCount() {
		return this.pool.filter((z) => z.alive).length;
	}
	spawn(x, z, hp, speed) {
		const zed = this.pool.find((z) => !z.alive && z.dying <= 0);
		if (!zed) return false;
		zed.alive = true;
		zed.x = x;
		zed.z = z;
		zed.hp = hp;
		zed.maxHp = hp;
		zed.speed = speed;
		zed.yaw = Math.random() * Math.PI * 2;
		zed.attackCd = .4;
		zed.dying = 0;
		zed.flash = 0;
		zed.mesh.visible = true;
		zed.mesh.rotation.set(0, zed.yaw, 0);
		zed.mesh.position.set(x, 0, z);
		zed.mesh.scale.set(1, 1, 1);
		zed.bodyMat.emissive.setHex(0);
		zed.skinMat.emissive.setHex(0);
		return true;
	}
	reset() {
		for (const z of this.pool) {
			z.alive = false;
			z.dying = 0;
			z.mesh.visible = false;
		}
	}
	hitFromRay(hit, damageBody, damageHead) {
		const idx = hit.object.userData.zombieIndex;
		if (idx === void 0) return null;
		const z = this.pool[idx];
		if (!z?.alive) return null;
		let obj = hit.object;
		let isHead = false;
		while (obj) {
			if (obj.name === "head") {
				isHead = true;
				break;
			}
			obj = obj.parent;
		}
		z.hp -= isHead ? damageHead : damageBody;
		z.flash = .09;
		const point = hit.point.clone();
		if (z.hp <= 0) {
			z.alive = false;
			z.dying = .85;
		}
		return {
			index: idx,
			head: isHead,
			point,
			zombie: z
		};
	}
	update(dt, px, pz, colliders, onBite) {
		for (let i = 0; i < this.pool.length; i++) {
			const z = this.pool[i];
			if (z.dying > 0) {
				z.dying -= dt;
				const t = 1 - z.dying / .85;
				z.mesh.rotation.x = t * 1.35;
				z.mesh.position.y = -t * .15;
				z.mesh.scale.setScalar(1 - t * .15);
				if (z.dying <= 0) z.mesh.visible = false;
				continue;
			}
			if (!z.alive) continue;
			if (z.flash > 0) {
				z.flash -= dt;
				const lit = z.flash > 0;
				z.bodyMat.emissive.setHex(lit ? 4465176 : 0);
				z.skinMat.emissive.setHex(lit ? 3348488 : 0);
			}
			const dx = px - z.x;
			const dz = pz - z.z;
			const dist = Math.hypot(dx, dz) || .001;
			const nx = dx / dist;
			const nz = dz / dist;
			let sepX = 0;
			let sepZ = 0;
			for (let j = 0; j < this.pool.length; j++) {
				if (i === j) continue;
				const o = this.pool[j];
				if (!o.alive) continue;
				const sdx = z.x - o.x;
				const sdz = z.z - o.z;
				const sd = Math.hypot(sdx, sdz);
				if (sd > .01 && sd < .85) {
					sepX += sdx / sd * (.85 - sd);
					sepZ += sdz / sd * (.85 - sd);
				}
			}
			const lurch = .75 + .25 * Math.sin(z.phase + performance.now() * .004);
			z.x += (nx * z.speed * lurch + sepX * 1.6) * dt;
			z.z += (nz * z.speed * lurch + sepZ * 1.6) * dt;
			for (const box of colliders) {
				const n = resolveCircleAabb(z.x, z.z, RADIUS, box);
				z.x = n.x;
				z.z = n.z;
			}
			z.yaw = Math.atan2(nx, nz);
			z.mesh.position.set(z.x, 0, z.z);
			z.mesh.rotation.y = z.yaw;
			z.phase += dt * z.speed * 3.2;
			const swing = Math.sin(z.phase) * .55;
			z.legL.rotation.x = swing;
			z.legR.rotation.x = -swing;
			z.armL.rotation.x = -swing * .7 - .3;
			z.armR.rotation.x = swing * .7 - .3;
			if (z.attackCd > 0) z.attackCd -= dt;
			if (dist < 1.2 && z.attackCd <= 0) {
				z.attackCd = .85;
				onBite(14);
			}
		}
	}
	knockback(index, dirX, dirZ, amt) {
		const z = this.pool[index];
		if (!z?.alive) return;
		z.x += dirX * amt;
		z.z += dirZ * amt;
	}
	dispose() {
		for (const g of this.geos) g.dispose();
		for (const z of this.pool) {
			z.bodyMat.dispose();
			z.skinMat.dispose();
		}
		for (const m of this.extraMats) m.dispose();
	}
};
var KEY = "gallows-hollow-save";
var VERSION = 1;
var EMPTY = {
	version: VERSION,
	highScore: 0,
	bestWave: 0
};
function loadSave() {
	try {
		const raw = localStorage.getItem(KEY);
		if (!raw) return { ...EMPTY };
		const parsed = JSON.parse(raw);
		return {
			version: VERSION,
			highScore: Number(parsed.highScore) || 0,
			bestWave: Number(parsed.bestWave) || 0
		};
	} catch {
		return { ...EMPTY };
	}
}
function writeSave(data) {
	try {
		localStorage.setItem(KEY, JSON.stringify({
			...data,
			version: VERSION
		}));
	} catch {}
}
function recordRun(score, wave) {
	const prev = loadSave();
	const next = {
		version: VERSION,
		highScore: Math.max(prev.highScore, score),
		bestWave: Math.max(prev.bestWave, wave)
	};
	writeSave(next);
	return next;
}
var GameEngine = class {
	canvas;
	renderer;
	scene = new Scene();
	overlay = new Scene();
	camera;
	overlayCam;
	player = new Player();
	input = new Input();
	audio = new GameAudio();
	weapon;
	world;
	horde;
	raycaster = new Raycaster();
	ndc = new Vector2(0, 0);
	shake = new Vector3();
	trauma = 0;
	hitstop = 0;
	time = 0;
	last = 0;
	disposed = false;
	hadPointerLock = false;
	wave = 1;
	toSpawn = 0;
	spawnCd = 0;
	wavePause = 0;
	score = 0;
	kills = 0;
	bannerT = 0;
	reduceMotion = false;
	impacts = [];
	impactGeo;
	onPointerMove;
	onMouseDown;
	onMouseUp;
	onPointerLock;
	onVisibility;
	onResize;
	constructor(canvas) {
		this.canvas = canvas;
		const mobile = window.matchMedia("(pointer: coarse)").matches;
		this.reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		this.renderer = new WebGLRenderer({
			canvas,
			antialias: !mobile,
			powerPreference: "high-performance",
			alpha: false
		});
		this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, mobile ? 1.25 : 2));
		this.renderer.outputColorSpace = SRGBColorSpace;
		this.renderer.autoClear = false;
		this.camera = new PerspectiveCamera(78, 1, .08, 120);
		this.overlayCam = new PerspectiveCamera(70, 1, .05, 10);
		this.overlay.add(this.overlayCam);
		const gunLight = new HemisphereLight(16774372, 3811864, 1.6);
		this.overlay.add(gunLight);
		const gunDir = new DirectionalLight(16769712, 1.15);
		gunDir.position.set(.4, .8, 1);
		this.overlay.add(gunDir);
		this.weapon = new Weapon();
		this.overlayCam.add(this.weapon.group);
		this.world = buildWorld(this.scene);
		this.horde = new ZombieHorde(this.scene);
		this.impactGeo = new SphereGeometry(.06, 6, 6);
		const impactMat = new MeshBasicMaterial({
			color: 1708556,
			transparent: true,
			opacity: .8
		});
		for (let i = 0; i < 18; i++) {
			const m = new Mesh(this.impactGeo, impactMat.clone());
			m.visible = false;
			this.scene.add(m);
			this.impacts.push(m);
		}
		impactMat.dispose();
		this.input.attach();
		this.onResize = () => this.resize();
		this.onPointerMove = (e) => {
			if (document.pointerLockElement === this.canvas) this.input.addLook(e.movementX, e.movementY);
		};
		this.onMouseDown = (e) => {
			if (e.button === 0 && document.pointerLockElement === this.canvas) this.input.fireHeld = true;
		};
		this.onMouseUp = (e) => {
			if (e.button === 0 && document.pointerLockElement === this.canvas) this.input.fireHeld = false;
		};
		this.onPointerLock = () => {
			const locked = document.pointerLockElement === this.canvas;
			if (!locked && this.hadPointerLock && useGameStore.getState().phase === "playing") this.pause();
			this.hadPointerLock = locked;
		};
		this.onVisibility = () => {
			if (document.visibilityState === "visible") this.audio.resume();
			if (document.visibilityState === "hidden" && useGameStore.getState().phase === "playing") this.pause();
		};
		window.addEventListener("resize", this.onResize);
		document.addEventListener("mousemove", this.onPointerMove);
		document.addEventListener("mousedown", this.onMouseDown);
		document.addEventListener("mouseup", this.onMouseUp);
		document.addEventListener("pointerlockchange", this.onPointerLock);
		document.addEventListener("visibilitychange", this.onVisibility);
		this.resize();
		this.placeTitleZombies();
		const save = loadSave();
		useGameStore.setState({
			ready: true,
			phase: "title",
			highScore: save.highScore,
			bestWave: save.bestWave
		});
		window.__controlsTest = this.probe();
		window.__startGame = () => this.start();
		this.last = performance.now();
		this.renderer.setAnimationLoop(this.loop);
	}
	probe() {
		return {
			getYaw: () => this.player.yaw,
			getSpeed: () => this.player.speed,
			getX: () => this.player.x,
			getZ: () => this.player.z,
			getAmmo: () => this.weapon.ammo,
			setKeys: (codes) => this.input.setInjected(codes)
		};
	}
	resize() {
		const w = this.canvas.clientWidth || 1;
		const h = this.canvas.clientHeight || 1;
		this.renderer.setSize(w, h, false);
		this.camera.aspect = w / h;
		this.camera.updateProjectionMatrix();
		this.overlayCam.aspect = w / h;
		this.overlayCam.updateProjectionMatrix();
	}
	tryPointerLock() {
		const fn = this.canvas.requestPointerLock;
		try {
			const res = fn.call(this.canvas, { unadjustedMovement: true });
			if (res && typeof res.catch === "function") res.catch(() => {
				try {
					this.canvas.requestPointerLock();
				} catch {}
			});
		} catch {
			try {
				this.canvas.requestPointerLock();
			} catch {}
		}
	}
	start() {
		this.audio.unlock();
		this.player.reset();
		this.weapon.reset();
		this.horde.reset();
		this.wave = 1;
		this.score = 0;
		this.kills = 0;
		this.trauma = 0;
		this.wavePause = .4;
		this.toSpawn = 0;
		this.spawnCd = 0;
		this.banner("Wave 1");
		this.audio.wave();
		useGameStore.setState({
			phase: "playing",
			newRecord: false,
			health: 100,
			ammo: 6,
			reserve: 24,
			score: 0,
			wave: 1,
			kills: 0,
			banner: "Wave 1"
		});
		this.tryPointerLock();
		this.pushHud();
	}
	pause() {
		if (useGameStore.getState().phase !== "playing") return;
		useGameStore.setState({ phase: "paused" });
		if (document.pointerLockElement) document.exitPointerLock();
	}
	resume() {
		if (useGameStore.getState().phase !== "paused") return;
		useGameStore.setState({ phase: "playing" });
		this.tryPointerLock();
		this.last = performance.now();
	}
	quitToTitle() {
		if (document.pointerLockElement) document.exitPointerLock();
		this.horde.reset();
		this.placeTitleZombies();
		this.player.reset();
		useGameStore.setState({
			phase: "title",
			banner: ""
		});
	}
	setTouchMove(x, y) {
		this.input.touchMoveX = x;
		this.input.touchMoveY = y;
	}
	addLook(dx, dy) {
		this.input.addLook(dx, dy);
	}
	setFireHeld(held) {
		this.input.fireHeld = held;
	}
	queueReload() {
		this.input.queueReload();
	}
	queuePause() {
		this.input.queuePause();
	}
	setMuted(muted) {
		this.audio.setMuted(muted);
	}
	banner(text) {
		this.bannerT = 2.4;
		useGameStore.setState({ banner: text });
	}
	placeTitleZombies() {
		this.horde.reset();
		const spots = this.world.spawnPoints;
		for (let i = 0; i < 5; i++) {
			const s = spots[i % spots.length];
			this.horde.spawn(s.x, s.z, 80, .55);
		}
	}
	beginWave() {
		this.toSpawn = 4 + this.wave * 2;
		this.spawnCd = .15;
		this.banner(`Wave ${this.wave}`);
		this.audio.wave();
	}
	spawnOne() {
		const spots = this.world.spawnPoints;
		const s = spots[Math.random() * spots.length | 0];
		const jitter = 1.4;
		const hp = 70 + this.wave * 12;
		const speed = 1.15 + this.wave * .1;
		if (this.horde.spawn(s.x + (Math.random() - .5) * jitter, s.z + (Math.random() - .5) * jitter, hp, speed)) {
			this.toSpawn -= 1;
			if (Math.random() < .35) this.audio.groan();
		}
	}
	loop = (now) => {
		if (this.disposed) return;
		const raw = Math.min((now - this.last) / 1e3, .1);
		this.last = now;
		const phase = useGameStore.getState().phase;
		if (phase === "title") {
			this.time += raw;
			const t = this.time * .12;
			this.camera.position.set(Math.sin(t) * 16, 7.2, Math.cos(t) * 16);
			this.camera.lookAt(0, 1.4, 0);
			this.horde.update(raw, Math.sin(t) * 3, Math.cos(t) * 3, this.world.colliders, () => void 0);
			this.render();
			return;
		}
		if (phase === "paused" || phase === "dead") {
			this.render();
			return;
		}
		const actions = this.input.sample();
		if (actions.pause) {
			this.pause();
			return;
		}
		const sens = useGameStore.getState().sensitivity;
		actions.lookDx *= sens;
		actions.lookDy *= sens;
		let dt = raw;
		if (this.hitstop > 0) {
			this.hitstop -= raw;
			dt = raw * .15;
		}
		this.time += dt;
		this.player.update(dt, actions, this.world.colliders);
		const bobAmt = this.player.speed > .4 ? .028 : 0;
		if (this.player.speed > 1.4) this.audio.footstep(this.time);
		if (actions.reload) {
			if (this.weapon.beginReload()) this.audio.reload();
		}
		if (actions.fire) this.tryShoot();
		this.weapon.update(dt, this.player.dist, actions.lookDx, actions.lookDy);
		this.horde.update(dt, this.player.x, this.player.z, this.world.colliders, (dmg) => {
			this.hurt(dmg);
		});
		if (this.wavePause > 0) {
			this.wavePause -= dt;
			if (this.wavePause <= 0) this.beginWave();
		} else if (this.toSpawn > 0) {
			this.spawnCd -= dt;
			if (this.spawnCd <= 0 && this.horde.aliveCount < 14) {
				this.spawnOne();
				this.spawnCd = Math.max(.35, 1.1 - this.wave * .06);
			}
		} else if (this.horde.aliveCount === 0 && useGameStore.getState().phase === "playing") {
			this.wave += 1;
			this.weapon.addReserve(10);
			this.player.health = Math.min(100, this.player.health + 18);
			this.wavePause = 2.2;
			this.banner("The square holds");
		}
		this.trauma = Math.max(0, this.trauma - dt * 1.7);
		const shakeAmt = this.reduceMotion ? 0 : this.trauma * this.trauma;
		this.shake.set(shakeAmt * .11 * Math.sin(this.time * 47.2), shakeAmt * .09 * Math.sin(this.time * 53.1 + 1.1), shakeAmt * .04 * Math.sin(this.time * 39.4));
		this.player.applyToCamera(this.camera, bobAmt, this.shake, this.weapon.recoil);
		for (const m of this.impacts) {
			if (!m.visible) continue;
			const mat = m.material;
			mat.opacity -= dt * 1.4;
			m.scale.multiplyScalar(1 + dt * 1.2);
			if (mat.opacity <= 0) m.visible = false;
		}
		if (this.bannerT > 0) {
			this.bannerT -= dt;
			if (this.bannerT <= 0) useGameStore.setState({ banner: "" });
		}
		this.pushHud();
		this.render();
	};
	tryShoot() {
		const result = this.weapon.tryFire();
		if (result === "empty") {
			this.audio.empty();
			return;
		}
		if (result !== "shot") return;
		this.audio.gunshot();
		this.trauma = Math.min(1, this.trauma + .22);
		if (navigator.vibrate) navigator.vibrate(16);
		this.raycaster.setFromCamera(this.ndc, this.camera);
		if (useGameStore.getState().aimAssist) this.applyAimAssist();
		const zombieHits = this.raycaster.intersectObjects(this.horde.targets, true);
		const worldHits = this.raycaster.intersectObjects(this.world.hitMeshes, true);
		const zHit = zombieHits[0];
		const wHit = worldHits[0];
		const zombieFirst = zHit && (!wHit || zHit.distance < wHit.distance - .05) ? zHit : null;
		if (zombieFirst) {
			const info = this.horde.hitFromRay(zombieFirst, 38, 100);
			if (info) {
				this.audio.hit();
				useGameStore.setState({ hitmarkerAt: performance.now() });
				const dir = this.raycaster.ray.direction;
				this.horde.knockback(info.index, dir.x, dir.z, .55);
				this.spawnImpact(info.point, true);
				const pts = info.head ? 150 : 80;
				this.score += pts;
				if (!info.zombie.alive) {
					this.kills += 1;
					this.score += 40;
					this.audio.kill();
					this.hitstop = .05;
					this.trauma = Math.min(1, this.trauma + .28);
					if (navigator.vibrate) navigator.vibrate(28);
				}
			}
		} else if (wHit) this.spawnImpact(wHit.point, false);
	}
	applyAimAssist() {
		const dir = this.raycaster.ray.direction;
		const origin = this.raycaster.ray.origin;
		let bestDot = .96;
		let best = null;
		const to = new Vector3();
		for (const obj of this.horde.targets) {
			if (!obj.visible) continue;
			obj.getWorldPosition(to);
			to.y += 1.45;
			to.sub(origin);
			const dist = to.length();
			if (dist < .4 || dist > 22) continue;
			to.multiplyScalar(1 / dist);
			const dot = to.dot(dir);
			if (dot > bestDot) {
				bestDot = dot;
				best = to.clone();
			}
		}
		if (best) dir.lerp(best, .45).normalize();
	}
	spawnImpact(point, flesh) {
		const m = this.impacts.find((p) => !p.visible);
		if (!m) return;
		m.visible = true;
		m.position.copy(point);
		m.scale.setScalar(flesh ? .7 : 1);
		const mat = m.material;
		mat.color.setHex(flesh ? 5904400 : 2761756);
		mat.opacity = .9;
	}
	hurt(dmg) {
		if (this.player.invuln > 0) return;
		this.player.health -= dmg;
		this.player.invuln = .55;
		this.trauma = Math.min(1, this.trauma + .45);
		this.audio.hurt();
		useGameStore.setState({
			hurtAt: performance.now(),
			health: Math.max(0, this.player.health)
		});
		if (navigator.vibrate) navigator.vibrate([
			20,
			30,
			40
		]);
		if (this.player.health <= 0) this.die();
	}
	die() {
		this.player.health = 0;
		if (document.pointerLockElement) document.exitPointerLock();
		const save = recordRun(this.score, this.wave);
		useGameStore.setState({
			phase: "dead",
			health: 0,
			score: this.score,
			wave: this.wave,
			highScore: save.highScore,
			bestWave: save.bestWave,
			newRecord: this.score > 0 && this.score >= save.highScore,
			banner: ""
		});
	}
	pushHud() {
		const s = useGameStore.getState();
		if (s.health === this.player.health && s.ammo === this.weapon.ammo && s.reserve === this.weapon.reserve && s.reloading === this.weapon.reloading && s.score === this.score && s.wave === this.wave && s.kills === this.kills) return;
		useGameStore.setState({
			health: this.player.health,
			ammo: this.weapon.ammo,
			reserve: this.weapon.reserve,
			reloading: this.weapon.reloading,
			score: this.score,
			wave: this.wave,
			kills: this.kills
		});
	}
	render() {
		this.renderer.clear();
		this.renderer.render(this.scene, this.camera);
		const phase = useGameStore.getState().phase;
		if (phase === "playing" || phase === "paused") {
			this.renderer.clearDepth();
			this.renderer.render(this.overlay, this.overlayCam);
		}
	}
	dispose() {
		this.disposed = true;
		this.renderer.setAnimationLoop(null);
		this.input.detach();
		window.removeEventListener("resize", this.onResize);
		document.removeEventListener("mousemove", this.onPointerMove);
		document.removeEventListener("mousedown", this.onMouseDown);
		document.removeEventListener("mouseup", this.onMouseUp);
		document.removeEventListener("pointerlockchange", this.onPointerLock);
		document.removeEventListener("visibilitychange", this.onVisibility);
		if (document.pointerLockElement === this.canvas) document.exitPointerLock();
		this.world.dispose();
		this.horde.dispose();
		this.weapon.dispose();
		this.impactGeo.dispose();
		for (const m of this.impacts) m.material.dispose();
		disposeTextures();
		this.renderer.dispose();
		delete window.__controlsTest;
		delete window.__startGame;
	}
};
//#endregion
export { GameEngine };
