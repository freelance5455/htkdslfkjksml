import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { C as useNavigate, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { m as useBootstrap, s as postOperation, t as booksFromBootstrap, v as useInvalidateBooks } from "./use-books-BtZpLk9U.mjs";
import { c as formatJalaliLong, h as todayIso, i as OP_LABELS, l as formatRial, m as parseFaNumber, r as OP_GROUPS } from "./format-c9GA3s0l.mjs";
import { i as PageHeader, n as Card } from "./card-Bb_-PO54.mjs";
import { t as Button } from "./button-BiViDDnZ.mjs";
import { n as Input, r as Textarea, t as Field } from "./input-CAg20-g-.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { i as buildJournalLines, t as AccountingError } from "./engine-DpqNPzjs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/operations.new-DlQysmVb.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function kindsFor(t) {
	if ([
		"receipt",
		"sale_cash",
		"sale_credit",
		"sale_mixed",
		"sale_return",
		"sale_discount",
		"advance",
		"check_receive",
		"check_return"
	].includes(t)) return ["customer"];
	if ([
		"payment",
		"purchase_cash",
		"purchase_credit",
		"purchase_return",
		"purchase_discount",
		"prepay",
		"check_pay"
	].includes(t)) return ["supplier"];
	if (["draw", "capital_in"].includes(t)) return ["shareholder"];
	if (["payroll"].includes(t)) return ["employee"];
	return null;
}
function OpForm({ initialType }) {
	const nav = useNavigate();
	const boot = useBootstrap();
	const invalidate = useInvalidateBooks();
	const [opType, setOpType] = (0, import_react.useState)(initialType ?? "receipt");
	const [date, setDate] = (0, import_react.useState)(todayIso());
	const [amount, setAmount] = (0, import_react.useState)("");
	const [description, setDescription] = (0, import_react.useState)("");
	const [partyId, setPartyId] = (0, import_react.useState)("");
	const [cashAccountId, setCashAccountId] = (0, import_react.useState)("");
	const [destCashAccountId, setDestCashAccountId] = (0, import_react.useState)("");
	const [expenseAccountId, setExpenseAccountId] = (0, import_react.useState)("");
	const [incomeAccountId, setIncomeAccountId] = (0, import_react.useState)("");
	const [cashPortion, setCashPortion] = (0, import_react.useState)("");
	const [checkNumber, setCheckNumber] = (0, import_react.useState)("");
	const [checkDueDate, setCheckDueDate] = (0, import_react.useState)("");
	const [checkBankName, setCheckBankName] = (0, import_react.useState)("");
	const [manual, setManual] = (0, import_react.useState)([{
		accountId: "",
		debit: "",
		credit: ""
	}]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const books = (0, import_react.useMemo)(() => boot.data ? booksFromBootstrap(boot.data) : null, [boot.data]);
	const parties = boot.data?.parties ?? [];
	const cash = boot.data?.cashAccounts ?? [];
	const postable = (boot.data?.accounts ?? []).filter((a) => a.isPostable);
	const expenses = postable.filter((a) => a.groupCode === "expense");
	const incomes = postable.filter((a) => a.groupCode === "income");
	const input = {
		opType,
		date,
		amount: parseFaNumber(amount),
		description,
		partyId: partyId || void 0,
		cashAccountId: cashAccountId || void 0,
		destCashAccountId: destCashAccountId || void 0,
		expenseAccountId: expenseAccountId || void 0,
		incomeAccountId: incomeAccountId || void 0,
		cashPortion: cashPortion ? parseFaNumber(cashPortion) : void 0,
		checkNumber: checkNumber || void 0,
		checkDueDate: checkDueDate || void 0,
		checkBankName: checkBankName || void 0,
		lines: opType === "manual" || opType === "adjustment" ? manual.filter((l) => l.accountId).map((l) => ({
			accountId: l.accountId,
			debit: parseFaNumber(l.debit),
			credit: parseFaNumber(l.credit)
		})) : void 0
	};
	let preview = null;
	if (books) try {
		preview = { lines: buildJournalLines(input, books) };
	} catch (e) {
		preview = {
			lines: [],
			error: e instanceof Error ? e.message : "خطا"
		};
	}
	const partyKinds = kindsFor(opType);
	const filteredParties = partyKinds ? parties.filter((p) => partyKinds.includes(p.kind)) : parties;
	const needsParty = partyKinds !== null;
	const needsCash = [
		"receipt",
		"receipt_other",
		"payment",
		"payment_other",
		"transfer",
		"sale_cash",
		"sale_mixed",
		"purchase_cash",
		"expense_cash",
		"income",
		"check_collect",
		"capital_in",
		"draw",
		"petty_fund",
		"prepay",
		"advance",
		"payroll"
	].includes(opType);
	const needsDest = opType === "transfer";
	const needsExpense = [
		"expense_cash",
		"expense_payable",
		"payment_other",
		"petty_settle"
	].includes(opType);
	const needsIncome = ["income", "receipt_other"].includes(opType);
	const isManual = opType === "manual" || opType === "adjustment";
	const isCheck = opType.startsWith("check_");
	async function submit() {
		setBusy(true);
		try {
			const res = await postOperation({ data: input });
			toast.success(`ثبت شد — ${res.operationNumber} / ${res.journalNumber}`);
			invalidate();
			nav({ to: "/operations" });
		} catch (e) {
			const msg = e instanceof AccountingError || e instanceof Error ? e.message : "ثبت ناموفق بود";
			toast.error(msg);
		} finally {
			setBusy(false);
		}
	}
	if (boot.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-64 animate-pulse rounded-[24px] bg-secondary" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-5 lg:grid-cols-[1.15fr_0.85fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "نوع عملیات",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						value: opType,
						onChange: (e) => setOpType(e.target.value),
						className: "h-11 w-full rounded-[10px] border border-line bg-paper px-3 text-sm",
						children: Object.entries(OP_LABELS).map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: k,
							children: v
						}, k))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
						label: "تاریخ",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "date",
							value: date,
							onChange: (e) => setDate(e.target.value)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-1 text-[11px] text-muted",
							children: formatJalaliLong(date)
						})]
					}), !isManual ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "مبلغ (ریال)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							inputMode: "numeric",
							value: amount,
							onChange: (e) => setAmount(e.target.value),
							placeholder: "مثلاً 25000000"
						})
					}) : null]
				}),
				needsParty ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "شخص",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: partyId,
						onChange: (e) => setPartyId(e.target.value),
						className: "h-11 w-full rounded-[10px] border border-line bg-paper px-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "انتخاب کنید"
						}), filteredParties.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
							value: p.id,
							children: [
								p.code,
								" — ",
								p.name
							]
						}, p.id))]
					})
				}) : null,
				needsCash ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: opType === "transfer" ? "مبدأ" : "منبع مالی",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: cashAccountId,
						onChange: (e) => setCashAccountId(e.target.value),
						className: "h-11 w-full rounded-[10px] border border-line bg-paper px-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "انتخاب کنید"
						}), cash.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: c.id,
							children: c.name
						}, c.id))]
					})
				}) : null,
				needsDest ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "مقصد",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: destCashAccountId,
						onChange: (e) => setDestCashAccountId(e.target.value),
						className: "h-11 w-full rounded-[10px] border border-line bg-paper px-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "انتخاب کنید"
						}), cash.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: c.id,
							children: c.name
						}, c.id))]
					})
				}) : null,
				needsExpense ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "حساب هزینه",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: expenseAccountId,
						onChange: (e) => setExpenseAccountId(e.target.value),
						className: "h-11 w-full rounded-[10px] border border-line bg-paper px-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "انتخاب کنید"
						}), expenses.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
							value: a.id,
							children: [
								a.code,
								" ",
								a.name
							]
						}, a.id))]
					})
				}) : null,
				needsIncome ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "حساب درآمد",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: incomeAccountId,
						onChange: (e) => setIncomeAccountId(e.target.value),
						className: "h-11 w-full rounded-[10px] border border-line bg-paper px-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "انتخاب کنید"
						}), incomes.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
							value: a.id,
							children: [
								a.code,
								" ",
								a.name
							]
						}, a.id))]
					})
				}) : null,
				opType === "sale_mixed" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "سهم نقدی (ریال)",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						inputMode: "numeric",
						value: cashPortion,
						onChange: (e) => setCashPortion(e.target.value)
					})
				}) : null,
				isCheck ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 sm:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "شماره چک",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: checkNumber,
								onChange: (e) => setCheckNumber(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "سررسید",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								value: checkDueDate,
								onChange: (e) => setCheckDueDate(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "بانک عهده",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: checkBankName,
								onChange: (e) => setCheckBankName(e.target.value)
							})
						})
					]
				}) : null,
				isManual ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs font-medium text-muted",
							children: "ردیف‌های سند"
						}),
						manual.map((row, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-[1.4fr_0.7fr_0.7fr] gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: row.accountId,
									onChange: (e) => {
										const next = [...manual];
										next[i] = {
											...row,
											accountId: e.target.value
										};
										setManual(next);
									},
									className: "h-10 rounded-[10px] border border-line bg-paper px-2 text-xs",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "حساب"
									}), postable.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: a.id,
										children: [
											a.code,
											" ",
											a.name
										]
									}, a.id))]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									placeholder: "بدهکار",
									value: row.debit,
									onChange: (e) => {
										const next = [...manual];
										next[i] = {
											...row,
											debit: e.target.value
										};
										setManual(next);
									}
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									placeholder: "بستانکار",
									value: row.credit,
									onChange: (e) => {
										const next = [...manual];
										next[i] = {
											...row,
											credit: e.target.value
										};
										setManual(next);
									}
								})
							]
						}, i)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							size: "sm",
							onClick: () => setManual([...manual, {
								accountId: "",
								debit: "",
								credit: ""
							}]),
							children: "ردیف جدید"
						})
					]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "شرح",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value: description,
						onChange: (e) => setDescription(e.target.value),
						rows: 3
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "gold",
					className: "w-full",
					disabled: busy || !!preview?.error,
					onClick: submit,
					children: busy ? "در حال ثبت…" : "ثبت عملیات و صدور سند دوبل"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "h-fit",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-sm font-medium text-navy",
					children: "پیش‌نمایش سند حسابداری"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs text-muted",
					children: "تا وقتی بدهکار با بستانکار برابر نباشد، ثبت نهایی متوقف می‌شود."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "text-muted",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "pb-2 text-right font-medium",
										children: "حساب"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "pb-2 text-left font-medium",
										children: "بدهکار"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "pb-2 text-left font-medium",
										children: "بستانکار"
									})
								]
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: preview?.lines.map((l, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-t border-line",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "py-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: l.accountName }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[10px] text-muted",
											children: l.accountCode
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-2 text-left tabular",
										dir: "ltr",
										children: l.debit ? formatRial(l.debit) : ""
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-2 text-left tabular",
										dir: "ltr",
										children: l.credit ? formatRial(l.credit) : ""
									})
								]
							}, i)) }),
							preview?.lines.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tfoot", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-t border-navy/20 font-medium",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-2",
										children: "جمع"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-2 text-left tabular",
										dir: "ltr",
										children: formatRial(preview.lines.reduce((s, l) => s + l.debit, 0))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-2 text-left tabular",
										dir: "ltr",
										children: formatRial(preview.lines.reduce((s, l) => s + l.credit, 0))
									})
								]
							}) }) : null
						]
					})
				}),
				preview?.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 rounded-[12px] bg-danger/10 px-3 py-2 text-xs text-danger",
					children: preview.error
				}) : preview?.lines.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cn("mt-3 rounded-[12px] px-3 py-2 text-xs", "bg-success/10 text-success"),
					children: "تراز برقرار است."
				}) : null
			]
		})]
	});
}
function NewOpPage() {
	const [picked, setPicked] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		title: "ثبت عملیات",
		description: "نوع رویداد را انتخاب کنید. سیستم سند دوبل را می‌سازد.",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/operations",
			className: "text-sm text-muted",
			children: "بازگشت به فهرست"
		})
	}), !picked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-6",
		children: OP_GROUPS.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mb-3 text-xs tracking-[0.18em] text-muted",
			children: g.title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-4",
			children: g.types.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setPicked(t),
				className: "rounded-[18px] border border-line bg-paper px-3 py-4 text-right text-sm hover:border-gold",
				children: OP_LABELS[t]
			}, t))
		})] }, g.title))
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: "mb-4 text-xs text-muted",
		onClick: () => setPicked(null),
		children: "تغییر نوع عملیات"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OpForm, { initialType: picked })] })] });
}
//#endregion
export { NewOpPage as component };
