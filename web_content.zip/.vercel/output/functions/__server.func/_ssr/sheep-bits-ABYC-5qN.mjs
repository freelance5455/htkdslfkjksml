import "../_runtime.mjs";
import { b as require_jsx_runtime, x as require_react } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { C as sexLabel, T as statusLabel, b as isPregnant, c as ageLabel, d as compareSheep, g as formatKg, u as cn, y as isLamb } from "./store-g4o8WGZx.mjs";
require_react();
var import_jsx_runtime = require_jsx_runtime();
var badgeVariants = cva("inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium", {
	variants: { variant: {
		default: "bg-secondary text-muted-foreground",
		ok: "bg-ok/15 text-ok",
		warn: "bg-warn/15 text-warn",
		danger: "bg-danger/15 text-danger"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
function SheepBadges({ sheep, breeding }) {
	const young = isLamb(sheep);
	const pregnant = sheep.sex === "ewe" && isPregnant(sheep.id, breeding);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap justify-end gap-1",
		children: [
			sheep.status === "sick" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
				variant: "danger",
				children: "مريض"
			}) : null,
			pregnant ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
				variant: "warn",
				children: "حامل"
			}) : null,
			young ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: "صغير" }) : null,
			sheep.status === "sold" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: "مبيع" }) : null,
			sheep.status === "dead" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: "نافق" }) : null,
			sheep.status === "active" && !pregnant && !young ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
				variant: "ok",
				children: statusLabel(sheep.status)
			}) : null
		]
	});
}
function SheepCard({ sheep, breeding }) {
	const young = isLamb(sheep);
	const meta = [
		sexLabel(sheep.sex, young),
		sheep.name,
		sheep.breed,
		sheep.pen
	].filter(Boolean).join(" · ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/sheep/$id",
		params: { id: sheep.id },
		className: "block rounded-3xl border border-border bg-card p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xl font-semibold break-all tabular-nums tracking-tight",
					children: sheep.tag
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheepBadges, {
					sheep,
					breeding
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted-foreground",
				children: meta
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm",
				children: [
					ageLabel(sheep.birthDate),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-muted-foreground",
						children: " · "
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums",
						children: formatKg(sheep.weightKg)
					})
				]
			})
		]
	});
}
function sortSheep(list) {
	return list.slice().sort(compareSheep);
}
//#endregion
export { SheepCard as n, sortSheep as r, SheepBadges as t };
