import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { C as useTrial, S as useStatements, y as useJournalBook } from "./use-books-BtZpLk9U.mjs";
import { h as todayIso, l as formatRial, s as formatJalali } from "./format-c9GA3s0l.mjs";
import { i as PageHeader, n as Card, r as Money } from "./card-Bb_-PO54.mjs";
import { t as Button } from "./button-BiViDDnZ.mjs";
import { n as Input } from "./input-CAg20-g-.mjs";
import { r as printReport, t as downloadCsv } from "./export-tWZA3qLh.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reports-CD-HEoKr.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TABS = [
	{
		id: "trial",
		label: "تراز آزمایشی"
	},
	{
		id: "pnl",
		label: "سود و زیان"
	},
	{
		id: "bs",
		label: "ترازنامه"
	},
	{
		id: "cf",
		label: "جریان وجوه"
	},
	{
		id: "journal",
		label: "دفتر روزنامه"
	}
];
function monthStart() {
	const d = /* @__PURE__ */ new Date();
	d.setDate(1);
	const z = (v) => String(v).padStart(2, "0");
	return `${d.getFullYear()}-${z(d.getMonth() + 1)}-${z(d.getDate())}`;
}
function ReportsPage() {
	const [tab, setTab] = (0, import_react.useState)("trial");
	const [from, setFrom] = (0, import_react.useState)("2026-03-21");
	const [to, setTo] = (0, import_react.useState)(todayIso());
	const [cols, setCols] = (0, import_react.useState)(6);
	const trial = useTrial(from, to);
	const st = useStatements(from, to);
	const book = useJournalBook(from, to);
	const title = TABS.find((t) => t.id === tab)?.label ?? "";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "گزارش‌های مالی",
			description: `از ${formatJalali(from)} تا ${formatJalali(to)}`,
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				onClick: () => printReport(),
				children: "PDF / چاپ"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				onClick: () => {
					if (tab === "trial" && trial.data) downloadCsv("trial-balance", [
						"کد",
						"حساب",
						"بدهکار اول",
						"بستانکار اول",
						"گردش بد",
						"گردش بس",
						"مانده بد",
						"مانده بس"
					], trial.data.rows.map((r) => [
						r.code,
						r.name,
						r.openingDebit,
						r.openingCredit,
						r.turnoverDebit,
						r.turnoverCredit,
						r.balanceDebit,
						r.balanceCredit
					]));
				},
				children: "Excel / CSV"
			})] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "no-print mb-4 flex flex-wrap items-end gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "text-xs text-muted",
					children: ["از تاریخ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						value: from,
						onChange: (e) => setFrom(e.target.value),
						className: "mt-1"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "text-xs text-muted",
					children: ["تا تاریخ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						value: to,
						onChange: (e) => setTo(e.target.value),
						className: "mt-1"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "ghost",
					onClick: () => setFrom(monthStart()),
					children: "ماه جاری"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "no-print mb-5 flex gap-1 overflow-x-auto",
			children: TABS.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setTab(t.id),
				className: `rounded-full px-3 py-1.5 text-xs ${tab === t.id ? "bg-navy text-cream" : "bg-paper text-muted"}`,
				children: t.label
			}, t.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "print:shadow-none print:border-none",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 hidden print:block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-display text-xl tracking-[0.14em]",
						children: "MR,KHORASANI"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-sm",
						children: title
					})]
				}),
				tab === "trial" && trial.data ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "no-print mb-3 flex gap-2",
						children: [
							2,
							4,
							6
						].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: cols === n ? "default" : "outline",
							onClick: () => setCols(n),
							children: [n, " ستونی"]
						}, n))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full min-w-[640px] text-xs",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "text-muted",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "py-2 text-right",
											children: "کد"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "py-2 text-right",
											children: "حساب"
										}),
										cols === 6 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "py-2 text-left",
											children: "بد اول دوره"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "py-2 text-left",
											children: "بس اول دوره"
										})] }) : null,
										cols >= 4 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "py-2 text-left",
											children: "گردش بد"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "py-2 text-left",
											children: "گردش بس"
										})] }) : null,
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "py-2 text-left",
											children: "مانده بد"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "py-2 text-left",
											children: "مانده بس"
										})
									]
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: trial.data.rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-t border-line",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-2",
											children: r.code
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-2",
											children: r.name
										}),
										cols === 6 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-2 text-left tabular",
											children: r.openingDebit ? formatRial(r.openingDebit) : ""
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-2 text-left tabular",
											children: r.openingCredit ? formatRial(r.openingCredit) : ""
										})] }) : null,
										cols >= 4 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-2 text-left tabular",
											children: r.turnoverDebit ? formatRial(r.turnoverDebit) : ""
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-2 text-left tabular",
											children: r.turnoverCredit ? formatRial(r.turnoverCredit) : ""
										})] }) : null,
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-2 text-left tabular",
											children: r.balanceDebit ? formatRial(r.balanceDebit) : ""
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-2 text-left tabular",
											children: r.balanceCredit ? formatRial(r.balanceCredit) : ""
										})
									]
								}, r.accountId)) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("tfoot", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-t-2 border-navy/30 font-medium",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-2",
											colSpan: 2,
											children: "جمع"
										}),
										cols === 6 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-2 text-left tabular",
											children: formatRial(trial.data.totals.openingDebit)
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-2 text-left tabular",
											children: formatRial(trial.data.totals.openingCredit)
										})] }) : null,
										cols >= 4 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-2 text-left tabular",
											children: formatRial(trial.data.totals.turnoverDebit)
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-2 text-left tabular",
											children: formatRial(trial.data.totals.turnoverCredit)
										})] }) : null,
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-2 text-left tabular",
											children: formatRial(trial.data.totals.balanceDebit)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-2 text-left tabular",
											children: formatRial(trial.data.totals.balanceCredit)
										})
									]
								}) })
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `mt-4 text-sm ${trial.data.difference === 0 ? "text-success" : "text-danger"}`,
						children: [
							"اختلاف تراز: ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, { value: trial.data.difference }),
							" ",
							trial.data.difference === 0 ? "— متوازن" : ""
						]
					})
				] }) : null,
				tab === "pnl" && st.data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatementList, {
					sections: [
						{
							title: "درآمدها",
							rows: st.data.pnl.income,
							total: st.data.pnl.incomeSum
						},
						{
							title: "بهای تمام‌شده",
							rows: st.data.pnl.cogs,
							total: st.data.pnl.cogsSum
						},
						{
							title: "هزینه‌ها",
							rows: st.data.pnl.expense,
							total: st.data.pnl.expSum
						}
					],
					footer: [["سود ناخالص", st.data.pnl.gross], ["سود خالص", st.data.pnl.net]]
				}) : null,
				tab === "bs" && st.data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatementList, {
					sections: [
						{
							title: "دارایی‌ها",
							rows: st.data.balanceSheet.assets,
							total: st.data.balanceSheet.assets.reduce((s, r) => s + r.amount, 0)
						},
						{
							title: "بدهی‌ها",
							rows: st.data.balanceSheet.liabilities,
							total: st.data.balanceSheet.liabilities.reduce((s, r) => s + r.amount, 0)
						},
						{
							title: "سرمایه",
							rows: st.data.balanceSheet.equity,
							total: st.data.balanceSheet.equity.reduce((s, r) => s + r.amount, 0)
						}
					],
					footer: [["سود جاری (به حقوق صاحبان سرمایه)", st.data.balanceSheet.net]]
				}) : null,
				tab === "cf" && st.data ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "وجوه ورودی عملیاتی",
							v: st.data.cashFlow.receipts
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "وجوه خروجی عملیاتی",
							v: st.data.cashFlow.payments
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "خالص جریان نقدی",
							v: st.data.cashFlow.receipts - st.data.cashFlow.payments
						})
					]
				}) : null,
				tab === "journal" && book.data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full min-w-[800px] text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "text-muted",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 text-right",
									children: "سند"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 text-right",
									children: "تاریخ"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 text-right",
									children: "حساب"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 text-right",
									children: "تفصیلی"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 text-left",
									children: "بدهکار"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 text-left",
									children: "بستانکار"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 text-right",
									children: "مرجع"
								})
							]
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: book.data.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-t border-line",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2",
									children: r.number
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2",
									children: formatJalali(r.date)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "py-2",
									children: [
										r.accountCode,
										" ",
										r.accountName
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2",
									children: r.partyName ?? ""
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2 text-left tabular",
									children: r.debit ? formatRial(r.debit) : ""
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2 text-left tabular",
									children: r.credit ? formatRial(r.credit) : ""
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2",
									children: r.operationNumber ?? ""
								})
							]
						}, `${r.journalId}-${r.lineNo}-${i}`)) })]
					})
				}) : null
			]
		})
	] });
}
function StatementList({ sections, footer }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [sections.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mb-2 text-sm font-medium text-navy",
				children: s.title
			}),
			s.rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
				k: `${r.code} ${r.name}`,
				v: r.amount
			}, r.code)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
				k: `جمع ${s.title}`,
				v: s.total,
				strong: true
			})
		] }, s.title)), footer.map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			k,
			v,
			strong: true
		}, k))]
	});
}
function Row({ k, v, strong }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `flex items-center justify-between border-t border-line py-2 text-sm ${strong ? "font-medium" : ""}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: k }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, { value: v })]
	});
}
//#endregion
export { ReportsPage as component };
