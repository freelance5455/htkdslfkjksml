import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { a as string, i as object, t as array } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/market.functions-DG85F2M2.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var Input = object({ symbols: array(string().min(1).max(20)).max(40) });
function safeSymbol(raw) {
	const symbol = raw.trim().toUpperCase();
	if (!/^[A-Z0-9.^=-]{1,20}$/.test(symbol)) return null;
	return symbol;
}
async function yahoo(symbol, interval, range) {
	const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol)}?interval=${interval}&range=${range}`;
	const response = await fetch(url, {
		signal: AbortSignal.timeout(8e3),
		headers: { "user-agent": "Mozilla/5.0" }
	});
	if (!response.ok) return null;
	return await response.json();
}
function monthKey(unix) {
	const date = /* @__PURE__ */ new Date(unix * 1e3);
	return `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, "0")}`;
}
function parseChart(json) {
	const result = json?.chart?.result?.[0];
	const price = result?.meta?.regularMarketPrice;
	if (!result || price == null || !Number.isFinite(price) || price <= 0) return null;
	const stamps = result.timestamp ?? [];
	const closes = result.indicators?.quote?.[0]?.close ?? [];
	const series = /* @__PURE__ */ new Map();
	stamps.forEach((stamp, index) => {
		const close = closes[index];
		if (close == null || !Number.isFinite(close)) return;
		series.set(monthKey(stamp), close);
	});
	return {
		price,
		currency: result.meta?.currency ?? "",
		series
	};
}
function mergeHistory(fx, sp, nasdaq) {
	const months = [.../* @__PURE__ */ new Set([
		...fx.keys(),
		...sp.keys(),
		...nasdaq.keys()
	])].sort();
	const points = [];
	let lastFx = 0;
	let lastSp = 0;
	let lastNq = 0;
	for (const month of months) {
		lastFx = fx.get(month) ?? lastFx;
		lastSp = sp.get(month) ?? lastSp;
		lastNq = nasdaq.get(month) ?? lastNq;
		if (lastFx <= 0 || lastSp <= 0 || lastNq <= 0) continue;
		points.push({
			month,
			fx: lastFx,
			sp500: lastSp,
			nasdaq: lastNq
		});
	}
	return points;
}
var fetchMarket_createServerFn_handler = createServerRpc({
	id: "a6eda8ba56e67e5554ad9d89a791655f45c97cbd7c37c474b0f994145e7ab731",
	name: "fetchMarket",
	filename: "src/lib/market.functions.ts"
}, (opts) => fetchMarket.__executeServer(opts));
var fetchMarket = createServerFn({ method: "POST" }).validator(Input).handler(fetchMarket_createServerFn_handler, async ({ data }) => {
	try {
		const symbols = [...new Set(data.symbols.map(safeSymbol).filter((item) => Boolean(item)))];
		const [spRaw, nqRaw, fxRaw] = await Promise.all([
			yahoo("^GSPC", "1mo", "5y"),
			yahoo("^NDX", "1mo", "5y"),
			yahoo("KRW=X", "1mo", "5y")
		]);
		const sp = parseChart(spRaw);
		const nq = parseChart(nqRaw);
		const fx = parseChart(fxRaw);
		if (!sp || !nq || !fx) return {
			ok: false,
			message: "지수나 환율을 가져오지 못했습니다."
		};
		const quotes = [];
		for (let index = 0; index < symbols.length; index += 6) {
			const chunk = symbols.slice(index, index + 6);
			const parsed = await Promise.all(chunk.map(async (symbol) => {
				try {
					const chart = parseChart(await yahoo(symbol, "1d", "5d"));
					if (!chart) return null;
					return {
						symbol,
						price: chart.price,
						currency: chart.currency
					};
				} catch {
					return null;
				}
			}));
			for (const quote of parsed) if (quote) quotes.push(quote);
		}
		return {
			ok: true,
			fx: fx.price,
			sp500: sp.price,
			nasdaq: nq.price,
			history: mergeHistory(fx.series, sp.series, nq.series),
			quotes,
			fetchedAt: (/* @__PURE__ */ new Date()).toISOString()
		};
	} catch {
		return {
			ok: false,
			message: "시세를 가져오지 못했습니다."
		};
	}
});
//#endregion
export { fetchMarket_createServerFn_handler };
