import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { o as RefreshCw } from "../_libs/lucide-react.mjs";
import { _ as viewsOf, a as capitalSeries, b as inflationLossPct, f as realHuf, i as allocation, m as sumViews, n as usePortfolio, o as classUsdSeries, u as investedToDate } from "./router-Ddmv2GI8.mjs";
import { t as Shell } from "./shell-wztA7KjE.mjs";
import { c as formatDay, d as formatPct, l as formatMoney, m as pnlClass, o as Segmented, p as formatWhen, s as compactHuf, t as CLASS_LABEL, u as formatNumber } from "./format-Bbm5TEoT.mjs";
import { a as Line, c as Cell, i as XAxis, l as ResponsiveContainer, n as LineChart, o as CartesianGrid, r as YAxis, s as Pie, t as PieChart, u as Tooltip } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DigUSM1O.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PIE = [
	"var(--color-pine)",
	"var(--color-ink)",
	"var(--color-clay)",
	"var(--color-muted)"
];
function useMounted() {
	const [mounted, setMounted] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setMounted(true), []);
	return mounted;
}
function useStill() {
	const [still, setStill] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const query = window.matchMedia("(prefers-reduced-motion: reduce)");
		const apply = () => setStill(query.matches);
		apply();
		query.addEventListener("change", apply);
		return () => query.removeEventListener("change", apply);
	}, []);
	return still;
}
var tipStyle = {
	background: "var(--color-surface)",
	border: "1px solid var(--color-line)",
	borderRadius: 12,
	color: "var(--color-ink)",
	fontSize: 13
};
function Donut({ rows }) {
	const mounted = useMounted();
	const total = rows.reduce((sum, row) => sum + row.huf, 0);
	if (!mounted || rows.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-52" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative h-52",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
			width: "100%",
			height: "100%",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PieChart, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pie, {
				data: rows,
				dataKey: "huf",
				nameKey: "label",
				innerRadius: 62,
				outerRadius: 88,
				stroke: "var(--color-bg)",
				strokeWidth: 3,
				isAnimationActive: false,
				children: rows.map((row, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, { fill: PIE[index % PIE.length] }, row.id))
			}) })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pointer-events-none absolute inset-0 flex flex-col items-center justify-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs text-muted",
				children: "összesen"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-serif text-xl tabular-nums",
				children: compactHuf(total)
			})]
		})]
	});
}
function CapitalChart({ rows }) {
	const mounted = useMounted();
	const still = useStill();
	if (!mounted) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-72" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-72 w-full min-w-0",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
			width: "100%",
			height: "100%",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LineChart, {
				data: rows,
				margin: {
					top: 8,
					right: 8,
					left: 0,
					bottom: 0
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
						stroke: "var(--color-line)",
						vertical: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
						dataKey: "date",
						tickFormatter: (value) => value.slice(0, 7),
						minTickGap: 32,
						tick: {
							fill: "var(--color-muted)",
							fontSize: 12
						},
						axisLine: false,
						tickLine: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
						tickFormatter: (value) => compactHuf(value).replace(" Ft", ""),
						width: 56,
						tick: {
							fill: "var(--color-muted)",
							fontSize: 12
						},
						axisLine: false,
						tickLine: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
						contentStyle: tipStyle,
						labelFormatter: (label) => formatDay(String(label)),
						formatter: (value, name) => [formatMoney(Number(value ?? 0), "HUF"), name === "toke" ? "Befizetett tőke" : "Érték"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
						type: "monotone",
						dataKey: "toke",
						name: "toke",
						stroke: "var(--color-clay)",
						strokeWidth: 2,
						dot: false,
						isAnimationActive: !still
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
						type: "monotone",
						dataKey: "ertek",
						name: "ertek",
						stroke: "var(--color-pine)",
						strokeWidth: 2.4,
						dot: false,
						connectNulls: false,
						isAnimationActive: !still
					})
				]
			})
		})
	});
}
function ClassChart({ rows }) {
	const mounted = useMounted();
	const still = useStill();
	if (!mounted) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-72" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-72 w-full min-w-0",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
			width: "100%",
			height: "100%",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LineChart, {
				data: rows,
				margin: {
					top: 8,
					right: 8,
					left: 0,
					bottom: 0
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
						stroke: "var(--color-line)",
						vertical: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
						dataKey: "date",
						tickFormatter: (value) => value.slice(0, 7),
						minTickGap: 32,
						tick: {
							fill: "var(--color-muted)",
							fontSize: 12
						},
						axisLine: false,
						tickLine: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
						tickFormatter: (value) => formatNumber(value, 0),
						width: 56,
						tick: {
							fill: "var(--color-muted)",
							fontSize: 12
						},
						axisLine: false,
						tickLine: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
						contentStyle: tipStyle,
						labelFormatter: (label) => formatDay(String(label)),
						formatter: (value, name) => [`${formatNumber(Number(value ?? 0), 0)} USD`, name === "etf" ? "ETF" : name === "kripto" ? "Kripto" : "Részvény"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
						type: "monotone",
						dataKey: "etf",
						name: "etf",
						stroke: "var(--color-pine)",
						strokeWidth: 2.2,
						dot: false,
						connectNulls: true,
						isAnimationActive: !still
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
						type: "monotone",
						dataKey: "reszveny",
						name: "reszveny",
						stroke: "var(--color-ink)",
						strokeWidth: 2.2,
						dot: false,
						connectNulls: true,
						isAnimationActive: !still
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
						type: "monotone",
						dataKey: "kripto",
						name: "kripto",
						stroke: "var(--color-clay)",
						strokeWidth: 2.2,
						dot: false,
						connectNulls: true,
						isAnimationActive: !still
					})
				]
			})
		})
	});
}
function Page() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Overview, {}) });
}
function Overview() {
	const { state, refreshing, marketError, range, setRange, refresh } = usePortfolio();
	const [mode, setMode] = (0, import_react.useState)("class");
	const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
	const rows = (0, import_react.useMemo)(() => viewsOf(state), [state]);
	const totals = (0, import_react.useMemo)(() => sumViews(rows), [rows]);
	const buckets = (0, import_react.useMemo)(() => allocation(state, mode), [state, mode]);
	const series = (0, import_react.useMemo)(() => capitalSeries(state, today), [state, today]);
	const classes = (0, import_react.useMemo)(() => classUsdSeries(state), [state]);
	const base = state.inflationBase || state.capitalPlan.startDate;
	const real = realHuf(totals.huf, base, today);
	const loss = inflationLossPct(base, today);
	const invested = investedToDate(state.capitalPlan, today);
	const gap = totals.huf - invested;
	const ranked = [...rows].sort((a, b) => b.huf - a.huf).slice(0, 6);
	const fxRows = [...rows].filter((row) => row.holding.currency !== "HUF").sort((a, b) => Math.abs(b.fxPnlHuf) - Math.abs(a.fxPnlHuf)).slice(0, 5);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-end justify-between gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-serif text-3xl",
				children: "Áttekintés"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm text-muted",
				children: [
					state.market.fxLive ? `Élő középárfolyam, ${formatWhen(state.market.asOf)}.` : "Becsült árak, amíg a jegyzés megérkezik.",
					" ",
					"1 USD = ",
					formatMoney(state.market.fx.usdHuf, "HUF", 2),
					", 1 EUR = ",
					formatMoney(state.market.fx.eurHuf, "HUF", 2),
					"."
				]
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "btn btn-ghost",
				onClick: () => void refresh(),
				disabled: refreshing,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: `size-4 ${refreshing ? "motion-safe:animate-spin" : ""}` }), refreshing ? "Frissül" : "Árak frissítése"]
			})]
		}),
		marketError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-sm text-clay",
			children: marketError
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-8 grid gap-8 border-t border-line pt-8 sm:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Forint"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 font-serif text-4xl tabular-nums leading-tight sm:text-5xl",
				children: formatMoney(totals.huf, "HUF")
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "sm:border-l sm:border-line sm:pl-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Dollár"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 font-serif text-4xl tabular-nums leading-tight sm:text-5xl",
					children: formatMoney(totals.usd, "USD")
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
			className: "mt-8 grid gap-6 border-t border-line pt-6 sm:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dt", {
						className: "text-sm text-muted",
						children: [
							"Inflációval, ",
							base,
							" óta"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-1 font-serif text-2xl tabular-nums",
						children: formatMoney(real, "HUF")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
						className: "text-sm text-muted",
						children: [
							"A forint vásárlóereje ",
							formatNumberLoss(loss),
							"."
						]
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-sm text-muted",
						children: "Devizahatás"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: `mt-1 font-serif text-2xl tabular-nums ${pnlClass(totals.fxPnlHuf)}`,
						children: formatMoney(totals.fxPnlHuf, "HUF")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
						className: `text-sm tabular-nums ${pnlClass(totals.pricePnlHuf)}`,
						children: ["Árhatás ", formatMoney(totals.pricePnlHuf, "HUF")]
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-sm text-muted",
						children: "Befizetett tőke"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-1 font-serif text-2xl tabular-nums",
						children: formatMoney(invested, "HUF")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
						className: `text-sm tabular-nums ${pnlClass(gap)}`,
						children: [
							"Az érték ",
							gap >= 0 ? "felette" : "alatta",
							" van: ",
							formatMoney(gap, "HUF")
						]
					})
				] })
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-10 flex flex-wrap items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segmented, {
				label: "Időtáv",
				value: range,
				onChange: setRange,
				options: [
					{
						id: "6mo",
						label: "6 hónap"
					},
					{
						id: "1y",
						label: "1 év"
					},
					{
						id: "5y",
						label: "5 év"
					}
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segmented, {
				label: "Megoszlás",
				value: mode,
				onChange: setMode,
				options: [{
					id: "class",
					label: "Osztály"
				}, {
					id: "group",
					label: "Csoport"
				}]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-6 grid items-start gap-10 lg:grid-cols-12",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:col-span-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl",
						children: "Megoszlás"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Donut, { rows: buckets }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-2 divide-y divide-line",
						children: buckets.map((bucket) => {
							const pct = totals.huf ? bucket.huf / totals.huf * 100 : 0;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "grid grid-cols-[1fr_auto] gap-3 py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-baseline justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: bucket.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm text-muted tabular-nums",
										children: formatPct(pct).replace("+", "")
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-2 h-1.5 rounded-full bg-line",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "h-1.5 rounded-full bg-pine",
										style: { width: `${Math.min(100, pct)}%` }
									})
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-right text-sm tabular-nums",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: compactHuf(bucket.huf) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-muted",
										children: formatMoney(bucket.usd, "USD")
									})]
								})]
							}, bucket.id);
						})
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 lg:col-span-7",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl",
						children: "Befizetés és érték"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "A rozsda színű vonal a megadott ütem, a zöld a mai darabszám visszaszámolt értéke, plusz a mostani készpénz. Nem a régi egyenleg."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 overflow-hidden rounded-2xl border border-line bg-surface p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CapitalChart, { rows: series }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex gap-4 px-2 text-xs text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-clay",
								children: "Befizetett tőke"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-pine",
								children: "Vagyon"
							})]
						})]
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-12",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-serif text-2xl",
					children: "Eszközosztályok dollárban"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "A most tartott ETF, részvény és kripto értéke dollárban, készpénz nélkül."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 overflow-hidden rounded-2xl border border-line bg-surface p-3",
					children: [classes.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClassChart, { rows: classes }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-2 py-16 text-sm text-muted",
						children: "Az árgörbe az első sikeres frissítés után rajzolódik ki."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex gap-4 px-2 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-pine",
								children: "ETF"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-ink",
								children: "Részvény"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-clay",
								children: "Kripto"
							})
						]
					})]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-12 grid gap-10 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-serif text-2xl",
					children: "Nagyobb tételek"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 divide-y divide-line",
					children: ranked.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-baseline justify-between gap-3 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "truncate",
								children: [
									row.holding.name,
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm text-muted",
										children: row.holding.symbol
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-muted",
								children: [
									state.groups.find((group) => group.id === row.holding.groupId)?.name,
									" · ",
									CLASS_LABEL[row.holding.assetClass]
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-right tabular-nums",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: formatMoney(row.huf, "HUF") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: formatMoney(row.usd, "USD")
							})]
						})]
					}, row.holding.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/eszkozok",
					className: "mt-2 inline-flex h-11 items-center text-sm text-pine",
					children: "Teljes állomány"
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-serif text-2xl",
					children: "Miből jön a változás"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Az árhatás a papír saját devizájában, a beszerzéskori forintárfolyamon. A devizahatás az árfolyam elmozdulása azóta."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 divide-y divide-line",
					children: fxRows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "grid grid-cols-[1fr_auto_auto] gap-3 py-3 text-sm tabular-nums",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate text-base",
								children: row.holding.symbol
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: pnlClass(row.pricePnlHuf),
								children: compactHuf(row.pricePnlHuf)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: pnlClass(row.fxPnlHuf),
								children: compactHuf(row.fxPnlHuf)
							})
						]
					}, row.holding.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-xs text-muted",
					children: "Árhatás, majd devizahatás. A forintos papíroknál a deviza nulla."
				})
			] })]
		})
	] });
}
function formatNumberLoss(pct) {
	const text = formatNumber(Math.abs(pct), 1);
	return pct >= 0 ? `${text}%-ot csökkent` : `${text}%-ot nőtt`;
}
//#endregion
export { Page as component };
