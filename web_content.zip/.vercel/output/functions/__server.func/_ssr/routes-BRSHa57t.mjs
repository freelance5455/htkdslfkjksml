import { i as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, q as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as interpretPrompt, i as frameFilter, o as recipeNotes, r as formatTime, s as windowFor, t as NEUTRAL_RECIPE } from "./recipe-CSjsxg-s.mjs";
import { a as Pause, c as Camera, i as Play, o as Film, r as Smartphone, s as Download, t as Upload } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BRSHa57t.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var grainTile = null;
function tile() {
	if (grainTile) return grainTile;
	const canvas = document.createElement("canvas");
	canvas.width = 160;
	canvas.height = 160;
	const ctx = canvas.getContext("2d");
	if (!ctx) return canvas;
	const image = ctx.createImageData(160, 160);
	for (let i = 0; i < image.data.length; i += 4) {
		const v = Math.random() * 255;
		image.data[i] = v;
		image.data[i + 1] = v;
		image.data[i + 2] = v;
		image.data[i + 3] = 255;
	}
	ctx.putImageData(image, 0, 0);
	grainTile = canvas;
	return canvas;
}
function bars(w, h, enabled) {
	if (!enabled) return 0;
	if (w >= h) return Math.max(0, (h - Math.min(h, w / 2.35)) / 2);
	return h * .07;
}
function wrap(ctx, text, maxWidth) {
	const words = text.split(/\s+/);
	const lines = [];
	let line = "";
	for (const word of words) {
		const next = line ? `${line} ${word}` : word;
		if (ctx.measureText(next).width > maxWidth && line) {
			lines.push(line);
			line = word;
		} else line = next;
	}
	if (line) lines.push(line);
	return lines.slice(0, 3);
}
function fadeAmount(outputTime, outputDuration, recipe) {
	let amount = 1;
	if (recipe.fadeIn > 0) amount = Math.min(amount, outputTime / recipe.fadeIn);
	if (recipe.fadeOut > 0) amount = Math.min(amount, (outputDuration - outputTime) / recipe.fadeOut);
	return Math.max(0, Math.min(1, amount));
}
function drawFrame(ctx, video, recipe, sourceTime, clipStart, clipEnd) {
	const w = ctx.canvas.width;
	const h = ctx.canvas.height;
	const span = Math.max(.001, clipEnd - clipStart);
	const progress = Math.max(0, Math.min(1, (sourceTime - clipStart) / span));
	const outputDuration = span / recipe.speed;
	const fade = fadeAmount(progress * outputDuration, outputDuration, recipe);
	const zoom = 1 + (recipe.zoom - 1) * progress;
	const vw = video.videoWidth || w;
	const vh = video.videoHeight || h;
	const scale = Math.max(w / vw, h / vh) * zoom;
	const dw = vw * scale;
	const dh = vh * scale;
	ctx.save();
	ctx.clearRect(0, 0, w, h);
	ctx.fillStyle = "#000";
	ctx.fillRect(0, 0, w, h);
	ctx.filter = frameFilter(recipe);
	ctx.drawImage(video, (w - dw) / 2, (h - dh) / 2, dw, dh);
	ctx.filter = "none";
	if (recipe.vignette > 0) {
		const g = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * .25, w / 2, h / 2, Math.max(w, h) * .72);
		g.addColorStop(0, "rgba(0,0,0,0)");
		g.addColorStop(1, `rgba(0,0,0,${recipe.vignette})`);
		ctx.fillStyle = g;
		ctx.fillRect(0, 0, w, h);
	}
	if (recipe.grain > 0) {
		ctx.globalAlpha = recipe.grain;
		const noise = tile();
		const ox = Math.round(sourceTime * 48 % 40);
		const oy = Math.round(sourceTime * 36 % 40);
		ctx.drawImage(noise, -ox, -oy, w + 40, h + 40);
		ctx.globalAlpha = 1;
	}
	const bar = bars(w, h, recipe.letterbox);
	if (bar > 0) {
		ctx.fillStyle = "#000";
		ctx.fillRect(0, 0, w, bar);
		ctx.fillRect(0, h - bar, w, bar);
	}
	if ((recipe.title || recipe.subtitle) && progress >= recipe.titleStart && progress <= recipe.titleEnd) {
		const windowSpan = Math.max(.001, recipe.titleEnd - recipe.titleStart);
		const local = (progress - recipe.titleStart) / windowSpan;
		const titleFade = Math.min(1, local / .18, (1 - local) / .18);
		ctx.save();
		ctx.globalAlpha = Math.max(0, titleFade);
		ctx.fillStyle = "#f3f2ef";
		ctx.textAlign = "center";
		ctx.textBaseline = "middle";
		ctx.shadowColor = "rgba(0,0,0,0.7)";
		ctx.shadowBlur = Math.max(8, w * .02);
		const pictureTop = bar;
		const pictureH = h - bar * 2;
		if (recipe.title) {
			const size = Math.max(22, Math.round(w * .078));
			ctx.font = `560 ${size}px Fraunces, Georgia, serif`;
			const lines = wrap(ctx, recipe.title, w * .82);
			const cy = pictureTop + pictureH * .42 - (lines.length - 1) * size * 1.15 / 2;
			lines.forEach((line, index) => {
				ctx.fillText(line, w / 2, cy + index * size * 1.15);
			});
		}
		if (recipe.subtitle) {
			ctx.font = `500 ${Math.max(14, Math.round(w * .038))}px Outfit, sans-serif`;
			ctx.fillText(recipe.subtitle, w / 2, pictureTop + pictureH * .58);
		}
		ctx.restore();
	}
	const caption = recipe.captions.find((item) => progress >= item.start && progress <= item.end);
	if (caption) {
		const size = Math.max(15, Math.round(w * .04));
		ctx.font = `500 ${size}px Outfit, sans-serif`;
		ctx.textAlign = "center";
		ctx.textBaseline = "middle";
		const lines = wrap(ctx, caption.text, w * .8);
		const lineH = size * 1.25;
		const blockH = lines.length * lineH + size * .7;
		const blockW = Math.min(w * .86, Math.max(...lines.map((line) => ctx.measureText(line).width)) + size);
		const x = (w - blockW) / 2;
		const y = h - bar - blockH - size * .7;
		ctx.fillStyle = "rgba(12,12,13,0.72)";
		ctx.beginPath();
		ctx.roundRect(x, y, blockW, blockH, 10);
		ctx.fill();
		ctx.fillStyle = "#f3f2ef";
		lines.forEach((line, index) => {
			ctx.fillText(line, w / 2, y + size * .55 + index * lineH);
		});
	}
	if (fade < .999) {
		ctx.fillStyle = `rgba(0,0,0,${1 - fade})`;
		ctx.fillRect(0, 0, w, h);
	}
	ctx.restore();
}
function noiseBuffer(ctx) {
	const length = ctx.sampleRate;
	const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
	const data = buffer.getChannelData(0);
	let last = 0;
	for (let i = 0; i < length; i += 1) {
		const white = Math.random() * 2 - 1;
		last = (last + .02 * white) / 1.02;
		data[i] = last * 3.2;
	}
	return buffer;
}
function tone(ctx, destination, frequency, type, level) {
	const osc = ctx.createOscillator();
	const gain = ctx.createGain();
	osc.type = type;
	osc.frequency.value = frequency;
	gain.gain.value = level;
	osc.connect(gain);
	gain.connect(destination);
	osc.start();
	return {
		osc,
		gain
	};
}
function startScore(ctx, destination, music, level) {
	if (music === "none" || level <= 0) return () => {};
	const master = ctx.createGain();
	master.gain.value = level;
	master.connect(destination);
	const nodes = [master];
	const oscillators = [];
	const timers = [];
	const stop = () => {
		timers.forEach((id) => window.clearInterval(id));
		const now = ctx.currentTime;
		master.gain.cancelScheduledValues(now);
		master.gain.setValueAtTime(Math.max(1e-4, master.gain.value), now);
		master.gain.linearRampToValueAtTime(1e-4, now + .12);
		window.setTimeout(() => {
			oscillators.forEach((osc) => {
				try {
					osc.stop();
				} catch {}
			});
			nodes.forEach((node) => node.disconnect());
		}, 180);
	};
	if (music === "drift" || music === "air") {
		const a = tone(ctx, master, music === "drift" ? 110 : 196, "sine", music === "drift" ? .45 : .2);
		const b = tone(ctx, master, music === "drift" ? 164.8 : 246.9, "sine", .22);
		oscillators.push(a.osc, b.osc);
		nodes.push(a.gain, b.gain);
		const source = ctx.createBufferSource();
		source.buffer = noiseBuffer(ctx);
		source.loop = true;
		const filter = ctx.createBiquadFilter();
		filter.type = "lowpass";
		filter.frequency.value = music === "air" ? 900 : 500;
		const gain = ctx.createGain();
		gain.gain.value = music === "air" ? .35 : .18;
		source.connect(filter);
		filter.connect(gain);
		gain.connect(master);
		source.start();
		nodes.push(source, filter, gain);
		return stop;
	}
	if (music === "keys") {
		const notes = [
			261.6,
			329.6,
			392,
			493.9,
			392,
			329.6
		];
		let step = 0;
		const play = () => {
			const osc = ctx.createOscillator();
			const gain = ctx.createGain();
			osc.type = "triangle";
			osc.frequency.value = notes[step % notes.length] ?? 261.6;
			step += 1;
			const now = ctx.currentTime;
			gain.gain.setValueAtTime(1e-4, now);
			gain.gain.exponentialRampToValueAtTime(.45, now + .03);
			gain.gain.exponentialRampToValueAtTime(1e-4, now + .42);
			osc.connect(gain);
			gain.connect(master);
			osc.start(now);
			osc.stop(now + .45);
		};
		play();
		timers.push(window.setInterval(play, 460));
		return stop;
	}
	const kick = () => {
		const now = ctx.currentTime;
		const osc = ctx.createOscillator();
		const gain = ctx.createGain();
		osc.type = "sine";
		osc.frequency.setValueAtTime(150, now);
		osc.frequency.exponentialRampToValueAtTime(48, now + .12);
		gain.gain.setValueAtTime(.7, now);
		gain.gain.exponentialRampToValueAtTime(1e-4, now + .2);
		osc.connect(gain);
		gain.connect(master);
		osc.start(now);
		osc.stop(now + .22);
	};
	kick();
	timers.push(window.setInterval(kick, 500));
	return stop;
}
function pickVideoMime() {
	if (typeof MediaRecorder === "undefined") return null;
	for (const option of [
		{
			mime: "video/mp4;codecs=avc1.42E01E,mp4a.40.2",
			ext: "mp4"
		},
		{
			mime: "video/mp4",
			ext: "mp4"
		},
		{
			mime: "video/webm;codecs=vp9,opus",
			ext: "webm"
		},
		{
			mime: "video/webm;codecs=vp8,opus",
			ext: "webm"
		},
		{
			mime: "video/webm",
			ext: "webm"
		}
	]) if (MediaRecorder.isTypeSupported(option.mime)) return option;
	return null;
}
function once(target, event, timeoutMs = 1e4) {
	return new Promise((resolve, reject) => {
		const timer = window.setTimeout(() => {
			target.removeEventListener(event, onEvent);
			reject(/* @__PURE__ */ new Error("That clip took too long to read."));
		}, timeoutMs);
		const onEvent = () => {
			window.clearTimeout(timer);
			resolve();
		};
		target.addEventListener(event, onEvent, { once: true });
	});
}
async function seekTo(video, time) {
	if (Math.abs(video.currentTime - time) < .04 && video.readyState >= 2) return;
	const pending = once(video, "seeked");
	video.currentTime = Math.max(0, time);
	await pending;
}
function exportSize(width, height) {
	const long = Math.max(width, height, 2);
	const cap = long > 960 ? 960 / long : 1;
	let w = Math.max(2, Math.round((width || 720) * cap));
	let h = Math.max(2, Math.round((height || 1280) * cap));
	if (w % 2) w -= 1;
	if (h % 2) h -= 1;
	return {
		w,
		h
	};
}
async function probeClip(url) {
	const video = document.createElement("video");
	video.preload = "auto";
	video.muted = true;
	video.playsInline = true;
	const ready = once(video, "loadedmetadata");
	video.src = url;
	try {
		await ready;
	} catch (error) {
		video.src = "";
		throw error;
	}
	const clip = {
		duration: video.duration,
		width: video.videoWidth,
		height: video.videoHeight
	};
	video.src = "";
	return clip;
}
async function exportClip(url, recipe, onProgress, isCancelled) {
	const mime = pickVideoMime();
	if (!mime || typeof HTMLCanvasElement.prototype.captureStream !== "function") throw new Error("This browser can’t save a video file. Try Chrome on Android.");
	const video = document.createElement("video");
	video.preload = "auto";
	video.playsInline = true;
	const ready = new Promise((resolve, reject) => {
		video.onloadedmetadata = () => resolve();
		video.onerror = () => reject(/* @__PURE__ */ new Error("Couldn’t read the clip for saving."));
	});
	video.src = url;
	await ready;
	const { start, end } = windowFor(recipe, video.duration);
	const { w, h } = exportSize(video.videoWidth, video.videoHeight);
	const canvas = document.createElement("canvas");
	canvas.width = w;
	canvas.height = h;
	const ctx = canvas.getContext("2d", { alpha: false });
	if (!ctx) throw new Error("Couldn’t draw the cut.");
	await seekTo(video, start);
	video.muted = recipe.sourceGain <= 0;
	video.playbackRate = recipe.speed;
	video.preservesPitch = true;
	const webkit = video;
	webkit.webkitPreservesPitch = true;
	const canvasStream = canvas.captureStream(30);
	const mixed = new MediaStream();
	canvasStream.getVideoTracks().forEach((track) => mixed.addTrack(track));
	const audio = new AudioContext();
	let stopScore = () => {};
	try {
		if (audio.state === "suspended") await audio.resume();
		const dest = audio.createMediaStreamDestination();
		if (recipe.sourceGain > 0) {
			const source = audio.createMediaElementSource(video);
			const gain = audio.createGain();
			gain.gain.value = recipe.sourceGain;
			source.connect(gain);
			gain.connect(dest);
		}
		stopScore = startScore(audio, dest, recipe.music, recipe.musicGain);
		dest.stream.getAudioTracks().forEach((track) => mixed.addTrack(track));
	} catch {
		stopScore();
	}
	if (!mixed.getVideoTracks().length) {
		stopScore();
		await audio.close();
		throw new Error("Couldn’t record the picture.");
	}
	const recorder = new MediaRecorder(mixed, {
		mimeType: mime.mime,
		videoBitsPerSecond: 22e5
	});
	const chunks = [];
	recorder.ondataavailable = (event) => {
		if (event.data.size) chunks.push(event.data);
	};
	const stopped = new Promise((resolve, reject) => {
		recorder.onstop = () => resolve();
		recorder.onerror = () => reject(/* @__PURE__ */ new Error("Saving stopped unexpectedly."));
	});
	const finish = () => {
		video.pause();
		if (recorder.state !== "inactive") recorder.stop();
	};
	recorder.start(250);
	try {
		await video.play();
	} catch {
		finish();
		stopScore();
		await audio.close();
		throw new Error("Playback was blocked, so the file couldn’t be saved.");
	}
	await new Promise((resolve) => {
		const tick = () => {
			if (isCancelled() || video.ended || video.currentTime >= end - .03) {
				finish();
				resolve();
				return;
			}
			drawFrame(ctx, video, recipe, video.currentTime, start, end);
			const span = Math.max(.001, end - start);
			onProgress(Math.max(0, Math.min(1, (video.currentTime - start) / span)));
			requestAnimationFrame(tick);
		};
		requestAnimationFrame(tick);
	});
	await stopped;
	stopScore();
	canvasStream.getTracks().forEach((track) => track.stop());
	video.src = "";
	await audio.close().catch(() => void 0);
	onProgress(1);
	const type = recorder.mimeType || mime.mime;
	const ext = type.includes("mp4") ? "mp4" : "webm";
	return {
		blob: new Blob(chunks, { type }),
		filename: `onecut-${Date.now()}.${ext}`
	};
}
async function deliverFile(blob, filename) {
	const shareData = {
		files: [new File([blob], filename, { type: blob.type || "video/webm" })],
		title: "OneCut"
	};
	if (typeof navigator.canShare === "function" && navigator.canShare(shareData)) try {
		await navigator.share(shareData);
		return "shared";
	} catch (error) {
		if (error instanceof DOMException && error.name === "AbortError") return "dismissed";
	}
	const url = URL.createObjectURL(blob);
	const link = document.createElement("a");
	link.href = url;
	link.download = filename;
	link.click();
	window.setTimeout(() => URL.revokeObjectURL(url), 4e3);
	return "downloaded";
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var planEdit = createServerFn({ method: "POST" }).validator((input) => {
	const prompt = String(input?.prompt ?? "").trim();
	if (prompt.length < 2 || prompt.length > 500) throw new Error("Write a short prompt (2–500 characters).");
	return { prompt };
}).handler(createSsrRpc("e894b5314c69f756b79c6ed414f4e9ace06da5fd20791cfbf237fd483483ec6b"));
function roundRect(ctx, x, y, w, h, r) {
	ctx.beginPath();
	ctx.roundRect(x, y, w, h, r);
	ctx.fill();
}
function paintSample(ctx, w, h, t) {
	const sky = ctx.createLinearGradient(0, 0, 0, h * .66);
	sky.addColorStop(0, "#121820");
	sky.addColorStop(.45, "#3c4d68");
	sky.addColorStop(1, "#e4b08a");
	ctx.fillStyle = sky;
	ctx.fillRect(0, 0, w, h);
	ctx.fillStyle = "#f3d2a4";
	ctx.beginPath();
	ctx.arc(w * .74, h * .46 + Math.sin(t * .6) * 6, w * .09, 0, Math.PI * 2);
	ctx.fill();
	ctx.fillStyle = "#171410";
	ctx.fillRect(0, h * .64, w, h * .36);
	for (const block of [
		{
			x: .02,
			bw: .2,
			bh: .3,
			lit: "#f0c36a"
		},
		{
			x: .22,
			bw: .14,
			bh: .2,
			lit: "#efe8dc"
		},
		{
			x: .38,
			bw: .22,
			bh: .36,
			lit: "#d7a15a"
		},
		{
			x: .62,
			bw: .16,
			bh: .24,
			lit: "#f4efe6"
		},
		{
			x: .8,
			bw: .18,
			bh: .28,
			lit: "#e7c48a"
		}
	]) {
		const bx = block.x * w;
		const bh = block.bh * h;
		const by = h * .64 - bh;
		ctx.fillStyle = "#221c18";
		ctx.fillRect(bx, by, block.bw * w, bh);
		ctx.fillStyle = block.lit;
		const cols = 3;
		const rows = 5;
		for (let col = 0; col < cols; col += 1) for (let row = 0; row < rows; row += 1) {
			ctx.globalAlpha = Math.sin(t * 3 + col * 2 + row) > -.2 ? .9 : .25;
			const pad = 8;
			const cw = (block.bw * w - 16) / cols - 4;
			ctx.fillRect(bx + pad + col * (cw + 4), by + 14 + row * 22, cw, 10);
		}
		ctx.globalAlpha = 1;
	}
	const carX = (t / 5 * 1.15 - .15) * w;
	ctx.fillStyle = "#8d2e2c";
	roundRect(ctx, carX, h * .78, w * .16, h * .035, 8);
	ctx.fillStyle = "#d9e4ef";
	ctx.fillRect(carX + w * .03, h * .785, w * .045, h * .012);
	ctx.fillStyle = "#c9d2dc";
	ctx.globalAlpha = .35 + Math.sin(t * 8) * .15;
	ctx.beginPath();
	ctx.arc(w * .18, h * .72, 3, 0, Math.PI * 2);
	ctx.arc(w * .5, h * .7, 2.5, 0, Math.PI * 2);
	ctx.fill();
	ctx.globalAlpha = 1;
}
async function recordSampleReel(onProgress) {
	const mime = pickVideoMime();
	const canvas = document.createElement("canvas");
	canvas.width = 540;
	canvas.height = 960;
	const ctx = canvas.getContext("2d", { alpha: false });
	if (!ctx || !mime || typeof canvas.captureStream !== "function") throw new Error("This browser can’t make a sample clip.");
	const stream = canvas.captureStream(30);
	const recorder = new MediaRecorder(stream, {
		mimeType: mime.mime,
		videoBitsPerSecond: 16e5
	});
	const chunks = [];
	recorder.ondataavailable = (event) => {
		if (event.data.size) chunks.push(event.data);
	};
	const duration = 5;
	const started = performance.now();
	const blob = await new Promise((resolve, reject) => {
		recorder.onerror = () => reject(/* @__PURE__ */ new Error("Sample recording failed."));
		recorder.onstop = () => resolve(new Blob(chunks, { type: recorder.mimeType || mime.mime }));
		recorder.start(200);
		const tick = () => {
			const t = (performance.now() - started) / 1e3;
			paintSample(ctx, canvas.width, canvas.height, t);
			onProgress(Math.max(0, Math.min(1, t / duration)));
			if (t >= duration) {
				recorder.stop();
				stream.getTracks().forEach((track) => track.stop());
				return;
			}
			requestAnimationFrame(tick);
		};
		requestAnimationFrame(tick);
	});
	const url = URL.createObjectURL(blob);
	const probe = document.createElement("video");
	probe.preload = "auto";
	probe.muted = true;
	probe.playsInline = true;
	const ready = once(probe, "loadedmetadata");
	probe.src = url;
	try {
		await ready;
	} catch (error) {
		URL.revokeObjectURL(url);
		throw error;
	}
	const meta = {
		url,
		name: "Sample reel",
		duration: Number.isFinite(probe.duration) ? probe.duration : 5,
		width: probe.videoWidth || 540,
		height: probe.videoHeight || 960
	};
	probe.src = "";
	return meta;
}
var PRESETS = [
	{
		label: "Trailer",
		prompt: "Cinematic trailer. Letterbox, slow push-in, film grain, title “Tonight”, soft score."
	},
	{
		label: "Golden hour",
		prompt: "Warm golden-hour grade, a little slower, gentle fade, title “Sunday”."
	},
	{
		label: "Noir",
		prompt: "Black and white noir, high contrast, heavy vignette, no music."
	},
	{
		label: "Hype",
		prompt: "Fast vivid recap with a punchy beat. Keep it bright and tight."
	},
	{
		label: "Dream",
		prompt: "Soft dreamy fade, slow motion, airy music, title “Stay”."
	},
	{
		label: "Silent story",
		prompt: "Mute the clip, monochrome, no music, caption “just us”."
	}
];
function formatBytes(bytes) {
	if (bytes < 1048576) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
	return `${(bytes / 1048576).toFixed(1)} MB`;
}
function frameStyle(width, height) {
	const ratio = width / Math.max(1, height);
	return {
		aspectRatio: `${width} / ${height}`,
		width: `min(100%, calc(52dvh * ${ratio}))`
	};
}
function Studio() {
	const videoRef = (0, import_react.useRef)(null);
	const canvasRef = (0, import_react.useRef)(null);
	const fileRef = (0, import_react.useRef)(null);
	const cameraRef = (0, import_react.useRef)(null);
	const clipRef = (0, import_react.useRef)(null);
	const recipeRef = (0, import_react.useRef)(null);
	const scoreStop = (0, import_react.useRef)(null);
	const audioRef = (0, import_react.useRef)(null);
	const toggleRef = (0, import_react.useRef)(() => {});
	const cancelSave = (0, import_react.useRef)(false);
	const [clip, setClip] = (0, import_react.useState)(null);
	const [prompt, setPrompt] = (0, import_react.useState)("");
	const [recipe, setRecipe] = (0, import_react.useState)(null);
	const [applied, setApplied] = (0, import_react.useState)("");
	const [via, setVia] = (0, import_react.useState)(null);
	const [status, setStatus] = (0, import_react.useState)("Add a clip. It stays on this phone.");
	const [busy, setBusy] = (0, import_react.useState)(null);
	const [progress, setProgress] = (0, import_react.useState)(0);
	const [playing, setPlaying] = (0, import_react.useState)(false);
	const [playhead, setPlayhead] = (0, import_react.useState)(0);
	const [installOpen, setInstallOpen] = (0, import_react.useState)(false);
	const [installed, setInstalled] = (0, import_react.useState)(false);
	const [deferred, setDeferred] = (0, import_react.useState)(null);
	clipRef.current = clip;
	recipeRef.current = recipe;
	(0, import_react.useEffect)(() => {
		const saved = window.localStorage.getItem("onecut-prompt");
		if (saved) setPrompt(saved);
		const standalone = window.matchMedia("(display-mode: standalone)").matches || navigator.standalone === true;
		setInstalled(standalone);
		const onPrompt = (event) => {
			event.preventDefault();
			setDeferred(event);
		};
		window.addEventListener("beforeinstallprompt", onPrompt);
		if ("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js").catch(() => void 0);
		return () => window.removeEventListener("beforeinstallprompt", onPrompt);
	}, []);
	(0, import_react.useEffect)(() => {
		const video = videoRef.current;
		if (!video || !clip) return;
		video.src = clip.url;
		video.playsInline = true;
		const plan = recipeRef.current ?? NEUTRAL_RECIPE;
		video.playbackRate = plan.speed;
		video.volume = plan.sourceGain;
		const onReady = () => {
			const { start } = windowFor(recipeRef.current ?? NEUTRAL_RECIPE, clip.duration);
			seekTo(video, Math.min(start + .04, clip.duration - .05)).catch(() => void 0);
			setPlayhead(start);
		};
		const onTime = () => {
			const current = clipRef.current;
			if (!current) return;
			const { start, end } = windowFor(recipeRef.current ?? NEUTRAL_RECIPE, current.duration);
			if (!video.paused && video.currentTime >= end - .04) video.currentTime = start;
			setPlayhead(video.currentTime);
			setPlaying(!video.paused);
		};
		const onPause = () => setPlaying(false);
		const onPlay = () => setPlaying(true);
		video.addEventListener("loadeddata", onReady);
		video.addEventListener("timeupdate", onTime);
		video.addEventListener("pause", onPause);
		video.addEventListener("play", onPlay);
		return () => {
			video.removeEventListener("loadeddata", onReady);
			video.removeEventListener("timeupdate", onTime);
			video.removeEventListener("pause", onPause);
			video.removeEventListener("play", onPlay);
		};
	}, [clip]);
	(0, import_react.useEffect)(() => {
		const video = videoRef.current;
		if (!video) return;
		const plan = recipe ?? NEUTRAL_RECIPE;
		video.playbackRate = plan.speed;
		video.preservesPitch = true;
		video.volume = plan.sourceGain;
	}, [recipe]);
	(0, import_react.useEffect)(() => {
		let frame = 0;
		const paint = () => {
			const canvas = canvasRef.current;
			const video = videoRef.current;
			const current = clipRef.current;
			if (canvas && video && current && video.readyState >= 2) {
				const rect = canvas.getBoundingClientRect();
				const dpr = Math.min(2, window.devicePixelRatio || 1);
				const w = Math.max(2, Math.round(rect.width * dpr));
				const h = Math.max(2, Math.round(rect.height * dpr));
				if (canvas.width !== w || canvas.height !== h) {
					canvas.width = w;
					canvas.height = h;
				}
				const ctx = canvas.getContext("2d");
				if (ctx && w > 0 && h > 0) {
					const plan = recipeRef.current ?? NEUTRAL_RECIPE;
					const { start, end } = windowFor(plan, current.duration);
					drawFrame(ctx, video, plan, video.currentTime, start, end);
				}
			}
			frame = requestAnimationFrame(paint);
		};
		frame = requestAnimationFrame(paint);
		return () => cancelAnimationFrame(frame);
	}, []);
	(0, import_react.useEffect)(() => {
		const onKey = (event) => {
			if (event.code !== "Space") return;
			const tag = event.target?.tagName;
			if (tag === "TEXTAREA" || tag === "INPUT" || tag === "BUTTON") return;
			event.preventDefault();
			toggleRef.current();
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, []);
	function replaceClip(next) {
		setClip((prev) => {
			if (prev?.url && prev.url !== next?.url) URL.revokeObjectURL(prev.url);
			return next;
		});
		setPlaying(false);
		scoreStop.current?.();
		scoreStop.current = null;
	}
	async function loadFile(file) {
		if (file.type && !file.type.startsWith("video/")) {
			setStatus("Choose a video file.");
			return;
		}
		const url = URL.createObjectURL(file);
		try {
			const meta = await probeClip(url);
			if (!Number.isFinite(meta.duration) || meta.duration <= 0 || !meta.width) throw new Error("empty");
			replaceClip({
				url,
				name: file.name || "Clip",
				duration: meta.duration,
				width: meta.width,
				height: meta.height
			});
			setRecipe(null);
			setApplied("");
			setVia(null);
			setStatus(file.size > 125829120 ? "Large clip loaded. Saving may take a while." : "Clip loaded. Describe the cut.");
		} catch {
			URL.revokeObjectURL(url);
			setStatus("That file couldn’t be read. Try an MP4 or WebM.");
		}
	}
	function onPick(list) {
		const file = list?.[0];
		if (file) loadFile(file);
	}
	function onDrop(event) {
		event.preventDefault();
		const file = event.dataTransfer.files[0];
		if (file) loadFile(file);
	}
	async function useSample() {
		setBusy("sample");
		setProgress(0);
		setStatus("Making a 5-second sample reel…");
		try {
			replaceClip(await recordSampleReel(setProgress));
			setRecipe(null);
			setApplied("");
			setVia(null);
			setStatus("Sample reel ready. Describe the cut, then press Cut.");
		} catch (error) {
			setStatus(error instanceof Error ? error.message : "Couldn’t make a sample.");
		} finally {
			setBusy(null);
			setProgress(0);
		}
	}
	async function ensureAudio() {
		if (!audioRef.current) audioRef.current = new AudioContext();
		if (audioRef.current.state === "suspended") await audioRef.current.resume();
		return audioRef.current;
	}
	function stopScore() {
		scoreStop.current?.();
		scoreStop.current = null;
	}
	async function playFrom(plan) {
		const video = videoRef.current;
		const current = clipRef.current;
		if (!video || !current) return;
		stopScore();
		const { start } = windowFor(plan, current.duration);
		video.playbackRate = plan.speed;
		video.preservesPitch = true;
		video.volume = plan.sourceGain;
		try {
			await seekTo(video, start);
			await video.play();
			setPlaying(true);
			if (plan.music !== "none") {
				const ctx = await ensureAudio();
				scoreStop.current = startScore(ctx, ctx.destination, plan.music, plan.musicGain);
			}
		} catch {
			setPlaying(false);
			setStatus("Press play to preview. The browser held back autoplay.");
		}
	}
	async function togglePlay() {
		const video = videoRef.current;
		if (!video || !clipRef.current) return;
		if (!video.paused) {
			video.pause();
			stopScore();
			setPlaying(false);
			return;
		}
		await playFrom(recipeRef.current ?? NEUTRAL_RECIPE);
	}
	toggleRef.current = () => {
		togglePlay();
	};
	async function cut() {
		const text = prompt.trim();
		if (!clipRef.current) {
			setStatus("Add a clip first.");
			return;
		}
		if (text.length < 2) {
			setStatus("Describe the cut in a sentence.");
			return;
		}
		setBusy("plan");
		setStatus("Reading your prompt…");
		let next = interpretPrompt(text);
		let planned = "device";
		try {
			const remote = await planEdit({ data: { prompt: text } });
			if (remote.ok) {
				next = remote.recipe;
				planned = "grok";
			}
		} catch {
			planned = "device";
		}
		const current = clipRef.current;
		const capped = current ? windowFor(next, current.duration).capped : false;
		setRecipe(next);
		setVia(planned);
		setApplied(text);
		setBusy(null);
		const where = planned === "grok" ? "Planned with Grok." : "Planned on this phone.";
		setStatus(capped ? `${where} Held to 40 seconds so saving stays reliable.` : `${where} Preview it, then save.`);
		playFrom(next);
	}
	async function save() {
		const current = clipRef.current;
		const plan = recipeRef.current;
		if (!current || !plan) return;
		videoRef.current?.pause();
		stopScore();
		setPlaying(false);
		cancelSave.current = false;
		setBusy("save");
		setProgress(0);
		setStatus("Saving plays the cut in real time.");
		try {
			const result = await exportClip(current.url, plan, setProgress, () => cancelSave.current);
			if (cancelSave.current) {
				setStatus("Save cancelled.");
				return;
			}
			const how = await deliverFile(result.blob, result.filename);
			const size = formatBytes(result.blob.size);
			if (how === "dismissed") setStatus("Share closed. You can save again.");
			else if (how === "shared") setStatus(`Sent ${size}. Keep it from the share sheet.`);
			else setStatus(`Saved ${size}. Look in Downloads.`);
		} catch (error) {
			setStatus(error instanceof Error ? error.message : "Couldn’t save the video.");
		} finally {
			setBusy(null);
		}
	}
	async function installNow() {
		if (!deferred) return;
		await deferred.prompt();
		const choice = await deferred.userChoice;
		setDeferred(null);
		if (choice.outcome === "accepted") {
			setInstalled(true);
			setInstallOpen(false);
		}
	}
	const plan = recipe ?? NEUTRAL_RECIPE;
	const span = clip ? windowFor(plan, clip.duration) : {
		start: 0,
		end: 0,
		capped: false
	};
	const scrub = clip && span.end > span.start ? Math.max(0, Math.min(1e3, Math.round((playhead - span.start) / (span.end - span.start) * 1e3))) : 0;
	const dirty = prompt.trim() !== applied || !recipe;
	const outputSeconds = clip ? (span.end - span.start) / plan.speed : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "safe-page mx-auto flex min-h-dvh w-full max-w-5xl flex-col gap-6 lg:px-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-start justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-wide text-subtle",
						children: "Free on your phone"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-3xl font-medium tracking-tight text-fg",
						children: "OneCut"
					})]
				}), installed ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "press inline-flex min-h-11 shrink-0 items-center gap-2 rounded-control border border-line px-3 text-sm font-medium text-fg",
					onClick: () => setInstallOpen(true),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smartphone, {
						className: "size-4",
						"aria-hidden": "true"
					}), "Install"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid items-start gap-6 lg:grid-cols-[minmax(0,420px)_minmax(0,1fr)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "min-w-0 lg:sticky lg:top-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-4 max-w-md text-sm text-muted",
							children: "One prompt sets the grade, pace, titles, and score. The video never leaves this phone."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "relative mx-auto overflow-hidden rounded-card border border-line bg-bg",
							style: clip ? frameStyle(clip.width, clip.height) : frameStyle(9, 16),
							onDragOver: (event) => event.preventDefault(),
							onDrop,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "absolute inset-0",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
										ref: videoRef,
										className: "absolute inset-0 h-full w-full opacity-0",
										playsInline: true,
										preload: "auto"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
										ref: canvasRef,
										className: "relative z-10 h-full w-full"
									}),
									clip ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "press absolute bottom-3 left-3 z-20 inline-flex size-11 items-center justify-center rounded-full bg-accent text-accent-fg",
										onClick: () => void togglePlay(),
										"aria-label": playing ? "Pause" : "Play",
										children: playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" })
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "absolute inset-0 z-20 flex flex-col items-center justify-center gap-4 p-4 text-center",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-display text-2xl text-fg",
												children: "Add a clip"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "max-w-xs text-sm text-muted",
												children: "Upload, record, or try the sample street at dusk."
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex flex-wrap items-center justify-center gap-2",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
														type: "button",
														className: "press inline-flex min-h-11 items-center gap-2 rounded-control bg-accent px-4 text-sm font-medium text-accent-fg",
														onClick: () => fileRef.current?.click(),
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, {
															className: "size-4",
															"aria-hidden": "true"
														}), "Upload"]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
														type: "button",
														className: "press inline-flex min-h-11 items-center gap-2 rounded-control border border-line bg-surface px-4 text-sm font-medium text-fg",
														onClick: () => cameraRef.current?.click(),
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, {
															className: "size-4",
															"aria-hidden": "true"
														}), "Camera"]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
														type: "button",
														className: "press inline-flex min-h-11 items-center gap-2 rounded-control border border-line bg-surface px-4 text-sm font-medium text-fg",
														onClick: () => void useSample(),
														disabled: busy !== null,
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Film, {
															className: "size-4",
															"aria-hidden": "true"
														}), "Sample"]
													})
												]
											})
										]
									})
								]
							})
						}),
						clip ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-1 flex items-center justify-between text-xs text-muted tabular-nums",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatTime(Math.max(0, playhead - span.start)) }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "truncate px-3 text-subtle",
										children: clip.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatTime(outputSeconds) })
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "range",
								min: 0,
								max: 1e3,
								value: Number.isFinite(scrub) ? scrub : 0,
								"aria-label": "Scrub the cut",
								className: "w-full",
								onChange: (event) => {
									const video = videoRef.current;
									if (!video || !clip) return;
									const { start, end } = windowFor(plan, clip.duration);
									const time = start + Number(event.target.value) / 1e3 * (end - start);
									video.currentTime = time;
									setPlayhead(time);
								}
							})]
						}) : null
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "flex min-w-0 flex-col gap-4",
					children: [
						clip ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "press inline-flex min-h-11 items-center gap-2 rounded-control border border-line px-3 text-sm text-fg",
								onClick: () => fileRef.current?.click(),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, {
									className: "size-4",
									"aria-hidden": "true"
								}), "Replace"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "press inline-flex min-h-11 items-center gap-2 rounded-control border border-line px-3 text-sm text-fg",
								onClick: () => void useSample(),
								disabled: busy !== null,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Film, {
									className: "size-4",
									"aria-hidden": "true"
								}), "Sample"]
							})]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex flex-col gap-2",
							htmlFor: "prompt",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm font-medium text-fg",
								children: "One prompt"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								id: "prompt",
								value: prompt,
								maxLength: 500,
								rows: 4,
								placeholder: "Warm cinematic grade, slow the middle, title “Sunday”, soft score.",
								className: "min-h-28 w-full resize-none rounded-card border border-line bg-surface px-4 py-3 text-base text-fg outline-none placeholder:text-subtle",
								onChange: (event) => {
									setPrompt(event.target.value);
									window.localStorage.setItem("onecut-prompt", event.target.value);
								}
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex min-w-0 gap-2 overflow-x-auto pb-1",
							children: PRESETS.map((preset) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "press inline-flex min-h-11 shrink-0 items-center rounded-control border border-line px-3 text-sm text-muted",
								onClick: () => {
									setPrompt(preset.prompt);
									window.localStorage.setItem("onecut-prompt", preset.prompt);
								},
								children: preset.label
							}, preset.label))
						}),
						recipe ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-card border border-line bg-surface p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-fg",
									children: recipe.summary || "Cut ready."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-xs text-subtle",
									children: via === "grok" ? "Read by Grok" : "Read on this phone"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-3 flex flex-col gap-1 text-sm text-muted",
									children: clip ? recipeNotes(recipe, clip.duration).map((note) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: note }, note)) : null
								})
							]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "min-h-5 text-sm text-muted",
							"aria-live": "polite",
							children: status
						}),
						busy === "sample" || busy === "save" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-1 overflow-hidden rounded-full bg-elevated",
							role: "progressbar",
							"aria-valuemin": 0,
							"aria-valuemax": 100,
							"aria-valuenow": Math.round(progress * 100),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-full bg-accent",
								style: { width: `${Math.round(progress * 100)}%` }
							})
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "sticky bottom-0 z-30 -mx-4 border-t border-line bg-bg px-4 py-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: `press inline-flex min-h-11 items-center justify-center rounded-control px-4 text-sm font-medium disabled:opacity-40 ${recipe && !dirty ? "border border-line text-fg" : "flex-1 bg-accent text-accent-fg"}`,
									onClick: () => void cut(),
									disabled: busy !== null || prompt.trim().length < 2,
									children: busy === "plan" ? "Reading prompt…" : recipe && !dirty ? "Cut again" : "Cut"
								}), recipe ? busy === "save" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "press inline-flex min-h-11 flex-1 items-center justify-center rounded-control border border-line px-4 text-sm font-medium text-fg",
									onClick: () => {
										cancelSave.current = true;
									},
									children: "Cancel save"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: `press inline-flex min-h-11 flex-1 items-center justify-center gap-2 rounded-control px-4 text-sm font-medium disabled:opacity-40 ${dirty ? "border border-line text-fg" : "bg-accent text-accent-fg"}`,
									onClick: () => void save(),
									disabled: busy !== null || dirty,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
										className: "size-4",
										"aria-hidden": "true"
									}), "Save video"]
								}) : null]
							})
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: fileRef,
				type: "file",
				accept: "video/*",
				className: "sr-only",
				onChange: (event) => {
					onPick(event.target.files);
					event.target.value = "";
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: cameraRef,
				type: "file",
				accept: "video/*",
				capture: "environment",
				className: "sr-only",
				onChange: (event) => {
					onPick(event.target.files);
					event.target.value = "";
				}
			}),
			installOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-40 flex items-end justify-center bg-bg/80 p-4 sm:items-center",
				onClick: () => setInstallOpen(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					role: "dialog",
					"aria-modal": "true",
					"aria-labelledby": "install-title",
					className: "w-full max-w-md rounded-card border border-line bg-surface p-5",
					onClick: (event) => event.stopPropagation(),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							id: "install-title",
							className: "font-display text-2xl font-medium text-fg",
							children: "Install on your phone"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: "There isn’t an APK to sideload. Android and iPhone install OneCut from the browser onto your home screen, and it opens full screen like any other app. Your clips still stay on the device."
						}),
						deferred ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "press mt-4 inline-flex min-h-11 w-full items-center justify-center rounded-control bg-accent px-4 text-sm font-medium text-accent-fg",
							onClick: () => void installNow(),
							children: "Install OneCut"
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 grid gap-4 text-sm text-muted sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium text-fg",
								children: "Android"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
								className: "mt-1 list-decimal pl-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Open OneCut in Chrome." }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Tap the menu." }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Choose Install app or Add to Home screen." })
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium text-fg",
								children: "iPhone"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
								className: "mt-1 list-decimal pl-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Open OneCut in Safari." }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Tap Share." }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Choose Add to Home Screen." })
								]
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "press mt-4 inline-flex min-h-11 w-full items-center justify-center rounded-control border border-line text-sm font-medium text-fg",
							onClick: () => setInstallOpen(false),
							children: "Close"
						})
					]
				})
			}) : null
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Studio, {});
}
//#endregion
export { Home as component };
