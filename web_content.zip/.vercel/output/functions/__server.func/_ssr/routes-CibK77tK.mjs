import { Y as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as buttonClass, I as presetLabel, U as useSelectedGame, V as useAppStore, _ as PageHeader, j as formatWhen, p as MetricRow, v as Panel } from "./ui-CJMJB--P.mjs";
import { n as useDeviceSnapshot, t as RefreshMeasure } from "./refresh-measure-CQ_5yNsN.mjs";
import { n as SessionClock, t as DevicePanel } from "./session-clock-Dj1rOmaj.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CibK77tK.js
var import_jsx_runtime = require_jsx_runtime();
var QUICK = [
	{
		to: "/boost",
		label: "Optimize",
		variant: "primary"
	},
	{
		to: "/games",
		label: "Game Library",
		variant: "quiet"
	},
	{
		to: "/clicker",
		label: "Auto Clicker",
		variant: "quiet"
	},
	{
		to: "/tools",
		hash: "tutorials",
		label: "Tutorials",
		variant: "quiet"
	},
	{
		to: "/settings",
		hash: "customize",
		label: "Customize",
		variant: "quiet"
	}
];
function HomePage() {
	const visible = useAppStore((state) => state.widgets).filter((widget) => widget.visible);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "stack",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			kicker: "Dashboard",
			title: "Session desk",
			subtitle: "Recommendations and measurements you can check. Nothing here is a live overlay on a game."
		}), visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			title: "Widgets hidden",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Every home widget is turned off."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/settings",
				hash: "widgets",
				className: "mt-3 inline-flex text-sm font-semibold text-primary",
				children: "Edit home widgets"
			})]
		}) : visible.map((widget) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeWidget, { id: widget.id }, widget.id))]
	});
}
function HomeWidget({ id }) {
	if (id === "quick") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuickActions, {});
	if (id === "session") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
		title: "Session timer",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SessionClock, { prominent: true })
	});
	if (id === "profile") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfileCard, {});
	if (id === "status") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusCard, {});
	if (id === "refresh") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
		title: "Display refresh",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshMeasure, {})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
		title: "Device and browser",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DevicePanel, {})
	});
}
function QuickActions() {
	const [primary, ...rest] = QUICK;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
		title: "Quick actions",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "stack",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: primary.to,
				className: buttonClass("primary", "w-full"),
				children: primary.label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-2",
				children: rest.map((action) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: action.to,
					hash: action.hash,
					className: buttonClass("quiet", "w-full"),
					children: action.label
				}, action.label))
			})]
		})
	});
}
function ProfileCard() {
	const game = useSelectedGame();
	if (!game) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		title: "Selected game",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: "No profile selected."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/games",
			className: "mt-3 inline-flex text-sm font-semibold text-primary",
			children: "Open the library"
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		title: "Selected game",
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/games",
			hash: `g-${game.id}`,
			className: "text-sm font-semibold text-primary",
			children: "Edit"
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Monogram, {
					name: game.name,
					image: game.image
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate font-display text-xl font-semibold",
						children: game.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: presetLabel(game.preset)
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-xs font-semibold tracking-widest text-faint uppercase",
				children: "Target"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-3xl font-semibold tabular-nums",
				children: game.fpsTarget
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Not a measured frame rate."
			})
		]
	});
}
function StatusCard() {
	const game = useSelectedGame();
	const logs = useAppStore((state) => state.fpsLogs);
	const sample = useAppStore((state) => state.refreshSample);
	const batteryLine = useBatteryLine();
	const last = logs.find((entry) => game ? entry.gameId === game.id : true) ?? logs[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		title: "Performance status",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricRow, {
					label: "Profile",
					value: game?.name ?? "None selected",
					source: "Your library"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricRow, {
					label: "Preset",
					value: game ? presetLabel(game.preset) : "—",
					source: "Saved preference. Not a system power mode."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricRow, {
					label: "Target FPS",
					value: game ? String(game.fpsTarget) : "—",
					source: "Target only. This app cannot force it."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricRow, {
					label: "Last measured FPS",
					value: last ? String(last.measuredFps) : "No manual measurement yet",
					source: last ? `You entered this ${formatWhen(last.at)}.` : "Manual FPS log"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricRow, {
					label: "Display refresh",
					value: sample ? `${sample.displayHz} Hz` : "Not measured yet",
					source: "Separate from rendered FPS and from interpolated FPS. Page estimate only."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricRow, {
					label: "Battery",
					value: batteryLine.value,
					unavailable: batteryLine.unavailable,
					source: batteryLine.source
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm font-semibold",
				children: "Frame generation unavailable in this version."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "CPU load, GPU load, and temperature are not available in this version. They are listed on the device card."
			})
		]
	});
}
function useBatteryLine() {
	const snap = useDeviceSnapshot();
	if (!snap) return {
		value: "Checking…",
		unavailable: false,
		source: "Battery Status API"
	};
	if (!snap.battery) return {
		value: null,
		unavailable: true,
		source: snap.batterySupported ? "Battery Status API returned nothing." : "Battery Status API is not in this browser."
	};
	return {
		value: `${Math.round(snap.battery.level * 100)}% · ${snap.battery.charging ? "charging" : "not charging"}`,
		unavailable: false,
		source: "Battery Status API"
	};
}
function Monogram({ name, image }) {
	if (image) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: image,
		alt: "",
		className: "media-frame size-14 rounded-lg object-cover"
	});
	const letter = name.trim().slice(0, 1).toUpperCase() || "?";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid size-14 place-items-center rounded-lg bg-surface-2 font-display text-xl text-primary",
		"aria-hidden": "true",
		children: letter
	});
}
var SplitComponent = HomePage;
//#endregion
export { SplitComponent as component };
