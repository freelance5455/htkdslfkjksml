import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, r as Slot, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as create } from "../_libs/zustand.mjs";
import { t as require_lib } from "../_libs/jszip+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/library-Dk3ax1hI.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var import_lib = /* @__PURE__ */ __toESM(require_lib());
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function hashString(value) {
	let hash = 0;
	for (let i = 0; i < value.length; i += 1) hash = hash * 31 + value.charCodeAt(i) | 0;
	return Math.abs(hash);
}
function formatCount(n) {
	return new Intl.NumberFormat("es-ES").format(n);
}
function estimateMinutes(chars, rate = 1) {
	return Math.max(1, Math.round(chars / (900 * rate)));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap font-sans text-sm font-medium transition-[color,background-color,box-shadow,transform,opacity] duration-[var(--motion-quick)] ease-[var(--ease-out)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-bg disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			default: "bg-accent text-accent-fg shadow-[var(--shadow-border)] hover:opacity-90",
			secondary: "bg-bg-elevated text-fg shadow-[var(--shadow-border)] hover:bg-bg-subtle",
			outline: "bg-transparent text-fg shadow-[var(--shadow-border)] hover:bg-bg-elevated",
			ghost: "bg-transparent text-fg hover:bg-bg-elevated",
			danger: "bg-danger text-accent-fg hover:opacity-90"
		},
		size: {
			default: "h-11 rounded-md px-4",
			sm: "h-9 rounded-sm px-3 text-xs",
			lg: "h-12 rounded-lg px-5",
			icon: "size-11 rounded-md",
			play: "size-16 rounded-full"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, type, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		ref,
		type: asChild ? void 0 : type ?? "button",
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
});
Button.displayName = "Button";
var MIN_CHAPTER_CHARS = 24;
async function parseEpub(data) {
	const zip = await import_lib.default.loadAsync(data);
	const containerXml = await readZipText(zip, "META-INF/container.xml");
	if (!containerXml) throw new Error("EPUB inválido: falta META-INF/container.xml");
	const container = parseXml(containerXml);
	const rootPath = firstByLocal(container, "rootfile")?.getAttribute("full-path") ?? container.querySelector("rootfile")?.getAttribute("full-path");
	if (!rootPath) throw new Error("EPUB inválido: no se encontró el paquete OPF");
	const opfDir = dirname(rootPath);
	const opfText = await readZipText(zip, rootPath);
	if (!opfText) throw new Error("EPUB inválido: no se pudo leer el archivo OPF");
	const opf = parseXml(opfText);
	const title = firstText(opf, "title")?.trim() || guessTitleFromFilename(rootPath) || "Libro sin título";
	const author = firstText(opf, "creator")?.trim() || null;
	const manifest = /* @__PURE__ */ new Map();
	for (const item of [...opf.getElementsByTagName("*")].filter((el) => el.localName === "item")) {
		const id = item.getAttribute("id");
		const href = item.getAttribute("href");
		const type = item.getAttribute("media-type") ?? "";
		if (id && href) manifest.set(id, {
			href,
			type
		});
	}
	const spineIds = [];
	for (const itemref of [...opf.getElementsByTagName("*")].filter((el) => el.localName === "itemref")) {
		const idref = itemref.getAttribute("idref");
		if (idref) spineIds.push(idref);
	}
	const hrefTitles = await loadNavTitles(zip, opf, manifest, opfDir);
	const chapters = [];
	for (const id of spineIds) {
		const item = manifest.get(id);
		if (!item || !isHtmlItem(item)) continue;
		const path = resolvePath(opfDir, item.href);
		const html = await readZipText(zip, path);
		if (!html) continue;
		const parts = splitHtmlIntoChapters(html, hrefTitles.get(path) ?? hrefTitles.get(item.href) ?? hrefTitles.get(stripHash(item.href)));
		for (const part of parts) {
			if (part.text.trim().length < MIN_CHAPTER_CHARS) continue;
			chapters.push({
				title: part.title || `Capítulo ${chapters.length + 1}`,
				text: part.text
			});
		}
	}
	if (chapters.length === 0) throw new Error("No se encontró texto legible en este EPUB");
	return {
		title,
		author,
		chapters
	};
}
function isHtmlItem(item) {
	if (item.type.includes("html") || item.type.includes("xhtml")) return true;
	return /\.x?html?$/i.test(item.href);
}
async function loadNavTitles(zip, opf, manifest, opfDir) {
	const titles = /* @__PURE__ */ new Map();
	const ncx = [...manifest.values()].find((m) => m.type.includes("dtbncx")) ?? [...manifest.values()].find((m) => /\.ncx$/i.test(m.href));
	if (!ncx) return titles;
	const ncxPath = resolvePath(opfDir, ncx.href);
	const ncxText = await readZipText(zip, ncxPath);
	if (!ncxText) return titles;
	const doc = parseXml(ncxText);
	const ncxDir = dirname(ncxPath);
	for (const point of [...doc.getElementsByTagName("*")].filter((el) => el.localName === "navPoint")) {
		const label = [...point.getElementsByTagName("*")].find((el) => el.localName === "text")?.textContent?.trim() ?? "";
		const src = [...point.getElementsByTagName("*")].find((el) => el.localName === "content")?.getAttribute("src") ?? "";
		if (!label || !src) continue;
		const file = resolvePath(ncxDir, stripHash(src));
		if (!titles.has(file)) titles.set(file, label);
	}
	return titles;
}
function splitHtmlIntoChapters(html, fallbackTitle) {
	const doc = new DOMParser().parseFromString(wrapHtml(html), "text/html");
	doc.querySelectorAll("script, style, svg, nav").forEach((node) => node.remove());
	const body = doc.body;
	if (!body) return [];
	const headings = [...body.querySelectorAll("h1, h2")];
	if (headings.length >= 2) {
		const parts = [];
		for (const heading of headings) {
			const title = (heading.textContent ?? "").replace(/\s+/g, " ").trim();
			const buffer = [];
			let node = heading.nextSibling;
			while (node && !(node instanceof HTMLElement && /^H[12]$/.test(node.tagName))) {
				buffer.push(plainFromNode(node));
				node = node.nextSibling;
			}
			const text = normalizeText(buffer.join("\n"));
			if (text.length >= MIN_CHAPTER_CHARS) parts.push({
				title: title || fallbackTitle || "Capítulo",
				text
			});
		}
		if (parts.length > 0) return parts;
	}
	const text = htmlToPlainText(html);
	if (!text) return [];
	return [{
		title: body.querySelector("h1, h2, h3")?.textContent?.replace(/\s+/g, " ").trim() || fallbackTitle || "",
		text
	}];
}
function wrapHtml(html) {
	if (/<html/i.test(html) || /<body/i.test(html)) return html;
	return `<!doctype html><html><body>${html}</body></html>`;
}
function htmlToPlainText(html) {
	const doc = new DOMParser().parseFromString(wrapHtml(html), "text/html");
	doc.querySelectorAll("script, style, svg, nav").forEach((node) => node.remove());
	return normalizeText(plainFromNode(doc.body));
}
function plainFromNode(node) {
	if (!node) return "";
	if (node.nodeType === Node.TEXT_NODE) return node.textContent ?? "";
	if (node.nodeType !== Node.ELEMENT_NODE) return "";
	const el = node;
	const tag = el.tagName;
	if (tag === "SCRIPT" || tag === "STYLE" || tag === "SVG" || tag === "NAV") return "";
	if (tag === "BR") return "\n";
	const block = /^(P|DIV|H[1-6]|LI|TR|BLOCKQUOTE|SECTION|ARTICLE|HEADER|PRE)$/.test(tag);
	const parts = [];
	if (block) parts.push("\n");
	for (const child of el.childNodes) parts.push(plainFromNode(child));
	if (block) parts.push("\n");
	return parts.join("");
}
function normalizeText(text) {
	return text.replace(/\u00a0/g, " ").replace(/[ \t]+\n/g, "\n").replace(/\n[ \t]+/g, "\n").replace(/[ \t]{2,}/g, " ").replace(/\n{3,}/g, "\n\n").trim();
}
function parseXml(xml) {
	const cleaned = xml.replace(/xmlns(:[A-Za-z0-9]+)?="[^"]*"/g, "").replace(/(<\/?)[A-Za-z0-9]+:/g, "$1");
	return new DOMParser().parseFromString(cleaned, "text/xml");
}
function firstByLocal(root, local) {
	const all = root.getElementsByTagName("*");
	for (const el of all) if (el.localName === local) return el;
	return null;
}
function firstText(root, local) {
	return firstByLocal(root, local)?.textContent?.trim() || null;
}
function dirname(path) {
	const i = path.lastIndexOf("/");
	return i === -1 ? "" : path.slice(0, i + 1);
}
function stripHash(href) {
	const i = href.indexOf("#");
	return i === -1 ? href : href.slice(0, i);
}
function resolvePath(baseDir, href) {
	const clean = stripHash(href).replace(/\\/g, "/");
	if (clean.startsWith("/")) return clean.slice(1);
	const parts = `${baseDir}${clean}`.split("/");
	const out = [];
	for (const part of parts) {
		if (!part || part === ".") continue;
		if (part === "..") out.pop();
		else out.push(part);
	}
	return out.join("/");
}
async function readZipText(zip, path) {
	const variants = [
		path,
		decodeURIComponent(path),
		path.replace(/\\/g, "/")
	];
	for (const candidate of variants) {
		const file = zip.file(candidate);
		if (file) return file.async("text");
	}
	const lower = path.toLowerCase();
	const match = Object.keys(zip.files).find((name) => name.toLowerCase() === lower);
	if (match) return zip.file(match)?.async("text") ?? null;
	return null;
}
function guessTitleFromFilename(path) {
	return (path.split("/").pop() ?? "").replace(/\.[^.]+$/, "") || null;
}
function toSummary(book) {
	return {
		id: book.id,
		title: book.title,
		author: book.author,
		addedAt: book.addedAt,
		isSample: book.isSample,
		sourceName: book.sourceName,
		chapterCount: book.chapters.length,
		totalChars: book.totalChars
	};
}
function totalCharsOf(chapters) {
	return chapters.reduce((sum, chapter) => sum + chapter.text.length, 0);
}
var CHAPTERS = [
	{
		title: "Cómo escuchar un libro",
		text: `Folio abre un archivo EPUB, extrae el texto capítulo a capítulo y lo lee en voz alta con las voces instaladas en tu navegador.

Para empezar, pulsa «Abrir un EPUB» o arrastra el archivo hasta la biblioteca. El libro queda guardado en este dispositivo, así que puedes cerrar la pestaña y continuar más tarde justo en el capítulo donde lo dejaste.

En el lector, elige una voz. Si tu sistema tiene voces en español, aparecerán primero. Ajusta la velocidad al oído: un paso más lento ayuda en prosa densa; un paso más rápido sirve para repasos.

Pulsa reproducir. Folio resalta la frase que está leyendo y avanza sola al capítulo siguiente. Puedes saltar de capítulo con los botones laterales o abrir el índice.

Esta app vive en el navegador. En el teléfono, instálala en la pantalla de inicio para abrirla como si fuera nativa. El motor de voz es el del sistema: la calidad y el género de las voces dependen de lo que tengas descargado en Ajustes.

El capítulo que sigue es un fragmento de dominio público, para que pruebes la lectura sin importar nada.`
	},
	{
		title: "Don Quijote. Capítulo primero",
		text: `En un lugar de la Mancha, de cuyo nombre no quiero acordarme, no ha mucho tiempo que vivía un hidalgo de los de lanza en astillero, adarga antigua, rocín flaco y galgo corredor. Una olla de algo más vaca que carnero, salpicón las más noches, duelos y quebrantos los sábados, lantejas los viernes, algún palomino de añadidura los domingos, consumían las tres partes de su hacienda.

El resto della concluían sayo de velarte, calzas de velludo para las fiestas, con sus pantuflos de lo mismo, y los días de entresemana se honraba con su vellorí de lo más fino. Tenía en su casa una ama que pasaba de los cuarenta, y una sobrina que no llegaba a los veinte, y un mozo de campo y plaza, que así ensillaba el rocín como tomaba la podadera.

Frisaba la edad de nuestro hidalgo con los cincuenta años; era de complexión recia, seco de carnes, enjuto de rostro, gran madrugador y amigo de la caza. Quieren decir que tenía el sobrenombre de Quijada, o Quesada, que en esto hay alguna diferencia en los autores que deste caso escriben; aunque, por conjeturas verosímiles, se deja entender que se llamaba Quejana. Pero esto importa poco a nuestro cuento; basta que en la narración dél no se salga un punto de la verdad.

Es, pues, de saber que este hidalgo, los ratos que estaba ocioso —que eran los más del año—, se daba a leer libros de caballerías, con tanta afición y gusto, que olvidó casi de todo punto el ejercicio de la caza y aun la administración de su hacienda. Y llegó a tanto su curiosidad y desatino en esto, que vendió muchas hanegas de tierra de sembradura para comprar libros de caballerías en que leer, y así, llevó a su casa todos cuantos pudo haber dellos.

Y desta manera, con estas razones, perdía el pobre caballero el juicio, y desvelábase por entenderlas y desentrañarles el sentido, que no se lo sacara ni las entendiera el mesmo Aristóteles, si resucitara para ello. No estaba muy bien con las heridas que don Belianís daba y recibía, porque se imaginaba que, por grandes maestros que le hubiesen curado, no dejaría de tener el rostro y todo el cuerpo lleno de cicatrices y señales.

En resolución, él se enfrascó tanto en su lectura, que se le pasaban las noches leyendo de claro en claro, y los días de turbio en turbio; y así, del poco dormir y del mucho leer, se le secó el cerebro, de manera que vino a perder el juicio. Llenósele la fantasía de todo aquello que leía en los libros, así de encantamentos como de pendencias, batallas, desafíos, heridas, requiebros, amores, tormentas y disparates imposibles; y aséntosele de tal modo en la imaginación que era verdad toda aquella máquina de aquellas soñadas invenciones que leía, que para él no había otra historia más cierta en el mundo.`
	},
	{
		title: "Rima LIII — Gustavo Adolfo Bécquer",
		text: `Volverán las oscuras golondrinas en tu balcón sus nidos a colgar, y otra vez con el ala a sus cristales jugando llamarán. Pero aquellas que el vuelo refrenaban tu hermosura y mi dicha a contemplar, aquellas que aprendieron nuestros nombres... esas... no volverán.

Volverán las tupidas madreselvas de tu jardín las tapias a escalar, y otra vez a la tarde, aun más hermosas, sus flores se abrirán. Pero aquellas, cuajadas de rocío, cuyas gotas mirábamos temblar y caer, como lágrimas del día... esas... no volverán.

Volverán del amor en tus oídos las palabras ardientes a sonar; tu corazón de su profundo sueño tal vez despertará. Pero mudo y absorto y de rodillas, como se adora a Dios ante su altar, como yo te he querido..., desengáñate: así no te querrán.`
	},
	{
		title: "La lámpara de aceite",
		text: `Había en el pueblo una habitación que nadie alquilaba dos veces. No era por la humedad ni por el tamaño: era por el silencio. Un silencio tan trabado que, al cerrar la puerta, el reloj de la plaza dejaba de oírse, como si el cuarto se hubiera desprendido de la calle.

Marta llegó un martes con una maleta y tres libros. El casero, sin mirarla, le dijo que la lámpara de aceite sobre la mesa no se apagaba del todo, que era cosa de la mecha, y que si le molestaba podía traer un quinqué de petróleo. Marta asintió. No pensaba leer de noche. Pensaba dormir.

A la tercera madrugada, la lámpara tenía una llama delgada, casi una coma de fuego. Marta se sentó. Abrió el libro que había dejado a medio empezar y leyó en voz alta, sin saber por qué, como quien prueba el aire de una casa extraña. La llama se estiró. Las palabras salieron más claras de lo que ella esperaba, como si alguien, detrás del yeso, las estuviera sosteniendo.

Leyó hasta el final del capítulo. Cuando calló, la llama volvió a su tamaño de coma. Marta cerró el libro y, por primera vez, durmió.

Desde entonces leyó cada noche. No mucho: diez páginas, doce. Lo bastante para que la habitación tuviera una voz. El silencio ya no era un muro; era una espera. A veces le parecía que la llama se adelantaba a una frase, como si conociera el párrafo. A veces se encogía en las enumeraciones largas, impaciente.

El último domingo, el casero subió a cobrar. Encontró la maleta hecha, la cama tendida, y sobre la mesa la lámpara apagada de verdad, con un hilo de hollín en el cristal. Junto a ella, un papel: «Dejo los tres libros. La casa ya sabe leerlos.»

Nadie volvió a quejarse del silencio. Quien entra ahora, si se queda quieto, oye todavía una frase que no es suya, dicha con una voz que no alcanza a reconocer, y entiende —sin asustarse del todo— que un libro, cuando se lee en voz alta, no se acaba de ir.`
	}
];
var SAMPLE_BOOK_ID = "sample-folio";
function getSampleBook() {
	return {
		id: SAMPLE_BOOK_ID,
		title: "Cuaderno de Folio",
		author: "Muestra",
		chapters: CHAPTERS,
		addedAt: 0,
		isSample: true,
		sourceName: "Libro de muestra",
		totalChars: totalCharsOf(CHAPTERS)
	};
}
var DB_NAME = "folio-library";
var STORE = "books";
var PROGRESS_KEY = "folio-progress";
var SETTINGS_KEY = "folio-settings";
var MAX_BYTES = 83886080;
var defaultSettings = {
	rate: 1,
	voiceURI: null,
	night: false
};
function openDb() {
	return new Promise((resolve, reject) => {
		const req = indexedDB.open(DB_NAME, 1);
		req.onupgradeneeded = () => {
			const db = req.result;
			if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE, { keyPath: "id" });
		};
		req.onsuccess = () => resolve(req.result);
		req.onerror = () => reject(req.error ?? /* @__PURE__ */ new Error("IndexedDB no disponible"));
	});
}
function idbRequest(req) {
	return new Promise((resolve, reject) => {
		req.onsuccess = () => resolve(req.result);
		req.onerror = () => reject(req.error ?? /* @__PURE__ */ new Error("Error de almacenamiento"));
	});
}
async function listStored() {
	const db = await openDb();
	try {
		return (await idbRequest(db.transaction(STORE, "readonly").objectStore(STORE).getAll())).filter((row) => row.id !== SAMPLE_BOOK_ID);
	} finally {
		db.close();
	}
}
async function putStored(book) {
	const db = await openDb();
	try {
		const tx = db.transaction(STORE, "readwrite");
		tx.objectStore(STORE).put(book);
		await new Promise((resolve, reject) => {
			tx.oncomplete = () => resolve();
			tx.onerror = () => reject(tx.error ?? /* @__PURE__ */ new Error("No se pudo guardar"));
		});
	} finally {
		db.close();
	}
}
async function deleteStored(id) {
	const db = await openDb();
	try {
		const tx = db.transaction(STORE, "readwrite");
		tx.objectStore(STORE).delete(id);
		await new Promise((resolve, reject) => {
			tx.oncomplete = () => resolve();
			tx.onerror = () => reject(tx.error ?? /* @__PURE__ */ new Error("No se pudo borrar"));
		});
	} finally {
		db.close();
	}
}
async function getStored(id) {
	const db = await openDb();
	try {
		return await idbRequest(db.transaction(STORE, "readonly").objectStore(STORE).get(id)) ?? null;
	} finally {
		db.close();
	}
}
function readProgress() {
	try {
		const raw = localStorage.getItem(PROGRESS_KEY);
		if (!raw) return {};
		const parsed = JSON.parse(raw);
		return parsed && typeof parsed === "object" ? parsed : {};
	} catch {
		return {};
	}
}
function writeProgress(map) {
	localStorage.setItem(PROGRESS_KEY, JSON.stringify(map));
}
function readSettings() {
	try {
		const raw = localStorage.getItem(SETTINGS_KEY);
		if (!raw) return defaultSettings;
		const parsed = JSON.parse(raw);
		return {
			rate: typeof parsed.rate === "number" ? parsed.rate : defaultSettings.rate,
			voiceURI: typeof parsed.voiceURI === "string" || parsed.voiceURI === null ? parsed.voiceURI : defaultSettings.voiceURI,
			night: Boolean(parsed.night)
		};
	} catch {
		return defaultSettings;
	}
}
function newId() {
	return `b_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}
var useLibrary = create((set, get) => ({
	hydrated: false,
	books: [toSummary(getSampleBook())],
	progress: {},
	settings: defaultSettings,
	hydrate: async () => {
		if (typeof window === "undefined") return;
		try {
			const stored = await listStored();
			set({
				books: [toSummary(getSampleBook()), ...stored.sort((a, b) => b.addedAt - a.addedAt).map(toSummary)],
				progress: readProgress(),
				settings: readSettings(),
				hydrated: true
			});
		} catch {
			set({
				books: [toSummary(getSampleBook())],
				progress: readProgress(),
				settings: readSettings(),
				hydrated: true
			});
		}
	},
	importEpub: async (file) => {
		if (file.size > MAX_BYTES) throw new Error("El archivo pesa demasiado (máximo 80 MB)");
		const parsed = await parseEpub(await file.arrayBuffer());
		const book = {
			id: newId(),
			title: parsed.title,
			author: parsed.author,
			chapters: parsed.chapters,
			addedAt: Date.now(),
			sourceName: file.name,
			totalChars: totalCharsOf(parsed.chapters)
		};
		await putStored(book);
		set({ books: [
			toSummary(getSampleBook()),
			toSummary(book),
			...get().books.filter((b) => !b.isSample && b.id !== book.id)
		] });
		return book;
	},
	removeBook: async (id) => {
		if (id === "sample-folio") return;
		await deleteStored(id);
		const progress = { ...get().progress };
		delete progress[id];
		writeProgress(progress);
		set({
			books: get().books.filter((b) => b.id !== id),
			progress
		});
	},
	getBook: async (id) => {
		if (id === "sample-folio") return getSampleBook();
		return getStored(id);
	},
	saveProgress: (id, chapter, chunk) => {
		const progress = {
			...get().progress,
			[id]: {
				chapter,
				chunk,
				updatedAt: Date.now()
			}
		};
		writeProgress(progress);
		set({ progress });
	},
	saveSettings: (patch) => {
		const settings = {
			...get().settings,
			...patch
		};
		localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
		set({ settings });
	}
}));
//#endregion
export { hashString as a, formatCount as i, cn as n, useLibrary as o, estimateMinutes as r, Button as t };
