import { n as __exportAll$1 } from "../_runtime.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/idb-CjcvWBBp.js
var idb_CjcvWBBp_exports = /* @__PURE__ */ __exportAll$1({
	a: () => listMedia,
	c: () => putMedia,
	d: () => __exportAll,
	i: () => idb_exports,
	l: () => putProfile,
	n: () => deleteProfile,
	o: () => listProfiles,
	r: () => getQuota,
	s: () => moveMedia,
	t: () => deleteMedia,
	u: () => requestPersist
});
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var idb_exports = /* @__PURE__ */ __exportAll({
	deleteMedia: () => deleteMedia,
	deleteProfile: () => deleteProfile,
	getMedia: () => getMedia,
	getQuota: () => getQuota,
	listMedia: () => listMedia,
	listProfiles: () => listProfiles,
	moveMedia: () => moveMedia,
	putMedia: () => putMedia,
	putProfile: () => putProfile,
	requestPersist: () => requestPersist
});
var DB_NAME = "stardex";
var DB_VERSION = 1;
function openDb() {
	return new Promise((resolve, reject) => {
		const req = indexedDB.open(DB_NAME, DB_VERSION);
		req.onupgradeneeded = () => {
			const db = req.result;
			if (!db.objectStoreNames.contains("media")) db.createObjectStore("media", { keyPath: "id" }).createIndex("starSlug", "starSlug", { unique: false });
			if (!db.objectStoreNames.contains("profiles")) db.createObjectStore("profiles", { keyPath: "slug" });
		};
		req.onsuccess = () => resolve(req.result);
		req.onerror = () => reject(req.error ?? /* @__PURE__ */ new Error("indexedDB open failed"));
	});
}
function txDone(tx) {
	return new Promise((resolve, reject) => {
		tx.oncomplete = () => resolve();
		tx.onerror = () => reject(tx.error ?? /* @__PURE__ */ new Error("transaction failed"));
		tx.onabort = () => reject(tx.error ?? /* @__PURE__ */ new Error("transaction aborted"));
	});
}
function reqOf(req) {
	return new Promise((resolve, reject) => {
		req.onsuccess = () => resolve(req.result);
		req.onerror = () => reject(req.error ?? /* @__PURE__ */ new Error("request failed"));
	});
}
async function listMedia() {
	const db = await openDb();
	try {
		return await reqOf(db.transaction("media").objectStore("media").getAll());
	} finally {
		db.close();
	}
}
async function getMedia(id) {
	const db = await openDb();
	try {
		return await reqOf(db.transaction("media").objectStore("media").get(id));
	} finally {
		db.close();
	}
}
async function putMedia(record) {
	const db = await openDb();
	try {
		const tx = db.transaction("media", "readwrite");
		tx.objectStore("media").put(record);
		await txDone(tx);
	} finally {
		db.close();
	}
}
async function deleteMedia(id) {
	const db = await openDb();
	try {
		const tx = db.transaction("media", "readwrite");
		tx.objectStore("media").delete(id);
		await txDone(tx);
	} finally {
		db.close();
	}
}
async function moveMedia(id, starSlug) {
	const db = await openDb();
	try {
		const tx = db.transaction("media", "readwrite");
		const store = tx.objectStore("media");
		const rec = await reqOf(store.get(id));
		if (rec) {
			rec.starSlug = starSlug;
			store.put(rec);
		}
		await txDone(tx);
	} finally {
		db.close();
	}
}
async function listProfiles() {
	const db = await openDb();
	try {
		return await reqOf(db.transaction("profiles").objectStore("profiles").getAll());
	} finally {
		db.close();
	}
}
async function putProfile(record) {
	const db = await openDb();
	try {
		const tx = db.transaction("profiles", "readwrite");
		const store = tx.objectStore("profiles");
		const existing = await reqOf(store.get(record.slug));
		store.put({
			...existing,
			...record
		});
		await txDone(tx);
	} finally {
		db.close();
	}
}
async function deleteProfile(slug) {
	const db = await openDb();
	try {
		const tx = db.transaction("profiles", "readwrite");
		tx.objectStore("profiles").delete(slug);
		await txDone(tx);
	} finally {
		db.close();
	}
}
async function getQuota() {
	try {
		if (!navigator.storage?.estimate) return null;
		const est = await navigator.storage.estimate();
		return {
			usage: est.usage ?? 0,
			quota: est.quota ?? 0
		};
	} catch {
		return null;
	}
}
async function requestPersist() {
	try {
		await navigator.storage?.persist?.();
	} catch {}
}
//#endregion
export { idb_CjcvWBBp_exports as a, moveMedia as c, requestPersist as d, getQuota as i, putMedia as l, deleteMedia as n, listMedia as o, deleteProfile as r, listProfiles as s, __exportAll as t, putProfile as u };
