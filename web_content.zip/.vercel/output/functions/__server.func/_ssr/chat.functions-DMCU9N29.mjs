import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { i as buildSystemPrompt } from "./prompt-DNxJ_SQu.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/chat.functions-DMCU9N29.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function cleanMessages(input) {
	if (!input || !Array.isArray(input.messages)) throw new Error("Geçersiz istek.");
	if (input.messages.length > 14) throw new Error("Çok fazla mesaj.");
	const messages = input.messages.map((message) => {
		if (!message || message.role !== "user" && message.role !== "assistant" || typeof message.content !== "string") throw new Error("Geçersiz mesaj.");
		return {
			role: message.role,
			content: message.content.slice(0, 4e3)
		};
	});
	if (typeof input.dataContext !== "string" || input.dataContext.length > 24e3) throw new Error("Veri çok büyük.");
	return {
		messages,
		dataContext: input.dataContext,
		nowLocal: String(input.nowLocal ?? "").slice(0, 40),
		timeZone: String(input.timeZone ?? "").slice(0, 80)
	};
}
var askNexor_createServerFn_handler = createServerRpc({
	id: "54ca6542a0f01998de26b0165ce636ff9fb427129dfb34de442fc7b8137a4b00",
	name: "askNexor",
	filename: "src/lib/nexor/chat.functions.ts"
}, (opts) => askNexor.__executeServer(opts));
var askNexor = createServerFn({ method: "POST" }).validator((input) => cleanMessages(input)).handler(askNexor_createServerFn_handler, async ({ data }) => {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "Yapay zekâ bu ortamda kullanılamıyor."
	};
	try {
		const res = await fetch("https://api.x.ai/v1/chat/completions", {
			method: "POST",
			signal: AbortSignal.timeout(25e3),
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${apiKey}`
			},
			body: JSON.stringify({
				model: "grok-4.5",
				temperature: .3,
				max_tokens: 800,
				messages: [{
					role: "system",
					content: buildSystemPrompt(data.dataContext, data.nowLocal, data.timeZone)
				}, ...data.messages]
			})
		});
		if (!res.ok) return {
			ok: false,
			error: `Asistan yanıt vermedi (${res.status}).`
		};
		const text = (await res.json()).choices?.[0]?.message?.content ?? "";
		if (!text.trim()) return {
			ok: false,
			error: "Asistan boş yanıt döndürdü."
		};
		return {
			ok: true,
			text
		};
	} catch (error) {
		return {
			ok: false,
			error: error instanceof Error && error.name === "TimeoutError" ? "İstek zaman aşımına uğradı." : "Bağlantı hatası."
		};
	}
});
async function requestSpeech(apiKey, text, withLanguage) {
	const body = {
		text,
		voice_id: "eve"
	};
	if (withLanguage) body.language = "tr";
	return fetch("https://api.x.ai/v1/tts", {
		method: "POST",
		signal: AbortSignal.timeout(2e4),
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		body: JSON.stringify(body)
	});
}
var speakNexor_createServerFn_handler = createServerRpc({
	id: "fc014d317b755dc1bb790328a6d83b1112d25cf90e3f72b4eebc36312c3c3080",
	name: "speakNexor",
	filename: "src/lib/nexor/chat.functions.ts"
}, (opts) => speakNexor.__executeServer(opts));
var speakNexor = createServerFn({ method: "POST" }).validator((input) => {
	const text = String(input?.text ?? "").replace(/\s+/g, " ").trim().slice(0, 420);
	if (!text) throw new Error("Boş metin.");
	return { text };
}).handler(speakNexor_createServerFn_handler, async ({ data }) => {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "Ses kullanılamıyor."
	};
	try {
		let res = await requestSpeech(apiKey, data.text, true);
		if (!res.ok) res = await requestSpeech(apiKey, data.text, false);
		if (!res.ok) return {
			ok: false,
			error: "Ses üretilemedi."
		};
		const bytes = new Uint8Array(await res.arrayBuffer());
		let binary = "";
		for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i] ?? 0);
		return {
			ok: true,
			audio: btoa(binary),
			mime: res.headers.get("content-type") || "audio/mpeg"
		};
	} catch {
		return {
			ok: false,
			error: "Ses üretilemedi."
		};
	}
});
//#endregion
export { askNexor_createServerFn_handler, speakNexor_createServerFn_handler };
