import { i as __toESM } from "../_runtime.mjs";
import { _ as require_react, g as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { G as isRedirect, S as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { O as ArrowLeftRight, a as Sparkles, f as Music, l as Pencil } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { E as utcTodayIso, S as partStatus, T as useMinistry, _ as formatTime, a as Field, b as loadOf, d as arrangeParts, g as formatShort, h as formatLong, i as Card, l as StatusPill, m as fieldClass, o as Modal, p as cn, r as Button, t as AppShell, u as addMinutes, v as fullName, w as toDraft, x as nextReplacement, y as isEligible } from "./shell-CGpvgZIy.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/planner-CdXSfuKV.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function useServerFn(serverFn) {
	const router = useRouter();
	return import_react.useCallback(async (...args) => {
		try {
			const res = await serverFn(...args);
			if (isRedirect(res)) throw res;
			return res;
		} catch (err) {
			if (isRedirect(err)) {
				err.options._fromLocation = router.stores.location.get();
				return router.navigate(router.resolveRedirect(err).options);
			}
			throw err;
		}
	}, [router, serverFn]);
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var arrangeWithGrok = createServerFn({ method: "POST" }).validator((input) => {
	if (!input || typeof input.brief !== "string" || input.brief.length < 20 || input.brief.length > 14e3) throw new Error("Invalid arrangement request");
	return { brief: input.brief };
}).handler(createSsrRpc("ab91f07c010894d1dde65bfcd19126cca80625b1ae1581aec1e2c3fdaa6a4a62"));
function arrangementBrief(congregation, meeting, parts, members, history) {
	return JSON.stringify({
		congregation,
		meeting: {
			date: meeting.date,
			theme: meeting.theme,
			reading: meeting.reading,
			week: meeting.weekLabel
		},
		parts: parts.map((part) => ({
			partId: part.id,
			title: part.title,
			section: part.section,
			durationMin: part.durationMin,
			skill: part.skill,
			who: part.who,
			allowUnbaptized: part.allowUnbaptized,
			preferElder: part.preferElder,
			needsAssistant: part.needsAssistant,
			assistantSkill: part.assistantSkill,
			assistantWho: part.assistantWho,
			assistantAllowUnbaptized: part.assistantAllowUnbaptized
		})),
		roster: members.map((member) => ({
			name: fullName(member),
			gender: member.gender,
			privilege: member.privilege,
			availability: member.awayDates.includes(meeting.date) ? "away" : member.availability,
			recentParts: Math.round(loadOf(history, member.id) * 10) / 10,
			skills: member.skills
		}))
	});
}
var STEPS = [
	"Reading availability",
	"Matching abilities",
	"Balancing the schedule",
	"Writing recommendations"
];
var SECTION_LABEL = {
	opening: "Opening",
	treasures: "Treasures from God’s Word",
	ministry: "Apply Yourself to the Field Ministry",
	living: "Living as Christians",
	closing: "Closing"
};
function PlannerPage() {
	const arrange = useServerFn(arrangeWithGrok);
	const congregation = useMinistry((state) => state.congregation);
	const meetingTime = useMinistry((state) => state.meetingTime);
	const members = useMinistry((state) => state.members);
	const meetings = useMinistry((state) => state.meetings);
	const assignments = useMinistry((state) => state.assignments);
	const lastArrangement = useMinistry((state) => state.lastArrangement);
	const arrangeRequested = useMinistry((state) => state.arrangeRequested);
	const focusMeetingId = useMinistry((state) => state.focusMeetingId);
	const applyMeeting = useMinistry((state) => state.applyMeeting);
	const patchAssignment = useMinistry((state) => state.patchAssignment);
	const today = utcTodayIso();
	const upcoming = meetings.find((meeting) => meeting.date >= today) ?? meetings[0];
	const [meetingId, setMeetingId] = (0, import_react.useState)(upcoming?.id ?? "");
	const [step, setStep] = (0, import_react.useState)(-1);
	const [running, setRunning] = (0, import_react.useState)(false);
	const [editing, setEditing] = (0, import_react.useState)(null);
	const meeting = meetings.find((item) => item.id === meetingId) ?? upcoming;
	const parts = (0, import_react.useMemo)(() => assignments.filter((assignment) => assignment.meetingId === meeting?.id).sort((a, b) => a.order - b.order), [assignments, meeting?.id]);
	async function runArrange(targetId = meeting?.id) {
		const current = meetings.find((item) => item.id === targetId);
		if (!current || running) return;
		const snapshot = assignments.filter((assignment) => assignment.meetingId === current.id).map((assignment) => ({ ...assignment }));
		setRunning(true);
		setStep(0);
		const timers = STEPS.map((_, index) => window.setTimeout(() => setStep(index), index * 420));
		try {
			const history = assignments.filter((assignment) => assignment.meetingId !== current.id);
			const brief = arrangementBrief(congregation, current, snapshot, members, history);
			let picks = [];
			let summary = "Arranged from skills, availability, and recent load.";
			let source = "local";
			try {
				const result = await arrange({ data: { brief } });
				if (result.ok) {
					picks = result.picks;
					summary = result.summary;
					source = "grok";
				}
			} catch {
				source = "local";
			}
			const next = arrangeParts(current.id, current.date, snapshot.map(toDraft), members, history, picks);
			applyMeeting(current.id, next, {
				meetingId: current.id,
				summary,
				source
			});
			toast.success(source === "grok" ? "AI arrangement ready" : "Arrangement ready", {
				description: summary,
				action: {
					label: "Undo",
					onClick: () => applyMeeting(current.id, snapshot, null)
				}
			});
		} finally {
			timers.forEach((timer) => window.clearTimeout(timer));
			setStep(4);
			setRunning(false);
		}
	}
	(0, import_react.useEffect)(() => {
		if (!focusMeetingId) return;
		setMeetingId(focusMeetingId);
		useMinistry.setState({ focusMeetingId: null });
	}, [focusMeetingId]);
	(0, import_react.useEffect)(() => {
		setStep(-1);
	}, [meetingId]);
	(0, import_react.useEffect)(() => {
		if (!arrangeRequested || !meeting) return;
		useMinistry.setState({ arrangeRequested: false });
		runArrange(meeting.id);
	}, [arrangeRequested, meeting?.id]);
	if (!meeting) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted",
		children: "No meetings are on the schedule."
	});
	const note = lastArrangement?.meetingId === meeting.id ? lastArrangement : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "mb-6 flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "max-w-2xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-xs font-semibold tracking-[0.16em] text-royal uppercase",
						children: "AI Meeting Planner"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-3xl text-ink sm:text-4xl",
						children: meeting.theme
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm text-muted sm:text-base",
						children: [
							formatLong(meeting.date),
							" · ",
							meeting.reading,
							". Review every name before it is announced."
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				disabled: running,
				onClick: () => void runArrange(meeting.id),
				className: "tap inline-flex h-14 items-center gap-3 self-start rounded-full bg-royal pr-5 pl-2 text-sm font-semibold text-on-royal disabled:opacity-60",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "ai-orb grid size-10 place-items-center rounded-full bg-cyan text-sidebar",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-5" })
				}), running ? "Arranging…" : "Arrange with AI"]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-5 flex flex-wrap gap-2",
			children: meetings.map((item) => {
				const active = item.id === meeting.id;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setMeetingId(item.id),
					className: cn("tap h-11 shrink-0 rounded-full border px-4 text-sm font-semibold", active ? "border-transparent bg-sidebar text-on-navy" : "border-line bg-card text-ink"),
					children: [item.date < today ? "Past · " : "", formatShort(item.date)]
				}, item.id);
			})
		}),
		running || step === 4 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "mb-5 p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("grid size-11 place-items-center rounded-2xl bg-cyan text-sidebar", running && "ai-orb"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold",
						children: running ? "MinistryFlow is arranging this week" : "Recommendations ready"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: note?.source === "grok" ? "Grok prepared this suggestion." : step === 4 ? "Balanced on this device from skills and availability." : "Checking who is qualified and free."
					})] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-4 grid gap-2 sm:grid-cols-4",
					children: STEPS.map((label, index) => {
						const done = step > index;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: cn("rounded-2xl border px-3 py-3 text-sm", done ? "border-royal/20 bg-royal/8 text-ink" : "border-line text-muted", step === index && running && "border-cyan bg-cyan/10 text-ink"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mr-2 font-semibold tabular-nums",
								children: done ? "✓" : index + 1
							}), label]
						}, label);
					})
				}),
				note && step === 4 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm text-ink",
					children: note.summary
				}) : null
			]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Programme, {
			meetingDate: meeting.date,
			meetingTime,
			songs: meeting.songs,
			parts,
			members,
			today,
			onEdit: setEditing,
			onReplace: (assignment, slot) => {
				const history = assignments.filter((item) => item.meetingId !== meeting.id);
				const replacement = nextReplacement(assignment, meeting.date, members, parts, history, slot);
				if (!replacement) {
					toast("No other qualified publisher is free for this part.");
					return;
				}
				const person = members.find((member) => member.id === replacement.id);
				patchAssignment(assignment.id, slot === "assignee" ? {
					assigneeId: replacement.id,
					reason: replacement.reason
				} : {
					assistantId: replacement.id,
					reason: replacement.reason
				}, {
					title: "Publisher replaced",
					detail: `${assignment.title} · ${person ? fullName(person) : "Updated"}`,
					tone: "edit"
				});
				toast.success("Replacement ready", { description: replacement.reason });
			}
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EditDialog, {
			assignment: editing,
			meetingDate: meeting.date,
			members,
			parts,
			onOpenChange: (open) => {
				if (!open) setEditing(null);
			},
			onSave: (next) => {
				patchAssignment(next.id, next, {
					title: "Assignment edited",
					detail: next.title,
					tone: "edit"
				});
				setEditing(null);
				toast.success("Assignment saved");
			}
		})
	] });
}
function Programme({ meetingDate, meetingTime, songs, parts, members, today, onEdit, onReplace }) {
	const byId = new Map(members.map((member) => [member.id, member]));
	let cursor = 0;
	let sangMid = false;
	const rows = [];
	const pushSong = (number) => {
		const when = formatTime(addMinutes(meetingTime, cursor));
		rows.push({
			key: `song-${number}-${cursor}`,
			node: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3 py-2 text-sm text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-8 place-items-center rounded-full bg-soft text-royal",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Music, { className: "size-3.5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums",
						children: when
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Song ", number] })
				]
			})
		});
		cursor += 4;
	};
	pushSong(songs[0]);
	let lastSection = null;
	for (const part of parts) {
		if (part.section === "living" && !sangMid) {
			pushSong(songs[1]);
			sangMid = true;
		}
		if (part.section === "closing") pushSong(songs[2]);
		const when = formatTime(addMinutes(meetingTime, cursor));
		const status = partStatus(meetingDate, part.assigneeId, today);
		const assignee = part.assigneeId ? byId.get(part.assigneeId) : void 0;
		const assistant = part.assistantId ? byId.get(part.assistantId) : void 0;
		const showSection = part.section !== lastSection;
		lastSection = part.section;
		rows.push({
			key: part.id,
			node: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [showSection ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 mb-2 text-xs font-semibold tracking-[0.14em] text-royal uppercase",
				children: SECTION_LABEL[part.section]
			}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: cn("rounded-3xl border bg-card p-4 shadow-card sm:p-5", status === "unassigned" ? "border-dashed border-warn/60" : "border-line"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs font-semibold text-muted tabular-nums",
									children: [
										when,
										" · ",
										part.durationMin,
										" min"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-1 font-sans text-lg font-semibold tracking-normal text-ink",
									children: part.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted",
									children: part.detail
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid gap-2 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonLine, {
							label: "Assigned member",
							name: assignee ? fullName(assignee) : "Unassigned"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonLine, {
							label: "Assistant",
							name: part.needsAssistant ? assistant ? fullName(assistant) : "Unassigned" : "Not required"
						})]
					}),
					part.reason ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: part.reason
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "soft",
								className: "h-10",
								onClick: () => onEdit(part),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" }), "Edit"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "soft",
								className: "h-10",
								onClick: () => onReplace(part, "assignee"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeftRight, { className: "size-4" }), "Replace"]
							}),
							part.needsAssistant ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								className: "h-10",
								onClick: () => onReplace(part, "assistant"),
								children: "Replace assistant"
							}) : null
						]
					})
				]
			})] })
		});
		cursor += part.durationMin;
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "relative space-y-1 border-l border-line pl-4 sm:pl-6",
		children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: row.node }, row.key))
	});
}
function PersonLine({ label, name }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl bg-soft px-3 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[11px] font-semibold tracking-wide text-muted uppercase",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "truncate text-sm font-semibold",
			children: name
		})]
	});
}
function EditDialog({ assignment, meetingDate, members, parts, onOpenChange, onSave }) {
	const [assigneeId, setAssigneeId] = (0, import_react.useState)("");
	const [assistantId, setAssistantId] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		setAssigneeId(assignment?.assigneeId ?? "");
		setAssistantId(assignment?.assistantId ?? "");
	}, [assignment]);
	const used = /* @__PURE__ */ new Set();
	for (const part of parts) {
		if (!assignment || part.id === assignment.id) continue;
		if (part.assigneeId) used.add(part.assigneeId);
		if (part.assistantId) used.add(part.assistantId);
	}
	const assigneeOptions = assignment ? members.filter((member) => member.id === assigneeId || isEligible(member, {
		date: meetingDate,
		skill: assignment.skill,
		who: assignment.who,
		allowUnbaptized: assignment.allowUnbaptized,
		used
	})) : [];
	const assistantUsed = new Set(used);
	if (assigneeId) assistantUsed.add(assigneeId);
	const assistantOptions = assignment?.assistantSkill ? members.filter((member) => member.id === assistantId || isEligible(member, {
		date: meetingDate,
		skill: assignment.assistantSkill,
		who: assignment.assistantWho,
		allowUnbaptized: assignment.assistantAllowUnbaptized,
		used: assistantUsed
	})) : [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		open: Boolean(assignment),
		onOpenChange,
		title: assignment?.title ?? "Edit assignment",
		description: "Choose a qualified publisher. People already used in this meeting are hidden.",
		children: assignment ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "space-y-4",
			onSubmit: (event) => {
				event.preventDefault();
				onSave({
					...assignment,
					assigneeId: assigneeId || null,
					assistantId: assignment.needsAssistant ? assistantId || null : null,
					reason: assigneeId ? "Adjusted manually by the overseer." : "Cleared. This part is open again."
				});
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Assigned member",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: fieldClass,
						value: assigneeId,
						onChange: (event) => setAssigneeId(event.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "Unassigned"
						}), assigneeOptions.map((member) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: member.id,
							children: fullName(member)
						}, member.id))]
					})
				}),
				assignment.needsAssistant ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Assistant",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: fieldClass,
						value: assistantId,
						onChange: (event) => setAssistantId(event.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "Unassigned"
						}), assistantOptions.map((member) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: member.id,
							children: fullName(member)
						}, member.id))]
					})
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap justify-end gap-2 pt-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "soft",
						onClick: () => onOpenChange(false),
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						children: "Save assignment"
					})]
				})
			]
		}) : null
	});
}
var SplitComponent = function PlannerRoute() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlannerPage, {}) });
};
//#endregion
export { SplitComponent as component };
