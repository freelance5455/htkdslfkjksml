import { i as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, x as require_react } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { b as Link, p as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as ClipboardList, i as House, n as Tags, o as ChevronRight, r as Settings } from "../_libs/lucide-react.mjs";
import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/store-g4o8WGZx.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var NAV = [
	{
		to: "/",
		label: "النظرة",
		icon: House
	},
	{
		to: "/flock",
		label: "القطيع",
		icon: Tags
	},
	{
		to: "/log",
		label: "السجلات",
		icon: ClipboardList
	},
	{
		to: "/more",
		label: "الإعدادات",
		icon: Settings
	}
];
function navActive(path, to) {
	if (to === "/") return path === "/";
	if (to === "/flock") return path === "/flock" || path.startsWith("/sheep");
	return path === to || path.startsWith(`${to}/`);
}
function AppShell({ title, backTo, action, children }) {
	const path = useRouterState({ select: (s) => s.location.pathname });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh overflow-x-hidden bg-background text-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex min-h-dvh w-full max-w-lg min-w-0 flex-col",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-20 flex items-center gap-2 border-b border-border bg-background px-4 pt-safe pb-3",
				children: [
					backTo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: backTo,
						"aria-label": "رجوع",
						className: "flex size-11 items-center justify-center rounded-lg text-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5" })
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "min-w-0 flex-1 truncate text-lg font-semibold leading-tight",
						children: title
					}),
					action ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "shrink-0",
						children: action
					}) : null
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "rise min-w-0 flex-1 px-4 py-4 pb-nav",
				children
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			className: "fixed inset-x-0 bottom-0 z-30 border-t border-border bg-background pb-[env(safe-area-inset-bottom)]",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto grid max-w-lg grid-cols-4",
				children: NAV.map((item) => {
					const active = navActive(path, item.to);
					const Icon = item.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: item.to,
						"aria-current": active ? "page" : void 0,
						className: cn("flex min-h-14 flex-col items-center justify-center gap-1 text-xs font-medium", active ? "text-foreground" : "text-muted-foreground"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
							className: "size-5",
							strokeWidth: 1.75
						}), item.label]
					}, item.to);
				})
			})
		})]
	});
}
var BREEDS = [
	"أولاد جلال",
	"رمبي",
	"بربرية",
	"الدمان",
	"حمراء",
	"سيدون",
	"تازكزاوت",
	"هجينة"
];
var PENS = [
	"حظيرة 1",
	"حظيرة 2",
	"العزل",
	"المرعى"
];
var HEALTH_PRESETS = [
	"تطعيم الحمى القلاعية",
	"طارد ديدان",
	"علاج الجرب",
	"مضاد حيوي",
	"فيتامينات",
	"فحص الحوافر",
	"فحص بيطري"
];
var HEALTH_KIND_LABEL = {
	vaccine: "تطعيم",
	treatment: "علاج",
	symptom: "عرض",
	check: "فحص"
};
var FILTERS = [
	{
		id: "all",
		label: "الكل"
	},
	{
		id: "ram",
		label: "كباش"
	},
	{
		id: "ewe",
		label: "نعاج"
	},
	{
		id: "lamb",
		label: "صغار"
	},
	{
		id: "pregnant",
		label: "حوامل"
	},
	{
		id: "sick",
		label: "مرضى"
	},
	{
		id: "archive",
		label: "الأرشيف"
	}
];
var nf = new Intl.NumberFormat("ar-DZ", {
	numberingSystem: "latn",
	maximumFractionDigits: 1
});
function formatInt(n) {
	return nf.format(n);
}
function formatKg(n) {
	if (n == null) return "—";
	return `${nf.format(n)} كغ`;
}
function todayIso() {
	const n = /* @__PURE__ */ new Date();
	return `${n.getFullYear()}-${String(n.getMonth() + 1).padStart(2, "0")}-${String(n.getDate()).padStart(2, "0")}`;
}
function parseDay(iso) {
	const [y, m, d] = iso.split("-").map(Number);
	return Date.UTC(y || 1970, (m || 1) - 1, d || 1);
}
function formatDay(utc) {
	const dt = new Date(utc);
	return `${dt.getUTCFullYear()}-${String(dt.getUTCMonth() + 1).padStart(2, "0")}-${String(dt.getUTCDate()).padStart(2, "0")}`;
}
function addDays(iso, days) {
	return formatDay(parseDay(iso) + days * 864e5);
}
function daysFromToday(iso) {
	if (!iso) return 0;
	return Math.round((parseDay(iso) - parseDay(todayIso())) / 864e5);
}
function formatDate(iso) {
	if (!iso) return "—";
	const [y, m, d] = iso.split("-").map(Number);
	if (!y || !m || !d) return iso;
	return new Intl.DateTimeFormat("ar-DZ", {
		day: "numeric",
		month: "short",
		year: "numeric",
		numberingSystem: "latn"
	}).format(new Date(y, m - 1, d));
}
function daysLabel(n) {
	if (n === 0) return "اليوم";
	if (n === 1) return "غداً";
	if (n > 1) return `بعد ${formatInt(n)} يوم`;
	if (n === -1) return "متأخر يوم";
	return `متأخر ${formatInt(Math.abs(n))} يوم`;
}
function ageDays(birth) {
	if (!birth) return null;
	return -daysFromToday(birth);
}
function ageLabel(birth) {
	const days = ageDays(birth);
	if (days == null) return "العمر غير معروف";
	if (days < 1) return "حديث الولادة";
	if (days < 60) return `${formatInt(days)} يوم`;
	const months = Math.floor(days / 30.4375);
	if (months < 24) return `${formatInt(months)} شهر`;
	const years = Math.floor(months / 12);
	const rem = months % 12;
	if (rem === 0) return `${formatInt(years)} سنة`;
	return `${formatInt(years)} سنة و ${formatInt(rem)} شهر`;
}
function isLamb(sheep) {
	const days = ageDays(sheep.birthDate);
	if (days == null) return false;
	return days >= 0 && days < 365;
}
function inHerd(sheep) {
	return sheep.status === "active" || sheep.status === "sick";
}
function isPregnant(sheepId, breeding) {
	return breeding.some((b) => b.eweId === sheepId && b.result === "pending");
}
function sexLabel(sex, lamb = false) {
	if (lamb) return sex === "ram" ? "خروف" : "نعجة صغيرة";
	return sex === "ram" ? "كبش" : "نعجة";
}
function statusLabel(status) {
	if (status === "sick") return "مريض";
	if (status === "sold") return "مبيع";
	if (status === "dead") return "نافق";
	return "سليم";
}
function matchesFilter(sheep, breeding, filter) {
	if (filter === "archive") return !inHerd(sheep);
	if (!inHerd(sheep)) return false;
	if (filter === "all") return true;
	if (filter === "ram") return sheep.sex === "ram" && !isLamb(sheep);
	if (filter === "ewe") return sheep.sex === "ewe" && !isLamb(sheep);
	if (filter === "lamb") return isLamb(sheep);
	if (filter === "pregnant") return isPregnant(sheep.id, breeding);
	if (filter === "sick") return sheep.status === "sick";
	return true;
}
function compareSheep(a, b) {
	const na = Number.parseInt(a.tag, 10);
	const nb = Number.parseInt(b.tag, 10);
	const aNum = String(na) === a.tag.trim() && Number.isFinite(na);
	const bNum = String(nb) === b.tag.trim() && Number.isFinite(nb);
	if (aNum && bNum && na !== nb) return na - nb;
	if (aNum !== bNum) return aNum ? -1 : 1;
	return a.tag.localeCompare(b.tag, "ar");
}
function herdStats(sheep, breeding) {
	const herd = sheep.filter(inHerd);
	const weights = herd.map((s) => s.weightKg).filter((n) => n != null);
	const avg = weights.length ? Math.round(weights.reduce((a, b) => a + b, 0) / weights.length * 10) / 10 : null;
	return {
		total: herd.length,
		rams: herd.filter((s) => s.sex === "ram" && !isLamb(s)).length,
		ewes: herd.filter((s) => s.sex === "ewe" && !isLamb(s)).length,
		lambs: herd.filter(isLamb).length,
		pregnant: herd.filter((s) => isPregnant(s.id, breeding)).length,
		sick: herd.filter((s) => s.status === "sick").length,
		archive: sheep.length - herd.length,
		avg
	};
}
function sheepName(sheep, fallback = "القطيع كله") {
	if (!sheep) return fallback;
	return sheep.name ? `${sheep.tag} · ${sheep.name}` : sheep.tag;
}
function suggestTags(sheep, count) {
	let max = 0;
	for (const s of sheep) {
		const n = Number.parseInt(s.tag, 10);
		if (Number.isFinite(n) && String(n) === s.tag.trim()) max = Math.max(max, n);
	}
	return Array.from({ length: count }, (_, i) => String(max + 1 + i));
}
function newId() {
	return crypto.randomUUID();
}
function clampGestation(value) {
	const n = typeof value === "number" ? value : Number(value);
	if (!Number.isFinite(n)) return 147;
	return Math.min(165, Math.max(140, Math.round(n)));
}
function asString(value) {
	return typeof value === "string" ? value : "";
}
function parseSheep(value) {
	if (!value || typeof value !== "object") return null;
	const o = value;
	if (typeof o.id !== "string" || typeof o.tag !== "string" || !o.tag.trim()) return null;
	if (o.sex !== "ram" && o.sex !== "ewe") return null;
	const status = o.status === "sick" || o.status === "sold" || o.status === "dead" ? o.status : "active";
	const weight = typeof o.weightKg === "number" && o.weightKg > 0 ? o.weightKg : null;
	return {
		id: o.id,
		tag: o.tag.trim(),
		name: asString(o.name).trim(),
		sex: o.sex,
		birthDate: asString(o.birthDate),
		breed: asString(o.breed).trim(),
		weightKg: weight,
		status,
		pen: asString(o.pen).trim(),
		notes: asString(o.notes),
		damId: typeof o.damId === "string" ? o.damId : null,
		sireId: typeof o.sireId === "string" ? o.sireId : null,
		createdAt: asString(o.createdAt) || (/* @__PURE__ */ new Date()).toISOString()
	};
}
function parseHealth(value) {
	if (!value || typeof value !== "object") return null;
	const o = value;
	if (typeof o.id !== "string" || typeof o.title !== "string" || !o.title.trim()) return null;
	const kind = o.kind === "vaccine" || o.kind === "treatment" || o.kind === "symptom" || o.kind === "check" ? o.kind : "treatment";
	return {
		id: o.id,
		sheepId: typeof o.sheepId === "string" ? o.sheepId : null,
		date: asString(o.date),
		kind,
		title: o.title.trim(),
		notes: asString(o.notes)
	};
}
function parseBreeding(value) {
	if (!value || typeof value !== "object") return null;
	const o = value;
	if (typeof o.id !== "string" || typeof o.eweId !== "string") return null;
	const result = o.result === "lambed" || o.result === "lost" || o.result === "pending" ? o.result : "pending";
	return {
		id: o.id,
		eweId: o.eweId,
		ramId: typeof o.ramId === "string" ? o.ramId : null,
		matingDate: asString(o.matingDate),
		expectedDate: asString(o.expectedDate),
		result,
		lambCount: typeof o.lambCount === "number" ? o.lambCount : null,
		closedDate: typeof o.closedDate === "string" ? o.closedDate : null,
		notes: asString(o.notes)
	};
}
function parseWeight(value) {
	if (!value || typeof value !== "object") return null;
	const o = value;
	if (typeof o.id !== "string" || typeof o.sheepId !== "string") return null;
	if (typeof o.kg !== "number" || !(o.kg > 0)) return null;
	return {
		id: o.id,
		sheepId: o.sheepId,
		date: asString(o.date),
		kg: o.kg
	};
}
function parseBackup(raw) {
	if (!raw || typeof raw !== "object") return null;
	const o = raw;
	if (o.version !== 1) return null;
	if (!Array.isArray(o.sheep) || !Array.isArray(o.health) || !Array.isArray(o.breeding) || !Array.isArray(o.weights)) return null;
	return {
		version: 1,
		herdName: typeof o.herdName === "string" && o.herdName.trim() ? o.herdName.trim().slice(0, 40) : "قطيعي",
		gestationDays: clampGestation(o.gestationDays),
		sheep: o.sheep.map(parseSheep).filter((x) => x != null),
		health: o.health.map(parseHealth).filter((x) => x != null),
		breeding: o.breeding.map(parseBreeding).filter((x) => x != null),
		weights: o.weights.map(parseWeight).filter((x) => x != null)
	};
}
function buildSample(today = todayIso()) {
	const years = (n) => addDays(today, -Math.round(n * 365.25));
	const sheep = [
		{
			id: "sample-ram-12",
			tag: "12",
			name: "الأصهب",
			sex: "ram",
			birthDate: years(3.2),
			breed: "أولاد جلال",
			weightKg: 76,
			status: "active",
			pen: "حظيرة 1",
			notes: "",
			damId: null,
			sireId: null,
			createdAt: (/* @__PURE__ */ new Date()).toISOString()
		},
		{
			id: "sample-ewe-21",
			tag: "21",
			name: "",
			sex: "ewe",
			birthDate: years(4),
			breed: "أولاد جلال",
			weightKg: 51,
			status: "active",
			pen: "حظيرة 1",
			notes: "",
			damId: null,
			sireId: null,
			createdAt: (/* @__PURE__ */ new Date()).toISOString()
		},
		{
			id: "sample-ewe-22",
			tag: "22",
			name: "الغيداء",
			sex: "ewe",
			birthDate: years(2.4),
			breed: "أولاد جلال",
			weightKg: 48,
			status: "active",
			pen: "حظيرة 1",
			notes: "",
			damId: null,
			sireId: "sample-ram-12",
			createdAt: (/* @__PURE__ */ new Date()).toISOString()
		},
		{
			id: "sample-ewe-23",
			tag: "23",
			name: "",
			sex: "ewe",
			birthDate: years(3),
			breed: "أولاد جلال",
			weightKg: 46,
			status: "sick",
			pen: "العزل",
			notes: "حكة في الخاصرة. معزولة عن القطيع.",
			damId: null,
			sireId: null,
			createdAt: (/* @__PURE__ */ new Date()).toISOString()
		},
		{
			id: "sample-lamb-44",
			tag: "44",
			name: "",
			sex: "ram",
			birthDate: addDays(today, -120),
			breed: "أولاد جلال",
			weightKg: 28,
			status: "active",
			pen: "حظيرة 1",
			notes: "",
			damId: "sample-ewe-21",
			sireId: "sample-ram-12",
			createdAt: (/* @__PURE__ */ new Date()).toISOString()
		},
		{
			id: "sample-lamb-45",
			tag: "45",
			name: "",
			sex: "ewe",
			birthDate: addDays(today, -118),
			breed: "أولاد جلال",
			weightKg: 26,
			status: "active",
			pen: "حظيرة 1",
			notes: "",
			damId: "sample-ewe-21",
			sireId: "sample-ram-12",
			createdAt: (/* @__PURE__ */ new Date()).toISOString()
		},
		{
			id: "sample-sold-7",
			tag: "7",
			name: "",
			sex: "ram",
			birthDate: years(5),
			breed: "رمبي",
			weightKg: 71,
			status: "sold",
			pen: "",
			notes: "بيع في السوق.",
			damId: null,
			sireId: null,
			createdAt: (/* @__PURE__ */ new Date()).toISOString()
		}
	];
	const mating = addDays(today, -100);
	return {
		sheep,
		breeding: [{
			id: "sample-breed-22",
			eweId: "sample-ewe-22",
			ramId: "sample-ram-12",
			matingDate: mating,
			expectedDate: addDays(mating, 147),
			result: "pending",
			lambCount: null,
			closedDate: null,
			notes: ""
		}],
		health: [{
			id: "sample-health-fmd",
			sheepId: null,
			date: addDays(today, -20),
			kind: "vaccine",
			title: "تطعيم الحمى القلاعية",
			notes: "جرعة القطيع كله."
		}, {
			id: "sample-health-23",
			sheepId: "sample-ewe-23",
			date: addDays(today, -2),
			kind: "symptom",
			title: "علاج الجرب",
			notes: "عزل ومراقبة."
		}],
		weights: [
			{
				id: "sample-w-12a",
				sheepId: "sample-ram-12",
				date: addDays(today, -40),
				kg: 74
			},
			{
				id: "sample-w-12b",
				sheepId: "sample-ram-12",
				date: today,
				kg: 76
			},
			{
				id: "sample-w-21",
				sheepId: "sample-ewe-21",
				date: addDays(today, -15),
				kg: 51
			}
		]
	};
}
var fallbackStorage = {
	getItem: (_name) => null,
	setItem: (_name, _value) => {},
	removeItem: (_name) => {}
};
function latestWeight(weights, sheepId) {
	const list = weights.filter((w) => w.sheepId === sheepId);
	if (!list.length) return void 0;
	return list.reduce((best, w) => w.date >= best.date ? w : best);
}
var useFlock = create()(persist((set, get) => ({
	herdName: "قطيعي",
	gestationDays: 147,
	sheep: [],
	health: [],
	breeding: [],
	weights: [],
	setHerdName: (name) => set({ herdName: name.slice(0, 40) }),
	setGestationDays: (days) => set({ gestationDays: clampGestation(days) }),
	saveSheep: (input, id) => {
		const tag = input.tag.trim();
		if (!tag) return { error: "رقم الحلقة مطلوب" };
		if (tag.length > 24) return { error: "رقم الحلقة طويل" };
		if (get().sheep.some((s) => s.tag.trim() === tag && s.id !== id)) return { error: "رقم الحلقة مستعمل لرأس آخر" };
		if (input.birthDate && input.birthDate > todayIso()) return { error: "تاريخ الميلاد لا يكون في المستقبل" };
		if (input.weightKg != null && !(input.weightKg > 0 && input.weightKg <= 250)) return { error: "الوزن غير واقعي" };
		const clean = {
			...input,
			tag,
			name: input.name.trim().slice(0, 40),
			breed: input.breed.trim().slice(0, 40),
			pen: input.pen.trim().slice(0, 40),
			notes: input.notes.trim().slice(0, 500),
			damId: input.damId || null,
			sireId: input.sireId || null
		};
		const prev = id ? get().sheep.find((s) => s.id === id) : void 0;
		const nid = id ?? newId();
		if (id && !prev) return { error: "الرأس غير موجود" };
		set((s) => ({ sheep: id ? s.sheep.map((x) => x.id === id ? {
			...x,
			...clean
		} : x) : [...s.sheep, {
			...clean,
			id: nid,
			createdAt: (/* @__PURE__ */ new Date()).toISOString()
		}] }));
		if (clean.weightKg != null && clean.weightKg !== prev?.weightKg) get().addWeight(nid, todayIso(), clean.weightKg);
		return { id: nid };
	},
	setStatus: (id, status) => set((s) => ({ sheep: s.sheep.map((x) => x.id === id ? {
		...x,
		status
	} : x) })),
	removeSheep: (id) => set((s) => ({
		sheep: s.sheep.filter((x) => x.id !== id).map((x) => ({
			...x,
			damId: x.damId === id ? null : x.damId,
			sireId: x.sireId === id ? null : x.sireId
		})),
		health: s.health.filter((h) => h.sheepId !== id),
		weights: s.weights.filter((w) => w.sheepId !== id),
		breeding: s.breeding.filter((b) => b.eweId !== id).map((b) => b.ramId === id ? {
			...b,
			ramId: null
		} : b)
	})),
	addHealth: (input) => {
		const title = input.title.trim();
		if (!title) return { error: "اكتب ماذا تم" };
		if (!input.date) return { error: "التاريخ مطلوب" };
		set((s) => ({
			health: [...s.health, {
				id: newId(),
				sheepId: input.sheepId,
				date: input.date,
				kind: input.kind,
				title: title.slice(0, 80),
				notes: input.notes.trim().slice(0, 500)
			}],
			sheep: input.markSick && input.sheepId ? s.sheep.map((sh) => sh.id === input.sheepId && inHerd(sh) ? {
				...sh,
				status: "sick"
			} : sh) : s.sheep
		}));
		return { ok: true };
	},
	removeHealth: (id) => set((s) => ({ health: s.health.filter((h) => h.id !== id) })),
	addBreeding: (input) => {
		const ewe = get().sheep.find((s) => s.id === input.eweId);
		if (!ewe || ewe.sex !== "ewe") return { error: "اختر نعجة من القطيع" };
		if (!inHerd(ewe)) return { error: "النعجة خارج القطيع" };
		if (get().breeding.some((b) => b.eweId === ewe.id && b.result === "pending")) return { error: "لهذه النعجة تلقيح قائم" };
		if (!input.matingDate) return { error: "تاريخ التلقيح مطلوب" };
		if (input.expectedDate && input.expectedDate < input.matingDate) return { error: "موعد الولادة قبل تاريخ التلقيح" };
		set((s) => ({ breeding: [...s.breeding, {
			id: newId(),
			eweId: input.eweId,
			ramId: input.ramId,
			matingDate: input.matingDate,
			expectedDate: input.expectedDate || input.matingDate,
			result: "pending",
			lambCount: null,
			closedDate: null,
			notes: input.notes.trim().slice(0, 500)
		}] }));
		return { ok: true };
	},
	markLost: (id, date) => set((s) => ({ breeding: s.breeding.map((b) => b.id === id ? {
		...b,
		result: "lost",
		closedDate: date,
		lambCount: 0
	} : b) })),
	removeBreeding: (id) => set((s) => ({ breeding: s.breeding.filter((b) => b.id !== id) })),
	recordLambing: (breedingId, date, lambs) => {
		const breeding = get().breeding.find((b) => b.id === breedingId);
		if (!breeding || breeding.result !== "pending") return { error: "لا يوجد تلقيح قائم" };
		if (!date) return { error: "تاريخ الولادة مطلوب" };
		if (date < breeding.matingDate) return { error: "الولادة قبل تاريخ التلقيح" };
		const ewe = get().sheep.find((s) => s.id === breeding.eweId);
		const created = [];
		const seen = new Set(get().sheep.map((s) => s.tag.trim()));
		for (const lamb of lambs) {
			const tag = lamb.tag.trim();
			if (!tag) return { error: "لكل مولود رقم حلقة" };
			if (seen.has(tag)) return { error: `الحلقة ${tag} مستعملة` };
			seen.add(tag);
			created.push({
				id: newId(),
				tag,
				name: "",
				sex: lamb.sex,
				birthDate: date,
				breed: ewe?.breed ?? "",
				weightKg: null,
				status: "active",
				pen: ewe?.pen ?? "",
				notes: "",
				damId: breeding.eweId,
				sireId: breeding.ramId,
				createdAt: (/* @__PURE__ */ new Date()).toISOString()
			});
		}
		if (!created.length) return { error: "أضف مولوداً واحداً على الأقل" };
		set((s) => ({
			sheep: [...s.sheep, ...created],
			breeding: s.breeding.map((b) => b.id === breedingId ? {
				...b,
				result: "lambed",
				lambCount: created.length,
				closedDate: date
			} : b)
		}));
		return { ok: true };
	},
	addWeight: (sheepId, date, kg) => {
		if (!(kg > 0 && kg <= 250)) return { error: "الوزن غير واقعي" };
		if (!date) return { error: "التاريخ مطلوب" };
		if (!get().sheep.some((s) => s.id === sheepId)) return { error: "الرأس غير موجود" };
		set((s) => {
			const weights = [...s.weights, {
				id: newId(),
				sheepId,
				date,
				kg
			}];
			const latest = latestWeight(weights, sheepId);
			return {
				weights,
				sheep: s.sheep.map((sh) => sh.id === sheepId ? {
					...sh,
					weightKg: latest ? latest.kg : sh.weightKg
				} : sh)
			};
		});
		return { ok: true };
	},
	removeWeight: (id) => set((s) => {
		const target = s.weights.find((w) => w.id === id);
		const weights = s.weights.filter((w) => w.id !== id);
		if (!target) return { weights };
		const latest = latestWeight(weights, target.sheepId);
		return {
			weights,
			sheep: s.sheep.map((sh) => sh.id === target.sheepId ? {
				...sh,
				weightKg: latest ? latest.kg : null
			} : sh)
		};
	}),
	loadSample: () => {
		const sample = buildSample();
		set({
			sheep: sample.sheep,
			health: sample.health,
			breeding: sample.breeding,
			weights: sample.weights
		});
	},
	replaceAll: (data) => set({
		herdName: data.herdName,
		gestationDays: data.gestationDays,
		sheep: data.sheep,
		health: data.health,
		breeding: data.breeding,
		weights: data.weights
	}),
	clearAll: () => set({
		herdName: "قطيعي",
		gestationDays: 147,
		sheep: [],
		health: [],
		breeding: [],
		weights: []
	})
}), {
	name: "qatiee.flock.v1",
	version: 1,
	storage: createJSONStorage(() => typeof window === "undefined" ? fallbackStorage : localStorage),
	partialize: (s) => ({
		herdName: s.herdName,
		gestationDays: s.gestationDays,
		sheep: s.sheep,
		health: s.health,
		breeding: s.breeding,
		weights: s.weights
	})
}));
function useHydrated() {
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const persistApi = useFlock.persist;
		const unsub = persistApi.onFinishHydration(() => setHydrated(true));
		if (persistApi.hasHydrated()) setHydrated(true);
		return unsub;
	}, []);
	return hydrated;
}
//#endregion
export { sexLabel as C, todayIso as D, suggestTags as E, useFlock as O, parseBackup as S, statusLabel as T, herdStats as _, HEALTH_PRESETS as a, isPregnant as b, ageLabel as c, compareSheep as d, daysFromToday as f, formatKg as g, formatInt as h, HEALTH_KIND_LABEL as i, useHydrated as k, clampGestation as l, formatDate as m, BREEDS as n, PENS as o, daysLabel as p, FILTERS as r, addDays as s, AppShell as t, cn as u, inHerd as v, sheepName as w, matchesFilter as x, isLamb as y };
