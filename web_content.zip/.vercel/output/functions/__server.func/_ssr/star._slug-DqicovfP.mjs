import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as Link, v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { d as ImagePlus, o as Star, p as ArrowLeft, r as Upload } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as useStar, c as useVault, d as Button, f as cn, n as Route, o as useStarMedia } from "./router-CboP5aV-.mjs";
import { t as AppShell } from "./app-shell-Dk04OjoX.mjs";
import { n as MediaViewer, t as MediaGrid } from "./media-viewer-DrIWtDkp.mjs";
import { t as StarPhoto } from "./star-photo-CYdE_HDR.mjs";
import { i as Trigger, n as List, r as Root2, t as Content } from "../_libs/radix-ui__react-tabs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/star._slug-DqicovfP.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Tabs = Root2;
function TabsList({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, {
		className: cn("inline-flex h-11 items-center gap-1 rounded-lg bg-secondary p-1 text-muted-foreground", className),
		...props
	});
}
function TabsTrigger({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trigger, {
		className: cn("inline-flex h-9 items-center justify-center rounded-md px-3 text-sm font-medium", "transition-colors duration-150", "data-[state=active]:bg-card data-[state=active]:text-foreground", "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring", className),
		...props
	});
}
function TabsContent({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content, {
		className: cn("mt-4 outline-none", className),
		...props
	});
}
function StarPage() {
	const { slug } = Route.useParams();
	const navigate = useNavigate();
	const ready = useVault((s) => s.ready);
	const star = useStar(slug);
	const media = useStarMedia(slug);
	const importFiles = useVault((s) => s.importFiles);
	const setStarPhoto = useVault((s) => s.setStarPhoto);
	const toggleFavorite = useVault((s) => s.toggleFavorite);
	const removeMedia = useVault((s) => s.removeMedia);
	const removeUserStar = useVault((s) => s.removeUserStar);
	const photoRef = (0, import_react.useRef)(null);
	const mediaRef = (0, import_react.useRef)(null);
	const [tab, setTab] = (0, import_react.useState)("all");
	const [open, setOpen] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const items = (0, import_react.useMemo)(() => {
		if (tab === "all") return media;
		return media.filter((m) => m.kind === tab);
	}, [media, tab]);
	if (!star) {
		if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto max-w-lg px-6 py-24 text-center text-muted-foreground",
			children: "Loading"
		}) });
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-lg px-6 py-24 text-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-3xl",
				children: "Not in the roster"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				className: "mt-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					children: "Back"
				})
			})]
		}) });
	}
	const profile = star;
	async function addFiles(files) {
		if (!files?.length) return;
		setBusy(true);
		try {
			const result = await importFiles([...files], slug);
			if (result.filed) toast.success(`${result.filed} added to ${profile.name}`);
			if (result.failed) toast.error("Some files could not be saved");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-5xl px-4 pb-20 pt-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-6 flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "icon",
					asChild: true,
					"aria-label": "Back",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" })
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Roster"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-6 md:grid-cols-[16rem_1fr] md:items-end",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => photoRef.current?.click(),
					className: "relative mx-auto aspect-portrait w-56 overflow-hidden rounded-xl bg-card shadow-[var(--shadow-border)] md:mx-0 md:w-full",
					"aria-label": "Change profile photo",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StarPhoto, {
						star: profile,
						sizes: "256px"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "absolute inset-x-0 bottom-0 flex items-center justify-center gap-1 bg-ink/70 py-2 text-xs text-paper",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "size-3.5" }), "Change photo"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-4xl font-medium tracking-tight sm:text-5xl",
						children: profile.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm tabular-nums text-muted-foreground",
						children: [
							profile.counts.video,
							" videos · ",
							profile.counts.photo,
							" photos · ",
							profile.counts.gif,
							" GIFs"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 flex flex-wrap gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								onClick: () => mediaRef.current?.click(),
								disabled: busy,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-4" }), "Add media"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: profile.favorite ? "default" : "outline",
								onClick: () => void toggleFavorite(profile.slug),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: `size-4 ${profile.favorite ? "fill-current" : ""}` }), profile.favorite ? "Saved" : "Save"]
							}),
							profile.addedByUser ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								className: "text-muted-foreground",
								onClick: async () => {
									await removeUserStar(profile.slug);
									navigate({ to: "/" });
								},
								children: "Remove profile"
							}) : null
						]
					})
				] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: photoRef,
				type: "file",
				accept: "image/*",
				className: "sr-only",
				onChange: (e) => {
					const file = e.target.files?.[0];
					if (file) setStarPhoto(profile.slug, file);
					e.currentTarget.value = "";
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: mediaRef,
				type: "file",
				accept: "video/*,image/*,.gif,.webm,.mp4,.mov,.mkv,.m4v",
				multiple: true,
				className: "sr-only",
				onChange: (e) => {
					addFiles(e.target.files);
					e.currentTarget.value = "";
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
				value: tab,
				onValueChange: setTab,
				className: "mt-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
						value: "all",
						children: "All"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
						value: "video",
						children: "Videos"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
						value: "photo",
						children: "Photos"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
						value: "gif",
						children: "GIFs"
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
					value: tab,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MediaGrid, {
						items,
						onOpen: setOpen,
						onDelete: (item) => void removeMedia(item.id)
					})
				})]
			})
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MediaViewer, {
		item: open,
		onClose: () => setOpen(null)
	})] });
}
//#endregion
export { StarPage as component };
