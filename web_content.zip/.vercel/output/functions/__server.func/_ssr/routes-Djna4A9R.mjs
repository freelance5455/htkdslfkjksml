import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as useProjects, o as useStory, s as visibleProjects } from "./use-projects-B0rAf6PZ.mjs";
import { t as format } from "../_libs/date-fns.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Djna4A9R.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const ready = useProjects();
	const projects = useStory((state) => state.projects);
	const recent = visibleProjects(projects).slice(0, 4);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-3xl gap-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-widest text-muted uppercase",
						children: "Product storyboards"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-4xl leading-tight font-medium tracking-tight sm:text-5xl",
						children: "Foto produk yang sama, scene yang berbeda."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-xl text-base text-muted",
						children: "Upload beberapa foto satu produk. Susun cerita, lalu salin prompt gambar dan prompt video tanpa mengubah bentuk produk."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/create",
						className: "inline-flex min-h-14 w-full items-center justify-center rounded-md bg-accent px-4 text-base font-medium text-accent-fg sm:w-fit",
						children: "Create storyboard"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [
					[
						"01",
						"Upload product",
						"Satu sampai sepuluh foto. Semuanya satu produk."
					],
					[
						"02",
						"Product & story",
						"Kategori, campaign, gaya foto, dan jumlah scene."
					],
					[
						"03",
						"Generate storyboard",
						"Setiap scene menjaga bentuk, warna, logo, dan konstruksi."
					],
					[
						"04",
						"Copy & download",
						"Prompt gambar, prompt video, atau unduh fotonya."
					]
				].map(([n, title, body]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-xl border border-line bg-surface p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium text-muted tabular-nums",
							children: n
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-2 font-medium",
							children: title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: body
						})
					]
				}, n))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl font-medium tracking-tight",
						children: "My storyboards"
					}),
					!ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Memuat…"
					}) : null,
					ready && recent.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Belum ada storyboard. Mulai dari foto produk."
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "grid gap-2",
						children: recent.map((project) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/storyboards/$id",
							params: { id: project.id },
							className: "flex items-center gap-3 rounded-xl border border-line bg-surface p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "frame-1-1 block w-16 shrink-0 overflow-hidden rounded-sm bg-bg",
								children: project.refs[0] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: project.refs[0].dataUrl,
									alt: "",
									className: "h-full w-full object-contain"
								}) : null
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "grid gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: project.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-sm text-muted",
									children: [
										project.scenes.length || project.sceneCount,
										" scene · ",
										format(project.updatedAt, "d MMM yyyy")
									]
								})]
							})]
						}) }, project.id))
					})
				]
			})
		]
	});
}
//#endregion
export { Home as component };
