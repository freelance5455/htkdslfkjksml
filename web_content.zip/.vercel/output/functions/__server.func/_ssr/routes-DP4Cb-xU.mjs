import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as DialogOverlay, c as DialogTrigger, i as DialogDescription, n as DialogClose, o as DialogPortal, r as DialogContent, s as DialogTitle, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { A as CloudSnow, B as Bookmark, C as Heart, D as Coffee, E as Compass, F as Clock, I as ChevronUp, L as ChevronDown, M as CloudLightning, N as CloudFog, O as Cloud, P as CloudDrizzle, R as Car, S as House, T as Globe, _ as Minus, a as Sun, b as LocateFixed, c as SlidersHorizontal, d as Plus, f as Play, g as Moon, h as Music2, i as Thermometer, j as CloudRain, k as CloudSun, l as Search, m as Navigation, n as X, o as SunMedium, p as Pause, s as Star, t as Zap, u as Radio, v as Mic, w as Headphones, x as Link2, y as Map, z as Calendar } from "../_libs/lucide-react.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DP4Cb-xU.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function asNumber(value) {
	const number = typeof value === "number" ? value : Number(value);
	return Number.isFinite(number) ? number : null;
}
function clampQuery(value) {
	if (typeof value !== "string") throw new Error("Consulta inválida");
	const query = value.trim().slice(0, 100);
	if (query.length < 2) throw new Error("Escribe al menos 2 caracteres");
	return query;
}
function coord(value, min, max) {
	const number = asNumber(value);
	if (number == null || number < min || number > max) throw new Error("Coordenadas inválidas");
	return number;
}
var searchPlaces = createServerFn({ method: "GET" }).validator((data) => ({ q: clampQuery(data?.q) })).handler(createSsrRpc("6399acd62efc069988915670a8f3ca832658085ec5ba1a1479798927de2fe001"));
var reversePlace = createServerFn({ method: "GET" }).validator((data) => ({
	lat: coord(data?.lat, -90, 90),
	lon: coord(data?.lon, -180, 180)
})).handler(createSsrRpc("c2eec810bc64097638182a3fc43fb67692b29ad33d6eaf3445d2f2bb37c557ed"));
var routeDrive = createServerFn({ method: "GET" }).validator((data) => ({
	fromLat: coord(data?.fromLat, -90, 90),
	fromLon: coord(data?.fromLon, -180, 180),
	toLat: coord(data?.toLat, -90, 90),
	toLon: coord(data?.toLon, -180, 180)
})).handler(createSsrRpc("0106403ebabf39fa4c382f9f718e68065eb5053ecec5c4238c85495977e17b0f"));
var searchTracks = createServerFn({ method: "GET" }).validator((data) => ({ q: clampQuery(data?.q) })).handler(createSsrRpc("0ad72f5bddc25d137ded1e9e691f78a500bca26251501e2d6524f75a21895c67"));
var FALLBACK = {
	lat: -34.6037,
	lon: -58.3816,
	label: "Buenos Aires"
};
var PlaceContext = (0, import_react.createContext)(null);
function hourLabel(stamp) {
	return stamp.slice(11, 16);
}
async function readForecast(lat, lon) {
	const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m,relative_humidity_2m,is_day&hourly=temperature_2m,weather_code,precipitation_probability&daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset&timezone=auto&forecast_days=7`;
	const response = await fetch(url);
	if (!response.ok) throw new Error("clima");
	return await response.json();
}
function PlaceProvider({ children }) {
	const [status, setStatus] = (0, import_react.useState)("loading");
	const [label, setLabel] = (0, import_react.useState)("Ubicando…");
	const [lat, setLat] = (0, import_react.useState)(FALLBACK.lat);
	const [lon, setLon] = (0, import_react.useState)(FALLBACK.lon);
	const [temp, setTemp] = (0, import_react.useState)(null);
	const [feels, setFeels] = (0, import_react.useState)(null);
	const [code, setCode] = (0, import_react.useState)(null);
	const [wind, setWind] = (0, import_react.useState)(null);
	const [humidity, setHumidity] = (0, import_react.useState)(null);
	const [isDay, setIsDay] = (0, import_react.useState)(true);
	const [hours, setHours] = (0, import_react.useState)([]);
	const [days, setDays] = (0, import_react.useState)([]);
	const [sunrise, setSunrise] = (0, import_react.useState)("");
	const [sunset, setSunset] = (0, import_react.useState)("");
	const precise = (0, import_react.useRef)(false);
	const coords = (0, import_react.useRef)({
		lat: FALLBACK.lat,
		lon: FALLBACK.lon
	});
	const applyForecast = (0, import_react.useCallback)(async (nextLat, nextLon) => {
		try {
			const data = await readForecast(nextLat, nextLon);
			const current = data.current;
			const hourly = data.hourly;
			const daily = data.daily;
			const times = hourly?.time ?? [];
			const nowStamp = current?.time ?? "";
			let start = times.findIndex((stamp) => stamp >= nowStamp);
			if (start < 0) start = 0;
			const nextHours = [];
			for (let index = start; index < Math.min(times.length, start + 12); index += 1) {
				const stamp = times[index];
				if (!stamp) continue;
				nextHours.push({
					time: hourLabel(stamp),
					temp: hourly?.temperature_2m?.[index] ?? 0,
					code: hourly?.weather_code?.[index] ?? 0,
					pop: hourly?.precipitation_probability?.[index] ?? 0
				});
			}
			const nextDays = (daily?.time ?? []).slice(0, 7).map((date, index) => ({
				date,
				min: daily?.temperature_2m_min?.[index] ?? 0,
				max: daily?.temperature_2m_max?.[index] ?? 0,
				code: daily?.weather_code?.[index] ?? 0
			}));
			setTemp(current?.temperature_2m ?? null);
			setFeels(current?.apparent_temperature ?? null);
			setCode(current?.weather_code ?? null);
			setWind(current?.wind_speed_10m ?? null);
			setHumidity(current?.relative_humidity_2m ?? null);
			setIsDay(current?.is_day !== 0);
			setHours(nextHours);
			setDays(nextDays);
			setSunrise(hourLabel(daily?.sunrise?.[0] ?? ""));
			setSunset(hourLabel(daily?.sunset?.[0] ?? ""));
			setStatus("ready");
		} catch {
			setStatus((current) => current === "ready" ? "ready" : "error");
		}
	}, []);
	const adopt = (0, import_react.useCallback)((nextLat, nextLon, nextLabel, isPrecise) => {
		if (!isPrecise && precise.current) return;
		if (isPrecise) precise.current = true;
		coords.current = {
			lat: nextLat,
			lon: nextLon
		};
		setLat(nextLat);
		setLon(nextLon);
		if (nextLabel) setLabel(nextLabel);
		applyForecast(nextLat, nextLon);
	}, [applyForecast]);
	(0, import_react.useEffect)(() => {
		let cancel = false;
		const fallbackTimer = window.setTimeout(() => {
			if (!cancel && !precise.current) adopt(FALLBACK.lat, FALLBACK.lon, FALLBACK.label, false);
		}, 2800);
		fetch("https://ipwho.is/").then((response) => response.json()).then((ip) => {
			if (cancel || !ip.success || typeof ip.latitude !== "number" || typeof ip.longitude !== "number") return;
			const city = [ip.city, ip.country_code].filter(Boolean).join(", ");
			adopt(ip.latitude, ip.longitude, city || "Tu zona", false);
		}).catch(() => void 0);
		if (navigator.geolocation) navigator.geolocation.getCurrentPosition((position) => {
			if (cancel) return;
			const nextLat = position.coords.latitude;
			const nextLon = position.coords.longitude;
			adopt(nextLat, nextLon, null, true);
			reversePlace({ data: {
				lat: nextLat,
				lon: nextLon
			} }).then((result) => {
				if (!cancel && result.ok) setLabel(result.label);
			});
		}, () => void 0, {
			enableHighAccuracy: false,
			timeout: 8e3,
			maximumAge: 6e5
		});
		return () => {
			cancel = true;
			window.clearTimeout(fallbackTimer);
		};
	}, [adopt]);
	const reload = (0, import_react.useCallback)(() => {
		setStatus("loading");
		applyForecast(coords.current.lat, coords.current.lon);
	}, [applyForecast]);
	const value = (0, import_react.useMemo)(() => ({
		status,
		label,
		lat,
		lon,
		temp,
		feels,
		code,
		wind,
		humidity,
		isDay,
		hours,
		days,
		sunrise,
		sunset,
		reload
	}), [
		status,
		label,
		lat,
		lon,
		temp,
		feels,
		code,
		wind,
		humidity,
		isDay,
		hours,
		days,
		sunrise,
		sunset,
		reload
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlaceContext.Provider, {
		value,
		children
	});
}
function usePlace() {
	const value = (0, import_react.useContext)(PlaceContext);
	if (!value) throw new Error("usePlace fuera de proveedor");
	return value;
}
function formatTemp(value) {
	if (value == null || Number.isNaN(value)) return "—°";
	return `${Math.round(value)}°`;
}
function formatTravel(seconds) {
	const minutes = Math.max(1, Math.round(seconds / 60));
	if (minutes < 60) return `${minutes} min`;
	const hours = Math.floor(minutes / 60);
	const rem = minutes % 60;
	return rem ? `${hours} h ${rem} min` : `${hours} h`;
}
function formatDistance(meters) {
	if (meters < 1e3) return `${Math.round(meters)} m`;
	return `${(meters / 1e3).toLocaleString("es", { maximumFractionDigits: 1 })} km`;
}
function formatDuration(total) {
	const seconds = Math.max(0, Math.round(total));
	const hours = Math.floor(seconds / 3600);
	const minutes = Math.floor(seconds % 3600 / 60);
	const secs = seconds % 60;
	if (hours > 0) return `${hours}:${String(minutes).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
	return `${minutes}:${String(secs).padStart(2, "0")}`;
}
function safeHttpUrl(value) {
	try {
		const url = new URL(value.trim());
		if (url.protocol === "https:" || url.protocol === "http:") return url.toString();
	} catch {
		return null;
	}
	return null;
}
function prettyDate(now) {
	const formatted = new Intl.DateTimeFormat("es", {
		weekday: "long",
		day: "numeric",
		month: "long"
	}).format(now);
	return formatted.charAt(0).toLocaleUpperCase("es") + formatted.slice(1);
}
function weatherLabel(code) {
	if (code == null) return "Clima";
	if (code === 0) return "Despejado";
	if (code === 1) return "Mayormente despejado";
	if (code === 2) return "Parcialmente nublado";
	if (code === 3) return "Nublado";
	if (code <= 49) return "Niebla";
	if (code <= 59) return "Llovizna";
	if (code <= 69) return "Lluvia";
	if (code <= 79) return "Nieve";
	if (code <= 82) return "Chubascos";
	if (code <= 86) return "Nieve";
	if (code <= 99) return "Tormenta";
	return "Clima";
}
function weatherIcon(code) {
	if (code == null || code <= 1) return Sun;
	if (code <= 3) return Cloud;
	if (code <= 49) return CloudFog;
	if (code <= 59) return CloudDrizzle;
	if (code <= 69) return CloudRain;
	if (code <= 79) return CloudSnow;
	if (code <= 82) return CloudRain;
	if (code <= 86) return CloudSnow;
	return CloudLightning;
}
function ClockCard() {
	const [now, setNow] = (0, import_react.useState)(null);
	const place = usePlace();
	(0, import_react.useEffect)(() => {
		const tick = () => setNow(/* @__PURE__ */ new Date());
		tick();
		const id = window.setInterval(tick, 1e3);
		return () => window.clearInterval(id);
	}, []);
	const hours = now ? String(now.getHours()).padStart(2, "0") : "--";
	const minutes = now ? String(now.getMinutes()).padStart(2, "0") : "--";
	const seconds = now ? String(now.getSeconds()).padStart(2, "0") : "--";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "glass p-5",
		"aria-label": "Hora",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: now ? prettyDate(now) : " "
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex items-end gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-7xl leading-none font-light tracking-tight tabular-nums md:text-8xl",
					children: [
						hours,
						":",
						minutes
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-1 w-10 text-xl text-muted tabular-nums",
					children: seconds
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 truncate text-sm text-muted",
				children: place.label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-lg",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "tabular-nums",
					children: formatTemp(place.temp)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-muted",
					children: [" · ", weatherLabel(place.code)]
				})]
			})
		]
	});
}
var ICONS = {
	house: House,
	map: Map,
	music: Music2,
	cloud: CloudSun,
	headphones: Headphones,
	compass: Compass,
	radio: Radio,
	coffee: Coffee,
	moon: Moon,
	heart: Heart,
	globe: Globe,
	zap: Zap,
	calendar: Calendar,
	bookmark: Bookmark,
	star: Star,
	navigation: Navigation,
	link: Link2,
	mic: Mic,
	car: Car,
	sun: Sun,
	thermo: Thermometer,
	clock: Clock
};
var ICON_OPTIONS = Object.keys(ICONS);
function resolveIcon(name) {
	return ICONS[name] ?? Star;
}
var DEFAULT_ACTIONS = [
	{
		id: "home",
		label: "Inicio",
		icon: "house",
		kind: "panel",
		panel: "home"
	},
	{
		id: "map",
		label: "Mapas",
		icon: "map",
		kind: "panel",
		panel: "map"
	},
	{
		id: "music",
		label: "Música",
		icon: "music",
		kind: "panel",
		panel: "music"
	},
	{
		id: "weather",
		label: "Clima",
		icon: "cloud",
		kind: "panel",
		panel: "weather"
	},
	{
		id: "ytm",
		label: "YT Music",
		icon: "headphones",
		kind: "url",
		url: "https://music.youtube.com"
	}
];
function isPanel(value) {
	return value === "home" || value === "map" || value === "music" || value === "weather";
}
var useConsole = create()(persist((set) => ({
	actions: DEFAULT_ACTIONS,
	panel: "home",
	dim: 0,
	volume: 70,
	paused: true,
	media: null,
	pendingQuery: null,
	setPanel: (panel) => set({ panel }),
	setDim: (dim) => set({ dim: Math.min(60, Math.max(0, dim)) }),
	setVolume: (volume) => set({ volume: Math.min(100, Math.max(0, volume)) }),
	setPaused: (paused) => set({ paused }),
	setMedia: (media) => set({
		media,
		paused: false
	}),
	setPendingQuery: (pendingQuery) => set({ pendingQuery }),
	addAction: (action) => set((state) => state.actions.length >= 8 ? state : { actions: [...state.actions, action] }),
	updateAction: (action) => set((state) => ({ actions: state.actions.map((item) => item.id === action.id ? action : item) })),
	removeAction: (id) => set((state) => state.actions.length <= 1 ? state : { actions: state.actions.filter((item) => item.id !== id) }),
	moveAction: (id, direction) => set((state) => {
		const index = state.actions.findIndex((item) => item.id === id);
		const next = index + direction;
		if (index < 0 || next < 0 || next >= state.actions.length) return state;
		const actions = state.actions.slice();
		const [item] = actions.splice(index, 1);
		if (!item) return state;
		actions.splice(next, 0, item);
		return { actions };
	})
}), {
	name: "aether-console",
	skipHydration: true,
	partialize: (state) => ({
		actions: state.actions,
		panel: state.panel,
		dim: state.dim,
		volume: state.volume,
		media: state.media
	}),
	merge: (persisted, current) => {
		const saved = persisted ?? {};
		const actions = Array.isArray(saved.actions) ? saved.actions.filter((item) => !!item && typeof item.id === "string" && typeof item.label === "string" && typeof item.icon === "string" && (item.kind === "panel" || item.kind === "url" || item.kind === "search")) : [];
		return {
			...current,
			...saved,
			actions: actions.length > 0 ? actions.slice(0, 8) : current.actions,
			panel: isPanel(saved.panel) ? saved.panel : current.panel,
			dim: typeof saved.dim === "number" ? saved.dim : current.dim,
			volume: typeof saved.volume === "number" ? saved.volume : current.volume,
			media: saved.media && typeof saved.media === "object" && "id" in saved.media ? saved.media : null,
			paused: true,
			pendingQuery: null
		};
	}
}));
var PANELS = [
	{
		id: "home",
		label: "Inicio"
	},
	{
		id: "map",
		label: "Mapas"
	},
	{
		id: "music",
		label: "Música"
	},
	{
		id: "weather",
		label: "Clima"
	}
];
var EMPTY = {
	id: null,
	label: "",
	icon: "star",
	kind: "panel",
	panel: "music",
	url: "https://",
	query: ""
};
function CustomizeSheet() {
	const actions = useConsole((state) => state.actions);
	const addAction = useConsole((state) => state.addAction);
	const updateAction = useConsole((state) => state.updateAction);
	const removeAction = useConsole((state) => state.removeAction);
	const moveAction = useConsole((state) => state.moveAction);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [draft, setDraft] = (0, import_react.useState)(EMPTY);
	const [error, setError] = (0, import_react.useState)(null);
	function load(action) {
		setDraft({
			id: action.id,
			label: action.label,
			icon: action.icon,
			kind: action.kind,
			panel: action.panel ?? "home",
			url: action.url ?? "https://",
			query: action.query ?? ""
		});
		setError(null);
	}
	function save() {
		const label = draft.label.trim().slice(0, 18);
		if (label.length < 1) {
			setError("Ponle un nombre corto.");
			return;
		}
		const action = {
			id: draft.id ?? crypto.randomUUID(),
			label,
			icon: draft.icon,
			kind: draft.kind,
			panel: draft.kind === "panel" ? draft.panel : void 0,
			url: void 0,
			query: void 0
		};
		if (draft.kind === "url") {
			const url = safeHttpUrl(draft.url);
			if (!url) {
				setError("El enlace tiene que empezar por https://");
				return;
			}
			action.url = url;
		}
		if (draft.kind === "search") {
			const query = draft.query.trim().slice(0, 80);
			if (query.length < 2) {
				setError("Escribe qué música buscar.");
				return;
			}
			action.query = query;
		}
		if (draft.id) updateAction(action);
		else if (actions.length >= 8) {
			setError("La barra admite hasta 8 acciones.");
			return;
		} else addAction(action);
		setDraft(EMPTY);
		setError(null);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "dock-btn",
				"aria-label": "Personalizar acciones",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, {
					className: "size-5",
					strokeWidth: 1.5
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Ajustes" })]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "sheet-overlay" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "sheet-content scroll-slim",
			"aria-describedby": "acciones-ayuda",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
						className: "text-2xl font-light",
						children: "Acciones"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
						id: "acciones-ayuda",
						className: "mt-1 text-sm text-muted",
						children: "Estos botones viven en la barra inferior. Pueden abrir una pantalla, un enlace o una búsqueda musical."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
						className: "btn",
						"aria-label": "Cerrar",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {
							className: "size-4",
							strokeWidth: 1.5
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-5 divide-y divide-line",
					children: actions.map((action, index) => {
						const Icon = resolveIcon(action.icon);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-2 py-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
									className: "size-4 text-accent",
									strokeWidth: 1.5,
									"aria-hidden": "true"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "min-w-0 flex-1 truncate",
									children: action.label
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn-ghost btn",
									"aria-label": `Subir ${action.label}`,
									onClick: () => moveAction(action.id, -1),
									disabled: index === 0,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, {
										className: "size-4",
										strokeWidth: 1.5
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn-ghost btn",
									"aria-label": `Bajar ${action.label}`,
									onClick: () => moveAction(action.id, 1),
									disabled: index === actions.length - 1,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
										className: "size-4",
										strokeWidth: 1.5
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn",
									onClick: () => load(action),
									children: "Editar"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn-ghost btn",
									onClick: () => removeAction(action.id),
									disabled: actions.length <= 1,
									children: "Quitar"
								})
							]
						}, action.id);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-5",
					onSubmit: (event) => {
						event.preventDefault();
						save();
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm text-muted",
							children: draft.id ? "Editar acción" : "Nueva acción"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "mt-3 block text-sm",
							htmlFor: "accion-nombre",
							children: "Nombre"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "accion-nombre",
							className: "field mt-1",
							value: draft.label,
							maxLength: 18,
							onChange: (event) => setDraft({
								...draft,
								label: event.target.value
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-sm",
							children: "Icono"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 flex flex-wrap gap-2",
							children: ICON_OPTIONS.map((name) => {
								const Icon = resolveIcon(name);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "icon-pick",
									"aria-label": name,
									"aria-pressed": draft.icon === name,
									onClick: () => setDraft({
										...draft,
										icon: name
									}),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
										className: "size-4",
										strokeWidth: 1.5
									})
								}, name);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "mt-4 block text-sm",
							htmlFor: "accion-tipo",
							children: "Tipo"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							id: "accion-tipo",
							className: "field mt-1",
							value: draft.kind,
							onChange: (event) => setDraft({
								...draft,
								kind: event.target.value
							}),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "panel",
									children: "Pantalla"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "url",
									children: "Enlace"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "search",
									children: "Búsqueda musical"
								})
							]
						}),
						draft.kind === "panel" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: "field mt-2",
							"aria-label": "Pantalla",
							value: draft.panel,
							onChange: (event) => setDraft({
								...draft,
								panel: event.target.value
							}),
							children: PANELS.map((panel) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: panel.id,
								children: panel.label
							}, panel.id))
						}) : null,
						draft.kind === "url" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field mt-2",
							"aria-label": "Enlace",
							inputMode: "url",
							value: draft.url,
							onChange: (event) => setDraft({
								...draft,
								url: event.target.value
							}),
							placeholder: "https://"
						}) : null,
						draft.kind === "search" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field mt-2",
							"aria-label": "Búsqueda musical",
							value: draft.query,
							onChange: (event) => setDraft({
								...draft,
								query: event.target.value
							}),
							placeholder: "jazz de noche"
						}) : null,
						error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: error
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "submit",
								className: "btn-accent btn",
								children: "Guardar"
							}), draft.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn",
								onClick: () => {
									setDraft(EMPTY);
									setError(null);
								},
								children: "Cancelar"
							}) : null]
						})
					]
				})
			]
		})] })]
	});
}
function ActionControl({ action }) {
	const panel = useConsole((state) => state.panel);
	const setPanel = useConsole((state) => state.setPanel);
	const setPendingQuery = useConsole((state) => state.setPendingQuery);
	const Icon = resolveIcon(action.icon);
	const pressed = action.kind === "panel" && action.panel === panel;
	if (action.kind === "url") {
		const href = safeHttpUrl(action.url ?? "");
		if (!href) return null;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
			className: "dock-btn",
			href,
			target: "_blank",
			rel: "noreferrer",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
				className: "size-5",
				strokeWidth: 1.5
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: action.label })]
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		className: "dock-btn",
		"aria-pressed": pressed,
		onClick: () => {
			if (action.kind === "panel" && action.panel) setPanel(action.panel);
			if (action.kind === "search" && action.query) {
				setPanel("music");
				setPendingQuery(action.query);
			}
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
			className: "size-5",
			strokeWidth: 1.5
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: action.label })]
	});
}
function Dock() {
	const actions = useConsole((state) => state.actions);
	const setPanel = useConsole((state) => state.setPanel);
	const dim = useConsole((state) => state.dim);
	const setDim = useConsole((state) => state.setDim);
	const place = usePlace();
	const [brightOpen, setBrightOpen] = (0, import_react.useState)(false);
	const brightness = 100 - dim;
	(0, import_react.useEffect)(() => {
		if (!brightOpen) return;
		function close(event) {
			const target = event.target;
			if (target instanceof Element && target.closest("[data-bright]")) return;
			setBrightOpen(false);
		}
		window.addEventListener("pointerdown", close);
		return () => window.removeEventListener("pointerdown", close);
	}, [brightOpen]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "aether-dock",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "temp-btn",
				onClick: () => setPanel("weather"),
				"aria-label": `Clima, ${formatTemp(place.temp)}`,
				children: formatTemp(place.temp)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "dock-rule" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "dock-scroll",
				children: actions.map((action) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionControl, { action }, action.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative",
				"data-bright": "",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "dock-btn",
					"aria-expanded": brightOpen,
					"aria-label": "Brillo",
					onClick: () => setBrightOpen((open) => !open),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SunMedium, {
						className: "size-5",
						strokeWidth: 1.5
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Brillo" })]
				}), brightOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bright-pop glass",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm",
						children: "Brillo de la pantalla"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "range mt-3",
						type: "range",
						min: 40,
						max: 100,
						value: brightness,
						"aria-label": "Nivel de brillo",
						onChange: (event) => setDim(100 - Number(event.target.value))
					})]
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CustomizeSheet, {})
		]
	});
}
var NavContext = (0, import_react.createContext)(null);
function NavProvider({ children }) {
	const { lat, lon } = usePlace();
	const [destination, setDestination] = (0, import_react.useState)(null);
	const [route, setRoute] = (0, import_react.useState)(null);
	const [routing, setRouting] = (0, import_react.useState)(false);
	const [routeError, setRouteError] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!destination) {
			setRoute(null);
			setRouteError(null);
			setRouting(false);
			return;
		}
		let cancel = false;
		setRouting(true);
		setRouteError(null);
		routeDrive({ data: {
			fromLat: lat,
			fromLon: lon,
			toLat: destination.lat,
			toLon: destination.lon
		} }).then((result) => {
			if (cancel) return;
			setRouting(false);
			if (result.ok) {
				setRoute(result.route);
				setRouteError(null);
			} else {
				setRoute(null);
				setRouteError(result.error);
			}
		});
		return () => {
			cancel = true;
		};
	}, [
		destination,
		lat,
		lon
	]);
	const value = (0, import_react.useMemo)(() => ({
		destination,
		route,
		routing,
		routeError,
		setDestination,
		clearRoute: () => setDestination(null)
	}), [
		destination,
		route,
		routing,
		routeError
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavContext.Provider, {
		value,
		children
	});
}
function useNav() {
	const value = (0, import_react.useContext)(NavContext);
	if (!value) throw new Error("useNav fuera de proveedor");
	return value;
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function motionDuration() {
	if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return 0;
	return .7;
}
function MapCanvas({ interactive }) {
	const { lat, lon } = usePlace();
	const { destination, route } = useNav();
	const hostRef = (0, import_react.useRef)(null);
	const mapRef = (0, import_react.useRef)(null);
	const meRef = (0, import_react.useRef)(null);
	const destRef = (0, import_react.useRef)(null);
	const routeRef = (0, import_react.useRef)(null);
	const followRef = (0, import_react.useRef)(true);
	const locRef = (0, import_react.useRef)({
		lat,
		lon
	});
	locRef.current = {
		lat,
		lon
	};
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!hostRef.current) return;
		let dead = false;
		let map = null;
		(async () => {
			const L = await import("../_libs/leaflet.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()));
			await Promise.resolve({});
			if (dead || !hostRef.current) return;
			map = L.map(hostRef.current, {
				zoomControl: false,
				attributionControl: true,
				center: [locRef.current.lat, locRef.current.lon],
				zoom: 12,
				minZoom: 3
			});
			map.attributionControl.setPrefix("");
			L.tileLayer("https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png", {
				subdomains: "abcd",
				maxZoom: 20,
				attribution: "&copy; OpenStreetMap &copy; CARTO"
			}).addTo(map);
			map.on("dragstart", () => {
				followRef.current = false;
			});
			mapRef.current = map;
			window.setTimeout(() => map?.invalidateSize(), 80);
			if (!dead) setReady(true);
		})();
		return () => {
			dead = true;
			map?.remove();
			mapRef.current = null;
			setReady(false);
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		const map = mapRef.current;
		if (!map) return;
		let dead = false;
		(async () => {
			const L = await import("../_libs/leaflet.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()));
			if (dead || !mapRef.current) return;
			meRef.current?.remove();
			const icon = L.divIcon({
				className: "aether-pin-wrap",
				html: "<div class=\"aether-pin\"></div>",
				iconSize: [18, 18],
				iconAnchor: [9, 9]
			});
			meRef.current = L.marker([lat, lon], {
				icon,
				interactive: false,
				keyboard: false
			}).addTo(map);
			if (followRef.current && !destination) map.flyTo([lat, lon], Math.max(map.getZoom(), 12), { duration: motionDuration() });
		})();
		return () => {
			dead = true;
		};
	}, [
		ready,
		lat,
		lon,
		destination
	]);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		const map = mapRef.current;
		if (!map) return;
		let dead = false;
		(async () => {
			const L = await import("../_libs/leaflet.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()));
			if (dead || !mapRef.current) return;
			destRef.current?.remove();
			destRef.current = null;
			if (!destination) return;
			followRef.current = false;
			const icon = L.divIcon({
				className: "aether-pin-wrap",
				html: "<div class=\"aether-dest\"></div>",
				iconSize: [12, 12],
				iconAnchor: [6, 6]
			});
			destRef.current = L.marker([destination.lat, destination.lon], {
				icon,
				interactive: false,
				keyboard: false
			}).addTo(map);
		})();
		return () => {
			dead = true;
		};
	}, [ready, destination]);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		const map = mapRef.current;
		if (!map) return;
		let dead = false;
		(async () => {
			const L = await import("../_libs/leaflet.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()));
			if (dead || !mapRef.current) return;
			routeRef.current?.remove();
			routeRef.current = null;
			if (!route) return;
			const accent = getComputedStyle(document.documentElement).getPropertyValue("--color-accent").trim() || "#e4c4a0";
			const layer = L.geoJSON(route.geometry, { style: {
				color: accent,
				weight: 4,
				opacity: .92
			} }).addTo(map);
			routeRef.current = layer;
			const narrow = window.matchMedia("(max-width: 767px)").matches;
			map.fitBounds(layer.getBounds(), {
				paddingTopLeft: narrow ? [28, 150] : [48, 96],
				paddingBottomRight: narrow ? [28, 180] : [120, 140]
			});
		})();
		return () => {
			dead = true;
		};
	}, [ready, route]);
	function locate() {
		followRef.current = true;
		mapRef.current?.flyTo([locRef.current.lat, locRef.current.lon], 14, { duration: motionDuration() });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "absolute inset-0 z-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref: hostRef,
			className: "h-full w-full"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("map-zoom", interactive && "is-open"),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn",
					"aria-label": "Acercar",
					onClick: () => mapRef.current?.zoomIn(),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
						className: "size-4",
						strokeWidth: 1.5
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn",
					"aria-label": "Alejar",
					onClick: () => mapRef.current?.zoomOut(),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, {
						className: "size-4",
						strokeWidth: 1.5
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn",
					"aria-label": "Mi ubicación",
					onClick: locate,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LocateFixed, {
						className: "size-4",
						strokeWidth: 1.5
					})
				})
			]
		})]
	});
}
function MapSearch() {
	const { destination, route, routing, routeError, setDestination, clearRoute } = useNav();
	const [query, setQuery] = (0, import_react.useState)("");
	const [hits, setHits] = (0, import_react.useState)([]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	async function run(value) {
		setBusy(true);
		setError(null);
		const result = await searchPlaces({ data: { q: value } });
		setBusy(false);
		if (!result.ok) {
			setHits([]);
			setError(result.error);
			return;
		}
		setHits(result.hits);
		if (result.hits.length === 0) setError("Sin resultados para esa búsqueda.");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "map-search glass p-3",
		onSubmit: (event) => {
			event.preventDefault();
			if (query.trim().length >= 2) run(query.trim());
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field",
					value: query,
					onChange: (event) => setQuery(event.target.value),
					placeholder: "A dónde vamos",
					"aria-label": "Buscar destino",
					enterKeyHint: "search"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "btn-accent btn",
					"aria-label": "Buscar destino",
					disabled: busy || query.trim().length < 2,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
						className: "size-4",
						strokeWidth: 1.5
					})
				})]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: error
			}) : null,
			hits.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-2 max-h-52 overflow-auto",
				children: hits.map((hit) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "w-full rounded-xl px-2 py-2 text-left text-sm hover:bg-raised",
					onClick: () => {
						setDestination(hit);
						setHits([]);
						setQuery(hit.label);
						setError(null);
					},
					children: hit.label
				}) }, hit.id))
			}) : null,
			destination ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm",
					children: destination.label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-accent tabular-nums",
					children: routing ? "Trazando ruta…" : route ? `${formatTravel(route.durationS)} · ${formatDistance(route.distanceM)}` : routeError
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn",
					"aria-label": "Quitar ruta",
					onClick: clearRoute,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {
						className: "size-4",
						strokeWidth: 1.5
					})
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-xs text-muted",
				children: "Busca una dirección y traza la ruta desde donde estás."
			})
		]
	});
}
function parseMediaUrl(input) {
	const raw = input.trim();
	if (!raw) return null;
	try {
		const url = new URL(raw);
		const host = url.hostname.replace(/^www\./, "");
		if (!(host === "youtu.be" || host === "youtube.com" || host === "m.youtube.com" || host === "music.youtube.com" || host === "youtube-nocookie.com")) return null;
		if (host === "youtu.be") {
			const id = url.pathname.split("/").filter(Boolean)[0];
			if (id) return {
				kind: "video",
				id,
				title: "YouTube",
				author: ""
			};
			return null;
		}
		const video = url.searchParams.get("v");
		const list = url.searchParams.get("list");
		if (video) return {
			kind: "video",
			id: video,
			title: "YouTube",
			author: ""
		};
		if (list) return {
			kind: "playlist",
			id: list,
			title: "Lista",
			author: "YouTube"
		};
	} catch {
		return null;
	}
	return null;
}
function embedSrc(media) {
	const base = media.kind === "video" ? `https://www.youtube-nocookie.com/embed/${encodeURIComponent(media.id)}` : `https://www.youtube-nocookie.com/embed/videoseries?list=${encodeURIComponent(media.id)}`;
	return `${base}${base.includes("?") ? "&" : "?"}autoplay=1&rel=0&modestbranding=1&playsinline=1&enablejsapi=1`;
}
var frame = null;
function bindPlayerFrame(next) {
	frame = next;
}
function playerCmd(func, args = []) {
	frame?.postMessage(JSON.stringify({
		event: "command",
		func,
		args
	}), "*");
}
function Player({ cinema }) {
	const media = useConsole((state) => state.media);
	const volume = useConsole((state) => state.volume);
	const paused = useConsole((state) => state.paused);
	const setPaused = useConsole((state) => state.setPaused);
	const setVolume = useConsole((state) => state.setVolume);
	const setPanel = useConsole((state) => state.setPanel);
	const origin = typeof window === "undefined" ? "" : window.location.origin;
	const frameRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		playerCmd("setVolume", [volume]);
	}, [volume, media]);
	function syncFrame() {
		bindPlayerFrame(frameRef.current?.contentWindow ?? null);
		playerCmd("setVolume", [useConsole.getState().volume]);
	}
	function toggle() {
		const next = !useConsole.getState().paused;
		setPaused(next);
		playerCmd(next ? "pauseVideo" : "playVideo");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cinema ? "player-cinema glass" : "player-mini glass",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cinema ? "h-full" : "flex h-full",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cinema ? "h-full w-full bg-bg" : "h-full shrink-0 bg-bg",
				children: media ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
					ref: frameRef,
					title: media.title,
					src: `${embedSrc(media)}&origin=${encodeURIComponent(origin)}`,
					className: cinema ? "h-full w-full" : "h-full w-36 md:w-44",
					allow: "autoplay; encrypted-media; picture-in-picture",
					allowFullScreen: true,
					referrerPolicy: "strict-origin-when-cross-origin",
					onLoad: syncFrame
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cinema ? "grid h-full place-items-center" : "grid h-full w-24 place-items-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "disc" })
				})
			}), !cinema ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 flex-1 flex-col justify-center gap-1 px-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-sm",
						children: media?.title ?? "Nada sonando"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-xs text-muted",
						children: media?.author || "YouTube Music"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-1 flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn h-9 min-h-9 w-9 px-0",
							"aria-label": media ? paused ? "Reproducir" : "Pausa" : "Abrir música",
							onClick: () => media ? toggle() : setPanel("music"),
							children: media && !paused ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, {
								className: "size-4",
								strokeWidth: 1.5
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
								className: "ml-px size-4",
								strokeWidth: 1.5
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "range",
							type: "range",
							min: 0,
							max: 100,
							value: volume,
							"aria-label": "Volumen",
							onChange: (event) => setVolume(Number(event.target.value))
						})]
					})
				]
			}) : null]
		})
	});
}
function Transport() {
	const media = useConsole((state) => state.media);
	const paused = useConsole((state) => state.paused);
	const volume = useConsole((state) => state.volume);
	const setPaused = useConsole((state) => state.setPaused);
	const setVolume = useConsole((state) => state.setVolume);
	function toggle() {
		if (!media) return;
		const next = !paused;
		setPaused(next);
		playerCmd(next ? "pauseVideo" : "playVideo");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			className: "btn-accent btn",
			onClick: toggle,
			disabled: !media,
			"aria-label": paused ? "Reproducir" : "Pausa",
			children: [paused ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
				className: "ml-px size-4",
				strokeWidth: 1.5
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, {
				className: "size-4",
				strokeWidth: 1.5
			}), paused ? "Reproducir" : "Pausa"]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "flex min-w-0 flex-1 items-center gap-2 text-xs text-muted",
			children: ["Volumen", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "range",
				type: "range",
				min: 0,
				max: 100,
				value: volume,
				"aria-label": "Volumen",
				onChange: (event) => setVolume(Number(event.target.value))
			})]
		})]
	});
}
var STATIONS = [
	{
		label: "Lo-fi",
		query: "lofi hip hop radio"
	},
	{
		label: "Jazz",
		query: "jazz cafe music"
	},
	{
		label: "Pop",
		query: "pop hits 2026"
	},
	{
		label: "Rock",
		query: "classic rock mix"
	},
	{
		label: "Clásica",
		query: "classical music playlist"
	},
	{
		label: "Latina",
		query: "música latina hits"
	},
	{
		label: "Foco",
		query: "deep focus music"
	},
	{
		label: "Electro",
		query: "electronic music mix"
	}
];
function MusicLibrary() {
	const setMedia = useConsole((state) => state.setMedia);
	const pendingQuery = useConsole((state) => state.pendingQuery);
	const setPendingQuery = useConsole((state) => state.setPendingQuery);
	const [query, setQuery] = (0, import_react.useState)("");
	const [tracks, setTracks] = (0, import_react.useState)([]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	async function runSearch(value, playFirst = false) {
		const parsed = parseMediaUrl(value);
		if (parsed) {
			setMedia(parsed);
			setError(null);
			setTracks([]);
			return;
		}
		setBusy(true);
		setError(null);
		const result = await searchTracks({ data: { q: value } });
		setBusy(false);
		if (!result.ok) {
			setTracks([]);
			setError(result.error);
			return;
		}
		setTracks(result.tracks);
		const first = result.tracks[0];
		if (playFirst && first) setMedia({
			kind: "video",
			id: first.id,
			title: first.title,
			author: first.author
		});
	}
	(0, import_react.useEffect)(() => {
		if (!pendingQuery) return;
		setQuery(pendingQuery);
		setPendingQuery(null);
		runSearch(pendingQuery, true);
	}, [pendingQuery, setPendingQuery]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "sheet-panel sheet-music glass scroll-slim p-4 md:p-5",
		"aria-label": "YouTube Music",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-widest text-muted uppercase",
				children: "YouTube Music"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-1 text-2xl font-light",
				children: "Qué quieres oír"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-4 flex gap-2",
				onSubmit: (event) => {
					event.preventDefault();
					if (query.trim().length >= 2) runSearch(query.trim(), true);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field",
					value: query,
					onChange: (event) => setQuery(event.target.value),
					placeholder: "Tema, artista o enlace",
					"aria-label": "Buscar en YouTube Music",
					enterKeyHint: "search"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "btn-accent btn",
					disabled: busy || query.trim().length < 2,
					children: busy ? "…" : "Buscar"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Transport, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 flex flex-wrap gap-2",
				children: STATIONS.map((station) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn",
					onClick: () => {
						setQuery(station.query);
						runSearch(station.query, true);
					},
					children: station.label
				}, station.label))
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 text-sm text-muted",
				children: [
					error,
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "text-accent underline-offset-2 hover:underline",
						href: "https://music.youtube.com",
						target: "_blank",
						rel: "noreferrer",
						children: "Abrir YouTube Music"
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 divide-y divide-line",
				children: tracks.map((track) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "flex w-full items-center gap-3 py-3 text-left",
					onClick: () => setMedia({
						kind: "video",
						id: track.id,
						title: track.title,
						author: track.author
					}),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: `https://i.ytimg.com/vi/${track.id}/hqdefault.jpg`,
							alt: "",
							className: "size-14 rounded-lg object-cover outline outline-1 -outline-offset-1 outline-fg/10"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block truncate",
								children: track.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block truncate text-sm text-muted",
								children: track.author
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm text-muted tabular-nums",
							children: formatDuration(track.duration)
						})
					]
				}) }, track.id))
			}),
			tracks.length === 0 && !busy && !error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-muted",
				children: "Elige una estación o busca un tema. El audio sigue mientras usas el mapa."
			}) : null
		]
	});
}
function dayName(day, index) {
	if (index === 0) return "Hoy";
	if (index === 1) return "Mañana";
	const name = (/* @__PURE__ */ new Date(`${day.date}T12:00:00`)).toLocaleDateString("es", { weekday: "short" });
	return name.charAt(0).toUpperCase() + name.slice(1);
}
function WeatherCard() {
	const place = usePlace();
	const setPanel = useConsole((state) => state.setPanel);
	const Icon = weatherIcon(place.code);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "glass home-weather p-5",
		"aria-label": "Clima de ahora",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-5xl font-light tabular-nums",
					children: formatTemp(place.temp)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-muted",
					children: place.status === "error" ? "Sin conexión al clima" : weatherLabel(place.code)
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
					className: "size-8 text-accent",
					strokeWidth: 1.5,
					"aria-hidden": "true"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mt-4 grid grid-cols-3 gap-3 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-muted",
						children: "Sensación"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "tabular-nums",
						children: formatTemp(place.feels)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-muted",
						children: "Viento"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "tabular-nums",
						children: place.wind == null ? "—" : `${Math.round(place.wind)} km/h`
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-muted",
						children: "Humedad"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "tabular-nums",
						children: place.humidity == null ? "—" : `${Math.round(place.humidity)}%`
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 flex gap-2 overflow-x-auto",
				children: place.hours.slice(0, 5).map((hour) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-14 rounded-xl bg-raised px-2 py-2 text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted tabular-nums",
						children: hour.time
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm tabular-nums",
						children: formatTemp(hour.temp)
					})]
				}, hour.time))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "btn-ghost btn mt-3 px-0",
				onClick: () => setPanel("weather"),
				children: "Ver pronóstico"
			})
		]
	});
}
function WeatherPanel() {
	const place = usePlace();
	const Icon = weatherIcon(place.code);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "sheet-panel sheet-weather glass scroll-slim p-5",
		"aria-label": "Pronóstico",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: place.label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-6xl font-light tabular-nums",
					children: formatTemp(place.temp)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
					className: "mb-2 size-10 text-accent",
					strokeWidth: 1.5,
					"aria-hidden": "true"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-lg",
				children: weatherLabel(place.code)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm text-muted",
				children: [
					"Sensación ",
					formatTemp(place.feels),
					" · Viento ",
					place.wind == null ? "—" : `${Math.round(place.wind)} km/h`,
					" · Humedad",
					" ",
					place.humidity == null ? "—" : `${Math.round(place.humidity)}%`
				]
			}),
			place.sunrise && place.sunset ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm text-muted",
				children: [
					"Amanecer ",
					place.sunrise,
					" · Atardecer ",
					place.sunset
				]
			}) : null,
			place.status === "error" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "btn mt-4",
				onClick: place.reload,
				children: "Reintentar"
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-6 text-sm text-muted",
				children: "Próximas horas"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 flex gap-2 overflow-x-auto pb-1",
				children: place.hours.map((hour) => {
					const HourIcon = weatherIcon(hour.code);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-16 rounded-xl bg-raised px-2 py-3 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted tabular-nums",
								children: hour.time
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HourIcon, {
								className: "mx-auto mt-2 size-4 text-accent",
								strokeWidth: 1.5,
								"aria-hidden": "true"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm tabular-nums",
								children: formatTemp(hour.temp)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted tabular-nums",
								children: [hour.pop, "%"]
							})
						]
					}, hour.time);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-6 text-sm text-muted",
				children: "Siete días"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-2 divide-y divide-line",
				children: place.days.map((day, index) => {
					const DayIcon = weatherIcon(day.code);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center gap-3 py-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "w-20 text-sm",
								children: dayName(day, index)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DayIcon, {
								className: "size-4 text-accent",
								strokeWidth: 1.5,
								"aria-hidden": "true"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-auto text-sm text-muted tabular-nums",
								children: formatTemp(day.min)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm tabular-nums",
								children: formatTemp(day.max)
							})
						]
					}, day.date);
				})
			}),
			place.status === "loading" && place.temp == null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-muted",
				children: "Leyendo el cielo…"
			}) : null
		]
	});
}
function Header() {
	const place = usePlace();
	const route = useNav().route;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "aether-header",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "wordmark",
			children: "Aether"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "truncate text-sm text-muted",
			children: route ? `En ruta · ${formatTravel(route.durationS)}` : place.label
		})]
	});
}
function Shell() {
	const panel = useConsole((state) => state.panel);
	const dim = useConsole((state) => state.dim);
	(0, import_react.useEffect)(() => {
		useConsole.persist.rehydrate();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "aether-root",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapCanvas, { interactive: panel === "map" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "map-scrim" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {}),
			panel === "home" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "home-stack",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClockCard, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WeatherCard, {})]
			}) : null,
			panel === "weather" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WeatherPanel, {}) : null,
			panel === "music" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MusicLibrary, {}) : null,
			panel === "map" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapSearch, {}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Player, { cinema: panel === "music" }),
			dim > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "dim-veil",
				style: { opacity: dim / 100 }
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dock, {})
		]
	});
}
function Aether() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlaceProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {}) }) });
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Aether, {});
}
//#endregion
export { Home as component };
