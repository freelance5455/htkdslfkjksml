import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { f as updateCheckStatus, h as useChecks, v as useInvalidateBooks } from "./use-books-BtZpLk9U.mjs";
import { s as formatJalali, t as CHECK_STATUS } from "./format-c9GA3s0l.mjs";
import { i as PageHeader, r as Money, t as Badge } from "./card-Bb_-PO54.mjs";
import { t as Button } from "./button-BiViDDnZ.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/checks-DDeBvpi4.js
var import_jsx_runtime = require_jsx_runtime();
function ChecksPage() {
	const { data = [] } = useChecks();
	const invalidate = useInvalidateBooks();
	async function setStatus(id, status) {
		await updateCheckStatus({ data: {
			id,
			status
		} });
		toast.success("وضعیت چک به‌روز شد");
		invalidate();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		title: "مدیریت چک‌ها",
		description: "دریافتنی و پرداختنی. وصول و برگشت از مسیر عملیات، سند دوبل می‌سازد."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "overflow-x-auto rounded-[24px] border border-line bg-paper",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
			className: "w-full min-w-[700px] text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
				className: "text-xs text-muted",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-4 py-3 text-right",
						children: "شماره"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-4 py-3 text-right",
						children: "نوع"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-4 py-3 text-right",
						children: "شخص"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-4 py-3 text-right",
						children: "بانک"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-4 py-3 text-left",
						children: "مبلغ"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-4 py-3 text-right",
						children: "سررسید"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-4 py-3 text-right",
						children: "وضعیت"
					})
				] })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: data.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
				className: "border-t border-line",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "px-4 py-3",
						children: c.number
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "px-4 py-3",
						children: c.kind === "receivable" ? "دریافتنی" : "پرداختنی"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "px-4 py-3",
						children: c.party_name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "px-4 py-3",
						children: c.bank_name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "px-4 py-3 text-left",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Money, {
							value: c.amount,
							compact: true
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "px-4 py-3",
						children: c.due_date ? formatJalali(c.due_date) : "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
						className: "px-4 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: CHECK_STATUS[c.status] ?? c.status }), c.kind === "receivable" && c.status === "in_hand" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "ghost",
							className: "mr-2",
							onClick: () => setStatus(c.id, "deposited"),
							children: "واگذاری"
						}) : null]
					})
				]
			}, c.id)) })]
		})
	})] });
}
//#endregion
export { ChecksPage as component };
