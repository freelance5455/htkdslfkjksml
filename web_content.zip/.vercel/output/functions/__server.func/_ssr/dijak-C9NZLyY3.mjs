import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { d as monthlySubscriptionHuf, n as usePortfolio, p as subscriptionTotals } from "./router-Ddmv2GI8.mjs";
import { t as Shell } from "./shell-wztA7KjE.mjs";
import { c as formatDay, g as uid, h as todayIso, i as Modal, l as formatMoney, n as Field } from "./format-Bbm5TEoT.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dijak-C9NZLyY3.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CADENCE = {
	heti: "Hetente",
	havi: "Havonta",
	eves: "Évente"
};
function Page() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fees, {}) });
}
function Fees() {
	const { state, saveSub, deleteSub } = usePortfolio();
	const [editing, setEditing] = (0, import_react.useState)(null);
	const totals = subscriptionTotals(state.subscriptions, state.market.fx);
	const usd = state.market.fx.usdHuf ? totals.monthly / state.market.fx.usdHuf : 0;
	const wasteUsd = state.market.fx.usdHuf ? totals.wastefulMonthly / state.market.fx.usdHuf : 0;
	const rows = [...state.subscriptions].sort((a, b) => Number(b.wasteful) - Number(a.wasteful) || a.name.localeCompare(b.name, "hu"));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-end justify-between gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-serif text-3xl",
				children: "Előfizetések"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 max-w-xl text-sm text-muted",
				children: "Ami rendszeresen elmegy. A feleslegesnek jelölt tételek külön összeadódnak, hogy lásd a szivárgást."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "btn btn-primary",
				onClick: () => setEditing({
					id: uid(),
					name: "",
					amount: 0,
					currency: "HUF",
					cadence: "havi",
					category: "Egyéb",
					nextDate: todayIso(),
					active: true,
					wasteful: false,
					note: ""
				}),
				children: "Új díj"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-8 grid gap-8 border-t border-line pt-8 sm:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Havi teher"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 font-serif text-4xl tabular-nums",
					children: formatMoney(totals.monthly, "HUF")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted tabular-nums",
					children: [
						formatMoney(usd, "USD"),
						" · évente ",
						formatMoney(totals.annual, "HUF")
					]
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "sm:border-l sm:border-line sm:pl-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Ebből feleslegesnek jelölt"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-serif text-4xl text-clay tabular-nums",
						children: formatMoney(totals.wastefulMonthly, "HUF")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted tabular-nums",
						children: [formatMoney(wasteUsd, "USD"), " havonta"]
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
			className: "mt-8 divide-y divide-line border-t border-line",
			children: [rows.map((item) => {
				const monthly = monthlySubscriptionHuf(item, state.market.fx);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: `grid gap-3 py-4 sm:grid-cols-[minmax(0,1fr)_auto] ${item.wasteful ? "border-l-2 border-clay pl-3" : ""}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: item.active ? "" : "text-muted line-through",
								children: item.name
							}),
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm text-muted",
								children: item.category
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: [
								formatMoney(item.amount, item.currency),
								" · ",
								CADENCE[item.cadence].toLowerCase(),
								item.nextDate ? ` · következő ${formatDay(item.nextDate)}` : "",
								item.wasteful ? " · felesleges" : "",
								!item.active ? " · szünetel" : ""
							]
						}),
						item.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: item.note
						}) : null
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-3 sm:flex-col sm:items-end",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "tabular-nums",
							children: item.active ? formatMoney(monthly, "HUF") : "—"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn btn-quiet",
									onClick: () => saveSub({
										...item,
										wasteful: !item.wasteful
									}),
									children: item.wasteful ? "Mégis kell" : "Felesleges"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn btn-quiet",
									onClick: () => setEditing(item),
									children: "Módosít"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn btn-quiet text-clay",
									onClick: () => deleteSub(item.id),
									children: "Töröl"
								})
							]
						})]
					})]
				}, item.id);
			}), rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: "py-10 text-sm text-muted",
				children: "Nincs rögzített díj."
			}) : null]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SubDialog, {
			item: editing,
			onClose: () => setEditing(null),
			onSave: (item) => {
				saveSub(item);
				setEditing(null);
			}
		})
	] });
}
function SubDialog({ item, onClose, onSave }) {
	const [draft, setDraft] = (0, import_react.useState)(item);
	(0, import_react.useEffect)(() => setDraft(item), [item]);
	if (!draft) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		open: false,
		title: "Díj",
		onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		open: Boolean(item),
		title: "Előfizetés",
		onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Név",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						value: draft.name,
						onChange: (event) => setDraft({
							...draft,
							name: event.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Összeg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field tabular-nums",
							inputMode: "decimal",
							value: draft.amount || "",
							onChange: (event) => setDraft({
								...draft,
								amount: Number(event.target.value.replace(",", ".")) || 0
							})
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Deviza",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: "field",
							value: draft.currency,
							onChange: (event) => setDraft({
								...draft,
								currency: event.target.value
							}),
							children: [
								"HUF",
								"USD",
								"EUR",
								"GBP"
							].map((currency) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: currency }, currency))
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Gyakoriság",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: "field",
							value: draft.cadence,
							onChange: (event) => setDraft({
								...draft,
								cadence: event.target.value
							}),
							children: Object.keys(CADENCE).map((cadence) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: cadence,
								children: CADENCE[cadence]
							}, cadence))
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Kategória",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							value: draft.category,
							onChange: (event) => setDraft({
								...draft,
								category: event.target.value
							})
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Következő terhelés",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						type: "date",
						value: draft.nextDate,
						onChange: (event) => setDraft({
							...draft,
							nextDate: event.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Megjegyzés",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						value: draft.note,
						onChange: (event) => setDraft({
							...draft,
							note: event.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex min-h-11 items-center gap-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						className: "size-5 accent-pine",
						checked: draft.active,
						onChange: (event) => setDraft({
							...draft,
							active: event.target.checked
						})
					}), "Aktív"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex min-h-11 items-center gap-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						className: "size-5 accent-pine",
						checked: draft.wasteful,
						onChange: (event) => setDraft({
							...draft,
							wasteful: event.target.checked
						})
					}), "Feleslegesnek jelölöm"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 flex justify-end gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-ghost",
						onClick: onClose,
						children: "Mégse"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-primary",
						disabled: !draft.name.trim(),
						onClick: () => onSave({
							...draft,
							name: draft.name.trim()
						}),
						children: "Mentés"
					})]
				})
			]
		})
	});
}
//#endregion
export { Page as component };
