import { i as __toESM } from "../_runtime.mjs";
import { T as require_react, w as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { C as parseDateKey, D as useAppStore, S as getDayStatus, _ as formatHours, c as WATER_QUICK, o as SKIN_CARE_ITEMS, s as SLEEP_QUICK, t as FOOD_ITEMS, v as formatLongDate, w as projectDayNumber, x as getDayChecks } from "./store-CuJQmbYj.mjs";
import { i as CardTitle, n as CardContent, r as CardHeader, t as Card } from "./card-ML3_y2lP.mjs";
import { _ as Droplets, p as Moon } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { o as Button } from "./router-0AvkMag6.mjs";
import { t as Input } from "./input-Y7CKgdfM.mjs";
import { t as CheckItem } from "./check-item-DFFuMcWH.mjs";
import { t as Textarea } from "./textarea-CwJtXt2R.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/day-checklist-BPquXlsy.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DayChecklist({ date }) {
	const settings = useAppStore((s) => s.settings);
	const log = useAppStore((s) => s.logs[date]);
	const toggleSkinCare = useAppStore((s) => s.toggleSkinCare);
	const addWater = useAppStore((s) => s.addWater);
	const setWater = useAppStore((s) => s.setWater);
	const setSleep = useAppStore((s) => s.setSleep);
	const toggleFood = useAppStore((s) => s.toggleFood);
	const togglePostureHabit = useAppStore((s) => s.togglePostureHabit);
	const toggleWorkoutHabit = useAppStore((s) => s.toggleWorkoutHabit);
	const toggleExtraHabit = useAppStore((s) => s.toggleExtraHabit);
	const setDayNotes = useAppStore((s) => s.setDayNotes);
	const [customMl, setCustomMl] = (0, import_react.useState)("");
	const checks = getDayChecks(log, settings);
	const status = getDayStatus(log, settings);
	const water = log?.waterMl ?? 0;
	const waterPct = Math.min(100, Math.round(water / settings.waterGoalMl * 100));
	const sleep = log?.sleepHours ?? null;
	const sleepPct = sleep == null ? 0 : Math.min(100, Math.round(sleep / settings.sleepGoalHours * 100));
	const dayNum = projectDayNumber(parseDateKey(date));
	function ping(ok, label) {
		if (ok) toast.success(`${label} concluído`);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] font-medium tracking-[0.18em] text-primary uppercase",
				children: dayNum > 0 ? `Dia ${String(dayNum).padStart(2, "0")}` : "Fora do ciclo"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-semibold",
				children: formatLongDate(date)
			})] }),
			status === "complete" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "border-success/40 bg-success/8 p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-sm font-semibold text-success",
					children: "Dia concluído"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs text-muted-foreground",
					children: "Tudo marcado. Amanhã é só repetir o padrão."
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Treino" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
				className: "pt-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckItem, {
					checked: Boolean(log?.workout),
					label: "Treino do dia",
					onToggle: () => {
						const next = !log?.workout;
						toggleWorkoutHabit(date);
						ping(next, "Treino");
					}
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Postura" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
				className: "pt-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckItem, {
					checked: Boolean(log?.posture),
					label: "Rotina de postura",
					onToggle: () => {
						const next = !log?.posture;
						togglePostureHabit(date);
						ping(next, "Postura");
					}
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Skin care" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
				className: "space-y-0.5 pt-3",
				children: SKIN_CARE_ITEMS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckItem, {
					checked: Boolean(log?.skinCare[item.key]),
					label: item.label,
					onToggle: () => {
						const next = !log?.skinCare[item.key];
						toggleSkinCare(date, item.key);
						ping(next, item.label);
					}
				}, item.key))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Droplets, { className: "size-4 text-primary" }), " Hidratação"]
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "space-y-3 pt-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-end justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-mono text-2xl font-semibold tabular-nums",
							children: [
								water,
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-sm font-normal text-muted-foreground",
									children: [
										"/ ",
										settings.waterGoalMl,
										" ml"
									]
								})
							]
						}), checks.water ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-medium text-success",
							children: "Meta de água concluída"
						}) : null]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-2 overflow-hidden rounded-full bg-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-full rounded-full bg-primary transition-[width] duration-300",
							style: { width: `${waterPct}%` }
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [WATER_QUICK.map((ml) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "secondary",
							onClick: () => {
								addWater(date, ml);
								const next = water + ml;
								if (water < settings.waterGoalMl && next >= settings.waterGoalMl) toast.success("Meta de água concluída");
							},
							children: [
								"+",
								ml,
								" ml"
							]
						}, ml)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "ghost",
							onClick: () => addWater(date, -250),
							children: "−250"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "flex gap-2",
						onSubmit: (e) => {
							e.preventDefault();
							const n = Number(customMl);
							if (!Number.isFinite(n) || n <= 0) return;
							addWater(date, n);
							setCustomMl("");
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								inputMode: "numeric",
								placeholder: "Quantidade (ml)",
								value: customMl,
								onChange: (e) => setCustomMl(e.target.value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								variant: "outline",
								children: "Somar"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "ghost",
								onClick: () => setWater(date, 0),
								children: "Zerar"
							})
						]
					})
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "size-4 text-primary" }), " Sono"]
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "space-y-3 pt-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-mono text-2xl font-semibold tabular-nums",
						children: [
							formatHours(sleep),
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-sm font-normal text-muted-foreground",
								children: ["/ ", formatHours(settings.sleepGoalHours)]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-2 overflow-hidden rounded-full bg-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-full rounded-full bg-primary transition-[width] duration-300",
							style: { width: `${sleepPct}%` }
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: SLEEP_QUICK.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: sleep === h ? "default" : "secondary",
							onClick: () => {
								setSleep(date, h);
								if (h >= settings.sleepGoalHours) toast.success("Meta de sono concluída");
							},
							children: formatHours(h)
						}, h))
					})
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Alimentação" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
				className: "space-y-0.5 pt-3",
				children: FOOD_ITEMS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckItem, {
					checked: Boolean(log?.food[item.key]),
					label: item.label,
					onToggle: () => {
						const next = !log?.food[item.key];
						toggleFood(date, item.key);
						ping(next, "Alimentação");
					}
				}, item.key))
			})] }),
			settings.extraHabits.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Hábitos extras" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
				className: "space-y-0.5 pt-3",
				children: settings.extraHabits.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckItem, {
					checked: Boolean(log?.extraHabits[h.id]),
					label: h.name,
					onToggle: () => {
						const next = !log?.extraHabits[h.id];
						toggleExtraHabit(date, h.id);
						ping(next, h.name);
					}
				}, h.id))
			})] }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Observações" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
				className: "pt-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					value: log?.notes ?? "",
					onChange: (e) => setDayNotes(date, e.target.value),
					placeholder: "Como foi o dia — curto e direto."
				})
			})] })
		]
	});
}
//#endregion
export { DayChecklist as t };
