import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { i as usePlanner, k as cn } from "./router-CQnHyG8o.mjs";
import { a as EmptyCopy, d as fieldClass, i as ColorDot, l as Segmented, s as PageHeader } from "./primitives-DM2UCvsE.mjs";
import { n as uid } from "./id-capIYR7Y.mjs";
import { t as SortableList } from "./sortable-DqnUMi7n.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/notebook-B7-cEJ2F.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STYLES = [
	{
		value: "dotted",
		label: "Dotted"
	},
	{
		value: "lined",
		label: "Lined"
	},
	{
		value: "grid",
		label: "Grid"
	}
];
function NotebookView() {
	const notebooks = usePlanner((s) => s.notebooks);
	const pages = usePlanner((s) => s.pages);
	const addNotebook = usePlanner((s) => s.addNotebook);
	const updateNotebook = usePlanner((s) => s.updateNotebook);
	const deleteNotebook = usePlanner((s) => s.deleteNotebook);
	const addPage = usePlanner((s) => s.addPage);
	const updatePage = usePlanner((s) => s.updatePage);
	const deletePage = usePlanner((s) => s.deletePage);
	const setPages = usePlanner((s) => s.setPages);
	const accent = usePlanner((s) => s.theme.accent);
	const [bookId, setBookId] = (0, import_react.useState)(notebooks[0]?.id ?? "");
	const [pageId, setPageId] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!notebooks.some((book) => book.id === bookId)) setBookId(notebooks[0]?.id ?? "");
	}, [notebooks, bookId]);
	const book = notebooks.find((item) => item.id === bookId);
	const bookPages = pages.filter((page) => page.notebookId === bookId);
	const page = bookPages.find((item) => item.id === pageId) ?? bookPages[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			section: "notebook",
			title: "Notebook",
			lede: "Pages with room to think."
		}),
		notebooks.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyCopy, {
			title: "No notebooks yet",
			body: "Start one for field notes, letters, or a single idea."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 md:grid-cols-[14rem_1fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid content-start gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex gap-2 overflow-x-auto md:grid md:overflow-visible",
						children: notebooks.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							"aria-pressed": item.id === bookId,
							onClick: () => {
								setBookId(item.id);
								setPageId(null);
							},
							className: cn("flex h-11 shrink-0 items-center gap-2 rounded-full px-3 text-sm font-medium md:w-full md:justify-start", item.id === bookId ? "bg-blush text-ink" : "border border-line text-muted"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "size-2 rounded-full",
								style: { background: item.color }
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate",
								children: item.title
							})]
						}, item.id))
					}),
					book ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "hidden items-center gap-2 md:flex",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColorDot, {
							label: "Cover color",
							value: book.color,
							onChange: (color) => updateNotebook(book.id, { color })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "h-11 text-sm text-muted",
							onClick: () => {
								const prevBooks = notebooks;
								const prevPages = pages;
								deleteNotebook(book.id);
								toast("Notebook removed", { action: {
									label: "Undo",
									onClick: () => usePlanner.setState({
										notebooks: prevBooks,
										pages: prevPages
									})
								} });
							},
							children: "Remove notebook"
						})]
					}) : null,
					bookPages.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortableList, {
						items: bookPages,
						getId: (item) => item.id,
						onReorder: (next) => {
							const rest = pages.filter((item) => item.notebookId !== bookId);
							setPages([...rest, ...next]);
						},
						render: (item, grip) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: cn("flex items-center rounded-lg", page?.id === item.id && "bg-blush"),
							children: [grip, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setPageId(item.id),
								className: "h-11 min-w-0 flex-1 truncate px-1 text-left text-sm",
								children: item.title || "Untitled"
							})]
						})
					}) : null,
					book ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "h-11 rounded-full bg-blush px-4 text-sm font-medium",
						onClick: () => {
							const id = uid();
							addPage({
								id,
								notebookId: book.id,
								title: "New page",
								style: "dotted",
								content: "",
								updated: Date.now()
							});
							setPageId(id);
						},
						children: "New page"
					}) : null
				]
			}), book && page ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: page.title,
							"aria-label": "Page title",
							onChange: (event) => updatePage(page.id, {
								title: event.target.value,
								updated: Date.now()
							}),
							className: "h-11 min-w-0 flex-1 bg-transparent font-display text-2xl outline-none"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "h-11 text-sm text-muted",
							onClick: () => {
								const prev = pages;
								deletePage(page.id);
								setPageId(null);
								toast("Page removed", { action: {
									label: "Undo",
									onClick: () => usePlanner.setState({ pages: prev })
								} });
							},
							children: "Remove page"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segmented, {
						label: "Page style",
						value: page.style,
						options: STYLES,
						onChange: (style) => updatePage(page.id, { style })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: page.content,
						"aria-label": "Page",
						onChange: (event) => updatePage(page.id, {
							content: event.target.value,
							updated: Date.now()
						}),
						placeholder: "The page is yours.",
						className: cn("sheet w-full resize-none rounded-3xl border border-line bg-card px-4 py-4 font-display text-lg text-ink outline-none placeholder:text-muted", page.style === "dotted" && "paper-dotted", page.style === "lined" && "paper-lined", page.style === "grid" && "paper-grid")
					})
				]
			}) : book ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyCopy, {
				title: "No pages",
				body: "Add a page and choose dotted, lined, or grid."
			}) : null]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "mt-6 flex gap-2",
			onSubmit: (event) => {
				event.preventDefault();
				const data = new FormData(event.currentTarget);
				const title = String(data.get("title") ?? "").trim();
				if (!title) return;
				const id = uid();
				addNotebook({
					id,
					title,
					color: accent
				});
				addPage({
					id: uid(),
					notebookId: id,
					title: "First page",
					style: "dotted",
					content: "",
					updated: Date.now()
				});
				setBookId(id);
				setPageId(null);
				event.currentTarget.reset();
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				name: "title",
				placeholder: "New notebook",
				"aria-label": "New notebook",
				className: fieldClass
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "submit",
				className: "h-11 shrink-0 rounded-full bg-accent px-4 text-sm font-medium text-accent-fg",
				children: "Create"
			})]
		})
	] });
}
var SplitComponent = NotebookView;
//#endregion
export { SplitComponent as component };
