import { a as genderLabel, i as fullName, r as formatScore, t as candidateNoun } from "./calc-DDlXNlj6.mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/certificate-doc-BBvbW0tk.js
var import_jsx_runtime = require_jsx_runtime();
function Seal() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 88 88",
		className: "size-20 text-primary",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "44",
				cy: "44",
				r: "41",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "44",
				cy: "44",
				r: "35",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M44 18 L48 34 H64 L51 44 L56 60 L44 50 L32 60 L37 44 L24 34 H40 Z",
				fill: "currentColor"
			})
		]
	});
}
function CertificateDoc({ student }) {
	const name = fullName(student.lastName, student.firstName);
	const average = student.average ?? 0;
	const issued = student.certificateNumber;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "print-sheet relative mx-auto w-full max-w-[210mm] overflow-hidden rounded-lg bg-surface px-6 py-8 text-fg shadow-card sm:px-10 sm:py-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-3 rounded-md border border-primary/30" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-4 rounded-sm border border-primary/15" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "relative text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-lg leading-snug text-primary sm:text-xl",
						children: "الجمهورية الجزائرية الديمقراطية الشعبية"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs tracking-wide text-muted",
						children: "وزارة التربية الوطنية · ديوان امتحانات شهادة البكالوريا"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mt-4 h-px w-40 bg-primary/30" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-5 flex justify-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Seal, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display mt-3 text-3xl text-primary sm:text-4xl",
						children: "شهادة البكالوريا"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "للتعليم الثانوي العام والتكنولوجي"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mt-8 space-y-4 text-center font-display text-lg leading-relaxed sm:text-xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["يشهد وزير التربية الوطنية أن ", candidateNoun(student.gender)] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-2xl font-bold text-ink sm:text-3xl",
						children: name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-base text-muted sm:text-lg",
						children: [
							"المولود",
							student.gender === "female" ? "ة" : "",
							" بتاريخ ",
							student.birthDate,
							" بـ",
							student.birthPlace,
							" · ",
							genderLabel(student.gender)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"قد نجح",
						student.gender === "female" ? "ت" : "",
						" في امتحان شهادة البكالوريا",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
						"شعبة ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-bold text-primary",
							children: student.streamName
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-base sm:text-lg",
						children: student.sessionLabel
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "relative mx-auto mt-8 grid max-w-md grid-cols-2 gap-3 text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-md bg-surface-2/80 px-3 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-xs text-muted",
						children: "المعدل العام"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-1 font-display text-2xl tabular-nums text-primary",
						children: formatScore(average)
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-md bg-surface-2/80 px-3 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-xs text-muted",
						children: "التقدير"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-1 font-display text-2xl text-primary",
						children: student.mention ?? "—"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "relative mt-10 grid grid-cols-2 gap-4 text-sm text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["رقم التسجيل: ", student.examNumber] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1",
						children: ["رقم الشهادة: ", issued ?? "غير مُصدَرة"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1",
						children: [
							student.schoolName,
							" — ",
							student.wilaya
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-end",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["حررت في ", student.wilaya] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 font-display text-base text-fg",
						children: "الختم والإمضاء"
					})]
				})]
			})
		]
	});
}
//#endregion
export { CertificateDoc as t };
