import { i as __toESM } from "../_runtime.mjs";
import { T as require_react, w as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { D as useAppStore, E as toDateKey, a as SESSION_TYPE_LABEL, u as WEEKDAY_LABEL } from "./store-CuJQmbYj.mjs";
import { t as PageHeader } from "./page-header-ueGZTDza.mjs";
import { t as Card } from "./card-ML3_y2lP.mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { T as ArrowLeft, d as Pencil, l as Play } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as Route, o as Button } from "./router-0AvkMag6.mjs";
import { t as Textarea } from "./textarea-CwJtXt2R.mjs";
import { a as DialogHeader, c as WorkoutEditor, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, s as LiveExerciseCard, t as Dialog } from "./dialog-DZVhkm8j.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/treinos._day-EeKF9iPN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var VALID = [
	"segunda",
	"terca",
	"quarta",
	"quinta",
	"sexta",
	"sabado",
	"domingo"
];
function WorkoutDayPage() {
	const { day } = Route.useParams();
	const dayKey = day;
	const valid = VALID.includes(dayKey);
	const workout = useAppStore((s) => valid ? s.workouts[dayKey] : null);
	const active = useAppStore((s) => s.activeSession);
	const startSession = useAppStore((s) => s.startSession);
	const completeSet = useAppStore((s) => s.completeSet);
	const undoSet = useAppStore((s) => s.undoSet);
	const updateLiveExercise = useAppStore((s) => s.updateLiveExercise);
	const finishSession = useAppStore((s) => s.finishSession);
	const abandonSession = useAppStore((s) => s.abandonSession);
	const setSessionNotes = useAppStore((s) => s.setSessionNotes);
	const [editing, setEditing] = (0, import_react.useState)(false);
	const [finishOpen, setFinishOpen] = (0, import_react.useState)(false);
	const updateWorkoutExercise = useAppStore((s) => s.updateWorkoutExercise);
	const addWorkoutExercise = useAppStore((s) => s.addWorkoutExercise);
	const removeWorkoutExercise = useAppStore((s) => s.removeWorkoutExercise);
	const duplicateWorkoutExercise = useAppStore((s) => s.duplicateWorkoutExercise);
	const moveWorkoutExercise = useAppStore((s) => s.moveWorkoutExercise);
	const restoreWorkout = useAppStore((s) => s.restoreWorkout);
	if (!valid || !workout) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted-foreground",
		children: "Treino não encontrado."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		asChild: true,
		variant: "outline",
		className: "mt-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/treinos",
			children: "Voltar"
		})
	})] });
	const live = active?.dayKey === dayKey ? active : null;
	const totalSets = (live?.exercises ?? workout.exercises).reduce((a, e) => a + e.sets, 0);
	const doneSets = live ? live.exercises.reduce((a, e) => a + e.completedSets, 0) : 0;
	function start() {
		if (active && active.dayKey !== dayKey) {
			toast.error("Finalize a sessão em andamento antes de começar outra.");
			return;
		}
		startSession({
			date: toDateKey(/* @__PURE__ */ new Date()),
			dayKey,
			exercises: workout.exercises,
			type: workout.type,
			title: workout.title
		});
		setEditing(false);
		toast.success("Sessão iniciada");
	}
	function confirmFinish() {
		finishSession();
		setFinishOpen(false);
		toast.success("Sessão salva");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "animate-in fade-in duration-300",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				variant: "ghost",
				size: "sm",
				className: "-ml-2 mb-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/treinos",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, {}), " Semana"]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: WEEKDAY_LABEL[dayKey],
				title: SESSION_TYPE_LABEL[workout.type],
				subtitle: workout.subtitle,
				action: live ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: editing ? "secondary" : "outline",
					size: "sm",
					onClick: () => setEditing((v) => !v),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, {}),
						" ",
						editing ? "Fechar edição" : "Editar treino"
					]
				})
			}),
			live ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "mb-4 flex items-center justify-between gap-3 p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Sessão em andamento"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-mono text-lg font-semibold tabular-nums",
					children: [
						doneSets,
						"/",
						totalSets,
						" séries"
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						size: "sm",
						onClick: abandonSession,
						children: "Descartar"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						onClick: () => setFinishOpen(true),
						children: "Finalizar"
					})]
				})]
			}) : editing ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				className: "mb-4 w-full",
				size: "lg",
				onClick: start,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {}), " Iniciar sessão"]
			}),
			editing && !live ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorkoutEditor, {
				exercises: workout.exercises,
				handlers: {
					onUpdate: (id, patch) => updateWorkoutExercise(dayKey, id, patch),
					onAdd: () => addWorkoutExercise(dayKey),
					onRemove: (id) => removeWorkoutExercise(dayKey, id),
					onDuplicate: (id) => duplicateWorkoutExercise(dayKey, id),
					onMove: (id, dir) => moveWorkoutExercise(dayKey, id, dir),
					onRestore: () => restoreWorkout(dayKey)
				}
			}) : live ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-3",
				children: live.exercises.map((ex) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveExerciseCard, {
					exercise: ex,
					onCompleteSet: () => completeSet(ex.id),
					onUndoSet: () => undoSet(ex.id),
					onPatch: (patch) => updateLiveExercise(ex.id, patch)
				}, ex.id))
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-3",
				children: workout.exercises.map((ex) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-display font-semibold",
							children: ex.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: [
								ex.sets,
								" × ",
								ex.reps,
								ex.load ? ` · ${ex.load}` : "",
								" · descanso ",
								ex.restSec,
								"s"
							]
						}),
						ex.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-xs text-muted-foreground",
							children: ex.notes
						}) : null
					]
				}, ex.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: finishOpen,
				onOpenChange: setFinishOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Finalizar sessão" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "A sessão entra no histórico. Você pode acrescentar uma observação." })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value: live?.notes ?? "",
						onChange: (e) => setSessionNotes(e.target.value),
						placeholder: "Como foi o treino"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: () => setFinishOpen(false),
						children: "Voltar"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: confirmFinish,
						children: "Salvar sessão"
					})] })
				] })
			})
		]
	});
}
//#endregion
export { WorkoutDayPage as component };
