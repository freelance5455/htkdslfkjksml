import { i as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, q as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as Plus, i as Send, o as Menu, r as Trash2, t as X } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-1u_tCFTU.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function clip(text, max) {
	const t = text.trim();
	return t.length > max ? t.slice(0, max) : t;
}
var sendChat = createServerFn({ method: "POST" }).validator((input) => {
	if (!input || !Array.isArray(input.messages) || input.messages.length === 0) throw new Error("Send a message first.");
	const messages = input.messages.filter((m) => m && (m.role === "user" || m.role === "assistant") && typeof m.content === "string").slice(-16).map((m) => ({
		role: m.role,
		content: clip(m.content, 6e3)
	}));
	if (!messages.length || messages[messages.length - 1]?.role !== "user") throw new Error("The latest message must be from you.");
	return { messages };
}).handler(createSsrRpc("1f52bca271952cad5ff37d96814219878833f65591cf5b6efeb8abd49a80b0d9"));
var STORE = "bareline.threads.v1";
function uid() {
	return Math.random().toString(36).slice(2, 10);
}
function starter() {
	return {
		id: "start",
		title: "New chat",
		messages: [],
		updated: 0
	};
}
function loadThreads() {
	try {
		const raw = localStorage.getItem(STORE);
		if (!raw) return [];
		const parsed = JSON.parse(raw);
		return Array.isArray(parsed) ? parsed : [];
	} catch {
		return [];
	}
}
function titleFrom(text) {
	const line = text.replace(/\s+/g, " ").trim();
	return line.length > 42 ? `${line.slice(0, 42)}…` : line || "New chat";
}
function Bareline() {
	const [threads, setThreads] = (0, import_react.useState)(() => [starter()]);
	const [activeId, setActiveId] = (0, import_react.useState)("start");
	const [draft, setDraft] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const [rail, setRail] = (0, import_react.useState)(false);
	const [ready, setReady] = (0, import_react.useState)(false);
	const scroller = (0, import_react.useRef)(null);
	const box = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const existing = loadThreads();
		if (existing.length) {
			setThreads(existing);
			setActiveId(existing[0].id);
		}
		setReady(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		localStorage.setItem(STORE, JSON.stringify(threads));
	}, [threads, ready]);
	const active = (0, import_react.useMemo)(() => threads.find((t) => t.id === activeId) ?? threads[0], [threads, activeId]);
	(0, import_react.useEffect)(() => {
		scroller.current?.scrollTo({ top: scroller.current.scrollHeight });
	}, [active?.messages.length, busy]);
	function newChat() {
		const t = {
			id: uid(),
			title: "New chat",
			messages: [],
			updated: Date.now()
		};
		setThreads((prev) => [t, ...prev]);
		setActiveId(t.id);
		setError("");
		setRail(false);
		box.current?.focus();
	}
	function removeThread(id) {
		setThreads((prev) => {
			const next = prev.filter((t) => t.id !== id);
			if (!next.length) {
				const t = {
					id: uid(),
					title: "New chat",
					messages: [],
					updated: Date.now()
				};
				setActiveId(t.id);
				return [t];
			}
			if (id === activeId) setActiveId(next[0].id);
			return next;
		});
	}
	async function submit() {
		const text = draft.trim();
		if (!text || busy || !active) return;
		setDraft("");
		setError("");
		const userTurn = {
			role: "user",
			content: text
		};
		const history = [...active.messages, userTurn];
		setThreads((prev) => prev.map((t) => t.id === active.id ? {
			...t,
			title: t.messages.length === 0 ? titleFrom(text) : t.title,
			messages: history,
			updated: Date.now()
		} : t));
		setBusy(true);
		try {
			const result = await sendChat({ data: { messages: history } });
			if (!result.ok) {
				setError(result.error);
				return;
			}
			setThreads((prev) => prev.map((t) => t.id === active.id ? {
				...t,
				messages: [...history, {
					role: "assistant",
					content: result.text
				}],
				updated: Date.now()
			} : t));
		} catch (err) {
			setError(err instanceof Error ? err.message : "Something broke.");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-dvh bg-bg text-fg",
		children: [
			rail && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-label": "Close threads",
				className: "fixed inset-0 z-20 bg-black/50 md:hidden",
				onClick: () => setRail(false)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: `fixed inset-y-0 left-0 z-30 flex w-72 flex-col border-r border-line bg-surface transition-transform md:static md:translate-x-0 ${rail ? "translate-x-0" : "-translate-x-full"}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-2 px-4 py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-2xl leading-none tracking-tight",
							children: "Bareline"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-muted",
							children: "Direct answers. Nothing extra."
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "grid size-10 place-items-center rounded-full text-muted md:hidden",
							"aria-label": "Close menu",
							onClick: () => setRail(false),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 18 })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "px-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: newChat,
							className: "flex h-11 w-full items-center justify-center gap-2 rounded-full bg-accent font-medium text-accent-ink",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 16 }), "New chat"]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 flex-1 overflow-y-auto px-2 pb-4",
						children: threads.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `group mb-1 flex items-center rounded-xl ${t.id === active?.id ? "bg-surface-2" : "hover:bg-surface-2"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									setActiveId(t.id);
									setRail(false);
								},
								className: "min-h-11 flex-1 truncate px-3 text-left text-sm",
								children: t.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": "Delete chat",
								onClick: () => removeThread(t.id),
								className: "mr-1 grid size-9 place-items-center rounded-lg text-muted opacity-100 md:opacity-0 md:group-hover:opacity-100",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { size: 15 })
							})]
						}, t.id))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex min-w-0 flex-1 flex-col",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "flex h-14 items-center gap-2 border-b border-line px-3 md:px-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "grid size-11 place-items-center rounded-full md:hidden",
							"aria-label": "Open threads",
							onClick: () => setRail(true),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { size: 18 })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate font-medium",
							children: active?.title ?? "Bareline"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						ref: scroller,
						className: "flex-1 overflow-y-auto px-4 py-6 md:px-8",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto flex max-w-2xl flex-col gap-5",
							children: [
								active && active.messages.length === 0 && !busy && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "pt-10",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
											className: "font-display text-4xl leading-tight md:text-5xl",
											children: "Say it straight."
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-3 max-w-md text-muted",
											children: "Ask for a plan, a rewrite, a diagnosis, or working code. Bareline answers the question and stops."
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mt-8 flex flex-wrap gap-2",
											children: [
												"Rewrite this email so it is shorter and clearer.",
												"Explain why my React list re-renders on every keystroke.",
												"Draft a week of dinners from what's already in a fridge."
											].map((prompt) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => {
													setDraft(prompt);
													box.current?.focus();
												},
												className: "rounded-full border border-line bg-surface px-4 py-2 text-left text-sm text-muted hover:text-fg",
												children: prompt
											}, prompt))
										})
									]
								}),
								active?.messages.map((m, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
									className: m.role === "user" ? "ml-8" : "",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mb-1 text-xs uppercase tracking-wide text-muted",
										children: m.role === "user" ? "You" : "Bareline"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: `whitespace-pre-wrap rounded-2xl px-4 py-3 text-[15px] ${m.role === "user" ? "bg-surface-2" : "bg-surface"}`,
										children: m.content
									})]
								}, `${active.id}-${i}`)),
								busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted",
									children: "Writing…"
								}),
								error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-accent",
									children: error
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("form", {
						className: "border-t border-line px-3 py-3 md:px-8",
						onSubmit: (e) => {
							e.preventDefault();
							submit();
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto flex max-w-2xl items-end gap-2 rounded-2xl border border-line bg-surface p-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								ref: box,
								value: draft,
								rows: 1,
								placeholder: "Ask anything",
								onChange: (e) => setDraft(e.target.value),
								onKeyDown: (e) => {
									if (e.key === "Enter" && !e.shiftKey) {
										e.preventDefault();
										submit();
									}
								},
								className: "max-h-40 min-h-11 flex-1 resize-none bg-transparent px-2 py-2 text-[15px] outline-none placeholder:text-muted"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "submit",
								disabled: busy || !draft.trim(),
								"aria-label": "Send",
								className: "grid size-11 shrink-0 place-items-center rounded-xl bg-accent text-accent-ink disabled:opacity-40",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { size: 16 })
							})]
						})
					})
				]
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bareline, {});
}
//#endregion
export { Home as component };
