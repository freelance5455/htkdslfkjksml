import { i as __toESM, n as __exportAll } from "../_runtime.mjs";
import { a as AlertDialogDescription, c as AlertDialogTitle, d as require_jsx_runtime, i as AlertDialogContent, n as AlertDialogAction, o as AlertDialogOverlay, r as AlertDialogCancel, s as AlertDialogPortal, t as AlertDialog, u as require_react } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { a as Plus, c as House, d as Cpu, f as CircleArrowUp, i as ShieldCheck, l as FileText, m as ArchiveRestore, n as Table, o as Monitor, p as Boxes, r as StickyNote, s as Image, u as FileArchive } from "../_libs/lucide-react.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-7Ub0RgDY.js
var routes_7Ub0RgDY_exports = /* @__PURE__ */ __exportAll({ component: () => Home });
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var OS = {
	xp: {
		id: "xp",
		name: "Windows XP",
		edition: "Professional SP3",
		build: "2600",
		released: "2001",
		support: "Unsupported",
		note: "Extended support ended April 8, 2014. Microsoft later shipped a few out-of-band fixes."
	},
	vista: {
		id: "vista",
		name: "Windows Vista",
		edition: "Service Pack 2",
		build: "6002",
		released: "2007",
		support: "Unsupported",
		note: "Extended support ended April 11, 2017."
	},
	win7: {
		id: "win7",
		name: "Windows 7",
		edition: "Professional SP1",
		build: "7601",
		released: "2009",
		support: "Unsupported",
		note: "Extended support ended January 14, 2020. Paid ESU ended in January 2023."
	},
	win8: {
		id: "win8",
		name: "Windows 8",
		edition: "Pro",
		build: "9200",
		released: "2012",
		support: "Unsupported",
		note: "Support ended January 12, 2016. The supported move is the update to Windows 8.1."
	},
	win81: {
		id: "win81",
		name: "Windows 8.1",
		edition: "Pro",
		build: "9600",
		released: "2013",
		support: "Unsupported",
		note: "Extended support ended January 10, 2023."
	},
	win10: {
		id: "win10",
		name: "Windows 10",
		edition: "22H2",
		build: "19045",
		released: "2015",
		support: "ESU",
		note: "Consumer support ended October 14, 2025. Enrolled devices can still take Extended Security Updates and some out-of-band fixes."
	},
	win11: {
		id: "win11",
		name: "Windows 11",
		edition: "24H2",
		build: "26100",
		released: "2021",
		support: "Supported",
		note: "Current system on this record. Newer servicing builds stay on Windows 11."
	}
};
var UPDATE_OS = [
	"xp",
	"vista",
	"win7",
	"win8",
	"win81",
	"win10"
];
function osLabel(id) {
	const os = OS[id];
	return `${os.name} ${os.edition}`;
}
var FROM_XP = [
	"xp",
	"vista",
	"win7",
	"win8",
	"win81",
	"win10",
	"win11"
];
var FROM_7 = [
	"win7",
	"win8",
	"win81",
	"win10",
	"win11"
];
var FROM_10 = ["win10", "win11"];
var FRAMEWORKS = [
	{
		id: "net40",
		name: ".NET Framework 4.0",
		version: "4.0",
		publisher: "Microsoft",
		size: "48 MB",
		summary: "Last .NET Framework release that still installs on Windows XP. Many older line-of-business apps ask for it.",
		supports: FROM_XP
	},
	{
		id: "net481",
		name: ".NET Framework 4.8.1",
		version: "4.8.1",
		publisher: "Microsoft",
		size: "74 MB",
		summary: "Final .NET Framework. Desktop apps that were never moved to modern .NET still need it. Not for XP or Vista.",
		supports: FROM_7
	},
	{
		id: "net8",
		name: ".NET Desktop Runtime 8",
		version: "8.0",
		publisher: "Microsoft",
		size: "56 MB",
		summary: "Runtime for modern .NET desktop apps. .NET 8 reached end of support on November 10, 2026.",
		supports: FROM_10
	},
	{
		id: "net9",
		name: ".NET Runtime 9",
		version: "9.0",
		publisher: "Microsoft",
		size: "52 MB",
		summary: ".NET 9 also reached end of support on November 10, 2026. Keep it only for apps that still require that exact runtime.",
		supports: FROM_10
	},
	{
		id: "vcredist",
		name: "Visual C++ 2015–2022",
		version: "14.44",
		publisher: "Microsoft",
		size: "24 MB",
		summary: "Shared libraries for programs built with Visual Studio 2015 through 2022.",
		supports: FROM_7
	},
	{
		id: "vc2010",
		name: "Visual C++ 2010",
		version: "10.0 SP1",
		publisher: "Microsoft",
		size: "11 MB",
		summary: "Older redistributable still required by some XP-era installers and hardware tools.",
		supports: FROM_XP
	},
	{
		id: "directx",
		name: "DirectX End-User Runtime",
		version: "June 2010",
		publisher: "Microsoft",
		size: "96 MB",
		summary: "Legacy DirectX 9.0c components. Windows 10 and 11 already include DirectX 12; older games still look for this pack.",
		supports: FROM_XP
	},
	{
		id: "webview2",
		name: "WebView2 Runtime",
		version: "Evergreen",
		publisher: "Microsoft",
		size: "138 MB",
		summary: "Embedded Edge engine used by many desktop apps. Evergreen updates itself while the OS can still reach Microsoft.",
		supports: [
			"win7",
			"win81",
			"win10",
			"win11"
		]
	},
	{
		id: "winappsdk",
		name: "Windows App SDK",
		version: "1.6",
		publisher: "Microsoft",
		size: "42 MB",
		summary: "WinUI 3 and related APIs. Requires Windows 10 or Windows 11.",
		supports: FROM_10
	},
	{
		id: "xps",
		name: "XPS document components",
		version: "1.0",
		publisher: "Microsoft",
		size: "8 MB",
		summary: "Opens XPS files. Optional on Windows 10 and 11, where the feature is often off by default.",
		supports: [
			"win7",
			"win8",
			"win81",
			"win10",
			"win11"
		]
	}
];
var UPDATES = [
	{
		id: "xp-sp3",
		os: "xp",
		kb: "KB936929",
		title: "Windows XP Service Pack 3",
		released: "April 2008",
		severity: "Servicing",
		summary: "The last service pack. Later out-of-band fixes expect this base."
	},
	{
		id: "xp-ms17",
		os: "xp",
		kb: "KB4012598",
		title: "MS17-010 SMB security update",
		released: "May 2017",
		severity: "Critical",
		summary: "Out-of-band fix for the SMB vulnerability used by WannaCry. Microsoft published it for Windows XP after that system was already unsupported."
	},
	{
		id: "xp-bluekeep",
		os: "xp",
		kb: "KB4500331",
		title: "Remote Desktop Services (BlueKeep)",
		released: "May 2019",
		severity: "Critical",
		summary: "Out-of-band fix for CVE-2019-0708. Microsoft shipped it for Windows XP and Windows Server 2003, which were out of support."
	},
	{
		id: "vista-sp2",
		os: "vista",
		kb: "KB948465",
		title: "Windows Vista Service Pack 2",
		released: "May 2009",
		severity: "Servicing",
		summary: "Last service pack for Vista. Required before the later security-only fixes."
	},
	{
		id: "vista-ms17",
		os: "vista",
		kb: "KB4012598",
		title: "MS17-010 SMB security update",
		released: "May 2017",
		severity: "Critical",
		summary: "Same out-of-band WannaCry fix, packaged for Windows Vista after its end of support."
	},
	{
		id: "win7-ssu",
		os: "win7",
		kb: "KB4490628",
		title: "Servicing stack update",
		released: "March 2019",
		severity: "Servicing",
		summary: "Lets Windows 7 install later SHA-2 signed packages. Install this before newer rollups."
	},
	{
		id: "win7-sha2",
		os: "win7",
		kb: "KB4474419",
		title: "SHA-2 code signing support",
		released: "March 2019",
		severity: "Important",
		summary: "Adds SHA-2 signing support so Windows Update can still trust packages after Microsoft dropped SHA-1."
	},
	{
		id: "win7-ssu2",
		os: "win7",
		kb: "KB4484071",
		title: "Servicing stack update",
		released: "January 2019",
		severity: "Servicing",
		summary: "Earlier servicing stack that belongs in the same sequence as KB4474419 and KB4490628."
	},
	{
		id: "win81-update",
		os: "win81",
		kb: "KB2919355",
		title: "Windows 8.1 Update",
		released: "April 2014",
		severity: "Important",
		summary: "The required Windows 8.1 Update. Later rollups will not install without it."
	},
	{
		id: "win10-emudhra",
		os: "win10",
		kb: "KB5134125",
		title: "Distrust compromised eMudhra certificates",
		released: "October 26, 2026",
		severity: "Important",
		summary: "Out-of-band update for Windows 10 21H2 and 22H2. It removes trust in compromised certificate hierarchies on PCs that do not get automatic certificate updates."
	},
	{
		id: "win10-certs-2027",
		os: "win10",
		kb: "Servicing note",
		title: "Update certificates expire in 2027",
		released: "October 2026",
		severity: "Servicing",
		summary: "Microsoft has said update-signing certificates expire on May 17, 2027 and June 19, 2027. After that, unsupported Windows can no longer use Windows Update. Windows 10 on a still-serviced or ESU channel needs the July 2026 security update or later before June 19, 2027."
	}
];
var UPGRADES = [
	{
		id: "xp-7",
		from: "xp",
		to: "win7",
		kind: "Clean install",
		title: "Install Windows 7",
		detail: "Windows 7 setup does not upgrade XP in place. Programs have to be installed again on a real PC.",
		needsMemory: false,
		needsTpm: false
	},
	{
		id: "xp-10",
		from: "xp",
		to: "win10",
		kind: "Clean install",
		title: "Install Windows 10",
		detail: "There is no direct upgrade from XP. Copy files off the PC before a real install.",
		needsMemory: true,
		needsTpm: false
	},
	{
		id: "vista-7",
		from: "vista",
		to: "win7",
		kind: "In place",
		title: "Upgrade to Windows 7",
		detail: "Windows 7 supports an in-place upgrade from Vista when the language and edition match.",
		needsMemory: false,
		needsTpm: false
	},
	{
		id: "7-10",
		from: "win7",
		to: "win10",
		kind: "In place",
		title: "Upgrade to Windows 10",
		detail: "In-place upgrade can keep files. Match edition and language on the real installer.",
		needsMemory: true,
		needsTpm: false
	},
	{
		id: "7-11",
		from: "win7",
		to: "win11",
		kind: "Clean install",
		title: "Install Windows 11",
		detail: "Windows 11 has no in-place upgrade from Windows 7.",
		needsMemory: true,
		needsTpm: true
	},
	{
		id: "8-81",
		from: "win8",
		to: "win81",
		kind: "In place",
		title: "Update to Windows 8.1",
		detail: "The supported step off Windows 8. Later upgrade paths start at 8.1.",
		needsMemory: false,
		needsTpm: false
	},
	{
		id: "81-10",
		from: "win81",
		to: "win10",
		kind: "In place",
		title: "Upgrade to Windows 10",
		detail: "In-place upgrade from Windows 8.1.",
		needsMemory: true,
		needsTpm: false
	},
	{
		id: "10-11",
		from: "win10",
		to: "win11",
		kind: "In place",
		title: "Upgrade to Windows 11",
		detail: "In-place when the PC has a supported processor, TPM 2.0, and Secure Boot.",
		needsMemory: true,
		needsTpm: true
	}
];
function formatWhen(iso) {
	return new Intl.DateTimeFormat(void 0, {
		month: "short",
		day: "numeric",
		year: "numeric"
	}).format(new Date(iso));
}
function uid(prefix) {
	return `${prefix}-${Math.random().toString(36).slice(2, 8)}`;
}
function frameworkName(id) {
	return FRAMEWORKS.find((item) => item.id === id)?.name ?? id;
}
function updateName(id) {
	const item = UPDATES.find((update) => update.id === id);
	return item ? `${item.kb} · ${item.title}` : id;
}
var seed = {
	machineName: "Desk",
	currentOs: "win11",
	previousOs: "win10",
	files: [
		{
			id: "f-notes",
			name: "Quarterly notes.txt",
			path: "C:\\Users\\Public\\Documents\\Quarterly notes.txt",
			kind: "note",
			size: "4 KB",
			modifiedAt: "2026-11-08T15:00:00.000Z",
			body: "Router closet still runs the old image. Keep the Windows 10 backup until the desk finishes the 11 upgrade. Do not delete the XP recovery disc in the drawer."
		},
		{
			id: "f-sheet",
			name: "House inventory.xlsx",
			path: "C:\\Users\\Public\\Documents\\House inventory.xlsx",
			kind: "sheet",
			size: "86 KB",
			modifiedAt: "2026-10-29T15:00:00.000Z",
			body: "Sheet: rooms, serial numbers, and which PC last opened the file. The den desktop is the one Eframe is tracking."
		},
		{
			id: "f-photo",
			name: "Porch scan.png",
			path: "C:\\Users\\Public\\Pictures\\Porch scan.png",
			kind: "image",
			size: "2.4 MB",
			modifiedAt: "2026-09-14T15:00:00.000Z",
			body: "A flat scan of the porch, saved from Photos. No edit history beyond the crop on September 14."
		},
		{
			id: "f-zip",
			name: "Drivers-2019.zip",
			path: "C:\\Users\\Public\\Downloads\\Drivers-2019.zip",
			kind: "archive",
			size: "140 MB",
			modifiedAt: "2019-06-02T15:00:00.000Z",
			body: "Chipset and audio drivers packed before the Windows 10 install. Leave the archive intact if you restore that system."
		}
	],
	apps: [
		{
			id: "explorer",
			name: "File Explorer",
			publisher: "Microsoft",
			openedAt: "2026-11-11T18:00:00.000Z",
			running: false
		},
		{
			id: "edge",
			name: "Microsoft Edge",
			publisher: "Microsoft",
			openedAt: "2026-11-12T14:00:00.000Z",
			running: true
		},
		{
			id: "notepad",
			name: "Notepad",
			publisher: "Microsoft",
			openedAt: "2026-11-08T15:10:00.000Z",
			running: false
		},
		{
			id: "photos",
			name: "Photos",
			publisher: "Microsoft",
			openedAt: "2026-09-14T16:00:00.000Z",
			running: false
		},
		{
			id: "terminal",
			name: "Terminal",
			publisher: "Microsoft",
			openedAt: "2026-08-02T12:00:00.000Z",
			running: false
		},
		{
			id: "mail",
			name: "Mail",
			publisher: "Microsoft",
			openedAt: "2026-11-01T09:00:00.000Z",
			running: false
		}
	],
	frameworks: [
		"net481",
		"vcredist",
		"directx",
		"webview2"
	],
	updates: {},
	backups: [{
		id: "bk-before-11",
		name: "Before Windows 11",
		createdAt: "2025-10-20T12:00:00.000Z",
		os: "win10",
		previous: "win81",
		frameworks: [
			"net481",
			"vcredist",
			"directx",
			"webview2"
		],
		updates: {}
	}],
	log: [
		{
			id: "l1",
			at: "2021-10-05T12:00:00.000Z",
			text: "Installed Windows 10 22H2."
		},
		{
			id: "l2",
			at: "2025-10-20T12:00:00.000Z",
			text: "Saved backup “Before Windows 11”."
		},
		{
			id: "l3",
			at: "2025-11-02T12:00:00.000Z",
			text: "Upgraded to Windows 11 24H2. Previous system is Windows 10."
		}
	]
};
function withLog(state, text) {
	return { log: [{
		id: uid("log"),
		at: (/* @__PURE__ */ new Date()).toISOString(),
		text
	}, ...state.log].slice(0, 16) };
}
var useEframe = create()(persist((set) => ({
	...seed,
	rename: (name) => set({ machineName: name.trim() || "Desk" }),
	touchFile: (id) => set((state) => ({
		files: state.files.map((file) => file.id === id ? {
			...file,
			modifiedAt: (/* @__PURE__ */ new Date()).toISOString()
		} : file),
		...withLog(state, `Opened ${state.files.find((file) => file.id === id)?.name ?? "a file"}.`)
	})),
	addFile: ({ name, kind }) => set((state) => {
		const clean = name.trim() || "Untitled";
		return {
			files: [{
				id: uid("file"),
				name: clean,
				path: `C:\\Users\\Public\\Documents\\${clean}`,
				kind,
				size: "1 KB",
				modifiedAt: (/* @__PURE__ */ new Date()).toISOString(),
				body: "Added on this PC record. Nothing has been written to a real disk."
			}, ...state.files],
			...withLog(state, `Added ${clean}.`)
		};
	}),
	removeFile: (id) => set((state) => ({
		files: state.files.filter((file) => file.id !== id),
		...withLog(state, `Removed ${state.files.find((file) => file.id === id)?.name ?? "a file"} from recent files.`)
	})),
	launchApp: (id) => set((state) => ({
		apps: state.apps.map((app) => app.id === id ? {
			...app,
			running: true,
			openedAt: (/* @__PURE__ */ new Date()).toISOString()
		} : app),
		...withLog(state, `Launched ${state.apps.find((app) => app.id === id)?.name ?? "an app"}.`)
	})),
	quitApp: (id) => set((state) => ({
		apps: state.apps.map((app) => app.id === id ? {
			...app,
			running: false
		} : app),
		...withLog(state, `Closed ${state.apps.find((app) => app.id === id)?.name ?? "an app"}.`)
	})),
	addApp: (name) => set((state) => {
		const clean = name.trim();
		if (!clean) return state;
		return {
			apps: [{
				id: uid("app"),
				name: clean,
				publisher: "Installed on this record",
				openedAt: (/* @__PURE__ */ new Date()).toISOString(),
				running: false
			}, ...state.apps],
			...withLog(state, `Added ${clean} to recent apps.`)
		};
	}),
	installFramework: (id) => set((state) => ({
		frameworks: state.frameworks.includes(id) ? state.frameworks : [...state.frameworks, id],
		...withLog(state, `Installed ${frameworkName(id)}.`)
	})),
	removeFramework: (id) => set((state) => ({
		frameworks: state.frameworks.filter((item) => item !== id),
		...withLog(state, `Removed ${frameworkName(id)}.`)
	})),
	trackUpdate: (id, status) => set((state) => ({
		updates: {
			...state.updates,
			[id]: status
		},
		...withLog(state, status === "installed" ? `Installed ${updateName(id)}.` : `Saved ${updateName(id)} to the plan.`)
	})),
	clearUpdate: (id) => set((state) => {
		const updates = { ...state.updates };
		delete updates[id];
		return {
			updates,
			...withLog(state, `Cleared ${updateName(id)}.`)
		};
	}),
	createBackup: (name) => set((state) => {
		const image = {
			id: uid("bk"),
			name: name.trim() || "Manual backup",
			createdAt: (/* @__PURE__ */ new Date()).toISOString(),
			os: state.currentOs,
			previous: state.previousOs,
			frameworks: [...state.frameworks],
			updates: { ...state.updates }
		};
		return {
			backups: [image, ...state.backups],
			...withLog(state, `Saved backup “${image.name}”.`)
		};
	}),
	deleteBackup: (id) => set((state) => ({
		backups: state.backups.filter((backup) => backup.id !== id),
		...withLog(state, "Deleted a backup image.")
	})),
	restoreBackup: (id) => set((state) => {
		const image = state.backups.find((backup) => backup.id === id);
		if (!image) return state;
		return {
			currentOs: image.os,
			previousOs: image.previous,
			frameworks: [...image.frameworks],
			updates: { ...image.updates },
			...withLog(state, `Restored backup “${image.name}”.`)
		};
	}),
	restorePrevious: () => set((state) => {
		if (!state.previousOs) return state;
		const nextCurrent = state.previousOs;
		const nextPrevious = state.currentOs;
		return {
			currentOs: nextCurrent,
			previousOs: nextPrevious,
			...withLog(state, `Restored ${osLabel(nextCurrent)}. ${osLabel(nextPrevious)} is now the previous system.`)
		};
	}),
	upgradeTo: (os, label) => set((state) => ({
		previousOs: state.currentOs,
		currentOs: os,
		...withLog(state, `${label}. Previous system kept for restore.`)
	})),
	reset: () => set({
		...seed,
		log: [...seed.log]
	})
}), { name: "eframe-record" }));
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function Button({ variant = "primary", className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		className: cn("inline-flex h-11 items-center justify-center gap-2 rounded-lg px-4 text-sm font-medium transition-opacity duration-150 disabled:pointer-events-none disabled:opacity-40", variant === "primary" && "bg-accent text-ink hover:opacity-90", variant === "quiet" && "border border-line bg-raised text-fg hover:opacity-90", variant === "danger" && "border border-line bg-transparent text-danger hover:opacity-90", className),
		...props
	});
}
function Panel({ title, aside, children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: cn("rounded-3xl border border-line bg-surface p-4", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 flex items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-base font-medium text-fg",
				children: title
			}), aside]
		}), children]
	});
}
function Badge({ tone = "muted", children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex h-6 items-center rounded-md px-2 text-xs font-medium", tone === "muted" && "bg-raised text-muted", tone === "ok" && "bg-raised text-ok", tone === "danger" && "bg-raised text-danger", tone === "solid" && "bg-accent text-ink"),
		children
	});
}
function Field({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-w-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-xs text-faint",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "text-sm break-words text-fg",
			children: value
		})]
	});
}
function ProgressMeter({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-2 flex items-center justify-between gap-3 text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-fg",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "tabular-nums text-muted",
			children: [Math.round(value), "%"]
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-1.5 overflow-hidden rounded-full bg-raised",
		role: "progressbar",
		"aria-valuenow": Math.round(value),
		"aria-valuemin": 0,
		"aria-valuemax": 100,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "h-full bg-accent",
			style: { width: `${Math.max(0, Math.min(100, value))}%` }
		})
	})] });
}
function useConfirm() {
	const [ask, setAsk] = (0, import_react.useState)(null);
	return {
		confirm: (next) => setAsk(next),
		dialog: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
			open: ask !== null,
			onOpenChange: (open) => !open && setAsk(null),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogOverlay, { className: "fixed inset-0 z-40 bg-canvas/80" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, {
				className: "fixed top-1/2 left-1/2 z-50 w-11/12 max-w-md -translate-x-1/2 -translate-y-1/2 rounded-3xl border border-line bg-surface p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, {
						className: "text-lg font-medium text-fg",
						children: ask?.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, {
						className: "mt-2 text-sm text-muted",
						children: ask?.body
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 flex flex-wrap justify-end gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "quiet",
								type: "button",
								children: "Cancel"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: ask?.danger ? "danger" : "primary",
								type: "button",
								onClick: () => ask?.run(),
								children: ask?.confirm ?? "Continue"
							})
						})]
					})
				]
			})] })
		})
	};
}
function useJob() {
	const [job, setJob] = (0, import_react.useState)(null);
	const timer = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		return () => {
			if (timer.current) window.clearInterval(timer.current);
		};
	}, []);
	function start(label, done) {
		if (timer.current) window.clearInterval(timer.current);
		setJob({
			label,
			progress: 8
		});
		timer.current = window.setInterval(() => {
			setJob((current) => {
				if (!current) return current;
				const progress = Math.min(100, current.progress + 8 + Math.round(Math.random() * 10));
				if (progress >= 100) {
					if (timer.current) window.clearInterval(timer.current);
					timer.current = null;
					window.setTimeout(done, 0);
					return null;
				}
				return {
					label: current.label,
					progress
				};
			});
		}, 160);
	}
	return {
		job,
		busy: job !== null,
		start
	};
}
function BackupView() {
	const currentOs = useEframe((state) => state.currentOs);
	const previousOs = useEframe((state) => state.previousOs);
	const backups = useEframe((state) => state.backups);
	const log = useEframe((state) => state.log);
	const createBackup = useEframe((state) => state.createBackup);
	const deleteBackup = useEframe((state) => state.deleteBackup);
	const restoreBackup = useEframe((state) => state.restoreBackup);
	const restorePrevious = useEframe((state) => state.restorePrevious);
	const reset = useEframe((state) => state.reset);
	const [name, setName] = (0, import_react.useState)("");
	const { job, busy, start } = useJob();
	const { confirm, dialog } = useConfirm();
	const previous = previousOs ? OS[previousOs] : null;
	const current = OS[currentOs];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			dialog,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Backup and restore"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-medium tracking-tight",
					children: "The system before this one"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-2xl text-sm text-muted",
					children: "Eframe keeps the operating system this record replaced, plus backup images of frameworks and updates. Restoring changes the record. It does not rewrite a disk."
				})
			] }),
			job ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressMeter, {
				label: job.label,
				value: job.progress
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: previous ? previous.name : "No previous system",
				aside: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					tone: "solid",
					children: "Before this OS"
				}),
				children: previous && previousOs ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: previous.note
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-4 grid grid-cols-2 gap-3 text-sm sm:grid-cols-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-xs text-faint",
								children: "Edition"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: previous.edition })] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-xs text-faint",
								children: "Build"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "tabular-nums",
								children: previous.build
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-xs text-faint",
								children: "Support"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: previous.support })] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-xs text-faint",
								children: "Now running"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: current.name })] })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							disabled: busy,
							onClick: () => confirm({
								title: `Restore ${previous.name}?`,
								body: `${osLabel(currentOs)} becomes the previous system. ${osLabel(previousOs)} becomes the one this record is running. Frameworks that ${previous.name} cannot use stay listed, but you cannot install new copies of them until you switch back.`,
								confirm: "Restore",
								danger: true,
								run: () => start(`Restoring ${previous.name}`, () => restorePrevious())
							}),
							children: "Restore this operating system"
						})
					})
				] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "This record has no system stored before the current one. Upgrade, or restore a backup that still has one."
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				title: "Backup images",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "mb-4 flex flex-col gap-2 sm:flex-row",
						onSubmit: (event) => {
							event.preventDefault();
							const label = name.trim() || `Backup of ${current.name}`;
							start(`Saving ${label}`, () => {
								createBackup(label);
								setName("");
							});
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: name,
							onChange: (event) => setName(event.target.value),
							placeholder: `Backup of ${current.name}`,
							className: "h-11 min-w-0 flex-1 rounded-lg border border-line bg-raised px-3 text-sm text-fg"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							disabled: busy,
							children: "Save backup"
						})]
					}),
					backups.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "No images yet."
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "flex flex-col gap-2",
						children: backups.map((backup) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "rounded-lg bg-raised p-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-start justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-medium text-fg",
										children: backup.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs text-faint",
										children: [
											formatWhen(backup.createdAt),
											" · ",
											osLabel(backup.os),
											backup.previous ? ` · before that, ${OS[backup.previous].name}` : ""
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										variant: "quiet",
										disabled: busy,
										onClick: () => confirm({
											title: `Restore “${backup.name}”?`,
											body: `The running system becomes ${osLabel(backup.os)}. Installed frameworks and the update plan are replaced with this image. Recent files stay.`,
											confirm: "Restore image",
											danger: true,
											run: () => start(`Restoring ${backup.name}`, () => restoreBackup(backup.id))
										}),
										children: "Restore"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										variant: "danger",
										disabled: busy,
										onClick: () => confirm({
											title: `Delete “${backup.name}”?`,
											body: "The image is removed from this record. The running system is left as it is.",
											confirm: "Delete",
											danger: true,
											run: () => deleteBackup(backup.id)
										}),
										children: "Delete"
									})]
								})]
							})
						}, backup.id))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				title: "History",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex flex-col gap-2",
					children: log.map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex flex-wrap items-baseline justify-between gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: entry.text }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-faint",
							children: formatWhen(entry.at)
						})]
					}, entry.id))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "quiet",
						onClick: () => confirm({
							title: "Reset this record?",
							body: "Returns the sample desk: Windows 11 running, Windows 10 previous, and the original files, apps, and backup.",
							confirm: "Reset",
							danger: true,
							run: () => reset()
						}),
						children: "Reset record"
					})
				})]
			})
		]
	});
}
function FrameworksView() {
	const currentOs = useEframe((state) => state.currentOs);
	const installed = useEframe((state) => state.frameworks);
	const installFramework = useEframe((state) => state.installFramework);
	const removeFramework = useEframe((state) => state.removeFramework);
	const { job, busy, start } = useJob();
	const [query, setQuery] = (0, import_react.useState)("");
	const [onlyFit, setOnlyFit] = (0, import_react.useState)(false);
	const rows = (0, import_react.useMemo)(() => {
		const needle = query.trim().toLowerCase();
		return FRAMEWORKS.filter((item) => {
			if (onlyFit && !item.supports.includes(currentOs)) return false;
			if (!needle) return true;
			return `${item.name} ${item.version} ${item.summary}`.toLowerCase().includes(needle);
		});
	}, [
		currentOs,
		onlyFit,
		query
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Frameworks"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
					className: "text-2xl font-medium tracking-tight",
					children: ["Runtimes for ", OS[currentOs].name]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-2xl text-sm text-muted",
					children: "Install or remove the frameworks this record is allowed to use. A package stays listed when you change operating systems, and is blocked if that system cannot run it."
				})
			] }),
			job ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressMeter, {
				label: job.label,
				value: job.progress
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2 sm:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: query,
					onChange: (event) => setQuery(event.target.value),
					placeholder: "Search frameworks",
					className: "h-11 min-w-0 flex-1 rounded-lg border border-line bg-surface px-3 text-sm text-fg"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: onlyFit ? "primary" : "quiet",
					onClick: () => setOnlyFit((value) => !value),
					children: onlyFit ? "Showing fits" : "Fits this system"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3",
				children: [rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
					title: "Nothing matches",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Clear the search or turn off the filter."
					})
				}) : null, rows.map((item) => {
					const on = installed.includes(item.id);
					const fits = item.supports.includes(currentOs);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
						title: item.name,
						aside: on ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: "ok",
							children: "Installed"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: "Not installed" }),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: item.summary
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
								className: "mt-3 grid grid-cols-2 gap-2 text-sm sm:grid-cols-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-xs text-faint",
										children: "Version"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: item.version })] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-xs text-faint",
										children: "Publisher"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: item.publisher })] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-xs text-faint",
										children: "Download size"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "tabular-nums",
										children: item.size
									})] })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 flex flex-wrap items-center gap-2",
								children: [on ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: "danger",
									disabled: busy,
									onClick: () => start(`Removing ${item.name}`, () => removeFramework(item.id)),
									children: "Remove"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									disabled: busy || !fits,
									onClick: () => start(`Installing ${item.name}`, () => installFramework(item.id)),
									children: "Install"
								}), !fits ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-sm text-muted",
									children: [
										"Not supported on ",
										OS[currentOs].name,
										"."
									]
								}) : null]
							})
						]
					}, item.id);
				})]
			})
		]
	});
}
async function readHardware() {
	const nav = navigator;
	let architecture = "Not reported";
	let bitness = "";
	let model = "";
	let platformVersion = "";
	try {
		const high = await nav.userAgentData?.getHighEntropyValues?.([
			"architecture",
			"bitness",
			"model",
			"platformVersion"
		]);
		if (high?.architecture) architecture = high.architecture;
		if (high?.bitness) bitness = high.bitness;
		if (high?.model) model = high.model;
		if (high?.platformVersion) platformVersion = high.platformVersion;
	} catch {
		architecture = "Not reported";
	}
	const downlink = nav.connection?.downlink;
	const effective = nav.connection?.effectiveType;
	const link = downlink != null || effective ? [effective, downlink != null ? `${downlink} Mb/s` : null].filter(Boolean).join(" · ") : null;
	return {
		cores: nav.hardwareConcurrency || 0,
		memoryGb: typeof nav.deviceMemory === "number" ? nav.deviceMemory : null,
		platform: nav.userAgentData?.platform || nav.platform || "Unknown",
		architecture,
		bitness,
		model,
		platformVersion,
		brands: nav.userAgentData?.brands?.map((brand) => `${brand.brand} ${brand.version}`).join(", ") ?? "",
		ua: nav.userAgent,
		screen: `${window.screen.width} × ${window.screen.height}`,
		dpr: window.devicePixelRatio || 1,
		colorDepth: window.screen.colorDepth,
		languages: nav.languages?.join(", ") || nav.language || "Unknown",
		timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || "Unknown",
		touch: nav.maxTouchPoints || 0,
		online: nav.onLine,
		link
	};
}
var CpuChart = (0, import_react.lazy)(() => import("./cpu-chart-D-oMebsx.mjs").then((mod) => ({ default: mod.CpuChart })));
var KIND_ICON = {
	note: StickyNote,
	sheet: Table,
	image: Image,
	archive: FileArchive
};
function useLoad(running) {
	const runningRef = (0, import_react.useRef)(running);
	runningRef.current = running;
	const [points, setPoints] = (0, import_react.useState)(() => Array.from({ length: 32 }, () => 8));
	const [cores, setCores] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		const count = Math.min(navigator.hardwareConcurrency || 4, 16);
		let load = 10;
		const id = window.setInterval(() => {
			const target = 7 + runningRef.current * 11;
			load = Math.max(3, Math.min(97, load * .7 + target * .3 + (Math.random() - .48) * 5));
			const rounded = Math.round(load);
			setPoints((prev) => [...prev.slice(-31), rounded]);
			setCores(Array.from({ length: count }, (_, index) => {
				const wobble = Math.sin(Date.now() / 700 + index) * 7;
				return Math.max(2, Math.min(99, Math.round(load + wobble)));
			}));
		}, 1e3);
		return () => window.clearInterval(id);
	}, []);
	return {
		points,
		cores,
		load: points[points.length - 1] ?? 0
	};
}
function HomeView() {
	const machineName = useEframe((state) => state.machineName);
	const rename = useEframe((state) => state.rename);
	const currentOs = useEframe((state) => state.currentOs);
	const previousOs = useEframe((state) => state.previousOs);
	const files = useEframe((state) => state.files);
	const apps = useEframe((state) => state.apps);
	const touchFile = useEframe((state) => state.touchFile);
	const addFile = useEframe((state) => state.addFile);
	const removeFile = useEframe((state) => state.removeFile);
	const launchApp = useEframe((state) => state.launchApp);
	const quitApp = useEframe((state) => state.quitApp);
	const addApp = useEframe((state) => state.addApp);
	const log = useEframe((state) => state.log);
	const running = apps.filter((app) => app.running).length;
	const { points, cores, load } = useLoad(running);
	const [hardware, setHardware] = (0, import_react.useState)(null);
	const [openId, setOpenId] = (0, import_react.useState)(null);
	const [draftName, setDraftName] = (0, import_react.useState)(machineName);
	const [fileName, setFileName] = (0, import_react.useState)("");
	const [fileKind, setFileKind] = (0, import_react.useState)("note");
	const [appName, setAppName] = (0, import_react.useState)("");
	const [showFileForm, setShowFileForm] = (0, import_react.useState)(false);
	const [showAppForm, setShowAppForm] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setDraftName(machineName);
	}, [machineName]);
	(0, import_react.useEffect)(() => {
		let alive = true;
		readHardware().then((next) => {
			if (alive) setHardware(next);
		});
		return () => {
			alive = false;
		};
	}, []);
	const openFile = files.find((file) => file.id === openId) ?? null;
	const os = OS[currentOs];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Home"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "text-2xl font-medium tracking-tight text-fg",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "sr-only",
							htmlFor: "machine-name",
							children: "Computer name"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "machine-name",
							value: draftName,
							onChange: (event) => setDraftName(event.target.value),
							onBlur: () => rename(draftName),
							className: "w-full max-w-xs rounded-lg border border-transparent bg-transparent px-1 text-2xl font-medium tracking-tight text-fg hover:border-line focus:border-line"
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-fg",
						children: osLabel(currentOs)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-muted",
						children: previousOs ? `Previous system: ${OS[previousOs].name}` : "No previous system saved"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
					className: "lg:col-span-3",
					title: "Processor",
					aside: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-2 text-sm text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cpu, {
							className: "size-4",
							"aria-hidden": "true"
						}), "Live"]
					}),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-end justify-between gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-4xl font-medium tabular-nums tracking-tight text-fg",
								children: [load, "%"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "max-w-xs text-sm text-muted",
								children: "Load rises while apps on this record are running. The count of processors is what this browser reports."
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Suspense, {
							fallback: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-3 h-36 rounded-lg bg-raised" }),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CpuChart, { points })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 grid grid-cols-4 gap-2 sm:grid-cols-8",
							children: (cores.length ? cores : Array.from({ length: hardware?.cores || 4 }, () => 0)).map((value, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex h-16 items-end rounded-lg bg-raised px-1",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "w-full rounded-sm bg-fg/80",
										style: { height: `${Math.max(value, 4)}%` }
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-center text-xs tabular-nums text-faint",
									children: [value, "%"]
								})]
							}, index))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Logical processors",
									value: hardware ? String(hardware.cores || "Not reported") : "Reading"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Memory",
									value: hardware ? hardware.memoryGb != null ? `${hardware.memoryGb} GB reported` : "Not reported" : "Reading"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Architecture",
									value: hardware ? [hardware.architecture, hardware.bitness && `${hardware.bitness}-bit`].filter(Boolean).join(" · ") : "Reading"
								})
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
					className: "lg:col-span-2",
					title: "This computer",
					aside: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-2 text-sm text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Monitor, {
							className: "size-4",
							"aria-hidden": "true"
						}), "Browser"]
					}),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "grid grid-cols-2 gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Platform",
									value: hardware?.platform ?? "Reading"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "System on record",
									value: os.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Edition",
									value: os.edition
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Build",
									value: os.build
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Screen",
									value: hardware?.screen ?? "Reading"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Pixel ratio",
									value: hardware ? String(hardware.dpr) : "Reading"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Color depth",
									value: hardware ? `${hardware.colorDepth}-bit` : "Reading"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Touch points",
									value: hardware ? String(hardware.touch) : "Reading"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Languages",
									value: hardware?.languages ?? "Reading"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Time zone",
									value: hardware?.timezone ?? "Reading"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Network",
									value: hardware ? hardware.online ? hardware.link || "Online" : "Offline" : "Reading"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Model",
									value: hardware?.model || "Not exposed"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-xs leading-5 break-words text-faint",
							children: hardware?.ua ?? "Reading the user agent."
						}),
						hardware?.platformVersion ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-xs text-faint",
							children: ["Platform version ", hardware.platformVersion]
						}) : null,
						hardware?.brands ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-faint",
							children: hardware.brands
						}) : null
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
					title: "Recent apps",
					aside: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "quiet",
						type: "button",
						onClick: () => setShowAppForm((open) => !open),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
							className: "size-4",
							"aria-hidden": "true"
						}), "Add"]
					}),
					children: [showAppForm ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "mb-3 flex flex-col gap-2 sm:flex-row",
						onSubmit: (event) => {
							event.preventDefault();
							addApp(appName);
							setAppName("");
							setShowAppForm(false);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: appName,
							onChange: (event) => setAppName(event.target.value),
							placeholder: "Program name",
							className: "h-11 min-w-0 flex-1 rounded-lg border border-line bg-raised px-3 text-sm text-fg"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							children: "Save"
						})]
					}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "flex flex-col gap-2",
						children: apps.map((app) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-3 rounded-lg bg-raised px-3 py-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate text-sm text-fg",
										children: app.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "truncate text-xs text-faint",
										children: [
											app.publisher,
											" · ",
											formatWhen(app.openedAt)
										]
									})]
								}),
								app.running ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: "ok",
									children: "Running"
								}) : null,
								app.running ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "quiet",
									type: "button",
									onClick: () => quitApp(app.id),
									children: "Quit"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "quiet",
									type: "button",
									onClick: () => launchApp(app.id),
									children: "Open"
								})
							]
						}, app.id))
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
					title: "Recent files",
					aside: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "quiet",
						type: "button",
						onClick: () => setShowFileForm((open) => !open),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
							className: "size-4",
							"aria-hidden": "true"
						}), "Add"]
					}),
					children: [
						showFileForm ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							className: "mb-3 flex flex-col gap-2",
							onSubmit: (event) => {
								event.preventDefault();
								addFile({
									name: fileName,
									kind: fileKind
								});
								setFileName("");
								setShowFileForm(false);
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: fileName,
								onChange: (event) => setFileName(event.target.value),
								placeholder: "File name",
								className: "h-11 rounded-lg border border-line bg-raised px-3 text-sm text-fg"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap gap-2",
								children: [[
									"note",
									"sheet",
									"image",
									"archive"
								].map((kind) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: fileKind === kind ? "primary" : "quiet",
									onClick: () => setFileKind(kind),
									children: kind
								}, kind)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "submit",
									children: "Save"
								})]
							})]
						}) : null,
						files.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "No recent files on this record."
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "flex flex-col gap-2",
							children: files.map((file) => {
								const Icon = KIND_ICON[file.kind] ?? FileText;
								const selected = file.id === openId;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "rounded-lg bg-raised",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-3 px-3 py-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
												className: "size-4 shrink-0 text-muted",
												"aria-hidden": "true"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												className: "min-w-0 flex-1 text-left",
												onClick: () => {
													setOpenId(selected ? null : file.id);
													if (!selected) touchFile(file.id);
												},
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "truncate text-sm text-fg",
													children: file.name
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
													className: "truncate text-xs text-faint",
													children: [
														file.size,
														" · ",
														formatWhen(file.modifiedAt)
													]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												variant: "quiet",
												type: "button",
												onClick: () => removeFile(file.id),
												children: "Remove"
											})
										]
									}), selected && openFile ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "border-t border-line px-3 py-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-mono text-xs break-all text-faint",
											children: openFile.path
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-sm text-fg",
											children: openFile.body
										})]
									}) : null]
								}, file.id);
							})
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "Record",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex flex-col gap-2",
					children: log.slice(0, 6).map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex flex-wrap items-baseline justify-between gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-fg",
							children: entry.text
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-faint",
							children: formatWhen(entry.at)
						})]
					}, entry.id))
				})
			})
		]
	});
}
function UpdatesView({ onUpgrade }) {
	const currentOs = useEframe((state) => state.currentOs);
	const tracked = useEframe((state) => state.updates);
	const trackUpdate = useEframe((state) => state.trackUpdate);
	const clearUpdate = useEframe((state) => state.clearUpdate);
	const [os, setOs] = (0, import_react.useState)(currentOs === "win11" ? "win10" : currentOs);
	const { job, busy, start } = useJob();
	const selected = UPDATE_OS.includes(os) ? os : "win10";
	const rows = (0, import_react.useMemo)(() => UPDATES.filter((item) => item.os === selected), [selected]);
	const info = OS[selected];
	const matches = selected === currentOs;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Updates"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-medium tracking-tight",
					children: "Windows XP through 10"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 max-w-2xl text-sm text-muted",
					children: [
						"Microsoft updates for versions that are out of standard support, including the out-of-band fixes published after end of life. Eframe records the plan. The packages themselves come from the",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							className: "text-fg underline decoration-line underline-offset-2",
							href: "https://www.catalog.update.microsoft.com/",
							target: "_blank",
							rel: "noreferrer",
							children: "Microsoft Update Catalog"
						}),
						"."
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "Certificate cutoff in 2027",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Microsoft has said Windows Update certificates expire on May 17, 2027 and June 19, 2027. After those dates, unsupported Windows versions stop receiving updates entirely. Supported releases need a recent cumulative update before then. Everything older needs an upgrade."
				})
			}),
			job ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressMeter, {
				label: job.label,
				value: job.progress
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2 overflow-x-auto pb-1",
				children: UPDATE_OS.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: selected === id ? "primary" : "quiet",
					onClick: () => setOs(id),
					children: OS[id].name.replace("Windows ", "")
				}, id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					info.note,
					" ",
					matches ? "This record is running that system, so packages can be marked installed." : `This record is running ${OS[currentOs].name}, so these stay on the plan until that system is restored.`
				]
			}),
			selected === "win8" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				title: "No servicing left for Windows 8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Windows 8 itself has no current Microsoft security updates. The supported move is the in-place update to Windows 8.1, which then has its own package."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						onClick: onUpgrade,
						children: "Open upgrades"
					})
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3",
				children: rows.map((item) => {
					const state = tracked[item.id];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
						title: item.title,
						aside: state === "installed" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: "ok",
							children: "Installed"
						}) : state === "planned" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: "Planned" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: item.severity === "Critical" ? "danger" : "muted",
							children: item.severity
						}),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: item.summary
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-3 text-xs text-faint",
								children: [
									item.kb,
									" · ",
									item.released,
									" · ",
									OS[item.os].name
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 flex flex-wrap gap-2",
								children: [state === "installed" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: "quiet",
									disabled: busy,
									onClick: () => clearUpdate(item.id),
									children: "Remove from record"
								}) : matches ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									disabled: busy,
									onClick: () => start(`Installing ${item.kb}`, () => trackUpdate(item.id, "installed")),
									children: "Install on this PC"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									disabled: busy || state === "planned",
									onClick: () => start(`Saving ${item.kb}`, () => trackUpdate(item.id, "planned")),
									children: state === "planned" ? "On the plan" : "Save to plan"
								}), state === "planned" && matches ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									disabled: busy,
									onClick: () => start(`Installing ${item.kb}`, () => trackUpdate(item.id, "installed")),
									children: "Install on this PC"
								}) : null]
							})
						]
					}, item.id);
				})
			})
		]
	});
}
function UpgradesView() {
	const currentOs = useEframe((state) => state.currentOs);
	const upgradeTo = useEframe((state) => state.upgradeTo);
	const paths = UPGRADES.filter((item) => item.from === currentOs);
	const [hardware, setHardware] = (0, import_react.useState)(null);
	const [picked, setPicked] = (0, import_react.useState)("");
	const { job, busy, start } = useJob();
	const { confirm, dialog } = useConfirm();
	const path = paths.find((item) => item.id === picked) ?? paths[0];
	(0, import_react.useEffect)(() => {
		let alive = true;
		readHardware().then((next) => {
			if (alive) setHardware(next);
		});
		return () => {
			alive = false;
		};
	}, []);
	const memory = hardware?.memoryGb ?? null;
	const cores = hardware?.cores ?? 0;
	const memoryOk = !path?.needsMemory || memory == null || memory >= 4;
	const coresOk = cores === 0 || cores >= 2;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			dialog,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Upgrades"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
					className: "text-2xl font-medium tracking-tight",
					children: ["From ", OS[currentOs].name]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-2xl text-sm text-muted",
					children: "Paths Microsoft actually offered, marked in place or clean install. Applying one updates this record and keeps the system you leave as the previous operating system."
				})
			] }),
			job ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressMeter, {
				label: job.label,
				value: job.progress
			}) : null,
			paths.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "Nothing newer in this record",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [osLabel(currentOs), " is the newest system Eframe tracks. Restore an older one from Backup if you need a different path."]
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 lg:grid-cols-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-3 lg:col-span-3",
					children: paths.map((item) => {
						const on = item.id === path?.id;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setPicked(item.id),
							className: `rounded-3xl border p-4 text-left ${on ? "border-accent bg-raised" : "border-line bg-surface"}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-base font-medium",
										children: item.title
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										tone: item.kind === "In place" ? "ok" : "muted",
										children: item.kind
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-muted",
									children: item.detail
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2 text-xs text-faint",
									children: [
										OS[item.from].name,
										" to ",
										osLabel(item.to)
									]
								})
							]
						}, item.id);
					})
				}), path ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
					title: "Check",
					className: "lg:col-span-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "flex flex-col gap-3 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-start justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Two or more processors" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										tone: coresOk ? "ok" : "danger",
										children: cores ? `${cores} reported` : "Not reported"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-start justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "4 GB memory" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										tone: !path.needsMemory || memoryOk ? "ok" : "danger",
										children: !path.needsMemory ? "Not required" : memory == null ? "Not reported" : `${memory} GB`
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-start justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "TPM 2.0 and Secure Boot" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: path.needsTpm ? "Not visible here" : "Not required" })]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-xs text-faint",
							children: "A browser cannot see TPM, Secure Boot, or the real CPU model. Check those on the PC before a real installer."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "mt-4 w-full",
							type: "button",
							disabled: busy,
							onClick: () => confirm({
								title: path.title,
								body: `${path.detail} ${OS[currentOs].name} will be kept as the previous system so you can restore it.`,
								confirm: "Update this record",
								run: () => start(path.title, () => upgradeTo(path.to, path.title))
							}),
							children: "Update this record"
						})
					]
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "Every path",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex flex-col gap-2",
					children: UPGRADES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex flex-wrap items-baseline justify-between gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							OS[item.from].name,
							" to ",
							OS[item.to].name
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-faint",
							children: item.kind
						})]
					}, item.id))
				})
			})
		]
	});
}
var NAV = [
	{
		id: "home",
		label: "Home",
		icon: House
	},
	{
		id: "frameworks",
		label: "Frameworks",
		icon: Boxes
	},
	{
		id: "backup",
		label: "Backup",
		icon: ArchiveRestore
	},
	{
		id: "updates",
		label: "Updates",
		icon: ShieldCheck
	},
	{
		id: "upgrades",
		label: "Upgrades",
		icon: CircleArrowUp
	}
];
function EframeApp() {
	const [section, setSection] = (0, import_react.useState)("home");
	const currentOs = useEframe((state) => state.currentOs);
	const machineName = useEframe((state) => state.machineName);
	(0, import_react.useEffect)(() => {
		useEframe.persist.rehydrate();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-canvas text-fg md:grid md:grid-cols-[15rem_minmax(0,1fr)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "sticky top-0 hidden h-screen flex-col border-r border-line px-3 py-5 md:flex",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "px-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-lg font-medium tracking-tight",
							children: "Eframe"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-faint",
							children: machineName
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "mt-6 flex flex-col gap-1",
						"aria-label": "Sections",
						children: NAV.map((item) => {
							const Icon = item.icon;
							const on = section === item.id;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setSection(item.id),
								className: cn("flex h-11 items-center gap-3 rounded-lg px-3 text-left text-sm", on ? "bg-raised text-fg" : "text-muted"),
								"aria-current": on ? "page" : void 0,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
									className: "size-4",
									"aria-hidden": "true"
								}), item.label]
							}, item.id);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-auto px-2 text-xs text-faint",
						children: OS[currentOs].name
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 pb-24 md:pb-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "sticky top-0 z-10 flex items-center justify-between gap-3 border-b border-line bg-canvas px-4 py-3 md:px-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 md:hidden",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium",
								children: "Eframe"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-xs text-faint",
								children: NAV.find((item) => item.id === section)?.label
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "hidden text-sm text-muted md:block",
							children: "PC record"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "truncate text-sm text-fg",
							children: [OS[currentOs].name, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-faint",
								children: [" · ", OS[currentOs].edition]
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
					className: "px-4 py-5 md:px-8 md:py-6",
					children: [
						section === "home" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeView, {}) : null,
						section === "frameworks" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FrameworksView, {}) : null,
						section === "backup" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackupView, {}) : null,
						section === "updates" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UpdatesView, { onUpgrade: () => setSection("upgrades") }) : null,
						section === "upgrades" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UpgradesView, {}) : null
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-20 grid grid-cols-5 border-t border-line bg-canvas px-1 pt-1 pb-2 md:hidden",
				"aria-label": "Sections",
				children: NAV.map((item) => {
					const Icon = item.icon;
					const on = section === item.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setSection(item.id),
						className: cn("flex min-h-14 flex-col items-center justify-center gap-1 rounded-lg text-xs", on ? "text-fg" : "text-faint"),
						"aria-current": on ? "page" : void 0,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
							className: "size-5",
							"aria-hidden": "true"
						}), item.label]
					}, item.id);
				})
			})
		]
	});
}
function Home() {
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setReady(true), []);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "flex min-h-screen items-center justify-center bg-canvas px-6 text-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: "Eframe"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-1 text-2xl font-medium tracking-tight",
			children: "Opening the machine record"
		})] })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EframeApp, {});
}
//#endregion
export { Home as component, routes_7Ub0RgDY_exports as t };
