import { a as AlertDialogDescription, b as require_jsx_runtime, c as AlertDialogTitle, i as AlertDialogContent, n as AlertDialogAction, o as AlertDialogOverlay, r as AlertDialogCancel, s as AlertDialogPortal, t as AlertDialog } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { u as cn } from "./store-g4o8WGZx.mjs";
import { n as buttonVariants } from "./button-C77Erh3S.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/confirm-D8Ph184n.js
var import_jsx_runtime = require_jsx_runtime();
function Confirm({ open, onOpenChange, title, body, confirmLabel, onConfirm, destructive = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogOverlay, { className: "fixed inset-0 z-50 bg-black/60" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, {
			className: "fixed top-1/2 left-1/2 z-50 w-[min(100%-2rem,24rem)] -translate-x-1/2 -translate-y-1/2 rounded-3xl border border-border bg-card p-5 text-card-foreground",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, {
					className: "text-lg font-semibold",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, {
					className: "mt-2 text-sm leading-normal text-muted-foreground",
					children: body
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, {
						type: "button",
						className: cn(buttonVariants({ variant: "outline" }), "flex-1"),
						children: "إلغاء"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
						type: "button",
						className: cn(buttonVariants({ variant: destructive ? "destructive" : "default" }), "flex-1"),
						onClick: onConfirm,
						children: confirmLabel
					})]
				})
			]
		})] })
	});
}
//#endregion
export { Confirm as t };
