import { i as __toESM } from "../_runtime.mjs";
import { q as require_react, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as ScreenBody, t as AppShell } from "./app-shell-BNnfZJ-W.mjs";
import { i as ScreenHeader } from "./screen-header-3v0iR4cd.mjs";
import { t as cn } from "./utils-Cfx5sVK6.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/calculator-CKTBRanY.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var initialCalc = {
	display: "0",
	acc: null,
	op: null,
	fresh: true,
	error: null
};
function reduceCalc(state, key) {
	if (state.error && key !== "C") return reduceCalc(initialCalc, key);
	if (key === "C") return { ...initialCalc };
	if (key === "⌫") return backspace(state);
	if (key === ".") return decimal(state);
	if (key === "+" || key === "−" || key === "×" || key === "÷") return setOp(state, key);
	if (key === "=") return equals(state);
	if (/^\d$/.test(key)) return digit(state, key);
	return state;
}
function digit(state, d) {
	const next = state.fresh || state.display === "0" ? d : state.display + d;
	if (next.replace(".", "").replace("-", "").length > 12) return state;
	return {
		...state,
		display: next,
		fresh: false,
		error: null
	};
}
function decimal(state) {
	if (state.fresh) return {
		...state,
		display: "0.",
		fresh: false
	};
	if (state.display.includes(".")) return state;
	return {
		...state,
		display: state.display + ".",
		fresh: false
	};
}
function backspace(state) {
	if (state.fresh) return {
		...state,
		display: "0",
		fresh: true
	};
	const next = state.display.slice(0, -1);
	if (!next || next === "-") return {
		...state,
		display: "0",
		fresh: true
	};
	return {
		...state,
		display: next
	};
}
function setOp(state, op) {
	const current = Number(state.display);
	if (!Number.isFinite(current)) return {
		...state,
		error: "Invalid number"
	};
	let acc = current;
	if (state.acc !== null && state.op && !state.fresh) {
		const result = compute(state.acc, current, state.op);
		if (result === null) return {
			...state,
			error: "Cannot divide by zero"
		};
		acc = result;
	}
	return {
		...state,
		acc,
		op,
		display: formatNum(acc),
		fresh: true
	};
}
function equals(state) {
	if (!state.op || state.acc === null) return state;
	const current = Number(state.display);
	if (!Number.isFinite(current)) return {
		...state,
		error: "Invalid number"
	};
	const result = compute(state.acc, current, state.op);
	if (result === null) return {
		...state,
		error: "Cannot divide by zero"
	};
	return {
		display: formatNum(result),
		acc: result,
		op: null,
		fresh: true,
		error: null
	};
}
function compute(a, b, op) {
	if (op === "÷" && b === 0) return null;
	const raw = op === "+" ? a + b : op === "−" ? a - b : op === "×" ? a * b : a / b;
	return Number(raw.toPrecision(12));
}
function formatNum(value) {
	if (!Number.isFinite(value)) return "Error";
	const text = String(Number(value.toPrecision(12)));
	return text.length > 14 ? value.toExponential(6) : text;
}
var rows = [
	[
		"C",
		"÷",
		"×",
		"⌫"
	],
	[
		"7",
		"8",
		"9",
		"−"
	],
	[
		"4",
		"5",
		"6",
		"+"
	],
	[
		"1",
		"2",
		"3",
		"="
	]
];
function CalculatorPage() {
	const [state, setState] = (0, import_react.useState)(initialCalc);
	function press(key) {
		setState((prev) => reduceCalc(prev, key));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ScreenBody, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScreenHeader, {
			title: "Calculator",
			subtitle: "Basic arithmetic. Works fully offline."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-card bg-surface px-[18px] py-6 shadow-[var(--shadow-border)]",
			children: [state.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-1 text-right text-sm text-danger",
				children: state.error
			}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "truncate text-right text-4xl font-bold tabular-nums tracking-tight text-fg",
				children: state.display
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 flex flex-col gap-2.5",
			children: [rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-4 gap-2.5",
				children: row.map((key) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
					label: key,
					onPress: press
				}, key))
			}, row.join("-"))), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-4 gap-2.5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
						label: "0",
						onPress: press,
						className: "col-span-2 min-h-16"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyButton, {
						label: ".",
						onPress: press
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-key bg-surface/50",
						"aria-hidden": true
					})
				]
			})]
		})
	] }) });
}
function KeyButton({ label, onPress, className }) {
	const accent = label === "=";
	const op = [
		"÷",
		"×",
		"−",
		"+",
		"C",
		"⌫"
	].includes(label);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick: () => onPress(label),
		className: cn("min-h-16 rounded-key text-xl font-semibold transition-transform duration-150 ease-out active:scale-[0.96]", accent && "bg-primary text-bg", !accent && op && "bg-elevated", !accent && !op && "bg-surface text-fg shadow-[var(--shadow-border)]", label === "C" && "text-danger", op && label !== "C" && "text-primary", className),
		children: label
	});
}
//#endregion
export { CalculatorPage as component };
