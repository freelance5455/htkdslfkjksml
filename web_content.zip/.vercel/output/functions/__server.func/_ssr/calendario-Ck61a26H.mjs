import { w as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { a as format } from "../_libs/date-fns.mjs";
import { C as parseDateKey, D as useAppStore, E as toDateKey, S as getDayStatus, d as allProjectDates, f as cn, w as projectDayNumber } from "./store-CuJQmbYj.mjs";
import { t as PageHeader } from "./page-header-ueGZTDza.mjs";
import { t as Card } from "./card-ML3_y2lP.mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/calendario-Ck61a26H.js
var import_jsx_runtime = require_jsx_runtime();
var DOW = [
	"S",
	"T",
	"Q",
	"Q",
	"S",
	"S",
	"D"
];
function CalendarPage() {
	const logs = useAppStore((s) => s.logs);
	const settings = useAppStore((s) => s.settings);
	const dates = allProjectDates();
	const today = toDateKey(/* @__PURE__ */ new Date());
	const complete = dates.filter((d) => getDayStatus(logs[d], settings) === "complete").length;
	const partial = dates.filter((d) => getDayStatus(logs[d], settings) === "partial").length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "animate-in fade-in duration-300",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: "101 dias",
				title: "Calendário",
				subtitle: `${complete} completos · ${partial} parciais · ${101 - complete - partial} em aberto`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex flex-wrap gap-4 text-xs text-muted-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, {
						swatch: "bg-primary",
						label: "Dia completo"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, {
						swatch: "bg-primary/35",
						label: "Parcial"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, {
						swatch: "bg-muted",
						label: "Não registrado"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-2 grid grid-cols-7 gap-1 text-center text-[10px] tracking-wide text-muted-foreground uppercase",
					children: DOW.map((d, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: d }, `${d}-${i}`))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-7 gap-1.5",
					children: [offsetBlanks(dates[0]).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}, `b-${i}`)), dates.map((d) => {
						const status = getDayStatus(logs[d], settings);
						const n = projectDayNumber(parseDateKey(d));
						const isToday = d === today;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/dia/$date",
							params: { date: d },
							title: `${format(parseDateKey(d), "dd/MM")} · dia ${n}`,
							className: cn("flex aspect-square flex-col items-center justify-center rounded-lg text-[11px] font-medium tabular-nums transition-colors", status === "complete" && "bg-primary text-primary-foreground", status === "partial" && "bg-primary/30 text-foreground", status === "empty" && "bg-muted text-muted-foreground", isToday && "ring-2 ring-primary ring-offset-2 ring-offset-background"),
							children: n
						}, d);
					})]
				})]
			})
		]
	});
}
function offsetBlanks(first) {
	const mondayIndex = (parseDateKey(first).getDay() + 6) % 7;
	return Array.from({ length: mondayIndex });
}
function Legend({ swatch, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "inline-flex items-center gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-2.5 rounded-sm", swatch) }), label]
	});
}
//#endregion
export { CalendarPage as component };
