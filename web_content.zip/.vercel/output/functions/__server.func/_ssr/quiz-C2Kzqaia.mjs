//#region node_modules/.nitro/vite/services/ssr/assets/quiz-C2Kzqaia.js
var QUESTIONS = [
	[
		1,
		true,
		"La carreggiata è la parte della strada destinata alla circolazione dei veicoli.",
		"سطح السير هو جزء الطريق المخصّص لمرور المركبات.",
		"التعريف صحيح. الرصيف والكتف ليسا سطح السير."
	],
	[
		1,
		false,
		"La banchina è la corsia riservata al sorpasso veloce.",
		"كتف الطريق مسلك مخصّص للتجاوز السريع.",
		"الكتف هامش جانبي، وليس مسلك تجاوز."
	],
	[
		1,
		true,
		"La corsia è una banda della carreggiata sufficiente al transito di una fila di veicoli.",
		"المسلك شريط من سطح السير يكفي لصف واحد من المركبات.",
		"هذا هو تعريف المسلك."
	],
	[
		1,
		true,
		"Con la patente B si guidano autoveicoli fino a 3500 kg con non più di 8 passeggeri oltre il conducente.",
		"برخصة B تُقاد مركبات حتى 3500 كغ وبما لا يزيد على 8 ركّاب غير السائق.",
		"هذا حد فئة B."
	],
	[
		1,
		false,
		"Con la patente B si può sempre trainare un rimorchio di 2000 kg, qualunque sia la massa del complesso.",
		"برخصة B يمكن دائمًا جر مقطورة 2000 كغ مهما كان مجموع الوزن.",
		"إذا تجاوزت المقطورة 750 كغ يجب ألا يتخطى المجموع 3500 كغ."
	],
	[
		1,
		false,
		"I pedoni possono circolare in autostrada sul margine destro.",
		"يجوز للمشاة السير على الأوتوسترادا على الحافة اليمنى.",
		"المشاة ممنوعون على الأوتوسترادا."
	],
	[
		1,
		false,
		"Il ciclomotore può entrare in autostrada se non supera 45 km/h.",
		"الدراجة البخارية الصغيرة تدخل الأوتوسترادا إذا لم تتجاوز 45.",
		"المركبات البطيئة والدراجات البخارية الصغيرة ممنوعة على الأوتوسترادا."
	],
	[
		1,
		true,
		"Il passaggio a livello è l'incrocio fra una strada e una linea ferroviaria.",
		"المزلقان هو تلاقي طريق مع خط سكة حديد.",
		"تعريف صحيح."
	],
	[
		1,
		true,
		"Chi usa la strada deve comportarsi in modo da non creare pericolo o intralcio.",
		"مستخدم الطريق يتصرف بحيث لا يخلق خطرًا أو إعاقة.",
		"هذا الواجب العام."
	],
	[
		1,
		false,
		"Il marciapiede è destinato alla sosta delle autovetture.",
		"رصيف المشاة مخصّص لوقوف السيارات.",
		"الرصيف للمشاة. الوقوف عليه ممنوع كقاعدة."
	],
	[
		2,
		true,
		"I segnali di pericolo hanno di regola forma di triangolo con bordo rosso e fondo bianco.",
		"إشارات الخطر مثلث بحافة حمراء وخلفية بيضاء في العادة.",
		"هذا شكلها. مثلث الأولوية مقلوب وليس إشارة خطر."
	],
	[
		2,
		false,
		"Il segnale di dare precedenza è un segnale di pericolo.",
		"إشارة أعطِ الأولوية هي إشارة خطر.",
		"هي إشارة أولوية، ومثلثها مقلوب.",
		"dare"
	],
	[
		2,
		true,
		"Il segnale raffigurato preannuncia una curva pericolosa a destra.",
		"الإشارة المرسومة تنبّه إلى منحنى خطر نحو اليمين.",
		"رأس الانحناء يتجه يمينًا.",
		"curva-dx"
	],
	[
		2,
		false,
		"Il segnale raffigurato indica che la curva è già finita.",
		"الإشارة المرسومة تعني أن المنحنى انتهى.",
		"هي إنذار قبل الخطر لا إعلان نهايته.",
		"curva-sx"
	],
	[
		2,
		true,
		"In presenza del dosso la visibilità può essere limitata e il sorpasso è spesso pericoloso.",
		"عند المرتفع قد تقل الرؤية والتجاوز غالبًا خطر.",
		"لا تتجاوز إذا لم ترَ ما بعد القمة.",
		"dosso"
	],
	[
		2,
		true,
		"La croce di Sant'Andrea indica la vicinanza immediata dei binari.",
		"صليب سكة الحديد يدل على القرب المباشر من القضبان.",
		"توضع عند المزلقان نفسه.",
		"croce"
	],
	[
		2,
		false,
		"Il segnale di bambini obbliga a suonare il clacson in ogni caso.",
		"إشارة الأطفال تُلزم باستخدام البوق دائمًا.",
		"تدعو للحذر والتهدئة، لا للبوق.",
		"bambini"
	],
	[
		2,
		true,
		"Il segnale di altri pericoli va letto insieme all'eventuale pannello integrativo.",
		"إشارة أخطار أخرى تُقرأ مع اللوحة المكمّلة إن وُجدت.",
		"علامة التعجب لا تكفي وحدها لمعرفة نوع الخطر.",
		"altri"
	],
	[
		2,
		false,
		"Il segnale di lavori in corso di forma triangolare bianca è una segnalazione temporanea gialla.",
		"مثلث الأعمال الأبيض إشارة مؤقتة صفراء.",
		"المثلث الأبيض دائم الشكل. الأصفر هو المؤقت.",
		"lavori"
	],
	[
		2,
		true,
		"Il segnale raffigurato preannuncia un passaggio a livello con barriere.",
		"الإشارة تنبّه إلى مزلقان بحواجز.",
		"رسم الحاجز داخل المثلث.",
		"passaggio-barriere"
	],
	[
		3,
		true,
		"Il divieto di transito vieta il passaggio dei veicoli nei due sensi.",
		"ممنوع المرور يمنع المركبات في الاتجاهين.",
		"دائرة حمراء فارغة.",
		"transito"
	],
	[
		3,
		false,
		"Il senso vietato e il divieto di transito hanno lo stesso significato.",
		"اتجاه ممنوع وممنوع المرور لهما المعنى نفسه.",
		"اتجاه ممنوع قرص أحمر بشريط أبيض، ويمنع الدخول من تلك الجهة فقط.",
		"senso-vietato"
	],
	[
		3,
		true,
		"Il divieto di sosta consente ancora la fermata per la salita e la discesa dei passeggeri.",
		"ممنوع الوقوف ما زال يسمح بالتوقف لصعود الركّاب ونزولهم.",
		"الصليب فيه الأزرق. ممنوع التوقف هو الصليب الأحمر كله.",
		"sosta"
	],
	[
		3,
		false,
		"Il divieto di fermata consente la sosta se il conducente resta a bordo.",
		"ممنوع التوقف يسمح بالوقوف إذا بقي السائق داخل السيارة.",
		"ممنوع التوقف يمنع التوقف القصير والوقوف.",
		"fermata"
	],
	[
		3,
		true,
		"Il segnale raffigurato indica la fine del divieto di sorpasso.",
		"الإشارة المرسومة تعني نهاية منع التجاوز.",
		"الحافة سوداء والخط المائل يعني نهاية لا منعًا جديدًا.",
		"fine-sorpasso"
	],
	[
		3,
		false,
		"Un limite di velocità raffigurato in un cerchio rosso è una velocità minima.",
		"حد السرعة داخل دائرة حمراء هو سرعة دنيا.",
		"الدائرة الحمراء حد أقصى. الدنيا قرص أزرق.",
		"limite-50"
	],
	[
		3,
		true,
		"La fine di tutti i divieti locali precedenti non cancella i limiti generali di legge.",
		"نهاية الممنوعات المحلية لا تلغي الحدود العامة في القانون.",
		"تعود مثلًا حدود 50 أو 90 حسب نوع الطريق.",
		"fine-divieti"
	],
	[
		3,
		false,
		"Il divieto di segnalazioni acustiche autorizza il clacson per salutare.",
		"منع التنبيه الصوتي يسمح بالبوق للتحية.",
		"البوق يبقى لتجنّب خطر.",
		"clacson"
	],
	[
		3,
		true,
		"Il segnale raffigurato vieta l'inversione di marcia.",
		"الإشارة المرسومة تمنع الالتفاف للخلف.",
		"سهم الدوران مشطوب.",
		"inversione"
	],
	[
		3,
		false,
		"Il segnale di fine del limite di velocità istituisce un nuovo divieto.",
		"إشارة نهاية حد السرعة تنشئ منعًا جديدًا.",
		"تنهي ذلك الحد فقط.",
		"fine-limite-50"
	],
	[
		4,
		true,
		"I segnali di obbligo sono cerchi blu con simbolo bianco.",
		"إشارات الإلزام دوائر زرقاء برمز أبيض.",
		"اللون الأزرق هنا يأمر لا يُرشد فقط."
	],
	[
		4,
		true,
		"Il segnale raffigurato obbliga a proseguire diritto.",
		"الإشارة تُلزم بمتابعة الأمام.",
		"السهم للأعلى على القرص الأزرق.",
		"dritto"
	],
	[
		4,
		false,
		"Il segnale di velocità minima consente di non superarla ma obbliga a non scendere sotto il numero.",
		"إشارة السرعة الدنيا تمنع تجاوز الرقم وتُلزم بعدم النزول تحته.",
		"الجملة انقلبت: الدنيا تمنع النزول تحت الرقم، ولا تمنع تجاوزه.",
		"vmin-30"
	],
	[
		4,
		true,
		"Il segnale di rotatoria obbliga il senso di circolazione antiorario.",
		"إشارة الدوار تُلزم بالدوران عكس عقارب الساعة.",
		"الأسهم على القرص الأزرق.",
		"rotatoria"
	],
	[
		4,
		false,
		"Il segnale di rotatoria da solo dà sempre la precedenza a chi entra.",
		"إشارة الدوار وحدها تعطي دائمًا الأولوية لمن يدخل.",
		"الأولوية تأتي من إشارة أعطِ الأولوية المرافقة عادة، لا من القرص الأزرق وحده.",
		"rotatoria"
	],
	[
		4,
		true,
		"Il passaggio obbligatorio a destra si riferisce al lato da cui aggirare l'ostacolo.",
		"المرور الإجباري يمينًا يحدد الجهة التي تُدار منها العائق.",
		"السهم الأبيض يمين الحاجز.",
		"passaggio-dx"
	],
	[
		4,
		true,
		"Il segnale delle catene obbliga a avere catene montabili o pneumatici da neve.",
		"إشارة السلاسل تُلزم بوجود سلاسل قابلة للتركيب أو إطارات ثلج.",
		"تسري في المقطع المشار إليه.",
		"catene"
	],
	[
		4,
		false,
		"La pista ciclabile obbligatoria è un triangolo di pericolo.",
		"مسار الدراجات الإجباري مثلث خطر.",
		"هو قرص أزرق. المثلث مجرد إنذار بوجود درّاجين.",
		"bici-obb"
	],
	[
		4,
		true,
		"La freccia bianca a destra su disco blu obbliga a svoltare a destra.",
		"السهم الأبيض يمينًا على قرص أزرق يُلزم بالانعطاف يمينًا.",
		"لا يجوز إكمال الأمام.",
		"destra"
	],
	[
		4,
		false,
		"I segnali di obbligo hanno bordo rosso come i divieti.",
		"إشارات الإلزام حافتها حمراء مثل المنع.",
		"إلزام أزرق، ومنع بحافة حمراء."
	],
	[
		5,
		true,
		"Lo STOP obbliga all'arresto completo anche se la strada sembra libera.",
		"STOP يُلزم بالوقوف التام حتى لو بدا الطريق خاليًا.",
		"ثم تُعطى الأولوية.",
		"stop"
	],
	[
		5,
		false,
		"Il dare precedenza obbliga sempre allo stesso arresto completo dello STOP.",
		"أعطِ الأولوية يُلزم دائمًا بالوقوف التام مثل STOP.",
		"يجب التهدئة والاستعداد للوقوف، لكن الوقوف التام ليس واجبًا إذا كان العبور آمنًا.",
		"dare"
	],
	[
		5,
		true,
		"La losanga gialla indica una strada con diritto di precedenza.",
		"المعيّن الأصفر يدل على طريق ذي أولوية.",
		"تسري حتى إشارة النهاية.",
		"diritto"
	],
	[
		5,
		true,
		"Il segnale raffigurato indica la fine del diritto di precedenza.",
		"الإشارة تعني نهاية حق الأولوية.",
		"الخط الأسود على المعيّن.",
		"fine-diritto"
	],
	[
		5,
		true,
		"Il triangolo con il ramo verticale più grosso preannuncia un incrocio in cui si ha la precedenza.",
		"المثلث ذو الفرع السميك ينبّه إلى تقاطع لك فيه الأولوية.",
		"الخط السميك يمثل طريقك.",
		"precedenza-incrocio"
	],
	[
		5,
		false,
		"In un incrocio senza segnali ha precedenza chi arriva per primo, anche da sinistra.",
		"في تقاطع بلا إشارات الأولوية لمن وصل أولًا حتى من اليسار.",
		"الأصل الأولوية لليمين لا لمن سبق بالوصول."
	],
	[
		5,
		true,
		"Gli ordini degli agenti prevalgono sui segnali di precedenza.",
		"أوامر الشرطي تغلب إشارات الأولوية.",
		"الشرطي أعلى من اللوحة والإشارة الضوئية."
	],
	[
		5,
		false,
		"Il segnale di dare precedenza è posto con il vertice in alto.",
		"إشارة أعطِ الأولوية رأسها إلى الأعلى.",
		"رأسها إلى الأسفل.",
		"dare"
	],
	[
		5,
		true,
		"Dopo la fine del diritto di precedenza torna la regola generale dell'incrocio.",
		"بعد نهاية حق الأولوية تعود القاعدة العامة للتقاطع.",
		"قد تصبح الأولوية لليمين إن لم توجد إشارة أخرى.",
		"fine-diritto"
	],
	[
		5,
		true,
		"Chi esce da un'area privata deve dare precedenza a chi circola sulla strada pubblica.",
		"من يخرج من مساحة خاصة يعطي الأولوية لمن على الطريق العام.",
		"قاعدة ثابتة في الامتحان."
	],
	[
		6,
		true,
		"La striscia continua non deve essere attraversata.",
		"الخط المتصل لا يجوز عبوره.",
		"لا للتجاوز الذي يقتضي عبوره.",
		"continua"
	],
	[
		6,
		true,
		"La striscia discontinua può essere superata per cambiare corsia se la manovra è sicura.",
		"الخط المتقطع يجوز تجاوزه لتغيير المسلك إذا كانت المناورة آمنة.",
		"ليس إذنًا أعمى.",
		"discontinua"
	],
	[
		6,
		false,
		"Sulle strisce pedonali il veicolo ha sempre precedenza sul pedone che attraversa.",
		"على خطوط المشاة المركبة دائمًا أولى من الماشي الذي يعبر.",
		"الماشي على الممر له الأولوية.",
		"zebrato"
	],
	[
		6,
		true,
		"La scritta STOP sulla carreggiata richiama l'obbligo di arresto.",
		"كلمة STOP على الأرض تذكّر بواجب الوقوف.",
		"الخط العرضي هو موضع الوقوف.",
		"stop-terra"
	],
	[
		6,
		true,
		"La freccia direzionale dipinta in corsia obbliga la direzione di marcia.",
		"السهم المرسوم في المسلك يُلزم باتجاه السير.",
		"ليس زخرفة.",
		"freccia-suolo"
	],
	[
		6,
		false,
		"La corsia con la scritta BUS può essere usata da tutte le autovetture per sorpassare.",
		"مسلك BUS يجوز لكل السيارات استخدامه للتجاوز.",
		"مسلك مخصص. لا تسر فيه للتجاوز.",
		"corsia-bus"
	],
	[
		6,
		true,
		"Se la segnaletica gialla di cantiere contraddice quella bianca, prevale la gialla.",
		"إذا تعارض الأصفر المؤقت مع الأبيض الدائم يغلب الأصفر.",
		"علامة الورشة لها الأولوية محليًا."
	],
	[
		6,
		false,
		"La doppia striscia continua può essere attraversata per un sorpasso breve.",
		"الخطان المتصلان يجوز عبورهما لتجاوز قصير.",
		"العبور ممنوع من الجهتين.",
		"doppia-continua"
	],
	[
		6,
		true,
		"È vietato sostare sopra l'attraversamento pedonale.",
		"الوقوف فوق ممر المشاة ممنوع.",
		"يسدّ عبور المشاة.",
		"zebrato"
	],
	[
		6,
		false,
		"La striscia discontinua ha lo stesso divieto di attraversamento della continua.",
		"الخط المتقطع له نفس منع العبور الخاص بالمتصل.",
		"المتقطع يُعبر عند أمان المناورة.",
		"discontinua"
	],
	[
		7,
		true,
		"La luce rossa del semaforo impone l'arresto.",
		"الضوء الأحمر يفرض الوقوف.",
		"قبل خط التوقف.",
		"rosso"
	],
	[
		7,
		false,
		"Il braccio alzato dell'agente equivale alla luce rossa.",
		"الذراع المرفوعة تعادل الضوء الأحمر.",
		"تعادل الأصفر الثابت: قف إن أمكن بأمان، وأخلِ التقاطع إن كنت داخله.",
		"agente-alt"
	],
	[
		7,
		true,
		"Il braccio alzato dell'agente equivale alla luce gialla fissa.",
		"الذراع المرفوعة تعادل الأصفر الثابت.",
		"هذه جملة صحيحة مشهورة في الامتحان.",
		"agente-alt"
	],
	[
		7,
		true,
		"Se l'incrocio è già impegnato quando il vigile alza il braccio, bisogna liberarlo rapidamente.",
		"إذا كنت داخل التقاطع حين يرفع الشرطي ذراعه فيجب إخلاؤه بسرعة.",
		"لا تقف في وسط التقاطع."
	],
	[
		7,
		false,
		"Con il braccio alzato si può solo svoltare a destra.",
		"مع الذراع المرفوعة يجوز فقط الانعطاف يمينًا.",
		"ليست إشارة اتجاه. هي تنبيه ووقوف إن أمكن.",
		"agente-alt"
	],
	[
		7,
		true,
		"Chi vede di fronte l'agente con le braccia distese deve fermarsi.",
		"من يرى الشرطي من الأمام وذراعاه ممدودتان يجب أن يقف.",
		"الصدر والظهر يعنيان وقفًا.",
		"agente-fronte"
	],
	[
		7,
		true,
		"Chi arriva di fianco all'agente con le braccia distese ha via libera.",
		"من يأتي من جنب الشرطي وذراعاه ممدودتان يمر.",
		"السير الموازي للذراعين مسموح.",
		"agente-profilo"
	],
	[
		7,
		false,
		"Il giallo lampeggiante dà la precedenza assoluta a chi lo incontra.",
		"الأصفر الوامض يعطي أولوية مطلقة لمن يراه.",
		"يدعو للحذر وتبقى قواعد الأولوية.",
		"lampeggiante"
	],
	[
		7,
		true,
		"La freccia verde consente il transito solo nella direzione della freccia.",
		"السهم الأخضر يسمح بالمرور في اتجاه السهم فقط.",
		"الاتجاهات الأخرى تبقى مغلقة.",
		"freccia-verde"
	],
	[
		7,
		true,
		"Non si entra in un incrocio con il verde se non si può uscire dall'altra parte per la coda.",
		"لا تدخل تقاطعًا بالأخضر إذا كان الزحام يمنعك من الخروج.",
		"لا تسدّ التقاطع.",
		"verde"
	],
	[
		7,
		false,
		"Il semaforo prevale sugli ordini dell'agente.",
		"الإشارة الضوئية تغلب أوامر الشرطي.",
		"الشرطي يغلب الإشارة."
	],
	[
		8,
		true,
		"L'inizio del centro abitato è indicato da un pannello bianco con il nome della località.",
		"بداية العمران لوحة بيضاء باسم المكان.",
		"ومعها غالبًا حد 50.",
		"abitato"
	],
	[
		8,
		true,
		"La fine del centro abitato è il nome sbarrato di rosso.",
		"نهاية العمران الاسم مشطوب بالأحمر.",
		"تعود حدود خارج العمران.",
		"fine-abitato"
	],
	[
		8,
		false,
		"I cartelli di direzione in autostrada hanno fondo blu.",
		"لوحات الاتجاه على الأوتوسترادا خلفيتها زرقاء.",
		"على الأوتوسترادا خضراء. الأزرق للطرق الرئيسية خارج العمران.",
		"preavviso"
	],
	[
		8,
		true,
		"Il segnale di inizio autostrada ha fondo verde.",
		"إشارة بداية الأوتوسترادا خلفيتها خضراء.",
		"ويمنع فئات مثل المشاة والدراجات.",
		"autostrada"
	],
	[
		8,
		false,
		"Il quadrato blu con il pedone è solo un preavviso di pericolo lontano.",
		"المربع الأزرق مع المشاة مجرد إنذار خطر بعيد.",
		"يبين موقع الممر. الإنذار البعيد هو المثلث.",
		"attraversamento"
	],
	[
		8,
		true,
		"Il senso unico è una freccia bianca su fondo blu.",
		"الاتجاه الواحد سهم أبيض على خلفية زرقاء.",
		"السير في اتجاه السهم فقط.",
		"senso-unico"
	],
	[
		8,
		false,
		"Il segnale di parcheggio vieta la sosta.",
		"إشارة الموقف تمنع الوقوف.",
		"تشير إلى مكان يُسمح فيه بالوقوف حسب القواعد.",
		"parcheggio"
	],
	[
		8,
		true,
		"Il segnale di strada senza uscita avvisa che non c'è sbocco.",
		"إشارة الطريق المسدود تنبّه إلى أنه لا مخرج.",
		"الطرف الأحمر في أعلى الرسم.",
		"senza-uscita"
	],
	[
		8,
		true,
		"La fine dell'autostrada fa cessare le regole particolari dell'autostrada.",
		"نهاية الأوتوسترادا تُنهي قواعدها الخاصة.",
		"تتغير السرعة والممنوعات.",
		"fine-autostrada"
	],
	[
		8,
		false,
		"Il segnale dell'ospedale impone da solo il limite di 30 km/h.",
		"إشارة المستشفى تفرض وحدها حد 30.",
		"هي إرشاد. الحد يأتي من إشارة سرعة أو من قاعدة المكان.",
		"ospedale"
	],
	[
		9,
		true,
		"La segnaletica temporanea di cantiere ha di regola fondo giallo.",
		"علامات الورشة المؤقتة خلفيتها صفراء في العادة.",
		"وتغلب الدائمة المتعارضة.",
		"cantiere"
	],
	[
		9,
		true,
		"I coni delimitano un ostacolo o una zona di lavori e non vanno attraversati.",
		"الأقماع تحدد عائقًا أو منطقة عمل ولا تُقطع.",
		"صف الأقماع كالحاجز.",
		"coni"
	],
	[
		9,
		false,
		"In un cantiere si può ignorare la deviazione gialla se la strada bianca sembra più corta.",
		"في الورشة يمكن تجاهل التحويلة الصفراء إذا بدا الطريق الأبيض أقصر.",
		"يُتبع المسار المؤقت.",
		"deviazione"
	],
	[
		9,
		true,
		"Avvicinandosi a un cantiere bisogna moderare la velocità.",
		"عند الاقتراب من ورشة يجب تخفيف السرعة.",
		"عمال ومسار أضيق."
	],
	[
		9,
		false,
		"Il triangolo bianco dei lavori e il cartello giallo di cantiere sono la stessa identica segnalazione.",
		"مثلث الأعمال الأبيض ولوحة الورشة الصفراء هما الإشارة نفسها تمامًا.",
		"الأبيض إنذار خطر، والأصفر تنظيم مؤقت.",
		"lavori"
	],
	[
		9,
		true,
		"Di notte un veicolo fermo presso un cantiere va segnalato con le luci di emergenza.",
		"ليلًا تُعلَن المركبة الواقفة قرب الورشة بأضواء الطوارئ.",
		"لتُرى من البعيد."
	],
	[
		9,
		false,
		"Gli operai del cantiere devono sempre cedere il passo alle auto, anche se sono in mezzo alla carreggiata segnalata.",
		"عمال الورشة يعطون دائمًا الطريق للسيارات حتى لو كانوا في سطح سير مُعلَّم.",
		"المنطقة المغلقة بالأشارات لا تُقتحم."
	],
	[
		9,
		true,
		"La freccia gialla di deviazione indica il percorso da seguire.",
		"السهم الأصفر للتحويلة يبيّن المسار الواجب.",
		"مؤقت طوال الأعمال.",
		"deviazione"
	],
	[
		10,
		true,
		"Il pannello con la scritta 150 m indica la distanza del pericolo o del punto d'inizio.",
		"لوحة 150 م تبين مسافة الخطر أو نقطة البداية.",
		"لا تعني أن الخطر يمتد 150 مترًا.",
		"pannello-distanza"
	],
	[
		10,
		false,
		"Il pannello di estesa 3 km indica che il segnale inizia fra 3 km.",
		"لوحة الامتداد 3 كم تعني أن الإشارة تبدأ بعد 3 كم.",
		"الامتداد هو طول سريان الإشارة. المسافة حتى البداية لوحة أخرى.",
		"pannello-estesa"
	],
	[
		10,
		true,
		"Un limite di velocità con sotto il simbolo di un autocarro può riguardare solo quella categoria.",
		"حد سرعة تحته رمز شاحنة قد يخص تلك الفئة فقط.",
		"اقرأ اللوحة المكمّلة قبل تعميم المنع."
	],
	[
		10,
		true,
		"Il pannello orario limita la validità del segnale alle ore indicate.",
		"لوحة الوقت تقصر سريان الإشارة على الساعات المكتوبة.",
		"خارجها لا يسري ذلك القيد.",
		"pannello-orario"
	],
	[
		10,
		false,
		"I pannelli integrativi si mettono sempre da soli, senza un segnale principale.",
		"اللوحات المكمّلة توضع دائمًا وحدها بلا إشارة رئيسية.",
		"هي تابعة للإشارة التي فوقها."
	],
	[
		10,
		true,
		"Il pannello ghiaccio precisa il motivo per cui il tratto è pericoloso.",
		"لوحة الجليد تحدد سبب خطر المقطع.",
		"تكمل مثلث الطريق الزلق.",
		"pannello-ghiaccio"
	],
	[
		10,
		false,
		"Se manca il pannello della distanza, il pericolo si trova sempre esattamente a 150 metri.",
		"إذا غابت لوحة المسافة فالخطر دائمًا على 150 مترًا بالضبط.",
		"150 مثال شائع لا قاعدة ثابتة بلا لوحة."
	],
	[
		10,
		true,
		"Un pannello può escludere dall'obbligo o dal divieto una categoria di utenti.",
		"اللوحة قد تستثني فئة من الإلزام أو المنع.",
		"اقرأ كلمة الاستثناء والفئة."
	],
	[
		11,
		true,
		"Per le autovetture il limite ordinario in autostrada è 130 km/h.",
		"حد السيارات العادي على الأوتوسترادا 130 كم/س.",
		"ينزل إلى 110 مع المطر."
	],
	[
		11,
		false,
		"In caso di pioggia il limite in autostrada resta 130 km/h.",
		"مع المطر يبقى حد الأوتوسترادا 130.",
		"ينزل إلى 110."
	],
	[
		11,
		true,
		"Sulle strade extraurbane principali il limite ordinario delle autovetture è 110 km/h.",
		"على الطرق الرئيسية خارج العمران حد السيارات العادي 110.",
		"ومع المطر 90."
	],
	[
		11,
		true,
		"Sulle strade extraurbane secondarie il limite ordinario è 90 km/h.",
		"على الطرق الثانوية خارج العمران الحد العادي 90.",
		"ما لم توجد إشارة أخرى."
	],
	[
		11,
		false,
		"Nel centro abitato il limite ordinario è 70 km/h.",
		"داخل العمران الحد العادي 70.",
		"الأصل 50 ما لم ترفع إشارة الحد."
	],
	[
		11,
		false,
		"Il neopatentato può viaggiare a 130 km/h in autostrada.",
		"حديث الرخصة يجوز له 130 على الأوتوسترادا.",
		"حده 100 لمدة 3 سنوات."
	],
	[
		11,
		true,
		"Il neopatentato non supera 90 km/h sulle strade extraurbane principali.",
		"حديث الرخصة لا يتجاوز 90 على الطرق الرئيسية خارج العمران.",
		"بدل 110 لمدة 3 سنوات."
	],
	[
		11,
		false,
		"Il limite del neopatentato in città è 30 km/h.",
		"حد حديث الرخصة في المدينة 30.",
		"يبقى 50 مثل الجميع، ما لم توجد إشارة أقل."
	],
	[
		11,
		true,
		"Per i primi 3 anni la potenza dell'autovettura del neopatentato non supera 105 kW, oltre al rapporto di 75 kW per tonnellata.",
		"في أول 3 سنوات لا تتجاوز قدرة سيارة حديث الرخصة 105 كيلوواط، مع حد 75 كيلوواط للطن.",
		"هناك استثناء للمرافق المؤهل أو لخدمة شخص من ذوي الإعاقة."
	],
	[
		11,
		false,
		"Un'autovettura con rimorchio può viaggiare a 130 km/h in autostrada.",
		"سيارة بمقطورة يجوز لها 130 على الأوتوسترادا.",
		"حد القطر أقل بكثير، والمرجع الشهير في الامتحان 80."
	],
	[
		11,
		true,
		"Rispettare il limite massimo non basta se la strada è bagnata o la visibilità è scarsa.",
		"احترام الحد الأقصى لا يكفي إذا كان الطريق مبللًا أو الرؤية ضعيفة.",
		"السرعة تُلائم الظروف."
	],
	[
		11,
		false,
		"Con la pioggia il limite sulle extraurbane principali resta 110 km/h.",
		"مع المطر يبقى حد الطرق الرئيسية خارج العمران 110.",
		"ينزل إلى 90."
	],
	[
		12,
		true,
		"Il tempo di reazione in condizioni normali è circa un secondo.",
		"زمن رد الفعل في الظروف العادية حوالي ثانية.",
		"يزيد مع التعب والكحول والدواء."
	],
	[
		12,
		false,
		"In un secondo, a 130 km/h, si percorrono circa 15 metri.",
		"في ثانية، عند 130، تُقطع حوالي 15 مترًا.",
		"حوالي 36 مترًا. 15 رقم خادع."
	],
	[
		12,
		true,
		"A 50 km/h si percorrono circa 14 metri in un secondo.",
		"عند 50 تُقطع حوالي 14 مترًا في الثانية.",
		"لأن 50 ÷ 3.6 ≈ 14."
	],
	[
		12,
		true,
		"Lo spazio di arresto comprende lo spazio di reazione e lo spazio di frenata.",
		"مسافة التوقف تشمل مسافة رد الفعل ومسافة الفرملة.",
		"الاثنان معًا."
	],
	[
		12,
		false,
		"Raddoppiando la velocità, lo spazio di frenata raddoppia soltanto.",
		"إذا ضاعفت السرعة فمسافة الفرملة تتضاعف فقط.",
		"تقريبًا تُضرب في أربعة لأنها تتبع مربع السرعة."
	],
	[
		12,
		true,
		"Sul bagnato la distanza di sicurezza deve aumentare.",
		"على الطريق المبلل يجب زيادة مسافة الأمان.",
		"التماسك أقل."
	],
	[
		12,
		false,
		"La distanza di sicurezza si può ridurre al minimo se si ha fretta e i freni sono nuovi.",
		"مسافة الأمان يمكن تقليلها لأدنى حد عند الاستعجال إذا كانت الفرامل جديدة.",
		"الاستعجال لا يغيّر الفيزياء."
	],
	[
		12,
		true,
		"L'alcol allunga il tempo di reazione.",
		"الكحول يطيل زمن رد الفعل.",
		"حتى تحت حد 0.5 قد يتأثر الأداء، والحد القانوني شيء والأمان شيء."
	],
	[
		12,
		true,
		"Una stima su asfalto asciutto è il quadrato delle decine della velocità in km/h.",
		"تقدير على الأسفلت الناشف هو مربع عشرات السرعة بالكم/س.",
		"50 تعطي حوالي 25 مترًا."
	],
	[
		12,
		false,
		"Lo spazio di frenata non dipende dallo stato degli pneumatici.",
		"مسافة الفرملة لا تعتمد على حالة الإطارات.",
		"الإطار الأملس أو الضغط الخطأ يطيلها."
	],
	[
		13,
		true,
		"Fuori dal centro abitato si circola di norma vicino al margine destro.",
		"خارج العمران يسير السائق عادة قرب الحافة اليمنى.",
		"اليسار للتجاوز لا للإقامة فيه."
	],
	[
		13,
		true,
		"Prima di cambiare corsia si controllano specchi e angolo cieco e si usa l'indicatore di direzione.",
		"قبل تغيير المسلك تُفحص المرايا والزاوية العمياء ويُستخدم الغمّاز.",
		"ثم تتم المناورة."
	],
	[
		13,
		false,
		"Per svoltare a sinistra si invade subito la corsia opposta molto prima dell'incrocio.",
		"للانعطاف يسارًا تُقتحم المسلك المقابل قبل التقاطع بوقت طويل.",
		"تبقى في جهة سيرك حتى نقطة الانعطاف، وتُعطي الأولوية لمن أمامك."
	],
	[
		13,
		true,
		"Chi svolta a sinistra cede il passo ai veicoli che arrivano di fronte.",
		"من ينعطف يسارًا يعطي الطريق للمركبات القادمة من الأمام.",
		"قاعدة ثابتة.",
		"fig-svolta"
	],
	[
		13,
		false,
		"La retromarcia è consentita in autostrada per tornare a un'uscita saltata.",
		"الرجوع للخلف مسموح على الأوتوسترادا للعودة إلى مخرج فائت.",
		"ممنوع تمامًا. تُكمل حتى المخرج التالي."
	],
	[
		13,
		true,
		"L'inversione di marcia è vietata dove la visibilità è insufficiente.",
		"الالتفاف للخلف ممنوع حيث الرؤية غير كافية.",
		"وكذلك حيث توجد إشارة منع.",
		"inversione"
	],
	[
		13,
		false,
		"Si può aprire la portiera senza guardare se arriva un ciclista.",
		"يمكن فتح الباب دون النظر إن كان درّاج قادمًا.",
		"يجب التأكد من عدم وجود ماشٍ أو درّاج."
	],
	[
		13,
		true,
		"La segnalazione della manovra si fa prima di eseguirla, non a metà curva.",
		"الإشارة إلى المناورة تكون قبل تنفيذها لا في منتصف الانعطاف.",
		"الغماز تنبيه مسبق."
	],
	[
		14,
		true,
		"All'incrocio senza segnali si dà la precedenza a destra.",
		"في التقاطع بلا إشارات تُعطى الأولوية لليمين.",
		"السيارة القادمة من يمينك تمر أولًا.",
		"fig-destra"
	],
	[
		14,
		false,
		"All'incrocio senza segnali passa prima il veicolo più veloce.",
		"في التقاطع بلا إشارات تمر السيارة الأسرع أولًا.",
		"السرعة لا تخلق أولوية."
	],
	[
		14,
		true,
		"In una rotatoria con il segnale di dare precedenza all'ingresso, hanno priorità i veicoli che sono già dentro.",
		"في دوار عليه إشارة أعطِ الأولوية عند المدخل، الأولوية للمركبات التي هي أصلًا داخله.",
		"لا تقتحم الدوار.",
		"fig-rotatoria"
	],
	[
		14,
		false,
		"In rotatoria si ha sempre la precedenza entrando, perché si arriva da destra.",
		"في الدوار لك دائمًا الأولوية عند الدخول لأنك تأتي من اليمين.",
		"إذا وُجدت إشارة أعطِ الأولوية فالأولوية لمن داخل.",
		"fig-rotatoria"
	],
	[
		14,
		true,
		"Nella strettoia in salita ha di regola precedenza chi sale.",
		"في التضيّق أثناء الصعود الأولوية عادة لمن يصعد.",
		"من ينزل قد يضطر للرجوع.",
		"fig-strettoia"
	],
	[
		14,
		true,
		"I veicoli di soccorso con sirena e luce blu hanno la precedenza.",
		"مركبات الإغاثة بالصفّارة والضوء الأزرق لها الأولوية.",
		"افسح لها الطريق."
	],
	[
		14,
		false,
		"Il pedone fermo sul marciapiede, che non attraversa, blocca tutta la carreggiata.",
		"الماشي الواقف على الرصيف دون أن يعبر يوقف كل سطح السير.",
		"الأولوية حين يعبر على الممر أو حين يكون العبور قد بدأ حسب القاعدة."
	],
	[
		14,
		true,
		"Lo STOP all'incrocio prevale sulla sola regola della precedenza a destra.",
		"STOP في التقاطع يغلب قاعدة اليمين وحدها.",
		"من عليه STOP يقف ويعطي الطريق.",
		"stop"
	],
	[
		14,
		true,
		"Uscendo da un parcheggio si cede la precedenza a chi è già sulla strada.",
		"عند الخروج من موقف تُعطى الأولوية لمن هو أصلًا على الطريق.",
		"أنت تدخل التيار."
	],
	[
		14,
		false,
		"Il tram si può tagliare sempre perché è lento.",
		"يمكن قطع طريق الترام دائمًا لأنه بطيء.",
		"مركبات السكة لها أولوية في الحالات التي يدرّسها الامتحان. لا تقطع أمامها."
	],
	[
		15,
		true,
		"Il sorpasso si effettua di norma a sinistra.",
		"التجاوز يتم عادة من اليسار.",
		"اليمين استثناء."
	],
	[
		15,
		false,
		"È consentito sorpassare in curva se la striscia è continua ma la strada è larga.",
		"يجوز التجاوز في المنحنى إذا كان الخط متصلًا لكن الطريق عريض.",
		"المتصل والمنحنى بلا رؤية يمنعان التجاوز."
	],
	[
		15,
		true,
		"È vietato il sorpasso in corrispondenza degli attraversamenti pedonali.",
		"التجاوز ممنوع عند ممرات المشاة.",
		"الرؤية على الماشي تُحجب.",
		"zebrato"
	],
	[
		15,
		false,
		"Chi viene sorpassato deve accelerare per non far perdere tempo.",
		"من يُتجاوَز يجب أن يسرع كي لا يضيّع الوقت.",
		"لا يزيد السرعة ويبقى يمينًا."
	],
	[
		15,
		true,
		"Prima del sorpasso ci si accerta che nessuno dietro abbia già iniziato la manovra.",
		"قبل التجاوز تتأكد أن أحدًا من الخلف لم يبدأ المناورة.",
		"انظر في المرايا."
	],
	[
		15,
		true,
		"Si rientra a destra solo quando si vede il veicolo sorpassato nello specchio, senza stringerlo.",
		"تعود يمينًا فقط عندما ترى المتجاوَز في المرآة دون التضييق عليه.",
		"لا تقطع عليه."
	],
	[
		15,
		false,
		"Il sorpasso a destra è la regola nelle strade a due corsie per senso di marcia vuote.",
		"التجاوز من اليمين هو القاعدة على طريق بمسلكين خاليين لكل اتجاه.",
		"الأصل يبقى اليسار. اليمين حالات خاصة مثل الزحام المنظم."
	],
	[
		15,
		true,
		"Sui dossi il sorpasso è vietato se la visibilità è insufficiente.",
		"على المرتفع التجاوز ممنوع إذا كانت الرؤية غير كافية.",
		"لا ترى المركبة المقابلة.",
		"dosso"
	],
	[
		15,
		false,
		"Si può sorpassare un veicolo fermo su un attraversamento pedonale accelerando.",
		"يجوز تجاوز مركبة واقفة على ممر مشاة بالتسارع.",
		"قد تكون تخفي ماشيًا. قف وتأكد."
	],
	[
		15,
		true,
		"Segnalare con gli abbaglianti l'intenzione di sorpassare non è l'uso normale dentro il centro abitato.",
		"التنبيه بالأضواء العالية لقصد التجاوز ليس الاستعمال العادي داخل العمران.",
		"داخل البلد الأضواء العالية ليست أداة إلحاح."
	],
	[
		16,
		true,
		"Durante la fermata il conducente deve essere pronto a ripartire.",
		"أثناء التوقف القصير يجب أن يكون السائق جاهزًا للانطلاق.",
		"هذا يفرّق fermata عن sosta."
	],
	[
		16,
		false,
		"La sosta è sempre più breve della fermata.",
		"الوقوف الطويل دائمًا أقصر من التوقف القصير.",
		"العكس: sosta أطول ويمكن ترك المركبة."
	],
	[
		16,
		true,
		"L'arresto è imposto dal traffico o dai segnali, non è una scelta di parcheggio.",
		"الوقوف الاضطراري تفرضه الحركة أو الإشارات، وليس اختيار موقف.",
		"مثل الأحمر أو الصف."
	],
	[
		16,
		false,
		"Il divieto di sosta vieta anche la fermata per far scendere un passeggero.",
		"ممنوع الوقوف يمنع أيضًا التوقف لإنزال راكب.",
		"التوقف القصير ما زال مسموحًا. الذي يمنعه هو divieto di fermata.",
		"sosta"
	],
	[
		16,
		true,
		"In città non ci si ferma a meno di 5 metri dall'intersezione, salvo diversa segnalazione.",
		"في المدينة لا تقف على أقل من 5 أمتار من التقاطع ما لم توجد إشارة مختلفة.",
		"تُقاس من امتداد حافة الطريق العرضي."
	],
	[
		16,
		true,
		"La sosta in seconda fila è vietata, salvo per i veicoli a due ruote.",
		"الوقوف في الصف الثاني ممنوع إلا للمركبات ذات العجلتين.",
		"يسدّ الانطلاق عن الرصيف."
	],
	[
		16,
		false,
		"Si può sostare sulle strisce pedonali se si lasciano le quattro frecce accese.",
		"يمكن الوقوف على خطوط المشاة إذا بقيت أضواء الطوارئ مضاءة.",
		"الأضواء لا تبيح سد الممر.",
		"zebrato"
	],
	[
		16,
		true,
		"Se la fermata dell'autobus non è disegnata a terra, la sosta è vietata a meno di 15 metri dal segnale.",
		"إذا لم يُرسم موقف الحافلة على الأرض فالوقوف ممنوع على أقل من 15 مترًا من اللوحة.",
		"مادة 158."
	],
	[
		16,
		false,
		"Sui marciapiedi la sosta delle auto è sempre libera.",
		"على الأرصفة وقوف السيارات دائمًا حر.",
		"ممنوع ما لم تسمح إشارة صراحة.",
		"fermata"
	],
	[
		16,
		true,
		"È vietata la fermata e la sosta in curva e sui dossi.",
		"التوقف والوقوف ممنوعان في المنحنى وعلى المرتفع.",
		"الرؤية والحيز."
	],
	[
		17,
		false,
		"In autostrada è consentita l'inversione di marcia sullo spartitraffico se non passano auto.",
		"على الأوتوسترادا يجوز الالتفاف على الفاصل إذا لم تمر سيارات.",
		"الالتفاف ممنوع."
	],
	[
		17,
		true,
		"La corsia di emergenza non si usa per viaggiare più veloci.",
		"مسلك الطوارئ لا يُستخدم للسير بسرعة أكبر.",
		"هو للتوقف الاضطراري والإغاثة."
	],
	[
		17,
		true,
		"In panne in autostrada si indossa il giubbotto retroriflettente prima di scendere.",
		"عند العطل على الأوتوسترادا تُلبس السترة العاكسة قبل النزول.",
		"ثم يوضع المثلث."
	],
	[
		17,
		false,
		"Si può trainare a mano un'auto in panne lungo la corsia di sorpasso.",
		"يمكن جر سيارة معطلة يدويًا على مسلك التجاوز.",
		"هذا خطر وممنوع. تُؤمَّن على مسلك الطوارئ ويُطلب الإغاثة."
	],
	[
		17,
		true,
		"Il carico non deve coprire le luci, la targa o gli specchi.",
		"الحمولة يجب ألا تغطي الأضواء أو لوحة الأرقام أو المرايا.",
		"ولا تسقط على الطريق."
	],
	[
		17,
		false,
		"Si possono trasportare passeggeri nel bagagliaio se sono pochi.",
		"يمكن نقل ركّاب في الصندوق إذا كانوا قلة.",
		"فقط المقاعد المعتمدة."
	],
	[
		17,
		true,
		"All'immissione in autostrada si cede il passo a chi è già sulla corsia di marcia.",
		"عند دخول الأوتوسترادا تُعطى الأولوية لمن هو أصلًا في مسلك السير.",
		"مسلك التسارع لبلوغ سرعة مناسبة لا لفرض نفسك."
	],
	[
		17,
		false,
		"La retromarcia in autostrada è lecita per pochi metri.",
		"الرجوع أمتار قليلة على الأوتوسترادا مشروع.",
		"ممنوع حتى لأمتار قليلة."
	],
	[
		17,
		true,
		"Pedoni e biciclette non circolano in autostrada.",
		"المشاة والدراجات لا يسيرون على الأوتوسترادا.",
		"كذلك الدراجات البخارية الصغيرة."
	],
	[
		18,
		true,
		"Fuori dai centri abitati gli anabbaglianti si usano anche di giorno.",
		"خارج العمران تُستخدم الأضواء المنخفضة حتى نهارًا.",
		"أو أضواء نهارية معادلة حسب تجهيز السيارة."
	],
	[
		18,
		false,
		"Gli abbaglianti si tengono accesi mentre si incrocia un veicolo di fronte.",
		"تُبقى الأضواء العالية مضاءة أثناء التلاقي مع مركبة مقابلة.",
		"يُرجع إلى المنخفضة حتى لا تُبهر."
	],
	[
		18,
		true,
		"In galleria si usano gli anabbaglianti.",
		"في النفق تُستخدم الأضواء المنخفضة.",
		"حتى نهارًا."
	],
	[
		18,
		false,
		"Il retronebbia si lascia acceso con poca pioggia e cielo chiaro.",
		"الضباب الخلفي يُترك مضاءً مع مطر خفيف وسماء صافية.",
		"فقط مع رؤية شديدة الانخفاض، ثم يُطفأ."
	],
	[
		18,
		true,
		"Le quattro frecce segnalano un pericolo o un rallentamento improvviso.",
		"الأضواء الأربعة تعلن خطرًا أو تباطؤًا مفاجئًا.",
		"وكذلك التوقف الاضطراري."
	],
	[
		18,
		false,
		"In città si può usare il clacson per invitare il pedone ad affrettarsi.",
		"في المدينة يمكن استخدام البوق لحث الماشي على الإسراع.",
		"البوق في المدينة لخطر داهم لا للاستعجال.",
		"clacson"
	],
	[
		18,
		true,
		"Da mezz'ora dopo il tramonto a mezz'ora prima dell'alba occorre l'illuminazione di marcia.",
		"من نصف ساعة بعد الغروب إلى نصف ساعة قبل الشروق يلزم إضاءة السير.",
		"الأضواء المنخفضة."
	],
	[
		18,
		false,
		"La spia rossa dell'olio si può ignorare fino a destinazione.",
		"لمبة الزيت الحمراء يمكن تجاهلها حتى الوصول.",
		"توقف بأمان وافحص. استمرار السير قد يتلف المحرك."
	],
	[
		18,
		true,
		"I fendinebbia anteriori servono con nebbia, neve o pioggia intensa.",
		"أضواء الضباب الأمامية للضباب أو الثلج أو المطر الشديد.",
		"ليست بديلًا دائمًا عن المنخفضة في كل رحلة."
	],
	[
		18,
		false,
		"Dentro il centro abitato, di giorno e con buona visibilità, gli anabbaglianti sono sempre obbligatori.",
		"داخل العمران نهارًا مع رؤية جيدة تكون المنخفضة دائمًا إجبارية.",
		"الإلزام النهاري يخص خارج العمران."
	],
	[
		19,
		true,
		"Le cinture sono obbligatorie anche per i passeggeri posteriori.",
		"الأحزمة إجبارية أيضًا للركاب الخلفيين.",
		"وفي المدينة كذلك."
	],
	[
		19,
		false,
		"L'airbag sostituisce la cintura di sicurezza.",
		"الوسادة الهوائية تغني عن حزام الأمان.",
		"تعمل مع الحزام لا بدلًا منه."
	],
	[
		19,
		true,
		"Il bambino di statura inferiore a 1,50 m usa un sistema di ritenuta omologato.",
		"الطفل الأقصر من 1.50 م يستخدم نظام تثبيت معتمد.",
		"مناسب لوزنه وطوله."
	],
	[
		19,
		false,
		"Il seggiolino rivolto all'indietro si mette davanti all'airbag acceso.",
		"مقعد الطفل المواجه للخلف يوضع أمام وسادة هوائية شغّالة.",
		"يجب إيقاف الوسادة. الخطر شديد."
	],
	[
		19,
		true,
		"Sul motociclo il casco omologato va allacciato, anche per il passeggero.",
		"على الدراجة النارية الخوذة المعتمدة تُربط، حتى للراكب.",
		"رخصة B لا تُعفي منها."
	],
	[
		19,
		false,
		"In città le cinture non sono obbligatorie sotto i 50 km/h.",
		"في المدينة الأحزمة غير إجبارية تحت 50.",
		"الإلزام عام، والاصطدام في المدينة يكفي لإصابة خطيرة."
	],
	[
		19,
		true,
		"Una cintura passata sotto il braccio non è un uso corretto.",
		"تمرير الحزام تحت الذراع ليس استخدامًا صحيحًا.",
		"يفسد حماية الحزام."
	],
	[
		19,
		false,
		"Il casco si può tenere slacciato se si va piano.",
		"يمكن إبقاء الخوذة غير مربوطة إذا كانت السرعة بطيئة.",
		"يجب أن تكون مثبتة."
	],
	[
		19,
		true,
		"Esistono esenzioni mediche documentate all'uso della cintura.",
		"توجد إعفاءات طبية موثّقة من الحزام.",
		"ليست رغبة شخصية."
	],
	[
		20,
		true,
		"Durante la guida bisogna poter esibire patente e carta di circolazione.",
		"أثناء القيادة يجب إبراز الرخصة وشهادة التسجيل.",
		"عند طلب الشرطي."
	],
	[
		20,
		false,
		"È ancora obbligatorio incollare il contrassegno cartaceo dell'assicurazione sul parabrezza.",
		"ما زال إجباريًا لصق ملصق التأمين الورقي على الزجاج.",
		"الرقابة صارت إلكترونية والملصق الورقي لم يعد يُعرض."
	],
	[
		20,
		true,
		"L'assicurazione RCA è obbligatoria per circolare.",
		"تأمين المسؤولية تجاه الغير إجباري للسير.",
		"بدونه لا تسير المركبة."
	],
	[
		20,
		true,
		"La patente a punti parte da 20 punti.",
		"رخصة النقاط تبدأ من 20 نقطة.",
		"والسقف 30 بحسن السلوك."
	],
	[
		20,
		false,
		"Il massimo dei punti patente è 20.",
		"الحد الأقصى لنقاط الرخصة 20.",
		"يمكن بلوغ 30."
	],
	[
		20,
		true,
		"Nei primi 3 anni le decurtazioni dei punti sono doppie.",
		"في أول 3 سنوات خصم النقاط مضاعف.",
		"هذا أثر صفة حديث الرخصة."
	],
	[
		20,
		false,
		"A zero punti si può continuare a guidare fino al rinnovo ordinario.",
		"عند صفر نقطة يمكن متابعة القيادة حتى التجديد العادي.",
		"الرخصة تدخل المراجعة ويجب إعادة الامتحانات."
	],
	[
		20,
		true,
		"Se la patente riporta l'obbligo di lenti, si guida solo usandole.",
		"إذا ذُكر على الرخصة وجوب العدسات فلا تُقاد السيارة إلا بها.",
		"المخالفة تثبّت عند الرقابة."
	],
	[
		20,
		true,
		"Ogni due anni senza infrazioni che tolgono punti si guadagnano 2 punti, fino a 30.",
		"كل سنتين بلا مخالفات تُنقص النقاط تُكسب نقطتان حتى 30.",
		"المكافأة ليست فورية كل شهر."
	],
	[
		20,
		false,
		"Si possono rifiutare i documenti all'agente se si ha fretta.",
		"يمكن رفض إبراز الوثائق للشرطي عند الاستعجال.",
		"الوقوف والامتثال واجبان."
	],
	[
		20,
		true,
		"La prima revisione di un'auto nuova cade dopo 4 anni, poi ogni 2.",
		"الفحص الأول لسيارة جديدة بعد 4 سنوات ثم كل سنتين.",
		"الفصل 25 يؤكده أيضًا."
	],
	[
		21,
		true,
		"Dopo un incidente bisogna fermarsi.",
		"بعد الحادث يجب التوقف.",
		"وخصوصًا إذا كان هناك مصابون."
	],
	[
		21,
		false,
		"Se i danni sono lievi si può lasciare il luogo senza scambiare i dati, purché non ci siano feriti.",
		"إذا كان الضرر بسيطًا يمكن مغادرة المكان دون تبادل البيانات ما دام لا مصابين.",
		"يُتبادل البيانات. الفرار حتى في الضرر المادي مشكلة."
	],
	[
		21,
		true,
		"Non si sposta un ferito se non c'è un pericolo immediato come un incendio.",
		"لا يُنقل المصاب إلا لخطر فوري مثل حريق.",
		"تحريكه قد يزيد الإصابة."
	],
	[
		21,
		true,
		"Si chiama il 112 indicando il luogo e il numero dei feriti.",
		"يُتصل بـ 112 مع تحديد المكان وعدد المصابين.",
		"والمخاطر مثل الوقود أو الحريق."
	],
	[
		21,
		false,
		"Al ferito si può dare un bicchiere di alcol per calmarlo.",
		"يمكن إعطاء المصاب كأس كحول لتهدئته.",
		"ممنوع. لا مشروب ولا دواء عشوائي."
	],
	[
		21,
		true,
		"Il triangolo e il giubbotto servono a segnalare il pericolo senza esporsi.",
		"المثلث والسترة لإعلان الخطر دون تعريض النفس.",
		"البس السترة قبل النزول."
	],
	[
		21,
		false,
		"In autostrada il triangolo si mette appena dietro il paraurti.",
		"على الأوتوسترادا يوضع المثلث ملاصقًا للمصد الخلفي.",
		"يوضع على مسافة كافية ليراه القادم. قريبًا جدًا لا يفيد."
	],
	[
		21,
		true,
		"Lasciare feriti senza soccorso è un reato.",
		"ترك المصابين بلا إغاثة جريمة.",
		"الوقوف واجب."
	],
	[
		21,
		true,
		"La constatazione amichevole si compila con disegno e firme quando è il caso.",
		"المحضر الودّي يُملأ برسم وتوقيع حين يناسب الحال.",
		"لا يغني عن الشرطة إذا كان هناك مصابون."
	],
	[
		22,
		true,
		"Il limite di alcolemia ordinario è 0,5 g/l.",
		"حد الكحول العادي 0.5 غ/ل.",
		"فوق ذلك تبدأ العقوبات."
	],
	[
		22,
		false,
		"Il neopatentato può guidare con 0,4 g/l perché è sotto 0,5.",
		"حديث الرخصة يجوز له 0.4 لأنه تحت 0.5.",
		"حده صفر طوال 3 سنوات."
	],
	[
		22,
		true,
		"Per i conducenti con meno di 21 anni il tasso consentito è zero.",
		"للسائقين دون 21 السنة المسموحة صفر.",
		"مثل حديثي الرخصة والمهنيين."
	],
	[
		22,
		false,
		"Un caffè forte abbassa rapidamente il tasso alcolemico.",
		"القهوة القوية تنزل نسبة الكحول بسرعة.",
		"لا ينزلها إلا مرور الوقت."
	],
	[
		22,
		true,
		"Le sostanze stupefacenti sono incompatibili con la guida.",
		"المواد المخدرة لا تجتمع مع القيادة.",
		"حتى بكميات يظنها السائق صغيرة."
	],
	[
		22,
		true,
		"Alcuni farmaci compromettono i riflessi e riportano un'avvertenza.",
		"بعض الأدوية تضعف ردود الفعل وعليها تحذير.",
		"اقرأ النشرة واسأل الطبيب."
	],
	[
		22,
		false,
		"La stanchezza non influisce sul tempo di reazione.",
		"التعب لا يؤثر على زمن رد الفعل.",
		"يطيله بشكل واضح. استرح كل ساعتين تقريبًا."
	],
	[
		22,
		true,
		"Fra 0,8 e 1,5 g/l la guida in stato di ebbrezza è reato, non solo multa amministrativa.",
		"بين 0.8 و1.5 القيادة تحت تأثير الكحول جريمة لا مجرد غرامة إدارية.",
		"وفوق 1.5 أشد."
	],
	[
		22,
		false,
		"Scrivere un messaggio tenendo il volante con i gomiti è consentito in coda.",
		"كتابة رسالة مع إمساك المقود بالمرفقين مسموحة في الزحام.",
		"الكتابة أثناء القيادة ممنوعة وخطرة."
	],
	[
		22,
		true,
		"Un'emorragia si comprime con un panno pulito in attesa dei soccorsi.",
		"النزيف يُضغط بقطعة قماش نظيفة بانتظار الإسعاف.",
		"ولا تُنزع الضمادة إذا تشبعت بل تُضاف فوقها."
	],
	[
		23,
		true,
		"L'assicurazione RCA copre i danni causati a terzi.",
		"تأمين المسؤولية يغطي الأضرار التي تُسبب للغير.",
		"لا يغطي تلقائيًا كل ضرر بسيارتك."
	],
	[
		23,
		false,
		"La polizza RCA sostituisce la revisione e la patente.",
		"وثيقة التأمين تغني عن الفحص الدوري والرخصة.",
		"كل واجب مستقل."
	],
	[
		23,
		true,
		"Responsabilità civile, penale e amministrativa possono sommarsi.",
		"المسؤولية المدنية والجنائية والإدارية قد تجتمع.",
		"تعويض، وعقوبة، وغرامة مع نقاط."
	],
	[
		23,
		false,
		"Se si è assicurati si può guidare dopo aver bevuto oltre il limite, perché paga la polizza.",
		"إذا كنت مؤمَّنًا يمكن القيادة بعد تجاوز حد الكحول لأن الوثيقة تدفع.",
		"التأمين لا يبيح الجريمة، وقد يرجع على السائق."
	],
	[
		23,
		true,
		"Circolare senza copertura assicurativa è illecito.",
		"السير بلا تغطية تأمينية مخالفة.",
		"تُفحص اللوحة إلكترونيًا."
	],
	[
		23,
		true,
		"Il proprietario può rispondere se affida l'auto a chi non ha la patente.",
		"المالك قد يُسأل إذا سلّم السيارة لمن لا رخصة له.",
		"اختيار السائق مسؤولية."
	],
	[
		23,
		false,
		"La constatazione amichevole va firmata anche se il disegno è falso, per chiudere in fretta.",
		"يوقَّع المحضر الودّي حتى لو كان الرسم كاذبًا لإنهاء الأمر بسرعة.",
		"لا توقّع على ما لا يطابق الواقع."
	],
	[
		23,
		true,
		"I danni al proprio veicolo non sono tutti coperti dalla sola RCA.",
		"أضرار مركبتك ليست كلها مغطاة بتأمين الغير وحده.",
		"يلزم ضمان إضافي إن أردت ذلك."
	],
	[
		24,
		true,
		"Una guida con velocità il più possibile costante riduce i consumi.",
		"قيادة بسرعة ثابتة قدر الإمكان تقلل الاستهلاك.",
		"التسارع والفرملة المتكرران يستهلكان أكثر."
	],
	[
		24,
		false,
		"Tenere il motore al massimo dei giri in ogni marcia fa risparmiare carburante.",
		"إبقاء المحرك على أعلى دورات في كل غيار يوفّر الوقود.",
		"العكس. الغيار المناسب أوفر وأقل تلويثًا."
	],
	[
		24,
		true,
		"Pneumatici sgonfi aumentano i consumi e peggiorano la tenuta.",
		"الإطارات الناقصة الهواء تزيد الاستهلاك وتُضعف الثبات.",
		"افحص الضغط باردًا."
	],
	[
		24,
		false,
		"Si possono scaricare sul bordo della strada olio e batterie usate.",
		"يمكن إلقاء الزيت والبطاريات المستعملة على حافة الطريق.",
		"نفايات خطرة تُسلَّم لنقاط الجمع."
	],
	[
		24,
		true,
		"Rimuovere il catalizzatore è vietato.",
		"إزالة المحوّل الحفّاز ممنوعة.",
		"يزيد التلوث وقد يُسقط الفحص."
	],
	[
		24,
		true,
		"Il clacson inutile aumenta l'inquinamento acustico.",
		"البوق بلا داعٍ يزيد التلوث الضوضائي.",
		"خصوصًا قرب المستشفيات وليلًا.",
		"clacson"
	],
	[
		24,
		false,
		"In una zona a traffico limitato si entra liberamente se si va piano.",
		"منطقة المرور المحدود تُدخل بحرية إذا كانت السرعة بطيئة.",
		"يلزم توافر شرط الدخول، لا مجرد البطء."
	],
	[
		24,
		true,
		"Un portapacchi vuoto lasciato sul tetto aumenta i consumi.",
		"حمالة سقف فارغة تُترك على السيارة تزيد الاستهلاك.",
		"تزيد مقاومة الهواء."
	],
	[
		25,
		true,
		"La prima revisione si fa dopo 4 anni dalla prima immatricolazione e poi ogni 2 anni.",
		"الفحص الأول بعد 4 سنوات من أول ترخيص ثم كل سنتين.",
		"الفحص المنتهي يمنع السير النظامي."
	],
	[
		25,
		false,
		"La profondità minima di riferimento del battistrada è 4 millimetri.",
		"العمق الأدنى المرجعي لنقش الإطار 4 ملم.",
		"المرجع القانوني في الامتحان 1.6 ملم. تحت ذلك الإطار غير مطابق."
	],
	[
		25,
		true,
		"Gomme lisce allungano lo spazio di frenata sul bagnato.",
		"الإطارات الملساء تطيل مسافة الفرملة على المبلل.",
		"وتسهّل الانزلاق المائي."
	],
	[
		25,
		true,
		"In caso di aquaplaning non si frena di colpo e si tiene il volante diritto.",
		"عند الانزلاق المائي لا تُفرمل فجأة ويُبقى المقود مستقيمًا.",
		"خفف الوقود حتى يعود التلامس."
	],
	[
		25,
		false,
		"Con l'ABS bisogna pompare ripetutamente il pedale del freno.",
		"مع ABS يجب ضخ دواسة الفرامل مرارًا.",
		"اضغط بقوة وثبات ووجّه. الضخ كان للأنظمة القديمة."
	],
	[
		25,
		true,
		"Il segnale blu delle catene impone mezzi antisdrucciolo nel tratto.",
		"القرص الأزرق للسلاسل يفرض وسائل منع الانزلاق في المقطع.",
		"سلاسل أو إطارات ثلج حسب النص.",
		"catene"
	],
	[
		25,
		true,
		"La pressione degli pneumatici si controlla a freddo.",
		"ضغط الإطارات يُقاس وهي باردة.",
		"ومنها الاحتياطي."
	],
	[
		25,
		false,
		"Una spia rossa dei freni permette di proseguire fino al prossimo distributore lontano.",
		"لمبة الفرامل الحمراء تسمح بالمتابعة حتى محطة بعيدة.",
		"توقف في أقرب مكان آمن."
	],
	[
		25,
		true,
		"In discesa su fondo sdrucciolevole conviene una marcia bassa.",
		"في النزول على أرض زلقة يُفضَّل غيار منخفض.",
		"المحرك يساعد على الإمساك بالسيارة.",
		"discesa"
	],
	[
		25,
		false,
		"Gli specchi retrovisori sono facoltativi se si guida solo di giorno.",
		"المرايا الخلفية اختيارية إذا كانت القيادة نهارًا فقط.",
		"جزء من تجهيز الأمان الواجب."
	],
	[
		25,
		true,
		"L'aquaplaning è favorito da velocità alta, acqua e battistrada consumato.",
		"الانزلاق المائي يساعده السرعة العالية والماء والنقش المتآكل.",
		"خفف السرعة في المطر."
	]
].map((row, i) => ({
	id: `q${i + 1}`,
	ch: row[0],
	ok: row[1],
	it: row[2],
	ar: row[3],
	whyAr: row[4],
	signId: row[5]
}));
function questionsByChapter(ch) {
	return QUESTIONS.filter((q) => q.ch === ch);
}
//#endregion
export { questionsByChapter as n, QUESTIONS as t };
