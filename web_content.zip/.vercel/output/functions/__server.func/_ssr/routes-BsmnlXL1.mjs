import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as LockKeyhole, c as Copy, i as Plus, l as ChevronDown, n as ShieldCheck, o as Eye, r as Search, s as EyeOff } from "../_libs/lucide-react.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BsmnlXL1.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var VAULT_KEY = "tijori.vault.v1";
var ITERATIONS = 1e5;
function bytesToB64(bytes) {
	let binary = "";
	const chunk = 32768;
	for (let i = 0; i < bytes.length; i += chunk) binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
	return btoa(binary);
}
function b64ToBytes(b64) {
	const binary = atob(b64);
	const out = new Uint8Array(binary.length);
	for (let i = 0; i < binary.length; i++) out[i] = binary.charCodeAt(i);
	return out;
}
async function deriveKey(passphrase, salt, iterations) {
	const material = await crypto.subtle.importKey("raw", new TextEncoder().encode(passphrase), "PBKDF2", false, ["deriveKey"]);
	return crypto.subtle.deriveKey({
		name: "PBKDF2",
		salt,
		iterations,
		hash: "SHA-256"
	}, material, {
		name: "AES-GCM",
		length: 256
	}, false, ["encrypt", "decrypt"]);
}
async function encryptJson(key, value) {
	const iv = crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(12));
	const plain = new TextEncoder().encode(JSON.stringify(value));
	const cipher = await crypto.subtle.encrypt({
		name: "AES-GCM",
		iv
	}, key, plain);
	return {
		iv: bytesToB64(iv),
		data: bytesToB64(new Uint8Array(cipher))
	};
}
async function decryptJson(key, ivB64, dataB64) {
	const iv = b64ToBytes(ivB64);
	const data = b64ToBytes(dataB64);
	const plain = await crypto.subtle.decrypt({
		name: "AES-GCM",
		iv
	}, key, data);
	return JSON.parse(new TextDecoder().decode(plain));
}
function isVaultFile(value) {
	if (!value || typeof value !== "object") return false;
	const file = value;
	return file.v === 1 && file.kdf === "PBKDF2-SHA256" && typeof file.iterations === "number" && file.iterations > 0 && file.iterations <= 2e6 && typeof file.salt === "string" && file.salt.length > 0 && typeof file.iv === "string" && file.iv.length > 0 && typeof file.data === "string" && file.data.length > 0 && typeof file.hint === "string" && typeof file.createdAt === "number";
}
function isEntry(value) {
	if (!value || typeof value !== "object") return false;
	const entry = value;
	return typeof entry.id === "string" && typeof entry.name === "string" && typeof entry.email === "string" && typeof entry.code === "string" && typeof entry.note === "string" && typeof entry.updatedAt === "number";
}
function sanitizeEntries(payload) {
	if (!payload || typeof payload !== "object") return [];
	const entries = payload.entries;
	if (!Array.isArray(entries)) return [];
	return entries.filter(isEntry).slice(0, 50);
}
function loadVault() {
	if (typeof localStorage === "undefined") return { status: "empty" };
	const raw = localStorage.getItem(VAULT_KEY);
	if (!raw) return { status: "empty" };
	try {
		const parsed = JSON.parse(raw);
		if (!isVaultFile(parsed)) return { status: "corrupt" };
		return {
			status: "ready",
			file: parsed
		};
	} catch {
		return { status: "corrupt" };
	}
}
function saveVaultFile(file) {
	localStorage.setItem(VAULT_KEY, JSON.stringify(file));
}
function clearVaultFile() {
	localStorage.removeItem(VAULT_KEY);
}
var AUTO_LOCK_MS = 18e4;
var EMAIL_OK = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
function cn(...parts) {
	return twMerge(parts.filter(Boolean).join(" "));
}
var controlClass = "w-full rounded-xl border border-line bg-bg px-4 text-base text-fg outline-none placeholder:text-muted focus-visible:border-brass";
function VaultApp() {
	const [phase, setPhase] = (0, import_react.useState)("boot");
	const [entries, setEntries] = (0, import_react.useState)([]);
	const [hint, setHint] = (0, import_react.useState)("");
	const [dialog, setDialog] = (0, import_react.useState)({ kind: "none" });
	const [toast, setToast] = (0, import_react.useState)(null);
	const [query, setQuery] = (0, import_react.useState)("");
	const [revealed, setRevealed] = (0, import_react.useState)({});
	const [copied, setCopied] = (0, import_react.useState)(null);
	const fileRef = (0, import_react.useRef)(null);
	const keyRef = (0, import_react.useRef)(null);
	const notify = (0, import_react.useCallback)((text) => {
		setToast({
			id: Date.now(),
			text
		});
	}, []);
	const closeDialog = (0, import_react.useCallback)(() => setDialog({ kind: "none" }), []);
	const lock = (0, import_react.useCallback)(() => {
		keyRef.current = null;
		setEntries([]);
		setRevealed({});
		setQuery("");
		setCopied(null);
		setDialog({ kind: "none" });
		setPhase(fileRef.current ? "locked" : "setup");
	}, []);
	(0, import_react.useEffect)(() => {
		const loaded = loadVault();
		if (loaded.status === "empty") {
			fileRef.current = null;
			setPhase("setup");
			return;
		}
		if (loaded.status === "corrupt") {
			fileRef.current = null;
			setPhase("corrupt");
			return;
		}
		fileRef.current = loaded.file;
		setHint(loaded.file.hint);
		setPhase("locked");
	}, []);
	(0, import_react.useEffect)(() => {
		if (!toast) return;
		const timer = window.setTimeout(() => setToast(null), 3600);
		return () => window.clearTimeout(timer);
	}, [toast]);
	(0, import_react.useEffect)(() => {
		if (phase !== "open") return;
		let timer = window.setTimeout(() => lock(), AUTO_LOCK_MS);
		const bump = () => {
			window.clearTimeout(timer);
			timer = window.setTimeout(() => lock(), AUTO_LOCK_MS);
		};
		window.addEventListener("pointerdown", bump);
		window.addEventListener("keydown", bump);
		return () => {
			window.clearTimeout(timer);
			window.removeEventListener("pointerdown", bump);
			window.removeEventListener("keydown", bump);
		};
	}, [phase, lock]);
	(0, import_react.useEffect)(() => {
		if (phase !== "open") return;
		const onHide = () => {
			if (document.visibilityState === "hidden") setRevealed({});
		};
		document.addEventListener("visibilitychange", onHide);
		return () => document.removeEventListener("visibilitychange", onHide);
	}, [phase]);
	async function createVault(passphrase, nextHint) {
		if (!crypto.subtle) throw new Error("Is browser mein encryption nahi chalti.");
		const salt = crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(16));
		const key = await deriveKey(passphrase, salt, ITERATIONS);
		const sealed = await encryptJson(key, { entries: [] });
		const file = {
			v: 1,
			kdf: "PBKDF2-SHA256",
			iterations: ITERATIONS,
			salt: bytesToB64(salt),
			iv: sealed.iv,
			data: sealed.data,
			hint: nextHint.trim(),
			createdAt: Date.now()
		};
		saveVaultFile(file);
		fileRef.current = file;
		keyRef.current = key;
		setHint(file.hint);
		setEntries([]);
		setPhase("open");
		notify("Tijori ban gayi. Ab entries add karo.");
	}
	async function unlock(passphrase) {
		const file = fileRef.current;
		if (!file) throw new Error("Vault nahi mili.");
		const key = await deriveKey(passphrase, b64ToBytes(file.salt), file.iterations);
		let payload;
		try {
			payload = await decryptJson(key, file.iv, file.data);
		} catch {
			throw new Error("Yeh passphrase nahi hai.");
		}
		keyRef.current = key;
		setEntries(sanitizeEntries(payload));
		setPhase("open");
	}
	async function writeEntries(next) {
		const key = keyRef.current;
		const file = fileRef.current;
		if (!key || !file) throw new Error("Pehle tijori kholo.");
		const sealed = await encryptJson(key, { entries: next });
		const updated = {
			...file,
			iv: sealed.iv,
			data: sealed.data
		};
		saveVaultFile(updated);
		fileRef.current = updated;
		setEntries(next);
	}
	async function saveEntry(next) {
		if (!entries.some((entry) => entry.id === next.id) && entries.length >= 50) throw new Error("50 entries full hain. Pehle koi purani hatao.");
		await writeEntries([next, ...entries.filter((entry) => entry.id !== next.id)]);
		closeDialog();
		notify("Save ho gaya. Is device par encrypted hai.");
	}
	async function removeEntry(id) {
		await writeEntries(entries.filter((entry) => entry.id !== id));
		setRevealed((current) => {
			const next = { ...current };
			delete next[id];
			return next;
		});
		closeDialog();
		notify("Entry hat gayi.");
	}
	async function changePass(oldPass, newPass) {
		const file = fileRef.current;
		if (!file) throw new Error("Vault nahi mili.");
		const oldKey = await deriveKey(oldPass, b64ToBytes(file.salt), file.iterations);
		let payload;
		try {
			payload = await decryptJson(oldKey, file.iv, file.data);
		} catch {
			throw new Error("Purani passphrase galat hai.");
		}
		const nextEntries = sanitizeEntries(payload);
		const salt = crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(16));
		const newKey = await deriveKey(newPass, salt, ITERATIONS);
		const sealed = await encryptJson(newKey, { entries: nextEntries });
		const updated = {
			...file,
			iterations: ITERATIONS,
			salt: bytesToB64(salt),
			iv: sealed.iv,
			data: sealed.data
		};
		saveVaultFile(updated);
		fileRef.current = updated;
		keyRef.current = newKey;
		setEntries(nextEntries);
		closeDialog();
		notify("Passphrase badal gayi.");
	}
	function commitImport(file) {
		saveVaultFile(file);
		fileRef.current = file;
		keyRef.current = null;
		setEntries([]);
		setHint(file.hint);
		setRevealed({});
		setDialog({ kind: "none" });
		setPhase("locked");
		notify("Backup lag gayi. Us file wali passphrase se kholo.");
	}
	async function stageImport(raw) {
		if (raw.size > 1e6) {
			notify("File bahut badi hai.");
			return;
		}
		let parsed;
		try {
			parsed = JSON.parse(await raw.text());
		} catch {
			notify("Yeh tijori backup nahi lagti.");
			return;
		}
		if (!isVaultFile(parsed)) {
			notify("Yeh tijori backup nahi lagti.");
			return;
		}
		if (phase === "setup" || phase === "corrupt") {
			commitImport(parsed);
			return;
		}
		setDialog({
			kind: "import",
			file: parsed
		});
	}
	function exportBackup() {
		const file = fileRef.current;
		if (!file) return;
		const blob = new Blob([JSON.stringify(file)], { type: "application/json" });
		const url = URL.createObjectURL(blob);
		const link = document.createElement("a");
		link.href = url;
		link.download = "tijori-backup.json";
		document.body.appendChild(link);
		link.click();
		link.remove();
		URL.revokeObjectURL(url);
		notify("Backup download ho gayi. File encrypted hai.");
	}
	function wipe() {
		clearVaultFile();
		fileRef.current = null;
		keyRef.current = null;
		setEntries([]);
		setHint("");
		setRevealed({});
		setDialog({ kind: "none" });
		setPhase("setup");
		notify("Tijori is device se mit gayi.");
	}
	async function copyText(entry, field) {
		const text = field === "email" ? entry.email : entry.code;
		try {
			await navigator.clipboard.writeText(text);
			setCopied({
				id: entry.id,
				field
			});
			window.setTimeout(() => {
				setCopied((current) => current && current.id === entry.id && current.field === field ? null : current);
			}, 1600);
		} catch {
			notify("Copy nahi hua. Code dikhao, phir khud select karo.");
		}
	}
	const needle = query.trim().toLowerCase();
	const visible = entries.filter((entry) => {
		if (!needle) return true;
		return [
			entry.name,
			entry.email,
			entry.note,
			entry.code
		].some((part) => part.toLowerCase().includes(needle));
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-1 bg-brass" }),
			toast ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none fixed inset-x-0 top-4 z-40 flex justify-center px-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					role: "status",
					className: "max-w-md rounded-xl border border-line bg-surface px-4 py-3 text-center text-sm text-fg",
					children: toast.text
				})
			}) : null,
			phase === "boot" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BootScreen, {}) : null,
			phase === "setup" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SetupScreen, {
				onCreate: createVault,
				onImport: stageImport
			}) : null,
			phase === "locked" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LockScreen, {
				hint,
				onUnlock: unlock,
				onImport: stageImport,
				onWipe: () => setDialog({ kind: "wipe" })
			}) : null,
			phase === "corrupt" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CorruptScreen, {
				onImport: stageImport,
				onWipe: () => setDialog({ kind: "wipe" })
			}) : null,
			phase === "open" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OpenScreen, {
				entries,
				visible,
				query,
				revealed,
				copied,
				onQuery: setQuery,
				onToggle: (id) => setRevealed((current) => ({
					...current,
					[id]: !current[id]
				})),
				onCopy: copyText,
				onAdd: () => setDialog({
					kind: "entry",
					entry: null
				}),
				onEdit: (entry) => setDialog({
					kind: "entry",
					entry
				}),
				onDelete: (entry) => setDialog({
					kind: "delete",
					entry
				}),
				onLock: lock,
				onExport: exportBackup,
				onImport: stageImport,
				onPass: () => setDialog({ kind: "pass" }),
				onWipe: () => setDialog({ kind: "wipe" })
			}) : null,
			dialog.kind === "entry" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntryDialog, {
				entry: dialog.entry,
				onClose: closeDialog,
				onSave: saveEntry
			}) : null,
			dialog.kind === "delete" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				title: "Entry hatao?",
				body: `${dialog.entry.email} aur uska security code is device se mit jayega.`,
				confirmLabel: "Hatao",
				danger: true,
				onClose: closeDialog,
				onConfirm: () => removeEntry(dialog.entry.id)
			}) : null,
			dialog.kind === "pass" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PassDialog, {
				onClose: closeDialog,
				onSubmit: changePass
			}) : null,
			dialog.kind === "wipe" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WipeDialog, {
				onClose: closeDialog,
				onConfirm: wipe
			}) : null,
			dialog.kind === "import" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				title: "Backup se badlo?",
				body: "Purani entries is device se hat jayengi. Nayi file ki passphrase se tijori khulegi.",
				confirmLabel: "Badal do",
				danger: true,
				onClose: closeDialog,
				onConfirm: () => commitImport(dialog.file)
			}) : null
		]
	});
}
function BootScreen() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gate, {
		title: "Tijori",
		lede: "Email aur security code, sirf is device par."
	});
}
function SetupScreen({ onCreate, onImport }) {
	const [passphrase, setPassphrase] = (0, import_react.useState)("");
	const [again, setAgain] = (0, import_react.useState)("");
	const [hint, setHint] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function submit(event) {
		event.preventDefault();
		if (passphrase.length < 6) {
			setError("Kam se kam 6 akshar. Lamba rakho to safer.");
			return;
		}
		if (passphrase !== again) {
			setError("Dono passphrase same nahi hain.");
			return;
		}
		setBusy(true);
		setError(null);
		try {
			await onCreate(passphrase, hint);
		} catch (err) {
			setError(err instanceof Error ? err.message : "Tijori nahi bani.");
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Gate, {
		title: "Apna lock lagao",
		lede: "50 email aur 50 security code. Sab kuch is browser ke andar encrypt hota hai — server par nahi jaata.",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex flex-col gap-4",
				onSubmit: submit,
				autoComplete: "off",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecretField, {
						id: "setup-pass",
						label: "Master passphrase",
						value: passphrase,
						onChange: setPassphrase,
						autoComplete: "new-password",
						autoFocus: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: strengthLine(passphrase)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecretField, {
						id: "setup-pass2",
						label: "Phir se likho",
						value: again,
						onChange: setAgain,
						autoComplete: "new-password"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Hint (zaruri nahi)",
						hint: "Lock screen par dikhega. Asli passphrase mat likhna.",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "setup-hint",
							className: cn(controlClass, "h-12"),
							value: hint,
							maxLength: 80,
							onChange: (event) => setHint(event.target.value),
							placeholder: "jaise: purana ghar",
							autoComplete: "off"
						})
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						role: "alert",
						className: "text-sm text-danger",
						children: error
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrassButton, {
						type: "submit",
						disabled: busy,
						children: busy ? "Bana rahe hain…" : "Tijori banao"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-6 flex flex-col gap-2 text-sm leading-relaxed text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Passphrase hum save nahi karte. Bhool gaye to entries nahi khulengi." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Browser data clear karoge to tijori bhi mit jayegi. Backup rakhna." })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImportLabel, {
				className: "mt-4",
				onFile: onImport,
				label: "Purani backup lao"
			})
		]
	});
}
function LockScreen({ hint, onUnlock, onImport, onWipe }) {
	const [passphrase, setPassphrase] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function submit(event) {
		event.preventDefault();
		setBusy(true);
		setError(null);
		try {
			await onUnlock(passphrase);
		} catch (err) {
			setError(err instanceof Error ? err.message : "Nahi khuli.");
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Gate, {
		title: "Tijori band hai",
		lede: "Master passphrase se kholo. Codes tab tak chhupe rehte hain.",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "flex flex-col gap-4",
			onSubmit: submit,
			autoComplete: "off",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecretField, {
					id: "unlock-pass",
					label: "Master passphrase",
					value: passphrase,
					onChange: setPassphrase,
					autoComplete: "current-password",
					autoFocus: true
				}),
				hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: ["Hint: ", hint]
				}) : null,
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					role: "alert",
					className: "text-sm text-danger",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrassButton, {
					type: "submit",
					disabled: busy || passphrase.length === 0,
					children: busy ? "Khol rahe hain…" : "Kholo"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 flex flex-col gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImportLabel, {
				onFile: onImport,
				label: "Backup file lao"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onWipe,
				className: "h-11 text-sm text-muted",
				children: "Is device se tijori mitao"
			})]
		})]
	});
}
function CorruptScreen({ onImport, onWipe }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gate, {
		title: "Vault padh nahi paayi",
		lede: "File kharab lag rahi hai. Backup hai to lao, warna nayi tijori banao. Purani entries bina passphrase ke nahi khulengi.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImportLabel, {
				onFile: onImport,
				label: "Backup file lao",
				primary: true
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
				type: "button",
				onClick: onWipe,
				children: "Nayi tijori ke liye purani mitao"
			})]
		})
	});
}
function OpenScreen({ entries, visible, query, revealed, copied, onQuery, onToggle, onCopy, onAdd, onEdit, onDelete, onLock, onExport, onImport, onPass, onWipe }) {
	const full = entries.length >= 50;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex w-full max-w-5xl flex-1 flex-col md:flex-row",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "flex flex-col gap-5 border-b border-line px-5 py-5 md:sticky md:top-0 md:h-dvh md:w-80 md:shrink-0 md:overflow-y-auto md:border-r md:border-b-0 md:px-6 md:py-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brand, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onLock,
							"aria-label": "Band karo",
							className: "grid size-12 place-items-center rounded-full border border-line text-fg md:hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LockKeyhole, {
								className: "size-5",
								strokeWidth: 1.75
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slots, { used: entries.length }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm leading-relaxed text-muted",
						children: "Sirf is browser mein. 3 minute chup rehne par khud band ho jayegi."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsBlock, {
						onExport,
						onImport,
						onPass,
						onWipe
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-auto hidden pt-4 md:block",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BrassButton, {
							type: "button",
							onClick: onLock,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LockKeyhole, { className: "size-4" }), "Band karo"]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "flex min-w-0 flex-1 flex-col px-5 pt-5 pb-28 md:px-8 md:pt-8 md:pb-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
							className: "pointer-events-none absolute top-1/2 left-4 size-4 -translate-y-1/2 text-muted",
							"aria-hidden": "true"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "search",
							value: query,
							onChange: (event) => onQuery(event.target.value),
							placeholder: "Email ya naam dhoondo",
							"aria-label": "Email ya naam dhoondo",
							className: cn(controlClass, "h-12 rounded-full pr-4 pl-11")
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BrassButton, {
						type: "button",
						onClick: onAdd,
						disabled: full,
						className: "hidden w-auto shrink-0 px-5 md:flex",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "Naya code"]
					})]
				}), entries.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-center px-4 py-16 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-14 place-items-center rounded-2xl border border-line text-brass",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, {
								className: "size-7",
								strokeWidth: 1.75
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-4 font-display text-3xl text-fg",
							children: "Abhi khali hai"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 max-w-xs text-sm leading-relaxed text-muted",
							children: "Pehla email aur uska security code add karo. 50 jagah hain — har jagah ek email, ek code."
						})
					]
				}) : visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "py-16 text-center text-sm text-muted",
					children: "Is search se kuch nahi mila."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-5 flex flex-col gap-3",
					children: visible.map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntryCard, {
						entry,
						shown: Boolean(revealed[entry.id]),
						copied,
						onToggle: () => onToggle(entry.id),
						onCopy: (field) => onCopy(entry, field),
						onEdit: () => onEdit(entry),
						onDelete: () => onDelete(entry)
					}) }, entry.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-x-0 bottom-0 z-20 border-t border-line bg-bg p-4 md:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BrassButton, {
					type: "button",
					onClick: onAdd,
					disabled: full,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), full ? "50 full hain" : "Naya code"]
				})
			})
		]
	});
}
function EntryCard({ entry, shown, copied, onToggle, onCopy, onEdit, onDelete }) {
	const emailCopied = copied?.id === entry.id && copied.field === "email";
	const codeCopied = copied?.id === entry.id && copied.field === "code";
	const when = new Intl.DateTimeFormat("en-IN", {
		day: "numeric",
		month: "short"
	}).format(entry.updatedAt);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-card border border-line bg-surface p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "truncate text-base font-medium text-fg",
						children: entry.name || "Bina naam"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-sm text-muted",
						title: entry.email,
						children: entry.email
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "shrink-0 text-xs text-muted",
					children: when
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex items-start gap-2 rounded-xl bg-bg px-3 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "min-w-0 flex-1 font-mono text-sm leading-relaxed break-all whitespace-pre-wrap text-fg",
					children: shown ? entry.code : "••••  ••••  ••••"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onToggle,
					"aria-pressed": shown,
					"aria-label": shown ? "Code chhupao" : "Code dikhao",
					className: "grid size-11 shrink-0 place-items-center rounded-full text-muted",
					children: shown ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-5" })
				})]
			}),
			entry.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 line-clamp-2 text-sm text-muted",
				children: entry.note
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(GhostButton, {
					type: "button",
					onClick: () => onCopy("email"),
					className: "h-11 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" }), emailCopied ? "Ho gaya" : "Email"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(GhostButton, {
					type: "button",
					onClick: () => onCopy("code"),
					className: "h-11 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" }), codeCopied ? "Ho gaya" : "Code"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-1 flex justify-end gap-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onEdit,
					className: "h-11 px-3 text-sm text-muted",
					children: "Badlo"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onDelete,
					className: "h-11 px-3 text-sm text-danger",
					children: "Hatao"
				})]
			})
		]
	});
}
function SettingsBlock({ onExport, onImport, onPass, onWipe }) {
	const buttons = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
				type: "button",
				onClick: onExport,
				className: "h-11",
				children: "Backup nikalo"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImportLabel, {
				onFile: onImport,
				label: "Backup lao"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
				type: "button",
				onClick: onPass,
				className: "h-11",
				children: "Passphrase badlo"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onWipe,
				className: "h-11 text-sm text-danger",
				children: "Poori tijori mitao"
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
		className: "group md:hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("summary", {
			className: "flex h-12 list-none items-center justify-between text-sm text-fg",
			children: ["Backup aur settings", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-4 text-muted transition-transform duration-200 group-open:rotate-180" })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pb-2",
			children: buttons
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "hidden md:block",
		children: buttons
	})] });
}
function EntryDialog({ entry, onClose, onSave }) {
	const [name, setName] = (0, import_react.useState)(entry?.name ?? "");
	const [email, setEmail] = (0, import_react.useState)(entry?.email ?? "");
	const [code, setCode] = (0, import_react.useState)(entry?.code ?? "");
	const [note, setNote] = (0, import_react.useState)(entry?.note ?? "");
	const [error, setError] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function submit(event) {
		event.preventDefault();
		const cleanEmail = email.trim();
		const cleanCode = code.trim();
		if (!EMAIL_OK.test(cleanEmail)) {
			setError("Email poora likho — jaise naam@email.com");
			return;
		}
		if (!cleanCode) {
			setError("Security code likho.");
			return;
		}
		if (name.trim().length > 60 || cleanCode.length > 2e3 || note.trim().length > 500) {
			setError("Bahut lamba hai. Thoda chhota karo.");
			return;
		}
		setBusy(true);
		setError(null);
		try {
			await onSave({
				id: entry?.id ?? crypto.randomUUID(),
				name: name.trim(),
				email: cleanEmail,
				code: cleanCode,
				note: note.trim(),
				updatedAt: Date.now()
			});
		} catch (err) {
			setError(err instanceof Error ? err.message : "Save nahi hua.");
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
		title: entry ? "Entry badlo" : "Nayi entry",
		onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "flex flex-col gap-4",
			onSubmit: submit,
			autoComplete: "off",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Naam",
					hint: "Jaise Gmail, bank, Instagram",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "entry-name",
						className: cn(controlClass, "h-12"),
						value: name,
						onChange: (event) => setName(event.target.value),
						placeholder: "Gmail",
						autoComplete: "off",
						autoFocus: true
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Email",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "entry-email",
						type: "email",
						inputMode: "email",
						className: cn(controlClass, "h-12"),
						value: email,
						onChange: (event) => setEmail(event.target.value),
						placeholder: "naam@email.com",
						autoComplete: "off",
						spellCheck: false
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Security code",
					hint: "Ek se zyada ho to nayi line par likho.",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						id: "entry-code",
						className: cn(controlClass, "min-h-28 resize-y py-3 font-mono text-sm"),
						value: code,
						onChange: (event) => setCode(event.target.value),
						placeholder: "security code",
						autoComplete: "off",
						spellCheck: false,
						rows: 4
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Note",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "entry-note",
						className: cn(controlClass, "h-12"),
						value: note,
						onChange: (event) => setNote(event.target.value),
						placeholder: "optional",
						autoComplete: "off"
					})
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					role: "alert",
					className: "text-sm text-danger",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
						type: "button",
						onClick: onClose,
						children: "Rehne do"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrassButton, {
						type: "submit",
						disabled: busy,
						children: busy ? "Save…" : "Save karo"
					})]
				})
			]
		})
	});
}
function PassDialog({ onClose, onSubmit }) {
	const [oldPass, setOldPass] = (0, import_react.useState)("");
	const [newPass, setNewPass] = (0, import_react.useState)("");
	const [again, setAgain] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function submit(event) {
		event.preventDefault();
		if (newPass.length < 6) {
			setError("Nayi passphrase kam se kam 6 akshar.");
			return;
		}
		if (newPass !== again) {
			setError("Nayi passphrase match nahi kar rahi.");
			return;
		}
		setBusy(true);
		setError(null);
		try {
			await onSubmit(oldPass, newPass);
		} catch (err) {
			setError(err instanceof Error ? err.message : "Nahi badli.");
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
		title: "Passphrase badlo",
		onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "flex flex-col gap-4",
			onSubmit: submit,
			autoComplete: "off",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecretField, {
					id: "old-pass",
					label: "Purani passphrase",
					value: oldPass,
					onChange: setOldPass,
					autoComplete: "current-password",
					autoFocus: true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecretField, {
					id: "new-pass",
					label: "Nayi passphrase",
					value: newPass,
					onChange: setNewPass,
					autoComplete: "new-password"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecretField, {
					id: "new-pass2",
					label: "Nayi phir se",
					value: again,
					onChange: setAgain,
					autoComplete: "new-password"
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					role: "alert",
					className: "text-sm text-danger",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
						type: "button",
						onClick: onClose,
						children: "Rehne do"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrassButton, {
						type: "submit",
						disabled: busy,
						children: busy ? "Badal rahe…" : "Badlo"
					})]
				})
			]
		})
	});
}
function WipeDialog({ onClose, onConfirm }) {
	const [phrase, setPhrase] = (0, import_react.useState)("");
	const ready = phrase.trim() === "MITAO";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
		title: "Poori tijori mitao?",
		onClose,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm leading-relaxed text-muted",
			children: "Saari entries is device se khatam. Jo backup pehle download ki hai, woh file nahi mitegi. Wapas nahi aayega."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "mt-4 flex flex-col gap-4",
			onSubmit: (event) => {
				event.preventDefault();
				if (ready) onConfirm();
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "MITAO likho",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: cn(controlClass, "h-12"),
					value: phrase,
					onChange: (event) => setPhrase(event.target.value),
					placeholder: "MITAO",
					autoComplete: "off",
					autoFocus: true,
					"aria-label": "MITAO likho"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
					type: "button",
					onClick: onClose,
					children: "Rehne do"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					disabled: !ready,
					className: "flex h-12 items-center justify-center rounded-full bg-danger px-4 text-sm font-medium text-brass-ink disabled:opacity-50",
					children: "Mitao"
				})]
			})]
		})]
	});
}
function ConfirmDialog({ title, body, confirmLabel, danger, onClose, onConfirm }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
		title,
		onClose,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm leading-relaxed text-muted",
			children: body
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-5 grid grid-cols-2 gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GhostButton, {
				type: "button",
				onClick: onClose,
				children: "Rehne do"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onConfirm,
				className: cn("flex h-12 items-center justify-center rounded-full px-4 text-sm font-medium", danger ? "bg-danger text-brass-ink" : "bg-brass text-brass-ink"),
				children: confirmLabel
			})]
		})]
	});
}
function Gate({ title, lede, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex w-full max-w-md flex-1 flex-col justify-center px-5 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brand, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-8 font-display text-4xl leading-tight text-fg",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-base leading-relaxed text-muted",
				children: lede
			}),
			children ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8",
				children
			}) : null
		]
	});
}
function Brand() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "grid size-12 shrink-0 place-items-center rounded-2xl border border-line bg-surface text-brass",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LockKeyhole, {
				className: "size-6",
				strokeWidth: 1.75
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-medium tracking-widest text-brass uppercase",
			children: "Tijori"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: "Private email locker"
		})] })]
	});
}
function Slots({ used }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "text-sm text-muted",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-display text-3xl text-fg",
			children: used
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
			" / ",
			50,
			" bhare"
		] })]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-3 grid grid-cols-10 gap-1",
		"aria-hidden": "true",
		children: Array.from({ length: 50 }, (_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("h-1.5 rounded-full", index < used ? "bg-brass" : "bg-line") }, index))
	})] });
}
function Sheet({ title, onClose, children }) {
	const titleId = (0, import_react.useId)();
	(0, import_react.useEffect)(() => {
		const onKey = (event) => {
			if (event.key === "Escape") onClose();
		};
		document.addEventListener("keydown", onKey);
		const previous = document.body.style.overflow;
		document.body.style.overflow = "hidden";
		return () => {
			document.removeEventListener("keydown", onKey);
			document.body.style.overflow = previous;
		};
	}, [onClose]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-50 flex items-end justify-center sm:items-center sm:p-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-modal": "true",
			"aria-labelledby": titleId,
			className: "relative z-10 max-h-dvh w-full max-w-md overflow-y-auto rounded-t-card border border-line bg-surface p-5 pb-8 sm:rounded-card sm:pb-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				id: titleId,
				className: "font-display text-3xl leading-tight text-fg",
				children: title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5",
				children
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "absolute inset-0 bg-bg/80",
			"aria-label": "Band karo",
			onClick: onClose
		})]
	});
}
function Field({ label, hint, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "flex flex-col gap-2 text-sm text-muted",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-medium text-fg",
				children: label
			}),
			children,
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: hint }) : null
		]
	});
}
function SecretField({ id, label, value, onChange, autoComplete, autoFocus }) {
	const [show, setShow] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
			htmlFor: id,
			className: "text-sm font-medium text-fg",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				id,
				type: show ? "text" : "password",
				value,
				onChange: (event) => onChange(event.target.value),
				autoComplete,
				autoFocus,
				spellCheck: false,
				className: cn(controlClass, "h-12 pr-14")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setShow((current) => !current),
				"aria-label": show ? "Chhupao" : "Dikhao",
				className: "absolute top-1 right-1 grid size-10 place-items-center rounded-full text-muted",
				children: show ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-4" })
			})]
		})]
	});
}
function ImportLabel({ onFile, label, className, primary }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: cn("flex h-12 cursor-pointer items-center justify-center rounded-full px-4 text-sm font-medium", primary ? "bg-brass text-brass-ink" : "border border-line text-fg", className),
		children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type: "file",
			accept: "application/json,.json",
			className: "sr-only",
			onChange: (event) => {
				const file = event.target.files?.[0];
				event.target.value = "";
				if (file) onFile(file);
			}
		})]
	});
}
function BrassButton({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		...props,
		className: cn("flex h-12 w-full items-center justify-center gap-2 rounded-full bg-brass px-5 text-base font-medium text-brass-ink transition-opacity duration-200 hover:opacity-90 disabled:opacity-50", className),
		children
	});
}
function GhostButton({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		...props,
		className: cn("flex h-12 w-full items-center justify-center gap-2 rounded-full border border-line bg-transparent px-4 text-sm font-medium text-fg transition-colors duration-200 hover:bg-surface-2 disabled:opacity-50", className),
		children
	});
}
function strengthLine(passphrase) {
	if (!passphrase) return "Yahi passphrase baad mein tijori kholegi.";
	if (passphrase.length < 6) return "Kam se kam 6 akshar.";
	if (passphrase.length < 10) return "Chhota hai — lamba rakho to safer.";
	return "Mazboot lag raha hai.";
}
var SplitComponent = VaultApp;
//#endregion
export { SplitComponent as component };
