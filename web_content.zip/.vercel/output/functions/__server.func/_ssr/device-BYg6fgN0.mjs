import { i as __toESM } from "../_runtime.mjs";
import { q as require_react, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as Smartphone } from "../_libs/lucide-react.mjs";
import { n as ScreenBody, t as AppShell } from "./app-shell-BNnfZJ-W.mjs";
import { i as ScreenHeader, n as InfoRow, r as Panel, t as IconBadge } from "./screen-header-3v0iR4cd.mjs";
import { n as readDevice } from "./web-device-D_Jv2ve6.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/device-BYg6fgN0.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DevicePage() {
	const [device, setDevice] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		readDevice().then(setDevice);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ScreenBody, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScreenHeader, {
			title: "Device Info",
			subtitle: "Hardware and software reported by this device."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBadge, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smartphone, { className: "size-5" }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-4 text-2xl font-semibold tracking-tight text-fg",
				children: device?.model ?? "Reading…"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: device?.manufacturer ?? ""
			})
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3.5 flex flex-col gap-2.5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
					label: "Device model",
					value: device?.model ?? "..."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
					label: "Manufacturer",
					value: device?.manufacturer ?? "..."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
					label: "Android / OS",
					value: device?.androidVersion ?? "..."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
					label: "SDK version",
					value: device?.sdk ?? "..."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
					label: "Platform",
					value: device?.platform ?? "..."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
					label: "CPU cores",
					value: device?.cores ?? "..."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
					label: "Device memory",
					value: device?.memory ?? "..."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
					label: "Screen",
					value: device?.screen ?? "..."
				})
			]
		})
	] }) });
}
//#endregion
export { DevicePage as component };
