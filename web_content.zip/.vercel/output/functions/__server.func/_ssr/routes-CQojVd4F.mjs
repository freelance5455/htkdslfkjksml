import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Power, r as Cpu } from "../_libs/lucide-react.mjs";
import { i as ResponsiveContainer, n as YAxis, r as Area, t as AreaChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CQojVd4F.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function HashChart({ data }) {
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setReady(true), []);
	if (!ready || data.length < 2) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex h-24 items-center border border-muted/25 bg-bg px-3 font-mono text-xs text-muted",
		children: "Trace arms once the rig is hashing"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-24 w-full min-w-0 border border-muted/25 bg-bg",
		role: "img",
		"aria-label": "Hashrate over recent seconds",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
			width: "100%",
			height: "100%",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
				data,
				margin: {
					top: 8,
					right: 0,
					left: 0,
					bottom: 0
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
					hide: true,
					domain: [0, "auto"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
					type: "monotone",
					dataKey: "hps",
					stroke: "var(--color-brass)",
					fill: "var(--color-brass)",
					fillOpacity: .16,
					strokeWidth: 1.5,
					isAnimationActive: false
				})]
			})
		})
	});
}
var K = new Uint32Array([
	1116352408,
	1899447441,
	3049323471,
	3921009573,
	961987163,
	1508970993,
	2453635748,
	2870763221,
	3624381080,
	310598401,
	607225278,
	1426881987,
	1925078388,
	2162078206,
	2614888103,
	3248222580,
	3835390401,
	4022224774,
	264347078,
	604807628,
	770255983,
	1249150122,
	1555081692,
	1996064986,
	2554220882,
	2821834349,
	2952996808,
	3210313671,
	3336571891,
	3584528711,
	113926993,
	338241895,
	666307205,
	773529912,
	1294757372,
	1396182291,
	1695183700,
	1986661051,
	2177026350,
	2456956037,
	2730485921,
	2820302411,
	3259730800,
	3345764771,
	3516065817,
	3600352804,
	4094571909,
	275423344,
	430227734,
	506948616,
	659060556,
	883997877,
	958139571,
	1322822218,
	1537002063,
	1747873779,
	1955562222,
	2024104815,
	2227730452,
	2361852424,
	2428436474,
	2756734187,
	3204031479,
	3329325298
]);
var HEX = "0123456789abcdef";
function rotr(x, n) {
	return x >>> n | x << 32 - n;
}
function ivInto(h) {
	h[0] = 1779033703;
	h[1] = 3144134277;
	h[2] = 1013904242;
	h[3] = 2773480762;
	h[4] = 1359893119;
	h[5] = 2600822924;
	h[6] = 528734635;
	h[7] = 1541459225;
}
function compress(h, w) {
	for (let t = 16; t < 64; t++) {
		const w15 = w[t - 15];
		const w2 = w[t - 2];
		const s0 = rotr(w15, 7) ^ rotr(w15, 18) ^ w15 >>> 3 | 0;
		const s1 = rotr(w2, 17) ^ rotr(w2, 19) ^ w2 >>> 10 | 0;
		w[t] = w[t - 16] + s0 + w[t - 7] + s1 | 0;
	}
	let a = h[0] | 0;
	let b = h[1] | 0;
	let c = h[2] | 0;
	let d = h[3] | 0;
	let e = h[4] | 0;
	let f = h[5] | 0;
	let g = h[6] | 0;
	let hh = h[7] | 0;
	for (let t = 0; t < 64; t++) {
		const s1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25) | 0;
		const ch = e & f ^ ~e & g | 0;
		const temp1 = hh + s1 + ch + K[t] + w[t] | 0;
		const temp2 = (rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22) | 0) + (a & b ^ a & c ^ b & c | 0) | 0;
		hh = g;
		g = f;
		f = e;
		e = d + temp1 | 0;
		d = c;
		c = b;
		b = a;
		a = temp1 + temp2 | 0;
	}
	h[0] = h[0] + a | 0;
	h[1] = h[1] + b | 0;
	h[2] = h[2] + c | 0;
	h[3] = h[3] + d | 0;
	h[4] = h[4] + e | 0;
	h[5] = h[5] + f | 0;
	h[6] = h[6] + g | 0;
	h[7] = h[7] + hh | 0;
}
function bytesToHex(bytes) {
	let s = "";
	for (let i = 0; i < bytes.length; i++) {
		const b = bytes[i] ?? 0;
		s += HEX[b >> 4] + HEX[b & 15];
	}
	return s;
}
function hexToBytes(hex) {
	if (hex.length % 2 !== 0 || /[^0-9a-f]/i.test(hex)) throw new Error("bad hex");
	const out = new Uint8Array(hex.length / 2);
	for (let i = 0; i < out.length; i++) out[i] = Number.parseInt(hex.slice(i * 2, i * 2 + 2), 16);
	return out;
}
function wordsToBytes(words) {
	const out = /* @__PURE__ */ new Uint8Array(32);
	const view = new DataView(out.buffer);
	for (let i = 0; i < 8; i++) view.setUint32(i * 4, words[i] >>> 0);
	return out;
}
function sha256Bytes(message) {
	const len = message.length;
	const bitLen = len * 8;
	const padLen = len + 9 + 63 & -64;
	const buf = new Uint8Array(padLen);
	buf.set(message);
	buf[len] = 128;
	const view = new DataView(buf.buffer);
	view.setUint32(padLen - 8, Math.floor(bitLen / 2 ** 32));
	view.setUint32(padLen - 4, bitLen >>> 0);
	const state = /* @__PURE__ */ new Uint32Array(8);
	ivInto(state);
	const w = /* @__PURE__ */ new Uint32Array(64);
	for (let off = 0; off < padLen; off += 64) {
		for (let i = 0; i < 16; i++) w[i] = view.getUint32(off + i * 4);
		compress(state, w);
	}
	return wordsToBytes(state);
}
function dsha256(message) {
	return sha256Bytes(sha256Bytes(message));
}
function leadingZeroBitsHex(hex) {
	let bits = 0;
	for (let i = 0; i < hex.length; i++) {
		const v = Number.parseInt(hex[i] ?? "", 16);
		if (v === 0) {
			bits += 4;
			continue;
		}
		if (v < 2) return bits + 3;
		if (v < 4) return bits + 2;
		if (v < 8) return bits + 1;
		return bits;
	}
	return bits;
}
/** Hot-path double SHA-256 of an 80-byte header. Midstate is the first 64 bytes. */
var HeaderMiner = class {
	w = /* @__PURE__ */ new Uint32Array(64);
	mid = /* @__PURE__ */ new Uint32Array(8);
	st = /* @__PURE__ */ new Uint32Array(8);
	out = /* @__PURE__ */ new Uint32Array(8);
	chunk = /* @__PURE__ */ new Uint32Array(16);
	load(head, tail0, tail1, tail2) {
		if (head.byteLength < 64) throw new Error("short header");
		const view = new DataView(head.buffer, head.byteOffset, 64);
		const w = this.w;
		for (let i = 0; i < 16; i++) w[i] = view.getUint32(i * 4);
		ivInto(this.mid);
		compress(this.mid, w);
		this.chunk.fill(0);
		this.chunk[0] = tail0;
		this.chunk[1] = tail1;
		this.chunk[2] = tail2;
		this.chunk[4] = 2147483648;
		this.chunk[15] = 640;
	}
	/** Leading zero bits of the byte-reversed digest — Bitcoin’s display order. */
	hashNonce(nonce) {
		const w = this.w;
		const chunk = this.chunk;
		chunk[3] = nonce >>> 0;
		for (let i = 0; i < 16; i++) w[i] = chunk[i];
		const st = this.st;
		const mid = this.mid;
		for (let i = 0; i < 8; i++) st[i] = mid[i];
		compress(st, w);
		for (let i = 0; i < 8; i++) w[i] = st[i] >>> 0;
		w[8] = 2147483648;
		for (let i = 9; i < 15; i++) w[i] = 0;
		w[15] = 256;
		const out = this.out;
		ivInto(out);
		compress(out, w);
		let bits = 0;
		for (let i = 7; i >= 0; i--) {
			const word = out[i];
			const b0 = word & 255;
			if (b0 !== 0) return bits + Math.clz32(b0) - 24;
			const b1 = word >>> 8 & 255;
			if (b1 !== 0) return bits + 8 + Math.clz32(b1) - 24;
			const b2 = word >>> 16 & 255;
			if (b2 !== 0) return bits + 16 + Math.clz32(b2) - 24;
			const b3 = word >>> 24 & 255;
			if (b3 !== 0) return bits + 24 + Math.clz32(b3) - 24;
			bits += 32;
		}
		return bits;
	}
	/** Block-hash order: digest bytes reversed so work shows up as leading zeros. */
	hex() {
		let s = "";
		const out = this.out;
		for (let i = 7; i >= 0; i--) {
			const v = out[i];
			const bytes = [
				v & 255,
				v >>> 8 & 255,
				v >>> 16 & 255,
				v >>> 24 & 255
			];
			for (let b = 0; b < 4; b++) {
				const byte = bytes[b] ?? 0;
				s += HEX[byte >> 4] + HEX[byte & 15];
			}
		}
		return s;
	}
};
var shared = new HeaderMiner();
function hashHeaderHex(header) {
	const view = new DataView(header.buffer, header.byteOffset, header.byteLength);
	shared.load(header.subarray(0, 64), view.getUint32(64), view.getUint32(68), view.getUint32(72));
	shared.hashNonce(view.getUint32(76));
	return shared.hex();
}
var GENESIS_MINER = "lode1" + "0".repeat(32);
var text = new TextEncoder();
function encodeCompact(zeroBits) {
	return (1258291200 | zeroBits & 255) >>> 0;
}
function buildHeader(prev, merkle, time, compact, nonce) {
	const header = /* @__PURE__ */ new Uint8Array(80);
	const view = new DataView(header.buffer);
	view.setUint32(0, 1);
	header.set(prev, 4);
	header.set(merkle, 36);
	view.setUint32(68, time >>> 0);
	view.setUint32(72, compact >>> 0);
	view.setUint32(76, nonce >>> 0);
	return header;
}
function merkleFor(miner, height, extra, time) {
	return dsha256(text.encode(`kiln|v1|${height}|${extra}|${time}|${miner}`));
}
function makeGenesis() {
	const prev = /* @__PURE__ */ new Uint8Array(32);
	const time = 17e8;
	const bits = 0;
	const extra = 0;
	const nonce = 0;
	const header = buildHeader(prev, dsha256(text.encode("KILN/GENESIS/1")), time, encodeCompact(bits), nonce);
	return {
		height: 0,
		hash: hashHeaderHex(header),
		prev: bytesToHex(prev),
		header: bytesToHex(header),
		time,
		nonce,
		miner: GENESIS_MINER,
		reward: 0,
		bits,
		extra
	};
}
function isBlock(value) {
	if (!value || typeof value !== "object") return false;
	const b = value;
	return typeof b.hash === "string" && b.hash.length === 64 && typeof b.header === "string" && b.header.length === 160 && typeof b.prev === "string" && typeof b.miner === "string" && typeof b.height === "number" && typeof b.nonce === "number" && typeof b.time === "number" && typeof b.bits === "number" && typeof b.extra === "number" && typeof b.reward === "number";
}
/** Null when the block really extends `prev`. */
function explain(block, prev) {
	if (!isBlock(block)) return "malformed";
	if (!prev) {
		const genesis = makeGenesis();
		if (block.hash !== genesis.hash || block.header !== genesis.header) return "genesis";
		return null;
	}
	if (block.height !== prev.height + 1) return "height";
	if (block.prev !== prev.hash) return "prev";
	if (block.reward !== 25) return "reward";
	let header;
	try {
		header = hexToBytes(block.header);
	} catch {
		return "header";
	}
	if (header.length !== 80) return "length";
	const view = new DataView(header.buffer, header.byteOffset, 80);
	if (bytesToHex(header.subarray(4, 36)) !== prev.hash) return "header prev";
	const expectMerkle = merkleFor(block.miner, block.height, block.extra, block.time);
	if (bytesToHex(header.subarray(36, 68)) !== bytesToHex(expectMerkle)) return "merkle";
	if (view.getUint32(68) !== block.time >>> 0) return "time";
	if (view.getUint32(72) !== encodeCompact(block.bits)) return "compact";
	if (view.getUint32(76) !== block.nonce >>> 0) return "nonce";
	const hash = hashHeaderHex(header);
	if (hash !== block.hash) return "hash";
	if (leadingZeroBitsHex(hash) < block.bits) return "target";
	return null;
}
function audit(stored) {
	const notes = [];
	const genesis = makeGenesis();
	const blocks = [genesis];
	if (!Array.isArray(stored) || stored.length === 0) return {
		blocks,
		notes
	};
	if (!stored[0] || stored[0].hash !== genesis.hash) notes.push("genesis checkpoint restored");
	for (let i = 1; i < stored.length && blocks.length < 400; i++) {
		const candidate = stored[i];
		if (!isBlock(candidate)) {
			notes.push("dropped a malformed tail");
			break;
		}
		const prev = blocks[blocks.length - 1];
		if (!prev) break;
		const reason = explain(candidate, prev);
		if (reason) {
			notes.push(`dropped tail at height ${candidate.height} (${reason})`);
			break;
		}
		blocks.push(candidate);
	}
	return {
		blocks,
		notes
	};
}
function balanceOf(blocks, miner) {
	let total = 0;
	for (const block of blocks) if (block.miner === miner) total += block.reward;
	return total;
}
function normalizeWallet(input) {
	const value = input.trim();
	if (value.length < 8 || value.length > 90) return null;
	if (!/^[A-Za-z0-9:_-]+$/.test(value)) return null;
	return value;
}
function mintAddress() {
	const bytes = /* @__PURE__ */ new Uint8Array(16);
	crypto.getRandomValues(bytes);
	return `lode1${bytesToHex(bytes)}`;
}
function shortId(value, head = 10, tail = 6) {
	if (value.length <= head + tail + 1) return value;
	return `${value.slice(0, head)}…${value.slice(-tail)}`;
}
var WALLET_KEY = "kiln.wallet.v1";
var THREAD_KEY = "kiln.threads.v1";
var CHAIN_KEY = "kiln.chain.v1";
var MAX_THREADS = 4;
function clamp(n, lo, hi) {
	return Math.max(lo, Math.min(hi, n));
}
function deadband(current, ideal) {
	if (Math.abs(ideal - current) < .85) return current;
	return Math.round(ideal);
}
var EMPTY_SNAPSHOT = {
	booted: false,
	running: false,
	wallet: "",
	threads: 2,
	cores: 0,
	hps: 0,
	accepted: 0,
	rejected: 0,
	sessionBlocks: 0,
	sessionHashes: 0,
	height: 0,
	balance: 0,
	shareBits: 18,
	blockBits: 22,
	jobId: 0,
	uptime: 0,
	lastShare: "",
	tip: "",
	logs: [{
		id: 0,
		t: 0,
		src: "kiln",
		msg: "booting local pool…",
		tone: "info"
	}],
	samples: [],
	chain: []
};
var MinerEngine = class {
	onEmit;
	chain = [makeGenesis()];
	logs = [];
	samples = [];
	workers = [];
	timer = 0;
	logId = 0;
	dirty = false;
	wallet = "";
	threads = 2;
	cores = 1;
	running = false;
	hps = 0;
	accepted = 0;
	rejected = 0;
	sessionBlocks = 0;
	sessionHashes = 0;
	hashesSinceTick = 0;
	lastTick = 0;
	lastRetarget = 0;
	startedAt = 0;
	shareBits = 18;
	blockBits = 22;
	jobId = 0;
	jobTime = 0;
	jobHeight = 0;
	jobExtra = 0;
	jobPrev = "";
	jobBits = 22;
	jobShareBits = 18;
	extra = 0;
	lastShare = "";
	booted = false;
	constructor(onEmit) {
		this.onEmit = onEmit;
	}
	boot() {
		if (this.booted) return;
		this.booted = true;
		this.cores = typeof navigator !== "undefined" && navigator.hardwareConcurrency ? navigator.hardwareConcurrency : 1;
		const storedWallet = readStorage(WALLET_KEY);
		const wallet = storedWallet ? normalizeWallet(storedWallet) : null;
		this.wallet = wallet ?? mintAddress();
		writeStorage(WALLET_KEY, this.wallet);
		const storedThreads = Number(readStorage(THREAD_KEY));
		this.threads = clamp(Number.isFinite(storedThreads) && storedThreads > 0 ? storedThreads : 2, 1, MAX_THREADS);
		let parsed = null;
		try {
			const raw = readStorage(CHAIN_KEY);
			parsed = raw ? JSON.parse(raw) : null;
		} catch {
			parsed = null;
		}
		const audited = audit(parsed);
		this.chain = audited.blocks;
		for (const note of audited.notes) this.log("kiln", note, "warn");
		this.log("kiln", "pool kiln://local online   fee 0%   nothing leaves this browser");
		this.log("kiln", "hashing is real SHA-256d on this CPU   the chain is local LODE, not mainnet");
		this.log("kiln", "type help, or start the rig");
		this.timer = window.setInterval(() => {
			if (!this.running && !this.dirty) return;
			this.flush();
		}, 250);
		this.flush();
	}
	destroy() {
		window.clearInterval(this.timer);
		this.running = false;
		this.killWorkers();
	}
	snapshot() {
		const tip = this.chain[this.chain.length - 1];
		return {
			booted: this.booted,
			running: this.running,
			wallet: this.wallet,
			threads: this.threads,
			cores: this.cores,
			hps: this.running ? this.hps : 0,
			accepted: this.accepted,
			rejected: this.rejected,
			sessionBlocks: this.sessionBlocks,
			sessionHashes: this.sessionHashes,
			height: tip ? tip.height : 0,
			balance: balanceOf(this.chain, this.wallet),
			shareBits: this.shareBits,
			blockBits: this.blockBits,
			jobId: this.jobId,
			uptime: this.running && this.startedAt ? (Date.now() - this.startedAt) / 1e3 : 0,
			lastShare: this.lastShare,
			tip: tip?.hash ?? "",
			logs: this.logs.slice(-180),
			samples: this.samples.slice(),
			chain: this.chain.slice(-8).reverse()
		};
	}
	start() {
		if (this.running) return;
		if (!this.wallet) {
			this.log("kiln", "set a payout address first", "warn");
			this.flush();
			return;
		}
		this.running = true;
		this.accepted = 0;
		this.rejected = 0;
		this.sessionBlocks = 0;
		this.sessionHashes = 0;
		this.hashesSinceTick = 0;
		this.lastTick = performance.now();
		this.lastRetarget = performance.now();
		this.startedAt = Date.now();
		this.hps = 0;
		this.samples = [];
		this.shareBits = 18;
		this.blockBits = 22;
		this.spawn();
		this.log("kiln", `spawned ${this.threads} cpu worker${this.threads === 1 ? "" : "s"} on this machine`);
		this.issueJob();
		this.flush();
	}
	stop() {
		if (!this.running) return;
		this.running = false;
		this.killWorkers();
		this.hps = 0;
		this.log("kiln", "workers halted");
		this.flush();
	}
	setThreads(n) {
		const next = clamp(Math.round(n), 1, MAX_THREADS);
		this.threads = next;
		writeStorage(THREAD_KEY, String(next));
		if (this.running) {
			this.spawn();
			this.log("kiln", `workers retuned to ${next}`);
			this.issueJob();
		}
		this.flush();
	}
	setWallet(input) {
		const addr = normalizeWallet(input);
		if (!addr) return false;
		this.applyWallet(addr);
		return true;
	}
	mintWallet() {
		const addr = mintAddress();
		this.applyWallet(addr);
		return addr;
	}
	resetChain() {
		if (this.running) this.stop();
		this.chain = [makeGenesis()];
		this.persistChain();
		this.lastShare = "";
		this.log("kiln", "local chain wiped back to genesis");
		this.flush();
	}
	verify(height) {
		const block = this.chain.find((item) => item.height === height);
		if (!block) {
			this.log("kiln", "no block at that height", "warn");
			this.flush();
			return;
		}
		const reason = explain(block, height === 0 ? null : this.chain[height - 1] ?? null);
		if (reason) this.log("pool", `verify height ${height} FAILED (${reason})`, "warn");
		else {
			const zeros = leadingZeroBitsHex(block.hash);
			this.log("pool", `verify height ${height}  sha256d ${block.hash.slice(0, 16)}…  ${height === 0 ? "checkpoint" : `${zeros} bits`}  ok`, "ok");
		}
		this.flush();
	}
	exec(line) {
		const raw = line.trim();
		if (!raw) return;
		this.log("you", raw);
		const [cmd, ...rest] = raw.split(/\s+/);
		const arg = rest.join(" ").trim();
		const name = (cmd ?? "").toLowerCase();
		if (name === "help") {
			this.log("kiln", "start · stop · threads N · wallet ADDR · mint · status");
			this.log("kiln", "balance · ledger · chain · job · verify H · diff · peers · reset confirm · clear");
		} else if (name === "start") this.start();
		else if (name === "stop") this.stop();
		else if (name === "threads") {
			const n = Number(arg);
			if (!arg || !Number.isFinite(n)) this.log("kiln", `threads ${this.threads}  (max ${MAX_THREADS})`);
			else this.setThreads(n);
		} else if (name === "wallet") {
			if (!arg) this.log("kiln", this.wallet);
			else if (!this.setWallet(arg)) this.log("kiln", "rejected — 8 to 90 of A–Z a–z 0–9 : _ -", "warn");
		} else if (name === "mint" || name === "address") this.mintWallet();
		else if (name === "status") this.printStatus();
		else if (name === "balance") this.log("kiln", `${balanceOf(this.chain, this.wallet)} LODE  ${this.wallet}`);
		else if (name === "ledger") this.printLedger();
		else if (name === "chain") this.printChain();
		else if (name === "job" || name === "jobs") {
			this.log("kiln", `job ${this.jobId}  next height ${this.chain.length}  coinbase ${this.wallet}`);
			this.log("kiln", `prev ${this.chain[this.chain.length - 1]?.hash ?? ""}`);
		} else if (name === "verify") this.verify(Number(arg));
		else if (name === "diff") {
			this.log("kiln", `share ${this.shareBits} bits   block ${this.blockBits} bits`);
			this.log("kiln", "pool retunes toward ~2.5 shares/s and a block about every 14s");
		} else if (name === "peers") this.log("kiln", "peers 0   this browser is the whole network");
		else if (name === "reset") {
			if (arg !== "confirm") this.log("kiln", "wipes the local chain. run: reset confirm", "warn");
			else this.resetChain();
		} else if (name === "clear") {
			this.logs = [];
			this.log("kiln", "scrollback cleared");
		} else this.log("kiln", `unknown '${name}' — try help`, "warn");
		this.flush();
	}
	printStatus() {
		const tip = this.chain[this.chain.length - 1];
		this.log("kiln", `height ${tip?.height ?? 0}  tip ${(tip?.hash ?? "").slice(0, 16)}…  balance ${balanceOf(this.chain, this.wallet)} LODE`);
		this.log("kiln", `${this.running ? "hashing" : "idle"}  ${Math.round(this.hps)} H/s  threads ${this.threads}  job ${this.jobId}`);
		this.log("kiln", `accepted ${this.accepted}  rejected ${this.rejected}  session blocks ${this.sessionBlocks}  hashes ${this.sessionHashes}`);
	}
	printLedger() {
		const totals = /* @__PURE__ */ new Map();
		for (const block of this.chain) {
			if (!block.reward) continue;
			totals.set(block.miner, (totals.get(block.miner) ?? 0) + block.reward);
		}
		if (totals.size === 0) {
			this.log("kiln", "no outputs yet — genesis pays nothing");
			return;
		}
		for (const [addr, amount] of totals) this.log("kiln", `${amount} LODE  ${addr}`);
	}
	printChain() {
		const recent = this.chain.slice(-6);
		for (const block of recent) this.log("kiln", `#${block.height}  ${block.hash.slice(0, 16)}…  +${block.reward}  ${block.bits} bits`);
	}
	applyWallet(addr) {
		const changed = addr !== this.wallet;
		this.wallet = addr;
		writeStorage(WALLET_KEY, addr);
		if (changed) this.log("kiln", `payout → ${addr}`);
		if (changed && this.running) this.issueJob();
		this.flush();
	}
	spawn() {
		this.killWorkers();
		for (let i = 0; i < this.threads; i++) {
			const worker = new Worker(new URL("./worker.ts", import.meta.url), { type: "module" });
			worker.onmessage = (event) => this.onWorker(event.data);
			worker.onerror = () => {
				this.log("cpu", "worker fault", "warn");
				this.dirty = true;
			};
			this.workers.push(worker);
		}
	}
	killWorkers() {
		for (const worker of this.workers) {
			worker.postMessage({ type: "stop" });
			worker.terminate();
		}
		this.workers = [];
	}
	issueJob() {
		if (!this.running || this.workers.length === 0) return;
		const prev = this.chain[this.chain.length - 1];
		if (!prev) return;
		const height = this.chain.length;
		const time = Math.floor(Date.now() / 1e3);
		this.extra = this.extra + 1 >>> 0;
		const merkle = merkleFor(this.wallet, height, this.extra, time);
		const header = buildHeader(hexToBytes(prev.hash), merkle, time, encodeCompact(this.blockBits), 0);
		const view = new DataView(header.buffer);
		this.jobId += 1;
		this.jobTime = time;
		this.jobHeight = height;
		this.jobExtra = this.extra;
		this.jobPrev = prev.hash;
		this.jobBits = this.blockBits;
		this.jobShareBits = this.shareBits;
		const head = header.slice(0, 64);
		const tail0 = view.getUint32(64);
		const tail1 = view.getUint32(68);
		const tail2 = view.getUint32(72);
		const step = this.workers.length;
		for (let index = 0; index < this.workers.length; index++) this.workers[index]?.postMessage({
			type: "job",
			jobId: this.jobId,
			head,
			tail0,
			tail1,
			tail2,
			shareBits: this.shareBits,
			blockBits: this.blockBits,
			nonceBase: index,
			nonceStep: step
		});
		this.log("pool", `job ${this.jobId}  next height ${height}  coinbase ${this.wallet}`);
	}
	onWorker(msg) {
		if (!msg || typeof msg !== "object") return;
		if (msg.type === "meter") {
			this.hashesSinceTick += msg.hashes;
			this.sessionHashes += msg.hashes;
			return;
		}
		if (!this.running || msg.jobId !== this.jobId) return;
		if (msg.type === "saturated") {
			this.shareBits = Math.min(30, this.shareBits + 2);
			this.blockBits = Math.max(this.blockBits, this.shareBits + 2);
			this.log("pool", `share flood — target now ${this.shareBits}/${this.blockBits} bits`);
			this.issueJob();
			this.flush();
			return;
		}
		this.onShare(msg);
	}
	onShare(msg) {
		const header = buildHeader(hexToBytes(this.jobPrev), merkleFor(this.wallet, this.jobHeight, this.jobExtra, this.jobTime), this.jobTime, encodeCompact(this.jobBits), msg.nonce >>> 0);
		const hash = hashHeaderHex(header);
		const zeros = leadingZeroBitsHex(hash);
		if (hash !== msg.hash || zeros < this.jobShareBits) {
			this.rejected += 1;
			this.log("pool", `reject nonce ${msg.nonce}`, "warn");
			this.flush();
			return;
		}
		this.accepted += 1;
		this.lastShare = hash.slice(0, 16);
		if (zeros >= this.jobBits) this.seal(header, hash, msg.nonce >>> 0);
		else this.log("cpu", `share ${hash.slice(0, 16)}  ${zeros} bits`);
		this.flush();
	}
	seal(header, hash, nonce) {
		if (this.chain.length >= 400) {
			this.log("pool", "ledger is full — reset confirm to keep mining", "warn");
			this.stop();
			return;
		}
		const prev = this.chain[this.chain.length - 1];
		if (!prev) return;
		const block = {
			height: this.jobHeight,
			hash,
			prev: this.jobPrev,
			header: bytesToHex(header),
			time: this.jobTime,
			nonce,
			miner: this.wallet,
			reward: 25,
			bits: this.jobBits,
			extra: this.jobExtra
		};
		const reason = explain(block, prev);
		if (reason) {
			this.rejected += 1;
			this.log("pool", `block failed audit (${reason})`, "warn");
			return;
		}
		this.chain.push(block);
		this.sessionBlocks += 1;
		this.persistChain();
		this.log("pool", `BLOCK height ${block.height}  +25 LODE  ${hash.slice(0, 16)}`, "block");
		this.issueJob();
	}
	sampleRate() {
		const now = performance.now();
		const dt = now - this.lastTick;
		if (dt < 200) return;
		const instant = this.hashesSinceTick * 1e3 / dt;
		this.hashesSinceTick = 0;
		this.lastTick = now;
		this.hps = this.hps === 0 ? instant : this.hps * .6 + instant * .4;
		this.samples.push({ hps: Math.round(this.hps) });
		if (this.samples.length > 40) this.samples.shift();
		this.maybeRetarget();
	}
	maybeRetarget() {
		const now = performance.now();
		if (now - this.lastRetarget < 3e3) return;
		if (this.hps < 200) return;
		this.lastRetarget = now;
		const idealShare = Math.log2(this.hps / 2.5);
		const idealBlock = Math.log2(this.hps * 14);
		let shareBits = deadband(this.shareBits, idealShare);
		let blockBits = deadband(this.blockBits, idealBlock);
		shareBits = clamp(shareBits, 8, 30);
		blockBits = clamp(blockBits, shareBits + 2, 42);
		if (shareBits === this.shareBits && blockBits === this.blockBits) return;
		this.shareBits = shareBits;
		this.blockBits = blockBits;
		this.log("pool", `retarget share ${shareBits} bits  block ${blockBits} bits`);
		this.issueJob();
	}
	flush() {
		if (this.running) this.sampleRate();
		this.dirty = false;
		this.onEmit();
	}
	log(src, msg, tone = "info") {
		this.logs.push({
			id: ++this.logId,
			t: Date.now(),
			src,
			msg,
			tone
		});
		if (this.logs.length > 400) this.logs.splice(0, this.logs.length - 280);
		this.dirty = true;
	}
	persistChain() {
		try {
			localStorage.setItem(CHAIN_KEY, JSON.stringify(this.chain));
		} catch {
			this.log("kiln", "this browser refused to store the ledger", "warn");
		}
	}
};
function readStorage(key) {
	try {
		return localStorage.getItem(key);
	} catch {
		return null;
	}
}
function writeStorage(key, value) {
	try {
		localStorage.setItem(key, value);
	} catch {}
}
var QUICK = [
	"status",
	"balance",
	"ledger",
	"job",
	"diff",
	"help"
];
function formatRate(hps) {
	if (hps >= 1e6) return `${(hps / 1e6).toFixed(2)} MH/s`;
	if (hps >= 1e3) return `${(hps / 1e3).toFixed(1)} kH/s`;
	return `${Math.round(hps)} H/s`;
}
function formatUptime(sec) {
	const s = Math.max(0, Math.floor(sec));
	const h = Math.floor(s / 3600);
	const m = Math.floor(s % 3600 / 60);
	const r = s % 60;
	const pad = (n) => String(n).padStart(2, "0");
	return h > 0 ? `${h}:${pad(m)}:${pad(r)}` : `${pad(m)}:${pad(r)}`;
}
function clock(t) {
	if (!t) return "--:--:--";
	const d = new Date(t);
	const pad = (n) => String(n).padStart(2, "0");
	return `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}
function formatInt(n) {
	return new Intl.NumberFormat("en-US").format(n);
}
function KilnApp() {
	const engineRef = (0, import_react.useRef)(null);
	const logRef = (0, import_react.useRef)(null);
	const stickRef = (0, import_react.useRef)(true);
	const historyRef = (0, import_react.useRef)([]);
	const histIdx = (0, import_react.useRef)(-1);
	const [snap, setSnap] = (0, import_react.useState)(EMPTY_SNAPSHOT);
	const [draft, setDraft] = (0, import_react.useState)("");
	const [dirty, setDirty] = (0, import_react.useState)(false);
	const [walletError, setWalletError] = (0, import_react.useState)("");
	const [line, setLine] = (0, import_react.useState)("");
	const [armReset, setArmReset] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		let frame = 0;
		let pending = false;
		const engine = new MinerEngine(() => {
			if (pending) return;
			pending = true;
			frame = requestAnimationFrame(() => {
				pending = false;
				setSnap(engine.snapshot());
			});
		});
		engineRef.current = engine;
		engine.boot();
		setSnap(engine.snapshot());
		return () => {
			cancelAnimationFrame(frame);
			engine.destroy();
			engineRef.current = null;
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (!dirty) setDraft(snap.wallet);
	}, [snap.wallet, dirty]);
	(0, import_react.useEffect)(() => {
		const el = logRef.current;
		if (!el || !stickRef.current) return;
		el.scrollTop = el.scrollHeight;
	}, [snap.logs]);
	function commitWallet() {
		const engine = engineRef.current;
		if (!engine) return false;
		if (!engine.setWallet(draft)) {
			setWalletError("Use 8–90 letters, numbers, colon, underscore, or hyphen.");
			return false;
		}
		setWalletError("");
		setDirty(false);
		return true;
	}
	function toggleRig() {
		const engine = engineRef.current;
		if (!engine) return;
		if (snap.running) {
			engine.stop();
			return;
		}
		if (dirty && !commitWallet()) return;
		engine.start();
	}
	function runLine(value) {
		const engine = engineRef.current;
		if (!engine) return;
		const trimmed = value.trim();
		if (!trimmed) return;
		historyRef.current.push(trimmed);
		if (historyRef.current.length > 40) historyRef.current.shift();
		histIdx.current = -1;
		engine.exec(trimmed);
	}
	const live = snap.running ? `Hashing. Height ${snap.height}. Balance ${snap.balance} LODE.` : `Idle. Height ${snap.height}. Balance ${snap.balance} LODE.`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg pb-24",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "sr-only",
				"aria-live": "polite",
				children: live
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "border-b border-muted/25",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-4 lg:px-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-lg font-semibold tracking-widest",
						children: "KILN"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-xs text-muted",
						children: "local stratum · sealed sandbox"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-4 font-mono text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted",
							children: "pool built-in · no server"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-2 text-fg",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `size-2 rounded-full bg-brass ${snap.running ? "led-live" : "opacity-30"}`,
								"aria-hidden": true
							}), snap.running ? "HASHING" : "IDLE"]
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto grid w-full max-w-6xl gap-4 px-4 py-4 lg:grid-cols-12 lg:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "flex min-w-0 flex-col gap-4 lg:col-span-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "border border-muted/25 bg-surface p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									htmlFor: "wallet",
									className: "font-mono text-xs text-muted",
									children: "Payout address"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-2 flex gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										id: "wallet",
										value: draft,
										autoCapitalize: "off",
										autoCorrect: "off",
										spellCheck: false,
										autoComplete: "off",
										placeholder: "lode1… or your own label",
										onChange: (event) => {
											setDraft(event.target.value);
											setDirty(true);
											setWalletError("");
										},
										className: "h-11 min-w-0 flex-1 border border-muted/30 bg-bg px-3 font-mono text-sm text-fg"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: commitWallet,
										className: "h-11 shrink-0 border border-muted/30 bg-bg px-3 text-sm text-fg",
										children: "Set"
									})]
								}),
								walletError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-fg",
									children: walletError
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-2 flex flex-wrap gap-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "h-11 border border-muted/30 bg-bg px-3 text-sm text-fg",
										onClick: () => {
											const addr = engineRef.current?.mintWallet();
											if (!addr) return;
											setDraft(addr);
											setDirty(false);
											setWalletError("");
										},
										children: "Mint address"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-4 font-mono text-3xl font-medium tabular-nums text-fg",
									children: [formatInt(snap.balance), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "ml-2 text-base font-medium text-brass",
										children: "LODE"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-pretty text-muted",
									children: "LODE is credit on this browser’s ledger, not a mainnet coin. The address is only the payee written into each block."
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "border border-muted/25 bg-surface p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
										className: "flex items-center gap-2 text-sm font-semibold tracking-wide",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cpu, {
											className: "size-4 text-brass",
											"aria-hidden": true
										}), "This machine"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-mono text-xs text-muted",
										children: snap.cores ? `${snap.cores} threads visible` : "cpu"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 font-mono text-3xl font-medium tabular-nums text-brass",
									children: formatRate(snap.hps)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 font-mono text-xs text-muted",
									children: snap.lastShare ? `last share ${snap.lastShare}` : "double SHA-256 of an 80-byte header"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-4",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HashChart, { data: snap.samples })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-4 flex items-center gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											"aria-label": "Fewer workers",
											className: "size-11 border border-muted/30 bg-bg font-mono text-lg text-fg disabled:opacity-40",
											disabled: snap.threads <= 1,
											onClick: () => engineRef.current?.setThreads(snap.threads - 1),
											children: "−"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "w-8 text-center font-mono text-lg tabular-nums",
											children: snap.threads
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											"aria-label": "More workers",
											className: "size-11 border border-muted/30 bg-bg font-mono text-lg text-fg disabled:opacity-40",
											disabled: snap.threads >= 4,
											onClick: () => engineRef.current?.setThreads(snap.threads + 1),
											children: "+"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-sm text-muted",
											children: "workers · cap 4"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: toggleRig,
									"aria-pressed": snap.running,
									className: snap.running ? "mt-4 flex h-12 w-full items-center justify-center gap-2 border border-brass bg-transparent text-sm font-semibold tracking-widest text-brass" : "mt-4 flex h-12 w-full items-center justify-center gap-2 bg-brass text-sm font-semibold tracking-widest text-bg",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Power, {
										className: "size-4",
										"aria-hidden": true
									}), snap.running ? "STOP RIG" : "START RIG"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-3 text-sm text-pretty text-muted",
									children: [
										"Workers run only while the rig is on. The built-in pool checks every share itself, then pays",
										" ",
										25,
										" LODE to the active address. Fee 0%."
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-px bg-muted/25",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									label: "Accepted",
									value: formatInt(snap.accepted)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									label: "Rejected",
									value: formatInt(snap.rejected)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									label: "Height",
									value: formatInt(snap.height)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									label: "Block target",
									value: `${snap.blockBits} bits`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									label: "Share target",
									value: `${snap.shareBits} bits`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									label: "Uptime",
									value: formatUptime(snap.uptime)
								})
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "flex min-w-0 flex-col gap-4 lg:col-span-7",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex min-h-80 flex-col border border-muted/25 bg-surface",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-3 border-b border-muted/25 px-3 py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-mono text-xs tracking-widest text-muted",
									children: "KILN SHELL"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate font-mono text-xs text-muted",
									children: "stratum+local://kiln"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								ref: logRef,
								onScroll: () => {
									const el = logRef.current;
									if (!el) return;
									stickRef.current = el.scrollHeight - el.scrollTop - el.clientHeight < 28;
								},
								className: "h-80 overflow-y-auto px-3 py-3 font-mono text-xs leading-relaxed sm:text-sm lg:h-96",
								children: snap.logs.map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex gap-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "w-16 shrink-0 text-muted tabular-nums",
											children: clock(entry.t)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `w-10 shrink-0 ${entry.src === "cpu" || entry.tone === "block" ? "text-brass" : "text-muted"}`,
											children: entry.src
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `min-w-0 flex-1 break-all ${entry.tone === "block" || entry.tone === "ok" ? "text-brass" : "text-fg"}`,
											children: entry.msg
										})
									]
								}, entry.id))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap gap-2 border-t border-muted/25 px-3 py-3",
								children: QUICK.map((cmd) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "h-11 border border-muted/30 bg-bg px-3 font-mono text-xs text-fg",
									onClick: () => runLine(cmd),
									children: cmd
								}, cmd))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
								className: "flex h-12 items-center gap-2 border-t border-muted/25 px-3",
								onSubmit: (event) => {
									event.preventDefault();
									runLine(line);
									setLine("");
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-sm text-brass",
									"aria-hidden": true,
									children: "kiln>"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "shell",
									value: line,
									onChange: (event) => setLine(event.target.value),
									autoCapitalize: "off",
									autoCorrect: "off",
									spellCheck: false,
									autoComplete: "off",
									"aria-label": "Shell command",
									className: "min-w-0 flex-1 bg-transparent font-mono text-sm text-fg outline-none",
									onKeyDown: (event) => {
										const hist = historyRef.current;
										if (event.key === "ArrowUp") {
											event.preventDefault();
											if (!hist.length) return;
											const next = histIdx.current < 0 ? hist.length - 1 : Math.max(0, histIdx.current - 1);
											histIdx.current = next;
											setLine(hist[next] ?? "");
										} else if (event.key === "ArrowDown") {
											event.preventDefault();
											if (histIdx.current < 0) return;
											const next = histIdx.current + 1;
											if (next >= hist.length) {
												histIdx.current = -1;
												setLine("");
											} else {
												histIdx.current = next;
												setLine(hist[next] ?? "");
											}
										}
									}
								})]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border border-muted/25 bg-surface",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-3 border-b border-muted/25 px-4 py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-sm font-semibold tracking-wide",
									children: "Local chain"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "font-mono text-xs text-muted",
									children: ["tip ", snap.tip ? shortId(snap.tip, 8, 4) : "—"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "max-h-80 divide-y divide-muted/20 overflow-y-auto",
								children: snap.chain.map((block) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-center gap-3 px-4 py-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0 flex-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "font-mono text-sm text-fg",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-brass",
													children: ["#", block.height]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-muted",
													children: " · "
												}),
												block.reward ? `+${block.reward} LODE` : "genesis",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-muted",
													children: " · "
												}),
												block.height === 0 ? "checkpoint" : `${block.bits} bits`
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "truncate font-mono text-xs text-muted",
											children: [
												block.hash.slice(0, 24),
												"… · ",
												shortId(block.miner)
											]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "h-11 shrink-0 border border-muted/30 bg-bg px-3 text-sm text-fg",
										onClick: () => engineRef.current?.verify(block.height),
										children: "Verify"
									})]
								}, block.height))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap gap-2 border-t border-muted/25 px-4 py-3",
								children: armReset ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "h-11 border border-brass px-3 text-sm text-brass",
									onClick: () => {
										engineRef.current?.resetChain();
										setArmReset(false);
									},
									children: "Confirm wipe"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "h-11 border border-muted/30 px-3 text-sm text-fg",
									onClick: () => setArmReset(false),
									children: "Cancel"
								})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "h-11 border border-muted/30 px-3 text-sm text-muted",
									onClick: () => setArmReset(true),
									children: "Reset chain"
								})
							})
						]
					})]
				})]
			})
		]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "bg-surface px-3 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "font-mono text-xs text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-1 font-mono text-base tabular-nums text-fg",
			children: value
		})]
	});
}
var SplitComponent = KilnApp;
//#endregion
export { SplitComponent as component };
