//#region node_modules/.nitro/vite/services/ssr/assets/innertube-Cxmnl2Mp.js
var CLIENT_VERSION = "2.20260901.00.00";
var POSTS_PARAMS = "EgVwb3N0c_IGBAoCSgA%3D";
var CHANNEL_SEARCH_PARAMS = "EgIQAg%3D%3D";
var CACHE_TTL_MS = 75e3;
var FETCH_MS = 18e3;
var memoryCache = /* @__PURE__ */ new Map();
function cacheGet(key) {
	const hit = memoryCache.get(key);
	if (!hit) return void 0;
	if (Date.now() - hit.at > CACHE_TTL_MS) {
		memoryCache.delete(key);
		return;
	}
	return hit.value;
}
function cacheSet(key, value) {
	if (memoryCache.size > 400) {
		const first = memoryCache.keys().next().value;
		if (first) memoryCache.delete(first);
	}
	memoryCache.set(key, {
		at: Date.now(),
		value
	});
}
function walk(node, visit, seen) {
	if (!node || typeof node !== "object") return;
	const tracker = seen ?? /* @__PURE__ */ new WeakSet();
	if (tracker.has(node)) return;
	tracker.add(node);
	if (Array.isArray(node)) {
		for (const item of node) walk(item, visit, tracker);
		return;
	}
	const obj = node;
	visit(obj);
	for (const value of Object.values(obj)) walk(value, visit, tracker);
}
function asJson(v) {
	return v && typeof v === "object" && !Array.isArray(v) ? v : null;
}
function textOf(value) {
	if (value == null) return "";
	if (typeof value === "string") return value;
	const obj = asJson(value);
	if (!obj) return "";
	if (typeof obj.simpleText === "string") return obj.simpleText;
	if (typeof obj.content === "string") return obj.content;
	if (Array.isArray(obj.runs)) return obj.runs.map((run) => {
		const r = asJson(run);
		return typeof r?.text === "string" ? r.text : "";
	}).join("");
	const label = asJson(obj.accessibility)?.accessibilityData;
	const lab = asJson(label)?.label;
	if (typeof lab === "string") return lab;
	const acc = asJson(obj.accessibilityData)?.label;
	if (typeof acc === "string") return acc;
	return "";
}
function absUrl(url) {
	if (!url) return "";
	if (url.startsWith("//")) return `https:${url}`;
	if (url.startsWith("/")) return `https://www.youtube.com${url}`;
	return url;
}
function pickThumb(thumbs, minW = 240) {
	if (!Array.isArray(thumbs) || thumbs.length === 0) return null;
	const parsed = thumbs.map((t) => {
		const o = asJson(t);
		if (!o || typeof o.url !== "string") return null;
		return {
			url: absUrl(o.url),
			width: typeof o.width === "number" ? o.width : 0,
			height: typeof o.height === "number" ? o.height : 0
		};
	}).filter((t) => !!t).sort((a, b) => a.width - b.width);
	if (!parsed.length) return null;
	return parsed.find((t) => t.width >= minW) ?? parsed[parsed.length - 1] ?? null;
}
function parseCount(raw) {
	const m = raw.replace(/,/g, "").replace(/subscribers|subscriber|videos|views|likes|like|votes|comments|replies/gi, "").trim().match(/([\d.]+)\s*([KMB])?/i);
	if (!m) return 0;
	const n = Number.parseFloat(m[1] ?? "0");
	if (!Number.isFinite(n)) return 0;
	const mul = m[2]?.toUpperCase() === "K" ? 1e3 : m[2]?.toUpperCase() === "M" ? 1e6 : m[2]?.toUpperCase() === "B" ? 1e9 : 1;
	return Math.round(n * mul);
}
function parseRelativeTime(raw, now = Date.now()) {
	const t = raw.toLowerCase().replace(/\(edited\)/g, "").replace(/edited/g, "").replace(/premiered/g, "").replace(/streamed/g, "").replace(/•.*/g, "").trim();
	if (!t) return now;
	if (t.includes("just now") || t.includes("moment") || t.includes("today")) return now;
	if (t.includes("yesterday")) return now - 864e5;
	const m = t.match(/(\d+)\s+(second|minute|hour|day|week|month|year)s?/);
	if (!m) return now - 36e5;
	return now - Number(m[1]) * ({
		second: 1e3,
		minute: 6e4,
		hour: 36e5,
		day: 864e5,
		week: 6048e5,
		month: 2592e6,
		year: 31536e6
	}[m[2]] ?? 36e5);
}
async function innertube(endpoint, extra) {
	const key = `${endpoint}:${JSON.stringify(extra)}`;
	const cached = cacheGet(key);
	if (cached) return cached;
	const controller = new AbortController();
	const timer = setTimeout(() => controller.abort(), FETCH_MS);
	try {
		const res = await fetch(`https://www.youtube.com/youtubei/v1/${endpoint}?prettyPrint=false`, {
			method: "POST",
			headers: {
				"content-type": "application/json",
				"x-youtube-client-name": "1",
				"x-youtube-client-version": CLIENT_VERSION,
				origin: "https://www.youtube.com",
				referer: "https://www.youtube.com/",
				"user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
			},
			body: JSON.stringify({
				context: { client: {
					clientName: "WEB",
					clientVersion: CLIENT_VERSION,
					hl: "en",
					gl: "US"
				} },
				...extra
			}),
			signal: controller.signal
		});
		if (!res.ok) throw new Error(`YouTube returned ${res.status}`);
		const json = await res.json();
		cacheSet(key, json);
		return json;
	} catch (err) {
		const empty = {};
		if (err instanceof Error && /abort/i.test(err.message)) return empty;
		throw err;
	} finally {
		clearTimeout(timer);
	}
}
function channelIdFrom(obj) {
	if (!obj) return "";
	if (typeof obj.channelId === "string" && obj.channelId.startsWith("UC")) return obj.channelId;
	const browse = asJson(obj.browseEndpoint) || asJson(asJson(obj.navigationEndpoint)?.browseEndpoint) || asJson(asJson(obj.authorEndpoint)?.browseEndpoint);
	const id = browse && typeof browse.browseId === "string" ? browse.browseId : "";
	return id.startsWith("UC") ? id : "";
}
function handleFrom(obj, fallback = "") {
	const browse = asJson(asJson(obj)?.browseEndpoint ?? asJson(asJson(obj)?.navigationEndpoint)?.browseEndpoint ?? asJson(asJson(obj)?.authorEndpoint)?.browseEndpoint);
	const base = (typeof browse?.canonicalBaseUrl === "string" ? browse.canonicalBaseUrl : "") || fallback;
	if (!base) return fallback;
	const trimmed = base.replace(/^https?:\/\/(www\.)?youtube\.com/i, "");
	if (trimmed.startsWith("/@")) return trimmed.slice(1);
	if (trimmed.startsWith("@")) return trimmed;
	const m = trimmed.match(/@[\w.-]+/);
	return m ? m[0] : fallback;
}
function isVerified(node) {
	let verified = false;
	walk(node, (o) => {
		const badge = asJson(o.metadataBadgeRenderer);
		if (!badge) return;
		const style = String(badge.style ?? "");
		const tooltip = String(badge.tooltip ?? "").toLowerCase();
		if (style.includes("VERIFIED") || tooltip.includes("verified")) verified = true;
	});
	return verified;
}
function parseChannelRenderer(renderer) {
	const id = typeof renderer.channelId === "string" ? renderer.channelId : channelIdFrom(renderer);
	if (!id) return null;
	const title = textOf(renderer.title) || "Untitled channel";
	const handleCandidate = textOf(renderer.subscriberCountText);
	const countCandidate = textOf(renderer.videoCountText);
	const handleRaw = handleCandidate.startsWith("@") ? handleCandidate : handleFrom(renderer, handleCandidate);
	const handle = handleRaw.startsWith("@") ? handleRaw : handleRaw ? `@${handleRaw.replace(/^\//, "")}` : "";
	const combined = `${handleCandidate} ${countCandidate}`;
	const subscriberText = /subscriber/i.test(handleCandidate) ? handleCandidate : /subscriber/i.test(countCandidate) ? countCandidate : /subscriber/i.test(combined) ? combined : "";
	const thumb = pickThumb(asJson(renderer.thumbnail)?.thumbnails, 88)?.url ?? pickThumb(asJson(asJson(renderer.thumbnail)?.image)?.sources, 88)?.url ?? "";
	return {
		id,
		title,
		handle,
		description: textOf(renderer.descriptionSnippet) || textOf(renderer.description) || "",
		thumbnail: thumb,
		subscriberCount: parseCount(subscriberText || countCandidate),
		subscriberText: subscriberText || countCandidate || "0 subscribers",
		videoCount: parseCount(/video/i.test(countCandidate) ? countCandidate : ""),
		videoText: /video/i.test(countCandidate) ? countCandidate : "",
		verified: isVerified(renderer),
		hasPostsTab: true
	};
}
function extractTabTitles(json) {
	const titles = [];
	const tabs = asJson(json.contents)?.twoColumnBrowseResultsRenderer;
	const list = asJson(tabs)?.tabs;
	if (!Array.isArray(list)) return titles;
	for (const tab of list) {
		const t = asJson(asJson(tab)?.tabRenderer)?.title;
		if (typeof t === "string") titles.push(t);
	}
	return titles;
}
function hasPostsTab(titles) {
	return titles.some((t) => /post|community|comunidad|community/i.test(t));
}
function parseHeaderMetadata(json) {
	const meta = asJson(asJson(json.metadata)?.channelMetadataRenderer) ?? asJson(json.metadata);
	const title = typeof meta?.title === "string" ? meta.title : "";
	const description = typeof meta?.description === "string" ? meta.description : "";
	const externalId = typeof meta?.externalId === "string" ? meta.externalId : "";
	const vanity = typeof meta?.vanityChannelUrl === "string" ? meta.vanityChannelUrl : "";
	const avatar = pickThumb(asJson(meta?.avatar)?.thumbnails, 200)?.url ?? "";
	let handle = "";
	const vanityMatch = vanity.match(/@[\w.-]+/);
	if (vanityMatch) handle = vanityMatch[0];
	let subscriberText = "";
	let videoText = "";
	walk(json, (o) => {
		const rows = asJson(o.contentMetadataViewModel)?.metadataRows;
		if (!Array.isArray(rows)) return;
		for (const row of rows) {
			const parts = asJson(row)?.metadataParts;
			if (!Array.isArray(parts)) continue;
			for (const part of parts) {
				const content = textOf(asJson(part)?.text) || textOf(part);
				if (/subscriber/i.test(content) && !subscriberText) subscriberText = content;
				if (/video/i.test(content) && !videoText) videoText = content;
				if (content.startsWith("@") && !handle) handle = content;
			}
		}
	});
	const banner = pickThumb(asJson(asJson(asJson(json.header)?.c4TabbedHeaderRenderer)?.banner)?.thumbnails, 800)?.url ?? null;
	const keywordsRaw = meta?.keywords;
	const keywords = typeof keywordsRaw === "string" ? keywordsRaw.split(/\s+/).filter(Boolean).slice(0, 24) : [];
	const tabTitles = extractTabTitles(json);
	return {
		id: externalId,
		title,
		handle,
		description,
		thumbnail: avatar,
		subscriberCount: parseCount(subscriberText),
		subscriberText: subscriberText || "Hidden subscribers",
		videoCount: parseCount(videoText),
		videoText,
		banner,
		keywords,
		tabTitles,
		hasPostsTab: hasPostsTab(tabTitles),
		verified: isVerified(json.header ?? json)
	};
}
function parseImages(attachment) {
	if (!attachment) return [];
	const images = [];
	walk(attachment, (o) => {
		if (o.backstageImageRenderer) {
			const img = pickThumb(asJson(asJson(o.backstageImageRenderer)?.image)?.thumbnails, 480);
			if (img) images.push(img);
		}
	});
	return images;
}
function parsePoll(attachment) {
	if (!attachment) return null;
	const poll = asJson(attachment.pollRenderer);
	if (!poll) return null;
	const choices = [];
	if (Array.isArray(poll.choices)) for (const choice of poll.choices) {
		const c = asJson(choice);
		if (!c) continue;
		const imageUrl = pickThumb(asJson(c.image)?.thumbnails, 80)?.url;
		choices.push({
			text: textOf(c.text),
			imageUrl
		});
	}
	return {
		choices,
		totalVotesText: textOf(poll.totalVotes) || ""
	};
}
function parseVideo(attachment) {
	if (!attachment) return null;
	let found = null;
	for (const key of [
		"videoRenderer",
		"compactVideoRenderer",
		"videoWithContextRenderer",
		"reelItemRenderer"
	]) if (asJson(attachment[key])) {
		found = asJson(attachment[key]);
		break;
	}
	if (!found) walk(attachment, (o) => {
		if (found) return;
		if (typeof o.videoId === "string" && (o.title || o.headline)) found = o;
	});
	if (!found) return null;
	const id = typeof found.videoId === "string" ? found.videoId : "";
	if (!id) return null;
	const thumb = pickThumb(asJson(found.thumbnail)?.thumbnails, 320)?.url || `https://i.ytimg.com/vi/${id}/hqdefault.jpg`;
	return {
		id,
		title: textOf(found.title) || textOf(found.headline) || "Video",
		thumbnail: thumb,
		viewText: textOf(found.viewCountText) || textOf(found.shortViewCountText) || "",
		lengthText: textOf(found.lengthText) || ""
	};
}
function detectKind(text, images, poll, video, attachment) {
	if (poll) return "poll";
	if (attachment && asJson(attachment.quizRenderer)) return "quiz";
	if (video) return "video";
	if (images.length) return "image";
	return text.trim() ? "text" : "text";
}
function parsePost(renderer) {
	const id = typeof renderer.postId === "string" ? renderer.postId : "";
	if (!id) return null;
	const author = asJson(renderer.authorEndpoint);
	const channelId = channelIdFrom(renderer) || channelIdFrom(author);
	const channelTitle = textOf(renderer.authorText) || "Unknown";
	const channelHandle = handleFrom(renderer, "");
	const channelThumbnail = pickThumb(asJson(renderer.authorThumbnail)?.thumbnails, 88)?.url ?? "";
	const text = textOf(renderer.contentText);
	const publishedText = textOf(renderer.publishedTimeText);
	const likeText = textOf(renderer.voteCount) || textOf(asJson(renderer.voteCount)?.accessibility) || "0";
	let replyCount = 0;
	let replyText = "";
	let commentParams = null;
	walk(renderer.actionButtons, (o) => {
		const btn = asJson(o.buttonRenderer) || asJson(o.toggleButtonRenderer);
		if (btn) {
			const label = `${textOf(btn.text)} ${textOf(btn.accessibility)} ${textOf(btn.accessibilityData)}`.toLowerCase();
			if (label.includes("comment") || label.includes("repl")) {
				const raw = textOf(btn.text);
				if (raw) {
					replyText = raw;
					replyCount = parseCount(raw);
				}
			}
		}
		const browse = asJson(asJson(o.navigationEndpoint)?.browseEndpoint);
		if (browse && browse.browseId === "FEpost_detail" && typeof browse.params === "string") commentParams = browse.params;
	});
	const attachment = asJson(renderer.backstageAttachment);
	const images = parseImages(attachment);
	const poll = parsePoll(attachment);
	const video = parseVideo(attachment);
	return {
		id,
		channelId,
		channelTitle,
		channelHandle,
		channelThumbnail,
		text,
		publishedText: publishedText || "just now",
		publishedAt: parseRelativeTime(publishedText),
		likeCount: parseCount(likeText),
		likeText,
		replyCount,
		replyText,
		kind: detectKind(text, images, poll, video, attachment),
		images,
		poll,
		video,
		url: `https://www.youtube.com/post/${id}`,
		commentParams
	};
}
function extractPosts(json) {
	const posts = [];
	const seen = /* @__PURE__ */ new Set();
	let continuation = null;
	let seenPost = false;
	const tabs = asJson(asJson(json.contents)?.twoColumnBrowseResultsRenderer)?.tabs;
	let root = json;
	if (Array.isArray(tabs)) {
		const selected = tabs.find((t) => asJson(asJson(t)?.tabRenderer)?.selected === true) ?? tabs.find((t) => {
			const title = String(asJson(asJson(t)?.tabRenderer)?.title ?? "");
			return /post|community/i.test(title);
		});
		if (selected) root = selected;
	}
	walk(root, (o) => {
		const renderer = asJson(o.backstagePostRenderer) || asJson(asJson(o.post)?.backstagePostRenderer) || asJson(o.postRenderer);
		if (renderer) {
			const post = parsePost(renderer);
			if (post && !seen.has(post.id)) {
				seen.add(post.id);
				posts.push(post);
				seenPost = true;
			}
		}
		const token = asJson(asJson(asJson(o.continuationItemRenderer)?.continuationEndpoint)?.continuationCommand)?.token;
		if (typeof token === "string" && token && seenPost) continuation = token;
	});
	return {
		posts,
		continuation
	};
}
function extractChannels(json) {
	const channels = [];
	const seen = /* @__PURE__ */ new Set();
	let continuation = null;
	walk(json, (o) => {
		if (o.channelRenderer) {
			const ch = parseChannelRenderer(asJson(o.channelRenderer));
			if (ch && !seen.has(ch.id)) {
				seen.add(ch.id);
				channels.push(ch);
			}
		}
		const token = asJson(asJson(asJson(o.continuationItemRenderer)?.continuationEndpoint)?.continuationCommand)?.token;
		if (typeof token === "string" && token) continuation = token;
	});
	return {
		channels,
		continuation
	};
}
var CHANNEL_ID_RE = /^UC[\w-]{20,}$/;
function parseUserQuery(raw) {
	const q = raw.trim();
	if (!q) return {
		kind: "search",
		value: ""
	};
	const urlMatch = q.match(/(?:https?:\/\/)?(?:www\.)?youtube\.com\/(channel\/(UC[\w-]+)|@([\w.-]+)|c\/([^/?#]+)|user\/([^/?#]+))/i);
	if (urlMatch?.[2]) return {
		kind: "id",
		value: urlMatch[2]
	};
	if (urlMatch?.[3]) return {
		kind: "handle",
		value: urlMatch[3]
	};
	if (urlMatch?.[4]) return {
		kind: "handle",
		value: urlMatch[4]
	};
	if (urlMatch?.[5]) return {
		kind: "handle",
		value: urlMatch[5]
	};
	const bare = q.replace(/^https?:\/\/(www\.)?youtu\.be\//i, "");
	if (CHANNEL_ID_RE.test(q) || CHANNEL_ID_RE.test(bare)) return {
		kind: "id",
		value: CHANNEL_ID_RE.test(q) ? q : bare
	};
	if (q.startsWith("@")) return {
		kind: "handle",
		value: q.slice(1)
	};
	return {
		kind: "search",
		value: q
	};
}
async function resolveChannel(input) {
	const parsed = parseUserQuery(input);
	let browseId = "";
	if (parsed.kind === "id") browseId = parsed.value;
	else if (parsed.kind === "handle") {
		const resolved = await innertube("navigation/resolve_url", { url: `https://www.youtube.com/@${parsed.value}` });
		browseId = channelIdFrom(asJson(resolved.endpoint)) || channelIdFrom(resolved);
		if (!browseId) walk(resolved, (o) => {
			if (!browseId) browseId = channelIdFrom(o);
		});
	} else return null;
	if (!browseId) return null;
	return getChannel(browseId);
}
async function getChannel(channelId) {
	const header = parseHeaderMetadata(await innertube("browse", { browseId: channelId }));
	if (!header.id && !header.title) return null;
	return {
		id: header.id || channelId,
		title: header.title || "Untitled channel",
		handle: header.handle || "",
		description: header.description || "",
		thumbnail: header.thumbnail || "",
		subscriberCount: header.subscriberCount ?? 0,
		subscriberText: header.subscriberText || "0 subscribers",
		videoCount: header.videoCount ?? 0,
		videoText: header.videoText || "",
		verified: header.verified ?? false,
		hasPostsTab: header.hasPostsTab ?? false,
		banner: header.banner ?? null,
		keywords: header.keywords ?? [],
		tabTitles: header.tabTitles ?? []
	};
}
async function getChannelPosts(input) {
	const json = input.continuation ? await innertube("browse", { continuation: input.continuation }) : await innertube("browse", {
		browseId: input.channelId,
		params: POSTS_PARAMS
	});
	const { posts, continuation } = extractPosts(json);
	const header = input.continuation ? null : parseHeaderMetadata(json);
	const channel = header?.title ? {
		id: header.id || input.channelId,
		title: header.title || "Untitled channel",
		handle: header.handle || "",
		description: header.description || "",
		thumbnail: header.thumbnail || "",
		subscriberCount: header.subscriberCount ?? 0,
		subscriberText: header.subscriberText || "0 subscribers",
		videoCount: header.videoCount ?? 0,
		videoText: header.videoText || "",
		verified: header.verified ?? false,
		hasPostsTab: header.hasPostsTab ?? hasPostsTab(header.tabTitles ?? []),
		banner: header.banner ?? null,
		keywords: header.keywords ?? [],
		tabTitles: header.tabTitles ?? []
	} : null;
	const tabbed = header ? hasPostsTab(header.tabTitles ?? []) : true;
	return {
		channel,
		posts,
		continuation,
		hasPostsTab: channel?.hasPostsTab ?? tabbed ?? posts.length > 0
	};
}
async function searchChannels(input) {
	const q = input.query.trim();
	if (!q && !input.continuation) return {
		channels: [],
		continuation: null,
		resolved: null
	};
	let resolved = null;
	if (!input.continuation && q) {
		const parsed = parseUserQuery(q);
		if (parsed.kind === "id" || parsed.kind === "handle") try {
			resolved = await resolveChannel(q);
		} catch {
			resolved = null;
		}
	}
	const { channels, continuation } = extractChannels(input.continuation ? await innertube("search", { continuation: input.continuation }) : await innertube("search", {
		query: q.replace(/^@/, ""),
		params: CHANNEL_SEARCH_PARAMS
	}));
	if (resolved && !channels.some((c) => c.id === resolved.id)) channels.unshift(resolved);
	return {
		channels,
		continuation,
		resolved
	};
}
var DISCOVERY_QUERIES = [
	"daily vlog",
	"news",
	"gaming",
	"music",
	"tech review",
	"comedy",
	"podcast",
	"sports",
	"official",
	"live",
	"today",
	"world",
	"a",
	"b",
	"c",
	"d",
	"e",
	"f",
	"g",
	"h",
	"i",
	"j",
	"k",
	"l",
	"m",
	"n",
	"o",
	"p",
	"q",
	"r",
	"s",
	"t",
	"u",
	"v",
	"w",
	"x",
	"y",
	"z",
	"the",
	"tv",
	"film",
	"art",
	"diy",
	"food",
	"travel",
	"science",
	"learn",
	"kids",
	"anime",
	"radio",
	"show",
	"channel",
	"studio",
	"media",
	"1",
	"2",
	"3",
	"4",
	"5",
	"8",
	"9",
	"0",
	"mr",
	"ms",
	"pro",
	"plus",
	"club",
	"network",
	"india",
	"brasil",
	"japan",
	"korea",
	"france",
	"spain",
	"mexico",
	"africa",
	"asia",
	"uk",
	"usa"
];
var TOPIC_QUERIES = {
	gaming: [
		"gaming",
		"gameplay",
		"esports",
		"minecraft",
		"fortnite",
		"roblox",
		"steam"
	],
	music: [
		"music",
		"official music",
		"vevo",
		"covers",
		"dj",
		"hip hop",
		"indie band"
	],
	news: [
		"news",
		"breaking news",
		"world news",
		"politics today",
		"local news"
	],
	tech: [
		"tech",
		"technology",
		"gadgets",
		"coding",
		"ai",
		"smartphones",
		"review tech"
	],
	sports: [
		"sports",
		"football",
		"soccer",
		"nba",
		"cricket",
		"f1",
		"ufc"
	],
	comedy: [
		"comedy",
		"stand up",
		"skits",
		"funny",
		"impressions"
	],
	education: [
		"education",
		"learn",
		"lectures",
		"tutorial",
		"university",
		"history"
	],
	food: [
		"cooking",
		"recipes",
		"food",
		"mukbang",
		"chef",
		"baking"
	],
	fashion: [
		"fashion",
		"beauty",
		"makeup",
		"style",
		"vogue"
	],
	science: [
		"science",
		"space",
		"physics",
		"nature documentary",
		"nasa"
	],
	travel: [
		"travel",
		"tour",
		"vlog travel",
		"city walk",
		"backpacking"
	],
	finance: [
		"finance",
		"investing",
		"crypto",
		"stock market",
		"business"
	],
	anime: [
		"anime",
		"manga",
		"otaku",
		"cosplay",
		"weeb"
	],
	podcasts: [
		"podcast",
		"interview show",
		"talk show",
		"radio show"
	]
};
function discoveryQueryAt(index, topic) {
	const topicQueries = TOPIC_QUERIES[topic];
	if (topicQueries?.length) {
		const combined = [...topicQueries, ...DISCOVERY_QUERIES.map((q) => `${topic} ${q}`)];
		return combined[index % combined.length] ?? topic;
	}
	return DISCOVERY_QUERIES[index % DISCOVERY_QUERIES.length] ?? "a";
}
async function discoverChannelsPage(input) {
	const page = await searchChannels({
		query: discoveryQueryAt(input.queryIndex, input.topic === "all" ? "" : input.topic) || discoveryQueryAt(input.queryIndex, "all"),
		continuation: input.continuation
	});
	const nextQueryIndex = page.continuation ? input.queryIndex : input.queryIndex + 1;
	return {
		channels: page.channels,
		continuation: page.continuation,
		nextQueryIndex
	};
}
async function fetchPostsForChannels(channels) {
	const normalized = channels.map((c) => typeof c === "string" ? {
		id: c,
		continuation: null
	} : c).filter((c) => c.id).slice(0, 8);
	const pages = await Promise.allSettled(normalized.map((ch) => getChannelPosts({
		channelId: ch.id,
		continuation: ch.continuation ?? void 0
	})));
	const posts = [];
	const next = [];
	pages.forEach((page, i) => {
		const ch = normalized[i];
		if (!ch || page.status !== "fulfilled") return;
		posts.push(...page.value.posts);
		if (page.value.continuation) next.push({
			id: ch.id,
			continuation: page.value.continuation
		});
	});
	return {
		posts,
		next
	};
}
async function loadFeedPage(input) {
	const posts = [];
	const channels = [];
	const seenPosts = /* @__PURE__ */ new Set();
	const seenChannels = /* @__PURE__ */ new Set();
	let queryIndex = input.queryIndex;
	let searchContinuation = input.searchContinuation ?? null;
	let nextCursors = [];
	const cursors = input.channelCursors?.length ? input.channelCursors : (input.extraChannelIds ?? []).map((id) => ({
		id,
		continuation: null
	}));
	const batch = cursors.slice(0, 8);
	const rest = cursors.slice(8);
	if (batch.length) {
		const extra = await fetchPostsForChannels(batch);
		for (const post of extra.posts) {
			if (seenPosts.has(post.id)) continue;
			seenPosts.add(post.id);
			posts.push(post);
		}
		nextCursors = [...extra.next, ...rest.map((c) => ({
			id: c.id,
			continuation: c.continuation ?? null
		}))];
	}
	if (input.discover === false) return {
		posts,
		channels,
		queryIndex,
		searchContinuation,
		nextCursors
	};
	let rounds = 0;
	while (posts.length < 10 && rounds < 2) {
		const discovered = await discoverChannelsPage({
			topic: input.topic,
			queryIndex,
			continuation: searchContinuation
		});
		queryIndex = discovered.nextQueryIndex;
		searchContinuation = discovered.continuation;
		for (const ch of discovered.channels) {
			if (seenChannels.has(ch.id)) continue;
			seenChannels.add(ch.id);
			channels.push(ch);
		}
		const more = await fetchPostsForChannels(discovered.channels.map((c) => c.id));
		for (const post of more.posts) {
			if (seenPosts.has(post.id)) continue;
			seenPosts.add(post.id);
			posts.push(post);
		}
		rounds += 1;
		if (!discovered.channels.length && !discovered.continuation) break;
	}
	return {
		posts,
		channels,
		queryIndex,
		searchContinuation,
		nextCursors
	};
}
function decodeContinuation(token) {
	try {
		return decodeURIComponent(token);
	} catch {
		return token;
	}
}
function continuationUtf8(token) {
	try {
		const raw = decodeContinuation(token).replace(/-/g, "+").replace(/_/g, "/");
		return Buffer.from(raw, "base64").toString("utf8");
	} catch {
		return "";
	}
}
function tokenOf(node) {
	const token = asJson(asJson(asJson(node)?.continuationEndpoint)?.continuationCommand)?.token;
	if (typeof token === "string" && token) return decodeContinuation(token);
	const direct = asJson(node)?.token;
	if (typeof direct === "string" && direct) return decodeContinuation(direct);
	return null;
}
function commentFromEntity(entity, heartByToolbarKey, thread) {
	const props = asJson(entity.properties);
	const author = asJson(entity.author);
	const toolbar = asJson(entity.toolbar);
	const id = typeof props?.commentId === "string" ? props.commentId : "";
	if (!id) return null;
	const toolbarKey = typeof props?.toolbarStateKey === "string" ? decodeContinuation(props.toolbarStateKey) : "";
	const likeRaw = typeof toolbar?.likeCountNotliked === "string" && toolbar.likeCountNotliked || typeof toolbar?.likeCountA11y === "string" && toolbar.likeCountA11y || "0";
	const heartedBy = (typeof toolbar?.heartActiveTooltip === "string" ? toolbar.heartActiveTooltip : "").replace(/^❤\s*by\s*/i, "").replace(/^hearted by\s*/i, "").trim();
	const repliesRoot = asJson(asJson(thread?.replies)?.commentRepliesRenderer);
	let repliesContinuation = null;
	let replyCount = parseCount(typeof toolbar?.replyCount === "string" && toolbar.replyCount ? toolbar.replyCount : String(toolbar?.replyCountA11y ?? ""));
	if (repliesRoot) {
		walk(repliesRoot, (o) => {
			if (repliesContinuation) return;
			const tok = tokenOf(asJson(o.continuationItemRenderer));
			if (tok) repliesContinuation = tok;
		});
		const view = textOf(asJson(asJson(repliesRoot.viewReplies)?.buttonRenderer)?.text);
		if (view) replyCount = Math.max(replyCount, parseCount(view));
	}
	const content = asJson(props?.content);
	const text = typeof content?.content === "string" && content.content || textOf(props?.content) || "";
	return {
		id,
		author: typeof author?.displayName === "string" && author.displayName || "Unknown",
		authorChannelId: typeof author?.channelId === "string" && author.channelId || "",
		authorThumbnail: typeof author?.avatarThumbnailUrl === "string" && author.avatarThumbnailUrl || "",
		text,
		publishedText: typeof props?.publishedTime === "string" && props.publishedTime || "",
		publishedAt: parseRelativeTime(typeof props?.publishedTime === "string" ? props.publishedTime : ""),
		likeCount: parseCount(String(likeRaw)),
		likeText: String(likeRaw),
		replyCount,
		hearted: heartByToolbarKey.get(toolbarKey)?.hearted === true,
		heartedBy,
		isCreator: author?.isCreator === true,
		isVerified: author?.isVerified === true,
		hidden: thread?.isModeratedElqComment === true,
		repliesContinuation
	};
}
function parseCommentsPage(json) {
	const entities = /* @__PURE__ */ new Map();
	const hearts = /* @__PURE__ */ new Map();
	const mutations = asJson(asJson(json.frameworkUpdates)?.entityBatchUpdate)?.mutations;
	if (Array.isArray(mutations)) for (const raw of mutations) {
		const payload = asJson(asJson(raw)?.payload);
		if (!payload) continue;
		const comment = asJson(payload.commentEntityPayload);
		if (comment && typeof comment.key === "string") entities.set(decodeContinuation(comment.key), comment);
		const state = asJson(payload.engagementToolbarStateEntityPayload);
		if (state && typeof state.key === "string") hearts.set(decodeContinuation(state.key), { hearted: String(state.heartState ?? "") === "TOOLBAR_HEART_STATE_HEARTED" });
	}
	const comments = [];
	const seen = /* @__PURE__ */ new Set();
	let continuation = null;
	let hiddenContinuation = null;
	let totalText = "";
	let newestToken = null;
	let topToken = null;
	walk(json, (o) => {
		const header = asJson(o.commentsHeaderRenderer);
		if (header) totalText = textOf(header.countText) || textOf(header.commentsCount) || totalText;
		if (typeof o.title === "string" && /newest/i.test(o.title)) {
			const cmd = asJson(asJson(o.serviceEndpoint)?.continuationCommand);
			const tok = typeof cmd?.token === "string" ? decodeContinuation(cmd.token) : tokenOf(asJson(o.serviceEndpoint));
			if (tok) newestToken = tok;
		}
		if (typeof o.title === "string" && /top comment/i.test(o.title)) {
			const cmd = asJson(asJson(o.serviceEndpoint)?.continuationCommand);
			const tok = typeof cmd?.token === "string" ? decodeContinuation(cmd.token) : tokenOf(asJson(o.serviceEndpoint));
			if (tok) topToken = tok;
		}
		const thread = asJson(o.commentThreadRenderer);
		if (thread) {
			const cvm = asJson(asJson(thread.commentViewModel)?.commentViewModel) || asJson(thread.commentViewModel);
			const key = typeof cvm?.commentKey === "string" ? decodeContinuation(cvm.commentKey) : "";
			const entity = key ? entities.get(key) : void 0;
			const parsed = entity ? commentFromEntity(entity, hearts, thread) : null;
			if (parsed && !seen.has(parsed.id)) {
				seen.add(parsed.id);
				comments.push(parsed);
			}
		}
		const item = asJson(o.continuationItemRenderer);
		if (item) {
			const tok = tokenOf(item);
			if (tok) {
				const utf = continuationUtf8(tok);
				const label = `${textOf(item.trigger)} ${utf}`.toLowerCase();
				if (/spam|hidden|held for review|probable/i.test(label)) hiddenContinuation = tok;
				else if (!/replies/i.test(utf) && (/top_level|comment_post|comments-section/i.test(utf) || item.trigger === "CONTINUATION_TRIGGER_ON_ITEM_SHOWN")) continuation = tok;
			}
		}
	});
	return {
		comments,
		continuation,
		hiddenContinuation,
		totalText,
		newestToken,
		topToken
	};
}
async function resolveCommentParams(postId, fallback) {
	if (fallback) return fallback;
	try {
		const resolved = await innertube("navigation/resolve_url", { url: `https://www.youtube.com/post/${postId}` });
		let params = null;
		walk(resolved, (o) => {
			const browse = asJson(o.browseEndpoint) || asJson(asJson(o.endpoint)?.browseEndpoint);
			if (browse && browse.browseId === "FEpost_detail" && typeof browse.params === "string") params = browse.params;
		});
		return params;
	} catch {
		return null;
	}
}
async function getPostComments(input) {
	try {
		let json;
		if (input.continuation) json = await innertube("browse", { continuation: decodeContinuation(input.continuation) });
		else {
			const params = await resolveCommentParams(input.postId, input.commentParams ?? null);
			if (!params) return {
				comments: [],
				continuation: null,
				hiddenContinuation: null,
				totalText: ""
			};
			const detail = await innertube("browse", {
				browseId: "FEpost_detail",
				params
			});
			let seed = null;
			walk(detail, (o) => {
				const tok = tokenOf(asJson(o.continuationItemRenderer));
				if (tok && /comment/i.test(continuationUtf8(tok))) seed = tok;
				else if (tok && !seed) seed = tok;
			});
			if (!seed) return {
				comments: [],
				continuation: null,
				hiddenContinuation: null,
				totalText: ""
			};
			json = await innertube("browse", { continuation: seed });
			const first = parseCommentsPage(json);
			if (input.sort === "top") {
				if (first.topToken) json = await innertube("browse", { continuation: first.topToken });
			} else if (first.newestToken) json = await innertube("browse", { continuation: first.newestToken });
		}
		const page = parseCommentsPage(json);
		let comments = page.comments;
		let continuation = page.continuation;
		let hiddenContinuation = page.hiddenContinuation;
		const totalText = page.totalText;
		if (input.includeHidden !== false && hiddenContinuation) try {
			const hiddenPage = parseCommentsPage(await innertube("browse", { continuation: hiddenContinuation }));
			const seen = new Set(comments.map((c) => c.id));
			for (const c of hiddenPage.comments) {
				if (seen.has(c.id)) continue;
				comments.push({
					...c,
					hidden: true
				});
			}
			hiddenContinuation = hiddenPage.hiddenContinuation;
		} catch {}
		return {
			comments,
			continuation,
			hiddenContinuation,
			totalText
		};
	} catch {
		return {
			comments: [],
			continuation: null,
			hiddenContinuation: null,
			totalText: ""
		};
	}
}
//#endregion
export { getChannel, getChannelPosts, getPostComments, loadFeedPage, parseUserQuery, resolveChannel, searchChannels };
