import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ask-De-6zIMS.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var askFrieren_createServerFn_handler = createServerRpc({
	id: "c4ce772559c0b417e31670dcb4486b978892238fc53563cba9efe209ef13f2c4",
	name: "askFrieren",
	filename: "src/lib/frieren/ask.ts"
}, (opts) => askFrieren.__executeServer(opts));
var askFrieren = createServerFn({ method: "POST" }).validator((input) => input).handler(askFrieren_createServerFn_handler, async ({ data }) => {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "Brain is unavailable in this environment."
	};
	const res = await fetch("https://api.x.ai/v1/chat/completions", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		body: JSON.stringify({
			model: "grok-4.5",
			max_tokens: 700,
			temperature: .4,
			messages: [{
				role: "system",
				content: [
					"You are FRIEREN, a calm local-first personal orchestration assistant.",
					"Speak plainly. No emoji. No hype.",
					"Never claim a device action, SMS, call, or task execution completed unless the user context already shows a verified result.",
					"Consequential actions require explicit confirmation. If the user asks you to do something risky, describe the plan and wait.",
					"Prefer short, structured answers. Use the local memory and graph context when relevant.",
					"If a request maps to remember / create task / status, say so clearly so the client can execute it locally.",
					"Context from the local kernel:",
					data.context.slice(0, 4e3)
				].join("\n")
			}, {
				role: "user",
				content: data.prompt.slice(0, 4e3)
			}]
		})
	});
	if (!res.ok) return {
		ok: false,
		error: `Brain error ${res.status}`
	};
	return {
		ok: true,
		text: (await res.json()).choices[0]?.message.content ?? ""
	};
});
//#endregion
export { askFrieren_createServerFn_handler };
