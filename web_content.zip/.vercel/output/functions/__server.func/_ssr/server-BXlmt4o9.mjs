import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { a as fallbackOffline, i as fallbackMissed } from "./prompts-DWlqwQ_V.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/server-BXlmt4o9.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var URGENCIES = [
	"low",
	"normal",
	"high",
	"emergency"
];
function asStringArray(value) {
	if (!Array.isArray(value)) return [];
	return value.filter((v) => typeof v === "string" && v.trim().length > 0);
}
function parseJsonObject(raw) {
	const trimmed = raw.trim();
	const body = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/i)?.[1] ?? trimmed;
	const start = body.indexOf("{");
	const end = body.lastIndexOf("}");
	if (start < 0 || end <= start) return null;
	try {
		return JSON.parse(body.slice(start, end + 1));
	} catch {
		return null;
	}
}
async function chat(args) {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "AI is not available"
	};
	try {
		const res = await fetch("https://api.x.ai/v1/chat/completions", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${apiKey}`
			},
			body: JSON.stringify({
				model: "grok-4.5",
				temperature: args.temperature,
				max_tokens: args.maxTokens,
				response_format: { type: "json_object" },
				messages: args.messages
			}),
			signal: AbortSignal.timeout(22e3)
		});
		if (!res.ok) return {
			ok: false,
			error: `xAI API error ${res.status}`
		};
		const text = (await res.json()).choices?.[0]?.message?.content ?? "";
		if (!text) return {
			ok: false,
			error: "empty"
		};
		return {
			ok: true,
			text
		};
	} catch {
		return {
			ok: false,
			error: "timeout"
		};
	}
}
function parseReply(raw) {
	const obj = parseJsonObject(raw);
	const extractedRaw = obj?.extracted ?? {};
	const urgencyRaw = String(extractedRaw.urgency ?? "normal");
	const extracted = {
		reason: typeof extractedRaw.reason === "string" ? extractedRaw.reason : void 0,
		people: asStringArray(extractedRaw.people),
		dates: asStringArray(extractedRaw.dates),
		times: asStringArray(extractedRaw.times),
		locations: asStringArray(extractedRaw.locations),
		requests: asStringArray(extractedRaw.requests),
		promises: asStringArray(extractedRaw.promises),
		importantInfo: asStringArray(extractedRaw.importantInfo),
		urgency: URGENCIES.includes(urgencyRaw) ? urgencyRaw : "normal",
		message: typeof extractedRaw.message === "string" && extractedRaw.message.trim() ? extractedRaw.message : null
	};
	return {
		reply: typeof obj?.reply === "string" && obj.reply.trim() ? obj.reply.trim() : fallbackMissed(),
		intent: typeof obj?.intent === "string" ? obj.intent : "clarify",
		shouldEndCall: Boolean(obj?.shouldEndCall),
		extracted
	};
}
var getAiStatus_createServerFn_handler = createServerRpc({
	id: "c2b71ab994a8d1ee84d621e29674fed647d9ace14433d69cc4015ed6da34eb4c",
	name: "getAiStatus",
	filename: "src/lib/ai/server.ts"
}, (opts) => getAiStatus.__executeServer(opts));
var getAiStatus = createServerFn({ method: "POST" }).handler(getAiStatus_createServerFn_handler, async () => {
	return { available: Boolean(process.env.XAI_API_KEY) };
});
var converseWithLisa_createServerFn_handler = createServerRpc({
	id: "0a03cbdef44ff1a18d34c724b14dc805e664ee1c48f88a8111cf926649ab20fd",
	name: "converseWithLisa",
	filename: "src/lib/ai/server.ts"
}, (opts) => converseWithLisa.__executeServer(opts));
var converseWithLisa = createServerFn({ method: "POST" }).validator((input) => input).handler(converseWithLisa_createServerFn_handler, async ({ data }) => {
	const caller = data.callerText.trim().slice(0, 2e3);
	if (!caller) return {
		ok: false,
		data: {
			reply: fallbackMissed(),
			intent: "clarify",
			shouldEndCall: false,
			extracted: {}
		}
	};
	const history = data.turns.slice(-16).map((t) => ({
		role: t.role === "lisa" ? "assistant" : "user",
		content: t.text
	}));
	const result = await chat({
		temperature: .55,
		maxTokens: 420,
		messages: [
			{
				role: "system",
				content: data.system
			},
			...history,
			{
				role: "user",
				content: caller
			}
		]
	});
	if (!result.ok) return {
		ok: false,
		data: {
			reply: fallbackOffline(),
			intent: "decline",
			shouldEndCall: false,
			extracted: {}
		}
	};
	return {
		ok: true,
		data: parseReply(result.text)
	};
});
var summarizeCall_createServerFn_handler = createServerRpc({
	id: "fbc3d15f5d1d2ae184a76bddd4279c84e115fcb1717e55cd77593a92919fbe6a",
	name: "summarizeCall",
	filename: "src/lib/ai/server.ts"
}, (opts) => summarizeCall.__executeServer(opts));
var summarizeCall = createServerFn({ method: "POST" }).validator((input) => input).handler(summarizeCall_createServerFn_handler, async ({ data }) => {
	const result = await chat({
		temperature: .2,
		maxTokens: 500,
		messages: [{
			role: "user",
			content: data.prompt.slice(0, 8e3)
		}]
	});
	if (!result.ok) return {
		ok: false,
		error: result.error
	};
	const obj = parseJsonObject(result.text) ?? {};
	const urgencyRaw = String(obj.urgency ?? "normal");
	return {
		ok: true,
		summary: {
			reason: typeof obj.reason === "string" && obj.reason ? obj.reason : "Conversation",
			summary: typeof obj.summary === "string" && obj.summary ? obj.summary : `${data.callerName} called ${data.callerNumber}.`,
			importantInfo: typeof obj.importantInfo === "string" && obj.importantInfo ? obj.importantInfo : "None noted.",
			urgency: URGENCIES.includes(urgencyRaw) ? urgencyRaw : "normal",
			message: typeof obj.message === "string" && obj.message ? obj.message : "No additional message.",
			people: asStringArray(obj.people),
			dates: asStringArray(obj.dates),
			times: asStringArray(obj.times),
			locations: asStringArray(obj.locations),
			requests: asStringArray(obj.requests),
			promises: asStringArray(obj.promises)
		}
	};
});
var speakLisa_createServerFn_handler = createServerRpc({
	id: "5b218b4c6adcf0c3ffa8a44d0e88e5b3e0f8257af1d928981aa1604b2a54d693",
	name: "speakLisa",
	filename: "src/lib/ai/server.ts"
}, (opts) => speakLisa.__executeServer(opts));
var speakLisa = createServerFn({ method: "POST" }).validator((input) => input).handler(speakLisa_createServerFn_handler, async ({ data }) => {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "AI is not available"
	};
	const text = data.text.trim().slice(0, 500);
	if (!text) return {
		ok: false,
		error: "empty"
	};
	try {
		const res = await fetch("https://api.x.ai/v1/tts", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${apiKey}`
			},
			body: JSON.stringify({
				text,
				voice_id: data.voiceId,
				language: "en"
			}),
			signal: AbortSignal.timeout(2e4)
		});
		if (!res.ok) return {
			ok: false,
			error: `tts ${res.status}`
		};
		const buf = Buffer.from(await res.arrayBuffer());
		return {
			ok: true,
			mime: res.headers.get("content-type") || "audio/mpeg",
			audio: buf.toString("base64")
		};
	} catch {
		return {
			ok: false,
			error: "tts timeout"
		};
	}
});
//#endregion
export { converseWithLisa_createServerFn_handler, getAiStatus_createServerFn_handler, speakLisa_createServerFn_handler, summarizeCall_createServerFn_handler };
