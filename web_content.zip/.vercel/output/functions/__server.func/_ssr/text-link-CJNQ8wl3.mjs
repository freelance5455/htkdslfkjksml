import { b as useRouter, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/text-link-CJNQ8wl3.js
var import_jsx_runtime = require_jsx_runtime();
function TextLink({ href, className, children }) {
	const router = useRouter();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
		href,
		className,
		onClick: (e) => {
			if (e.metaKey || e.ctrlKey || e.button !== 0) return;
			e.preventDefault();
			router.history.push(href);
		},
		children
	});
}
//#endregion
export { TextLink as t };
