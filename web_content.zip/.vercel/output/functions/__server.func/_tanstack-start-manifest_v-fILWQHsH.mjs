//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-fILWQHsH.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/adhkar/$listId",
			"/library/$bookId",
			"/quran/$surahId",
			"/adhkar/",
			"/favorites/",
			"/library/",
			"/listen/",
			"/more/",
			"/quran/",
			"/search/"
		],
		preloads: [
			"/assets/index-D4vBwDRR.js",
			"/assets/createLucideIcon-BwiAB6cH.js",
			"/assets/lazyRouteComponent-AbmFQqSh.js",
			"/assets/preload-helper-Czpn1I53.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-D4vBwDRR.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CbURmumw.js",
			"/assets/app-shell-Clje0t7F.js",
			"/assets/search-D9dDd4T9.js",
			"/assets/catalog-cKUwFbTC.js"
		]
	},
	"/adhkar/$listId": {
		filePath: "/workspace/src/routes/adhkar/$listId.tsx",
		children: void 0,
		preloads: [
			"/assets/_listId-D2uOrnNe.js",
			"/assets/app-shell-Clje0t7F.js",
			"/assets/back-button-D0XzFaU_.js",
			"/assets/share-BT7qq-qz.js",
			"/assets/volume-2-BGh-l6nd.js",
			"/assets/catalog-cKUwFbTC.js"
		]
	},
	"/library/$bookId": {
		filePath: "/workspace/src/routes/library/$bookId.tsx",
		children: void 0,
		preloads: [
			"/assets/_bookId-BVrlWOe-.js",
			"/assets/app-shell-Clje0t7F.js",
			"/assets/back-button-D0XzFaU_.js",
			"/assets/plus-u1vcTf3d.js",
			"/assets/share-BT7qq-qz.js",
			"/assets/volume-2-BGh-l6nd.js",
			"/assets/catalog-cKUwFbTC.js",
			"/assets/text-link-DY0Dmnkk.js"
		]
	},
	"/quran/$surahId": {
		filePath: "/workspace/src/routes/quran/$surahId.tsx",
		children: void 0,
		preloads: [
			"/assets/_surahId-DKizghqY.js",
			"/assets/app-shell-Clje0t7F.js",
			"/assets/bookmark-BgB2z51U.js",
			"/assets/back-button-D0XzFaU_.js",
			"/assets/download-BLlIw1Xz.js",
			"/assets/plus-u1vcTf3d.js",
			"/assets/share-BT7qq-qz.js",
			"/assets/catalog-cKUwFbTC.js"
		]
	},
	"/adhkar/": {
		filePath: "/workspace/src/routes/adhkar/index.tsx",
		children: void 0,
		preloads: [
			"/assets/adhkar-DtF-oAPw.js",
			"/assets/app-shell-Clje0t7F.js",
			"/assets/back-button-D0XzFaU_.js",
			"/assets/catalog-cKUwFbTC.js"
		]
	},
	"/favorites/": {
		filePath: "/workspace/src/routes/favorites/index.tsx",
		children: void 0,
		preloads: [
			"/assets/favorites-B3VQ7Kve.js",
			"/assets/app-shell-Clje0t7F.js",
			"/assets/bookmark-BgB2z51U.js",
			"/assets/back-button-D0XzFaU_.js",
			"/assets/text-link-DY0Dmnkk.js"
		]
	},
	"/library/": {
		filePath: "/workspace/src/routes/library/index.tsx",
		children: void 0,
		preloads: [
			"/assets/library-BrOXGZmr.js",
			"/assets/app-shell-Clje0t7F.js",
			"/assets/back-button-D0XzFaU_.js",
			"/assets/catalog-cKUwFbTC.js"
		]
	},
	"/listen/": {
		filePath: "/workspace/src/routes/listen/index.tsx",
		children: void 0,
		preloads: [
			"/assets/listen-CF6VxrR7.js",
			"/assets/app-shell-Clje0t7F.js",
			"/assets/back-button-D0XzFaU_.js",
			"/assets/download-BLlIw1Xz.js",
			"/assets/catalog-cKUwFbTC.js"
		]
	},
	"/more/": {
		filePath: "/workspace/src/routes/more/index.tsx",
		children: void 0,
		preloads: [
			"/assets/more-PdwPkF_Y.js",
			"/assets/app-shell-Clje0t7F.js",
			"/assets/back-button-D0XzFaU_.js",
			"/assets/catalog-cKUwFbTC.js"
		]
	},
	"/quran/": {
		filePath: "/workspace/src/routes/quran/index.tsx",
		children: void 0,
		preloads: [
			"/assets/quran-VCuoqE1X.js",
			"/assets/app-shell-Clje0t7F.js",
			"/assets/back-button-D0XzFaU_.js",
			"/assets/search-D9dDd4T9.js",
			"/assets/catalog-cKUwFbTC.js"
		]
	},
	"/search/": {
		filePath: "/workspace/src/routes/search/index.tsx",
		children: void 0,
		preloads: [
			"/assets/search-5WVn5xqt.js",
			"/assets/app-shell-Clje0t7F.js",
			"/assets/back-button-D0XzFaU_.js",
			"/assets/search-D9dDd4T9.js",
			"/assets/catalog-cKUwFbTC.js",
			"/assets/text-link-DY0Dmnkk.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
