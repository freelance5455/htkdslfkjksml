//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BSh8LLCh.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-C93BR52u.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-C93BR52u.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-KzcV0TDA.js"]
	}
} });
//#endregion
export { tsrStartManifest };
