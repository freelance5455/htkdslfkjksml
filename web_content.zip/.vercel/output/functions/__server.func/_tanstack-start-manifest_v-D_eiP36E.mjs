//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D_eiP36E.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CFRywOe1.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CFRywOe1.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-C49Cec1g.js"]
	}
} });
//#endregion
export { tsrStartManifest };
