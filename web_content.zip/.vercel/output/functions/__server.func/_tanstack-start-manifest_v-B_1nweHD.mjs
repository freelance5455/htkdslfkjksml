//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-B_1nweHD.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-n3rVF8uC.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-n3rVF8uC.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CO--zkRo.js"]
	}
} });
//#endregion
export { tsrStartManifest };
