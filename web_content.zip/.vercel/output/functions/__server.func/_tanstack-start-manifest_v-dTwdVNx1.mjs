//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-dTwdVNx1.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/api/chat",
			"/api/hear",
			"/api/speak"
		],
		preloads: ["/assets/index-CjyxNNtJ.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CjyxNNtJ.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DNUHDSVl.js"]
	}
} });
//#endregion
export { tsrStartManifest };
