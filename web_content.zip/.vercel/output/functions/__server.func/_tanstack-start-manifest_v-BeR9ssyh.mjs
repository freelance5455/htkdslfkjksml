//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BeR9ssyh.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CNQv86y2.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CNQv86y2.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-B1F6cZZm.js"]
	}
} });
//#endregion
export { tsrStartManifest };
