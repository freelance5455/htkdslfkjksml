//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-C3o0zubl.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/login",
			"/api/auth/$"
		],
		preloads: ["/assets/index-CamS4f-r.js", "/assets/react-SIfiwpqq.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CamS4f-r.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-B_qhPclG.js", "/assets/gates-DWphpcce.js"]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: ["/assets/login-CxAscbHm.js", "/assets/gates-DWphpcce.js"]
	}
} });
//#endregion
export { tsrStartManifest };
