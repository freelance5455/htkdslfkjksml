# Satoriuou Hub — исправленный Android-проект

Исправлена причина `net::ERR_HTTP_RESPONSE_CODE_FAILURE` при открытии `https://appassets.androidplatform.net/web/index.html`.

Важное исправление: Android `WebViewAssetLoader` теперь явно обслуживает `/web/` из `app/src/main/assets/web/`.

Откройте папку в Android Studio и соберите APK через **Build > Build APK(s)**.
