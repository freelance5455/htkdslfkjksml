"use strict";

const BUDGET_LIMIT = 20000;
const STORAGE_KEY = "personalExpensesManagerBills_v1";
const REMINDER_LOG_KEY = "personalExpensesManagerReminderLog_v1";

const form = document.getElementById("billForm");
const billIdInput = document.getElementById("billId");
const billNameInput = document.getElementById("billName");
const billAmountInput = document.getElementById("billAmount");
const billDueDateInput = document.getElementById("billDueDate");
const reminderDaysInput = document.getElementById("reminderDays");
const repeatMonthlyInput = document.getElementById("repeatMonthly");
const formTitle = document.getElementById("formTitle");
const saveBillBtn = document.getElementById("saveBillBtn");
const cancelEditBtn = document.getElementById("cancelEditBtn");
const formMessage = document.getElementById("formMessage");
const billList = document.getElementById("billList");
const emptyState = document.getElementById("emptyState");
const statusFilter = document.getElementById("statusFilter");
const notificationStatus = document.getElementById("notificationStatus");
const enableNotificationsBtn = document.getElementById("enableNotificationsBtn");

let bills = loadBills();

function loadBills() {
  try {
    const parsed = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
    return Array.isArray(parsed) ? parsed.filter(isValidStoredBill) : [];
  } catch (error) {
    console.error("Could not load saved bills:", error);
    return [];
  }
}

function isValidStoredBill(bill) {
  return bill && typeof bill.id === "string" &&
    typeof bill.name === "string" &&
    Number.isFinite(Number(bill.amount)) && Number(bill.amount) > 0 &&
    typeof bill.dueDate === "string" && /^\d{4}-\d{2}-\d{2}$/.test(bill.dueDate);
}

function saveBills() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(bills));
    return true;
  } catch (error) {
    console.error("Could not save bills:", error);
    showFormMessage("Hindi ma-save ang data. Tingnan kung enabled ang browser storage.", "error");
    return false;
  }
}

function loadReminderLog() {
  try {
    const value = JSON.parse(localStorage.getItem(REMINDER_LOG_KEY) || "{}");
    return value && typeof value === "object" ? value : {};
  } catch {
    return {};
  }
}

function saveReminderLog(log) {
  try { localStorage.setItem(REMINDER_LOG_KEY, JSON.stringify(log)); } catch (error) {
    console.warn("Could not save reminder log:", error);
  }
}

function peso(value) {
  return new Intl.NumberFormat("en-PH", {
    style: "currency", currency: "PHP", minimumFractionDigits: 2
  }).format(value);
}

function localDateString(date = new Date()) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function dateDifference(dateString) {
  const [year, month, day] = dateString.split("-").map(Number);
  const due = Date.UTC(year, month - 1, day);
  const now = new Date();
  const today = Date.UTC(now.getFullYear(), now.getMonth(), now.getDate());
  return Math.round((due - today) / 86400000);
}

function isOverdue(bill) {
  return !bill.paid && dateDifference(bill.dueDate) < 0;
}

function getStatus(bill) {
  if (bill.paid) return "paid";
  if (isOverdue(bill)) return "overdue";
  return "unpaid";
}

function showFormMessage(message, type = "") {
  formMessage.textContent = message;
  formMessage.className = `form-message ${type}`.trim();
}

function currentMonthKey(date = new Date()) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
}

function isCurrentMonthBill(bill) {
  return bill.dueDate.slice(0, 7) === currentMonthKey();
}

function render() {
  const monthBills = bills.filter(isCurrentMonthBill);
  const unpaidBills = monthBills.filter(bill => !bill.paid);
  const paidBills = monthBills.filter(bill => bill.paid);
  const unpaidTotal = unpaidBills.reduce((sum, bill) => sum + Number(bill.amount), 0);
  const paidTotal = paidBills.reduce((sum, bill) => sum + Number(bill.amount), 0);
  const remaining = BUDGET_LIMIT - unpaidTotal;

  document.getElementById("unpaidTotal").textContent = peso(unpaidTotal);
  document.getElementById("paidTotal").textContent = peso(paidTotal);
  document.getElementById("remainingTotal").textContent = peso(remaining);

  const percentage = Math.min((unpaidTotal / BUDGET_LIMIT) * 100, 100);
  document.getElementById("budgetProgress").style.width = `${percentage}%`;

  const message = document.getElementById("budgetMessage");
  if (unpaidTotal > BUDGET_LIMIT) {
    message.textContent = `Over budget by ${peso(unpaidTotal - BUDGET_LIMIT)}. Reduce or edit your planned bills.`;
    message.style.color = "#ffe0e0";
  } else if (unpaidTotal >= BUDGET_LIMIT * 0.8) {
    message.textContent = `Warning: you have used ${percentage.toFixed(0)}% of your budget.`;
    message.style.color = "#fff0c2";
  } else {
    message.textContent = `You have ${peso(remaining)} of the ₱20,000 budget available for unpaid bills.`;
    message.style.color = "#f0f5ff";
  }

  const filter = statusFilter.value;
  const filteredBills = monthBills
    .filter(bill => {
      const status = getStatus(bill);
      return filter === "all" || status === filter;
    })
    .sort((a, b) => a.dueDate.localeCompare(b.dueDate));

  billList.replaceChildren();
  emptyState.classList.toggle("hidden", filteredBills.length > 0);

  filteredBills.forEach(bill => {
    const status = getStatus(bill);
    const item = document.createElement("article");
    item.className = "bill-item";

    const main = document.createElement("div");
    main.className = "bill-main";
    const info = document.createElement("div");

    const title = document.createElement("h3");
    title.className = "bill-title";
    title.textContent = bill.name;

    const date = document.createElement("p");
    date.className = "bill-date";
    date.textContent = dueDateLabel(bill.dueDate);

    const statusLabel = document.createElement("span");
    statusLabel.className = `status status-${status}`;
    statusLabel.textContent = status === "paid" ? "PAID" : status === "overdue" ? "OVERDUE" : "UNPAID";

    info.append(title, date, statusLabel);

    const amount = document.createElement("strong");
    amount.className = "bill-amount";
    amount.textContent = peso(Number(bill.amount));
    main.append(info, amount);

    const actions = document.createElement("div");
    actions.className = "bill-actions";

    const paidButton = makeActionButton(bill.paid ? "Mark unpaid" : "Mark paid", () => togglePaid(bill.id));
    const editButton = makeActionButton("Edit", () => startEdit(bill.id));
    const deleteButton = makeActionButton("Delete", () => deleteBill(bill.id), true);
    actions.append(paidButton, editButton, deleteButton);

    item.append(main, actions);
    billList.append(item);
  });
}

function dueDateLabel(dateString) {
  const difference = dateDifference(dateString);
  const [year, month, day] = dateString.split("-").map(Number);
  const formatted = new Intl.DateTimeFormat("en-PH", {
    year: "numeric", month: "short", day: "numeric"
  }).format(new Date(year, month - 1, day));

  if (difference < 0) return `Due ${formatted} · ${Math.abs(difference)} day(s) overdue`;
  if (difference === 0) return `Due today · ${formatted}`;
  if (difference === 1) return `Due tomorrow · ${formatted}`;
  return `Due ${formatted} · ${difference} day(s) left`;
}

function makeActionButton(label, action, danger = false) {
  const button = document.createElement("button");
  button.type = "button";
  button.className = `mini-button${danger ? " danger" : ""}`;
  button.textContent = label;
  button.addEventListener("click", action);
  return button;
}

function resetForm() {
  form.reset();
  billIdInput.value = "";
  reminderDaysInput.value = "3";
  repeatMonthlyInput.checked = true;
  formTitle.textContent = "Add a bill";
  saveBillBtn.textContent = "Add bill";
  cancelEditBtn.classList.add("hidden");
  showFormMessage("");
}

function startEdit(id) {
  const bill = bills.find(item => item.id === id);
  if (!bill) return;
  billIdInput.value = bill.id;
  billNameInput.value = bill.name;
  billAmountInput.value = bill.amount;
  billDueDateInput.value = bill.dueDate;
  reminderDaysInput.value = String(bill.reminderDays ?? 3);
  repeatMonthlyInput.checked = bill.repeatMonthly !== false;
  formTitle.textContent = "Edit bill";
  saveBillBtn.textContent = "Save changes";
  cancelEditBtn.classList.remove("hidden");
  showFormMessage("Edit the details, then save your changes.");
  form.scrollIntoView({ behavior: "smooth", block: "start" });
}

function togglePaid(id) {
  const bill = bills.find(item => item.id === id);
  if (!bill) return;
  bill.paid = !bill.paid;
  bill.updatedAt = new Date().toISOString();
  // When a recurring monthly bill is paid, create the next month's occurrence.
  if (bill.paid && bill.repeatMonthly !== false) {
    const [year, month, day] = bill.dueDate.split("-").map(Number);
    const nextMonthFirst = new Date(year, month, 1);
    const lastDay = new Date(nextMonthFirst.getFullYear(), nextMonthFirst.getMonth() + 1, 0).getDate();
    const nextDue = new Date(nextMonthFirst.getFullYear(), nextMonthFirst.getMonth(), Math.min(day, lastDay));
    const nextDueDate = localDateString(nextDue);
    const alreadyExists = bills.some(item => item.id !== bill.id && item.name === bill.name && item.dueDate === nextDueDate);
    if (!alreadyExists) {
      bills.push({
        id: window.crypto && crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`,
        name: bill.name, amount: Number(bill.amount), dueDate: nextDueDate,
        reminderDays: Number(bill.reminderDays ?? 3), repeatMonthly: true, paid: false,
        createdAt: new Date().toISOString(), updatedAt: new Date().toISOString()
      });
    }
  }
  if (saveBills()) {
    render();
    showFormMessage(bill.paid ? "Marked as paid." : "Marked as unpaid.", "success");
  }
}

function deleteBill(id) {
  const bill = bills.find(item => item.id === id);
  if (!bill) return;
  if (!window.confirm(`Delete "${bill.name}"? This cannot be undone.`)) return;
  bills = bills.filter(item => item.id !== id);
  if (saveBills()) {
    render();
    showFormMessage("Bill deleted.", "success");
  }
}

form.addEventListener("submit", event => {
  event.preventDefault();

  const name = billNameInput.value.trim();
  const amount = Number(billAmountInput.value);
  const dueDate = billDueDateInput.value;
  const reminderDays = Number(reminderDaysInput.value);
  const repeatMonthly = repeatMonthlyInput.checked;
  const editingId = billIdInput.value;

  if (!name || !Number.isFinite(amount) || amount <= 0 || !dueDate) {
    showFormMessage("Please enter a bill name, a valid amount, and a due date.", "error");
    return;
  }

  const existing = editingId ? bills.find(bill => bill.id === editingId) : null;
  const candidate = {
    id: editingId || (window.crypto && crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`),
    name, amount, dueDate, reminderDays, repeatMonthly,
    paid: existing ? existing.paid : false,
    createdAt: existing ? existing.createdAt : new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  // Budget rule: total unpaid bills must not exceed ₱20,000.
  const proposedBills = existing
    ? bills.map(bill => bill.id === editingId ? candidate : bill)
    : [...bills, candidate];
  const proposedUnpaid = proposedBills
    .filter(bill => !bill.paid && isCurrentMonthBill(bill))
    .reduce((sum, bill) => sum + Number(bill.amount), 0);

  if (proposedUnpaid > BUDGET_LIMIT) {
    showFormMessage(`This bill would exceed the ₱20,000 budget by ${peso(proposedUnpaid - BUDGET_LIMIT)}. Lower an amount or remove another unpaid bill first.`, "error");
    return;
  }

  bills = proposedBills;
  if (saveBills()) {
    resetForm();
    render();
    showFormMessage(existing ? "Bill updated successfully." : "Bill added successfully.", "success");
    checkDueReminders();
  }
});

cancelEditBtn.addEventListener("click", resetForm);
statusFilter.addEventListener("change", render);

enableNotificationsBtn.addEventListener("click", async () => {
  if (!("Notification" in window)) {
    notificationStatus.textContent = "This browser does not support desktop notifications. You can still see due dates in the app.";
    return;
  }
  if (!window.isSecureContext) {
    notificationStatus.textContent = "Open this app through localhost (for example, Live Server) to enable notifications.";
    return;
  }
  try {
    const permission = await Notification.requestPermission();
    updateNotificationStatus();
    if (permission === "granted") {
      showDesktopNotification("Notifications enabled", "Your bill reminders can appear while this app is open.");
      checkDueReminders();
    }
  } catch (error) {
    console.error("Notification permission request failed:", error);
    notificationStatus.textContent = "Could not request notification permission. Check your browser settings.";
  }
});

function updateNotificationStatus() {
  if (!("Notification" in window)) {
    notificationStatus.textContent = "Desktop notifications are not supported by this browser.";
    return;
  }
  const permission = Notification.permission;
  if (permission === "granted") {
    notificationStatus.textContent = "Enabled. Keep this page open to check reminders.";
    enableNotificationsBtn.textContent = "Notifications enabled";
  } else if (permission === "denied") {
    notificationStatus.textContent = "Blocked by browser settings. Allow notifications for this site in your browser settings.";
    enableNotificationsBtn.textContent = "Notifications blocked";
  } else {
    notificationStatus.textContent = "Not enabled yet. Click Enable notifications and allow permission.";
  }
}

function showDesktopNotification(title, body) {
  if (!("Notification" in window) || Notification.permission !== "granted") return;
  try {
    const notification = new Notification(title, { body, tag: "personal-expenses-manager" });
    notification.onclick = () => {
      window.focus();
      notification.close();
    };
  } catch (error) {
    console.warn("Could not show desktop notification:", error);
  }
}

function checkDueReminders() {
  if (!("Notification" in window) || Notification.permission !== "granted") return;
  const today = localDateString();
  const log = loadReminderLog();

  bills.forEach(bill => {
    if (bill.paid) return;
    const daysLeft = dateDifference(bill.dueDate);
    const reminderDays = Number(bill.reminderDays ?? 3);
    const isReminderDay = daysLeft === reminderDays || daysLeft === 0 || daysLeft < 0;
    if (!isReminderDay) return;

    const logKey = `${bill.id}:${today}`;
    if (log[logKey]) return;

    let message;
    if (daysLeft < 0) message = `${bill.name} (${peso(Number(bill.amount))}) is ${Math.abs(daysLeft)} day(s) overdue.`;
    else if (daysLeft === 0) message = `${bill.name} (${peso(Number(bill.amount))}) is due today.`;
    else message = `${bill.name} (${peso(Number(bill.amount))}) is due in ${daysLeft} day(s).`;

    showDesktopNotification("Bill reminder", message);
    log[logKey] = true;
  });

  saveReminderLog(log);
}

function scheduleReminderChecks() {
  // Browser JavaScript runs only while this page is active/open.
  checkDueReminders();
  window.setInterval(checkDueReminders, 60 * 60 * 1000);
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden) checkDueReminders();
  });
  window.addEventListener("focus", checkDueReminders);
}

updateNotificationStatus();
render();
scheduleReminderChecks();
