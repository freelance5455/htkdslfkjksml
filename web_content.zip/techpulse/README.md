# TechPulse – actualités tech automatiques

Le serveur récupère lui-même les articles (flux RSS de TechCrunch, The Verge,
Ars Technica, Wired, BBC, Numerama, Journal du Geek, Le Monde Pixels), avec
leurs images, toutes les 30 minutes. Il gère aussi les comptes (email + mot de
passe), les favoris et les centres d'intérêt.

## Lancer chez soi
    pip install -r requirements.txt
    python app.py
Puis ouvrir http://localhost:5000 (ou http://IP-DE-VOTRE-PC:5000 depuis un téléphone sur le même Wi-Fi).

## Mettre en ligne
Hébergeurs simples : Render, Railway, PythonAnywhere, Fly.io (commande de
démarrage : `python app.py`, variable PORT fournie par l'hébergeur).
Pensez à utiliser un volume/disque persistant pour `techpulse.db` et le dossier `uploads/` (photos de profil).

## Personnaliser
- Sources : liste `FEEDS` dans `app.py`.
- Catégories : dictionnaire `CATS` (mots-clés) dans `app.py`.
- Fréquence : `INTERVAL` (en secondes).
