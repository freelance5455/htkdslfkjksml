"""TechPulse : agrégateur d'actualités tech avec comptes utilisateurs.
Lancer :  pip install -r requirements.txt  puis  python app.py
"""
import base64, calendar, os, re, secrets, sqlite3, threading, time
import feedparser
from flask import Flask, jsonify, request, send_from_directory, session
from werkzeug.security import check_password_hash, generate_password_hash

BASE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(BASE, "techpulse.db")
UPLOADS = os.path.join(BASE, "uploads")
INTERVAL = 30 * 60  # mise à jour automatique toutes les 30 minutes

# Sources (flux RSS). Ajoutez ou retirez des lignes librement.
FEEDS = [
    ("TechCrunch", "https://techcrunch.com/feed/"),
    ("The Verge", "https://www.theverge.com/rss/index.xml"),
    ("Ars Technica", "https://feeds.arstechnica.com/arstechnica/index"),
    ("Wired", "https://www.wired.com/feed/rss"),
    ("BBC Tech", "https://feeds.bbci.co.uk/news/technology/rss.xml"),
    ("Numerama", "https://www.numerama.com/feed/"),
    ("Journal du Geek", "https://www.journaldugeek.com/feed/"),
    ("Le Monde Pixels", "https://www.lemonde.fr/pixels/rss_full.xml"),
]

CATS = {
    "IA": r"\b(ai|ia|llm|openai|chatgpt|gemini|anthropic|claude|copilot|intelligence artificielle|artificial intelligence)\b",
    "Cybersécurité": r"\b(security|cyber\w*|hack\w*|breach|ransomware|malware|vulnerabilit\w*|phishing|sécurité|faille\w*|piratage|fuite)\b",
    "Cloud": r"\b(cloud|aws|azure|data ?centers?|serveurs?|servers?)\b",
    "Réseaux": r"\b(5g|6g|wi-?fi|starlink|satellites?|fibre|telecoms?|télécoms?|réseaux?)\b",
    "Robotique": r"\b(robots?|robotique|humano\w+|humanoid\w*|drones?)\b",
    "Science": r"\b(quantum|quantique|adn|dna|biolog\w*|space|nasa|esa|spacex|science\w*)\b",
    "Mobile": r"\b(iphone|android|ios|samsung|pixel|smartphones?|apple|mobile)\b",
    "Jeux": r"\b(games?|gaming|playstation|xbox|nintendo|jeux?)\b",
    "Développement": r"\b(developers?|développeurs?|programming|open ?source|github|python|rust|javascript|linux|api)\b",
}


def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    return c


def init_db():
    with db() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS articles(
          id INTEGER PRIMARY KEY, link TEXT UNIQUE, title TEXT, summary TEXT,
          image TEXT, source TEXT, cat TEXT, published INTEGER);
        CREATE TABLE IF NOT EXISTS users(
          id INTEGER PRIMARY KEY, email TEXT UNIQUE, pass_hash TEXT,
          pseudo TEXT DEFAULT '', ville TEXT DEFAULT '', bio TEXT DEFAULT '',
          interets TEXT DEFAULT '');
        CREATE TABLE IF NOT EXISTS favs(
          user_id INTEGER, article_id INTEGER, UNIQUE(user_id, article_id));
        """)
        cols = {r["name"] for r in c.execute("PRAGMA table_info(users)")}
        if "avatar" not in cols:
            c.execute("ALTER TABLE users ADD COLUMN avatar TEXT DEFAULT ''")
        if "onboarded" not in cols:
            c.execute("ALTER TABLE users ADD COLUMN onboarded INTEGER DEFAULT 0")


def categorize(text):
    t = text.lower()
    for cat, rx in CATS.items():
        if re.search(rx, t):
            return cat
    return "Autres"


def find_image(e):
    for k in ("media_content", "media_thumbnail"):
        for m in e.get(k) or []:
            if str(m.get("url", "")).startswith("http"):
                return m["url"]
    for l in e.get("links", []):
        if l.get("rel") == "enclosure" and str(l.get("type", "")).startswith("image"):
            return l.get("href", "")
    blob = " ".join([e.get("summary", "")] + [c.get("value", "") for c in e.get("content", [])])
    m = re.search(r'<img[^>]+src=["\'](https?://[^"\']+)', blob)
    return m.group(1) if m else ""


def clean(s, n=300):
    s = re.sub(r"<[^>]+>", " ", s or "")
    s = re.sub(r"\s+", " ", s).strip()
    import html
    s = html.unescape(s)
    return s if len(s) <= n else s[:n].rsplit(" ", 1)[0] + "…"


def fetch_all():
    added = 0
    for source, url in FEEDS:
        try:
            feed = feedparser.parse(url, agent="TechPulse/1.0")
        except Exception:
            continue
        for e in feed.entries[:30]:
            link = e.get("link", "")
            if not link.startswith("http") or not e.get("title"):
                continue
            t = e.get("published_parsed") or e.get("updated_parsed")
            ts = calendar.timegm(t) if t else int(time.time())
            title, summary = clean(e["title"], 200), clean(e.get("summary", ""))
            with db() as c:
                cur = c.execute(
                    "INSERT OR IGNORE INTO articles(link,title,summary,image,source,cat,published) VALUES(?,?,?,?,?,?,?)",
                    (link, title, summary, find_image(e), source, categorize(title + " " + summary), ts))
                added += cur.rowcount
    with db() as c:
        c.execute("DELETE FROM articles WHERE published < ?", (int(time.time()) - 60 * 86400,))
    return added


def loop():
    while True:
        try:
            fetch_all()
        except Exception as ex:
            print("Erreur de mise à jour :", ex)
        time.sleep(INTERVAL)


app = Flask(__name__, static_folder="static", static_url_path="/static")
keyfile = os.path.join(BASE, ".secret_key")
if not os.path.exists(keyfile):
    open(keyfile, "w").write(secrets.token_hex(32))
app.secret_key = open(keyfile).read().strip()
app.config.update(SESSION_COOKIE_SAMESITE="Lax", SESSION_COOKIE_HTTPONLY=True, MAX_CONTENT_LENGTH=1_000_000)


def user_dict(r):
    return {"email": r["email"], "pseudo": r["pseudo"], "ville": r["ville"], "bio": r["bio"],
            "interets": [x for x in r["interets"].split(",") if x],
            "avatar": r["avatar"] or "", "onboarded": bool(r["onboarded"])}


def current_user():
    uid = session.get("uid")
    if not uid:
        return None
    with db() as c:
        return c.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()


@app.get("/")
def index():
    return send_from_directory(os.path.join(BASE, "static"), "index.html")


@app.get("/api/news")
def news():
    where, args = [], [session.get("uid") or 0]
    cats = [c for c in request.args.get("cat", "").split(",") if c]
    if cats:
        where.append("a.cat IN (%s)" % ",".join("?" * len(cats)))
        args += cats
    q = request.args.get("q", "").strip()
    if q:
        where.append("(a.title LIKE ? OR a.summary LIKE ?)")
        args += ["%" + q + "%"] * 2
    if request.args.get("fav") == "1":
        where.append("f.user_id IS NOT NULL")
    sql = ("SELECT a.*, f.user_id IS NOT NULL AS fav FROM articles a "
           "LEFT JOIN favs f ON f.article_id=a.id AND f.user_id=? "
           + ("WHERE " + " AND ".join(where) + " " if where else "")
           + "ORDER BY a.published DESC LIMIT 60")
    with db() as c:
        rows = c.execute(sql, args).fetchall()
    return jsonify(items=[{**dict(r), "fav": bool(r["fav"])} for r in rows])


@app.post("/api/refresh")
def refresh():
    return jsonify(added=fetch_all())


@app.get("/api/me")
def me():
    u = current_user()
    return jsonify(user=user_dict(u) if u else None)


@app.post("/api/register")
def register():
    d = request.get_json(silent=True) or {}
    email, pw = str(d.get("email", "")).strip().lower(), str(d.get("password", ""))
    if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email) or len(pw) < 8:
        return jsonify(error="Email invalide ou mot de passe trop court (8 caractères minimum)."), 400
    try:
        with db() as c:
            cur = c.execute("INSERT INTO users(email,pass_hash,pseudo) VALUES(?,?,?)",
                            (email, generate_password_hash(pw), str(d.get("pseudo", ""))[:40]))
            uid = cur.lastrowid
    except sqlite3.IntegrityError:
        return jsonify(error="Un compte existe déjà avec cet email."), 409
    session["uid"] = uid
    return jsonify(user=user_dict(current_user()))


@app.post("/api/login")
def login():
    d = request.get_json(silent=True) or {}
    with db() as c:
        r = c.execute("SELECT * FROM users WHERE email=?", (str(d.get("email", "")).strip().lower(),)).fetchone()
    if not r or not check_password_hash(r["pass_hash"], str(d.get("password", ""))):
        return jsonify(error="Email ou mot de passe incorrect."), 401
    session["uid"] = r["id"]
    return jsonify(user=user_dict(r))


@app.post("/api/logout")
def logout():
    session.clear()
    return jsonify(ok=True)


@app.post("/api/profile")
def profile():
    u = current_user()
    if not u:
        return jsonify(error="Non connecté."), 401
    d = request.get_json(silent=True) or {}
    ints = [x for x in d.get("interets", []) if x in CATS or x == "Autres"]
    with db() as c:
        c.execute("UPDATE users SET pseudo=?,ville=?,bio=?,interets=?,onboarded=1 WHERE id=?",
                  (str(d.get("pseudo", ""))[:40], str(d.get("ville", ""))[:60],
                   str(d.get("bio", ""))[:300], ",".join(ints), u["id"]))
    return jsonify(user=user_dict(current_user()))


@app.post("/api/avatar")
def avatar():
    u = current_user()
    if not u:
        return jsonify(error="Non connecté."), 401
    data = (request.get_json(silent=True) or {}).get("image", "")
    m = re.match(r"data:image/(?:jpeg|png|webp);base64,(.+)", data, re.S)
    if not m:
        return jsonify(error="Image invalide."), 400
    try:
        raw = base64.b64decode(m.group(1), validate=True)
    except Exception:
        return jsonify(error="Image invalide."), 400
    if len(raw) > 600_000:
        return jsonify(error="Image trop lourde."), 413
    if raw.startswith(b"\xff\xd8\xff"):
        ext = "jpg"
    elif raw.startswith(b"\x89PNG\r\n\x1a\n"):
        ext = "png"
    elif raw[:4] == b"RIFF" and raw[8:12] == b"WEBP":
        ext = "webp"
    else:
        return jsonify(error="Format d'image non pris en charge."), 400
    os.makedirs(UPLOADS, exist_ok=True)
    name = "u%d-%d.%s" % (u["id"], int(time.time()), ext)
    with open(os.path.join(UPLOADS, name), "wb") as f:
        f.write(raw)
    old = u["avatar"] or ""
    if old.startswith("/uploads/"):
        try:
            os.remove(os.path.join(UPLOADS, os.path.basename(old)))
        except OSError:
            pass
    with db() as c:
        c.execute("UPDATE users SET avatar=? WHERE id=?", ("/uploads/" + name, u["id"]))
    return jsonify(user=user_dict(current_user()))


@app.get("/uploads/<path:name>")
def uploads(name):
    r = send_from_directory(UPLOADS, name)
    r.headers["X-Content-Type-Options"] = "nosniff"
    return r


@app.post("/api/fav/<int:aid>")
def fav(aid):
    u = current_user()
    if not u:
        return jsonify(error="Non connecté."), 401
    with db() as c:
        if c.execute("SELECT 1 FROM favs WHERE user_id=? AND article_id=?", (u["id"], aid)).fetchone():
            c.execute("DELETE FROM favs WHERE user_id=? AND article_id=?", (u["id"], aid))
            return jsonify(fav=False)
        c.execute("INSERT OR IGNORE INTO favs VALUES(?,?)", (u["id"], aid))
        return jsonify(fav=True)


init_db()
if os.environ.get("TECHPULSE_NO_BG") != "1":
    threading.Thread(target=loop, daemon=True).start()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)))
