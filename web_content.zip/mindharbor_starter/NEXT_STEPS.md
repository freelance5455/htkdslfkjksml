# MindHarbor: beginner-friendly setup

## A. Create your online database
1. Open https://supabase.com/ in Chrome and create an account.
2. Create a new project named `mindharbor`. Save the database password somewhere private.
3. In the project, open **SQL Editor** -> **New query**.
4. Open `supabase/schema.sql` from this ZIP, copy all its contents into the SQL Editor, and click **Run**.
5. Open **Project Settings** -> **API** (the exact menu may change). You will later need the Project URL and the publishable/anon key for the public website. Do not use a `service_role` or secret key in HTML.

## B. Create your private dashboard account
1. In Supabase, open **Authentication** and make sure email sign-ups are enabled.
2. Create an account using your own email from the app once its sign-in screen is connected, or use the Supabase Authentication user-management screen if available.
3. After that account exists, open **SQL Editor** and run the following query, replacing the email with your own:

   ```sql
   update public.profiles
   set role = 'admin'
   where id = (
     select id from auth.users
     where email = 'YOUR-EMAIL@example.com'
   );
   ```
4. Confirm one row was updated. Do not promote other users to admin.

## C. What still needs to be wired up
The supplied HTML is the visual prototype and does not yet connect to Supabase. The next code change must:
- add Supabase client setup using your Project URL and publishable/anon key;
- insert questions into `public.questions`;
- add email sign-in and a dashboard page;
- show pending submissions only to admins;
- let admins request an AI draft from a server-side function and edit/publish it;
- show published Q&A publicly.

Do not paste passwords, secret keys, or private API keys into this chat. If you share project settings for setup help, share only the Project URL and publishable/anon key, never any secret/service-role key.

## D. AI answer suggestions (after database setup)
Create a Supabase Edge Function for AI suggestions and save the OpenAI API key as a server-side secret using Supabase's secret management/CLI. The browser should call the function; it must never receive the OpenAI secret key. Keep suggestions as drafts until you review and publish them.

## E. Test before sharing publicly
- Submit a test question while signed out.
- Verify it appears as pending only in your admin dashboard.
- Verify a signed-out visitor cannot read pending questions.
- Publish a test answer and verify only that published Q&A is visible publicly.
- Test sign-out and password reset.
- Add spam protection/rate limiting before public launch.
