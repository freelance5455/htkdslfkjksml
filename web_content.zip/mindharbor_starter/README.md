# MindHarbor online starter

This starter keeps the original HTML prototype and adds a secure database plan.
The database is not connected until you create a Supabase project and add its
public project URL/key to the website code.

## Files
- `mindharbor_prototype.html`: the first front-end demo (included at ZIP root)
- `supabase/schema.sql`: database tables, authentication profile trigger, and row-level security policies
- `NEXT_STEPS.md`: beginner setup instructions

## Security basics
- Never put a Supabase `service_role` key or an OpenAI API key in browser HTML.
- Public visitors can submit pending questions and can read published Q&A only.
- The admin role must be assigned manually by you after creating your own account.
- AI answer generation should run in a server-side Edge Function; do not call the AI API directly from public browser code.
- Before collecting real personal stories, add a privacy notice, abuse controls/rate limiting, moderation, and a way to delete submissions.

This starter is a scaffold, not a deployed/connected production service.
