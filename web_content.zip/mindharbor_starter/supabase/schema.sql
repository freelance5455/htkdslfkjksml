-- MindHarbor starter database schema for Supabase
-- Run this in Supabase Dashboard -> SQL Editor.
-- After your first email sign-up, promote your account to admin using the SQL
-- instructions in README.md. Never expose a service-role key in browser code.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'user' check (role in ('user', 'admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.questions (
  id uuid primary key default gen_random_uuid(),
  topic text not null default 'Other',
  nickname text,
  question text not null check (char_length(question) between 5 and 3000),
  status text not null default 'pending'
    check (status in ('pending', 'reviewing', 'published', 'rejected')),
  ai_draft text,
  answer text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (status <> 'published' or answer is not null)
);

create index if not exists questions_status_created_at_idx
  on public.questions (status, created_at desc);

alter table public.profiles enable row level security;
alter table public.questions enable row level security;

-- Secure helper avoids policy recursion when checking the profiles table.
create or replace function public.is_mindharbor_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.profiles p
    where p.id = (select auth.uid()) and p.role = 'admin'
  );
$$;

revoke all on function public.is_mindharbor_admin() from public;
grant execute on function public.is_mindharbor_admin() to anon, authenticated;

-- New sign-ups get a normal user profile. You will promote your own account
-- to admin manually from the SQL Editor after signing up.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, role)
  values (new.id, 'user')
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_mindharbor on auth.users;
create trigger on_auth_user_created_mindharbor
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- A signed-in user may read their own profile; no client may edit their role.
drop policy if exists "Read own profile" on public.profiles;
create policy "Read own profile"
on public.profiles for select to authenticated
using (id = (select auth.uid()) or public.is_mindharbor_admin());

-- Public visitors can submit pending questions only. No public read access to
-- pending questions, and public clients cannot set answers or AI drafts.
drop policy if exists "Public submits pending questions" on public.questions;
create policy "Public submits pending questions"
on public.questions for insert to anon, authenticated
with check (
  status = 'pending'
  and answer is null
  and ai_draft is null
);

-- Only published Q&A is visible to visitors.
drop policy if exists "Public reads published Q&A" on public.questions;
create policy "Public reads published Q&A"
on public.questions for select to anon, authenticated
using (status = 'published');

-- Admins can review, draft, publish, edit, and reject submissions.
drop policy if exists "Admins read all questions" on public.questions;
create policy "Admins read all questions"
on public.questions for select to authenticated
using (public.is_mindharbor_admin());

drop policy if exists "Admins update questions" on public.questions;
create policy "Admins update questions"
on public.questions for update to authenticated
using (public.is_mindharbor_admin())
with check (public.is_mindharbor_admin());

-- Optional timestamp helper for admin edits.
create or replace function public.set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists set_questions_updated_at on public.questions;
create trigger set_questions_updated_at
before update on public.questions
for each row execute procedure public.set_updated_at();
