package com.mall.garmentshop;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.graphics.drawable.ColorDrawable;
import android.view.*;
import android.content.Context;
import java.util.*;

public class MainActivity extends Activity {
 @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(Color.TRANSPARENT); setContentView(new MallView(this));}
}

class MallView extends View {
 Paint p=new Paint(3); Random r=new Random(); int coins=500, level=1, selected=0; ArrayList<Customer> customers=new ArrayList<>();
 String[] clothes={"Shirt","Jeans","Dress","Jacket"};
 MallView(Context c){super(c); for(int i=0;i<7;i++) customers.add(new Customer()); p.setTypeface(Typeface.create("sans",Typeface.BOLD)); setFocusable(true);}
 void rect(Canvas c,int color,float l,float t,float rr,float bb){p.setColor(color);c.drawRect(l,t,rr,bb,p);} 
 void txt(Canvas c,String s,float x,float y,float size,int color){p.setTextSize(size);p.setColor(color);c.drawText(s,x,y,p);} 
 @Override protected void onDraw(Canvas c){super.onDraw(c); float w=getWidth(),h=getHeight();
  rect(c,Color.rgb(215,232,245),0,0,w,h); // sky
  p.setColor(Color.rgb(130,130,140)); Path road=new Path(); road.moveTo(0,h*.72f);road.lineTo(w,h*.60f);road.lineTo(w,h);road.lineTo(0,h);road.close();c.drawPath(road,p);
  // mall building
  rect(c,Color.rgb(235,220,200),w*.06f,h*.16f,w*.94f,h*.72f); rect(c,Color.rgb(90,65,55),w*.04f,h*.10f,w*.96f,h*.20f);
  txt(c,"MALL • GARMENT SHOP",w*.29f,h*.165f,28,Color.WHITE);
  // shops
  for(int i=0;i<4;i++){float x=w*.10f+i*w*.21f; rect(c,Color.WHITE,x,h*.27f,x+w*.17f,h*.59f); rect(c,Color.rgb(65,95,130),x,h*.27f,x+w*.17f,h*.34f); txt(c,clothes[i],x+w*.025f,h*.315f,16,Color.WHITE);
    // racks
    for(int j=0;j<3;j++){rect(c,Color.rgb(190,70+j*35,100+j*20),x+w*.025f+j*w*.045f,h*.40f,x+w*.055f+j*w*.045f,h*.52f);}
  }
  // entrance
  rect(c,Color.rgb(80,160,190),w*.43f,h*.57f,w*.57f,h*.72f); txt(c,"OPEN",w*.47f,h*.64f,18,Color.WHITE);
  // customers
  for(Customer q:customers){q.x+=q.dx;if(q.x>w*.9f||q.x<w*.1f)q.dx=-q.dx; float y=h*.76f+q.off; p.setColor(Color.rgb(45,45,55));c.drawCircle(q.x,y,12,p); rect(c,Color.rgb(70,120,170),q.x-9,y+10,q.x+9,y+34);}
  // UI
  rect(c,Color.argb(220,25,30,40),0,0,w,h*.09f); txt(c,"Coins: "+coins,w*.03f,h*.06f,22,Color.YELLOW); txt(c,"Shop Lv."+level,w*.20f,h*.06f,22,Color.WHITE); txt(c,"Offline Mode",w*.78f,h*.06f,20,Color.GREEN);
  // buttons
  button(c,"ORDER",w*.05f,h*.86f,w*.25f,h*.97f); button(c,"UPGRADE",w*.29f,h*.86f,w*.49f,h*.97f); button(c,"DELIVERY",w*.53f,h*.86f,w*.73f,h*.97f); button(c,"NEXT",w*.77f,h*.86f,w*.95f,h*.97f);
 }
 void button(Canvas c,String s,float l,float t,float rr,float b){rect(c,Color.rgb(50,75,105),l,t,rr,b); txt(c,s,l+(rr-l)*.24f,t+(b-t)*.68f,18,Color.WHITE);}
 @Override public boolean onTouchEvent(android.view.MotionEvent e){if(e.getAction()!=1)return true; float w=getWidth(),h=getHeight(),x=e.getX(),y=e.getY();
  if(y>h*.84f){ if(x<w*.27f){coins+=50;} else if(x<w*.51f && coins>=100){coins-=100;level++;} else if(x<w*.75f){coins+=80;} else {coins+=25;} invalidate(); } return true; }
 static class Customer{float x=(float)(Math.random()*.8+.1)*1000,dx=(float)(Math.random()*2+1),off=(float)(Math.random()*15);}
}
