Mall Garment Shop - Offline Android Prototype

આ Android Studio project છે. આ prototype સંપૂર્ણ offline gameplay માટે બનાવાયેલ છે.

Features:
- 3D-style mall/garment shop visual prototype
- Shirt, Jeans, Dress, Jacket shops
- Coins, Shop Level
- Order / Upgrade / Delivery / Next buttons
- Moving customers
- Internetની જરૂર નથી (gameplay માટે)

Build:
1. Android Studioમાં project folder ખોલો.
2. Gradle sync થવા દો.
3. Build > Build APK(s) પસંદ કરો.
4. APK: app/build/outputs/apk/debug/app-debug.apk

નોંધ: આ starter prototype છે. વધુ advanced true-3D graphics, character animation, inventory, missions વગેરે ઉમેરવા માટે આગળ development જરૂરી છે.
