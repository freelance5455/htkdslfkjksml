# Portafoglio — istruzioni per compilare l'app Android

Questo pacchetto contiene il progetto pronto per generare un vero file .apk
usando Capacitor (impacchetta l'app web dentro un'app Android nativa).

Io non posso compilare l'APK da qui: serve farlo sul tuo computer con
Android Studio. Segui questi passaggi, sono più lunghi da leggere che da fare.

## Cosa ti serve installare (una volta sola)

1. **Node.js** (versione LTS) — https://nodejs.org
2. **Android Studio** (ultima versione stabile) — https://developer.android.com/studio
   Durante la prima apertura di Android Studio, lascialo scaricare
   l'Android SDK quando te lo propone (richiede connessione internet e
   qualche minuto).
3. **JDK 17** — di solito Android Studio lo installa già da solo insieme
   all'SDK, non serve installarlo a parte.

## Passo 1 — Estrai la cartella

Estrai lo zip che ti ho dato in una cartella qualsiasi del tuo computer,
ad esempio sul Desktop. Dentro trovi:

- `www/index.html` → la tua app Portafoglio
- `icona-app.png` → l'icona a tema soldi da usare per l'app
- `package.json` e `capacitor.config.json` → configurazione già impostata
- questo file di istruzioni

## Passo 2 — Apri il terminale nella cartella

- **Windows**: apri la cartella, clic destro dentro lo spazio vuoto → "Apri
  nel terminale" (o apri il Prompt dei comandi e usa `cd` per spostarti).
- **Mac**: apri l'app Terminale, poi `cd` seguito dal trascinamento della
  cartella dentro la finestra.

## Passo 3 — Installa le dipendenze e genera il progetto Android

Digita questi comandi uno alla volta, premendo Invio dopo ognuno:

```
npm install
npx cap init "Portafoglio" "com.agostino.portafoglio" --web-dir www
npx cap add android
npx cap sync android
```

Il comando `npx cap add android` crea una cartella `android/` con dentro
tutto il progetto nativo — è normale che richieda un minuto e scarichi
qualche file.

## Passo 4 — Apri il progetto in Android Studio

```
npx cap open android
```

Questo apre Android Studio direttamente sul progetto. Se il comando non
funziona, apri Android Studio manualmente e scegli "Open" selezionando la
cartella `android/` appena creata.

Alla prima apertura, Android Studio farà una "sincronizzazione Gradle"
(la barra in basso mostra il progresso): può richiedere qualche minuto,
lascialo lavorare.

## Passo 5 — Metti l'icona a tema soldi

Nel pannello a sinistra di Android Studio, tasto destro sulla cartella
`res` dentro `app/src/main/` → `New` → `Image Asset`.

- In "Icon Type" lascia "Launcher Icons (Adaptive and Legacy)"
- In "Path" seleziona il file `icona-app.png` che era nello zip
- Nella scheda "Background Layer" scegli un colore pieno con lo stesso
  blu dell'app: `#16324F`, così l'icona non ha bordi bianchi strani
- Clicca "Next" poi "Finish": Android Studio genera da solo tutte le
  dimensioni necessarie e sostituisce l'icona di default

## Passo 6 — Genera l'APK

Dal menu in alto in Android Studio:

`Build` → `Build Bundle(s) / APK(s)` → `Build APK(s)`

Quando finisce, comparirà una notifica in basso a destra con un link
"locate" che apre la cartella dove si trova il file:

`android/app/build/outputs/apk/debug/app-debug.apk`

Questo file `app-debug.apk` è la tua app "Portafoglio": copialo sul
telefono (via cavo, email, drive) e installalo. Il telefono probabilmente
chiederà di autorizzare "l'installazione da origini sconosciute" la prima
volta: è normale per un APK non scaricato dal Play Store.

## Cose importanti da sapere

- **I dati restano solo sul telefono.** L'app salva tutto in locale
  (come nella versione HTML): se disinstalli l'app o cambi telefono,
  li perdi. Usa "Esporta dati" nelle Impostazioni dell'app prima di
  disinstallare o cambiare dispositivo, e "Importa dati" per recuperarli.
- **Serve internet ad ogni apertura per lo stile grafico.** L'app carica
  ancora Tailwind CSS e i font da internet come nella versione web,
  invece di averli inclusi nel file. Se vuoi che l'app funzioni anche
  offline al 100% (incluso lo stile grafico), dimmelo e la sistemo: è
  fattibile ma richiede includere quei file direttamente nel pacchetto.
- **Per pubblicarla sul Play Store** serve un passaggio in più (creare
  un "APK firmato" con una chiave tua tramite `Build` → `Generate Signed
  Bundle / APK`) più un account sviluppatore Google (a pagamento, una
  tantum). Per uso personale sul tuo telefono, l'APK di debug del Passo 6
  è sufficiente.

## Se qualcosa va storto

Il messaggio d'errore più comune riguarda versioni di Gradle o del JDK
non compatibili: Android Studio di solito propone da solo il tasto
"Fix" o "Upgrade" quando serve. Se ti blocchi su un errore specifico,
incollamelo e vediamo insieme cosa sistemare.
