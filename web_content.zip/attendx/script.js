(function(){
"use strict";
const $=id=>document.getElementById(id);
/* Storage keys are unchanged so existing data is picked up automatically. */
const KEY="attendx_v2",OLD_KEY="attendx_v1",CORRUPT_KEY="attendx_v2_unreadable_copy";
const SUBJECTS=[["maths1","Maths-I"],["qme","QME"],["qmelab","QME Lab"],["pps","PPS"],["ppslab","PPS Lab"],["mpe","MPE"],["etw","ETW"],["etwlab","ETW Lab"],["evs","EVS"]];
const FDA="FDA Using Python";
const DAYNAMES=["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
const MONTHS=["January","February","March","April","May","June","July","August","September","October","November","December"];
function defTT(){return{
 0:[],
 1:[["Maths-I"],["QME"],["PPS Lab","ETW Lab"],["MPE"],["PPS"]],
 2:[["QME Lab","PPS Lab"],["MPE"],["Maths-I"],[FDA]],
 3:[["Maths-I"],["QME"],["PPS"],["ETW"],["ETW Lab","QME Lab"]],
 4:[["EVS"],["QME"],["ETW"],["Maths-I"],[FDA]],
 5:[["EVS"],["MPE"],["PPS"],["Maths-I"],[FDA]]
}}
function defState(){return{version:2,target:75,subjects:SUBJECTS.map(([id,name])=>({id,name,baseAttended:0,baseTotal:0})),entries:[],timetable:defTT(),enableSunday:false,setupSaved:false}}
let state=defState();
let editingId=null,draftTT=null,lastKey="",lastTime=0,selChoice={},selDate="",currentView="home";

const uid=()=>(window.crypto&&crypto.randomUUID)?crypto.randomUUID():String(Date.now())+Math.random().toString(16).slice(2);
const esc=s=>String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const isInt=v=>Number.isInteger(v)&&v>=0;
const dateOk=d=>/^\d{4}-\d{2}-\d{2}$/.test(d)&&!isNaN(new Date(d+"T00:00:00"));
const dow=d=>new Date(d+"T00:00:00").getDay();
function todayStr(){const t=new Date();return t.getFullYear()+"-"+String(t.getMonth()+1).padStart(2,"0")+"-"+String(t.getDate()).padStart(2,"0")}
const subj=id=>state.subjects.find(s=>s.id===id);
const subjByName=n=>state.subjects.find(s=>s.name.toLowerCase()===String(n).trim().toLowerCase());
const isFda=n=>/^fda/i.test(n);

/* ---------- persistence ---------- */
function persist(){try{localStorage.setItem(KEY,JSON.stringify(state));return true}catch(e){toast("Could not save to device storage (private mode or full).");return false}}
function sanitize(o){
 if(!o||typeof o!=="object")return{err:"File is not a valid AttendX backup."};
 const d=defState();
 if(o.target!==undefined){const t=Number(o.target);if(!(t>=1&&t<=100))return{err:"Backup has an invalid target."};d.target=t}
 if(Array.isArray(o.subjects)){
  const out=[];
  for(const s of o.subjects){
   if(!s||typeof s.id!=="string"||typeof s.name!=="string")return{err:"Backup has a malformed subject."};
   if(!isInt(s.baseAttended)||!isInt(s.baseTotal)||s.baseAttended>s.baseTotal)return{err:"Backup has invalid counts for "+s.name+"."};
   out.push({id:s.id,name:s.name,baseAttended:s.baseAttended,baseTotal:s.baseTotal});
  }
  if(!out.length)return{err:"Backup has no subjects."};
  d.subjects=out;
 }
 if(Array.isArray(o.entries)){
  const out=[];
  for(const e of o.entries){
   if(!e||!dateOk(e.date)||(e.status!=="present"&&e.status!=="absent")||!d.subjects.some(s=>s.id===e.subjectId))return{err:"Backup has an invalid attendance record."};
   const rec={id:typeof e.id==="string"?e.id:uid(),subjectId:e.subjectId,date:e.date,status:e.status,createdAt:Number(e.createdAt)||Date.now()};
   if(isInt(e.slot))rec.slot=e.slot; /* optional: timetable period this record belongs to */
   out.push(rec);
  }
  d.entries=out;
 }
 if(o.timetable&&typeof o.timetable==="object"){
  const tt={};
  for(let i=0;i<=5;i++){
   const day=o.timetable[i];
   if(day===undefined){tt[i]=defTT()[i];continue}
   if(!Array.isArray(day)||!day.every(sl=>Array.isArray(sl)&&sl.every(x=>typeof x==="string")))return{err:"Backup has a malformed timetable."};
   tt[i]=day.filter(sl=>sl.length);
  }
  d.timetable=tt;
 }
 d.enableSunday=!!o.enableSunday;d.setupSaved=!!o.setupSaved;
 return{state:d};
}
function load(){
 let raw=null;
 try{
  raw=localStorage.getItem(KEY);
  if(raw){
   const r=sanitize(JSON.parse(raw));
   if(r.state){state=r.state;return}
   throw new Error("unreadable");
  }
  const old=localStorage.getItem(OLD_KEY);
  if(old){ // migrate v1
   const o=JSON.parse(old),d=defState(),map={};
   (o.subjects||[]).forEach(s=>{const m=d.subjects.find(x=>x.name.toLowerCase()===String(s.name).toLowerCase());if(m){map[s.id]=m.id;if(isInt(s.baseAttended)&&isInt(s.baseTotal)&&s.baseAttended<=s.baseTotal){m.baseAttended=s.baseAttended;m.baseTotal=s.baseTotal}}});
   d.entries=(o.entries||[]).filter(e=>map[e.subjectId]&&dateOk(e.date)&&(e.status==="present"||e.status==="absent")).map(e=>({id:e.id||uid(),subjectId:map[e.subjectId],date:e.date,status:e.status,createdAt:e.createdAt||Date.now()}));
   if(o.target>=1&&o.target<=100)d.target=Number(o.target);
   d.setupSaved=!!o.setupSaved;state=d;persist();
  }
 }catch(e){
  /* Never silently overwrite data we could not read: keep a raw copy first. */
  try{if(raw)localStorage.setItem(CORRUPT_KEY,raw)}catch(_){}
  state=defState();
 }
}

/* ---------- calculations ---------- */
function totals(s){
 const es=state.entries.filter(e=>e.subjectId===s.id),pres=es.filter(e=>e.status==="present").length;
 const attended=s.baseAttended+pres,total=s.baseTotal+es.length;
 return{attended,total,absent:total-attended,pct:total?attended/total*100:null};
}
function plan(A,T,P){
 if(P===undefined)P=state.target;
 if(T===0)return{none:true,canMiss:0,need:0};
 if(100*A>=P*T-1e-9){return{ok:true,canMiss:Math.max(0,Math.floor(100*A/P-T+1e-9)),need:0}}
 if(P>=100)return{ok:false,impossible:true,canMiss:0,need:null};
 return{ok:false,canMiss:0,need:Math.max(0,Math.ceil((P*T-100*A)/(100-P)-1e-9))};
}
function overall(){let a=0,t=0;state.subjects.forEach(s=>{const x=totals(s);a+=x.attended;t+=x.total});return{attended:a,total:t,absent:t-a,pct:t?a/t*100:null}}
const fmt=n=>n===null?"No classes yet":n.toFixed(1)+"%";
function level(x,p){if(p.none)return"none";if(!p.ok)return"bad";return p.canMiss<=1?"warn":"good"}
const colorVar=l=>l==="good"?"var(--green)":l==="warn"?"var(--yellow)":l==="bad"?"var(--red)":"#555";

/* ---------- messages ---------- */
let toastT;
function toast(t){const el=$("toast");el.textContent=t;el.classList.add("show");clearTimeout(toastT);toastT=setTimeout(()=>el.classList.remove("show"),3000)}
function inline(id,t,ok){$(id).innerHTML=t?`<div class="msg ${ok?"ok":"bad"}">${esc(t)}</div>`:""}

/* ---------- navigation (works with the Android back button) ---------- */
const TITLES={dashboard:"Dashboard",subjects:"Subject Management",history:"Attendance History",calculator:"Attendance Calculator",timetable:"Timetable Management",reports:"Reports & Statistics",backup:"Backup & Restore",settings:"Settings",about:"About AttendX"};
function showView(v){
 if(v!=="home"&&!TITLES[v])v="home";
 currentView=v;closeMenu();
 document.querySelectorAll(".view").forEach(el=>el.hidden=el.id!=="v-"+v);
 const home=v==="home";
 $("backBtn").hidden=home;$("pageTitle").hidden=home;$("brand").hidden=!home;
 $("pageTitle").textContent=home?"":TITLES[v];
 window.scrollTo(0,0);
 if(v==="home")renderHome();
 else if(v==="subjects"){renderStartingInputs();inline("startMsg","",true);inline("subjMsg","",true)}
 else if(v==="timetable"){draftTT=null;renderTTEditor();inline("ttMsg","",true)}
 else if(v==="calculator"){$("calcTarget").value=state.target;fillCalcScope();renderCalc()}
 else if(v==="history"){const d=todayStr();if(!editingId)$("entryDate").value=d;renderHistory()}
 else if(v==="settings"){$("targetInput").value=state.target;$("sundayToggle").checked=state.enableSunday;inline("targetMsg","",true)}
 else if(v==="backup")inline("backupMsg","",true);
 else render();
}
function go(v){
 if(v===currentView)return;
 if(currentView==="home")history.pushState({v:v,sub:1},"");
 else history.replaceState({v:v,sub:history.state&&history.state.sub?1:0},"");
 showView(v);
}
function goHome(){
 if(currentView==="home")return;
 if(history.state&&history.state.sub)history.back(); /* popstate shows home */
 else{history.replaceState({v:"home"},"");showView("home")}
}
window.addEventListener("popstate",e=>showView((e.state&&e.state.v)||"home"));

/* overflow menu */
function openMenu(){$("menu").hidden=false;$("menuBackdrop").hidden=false;$("menuBtn").setAttribute("aria-expanded","true");const f=$("menu").querySelector("button");if(f)f.focus()}
function closeMenu(){$("menu").hidden=true;$("menuBackdrop").hidden=true;$("menuBtn").setAttribute("aria-expanded","false")}
$("menuBtn").addEventListener("click",e=>{e.stopPropagation();$("menu").hidden?openMenu():closeMenu()});
$("menuBackdrop").addEventListener("click",closeMenu);
$("menu").addEventListener("click",e=>{const b=e.target.closest("[data-go]");if(b)go(b.dataset.go)});
$("backBtn").addEventListener("click",goHome);
document.addEventListener("keydown",e=>{if(e.key==="Escape"){if(!$("menu").hidden)closeMenu();else goHome()}});

/* ---------- today's attendance (home) ---------- */
function dayAllowed(d){const w=dow(d);return w===6?"saturday":(w===0&&!state.enableSunday)?"sunday":""}
function slotOpts(slot){return slot.filter(n=>!isFda(n)).map(subjByName).filter(Boolean)}
function todaySlots(d){return dayAllowed(d)?[]:(state.timetable[dow(d)]||[])}
/* Match the date's records to timetable periods: records carrying a slot number first,
   then older/manual records (no slot) by subject, in the order they were created. */
function slotAssign(date,slots){
 const res=slots.map(()=>null),used=new Set();
 const todays=state.entries.filter(e=>e.date===date).sort((a,b)=>a.createdAt-b.createdAt);
 todays.forEach(e=>{if(isInt(e.slot)&&e.slot<slots.length&&!res[e.slot]){res[e.slot]=e;used.add(e.id)}});
 todays.forEach(e=>{
  if(used.has(e.id))return;
  for(let i=0;i<slots.length;i++){
   if(res[i])continue;
   if(slotOpts(slots[i]).some(o=>o.id===e.subjectId)){res[i]=e;used.add(e.id);break}
  }
 });
 return res;
}
function renderHome(){
 const d=todayStr();
 if(d!==selDate){selDate=d;selChoice={}}
 const t=new Date(d+"T00:00:00");
 $("todayDate").textContent=DAYNAMES[t.getDay()]+", "+t.getDate()+" "+MONTHS[t.getMonth()]+" "+t.getFullYear();
 const slots=todaySlots(d),box=$("todayList");
 if(!slots.length){
  $("todaySub").textContent="";
  box.innerHTML='<div class="empty-today">No classes scheduled for today.</div>';
  return;
 }
 const asg=slotAssign(d,slots);
 let marked=0,total=0;
 box.innerHTML=slots.map((slot,i)=>{
  const opts=slotOpts(slot);
  if(!opts.length)return `<div class="class-card is-excluded"><div class="class-top"><span class="period">P${i+1}</span><div class="class-name excl-note">${esc(FDA)} — excluded, not counted</div></div></div>`;
  total++;
  const cur=asg[i],st=cur?cur.status:"";
  if(cur)marked++;
  let chosen=cur?cur.subjectId:(selChoice[i]&&opts.some(o=>o.id===selChoice[i])?selChoice[i]:opts[0].id);
  let nameHtml;
  if(opts.length>1||(cur&&!opts.some(o=>o.id===cur.subjectId))){
   const list=opts.slice();if(cur&&!list.some(o=>o.id===cur.subjectId)){const s=subj(cur.subjectId);if(s)list.push(s)}
   nameHtml=`<select data-qsel="${i}" aria-label="Choose subject for period ${i+1}">${list.map(o=>`<option value="${esc(o.id)}"${o.id===chosen?" selected":""}>${esc(o.name)}</option>`).join("")}</select>`;
  }else nameHtml=`<div class="class-name">${esc(opts[0].name)}</div>`;
  const label=st==="present"?"✓ Present":st==="absent"?"✕ Absent":"Not marked";
  return `<div class="class-card${st?" is-"+st:""}"><div class="class-top"><span class="period">P${i+1}</span>${nameHtml}<span class="status ${st}">${label}</span></div>
  <div class="class-actions"><button type="button" class="present${st==="present"?" on":""}" data-mark="${i}" data-s="present">Present</button><button type="button" class="absent${st==="absent"?" on":""}" data-mark="${i}" data-s="absent">Absent</button></div>
  ${cur?`<button type="button" class="clear-link" data-clear="${i}">Clear this mark</button>`:""}</div>`;
 }).join("");
 $("todaySub").textContent=marked+" of "+total+" classes marked";
}
function markSlot(i,status){
 const d=todayStr(),slots=todaySlots(d),slot=slots[i];
 if(!slot)return;
 const opts=slotOpts(slot);if(!opts.length)return;
 const asg=slotAssign(d,slots),cur=asg[i];
 const sel=document.querySelector(`[data-qsel="${i}"]`);
 const sid=sel?sel.value:(cur?cur.subjectId:opts[0].id);
 const name=(subj(sid)||{}).name||"Class",word=status==="present"?"Present":"Absent";
 if(cur){
  if(cur.status===status&&cur.subjectId===sid){toast(name+" is already marked "+word);return}
  cur.status=status;cur.subjectId=sid;cur.slot=i; /* correction: updates in place, never duplicates */
  persist();render();toast("Updated: "+name+" → "+word);return;
 }
 state.entries.push({id:uid(),subjectId:sid,date:d,status,createdAt:Date.now(),slot:i});
 persist();render();toast(name+": "+word);
}
function clearSlot(i){
 const d=todayStr(),slots=todaySlots(d),cur=slotAssign(d,slots)[i];
 if(!cur)return;
 state.entries=state.entries.filter(x=>x.id!==cur.id);
 persist();render();toast("Mark cleared");
}

/* ---------- dashboard ---------- */
function renderStats(){
 const x=overall(),P=state.target,p=plan(x.attended,x.total);
 $("overallPct").textContent=x.total?x.pct.toFixed(1)+"%":"—";
 $("overallNote").textContent=!x.total?"No classes yet":(p.ok?"At or above":"Below")+" your "+P+"% target";
 const lv=level(x,p);$("overallBar").style.width=x.total?Math.min(100,x.pct)+"%":"0";$("overallBar").style.background=colorVar(lv);
 $("attendedTotal").textContent=x.attended;$("absentNote").textContent=x.absent+" absent";$("heldTotal").textContent=x.total;
 $("heldNote").textContent="All "+state.subjects.length+" subjects combined";
 if(!x.total){$("relLabel").textContent="Can miss (estimate)";$("relValue").textContent="—";$("relNote").textContent="Save starting attendance first"}
 else if(p.ok){$("relLabel").textContent="Can miss (estimate)";$("relValue").textContent=p.canMiss;$("relNote").textContent="Future classes at "+P+"% · not official"}
 else{$("relLabel").textContent="Need to attend";$("relValue").textContent=p.impossible?"—":p.need;$("relNote").textContent=p.impossible?"100% not recoverable once a class is missed":"Consecutive classes to reach "+P+"%"}
}
function adviceFor(s,x,p,lv,P){
 if(p.none)return"No classes yet.";
 if(p.ok)return`Can miss <strong class="${lv}">${p.canMiss}</strong> future class${p.canMiss===1?"":"es"} and stay at ${P}%. (estimate)`;
 if(p.impossible)return"A 100% target cannot be recovered after an absence.";
 return`Attend <strong class="bad">${p.need}</strong> consecutive class${p.need===1?"":"es"} to reach ${P}%.`;
}
function renderCards(){
 const P=state.target;
 $("subjectCards").innerHTML=state.subjects.map(s=>{
  const x=totals(s),p=plan(x.attended,x.total),lv=level(x,p);
  return `<div class="subject"><div class="subject-head"><div><div class="subject-name">${esc(s.name)}</div><div class="subject-meta">${x.attended} attended · ${x.absent} absent · ${x.total} held</div></div><span class="badge ${lv==="good"?"":lv}">${p.none?"No classes yet":x.pct.toFixed(1)+"%"}</span></div><div class="progress"><span style="width:${x.total?Math.min(100,x.pct):0}%;background:${colorVar(lv)}"></span></div><div class="subject-foot" style="margin-top:10px"><div class="advice">${adviceFor(s,x,p,lv,P)}</div><div class="small-actions"><button type="button" class="present" data-quick="present" data-id="${esc(s.id)}">+ Present</button><button type="button" class="absent" data-quick="absent" data-id="${esc(s.id)}">+ Absent</button></div></div></div>`}).join("");
}

/* ---------- reports ---------- */
function renderReports(){
 const P=state.target,al=[];
 const rows=state.subjects.map(s=>{
  const x=totals(s),p=plan(x.attended,x.total),lv=level(x,p);
  let next;
  if(p.none)next="No classes yet";
  else if(p.ok){next=`Can miss ${p.canMiss}`;if(p.canMiss===0)al.push(["yel",`${s.name}: exactly at target — no spare absences.`]);else if(p.canMiss===1)al.push(["yel",`${s.name}: only 1 spare absence left.`])}
  else if(p.impossible){next="Target unreachable";al.push(["red",`${s.name}: ${fmt(x.pct)} — target unreachable.`])}
  else{next=`Attend ${p.need} in a row`;al.push(["red",`${s.name}: shortage at ${fmt(x.pct)} — attend ${p.need} in a row to recover.`])}
  return `<tr><td>${esc(s.name)}</td><td>${x.attended}</td><td>${x.absent}</td><td>${x.total}</td><td class="${lv==="none"?"":lv}">${p.none?"—":x.pct.toFixed(1)+"%"}</td><td class="wrapcell">${esc(next)}</td></tr>`}).join("");
 $("reportBody").innerHTML=rows;
 $("alerts").innerHTML=al.length?al.map(a=>`<div class="alert ${a[0]}">${esc(a[1])}</div>`).join(""):(overall().total?'<div class="alert grn">All subjects are above target with room to spare.</div>':'<div class="empty">No data yet.</div>');
 const m={};
 state.entries.forEach(e=>{const k=e.date.slice(0,7);(m[k]=m[k]||{p:0,a:0})[e.status==="present"?"p":"a"]++});
 const keys=Object.keys(m).sort().reverse();
 $("monthBody").innerHTML=keys.length?keys.map(k=>{const v=m[k],t=v.p+v.a,[y,mo]=k.split("-");return `<tr><td>${MONTHS[Number(mo)-1]} ${y}</td><td>${v.p}</td><td>${v.a}</td><td>${(v.p/t*100).toFixed(1)}%</td></tr>`}).join(""):'<tr><td colspan="4" class="empty">No date-wise records yet.</td></tr>';
}

/* ---------- history ---------- */
function fillSubjectSelects(){
 const opts=state.subjects.map(s=>`<option value="${esc(s.id)}">${esc(s.name)}</option>`).join("");
 const cur=$("entrySubject").value;$("entrySubject").innerHTML=opts;if(cur&&subj(cur))$("entrySubject").value=cur;
 const f=$("fSubject").value;$("fSubject").innerHTML='<option value="">All subjects</option>'+opts;if(f&&subj(f))$("fSubject").value=f;
}
function filteredEntries(){
 const f=$("fFrom").value,t=$("fTo").value,s=$("fSubject").value;
 return state.entries.filter(e=>(!f||e.date>=f)&&(!t||e.date<=t)&&(!s||e.subjectId===s)).sort((a,b)=>b.date.localeCompare(a.date)||b.createdAt-a.createdAt);
}
function renderHistory(){
 const list=filteredEntries();
 $("histCount").textContent=list.length+" of "+state.entries.length+" records";
 $("historyBody").innerHTML=list.length?list.map(e=>{const s=subj(e.subjectId);return `<tr><td>${esc(e.date)}</td><td>${esc(s?s.name:"Removed subject")}</td><td class="${e.status==="present"?"good":"bad"}">${e.status==="present"?"Present":"Absent"}</td><td><button type="button" class="secondary" style="padding:6px 10px;min-height:34px" data-edit="${esc(e.id)}">Edit</button> <button type="button" class="danger" style="padding:6px 10px;min-height:34px" data-del="${esc(e.id)}">Delete</button></td></tr>`}).join(""):`<tr><td colspan="4" class="empty">${state.entries.length?"No records match the filters.":"No date-wise records yet."}</td></tr>`;
}

/* ---------- calculator ---------- */
function fillCalcScope(){
 const cur=$("calcScope").value;
 $("calcScope").innerHTML='<option value="all">Overall (all subjects)</option>'+state.subjects.map(s=>`<option value="${esc(s.id)}">${esc(s.name)}</option>`).join("");
 $("calcScope").value=(cur==="all"||subj(cur))?(cur||"all"):"all";
}
function calcMsg(p,x,P){
 if(p.none)return"No classes recorded yet.";
 if(p.ok)return`You can miss <strong class="good">${p.canMiss}</strong> more class${p.canMiss===1?"":"es"} and stay at ${P}%.`;
 if(p.impossible)return"A 100% target cannot be recovered after an absence.";
 return`Attend <strong class="bad">${p.need}</strong> consecutive class${p.need===1?"":"es"} to reach ${P}%.`;
}
function renderCalc(){
 if(!$("calcScope").options.length)fillCalcScope();
 const P=Number($("calcTarget").value),raw=$("calcTarget").value.trim();
 if(raw===""||!isFinite(P)||P<1||P>100){$("calcResult").innerHTML='<div class="msg bad">Target must be a number from 1 to 100.</div>';$("calcWhatIf").innerHTML="";$("calcAll").innerHTML="";return}
 const sc=$("calcScope").value,x=sc==="all"?overall():totals(subj(sc)||state.subjects[0]);
 const p=plan(x.attended,x.total,P),lv=level(x,p);
 $("calcResult").innerHTML=`<div class="calc-big"><div class="stat-label">Current attendance</div><div class="n ${lv==="none"?"":lv}">${fmt(x.pct)}</div><div class="stat-note">${x.attended} attended of ${x.total} held</div></div><div class="calc-big"><div>${calcMsg(p,x,P)}</div><div class="stat-note" style="margin-top:6px">Maths estimate, not official.</div></div>`;
 const a=Math.max(0,Math.floor(Number($("calcAtt").value)||0)),m=Math.max(0,Math.floor(Number($("calcMiss").value)||0));
 if(a||m){const A=x.attended+a,T=x.total+a+m,pc=T?A/T*100:null;$("calcWhatIf").innerHTML=`<div class="calc-big"><div class="stat-label">After attending ${a} and missing ${m}</div><div class="n ${pc!==null&&pc>=P?"good":"bad"}">${fmt(pc)}</div><div class="stat-note">${A} of ${T} · ${pc!==null&&pc>=P?"at or above":"below"} ${P}%</div></div>`}
 else $("calcWhatIf").innerHTML='<div class="stat-note">Enter a number above to see the result.</div>';
 $("calcAll").innerHTML=state.subjects.map(s=>{const t=totals(s),q=plan(t.attended,t.total,P),l=level(t,q);return `<div class="subject"><div class="subject-head"><div><div class="subject-name">${esc(s.name)}</div><div class="subject-meta">${t.attended}/${t.total}</div></div><span class="badge ${l==="good"?"":l}">${q.none?"No classes yet":t.pct.toFixed(1)+"%"}</span></div><div class="advice" style="margin-top:8px">${calcMsg(q,t,P)}</div></div>`}).join("");
}
["calcScope","calcTarget","calcAtt","calcMiss"].forEach(id=>{$(id).addEventListener("input",renderCalc);$(id).addEventListener("change",renderCalc)});

/* ---------- subject management ---------- */
function renderStartingInputs(){
 $("startingInputs").innerHTML=state.subjects.map(s=>`<div class="subject"><div class="subject-head"><div style="flex:1;min-width:0"><label for="sn-${esc(s.id)}">Subject name</label><input id="sn-${esc(s.id)}" data-sn="${esc(s.id)}" type="text" maxlength="40" autocomplete="off" value="${esc(s.name)}"></div><button type="button" class="danger" data-subdel="${esc(s.id)}" aria-label="Delete ${esc(s.name)}" style="align-self:flex-end">Delete</button></div><div class="pair"><div><label for="sa-${esc(s.id)}">Attended Classes</label><input id="sa-${esc(s.id)}" data-sa="${esc(s.id)}" type="number" inputmode="numeric" min="0" step="1" value="${s.baseAttended}"></div><div><label for="st-${esc(s.id)}">Total Classes Held</label><input id="st-${esc(s.id)}" data-st="${esc(s.id)}" type="number" inputmode="numeric" min="0" step="1" value="${s.baseTotal}"></div></div><div class="fe" id="fe-${esc(s.id)}"></div></div>`).join("");
}
function nameProblem(n,ignoreId){
 if(!n)return"Enter a subject name.";
 if(n.indexOf("/")>=0)return"Names cannot contain “/”.";
 if(isFda(n))return"“FDA” is reserved for excluded classes.";
 if(state.subjects.some(s=>s.id!==ignoreId&&s.name.toLowerCase()===n.toLowerCase()))return"Another subject already uses this name.";
 return"";
}
$("saveStarting").addEventListener("click",()=>{
 let bad=0;const vals=[],seen={};
 state.subjects.forEach(s=>{
  const nm=$("sn-"+s.id),a=$("sa-"+s.id),t=$("st-"+s.id),fe=$("fe-"+s.id);let m="";
  [nm,a,t].forEach(i=>i.classList.remove("err"));
  const name=nm.value.trim().replace(/\s+/g," "),as=a.value.trim(),ts=t.value.trim(),av=Number(as),tv=Number(ts);
  if(!name){m="Enter a subject name.";nm.classList.add("err")}
  else if(name.indexOf("/")>=0||isFda(name)){m=name.indexOf("/")>=0?"Names cannot contain “/”.":"“FDA” is reserved for excluded classes.";nm.classList.add("err")}
  else if(seen[name.toLowerCase()]){m="Two subjects have the same name.";nm.classList.add("err")}
  else if(as===""||ts===""){m="Fill both fields (use 0 if none).";if(as==="")a.classList.add("err");if(ts==="")t.classList.add("err")}
  else if(!/^\d+$/.test(as)||!/^\d+$/.test(ts)){m="Use non-negative whole numbers only.";if(!/^\d+$/.test(as))a.classList.add("err");if(!/^\d+$/.test(ts))t.classList.add("err")}
  else if(av>tv){m="Attended cannot be more than total held.";a.classList.add("err")}
  seen[name.toLowerCase()]=1;
  if(m){bad++;fe.textContent=m}else{fe.textContent="";vals.push([s,name,av,tv])}
 });
 if(bad){inline("startMsg",`${bad} subject${bad>1?"s have":" has"} errors. Nothing was saved — your entries are still in the boxes; fix the highlighted ones.`,false);return}
 /* apply renames to the timetable in one pass (names are what the timetable stores) */
 const map={};vals.forEach(([s,n])=>{if(s.name!==n)map[s.name.toLowerCase()]=n});
 if(Object.keys(map).length)for(const i in state.timetable)state.timetable[i]=state.timetable[i].map(sl=>sl.map(n=>map[n.toLowerCase()]||n));
 vals.forEach(([s,n,a,t])=>{s.name=n;s.baseAttended=a;s.baseTotal=t});state.setupSaved=true;
 draftTT=null;
 if(persist()){inline("startMsg","Saved "+vals.length+" subjects. Dashboard updated.",true);toast("Subjects saved")}
 render();
});
$("resetInputs").addEventListener("click",()=>{renderStartingInputs();inline("startMsg","Inputs reset to your last saved values.",true)});
$("addSubject").addEventListener("click",()=>{
 const n=$("newName").value.trim().replace(/\s+/g," "),as=$("newAtt").value.trim(),ts=$("newTot").value.trim();
 const pr=nameProblem(n);if(pr){inline("subjMsg",pr,false);return}
 if(!/^\d+$/.test(as)||!/^\d+$/.test(ts)){inline("subjMsg","Use non-negative whole numbers for the counts.",false);return}
 const a=Number(as),t=Number(ts);if(a>t){inline("subjMsg","Attended cannot be more than total held.",false);return}
 let id="s"+Date.now().toString(36);while(subj(id))id+="x";
 state.subjects.push({id,name:n,baseAttended:a,baseTotal:t});
 persist();render();renderStartingInputs();
 $("newName").value="";$("newAtt").value=0;$("newTot").value=0;
 inline("subjMsg",`Added “${n}”. Add it to the timetable in Timetable Management.`,true);
});
function deleteSubject(id){
 const s=subj(id);if(!s)return;
 if(state.subjects.length<=1){inline("startMsg","You need at least one subject.",false);return}
 const n=state.entries.filter(e=>e.subjectId===id).length;
 if(!confirm(`Delete “${s.name}”?\n\nIts starting counts and ${n} date-wise record${n===1?"":"s"} will be removed from your totals, and it will be taken out of the timetable. Export a backup first if unsure.`))return;
 state.subjects=state.subjects.filter(x=>x.id!==id);
 state.entries=state.entries.filter(e=>e.subjectId!==id);
 const low=s.name.toLowerCase();
 for(const i in state.timetable)state.timetable[i]=state.timetable[i].map(sl=>sl.filter(x=>x.toLowerCase()!==low)).filter(sl=>sl.length);
 if(editingId&&!state.entries.some(e=>e.id===editingId))resetForm();
 draftTT=null;persist();render();renderStartingInputs();
 inline("startMsg","Deleted “"+s.name+"”.",true);
}

/* ---------- timetable ---------- */
function renderTTEditor(){
 if(!draftTT){draftTT={};for(let i=0;i<=5;i++)draftTT[i]=(state.timetable[i]||[]).map(sl=>sl.join(" / "))}
 const days=[1,2,3,4,5];if(state.enableSunday)days.unshift(0);
 $("ttDays").innerHTML=days.map(i=>`<div class="daybox"><h3 style="margin-top:0">${DAYNAMES[i]}</h3>${(draftTT[i]||[]).map((v,k)=>`<div class="tt-slot"><input data-tt="${i}" data-k="${k}" value="${esc(v)}" aria-label="${DAYNAMES[i]} period ${k+1}"><button type="button" class="danger" data-ttdel="${i}:${k}" aria-label="Remove period">✕</button></div>`).join("")||'<div class="stat-note" style="margin-bottom:6px">No periods.</div>'}<button type="button" class="secondary" data-ttadd="${i}" style="padding:7px 11px;font-size:12px;min-height:36px">+ Add period</button></div>`).join("")+'<div class="daybox"><h3 style="margin:0">Saturday</h3><div class="stat-note">Entire day excluded — cannot be edited.</div></div>';
}
function readDraft(){if(!draftTT)return;document.querySelectorAll("[data-tt]").forEach(inp=>{const i=inp.dataset.tt,k=Number(inp.dataset.k);if(draftTT[i])draftTT[i][k]=inp.value})}
$("saveTT").addEventListener("click",()=>{
 readDraft();const tt={};
 for(let i=0;i<=5;i++){
  tt[i]=[];
  for(const line of (draftTT[i]||[])){
   const parts=line.split("/").map(x=>x.trim()).filter(Boolean);
   if(!parts.length)continue;
   const slot=[];
   for(const p of parts){
    if(isFda(p)){slot.push(FDA);continue}
    const s=subjByName(p);
    if(!s){inline("ttMsg",`“${p}” (${DAYNAMES[i]}) is not a known subject. Use: ${state.subjects.map(x=>x.name).join(", ")} or FDA.`,false);return}
    slot.push(s.name);
   }
   tt[i].push(slot);
  }
 }
 state.timetable=tt;persist();draftTT=null;renderTTEditor();render();inline("ttMsg","Timetable saved.",true);
});
$("resetTT").addEventListener("click",()=>{if(!confirm("Restore the default timetable? Your edits will be lost."))return;state.timetable=defTT();persist();draftTT=null;renderTTEditor();render();inline("ttMsg","Default timetable restored.",true)});

/* ---------- records ---------- */
function render(){fillSubjectSelects();renderHome();renderStats();renderCards();renderReports();renderHistory();if(currentView==="calculator"){fillCalcScope();renderCalc()}}
/* A subject may legitimately have several periods in a day (e.g. two Maths-I classes), so only
   warn when the date already holds as many records for it as the timetable has periods. */
function allowedPerDay(subjectId,date){
 const s=subj(subjectId);if(!s)return 1;
 const slots=todaySlots(date),n=slots.filter(sl=>sl.some(x=>x.toLowerCase()===s.name.toLowerCase())).length;
 return Math.max(1,n);
}
function addRecord(subjectId,date,status){
 const why=dayAllowed(date);
 if(why==="saturday")return"Saturdays are excluded from attendance — this record was not added.";
 if(why==="sunday")return"Sunday is an off day. Enable Sunday in Settings to add records.";
 const key=subjectId+"|"+date+"|"+status,now=Date.now();
 if(key===lastKey&&now-lastTime<800)return"Ignored a double tap. Tap again to add another class.";
 const have=state.entries.filter(e=>e.subjectId===subjectId&&e.date===date).length;
 if(have>=allowedPerDay(subjectId,date)&&!confirm(`${subj(subjectId).name} already has ${have} record${have===1?"":"s"} on ${date}. Add another one anyway?\n\nTo fix a mistake, use Edit in Attendance History instead.`))return"Not added — this class already has a record for that date.";
 lastKey=key;lastTime=now;
 state.entries.push({id:uid(),subjectId,date,status,createdAt:now});
 persist();render();return"";
}
function resetForm(){editingId=null;$("editBar").style.display="none";$("addEntry").textContent="Add Attendance";$("formTitle").textContent="Add or Correct a Record"}
$("addEntry").addEventListener("click",()=>{
 const sid=$("entrySubject").value,date=$("entryDate").value,st=$("entryStatus").value;
 if(!dateOk(date)){inline("markMsg","Choose a valid date.",false);return}
 if(!subj(sid)){inline("markMsg","Choose a subject.",false);return}
 if(editingId){
  const e=state.entries.find(x=>x.id===editingId);
  const why=dayAllowed(date);
  if(why){inline("markMsg",why==="saturday"?"Saturdays are excluded.":"Sunday is disabled.",false);return}
  if(e){if(e.date!==date)delete e.slot;e.subjectId=sid;e.date=date;e.status=st}
  persist();render();resetForm();inline("markMsg","Record updated.",true);return;
 }
 const err=addRecord(sid,date,st);
 if(err)inline("markMsg",err,false);else inline("markMsg",`Added: ${subj(sid).name} · ${date} · ${st==="present"?"Present":"Absent"}.`,true);
});
$("cancelEdit").addEventListener("click",()=>{resetForm();inline("markMsg","Edit cancelled.",true)});
["fFrom","fTo","fSubject"].forEach(id=>$(id).addEventListener("change",renderHistory));
$("clearFilters").addEventListener("click",()=>{$("fFrom").value="";$("fTo").value="";$("fSubject").value="";renderHistory()});

/* settings */
$("saveTarget").addEventListener("click",()=>{
 const raw=$("targetInput").value.trim(),t=Number(raw);
 if(raw===""||!isFinite(t)||t<1||t>100){inline("targetMsg","Target must be a number from 1 to 100.",false);return}
 state.target=t;persist();render();inline("targetMsg","Target updated to "+t+"%.",true);
});
$("sundayToggle").addEventListener("change",()=>{state.enableSunday=$("sundayToggle").checked;persist();draftTT=null;render()});

/* one delegated click handler for dynamic buttons */
document.addEventListener("click",e=>{
 const mk=e.target.closest("[data-mark]");
 if(mk){markSlot(Number(mk.dataset.mark),mk.dataset.s);return}
 const cl=e.target.closest("[data-clear]");
 if(cl){clearSlot(Number(cl.dataset.clear));return}
 const q=e.target.closest("[data-quick]");
 if(q){const err=addRecord(q.dataset.id,todayStr(),q.dataset.quick);toast(err||`${subj(q.dataset.id).name}: ${q.dataset.quick} today`);return}
 const sd=e.target.closest("[data-subdel]");
 if(sd){deleteSubject(sd.dataset.subdel);return}
 const del=e.target.closest("[data-del]");
 if(del){if(!confirm("Delete this record?"))return;state.entries=state.entries.filter(x=>x.id!==del.dataset.del);if(editingId===del.dataset.del)resetForm();persist();render();toast("Record deleted");return}
 const ed=e.target.closest("[data-edit]");
 if(ed){const r=state.entries.find(x=>x.id===ed.dataset.edit);if(!r)return;editingId=r.id;
  $("entryDate").value=r.date;$("entrySubject").value=r.subjectId;$("entryStatus").value=r.status;
  $("editBar").style.display="flex";$("addEntry").textContent="Update Record";$("formTitle").textContent="Correct a Record";$("editLabel").textContent="Editing record from "+r.date;
  inline("markMsg","",true);$("mark").scrollIntoView();return}
 const ta=e.target.closest("[data-ttadd]");
 if(ta){readDraft();draftTT[ta.dataset.ttadd].push("");renderTTEditor();return}
 const td=e.target.closest("[data-ttdel]");
 if(td){readDraft();const [i,k]=td.dataset.ttdel.split(":");draftTT[i].splice(Number(k),1);renderTTEditor()}
});
document.addEventListener("change",e=>{
 const s=e.target.closest("[data-qsel]");
 if(s)selChoice[s.dataset.qsel]=s.value;
});

/* backup */
function download(name,text,type){const b=new Blob([text],{type}),u=URL.createObjectURL(b),a=document.createElement("a");a.href=u;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),500)}
$("exportCsv").addEventListener("click",()=>{
 const rows=[["Date","Subject","Status"],...[...state.entries].sort((a,b)=>a.date.localeCompare(b.date)||a.createdAt-b.createdAt).map(e=>[e.date,(subj(e.subjectId)||{}).name||"Removed subject",e.status])];
 download("attendx-history.csv",rows.map(r=>r.map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(",")).join("\r\n"),"text/csv;charset=utf-8");
 inline("backupMsg","CSV exported ("+state.entries.length+" records). Starting counts are in the JSON backup.",true);
});
$("exportJson").addEventListener("click",()=>{download("attendx-backup-"+todayStr()+".json",JSON.stringify(state,null,2),"application/json");inline("backupMsg","Full JSON backup exported.",true)});
$("importBtn").addEventListener("click",()=>$("importFile").click());
$("importFile").addEventListener("change",ev=>{
 const f=ev.target.files[0];if(!f)return;
 const rd=new FileReader();
 rd.onload=()=>{
  let obj;try{obj=JSON.parse(rd.result)}catch(e){inline("backupMsg","That file is not valid JSON.",false);ev.target.value="";return}
  const r=sanitize(obj);
  if(r.err){inline("backupMsg",r.err+" Nothing was changed.",false);ev.target.value="";return}
  if(!confirm("Importing will replace all current data on this device. Continue?")){ev.target.value="";return}
  state=r.state;draftTT=null;resetForm();persist();render();
  inline("backupMsg","Backup imported: "+state.entries.length+" records.",true);ev.target.value="";
 };
 rd.onerror=()=>inline("backupMsg","Could not read the file.",false);
 rd.readAsText(f);
});
$("clearEntries").addEventListener("click",()=>{if(!state.entries.length){inline("backupMsg","There are no date-wise records to clear.",false);return}
 if(confirm("Delete ALL date-wise records? Starting counts stay.")){state.entries=[];resetForm();persist();render();inline("backupMsg","Date-wise records cleared.",true)}});
$("resetAll").addEventListener("click",()=>{if(confirm("Reset EVERYTHING (starting counts, records, timetable, target)? This cannot be undone.")){state=defState();draftTT=null;resetForm();persist();render();inline("backupMsg","Everything reset.",true)}});

/* init */
load();
$("entryDate").value=todayStr();
history.replaceState({v:"home"},"");
render();
showView("home");
/* refresh "today" if the app stays open past midnight or returns from the background */
document.addEventListener("visibilitychange",()=>{if(!document.hidden&&currentView==="home")renderHome()});
window.__attendx={get state(){return state}};
})();

(function(){
 var deferred=null,btn=document.getElementById("installBtn"),card=document.getElementById("installCard");
 window.addEventListener("beforeinstallprompt",function(e){e.preventDefault();deferred=e;card.style.display="block"});
 btn.addEventListener("click",function(){if(!deferred)return;deferred.prompt();deferred.userChoice.then(function(){deferred=null;card.style.display="none"})});
 window.addEventListener("appinstalled",function(){card.style.display="none"});
 if("serviceWorker" in navigator&&/^https?:$/.test(location.protocol)){
  window.addEventListener("load",function(){navigator.serviceWorker.register("sw.js").catch(function(){})});
 }
})();
