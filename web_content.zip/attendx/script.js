(function(){
"use strict";
const $=id=>document.getElementById(id);
const KEY="attendx_v2",OLD_KEY="attendx_v1";
const SUBJECTS=[["maths1","Maths-I"],["qme","QME"],["qmelab","QME Lab"],["pps","PPS"],["ppslab","PPS Lab"],["mpe","MPE"],["etw","ETW"],["etwlab","ETW Lab"],["evs","EVS"]];
const FDA="FDA Using Python";
const DAYNAMES=["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
function defTT(){return{
 0:[],
 1:[["Maths-I"],["QME"],["PPS Lab","ETW Lab"],["MPE"],["PPS"]],
 2:[["QME Lab","PPS Lab"],["MPE"],["Maths-I"],[FDA]],
 3:[["Maths-I"],["QME"],["PPS"],["ETW"],["ETW Lab","QME Lab"]],
 4:[["EVS"],["QME"],["ETW"],["Maths-I"],[FDA]],
 5:[["EVS"],["MPE"],["PPS"],["Maths-I"],[FDA]]
}}
function defState(){return{version:2,target:75,subjects:SUBJECTS.map(([id,name])=>({id,name,baseAttended:0,baseTotal:0})),entries:[],timetable:defTT(),enableSunday:false,setupSaved:false}}
let state=defState();
let editingId=null,draftTT=null,lastKey="",lastTime=0;

const uid=()=>(window.crypto&&crypto.randomUUID)?crypto.randomUUID():String(Date.now())+Math.random().toString(16).slice(2);
const esc=s=>String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const isInt=v=>Number.isInteger(v)&&v>=0;
const dateOk=d=>/^\d{4}-\d{2}-\d{2}$/.test(d)&&!isNaN(new Date(d+"T00:00:00"));
const dow=d=>new Date(d+"T00:00:00").getDay();
function todayStr(){const t=new Date();return t.getFullYear()+"-"+String(t.getMonth()+1).padStart(2,"0")+"-"+String(t.getDate()).padStart(2,"0")}
const subj=id=>state.subjects.find(s=>s.id===id);
const subjByName=n=>state.subjects.find(s=>s.name.toLowerCase()===String(n).trim().toLowerCase());

/* ---------- persistence ---------- */
function persist(){try{localStorage.setItem(KEY,JSON.stringify(state));return true}catch(e){toast("Could not save to browser storage (private mode or full).");return false}}
function sanitize(o){
 if(!o||typeof o!=="object")return{err:"File is not a valid AttendX backup."};
 const d=defState();
 if(o.target!==undefined){const t=Number(o.target);if(!(t>=1&&t<=100))return{err:"Backup has an invalid target."};d.target=t}
 if(Array.isArray(o.subjects)){
  const out=[];
  for(const s of o.subjects){
   if(!s||typeof s.id!=="string"||typeof s.name!=="string")return{err:"Backup has a malformed subject."};
   if(!isInt(s.baseAttended)||!isInt(s.baseTotal)||s.baseAttended>s.baseTotal)return{err:"Backup has invalid counts for "+s.name+"."};
   out.push({id:s.id,name:s.name,baseAttended:s.baseAttended,baseTotal:s.baseTotal});
  }
  if(!out.length)return{err:"Backup has no subjects."};
  d.subjects=out;
 }
 if(Array.isArray(o.entries)){
  const out=[];
  for(const e of o.entries){
   if(!e||!dateOk(e.date)||(e.status!=="present"&&e.status!=="absent")||!d.subjects.some(s=>s.id===e.subjectId))return{err:"Backup has an invalid attendance record."};
   out.push({id:typeof e.id==="string"?e.id:uid(),subjectId:e.subjectId,date:e.date,status:e.status,createdAt:Number(e.createdAt)||Date.now()});
  }
  d.entries=out;
 }
 if(o.timetable&&typeof o.timetable==="object"){
  const tt={};
  for(let i=0;i<=5;i++){
   const day=o.timetable[i];
   if(day===undefined){tt[i]=defTT()[i];continue}
   if(!Array.isArray(day)||!day.every(sl=>Array.isArray(sl)&&sl.every(x=>typeof x==="string")))return{err:"Backup has a malformed timetable."};
   tt[i]=day.filter(sl=>sl.length);
  }
  d.timetable=tt;
 }
 d.enableSunday=!!o.enableSunday;d.setupSaved=!!o.setupSaved;
 return{state:d};
}
function load(){
 try{
  const raw=localStorage.getItem(KEY);
  if(raw){const r=sanitize(JSON.parse(raw));if(r.state){state=r.state;return}}
  const old=localStorage.getItem(OLD_KEY);
  if(old){ // migrate v1
   const o=JSON.parse(old),d=defState(),map={};
   (o.subjects||[]).forEach(s=>{const m=d.subjects.find(x=>x.name.toLowerCase()===String(s.name).toLowerCase());if(m){map[s.id]=m.id;if(isInt(s.baseAttended)&&isInt(s.baseTotal)&&s.baseAttended<=s.baseTotal){m.baseAttended=s.baseAttended;m.baseTotal=s.baseTotal}}});
   d.entries=(o.entries||[]).filter(e=>map[e.subjectId]&&dateOk(e.date)&&(e.status==="present"||e.status==="absent")).map(e=>({id:e.id||uid(),subjectId:map[e.subjectId],date:e.date,status:e.status,createdAt:e.createdAt||Date.now()}));
   if(o.target>=1&&o.target<=100)d.target=Number(o.target);
   d.setupSaved=!!o.setupSaved;state=d;persist();
  }
 }catch(e){state=defState()}
}

/* ---------- calculations ---------- */
function totals(s){
 const es=state.entries.filter(e=>e.subjectId===s.id),pres=es.filter(e=>e.status==="present").length;
 const attended=s.baseAttended+pres,total=s.baseTotal+es.length;
 return{attended,total,absent:total-attended,pct:total?attended/total*100:null};
}
function plan(A,T){
 const P=state.target;
 if(T===0)return{none:true,canMiss:0,need:0};
 if(100*A>=P*T-1e-9){return{ok:true,canMiss:Math.max(0,Math.floor(100*A/P-T+1e-9)),need:0}}
 if(P>=100)return{ok:false,impossible:true,canMiss:0,need:null};
 return{ok:false,canMiss:0,need:Math.max(0,Math.ceil((P*T-100*A)/(100-P)-1e-9))};
}
function overall(){let a=0,t=0;state.subjects.forEach(s=>{const x=totals(s);a+=x.attended;t+=x.total});return{attended:a,total:t,absent:t-a,pct:t?a/t*100:null}}
const fmt=n=>n===null?"No classes yet":n.toFixed(1)+"%";
function level(x,p){if(p.none)return"none";if(!p.ok)return"bad";return p.canMiss<=1?"warn":"good"}
const colorVar=l=>l==="good"?"var(--green)":l==="warn"?"var(--yellow)":l==="bad"?"var(--red)":"#ccc";

/* ---------- messages ---------- */
let toastT;
function toast(t){const el=$("toast");el.textContent=t;el.classList.add("show");clearTimeout(toastT);toastT=setTimeout(()=>el.classList.remove("show"),3500)}
function inline(id,t,ok){$(id).innerHTML=t?`<div class="msg ${ok?"ok":"bad"}">${esc(t)}</div>`:""}

/* ---------- renderers ---------- */
function renderStartingInputs(){
 $("startingInputs").innerHTML=state.subjects.map(s=>`<div class="subject"><div class="subject-name">${esc(s.name)}</div><div class="pair"><div><label for="sa-${esc(s.id)}">Attended Classes</label><input id="sa-${esc(s.id)}" data-sa="${esc(s.id)}" type="number" inputmode="numeric" min="0" step="1" value="${s.baseAttended}"></div><div><label for="st-${esc(s.id)}">Total Classes Held</label><input id="st-${esc(s.id)}" data-st="${esc(s.id)}" type="number" inputmode="numeric" min="0" step="1" value="${s.baseTotal}"></div></div><div class="fe" id="fe-${esc(s.id)}"></div></div>`).join("");
}
function fillSubjectSelects(){
 const opts=state.subjects.map(s=>`<option value="${esc(s.id)}">${esc(s.name)}</option>`).join("");
 const cur=$("entrySubject").value;$("entrySubject").innerHTML=opts;if(cur&&subj(cur))$("entrySubject").value=cur;
 const f=$("fSubject").value;$("fSubject").innerHTML='<option value="">All subjects</option>'+opts;if(f&&subj(f))$("fSubject").value=f;
}
function renderStats(){
 const x=overall(),P=state.target,p=plan(x.attended,x.total);
 $("targetPill").textContent=P+"%";$("targetInput").value=P;
 $("overallPct").textContent=x.total?x.pct.toFixed(1)+"%":"—";
 $("overallNote").textContent=!x.total?"No classes yet":(p.ok?"At or above":"Below")+" your "+P+"% target";
 const lv=level(x,p);$("overallBar").style.width=x.total?Math.min(100,x.pct)+"%":"0";$("overallBar").style.background=colorVar(lv);
 $("attendedTotal").textContent=x.attended;$("absentNote").textContent=x.absent+" absent";$("heldTotal").textContent=x.total;
 if(!x.total){$("relLabel").textContent="Can miss (estimate)";$("relValue").textContent="—";$("relNote").textContent="Save starting attendance first"}
 else if(p.ok){$("relLabel").textContent="Can miss (estimate)";$("relValue").textContent=p.canMiss;$("relNote").textContent="Future classes at "+P+"% · not official"}
 else{$("relLabel").textContent="Need to attend";$("relValue").textContent=p.impossible?"—":p.need;$("relNote").textContent=p.impossible?"100% not recoverable once a class is missed":"Consecutive classes to reach "+P+"%"}
}
function renderCards(){
 const P=state.target,al=[];
 $("subjectCards").innerHTML=state.subjects.map(s=>{
  const x=totals(s),p=plan(x.attended,x.total),lv=level(x,p);
  let adv;
  if(p.none)adv="No classes yet.";
  else if(p.ok){adv=`Can miss <strong class="${lv}">${p.canMiss}</strong> future class${p.canMiss===1?"":"es"} and stay at ${P}%. (estimate)`;
   if(p.canMiss===0)al.push(["yel",`${s.name}: exactly at target — no spare absences.`]);else if(p.canMiss===1)al.push(["yel",`${s.name}: only 1 spare absence left.`]);}
  else if(p.impossible){adv="A 100% target cannot be recovered after an absence.";al.push(["red",`${s.name}: ${fmt(x.pct)} — target unreachable.`])}
  else{adv=`Attend <strong class="bad">${p.need}</strong> consecutive class${p.need===1?"":"es"} to reach ${P}%.`;al.push(["red",`${s.name}: shortage at ${fmt(x.pct)} — attend ${p.need} in a row to recover.`])}
  return `<div class="subject"><div class="subject-head"><div><div class="subject-name">${esc(s.name)}</div><div class="subject-meta">${x.attended} attended · ${x.absent} absent · ${x.total} held</div></div><span class="badge ${lv==="good"?"":lv}">${p.none?"No classes yet":x.pct.toFixed(1)+"%"}</span></div><div class="progress"><span style="width:${x.total?Math.min(100,x.pct):0}%;background:${colorVar(lv)}"></span></div><div class="subject-foot" style="margin-top:10px"><div class="advice">${adv}</div><div class="small-actions"><button class="present" data-quick="present" data-id="${esc(s.id)}">+ Present</button><button class="absent" data-quick="absent" data-id="${esc(s.id)}">+ Absent</button></div></div></div>`}).join("");
 $("alerts").innerHTML=al.length?al.map(a=>`<div class="alert ${a[0]}">${esc(a[1])}</div>`).join(""):(overall().total?'<div class="alert grn">All subjects are above target with room to spare.</div>':"");
}
function filteredEntries(){
 const f=$("fFrom").value,t=$("fTo").value,s=$("fSubject").value;
 return state.entries.filter(e=>(!f||e.date>=f)&&(!t||e.date<=t)&&(!s||e.subjectId===s)).sort((a,b)=>b.date.localeCompare(a.date)||b.createdAt-a.createdAt);
}
function renderHistory(){
 const list=filteredEntries();
 $("histCount").textContent=list.length+" of "+state.entries.length+" records";
 $("historyBody").innerHTML=list.length?list.map(e=>{const s=subj(e.subjectId);return `<tr><td>${esc(e.date)}</td><td>${esc(s?s.name:"Removed subject")}</td><td class="${e.status==="present"?"good":"bad"}">${e.status==="present"?"Present":"Absent"}</td><td><button class="secondary" style="padding:6px 9px" data-edit="${esc(e.id)}">Edit</button> <button class="danger" style="padding:6px 9px" data-del="${esc(e.id)}">Delete</button></td></tr>`}).join(""):`<tr><td colspan="4" class="empty">${state.entries.length?"No records match the filters.":"No date-wise records yet."}</td></tr>`;
}
function dayAllowed(d){const w=dow(d);return w===6?"saturday":(w===0&&!state.enableSunday)?"sunday":""}
function renderQuick(){
 const d=$("quickDate").value,box=$("quickList");
 if(!dateOk(d)){box.innerHTML='<div class="empty">Pick a date.</div>';return}
 const w=dow(d),why=dayAllowed(d);
 if(why==="saturday"){box.innerHTML='<div class="empty">Saturday is excluded — nothing is counted.</div>';return}
 if(why==="sunday"){box.innerHTML='<div class="empty">Sunday is an off day. Enable Sunday in “Edit Timetable” if needed.</div>';return}
 const slots=state.timetable[w]||[];
 if(!slots.length){box.innerHTML='<div class="empty">No classes in the timetable for '+DAYNAMES[w]+'.</div>';return}
 box.innerHTML=slots.map((slot,i)=>{
  const opts=slot.filter(n=>!/^fda/i.test(n)).map(subjByName).filter(Boolean);
  if(!opts.length)return `<div class="slot"><div class="nm excl">Period ${i+1}: ${esc(FDA)} — excluded</div></div>`;
  const sel=opts.length>1?`<select data-qsel="${i}" aria-label="Choose subject for period ${i+1}">${opts.map(o=>`<option value="${esc(o.id)}">${esc(o.name)}</option>`).join("")}</select>`:`<span class="nm">${esc(opts[0].name)}</span>`;
  const first=opts[0].id;
  return `<div class="slot"><span class="stat-note">P${i+1}</span>${opts.length>1?'<span class="nm" style="flex:0">'+sel+'</span><span class="nm"></span>':sel}<button class="present" data-qs="${i}" data-s="present" data-first="${esc(first)}">Present</button><button class="absent" data-qs="${i}" data-s="absent" data-first="${esc(first)}">Absent</button></div>`}).join("");
}
function renderTTEditor(){
 if(!draftTT){draftTT={};for(let i=0;i<=5;i++)draftTT[i]=(state.timetable[i]||[]).map(sl=>sl.join(" / "))}
 $("sundayToggle").checked=state.enableSunday;
 const days=[1,2,3,4,5];if(state.enableSunday)days.unshift(0);
 $("ttDays").innerHTML=days.map(i=>`<div class="daybox"><h3 style="margin-top:0">${DAYNAMES[i]}</h3>${(draftTT[i]||[]).map((v,k)=>`<div class="tt-slot"><input data-tt="${i}" data-k="${k}" value="${esc(v)}" aria-label="${DAYNAMES[i]} period ${k+1}"><button class="danger" data-ttdel="${i}:${k}" aria-label="Remove period">✕</button></div>`).join("")||'<div class="stat-note" style="margin-bottom:6px">No periods.</div>'}<button class="secondary" data-ttadd="${i}" style="padding:7px 11px;font-size:12px">+ Add period</button></div>`).join("")+'<div class="daybox"><h3 style="margin:0">Saturday</h3><div class="stat-note">Entire day excluded — cannot be edited.</div></div>';
}
function readDraft(){document.querySelectorAll("[data-tt]").forEach(inp=>{const i=inp.dataset.tt,k=Number(inp.dataset.k);if(draftTT[i])draftTT[i][k]=inp.value})}
function render(){fillSubjectSelects();renderStats();renderCards();renderHistory();renderQuick()}

/* ---------- actions ---------- */
function addRecord(subjectId,date,status){
 const why=dayAllowed(date);
 if(why==="saturday"){return"Saturdays are excluded from attendance — this record was not added."}
 if(why==="sunday"){return"Sunday is an off day. Enable Sunday under “Edit Timetable” to add records."}
 const key=subjectId+"|"+date+"|"+status,now=Date.now();
 if(key===lastKey&&now-lastTime<800)return"Ignored a double tap. Tap again to add another class.";
 lastKey=key;lastTime=now;
 state.entries.push({id:uid(),subjectId,date,status,createdAt:now});
 persist();render();return"";
}
$("saveStarting").addEventListener("click",()=>{
 let bad=0;const vals=[];
 state.subjects.forEach(s=>{
  const a=$("sa-"+s.id),t=$("st-"+s.id),fe=$("fe-"+s.id);let m="";
  a.classList.remove("err");t.classList.remove("err");
  const as=a.value.trim(),ts=t.value.trim(),av=Number(as),tv=Number(ts);
  if(as===""||ts==="")m="Fill both fields (use 0 if none).";
  else if(!/^\d+$/.test(as)||!/^\d+$/.test(ts)||!isInt(av)||!isInt(tv))m="Use non-negative whole numbers only.";
  else if(av>tv)m="Attended cannot be more than total held.";
  if(m){bad++;fe.textContent=m;(m.startsWith("Attended")?a:(as===""||!/^\d+$/.test(as)?a:t)).classList.add("err");if(!m.startsWith("Attended")&&(ts===""||!/^\d+$/.test(ts)))t.classList.add("err")}else{fe.textContent="";vals.push([s,av,tv])}
 });
 if(bad){inline("startMsg",`${bad} subject${bad>1?"s have":" has"} errors. Nothing was saved — your entries are still in the boxes; fix the highlighted ones.`,false);return}
 vals.forEach(([s,a,t])=>{s.baseAttended=a;s.baseTotal=t});state.setupSaved=true;
 if(persist()){inline("startMsg","Saved starting attendance for all "+vals.length+" subjects. Dashboard updated.",true);toast("Starting attendance saved")}
 render();
});
$("resetInputs").addEventListener("click",()=>{renderStartingInputs();inline("startMsg","Inputs reset to your last saved values.",true)});
function resetForm(){editingId=null;$("editBar").style.display="none";$("addEntry").textContent="Add Attendance"}
$("addEntry").addEventListener("click",()=>{
 const sid=$("entrySubject").value,date=$("entryDate").value,st=$("entryStatus").value;
 if(!dateOk(date)){inline("markMsg","Choose a valid date.",false);return}
 if(!subj(sid)){inline("markMsg","Choose a subject.",false);return}
 if(editingId){
  const e=state.entries.find(x=>x.id===editingId);
  const why=dayAllowed(date);
  if(why){inline("markMsg",why==="saturday"?"Saturdays are excluded.":"Sunday is disabled.",false);return}
  if(e){e.subjectId=sid;e.date=date;e.status=st}
  persist();render();resetForm();inline("markMsg","Record updated.",true);return;
 }
 const err=addRecord(sid,date,st);
 if(err)inline("markMsg",err,false);else inline("markMsg",`Added: ${subj(sid).name} · ${date} · ${st==="present"?"Present":"Absent"}.`,true);
});
$("cancelEdit").addEventListener("click",()=>{resetForm();inline("markMsg","Edit cancelled.",true)});
$("entryDate").addEventListener("change",()=>{});
$("quickDate").addEventListener("change",renderQuick);
$("saveTarget").addEventListener("click",()=>{
 const raw=$("targetInput").value.trim(),t=Number(raw);
 if(raw===""||!isFinite(t)||t<1||t>100){inline("targetMsg","Target must be a number from 1 to 100.",false);return}
 state.target=t;persist();render();inline("targetMsg","Target updated to "+t+"%.",true);
});
["fFrom","fTo","fSubject"].forEach(id=>$(id).addEventListener("change",renderHistory));
$("clearFilters").addEventListener("click",()=>{$("fFrom").value="";$("fTo").value="";$("fSubject").value="";renderHistory()});

document.addEventListener("click",e=>{
 const q=e.target.closest("[data-quick]");
 if(q){const d=$("entryDate").value;if(!dateOk(d)){toast("Pick a valid date in Step 2 first.");return}
  const err=addRecord(q.dataset.id,d,q.dataset.quick);toast(err||`${subj(q.dataset.id).name}: ${q.dataset.quick} on ${d}`);return}
 const qs=e.target.closest("[data-qs]");
 if(qs){const d=$("quickDate").value,i=qs.dataset.qs,sel=document.querySelector(`[data-qsel="${i}"]`),sid=sel?sel.value:qs.dataset.first;
  const err=addRecord(sid,d,qs.dataset.s);toast(err||`${subj(sid).name}: ${qs.dataset.s} on ${d}`);return}
 const del=e.target.closest("[data-del]");
 if(del){if(!confirm("Delete this record?"))return;state.entries=state.entries.filter(x=>x.id!==del.dataset.del);if(editingId===del.dataset.del)resetForm();persist();render();toast("Record deleted");return}
 const ed=e.target.closest("[data-edit]");
 if(ed){const r=state.entries.find(x=>x.id===ed.dataset.edit);if(!r)return;editingId=r.id;
  $("entryDate").value=r.date;$("entrySubject").value=r.subjectId;$("entryStatus").value=r.status;
  $("editBar").style.display="flex";$("addEntry").textContent="Update Record";$("editLabel").textContent="Editing record from "+r.date;
  inline("markMsg","",true);$("mark").scrollIntoView();return}
 const ta=e.target.closest("[data-ttadd]");
 if(ta){readDraft();draftTT[ta.dataset.ttadd].push("");renderTTEditor();return}
 const td=e.target.closest("[data-ttdel]");
 if(td){readDraft();const [i,k]=td.dataset.ttdel.split(":");draftTT[i].splice(Number(k),1);renderTTEditor()}
});

/* timetable editor */
$("sundayToggle").addEventListener("change",()=>{readDraft();state.enableSunday=$("sundayToggle").checked;persist();renderTTEditor();renderQuick()});
$("saveTT").addEventListener("click",()=>{
 readDraft();const tt={};
 for(let i=0;i<=5;i++){
  tt[i]=[];
  for(const line of (draftTT[i]||[])){
   const parts=line.split("/").map(x=>x.trim()).filter(Boolean);
   if(!parts.length)continue;
   const slot=[];
   for(const p of parts){
    if(/^fda/i.test(p)){slot.push(FDA);continue}
    const s=subjByName(p);
    if(!s){inline("ttMsg",`“${p}” (${DAYNAMES[i]}) is not a known subject. Use: ${state.subjects.map(x=>x.name).join(", ")} or FDA.`,false);return}
    slot.push(s.name);
   }
   tt[i].push(slot);
  }
 }
 state.timetable=tt;persist();draftTT=null;renderTTEditor();renderQuick();inline("ttMsg","Timetable saved.",true);
});
$("resetTT").addEventListener("click",()=>{if(!confirm("Restore the default timetable? Your edits will be lost."))return;state.timetable=defTT();persist();draftTT=null;renderTTEditor();renderQuick();inline("ttMsg","Default timetable restored.",true)});

/* backup */
function download(name,text,type){const b=new Blob([text],{type}),u=URL.createObjectURL(b),a=document.createElement("a");a.href=u;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),500)}
$("exportCsv").addEventListener("click",()=>{
 const rows=[["Date","Subject","Status"],...[...state.entries].sort((a,b)=>a.date.localeCompare(b.date)||a.createdAt-b.createdAt).map(e=>[e.date,(subj(e.subjectId)||{}).name||"Removed subject",e.status])];
 download("attendx-history.csv",rows.map(r=>r.map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(",")).join("\r\n"),"text/csv;charset=utf-8");
 inline("backupMsg","CSV exported ("+state.entries.length+" records). Starting counts are in the JSON backup.",true);
});
$("exportJson").addEventListener("click",()=>{download("attendx-backup-"+todayStr()+".json",JSON.stringify(state,null,2),"application/json");inline("backupMsg","Full JSON backup exported.",true)});
$("importBtn").addEventListener("click",()=>$("importFile").click());
$("importFile").addEventListener("change",ev=>{
 const f=ev.target.files[0];if(!f)return;
 const rd=new FileReader();
 rd.onload=()=>{
  let obj;try{obj=JSON.parse(rd.result)}catch(e){inline("backupMsg","That file is not valid JSON.",false);ev.target.value="";return}
  const r=sanitize(obj);
  if(r.err){inline("backupMsg",r.err+" Nothing was changed.",false);ev.target.value="";return}
  if(!confirm("Importing will replace all current data in this browser. Continue?")){ev.target.value="";return}
  state=r.state;draftTT=null;resetForm();persist();renderStartingInputs();renderTTEditor();render();
  inline("backupMsg","Backup imported: "+state.entries.length+" records.",true);ev.target.value="";
 };
 rd.onerror=()=>inline("backupMsg","Could not read the file.",false);
 rd.readAsText(f);
});
$("clearEntries").addEventListener("click",()=>{if(!state.entries.length){inline("backupMsg","There are no date-wise records to clear.",false);return}
 if(confirm("Delete ALL date-wise records? Starting counts stay.")){state.entries=[];resetForm();persist();render();inline("backupMsg","Date-wise records cleared.",true)}});
$("resetAll").addEventListener("click",()=>{if(confirm("Reset EVERYTHING (starting counts, records, timetable, target)? This cannot be undone.")){state=defState();draftTT=null;resetForm();persist();renderStartingInputs();renderTTEditor();render();inline("backupMsg","Everything reset.",true)}});

/* init */
load();
$("entryDate").value=todayStr();$("quickDate").value=todayStr();
renderStartingInputs();renderTTEditor();render();
window.__attendx={get state(){return state}};
})();

(function(){
 var deferred=null,btn=document.getElementById("installBtn");
 window.addEventListener("beforeinstallprompt",function(e){e.preventDefault();deferred=e;btn.style.display="inline-block"});
 btn.addEventListener("click",function(){if(!deferred)return;deferred.prompt();deferred.userChoice.then(function(){deferred=null;btn.style.display="none"})});
 window.addEventListener("appinstalled",function(){btn.style.display="none"});
 if("serviceWorker" in navigator&&/^https?:$/.test(location.protocol)){
  window.addEventListener("load",function(){navigator.serviceWorker.register("sw.js").catch(function(){})});
 }
})();
