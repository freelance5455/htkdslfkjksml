npm install -g vercel
npm run build
vercel deploy --prod