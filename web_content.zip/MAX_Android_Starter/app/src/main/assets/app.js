const setup = document.getElementById("setup");
const chat = document.getElementById("chat");
const keyInput = document.getElementById("apiKey");
const setupMsg = document.getElementById("setupMsg");
const messages = document.getElementById("messages");
const messageInput = document.getElementById("message");
const sendButton = document.getElementById("send");
let waiting = false;

function showSetup() { chat.classList.add("hidden"); setup.classList.remove("hidden"); }
function showChat() { setup.classList.add("hidden"); chat.classList.remove("hidden"); }
function addMessage(text, who) {
  const div = document.createElement("div");
  div.className = "bubble " + who;
  div.textContent = text;
  messages.appendChild(div);
  messages.scrollTop = messages.scrollHeight;
}
function send() {
  const text = messageInput.value.trim();
  if (!text || waiting) return;
  addMessage(text, "user");
  messageInput.value = "";
  waiting = true;
  sendButton.disabled = true;
  sendButton.textContent = "Thinking...";
  addMessage("MAX soch raha hai...", "bot");
  window.MaxBridge.ask(text);
}
window.MAX = {
  onKeySaved(ok, msg) {
    setupMsg.textContent = msg;
    if (ok) showChat();
  },
  onKeyCleared() { showSetup(); },
  showSetup,
  onReply(ok, reply) {
    const pending = messages.lastElementChild;
    if (pending && pending.textContent === "MAX soch raha hai...") pending.remove();
    addMessage(reply, "bot");
    waiting = false;
    sendButton.disabled = false;
    sendButton.textContent = "Send";
  }
};
document.getElementById("saveKey").addEventListener("click", () => {
  const key = keyInput.value.trim();
  if (!key) { setupMsg.textContent = "Pehle API key paste karo."; return; }
  setupMsg.textContent = "Saving...";
  window.MaxBridge.saveApiKey(key);
  keyInput.value = "";
});
document.getElementById("send").addEventListener("click", send);
messageInput.addEventListener("keydown", e => {
  if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); }
});
document.getElementById("changeKey").addEventListener("click", () => {
  if (confirm("Saved API key clear karke setup screen kholni hai?")) window.MaxBridge.clearApiKey();
});
window.addEventListener("load", () => {
  if (window.MaxBridge.hasApiKey()) showChat(); else showSetup();
});
