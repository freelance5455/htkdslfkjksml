package com.max.assistant

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var keyStore: ApiKeyStore

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        keyStore = ApiKeyStore(this)

        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = false
        webView.settings.allowContentAccess = false
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(MaxBridge(), "MaxBridge")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    inner class MaxBridge {
        @JavascriptInterface
        fun hasApiKey(): Boolean = keyStore.getKey() != null

        @JavascriptInterface
        fun saveApiKey(key: String) {
            if (key.length !in 20..300 || key.contains(" ")) {
                sendToPage("MAX.onKeySaved(false, 'API key format check karo.')")
                return
            }
            try {
                keyStore.saveKey(key)
                sendToPage("MAX.onKeySaved(true, 'API key save ho gayi.')")
            } catch (e: Exception) {
                sendToPage("MAX.onKeySaved(false, 'Key save nahi ho saki.')")
            }
        }

        @JavascriptInterface
        fun clearApiKey() {
            keyStore.clear()
            sendToPage("MAX.onKeyCleared()")
        }

        @JavascriptInterface
        fun ask(message: String) {
            if (message.isBlank() || message.length > 4000) {
                sendToPage("MAX.onReply(false, 'Message khaali ya bohat lamba hai.')")
                return
            }
            val apiKey = keyStore.getKey()
            if (apiKey == null) {
                sendToPage("MAX.showSetup()")
                return
            }
            executor.execute {
                try {
                    val reply = callGemini(apiKey, message)
                    val safe = JSONObject.quote(reply)
                    sendToPage("MAX.onReply(true, $safe)")
                } catch (e: Exception) {
                    val safe = JSONObject.quote(
                        "Gemini request fail hui. API key, internet aur API access check karo. (${e.message ?: "unknown error"})"
                    )
                    sendToPage("MAX.onReply(false, $safe)")
                }
            }
        }
    }

    private fun callGemini(apiKey: String, message: String): String {
        val endpoint = URL(
            "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey"
        )
        val connection = (endpoint.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 60000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
        }

        try {
            val body = JSONObject().apply {
                put("system_instruction", JSONObject().put(
                    "parts", JSONArray().put(JSONObject().put(
                        "text",
                        "You are MAX, a helpful personal Android assistant. Reply naturally in Pakistani Urdu mixed with English when suitable. Be clear and concise. Never claim to have controlled the phone unless the app confirms it."
                    ))
                ))
                put("contents", JSONArray().put(JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().put(JSONObject().put("text", message)))
                }))
            }

            OutputStreamWriter(connection.outputStream, Charsets.UTF_8).use {
                it.write(body.toString())
            }

            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = stream.bufferedReader().use { it.readText() }
            if (code !in 200..299) {
                throw IllegalStateException("HTTP $code: ${response.take(500)}")
            }

            val json = JSONObject(response)
            return json.getJSONArray("candidates")
                .getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
                .getJSONObject(0)
                .getString("text")
        } finally {
            connection.disconnect()
        }
    }

    private fun sendToPage(js: String) {
        runOnUiThread { webView.evaluateJavascript(js, null) }
    }

    override fun onDestroy() {
        executor.shutdown()
        webView.destroy()
        super.onDestroy()
    }
}
