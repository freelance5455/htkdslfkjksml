# MAX Android Starter — Roman Urdu Guide

## Is ZIP mein kya hai?
- Android Studio project source
- Pehli dafa open par Gemini API key setup screen
- API key Android Keystore AES-GCM encryption se device par encrypted save hoti hai
- HTML/CSS/JavaScript interface `app/src/main/assets/` mein hai
- Gemini 2.5 Flash API se basic chat connection
- Change API key option

## APK kaise banao?
1. Android Studio install karo: https://developer.android.com/studio
2. ZIP extract karo.
3. Android Studio > Open > extracted `MAX_Android_Starter` folder select karo.
4. Gradle sync complete hone do. JDK 17 use karo.
5. Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK `app/build/outputs/apk/debug/app-debug.apk` mein milegi.
7. APK phone par install karo. First launch par Gemini API key maangegi.

## API key
Google AI Studio: https://aistudio.google.com/app/apikey
Key ko kisi ke saath share mat karo. App key ko Android Keystore se encrypted form mein local device par rakhta hai. App uninstall/clear data karne par key dobara enter karni par sakti hai.

## Important
- Yeh starter hai, full MAX/JARVIS feature-complete app nahi.
- Is version mein Gemini chat hai; wake word, continuous background listening, app control, YouTube control, reminders, vision, document analysis, live translation, cloud memory aur automation abhi implemented nahi.
- API usage par Google ki billing/quota conditions apply ho sakti hain. API key ko private rakho.
- App personal-use prototype hai. APK reverse engineering se app ke andar use hone wali key ko technically retrieve karna mumkin ho sakta hai; Android Keystore at-rest encryption provide karta hai, server-side key secrecy nahi.
- Production app ke liye backend proxy, authentication, rate limiting, HTTPS, privacy policy aur abuse controls recommended hain.
- Speech/microphone permissions abhi is starter mein request nahi ki jati.
