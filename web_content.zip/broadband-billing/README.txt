# Broadband Billing App

Simple mobile billing app for broadband/internet subscriber payment tracking.

## Fields
- Customer Name
- STB ID
- Mobile Number
- Balance Amount
- Paid Amount
- Remaining Balance (auto-calculated)
- Payment Date
- Notes
- Status (Paid / Outstanding)

## Features
- Add, Edit, Delete customers
- Search
- Summary of total customers & outstanding
- Export all data to CSV (open in Excel)

## How to use as APK

1. Download the file `broadband-billing-app.zip`
2. Go to one of these free online tools:
   - https://www.apkmaker.dev
   - Or search "HTML to APK" / "ZIP to APK"
3. Upload the ZIP file
4. Set app name: **Broadband Billing**
5. Build and download the APK
6. Transfer to Android phone and install

## Alternative: Use as Web App
Open `index.html` in any browser (Chrome recommended). It works offline and data is saved on the device.

Data is stored locally on the phone (localStorage). No internet needed after loading.
