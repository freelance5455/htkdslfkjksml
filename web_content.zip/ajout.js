const formulaire = document.getElementById("formulaire");
const selectType = document.getElementById("type-trophees");
const champAutres = document.getElementById("autres");
const champCover = document.getElementById("cover");
const blocTrophees = document.getElementById("bloc-trophees");
const TYPES_PS = ["platine", "or", "argent", "bronze"];
const LIBELLES_RARETE = [["platine", "Platine"], ["or", "Or"], ["argent", "Argent"], ["bronze", "Bronze"]];
const LIBELLES_SYSTEME = { playstation: "Trophées", steam: "Succès", libre: "Objectifs" };
const ARTICLES_SYSTEME = { playstation: "un trophée", steam: "un succès", libre: "un objectif" };

const parametres = new URLSearchParams(window.location.search);
const idEdition = parametres.get("id");
const jeuEdite = idEdition ? lireJeuxPerso().find(j => j.id === idEdition) : null;

let collectiblesModele = [];
let tropheesModele = [];
let ligneEnCours = null;

function plateformesChoisies() {
  const cochees = [...document.querySelectorAll('input[name="plateforme"]:checked')]
    .map(c => c.value);
  const autres = champAutres.value.split(",").map(s => s.trim()).filter(Boolean);
  return cochees.concat(autres);
}

function proposerSysteme() {
  const texte = plateformesChoisies().join(" ");
  if (/playstation|\bps\d?\b/i.test(texte)) selectType.value = "playstation";
  else if (/steam/i.test(texte)) selectType.value = "steam";
  else selectType.value = "libre";
  majBlocTrophees();
}

document.querySelectorAll('input[name="plateforme"]').forEach(c =>
  c.addEventListener("change", proposerSysteme));
champAutres.addEventListener("input", proposerSysteme);
selectType.addEventListener("change", () => majBlocTrophees());

function attribuerIds(nouveaux, anciens, prefixe) {
  const utilises = new Set();
  nouveaux.forEach(n => {
    const trouve = anciens.find(o => o.nom === n.nom && !utilises.has(o.id));
    if (trouve) {
      n.id = trouve.id;
      utilises.add(trouve.id);
    } else {
      n.id = null;
    }
  });
  nouveaux.forEach((n, i) => {
    if (n.id !== null) return;
    const ancien = anciens[i];
    if (ancien && !utilises.has(ancien.id)) {
      n.id = ancien.id;
      utilises.add(ancien.id);
    } else {
      n.id = prefixe + Date.now().toString(36) + i;
    }
  });
}

function idsImages(j) {
  return [j.cover].concat((j.collectibles || []).map(c => c.icone)).filter(estIdImage);
}

const imagesOriginales = new Set(jeuEdite ? idsImages(jeuEdite) : []);

function oublierImageTemporaire(id) {
  if (estIdImage(id) && !imagesOriginales.has(id)) supprimerImage(id).catch(() => {});
}

function nomDepuisFichier(nomFichier) {
  return nomFichier.replace(/\.[^.]+$/, "").replace(/[_-]+/g, " ").trim() || "Collectible";
}

/* ---------- Trophées ---------- */

function majBlocTrophees() {
  const systeme = selectType.value;
  blocTrophees.style.display = systeme === "aucun" ? "none" : "";
  document.getElementById("legende-trophees").textContent = LIBELLES_SYSTEME[systeme] || "Trophées";
  document.getElementById("btn-ajouter-trophee").textContent =
    "+ Ajouter " + (ARTICLES_SYSTEME[systeme] || "un trophée");
  dessinerTrophees();
}

function dessinerTrophees() {
  const conteneur = document.getElementById("liste-trophees-form");
  const avecRarete = selectType.value === "playstation";
  conteneur.innerHTML = "";
  conteneur.classList.toggle("avec-type", avecRarete);

  if (tropheesModele.length === 0) {
    conteneur.innerHTML = '<p class="aide">Rien pour le moment.</p>';
    return;
  }

  tropheesModele.forEach(t => {
    const ligne = document.createElement("div");
    ligne.className = "ligne-trophee";

    const nom = document.createElement("input");
    nom.type = "text";
    nom.className = "champ-nom";
    nom.placeholder = "Nom";
    nom.value = t.nom;
    nom.addEventListener("input", () => { t.nom = nom.value; });

    const description = document.createElement("input");
    description.type = "text";
    description.className = "champ-desc";
    description.placeholder = "Description";
    description.value = t.description;
    description.addEventListener("input", () => { t.description = description.value; });

    ligne.append(nom, description);

    if (avecRarete) {
      const rarete = document.createElement("select");
      rarete.className = "champ-rarete";
      LIBELLES_RARETE.forEach(([valeur, libelle]) => {
        const option = document.createElement("option");
        option.value = valeur;
        option.textContent = libelle;
        rarete.appendChild(option);
      });
      rarete.value = TYPES_PS.includes(t.type) ? t.type : "bronze";
      rarete.addEventListener("change", () => { t.type = rarete.value; });
      ligne.appendChild(rarete);
    }

    const retirer = document.createElement("button");
    retirer.type = "button";
    retirer.className = "retirer";
    retirer.title = "Retirer";
    retirer.textContent = "×";
    retirer.addEventListener("click", () => {
      tropheesModele.splice(tropheesModele.indexOf(t), 1);
      dessinerTrophees();
    });
    ligne.appendChild(retirer);

    conteneur.appendChild(ligne);
  });
}

document.getElementById("btn-ajouter-trophee").addEventListener("click", () => {
  tropheesModele.push({ nom: "", description: "", type: "bronze" });
  dessinerTrophees();
  const conteneur = document.getElementById("liste-trophees-form");
  const champ = conteneur.lastElementChild.querySelector(".champ-nom");
  champ.focus();
  champ.scrollIntoView({ block: "center" });
});

/* ---------- Jaquette ---------- */

function afficherApercuCover() {
  const zone = document.getElementById("apercu-cover");
  if (!champCover.value) {
    zone.textContent = "Aucune image";
    return;
  }
  zone.innerHTML = balisesImage(champCover.value, "");
  resoudreImages(zone);
}

document.getElementById("btn-cover").addEventListener("click", () =>
  document.getElementById("fichier-cover").click());

document.getElementById("fichier-cover").addEventListener("change", async e => {
  const fichier = e.target.files[0];
  e.target.value = "";
  if (!fichier) return;
  try {
    const blob = await redimensionner(fichier, 400, 600, 0.85);
    const id = await enregistrerImage(blob);
    oublierImageTemporaire(champCover.value);
    champCover.value = id;
    afficherApercuCover();
  } catch (erreur) {
    alert("Impossible de lire cette image.");
  }
});

document.getElementById("btn-retirer-cover").addEventListener("click", () => {
  oublierImageTemporaire(champCover.value);
  champCover.value = "";
  afficherApercuCover();
});

/* ---------- Collectibles ---------- */

function vignetteHtml(icone) {
  if (estIdImage(icone) || /\.(png|jpe?g|webp|svg|gif)$/i.test(icone || "")) {
    return balisesImage(icone, "");
  }
  if (icone) return '<span class="emoji">' + icone + "</span>";
  return "+";
}

function majTypesSuggeres() {
  const types = [...new Set(collectiblesModele.map(c => (c.groupe || "").trim()).filter(Boolean))];
  document.getElementById("liste-types").innerHTML =
    types.map(t => '<option value="' + t.replace(/"/g, "&quot;") + '">').join("");
}

function dessinerLignes() {
  const conteneur = document.getElementById("liste-collectibles");
  conteneur.innerHTML = "";

  if (collectiblesModele.length === 0) {
    conteneur.innerHTML = '<p class="aide">Aucun collectible pour le moment.</p>';
    majTypesSuggeres();
    return;
  }

  collectiblesModele.forEach(c => {
    const ligne = document.createElement("div");
    ligne.className = "ligne-collectible";

    const vignette = document.createElement("button");
    vignette.type = "button";
    vignette.className = "vignette";
    vignette.title = "Choisir une image";
    vignette.innerHTML = vignetteHtml(c.icone);
    vignette.addEventListener("click", () => {
      ligneEnCours = c;
      document.getElementById("fichier-ligne").click();
    });

    const nom = document.createElement("input");
    nom.type = "text";
    nom.className = "champ-nom";
    nom.placeholder = "Nom";
    nom.value = c.nom;
    nom.addEventListener("input", () => { c.nom = nom.value; });

    const type = document.createElement("input");
    type.type = "text";
    type.className = "champ-type";
    type.placeholder = "Type";
    type.setAttribute("list", "liste-types");
    type.value = c.groupe || "";
    type.addEventListener("input", () => { c.groupe = type.value; });
    type.addEventListener("change", majTypesSuggeres);

    const retirer = document.createElement("button");
    retirer.type = "button";
    retirer.className = "retirer";
    retirer.title = "Retirer ce collectible";
    retirer.textContent = "×";
    retirer.addEventListener("click", () => {
      oublierImageTemporaire(c.icone);
      collectiblesModele.splice(collectiblesModele.indexOf(c), 1);
      dessinerLignes();
    });

    ligne.append(vignette, nom, type, retirer);
    conteneur.appendChild(ligne);
  });

  resoudreImages(conteneur);
  majTypesSuggeres();
}

document.getElementById("btn-ajouter-collectible").addEventListener("click", () => {
  const dernier = collectiblesModele[collectiblesModele.length - 1];
  collectiblesModele.push({ nom: "", groupe: dernier ? dernier.groupe || "" : "", icone: "" });
  dessinerLignes();
  const conteneur = document.getElementById("liste-collectibles");
  const champ = conteneur.lastElementChild.querySelector(".champ-nom");
  champ.focus();
  champ.scrollIntoView({ block: "center" });
});

document.getElementById("fichier-ligne").addEventListener("change", async e => {
  const fichier = e.target.files[0];
  const cible = ligneEnCours;
  e.target.value = "";
  if (!fichier || !cible) return;
  try {
    const blob = await redimensionner(fichier, 160, 160, 0.9);
    const id = await enregistrerImage(blob);
    oublierImageTemporaire(cible.icone);
    cible.icone = id;
    if (!cible.nom.trim()) cible.nom = nomDepuisFichier(fichier.name);
    dessinerLignes();
  } catch (erreur) {
    alert("Impossible de lire cette image.");
  }
});

document.getElementById("btn-lot").addEventListener("click", () =>
  document.getElementById("fichier-lot").click());

document.getElementById("fichier-lot").addEventListener("change", async e => {
  const fichiers = [...e.target.files].sort((a, b) =>
    a.name.localeCompare(b.name, "fr", { numeric: true }));
  e.target.value = "";
  if (fichiers.length === 0) return;

  const type = document.getElementById("type-lot").value.trim();
  const etat = document.getElementById("etat-lot");
  let ajoutes = 0;
  let echecs = 0;

  for (let i = 0; i < fichiers.length; i++) {
    etat.textContent = "Traitement " + (i + 1) + " / " + fichiers.length + "…";
    try {
      const blob = await redimensionner(fichiers[i], 160, 160, 0.9);
      const id = await enregistrerImage(blob);
      collectiblesModele.push({ nom: nomDepuisFichier(fichiers[i].name), groupe: type, icone: id });
      ajoutes++;
    } catch (erreur) {
      echecs++;
    }
  }

  dessinerLignes();
  etat.textContent = ajoutes + " collectible(s) ajouté(s)" +
    (echecs ? ", " + echecs + " fichier(s) illisible(s) ignoré(s)." : ".");
});

/* ---------- Édition d'un jeu existant ---------- */

function remplir(j) {
  document.getElementById("titre-page").textContent = "Modifier un jeu";
  document.getElementById("btn-valider").textContent = "Enregistrer les modifications";
  document.getElementById("titre").value = j.titre;

  const cases = [...document.querySelectorAll('input[name="plateforme"]')];
  const connues = cases.map(c => c.value);
  cases.forEach(c => { c.checked = j.plateformes.includes(c.value); });
  champAutres.value = j.plateformes.filter(p => !connues.includes(p)).join(", ");

  document.getElementById("date").value = j.dateSortie;
  document.getElementById("developpeur").value = j.developpeur === "—" ? "" : j.developpeur;
  document.getElementById("editeur").value = j.editeur === "—" ? "" : j.editeur;
  document.getElementById("genre").value = j.genre === "—" ? "" : j.genre;
  champCover.value = j.cover || "";
  afficherApercuCover();
  selectType.value = j.typeTrophees || "aucun";

  tropheesModele = (j.trophees || []).map(t => ({
    nom: t.nom, description: t.description || "", type: t.type || "bronze"
  }));
  collectiblesModele = (j.collectibles || []).map(c => ({
    nom: c.nom, groupe: c.groupe || "", icone: c.icone || ""
  }));
}

if (idEdition && !jeuEdite) {
  alert("Ce jeu est introuvable.");
  window.location.href = "index.html";
} else if (jeuEdite) {
  remplir(jeuEdite);
}

majBlocTrophees();
dessinerLignes();

/* ---------- Enregistrement ---------- */

formulaire.addEventListener("submit", async e => {
  e.preventDefault();

  const plateformes = plateformesChoisies();
  if (plateformes.length === 0) {
    alert("Choisis au moins une plateforme.");
    return;
  }

  const systeme = selectType.value;

  const trophees = systeme === "aucun"
    ? []
    : tropheesModele
        .filter(t => t.nom.trim())
        .map((t, i) => {
          const element = {
            id: "t" + (i + 1),
            nom: t.nom.trim(),
            description: (t.description || "").trim()
          };
          if (systeme === "playstation") {
            element.type = TYPES_PS.includes(t.type) ? t.type : "bronze";
          }
          return element;
        });

  const collectibles = collectiblesModele
    .filter(c => c.nom.trim() || c.icone)
    .map((c, i) => {
      const element = {
        id: "c" + (i + 1),
        nom: c.nom.trim() || "Collectible " + (i + 1),
        icone: c.icone || "🔹"
      };
      if (c.groupe && c.groupe.trim()) element.groupe = c.groupe.trim();
      return element;
    });

  if (jeuEdite) {
    attribuerIds(trophees, jeuEdite.trophees || [], "t");
    attribuerIds(collectibles, jeuEdite.collectibles || [], "c");
  }

  const jeu = {
    id: jeuEdite ? jeuEdite.id : "jeu-" + Date.now(),
    titre: document.getElementById("titre").value.trim(),
    plateformes: plateformes,
    dateSortie: document.getElementById("date").value,
    developpeur: document.getElementById("developpeur").value.trim() || "—",
    editeur: document.getElementById("editeur").value.trim() || "—",
    genre: document.getElementById("genre").value.trim() || "—",
    cover: champCover.value.trim(),
    typeTrophees: systeme === "aucun" ? null : systeme,
    trophees: trophees.length ? trophees : null,
    collectibles: collectibles.length ? collectibles : null
  };

  const liste = lireJeuxPerso();
  if (jeuEdite) {
    const position = liste.findIndex(j => j.id === jeuEdite.id);
    liste[position] = jeu;
  } else {
    liste.push(jeu);
  }
  ecrireJeuxPerso(liste);

  if (jeuEdite) {
    const gardees = new Set(idsImages(jeu));
    await Promise.all(idsImages(jeuEdite)
      .filter(id => !gardees.has(id))
      .map(id => supprimerImage(id).catch(() => {})));
  }

  window.location.href = jeuEdite
    ? "jeu.html?id=" + encodeURIComponent(jeu.id)
    : "index.html";
});

/* ---------- Espace disponible ---------- */

const infoStockage = document.getElementById("info-stockage");
if (navigator.storage && navigator.storage.persist) {
  navigator.storage.persist();
}
if (navigator.storage && navigator.storage.estimate) {
  navigator.storage.estimate().then(({ usage, quota }) => {
    infoStockage.textContent = "Espace utilisé : " + (usage / 1048576).toFixed(1) +
      " Mo, sur environ " + (quota / 1048576).toFixed(0) + " Mo disponibles.";
  });
}