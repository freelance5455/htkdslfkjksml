import { config } from "dotenv";
import { defineConfig } from "drizzle-kit";

config();

/**
 * Migration config.
 *
 * The connection string is read from the environment so that
 * `npx drizzle-kit push` targets whichever database is configured
 * (local in development, the real instance in production).
 *
 * It was previously hardcoded to localhost, which meant production
 * migrations silently ran against a developer machine and the deployed
 * schema drifted — the root cause of the Share Match failure.
 */
export default defineConfig({
  dialect: "postgresql",
  schema: "./src/db/schema.ts",
  out: "./drizzle",
  dbCredentials: {
    url: process.env.DATABASE_URL ?? "",
  },
});
