package com.vanta.apkcloner

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.File
import java.io.FileInputStream

class MainActivity : Activity() {
    private lateinit var rootStatus: TextView
    private lateinit var list: LinearLayout
    private val purple = Color.rgb(139, 92, 246)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(9, 11, 18)
        window.navigationBarColor = Color.rgb(9, 11, 18)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 30, 24, 24)
            setBackgroundColor(Color.rgb(9, 11, 18))
        }
        val title = TextView(this).apply {
            text = "⧉  APK Cloner ROOT"
            textSize = 25f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        }
        page.addView(title, matchWrap())
        rootStatus = TextView(this).apply {
            textSize = 14f; setTextColor(Color.rgb(196, 181, 253))
            gravity = Gravity.CENTER; setPadding(8, 20, 8, 20)
        }
        page.addView(rootStatus, matchWrap())

        val add = Button(this).apply {
            text = "＋  إضافة ملف APK"
            setTextColor(Color.WHITE); setBackgroundColor(purple)
            setOnClickListener { chooseApk() }
        }
        page.addView(add, matchWrap())

        val installed = Button(this).apply {
            text = "عرض التطبيقات المثبتة"
            setOnClickListener { showInstalledApps() }
        }
        page.addView(installed, matchWrap())

        val heading = TextView(this).apply {
            text = "التطبيقات / الملفات"; textSize = 18f
            setTextColor(Color.WHITE); setPadding(0, 24, 0, 12)
        }
        page.addView(heading, matchWrap())

        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(page)
        checkRoot()
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)

    private fun checkRoot() {
        Thread {
            val result = try {
                val process = ProcessBuilder("su", "-c", "id").redirectErrorStream(true).start()
                val output = process.inputStream.bufferedReader().readText()
                val code = process.waitFor()
                code == 0 && output.contains("uid=0")
            } catch (_: Exception) { false }
            runOnUiThread {
                rootStatus.text = if (result)
                    "● تم اكتشاف Root — تمت الموافقة على فحص su"
                else
                    "● لم يتم منح Root أو Magisk غير متاح"
            }
        }.start()
    }

    private fun chooseApk() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/vnd.android.package-archive"
        }
        startActivityForResult(intent, 100)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == Activity.RESULT_OK) {
            data?.data?.let { uri ->
                addRow("ملف APK محدد", uri.lastPathSegment ?: uri.toString())
            }
        } else if (requestCode == 101 && resultCode == Activity.RESULT_OK) {
            val uri = data?.data
            val source = pendingSource
            if (uri != null && source != null) {
                Thread {
                    val ok = try {
                        contentResolver.openOutputStream(uri)?.use { out ->
                            FileInputStream(File(source)).use { input -> input.copyTo(out) }
                        } ?: error("تعذر فتح ملف الوجهة")
                        true
                    } catch (_: Exception) { false }
                    runOnUiThread {
                        Toast.makeText(this, if (ok) "تم تصدير APK" else "فشل تصدير APK",
                            Toast.LENGTH_LONG).show()
                    }
                }.start()
            }
            pendingSource = null
        }
    }

    private fun showInstalledApps() {
        list.removeAllViews()
        val pm = packageManager
        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { pm.getLaunchIntentForPackage(it.packageName) != null }
            .sortedBy { pm.getApplicationLabel(it).toString().lowercase() }

        for (app in apps) {
            val label = pm.getApplicationLabel(app).toString()
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(8, 12, 8, 12)
            }
            val name = TextView(this).apply {
                text = "$label\n${app.packageName}"
                textSize = 14f; setTextColor(Color.WHITE)
            }
            row.addView(name, LinearLayout.LayoutParams(0, -2, 1f))
            val export = Button(this).apply {
                text = "تصدير APK"
                setOnClickListener { exportApk(app.sourceDir, "$label.apk") }
            }
            row.addView(export)
            list.addView(row)
            val divider = View(this).apply { setBackgroundColor(Color.rgb(40, 47, 64)) }
            list.addView(divider, LinearLayout.LayoutParams(-1, 1))
        }
    }

    private fun exportApk(source: String, suggestedName: String) {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/vnd.android.package-archive"
            putExtra(Intent.EXTRA_TITLE, suggestedName.replace("/", "_"))
        }
        pendingSource = source
        startActivityForResult(intent, 101)
    }

    private var pendingSource: String? = null

    private fun addRow(title: String, subtitle: String) {
        val row = TextView(this).apply {
            text = "📦  $title\n$subtitle"
            textSize = 14f; setTextColor(Color.WHITE); setPadding(10, 14, 10, 14)
        }
        list.addView(row, 0)
    }
}
