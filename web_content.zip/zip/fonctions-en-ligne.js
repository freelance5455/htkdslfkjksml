(function () {
  const estPageVersionEnLigne =
    window.location.pathname.toLowerCase().includes("version-en-ligne");

  const CONFIG_RESEAU = {
    idEcranBlocage: "tc-ecran-blocage",
    idTexteBlocage: "tc-texte-blocage",
    idBoutonConnexion: "tc-btn-retour-connexion",
    idBoutonHorsLigne: "tc-btn-passer-hors-ligne",
    idBoutonVerifier: "tc-btn-verifier-connexion",
    pageConnexion: "connexion-en-ligne.html",
    pageHorsLigne: "index.html",
    cleSession: "tc_session_profil_en_ligne",
    cleSauvegardeSession: "tc_session_secours_reseau",
    urlTestReseau:
      "https://firestore.googleapis.com/v1/projects/trading-commerce/databases/(default)/documents/comptes_trading_commerce?pageSize=1&key=AIzaSyAPEnpD8hfQNBZT1wpjSEh9E_OXsjsNiAU",
    intervalleVerificationMs: 3000
  };

  let verificationEnCours = false;
  let dernierEtatEnLigne = null;

  function sauvegarderSessionAvantCoupure() {
    const sessionActuelle = sessionStorage.getItem(CONFIG_RESEAU.cleSession);
    if (sessionActuelle) {
      sessionStorage.setItem(CONFIG_RESEAU.cleSauvegardeSession, sessionActuelle);
      sessionStorage.removeItem(CONFIG_RESEAU.cleSession);
    }
  }

  function restaurerSessionApresReconnexion() {
    if (!sessionStorage.getItem(CONFIG_RESEAU.cleSession)) {
      const secours = sessionStorage.getItem(CONFIG_RESEAU.cleSauvegardeSession);
      if (secours) {
        sessionStorage.setItem(CONFIG_RESEAU.cleSession, secours);
      }
    }
  }

  function supprimerDoublonsEcran() {
    const tousLesEcrans = document.querySelectorAll("#" + CONFIG_RESEAU.idEcranBlocage);
    if (tousLesEcrans.length > 1) {
      for (let i = 1; i < tousLesEcrans.length; i++) {
        tousLesEcrans[i].remove();
      }
    }
  }

  function preparerElementsBlocage() {
    supprimerDoublonsEcran();
    let ecran = document.getElementById(CONFIG_RESEAU.idEcranBlocage);
    if (ecran) {
      return ecran;
    }

    const titreBlocage = "Vous devez vous connecter";

    const messageBlocage = estPageVersionEnLigne
      ? "La connexion internet est absente ou a été coupée. Vous ne pouvez pas utiliser la version en ligne."
      : "Aucune connexion internet détectée. Vous ne pouvez pas utiliser cette page sans internet.";

    const boutonConnexionHtml = estPageVersionEnLigne
      ? `<button type="button" id="${CONFIG_RESEAU.idBoutonConnexion}" style="display:block;width:100%;padding:13px;margin-bottom:10px;border:none;border-radius:10px;background:#16a34a;color:#ffffff;font-size:1rem;font-weight:bold;cursor:pointer;">
          Aller à la page de connexion
        </button>`
      : "";

    ecran = document.createElement("div");
    ecran.id = CONFIG_RESEAU.idEcranBlocage;
    ecran.style.cssText = [
      "position:fixed",
      "inset:0",
      "background:#0f172a",
      "color:#ffffff",
      "display:none",
      "align-items:center",
      "justify-content:center",
      "padding:24px",
      "z-index:99999",
      "text-align:center",
      "font-family:Arial,sans-serif"
    ].join(";");

    ecran.innerHTML = `
      <div style="max-width:460px;width:100%;background:#1e293b;border:2px solid #ef4444;border-radius:16px;padding:26px 22px;box-shadow:0 20px 45px rgba(0,0,0,0.45);">
        <h2 style="margin:0 0 12px 0;font-size:1.55rem;color:#fca5a5;">${titreBlocage}</h2>
        <p id="${CONFIG_RESEAU.idTexteBlocage}" style="margin:0 0 20px 0;font-size:1rem;line-height:1.5;color:#e2e8f0;">
          ${messageBlocage}
        </p>
        ${boutonConnexionHtml}
        <button type="button" id="${CONFIG_RESEAU.idBoutonHorsLigne}" style="display:block;width:100%;padding:13px;margin-bottom:10px;border:none;border-radius:10px;background:#f59e0b;color:#0f172a;font-size:1rem;font-weight:bold;cursor:pointer;">
          Passer à l'application hors ligne
        </button>
        <button type="button" id="${CONFIG_RESEAU.idBoutonVerifier}" style="display:block;width:100%;padding:12px;border:1px solid #64748b;border-radius:10px;background:#334155;color:#ffffff;font-size:0.96rem;font-weight:bold;cursor:pointer;">
          Vérifier la connexion
        </button>
      </div>
    `;

    document.body.appendChild(ecran);

    const btnConnexion = document.getElementById(CONFIG_RESEAU.idBoutonConnexion);
    if (btnConnexion) {
      btnConnexion.addEventListener("click", function () {
        sessionStorage.removeItem(CONFIG_RESEAU.cleSession);
        sessionStorage.removeItem(CONFIG_RESEAU.cleSauvegardeSession);
        window.location.href = CONFIG_RESEAU.pageConnexion;
      });
    }

    const btnHorsLigne = document.getElementById(CONFIG_RESEAU.idBoutonHorsLigne);
    if (btnHorsLigne) {
      btnHorsLigne.addEventListener("click", function () {
        sessionStorage.removeItem(CONFIG_RESEAU.cleSession);
        sessionStorage.removeItem(CONFIG_RESEAU.cleSauvegardeSession);
        window.location.href = CONFIG_RESEAU.pageHorsLigne;
      });
    }

    const btnVerifier = document.getElementById(CONFIG_RESEAU.idBoutonVerifier);
    if (btnVerifier) {
      btnVerifier.addEventListener("click", function () {
        verifierConnexionReelle(true);
      });
    }

    return ecran;
  }

  function masquerOuAfficherContenuPage(masquer) {
    const ecran = document.getElementById(CONFIG_RESEAU.idEcranBlocage);
    Array.from(document.body.children).forEach(function (enfant) {
      if (enfant === ecran || enfant.tagName === "SCRIPT") {
        return;
      }
      if (!enfant.dataset.tcDisplayPrecedent) {
        enfant.dataset.tcDisplayPrecedent = enfant.style.display || "";
      }
      enfant.style.display = masquer ? "none" : enfant.dataset.tcDisplayPrecedent;
    });
  }

  function appliquerEtatInterface(estConnecte, messagePersonnalise) {
    const ecran = preparerElementsBlocage();
    const texteEl = document.getElementById(CONFIG_RESEAU.idTexteBlocage);

    if (!estConnecte) {
      sauvegarderSessionAvantCoupure();
      if (texteEl) {
        texteEl.textContent =
          messagePersonnalise ||
          (estPageVersionEnLigne
            ? "La connexion internet est absente ou a été coupée. Vous ne pouvez pas utiliser la version en ligne."
            : "Vous devez vous connecter à internet. La connexion est absente ou a été coupée.");
      }
      masquerOuAfficherContenuPage(true);
      ecran.style.setProperty("display", "flex", "important");
    } else {
      restaurerSessionApresReconnexion();
      ecran.style.setProperty("display", "none", "important");
      masquerOuAfficherContenuPage(false);
    }

    if (dernierEtatEnLigne !== estConnecte) {
      dernierEtatEnLigne = estConnecte;
      window.dispatchEvent(
        new CustomEvent("tc:etat-reseau-change", {
          detail: { enLigne: estConnecte }
        })
      );
    }
  }

  async function testerAccesInternetReel() {
    if (!navigator.onLine) {
      return false;
    }

    const controller = new AbortController();
    const timer = setTimeout(function () {
      controller.abort();
    }, 4500);

    try {
      const res = await fetch(CONFIG_RESEAU.urlTestReseau, {
        method: "GET",
        cache: "no-store",
        signal: controller.signal
      });
      clearTimeout(timer);
      return res.ok || res.status === 400 || res.status === 403;
    } catch (e) {
      clearTimeout(timer);
      return false;
    }
  }

  async function verifierConnexionReelle(depuisBouton) {
    if (verificationEnCours) {
      return;
    }
    verificationEnCours = true;

    const btnVerifier = document.getElementById(CONFIG_RESEAU.idBoutonVerifier);
    const texteEl = document.getElementById(CONFIG_RESEAU.idTexteBlocage);

    if (depuisBouton && btnVerifier) {
      btnVerifier.disabled = true;
      btnVerifier.textContent = "Vérification...";
    }

    if (!navigator.onLine) {
      appliquerEtatInterface(false);
      if (depuisBouton && btnVerifier) {
        btnVerifier.disabled = false;
        btnVerifier.textContent = "Vérifier la connexion";
      }
      verificationEnCours = false;
      return;
    }

    const ok = await testerAccesInternetReel();

    if (ok) {
      appliquerEtatInterface(true);
    } else {
      appliquerEtatInterface(
        false,
        "Connexion instable ou sans accès internet réel. Veuillez vérifier votre connexion."
      );
      if (depuisBouton && texteEl) {
        texteEl.textContent =
          "Toujours pas d'accès internet détecté. Réessayez dès que le réseau est actif.";
      }
    }

    if (depuisBouton && btnVerifier) {
      btnVerifier.disabled = false;
      btnVerifier.textContent = "Vérifier la connexion";
    }

    verificationEnCours = false;
  }

  function gererCoupureImmediate() {
    appliquerEtatInterface(false);
  }

  function demarrerSurveillanceReseau() {
    preparerElementsBlocage();

    if (!navigator.onLine) {
      appliquerEtatInterface(false);
    } else {
      verifierConnexionReelle(false);
    }

    window.addEventListener("offline", gererCoupureImmediate);
    window.addEventListener("online", function () {
      verifierConnexionReelle(false);
    });

    setInterval(function () {
      if (!navigator.onLine) {
        appliquerEtatInterface(false);
      } else {
        verifierConnexionReelle(false);
      }
    }, CONFIG_RESEAU.intervalleVerificationMs);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", demarrerSurveillanceReseau);
  } else {
    demarrerSurveillanceReseau();
  }
})();


  (function () {
    const CONFIG_CONNEXION = {
      projectId: "trading-commerce",
      apiKey: "AIzaSyAPEnpD8hfQNBZT1wpjSEh9E_OXsjsNiAU",
      collection: "comptes_trading_commerce",
      cleSessionActive: "tc_session_profil_en_ligne",
      cleSessionPermanente: "tc_session_permanente_en_ligne",
      cleDernierEmail: "tc_dernier_email_en_ligne",
      pageAccueil: "espace-accueil-en-ligne.html"
    };

    function urlDocFirestore(email) {
      return (
        "https://firestore.googleapis.com/v1/projects/" +
        CONFIG_CONNEXION.projectId +
        "/databases/(default)/documents/" +
        CONFIG_CONNEXION.collection +
        "/" +
        encodeURIComponent(email) +
        "?key=" +
        CONFIG_CONNEXION.apiKey
      );
    }

    function lireSessionPermanente() {
      try {
        const brute = localStorage.getItem(CONFIG_CONNEXION.cleSessionPermanente);
        if (!brute) return null;
        const parsed = JSON.parse(brute);
        if (parsed && parsed.email) {
          return parsed;
        }
      } catch (e) {}
      return null;
    }

    async function synchroniserProfilDepuisFirestore(email, infosSaisies) {
      const emailPropre = String(email || "").trim().toLowerCase();
      if (!emailPropre) return null;

      let profil = Object.assign(
        {
          nom: "",
          prenom: "",
          age: "",
          adresse: "",
          ville: "",
          continent: "",
          numero: "",
          email: emailPropre,
          photo: ""
        },
        infosSaisies || {},
        { email: emailPropre }
      );

      const cleEtat = "tc_donnees_completes_" + encodeURIComponent(emailPropre);
      let etatLocal = { profil: profil, entrees: [], historique: [] };

      const localBrut = localStorage.getItem(cleEtat);
      if (localBrut) {
        try {
          const obj = JSON.parse(localBrut);
          if (obj && typeof obj === "object") {
            etatLocal.profil = Object.assign(profil, obj.profil || {}, { email: emailPropre });
            etatLocal.entrees = Array.isArray(obj.entrees) ? obj.entrees : [];
            etatLocal.historique = Array.isArray(obj.historique) ? obj.historique : [];
          }
        } catch (e) {}
      }

      if (navigator.onLine) {
        try {
          const res = await fetch(urlDocFirestore(emailPropre), { method: "GET" });
          if (res.ok) {
            const doc = await res.json();
            const f = doc.fields || {};
            profil = {
              nom: (f.nom && f.nom.stringValue) || etatLocal.profil.nom || "",
              prenom: (f.prenom && f.prenom.stringValue) || etatLocal.profil.prenom || "",
              age: (f.age && f.age.stringValue) || etatLocal.profil.age || "",
              adresse: (f.adresse && f.adresse.stringValue) || etatLocal.profil.adresse || "",
              ville: (f.ville && f.ville.stringValue) || etatLocal.profil.ville || "",
              continent: (f.continent && f.continent.stringValue) || etatLocal.profil.continent || "",
              numero: (f.numero && f.numero.stringValue) || etatLocal.profil.numero || "",
              email: emailPropre,
              photo: etatLocal.profil.photo || ""
            };

            if (f.donneesJson && f.donneesJson.stringValue) {
              try {
                const cloudObj = JSON.parse(f.donneesJson.stringValue);
                if (cloudObj && cloudObj.profil) {
                  profil = Object.assign(profil, cloudObj.profil, { email: emailPropre });
                }
                if (cloudObj && Array.isArray(cloudObj.entrees)) {
                  etatLocal.entrees = cloudObj.entrees;
                }
                if (cloudObj && Array.isArray(cloudObj.historique)) {
                  etatLocal.historique = cloudObj.historique;
                }
              } catch (e) {}
            }
          }
        } catch (e) {}
      }

      etatLocal.profil = profil;
      localStorage.setItem(cleEtat, JSON.stringify(etatLocal));
      localStorage.setItem(
        "tc_profil_fichier_" + encodeURIComponent(emailPropre),
        JSON.stringify(profil)
      );
      localStorage.setItem(CONFIG_CONNEXION.cleDernierEmail, emailPropre);

      return profil;
    }

    async function validerConnexionUnique(email, infosSaisies) {
      const emailPropre = String(email || "").trim().toLowerCase();
      if (!emailPropre) return;

      const profil = await synchroniserProfilDepuisFirestore(emailPropre, infosSaisies);
      const payloadSession = {
        email: emailPropre,
        nom: profil ? profil.nom : "",
        prenom: profil ? profil.prenom : "",
        ville: profil ? profil.ville : "",
        continent: profil ? profil.continent : "",
        connecteUneFois: true,
        connecteLe: new Date().toISOString()
      };

      localStorage.setItem(CONFIG_CONNEXION.cleSessionPermanente, JSON.stringify(payloadSession));
      sessionStorage.setItem(CONFIG_CONNEXION.cleSessionActive, JSON.stringify(payloadSession));

      window.location.href = CONFIG_CONNEXION.pageAccueil;
    }

    // Expose la fonction pour qu'elle puisse être appelée après connexion ou création de compte
    window.TC_ConnexionUnique = {
      valider: validerConnexionUnique,
      synchroniserProfil: synchroniserProfilDepuisFirestore
    };

    // Si l'utilisateur vient de cliquer sur "Se déconnecter", on n'auto-redirige pas
    const params = new URLSearchParams(window.location.search);
    if (params.get("deconnecte") === "1") {
      localStorage.removeItem(CONFIG_CONNEXION.cleSessionPermanente);
      sessionStorage.removeItem(CONFIG_CONNEXION.cleSessionActive);
      return;
    }

    // Connexion automatique si déjà connecté une fois
    const sessionExistante = lireSessionPermanente();
    if (sessionExistante && navigator.onLine) {
      sessionStorage.setItem(
        CONFIG_CONNEXION.cleSessionActive,
        JSON.stringify(sessionExistante)
      );
      window.location.replace(CONFIG_CONNEXION.pageAccueil);
    }
  })();



btnCreerCompteEl.addEventListener("click", function () {
  if (!navigator.onLine) {
    basculerEtatReseau();
    return;
  }
  window.location.href = "creer-compte.html";
});


/* ==========================================================================
   fonctions-en-ligne.js — Gestion intelligente des sessions & rôles en ligne
   Trading Commerce
   ========================================================================== */
(function (global) {
  "use strict";

  const TC_EN_LIGNE_CONFIG = {
    pageConnexion: "connexion.html",
    pageCreationCompte: "creer-compte.html",
    pageVerification: "sign-up.html",
    pageAccueilEnLigne: "espace-accueil-en-ligne.html",
    pageVersionEnLigne: "version-en-ligne.html",
    pageHorsLigne: "index.html",
    cleConnecteLocal: "tc_connecte_en_ligne",
    cleEmailLocal: "tc_user_email",
    cleDernierEmailLocal: "tc_dernier_email_en_ligne",
    cleSession: "tc_session_profil_en_ligne"
  };

  function obtenirNomFichierActuel() {
    const chemin = (global.location && global.location.pathname) || "";
    const morceau = chemin.split("/").pop();
    return (morceau || "index.html").toLowerCase();
  }

  function obtenirSessionEnLigne() {
    let sessionObj = null;
    try {
      const brut = global.sessionStorage.getItem(TC_EN_LIGNE_CONFIG.cleSession);
      if (brut) {
        sessionObj = JSON.parse(brut);
      }
    } catch (_) {
      sessionObj = null;
    }

    const email =
      (sessionObj && sessionObj.email) ||
      global.localStorage.getItem(TC_EN_LIGNE_CONFIG.cleEmailLocal) ||
      global.localStorage.getItem(TC_EN_LIGNE_CONFIG.cleDernierEmailLocal) ||
      "";

    const flagConnecte =
      global.localStorage.getItem(TC_EN_LIGNE_CONFIG.cleConnecteLocal) === "true";

    const estConnecte = Boolean(flagConnecte && email);

    if (estConnecte && !sessionObj) {
      sessionObj = {
        email: email,
        fournisseur: "persistant",
        connecteLe: new Date().toISOString()
      };
      try {
        global.sessionStorage.setItem(TC_EN_LIGNE_CONFIG.cleSession, JSON.stringify(sessionObj));
      } catch (_) {}
    }

    return {
      estConnecte: estConnecte,
      email: email,
      session: sessionObj
    };
  }

  function marquerUtilisateurConnecte(email, fournisseur, extraSession) {
    const emailPropre = String(email || "").trim().toLowerCase();
    if (!emailPropre) return;

    const payload = Object.assign(
      {
        email: emailPropre,
        fournisseur: fournisseur || "compte",
        connecteLe: new Date().toISOString()
      },
      extraSession || {}
    );

    global.localStorage.setItem(TC_EN_LIGNE_CONFIG.cleConnecteLocal, "true");
    global.localStorage.setItem(TC_EN_LIGNE_CONFIG.cleEmailLocal, emailPropre);
    global.localStorage.setItem(TC_EN_LIGNE_CONFIG.cleDernierEmailLocal, emailPropre);

    try {
      global.sessionStorage.setItem(TC_EN_LIGNE_CONFIG.cleSession, JSON.stringify(payload));
    } catch (_) {}
  }

  function deconnecterCompteEnLigne(options) {
    const opts = options || {};
    global.localStorage.removeItem(TC_EN_LIGNE_CONFIG.cleConnecteLocal);
    global.localStorage.removeItem(TC_EN_LIGNE_CONFIG.cleEmailLocal);
    try {
      global.sessionStorage.removeItem(TC_EN_LIGNE_CONFIG.cleSession);
    } catch (_) {}

    if (opts.rediriger !== false) {
      const cible = opts.cible || TC_EN_LIGNE_CONFIG.pageConnexion;
      global.location.replace(cible);
    }
  }

  function estElementConnexion(el) {
    if (!el) return false;
    const id = (el.id || "").toLowerCase();
    const href = (el.getAttribute("href") || "").toLowerCase();
    const texte = (el.textContent || "").trim().toLowerCase();

    if (
      id === "btn-se-connecter" ||
      id === "btn-connexion-google" ||
      id === "btntopconnexion"
    ) {
      return true;
    }

    if (href.includes("connexion.html")) {
      return true;
    }

    if (
      (el.tagName === "BUTTON" || el.tagName === "A") &&
      (texte === "se connecter" || texte === "connexion" || texte === "continuer avec google")
    ) {
      return true;
    }

    return false;
  }

  function mettreAJourBoutonsConnexionSelonEtat() {
    const etat = obtenirSessionEnLigne();
    const candidats = document.querySelectorAll("button, a, [data-role-connexion]");

    candidats.forEach(function (el) {
      if (!estElementConnexion(el)) return;

      if (etat.estConnecte) {
        // Masque ou neutralise l'accès à la page de connexion tant qu'on est connecté
        if (el.id === "btn-se-connecter" || el.id === "btn-connexion-google") {
          const carteForm = el.closest("form") || el.parentElement;
          if (carteForm && carteForm.id === "form-connexion") {
            carteForm.style.display = "none";
          } else {
            el.style.display = "none";
          }
        } else if (el.id === "btnTopConnexion" || (el.getAttribute("href") || "").includes("connexion.html")) {
          const span = el.querySelector("span");
          if (span) {
            span.textContent = "Mon espace";
          } else if (el.tagName === "A") {
            el.textContent = "Mon espace";
          }
          el.setAttribute("href", TC_EN_LIGNE_CONFIG.pageAccueilEnLigne);
        }
      }
    });
  }

  function appliquerRolePageActuelle() {
    const fichier = obtenirNomFichierActuel();
    const etat = obtenirSessionEnLigne();

    // 1. Page de connexion : si déjà connecté, pas besoin de se reconnecter
    if (fichier === TC_EN_LIGNE_CONFIG.pageConnexion && etat.estConnecte) {
      global.location.replace(TC_EN_LIGNE_CONFIG.pageAccueilEnLigne);
      return;
    }

    // 2. Pages protégées en ligne : si pas connecté, renvoie vers connexion.html
    const pagesProtegees = [
      TC_EN_LIGNE_CONFIG.pageAccueilEnLigne,
      TC_EN_LIGNE_CONFIG.pageVersionEnLigne
    ];

    if (pagesProtegees.includes(fichier) && !etat.estConnecte) {
      global.location.replace(TC_EN_LIGNE_CONFIG.pageConnexion);
      return;
    }

    mettreAJourBoutonsConnexionSelonEtat();
  }

  // Intercepte en priorité tout clic sur un bouton de connexion quand déjà connecté
  document.addEventListener(
    "click",
    function (event) {
      const cible = event.target && event.target.closest("button, a, [data-role-connexion]");
      if (!cible || !estElementConnexion(cible)) return;

      const etat = obtenirSessionEnLigne();
      if (etat.estConnecte) {
        event.preventDefault();
        event.stopImmediatePropagation();
        global.location.href = TC_EN_LIGNE_CONFIG.pageAccueilEnLigne;
      }
    },
    true
  );

  // Empêche la soumission du formulaire de connexion si déjà connecté
  document.addEventListener(
    "submit",
    function (event) {
      const form = event.target;
      if (form && form.id === "form-connexion") {
        const etat = obtenirSessionEnLigne();
        if (etat.estConnecte) {
          event.preventDefault();
          event.stopImmediatePropagation();
          global.location.href = TC_EN_LIGNE_CONFIG.pageAccueilEnLigne;
        }
      }
    },
    true
  );

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", appliquerRolePageActuelle);
  } else {
    appliquerRolePageActuelle();
  }

  global.TC_EnLigne = {
    config: TC_EN_LIGNE_CONFIG,
    obtenirSession: obtenirSessionEnLigne,
    marquerConnecte: marquerUtilisateurConnecte,
    deconnecter: deconnecterCompteEnLigne,
    appliquerRole: appliquerRolePageActuelle
  };
})(window);
/* ==========================================================================
   fonctions-en-ligne.js — Gestion intelligente des sessions & rôles en ligne
   Trading Commerce
   ========================================================================== */
(function (global) {
  "use strict";

  const TC_EN_LIGNE_CONFIG = {
    pageConnexion: "connexion.html",
    pageCreationCompte: "creer-compte.html",
    pageVerification: "sign-up.html",
    pageAccueilEnLigne: "espace-accueil-en-ligne.html",
    pageVersionEnLigne: "version-en-ligne.html",
    pageHorsLigne: "index.html",
    cleConnecteLocal: "tc_connecte_en_ligne",
    cleEmailLocal: "tc_user_email",
    cleDernierEmailLocal: "tc_dernier_email_en_ligne",
    cleSession: "tc_session_profil_en_ligne"
  };

  function obtenirNomFichierActuel() {
    const chemin = (global.location && global.location.pathname) || "";
    const morceau = chemin.split("/").pop();
    return (morceau || "index.html").toLowerCase();
  }

  function obtenirSessionEnLigne() {
    let sessionObj = null;
    try {
      const brut = global.sessionStorage.getItem(TC_EN_LIGNE_CONFIG.cleSession);
      if (brut) {
        sessionObj = JSON.parse(brut);
      }
    } catch (_) {
      sessionObj = null;
    }

    const email =
      (sessionObj && sessionObj.email) ||
      global.localStorage.getItem(TC_EN_LIGNE_CONFIG.cleEmailLocal) ||
      global.localStorage.getItem(TC_EN_LIGNE_CONFIG.cleDernierEmailLocal) ||
      "";

    const flagConnecte =
      global.localStorage.getItem(TC_EN_LIGNE_CONFIG.cleConnecteLocal) === "true";

    const estConnecte = Boolean(flagConnecte && email);

    if (estConnecte && !sessionObj) {
      sessionObj = {
        email: email,
        fournisseur: "persistant",
        connecteLe: new Date().toISOString()
      };
      try {
        global.sessionStorage.setItem(TC_EN_LIGNE_CONFIG.cleSession, JSON.stringify(sessionObj));
      } catch (_) {}
    }

    return {
      estConnecte: estConnecte,
      email: email,
      session: sessionObj
    };
  }

  function marquerUtilisateurConnecte(email, fournisseur, extraSession) {
    const emailPropre = String(email || "").trim().toLowerCase();
    if (!emailPropre) return;

    const payload = Object.assign(
      {
        email: emailPropre,
        fournisseur: fournisseur || "compte",
        connecteLe: new Date().toISOString()
      },
      extraSession || {}
    );

    global.localStorage.setItem(TC_EN_LIGNE_CONFIG.cleConnecteLocal, "true");
    global.localStorage.setItem(TC_EN_LIGNE_CONFIG.cleEmailLocal, emailPropre);
    global.localStorage.setItem(TC_EN_LIGNE_CONFIG.cleDernierEmailLocal, emailPropre);

    try {
      global.sessionStorage.setItem(TC_EN_LIGNE_CONFIG.cleSession, JSON.stringify(payload));
    } catch (_) {}
  }

  function deconnecterCompteEnLigne(options) {
    const opts = options || {};
    global.localStorage.removeItem(TC_EN_LIGNE_CONFIG.cleConnecteLocal);
    global.localStorage.removeItem(TC_EN_LIGNE_CONFIG.cleEmailLocal);
    try {
      global.sessionStorage.removeItem(TC_EN_LIGNE_CONFIG.cleSession);
    } catch (_) {}

    if (opts.rediriger !== false) {
      const cible = opts.cible || TC_EN_LIGNE_CONFIG.pageConnexion;
      global.location.replace(cible);
    }
  }

  function estElementConnexion(el) {
    if (!el) return false;
    const id = (el.id || "").toLowerCase();
    const href = (el.getAttribute("href") || "").toLowerCase();
    const texte = (el.textContent || "").trim().toLowerCase();

    if (
      id === "btn-se-connecter" ||
      id === "btn-connexion-google" ||
      id === "btntopconnexion"
    ) {
      return true;
    }

    if (href.includes("connexion.html")) {
      return true;
    }

    if (
      (el.tagName === "BUTTON" || el.tagName === "A") &&
      (texte === "se connecter" || texte === "connexion" || texte === "continuer avec google")
    ) {
      return true;
    }

    return false;
  }

  function mettreAJourBoutonsConnexionSelonEtat() {
    const etat = obtenirSessionEnLigne();
    const candidats = document.querySelectorAll("button, a, [data-role-connexion]");

    candidats.forEach(function (el) {
      if (!estElementConnexion(el)) return;

      if (etat.estConnecte) {
        // Masque ou neutralise l'accès à la page de connexion tant qu'on est connecté
        if (el.id === "btn-se-connecter" || el.id === "btn-connexion-google") {
          const carteForm = el.closest("form") || el.parentElement;
          if (carteForm && carteForm.id === "form-connexion") {
            carteForm.style.display = "none";
          } else {
            el.style.display = "none";
          }
        } else if (el.id === "btnTopConnexion" || (el.getAttribute("href") || "").includes("connexion.html")) {
          const span = el.querySelector("span");
          if (span) {
            span.textContent = "Mon espace";
          } else if (el.tagName === "A") {
            el.textContent = "Mon espace";
          }
          el.setAttribute("href", TC_EN_LIGNE_CONFIG.pageAccueilEnLigne);
        }
      }
    });
  }

  function appliquerRolePageActuelle() {
    const fichier = obtenirNomFichierActuel();
    const etat = obtenirSessionEnLigne();

    // 1. Page de connexion : si déjà connecté, pas besoin de se reconnecter
    if (fichier === TC_EN_LIGNE_CONFIG.pageConnexion && etat.estConnecte) {
      global.location.replace(TC_EN_LIGNE_CONFIG.pageAccueilEnLigne);
      return;
    }

    // 2. Pages protégées en ligne : si pas connecté, renvoie vers connexion.html
    const pagesProtegees = [
      TC_EN_LIGNE_CONFIG.pageAccueilEnLigne,
      TC_EN_LIGNE_CONFIG.pageVersionEnLigne
    ];

    if (pagesProtegees.includes(fichier) && !etat.estConnecte) {
      global.location.replace(TC_EN_LIGNE_CONFIG.pageConnexion);
      return;
    }

    mettreAJourBoutonsConnexionSelonEtat();
  }

  // Intercepte en priorité tout clic sur un bouton de connexion quand déjà connecté
  document.addEventListener(
    "click",
    function (event) {
      const cible = event.target && event.target.closest("button, a, [data-role-connexion]");
      if (!cible || !estElementConnexion(cible)) return;

      const etat = obtenirSessionEnLigne();
      if (etat.estConnecte) {
        event.preventDefault();
        event.stopImmediatePropagation();
        global.location.href = TC_EN_LIGNE_CONFIG.pageAccueilEnLigne;
      }
    },
    true
  );

  // Empêche la soumission du formulaire de connexion si déjà connecté
  document.addEventListener(
    "submit",
    function (event) {
      const form = event.target;
      if (form && form.id === "form-connexion") {
        const etat = obtenirSessionEnLigne();
        if (etat.estConnecte) {
          event.preventDefault();
          event.stopImmediatePropagation();
          global.location.href = TC_EN_LIGNE_CONFIG.pageAccueilEnLigne;
        }
      }
    },
    true
  );

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", appliquerRolePageActuelle);
  } else {
    appliquerRolePageActuelle();
  }

  global.TC_EnLigne = {
    config: TC_EN_LIGNE_CONFIG,
    obtenirSession: obtenirSessionEnLigne,
    marquerConnecte: marquerUtilisateurConnecte,
    deconnecter: deconnecterCompteEnLigne,
    appliquerRole: appliquerRolePageActuelle
  };
})(window);
