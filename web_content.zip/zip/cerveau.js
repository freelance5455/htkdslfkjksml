/* ====================================================================================
   TRADING COMMERCE - CERVEAU.JS (MOTEUR LOGIQUE GLOBAL ET AVANCÉ)
   ==================================================================================== */

(function (window) {
    'use strict';

    // 1. DICTIONNAIRE GLOBAL DE TRADUCTION ET DES LIBELLÉS DE L'APPLICATION
    const TRADUCTIONS_APP = {
        fr: {
            appTitle: "Trading Commerce",
            menuTitle: "Menu Principal",
            langLbl: "🌐 Langue / Language :",
            mHome: "Accueil",
            mClients: "Profils Clients",
            mCalc: "Calculatrices & Devises",
            mProfil: "Mon Profil",
            mSettings: "Paramètres & Style",
            mSync: "Synchronisation QR",
            mClose: "Fermer le menu",
            online: "● En ligne",
            formTitle: "Enregistrer un mouvement",
            namePh: "Nom du client *",
            waPh: "Numéro WhatsApp (optionnel)",
            optCredit: "📥 Il a pris crédit (+)",
            optRepay: "📤 Il a remboursé (-)",
            optAdvance: "💵 Il a donné un peu d'avance (-)",
            optFinish: "✅ Règlement total (0)",
            amtPh: "Montant *",
            btnSave: "Enregistrer & Voir Profil",
            navAcc: "Accueil",
            navCli: "Clients",
            navCal: "Calc",
            navShare: "Partager",
            alertMsg: "Attention : Mets le nom et un montant correct !",
            errCalc: "Erreur de calcul",
            convTitle: "🌍 TOUT L'ARGENT DU MONDE ENTIER"
        },
        en: {
            appTitle: "Trading Commerce",
            menuTitle: "Main Menu",
            langLbl: "🌐 Language / Langue :",
            mHome: "Home",
            mClients: "Client Profiles",
            mCalc: "Calculators & Currencies",
            mProfil: "My Profile",
            mSettings: "Settings & Style",
            mSync: "QR Sync",
            mClose: "Close Menu",
            online: "● Online",
            formTitle: "Record a Movement",
            namePh: "Client Name *",
            waPh: "WhatsApp Number (optional)",
            optCredit: "📥 Took Credit (+)",
            optRepay: "📤 Repaid (-)",
            optAdvance: "💵 Advanced Payment (-)",
            optFinish: "✅ Full Payment (0)",
            amtPh: "Amount *",
            btnSave: "Save & View Profile",
            navAcc: "Home",
            navCli: "Clients",
            navCal: "Calc",
            navShare: "Share",
            alertMsg: "Warning: Please enter the name and a valid amount!",
            errCalc: "Calculation Error",
            convTitle: "🌍 ALL THE MONEY IN THE WORLD"
        },
        ar: {
            appTitle: "تجارة التداول",
            menuTitle: "القائمة الرئيسية",
            langLbl: "🌐 اللغة / Language:",
            mHome: "الرئيسية",
            mClients: "ملفات العملاء",
            mCalc: "الآلات الحاسبة والعملات",
            mProfil: "ملفي الشخصي",
            mSettings: "الإعدادات والنمط",
            mSync: "مزامنة QR",
            mClose: "إغلاق القائمة",
            online: "● متصل",
            formTitle: "تسجيل حركة",
            namePh: "اسم العميل *",
            waPh: "رقم واتساب (اختياري)",
            optCredit: "📥 أخذ كريدي/دين (+)",
            optRepay: "📤 سداد (-)",
            optAdvance: "💵 دفعة مقدمة (-)",
            optFinish: "✅ تسوية كاملة (0)",
            amtPh: "المبلغ *",
            btnSave: "حفظ وعرض الملف",
            navAcc: "الرئيسية",
            navCli: "العملاء",
            navCal: "حاسبة",
            navShare: "مشاركة",
            alertMsg: "تنبيه: أدخل الاسم والمبلغ بشكل صحيح!",
            errCalc: "خطأ في الحساب",
            convTitle: "🌍 كل أموال العالم"
        },
        zh: {
            appTitle: "贸易商业",
            menuTitle: "主菜单",
            langLbl: "🌐 语言 / Language:",
            mHome: "首页",
            mClients: "客户档案",
            mCalc: "计算器与货币",
            mProfil: "个人资料",
            mSettings: "设置与样式",
            mSync: "二维码同步",
            mClose: "关闭菜单",
            online: "● 在线",
            formTitle: "记录交易",
            namePh: "客户姓名 *",
            waPh: "WhatsApp 号码（可选）",
            optCredit: "📦 记账欠款 (+)",
            optRepay: "💵 还款 (-)",
            optAdvance: "💵 预付款 (-)",
            optFinish: "✅ 结清 (0)",
            amtPh: "金额 *",
            btnSave: "保存并查看资料",
            navAcc: "首页",
            navCli: "客户",
            navCal: "计算",
            navShare: "分享",
            alertMsg: "警告：请输入姓名和正确的金额！",
            errCalc: "计算错误",
            convTitle: "🌍 全世界的货币"
        }
    };

    // 2. TABLEAU DE TAUX DE CHANGE DE TOUTES LES MONNAIES DU MONDE (BASÉ SUR LE DOLLAR US)
    const TAUX_CHANGE_MONDE = {
        'USD': 1.0, 'EUR': 0.92, 'GBP': 0.79, 'CHF': 0.90, 'CAD': 1.36, 'AUD': 1.50, 'NZD': 1.63,
        'CNY': 7.20, 'JPY': 155.0, 'INR': 83.0, 'KRW': 1350.0, 'SGD': 1.35, 'HKD': 7.82,
        'THB': 36.5, 'IDR': 16000.0, 'MYR': 4.70, 'PHP': 56.0, 'VND': 25400.0, 'PKR': 278.0, 'BDT': 117.0,
        'XOF': 605.0, 'XAF': 605.0, 'GNF': 8600.0, 'NGN': 1450.0, 'GHS': 15.0, 'ZAR': 18.5,
        'KES': 130.0, 'MAD': 10.0, 'DZD': 134.0, 'TND': 3.12, 'EGP': 47.5, 'AOA': 835.0,
        'ETB': 57.0, 'UGX': 3800.0, 'RWF': 1300.0, 'BRL': 5.15, 'MXN': 17.0, 'ARS': 880.0,
        'COP': 3900.0, 'CLP': 950.0, 'PEN': 3.70, 'AED': 3.67, 'SAR': 3.75, 'QAR': 3.64, 'ILS': 3.70,
        'SEK': 10.8, 'NOK': 10.6, 'DKK': 6.88, 'PLN': 4.0, 'RUB': 91.0, 'UAH': 40.0, 'TRY': 32.2
    };

    // 3. OBJET CENTRAL DU CERVEAU (LOGIQUE AVANCÉE)
    window.CerveauApp = {

        // Initialisation du système au démarrage de chaque page
        init: function () {
            let langueActuelle = localStorage.getItem('tc_langue') || 'fr';
            this.appliquerDirectionLangue(langueActuelle);
            this.verifierIntegriteStockage();
            console.log("Cerveau.js - Moteur chargé et optimisé sans latence.");
        },

        // Gestion automatique de l'affichage de droite à gauche (RTL) pour l'arabe
        appliquerDirectionLangue: function (lang) {
            if (lang === 'ar') {
                document.dir = 'rtl';
            } else {
                document.dir = 'ltr';
            }
        },

        // Transformation automatique des chiffres occidentaux en chiffres arabes orientaux (٠, ١, ٢, ٣...)
        formaterChiffresArabe: function (texte) {
            let lang = localStorage.getItem('tc_langue') || 'fr';
            if (lang !== 'ar') return texte;
            const mapChiffres = {'0':'٠','1':'١','2':'٢','3':'٣','4':'٤','5':'٥','6':'٦','7':'٧','8':'٨','9':'٩'};
            return texte.toString().replace(/[0-9]/g, match => mapChiffres[match]);
        },

        // Vérification et initialisation des données locales
        verifierIntegriteStockage: function () {
            if (!localStorage.getItem('tc_clients')) {
                localStorage.setItem('tc_clients', JSON.stringify([]));
            }
            if (!localStorage.getItem('tc_boutique')) {
                localStorage.setItem('tc_boutique', 'Trading Commerce');
            }
        },

        // Récupérer la liste complète des clients de manière sécurisée
        recupererClients: function () {
            try {
                return JSON.parse(localStorage.getItem('tc_clients')) || [];
            } catch (e) {
                console.error("Erreur de lecture des clients :", e);
                return [];
            }
        },

        // Enregistrer un mouvement de crédit ou de remboursement avec mise à jour du solde
        enregistrerMouvementClient: function (nomClient, numeroWhatsapp, typeOperation, montantValeur, codeDevise) {
            if (!nomClient || isNaN(montantValeur) || montantValeur <= 0) {
                return { succes: false, message: "Nom ou montant invalide." };
            }

            let clients = this.recupererClients();
            let clientExistant = clients.find(c => c.nom.toLowerCase() === nomClient.toLowerCase());

            let maintenant = new Date();
            let dateExacte = maintenant.toLocaleDateString() + " à " + maintenant.toLocaleTimeString();

            let nouveauMouvement = {
                action: typeOperation,
                montant: montantValeur,
                date: dateExacte
            };

            if (clientExistant) {
                let ancienSolde = parseFloat(clientExistant.solde || 0);

                if (typeOperation.includes("crédit") || typeOperation.includes("pris")) {
                    clientExistant.solde = ancienSolde + montantValeur;
                } else if (typeOperation.includes("remboursé") || typeOperation.includes("avance")) {
                    clientExistant.solde = ancienSolde - montantValeur;
                    if (clientExistant.solde < 0) clientExistant.solde = 0;
                } else if (typeOperation.includes("fini") || typeOperation.includes("total")) {
                    clientExistant.solde = 0;
                }

                if (!clientExistant.mouvements) clientExistant.mouvements = [];
                clientExistant.mouvements.push(nouveauMouvement);
                clientExistant.devise = codeDevise;
                if (numeroWhatsapp) clientExistant.whatsapp = numeroWhatsapp;

            } else {
                let soldeInitial = (typeOperation.includes("crédit") || typeOperation.includes("pris")) ? montantValeur : 0;
                clients.push({
                    nom: nomClient,
                    whatsapp: numeroWhatsapp || "Pas de numéro",
                    solde: soldeInitial,
                    devise: codeDevise,
                    mouvements: [nouveauMouvement]
                });
            }

            localStorage.setItem('tc_clients', JSON.stringify(clients));
            return { succes: true, message: "Mouvement enregistré avec succès !" };
        },

        // Convertisseur lourd multi-devises mondial
        convertirMonnaieMondiale: function (montant, deviseSource, deviseCible) {
            let montantNum = parseFloat(montant);
            if (isNaN(montantNum)) return 0;

            let tauxSrc = TAUX_CHANGE_MONDE[deviseSource] || 1.0;
            let tauxCib = TAUX_CHANGE_MONDE[deviseCible] || 1.0;

            let montantEnUSD = montantNum / tauxSrc;
            let resultatConverti = montantEnUSD * tauxCib;
            return resultatConverti.toFixed(2);
        },

        // Moteur de recherche global à travers toute l'application et les clients
        rechercherDansApplication: function (termeRecherche) {
            let query = termeRecherche.toLowerCase().trim();
            if (!query) return [];

            let resultatsFiltres = [];
            let pagesDisponibles = [
                { nom: "Profils Clients", url: "client.html", mots: ["client", "profil", "dette", "credit"] },
                { nom: "Calculatrices & Devises", url: "calculatrices.html", mots: ["calc", "calculatrice", "monnaie", "argent"] },
                { nom: "Paramètres & Style", url: "settings.html", mots: ["parametre", "reglages", "style"] },
                { nom: "Mon Profil", url: "modul2.html", mots: ["profil", "nom"] },
                { nom: "Synchronisation QR", url: "QRCode.html", mots: ["qr", "sync", "partager"] }
            ];

            pagesDisponibles.forEach(p => {
                if (p.nom.toLowerCase().includes(query) || p.mots.some(m => m.includes(query))) {
                    resultatsFiltres.push({ texte: `⚙️ Aller vers : ${p.nom}`, url: p.url });
                }
            });

            let clients = this.recupererClients();
            clients.forEach(c => {
                if (c.nom.toLowerCase().includes(query) || (c.whatsapp && c.whatsapp.includes(query))) {
                    resultatsFiltres.push({ texte: `👤 Client : ${c.nom} (${c.solde} ${c.devise})`, url: "client.html" });
                }
            });

            return resultatsFiltres;
        }

    };

    // Lancement automatique et instantané du cerveau dès que le document HTML est prêt
    document.addEventListener('DOMContentLoaded', function () {
        window.CerveauApp.init();
    });

})(window);

/* =========================================================
   BLOC 1 (CLOUD) — LOGIQUE CERVEAU.JS
   ========================================================= */
(function () {
  // [ESPACE URL DU SERVEUR MODIFIABLE]
  const URL_TEST_CLOUD = "https://httpbin.org/get";

  const etatEl = document.getElementById("cloud-etat");
  const msgEl = document.getElementById("cloud-message");
  const btnTester = document.getElementById("btn-tester-cloud");
  const btnVider = document.getElementById("btn-vider-cloud");

  function afficherMessage(texte) {
    if (!msgEl) return;
    msgEl.textContent = texte;
  }

  function mettreAJourEtatReseau() {
    if (!etatEl) return;
    if (navigator.onLine) {
      etatEl.textContent = "En ligne";
      etatEl.classList.add("est-en-ligne");
    } else {
      etatEl.textContent = "Hors ligne";
      etatEl.classList.remove("est-en-ligne");
    }
  }

  async function testerServeur() {
    mettreAJourEtatReseau();
    if (!navigator.onLine) {
      afficherMessage("Pas de connexion internet sur l'appareil.");
      return;
    }

    afficherMessage("Test en cours...");
    try {
      const reponse = await fetch(URL_TEST_CLOUD, { cache: "no-store" });
      if (reponse.ok) {
        afficherMessage("Serveur en ligne accessible (OK).");
      } else {
        afficherMessage("Le serveur a répondu avec une erreur : " + reponse.status);
      }
    } catch (e) {
      afficherMessage("Impossible de joindre le serveur en ligne.");
    }
  }

  if (btnTester) {
    btnTester.addEventListener("click", testerServeur);
  }

  if (btnVider) {
    btnVider.addEventListener("click", function () {
      afficherMessage("Message effacé.");
    });
  }

  window.addEventListener("online", function () {
    mettreAJourEtatReseau();
    afficherMessage("Connexion internet revenue.");
  });

  window.addEventListener("offline", function () {
    mettreAJourEtatReseau();
    afficherMessage("Connexion internet coupée.");
  });

  mettreAJourEtatReseau();
})();
/* =========================================================
   FIN BLOC 1 (CLOUD) — LOGIQUE CERVEAU.JS
   ========================================================= */

/* =========================================================
   BLOC 2 : LABEL INTELLIGENT, ANIMATIONS & REDIRECTION EN LIGNE
   ========================================================= */
(function () {
  // [ESPACE NOMS DE PAGES, CLÉS & TEXTES MODIFIABLES]
  const PAGE_CONNEXION_EN_LIGNE = "connexion-en-ligne.html";
  const PAGE_BASE_EN_LIGNE = "version-en-ligne.html";
  const CLE_SESSION_PROFIL_EN_LIGNE = "tc_session_profil_en_ligne";
  const TEXTE_EN_LIGNE = "En ligne";
  const TEXTE_HORS_LIGNE = "On n'est pas en ligne";
  const MESSAGE_HORS_LIGNE = "Veuillez vous connecter au réseau";

  function getRefs() {
    return {
      blocEtat: document.getElementById("tc-cadenas-jaune-ligne"),
      labelEtat: document.getElementById("tc-label-intelligent"),
      texteEtat: document.getElementById("tc-texte-intelligent"),
      boutonLigne: document.getElementById("tc-bouton-unique-ligne"),
      labelErreurBas: document.getElementById("tc-label-erreur-bas")
    };
  }

  function estEnLigneActuellement() {
    return Boolean(navigator.onLine);
  }

  function aUnProfilConnecte() {
    try {
      const brut = sessionStorage.getItem(CLE_SESSION_PROFIL_EN_LIGNE);
      if (!brut) return false;
      const data = JSON.parse(brut);
      return Boolean(data && data.email);
    } catch (e) {
      return false;
    }
  }

  function obtenirPageCibleEnLigne() {
    return aUnProfilConnecte() ? PAGE_BASE_EN_LIGNE : PAGE_CONNEXION_EN_LIGNE;
  }

  function mettreAJourLabelIntelligent() {
    const { blocEtat, labelEtat, texteEtat, labelErreurBas } = getRefs();
    const enLigne = estEnLigneActuellement();

    if (blocEtat) {
      blocEtat.classList.toggle("est-en-ligne", enLigne);
      blocEtat.classList.toggle("est-hors-ligne", !enLigne);
    }

    if (labelEtat) {
      labelEtat.classList.toggle("est-en-ligne", enLigne);
      labelEtat.classList.toggle("est-hors-ligne", !enLigne);
    }

    if (texteEtat) {
      texteEtat.textContent = enLigne ? TEXTE_EN_LIGNE : TEXTE_HORS_LIGNE;
    }

    if (enLigne && labelErreurBas) {
      labelErreurBas.textContent = "";
    }
  }

  document.addEventListener("click", function (event) {
    const btn = event.target.closest("#tc-bouton-unique-ligne");
    if (!btn) return;

    event.preventDefault();
    event.stopImmediatePropagation();

    const { labelErreurBas } = getRefs();
    const enLigne = estEnLigneActuellement();

    mettreAJourLabelIntelligent();

    if (!enLigne) {
      if (labelErreurBas) {
        labelErreurBas.textContent = MESSAGE_HORS_LIGNE;
      }
      return;
    }

    if (labelErreurBas) {
      labelErreurBas.textContent = "";
    }

    window.location.href = obtenirPageCibleEnLigne();
  }, true);

  window.addEventListener("online", mettreAJourLabelIntelligent);
  window.addEventListener("offline", mettreAJourLabelIntelligent);

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", mettreAJourLabelIntelligent);
  } else {
    mettreAJourLabelIntelligent();
  }
})();
/* =========================================================
   FIN BLOC 2 : LABEL INTELLIGENT, ANIMATIONS & REDIRECTION EN LIGNE
   ========================================================= */

/* =========================================================
   CADENAS CONNEXION VIA ICONE GOOGLE — CERVEAU.JS
   ========================================================= */
(function () {
  // [ESPACE CLIENT ID GOOGLE OAUTH MODIFIABLE SI DÉPLOYÉ EN LIGNE]
  const GOOGLE_CLIENT_ID = "";
  const CLE_PROFIL_ACTIF = "tc_profil_email_actif";
  const CLE_DONNEES_PROFILS = "tc_profils_trading_commerce";

  function connecterEmailProfil(emailBrut) {
    const email = String(emailBrut || "").trim().toLowerCase();
    if (!email) return;

    let profils = {};
    try {
      profils = JSON.parse(localStorage.getItem(CLE_DONNEES_PROFILS) || "{}");
    } catch (e) {
      profils = {};
    }

    if (!profils[email]) {
      profils[email] = {
        email: email,
        creeLe: new Date().toLocaleString("fr-FR"),
        actions: []
      };
    }

    profils[email].actions.push({
      date: new Date().toLocaleTimeString("fr-FR"),
      libelle: "Connexion via Google",
      mode: navigator.onLine ? "Hors ligne + En ligne" : "Hors ligne"
    });

    localStorage.setItem(CLE_DONNEES_PROFILS, JSON.stringify(profils));
    localStorage.setItem(CLE_PROFIL_ACTIF, email);

    const inputEmail = document.getElementById("tc-input-email");
    const form = document.getElementById("tc-form-connexion-email");
    if (inputEmail && form) {
      inputEmail.value = email;
      form.dispatchEvent(new Event("submit", { cancelable: true }));
    }
  }

  function afficherListeEmailsEnregistres(conteneur) {
    let profils = {};
    try {
      profils = JSON.parse(localStorage.getItem(CLE_DONNEES_PROFILS) || "{}");
    } catch (e) {
      profils = {};
    }

    const emails = Object.keys(profils);
    conteneur.innerHTML = "";

    if (emails.length === 0) {
      const vide = document.createElement("div");
      vide.style.fontSize = "0.78rem";
      vide.style.color = "#475569";
      vide.textContent = "Aucune adresse e-mail enregistrée. Saisis-en une ci-dessus.";
      conteneur.appendChild(vide);
      return;
    }

    emails.forEach(function (email) {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "tc-item-email-google";
      btn.innerHTML = "<span>" + email + "</span><span>Connecter</span>";
      btn.addEventListener("click", function () {
        conteneur.classList.add("tc-cache");
        connecterEmailProfil(email);
      });
      conteneur.appendChild(btn);
    });
  }

  function initialiserBoutonGoogle() {
    const btnGoogle = document.getElementById("tc-btn-icone-google");
    const listeEmails = document.getElementById("tc-liste-emails-google");
    if (!btnGoogle || !listeEmails) return;

    btnGoogle.addEventListener("click", function () {
      if (GOOGLE_CLIENT_ID && window.google && window.google.accounts && window.google.accounts.oauth2) {
        const client = window.google.accounts.oauth2.initTokenClient({
          client_id: GOOGLE_CLIENT_ID,
          scope: "email profile openid",
          callback: function (resp) {
            if (resp && resp.access_token) {
              fetch("https://www.googleapis.com/oauth2/v3/userinfo", {
                headers: { Authorization: "Bearer " + resp.access_token }
              })
                .then(function (r) { return r.json(); })
                .then(function (info) {
                  if (info && info.email) {
                    connecterEmailProfil(info.email);
                  }
                });
            }
          }
        });
        client.requestAccessToken();
        return;
      }

      afficherListeEmailsEnregistres(listeEmails);
      listeEmails.classList.toggle("tc-cache");
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initialiserBoutonGoogle);
  } else {
    initialiserBoutonGoogle();
  }
})();
/* =========================================================
   FIN CADENAS CONNEXION VIA ICONE GOOGLE — CERVEAU.JS
   ========================================================= */

   
   (function () {
    const CLE_PROFILS = "tc_profils_clients";
    const CLE_STATS = "tc_stats_globales";
    const CLE_DERNIER_CLIENT = "tc_dernier_client";
    const CLE_DERNIER_MOUVEMENT = "tc_dernier_mouvement";
    const CLE_FLUX_LIVE = "tc_flux_trading_live";

    function tcFormaterMontant(val) {
        return Number(val || 0).toLocaleString("fr-FR", { maximumFractionDigits: 2 });
    }

    function tcDateCourte() {
        const d = new Date();
        return d.toLocaleDateString("fr-FR") + " " + d.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
    }

    function tcLireFluxLive() {
        try {
            const raw = JSON.parse(localStorage.getItem(CLE_FLUX_LIVE) || '{"montants":[],"descentes":[]}');
            return {
                montants: Array.isArray(raw.montants) ? raw.montants : [],
                descentes: Array.isArray(raw.descentes) ? raw.descentes : []
            };
        } catch (e) {
            return { montants: [], descentes: [] };
        }
    }

    function tcSauvegarderFluxLive(flux) {
        localStorage.setItem(CLE_FLUX_LIVE, JSON.stringify({
            montants: (flux.montants || []).slice(0, 25),
            descentes: (flux.descentes || []).slice(0, 25)
        }));
    }

    function tcLireDonneesClients() {
        let profils = [];
        try {
            const raw = JSON.parse(localStorage.getItem(CLE_PROFILS) || "[]");
            profils = Array.isArray(raw) ? raw : [];
        } catch (e) {
            profils = [];
        }

        const totalEmprunts = profils.reduce((s, c) => s + (Number(c.totalEmprunt) || 0), 0);
        const totalRembourses = profils.reduce((s, c) => s + (Number(c.totalRembourse) || 0), 0);
        const resteAPayer = Math.max(0, totalEmprunts - totalRembourses);
        const soldeNet = totalRembourses - totalEmprunts;

        return {
            profils,
            fluxLive: tcLireFluxLive(),
            dernierClient: localStorage.getItem(CLE_DERNIER_CLIENT) || "",
            dernierMouvement: localStorage.getItem(CLE_DERNIER_MOUVEMENT) || "",
            stats: {
                totalClients: profils.length,
                totalEmprunts,
                totalRembourses,
                resteAPayer,
                soldeNet
            }
        };
    }

    function tcCalculerEtSauvegarderStats(profils) {
        const totalEmprunts = profils.reduce((s, c) => s + (Number(c.totalEmprunt) || 0), 0);
        const totalRembourses = profils.reduce((s, c) => s + (Number(c.totalRembourse) || 0), 0);
        const resteAPayer = Math.max(0, totalEmprunts - totalRembourses);
        const soldeNet = totalRembourses - totalEmprunts;

        const stats = {
            totalClients: profils.length,
            totalEmprunts,
            totalRembourses,
            resteAPayer,
            soldeNet,
            misAJourLe: tcDateCourte()
        };

        localStorage.setItem(CLE_STATS, JSON.stringify(stats));
        return stats;
    }

    function tcEnregistrerMouvementClient({
        nom,
        whatsapp = "",
        typeOp = "Il a pris crédit",
        montant,
        devise = "XOF",
        optionLabel = "",
        source = "index.html",
        verifierResteRemboursement = false
    }) {
        const nomClean = String(nom || "").trim();
        const montantNum = Number(String(montant ?? "").replace(/[^0-9.]/g, ""));

        if (!nomClean || !Number.isFinite(montantNum) || montantNum <= 0) {
            return { ok: false, erreur: "Nom du client ou montant invalide." };
        }

        const dataActuelle = tcLireDonneesClients();
        const profils = dataActuelle.profils.slice();
        const nowStr = tcDateCourte();
        const dev = devise || localStorage.getItem("tc_devise") || "XOF";

        const opNorm = String(typeOp || "").toLowerCase();
        const estEntree =
            opNorm.includes("rembours") ||
            opNorm.includes("payer") ||
            opNorm.includes("fini") ||
            opNorm === "rembourser" ||
            opNorm === "payer_avance";
        const estReglementTotal = opNorm.includes("fini de tout payer");
        const estSortie = !estEntree;

        const idx = profils.findIndex((p) => String(p.nom || "").toLowerCase() === nomClean.toLowerCase());
        const existant = idx >= 0 ? { ...profils[idx] } : null;

        const empruntActuel = existant ? (Number(existant.totalEmprunt) || 0) : 0;
        const rembourseActuel = existant ? (Number(existant.totalRembourse) || 0) : 0;
        const resteActuel = Math.max(0, empruntActuel - rembourseActuel);

        if (verifierResteRemboursement && estEntree && !estReglementTotal) {
            if (resteActuel <= 0) {
                return {
                    ok: false,
                    erreur: `Refusé : ${nomClean} n'a aucun emprunt actif à rembourser (reste dû : 0 ${dev}).`
                };
            }
            if (montantNum > resteActuel) {
                return {
                    ok: false,
                    erreur: `Refusé : ${nomClean} a ${tcFormaterMontant(resteActuel)} ${dev} à rembourser. Impossible de dépasser ce montant.`
                };
            }
        }

        const texteMouvement = estSortie
            ? `${nomClean} a emprunté ${tcFormaterMontant(montantNum)} ${dev}`
            : `${nomClean} a remboursé ${tcFormaterMontant(montantNum)} ${dev}`;

        let clientMaj;
        if (existant) {
            clientMaj = { ...existant };
            if (estSortie) {
                clientMaj.totalEmprunt = (Number(clientMaj.totalEmprunt) || 0) + montantNum;
                clientMaj.derniereDateEmprunt = nowStr;
            } else if (estReglementTotal) {
                clientMaj.totalRembourse = Number(clientMaj.totalEmprunt) || montantNum;
                clientMaj.derniereDateRemboursement = nowStr;
            } else {
                clientMaj.totalRembourse = (Number(clientMaj.totalRembourse) || 0) + montantNum;
                clientMaj.derniereDateRemboursement = nowStr;
            }
            clientMaj.resteAPayer = Math.max(0, (Number(clientMaj.totalEmprunt) || 0) - (Number(clientMaj.totalRembourse) || 0));
            clientMaj.soldeNet = (Number(clientMaj.totalRembourse) || 0) - (Number(clientMaj.totalEmprunt) || 0);
            if (whatsapp) clientMaj.whatsapp = String(whatsapp).trim();
            clientMaj.devise = dev;
            clientMaj.dateEnregistrement = nowStr;
            clientMaj.dernierMouvementTexte = texteMouvement;
            if (optionLabel) clientMaj.derniereOption = optionLabel;
            if (source) clientMaj.source = source;
            clientMaj.historique = Array.isArray(clientMaj.historique) ? clientMaj.historique.slice() : [];
            clientMaj.historique.unshift({
                date: nowStr,
                type: estSortie ? "emprunter" : "rembourser",
                option: optionLabel || typeOp,
                montant: montantNum,
                devise: dev,
                texte: texteMouvement,
                source
            });
            profils.splice(idx, 1);
            profils.unshift(clientMaj);
        } else {
            const totalEmprunt = estSortie ? montantNum : 0;
            const totalRembourse = estSortie ? 0 : montantNum;
            clientMaj = {
                nom: nomClean,
                whatsapp: String(whatsapp || "").trim(),
                devise: dev,
                totalEmprunt,
                totalRembourse,
                resteAPayer: Math.max(0, totalEmprunt - totalRembourse),
                soldeNet: totalRembourse - totalEmprunt,
                derniereDateEmprunt: estSortie ? nowStr : "-",
                derniereDateRemboursement: estSortie ? "-" : nowStr,
                dateEnregistrement: nowStr,
                dernierMouvementTexte: texteMouvement,
                derniereOption: optionLabel || typeOp,
                source,
                historique: [{
                    date: nowStr,
                    type: estSortie ? "emprunter" : "rembourser",
                    option: optionLabel || typeOp,
                    montant: montantNum,
                    devise: dev,
                    texte: texteMouvement,
                    source
                }]
            };
            profils.unshift(clientMaj);
        }

        const flux = tcLireFluxLive();
        const entreeFlux = {
            nom: nomClean,
            montant: montantNum,
            devise: dev,
            texte: texteMouvement,
            date: nowStr,
            sens: estSortie ? "down" : "up"
        };
        if (estSortie) {
            flux.descentes.unshift(entreeFlux);
        } else {
            flux.montants.unshift(entreeFlux);
        }
        tcSauvegarderFluxLive(flux);

        localStorage.setItem(CLE_PROFILS, JSON.stringify(profils));
        localStorage.setItem(CLE_DERNIER_CLIENT, nomClean);
        localStorage.setItem(CLE_DERNIER_MOUVEMENT, texteMouvement);
        localStorage.setItem("tc_dernier_profil_actif", JSON.stringify(clientMaj));
        localStorage.setItem("tc_profil_client_selectionne", nomClean);

        const stats = tcCalculerEtSauvegarderStats(profils);
        const payload = {
            profils,
            stats,
            fluxLive: flux,
            dernierClient: nomClean,
            dernierMouvement: texteMouvement,
            clientMaj,
            estSortie,
            montantNum
        };

        window.dispatchEvent(new CustomEvent("tc:client-update", { detail: payload }));
        tcActualiserPage();

        return { ok: true, ...payload };
    }

    function tcAppliquerAuxElementsData(data) {
        document.querySelectorAll("[data-tc]").forEach((el) => {
            const cle = el.getAttribute("data-tc");
            if (cle === "totalClients") el.innerText = data.stats.totalClients;
            else if (cle === "totalEmprunts") el.innerText = data.stats.totalEmprunts;
            else if (cle === "totalRembourses") el.innerText = data.stats.totalRembourses;
            else if (cle === "resteAPayer") el.innerText = data.stats.resteAPayer;
            else if (cle === "soldeNet") el.innerText = data.stats.soldeNet;
            else if (cle === "dernierClient") el.innerText = data.dernierClient;
            else if (cle === "dernierMouvement") el.innerText = data.dernierMouvement;
            else if (cle === "listeClients") {
                el.innerHTML = data.profils.map((c) => {
                    const reste = Math.max(0, (Number(c.totalEmprunt) || 0) - (Number(c.totalRembourse) || 0));
                    return `<div><strong>${c.nom || ""}</strong> — ${c.dernierMouvementTexte || ""} (Reste : ${reste} ${c.devise || "XOF"})</div>`;
                }).join("");
            }
        });
    }

    function tcActualiserPage() {
        const data = tcLireDonneesClients();
        tcAppliquerAuxElementsData(data);
        if (typeof window.onTradingCommerceUpdate === "function") {
            window.onTradingCommerceUpdate(data);
        }
    }

    window.tcLireDonneesClients = tcLireDonneesClients;
    window.tcCalculerEtSauvegarderStats = tcCalculerEtSauvegarderStats;
    window.tcEnregistrerMouvementClient = tcEnregistrerMouvementClient;
    window.tcActualiserPage = tcActualiserPage;
    window.tcFormaterMontant = tcFormaterMontant;

    window.addEventListener("tc:client-update", tcActualiserPage);
    window.addEventListener("storage", tcActualiserPage);

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", tcActualiserPage);
    } else {
        tcActualiserPage();
    }
})();



(function () {
    const CLE_PROFILS = "tc_profils_clients";
    const CLE_STATS = "tc_stats_globales";
    const CLE_DERNIER_CLIENT = "tc_dernier_client";
    const CLE_DERNIER_MOUVEMENT = "tc_dernier_mouvement";

    function tcLireDonneesClients() {
        let profils = [];
        try {
            const raw = JSON.parse(localStorage.getItem(CLE_PROFILS) || "[]");
            profils = Array.isArray(raw) ? raw : [];
        } catch (e) {
            profils = [];
        }

        const totalEmprunts = profils.reduce((s, c) => s + (Number(c.totalEmprunt) || 0), 0);
        const totalRembourses = profils.reduce((s, c) => s + (Number(c.totalRembourse) || 0), 0);
        const resteAPayer = Math.max(0, totalEmprunts - totalRembourses);

        return {
            profils,
            dernierClient: localStorage.getItem(CLE_DERNIER_CLIENT) || "",
            dernierMouvement: localStorage.getItem(CLE_DERNIER_MOUVEMENT) || "",
            stats: {
                totalClients: profils.length,
                totalEmprunts,
                totalRembourses,
                resteAPayer
            }
        };
    }

    function tcCalculerEtSauvegarderStats(profils) {
        const totalEmprunts = profils.reduce((s, c) => s + (Number(c.totalEmprunt) || 0), 0);
        const totalRembourses = profils.reduce((s, c) => s + (Number(c.totalRembourse) || 0), 0);
        const resteAPayer = Math.max(0, totalEmprunts - totalRembourses);

        const stats = {
            totalClients: profils.length,
            totalEmprunts,
            totalRembourses,
            resteAPayer,
            misAJourLe: new Date().toLocaleString("fr-FR")
        };

        localStorage.setItem(CLE_STATS, JSON.stringify(stats));
        return stats;
    }

    function tcEnregistrerMouvementClient({ nom, whatsapp = "", typeOp = "Il a pris crédit", montant, devise = "XOF" }) {
        const nomClean = String(nom || "").trim();
        const montantNum = Number(String(montant ?? "").replace(/[^0-9.]/g, ""));

        if (!nomClean || !Number.isFinite(montantNum) || montantNum <= 0) {
            return { ok: false, erreur: "Nom ou montant invalide." };
        }

        const dataActuelle = tcLireDonneesClients();
        const profils = dataActuelle.profils.slice();
        const dateActuelle = new Date().toLocaleString("fr-FR");
        const estCredit = typeOp === "Il a pris crédit";
        const estReglementTotal = typeOp === "Il a fini de tout payer";

        const texteMouvement = estCredit
            ? `${nomClean} a emprunté ${montantNum}F`
            : `${nomClean} : ${typeOp} (${montantNum}F)`;

        const idx = profils.findIndex((p) => String(p.nom || "").toLowerCase() === nomClean.toLowerCase());

        if (idx >= 0) {
            const c = { ...profils[idx] };
            if (estCredit) {
                c.totalEmprunt = (Number(c.totalEmprunt) || 0) + montantNum;
                c.derniereDateEmprunt = dateActuelle;
            } else if (estReglementTotal) {
                c.totalRembourse = Number(c.totalEmprunt) || montantNum;
                c.derniereDateRemboursement = dateActuelle;
            } else {
                c.totalRembourse = (Number(c.totalRembourse) || 0) + montantNum;
                c.derniereDateRemboursement = dateActuelle;
            }
            c.reste = Math.max(0, (Number(c.totalEmprunt) || 0) - (Number(c.totalRembourse) || 0));
            if (whatsapp) c.whatsapp = String(whatsapp).trim();
            c.devise = devise || c.devise || "XOF";
            c.dateEnregistrement = dateActuelle;
            c.dernierMouvementTexte = texteMouvement;
            c.historique = Array.isArray(c.historique) ? c.historique.slice() : [];
            c.historique.unshift({
                texte: texteMouvement,
                montant: montantNum,
                type: typeOp,
                date: dateActuelle
            });
            profils[idx] = c;
        } else {
            const totalEmprunt = estCredit ? montantNum : 0;
            const totalRembourse = estCredit ? 0 : montantNum;
            profils.unshift({
                nom: nomClean,
                whatsapp: String(whatsapp || "").trim(),
                devise: devise || "XOF",
                totalEmprunt,
                totalRembourse,
                reste: Math.max(0, totalEmprunt - totalRembourse),
                derniereDateEmprunt: estCredit ? dateActuelle : "",
                derniereDateRemboursement: estCredit ? "" : dateActuelle,
                dateEnregistrement: dateActuelle,
                dernierMouvementTexte: texteMouvement,
                historique: [{
                    texte: texteMouvement,
                    montant: montantNum,
                    type: typeOp,
                    date: dateActuelle
                }]
            });
        }

        localStorage.setItem(CLE_PROFILS, JSON.stringify(profils));
        localStorage.setItem(CLE_DERNIER_CLIENT, nomClean);
        localStorage.setItem(CLE_DERNIER_MOUVEMENT, texteMouvement);
        const stats = tcCalculerEtSauvegarderStats(profils);

        const payload = { profils, stats, dernierClient: nomClean, dernierMouvement: texteMouvement };
        window.dispatchEvent(new CustomEvent("tc:client-update", { detail: payload }));
        tcActualiserPage();

        return { ok: true, ...payload };
    }

    function tcAppliquerAuxElementsData(data) {
        document.querySelectorAll("[data-tc]").forEach((el) => {
            const cle = el.getAttribute("data-tc");
            if (cle === "totalClients") el.innerText = data.stats.totalClients;
            else if (cle === "totalEmprunts") el.innerText = data.stats.totalEmprunts;
            else if (cle === "totalRembourses") el.innerText = data.stats.totalRembourses;
            else if (cle === "resteAPayer") el.innerText = data.stats.resteAPayer;
            else if (cle === "dernierClient") el.innerText = data.dernierClient;
            else if (cle === "dernierMouvement") el.innerText = data.dernierMouvement;
            else if (cle === "listeClients") {
                el.innerHTML = data.profils.map((c) => {
                    const reste = Math.max(0, (Number(c.totalEmprunt) || 0) - (Number(c.totalRembourse) || 0));
                    return `<div><strong>${c.nom || ""}</strong> — ${c.dernierMouvementTexte || ""} (Reste : ${reste} ${c.devise || "XOF"})</div>`;
                }).join("");
            }
        });
    }

    function tcActualiserPage() {
        const data = tcLireDonneesClients();
        tcAppliquerAuxElementsData(data);

        if (typeof window.onTradingCommerceUpdate === "function") {
            window.onTradingCommerceUpdate(data);
        }
    }

    window.tcLireDonneesClients = tcLireDonneesClients;
    window.tcCalculerEtSauvegarderStats = tcCalculerEtSauvegarderStats;
    window.tcEnregistrerMouvementClient = tcEnregistrerMouvementClient;
    window.tcActualiserPage = tcActualiserPage;

    window.addEventListener("tc:client-update", tcActualiserPage);
    window.addEventListener("storage", tcActualiserPage);

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", tcActualiserPage);
    } else {
        tcActualiserPage();
    }
})();

