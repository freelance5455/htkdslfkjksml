# Launch Checklist — NASLAN WORLD ONLINE

## Branding and contacts
- [ ] Confirm final logo and app icon.
- [ ] Add verified business email and phone.
- [ ] Add registered business details where required.
- [ ] Publish Terms, Refund/Cancellation Policy and Privacy Policy.

## Firebase
- [ ] Create Firebase project and Android app.
- [ ] Configure FlutterFire.
- [ ] Enable Firebase Authentication.
- [ ] Enable Firestore and deploy reviewed security rules.
- [ ] Add admin role/claims and test unauthorized access.
- [ ] Confirm booking requests are actually visible in admin panel.

## Travel partners
- [ ] Obtain written approval from flight provider/agency.
- [ ] Obtain hotel affiliate/API approval.
- [ ] Contract and verify taxi operators in each launch region.
- [ ] Document commission, refunds, cancellations, customer support and settlement.
- [ ] Do not claim bookings are confirmed until the partner confirms them.

## Payments and legal
- [ ] Start without payments, as requested.
- [ ] When ready, apply for a supported payment gateway and complete merchant verification.
- [ ] Never store card details in the app.
- [ ] Confirm applicable Sri Lankan/UAE business, tax, travel agency and consumer protection requirements with qualified local advisers.

## Play Store
- [ ] Generate release APK/AAB.
- [ ] Test on physical Android devices.
- [ ] Complete Play Console developer registration.
- [ ] Complete current testing requirements for your account type.
- [ ] Upload privacy policy, data safety disclosures, screenshots and store listing.
- [ ] Submit for review.
