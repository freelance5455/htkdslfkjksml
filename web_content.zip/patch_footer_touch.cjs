const fs = require('fs');
let code = fs.readFileSync('src/components/ProfessionalFooter.tsx', 'utf8');

// Add touch-action styles to the full-screen containers
code = code.replace(/<div className="fixed inset-0 z-50 flex flex-col bg-slate-950 animate-fadeIn"/g, '<div className="fixed inset-0 z-50 flex flex-col bg-slate-950 animate-fadeIn" style={{ touchAction: "pan-x pan-y pinch-zoom" }}');
code = code.replace(/<div className="fixed inset-0 z-\[100\] flex flex-col bg-slate-950 animate-fadeIn"/g, '<div className="fixed inset-0 z-[100] flex flex-col bg-slate-950 animate-fadeIn" style={{ touchAction: "pan-x pan-y pinch-zoom" }}');

fs.writeFileSync('src/components/ProfessionalFooter.tsx', code);
console.log("Patched touch styles");
