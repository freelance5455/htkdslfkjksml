ULTIMA AI

This ZIP is a front-end prototype designed for a web-to-APK / ZIP-to-APK builder.

It includes the requested UI concepts: Chat, Sources, Notes, Writing, Voice, source-vs-web modes, and an include-notes toggle.

IMPORTANT: This is NOT yet the finished AI product. A real ChatGPT-like AI, web search, source ingestion/retrieval, image understanding, document parsing, cloud sync, and secure API authentication require a backend. API keys should never be placed directly in this front-end.
