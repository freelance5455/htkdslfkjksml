# سیستم ماموریت‌ها و اهداف (Quest System)
# فرمت استاندارد برای خوانش هوش مصنوعی (Ren'Py Style)

# ۱. تعریف متغیرهای ماموریت در ابتدای بازی
default quest_active = False
default quest_completed = False
default quest_progress = 0
default quest_target = 3 # مثلا جمع آوری ۳ مدرک یا صحبت با ۳ نفر

init python:
    # تابع بررسی وضعیت ماموریت برای ساده‌سازی کدهای داستانی
    def advance_quest():
        store.quest_progress += 1
        if store.quest_progress >= store.quest_target:
            store.quest_active = False
            store.quest_completed = True
            renpy.notify("ماموریت با موفقیت به پایان رسید!")

# ۲. منطق داستانی ماموریت
label start_quest_line:
    scene bg room
    show npc happy
    
    npc "سلام قهرمان! به کمک تو نیاز دارم. طلسم‌های گم شده من را پیدا کن."
    
    menu:
        "قبول کردن ماموریت":
            $ quest_active = True
            npc "ممنونم! وقتی تمامشون را پیدا کردی برگرد پیش من."
        "رد کردن":
            npc "حیف شد... اگر نظرت عوض شد من همینجا هستم."
    return

label check_quest_status:
    if quest_completed:
        npc "فوق‌العادست! تو کار رو تموم کردی. اینم پاداش تو!"
        $ gold += 50 # اتصال به سیستم اقتصاد
    elif quest_active:
        npc "هنوز کار رو تموم نکردی. تو [quest_progress] از [quest_target] طلسم رو پیدا کردی."
    else:
        npc "امروز کار خاصی برای انجام دادن ندارم."
    return
