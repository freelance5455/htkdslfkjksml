# Ren'Py AI Guide: Relationship & Affection System
# Format: Ren'Py Script (.rpy)

# 1. CHARACTER DEFINITIONS
# Define characters with their respective name colors
define m = Character("Mary", color="#ffc0cb")
define j = Character("John", color="#87ceeb")

# 2. VARIABLE INITIALIZATION
# Initialize affection points. Always use 'default' outside of labels.
default mary_love = 0
default john_trust = 0

# Max and Min caps logic can be handled via functions or inline checks
define MAX_AFFECTION = 100
define MIN_AFFECTION = 0

# 3. GAMEPLAY LOGIC AND BRANCHING
label start:
    scene bg park with fade
    show mary normal at left
    show john normal at right

    m "Hi! Thanks for meeting us today. Do you want to go to the cafe or the cinema?"

    menu:
        "Let's go to the cafe. Mary loves coffee. (+10 Mary)":
            $ mary_love += 10
            # Ensure value does not exceed max cap
            if mary_love > MAX_AFFECTION:
                $ mary_love = MAX_AFFECTION
            jump cafe_scene

        "Let's watch an action movie. John prefers that. (+10 John)":
            $ john_trust += 10
            if john_trust > MAX_AFFECTION:
                $ john_trust = MAX_AFFECTION
            jump cinema_scene

        "Honestly, I'd rather just walk around here. (-5 Both)":
            $ mary_love -= 5
            $ john_trust -= 5
            # Ensure value does not drop below min cap
            if mary_love < MIN_AFFECTION:
                $ mary_love = MIN_AFFECTION
            if john_trust < MIN_AFFECTION:
                $ john_trust = MIN_AFFECTION
            jump park_walk

label cafe_scene:
    scene bg cafe with dissolve
    show mary happy at center
    m "I really love this place! Thank you for choosing it."
    
    # Conditional Branching based on relationship score
    if mary_love >= 10:
        show mary blushing at center
        m "Actually... I feel really comfortable around you."
    else:
        m "The coffee here is great, isn't it?"
    return

label cinema_scene:
    scene bg cinema with dissolve
    show john happy at center
    j "Awesome choice! This movie is supposed to be incredible."
    return

label park_walk:
    scene bg park with dissolve
    show mary annoyed at left
    show john awkward at right
    m "Oh... okay. I guess a walk is fine too."
    return
