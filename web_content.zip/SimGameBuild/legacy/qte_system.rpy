# سیستم رویدادهای واکنش سریع (QTE - Quick Time Event)
# فرمت استاندارد برای خوانش هوش مصنوعی (Ren'Py Style)

init python:
    # متغیر نتیجه سیستم واکنش سریع
    qte_success = False

# تعریف صفحه گرافیکی QTE که زمان‌سنج دارد
screen qte_button(target_label, timeout_duration=2.0):
    timer timeout_duration action [Hide("qte_button"), Jump(target_label + "_failed")]
    
    frame:
        xalign 0.5
        yalign 0.5
        vbox:
            spacing 20
            text "سریع کلیک کن!" size 30 xalign 0.5
            textbutton "کلیک!" action [SetVariable("qte_success", True), Hide("qte_button"), Jump(target_label + "_success")] xalign 0.5

# ۳. نمونه پیاده‌سازی در داستان بازی
label start_action_scene:
    scene bg forest_danger
    "یک سنگ بزرگ دارد به سمت شما سقوط می‌کند! باید به سرعت جاخالی دهید!"
    
    # ریست کردن متغیر موفقیت
    $ qte_success = False
    
    # فراخوانی صفحه QTE با محدودیت ۲ ثانیه زمان
    call screen qte_button(target_label="evade_rock", timeout_duration=2.0)

label evade_rock_success:
    "به موقع شیرجه زدید و سنگ از کنار شما عبور کرد. خطری تهدیدتان نمی‌کند."
    $ relationship_score += 5 # اتصال به سیستم رابطه (شجاعت کاراکتر)
    jump continue_story

label evade_rock_failed:
    "آخ! زمان شما تمام شد و سنگ به پای شما برخورد کرد."
    $ player_health -= 20
    jump continue_story

label continue_story:
    "به مسیر خود در جنگل ادامه می‌دهید..."
    return
