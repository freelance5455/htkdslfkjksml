// farming_system.js - سیستم شبیه‌ساز کشاورزی تحت وب
export class Crop {
    constructor(id, name, growthDays, seedCost, harvestValue) {
        this.id = id;
        this.name = name;
        this.growthDays = growthDays;
        this.seedCost = seedCost;
        this.harvestValue = harvestValue;
    }
}

export class FieldPlot {
    constructor(id) {
        this.id = id;
        this.crop = null;
        this.currentGrowth = 0;
        this.isWatered = false;
    }

    plant(crop) {
        if (this.crop) return false;
        this.crop = crop;
        this.currentGrowth = 0;
        this.isWatered = false;
        return true;
    }

    water() {
        this.isWatered = true;
    }

    advanceDay() {
        if (this.crop && this.isWatered) {
            this.currentGrowth++;
            this.isWatered = false; // نیاز به آبیاری مجدد برای روز بعد
        }
    }

    isReadyToHarvest() {
        return this.crop && this.currentGrowth >= this.crop.growthDays;
    }

    harvest() {
        if (!this.isReadyToHarvest()) return null;
        const harvestedCrop = this.crop;
        this.crop = null;
        this.currentGrowth = 0;
        this.isWatered = false;
        return harvestedCrop;
    }
}
