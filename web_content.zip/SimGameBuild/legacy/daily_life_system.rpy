# Daily Life Routine & Time Management System for Ren'Py
# This system handles days of the week, daily time slots (Morning, Afternoon, Evening, Night),
# and updates local NPC locations based on the current time and day.

# Define Time Slots and Days
define TIME_SLOTS = ["Morning", "Afternoon", "Evening", "Night"]
define DAYS_OF_WEEK = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]

init python:
    class TimeManager(object):
        def __init__(self):
            self.day_index = 0  # Starts on Monday
            self.time_index = 0 # Starts in the Morning
            self.total_days_passed = 1
            
        @property
        def current_day(self):
            return DAYS_OF_WEEK[self.day_index]
            
        @property
        def current_time_slot(self):
            return TIME_SLOTS[self.time_index]
            
        def advance_time(self, slots=1):
            """Advances time slots. Automatically rolls over to the next day if Night passes."""
            self.time_index += slots
            while self.time_index >= len(TIME_SLOTS):
                self.time_index -= len(TIME_SLOTS)
                self.advance_day()
            renpy.notify(f"Time Advanced: {self.current_time_slot} ({self.current_day})")
                
        def advance_day(self):
            self.day_index = (self.day_index + 1) % len(DAYS_OF_WEEK)
            self.total_days_passed += 1
            # Trigger daily farming simulation updates if farming system is linked
            if 'farming_system' in globals():
                farming_system.next_day_update()

        def get_npc_location(self, npc_name):
            """Determines where an NPC is based on schedule."""
            # Example Schedule: Mary is at the farm in the morning, town in afternoon, home at night
            if npc_name == "Mary":
                if self.current_time_slot == "Morning":
                    return "farm_field"
                elif self.current_time_slot == "Afternoon":
                    return "town_market"
                else:
                    return "mary_house"
            return "unknown"

# Initialize the global time manager
default time_manager = TimeManager()

# Screen to display HUD for Daily Life Status
screen daily_life_hud():
    frame:
        xalign 0.02
        yalign 0.02
        padding (10, 10)
        background "#000000a0"
        vbox:
            spacing 5
            text "Day: [time_manager.total_days_passed] ([time_manager.current_day])" size 20 color "#ffffff"
            text "Time: [time_manager.current_time_slot]" size 18 color "#ffcc00"

# Code usage and script execution sample
label daily_life_example:
    show screen daily_life_hud
    
    "It is a beautiful [time_manager.current_day] morning. I should check where everyone is."
    
    $ mary_loc = time_manager.get_npc_location("Mary")
    "According to my schedule, Mary should be at the [mary_loc]."
    
    menu:
        "Go to work in the field (Takes 2 time slots)":
            $ time_manager.advance_time(2)
            "You worked hard. Time has passed rapidly."
        "Rest until evening":
            if time_manager.current_time_slot == "Morning":
                $ time_manager.advance_time(2)
            elif time_manager.current_time_slot == "Afternoon":
                $ time_manager.advance_time(1)
            "You took a nice long nap."
            
    "Now it is [time_manager.current_time_slot]. Let's check Mary's location again."
    $ mary_loc = time_manager.get_npc_location("Mary")
    "Mary moved! She is now at the [mary_loc]."
    return
