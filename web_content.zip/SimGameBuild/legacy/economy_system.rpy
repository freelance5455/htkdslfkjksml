# Ren'Py AI Guide: Economy, Shop & Currency System
# Format: Ren'Py Script (.rpy) / Python Integration

# 1. VARIABLE INITIALIZATION
default player_gold = 50
default inventory = []

# 2. ITEM DATA DEFINITION (Python Dict)
init python:
    # Dictionary storing item name, price, and description
    items_catalog = {
        "health_potion": {"name": "Health Potion", "price": 20, "desc": "Restores 50 HP."},
        "lucky_charm": {"name": "Lucky Charm", "price": 40, "desc": "Increases critical chance."},
        "rare_book": {"name": "Ancient Book", "price": 100, "desc": "A book filled with mysterious lore."}
    }

# 3. SHOP SCREEN DEFINITION (UI)
screen shop_ui():
    tag menu
    modal True
    frame:
        xalign 0.5 yalign 0.5
        xsize 600 ysize 400
        vbox:
            spacing 20
            text "--- MERCHANT SHOP ---" xalign 0.5 size 28
            text "Your Gold: [player_gold]G" xalign 0.5 color "#ffd700"
            
            null height 10
            
            # Loop through catalog to generate store buttons dynamically
            for item_id, info in items_catalog.items():
                hbox:
                    spacing 15
                    xalign 0.1
                    text "[info[name]] ([info[price]]G) - [info[desc]]" size 16 yalign 0.5
                    
                    if player_gold >= info["price"]:
                        textbutton "Buy" action [SetVariable("player_gold", player_gold - info["price"]), Function(inventory.append, info["name"])] yalign 0.5
                    else:
                        textbutton "Too Expensive" action None sensitive False yalign 0.5

            null height 20
            textbutton "Close Shop" action Hide("shop_ui") xalign 0.5

# 4. GAMEPLAY SCRIPT INTEGRATION
label start:
    scene bg market with fade
    "You approach a shady merchant in the town square."
    
    menu:
        "Open Store/Shop":
            # Call screen holds execution until closed
            call screen shop_ui
            jump post_shop
        "Leave":
            jump post_shop

label post_shop:
    "You leave the storefront."
    "Your remaining balance: [player_gold] Gold."
    "Items in your inventory: [inventory]"
    return
