// weather_system.js - سیستم مستقل آب و هوا و تاثیرات محیطی بازی تحت وب
export class WeatherSystem {
    constructor() {
        this.weatherTypes = ['sunny', 'cloudy', 'rainy', 'stormy'];
        this.currentWeather = 'sunny';
        this.temperature = 22; // دمای پایه به سانتی‌گراد
    }

    // تغییر اتفاقی آب و هوا برای روز جدید
    changeWeather() {
        const rand = Math.random();
        if (rand < 0.4) {
            this.currentWeather = 'sunny';
            this.temperature = Math.floor(Math.random() * (35 - 25 + 1)) + 25;
        } else if (rand < 0.7) {
            this.currentWeather = 'cloudy';
            this.temperature = Math.floor(Math.random() * (24 - 15 + 1)) + 15;
        } else if (rand < 0.9) {
            this.currentWeather = 'rainy';
            this.temperature = Math.floor(Math.random() * (14 - 8 + 1)) + 8;
        } else {
            this.currentWeather = 'stormy';
            this.temperature = Math.floor(Math.random() * (7 - 2 + 1)) + 2;
        }
        return { weather: this.currentWeather, temp: this.temperature };
    }

    // تاثیر آب و هوا روی کرت‌های کشاورزی
    applyWeatherToFields(fieldPlots) {
        fieldPlots.forEach(plot => {
            if (this.currentWeather === 'rainy' || this.currentWeather === 'stormy') {
                plot.water(); // باران زمین را به صورت خودکار آبیاری می‌کند
            }
        });
    }

    // تاثیر آب و هوا روی وضعیت روانی و خستگی بازیکن
    getMentalImpact() {
        if (this.currentWeather === 'stormy') {
            return { stressImpact: 15, fatigueImpact: 10, msg: "طوفان شدید باعث استرس و خستگی بیشتر می‌شود." };
        } else if (this.currentWeather === 'rainy') {
            return { stressImpact: -5, fatigueImpact: 0, msg: "باران ملایم استرس شما را کاهش می‌دهد." };
        }
        return { stressImpact: 0, fatigueImpact: 0, msg: "" };
    }
}
