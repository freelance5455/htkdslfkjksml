# Farming and Agriculture Simulation System for Ren'Py
# This handles land plots, planting seeds, watering, crop growth cycles, and harvesting.

init python:
    class Crop(object):
        def __init__(self, name, days_to_grow, seed_cost, sell_value):
            self.name = name
            self.days_to_grow = days_to_grow
            self.seed_cost = seed_cost
            self.sell_value = sell_value

    class CropPlot(object):
        def __init__(self):
            self.crop = None          # None if empty, else a Crop object
            self.current_growth = 0   # Days spent growing
            self.is_watered = False
            self.is_harvestable = False

        def plant_seed(self, crop_object):
            if self.crop is None:
                self.crop = crop_object
                self.current_growth = 0
                self.is_watered = False
                self.is_harvestable = False
                return True
            return False # Plot occupied

        def water_plot(self):
            self.is_watered = True

        def update_daily_growth(self):
            """Simulates one day of growth. Must be called during day roll-over."""
            if self.crop and self.is_watered:
                self.current_growth += 1
                self.is_watered = False # Dries up for the next day
                if self.current_growth >= self.crop.days_to_grow:
                    self.is_harvestable = True
            elif self.crop and not self.is_watered:
                # Crop doesn't grow if not watered, could implement withered logic here
                pass

        def harvest(self):
            if self.is_harvestable:
                harvested_crop = self.crop
                self.crop = None
                self.current_growth = 0
                self.is_harvestable = False
                self.is_watered = False
                return harvested_crop
            return None

    class FarmingSystem(object):
        def __init__(self, number_of_plots=4):
            self.plots = [CropPlot() for _ in range(number_of_plots)]
            # Define database of available crops
            self.crop_db = {
                "Wheat": Crop("Wheat", days_to_grow=2, seed_cost=10, sell_value=25),
                "Tomato": Crop("Tomato", days_to_grow=4, seed_cost=20, sell_value=60)
            }

        def next_day_update(self):
            """Updates all fields when the day shifts."""
            for plot in self.plots:
                plot.update_daily_growth()

# Initialize Farming Database and Fields
default farming_system = FarmingSystem(number_of_plots=4)

# Farming Screen Interface Layout
screen farming_menu():
    modal True
    frame:
        xalign 0.5
        yalign 0.5
        padding (20, 20)
        background "#2e1f10d0"
        vbox:
            spacing 15
            text "--- MY FARM FIELD ---" xalign 0.5 size 24 color "#fff"
            
            hbox:
                spacing 20
                # Render each plot dynamically
                for index, plot in enumerate(farming_system.plots):
                    vbox:
                        spacing 10
                        box_wrap True
                        text f"Plot #{index+1}" color "#ffcc00" xalign 0.5
                        
                        if plot.crop is None:
                            text "Empty Land" color "#888888"
                            textbutton "Plant Wheat" action [Function(plot.plant_seed, farming_system.crop_db["Wheat"]), SensitiveIf(plot.crop is None)]
                        else:
                            text f"Crop: {plot.crop.name}" color "#ffffff"
                            text f"Growth: {plot.current_growth}/{plot.crop.days_to_grow} Days" color "#aaaaaa"
                            
                            if plot.is_harvestable:
                                text "READY!" color "#00ff00"
                                textbutton "Harvest" action [SetVariable("harvested_item", plot.harvest()), Return("harvested")]
                            else:
                                if plot.is_watered:
                                    text "Watered" color "#3399ff"
                                else:
                                    textbutton "Water Field" action Function(plot.water_plot)
            
            textbutton "Exit Field" action Return("exit") xalign 0.5 ymargin 10

# Code usage and script execution sample
label farming_example:
    define harvested_item = None
    "You walk down to your agricultural farm field plots."
    
    call screen farming_menu
    $ res = _return
    
    if res == "harvested" and harvested_item is not None:
        "Congratulations! You successfully harvested [harvested_item.name]!"
        "You can now sell it at the market for [harvested_item.sell_value] gold."
    else:
        "You left the farm management view."
    return
