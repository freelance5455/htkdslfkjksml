# Visual Novel Creation Guide & Script Templates (Ren'Py)

This document provides structured text and Python/Ren'Py code templates that can be fed into an AI system to help it write, format, or generate code for a Visual Novel game.

---

## 1. Project Directory Structure
A standard Ren'Py project requires this minimum directory structure:
```text
my_visual_novel/
│
├── game/
│   ├── audio/              # Sound effects and music (.mp3, .ogg)
│   ├── images/             # Character sprites and backgrounds (.png, .jpg)
│   ├── options.rpy         # Game configuration (window size, title, etc.)
│   ├── gui.rpy             # User interface customization
│   └── script.rpy          # Main game script and story flow
│
└── README.txt
```

---

## 2. Character and Asset Definitions
Before writing the story, define the characters and their associated colors/sprites in `script.rpy`.

```renpy
# Define Characters
define e = Character("Eileen", color="#c8ffc8")
define mc = Character("[player_name]", color="#ffffff")

# Define Background Images
image bg room = "images/bg_room.jpg"
image bg school = "images/bg_school.jpg"

# Define Character Sprites (Happy, Sad, Neutral)
image eileen happy = "images/eileen_happy.png"
image eileen sad = "images/eileen_sad.png"
```

---

## 3. Core Syntax and Story Flow (Template)
Here is a comprehensive script template showcasing dialogue, transitions, player inputs, conditional logic, and branching paths.

```renpy
# The game starts here.
label start:

    # Play background music
    play music "audio/ambient_wind.ogg" fadein 2.0

    # Show a background with a fade transition
    scene bg room
    with fade

    "The sun was setting, casting a warm glow over the messy desk."

    # Show character sprite on screen
    show eileen happy at right
    with dissolve

    e "Hi! Welcome to your first Ren'Py visual novel. What's your name?"

    # Getting Player Name Input
    python:
        player_name = renpy.input("Enter your name:", default="Hero")
        player_name = player_name.strip()
        if not player_name:
            player_name = "Hero"

    e "Nice to meet you, [player_name]!"

    show eileen sad at right
    e "I have a very important question to ask you..."

    # Branching Choices (Menu)
    menu:
        "Help Eileen with her quest.":
            jump path_help

        "Decline and stay home.":
            jump path_decline

# Branch 1
label path_help:
    show eileen happy at right
    e "Thank you so much! I knew I could count on you."
    
    # Increase a hidden variable (e.g., affection points)
    $ eileen_trust = True
    
    scene bg school
    with pixellate
    "And so, your adventure together begins at the school gates..."
    
    jump game_end

# Branch 2
label path_decline:
    show eileen sad at right
    e "Oh... I understand. Maybe next time."
    
    $ eileen_trust = False
    "You spent the rest of the evening reading a book alone."
    
    jump game_end

# Game Conclusion
label game_end:
    scene black
    with fade
    
    if eileen_trust:
        "Ending 1: The Beginning of a Friendship."
    else:
        "Ending 2: The Path Not Taken."

    "Thank you for playing!"
    return
```

---

## 4. Advanced Python Integration
Ren'Py natively supports inline Python for complex systems like inventory, stats, or timers.

```renpy
# Initialize variables using default
default player_gold = 100
default inventory = []

label shop:
    "Merchant" "Would you like to buy a health potion for 50 gold?"
    
    menu:
        "Buy Potion" if player_gold >= 50:
            $ player_gold -= 50
            $ inventory.append("Health Potion")
            "You bought a potion!"
        "Leave":
            "You left the shop."
```

---

## 5. AI System Prompt Instruction
When you upload this file to an AI, you can use the following prompt:
> "Use the attached structure and code syntax rules to generate a comprehensive visual novel script based on [Your Story Idea]. Ensure all characters are properly defined, menus use correct label jumps, and the syntax strictly matches Ren'Py standard standards."