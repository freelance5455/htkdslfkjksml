// economy_system.js - سیستم اقتصاد و فروشگاه تحت وب
export class EconomySystem {
    constructor(initialGold = 100) {
        this.gold = initialGold;
        this.inventory = [];
    }

    buySeed(crop) {
        if (this.gold >= crop.seedCost) {
            this.gold -= crop.seedCost;
            this.inventory.push({ type: 'seed', target: crop });
            return true;
        }
        return false;
    }

    sellProduct(crop) {
        this.gold += crop.harvestValue;
        return this.gold;
    }
}
