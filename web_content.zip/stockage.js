const CLE_STOCKAGE = "the-completionist-progression";
const CLE_JEUX = "the-completionist-jeux";

function lireProgression() {
  try {
    return JSON.parse(localStorage.getItem(CLE_STOCKAGE)) || {};
  } catch (e) {
    return {};
  }
}

function ecrireProgression(p) {
  localStorage.setItem(CLE_STOCKAGE, JSON.stringify(p));
}

function estFait(idJeu, categorie, idElement) {
  const p = lireProgression();
  return !!(p[idJeu] && p[idJeu][categorie] && p[idJeu][categorie][idElement]);
}

function basculer(idJeu, categorie, idElement) {
  const p = lireProgression();
  p[idJeu] = p[idJeu] || {};
  p[idJeu][categorie] = p[idJeu][categorie] || {};
  if (p[idJeu][categorie][idElement]) {
    delete p[idJeu][categorie][idElement];
  } else {
    p[idJeu][categorie][idElement] = true;
  }
  ecrireProgression(p);
}

function compter(jeu, categorie) {
  const liste = jeu[categorie];
  if (!Array.isArray(liste)) return null;
  const obtenus = liste.filter(e => estFait(jeu.id, categorie, e.id)).length;
  return { obtenus: obtenus, total: liste.length };
}

function lireJeuxPerso() {
  try {
    return JSON.parse(localStorage.getItem(CLE_JEUX)) || [];
  } catch (e) {
    return [];
  }
}

function ecrireJeuxPerso(liste) {
  localStorage.setItem(CLE_JEUX, JSON.stringify(liste));
}

function tousLesJeux() {
  return lireJeuxPerso();
}

function supprimerJeuPerso(id) {
  const jeu = lireJeuxPerso().find(j => j.id === id);
  if (jeu) {
    [jeu.cover].concat((jeu.collectibles || []).map(c => c.icone))
      .filter(estIdImage)
      .forEach(supprimerImage);
  }
  ecrireJeuxPerso(lireJeuxPerso().filter(j => j.id !== id));
  const p = lireProgression();
  delete p[id];
  ecrireProgression(p);
}