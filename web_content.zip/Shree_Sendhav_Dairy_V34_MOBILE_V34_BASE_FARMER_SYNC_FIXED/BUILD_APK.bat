@echo off
setlocal
cd /d "%~dp0"
echo Shree Sendhav Dairy V34 Mobile - APK Build
where gradle >nul 2>&1
if %errorlevel%==0 (
  echo Gradle found. Building debug APK...
  gradle assembleDebug
  if %errorlevel%==0 goto done
)
echo.
echo Gradle command not found.
echo Please open this folder in Android Studio and use Build ^> Build APK(s).
echo.
pause
exit /b 1
:done
echo.
echo APK build complete. Check app\build\outputs\apk\debug\app-debug.apk
pause
