AKUNTANSIKU - PROYEK ANDROID

Isi:
- Aplikasi Android berbasis WebView.
- Menggunakan file HTML AkuntansiKu yang Anda unggah sebagai tampilan dan logika aplikasi.
- Nama aplikasi: AkuntansiKu
- Package: id.akuntansiku.app
- Penyimpanan transaksi memakai localStorage WebView pada perangkat.

CARA MEMBUAT APK DI ANDROID STUDIO
1. Instal Android Studio pada komputer Windows.
2. Ekstrak folder AkuntansiKu-Android.zip.
3. Buka Android Studio > Open, lalu pilih folder AkuntansiKu-Android.
4. Tunggu Gradle Sync selesai. Jika diminta, instal Android SDK Platform 35.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Setelah selesai, klik "locate" pada notifikasi Build. APK debug biasanya berada di:
   app/build/outputs/apk/debug/app-debug.apk
7. Pindahkan APK ke HP Android dan instal. Jika diminta, izinkan instalasi dari sumber tersebut.

CATATAN
- Paket ini adalah proyek Android Studio, belum berupa file APK yang sudah dikompilasi.
- Lingkungan pembuatan di sesi ini tidak memiliki Android SDK/Gradle, sehingga APK tidak dapat dikompilasi langsung di sini.
- Aplikasi memuat HTML secara lokal dan tidak memerlukan koneksi internet untuk fitur pencatatan.
- Data localStorage tersimpan di perangkat/browser aplikasi tersebut. Cadangkan data secara berkala melalui menu Unduh cadangan JSON.
