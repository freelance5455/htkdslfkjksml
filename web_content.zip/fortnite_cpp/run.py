#!/usr/bin/env python3
"""Baut die C++ Dateien und startet das Spiel.

Benutzung:
    python run.py          -> baut (falls noetig) und startet den Launcher
    python run.py game     -> startet direkt das Spiel
    python run.py rebuild  -> alles neu bauen, dann Launcher starten
    python run.py serve    -> oeffnet start.html im Browser; der START-Knopf dort
                              startet run.py (baut + startet das Spiel)
"""
import os
import platform
import shutil
import subprocess
import sys
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer

ROOT = os.path.dirname(os.path.abspath(__file__))
BUILD = os.path.join(ROOT, "build")
EXT = ".exe" if platform.system() == "Windows" else ""


def find(name):
    for sub in ("Release", "", "Debug"):
        p = os.path.join(BUILD, sub, name + EXT)
        if os.path.isfile(p):
            return p
    return None


def build():
    if not shutil.which("cmake"):
        sys.exit("CMake fehlt. Installiere CMake und einen C++ Compiler (Visual Studio / g++).")
    subprocess.check_call(["cmake", "-B", BUILD, "-S", ROOT], cwd=ROOT)
    subprocess.check_call(["cmake", "--build", BUILD, "--config", "Release"], cwd=ROOT)


STATE = {"v": "idle"}


def start_game():
    """Wird vom START-Knopf in start.html aufgerufen."""
    if STATE["v"] == "building":
        return
    try:
        if not (find("fortnite") and find("launcher")):
            STATE["v"] = "building"
            build()
        subprocess.Popen([find("fortnite"), "--start"], cwd=os.path.dirname(find("fortnite")))
        STATE["v"] = "running"
    except (subprocess.CalledProcessError, OSError, TypeError) as e:
        STATE["v"] = "error: " + str(e)


class Handler(BaseHTTPRequestHandler):
    def _send(self, body, ctype="text/plain"):
        data = body if isinstance(body, bytes) else body.encode()
        self.send_response(200)
        self.send_header("Content-Type", ctype + "; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if self.path == "/status":
            return self._send(STATE["v"])
        with open(os.path.join(ROOT, "start.html"), "rb") as f:
            self._send(f.read(), "text/html")

    def do_POST(self):
        if self.path == "/start":
            threading.Thread(target=start_game, daemon=True).start()
            STATE["v"] = "building" if not (find("fortnite") and find("launcher")) else STATE["v"]
        self._send("ok")

    def log_message(self, *a):
        pass


def serve():
    srv = HTTPServer(("127.0.0.1", 8765), Handler)  # nur lokal erreichbar
    print("Oeffne http://127.0.0.1:8765  (Strg+C zum Beenden)")
    webbrowser.open("http://127.0.0.1:8765")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


def main():
    arg = sys.argv[1] if len(sys.argv) > 1 else ""
    if arg == "serve":
        return serve()
    if arg == "rebuild" and os.path.isdir(BUILD):
        shutil.rmtree(BUILD)
    if arg == "rebuild" or not (find("fortnite") and find("launcher")):
        print("Baue die C++ Dateien ...")
        build()

    target = find("fortnite") if arg == "game" else find("launcher")
    if not target:
        sys.exit("Programm nicht gefunden. Versuche: python run.py rebuild")
    cmd = [target] + (["--start"] if arg == "game" else [])
    print("Starte", target)
    subprocess.Popen(cmd, cwd=os.path.dirname(target))


if __name__ == "__main__":
    main()
