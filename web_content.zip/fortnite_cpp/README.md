# Fortnite C++ (raylib)
Build:  cmake -B build && cmake --build build  ->  ./build/fortnite
Controls: WASD move | Mouse aim | LMB use item | 1 Pickaxe | 2 Rifle | Q / RMB build wall (10 wood)
Pickaxe: hit trees for wood. Walk over pickups. Stay inside the storm circle. Last one alive wins.

Start: run the 'launcher' program (build/Release/launcher.exe or ./build/launcher) and click START. It opens the game directly.
