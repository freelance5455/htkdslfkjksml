#include "raylib.h"
#include <cstdlib>
#include <string>

int main() {
    InitWindow(700, 520, "Fortnite C++ Launcher");
    SetTargetFPS(60);
    const std::string dir = GetApplicationDirectory();
#ifdef _WIN32
    const std::string exe = dir + "fortnite.exe";
#else
    const std::string exe = dir + "fortnite";
#endif
    std::string error;

    while (!WindowShouldClose()) {
        Rectangle btn{200, 110, 300, 70};
        bool hover = CheckCollisionPointRec(GetMousePosition(), btn);
        bool go = (hover && IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) || IsKeyPressed(KEY_ENTER);

        if (go) {
            if (!FileExists(exe.c_str())) {
                error = "Spiel nicht gefunden: " + exe;
            } else {
#ifdef _WIN32
                std::string cmd = "start \"\" \"" + exe + "\" --start";
#else
                std::string cmd = "\"" + exe + "\" --start &";
#endif
                std::system(cmd.c_str());
                break; // launcher schliesst sich, Spiel laeuft
            }
        }

        BeginDrawing();
        ClearBackground({40, 20, 90, 255});
        DrawText("FORTNITE C++", 150, 40, 56, WHITE);
        DrawRectangleRec(btn, hover ? Color{255, 229, 92, 255} : GOLD);
        DrawText("START", 275, 126, 40, {30, 30, 30, 255});

        DrawText("Steuerung", 60, 230, 26, YELLOW);
        DrawText("W A S D ........ Laufen", 60, 270, 22, WHITE);
        DrawText("Maus ........... Zielen", 60, 300, 22, WHITE);
        DrawText("Linksklick ..... Schiessen / Baum abbauen", 60, 330, 22, WHITE);
        DrawText("1 / 2 .......... Spitzhacke / Gewehr", 60, 360, 22, WHITE);
        DrawText("Q / Rechtsklick  Wand bauen (10 Holz)", 60, 390, 22, WHITE);
        DrawText("Ziel: Letzter Ueberlebender gewinnt. Bleib im Sturmkreis!", 60, 440, 20, LIGHTGRAY);
        if (!error.empty()) DrawText(error.c_str(), 20, 485, 18, RED);
        EndDrawing();
    }
    CloseWindow();
    return 0;
}
