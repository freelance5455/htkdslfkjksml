Tetris Web
==========
1. Ekstrak file zip ini.
2. Buka index.html di browser (Chrome, Firefox, Edge, Safari).
Tidak perlu internet atau instalasi apa pun.
