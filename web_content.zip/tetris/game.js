(() => {
'use strict';
const COLS = 10, ROWS = 20, S = 30;
const $ = id => document.getElementById(id);
const bctx = $('board').getContext('2d'), hctx = $('hold').getContext('2d'), nctx = $('next').getContext('2d');

// warna resmi Tetris Guideline
const COLORS = { I:'#29d3ff', O:'#ffe14d', T:'#c64dff', S:'#3ee06a', Z:'#ff3b3b', J:'#3b6bff', L:'#ff9f1c' };
const SHAPES = {
  I:[[0,0,0,0],[1,1,1,1],[0,0,0,0],[0,0,0,0]], O:[[1,1],[1,1]],
  T:[[0,1,0],[1,1,1],[0,0,0]], S:[[0,1,1],[1,1,0],[0,0,0]], Z:[[1,1,0],[0,1,1],[0,0,0]],
  J:[[1,0,0],[1,1,1],[0,0,0]], L:[[0,0,1],[1,1,1],[0,0,0]]
};
// tabel wall kick Super Rotation System (x, y dengan y ke atas, seperti standar)
const KJ = {'01':[0,0,-1,0,-1,1,0,-2,-1,-2],'10':[0,0,1,0,1,-1,0,2,1,2],'12':[0,0,1,0,1,-1,0,2,1,2],'21':[0,0,-1,0,-1,1,0,-2,-1,-2],
            '23':[0,0,1,0,1,1,0,-2,1,-2],'32':[0,0,-1,0,-1,-1,0,2,-1,2],'30':[0,0,-1,0,-1,-1,0,2,-1,2],'03':[0,0,1,0,1,1,0,-2,1,-2]};
const KI = {'01':[0,0,-2,0,1,0,-2,-1,1,2],'10':[0,0,2,0,-1,0,2,1,-1,-2],'12':[0,0,-1,0,2,0,-1,2,2,-1],'21':[0,0,1,0,-2,0,1,-2,-2,1],
            '23':[0,0,2,0,-1,0,2,1,-1,-2],'32':[0,0,-2,0,1,0,-2,-1,1,2],'30':[0,0,1,0,-2,0,1,-2,-2,1],'03':[0,0,-1,0,2,0,-1,2,2,-1]};
const NAMES = ['', 'SINGLE', 'DOUBLE', 'TRIPLE', 'TETRIS!'];

let grid, cur, hold, canHold, queue, bag;
let score, level, lines, best = 0, combo, b2b;
let state = 'idle', dropAcc = 0, last = 0, flash = [], lockT = 0, resets = 0, lowY = 0, lastRot = false, kick = 0, bt;
try { best = +localStorage.getItem('tetris-best') || 0; } catch (e) {}
$('best').textContent = best;

const rotate = (m, dir) => {
  const n = m.length, r = m.map(r => r.slice());
  for (let y = 0; y < n; y++) for (let x = 0; x < n; x++)
    r[dir > 0 ? x : n - 1 - x][dir > 0 ? n - 1 - y : y] = m[y][x];
  return r;
};
function refill() {
  const b = Object.keys(SHAPES);
  for (let i = b.length - 1; i > 0; i--) { const j = Math.random() * (i + 1) | 0; [b[i], b[j]] = [b[j], b[i]]; }
  bag.push(...b);
}
function take() {
  while (queue.length < 6) { if (!bag.length) refill(); queue.push(bag.shift()); }
  return queue.shift();
}
const solid = (x, y) => x < 0 || x >= COLS || y >= ROWS || (y >= 0 && !!grid[y][x]);
function collides(m, px, py) {
  for (let y = 0; y < m.length; y++) for (let x = 0; x < m.length; x++)
    if (m[y][x] && solid(px + x, py + y)) return true;
  return false;
}
const grounded = () => collides(cur.m, cur.x, cur.y + 1);
function spawn(type) {
  const m = SHAPES[type].map(r => r.slice());
  cur = { type, m, r: 0, x: ((COLS - m.length) / 2) | 0, y: type === 'I' ? -1 : 0 };
  lastRot = false; lockT = 0; resets = 0; dropAcc = 0; lowY = cur.y;
  if (collides(cur.m, cur.x, cur.y)) return gameOver();
  if (!grounded()) { cur.y++; lowY = cur.y; } // spawn langsung turun satu baris
}
function reset() {
  grid = Array.from({ length: ROWS }, () => Array(COLS).fill(null));
  queue = []; bag = []; hold = null; canHold = true; flash = [];
  score = 0; level = mode === 'road' ? ST[stage].lv : 1; lines = 0; combo = -1; b2b = false;
  spawn(take()); ui();
}
function ui() {
  $('score').textContent = score; $('level').textContent = level; $('lines').textContent = lines;
  $('best').textContent = best; coins();
  $('modeLabel').textContent = mode === 'road' ? `Tahap ${stage + 1} · ${lines}/${ST[stage].goal} baris · ${score}` : `Skor ${score} · Lv ${level}`;
}
// kecepatan jatuh standar Guideline: (0.8 - (level-1)*0.007)^(level-1) detik per baris
const gravity = () => 1000 * Math.pow(0.8 - (level - 1) * 0.007, level - 1);
function touch() {
  if (cur.y > lowY) { lowY = cur.y; resets = 0; }
  if (grounded()) { if (resets < 15) { lockT = 0; resets++; } } else lockT = 0;
}
function move(dx) {
  if (collides(cur.m, cur.x + dx, cur.y)) return;
  cur.x += dx; lastRot = false; touch();
}
function turn(dir) {
  if (cur.type === 'O') return;
  const nr = (cur.r + dir + 4) % 4, m = rotate(cur.m, dir), t = (cur.type === 'I' ? KI : KJ)['' + cur.r + nr];
  for (let i = 0; i < 5; i++) {
    const kx = t[i * 2], ky = -t[i * 2 + 1];
    if (!collides(m, cur.x + kx, cur.y + ky)) { cur.m = m; cur.x += kx; cur.y += ky; cur.r = nr; lastRot = true; kick = i; touch(); return; }
  }
}
function softDrop() {
  if (grounded()) return;
  cur.y++; score++; lastRot = false; dropAcc = 0; touch(); ui();
}
function hardDrop() {
  let d = 0;
  while (!grounded()) { cur.y++; d++; }
  if (d) lastRot = false;
  score += d * 2; lock();
}
function ghostY() { let y = cur.y; while (!collides(cur.m, cur.x, y + 1)) y++; return y; }
function doHold() {
  if (!canHold) return;
  const t = cur.type;
  if (hold) { const h = hold; hold = t; spawn(h); } else { hold = t; spawn(take()); }
  canHold = false;
}
function burst(t) {
  const b = $('burst'); b.innerHTML = t; b.classList.remove('go'); void b.offsetWidth; b.classList.add('go');
  clearTimeout(bt); bt = setTimeout(() => b.classList.remove('go'), 1000);
}

function lock() {
  // deteksi T-Spin (aturan 3 sudut)
  let ts = 0;
  if (cur.type === 'T' && lastRot) {
    const cs = [[0,0],[2,0],[0,2],[2,2]].map(([a, b]) => solid(cur.x + a, cur.y + b));
    const fr = [[0,1],[1,3],[2,3],[0,2]][cur.r];
    if (cs.filter(Boolean).length >= 3) ts = (cs[fr[0]] && cs[fr[1]]) || kick === 4 ? 2 : 1;
  }
  cur.m.forEach((row, y) => row.forEach((v, x) => { if (v && cur.y + y >= 0) grid[cur.y + y][cur.x + x] = cur.type; }));
  const full = [];
  grid.forEach((r, i) => { if (r.every(Boolean)) full.push(i); });
  full.forEach(i => { grid.splice(i, 1); grid.unshift(Array(COLS).fill(null)); });
  const n = full.length;
  let pts = (ts ? (ts === 2 ? [400, 800, 1200, 1600] : [100, 200, 400, 400])[n] : [0, 100, 300, 500, 800][n]) * level;
  let tag = '';
  if (n) {
    combo++;
    const hard = n === 4 || ts;
    if (hard && b2b) { pts = pts * 1.5 | 0; tag += '<small>BACK-TO-BACK</small>'; }
    b2b = hard; pts += 50 * combo * level;
    if (combo > 0) tag += `<small>COMBO ×${combo}</small>`;
    flash = full; setTimeout(() => flash = [], 160);
  } else combo = -1;
  if (n || ts) burst((ts ? (ts === 2 ? 'T-SPIN ' : 'MINI T-SPIN ') : '') + (NAMES[n] || '!') + (tag ? '<br>' + tag : ''));
  score += pts; lines += n;
  if (mode === 'free') level = 1 + (lines / 10 | 0);
  if (score > best) { best = score; try { localStorage.setItem('tetris-best', best); } catch (e) {} }
  ui();
  if (mode === 'road' && lines >= ST[stage].goal) { state = 'won'; setTimeout(win, 500); return; }
  canHold = true;
  spawn(take());
}

function gameOver() {
  state = 'over';
  const earn = score / (mode === 'road' ? 40 : 25) | 0;
  save.coins += earn; persist(); ui();
  showOverlay(mode === 'road' ? 'Belum berhasil' : 'Game over', `Skor <b>${score}</b> · +${earn} koin`, 'Main lagi');
}
function showOverlay(h, p, b, fn) {
  const o = $('overlay');
  o.querySelector('h1').textContent = h;
  o.querySelector('p').innerHTML = p;
  $('startBtn').textContent = b;
  primary = fn || (() => start());
  o.classList.remove('hidden');
}
function start() {
  if (state === 'pause') { state = 'play'; $('overlay').classList.add('hidden'); return; }
  reset(); state = 'play'; $('overlay').classList.add('hidden');
}
function togglePause() {
  if (state === 'play') { state = 'pause'; showOverlay('Jeda', 'Tekan <b>P</b> untuk lanjut', 'Lanjut'); }
  else if (state === 'pause') start();
}

// ===== gambar bergaya komik =====
function cell(c, px, py, color, a = 1, s = S) {
  c.globalAlpha = a;
  c.fillStyle = color; c.fillRect(px, py, s, s);
  c.fillStyle = 'rgba(255,255,255,.6)';
  c.fillRect(px + s * .15, py + s * .15, s * .5, s * .15); c.fillRect(px + s * .15, py + s * .15, s * .15, s * .5);
  c.fillStyle = 'rgba(0,0,0,.2)'; c.fillRect(px + s * .72, py + s * .3, s * .14, s * .56);
  c.strokeStyle = '#111'; c.lineWidth = Math.max(2, s / 10);
  c.strokeRect(px + c.lineWidth / 2, py + c.lineWidth / 2, s - c.lineWidth, s - c.lineWidth);
  c.globalAlpha = 1;
}
function mini(c, type, ox, oy, s) {
  const m = SHAPES[type]; let x0 = 9, x1 = 0, y0 = 9, y1 = 0;
  m.forEach((r, y) => r.forEach((v, x) => { if (v) { x0 = Math.min(x0, x); x1 = Math.max(x1, x); y0 = Math.min(y0, y); y1 = Math.max(y1, y); } }));
  const bx = ox - (x1 - x0 + 1) * s / 2, by = oy - (y1 - y0 + 1) * s / 2;
  m.forEach((r, y) => r.forEach((v, x) => { if (v) cell(c, bx + (x - x0) * s, by + (y - y0) * s, COLORS[type], 1, s); }));
}
function draw() {
  const c = bctx; c.clearRect(0, 0, 300, 600);
  c.strokeStyle = 'rgba(255,255,255,.07)'; c.lineWidth = 1;
  for (let x = 1; x < COLS; x++) { c.beginPath(); c.moveTo(x * S, 0); c.lineTo(x * S, 600); c.stroke(); }
  for (let y = 1; y < ROWS; y++) { c.beginPath(); c.moveTo(0, y * S); c.lineTo(300, y * S); c.stroke(); }
  hctx.clearRect(0, 0, 96, 96); nctx.clearRect(0, 0, 96, 360);
  if (!grid) return;
  grid.forEach((r, y) => r.forEach((t, x) => { if (t) cell(c, x * S, y * S, COLORS[t]); }));
  if (state === 'play' || state === 'pause') {
    const gy = ghostY();
    cur.m.forEach((r, y) => r.forEach((v, x) => { if (v && gy + y >= 0) cell(c, (cur.x + x) * S, (gy + y) * S, COLORS[cur.type], .25); }));
    cur.m.forEach((r, y) => r.forEach((v, x) => { if (v && cur.y + y >= 0) cell(c, (cur.x + x) * S, (cur.y + y) * S, COLORS[cur.type]); }));
  }
  flash.forEach(y => { c.fillStyle = 'rgba(255,255,255,.85)'; c.fillRect(0, y * S, 300, S); });
  if (hold) mini(hctx, hold, 48, 48, 20);
  queue.slice(0, 5).forEach((t, i) => mini(nctx, t, 48, 36 + i * 72, 18));
}
function loop(t) {
  const dt = Math.min(100, t - last); last = t;
  if (state === 'play') {
    if (grounded()) { lockT += dt; dropAcc = 0; if (lockT >= 500) lock(); }
    else {
      dropAcc += dt; const g = gravity();
      for (let n = 0; dropAcc >= g && n < ROWS && !grounded(); n++) { cur.y++; dropAcc -= g; lastRot = false; }
      if (cur.y > lowY) { lowY = cur.y; resets = 0; }
      if (grounded()) { lockT = 0; dropAcc = 0; }
    }
  }
  draw();
  requestAnimationFrame(loop);
}

// ===== kontrol (DAS 160ms, ARR 33ms) =====
const held = {}, DAS = 160, ARR = 33;
function act(a) {
  if (state !== 'play') return;
  ({ left: () => move(-1), right: () => move(1), rot: () => turn(1), rotb: () => turn(-1),
     down: softDrop, drop: hardDrop, hold: doHold })[a]();
}
const KEYMAP = { ArrowLeft:'left', ArrowRight:'right', ArrowUp:'rot', x:'rot', X:'rot', z:'rotb', Z:'rotb',
  ArrowDown:'down', ' ':'drop', c:'hold', C:'hold', Shift:'hold' };
addEventListener('keydown', e => {
  if (e.key === 'Enter' && screen === 'game' && ['idle', 'over', 'won'].includes(state)) return primary();
  if (e.key === 'p' || e.key === 'P' || e.key === 'Escape') return togglePause();
  const a = KEYMAP[e.key]; if (!a) return;
  e.preventDefault();
  if (e.repeat) return;
  act(a);
  if (a === 'left' || a === 'right' || a === 'down') {
    clearInterval(held[a]); clearTimeout(held[a + 't']);
    held[a + 't'] = setTimeout(() => { held[a] = setInterval(() => act(a), a === 'down' ? 30 : ARR); }, a === 'down' ? 0 : DAS);
  }
});
addEventListener('keyup', e => {
  const a = KEYMAP[e.key]; if (!a) return;
  clearInterval(held[a]); clearTimeout(held[a + 't']);
});
$('startBtn').addEventListener('click', () => primary());
// gestur sentuh seperti Tetris di HP: ketuk = putar, geser = pindah, tarik ke bawah = turun,
// sentak ke bawah = jatuh langsung, geser ke atas = simpan
(() => {
  const el = $('sg'); let t = null;
  const cw = () => $('board').getBoundingClientRect().width / COLS;
  el.addEventListener('pointerdown', e => {
    if (e.pointerType === 'mouse' || e.target.closest('.bar,.overlay')) return;
    const n = performance.now();
    t = { id: e.pointerId, sx: e.clientX, sy: e.clientY, ax: e.clientX, ay: e.clientY, t0: n, moved: false, pts: [[e.clientY, n]] };
    el.setPointerCapture(e.pointerId);
  });
  el.addEventListener('pointermove', e => {
    if (!t || e.pointerId !== t.id) return;
    const c = cw();
    t.pts.push([e.clientY, performance.now()]); if (t.pts.length > 6) t.pts.shift();
    if (Math.hypot(e.clientX - t.sx, e.clientY - t.sy) > 12) t.moved = true;
    while (e.clientX - t.ax >= c) { act('right'); t.ax += c; }
    while (t.ax - e.clientX >= c) { act('left'); t.ax -= c; }
    if (e.clientY < t.ay) t.ay = e.clientY;
    while (e.clientY - t.ay >= c) { act('down'); t.ay += c; }
  });
  el.addEventListener('pointerup', e => {
    if (!t || e.pointerId !== t.id) return;
    const n = performance.now(), c = cw(), dx = e.clientX - t.sx, dy = e.clientY - t.sy;
    const p = t.pts[0], vy = (e.clientY - p[0]) / Math.max(1, n - p[1]);
    if (!t.moved && n - t.t0 < 350) act('rot');
    else if (dy > c * 2.5 && vy > 0.9 && Math.abs(dx) < dy * .6) act('drop');
    else if (dy < -c * 2.5 && Math.abs(dx) < -dy * .6) act('hold');
    t = null;
  });
  el.addEventListener('pointercancel', () => { t = null; });
  $('overlay').addEventListener('click', e => { if (!e.target.closest('button')) primary(); });
})();
addEventListener('blur', () => { if (state === 'play') togglePause(); });

// ===== Jalan, Kota, simpanan =====
const ST = Array.from({ length: 10 }, (_, i) => ({ goal: 8 + i * 2, lv: 1 + i }));
let mode = 'free', stage = 0, screen = 'menu', primary = () => start();
let save = { coins: 0, open: 1, stars: [], town: {} };
try { Object.assign(save, JSON.parse(localStorage.getItem('tetris-save') || '{}')); } catch (e) {}
const persist = () => { try { localStorage.setItem('tetris-save', JSON.stringify(save)); } catch (e) {} };
function coins() { document.querySelectorAll('.coinv').forEach(e => e.textContent = save.coins); }

const HINT = matchMedia('(pointer:coarse)').matches
  ? 'Ketuk: putar · Geser: pindah · Tarik ke bawah: turun · Sentak ke bawah: jatuh · Geser ke atas: simpan'
  : '← → pindah · ↑ putar · ↓ turun · Spasi jatuh · C simpan · P jeda';
function show(n) {
  screen = n; if (n !== 'game') state = 'idle';
  ['menu', 'road', 'town', 'game'].forEach(k => $('s' + k[0]).hidden = k !== n);
  coins();
  if (n === 'road') renderRoad();
  if (n === 'town') renderTown();
}
function openGame(m, s) {
  mode = m; stage = s || 0; show('game'); reset(); state = 'idle';
  showOverlay(m === 'road' ? 'Tahap ' + (stage + 1) : 'Mode Bebas',
    m === 'road' ? `Hapus <b>${ST[stage].goal}</b> baris untuk lanjut.<br>Kecepatan level ${ST[stage].lv}.<br><small>${HINT}</small>` : `Main sampai habis. Level naik tiap 10 baris.<br><small>${HINT}</small>`, 'Mulai');
}
function win() {
  const g = ST[stage].goal, st = 1 + (score >= g * 250) + (score >= g * 400);
  const earn = 30 + stage * 10 + (score / 25 | 0);
  save.stars[stage] = Math.max(save.stars[stage] || 0, st);
  save.open = Math.max(save.open, Math.min(10, stage + 2));
  save.coins += earn; persist(); ui();
  const last = stage >= 9;
  showOverlay('Tahap selesai!', `<span style="font-size:1.6rem;color:var(--red)">${'★'.repeat(st)}${'☆'.repeat(3 - st)}</span><br>+${earn} koin`,
    last ? 'Ke peta' : 'Tahap berikut', last ? () => show('road') : () => openGame('road', stage + 1));
}
document.addEventListener('click', e => {
  const b = e.target.closest('[data-go]');
  if (b) return b.dataset.go === 'free' ? openGame('free') : show(b.dataset.go);
  const n = e.target.closest('g[data-i]');
  if (n && +n.dataset.i < save.open) openGame('road', +n.dataset.i);
});
$('menuTop').addEventListener('click', () => show(mode === 'road' ? 'road' : 'menu'));
$('menuBtn').addEventListener('click', () => show(mode === 'road' ? 'road' : 'menu'));

function renderRoad() {
  const H = 60 + 9 * 84 + 60, pos = i => [180 + 85 * Math.sin(i * 1.3), H - 60 - i * 84];
  const pts = ST.map((_, i) => pos(i).join(',')).join(' ');
  let s = `<svg viewBox="0 0 360 ${H}"><polyline points="${pts}" fill="none" stroke="#111" stroke-width="38" stroke-linecap="round" stroke-linejoin="round"/>
  <polyline points="${pts}" fill="none" stroke="#ffd23f" stroke-width="28" stroke-linecap="round"/>`;
  ST.forEach((t, i) => {
    const [x, y] = pos(i), ok = i < save.open, done = save.stars[i], cur = ok && !done;
    const fill = done ? '#3ddc84' : cur ? '#ff3b3b' : '#cfd6e4';
    s += `<g data-i="${i}"><circle cx="${x}" cy="${y}" r="24" fill="${fill}" stroke="#10141f" stroke-width="4"/>
    <text x="${x}" y="${y + 6}" text-anchor="middle" font-size="17" font-weight="700" fill="${ok ? '#111' : '#667'}">${ok ? i + 1 : '🔒'}</text>
    <text x="${x}" y="${y + 42}" text-anchor="middle" font-size="12" fill="#d11">${ok ? '★'.repeat(done || 0) + '☆'.repeat(3 - (done || 0)) : ''}</text></g>`;
  });
  $('road').innerHTML = s + '</svg>';
  $('road').scrollTop = 9999;
}

const BD = [['house', 'Rumah', 60], ['shop', 'Toko', 90], ['tower', 'Menara Jam', 130], ['fountain', 'Air Mancur', 110], ['trees', 'Taman', 50], ['lamps', 'Lampu Jalan', 40]];
const price = (b, l) => b[2] * [1, 2, 4][l];
function scene() {
  const L = k => save.town[k] || 0, plot = (x, w) => `<rect x="${x}" y="140" width="${w}" height="10" fill="none" stroke="#8fb996" stroke-dasharray="4 3" rx="2"/>`;
  const total = Object.values(save.town).reduce((a, b) => a + b, 0), glow = total >= 9;
  let s = `<defs><linearGradient id="sk" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${glow ? '#34406e' : '#4a6fa5'}"/><stop offset="1" stop-color="${glow ? '#f2a65a' : '#bcd9ec'}"/></linearGradient></defs>
  <rect width="360" height="220" fill="url(#sk)"/><circle cx="318" cy="38" r="16" fill="#ffe08a"/><rect y="150" width="360" height="70" fill="#37693f"/><rect y="176" width="360" height="30" fill="#3b4252"/><path d="M0 191H360" stroke="#d8dee9" stroke-width="2" stroke-dasharray="12 10"/>`;
  let l = L('house'); s += l ? `<rect x="14" y="${150 - 18 - l * 14}" width="70" height="${18 + l * 14}" fill="#e8c9a0"/><polygon points="8,${150 - 18 - l * 14} 49,${150 - 42 - l * 14} 90,${150 - 18 - l * 14}" fill="#b5523b"/>${[...Array(l)].map((_, i) => `<rect x="${22 + i * 20}" y="${150 - 8 - l * 14 + (i % 2) * 6}" width="12" height="10" fill="#fff3b0"/>`).join('')}<rect x="60" y="130" width="12" height="20" fill="#7a4b2a"/>` : plot(14, 70);
  l = L('shop'); s += l ? `<rect x="100" y="${150 - 22 - l * 10}" width="66" height="${22 + l * 10}" fill="#8ecae6"/>${l > 1 ? `<rect x="96" y="${150 - 14 - l * 10}" width="74" height="9" fill="#e5484d"/>` : ''}<rect x="126" y="132" width="16" height="18" fill="#264653"/>${l > 2 ? `<rect x="112" y="${150 - 40 - 10}" width="42" height="10" fill="#ffb62e"/>` : ''}` : plot(100, 66);
  l = L('tower'); s += l ? `<rect x="184" y="${150 - 30 - l * 26}" width="30" height="${30 + l * 26}" fill="#cbd5e1"/><polygon points="180,${150 - 30 - l * 26} 199,${150 - 52 - l * 26} 218,${150 - 30 - l * 26}" fill="#6b4e9b"/>${l > 1 ? `<circle cx="199" cy="${150 - 14 - l * 26}" r="9" fill="#fff" stroke="#334"/><path d="M199 ${150 - 14 - l * 26}v-6m0 0 4 4" stroke="#334" stroke-width="1.5"/>` : ''}${l > 2 ? `<path d="M199 ${150 - 52 - l * 26}v-14" stroke="#334"/><path d="M199 ${150 - 66 - l * 26}h14l-4 4 4 4h-14z" fill="#e5484d"/>` : ''}` : plot(184, 30);
  l = L('fountain'); s += l ? `<ellipse cx="250" cy="148" rx="24" ry="7" fill="#6b7a99"/><ellipse cx="250" cy="146" rx="20" ry="5" fill="#5ec8f2"/>${[...Array(l)].map((_, i) => `<path d="M250 146 q${(i - (l - 1) / 2) * 9} ${-12 - l * 6} ${(i - (l - 1) / 2) * 18} 0" fill="none" stroke="#bdeaff" stroke-width="2"/>`).join('')}` : plot(226, 48);
  l = L('trees'); s += l ? [...Array(l)].map((_, i) => `<rect x="${302 + i * 20}" y="132" width="5" height="18" fill="#6b4a2b"/><circle cx="${304.5 + i * 20}" cy="126" r="${11 + i}" fill="#3f9b4b"/>`).join('') : plot(292, 62);
  l = L('lamps'); if (l) [60, 150, 235, 330].slice(0, l + 1).forEach(x => { s += `<rect x="${x}" y="156" width="3" height="22" fill="#222"/>${l > 2 ? `<circle cx="${x + 1.5}" cy="154" r="14" fill="#ffe08a" opacity=".3"/>` : ''}<circle cx="${x + 1.5}" cy="154" r="4" fill="#ffe08a"/>`; });
  return s;
}
function renderTown() {
  $('scene').innerHTML = scene();
  const total = Object.values(save.town).reduce((a, b) => a + b, 0);
  $('ttitle').textContent = ['Dusun', 'Desa', 'Kota Kecil', 'Kota Megah', 'Kota Impian'][total < 4 ? 0 : total < 9 ? 1 : total < 14 ? 2 : total < 18 ? 3 : 4] + ` · Lv ${total}/18`;
  $('shop').innerHTML = BD.map(b => {
    const l = save.town[b[0]] || 0, max = l >= 3, p = max ? 0 : price(b, l);
    return `<div class="item"><span>${b[1]}</span><i>${'●'.repeat(l)}${'○'.repeat(3 - l)}</i><button data-b="${b[0]}" ${max || save.coins < p ? 'disabled' : ''}>${max ? 'Maksimal' : (l ? 'Tingkatkan ' : 'Bangun ') + '🪙' + p}</button></div>`;
  }).join('');
}
$('shop').addEventListener('click', e => {
  const k = e.target.closest('button[data-b]')?.dataset.b; if (!k) return;
  const b = BD.find(x => x[0] === k), l = save.town[k] || 0;
  if (l >= 3 || save.coins < price(b, l)) return;
  save.coins -= price(b, l); save.town[k] = l + 1; persist(); coins(); renderTown();
});

show('menu');
queue = []; bag = [];
requestAnimationFrame(loop);
})();
