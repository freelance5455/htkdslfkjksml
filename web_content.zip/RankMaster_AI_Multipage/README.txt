RANKMASTER AI — MULTI-PAGE HTML APP
Open index.html in a browser to start.
Keep all files and the assets folder together; the pages share assets/style.css and assets/app.js.
For Android APK: copy this folder's contents into app/src/main/assets/ and load file:///android_asset/index.html in a WebView.
The profile, progress, coins and session history are stored locally in the browser/WebView localStorage.
The offline Study Companion creates structured templates; it is not a live AI connection.
