
const STORE='rankmaster_multipage_v2';
const BASE={goal:'JEE',coins:0,profile:{name:'',handle:'',bio:'',stage:'Class 11',goal:'JEE',batch:'',batchStart:'',lectureTime:'',target:240,avatar:''},progress:{'Class lectures & notes':0,'Coaching modules & DPPs':0,'Revision loops':0,'Past 5 years PYQs':0,'Mock tests & analysis':0},sessions:[],milestones:[],questions:0,streak:0,lastDay:'',todaySeconds:0,todayQuestions:0};
let state;try{state={...BASE,...JSON.parse(localStorage.getItem(STORE)||'{}')}}catch(e){state=structuredClone(BASE)}
function persist(){localStorage.setItem(STORE,JSON.stringify(state));refreshShared()}
function toast(s){let t=document.getElementById('toast');if(t){t.textContent=s;t.style.display='block';setTimeout(()=>t.style.display='none',2300)}}
function refreshShared(){document.querySelectorAll('.coinBalance').forEach(x=>x.textContent=state.coins.toLocaleString('en-IN'));document.querySelectorAll('[data-goal]').forEach(b=>{b.classList.toggle('active',b.dataset.goal===state.goal)})}
document.querySelectorAll('[data-goal]').forEach(b=>b.addEventListener('click',()=>{state.goal=b.dataset.goal;state.profile.goal=state.goal;persist();toast('Study theme changed to '+state.goal)}));
const tiers=[[1000,'Student Master','✨'],[2500,'Scholar Scout','🎖️'],[5000,'Brainiac Boss','🧠'],[10000,'Knowledge Knight','⚔️'],[25000,'Academic Ace','🏆'],[50000,'Wisdom Wizard','🧙‍♂️'],[100000,'Ultimate Einstein','⚛️']];
function currentTier(){return [...tiers].reverse().find(t=>state.coins>=t[0])}
function refreshShared(){document.querySelectorAll('.coinBalance').forEach(x=>x.textContent=state.coins.toLocaleString('en-IN'));document.querySelectorAll('[data-goal]').forEach(b=>b.classList.toggle('active',b.dataset.goal===state.goal))}
refreshShared();
const page=location.pathname.split('/').pop()||'index.html';
if(page==='index.html'){let p=state.profile;document.getElementById('greeting').textContent=p.name?`Your next rank starts today, ${p.name}.`:'Your next rank starts today.';document.getElementById('coinStat').textContent=state.coins.toLocaleString('en-IN');document.getElementById('streakStat').textContent=state.streak;document.getElementById('questionStat').textContent=state.questions;document.getElementById('todayQStat').textContent=state.todayQuestions;document.getElementById('todayStat').textContent=Math.floor(state.todaySeconds/60)+' min';document.getElementById('todayBar').style.width=Math.min(100,state.todaySeconds/60/(p.target||240)*100)+'%';document.getElementById('questionBar').style.width=Math.min(100,state.todayQuestions/40*100)+'%';let t=currentTier();document.getElementById('tierStat').textContent=t?`${t[2]} ${t[1]} unlocked`:'Next milestone: Student Master at 1,000 J-Coins';document.getElementById('badgeGallery').innerHTML=tiers.map(t=>`<div class="badge"><b>${t[2]} ${t[1]}</b><small>${t[0].toLocaleString('en-IN')} J-Coins · ${state.coins>=t[0]?'Unlocked':'Locked'}</small></div>`).join('')}
if(page==='focus.html'){
 let mode=new URLSearchParams(location.search).get('mode')||'Question Practice',running=false,paused=false,elapsed=0,startAt=0,sessionStart=0,questions=0,coinMilestones=new Set(),timerId=null;
 const $=id=>document.getElementById(id);let timer=$('timer'),status=$('focusStatus');
 document.querySelectorAll('[data-mode]').forEach(b=>{b.classList.toggle('active',b.dataset.mode===mode);b.onclick=()=>{mode=b.dataset.mode;document.querySelectorAll('[data-mode]').forEach(x=>x.classList.toggle('active',x===b));$('solveBtn').classList.toggle('hidden',mode!=='Question Practice')}});$('solveBtn').classList.toggle('hidden',mode!=='Question Practice');
 function seconds(){return elapsed+(running?Math.floor((Date.now()-startAt)/1000):0)}
 function fmt(s){return [Math.floor(s/3600),Math.floor(s%3600/60),s%60].map(n=>String(n).padStart(2,'0')).join(':')}
 function update(){let s=seconds();timer.textContent=fmt(s);$('qCount').textContent=`Question ${questions} completed`;if(running){let awardAt=s<300?([120,240].includes(s)?s:0):(s>=360&&s%60===0?s:0);if(awardAt&&!coinMilestones.has(awardAt)){coinMilestones.add(awardAt);state.coins+=100;persist();toast('+100 J-Coins earned!')}}}
 function controls(){$('startBtn').disabled=running;$('pauseBtn').disabled=!running;$('stopBtn').disabled=!sessionStart}
 $('startBtn').onclick=()=>{if(running)return;if(!sessionStart){sessionStart=Date.now();elapsed=0;questions=0;coinMilestones=new Set()}running=true;paused=false;startAt=Date.now();status.textContent=paused?'Session resumed':'Session running';timerId=setInterval(update,250);controls();update()};
 $('pauseBtn').onclick=()=>{if(!running)return;elapsed=seconds();running=false;paused=true;clearInterval(timerId);status.textContent='Paused';controls();update()};
 $('stopBtn').onclick=()=>{if(!sessionStart)return;let s=seconds();running=false;clearInterval(timerId);let subject=$('subject').value,chapter=$('chapter').value.trim()||'General study';state.sessions.unshift({date:new Date().toLocaleString(),subject,chapter,mode,seconds:s,questions,note:$('note').value});state.todaySeconds+=s;state.todayQuestions+=questions;state.questions+=questions;let day=new Date().toDateString();if(state.lastDay!==day){state.streak=state.lastDay===new Date(Date.now()-86400000).toDateString()?state.streak+1:1;state.lastDay=day}persist();sessionStart=0;elapsed=0;questions=0;timer.textContent='00:00:00';status.textContent='Session saved';controls();drawSessions();toast('Session saved')};
 $('solveBtn').onclick=()=>{if(!running||mode!=='Question Practice')return;questions++;$('qCount').textContent=`Question ${questions} completed`;toast('Question recorded')};
 function drawSessions(){$('sessionHistory').innerHTML=state.sessions.length?state.sessions.slice(0,8).map(s=>`<div class="row"><span><b>${s.subject} · ${s.chapter}</b><small class="muted" style="display:block">${s.mode} · ${s.date} · ${fmt(s.seconds)}</small></span><b>${s.questions} Q</b></div>`).join(''):'No saved sessions yet.'}drawSessions();controls();
}
if(page==='profile.html'){
 const $=id=>document.getElementById(id),p=state.profile;
 function draw(){
  $('profileName').textContent=p.name||'Create your student profile';
  $('profileHandle').textContent=p.handle?'@'+p.handle.replace(/^@/,''):'@yourhandle';
  $('profileBio').textContent=p.bio||'Your learning journey, milestones and achievements live here.';
  $('profileStreak').textContent=state.streak;$('profileCoins').textContent=state.coins.toLocaleString('en-IN');
  $('postCount').textContent=state.milestones.length;$('avatarPreview').src=p.avatar||'assets/rankmaster-icon.jpg';
  let t=currentTier();$('masterTag').textContent=t?`${t[2]} ${t[1]}`:'';
  $('milestoneFeed').innerHTML=state.milestones.length?state.milestones.map(m=>`<div class="feeditem"><b>🏆 ${safe(m.title)}</b><p class="muted">${safe(m.note)}</p><small class="muted">${safe(m.date)}</small></div>`).join(''):'Your study achievements will appear here.';
 }
 function safe(s){return String(s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
 function openEditor(){
  $('editName').value=p.name||'';$('editHandle').value=p.handle||'';$('editBio').value=p.bio||'';
  $('editStage').value=p.stage||'Class 11';$('editGoal').value=p.goal||state.goal;
  $('editBatch').value=p.batch||'';$('editBatchStart').value=p.batchStart||'';
  $('editLectureTime').value=p.lectureTime||'';$('editTarget').value=p.target||240;
  $('profileEditor').classList.remove('hidden');
 }
 $('editProfile').onclick=openEditor;
 $('closeEditor').onclick=()=>$('profileEditor').classList.add('hidden');
 $('saveProfile').onclick=()=>{
  p.name=$('editName').value.trim();p.handle=$('editHandle').value.trim().replace(/^@/,'');
  p.bio=$('editBio').value.trim();p.stage=$('editStage').value;p.goal=$('editGoal').value;
  p.batch=$('editBatch').value.trim();p.batchStart=$('editBatchStart').value;
  p.lectureTime=$('editLectureTime').value.trim();p.target=Math.max(15,Number($('editTarget').value)||240);
  state.goal=p.goal;
  let file=$('editAvatar').files[0];
  const finish=()=>{persist();draw();$('profileEditor').classList.add('hidden');toast('Profile saved successfully')};
  if(file){let reader=new FileReader();reader.onload=()=>{p.avatar=reader.result;finish()};reader.readAsDataURL(file)}else finish();
 };
 $('addMilestone').onclick=()=>{let title=prompt('Milestone title');if(!title)return;let note=prompt('What did you achieve?','Completed a focused study target.')||'';state.milestones.unshift({title,note,date:new Date().toLocaleDateString()});persist();draw()};
 $('exportBackup').onclick=()=>download('RankMaster_Backup.json',JSON.stringify(state,null,2),'application/json');
 $('importBackup').onclick=()=>$('backupFile').click();
 $('backupFile').onchange=e=>{let f=e.target.files[0];if(!f)return;let r=new FileReader();r.onload=()=>{try{state={...BASE,...JSON.parse(r.result)};localStorage.setItem(STORE,JSON.stringify(state));location.reload()}catch(x){toast('Invalid backup file')}};r.readAsText(f)};
 draw();if(!p.name)setTimeout(openEditor,350);
}
if(page==='readiness.html'){let rows=document.getElementById('readinessRows');function draw(){rows.innerHTML=Object.entries(state.progress).map(([k,v])=>`<div style="margin:15px 0"><div class="progresslabel"><b>${k}</b><b>${v}%</b></div><div class="bar"><i style="width:${v}%"></i></div></div>`).join('');document.getElementById('dropperWarning').classList.toggle('hidden',state.profile.stage!=='Dropper')}document.getElementById('editProgress').onclick=()=>{for(let k of Object.keys(state.progress)){let val=prompt(k+' completion %',state.progress[k]);if(val!==null&&val.trim()!==''&&Number.isFinite(+val))state.progress[k]=Math.max(0,Math.min(100,+val))}persist();draw()};draw()}
if(page==='companion.html'){document.getElementById('companionHeading').textContent='STUDY '+state.goal;document.getElementById('generateGuide').onclick=()=>{let topic=document.getElementById('companionTopic').value||'your selected chapter',task=document.getElementById('companionTask').value;let out={doubt:`DOUBT BREAKDOWN — ${topic}\n1. Identify the exact concept involved.\n2. List the known values and conditions.\n3. Write the relevant definition, law or formula.\n4. Solve one step at a time and check units/signs.\n5. Verify the result and note the key learning.`,quiz:`PRACTICE SET — ${topic}\n1. One basic concept question.\n2. Two application questions.\n3. One multi-step exam-style problem.\n4. One assertion-reason question.\n5. One question asking why a distractor is wrong.\nReview every answer using your class notes.`,backlog:`7-DAY BACKLOG PLAN — ${topic}\nDay 1: Map subtopics and learn core idea.\nDay 2: Complete concepts and notes.\nDay 3: Work through examples and DPP.\nDay 4: Solve topic-wise PYQs.\nDay 5: Revisit weak concepts.\nDay 6: Take a timed mini-test.\nDay 7: Reattempt errors and revise.`,recall:`ACTIVE RECALL — ${topic}\n• Explain the topic without looking.\n• List five key facts or formulas.\n• State the conditions where each applies.\n• Explain one common misconception.\n• Teach the concept in 60 seconds.`};document.getElementById('guideOutput').textContent=out[task]}}
function download(name,content,type){let a=document.createElement('a'),u=URL.createObjectURL(new Blob([content],{type}));a.href=u;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(u),1000)}
