import assert from 'node:assert/strict';
import { entrySide, entryEffect, calculateBalance, signedOpening, legacyEntriesNeedingReview } from './accounting-engine.js';
const motorAndFertilizer = [
  { id: '1', date: '2026-10-01', type: 'motorBill', amount: 720, side: 'dr' },
  { id: '2', date: '2026-10-02', type: 'fertilizer', amount: 600, side: 'cr' }
];
assert.equal(calculateBalance(motorAndFertilizer, 0, 'farmer').closingBalance, 120, 'Motor 720 Dr minus Fertilizer 600 Cr = 120 Dr');
assert.equal(calculateBalance([{ type: 'tractor', amount: 100, side: 'dr' }, { type: 'cash', amount: 150, side: 'cr' }]).closingBalance, -50, 'Credit exceeding debit yields Cr');
assert.equal(calculateBalance([{ type: 'workerWage', amount: 3000, side: 'cr' }, { type: 'workerAdvance', amount: 1000, side: 'dr' }], 0, 'staff').closingBalance, -2000, 'Worker 3000 Cr less 1000 Dr leaves 2000 Cr payable');
assert.equal(entrySide({ type: 'cash' }), 'cr', 'cash received defaults Cr');
assert.equal(entrySide({ type: 'cashPaid' }), 'dr', 'cash paid defaults Dr');
assert.equal(entrySide({ type: 'adjust', side: 'dr' }), 'dr', 'adjustment supports Dr');
assert.equal(entrySide({ type: 'adjust', side: 'cr' }), 'cr', 'adjustment supports Cr');
assert.deepEqual(entryEffect({ amount: 4, side: 'dr' }), { debit: 4, credit: 0 });
assert.equal(signedOpening(125, 'cr'), -125, 'opening balance Cr is represented as negative');
assert.equal(calculateBalance([{ type: 'tractor', amount: 200, side: 'dr' }], { amount: 50, side: 'cr' }).closingBalance, 150);
assert.equal(legacyEntriesNeedingReview([{ type: 'spray', amount: 20 }, { type: 'fertilizer', amount: 30, side: 'cr' }, { type: 'motor', amount: 5 }]).length, 2, 'ambiguous legacy entries are flagged, not rewritten');
console.log('All accounting engine acceptance tests passed.');
