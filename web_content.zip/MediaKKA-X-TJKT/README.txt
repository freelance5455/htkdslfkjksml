MEDIA INTERAKTIF KKA - KELAS X TJKT (FASE E)
SMK Negeri 1 Lamboya
Pembuat: Agustinus Lay Rihi, ST - Guru KKA SMKN 1 Lamboya

Cara memakai:
1. Ekstrak file zip.
2. Klik dua kali index.html (Chrome, Edge, atau Firefox). Tidak perlu internet.
3. Klik tombol Musik untuk menyalakan musik latar.
