MEDIA INTERAKTIF KKA - KELAS X TJKT (FASE E)
SMK Negeri 1 Lamboya
Pembuat: Agustinus Lay Rihi, ST - Guru KKA SMKN 1 Lamboya

1. Ekstrak zip, klik dua kali index.html (Chrome/Edge/Firefox).
2. Tampilan otomatis menyesuaikan potret dan lanskap saat layar diputar.
3. Klik Musik untuk menyalakan musik latar.
4. Tombol Simpan PDF dan Bagikan di LKPD memerlukan internet; tanpa internet gunakan Cetak lalu Simpan sebagai PDF.
