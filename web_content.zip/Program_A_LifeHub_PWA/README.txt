PROGRAM A LIFEHUB — @NextAspire
Installable Android web app (PWA) package

IMPORTANT: The app must be hosted on HTTPS (or localhost) for install/offline support. Opening index.html directly from Downloads will show the website, but the install/offline features will not fully activate.

EASIEST FREE METHOD — GitHub Pages
1. On your phone or computer, sign in to GitHub and create a new repository.
2. Upload all files and folders from this package (index.html, manifest.webmanifest, sw.js, icons/).
3. In the repository, open Settings → Pages.
4. Under Build and deployment, choose Deploy from a branch; select main and /(root), then Save.
5. Wait for the published HTTPS link. Open that link in Chrome on Android.
6. Tap Chrome ⋮ → Install app or Add to Home screen.
7. Open LifeHub from the new home-screen icon.

DATA NOTE
Your current app stores progress in the browser on your device. Back up your data from the Progress tab before clearing browser data or moving to another browser/device. This package does not upload your personal progress to a server.

OFFLINE NOTE
Open the hosted app online once so the service worker can cache the app. Some externally hosted fonts may not appear offline; the app falls back to system fonts.
