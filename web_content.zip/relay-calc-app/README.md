# ماشین حساب رله و حفاظت

## روش ۱ — نصب سریع (PWA، بدون APK)
پوشه www را روی یک هاست HTTPS بگذار (مثلاً GitHub Pages)، در Chrome گوشی باز کن و «Add to Home screen» را بزن. بعد از اولین بار آفلاین هم کار می‌کند.

## روش ۲ — ساخت APK با Capacitor
npm install
npx cap add android
npx cap sync
npx cap open android   # در Android Studio: Build > Build APK(s)

## روش ۳ — مبدل‌های آنلاین
پوشه www را زیپ کن و در PWABuilder یا WebIntoApp آپلود کن.

آیکن‌ها فعلاً ساده‌اند؛ برای تغییر، icon-192.png و icon-512.png را جایگزین کن.
