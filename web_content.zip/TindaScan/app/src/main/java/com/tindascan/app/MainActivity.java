package com.tindascan.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanner;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning;
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
  private static final int CREATE_BACKUP = 201;
  private static final int OPEN_BACKUP = 202;
  private static final int MAX_BACKUP_BYTES = 15 * 1024 * 1024;
  private WebView web;
  private String pendingBackup;

  @Override public void onCreate(Bundle b) { super.onCreate(b);
    web = new WebView(this);
    web.getSettings().setJavaScriptEnabled(true);
    web.getSettings().setDomStorageEnabled(true);
    web.setWebViewClient(new WebViewClient());
    web.setWebChromeClient(new WebChromeClient());
    web.addJavascriptInterface(new Bridge(), "Android");
    setContentView(web);
    web.loadUrl("file:///android_asset/index.html");
  }

  private void notifyJs(String function, String value) {
    web.evaluateJavascript(function + "(" + JSONObject.quote(value) + ")", null);
  }

  class Bridge {
    @JavascriptInterface public void scan() { runOnUiThread(() -> {
      GmsBarcodeScannerOptions opts = new GmsBarcodeScannerOptions.Builder().enableAutoZoom().build();
      GmsBarcodeScanner scanner = GmsBarcodeScanning.getClient(MainActivity.this, opts);
      scanner.startScan().addOnSuccessListener(code -> {
        String value = code.getRawValue();
        if (value != null) notifyJs("onBarcode", value);
      }).addOnFailureListener(e -> Toast.makeText(MainActivity.this, "Scanner unavailable. Use manual barcode entry.", Toast.LENGTH_LONG).show());
    }); }

    // Android document picker allows user-selected local backup storage.
    @JavascriptInterface public void exportBackup(String json) { runOnUiThread(() -> {
      try {
        JSONObject data = new JSONObject(json);
        if (!"TindaScanBackupV1".equals(data.optString("format")) ||
            !(data.opt("products") instanceof org.json.JSONArray) ||
            !(data.opt("sales") instanceof org.json.JSONArray) ||
            json.getBytes(StandardCharsets.UTF_8).length > MAX_BACKUP_BYTES) {
          notifyJs("backupError", "Invalid or oversized backup"); return;
        }
        pendingBackup = json;
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        intent.putExtra(Intent.EXTRA_TITLE, "tindascan-backup-" +
          new java.text.SimpleDateFormat("yyyy-MM-dd-HHmm", java.util.Locale.US).format(new java.util.Date()) + ".json");
        startActivityForResult(intent, CREATE_BACKUP);
      } catch (Exception e) { notifyJs("backupError", "Could not open backup save picker"); }
    }); }

    @JavascriptInterface public void importBackup() { runOnUiThread(() -> {
      try {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivityForResult(intent, OPEN_BACKUP);
      } catch (Exception e) { notifyJs("backupError", "Could not open backup file picker"); }
    }); }
  }

  @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (resultCode != RESULT_OK || data == null || data.getData() == null) {
      if (requestCode == CREATE_BACKUP) pendingBackup = null;
      return;
    }
    Uri uri = data.getData();
    if (requestCode == CREATE_BACKUP) {
      try {
        if (pendingBackup == null) throw new IllegalStateException("No backup pending");
        try (OutputStream out = getContentResolver().openOutputStream(uri, "w")) {
          if (out == null) throw new IllegalStateException("Storage provider unavailable");
          out.write(pendingBackup.getBytes(StandardCharsets.UTF_8)); out.flush();
        }
        notifyJs("backupSaved", "Backup saved to selected location. Keep a copy in a safe phone folder.");
      } catch (Exception e) { notifyJs("backupError", "Could not save backup. Try another location."); }
      finally { pendingBackup = null; }
    } else if (requestCode == OPEN_BACKUP) {
      try (InputStream in = getContentResolver().openInputStream(uri);
           ByteArrayOutputStream out = new ByteArrayOutputStream()) {
        if (in == null) throw new IllegalStateException("Cannot read file");
        byte[] buf = new byte[8192]; int n; int total = 0;
        while ((n = in.read(buf)) != -1) {
          total += n; if (total > MAX_BACKUP_BYTES) throw new IllegalArgumentException("File too large");
          out.write(buf, 0, n);
        }
        String json = out.toString("UTF-8");
        JSONObject obj = new JSONObject(json);
        if (!"TindaScanBackupV1".equals(obj.optString("format")) ||
            !(obj.opt("products") instanceof org.json.JSONArray) ||
            !(obj.opt("sales") instanceof org.json.JSONArray)) throw new IllegalArgumentException("Not a TindaScan backup");
        notifyJs("receiveBackup", json);
      } catch (Exception e) { notifyJs("backupError", "Invalid, inaccessible, or oversized backup file."); }
    }
  }

  @Override public void onBackPressed() { web.evaluateJavascript("goBack()", null); }
}
