# TindaScan v1.3 — Camera Barcode / QR Scanner

Android Studio source project. This replaces the old Google Play Services code scanner with the bundled ZXing Android Embedded camera scanner. Press **Scan Product** in the installed Android app to launch the live camera scanner; scanning a barcode/QR passes the result back to the existing product lookup and POS flows. Camera permission is requested by the scanner. No barcode typing popup is used.

## Build
1. Extract ZIP and open this project folder in Android Studio.
2. Connect to the internet once to download Gradle dependencies (including ZXing).
3. Build > Build APK(s), then install and allow camera access.
4. Test a real product barcode and QR code. The scanning library runs offline after installation.

The app saves inventory locally in WebView storage and supports manual local JSON backup/restore. The approved mockup is included for design reference; the implemented UI is not yet pixel-identical to it. Not compiled or tested on a physical device in this environment. Existing unfinished features (e.g., Utang Tracker and Recycle Bin) remain unfinished.
