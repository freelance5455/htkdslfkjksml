# TindaScan v1.2 — Offline Android source / purple-yellow design

This source project is an **intermediate implementation**, not a tested APK. It applies the approved purple/yellow/white visual theme to the existing offline inventory, product editor, sales POS and local backup/restore screens. The full ten-screen mockup is a design target, **not yet completely implemented**.

## Working source features (device testing required)
- Add, edit, update and delete products, including prices, barcodes, piece/pack units, stock and low-stock threshold.
- Product alphabetical sorting, barcode scanning via Google Play Services Code Scanner, manual barcode entry.
- Sales checkout with stock deduction and sales history.
- Offline WebView localStorage and JSON backup/restore through Android document picker.

## Not yet implemented
- Dedicated Utang Tracker, Recycle Bin, returns/void corrections, separate restock history, detailed profit reports, box units, automatic backup.
- Pixel-perfect reproduction of all ten mockup screens.

## Build
Open this folder in Android Studio (JDK 17 / Android SDK 35). Sync Gradle and choose Build > Build APK(s). Scanner may need an initial Google Play Services module download. The source has not been compiled or tested here.

## Data safety
All live data is on the phone in app-private WebView localStorage. Uninstall/clear app data can erase it. Save JSON backups to phone storage regularly; restore replaces the existing inventory and sales.
