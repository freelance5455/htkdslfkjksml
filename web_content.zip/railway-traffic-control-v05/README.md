# Rail Control India – 2D traffic-control simulator

A lightweight, offline-first 2D railway traffic-control game designed for Android WebView and mobile browsers. The visual style is inspired by the supplied Indian suburban/yard traffic-control screenshots.

## What is in this build

- Animated five-track yard diagram with track blocks, signal lamps, turnout/crossover geometry and individual train formations.
- Distinct locomotive/formation styling for WAP-7, WAP-5, WAP-4 (fleet reference), WDP-4D (fleet reference), WAG-9, Vande Bharat, LHB Rajdhani, LHB Shatabdi, LHB Duronto, ICF blue, suburban local and goods trains.
- Formation lengths vary by service; passenger coaches and freight wagons are individually drawn on the yard canvas.
- Eight route scenarios: Howrah–New Delhi via Gaya, Howrah–New Delhi via Patna, Howrah–Mumbai, Howrah–Chennai, Howrah–Guwahati, Sealdah–New Delhi, Howrah–Puri and Mumbai–New Delhi.
- Six station platform faces in the working panel; loop availability is station-specific in the scenario data.
- Manual hold/release, track change, signal aspects, speed supervision, simulated passenger announcements and event log.
- Loop admission for overtaking at configured stations; route changes are denied if a conflicting train occupies the target block.
- Normal, busy and peak-hour/expert traffic levels; Career and Free Play modes; 1×/2×/4× simulation speeds.
- Canvas-based rendering avoids heavy 3D assets and is intended to remain usable on entry-level Android hardware.

## Controls

1. Select a corridor and traffic level, then start a new scenario.
2. Tap a train formation on the yard diagram or its row in the movement board.
3. Tap a signal lamp to cycle its aspect. The signal panel controls the selected train's next block.
4. Use Stop/Hold and Release to manage a train. A red next-block signal or occupied target block prevents unsafe release/routing.
5. Change track only when the destination track/block is clear.
6. Use Send to loop when the selected train is at a station configured with a loop. It is held on the loop to create an overtaking window.
7. Toggle speed monitoring to apply the scenario's section speed profile to the selected train.

## Timetable, distance and live-data limitations

This is a **simulation scenario**, not a certified railway timetable or signalling product. The route station chains and kilometre markers are illustrative route-profile data and should be verified against current official railway working timetables and engineering distance tables before being described as exact. Train numbers/names are representative services; scheduled departure/arrival fields are scenario labels, not a complete current timetable. Section speed limits are gameplay parameters, not operating authority.

GPS is simulated from the train's position in the scenario. Passenger announcements are generated locally. No live NTES/CRIS feed, GPS device, railway interlocking, passenger messaging gateway or official timetable API is connected. Do not use this game for real railway operations.

## Run in a browser

Open `www/index.html` in a modern browser. For offline install support, serve the `www` directory over HTTPS or localhost so the service worker can register.

## Build the Android APK

Open the `android` folder in Android Studio with Android Gradle Plugin 8.7.3 support, allow Gradle sync, then choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**. The output is normally under `android/app/build/outputs/apk/debug/`.

The project contains the WebView activity and bundled game assets. A compiled APK is not included in this source archive; an Android SDK/Gradle build environment is required to produce and sign it.


## Version 0.3 – Howrah Terminal Yard

Select **Howrah Terminal Yard · 23 platforms** in Control Section to load the station-specific scenario. The yard view includes 23 numbered platform faces, five approach roads, crossover fan geometry, local reception loops, express arrival/departure loops and a goods/stabling siding. The platform occupancy board lists all 23 platforms plus the five operating roads.

The scenario includes Howrah Rajdhani, Duronto, Poorva, Coromandel, Shatabdi, Gitanjali, Vande Bharat, three suburban local services and a WAG-9 goods rake. Coach formations are drawn as linked vehicles with livery-specific windows and a locomotive head. Select a train, hold it, route it to a loop, then dispatch a higher-priority express before releasing the local.

**Layout note:** this is a playable, simplified 23-platform yard schematic inspired by Howrah terminal operations. It is not a surveyed engineering track plan, official platform allocation, live interlocking diagram or verified working timetable. Train times, platform assignments, signal aspects and movement windows are scenario data.


## Version 0.4 – ER / SER interchange and throat interlocking

- Added separate Eastern Railway and South Eastern Railway approach movements to the Howrah terminal schematic.
- Added dedicated Shalimar and Santragachi interchange scenarios with separate service mixes and smaller platform groups.
- Added route-resource locking for throat, crossover and target-track resources. Conflicting routes are denied while another train owns the resource; route resources release when the train completes its movement.
- Added platform allocation based on scenario train-length classes and platform capacity classes, with availability checks and an explicit Allocate Platform action.
- Added an optional automatic local-train dispatch controller that checks suburban-road occupancy and throat availability before releasing a local.
- Added animated point-blade indicators, route-lock highlighting, signal posts and locomotive headlight beams.
- These are game mechanics and illustrative yard geometry, not official Howrah/Shalimar/Santragachi interlocking plans or real operating data. Platform lengths and route resources are scenario abstractions; verify official plans before making engineering claims.


## Version 0.5 – Advanced Howrah Operations

This build adds a separate advanced yard operations panel with an eight-road illustrative throat diagram and selectable train consists. The advanced panel provides: independent arrival-home and departure-starting signal controls; scenario-based platform-length allocation; train reversal when stopped; locomotive/rake shunting between yard roads; route resource locking; suburban local loop admission; AI-assisted express overtaking; WAP-7/WAP-5/WAG-9/EMU locomotive labels and individually drawn coaches; and three career mission briefs for peak-hour and delayed-train operations.

The advanced panel is a gameplay layer alongside the existing network simulator. It uses illustrative track geometry and simulated route resources, not an official Howrah station plan, interlocking table, signal sighting plan, working timetable, or railway operating instruction. Coach lengths, platform capacities, and movement timings are game abstractions.

Android WebView assets include `advanced.js`. JavaScript syntax check: `node --check www/game.js` and `node --check www/advanced.js`.
