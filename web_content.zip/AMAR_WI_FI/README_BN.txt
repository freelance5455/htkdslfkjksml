AMAR WI FI — Online-required mobile prototype

This ZIP contains a mobile-first web app prototype:
- Requires browser-reported internet connection; offline event displays a connection-required screen.
- Nagad Send Money number: 01764465689
- bKash Send Money number: 01333956610
- Demo login/register, dashboard, packages, deposit, withdraw, history, monthly expense, admin prototype.

Preview: Extract ZIP and open index.html in a browser while connected.

Important: This is a web prototype, not a compiled APK or production-ready financial application. The app currently checks browser online/offline state, not whether the server is truly reachable; a production Android app should check its backend and deny core operations if unreachable. Data is demo-only and may reset. Secure backend/database, authentication, admin role security, real payment verification, and APK packaging are still required. Do not treat a submitted TrxID as proof of payment without verification.
\n\nDeposit UI update (v3): পেমেন্ট মাধ্যম বেছে নম্বরে ক্লিক করে কপি করা যায়; পরিমাণ ও TrxID জমা দেওয়া যায়। এই prototype-এ জমা Pending থাকে এবং Admin Demo থেকে Approve করলে wallet-এ টাকা যোগ হয়। প্রকৃত স্বয়ংক্রিয় জমার জন্য নিরাপদ backend ও bKash/Nagad payment gateway/API verification প্রয়োজন—শুধু TrxID ইনপুটে টাকা স্বয়ংক্রিয় যোগ করা নিরাপদ নয়।\n