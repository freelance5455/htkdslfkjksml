AMAR WI FI — Internet-required Android app prototype

This project is a mobile-first browser prototype. It shows the app only when the browser reports an internet connection (navigator.onLine); on offline event it displays an internet-required screen.

Files: index.html, style.css, app.js.

Important: This is not a compiled Android APK and not a production payment application. Browser online status can be inaccurate (WiFi connected but no internet); a real Android app must check a backend endpoint and fail closed when backend is unreachable. Firebase/secure backend, authentication, server-enforced admin access, real bKash/Nagad verification, and Android APK packaging are not configured. Do not use real customer funds with this demo.

To preview: extract ZIP and open index.html in a mobile browser while online.
