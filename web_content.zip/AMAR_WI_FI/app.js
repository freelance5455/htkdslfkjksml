const $=id=>document.getElementById(id);let user=null,balance=0,records=[],activePackage=null;
const packages=[["Basic",1,80],["Standard",2,150],["Popular",3,220],["Silver",4,290],["Gold",5,350],["Premium",6,420],["Special",7,490],["Super",8,550],["Mega",9,610],["Yearly",12,750]];
let connectionCheckBusy=false;
async function checkOnline(){
 if(connectionCheckBusy)return; connectionCheckBusy=true;
 $("app").classList.add("hidden"); $("offline").classList.remove("hidden");
 const msg=$("offline").querySelector("p");
 msg.textContent="ইন্টারনেট সংযোগ পরীক্ষা করা হচ্ছে…";
 if(!navigator.onLine){msg.textContent="AMAR WI FI ব্যবহার করতে মোবাইল ডাটা/MB অথবা WiFi ইন্টারনেট চালু করুন।";connectionCheckBusy=false;return;}
 try{
   const controller=new AbortController(); const timer=setTimeout(()=>controller.abort(),5000);
   await fetch("https://www.gstatic.com/generate_204",{mode:"no-cors",cache:"no-store",signal:controller.signal});
   clearTimeout(timer);
   $("offline").classList.add("hidden"); $("app").classList.remove("hidden");
   msg.textContent="AMAR WI FI ব্যবহার করতে MB অথবা WiFi চালু করুন।";
 }catch(e){
   msg.textContent="ইন্টারনেট নেই বা সংযোগ কাজ করছে না। মোবাইল ডাটা/MB অথবা WiFi চালু করে আবার চেষ্টা করুন।";
 }finally{connectionCheckBusy=false;}
}
window.addEventListener("online",checkOnline);window.addEventListener("offline",checkOnline);checkOnline();
function toast(s){$("toast").textContent=s;$("toast").classList.remove("hidden");setTimeout(()=>$("toast").classList.add("hidden"),2200)}
function authTab(w){$("loginForm").classList.toggle("hidden",w!=="login");$("registerForm").classList.toggle("hidden",w!=="register");$("loginTab").classList.toggle("active",w==="login");$("registerTab").classList.toggle("active",w==="register")}
$("loginTab").onclick=()=>authTab("login");$("registerTab").onclick=()=>authTab("register");
$("loginForm").onsubmit=e=>{e.preventDefault();user={name:"AMAR WI FI User",phone:$("loginPhone").value};start()};
$("registerForm").onsubmit=e=>{e.preventDefault();user={name:$("regName").value,phone:$("regPhone").value,age:$("regAge").value};start()};
function start(){$("auth").classList.add("hidden");$("content").classList.remove("hidden");$("welcomeName").textContent=user.name;$("navName").textContent=user.name;show("home")}
$("menuBtn").onclick=()=>$("drawer").classList.toggle("hidden");$("logoutBtn").onclick=()=>{user=null;$("content").classList.add("hidden");$("auth").classList.remove("hidden");$("drawer").classList.add("hidden")};document.querySelectorAll("[data-page]").forEach(b=>b.onclick=()=>{show(b.dataset.page);$("drawer").classList.add("hidden")});
function cards(items){return `<div class="cards">${items.map(x=>`<div class="card"><div>◉</div><div class="amount">${x[1]}</div><small>${x[0]}</small></div>`).join("")}</div>`}
function show(p){let h="";if(p==="home"){h=cards([["Total Deposit","৳"+records.filter(r=>r.type==="Deposit"&&r.status==="Approved").reduce((a,r)=>a+r.amount,0)],["Wallet Balance","৳"+balance],["Active Package",activePackage?activePackage.name:"None"],["Monthly Expense","৳"+records.filter(r=>r.type==="Package").reduce((a,r)=>a+r.amount,0)]]);h+=`<div class="section"><h3>Quick Actions</h3><div class="cards"><button class="secondary" onclick="show('packages')">Packages</button><button class="secondary" onclick="show('deposit')">Deposit</button><button class="secondary" onclick="show('history')">History</button><button class="secondary" onclick="show('support')">Support</button></div></div>`}
if(p==="packages")h="<div class='section'><h3>WiFi Packages</h3>"+packages.map(x=>`<div class="package"><div><b>${x[0]} · ${x[1]} মাস</b><br><small>প্যাকেজ মূল্য</small></div><div><b>৳${x[2]}</b><br><button onclick="buy('${x[0]}',${x[1]},${x[2]})">কিনুন</button></div></div>`).join("")+"</div>";
if(p==="wallet")h=cards([["Available Balance","৳"+balance],["Pending Deposit","৳"+records.filter(r=>r.type==="Deposit"&&r.status==="Pending").reduce((a,r)=>a+r.amount,0)]]);
if(p==="deposit")h=`<div class="section"><h3>Deposit · বিকাশ / নগদ</h3><p class="muted">যে মাধ্যমে টাকা পাঠাবেন সেটি নির্বাচন করুন। নম্বরে চাপ দিলে কপি হবে।</p><label>পেমেন্ট মাধ্যম</label><select id="dm" onchange="updatePayNumber()"><option value="নগদ">নগদ</option><option value="বিকাশ">বিকাশ</option></select><div class="package"><div><b id="payLabel">নগদ Send Money</b><br><small>নম্বর কপি করতে চাপ দিন</small></div><button class="copyNumber" id="payNumber" onclick="copyPayNumber()">01764465689 ⧉</button></div><label>টাকার পরিমাণ</label><input id="da" type="number" min="1" placeholder="যেমন: 100"><label>Transaction ID (TrxID)</label><input id="dt" placeholder="টাকা পাঠানোর TrxID"><button class="primary" onclick="deposit()">টাকা পাঠানোর তথ্য Submit করুন</button><p class="muted">TrxID জমা দিলে অনুরোধটি যাচাই হবে। যাচাই সম্পন্ন হলে Wallet-এ টাকা যোগ হবে।</p></div>`;
if(p==="withdraw")h=`<div class="section"><h3>Withdraw Request</h3><input id="wa" type="number" placeholder="টাকার পরিমাণ"><select id="wm"><option>বিকাশ</option><option>নগদ</option></select><input id="wp" placeholder="গ্রাহকের পেমেন্ট নম্বর"><button class="primary" onclick="withdraw()">Request পাঠান</button></div>`;
if(p==="history")h="<div class='section'><h3>Transaction History</h3>"+(records.length?records.slice().reverse().map(r=>`<div class="rowitem"><div><b>${r.type}</b><br><small>${r.info} · ${r.date}</small></div><div>৳${r.amount}<br><span class="pill">${r.status}</span></div></div>`).join(""):"<div class='empty'>কোনো লেনদেন নেই</div>")+"</div>";
if(p==="monthly")h=cards([["এই মাসের প্যাকেজ খরচ","৳"+records.filter(r=>r.type==="Package").reduce((a,r)=>a+r.amount,0)],["মোট লেনদেন","৳"+records.reduce((a,r)=>a+r.amount,0)]]);
if(p==="profile")h=`<div class="section"><h3>Update Profile</h3><input id="pn" value="${user.name}"><input id="pp" value="${user.phone}"><button class="primary" onclick="user.name=$('pn').value;user.phone=$('pp').value;$('welcomeName').textContent=user.name;toast('Demo profile updated')">Save</button></div>`;
if(p==="support")h=`<div class="section"><h3>Admin Support · WhatsApp</h3><p>কোনো সমস্যা হলে WhatsApp-এ Admin-এর সঙ্গে যোগাযোগ করুন।</p><div class="package"><div><b>WhatsApp Support</b><br><small>Admin নম্বর</small></div><a class="primary" style="text-decoration:none;display:inline-block;padding:12px;border-radius:10px;color:white" href="https://wa.me/8801764465689" target="_blank" rel="noopener">01764465689 · Chat</a></div></div>`;
if(p==="admin")h=`<div class="section"><h3>Admin Dashboard · Demo</h3><p class="muted">এটি কেবল UI demo; production-এ server-protected admin login দরকার।</p>`+cards([["Deposit Requests",records.filter(r=>r.type==="Deposit").length],["Withdraw Requests",records.filter(r=>r.type==="Withdraw").length],["Package Sales",records.filter(r=>r.type==="Package").length],["Users","Demo"]])+records.filter(r=>r.status==="Pending").map(r=>`<div class="rowitem"><div>${r.type}<br><small>${r.info}</small></div><div>৳${r.amount}<br><button onclick="approve(${r.id})">Approve</button></div></div>`).join("")+"</div>";
$("page").innerHTML=h}
function add(type,amount,info,status="Pending"){records.push({id:Date.now()+Math.random(),type,amount:+amount,info,status,date:new Date().toLocaleDateString("bn-BD")})}
function updatePayNumber(){let m=$("dm").value,n=m==="নগদ"?"01764465689":"01333956610";$("payLabel").textContent=m+" Send Money";$("payNumber").textContent=n+" ⧉"}
async function copyPayNumber(){let n=$("dm").value==="নগদ"?"01764465689":"01333956610";try{await navigator.clipboard.writeText(n);toast("নম্বর কপি হয়েছে")}catch(e){toast("নম্বরটি চেপে ধরে কপি করুন: "+n)}}
function deposit(){let a=+$("da").value,t=$("dt").value.trim(),m=$("dm").value;if(a<=0||!t)return toast("টাকার পরিমাণ ও TrxID দিন");if(records.some(r=>r.type==="Deposit"&&r.info.endsWith("· "+t)))return toast("এই TrxID আগে জমা হয়েছে");add("Deposit",a,m+" · "+t,"Pending");toast("Deposit request জমা হয়েছে; যাচাই শেষে টাকা যোগ হবে");show("history")}
function withdraw(){let a=+$("wa").value,ph=$("wp").value,m=$("wm").value;if(a<=0||a>balance||!ph)return toast("সঠিক তথ্য দিন");add("Withdraw",a,m+" · "+ph);balance-=a;show("history")}
function buy(n,mo,pr){if(balance<pr){toast("আগে Deposit করুন");return show("deposit")}balance-=pr;activePackage={name:n,months:mo};add("Package",pr,n+" · "+mo+" মাস","Approved");toast("Demo purchase; WiFi password Admin দেবেন");show("home")}
function approve(id){let r=records.find(x=>x.id===id);if(!r||r.status!=="Pending")return;r.status="Approved";if(r.type==="Deposit")balance+=r.amount;show("admin");toast("Demo request approved")}
