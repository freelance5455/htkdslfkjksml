# Matemática Pro (APK)

App Android con voz y micrófono. Después de instalar el APK y descargar el español sin conexión, no necesita internet.

## Opción A: obtener el APK sin instalar nada (GitHub)
1. Crea un repositorio nuevo en github.com y sube TODO el contenido de esta carpeta (incluida la carpeta oculta `.github`).
2. Abre la pestaña **Actions**, entra en **Build APK** y espera a que termine (unos 3 minutos).
3. Abajo, en **Artifacts**, descarga **MatematicaPro-apk**. Dentro está `app-debug.apk`.

## Opción B: con Android Studio
1. Abre esta carpeta en Android Studio y deja que sincronice.
2. Menú **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
3. El archivo queda en `app/build/outputs/apk/debug/app-debug.apk`.

## Instalar en el teléfono
Pasa el APK al teléfono y ábrelo. Si Android lo pide, permite instalar apps de esta fuente.

## Para que funcione sin internet
- **Voz que habla:** Ajustes > Sistema > Idioma > Salida de texto a voz. Instala los datos de voz en español.
- **Micrófono:** Ajustes > Sistema > Idioma > Escritura por voz (o app Google > Ajustes > Voz > Reconocimiento sin conexión). Descarga **Español**.
- Al abrir la app, acepta el permiso del micrófono.
