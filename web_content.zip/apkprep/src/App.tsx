import { useState } from 'react';
import {
  ArrowDownLeft,
  ArrowUpRight,
  CreditCard,
  Eye,
  EyeOff,
  LogOut,
  Moon,
  Send,
  Sun,
  User,
  Wallet,
} from 'lucide-react';

const demoUser = {
  username: 'ChristopherMiller01',
  displayName: 'Christopher Miller',
  accountNumber: 'MT 5122106651',
  balance: 2500000,
};

const transactions = [
  {
    id: 1,
    label: 'Received — Prize / winnings',
    date: 'Oct 02, 2026',
    amount: 2500000,
    type: 'in',
  },
];

function App() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showBalance, setShowBalance] = useState(true);
  const [dark, setDark] = useState(true);
  const [tab, setTab] = useState('Overview');
  const [error, setError] = useState('');
  const [transferMessage, setTransferMessage] = useState('');

  const signIn = (event: React.FormEvent) => {
    event.preventDefault();
    setError('');
    if (username.trim() === demoUser.username && password === 'Winwin_1') {
      setLoggedIn(true);
    } else {
      setError(
        'Incorrect username or password. This sandbox accepts the configured test credentials only.'
      );
    }
  };

  if (!loggedIn) {
    return (
      <div className={dark ? 'shell dark' : 'shell'}>
        <main className="login-wrap">
          <section className="brand-panel">
            <div className="bank-visual" aria-hidden="true">
              <div className="bank-skyline">
                <span className="bank-sun" />
                <div className="bank-building">
                  <div className="bank-roof" />
                  <div className="bank-columns"><i /><i /><i /><i /></div>
                  <div className="bank-steps" />
                </div>
                <span className="bank-glow" />
              </div>
            </div>
            <div className="brand-lockup">
              <div className="logo">
                <CreditCard size={24} />
              </div>
              <div>
                <p className="eyebrow">M.&T</p>
                <h1>Credit Union</h1>
              </div>
            </div>
            <p className="bank-tagline">Secure. Simple. Personal banking.</p>
            <p className="muted">Your everyday banking, presented with clarity and designed around your financial journey.</p>
            <div className="bank-highlights">
              <span><b>01</b> Account overview</span>
              <span><b>02</b> Account activity</span>
              <span><b>03</b> Money movement</span>
            </div>
          </section>
          <section className="login-card">
            <p className="eyebrow">PERSONAL ACCESS</p>
            <h2>Welcome back</h2>
            <p className="muted">Sign in to your sandbox account.</p>
            <form onSubmit={signIn}>
              <label>
                Username
                <input
                  value={username}
                  onChange={e => setUsername(e.target.value)}
                  placeholder="Enter username"
                  autoComplete="username"
                />
              </label>
              <label>
                Password
                <div className="password-field">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    placeholder="Enter password"
                    autoComplete="current-password"
                  />{' '}
                  <button
                    type="button"
                    onClick={() => setShowPassword(v => !v)}
                    aria-label="Toggle password visibility"
                  >
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
              </label>
              {error && <div className="error">{error}</div>}
              <button className="primary" type="submit">
                Sign in
              </button>
            </form>
            <div className="login-footer">
              <span>Test account</span>
              <button onClick={() => setDark(v => !v)}>
                {dark ? <Sun size={17} /> : <Moon size={17} />} Theme
              </button>
            </div>
          </section>
        </main>
      </div>
    );
  }

  const money = (n: number) =>
    new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(n);

  return (
    <div className={dark ? 'shell dark' : 'shell'}>
      <header className="topbar">
        <div className="topbrand">
          <div className="logo small">
            <CreditCard size={19} />
          </div>
          <strong>M.&T Credit Union</strong>
        </div>
        <div className="top-actions">
          <button
            className="icon-btn"
            onClick={() => setDark(v => !v)}
            aria-label="Toggle theme"
          >
            {dark ? <Sun size={18} /> : <Moon size={18} />}
          </button>
          <button className="profile-chip">
            <span className="avatar">CM</span>
            <span>{demoUser.displayName}</span>
          </button>
          <button
            className="icon-btn"
            onClick={() => setLoggedIn(false)}
            aria-label="Sign out"
          >
            <LogOut size={18} />
          </button>
        </div>
      </header>
      <div className="layout">
        <aside className="sidebar">
          <nav>
            {['Overview', 'Transactions', 'Transfers', 'Profile'].map(item => (
              <button
                key={item}
                className={tab === item ? 'nav-item active' : 'nav-item'}
                onClick={() => setTab(item)}
              >
                {item}
              </button>
            ))}
          </nav>
          <div className="account-mini">
            <span>ACCOUNT</span>
            <strong>{demoUser.accountNumber}</strong>
            <small>Personal sandbox</small>
          </div>
        </aside>
        <main className="content">
          <div className="page-head">
            <div>
              <p className="eyebrow">PERSONAL ACCOUNT</p>
              <h1>{tab}</h1>
              <p className="muted">
                Good to see you, {demoUser.displayName.split(' ')[0]}.
              </p>
            </div>
            <div className="status-pill">● Sandbox active</div>
          </div>
          {tab === 'Overview' && (
            <>
              <section className="hero-balance">
                <div>
                  <p>Total available balance</p>
                  <div className="balance-row">
                    <h2>
                      {showBalance ? money(demoUser.balance) : '••••••••'}
                    </h2>
                    <button
                      className="balance-toggle"
                      onClick={() => setShowBalance(v => !v)}
                    >
                      {showBalance ? <EyeOff size={18} /> : <Eye size={18} />}
                    </button>
                  </div>
                  <span className="account-label">
                    {demoUser.accountNumber}
                  </span>
                </div>
                <div className="wallet-icon">
                  <Wallet size={30} />
                </div>
              </section>
              <section className="quick-grid">
                <button onClick={() => setTab('Transfers')}>
                  <Send size={20} />
                  <strong>Transfer</strong>
                  <span>Move simulated funds</span>
                </button>
                <button onClick={() => setTab('Transactions')}>
                  <ArrowDownLeft size={20} />
                  <strong>Ac+1 transaction History</strong>
                  <span>View account activity</span>
                </button>
                <button onClick={() => setTab('Profile')}>
                  <User size={20} />
                  <strong>Profile</strong>
                  <span>Manage preferences</span>
                </button>
              </section>
              <section className="panel">
                <div className="panel-head">
                  <div>
                    <h3>Recent activity</h3>
                    <p className="muted">Latest simulated account activity</p>
                  </div>
                  <button
                    className="text-btn"
                    onClick={() => setTab('Transactions')}
                  >
                    View all
                  </button>
                </div>
                {transactions.map(t => (
                  <div className="transaction" key={t.id}>
                    <div className="tx-icon">
                      <ArrowDownLeft size={18} />
                    </div>
                    <div className="tx-main">
                      <strong>{t.label}</strong>
                      <span>{t.date}</span>
                    </div>
                    <strong className="amount positive">
                      +{money(t.amount)}
                    </strong>
                  </div>
                ))}
              </section>
            </>
          )}
          {tab === 'Transactions' && (
            <section className="panel">
              <div className="panel-head">
                <div>
                  <h3>Ac+1 transaction History</h3>
                  <p className="muted">Account activity</p>
                </div>
              </div>
              {transactions.map(t => (
                <div className="transaction" key={t.id}>
                  <div className="tx-icon">
                    <ArrowDownLeft size={18} />
                  </div>
                  <div className="tx-main">
                    <strong>{t.label}</strong>
                    <span>{t.date}</span>
                  </div>
                  <strong className="amount positive">
                    +{money(t.amount)}
                  </strong>
                </div>
              ))}
            </section>
          )}
          {tab === 'Transfers' && (
            <section className="panel transfer-panel">
              <h3>MTd+1 Transfer</h3>
              <p className="muted">
                Send and manage a transfer request.
              </p>
              <label>
                Recipient name
                <input placeholder="Recipient name" />
              </label>
              <label>
                Amount
                <input type="number" placeholder="0.00" />
              </label>
              <label>
                Reference
                <input placeholder="Optional reference" />
              </label>
              <button
                className="primary"
                onClick={() =>
                  setTransferMessage(
                    'MTd+1 transfer request created in sandbox mode. No real funds were moved.'
                  )
                }
              >
                Review MTd+1 transfer
              </button>
              {transferMessage && (
                <div className="success">{transferMessage}</div>
              )}
            </section>
          )}
          {tab === 'Profile' && (
            <section className="panel profile-panel">
              <div className="large-avatar">CM</div>
              <div>
                <p className="eyebrow">ACCOUNT HOLDER</p>
                <h3>{demoUser.displayName}</h3>
                <p className="muted">{demoUser.accountNumber}</p>
              </div>
              <div className="profile-grid">
                <div>
                  <span>Username</span>
                  <strong>{demoUser.username}</strong>
                </div>
                <div>
                  <span>Account type</span>
                  <strong>Personal</strong>
                </div>
                <div>
                  <span>Currency</span>
                  <strong>USD</strong>
                </div>
                <div>
                  <span>Security</span>
                  <strong>Password protected</strong>
                </div>
              </div>
            </section>
          )}
        </main>
      </div>
    </div>
  );
}

export default App;
