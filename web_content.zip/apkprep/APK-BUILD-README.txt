M.&T Credit Union — APK-ready web project

This ZIP is prepared for a web-to-APK builder.

Recommended:
1. Upload this ZIP to a builder that accepts HTML/React/Vite source projects, or build the project first.
2. If the builder asks for a start file, use index.html.
3. If it asks for the website URL instead, use the deployed AppDeploy site.
4. App name: M.&T Credit Union
5. Orientation: Portrait
6. Display: Standalone

For a Vite build locally:
  npm install
  npm run build
Then package the generated dist/ folder as the web assets for an Android WebView/TWA wrapper.

Note: This project is a client-side web app. Any banking/authentication/backend behavior that requires a server must remain connected to its backend service after packaging.
