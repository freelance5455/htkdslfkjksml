# WebChat — Android Studio + servidor próprio

Projeto completo com aplicativo Android (Kotlin/Gradle) e backend Node.js incluído.

## O usuário NÃO informa URL
O endereço do backend é definido pelo desenvolvedor na compilação (`app/src/main/assets/web/index.html`). O usuário usa apenas sua conta e o código numérico.

## Conta
- Nome
- Senha (mínimo 6 caracteres)
- Código de identificação de 8 dígitos gerado pelo servidor

## Chat
- Busca por código
- Histórico
- Mensagens em tempo real por WebSocket
- Status online/offline
- Indicador de leitura

## Segurança
- Senhas com bcrypt
- Tokens JWT
- Banco SQLite
- Android com armazenamento seguro disponível pela ponte nativa
- Notificações Android 13+
- WebView sem mixed content

## Compilar Android
Abra a pasta no Android Studio, sincronize Gradle e gere o APK.

Antes de distribuir, substitua `https://SEU-DOMINIO-AQUI` pelo endereço HTTPS real do servidor e use um `JWT_SECRET` forte.

## Servidor
Na pasta `server`: `npm install` e depois `npm start`.

Para produção, use HTTPS/WSS e um domínio. Não exponha o segredo JWT no app.
