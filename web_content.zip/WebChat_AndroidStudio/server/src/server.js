import express from 'express';
import cors from 'cors';
import http from 'http';
import crypto from 'crypto';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import Database from 'better-sqlite3';
import {WebSocketServer} from 'ws';

const PORT=process.env.PORT||8080;
const JWT_SECRET=process.env.JWT_SECRET||'CHANGE_THIS_SECRET_IN_PRODUCTION';
const app=express(); app.use(cors()); app.use(express.json({limit:'16kb'}));
const db=new Database(process.env.DB_FILE||'webchat.db');
db.pragma('journal_mode = WAL');
db.exec(`CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY, code TEXT UNIQUE NOT NULL, name TEXT NOT NULL, pass_hash TEXT NOT NULL, created_at INTEGER NOT NULL, last_seen INTEGER NOT NULL);CREATE TABLE IF NOT EXISTS messages(id TEXT PRIMARY KEY, sender_id TEXT NOT NULL, receiver_id TEXT NOT NULL, text TEXT NOT NULL, created_at INTEGER NOT NULL, read INTEGER NOT NULL DEFAULT 0);CREATE INDEX IF NOT EXISTS idx_messages_pair ON messages(sender_id,receiver_id,created_at);`);
const online=new Map();
function code(){let c; do c=String(Math.floor(10000000+Math.random()*90000000)); while(db.prepare('SELECT 1 FROM users WHERE code=?').get(c)); return c}
function token(u){return jwt.sign({sub:u.id},JWT_SECRET,{expiresIn:'30d'})}
function auth(req,res,next){try{const p=jwt.verify((req.headers.authorization||'').replace(/^Bearer\s+/i,''),JWT_SECRET); const u=db.prepare('SELECT id,code,name FROM users WHERE id=?').get(p.sub); if(!u)throw Error(); req.user=u; next()}catch{res.status(401).json({error:'Não autenticado'})}}
function pub(u){return {id:u.id,code:u.code,name:u.name,online:online.has(u.id)}}
app.get('/health',(req,res)=>res.json({ok:true,service:'WebChat'}));
app.post('/api/register',async(req,res)=>{try{const name=String(req.body.name||'').trim(), password=String(req.body.password||'');if(name.length<2||name.length>32)throw Error('Nome inválido.');if(password.length<6)throw Error('Senha deve ter pelo menos 6 caracteres.');const id=crypto.randomUUID(), c=code(), now=Date.now(), hash=await bcrypt.hash(password,12);db.prepare('INSERT INTO users VALUES(?,?,?,?,?,?)').run(id,c,name,hash,now,now);const u={id,code:c,name};res.json({token:token(u),user:pub(u)})}catch(e){res.status(400).json({error:e.message||'Não foi possível criar a conta.'})}});
app.post('/api/login',async(req,res)=>{try{const c=String(req.body.code||'').replace(/\D/g,'');const password=String(req.body.password||'');const u=db.prepare('SELECT * FROM users WHERE code=?').get(c);if(!u||!(await bcrypt.compare(password,u.pass_hash)))throw Error('Código ou senha incorretos.');db.prepare('UPDATE users SET last_seen=? WHERE id=?').run(Date.now(),u.id);res.json({token:token(u),user:pub(u)})}catch(e){res.status(401).json({error:e.message||'Falha no login.'})}});
app.get('/api/users/:code',auth,(req,res)=>{const u=db.prepare('SELECT id,code,name FROM users WHERE code=?').get(String(req.params.code).replace(/\D/g,''));if(!u||u.id===req.user.id)return res.status(404).json({error:'Usuário não encontrado.'});res.json(pub(u))});
app.get('/api/history/:id',auth,(req,res)=>{const rows=db.prepare(`SELECT id,sender_id as "from",receiver_id as "to",text,created_at as t,read FROM messages WHERE (sender_id=? AND receiver_id=?) OR (sender_id=? AND receiver_id=?) ORDER BY created_at ASC LIMIT 500`).all(req.user.id,req.params.id,req.params.id,req.user.id);db.prepare('UPDATE messages SET read=1 WHERE receiver_id=? AND sender_id=?').run(req.user.id,req.params.id);res.json(rows)});
app.post('/api/message',auth,(req,res)=>{const to=String(req.body.to||''), text=String(req.body.text||'').trim();const target=db.prepare('SELECT id FROM users WHERE id=?').get(to);if(!target)return res.status(404).json({error:'Destinatário não encontrado.'});if(!text||text.length>2000)return res.status(400).json({error:'Mensagem inválida.'});const m={id:crypto.randomUUID(),from:req.user.id,to,text,t:Date.now(),read:0};db.prepare('INSERT INTO messages VALUES(?,?,?,?,?,?)').run(m.id,m.from,m.to,m.text,m.t,m.read);const payload=JSON.stringify({type:'message',message:m});online.get(m.to)?.forEach(ws=>{if(ws.readyState===1)ws.send(payload)});res.json(m)});
const server=http.createServer(app);const wss=new WebSocketServer({server,path:'/ws'});
wss.on('connection',(ws,req)=>{try{const q=new URL(req.url,'http://localhost').searchParams;const p=jwt.verify(q.get('token')||'',JWT_SECRET);const id=p.sub;if(!online.has(id))online.set(id,new Set());online.get(id).add(ws);ws.on('close',()=>{online.get(id)?.delete(ws);if(!online.get(id)?.size)online.delete(id)})}catch{ws.close(1008,'Unauthorized')}});
server.listen(PORT,()=>console.log(`WebChat server listening on :${PORT}`));
