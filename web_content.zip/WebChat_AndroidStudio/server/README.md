# WebChat Server

Backend real do WebChat: contas, código numérico de 8 dígitos, login, histórico e mensagens em tempo real via WebSocket.

## Rodar localmente

1. Instale Node.js 20+.
2. Entre nesta pasta: `cd server`
3. Execute `npm install`
4. Defina `JWT_SECRET` com um segredo forte.
5. Execute `npm start`

O servidor fica em `http://localhost:8080`.

## Produção

Hospede este servidor em um VPS/PaaS com HTTPS/WSS. Não use o segredo padrão. O banco SQLite é criado como `webchat.db`.

O Android deve receber internamente o endereço do backend pelo desenvolvedor/build, e o usuário nunca precisa digitar uma URL.
