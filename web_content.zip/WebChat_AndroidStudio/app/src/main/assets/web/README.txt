O placeholder __BACKEND__ deve ser substituído na etapa de build por um endpoint HTTPS/WSS seu. Não exponha URL configurável ao usuário.
