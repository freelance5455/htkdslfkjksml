(()=> {
'use strict';
const stage=document.getElementById('stage');
if(!window.THREE){stage.innerHTML='<p style="padding:20px;color:#102">تعذر تحميل محرك 3D. تحقق من اتصال الإنترنت وافتح الصفحة مجدداً.</p>';return;}
const THREE=window.THREE;
const scene=new THREE.Scene();scene.background=new THREE.Color(0x9bd0d2);scene.fog=new THREE.Fog(0x9bd0d2,35,115);
const camera=new THREE.PerspectiveCamera(62,1,.1,180);camera.position.set(0,5.4,10.5);camera.lookAt(0,1,-7);
const renderer=new THREE.WebGLRenderer({antialias:true,alpha:false});renderer.setPixelRatio(Math.min(devicePixelRatio,1.8));renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.15;stage.appendChild(renderer.domElement);
scene.add(new THREE.HemisphereLight(0xd9f4ff,0x80604a,2.0));
const sun=new THREE.DirectionalLight(0xffe2b4,3.0);sun.position.set(-9,18,8);sun.castShadow=true;sun.shadow.mapSize.set(1024,1024);scene.add(sun);
const mat=(color,rough=.8,metal=0)=>new THREE.MeshStandardMaterial({color,roughness:rough,metalness:metal});
const mats={road:mat(0x343b40),sand:mat(0xb99b70),cream:mat(0xe0c49a),ochre:mat(0xc08a5d),terracotta:mat(0xa96748),glass:mat(0x315e66,.35),dark:mat(0x1c2931),red:mat(0xc9432f),blue:mat(0x1d3d59),skin:mat(0xb97850),gold:mat(0xffc928,.25,.65),train:mat(0x087780,.35,.15),white:mat(0xe8e5d8)};
function box(parent,w,h,d,material,x,y,z){const o=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),material);o.position.set(x,y,z);o.castShadow=true;o.receiveShadow=true;parent.add(o);return o}
const floor=box(scene,80,.4,150,mats.sand,0,-.35,-48);box(scene,10,.12,150,mats.road,0,-.08,-48);
for(const x of [-1.67,1.67])for(let z=-120;z<12;z+=7)box(scene,.055,.025,2.4,mats.white,x,.0,z);
// Railway corridor details visible beneath approaching trains
for(const x of [-1.18,1.18]){
 box(scene,.075,.08,150,mat(0x777d7e,.45,.75),x,.02,-48);
 for(let z=-120;z<10;z+=1.25)box(scene,2.65,.07,.16,mat(0x65503d),0,-.02,z);
}
// city buildings with parapets, windows and storefront details
const buildings=[];
for(const side of [-1,1])for(let i=0;i<18;i++){
 const group=new THREE.Group();const h=THREE.MathUtils.randFloat(5,13),w=THREE.MathUtils.randFloat(2.7,4.1),z=-i*7-9,x=side*THREE.MathUtils.randFloat(7.1,9.3);
 const wall=[mats.cream,mats.ochre,mats.terracotta][Math.floor(Math.random()*3)];
 box(group,w,h,w,wall,0,h/2,0);box(group,w+.15,.18,w+.15,mats.white,0,h,0);
 // roof terrace and facade windows
 for(let fy=1.2;fy<h-1;fy+=1.8)for(let fx=-w*.27;fx<=w*.27;fx+=w*.52){
   box(group,.48,.68,.06,mats.glass,fx,fy,w/2+.04);
   box(group,.56,.07,.09,mats.white,fx,fy-.39,w/2+.07);
 }
 // arched doorway facade
 box(group,.85,1.5,.08,mats.dark,0,.76,w/2+.05);
 group.position.set(x,0,z);scene.add(group);buildings.push(group);
}
// street lamps, palms and planters
const decor=[];
for(let z=-100;z<8;z+=15)for(const side of [-1,1]){
 const g=new THREE.Group();box(g,.14,3.5,.14,mats.dark,0,1.75,0);box(g,.8,.12,.12,mats.dark,side*.34,3.35,0);box(g,.3,.18,.3,mats.gold,side*.68,3.25,0);
 g.position.set(side*5.8,0,z);scene.add(g);decor.push(g);
 // stylized palm
 const palm=new THREE.Group();const trunk=new THREE.Mesh(new THREE.CylinderGeometry(.12,.2,3.5,8),mat(0x765036));trunk.position.y=1.75;palm.add(trunk);
 for(let a=0;a<7;a++){const leaf=new THREE.Mesh(new THREE.ConeGeometry(.22,2.6,5),mat(0x26784b));leaf.position.y=3.55;leaf.rotation.z=Math.PI/2;leaf.rotation.y=a*Math.PI*2/7;leaf.rotation.x=.35;palm.add(leaf)}
 palm.position.set(side*6.7,0,z-4);scene.add(palm);decor.push(palm);
}
function makeRunner(){
 const g=new THREE.Group(), torso=new THREE.Mesh(new THREE.CapsuleGeometry(.38,.65,5,10),mats.red);torso.position.y=1.25;torso.castShadow=true;g.add(torso);
 const head=new THREE.Mesh(new THREE.SphereGeometry(.27,16,12),mats.skin);head.position.y=2.05;g.add(head);
 const hair=new THREE.Mesh(new THREE.SphereGeometry(.28,16,10,0,Math.PI*2,0,Math.PI*.55),mats.dark);hair.position.y=2.14;g.add(hair);
 const backpack=new THREE.Mesh(new THREE.BoxGeometry(.48,.62,.22),mat(0xb27b32));backpack.position.set(0,1.25,.35);g.add(backpack);
 const limbs=[];
 for(const side of [-1,1]){
  const arm=new THREE.Mesh(new THREE.CapsuleGeometry(.105,.52,4,8),mats.red);arm.position.set(side*.47,1.35,0);g.add(arm);
  const leg=new THREE.Mesh(new THREE.CapsuleGeometry(.13,.58,4,8),mats.blue);leg.position.set(side*.19,.48,0);g.add(leg);limbs.push({arm,leg,side});
 }
 g.position.set(0,0,2.2);scene.add(g);return {g,limbs,torso,head};
}
const runner=makeRunner();
let lane=0,targetX=0,jumpV=0,slideT=0,score=0,coins=0,best=+(localStorage.getItem('cityRunnerBest')||0),speed=17,objects=[],active=false,spawnT=0,clock=new THREE.Clock();
document.getElementById('best').textContent=best;
function spawn(){
 const laneN=Math.floor(Math.random()*3)-1,roll=Math.random();
 if(roll<.34){const group=new THREE.Group();const ring=new THREE.Mesh(new THREE.TorusGeometry(.34,.105,10,22),mats.gold);ring.rotation.y=Math.PI/2;group.add(ring);group.position.set(laneN*3,1.25,-62);scene.add(group);objects.push({g:group,type:'coin',lane:laneN});}
 else {const g=new THREE.Group();let type=roll<.58?'barrier':roll<.82?'train':'crate';
 if(type==='train'){
 // Detailed modern Moroccan-style commuter train, with its nose facing the runner (+Z)
 const bodyMat=mat(0xe8e8df,.42,.18),roofMat=mat(0x4b555b,.65,.25),windowMat=mat(0x102e3a,.18,.55),stripeMat=mat(0x087c80,.35,.25),rubberMat=mat(0x171d20,.9),metalMat=mat(0x9ba5a8,.3,.8);
 // Long carriage body, roof and lower chassis
 box(g,2.55,2.45,8.6,bodyMat,0,1.55,-.15);
 box(g,2.35,.22,8.25,roofMat,0,2.82,-.15);
 box(g,2.62,.34,8.45,rubberMat,0,.32,-.15);
 // Front cab: sloped-looking layered nose and broad windshield
 box(g,2.48,.72,.24,bodyMat,0,2.42,4.12);
 box(g,1.92,.78,.08,windowMat,0,2.42,4.27);
 box(g,.08,.82,.10,metalMat,-.98,2.42,4.25);
 box(g,.08,.82,.10,metalMat,.98,2.42,4.25);
 // Front destination panel, bumper and headlights
 box(g,.9,.18,.07,mat(0x172d35,.35,.4),0,2.91,4.28);
 for(const x of [-.86,.86]){
   const lamp=new THREE.Mesh(new THREE.CircleGeometry(.105,16),mat(0xfff1c7,.2,.15));
   lamp.position.set(x,1.72,4.29);g.add(lamp);
   const redLamp=new THREE.Mesh(new THREE.CircleGeometry(.07,12),mat(0xe44732,.25,.1));
   redLamp.position.set(x,1.35,4.29);g.add(redLamp);
 }
 box(g,2.5,.2,.25,roofMat,0,.72,4.3);
 // Turquoise waist stripe along both sides
 for(const side of [-1,1]){
   box(g,.055,.32,8.15,stripeMat,side*1.29,1.22,-.18);
   // Side windows and door panels
   for(let z=-3.35;z<=2.25;z+=1.12){
     box(g,.055,.68,.78,windowMat,side*1.292,2.12,z);
     box(g,.07,.055,.84,metalMat,side*1.33,1.76,z);
   }
   for(const z of [-1.05,1.05]){
     box(g,.075,1.25,.82,bodyMat,side*1.30,1.55,z);
     box(g,.08,.82,.58,windowMat,side*1.35,2.08,z);
     box(g,.09,.06,.62,stripeMat,side*1.36,1.55,z);
   }
   // Bogies and visible wheels
   for(const z of [-2.8,2.55]){
     box(g,.22,.42,1.25,rubberMat,side*1.05,.48,z);
     for(const wz of [-.38,.38]){
       const wheel=new THREE.Mesh(new THREE.CylinderGeometry(.28,.28,.16,18),rubberMat);
       wheel.rotation.z=Math.PI/2;wheel.position.set(side*1.29,.43,z+wz);g.add(wheel);
       const hub=new THREE.Mesh(new THREE.CylinderGeometry(.11,.11,.18,16),metalMat);
       hub.rotation.z=Math.PI/2;hub.position.set(side*1.30,.43,z+wz);g.add(hub);
     }
   }
 }
 // Coupler and under-front detail
 box(g,.38,.16,.38,metalMat,0,.48,4.43);
 box(g,1.5,.08,.08,metalMat,0,.88,4.38);
}
 else if(type==='barrier'){box(g,1.8,.9,.45,mats.red,0,.8,0);box(g,1.95,.16,.5,mats.white,0,1.05,0);}
 else {box(g,1.35,1.25,1.3,mat(0x9c7447),0,.65,0);box(g,1.4,.12,1.35,mats.gold,0,1.15,0);}
 g.position.set(laneN*3,0,-62);scene.add(g);objects.push({g,type,lane:laneN});}
}
function move(action){if(!active)return;if(action==='left')lane=Math.max(-1,lane-1),targetX=lane*3;if(action==='right')lane=Math.min(1,lane+1),targetX=lane*3;if(action==='jump'&&jumpV===0)jumpV=9.5;if(action==='slide')slideT=.7;}
function start(){score=0;coins=0;speed=17;lane=0;targetX=0;jumpV=0;slideT=0;spawnT=.5;for(const o of objects)scene.remove(o.g);objects=[];runner.g.position.set(0,0,2.2);active=true;document.getElementById('start').classList.add('hidden');document.getElementById('finish').classList.add('hidden');}
function end(){if(!active)return;active=false;best=Math.max(best,Math.floor(score));localStorage.setItem('cityRunnerBest',best);document.getElementById('best').textContent=best;document.getElementById('finalScore').textContent=Math.floor(score);document.getElementById('finish').classList.remove('hidden');}
document.getElementById('play').onclick=start;document.getElementById('again').onclick=start;
document.querySelectorAll('[data-move]').forEach(b=>b.addEventListener('pointerdown',()=>move(b.dataset.move)));
addEventListener('keydown',e=>{const m={ArrowLeft:'left',ArrowRight:'right',ArrowUp:'jump',' ':'jump',ArrowDown:'slide',a:'left',d:'right',s:'slide'};if(m[e.key]){e.preventDefault();move(m[e.key]);}});
let sx=0,sy=0;renderer.domElement.addEventListener('touchstart',e=>{sx=e.changedTouches[0].clientX;sy=e.changedTouches[0].clientY},{passive:true});renderer.domElement.addEventListener('touchend',e=>{const dx=e.changedTouches[0].clientX-sx,dy=e.changedTouches[0].clientY-sy;if(Math.max(Math.abs(dx),Math.abs(dy))<20)return;move(Math.abs(dx)>Math.abs(dy)?(dx>0?'right':'left'):(dy<0?'jump':'slide'));},{passive:true});
function resize(){const w=stage.clientWidth,h=stage.clientHeight;renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix();}addEventListener('resize',resize);resize();
function animate(){
 requestAnimationFrame(animate);const dt=Math.min(clock.getDelta(),.04),t=clock.elapsedTime;
 if(active){
  score+=dt*speed;speed=Math.min(29,speed+dt*.22);spawnT-=dt;if(spawnT<=0){spawn();spawnT=THREE.MathUtils.randFloat(.62,.95);}
  runner.g.position.x=THREE.MathUtils.damp(runner.g.position.x,targetX,12,dt);
  if(jumpV!==0||runner.g.position.y>0){jumpV-=23*dt;runner.g.position.y=Math.max(0,runner.g.position.y+jumpV*dt);if(runner.g.position.y===0)jumpV=0;}
  slideT=Math.max(0,slideT-dt);runner.torso.scale.y=slideT>0?.58:1;runner.torso.position.y=slideT>0?.92:1.25;runner.head.position.y=slideT>0?1.45:2.05;
  runner.limbs.forEach((l,i)=>{l.leg.rotation.x=Math.sin(t*13+i*Math.PI)*.65;l.arm.rotation.x=-Math.sin(t*13+i*Math.PI)*.5;});
  for(let i=objects.length-1;i>=0;i--){const o=objects[i];o.g.position.z+=speed*dt;if(o.type==='coin')o.g.rotation.z+=dt*3;
   if(Math.abs(o.g.position.z-2.2)<1.25&&o.lane===lane){
    if(o.type==='coin'){coins++;score+=25;scene.remove(o.g);objects.splice(i,1);continue;}
    const safe=(o.type==='barrier'&&runner.g.position.y>.85)||(o.type==='crate'&&slideT>0);
    if(!safe){end();break;}
   }
   if(o.g.position.z>8){scene.remove(o.g);objects.splice(i,1);}
  }
  buildings.forEach(b=>{b.position.z+=speed*dt*.78;if(b.position.z>13)b.position.z-=126;});
  decor.forEach(d=>{d.position.z+=speed*dt*.8;if(d.position.z>13)d.position.z-=120;});
  document.getElementById('score').textContent=Math.floor(score);document.getElementById('coins').textContent=coins;
 }
 renderer.render(scene,camera);
}
animate();
})();