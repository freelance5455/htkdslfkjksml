ULTIMATE CONTROLLER - HTML to APK Builder 用ZIP

使い方:
1. このZIPを解凍せずに、使用するHTML to APK Builderアプリで読み込んでください。
2. メインファイルとして index.html を指定できる場合は index.html を選択してください。
3. アプリ名を ULTIMATE CONTROLLER にしてAPKをビルドしてください。

重要:
これはタッチ操作画面のHTML試作品です。
ブラウザ/WebViewだけでは、Android上の他のアプリやRobloxへゲームパッド入力を送信できません。
Bluetooth HIDゲームパッドとして動かす機能は含まれていません。
今回のZIPはHTMLをAPK化するアプリで読み込めるようにした画面用ファイルです。
