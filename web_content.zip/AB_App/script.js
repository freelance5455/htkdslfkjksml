const $ = (s) => document.querySelector(s);
const workspace = $("#workspace"), pageContent = $("#pageContent");
const titles = {math:"Matematika",translate:"Tarjimon",ask:"Aqlli savol-javob",proverbs:"Maqollar"};
$("#year").textContent = new Date().getFullYear();
function onlineStatus(){ $("#connectionStatus").textContent = navigator.onLine ? "Internet mavjud — online imkoniyatlar tayyor" : "Offline imkoniyatlar tayyor"; }
window.addEventListener("online",onlineStatus); window.addEventListener("offline",onlineStatus); onlineStatus();
document.querySelectorAll("[data-page]").forEach(b=>b.addEventListener("click",()=>openPage(b.dataset.page)));
$("#backBtn").addEventListener("click",()=>{workspace.classList.add("hidden");window.scrollTo({top:0,behavior:"smooth"});});
$("#settingsBtn").addEventListener("click",()=>{$("#apiUrl").value=localStorage.getItem("ab_api_url")||"";$("#settingsDialog").showModal();});
$("#saveSettings").addEventListener("click",()=>{localStorage.setItem("ab_api_url",$("#apiUrl").value.trim());});
function openPage(page){workspace.classList.remove("hidden");$("#pageBadge").textContent=titles[page];pageContent.innerHTML=pages[page]();window.scrollTo({top:workspace.offsetTop-10,behavior:"smooth"});bindPage(page);}
const pages={
math:()=>`<h2 class="page-title">🧮 Matematika</h2><p class="page-desc">Ifodani yozing. Oddiy hisob-kitoblar internet talab qilmaydi.</p><label class="field-label">Matematik ifoda</label><input id="mathInput" class="input" placeholder="Masalan: (25 + 15) * 3 - 10"><div class="actions"><button class="primary-btn" id="solveBtn">Hisoblash</button><button class="secondary-btn" id="clearMath">Tozalash</button></div><div id="mathResult" class="result hidden"></div><p class="muted">Eslatma: bu hisoblagich oddiy arifmetik ifodalarni yechadi. To‘liq algebraik yechimlar keyingi versiyada kengaytirilishi mumkin.</p>`,
translate:()=>`<h2 class="page-title">🌍 Tarjimon</h2><p class="page-desc">Manba va maqsad tilini tanlang. Offline rejimda kichik iboralar lug‘ati ishlaydi.</p><div class="row"><div><label class="field-label">Qaysi tildan?</label><select id="fromLang"><option value="auto">Avtomatik aniqlash</option><option>O‘zbekcha</option><option>English</option><option>Русский</option><option>中文</option><option>Türkçe</option><option>العربية</option><option>Қазақша</option></select></div><div><label class="field-label">Qaysi tilga?</label><select id="toLang"><option>English</option><option>O‘zbekcha</option><option>Русский</option><option>中文</option><option>Türkçe</option><option>العربية</option><option>Қазақша</option><option>Français</option><option>Español</option><option>Deutsch</option></select></div></div><label class="field-label">Tarjima qilinadigan matn</label><textarea id="translateInput" rows="4" placeholder="Matnni shu yerga yozing..."></textarea><div class="actions"><button class="primary-btn" id="translateBtn">Tarjima qilish</button><button class="secondary-btn" id="swapBtn">⇄ Almashtirish</button></div><div id="translateResult" class="result hidden"></div><p class="muted">Keng ko‘lamli online tarjima uchun tarjima API/serverini sozlash kerak. Ushbu demo API manzili berilsa, serverga so‘rov yuborishga urinadi.</p>`,
ask:()=>`<h2 class="page-title">🤖 Aqlli savol-javob</h2><p class="page-desc">Savolingizni yozing. Offline holatda ilova saqlangan ma’lumotlar va umumiy maslahatlarni beradi.</p><label class="field-label">Savolingiz</label><textarea id="askInput" rows="4" placeholder="Masalan: Quyosh tizimi haqida aytib ber..."></textarea><div class="actions"><button class="primary-btn" id="askBtn">Javob olish</button><button class="secondary-btn" id="clearAsk">Tozalash</button></div><div id="askResult" class="result hidden"></div><p class="muted">To‘liq AI javoblari uchun sozlamalarda mos server/API manzili kerak. Maxfiy API kalitini bu faylda saqlamang.</p>`,
proverbs:()=>`<h2 class="page-title">📚 Maqollar</h2><p class="page-desc">O‘zbek maqollarini mavzu bo‘yicha qidiring yoki tasodifiy maqol oling.</p><input id="proverbSearch" class="input" placeholder="Maqol yoki mavzu qidirish..."><div class="actions"><button class="primary-btn" id="randomProverb">Tasodifiy maqol</button></div><div id="proverbList"></div>`
};
function bindPage(page){
 if(page==="math"){ $("#solveBtn").onclick=solveMath; $("#clearMath").onclick=()=>{$("#mathInput").value="";$("#mathResult").classList.add("hidden")}; $("#mathInput").addEventListener("keydown",e=>{if(e.key==="Enter")solveMath()});}
 if(page==="translate"){ $("#translateBtn").onclick=translateText; $("#swapBtn").onclick=()=>{let a=$("#fromLang"),b=$("#toLang"),old=a.value==="auto"?"O‘zbekcha":a.value; a.value=b.value; b.value=old;}; }
 if(page==="ask"){ $("#askBtn").onclick=askQuestion; $("#clearAsk").onclick=()=>{$("#askInput").value="";$("#askResult").classList.add("hidden")};}
 if(page==="proverbs"){renderProverbs("");$("#proverbSearch").addEventListener("input",e=>renderProverbs(e.target.value));$("#randomProverb").onclick=()=>{let p=proverbs[Math.floor(Math.random()*proverbs.length)];$("#proverbList").innerHTML=proverbHTML(p)};}
}
function showResult(id,text){let el=$(id);el.textContent=text;el.classList.remove("hidden")}
function solveMath(){
 const raw=$("#mathInput").value.trim();if(!raw)return showResult("#mathResult","Avval misolni yozing.");
 try{
  if(!/^[0-9+\-*/().%\s^,]+$/.test(raw))throw Error("Faqat raqamlar va + − × ÷, qavs, foiz yoki daraja belgilaridan foydalaning.");
  let expr=raw.replace(/\^/g,"**").replace(/(\d+(?:\.\d+)?)%/g,"($1/100)");
  if(/\/\s*0(?![\d.])/.test(expr))throw Error("Nolga bo‘lish mumkin emas.");
  let val=Function('"use strict";return ('+expr+')')();
  if(typeof val!=="number"||!Number.isFinite(val))throw Error("Ifodani hisoblab bo‘lmadi.");
  showResult("#mathResult",`Javob: ${Number(val.toPrecision(12))}`);
 }catch(e){showResult("#mathResult",e.message||"Misolni tekshirib qayta kiriting.");}
}
const dict = {
 "salom|English":"Hello","rahmat|English":"Thank you","xayr|English":"Goodbye","qandaysiz|English":"How are you?","men seni yaxshi ko‘raman|English":"I love you",
 "hello|O‘zbekcha":"Salom","thank you|O‘zbekcha":"Rahmat","goodbye|O‘zbekcha":"Xayr","how are you?|O‘zbekcha":"Qandaysiz?",
 "salom|Русский":"Привет","rahmat|Русский":"Спасибо","xayr|Русский":"До свидания","привет|O‘zbekcha":"Salom","спасибо|O‘zbekcha":"Rahmat",
 "你好|O‘zbekcha":"Salom","谢谢|O‘zbekcha":"Rahmat","salom|中文":"你好","rahmat|中文":"谢谢",
 "merhaba|O‘zbekcha":"Salom","teşekkürler|O‘zbekcha":"Rahmat","hola|O‘zbekcha":"Salom","gracias|O‘zbekcha":"Rahmat",
 "bonjour|O‘zbekcha":"Salom","danke|O‘zbekcha":"Rahmat"
};
async function translateText(){
 const text=$("#translateInput").value.trim(),to=$("#toLang").value,from=$("#fromLang").value;
 if(!text)return showResult("#translateResult","Avval tarjima qilinadigan matnni yozing.");
 const api=localStorage.getItem("ab_api_url");
 if(navigator.onLine&&api){try{let r=await fetch(api,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({text,source:from,target:to})});if(!r.ok)throw Error("API javobi: "+r.status);let data=await r.json();showResult("#translateResult",data.translation||data.translatedText||data.result||JSON.stringify(data));return;}catch(e){showResult("#translateResult","Online tarjima ulanmagan yoki server xatosi yuz berdi. Offline lug‘at tekshiriladi.");}}
 const key=text.toLowerCase().trim()+"|"+to;const found=dict[key];
 showResult("#translateResult",found?found:(from!=="auto"&&from===to?text:"Bu ibora offline lug‘atda yo‘q. To‘liq tarjima uchun internet va tarjima API/serveri kerak."));
}
async function askQuestion(){
 const q=$("#askInput").value.trim();if(!q)return showResult("#askResult","Avval savolingizni yozing.");
 const api=localStorage.getItem("ab_api_url");
 if(navigator.onLine&&api){try{let r=await fetch(api,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({question:q})});if(!r.ok)throw Error("API javobi: "+r.status);let d=await r.json();showResult("#askResult",d.answer||d.response||d.result||JSON.stringify(d));return;}catch(e){showResult("#askResult","Online AI serveriga ulanish amalga oshmadi. Quyida offline javob qoidalari tekshiriladi.\n\n"+offlineAnswer(q));return;}}
 showResult("#askResult",offlineAnswer(q));
}
function offlineAnswer(q){
 const s=q.toLowerCase();
 if(/[0-9]\s*[+\-*/×÷]\s*[0-9]/.test(s)){return "Bu matematik ifodani Matematika bo‘limiga kiriting — u hisoblab beradi."}
 if(s.includes("salom")||s.includes("hello"))return "Salom! Men A-B ilovasining offline yordamchisiman. Matematika, maqollar va saqlangan ma’lumotlar bo‘yicha yordam bera olaman.";
 if(s.includes("maqol"))return "Maqollar bo‘limiga o‘ting: mavzu bo‘yicha qidirish yoki tasodifiy maqol olish mumkin.";
 if(s.includes("quyosh"))return "Quyosh — Quyosh tizimining markazidagi yulduz. Yer va boshqa sayyoralar uning atrofida aylanadi. Bu qisqa offline ma’lumot; batafsil ilmiy javob uchun online AI kerak bo‘ladi.";
 if(s.includes("o‘zbekiston")||s.includes("uzbekiston"))return "O‘zbekiston — Markaziy Osiyoda joylashgan davlat. Poytaxti Toshkent. Bu qisqa offline javob; aniq yoki yangilangan ma’lumot uchun manbani tekshirish muhim.";
 return "Hozir offline rejimdasiz. Bu savol uchun ilovaning ichki bilim bazasida tayyor javob yo‘q. Internetga ulanganda va AI serveri sozlanganda batafsil javob olish mumkin.";
}
const proverbs=[
["Mehnatning tagi — rohat.","Mehnat qilgan odam oxir-oqibat uning samarasini ko‘radi."],
["Bilim — aql chirog‘i.","Bilim insonning yo‘lini yoritadi va to‘g‘ri qaror qilishga yordam beradi."],
["Yetti o‘lchab, bir kes.","Ishni boshlashdan oldin yaxshilab o‘ylab, tekshirib olish kerak."],
["Do‘st kulfatda bilinadi.","Haqiqiy do‘st qiyin vaziyatda yordam beradi."],
["Bugungi ishni ertaga qo‘yma.","Vazifani vaqtida bajarish foydali."],
["Birlik bor joyda tiriklik bor.","Hamjihatlik va hamkorlik ishni osonlashtiradi."],
["Ona yurting — oltin beshiging.","Vatan inson uchun aziz va qadrli maskan."],
["Aql yoshda emas, boshda.","Dono fikr faqat yoshga bog‘liq emas."],
["Tomchi-tomchi ko‘l bo‘lur.","Kichik harakatlar yig‘ilib katta natija beradi."],
["Kitob — bilim bulog‘i.","Kitob o‘qish bilim va dunyoqarashni kengaytiradi."],
["Yaxshi so‘z — jon ozig‘i.","Yoqimli va mehribon so‘zlar kishiga dalda beradi."],
["Shoshgan qiz erga yolchimas.","Shoshqaloqlik ba’zan xatoga olib keladi."]
];
function proverbHTML(p){return `<div class="proverb-item"><strong>${escapeHTML(p[0])}</strong><p>${escapeHTML(p[1])}</p><button class="secondary-btn copy-btn" data-copy="${encodeURIComponent(p[0]+' — '+p[1])}">Nusxalash</button></div>`}
function renderProverbs(q){const list=proverbs.filter(p=>p.join(" ").toLowerCase().includes(q.toLowerCase()));$("#proverbList").innerHTML=list.length?list.map(proverbHTML).join(""):'<p class="muted">Mos maqol topilmadi.</p>';$("#proverbList").querySelectorAll("[data-copy]").forEach(b=>b.onclick=async()=>{try{await navigator.clipboard.writeText(decodeURIComponent(b.dataset.copy));b.textContent="Nusxalandi ✓"}catch{b.textContent=decodeURIComponent(b.dataset.copy)}})}
function escapeHTML(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
if("serviceWorker" in navigator && location.protocol.startsWith("http")){navigator.serviceWorker.register("sw.js").catch(()=>{});}
