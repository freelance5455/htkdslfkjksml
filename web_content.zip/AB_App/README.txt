A-B — APK GA AYLANTIRISH UCHUN LOYIHA

Fayllar:
- index.html: asosiy sahifa
- style.css: rangli dizayn
- script.js: matematika, offline iboralar, maqollar va API ulanish namunasi
- manifest.json va sw.js: PWA/offline keshlash uchun

MUHIM:
1) Bu boshlang‘ich loyiha. Matematika oddiy arifmetik ifodalarni yechadi.
2) Offline tarjimon hozircha kichik namuna lug‘atidan foydalanadi; barcha tillar va murakkab matnlar uchun offline til modellari/lug‘atlari kerak.
3) Offline savol-javob tayyor ichki javoblardan foydalanadi. Har qanday savolga mukammal javob uchun AI modeli yoki internetdagi server kerak.
4) Online API ulash uchun sozlamalarda server manzilini kiriting. Kutiladigan namunaviy endpoint POST JSON qabul qiladi:
   Tarjima: {"text":"Hello","source":"English","target":"O‘zbekcha"} -> {"translation":"Salom"}
   Savol: {"question":"Savol matni"} -> {"answer":"Javob matni"}
5) Maxfiy API kalitini HTML/JS ichiga joylamang. Ishlab chiqarish ilovasida API kaliti serverda saqlanishi kerak.

APK qilish:
- Ushbu papkadagi fayllarni ZIP qiling yoki hostingga joylang.
- HTML-to-APK/WebView quruvchida index.html ni asosiy sahifa qilib belgilang.
- Offline ishlashi uchun barcha fayllarni APK ichiga qo‘shish kerak.
- Internet orqali AI/translation uchun internet ruxsati va ishlaydigan server/API kerak.
