DevNen Chapter 1 — playable browser horror prototype
====================================================

This ZIP contains a small, original, playable 2D top-down horror game prototype.
It is NOT a native Android APK and it is NOT a full 3D game yet.

How to play:
1. Extract the ZIP.
2. Open www/index.html in a modern browser, or host the www folder on a website.
3. Use WASD or arrow keys to move. On a phone, use the on-screen directional pad.
4. Find the key, rescue the friend, then reach the exit. Avoid the Nun and Teacher.
5. Press E / the INTERACT button near objects. Press F / FLASHLIGHT to toggle the light.
6. Press R to restart after game over or victory.

How to package as an Android app:
- This is a web game. To make an APK, use a trusted HTML-to-Android wrapper/build service or package it with a WebView Android project.
- A simple ZIP-to-APK converter may not support this format; the app must specifically support HTML games or WebView projects.
- No APK is included because no Android build has been run.

All visuals are original simple canvas drawings. No external assets or libraries are required.
