/* FoodGo BD Admin — vanilla JS + Supabase (RLS e is_admin() check hoy) */
const sb = window.supabase.createClient(CONFIG.SUPABASE_URL, CONFIG.SUPABASE_ANON_KEY);
const $ = (s) => document.querySelector(s);
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const money = (n) => CONFIG.CURRENCY + Number(n || 0).toLocaleString("en-US");
const STATUSES = ["pending", "confirmed", "preparing", "on_the_way", "delivered", "cancelled"];
const GROUPS = ["পরিচিত এলাকা", "ইয়ারপুর ইউনিয়নের গ্রাম", "কাশিমপুর ও আশপাশ", "Other"];
let tab = "dashboard", channel = null, newCount = 0;

function toast(m) { const el = $("#toast"); el.textContent = m; el.classList.remove("hidden"); clearTimeout(toast.t); toast.t = setTimeout(() => el.classList.add("hidden"), 2500); }
function openModal(h) { $("#mcard").innerHTML = h; $("#modal").classList.remove("hidden"); }
function closeModal() { $("#modal").classList.add("hidden"); }
$("#modal").addEventListener("click", (e) => { if (e.target.id === "modal") closeModal(); });

/* ---------- auth ---------- */
async function boot() {
  const { data } = await sb.auth.getSession();
  if (!data.session) return showLogin();
  const { data: p } = await sb.from("profiles").select("role").eq("id", data.session.user.id).maybeSingle();
  if (p?.role !== "admin") { await sb.auth.signOut(); showLogin("Ei account admin na."); return; }
  $("#login").classList.add("hidden"); $("#shell").classList.remove("hidden");
  subscribe(); go(tab);
}
function showLogin(msg = "") { $("#shell").classList.add("hidden"); $("#login").classList.remove("hidden"); $("#lErr").textContent = msg; }
$("#loginForm").onsubmit = async (e) => {
  e.preventDefault();
  const { error } = await sb.auth.signInWithPassword({ email: $("#lEmail").value.trim(), password: $("#lPass").value });
  if (error) return ($("#lErr").textContent = error.message);
  boot();
};
$("#logout").onclick = async () => { await sb.auth.signOut(); if (channel) sb.removeChannel(channel); showLogin(); };
$("#nav").onclick = (e) => { const b = e.target.closest("button"); if (b) go(b.dataset.tab); };

const TABS = { dashboard, orders, areas, restaurants, menu, coupons, customers, settings };
function go(t) {
  tab = t;
  document.querySelectorAll("#nav button").forEach((b) => b.classList.toggle("on", b.dataset.tab === t));
  if (t === "orders") { newCount = 0; $("#newBadge").classList.add("hidden"); }
  TABS[t]().catch((e) => ($("#main").innerHTML = `<p class="err">${esc(e.message)}<br>Jodi "relation does not exist" dekhao, tahole supabase/update_v2.sql Run koro.</p>`));
}

/* ---------- realtime new orders ---------- */
function subscribe() {
  if (channel) sb.removeChannel(channel);
  channel = sb.channel("admin-orders").on("postgres_changes", { event: "INSERT", schema: "public", table: "orders" }, (p) => {
    toast(`Notun order #${p.new.id} — ${money(p.new.total)}`);
    if (tab === "orders") orders(); else { newCount++; $("#newBadge").textContent = newCount; $("#newBadge").classList.remove("hidden"); }
  }).subscribe();
}

/* ---------- generic form modal ---------- */
function form(title, fields, values, onSave) {
  const v = values || {};
  openModal(`<h3>${esc(title)}</h3>` + fields.map((f) => {
    const val = v[f.k] ?? f.def ?? "";
    let input;
    if (f.type === "select") input = `<select id="f_${f.k}">${f.opts.map((o) => `<option value="${esc(o.v)}" ${String(o.v) === String(val) ? "selected" : ""}>${esc(o.l)}</option>`).join("")}</select>`;
    else if (f.type === "bool") input = `<select id="f_${f.k}"><option value="true" ${val === true || val === "true" ? "selected" : ""}>Yes</option><option value="false" ${val === false || val === "false" ? "selected" : ""}>No</option></select>`;
    else if (f.type === "textarea") input = `<textarea id="f_${f.k}" rows="2">${esc(val)}</textarea>`;
    else input = `<input id="f_${f.k}" type="${f.type || "text"}" ${f.type === "number" ? 'step="any"' : ""} value="${esc(val)}">`;
    return `<label>${esc(f.l)}</label>${input}${f.hint ? `<div class="mut">${esc(f.hint)}</div>` : ""}`;
  }).join("") + `<p id="fErr" class="err"></p><div class="bar"><button class="btn" id="fSave">Save</button><button class="btn sec" onclick="closeModal()">Cancel</button></div>`);
  $("#fSave").onclick = async () => {
    const out = {};
    for (const f of fields) {
      let x = $("#f_" + f.k).value;
      if (f.type === "number") x = x === "" ? null : Number(x);
      if (f.type === "bool") x = x === "true";
      if (f.type === "select" && f.num) x = Number(x);
      if (f.req && (x === "" || x === null)) return ($("#fErr").textContent = f.l + " dorkar");
      out[f.k] = x === "" ? null : x;
    }
    $("#fSave").disabled = true;
    const { error } = await onSave(out);
    if (error) { $("#fSave").disabled = false; return ($("#fErr").textContent = error.message); }
    closeModal(); toast("Saved"); go(tab);
  };
}
async function del(table, col, val) {
  if (!confirm("Delete korbe?")) return;
  const { error } = await sb.from(table).delete().eq(col, val);
  if (error) return toast(error.message);
  toast("Deleted"); go(tab);
}
window.closeModal = closeModal;

/* ---------- dashboard ---------- */
async function dashboard() {
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const [all, tod, pend, rest, cust] = await Promise.all([
    sb.from("orders").select("total,status"),
    sb.from("orders").select("total,status").gte("created_at", today.toISOString()),
    sb.from("orders").select("id", { count: "exact", head: true }).eq("status", "pending"),
    sb.from("restaurants").select("id", { count: "exact", head: true }),
    sb.from("profiles").select("id", { count: "exact", head: true }).eq("role", "customer")
  ]);
  const rev = (rows) => (rows || []).filter((o) => o.status !== "cancelled").reduce((s, o) => s + o.total, 0);
  $("#main").innerHTML = `<h1>Dashboard</h1><div class="stats">
    <div class="stat"><small>Today orders</small><b>${tod.data?.length || 0}</b></div>
    <div class="stat"><small>Today revenue</small><b>${money(rev(tod.data))}</b></div>
    <div class="stat"><small>Pending orders</small><b>${pend.count || 0}</b></div>
    <div class="stat"><small>Total orders</small><b>${all.data?.length || 0}</b></div>
    <div class="stat"><small>Total revenue</small><b>${money(rev(all.data))}</b></div>
    <div class="stat"><small>Restaurants</small><b>${rest.count || 0}</b></div>
    <div class="stat"><small>Customers</small><b>${cust.count || 0}</b></div></div>`;
}

/* ---------- orders ---------- */
async function orders() {
  const filter = orders.filter || "all";
  let q = sb.from("orders").select("*").order("created_at", { ascending: false }).limit(200);
  if (filter !== "all") q = q.eq("status", filter);
  const { data, error } = await q; if (error) throw error;
  $("#main").innerHTML = `<h1>Orders</h1>
    <div class="bar"><select id="ofilter"><option value="all">All</option>${STATUSES.map((s) => `<option ${s === filter ? "selected" : ""}>${s}</option>`).join("")}</select>
    <button class="btn sec sm" id="oref">Refresh</button></div>
    <table><tr><th>#</th><th>Customer / Location</th><th>Items</th><th>Payment</th><th>Total</th><th>Status</th></tr>
    ${data.map((o) => `<tr>
      <td><b>${o.id}</b><div class="mut">${new Date(o.created_at).toLocaleString("en-GB")}</div></td>
      <td>${esc(o.customer_name)}<div class="mut">📞 <a href="tel:${esc(o.phone)}">${esc(o.phone)}</a></div>
        ${o.area_name ? `<div>📍 <b>${esc(o.area_name)}</b></div>` : ""}<div class="mut">${esc(o.address)}</div>
        ${o.lat != null ? `<a class="map" target="_blank" rel="noopener" href="https://www.google.com/maps?q=${o.lat},${o.lng}">🗺️ Map e dekho</a>` : ""}
        ${o.note ? `<div class="mut">📝 ${esc(o.note)}</div>` : ""}</td>
      <td><div class="mut">${esc(o.restaurant_name || "")}</div>${o.items.map((i) => `${esc(i.name)} ×${i.qty}`).join("<br>")}</td>
      <td>${esc(o.payment_method.toUpperCase())}${o.payment_trx_id ? `<div class="mut">Trx: <b>${esc(o.payment_trx_id)}</b></div>` : ""}</td>
      <td><b>${money(o.total)}</b><div class="mut">delivery ${money(o.delivery_fee)}${o.distance_km != null ? ` (${o.distance_km} km)` : ""}${o.discount ? ` · −${money(o.discount)}` : ""}</div></td>
      <td><select data-oid="${o.id}" class="pill s-${o.status}">${STATUSES.map((s) => `<option ${s === o.status ? "selected" : ""}>${s}</option>`).join("")}</select></td></tr>`).join("") || `<tr><td colspan="6" class="mut">Kono order nai</td></tr>`}
    </table>`;
  $("#ofilter").onchange = (e) => { orders.filter = e.target.value; orders(); };
  $("#oref").onclick = orders;
  document.querySelectorAll("[data-oid]").forEach((s) => (s.onchange = async () => {
    const { error } = await sb.from("orders").update({ status: s.value }).eq("id", s.dataset.oid);
    if (error) toast(error.message); else { toast("Status updated"); s.className = "pill s-" + s.value; }
  }));
}

/* ---------- delivery areas ---------- */
const AF = [
  { k: "name", l: "Area name", req: 1 },
  { k: "grp", l: "Group", type: "select", opts: GROUPS.map((g) => ({ v: g, l: g })), def: GROUPS[0] },
  { k: "fee", l: "Delivery fee (৳)", type: "number", req: 1, def: 40 },
  { k: "lat", l: "Latitude (optional)", type: "number", hint: "Google Maps e jayga ta long press korle lat, lng dekhay. Dile GPS theke nearest area auto dhora jabe." },
  { k: "lng", l: "Longitude (optional)", type: "number" },
  { k: "sort", l: "Sort order", type: "number", def: 100 },
  { k: "active", l: "Active?", type: "bool", def: true }
];
async function areas() {
  const { data, error } = await sb.from("delivery_areas").select("*").order("sort").order("id"); if (error) throw error;
  const groups = [...new Set(data.map((a) => a.grp))];
  $("#main").innerHTML = `<h1>Delivery areas</h1>
    <div class="bar"><button class="btn" id="aAdd">+ Add area</button><button class="btn y" id="aAll">Sob area r fee ek sathe set koro</button></div>
    <div class="note">Fee column e number likhe baire click korle (ba Enter chapole) save hoye jabe. Customer ra ei fee ta dekhbe.</div>
    ${groups.map((g) => `<h3 class="grp"><span>${esc(g)}</span><button class="btn sec sm" data-grp="${esc(g)}">Ei group er sob fee set koro</button></h3>
      <table><tr><th>Area</th><th>Fee ৳</th><th>GPS</th><th>Active</th><th></th></tr>
      ${data.filter((a) => a.grp === g).map((a) => `<tr><td><b>${esc(a.name)}</b></td>
        <td><input type="number" min="0" data-fee="${a.id}" value="${a.fee}"></td>
        <td class="mut">${a.lat != null ? "✓" : "-"}</td>
        <td><span class="pill ${a.active ? "on-pill" : "off-pill"}">${a.active ? "Yes" : "No"}</span></td>
        <td><button class="btn sec sm" data-e="${a.id}">Edit</button> <button class="btn red sm" data-d="${a.id}">Del</button></td></tr>`).join("")}</table>`).join("")}`;
  $("#aAdd").onclick = () => form("Add area", AF, null, (v) => sb.from("delivery_areas").insert(v));
  const bulk = async (label, filterGrp) => {
    const x = prompt(`${label} - notun delivery fee (৳) likho:`); if (x === null) return;
    const n = Number(x); if (!Number.isFinite(n) || n < 0) return toast("Sothik number dao");
    let q = sb.from("delivery_areas").update({ fee: n }); q = filterGrp ? q.eq("grp", filterGrp) : q.gte("id", 0);
    const { error } = await q; if (error) return toast(error.message); toast("Fee updated"); areas();
  };
  $("#aAll").onclick = () => bulk("Sob area", null);
  document.querySelectorAll("[data-grp]").forEach((b) => (b.onclick = () => bulk(b.dataset.grp, b.dataset.grp)));
  document.querySelectorAll("[data-fee]").forEach((i) => (i.onchange = async () => {
    const n = Number(i.value); if (!Number.isFinite(n) || n < 0) return toast("Sothik number dao");
    const { error } = await sb.from("delivery_areas").update({ fee: n }).eq("id", i.dataset.fee);
    toast(error ? error.message : "Fee saved");
  }));
  document.querySelectorAll("[data-e]").forEach((b) => (b.onclick = () => form("Edit area", AF, data.find((a) => a.id == b.dataset.e), (v) => sb.from("delivery_areas").update(v).eq("id", b.dataset.e))));
  document.querySelectorAll("[data-d]").forEach((b) => (b.onclick = () => del("delivery_areas", "id", b.dataset.d)));
}

/* ---------- restaurants ---------- */
const RF = [
  { k: "name", l: "Name", req: 1 }, { k: "cuisine", l: "Cuisine (comma diye: Biryani, Kacchi)" }, { k: "image_url", l: "Image URL" },
  { k: "min_order", l: "Min order (৳)", type: "number", def: 0 }, { k: "eta", l: "ETA", def: "30-40 min" },
  { k: "rating", l: "Rating", type: "number", def: 4.5 }, { k: "is_open", l: "Open?", type: "bool", def: true },
  { k: "lat", l: "Latitude (distance fee er jonno, optional)", type: "number" }, { k: "lng", l: "Longitude (optional)", type: "number" }
];
async function restaurants() {
  const { data, error } = await sb.from("restaurants").select("*").order("id"); if (error) throw error;
  $("#main").innerHTML = `<h1>Restaurants</h1><div class="bar"><button class="btn" id="rAdd">+ Add restaurant</button></div>
    <table><tr><th></th><th>Name</th><th>Min order</th><th>ETA</th><th>Location</th><th>Status</th><th></th></tr>
    ${data.map((r) => `<tr><td>${r.image_url ? `<img src="${esc(r.image_url)}" alt="">` : ""}</td>
      <td><b>${esc(r.name)}</b><div class="mut">${esc(r.cuisine || "")} · ⭐${r.rating}</div></td>
      <td>${money(r.min_order)}</td><td>${esc(r.eta || "")}</td><td class="mut">${r.lat != null ? "✓ set" : "-"}</td>
      <td><span class="pill ${r.is_open ? "on-pill" : "off-pill"}">${r.is_open ? "Open" : "Closed"}</span></td>
      <td><button class="btn sec sm" data-e="${r.id}">Edit</button> <button class="btn red sm" data-d="${r.id}">Del</button></td></tr>`).join("")}</table>`;
  $("#rAdd").onclick = () => form("Add restaurant", RF, null, (v) => sb.from("restaurants").insert(v));
  document.querySelectorAll("[data-e]").forEach((b) => (b.onclick = () => form("Edit restaurant", RF, data.find((r) => r.id == b.dataset.e), (v) => sb.from("restaurants").update(v).eq("id", b.dataset.e))));
  document.querySelectorAll("[data-d]").forEach((b) => (b.onclick = () => del("restaurants", "id", b.dataset.d)));
}

/* ---------- menu items ---------- */
async function menu() {
  const { data: rs } = await sb.from("restaurants").select("id,name").order("name");
  const rid = menu.rid || rs?.[0]?.id;
  if (!rid) { $("#main").innerHTML = `<h1>Menu</h1><p class="mut">Age restaurant add koro.</p>`; return; }
  const { data, error } = await sb.from("menu_items").select("*").eq("restaurant_id", rid).order("category").order("name"); if (error) throw error;
  const MF = [
    { k: "restaurant_id", l: "Restaurant", type: "select", num: 1, opts: rs.map((r) => ({ v: r.id, l: r.name })), def: rid },
    { k: "name", l: "Name", req: 1 }, { k: "description", l: "Description", type: "textarea" },
    { k: "category", l: "Category", def: "Main" }, { k: "price", l: "Price", type: "number", req: 1 },
    { k: "image_url", l: "Image URL" }, { k: "is_available", l: "Available?", type: "bool", def: true }
  ];
  $("#main").innerHTML = `<h1>Menu items</h1><div class="bar">
    <select id="mrest">${rs.map((r) => `<option value="${r.id}" ${r.id == rid ? "selected" : ""}>${esc(r.name)}</option>`).join("")}</select>
    <button class="btn" id="mAdd">+ Add item</button></div>
    <table><tr><th></th><th>Item</th><th>Category</th><th>Price</th><th>Stock</th><th></th></tr>
    ${data.map((i) => `<tr><td>${i.image_url ? `<img src="${esc(i.image_url)}" alt="">` : ""}</td>
      <td><b>${esc(i.name)}</b><div class="mut">${esc(i.description || "")}</div></td><td>${esc(i.category || "")}</td><td>${money(i.price)}</td>
      <td><span class="pill ${i.is_available ? "on-pill" : "off-pill"}">${i.is_available ? "Available" : "Out"}</span></td>
      <td><button class="btn sec sm" data-e="${i.id}">Edit</button> <button class="btn red sm" data-d="${i.id}">Del</button></td></tr>`).join("") || `<tr><td colspan="6" class="mut">Kono item nai</td></tr>`}</table>`;
  $("#mrest").onchange = (e) => { menu.rid = Number(e.target.value); menu(); };
  $("#mAdd").onclick = () => form("Add item", MF, null, (v) => sb.from("menu_items").insert(v));
  document.querySelectorAll("[data-e]").forEach((b) => (b.onclick = () => form("Edit item", MF, data.find((i) => i.id == b.dataset.e), (v) => sb.from("menu_items").update(v).eq("id", b.dataset.e))));
  document.querySelectorAll("[data-d]").forEach((b) => (b.onclick = () => del("menu_items", "id", b.dataset.d)));
}

/* ---------- coupons ---------- */
const CF = [
  { k: "code", l: "Code (UPPERCASE)", req: 1 }, { k: "discount_percent", l: "Discount %", type: "number", req: 1 },
  { k: "max_discount", l: "Max discount (৳)", type: "number", def: 200 }, { k: "min_order", l: "Min order (৳)", type: "number", def: 0 },
  { k: "active", l: "Active?", type: "bool", def: true }
];
async function coupons() {
  const { data, error } = await sb.from("coupons").select("*").order("code"); if (error) throw error;
  $("#main").innerHTML = `<h1>Coupons</h1><div class="bar"><button class="btn" id="cAdd">+ Add coupon</button></div>
    <table><tr><th>Code</th><th>Discount</th><th>Max</th><th>Min order</th><th>Active</th><th></th></tr>
    ${data.map((c) => `<tr><td><b>${esc(c.code)}</b></td><td>${c.discount_percent}%</td><td>${money(c.max_discount)}</td><td>${money(c.min_order)}</td>
      <td><span class="pill ${c.active ? "on-pill" : "off-pill"}">${c.active ? "Yes" : "No"}</span></td>
      <td><button class="btn sec sm" data-e="${esc(c.code)}">Edit</button> <button class="btn red sm" data-d="${esc(c.code)}">Del</button></td></tr>`).join("")}</table>`;
  const up = (v) => ({ ...v, code: String(v.code).toUpperCase().trim() });
  $("#cAdd").onclick = () => form("Add coupon", CF, null, (v) => sb.from("coupons").insert(up(v)));
  document.querySelectorAll("[data-e]").forEach((b) => (b.onclick = () => form("Edit coupon", CF, data.find((c) => c.code === b.dataset.e), (v) => sb.from("coupons").update(up(v)).eq("code", b.dataset.e))));
  document.querySelectorAll("[data-d]").forEach((b) => (b.onclick = () => del("coupons", "code", b.dataset.d)));
}

/* ---------- customers ---------- */
async function customers() {
  const { data, error } = await sb.from("profiles").select("*").order("created_at", { ascending: false }).limit(300); if (error) throw error;
  $("#main").innerHTML = `<h1>Customers</h1><table><tr><th>Name</th><th>Phone</th><th>Role</th><th>Joined</th></tr>
    ${data.map((p) => `<tr><td>${esc(p.name || "-")}</td><td>${esc(p.phone || "-")}</td><td>${esc(p.role)}</td><td>${new Date(p.created_at).toLocaleDateString("en-GB")}</td></tr>`).join("")}</table>`;
}

/* ---------- fee settings ---------- */
async function settings() {
  const { data, error } = await sb.from("app_settings").select("*"); if (error) throw error;
  const s = { fee_mode: "area", dist_base: "30", dist_per_km: "10", dist_free_km: "1", dist_factor: "1.3" };
  data.forEach((x) => (s[x.key] = x.value));
  $("#main").innerHTML = `<h1>Delivery fee settings</h1><div class="card">
    <label class="mut">Fee kivabe hishab hobe</label>
    <select id="s_mode"><option value="area" ${s.fee_mode === "area" ? "selected" : ""}>Area onujayi (Delivery areas tab er fee)</option>
      <option value="distance" ${s.fee_mode === "distance" ? "selected" : ""}>Durotto onujayi (automatic, GPS + restaurant location)</option></select>
    <div class="note"><b>Area mode:</b> customer je area bachbe, oi area r fee lagbe.<br>
    <b>Distance mode:</b> customer GPS dile, restaurant theke durotto dekhe fee hishab hobe: base fee + (free km er por proti km × per km). Restaurant e latitude/longitude dite hobe, na thakle ba customer GPS na dile area fee use hobe.</div>
    <div id="dist" ${s.fee_mode === "distance" ? "" : 'style="opacity:.55"'}>
      <label class="mut">Base fee (৳) (free km porjonto)</label><input id="s_base" type="number" min="0" value="${esc(s.dist_base)}">
      <label class="mut">Free distance (km)</label><input id="s_free" type="number" min="0" step="0.1" value="${esc(s.dist_free_km)}">
      <label class="mut">Prottek extra km er fee (৳)</label><input id="s_per" type="number" min="0" value="${esc(s.dist_per_km)}">
      <label class="mut">Road factor (sojasuji durottor guntok, 1.3 = prai 30% beshi)</label><input id="s_fac" type="number" min="1" step="0.1" value="${esc(s.dist_factor)}">
    </div>
    <p class="mut" style="margin-bottom:0">Example: base 30, free 1 km, per km 10, durotto 3.5 km → 30 + (3.5 − 1) × 10 = ৳55</p>
    <div class="bar" style="margin:12px 0 0"><button class="btn" id="sSave">Save settings</button></div></div>`;
  $("#s_mode").onchange = () => ($("#dist").style.opacity = $("#s_mode").value === "distance" ? 1 : 0.55);
  $("#sSave").onclick = async () => {
    const rows = [["fee_mode", $("#s_mode").value], ["dist_base", $("#s_base").value || "0"], ["dist_free_km", $("#s_free").value || "0"], ["dist_per_km", $("#s_per").value || "0"], ["dist_factor", $("#s_fac").value || "1"]]
      .map(([key, value]) => ({ key, value: String(value) }));
    const { error } = await sb.from("app_settings").upsert(rows);
    toast(error ? error.message : "Settings saved");
  };
}

boot();
