import { auth, database } from "./firebase.js";
import { signInWithEmailAndPassword, signOut, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/12.1.0/firebase-auth.js";
import { ref, onValue, update, remove, push, set, get } from "https://www.gstatic.com/firebasejs/12.1.0/firebase-database.js";

const $ = id => document.getElementById(id);
const loginPage = $("loginPage"), dashboard = $("dashboard"), list = $("applicationList"), notice = $("notice");
let all = [], appUnsub = null, noticeUnsub = null, kbUnsub = null, donationUnsub = null, knowledgeRows = [];
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const errorText = e => {
  const code = e?.code || "";
  const messages = {
    "auth/invalid-email":"ইমেইল ঠিকভাবে লিখুন।", "auth/invalid-credential":"ইমেইল বা পাসওয়ার্ড সঠিক নয়।",
    "auth/user-not-found":"এই ইমেইলে কোনো অ্যাডমিন অ্যাকাউন্ট পাওয়া যায়নি।", "auth/wrong-password":"পাসওয়ার্ড সঠিক নয়।",
    "auth/too-many-requests":"অনেকবার চেষ্টা হয়েছে। কিছুক্ষণ পরে আবার চেষ্টা করুন।", "auth/network-request-failed":"ইন্টারনেট সংযোগ পরীক্ষা করে আবার চেষ্টা করুন।",
    "auth/operation-not-allowed":"Firebase-এ Email/Password sign-in চালু নেই।", "auth/invalid-api-key":"Firebase API Key সঠিক নয়।"
  };
  return messages[code] || e?.message || "অজানা সমস্যা হয়েছে। Console-এ বিস্তারিত দেখুন।";
};

async function doLogin(){
  const email=$("email").value.trim(), password=$("password").value;
  const err=$("loginError"), btn=$("loginBtn");
  err.textContent=""; $("loginStatus").textContent="";
  if(!email || !password){err.textContent="ইমেইল ও পাসওয়ার্ড দুটোই লিখুন।";return;}
  btn.disabled=true; btn.dataset.oldText=btn.innerHTML; btn.textContent="লগইন হচ্ছে…";
  try { await signInWithEmailAndPassword(auth,email,password); }
  catch(e){ err.textContent="❌ লগইন ব্যর্থ: "+errorText(e); console.error("Admin login failed",e); }
  finally { btn.disabled=false; btn.innerHTML=btn.dataset.oldText || "Login"; }
}
$("loginBtn").addEventListener("click",doLogin);
["email","password"].forEach(id=>$(id).addEventListener("keydown",e=>{if(e.key==="Enter"){e.preventDefault();doLogin();}}));
$("logoutBtn").addEventListener("click",()=>signOut(auth).catch(e=>showMsg("❌ লগআউট করা যায়নি: "+errorText(e),true)));
$("refreshBtn").addEventListener("click",()=>{loadApplications();showMsg("↻ আবেদন তালিকা রিফ্রেশ করা হচ্ছে…")});
function showMsg(t,isError=false){notice.textContent=t;notice.style.color=isError?"#b42318":"#16824e";}

onAuthStateChanged(auth,user=>{
  loginPage.style.display=user?"none":"flex"; dashboard.style.display=user?"block":"none";
  if(user){$("loginError").textContent="";loadApplications();loadMembers();}
  else {stopListener("app");stopListener("notice");stopListener("kb");all=[];}
},e=>{$("loginError").textContent="Firebase Authentication সমস্যা: "+errorText(e);});
function stopListener(which){if(which==="app"&&appUnsub){appUnsub();appUnsub=null;}if(which==="notice"&&noticeUnsub){noticeUnsub();noticeUnsub=null;}if(which==="kb"&&kbUnsub){kbUnsub();kbUnsub=null;}if(which==="donation"&&donationUnsub){donationUnsub();donationUnsub=null;}}
function toMillis(v){if(typeof v==="number")return v;const n=Date.parse(String(v||""));return Number.isFinite(n)?n:0;}
function loadApplications(){
  stopListener("app"); list.innerHTML='<div class="empty">⏳ Firebase থেকে আবেদন লোড হচ্ছে…</div>';
  appUnsub=onValue(ref(database,"volunteers"),snap=>{
    all=[]; if(snap.exists())snap.forEach(ch=>{ all.push({key:ch.key,...(ch.val()||{})}); });
    all.sort((a,b)=>toMillis(b.createdAt||b.submittedAt)-toMillis(a.createdAt||a.submittedAt)); renderApplications();
  },e=>{list.innerHTML='<div class="empty">❌ আবেদন লোড করা যায়নি। Firebase Database Rules/সংযোগ যাচাই করুন।</div>';showMsg("আবেদন লোড ব্যর্থ: "+errorText(e),true);console.error(e);});
}
function renderApplications(){
  if(!list)return;
  const q=$("search").value.trim().toLowerCase(), f=$("statusFilter").value, af=$("archiveFilter")?.value||"all";
  const active=all.filter(x=>x.archived!==true), archived=all.filter(x=>x.archived===true);
  const today=new Date(); const start=new Date(today.getFullYear(),today.getMonth(),today.getDate()).getTime();
  $("totalCount").textContent=active.length;
  $("pendingCount").textContent=active.filter(x=>(x.status||"Pending")==="Pending").length;
  $("approvedCount").textContent=active.filter(x=>x.status==="Approved").length;
  $("todayCount").textContent=active.filter(x=>{const t=toMillis(x.createdAt||x.submittedAt);return t>=start&&t<start+86400000;}).length;
  let shown=all.filter(x=>{
    const isArc=x.archived===true;
    const archiveOK=af==="all"||(af==="archived"?isArc:!isArc);
    const statusOK=f==="all"||(x.status||"Pending")===f;
    return archiveOK&&statusOK&&(!q||JSON.stringify(x).toLowerCase().includes(q));
  });
  $("applicationSummary").textContent=`সক্রিয়: ${active.length}টি · আর্কাইভ: ${archived.length}টি · দেখানো হচ্ছে: ${shown.length}টি`;
  if(!shown.length){list.innerHTML='<div class="empty">🔎 এই ফিল্টারে কোনো আবেদন পাওয়া যায়নি।</div>';return;}
  list.innerHTML=shown.map(x=>{
    const phone=String(x.phone||""); const wa=String(x.whatsapp||x.phone||""); const status=x.status||"Pending";
    const arc=x.archived===true;
    const digits=wa.replace(/\D/g,""); const waDigits=digits.startsWith("880")?digits:(digits.startsWith("0")?"88"+digits:digits);
    const date=x.submittedAt|| (x.createdAt?new Date(Number(x.createdAt)).toLocaleString("bn-BD"):"তারিখ নেই");
    const makeWa = (message, label, cls) => digits ? `<a class="${cls}" target="_blank" rel="noopener" href="https://wa.me/${esc(waDigits)}?text=${encodeURIComponent(message)}">${label}</a>` : "";
    const greeting = `আসসালামু আলাইকুম ${x.name||""}।`;
    const reviewMsg = `${greeting}\nধন্যবাদ ফাউন্ডেশন। আপনার মেম্বারশিপের আবেদনটি সফলভাবে জমা হয়েছে এবং বর্তমানে অ্যাডমিনের পর্যালোচনায় রয়েছে। আবেদন অনুমোদিত হলে আপনাকে জানানো হবে।`;
    const approvedMsg = `${greeting}\n🎉 অভিনন্দন! ধন্যবাদ ফাউন্ডেশন আপনার মেম্বারশিপের আবেদনটি অনুমোদন করেছে। আমাদের সঙ্গে থাকার জন্য ধন্যবাদ।`;
    const rejectedMsg = `${greeting}\nধন্যবাদ ফাউন্ডেশন। দুঃখিত, আপনার মেম্বারশিপের আবেদনটি অনুমোদিত হয়নি। বিস্তারিত জানতে অ্যাডমিনের সঙ্গে যোগাযোগ করুন।`;
    return `<article class="application-card ${arc?'is-archived':''}"><div class="card-head"><div><span class="status ${status==="Approved"?'approved':'pending'}">${esc(status)}</span>${arc?'<span class="archive-badge">📦 Archived</span>':''}<h3>${esc(x.name||"নাম নেই")}</h3></div><small>${esc(date)}</small></div><div class="details"><p>📱 <b>মোবাইল:</b> ${esc(phone||"-")}</p><p>💬 <b>WhatsApp:</b> ${esc(wa||"-")}</p><p>📧 <b>ইমেইল:</b> ${esc(x.email||"-")}</p><p>📍 <b>ঠিকানা:</b> ${esc(x.address||"-")}</p><p>📝 <b>সদস্য হওয়ার কারণ:</b> ${esc(x.reason||"-")}</p><p>🆔 <b>আবেদন ID:</b> ${esc(x.key)}</p></div><div class="button-group">${phone?`<a class="call-btn" href="tel:${esc(phone)}">📞 কল</a>`:""}${makeWa(reviewMsg,"💬 পর্যালোচনার মেসেজ","wa-review-btn")}${makeWa(approvedMsg,"✅ অনুমোদনের মেসেজ","wa-approved-btn")}${makeWa(rejectedMsg,"❌ বাতিলের মেসেজ","wa-rejected-btn")}<button class="approve-btn" data-action="approve" data-key="${esc(x.key)}">✅ Approve</button><button class="reject-btn" data-action="reject" data-key="${esc(x.key)}">❌ Reject</button><select aria-label="আবেদনের স্ট্যাটাস" class="inline-status" data-status-key="${esc(x.key)}"><option ${status==="Pending"?'selected':''}>Pending</option><option ${status==="Under Review"?'selected':''}>Under Review</option><option ${status==="Contacted"?'selected':''}>Contacted</option><option ${status==="Approved"?'selected':''}>Approved</option><option ${status==="Rejected"?'selected':''}>Rejected</option></select>${!arc?`<button class="archive-btn" data-action="archive" data-key="${esc(x.key)}">📦 Archive</button>`:`<button class="restore-btn" data-action="restore" data-key="${esc(x.key)}">↩ Restore</button>`}<button class="delete-btn" data-action="delete" data-key="${esc(x.key)}">🗑 স্থায়ী Delete</button></div></article>`;
  }).join("");
  list.querySelectorAll("[data-action]").forEach(b=>b.addEventListener("click",()=>handleApplicationAction(b.dataset.action,b.dataset.key)));
  list.querySelectorAll("[data-status-key]").forEach(s=>s.addEventListener("change",()=>updateStatus(s.dataset.statusKey,s.value)));
}

async function notifyApplicationMember(key,status){
  try{
    const snap=await get(ref(database,'volunteers/'+key)); const app=snap.val(); if(!app?.memberUid)return;
    const titles={Approved:'সদস্যপদ আবেদন অনুমোদিত',Rejected:'সদস্যপদ আবেদন আপডেট',Pending:'আবেদন গ্রহণ করা হয়েছে','Under Review':'আবেদন পর্যালোচনাধীন',Contacted:'আবেদন সম্পর্কে যোগাযোগ করা হয়েছে'};
    const messages={Approved:`অভিনন্দন ${app.name||''}! আপনার সদস্যপদের আবেদন অনুমোদন করা হয়েছে।`,Rejected:`${app.name||'প্রিয় সদস্য'}, দুঃখিত, আপনার সদস্যপদের আবেদনটি অনুমোদিত হয়নি। বিস্তারিত জানতে ফাউন্ডেশনের সঙ্গে যোগাযোগ করুন।`,Pending:`${app.name||'প্রিয় সদস্য'}, আপনার আবেদনটি গ্রহণ করা হয়েছে।`,'Under Review':`${app.name||'প্রিয় সদস্য'}, আপনার আবেদনটি বর্তমানে অ্যাডমিনের পর্যালোচনায় রয়েছে।`,Contacted:`${app.name||'প্রিয় সদস্য'}, আপনার আবেদনের বিষয়ে ফাউন্ডেশন থেকে যোগাযোগের চেষ্টা করা হয়েছে।`};
    await push(ref(database,'memberNotifications/'+app.memberUid),{title:titles[status]||'আবেদনের আপডেট',message:messages[status]||`আপনার আবেদনের স্ট্যাটাস: ${status}`,createdAt:Date.now(),type:'application-status',applicationId:key,status});
  }catch(e){console.warn('Could not notify applicant',e);}
}

async function updateStatus(key,status){
  try{
    await update(ref(database,"volunteers/"+key),{status,reviewedAt:Date.now()});
    await notifyApplicationMember(key,status);
    // স্ট্যাটাস বদলালে কোনো সংকীর্ণ ফিল্টারে আবেদন লুকিয়ে না যাওয়ার জন্য সব স্ট্যাটাস দেখাই।
    if(status==="Approved") $("statusFilter").value="all";
    renderApplications();
    showMsg(status==="Approved"?"✅ আবেদন অনুমোদিত হয়েছে। WhatsApp নোটিফিকেশন Cloud Function সেটআপ থাকলে স্বয়ংক্রিয়ভাবে পাঠানো হবে।":"✅ আবেদন স্ট্যাটাস আপডেট হয়েছে");
  }catch(e){showMsg("❌ স্ট্যাটাস আপডেট হয়নি: "+errorText(e),true);}
}
async function handleApplicationAction(action,key){
  try{
    if(action==="approve"){await update(ref(database,"volunteers/"+key),{status:"Approved",reviewedAt:Date.now()});await notifyApplicationMember(key,"Approved");$("statusFilter").value="all";showMsg("✅ আবেদন অনুমোদিত হয়েছে। WhatsApp মেসেজ পাঠাতে আলাদা মেসেজ বাটনে ক্লিক করুন।");}
    if(action==="reject"){await update(ref(database,"volunteers/"+key),{status:"Rejected",reviewedAt:Date.now()});await notifyApplicationMember(key,"Rejected");$("statusFilter").value="all";showMsg("❌ আবেদন Reject করা হয়েছে। চাইলে WhatsApp মেসেজ বাটনে ক্লিক করে পাঠান।");}
    if(action==="archive"){if(!confirm("এই আবেদনটি আর্কাইভ করবেন? পরে Restore করা যাবে।"))return;await update(ref(database,"volunteers/"+key),{archived:true,archivedAt:Date.now()});showMsg("📦 আবেদন আর্কাইভ করা হয়েছে");}
    if(action==="restore"){await update(ref(database,"volunteers/"+key),{archived:false,restoredAt:Date.now()});showMsg("↩ আবেদন Restore করা হয়েছে");}
    if(action==="delete"){if(!confirm("এই আবেদনটি স্থায়ীভাবে মুছে ফেলবেন? এটি ফেরত আনা যাবে না।"))return;await remove(ref(database,"volunteers/"+key));showMsg("🗑 আবেদন স্থায়ীভাবে মুছে ফেলা হয়েছে");}
  }catch(e){showMsg("❌ কাজটি সম্পন্ন হয়নি: "+errorText(e),true);}
}
$("search").addEventListener("input",renderApplications);$("statusFilter").addEventListener("change",renderApplications);$("archiveFilter")?.addEventListener("change",renderApplications);
$("exportBtn").addEventListener("click",()=>{
  const rows=[["Name","Phone","WhatsApp","Email","Address","Reason","Status","Archived","Submitted At","Application ID"],...all.map(x=>[x.name,x.phone,x.whatsapp,x.email,x.address,x.reason,x.status||"Pending",x.archived?"Yes":"No",x.submittedAt,x.key])];
  const csv="\ufeff"+rows.map(r=>r.map(v=>'"'+String(v??"").replace(/"/g,'""')+'"').join(",")).join("\n");
  const a=document.createElement("a"),url=URL.createObjectURL(new Blob([csv],{type:"text/csv;charset=utf-8"}));a.href=url;a.download="dhonnobad-foundation-applications.csv";a.click();setTimeout(()=>URL.revokeObjectURL(url),800);
});

// Admin navigation tabs
const tabButtons=[...document.querySelectorAll(".admin-tab")];
tabButtons.forEach(btn=>btn.addEventListener("click",()=>{
  tabButtons.forEach(x=>x.classList.toggle("active",x===btn));
  document.querySelectorAll(".admin-tab-panel").forEach(p=>p.classList.remove("active-panel"));
  $("tab-"+btn.dataset.tab)?.classList.add("active-panel");
  if(btn.dataset.tab==="donations")loadDonations();
  if(btn.dataset.tab==="notices")loadNotices();
  if(btn.dataset.tab==="ai")loadKnowledge();
  if(btn.dataset.tab==="analytics")loadAIAnalytics();
  if(btn.dataset.tab==="quiz")loadQuizAdmin(); if(btn.dataset.tab==="activity")loadActivityAdmin();
}));


let donationRowsCache=[];
function renderDonationRows(){
  const box=$("donationList");if(!box)return;
  const query=String($("donationSearch")?.value||"").trim().toLocaleLowerCase("bn");
  const statusFilter=$("donationStatusFilter")?.value||"all";
  const rows=donationRowsCache.filter(x=>{
    const status=x.status||"Pending";
    const matchesStatus=statusFilter==="all"||status===statusFilter;
    const hay=[x.name,x.phone,x.method,x.amount,x.transactionId,x.key,status].join(" ").toLocaleLowerCase("bn");
    return matchesStatus&&(!query||hay.includes(query));
  });
  const pending=donationRowsCache.filter(x=>(x.status||"Pending")==="Pending").length;
  $("donationSummary").textContent=`মোট দান-রেকর্ড: ${donationRowsCache.length}টি · যাচাই অপেক্ষমাণ: ${pending}টি · বর্তমানে দেখানো: ${rows.length}টি`;
  box.innerHTML=rows.length?rows.map(x=>{
    const phone=String(x.phone||"");let digits=phone.replace(/\D/g,"");if(digits.startsWith("0"))digits="88"+digits;
    const msg=`আসসালামু আলাইকুম ${x.name||""}। ধন্যবাদ ফাউন্ডেশনে আপনার ${x.amount||""} টাকার অনুদান (Transaction ID: ${x.transactionId||""}) যাচাই করে সঠিকভাবে আমাদের কাছে পৌঁছেছে। অনুদান দেওয়ার জন্য আন্তরিক ধন্যবাদ। ❤️`;
    const wa=digits?`<a class="wa-approved-btn" target="_blank" rel="noopener" href="https://wa.me/${esc(digits)}?text=${encodeURIComponent(msg)}">💬 WhatsApp-এ ধন্যবাদ জানান</a>`:"";
    return `<article class="application-card donation-admin-card"><div class="card-head"><div><span class="status ${(x.status||"Pending")==="Verified"?'approved':'pending'}">${esc(x.status||"Pending")}</span><h3>${esc(x.name||"নাম নেই")}</h3></div><small>${esc(x.submittedAt?new Date(Number(x.submittedAt)).toLocaleString("bn-BD"):"তারিখ নেই")}</small></div><div class="details"><p>📱 <b>মোবাইল:</b> ${esc(phone||"-")}</p><p>💳 <b>মাধ্যম:</b> ${esc(x.method||"-")}</p><p>💰 <b>পরিমাণ:</b> ৳${esc(x.amount??"-")}</p><p>🧾 <b>Transaction ID:</b> ${esc(x.transactionId||"-")}</p><p>🆔 <b>রেকর্ড ID:</b> ${esc(x.key)}</p></div><div class="button-group">${wa}<button class="approve-btn" data-donation-action="verify" data-key="${esc(x.key)}">✅ যাচাই সম্পন্ন</button><button class="delete-btn" data-donation-action="delete" data-key="${esc(x.key)}">🗑 Delete</button></div></article>`;
  }).join(""):'<div class="empty">এই ফিল্টারে কোনো অনুদানের রেকর্ড পাওয়া যায়নি।</div>';
  box.querySelectorAll("[data-donation-action]").forEach(b=>b.onclick=async()=>{
    try{
      if(b.dataset.donationAction==="verify"){
        await update(ref(database,"donations/"+b.dataset.key),{status:"Verified",verifiedAt:Date.now()});showMsg("✅ অনুদানের তথ্য যাচাই সম্পন্ন হয়েছে। চাইলে WhatsApp-এ ধন্যবাদ জানান।");
      }else{
        if(!confirm("এই অনুদানের রেকর্ড স্থায়ীভাবে মুছবেন?"))return;
        await remove(ref(database,"donations/"+b.dataset.key));showMsg("অনুদানের রেকর্ড মুছে ফেলা হয়েছে।");
      }
    }catch(e){showMsg("❌ অনুদানের রেকর্ড আপডেট হয়নি: "+errorText(e),true);}
  });
}
function loadDonations(){
  stopListener("donation");const box=$("donationList");if(!box)return;
  box.innerHTML='<div class="notice-loading">⏳ Firebase থেকে সব অনুদানের রেকর্ড লোড হচ্ছে…</div>';
  donationUnsub=onValue(ref(database,"donations"),snap=>{
    donationRowsCache=[];
    if(snap.exists()){
      const raw=snap.val()||{};
      // Enumerate every direct child; do not use limitToFirst/limitToLast or stop after the first item.
      Object.entries(raw).forEach(([key,value])=>{
        if(value&&typeof value==="object"&&!Array.isArray(value))donationRowsCache.push({key,...value});
      });
    }
    donationRowsCache.sort((a,b)=>Number(b.submittedAt||0)-Number(a.submittedAt||0));
    renderDonationRows();
  },e=>{box.innerHTML='<div class="empty">অনুদানের তথ্য লোড করা যায়নি। Firebase Rules-এ donations read permission যাচাই করুন।</div>';showMsg("অনুদানের তথ্য লোড ব্যর্থ: "+errorText(e),true);});
}
$("donationSearch")?.addEventListener("input",renderDonationRows);
$("donationStatusFilter")?.addEventListener("change",renderDonationRows);

function loadNotices(){
  stopListener("notice");const box=$("noticeList");box.innerHTML='<div class="notice-loading">⏳ Firebase থেকে নোটিশ লোড হচ্ছে…</div>';
  noticeUnsub=onValue(ref(database,"publicNotices"),snap=>{
    const rows=[];if(snap.exists())snap.forEach(ch=>rows.push({key:ch.key,...(ch.val()||{})}));
    rows.sort((a,b)=>Number(Boolean(b.pinned))-Number(Boolean(a.pinned))||Number(b.publishedAt||0)-Number(a.publishedAt||0));
    box.innerHTML=rows.length?rows.map(n=>`<div class="notice-item ${n.pinned?'is-pinned':''}"><div class="notice-admin-head"><span class="status ${n.active===false?'pending':'approved'}">${n.type==="urgent"?'⚠ জরুরি':'📢'} ${n.active===false?'বন্ধ':'প্রকাশিত'}</span><small>${esc(new Date(Number(n.publishedAt||Date.now())).toLocaleString("bn-BD"))}</small></div><h4>${esc(n.title)}</h4><p>${esc(n.text)}</p><div class="notice-admin-actions">${n.active===false?`<button class="primary-btn" data-notice="toggle" data-key="${esc(n.key)}" data-active="true">▶ আবার প্রকাশ</button>`:`<button class="secondary-btn" data-notice="toggle" data-key="${esc(n.key)}" data-active="false">⏸ সাময়িক বন্ধ</button>`}<button class="danger-lite" data-notice="delete" data-key="${esc(n.key)}">🗑 Delete</button></div></div>`).join(""):'<div class="empty">এখনও কোনো নোটিশ নেই।</div>';
    box.querySelectorAll("[data-notice]").forEach(b=>b.onclick=async()=>{try{if(b.dataset.notice==="delete"){if(!confirm("নোটিশটি মুছে ফেলবেন?"))return;await remove(ref(database,"publicNotices/"+b.dataset.key));showMsg("নোটিশ মুছে ফেলা হয়েছে");}else{await update(ref(database,"publicNotices/"+b.dataset.key),{active:b.dataset.active==="true"});showMsg("নোটিশের অবস্থা আপডেট হয়েছে");}}catch(e){showMsg("❌ নোটিশ আপডেট হয়নি: "+errorText(e),true);}});
  },e=>{box.innerHTML='<div class="empty">নোটিশ লোড করা যায়নি। Database Rules যাচাই করুন।</div>';showMsg("নোটিশ লোড ব্যর্থ: "+errorText(e),true);});
}
$("addNotice")?.addEventListener("click",async()=>{
  const title=$("noticeTitle").value.trim(),text=$("noticeText").value.trim();if(!title||!text){alert("শিরোনাম ও বিস্তারিত লিখুন।");return;}
  const now=Date.now(),days=Number($("noticeExpiry")?.value||0);
  try{await push(ref(database,"publicNotices"),{title,text,pinned:Boolean($("noticePinned")?.checked),type:$("noticeUrgent")?.checked?"urgent":"normal",active:true,publishedAt:now,expiresAt:days?now+days*86400000:0});$("noticeTitle").value="";$("noticeText").value="";showMsg("✅ নোটিশ প্রকাশ হয়েছে");}
  catch(e){showMsg("❌ নোটিশ প্রকাশ হয়নি: "+errorText(e),true);}
});

// Firebase-backed Knowledge Center (not browser-only localStorage)
function loadKnowledge(){
  stopListener("kb");const box=$("kbList");box.innerHTML='<div class="notice-loading">⏳ Firebase থেকে Knowledge লোড হচ্ছে…</div>';
  kbUnsub=onValue(ref(database,"aiKnowledge"),snap=>{knowledgeRows=[];if(snap.exists())snap.forEach(ch=>knowledgeRows.push({key:ch.key,...(ch.val()||{})}));knowledgeRows.sort((a,b)=>Number(b.updatedAt||b.createdAt||0)-Number(a.updatedAt||a.createdAt||0));renderKnowledge();},e=>{box.innerHTML='<div class="empty">Knowledge লোড করা যায়নি। Firebase Rules-এ aiKnowledge read permission যাচাই করুন।</div>';showMsg("Knowledge লোড ব্যর্থ: "+errorText(e),true);});
}
function renderKnowledge(){const box=$("kbList");if(!box)return;box.innerHTML=knowledgeRows.length?knowledgeRows.map(n=>`<div class="kb-item"><h4>${esc(n.q||n.question||"")}</h4><p>${esc(n.a||n.answer||"")}</p><small>${esc(n.updatedAt?new Date(Number(n.updatedAt)).toLocaleString("bn-BD"):"")}</small><br><button class="danger-lite" data-kb-delete="${esc(n.key)}">🗑 Delete</button></div>`).join(""):'<div class="empty">এখনও কোনো প্রকাশিত Knowledge নেই।</div>';box.querySelectorAll("[data-kb-delete]").forEach(b=>b.onclick=async()=>{if(!confirm("এই Knowledge মুছে ফেলবেন?"))return;try{await remove(ref(database,"aiKnowledge/"+b.dataset.kbDelete));showMsg("Knowledge মুছে ফেলা হয়েছে");}catch(e){showMsg("❌ Knowledge মুছতে পারেনি: "+errorText(e),true);}});}
$("saveKb")?.addEventListener("click",async()=>{const q=$("kbQuestion").value.trim(),a=$("kbAnswer").value.trim();if(!q||!a){alert("প্রশ্ন ও উত্তর দুটোই লিখুন।");return;}try{await push(ref(database,"aiKnowledge"),{q,a,active:true,createdAt:Date.now(),updatedAt:Date.now()});$("kbQuestion").value="";$("kbAnswer").value="";showMsg("✅ Knowledge Firebase-এ প্রকাশ হয়েছে");}catch(e){showMsg("❌ Knowledge সংরক্ষণ হয়নি: "+errorText(e)+" — Firebase Rules-এ aiKnowledge write permission প্রয়োজন।",true);}});
$("clearKb")?.addEventListener("click",async()=>{if(!confirm("সব Knowledge স্থায়ীভাবে মুছে ফেলবেন?"))return;try{await remove(ref(database,"aiKnowledge"));showMsg("সব Knowledge মুছে ফেলা হয়েছে");}catch(e){showMsg("❌ মুছতে পারেনি: "+errorText(e),true);}});
$("exportKb")?.addEventListener("click",()=>{if(!knowledgeRows.length){alert("Export করার মতো Knowledge নেই।");return;}const blob=new Blob([JSON.stringify(knowledgeRows.map(({key,...x})=>x),null,2)],{type:"application/json;charset=utf-8"}),url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download="dhonnobad-ai-knowledge.json";a.click();setTimeout(()=>URL.revokeObjectURL(url),800);});

// Member directory + editable monthly contribution ledger (May–December)
let memberRows=[], memberUnsub=null, ledgerUnsub=null, ledgerData={};
const monthNames={5:"মে",6:"জুন",7:"জুলাই",8:"আগস্ট",9:"সেপ্টেম্বর",10:"অক্টোবর",11:"নভেম্বর",12:"ডিসেম্বর"};
const todayISO=()=>{const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;};
function loadMembers(){
 if(memberUnsub)memberUnsub(); const box=$("memberList"); if(!box)return;
 box.innerHTML='<div class="notice-loading">সদস্যদের তথ্য লোড হচ্ছে…</div>';
 memberUnsub=onValue(ref(database,"members"),snap=>{memberRows=[];if(snap.exists())snap.forEach(ch=>memberRows.push({key:ch.key,...(ch.val()||{})}));memberRows.sort((a,b)=>String(a.name||"").localeCompare(String(b.name||""),"bn"));renderMembers();refreshMemberSelect();},e=>{box.innerHTML='<div class="empty">সদস্য লোড করা যায়নি। Database Rules/সংযোগ পরীক্ষা করুন।</div>';showMsg("সদস্য লোড ব্যর্থ: "+errorText(e),true);});
}
function renderMembers(){
 const box=$("memberList"),q=($("memberSearch")?.value||"").trim().toLowerCase();if(!box)return;
 const rows=memberRows.filter(m=>!m.archived&&(!q||[m.name,m.phone,m.whatsapp,m.address,m.position,m.memberType].join(" ").toLowerCase().includes(q)));
 $("memberSummary").textContent=`মোট সদস্য: ${memberRows.filter(m=>!m.archived).length} · দেখানো হচ্ছে: ${rows.length}`;
 box.innerHTML=rows.length?rows.map(m=>`<article class="member-card"><div class="member-card-top"><div><span class="status ${m.status==="নিষ্ক্রিয়"?'pending':'approved'}">${esc(m.status||"সক্রিয়")}</span><h3>${esc(m.name||"নাম নেই")}</h3><small>${esc(m.position||m.memberType||"পদ উল্লেখ নেই")}</small></div><span class="member-initial">${esc((m.name||"স").trim().slice(0,1))}</span></div><div class="details"><p>📱 <b>মোবাইল:</b> ${esc(m.phone||"-")}</p><p>💬 <b>WhatsApp:</b> ${esc(m.whatsapp||"-")}</p><p>📍 <b>ঠিকানা:</b> ${esc(m.address||"-")}</p><p><b>ID:</b> ${esc(m.key)}</p></div><div class="button-group"><button class="secondary-btn" data-member-edit="${esc(m.key)}">✏️ সম্পাদনা</button><button class="secondary-btn" data-member-ledger="${esc(m.key)}">📒 অনুদানের হিসাব</button><button class="archive-btn" data-member-archive="${esc(m.key)}">📦 আর্কাইভ</button></div></article>`).join(""):'<div class="empty">এখনও কোনো সদস্য নেই। “নতুন সদস্য” থেকে যোগ করুন।</div>';
 box.querySelectorAll("[data-member-edit]").forEach(b=>b.onclick=()=>editMember(b.dataset.memberEdit));
 box.querySelectorAll("[data-member-ledger]").forEach(b=>b.onclick=()=>{ $("ledgerMember").value=b.dataset.memberLedger; const mm=memberRows.find(x=>x.key===b.dataset.memberLedger); if($("ledgerMemberSearch"))$("ledgerMemberSearch").value=mm?.name||""; document.querySelector('[data-tab="ledger"]').click(); loadLedger();});
 box.querySelectorAll("[data-member-archive]").forEach(b=>b.onclick=async()=>{if(!confirm("সদস্যকে আর্কাইভ করবেন? সদস্যের হিসাব মুছে যাবে না।"))return;try{await update(ref(database,"members/"+b.dataset.memberArchive),{archived:true,archivedAt:Date.now()});showMsg("সদস্য আর্কাইভ করা হয়েছে");}catch(e){showMsg("আর্কাইভ করা যায়নি: "+errorText(e),true);}});
}
function refreshMemberSelect(){const sel=$("ledgerMember");if(!sel)return;const old=sel.value;sel.innerHTML='<option value="">সদস্য নির্বাচন করুন</option>'+memberRows.filter(m=>!m.archived).map(m=>`<option value="${esc(m.key)}">${esc(m.name||"নাম নেই")}</option>`).join("");const dl=$("ledgerMemberOptions");if(dl)dl.innerHTML=memberRows.filter(m=>!m.archived).map(m=>`<option value="${esc(m.name||"")}"></option>`).join("");if(memberRows.some(m=>m.key===old))sel.value=old;const inp=$("ledgerMemberSearch");if(inp&&sel.value){const found=memberRows.find(m=>m.key===sel.value);inp.value=found?.name||"";}}
function editMember(key){const m=memberRows.find(x=>x.key===key);if(!m)return;$("memberKey").value=key;$("memberName").value=m.name||"";$("memberPosition").value=m.position||m.memberType||"";$("memberPhone").value=m.phone||"";$("memberWhatsapp").value=m.whatsapp||"";$("memberAddress").value=m.address||"";$("memberForm").hidden=false;$("memberForm").scrollIntoView({behavior:"smooth",block:"start"});}
function clearMemberForm(){ $("memberForm").reset();$("memberKey").value="";$("memberForm").hidden=true; }
$("memberAddToggle")?.addEventListener("click",()=>{clearMemberForm();$("memberForm").hidden=false;$("memberName").focus();});
$("memberCancel")?.addEventListener("click",clearMemberForm);
$("memberForm")?.addEventListener("submit",async e=>{e.preventDefault();const name=$("memberName").value.trim();if(!name){alert("সদস্যের নাম লিখুন।");return;}const data={name,position:$("memberPosition").value.trim(),phone:$("memberPhone").value.trim(),whatsapp:$("memberWhatsapp").value.trim(),address:$("memberAddress").value.trim(),updatedAt:Date.now()};try{const key=$("memberKey").value;if(key)await update(ref(database,"members/"+key),data);else{data.createdAt=Date.now();await push(ref(database,"members"),data);}clearMemberForm();showMsg("✅ সদস্যের তথ্য সংরক্ষণ হয়েছে");}catch(err){showMsg("❌ সদস্য সংরক্ষণ হয়নি: "+errorText(err),true);}});
$("memberSearch")?.addEventListener("input",renderMembers);
$("memberExport")?.addEventListener("click",()=>{const rows=[["Name","Position","Phone","WhatsApp","Address"],...memberRows.filter(m=>!m.archived).map(m=>[m.name,m.position||m.memberType,m.phone,m.whatsapp,m.address])];downloadCSV(rows,"dhanyabad-members.csv");});
function downloadCSV(rows,name){const csv="\ufeff"+rows.map(r=>r.map(v=>'"'+String(v??"").replace(/"/g,'""')+'"').join(",")).join("\n");const a=document.createElement("a"),u=URL.createObjectURL(new Blob([csv],{type:"text/csv;charset=utf-8"}));a.href=u;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(u),1000);}
function ledgerPath(){return `contributions/${$("ledgerYear").value}`;}
function loadLedger(){if(ledgerUnsub){ledgerUnsub();ledgerUnsub=null;}const year=$("ledgerYear")?.value;if(!year)return;$("ledgerDate").value=$("ledgerDate").value||todayISO();ledgerUnsub=onValue(ref(database,ledgerPath()),snap=>{ledgerData=snap.val()||{};renderLedger();},e=>{showMsg("অনুদানের হিসাব লোড ব্যর্থ: "+errorText(e),true);});}
function monthRecord(member,month){return ledgerData?.[member]?.[month]||{};}
function paymentsOf(rec){const p=rec.payments||{};return Object.entries(p).map(([key,v])=>({key,...(v||{})}));}
function sumPaid(rec){return paymentsOf(rec).reduce((s,p)=>s+Number(p.amount||0),0);}
function renderLedger(){const mk=$("ledgerMember").value,box=$("ledgerHistory");const methods={Cash:0,bKash:0,Nagad:0};let grandExpected=0,grandPaid=0;
 Object.values(ledgerData||{}).forEach(m=>Object.values(m||{}).forEach(rec=>{grandExpected+=Number(rec.expected||0);paymentsOf(rec).forEach(p=>{grandPaid+=Number(p.amount||0);if(methods[p.method]!==undefined)methods[p.method]+=Number(p.amount||0);});}));
 $("ledgerMethodSummary").innerHTML=`<div><b>হাতে হাতে</b><strong>৳${methods.Cash.toLocaleString("bn-BD")}</strong></div><div><b>বিকাশ</b><strong>৳${methods.bKash.toLocaleString("bn-BD")}</strong></div><div><b>Nagad</b><strong>৳${methods.Nagad.toLocaleString("bn-BD")}</strong></div><div><b>সর্বমোট জমা</b><strong>৳${grandPaid.toLocaleString("bn-BD")}</strong></div>`;
 $("ledgerMemberSummary").textContent=`এই বছরের সব সদস্যের ধার্য: ৳${grandExpected.toLocaleString("bn-BD")} · জমা: ৳${grandPaid.toLocaleString("bn-BD")} · বকেয়া: ৳${Math.max(0,grandExpected-grandPaid).toLocaleString("bn-BD")}`;
 const table=$("ledgerMonthTable");if(!mk){table.innerHTML='<div class="empty">সদস্য নির্বাচন করলে মাসভিত্তিক হিসাব দেখাবে।</div>';box.innerHTML="";return;}
 const m=memberRows.find(x=>x.key===mk);let totalE=0,totalP=0;
 const tr=Object.keys(monthNames).map(month=>{const rec=monthRecord(mk,month),expected=Number(rec.expected??50),paid=sumPaid(rec),due=Math.max(0,expected-paid);totalE+=expected;totalP+=paid;return `<tr><td>${monthNames[month]}</td><td>৳${expected.toLocaleString("bn-BD")}</td><td>৳${paid.toLocaleString("bn-BD")}</td><td class="${due?'due-text':'paid-text'}">৳${due.toLocaleString("bn-BD")}</td><td><span class="status ${due?'pending':'approved'}">${due?'বকেয়া':'পরিশোধিত'}</span></td><td><button class="secondary-btn" data-month-edit="${month}">ধার্য এডিট</button></td></tr>`;}).join("");
 table.innerHTML=`<div class="ledger-member-title"><h3>${esc(m?.name||"সদস্য")}</h3><span>বছর ${esc($("ledgerYear").value)}</span></div><div class="table-wrap"><table class="ledger-table"><thead><tr><th>মাস</th><th>ধার্য</th><th>জমা</th><th>বকেয়া</th><th>অবস্থা</th><th>অ্যাকশন</th></tr></thead><tbody>${tr}<tr class="total-row"><td>মোট</td><td>৳${totalE.toLocaleString("bn-BD")}</td><td>৳${totalP.toLocaleString("bn-BD")}</td><td>৳${Math.max(0,totalE-totalP).toLocaleString("bn-BD")}</td><td colspan="2"></td></tr></tbody></table></div>`;
 table.querySelectorAll("[data-month-edit]").forEach(b=>b.onclick=()=>{const mon=b.dataset.month;$("ledgerMonth").value=mon;$("ledgerExpected").value=monthRecord(mk,mon).expected??50;$("ledgerExpected").focus();});
 const chosen=monthRecord(mk,$("ledgerMonth").value);$("ledgerExpected").value=chosen.expected??50;
 const pay=paymentsOf(chosen);box.innerHTML=`<h4>${monthNames[$("ledgerMonth").value]} মাসের পেমেন্ট ইতিহাস</h4>`+(pay.length?pay.map(p=>`<div class="payment-row"><div><b>৳${Number(p.amount||0).toLocaleString("bn-BD")}</b> · ${esc(p.method==="Cash"?"হাতে হাতে":p.method)}<small>${esc(p.date||"তারিখ নেই")} ${p.note?'· '+esc(p.note):''}</small></div><button class="danger-lite" data-payment-delete="${esc(p.key)}">মুছুন</button></div>`).join(""):'<div class="empty">এই মাসে কোনো পেমেন্ট যোগ হয়নি।</div>');
 box.querySelectorAll("[data-payment-delete]").forEach(b=>b.onclick=async()=>{if(!confirm("এই পেমেন্ট রেকর্ড মুছবেন?"))return;try{await remove(ref(database,`${ledgerPath()}/${mk}/${$("ledgerMonth").value}/payments/${b.dataset.paymentDelete}`));showMsg("পেমেন্ট মুছে ফেলা হয়েছে");}catch(e){showMsg("পেমেন্ট মোছা যায়নি: "+errorText(e),true);}});
}
function resolveLedgerMember(){const inp=$("ledgerMemberSearch"),sel=$("ledgerMember"),hint=$("ledgerMemberHint");if(!inp||!sel)return null;const value=inp.value.trim().toLocaleLowerCase("bn");const match=value?memberRows.find(m=>!m.archived&&String(m.name||"").trim().toLocaleLowerCase("bn")===value):null;sel.value=match?.key||"";if(hint){hint.textContent=match?`✓ সদস্য পাওয়া গেছে: ${match.name}`:(value?"⚠️ দয়া করে কোনো সদস্যের নামে টাকা জমা দিন।":"তালিকাভুক্ত সদস্যের সঠিক নাম লিখুন।");hint.classList.toggle("is-valid",!!match);hint.classList.toggle("is-invalid",!!value&&!match);}return match||null;}
$("ledgerMemberSearch")?.addEventListener("input",()=>{resolveLedgerMember();renderLedger();});
$("ledgerYear")?.replaceChildren(...Array.from({length:9},(_,i)=>{const y=new Date().getFullYear()-4+i,o=document.createElement("option");o.value=y;o.textContent=y;return o;}));if($("ledgerYear"))$("ledgerYear").value=new Date().getFullYear();
$("ledgerDate")&&($("ledgerDate").value=todayISO());
["ledgerYear","ledgerMember","ledgerMonth"].forEach(id=>$(id)?.addEventListener("change",()=>{if(id==="ledgerYear")loadLedger();else {if(id==="ledgerMember"&&$("ledgerMemberSearch")){const mm=memberRows.find(x=>x.key===$("ledgerMember").value);$("ledgerMemberSearch").value=mm?.name||"";}renderLedger();}}));
$("ledgerSetExpected")?.addEventListener("click",async()=>{const validMember=resolveLedgerMember();const mk=validMember?.key,month=$("ledgerMonth").value,amount=Number($("ledgerExpected").value);if(!mk){alert("দয়া করে কোনো সদস্যের নামে টাকা জমা দিন।");return;}if(!Number.isFinite(amount)||amount<0){alert("সঠিক ধার্য টাকা লিখুন।");return;}try{await update(ref(database,`${ledgerPath()}/${mk}/${month}`),{expected:amount,updatedAt:Date.now()});showMsg("মাসিক ধার্য সংরক্ষণ হয়েছে");}catch(e){showMsg("ধার্য সংরক্ষণ হয়নি: "+errorText(e),true);}});
$("ledgerSave")?.addEventListener("click",async()=>{const validMember=resolveLedgerMember();const mk=validMember?.key,month=$("ledgerMonth").value,amount=Number($("ledgerAmount").value);if(!mk){alert("দয়া করে কোনো সদস্যের নামে টাকা জমা দিন।");$("ledgerMemberSearch")?.focus();return;}if(!Number.isFinite(amount)||amount<=0){alert("জমার সঠিক পরিমাণ লিখুন।");return;}try{const base=`${ledgerPath()}/${mk}/${month}`;const current=monthRecord(mk,month);if(current.expected===undefined)await update(ref(database,base),{expected:Number($("ledgerExpected").value||50)});await push(ref(database,base+"/payments"),{amount,method:$("ledgerMethod").value,date:$("ledgerDate").value||todayISO(),note:$("ledgerNote").value.trim(),createdAt:Date.now()});$("ledgerAmount").value="";$("ledgerNote").value="";showMsg("✅ পেমেন্ট যোগ হয়েছে");}catch(e){showMsg("পেমেন্ট সংরক্ষণ হয়নি: "+errorText(e),true);}});
$("ledgerExport")?.addEventListener("click",()=>{const rows=[["Member","Year","Month","Expected","Paid","Due","Method","Amount","Date","Note"]];Object.entries(ledgerData||{}).forEach(([member,months])=>Object.entries(months||{}).forEach(([month,rec])=>{const m=memberRows.find(x=>x.key===member);const exp=Number(rec.expected||0),paid=sumPaid(rec);const ps=paymentsOf(rec);if(!ps.length)rows.push([m?.name||member,$("ledgerYear").value,monthNames[month],exp,0,Math.max(0,exp),"","","",""]);ps.forEach(p=>rows.push([m?.name||member,$("ledgerYear").value,monthNames[month],exp,paid,Math.max(0,exp-paid),p.method,p.amount,p.date,p.note]));}));downloadCSV(rows,"dhanyabad-contribution-ledger-"+$("ledgerYear").value+".csv");});
// Ensure added sections initialize when the authenticated admin opens the dashboard.
const previousAuthState=onAuthStateChanged;


// AI Analytics: aggregate anonymous topic counts from the aiAnalytics node.
function loadAIAnalytics(){const box=$("aiAnalyticsList"),summary=$("aiAnalyticsSummary");if(!box||!summary)return;summary.textContent="⏳ অ্যানালিটিক্স লোড হচ্ছে…";box.innerHTML="";onValue(ref(database,"aiAnalytics"),snap=>{const rows=[];if(snap.exists())snap.forEach(ch=>rows.push(ch.val()||{}));const valid=rows.filter(x=>x.topic&&Number(x.at));const counts={};valid.forEach(x=>counts[x.topic]=(counts[x.topic]||0)+1);const labels={membership:"সদস্য আবেদন",donation:"অনুদান",notices:"নোটিশ",contact:"যোগাযোগ",foundation:"ফাউন্ডেশন তথ্য",islamic:"ইসলামিক শিক্ষা",general:"অন্যান্য প্রশ্ন"};summary.textContent=`মোট লগ: ${valid.length} · বিষয়ের ধরন: ${Object.keys(counts).length}`;const entries=Object.entries(counts).sort((a,b)=>b[1]-a[1]);box.innerHTML=entries.length?`<div class="analytics-grid">${entries.map(([k,v])=>`<div class="stat-card"><h3>${esc(labels[k]||k)}</h3><h1>${v}</h1></div>`).join("")}</div><p class="muted">সর্বশেষ লগ: ${new Date(Math.max(...valid.map(x=>Number(x.at)))).toLocaleString("bn-BD")}</p>`:'<div class="empty">এখনো কোনো অ্যানালিটিক্স লগ নেই।</div>';},e=>{summary.textContent="অ্যানালিটিক্স পড়া যায়নি। Firebase Rules/permission পরীক্ষা করুন।";box.innerHTML="";});}
$("refreshAiAnalytics")?.addEventListener("click",loadAIAnalytics);

// Scheduled Daily Quiz Management
let quizAdminUnsub=null;
const QUIZ_GROUP_URL="https://chat.whatsapp.com/DB05tfjoR8DA5m6ql82xqR";
const quizLabels=["A","B","C","D"];
const quizDateToday=()=>{const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;};
function addDaysISO(iso,days){const d=new Date(`${iso}T12:00:00`);d.setDate(d.getDate()+days);return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;}
function quizAdminDate(){return $("quizDateAdmin")?.value||quizDateToday();}
function quizAdminDateTime(date,time){return new Date(`${date}T${time||"08:00"}:00`).getTime();}
function quizStatus(q,date){
  const now=Date.now(), at=Number(q.publishAt||0), today=quizDateToday();
  if(date===today && at && at<=now) return "live";
  if(at && at>now) return "scheduled";
  if(date<today) return "expired";
  return "draft";
}
function quizStatusLabel(st){return ({live:"🟢 Live",scheduled:"🟡 Scheduled",expired:"⚪ Expired",draft:"⚪ Draft"})[st]||st;}
function quizMessage(q,date){
  const opts=Array.isArray(q.options)?q.options:[];
  const idx=quizLabels.indexOf(q.correctAnswer||"A");
  const answer=opts[idx]||"";
  return `📢 আজকের কুইজের সঠিক উত্তর\n\n📝 প্রশ্ন: ${q.question||""}\n\n✅ সঠিক উত্তর: ${q.correctAnswer||"-"}${answer?` — ${answer}`:""}\n\n💡 সংক্ষেপে: ${q.explanation||""}\n\n🌙 ধন্যবাদ ফাউন্ডেশন`;
}
async function copyTextFallback(text){
  try{if(navigator.clipboard?.writeText){await navigator.clipboard.writeText(text);return true;}}catch{}
  try{const ta=document.createElement("textarea");ta.value=text;ta.style.position="fixed";ta.style.opacity="0";document.body.appendChild(ta);ta.focus();ta.select();const ok=document.execCommand("copy");ta.remove();return ok;}catch{return false;}
}
async function copyAndOpenQuizWhatsApp(date,key){
  const win=window.open(QUIZ_GROUP_URL,"_blank");
  try{
    const snap=await get(ref(database,"quizzes/"+key)); const q=snap.val();
    if(!q){if(win)win.close();showMsg("❌ কুইজটি পাওয়া যায়নি।",true);return;}
    const msg=quizMessage(q,date);
    const copied=await copyTextFallback(msg);
    if(!win)window.location.href=QUIZ_GROUP_URL;
    showMsg(copied?"✅ উত্তর মেসেজ কপি হয়েছে এবং WhatsApp Group খোলা হয়েছে। সেখানে Paste করে Send করুন।":"⚠️ WhatsApp Group খোলা হয়েছে। মেসেজ কপি করা যায়নি।");
  }catch(e){if(win)win.close();showMsg("❌ WhatsApp মেসেজ প্রস্তুত করা যায়নি: "+errorText(e),true);}
}
function clearQuizEditor(){
  $("quizDateAdmin").value=quizDateToday();
  $("quizTimeAdmin").value=$("quizChangeTime")?.value||"08:00";
  $("quizQuestionAdmin").value=""; [0,1,2,3].forEach(i=>$("quizOpt"+i).value="");
  $("quizCorrect").value="A"; $("quizExplanation").value="";
  $("quizEditorTitle").textContent="➕ নতুন কুইজ তৈরি করুন";
}
async function loadQuizSettings(){try{const s=await get(ref(database,"quizSettings"));const t=s.val()?.changeTime||"08:00";$("quizChangeTime").value=t;if(!$("quizTimeAdmin").value||$("quizTimeAdmin").value==="00:00")$("quizTimeAdmin").value=t;$("quizSettingsStatus").textContent=`ডিফল্ট প্রকাশের সময়: ${t}`;}catch(e){}}
async function loadQuizEditor(date){
  if(!date)return;
  try{
    const s=await get(ref(database,"quizzes/"+date));
    if(!s.exists()){clearQuizEditor();$("quizDateAdmin").value=date;return;}
    const q=s.val()||{}; $("quizDateAdmin").value=date; $("quizTimeAdmin").value=q.publishTime||$("quizChangeTime").value||"08:00";
    $("quizQuestionAdmin").value=q.question||""; (q.options||[]).slice(0,4).forEach((v,i)=>$("quizOpt"+i).value=v||"");
    for(let i=(q.options||[]).length;i<4;i++)$("quizOpt"+i).value="";
    $("quizCorrect").value=q.correctAnswer||"A"; $("quizExplanation").value=q.explanation||"";
    $("quizEditorTitle").textContent=`✏️ ${date} এর কুইজ সম্পাদনা`;
  }catch(e){showMsg("❌ কুইজ লোড করা যায়নি: "+errorText(e),true);}
}
async function loadQuizScheduleList(){
  const box=$("quizScheduleList"),summary=$("quizScheduleSummary"); if(!box||!summary)return;
  box.innerHTML='<div class="notice-loading">⏳ শিডিউল করা কুইজ লোড হচ্ছে…</div>';
  try{
    const s=await get(ref(database,"quizzes")); const rows=[];
    if(s.exists())s.forEach(ch=>rows.push({key:ch.key,...(ch.val()||{})}));
    rows.sort((a,b)=>Number(a.publishAt||0)-Number(b.publishAt||0));
    const now=Date.now(), upcoming=rows.filter(x=>Number(x.publishAt||0)>now).length, live=rows.filter(x=>quizStatus(x,x.key)==="live").length;
    summary.textContent=`মোট কুইজ: ${rows.length}টি · Scheduled: ${upcoming}টি · আজ Live: ${live}টি`;
    if(!rows.length){box.innerHTML='<div class="empty">এখনো কোনো কুইজ শিডিউল করা হয়নি। উপরের ফর্ম থেকে তৈরি করুন।</div>';return;}
    box.innerHTML=rows.map(q=>{
      const date=q.key, st=quizStatus(q,date), at=q.publishAt?new Date(Number(q.publishAt)).toLocaleString("bn-BD",{dateStyle:"medium",timeStyle:"short"}):`${date} · ${q.publishTime||"-"}`;
      const opts=Array.isArray(q.options)?q.options:[]; const idx=quizLabels.indexOf(q.correctAnswer||"A");
      return `<article class="quiz-schedule-card ${st}">
        <div class="quiz-schedule-main"><div class="quiz-schedule-date"><strong>${esc(date)}</strong><span class="quiz-status ${st}">${quizStatusLabel(st)}</span></div><h4>${esc(q.question||"প্রশ্ন নেই")}</h4><p>🕐 ${esc(at)} · ✅ সঠিক: ${esc(q.correctAnswer||"-")}${opts[idx]?` — ${esc(opts[idx])}`:""}</p></div>
        <div class="quiz-schedule-actions"><button class="secondary-btn" data-quiz-edit="${esc(date)}">✏️ Edit</button><button class="wa-quiz-btn" data-quiz-wa="${esc(date)}">💬 WhatsApp</button><button class="danger-lite" data-quiz-delete="${esc(date)}">🗑️ Delete</button></div>
      </article>`;
    }).join("");
    box.querySelectorAll("[data-quiz-edit]").forEach(b=>b.onclick=async()=>{await loadQuizEditor(b.dataset.quizEdit);$("quizQuestionAdmin")?.scrollIntoView({behavior:"smooth",block:"center"});});
    box.querySelectorAll("[data-quiz-wa]").forEach(b=>b.onclick=()=>copyAndOpenQuizWhatsApp(b.dataset.quizWa,b.dataset.quizWa));
    box.querySelectorAll("[data-quiz-delete]").forEach(b=>b.onclick=async()=>{const date=b.dataset.quizDelete;if(!confirm(`${date} এর কুইজ মুছে ফেলবেন? উত্তরগুলোর হিসাব মুছবে না।`))return;try{await remove(ref(database,"quizzes/"+date));showMsg("🗑️ কুইজ মুছে ফেলা হয়েছে");await loadQuizScheduleList();if(quizAdminDate()===date)clearQuizEditor();}catch(e){showMsg("❌ কুইজ মুছে ফেলা যায়নি: "+errorText(e),true);}});
  }catch(e){summary.textContent="শিডিউল লোড করা যায়নি।";box.innerHTML='<div class="empty">Firebase Rules/সংযোগ পরীক্ষা করুন।</div>';}
}
async function loadQuizAnswers(date){
  const box=$("quizAnswerList"),summary=$("quizAdminSummary");if(!box||!summary)return;summary.textContent="⏳ উত্তরগুলোর হিসাব লোড হচ্ছে…";box.innerHTML="";
  try{const s=await get(ref(database,"quizAnswers/"+date));const data=s.val()||{};const rows=Object.entries(data).map(([key,v])=>({key,...(v||{})})).sort((a,b)=>Number(b.submittedAt||0)-Number(a.submittedAt||0));const counts={A:0,B:0,C:0,D:0};rows.forEach(r=>{if(counts[r.optionLetter]!=null)counts[r.optionLetter]++;});
    summary.innerHTML=`<div class="quiz-answer-stats"><div><b>👥 মোট উত্তর</b><strong>${rows.length}</strong></div><div><b>A</b><strong>${counts.A}</strong></div><div><b>B</b><strong>${counts.B}</strong></div><div><b>C</b><strong>${counts.C}</strong></div><div><b>D</b><strong>${counts.D}</strong></div></div>`;
    box.innerHTML=rows.length?`<div class="quiz-answer-table-wrap"><table class="quiz-answer-table"><thead><tr><th>নাম</th><th>উত্তর</th><th>সময়</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${esc(r.name||"নাম নেই")}</td><td><b>${esc(r.optionLetter||"-")}</b> · ${esc(r.answer||"-")}</td><td>${esc(r.submittedAt?new Date(Number(r.submittedAt)).toLocaleString("bn-BD"):"-")}</td></tr>`).join("")}</tbody></table></div>`:'<div class="empty">এই দিনের কুইজে এখনো কোনো উত্তর আসেনি।</div>';
  }catch(e){summary.textContent="উত্তরের তথ্য লোড করা যায়নি।";box.innerHTML='<div class="empty">Firebase Rules/সংযোগ পরীক্ষা করুন।</div>';}
}
async function loadQuizAdmin(){
  await loadQuizSettings(); const date=quizAdminDate(); if(!$("quizDateAdmin").value)$("quizDateAdmin").value=date; await loadQuizEditor(date); await loadQuizScheduleList(); await loadQuizAnswers(date);
}
$("quizDateAdmin")?.addEventListener("change",async()=>{await loadQuizEditor(quizAdminDate());await loadQuizAnswers(quizAdminDate());});
$("quizToday")?.addEventListener("click",()=>{const d=quizDateToday();$("quizDateAdmin").value=d;loadQuizEditor(d);loadQuizAnswers(d);});
$("quizNextDay")?.addEventListener("click",()=>{const d=addDaysISO(quizAdminDate(),1);$("quizDateAdmin").value=d;loadQuizEditor(d);loadQuizAnswers(d);});
$("quizLoad")?.addEventListener("click",()=>loadQuizAdmin());
$("quizNew")?.addEventListener("click",clearQuizEditor);
$("quizRefreshList")?.addEventListener("click",loadQuizScheduleList);
$("quizRefreshAnswers")?.addEventListener("click",()=>loadQuizAnswers(quizAdminDate()));
$("saveQuizSettings")?.addEventListener("click",async()=>{const t=$("quizChangeTime").value||"08:00";try{await set(ref(database,"quizSettings"),{changeTime:t,updatedAt:Date.now()});$("quizSettingsStatus").textContent=`✅ ডিফল্ট সময় ${t} সংরক্ষণ হয়েছে।`;if(!$("quizTimeAdmin").value||$("quizTimeAdmin").value==="00:00")$("quizTimeAdmin").value=t;showMsg("✅ ডিফল্ট কুইজ প্রকাশের সময় সংরক্ষণ হয়েছে");}catch(e){showMsg("❌ সময় সংরক্ষণ হয়নি: "+errorText(e),true);}});
async function saveQuiz(moveNext=false){
  const date=quizAdminDate(),time=$("quizTimeAdmin").value||$("quizChangeTime").value||"08:00",question=$("quizQuestionAdmin").value.trim(),options=[0,1,2,3].map(i=>$("quizOpt"+i).value.trim()),correct=$("quizCorrect").value,explanation=$("quizExplanation").value.trim();
  if(!question||options.some(x=>!x)){alert("প্রশ্ন ও চারটি অপশনই পূরণ করুন।");return;}
  const publishAt=quizAdminDateTime(date,time); if(!Number.isFinite(publishAt)){alert("সঠিক তারিখ ও সময় দিন।");return;}
  try{
    const old=(await get(ref(database,"quizzes/"+date))).val()||{};
    await set(ref(database,"quizzes/"+date),{question,options,correctAnswer:correct,explanation,publishTime:time,publishAt,updatedAt:Date.now(),createdAt:old.createdAt||Date.now(),version:3});
    showMsg(`✅ ${date} এর কুইজ সফলভাবে শিডিউল হয়েছে।`);
    await loadQuizScheduleList();
    if(moveNext){const next=addDaysISO(date,1);$("quizDateAdmin").value=next;clearQuizEditor();$("quizDateAdmin").value=next;$("quizTimeAdmin").value=time;await loadQuizAnswers(next);$("quizQuestionAdmin").focus();} else {$("quizEditorTitle").textContent=`✏️ ${date} এর কুইজ সম্পাদনা`;$('quizAnswerList')&&await loadQuizAnswers(date);}
  }catch(e){showMsg("❌ কুইজ সংরক্ষণ হয়নি: "+errorText(e),true);}
}
$("saveQuiz")?.addEventListener("click",()=>saveQuiz(false));
$("saveQuizNext")?.addEventListener("click",()=>saveQuiz(true));
$("deleteQuiz")?.addEventListener("click",async()=>{const date=quizAdminDate();if(!confirm(`${date} এর কুইজ মুছে ফেলবেন? উত্তরগুলোর হিসাব মুছবে না।`))return;try{await remove(ref(database,"quizzes/"+date));clearQuizEditor();showMsg("🗑️ কুইজ মুছে ফেলা হয়েছে");await loadQuizScheduleList();await loadQuizAnswers(date);}catch(e){showMsg("❌ কুইজ মুছে ফেলা যায়নি: "+errorText(e),true);}});

/* Islamic Activity Center */
const activityISO=(d=new Date())=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
const activityAddDays=(date,n)=>{const d=new Date(date+'T12:00:00');d.setDate(d.getDate()+n);return activityISO(d)};
const activityDuaSeed=[['উপকারী জ্ঞানের দোয়া','রব্বি যিদনী ইলমা','হে আমার রব, আমার জ্ঞান বৃদ্ধি করে দিন।','পড়াশোনা বা জ্ঞান অর্জনের সময় পড়তে পারেন।'],['দুনিয়া ও আখিরাতের কল্যাণ','রব্বানা আতিনা ফিদ্দুনইয়া হাসানাতাও ওয়া ফিল-আখিরাতি হাসানাতাও ওয়াকিনা আজাবান নার','হে আমাদের রব, আমাদের দুনিয়ায় কল্যাণ দিন এবং আখিরাতেও কল্যাণ দিন এবং আগুনের শাস্তি থেকে রক্ষা করুন।','সাধারণভাবে বেশি বেশি পড়া যায়।'],['ক্ষমা চাওয়ার দোয়া','রব্বিগফির লি','হে আমার রব, আমাকে ক্ষমা করুন।','তওবা ও ক্ষমা চাওয়ার সময়।'],['মা-বাবার জন্য দোয়া','রব্বির হামহুমা কামা রব্বায়ানী সগীরা','হে আমার রব, তাঁদের প্রতি দয়া করুন, যেমন তাঁরা আমাকে ছোটবেলায় লালন-পালন করেছেন।','মা-বাবার জন্য দোয়া করার সময়।'],['সঠিক পথের দোয়া','ইহদিনাস সিরাতাল মুস্তাকীম','আমাদের সরল পথ দেখান।','সূরা ফাতিহার এই দোয়াটি নামাজে প্রতিদিন পড়া হয়।'],['নিরাপত্তার জন্য দোয়া','আল্লাহুম্মা ইন্নি আসআলুকাল আফওয়া ওয়াল আফিয়াহ','হে আল্লাহ, আমি আপনার কাছে ক্ষমা ও নিরাপত্তা চাই।','সুস্থতা ও নিরাপত্তার জন্য দোয়া করতে পারেন।'],['ইবাদতের তাওফিক','আল্লাহুম্মা আঈন্নি আলা যিকরিকা ওয়া শুকরিকা ওয়া হুসনি ইবাদাতিক','হে আল্লাহ, আপনার স্মরণ, কৃতজ্ঞতা ও সুন্দরভাবে ইবাদত করতে আমাকে সাহায্য করুন।','ইবাদতের তাওফিক চাওয়ার জন্য।'],['দুশ্চিন্তা থেকে আশ্রয়','আল্লাহুম্মা ইন্নি আউযু বিকা মিনাল হাম্মি ওয়াল হাজান','হে আল্লাহ, আমি দুশ্চিন্তা ও দুঃখ থেকে আপনার আশ্রয় চাই।','দুশ্চিন্তা বা দুঃখের সময়।'],['ঈমানের স্থিরতার জন্য','রব্বানা লা তুযিগ কুলুবানা বাদ ইয হাদাইতানা','হে আমাদের রব, হেদায়াত দেওয়ার পর আমাদের অন্তর বেঁকিয়ে দেবেন না।','ঈমানের ওপর অটল থাকার জন্য।'],['কাজ সহজ হওয়ার দোয়া','রব্বি শারহ লি সদরি, ওয়া ইয়াসসির লি আমরি','হে আমার রব, আমার অন্তর প্রশস্ত করুন এবং আমার কাজ সহজ করুন।','গুরুত্বপূর্ণ ভালো কাজের আগে পড়তে পারেন।']];
const activityAmalSeed=[['আজকের আমল: মা-বাবাকে সাহায্য','আজ ইচ্ছা করে মা বা বাবার একটি কাজে সাহায্য করুন এবং বিনিময়ে কিছু আশা করবেন না।'],['আজকের আমল: কুরআন','আজ অন্তত কয়েকটি আয়াত মনোযোগ দিয়ে পড়ুন এবং অর্থ বোঝার চেষ্টা করুন।'],['আজকের আমল: ইস্তিগফার','আজ কিছু সময় নিয়ে আন্তরিকভাবে আল্লাহর কাছে ক্ষমা চান।'],['আজকের আমল: সালাম','আজ দেখা হওয়া মুসলিম ভাই-বোনকে আগে সালাম দেওয়ার চেষ্টা করুন।'],['আজকের আমল: সদকা','সামর্থ্য অনুযায়ী কাউকে সাহায্য করুন—টাকা না হলেও খাবার, সময় বা সহযোগিতা হতে পারে।'],['আজকের আমল: ভালো কথা','আজ অন্তত একজন মানুষকে এমন একটি ভালো কথা বলুন যা তার মন ভালো করে।'],['আজকের আমল: নামাজ','আজ পাঁচ ওয়াক্ত নামাজ সময়মতো আদায় করার জন্য সচেতন থাকুন।'],['আজকের আমল: গীবত থেকে বিরত থাকা','আজ কারও অনুপস্থিতিতে তার সম্পর্কে খারাপ কথা না বলার বিশেষ চেষ্টা করুন।'],['আজকের আমল: দরুদ','আজ কিছু সময় আল্লাহর রাসূল ﷺ-এর ওপর দরুদ পাঠ করুন।'],['আজকের আমল: গোপন ভালো কাজ','আজ এমন একটি ভালো কাজ করুন যা শুধু আল্লাহ জানবেন।']];
async function seedActivityAdmin(){const base=activityISO();const writes={};try{const [d,a]=await Promise.all([get(ref(database,'dailyDuas')),get(ref(database,'dailyAmals'))]);const dv=d.val()||{},av=a.val()||{};for(let i=0;i<10;i++){const day=activityAddDays(base,i);const x=activityDuaSeed[i],y=activityAmalSeed[i];if(!dv[day])writes['dailyDuas/'+day]={title:x[0],text:x[1],meaning:x[2],when:x[3],publishAt:new Date(day+'T08:00:00').getTime(),createdAt:Date.now()};if(!av[day])writes['dailyAmals/'+day]={title:y[0],text:y[1],publishAt:new Date(day+'T08:00:00').getTime(),createdAt:Date.now()};}if(Object.keys(writes).length)await Promise.all(Object.entries(writes).map(([p,v])=>set(ref(database,p),v)));showMsg('✅ ১০ দিনের দোয়া ও আমলের Schedule প্রস্তুত হয়েছে।');await loadActivityAdmin();}catch(e){showMsg('❌ Schedule তৈরি করা যায়নি: '+errorText(e),true);}}
async function loadActivityAdmin(){const base=activityISO();const list=$('activityScheduleList');if(!list)return;try{const [ds,as,cs]=await Promise.all([get(ref(database,'dailyDuas')),get(ref(database,'dailyAmals')),get(ref(database,'dailyChallenge'))]);const d=ds.val()||{},a=as.val()||{},c=cs.val()||{};const days=Array.from({length:10},(_,i)=>activityAddDays(base,i));const totalD=Object.keys(d).length,totalA=Object.keys(a).length;$('activityAdminStats').innerHTML=`<div class="activity-admin-stat"><span>🤲 মোট দোয়া</span><strong>${totalD}</strong></div><div class="activity-admin-stat"><span>✨ মোট আমল</span><strong>${totalA}</strong></div><div class="activity-admin-stat"><span>📅 সামনে ১০ দিন</span><strong>${days.filter(x=>d[x]||a[x]).length}</strong></div><div class="activity-admin-stat"><span>🔥 Challenge</span><strong>${Object.keys(c).length}</strong></div>`;const td=d[base]||{},ta=a[base]||{};$('adminTodayDua').innerHTML=`<b>${esc(td.title||'আজকের দোয়া নেই')}</b><p>${esc(td.text||'')}</p>`;$('adminTodayAmal').innerHTML=`<b>${esc(ta.title||'আজকের আমল নেই')}</b><p>${esc(ta.text||'')}</p>`;const tc=c[base];$('adminTodayChallenge').innerHTML=tc?`<b>${esc(tc.title||'Challenge')}</b><p>${esc(tc.intro||'')}</p>`:'<p>আজকের Challenge নেই।';list.innerHTML=days.map(day=>`<div class="activity-schedule-row"><b>${esc(day)}</b><span>🤲 ${esc(d[day]?.title||'দোয়া নেই')}</span><span>✨ ${esc(a[day]?.title||'আমল নেই')}</span></div>`).join('');$('activityDate').value=$('activityDate').value||base;await loadActivityEditor($('activityDate').value);await loadActivityTrackerAdmin();}catch(e){list.innerHTML='<div class="empty">Activity data লোড করা যায়নি। Firebase Rules/সংযোগ পরীক্ষা করুন।</div>';}}
async function loadActivityEditor(day){try{const [ds,as]=await Promise.all([get(ref(database,'dailyDuas/'+day)),get(ref(database,'dailyAmals/'+day))]);const d=ds.val()||{},a=as.val()||{};$('activityDuaTitle').value=d.title||'';$('activityDuaText').value=d.text||'';$('activityDuaMeaning').value=d.meaning||'';$('activityDuaWhen').value=d.when||'';$('activityAmalTitle').value=a.title||'';$('activityAmalText').value=a.text||'';}catch(e){showMsg('❌ কনটেন্ট লোড হয়নি: '+errorText(e),true);}}
async function saveActivityEditor(){const day=$('activityDate').value;if(!day){alert('তারিখ দিন।');return;}try{await set(ref(database,'dailyDuas/'+day),{title:$('activityDuaTitle').value.trim(),text:$('activityDuaText').value.trim(),meaning:$('activityDuaMeaning').value.trim(),when:$('activityDuaWhen').value.trim(),publishAt:new Date(day+'T08:00:00').getTime(),updatedAt:Date.now()});await set(ref(database,'dailyAmals/'+day),{title:$('activityAmalTitle').value.trim(),text:$('activityAmalText').value.trim(),publishAt:new Date(day+'T08:00:00').getTime(),updatedAt:Date.now()});showMsg('✅ '+day+' এর দোয়া ও আমল সংরক্ষণ হয়েছে।');await loadActivityAdmin();}catch(e){showMsg('❌ সংরক্ষণ হয়নি: '+errorText(e),true);}}
$('activitySeedBtn')?.addEventListener('click',seedActivityAdmin);$('activityRefresh')?.addEventListener('click',loadActivityAdmin);$('activityTrackerRefresh')?.addEventListener('click',loadActivityTrackerAdmin);$('activityLoad')?.addEventListener('click',()=>loadActivityEditor($('activityDate').value));$('activitySave')?.addEventListener('click',saveActivityEditor);$('activityDate')?.addEventListener('change',()=>loadActivityEditor($('activityDate').value));
const origLoadTab=loadQuizAdmin;

async function loadActivityTrackerAdmin(){
 const body=$('activityTrackerBody');if(!body)return;
 body.innerHTML='<tr><td colspan="12">⏳ Activity রিপোর্ট লোড হচ্ছে…</td></tr>';
 try{
  const [us,ls]=await Promise.all([get(ref(database,'activityUsers')),get(ref(database,'activityLogs'))]);
  const users=us.val()||{},logs=ls.val()||{}; const rows=[];
  let totalUsers=Object.keys(users).length, totalPrayer=0,totalFullDays=0,totalDua=0,totalAmal=0,totalChallenge=0;
  Object.entries(users).forEach(([uid,u])=>{
   const userLogs=logs[uid]||{};let pf=0,pz=0,pa=0,pm=0,pe=0,full=0,du=0,am=0,ch=0,last='—';
   Object.entries(userLogs).forEach(([day,v])=>{if(!v||typeof v!=='object')return;const pr=v.prayer||{};pf+=pr.fajr?1:0;pz+=pr.zuhr?1:0;pa+=pr.asr?1:0;pm+=pr.maghrib?1:0;pe+=pr.isha?1:0;const pc=[pr.fajr,pr.zuhr,pr.asr,pr.maghrib,pr.isha].filter(Boolean).length;totalPrayer+=pc;if(pc===5)full++;if(v.duaDone)du++;if(v.amalDone)am++;if(Array.isArray(v.challenge))ch+=v.challenge.filter(Boolean).length;if(day>last)last=day;});
   totalFullDays+=full;totalDua+=du;totalAmal+=am;totalChallenge+=ch;
   rows.push({uid,name:u.name||'নাম নেই',pf,pz,pa,pm,pe,full,du,am,ch,last});
  });
  rows.sort((a,b)=>a.name.localeCompare(b.name,'bn'));
  $('activityTrackerStats').innerHTML=[['👤','অ্যাক্টিভিটি ইউজার',totalUsers],['🕌','মোট নামাজ টিক',totalPrayer],['🌙','পূর্ণ ৫ ওয়াক্তের দিন',totalFullDays],['🤲','দোয়া সম্পন্ন',totalDua],['✨','আমল + Challenge',totalAmal+totalChallenge]].map(x=>`<div class="activity-tracker-stat"><b>${x[0]} ${x[1]}</b><strong>${x[2]}</strong></div>`).join('');
  if(!rows.length){body.innerHTML='<tr><td colspan="12">এখনও কোনো Activity user তৈরি হয়নি।</td></tr>';return;}
  body.innerHTML=rows.map(r=>{const vals=[r.pf,r.pz,r.pa,r.pm,r.pe,r.full,r.du,r.am,r.ch];return `<tr><td><b>${esc(r.name)}</b></td>${vals.map(v=>`<td class="${v?'tracker-good':'tracker-zero'}">${v}</td>`).join('')}<td>${r.last==='—'?'—':esc(r.last)}</td><td><button class="tracker-detail-btn" data-activity-user="${r.uid}">বিস্তারিত</button></td></tr>`}).join('');
  body.querySelectorAll('[data-activity-user]').forEach(btn=>btn.onclick=()=>showActivityUserDetail(btn.dataset.activityUser,users,logs));
 }catch(e){body.innerHTML=`<tr><td colspan="12">❌ Activity রিপোর্ট লোড করা যায়নি: ${esc(errorText(e))}</td></tr>`;}
}
function showActivityUserDetail(uid,users,logs){
 const box=$('activityUserDetail');if(!box)return;const u=users[uid]||{};const entries=Object.entries(logs[uid]||{}).filter(([d,v])=>v&&typeof v==='object').sort((a,b)=>b[0].localeCompare(a[0]));
 let pf=0,pz=0,pa=0,pm=0,pe=0,full=0,du=0,am=0,ch=0;entries.forEach(([d,v])=>{const p=v.prayer||{};pf+=p.fajr?1:0;pz+=p.zuhr?1:0;pa+=p.asr?1:0;pm+=p.maghrib?1:0;pe+=p.isha?1:0;const pc=[p.fajr,p.zuhr,p.asr,p.maghrib,p.isha].filter(Boolean).length;if(pc===5)full++;if(v.duaDone)du++;if(v.amalDone)am++;if(Array.isArray(v.challenge))ch+=v.challenge.filter(Boolean).length;});
 box.innerHTML=`<div class="activity-detail-head"><div><span class="eyebrow">ACTIVITY PROFILE</span><h4>👤 ${esc(u.name||'নাম নেই')}</h4></div><button class="secondary-btn" id="closeActivityDetail">✕ বন্ধ</button></div><div class="activity-detail-grid"><div><b>ফজর</b><strong>${pf}</strong></div><div><b>যোহর</b><strong>${pz}</strong></div><div><b>আসর</b><strong>${pa}</strong></div><div><b>মাগরিব</b><strong>${pm}</strong></div><div><b>এশা</b><strong>${pe}</strong></div><div><b>পূর্ণ ৫ ওয়াক্তের দিন</b><strong>${full}</strong></div><div><b>দোয়া সম্পন্ন</b><strong>${du}</strong></div><div><b>আমল সম্পন্ন</b><strong>${am}</strong></div><div><b>Challenge টাস্ক</b><strong>${ch}</strong></div></div><h4>📅 দিনের বিস্তারিত</h4><div class="activity-history">${entries.length?entries.slice(0,60).map(([d,v])=>{const p=v.prayer||{},pc=[p.fajr,p.zuhr,p.asr,p.maghrib,p.isha].filter(Boolean).length;const cc=Array.isArray(v.challenge)?v.challenge.filter(Boolean).length:0;return `<div class="activity-history-row"><b>${esc(d)}</b><span>🕌 নামাজ: ${pc}/5</span><span>🤲 দোয়া: ${v.duaDone?'হ্যাঁ':'না'}</span><span>✨ আমল: ${v.amalDone?'হ্যাঁ':'না'}</span><span>🔥 Challenge: ${cc}</span></div>`}).join(''):'<div class="empty">কোনো দিনের রেকর্ড নেই।</div>'}</div>`;
 box.classList.add('show');$('closeActivityDetail').onclick=()=>box.classList.remove('show');box.scrollIntoView({behavior:'smooth',block:'nearest'});
}

// activity is initialized when its admin tab is opened via the shared tab handler below

// Website login users + in-site notification manager
const memberUsersCache = {};
async function loadRegisteredUsers(){
  const box=$('registeredUserList'), summary=$('registeredUserSummary'), target=$('memberNoticeTarget');
  if(!box||!summary||!target)return;
  summary.textContent='⏳ নিবন্ধিত ইউজার লোড হচ্ছে…'; box.innerHTML='';
  try{
    const snap=await get(ref(database,'memberUsers')); const rows=[];
    if(snap.exists())snap.forEach(ch=>{const v=ch.val()||{};if(v.status!=='deleted'&&v.phone)rows.push({uid:ch.key,...v});});
    rows.sort((a,b)=>Number(b.createdAt||0)-Number(a.createdAt||0));
    Object.keys(memberUsersCache).forEach(k=>delete memberUsersCache[k]); rows.forEach(u=>memberUsersCache[u.uid]=u);
    const old=target.value; target.innerHTML='<option value="all">সব নিবন্ধিত ইউজার</option>'+rows.map(u=>`<option value="${esc(u.uid)}">${esc(u.name||'নাম নেই')} — ${esc(u.phone||'')}</option>`).join(''); if([...target.options].some(o=>o.value===old))target.value=old;
    summary.textContent=`মোট সক্রিয় নিবন্ধিত ইউজার: ${rows.length}`;
    if(!rows.length){box.innerHTML='<div class="empty">এখনো কোনো ইউজার নিবন্ধন করেনি।</div>';return;}
    box.innerHTML='<div class="registered-user-grid">'+rows.map(u=>`<article class="registered-user-card"><h4>${esc(u.name||'নাম নেই')}</h4><p>📱 ${esc(u.phone||'-')}</p><p>🆔 <small>${esc(u.uid)}</small></p><p>🗓 নিবন্ধন: ${u.createdAt?esc(new Date(Number(u.createdAt)).toLocaleString('bn-BD')):'-'}</p><p>🟢 অবস্থা: ${esc(u.status||'active')}</p><button type="button" class="delete-btn" data-member-delete="${esc(u.uid)}">🗑 ইউজার ও লগইন রেকর্ড মুছুন</button></article>`).join('')+'</div>';
    box.querySelectorAll('[data-member-delete]').forEach(btn=>btn.addEventListener('click',()=>deleteRegisteredUser(btn.dataset.memberDelete)));
  }catch(e){console.error(e);summary.textContent='ইউজার লোড করা যায়নি। Firebase Rules-এ memberUsers read permission পরীক্ষা করুন।';}
}
async function deleteRegisteredUser(uid){
  const user=memberUsersCache[uid]; if(!user)return;
  if(!confirm(`${user.name||'এই ইউজার'} (${user.phone})-এর লগইন তথ্য মুছে দেবেন? মুছে দিলে এই নম্বর দিয়ে আবার নিবন্ধন করা যাবে।`))return;
  try{
    await remove(ref(database,'memberUsers/'+uid));
    if(user.phone)await remove(ref(database,'memberPhoneIndex/'+String(user.phone).replace(/\D/g,'')));
    await remove(ref(database,'memberNotifications/'+uid));
    showMsg('✅ ইউজারের রেকর্ড ও ব্যক্তিগত নোটিফিকেশন মুছে ফেলা হয়েছে।'); await loadRegisteredUsers();
  }catch(e){showMsg('❌ ইউজার মুছতে ব্যর্থ: '+errorText(e),true);}
}
$('memberUsersRefresh')?.addEventListener('click',loadRegisteredUsers);
$('memberNoticeSend')?.addEventListener('click',async()=>{
  const title=$('memberNoticeTitle').value.trim(), message=$('memberNoticeMessage').value.trim(), target=$('memberNoticeTarget').value||'all', status=$('memberNoticeStatus'), btn=$('memberNoticeSend');
  if(!title||!message){status.textContent='শিরোনাম ও বিস্তারিত লিখুন।';return;}
  btn.disabled=true;status.textContent='নোটিফিকেশন পাঠানো হচ্ছে…';
  const payload={title,message,createdAt:Date.now(),sentBy:auth.currentUser?.uid||'admin'};
  try{
    if(target==='all')await push(ref(database,'memberBroadcasts'),payload);
    else {if(!memberUsersCache[target])throw new Error('ইউজার তালিকা রিফ্রেশ করে আবার চেষ্টা করুন।');await push(ref(database,'memberNotifications/'+target),payload);}
    status.textContent=target==='all'?'✅ নোটিফিকেশন সব নিবন্ধিত ইউজারের জন্য প্রকাশিত হয়েছে।':'✅ নির্বাচিত ইউজারের কাছে নোটিফিকেশন পাঠানো হয়েছে।';$('memberNoticeTitle').value='';$('memberNoticeMessage').value='';showMsg('📣 সদস্য নোটিফিকেশন প্রকাশিত হয়েছে।');
  }catch(e){status.textContent='❌ পাঠানো যায়নি: '+errorText(e);}
  finally{btn.disabled=false;}
});
const originalMemberTabHandler = tabButtons.find(b=>b.dataset.tab==='users');
originalMemberTabHandler?.addEventListener('click',loadRegisteredUsers);
