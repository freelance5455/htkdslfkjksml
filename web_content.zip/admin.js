const conf = {
  a: "AIzaSyAzPtsCI0KJCrUgiQFMjh8SUud04_WE3Es",
  b: "://firebaseapp.com",
  c: "https://firebaseio.com",
  d: "admin-panel-d9281",
  e: "://appspot.com",
  f: "300774487431",
  g: "1:300774487431:web:811df162901f456758cf22"
};

const firebaseConfig = {
  apiKey: conf.a,
  authDomain: conf.b,
  databaseURL: conf.c,
  projectId: conf.d,
  storageBucket: conf.e,
  messagingSenderId: conf.f,
  appId: conf.g
};

firebase.initializeApp(firebaseConfig);
const database = firebase.database();

function addTournament() {
    let nameInput = document.getElementById("tn");
    let entryInput = document.getElementById("entry");
    let name = nameInput.value.trim();
    let entry = entryInput.value.trim();
    if (name === "" || entry === "") {
        alert("ম্যাচের নাম এবং এন্ট্রি ফি লিখুন!");
        return;
    }
    database.ref('tournaments/').push({
        name: name,
        entry: Number(entry),
        status: "open"
    }).then(() => {
        alert("ম্যাচ সফলভাবে ফায়ারবেসে যুক্ত হয়েছে!");
        nameInput.value = "";
        entryInput.value = "";
    }).catch((error) => {
        alert("ভুল হয়েছে: " + error.message);
    });
}