# ANONYMOUX STUDIOS 2.4.0 — Source Audit Report

Audit target: `ANONYMOUX_STUDIOS_2.3.3_MAGICHOUR_INTEGRATION.zip`  
Approach: independent source inspection; prior build reports were treated as historical documentation, not proof.  
Scope inspected: 139 files after rebuild (PHP, JavaScript, CSS, SQL, documentation and media). Original archive contained 131 files.

## Findings and remediation register

| File | Severity | Finding / source evidence | Recommended fix | Action taken | Verification |
|---|---|---|---|---|---|
| `app/auth.php` | Critical | Original `auth_register()` assigned `admin` only when an email matched optional `admin_emails`; it did not implement atomic first-user initialization. | Serialize registration and derive role exclusively from server-side administrator count. | Added singleton `admin_bootstrap_lock`; SQLite uses `BEGIN IMMEDIATE`, MySQL locks the singleton row with `FOR UPDATE`; first account becomes admin, later accounts member. | PASS — PHP syntax and source-path inspection. Runtime concurrency test NOT TESTED (PDO drivers unavailable). |
| `config.local.example.php` | High | Original template exposed the `admin_emails` allow-list as the administrator bootstrap mechanism. | Remove registration allow-list role assignment. | Removed `admin_emails` template setting; registration no longer reads it. | PASS — source inspection. |
| `ADMIN-PROMOTION.sql` | High | Original SQL promoted the hardcoded email `admin@gmail.com` to admin. | Remove hardcoded identity promotion and provide controlled recovery. | Removed the SQL file; added CLI-only `tools-recover-admin.php`. | PASS — file removal and PHP syntax. CLI recovery execution NOT TESTED against a live DB. |
| `admin.php`, `app/admin.php` | High | Existing admin interface had user/API/voice/model/Magic Hour/resources/system controls but no package, payment order or Flutterwave configuration workflow. | Add payment controls to the authoritative admin implementation. | Rebuilt the navigation as a grouped responsive sidebar; added a dedicated wallet/credit ledger view, Payments tab, gateway configuration, encrypted secret storage, connection test, package create/edit/activate controls, order ledger and summary counts. | PASS — PHP syntax and route/source inspection; DB-backed actions NOT TESTED. |
| `admin-panel.php`, `admin/index.php`, `dashboard/admin.php` | Medium | Multiple URLs can look like competing admin implementations. Source inspection shows thin `require` aliases, not independent controllers. | Retain compatibility URLs but route all to one implementation; compute correct base URL for subdirectory deployment. | Kept wrappers and corrected base URL derivation for nested deployments. | PASS — syntax and static reference checks. Browser navigation NOT TESTED. |
| `app/voice.php` | High | Existing authoritative wallet and credit ledger are coupled to Voice Studio (`user_wallets`, `credit_transactions`, `voice_wallet_ensure()`). A separate payment wallet would create inconsistent balances. | Reuse the current wallet and ledger. | Payment verification calls the existing wallet initializer, increments the same wallet and writes the same credit ledger in the payment transaction. | PASS — implementation inspection; DB execution NOT TESTED. |
| `app/payments.php` | Critical | No Flutterwave payment implementation existed in the supplied source. | Create pending orders server-side, verify provider transactions server-side, validate order/user/amount/currency and allocate credits idempotently. | Added encrypted credential handling, package/order schema, checkout initialization, transaction verification, locked ledger update, unique references and provider transaction IDs. | PASS — PHP syntax/static inspection. Flutterwave calls NOT TESTED (no cURL/provider credentials). |
| `api/payments.php` | High | No authenticated payment API existed. | Require user authentication and CSRF for checkout; require ownership for redirect verification. | Added POST checkout and authenticated GET verification endpoints. | PASS — syntax; HTTP integration NOT TESTED. |
| `api/flutterwave-webhook.php` | Critical | No signed payment webhook existed. | Validate `verif-hash`, then independently verify transaction before wallet allocation. | Added signature validation and shared idempotent server-side verification path. | PASS — syntax/static inspection; signed webhook test NOT TESTED. |
| `credits.php` | High | No customer-facing credit package checkout page existed. | Display active packages, launch hosted checkout and show server verification result. | Added package listing, wallet balance, purchase history and redirect verification. | PASS — syntax/static reference checks; browser/provider flow NOT TESTED. |
| `app/bootstrap.php`, `app/auth.php`, `app/payments.php` | High | New persistence requirements need additive schema changes without resetting existing data. | Create tables idempotently and preserve wallet/user tables. | Added payment tables through runtime schema helpers and explicit SQLite/MySQL migration `003`. Existing user and wallet tables are not dropped or reset. | PASS — SQLite migration repeatability tested using Python sqlite3; PHP PDO DB runtime NOT TESTED. |
| `.htaccess`, `storage/.htaccess` | High | Original root `.htaccess` did not deny direct requests to the storage directory even though the app stores the SQLite DB and private media there. | Deny web access to all storage paths. | Added root rewrite denial, storage-level deny rules and a storage index fallback. | PASS — configuration inspection; hosting-server behavior NOT TESTED. |
| `README.md`, `migrations/README.md` | Medium | Existing instructions described the superseded email allow-list and did not cover the new payment deployment. | Replace obsolete guidance and document current bootstrap, secrets, webhook and migrations. | Updated instructions and migration documentation. | PASS — documentation inspection. |
| `tests/smoke.php` | Medium | Original smoke test did not include admin bootstrap or payment tables. | Extend table checks while preserving a clean skip when PDO SQLite is unavailable. | Added auth/payment schema checks and required table assertions. | NOT TESTED — correctly skipped because this PHP runtime has no PDO drivers. |

## Additional inspection results

- All PHP source files were run through `php -l`: PASS.
- All JavaScript files were run through `node --check`: PASS.
- Static local `href`/`src` scan: no missing literal local references found.
- Existing resource migration test: PASS (SQLite migration repeatability, table/index creation and sample writes).
- New migration `003_flutterwave_payments_sqlite.sql`: PASS in Python sqlite3 when executed twice.
- Dangerous dynamic execution patterns: no `eval`, `shell_exec`, `system`, `passthru` or `unserialize` calls found in PHP source.
- Existing creative workspaces, Decart/Magic Hour/Fish Audio modules, resource centre, assets and user-facing routes were retained.
- Existing `admin_resources_view.php` and `admin_magichour_view.php` are admin tab partials, not competing admin controllers; retained.
- Admin URL aliases were retained for backward compatibility and point to `admin.php`.

## Verification limitations

The audit environment's PHP runtime reports no available PDO drivers and lacks the cURL extension. Therefore no PHP database migration, registration race test, wallet transaction test, Flutterwave checkout, provider verification, webhook signature round-trip or live browser test could be executed here. These are marked NOT TESTED rather than passed.
