package com.cg10.plonge;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class ReminderReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        String text = intent.getStringExtra("text");
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel("rappels", "Rappels de plonge et cuisine", NotificationManager.IMPORTANCE_HIGH));
        PendingIntent open = PendingIntent.getActivity(ctx, 0, new Intent(ctx, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(ctx, "rappels")
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Plonge & Cuisine CG10")
            .setContentText(text)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build();
        nm.notify((int) (System.currentTimeMillis() % 100000), n);
        Scheduler.rescheduleAll(ctx);
    }
}
