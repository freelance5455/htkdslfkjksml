package com.cg10.plonge;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;

public class Scheduler {
    static final String[] N = {"Sagesse Kavughe", "Danu Bienvenu", "Hubert Angambi", "Paluku Promesse", "Joel Kwanza", "Henri Musafiri", "Baraka Baltazar"};
    static final String[] C = {"Baraka Baltazar", "Paluku Promesse", "Joel Kwanza", "Danu Bienvenu", "Henri Musafiri", "Sagesse Kavughe", "Hubert Angambi"};
    static final LocalDate D0 = LocalDate.of(2026, 11, 8);

    static int dow(LocalDate d) { return d.getDayOfWeek().getValue() % 7; }

    /** Retourne "plonge", "cuisine", "plonge et de cuisine" ou null. */
    static String kind(String me, LocalDate d) {
        boolean p = N[dow(d)].equals(me);
        boolean c = dow(d) == 0 && C[(int) Math.floorMod(ChronoUnit.WEEKS.between(D0, d), 7L)].equals(me);
        return p && c ? "plonge et de cuisine" : p ? "plonge" : c ? "cuisine" : null;
    }

    private static PendingIntent pi(Context ctx, int code, String text, boolean create) {
        Intent i = new Intent(ctx, ReminderReceiver.class);
        i.putExtra("text", text);
        int flags = PendingIntent.FLAG_IMMUTABLE | (create ? PendingIntent.FLAG_UPDATE_CURRENT : PendingIntent.FLAG_NO_CREATE);
        return PendingIntent.getBroadcast(ctx, code, i, flags);
    }

    public static void rescheduleAll(Context ctx) {
        SharedPreferences sp = ctx.getSharedPreferences("cg10", 0);
        String me = sp.getString("me", "");
        boolean on = sp.getBoolean("on", false);
        int eve = sp.getInt("eve", 18), same = sp.getInt("same", 7);
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        ZoneId z = ZoneId.systemDefault();
        long now = System.currentTimeMillis();
        LocalDate today = LocalDate.now();
        for (int off = 0; off <= 60; off++) {
            LocalDate d = today.plusDays(off);
            int base = (int) d.toEpochDay() * 2;
            PendingIntent o1 = pi(ctx, base, "", false);
            if (o1 != null) { am.cancel(o1); o1.cancel(); }
            PendingIntent o2 = pi(ctx, base + 1, "", false);
            if (o2 != null) { am.cancel(o2); o2.cancel(); }
            if (!on || me.isEmpty()) continue;
            String k = kind(me, d);
            if (k == null) continue;
            long t1 = d.minusDays(1).atTime(eve, 0).atZone(z).toInstant().toEpochMilli();
            long t2 = d.atTime(same, 0).atZone(z).toInstant().toEpochMilli();
            if (t1 > now)
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t1, pi(ctx, base, "Demain, c'est ton tour de " + k + " 🍽️", true));
            if (t2 > now)
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t2, pi(ctx, base + 1, "Aujourd'hui, c'est ton tour de " + k + " 🍽️", true));
        }
    }
}
