package com.cg10.plonge;

import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;
import android.webkit.JavascriptInterface;

public class Bridge {
    private final Activity a;
    Bridge(Activity a) { this.a = a; }

    @JavascriptInterface
    public void setReminders(String me, int eve, int same, boolean on) {
        a.getSharedPreferences("cg10", 0).edit()
            .putString("me", me).putInt("eve", eve).putInt("same", same).putBoolean("on", on).apply();
        Scheduler.rescheduleAll(a);
        if (on && Build.VERSION.SDK_INT >= 33
            && a.checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            a.runOnUiThread(() -> a.requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1));
        }
    }
}
