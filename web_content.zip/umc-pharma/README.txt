UMC PHARMA – DJeBaiLi aPPs 2026
Dossier www/ = l'application (index.html). Package Android : dz.djebaili.umcpharma

CONVERSION EN APK (Capacitor) – nécessite Node.js + Android Studio :
1) npm install
2) npx cap add android
3) npx cap sync android
4) npx cap open android  -> Android Studio : Build > Build APK(s)

Sans PC : envoyer ce ZIP à un convertisseur "HTML/ZIP vers APK" (ex. WebIntoApp, AppsGeyser), index.html à la racine du dossier www.

Note : les graphiques utilisent Chart.js via internet (CDN). Pour un APK 100 % hors ligne, placez chart.umd.min.js dans www/ et remplacez l'URL du <script> dans index.html par "chart.umd.min.js".
