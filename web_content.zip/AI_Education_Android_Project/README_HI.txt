AI Education — CGBSE कक्षा 9 (Android Studio प्रोजेक्ट)

इस ZIP में Android ऐप का सोर्स प्रोजेक्ट है, APK फ़ाइल नहीं।
इस डेमो में:
- हिंदी / English स्विच
- नमूना ऑफलाइन नोट्स और MCQ टेस्ट
- टेस्ट स्कोर व पढ़ाई के लक्ष्य फोन में सेव
- AI टीचर का UI, लेकिन लाइव AI API अभी कनेक्ट नहीं है

APK बनाने के लिए:
1. कंप्यूटर पर Android Studio इंस्टॉल करें।
2. Android Studio में इस ZIP को extract करके मौजूद AI_Education_Android_Project फ़ोल्डर खोलें।
3. Gradle sync पूरा होने दें और Android SDK Platform 35 उपलब्ध रखें।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
5. APK आमतौर पर app/build/outputs/apk/debug/app-debug.apk में मिलेगा।

ध्यान दें:
- इस वातावरण में Android build tools उपलब्ध न होने के कारण APK स्वयं compile नहीं किया गया।
- लाइव AI के लिए backend/API बनाना होगा। API secret को APK या HTML में सीधे न रखें।
- नमूना सामग्री सीमित है; यह आधिकारिक CGBSE पाठ्यक्रम/सभी अध्यायों के पूरे नोट्स नहीं हैं।
