# AI Education — CGBSE Class 9

Android Studio starter project for a bilingual (Hindi/English) study app.

Includes offline sample notes and quizzes, local progress/goals, and a placeholder AI tutor UI. Live AI is not connected; add a secure backend before production use.

See `README_HI.txt` for build instructions. This is the project source, not a compiled APK.
