# NRB by nabin — Android APK project

This project packages the supplied chapter-wise NRB HTML notebook as an offline-first Android application.

## Included content
- Original main HTML application, with app branding changed to **NRB by nabin**
- 16 chapter HTML files and the original chapter index
- Original JavaScript features such as chapter navigation, search, bookmarks, and local reading data
- Google Fonts network references removed; system font fallbacks keep the reader usable offline

## Build the APK (Windows / macOS / Linux)

### Requirements
- Node.js 20 or newer
- Android Studio (current stable version)
- Android SDK installed through Android Studio
- Java version required by your installed Android Gradle Plugin (Android Studio's bundled JDK is recommended)

### Steps
1. Extract this folder.
2. Open a terminal in this folder.
3. Install dependencies:

   ```bash
   npm install
   ```

4. Generate the native Android project:

   ```bash
   npx cap add android
   ```

   If an `android` folder already exists, skip this command.

5. Copy the bundled web app into Android:

   ```bash
   npx cap sync android
   ```

6. Open the project in Android Studio:

   ```bash
   npx cap open android
   ```

7. In Android Studio, wait for Gradle sync, then choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

8. The debug APK will be created at:

   `android/app/build/outputs/apk/debug/app-debug.apk`

## Release APK
For a shareable release build, use **Build → Generate Signed Bundle / APK → APK** in Android Studio, create or select a signing key, and follow the wizard. Keep the signing key private and backed up.

## Offline behavior
All chapter HTML and the chapter index are bundled inside the app. The reader's chapter fetches use local packaged files, while bookmarks and progress use local browser storage. No server is required to read the book. Device-level Android testing is still recommended before distribution.

## Notes
- The supplied archive contained `index.html`, `chapters/index.json`, and 16 chapter HTML files. No separate image, CSS, or JavaScript asset folders were present.
- The source HTML has been retained, apart from the app title/header branding and removal of external Google Fonts loading so it does not depend on internet access for typography.
