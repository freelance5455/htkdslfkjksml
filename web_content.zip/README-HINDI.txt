YOUSUF4TIX ANDROID APP PROJECT

Yeh Android Studio project hai, APK file nahi. Isme website phone app ke andar bundled hai.

APK banane ka tareeqa:
1. Computer par Android Studio install karo.
2. Is ZIP ko extract karo.
3. Android Studio mein extracted Yousuf4tixAndroid folder open karo.
4. Gradle sync complete hone do.
5. Build > Build Bundle(s) / APK(s) > Build APK(s) chuno.
6. APK aam taur par app/build/outputs/apk/debug/app-debug.apk par milega.
7. APK ko apne Android phone mein transfer karke install karo. Phone unknown-source install permission maang sakta hai.

Note: Is environment mein Android SDK/Gradle build tools available nahi the, isliye yahan directly installable APK compile nahi ho saka. Project ko Android Studio se build karna hoga.
