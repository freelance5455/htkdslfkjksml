# RAGE Engine 0.8.0 — Atmosfera, sombras e reflexos

## Nuvens e céu

A viewport usa um domo de céu com shader próprio. A densidade das nuvens é calculada em tempo real por ruído 3D/fBm e integração volumétrica por ray marching. O vetor de vento desloca diferentes escalas de ruído em velocidades distintas, criando deriva e deformação contínuas em vez de mover uma imagem plana. O custo de amostragem varia por perfil: desempenho, equilibrado e alta qualidade.

As referências visuais usadas durante o desenvolvimento incluem uma fotografia de cúmulos de domínio público: <https://www.publicdomainpictures.net/en/view-image.php?image=542938&picture=cumulus-clouds-blue-sky>. A renderização da engine, porém, é procedural; a fotografia não é usada como textura de céu.

## Clima

Os presets globais alteram cobertura/densidade de nuvens, cor atmosférica, fog e intensidade da iluminação: céu limpo, parcialmente nublado, nublado, tempestade e neblina. Os parâmetros de cobertura, densidade e vento podem ser refinados pelo usuário e são persistidos no `.rageproj`.

Nesta versão o clima é global por cena. Ainda não há volumes meteorológicos independentes por bairro, precipitação, relâmpagos, acúmulo de água ou física de embarcações afetada pelo clima.

## Sombras

- O sol usa `DirectionalLight` com shadow map e acompanha a hora do dia.
- Malhas primitivas e malhas importadas de GLB/GLTF são configuradas para projetar e receber sombras.
- Luzes locais do tipo `PointLight` e `SpotLight` recebem shadow maps dinâmicos; os spots também oferecem abertura configurável. Como uma point light exige seis faces de mapa de sombra por atualização, o orçamento é limitado a nenhuma luz local no perfil desempenho, uma no equilibrado e duas no alto.
- As nuvens aplicam uma sombra procedimental animada aproximada nos materiais PBR. Ela acompanha o vento e a direção da luz, mas não é uma projeção física exata do volume de nuvem.

Cabelos e folhagens só projetam silhuetas detalhadas quando a malha importada tem geometria adequada e seu material/alpha test está preparado para sombras. Não existe ainda um sistema dedicado de strand-hair ou foliage.

## Reflexos e materiais

A engine gera um mapa equiretangular procedural do céu/ambiente e o fornece como iluminação de ambiente para materiais Standard/Physical. Isso habilita reflexos IBL em superfícies metálicas e brilhantes, inclusive em áreas com pouca iluminação direta, sujeitos aos parâmetros de rugosidade e metalicidade.

Isso não é ray tracing/path tracing: o mapa representa o ambiente global e não atualiza a imagem exata de cada carro, personagem, letreiro neon ou objeto ao redor dentro de cada superfície. Reflexos locais dinâmicos, SSR/SSGI e ray tracing continuam como etapas futuras. Uma superfície emissiva (por exemplo, um letreiro neon) ainda precisa de uma ou mais luzes pontuais/spots próximas para iluminar objetos ao redor; emissive sozinho não é uma fonte de luz que ilumina a cena.

## Roadmap gráfico sugerido

1. Volumes de clima por região com transições de fronteira, chuva, trovões, vento e partículas.
2. Sistema de água com ondas, espuma, transparência e superfícies molhadas/reflexos locais.
3. Renderizador avançado baseado em WebGPU/TSL, mantendo um caminho WebGL para dispositivos que não suportem WebGPU.
4. Física de corpos rígidos, tecidos/cabelos, vegetação reativa e deformação de veículos por dano.
5. Otimização de sombras em cascata, foliage/LOD, streaming de mundo e perfis específicos para aparelhos móveis.

O objetivo é aproximar a engine de uma simulação visual coerente com a natureza de forma progressiva, sem declarar como já existente o que ainda depende de sistemas futuros.
