# RAGE Project Format — v1

A `.rageproj` file is a UTF-8 JSON document. It is portable between the PC and Mobile editions and contains the project metadata, all scenes, all imported assets (as data URLs), and the selected start scene.

## Top-level structure

- `format`: `rage-project`
- `version`: `1`
- `id`, `name`, `createdAt`, `updatedAt`
- `activeSceneId`: currently edited scene
- `scenes`: an array of `rage-scene` v1 documents
- `assets`: embedded model/texture/file records; optional `folder` stores the virtual asset-browser location
- `assetFolders`: optional list of project asset folders
- `renderSettings`: optional viewport quality, environment, exposure, shadows, weather, procedural clouds, wind, and time-of-day settings
- `exportSettings: target and start scene reference

## Scene and object data

The scene format remains `rage-scene` version `1` to preserve compatibility with the existing v0.3.1 `.ragescene` files. Objects retain the existing transform/color/visibility fields. A standalone `.ragescene` export may include an optional top-level `assets` array containing only the model/texture assets referenced by that scene, making it portable on its own. New optional object fields are:

- `parentId`: parent group reference; only objects of type `group` can be parents
- `assetId`: reference to an imported model asset for objects of type `model`
- `roughness`, `metalness`: material overrides in the range `0..1`
- `textureAssetId`: reference to an imported image texture
- `materialColor`: optional color override for imported model materials

Supported object types: `cube`, `sphere`, `plane`, `terrain`, `cylinder`, `light`, `group`, and `model`. Light objects optionally store `lightType` (`point` or `spot`), `lightIntensity`, `lightDistance`, and `lightAngle` in degrees.

## Assets

Each asset contains `id`, `name`, `kind`, `mimeType`, `dataUrl`, and `size`. GLB files are embedded as binary data URLs. For glTF JSON files, external `.bin` and image dependencies must be selected with the `.gltf`; the importer rewrites those dependency URIs to embedded data URLs so the project remains self-contained.

The asset browser supports virtual folders, search, and moving assets between folders. Folder names are stored in the project document; the files themselves remain embedded in the `.rageproj`. The asset manager currently supports model files (`.glb`, `.gltf`) and image textures (`.png`, `.jpg`, `.jpeg`, `.webp`, `.avif`). Imported model materials are preserved until a material override is applied in the Inspector.

## Local persistence and portability

The editor autosaves the active project in IndexedDB (with a localStorage fallback). The `.rageproj` export is the portable backup intended for copying between devices. Autosave is local to the browser/WebView profile and is not cloud synchronization.

## Build preparation

`exportSettings.startSceneId` selects the game entry scene. The optional `.ragebuild.json` manifest records the scene and asset paths planned for a future export pipeline (`scenes/`, `assets/`, `runtime/`, and `build/`). It is preparation metadata only: a packaged playable game/runtime exporter is not part of v0.5.0.


## Rendering foundation (v0.8.0)

`renderSettings` contains `quality` (`performance`, `balanced`, `high`), `environment` (`studio`, `daylight`, `sunset`, `night`), `exposure`, `shadows`, `timeOfDay`, `clouds`, `cloudCoverage`, `cloudDensity`, `windX`, `windZ`, and `weather` (`clear`, `partly-cloudy`, `overcast`, `storm`, `fog`). These settings configure the editor viewport and are optional for backwards compatibility. They are an evolving real-time rendering foundation, not a final game renderer and not a claim of parity with GTA VI.


## Campos opcionais v0.7.0

Objetos `terrain` podem armazenar `terrainAmplitude`, `terrainFrequency` e `terrainSeed`, usados para reconstruir o relevo procedural. Objetos também podem referenciar `normalMapAssetId`, `roughnessMapAssetId`, `metalnessMapAssetId` e `aoMapAssetId`. As referências apontam para assets de textura existentes no array `assets` do projeto. Esses campos são opcionais; projetos antigos continuam válidos.


## Campos opcionais v0.8.0

Os objetos `light` podem usar `lightType` (`point` ou `spot`), `lightIntensity`, `lightDistance` e `lightAngle` (em graus). As configurações atmosféricas ficam em `renderSettings`: `clouds`, `cloudCoverage`, `cloudDensity`, `windX`, `windZ`, `weather` e `timeOfDay`. Todos esses campos têm defaults para preservar a abertura de projetos antigos v1.
