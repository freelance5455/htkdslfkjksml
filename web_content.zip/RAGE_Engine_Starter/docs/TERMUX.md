# Guia prático do Termux para o RAGE Engine

Este guia foca no uso do Termux para desenvolver e compilar a edição Android do projeto.

## 1. O que é o Termux

Termux é um ambiente de terminal para Android, não um Ubuntu instalado por completo. O comando `pkg` é a interface recomendada para instalar pacotes compilados para o Termux; o ambiente é instalado dentro da área privada do aplicativo. Ele não exige root para os fluxos descritos aqui.

O ambiente usa bibliotecas do Android (Bionic) e fica no espaço privado do aplicativo. Não é uma distribuição Linux completa, nem uma máquina virtual, nem um emulador de Android.

O usuário normal não tem root. Isso é suficiente para Node.js, npm, Git, Python, Java, Gradle e muitas ferramentas de compilação que tenham versões compatíveis com Android/ARM. Não conte com `sudo`, `systemd`, montagem de partições, acesso irrestrito a `/system` ou execução de qualquer binário Linux x86_64.

## 2. Instalação e origem do Termux

As versões mantidas são distribuídas pelo F-Droid e pelo GitHub oficial do projeto. A versão experimental da Play Store pode ter diferenças e recursos ausentes em relação às versões estáveis. Os APKs de origens diferentes são assinados com chaves diferentes; Termux e seus plugins devem vir da mesma origem. Não desinstale/reinstale de outra origem sem fazer backup do ambiente, pois os arquivos privados podem ser perdidos.

Para inspecionar a instalação atual:

```bash
termux-info
```

O suporte a pacotes atual exige Android 7 ou superior. Confirme a versão do aplicativo e a origem antes de tentar consertar erros persistentes do `pkg`.

## 3. Comandos essenciais

| Comando | Uso |
|---|---|
| `pkg update` | Atualiza o índice dos repositórios. |
| `pkg upgrade` | Atualiza os pacotes já instalados. |
| `pkg install nome` | Instala um pacote. |
| `pkg uninstall nome` | Remove um pacote. |
| `pkg search termo` | Procura pacotes disponíveis. |
| `pkg list-installed` | Lista o que está instalado. |
| `termux-info` | Mostra dados do Termux, Android e repositórios. |
| `termux-change-repo` | Troca o espelho de pacotes quando o atual falha. |
| `termux-setup-storage` | Pede permissão e cria atalhos em `~/storage/`. |
| `termux-open arquivo` | Abre um arquivo com um aplicativo Android compatível. |
| `df -h` | Mostra espaço em disco. |
| `free -h` | Mostra memória disponível (se o comando estiver instalado). |
| `uname -m` | Mostra a arquitetura, por exemplo `aarch64`. |
| `which node` | Mostra de onde um executável será chamado. |

`pkg` é a interface recomendada do Termux para o gerenciador de pacotes. Ele simplifica o uso do APT dentro do ambiente Termux; não use comandos de Ubuntu/Debian que dependam de `sudo` como se o Termux fosse um servidor Linux convencional.

## 4. Armazenamento: local certo para o projeto

O diretório privado (`$HOME`, normalmente `/data/data/com.termux/files/home`) é o local recomendado para código, `node_modules`, Gradle e compilação. Execute `termux-setup-storage` para criar atalhos como `~/storage/downloads`.

Use Downloads apenas para entrada/saída de arquivos. Não é recomendado extrair o código e compilar diretamente em `/sdcard` ou `~/storage/shared`: o armazenamento compartilhado do Android tem restrições de permissões, links simbólicos, atributos executáveis e desempenho. Isso costuma causar `Permission denied`, problemas de links e builds quebrados.

Comandos de arquivos que você vai usar bastante:

```bash
pwd                         # mostra a pasta atual
ls -la                      # lista arquivos e pastas
cd ~/projects               # entra na pasta de projetos
mkdir -p ~/projects         # cria pasta, sem erro se já existir
cp origem destino           # copia arquivo
mv origem destino           # move/renomeia arquivo
chmod +x scripts/*.sh       # permite executar os scripts
termux-setup-storage        # cria acesso a Downloads/Documentos compartilhados
```

### Gerenciador de pacotes

```bash
pkg update                  # atualiza índices de pacotes
pkg upgrade -y              # atualiza os pacotes instalados
pkg search nodejs           # pesquisa um pacote
pkg show android-sdk        # mostra detalhes de um pacote
pkg install nome            # instala
pkg reinstall nome          # reinstala
pkg uninstall nome          # remove
termux-change-repo          # seleciona outro espelho quando o atual falhar
```

Não adicione repositórios do Ubuntu/Debian diretamente ao `$PREFIX`: pacotes de outra distribuição podem ser incompatíveis com o ambiente Android/Bionic do Termux.

## 5. Node.js e npm

O RAGE Engine usa React, Vite, TypeScript e Capacitor. Para Capacitor 8, a documentação pede Node.js 22 ou superior. No Termux, instale a versão LTS disponível e confirme:

```bash
pkg install nodejs-lts npm
node --version
npm --version
```

Dentro da pasta `mobile/`, `npm install` baixa as dependências; `npm run build` executa a checagem TypeScript e gera o site estático em `dist/`. O projeto precisa ser servido por Vite no desenvolvimento ou embutido no APK pelo Capacitor. Não abra o `index.html` de `src` ou o `index.html` do projeto por `file://`.

## 6. Java, Android SDK e Gradle

Para gerar o APK mobile o projeto usa Capacitor 8. A combinação que o script procura é:

- Node.js 22+;
- OpenJDK 21;
- Android SDK Platform 36;
- Android Build Tools 36.1.0;
- `aapt2`, `d8`, `zipalign` e `apksigner` compatíveis com Termux/arquitetura do aparelho;
- Gradle Wrapper do projeto Capacitor (não é necessário instalar Gradle globalmente).

Instalação inicial preparada pelo script:

```bash
pkg update
pkg install nodejs-lts npm openjdk-21 android-sdk aapt2 apksigner zipalign d8 unzip
```

Confira os caminhos e ferramentas:

```bash
echo "$PREFIX"
echo "$ANDROID_HOME"
java -version
node --version
which aapt2 d8 zipalign apksigner
ls "$PREFIX/opt/android-sdk/platforms"
ls "$PREFIX/opt/android-sdk/build-tools"
```

O diretório SDK padrão usado pelo script é `$PREFIX/opt/android-sdk`. O pacote `android-sdk` do Termux fornece uma base de ferramentas Android e o SDK Manager; o script procura o `sdkmanager` tanto no `PATH` quanto dentro do SDK e tenta instalar a Platform 36 quando o `android.jar` está ausente. `aapt2`, `d8`, `zipalign` e `apksigner` devem vir dos pacotes nativos do Termux, não de binários Linux x86_64 baixados aleatoriamente.

### Por que o AAPT2 precisa de ajuste?

O Android Gradle Plugin normalmente baixa seu `aapt2` do Maven do Google. O executável fornecido nesse artefato é normalmente preparado para Linux/glibc x86_64, enquanto o Termux roda no ambiente Android/Bionic e, em celulares comuns, ARM64. Por isso ele pode falhar com mensagens como `cannot execute binary file`, erro de linker ou `AAPT2 Daemon startup failed`.

O Termux mantém ferramentas Android nativas/compatíveis para essa arquitetura. O script configura `android.aapt2FromMavenOverride` para apontar para o `aapt2` instalado pelo Termux (`command -v aapt2`). Não remova essa configuração ao compilar no celular. O mesmo cuidado vale para utilitários do SDK que dependam da arquitetura: priorize os comandos disponibilizados pelo Termux. A documentação de uma ferramenta comunitária para builds nativos no Termux lista `openjdk-21`, `android-sdk`, `aapt2`, `d8`, `zipalign` e `apksigner` como base de trabalho, mas isso não constitui garantia oficial do Capacitor nem cobre todos os modelos de aparelho.

## 7. Como compilar

No diretório do projeto:

```bash
bash scripts/setup-termux.sh
termux-setup-storage
bash scripts/build-apk.sh
```

O script faz `npm install`, compila o bundle web, cria a plataforma Android do Capacitor na primeira execução, sincroniza os assets e plugins, configura Gradle para memória limitada e executa `:app:assembleDebug` sem daemon persistente.

O APK final é `output/RAGE-Engine-debug.apk` e, quando o armazenamento estiver autorizado, também `~/storage/downloads/RAGE-Engine-debug.apk`.

### Observação sobre o caminho Termux

A documentação oficial do Capacitor indica Android Studio e Android SDK como ambiente Android padrão. Este projeto tenta uma rota alternativa comunitária, usando ferramentas Android empacotadas para Termux/ARM. Isso é útil quando você só tem o celular, mas pode quebrar com mudanças em repositórios, Android Gradle Plugin, Gradle ou SDK. Se falhar por incompatibilidade de toolchain, a rota mais previsível é fazer o build Android num computador com Android Studio e transferir o APK ao celular.

## 8. Por que não usar PRoot/Ubuntu aqui?

`proot-distro` permite executar um userland Ubuntu/Debian sem root, mas usa tradução de caminhos e `ptrace`. Não cria root real, não fornece namespaces/cgroups reais, não habilita módulos do kernel e costuma deixar compilações intensivas em I/O mais lentas. Para este projeto, os binários Termux nativos e Java/Gradle rodam diretamente no ambiente principal, então adicionar PRoot é uma camada extra sem benefício para o fluxo de APK descrito.

Use PRoot apenas quando uma ferramenta realmente exigir bibliotecas ou scripts de uma distribuição GNU/Linux que não estejam disponíveis no Termux, e não como tentativa automática de corrigir binários x86_64 em um aparelho ARM64.

## 9. Comandos de diagnóstico úteis

```bash
termux-info                  # origem, versão e detalhes do ambiente
uname -m                     # arquitetura (a maioria dos telefones atuais é aarch64)
getprop ro.build.version.release  # versão Android
free -h                      # memória disponível
df -h "$HOME"                # espaço disponível na partição do projeto
which node npm java javac aapt2 d8 zipalign apksigner
file "$(which aapt2)"        # identifica o wrapper/binário instalado
```

Para registrar uma tentativa de build e poder enviar o erro completo:

```bash
bash scripts/build-apk.sh 2>&1 | tee build.log
```

Leia principalmente `FAILURE:`, `What went wrong:` e a primeira mensagem `Caused by:`. A última linha frequentemente só informa que o Gradle falhou, não a causa.

## 10. Recursos e limitações

**O que o Termux consegue fazer:** executar shells Bash/Zsh, instalar pacotes, rodar Node/npm, Git, Python, OpenJDK, Gradle, compilar alguns projetos nativos, hospedar servidores locais, manipular arquivos no espaço permitido e integrar ações Android por comandos/intent ou plugins opcionais.

**O que não deve ser presumido:** root; ambiente glibc completo; acesso irrestrito à memória/arquivos de outros apps; emulador Android completo; Android Studio de desktop; execução de serviços persistentes garantidos; execução de binários de qualquer arquitetura; liberdade para gravar/compilar dentro de qualquer pasta compartilhada.

Em Android 12 ou superior, o sistema pode encerrar processos em segundo plano ou processos filhos em excesso. Mantenha o Termux aberto durante o build, feche aplicativos pesados, evite muitos workers e deixe o Gradle sem daemon como o script configura. Desative a otimização de bateria do Termux nas configurações do Android se o aparelho o encerrar durante tarefas longas.

## 11. Diagnóstico para enviar em caso de erro

Execute:

```bash
bash scripts/diagnostico-termux.sh
```

Copie a saída completa. Para erros do Gradle, envie também as primeiras linhas que contêm `FAILURE`, `What went wrong` e a primeira causa `Caused by`, não apenas a última linha do erro.
