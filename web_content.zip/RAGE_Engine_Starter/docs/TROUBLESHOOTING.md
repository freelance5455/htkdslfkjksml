# Solução de problemas — RAGE Engine + Termux

## A página fica branca no Chrome ou no leitor HTML

Não abra o `index.html` do projeto diretamente como `file:///...`. O projeto original é React + TypeScript + Vite; o navegador não compila `.tsx` nem resolve pacotes npm nesse modo. Rode `bash scripts/run-mobile.sh` e abra `http://127.0.0.1:5173`. Para APK, rode `bash scripts/build-apk.sh`.

Se o APK abrir mas o viewport 3D não, atualize Android System WebView e Chrome pela Play Store/loja do aparelho. O RAGE Engine agora mostra uma mensagem de erro dentro do viewport quando o WebGL falha; confira também se o dispositivo oferece aceleração gráfica/WebGL.

## `pkg update` diz que o repositório está fora do ar

```bash
termux-change-repo
pkg update
pkg upgrade -y
```

Escolha um espelho oficial disponível para o repositório `main`. Confirme que a internet funciona e rode `termux-info`. Não apague manualmente `$PREFIX/etc/apt` sem saber qual repositório está configurado.

## `Unable to locate package` para `android-sdk`, `aapt2` ou `openjdk-21`

Atualize os índices e confira a origem/versão do Termux:

```bash
pkg update
termux-info
pkg search android-sdk
pkg search aapt2
pkg search openjdk
pkg search d8
```

O Termux antigo ou uma versão de origem não suportada pode não ter o mesmo conjunto de pacotes. Não misture APKs de Termux assinados por fontes diferentes.

## `Permission denied`, `Operation not permitted` ou `npm EACCES`

Mova o projeto para dentro de `$HOME`, por exemplo `~/projects/RAGE_Engine_Starter`. Evite executar e instalar `node_modules` dentro de `/sdcard`, `Download` ou `~/storage/shared`.

Para scripts do projeto:

```bash
chmod +x scripts/*.sh
bash scripts/build-apk.sh
```

## `AAPT2 Daemon startup failed`, `Exec format error` ou `cannot execute binary file`

O Gradle está tentando executar o binário AAPT2 errado para a arquitetura do Android. Confirme:

```bash
uname -m
which aapt2
file "$(which aapt2)"
aapt2 version
```

Reinstale o AAPT2 Termux:

```bash
pkg reinstall aapt2
```

O script grava `android.aapt2FromMavenOverride` com o caminho encontrado pelo Termux. Não substitua essa configuração pelo `aapt2` x86_64 que o Gradle baixa do Maven. Confirme também que `d8`, `zipalign` e `apksigner` existem no Termux (`which d8 zipalign apksigner`); reinstale os pacotes correspondentes com `pkg reinstall d8 zipalign apksigner` se necessário.

## `SDK location not found` ou `Failed to find Build Tools revision`

```bash
echo "$ANDROID_HOME"
ls "$PREFIX/opt/android-sdk/platforms"
ls "$PREFIX/opt/android-sdk/build-tools"
```

Rode novamente `bash scripts/setup-termux.sh` e depois o build. O script também tenta chamar `sdkmanager` para instalar `platforms;android-36` e `build-tools;36.1.0`. Se não encontrar o SDK Manager, confirme `pkg install android-sdk` e envie o diagnóstico.

## `Unsupported class file major version`, `invalid source release` ou erro da JVM

Capacitor 8 usa a toolchain Java 21. Confira:

```bash
java -version
which java
which javac
```

Instale/seleciona OpenJDK 21:

```bash
pkg install openjdk-21
```

Não force Gradle antigo nem troque apenas o Java sem respeitar a versão do Android Gradle Plugin e do Wrapper gerado pelo Capacitor.

## Gradle fecha sozinho ou aparece `[Process completed (signal 9)]`

Pode ser encerramento de processo pelo Android 12+ ou pressão de memória. Feche apps pesados, mantenha o Termux em primeiro plano, conecte o carregador e evite executar vários builds ao mesmo tempo. O script já usa `--no-daemon`, heap de 1,5 GB e dois workers. Em aparelhos com pouca RAM, reduza no `android/gradle.properties` para:

```properties
org.gradle.jvmargs=-Xmx1024m -XX:MaxMetaspaceSize=384m -Dfile.encoding=UTF-8
org.gradle.daemon=false
org.gradle.parallel=false
org.gradle.workers.max=1
```

Confira também a otimização de bateria do Termux nas configurações Android.

## `Could not resolve`, `Could not GET` ou timeout Maven/npm

É falha de rede, DNS, espelho ou indisponibilidade temporária de repositório. Confirme Wi-Fi/dados, repita a tentativa e mantenha `google()` e `mavenCentral()` habilitados. A primeira build precisa baixar muitos arquivos e não funciona offline até que as dependências estejam em cache.

## O APK não instala (`App not installed`, incompatibilidade de assinatura)

- Ative a permissão Android para instalar apps desta origem (Termux ou Arquivos).
- Se já há um app `com.rageengine.editor` instalado e assinado por outra chave, o Android rejeita a atualização. Desinstalar o antigo remove os dados privados do app; exporte/guarde suas cenas `.ragescene` antes.
- Para atualizações futuras, use sempre a mesma chave de assinatura. O APK produzido aqui é debug e é indicado para testes locais.

## O botão de exportar não salva em Downloads

Na edição APK, a cena é gravada na pasta Documents privada do app e o Android abre a folha de compartilhamento. Escolha um destino como Arquivos/Drive para guardar uma cópia. O armazenamento automático também mantém a cena no WebView local. Na edição de navegador, o download é iniciado pelo próprio navegador.

## Manipular objetos diretamente na viewport (v0.3.0)

1. Toque em um objeto para selecioná-lo.
2. Na barra flutuante da viewport mobile, escolha **Mover**, **Girar** ou **Escalar**. No PC, use a barra superior.
3. Arraste uma das alças coloridas do gizmo. Arrastar fora das alças continua orbitando a câmera; pinça/scroll controla o zoom.
4. Os valores de posição, rotação e escala são sincronizados com o Inspector e o salvamento automático.
5. Escolha **Selecionar** para ocultar o gizmo e voltar ao modo de seleção.

Se o gesto mover a câmera em vez do objeto, toque no modo desejado e arraste exatamente uma das alças do gizmo. Objetos precisam estar visíveis e selecionados.
