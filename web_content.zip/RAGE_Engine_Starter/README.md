# RAGE Engine — 0.8.0 (PC / Android / Termux)

Projeto de editor de cenas 3D com duas aplicações independentes: `pc/` (layout desktop) e `mobile/` (layout touch-first). A versão mobile agora também tem configuração Capacitor 8 para gerar um APK Android.

## Estado real do projeto (v0.8.0)

**Já implementado nesta base:**
- Sistema de atmosfera dinâmica: nuvens tridimensionais procedurais por ray marching, distorção contínua, deslocamento por vento e presets globais de clima.
- Sombras atmosféricas aproximadas animadas nos materiais, sombras do sol e sombras de luzes pontuais com orçamento limitado por qualidade.
- Iluminação de ambiente procedural (IBL) para reflexos PBR coerentes com o horário e o clima.
- World Builder inicial com terreno procedural subdividido e parâmetros editáveis de altura, frequência e seed.
- Fluxo PBR conectado: Base Color, Normal, Roughness, Metallic e Ambient Occlusion usando texturas importadas; mapas de dados são tratados em espaço linear.
- UV2 é criado para geometria com UV quando Ambient Occlusion é usado; materiais originais de modelos importados são preservados quando não há override.
- Aplicações independentes para PC e Mobile, com organização visual adequada a cada formato.
- Viewport 3D Three.js/WebGL com seleção e transformação por gizmos (Mover, Girar e Escalar).
- Criação de cubo, esfera, cilindro, plano, luzes pontuais/spots e grupos.
- Hierarquia com grupos e objetos filhos, além de visibilidade e Inspector.
- Sistema de projetos: criar, abrir projetos locais, importar e exportar arquivos `.rageproj`.
- Salvamento automático do projeto em IndexedDB, com fallback localStorage.
- Várias cenas dentro de um projeto: criar, alternar, renomear e excluir (mantendo pelo menos uma cena).
- Compatibilidade de importação com cenas `.ragescene` v1 das versões anteriores.
- Importação de modelos `.glb` e `.gltf`; dependências externas do glTF devem ser selecionadas junto com o arquivo principal.
- Gerenciamento de assets de imagem/textura e overrides de cor, rugosidade e metalicidade no Inspector.
- Seleção de textura importada para objetos e modelos.
- Configuração da cena inicial e exportação de manifesto `.ragebuild.json` para preparar uma futura pipeline de build.
- Na edição Android nativa, exportação de arquivos pelo menu de compartilhamento do sistema.

**Limites que continuam explícitos:** o botão Play ainda é uma pré-visualização demonstrativa. O `.ragebuild.json` é apenas um manifesto de preparação; a engine ainda não gera um jogo executável. Ainda faltam runtime, física, animação, scripting, áudio e empacotamento final de jogos. A persistência local não é sincronização em nuvem; use o arquivo `.rageproj` para backup e transferência entre dispositivos.

O formato e os campos do projeto estão descritos em [`docs/PROJECT_FORMAT.md`](docs/PROJECT_FORMAT.md). Os detalhes, limites e próximos passos gráficos estão em [`docs/GRAPHICS_V0_8.md`](docs/GRAPHICS_V0_8.md).

## Por que abrir `index.html` diretamente dá tela branca?

Este é um projeto React + TypeScript + Vite. O `index.html` aponta para um módulo de entrada (`src/main.tsx`) e o código importa bibliotecas como React, Three.js e Lucide. O navegador não transpila TypeScript/JSX nem resolve esses pacotes quando o arquivo é aberto como `file:///...`. O Vite precisa servir o projeto durante o desenvolvimento ou gerar a pasta `dist/` para produção. No APK, o Capacitor inclui os arquivos gerados dentro do aplicativo Android.

## Requisitos do computador

Node.js 22 ou superior, npm e um navegador moderno com WebGL2. Para Android, use os scripts do Termux na seção seguinte.

## Android: gerar APK no próprio Termux

**Aviso importante:** a documentação oficial do Capacitor descreve Android Studio + Android SDK como ambiente padrão. Este ZIP não instala Android Studio e não substitui o caminho oficial. Compilar dentro do Termux é uma rota comunitária, sem suporte oficial do Capacitor, que depende de pacotes nativos ARM do Termux (principalmente AAPT2, D8 e ferramentas de alinhamento/assinatura). Foi preparado para Android ARM64 sem root e sem PRoot, mas a compatibilidade depende da versão dos pacotes disponíveis no espelho do Termux e da memória livre do aparelho. O APK produzido pelo script é um **debug APK assinado para testes e instalação local**, não uma versão de publicação na Play Store.

1. Instale o Termux por uma fonte mantida pelo projeto (F-Droid ou GitHub oficial). Não misture Termux e plugins instalados de origens diferentes, porque as assinaturas dos APKs diferem.
2. Copie este ZIP para Downloads. No Termux, dê permissão de armazenamento:

   ```bash
   termux-setup-storage
   ```

3. Extraia o ZIP para o diretório privado do Termux (não compile diretamente em `/sdcard`):

   ```bash
   cd ~
   mkdir -p projects
   unzip ~/storage/downloads/RAGE_Engine_Termux_Android_v0.8.0.zip -d ~/projects
   cd ~/projects/RAGE_Engine_Starter
   ```

4. Instale as ferramentas e configure o Gradle:

   ```bash
   bash scripts/setup-termux.sh
   ```

5. Gere o APK:

   ```bash
   bash scripts/build-apk.sh
   ```

6. O APK será copiado para `~/storage/downloads/RAGE-Engine-debug.apk` (se o acesso ao armazenamento estiver habilitado) e também para `output/RAGE-Engine-debug.apk`. Toque no APK pelo app Arquivos/Downloads e autorize a instalação para esta origem.

A primeira compilação precisa baixar os pacotes npm, Gradle, plugin Android e dependências Maven. Ela exige internet e vários GB livres. Mantenha o Termux aberto até terminar. Recomendação prática: tenha pelo menos 5 GB livres, feche jogos e aplicativos pesados, deixe o Termux sem otimização de bateria e mantenha-o em primeiro plano. Se o Android encerrar o processo, repita o comando após liberar memória.

### Testar sem APK

Para testar a edição móvel no Chrome do mesmo celular:

```bash
bash scripts/run-mobile.sh
```

Abra `http://127.0.0.1:5173` no Chrome. Para a versão desktop:

```bash
bash scripts/run-pc.sh
```

O servidor Vite fica em primeiro plano. Para encerrar, volte ao Termux e pressione `Ctrl+C`.

## Usar o gerenciador de projetos

1. Abra **Projeto → Novo projeto** para iniciar um projeto separado.
2. Use **Cenas → +** para criar cenas; toque uma vez para abrir e clique duplo no PC para renomear.
3. Use **Importar projeto / cena** para abrir `.rageproj` ou adicionar uma cena `.ragescene` ao projeto atual.
4. Importe `.glb` diretamente. Para `.gltf`, selecione o `.gltf` junto com os `.bin` e imagens referenciados pelo arquivo.
5. Selecione um objeto para editar cor, rugosidade, metalicidade e textura. Crie um **Grupo** para organizar objetos filhos na hierarquia.
6. Escolha a **Cena inicial do jogo** e exporte `.ragebuild.json` para obter o manifesto da futura pipeline de build.

O arquivo `.rageproj` inclui os dados dos modelos e texturas importados, por isso pode ficar grande. Guarde uma cópia externa dos projetos importantes.

## PC

```bash
cd pc
npm install
npm run dev
```

Build de produção:

```bash
npm run build
```

A pasta gerada é `pc/dist/`.

## Estrutura de pastas

```text
RAGE_Engine_Starter/
├── pc/                    # Edição desktop independente (React + Vite + Three.js)
├── mobile/                # Edição móvel independente
│   ├── src/                # Interface, viewport e modelo de cena
│   ├── capacitor.config.ts # Configuração Capacitor / Android
│   └── android/            # Gerada por `npx cap add android` na primeira compilação
├── scripts/
│   ├── setup-termux.sh     # Instala dependências no Termux
│   ├── build-apk.sh        # Build e verificação do APK debug
│   ├── run-mobile.sh       # Servidor de desenvolvimento móvel
│   ├── run-pc.sh           # Servidor de desenvolvimento PC
│   └── diagnostico-termux.sh
├── docs/
│   ├── TERMUX.md
│   └── TROUBLESHOOTING.md
└── output/                 # APK gerado
```

## Compatibilidade e dados

- O projeto usa `format: "rage-project"`, `version: 1` no arquivo `.rageproj`.
- As cenas continuam usando `format: "rage-scene"`, `version: 1`, incluindo os arquivos antigos da v0.3.1.
- PC e Mobile compartilham o mesmo formato de projeto e referências de assets; arquivos `.rageproj` podem ser transferidos entre as edições.
- O salvamento automático ocorre no armazenamento local do navegador/WebView. Exporte `.rageproj` para backup e transferência; não existe sincronização na nuvem.
- Para atualizar o app já instalado, mantenha o mesmo `appId` (`com.rageengine.editor`) e assine as futuras versões com a mesma chave. Um APK debug novo só instala como atualização se a assinatura for a mesma.

### Manipulação 3D direta (v0.3.0)
Selecione um objeto e use as ferramentas **Mover**, **Girar** e **Escalar** para arrastar os eixos/alças na viewport. Na edição mobile, os modos ficam na barra flutuante sobre a cena; no PC, ficam na barra superior. Os valores são sincronizados com o Inspector e o salvamento automático.


## v0.6.0 — Arquivos e realismo

O Project Hub agora inclui um explorador de assets com busca, pastas virtuais persistidas no `.rageproj` e movimentação de modelos/texturas entre pastas. A viewport ganhou presets iniciais de iluminação (estúdio, dia, pôr do sol e noite), exposição, sombras e perfis de qualidade.

**Limite importante:** estes recursos são uma fundação de renderização PBR e iluminação da viewport, não equivalem ao nível visual de GTA VI. Para chegar a esse patamar serão necessários pipeline HDRI/IBL, materiais completos (normal/roughness/metalness/AO), sombras avançadas, pós-processamento, streaming de mundo, LODs e um renderer/runtime próprio otimizado para cada plataforma.


## v0.7.0 — World Builder

- Terrain mesh real com subdivisões, relevo procedural e controles editáveis no Inspector.
- Mapas PBR agora são aplicados aos materiais: Base Color, Normal, Roughness, Metallic e Ambient Occlusion.
- Espaço de cor sRGB para Base Color e linear para mapas de dados.
- Preservação dos mapas originais dos materiais GLB/GLTF quando não há override do usuário.
- Os dados novos são opcionais e mantêm compatibilidade com projetos `.rageproj` versão 1.

Limitações: o terreno ainda não possui escultura por pincel, pintura por camadas nem espalhamento de vegetação. Também não há carregador HDRI/IBL, iluminação global em tempo real, geometria virtualizada ou runtime de exportação de jogos. O realismo continua dependendo de assets de alta qualidade e das capacidades do dispositivo. Em celulares, prefira o perfil Desempenho.
