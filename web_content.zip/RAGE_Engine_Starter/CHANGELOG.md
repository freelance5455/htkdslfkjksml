# Changelog

## 0.8.0 — Atmosfera dinâmica e iluminação avançada
- Adicionado céu procedural com nuvens volumétricas aproximadas por ray marching e ruído 3D/fBm, sem depender de imagens planas.
- Nuvens se deformam e se deslocam por um vetor de vento configurável nos eixos X/Z; cobertura, densidade, altura e custo de amostragem respondem ao preset climático e à qualidade.
- Adicionados presets globais de clima: céu limpo, parcialmente nublado, nublado, tempestade e neblina, com ajustes de cor, iluminação e fog.
- Adicionadas sombras de nuvens procedurais animadas nos materiais PBR, como aproximação de sombras atmosféricas em superfícies expostas.
- Sol passa a acompanhar a hora do dia; sombras direcionais recebem frustum ampliado e configuração de bias.
- Modelos GLB/GLTF agora marcam suas malhas para projetar e receber sombras.
- Luzes pontuais e spots podem projetar sombras dinâmicas: orçamento de 0/1/2 luzes locais por cena nos perfis desempenho/equilibrado/alto para evitar custo explosivo.
- Adicionada iluminação de ambiente procedural equiretangular para reflexos IBL nos materiais PBR, atualizada com hora e clima.
- Adicionados controles de luz pontual/spot, cor, intensidade, alcance e abertura; controles de nuvens, clima, densidade, cobertura e vento no painel de renderização são salvos no `.rageproj`.
- Recursos integrados nas versões PC e Mobile com o mesmo formato de projeto.
- Limites explícitos: IBL não é ray tracing completo; reflexos de objetos locais, clima por bairro, chuva/água física, vento afetando cabelo/roupa e simulação de veículos continuam no roadmap.


## 0.7.0 — World Builder e materiais PBR
- Corrigido o objeto Terrain: agora usa uma malha subdividida real, com relevo procedural e normais recalculadas.
- Adicionados controles de altura, frequência e geração de novas formações no Inspector do terreno.
- Adicionados campos tipados para mapas Normal, Roughness, Metallic e Ambient Occlusion no modelo de objeto.
- Conectada a aplicação dos mapas PBR importados aos materiais Three.js; mapas de dados usam espaço de cor linear e Base Color usa sRGB.
- Adicionado suporte de UV2 para Ambient Occlusion quando a geometria possui UVs.
- Preservados os materiais originais dos modelos GLB/GLTF quando um override não está atribuído.
- Parâmetros do terreno e referências PBR são persistidos no `.rageproj` e compatíveis entre PC e Mobile.


## 0.5.0 — Explorador de assets e realismo inicial
- Explorador de arquivos com busca, pastas virtuais persistentes e movimentação de assets entre pastas.
- Pastas padrão Models, Textures e Other; compatibilidade com assets de projetos anteriores.
- Configurações de renderização salvas no projeto: qualidade, ambiente, exposição e sombras.
- Presets de iluminação de estúdio, dia, pôr do sol e noite.
- Ajustes de pixel ratio e resolução de sombras por perfil de desempenho.
- Base PBR com gerenciamento de luzes, tone mapping ACES e sombras em tempo real.
- PC e Mobile compartilham o mesmo formato de projeto e as mesmas configurações.


## 0.4.0 — Projetos, cenas e assets
- Criado o formato portátil `.rageproj` (JSON) com metadados, múltiplas cenas, assets incorporados e cena inicial de exportação.
- Adicionado salvamento automático de projetos em IndexedDB, com fallback localStorage, nas edições PC e Mobile.
- Adicionado gerenciador para criar projetos, abrir projetos locais, importar/exportar `.rageproj` e importar cenas `.ragescene` existentes.
- Adicionado suporte a múltiplas cenas por projeto, com criação, troca, renomeação e exclusão protegida da última cena.
- Adicionada hierarquia de objetos com grupos e objetos filhos.
- Adicionada importação de modelos `.glb` e `.gltf`; o importador incorpora dependências `.bin`/imagens do glTF quando selecionadas junto ao arquivo principal.
- Adicionado gerenciamento de assets de textura e aplicação de cor, rugosidade, metalicidade e textura no Inspector.
- Integrado o carregamento de modelos e texturas no viewport Three.js.
- Adicionadas configurações de cena inicial e exportação de manifesto `.ragebuild.json` para preparar o pipeline de build futuro.
- Mantida a leitura de cenas `.ragescene` v1 criadas nas versões anteriores.

## 0.3.1 — Correção dos TransformControls
- Corrigida a integração com `TransformControls` da dependência `three-stdlib` usada pelo projeto.
- O helper é adicionado diretamente à cena, conforme a API desta versão.
- Eventos de arraste e alteração do objeto são tipados por uma ponte local, sem acessar propriedades privadas (`dragging` e `axis`).
- O mesmo ajuste foi aplicado às versões mobile e PC.

## 0.3.0 — Manipulação direta de objetos
- Adicionados gizmos 3D de mover, rotacionar e escalar nas versões mobile e PC.
- O arraste das alças atualiza posição, rotação e escala no inspector e no salvamento automático.
- A navegação da câmera é pausada enquanto uma alça está sendo arrastada.
- Na edição mobile, os modos de transformação ficam disponíveis sobre a viewport.

## 0.2.0 — Base de edição mobile
- Adicionada configuração Capacitor 8 para empacotar a edição mobile em APK.
- Adicionados plugins nativos Filesystem e Share para exportar cenas no Android.
- Adicionado salvamento automático local.
- Adicionada validação do formato de cena importado e tela de erro de WebGL.
