import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.rageengine.editor',
  appName: 'RAGE Engine',
  webDir: 'dist'
};

export default config;
