import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { GLTFLoader, OrbitControls, TransformControls } from 'three-stdlib';
import type { ProjectAsset, RenderSettings, SceneObject, Vec3 } from './model';
import { createAtmosphereDome, createReflectionEnvironment, updateAtmosphereUniforms } from './atmosphere';

type TransformSnapshot = { position: Vec3; rotation: Vec3; scale: Vec3 };
type Props = {
  objects: SceneObject[];
  assets: ProjectAsset[];
  selectedId: string | null;
  onSelect: (id: string | null) => void;
  onTransform: (id: string, value: TransformSnapshot) => void;
  tool: string;
  showGrid: boolean;
  renderSettings?: RenderSettings;
};
type SceneRuntime = {
  scene: THREE.Scene;
  grid: THREE.GridHelper;
  camera: THREE.PerspectiveCamera;
  renderer: THREE.WebGLRenderer;
  controls: OrbitControls;
  transform: TransformControls;
  isTransformDragging: { current: boolean };
  meshes: Map<string, THREE.Object3D>;
  textureCache: Map<string, THREE.Texture>;
  loadingModels: Set<string>;
  raycaster: THREE.Raycaster;
  pointer: THREE.Vector2;
  sun: THREE.DirectionalLight;
  hemi: THREE.HemisphereLight;
  fill: THREE.AmbientLight;
  skyDome: THREE.Mesh;
  reflectionEnvironment: THREE.DataTexture;
  cloudShadowUniforms: { time: { value: number }; coverage: { value: number }; density: { value: number }; wind: { value: THREE.Vector2 }; sunDirection: { value: THREE.Vector3 } };
};

function disposeObject(object: THREE.Object3D) {
  object.traverse((child) => {
    if (child instanceof THREE.Mesh) {
      child.geometry.dispose();
      if (Array.isArray(child.material)) child.material.forEach((material) => material.dispose());
      else child.material.dispose();
    }
  });
}

function createTerrainGeometry(amplitude = 1.35, frequency = 0.28, seed = 7) {
  const segments = 64;
  const geometry = new THREE.PlaneGeometry(24, 24, segments, segments);
  geometry.rotateX(-Math.PI / 2);
  const position = geometry.attributes.position;
  for (let i = 0; i < position.count; i++) {
    const x = position.getX(i);
    const z = position.getZ(i);
    const phase = seed * 0.173;
    const broad = Math.sin(x * frequency + phase) * Math.cos(z * frequency * 0.82 - phase) * 0.58;
    const ridge = Math.max(0, Math.sin((x + z) * frequency * 0.68 + phase * 2)) * 0.34;
    const detail = Math.sin(x * frequency * 4.4 + z * frequency * 2.7 + phase) * Math.cos(z * frequency * 3.8 - phase) * 0.055;
    position.setY(i, (broad + ridge + detail) * amplitude);
  }
  position.needsUpdate = true;
  geometry.computeVertexNormals();
  return geometry;
}

function markObjectTree(object: THREE.Object3D, objectId: string) {
  object.traverse((child) => {
    child.userData.objectId = objectId;
    if (child instanceof THREE.Mesh) { child.castShadow = true; child.receiveShadow = true; }
  });
}

function attachProceduralCloudShadows(state: SceneRuntime, material: THREE.Material) {
  const standard = material as THREE.MeshStandardMaterial;
  if (!standard.isMeshStandardMaterial || standard.userData.rageCloudShadowPatched) return;
  const originalCompile = standard.onBeforeCompile;
  standard.onBeforeCompile = (shader, renderer) => {
    originalCompile.call(standard, shader, renderer);
    shader.uniforms.rageCloudTime = state.cloudShadowUniforms.time;
    shader.uniforms.rageCloudCoverage = state.cloudShadowUniforms.coverage;
    shader.uniforms.rageCloudDensity = state.cloudShadowUniforms.density;
    shader.uniforms.rageCloudWind = state.cloudShadowUniforms.wind;
    shader.uniforms.rageCloudSunDirection = state.cloudShadowUniforms.sunDirection;
    shader.vertexShader = shader.vertexShader.replace(
      '#include <common>',
      '#include <common>\nvarying vec3 vRageWorldPosition;\nvarying vec3 vRageWorldNormal;'
    ).replace(
      '#include <worldpos_vertex>',
      '#include <worldpos_vertex>\nvRageWorldPosition = (modelMatrix * vec4(transformed, 1.0)).xyz;\nvRageWorldNormal = normalize(mat3(modelMatrix) * objectNormal);'
    );
    shader.fragmentShader = shader.fragmentShader.replace(
      '#include <common>',
      `#include <common>
      varying vec3 vRageWorldPosition;
      varying vec3 vRageWorldNormal;
      uniform float rageCloudTime;
      uniform float rageCloudCoverage;
      uniform float rageCloudDensity;
      uniform vec2 rageCloudWind;
      uniform vec3 rageCloudSunDirection;
      float rageCloudHash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
      float rageCloudNoise(vec2 p) {
        vec2 i = floor(p); vec2 f = fract(p); f = f * f * (3.0 - 2.0 * f);
        float a = rageCloudHash(i); float b = rageCloudHash(i + vec2(1.0, 0.0));
        float c = rageCloudHash(i + vec2(0.0, 1.0)); float d = rageCloudHash(i + vec2(1.0, 1.0));
        return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
      }`
    ).replace(
      '#include <color_fragment>',
      `#include <color_fragment>
      vec2 rageCloudCoord = vRageWorldPosition.xz * 0.026 + rageCloudWind * rageCloudTime * 0.28;
      float rageCloudField = rageCloudNoise(rageCloudCoord) * 0.68 + rageCloudNoise(rageCloudCoord * 2.1 + 7.3) * 0.32;
      float rageCloudMask = smoothstep(0.50 - rageCloudCoverage * 0.12, 0.76, rageCloudField) * rageCloudCoverage;
      float rageCloudFacing = 0.25 + 0.75 * max(dot(normalize(vRageWorldNormal), normalize(rageCloudSunDirection)), 0.0);
      diffuseColor.rgb *= 1.0 - rageCloudMask * rageCloudDensity * rageCloudFacing * 0.48;`
    );
  };
  standard.customProgramCacheKey = () => 'rage-procedural-cloud-shadow-v1';
  standard.userData.rageCloudShadowPatched = true;
  standard.needsUpdate = true;
}

function applyAppearance(state: SceneRuntime, object: THREE.Object3D, data: SceneObject, selectedId: string | null, assets: ProjectAsset[]) {
  if (data.type === 'group') return;
  const loadMap = (assetId: string | null | undefined, color: boolean): THREE.Texture | null => {
    if (!assetId) return null;
    const asset = assets.find((entry) => entry.id === assetId && entry.kind === 'texture');
    if (!asset) return null;
    const cacheKey = `${asset.id}:${color ? 'srgb' : 'linear'}`;
    const cached = state.textureCache.get(cacheKey);
    if (cached) return cached;
    const texture = new THREE.TextureLoader().load(asset.dataUrl);
    texture.colorSpace = color ? THREE.SRGBColorSpace : THREE.NoColorSpace;
    texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
    texture.anisotropy = Math.min(8, state.renderer.capabilities.getMaxAnisotropy());
    state.textureCache.set(cacheKey, texture);
    return texture;
  };
  const baseMap = loadMap(data.textureAssetId, true);
  const normalMap = loadMap(data.normalMapAssetId, false);
  const roughnessMap = loadMap(data.roughnessMapAssetId, false);
  const metalnessMap = loadMap(data.metalnessMapAssetId, false);
  const aoMap = loadMap(data.aoMapAssetId, false);
  object.traverse((child) => {
    if (!(child instanceof THREE.Mesh)) return;
    if (aoMap && child.geometry.getAttribute('uv') && !child.geometry.getAttribute('uv2')) {
      child.geometry.setAttribute('uv2', child.geometry.getAttribute('uv').clone());
    }
    const materials = Array.isArray(child.material) ? child.material : [child.material];
    for (const material of materials) {
      attachProceduralCloudShadows(state, material);
      if (data.type !== 'model' || data.materialColor) {
        const nextColor = data.materialColor ?? data.color;
        if ('color' in material) (material as THREE.MeshStandardMaterial).color.set(nextColor);
      }
      if (data.roughness !== undefined && 'roughness' in material) (material as THREE.MeshStandardMaterial).roughness = data.roughness;
      if (data.metalness !== undefined && 'metalness' in material) (material as THREE.MeshStandardMaterial).metalness = data.metalness;
      if ('map' in material) {
        const standard = material as THREE.MeshStandardMaterial;
        const originals = (standard.userData.rageOriginalMaps ??= {
          map: standard.map, normalMap: standard.normalMap, roughnessMap: standard.roughnessMap,
          metalnessMap: standard.metalnessMap, aoMap: standard.aoMap
        }) as { map: THREE.Texture | null; normalMap: THREE.Texture | null; roughnessMap: THREE.Texture | null; metalnessMap: THREE.Texture | null; aoMap: THREE.Texture | null };
        standard.map = baseMap ?? (data.textureAssetId ? null : originals.map);
        standard.normalMap = normalMap ?? (data.normalMapAssetId ? null : originals.normalMap);
        standard.roughnessMap = roughnessMap ?? (data.roughnessMapAssetId ? null : originals.roughnessMap);
        standard.metalnessMap = metalnessMap ?? (data.metalnessMapAssetId ? null : originals.metalnessMap);
        standard.aoMap = aoMap ?? (data.aoMapAssetId ? null : originals.aoMap);
        standard.needsUpdate = true;
      }
      if ('emissive' in material) {
        const standard = material as THREE.MeshStandardMaterial;
        standard.emissive.set(data.id === selectedId ? '#263b20' : '#000000');
        standard.emissiveIntensity = data.id === selectedId ? 0.75 : 0;
      }
    }
  });
}

export default function SceneView({ objects, assets, selectedId, onSelect, onTransform, tool, showGrid, renderSettings }: Props) {
  const host = useRef<HTMLDivElement>(null);
  const runtime = useRef<SceneRuntime | null>(null);
  const selectedIdRef = useRef(selectedId);
  const onTransformRef = useRef(onTransform);
  const toolRef = useRef(tool);
  const objectsRef = useRef(objects);
  const assetsRef = useRef(assets);
  const renderSettingsRef = useRef(renderSettings);
  renderSettingsRef.current = renderSettings;
  const [rendererError, setRendererError] = useState<string | null>(null);
  selectedIdRef.current = selectedId;
  onTransformRef.current = onTransform;
  toolRef.current = tool;
  objectsRef.current = objects;
  assetsRef.current = assets;

  useEffect(() => {
    const container = host.current;
    if (!container) return;
    const scene = new THREE.Scene();
    scene.background = new THREE.Color('#151d23');
    const skyDome = createAtmosphereDome();
    scene.add(skyDome);
    scene.fog = new THREE.Fog('#151d23', 18, 55);
    const camera = new THREE.PerspectiveCamera(55, 1, 0.1, 200);
    camera.position.set(7, 6, 9);
    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: window.innerWidth > 700, alpha: false });
    } catch (error) {
      const details = error instanceof Error ? error.message : String(error);
      setRendererError(`O WebGL não pôde ser iniciado neste aparelho. ${details}`);
      console.error('RAGE Engine: falha ao iniciar o WebGL:', error);
      return;
    }
    setRendererError(null);
    const initialQuality = renderSettingsRef.current?.quality ?? 'balanced';
    const pixelLimit = initialQuality === 'high' ? 2 : initialQuality === 'performance' ? 1 : 1.5;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, pixelLimit));
    renderer.shadowMap.enabled = renderSettingsRef.current?.shadows ?? true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.shadowMap.autoUpdate = true;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = renderSettingsRef.current?.exposure ?? 1.15;
    renderer.domElement.style.touchAction = 'none';
    container.appendChild(renderer.domElement);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.target.set(0, 0, 0);
    const transform = new TransformControls(camera, renderer.domElement);
    // three-stdlib expõe o controle como Object3D.
    scene.add(transform);
    const isTransformDragging = { current: false };
    const transformEvents = transform as unknown as {
      addEventListener(type: 'dragging-changed', listener: (event: { value: boolean }) => void): void;
      addEventListener(type: 'objectChange', listener: () => void): void;
    };
    transformEvents.addEventListener('dragging-changed', (event) => {
      isTransformDragging.current = event.value;
      controls.enabled = !event.value;
    });
    transformEvents.addEventListener('objectChange', () => {
      const id = selectedIdRef.current;
      const object = id ? runtime.current?.meshes.get(id) : null;
      if (!id || !object) return;
      onTransformRef.current(id, {
        position: [object.position.x, object.position.y, object.position.z],
        rotation: [THREE.MathUtils.radToDeg(object.rotation.x), THREE.MathUtils.radToDeg(object.rotation.y), THREE.MathUtils.radToDeg(object.rotation.z)],
        scale: [object.scale.x, object.scale.y, object.scale.z]
      });
    });

    const initialSettings = renderSettingsRef.current ?? { quality: 'balanced', environment: 'daylight', exposure: 1.15, shadows: true };
    const reflectionEnvironment = createReflectionEnvironment(initialSettings);
    scene.environment = reflectionEnvironment;
    scene.environmentIntensity = initialQuality === 'high' ? 1 : 0.72;
    const hemi = new THREE.HemisphereLight(0xc8e3ed, 0x29352d, 1.5);
    scene.add(hemi);
    const fill = new THREE.AmbientLight(0xffffff, 0.22);
    scene.add(fill);
    const sun = new THREE.DirectionalLight(0xffe6bd, 3);
    sun.position.set(5, 9, 4);
    sun.castShadow = renderSettingsRef.current?.shadows ?? true;
    sun.shadow.mapSize.set(initialQuality === 'high' ? 2048 : initialQuality === 'performance' ? 512 : 1024, initialQuality === 'high' ? 2048 : initialQuality === 'performance' ? 512 : 1024);
    sun.shadow.camera.near = 0.5; sun.shadow.camera.far = 60;
    sun.shadow.bias = -0.00015;
    scene.add(sun);
    const grid = new THREE.GridHelper(30, 30, '#68836f', '#34453d');
    (grid.material as THREE.Material).transparent = true;
    (grid.material as THREE.Material).opacity = 0.5;
    scene.add(grid);
    scene.add(new THREE.AxesHelper(1.5));
    const raycaster = new THREE.Raycaster();
    const pointer = new THREE.Vector2();
    const cloudShadowUniforms = { time: { value: 0 }, coverage: { value: 0.56 }, density: { value: 0.82 }, wind: { value: new THREE.Vector2(0.65, 0.22) }, sunDirection: { value: new THREE.Vector3(0.2, 0.8, 0.3) } };
    const state: SceneRuntime = {
      scene, camera, renderer, controls, transform, isTransformDragging, grid,
      meshes: new Map(), textureCache: new Map(), loadingModels: new Set(), raycaster, pointer, sun, hemi, fill,
      skyDome, reflectionEnvironment, cloudShadowUniforms
    };
    runtime.current = state;

    const resize = () => {
      if (!host.current) return;
      const width = Math.max(host.current.clientWidth, 1);
      const height = Math.max(host.current.clientHeight, 1);
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
    };
    const observer = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(resize) : null;
    observer?.observe(container);
    window.addEventListener('resize', resize);
    resize();
    let frame = 0;
    const atmosphereClock = new THREE.Clock();
    const loop = () => {
      frame = requestAnimationFrame(loop);
      controls.update();
      skyDome.position.copy(camera.position);
      const elapsed = atmosphereClock.getElapsedTime();
      const liveSettings = renderSettingsRef.current ?? initialSettings;
      updateAtmosphereUniforms(skyDome, liveSettings, sun.position, camera.position, elapsed);
      const weatherCoverage = liveSettings.clouds === false ? 0 : (liveSettings.cloudCoverage ?? 0.56);
      cloudShadowUniforms.time.value = elapsed;
      cloudShadowUniforms.coverage.value = weatherCoverage;
      cloudShadowUniforms.density.value = liveSettings.cloudDensity ?? 0.82;
      cloudShadowUniforms.wind.value.set(liveSettings.windX ?? 0.65, liveSettings.windZ ?? 0.22);
      cloudShadowUniforms.sunDirection.value.copy(sun.position).normalize();
      renderer.render(scene, camera);
    };
    loop();
    const click = (event: PointerEvent) => {
      if (isTransformDragging.current) return;
      const rect = renderer.domElement.getBoundingClientRect();
      if (!rect.width || !rect.height) return;
      pointer.set(((event.clientX - rect.left) / rect.width) * 2 - 1, -((event.clientY - rect.top) / rect.height) * 2 + 1);
      raycaster.setFromCamera(pointer, camera);
      const hits = raycaster.intersectObjects([...state.meshes.values()], true);
      const hit = hits.find((candidate) => candidate.object.userData.objectId);
      onSelect(hit ? String(hit.object.userData.objectId) : null);
    };
    renderer.domElement.addEventListener('pointerdown', click);
    return () => {
      cancelAnimationFrame(frame);
      observer?.disconnect();
      window.removeEventListener('resize', resize);
      renderer.domElement.removeEventListener('pointerdown', click);
      transform.detach();
      transform.dispose();
      controls.dispose();
      for (const object of state.meshes.values()) disposeObject(object);
      state.textureCache.forEach((texture) => texture.dispose());
      state.skyDome.geometry.dispose();
      (state.skyDome.material as THREE.ShaderMaterial).dispose();
      state.reflectionEnvironment.dispose();
      renderer.dispose();
      renderer.domElement.remove();
      runtime.current = null;
    };
  }, [onSelect]);

  useEffect(() => {
    const state = runtime.current;
    if (!state) return;
    const settings = renderSettings ?? { quality: 'balanced', environment: 'daylight', exposure: 1.15, shadows: true };
    const palettes = {
      studio: { background: '#20272d', fog: '#20272d', sky: 0xcbd5df, ground: 0x343a40, sun: 0xffffff, sunIntensity: 2.2, hemi: 1.25, fill: 0.35, fogNear: 30, fogFar: 90 },
      daylight: { background: '#8ba7b8', fog: '#8ba7b8', sky: 0xd7eaff, ground: 0x465344, sun: 0xfff0d4, sunIntensity: 3.1, hemi: 1.65, fill: 0.18, fogNear: 45, fogFar: 140 },
      sunset: { background: '#75564e', fog: '#75564e', sky: 0xffb47c, ground: 0x40312f, sun: 0xffa36b, sunIntensity: 2.6, hemi: 0.9, fill: 0.12, fogNear: 35, fogFar: 110 },
      night: { background: '#101a2b', fog: '#101a2b', sky: 0x344e82, ground: 0x101827, sun: 0x9bbcff, sunIntensity: 0.65, hemi: 0.42, fill: 0.08, fogNear: 25, fogFar: 85 }
    } as const;
    const palette = palettes[settings.environment];
    const hour = settings.timeOfDay ?? 14;
    const daylight = Math.max(0, Math.sin(((hour - 6) / 12) * Math.PI));
    const dawn = Math.max(0, 1 - Math.abs(hour - 6) / 3);
    const dusk = Math.max(0, 1 - Math.abs(hour - 18) / 3);
    const timeTint = new THREE.Color().setHSL(0.58 - 0.12 * (dusk + dawn), 0.24 + 0.25 * daylight, 0.18 + 0.36 * daylight);
    state.scene.background = settings.environment === 'daylight' ? timeTint : new THREE.Color(palette.background);
    const weather = settings.weather ?? 'partly-cloudy';
    const fogNear = weather === 'fog' ? 8 : weather === 'storm' ? 16 : weather === 'overcast' ? palette.fogNear * 0.82 : palette.fogNear;
    const fogFar = weather === 'fog' ? 48 : weather === 'storm' ? 72 : weather === 'overcast' ? palette.fogFar * 0.78 : palette.fogFar;
    state.scene.fog = new THREE.Fog(palette.fog, fogNear, fogFar);
    const weatherLighting = weather === 'storm' ? 0.44 : weather === 'overcast' ? 0.68 : weather === 'fog' ? 0.58 : 1;
    state.hemi.color.setHex(palette.sky); state.hemi.groundColor.setHex(palette.ground); state.hemi.intensity = (settings.environment === 'daylight' ? 0.25 + daylight * 1.45 : palette.hemi) * weatherLighting;
    state.fill.intensity = palette.fill * weatherLighting;
    state.sun.color.copy(new THREE.Color(palette.sun).lerp(new THREE.Color('#ff9b62'), settings.environment === 'daylight' ? Math.min(1, dawn + dusk) : 0));
    const sunElevation = Math.sin(((hour - 6) / 12) * Math.PI);
    const sunAzimuth = ((hour - 12) / 12) * Math.PI * 0.78;
    const sunHeight = settings.environment === 'night' ? -5 : sunElevation * 24 + 1.5;
    state.sun.position.set(Math.cos(sunAzimuth) * 28, sunHeight, Math.sin(sunAzimuth) * 28);
    state.sun.intensity = (settings.environment === 'daylight' ? palette.sunIntensity * (0.06 + daylight * 0.94) : palette.sunIntensity) * weatherLighting;
    state.scene.environmentIntensity = settings.quality === 'high' ? 1.0 : settings.quality === 'performance' ? 0.48 : 0.72;
    const nextEnvironment = createReflectionEnvironment(settings);
    state.scene.environment = nextEnvironment;
    state.reflectionEnvironment.dispose();
    state.reflectionEnvironment = nextEnvironment;
    state.renderer.toneMappingExposure = settings.exposure;
    state.renderer.shadowMap.enabled = settings.shadows;
    state.sun.castShadow = settings.shadows;
    state.sun.shadow.camera.left = -28; state.sun.shadow.camera.right = 28;
    state.sun.shadow.camera.top = 28; state.sun.shadow.camera.bottom = -28;
    state.sun.shadow.camera.near = 0.5; state.sun.shadow.camera.far = 90;
    state.sun.shadow.camera.updateProjectionMatrix();
    const quality = settings.quality;
    state.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, quality === 'high' ? 2 : quality === 'performance' ? 1 : 1.5));
    const shadowSize = quality === 'high' ? 2048 : quality === 'performance' ? 512 : 1024;
    if (state.sun.shadow.mapSize.width !== shadowSize) {
      state.sun.shadow.map?.dispose();
      state.sun.shadow.mapSize.set(shadowSize, shadowSize);
      state.sun.shadow.needsUpdate = true;
    }
    state.sun.shadow.bias = -0.00012;
    state.sun.shadow.normalBias = 0.025;
  }, [renderSettings]);

  useEffect(() => {
    const state = runtime.current;
    if (!state) return;
    state.grid.visible = showGrid;
    const wanted = new Set(objects.map((object) => object.id));
    for (const [id, object] of state.meshes) {
      if (!wanted.has(id)) {
        object.parent?.remove(object);
        disposeObject(object);
        state.meshes.delete(id);
        state.loadingModels.delete(id);
      }
    }

    // Create every node before attaching parents so imported projects can store any ordering.
    let selectedObjectReplaced = false;
    for (const data of objects) {
      const existing = state.meshes.get(data.id);
      if (existing && (existing.userData.rageType !== data.type || (data.type === 'model' && existing.userData.rageAssetId !== data.assetId) || (data.type === 'light' && existing.userData.rageLightType !== (data.lightType ?? 'point')))) {
        if (data.id === selectedIdRef.current) selectedObjectReplaced = true;
        existing.parent?.remove(existing);
        disposeObject(existing);
        state.meshes.delete(data.id);
        state.loadingModels.delete(data.id);
      }
      if (state.meshes.has(data.id)) continue;
      let object: THREE.Object3D;
      if (data.type === 'group' || data.type === 'model') {
        object = new THREE.Group();
      } else if (data.type === 'light') {
        const intensity = data.lightIntensity ?? 45;
        const distance = data.lightDistance ?? 18;
        const light = data.lightType === 'spot'
          ? new THREE.SpotLight(data.color, intensity, distance, THREE.MathUtils.degToRad(data.lightAngle ?? 38), 0.32, 2)
          : new THREE.PointLight(data.color, intensity, distance, 2);
        if (light instanceof THREE.SpotLight) {
          light.target.position.set(0, -1, 0);
          light.add(light.target);
        }
        const marker = new THREE.Mesh(new THREE.SphereGeometry(0.12, 16, 12), new THREE.MeshBasicMaterial({ color: data.color }));
        light.add(marker);
        object = light;
      } else {
        const geometry = data.type === 'terrain' ? createTerrainGeometry(data.terrainAmplitude, data.terrainFrequency, data.terrainSeed)
          : data.type === 'sphere' ? new THREE.SphereGeometry(0.5, 32, 20)
          : data.type === 'plane' ? new THREE.PlaneGeometry(1, 1)
          : data.type === 'cylinder' ? new THREE.CylinderGeometry(0.5, 0.5, 1, 24)
          : new THREE.BoxGeometry(1, 1, 1);
        if (data.type === 'plane') geometry.rotateX(-Math.PI / 2);
        const material = new THREE.MeshStandardMaterial({ color: data.color, roughness: data.roughness ?? 0.72, metalness: data.metalness ?? 0.05 });
        const mesh = new THREE.Mesh(geometry, material);
        mesh.castShadow = true;
        mesh.receiveShadow = true;
        object = mesh;
      }
      object.userData.objectId = data.id;
      object.userData.rageType = data.type;
      object.userData.rageAssetId = data.assetId ?? null;
      if (data.type === 'light') object.userData.rageLightType = data.lightType ?? 'point';
      state.meshes.set(data.id, object);
      if (data.type === 'terrain') object.userData.terrainSignature = `${data.terrainAmplitude ?? 1.35}|${data.terrainFrequency ?? 0.28}|${data.terrainSeed ?? 7}`;
      if (data.type === 'model' && data.assetId) {
        const modelAsset = assets.find((asset) => asset.id === data.assetId && asset.kind === 'model');
        if (modelAsset) {
          state.loadingModels.add(data.id);
          const loader = new GLTFLoader();
          const isJson = modelAsset.mimeType === 'model/gltf+json';
          const readModel = isJson ? fetch(modelAsset.dataUrl).then((response) => response.text()) : fetch(modelAsset.dataUrl).then((response) => response.arrayBuffer());
          readModel.then((source) => new Promise<void>((resolve, reject) => {
            loader.parse(source, '', (gltf) => {
              if (state.meshes.get(data.id) !== object) {
                disposeObject(gltf.scene);
                resolve();
                return;
              }
              markObjectTree(gltf.scene, data.id);
              object.add(gltf.scene);
              const latestData = objectsRef.current.find((item) => item.id === data.id);
              if (latestData) applyAppearance(state, object, latestData, selectedIdRef.current, assetsRef.current);
              resolve();
            }, reject);
          })).catch((error: unknown) => console.error(`Falha ao carregar ${modelAsset.name}:`, error))
            .finally(() => state.loadingModels.delete(data.id));
        }
      }
    }

    for (const data of objects) {
      const object = state.meshes.get(data.id);
      if (!object) continue;
      const possibleParent = data.parentId ? state.meshes.get(data.parentId) : null;
      const parent = possibleParent?.userData.objectId && objects.find((item) => item.id === data.parentId)?.type === 'group' ? possibleParent : state.scene;
      if (object.parent !== parent) parent.add(object);
      if (!(state.isTransformDragging.current && selectedId === data.id)) {
        object.position.set(...data.position);
        object.rotation.set(...data.rotation.map((value) => value * Math.PI / 180) as [number, number, number]);
        object.scale.set(...data.scale);
      }
      object.visible = data.visible;
      if (object instanceof THREE.PointLight || object instanceof THREE.SpotLight) {
        object.color.set(data.color);
        object.intensity = data.lightIntensity ?? 45;
        object.distance = data.lightDistance ?? 18;
        if (object instanceof THREE.SpotLight) object.angle = THREE.MathUtils.degToRad(data.lightAngle ?? 38);
      }
      if (data.type === 'terrain' && object instanceof THREE.Mesh) {
        const signature = `${data.terrainAmplitude ?? 1.35}|${data.terrainFrequency ?? 0.28}|${data.terrainSeed ?? 7}`;
        if (object.userData.terrainSignature !== signature) {
          object.geometry.dispose();
          object.geometry = createTerrainGeometry(data.terrainAmplitude, data.terrainFrequency, data.terrainSeed);
          object.userData.terrainSignature = signature;
        }
      }
      applyAppearance(state, object, data, selectedId, assets);
    }
    // Point-light shadow maps render the scene six times per light. Keep a small quality-based budget.
    const shadowSettings = renderSettingsRef.current ?? { quality: 'balanced', environment: 'daylight', exposure: 1.15, shadows: true };
    const localShadowBudget = shadowSettings.shadows ? (shadowSettings.quality === 'high' ? 2 : shadowSettings.quality === 'balanced' ? 1 : 0) : 0;
    let localShadowCount = 0;
    for (const data of objects) {
      const light = state.meshes.get(data.id);
      if (!(light instanceof THREE.PointLight) && !(light instanceof THREE.SpotLight)) continue;
      const canCast = data.visible && localShadowCount < localShadowBudget;
      light.castShadow = canCast;
      if (canCast) {
        localShadowCount += 1;
        const localMapSize = shadowSettings.quality === 'high' ? 1024 : 512;
        if (light.shadow.mapSize.width !== localMapSize) {
          light.shadow.map?.dispose();
          light.shadow.mapSize.set(localMapSize, localMapSize);
        }
        light.shadow.camera.near = 0.1;
        light.shadow.camera.far = Math.max(24, light.distance || 24);
        light.shadow.camera.updateProjectionMatrix();
        light.shadow.bias = -0.00025;
        light.shadow.normalBias = 0.025;
      }
    }
    if (selectedObjectReplaced && selectedIdRef.current && toolRef.current !== 'select') {
      const replacement = state.meshes.get(selectedIdRef.current);
      if (replacement) state.transform.attach(replacement);
    }
  }, [objects, assets, selectedId, showGrid, renderSettings]);

  useEffect(() => {
    const state = runtime.current;
    if (!state) return;
    const selected = selectedId ? state.meshes.get(selectedId) : null;
    if (!selected || tool === 'select') {
      state.transform.detach();
      return;
    }
    state.transform.setMode(tool === 'rotate' ? 'rotate' : tool === 'scale' ? 'scale' : 'translate');
    state.transform.setSpace('world');
    state.transform.attach(selected);
    state.transform.setSize(window.innerWidth < 700 ? 0.9 : 0.8);
  }, [selectedId, tool]);

  return (
    <div className="scene-host" ref={host}>
      <div className="viewport-hint">Arraste as alças para transformar · Arraste fora delas para orbitar · Pinça para zoom</div>
      {rendererError && <div className="scene-error" role="alert"><strong>Viewport 3D indisponível</strong><span>{rendererError}</span><small>Atualize o Android System WebView/Chrome e confira se a aceleração gráfica está ativa.</small></div>}
    </div>
  );
}
