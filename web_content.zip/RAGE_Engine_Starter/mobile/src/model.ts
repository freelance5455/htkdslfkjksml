export type Vec3 = [number, number, number];
export type ObjectKind = 'cube' | 'sphere' | 'plane' | 'terrain' | 'cylinder' | 'light' | 'group' | 'model';

export type SceneObject = {
  id: string;
  name: string;
  type: ObjectKind;
  position: Vec3;
  rotation: Vec3;
  scale: Vec3;
  color: string;
  visible: boolean;
  /** Only groups may be parents. Values are local transforms relative to the parent. */
  parentId?: string | null;
  /** Project asset reference used by imported model objects. */
  assetId?: string | null;
  /** Material overrides. When absent, imported model materials keep their source appearance. */
  roughness?: number;
  metalness?: number;
  textureAssetId?: string | null;
  materialColor?: string;
  normalMapAssetId?: string | null;
  roughnessMapAssetId?: string | null;
  metalnessMapAssetId?: string | null;
  aoMapAssetId?: string | null;
  terrainAmplitude?: number;
  terrainFrequency?: number;
  terrainSeed?: number;
  lightType?: 'point' | 'spot';
  lightIntensity?: number;
  lightDistance?: number;
  lightAngle?: number;
};

export type SceneDocument = {
  format: 'rage-scene';
  version: 1;
  id?: string;
  name: string;
  objects: SceneObject[];
  /** Optional assets make a standalone .ragescene portable without changing its v1 format. */
  assets?: ProjectAsset[];
};

export type ProjectAsset = {
  id: string;
  /** Virtual folder inside the project file browser. */
  folder?: string;
  name: string;
  kind: 'model' | 'texture' | 'other';
  mimeType: string;
  dataUrl: string;
  size: number;
};

export type WeatherPreset = 'clear' | 'partly-cloudy' | 'overcast' | 'storm' | 'fog';
export type RenderSettings = { quality: 'performance' | 'balanced' | 'high'; environment: 'studio' | 'daylight' | 'sunset' | 'night'; exposure: number; shadows: boolean; timeOfDay?: number; clouds?: boolean; cloudCoverage?: number; cloudDensity?: number; windX?: number; windZ?: number; weather?: WeatherPreset };

export type RageProject = {
  format: 'rage-project';
  version: 1;
  id: string;
  name: string;
  createdAt: string;
  updatedAt: string;
  activeSceneId: string;
  scenes: SceneDocument[];
  assets: ProjectAsset[];
  assetFolders?: string[];
  renderSettings?: RenderSettings;
  exportSettings: {
    target: 'web';
    startSceneId: string;
  };
};

export const starterObjects: SceneObject[] = [
  { id: 'ground', name: 'Ground', type: 'plane', position: [0, -0.55, 0], rotation: [0, 0, 0], scale: [12, 1, 12], color: '#536b5b', visible: true },
  { id: 'starter-cube', name: 'Starter Cube', type: 'cube', position: [0, 0.5, 0], rotation: [0, 0, 0], scale: [1, 1, 1], color: '#83aeb2', visible: true },
  { id: 'sun-light', name: 'Sun Light', type: 'light', position: [3, 5, 3], rotation: [0, 0, 0], scale: [1, 1, 1], color: '#fff0cf', visible: true }
];

export function createId(prefix = 'rage'): string {
  return typeof crypto !== 'undefined' && 'randomUUID' in crypto
    ? `${prefix}-${crypto.randomUUID()}`
    : `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}

export function makeObject(type: ObjectKind, n: number, assetId?: string): SceneObject {
  return {
    id: createId('object'),
    name: type === 'model' ? `Modelo ${n}` : type === 'group' ? `Grupo ${n}` : `${type[0].toUpperCase()}${type.slice(1)} ${n}`,
    type,
    position: [0, type === 'plane' || type === 'group' ? 0 : 0.5, 0],
    rotation: [0, 0, 0],
    scale: type === 'plane' ? [3, 1, 3] : [1, 1, 1],
    color: type === 'light' ? '#fff0cf' : '#83aeb2',
    visible: true,
    ...(assetId ? { assetId } : {}),
    ...(type === 'terrain' ? { terrainAmplitude: 1.35, terrainFrequency: 0.28, terrainSeed: 7 } : {}),
    ...(type === 'light' ? { lightType: 'point' as const, lightIntensity: 45, lightDistance: 18, lightAngle: 38 } : {})
  };
}

export function createScene(name = 'Nova Cena', objects: SceneObject[] = []): SceneDocument {
  return { format: 'rage-scene', version: 1, id: createId('scene'), name, objects };
}

export function createProject(name = 'Meu Projeto'): RageProject {
  const scene = createScene('Main Scene', starterObjects.map((object) => ({ ...object, position: [...object.position] as Vec3, rotation: [...object.rotation] as Vec3, scale: [...object.scale] as Vec3 })));
  const now = new Date().toISOString();
  return {
    format: 'rage-project', version: 1, id: createId('project'), name, createdAt: now, updatedAt: now,
    activeSceneId: scene.id!, scenes: [scene], assets: [], assetFolders: ['Models', 'Textures', 'Other'],
    renderSettings: { quality: 'balanced', environment: 'daylight', exposure: 1.15, shadows: true, timeOfDay: 14, clouds: true, cloudCoverage: 0.56, cloudDensity: 0.82, windX: 0.65, windZ: 0.22, weather: 'partly-cloudy' },
    exportSettings: { target: 'web', startSceneId: scene.id! }
  };
}

const isVec3 = (value: unknown): value is Vec3 =>
  Array.isArray(value) && value.length === 3 && value.every((n) => typeof n === 'number' && Number.isFinite(n));

export function isSceneObject(value: unknown): value is SceneObject {
  if (!value || typeof value !== 'object') return false;
  const item = value as Record<string, unknown>;
  const validType = ['cube', 'sphere', 'plane', 'terrain', 'cylinder', 'light', 'group', 'model'].includes(String(item.type));
  return typeof item.id === 'string' && typeof item.name === 'string' && validType
    && isVec3(item.position) && isVec3(item.rotation) && isVec3(item.scale)
    && typeof item.color === 'string' && /^#[0-9a-fA-F]{6}$/.test(item.color)
    && typeof item.visible === 'boolean'
    && (item.parentId === undefined || item.parentId === null || typeof item.parentId === 'string')
    && (item.assetId === undefined || item.assetId === null || typeof item.assetId === 'string')
    && (item.roughness === undefined || (typeof item.roughness === 'number' && item.roughness >= 0 && item.roughness <= 1))
    && (item.metalness === undefined || (typeof item.metalness === 'number' && item.metalness >= 0 && item.metalness <= 1))
    && (item.textureAssetId === undefined || item.textureAssetId === null || typeof item.textureAssetId === 'string')
    && (item.materialColor === undefined || (typeof item.materialColor === 'string' && /^#[0-9a-fA-F]{6}$/.test(item.materialColor)))
    && (['normalMapAssetId', 'roughnessMapAssetId', 'metalnessMapAssetId', 'aoMapAssetId'].every((key) => item[key] === undefined || item[key] === null || typeof item[key] === 'string'))
    && (['terrainAmplitude', 'terrainFrequency', 'terrainSeed'].every((key) => item[key] === undefined || (typeof item[key] === 'number' && Number.isFinite(item[key]))))
    && (item.lightType === undefined || item.lightType === 'point' || item.lightType === 'spot')
    && (item.lightIntensity === undefined || (typeof item.lightIntensity === 'number' && Number.isFinite(item.lightIntensity) && item.lightIntensity >= 0 && item.lightIntensity <= 500))
    && (item.lightDistance === undefined || (typeof item.lightDistance === 'number' && Number.isFinite(item.lightDistance) && item.lightDistance >= 0 && item.lightDistance <= 500))
    && (item.lightAngle === undefined || (typeof item.lightAngle === 'number' && Number.isFinite(item.lightAngle) && item.lightAngle >= 5 && item.lightAngle <= 85));
}

export function isSceneDocument(value: unknown): value is SceneDocument {
  if (!value || typeof value !== 'object') return false;
  const doc = value as Record<string, unknown>;
  return doc.format === 'rage-scene' && doc.version === 1 && typeof doc.name === 'string'
    && Array.isArray(doc.objects) && doc.objects.every(isSceneObject)
    && new Set(doc.objects.map((item) => (item as SceneObject).id)).size === doc.objects.length
    && (doc.assets === undefined || (Array.isArray(doc.assets) && doc.assets.every(isProjectAsset)));
}

export function isProjectAsset(value: unknown): value is ProjectAsset {
  if (!value || typeof value !== 'object') return false;
  const item = value as Record<string, unknown>;
  return typeof item.id === 'string' && typeof item.name === 'string'
    && ['model', 'texture', 'other'].includes(String(item.kind))
    && typeof item.mimeType === 'string' && typeof item.dataUrl === 'string' && typeof item.size === 'number'
    && (item.folder === undefined || typeof item.folder === 'string');
}

export function isRageProject(value: unknown): value is RageProject {
  if (!value || typeof value !== 'object') return false;
  const project = value as Record<string, unknown>;
  if (project.format !== 'rage-project' || project.version !== 1 || typeof project.id !== 'string'
    || typeof project.name !== 'string' || typeof project.createdAt !== 'string' || typeof project.updatedAt !== 'string'
    || typeof project.activeSceneId !== 'string' || !Array.isArray(project.scenes) || !Array.isArray(project.assets)) return false;
  if (!project.scenes.every(isSceneDocument) || project.scenes.length === 0) return false;
  if (new Set(project.scenes.map((scene) => (scene as SceneDocument).id)).size !== project.scenes.length) return false;
  if (!project.assets.every(isProjectAsset)) return false;
  if (new Set(project.assets.map((asset) => (asset as ProjectAsset).id)).size !== project.assets.length) return false;
  const settings = project.exportSettings as Record<string, unknown> | undefined;
  return !!settings && settings.target === 'web' && typeof settings.startSceneId === 'string';
}

export function normalizeScene(scene: SceneDocument): SceneDocument {
  const groupIds = new Set(scene.objects.filter((object) => object.type === 'group').map((object) => object.id));
  const rawParents = new Map(scene.objects.map((object) => [object.id, object.parentId ?? null]));
  const hasParentCycle = (objectId: string, candidateParent: string): boolean => {
    const visited = new Set<string>([objectId]);
    let current: string | null = candidateParent;
    while (current) {
      if (visited.has(current)) return true;
      visited.add(current);
      const next = rawParents.get(current);
      current = next && groupIds.has(next) ? next : null;
    }
    return false;
  };
  return {
    ...scene,
    id: scene.id || createId('scene'),
    objects: scene.objects.map((object) => ({
      ...object,
      parentId: object.parentId && groupIds.has(object.parentId) && !hasParentCycle(object.id, object.parentId) ? object.parentId : null
    }))
  };
}

export function normalizeProject(project: RageProject): RageProject {
  const scenes = project.scenes.map(normalizeScene);
  const activeSceneId = scenes.some((scene) => scene.id === project.activeSceneId) ? project.activeSceneId : scenes[0].id!;
  const startSceneId = scenes.some((scene) => scene.id === project.exportSettings?.startSceneId)
    ? project.exportSettings.startSceneId : scenes[0].id!;
  const rawRender = project.renderSettings;
  const renderSettings: RenderSettings = {
    quality: rawRender?.quality === 'performance' || rawRender?.quality === 'high' ? rawRender.quality : 'balanced',
    environment: rawRender?.environment === 'studio' || rawRender?.environment === 'sunset' || rawRender?.environment === 'night' ? rawRender.environment : 'daylight',
    exposure: typeof rawRender?.exposure === 'number' && Number.isFinite(rawRender.exposure) ? Math.min(2, Math.max(0.5, rawRender.exposure)) : 1.15,
    shadows: typeof rawRender?.shadows === 'boolean' ? rawRender.shadows : true,
    timeOfDay: typeof rawRender?.timeOfDay === 'number' && Number.isFinite(rawRender.timeOfDay) ? Math.min(24, Math.max(0, rawRender.timeOfDay)) : 14,
    clouds: rawRender?.clouds !== false,
    cloudCoverage: typeof rawRender?.cloudCoverage === 'number' ? Math.min(1, Math.max(0, rawRender.cloudCoverage)) : 0.56,
    cloudDensity: typeof rawRender?.cloudDensity === 'number' ? Math.min(2, Math.max(0, rawRender.cloudDensity)) : 0.82,
    windX: typeof rawRender?.windX === 'number' ? Math.min(2, Math.max(-2, rawRender.windX)) : 0.65,
    windZ: typeof rawRender?.windZ === 'number' ? Math.min(2, Math.max(-2, rawRender.windZ)) : 0.22,
    weather: ['clear', 'partly-cloudy', 'overcast', 'storm', 'fog'].includes(String(rawRender?.weather)) ? rawRender?.weather : 'partly-cloudy'
  };
  const folders = Array.isArray(project.assetFolders) ? project.assetFolders.filter((folder): folder is string => typeof folder === 'string' && !!folder.trim()) : [];
  return { ...project, scenes, activeSceneId, assetFolders: [...new Set([...folders, ...project.assets.map((asset) => asset.folder).filter((folder): folder is string => !!folder)])], renderSettings, exportSettings: { target: 'web', startSceneId } };
}
