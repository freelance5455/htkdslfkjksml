import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import AppErrorBoundary from './ErrorBoundary';

const root = document.getElementById('root');
if (!root) throw new Error('Elemento #root não encontrado no index.html');

createRoot(root).render(
  <React.StrictMode>
    <AppErrorBoundary>
      <App mobile />
    </AppErrorBoundary>
  </React.StrictMode>
);
