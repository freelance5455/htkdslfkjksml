import { createId, type ProjectAsset } from './model';

function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => typeof reader.result === 'string' ? resolve(reader.result) : reject(new Error(`Falha ao ler ${file.name}`));
    reader.onerror = () => reject(reader.error ?? new Error(`Falha ao ler ${file.name}`));
    reader.readAsDataURL(file);
  });
}

function normalizePath(path: string): string {
  return decodeURIComponent(path).replace(/\\/g, '/').replace(/^\.\//, '').toLowerCase();
}

export async function importProjectAssets(files: File[]): Promise<{ assets: ProjectAsset[]; models: ProjectAsset[]; textures: ProjectAsset[] }> {
  const fileMap = new Map<string, File>();
  for (const file of files) {
    fileMap.set(normalizePath(file.name), file);
    const relative = (file as File & { webkitRelativePath?: string }).webkitRelativePath;
    if (relative) fileMap.set(normalizePath(relative), file);
  }

  const newAssets: ProjectAsset[] = [];
  const models: ProjectAsset[] = [];
  const textures: ProjectAsset[] = [];

  for (const file of files) {
    const extension = file.name.split('.').pop()?.toLowerCase() ?? '';
    if (extension === 'glb' || extension === 'gltf') {
      let dataUrl = await fileToDataUrl(file);
      const mimeType = extension === 'glb' ? 'model/gltf-binary' : 'model/gltf+json';
      if (extension === 'gltf') {
        const json = JSON.parse(await file.text()) as {
          buffers?: Array<{ uri?: string }>;
          images?: Array<{ uri?: string }>;
        };
        const dependencies = [...(json.buffers ?? []), ...(json.images ?? [])];
        for (const dependency of dependencies) {
          const uri = dependency.uri;
          if (!uri || /^(data:|https?:|blob:)/i.test(uri)) continue;
          const normalized = normalizePath(uri.split(/[?#]/)[0]);
          const baseName = normalized.split('/').pop() ?? normalized;
          const baseDirectory = normalizePath(file.name.includes('/') ? file.name.slice(0, file.name.lastIndexOf('/') + 1) : '');
          const candidate = fileMap.get(normalized) ?? fileMap.get(normalizePath(`${baseDirectory}${normalized}`)) ?? fileMap.get(baseName);
          if (!candidate) throw new Error(`O arquivo dependente "${uri}" não foi selecionado junto com ${file.name}. Selecione o .gltf e seus arquivos .bin/texturas juntos.`);
          dependency.uri = await fileToDataUrl(candidate);
        }
        const rewritten = JSON.stringify(json);
        dataUrl = `data:application/json;base64,${btoa(unescape(encodeURIComponent(rewritten)))}`;
      }
      const asset: ProjectAsset = { id: createId('asset'), name: file.name, folder: 'Models', kind: 'model', mimeType, dataUrl, size: file.size };
      newAssets.push(asset);
      models.push(asset);
    } else if (['png', 'jpg', 'jpeg', 'webp', 'avif'].includes(extension)) {
      const asset: ProjectAsset = { id: createId('asset'), name: file.name, folder: 'Textures', kind: 'texture', mimeType: file.type || 'application/octet-stream', dataUrl: await fileToDataUrl(file), size: file.size };
      newAssets.push(asset);
      textures.push(asset);
    } else if (extension !== 'bin') {
      const asset: ProjectAsset = { id: createId('asset'), name: file.name, folder: 'Other', kind: 'other', mimeType: file.type || 'application/octet-stream', dataUrl: await fileToDataUrl(file), size: file.size };
      newAssets.push(asset);
    }
  }
  return { assets: newAssets, models, textures };
}

export function formatBytes(size: number): string {
  if (size < 1024) return `${size} B`;
  if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} KB`;
  return `${(size / (1024 * 1024)).toFixed(1)} MB`;
}
