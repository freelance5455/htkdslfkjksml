import * as THREE from 'three';
import type { RenderSettings } from './model';

const SKY_VERTEX = /* glsl */`
  varying vec3 vWorldPosition;
  void main() {
    vec4 worldPosition = modelMatrix * vec4(position, 1.0);
    vWorldPosition = worldPosition.xyz;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`;

const SKY_FRAGMENT = /* glsl */`
  precision highp float;
  uniform vec3 uCameraPosition;
  uniform vec3 uSunDirection;
  uniform vec3 uSunColor;
  uniform vec3 uSkyTop;
  uniform vec3 uSkyHorizon;
  uniform vec3 uCloudTint;
  uniform float uTime;
  uniform float uCoverage;
  uniform float uDensity;
  uniform float uWindX;
  uniform float uWindZ;
  uniform float uCloudBase;
  uniform float uCloudTop;
  uniform float uStorm;
  uniform int uSteps;
  varying vec3 vWorldPosition;

  float hash31(vec3 p) {
    p = fract(p * 0.1031);
    p += dot(p, p.yzx + 33.33);
    return fract((p.x + p.y) * p.z);
  }

  float noise3(vec3 x) {
    vec3 i = floor(x);
    vec3 f = fract(x);
    f = f * f * (3.0 - 2.0 * f);
    float n000 = hash31(i + vec3(0.0, 0.0, 0.0));
    float n100 = hash31(i + vec3(1.0, 0.0, 0.0));
    float n010 = hash31(i + vec3(0.0, 1.0, 0.0));
    float n110 = hash31(i + vec3(1.0, 1.0, 0.0));
    float n001 = hash31(i + vec3(0.0, 0.0, 1.0));
    float n101 = hash31(i + vec3(1.0, 0.0, 1.0));
    float n011 = hash31(i + vec3(0.0, 1.0, 1.0));
    float n111 = hash31(i + vec3(1.0, 1.0, 1.0));
    float x00 = mix(n000, n100, f.x);
    float x10 = mix(n010, n110, f.x);
    float x01 = mix(n001, n101, f.x);
    float x11 = mix(n011, n111, f.x);
    return mix(mix(x00, x10, f.y), mix(x01, x11, f.y), f.z);
  }

  float fbm(vec3 p) {
    float value = 0.0;
    float amplitude = 0.5;
    for (int octave = 0; octave < 3; octave++) {
      value += noise3(p) * amplitude;
      p *= 2.03;
      amplitude *= 0.5;
    }
    return value;
  }

  float cloudDensity(vec3 p) {
    float h = clamp((p.y - uCloudBase) / max(0.001, uCloudTop - uCloudBase), 0.0, 1.0);
    float verticalProfile = smoothstep(0.015, 0.18, h) * (1.0 - smoothstep(0.72, 1.0, h));
    vec3 q = p * vec3(0.030, 0.052, 0.030);
    vec2 wind = vec2(uWindX, uWindZ);
    q.xz += wind * uTime * 0.72;
    float warp = noise3(q * 0.58 + vec3(0.0, uTime * 0.009, 0.0));
    q.x += (warp - 0.5) * 2.4;
    q.z += (noise3(q * 0.61 + vec3(13.7, 4.2, -8.1)) - 0.5) * 2.4;
    float broad = fbm(q);
    float detail = noise3(q * 2.65 + vec3(5.2, uTime * 0.018, 9.1));
    float threshold = mix(0.70, 0.38, clamp(uCoverage, 0.0, 1.0));
    float shape = smoothstep(threshold, threshold + 0.22, broad + detail * 0.17 - 0.035);
    float stormBuild = mix(1.0, 1.24, uStorm);
    return clamp(shape * verticalProfile * stormBuild, 0.0, 1.0);
  }

  void main() {
    vec3 rayDir = normalize(vWorldPosition - uCameraPosition);
    float elevation = clamp(rayDir.y * 0.5 + 0.5, 0.0, 1.0);
    vec3 sky = mix(uSkyHorizon, uSkyTop, pow(elevation, 0.72));
    float sunDot = max(dot(rayDir, normalize(uSunDirection)), 0.0);
    float sunHalo = pow(sunDot, 12.0) * 0.10 + pow(sunDot, 180.0) * 0.65;
    sky += uSunColor * sunHalo;

    vec3 cloudLight = uCloudTint;
    float sunHeight = clamp(uSunDirection.y * 0.5 + 0.5, 0.0, 1.0);
    cloudLight *= mix(0.48, 1.13, sunHeight);
    cloudLight = mix(cloudLight, vec3(0.34, 0.39, 0.48), uStorm * 0.62);

    if (rayDir.y > 0.012 && uCoverage > 0.015 && uDensity > 0.015) {
      float nearT = (uCloudBase - uCameraPosition.y) / rayDir.y;
      float farT = (uCloudTop - uCameraPosition.y) / rayDir.y;
      float startT = max(0.0, nearT);
      float endT = min(farT, 520.0);
      if (endT > startT) {
        float stepLength = (endT - startT) / float(uSteps);
        float transmittance = 1.0;
        vec3 cloudAccum = vec3(0.0);
        for (int i = 0; i < 32; i++) {
          if (i >= uSteps) break;
          float t = startT + (float(i) + 0.5) * stepLength;
          vec3 samplePosition = uCameraPosition + rayDir * t;
          float d = cloudDensity(samplePosition);
          if (d > 0.008) {
            float opticalDepth = d * uDensity * stepLength * 0.028;
            float sampleAlpha = 1.0 - exp(-opticalDepth);
            float heightShade = smoothstep(uCloudBase, uCloudBase + 12.0, samplePosition.y);
            float internalShade = exp(-d * 0.65 - (1.0 - sunHeight) * 0.72);
            float silverEdge = pow(max(dot(rayDir, normalize(uSunDirection)), 0.0), 5.0) * 0.16;
            vec3 litCloud = cloudLight * (0.62 + 0.38 * heightShade) * (0.55 + 0.45 * internalShade);
            litCloud += uSunColor * silverEdge * (1.0 - d * 0.35);
            cloudAccum += transmittance * sampleAlpha * litCloud;
            transmittance *= (1.0 - sampleAlpha);
            if (transmittance < 0.025) break;
          }
        }
        sky = sky * transmittance + cloudAccum;
      }
    }

    gl_FragColor = vec4(sky, 1.0);
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
  }
`;

export function createAtmosphereDome(): THREE.Mesh {
  const material = new THREE.ShaderMaterial({
    uniforms: {
      uCameraPosition: { value: new THREE.Vector3() },
      uSunDirection: { value: new THREE.Vector3(0.2, 0.8, 0.3) },
      uSunColor: { value: new THREE.Color('#fff0d4') },
      uSkyTop: { value: new THREE.Color('#3678b4') },
      uSkyHorizon: { value: new THREE.Color('#a8c9db') },
      uCloudTint: { value: new THREE.Color('#f1f3f2') },
      uTime: { value: 0 },
      uCoverage: { value: 0.58 },
      uDensity: { value: 0.82 },
      uWindX: { value: 0.65 },
      uWindZ: { value: 0.22 },
      uCloudBase: { value: 14 },
      uCloudTop: { value: 38 },
      uStorm: { value: 0 },
      uSteps: { value: 18 }
    },
    vertexShader: SKY_VERTEX,
    fragmentShader: SKY_FRAGMENT,
    side: THREE.BackSide,
    depthWrite: false,
    depthTest: false,
    toneMapped: true
  });
  const dome = new THREE.Mesh(new THREE.SphereGeometry(1, 32, 24), material);
  dome.frustumCulled = false;
  dome.renderOrder = -1000;
  dome.scale.setScalar(500);
  dome.name = 'RAGE Dynamic Atmosphere';
  return dome;
}

export function updateAtmosphereUniforms(
  dome: THREE.Mesh,
  settings: RenderSettings,
  sunDirection: THREE.Vector3,
  cameraPosition: THREE.Vector3,
  elapsedSeconds: number
) {
  const material = dome.material as THREE.ShaderMaterial;
  const u = material.uniforms;
  const qualitySteps = settings.quality === 'high' ? 24 : settings.quality === 'performance' ? 10 : 16;
  const weather = settings.weather ?? 'partly-cloudy';
  const storm = weather === 'storm' ? 1 : weather === 'overcast' ? 0.58 : weather === 'fog' ? 0.28 : 0;
  const defaultCoverage = weather === 'clear' ? 0.16 : weather === 'overcast' ? 0.84 : weather === 'storm' ? 0.96 : weather === 'fog' ? 0.7 : 0.56;
  const coverage = settings.cloudCoverage ?? defaultCoverage;
  const density = (settings.cloudDensity ?? 0.82) * (weather === 'storm' ? 1.22 : 1);
  const environment = settings.environment;
  const hour = settings.timeOfDay ?? 14;
  const day = Math.max(0, Math.sin(((hour - 6) / 12) * Math.PI));
  const dawnDusk = Math.max(0, 1 - Math.min(Math.abs(hour - 6), Math.abs(hour - 18)) / 3);
  const palettes = {
    studio: { top: '#536474', horizon: '#aab3b9' },
    daylight: { top: day > 0.05 ? '#347ab9' : '#172a46', horizon: day > 0.05 ? '#b4d4e4' : '#56647c' },
    sunset: { top: '#543e58', horizon: '#efa16f' },
    night: { top: '#091329', horizon: '#263b5c' }
  } as const;
  const palette = palettes[environment];
  const top = new THREE.Color(palette.top);
  const horizon = new THREE.Color(palette.horizon);
  const sunsetTint = new THREE.Color('#ffad7a');
  top.lerp(new THREE.Color('#16253e'), storm * 0.58);
  horizon.lerp(new THREE.Color('#68717d'), storm * 0.55);
  if (environment === 'daylight') {
    top.lerp(sunsetTint, dawnDusk * 0.48);
    horizon.lerp(sunsetTint, dawnDusk * 0.48);
  }
  const sunColor = new THREE.Color(environment === 'night' ? '#91aee8' : '#fff0d6').lerp(sunsetTint, dawnDusk * 0.82);
  const cloudTint = new THREE.Color('#f5f6f4').lerp(new THREE.Color('#858d9a'), storm * 0.62);
  u.uCameraPosition.value.copy(cameraPosition);
  u.uSunDirection.value.copy(sunDirection).normalize();
  u.uSunColor.value.copy(sunColor);
  u.uSkyTop.value.copy(top);
  u.uSkyHorizon.value.copy(horizon);
  u.uCloudTint.value.copy(cloudTint);
  u.uTime.value = elapsedSeconds;
  u.uCoverage.value = settings.clouds === false ? 0 : coverage;
  u.uDensity.value = density;
  u.uWindX.value = settings.windX ?? 0.65;
  u.uWindZ.value = settings.windZ ?? 0.22;
  u.uCloudBase.value = weather === 'storm' ? 10 : weather === 'fog' ? 5 : 14;
  u.uCloudTop.value = weather === 'storm' ? 46 : weather === 'fog' ? 15 : 38;
  u.uStorm.value = storm;
  u.uSteps.value = qualitySteps;
}

function envHash(x: number, y: number) {
  const value = Math.sin(x * 127.1 + y * 311.7) * 43758.5453;
  return value - Math.floor(value);
}

export function createReflectionEnvironment(settings: RenderSettings): THREE.DataTexture {
  const width = 256;
  const height = 128;
  const pixels = new Uint8Array(width * height * 4);
  const hour = settings.timeOfDay ?? 14;
  const weather = settings.weather ?? 'partly-cloudy';
  const storm = weather === 'storm' ? 0.62 : weather === 'overcast' ? 0.45 : weather === 'fog' ? 0.34 : 0;
  const sunU = ((hour / 24) + 0.25) % 1;
  const daylight = Math.max(0, Math.sin(((hour - 6) / 12) * Math.PI));
  for (let y = 0; y < height; y++) {
    const v = y / (height - 1);
    const elevation = (0.5 - v) * Math.PI;
    const skyFactor = Math.max(0, Math.sin(elevation));
    for (let x = 0; x < width; x++) {
      const u = x / width;
      const horizonFactor = Math.pow(1 - skyFactor, 2.4);
      let r = 0.10 + 0.20 * skyFactor + 0.28 * horizonFactor;
      let g = 0.19 + 0.34 * skyFactor + 0.22 * horizonFactor;
      let b = 0.34 + 0.42 * skyFactor + 0.12 * horizonFactor;
      if (v > 0.51) {
        const ground = (v - 0.51) / 0.49;
        r = 0.10 - ground * 0.055;
        g = 0.12 - ground * 0.065;
        b = 0.13 - ground * 0.07;
      }
      const cloudNoise = envHash(Math.floor(u * 46), Math.floor(v * 16));
      const cloudBand = v > 0.22 && v < 0.52 ? Math.max(0, (cloudNoise - (0.72 - (settings.cloudCoverage ?? 0.56) * 0.2)) * 2.4) : 0;
      const cloudShade = cloudBand * (1 - storm * 0.46);
      r = r * (1 - cloudShade * 0.48) + cloudShade * 0.82;
      g = g * (1 - cloudShade * 0.48) + cloudShade * 0.86;
      b = b * (1 - cloudShade * 0.48) + cloudShade * 0.91;
      const dx = Math.min(Math.abs(u - sunU), 1 - Math.abs(u - sunU));
      const sunV = 0.5 - Math.sin(((hour - 6) / 12) * Math.PI) * 0.33;
      const sunDistance = Math.sqrt(dx * dx + Math.pow(v - sunV, 2));
      const sun = Math.exp(-sunDistance * 95) * daylight * (1 - storm * 0.65);
      r += sun * 0.85; g += sun * 0.72; b += sun * 0.48;
      const idx = (y * width + x) * 4;
      pixels[idx] = Math.round(THREE.MathUtils.clamp(r, 0, 1) * 255);
      pixels[idx + 1] = Math.round(THREE.MathUtils.clamp(g, 0, 1) * 255);
      pixels[idx + 2] = Math.round(THREE.MathUtils.clamp(b, 0, 1) * 255);
      pixels[idx + 3] = 255;
    }
  }
  const texture = new THREE.DataTexture(pixels, width, height, THREE.RGBAFormat);
  texture.mapping = THREE.EquirectangularReflectionMapping;
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.magFilter = THREE.LinearFilter;
  texture.minFilter = THREE.LinearMipmapLinearFilter;
  texture.generateMipmaps = true;
  texture.needsUpdate = true;
  texture.name = 'RAGE Procedural Sky Reflection';
  return texture;
}
