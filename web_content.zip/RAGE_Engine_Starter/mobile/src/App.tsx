import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import {
  Box, Circle, Cylinder, Eye, EyeOff, FilePlus2, Folder, FolderOpen, Grid3X3,
  Image, Lightbulb, PackageOpen, Play, Plus, Save, Search, Settings2, Square, SlidersHorizontal, FolderPlus, FolderInput,
  Trash2, Upload, X, Cuboid, Layers3, ChevronRight, FileCode2, Download
} from 'lucide-react';
import SceneView from './SceneView';
import {
  createProject, createScene, isRageProject, isSceneDocument,
  makeObject, normalizeProject, normalizeScene,
  type ObjectKind, type ProjectAsset, type RageProject, type SceneObject, type SceneDocument, type Vec3
} from './model';
import { importProjectAssets, formatBytes } from './assetImport';
import { listLocalProjects, loadLastProject, saveProjectLocal } from './ProjectStore';
import { exportLocalFile } from './platformFiles';
import './style.css';

type Props = { mobile?: boolean };
type Drawer = 'project' | 'create' | 'hierarchy' | 'inspector';
type ProjectDialog = 'new' | 'library' | null;

function safeFileName(value: string): string {
  return value.trim().replace(/[^a-z0-9-_]+/gi, '-').replace(/^-+|-+$/g, '').toLowerCase() || 'rage-project';
}

export default function App({ mobile = false }: Props) {
  const [project, setProject] = useState<RageProject>(() => createProject());
  const [ready, setReady] = useState(false);
  const [localProjects, setLocalProjects] = useState<RageProject[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>('starter-cube');
  const [tool, setTool] = useState('select');
  const [grid, setGrid] = useState(true);
  const [playing, setPlaying] = useState(false);
  const [drawer, setDrawer] = useState<Drawer>('project');
  const [dialog, setDialog] = useState<ProjectDialog>(null);
  const [projectName, setProjectName] = useState('Meu Projeto');
  const [search, setSearch] = useState('');
  const [assetSearch, setAssetSearch] = useState('');
  const [assetFolder, setAssetFolder] = useState('');
  const [notice, setNotice] = useState('');
  const projectFileRef = useRef<HTMLInputElement>(null);
  const assetFileRef = useRef<HTMLInputElement>(null);

  const activeScene = project.scenes.find((scene) => scene.id === project.activeSceneId) ?? project.scenes[0];
  const objects = activeScene?.objects ?? [];
  const assets = project.assets;
  const selected = objects.find((object) => object.id === selectedId) ?? null;
  const filtered = useMemo(() => objects.filter((object) => object.name.toLowerCase().includes(search.toLowerCase())), [objects, search]);
  const assetById = (id?: string | null) => assets.find((asset) => asset.id === id);
  const assetFolders = useMemo(() => [...new Set([...(project.assetFolders ?? []), ...assets.map((asset) => asset.folder || 'Unsorted')])].sort(), [assets, project.assetFolders]);
  const visibleAssets = useMemo(() => assets.filter((asset) => (!assetFolder || (asset.folder || 'Unsorted') === assetFolder) && asset.name.toLowerCase().includes(assetSearch.toLowerCase())), [assets, assetFolder, assetSearch]);

  useEffect(() => {
    let cancelled = false;
    loadLastProject().then((stored) => {
      if (cancelled) return;
      if (stored && isRageProject(stored)) {
        const restored = normalizeProject(stored);
        setProject(restored);
        const currentScene = restored.scenes.find((scene) => scene.id === restored.activeSceneId);
        setSelectedId(currentScene?.objects.find((object) => object.type !== 'group')?.id ?? currentScene?.objects[0]?.id ?? null);
      }
      setReady(true);
    }).catch((error) => {
      console.warn('Não foi possível restaurar o último projeto:', error);
      if (!cancelled) setReady(true);
    });
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    if (!notice) return;
    const timer = window.setTimeout(() => setNotice(''), 4500);
    return () => window.clearTimeout(timer);
  }, [notice]);

  useEffect(() => {
    if (!ready) return;
    const timer = window.setTimeout(() => {
      const next = { ...project, updatedAt: new Date().toISOString() };
      saveProjectLocal(next).catch((error) => {
        console.warn('Falha ao salvar o projeto localmente:', error);
        setNotice('Não foi possível salvar localmente. Exporte o projeto para não perder alterações.');
      });
    }, 550);
    return () => window.clearTimeout(timer);
  }, [project, ready]);

  const updateObjects = (updater: (current: SceneObject[]) => SceneObject[]) => {
    if (!activeScene) return;
    setProject((current) => ({
      ...current,
      updatedAt: new Date().toISOString(),
      scenes: current.scenes.map((scene) => scene.id === current.activeSceneId ? { ...scene, objects: updater(scene.objects) } : scene)
    }));
  };

  const updateSelected = (patch: Partial<SceneObject>) => {
    if (!selectedId) return;
    updateObjects((current) => current.map((object) => object.id === selectedId ? { ...object, ...patch } : object));
  };

  const add = (kind: ObjectKind, assetId?: string) => {
    const item = makeObject(kind, objects.length + 1, assetId);
    if (kind === 'model') item.position = [Math.max(0, objects.filter((object) => object.type === 'model').length) * 1.5, 0.5, 0];
    updateObjects((current) => [...current, item]);
    setSelectedId(item.id);
    setNotice(`${item.name} adicionado`);
    setDrawer('inspector');
  };

  const addGroup = () => add('group');

  const patchVector = (key: 'position' | 'rotation' | 'scale', axis: number, value: string) => {
    const number = Number(value);
    if (!Number.isFinite(number) || !selectedId) return;
    updateObjects((current) => current.map((object) => object.id === selectedId
      ? { ...object, [key]: object[key].map((component, index) => index === axis ? number : component) as Vec3 }
      : object));
  };

  const remove = () => {
    if (!selectedId) return;
    const toRemove = new Set<string>([selectedId]);
    let found = true;
    while (found) {
      found = false;
      for (const object of objects) {
        if (object.parentId && toRemove.has(object.parentId) && !toRemove.has(object.id)) {
          toRemove.add(object.id);
          found = true;
        }
      }
    }
    updateObjects((current) => current.filter((object) => !toRemove.has(object.id)));
    setSelectedId(null);
  };

  const descendantsOf = (id: string): Set<string> => {
    const result = new Set<string>();
    let changed = true;
    while (changed) {
      changed = false;
      for (const object of objects) {
        if (object.parentId === id || (object.parentId && result.has(object.parentId))) {
          if (!result.has(object.id)) { result.add(object.id); changed = true; }
        }
      }
    }
    return result;
  };

  const setParent = (parentId: string) => {
    if (!selected) return;
    if (parentId === selected.id || (parentId && descendantsOf(selected.id).has(parentId))) return;
    updateSelected({ parentId: parentId || null });
  };

  const switchScene = (sceneId: string) => {
    setProject((current) => ({ ...current, activeSceneId: sceneId, updatedAt: new Date().toISOString() }));
    const scene = project.scenes.find((item) => item.id === sceneId);
    setSelectedId(scene?.objects.find((object) => object.type !== 'group')?.id ?? scene?.objects[0]?.id ?? null);
    setSearch('');
  };

  const createNewScene = () => {
    const scene = createScene(`Cena ${project.scenes.length + 1}`);
    setProject((current) => ({ ...current, scenes: [...current.scenes, scene], activeSceneId: scene.id!, updatedAt: new Date().toISOString() }));
    setSelectedId(null);
    setNotice('Nova cena criada');
  };

  const renameScene = (scene: SceneDocument) => {
    const nextName = window.prompt('Nome da cena:', scene.name);
    if (!nextName?.trim()) return;
    setProject((current) => ({ ...current, scenes: current.scenes.map((item) => item.id === scene.id ? { ...item, name: nextName.trim() } : item) }));
  };

  const deleteScene = (scene: SceneDocument) => {
    if (project.scenes.length <= 1) { setNotice('O projeto precisa ter pelo menos uma cena.'); return; }
    if (!window.confirm(`Excluir a cena "${scene.name}"?`)) return;
    const remaining = project.scenes.filter((item) => item.id !== scene.id);
    const nextActive = scene.id === project.activeSceneId ? remaining[0] : activeScene;
    setProject((current) => ({
      ...current, scenes: remaining, activeSceneId: nextActive?.id ?? remaining[0].id!,
      exportSettings: { ...current.exportSettings, startSceneId: current.exportSettings.startSceneId === scene.id ? remaining[0].id! : current.exportSettings.startSceneId }
    }));
    setSelectedId(null);
  };

  const startNewProject = () => {
    const next = createProject(projectName.trim() || 'Meu Projeto');
    setProject(next);
    setSelectedId('starter-cube');
    setDialog(null);
    setDrawer('project');
    setNotice(`Projeto "${next.name}" criado`);
  };

  const openProjectLibrary = async () => {
    try { setLocalProjects(await listLocalProjects()); }
    catch (error) { console.error(error); setLocalProjects([]); }
    setDialog('library');
  };

  const openLocalProject = (item: RageProject) => {
    const next = normalizeProject(item);
    setProject(next);
    const scene = next.scenes.find((entry) => entry.id === next.activeSceneId);
    setSelectedId(scene?.objects.find((object) => object.type !== 'group')?.id ?? scene?.objects[0]?.id ?? null);
    setDialog(null);
    setNotice(`Projeto "${next.name}" aberto`);
  };

  const exportProject = async () => {
    try {
      const content = JSON.stringify({ ...project, updatedAt: new Date().toISOString() }, null, 2);
      await saveProjectLocal({ ...project, updatedAt: new Date().toISOString() });
      await exportLocalFile(content, `${safeFileName(project.name)}.rageproj`);
      setNotice('Projeto salvo e exportado (.rageproj)');
    } catch (error) {
      console.error('Falha ao exportar projeto:', error);
      setNotice('Falha ao exportar projeto');
    }
  };

  const exportBuildManifest = async () => {
    const manifest = {
      format: 'rage-build-manifest', version: 1, engine: 'RAGE Engine', projectId: project.id,
      projectName: project.name, target: project.exportSettings.target, startSceneId: project.exportSettings.startSceneId,
      renderSettings: project.renderSettings, assetFolders: project.assetFolders ?? [],
      scenes: project.scenes.map((scene) => ({ id: scene.id, name: scene.name, path: `scenes/${scene.id}-${safeFileName(scene.name)}.ragescene`, objectCount: scene.objects.length })),
      assets: project.assets.map((asset) => ({ id: asset.id, name: asset.name, kind: asset.kind, folder: asset.folder ?? 'Unsorted', mimeType: asset.mimeType, path: `assets/${asset.id}-${safeFileName(asset.name)}` })),
      plannedLayout: ['project.rageproj', 'scenes/', 'assets/', 'runtime/', 'build/'],
      note: 'Manifesto de preparação. O empacotador/runtime de jogo ainda não está implementado.'
    };
    await exportLocalFile(JSON.stringify(manifest, null, 2), `${safeFileName(project.name)}.ragebuild.json`);
    setNotice('Manifesto de build exportado');
  };

  const exportScene = async () => {
    if (!activeScene) return;
    const requiredAssetIds = new Set(activeScene.objects.flatMap((object) => [object.assetId, object.textureAssetId, object.normalMapAssetId, object.roughnessMapAssetId, object.metalnessMapAssetId, object.aoMapAssetId]).filter((id): id is string => !!id));
    const standaloneAssets = project.assets.filter((asset) => requiredAssetIds.has(asset.id));
    const content = JSON.stringify({ ...activeScene, assets: standaloneAssets, format: 'rage-scene', version: 1 }, null, 2);
    await exportLocalFile(content, `${safeFileName(activeScene.name)}.ragescene`);
    setNotice('Cena exportada');
  };

  const importProjectOrScene = async (file?: File) => {
    if (!file) return;
    try {
      const parsed: unknown = JSON.parse(await file.text());
      if (isRageProject(parsed)) {
        const next = normalizeProject(parsed);
        setProject(next);
        const scene = next.scenes.find((item) => item.id === next.activeSceneId);
        setSelectedId(scene?.objects[0]?.id ?? null);
        setNotice(`Projeto "${next.name}" importado`);
      } else if (isSceneDocument(parsed)) {
        const standaloneAssets = parsed.assets ?? [];
        const { assets: _sceneAssets, ...scenePayload } = parsed;
        const scene = normalizeScene(scenePayload);
        setProject((current) => ({ ...current, assets: [...current.assets.filter((asset) => !standaloneAssets.some((entry) => entry.id === asset.id)), ...standaloneAssets], scenes: [...current.scenes, scene], activeSceneId: scene.id!, updatedAt: new Date().toISOString() }));
        setSelectedId(scene.objects[0]?.id ?? null);
        setNotice(`Cena "${scene.name}" adicionada ao projeto`);
      } else {
        throw new Error('O arquivo não corresponde a um projeto ou cena RAGE válida.');
      }
      setDialog(null);
    } catch (error) {
      console.error('Falha ao abrir arquivo RAGE:', error);
      setNotice(error instanceof Error ? error.message : 'Arquivo inválido ou danificado');
    } finally {
      if (projectFileRef.current) projectFileRef.current.value = '';
    }
  };

  const importAssets = async (files: File[]) => {
    if (!files.length) return;
    try {
      const result = await importProjectAssets(files);
      setProject((current) => ({ ...current, assets: [...current.assets, ...result.assets], updatedAt: new Date().toISOString() }));
      if (result.models.length) {
        const created = result.models.map((asset, index) => {
          const object = makeObject('model', objects.length + index + 1, asset.id);
          object.name = asset.name.replace(/\.(glb|gltf)$/i, '');
          object.position = [objects.filter((item) => item.type === 'model').length * 1.5 + index * 1.5, 0.5, 0];
          return object;
        });
        updateObjects((current) => [...current, ...created]);
        setSelectedId(created[created.length - 1].id);
        setDrawer('inspector');
      }
      setNotice(`${result.models.length} modelo(s) e ${result.textures.length} textura(s) importado(s)`);
    } catch (error) {
      console.error('Falha ao importar assets:', error);
      setNotice(error instanceof Error ? error.message : 'Falha ao importar arquivos');
    } finally {
      if (assetFileRef.current) assetFileRef.current.value = '';
    }
  };

  const createAssetFolder = () => {
    const name = window.prompt('Nome da nova pasta:');
    if (!name?.trim()) return;
    const folder = name.trim().replace(/[\\/]+/g, '-');
    setProject((current) => ({ ...current, assetFolders: [...new Set([...(current.assetFolders ?? []), folder])], assets: current.assets.map((asset) => asset.folder ? asset : { ...asset, folder: 'Unsorted' }), updatedAt: new Date().toISOString() }));
    setAssetFolder(folder);
    setNotice(`Pasta \"${folder}\" criada. Importe ou mova assets para ela.`);
  };

  const moveAsset = (asset: ProjectAsset) => {
    const destination = window.prompt(`Mover \"${asset.name}\" para qual pasta?`, asset.folder || 'Unsorted');
    if (!destination?.trim()) return;
    const folder = destination.trim().replace(/[\\/]+/g, '-');
    setProject((current) => ({ ...current, assets: current.assets.map((item) => item.id === asset.id ? { ...item, folder } : item), updatedAt: new Date().toISOString() }));
    setNotice(`Asset movido para ${folder}`);
  };

  const deleteAsset = (asset: ProjectAsset) => {
    if (!window.confirm(`Remover "${asset.name}" do projeto?`)) return;
    setProject((current) => ({
      ...current,
      assets: current.assets.filter((item) => item.id !== asset.id),
      scenes: current.scenes.map((scene) => ({
        ...scene,
        objects: scene.objects
          .filter((object) => !(asset.kind === 'model' && object.type === 'model' && object.assetId === asset.id))
          .map((object) => ({ ...object,
            ...(object.textureAssetId === asset.id ? { textureAssetId: null } : {}),
            ...(object.normalMapAssetId === asset.id ? { normalMapAssetId: null } : {}),
            ...(object.roughnessMapAssetId === asset.id ? { roughnessMapAssetId: null } : {}),
            ...(object.metalnessMapAssetId === asset.id ? { metalnessMapAssetId: null } : {}),
            ...(object.aoMapAssetId === asset.id ? { aoMapAssetId: null } : {})
          }))
      }))
    }));
    setNotice('Asset removido do projeto');
  };

  const toggleVisible = (id: string) => updateObjects((current) => current.map((object) => object.id === id ? { ...object, visible: !object.visible } : object));
  const renderHierarchy = (parentId: string | null = null, depth = 0): ReactNode => {
    const children = objects.filter((object) => (object.parentId ?? null) === parentId);
    return children.filter((object) => filtered.some((entry) => entry.id === object.id) || objects.some((candidate) => candidate.parentId === object.id && filtered.some((entry) => entry.id === candidate.id))).map((object) => (
      <div key={object.id}>
        <div className={`object-line ${object.id === selectedId ? 'chosen' : ''}`} style={{ paddingLeft: `${depth * 13}px` }}>
          <button className="object-select" onClick={() => { setSelectedId(object.id); setDrawer('inspector'); }} title={object.name}>
            <span className="object-dot">{object.type === 'group' ? <Folder/> : object.type === 'light' ? <Lightbulb/> : object.type === 'model' ? <Cuboid/> : <Box/>}</span>
            <span className="object-name">{object.name}</span>
            {object.type === 'group' && <ChevronRight className="tree-chevron"/>}
          </button>
          <button className="visibility" onClick={() => toggleVisible(object.id)} aria-label="Alternar visibilidade">{object.visible ? <Eye/> : <EyeOff/>}</button>
        </div>
        {object.type === 'group' && renderHierarchy(object.id, depth + 1)}
      </div>
    ));
  };

  const createPanel = <div className="create-content">
    <div className="create-hero"><span className="hero-glyph">✦</span><div><b>Construa seu mundo</b><small>Adicione elementos diretamente à cena 3D.</small></div></div>
    <div className="section-label">FORMAS 3D</div>
    <div className="create-grid">
      <button onClick={() => add('cube')}><Box/><b>Cubo</b></button>
      <button onClick={() => add('sphere')}><Circle/><b>Esfera</b></button>
      <button onClick={() => add('cylinder')}><Cylinder/><b>Cilindro</b></button>
      <button onClick={() => add('plane')}><Grid3X3/><b>Plano</b></button>\n      <button onClick={() => add('terrain')}><Layers3/><b>Terreno</b></button>
      <button onClick={() => add('light')}><Lightbulb/><b>Luz pontual</b></button>
      <button onClick={addGroup}><Folder/><b>Grupo</b></button>
    </div>
    <div className="section-label">ARQUIVOS 3D</div>
    <button className="wide-action" onClick={() => assetFileRef.current?.click()}><PackageOpen/> Importar modelos / texturas</button>
    <button className="wide-action" onClick={exportScene}><Download/> Exportar cena (.ragescene)</button>
  </div>;

  const projectPanel = <div className="create-content project-content">
    <div className="project-summary"><div className="project-summary-icon"><FolderOpen/></div><div><b>{project.name}</b><small>{project.scenes.length} cena(s) · {assets.length} asset(s)</small></div></div>
    <div className="section-label">PROJETO</div>
    <button className="wide-action" onClick={() => { setProjectName('Meu Projeto'); setDialog('new'); }}><FilePlus2/> Novo projeto</button>
    <button className="wide-action" onClick={openProjectLibrary}><FolderOpen/> Abrir projeto local</button>
    <button className="wide-action" onClick={() => projectFileRef.current?.click()}><Upload/> Importar projeto / cena</button>
    <button className="wide-action primary-action" onClick={exportProject}><Save/> Salvar / Exportar .rageproj</button>

    <div className="section-label section-row"><span>CENAS</span><button onClick={createNewScene} title="Criar cena"><Plus/></button></div>
    <div className="scene-list">
      {project.scenes.map((scene) => <div className={`scene-entry ${scene.id === activeScene?.id ? 'active' : ''}`} key={scene.id}>
        <button className="scene-entry-main" onClick={() => switchScene(scene.id!)} onDoubleClick={() => renameScene(scene)} title="Toque para abrir · clique duplo para renomear">
          <Layers3/><span>{scene.name}</span>{scene.id === project.exportSettings.startSceneId && <small>START</small>}
        </button>
        <button className="scene-delete" onClick={() => deleteScene(scene)} title="Excluir cena"><X/></button>
      </div>)}
    </div>
    <button className="wide-action" onClick={() => projectFileRef.current?.click()}><Folder/> Importar cena .ragescene</button>

    <div className="section-label section-row"><span>EXPLORADOR DE ARQUIVOS</span><button onClick={createAssetFolder} title="Nova pasta"><FolderPlus/></button></div>
    <button className="wide-action" onClick={() => assetFileRef.current?.click()}><PackageOpen/> Importar modelos / texturas</button>
    <div className="asset-browser">
      <div className="asset-browser-tools"><div className="searchbox"><Search/><input value={assetSearch} onChange={(event) => setAssetSearch(event.target.value)} placeholder="Buscar arquivos..."/></div></div>
      <div className="asset-folder-tabs"><button className={!assetFolder ? 'active' : ''} onClick={() => setAssetFolder('')}>Todos</button>{assetFolders.map((folder) => <button key={folder} className={assetFolder === folder ? 'active' : ''} onClick={() => setAssetFolder(folder)}><Folder/> {folder}</button>)}</div>
      <div className="asset-list">
        {visibleAssets.map((asset) => <div className="asset-entry" key={asset.id}>
          <span className="asset-icon">{asset.kind === 'texture' ? <Image/> : asset.kind === 'model' ? <Cuboid/> : <FileCode2/>}</span>
          <span className="asset-name"><b>{asset.name}</b><small>{asset.folder || 'Unsorted'} · {asset.kind.toUpperCase()} · {formatBytes(asset.size)}</small></span>
          <button className="scene-delete" onClick={() => moveAsset(asset)} title="Mover para pasta"><FolderInput/></button>
          <button className="scene-delete" onClick={() => deleteAsset(asset)} title="Remover asset"><X/></button>
        </div>)}
        {!visibleAssets.length && <p className="empty compact-empty">{assets.length ? 'Nenhum arquivo nesta pasta.' : 'Nenhum asset importado ainda.'}</p>}
      </div>
    </div>

    <div className="section-label section-row"><span>RENDER / REALISMO</span><SlidersHorizontal size={14}/></div>
    <label className="field-label">Qualidade de renderização
      <select value={project.renderSettings?.quality ?? 'balanced'} onChange={(event) => setProject((current) => ({ ...current, renderSettings: { ...(current.renderSettings ?? { quality: 'balanced', environment: 'daylight', exposure: 1.15, shadows: true }), quality: event.target.value as 'performance' | 'balanced' | 'high' } }))}>
        <option value="performance">Desempenho (mobile)</option><option value="balanced">Equilibrado</option><option value="high">Alta qualidade</option>
      </select>
    </label>
    <label className="field-label">Ambiente / iluminação
      <select value={project.renderSettings?.environment ?? 'daylight'} onChange={(event) => setProject((current) => ({ ...current, renderSettings: { ...(current.renderSettings ?? { quality: 'balanced', environment: 'daylight', exposure: 1.15, shadows: true }), environment: event.target.value as 'studio' | 'daylight' | 'sunset' | 'night' } }))}>
        <option value="studio">Estúdio neutro</option><option value="daylight">Dia claro</option><option value="sunset">Pôr do sol</option><option value="night">Noite</option>
      </select>
    </label>
    <label className="field-label">Exposição · {(project.renderSettings?.exposure ?? 1.15).toFixed(2)}
      <input type="range" min="0.5" max="2" step="0.05" value={project.renderSettings?.exposure ?? 1.15} onChange={(event) => setProject((current) => ({ ...current, renderSettings: { ...(current.renderSettings ?? { quality: 'balanced', environment: 'daylight', exposure: 1.15, shadows: true }), exposure: Number(event.target.value) } }))}/>
    </label>
    <label className="check-field"><input type="checkbox" checked={project.renderSettings?.shadows ?? true} onChange={(event) => setProject((current) => ({ ...current, renderSettings: { ...(current.renderSettings ?? { quality: 'balanced', environment: 'daylight', exposure: 1.15, shadows: true }), shadows: event.target.checked } }))}/> Sombras em tempo real</label>
    <div className="section-label section-row"><span>ATMOSFERA DINÂMICA</span></div>
    <label className="check-field"><input type="checkbox" checked={project.renderSettings?.clouds !== false} onChange={(event) => setProject((current) => ({ ...current, renderSettings: { ...(current.renderSettings ?? { quality: 'balanced', environment: 'daylight', exposure: 1.15, shadows: true }), clouds: event.target.checked } }))}/> Nuvens volumétricas</label>
    <label className="field-label">Clima
      <select value={project.renderSettings?.weather ?? 'partly-cloudy'} onChange={(event) => { const weather = event.target.value as 'clear' | 'partly-cloudy' | 'overcast' | 'storm' | 'fog'; const presets = { clear: { cloudCoverage: 0.16, cloudDensity: 0.45, windX: 0.35, windZ: 0.1 }, 'partly-cloudy': { cloudCoverage: 0.56, cloudDensity: 0.82, windX: 0.65, windZ: 0.22 }, overcast: { cloudCoverage: 0.84, cloudDensity: 0.95, windX: 0.8, windZ: 0.35 }, storm: { cloudCoverage: 0.96, cloudDensity: 1.25, windX: 1.45, windZ: 0.9 }, fog: { cloudCoverage: 0.7, cloudDensity: 0.65, windX: 0.2, windZ: 0.08 } }; setProject((current) => ({ ...current, renderSettings: { ...(current.renderSettings ?? { quality: 'balanced', environment: 'daylight', exposure: 1.15, shadows: true }), weather, ...presets[weather] } })); }}>
        <option value="clear">Céu limpo</option><option value="partly-cloudy">Parcialmente nublado</option><option value="overcast">Nublado</option><option value="storm">Tempestade</option><option value="fog">Neblina</option>
      </select>
    </label>
    <label className="field-label">Cobertura de nuvens · {Math.round((project.renderSettings?.cloudCoverage ?? 0.56) * 100)}%
      <input type="range" min="0" max="1" step="0.01" value={project.renderSettings?.cloudCoverage ?? 0.56} onChange={(event) => setProject((current) => ({ ...current, renderSettings: { ...(current.renderSettings ?? { quality: 'balanced', environment: 'daylight', exposure: 1.15, shadows: true }), cloudCoverage: Number(event.target.value) } }))}/>
    </label>
    <label className="field-label">Densidade das nuvens · {(project.renderSettings?.cloudDensity ?? 0.82).toFixed(2)}
      <input type="range" min="0.1" max="1.5" step="0.05" value={project.renderSettings?.cloudDensity ?? 0.82} onChange={(event) => setProject((current) => ({ ...current, renderSettings: { ...(current.renderSettings ?? { quality: 'balanced', environment: 'daylight', exposure: 1.15, shadows: true }), cloudDensity: Number(event.target.value) } }))}/>
    </label>
    <label className="field-label">Vento · eixo X · {(project.renderSettings?.windX ?? 0.65).toFixed(2)}
      <input type="range" min="-2" max="2" step="0.05" value={project.renderSettings?.windX ?? 0.65} onChange={(event) => setProject((current) => ({ ...current, renderSettings: { ...(current.renderSettings ?? { quality: 'balanced', environment: 'daylight', exposure: 1.15, shadows: true }), windX: Number(event.target.value) } }))}/>
    </label>
    <label className="field-label">Vento · eixo Z · {(project.renderSettings?.windZ ?? 0.22).toFixed(2)}
      <input type="range" min="-2" max="2" step="0.05" value={project.renderSettings?.windZ ?? 0.22} onChange={(event) => setProject((current) => ({ ...current, renderSettings: { ...(current.renderSettings ?? { quality: 'balanced', environment: 'daylight', exposure: 1.15, shadows: true }), windZ: Number(event.target.value) } }))}/>
    </label>
    <label className="field-label">Hora do dia · {(project.renderSettings?.timeOfDay ?? 14).toFixed(1)}h
      <input type="range" min="0" max="24" step="0.25" value={project.renderSettings?.timeOfDay ?? 14} onChange={(event) => setProject((current) => ({ ...current, renderSettings: { ...(current.renderSettings ?? { quality: 'balanced', environment: 'daylight', exposure: 1.15, shadows: true, timeOfDay: 14 }), timeOfDay: Number(event.target.value) } }))}/>
    </label>
    <p className="helper-copy">As nuvens são geradas por ruído 3D procedural e ray marching: elas se deformam e se deslocam no vento, com custo ajustado à qualidade escolhida. Clima local por região e chuva ainda são etapas futuras.</p>
    <p className="helper-copy">Sombras locais são limitadas por qualidade para preservar o desempenho. Os reflexos usam iluminação de ambiente procedural (IBL/PBR); não são ray tracing completo de objetos em tempo real.</p>

    <div className="section-label">EXPORTAÇÃO (PREPARAÇÃO)</div>
    <label className="field-label">Cena inicial do jogo
      <select value={project.exportSettings.startSceneId} onChange={(event) => setProject((current) => ({ ...current, exportSettings: { ...current.exportSettings, startSceneId: event.target.value } }))}>
        {project.scenes.map((scene) => <option key={scene.id} value={scene.id}>{scene.name}</option>)}
      </select>
    </label>
    <p className="helper-copy">O projeto já registra a cena inicial e reúne os assets. A geração do executável/runtime será uma etapa posterior.</p>
    <button className="wide-action" onClick={exportBuildManifest}><Download/> Exportar manifesto .ragebuild.json</button>
  </div>;

  const hierarchy = <div className="hierarchy-content">
    <div className="searchbox"><Search/><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Filtrar objetos..."/></div>
    {renderHierarchy()}
    {!filtered.length && <p className="empty">Nenhum objeto encontrado.</p>}
  </div>;

  const inspector = <div className="inspector-content">
    {selected ? <>
      <div className="selected-object-title">
        <span className="object-badge">{selected.type === 'light' ? <Lightbulb/> : selected.type === 'group' ? <Folder/> : selected.type === 'model' ? <Cuboid/> : <Box/>}</span>
        <div><input value={selected.name} onChange={(event) => updateSelected({ name: event.target.value })}/><small>{selected.type.toUpperCase()}</small></div>
        <button className="icon-only danger" onClick={remove} title="Excluir objeto"><Trash2/></button>
      </div>
      {(['position', 'rotation', 'scale'] as const).map((key) => <section className="property-group" key={key}>
        <h3>{key === 'position' ? 'POSIÇÃO' : key === 'rotation' ? 'ROTAÇÃO' : 'ESCALA'}</h3>
        <div className="vector-row">{selected[key].map((value, index) => <label key={index}><span>{['X', 'Y', 'Z'][index]}</span><input type="number" step={key === 'rotation' ? 5 : 0.1} value={value} onChange={(event) => patchVector(key, index, event.target.value)}/></label>)}</div>
      </section>)}
      <section className="property-group">
        <h3>HIERARQUIA</h3>
        <label className="field-label">Objeto pai (grupo)
          <select value={selected.parentId ?? ''} onChange={(event) => setParent(event.target.value)}>
            <option value="">Raiz da cena</option>
            {objects.filter((object) => object.type === 'group' && object.id !== selected.id && !descendantsOf(selected.id).has(object.id)).map((group) => <option value={group.id} key={group.id}>{group.name}</option>)}
          </select>
        </label>
      </section>
      {selected.type !== 'group' && selected.type !== 'light' && <section className="property-group">
        <h3>MATERIAL</h3>
        <label className="color-row">Cor base <input type="color" value={selected.type === 'model' ? selected.materialColor ?? '#ffffff' : selected.color} onChange={(event) => updateSelected(selected.type === 'model' ? { materialColor: event.target.value } : { color: event.target.value })}/></label>
        <label className="field-label">Rugosidade
          <input type="range" min="0" max="1" step="0.01" value={selected.roughness ?? 0.72} onChange={(event) => updateSelected({ roughness: Number(event.target.value) })}/>
        </label>
        <label className="field-label">Metallicidade
          <input type="range" min="0" max="1" step="0.01" value={selected.metalness ?? 0.05} onChange={(event) => updateSelected({ metalness: Number(event.target.value) })}/>
        </label>
        <label className="field-label">Textura
          <select value={selected.textureAssetId ?? ''} onChange={(event) => updateSelected({ textureAssetId: event.target.value || null })}>
            <option value="">Sem textura adicional</option>
            {assets.filter((asset) => asset.kind === 'texture').map((asset) => <option value={asset.id} key={asset.id}>{asset.name}</option>)}
          </select>
        </label>
        {selected.textureAssetId && <small className="helper-copy">{assetById(selected.textureAssetId)?.name ?? 'Textura não encontrada'}</small>}
        {([
          ['normalMapAssetId', 'Normal Map'],
          ['roughnessMapAssetId', 'Roughness Map'],
          ['metalnessMapAssetId', 'Metallic Map'],
          ['aoMapAssetId', 'Ambient Occlusion Map']
        ] as const).map(([key, label]) => <label className="field-label" key={key}>{label}
          <select value={selected[key] ?? ''} onChange={(event) => updateSelected({ [key]: event.target.value || null })}>
            <option value="">Não atribuído</option>
            {assets.filter((asset) => asset.kind === 'texture').map((asset) => <option value={asset.id} key={asset.id}>{asset.name}</option>)}
          </select>
        </label>)}
        <p className="helper-copy">Mapas PBR são interpretados como dados lineares (sem correção sRGB), exceto Base Color.</p>
      </section>}
      {selected.type === 'light' && <section className="property-group">
        <h3>ILUMINAÇÃO LOCAL</h3>
        <label className="field-label">Tipo de luz
          <select value={selected.lightType ?? 'point'} onChange={(event) => updateSelected({ lightType: event.target.value as 'point' | 'spot' })}>
            <option value="point">Pontual (lâmpada / neon)</option><option value="spot">Spot (farol / refletor)</option>
          </select>
        </label>
        <label className="color-row">Cor da luz <input type="color" value={selected.color} onChange={(event) => updateSelected({ color: event.target.value })}/></label>
        <label className="field-label">Intensidade · {(selected.lightIntensity ?? 45).toFixed(0)}
          <input type="range" min="0" max="180" step="1" value={selected.lightIntensity ?? 45} onChange={(event) => updateSelected({ lightIntensity: Number(event.target.value) })}/>
        </label>
        <label className="field-label">Alcance · {(selected.lightDistance ?? 18).toFixed(0)} m
          <input type="range" min="2" max="80" step="1" value={selected.lightDistance ?? 18} onChange={(event) => updateSelected({ lightDistance: Number(event.target.value) })}/>
        </label>
        {selected.lightType === 'spot' && <label className="field-label">Abertura · {selected.lightAngle ?? 38}°
          <input type="range" min="5" max="85" step="1" value={selected.lightAngle ?? 38} onChange={(event) => updateSelected({ lightAngle: Number(event.target.value) })}/>
        </label>}
        <p className="helper-copy">Ponto: lâmpada/neon. Spot: farol/refletor. Para neon, combine a superfície emissiva com luzes locais; a emissão do material sozinha não ilumina outros objetos.</p>
      </section>}
      {selected.type === 'terrain' && <section className="property-group">
        <h3>WORLD BUILDER · TERRENO</h3>
        <label className="field-label">Altura do relevo · {(selected.terrainAmplitude ?? 1.35).toFixed(2)} m
          <input type="range" min="0.1" max="5" step="0.05" value={selected.terrainAmplitude ?? 1.35} onChange={(event) => updateSelected({ terrainAmplitude: Number(event.target.value) })}/>
        </label>
        <label className="field-label">Frequência das formas · {(selected.terrainFrequency ?? 0.28).toFixed(2)}
          <input type="range" min="0.08" max="0.65" step="0.01" value={selected.terrainFrequency ?? 0.28} onChange={(event) => updateSelected({ terrainFrequency: Number(event.target.value) })}/>
        </label>
        <button className="wide-action" onClick={() => updateSelected({ terrainSeed: (selected.terrainSeed ?? 7) + 1 })}><Layers3/> Gerar nova formação</button>
        <p className="helper-copy">Terreno procedural com malha subdividida e normais recalculadas. Os parâmetros ficam salvos no projeto e são compartilhados entre PC e Mobile.</p>
      </section>} 
      {selected.type === 'model' && <section className="property-group"><h3>MODELO</h3><p className="helper-copy">Arquivo: {assetById(selected.assetId)?.name ?? 'asset ausente'}</p></section>}
      <button className="delete-action" onClick={remove}><Trash2/> Excluir objeto</button>
    </> : <div className="empty-inspector">Selecione um objeto na cena ou na hierarquia para editar suas propriedades.</div>}
  </div>;

  return <main className={mobile ? 'app-shell mobile-app' : 'app-shell desktop-app'}>
    <input ref={projectFileRef} hidden type="file" accept=".rageproj,.ragescene,.json,application/json" onChange={(event) => importProjectOrScene(event.target.files?.[0])}/>
    <input ref={assetFileRef} hidden type="file" multiple accept=".glb,.gltf,.bin,.png,.jpg,.jpeg,.webp,.avif,model/gltf-binary,model/gltf+json,image/*" onChange={(event) => importAssets(Array.from(event.target.files ?? []))}/>
    <header className="topbar">
      <div className="brand-lockup"><div className="brand-mark">R</div><div><strong>RAGE ENGINE</strong><span>{mobile ? 'MOBILE EDITION' : 'DESKTOP EDITION'}</span></div></div>
      {!mobile && <button className="project-tab" onClick={() => setDrawer('project')}><i/> {project.name} <span>⌄</span></button>}
      <div className="top-actions"><span className="save-state">● {ready ? 'Salvamento automático' : 'Carregando...'}</span>{mobile && <button className="icon-only" onClick={() => setPlaying((value) => !value)} title={playing ? 'Parar pré-visualização' : 'Play'}>{playing ? <Square/> : <Play/>}</button>}<button className="icon-only" onClick={exportProject} title="Exportar projeto"><Save/></button><button className="icon-only" onClick={openProjectLibrary} title="Abrir projeto local"><FolderOpen/></button></div>
    </header>
    {!mobile && <nav className="toolbar">
      <div className="tool-set">{[['select', '↖'], ['move', '✥'], ['rotate', '⟳'], ['scale', '□']].map(([key, glyph]) => <button key={key} className={tool === key ? 'active' : ''} onClick={() => setTool(key)} title={key}>{glyph}</button>)}</div>
      <button className={grid ? 'toolbar-item active' : 'toolbar-item'} onClick={() => setGrid((value) => !value)}><Grid3X3/> Grid</button>
      <span className="toolbar-spacer"/><span className="scene-status">● {activeScene?.name ?? 'Sem cena'}</span>
      <button className={playing ? 'play-button running' : 'play-button'} onClick={() => setPlaying((value) => !value)}>{playing ? <Square/> : <Play/>}{playing ? 'Parar' : 'Play'}</button>
    </nav>}
    <div className="workspace">
      {!mobile && <aside className="left-panel"><div className="panel-heading"><div><small>PROJECT HUB</small><h2>Projeto</h2></div><FolderOpen/></div>{projectPanel}</aside>}
      <section className="viewport-column">
        <div className="viewport-top"><span>＋ Scene View / {activeScene?.name ?? 'Scene'}</span><span>Perspective · Lit</span></div>
        {mobile && <div className="mobile-transform-tools" aria-label="Ferramentas de transformação">{([['select', 'Selecionar', '↖'], ['move', 'Mover', '✥'], ['rotate', 'Girar', '⟳'], ['scale', 'Escalar', '□']] as const).map(([mode, label, glyph]) => <button key={mode} className={tool === mode ? 'active' : ''} onClick={() => setTool(mode)}>{glyph}<span>{label}</span></button>)}</div>}
        <SceneView objects={objects} assets={assets} selectedId={selectedId} onSelect={setSelectedId}
          onTransform={(id, value) => updateObjects((current) => current.map((object) => object.id === id ? { ...object, position: value.position, rotation: value.rotation, scale: value.scale } : object))}
          tool={tool} showGrid={grid} renderSettings={project.renderSettings}/>
        <div className="viewport-bottom"><span>{objects.length} objetos</span><span>Three.js · WebGL</span><span>{grid ? 'Grid ligado' : 'Grid desligado'}</span></div>
      </section>
      {!mobile && <aside className="right-panel"><div className="panel-heading"><div><small>SCENE</small><h2>Hierarquia</h2></div><span>{objects.length}</span></div>{hierarchy}<div className="inspector-heading"><small>INSPECTOR / DETAILS</small></div>{inspector}</aside>}
    </div>
    {mobile && <>
      <div className="mobile-toolbar">
        <button onClick={() => setDrawer('project')} className={drawer === 'project' ? 'active' : ''}><FolderOpen/>Projeto</button>
        <button onClick={() => setDrawer('create')} className={drawer === 'create' ? 'active' : ''}><Plus/>Criar</button>
        <button onClick={() => setDrawer('hierarchy')} className={drawer === 'hierarchy' ? 'active' : ''}><Grid3X3/>Cena</button>
        <button onClick={() => setDrawer('inspector')} className={drawer === 'inspector' ? 'active' : ''}><Settings2/>Ajustes</button>
      </div>
      <section className="mobile-drawer">
        <div className="drawer-handle"/><div className="drawer-title"><b>{drawer === 'project' ? 'Gerenciador de projeto' : drawer === 'create' ? 'Criar elementos' : drawer === 'hierarchy' ? 'Hierarquia da cena' : 'Inspector'}</b><button onClick={() => setDrawer('create')}><X/></button></div>
        {drawer === 'project' ? projectPanel : drawer === 'create' ? createPanel : drawer === 'hierarchy' ? hierarchy : inspector}
      </section>
    </>}
    {dialog && <div className="project-modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setDialog(null); }}>
      <section className="project-modal" role="dialog" aria-modal="true" aria-label={dialog === 'new' ? 'Novo projeto' : 'Abrir projeto'}>
        <div className="modal-heading"><div><small>RAGE PROJECT MANAGER</small><h2>{dialog === 'new' ? 'Criar projeto' : 'Abrir projeto'}</h2></div><button className="icon-only" onClick={() => setDialog(null)}><X/></button></div>
        {dialog === 'new' ? <>
          <label className="field-label">Nome do projeto<input autoFocus value={projectName} onChange={(event) => setProjectName(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter') startNewProject(); }}/></label>
          <p className="helper-copy">Um projeto novo começa com uma cena principal e objetos de demonstração. O projeto atual continuará salvo localmente.</p>
          <div className="modal-actions"><button className="wide-action" onClick={() => setDialog(null)}>Cancelar</button><button className="wide-action primary-action" onClick={startNewProject}><FilePlus2/> Criar projeto</button></div>
        </> : <>
          <div className="local-project-list">{localProjects.map((item) => <button key={item.id} className="local-project-entry" onClick={() => openLocalProject(item)}>
            <FolderOpen/><span><b>{item.name}</b><small>{item.scenes.length} cena(s) · atualizado {new Date(item.updatedAt).toLocaleString()}</small></span><ChevronRight/>
          </button>)}{!localProjects.length && <p className="empty">Nenhum projeto salvo neste dispositivo. Importe um arquivo .rageproj.</p>}</div>
          <div className="modal-actions"><button className="wide-action" onClick={() => { setDialog(null); projectFileRef.current?.click(); }}><Upload/> Importar .rageproj</button><button className="wide-action" onClick={() => setDialog(null)}>Fechar</button></div>
        </>}
      </section>
    </div>}
    {notice && <div className="toast" role="status">{notice}</div>}
    {playing && <div className="play-overlay"><span>PRÉ-VISUALIZAÇÃO</span><b>Modo Play de demonstração</b><small>O runtime de jogo ainda será implementado.</small><button onClick={() => setPlaying(false)}>Encerrar Play</button></div>}
  </main>;
}
