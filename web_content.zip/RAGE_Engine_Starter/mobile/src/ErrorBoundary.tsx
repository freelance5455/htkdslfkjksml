import React from 'react';

type Props = { children: React.ReactNode };
type State = { error: Error | null };

export default class AppErrorBoundary extends React.Component<Props, State> {
  state: State = { error: null };

  static getDerivedStateFromError(error: Error): State {
    return { error };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo) {
    console.error('Erro fatal na interface do RAGE Engine:', error, info.componentStack);
  }

  render() {
    if (this.state.error) {
      return (
        <main style={{ minHeight: '100vh', padding: 24, background: '#10151b', color: '#e6ecef', fontFamily: 'system-ui, sans-serif' }}>
          <h1>RAGE Engine encontrou um erro</h1>
          <p>A interface não conseguiu iniciar corretamente. O diagnóstico abaixo ajuda a identificar a causa.</p>
          <pre style={{ whiteSpace: 'pre-wrap', overflowWrap: 'anywhere', padding: 12, background: '#1c252d', borderRadius: 8 }}>{this.state.error.message}</pre>
          <button onClick={() => window.location.reload()} style={{ padding: '10px 16px', borderRadius: 6 }}>Recarregar aplicativo</button>
        </main>
      );
    }
    return this.props.children;
  }
}
