import { createProject, isSceneObject, type RageProject } from './model';

const DB_NAME = 'rage-engine-projects';
const DB_VERSION = 1;
const STORE_NAME = 'projects';
const FALLBACK_PREFIX = 'rage-project:';

function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') return reject(new Error('IndexedDB indisponível'));
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) db.createObjectStore(STORE_NAME, { keyPath: 'id' });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error('Não foi possível abrir o banco de projetos'));
  });
}

export async function saveProjectLocal(project: RageProject): Promise<void> {
  try {
    const db = await openDatabase();
    await new Promise<void>((resolve, reject) => {
      const transaction = db.transaction(STORE_NAME, 'readwrite');
      transaction.objectStore(STORE_NAME).put(project);
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error ?? new Error('Falha ao salvar projeto'));
      transaction.onabort = () => reject(transaction.error ?? new Error('Salvamento cancelado'));
    });
    db.close();
    try { localStorage.setItem('rage-engine-last-project', project.id); } catch { /* private mode */ }
  } catch (error) {
    try {
      localStorage.setItem(`${FALLBACK_PREFIX}${project.id}`, JSON.stringify(project));
      localStorage.setItem('rage-engine-last-project', project.id);
    } catch {
      throw error;
    }
  }
}

export async function listLocalProjects(): Promise<RageProject[]> {
  try {
    const db = await openDatabase();
    const rows = await new Promise<RageProject[]>((resolve, reject) => {
      const request = db.transaction(STORE_NAME, 'readonly').objectStore(STORE_NAME).getAll();
      request.onsuccess = () => resolve(request.result as RageProject[]);
      request.onerror = () => reject(request.error);
    });
    db.close();
    return rows.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
  } catch {
    const rows: RageProject[] = [];
    try {
      for (let index = 0; index < localStorage.length; index += 1) {
        const key = localStorage.key(index);
        if (key?.startsWith(FALLBACK_PREFIX)) {
          const parsed = JSON.parse(localStorage.getItem(key) || 'null') as RageProject | null;
          if (parsed) rows.push(parsed);
        }
      }
    } catch { /* ignore malformed fallback records */ }
    return rows.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
  }
}

export async function loadLastProject(): Promise<RageProject | null> {
  let lastId: string | null = null;
  try { lastId = localStorage.getItem('rage-engine-last-project'); } catch { /* storage may be restricted */ }
  try {
    const db = await openDatabase();
    const project = await new Promise<RageProject | null>((resolve, reject) => {
      const store = db.transaction(STORE_NAME, 'readonly').objectStore(STORE_NAME);
      if (lastId) {
        const request = store.get(lastId);
        request.onsuccess = () => resolve((request.result as RageProject | undefined) ?? null);
        request.onerror = () => reject(request.error);
      } else {
        const request = store.getAll();
        request.onsuccess = () => {
          const projects = (request.result as RageProject[]).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
          resolve(projects[0] ?? null);
        };
        request.onerror = () => reject(request.error);
      }
    });
    db.close();
    if (project) return project;
  } catch { /* use localStorage fallback below */ }
  try {
    if (lastId) {
      const raw = localStorage.getItem(`${FALLBACK_PREFIX}${lastId}`);
      if (raw) return JSON.parse(raw) as RageProject;
    }
    const fallbackProjects: RageProject[] = [];
    for (let index = 0; index < localStorage.length; index += 1) {
      const key = localStorage.key(index);
      if (key?.startsWith(FALLBACK_PREFIX)) {
        const raw = localStorage.getItem(key);
        if (raw) fallbackProjects.push(JSON.parse(raw) as RageProject);
      }
    }
    const savedFallback = fallbackProjects.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))[0];
    if (savedFallback) return savedFallback;

    // Migrate the v0.3.1 Mobile edition's single-scene localStorage save.
    const legacyRaw = localStorage.getItem('rage-engine-scene-v1');
    if (legacyRaw) {
      const legacy: unknown = JSON.parse(legacyRaw);
      if (Array.isArray(legacy) && legacy.every(isSceneObject)) {
        const migrated = createProject('Projeto migrado');
        migrated.scenes[0].objects = legacy;
        await saveProjectLocal(migrated);
        return migrated;
      }
    }
    return null;
  } catch { return null; }
}
