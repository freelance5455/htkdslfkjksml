#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT/mobile"
command -v node >/dev/null 2>&1 || { echo "Instale Node.js: pkg install nodejs-lts npm"; exit 1; }
command -v npm >/dev/null 2>&1 || { echo "Instale npm: pkg install npm"; exit 1; }
[[ -d node_modules ]] || npm install
npm run dev -- --host 0.0.0.0
