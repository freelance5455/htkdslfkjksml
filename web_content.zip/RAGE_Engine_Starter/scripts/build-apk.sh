#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MOBILE="$ROOT/mobile"

if [[ -z "${PREFIX:-}" || "$PREFIX" != *"com.termux"* ]]; then
  echo "ERRO: este script foi preparado para compilar no Termux do Android."
  exit 1
fi

if [[ ! -f "$MOBILE/package.json" ]]; then
  echo "ERRO: pasta mobile do RAGE Engine não foi encontrada: $MOBILE"
  exit 1
fi

export ANDROID_HOME="${ANDROID_HOME:-$PREFIX/opt/android-sdk}"
export ANDROID_SDK_ROOT="$ANDROID_HOME"
export TMPDIR="$HOME/tmp"
export PATH="$PREFIX/bin:$ANDROID_HOME/build-tools/36.1.0:$ANDROID_HOME/platform-tools:$PATH"
mkdir -p "$TMPDIR" "$HOME/.android"
touch "$HOME/.android/repositories.cfg"

if ! command -v node >/dev/null 2>&1 || ! command -v npm >/dev/null 2>&1; then
  echo "ERRO: Node.js/npm não encontrados. Rode: bash scripts/setup-termux.sh"
  exit 1
fi
NODE_MAJOR="$(node -p 'Number(process.versions.node.split(".")[0])')"
if (( NODE_MAJOR < 22 )); then
  echo "ERRO: Capacitor 8 precisa de Node.js 22 ou superior. Versão atual: $(node --version)"
  echo "Atualize com: pkg install nodejs-lts"
  exit 1
fi

JAVAC_PATH="$(command -v javac || true)"
if [[ -z "$JAVAC_PATH" ]]; then
  echo "ERRO: JDK não encontrado. Rode: pkg install openjdk-21"
  exit 1
fi
export JAVA_HOME="${JAVA_HOME:-$(dirname "$(dirname "$(readlink -f "$JAVAC_PATH")")")}"
if [[ ! -x "$JAVA_HOME/bin/java" ]]; then
  echo "ERRO: JAVA_HOME inválido: $JAVA_HOME"
  exit 1
fi

AAPT2_BIN="$(command -v aapt2 || true)"
ZIPALIGN_BIN="$(command -v zipalign || true)"
APKSIGNER_BIN="$(command -v apksigner || true)"
D8_BIN="$(command -v d8 || true)"
for pair in "aapt2:$AAPT2_BIN" "zipalign:$ZIPALIGN_BIN" "apksigner:$APKSIGNER_BIN" "d8:$D8_BIN"; do
  name="${pair%%:*}"
  path="${pair#*:}"
  if [[ -z "$path" ]]; then
    echo "ERRO: $name ausente. Instale com: pkg install $name"
    exit 1
  fi
done

if [[ ! -d "$ANDROID_HOME" ]]; then
  echo "ERRO: Android SDK ausente em $ANDROID_HOME"
  echo "Rode: pkg install android-sdk"
  exit 1
fi

SDKMANAGER="$(command -v sdkmanager || true)"
for candidate in "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" "$ANDROID_HOME/cmdline-tools/bin/sdkmanager"; do
  if [[ -z "$SDKMANAGER" && -f "$candidate" ]]; then SDKMANAGER="$candidate"; break; fi
done
if [[ -z "$SDKMANAGER" && -d "$ANDROID_HOME/cmdline-tools" ]]; then
  SDKMANAGER="$(find "$ANDROID_HOME/cmdline-tools" -type f -name sdkmanager 2>/dev/null | head -n 1 || true)"
fi

if [[ ! -f "$ANDROID_HOME/platforms/android-36/android.jar" ]]; then
  if [[ -n "$SDKMANAGER" ]]; then
    echo "Instalando Android SDK Platform 36..."
    yes | bash "$SDKMANAGER" --sdk_root="$ANDROID_HOME" --licenses >/dev/null 2>&1 || true
    bash "$SDKMANAGER" --sdk_root="$ANDROID_HOME" "platforms;android-36"
  else
    echo "ERRO: Android SDK Platform 36 está ausente."
    echo "Instale/repare o pacote android-sdk e confirme se sdkmanager está no PATH ou dentro de $ANDROID_HOME/cmdline-tools."
    exit 1
  fi
fi

if [[ ! -d "$ANDROID_HOME/build-tools/36.1.0" ]]; then
  echo "ERRO: Build Tools 36.1.0 não encontrados em $ANDROID_HOME/build-tools."
  echo "Rode: pkg reinstall android-sdk"
  exit 1
fi

printf '\n[RAGE Engine] Node %s | Java: ' "$(node --version)"
java -version 2>&1 | head -n 1
printf '[RAGE Engine] Android SDK: %s\n' "$ANDROID_HOME"
printf '[RAGE Engine] AAPT2 nativo: %s\n' "$AAPT2_BIN"
printf '[RAGE Engine] D8: %s\n\n' "$D8_BIN"

cd "$MOBILE"
if [[ ! -d node_modules ]]; then
  echo "Instalando dependências web e Capacitor (primeira execução)..."
fi
npm install

# Build the Vite app before Capacitor copies assets into android/app/src/main/assets/public.
npm run build

if [[ ! -f android/build.gradle && ! -f android/build.gradle.kts ]]; then
  if [[ -d android ]]; then
    echo "ERRO: existe uma pasta android incompleta. Faça backup dela e remova-a antes de executar novamente."
    exit 1
  fi
  npx cap add android
fi

npx cap sync android

GRADLE_PROPS="$MOBILE/android/gradle.properties"
touch "$GRADLE_PROPS"
set_gradle_prop() {
  local key="$1" value="$2"
  if grep -q "^${key}=" "$GRADLE_PROPS"; then
    sed -i "s|^${key}=.*|${key}=${value}|" "$GRADLE_PROPS"
  else
    printf '%s=%s\n' "$key" "$value" >> "$GRADLE_PROPS"
  fi
}
set_gradle_prop android.aapt2FromMavenOverride "$AAPT2_BIN"
set_gradle_prop org.gradle.jvmargs '-Xmx1536m -XX:MaxMetaspaceSize=512m -Dfile.encoding=UTF-8'
set_gradle_prop org.gradle.daemon false
set_gradle_prop org.gradle.parallel false
set_gradle_prop org.gradle.workers.max 2

printf 'sdk.dir=%s\n' "$ANDROID_HOME" > "$MOBILE/android/local.properties"
chmod +x "$MOBILE/android/gradlew"

echo "Compilando APK de teste. A primeira compilação pode demorar e baixar dependências..."
(
  cd "$MOBILE/android"
  ./gradlew :app:assembleDebug --no-daemon --stacktrace
)

APK_SOURCE="$MOBILE/android/app/build/outputs/apk/debug/app-debug.apk"
if [[ ! -f "$APK_SOURCE" ]]; then
  echo "ERRO: Gradle terminou sem gerar $APK_SOURCE"
  exit 1
fi

mkdir -p "$ROOT/output"
APK_DEST="$ROOT/output/RAGE-Engine-debug.apk"
cp "$APK_SOURCE" "$APK_DEST"

if command -v apksigner >/dev/null 2>&1; then
  apksigner verify --verbose "$APK_DEST" >/dev/null
fi
if command -v zipalign >/dev/null 2>&1; then
  zipalign -c -v 4 "$APK_DEST" >/dev/null
fi

if [[ -d "$HOME/storage/downloads" ]]; then
  cp "$APK_DEST" "$HOME/storage/downloads/RAGE-Engine-debug.apk"
  echo "APK copiado para: $HOME/storage/downloads/RAGE-Engine-debug.apk"
else
  echo "APK salvo em: $APK_DEST"
  echo "Para copiar para Downloads, execute termux-setup-storage e rode o build novamente."
fi

echo "Build concluído. Este é um APK debug assinado para testes locais."
echo "Toque no arquivo APK no app Arquivos/Downloads para instalar."
