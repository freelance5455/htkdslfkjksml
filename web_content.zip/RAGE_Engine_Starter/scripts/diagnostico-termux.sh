#!/data/data/com.termux/files/usr/bin/bash
set +e
printf '\n===== RAGE ENGINE / DIAGNÓSTICO TERMUX =====\n'
printf 'Data: '; date
printf 'Arquitetura: '; uname -m
printf 'Android: '; getprop ro.build.version.release 2>/dev/null || echo 'não disponível'
printf 'PREFIX: %s\nHOME: %s\n' "${PREFIX:-não definido}" "$HOME"
printf '\n--- Termux ---\n'
termux-info 2>&1 | head -n 70
printf '\n--- Ferramentas ---\n'
for tool in node npm java javac aapt2 d8 zipalign apksigner sdkmanager adb; do
  printf '%-12s' "$tool"
  command -v "$tool" || true
done
printf '\n--- Versões ---\n'
node --version 2>&1
npm --version 2>&1
java -version 2>&1 | head -n 3
printf '\n--- Android SDK ---\n'
printf 'ANDROID_HOME atual: %s\n' "${ANDROID_HOME:-não definido}"
SDK="${ANDROID_HOME:-${PREFIX:-/data/data/com.termux/files/usr}/opt/android-sdk}"
ls -la "$SDK" 2>&1 | head -n 25
ls -1 "$SDK/platforms" 2>&1 | head -n 20
ls -1 "$SDK/build-tools" 2>&1 | head -n 20
printf '\n--- Espaço em disco ---\n'
df -h "$HOME" 2>&1
printf '\n--- Memória ---\n'
free -h 2>&1
printf '\n===== FIM DO DIAGNÓSTICO =====\n'
