#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

if [[ -z "${PREFIX:-}" || "$PREFIX" != *"com.termux"* ]]; then
  echo "ERRO: execute este script dentro do Termux, não em um terminal Linux comum."
  exit 1
fi

say() { printf '\n\033[1;32m[RAGE Engine] %s\033[0m\n' "$1"; }

say "Atualizando índices e pacotes do Termux"
pkg update
pkg upgrade -y

say "Instalando Node.js, Java e ferramentas Android nativas para ARM"
pkg install -y nodejs-lts npm openjdk-21 android-sdk aapt2 apksigner zipalign d8 unzip

SDK_ROOT="${ANDROID_HOME:-$PREFIX/opt/android-sdk}"
JAVAC_PATH="$(command -v javac || true)"
if [[ -z "$JAVAC_PATH" ]]; then
  echo "ERRO: javac não foi encontrado após instalar openjdk-21."
  exit 1
fi
JDK_ROOT="$(dirname "$(dirname "$(readlink -f "$JAVAC_PATH")")")"

if [[ ! -d "$SDK_ROOT" ]]; then
  echo "ERRO: Android SDK não encontrado em: $SDK_ROOT"
  echo "Confira o pacote android-sdk com: pkg search android-sdk"
  exit 1
fi

mkdir -p "$HOME/tmp" "$HOME/.gradle"

# Persist the environment for future Termux sessions (avoid duplicate lines).
PROFILE="$HOME/.bashrc"
touch "$PROFILE"
add_profile_line() {
  local line="$1"
  grep -Fqx "$line" "$PROFILE" || printf '%s\n' "$line" >> "$PROFILE"
}
add_profile_line 'export ANDROID_HOME="$PREFIX/opt/android-sdk"'
add_profile_line 'export ANDROID_SDK_ROOT="$ANDROID_HOME"'
add_profile_line "export JAVA_HOME=\"$JDK_ROOT\""
add_profile_line 'export PATH="$PREFIX/bin:$ANDROID_HOME/build-tools/36.1.0:$ANDROID_HOME/platform-tools:$PATH"'

export ANDROID_HOME="$SDK_ROOT"
export ANDROID_SDK_ROOT="$SDK_ROOT"
export JAVA_HOME="$JDK_ROOT"
export PATH="$PREFIX/bin:$ANDROID_HOME/build-tools/36.1.0:$ANDROID_HOME/platform-tools:$PATH"

AAPT2_BIN="$(command -v aapt2 || true)"
ZIPALIGN_BIN="$(command -v zipalign || true)"
APKSIGNER_BIN="$(command -v apksigner || true)"
D8_BIN="$(command -v d8 || true)"
for pair in "aapt2:$AAPT2_BIN" "zipalign:$ZIPALIGN_BIN" "apksigner:$APKSIGNER_BIN" "d8:$D8_BIN"; do
  name="${pair%%:*}"
  path="${pair#*:}"
  if [[ -z "$path" ]]; then
    echo "ERRO: ferramenta $name não foi encontrada. Tente: pkg install $name"
    exit 1
  fi
done

say "Configurando limite de memória do Gradle para celular"
GRADLE_PROPS="$HOME/.gradle/gradle.properties"
touch "$GRADLE_PROPS"
set_prop() {
  local key="$1" value="$2"
  if grep -q "^${key}=" "$GRADLE_PROPS"; then
    sed -i "s|^${key}=.*|${key}=${value}|" "$GRADLE_PROPS"
  else
    printf '%s=%s\n' "$key" "$value" >> "$GRADLE_PROPS"
  fi
}
set_prop android.aapt2FromMavenOverride "$AAPT2_BIN"
set_prop org.gradle.jvmargs '-Xmx1536m -XX:MaxMetaspaceSize=512m -Dfile.encoding=UTF-8'
set_prop org.gradle.daemon false
set_prop org.gradle.parallel false
set_prop org.gradle.workers.max 2

say "Verificando a instalação"
echo "Arquitetura: $(uname -m)"
echo "Node: $(node --version)"
echo "npm: $(npm --version)"
java -version 2>&1 | head -n 2
echo "Android SDK: $ANDROID_HOME"
echo "aapt2: $AAPT2_BIN"
echo "zipalign: $ZIPALIGN_BIN"
echo "apksigner: $APKSIGNER_BIN"
echo "d8: $D8_BIN"

echo
echo "Configuração básica concluída."
echo "Agora execute: termux-setup-storage"
echo "Depois abra a pasta do projeto e rode: bash scripts/build-apk.sh"
echo "Para abrir a edição web no navegador: bash scripts/run-mobile.sh"
