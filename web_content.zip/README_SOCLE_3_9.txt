CGD V117 — Socle 3.9
Ambiance cinématique, mouvements de public et caméra plus organique.
Ouvrir index.html via un serveur web local pour utiliser le jeu.
Voir VERIFICATION_SOCLE_3_9.md et STAGE_3_9_AMBIANCE_CINEMATIQUE_ANIMATIONS_PUBLIC.md.
