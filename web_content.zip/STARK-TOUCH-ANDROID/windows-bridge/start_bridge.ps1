$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
py -m pip install -r requirements.txt
py .\stark_bridge.py
