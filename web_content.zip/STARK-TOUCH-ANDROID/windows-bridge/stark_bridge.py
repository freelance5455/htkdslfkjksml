import secrets, socket, subprocess, sys, threading, time
from flask import Flask, request, jsonify
from flask_cors import CORS

try:
    import pyautogui
except Exception:
    pyautogui = None

app = Flask(__name__)
CORS(app, resources={r"/*": {"origins": "*"}})  # Local-only bridge; do not expose to the Internet.
PAIR_PIN = f"{secrets.randbelow(1000000):06d}"
TOKENS = set()
PORT = 8765
ALLOWED_KEYS = {
    "ESC":"esc","TAB":"tab","CTRL":"ctrl","ALT":"alt","SHIFT":"shift",
    "SPACE":"space","ENTER":"enter","BACKSPACE":"backspace","WIN":"win",
    "CTRL+C":("ctrl","c"),"CTRL+V":("ctrl","v"),"ALT+TAB":("alt","tab"),
    "CTRL+SHIFT+ESC":("ctrl","shift","esc")
}
for ch in "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZÑ":
    ALLOWED_KEYS[ch] = ch.lower() if ch != "Ñ" else "ñ"

def local_ip():
    s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
    try:
        s.connect(("192.0.2.1",80)); ip=s.getsockname()[0]
    except Exception: ip="127.0.0.1"
    finally: s.close()
    return ip

def authorized():
    auth=request.headers.get("Authorization","")
    token=auth.removeprefix("Bearer ").strip()
    return token in TOKENS

@app.after_request
def security_headers(resp):
    resp.headers["X-Content-Type-Options"]="nosniff"
    resp.headers["Cache-Control"]="no-store"
    return resp

@app.get("/health")
def health(): return jsonify({"ok":True,"service":"STARK TOUCH Bridge"})

@app.post("/pair")
def pair():
    data=request.get_json(silent=True) or {}
    if not secrets.compare_digest(str(data.get("pin","")),PAIR_PIN):
        return jsonify({"error":"PIN incorrecto"}),401
    token=secrets.token_urlsafe(32); TOKENS.add(token)
    return jsonify({"token":token,"paired":True})

@app.before_request
def auth_guard():
    if request.path in ("/pair","/health"): return None
    if not authorized(): return jsonify({"error":"No autorizado; vuelve a emparejar"}),401

@app.post("/key")
def key():
    data=request.get_json(silent=True) or {}; k=str(data.get("key","")).upper()
    if k not in ALLOWED_KEYS: return jsonify({"error":"Tecla no permitida"}),400
    if pyautogui is None: return jsonify({"error":"Falta pyautogui; instala requirements.txt"}),500
    val=ALLOWED_KEYS[k]
    try:
        if isinstance(val,tuple): pyautogui.hotkey(*val)
        else: pyautogui.press(val)
        return jsonify({"ok":True})
    except Exception as e: return jsonify({"error":str(e)}),500

@app.post("/text")
def text():
    data=request.get_json(silent=True) or {}; value=str(data.get("text",""))
    if len(value)>2000: return jsonify({"error":"Máximo 2000 caracteres por envío"}),400
    if pyautogui is None: return jsonify({"error":"Falta pyautogui"}),500
    try:
        # Write literal text only; no shell or command execution.
        pyautogui.write(value, interval=0.001)
        return jsonify({"ok":True,"chars":len(value)})
    except Exception as e: return jsonify({"error":str(e)}),500

@app.post("/mouse")
def mouse():
    if pyautogui is None: return jsonify({"error":"Falta pyautogui"}),500
    data=request.get_json(silent=True) or {}; action=data.get("action")
    try:
        if action=="move":
            dx=max(-250,min(250,float(data.get("dx",0)))); dy=max(-250,min(250,float(data.get("dy",0))))
            pyautogui.moveRel(dx,dy,duration=0)
        elif action=="leftClick": pyautogui.click()
        elif action=="rightClick": pyautogui.click(button="right")
        else: return jsonify({"error":"Acción de ratón no permitida"}),400
        return jsonify({"ok":True})
    except Exception as e: return jsonify({"error":str(e)}),500

@app.post("/action")
def action():
    data=request.get_json(silent=True) or {}; a=data.get("action")
    # Only pre-defined safe actions. No arbitrary shell commands.
    try:
        if a=="openNotepad": subprocess.Popen(["notepad.exe"])
        elif a=="openCalculator": subprocess.Popen(["calc.exe"])
        elif a=="openBrowser": subprocess.Popen(["cmd.exe","/c","start","","https://example.com"], shell=False)
        elif a=="showDesktop":
            if pyautogui: pyautogui.hotkey("win","d")
            else: return jsonify({"error":"Falta pyautogui"}),500
        elif a in ("scrollUp","scrollDown"):
            if pyautogui: pyautogui.scroll(4 if a=="scrollUp" else -4)
            else: return jsonify({"error":"Falta pyautogui"}),500
        else: return jsonify({"error":"Acción no permitida"}),400
        return jsonify({"ok":True})
    except Exception as e: return jsonify({"error":str(e)}),500

@app.post("/workshop")
def workshop():
    data=request.get_json(silent=True) or {}; action=data.get("action")
    allowed={"select","rotate","zoomIn","zoomOut","assemble","explode","reset","toggleHolograms"}
    if action not in allowed: return jsonify({"error":"Acción de taller no permitida"}),400
    # Intentionally generic event: connect this to the real workshop API only after inspection.
    print(f"[WORKSHOP EVENT] {action}")
    return jsonify({"ok":True,"event":action,"note":"Evento recibido; API real del taller aún no conectada."})

if __name__=="__main__":
    print("\\n=== STARK TOUCH BRIDGE ===")
    print("PIN de emparejamiento (no lo compartas):",PAIR_PIN)
    print("Puerto:",PORT)
    print("IP detectada:",local_ip())
    print("USB: activa Anclaje USB en Android y usa la IP de la interfaz de red USB si cambia.")
    print("No expongas este servidor a Internet. Ctrl+C para salir.\\n")
    app.run(host="0.0.0.0",port=PORT,debug=False,threaded=True)
