# STARK TOUCH Android — proyecto instalable

Este paquete es un **proyecto Android nativo** que empaqueta la interfaz STARK TOUCH dentro de una app Android (WebView local). No modifica MARK 1. El ZIP contiene el código fuente de Android Studio; **no incluye un APK precompilado**.

## Crear el APK
1. Instala Android Studio en Windows desde el sitio oficial de Android Developers.
2. Extrae este ZIP, abre Android Studio y elige **Open**. Selecciona la carpeta `STARK-TOUCH-ANDROID`.
3. Espera la sincronización de Gradle e instala el Android SDK que Android Studio solicite (compile SDK 35).
4. Conecta el teléfono Android por USB y activa Opciones de desarrollador → Depuración USB, o usa Build → Build Bundle(s) / APK(s) → Build APK(s).
5. El APK de depuración queda normalmente en `app/build/outputs/apk/debug/app-debug.apk`. Copialo al teléfono y abrilo para instalarlo. Puede que Android pida permitir instalación desde esa fuente.

## Conectar con Windows
La app Android contiene la interfaz local. El puente Windows sigue siendo el componente `windows-bridge` del paquete STARK-TOUCH anterior:
- instala Python 3 y las dependencias en `windows-bridge`;
- ejecuta `py stark_bridge.py`;
- introduce en la app la dirección del puente y el PIN de emparejamiento.

Para Wi-Fi, teléfono y PC deben estar en la misma red local. Para USB, conecta el teléfono por cable y activa **Anclaje USB** en Android; usa la IP de la interfaz USB que muestre Windows. En algunas redes Android, el tráfico de anclaje USB no permite alcanzar la IP del PC en ambos sentidos; en ese caso usa Wi-Fi o ADB reverse configurado manualmente.

## Estado y límites
- Es una app Android nativa que muestra la interfaz web empaquetada; la UI no necesita Internet.
- El puente Windows debe estar funcionando para enviar teclas/ratón.
- Los controles del taller 3D todavía envían eventos genéricos, no controlan el taller real hasta integrar una API existente.
- Este proyecto fuente requiere Android Studio/Gradle para producir el APK. No afirmamos que el APK esté compilado.
- No expongas el puente a Internet. Úsalo solo en una red local de confianza.
