const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
let mode='wifi', token='', connected=false, ws=null, lastMove=0;
const toast=(m)=>{const t=$('#toast');t.textContent=m;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2300)};
$$('[data-mode]').forEach(b=>b.onclick=()=>{$$('[data-mode]').forEach(x=>x.classList.toggle('selected',x===b));mode=b.dataset.mode;$('#linkType').textContent=mode==='wifi'?'WI-FI':'USB';toast(mode==='usb'?'Conecta USB y activa Anclaje USB en Android':'Modo Wi-Fi local seleccionado')});
$$('[data-tab]').forEach(b=>b.onclick=()=>{$$('[data-tab]').forEach(x=>x.classList.toggle('active',x===b));$$('.tab').forEach(x=>x.classList.toggle('active',x.id===b.dataset.tab))});
const chars='1234567890QWERTYUIOPASDFGHJKLÑZXCVBNM';
const grid=$('#keygrid');[...'1234567890','QWERTYUIOP','ASDFGHJKLÑ','ZXCVBNM'].forEach((row,i)=>{for(const ch of row){const b=document.createElement('button');b.textContent=ch;b.dataset.text=ch;grid.appendChild(b)}});
async function connect(){const base=$('#server').value.trim().replace(/\/+$/,'');const pin=$('#pin').value.trim();if(!base||!pin){toast('Introduce la dirección del puente y el PIN');return}
try{const r=await fetch(base+'/pair',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({pin})});const d=await r.json();if(!r.ok)throw Error(d.error||'Emparejamiento rechazado');token=d.token;connected=true;$('#dot').classList.add('on');$('#statusText').textContent='CONECTADO';toast('Emparejamiento correcto');}catch(e){toast('No conecta: '+e.message+' · revisa IP, PIN y red');}}
$('#connect').onclick=connect;$('#disconnect').onclick=()=>{connected=false;token='';$('#dot').classList.remove('on');$('#statusText').textContent='SIN CONEXIÓN';toast('Desconectado')};
async function send(path,payload={}){if(!connected){toast('Primero conecta con Windows');return}try{const base=$('#server').value.trim().replace(/\/+$/,'');const t0=performance.now();const r=await fetch(base+path,{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+token},body:JSON.stringify(payload)});const d=await r.json();if(!r.ok)throw Error(d.error||'Error');$('#latency').textContent=Math.round(performance.now()-t0)+' ms';return d}catch(e){toast('Error: '+e.message)}}
grid.onclick=e=>{const b=e.target.closest('button');if(b)send('/key',{key:b.dataset.text})};
$$('[data-key]').forEach(b=>b.onclick=()=>send('/key',{key:b.dataset.key}));
$('#sendText').onclick=()=>{const text=$('#textEntry').value;if(text)send('/text',{text})};
$('#leftClick').onclick=()=>send('/mouse',{action:'leftClick'});$('#rightClick').onclick=()=>send('/mouse',{action:'rightClick'});
$$('[data-action]').forEach(b=>b.onclick=()=>send('/action',{action:b.dataset.action}));
$$('[data-workshop]').forEach(b=>b.onclick=()=>send('/workshop',{action:b.dataset.workshop}));
const pad=$('#pad');let prev=null;pad.addEventListener('pointerdown',e=>{prev={x:e.clientX,y:e.clientY};pad.setPointerCapture(e.pointerId)});pad.addEventListener('pointermove',e=>{if(!prev)return;const now=performance.now();if(now-lastMove<25)return;lastMove=now;const dx=e.clientX-prev.x,dy=e.clientY-prev.y;prev={x:e.clientX,y:e.clientY};if(Math.abs(dx)+Math.abs(dy)>0)send('/mouse',{action:'move',dx,dy})});const end=()=>prev=null;pad.addEventListener('pointerup',end);pad.addEventListener('pointercancel',end);
if('serviceWorker' in navigator && location.protocol.startsWith('https'))navigator.serviceWorker.register('sw.js').catch(()=>{});
