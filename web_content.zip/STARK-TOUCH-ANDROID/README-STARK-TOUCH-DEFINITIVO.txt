# STARK TOUCH DEFINITIVO

Actualización de la interfaz móvil: núcleo holográfico azul/naranja, paneles técnicos, teclado QWERTY español y dial circular a la izquierda del teclado. El dial se puede tocar o deslizar para alternar entre ESPAÑOL, SÍMBOLOS, GRIEGO y MATEMÁTICA.

El proyecto incluye el puente Windows en `windows-bridge`. La conexión usa la red local y no necesita Internet una vez instalados los componentes.

Importante: este archivo ZIP es el código fuente Android, no un APK compilado. Para instalarlo como aplicación normal todavía hay que compilarlo en un entorno Android. Los controles de taller envían eventos genéricos; no están conectados automáticamente al taller real de MARK 1 y no modifican sus archivos ni su interfaz.
