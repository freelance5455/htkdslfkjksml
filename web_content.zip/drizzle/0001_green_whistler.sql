CREATE TABLE `schedules` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(160) NOT NULL,
	`location` varchar(160) NOT NULL,
	`shift` varchar(80) NOT NULL,
	`startAt` timestamp NOT NULL,
	`endAt` timestamp NOT NULL,
	`status` enum('scheduled','in-progress','completed') NOT NULL DEFAULT 'scheduled',
	`assigneeName` varchar(120) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `schedules_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `teamMembers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(120) NOT NULL,
	`initials` varchar(4) NOT NULL,
	`role` enum('owner','admin','trainee','recruiter','technician','user') NOT NULL DEFAULT 'technician',
	`rank` varchar(80) NOT NULL,
	`status` enum('available','on-shift','away') NOT NULL DEFAULT 'available',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `teamMembers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `role` enum('owner','admin','trainee','recruiter','technician','user') NOT NULL DEFAULT 'trainee';