CREATE TABLE `workspaceAccounts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(120) NOT NULL,
	`email` varchar(320) NOT NULL,
	`role` enum('owner','admin','trainee','recruiter','technician','user') NOT NULL DEFAULT 'trainee',
	`createdBy` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `workspaceAccounts_id` PRIMARY KEY(`id`),
	CONSTRAINT `workspaceAccounts_email_unique` UNIQUE(`email`)
);
