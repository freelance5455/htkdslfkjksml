ALTER TABLE `workspaceAccounts` ADD `username` varchar(64);--> statement-breakpoint
ALTER TABLE `workspaceAccounts` ADD CONSTRAINT `workspaceAccounts_username_unique` UNIQUE(`username`);