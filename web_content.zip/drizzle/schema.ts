import { boolean, int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/** Legacy starter identity table is retained for migration compatibility; dashboard auth does not use it. */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const adminAccounts = mysqlTable("admin_accounts", {
  id: int("id").autoincrement().primaryKey(),
  email: varchar("email", { length: 320 }).notNull().unique(),
  displayName: varchar("display_name", { length: 120 }).notNull(),
  passwordHash: varchar("password_hash", { length: 128 }).notNull(),
  passwordSalt: varchar("password_salt", { length: 64 }).notNull(),
  totpCiphertext: text("totp_ciphertext").notNull(),
  recoveryCodes: text("recovery_codes").notNull(),
  role: mysqlEnum("admin_role", ["owner", "admin", "analyst", "support"]).default("admin").notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  failedAttempts: int("failed_attempts").default(0).notNull(),
  lockedUntil: timestamp("locked_until"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  lastLoginAt: timestamp("last_login_at"),
});
export type AdminAccount = typeof adminAccounts.$inferSelect;
export type AdminRole = AdminAccount["role"];

export const bootstrapClaims = mysqlTable("admin_bootstrap_claims", {
  claim: varchar("claim", { length: 32 }).primaryKey(),
  claimedAt: timestamp("claimed_at").defaultNow().notNull(),
});

export const adminSessions = mysqlTable("admin_sessions", {
  tokenHash: varchar("token_hash", { length: 64 }).primaryKey(),
  adminId: int("admin_id").notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const adminChallenges = mysqlTable("admin_mfa_challenges", {
  tokenHash: varchar("token_hash", { length: 64 }).primaryKey(),
  adminId: int("admin_id").notNull(),
  attempts: int("attempts").default(0).notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const adminInvitations = mysqlTable("admin_invitations", {
  tokenHash: varchar("token_hash", { length: 64 }).primaryKey(),
  email: varchar("email", { length: 320 }).notNull(),
  role: mysqlEnum("invite_role", ["admin", "analyst", "support"]).notNull(),
  resetAdminId: int("reset_admin_id"),
  createdBy: varchar("created_by", { length: 320 }).notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const featureSettings = mysqlTable("admin_feature_settings", {
  key: varchar("key", { length: 64 }).primaryKey(),
  label: varchar("label", { length: 120 }).notNull(),
  description: text("description").notNull(),
  enabled: boolean("enabled").default(false).notNull(),
  updatedBy: varchar("updated_by", { length: 320 }).notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export const announcements = mysqlTable("admin_announcements", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 160 }).notNull(),
  body: text("body").notNull(),
  status: mysqlEnum("announcement_status", ["draft", "published"]).default("draft").notNull(),
  publishAt: timestamp("publish_at"),
  createdBy: varchar("created_by", { length: 320 }).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export const releases = mysqlTable("admin_releases", {
  id: int("id").autoincrement().primaryKey(),
  version: varchar("version", { length: 48 }).notNull(),
  platform: mysqlEnum("platform", ["android", "ios", "backend"]).notNull(),
  status: mysqlEnum("release_status", ["planned", "review", "live", "paused"]).default("planned").notNull(),
  notes: text("notes").notNull(),
  releaseDate: timestamp("release_date"),
  createdBy: varchar("created_by", { length: 320 }).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const auditEvents = mysqlTable("admin_audit_events", {
  id: int("id").autoincrement().primaryKey(),
  actorEmail: varchar("actor_email", { length: 320 }).notNull(),
  action: varchar("action", { length: 80 }).notNull(),
  resourceType: varchar("resource_type", { length: 80 }).notNull(),
  summary: varchar("summary", { length: 500 }).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
