import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

export const WORK_ROLES = ["owner", "admin", "trainee", "recruiter", "technician", "user"] as const;
export type WorkRole = (typeof WORK_ROLES)[number];

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", WORK_ROLES).default("trainee").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const schedules = mysqlTable("schedules", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 160 }).notNull(),
  location: varchar("location", { length: 160 }).notNull(),
  shift: varchar("shift", { length: 80 }).notNull(),
  startAt: timestamp("startAt").notNull(),
  endAt: timestamp("endAt").notNull(),
  status: mysqlEnum("status", ["scheduled", "in-progress", "completed"] as const).default("scheduled").notNull(),
  assigneeName: varchar("assigneeName", { length: 120 }).notNull(),
  assigneeAccountId: int("assigneeAccountId"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const workspaceAccounts = mysqlTable("workspaceAccounts", {
  id: int("id").autoincrement().primaryKey(),
  username: varchar("username", { length: 64 }).unique(),
  name: varchar("name", { length: 120 }).notNull(),
  email: varchar("email", { length: 320 }).notNull().unique(),
  passwordHash: varchar("passwordHash", { length: 220 }),
  role: mysqlEnum("role", WORK_ROLES).default("trainee").notNull(),
  createdBy: int("createdBy").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const teamMembers = mysqlTable("teamMembers", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 120 }).notNull(),
  initials: varchar("initials", { length: 4 }).notNull(),
  role: mysqlEnum("role", WORK_ROLES).default("technician").notNull(),
  rank: varchar("rank", { length: 80 }).notNull(),
  status: mysqlEnum("status", ["available", "on-shift", "away"] as const).default("available").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const passwordResetRequests = mysqlTable("passwordResetRequests", {
  id: int("id").autoincrement().primaryKey(),
  identifier: varchar("identifier", { length: 320 }).notNull(),
  status: mysqlEnum("status", ["pending", "resolved"] as const).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  resolvedAt: timestamp("resolvedAt"),
  resolvedBy: int("resolvedBy"),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Schedule = typeof schedules.$inferSelect;
export type TeamMember = typeof teamMembers.$inferSelect;
export type WorkspaceAccount = typeof workspaceAccounts.$inferSelect;
export type PasswordResetRequest = typeof passwordResetRequests.$inferSelect;
