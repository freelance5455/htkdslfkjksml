ALTER TABLE `admin_accounts` ADD `is_active` boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE `admin_invitations` ADD `reset_admin_id` int;