CREATE TABLE `like_requests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`playerId` varchar(15) NOT NULL,
	`amount` int NOT NULL DEFAULT 200,
	`status` enum('pending','confirmed','error') NOT NULL,
	`message` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `like_requests_id` PRIMARY KEY(`id`)
);
