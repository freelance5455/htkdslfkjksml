CREATE TABLE `admin_accounts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`email` varchar(320) NOT NULL,
	`display_name` varchar(120) NOT NULL,
	`password_hash` varchar(128) NOT NULL,
	`password_salt` varchar(64) NOT NULL,
	`totp_ciphertext` text NOT NULL,
	`recovery_codes` text NOT NULL,
	`admin_role` enum('owner','admin','analyst','support') NOT NULL DEFAULT 'admin',
	`failed_attempts` int NOT NULL DEFAULT 0,
	`locked_until` timestamp,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`last_login_at` timestamp,
	CONSTRAINT `admin_accounts_id` PRIMARY KEY(`id`),
	CONSTRAINT `admin_accounts_email_unique` UNIQUE(`email`)
);
--> statement-breakpoint
CREATE TABLE `admin_mfa_challenges` (
	`token_hash` varchar(64) NOT NULL,
	`admin_id` int NOT NULL,
	`attempts` int NOT NULL DEFAULT 0,
	`expires_at` timestamp NOT NULL,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `admin_mfa_challenges_token_hash` PRIMARY KEY(`token_hash`)
);
--> statement-breakpoint
CREATE TABLE `admin_invitations` (
	`token_hash` varchar(64) NOT NULL,
	`email` varchar(320) NOT NULL,
	`invite_role` enum('admin','analyst','support') NOT NULL,
	`created_by` varchar(320) NOT NULL,
	`expires_at` timestamp NOT NULL,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `admin_invitations_token_hash` PRIMARY KEY(`token_hash`)
);
--> statement-breakpoint
CREATE TABLE `admin_sessions` (
	`token_hash` varchar(64) NOT NULL,
	`admin_id` int NOT NULL,
	`expires_at` timestamp NOT NULL,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `admin_sessions_token_hash` PRIMARY KEY(`token_hash`)
);
--> statement-breakpoint
CREATE TABLE `admin_announcements` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(160) NOT NULL,
	`body` text NOT NULL,
	`announcement_status` enum('draft','published') NOT NULL DEFAULT 'draft',
	`publish_at` timestamp,
	`created_by` varchar(320) NOT NULL,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `admin_announcements_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `admin_audit_events` (
	`id` int AUTO_INCREMENT NOT NULL,
	`actor_email` varchar(320) NOT NULL,
	`action` varchar(80) NOT NULL,
	`resource_type` varchar(80) NOT NULL,
	`summary` varchar(500) NOT NULL,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `admin_audit_events_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `admin_bootstrap_claims` (
	`claim` varchar(32) NOT NULL,
	`claimed_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `admin_bootstrap_claims_claim` PRIMARY KEY(`claim`)
);
--> statement-breakpoint
CREATE TABLE `admin_feature_settings` (
	`key` varchar(64) NOT NULL,
	`label` varchar(120) NOT NULL,
	`description` text NOT NULL,
	`enabled` boolean NOT NULL DEFAULT false,
	`updated_by` varchar(320) NOT NULL,
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `admin_feature_settings_key` PRIMARY KEY(`key`)
);
--> statement-breakpoint
CREATE TABLE `admin_releases` (
	`id` int AUTO_INCREMENT NOT NULL,
	`version` varchar(48) NOT NULL,
	`platform` enum('android','ios','backend') NOT NULL,
	`release_status` enum('planned','review','live','paused') NOT NULL DEFAULT 'planned',
	`notes` text NOT NULL,
	`release_date` timestamp,
	`created_by` varchar(320) NOT NULL,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `admin_releases_id` PRIMARY KEY(`id`)
);
