# BuildTrack – Expense Tracker

An offline-first expense tracker prototype designed for Android-sized screens.

## Included
- Three bottom-navigation screens: Add, Expenses, Analytics
- Expense type combo box with inline Add New and duplicate prevention
- Date, recipient, details, payment-proof Yes/No
- Multiple image attachments stored with each expense in browser IndexedDB
- Listing filters: search, type, proof status, date range, sorting
- Filtered total and CSV export
- Pie chart by category, monthly bar chart, proof summary
- Offline caching via service worker

## Run locally
Serve this folder over localhost or HTTPS (service workers require a secure context):

```bash
python3 -m http.server 8080
```

Open `http://localhost:8080` in Chrome. On Android Chrome, open the hosted HTTPS URL and choose **Install app** / **Add to Home screen**.

## Important storage note
Data and proof images are stored in the browser's local IndexedDB on that device. Clearing browser/site data can erase them. CSV export currently exports expense fields and proof filenames, not the image bytes. Use a device backup before clearing data.

## APK build
This folder is a functional installable web-app prototype, not a compiled APK. To produce a native APK, wrap this web app with Capacitor in an environment with Android Studio, Android SDK and Gradle installed. Those Android build tools are not available in the creation environment used for this delivery.
