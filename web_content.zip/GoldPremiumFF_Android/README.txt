GOLD PREMIUM FF — Android WebView project
==========================================

Target minimum: Android 8.0 (API 26)
App RAM footprint: small; actual usage depends on device/browser WebView.
This is a standalone simulator/settings UI. It does not connect to, modify,
inject into, or automate Free Fire.

BUILD APK
---------
1. Install Android Studio (with Android SDK 34) and JDK 17.
2. Open this folder (GoldPremiumFF_Android) in Android Studio.
3. Allow Gradle sync to finish.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK will be in app/build/outputs/apk/debug/app-debug.apk.

Notes:
- The project uses a local HTML file inside app/src/main/assets.
- No internet permission is requested.
- This is a source project, not a prebuilt/signed APK.
