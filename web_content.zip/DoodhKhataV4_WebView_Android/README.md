# Doodh Khata V4 — Android WebView

This is a complete Android Studio project. The V4 web app is bundled at:
`app/src/main/assets/index.html`

## Build in Android Studio
1. Open the project folder `DoodhKhataV4`.
2. Let Gradle sync finish.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The debug APK is normally under `app/build/outputs/apk/debug/`.

## App data
Customer data is stored locally in WebView `localStorage` under `doodh_khata_v4`.
No internet permission is required.
