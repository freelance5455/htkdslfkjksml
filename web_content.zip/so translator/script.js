// Append this inside your <script> tags to manage UI and network logic
function logToConsole(text, type = '') {
    const consoleEl = document.getElementById('console');
    const line = document.createElement('div');
    line.className = `console-line ${type}`;
    line.innerText = text;
    consoleEl.appendChild(line);
    consoleEl.scrollTop = consoleEl.scrollHeight; // Auto scroll
}

async function triggerTranslation() {
    const code = document.getElementById('editor').value;
    const dot = document.getElementById('dot');
    const statusText = document.getElementById('status-text');
    
    // UI Feedback
    dot.style.backgroundColor = '#f59e0b'; // Amber compiling color
    statusText.innerText = 'Compiling...';
    logToConsole('⏳ Sending translation payload to compiler...', 'console-sys');

    try {
        const response = await fetch('http://localhost:3000/compile', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ code: code })
        });
        
        const result = await response.json();
        
        if (response.ok) {
            logToConsole(`✅ Success! Binary written to: ${result.path}`);
            dot.style.backgroundColor = 'var(--success)';
            statusText.innerText = 'Ready';
        } else {
            throw new Error(result.error);
        }
    } catch (err) {
        logToConsole(`❌ Error: ${err.message}`, 'console-err');
        dot.style.backgroundColor = 'var(--error)';
        statusText.innerText = 'Failed';
    }
}
