# Mall & Garment Shop 3D — Android project

This project packages the current playable HTML game as a native Android app using a local WebView. The game works offline and stores progress locally on the device.

## Build an APK/AAB
1. Install Android Studio (latest stable) with Android SDK Platform 35 and Build Tools.
2. Open this folder as a project.
3. Let Gradle sync.
4. For testing: Build > Build APK(s).
5. For Google Play: Build > Generate Signed Bundle / APK > Android App Bundle (AAB), create/select a release keystore, and build the release bundle.

## Play Store checklist
- Create a Google Play Console developer account and complete the required account verification.
- Use a unique package/application ID if this is your final production identity.
- Add app icon, screenshots, short/full descriptions, category, content rating, target audience and Data safety details.
- Because this build does not send game data to a server, the game itself does not need an account or network backend. If analytics, ads, cloud saves, payments or online services are added later, update the privacy policy and Data safety declaration accordingly.
- Test the release AAB on multiple Android phones before publishing.

## Important
This source project is ready for Android Studio, but a signed production AAB/APK cannot be produced in this environment because the Android SDK/Gradle build toolchain is not installed here.
