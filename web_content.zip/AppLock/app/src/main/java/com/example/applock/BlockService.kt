package com.example.applock
import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast
class BlockService : AccessibilityService() {
    // Settings and installer are also blocked during a lock so the service can't be turned off or the app uninstalled
    private val guard = setOf("com.android.settings", "com.google.android.packageinstaller", "com.android.packageinstaller")
    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName || !Store.isActive(this)) return
        if (pkg in Store.pkgs(this) || pkg in guard) {
            performGlobalAction(GLOBAL_ACTION_HOME)
            val mins = (Store.end(this) - Store.now(this)) / 60000 + 1
            Toast.makeText(this, "Blocked: $mins min left", Toast.LENGTH_SHORT).show()
        }
    }
    override fun onInterrupt() {}
}
