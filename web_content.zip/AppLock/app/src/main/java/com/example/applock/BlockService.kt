package com.example.applock
import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast
class BlockService : AccessibilityService() {
    // Settings and installer are also blocked (if enabled) so the service can't be turned off or the app uninstalled
    private val guard = setOf("com.android.settings", "com.google.android.packageinstaller", "com.android.packageinstaller")
    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName || !Store.isActive(this)) return
        if (pkg in Store.pkgs(this) || (Store.guard(this) && pkg in guard)) {
            performGlobalAction(GLOBAL_ACTION_HOME)
            Handler(Looper.getMainLooper()).postDelayed({
                try {
                    startActivity(Intent(this, BlockActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION))
                } catch (x: Exception) {
                    Toast.makeText(this, "Blocked", Toast.LENGTH_SHORT).show()
                }
            }, 150)
        }
    }
    override fun onInterrupt() {}
}
