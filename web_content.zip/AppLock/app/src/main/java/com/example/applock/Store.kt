package com.example.applock
import android.content.Context
object Store {
    private fun p(c: Context) = c.getSharedPreferences("lock", 0)
    // setting the clock back will not break the lock
    fun now(c: Context): Long {
        val t = maxOf(System.currentTimeMillis(), p(c).getLong("seen", 0))
        p(c).edit().putLong("seen", t).apply(); return t
    }
    fun end(c: Context) = p(c).getLong("end", 0)
    fun isActive(c: Context) = now(c) < end(c)
    fun pkgs(c: Context): Set<String> = p(c).getStringSet("pkgs", emptySet()) ?: emptySet()
    fun last(c: Context): Set<String> = p(c).getStringSet("last", emptySet()) ?: emptySet()
    fun guard(c: Context) = p(c).getBoolean("guard", true)
    fun dur(c: Context) = p(c).getLong("dur", 1)
    fun sessions(c: Context) = p(c).getInt("sessions", 0)
    fun totalMin(c: Context) = p(c).getLong("totalMin", 0)
    fun start(c: Context, pkgs: Set<String>, minutes: Int, guard: Boolean) {
        val e = p(c).edit()
        e.putStringSet("pkgs", HashSet(pkgs)).putStringSet("last", HashSet(pkgs))
        e.putLong("end", now(c) + minutes * 60_000L).putLong("dur", minutes * 60_000L).putBoolean("guard", guard)
        e.putInt("sessions", sessions(c) + 1).putLong("totalMin", totalMin(c) + minutes).apply()
    }
}
