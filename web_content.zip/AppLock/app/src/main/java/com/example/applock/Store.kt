package com.example.applock
import android.content.Context
object Store {
    private fun p(c: Context) = c.getSharedPreferences("lock", 0)
    // setting the clock back will not break the lock
    fun now(c: Context): Long {
        val t = maxOf(System.currentTimeMillis(), p(c).getLong("seen", 0))
        p(c).edit().putLong("seen", t).apply(); return t
    }
    fun end(c: Context) = p(c).getLong("end", 0)
    fun isActive(c: Context) = now(c) < end(c)
    fun pkgs(c: Context): Set<String> = p(c).getStringSet("pkgs", emptySet()) ?: emptySet()
    fun start(c: Context, pkgs: Set<String>, minutes: Int) =
        p(c).edit().putStringSet("pkgs", pkgs).putLong("end", now(c) + minutes * 60_000L).apply()
}
