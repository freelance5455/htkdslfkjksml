package com.example.applock
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
class MainActivity : Activity() {
    private var web: WebView? = null
    override fun onResume() {
        super.onResume()
        web?.evaluateJavascript("if(window.reloadApps)reloadApps()", null)
    }
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.parseColor("#0A0A0A")
        window.navigationBarColor = Color.parseColor("#0A0A0A")
        val w = WebView(this); web = w; w.setBackgroundColor(Color.parseColor("#0A0A0A")); setContentView(w)
        w.settings.javaScriptEnabled = true
        w.addJavascriptInterface(Bridge(), "Android")
        w.loadUrl("file:///android_asset/index.html")
    }
    inner class Bridge {
        private var diag = ""
        @JavascriptInterface fun getApps(): String {
            diag = ""
            val pm = packageManager
            val map = LinkedHashMap<String, String>()
            var a = 0; var b = 0
            try {
                val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                for (r in pm.queryIntentActivities(i, 0)) { map[r.activityInfo.packageName] = r.loadLabel(pm).toString(); a++ }
            } catch (e: Exception) { diag += "query error: ${e.message} " }
            try {
                for (ai in pm.getInstalledApplications(0)) {
                    if (!map.containsKey(ai.packageName) && pm.getLaunchIntentForPackage(ai.packageName) != null) {
                        map[ai.packageName] = ai.loadLabel(pm).toString(); b++
                    }
                }
            } catch (e: Exception) { diag += "installed error: ${e.message} " }
            map.remove(packageName)
            diag = "${Build.MANUFACTURER} Android ${Build.VERSION.SDK_INT} | launcher=$a extra=$b | " + diag
            val arr = JSONArray()
            map.entries.sortedBy { it.value.lowercase() }.forEach {
                arr.put(JSONObject().put("name", it.value).put("pkg", it.key))
            }
            return arr.toString()
        }
        @JavascriptInterface fun getDiag(): String = diag
        @JavascriptInterface fun openAppSettings() {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        @JavascriptInterface fun getIcon(pkg: String): String {
            val d = packageManager.getApplicationIcon(pkg)
            val bmp = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888)
            d.setBounds(0, 0, 96, 96); d.draw(Canvas(bmp))
            val o = ByteArrayOutputStream(); bmp.compress(Bitmap.CompressFormat.PNG, 100, o)
            return Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
        }
        @JavascriptInterface fun getLast(): String = JSONArray(Store.last(this@MainActivity).toList()).toString()
        @JavascriptInterface fun startLock(pkgs: String, minutes: Int, guard: Boolean): Boolean {
            if (Store.isActive(this@MainActivity)) return false
            val a = JSONArray(pkgs); val s = HashSet<String>()
            for (k in 0 until a.length()) s.add(a.getString(k))
            Store.start(this@MainActivity, s, minutes, guard); return true
        }
        @JavascriptInterface fun status(): String {
            val c = this@MainActivity
            val on = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
                ?.contains(packageName) == true
            return JSONObject().put("active", Store.isActive(c))
                .put("left", maxOf(0L, Store.end(c) - Store.now(c))).put("total", Store.dur(c))
                .put("pkgs", JSONArray(Store.pkgs(c).toList())).put("sessions", Store.sessions(c))
                .put("totalMin", Store.totalMin(c)).put("serviceOn", on).toString()
        }
        @JavascriptInterface fun openAccessibility() {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }
}
