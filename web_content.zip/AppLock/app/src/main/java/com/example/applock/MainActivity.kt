package com.example.applock
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.parseColor("#0A0A0A")
        window.navigationBarColor = Color.parseColor("#0A0A0A")
        val w = WebView(this); w.setBackgroundColor(Color.parseColor("#0A0A0A")); setContentView(w)
        w.settings.javaScriptEnabled = true
        w.addJavascriptInterface(Bridge(), "Android")
        w.loadUrl("file:///android_asset/index.html")
    }
    inner class Bridge {
        @JavascriptInterface fun getApps(): String {
            val pm = packageManager
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val arr = JSONArray(); val seen = HashSet<String>()
            pm.queryIntentActivities(i, 0).filter { it.activityInfo.packageName != packageName }
                .sortedBy { it.loadLabel(pm).toString().lowercase() }
                .forEach {
                    if (seen.add(it.activityInfo.packageName))
                        arr.put(JSONObject().put("name", it.loadLabel(pm).toString()).put("pkg", it.activityInfo.packageName))
                }
            return arr.toString()
        }
        @JavascriptInterface fun getIcon(pkg: String): String {
            val d = packageManager.getApplicationIcon(pkg)
            val bmp = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888)
            d.setBounds(0, 0, 96, 96); d.draw(Canvas(bmp))
            val o = ByteArrayOutputStream(); bmp.compress(Bitmap.CompressFormat.PNG, 100, o)
            return Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
        }
        @JavascriptInterface fun getLast(): String = JSONArray(Store.last(this@MainActivity).toList()).toString()
        @JavascriptInterface fun startLock(pkgs: String, minutes: Int, guard: Boolean): Boolean {
            if (Store.isActive(this@MainActivity)) return false
            val a = JSONArray(pkgs); val s = HashSet<String>()
            for (k in 0 until a.length()) s.add(a.getString(k))
            Store.start(this@MainActivity, s, minutes, guard); return true
        }
        @JavascriptInterface fun status(): String {
            val c = this@MainActivity
            val on = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
                ?.contains(packageName) == true
            return JSONObject().put("active", Store.isActive(c))
                .put("left", maxOf(0L, Store.end(c) - Store.now(c))).put("total", Store.dur(c))
                .put("pkgs", JSONArray(Store.pkgs(c).toList())).put("sessions", Store.sessions(c))
                .put("totalMin", Store.totalMin(c)).put("serviceOn", on).toString()
        }
        @JavascriptInterface fun openAccessibility() {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }
}
