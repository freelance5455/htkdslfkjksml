package com.example.applock
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val w = WebView(this); setContentView(w)
        w.settings.javaScriptEnabled = true
        w.addJavascriptInterface(Bridge(), "Android")
        w.loadUrl("file:///android_asset/index.html")
    }
    inner class Bridge {
        @JavascriptInterface fun getApps(): String {
            val pm = packageManager
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val arr = JSONArray()
            pm.queryIntentActivities(i, 0).filter { it.activityInfo.packageName != packageName }
                .sortedBy { it.loadLabel(pm).toString().lowercase() }
                .forEach { arr.put(JSONObject().put("name", it.loadLabel(pm).toString()).put("pkg", it.activityInfo.packageName)) }
            return arr.toString()
        }
        @JavascriptInterface fun startLock(pkgs: String, minutes: Int): Boolean {
            if (Store.isActive(this@MainActivity)) return false
            val a = JSONArray(pkgs); val s = HashSet<String>()
            for (k in 0 until a.length()) s.add(a.getString(k))
            Store.start(this@MainActivity, s, minutes); return true
        }
        @JavascriptInterface fun status(): String {
            val on = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
                ?.contains(packageName) == true
            return JSONObject().put("active", Store.isActive(this@MainActivity))
                .put("left", maxOf(0, Store.end(this@MainActivity) - Store.now(this@MainActivity)))
                .put("serviceOn", on).toString()
        }
        @JavascriptInterface fun openAccessibility() {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }
}
