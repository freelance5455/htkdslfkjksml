package com.example.applock
import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
class BlockActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var t: TextView
    private fun tv(s: String, sz: Float, c: Int) = TextView(this).apply {
        text = s; textSize = sz; setTextColor(c); gravity = Gravity.CENTER; setPadding(0, 16, 0, 16)
    }
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val l = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setBackgroundColor(0xFF0A0A0A.toInt()); setPadding(60, 60, 60, 60)
        }
        t = tv("", 44f, 0xFFE10600.toInt())
        l.addView(tv("\uD83D\uDD12", 64f, Color.WHITE))
        l.addView(tv("This app is blocked", 24f, Color.WHITE))
        l.addView(t)
        l.addView(tv("Time left. Stay locked in.", 14f, 0xFF9A9A9A.toInt()))
        setContentView(l)
    }
    private val tick = object : Runnable {
        override fun run() {
            val left = (Store.end(this@BlockActivity) - Store.now(this@BlockActivity)) / 1000
            if (left <= 0) { finish(); return }
            t.text = String.format("%02d:%02d:%02d", left / 3600, left % 3600 / 60, left % 60)
            h.postDelayed(this, 1000)
        }
    }
    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }
}
