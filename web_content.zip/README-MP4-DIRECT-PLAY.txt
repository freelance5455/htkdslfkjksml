DHRUV MOVIES - MP4 DIRECT PLAY

This build is prepared for direct browser playback of authorized MP4 video files.

1. Open app/src/main/assets/index.html
2. Find: const LOCAL_STREAM_VIDEO_URL=''
3. Put the DIRECT .mp4 file URL between the quotes.
4. Rebuild and install the APK.

Example format:
const LOCAL_STREAM_VIDEO_URL='http://YOUR-SERVER/video.mp4';

The URL must return the actual MP4 file. A LocalStream web-player page or /api/media JSON URL will not work as the <video> source.
For best Android WebView compatibility use MP4 with H.264 video + AAC audio.
