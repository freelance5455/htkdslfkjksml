Anis Muslim: Android native reminder bridge (integration patch)

IMPORTANT
This is Android source integration material, not a rebuilt APK. The current HTML-only WebView package cannot install native Android alarms by itself. The host Android app must include these Kotlin files, AndroidX Core dependency for NotificationCompat, manifest permissions/receiver, and runtime permission handling for POST_NOTIFICATIONS on Android 13+.

WebView host setup:
1) Add: webView.addJavascriptInterface(ReminderBridge(context), "AndroidReminderBridge")
2) Add runtime notification permission request on Android 13+ before enabling reminders.
3) Add the manifest snippet; merge into the app's existing manifest (do not paste a second <application> block).
4) Ensure exact-alarm permission/availability on Android 12+ and guide the user to allow it if required.
5) The HTML settings page must call scheduleDaily(key, hour, minute, title, body) for enabled reminders and cancel(key) for disabled ones. Quiet-hours logic must be passed/enforced by native code before production; this patch currently schedules daily reminders without quiet-hour enforcement.
6) Test on the actual Android wrapper: app closed, device reboot, notification permission denied/granted, exact alarm permission unavailable, and timezone/DST changes.

Current source package is PWA/WebView content only. Native reminders cannot be made reliable by HTML changes alone in appassets:// or file-backed WebViews.
HTML bridge hook included in this patch: the settings-save path forwards enabled daily reminders to AndroidReminderBridge.scheduleDaily; disabled items call cancel; the global disable button calls cancelAll. Quiet-hours times are passed to the receiver and checked at firing time. Native runtime permission request still must be implemented by the host Activity (this JavaScript bridge intentionally cannot prompt Android runtime permissions itself).

Host Activity requirements (pseudo):
- Before setting up WebView, request POST_NOTIFICATIONS at runtime on Android 13+.
- webView.settings.javaScriptEnabled = true
- webView.addJavascriptInterface(ReminderBridge(this), "AndroidReminderBridge")
- Integrate Kotlin files into app module, add AndroidX Core dependency, merge manifest entries.
