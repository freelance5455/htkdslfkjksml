package com.anismuslim.notifications

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

object DailyReminderScheduler {
    private const val PREFS = "anis_native_daily_reminders"
    private fun id(key: String) = (key.hashCode() and 0x7fffffff).coerceAtLeast(1)
    private fun pending(context: Context, key: String, title: String = "", body: String = ""): PendingIntent {
        val intent = Intent(context, DailyReminderReceiver::class.java).apply {
            action = "com.anismuslim.DAILY_REMINDER.$key"
            putExtra("key", key); putExtra("title", title); putExtra("body", body)
        }
        return PendingIntent.getBroadcast(context, id(key), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
    fun schedule(context: Context, key: String, hour: Int, minute: Int, title: String, body: String, quietStart: String = "22:00", quietEnd: String = "06:00") {
        val safeHour = hour.coerceIn(0,23); val safeMinute = minute.coerceIn(0,59)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putStringSet("keys", (context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getStringSet("keys", emptySet()) ?: emptySet()) + key).putString("time_$key", String.format("%02d:%02d", safeHour, safeMinute)).putString("quietStart_$key", quietStart).putString("quietEnd_$key", quietEnd).apply()
        val cal = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY,safeHour); set(Calendar.MINUTE,safeMinute); set(Calendar.SECOND,0); set(Calendar.MILLISECOND,0); if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DATE,1) }
        val alarm = context.getSystemService(AlarmManager::class.java)
        val pi = pending(context,key,title,body)
        if (Build.VERSION.SDK_INT >= 23) alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi) else alarm.setExact(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
    }
    fun cancel(context: Context, key: String) {
        context.getSystemService(AlarmManager::class.java).cancel(pending(context,key))
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit().putStringSet("keys", (prefs.getStringSet("keys", emptySet()) ?: emptySet()) - key).apply()
    }
    fun cancelAll(context: Context) { val prefs=context.getSharedPreferences(PREFS,Context.MODE_PRIVATE); (prefs.getStringSet("keys",emptySet()) ?: emptySet()).toList().forEach { cancel(context,it) } }
    fun rescheduleTomorrow(context: Context, key: String, hour: Int, minute: Int, title: String, body: String, quietStart: String = "22:00", quietEnd: String = "06:00") = schedule(context,key,hour,minute,title,body,quietStart,quietEnd)
}
