package com.anismuslim.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import java.util.Calendar

class DailyReminderReceiver : BroadcastReceiver() {
    private fun isQuietNow(now: Calendar, start: String, end: String): Boolean {
        fun mins(s: String): Int { val p=s.split(":"); return (p.getOrNull(0)?.toIntOrNull() ?: 22)*60+(p.getOrNull(1)?.toIntOrNull() ?: 0) }
        val n=now.get(Calendar.HOUR_OF_DAY)*60+now.get(Calendar.MINUTE); val a=mins(start); val b=mins(end)
        return if(a==b) false else if(a<b) n>=a && n<b else n>=a || n<b
    }
    override fun onReceive(context: Context, intent: Intent) {
        val key = intent.getStringExtra("key") ?: return
        val title = intent.getStringExtra("title") ?: "تذكير من أَنيس المسلم"
        val body = intent.getStringExtra("body") ?: "لا تنسَ ذكر الله."
        val nm = context.getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("anis_reminders", "تذكيرات أَنيس المسلم", NotificationManager.IMPORTANCE_DEFAULT))
        val launch = context.packageManager.getLaunchIntentForPackage(context.packageName)
        val tap = launch?.let { PendingIntent.getActivity(context, 7001, it, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE) }
        val prefs = context.getSharedPreferences("anis_native_daily_reminders", Context.MODE_PRIVATE)
        val quietStart = prefs.getString("quietStart_$key", "22:00") ?: "22:00"
        val quietEnd = prefs.getString("quietEnd_$key", "06:00") ?: "06:00"
        if (!isQuietNow(Calendar.getInstance(), quietStart, quietEnd)) {
            val notification = NotificationCompat.Builder(context, "anis_reminders")
                .setSmallIcon(context.applicationInfo.icon.takeIf { it != 0 } ?: android.R.drawable.ic_dialog_info)
                .setContentTitle(title).setContentText(body).setAutoCancel(true).setContentIntent(tap).build()
            nm.notify(key.hashCode(), notification)
        }
        // Keep daily recurrence by scheduling the next occurrence.
        val stored = prefs.getString("time_$key", null)
        if (stored != null) {
            val parts=stored.split(":"); if(parts.size==2) DailyReminderScheduler.schedule(context,key,parts[0].toIntOrNull() ?: 8,parts[1].toIntOrNull() ?: 0,title,body,quietStart,quietEnd)
        }
    }
}
