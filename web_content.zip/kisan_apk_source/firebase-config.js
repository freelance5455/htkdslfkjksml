// Firebase Web App configuration. Paste values from Firebase Console > Project settings > Your apps.
// This config is not a password. Keep Firestore security rules enabled as provided.
export const firebaseConfig = {
  apiKey: 'PASTE_API_KEY_HERE',
  authDomain: 'PASTE_PROJECT_ID_HERE.firebaseapp.com',
  projectId: 'PASTE_PROJECT_ID_HERE',
  storageBucket: 'PASTE_PROJECT_ID_HERE.firebasestorage.app',
  messagingSenderId: 'PASTE_MESSAGING_SENDER_ID_HERE',
  appId: 'PASTE_APP_ID_HERE'
};
