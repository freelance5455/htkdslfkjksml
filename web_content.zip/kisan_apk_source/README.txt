KISAN MOTOR & TRACTOR LEDGER — FREE CLOUD-SYNC SOURCE

Important:
- This is a web app source package, not a finished APK.
- Local data is retained in the browser and existing JSON backup/restore remains available.
- Google sign-in + cloud sync needs a Firebase project configured on the FREE Spark plan. This is not Google Drive file storage; it is a private Firestore cloud backup under your Google-authenticated account.
- Free tier has quotas/limits. Google may require billing details for some products; do NOT upgrade to a paid plan for this setup. Stay on Spark/free.
- Do not rely on one copy. Keep downloading JSON backups regularly until cloud sync is tested.

SETUP (one-time; use a computer or suitable online terminal):
1. Open https://console.firebase.google.com and create a project. Keep it on the no-cost Spark plan.
2. Authentication > Sign-in method > enable Google.
3. Firestore Database > create database, then publish rules from firestore.rules.
4. Project settings > General > Your apps > add a Web app and copy its config values into firebase-config.js. Replace every PASTE_... placeholder.
5. Deploy this folder to Firebase Hosting (free Spark hosting quota): install Firebase CLI on a computer/online terminal, run `firebase login`, `firebase init hosting firestore` (choose existing project and current directory), then `firebase deploy`.
6. Open the deployed HTTPS website, first download a JSON backup from the app, then sign in with Google. Check cloud sync status. Test restore on another browser before trusting it.
7. For APK, use an Android WebView/PWA wrapper that points to the deployed HTTPS URL. Do not use a wrapper that embeds the raw local HTML, because Google popup login needs a proper HTTPS origin.

DATA SAFETY:
- The app merges local and cloud rows by record ID on sign-in and then uploads the merged data.
- It syncs after app changes while signed in and online; it is not guaranteed if the app is closed immediately or internet is unavailable.
- Never share your Google password or OAuth client secret. The Firebase web config is public, but the Firestore rules are essential.
- Before real business use, test customer balances, restore, and sign-in carefully. This source has not been production-tested.
