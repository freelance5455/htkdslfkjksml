# Balancing ATM — Android project

Project ini membungkus aplikasi HTML Balancing ATM menjadi aplikasi Android menggunakan WebView.

## Membuat APK
1. Instal Android Studio pada komputer/laptop.
2. Ekstrak ZIP project ini.
3. Android Studio → **Open** → pilih folder `balancing-atm-android`.
4. Tunggu Gradle Sync selesai. Koneksi internet diperlukan saat pertama kali mengunduh Android Gradle Plugin dan SDK.
5. Pilih **Build → Build APK(s)**.
6. APK debug biasanya tersedia di `app/build/outputs/apk/debug/app-debug.apk`.
7. Pindahkan APK ke HP Android, lalu buka file tersebut untuk memasang. Jika diminta, izinkan instalasi aplikasi dari sumber tersebut.

## Catatan
- Aplikasi memuat HTML lokal dari dalam APK.
- Halaman HTML saat ini menggunakan Tailwind CDN, jadi tampilan yang bergantung pada CDN membutuhkan koneksi internet.
- Ini adalah source project Android siap dibuka/build di Android Studio, bukan file APK yang sudah dikompilasi.
