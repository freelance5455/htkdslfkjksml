const CACHE = "ikhtiyari-v1";
const FILES = ["./", "./index.html", "./manifest.webmanifest", "./assets/vegetables.svg", "./assets/fruits.svg", "./assets/dairy.svg", "./assets/cheese.svg", "./assets/hero.svg"];
self.addEventListener("install", event => event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(FILES))));
self.addEventListener("activate", event => event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))));
self.addEventListener("fetch", event => { if (event.request.method === "GET") event.respondWith(caches.match(event.request).then(cached => cached || fetch(event.request))); });
