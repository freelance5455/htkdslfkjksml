module.exports = {
  tokens: "9030848871:AAHTE0ac3mKNi_qeRZNWEAg0i0vE1BzR7EY",// Token bot
  owner: "83177300713"
  port: "2804", // Ubah Jadi Port Panel Mu !!!
  ipvps: "https://taaammmmaaaa.jhonaleytech.web.id" // Ubah Jadi Ip Vps Mu !!!
};