# Chatcloude — ton assistant Claude (web et mobile)

## Ce qui est inclus
- Comptes (inscription/connexion, enregistrés sur l'appareil ; le premier compte est administrateur)
- Discussion avec Claude, mode « Code et apps », envoi de photos
- Historique, tableau d'administration (statistiques)
- Notifications (quand la réponse est prête), boutique (vitrine, sans paiement réel)

## 1. Version web (3 minutes)
1. Installe Node.js (https://nodejs.org).
2. Dans ce dossier : `npm install` puis `npm run web`.
3. Ouvre l'adresse affichée, va dans Réglages et colle ta clé Claude (https://console.anthropic.com). Claude répond ensuite pour de vrai.

## 2. App Android
1. Installe Android Studio.
2. `npm install` puis `npm run android` : Android Studio s'ouvre.
3. Branche ton téléphone (mode développeur) et clique sur Run. Pour publier : Build > Generate Signed Bundle.

## 3. App iPhone
Il faut un Mac avec Xcode et un compte développeur Apple : `npm run ios`.

## Important avant de publier pour d'autres personnes
- La clé API est stockée sur l'appareil : parfait pour toi seul. Pour des clients, crée un petit serveur qui garde la clé et appelle Claude.
- Les comptes sont locaux : pour de vrais comptes partagés, branche une base de données (Supabase, Firebase).
- Paiements (Wave, Stripe), cartes, réservations et vidéo ne sont pas inclus dans cette version.
- Le nom du modèle (Réglages) peut changer : vérifie-le dans la documentation d'Anthropic.
