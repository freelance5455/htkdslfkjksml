const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const STORE_KEY = 'mon-argent-fcfa-v1';
const ACCOUNTS = ['Banque','Espèces','MTN MoMo','Orange Money'];
const COLORS = {income:'#16825c',expense:'#dc716a'};
const fmt = n => new Intl.NumberFormat('fr-FR',{maximumFractionDigits:0}).format(Math.round(Number(n)||0))+' F';
const today = () => new Date().toISOString().slice(0,10);
const monthNow = () => today().slice(0,7);
const id = () => Math.random().toString(36).slice(2,10)+Date.now().toString(36);
const defaultState = () => ({
  version:1,
  openingAccounts:{'Banque':297000,'Espèces':760000,'MTN MoMo':274000,'Orange Money':65000},
  transactions:[],
  cotisations:[],
  company:[
    {id:id(),date:today(),type:'received',category:'Location appareil',amount:682000,account:'Espèces',note:'Solde initial déclaré — déjà compris dans les comptes physiques',opening:true},
    {id:id(),date:today(),type:'received',category:'Vente accessoires appareil',amount:100000,account:'Espèces',note:'Solde initial déclaré — déjà compris dans les comptes physiques',opening:true}
  ],
  forecast:{salary:300000,variable:0,bankFee:1193,otherExpenses:0}
});
let state = loadState();
let installPrompt = null;
function loadState(){try{const x=JSON.parse(localStorage.getItem(STORE_KEY));if(x&&x.version===1)return x;}catch(e){}return defaultState();}
function save(){localStorage.setItem(STORE_KEY,JSON.stringify(state));renderAll();}
function toast(msg){const t=$('#toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2600);}
function escapeHtml(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function monthOf(d){return (d||'').slice(0,7);}
function typeName(t){return ({income:'Revenu personnel',expense:'Dépense personnelle',transfer:'Transfert',company:'Fonds entreprise',cotisation:'Cotisation'})[t]||t;}
function iconFor(t){return ({income:'↗',expense:'↘',transfer:'⇄',company:'▣',cotisation:'◷'})[t]||'•';}
function signedAmount(t,a){return t==='income'?'+ '+fmt(a):t==='expense'?'− '+fmt(a):fmt(a);}
function allMovements(){return [...state.transactions.map(t=>({...t,source:'tx'}))];}
function getAccountBalances(){
 const out={...state.openingAccounts};
 state.transactions.forEach(t=>{
  const a=Number(t.amount)||0;
  if(t.type==='income')out[t.account]=(out[t.account]||0)+a;
  else if(t.type==='expense')out[t.account]=(out[t.account]||0)-a;
  else if(t.type==='transfer'){out[t.account]=(out[t.account]||0)-a;out[t.toAccount]=(out[t.toAccount]||0)+a;}
  else if(t.type==='company'&&t.companyCashEffect){out[t.account]=(out[t.account]||0)+Number(t.companyCashEffect);}
 });
 state.cotisations.forEach(c=>{
  const a=Number(c.amount)||0;
  if(c.action==='paid'||c.action==='expense')out[c.account]=(out[c.account]||0)-a;
  if(c.action==='refund')out[c.account]=(out[c.account]||0)+a;
 });
 state.company.filter(c=>!c.opening).forEach(c=>{
  const a=Number(c.amount)||0;
  if(c.type==='received')out[c.account]=(out[c.account]||0)+a;
  if(c.type==='remitted')out[c.account]=(out[c.account]||0)-a;
  if(c.type==='personal_use')out[c.account]=(out[c.account]||0)-a;
  if(c.type==='repaid')out[c.account]=(out[c.account]||0)+a;
 });
 return out;
}
function companyHeld(){return state.company.reduce((s,c)=>s+(c.type==='received'?+c.amount:0)-(c.type==='remitted'?+c.amount:0)-(c.type==='personal_use'?+c.amount:0),0);}
function companyDebt(){return state.company.reduce((s,c)=>s+(c.type==='personal_use'?+c.amount:0)-(c.type==='repaid'?+c.amount:0),0);}
function cotStats(){
 let outstanding=0,recovered=0,trueExpense=0;
 state.cotisations.forEach(c=>{
  if(c.recoverable){if(c.action==='paid')outstanding+=+c.amount;if(c.action==='refund'){outstanding-=+c.amount;recovered+=+c.amount;}}
  else if(c.action==='expense'||c.action==='paid')trueExpense+=+c.amount;
 });
 return {outstanding,recovered,trueExpense};
}
function personalAvailable(){
 const b=Object.values(getAccountBalances()).reduce((s,v)=>s+v,0);
 return b-companyHeld()-companyDebt()-cotStats().outstanding;
}
function totalsForMonth(m){
 let income=0,expenses=0;
 state.transactions.filter(t=>monthOf(t.date)===m).forEach(t=>{if(t.type==='income')income+=+t.amount;if(t.type==='expense')expenses+=+t.amount;});
 state.cotisations.filter(c=>monthOf(c.date)===m&&!c.recoverable&&(c.action==='paid'||c.action==='expense')).forEach(c=>expenses+=+c.amount);
 return {income,expenses};
}
function monthName(m){return new Date(m+'-02T12:00:00').toLocaleDateString('fr-FR',{month:'short',year:'2-digit'}).replace('.','');}
function renderDashboard(){
 const m=$('#dashboardMonth').value||monthNow(),t=totalsForMonth(m),bal=getAccountBalances();
 $('#personalAvailable').textContent=fmt(personalAvailable());
 $('#totalAccounts').textContent=fmt(Object.values(bal).reduce((a,b)=>a+b,0));
 $('#monthIncome').textContent=fmt(t.income);$('#monthExpenses').textContent=fmt(t.expenses);
 $('#companyDebt').textContent=fmt(companyDebt());$('#companyDebt2').textContent=fmt(companyDebt());
 $('#companyHeld').textContent=fmt(companyHeld());
 const stats=cotStats();$('#cotOutstanding').textContent=fmt(Math.max(0,stats.outstanding));$('#cotRecovered').textContent=fmt(stats.recovered);$('#cotTrueExpense').textContent=fmt(stats.trueExpense);
 $('#accountSummary').innerHTML=ACCOUNTS.map(a=>{const v=bal[a]||0,max=Math.max(1,...Object.values(bal));return `<div class="account-row"><span>${escapeHtml(a)}</span><strong>${fmt(v)}</strong><div class="bar"><i style="width:${Math.max(0,Math.min(100,v/max*100))}%"></i></div></div>`}).join('');
 const rec=[...state.transactions.map(t=>({...t,kind:t.type})),...state.cotisations.map(c=>({...c,label:c.type,kind:'cotisation',type:c.action==='refund'?'income':c.recoverable?'cotisation':'expense'}))].sort((a,b)=>(b.date||'').localeCompare(a.date||'')).slice(0,5);
 $('#recentTransactions').innerHTML=rec.length?rec.map(renderTxRow).join(''):'<div class="empty-state">Aucune opération pour le moment. Ajoute ton premier revenu ou ta première dépense.</div>';
 drawChart();
}
function renderTxRow(t){
 const typ=t.kind==='cotisation'?'cotisation':t.type;
 const amountClass=typ==='income'?'income':typ==='expense'?'expense':'';
 const amountLabel=t.kind==='cotisation'&&t.action==='refund'?'+ '+fmt(t.amount):signedAmount(typ,t.amount);
 const sub=[t.date||'',t.category||t.type||'',t.account||''].filter(Boolean).join(' · ');
 return `<div class="tx-row"><div class="tx-icon ${escapeHtml(typ)}">${iconFor(typ)}</div><div class="tx-main"><strong>${escapeHtml(t.label||t.category||t.type||'Opération')}</strong><small>${escapeHtml(sub)}</small></div><div class="tx-amount ${amountClass}">${amountLabel}</div>${t.source==='tx'?`<div class="tx-actions"><button class="mini-btn" data-edit-tx="${t.id}">Modifier</button><button class="mini-btn" data-delete-tx="${t.id}">✕</button></div>`:''}</div>`;
}
function drawChart(){
 const canvas=$('#cashflowChart');if(!canvas)return;
 const rect=canvas.getBoundingClientRect();const w=Math.max(280,rect.width),h=220,dpr=window.devicePixelRatio||1;
 canvas.width=w*dpr;canvas.height=h*dpr;const c=canvas.getContext('2d');c.scale(dpr,dpr);c.clearRect(0,0,w,h);
 const months=[];const base=new Date((($('#dashboardMonth').value||monthNow())+'-01T12:00:00'));base.setMonth(base.getMonth()-11);
 for(let i=0;i<12;i++){const d=new Date(base);d.setMonth(base.getMonth()+i);months.push(d.toISOString().slice(0,7));}
 const vals=months.map(m=>totalsForMonth(m));const max=Math.max(50000,...vals.flatMap(v=>[v.income,v.expenses]))*1.12;
 const left=32,right=8,top=12,bottom=28,cw=w-left-right,ch=h-top-bottom;
 c.strokeStyle='#e8eee9';c.lineWidth=1;c.fillStyle='#91a097';c.font='10px DM Sans';
 for(let i=0;i<4;i++){const y=top+ch*i/3;c.beginPath();c.moveTo(left,y);c.lineTo(w-right,y);c.stroke();}
 const x=i=>left+(i/(months.length-1))*cw, y=v=>top+ch-(v/max)*ch;
 function line(key,color){c.beginPath();c.strokeStyle=color;c.lineWidth=2.5;c.lineJoin='round';months.forEach((m,i)=>i?c.lineTo(x(i),y(vals[i][key])):c.moveTo(x(i),y(vals[i][key])));c.stroke();months.forEach((m,i)=>{c.beginPath();c.fillStyle=color;c.arc(x(i),y(vals[i][key]),3,0,Math.PI*2);c.fill();});}
 line('income',COLORS.income);line('expenses',COLORS.expense);
 months.forEach((m,i)=>{if(i%2===0||i===11){c.fillStyle='#829188';c.textAlign='center';c.fillText(monthName(m),x(i),h-8);}});
}
function renderTransactions(){
 const q=($('#transactionSearch').value||'').toLowerCase(),filter=$('#transactionFilter').value;
 let arr=[...state.transactions.map(t=>({...t,source:'tx'})),...state.cotisations.map(c=>({...c,label:c.type,category:c.recoverable?'Récupérable':'Définitive',kind:'cotisation',type:c.action==='refund'?'income':c.recoverable?'cotisation':'expense',source:'cot'})),...state.company.map(c=>({...c,label:c.category,kind:'company',type:'company',source:'company'}))];
 arr=arr.filter(t=>(`${t.label||''} ${t.category||''} ${t.note||''}`).toLowerCase().includes(q));
 if(filter==='income'||filter==='expense'||filter==='transfer')arr=arr.filter(t=>t.type===filter);
 else if(filter==='company')arr=arr.filter(t=>t.kind==='company'||t.type==='company');
 else if(filter==='cotisation')arr=arr.filter(t=>t.kind==='cotisation');
 arr.sort((a,b)=>(b.date||'').localeCompare(a.date||''));
 $('#transactionsList').innerHTML=arr.length?arr.map(renderTxRow).join(''):'<div class="empty-state">Aucun résultat. Essaie un autre filtre ou ajoute une opération.</div>';
}
function renderAccounts(){
 const b=getAccountBalances(),tot=Object.values(b).reduce((s,v)=>s+v,0);
 $('#accountsCards').innerHTML=ACCOUNTS.map((a,i)=>`<div class="account-card"><span class="account-name">${['Compte bancaire','Argent liquide','Portefeuille mobile','Portefeuille mobile'][i]}</span><strong>${fmt(b[a]||0)}</strong><span>${a}</span><small>Part du total : ${tot?Math.round((b[a]||0)/tot*100):0}%</small></div>`).join('');
 $('#accountEditFields').innerHTML=ACCOUNTS.map(a=>`<label>${a} (FCFA)<input type="number" min="0" step="1" id="opening-${ACCOUNTS.indexOf(a)}" value="${state.openingAccounts[a]||0}" required></label>`).join('');
}
function renderCotisations(){
 const arr=[...state.cotisations].sort((a,b)=>b.date.localeCompare(a.date));
 $('#cotisationsList').innerHTML=arr.length?arr.map(c=>`<div class="tx-row"><div class="tx-icon ${c.recoverable?'cotisation':'expense'}">${c.action==='refund'?'↩':c.recoverable?'◷':'↘'}</div><div class="tx-main"><strong>${escapeHtml(c.type)} — ${c.action==='refund'?'Récupération':c.action==='expense'?'Dépense définitive':'Versement'}</strong><small>${escapeHtml(c.date)} · ${escapeHtml(c.account)} · ${c.recoverable?'Récupérable':'Non récupérable'}</small></div><div class="tx-amount ${c.action==='refund'?'income':c.recoverable?'':'expense'}">${c.action==='refund'?'+ ':'− '}${fmt(c.amount)}</div><div class="tx-actions"><button class="mini-btn" data-delete-cot="${c.id}">✕</button></div></div>`).join(''):'<div class="empty-state">Aucune cotisation enregistrée.</div>';
}
function renderCompany(){
 const arr=[...state.company].sort((a,b)=>b.date.localeCompare(a.date));
 $('#companyList').innerHTML=arr.map(c=>`<div class="tx-row"><div class="tx-icon company">${c.type==='received'?'↗':c.type==='personal_use'?'!':c.type==='repaid'?'↩':'↘'}</div><div class="tx-main"><strong>${escapeHtml(c.category)} — ${{received:'Réception',remitted:'Reversement',personal_use:'Utilisation personnelle (dette)',repaid:'Remboursement'}[c.type]||c.type}</strong><small>${escapeHtml(c.date)} · ${escapeHtml(c.account||'')} ${c.opening?'· Solde initial':''} ${escapeHtml(c.note||'')}</small></div><div class="tx-amount ${c.type==='received'?'income':c.type==='personal_use'?'expense':''}">${c.type==='received'?'+ ':c.type==='remitted'||c.type==='personal_use'?'− ':''}${fmt(c.amount)}</div><div class="tx-actions">${c.opening?'':`<button class="mini-btn" data-delete-company="${c.id}">✕</button>`}</div></div>`).join('');
}
function forecastCotisation(month){
 const d=new Date(month+'-01T12:00:00'),end=new Date(d.getFullYear(),d.getMonth()+1,0);let mon=0,sat=0,lastSun=0;
 for(let i=1;i<=end.getDate();i++){const x=new Date(d.getFullYear(),d.getMonth(),i);if(x.getDay()===1)mon++;if(x.getDay()===6)sat++;if(x.getDay()===0&&i+7>end.getDate())lastSun=i;}
 return {recoverable:mon*10000+sat*20000+4000,meal:1500};
}
function renderForecasts(){
 const f=state.forecast;$('#forecastSalary').textContent=fmt(f.salary);$('#forecastVariable').textContent=fmt(f.variable);
 let base=new Date(monthNow()+'-01T12:00:00');const rows=[];
 for(let i=0;i<12;i++){const d=new Date(base);d.setMonth(base.getMonth()+i);const m=d.toISOString().slice(0,7),co=forecastCotisation(m),income=+f.salary+(+f.variable),expense=+f.bankFee+(+f.otherExpenses)+co.meal,net=income-expense;
 rows.push(`<tr><td>${escapeHtml(new Date(m+'-02T12:00:00').toLocaleDateString('fr-FR',{month:'long',year:'numeric'}))}</td><td>${fmt(income)}</td><td>${fmt(co.recoverable)}</td><td>${fmt(expense)}</td><td>${fmt(net)}</td></tr>`);}
 $('#forecastRows').innerHTML=rows.join('');
 $('#forecastAssumptions').innerHTML=[['Salaire mensuel fixe',fmt(f.salary)],['Prestations estimées',fmt(f.variable)],['Frais bancaires mensuels',fmt(f.bankFee)],['Autres dépenses prévues',fmt(f.otherExpenses)],['Repas dernier dimanche (dépense réelle)',fmt(1500)],['Cotisation quartier', '10 000 F chaque lundi'],['Cotisation carrière','20 000 F chaque samedi'],['Réunion familiale','4 000 F / mois (hypothèse)']].map(([a,b])=>`<div class="assumption-row"><span>${a}</span><strong>${b}</strong></div>`).join('');
}
function renderAll(){renderDashboard();renderTransactions();renderAccounts();renderCotisations();renderCompany();renderForecasts();updateOnline();}
function goPage(page){$$('.tab').forEach(b=>b.classList.toggle('active',b.dataset.page===page));$$('.page').forEach(p=>p.classList.toggle('active',p.id==='page-'+page));if(page==='dashboard')drawChart();window.scrollTo({top:0,behavior:'smooth'});}
$$('.tab').forEach(b=>b.addEventListener('click',()=>goPage(b.dataset.page)));
$$('[data-goto]').forEach(b=>b.addEventListener('click',()=>goPage(b.dataset.goto)));
$$('[data-close]').forEach(b=>b.addEventListener('click',()=>$('#'+b.dataset.close).close()));
$('#dashboardMonth').value=monthNow();$('#dashboardMonth').addEventListener('change',renderDashboard);
$('#addTransactionBtn').addEventListener('click',()=>openTx());
function openTx(t=null){
 $('#transactionForm').reset();$('#transactionId').value=t?.id||'';$('#txDate').value=t?.date||today();$('#txType').value=t?.type||'expense';$('#txLabel').value=t?.label||'';$('#txAmount').value=t?.amount||'';$('#txCategory').value=t?.category||'Autre';$('#txAccount').value=t?.account||'Espèces';$('#txToAccount').value=t?.toAccount||'Banque';$('#txNote').value=t?.note||'';
 $('#transactionModalTitle').textContent=t?'Modifier une opération':'Nouvelle opération';$('#transferAccountWrap').classList.toggle('hidden',$('#txType').value!=='transfer');$('#transactionDialog').showModal();
}
$('#txType').addEventListener('change',()=>$('#transferAccountWrap').classList.toggle('hidden',$('#txType').value!=='transfer'));
$('#transactionForm').addEventListener('submit',e=>{e.preventDefault();const type=$('#txType').value,amount=Number($('#txAmount').value),account=$('#txAccount').value,toAccount=$('#txToAccount').value;if(type==='transfer'&&account===toAccount){toast('Choisis deux comptes différents.');return;}
 const obj={id:$('#transactionId').value||id(),date:$('#txDate').value,type,label:$('#txLabel').value.trim(),amount,category:$('#txCategory').value,account,toAccount:type==='transfer'?toAccount:'',note:$('#txNote').value.trim()};
 if(type==='company'){obj.companyCashEffect=0;}
 const ix=state.transactions.findIndex(x=>x.id===obj.id);if(ix>=0)state.transactions[ix]=obj;else state.transactions.push(obj);
 $('#transactionDialog').close();save();toast('Opération enregistrée.');
});
$('#transactionSearch').addEventListener('input',renderTransactions);$('#transactionFilter').addEventListener('change',renderTransactions);
document.addEventListener('click',e=>{
 const ed=e.target.closest('[data-edit-tx]');if(ed){const t=state.transactions.find(x=>x.id===ed.dataset.editTx);if(t)openTx(t);}
 const del=e.target.closest('[data-delete-tx]');if(del&&confirm('Supprimer cette opération ?')){state.transactions=state.transactions.filter(x=>x.id!==del.dataset.deleteTx);save();toast('Opération supprimée.');}
 const dc=e.target.closest('[data-delete-cot]');if(dc&&confirm('Supprimer cette cotisation ?')){state.cotisations=state.cotisations.filter(x=>x.id!==dc.dataset.deleteCot);save();toast('Cotisation supprimée.');}
 const dco=e.target.closest('[data-delete-company]');if(dco&&confirm('Supprimer ce mouvement entreprise ?')){state.company=state.company.filter(x=>x.id!==dco.dataset.deleteCompany);save();toast('Mouvement supprimé.');}
});
$('#editAccountsBtn').addEventListener('click',()=>{renderAccounts();$('#accountsDialog').showModal();});
$('#accountsForm').addEventListener('submit',e=>{e.preventDefault();ACCOUNTS.forEach((a,i)=>state.openingAccounts[a]=Number($('#opening-'+i).value)||0);$('#accountsDialog').close();save();toast('Soldes initiaux mis à jour.');});
$('#addCotisationBtn').addEventListener('click',()=>{$('#cotisationForm').reset();$('#cotDate').value=today();$('#cotisationDialog').showModal();});
$('#cotAction').addEventListener('change',()=>{if($('#cotAction').value==='expense')$('#cotType').value='Repas';});
$('#cotisationForm').addEventListener('submit',e=>{e.preventDefault();const type=$('#cotType').value,action=$('#cotAction').value,recoverable=type!=='Repas'&&type!=='Autre'&&action!=='expense';state.cotisations.push({id:id(),date:$('#cotDate').value,type,action,amount:Number($('#cotAmount').value),account:$('#cotAccount').value,note:$('#cotNote').value.trim(),recoverable});$('#cotisationDialog').close();save();toast('Cotisation enregistrée.');});
$('#addCompanyBtn').addEventListener('click',()=>{$('#companyForm').reset();$('#coDate').value=today();$('#companyDialog').showModal();});
$('#companyForm').addEventListener('submit',e=>{e.preventDefault();const type=$('#coType').value,amount=Number($('#coAmount').value),account=$('#coAccount').value,category=$('#coCategory').value;
 state.company.push({id:id(),date:$('#coDate').value,type,amount,account,category,note:$('#coNote').value.trim()});
 // Reflect real cash movement in the physical accounts using the company ledger itself.
 $('#companyDialog').close();save();toast('Mouvement entreprise enregistré.');});
$('#editForecastBtn').addEventListener('click',()=>{const f=state.forecast;$('#salaryInput').value=f.salary;$('#variableInput').value=f.variable;$('#bankFeeInput').value=f.bankFee;$('#otherExpensesInput').value=f.otherExpenses;$('#forecastDialog').showModal();});
$('#forecastForm').addEventListener('submit',e=>{e.preventDefault();state.forecast={salary:+$('#salaryInput').value,variable:+$('#variableInput').value,bankFee:+$('#bankFeeInput').value,otherExpenses:+$('#otherExpensesInput').value};$('#forecastDialog').close();save();toast('Prévisions mises à jour.');});
$('#exportBtn').addEventListener('click',()=>download('mon-argent-sauvegarde-'+today()+'.json',JSON.stringify(state,null,2),'application/json'));
function download(name,content,type){const blob=new Blob([content],{type}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
$('#exportCsvBtn').addEventListener('click',()=>{const rows=[['date','type','libelle','montant_fcfa','categorie','compte','compte_destination','note'],...state.transactions.map(t=>[t.date,t.type,t.label,t.amount,t.category,t.account,t.toAccount||'',t.note||''])];const csv=rows.map(r=>r.map(v=>'"'+String(v??'').replace(/"/g,'""')+'"').join(';')).join('\r\n');download('operations-'+today()+'.csv','\ufeff'+csv,'text/csv;charset=utf-8;');});
$('#importFile').addEventListener('change',async e=>{const file=e.target.files[0];if(!file)return;try{const obj=JSON.parse(await file.text());if(obj.version!==1||!obj.openingAccounts||!Array.isArray(obj.transactions)||!Array.isArray(obj.company)||!Array.isArray(obj.cotisations))throw Error('Format invalide');if(confirm('Remplacer toutes les données actuelles par cette sauvegarde ?')){state=obj;save();toast('Sauvegarde importée.');}}catch(err){alert('Impossible d’importer ce fichier. Vérifie qu’il s’agit d’une sauvegarde Mon Argent.');}e.target.value='';});
$('#resetBtn').addEventListener('click',()=>{if(confirm('Es-tu sûr de vouloir supprimer toutes les opérations et réinitialiser les données ?')){state=defaultState();save();toast('Données réinitialisées.');}});
function updateOnline(){const on=navigator.onLine;$('#offlineDot').classList.toggle('online',!on);$('#offlineStatus').textContent=on?'Connecté · les données restent enregistrées localement':'Hors connexion · mode local actif';}
window.addEventListener('online',updateOnline);window.addEventListener('offline',updateOnline);window.addEventListener('resize',()=>{if($('#page-dashboard').classList.contains('active'))drawChart();});
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();installPrompt=e;$('#installBtn').classList.remove('hidden');});
$('#installBtn').addEventListener('click',async()=>{if(!installPrompt){toast('Utilise le menu Chrome puis « Installer l’application ».');return;}installPrompt.prompt();await installPrompt.userChoice;installPrompt=null;$('#installBtn').classList.add('hidden');});
if('serviceWorker' in navigator){window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));}
renderAll();
