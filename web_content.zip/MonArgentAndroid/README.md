# Mon Argent — projet Android

Ce projet enveloppe la version locale de l'application de gestion financière dans une application Android WebView. Les données restent stockées localement dans le stockage WebView du téléphone. Aucun compte ni serveur n'est requis pour les fonctions locales.

## Produire le fichier APK

Le fichier APK n'est pas inclus : cet environnement ne dispose pas du SDK Android ni de Gradle pour compiler et signer le paquet.

### Avec Android Studio
1. Installe Android Studio sur un ordinateur.
2. Ouvre le dossier `MonArgentAndroid` comme projet.
3. Laisse Gradle synchroniser et installer les composants SDK demandés (compile SDK 35).
4. Dans le menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Le APK de test sera dans `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfère ce fichier sur le téléphone Android, ouvre-le et autorise temporairement l'installation depuis cette source si Android le demande.

Pour distribuer l'application à d'autres personnes, générer plutôt un APK signé via **Build > Generate Signed Bundle / APK** et conserver la clé privée.
