/* ===== فهرس المصحف: السور + الأجزاء والأرباع (من بيانات QMeta، مفيش أرقام ثابتة هنا) ===== */
(function(){
"use strict";
var E=function(id){return document.getElementById(id)};
var V="s",loading=false;
var norm=function(t){return String(t).replace(/[\u064B-\u0652\u0670\u0640]/g,"").replace(/[أإآٱ]/g,"ا").replace(/ى/g,"ي").replace(/ة/g,"ه").replace(/^سور[ةه]\s*/,"").trim()};
var QUARTER=["بداية الحزب","ربع الحزب","نصف الحزب","ثلاثة أرباع الحزب"];

function where(k){var Q=QMeta;return "سورة "+Q.name(Q.surahOfKey(k))+" آية "+(k%1000)}

function surahRows(f){
  var Q=QMeta,h="",n,nf=norm(f),dig=/^\d+$/.test(nf)?+nf:0,cnt=0;
  for(n=1;n<=114;n++){
    var nm=Q.name(n),pg=Q.pageOf(1000*n+1);
    if(nf&&!(dig?(n===dig||pg===dig):norm(nm).indexOf(nf)>-1))continue;
    cnt++;
    var meta=Q.full()?(Q.isMadani(n)?"مدنية":"مكية")+" · "+Q.ayahCount(n)+" آية":"";
    h+='<div class="mh-row" style="cursor:pointer" onclick="Reader.openPage('+pg+')"><span class="mh-n">'+n+'</span><div class="mh-t"><b>'+nm+'</b>'+(meta?'<small>'+meta+'</small>':'')+'</div><div class="mh-p"><b>صفحة '+pg+'</b><small>الجزء '+Q.juzOf(1000*n+1)+'</small></div></div>';
  }
  return h||'<div class="empty" style="padding:12px">مفيش نتيجة</div>';
}

function juzList(){
  var Q=QMeta,h="",j,i;
  for(j=1;j<=30;j++){
    var k=Q.juzStart(j);
    h+='<details class="mh-juz"><summary><span class="mh-n">'+j+'</span><div class="mh-t"><b>الجزء '+j+'</b><small>'+where(k)+'</small></div><div class="mh-p"><b>صفحة '+Q.pageOf(k)+'</b></div></summary>';
    for(i=0;i<8;i++){
      var r=(j-1)*8+i+1,rk=Q.rubStart(r);
      h+='<div class="mh-q" style="cursor:pointer" onclick="Reader.openPage('+Q.pageOf(rk)+')"><span>الحزب '+Math.ceil(r/4)+' · '+QUARTER[(r-1)%4]+' <small>(ربع '+r+')</small></span><span>'+where(rk)+' · ص '+Q.pageOf(rk)+'</span></div>';
    }
    h+='</details>';
  }
  return h;
}

function body(){
  var Q=window.QMeta;
  if(!Q||!Q.ready())return '<div class="card"><p class="mute">'+(loading?'جاري تحميل الفهرس...':'الفهرس محتاج نت مرة واحدة بس، وبعدها بيشتغل من غير نت.')+'</p>'+(loading?'':'<div class="row"><button onclick="Mushaf.retry()">🔄 حمّل الفهرس</button></div>')+'</div>';
  if(V==="j")return '<div id="mhList">'+juzList()+'</div>';
  return '<input id="mhQ" placeholder="🔎 ابحث باسم السورة أو رقمها" oninput="Mushaf.find(this.value)" style="font-size:17px;margin:8px 0"><div id="mhList">'+surahRows("")+'</div>';
}

function render(){
  var el=E("mushaf");if(!el)return;
  el.innerHTML='<div class="panel"><h2>📖 فهرس المصحف</h2><div class="mh-tabs"><button class="alt'+(V==="s"?" on":"")+'" onclick="Mushaf.tab(\'s\')">السور (114)</button><button class="alt'+(V==="j"?" on":"")+'" onclick="Mushaf.tab(\'j\')">الأجزاء والأرباع (30)</button></div>'+body()+'<div class="row"><button class="alt" onclick="show(\'home\')">⬅️ رجوع</button></div></div>';
}

function ensure(){
  var Q=window.QMeta;if(!Q||Q.full()||loading)return;
  loading=true;render();
  Q.load().then(function(){loading=false;render()});
}

window.Mushaf={
  open:function(){V="s";render();show("mushaf");ensure()},
  tab:function(v){V=v;render()},
  find:function(f){var l=E("mhList");if(l)l.innerHTML=surahRows(f)},
  retry:function(){ensure()}
};

var css=document.createElement("style");
css.textContent=".mh-tabs{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:6px}.mh-tabs button{padding:11px 4px;font-size:15px}.mh-tabs button.on{outline:2px solid #2a9df4;font-weight:800}"+
".mh-row,.mh-juz summary{display:flex;align-items:center;gap:10px;padding:9px 6px;border-bottom:1px solid rgba(31,134,214,.15);text-align:right}.mh-juz summary{cursor:pointer;list-style:none}.mh-juz summary::-webkit-details-marker{display:none}"+
".mh-n{flex:none;min-width:32px;height:32px;line-height:32px;text-align:center;border-radius:50%;background:rgba(31,134,214,.14);font-weight:800;font-size:14px}"+
".mh-t{flex:1;display:flex;flex-direction:column}.mh-t b{font-size:17px}.mh-t small,.mh-p small{font-size:12px;opacity:.75}.mh-p{flex:none;display:flex;flex-direction:column;text-align:left}"+
".mh-q{display:flex;justify-content:space-between;gap:8px;padding:7px 10px;font-size:13px;border-bottom:1px dashed rgba(31,134,214,.15);text-align:right;background:rgba(31,134,214,.05)}.mh-q small{opacity:.7}";
document.head.appendChild(css);
})();
