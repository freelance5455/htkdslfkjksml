/* ===== تتبع الورد ===== */
(function(){
"use strict";
var E=function(id){return document.getElementById(id)};
var pad=function(n){return String(n).padStart(2,"0")};
var dk=function(d){return d.getFullYear()+"-"+pad(d.getMonth()+1)+"-"+pad(d.getDate())};
var parse=function(k){var a=k.split("-").map(Number);return new Date(a[0],a[1]-1,a[2])};
var addDays=function(d,n){var x=new Date(d);x.setDate(x.getDate()+n);return x};
var DAYS=["س","ح","ن","ث","ر","خ","ج"];                       // الأسبوع بيبدأ السبت
var MONTHS=["يناير","فبراير","مارس","أبريل","مايو","يونيو","يوليو","أغسطس","سبتمبر","أكتوبر","نوفمبر","ديسمبر"];
var W=blank(),calM=new Date(),openForm=false,metaTried=false;
calM.setDate(1);

function bu(p){return {ppd:p,g:{},days:{},pos:0,kh:0,log:[],cel:""}}
function blank(){var b=bu(5);b.u=0;b.m="p";b.r=bu(4);return b}
function fix(){if(!W.days)W.days={};if(!W.g)W.g={};if(!W.log)W.log=[];if(!W.r||typeof W.r!=="object")W.r=bu(4);var r=W.r;if(!r.days)r.days={};if(!r.g)r.g={};if(!r.log)r.log=[];if(!r.ppd)r.ppd=4;W.m=W.m==="r"?"r":"p"}
function key(){return "q_wird_"+(typeof uid!=="undefined"&&uid?uid:"")}
function load(){
  try{W=Object.assign(blank(),JSON.parse(localStorage.getItem(key()))||{})}catch(e){W=blank()}
  fix();
}
function save(){
  W.u=Date.now();
  try{localStorage.setItem(key(),JSON.stringify(W))}catch(e){}
  if(typeof db!=="undefined"&&db&&typeof uid!=="undefined"&&uid)db.collection("users").doc(uid).set({wird:W},{merge:true}).catch(function(){});
  render();
}
/* بيتنده لما المستخدم يتغيّر (دخول/خروج) */
window.onUserSwitch=function(){load();render()};
/* بيتنده بعد قراءة بيانات المستخدم من Firebase: الأحدث بيكسب */
window.wirdRemote=function(r){
  if(r&&typeof r==="object"&&(r.u||0)>(W.u||0)){
    W=Object.assign(blank(),r);fix();try{localStorage.setItem(key(),JSON.stringify(W))}catch(e){}render();
  }
};

var today=function(){return dk(new Date())};
function S(){return W.m==="r"?W.r:W}function TT(){return W.m==="r"?240:604}function UN(){return W.m==="r"?"ربع":"صفحة"}function PRE(){return W.m==="r"?[1,2,4,8,16]:[1,2,5,10,20]}
function setMode(m){W.m=m==="r"?"r":"p";openForm=false;save()}
var pagesOn=function(k){return S().days[k]||0};
var goalOf=function(k){return S().g[k]||S().ppd};
function totalPages(){var t=0;for(var k in S().days)t+=S().days[k];return t}
function streakInfo(){
  var d=new Date(),cur=0;
  if(pagesOn(dk(d))<goalOf(dk(d)))d=addDays(d,-1);
  while(pagesOn(dk(d))>0&&pagesOn(dk(d))>=goalOf(dk(d))&&cur<4000){cur++;d=addDays(d,-1)}
  var ks=Object.keys(S().days).filter(function(k){return S().days[k]>=goalOf(k)}).sort(),best=0,run=0,prev=null;
  ks.forEach(function(k){var t=parse(k);run=(prev&&Math.round((t-prev)/864e5)===1)?run+1:1;if(run>best)best=run;prev=t});
  return {cur:cur,best:Math.max(best,cur)};
}

/* ----- تسجيل ----- */
function commit(p,newPos,newKh){
  if(!(p>0))return;
  var k=today();
  S().log.push({id:Date.now(),t:Date.now(),d:k,p:p,pos0:S().pos,kh0:S().kh});
  if(S().log.length>40)S().log.shift();
  S().days[k]=pagesOn(k)+p;S().g[k]=S().ppd;S().pos=newPos;S().kh=newKh;
  var done=S().days[k]>=S().ppd;
  if(done&&S().cel!==k){S().cel=k;setTimeout(function(){if(window.fxWin)fxWin("ما شاء الله، خلّصت وردك 🌙")},200)}
  if(newKh>S().log[S().log.length-1].kh0)setTimeout(function(){if(window.fxWin)fxWin("ختمة مباركة 🎉📖")},900);
  save();
}
function add(p){
  p=Math.floor(Number(p));
  if(!(p>=1)||p>TT())return toastMsg("اكتب عدد من 1 لـ "+TT()+" "+UN());
  var t=S().pos+p,kh=S().kh;while(t>=TT()){kh++;t-=TT()}
  commit(p,t,kh);
}
function addCustom(){add(E("wdCustom")&&E("wdCustom").value)}
function addRange(){
  var a=Math.floor(Number(E("wdFrom").value)),b=Math.floor(Number(E("wdTo").value));
  if(!(a>=1&&b>=a&&b<=TT()))return toastMsg("اكتب بداية ونهاية صح (1–"+TT()+")");
  var kh=S().kh,pos=b;if(b>=TT()){kh++;pos=0}
  commit(b-a+1,pos,kh);
}
function undo(){
  var e=S().log.pop();if(!e)return;
  var k=e.d;S().days[k]=Math.max(0,pagesOn(k)-e.p);if(!S().days[k])delete S().days[k];
  S().pos=e.pos0;S().kh=e.kh0;
  if(S().cel===k&&pagesOn(k)<goalOf(k))S().cel="";
  save();
}
function setGoal(v){
  v=Math.floor(Number(v));
  if(!(v>=1&&v<=TT()))return toastMsg("الهدف من 1 لـ "+TT()+" "+UN());
  S().ppd=v;S().g[today()]=v;save();if(window.okMsg)okMsg("هدفك اتعدّل");
}
function setGoalDays(){
  var n=Math.floor(Number(E("wdDays").value));
  if(!(n>=1&&n<=3650))return toastMsg("اكتب عدد أيام صح");
  setGoal(Math.min(TT(),Math.ceil(TT()/n)));
}
function setPos(){
  var v=Math.floor(Number(E("wdPos").value));
  if(!(v>=0&&v<TT()))return toastMsg("اكتب آخر "+UN()+" وقفت عندها (0–"+(TT()-1)+")");
  S().pos=v;save();if(window.okMsg)okMsg("مكان وقوفك اتحفظ");
}
function toastMsg(t){if(window.toast)toast(t);else alert(t)}
function calNav(n){calM=new Date(calM.getFullYear(),calM.getMonth()+n,1);render()}
function toggleForm(){openForm=!openForm;render()}

/* ----- مكان القراءة (لو بيانات الصفحات متاحة) ----- */
function whereIs(n){
  var Q=window.QMeta;if(!Q||!Q.ready())return "";
  var r=W.m==="r",k=r?Q.rubStart(n):Q.pageStart(n);if(!k)return "";
  return "سورة "+Q.name(Q.surahOfKey(k))+(r?" آية "+(k%1000)+" · صفحة "+Q.pageOf(k):"")+" · الجزء "+Q.juzOf(k);
}
function maybeLoadMeta(){
  if(metaTried||!window.QMeta||QMeta.ready())return;
  metaTried=true;QMeta.load().then(function(ok){if(ok)render()});
}

/* ----- شارات ----- */
function badges(){
  var s=streakInfo(),tp=totalPages();
  return [
    ["🔥","3 أيام ورا بعض",s.best>=3],["🔥","أسبوع كامل",s.best>=7],["🔥","14 يوم",s.best>=14],["🔥","شهر كامل",s.best>=30],["🔥","60 يوم",s.best>=60],["🔥","100 يوم",s.best>=100],
    ["📄",(W.m==="r"?"40 ربع":"100 صفحة"),tp>=(W.m==="r"?40:100)],["📚",(W.m==="r"?"120 ربع":"300 صفحة"),tp>=(W.m==="r"?120:300)],["📖",(W.m==="r"?"400 ربع":"1000 صفحة"),tp>=(W.m==="r"?400:1000)],["🏔️",(W.m==="r"?"1200 ربع":"3000 صفحة"),tp>=(W.m==="r"?1200:3000)],
    ["🌙","ختمة أولى",S().kh>=1],["🌟","3 ختمات",S().kh>=3],["👑","5 ختمات",S().kh>=5]
  ];
}

/* ----- رسومات ----- */
function ring(pct,big,small){
  var C=2*Math.PI*52,off=C*(1-Math.min(1,pct));
  return '<svg viewBox="0 0 130 130" class="wd-ring"><circle cx="65" cy="65" r="52" fill="none" stroke="rgba(31,134,214,.15)" stroke-width="12"/>'+
    '<circle cx="65" cy="65" r="52" fill="none" stroke="'+(pct>=1?"#1b9e63":"#2a9df4")+'" stroke-width="12" stroke-linecap="round" stroke-dasharray="'+C.toFixed(1)+'" stroke-dashoffset="'+off.toFixed(1)+'" transform="rotate(-90 65 65)" style="transition:stroke-dashoffset .8s"/>'+
    '<text x="65" y="64" text-anchor="middle" font-size="30" font-weight="800" fill="#0b3a5e">'+big+'</text>'+
    '<text x="65" y="86" text-anchor="middle" font-size="12" fill="#3d77a3">'+small+'</text></svg>';
}
function weekChart(){
  var vals=[],i,d,max=S().ppd;
  for(i=6;i>=0;i--){d=addDays(new Date(),-i);var k=dk(d);vals.push({k:k,v:pagesOn(k),g:goalOf(k),wd:(d.getDay()+1)%7,t:i===0});if(pagesOn(k)>max)max=pagesOn(k)}
  max=max*1.2;var H=100,svg='<svg viewBox="0 0 320 140" class="wd-chart">';
  var gy=H-(S().ppd/max)*H+10;
  svg+='<line x1="8" x2="312" y1="'+gy.toFixed(1)+'" y2="'+gy.toFixed(1)+'" stroke="#1b9e63" stroke-dasharray="4 4" opacity=".6"/>';
  vals.forEach(function(x,n){
    var bh=(x.v/max)*H,xx=14+n*44,y=H-bh+10;
    svg+='<rect x="'+xx+'" y="'+y.toFixed(1)+'" width="30" height="'+Math.max(bh,x.v?3:0).toFixed(1)+'" rx="6" fill="'+(x.v>=x.g?"#1b9e63":"#2a9df4")+'"'+(x.t?' stroke="#0b3a5e" stroke-width="2"':'')+'/>';
    if(x.v)svg+='<text x="'+(xx+15)+'" y="'+(y-4).toFixed(1)+'" text-anchor="middle" font-size="11" font-weight="700" fill="#0b3a5e">'+x.v+'</text>';
    svg+='<text x="'+(xx+15)+'" y="130" text-anchor="middle" font-size="12" fill="'+(x.t?"#0b3a5e":"#3d77a3")+'" font-weight="'+(x.t?800:400)+'">'+DAYS[x.wd]+'</text>';
  });
  return svg+'</svg>';
}
function calendar(){
  var y=calM.getFullYear(),m=calM.getMonth(),first=new Date(y,m,1),n=new Date(y,m+1,0).getDate(),off=(first.getDay()+1)%7,tk=today(),h="";
  DAYS.forEach(function(d){h+='<div class="wd-dh">'+d+'</div>'});
  for(var i=0;i<off;i++)h+='<div></div>';
  for(var d=1;d<=n;d++){
    var k=y+"-"+pad(m+1)+"-"+pad(d),v=pagesOn(k),r=v?Math.min(1,v/goalOf(k)):0,fut=k>tk,bg,fg="#0b3a5e";
    if(r>=1){bg="#1b9e63";fg="#fff"}else if(r>0){bg="rgba(42,157,244,"+(0.2+0.5*r).toFixed(2)+")"}else bg="rgba(31,134,214,.07)";
    h+='<div class="wd-d'+(k===tk?" wd-today":"")+(fut?" wd-fut":"")+'" style="background:'+bg+';color:'+fg+'" title="'+k+': '+v+' '+UN()+'"><b>'+d+'</b>'+(v?'<small>'+v+'</small>':'')+'</div>';
  }
  return h;
}

/* ----- الرسم الرئيسي ----- */
function render(){
  var T=today(),tp=pagesOn(T),goal=S().ppd,pct=tp/goal,st=streakInfo(),rem=Math.max(0,goal-tp),totP=totalPages();
  var nextPage=S().pos+1,untilPage=Math.min(TT(),S().pos+rem),loc=whereIs(nextPage);
  /* بطاقة الصفحة الرئيسية */
  var hh=E("wirdHome");
  if(hh)hh.innerHTML='<h2>📖 وِرْدِي</h2><div class="wd-mini"><div class="wd-mini-t"><b>'+tp+' / '+goal+'</b> '+UN()+' النهاردة'+(pct>=1?' ✅':'')+'</div><div class="lvl-track"><i style="width:'+Math.min(100,Math.round(pct*100))+'%"></i></div><div class="wd-mini-s">🔥 '+st.cur+' يوم ورا بعض · 🌙 '+S().kh+' ختمة</div></div><div class="row"><button onclick="show(\'wird\')">افتح تتبع الورد</button></div>';
  var el=E("wird");if(!el)return;
  maybeLoadMeta();
  var logHtml=S().log.slice(-6).reverse().map(function(e,i){
    var t=new Date(e.t);
    return '<div class="wd-li"><span>+'+e.p+' '+UN()+'</span><span class="mute">'+e.d+' · '+pad(t.getHours())+':'+pad(t.getMinutes())+'</span>'+(i===0?'<button class="alt wd-undo" onclick="Wird.undo()">↩️ تراجع</button>':'')+'</div>';
  }).join("")||'<div class="empty" style="padding:10px">لسه مسجّلتش أي ورد</div>';
  var last30=0,i;for(i=0;i<30;i++)last30+=pagesOn(dk(addDays(new Date(),-i)));
  var activeDays=Object.keys(S().days).length,bestDay=0;for(var k in S().days)if(S().days[k]>bestDay)bestDay=S().days[k];
  var daysPerKh=Math.ceil(TT()/goal),remKh=TT()-S().pos,fin=addDays(new Date(),Math.ceil(remKh/goal)-1);
  var presets=PRE().map(function(v){return '<button class="alt wd-chip'+(goal===v?' sel':'')+'" onclick="Wird.goal('+v+')">'+v+'</button>'}).join("");
  var bd=badges().map(function(b){return '<div class="wd-b'+(b[2]?' on':'')+'"><span>'+b[0]+'</span><small>'+b[1]+'</small></div>'}).join("");
  var mn=MONTHS[calM.getMonth()]+" "+calM.getFullYear();
  el.innerHTML='<div class="panel wd">'+
   '<h2>📖 تتبع الورد</h2>'+'<div class="wd-modes"><button class="wd-mode'+(W.m==="p"?' on':'')+'" onclick="Wird.mode(\'p\')"><span>📄</span><b>أنتظم بالصفحات</b><small>اختار كام صفحة</small></button><button class="wd-mode'+(W.m==="r"?' on':'')+'" onclick="Wird.mode(\'r\')"><span>🌓</span><b>أنتظم بالأرباع</b><small>اختار كام ربع</small></button></div>'+
   '<div class="card wd-hero">'+ring(pct,tp+'/'+goal,pct>=1?'خلّصت وردك ✅':'باقي '+rem+' '+UN())+
     '<div class="wd-hero-side"><div class="wd-streak">🔥 <b>'+st.cur+'</b> يوم ورا بعض</div><div class="mute">أطول سلسلة: '+st.best+' يوم</div>'+
     (rem>0?'<div class="wd-next">ورد النهاردة:<br><b>من '+UN()+' '+nextPage+' إلى '+untilPage+'</b>'+(loc?'<div class="mute">'+loc+'</div>':'')+'</div>':'<div class="wd-next">🌙 تقبّل الله منك<br><span class="mute">كمّل من '+UN()+' '+nextPage+(loc?' · '+loc:'')+'</span></div>')+
     '</div></div>'+
   '<div class="card"><h3>➕ سجّل قراءتك</h3>'+(W.m==="r"?'<div class="mute" style="margin:-4px 0 8px">4 أرباع = حزب · 8 أرباع = جزء</div>':'')+'<div class="wd-quick">'+PRE().map(function(v){return '<button onclick="Wird.add('+v+')">+'+v+'</button>'}).join("")+'</div>'+
     '<div class="wd-inline"><input id="wdCustom" type="number" min="1" max="'+TT()+'" inputmode="numeric" placeholder="'+(W.m==="r"?"عدد أرباع تانية":"عدد صفحات تانية")+'"><button onclick="Wird.addCustom()">سجّل</button></div>'+
     '<button class="alt wd-link" onclick="Wird.toggleForm()">'+(openForm?'▲ إخفاء':'▼ أو سجّل من '+UN()+' لـ '+UN())+'</button>'+
     (openForm?'<div class="wd-inline"><input id="wdFrom" type="number" min="1" max="'+TT()+'" inputmode="numeric" placeholder="من '+UN()+'" value="'+nextPage+'"><input id="wdTo" type="number" min="1" max="'+TT()+'" inputmode="numeric" placeholder="إلى '+UN()+'"><button onclick="Wird.addRange()">سجّل</button></div>':'')+
     '<h3 style="margin-top:16px">🕘 آخر التسجيلات</h3>'+logHtml+'</div>'+
   '<div class="card"><h3>🎯 هدفك اليومي</h3><div class="wd-chips">'+presets+'</div>'+
     '<div class="wd-inline"><input id="wdDays" type="number" min="1" inputmode="numeric" placeholder="أختم في كام يوم؟"><button class="alt" onclick="Wird.goalDays()">احسب</button></div>'+
     '<div class="mute" style="margin-top:8px">هدفك: <b>'+goal+'</b> '+UN()+' في اليوم = ختمة كل <b>'+daysPerKh+'</b> يوم تقريبًا</div></div>'+
   '<div class="card"><h3>🌙 الختمة الحالية</h3><div class="lvl-row"><b>وصلت '+UN()+' '+S().pos+' من '+TT()+'</b><span>'+(S().pos/TT()*100).toFixed(1)+'%</span></div><div class="lvl-track"><i style="width:'+(S().pos/TT()*100)+'%"></i></div>'+
     '<div class="wd-stats"><div><b>'+S().kh+'</b><small>ختمات</small></div><div><b>'+remKh+'</b><small>'+UN()+' باقية</small></div><div><b>'+fin.getDate()+'/'+(fin.getMonth()+1)+'</b><small>الختم المتوقع</small></div></div>'+
     '<div class="wd-inline"><input id="wdPos" type="number" min="0" max="'+(TT()-1)+'" inputmode="numeric" placeholder="آخر '+UN()+' وقفت عندها"><button class="alt" onclick="Wird.setPos()">تحديد</button></div></div>'+
   '<div class="card"><h3>📊 آخر 7 أيام</h3>'+weekChart()+'<div class="mute">الخط الأخضر المتقطع = هدفك</div></div>'+
   '<div class="card"><h3>🗓️ التقويم</h3><div class="wd-calnav"><button class="alt" onclick="Wird.cal(-1)">›</button><b>'+mn+'</b><button class="alt" onclick="Wird.cal(1)">‹</button></div><div class="wd-cal">'+calendar()+'</div></div>'+
   '<div class="card"><h3>📈 إحصائيات</h3><div class="wd-stats"><div><b>'+totP+'</b><small>'+UN()+' إجمالي</small></div><div><b>'+activeDays+'</b><small>يوم قرأت فيه</small></div><div><b>'+(last30/30).toFixed(1)+'</b><small>متوسط/يوم (30 يوم)</small></div><div><b>'+bestDay+'</b><small>أكتر يوم</small></div></div></div>'+
   '<div class="card"><h3>🏅 الشارات</h3><div class="wd-badges">'+bd+'</div></div>'+
   '<div class="row"><button class="alt" onclick="show(\'home\')">⬅️ رجوع</button></div></div>';
}

window.Wird={mode:setMode,add:add,addCustom:addCustom,addRange:addRange,undo:undo,goal:setGoal,goalDays:setGoalDays,setPos:setPos,cal:calNav,toggleForm:toggleForm,render:render,_state:function(){return W}};
load();render();

/* ----- ستايل ----- */
var css=document.createElement("style");
css.textContent=
".wd h3{margin:0 0 10px;color:#0f5f9e;font-size:17px;text-align:right}.wd .card{text-align:right}"+
".wd-hero{display:flex;flex-direction:column;align-items:center;text-align:center!important;gap:10px}.wd-ring{width:150px;flex:none}.wd-hero-side{width:100%}"+
".wd-streak{font-size:18px}.wd-streak b{font-size:26px;color:#e8590c}.wd-next{margin-top:10px;padding:8px 10px;border-radius:12px;background:rgba(31,134,214,.1);line-height:1.8}"+
".wd-quick{display:grid;grid-template-columns:repeat(5,1fr);gap:8px}.wd-quick button{padding:12px 0;font-size:18px}"+
".wd-inline{display:flex;gap:8px;margin-top:10px}.wd-inline input{font:16px sans-serif;padding:11px}.wd-inline button{flex:none;min-width:84px}"+
".wd-link{width:100%;margin-top:10px;font-size:14px;padding:8px}"+
".wd-chips{display:flex;gap:8px}.wd-chip{padding:11px 0;font-size:17px}"+
".wd-li{display:flex;align-items:center;gap:10px;padding:7px 0;border-bottom:1px solid rgba(31,134,214,.12)}.wd-li span:first-child{font-weight:700;color:#1b9e63}.wd-li .mute{flex:1;text-align:start}.wd-undo{flex:none;padding:6px 10px;font-size:13px}"+
".wd-stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(86px,1fr));gap:8px;margin-top:12px;text-align:center}.wd-stats div{background:rgba(31,134,214,.08);border-radius:12px;padding:8px 4px}.wd-stats b{display:block;font-size:20px;color:#0f5f9e}.wd-stats small{font-size:11px;color:#3d77a3}"+
".wd-chart{width:100%;height:auto;display:block}"+
".wd-calnav{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px}.wd-calnav button{flex:none;width:44px;padding:6px}"+
".wd-cal{display:grid;grid-template-columns:repeat(7,1fr);gap:5px}.wd-dh{text-align:center;font-size:12px;color:#3d77a3;font-weight:700}"+
".wd-d{aspect-ratio:1;border-radius:9px;display:flex;flex-direction:column;align-items:center;justify-content:center;line-height:1.1;font-size:13px}.wd-d small{font-size:9px;opacity:.85}.wd-fut{opacity:.4}.wd-today{outline:2px solid #0b3a5e}"+
".wd-badges{display:grid;grid-template-columns:repeat(auto-fit,minmax(88px,1fr));gap:8px;text-align:center}.wd-b{padding:8px 4px;border-radius:12px;background:rgba(31,134,214,.06);filter:grayscale(1);opacity:.45}.wd-b.on{filter:none;opacity:1;background:rgba(255,213,74,.25);box-shadow:inset 0 0 0 1px rgba(232,170,0,.5)}.wd-b span{font-size:26px;display:block}.wd-b small{font-size:11px;color:#0b3a5e}"+
".wd-mini{text-align:right;margin-bottom:8px}.wd-mini-t{margin-bottom:6px}.wd-mini-s{font-size:13px;color:#3d77a3;margin-top:6px}"+
".wd-modes{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:12px}.wd-mode{display:flex!important;flex-direction:column;align-items:center;gap:4px;padding:14px 6px!important;border-radius:16px;background:rgba(31,134,214,.08)!important;color:#0b3a5e!important;border:2px solid transparent!important;box-shadow:none!important}.wd-mode span{font-size:30px}.wd-mode b{font-size:15px}.wd-mode small{font-size:11px;color:#3d77a3}.wd-mode.on{border-color:#2a9df4!important;background:rgba(42,157,244,.22)!important}"+
"@media(max-width:380px){.wd-quick{grid-template-columns:repeat(3,1fr)}}";
document.head.appendChild(css);
})();
