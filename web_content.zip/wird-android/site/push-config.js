/* إعدادات سيرفر الإشعارات (Cloudflare Worker) - بعد ما تنشر الـ Worker حط رابطه هنا */
window.PUSH_URL = "https://wird-push.lovefreedme88.workers.dev";   // مثال: "https://wird-push.اسمك.workers.dev"  (من غير / في الآخر). لو فاضي الإشعارات بتشتغل محلياً بس
window.VAPID_PUB = "BLLgkib2a3h47EXAZueoDYwqbwkIoGbr8AV-AJAlLdAwVI41BU8uZhTT7MjOI2yimO-wlhSYz-hW_EMFYb0_eRc";

/* خليها true بعد ما تحدّث الـ Worker عشان يبعت إشعارات الصلاة من السيرفر (وقبلها بتطلع من التطبيق وهو مفتوح/في الخلفية) */
window.PRAY_PUSH = true;
