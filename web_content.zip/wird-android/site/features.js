/* ===== ميزات فاخرة: سماء حيّة، عدّاد المناسبات، رسالة المطوّر، آية اليوم ===== */
(function(){
"use strict";
var E=function(i){return document.getElementById(i)};
var pad=function(n){return String(n).padStart(2,"0")};
var NM=function(){try{return nmx()}catch(e){return ""}};
var esc=function(s){return String(s).replace(/[&<>"]/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]})};
var dayN=function(){return Math.floor((Date.now()-new Date().getTimezoneOffset()*6e4)/864e5)};
var lsGet=function(k,d){try{return JSON.parse(localStorage.getItem(k))||d}catch(e){return d}};
var lsSet=function(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}};

/* ---------- CSS ---------- */
var css=
".fx-card{position:relative;margin:12px 0;border-radius:20px;overflow:hidden;direction:rtl}"+
".fx-sky{height:252px;color:#fff;text-shadow:0 2px 12px rgba(0,0,0,.5);transition:background 2s;border-radius:26px;box-shadow:0 18px 40px rgba(0,0,0,.42),0 2px 0 rgba(255,255,255,.12) inset,0 0 0 1px rgba(232,200,120,.55)}"+
".fx-sky:before{content:'';position:absolute;inset:6px;border-radius:21px;border:1px solid rgba(255,236,180,.22);pointer-events:none;z-index:3}"+
".fx-sky:after{content:'';position:absolute;left:0;right:0;top:0;height:46%;background:linear-gradient(180deg,rgba(255,255,255,.16),rgba(255,255,255,0));pointer-events:none;z-index:1}"+
".fx-sky .st,.fx-sky .cl,.fx-sky .sun{position:absolute;pointer-events:none}"+
".fx-sky .st{width:2.5px;height:2.5px;border-radius:50%;background:#fff;animation:fxTw 3.4s ease-in-out infinite;transition:opacity 2s}"+
"@keyframes fxTw{0%,100%{opacity:.2;transform:scale(.6)}50%{opacity:1;transform:scale(1.3)}}"+
".fx-sky .cl{height:30px;border-radius:40px;background:rgba(255,255,255,.5);filter:blur(9px);animation:fxCl linear infinite;transition:opacity 2s}"+
"@keyframes fxCl{from{transform:translateX(-160px)}to{transform:translateX(560px)}}"+
".fx-sky .sun{width:50px;height:50px;border-radius:50%;transition:left 1s,top 1s;animation:fxPulse 5s ease-in-out infinite}"+
".fx-sky .sun.s{background:radial-gradient(circle,#fffdf0 0,#ffe27a 50%,#ffbf2e 100%);box-shadow:0 0 0 10px rgba(255,214,102,.16),0 0 46px 20px rgba(255,205,80,.5)}"+
".fx-sky .sun.m{background:transparent;box-shadow:inset -13px 5px 0 0 #f7efcf;width:44px;height:44px;filter:drop-shadow(0 0 14px rgba(255,248,205,.85))}"+
"@keyframes fxPulse{0%,100%{transform:scale(1)}50%{transform:scale(1.07)}}"+
".fx-sky .sk{position:absolute;left:0;right:0;bottom:0;width:100%;height:92px;z-index:1;pointer-events:none}"+
".fx-sky .ov{position:absolute;inset:0;background:linear-gradient(180deg,rgba(0,0,0,.12) 0,rgba(0,0,0,0) 28%,rgba(4,8,16,.62) 100%);z-index:1}"+
".fx-sky .top{position:absolute;top:16px;right:18px;left:18px;display:flex;justify-content:space-between;align-items:center;z-index:2}"+
".fx-sky .pill{display:inline-flex;align-items:center;gap:6px;padding:5px 13px;border-radius:30px;background:rgba(8,14,26,.32);border:1px solid rgba(255,236,180,.45);backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);font-size:12.5px;font-weight:800;letter-spacing:.2px;color:#fff3cf}"+
".fx-sky .dt{font-size:12px;font-weight:700;opacity:.92}"+
".fx-sky .tx{position:absolute;right:20px;left:20px;bottom:18px;z-index:2}"+
".fx-sky .gr{font-family:'Amiri','Scheherazade New','Traditional Arabic',Tahoma,serif;font-size:29px;font-weight:700;line-height:1.35;color:#fffaf0;letter-spacing:.2px}"+
".fx-sky .orn{display:flex;align-items:center;gap:8px;margin:6px 0 7px;width:150px}.fx-sky .orn:before,.fx-sky .orn:after{content:'';flex:1;height:1px;background:linear-gradient(90deg,rgba(247,220,138,0),rgba(247,220,138,.85))}.fx-sky .orn:after{transform:scaleX(-1)}.fx-sky .orn i{width:6px;height:6px;transform:rotate(45deg);background:#f7dc8a;box-shadow:0 0 8px rgba(247,220,138,.9)}"+
".fx-sky .sb{font-size:13.5px;font-weight:600;opacity:.95}"+
".fx-sky .nx{margin-top:11px;display:inline-flex;align-items:center;gap:9px;padding:7px 15px;border-radius:30px;background:rgba(8,14,26,.38);backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);font-size:13px;font-weight:800;color:#fff3cf;border:1px solid rgba(247,220,138,.55);box-shadow:0 4px 14px rgba(0,0,0,.25)}"+
".fx-h{font-size:15px;font-weight:800;color:var(--gold,#d4a95a);margin:0 0 10px;display:flex;align-items:center;gap:6px}"+
".fx-occ{display:flex;gap:10px;overflow-x:auto;padding:4px 2px 10px;scroll-snap-type:x mandatory;-webkit-overflow-scrolling:touch}"+
".fx-oc{flex:0 0 132px;scroll-snap-align:start;border-radius:16px;padding:12px 10px;text-align:center;background:linear-gradient(160deg,rgba(255,255,255,.1),rgba(255,255,255,.03));border:1px solid rgba(212,169,90,.35);animation:fxUp .6s both}"+
".fx-oc.now{border-color:#ffd75e;box-shadow:0 0 18px rgba(255,215,94,.45);animation:fxUp .6s both,fxGlow 2.4s ease-in-out infinite}"+
"@keyframes fxGlow{0%,100%{box-shadow:0 0 8px rgba(255,215,94,.25)}50%{box-shadow:0 0 22px rgba(255,215,94,.7)}}"+
"@keyframes fxUp{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:none}}"+
".fx-oc .e{font-size:30px;display:block;animation:fxFloat 3s ease-in-out infinite}"+
"@keyframes fxFloat{0%,100%{transform:translateY(0)}50%{transform:translateY(-5px)}}"+
".fx-oc .n{font-weight:800;font-size:14px;margin-top:4px}.fx-oc .d{font-size:26px;font-weight:900;color:var(--gold,#d4a95a);line-height:1.1;margin-top:4px}"+
".fx-oc .u{font-size:11px;color:var(--mute,#9db3a6)}.fx-oc .l{font-size:10.5px;color:var(--mute,#9db3a6);margin-top:6px;line-height:1.5}"+
".fx-dm{padding:16px;background:linear-gradient(135deg,rgba(212,169,90,.18),rgba(95,191,143,.12));border:1px solid rgba(212,169,90,.5);animation:fxUp .7s both}"+
".fx-dm:before{content:'';position:absolute;inset:0;background:linear-gradient(110deg,transparent 35%,rgba(255,255,255,.14) 50%,transparent 65%);transform:translateX(-100%);animation:fxShine 5s ease-in-out infinite}"+
"@keyframes fxShine{to{transform:translateX(100%)}}"+
".fx-dm .t{font-size:15.5px;line-height:1.9;white-space:pre-wrap;position:relative}"+
".fx-verse{padding:18px 16px;text-align:center;background:radial-gradient(circle at 50% 0,rgba(212,169,90,.22),rgba(14,27,23,.6) 70%);border:1px solid rgba(212,169,90,.45)}"+
".fx-verse .v{font-family:'Amiri','Scheherazade New','Traditional Arabic',serif;font-size:25px;line-height:2.05;color:#fff3cf;margin:6px 0}"+
".fx-verse .r{font-size:13px;color:var(--gold,#d4a95a);font-weight:700}"+
".fx-row{display:flex;gap:8px;justify-content:center;flex-wrap:wrap;margin-top:12px}"+
".fx-btn{border:0;border-radius:30px;padding:9px 16px;font:inherit;font-weight:800;font-size:13.5px;cursor:pointer;color:#2a1d05;background:linear-gradient(135deg,#f7dc8a,#d4a95a);box-shadow:0 4px 14px rgba(212,169,90,.35);transition:transform .15s}"+
".fx-btn:active{transform:scale(.94)}.fx-btn.alt{color:var(--ink,#efe6d2);background:rgba(255,255,255,.1);box-shadow:none;border:1px solid rgba(255,255,255,.2)}"+
"@media (prefers-reduced-motion:reduce){.fx-card *,.fx-card:before{animation:none!important}}";
function addCss(){if(E("fxCss"))return;var s=document.createElement("style");s.id="fxCss";s.textContent=css;document.head.appendChild(s)}

/* ---------- 1) السماء الحيّة ---------- */
var PH=[
 {k:"dawn",n:"الفجر",e:"🌌",g:"linear-gradient(180deg,#241552,#6b469c 55%,#f0a3b4)",st:1,cl:.2},
 {k:"duha",n:"الضحى",e:"🌅",g:"linear-gradient(180deg,#e39a2a,#f6c85f 55%,#fde7a6)",st:0,cl:.7},
 {k:"noon",n:"الظهيرة",e:"☀️",g:"linear-gradient(180deg,#2874cf,#62aeea 60%,#a9d8f5)",st:0,cl:.9},
 {k:"asr",n:"العصر",e:"🌤️",g:"linear-gradient(180deg,#bf6526,#ee9638 55%,#f8cf84)",st:0,cl:.7},
 {k:"sunset",n:"المغرب",e:"🌇",g:"linear-gradient(180deg,#34173f,#c2455a 55%,#f58a3a)",st:.5,cl:.45},
 {k:"night",n:"الليل",e:"🌙",g:"linear-gradient(180deg,#040916,#0c1a3b 70%,#17305c)",st:1,cl:0}
];
function mins(t){var a=t.split(":");return +a[0]*60+ +a[1]}
function phase(){
 var inf=window.Prayer&&Prayer.info?Prayer.info():null,now=new Date(),m=now.getHours()*60+now.getMinutes();
 var T=inf?{f:mins(inf.t.fajr),sr:mins(inf.t.sunrise),d:mins(inf.t.dhuhr),a:mins(inf.t.asr),m:mins(inf.t.maghrib),i:mins(inf.t.isha)}:{f:300,sr:380,d:720,a:930,m:1100,i:1180};
 var i,p=0;
 if(m>=T.f&&m<T.sr){i=0;p=(m-T.f)/(T.sr-T.f)}
 else if(m>=T.sr&&m<T.d-10){i=1}
 else if(m>=T.d-10&&m<T.a){i=2}
 else if(m>=T.a&&m<T.m){i=3}
 else if(m>=T.m&&m<T.i){i=4}
 else i=5;
 var day=m>=T.sr&&m<T.m,prog;
 if(day)prog=(m-T.sr)/(T.m-T.sr);
 else{var span=(1440-T.m)+T.sr,el=m>=T.m?m-T.m:m+1440-T.m;prog=el/span}
 return {ph:PH[i],day:day,prog:Math.min(1,Math.max(0,prog)),T:T}}
function buildSky(){
 var h=E("fxSky");if(h)return h;
 h=document.createElement("div");h.id="fxSky";h.className="fx-card fx-sky";
 var s="";for(var i=0;i<38;i++)s+='<i class="st" style="left:'+(Math.random()*100)+'%;top:'+(Math.random()*62)+'%;animation-delay:'+(Math.random()*3).toFixed(1)+'s"></i>';
 for(i=0;i<3;i++)s+='<i class="cl" style="width:'+(90+i*40)+'px;top:'+(48+i*30)+'px;animation-duration:'+(55+i*25)+'s;animation-delay:-'+(i*22)+'s"></i>';
 var sk='<svg class="sk" viewBox="0 0 400 92" preserveAspectRatio="none" aria-hidden="true"><path fill="rgba(4,9,18,.5)" d="M0 92V76H28V38L32 26L36 38V76H118Q118 58 158 54Q170 28 200 20Q230 28 242 54Q282 58 282 76H364V38L368 26L372 38V76H400V92Z"/><path fill="none" stroke="rgba(4,9,18,.5)" stroke-width="2" d="M200 20V8M196 12H204"/><path fill="rgba(4,9,18,.38)" d="M0 92V84Q60 72 120 84T240 84T400 82V92Z"/></svg>';
 h.innerHTML=s+'<i class="sun s" id="fxSun"></i>'+sk+'<div class="ov"></div><div class="top"><span class="pill" id="fxPh"></span><span class="dt" id="fxDt"></span></div><div class="tx"><div class="gr" id="fxGr"></div><div class="orn"><i></i></div><div class="sb" id="fxSb"></div><div class="nx" id="fxNx"></div></div>';
 return h}
function paintSky(){
 var h=E("fxSky");if(!h)return;var P=phase(),ph=P.ph;
 h.style.background=ph.g;
 [].forEach.call(h.querySelectorAll(".st"),function(x){x.style.opacity=ph.st});
 [].forEach.call(h.querySelectorAll(".cl"),function(x){x.style.opacity=ph.cl});
 var sun=E("fxSun");sun.className="sun "+(P.day?"s":"m");
 var x=8+P.prog*84,y=Math.max(14,66-Math.sin(P.prog*Math.PI)*46);
 sun.style.left=x+"%";sun.style.top=y+"%";
 var hr=new Date().getHours(),greet=ph.k==="dawn"?"فجر مبارك":ph.k==="night"?(hr<5?"سهر الليل عبادة":"ليلة طيبة"):ph.k==="sunset"?"مغرب هادي":hr<12?"صباح النور":"نهارك سعيد",
     bk;try{bk=g("بيك","بيكي")}catch(e){bk="بيك"}
 E("fxGr").textContent="أهلاً "+bk+NM();
 E("fxPh").textContent=ph.e+" "+ph.n;
 E("fxDt").textContent=new Date().toLocaleDateString("ar-EG",{weekday:"long",day:"numeric",month:"long"});
 E("fxSb").textContent=greet+" · دلوقتي وقت "+ph.n;
 var nx=window.Prayer&&Prayer.next?Prayer.next():null,box=E("fxNx");
 if(nx&&nx.t){var d=Math.max(0,Math.round((nx.t-Date.now())/6e4)),hh=Math.floor(d/60),mm=d%60;box.style.display="";box.innerHTML="🕌 "+esc(nx.n)+" بعد "+(hh?hh+" ساعة و ":"")+mm+" دقيقة"}else box.style.display="none"}

/* ---------- 2) عدّاد المناسبات ---------- */
var HF;try{HF=new Intl.DateTimeFormat("en-u-ca-islamic-umalqura-nu-latn",{day:"numeric",month:"numeric",year:"numeric"})}catch(e){HF=null}
function hij(d){if(!HF)return null;var o={};HF.formatToParts(d).forEach(function(p){if(p.type==="day")o.d=+p.value;if(p.type==="month")o.m=+p.value;if(p.type==="year")o.y=+p.value});return o}
var OCC=[
 {n:"الجمعة",e:"🕌",fri:1,l:"سورة الكهف · الصلاة على النبي ﷺ · ساعة الإجابة"},
 {n:"الأيام البيض",e:"🌕",m:0,d:13,l:"صيام 13 و14 و15 من كل شهر هجري"},
 {n:"رمضان",e:"🌙",m:9,d:1,l:"شهر القرآن والصيام والقيام"},
 {n:"عيد الفطر",e:"🎊",m:10,d:1,l:"تقبّل الله منّا ومنكم"},
 {n:"يوم عرفة",e:"⛰️",m:12,d:9,l:"صيامه يكفّر سنتين، وأكثر يوم للدعاء"},
 {n:"عيد الأضحى",e:"🐑",m:12,d:10,l:"التكبير والأضحية وصلة الرحم"},
 {n:"رأس السنة الهجرية",e:"🧭",m:1,d:1,l:"سنة جديدة، نيّة جديدة"},
 {n:"عاشوراء",e:"🌤️",m:1,d:10,l:"صيامه يكفّر السنة الماضية"}
];
function until(o){
 var t=new Date();t.setHours(12,0,0,0);
 if(o.fri){return (5-t.getDay()+7)%7}
 for(var i=0;i<400;i++){var d=new Date(t.getTime()+i*864e5),h=hij(d);if(!h)return null;if(h.d===o.d&&(!o.m||h.m===o.m))return i}
 return null}
function paintOcc(){
 var box=E("fxOcc");if(!box)return;var arr=[];
 OCC.forEach(function(o){var u=until(o);if(u!==null)arr.push({o:o,u:u})});
 arr.sort(function(a,b){return a.u-b.u});
 var h=hij(new Date()),top="";
 if(h&&h.m===9)top='<div class="sb" style="margin-bottom:8px;color:#ffe9a8;font-weight:800">🌙 رمضان كريم · النهاردة '+h.d+' رمضان</div>';
 box.innerHTML=top+'<div class="fx-occ">'+arr.map(function(x,i){
  var now=x.u===0;return '<div class="fx-oc'+(now?" now":"")+'" style="animation-delay:'+(i*.07)+'s"><span class="e">'+x.o.e+'</span><div class="n">'+x.o.n+'</div>'+
  (now?'<div class="d" style="font-size:18px">النهاردة ✨</div>':'<div class="d">'+x.u+'</div><div class="u">'+(x.u===1?"يوم":x.u===2?"يومين":x.u<11?"أيام":"يوم")+'</div>')+'<div class="l">'+x.o.l+'</div></div>'}).join("")+'</div>'}

/* ---------- 3) رسالة المطوّر ---------- */
function paintDm(t){
 var c=E("fxDm");if(!c)return;
 if(!t){c.style.display="none";return}
 c.style.display="";c.innerHTML='<div class="fx-h">💌 رسالة اليوم من المطوّر</div><div class="t">'+esc(t)+'</div>'}
function loadDm(n){
 paintDm((lsGet("fx_dm",{})).text||"");
 try{if(typeof db!=="undefined"&&db){db.collection("content").doc("devmsg").get().then(function(s){var d=s.exists?s.data():{};lsSet("fx_dm",{text:d.text||""});paintDm(d.text||"")}).catch(function(){});return}}catch(e){}
 if((n||0)<8)setTimeout(function(){loadDm((n||0)+1)},2500)}
function buildDevPanel(){
 var ed=E("edit");if(!ed||E("fxDevP"))return;var p=ed.querySelector(".panel")||ed,d=document.createElement("div");d.id="fxDevP";d.style.cssText="margin-top:14px;padding-top:12px;border-top:1px dashed rgba(255,255,255,.2)";
 d.innerHTML='<h3 style="margin:0 0 8px">💌 رسالة اليوم للمستخدمين</h3><textarea id="fxDevT" rows="3" style="width:100%;box-sizing:border-box" placeholder="اكتب رسالة تظهر في الرئيسية لكل المستخدمين"></textarea><div class="fx-row" style="justify-content:flex-start"><button class="fx-btn" id="fxDevS">نشر الرسالة 🚀</button><button class="fx-btn alt" id="fxDevC">مسح الرسالة</button></div><div class="mute" id="fxDevM" style="margin-top:6px"></div>';
 p.appendChild(d);E("fxDevT").value=(lsGet("fx_dm",{})).text||"";
 var go=function(txt){var m=E("fxDevM");if(typeof db==="undefined"||!db){m.textContent="لازم تكون مسجّل دخول";return}
  db.collection("content").doc("devmsg").set({text:txt,at:Date.now()}).then(function(){lsSet("fx_dm",{text:txt});paintDm(txt);m.textContent=txt?"اتنشرت ✅":"اتمسحت ✅"}).catch(function(e){m.textContent="خطأ: "+(e.code||e.message)})};
 E("fxDevS").onclick=function(){go(E("fxDevT").value.trim())};
 E("fxDevC").onclick=function(){E("fxDevT").value="";go("")}}

/* ---------- 4) آية اليوم ---------- */
var VS=[
["أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ","الرعد · 28"],
["فَإِنَّ مَعَ الْعُسْرِ يُسْرًا ۝ إِنَّ مَعَ الْعُسْرِ يُسْرًا","الشرح · 5-6"],
["وَمَن يَتَّقِ اللَّهَ يَجْعَل لَّهُ مَخْرَجًا","الطلاق · 2"],
["وَلَسَوْفَ يُعْطِيكَ رَبُّكَ فَتَرْضَىٰ","الضحى · 5"],
["فَاذْكُرُونِي أَذْكُرْكُمْ وَاشْكُرُوا لِي وَلَا تَكْفُرُونِ","البقرة · 152"],
["وَإِذَا سَأَلَكَ عِبَادِي عَنِّي فَإِنِّي قَرِيبٌ ۖ أُجِيبُ دَعْوَةَ الدَّاعِ إِذَا دَعَانِ","البقرة · 186"],
["لَا يُكَلِّفُ اللَّهُ نَفْسًا إِلَّا وُسْعَهَا","البقرة · 286"],
["وَهُوَ مَعَكُمْ أَيْنَ مَا كُنتُمْ","الحديد · 4"],
["إِنَّ اللَّهَ مَعَ الصَّابِرِينَ","البقرة · 153"],
["وَمَا تَوْفِيقِي إِلَّا بِاللَّهِ","هود · 88"],
["حَسْبُنَا اللَّهُ وَنِعْمَ الْوَكِيلُ","آل عمران · 173"],
["أَلَيْسَ اللَّهُ بِكَافٍ عَبْدَهُ","الزمر · 36"],
["وَرَحْمَتِي وَسِعَتْ كُلَّ شَيْءٍ","الأعراف · 156"],
["فَاصْبِرْ صَبْرًا جَمِيلًا","المعارج · 5"]];
function rnd(a){return function(){a|=0;a=a+0x6D2B79F5|0;var t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
function rawV(d){return Math.floor(rnd(d*2654435761)()*VS.length)}
function todayV(){var d=dayN(),i=rawV(d);if(i===rawV(d-1))i=(i+1)%VS.length;return VS[i]}
function paintVerse(){var c=E("fxVerse");if(!c)return;var v=todayV();
 c.innerHTML='<div class="fx-h" style="justify-content:center">✨ آية اليوم</div><div style="font-size:26px;opacity:.5">﴿</div><div class="v">'+v[0]+'</div><div style="font-size:26px;opacity:.5">﴾</div><div class="r">'+v[1]+'</div>'+
 '<div class="fx-row"><button class="fx-btn" id="fxShr">📸 شاركها كصورة</button></div>';
 E("fxShr").onclick=function(){shareVerse(v)}}
function wrap(ctx,t,w){var ws=t.split(" "),L=[],c="";ws.forEach(function(x){var n=c?c+" "+x:x;if(ctx.measureText(n).width>w&&c){L.push(c);c=x}else c=n});if(c)L.push(c);return L}
function shareVerse(v){
 var W=1080,H=1920,cv=document.createElement("canvas");cv.width=W;cv.height=H;var x=cv.getContext("2d");
 var g=x.createLinearGradient(0,0,0,H);g.addColorStop(0,"#06130e");g.addColorStop(.55,"#12301f");g.addColorStop(1,"#0a1d14");x.fillStyle=g;x.fillRect(0,0,W,H);
 /* زخرفة هندسية */
 x.strokeStyle="rgba(212,169,90,.13)";x.lineWidth=2;
 for(var gx=0;gx<=W;gx+=120)for(var gy=0;gy<=H;gy+=120){x.save();x.translate(gx,gy);x.rotate(Math.PI/4);x.strokeRect(-42,-42,84,84);x.rotate(Math.PI/4);x.strokeRect(-42,-42,84,84);x.restore()}
 var r=x.createRadialGradient(W/2,H/2,50,W/2,H/2,900);r.addColorStop(0,"rgba(212,169,90,.22)");r.addColorStop(1,"rgba(0,0,0,.55)");x.fillStyle=r;x.fillRect(0,0,W,H);
 x.strokeStyle="#d4a95a";x.lineWidth=6;x.strokeRect(70,70,W-140,H-140);x.lineWidth=2;x.strokeRect(95,95,W-190,H-190);
 x.textAlign="center";x.direction="rtl";x.textBaseline="middle";
 x.fillStyle="#d4a95a";x.font="800 54px Tahoma,Arial,sans-serif";x.fillText("✦  آية اليوم  ✦",W/2,260);
 x.fillStyle="#fff3cf";x.font="700 84px 'Amiri','Scheherazade New','Traditional Arabic',Tahoma,serif";
 var L=wrap(x,"﴿ "+v[0]+" ﴾",W-300),lh=150,y0=H/2-(L.length-1)*lh/2;L.forEach(function(l,i){x.fillText(l,W/2,y0+i*lh)});
 x.fillStyle="#d4a95a";x.font="800 52px Tahoma,Arial,sans-serif";x.fillText(v[1],W/2,y0+L.length*lh+50);
 x.fillStyle="rgba(255,255,255,.55)";x.font="600 38px Tahoma,Arial,sans-serif";x.fillText("وِرْد",W/2,H-190);
 cv.toBlob(function(b){if(window.NativeApp){NativeApp.shareBlob(b,"ayah.png").catch(function(){});return}var f=new File([b],"ayah.png",{type:"image/png"});
  if(navigator.canShare&&navigator.canShare({files:[f]}))navigator.share({files:[f]}).catch(function(){});
  else{var a=document.createElement("a");a.href=URL.createObjectURL(b);a.download="ayah.png";a.click();setTimeout(function(){URL.revokeObjectURL(a.href)},4e3)}},"image/png")}

/* ---------- تركيب كل ده في الرئيسية ---------- */
function mk(id,cls,html){var d=document.createElement("div");d.id=id;d.className="fx-card "+cls;if(html)d.innerHTML=html;return d}
function init(){
 var home=E("home");if(!home||E("fxSky"))return;addCss();
 var first=home.firstChild,add=function(n){home.insertBefore(n,first)};
 add(buildSky());
 add(mk("fxDm","fx-dm"));
 var oc=mk("fxOcc0","");oc.style.overflow="visible";oc.innerHTML='<div class="fx-h">🗓️ المناسبات الجاية</div><div id="fxOcc"></div>';add(oc);
 add(mk("fxVerse","fx-verse"));
 add(mk("fxDua","fx-dua"));
 paintSky();paintOcc();paintVerse();loadDm();buildDevPanel();
 setInterval(paintSky,30000);setInterval(paintOcc,36e5);
 document.addEventListener("visibilitychange",function(){if(!document.hidden){paintSky();paintOcc()}})}
window.Feat={refresh:function(){paintSky();paintOcc()}};
if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",init);else init();
})();
