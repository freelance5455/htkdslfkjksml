/* ===== صلاتك: مواعيد الصلاة + تعليم اللي صليته ===== */
(function(){
"use strict";
var E=function(i){return document.getElementById(i)};
var pad=function(n){return String(n).padStart(2,"0")};
var dk=function(d){return d.getFullYear()+"-"+pad(d.getMonth()+1)+"-"+pad(d.getDate())};
var LIST=[["fajr","الفجر","🌙"],["dhuhr","الظهر","☀️"],["asr","العصر","🌤️"],["maghrib","المغرب","🌇"],["isha","العشاء","🌃"]];
var DEF={lat:30.0444,lon:31.2357};   // القاهرة، لحد ما المستخدم يحدد موقعه
var S=null,loaded="",cache=null;

/* ---------- حساب المواعيد (طريقة الهيئة المصرية العامة للمساحة: فجر 19.5° وعشاء 17.5°، عصر عادي) ---------- */
var R=Math.PI/180,sin=function(d){return Math.sin(d*R)},cos=function(d){return Math.cos(d*R)},tan=function(d){return Math.tan(d*R)},
    asin=function(x){return Math.asin(x)/R},acos=function(x){return Math.acos(x)/R},atan2=function(y,x){return Math.atan2(y,x)/R},acot=function(x){return Math.atan(1/x)/R},
    fixa=function(a){return ((a%360)+360)%360},fixh=function(h){return ((h%24)+24)%24};
function julian(y,m,d){if(m<=2){y-=1;m+=12}var A=Math.floor(y/100),B=2-A+Math.floor(A/4);return Math.floor(365.25*(y+4716))+Math.floor(30.6001*(m+1))+d+B-1524.5}
function sunPos(jd){var D=jd-2451545.0,g=fixa(357.529+0.98560028*D),q=fixa(280.459+0.98564736*D),L=fixa(q+1.915*sin(g)+0.020*sin(2*g)),e=23.439-0.00000036*D,
  RA=atan2(cos(e)*sin(L),cos(L))/15;return {decl:asin(sin(e)*sin(L)),eqt:q/15-fixh(RA)}}
function loc(){try{var o=JSON.parse(localStorage.getItem("q_pray_loc"));if(o&&isFinite(o.lat)&&isFinite(o.lon))return o}catch(e){}return DEF}
function hasLoc(){return loc()!==DEF}
function times(d){
  var l=loc(),y=d.getFullYear(),m=d.getMonth()+1,dd=d.getDate(),ck=y+"-"+m+"-"+dd+"|"+l.lat+"|"+l.lon;
  if(cache&&cache.k===ck)return cache.v;
  var tz=-new Date(y,m-1,dd,12).getTimezoneOffset()/60,jd=julian(y,m,dd)-l.lon/360;
  function mid(t){return fixh(12-sunPos(jd+t).eqt)}
  function sat(ang,t,ccw){var dc=sunPos(jd+t).decl,x=(-sin(ang)-sin(dc)*sin(l.lat))/(cos(dc)*cos(l.lat));if(x>1||x<-1)return NaN;var h=acos(x)/15;return mid(t)+(ccw?-h:h)}
  function asr(f,t){var dc=sunPos(jd+t).decl;return sat(-acot(f+tan(Math.abs(l.lat-dc))),t,false)}
  var raw={fajr:sat(19.5,5/24,true),sunrise:sat(0.833,6/24,true),dhuhr:mid(12/24),asr:asr(1,13/24),maghrib:sat(0.833,18/24,false),isha:sat(17.5,18/24,false)},
      adj=tz-l.lon/15,base=new Date(y,m-1,dd,0,0,0).getTime(),o={};
  Object.keys(raw).forEach(function(k){o[k]=base+Math.round((raw[k]+adj)*60)*60000});
  cache={k:ck,v:o};return o}

/* ---------- الحالة (اللي صليته) ---------- */
function key(){return "q_pray_"+(typeof uid!=="undefined"&&uid?uid:"")}
function load(){var k=key();if(S&&loaded===k)return;loaded=k;try{S=JSON.parse(localStorage.getItem(k))||{}}catch(e){S={}}if(!S.days)S.days={};if(!S.u)S.u=0}
function saveLocal(){try{localStorage.setItem(key(),JSON.stringify(S))}catch(e){}}
function push(){if(typeof db!=="undefined"&&db&&typeof uid!=="undefined"&&uid)db.collection("users").doc(uid).set({pray:S},{merge:true}).catch(function(){})}
function done(k,id){load();return !!(S.days[k]&&S.days[k][id])}
function resync(){try{if(window.Notif&&Notif.sync)Notif.sync()}catch(e){}}
function toastM(m){if(typeof toast==="function")toast(m)}
function earlyMsg(id){var f=(typeof prof!=="undefined"&&prof&&prof.gender==="f"),n=(typeof prof!=="undefined"&&prof&&prof.name)||"";
  return {t:nameOf(id)+" لسه ما أذّنش "+""+(n?" يا "+n:"")+" 🤥",b:"إيه ده؟ "+(f?"إنتي":"إنت")+" هتصلّيه قبل ما يأذّن؟ 🤦🏻"}}
function warnFx(m,tag,emo){try{
  fxCss();var old=E("prFx");if(old&&old.parentNode)old.parentNode.removeChild(old);clearTimeout(fxT);
  var o=document.createElement("div");o.id="prFx";o.className="pr-fx warn";
  o.innerHTML='<div class="pr-card"><div class="l1">'+esc(m.t)+'</div><div class="l2">'+esc(m.b)+'</div></div>';
  document.body.appendChild(o);rain(o,14,.6,emo);
  try{if(navigator.vibrate)navigator.vibrate([40,40,40])}catch(e){}
  fxT=setTimeout(closeFx,3200)}catch(e){}}
function earlyWarn(id){warnFx(earlyMsg(id),"wird-early-"+id,["🤥","🤦🏻","🔒","⏳"])}
function doneMsg(id){var f=(typeof prof!=="undefined"&&prof&&prof.gender==="f"),n=(typeof prof!=="undefined"&&prof&&prof.name)||"";
  return {t:(f?"إنتي":"إنت")+" خلاص "+(f?"صلّيتيها":"صلّيتها")+" "+""+(n?" يا "+n:"")+" 🔒",b:"إيه اللي لسه؟ "+(f?"إنتي":"إنت")+" بتشتغلني ولا إيه؟ 🤷🏻🙄"}}
function lockMsg(id){var f=(typeof prof!=="undefined"&&prof&&prof.gender==="f");
  return {t:"خلاص"+nmx()+" 🔒",b:"هتصلّيها تاني ولا إيه؟ هي دلوقتي مقفولة ومش هتفتح غير بكرة لما تأذّن تاني 🕌"}}
function lockWarn(id){warnFx(lockMsg(id),"wird-lock-"+id,["🕌","🔒","✅","🤲🏻"])}
function doneWarn(id){warnFx(doneMsg(id),"wird-done-"+id,["🤷🏻","🙄","🔒","✅"])}
function setP(id,v){load();var pd=pday(),k=dk(pd),T=times(pd),day=S.days[k]||(S.days[k]={});v=v?1:0;
  if(!T[id])return;
  if(Date.now()<T[id])return earlyWarn(id);
  if(day[id]){if(!v)return doneWarn(id);return lockWarn(id)}
  if(!v)return toastM("تمام، هفضل أفكّرك ⏳");
  day[id]=1;S.u=Date.now();
  var ks=Object.keys(S.days).sort();while(ks.length>60)delete S.days[ks.shift()];
  saveLocal();push();render();home();resync();
  celebrate(id,counts()>=LIST.length)}
function tog(id){setP(id,1)}

/* ---------- احتفال: دعاء + إيموجي نازلة ---------- */
var fxT=0;
var ESC={"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"};
function esc(s){return String(s).replace(/[&<>"]/g,function(c){return ESC[c]})}
function who(){var f=(typeof prof!=="undefined"&&prof&&prof.gender==="f"),n=(typeof prof!=="undefined"&&prof&&prof.name)||"";
  return {f:f,t:(n?esc(n):"")}}
function fxCss(){if(E("prFxCss"))return;var s=document.createElement("style");s.id="prFxCss";
  s.textContent=".pr-fx{position:fixed;inset:0;z-index:300;display:flex;align-items:center;justify-content:center;padding:20px;overflow:hidden;direction:rtl;pointer-events:none;animation:prFade .35s ease both}"+
  ".pr-fx.big{pointer-events:auto;background:radial-gradient(circle at 50% 45%,rgba(224,184,74,.35),rgba(0,0,0,.78) 70%)}"+
  ".pr-fx.out{animation:prOut .45s ease forwards}.pr-fx.warn .pr-card{border-color:#e07a6a;box-shadow:0 10px 40px rgba(0,0,0,.5),0 0 28px rgba(224,122,106,.55)}.pr-fx.warn .l1{color:#ffb4a8;font-size:22px}"+
  ".pr-card{position:relative;z-index:2;text-align:center;max-width:340px;padding:20px 22px;border-radius:22px;background:rgba(14,27,23,.94);color:#fff;border:2px solid #e0b84a;box-shadow:0 10px 40px rgba(0,0,0,.5),0 0 30px rgba(224,184,74,.45);animation:prPop .7s cubic-bezier(.2,1.5,.4,1) both;line-height:1.6}"+
  ".pr-card .l1{font-size:26px;font-weight:800;color:#ffe08a}.pr-card .l2{font-size:20px;font-weight:700;margin-top:4px}.pr-card .l3{font-size:13px;opacity:.8;margin-top:8px}"+
  ".pr-fx.big .pr-card{max-width:360px;padding:30px 24px;border-radius:28px;animation:prPop .9s cubic-bezier(.2,1.5,.4,1) both,prGlow 1.6s ease-in-out infinite alternate}"+
  ".pr-fx.big .l1{font-size:32px}.pr-fx.big .l2{font-size:23px;margin-top:8px}.pr-fx.big .big-e{font-size:54px;line-height:1.2;animation:prBounce 1s ease-in-out infinite}"+
  ".pr-e{position:absolute;top:-12vh;z-index:1;will-change:transform;animation:prFall linear forwards;user-select:none}"+
  "@keyframes prFall{0%{transform:translateY(0) rotate(0) scale(.8);opacity:0}8%{opacity:1}100%{transform:translateY(125vh) rotate(var(--r,360deg)) scale(1.1);opacity:1}}"+
  "@keyframes prPop{0%{transform:scale(.3) translateY(40px);opacity:0}100%{transform:scale(1) translateY(0);opacity:1}}"+
  "@keyframes prFade{from{opacity:0}to{opacity:1}}@keyframes prOut{to{opacity:0}}"+
  "@keyframes prGlow{from{box-shadow:0 10px 40px rgba(0,0,0,.5),0 0 20px rgba(224,184,74,.35)}to{box-shadow:0 10px 40px rgba(0,0,0,.5),0 0 55px rgba(224,184,74,.9)}}"+
  "@keyframes prBounce{0%,100%{transform:translateY(0) scale(1)}50%{transform:translateY(-8px) scale(1.12)}}"+
  "@media (prefers-reduced-motion:reduce){.pr-e{display:none}}";
  document.head.appendChild(s)}
var EMJ=["🥳","🤩","✨","🙋🏻","🙋🏻‍♀️","💫","🤲🏻","🎉","🌟","🤍"];
function rain(box,n,span,lst){lst=lst||EMJ;for(var i=0;i<n;i++){var e=document.createElement("span");e.className="pr-e";e.textContent=lst[Math.floor(Math.random()*lst.length)];
  e.style.left=(Math.random()*96)+"%";e.style.fontSize=(20+Math.random()*20)+"px";
  e.style.animationDuration=(2.4+Math.random()*2)+"s";e.style.animationDelay=(Math.random()*span)+"s";
  e.style.setProperty("--r",(Math.random()<.5?-1:1)*(180+Math.random()*360)+"deg");box.appendChild(e)}}
function closeFx(){var o=E("prFx");if(!o)return;clearTimeout(fxT);o.classList.add("out");setTimeout(function(){if(o.parentNode)o.parentNode.removeChild(o)},450)}
function celebrate(id,all){try{
  fxCss();var old=E("prFx");if(old&&old.parentNode)old.parentNode.removeChild(old);clearTimeout(fxT);
  var w=who(),o=document.createElement("div");o.id="prFx";o.className="pr-fx"+(all?" big":"");
  if(all)o.innerHTML='<div class="pr-card"><div class="big-e">🎉🤲🏻🎉</div><div class="l1">'+(w.f?"الله يفتح عليكي":"الله يفتح عليك")+'</div><div class="l2">'+w.t+' ✨<br>ويثبّتكو يارب 💫</div><div class="l3">'+(w.f?"خلّصتي":"خلّصت")+' صلواتك كلها النهاردة 🕌<br>دوس في أي مكان للإغلاق</div></div>';
  else o.innerHTML='<div class="pr-card"><div class="l1">اللهم بارك 🤲🏻</div><div class="l2">اللهم الثبات '+(w.t?'يا '+w.t:'')+' 💫</div><div class="l3">'+(w.f?"صلّيتي ":"صلّيت ")+esc(nameOf(id))+' ✅</div></div>';
  document.body.appendChild(o);rain(o,all?90:30,all?2.5:.8);
  if(all)o.addEventListener("click",closeFx);
  try{if(navigator.vibrate)navigator.vibrate(all?[80,60,80,60,200]:[60])}catch(e){}
  fxT=setTimeout(closeFx,all?9000:3200)}catch(e){}}

/* ---------- عرض ---------- */
function fmt(ms){var d=new Date(ms),h=d.getHours(),a=h<12?"ص":"م";h=h%12||12;return pad(h)+":"+pad(d.getMinutes())+" "+a}
function dur(ms){var m=Math.max(0,Math.round(ms/60000)),h=Math.floor(m/60);m=m%60;if(!h&&!m)return "أقل من دقيقة";return (h?h+" س":"")+(h&&m?" و ":"")+(m?m+" د":"")}
function nameOf(id){for(var i=0;i<LIST.length;i++)if(LIST[i][0]===id)return LIST[i][1];return id}
function next(){var now=Date.now(),T=times(new Date());
  for(var i=0;i<LIST.length;i++)if(T[LIST[i][0]]>now)return {id:LIST[i][0],n:LIST[i][1],t:T[LIST[i][0]]};
  var tm=times(new Date(Date.now()+864e5));return {id:"fajr",n:"الفجر",t:tm.fajr}}
function lastP(){var now=Date.now(),T=times(new Date()),r=null;
  LIST.forEach(function(p){if(T[p[0]]<=now)r={id:p[0],n:p[1],t:T[p[0]]}});return r||next()}
function css(){if(E("prCss"))return;var s=document.createElement("style");s.id="prCss";
  s.textContent=".pr-row{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:10px 12px;margin:8px 0;border-radius:14px;background:var(--card);border:1px solid rgba(127,127,127,.3);text-align:right}.pr-row b{font-size:18px}.pr-row small{display:block;color:var(--mute);font-size:12px}.pr-t{direction:ltr;font-weight:800;font-size:18px;flex:none}.pr-row{flex-wrap:wrap}.pr-bs{flex:1 0 100%;display:flex;gap:8px}.pr-btn{flex:1;padding:9px 6px;border-radius:12px;font-size:15px;transition:transform .15s,opacity .2s}.pr-btn:active{transform:scale(.95)}.pr-btn.lk{background:#23282a!important;color:#8b979c!important;border:1px solid rgba(127,127,127,.4);box-shadow:inset 0 0 14px rgba(0,0,0,.55);filter:grayscale(.7) brightness(.85);cursor:not-allowed}.pr-btn.go{background:#e9fff3!important;color:#0d6a42!important;border:2px solid #1b9e63;box-shadow:0 0 12px rgba(27,158,99,.45)}.pr-btn.dim{opacity:.4;cursor:not-allowed}.pr-btn.unl{animation:prUnl 1.1s ease 3}@keyframes prUnl{0%{filter:brightness(.35);transform:scale(.9)}40%{transform:scale(1.1);box-shadow:0 0 24px 8px rgba(224,184,74,.95)}100%{filter:none;transform:scale(1)}}.pr-btn:disabled{opacity:.4;cursor:not-allowed;transform:none}.pr-btn.on-y:disabled{opacity:1}.pr-row.lck{opacity:.8}.pr-btn.alt{opacity:.7}.pr-btn.on-y{background:#1b9e63!important;color:#fff!important;box-shadow:0 0 0 2px rgba(27,158,99,.35)}.pr-btn.on-n{background:#e0b84a!important;color:#1a1405!important;box-shadow:0 0 0 2px rgba(224,184,74,.35)}.pr-row.done{border-color:rgba(27,158,99,.7)}.pr-row.nxt{border-color:#e0b84a;box-shadow:0 0 0 2px rgba(224,184,74,.35)}.pr-row.info{opacity:.8}";
  document.head.appendChild(s)}
function pday(){var n=new Date(),T=times(n);return n.getTime()<T.fajr?new Date(n.getTime()-864e5):n}   // "يوم الصلاة" بيبدأ مع أذان الفجر، فالعشاء بعد منتصف الليل لسه تبع امبارح
function pk(){return dk(pday())}
function counts(){var k=pk(),n=0;LIST.forEach(function(p){if(done(k,p[0]))n++});return n}
var lkSeen={},unlAt={},rt=0,ut=0;
function render(){var sec=E("prayer");if(!sec)return;css();load();
  var now=Date.now(),pd=pday(),k=dk(pd),T=times(pd),isT=(k===dk(new Date())),nx=next(),n=counts(),nextUnlock=0,freshEnd=0;
  var rows=LIST.map(function(p){var id=p[0],dn=done(k,id),lock=now<T[id],ky=k+id;
    if(lkSeen[ky]===true&&!lock&&now-T[id]<20000)unlAt[ky]=now;
    lkSeen[ky]=lock;
    if(lock&&(!nextUnlock||T[id]<nextUnlock))nextUnlock=T[id];
    var fresh=!lock&&!dn&&unlAt[ky]&&now-unlAt[ky]<4000;if(fresh)freshEnd=unlAt[ky]+4100;
    var sub=dn?'صليتها ✅ 🔒 مقفولة لحد فجر بكرة':(lock?'🔒 هتتفتح الساعة '+fmt(T[id]):'وقتها جه ولسه ما علّمتش ⏰'),
        cy=dn?'on-y':(lock?'lk':'go'),cn=dn?'dim':(lock?'lk':'on-n'),
        ly=lock?'🔒 صليت':(dn?'✅🔒 صليت':(fresh?'🔓 صليت':'✅ صليت')),ln=(lock||dn)?'🔒 لسه':'⏳ لسه',fz=fresh?' unl':'';
    var r='<div class="pr-row'+(dn?' done':'')+(lock&&!dn?' lck':'')+(isT&&nx.id===id&&!dn?' nxt':'')+'"><div><b>'+p[2]+' '+p[1]+'</b><small>'+sub+'</small></div><span class="pr-t">'+fmt(T[id])+'</span>'+
      '<div class="pr-bs"><button class="pr-btn '+cy+fz+'" aria-disabled="'+((lock||dn)?1:0)+'" onclick="Prayer.mark(\''+id+'\',1)">'+ly+'</button><button class="pr-btn '+cn+fz+'" aria-disabled="'+((lock||dn)?1:0)+'" onclick="Prayer.mark(\''+id+'\',0)">'+ln+'</button></div></div>';
    if(id==="fajr")r+='<div class="pr-row info"><div><b>🌅 الشروق</b></div><span class="pr-t">'+fmt(T.sunrise)+'</span></div>';
    return r}).join("");
  sec.innerHTML='<div class="panel"><h2>🕌 صلاتك</h2><div class="nt-st" style="margin:8px 0;font-weight:700">الصلاة الجاية: '+nx.n+' بعد '+dur(nx.t-now)+'</div>'+(isT?'':'<div class="mute" style="margin-bottom:6px">🌙 الفجر لسه ما أذّنش، دي صلوات امبارح لحد ما يؤذّن</div>')+'<div class="mute" style="margin-bottom:6px">النهاردة صليت '+n+' من '+LIST.length+' · 📍 '+(hasLoc()?'حسب موقعك':'القاهرة (تقريبي)')+'</div>'+rows+
   '<div class="mute" style="margin-top:10px">الأزرار بتتفتح لما يأذّن وقت الصلاة. لو سايبها «⏳ لسه» هيفضل يفكّرك بإشعارات، ولما تدوس «✅ صليت» التذكير بيقف وبتتثبّت لحد فجر بكرة.</div><div class="mute" style="margin-top:10px">المواعيد محسوبة بطريقة الهيئة المصرية العامة للمساحة، وممكن تختلف دقيقة أو اتنين عن جامعك. اعتمد على الأذان.</div>'+
   '<div class="row"><button class="alt" onclick="Prayer.loc()">📍 استخدم موقعي</button><button class="alt" onclick="show(\'home\')">⬅️ رجوع</button></div></div>';
  clearTimeout(rt);clearTimeout(ut);
  if(nextUnlock)rt=setTimeout(function(){render();home()},Math.max(500,nextUnlock-Date.now()+400));
  if(freshEnd)ut=setTimeout(function(){render()},Math.max(300,freshEnd-Date.now()))}
function home(){var a=E("prSmall"),b=E("prNextT");if(!a&&!b)return;var nx=next();
  if(a)a.textContent="صليت "+counts()+" من "+LIST.length+" النهاردة";
  if(b)b.textContent=nx.n+" "+fmt(nx.t)+" · بعد "+dur(nx.t-Date.now())}
function askLoc(){var t=function(m){if(typeof toast==="function")toast(m)};
  if(!navigator.geolocation)return t("المتصفح مش بيدعم تحديد الموقع");
  navigator.geolocation.getCurrentPosition(function(p){try{localStorage.setItem("q_pray_loc",JSON.stringify({lat:+p.coords.latitude.toFixed(3),lon:+p.coords.longitude.toFixed(3)}))}catch(e){}
    cache=null;render();home();resync();t("اتحدد موقعك 📍 والمواعيد اتحدّثت")},function(){t("مقدرتش أحدد موقعك، تأكد إن إذن الموقع مفتوح")},{timeout:12000})}
function info(){var l=loc(),d=new Date(),T=times(d),k=dk(d),o={lat:l.lat,lon:l.lon,tz:(Intl.DateTimeFormat().resolvedOptions().timeZone||"Africa/Cairo"),t:{},done:{d:k}};
  LIST.forEach(function(p){var x=new Date(T[p[0]]);o.t[p[0]]=pad(x.getHours())+":"+pad(x.getMinutes());o.done[p[0]]=done(k,p[0])?1:0});var sr=new Date(T.sunrise);o.t.sunrise=pad(sr.getHours())+":"+pad(sr.getMinutes());return o}

window.Prayer={open:function(){render();show("prayer")},tog:tog,mark:setP,celebrate:celebrate,loc:askLoc,times:times,done:done,next:next,last:lastP,info:info,name:nameOf,LIST:LIST,home:home};
window.prayRemote=function(r){load();if(r&&typeof r==="object"&&(r.u||0)>(S.u||0)){S=Object.assign({days:{},u:0},r);if(!S.days)S.days={};saveLocal();if(typeof cur_v!=="undefined"&&cur_v==="prayer")render();home()}};
var prev=window.onUserSwitch;
window.onUserSwitch=function(){if(prev)try{prev()}catch(e){}S=null;load();home();if(typeof cur_v!=="undefined"&&cur_v==="prayer")render()};
home();setInterval(function(){home();if(typeof cur_v!=="undefined"&&cur_v==="prayer")render()},15000);
document.addEventListener("visibilitychange",function(){if(!document.hidden){home();if(typeof cur_v!=="undefined"&&cur_v==="prayer")render()}});
})();
