/* املا القيم دي من Firebase Console > Project settings > Your apps > Web app.
   سيبها فاضية والموقع هيشتغل محليًا بدون Firebase. */
window.APP_CONFIG = {
  firebase: { apiKey: "AIzaSyC7_NW4GCrc3cbQM3B15EpoFPe2deGSILY", authDomain: "werd-3095f.firebaseapp.com", projectId: "werd-3095f", storageBucket: "werd-3095f.firebasestorage.app", messagingSenderId: "332582089006", appId: "1:332582089006:web:ef768272452958124ecabf" },
  adminEmails: ["lovefreedme88@gmail.com"],  // ضع هنا إيميلك (مثال: ["you@gmail.com"]) عشان قائمة edit تفتح لحسابك انت بس. سيبها فاضية = أي حساب بباسورد التعديل بتاعه
  vapidKey: "BDKqGuyjCDvru0BzZOVbw__MCYCVAyx4SMLGQ_ov7S-LWq2QSKgUcGUmE79Mf61NN9qvj0bh2Lf6XBXmd6swR8A",   // للإشعارات: Firebase Console > Cloud Messaging > Web Push certificates
  workers: {      // روابط Cloudflare Workers بعد النشر
    notify: "",
    api:    "https://quran-admin.lovefreedme88.workers.dev",
    media:  ""
  }
};
