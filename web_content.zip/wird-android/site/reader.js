/* ===== المصحف: قراءة بالتشكيل والتجويد (نص quran-tajweed من alquran.cloud) =====
   بيتحمّل مرة واحدة ويتخزّن على الجهاز (IndexedDB)، وبعدها بيشتغل من غير نت.
   صيغة النص: [h:9421[ٱ] = حرف عليه حكم تجويد. الحرف قبل : هو نوع الحكم. */
(function(){
"use strict";
var E=function(id){return document.getElementById(id)};
var API="https://api.alquran.cloud/v1/quran/quran-tajweed",IDB="q_reader",STORE="d",DKEY="tajweed-v1",PK="q_rd";
var D=null,PR=null,SO=null,loading=false,failed=false,jumpOpen=false,legOpen=false,sel=-1,J={s:-1,m:""};
var P=loadPrefs();

/* ----- أنواع التجويد: [اسم، لون فاتح، لون ليلي، شرح مختصر] ----- */
var RULES={
 h:["همزة الوصل","#9a9a9a","#9aa0a6","لا تُنطق في الوصل"],
 s:["حرف لا يُنطق","#9a9a9a","#9aa0a6","حرف ساكن لا يُلفظ"],
 l:["لام شمسية","#9a9a9a","#9aa0a6","لا تُنطق وتُدغم في الحرف بعدها"],
 n:["مد طبيعي","#537FFF","#86a6ff","حركتان"],
 p:["مد جائز","#4050FF","#8f99ff","2 أو 4 أو 6 حركات"],
 m:["مد لازم","#000EBC","#7480ff","6 حركات"],
 o:["مد واجب","#2144C1","#7f9bff","4–5 حركات"],
 q:["قلقلة","#DD0008","#ff6268","اهتزاز الصوت على (قطب جد)"],
 c:["إخفاء شفوي","#D500B7","#ff63e6","الميم الساكنة قبل الباء"],
 f:["إخفاء","#9400A8","#d77bff","النون الساكنة أو التنوين"],
 w:["إدغام شفوي","#58B800","#93e040","ميم ساكنة قبل ميم"],
 i:["إقلاب","#26BFFD","#4fd0ff","النون الساكنة أو التنوين قبل الباء"],
 a:["إدغام بغنة","#169777","#3bd6ae","في حروف (ينمو)"],
 u:["إدغام بغير غنة","#169200","#58d63f","اللام والراء"],
 d:["إدغام متجانسين","#A1A1A1","#b8b8b8","حرفان من نفس المخرج"],
 b:["إدغام متقاربين","#A1A1A1","#b8b8b8","حرفان متقاربان في المخرج"],
 g:["غنة","#FF7E1E","#ff9a4d","نون أو ميم مشددة (حركتان)"]
};
var LEGEND_ORDER="n p o m q g f c i a u w l h d".split(" ");

function loadPrefs(){
  var d={p:1,fs:28,tj:1,th:"paper",bm:-1};
  try{var c=JSON.parse(localStorage.getItem(PK));if(c){d.p=+c.p||1;d.fs=Math.min(48,Math.max(18,+c.fs||28));d.tj=c.tj===0?0:1;d.th=c.th==="dark"?"dark":"paper";d.bm=(c.bm>=0)?+c.bm:-1}}catch(e){}
  return d;
}
function savePrefs(){try{localStorage.setItem(PK,JSON.stringify(P))}catch(e){}}
var esc=function(s){return String(s).replace(/[&<>"]/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]})};
var ar=function(n){return String(n).replace(/\d/g,function(d){return "٠١٢٣٤٥٦٧٨٩".charAt(d)})};
var norm=function(t){return String(t).replace(/[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED\u0640]/g,"").replace(/[أإآٱ]/g,"ا").replace(/ى/g,"ي").replace(/ة/g,"ه").replace(/\s+/g," ").trim()};

/* ----- تحليل النص ----- */
function segs(raw){
  var out=[],re=/\[([a-z])(?::\d+)?\[([^\]]*)\]/g,last=0,m;
  while((m=re.exec(raw))){
    if(m.index>last)out.push({c:"",t:raw.slice(last,m.index)});
    out.push({c:m[1],t:m[2]});last=re.lastIndex;
  }
  if(last<raw.length)out.push({c:"",t:raw.slice(last)});
  return out;
}
function plainOf(raw){return segs(raw).map(function(x){return x.t}).join("")}
/* أول آية في كل سورة (غير الفاتحة والتوبة) فيها البسملة، بنفصلها ونعرضها سطر لوحدها */
function stripBasmala(raw){
  var sg=segs(raw),plain=sg.map(function(x){return x.t}).join(""),w=plain.trim().split(/\s+/);
  if(w.length<5||norm(w.slice(0,4).join(" "))!=="بسم الله الرحمن الرحيم")return raw;
  var pos=0,L=plain.length,k,sp=/\s/;
  while(pos<L&&sp.test(plain.charAt(pos)))pos++;
  for(k=0;k<4;k++){while(pos<L&&!sp.test(plain.charAt(pos)))pos++;while(pos<L&&sp.test(plain.charAt(pos)))pos++}
  var out="",acc=0;
  sg.forEach(function(x){
    var len=x.t.length,from=Math.max(0,pos-acc);acc+=len;
    if(from>=len)return;
    var tx=x.t.slice(from);out+=x.c?"["+x.c+"["+tx+"]":tx;
  });
  return out;
}
function html(raw,tj){
  if(!tj)return esc(plainOf(raw));
  return segs(raw).map(function(x){return x.c&&RULES[x.c]?'<i class="tj tj-'+x.c+'">'+esc(x.t)+'</i>':esc(x.t)}).join("");
}

/* ----- بناء البيانات من الـAPI + التحقق ----- */
function fromApi(surahs){
  if(!surahs||surahs.length!==114)return null;
  var t=[],pg=[],jz=[],hq=[],so=[],Q=window.QMeta;
  surahs.forEach(function(s,si){
    so.push(t.length);
    s.ayahs.forEach(function(a,k){
      var raw=a.text||"";
      if(k===0&&si!==0&&si!==8)raw=stripBasmala(raw);
      var p=a.page;if(!p&&Q&&Q.ready())p=Q.pageOf((si+1)*1000+k+1);
      t.push(raw);pg.push(p||0);jz.push(a.juz||0);hq.push(a.hizbQuarter||0);
    });
  });
  var d={v:1,t:t,pg:pg,jz:jz,hq:hq,so:so};
  return valid(d)?d:null;
}
function valid(d){
  if(!d||!d.t||!d.pg||!d.so||d.t.length!==6236||d.pg.length!==6236||d.so.length!==114)return false;
  if(d.pg[0]!==1||d.pg[6235]!==604)return false;
  for(var i=0;i<6236;i++){if(!d.t[i]||!(d.pg[i]>=1&&d.pg[i]<=604)||(i&&d.pg[i]<d.pg[i-1]))return false}
  return true;
}
function index(){
  PR=[];SO=[];
  var i,s=0,n=D.t.length;
  for(i=0;i<n;i++){
    while(s+1<114&&D.so[s+1]<=i)s++;
    SO[i]=s;
    var p=D.pg[i];if(!PR[p])PR[p]={a:i,b:i+1};else PR[p].b=i+1;
  }
}

/* ----- تخزين على الجهاز ----- */
function idb(){return new Promise(function(res,rej){try{var r=indexedDB.open(IDB,1);r.onupgradeneeded=function(){r.result.createObjectStore(STORE)};r.onsuccess=function(){res(r.result)};r.onerror=function(){rej(r.error)}}catch(e){rej(e)}})}
function idbGet(k){return idb().then(function(db){return new Promise(function(res,rej){var q=db.transaction(STORE).objectStore(STORE).get(k);q.onsuccess=function(){res(q.result)};q.onerror=function(){rej(q.error)}})})}
function idbSet(k,v){return idb().then(function(db){return new Promise(function(res,rej){var tx=db.transaction(STORE,"readwrite");tx.objectStore(STORE).put(v,k);tx.oncomplete=function(){res()};tx.onerror=function(){rej(tx.error)}})})}

function ensure(){
  if(D||loading)return;
  loading=true;failed=false;draw();
  idbGet(DKEY).catch(function(){return null}).then(function(c){
    if(valid(c))return c;
    return fetch(API).then(function(r){if(!r.ok)throw 0;return r.json()}).then(function(j){
      var d=fromApi(j&&j.data&&j.data.surahs);if(!d)throw 0;
      idbSet(DKEY,d).catch(function(){});return d;
    });
  }).then(function(d){D=d;index();loading=false;draw()}).catch(function(){loading=false;failed=true;draw()});
}

/* ----- الرسم ----- */
var ayahOf=function(i){return i-D.so[SO[i]]+1};
function pageHtml(p){
  var r=PR[p];if(!r)return "";
  var a,h="",open=false,first=r.a,s0=SO[first],head;
  var close=function(){if(open){h+="</div>";open=false}};
  for(a=r.a;a<r.b;a++){
    var s=SO[a],n=ayahOf(a);
    if(n===1){
      close();
      h+='<div class="rd-ban">سورة '+esc(window.SURAH_NAMES[s]||"")+'</div>';
      if(s!==0&&s!==8)h+='<div class="rd-bsm">بِسْمِ ٱللَّهِ ٱلرَّحْمَـٰنِ ٱلرَّحِيمِ</div>';
    }
    if(!open){h+='<div class="rd-text">';open=true}
    if(D.hq[a]&&D.hq[a]!==D.hq[a-1]){h+=D.hq[a]%4===1?'<span class="rd-hz" title="بداية حزب">۞</span>':'<span class="rd-q" title="ربع"></span>'}
    h+='<span class="rd-a'+(a===sel?' sel':'')+'" data-i="'+a+'">'+(a===P.bm?'<span class="rd-bk">🔖</span>':'')+html(D.t[a],P.tj)+' <span class="rd-n">'+ar(n)+'</span></span> ';
  }
  close();
  var jz=D.jz[first];
  head='<div class="rd-hd"><span>سورة '+esc(window.SURAH_NAMES[s0]||"")+'</span><span>'+(jz?'الجزء '+ar(jz):'')+'</span></div>';
  return head+h+'<div class="rd-ft"><span>'+ar(p)+'</span></div>';
}
function legendHtml(){
  var dk=P.th==="dark";
  return '<div class="rd-leg">'+LEGEND_ORDER.map(function(k){var R=RULES[k];return '<div><i class="rd-sw" style="background:'+(dk?R[2]:R[1])+'"></i><b>'+R[0]+'</b><small>'+R[3]+'</small></div>'}).join("")+'</div>';
}
function firstWords(a){
  var w=[],i=a;
  while(w.length<2&&i<D.t.length&&i<a+3){w=w.concat(plainOf(D.t[i]).trim().split(/\s+/).filter(Boolean));i++}
  return w.slice(0,2).join(" ");
}
function rubs(s){
  var a0=D.so[s],a1=(s<113?D.so[s+1]:D.t.length)-1,out=[],a;
  for(a=a0;a<=a1;a++)if(D.hq[a]&&(a===0||D.hq[a]!==D.hq[a-1]))out.push(a);
  return out;
}
function surahBox(){
  var s=J.s,a0=D.so[s],a1=(s<113?D.so[s+1]:D.t.length)-1,n=a1-a0+1,p0=D.pg[a0],p1=D.pg[a1],rq=rubs(s),h,i;
  var mb=function(m,t){return '<button class="'+(J.m===m?'on':'')+'" onclick="Reader.jm(\''+m+'\')">'+t+'</button>'};
  h='<div class="rd-sb"><b>سورة '+esc(window.SURAH_NAMES[s])+'</b><small>'+ar(n)+' آية · '+ar(p1-p0+1)+' صفحة · '+(rq.length?ar(rq.length)+' ربع':'جزء من ربع واحد')+'</small>'+
    '<div class="rd-md">'+mb("start","من أولها")+mb("ayah","من آية")+mb("page","من صفحة")+(rq.length?mb("rub","من ربع"):"")+'</div>';
  if(J.m==="ayah")h+='<div class="rd-pg"><input id="rdAy" type="number" min="1" max="'+n+'" inputmode="numeric" placeholder="رقم الآية (1–'+n+')" onkeydown="if(event.key===\'Enter\')Reader.goAyah()"><button onclick="Reader.goAyah()">اذهب</button></div>';
  if(J.m==="page"){
    var o="";for(i=p0;i<=p1;i++)o+='<option value="'+i+'">صفحة '+ar(i)+'</option>';
    h+='<div class="rd-pg"><select id="rdSp">'+o+'</select><button onclick="Reader.goSp()">اذهب</button></div>';
  }
  if(J.m==="rub")h+='<div class="rd-rl">'+rq.map(function(a){
    return '<button onclick="Reader.goRub('+a+')"><b>ربع «'+esc(firstWords(a))+'»</b><small>الربع '+ar(D.hq[a])+' · الحزب '+ar(Math.ceil(D.hq[a]/4))+' · آية '+ar(ayahOf(a))+' · صفحة '+ar(D.pg[a])+'</small></button>';
  }).join("")+'</div>';
  return h+'</div>';
}
function jumpHtml(){
  var so='<option value="">اختار سورة…</option>',ju='<option value="">اختار جزء…</option>',i;
  for(i=0;i<114;i++)so+='<option value="'+i+'"'+(i===J.s?' selected':'')+'>'+(i+1)+' · '+window.SURAH_NAMES[i]+'</option>';
  for(i=1;i<=30;i++)ju+='<option value="'+i+'">الجزء '+i+'</option>';
  return '<div class="rd-jump"><select onchange="Reader.pickSurah(this.value)">'+so+'</select><select onchange="Reader.juz(this.value)">'+ju+'</select>'+(J.s>=0?surahBox():'')+'<div class="rd-pg"><input id="rdPn" type="number" min="1" max="604" inputmode="numeric" placeholder="أو رقم الصفحة (1–604)" onkeydown="if(event.key===\'Enter\')Reader.goInput()"><button onclick="Reader.goInput()">اذهب</button></div></div>';
}
function curPage(){return Math.min(604,Math.max(1,P.p))}
function draw(){
  var el=E("reader");if(!el)return;
  var dk=P.th==="dark",body;
  if(!D){
    body='<div class="rd-msg">'+(loading?'<div class="rd-spin">📖</div><b>بحمّل المصحف بالتشكيل والتجويد…</b><small>مرة واحدة بس (محتاج نت)، وبعدها بيشتغل من غير نت.</small>':
      failed?'<b>تعذّر تحميل المصحف.</b><small>اتأكد من الإنترنت وجرّب تاني.</small><button onclick="Reader.retry()">🔄 حاول تاني</button>':'')+'</div>';
  }else{
    var p=curPage();
    body=(jumpOpen?jumpHtml():'')+(legOpen?legendHtml():'')+'<div class="rd-page" id="rdPage">'+pageHtml(p)+'</div>'+
      '<div class="rd-sel" id="rdSel"'+(sel<0?' hidden':'')+'>'+selHtml()+'</div>'+
      '<div class="rd-nav"><button onclick="Reader.next()"'+(p>=604?' disabled':'')+'>◀ التالية</button><span>صفحة '+ar(p)+' / '+ar(604)+'</span><button onclick="Reader.prev()"'+(p<=1?' disabled':'')+'>السابقة ▶</button></div>';
  }
  el.innerHTML='<div class="rd'+(dk?' dark':'')+'" style="--rf:'+P.fs+'px">'+
    '<div class="rd-bar"><button onclick="show(\'home\')" title="رجوع">⬅️</button><button onclick="Mushaf.open()" title="الفهرس">📑</button><button class="'+(jumpOpen?'on':'')+'" onclick="Reader.toggle(\'j\')" title="انتقال">🔎</button>'+
    '<button onclick="Reader.size(-2)" title="تصغير">A−</button><button onclick="Reader.size(2)" title="تكبير">A+</button>'+
    '<button class="'+(P.tj?'on':'')+'" onclick="Reader.tajweed()" title="ألوان التجويد">🎨</button><button class="'+(legOpen?'on':'')+'" onclick="Reader.toggle(\'l\')" title="دليل الألوان">❓</button>'+
    '<button onclick="Reader.theme()" title="ورق / ليلي">'+(dk?'☀️':'🌙')+'</button>'+(P.bm>=0?'<button onclick="Reader.toBm()" title="علامتي">🔖</button>':'')+'</div>'+body+'</div>';
}
function selHtml(){
  if(sel<0||!D)return "";
  return '<b>سورة '+esc(window.SURAH_NAMES[SO[sel]])+' · آية '+ar(ayahOf(sel))+'</b><div><button onclick="Reader.mark()">'+(sel===P.bm?'🔖 شيل العلامة':'🔖 علّم هنا')+'</button><button onclick="Reader.copy()">📋 نسخ</button><button onclick="Reader.unsel()">✖</button></div>';
}

/* ----- تنقّل ----- */
function go(p,keepSel){
  P.p=Math.min(604,Math.max(1,Math.floor(+p)||1));if(!keepSel)sel=-1;savePrefs();draw();
  var pg=E("rdPage");if(pg){pg.classList.add("rd-flip")}
}
function openAt(p){if(p)P.p=p;jumpOpen=false;draw();show("reader");ensure();if(D)go(P.p)}
function pickAyah(a){
  sel=a;jumpOpen=false;J={s:-1,m:""};go(D.pg[a],true);
  setTimeout(function(){var el=document.querySelector&&document.querySelector(".rd-a.sel");if(el&&el.scrollIntoView)el.scrollIntoView({block:"center"})},40);
}
function visible(){return typeof cur_v!=="undefined"&&cur_v==="reader"}

var tx0=0,ty0=0;
document.addEventListener("click",function(e){
  if(!D||!visible())return;
  var a=e.target.closest&&e.target.closest(".rd-a");if(!a)return;
  sel=+a.getAttribute("data-i");draw();
});
document.addEventListener("touchstart",function(e){if(!visible()||!e.touches[0])return;tx0=e.touches[0].clientX;ty0=e.touches[0].clientY},{passive:true});
document.addEventListener("touchend",function(e){
  if(!D||!visible()||!e.changedTouches[0])return;
  var dx=e.changedTouches[0].clientX-tx0,dy=e.changedTouches[0].clientY-ty0;
  if(Math.abs(dx)>70&&Math.abs(dx)>Math.abs(dy)*1.6){if(dx>0)Reader.next();else Reader.prev()}
},{passive:true});
document.addEventListener("keydown",function(e){
  if(!D||!visible()||/INPUT|SELECT|TEXTAREA/.test((e.target||{}).tagName||""))return;
  if(e.key==="ArrowLeft")Reader.next();else if(e.key==="ArrowRight")Reader.prev();
});

window.Reader={
  open:function(){openAt(0)},
  openPage:function(p){openAt(Math.min(604,Math.max(1,Math.floor(+p)||1)))},
  retry:function(){ensure()},
  next:function(){if(curPage()<604)go(curPage()+1)},
  prev:function(){if(curPage()>1)go(curPage()-1)},
  size:function(d){P.fs=Math.min(48,Math.max(18,P.fs+d));savePrefs();draw()},
  tajweed:function(){P.tj=P.tj?0:1;savePrefs();draw()},
  theme:function(){P.th=P.th==="dark"?"paper":"dark";savePrefs();draw()},
  toggle:function(w){if(w==="j")jumpOpen=!jumpOpen;else legOpen=!legOpen;draw()},
  pickSurah:function(s){J={s:s===""?-1:+s,m:""};draw()},
  jm:function(m){
    if(J.s<0||!D)return;
    if(m==="start"){var a=D.so[J.s];jumpOpen=false;J={s:-1,m:""};go(D.pg[a]);return}
    J.m=(J.m===m?"":m);draw();
  },
  goAyah:function(){
    if(J.s<0||!D)return;
    var s=J.s,n=(s<113?D.so[s+1]:D.t.length)-D.so[s],v=Math.floor(Number(E("rdAy")&&E("rdAy").value));
    if(!(v>=1&&v<=n))return window.toast?toast("اكتب رقم آية من 1 لـ "+n):0;
    pickAyah(D.so[s]+v-1);
  },
  goSp:function(){var v=E("rdSp");if(!v||!D)return;jumpOpen=false;J={s:-1,m:""};go(+v.value)},
  goRub:function(a){if(D)pickAyah(+a)},
  juz:function(j){if(!D)return;var i=D.jz.indexOf(+j);jumpOpen=false;if(i>=0)go(D.pg[i]);else if(window.QMeta&&QMeta.ready())go(QMeta.pageOf(QMeta.juzStart(+j)))},
  goInput:function(){var v=E("rdPn");var n=Math.floor(Number(v&&v.value));if(!(n>=1&&n<=604))return window.toast?toast("اكتب رقم صفحة من 1 لـ 604"):0;jumpOpen=false;go(n)},
  mark:function(){P.bm=(sel===P.bm)?-1:sel;savePrefs();draw();if(window.okMsg)okMsg(P.bm>=0?"العلامة اتحفظت":"العلامة اتشالت")},
  toBm:function(){if(P.bm>=0&&D)go(D.pg[P.bm])},
  unsel:function(){sel=-1;draw()},
  copy:function(){
    if(sel<0||!D)return;
    var t=plainOf(D.t[sel])+" ﴿"+ar(ayahOf(sel))+"﴾ ["+window.SURAH_NAMES[SO[sel]]+"]";
    var ok=function(){if(window.okMsg)okMsg("اتنسخت")};
    if(navigator.clipboard&&navigator.clipboard.writeText)navigator.clipboard.writeText(t).then(ok,function(){prompt("انسخ الآية:",t)});else prompt("انسخ الآية:",t);
  },
  _t:{segs:segs,stripBasmala:stripBasmala,fromApi:fromApi,html:html,norm:norm,pageHtml:function(p){return pageHtml(p)},load:function(d){D=d;index();draw()}}
};

/* ----- ستايل ----- */
var vars=function(i){var s="";for(var k in RULES)s+="--c-"+k+":"+RULES[k][i]+";";return s};
var css=document.createElement("style");
css.textContent=
".rd{"+vars(1)+"--paper:#fbf3dc;--paper2:#f1e2b8;--ink:#1d1a14;--gold:#a97a1f;--gold2:#dcc06a;--rf:28px;max-width:660px;margin:0 auto;text-align:right}"+
".rd.dark{"+vars(2)+"--paper:#14232f;--paper2:#0d1922;--ink:#f1e8cf;--gold:#d9b55b;--gold2:#7d6428}"+
".rd-bar{display:flex;flex-wrap:wrap;gap:6px;justify-content:center;margin:4px 6px 10px}.rd-bar button{flex:none;width:auto;min-width:42px;padding:8px 10px;font-size:15px}.rd-bar button.on{outline:2px solid #2a9df4}"+
".rd-page{position:relative;background:radial-gradient(ellipse at 50% 0,var(--paper),var(--paper2));color:var(--ink);border-radius:14px;padding:16px 14px 12px;border:3px double var(--gold);box-shadow:0 0 0 5px var(--paper2),0 0 0 6px var(--gold2),0 10px 28px rgba(0,0,0,.3);margin:10px 8px 14px}"+
".rd-page:before,.rd-page:after{content:'❖';position:absolute;top:3px;color:var(--gold);font-size:14px;line-height:1}.rd-page:before{right:6px}.rd-page:after{left:6px}"+
".rd-flip{animation:rdIn .28s ease}@keyframes rdIn{from{opacity:.2;transform:translateX(-14px)}}"+
".rd-hd{display:flex;justify-content:space-between;font:700 15px/1.6 'Amiri Quran','Amiri',serif;color:var(--gold);border-bottom:1px solid var(--gold2);padding:2px 6px 6px;margin-bottom:6px}"+
".rd-ban{position:relative;margin:12px 0 6px;text-align:center;padding:6px 36px;border:2px solid var(--gold);border-radius:12px;background:linear-gradient(90deg,transparent,rgba(169,122,31,.2),transparent);font:700 calc(var(--rf)*.9)/1.7 'Amiri Quran','Amiri',serif;color:var(--ink)}"+
".rd-ban:before,.rd-ban:after{content:'۞';position:absolute;top:50%;transform:translateY(-50%);color:var(--gold);font-size:.85em}.rd-ban:before{right:12px}.rd-ban:after{left:12px}"+
".rd-bsm{text-align:center;font:400 var(--rf)/2.1 'Amiri Quran','Amiri',serif;margin:2px 0 4px}"+
".rd-text{direction:rtl;font:400 var(--rf)/2.3 'Amiri Quran','Amiri','Scheherazade New','Traditional Arabic',serif;text-align:justify;text-align-last:center}"+
".rd-a{cursor:pointer;-webkit-tap-highlight-color:transparent}.rd-a.sel{background:rgba(169,122,31,.25);border-radius:6px;-webkit-box-decoration-break:clone;box-decoration-break:clone}"+
".rd-n{display:inline-flex;align-items:center;justify-content:center;direction:ltr;min-width:1.7em;height:1.7em;padding:0 .15em;margin:0 .15em;border:1.5px solid var(--gold);border-radius:50%;font:700 .5em/1 'Amiri','Amiri Quran',serif;color:var(--gold);vertical-align:middle;box-shadow:inset 0 0 0 2px var(--paper)}"+
".rd-hz{color:var(--gold);font-size:1.15em;margin:0 .15em}.rd-q{display:inline-block;width:.42em;height:.42em;margin:0 .25em;background:var(--gold);transform:rotate(45deg);vertical-align:middle}.rd-bk{margin-inline-end:.15em;font-size:.7em}"+
".rd-ft{text-align:center;margin-top:8px}.rd-ft span{display:inline-block;min-width:2.2em;padding:2px 12px;border:1.5px solid var(--gold);border-radius:99px;font:700 15px/1.6 'Amiri',serif;color:var(--gold)}"+
".tj{font-style:normal}"+Object.keys(RULES).map(function(k){return ".tj-"+k+"{color:var(--c-"+k+")}"}).join("")+
".rd-nav{display:flex;align-items:center;justify-content:space-between;gap:8px;margin:0 8px 10px;position:sticky;bottom:8px}.rd-nav button{flex:none;width:auto;padding:10px 16px}.rd-nav button:disabled{opacity:.4}.rd-nav span{font-weight:700;font-size:14px;background:rgba(0,0,0,.35);color:#fff;padding:6px 12px;border-radius:99px}"+
".rd-sel{margin:0 8px 10px;padding:10px 12px;border-radius:12px;background:rgba(169,122,31,.18);border:1px solid var(--gold);display:flex;flex-wrap:wrap;gap:8px;align-items:center;justify-content:space-between;font-size:15px;color:inherit}.rd-sel[hidden]{display:none}.rd-sel button{flex:none;width:auto;padding:7px 12px;font-size:14px;margin-inline-start:6px}"+
".rd-jump{margin:0 8px 10px;display:grid;grid-template-columns:1fr 1fr;gap:8px}.rd-jump select,.rd-jump input{font:16px sans-serif;padding:10px}.rd-pg{grid-column:1/-1;display:flex;gap:8px}.rd-pg button{flex:none;width:auto;padding:10px 18px}"+
".rd-sb{grid-column:1/-1;padding:10px;border-radius:12px;background:rgba(31,134,214,.1);display:flex;flex-direction:column;gap:8px}.rd-sb>b{font-size:17px}.rd-sb small{opacity:.8}.rd-md{display:grid;grid-template-columns:1fr 1fr;gap:8px}.rd-md button{padding:10px 4px;font-size:15px}.rd-md button.on{outline:2px solid #2a9df4}.rd-rl{display:flex;flex-direction:column;gap:6px;max-height:48vh;overflow:auto}.rd-rl button{display:flex;flex-direction:column;align-items:flex-start;gap:2px;padding:9px 12px;text-align:right}.rd-rl button b{font:700 19px/1.6 'Amiri Quran','Amiri',serif}.rd-rl button small{font-size:12px;opacity:.8}"+
".rd-leg{margin:0 8px 10px;padding:10px;border-radius:12px;background:var(--paper);color:var(--ink);border:1px solid var(--gold2);display:grid;grid-template-columns:1fr 1fr;gap:8px 10px;font-size:13px}.rd-leg div{display:grid;grid-template-columns:16px 1fr;column-gap:6px;align-items:center}.rd-leg small{grid-column:2;opacity:.75;font-size:11px}.rd-sw{width:14px;height:14px;border-radius:50%;display:block}"+
".rd-msg{margin:30px 12px;text-align:center;display:flex;flex-direction:column;gap:10px;align-items:center}.rd-msg small{opacity:.8}.rd-spin{font-size:48px;animation:rdIn 1s ease infinite alternate}";
document.head.appendChild(css);
draw();
})();
