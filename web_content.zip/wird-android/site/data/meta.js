/* بيانات مساعدة للمصحف: أسماء السور + حدود الصفحات/الأجزاء/الأرباع.
   الحدود بتتحمّل مرة واحدة من alquran.cloud (أو بتتاخد من استيراد المصحف) وبتتخزّن على الجهاز.
   كل حدّ = رقم السورة*1000 + رقم الآية فيها، فمفيش أي عدد آيات ثابت متكتب هنا. */
window.SURAH_NAMES=["الفاتحة","البقرة","آل عمران","النساء","المائدة","الأنعام","الأعراف","الأنفال","التوبة","يونس","هود","يوسف","الرعد","إبراهيم","الحجر","النحل","الإسراء","الكهف","مريم","طه","الأنبياء","الحج","المؤمنون","النور","الفرقان","الشعراء","النمل","القصص","العنكبوت","الروم","لقمان","السجدة","الأحزاب","سبأ","فاطر","يس","الصافات","ص","الزمر","غافر","فصلت","الشورى","الزخرف","الدخان","الجاثية","الأحقاف","محمد","الفتح","الحجرات","ق","الذاريات","الطور","النجم","القمر","الرحمن","الواقعة","الحديد","المجادلة","الحشر","الممتحنة","الصف","الجمعة","المنافقون","التغابن","الطلاق","التحريم","الملك","القلم","الحاقة","المعارج","نوح","الجن","المزمل","المدثر","القيامة","الإنسان","المرسلات","النبأ","النازعات","عبس","التكوير","الانفطار","المطففين","الانشقاق","البروج","الطارق","الأعلى","الغاشية","الفجر","البلد","الشمس","الليل","الضحى","الشرح","التين","العلق","القدر","البينة","الزلزلة","العاديات","القارعة","التكاثر","العصر","الهمزة","الفيل","قريش","الماعون","الكوثر","الكافرون","النصر","المسد","الإخلاص","الفلق","الناس"];
(function(){
  var KEY="q_meta2",M=null,pending=null,K=function(s,a){return s*1000+a};
  function valid(m){
    if(!m||!m.p||!m.j||!m.h||m.p.length!==604||m.j.length!==30||m.h.length!==240)return false;
    for(var i=0;i<604;i++)if(!m.p[i])return false;
    for(i=0;i<30;i++)if(!m.j[i])return false;
    for(i=0;i<240;i++)if(!m.h[i])return false;
    return true;
  }
  function fromApi(surahs){
    var p=[],j=[],h=[],c=[],t=[];
    surahs.forEach(function(s){c[s.number-1]=s.ayahs.length;t[s.number-1]=s.revelationType==="Medinan"?2:1;s.ayahs.forEach(function(a){
      var k=K(s.number,a.numberInSurah);
      if(!p[a.page-1])p[a.page-1]=k;
      if(!j[a.juz-1])j[a.juz-1]=k;
      if(!h[a.hizbQuarter-1])h[a.hizbQuarter-1]=k;
    })});
    return {p:p,j:j,h:h,c:c,t:t};
  }
  function full(){return ready()&&M.c&&M.t&&M.c.length===114&&M.t.length===114&&M.c[113]>0}
  function store(m){M=m;try{localStorage.setItem(KEY,JSON.stringify(m))}catch(e){}}
  function ready(){
    if(M)return true;
    try{var m=JSON.parse(localStorage.getItem(KEY));if(valid(m)){M=m;return true}}catch(e){}
    return false;
  }
  /* بيحمّل الحدود لو مش متخزّنة. بيرجّع Promise<boolean> */
  function load(){
    if(full())return Promise.resolve(true);
    if(pending)return pending;
    pending=fetch("https://api.alquran.cloud/v1/quran/quran-uthmani").then(function(r){if(!r.ok)throw 0;return r.json()}).then(function(j){
      var m=fromApi(j.data.surahs);if(!valid(m))throw 0;store(m);return true;
    }).catch(function(){return false}).then(function(ok){pending=null;return ok});
    return pending;
  }
  /* نطاق [من،إلى] بالمفاتيح (inclusive) حسب نوع الاختيار. type: juz|hizb|rub|page|surah */
  function range(type,from,to){
    if(type==="surah")return [K(from,1),K(to,999)];
    if(!ready())return null;
    var a,n,arr,last;
    if(type==="juz"){arr=M.j;last=30;a=from;n=to}
    else if(type==="hizb"){arr=M.h;last=240;a=(from-1)*4+1;n=to*4}
    else if(type==="rub"){arr=M.h;last=240;a=from;n=to}
    else{arr=M.p;last=604;a=from;n=to}
    return [arr[a-1],n<last?arr[n]-1:K(114,999)];
  }
  function locate(arr,k){var r=0;for(var i=0;i<arr.length;i++){if(arr[i]<=k)r=i+1;else break}return r}
  window.QMeta={
    ready:ready,full:full,load:load,rubStart:function(r){return ready()&&M.h[r-1]||0},juzStart:function(j){return ready()&&M.j[j-1]||0},ayahCount:function(n){return full()?M.c[n-1]:0},isMadani:function(n){return full()&&M.t[n-1]===2},range:range,
    pageOf:function(k){return ready()?locate(M.p,k):0},
    juzOf:function(k){return ready()?locate(M.j,k):0},
    rubOf:function(k){return ready()?locate(M.h,k):0},
    pageStart:function(pg){return ready()&&M.p[pg-1]||0},
    surahOfKey:function(k){return Math.floor(k/1000)},
    name:function(n){return window.SURAH_NAMES[n-1]||""}
  };
  window.QMetaFromApi=function(surahs){var m=fromApi(surahs);if(valid(m))store(m)};
})();
