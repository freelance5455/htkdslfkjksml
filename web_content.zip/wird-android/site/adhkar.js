/* ===== أذكار الصباح والمساء ===== */
(function(){
"use strict";
var E=function(i){return document.getElementById(i)};
var G=function(m,f){try{return g(m,f)}catch(e){return m}};
var pad=function(n){return String(n).padStart(2,"0")};
var dk=function(d){return d.getFullYear()+"-"+pad(d.getMonth()+1)+"-"+pad(d.getDate())};
var BS="بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ ";
// w: b=الاتنين، m=صباح بس، e=مساء بس | t=صباح / t2=مساء لو النص مختلف
var ITEMS=[
{id:"ks",n:1,h:"آية الكرسي 📖",t:"أَعُوذُ بِاللَّهِ مِنَ الشَّيْطَانِ الرَّجِيمِ\nاللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ ۚ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ ۚ لَّهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ ۗ مَن ذَا الَّذِي يَشْفَعُ عِندَهُ إِلَّا بِإِذْنِهِ ۚ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ ۖ وَلَا يُحِيطُونَ بِشَيْءٍ مِّنْ عِلْمِهِ إِلَّا بِمَا شَاءَ ۚ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ ۖ وَلَا يَئُودُهُ حِفْظُهُمَا ۚ وَهُوَ الْعَلِيُّ الْعَظِيمُ"},
{id:"ik",n:3,h:"سورة الإخلاص",t:BS+"\nقُلْ هُوَ اللَّهُ أَحَدٌ ۝ اللَّهُ الصَّمَدُ ۝ لَمْ يَلِدْ وَلَمْ يُولَدْ ۝ وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ"},
{id:"fl",n:3,h:"سورة الفلق",t:BS+"\nقُلْ أَعُوذُ بِرَبِّ الْفَلَقِ ۝ مِن شَرِّ مَا خَلَقَ ۝ وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ ۝ وَمِن شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ ۝ وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ"},
{id:"ns",n:3,h:"سورة الناس",t:BS+"\nقُلْ أَعُوذُ بِرَبِّ النَّاسِ ۝ مَلِكِ النَّاسِ ۝ إِلَٰهِ النَّاسِ ۝ مِن شَرِّ الْوَسْوَاسِ الْخَنَّاسِ ۝ الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ ۝ مِنَ الْجِنَّةِ وَالنَّاسِ"},
{id:"rd",n:3,h:"أذكار متنوعة",t:"رَضِيتُ بِاللَّهِ رَبًّا، وَبِالْإِسْلَامِ دِينًا، وَبِمُحَمَّدٍ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ نَبِيًّا"},
{id:"hs",n:7,h:"أذكار متنوعة",t:"حَسْبِيَ اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ، عَلَيْهِ تَوَكَّلْتُ وَهُوَ رَبُّ الْعَرْشِ الْعَظِيمِ"},
{id:"bd",n:3,h:"أذكار متنوعة",t:"بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ"},
{id:"af",n:3,h:"أذكار متنوعة",t:"اللَّهُمَّ عَافِنِي فِي بَدَنِي، اللَّهُمَّ عَافِنِي فِي سَمْعِي، اللَّهُمَّ عَافِنِي فِي بَصَرِي"},
{id:"sy",n:1,h:"سيد الاستغفار 🤍",t:"اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَٰهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَىٰ عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوءُ بِذَنْبِي فَاغْفِرْ لِي، فَإِنَّهُ لَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ"},
{id:"mlk",n:1,h:"دعاء الصباح ☀️",h2:"دعاء المساء 🌙",
 t:"أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَٰهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَىٰ كُلِّ شَيْءٍ قَدِيرٌ. اللَّهُمَّ إِنِّي أَسْأَلُكَ خَيْرَ هَٰذَا الْيَوْمِ وَخَيْرَ مَا بَعْدَهُ، وَأَعُوذُ بِكَ مِنْ شَرِّ هَٰذَا الْيَوْمِ وَشَرِّ مَا بَعْدَهُ. اللَّهُمَّ أَعُوذُ بِكَ مِنَ الْكَسَلِ وَسُوءِ الْكِبَرِ، وَأَعُوذُ بِكَ مِنْ عَذَابِ النَّارِ وَعَذَابِ الْقَبْرِ",
 t2:"أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَٰهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَىٰ كُلِّ شَيْءٍ قَدِيرٌ. اللَّهُمَّ إِنِّي أَسْأَلُكَ خَيْرَ هَٰذِهِ اللَّيْلَةِ وَخَيْرَ مَا بَعْدَهَا، وَأَعُوذُ بِكَ مِنْ شَرِّ هَٰذِهِ اللَّيْلَةِ وَشَرِّ مَا بَعْدَهَا. اللَّهُمَّ أَعُوذُ بِكَ مِنَ الْكَسَلِ وَسُوءِ الْكِبَرِ، وَأَعُوذُ بِكَ مِنْ عَذَابِ النَّارِ وَعَذَابِ الْقَبْرِ"},
{id:"il",n:1,w:"m",h:"دعوات جامعة",t:"اللَّهُمَّ إِنِّي أَسْأَلُكَ عِلْمًا نَافِعًا، وَرِزْقًا طَيِّبًا، وَعَمَلًا مُتَقَبَّلًا"},
{id:"ea",n:1,h:"دعوات جامعة",t:"اللَّهُمَّ إِنِّي أَسْأَلُكَ الْعَفْوَ وَالْعَافِيَةَ فِي الدُّنْيَا وَالْآخِرَةِ"},
{id:"st",n:1,h:"دعوات جامعة",t:"اللَّهُمَّ اسْتُرْ عَوْرَاتِي وَآمِنْ رَوْعَاتِي، وَاحْفَظْنِي مِنْ بَيْنِ يَدَيَّ وَمِنْ خَلْفِي، وَعَنْ يَمِينِي وَعَنْ شِمَالِي، وَمِنْ فَوْقِي"},
{id:"sb",n:100,h:"أذكار ختامية",t:"سُبْحَانَ اللَّهِ وَبِحَمْدِهِ"},
{id:"is",n:100,h:"أذكار ختامية",t:"أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ"},
{id:"sl",n:10,h:"أذكار ختامية",t:"اللَّهُمَّ صَلِّ وَسَلِّمْ وَبَارِكْ عَلَىٰ نَبِيِّنَا مُحَمَّدٍ"},
{id:"ek",n:3,h:"أذكار ختامية",t:"أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ"}
];
var T=new Date().getHours()<15?"m":"e", S=null, loaded="";
function key(){return "q_adhkar_"+(typeof uid!=="undefined"&&uid?uid:"")}
function blank(){return {fs:22,days:{},p:{d:dk(new Date()),m:{},e:{}}}}
function load(){
  var k=key();if(S&&loaded===k)return;loaded=k;
  try{S=Object.assign(blank(),JSON.parse(localStorage.getItem(k))||{})}catch(e){S=blank()}
  if(!S.days)S.days={};if(!S.p)S.p={d:"",m:{},e:{}};
}
function saveLocal(){try{localStorage.setItem(key(),JSON.stringify(S))}catch(e){}}
function push(){if(typeof db!=="undefined"&&db&&typeof uid!=="undefined"&&uid)db.collection("users").doc(uid).set({adhkar:S},{merge:true}).catch(function(){})}
function save(){S.u=Date.now();saveLocal();push()}   // بيتخزّن على الجهاز وعلى الحساب (Firebase)
function today(){load();var d=dk(new Date());if(S.p.d!==d){S.p={d:d,m:{},e:{}};saveLocal()}}
function list(t){return ITEMS.filter(function(x){return !x.w||x.w===t})}
function txt(x,t){return t==="e"&&x.t2?x.t2:x.t}
function cnt(t){var c=S.p[t]||{},l=list(t),d=0;l.forEach(function(x){if((c[x.id]||0)>=x.n)d++});return {d:d,n:l.length}}
function streak(){
  var n=0,c=new Date();if(!S.days[dk(c)])c.setDate(c.getDate()-1);
  while(S.days[dk(c)]){n++;c.setDate(c.getDate()-1)}return n}
function esc(s){return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}
function css(){
  if(E("adhkarCss"))return;var s=document.createElement("style");s.id="adhkarCss";
  s.textContent=".ad-tabs{display:flex;gap:8px;margin:6px 0 12px}.ad-tabs button{flex:1}.ad-tabs button.on{outline:2px solid var(--gold);font-weight:800}"+
  ".ad-bar{height:10px;border-radius:9px;background:rgba(127,127,127,.25);overflow:hidden;margin:6px 0}.ad-bar i{display:block;height:100%;width:0;background:var(--ok,#5fbf8f);transition:width .35s}"+
  ".ad-tools{display:flex;gap:8px;justify-content:center;flex-wrap:wrap;margin:8px 0}.ad-tools button{padding:6px 14px}"+
  ".ad-card{position:relative;text-align:center;padding:16px 14px;margin:10px 0;border-radius:18px;background:var(--card);border:1px solid rgba(127,127,127,.3);cursor:pointer;user-select:none;-webkit-user-select:none;-webkit-tap-highlight-color:transparent;transition:transform .12s,opacity .3s}"+
  ".ad-card:active{transform:scale(.98)}.ad-card.done{opacity:.55;border-color:var(--ok,#5fbf8f)}.ad-card.cur{border-color:var(--gold);box-shadow:0 0 0 2px var(--gold)}"+
  ".ad-h{font-size:13px;color:var(--mute);margin-bottom:6px}.ad-t{line-height:2.1;color:var(--ink);font-family:inherit}"+
  ".ad-c{display:inline-block;min-width:78px;margin-top:10px;padding:6px 14px;border-radius:999px;font-weight:800;font-size:18px;background:rgba(127,127,127,.2);color:var(--ink)}.ad-card.done .ad-c{background:var(--ok,#5fbf8f);color:#fff}"+
  ".ad-pill{display:block;font-size:13px;margin-top:4px}";
  document.head.appendChild(s)}
function render(){
  var sec=E("adhkar");if(!sec)return;css();today();
  var c=cnt(T),pc=c.n?Math.round(c.d*100/c.n):0,l=list(T),cc=S.p[T]||{},first=-1,i;
  for(i=0;i<l.length;i++)if((cc[l[i].id]||0)<l[i].n){first=i;break}
  var fs=S.fs,h='<div class="panel"><h2>📿 أذكار '+(T==="m"?"الصباح ☀️":"المساء 🌙")+'</h2>'+
   '<div class="ad-tabs"><button class="alt'+(T==="m"?" on":"")+'" onclick="Adhkar.tab(\'m\')">☀️ الصباح</button><button class="alt'+(T==="e"?" on":"")+'" onclick="Adhkar.tab(\'e\')">🌙 المساء</button></div>'+
   '<div class="mute">'+c.d+' / '+c.n+' · '+pc+'%'+(streak()?' · 🔥 '+streak()+' '+(streak()===1?'يوم':'أيام')+' متتالية':'')+'</div><div class="ad-bar"><i style="width:'+pc+'%"></i></div>'+
   '<div class="ad-tools"><button class="alt" onclick="Adhkar.fs(-2)">A−</button><button class="alt" onclick="Adhkar.fs(2)">A+</button><button class="alt" onclick="Adhkar.reset()">🔄 من الأول</button></div>'+
   '<div class="mute">دوس على الذكر أو Enter عشان تعدّ 👆</div>';
  l.forEach(function(x,k){var v=Math.min(cc[x.id]||0,x.n),dn=v>=x.n;
    h+='<div class="ad-card'+(dn?" done":"")+(k===first?" cur":"")+'" id="adc'+k+'" onclick="Adhkar.t('+k+')">'+(x.h?'<div class="ad-h">'+(T==="e"&&x.h2?x.h2:x.h)+'</div>':'')+
     '<div class="ad-t" style="font-size:clamp(15px,6vw,'+fs+'px)">'+esc(txt(x,T)).replace(/\n/g,'<br>')+'</div><span class="ad-c">'+(dn?'✅ ':'')+v+' / '+x.n+'</span></div>'});
  h+='<div class="row"><button class="alt" onclick="back()">⬅️ رجوع</button></div></div>';
  sec.innerHTML=h;home()}
function home(){
  var b=E("adhkarHome");if(!b)return;load();today();var m=cnt("m"),e=cnt("e"),s=streak();
  var f=function(c){return c.d>=c.n?"✅ خلصت النهاردة":c.d+" / "+c.n};
  b.innerHTML='<h2>📿 الأذكار</h2><div class="gm-menu"><button class="gm-card alt" onclick="Adhkar.open(\'m\')"><span>☀️</span>أذكار الصباح<small>'+f(m)+'</small></button><button class="gm-card alt" onclick="Adhkar.open(\'e\')"><span>🌙</span>أذكار المساء<small>'+f(e)+'</small></button></div>'+(s?'<div class="mute" style="margin-top:8px">🔥 '+s+' '+(s===1?'يوم':'أيام')+' متتالية</div>':'')}
function tap(k){
  today();var l=list(T),x=l[k];if(!x)return;var c=S.p[T]||(S.p[T]={}),v=c[x.id]||0;if(v>=x.n)return;
  c[x.id]=v+1;try{navigator.vibrate&&navigator.vibrate(12)}catch(e){}
  var all=cnt(T).d>=l.length,was=(S.days[S.p.d]||{})[T];
  if(all&&!was){S.days[S.p.d]=Object.assign(S.days[S.p.d]||{},{[T]:1})}
  save();render();
  if(c[x.id]>=x.n&&!all){var nx=E("adc"+firstIdx());if(nx&&nx.scrollIntoView)nx.scrollIntoView({behavior:"smooth",block:"center"})}
  if(all&&!was&&window.fxWin)fxWin(G("ما شاء الله"+nmx()+" ✨ خلّصت أذكار ","ما شاء الله"+nmx()+" ✨ خلّصتي أذكار ")+(T==="m"?"الصباح ☀️":"المساء 🌙")+" 🤍")}
function firstIdx(){var l=list(T),c=S.p[T]||{};for(var i=0;i<l.length;i++)if((c[l[i].id]||0)<l[i].n)return i;return -1}
window.Adhkar={
  open:function(t){if(t)T=t;render();show("adhkar")},
  tab:function(t){T=t;render()},
  t:tap,
  tap:function(){var i=firstIdx();if(i>-1)tap(i)},
  fs:function(d){load();S.fs=Math.max(16,Math.min(40,S.fs+d));save();render()},
  reset:function(){if(!confirm(G("تبدأ أذكار ","تبدأي أذكار ")+(T==="m"?"الصباح":"المساء")+" من الأول؟"))return;load();S.p[T]={};if(S.days[S.p.d])delete S.days[S.p.d][T];save();render()},
  done:function(t){load();today();var c=cnt(t);return c.d>=c.n},
  home:home
};
/* بيتنده بعد قراءة بيانات الحساب من Firebase: التقدم الأحدث بيكسب، وأيام السلسلة بتتجمع من كل الأجهزة */
window.adhkarRemote=function(r){
  if(!r||typeof r!=="object")return;load();
  var d=Object.assign({},r.days||{}),chg=false;
  Object.keys(S.days).forEach(function(k){var a=d[k]||{},b=S.days[k],m=Object.assign({},a,b);if(JSON.stringify(m)!==JSON.stringify(a)){d[k]=m;chg=true}});
  var newer=(r.u||0)>(S.u||0);
  if(newer){S.p=r.p||S.p;S.fs=r.fs||S.fs;S.u=r.u}
  S.days=d;saveLocal();today();
  if(!newer&&((S.u||0)>(r.u||0)||chg))push();
  home();if(cur_v==="adhkar")render()};
/* بيتنده لما المستخدم يتغيّر (دخول/خروج) */
var prevSwitch=window.onUserSwitch;
window.onUserSwitch=function(){if(prevSwitch)try{prevSwitch()}catch(e){}S=null;load();home();if(cur_v==="adhkar")render()};
var os=window.show;window.show=function(id){os(id);if(id==="home")home()};
home();
document.addEventListener("visibilitychange",function(){if(!document.hidden){home();if(cur_v==="adhkar")render()}});
})();
