/* ===== الإشعارات: أذكار الصباح والمساء + الورد + "اذكر ربنا" كل فترة ===== */
(function(){
"use strict";
var E=function(i){return document.getElementById(i)};
var G=function(m,f){try{return g(m,f)}catch(e){return m}};
var pad=function(n){return String(n).padStart(2,"0")};
var dk=function(d){return d.getFullYear()+"-"+pad(d.getMonth()+1)+"-"+pad(d.getDate())};
var tm=function(s){var a=String(s||"0:0").split(":");return (+a[0]||0)*60+(+a[1]||0)};
var CATCH=240;   // لو التطبيق اتفتح متأخر لحد 4 ساعات عن الميعاد لسه بيفكّرك، بعد كده بيعدّيها
var DHIKR=["سُبْحَانَ اللَّهِ وَبِحَمْدِهِ، سُبْحَانَ اللَّهِ الْعَظِيمِ","لَا إِلَٰهَ إِلَّا اللَّهُ","أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ","اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَىٰ نَبِيِّنَا مُحَمَّدٍ","لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ","الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ"];
var EMO=["🤍","🌿","📿","✨","🌙","☀️"];
var ON0={m:1,e:1,w:1,d:1,pb:1,pm:1};
var N=null,loaded="";
function blank(){return {u:0,on:Object.assign({},ON0),pr:30,tm:"06:00",te:"17:00",tw:"21:00",iv:10,qs:"23:00",qe:"05:00",rc:1,rg:30}}
function key(){return "q_notif_cfg"}   // إعدادات واحدة لكل المستخدمين، المطوّر بس هو اللي بيغيّرها
function isDev(){try{var AD=(window.APP_CONFIG&&APP_CONFIG.adminEmails)||[];return AD.length?(typeof isAdminEmail==="function"&&isAdminEmail()):true}catch(e){return false}}
var lastPull=0;
function pull(force){
  if(typeof db==="undefined"||!db||typeof uid==="undefined"||!uid)return;
  if(!force&&Date.now()-lastPull<300000)return;lastPull=Date.now();
  db.collection("content").doc("notif_cfg").get().then(function(sn){
    if(!sn.exists)return;var r=sn.data()||{};load();
    if((r.u||0)>(N.u||0)){N=Object.assign(blank(),r.cfg||{},{u:r.u});N.on=Object.assign({},ON0,N.on||{});fixIv();saveLocal();if(cur_v==="notif")render();sync()}
  }).catch(function(){})}
/* تكرار "اذكر ربنا" لازم يبقى 5/10/15/30 (الـ cron بيشتغل كل 5 دقايق) */
function fixIv(){var v=+N.iv||10,a=[5,10,15,30];N.iv=a.reduce(function(p,c){return Math.abs(c-v)<Math.abs(p-v)?c:p})}
function load(){var k=key();if(N&&loaded===k)return;loaded=k;
  try{N=Object.assign(blank(),JSON.parse(localStorage.getItem(k))||{})}catch(e){N=blank()}
  N.on=Object.assign({},ON0,N.on||{});fixIv()}
function saveLocal(){try{localStorage.setItem(key(),JSON.stringify(N))}catch(e){}}
function save(){if(!isDev())return;N.u=Date.now();saveLocal();
  var c={on:N.on,tm:N.tm,te:N.te,tw:N.tw,iv:N.iv,qs:N.qs,qe:N.qe,rc:N.rc,rg:N.rg,pr:N.pr||30};
  if(typeof db!=="undefined"&&db)db.collection("content").doc("notif_cfg").set({cfg:c,u:N.u}).then(function(){if(typeof toast==="function")toast("اتحفظ ✓ وهيتطبق على كل المستخدمين")}).catch(function(e){if(typeof toast==="function")toast("مقدرتش أحفظ للمستخدمين: "+((e&&(e.code||e.message))||""))})}
function last(){try{return JSON.parse(localStorage.getItem("q_notif_last"))||{}}catch(e){return {}}}
function setLast(L){try{localStorage.setItem("q_notif_last",JSON.stringify(L))}catch(e){}}
function perm(){return typeof Notification==="undefined"?"unsupported":Notification.permission}
function nm(){return (typeof prof!=="undefined"&&prof.name)?" يا "+prof.name:""}
function quiet(m){var s=tm(N.qs),e=tm(N.qe);if(s===e)return false;return s>e?(m>=s||m<e):(m>=s&&m<e)}
function fire(title,body,tag,go){
  if(window.NativeApp)return NativeApp.fire(title,body,tag,go);   // على أندرويد: الإشعارات الأصلية هي اللي بتتولى الأمر
  var o={body:body,icon:"icon-192.png",badge:"badge-96.png",tag:tag,renotify:true,lang:"ar",dir:"rtl",vibrate:[120,60,120],data:{go:go||"home"}};
  var fb=function(){try{new Notification(title,o)}catch(e){}};
  if(navigator.serviceWorker&&navigator.serviceWorker.ready)navigator.serviceWorker.ready.then(function(r){return r.showNotification(title,o)}).catch(fb);else fb()}
function msgDhikr(){var i=Math.floor(Math.random()*DHIKR.length);
  return {t:G("اذكر ربنا","اذكري ربنا")+nm()+" "+EMO[Math.floor(Math.random()*EMO.length)],b:DHIKR[i]}}
var MSG={
  m:function(){return {t:G("صباح الخير","صباح الخير")+nm()+" ☀️",b:G("وقت أذكار الصباح 📿 دوس وابدأ يومك بذكر الله","وقت أذكار الصباح 📿 دوسي وابدأي يومك بذكر الله")}},
  e:function(){return {t:G("مساء الخير","مساء الخير")+nm()+" 🌙",b:G("وقت أذكار المساء 📿 دوس واختم يومك بذكر الله","وقت أذكار المساء 📿 دوسي واختمي يومك بذكر الله")}},
  w:function(){return {t:G("وردك النهاردة","وردك النهاردة")+nm()+" 📖",b:G("لسه ما سجلتش ورد النهاردة، ولو صفحة واحدة 🤍","لسه ما سجلتيش ورد النهاردة، ولو صفحة واحدة 🤍")}}
};
var GO={m:"m",e:"e",w:"home",d:"dhikr"};
function done(x){
  try{if(x==="m"||x==="e")return window.Adhkar&&Adhkar.done(x);
    if(x==="w"&&window.Wird){var s=Wird._state(),k=dk(new Date());return ((s.days||{})[k]>0)||((s.r&&s.r.days||{})[k]>0)}}catch(e){}
  return false}
/* ===== إشعارات السيرفر (Web Push): بتوصل حتى والتطبيق مقفول ===== */
var PU=function(){return !!(window.PUSH_URL&&window.VAPID_PUB&&"PushManager" in window&&navigator.serviceWorker)};
var pushOk=function(){try{return localStorage.getItem("q_push_ok")==="1"}catch(e){return false}};
var setOk=function(v){try{localStorage.setItem("q_push_ok",v?"1":"0")}catch(e){}};
function u8(s){s=s.replace(/-/g,"+").replace(/_/g,"/");s+="=".repeat((4-s.length%4)%4);return Uint8Array.from(atob(s),function(c){return c.charCodeAt(0)})}
var lastSent="",syncing=false,lastTry=0,lastErr="";
function escT(s){return String(s||"").replace(/[&<>"]/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]})}
function sync(force){
  if(!PU()||perm()!=="granted"||syncing)return;
  if(!force&&!pushOk()&&Date.now()-lastTry<300000)return;   // لو السيرفر مش متربط منحاولش كل ثواني، كل 5 دقايق
  lastTry=Date.now();syncing=true;
  navigator.serviceWorker.ready.then(function(r){return r.pushManager.getSubscription().then(function(s){return s||r.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:u8(window.VAPID_PUB)})})})
  .then(function(s){load();
    var u=(typeof uid!=="undefined"&&uid)||null,n=(typeof prof!=="undefined"&&prof)||{};
    if(u&&n.gender!=="m"&&n.gender!=="f"){setOk(false);lastTry=0;lastErr="لسه ما اخترتش النوع (ذكر/أنثى)";return}   // النوع إجباري عشان الصيغة تطلع صح
    var pi=(window.Prayer&&Prayer.info)?Prayer.info():null;if(pi){delete pi.lat;delete pi.lon}   // مواعيد الصلاة بس، من غير إحداثيات
    var b={sub:s.toJSON(),uid:u,name:n.name||"",g:n.gender,tz:(Intl.DateTimeFormat().resolvedOptions().timeZone||"Africa/Cairo"),
           pr:pi,cfg:{on:N.on,tm:N.tm,te:N.te,tw:N.tw,iv:N.iv,qs:N.qs,qe:N.qe,rc:N.rc||1,rg:N.rg||30,pr:N.pr||30},done:{d:dk(new Date()),m:done("m")?1:0,e:done("e")?1:0,w:done("w")?1:0}},
        j=JSON.stringify(b);
    if(!force&&j===lastSent)return;
    return fetch(window.PUSH_URL+"/subscribe",{method:"POST",headers:{"Content-Type":"application/json"},body:j}).then(function(x){
      if(x.ok){lastSent=j;setOk(!!u);lastErr=u?"":"مفيش حساب مسجّل دخول"}
      else{setOk(false);return x.json().catch(function(){return {}}).then(function(d){lastErr="رد السيرفر: "+x.status+((d&&(d.detail||d.error))?" - "+(d.detail||d.error):"")})}})})
  .catch(function(e){setOk(false);lastErr=((e&&e.name)||"خطأ")+": "+((e&&e.message)||"")+(e&&e.name==="TypeError"?" (السيرفر مبيردش أو CORS)":"")}).then(function(){syncing=false;if(cur_v==="notif")render();home()})}

/* ===== رسائل جاهزة للبث + إشعارات الصلاة ===== */
var M2=function(a,b){return {m:a,f:b}};
function BC(x,pid){
  if(x==="m")return {t:M2("صباح الخير","صباح الخير"),s:" ☀️",n:1,b:M2("وقت أذكار الصباح 📿 دوس وابدأ يومك بذكر الله","وقت أذكار الصباح 📿 دوسي وابدأي يومك بذكر الله"),tag:"wird-m",go:"m"};
  if(x==="e")return {t:M2("مساء الخير","مساء الخير"),s:" 🌙",n:1,b:M2("وقت أذكار المساء 📿 دوس واختم يومك بذكر الله","وقت أذكار المساء 📿 دوسي واختمي يومك بذكر الله"),tag:"wird-e",go:"e"};
  if(x==="w")return {t:M2("وردك النهاردة","وردك النهاردة"),s:" 📖",n:1,b:M2("لسه ما سجلتش ورد النهاردة، ولو صفحة واحدة 🤍","لسه ما سجلتيش ورد النهاردة، ولو صفحة واحدة 🤍"),tag:"wird-w",go:"home"};
  if(x==="d"){var z=DHIKR[Math.floor(Math.random()*DHIKR.length)];return {t:M2("اذكر ربنا","اذكري ربنا"),s:" "+EMO[Math.floor(Math.random()*EMO.length)],n:1,b:M2(z,z),tag:"wird-d",go:"dhikr"}}
  var P=window.Prayer,q=pid?{id:pid,n:P.name(pid)}:(x==="pm"?P.last():P.next());
  if(x==="pb")return {t:M2("صلاة "+q.n+" بعد 5 دقايق 🕌","صلاة "+q.n+" بعد 5 دقايق 🕌"),s:"",n:0,b:M2("جهّز نفسك واتوضّى","جهّزي نفسك واتوضّي"),tag:"wird-pb-"+q.id,go:"pray"};
  return {t:M2("قوم صلي "+q.n+"","قومي صلي "+q.n+""),s:" 🕌",n:1,b:M2("وقتها جه ولسه ما علّمتش إنك صليتها","وقتها جه ولسه ما علّمتيش إنك صليتيها"),tag:"wird-pm-"+q.id,go:"pray"}}
function mk(o,f,name){var k=f?"f":"m",nn=name?" يا "+name:"";return {t:o.t[k]+(o.n?nn:"")+(o.s||""),b:o.b[k]+(o.n?"":nn)}}
function me(){return {f:(typeof prof!=="undefined"&&prof.gender==="f"),name:(typeof prof!=="undefined"&&prof.name)||""}}
function run(L,key,dayk,starts,now,end,isDone,send){
  var st=L[key];if(!st||typeof st!=="object"||st.k!==dayk)st={k:dayk,n:0};
  if(st.n>=starts.length)return false;
  if(isDone){L[key]={k:dayk,n:starts.length};return true}
  var due=0;for(var i=0;i<starts.length;i++)if(now>=starts[i])due=i+1;
  if(due<=st.n)return false;
  L[key]={k:dayk,n:due};
  if(now>=Math.min(end,starts[due-1]+CATCH*60000))return true;
  send();return true}
function jamMsg(id,pv,u){var P=window.Prayer,nm=u.name?" يا "+u.name:"";
  return {t:"صلاة "+P.name(id)+" أذّنت "+nm+" "+(u.f?"وإنتي لسه مصلّيتيش ":"وإنت لسه مصلّيتش ")+P.name(pv)+" 🙆🏻⚠️",
          b:(u.f?"إنتي هتجمعي صلاتين!!!":"إنت هتجمع صلاتين!!!")+" 😔😳🤦🏻🙀"}}
function prayTick(){
  var P=window.Prayer;if(!P||!P.times)return;load();if(!N.on.pb&&!N.on.pm)return;
  var now=Date.now(),d=new Date(),k=dk(d),T=P.times(d),L=last(),ch=false,u=me(),
      mid=new Date(d.getFullYear(),d.getMonth(),d.getDate()+1).getTime(),
      END={fajr:T.sunrise,dhuhr:T.asr,asr:T.maghrib,maghrib:T.isha,isha:mid},
      gap=Math.max(5,+N.pr||30)*60000;
  P.LIST.forEach(function(p,ix){var id=p[0],t=T[id],dn=P.done(k,id);
    if(N.on.pm&&ix>0){var pv=P.LIST[ix-1][0];
      ch=run(L,"pj_"+id,k,[t],now,t+30*60000,dn||P.done(k,pv),function(){var o=jamMsg(id,pv,u);fire(o.t,o.b,"wird-pj-"+id,"pray")})||ch}
    if(N.on.pb)ch=run(L,"pb_"+id,k,[t-5*60000],now,t,dn,function(){var o=mk(BC("pb",id),u.f,u.name);fire(o.t,o.b,"wird-pb-"+id,"pray")})||ch;
    if(N.on.pm){var s0=t+15*60000;
      ch=run(L,"pm_"+id,k,[s0,s0+gap,s0+2*gap],now,Math.min(t+3*3600000,END[id]),dn,function(){var o=mk(BC("pm",id),u.f,u.name);fire(o.t,o.b,"wird-pm-"+id,"pray")})||ch}});
  if(ch)setLast(L)}
/* بث من المطوّر لكل المستخدمين */
var bcUnsub=null,bcUid="";
function watchBC(){
  var u=(typeof uid!=="undefined"&&uid)||"";
  if(typeof db==="undefined"||!db||!u||bcUid===u)return;
  if(bcUnsub){try{bcUnsub()}catch(e){}}bcUid=u;
  try{bcUnsub=db.collection("content").doc("broadcast").onSnapshot(function(sn){
    if(!sn.exists)return;var d=sn.data()||{},seen=+localStorage.getItem("q_bc_seen")||0;
    if(!d.id||d.id<=seen||Date.now()-d.id>10*60000||!d.msg||perm()!=="granted")return;
    try{localStorage.setItem("q_bc_seen",String(d.id))}catch(e){}
    var x=me(),o=mk(d.msg,x.f,x.name);fire(o.t,o.b,d.msg.tag||"wird-bc",d.msg.go||"home")},function(){})}catch(e){}}
function broadcast(x){
  if(!isDev())return;var t=function(m){if(typeof toast==="function")toast(m)};
  var o=BC(x);if(!confirm("تبعت الإشعار ده لكل المستخدمين اللي مفعّلين الإشعارات دلوقتي؟"))return;
  var tk=(typeof auth!=="undefined"&&auth&&auth.currentUser)?auth.currentUser.getIdToken():Promise.resolve("");
  tk.then(function(tok){
    if(!window.PUSH_URL)throw new Error("no push url");
    return fetch(window.PUSH_URL+"/broadcast",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({token:tok,msg:o})})
      .then(function(r){if(!r.ok)throw new Error("http "+r.status);return r.json().catch(function(){return {}})})})
  .then(function(j){t("📣 اتبعت"+((j&&j.sent!=null)?" لـ "+j.sent+" جهاز":" لكل المستخدمين"))})
  .catch(function(){
    if(typeof db==="undefined"||!db)return t("مقدرتش أبعت: Firebase مش متفعّل");
    db.collection("content").doc("broadcast").set({id:Date.now(),msg:o,by:(typeof uid!=="undefined"&&uid)||""})
      .then(function(){t("اتبعت للي فاتحين التطبيق دلوقتي. السيرفر لسه مش جاهز للبث لكل الأجهزة")})
      .catch(function(e){t("مقدرتش أبعت: "+((e&&(e.code||e.message))||""))})})}

function tick(){
  if(perm()!=="granted")return;
  pull();watchBC();
  if(!(window.PRAY_PUSH&&pushOk()))prayTick();   // لحد ما الـ Worker يتحدّث، إشعارات الصلاة بتطلع من التطبيق
  if(PU()){sync();if(pushOk()||syncing)return}   // السيرفر هو اللي بيبعت، فمنبعتش من التطبيق عشان ما يتكررش
  load();
  var now=new Date(),k=dk(now),m=now.getHours()*60+now.getMinutes(),L=last(),ch=false;
  var rc=Math.min(3,Math.max(1,+N.rc||1)),rg=Math.max(5,+N.rg||30);
  [["m","tm"],["e","te"],["w","tw"]].forEach(function(p){var x=p[0],t=tm(N[p[1]]);
    if(!N.on[x])return;
    var st=L[x];if(typeof st==="string")st={k:st,n:1};if(!st||st.k!==k)st={k:k,n:0};
    if(st.n>=rc)return;
    var due=0;for(var i=0;i<rc;i++)if(m>=t+i*rg)due=i+1;
    if(due<=st.n)return;
    var late=m>=t+(due-1)*rg+CATCH;
    var wasDone=done(x);
    L[x]={k:k,n:wasDone?rc:due};ch=true;
    if(wasDone||late)return;
    var o=MSG[x]();fire(o.t+(due>1?" 🔁":""),o.b,"wird-"+x,GO[x])});
  if(N.on.d&&!quiet(m)&&Date.now()-(L.d||0)>=Math.max(1,+N.iv||10)*60000){
    L.d=Date.now();ch=true;var o=msgDhikr();
    if(document.visibilityState==="visible"&&typeof toast==="function")toast(o.t);   // لو التطبيق مفتوح قدامك بنظهرها جواه بس
    else fire(o.t,o.b,"wird-d",GO.d)}
  if(ch)setLast(L)}
function css(){if(E("ntCss"))return;var s=document.createElement("style");s.id="ntCss";
  s.textContent=".nt-row{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:10px 12px;margin:8px 0;border-radius:14px;background:var(--card);border:1px solid rgba(127,127,127,.3);text-align:right}.nt-row b{display:block}.nt-row small{display:block;color:var(--mute);font-size:12px}.nt-row input[type=checkbox]{width:24px!important;height:24px;flex:none}.nt-row input[type=time],.nt-row select{width:auto!important;min-width:96px;flex:none;padding:6px 8px}.nt-st{margin:8px 0;font-weight:700}.nt-row{flex-wrap:wrap}.nt-send{flex:1 0 100%;padding:8px;font-size:14px;margin-top:2px}";
  document.head.appendChild(s)}
function status(){var p=perm();
  if(p==="unsupported")return {t:"المتصفح ده مش بيدعم الإشعارات. على الآيفون لازم تثبّت التطبيق على الشاشة الرئيسية الأول 📲",ok:0};
  if(p==="denied")return {t:"الإشعارات متقفلة من إعدادات المتصفح/التليفون ❌ افتحها لموقع التطبيق وارجع هنا",ok:0};
  if(p==="granted")return {t:pushOk()?"الإشعارات شغالة وبتوصل حتى والتطبيق مقفول ✅":(PU()?"الإشعارات شغالة ✅ (بنربط السيرفر...)":"الإشعارات شغالة على الجهاز ده ✅"),ok:1};
  return {t:"الإشعارات لسه مش مفعّلة 🔕",ok:0}}
function bcb(x){return '<button class="alt nt-send" onclick="Notif.bc(\''+x+'\')">📣 ابعت دلوقتي</button>'}
function row(x,tt,sub,tk){return '<div class="nt-row"><div><b>'+tt+'</b><small>'+sub+'</small></div>'+(tk?'<input type="time" value="'+N[tk]+'" onchange="Notif.set(\''+tk+'\',this.value)">':'')+'<input type="checkbox"'+(N.on[x]?' checked':'')+' onchange="Notif.tog(\''+x+'\',this.checked)">'+bcb(x)+'</div>'}
function render(){var sec=E("notif");if(!sec)return;css();load();var st=status();
  var h='<div class="panel"><h2>🔔 الإشعارات</h2><div class="mute" style="margin-bottom:6px">⚙️ للمطوّر بس — اللي تختاره هنا بيتطبق على كل المستخدمين، وهما بس بيفعّلوا الإشعارات.</div><div class="nt-st">'+st.t+'</div>'+
   (st.ok?'<div class="row"><button class="alt" onclick="Notif.test()">🔔 جرّب إشعار</button></div>':(perm()==="unsupported"||perm()==="denied"?'':'<div class="row"><button onclick="Notif.ask()">🔔 فعّل الإشعارات</button></div>'))+
   row("m","☀️ أذكار الصباح","بيفكّرك لو لسه ما خلصتهاش","tm")+row("e","🌙 أذكار المساء","بيفكّرك لو لسه ما خلصتهاش","te")+row("w","📖 الورد","بيفكّرك لو لسه ما سجلتش ورد النهاردة","tw")+
   '<div class="nt-row"><div><b>📿 اذكر ربنا</b><small>تذكير بالاسم كل فترة</small></div><select onchange="Notif.set(\'iv\',+this.value)">'+[5,10,15,30].map(function(v){return '<option value="'+v+'"'+(+N.iv===v?' selected':'')+'>كل '+v+' دقيقة</option>'}).join("")+'</select><input type="checkbox"'+(N.on.d?' checked':'')+' onchange="Notif.tog(\'d\',this.checked)">'+bcb("d")+'</div>'+
   '<div class="nt-row"><div><b>🕌 قبل الصلاة بـ 5 دقايق</b><small>"صلاة كذا بعد 5 دقايق"</small></div><input type="checkbox"'+(N.on.pb?' checked':'')+' onchange="Notif.tog(\'pb\',this.checked)">'+bcb("pb")+'</div>'+
   '<div class="nt-row"><div><b>🕌 «قوم صلي» لو لسه ما علّمتش</b><small>بيبدأ بعد الأذان بـ 15 دقيقة، وبحد أقصى 3 مرات للصلاة</small></div><select onchange="Notif.set(\'pr\',+this.value)">'+[15,30,45,60].map(function(v){return '<option value="'+v+'"'+((+N.pr||30)===v?' selected':'')+'>كل '+v+' دقيقة</option>'}).join("")+'</select><input type="checkbox"'+(N.on.pm?' checked':'')+' onchange="Notif.tog(\'pm\',this.checked)">'+bcb("pm")+'</div>'+
   '<div class="nt-row"><div><b>😴 ساعات الهدوء</b><small>"اذكر ربنا" ما بتجيش فيها</small></div><span>من <input type="time" value="'+N.qs+'" onchange="Notif.set(\'qs\',this.value)"> إلى <input type="time" value="'+N.qe+'" onchange="Notif.set(\'qe\',this.value)"></span></div>'+
   '<div class="nt-row"><div><b>🔁 تكرار تذكير الأذكار والورد</b><small>لو لسه ما خلصتهاش يفكّرك أكتر من مرة (بيقف أول ما تخلّصها)</small></div><span><select onchange="Notif.set(\'rc\',+this.value)">'+[1,2,3].map(function(v){return '<option value="'+v+'"'+((+N.rc||1)===v?' selected':'')+'>'+(v===1?"مرة واحدة":v===2?"مرتين":"3 مرات")+'</option>'}).join("")+'</select> <select onchange="Notif.set(\'rg\',+this.value)">'+[15,30,45,60,120].map(function(v){return '<option value="'+v+'"'+((+N.rg||30)===v?' selected':'')+'>كل '+v+' دقيقة</option>'}).join("")+'</select></span></div>'+
   (pushOk()?'':'<div class="mute" style="margin-top:10px">⚠️ '+(PU()?'السيرفر لسه مش متربط، فالإشعارات شغالة والتطبيق مفتوح أو في الخلفية بس.'+(lastErr?'<br><small dir="auto">السبب: '+escT(lastErr)+'</small>':''):'الإشعارات بتشتغل طول ما التطبيق مفتوح أو شغّال في الخلفية. لو التليفون قفله خالص ممكن تتأخر.')+'</div>')+
   '<div class="row"><button class="alt" onclick="show(\'edit\')">⬅️ رجوع</button></div></div>';
  sec.innerHTML=h}
function home(){var b=E("notifHome");if(!b)return;var st=status(),p=perm();
  b.innerHTML='<h2>🔔 الإشعارات</h2><div class="mute" style="margin-bottom:8px">'+(st.ok?"شغالة ✅":"مش مفعّلة 🔕")+'</div>'+
   (p==="default"?'<div class="row"><button onclick="Notif.ask()">🔔 فعّل الإشعارات</button></div>':(st.ok?'':'<div class="mute">'+st.t+'</div>'))}
function go(x){if(!x)return;try{if(x==="m"||x==="e")Adhkar.open(x);else if(x==="dhikr")Adhkar.open();else if(x==="pray")Prayer.open();else show("home")}catch(e){}}
window.Notif={
  open:function(){if(!isDev())return;render();show("notif")},
  ask:function(){if(typeof Notification==="undefined")return render();
    var done=function(){var L=last();L.d=Date.now();setLast(L);pull(true);sync(true);home();tick()};
    try{var r=Notification.requestPermission(done);if(r&&r.then)r.then(done)}catch(e){done()}},
  test:function(){var o=msgDhikr();fire(o.t,o.b,"wird-test","dhikr")},
  tog:function(x,v){if(!isDev())return;load();N.on[x]=v?1:0;save();sync()},
  set:function(k,v){if(!isDev())return;load();N[k]=v;save();sync()},
  bc:broadcast,
  fire:fire,
  go:go,
  sync:function(){sync()},
  /* بيمسح اشتراك الجهاز (وكل أجهزة الحساب) من سيرفر الإشعارات - بيتنادى قبل مسح الحساب. مبيفشلش أبدًا */
  unsub:function(){
    if(window.NativeApp)return NativeApp.unsub();
    if(!PU())return Promise.resolve();
    var cap=function(p,ms){return Promise.race([p,new Promise(function(r){setTimeout(r,ms)})])};
    var tk=(typeof auth!=="undefined"&&auth&&auth.currentUser)?auth.currentUser.getIdToken():Promise.resolve("");
    return cap(navigator.serviceWorker.ready.then(function(r){return r.pushManager.getSubscription()}).then(function(s){
      return tk.then(function(tok){
        var b=tok?{token:tok,uid:(typeof uid!=="undefined"&&uid)||"",sub:s?s.toJSON():undefined}:{sub:s?s.toJSON():undefined};
        if(!tok&&!s)return;
        return fetch(window.PUSH_URL+"/unsubscribe",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(b)}).catch(function(){})
      }).then(function(){return s&&s.unsubscribe()})}),6000).catch(function(){}).then(function(){setOk(false);lastSent=""})},
  tick:tick
};
window.notifRemote=function(){};   // الإعدادات بقت عامة من المطوّر (content/notif_cfg)
var prevSwitch=window.onUserSwitch;
window.onUserSwitch=function(){if(prevSwitch)try{prevSwitch()}catch(e){}N=null;load();setOk(false);lastSent="";setTimeout(function(){pull(true);sync(true)},800);if(cur_v==="notif")render()};
var os=window.show;window.show=function(i){os(i);if(i==="home")home()};
if("serviceWorker" in navigator)navigator.serviceWorker.addEventListener("message",function(e){if(!e.data)return;if(e.data.resync){setOk(false);lastSent="";sync(true)}if(e.data.go)go(e.data.go)});
try{var q=new URLSearchParams(location.search).get("go");if(q){history.replaceState(null,"",location.pathname);setTimeout(function(){go(q)},900)}}catch(e){}
home();setInterval(tick,15000);
document.addEventListener("visibilitychange",function(){if(!document.hidden){home();tick()}});
setTimeout(tick,4000);
})();
