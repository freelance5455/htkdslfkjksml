// Offline-first. غيّر رقم CACHE_NAME مع كل نسخة جديدة عشان الموبايل يحمّلها.
const CACHE_NAME = "quran-shell-v85", LIB_CACHE = "quran-libs-v1";
const SHELL = ["./", "./index.html", "./manifest.json", "./firebase-config.js", "./data/ayat.js", "./data/meta.js", "./wird.js", "./adhkar.js", "./prayer.js", "./notif.js", "./push-config.js", "./quiz.js", "./mushaf.js", "./reader.js", "./features.js", "./icon-192.png", "./icon-512.png", "./icon-maskable-192.png", "./icon-maskable-512.png", "./badge-96.png"];
const FONT_CSS = "https://fonts.googleapis.com/css2?family=Amiri+Quran&family=Amiri:wght@400;700&display=swap";
const LIBS = ["app", "auth", "firestore"].map(n => `https://www.gstatic.com/firebasejs/10.13.0/firebase-${n}-compat.js`).concat(FONT_CSS);

/* ردّ بعد redirect (زي /index.html ← / في Cloudflare Pages) مينفعش يتقدّم لصفحة، فبنعمله نسخة نضيفة */
const clean = async x => x.redirected ? new Response(await x.blob(), { status: x.status, statusText: x.statusText, headers: x.headers }) : x;

self.addEventListener("install", e => e.waitUntil((async () => {
  const sc = await caches.open(CACHE_NAME);
  await Promise.all(SHELL.map(async u => { const x = await fetch(new Request(u, { cache: "reload" })); if (!x.ok) throw new Error(u); await sc.put(u, await clean(x)); }));
  const libs = await caches.open(LIB_CACHE);
  await Promise.all(LIBS.map(u => fetch(new Request(u, { mode: "no-cors" })).then(r => libs.put(u, r)).catch(() => {})));
  self.skipWaiting();
})()));

self.addEventListener("activate", e => e.waitUntil(
  caches.keys().then(ks => Promise.all(ks.filter(k => ![CACHE_NAME, LIB_CACHE].includes(k)).map(k => caches.delete(k)))).then(() => self.clients.claim())
));

/* إشعار جاي من السيرفر (Web Push) - بيظهر حتى والتطبيق مقفول */
self.addEventListener("push", e => {
  let d = {};
  try { d = e.data.json(); } catch (_) { d = { t: "اذكر ربنا 🤍", b: "" }; }
  e.waitUntil(self.registration.showNotification(d.t || "اذكر ربنا 🤍", {
    body: d.b || "", icon: "icon-192.png", badge: "badge-96.png", tag: d.tag || "wird", renotify: true,
    lang: "ar", dir: "rtl", vibrate: [120, 60, 120], data: { go: d.go || "home" }
  }));
});

/* المتصفح غيّر/جدّد اشتراك الإشعارات: نشترك من جديد وننقل بيانات الاشتراك القديم للسيرفر، ونبلّغ التطبيق لو مفتوح */
let PUSH_URL = "";
try { self.window = self; importScripts("./push-config.js"); PUSH_URL = self.PUSH_URL || ""; } catch (_) {}
self.addEventListener("pushsubscriptionchange", e => e.waitUntil((async () => {
  const old = e.oldSubscription;
  let sub = e.newSubscription;
  if (!sub) {
    const key = (old && old.options && old.options.applicationServerKey) || self.VAPID_PUB;
    if (key) sub = await self.registration.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: key }).catch(() => null);
  }
  if (sub && PUSH_URL && old && old.endpoint && sub.endpoint !== old.endpoint) {
    try { await fetch(PUSH_URL + "/resubscribe", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ old: old.endpoint, sub: sub.toJSON() }) }); } catch (_) {}
  }
  (await self.clients.matchAll({ type: "window", includeUncontrolled: true })).forEach(c => c.postMessage({ resync: 1 }));
})()));

/* الضغط على الإشعار: يفتح التطبيق ويودّيك للصفحة المناسبة (أذكار الصباح/المساء/الرئيسية) */
self.addEventListener("notificationclick", e => {
  e.notification.close();
  const go = (e.notification.data && e.notification.data.go) || "home";
  e.waitUntil(self.clients.matchAll({ type: "window", includeUncontrolled: true }).then(cs => {
    const c = cs[0];
    if (c) { c.postMessage({ go }); return c.focus(); }
    return self.clients.openWindow("./?go=" + encodeURIComponent(go));
  }));
});

self.addEventListener("fetch", e => {
  const r = e.request, u = new URL(r.url);
  if (r.method !== "GET" || u.pathname.endsWith("version.json") || u.pathname.startsWith("/.well-known/") || /\/(privacy|delete-account)(\.html)?$/.test(u.pathname)) return;   // version.json دايمًا من النت
  if (["www.gstatic.com", "fonts.googleapis.com", "fonts.gstatic.com"].includes(u.hostname)) {                       // مكتبات Firebase: من الكاش الأول
    e.respondWith(caches.open(LIB_CACHE).then(c => c.match(r).then(h => h || fetch(r).then(x => { c.put(r, x.clone()); return x; }))));
  } else if (u.origin === location.origin) {                    // ملفات الموقع: من الكاش وتتحدّث في الخلفية
    e.respondWith(caches.open(CACHE_NAME).then(async c => {
      const nav = r.mode === "navigate";
      const hit = await c.match(r, { ignoreSearch: true }) || (nav && (await c.match("./index.html") || await c.match("./")));
      const net = fetch(r).then(async x => { const y = await clean(x); if (y.ok) c.put(nav ? "./index.html" : r, y.clone()); return y; }).catch(() => hit || Response.error());
      return hit || net;
    }));
  }
});
