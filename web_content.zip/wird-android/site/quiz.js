function G(m,f){try{return g(m,f)}catch(e){return m}}
/* ===== لعبة اختبار ☢️⚠️ ===== */
(function(){
"use strict";
var E=function(id){return document.getElementById(id)};
var CFG_KEY="q_quiz_cfg";
var KINDS={
  juz:{label:"جزء",unit:"جزء",min:1,max:30,sel:true},
  hizb:{label:"حزب",unit:"حزب",min:1,max:60,sel:true},
  rub:{label:"ربع",unit:"ربع",min:1,max:240},
  page:{label:"صفحات",unit:"صفحة",min:1,max:604},
  surah:{label:"سورة",unit:"سورة",min:1,max:114,sel:true,single:true},
  surahs:{label:"من سورة لسورة",unit:"سورة",min:1,max:114,sel:true}
};
var TYPES={
  next:{label:"أكمل الآية",emoji:"✍️",pts:10},
  next2:{label:"اكتب آيتين بعدها",emoji:"🙋🏻",pts:20},
  between:{label:"من قوله تعالى … إلى قوله تعالى",emoji:"🤔",pts:12},
  prev:{label:"الآية اللي قبلها",emoji:"⏪",pts:12},
  blank:{label:"الكلمة الناقصة",emoji:"🧩",pts:6},
  surah:{label:"دي آية من أنهي سورة؟",emoji:"📍",pts:6}
};
var S=loadCfg(),V="setup",R=null,info="";

function loadCfg(){
  var d={kind:"juz",a:1,b:1,n:10,types:{next:1,next2:1,between:1,prev:1,blank:1,surah:1}};
  try{var c=JSON.parse(localStorage.getItem(CFG_KEY));if(c&&KINDS[c.kind]){d.kind=c.kind;d.a=+c.a||1;d.b=+c.b||d.a;d.n=+c.n||10;if(c.types)d.types=c.types}}catch(e){}
  return d;
}
function saveCfg(){try{localStorage.setItem(CFG_KEY,JSON.stringify(S))}catch(e){}}
function clampRange(){var K=KINDS[S.kind];S.a=Math.min(K.max,Math.max(K.min,Math.floor(S.a)||K.min));S.b=K.single?S.a:Math.min(K.max,Math.max(K.min,Math.floor(S.b)||S.a))}
var shuffle=function(a){for(var i=a.length-1;i>0;i--){var j=Math.floor(Math.random()*(i+1)),t=a[i];a[i]=a[j];a[j]=t}return a};
var short=function(t){return String(t).replace(/^سور[ةه]\s*/,"")};
var wordsOf=function(t){return String(t).trim().split(/\s+/)};

/* ----- النطاق والآيات المتاحة ----- */
function scopeRange(){
  clampRange();var a=S.a,b=Math.max(S.a,S.b);
  return window.QMeta?QMeta.range(S.kind,a,b):null;
}
function universe(rg){
  var out=[],lo=rg[0],hi=rg[1];
  (typeof surahs!=="undefined"?surahs:[]).forEach(function(s){
    var m=/^q(\d+)$/.exec(s.id);if(!m)return;var n=+m[1];if(n<1||n>114)return;
    var ok=s.segments.map(function(_,i){var k=n*1000+i+1;return k>=lo&&k<=hi});
    if(ok.some(Boolean))out.push({id:s.id,n:n,title:s.title,seg:s.segments,ok:ok});
  });
  return out;
}
function countAyat(U){var c=0;U.forEach(function(b){b.ok.forEach(function(x){if(x)c++})});return c}

/* ----- بناء الأسئلة ----- */
function buildCounts(){
  var cnt={};
  (typeof surahs!=="undefined"?surahs:[]).forEach(function(s){if(!/^q\d+$/.test(s.id))return;s.segments.forEach(function(t){var k=norm(t);cnt[k]=(cnt[k]||0)+1})});
  return cnt;
}
function candidates(U,cnt){
  var C={next:[],next2:[],between:[],prev:[],blank:[],surah:[]};
  var uq=function(t){return cnt[norm(t)]===1};
  U.forEach(function(b){
    var L=b.seg.length,sg=b.seg,ok=b.ok;
    for(var i=0;i<L;i++){
      if(!ok[i]||!uq(sg[i]))continue;
      var t=norm(sg[i]);
      if(i+1<L&&ok[i+1]&&norm(sg[i+1])!==t)C.next.push([b,i]);
      if(i+2<L&&ok[i+1]&&ok[i+2])C.next2.push([b,i]);
      for(var sp=3;sp<=4;sp++)if(i+sp-1<L&&ok[i+1]&&ok[i+sp-1]&&(sp<4||ok[i+2])&&uq(sg[i+sp-1]))C.between.push([b,i,sp]);
      if(i>0&&ok[i-1]&&norm(sg[i-1])!==t)C.prev.push([b,i]);
      if(wordsOf(sg[i]).length>=4){C.blank.push([b,i]);C.surah.push([b,i])}
    }
  });
  return C;
}
function make(type,c){
  var b=c[0],i=c[1],sg=b.seg,q={type:type,sid:b.id,n:b.n,title:b.title,i:i,pts:TYPES[type].pts,hintCost:0,hinted:false,wrong:0,mk:-1,single:false};
  if(type==="next"){q.shown=[sg[i]];q.ask="اكتب الآية اللي بعدها";q.ans=sg[i+1];q.mk=i}
  else if(type==="next2"){q.shown=[sg[i]];q.ask="اكتب الآيتين اللي بعدها";q.ans=sg[i+1]+" "+sg[i+2];q.mk=i}
  else if(type==="between"){var sp=c[2];q.shown=[sg[i],sg[i+sp-1]];q.pair=true;q.ask=sp===3?"اكتب الآية اللي بينهم":"اكتب الآيتين اللي بينهم";q.ans=sg.slice(i+1,i+sp-1).join(" ");q.pts=sp===3?12:20;q.mk=i}
  else if(type==="prev"){q.shown=[sg[i]];q.ask="اكتب الآية اللي قبلها";q.ans=sg[i-1];q.mk=i-1}
  else if(type==="blank"){
    var w=wordsOf(sg[i]),cand=[];w.forEach(function(x,k){if(letters(x).length>=3)cand.push(k)});
    var k=cand.length?cand[Math.floor(Math.random()*cand.length)]:Math.floor(w.length/2);
    q.ans=w[k];var sh=w.slice();sh[k]="＿＿＿＿";q.shown=[sh.join(" ")];q.ask="اكتب الكلمة الناقصة";q.single=true;q.mk=i;q.ansLen=letters(w[k]).length;
  }
  else{q.shown=[sg[i]];q.ask="دي آية من أنهي سورة؟";q.ans=b.title;q.single=true;q.mk=i}
  if(q.mk<0||q.mk+1>=sg.length)q.mk=-1;           // مينفعش نسجّلها للمراجعة (مفيش آية بعدها)
  return q;
}
function letters(t){return String(t).replace(/[ً-ٰٟـ]/g,"")}
function generate(U,n,types){
  var cnt=buildCounts(),C=candidates(U,cnt),pool=[],used={},out=[],tries=0;
  types.forEach(function(t){if(C[t].length)pool.push(t)});
  if(!pool.length)return out;
  var order=[],tot={},seen={};
  while(order.length<n)order=order.concat(shuffle(pool.slice()));
  order=order.slice(0,n);
  order.forEach(function(t){tot[t]=(tot[t]||0)+1});
  order.forEach(function(t){
    var arr=C[t],picked=null,k,m=seen[t]=(seen[t]===undefined?0:seen[t]+1);
    /* كل سؤال من نوعه بيتسحب من شريحة مختلفة من النطاق عشان الأسئلة تتوزّع على الجزء/السور كلها */
    var lo=Math.floor(m/tot[t]*arr.length),hi=Math.max(lo+1,Math.floor((m+1)/tot[t]*arr.length));
    for(k=0;k<30&&!picked;k++){
      var c=k<20?arr[lo+Math.floor(Math.random()*(hi-lo))]:arr[Math.floor(Math.random()*arr.length)],span=t==="between"?c[2]:t==="next2"?3:2,clash=false,j;
      for(j=-1;j<=span;j++)if(used[c[0].id+"|"+(c[1]+j)])clash=true;
      if(!clash)picked=c;
    }
    if(!picked)return;
    var sp=picked[2]||(t==="next2"?3:2),j;
    for(j=0;j<sp;j++)used[picked[0].id+"|"+(picked[1]+j)]=1;
    out.push(make(t,picked));
  });
  return shuffle(out);
}

/* ----- تصحيح ----- */
function checkAns(q,val){
  if(!norm(val))return null;
  if(q.type==="surah")return surahOk(val,q.title);
  if(q.type==="blank")return dist(val,q.ans)<=(strictKey(q.ans).length>=4?1:0);
  return match(val,q.ans);
}
function hintFor(q){
  if(q.type==="surah"){var nm=short(q.title);return "تبدأ بحرف «"+letters(nm).charAt(0)+"» وعدد حروفها "+letters(nm).replace(/ /g,"").length}
  if(q.type==="blank")return "الكلمة تبدأ بحرف «"+letters(q.ans).charAt(0)+"» وعدد حروفها "+q.ansLen;
  var w=wordsOf(q.ans);
  return w.length>=3?"أول كلمة: «"+w[0]+"» · الإجابة "+w.length+" كلمات":"أول حرفين: «"+letters(w[0]).slice(0,2)+"…» · الإجابة "+w.length+" كلمات";
}

/* ----- تشغيل ----- */
function start(){
  clampRange();saveCfg();
  var rg=scopeRange();
  if(!rg){info="بيانات الصفحات والأجزاء لسه ما اتحمّلتش";return render()}
  var U=universe(rg),total=countAyat(U);
  if(!total){info="المصحف مش متحمّل للنطاق ده. دوس «حمّل المصحف كامل» تحت.";return render()}
  var types=Object.keys(S.types).filter(function(t){return S.types[t]});
  if(!types.length){info="اختار نوع سؤال واحد على الأقل";return render()}
  var qs=generate(U,S.n,types);
  if(!qs.length){info="النطاق ده صغير ومفيش أسئلة مناسبة من الأنواع المختارة";return render()}
  R={qs:qs,i:0,res:[],pts:0,cor:0,answered:false,last:null,cfgLabel:scopeLabel()};
  V="run";info="";render();
  if(qs.length<S.n&&window.toast)toast("النطاق صغير: هيتعمل "+qs.length+" سؤال بس");
}
function scopeLabel(){
  var K=KINDS[S.kind],a=S.a,b=Math.max(S.a,S.b);
  if(S.kind==="surah")return "سورة "+window.SURAH_NAMES[a-1];
  if(S.kind==="surahs")return a===b?"سورة "+window.SURAH_NAMES[a-1]:"من سورة "+window.SURAH_NAMES[a-1]+" إلى "+window.SURAH_NAMES[b-1];
  return a===b?K.unit+" "+a:"من "+K.unit+" "+a+" إلى "+b;
}
function answer(skip){
  var q=R.qs[R.i];if(R.answered)return;
  var el=E("qzIn"),val=el?el.value:"",ok=false;
  if(!skip){
    var r=checkAns(q,val);
    if(r===null)return toastMsg("اكتب إجابتك الأول");
    ok=r;
  }
  R.answered=true;
  var earned=0,bonus=0;
  if(ok){
    var base=Math.max(1,q.pts-q.hintCost);score.st++;if(score.st>score.best)score.best=score.st;bonus=Math.min(score.st,5);earned=base+bonus;addPts(earned);score.w++;R.cor++;R.pts+=earned;
    if(window.fxWin)fxWin(G("شاطور"+nmx()+"","شاطورة"+nmx()+"")+" 🎉");
  }else{
    score.l++;score.st=0;if(q.mk>=0&&window.recMist)recMist(q.sid,q.mk);
    if(window.fxLose)fxLose(skip?G("كنت حاول فيها"+nmx()+" 🥺💔","كنتي حاولي فيها"+nmx()+" 🥺💔"):G("غلط"+nmx()+"… 💔","غلط"+nmx()+"… 💔"));
  }
  save();
  R.res.push({q:q,ok:ok,skip:!!skip,val:val,earned:earned});
  R.last={ok:ok,skip:!!skip,earned:earned,bonus:bonus};
  render();
}
function hint(){
  var q=R.qs[R.i];if(R.answered||q.hinted)return;
  q.hinted=true;q.hintCost=Math.ceil(q.pts*0.3);q.hintText=hintFor(q);render();
}
function next(){
  if(R.i+1>=R.qs.length){V="result";R.fin=true;render();
    var pct=R.cor/R.qs.length;if(pct>=.7&&window.fxWin)setTimeout(function(){fxWin(G("ما شاء الله"+nmx()+" 🌟","ما شاء الله"+nmx()+" 🌟"))},200);return}
  R.i++;R.answered=false;R.last=null;render();
}
function quit(){if(!confirm("تنهي الاختبار؟ النقاط اللي خدتها هتفضل محفوظة."))return;
  if(R.res.length){V="result";R.fin=true}else{V="setup";R=null}render()}
function again(){start()}
function newSetup(){V="setup";R=null;info="";render()}
function toastMsg(t){if(window.toast)toast(t);else alert(t)}

/* ----- إعدادات ----- */
function setKind(k){S.kind=k;var K=KINDS[k];S.a=K.min;S.b=K.min;info="";clampRange();render()}
function setA(v){S.a=+v;if(S.b<S.a||KINDS[S.kind].single)S.b=S.a;info="";render()}
function setB(v){S.b=+v;if(S.b<S.a)S.a=S.b;info="";render()}
function setN(n){S.n=n;render()}
function toggleType(t){S.types[t]=S.types[t]?0:1;render()}
function opts(K,sel){
  var h="";
  for(var i=K.min;i<=K.max;i++){
    var lab=(S.kind==="surah"||S.kind==="surahs")?i+" · "+window.SURAH_NAMES[i-1]:K.unit+" "+i;
    h+='<option value="'+i+'"'+(i===sel?' selected':'')+'>'+lab+'</option>';
  }
  return h;
}
function fieldHtml(id,sel,fn){
  var K=KINDS[S.kind];
  return K.sel
    ?'<select id="'+id+'" onchange="Quiz.'+fn+'(this.value)">'+opts(K,sel)+'</select>'
    :'<input id="'+id+'" type="number" inputmode="numeric" min="'+K.min+'" max="'+K.max+'" value="'+sel+'" onchange="Quiz.'+fn+'(this.value)">';
}
function previewInfo(){
  var K=KINDS[S.kind];
  if(S.kind!=="surah"&&S.kind!=="surahs"&&window.QMeta&&!QMeta.ready()){
    if(!previewInfo.busy){previewInfo.busy=true;QMeta.load().then(function(ok){previewInfo.busy=false;previewInfo.failed=!ok;if(V==="setup")render()})}
    return previewInfo.failed?"⚠️ محتاج نت مرة واحدة لتحميل بيانات الأجزاء والصفحات. اختيار السورة بيشتغل من غير نت.":"⏳ بجهّز بيانات الصفحات والأجزاء...";
  }
  var rg=scopeRange();if(!rg)return "";
  return countAyat(universe(rg))?"✅ "+scopeLabel():"⚠️ المصحف مش متحمّل للنطاق ده";
}

/* ----- الرسم ----- */
function render(){
  var el=E("quiz");if(!el)return;
  if(V==="setup")el.innerHTML=setupHtml();
  else if(V==="run")el.innerHTML=runHtml();
  else el.innerHTML=resultHtml();
  if(V==="run"){var i=E("qzIn");if(i&&!R.answered)i.focus({preventScroll:true})}
}
function emptyRange(){var rg=scopeRange();return !!rg&&!countAyat(universe(rg))}
function loadAll(){
  if(typeof importQuran!=="function")return;
  var p=importQuran();Promise.resolve(p).then(function(){info="";render()});
}
function setupHtml(){
  var K=KINDS[S.kind],kinds=Object.keys(KINDS).map(function(k){return '<button class="alt qz-chip'+(S.kind===k?' sel':'')+'" onclick="Quiz.kind(\''+k+'\')">'+KINDS[k].label+'</button>'}).join("");
  var ns=[5,10,15,20,30].map(function(n){return '<button class="alt qz-chip'+(S.n===n?' sel':'')+'" onclick="Quiz.n('+n+')">'+n+'</button>'}).join("");
  var ts=Object.keys(TYPES).map(function(t){return '<label class="qz-type'+(S.types[t]?' on':'')+'"><input type="checkbox" '+(S.types[t]?'checked':'')+' onchange="Quiz.type(\''+t+'\')"><span>'+TYPES[t].emoji+' '+TYPES[t].label+'</span></label>'}).join("");
  var from=K.single
    ?'<div class="qz-field"><label>'+K.unit+'</label>'+fieldHtml("qzA",S.a,"a")+'</div>'
    :'<div class="qz-two"><div class="qz-field"><label>من '+K.unit+'</label>'+fieldHtml("qzA",S.a,"a")+'</div><div class="qz-field"><label>إلى '+K.unit+'</label>'+fieldHtml("qzB",Math.max(S.a,S.b),"b")+'</div></div>';
  var pv=previewInfo();
  return '<div class="panel qz"><h2>☢️⚠️ اختبار</h2>'+
    '<div class="card"><h3>عايزني اختبرك في إيه؟ ✨🤍</h3><div class="qz-chips">'+kinds+'</div>'+from+
      (emptyRange()?'<div class="row"><button class="alt" onclick="Quiz.loadAll()">📥 حمّل المصحف كامل</button></div>':'')+
      (K.max===240||K.max===604?'<div class="mute">'+(S.kind==="rub"?'الربع من 1 لـ 240':'الصفحة من 1 لـ 604')+'</div>':'')+
      '<div class="qz-info">'+esc(info||pv)+'</div></div>'+
    '<div class="card"><h3>كام سؤال؟</h3><div class="qz-chips">'+ns+'</div>'+
      '<h3 style="margin-top:14px">أنواع الأسئلة</h3><div class="qz-types">'+ts+'</div></div>'+
    '<div class="row"><button onclick="Quiz.start()">ابدأ الاختبار 🚀</button></div>'+
    '<div class="row"><button class="alt" onclick="show(\'home\')">⬅️ رجوع</button></div></div>';
}
function runHtml(){
  var q=R.qs[R.i],T=TYPES[q.type],pct=Math.round(R.i/R.qs.length*100),a=R.answered,L=R.last;
  var shown;
  if(q.pair)shown='<div class="qz-lab">من قوله تعالى</div><div class="qz-ayah">'+esc(q.shown[0])+'</div><div class="qz-dots">⋯</div><div class="qz-lab">إلى قوله تعالى</div><div class="qz-ayah">'+esc(q.shown[1])+'</div>';
  else shown='<div class="qz-ayah">'+esc(q.shown[0])+'</div>';
  var inp=q.single
    ?'<input id="qzIn" autocomplete="off" dir="rtl" placeholder="'+(q.type==="surah"?"اكتب اسم السورة":"اكتب الكلمة")+'" '+(a?'disabled':'')+' enterkeyhint="go">'
    :'<textarea id="qzIn" dir="rtl" rows="3" enterkeyhint="go" placeholder="اكتب إجابتك هنا" '+(a?'disabled':'')+'></textarea>';
  var res="";
  if(a){
    var good=L.ok;
    res='<div class="qz-res '+(good?'good':'bad')+'"><b>'+(good?"✅ صح! +"+L.earned+" نقطة"+(L.bonus?" (منها "+L.bonus+" 🔥)":""):(L.skip?G("⏭️ تخطّيت"+nmx()+"","⏭️ تخطّيتي"+nmx()+""):G("❌ غلط"+nmx()+"","❌ غلط"+nmx()+"")))+'</b>'+
      (good?'':'<div class="qz-ans">الإجابة الصحيحة:<br>'+esc(q.type==="surah"?short(q.title):q.ans)+'</div>')+
      (!good&&q.mk>=0?'<div class="mute">اتضافت لمراجعة الغلطات 🔁</div>':'')+'</div>'+
      '<div class="row"><button onclick="Quiz.next()">'+(R.i+1>=R.qs.length?"شوف النتيجة 🏁":"التالي ➡️")+'</button></div>';
  }
  var acts=a?'':'<div class="row"><button onclick="Quiz.ok()">✅ تأكيد</button><button class="alt" onclick="Quiz.hint()"'+(q.hinted?' disabled':'')+'>'+(q.hinted?G('💡 كفاية عليك'+nmx(),'💡 كفاية عليكي'+nmx()):'💡 تلميح −'+Math.ceil(q.pts*0.3))+'</button><button class="alt" onclick="Quiz.skip()">⏭️ تخطّي</button></div>';
  return '<div class="panel qz"><h2>☢️⚠️ '+esc(R.cfgLabel)+'</h2>'+
    '<div class="qz-prog"><i style="width:'+pct+'%"></i></div>'+
    '<div class="lvl-row"><b>سؤال '+(R.i+1)+' / '+R.qs.length+'</b><span>⭐ '+R.pts+' نقطة · صح '+R.cor+'</span></div>'+
    '<div class="card"><div class="qz-tag">'+T.emoji+' '+T.label+'</div>'+shown+'<div class="qz-ask">'+q.ask+'</div>'+inp+
      (q.hinted?'<div class="hint-box">💡 '+esc(q.hintText)+' <small>(−'+q.hintCost+')</small></div>':'')+res+acts+'</div>'+
    '<div class="row"><button class="alt" onclick="Quiz.quit()">إنهاء الاختبار</button></div></div>';
}
function resultHtml(){
  var n=R.res.length,cor=R.res.filter(function(r){return r.ok}).length,pct=n?Math.round(cor/n*100):0;
  var stars=pct>=90?"🌟🌟🌟":pct>=70?"🌟🌟":pct>=50?"🌟":"💪";
  var msg=pct>=90?G("ما شاء الله، ممتاز"+nmx()+"!","ما شاء الله، ممتازة"+nmx()+"!"):pct>=70?G("جيد جدًا، كمّل"+nmx()+"!","جيد جدًا، كمّلي"+nmx()+"!"):pct>=50?G("كويس، راجع الغلطات"+nmx()+"","كويس، راجعي الغلطات"+nmx()+""):G("محتاج مراجعة أكتر، متزعلش"+nmx()+"","محتاجة مراجعة أكتر، متزعليش"+nmx()+"");
  var list=R.res.map(function(r,k){
    return '<div class="qz-li '+(r.ok?'good':'bad')+'"><div><b>'+(r.ok?'✅':'❌')+' '+(k+1)+'. '+TYPES[r.q.type].label+'</b><span class="mute"> · '+(r.ok?'+'+r.earned:'0')+'</span></div>'+
      '<div class="qz-q">'+esc(r.q.shown.join(" … "))+'</div>'+
      (r.ok?'':'<div class="qz-a">الصح: '+esc(r.q.type==="surah"?short(r.q.title):r.q.ans)+'</div>')+'</div>';
  }).join("");
  var mc=typeof mistCount==="function"?mistCount():0;
  return '<div class="panel qz"><h2>🏁 نتيجة الاختبار</h2>'+
    '<div class="card qz-score"><div class="qz-stars">'+stars+'</div><div class="qz-big">'+cor+' / '+n+'</div><div>'+pct+'% · '+msg+'</div><div class="mute">'+esc(R.cfgLabel)+' · ⭐ '+R.pts+' نقطة اتضافت</div></div>'+
    '<div class="row"><button onclick="Quiz.again()">🔄 اختبار تاني بنفس الإعدادات</button></div>'+
    '<div class="row"><button class="alt" onclick="Quiz.setup()">⚙️ إعدادات تانية</button>'+(mc?'<button class="alt" onclick="openReview()">🔁 راجع الغلطات ('+mc+')</button>':'')+'</div>'+
    '<div class="card" style="margin-top:12px"><h3>تفاصيل الأسئلة</h3>'+list+'</div>'+
    '<div class="row"><button class="alt" onclick="show(\'home\')">⬅️ رجوع</button></div></div>';
}

window.Quiz={loadAll:loadAll,kind:setKind,a:setA,b:setB,n:setN,type:toggleType,start:start,ok:function(){answer(false)},skip:function(){answer(true)},hint:hint,next:next,quit:quit,again:again,setup:newSetup,_s:function(){return {S:S,R:R,V:V}}};
window.openQuiz=function(){if(V!=="run")V="setup";render();show("quiz")};
render();

var css=document.createElement("style");
css.textContent=
".qz h3{margin:0 0 10px;color:#0f5f9e;font-size:17px;text-align:right}.qz .card{text-align:right}"+
".qz-chips{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:12px}.qz-chip{flex:1 1 auto;padding:10px 14px;font-size:15px}"+
".qz-two{display:grid;grid-template-columns:1fr 1fr;gap:10px}.qz-field label{display:block;font-size:13px;color:#3d77a3;margin-bottom:4px}.qz-field input,.qz-field select{font:16px sans-serif;padding:11px}"+
".qz-info{margin-top:12px;padding:8px 10px;border-radius:10px;background:rgba(31,134,214,.08);font-size:14px;text-align:center}"+
".qz-types{display:grid;gap:8px}.qz-type{display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:12px;background:rgba(31,134,214,.06);border:1px solid rgba(31,134,214,.2);cursor:pointer}.qz-type.on{background:rgba(42,157,244,.18);border-color:#2a9df4}.qz-type input{width:20px;height:20px;flex:none;margin:0}.qz-type span{font-size:15px}"+
".qz-prog{height:8px;border-radius:99px;background:rgba(31,134,214,.15);overflow:hidden;margin-bottom:8px}.qz-prog i{display:block;height:100%;background:linear-gradient(90deg,#5cbcf8,#1f86d6);transition:width .4s}"+
".qz-tag{display:inline-block;padding:3px 12px;border-radius:99px;background:rgba(31,134,214,.12);font-size:13px;font-weight:700;margin-bottom:6px}"+
".qz-ayah{font:600 24px/2.1 'Amiri','Traditional Arabic','Scheherazade New',serif;text-align:center;color:#0b3a5e;margin:6px 0}.qz-lab{text-align:center;font-size:13px;color:#3d77a3}.qz-dots{text-align:center;color:#3d77a3;font-size:22px}"+
".qz-ask{text-align:center;font-weight:700;margin:8px 0 10px;color:#0f5f9e}.qz textarea{min-height:90px;font:19px/1.9 'Amiri',serif}.qz input{font:20px 'Amiri',serif}"+
".qz-res{margin-top:12px;padding:12px;border-radius:12px;text-align:center}.qz-res.good{background:rgba(27,158,99,.14);color:#0d6b42}.qz-res.bad{background:rgba(214,69,69,.12);color:#9b2c2c}.qz-ans{margin-top:6px;font:600 20px/2 'Amiri',serif;color:#0b3a5e}"+
".qz-score{text-align:center!important}.qz-stars{font-size:38px}.qz-big{font-size:44px;font-weight:800;color:#0f5f9e}"+
".qz-li{padding:10px;border-radius:10px;margin-bottom:8px;border:1px solid rgba(31,134,214,.15)}.qz-li.good{background:rgba(27,158,99,.08)}.qz-li.bad{background:rgba(214,69,69,.07)}.qz-q{font:17px/1.9 'Amiri',serif;color:#0b3a5e}.qz-a{font:600 17px/1.9 'Amiri',serif;color:#9b2c2c}";
document.head.appendChild(css);
})();
