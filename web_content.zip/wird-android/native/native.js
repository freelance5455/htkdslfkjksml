/* وِرْد - طبقة التطبيق الأصلي (Capacitor / أندرويد)
   بتشتغل بس جوه التطبيق. في المتصفح العادي مبتعملش أي حاجة.
   بتتحزّم بـ esbuild في www/native.bundle.js (شوف scripts/prepare-web.mjs) */
import * as Core from "@capacitor/core";
import { App } from "@capacitor/app";
import { LocalNotifications } from "@capacitor/local-notifications";
import { PushNotifications } from "@capacitor/push-notifications";
import { Share } from "@capacitor/share";
import { Filesystem, Directory } from "@capacitor/filesystem";
import { BiometricAuth } from "@aparajita/capacitor-biometric-auth";

const Cap = Core.Capacitor;
if (Cap && Cap.isNativePlatform && Cap.isNativePlatform()) boot();

function boot() {
  const CFG = window.NATIVE_CFG || {};
  const CH = "wird_reminders", CH_PUSH = "wird_push", ICON = "ic_stat_wird";
  const DAYS = 3, DMAX = 60, CAP = 400;
  const $ = id => document.getElementById(id);
  const pad = n => String(n).padStart(2, "0");
  const dk = d => d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate());
  const tmin = s => { const a = String(s || "0:0").split(":"); return (+a[0] || 0) * 60 + (+a[1] || 0); };
  const ls = (k, v) => { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) {} return null; };
  const warn = e => { try { console.warn("[native]", e); } catch (_) {} };

  document.documentElement.classList.add("native");

  /* ---- مفيش Service Worker ولا Web Push جوه التطبيق (الإشعارات أصلية) ---- */
  try { delete window.PushManager; } catch (e) {}

  /* ---- شريط الحالة ---- */
  try { if (Core.SystemBars) Core.SystemBars.setStyle({ style: (Core.SystemBarsStyle && Core.SystemBarsStyle.Dark) || "DARK" }); } catch (e) { warn(e); }

  /* ---- إذن الإشعارات: نعمل Notification بديل عشان كود الموقع (notif.js) يشتغل زي ما هو ---- */
  let permState = "default";
  const mapPerm = v => (v === "granted" ? "granted" : v === "denied" ? "denied" : "default");
  function NotificationShim() {}
  Object.defineProperty(NotificationShim, "permission", { get: () => permState });
  NotificationShim.requestPermission = function (cb) {
    return (async () => {
      try { permState = mapPerm((await LocalNotifications.requestPermissions()).display); } catch (e) { warn(e); }
      await afterPerm();
      if (typeof cb === "function") { try { cb(permState); } catch (e) {} }
      return permState;
    })();
  };
  window.Notification = NotificationShim;

  /* ---- المستخدم الحالي (الاسم والنوع) من متغيرات الموقع ---- */
  function user() {
    try {
      const u = typeof uid !== "undefined" ? uid : "";
      const p = typeof prof !== "undefined" ? prof : null;
      if (!u || !p || (p.gender !== "m" && p.gender !== "f")) return null;
      return { uid: u, name: p.name || "", f: p.gender === "f" };
    } catch (e) { return null; }
  }
  function cfg() {
    let c = {}; try { c = JSON.parse(ls("q_notif_cfg")) || {}; } catch (e) {}
    const on = Object.assign({ m: 1, e: 1, w: 1, d: 1, pb: 1, pm: 1 }, c.on || {});
    const iv = [5, 10, 15, 30].reduce((p, x) => Math.abs(x - (+c.iv || 10)) < Math.abs(p - (+c.iv || 10)) ? x : p, 10);
    return { on, tm: c.tm || "06:00", te: c.te || "17:00", tw: c.tw || "21:00", iv, qs: c.qs || "23:00", qe: c.qe || "05:00",
      rc: Math.min(3, Math.max(1, +c.rc || 1)), rg: Math.max(5, +c.rg || 30), pr: Math.max(5, +c.pr || 30) };
  }
  const quiet = (m, C) => { const s = tmin(C.qs), e = tmin(C.qe); if (s === e) return false; return s > e ? (m >= s || m < e) : (m >= s && m < e); };

  /* ---- نصوص الإشعارات (نفس صيغة الموقع: مذكر/مؤنث + "يا فلان") ---- */
  const DHIKR = ["سُبْحَانَ اللَّهِ وَبِحَمْدِهِ، سُبْحَانَ اللَّهِ الْعَظِيمِ", "لَا إِلَٰهَ إِلَّا اللَّهُ", "أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ", "اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَىٰ نَبِيِّنَا مُحَمَّدٍ", "لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ", "الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ"];
  const EMO = ["🤍", "🌿", "📿", "✨", "🌙", "☀️"];
  const pick = a => a[Math.floor(Math.random() * a.length)];
  const MSG = {
    m: U => ({ t: "صباح الخير" + ya(U) + " ☀️", b: U.f ? "وقت أذكار الصباح 📿 دوسي وابدأي يومك بذكر الله" : "وقت أذكار الصباح 📿 دوس وابدأ يومك بذكر الله" }),
    e: U => ({ t: "مساء الخير" + ya(U) + " 🌙", b: U.f ? "وقت أذكار المساء 📿 دوسي واختمي يومك بذكر الله" : "وقت أذكار المساء 📿 دوس واختم يومك بذكر الله" }),
    w: U => ({ t: "وردك النهاردة" + ya(U) + " 📖", b: U.f ? "لسه ما سجلتيش ورد النهاردة، ولو صفحة واحدة 🤍" : "لسه ما سجلتش ورد النهاردة، ولو صفحة واحدة 🤍" }),
    d: U => ({ t: (U.f ? "اذكري ربنا" : "اذكر ربنا") + ya(U) + " " + pick(EMO), b: pick(DHIKR) }),
    pb: (U, n) => ({ t: `صلاة ${n} بعد 5 دقايق 🕌`, b: (U.f ? "جهّزي نفسك واتوضّي" : "جهّز نفسك واتوضّى") + ya(U) }),
    pm: (U, n) => ({ t: (U.f ? `قومي صلي ${n}` : `قوم صلي ${n}`) + ya(U) + " 🕌", b: U.f ? "وقتها جه ولسه ما علّمتيش إنك صليتيها" : "وقتها جه ولسه ما علّمتش إنك صليتها" }),
    pj: (U, n, pn) => ({ t: `صلاة ${n} أذّنت${ya(U)} ${U.f ? "وإنتي لسه مصلّيتيش" : "وإنت لسه مصلّيتش"} ${pn} 🙆🏻⚠️`, b: (U.f ? "إنتي هتجمعي صلاتين!!!" : "إنت هتجمع صلاتين!!!") + " 😔😳🤦🏻🙀" })
  };
  const ya = U => (U.name ? " يا " + U.name : "");

  /* ---- حالة "خلّصت" (أذكار/ورد/صلاة) من كود الموقع ---- */
  function isDone(x) {
    try {
      if (x === "m" || x === "e") return !!(window.Adhkar && Adhkar.done(x));
      if (x === "w" && window.Wird) { const s = Wird._state(), k = dk(new Date()); return ((s.days || {})[k] > 0) || ((s.r && s.r.days || {})[k] > 0); }
    } catch (e) {}
    return false;
  }

  /* ---- جدولة إشعارات محلية لـ 3 أيام قدّام (بتشتغل والتطبيق مقفول ومن غير سيرفر/نت) ---- */
  function plan(now) {
    const U = user(); if (!U) return null;
    const C = cfg(), P = window.Prayer, out = [];
    const add = (t, m, go, tag) => { if (t > now + 5000) out.push({ t, title: m.t, body: m.b, go, tag }); };
    const base = new Date();
    for (let off = 0; off < DAYS; off++) {
      const d = new Date(base.getFullYear(), base.getMonth(), base.getDate() + off), k = dk(d), today = off === 0;
      const at = min => new Date(d.getFullYear(), d.getMonth(), d.getDate(), 0, min).getTime();
      [["m", "tm", "m"], ["e", "te", "e"], ["w", "tw", "home"]].forEach(([x, kk, go]) => {
        if (!C.on[x] || (today && isDone(x))) return;
        for (let i = 0; i < C.rc; i++) {
          const m = MSG[x](U); if (i) m.t += " 🔁";
          add(at(tmin(C[kk]) + i * C.rg), m, go, "wird-" + x);
        }
      });
      if (P && P.times && P.LIST && (C.on.pb || C.on.pm)) {
        let T = null; try { T = P.times(d); } catch (e) {}
        if (T && isFinite(T.fajr)) {
          const mid = new Date(d.getFullYear(), d.getMonth(), d.getDate() + 1).getTime();
          const END = { fajr: T.sunrise, dhuhr: T.asr, asr: T.maghrib, maghrib: T.isha, isha: mid }, gap = C.pr * 60000;
          P.LIST.forEach((pp, ix) => {
            const id = pp[0], n = P.name(id), t = T[id];
            if (!isFinite(t) || (today && P.done(k, id))) return;
            if (C.on.pm && today && ix > 0) { const pv = P.LIST[ix - 1][0]; if (!P.done(k, pv)) add(t, MSG.pj(U, n, P.name(pv)), "pray", "wird-pj-" + id); }
            if (C.on.pb) add(t - 5 * 60000, MSG.pb(U, n), "pray", "wird-pb-" + id);
            if (C.on.pm) for (let i = 0; i < 3; i++) {
              const s = t + 15 * 60000 + i * gap;
              if (s < Math.min(t + 3 * 3600000, END[id])) add(s, MSG.pm(U, n), "pray", "wird-pm-" + id);
            }
          });
        }
      }
    }
    if (C.on.d) {
      const iv = C.iv * 60000, lim = now + 24 * 3600000; let t = Math.ceil((now + 60000) / iv) * iv, n = 0;
      for (; t < lim && n < DMAX; t += iv) {
        const dt = new Date(t);
        if (!quiet(dt.getHours() * 60 + dt.getMinutes(), C)) { add(t, MSG.d(U), "dhikr", "wird-d"); n++; }
      }
    }
    out.sort((a, b) => a.t - b.t);
    return out.slice(0, CAP);
  }

  let busy = false, lastSig = "";
  async function schedule() {
    if (busy) return; busy = true;
    try {
      const pend = await LocalNotifications.getPending();
      if (pend.notifications && pend.notifications.length) await LocalNotifications.cancel({ notifications: pend.notifications.map(n => ({ id: n.id })) });
      if (permState !== "granted") return;
      const list = plan(Date.now());
      if (list && list.length) {
        await LocalNotifications.schedule({ notifications: list.map((x, i) => ({
          id: 1000 + i, title: x.title, body: x.body, channelId: CH, smallIcon: ICON, iconColor: "#d4a95a",
          schedule: { at: new Date(x.t), allowWhileIdle: true }, extra: { go: x.go }
        })) });
      }
    } catch (e) { warn(e); } finally { busy = false; }
  }
  /* بصمة الحالة: لو أي حاجة اتغيّرت (إعدادات/اسم/صلاة اتعلّمت/مواعيد) نعيد الجدولة */
  function sig() {
    const U = user(); if (!U) return "nouser";
    const P = window.Prayer, d = new Date(), k = dk(d); let T = {}; const pd = {};
    try { T = (P && P.times && P.times(d)) || {}; P && P.LIST && P.LIST.forEach(p => { pd[p[0]] = P.done(k, p[0]) ? 1 : 0; }); } catch (e) {}
    return JSON.stringify([cfg(), U, k, pd, isDone("m"), isDone("e"), isDone("w"), T.fajr, T.dhuhr, T.isha, Math.floor(Date.now() / (6 * 3600000)), permState]);
  }
  function check(force) {
    if (permState === "unsupported") return;
    const s = sig();
    if (force || s !== lastSig) { lastSig = s; schedule(); syncFcm(); }
  }

  /* ---- إذن المنبّهات الدقيقة (أندرويد 12+) ---- */
  async function exactAlarm() {
    try {
      if (Cap.getPlatform() !== "android" || !LocalNotifications.checkExactNotificationSetting) return;
      const r = await LocalNotifications.checkExactNotificationSetting();
      if (r.exact_alarm === "granted" || ls("q_exact_asked")) return;
      ls("q_exact_asked", "1");
      if (confirm("عشان الأذكار ومواعيد الصلاة توصلك في ميعادها بالظبط، اسمح لوِرْد بـ «المنبّهات والتذكيرات» في الصفحة اللي هتفتح.")) await LocalNotifications.changeExactNotificationSetting();
    } catch (e) { warn(e); }
  }

  /* ---- FCM: رسائل المطوّر (بث) من سيرفر الإشعارات ---- */
  let fcmToken = ls("q_fcm") || "", fcmSent = "";
  async function initPush() {
    if (!CFG.fcm) return;
    try {
      PushNotifications.addListener("registration", t => { fcmToken = t.value; ls("q_fcm", fcmToken); fcmSent = ""; syncFcm(); });
      PushNotifications.addListener("registrationError", warn);
      PushNotifications.addListener("pushNotificationReceived", n => showNow(n.title, n.body, (n.data || {}).go));
      PushNotifications.addListener("pushNotificationActionPerformed", a => openGo(((a.notification || {}).data || {}).go));
      const p = await PushNotifications.checkPermissions();
      if (p.receive === "granted") await PushNotifications.register();
    } catch (e) { warn(e); }
  }
  function syncFcm() {
    try {
      const U = user(); if (!U || !fcmToken || !window.PUSH_URL || permState !== "granted") return;
      const P = window.Prayer; let pr = null;
      try { pr = P && P.info ? P.info() : null; if (pr) { delete pr.lat; delete pr.lon; } } catch (e) {}
      const C = cfg(), d = new Date();
      const body = JSON.stringify({ fcm: fcmToken, uid: U.uid, name: U.name, g: U.f ? "f" : "m",
        tz: (Intl.DateTimeFormat().resolvedOptions().timeZone || "Africa/Cairo"), pr,
        cfg: { on: C.on, tm: C.tm, te: C.te, tw: C.tw, iv: C.iv, qs: C.qs, qe: C.qe, rc: C.rc, rg: C.rg, pr: C.pr },
        done: { d: dk(d), m: isDone("m") ? 1 : 0, e: isDone("e") ? 1 : 0, w: isDone("w") ? 1 : 0 } });
      if (body === fcmSent) return;
      fetch(window.PUSH_URL + "/subscribe-native", { method: "POST", headers: { "Content-Type": "application/json" }, body })
        .then(r => { if (r.ok) fcmSent = body; }).catch(warn);
    } catch (e) { warn(e); }
  }

  async function afterPerm() {
    if (permState === "granted") { await exactAlarm(); await initPush(); }
    check(true);
    try { document.dispatchEvent(new Event("visibilitychange")); } catch (e) {}   // الموقع يحدّث شكل زرار الإشعارات
  }

  /* ---- عرض إشعار فوري (اختبار / رسالة مطوّر وانت فاتح التطبيق) ---- */
  async function showNow(title, body, go) {
    try {
      await LocalNotifications.schedule({ notifications: [{ id: 100000 + Math.floor(Math.random() * 1.9e9), title: title || "وِرْد", body: body || "",
        channelId: CH_PUSH, smallIcon: ICON, iconColor: "#d4a95a", extra: { go: go || "home" } }] });
    } catch (e) { warn(e); }
  }
  function openGo(go) {
    if (!go) return; let n = 0;
    const t = setInterval(() => { if (window.Notif && Notif.go) { clearInterval(t); Notif.go(go); } else if (++n > 50) clearInterval(t); }, 300);
  }

  /* ---- واجهة بيستخدمها كود الموقع ---- */
  const NativeApp = window.NativeApp = {
    bioOk: false,
    fire(title, body, tag, go) {   // الجدولة بتتم أصليًا؛ هنا بس الاختبار وبث المطوّر
      if (/^wird-(test|bc)/.test(tag || "")) showNow(title, body, go);
    },
    async bioAsk() {
      await BiometricAuth.authenticate({ reason: "افتح وِرْد", cancelTitle: "إلغاء", allowDeviceCredential: true,
        androidTitle: "وِرْد", androidSubtitle: "أكّد هويتك لفتح التطبيق" });
    },
    async shareBlob(blob, name) {
      const b64 = await new Promise((res, rej) => { const f = new FileReader(); f.onload = () => res(String(f.result).split(",")[1]); f.onerror = rej; f.readAsDataURL(blob); });
      await Filesystem.writeFile({ path: name, data: b64, directory: Directory.Cache });
      const { uri } = await Filesystem.getUri({ path: name, directory: Directory.Cache });
      await Share.share({ title: "وِرْد", files: [uri], dialogTitle: "مشاركة" });
    },
    async unsub() {   // قبل مسح الحساب / تسجيل الخروج
      try {
        const u = typeof auth !== "undefined" && auth && auth.currentUser, tok = u ? await u.getIdToken() : "";
        if (tok && window.PUSH_URL) {
          await Promise.race([
            fetch(window.PUSH_URL + "/unsubscribe", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ token: tok, uid: typeof uid !== "undefined" ? uid : "" }) }).catch(() => {}),
            new Promise(r => setTimeout(r, 6000))
          ]);
        } else if (fcmToken && window.PUSH_URL) {
          await fetch(window.PUSH_URL + "/unsubscribe", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ fcm: fcmToken }) }).catch(() => {});
        }
      } catch (e) { warn(e); }
      try { const p = await LocalNotifications.getPending(); if (p.notifications.length) await LocalNotifications.cancel({ notifications: p.notifications.map(n => ({ id: n.id })) }); } catch (e) {}
      try { await PushNotifications.unregister(); } catch (e) {}
      fcmSent = ""; lastSig = "";
    },
    openStore() { location.href = "https://play.google.com/store/apps/details?id=" + (CFG.appId || ""); }
  };

  /* ---- زر الرجوع الصح ---- */
  let lastBack = 0;
  App.addListener("backButton", () => {
    try {
      const vis = e => e && getComputedStyle(e).display !== "none";
      const ov = ["pwm", "fpw", "prof", "upd"].map($).find(vis);
      if (ov) { const x = ov.querySelector(".xbtn"); if (x) x.click(); else ov.style.display = "none"; return; }
      if (vis($("gate")) || document.documentElement.classList.contains("hb")) { App.minimizeApp(); return; }
      const v = typeof cur_v !== "undefined" ? cur_v : "home";
      if (v === "reader") { show("mushaf"); return; }
      if (v !== "home") { show("home"); return; }
      const now = Date.now();
      if (now - lastBack < 2000) { App.exitApp(); return; }
      lastBack = now; if (typeof toast === "function") toast("اضغط رجوع مرة تانية للخروج");
    } catch (e) { warn(e); App.exitApp(); }
  });

  /* ---- ضغط الإشعار ---- */
  LocalNotifications.addListener("localNotificationActionPerformed", a => openGo(a.notification && a.notification.extra && a.notification.extra.go));

  /* ---- التشغيل ---- */
  (async function start() {
    try {
      await LocalNotifications.createChannel({ id: CH, name: "تذكيرات الأذكار والصلاة", description: "الأذكار والورد ومواعيد الصلاة", importance: 4, visibility: 1, vibration: true });
      await LocalNotifications.createChannel({ id: CH_PUSH, name: "رسائل وِرْد", description: "رسائل من المطوّر وإشعارات فورية", importance: 4, visibility: 1, vibration: true });
    } catch (e) { warn(e); }
    try { permState = mapPerm((await LocalNotifications.checkPermissions()).display); } catch (e) { warn(e); }
    try { const i = await BiometricAuth.checkBiometry(); NativeApp.bioOk = !!(i.isAvailable || i.deviceIsSecure); } catch (e) {}
    if (permState === "granted") { await initPush(); }
    try { document.dispatchEvent(new Event("visibilitychange")); } catch (e) {}
    setTimeout(() => check(true), 3000);
    setInterval(() => check(false), 20000);
  })();
  App.addListener("appStateChange", s => { if (s.isActive) setTimeout(() => check(true), 800); });
}
