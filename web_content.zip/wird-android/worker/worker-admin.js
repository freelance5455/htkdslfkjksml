// وِرْد - ورکر الأدمن (Cloudflare Worker): مسح مستخدم من Firebase Auth + Firestore + اشتراكات الإشعارات
// Secrets: SA_JSON (مفتاح الـ Service Account) | اختياري: ADMIN_EMAILS, FIREBASE_API_KEY, PUSH_URL, ALLOWED_ORIGIN
const PROJECT_ID = "werd-3095f", WEB_API_KEY = "AIzaSyC7_NW4GCrc3cbQM3B15EpoFPe2deGSILY", ADMINS = ["lovefreedme88@gmail.com"], PUSH = "https://wird-push.lovefreedme88.workers.dev";
const cors = env => {
  const list = String(env.ALLOWED_ORIGIN || "*").split(",").map(s => s.trim()).filter(Boolean);
  let allow = "*";
  if (!list.includes("*")) { list.push("https://localhost"); allow = list.includes(env.__o) ? env.__o : list[0]; }   // https://localhost = تطبيق أندرويد
  return { "access-control-allow-origin": allow, vary: "Origin", "access-control-allow-headers": "content-type", "access-control-allow-methods": "POST,OPTIONS", "access-control-max-age": "86400" };
};
const J = (env, o, s = 200) => new Response(JSON.stringify(o), { status: s, headers: { ...cors(env), "content-type": "application/json" } });
const b64u = b => btoa(String.fromCharCode(...new Uint8Array(b))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
const enc = s => b64u(new TextEncoder().encode(s));
async function accessToken(env) {
  const sa = JSON.parse(env.SA_JSON);
  const now = Math.floor(Date.now() / 1000), h = enc(JSON.stringify({ alg: "RS256", typ: "JWT" })),
    c = enc(JSON.stringify({ iss: sa.client_email, scope: "https://www.googleapis.com/auth/cloud-platform", aud: "https://oauth2.googleapis.com/token", iat: now, exp: now + 3000 })),
    pem = sa.private_key.replace(/\\n/g, "\n").replace(/-----[^-]+-----/g, "").replace(/\s+/g, ""),
    key = await crypto.subtle.importKey("pkcs8", Uint8Array.from(atob(pem), x => x.charCodeAt(0)), { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["sign"]),
    sig = b64u(await crypto.subtle.sign("RSASSA-PKCS1-v1_5", key, new TextEncoder().encode(h + "." + c))),
    r = await fetch("https://oauth2.googleapis.com/token", { method: "POST", headers: { "content-type": "application/x-www-form-urlencoded" }, body: "grant_type=urn:ietf:params:oauth:grant-type:jwt-bearer&assertion=" + h + "." + c + "." + sig }),
    j = await r.json();
  if (!j.access_token) throw new Error("token: " + (j.error_description || j.error));
  return j.access_token;
}
/* بيتأكد من توكن الأدمن ويرجّع إيميله (أو فاضي لو التوكن غلط) */
async function emailOf(env, idToken) {
  try {
    const r = await fetch("https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=" + (env.FIREBASE_API_KEY || WEB_API_KEY), { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ idToken }) });
    if (!r.ok) return "";
    const u = ((await r.json()).users || [])[0];
    return String((u && u.email) || "").toLowerCase();
  } catch (e) { return ""; }
}
export default {
  async fetch(req, env0) {
    const o = req.headers.get("Origin") || "", env = new Proxy(env0, { get: (t, k) => (k === "__o" ? o : t[k]) });
    if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: cors(env) });
    const url = new URL(req.url);
    if (url.pathname !== "/delete-user" || req.method !== "POST") return J(env, { ok: false, error: "not found" }, 404);
    try {
      let body; try { body = await req.json(); } catch (e) { return J(env, { ok: false, error: "bad json" }, 400); }
      const { idToken, uid } = body || {};
      if (typeof idToken !== "string" || typeof uid !== "string" || !idToken || !uid) return J(env, { ok: false, error: "missing idToken/uid" }, 400);
      const mail = await emailOf(env, idToken), adm = (env.ADMIN_EMAILS ? env.ADMIN_EMAILS.split(",") : ADMINS).map(s => s.trim().toLowerCase()).filter(Boolean);
      if (!mail || !adm.includes(mail)) return J(env, { ok: false, error: "not admin" }, 403);
      const tk = await accessToken(env), P = PROJECT_ID, H = { authorization: "Bearer " + tk, "content-type": "application/json" };
      const a = await fetch("https://identitytoolkit.googleapis.com/v1/projects/" + P + "/accounts:delete", { method: "POST", headers: H, body: JSON.stringify({ localId: uid }) }), aj = await a.json().catch(() => ({}));
      const authOk = a.ok || /USER_NOT_FOUND/.test(JSON.stringify(aj));
      const d = await fetch("https://firestore.googleapis.com/v1/projects/" + P + "/databases/(default)/documents/users/" + encodeURIComponent(uid), { method: "DELETE", headers: H });
      const docOk = d.ok || d.status === 404;
      /* مسح اشتراكات الإشعارات بتاعته من سيرفر الإشعارات (لو فشل مبيأثرش على نتيجة المسح) */
      let push = false;
      try { const p = await fetch((env.PUSH_URL || PUSH) + "/unsubscribe", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ token: idToken, uid }) }); push = p.ok; } catch (e) {}
      if (!authOk) return J(env, { ok: false, error: "auth delete failed: " + JSON.stringify(aj) }, 502);
      return J(env, { ok: docOk, auth: true, doc: docOk, push, error: docOk ? undefined : "firestore HTTP " + d.status });
    } catch (e) { return J(env, { ok: false, error: String((e && e.message) || e) }, 500); }
  }
};
