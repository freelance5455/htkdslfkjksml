// وِرْد - سيرفر الإشعارات (Cloudflare Worker + D1 + Cron) - ملف واحد، من غير مكتبات
// Bindings لازم تتضبط: DB (قاعدة D1) | Secrets: VAPID_PRIVATE_JWK و VAPID_SUBJECT | اختياري: ALLOWED_ORIGIN, ADMIN_EMAILS, FIREBASE_API_KEY
// Cron Trigger: */5 * * * *   (كل 5 دقايق)
// المسارات: POST /subscribe (افتراضي) | POST /subscribe-native (أندرويد FCM) | POST /unsubscribe | POST /resubscribe | POST /broadcast | GET /?db=1 (فحص القاعدة)
// FCM لأندرويد: ضيف Secret اسمه SA_JSON (مفتاح Service Account بتاع Firebase، نفس اللي في quran-admin)
// الصيغة: كل الإشعارات بتنادي المستخدم بـ "يا + الاسم" والصيغة (مذكر/مؤنث) حسب النوع، والنوع إجباري.
const enc = new TextEncoder();
const b64u = {
  enc: b => btoa(String.fromCharCode(...new Uint8Array(b))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, ""),
  dec: s => Uint8Array.from(atob(s.replace(/-/g, "+").replace(/_/g, "/").padEnd(Math.ceil(s.length / 4) * 4, "=")), c => c.charCodeAt(0)),
};
const cat = (...a) => { const o = new Uint8Array(a.reduce((n, x) => n + x.length, 0)); let i = 0; a.forEach(x => { o.set(x, i); i += x.length; }); return o; };
const sleep = ms => new Promise(r => setTimeout(r, ms));

/* ---------- تشفير Web Push (RFC 8291 / aes128gcm) ---------- */
async function hkdf(salt, ikm, info, len) {
  const k = await crypto.subtle.importKey("raw", ikm, "HKDF", false, ["deriveBits"]);
  return new Uint8Array(await crypto.subtle.deriveBits({ name: "HKDF", hash: "SHA-256", salt, info }, k, len * 8));
}
async function encrypt(text, sub) {
  const uaPub = b64u.dec(sub.keys.p256dh), auth = b64u.dec(sub.keys.auth);
  const as = await crypto.subtle.generateKey({ name: "ECDH", namedCurve: "P-256" }, true, ["deriveBits"]);
  const asPub = new Uint8Array(await crypto.subtle.exportKey("raw", as.publicKey));
  const uaKey = await crypto.subtle.importKey("raw", uaPub, { name: "ECDH", namedCurve: "P-256" }, false, []);
  const ecdh = new Uint8Array(await crypto.subtle.deriveBits({ name: "ECDH", public: uaKey }, as.privateKey, 256));
  const ikm = await hkdf(auth, ecdh, cat(enc.encode("WebPush: info\0"), uaPub, asPub), 32);
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const cek = await hkdf(salt, ikm, enc.encode("Content-Encoding: aes128gcm\0"), 16);
  const nonce = await hkdf(salt, ikm, enc.encode("Content-Encoding: nonce\0"), 12);
  const key = await crypto.subtle.importKey("raw", cek, "AES-GCM", false, ["encrypt"]);
  const data = await crypto.subtle.encrypt({ name: "AES-GCM", iv: nonce }, key, cat(enc.encode(text), new Uint8Array([2])));
  return cat(salt, new Uint8Array([0, 0, 16, 0, 65]), asPub, new Uint8Array(data));
}

/* ---------- VAPID ---------- */
let signKey, pubRaw;
async function vapid(env, endpoint) {
  if (!signKey) {
    const jwk = JSON.parse(env.VAPID_PRIVATE_JWK);
    signKey = await crypto.subtle.importKey("jwk", jwk, { name: "ECDSA", namedCurve: "P-256" }, false, ["sign"]);
    pubRaw = b64u.enc(cat(new Uint8Array([4]), b64u.dec(jwk.x), b64u.dec(jwk.y)));
  }
  const h = b64u.enc(enc.encode(JSON.stringify({ typ: "JWT", alg: "ES256" })));
  const c = b64u.enc(enc.encode(JSON.stringify({ aud: new URL(endpoint).origin, exp: Math.floor(Date.now() / 1000) + 43200, sub: env.VAPID_SUBJECT || "mailto:admin@example.com" })));
  const sig = await crypto.subtle.sign({ name: "ECDSA", hash: "SHA-256" }, signKey, enc.encode(h + "." + c));
  return `vapid t=${h}.${c}.${b64u.enc(sig)}, k=${pubRaw}`;
}

/* ---------- الرسائل (نفس صيغة التطبيق: "يا + الاسم"، والمذكر/المؤنث حسب النوع) ---------- */
const DHIKR = ["سُبْحَانَ اللَّهِ وَبِحَمْدِهِ، سُبْحَانَ اللَّهِ الْعَظِيمِ", "لَا إِلَٰهَ إِلَّا اللَّهُ", "أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ", "اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَىٰ نَبِيِّنَا مُحَمَّدٍ", "لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ", "الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ"];
const EMO = ["🤍", "🌿", "📿", "✨", "🌙", "☀️"];
const PRAYERS = [["fajr", "الفجر"], ["dhuhr", "الظهر"], ["asr", "العصر"], ["maghrib", "المغرب"], ["isha", "العشاء"]];
const pick = a => a[Math.floor(Math.random() * a.length)];
const isF = row => row.g === "f";
/* " يا أحمد" - بتتحط بعد الكلام، ولو مفيش اسم بترجع فاضية */
const ya = row => row.name ? " يا " + row.name : "";
function msgs(row) {
  const f = isF(row), G = (m, x) => f ? x : m, nm = ya(row);
  return {
    m: { t: "صباح الخير" + nm + " ☀️", b: G("وقت أذكار الصباح 📿 دوس وابدأ يومك بذكر الله", "وقت أذكار الصباح 📿 دوسي وابدأي يومك بذكر الله"), tag: "wird-m", go: "m", ttl: 3600 },
    e: { t: "مساء الخير" + nm + " 🌙", b: G("وقت أذكار المساء 📿 دوس واختم يومك بذكر الله", "وقت أذكار المساء 📿 دوسي واختمي يومك بذكر الله"), tag: "wird-e", go: "e", ttl: 3600 },
    w: { t: "وردك النهاردة" + nm + " 📖", b: G("لسه ما سجلتش ورد النهاردة، ولو صفحة واحدة 🤍", "لسه ما سجلتيش ورد النهاردة، ولو صفحة واحدة 🤍"), tag: "wird-w", go: "home", ttl: 3600 },
    d: { t: G("اذكر ربنا", "اذكري ربنا") + nm + " " + pick(EMO), b: pick(DHIKR), tag: "wird-d", go: "dhikr", ttl: 300 },
  };
}
function prayMsg(row, kind, id, n) {
  const f = isF(row), G = (m, x) => f ? x : m, nm = ya(row);
  if (kind === "pb") return { t: `صلاة ${n} بعد 5 دقايق 🕌`, b: G("جهّز نفسك واتوضّى", "جهّزي نفسك واتوضّي") + nm, tag: "wird-pb-" + id, go: "pray", ttl: 300 };
  return { t: G(`قوم صلي ${n}`, `قومي صلي ${n}`) + nm + " 🕌", b: G("وقتها جه ولسه ما علّمتش إنك صليتها", "وقتها جه ولسه ما علّمتيش إنك صليتيها"), tag: "wird-pm-" + id, go: "pray", ttl: 900 };
}
function jamMsg(row, id, n, pn) {
  const f = isF(row);
  return { t: `صلاة ${n} أذّنت${ya(row)} ${f ? "وإنتي لسه مصلّيتيش" : "وإنت لسه مصلّيتش"} ${pn} 🙆🏻⚠️`, b: (f ? "إنتي هتجمعي صلاتين!!!" : "إنت هتجمع صلاتين!!!") + " 😔😳🤦🏻🙀", tag: "wird-pj-" + id, go: "pray", ttl: 900 };
}
const tmin = s => { const a = String(s || "0:0").split(":"); return (+a[0] || 0) * 60 + (+a[1] || 0); };
function localOf(tz, ms) {
  try {
    const p = Object.fromEntries(new Intl.DateTimeFormat("en-GB", { timeZone: tz, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).formatToParts(new Date(ms)).map(x => [x.type, x.value]));
    return { d: `${p.year}-${p.month}-${p.day}`, m: +p.hour * 60 + +p.minute };
  } catch (e) { return localOf("Africa/Cairo", ms); }
}
const quiet = (m, s, e) => { s = tmin(s); e = tmin(e); return s === e ? false : s > e ? (m >= s || m < e) : (m >= s && m < e); };

/* الـ cron بيشتغل كل 5 دقايق، فأي فترة لازم تكون من مضاعفات الـ 5 وإلا عمرها ما هتتنفّذ */
const IV_OK = [5, 10, 15, 30];                 // تكرار "اذكر ربنا" المسموح
const snapIv = v => { v = +v; if (!isFinite(v) || v <= 0) return 10; return IV_OK.reduce((a, b) => Math.abs(b - v) < Math.abs(a - v) ? b : a); };
const snapPr = v => { v = +v; if (!isFinite(v) || v <= 0) return 30; return Math.min(120, Math.max(15, Math.round(v / 5) * 5)); };

/* إشعارات الصلاة: قبل الأذان بـ 5 دقايق، وبعد الأذان بـ 15 دقيقة "قوم صلي" (3 مرات بالكتير) لو لسه ما اتعلّمتش */
function prayDue(row, L, on, cfg) {
  let pr = {}; try { pr = JSON.parse(row.pr) || {}; } catch (e) {}
  const T = pr.t || {}, pd = pr.done || {}, out = [];
  if (!T.fajr || (!on.pb && !on.pm)) return out;
  const fresh = pd.d === L.d, gap = snapPr(cfg.pr),
        end = { fajr: tmin(T.sunrise || "06:00"), dhuhr: tmin(T.asr), asr: tmin(T.maghrib), maghrib: tmin(T.isha), isha: 1440 };
  PRAYERS.forEach(([id, n], ix) => {
    if (!T[id] || (fresh && pd[id])) return;
    const t = tmin(T[id]);
    /* أذّنت صلاة وإنت لسه مصلّتش اللي قبلها: "هتجمع صلاتين!" */
    if (on.pm && ix > 0) { const pv = PRAYERS[ix - 1]; if (T[pv[0]] && !(fresh && pd[pv[0]]) && L.m >= t && L.m < t + 5) out.push(jamMsg(row, id, n, pv[1])); }
    if (on.pb && L.m >= t - 5 && L.m < t) out.push(prayMsg(row, "pb", id, n));
    if (on.pm) for (let i = 0; i < 3; i++) {
      const s = t + 15 + i * gap;
      if (s < Math.min(t + 180, end[id]) && L.m >= s && L.m < s + 5 && L.m < end[id]) { out.push(prayMsg(row, "pm", id, n)); break; }
    }
  });
  return out;
}
/* بيرجّع الإشعارات المستحقة لمستخدم في لحظة معيّنة (الـ cron بيشتغل كل 5 دقايق فكل ميعاد بيقع في نافذة واحدة بس) */
function due(row, ms) {
  let cfg = {}, done = {};
  try { cfg = JSON.parse(row.cfg) || {}; done = JSON.parse(row.done) || {}; } catch (e) {}
  const on = cfg.on || {}, L = localOf(row.tz, ms), M = msgs(row), out = [];
  [["m", "tm", "06:00"], ["e", "te", "17:00"], ["w", "tw", "21:00"]].forEach(([x, k, def]) => {
    const t = tmin(cfg[k] || def);
    if (on[x] && L.m >= t && L.m < t + 5 && !(done.d === L.d && done[x])) out.push(M[x]);
  });
  const iv = snapIv(cfg.iv);
  if (on.d && !quiet(L.m, cfg.qs || "23:00", cfg.qe || "05:00") && Math.floor(ms / 60000) % iv === 0) out.push(M.d);
  return out.concat(prayDue(row, L, on, cfg));
}

/* ---------- بث من المطوّر ---------- */
const clean = (x, n) => String(x == null ? "" : x).slice(0, n);
function cleanMsg(m) {
  if (!m || !m.t || !m.b) return null;
  const o = { t: { m: clean(m.t.m, 120), f: clean(m.t.f || m.t.m, 120) }, b: { m: clean(m.b.m, 300), f: clean(m.b.f || m.b.m, 300) }, s: clean(m.s, 10), n: m.n ? 1 : 0, tag: clean(m.tag || "wird-bc", 60), go: clean(m.go || "home", 20) };
  return o.t.m && o.b.m ? o : null;
}
function fromBroadcast(msg, row) {
  const k = isF(row) ? "f" : "m", nm = ya(row);
  return { t: msg.t[k] + (msg.n ? nm : "") + (msg.s || ""), b: msg.b[k] + (msg.n ? "" : nm), tag: msg.tag, go: msg.go, ttl: 1800 };
}
/* بيتأكد من توكن Firebase ويرجّع صاحبه {uid, email} أو null */
async function verifyToken(env, idToken) {
  if (typeof idToken !== "string" || idToken.length < 50 || idToken.length > 4000) return null;
  try {
    const r = await fetch("https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=" + (env.FIREBASE_API_KEY || "AIzaSyC7_NW4GCrc3cbQM3B15EpoFPe2deGSILY"), { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ idToken }) });
    if (!r.ok) return null;
    const u = ((await r.json()).users || [])[0];
    return u && u.localId ? { uid: String(u.localId), email: String(u.email || "").toLowerCase() } : null;
  } catch (e) { return null; }
}
const adminList = env => (env.ADMIN_EMAILS || "lovefreedme88@gmail.com").toLowerCase().split(",").map(s => s.trim()).filter(Boolean);
async function isAdmin(env, idToken) { const w = await verifyToken(env, idToken); return !!w && adminList(env).includes(w.email); }

/* ---------- قاعدة البيانات والإرسال ---------- */
const DAY = 86400000;
const STALE = 14 * DAY;    // اللي مفتحش التطبيق من 14 يوم: بنوقّف عنه الإشعارات
const PURGE = 60 * DAY;    // واللي غايب 60 يوم: بنمسحه من القاعدة
const SCHEMA = "CREATE TABLE IF NOT EXISTS subs(endpoint TEXT PRIMARY KEY,p256dh TEXT,auth TEXT,uid TEXT,name TEXT,g TEXT,tz TEXT,cfg TEXT,done TEXT,u INTEGER)";
const BCQ = "CREATE TABLE IF NOT EXISTS bcq(endpoint TEXT PRIMARY KEY,msg TEXT,ts INTEGER)";
const OUTQ = "CREATE TABLE IF NOT EXISTS outq(id INTEGER PRIMARY KEY AUTOINCREMENT,endpoint TEXT,msg TEXT,exp INTEGER,tries INTEGER DEFAULT 0)";   // إشعارات فشلت بسبب 429/5xx وهتتعاد
let ready = false;
async function ensure(env) {
  if (ready) return;
  if (!env.DB) throw new Error("الـ binding اسمه DB مش متربط بالـ Worker (Settings > Bindings > D1)");
  await env.DB.prepare(SCHEMA).run();
  await env.DB.prepare(BCQ).run();
  await env.DB.prepare(OUTQ).run();
  try { await env.DB.prepare("ALTER TABLE subs ADD COLUMN pr TEXT").run(); } catch (e) {}   // عمود مواعيد الصلاة (بيتضاف مرة واحدة)
  ready = true;
}
const RETRYABLE = s => s === 0 || s === 429 || s >= 500;
/* بيبعت إشعار واحد. 404/410 = الاشتراك مات فبنمسحه. 429 و 5xx وأخطاء الشبكة بنعيد المحاولة (ضمن ميزانية الطلبات) */
async function send(env, row, m, B) {
  if (isFcm(row)) return sendFcm(env, row, m, B);
  let body;
  try { body = await encrypt(JSON.stringify({ t: m.t, b: m.b, tag: m.tag, go: m.go }), { keys: { p256dh: row.p256dh, auth: row.auth } }); }
  catch (e) { await env.DB.prepare("DELETE FROM subs WHERE endpoint=?").bind(row.endpoint).run(); return 400; }   // مفاتيح اشتراك بايظة
  let st = 0;
  for (let a = 0; a < 3; a++) {
    let r = null;
    try { r = await fetch(row.endpoint, { method: "POST", body, headers: { TTL: String(m.ttl), Urgency: "normal", "Content-Encoding": "aes128gcm", "Content-Type": "application/octet-stream", Authorization: await vapid(env, row.endpoint) } }); } catch (e) {}
    st = r ? r.status : 0;
    if (!RETRYABLE(st) || a === 2 || B.retry <= 0) break;
    const ra = r ? (+r.headers.get("Retry-After") || 0) * 1000 : 0;
    if (ra > 5000) break;                       // الخدمة طالبة انتظار طويل: هنعيدها في الـ cron الجاي
    B.retry--; await sleep(ra || 700 * (a + 1));
  }
  if (st === 404 || st === 410) await env.DB.prepare("DELETE FROM subs WHERE endpoint=?").bind(row.endpoint).run();
  return st;
}
/* ---------- FCM: تطبيق أندرويد (HTTP v1) ----------
   محتاج Secret اسمه SA_JSON (نفس مفتاح الـ Service Account بتاع quran-admin).
   الأجهزة بتتخزّن في نفس جدول subs بـ endpoint = "fcm:" + التوكن.
   افتراضيًا: FCM للبث (رسائل المطوّر) بس، لأن التطبيق بيجدول الأذكار والصلاة محليًا على الجهاز.
   لو عايز السيرفر يبعت المجدولة كمان لأجهزة أندرويد: ضيف متغير FCM_SCHEDULED=1 (هتتكرر مع المحلية). */
const isFcm = row => String((row && row.endpoint) || "").startsWith("fcm:");
let fcmTok = "", fcmExp = 0, fcmProj = "";
async function fcmAccess(env) {
  if (fcmTok && Date.now() < fcmExp) return fcmTok;
  const sa = JSON.parse(env.SA_JSON), now = Math.floor(Date.now() / 1000);
  const h = b64u.enc(enc.encode(JSON.stringify({ alg: "RS256", typ: "JWT" })));
  const c = b64u.enc(enc.encode(JSON.stringify({ iss: sa.client_email, scope: "https://www.googleapis.com/auth/firebase.messaging", aud: "https://oauth2.googleapis.com/token", iat: now, exp: now + 3000 })));
  const pem = sa.private_key.replace(/\\n/g, "\n").replace(/-----[^-]+-----/g, "").replace(/\s+/g, "");
  const key = await crypto.subtle.importKey("pkcs8", Uint8Array.from(atob(pem), x => x.charCodeAt(0)), { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["sign"]);
  const sig = b64u.enc(await crypto.subtle.sign("RSASSA-PKCS1-v1_5", key, enc.encode(h + "." + c)));
  const r = await fetch("https://oauth2.googleapis.com/token", { method: "POST", headers: { "content-type": "application/x-www-form-urlencoded" }, body: "grant_type=urn:ietf:params:oauth:grant-type:jwt-bearer&assertion=" + h + "." + c + "." + sig });
  const j = await r.json();
  if (!j.access_token) throw new Error("fcm token: " + (j.error_description || j.error));
  fcmTok = j.access_token; fcmExp = Date.now() + 50 * 60000; fcmProj = sa.project_id;
  return fcmTok;
}
async function sendFcm(env, row, m, B) {
  if (!env.SA_JSON) return 400;
  const token = row.endpoint.slice(4);
  let st = 0;
  for (let a = 0; a < 3; a++) {
    let r = null, txt = "";
    try {
      const at = await fcmAccess(env);
      r = await fetch("https://fcm.googleapis.com/v1/projects/" + fcmProj + "/messages:send", {
        method: "POST", headers: { authorization: "Bearer " + at, "content-type": "application/json" },
        body: JSON.stringify({ message: { token, notification: { title: m.t, body: m.b }, data: { go: String(m.go || "home"), tag: String(m.tag || "wird") },
          android: { priority: "HIGH", ttl: Math.max(60, +m.ttl || 900) + "s", notification: { channel_id: "wird_push", tag: String(m.tag || "wird"), icon: "ic_stat_wird", color: "#0e1b17", default_vibrate_timings: true } } } })
      });
      if (!r.ok) txt = await r.text().catch(() => "");
    } catch (e) { fcmTok = ""; }
    st = r ? r.status : 0;
    /* التوكن مات (التطبيق اتمسح أو التوكن اتجدّد): نمسحه */
    if (r && (st === 404 || (st === 400 && /registration token|UNREGISTERED|not a valid FCM/i.test(txt)))) { await env.DB.prepare("DELETE FROM subs WHERE endpoint=?").bind(row.endpoint).run(); return 404; }
    if (r && st === 401) fcmTok = "";   // توكن الوصول انتهى: نجدّده ونعيد
    if ((!RETRYABLE(st) && st !== 401) || a === 2 || B.retry <= 0) break;
    B.retry--; await sleep(700 * (a + 1));
  }
  return st;
}

const LIMIT = 45;   // حد Cloudflare المجاني: 50 طلب خارجي في كل تشغيل (45 إرسال + الباقي لإعادة المحاولة)
const newBudget = () => ({ retry: 3 });
async function sendAll(env, jobs, B) {
  const out = [];
  for (let i = 0; i < jobs.length; i += 15) out.push(...await Promise.all(jobs.slice(i, i + 15).map(([r, m]) => send(env, r, m, B).catch(() => 0))));
  return out;
}
/* الإشعار اللي فشل بسبب ضغط/عطل مؤقت: لو لسه صالح (TTL 15 دقيقة فأكتر) بنحفظه ونعيده في الـ cron الجاي */
async function requeue(env, jobs, sts, now) {
  const st = [];
  jobs.forEach(([r, m], i) => { if (RETRYABLE(sts[i]) && m.ttl >= 900) st.push(env.DB.prepare("INSERT INTO outq(endpoint,msg,exp,tries) VALUES(?,?,?,0)").bind(r.endpoint, JSON.stringify(m), now + Math.min(m.ttl * 1000, 15 * 60000))); });
  if (st.length) await env.DB.batch(st);
}
async function run(env, ms) {
  await ensure(env);
  const B = newBudget();
  let budget = LIMIT;
  /* 0) تنضيف: اللي غايب 60 يوم يتمسح، وأي طوابير ملهاش اشتراك */
  await env.DB.prepare("DELETE FROM subs WHERE u IS NULL OR u<?").bind(ms - PURGE).run();
  await env.DB.prepare("DELETE FROM outq WHERE exp<=? OR tries>=3 OR endpoint NOT IN (SELECT endpoint FROM subs)").bind(ms).run();
  /* 1) إشعارات فشلت قبل كده (429/5xx) وهتتعاد */
  const o = await env.DB.prepare("SELECT s.*, q.id AS qid, q.msg AS qmsg, q.exp AS qexp FROM outq q JOIN subs s ON s.endpoint=q.endpoint WHERE s.u>=? LIMIT ?").bind(ms - STALE, budget).all();
  const oJobs = (o.results || []).map(r => { try { const m = JSON.parse(r.qmsg); m.ttl = Math.max(60, Math.floor((r.qexp - ms) / 1000)); return [r, m]; } catch (e) { return null; } }).filter(Boolean);
  if (oJobs.length) {
    const sts = await sendAll(env, oJobs, B);
    await env.DB.batch(oJobs.map(([r], i) => RETRYABLE(sts[i]) ? env.DB.prepare("UPDATE outq SET tries=tries+1 WHERE id=?").bind(r.qid) : env.DB.prepare("DELETE FROM outq WHERE id=?").bind(r.qid)));
    budget -= oJobs.length;
  }
  /* 2) بث متأخر لسه ما وصلش لناس (لما المستخدمين يزيدوا عن حد الإرسال في المرة الواحدة) */
  if (budget > 0) {
    const q = await env.DB.prepare("SELECT s.*, b.msg AS bmsg FROM bcq b JOIN subs s ON s.endpoint=b.endpoint WHERE b.ts>? LIMIT ?").bind(ms - 3 * 3600000, budget).all();
    const qJobs = (q.results || []).map(r => { try { return [r, fromBroadcast(JSON.parse(r.bmsg), r)]; } catch (e) { return null; } }).filter(Boolean);
    if (qJobs.length) {
      const sts = await sendAll(env, qJobs, B);
      await env.DB.batch(qJobs.map(([r]) => env.DB.prepare("DELETE FROM bcq WHERE endpoint=?").bind(r.endpoint)));
      await requeue(env, qJobs, sts, ms);
      budget -= qJobs.length;
    }
  }
  await env.DB.prepare("DELETE FROM bcq WHERE ts<=?").bind(ms - 3 * 3600000).run();
  /* 3) الإشعارات المجدولة (للنشطين بس: فاتحين التطبيق في آخر 14 يوم) */
  const { results } = await env.DB.prepare("SELECT * FROM subs WHERE u>=?").bind(ms - STALE).all();
  const jobs = [];
  for (const row of results || []) { if (isFcm(row) && env.FCM_SCHEDULED !== "1") continue; for (const m of due(row, ms)) jobs.push([row, m]); }
  const batch = jobs.slice(0, Math.max(0, budget));
  const sts = await sendAll(env, batch, B);
  await requeue(env, batch, sts, ms);
  if (jobs.length > batch.length) console.log("تخطّيت " + (jobs.length - batch.length) + " إشعار بسبب الحد المجاني");
}
async function broadcast(env, msg) {
  await ensure(env);
  const now = Date.now(), B = newBudget();
  const { results } = await env.DB.prepare("SELECT * FROM subs WHERE g IN ('m','f') AND u>=? ORDER BY u DESC").bind(now - PURGE).all(), rows = results || [], first = rows.slice(0, LIMIT - 1), rest = rows.slice(LIMIT - 1);
  const jobs = first.map(r => [r, fromBroadcast(msg, r)]), sts = await sendAll(env, jobs, B);
  await requeue(env, jobs, sts, now);
  if (rest.length) {
    const js = JSON.stringify(msg);
    await env.DB.batch(rest.map(r => env.DB.prepare("INSERT OR REPLACE INTO bcq(endpoint,msg,ts) VALUES(?,?,?)").bind(r.endpoint, js, now)));
  }
  return { sent: first.length, queued: rest.length, total: rows.length };
}

/* ---------- تنضيف بيانات الاشتراك ---------- */
const hhmm = x => /^\d\d:\d\d$/.test(x) ? x : "";
const s120 = (x, n = 120) => String(x == null ? "" : x).replace(/[\u0000-\u001f\u007f]/g, " ").slice(0, n);
function cleanCfg(c) {
  c = c && typeof c === "object" ? c : {};
  const on = {}; ["m", "e", "w", "d", "pb", "pm"].forEach(k => { on[k] = c.on && c.on[k] ? 1 : 0; });
  return { on, tm: hhmm(c.tm) || "06:00", te: hhmm(c.te) || "17:00", tw: hhmm(c.tw) || "21:00", qs: hhmm(c.qs) || "23:00", qe: hhmm(c.qe) || "05:00", iv: snapIv(c.iv), pr: snapPr(c.pr), rc: Math.min(3, Math.max(1, +c.rc || 1)), rg: Math.min(120, Math.max(5, +c.rg || 30)) };
}
function cleanDone(d) { d = d && typeof d === "object" ? d : {}; return { d: s120(d.d, 10), m: d.m ? 1 : 0, e: d.e ? 1 : 0, w: d.w ? 1 : 0 }; }

function cleanPr(x) {
  if (!x || !x.t) return null;
  const pr = { t: {}, done: { d: s120(x.done && x.done.d, 10) } };
  [...PRAYERS.map(p => p[0]), "sunrise"].forEach(id => { pr.t[id] = hhmm(x.t[id]); });
  PRAYERS.forEach(([id]) => { pr.done[id] = x.done && x.done[id] ? 1 : 0; });
  return pr;
}

const cors = (env, req) => {
  const list = String(env.ALLOWED_ORIGIN || "*").split(",").map(s => s.trim()).filter(Boolean), o = (req && req.headers.get("Origin")) || "";
  let allow = "*";
  if (!list.includes("*")) { list.push("https://localhost"); allow = list.includes(o) ? o : list[0]; }   // https://localhost = تطبيق أندرويد (Capacitor)
  return { "Access-Control-Allow-Origin": allow, Vary: "Origin", "Access-Control-Allow-Methods": "GET, POST, OPTIONS", "Access-Control-Allow-Headers": "Content-Type", "Access-Control-Max-Age": "86400" };
};
export default {
  async scheduled(ev, env, ctx) { ctx.waitUntil(run(env, ev.scheduledTime)); },
  async fetch(req, env) {
    try {
      const H = cors(env, req), u = new URL(req.url), res = (o, s = 200) => new Response(JSON.stringify(o), { status: s, headers: { ...H, "Content-Type": "application/json" } });
      if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: H });
      /* فحص القاعدة: افتح الرابط ده في المتصفح  /?db=1 */
      if (req.method === "GET" && u.searchParams.has("db")) {
        await ensure(env);
        const n = await env.DB.prepare("SELECT COUNT(*) AS n FROM subs").first();
        return res({ ok: true, db: true, subs: n ? n.n : 0, vapid: !!env.VAPID_PRIVATE_JWK, fcm: !!env.SA_JSON });
      }
      if (req.method !== "POST") return res({ ok: true, service: "wird-push" });
      const raw = await req.text(); if (raw.length > 8000) return res({ error: "big" }, 413);
      let b; try { b = JSON.parse(raw); } catch (e) { return res({ error: "json" }, 400); }
      if (!b || typeof b !== "object") return res({ error: "json" }, 400);

      if (u.pathname === "/broadcast") {
        if (!(await isAdmin(env, b.token))) return res({ error: "forbidden" }, 403);
        const msg = cleanMsg(b.msg); if (!msg) return res({ error: "msg" }, 400);
        return res(await broadcast(env, msg));
      }
      await ensure(env);

      /* تطبيق أندرويد: تسجيل/تحديث جهاز FCM */
      if (u.pathname === "/subscribe-native") {
        const t = b.fcm;
        if (typeof t !== "string" || !/^[\w:.\-]{50,500}$/.test(t)) return res({ error: "fcm" }, 400);
        const nep = "fcm:" + t;
        if (!b.uid) { await env.DB.prepare("DELETE FROM subs WHERE endpoint=?").bind(nep).run(); return res({ ok: true, removed: true }); }
        if (b.g !== "m" && b.g !== "f") return res({ error: "gender" }, 400);
        const npr = cleanPr(b.pr);
        await env.DB.prepare("INSERT INTO subs(endpoint,p256dh,auth,uid,name,g,tz,cfg,done,u,pr) VALUES(?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(endpoint) DO UPDATE SET uid=excluded.uid,name=excluded.name,g=excluded.g,tz=excluded.tz,cfg=excluded.cfg,done=excluded.done,u=excluded.u,pr=excluded.pr")
          .bind(nep, "", "", s120(b.uid), s120(b.name, 60).trim(), b.g, s120(b.tz), JSON.stringify(cleanCfg(b.cfg)), JSON.stringify(cleanDone(b.done)), Date.now(), npr ? JSON.stringify(npr) : null).run();
        return res({ ok: true });
      }
      if (u.pathname === "/unsubscribe" && typeof b.fcm === "string" && !b.token) {
        await env.DB.prepare("DELETE FROM subs WHERE endpoint=?").bind("fcm:" + b.fcm).run();
        return res({ ok: true, removed: true });
      }

      /* مسح الاشتراك: بالتوكن (كل أجهزة الحساب، أو أي حساب لو المطوّر) أو بالـ endpoint بتاع الجهاز */
      if (u.pathname === "/unsubscribe" && b.token) {
        const who = await verifyToken(env, b.token);
        if (!who) return res({ error: "forbidden" }, 403);
        const target = b.uid && String(b.uid) !== who.uid ? (adminList(env).includes(who.email) ? s120(b.uid) : null) : who.uid;
        if (!target) return res({ error: "forbidden" }, 403);
        await env.DB.prepare("DELETE FROM subs WHERE uid=?").bind(target).run();
        return res({ ok: true, removed: true });
      }

      /* المتصفح غيّر الاشتراك (pushsubscriptionchange): بننقل بيانات القديم للجديد */
      if (u.pathname === "/resubscribe") {
        const old = b.old, n = b.sub, k = n && n.keys;
        if (typeof old !== "string" || !n || typeof n.endpoint !== "string" || !n.endpoint.startsWith("https://") || !k || !k.p256dh || !k.auth) return res({ error: "sub" }, 400);
        await env.DB.prepare("DELETE FROM subs WHERE endpoint=? AND endpoint<>?").bind(n.endpoint, old).run();
        const r = await env.DB.prepare("UPDATE subs SET endpoint=?,p256dh=?,auth=?,u=? WHERE endpoint=?").bind(n.endpoint, s120(k.p256dh), s120(k.auth), Date.now(), old).run();
        return res({ ok: true, moved: !!(r.meta && r.meta.changes) });
      }

      const ep = b.sub && b.sub.endpoint, k = b.sub && b.sub.keys;
      if (typeof ep !== "string" || !ep.startsWith("https://") || !k || !k.p256dh || !k.auth) return res({ error: "sub" }, 400);
      if (u.pathname === "/unsubscribe" || !b.uid) { await env.DB.prepare("DELETE FROM subs WHERE endpoint=?").bind(ep).run(); return res({ ok: true, removed: true }); }
      if (b.g !== "m" && b.g !== "f") return res({ error: "gender" }, 400);   // النوع إجباري عشان الصيغة (مذكر/مؤنث) تطلع صح
      let pr = null;
      if (b.pr && b.pr.t) {
        pr = { t: {}, done: { d: s120(b.pr.done && b.pr.done.d, 10) } };
        [...PRAYERS.map(p => p[0]), "sunrise"].forEach(id => { pr.t[id] = hhmm(b.pr.t[id]); });
        PRAYERS.forEach(([id]) => { pr.done[id] = b.pr.done && b.pr.done[id] ? 1 : 0; });
      }
      await env.DB.prepare("INSERT INTO subs(endpoint,p256dh,auth,uid,name,g,tz,cfg,done,u,pr) VALUES(?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(endpoint) DO UPDATE SET p256dh=excluded.p256dh,auth=excluded.auth,uid=excluded.uid,name=excluded.name,g=excluded.g,tz=excluded.tz,cfg=excluded.cfg,done=excluded.done,u=excluded.u,pr=excluded.pr")
        .bind(ep, s120(k.p256dh), s120(k.auth), s120(b.uid), s120(b.name, 60).trim(), b.g, s120(b.tz), JSON.stringify(cleanCfg(b.cfg)), JSON.stringify(cleanDone(b.done)), Date.now(), pr ? JSON.stringify(pr) : null).run();
      return res({ ok: true });
    } catch (e) {
      return new Response(JSON.stringify({ error: "server", detail: String((e && e.message) || e).slice(0, 200) }), { status: 500, headers: { ...cors(env, req), "Content-Type": "application/json" } });
    }
  },
};
if (globalThis.__WP_TEST) globalThis.__WP_TEST = { encrypt, vapid, due, localOf, b64u, cleanMsg, fromBroadcast, msgs, prayMsg, jamMsg, cleanCfg, snapIv, snapPr, send, run, broadcast };
