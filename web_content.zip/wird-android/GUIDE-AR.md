# وِرْد — دليل تحويله لتطبيق أندرويد حقيقي ورفعه على Google Play

> اللي في الـ ZIP ده اتجهّز بدون ما أقدر أبنيه أو أجرّبه على موبايل (مفيش Android SDK ولا نت عندي). الكود اتراجع واتجرّب منطقه، لكن **أول تشغيل على جهازك هو الاختبار الحقيقي**، وفي آخر الدليل قايمة اختبار ومشاكل متوقعة.

## اللي اتغيّر

| الجزء | إيه اللي حصل |
|---|---|
| `site/` | نسخة v85 من الموقع، معدّلة عشان تشتغل جوه التطبيق (البصمة، المشاركة، الإشعارات، زر الرجوع). على المتصفح بتشتغل زي ما كانت. |
| `native/native.js` | طبقة الأندرويد: إشعارات محلية مجدولة 3 أيام (أذكار/ورد/صلاة/«اذكر ربنا») بتشتغل والتطبيق مقفول **ومن غير نت أو سيرفر**، استقبال FCM، بصمة/قفل شاشة أصلي، مشاركة صورة الآية، زر رجوع صح. |
| `scripts/prepare-web.mjs` | بيحزّم الموقع جوه التطبيق وبينزّل مكتبات Firebase والخطوط ونص المصحف عشان التطبيق يفتح **أوفلاين** من الجهاز مش من رابط. |
| `worker/worker-push.js` | بقى بيبعت **FCM لأجهزة أندرويد** (للبث ورسائل المطوّر) وفاضل بيبعت Web Push للمتصفح زي ما هو. |
| `worker/worker-admin.js` | نفس الكود + CORS للتطبيق. |
| `site/privacy.html` | اتحدّثت (FCM والبصمة والإشعارات المحلية). |

---

## الخطوة 0: إصلاح Error 1031 (دقيقتين)

الخطأ ده من **نافذة المعاينة جوه لوحة Cloudflare** مش من الكود. الحل:

1. افتح الوركر `quran-admin` ← الصق محتوى `worker/worker-admin.js` الجديد ← اضغط **Deploy** (من غير ما تعتمد على نافذة Preview).
2. افتح الرابط الحقيقي في تاب لوحده: `https://quran-admin.lovefreedme88.workers.dev/` — لازم يرد `{"ok":false,"error":"not found"}`. ده معناه إنه شغال.
3. لو الـ Preview لسه بيطلّع 1031 تجاهله. أو انشر بالأوامر بدل اللوحة:
   ```
   cd worker
   npx wrangler login
   npx wrangler deploy -c wrangler.admin.toml
   ```
   (لو بتنشره بـ wrangler هيكتب فوق إعدادات اللوحة، فتأكد إن الـ Secret `SA_JSON` متضاف: `npx wrangler secret put SA_JSON -c wrangler.admin.toml`)
4. لو لسه: Settings ← Domains & Routes ← تأكد إن **workers.dev** متفعّل.

---

## الخطوة 1: جهّز جهازك (مرة واحدة)

1. **Node.js 22 أو أحدث** (نزّله من nodejs.org) — تأكد: `node -v`.
2. **Android Studio** (أحدث نسخة) — وقت التثبيت سيبه ينزّل Android SDK. ده بيجي معاه JDK 21 جاهز.
3. موبايل أندرويد: من الإعدادات فعّل **Developer options** ثم **USB debugging**.

## الخطوة 2: Firebase (إشعارات FCM)

1. https://console.firebase.google.com ← مشروع **werd** ← ⚙️ Project settings ← **Your apps** ← **Add app** ← أيقونة Android.
2. **Android package name**: اكتب `com.wird.quran` (لازم يطابق `appId` في `capacitor.config.json`. لو عايز اسم تاني غيّره في الملف **قبل** الخطوة 4، ولا تغيّره بعد أول رفع على بلاي أبدًا).
3. Register app ← **Download google-services.json** ← حطه في **جذر مجلد المشروع** (جنب `package.json`). باقي الشاشات اضغط Next/Continue.
4. تأكد إن Cloud Messaging شغّال: Project settings ← **Cloud Messaging** ← لازم **Firebase Cloud Messaging API (V1)** يبقى Enabled. لو Disabled اضغط النقط التلاتة ← Manage API in Google Cloud ← Enable.

## الخطوة 3: حدّث الـ Workers

**wird-push** (أهم واحد):
1. Cloudflare ← Workers & Pages ← `wird-push` ← Edit code ← امسح القديم والصق `worker/worker-push.js` ← **Deploy**.
2. Settings ← **Variables and Secrets** ← Add ← النوع **Secret** ← الاسم `SA_JSON` ← القيمة: محتوى ملف الـ Service Account كامل (نفس اللي حاطه في quran-admin. لو مش معاك: Firebase ← Project settings ← Service accounts ← **Generate new private key**).
3. اختبر: افتح `https://wird-push.lovefreedme88.workers.dev/?db=1` ← لازم يطلّع `"fcm":true`.
4. لو كنت ضابط `ALLOWED_ORIGIN` على رابط موقعك، مفيش مشكلة: الكود بيضيف `https://localhost` (التطبيق) لوحده.

**quran-admin**: اتعمل في الخطوة 0.

## الخطوة 4: ابنِ المشروع على جهازك

افتح Terminal جوه مجلد المشروع (بعد فك الـ ZIP):

```
npm install
```
قبل الخطوة الجاية افتح `package.json` وعدّل `"siteUrl"` لرابط موقعك على Cloudflare Pages (مثلًا `"https://اسم-موقعك.pages.dev"`)، ده اللي بيخلي التطبيق يعرف إن في نسخة أحدث ويفتح لك صفحة بلاي. لو سبته فاضي مفيش مشكلة، بس مفيش تنبيه تحديث.

```
npm run init
```
ده بيعمل كل ده لوحده: يحزّم الموقع (محتاج نت) ← ينشئ مشروع أندرويد ← يولّد الأيقونة وشاشة البداية ← يظبط الصلاحيات و`google-services.json` ← يضبط رقم الإصدار.
اقرأ آخر الشاشة: أي سطر بيبدأ بـ ⚠ بيقولك على حاجة ناقصة (مثلًا google-services.json).

بعدها:
```
npm run open
```
هيفتح Android Studio. استنى Gradle sync يخلّص (أول مرة بتاخد 5–10 دقايق). وصّل الموبايل بالكيبل واضغط ▶ **Run**.

**أي تعديل بعد كده** (على ملفات `site/` مثلًا): `npm run sync` وبعدين ▶ Run تاني.
(ونفس مجلد `site/` هو اللي تنشره على Cloudflare Pages للويب.)

## الخطوة 5: اختبر على الموبايل قبل ما ترفع

- [ ] التطبيق بيفتح ويعرض الشاشة كاملة من غير ما شريط الحالة يغطي المحتوى.
- [ ] سجّل دخول بحسابك. وافق على إذن الإشعارات، واللي بعده «المنبّهات والتذكيرات» (مهم لدقة المواعيد).
- [ ] **اختبار الإشعار المجدول (الأهم):** من قائمة التعديل ← الإشعارات (للمطوّر) غيّر وقت أذكار الصباح لبعد **دقيقتين**. سيب التطبيق مفتوح 30 ثانية (عشان يعيد الجدولة)، بعدين اقفله من الأخير وافصل النت (وضع الطيران). لازم الإشعار يطلع في ميعاده. الضغط عليه يفتح الأذكار.
- [ ] زر «📣 ابعت دلوقتي» من نفس الصفحة: لازم يوصل (ده FCM من السيرفر).
- [ ] وضع الطيران + فتح التطبيق: بيشتغل ويفتح المصحف.
- [ ] زر الرجوع: يقفل النوافذ ← يرجع للرئيسية ← مرتين للخروج.
- [ ] تفعيل البصمة وقفل/فتح التطبيق، مشاركة صورة آية اليوم.
- [ ] تحديد الموقع لمواقيت الصلاة، وتعليم صلاة «صليت» (يوقف تذكيراتها).
- [ ] مسح الحساب من التطبيق.

## الخطوة 6: ابنِ ملف النشر (AAB) ووقّعه

1. في Android Studio: **Build ← Generate Signed App Bundle / APK ← Android App Bundle ← Next**.
2. **Create new...** لإنشاء Keystore: اختار مكان آمن، اكتب باسورد، alias مثلًا `wird`، Validity 25 سنة، واملا الاسم. 
   ⚠️ **خد نسخة من ملف الـ keystore والباسوردات في مكانين** (إيميلك + فلاشة). لو ضاع مش هتقدر تحدّث التطبيق بنفس الاسم.
3. Next ← اختار **release** ← Create. الملف هيطلع في `android/app/release/app-release.aab`.

## الخطوة 7: Google Play Console

**1) إنشاء التطبيق:** Create app ← الاسم «وِرْد» ← اللغة العربية ← **App** ← **Free** ← وافق على الإقرارات.

**2) متطلب الاختبار المغلق:** لو حساب المطوّر شخصي وجديد، بلاي بتطلب **اختبار مغلق (Closed testing) بعدد معيّن من المختبرين لمدة 14 يوم** قبل الإنتاج (كان 12 مختبر، اتأكد من الرقم الحالي في Dashboard). اعمل Testing ← Closed testing ← Create track ← ضيف إيميلات المختبرين (Google Group أو قايمة) ← ارفع الـ AAB هناك الأول.

**3) Set up your app (في Dashboard):**
- **Privacy policy**: `رابط-موقعك/privacy.html`
- **App access**: التطبيق بيطلب تسجيل دخول، فاختار «All or some functionality is restricted» وحط **إيميل وباسورد حساب تجريبي** تعمله مخصوص للمراجعين (ومعاه اسم ونوع ورقم تليفون لو بيطلبهم).
- **Ads**: No.
- **Content rating**: ابدأ الاستبيان، الفئة Reference/Education أو Utility. كل الأسئلة (عنف، جنس، مقامرة...) = No. هتطلع «للجميع».
- **Target audience**: اختار 13+ و16+ و18+ (متختارش تحت 13 عشان متدخلش في سياسة الأطفال).
- **News app / COVID / Government / Financial**: No.
- **Data safety** (لازم تطابق سياسة الخصوصية):
  - *Does your app collect or share user data?* **Yes**
  - *Encrypted in transit:* **Yes** — *Users can request data deletion:* **Yes**، الرابط: `رابط-موقعك/delete-account.html`
  - البيانات اللي بتتجمع (كلها: **Collected**، **مش Shared** — Firebase وCloudflare معالجين بالنيابة عنك):
    - **Personal info**: Name، Email address، Phone number — الغرض: App functionality + Account management
    - **Personal info → User IDs**: معرّف الحساب — App functionality
    - **App activity**: بيانات التقدم والنقاط (App interactions) — App functionality
    - **Device or other IDs**: معرّف جهاز FCM — App functionality (اختياري للمستخدم: بيتجمع بس لو وافق على الإشعارات)
  - **Location**: اختار إنه **مش بيتجمع**، لأن الإحداثيات بتتحسب على الجهاز ومبتتبعتش لأي سيرفر.
- **Exact alarms / Permissions declarations**: لو بلاي طلبت إقرار عن `SCHEDULE_EXACT_ALARM` اشرح إن التنبيهات بوقت محدد (أذكار الصباح والمساء ومواقيت الصلاة) هي وظيفة أساسية في التطبيق.

**4) Store listing:**
- الأيقونة: `store/icon-512.png` — الرسمة الترويجية: `store/feature-graphic-1024x500.png`
- **لقطات شاشة**: 4–8 لقطات من موبايلك (الرئيسية، المصحف، الأذكار، مواقيت الصلاة، الورد).
- **الوصف المختصر (80 حرف):** «ورد القرآن اليومي، الأذكار ومواقيت الصلاة، وتذكيرات تفتح لك الباب»
- **الوصف الكامل (مقترح):**
  «وِرْد رفيقك اليومي مع القرآن الكريم. سجّل وردك وتابع ختمتك بالصفحات أو الأرباع، واقرأ المصحف بالتشكيل وألوان التجويد، واحفظ وراجع واختبر نفسك، وتابع أذكار الصباح والمساء بعدّاد، وشوف مواقيت الصلاة حسب موقعك.
  تنبيهات أصلية في أوقاتها (أذكار، ورد، صلاة) تعمل حتى لو الإنترنت مقطوع. قفل بالبصمة، ومشاركة آية اليوم كصورة، وتتبّع للسلاسل والنقاط. بلا إعلانات.»

**5) رفع الإصدار:** Testing ← Closed testing (أو Production لو الحساب مش محتاج اختبار) ← Create new release ← ارفع `app-release.aab` ← فعّل **Play App Signing** لو سألك ← اكتب Release notes ← Review ← Start rollout.
في خانة **Notes for review / App access** اكتب للمراجع (ده بيعالج سبب الرفض المتوقع «Minimum functionality»):
> The app is a native Android app (Capacitor) that bundles all content on-device and works fully offline. Native functionality: scheduled local notifications for adhkar and prayer times (work without internet), Firebase Cloud Messaging push, biometric lock, native share of verse cards, Quran reader with tajweed, and progress tracking. Test account: EMAIL / PASSWORD.

**6) التحديثات بعد كده:** عدّل `package.json`: ارفع `"version"` (مثلًا 1.0.1) و`"wird.versionCode"` (+1 كل مرة، لازم يزيد) ← `npm run sync` ← Build Signed Bundle بنفس الـ keystore ← ارفع AAB جديد.

---

## مشاكل متوقعة وحلولها

| المشكلة | الحل |
|---|---|
| `npm run init` فشل في تنزيل الخطوط/المكتبات | اتأكد من النت وشغّله تاني (بيكمّل من الكاش). مكتبات Firebase إجبارية، الخطوط ونص المصحف لو فشلوا التطبيق بيشتغل ويحمّلهم أول مرة من النت. |
| `npm install` يشتكي من peer dependencies | `npm install --legacy-peer-deps`. لو مكتبة البصمة (`@aparajita/capacitor-biometric-auth`) اشتكت من نسخة Capacitor، نزّل أحدث نسخة منها: `npm i @aparajita/capacitor-biometric-auth@latest`. |
| Gradle: «Unsupported Java» | Android Studio ← Settings ← Build Tools ← Gradle ← **Gradle JDK = jbr-21 (Embedded JDK)**. |
| الإشعارات متأخرة أو مبتظهرش على شاومي/هواوي/أوبو/سامسونج | إعدادات الموبايل ← التطبيقات ← وِرْد ← البطارية ← **بدون قيود** + فعّل «التشغيل التلقائي/Autostart». ده من الشركة المصنّعة مش من التطبيق. |
| الإشعارات مش مفعّلة بعد التحديث | الجدولة بتتجدد كل ما تفتح التطبيق (بتغطي 3 أيام قدام و«اذكر ربنا» 24 ساعة). لو مفتحتش التطبيق أكتر من كده هتقف لحد ما تفتحه. |
| رسائل FCM مش بتوصل | اتأكد: `google-services.json` موجود قبل `npm run sync`، و`?db=1` بيرجّع `fcm:true`، وإن الإذن اتمنح، وإنك فتحت التطبيق مرة بعد تسجيل الدخول (بيسجّل الجهاز وقتها). |
| المحتوى تحت شريط الحالة/الأزرار | قولّي ومعاك صورة الشاشة، التعديل CSS بسيط. |

## ملاحظات مهمة

- **مفيش تكرار إشعارات:** الأذكار والصلاة بتتجدول **محليًا** بس. السيرفر (FCM) بيبعت البث ورسائل المطوّر. لو عايز السيرفر يبعت المجدولة كمان لأجهزة أندرويد ضيف متغير `FCM_SCHEDULED=1` في wird-push، بس هتتكرر مع المحلية.
- **اسم الحزمة** `com.wird.quran` بيتحدد من `capacitor.config.json` ومينفعش يتغيّر بعد النشر. التطبيق القديم (TWA `dev.pages.quran_hifz.twa`) له تسجيل منفصل ومتأثرش، وملف `assetlinks.json` ملوش لازمة للتطبيق الجديد.
- **آيفون لاحقًا:** نفس المشروع. محتاج Mac وحساب Apple Developer. وقتها: `npm i @capacitor/ios && npx cap add ios`، وإضافة APNs key في Firebase. قولّي ساعتها وأجهّزها.
