// بيجهّز مجلد www (اللي بيتحزّم جوه التطبيق) من مجلد site:
//  1) ينسخ الموقع  2) ينزّل مكتبات Firebase والخطوط ونص المصحف ويحطها جوه التطبيق (عشان يشتغل من غير نت)
//  3) يضيف طبقة الأندرويد (native.bundle.js) وإعداداتها  4) يظبط المساحات الآمنة (شريط الحالة)
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { build } from "esbuild";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const SITE = path.join(root, "site"), WWW = path.join(root, "www"), CACHE = path.join(root, ".cache");
const pkg = JSON.parse(fs.readFileSync(path.join(root, "package.json"), "utf8"));
const capCfg = JSON.parse(fs.readFileSync(path.join(root, "capacitor.config.json"), "utf8"));
const FB = "10.13.0";

fs.rmSync(WWW, { recursive: true, force: true });
fs.mkdirSync(WWW, { recursive: true });
fs.mkdirSync(CACHE, { recursive: true });

// 1) نسخ الموقع (من غير ملفات الاستضافة)
const SKIP = new Set([".well-known", "_headers", "service-worker.js"]);
fs.cpSync(SITE, WWW, { recursive: true, filter: s => !SKIP.has(path.basename(s)) });

// تنزيل ملف مع كاش محلي
async function get(url, name, asText = false, ua) {
  const cp = path.join(CACHE, name);
  if (fs.existsSync(cp)) return asText ? fs.readFileSync(cp, "utf8") : fs.readFileSync(cp);
  const r = await fetch(url, ua ? { headers: { "user-agent": ua } } : undefined);
  if (!r.ok) throw new Error(url + " -> HTTP " + r.status);
  const buf = Buffer.from(await r.arrayBuffer());
  fs.mkdirSync(path.dirname(cp), { recursive: true });
  fs.writeFileSync(cp, buf);
  return asText ? buf.toString("utf8") : buf;
}
const put = (rel, data) => { const p = path.join(WWW, rel); fs.mkdirSync(path.dirname(p), { recursive: true }); fs.writeFileSync(p, data); };

let html = fs.readFileSync(path.join(WWW, "index.html"), "utf8");
let warnings = [];

// 2أ) مكتبات Firebase (إجباري، من غيرها التطبيق مش هيفتح من غير نت)
for (const n of ["app", "auth", "firestore"]) {
  const u = `https://www.gstatic.com/firebasejs/${FB}/firebase-${n}-compat.js`;
  put(`vendor/firebase-${n}-compat.js`, await get(u, `firebase-${n}-${FB}.js`));
  html = html.split(u).join(`vendor/firebase-${n}-compat.js`);
}

// 2ب) الخطوط (Amiri)
try {
  const cssUrl = "https://fonts.googleapis.com/css2?family=Amiri+Quran&family=Amiri:wght@400;700&display=swap";
  let css = await get(cssUrl, "fonts.css", true, "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/130 Mobile Safari/537.36");
  const urls = [...new Set([...css.matchAll(/url\((https:[^)]+)\)/g)].map(m => m[1]))];
  let i = 0;
  for (const u of urls) {
    const ext = (u.match(/\.(woff2|woff|ttf)/) || [, "woff2"])[1], name = `f${i++}.${ext}`;
    put(`vendor/fonts/${name}`, await get(u, `fonts/${name}`));
    css = css.split(u).join(`fonts/${name}`);
  }
  put("vendor/fonts.css", css);
  html = html.replace(/<link rel="preconnect"[^>]*fonts\.g[^>]*>\s*/g, "");
  html = html.replace(cssUrl, "vendor/fonts.css");
} catch (e) { warnings.push("الخطوط: مقدرتش أنزّلها (" + e.message + "). التطبيق هيشتغل بخطوط النظام لو مفيش نت."); }

// 2ج) نص المصحف (عشان القراءة تشتغل أوفلاين من أول مرة)
for (const [key, file] of [["quran-uthmani", "quran-uthmani.json"], ["quran-tajweed", "quran-tajweed.json"]]) {
  const remote = `https://api.alquran.cloud/v1/quran/${key}`;
  try {
    put("data/" + file, await get(remote, file));
    for (const f of fs.readdirSync(WWW).filter(x => x.endsWith(".js") || x === "index.html")) {
      const p = path.join(WWW, f);
      const t = fs.readFileSync(p, "utf8");
      if (t.includes(remote)) { if (f === "index.html") html = html.split(remote).join("data/" + file); else fs.writeFileSync(p, t.split(remote).join("data/" + file)); }
    }
  } catch (e) { warnings.push(`نص المصحف (${key}): مقدرتش أنزّله، هيتحمّل من النت أول مرة. (${e.message})`); }
}

// 3) طبقة الأندرويد
const hasGS = fs.existsSync(path.join(root, "google-services.json")) || fs.existsSync(path.join(root, "android/app/google-services.json"));
if (!hasGS) warnings.push("google-services.json مش موجود: إشعارات FCM (رسائل المطوّر) مش هتشتغل لحد ما تحطه (شوف الدليل). الإشعارات المجدولة المحلية هتشتغل عادي.");
const siteUrl = String((pkg.wird && pkg.wird.siteUrl) || "").replace(/\/?$/, "/").replace(/^\/$/, "");
put("native-config.js", `window.NATIVE_SITE=${JSON.stringify(siteUrl)};window.NATIVE_CFG=${JSON.stringify({ appId: capCfg.appId, fcm: hasGS, version: pkg.version })};\n`);
await build({ entryPoints: [path.join(root, "native/native.js")], bundle: true, format: "iife", target: "chrome90", minify: true, outfile: path.join(WWW, "native.bundle.js"), logLevel: "warning" });

const inject = `<script src="native-config.js"></script><script src="native.bundle.js"></script>` +
  `<style>html.native body{padding-top:var(--safe-area-inset-top,env(safe-area-inset-top,0px));padding-bottom:var(--safe-area-inset-bottom,env(safe-area-inset-bottom,0px))}</style>`;
const m = html.match(/<meta name="viewport"[^>]*>/);
if (!m) throw new Error("مش لاقي وسم viewport في index.html");
html = html.replace(m[0], m[0] + inject);
fs.writeFileSync(path.join(WWW, "index.html"), html);

// فحص: أي مصادر خارجية لسه موجودة؟
const ext = [...new Set([...html.matchAll(/<(?:script|link)[^>]+(?:src|href)="(https?:[^"]+)"/g)].map(x => x[1]))];
if (ext.length) warnings.push("روابط خارجية لسه في index.html: " + ext.join(", "));

console.log("✔ www جاهز (" + (fs.readdirSync(WWW).length) + " عنصر) - نسخة " + pkg.version);
warnings.forEach(w => console.log("⚠ " + w));
