// بيشتغل بعد `npx cap add android` / `npx cap sync`: بيظبط الـ Manifest والأيقونة والإصدار (آمن تشغيله أكتر من مرة)
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const A = path.join(root, "android");
if (!fs.existsSync(A)) { console.error("مفيش مجلد android. شغّل الأول: npx cap add android"); process.exit(1); }
const pkg = JSON.parse(fs.readFileSync(path.join(root, "package.json"), "utf8"));

// 1) Manifest
const mp = path.join(A, "app/src/main/AndroidManifest.xml");
let mf = fs.readFileSync(mp, "utf8");
const perms = ["ACCESS_COARSE_LOCATION", "ACCESS_FINE_LOCATION", "POST_NOTIFICATIONS", "SCHEDULE_EXACT_ALARM", "VIBRATE", "RECEIVE_BOOT_COMPLETED", "USE_BIOMETRIC"];
const add = perms.filter(p => !mf.includes(`android.permission.${p}"`)).map(p => `    <uses-permission android:name="android.permission.${p}" />`);
if (add.length) mf = mf.replace("</manifest>", add.join("\n") + "\n</manifest>");
mf = mf.replace('android:allowBackup="true"', 'android:allowBackup="false"');
if (!mf.includes("supportsRtl")) mf = mf.replace("<application", '<application android:supportsRtl="true"');
if (!mf.includes("default_notification_icon"))
  mf = mf.replace("</application>", `        <meta-data android:name="com.google.firebase.messaging.default_notification_icon" android:resource="@drawable/ic_stat_wird" />\n        <meta-data android:name="com.google.firebase.messaging.default_notification_channel_id" android:value="wird_push" />\n    </application>`);
fs.writeFileSync(mp, mf);

// 2) أيقونة الإشعار
const dr = path.join(A, "app/src/main/res/drawable");
fs.mkdirSync(dr, { recursive: true });
fs.copyFileSync(path.join(root, "android-res/drawable/ic_stat_wird.xml"), path.join(dr, "ic_stat_wird.xml"));

// 3) google-services.json
const gs = path.join(root, "google-services.json");
if (fs.existsSync(gs)) { fs.copyFileSync(gs, path.join(A, "app/google-services.json")); console.log("✔ google-services.json اتنسخ"); }
else console.log("⚠ مفيش google-services.json في جذر المشروع (مطلوب لـ FCM)");

// 4) رقم الإصدار
const gp = path.join(A, "app/build.gradle");
let g = fs.readFileSync(gp, "utf8");
const vc = (pkg.wird && pkg.wird.versionCode) || 1;
if (/versionCode\s+\d+/.test(g)) g = g.replace(/versionCode\s+\d+/, `versionCode ${vc}`); else console.log("⚠ مش لاقي versionCode في build.gradle، غيّره يدويًا");
if (/versionName\s+"[^"]*"/.test(g)) g = g.replace(/versionName\s+"[^"]*"/, `versionName "${pkg.version}"`); else console.log("⚠ مش لاقي versionName في build.gradle");
fs.writeFileSync(gp, g);
console.log(`✔ android جاهز: versionName ${pkg.version} / versionCode ${vc}`);
