/* ---------- State ---------- */
var products=[], lang='bn', view='home', editId=null, detailId=null, filter='all', query='', modalCb=null, toastTimer=null;

/* ---------- Helpers ---------- */
function $(s){return document.querySelector(s);}
function $$(s){return Array.prototype.slice.call(document.querySelectorAll(s));}
function t(k){var d=T[lang]||T.bn;return d[k]!==undefined?d[k]:(T.bn[k]!==undefined?T.bn[k]:k);}
function fill(s,o){return s.replace(/\{(\w+)\}/g,function(m,k){return o[k]!==undefined?o[k]:m;});}
function esc(s){return String(s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
function str(v,max){return (typeof v==='string'||typeof v==='number')?String(v).trim().slice(0,max):'';}
function pad(n){return (n<10?'0':'')+n;}
function uid(){return Date.now().toString(36)+Math.random().toString(36).slice(2,8);}
function num(n){try{return Number(n).toLocaleString(lang==='bn'?'bn-BD':'en-US');}catch(e){return String(n);}}

function parseDate(s){
  if(typeof s!=='string')return null;
  var m=/^(\d{4})-(\d{2})-(\d{2})$/.exec(s);if(!m)return null;
  var y=+m[1],mo=+m[2],d=+m[3];
  var dt=new Date(Date.UTC(y,mo-1,d));
  if(dt.getUTCFullYear()!==y||dt.getUTCMonth()!==mo-1||dt.getUTCDate()!==d)return null;
  if(y<1990||y>2200)return null;
  return {y:y,m:mo,d:d};
}
function addMonths(s,n){
  var p=parseDate(s);if(!p||!isFinite(n))return '';
  var tot=p.m-1+n, ny=p.y+Math.floor(tot/12), nm=((tot%12)+12)%12;
  var dim=new Date(Date.UTC(ny,nm+1,0)).getUTCDate();
  return ny+'-'+pad(nm+1)+'-'+pad(Math.min(p.d,dim));
}
function todayStr(){var d=new Date();return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());}
function dayDiff(a,b){
  var x=parseDate(a),y=parseDate(b);if(!x||!y)return 0;
  return Math.round((Date.UTC(y.y,y.m-1,y.d)-Date.UTC(x.y,x.m-1,x.d))/86400000);
}
function fmtDate(s){
  var p=parseDate(s);if(!p)return s||'—';
  try{return new Date(Date.UTC(p.y,p.m-1,p.d)).toLocaleDateString(lang==='bn'?'bn-BD':'en-GB',{day:'numeric',month:'short',year:'numeric',timeZone:'UTC'});}
  catch(e){return s;}
}
function wstatus(p){
  var left=dayDiff(todayStr(),p.expiryDate), total=dayDiff(p.purchaseDate,p.expiryDate);
  var k=left<0?'expired':(left<=SOON_DAYS?'expiring':'active');
  var pct=total>0?Math.max(0,Math.min(100,left/total*100)):0;
  return {k:k,left:left,pct:pct};
}
function leftTxt(s){
  if(s.left<0)return fill(t('ago'),{n:num(-s.left)});
  if(s.left===0)return t('today');
  return fill(t('left'),{n:num(s.left)});
}

/* ---------- Storage ---------- */
function clean(o){
  if(!o||typeof o!=='object')return null;
  var name=str(o.name,100);if(!name)return null;
  var pd=str(o.purchaseDate,10);if(!parseDate(pd))return null;
  var m=Math.floor(Number(o.months));if(!(m>=1&&m<=120))return null;
  return {
    id:str(o.id,40)||uid(), name:name, brand:str(o.brand,60),
    category:CATS.indexOf(o.category)>-1?o.category:'other',
    purchaseDate:pd, months:m, expiryDate:addMonths(pd,m),
    shop:str(o.shop,80), serial:str(o.serial,60), notes:str(o.notes,500),
    createdAt:Number(o.createdAt)||Date.now()
  };
}
function load(){
  try{
    var raw=localStorage.getItem(KEY);if(!raw)return [];
    var a=JSON.parse(raw);if(!Array.isArray(a))return [];
    var seen={},out=[];
    a.forEach(function(x){var c=clean(x);if(c&&!seen[c.id]){seen[c.id]=1;out.push(c);}});
    return out;
  }catch(e){return [];}
}
function persist(){
  try{localStorage.setItem(KEY,JSON.stringify(products));return true;}
  catch(e){toast(t('eStore'));return false;}
}

/* ---------- UI helpers ---------- */
function toast(msg){
  var el=$('#toast');el.textContent=msg;el.classList.add('on');
  clearTimeout(toastTimer);toastTimer=setTimeout(function(){el.classList.remove('on');},2400);
}
function ask(title,msg,okLabel,cb){
  $('#m-title').textContent=title;$('#m-msg').textContent=msg;
  $('#m-ok').textContent=okLabel;$('#m-cancel').textContent=t('cancel');
  modalCb=cb;$('#modal').classList.add('on');
}
function closeModal(){$('#modal').classList.remove('on');modalCb=null;}

function applyLang(){
  document.documentElement.lang=lang;
  $$('[data-i]').forEach(function(el){el.textContent=t(el.getAttribute('data-i'));});
  $$('[data-ph]').forEach(function(el){el.placeholder=t(el.getAttribute('data-ph'));});
  $('#langBtn').textContent=lang==='bn'?'EN':'বাংলা';
  $('#b-export').innerHTML=ic('down')+'<span>'+esc(t('exportBtn'))+'</span>';
  $('#b-import').innerHTML=ic('up')+'<span>'+esc(t('importBtn'))+'</span>';
  var nav={home:['home','navHome'],list:['list','navList'],form:['plus','navAdd'],settings:['settings','navBackup']};
  Object.keys(nav).forEach(function(k){
    var inner=k==='form'?'<i>'+ic(nav[k][0])+'</i>':ic(nav[k][0]);
    $('#n-'+k).innerHTML=inner+'<span>'+esc(t(nav[k][1]))+'</span>';
  });
  $('#formBack').innerHTML=ic('back')+'<span>'+esc(t('back'))+'</span>';
  $('#p-search').setAttribute('d',ICONS.search);
  $('#lockIc').innerHTML=ic('lock');
  var sel=$('#f-cat'),cur=sel.value||'electronics';
  sel.innerHTML=CATS.map(function(c){return '<option value="'+c+'">'+esc(t('cat_'+c))+'</option>';}).join('');
  sel.value=cur;
  $('#l-bn').classList.toggle('g',lang!=='bn');$('#l-en').classList.toggle('g',lang!=='en');
  updateFormTexts();updateExpiryPreview();renderAll();
}
function updateFormTexts(){
  $('#formTitle').textContent=t(editId?'editTitle':'addTitle');
  $('#saveBtn').textContent=t(editId?'update':'save');
}

/* ---------- Rendering ---------- */
function card(p){
  var s=wstatus(p);
  var sub=[p.brand,t('cat_'+p.category)].filter(Boolean).join(' • ');
  return '<div class="card pc" data-act="open" data-id="'+esc(p.id)+'"><div class="pi '+s.k+'">'+ic('shield')+'</div>'+
    '<div class="pm"><b>'+esc(p.name)+'</b><small>'+esc(sub)+'</small><div class="bar"><i class="'+s.k+'" style="width:'+s.pct+'%"></i></div><small>'+esc(leftTxt(s))+'</small></div>'+
    '<span class="badge '+s.k+'">'+esc(t('st_'+s.k))+'</span></div>';
}
function emptyBox(title,hint,withBtn){
  return '<div class="card empty"><div class="ic">'+ic('box')+'</div><b>'+esc(title)+'</b><p style="margin:6px 0 0">'+esc(hint||'')+'</p>'+
    (withBtn?'<div style="margin-top:14px"><button class="btn" type="button" data-act="nav" data-v="form">'+ic('plus')+'<span>'+esc(t('addFirst'))+'</span></button></div>':'')+'</div>';
}
function renderHome(){
  var c={active:0,expiring:0,expired:0};
  products.forEach(function(p){c[wstatus(p).k]++;});
  var items=[['all','total','box','t',products.length],['active','active','check','active',c.active],['expiring','expiring','clock','expiring',c.expiring],['expired','expired','alert','expired',c.expired]];
  $('#stats').innerHTML=items.map(function(i){
    return '<button type="button" class="card st" data-act="stat" data-f="'+i[0]+'"><div class="ic '+i[3]+'">'+ic(i[2])+'</div><b>'+num(i[4])+'</b><span>'+esc(t(i[1]))+'</span></button>';
  }).join('');
  var soon=products.filter(function(p){return wstatus(p).k==='expiring';}).sort(function(a,b){return wstatus(a).left-wstatus(b).left;}).slice(0,5);
  $('#soonList').innerHTML=soon.length?soon.map(card).join(''):(products.length?'<div class="card" style="color:var(--mu)">'+esc(t('soonNone'))+'</div>':emptyBox(t('empty'),t('emptyHint'),true));
}
function renderList(){
  var q=query.trim().toLowerCase();
  var arr=products.filter(function(p){
    if(filter!=='all'&&wstatus(p).k!==filter)return false;
    if(!q)return true;
    return (p.name+' '+p.brand+' '+p.serial+' '+p.shop).toLowerCase().indexOf(q)>-1;
  }).sort(function(a,b){return wstatus(a).left-wstatus(b).left;});
  $('#plist').innerHTML=arr.length?arr.map(card).join(''):(products.length?emptyBox(t('noMatch'),'',false):emptyBox(t('empty'),t('emptyHint'),true));
  $$('#chips .chip').forEach(function(ch){ch.classList.toggle('on',ch.getAttribute('data-f')===filter);});
}
function renderDetail(){
  var p=products.filter(function(x){return x.id===detailId;})[0];
  if(!p){$('#detail').innerHTML=emptyBox(t('detMissing'),'',false);return;}
  var s=wstatus(p);
  function r(k,v){return v?'<div class="dr"><span>'+esc(t(k).replace(' *',''))+'</span><span>'+esc(v)+'</span></div>':'';}
  $('#detail').innerHTML=
   '<div class="card"><div style="display:flex;gap:12px;align-items:center"><div class="pi '+s.k+'">'+ic('shield')+'</div><div style="flex:1;min-width:0"><b style="font-size:17px;word-break:break-word">'+esc(p.name)+'</b><br><small>'+esc(leftTxt(s))+'</small></div><span class="badge '+s.k+'">'+esc(t('st_'+s.k))+'</span></div>'+
   '<div class="bar" style="margin-top:14px"><i class="'+s.k+'" style="width:'+s.pct+'%"></i></div></div>'+
   '<div class="card">'+r('lBrand',p.brand)+r('lCat',t('cat_'+p.category))+r('lPurchase',fmtDate(p.purchaseDate))+r('lMonths',num(p.months)+' '+t('monthsUnit'))+r('lExpiry',fmtDate(p.expiryDate))+r('lShop',p.shop)+r('lSerial',p.serial)+r('lNotes',p.notes)+'</div>'+
   '<div class="row"><button class="btn g" type="button" data-act="edit" data-id="'+esc(p.id)+'">'+ic('edit')+'<span>'+esc(t('edit'))+'</span></button>'+
   '<button class="btn d" type="button" data-act="del" data-id="'+esc(p.id)+'">'+ic('trash')+'<span>'+esc(t('del'))+'</span></button></div>';
}
function renderAll(){
  if(view==='home')renderHome();
  if(view==='list')renderList();
  if(view==='detail')renderDetail();
}
/* AKASH Warranty Keeper - part 2 (app1.js আগে লোড হতে হবে) */
