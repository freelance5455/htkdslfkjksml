/* JOSTECH — MANUEL 01 : INFORMATIQUE GÉNÉRALE */
registerDisciplineLevels(1, {
  1: {
    label: "Niveau 1 — Fondamental",
    subtitle: "Fondements des sciences informatiques, architecture matérielle et systèmes de numération.",
    chapters: [{
      id: "ig-1-1",
      title: "Chapitre 1 : Fondements et Architecture des Ordinateurs",
      lessons: [
        {
          id: "ig-1-1-1",
          title: "Leçon 1 : La science informatique et le Modèle de Von Neumann",
          duration: "25 min",
          objectives: [
            "Distinguer l'outil (l'ordinateur) de la discipline scientifique (l'informatique).",
            "Comprendre l'évolution historique des calculateurs aux ordinateurs à programme enregistré.",
            "Analyser les 4 composantes du modèle de Von Neumann et leurs bus.",
            "Suivre étape par étape le cycle d'exécution d'une instruction machine."
          ],
          prerequisites: ["Aucun prérequis technique. Notions générales de raisonnement logique."],
          sections: [
            {
              type: "definition",
              term: "Informatique (Computer Science)",
              text: "Terme proposé en 1962 par Philippe Dreyfus à partir des mots « information » et « automatique ». Sur le plan universitaire, l'informatique est la science du traitement rationnel et automatique de l'information, support des connaissances humaines et des communications.\n\nAttention à ne pas confondre l'informatique (science des algorithmes, des données et des systèmes) avec la bureautique (simple utilisation de logiciels)."
            },
            {
              type: "theory",
              title: "1. De l'automate figé à l'ordinateur programmable",
              text: "Avant 1945, les premières machines électroniques comme l'ENIAC devaient être recâblées à la main pendant des jours à chaque changement de calcul : le programme était figé dans le matériel.\n\nEn juin 1945, le mathématicien John von Neumann décrit l'architecture à programme enregistré (Stored-Program Computer) : les instructions sont codées comme des nombres et stockées dans la même mémoire que les données. Pour changer de tâche, il suffit donc de charger un autre logiciel en mémoire.",
              bullets: [
                "Avant 1945 : Machine spécialisée = 1 circuit physique par tâche.",
                "Après 1945 (Von Neumann) : Machine universelle = 1 matériel capable d'exécuter une infinité de logiciels."
              ]
            },
            {
              type: "table",
              title: "2. Anatomie complète du modèle de Von Neumann",
              headers: ["Organe", "Rôle détaillé", "Sous-éléments clés"],
              rows: [
                ["Unité Arithmétique et Logique (UAL)", "Calculateur pur : opérations arithmétiques (+, -, ×, ÷) et logiques (=, <, >, ET, OU).", "Additionneur, comparateur, registres d'état"],
                ["Unité de Contrôle (UC)", "Chef d'orchestre : lit les instructions en RAM, les décode et pilote les autres organes.", "Compteur ordinal (PC), registre d'instruction (IR), horloge"],
                ["Mémoire Centrale (RAM)", "Tableau géant de cases numérotées contenant données et instructions du programme actif.", "Cellules volatiles, bus d'adresses"],
                ["Entrées / Sorties (E/S)", "Dialoguent avec l'utilisateur, le réseau et le stockage permanent.", "Écran tactile, clavier, carte Wi-Fi, SSD"]
              ]
            },
            {
              type: "code",
              lang: "Schéma détaillé : Le cycle Fetch-Decode-Execute",
              code: [
                "Instruction en RAM à l'adresse 100 : ADD R1, R2 (Additionner R1 et R2)",
                "",
                "1. FETCH (Recherche) :",
                "   - Le Compteur Ordinal (PC) contient l'adresse 100.",
                "   - L'UC place 100 sur le bus d'adresses et lit la RAM.",
                "   - L'instruction revient via le bus de données vers l'IR.",
                "   - Le PC passe à 101 pour préparer l'instruction suivante.",
                "",
                "2. DECODE (Décodage) : L'UC reconnaît l'ordre ADD.",
                "3. EXECUTE (Exécution) : L'UAL additionne les registres R1 et R2.",
                "4. STORE (Écriture) : Le résultat est enregistré."
              ].join("\n")
            },
            {
              type: "example",
              title: "Ce qui se passe quand vous ouvrez une app Android",
              text: "Quand vous touchez une icône (Entrée), Android copie le programme du stockage permanent (Flash/SSD) vers la RAM, car le processeur ne peut exécuter rapidement que ce qui est en RAM. Puis l'UC et l'UAL exécutent des milliards de cycles par seconde pour afficher l'écran (Sortie)."
            }
          ],
          exercise: {
            question: "Un processeur cadencé à 2,4 GHz exécute un programme en RAM.\n1) Pourquoi copier un programme du disque vers la RAM avant exécution ?\n2) Quel registre de l'UC indique l'adresse de la prochaine instruction ?",
            solution: "1) Le stockage permanent est des milliers de fois plus lent que la RAM. Le processeur exécute directement depuis la RAM (modèle de Von Neumann).\n2) C'est le Compteur Ordinal (Program Counter ou PC)."
          },
          summary: "L'architecture de Von Neumann unifie programmes et données en RAM, pilotés par le processeur (UC + UAL) via le cycle en 4 temps : Fetch, Decode, Execute, Store.",
          references: [
            "Tanenbaum, A. S. — Architecture de l'ordinateur, Pearson.",
            "Von Neumann, J. (1945) — First Draft of a Report on the EDVAC."
          ]
        },
        {
          id: "ig-1-1-2",
          title: "Leçon 2 : Systèmes de numération et codage de l'information",
          duration: "30 min",
          objectives: [
            "Comprendre pourquoi le matériel utilise la base 2 (binaire).",
            "Convertir entre décimal (base 10), binaire (base 2) et hexadécimal (base 16).",
            "Maîtriser bit, octet et encodage des caractères (ASCII / UTF-8)."
          ],
          prerequisites: ["Division euclidienne et puissances de 2."],
          sections: [
            {
              type: "theory",
              title: "1. Pourquoi compter uniquement avec 0 et 1 ?",
              text: "Un microprocesseur contient des milliards de transistors agissant comme des interrupteurs microscopiques : soit le courant est bloqué (0), soit il passe (1). Utiliser 10 tensions différentes provoquerait des erreurs à cause des parasites électriques. Avec deux états stables (binaire, base 2), la fiabilité est quasi parfaite."
            },
            {
              type: "definition",
              term: "Bit, Octet et Poids binaire",
              text: "Un bit vaut 0 ou 1. Un octet (byte) regroupe 8 bits, offrant 2⁸ = 256 combinaisons possibles (de 0 à 255). En binaire, chaque colonne de droite à gauche vaut une puissance de 2 : 1, 2, 4, 8, 16, 32, 64, 128."
            },
            {
              type: "code",
              lang: "Démonstrations : Binaire ↔ Décimal ↔ Hexadécimal",
              code: [
                "A) Binaire → Décimal : exemple 101101 (2)",
                "   Poids  : 32  16   8   4   2   1",
                "   Bits   :  1   0   1   1   0   1",
                "   Calcul : 32 + 0 + 8 + 4 + 0 + 1 = 45 (base 10)",
                "",
                "B) Décimal → Binaire (divisions par 2) : exemple 45",
                "   45 ÷ 2 = 22 reste 1 (droite)",
                "   22 ÷ 2 = 11 reste 0",
                "   11 ÷ 2 =  5 reste 1",
                "    5 ÷ 2 =  2 reste 1",
                "    2 ÷ 2 =  1 reste 0",
                "    1 ÷ 2 =  0 reste 1 (gauche)",
                "   Lecture bas → haut : 101101 (2)",
                "",
                "C) Hexadécimal (base 16 : 0..9 puis A=10..F=15)",
                "   1 chiffre hexa = exactement 4 bits :",
                "   101101 → 0010 | 1101  →  0010=2, 1101=13=D  →  2D (base 16)"
              ].join("\n")
            },
            {
              type: "table",
              title: "Codage des caractères : de l'ASCII à l'UTF-8",
              headers: ["Norme", "Taille", "Capacité"],
              rows: [
                ["ASCII", "7 bits (128 car.)", "Lettres anglaises, chiffres 0-9. Ex: 'A' = 65."],
                ["ISO-8859-1", "8 bits (256 car.)", "Ajoute les accents européens (é, è, ç)."],
                ["UTF-8 (Unicode)", "1 à 4 octets", "Standard mondial du Web : toutes les langues + émojis."]
              ]
            }
          ],
          exercise: {
            question: "1) Quelle valeur décimale représente l'octet 1100 1010 (2) ?\n2) Écrivez-le en hexadécimal.\n3) Sachant que 'A' = 65 en ASCII, quel est le code binaire sur 8 bits de 'D' ?",
            solution: "1) 128 + 64 + 8 + 2 = 202 (base 10).\n2) 1100 = 12 = C ; 1010 = 10 = A → CA (16).\n3) 'D' = 68 = 64 + 4 = 0100 0100 (2)."
          },
          summary: "Le binaire traduit le matériel, l'hexadécimal compresse l'écriture (4 bits par symbole) et UTF-8 encode universellement tous les textes en octets.",
          references: ["Delannoy, C. — Initiation à l'architecture des ordinateurs."]
        }
      ]
    }]
  },
  2: {
    label: "Niveau 2 — Intermédiaire",
    subtitle: "Algèbre de Boole, portes logiques et lois de De Morgan.",
    chapters: [{
      id: "ig-2-1",
      title: "Chapitre 2 : Logique Booléenne et Circuits",
      lessons: [{
        id: "ig-2-1-1",
        title: "Leçon 1 : Algèbre de Boole, Portes logiques et Lois de De Morgan",
        duration: "25 min",
        objectives: [
          "Maîtriser les opérateurs ET, OU, NON, NAND et XOR.",
          "Lire une table de vérité complète.",
          "Appliquer les lois de De Morgan en programmation et électronique."
        ],
        prerequisites: ["Niveau 1 — Binaire."],
        sections: [
          {
            type: "theory",
            title: "1. De la logique mathématique aux circuits",
            text: "En 1854, George Boole formalise une algèbre à deux valeurs : VRAI (1) et FAUX (0). En 1937, Claude Shannon prouve que cette algèbre permet de concevoir n'importe quel circuit électronique à interrupteurs. Chaque condition dans un logiciel (if) et chaque calcul du CPU repose dessus."
          },
          {
            type: "table",
            title: "Tables de vérité fondamentales",
            headers: ["A", "B", "A·B (ET)", "A+B (OU)", "A⊕B (XOR)", "NAND"],
            rows: [
              ["0", "0", "0", "0", "0", "1"],
              ["0", "1", "0", "1", "1", "1"],
              ["1", "0", "0", "1", "1", "1"],
              ["1", "1", "1", "1", "0", "0"]
            ]
          },
          {
            type: "definition",
            term: "Les deux Lois de De Morgan",
            text: "1) NON(A ET B) = (NON A) OU (NON B)\n2) NON(A OU B) = (NON A) ET (NON B)\nPour inverser une condition composée, on inverse chaque terme et on change ET en OU (et inversement)."
          }
        ],
        exercise: {
          question: "Une alarme sonne si l'utilisateur n'est PAS admin (NON A) OU si son badge est expiré (NON B). Par De Morgan, quelle est la condition inverse (accès autorisé) ?",
          solution: "NON((NON A) OU (NON B)) = A ET B : l'accès est autorisé uniquement s'il est admin ET que son badge est valide."
        },
        summary: "L'algèbre de Boole et les lois de De Morgan permettent de concevoir des circuits fiables et de simplifier des conditions logiques complexes.",
        references: ["Boole, G. (1854) — The Laws of Thought."]
      }]
    }]
  },
  3: {
    label: "Niveau 3 — Avancé & Universitaire",
    subtitle: "Microarchitecture CPU, hiérarchie mémoire et localité.",
    chapters: [{
      id: "ig-3-1",
      title: "Chapitre 3 : Microarchitecture et Performance Mémoire",
      lessons: [{
        id: "ig-3-1-1",
        title: "Leçon 1 : Goulot de Von Neumann, Caches et Localité",
        duration: "30 min",
        objectives: [
          "Analyser le goulot d'étranglement CPU / RAM (Memory Wall).",
          "Comprendre les caches L1, L2, L3.",
          "Exploiter la localité temporelle et spatiale."
        ],
        prerequisites: ["Niveaux 1 et 2."],
        sections: [
          {
            type: "theory",
            title: "1. Le mur de la mémoire (Memory Wall)",
            text: "Un cœur CPU à 3 GHz exécute un cycle en 0,33 ns, alors qu'un accès RAM prend environ 80 ns. Sans mémoire tampon intermédiaire, le processeur passerait 95 % de son temps à attendre ! C'est le goulot d'étranglement de Von Neumann, résolu par les caches SRAM intégrés sur la puce CPU."
          },
          {
            type: "table",
            title: "Pyramide hiérarchique des mémoires",
            headers: ["Niveau", "Capacité typique", "Latence"],
            rows: [
              ["Registres CPU", "Quelques octets", "0,3 ns"],
              ["Cache L1 / L2", "32 Ko à 2 Mo", "1 à 4 ns"],
              ["Cache L3", "8 Mo à 64 Mo", "15 ns"],
              ["RAM (DRAM)", "4 Go à 64 Go", "80 ns"],
              ["SSD NVMe", "256 Go à 4 To", "50 000 ns"]
            ]
          },
          {
            type: "definition",
            term: "Cache Hit/Miss et Principe de Localité",
            text: "Cache Hit : la donnée est déjà dans le cache. Cache Miss : il faut la charger depuis la RAM par blocs de 64 octets (lignes de cache).\n• Localité temporelle : une variable utilisée maintenant servira bientôt.\n• Localité spatiale : après l'adresse M, le CPU lira probablement M+1, M+2 (ex. tableau contigu)."
          }
        ],
        exercise: {
          question: "Un programme trouve 90 % de ses données en cache L1 (1 ns) et 10 % en RAM (80 ns). Calculez le temps moyen d'accès mémoire.",
          solution: "Temps moyen = (0,90 × 1) + (0,10 × 80) = 0,9 + 8 = 8,9 ns (presque 9× plus rapide que 80 ns sans cache)."
        },
        summary: "Comprendre les lignes de cache et la localité spatiale/temporelle est essentiel pour écrire des logiciels haute performance.",
        references: ["Hennessy & Patterson — Computer Architecture."]
      }]
    }]
  }
});