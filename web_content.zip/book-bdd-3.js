/* JOSTECH — MANUEL 07 : BASES DE DONNÉES NIVEAU 3 */
registerLessonDetail(7, 3, "bdd-3-1-1", {
  title: "Leçon 1 : Transactions ACID, Index B-Tree, Sauvegardes et SI",
  duration: "45 min (Manuel universitaire complet)",
  objectives: [
    "Garantir l'intégrité des opérations critiques via les propriétés ACID (BEGIN/COMMIT/ROLLBACK).",
    "Comprendre le fonctionnement interne des index B-Tree et le compromis lecture/écriture.",
    "Concevoir la stratégie de sauvegarde (RPO, RTO) et la gouvernance d'un Système d'Information."
  ],
  prerequisites: ["Niveau 2 — SQL et notions de complexité O(log n)."],
  sections: [
    {
      type: "definition",
      term: "Les 4 Propriétés ACID d'une Transaction",
      text: "Une transaction regroupe plusieurs requêtes SQL en une unité indivisible :\n• Atomicité (Tout ou rien) : si le virement débite A mais échoue à créditer B, ROLLBACK annule tout automatiquement.\n• Cohérence (Consistency) : la base passe d'un état valide à un autre état valide respectant toutes les contraintes.\n• Isolation : deux transactions concurrentes ne lisent pas des états intermédiaires sales (Dirty Reads).\n• Durabilité : une fois COMMIT confirmé sur disque (journal WAL), les données survivent à une coupure de courant."
    },
    {
      type: "theory",
      title: "1. Comment un Index B-Tree accélère-t-il SQL de O(n) à O(log n) ?",
      text: "Sans index sur la colonne email dans une table de 5 millions d'étudiants, PostgreSQL doit faire un « Sequential Scan » : lire les 5 millions de lignes une par une (très lent !). En exécutant « CREATE INDEX idx_email ON etudiants(email); », le SGBD construit un arbre équilibré (B-Tree) trié en arrière-plan : il trouve n'importe quel étudiant en 3 ou 4 sauts de pages disque !\n\nContrepartie : chaque index occupe de l'espace disque et ralentit légèrement INSERT/UPDATE/DELETE car le SGBD doit aussi mettre à jour l'arbre."
    },
    {
      type: "table",
      title: "2. Gestion du SI : Sauvegardes, RPO et RTO",
      headers: ["Indicateur / Stratégie", "Signification concrète"],
      rows: [
        ["RPO (Recovery Point Objective)", "Perte de données maximale tolérable (ex: RPO = 1 heure → sauvegarde incrémentale toutes les heures)."],
        ["RTO (Recovery Time Objective)", "Durée maximale d'arrêt acceptable après panne avant remise en service."],
        ["Principe du moindre privilège (RBAC)", "L'application Web n'a jamais les droits super-admin (DROP TABLE) sur la base."]
      ]
    },
    {
      type: "warning",
      title: "Le mythe de la sauvegarde jamais testée",
      text: "Une sauvegarde automatique qui n'a jamais fait l'objet d'un test réel de restauration (pg_restore) est une illusion dangereuse : de nombreuses entreprises découvrent le jour d'un sinistre que leurs archives étaient corrompues ou vides !"
    }
  ],
  exercises: [
    {
      title: "Exercice 1 — Écrire une transaction bancaire sûre",
      question: "Rédigez le squelette SQL d'une transaction transférant 50 000 FC du compte 1 vers le compte 2.",
      solution: "BEGIN;\nUPDATE comptes SET solde = solde - 50000 WHERE id = 1 AND solde >= 50000;\nUPDATE comptes SET solde = solde + 50000 WHERE id = 2;\nCOMMIT; -- (Ou ROLLBACK en cas d'erreur)"
    },
    {
      title: "Exercice 2 — Arbitrage d'indexation",
      question: "Pourquoi ne doit-on pas créer un index sur TOUTES les 20 colonnes d'une table qui reçoit 10 000 écritures par seconde (table de logs) ?",
      solution: "Parce que chaque INSERT devrait mettre à jour 20 arbres B-Tree différents sur le disque, effondrant les performances d'écriture et multipliant la taille de la base."
    }
  ],
  summary: "Les transactions ACID protègent les données critiques, les index B-Tree accélèrent les requêtes sélectives, et la gouvernance d'un SI s'appuie sur le RBAC et des sauvegardes testées selon les objectifs RPO/RTO.",
  references: ["Kleppmann, M. — Designing Data-Intensive Applications, O'Reilly.", "Winand, M. — SQL Performance Explained."]
});