package uz.yordamchi

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class Cmd(val action: String = "none", val target: String = "", val text: String = "")

object Brain {
    private const val SYS = "Foydalanuvchining ovozli buyrug'ini (o'zbek, rus yoki ingliz tilida) JSON ga aylantir. " +
        "Faqat JSON qaytar, boshqa hech narsa yozma: " +
        "{\"action\":\"call|sms|telegram|whatsapp|instagram_dm|instagram_follow|claude|music|open_app|search|alarm|none\"," +
        "\"target\":\"odam ismi / ilova nomi / instagram username / qo'shiq yoki qidiruv so'rovi / alarm uchun HH:MM\"," +
        "\"text\":\"yuboriladigan xabar yoki Claude'ga beriladigan prompt\"}"
    private val JUNK = setOf("shu", "odamga", "deb", "ga", "ka", "qa", "ni", "ning", "tashla", "yubor", "yoz", "qil", "bol", "bos")
    private val CALL = setOf("qongiroq", "tel", "telefon", "call", "позвони")
    private val FOL = setOf("bolish", "podpiska", "follow")
    private val MW = setOf("qoy", "qoying", "ijro", "et", "ni", "ning", "play", "musiqa")
    private val VERBS = setOf("yoz", "yubor", "tashla", "jonat", "jonating", "yozing", "yuboring")

    fun parse(said: String, key: String): Cmd {
        if (key.isNotBlank()) try { return viaClaude(said, key) } catch (e: Exception) { }
        return viaRules(said)
    }

    private fun viaClaude(said: String, key: String): Cmd {
        val body = JSONObject().put("model", "claude-haiku-5-5").put("max_tokens", 200).put("system", SYS)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", said)))
        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 8000; c.readTimeout = 15000
        c.setRequestProperty("x-api-key", key)
        c.setRequestProperty("anthropic-version", "2023-06-01")
        c.setRequestProperty("content-type", "application/json")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val txt = JSONObject(c.inputStream.bufferedReader().readText())
            .getJSONArray("content").getJSONObject(0).getString("text")
        val j = JSONObject(txt.substring(txt.indexOf('{'), txt.lastIndexOf('}') + 1))
        return Cmd(j.optString("action", "none"), j.optString("target"), j.optString("text"))
    }

    // Kalitsiz zaxira: oddiy o'zbekcha qoliplar
    fun viaRules(raw: String): Cmd {
        val w = raw.lowercase().replace("‘", "'").replace("’", "'").replace("ʻ", "'").replace("`", "'")
            .split(" ").filter { it.isNotBlank() }
        val n = w.map { it.replace("'", "") }
        fun has(vararg k: String) = n.any { t -> k.any { t.startsWith(it) } }
        fun idx(vararg k: String) = n.indexOfFirst { t -> k.any { t.startsWith(it) } }
        fun keep(from: Int, to: Int) = (from until to).filter { n[it] !in JUNK }.map { w[it] }
        val callAt = n.indexOfFirst { it in CALL || it.startsWith("qongiroq") }
        val openAt = n.indexOfFirst { it == "och" || it == "ochib" }

        return when {
            has("claude", "cloude", "klod") -> {
                var t = w.drop(idx("claude", "cloude", "klod") + 1)
                    .filter { it.replace("'", "") !in setOf("shu", "promptni", "prompt", "deb") }
                if (t.firstOrNull() in setOf("ga", "ka", "qa")) t = t.drop(1)
                while (t.isNotEmpty() && t.last().replace("'", "") in VERBS) t = t.dropLast(1)
                Cmd("claude", text = t.joinToString(" "))
            }
            callAt >= 0 -> Cmd("call", keep(0, callAt).lastOrNull() ?: w.getOrNull(callAt + 1) ?: "")
            has("obuna", "podpiska", "подпис", "follow") ->
                Cmd("instagram_follow", w.indices.filter {
                    n[it] !in JUNK && n[it] !in FOL && !n[it].startsWith("instagram") && !n[it].startsWith("obuna")
                }.map { w[it] }.firstOrNull() ?: "")
            has("musiqa", "qoshiq", "play", "музык") ->
                Cmd("music", target = w.indices.filter {
                    n[it] !in MW && !n[it].startsWith("musiqa") && !n[it].startsWith("qoshiq")
                }.joinToString(" ") { w[it] })
            openAt >= 0 -> Cmd("open_app", keep(0, openAt).joinToString(" "))
            has("qidir", "izla", "google") ->
                Cmd("search", text = w.indices.filter {
                    n[it] !in JUNK && !n[it].startsWith("qidir") && !n[it].startsWith("izla") && !n[it].startsWith("google")
                }.joinToString(" ") { w[it] })
            else -> {
                val pi = n.indexOfFirst {
                    it.startsWith("telegram") || it.startsWith("instagram") || it.startsWith("whatsapp") ||
                        it.startsWith("vatsap") || it == "sms"
                }
                val act = when {
                    pi < 0 -> if (has("yoz", "yubor", "jonat", "tashla")) "sms" else "none"
                    n[pi].startsWith("telegram") -> "telegram"
                    n[pi].startsWith("instagram") -> "instagram_dm"
                    n[pi] == "sms" -> "sms"
                    else -> "whatsapp"
                }
                if (act == "none") return Cmd()
                val st = pi + 1
                val tgt = w.getOrNull(st) ?: ""
                var ms = st + 1
                if (n.getOrNull(ms) in setOf("ga", "ka", "qa")) ms++
                val d = n.indexOf("deb")
                val text = if (d > ms) w.subList(ms, d).joinToString(" ")
                else w.drop(ms).filterIndexed { i, _ -> n[ms + i] !in VERBS }.joinToString(" ")
                Cmd(act, tgt, text)
            }
        }
    }
}
