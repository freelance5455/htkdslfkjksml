package uz.yordamchi

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.telephony.SmsManager

object Actions {
    private val SEND = listOf("Send", "Yuborish", "Отправить")

    // "Aliga" -> ["Aliga", "Ali"]
    private fun names(t: String): List<String> {
        val x = t.trim()
        return if (x.length > 3 && (x.endsWith("ga") || x.endsWith("ka") || x.endsWith("qa") || x.endsWith("ni")))
            listOf(x, x.dropLast(2)) else listOf(x)
    }

    private fun number(c: Context, t: String): String? {
        if (t.any { it.isDigit() }) return t.filter { it.isDigit() || it == '+' }
        for (nm in names(t)) {
            c.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$nm%"), null
            )?.use { if (it.moveToFirst()) return it.getString(0) }
        }
        return null
    }

    private fun go(c: Context, i: Intent) = c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

    private fun share(c: Context, pkg: String, text: String): Boolean = try {
        go(c, Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text).setPackage(pkg)); true
    } catch (e: Exception) { false }

    private const val NEED_ACC = "Maxsus imkoniyatlarda “Yordamchi”ni yoqing"

    private fun viaShare(c: Context, m: Cmd, vararg pkgs: String): String {
        if (AutoService.inst == null) return NEED_ACC
        if (pkgs.none { share(c, it, m.text) }) return "Ilova topilmadi"
        AutoService.run(listOf(names(m.target), SEND)) // ro'yxatdan odamni tanlab, "Yuborish"ni bosadi
        return "${m.target} ga yuborilmoqda"
    }

    private fun open(c: Context, name: String): String {
        val pm = c.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val a = apps.firstOrNull { ri ->
            names(name).any { nm -> ri.loadLabel(pm).toString().lowercase().contains(nm.lowercase()) }
        } ?: return "Ilova topilmadi: $name"
        go(c, pm.getLaunchIntentForPackage(a.activityInfo.packageName)!!)
        return "Ochildi: $name"
    }

    fun run(c: Context, m: Cmd): String = try {
        val q = m.target.ifBlank { m.text }
        when (m.action) {
            "call" -> {
                val num = number(c, m.target) ?: return "Kontakt topilmadi: ${m.target}"
                go(c, Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(num))))
                "Qo'ng'iroq: ${m.target}"
            }
            "sms" -> {
                val num = number(c, m.target) ?: return "Kontakt topilmadi: ${m.target}"
                if (m.text.isBlank()) return "Xabar matni bo'sh"
                val sm = if (Build.VERSION.SDK_INT >= 31) c.getSystemService(SmsManager::class.java)
                    else @Suppress("DEPRECATION") SmsManager.getDefault()
                sm.sendMultipartTextMessage(num, null, sm.divideMessage(m.text), null, null, null)
                "SMS yuborildi"
            }
            "telegram" -> viaShare(c, m, "org.telegram.messenger", "org.telegram.messenger.web")
            "whatsapp" -> viaShare(c, m, "com.whatsapp", "com.whatsapp.w4b")
            "instagram_dm" -> viaShare(c, m, "com.instagram.android")
            "instagram_follow" -> {
                if (AutoService.inst == null) return NEED_ACC
                go(c, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com/_u/" + m.target.replace(" ", "")))
                    .setPackage("com.instagram.android"))
                AutoService.run(listOf(listOf("Follow", "Obuna bo'lish", "Obuna bo‘lish", "Подписаться")))
                "Obuna bosilmoqda: ${m.target}"
            }
            "claude" -> {
                if (!share(c, "com.anthropic.claude", m.text))
                    go(c, Intent(Intent.ACTION_VIEW, Uri.parse("https://claude.ai/new?q=" + Uri.encode(m.text))))
                AutoService.run(listOf(listOf("Send message", "Send", "Yuborish")))
                "Claude'ga yuborilmoqda"
            }
            "music" -> {
                try {
                    go(c, Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
                        .putExtra(SearchManager.QUERY, q)
                        .putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*"))
                } catch (e: Exception) {
                    go(c, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))))
                }
                "Musiqa: $q"
            }
            "open_app" -> open(c, q)
            "search" -> {
                go(c, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))
                "Qidirilmoqda: $q"
            }
            "alarm" -> {
                val (hh, mm) = m.target.split(":").map { it.trim().toInt() }
                go(c, Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, hh)
                    .putExtra(AlarmClock.EXTRA_MINUTES, mm).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
                "Budilnik: $hh:$mm"
            }
            else -> "Tushunmadim"
        }
    } catch (e: Exception) { "Xatolik: ${e.message}" }
}
