package uz.yordamchi

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView

    private val need = arrayOf(
        Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE,
        Manifest.permission.SEND_SMS, Manifest.permission.READ_CONTACTS
    )

    private fun granted(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    private fun permsOk() = need.all { granted(it) }
    private fun accOk(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains("$packageName/") && s.contains("AutoService")
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = 0xFF1B2B5A.toInt()
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            setBackgroundColor(0xFF1B2B5A.toInt())
            addJavascriptInterface(Bridge(), "Native")
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(web)
    }

    override fun onResume() {
        super.onResume()
        if (::web.isInitialized) web.evaluateJavascript("window.refresh && window.refresh()", null)
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (!permsOk()) {
            Toast.makeText(this, "Ruxsatlar to'liq emas. Sozlamalarda hammasini yoqing", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
        web.evaluateJavascript("window.refresh && window.refresh()", null)
    }

    inner class Bridge {
        @JavascriptInterface
        fun state(): String {
            val p = getSharedPreferences("s", 0)
            return JSONObject()
                .put("perms", permsOk())
                .put("overlay", Settings.canDrawOverlays(this@MainActivity))
                .put("acc", accOk())
                .put("on", VoiceService.running)
                .put("wake", p.getString("wake", "jarvis"))
                .put("lang", p.getString("lang", "uz-UZ"))
                .put("key", p.getString("key", ""))
                .put("hist", JSONArray(p.getString("hist", "[]")))
                .toString()
        }

        @JavascriptInterface
        fun askPerms() {
            runOnUiThread {
                val l = need.toMutableList()
                if (Build.VERSION.SDK_INT >= 33) l.add("android.permission.POST_NOTIFICATIONS")
                requestPermissions(l.toTypedArray(), 1)
            }
        }

        @JavascriptInterface
        fun askOverlay() {
            runOnUiThread {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        }

        @JavascriptInterface
        fun openAcc() {
            runOnUiThread { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }

        @JavascriptInterface
        fun setOn(on: Boolean): Boolean {
            val i = Intent(this@MainActivity, VoiceService::class.java)
            if (on) {
                if (!granted(Manifest.permission.RECORD_AUDIO)) return false
                startForegroundService(i)
            } else stopService(i)
            return true
        }

        @JavascriptInterface
        fun save(wake: String, lang: String, key: String) {
            getSharedPreferences("s", 0).edit()
                .putString("wake", wake).putString("lang", lang).putString("key", key.trim()).apply()
        }
    }
}
