package uz.yordamchi

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

open class L : RecognitionListener {
    override fun onReadyForSpeech(p: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(v: Float) {}
    override fun onBufferReceived(b: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onError(e: Int) {}
    override fun onResults(r: Bundle?) {}
    override fun onPartialResults(p: Bundle?) {}
    override fun onEvent(t: Int, p: Bundle?) {}
}

class VoiceService : Service() {
    companion object {
        @Volatile var running = false
    }

    private var sr: SpeechRecognizer? = null
    private val h = Handler(Looper.getMainLooper())
    private var on = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (on) return START_STICKY
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("v", "Yordamchi", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "v").setContentTitle("Yordamchi tinglamoqda")
            .setContentIntent(open).setOngoing(true)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            else startForeground(1, n)
        } catch (e: Exception) {
            toast("Xatolik: ${e.message}"); stopSelf(); return START_NOT_STICKY
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            toast("Mikrofon ruxsati yo'q"); stopSelf(); return START_NOT_STICKY
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            toast("Telefonda Google ovoz xizmati topilmadi"); stopSelf(); return START_NOT_STICKY
        }
        on = true
        running = true
        listen()
        return START_STICKY
    }

    private fun listen() {
        if (!on) return
        sr?.destroy()
        val lang = getSharedPreferences("s", 0).getString("lang", "uz-UZ") ?: "uz-UZ"
        sr = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : L() {
                override fun onResults(r: Bundle?) {
                    r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.let { handle(it) }
                    h.postDelayed({ listen() }, 300)
                }

                override fun onError(e: Int) {
                    if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                        toast("Mikrofon ruxsati yo'q"); stopSelf(); return
                    }
                    h.postDelayed({ listen() }, if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500 else 400)
                }
            })
            startListening(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
                    .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            )
        }
    }

    private fun handle(cands: List<String>) {
        val p = getSharedPreferences("s", 0)
        val wake = (p.getString("wake", "jarvis") ?: "").lowercase().trim()
        val key = p.getString("key", "") ?: ""
        var said: String? = null
        if (wake.isEmpty()) said = cands.firstOrNull()
        else for (c in cands) {
            val i = c.lowercase().indexOf(wake)
            if (i >= 0) { said = c.substring(i + wake.length); break }
        }
        val cmdText = said?.trim() ?: return
        if (cmdText.isEmpty()) return
        Thread {
            val cmd = Brain.parse(cmdText, key)
            h.post {
                val res = if (cmd.action == "none") "Tushunmadim" else Actions.run(this, cmd)
                toast(res)
                addHist(cmd.action, cmdText, res)
            }
        }.start()
    }

    private fun icon(a: String) = when (a) {
        "call" -> "call"; "sms" -> "msg"
        "telegram", "whatsapp", "instagram_dm" -> "send"
        "instagram_follow" -> "heart"; "claude" -> "spark"
        "music" -> "music"; "alarm" -> "clock"; "open_app" -> "app"
        else -> "search"
    }

    private fun addHist(action: String, said: String, res: String) {
        val p = getSharedPreferences("s", 0)
        val old = try { JSONArray(p.getString("hist", "[]")) } catch (e: Exception) { JSONArray() }
        val arr = JSONArray().put(JSONObject().put("i", icon(action)).put("s", said).put("r", res))
        for (k in 0 until minOf(old.length(), 9)) arr.put(old.get(k))
        p.edit().putString("hist", arr.toString()).apply()
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    override fun onDestroy() {
        on = false; running = false
        h.removeCallbacksAndMessages(null)
        sr?.destroy()
        super.onDestroy()
    }
}
