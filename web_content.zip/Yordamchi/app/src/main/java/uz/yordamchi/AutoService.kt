package uz.yordamchi

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

// Boshqa ilovalarda tugmalarni ekrandan topib bosadi (odam o'rniga).
class AutoService : AccessibilityService() {
    companion object {
        @Volatile var inst: AutoService? = null
        fun run(steps: List<List<String>>) { inst?.exec(steps) }
    }

    private val h = Handler(Looper.getMainLooper())

    override fun onServiceConnected() { inst = this }

    override fun onUnbind(i: Intent?): Boolean {
        inst = null
        h.removeCallbacksAndMessages(null)
        return super.onUnbind(i)
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    // Har qadam: shu matnlardan birini ekranda topib bosadi (har qadamda 25 marta urinadi).
    // Hammasi asosiy (UI) thread'da ishlaydi, shuning uchun oqimlar aralashmaydi.
    private fun exec(steps: List<List<String>>) {
        h.removeCallbacksAndMessages(null)
        step(steps, 0, 0, 2500)
    }

    private fun step(steps: List<List<String>>, idx: Int, tries: Int, delay: Long) {
        if (idx >= steps.size) return
        h.postDelayed({
            if (click(steps[idx])) step(steps, idx + 1, 0, 900)
            else if (tries < 25) step(steps, idx, tries + 1, 400)
        }, delay)
    }

    private fun click(texts: List<String>): Boolean {
        val root = rootInActiveWindow ?: return false
        for (t in texts) for (nd in root.findAccessibilityNodeInfosByText(t)) {
            var x: AccessibilityNodeInfo? = nd
            while (x != null && !x.isClickable) x = x.parent
            if (x != null && x.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        }
        return false
    }
}
