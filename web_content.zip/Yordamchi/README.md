# Yordamchi (Android)

Ovozli yordamchi: buyruqni ovoz bilan aytasiz, ilova qo'ng'iroq qiladi, SMS yuboradi,
Telegram/WhatsApp/Instagram orqali xabar yuboradi, musiqa qo'yadi, budilnik qo'yadi va h.k.

## 1. Talablar
- Android Studio (Koala yoki yangiroq)
- JDK 17 (Android Studio bilan birga keladi)
- Android 8.0 (API 26) va undan yangi telefon

## 2. Loyihani ochish
1. Android Studio → **Open** → `Yordamchi` papkasini tanlang.
2. Birinchi ochilishda Gradle sinxronlanadi (internet kerak). Gradle wrapper o'zi yaratiladi.

## 3. APK yig'ish (GitHub orqali, kompyutersiz)
Repoga yuklang, "Actions" bo'limida APK tayyor bo'ladi (`.github/workflows/build.yml` tayyor).

## 3b. APK yig'ish (Android Studio)
- Test uchun: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
  Natija: `app/build/outputs/apk/debug/app-debug.apk`
- Terminal orqali: `./gradlew assembleDebug` (Windows: `gradlew.bat assembleDebug`)

APK'ni telefonga o'rnating (oldin "Noma'lum manbalardan o'rnatish" ruxsatini bering).

## 4. Ilovani sozlash
Ilovani oching va 3 ta bosqichni bajaring:
1. **Ruxsatlar**: mikrofon, qo'ng'iroq, SMS, kontaktlar, bildirishnoma.
2. **Ustidan chizish**: boshqa ilovalar ustida ko'rsatish ruxsati.
3. **Maxsus imkoniyatlar**: "Yordamchi"ni yoqing. Bu Telegram/WhatsApp/Instagram'da
   "Yuborish" va "Obuna bo'lish" tugmalarini avtomatik bosish uchun kerak.

**Muhim:** Android 13 va undan yangi versiyalarda sideload qilingan ilovalar uchun
maxsus imkoniyatlar bo'limi cheklangan bo'lishi mumkin. Bunday holda:
Sozlamalar → Ilovalar → Yordamchi → ⋮ → **"Cheklangan sozlamalarga ruxsat berish"**,
keyin maxsus imkoniyatlarda yoqing.

Sozlamalar bo'limida xohlasangiz:
- **Uyg'otuvchi so'z** (masalan `jarvis`). Bo'sh qoldirsangiz, har bir gap buyruq bo'ladi.
- **Til**: O'zbekcha, Русский, English.
- **Claude API kaliti** (ixtiyoriy). Kiritilsa buyruqlar aniqroq tushuniladi. Kalit bo'lmasa oddiy qoliplar ishlaydi.

## 5. Ishlatish misollari
- "Jarvis, Aliga qo'ng'iroq qil"
- "Jarvis, Aliga salom deb sms yoz"
- "Jarvis, Telegram Aliga yig'ilish soat 5 da deb yoz"
- "Jarvis, Instagram obuna bo'l nasa"
- "Jarvis, Musiqa qo'y Sherali Jo'rayev"
- "Jarvis, Budilnik 06:30"
- "Jarvis, Google dan dollar kursini qidir"
- "Jarvis, Kamera och"

## 6. Ma'lum cheklovlar
- Ovozni tanish uchun telefonda Google ovoz xizmati bo'lishi kerak.
- Telegram/WhatsApp/Instagram'da xabar yuborish uchun ilova avval "Ulashish" oynasi orqali
  ochiladi, keyin maxsus imkoniyat xizmati "Yuborish" tugmasini bosadi. Interfeys
  o'zgarsa, tugma topilmasligi mumkin.
- Ilova ishlayotganda doimiy bildirishnoma ko'rinadi. Bu Android talabi (mikrofon foreground xizmati).
- Instagram/Telegram/WhatsApp ilovalarining yangi versiyalarida tugma matni boshqacha bo'lsa,
  `AutoService.kt` ichidagi matnlar ro'yxatiga qo'shing.
