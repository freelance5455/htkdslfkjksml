JCK PLAYER ANDROID - MUSIC SCAN

Este es el proyecto Android de JCK Player.
Incluye:
- Interfaz JCK Player en assets/index.html
- Escaneo de biblioteca de audio mediante MediaStore
- Permiso READ_MEDIA_AUDIO (Android 13+) y READ_EXTERNAL_STORAGE (Android 12 o anterior)
- Lectura de metadatos y portada incrustada

Para obtener una APK, abre la carpeta JCK_Player_Android como proyecto Android/Gradle en Android Studio o en tu compilador compatible.
