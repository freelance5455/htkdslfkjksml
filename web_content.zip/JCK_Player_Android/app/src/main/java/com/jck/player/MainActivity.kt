package com.jck.player

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val permissionRequestCode = 77

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.settings.mediaPlaybackRequiresUserGesture = false
        webView.addJavascriptInterface(AndroidMusicBridge(this), "AndroidMusic")
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val url = request.url
                if (url.scheme == "content" && (url.authority == "media" || url.toString().contains("/audio/"))) {
                    return try {
                        val mime = contentResolver.getType(url) ?: "audio/mpeg"
                        WebResourceResponse(mime, null, contentResolver.openInputStream(url))
                    } catch (_: Exception) { null }
                }
                return super.shouldInterceptRequest(view, request)
            }
        }
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    fun requestAudioPermission() {
        val permission = if (android.os.Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
        if (checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED) {
            webView.evaluateJavascript("window.jckAudioPermissionResult(true)", null)
        } else {
            requestPermissions(arrayOf(permission), permissionRequestCode)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == permissionRequestCode) {
            val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            webView.evaluateJavascript("window.jckAudioPermissionResult($granted)", null)
        }
    }

    class AndroidMusicBridge(private val activity: MainActivity) {
        @JavascriptInterface
        fun requestAudioPermission() = activity.requestAudioPermission()

        @JavascriptInterface
        fun getAudioLibrary(): String {
            val result = JSONArray()
            val permission = if (android.os.Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
            if (activity.checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) return result.toString()

            val projection = arrayOf(
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.DISPLAY_NAME,
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST,
                MediaStore.Audio.Media.ALBUM,
                MediaStore.Audio.Media.GENRE,
                MediaStore.Audio.Media.DURATION,
                MediaStore.Audio.Media.MIME_TYPE
            )
            val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            val sort = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
            activity.contentResolver.query(collection, projection, null, null, sort)?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val genreCol = cursor.getColumnIndex(MediaStore.Audio.Media.GENRE)
                val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)
                while (cursor.moveToNext()) {
                    val mime = cursor.getString(mimeCol) ?: ""
                    if (!mime.startsWith("audio/")) continue
                    val id = cursor.getLong(idCol)
                    val uri = Uri.withAppendedPath(collection, id.toString())
                    val item = JSONObject()
                    item.put("name", cursor.getString(nameCol) ?: "audio")
                    item.put("title", cursor.getString(titleCol) ?: cursor.getString(nameCol) ?: "Sin título")
                    item.put("artist", cursor.getString(artistCol) ?: "Artista desconocido")
                    item.put("album", cursor.getString(albumCol) ?: "Álbum desconocido")
                    item.put("genre", if (genreCol >= 0) cursor.getString(genreCol) ?: "" else "")
                    item.put("duration", (cursor.getLong(durationCol) / 1000.0))
                    item.put("url", uri.toString())
                    item.put("art", embeddedArt(activity, uri))
                    result.put(item)
                }
            }
            return result.toString()
        }

        private fun embeddedArt(context: Context, uri: Uri): String? {
            return try {
                val retriever = MediaMetadataRetriever()
                retriever.setDataSource(context, uri)
                val bytes = retriever.embeddedPicture
                retriever.release()
                if (bytes == null || bytes.size > 700_000) return null
                val mime = when {
                    bytes.size >= 8 && bytes[0].toInt() == 0x89 -> "image/png"
                    else -> "image/jpeg"
                }
                "data:$mime;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP)
            } catch (_: Exception) { null }
        }
    }
}
