THUNDER TAP — Reflex Game Prototype

This is a playable, mobile-friendly browser game prototype.

How to try it:
1. Extract the ZIP (if you downloaded the ZIP).
2. Open index.html in Chrome on a phone or computer.
3. Press START GAME and tap the glowing target for 30 seconds.

Important:
- The Premium Packs are visual shop previews only. They do not charge money.
- This folder is not an Android APK yet.
- To create an installable APK for free, you can use MIT App Inventor (https://appinventor.mit.edu/) and follow its Build > Android App (.apk) workflow. Rebuilding this exact HTML game as a native project or embedding it in a WebViewer will be the next step.
- Real Google Play purchases require a developer account, Play Console product setup, and Google Play Billing integration. Do not represent demo buttons as real purchases.
