# CAREER GROWTH SPECIALIST

A mobile-first, locally runnable career-services web app designed for Android WebView / HTML-to-APK builders.

## Run locally
1. Extract the ZIP.
2. Open `index.html` in a modern browser, or import the extracted folder into your HTML-to-APK builder.
3. Keep the `css`, `js`, and `assets` folders beside `index.html`.
4. Internet is only needed for optional Google Fonts and the external ChatGPT / WhatsApp / Teams links. The core app runs locally without a paid API.

## Included working features
- First-screen specialist introduction featuring the supplied portrait.
- Responsive dashboard and navigation across all service centres.
- Resume review with local text-based heuristic checks and a structured report.
- TXT import; PDF, DOC and DOCX file selection with paste-to-review workflow.
- Writing prompt builders for CVs, cover letters, job applications, LinkedIn and interviews.
- Clearly labelled external ChatGPT prompt handoff; no fake embedded AI.
- Candidate profile, checklist, activity and recruiter enquiry saved in browser local storage.
- JSON export and local data reset.
- Configurable services and prices in `js/config.js`.
- WhatsApp consultation/contact links and Microsoft Teams invitation.

## Important limitations / privacy
- No backend, login, shared cloud database, recruiter publishing, or server-side file upload is included. Candidate and recruiter data is local to the browser/device.
- The AI Career Assistant prepares a prompt and opens ChatGPT. The user must review and submit it there; this app does not claim to have an AI API connection.
- Resume review is a lightweight heuristic first pass, not a certified ATS scan or professional human review. It analyses pasted text. Selected PDF/DOC/DOCX files are not uploaded or parsed; paste the extracted text for review. TXT files can be read locally.
- Do not enter sensitive personal information into external AI tools unless comfortable with that provider's privacy terms.
- Prices are deliberately blank. Configure confirmed amounts and service descriptions in `js/config.js` before release.
- This package does not integrate with job-search APIs.

## Configure prices
Edit `window.CGS_CONFIG.services` in `js/config.js`. Set each `price` to an approved display string, for example `₦25,000`, only after the business confirms it.

## Branding / portrait
- The dashboard introduction and portrait are in `index.html` and `assets/career-growth-specialist.png`. Replace that image file to update the portrait; keep the same filename or update the image path in `index.html`.

## Business contact details
- WhatsApp: +23480 2275 3745
- https://wa.me/2348022753745
- Microsoft Teams: https://teams.live.com/l/invite/FEA6QRP1V2D48JLng?v=g1

## Android packaging notes
Import the extracted project folder into your HTML-to-APK / ZIP-to-APK builder. Set the start page to `index.html`, app name to `CAREER GROWTH SPECIALIST`, and enable internet access only if you want external fonts and links. For fully offline branding, replace the Google Fonts import in `css/styles.css` with bundled fonts or system font fallbacks.

## Test checklist
- Open `index.html`; dashboard loads.
- Use each sidebar item and dashboard shortcut; matching page appears.
- Submit review with at least 80 characters of pasted resume text.
- Select a TXT file and confirm it populates the text field.
- Build prompts in Studio, Applications, LinkedIn and Interview sections; ChatGPT opens with prompt query.
- Save candidate profile; refresh and confirm data persists.
- Save recruiter enquiry; data remains local.
- Export JSON and clear local data.
- Confirm WhatsApp and Teams links open.
