# CAREER GROWTH SPECIALIST — Abdulbasit's Personal Workspace

A mobile-first, app-style HTML/CSS/JavaScript career workbench. The first screen introduces Abdulbasit with his supplied portrait and professional experience.

## Run locally
1. Extract the ZIP.
2. Open `career_growth_specialist/index.html` in a browser, or import the extracted folder into an HTML-to-APK builder.
3. Set `index.html` as the start page.

## Included tools
- Personal home screen: Abdulbasit's profile, portrait and five-year experience introduction.
- Apply for a role: creates a detailed, fact-checked client application prompt.
- Review a resume: prepares a structured ATS-aware review prompt. Paste readable resume text; selecting a file alone does not extract its contents.
- Find opportunities: searches Google Jobs, LinkedIn Jobs, Indeed, Glassdoor and official company career pages using role, location and work preferences.
- AI assistant: creates prompts for ChatGPT and opens ChatGPT for the user to review and submit.

## Important limitations
- No AI API is embedded. AI drafting happens in ChatGPT after the user reviews and submits the prepared prompt.
- Job results are fetched by external public search pages. This app does not scrape, host, or independently verify vacancies. Confirm each opening on the employer's official careers site before applying. Never pay a recruiter for a job.
- No contact details or contact/consultation sections are included.
- Recent activity is stored in browser local storage. No shared cloud database is used.
- Internet access is required for external job searches and ChatGPT. The core interface runs locally.

## Package structure
- `index.html` — app interface
- `css/styles.css` — mobile-first app styling
- `js/app.js` — navigation, forms, prompt generation, local activity and job search links
- `assets/abdulbasit.png` — supplied profile portrait
- `assets/mark.svg` — app icon
