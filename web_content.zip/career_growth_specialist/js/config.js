/* Configure service descriptions and prices here. Leave price as an empty string until confirmed. */
window.CGS_CONFIG = {
  businessName: "CAREER GROWTH SPECIALIST",
  whatsapp: "2348022753745",
  teamsUrl: "https://teams.live.com/l/invite/FEA6QRP1V2D48JLng?v=g1",
  services: [
    {name:"Professional CV writing", description:"A tailored, achievement-led CV for your next opportunity.", price:""},
    {name:"Executive resume writing", description:"A strategic executive profile focused on leadership and impact.", price:""},
    {name:"ATS-friendly resume", description:"A clear, recruiter-readable resume aligned to a target role.", price:""},
    {name:"Cover letter writing", description:"A persuasive, role-specific cover letter.", price:""},
    {name:"LinkedIn optimization", description:"A consistent professional profile and visibility strategy.", price:""},
    {name:"Interview preparation", description:"Structured preparation, STAR stories and mock interview practice.", price:""}
  ]
};