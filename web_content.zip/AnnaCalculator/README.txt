AnnaCalculator
1. Extract this ZIP.
2. Open index.html in Acode.
3. The multiplication button displays × (proper multiplication sign).
4. Calculation logic continues to use * internally.
5. Build APK using your HTML-to-APK app.

Note: Vault/file selection in this HTML demo is not secure storage and does not truly hide or move files.
