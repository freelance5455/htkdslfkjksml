/* Offline Excel reader for CG Pest Control. No network required. */
(function(global){
  'use strict';
  function xml(text){
    var p=new DOMParser();
    var d=p.parseFromString(text,'application/xml');
    if(!d || d.getElementsByTagName('parsererror').length) throw new Error('Invalid Excel XML');
    return d;
  }
  function all(root, name){ return Array.prototype.filter.call(root.getElementsByTagName('*'), function(n){ return n.localName===name || n.nodeName===name; }); }
  function one(root,name){ var a=all(root,name); return a[0]||null; }
  function textOf(n){ return n ? (n.textContent||'') : ''; }
  function attr(n,k){ return n && n.getAttribute ? (n.getAttribute(k)||'') : ''; }
  function normPath(p){
    var parts=p.replace(/^\/+/, '').split('/'), out=[];
    parts.forEach(function(x){ if(!x||x==='.') return; if(x==='..') out.pop(); else out.push(x); });
    return out.join('/');
  }
  function relTarget(base,target){
    if(target.charAt(0)==='/') return normPath(target);
    var b=base.split('/'); b.pop(); return normPath(b.join('/')+'/'+target);
  }
  function colIndex(ref){
    var m=String(ref||'').match(/^([A-Z]+)\d+$/i); if(!m)return 0;
    var s=m[1].toUpperCase(), n=0; for(var i=0;i<s.length;i++) n=n*26+(s.charCodeAt(i)-64); return n-1;
  }
  function excelDate(n){
    if(typeof n!=='number'||!isFinite(n)) return n;
    var d=new Date(Date.UTC(1899,11,30)+n*86400000);
    return d.toISOString().slice(0,10);
  }
  function parseCSV(text){
    var rows=[], row=[], cur='', q=false;
    text=text.replace(/^\uFEFF/,'');
    for(var i=0;i<text.length;i++){
      var c=text[i];
      if(c==='"'){
        if(q && text[i+1]==='"'){cur+='"';i++;}
        else q=!q;
      } else if(c===',' && !q){row.push(cur);cur='';}
      else if((c==='\n'||c==='\r')&&!q){ if(c==='\r'&&text[i+1]==='\n')i++; row.push(cur);rows.push(row);row=[];cur=''; }
      else cur+=c;
    }
    if(cur!==''||row.length){row.push(cur);rows.push(row);}
    return rows;
  }
  function sheetRows(xmlText, shared, dateStyles){
    var doc=xml(xmlText), rowNodes=all(doc,'row'), out=[];
    rowNodes.forEach(function(rn){
      var arr=[];
      all(rn,'c').forEach(function(c){
        var idx=colIndex(attr(c,'r')); if(idx<0)return;
        var t=attr(c,'t'), s=attr(c,'s'), vNode=one(c,'v'), v=textOf(vNode), val='';
        if(t==='s') val=shared[parseInt(v,10)]||'';
        else if(t==='inlineStr') val=textOf(one(c,'is'));
        else if(t==='b') val=v==='1';
        else if(t==='d') val=v;
        else if(t==='e') val='';
        else if(v!=='') { var num=Number(v); val=isNaN(num)?v:num; if(dateStyles[s]) val=excelDate(num); }
        arr[idx]=val;
      });
      out.push(arr);
    });
    return out;
  }
  async function parseXLSX(arrayBuffer){
    if(!global.JSZip) throw new Error('Offline ZIP reader is missing');
    var zip=await global.JSZip.loadAsync(arrayBuffer), files=zip.files;
    function has(n){return !!files[n];}
    async function read(n){ if(!files[n]) throw new Error('Missing '+n); return files[n].async('string'); }
    var wb=xml(await read('xl/workbook.xml'));
    var rels={};
    if(has('xl/_rels/workbook.xml.rels')){
      var rd=xml(await read('xl/_rels/workbook.xml.rels'));
      all(rd,'Relationship').forEach(function(r){ rels[attr(r,'Id')]=attr(r,'Target'); });
    }
    var shared=[];
    if(has('xl/sharedStrings.xml')){
      var sd=xml(await read('xl/sharedStrings.xml'));
      all(sd,'si').forEach(function(si){ shared.push(all(si,'t').map(textOf).join('')); });
    }
    var dateStyles={};
    if(has('xl/styles.xml')){
      var st=xml(await read('xl/styles.xml')), xfs=one(st,'cellXfs');
      var dateFmt={14:1,15:1,16:1,17:1,18:1,19:1,20:1,21:1,22:1,27:1,28:1,29:1,30:1,31:1,32:1,33:1,34:1,35:1,36:1,45:1,46:1,47:1,50:1,57:1};
      var custom={}; all(st,'numFmt').forEach(function(n){var id=parseInt(attr(n,'numFmtId'),10), f=attr(n,'formatCode'); if(/yy|mm|dd|hh|ss/i.test(f)) custom[id]=1;});
      if(xfs) all(xfs,'xf').forEach(function(x,i){var id=parseInt(attr(x,'numFmtId'),10); if(dateFmt[id]||custom[id])dateStyles[String(i)]=1;});
    }
    var sheets=[];
    all(wb,'sheet').forEach(function(s){
      var name=attr(s,'name'), rid=attr(s,'r:id')||attr(s,'id'), target=rels[rid];
      if(target){ var path=relTarget('xl/workbook.xml',target); sheets.push({name:name,path:path}); }
    });
    if(!sheets.length) throw new Error('No worksheets found');
    var result={SheetNames:[],Sheets:{}};
    for(var i=0;i<sheets.length;i++){
      var rows=sheetRows(await read(sheets[i].path),shared,dateStyles), aoa=rows;
      var max=0; aoa.forEach(function(r){if(r.length>max)max=r.length;});
      var header=aoa[0]||[], json=[];
      for(var r=1;r<aoa.length;r++){
        var obj={}, non=false;
        for(var c=0;c<max;c++){var h=header[c]; if(h==null||String(h).trim()==='')continue; var v=aoa[r][c]; if(v!==undefined&&v!=='')non=true; obj[String(h)]=v==null?'':v;}
        if(non)json.push(obj);
      }
      var ws={__rows:json,__aoa:aoa}; result.SheetNames.push(sheets[i].name); result.Sheets[sheets[i].name]=ws;
    }
    return result;
  }
  global.XLSX={
    read: async function(data,opts){
      if(typeof data==='string') return {SheetNames:['Sheet1'],Sheets:{Sheet1:{__rows:parseCSV(data),__aoa:[]}}};
      var b=data instanceof ArrayBuffer?data:data.buffer;
      var bytes=new Uint8Array(b);
      // CSV fallback by BOM/text when file is not a ZIP container.
      if(bytes[0]!==80||bytes[1]!==75){
        var txt=new TextDecoder('utf-8').decode(bytes).replace(/^\uFEFF/,'');
        var rows=parseCSV(txt), headers=rows[0]||[], json=[];
        for(var i=1;i<rows.length;i++){var o={},non=false;for(var j=0;j<headers.length;j++){var v=rows[i][j]||'';o[headers[j]]=v;if(v)non=true;}if(non)json.push(o);}
        return {SheetNames:['Sheet1'],Sheets:{Sheet1:{__rows:json,__aoa:rows}}};
      }
      return await parseXLSX(b);
    },
    utils:{sheet_to_json:function(ws){return ws&&ws.__rows?ws.__rows:[];}}
  };
})(window);
