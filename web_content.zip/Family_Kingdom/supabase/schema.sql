-- مخطط Supabase لحكومة البيت. لم يُختبر على خادم حقيقي بعد: نفّذه في SQL Editor ثم راجع README.
create table families (id uuid primary key default gen_random_uuid(), name text not null, tz text not null default 'Africa/Khartoum', invite_code text unique not null default substr(md5(random()::text),1,8), created_at timestamptz default now());
create table members (id uuid primary key default gen_random_uuid(), family_id uuid references families on delete cascade, user_id uuid references auth.users, name text not null, avatar text, role text not null default 'member' check (role in ('guardian','member')), unique(family_id,user_id));
create table ledger (id bigserial primary key, family_id uuid references families on delete cascade, member_id uuid references members, amount int not null check (amount<>0), reason text not null, key text not null, created_at timestamptz default now(), unique(family_id,key));
create table tasks (id uuid primary key default gen_random_uuid(), family_id uuid references families on delete cascade, title text not null, stars int not null check (stars between 1 and 20), assignee uuid references members, status text not null default 'new' check (status in ('new','in_progress','pending','approved','rejected')), reject_reason text, reviewed_by uuid references members);

create or replace function my_family() returns uuid language sql stable security definer as $$ select family_id from members where user_id = auth.uid() limit 1 $$;
create or replace function my_member() returns members language sql stable security definer as $$ select * from members where user_id = auth.uid() limit 1 $$;

alter table families enable row level security; alter table members enable row level security; alter table ledger enable row level security; alter table tasks enable row level security;
create policy fam_read on families for select using (id = my_family());
create policy mem_read on members for select using (family_id = my_family());
create policy led_read on ledger for select using (family_id = my_family());
create policy task_read on tasks for select using (family_id = my_family());
-- لا توجد سياسات insert/update/delete على ledger: الكتابة تتم فقط عبر الدوال أدناه (security definer).

create or replace function claim_daily() returns void language plpgsql security definer as $$
declare m members := my_member(); d text;
begin
  if m.id is null then raise exception 'غير مصرّح'; end if;
  d := to_char(now() at time zone (select tz from families where id=m.family_id),'YYYY-MM-DD');
  insert into ledger(family_id,member_id,amount,reason,key) values (m.family_id,m.id,5,'المكافأة اليومية','daily:'||m.id||':'||d)
  on conflict (family_id,key) do nothing;
  if not found then raise exception 'استلمت مكافأة اليوم بالفعل'; end if;
end $$;

create or replace function review_task(p_task uuid, p_ok boolean, p_reason text) returns void language plpgsql security definer as $$
declare m members := my_member(); t tasks;
begin
  select * into t from tasks where id=p_task and family_id=m.family_id for update;
  if t.id is null or t.status<>'pending' then raise exception 'المهمة ليست بانتظار المراجعة'; end if;
  if t.assignee=m.id then raise exception 'لا يمكنك اعتماد مهمتك'; end if;
  if m.role<>'guardian' then raise exception 'لا تملك صلاحية'; end if; -- طوّرها لاحقاً لتشمل الوزراء
  if p_ok then
    insert into ledger(family_id,member_id,amount,reason,key) values (t.family_id,t.assignee,t.stars,'مهمة معتمدة','task:'||t.id) on conflict do nothing;
    update tasks set status='approved', reviewed_by=m.id where id=t.id;
  else
    if coalesce(trim(p_reason),'')='' then raise exception 'اكتب سبب الرفض'; end if;
    update tasks set status='rejected', reject_reason=p_reason, reviewed_by=m.id where id=t.id;
  end if;
end $$;
revoke all on function claim_daily(), review_task(uuid,boolean,text) from public; grant execute on function claim_daily(), review_task(uuid,boolean,text) to authenticated;
-- المتبقي للتنفيذ بنفس النمط: المتجر، القوانين، التصويت، الرئاسة، سحب الثقة.
