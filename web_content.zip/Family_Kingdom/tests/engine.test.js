import test from 'node:test';
import assert from 'node:assert/strict';
import * as E from '../src/engine.js';
import { applyOps } from '../src/queue.js';
const T0 = Date.UTC(2026, 9, 23, 10), D = E.DAY;
const mk = () => E.createFamily({ name: 'أسرتنا', members: [1, 2, 3, 4, 5, 6].map((i) => ({ name: 'عضو' + i, pin: '1111' })) });
const throwsRule = (fn) => assert.throws(fn, E.RuleError);
function approved(s, who, stars = 3, at = T0) { const t = E.createTask(s, 'm1', { title: 'x', stars, assignee: who }, at); E.submitTask(s, who, t.id, at); E.reviewTask(s, 'm1', t.id, true, '', at); }

test('1 إنشاء أسرة بستة أعضاء', () => { const s = mk(); assert.equal(s.members.length, 6); throwsRule(() => E.createFamily({ name: 'x', members: [] })); });
test('2 تسجيل الدخول والرمز السري والإغلاق المؤقت', () => {
  const s = mk(); assert.equal(E.login(s, 'm2', '1111'), 'm2'); throwsRule(() => E.login(s, 'm2', '0000'));
  for (let i = 0; i < 5; i++) try { E.login(s, 'm3', '9999'); } catch {}
  throwsRule(() => E.login(s, 'm3', '1111'));
});
test('3 مكافأة يومية مرة واحدة ثم يوم جديد', () => {
  const s = mk(); E.claimDaily(s, 'm2', T0); throwsRule(() => E.claimDaily(s, 'm2', T0 + 3600e3));
  E.claimDaily(s, 'm2', T0 + D); assert.equal(E.balance(s, 'm2'), 10);
});
test('4 الضغط المتكرر لا يكرر المكافأة', () => {
  const s = mk(); for (let i = 0; i < 10; i++) try { E.claimDaily(s, 'm2', T0); } catch {}
  assert.equal(E.balance(s, 'm2'), 5);
});
test('5 اعتماد مهمة مرة واحدة', () => {
  const s = mk(); const t = E.createTask(s, 'm1', { title: 'مذاكرة', stars: 8, assignee: 'm2' }, T0);
  E.submitTask(s, 'm2', t.id, T0); E.reviewTask(s, 'm1', t.id, true, '', T0);
  throwsRule(() => E.reviewTask(s, 'm1', t.id, true, '', T0)); assert.equal(E.balance(s, 'm2'), 8);
});
test('6 رفض المهمة يتطلب سبباً', () => {
  const s = mk(); const t = E.createTask(s, 'm1', { title: 'ترتيب', stars: 4, assignee: 'm2' }, T0); E.submitTask(s, 'm2', t.id, T0);
  throwsRule(() => E.reviewTask(s, 'm1', t.id, false, '', T0)); E.reviewTask(s, 'm1', t.id, false, 'غير مرتبة', T0);
  assert.equal(t.status, 'rejected'); assert.equal(E.balance(s, 'm2'), 0);
});
test('7 منع التعديل بلا صلاحية', () => {
  const s = mk();
  throwsRule(() => E.createTask(s, 'm3', { title: 'x', stars: 5, assignee: 'm3' }, T0));
  throwsRule(() => E.adminCorrection(s, 'm3', 'm3', 50, 'x', T0));
  throwsRule(() => E.adminCorrection(s, 'm1', 'm1', 50, 'x', T0));
  const t = E.createTask(s, 'm1', { title: 'x', stars: 5, assignee: 'm2' }, T0); E.submitTask(s, 'm2', t.id, T0);
  throwsRule(() => E.reviewTask(s, 'm2', t.id, true, '', T0));
});
test('8 الشراء والتحقق من الرصيد', () => {
  const s = mk(); const r = E.addReward(s, 'm1', { name: 'فيلم', price: 10 }, T0);
  throwsRule(() => E.requestRedeem(s, 'm2', r.id, T0)); E.claimDaily(s, 'm2', T0); E.claimDaily(s, 'm2', T0 + D);
  E.requestRedeem(s, 'm2', r.id, T0); assert.equal(E.balance(s, 'm2'), 0);
});
test('9 استرداد العملات عند رفض الاستبدال', () => {
  const s = mk(); const r = E.addReward(s, 'm1', { name: 'فيلم', price: 5, stock: 1 }, T0); E.claimDaily(s, 'm2', T0);
  const q = E.requestRedeem(s, 'm2', r.id, T0); throwsRule(() => E.reviewRedeem(s, 'm1', q.id, false, '', T0));
  E.reviewRedeem(s, 'm1', q.id, false, 'غير متاح', T0); assert.equal(E.balance(s, 'm2'), 5); assert.equal(r.stock, 1);
  throwsRule(() => E.reviewRedeem(s, 'm1', q.id, true, '', T0));
});
test('10 قانون وتصويت وتوزيع وزارات', () => {
  const s = mk(); E.startPresidency(s, 'm2', T0);
  throwsRule(() => E.proposeLaw(s, 'm3', { title: 'a', text: 'b' }, T0));
  const l = E.proposeLaw(s, 'm2', { title: 'قانون', text: 'لا هاتف وقت الدراسة' }, T0);
  ['m1', 'm2', 'm3'].forEach((m) => E.vote(s, m, l.id, true, T0)); assert.equal(l.status, 'voting'); throwsRule(() => E.vote(s, 'm3', l.id, true, T0));
  E.vote(s, 'm4', l.id, true, T0); assert.equal(l.status, 'accepted');
  const map = Object.fromEntries(Object.keys(E.MINISTRIES).map((k, i) => [k, 'm' + (i + 1)]));
  const ml = E.proposeMinistries(s, 'm2', map, T0); ['m1', 'm2', 'm3', 'm4'].forEach((m) => E.vote(s, m, ml.id, true, T0));
  assert.equal(s.ministries.finance, 'm6');
});
test('11 اختيار الرئيس القادم وكسر التعادل', () => {
  const s = mk(); assert.deepEqual(E.chooseNext(s, T0), { needsVote: true });
  approved(s, 'm3'); approved(s, 'm2'); assert.equal(E.chooseNext(s, T0).winner, 'm2');
  approved(s, 'm3'); assert.equal(E.chooseNext(s, T0).winner, 'm3');
});
test('12 انتهاء الرئاسة بعد سبعة أيام', () => {
  const s = mk(); E.startPresidency(s, 'm2', T0);
  assert.equal(E.president(s, T0 + 6 * D), 'm2'); assert.equal(E.president(s, T0 + 7 * D), null);
});
test('13 سحب الثقة', () => {
  const s = mk(); E.startPresidency(s, 'm2', T0); E.requestNoConfidence(s, 'm3', 'تجاوز القواعد', T0);
  throwsRule(() => E.voteNoConfidence(s, 'm2', false, T0));
  ['m1', 'm3', 'm4'].forEach((m) => E.voteNoConfidence(s, m, true, T0)); assert.equal(E.president(s, T0), null);
});
test('14 كشف العبث بسجل المعاملات', () => {
  const s = mk(); E.claimDaily(s, 'm2', T0); assert.ok(E.verifyLedger(s)); s.ledger[0].amount = 500; assert.equal(E.verifyLedger(s), false);
});
test('17 قائمة الانتظار لا تكرر العمليات عند إعادة المزامنة', () => {
  const s = mk(); const ops = [{ id: 'op1', type: 'claimDaily', actor: 'm2' }];
  assert.equal(applyOps(s, ops, T0)[0].status, 'ok'); assert.equal(applyOps(s, ops, T0)[0].status, 'duplicate');
  assert.equal(applyOps(s, [{ id: 'op2', type: 'claimDaily', actor: 'm2' }], T0)[0].status, 'rejected'); assert.equal(E.balance(s, 'm2'), 5);
});
