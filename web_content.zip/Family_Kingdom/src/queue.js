// قائمة انتظار العمليات عند انقطاع الاتصال: لكل عملية معرّف فريد فلا تتكرر عند إعادة المزامنة.
import * as E from './engine.js';
const OPS = {
  claimDaily: (s, a, p, now) => E.claimDaily(s, a, now),
  submitTask: (s, a, p, now) => E.submitTask(s, a, p.taskId, now, p.photo),
  requestRedeem: (s, a, p, now) => E.requestRedeem(s, a, p.rewardId, now),
  vote: (s, a, p, now) => E.vote(s, a, p.lawId, p.yes, now),
};
export function applyOps(s, ops, serverNow) {
  return ops.map((op) => {
    if (s.appliedOps.includes(op.id)) return { id: op.id, status: 'duplicate' };
    s.appliedOps.push(op.id);
    try { OPS[op.type](s, op.actor, op.payload || {}, serverNow); return { id: op.id, status: 'ok' }; }
    catch (e) { if (e instanceof E.RuleError) return { id: op.id, status: 'rejected', reason: e.message }; throw e; }
  });
}
