// محرك قواعد «حكومة البيت» — منطق خالص بلا اعتماد على المتصفح، قابل للاختبار.
export const DAILY_STARS = 5;
export const PRESIDENCY_DAYS = 7;
export const DAY = 86400000;
export class RuleError extends Error {}
const fail = (m) => { throw new RuleError(m); };
export const MINISTRIES = {
  cleaning: 'وزارة النظافة والترتيب', education: 'وزارة التعليم والمعرفة',
  kitchen: 'وزارة المطبخ والخدمات المنزلية', fun: 'وزارة الترفيه والعلاقات الأسرية',
  digital: 'وزارة النظام الرقمي', finance: 'وزارة المالية والامتيازات',
};
export function dayKey(ms, tz = 'Africa/Khartoum') {
  return new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date(ms));
}
// بصمة سريعة للكشف عن العبث بالسجل المحلي (ليست تشفيراً قوياً؛ الحماية الحقيقية في الخادم).
function fnv(s) { let h = 0x811c9dc5; for (const c of s) { h ^= c.codePointAt(0); h = Math.imul(h, 0x01000193) >>> 0; } return h.toString(16).padStart(8, '0'); }
export const hashPin = (pin, salt) => fnv(salt + ':' + pin);
const uid = (s, p) => `${p}${++s.seq}`;
const audit = (s, actor, action, ref, now) => s.audit.push({ at: now, actor, action, ref });

export function createFamily({ name, tz = 'Africa/Khartoum', members }) {
  if (!name?.trim()) fail('اكتب اسم الأسرة');
  if (!members || members.length !== 6) fail('يجب إضافة ستة أفراد');
  const s = { family: { name: name.trim(), tz }, seq: 0, members: [], ledger: [], tasks: [], rewards: [], redemptions: [],
    laws: [], ministries: {}, ministryHistory: [], presidency: null, presidentHistory: [], noConfidence: null, audit: [], appliedOps: [] };
  members.forEach((m, i) => {
    if (!m.name?.trim()) fail('اكتب اسم كل فرد');
    if (!/^\d{4}$/.test(m.pin || '')) fail('الرمز السري يجب أن يكون أربعة أرقام');
    const id = 'm' + (i + 1), salt = id + Math.random().toString(36).slice(2);
    s.members.push({ id, name: m.name.trim(), avatar: m.avatar || '🙂', role: i === 0 ? 'guardian' : 'member', salt, pinHash: hashPin(m.pin, salt), fails: 0 });
  });
  return s;
}
export function member(s, id) { return s.members.find((m) => m.id === id) || fail('عضو غير موجود'); }
export const isGuardian = (s, id) => member(s, id).role === 'guardian';
export const isMinister = (s, id) => Object.values(s.ministries).includes(id);
export function login(s, id, pin) {
  const m = member(s, id);
  if (m.fails >= 5) fail('تم إيقاف المحاولات مؤقتاً، اطلب مساعدة ولي الأمر');
  if (hashPin(pin, m.salt) !== m.pinHash) { m.fails++; fail('الرمز السري غير صحيح'); }
  m.fails = 0; return m.id;
}
export function resetPin(s, actor, id, pin) {
  if (!isGuardian(s, actor)) fail('ولي الأمر فقط يعيد ضبط الرمز');
  if (!/^\d{4}$/.test(pin)) fail('الرمز السري يجب أن يكون أربعة أرقام');
  const m = member(s, id); m.pinHash = hashPin(pin, m.salt); m.fails = 0;
}

// ---------- السجل المالي (إضافة فقط + سلسلة بصمات) ----------
export const balance = (s, id) => s.ledger.filter((e) => e.memberId === id).reduce((a, e) => a + e.amount, 0);
function post(s, { key, memberId, amount, reason, now }) {
  if (!Number.isInteger(amount) || amount === 0) fail('مبلغ غير صالح');
  if (!reason) fail('لا يمكن تغيير الرصيد دون سبب');
  if (s.ledger.some((e) => e.key === key)) return null; // منع التكرار (idempotency)
  if (amount < 0 && balance(s, memberId) + amount < 0) fail('الرصيد غير كافٍ');
  const prev = s.ledger.at(-1)?.hash || 'genesis';
  const e = { id: uid(s, 't'), key, memberId, amount, reason, at: now };
  e.hash = fnv(prev + JSON.stringify([e.id, e.key, e.memberId, e.amount, e.reason, e.at]));
  s.ledger.push(e); return e;
}
export function verifyLedger(s) {
  let prev = 'genesis';
  for (const e of s.ledger) {
    if (e.hash !== fnv(prev + JSON.stringify([e.id, e.key, e.memberId, e.amount, e.reason, e.at]))) return false;
    prev = e.hash;
  }
  return true;
}
export function claimDaily(s, actor, now) {
  member(s, actor);
  const day = dayKey(now, s.family.tz);
  const e = post(s, { key: `daily:${actor}:${day}`, memberId: actor, amount: DAILY_STARS, reason: 'المكافأة اليومية', now });
  if (!e) fail('استلمت مكافأة اليوم بالفعل، عد غداً');
  return e;
}
export function adminCorrection(s, actor, memberId, amount, reason, now) {
  if (!isGuardian(s, actor)) fail('ولي الأمر فقط يجري التصحيح الإداري');
  if (actor === memberId) fail('لا يعدّل ولي الأمر رصيده بنفسه');
  if (!reason?.trim()) fail('اكتب سبب التصحيح');
  const e = post(s, { key: uid(s, 'adj'), memberId, amount, reason: 'تصحيح إداري: ' + reason, now });
  audit(s, actor, 'adminCorrection', e.id, now); return e;
}
export function economy(s) {
  const sources = {}; let total = 0;
  for (const e of s.ledger) if (e.amount > 0) { sources[e.reason] = (sources[e.reason] || 0) + e.amount; }
  s.members.forEach((m) => { total += balance(s, m.id); });
  return { total, sources };
}

// ---------- المهام ----------
export function createTask(s, actor, { title, desc = '', stars, assignee, due = null, difficulty = 'متوسط', verify = 'review' }, now) {
  if (!isGuardian(s, actor) && !isMinister(s, actor)) fail('لا تملك صلاحية إنشاء المهام');
  member(s, assignee);
  if (!title?.trim()) fail('اكتب اسم المهمة');
  if (!Number.isInteger(stars) || stars < 1 || stars > 20) fail('المكافأة بين 1 و20 نجمة');
  if (actor === assignee && !isGuardian(s, actor)) fail('لا يمكنك إنشاء مهمة مكافأة لنفسك');
  const t = { id: uid(s, 'k'), title: title.trim(), desc, stars, assignee, due, difficulty, verify, status: 'new', log: [{ at: now, by: actor, what: 'إنشاء' }] };
  s.tasks.push(t); audit(s, actor, 'createTask', t.id, now); return t;
}
const task = (s, id) => s.tasks.find((t) => t.id === id) || fail('مهمة غير موجودة');
export function startTask(s, actor, id, now) {
  const t = task(s, id); if (t.assignee !== actor) fail('هذه المهمة ليست لك');
  if (t.status !== 'new' && t.status !== 'rejected') fail('لا يمكن بدء المهمة الآن');
  t.status = 'in_progress'; t.log.push({ at: now, by: actor, what: 'بدء' });
}
export function submitTask(s, actor, id, now, photo = null) {
  const t = task(s, id); if (t.assignee !== actor) fail('هذه المهمة ليست لك');
  if (!['new', 'in_progress', 'rejected'].includes(t.status)) fail('لا يمكن إرسال المهمة الآن');
  if (t.verify === 'photo' && !photo) fail('أرفق صورة لإثبات الإنجاز');
  t.status = 'pending'; t.photo = photo; t.log.push({ at: now, by: actor, what: 'طلب اعتماد' });
}
export function reviewTask(s, actor, id, approve, reason, now) {
  const t = task(s, id);
  if (t.status !== 'pending') fail('المهمة ليست بانتظار المراجعة');
  if (actor === t.assignee) fail('لا يمكنك اعتماد مهمتك بنفسك');
  if (!isGuardian(s, actor) && !isMinister(s, actor)) fail('لا تملك صلاحية المراجعة');
  if (approve) {
    post(s, { key: `task:${t.id}`, memberId: t.assignee, amount: t.stars, reason: 'مهمة معتمدة', now });
    t.status = 'approved';
  } else {
    if (!reason?.trim()) fail('اكتب سبب الرفض');
    t.status = 'rejected'; t.rejectReason = reason;
  }
  t.reviewedAt = now; t.log.push({ at: now, by: actor, what: approve ? 'اعتماد' : 'رفض: ' + reason });
  audit(s, actor, 'reviewTask', t.id, now);
}

// ---------- المتجر ----------
export function addReward(s, actor, { name, price, stock = null, cash = false }, now) {
  if (!isGuardian(s, actor)) fail('ولي الأمر فقط يضيف الامتيازات');
  if (!name?.trim() || !Number.isInteger(price) || price < 1) fail('بيانات الامتياز غير صالحة');
  const r = { id: uid(s, 'r'), name: name.trim(), price, stock, cash };
  s.rewards.push(r); audit(s, actor, 'addReward', r.id, now); return r;
}
export function requestRedeem(s, actor, rewardId, now) {
  const r = s.rewards.find((x) => x.id === rewardId) || fail('امتياز غير موجود');
  if (r.stock !== null && r.stock < 1) fail('نفدت الكمية');
  const rid = uid(s, 'q');
  post(s, { key: `hold:${rid}`, memberId: actor, amount: -r.price, reason: 'حجز استبدال: ' + r.name, now });
  if (r.stock !== null) r.stock--;
  const q = { id: rid, rewardId, memberId: actor, price: r.price, status: 'pending', at: now };
  s.redemptions.push(q); return q;
}
export function reviewRedeem(s, actor, rid, approve, reason, now) {
  const q = s.redemptions.find((x) => x.id === rid) || fail('طلب غير موجود');
  if (q.status !== 'pending') fail('تمت معالجة الطلب');
  if (actor === q.memberId) fail('لا يمكنك اعتماد طلبك');
  if (!isGuardian(s, actor)) fail('ولي الأمر فقط يعتمد الاستبدال');
  if (approve) q.status = 'approved';
  else {
    if (!reason?.trim()) fail('اكتب سبب الرفض');
    post(s, { key: `refund:${q.id}`, memberId: q.memberId, amount: q.price, reason: 'استرداد طلب مرفوض', now });
    const r = s.rewards.find((x) => x.id === q.rewardId); if (r && r.stock !== null) r.stock++;
    q.status = 'rejected'; q.reason = reason;
  }
  audit(s, actor, 'reviewRedeem', q.id, now);
}

// ---------- الرئاسة ----------
export function president(s, now) { const p = s.presidency; return p && now < p.endsAt ? p.memberId : null; }
export function startPresidency(s, memberId, now) {
  member(s, memberId);
  if (president(s, now)) fail('هناك رئيس حالي');
  const p = { memberId, startsAt: now, endsAt: now + PRESIDENCY_DAYS * DAY };
  s.presidency = p; s.presidentHistory.push(p); return p;
}
// القاعدة المعلنة: نقاط الأسبوع = عدد المهام المعتمدة (كل مهمة تُحسب مرة)؛ لا يتكرر الرئيس السابق مباشرة؛
// كسر التعادل: الأقل رئاسةً سابقاً ثم ترتيب العضو. إن لم يوجد مؤهل: تصويت.
export function chooseNext(s, now) {
  const since = now - 7 * DAY, last = s.presidentHistory.at(-1)?.memberId;
  const sc = s.members.map((m) => ({ id: m.id, points: s.tasks.filter((t) => t.assignee === m.id && t.status === 'approved' && t.reviewedAt >= since).length,
    past: s.presidentHistory.filter((p) => p.memberId === m.id).length })).filter((x) => x.points > 0 && x.id !== last);
  if (!sc.length) return { needsVote: true };
  sc.sort((a, b) => b.points - a.points || a.past - b.past || a.id.localeCompare(b.id));
  return { winner: sc[0].id, scores: sc };
}
export function requestNoConfidence(s, actor, reason, now) {
  const pr = president(s, now); member(s, actor);
  if (!pr) fail('لا يوجد رئيس حالياً');
  if (!reason?.trim()) fail('اذكر سبب الطلب');
  if (s.noConfidence?.status === 'voting') fail('يوجد طلب قيد التصويت');
  s.noConfidence = { id: uid(s, 'nc'), by: actor, reason, target: pr, votes: {}, status: 'voting' };
}
export function voteNoConfidence(s, actor, yes, now) {
  const nc = s.noConfidence; member(s, actor);
  if (!nc || nc.status !== 'voting') fail('لا يوجد تصويت جارٍ');
  if (actor === nc.target) fail('الرئيس لا يصوّت على سحب الثقة من نفسه');
  if (actor in nc.votes) fail('صوّتّ مسبقاً');
  nc.votes[actor] = !!yes;
  const n = s.members.length - 1, y = Object.values(nc.votes).filter(Boolean).length, no = Object.values(nc.votes).length - y;
  if (y > n / 2) { nc.status = 'passed'; s.presidency.endsAt = now; s.presidency.endedEarly = true; }
  else if (no >= n / 2) nc.status = 'failed';
}

// ---------- القوانين ----------
export function proposeLaw(s, actor, { title, text, payload = null }, now) {
  if (actor !== president(s, now) && !isGuardian(s, actor)) fail('الرئيس أو ولي الأمر فقط يقترح القوانين');
  if (!title?.trim() || !text?.trim()) fail('اكتب عنوان القانون ونصه');
  const l = { id: uid(s, 'l'), title, text, payload, status: 'voting', votes: {}, proposedAt: now };
  s.laws.push(l); return l;
}
export function proposeMinistries(s, actor, map, now) {
  const keys = Object.keys(MINISTRIES);
  if (keys.some((k) => !map[k]) || new Set(Object.values(map)).size !== 6) fail('وزارة واحدة لكل فرد');
  Object.values(map).forEach((id) => member(s, id));
  return proposeLaw(s, actor, { title: 'توزيع الوزارات', text: 'توزيع الوزارات الأسبوعي', payload: { ministries: map } }, now);
}
export function vote(s, actor, lawId, yes, now) {
  member(s, actor);
  const l = s.laws.find((x) => x.id === lawId) || fail('قانون غير موجود');
  if (l.status !== 'voting') fail('أُغلق التصويت');
  if (actor in l.votes) fail('صوّتّ مسبقاً');
  l.votes[actor] = !!yes;
  const n = s.members.length, y = Object.values(l.votes).filter(Boolean).length, no = Object.values(l.votes).length - y;
  if (y > n / 2) {
    l.status = 'accepted'; l.startsAt = now; // لا أثر رجعي: يبدأ من لحظة القبول
    if (l.payload?.ministries) { s.ministries = { ...l.payload.ministries }; s.ministryHistory.push({ at: now, map: s.ministries }); }
  } else if (no >= n / 2) l.status = 'rejected';
}
