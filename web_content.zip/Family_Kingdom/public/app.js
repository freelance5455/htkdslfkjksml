import * as E from './engine.js';
// وضع محلي: البيانات في هذا الجهاز فقط. المزامنة بين الهواتف تتطلب ربط Supabase (راجع README).
const KEY = 'family-kingdom-v1', $ = document.getElementById('app');
let S = (() => { try { return JSON.parse(localStorage.getItem(KEY)); } catch { return null; } })();
let me = sessionStorage.getItem('me'), page = 'home', msg = '';
const esc = (x) => String(x ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const save = () => localStorage.setItem(KEY, JSON.stringify(S));
const nm = (id) => { const m = S.members.find((x) => x.id === id); return m ? m.avatar + ' ' + esc(m.name) : ''; };
const act = (fn) => { try { fn(Date.now()); save(); msg = ''; } catch (e) { msg = e instanceof E.RuleError ? e.message : 'حدث خطأ غير متوقع'; console.error(e); } render(); };
const st = { new: 'جديدة', in_progress: 'قيد التنفيذ', pending: 'بانتظار المراجعة', approved: 'مقبولة', rejected: 'مرفوضة' };
const lawSt = { voting: 'قيد التصويت', accepted: 'مقبول', rejected: 'مرفوض' };

function setup() {
  $.innerHTML = `<header><h1>👑 حكومة البيت</h1><small>إعداد الأسرة</small></header><main><div class="card">
  <input id="fn" placeholder="اسم الأسرة">${[1, 2, 3, 4, 5, 6].map((i) => `<div class="row"><input id="n${i}" placeholder="${i === 1 ? 'ولي الأمر (العضو 1)' : 'العضو ' + i}"><input id="p${i}" type="password" inputmode="numeric" maxlength="4" placeholder="رمز من 4 أرقام"></div>`).join('')}
  <button data-a="create">إنشاء الأسرة</button><p class="err" ${msg ? '' : 'hidden'}>${esc(msg)}</p></div></main>`;
}
function loginView() {
  $.innerHTML = `<header><h1>👑 ${esc(S.family.name)}</h1><small>من أنت؟</small></header><main><div class="card">
  ${S.members.map((m) => `<button class="${me === m.id ? 'gold' : 'alt'}" data-a="pick:${m.id}">${m.avatar} ${esc(m.name)}</button> `).join('')}
  <input id="pin" type="password" inputmode="numeric" maxlength="4" placeholder="الرمز السري"><button data-a="login">دخول</button>
  <p class="err" ${msg ? '' : 'hidden'}>${esc(msg)}</p></div></main>`;
}
function render() {
  if (!S) return setup();
  if (!me || !S.members.find((m) => m.id === me) || !sessionStorage.getItem('auth')) return loginView();
  const now = Date.now(), pr = E.president(S, now), g = E.isGuardian(S, me), p = S.presidency;
  const left = pr ? Math.max(0, Math.ceil((p.endsAt - now) / E.DAY)) : 0;
  const pages = { home: 'الرئيسية', tasks: 'المهام', shop: 'المتجر', council: 'المجلس', me: 'حسابي', ...(g ? { admin: 'ولي الأمر' } : {}) };
  $.innerHTML = `<header><h1>👑 ${esc(S.family.name)}</h1><small>${new Date(now).toLocaleDateString('ar', { weekday: 'long', day: 'numeric', month: 'long' })} — الرئيس: ${pr ? `<span class="crown">👑</span> ${nm(pr)} (باقٍ ${left} يوم)` : 'لا يوجد'}</small></header>
  <nav>${Object.entries(pages).map(([k, v]) => `<button class="${page === k ? 'on' : 'alt'}" data-a="go:${k}">${v}</button>`).join('')}<button class="alt" data-a="logout">تبديل المستخدم</button></nav>
  <main>${msg ? `<div class="err">${esc(msg)}</div>` : ''}${views[page](now, pr, g)}<p class="note">وضع محلي: البيانات على هذا الجهاز فقط ولا تتزامن مع الهواتف الأخرى قبل إعداد الخادم.</p></main>`;
}
const views = {
  home: (now) => `<div class="card"><div class="row"><b>رصيدك</b><span class="stars">${E.balance(S, me)} ⭐</span></div><button class="gold" data-a="claim">استلام مكافأتي اليومية (5 ⭐)</button></div>
  ${S.members.map((m) => `<div class="card row"><span>${m.avatar} ${esc(m.name)}${Object.entries(S.ministries).filter(([, v]) => v === m.id).map(([k]) => ` · <small>${E.MINISTRIES[k]}</small>`).join('')}</span><span class="stars">${E.balance(S, m.id)} ⭐</span></div>`).join('')}
  <div class="card"><b>آخر المعاملات</b>${S.ledger.slice(-6).reverse().map((e) => `<div class="row note"><span>${nm(e.memberId)} — ${esc(e.reason)}</span><span>${e.amount > 0 ? '+' : ''}${e.amount}</span></div>`).join('') || '<p class="note">لا توجد معاملات</p>'}</div>`,
  tasks: (now, pr, g) => `${(g || E.isMinister(S, me)) ? '<button data-a="newtask">+ مهمة جديدة</button>' : ''}` + (S.tasks.map((t) => `<div class="card"><div class="row"><b>${esc(t.title)}</b><span class="stars">${t.stars} ⭐</span></div>
  <div class="note">${nm(t.assignee)} · ${st[t.status]}${t.rejectReason ? ' · السبب: ' + esc(t.rejectReason) : ''}</div>
  ${t.assignee === me && ['new', 'in_progress', 'rejected'].includes(t.status) ? `<button data-a="submit:${t.id}">طلب اعتماد الإنجاز</button>` : ''}
  ${t.status === 'pending' && t.assignee !== me && (g || E.isMinister(S, me)) ? `<button data-a="rv:${t.id}:1">اعتماد</button> <button class="alt" data-a="rv:${t.id}:0">رفض</button>` : ''}</div>`).join('') || '<p class="note">لا توجد مهام</p>'),
  shop: () => S.rewards.map((r) => `<div class="card row"><span><b>${esc(r.name)}</b><br><small>${r.stock === null ? '' : 'المتاح: ' + r.stock}${r.cash ? ' · مكافأة نقدية يوافق عليها ولي الأمر وينفذها خارج التطبيق' : ''}</small></span><button data-a="buy:${r.id}">${r.price} ⭐</button></div>`).join('') || '<p class="note">لم يضف ولي الأمر امتيازات بعد</p>',
  council: (now, pr, g) => `<div class="card"><b>القوانين</b>${S.laws.map((l) => `<div class="card"><b>${esc(l.title)}</b> — ${lawSt[l.status]}<div class="note">${esc(l.text)}</div>${l.status === 'voting' && !(me in l.votes) ? `<button data-a="vote:${l.id}:1">موافق</button> <button class="alt" data-a="vote:${l.id}:0">غير موافق</button>` : ''}</div>`).join('') || '<p class="note">لا توجد قوانين</p>'}
  ${(g || me === pr) ? '<button data-a="law">+ اقتراح قانون</button>' : ''}</div>
  <div class="card"><b>سحب الثقة</b>${S.noConfidence?.status === 'voting' ? `<p>طلب ضد ${nm(S.noConfidence.target)}: ${esc(S.noConfidence.reason)}</p>${me !== S.noConfidence.target && !(me in S.noConfidence.votes) ? '<button data-a="ncv:1">موافق</button> <button class="alt" data-a="ncv:0">غير موافق</button>' : ''}` : pr ? '<button class="alt" data-a="nc">طلب سحب الثقة</button>' : '<p class="note">لا يوجد رئيس</p>'}</div>
  <div class="card"><b>الاجتماع الأسبوعي</b>${pr ? '<p class="note">الرئاسة جارية.</p>' : ''}<button data-a="meeting">عرض ملخص الأسبوع واختيار الرئيس القادم</button></div>`,
  me: () => `<div class="card"><b>${nm(me)}</b><p>الرصيد: <span class="stars">${E.balance(S, me)} ⭐</span></p>${S.ledger.filter((e) => e.memberId === me).reverse().map((e) => `<div class="row note"><span>${esc(e.reason)}</span><span>${e.amount}</span></div>`).join('')}</div>`,
  admin: () => { const ec = E.economy(S); return `<div class="card"><b>الاقتصاد</b><p>إجمالي النجمات المتداولة: ${ec.total}</p>${Object.entries(ec.sources).map(([k, v]) => `<div class="row note"><span>${esc(k)}</span><span>${v}</span></div>`).join('')}<p class="note">سلامة السجل: ${E.verifyLedger(S) ? '✅ سليم' : '⚠️ يوجد عبث'}</p></div>
  <div class="card"><b>طلبات الاستبدال</b>${S.redemptions.filter((q) => q.status === 'pending').map((q) => `<div class="row"><span>${nm(q.memberId)} — ${esc(S.rewards.find((r) => r.id === q.rewardId)?.name)}</span><span><button data-a="rr:${q.id}:1">قبول</button> <button class="alt" data-a="rr:${q.id}:0">رفض</button></span></div>`).join('') || '<p class="note">لا توجد طلبات</p>'}</div>
  <div class="card"><button data-a="addreward">+ امتياز</button> <button class="alt" data-a="adjust">تصحيح إداري</button> <button class="alt" data-a="startpres">تنصيب رئيس</button> <button class="alt" data-a="ministries">توزيع الوزارات</button> <button class="alt" data-a="export">نسخ احتياطي</button></div>`; },
};
const ask = (q) => prompt(q) || '';
const A = {
  create: () => { try { S = E.createFamily({ name: $.querySelector('#fn').value, members: [1, 2, 3, 4, 5, 6].map((i) => ({ name: $.querySelector('#n' + i).value, pin: $.querySelector('#p' + i).value, avatar: ['👑', '🌟', '🦁', '🚀', '🌈', '🎨'][i - 1] })) }); save(); msg = ''; } catch (e) { msg = e.message; } render(); },
  pick: (id) => { me = id; render(); },
  login: () => { try { E.login(S, me, $.querySelector('#pin').value); sessionStorage.setItem('me', me); sessionStorage.setItem('auth', '1'); msg = ''; } catch (e) { msg = e.message || 'اختر اسمك أولاً'; } save(); render(); },
  logout: () => { sessionStorage.clear(); me = null; render(); },
  go: (k) => { page = k; render(); },
  claim: () => act((n) => E.claimDaily(S, me, n)),
  newtask: () => act((n) => E.createTask(S, me, { title: ask('اسم المهمة'), stars: +ask('عدد النجمات (1-20)'), assignee: 'm' + ask('رقم العضو (1-6)') }, n)),
  submit: (id) => act((n) => E.submitTask(S, me, id, n)),
  rv: (id, ok) => act((n) => E.reviewTask(S, me, id, ok === '1', ok === '1' ? '' : ask('سبب الرفض'), n)),
  buy: (id) => act((n) => E.requestRedeem(S, me, id, n)),
  rr: (id, ok) => act((n) => E.reviewRedeem(S, me, id, ok === '1', ok === '1' ? '' : ask('سبب الرفض'), n)),
  addreward: () => act((n) => E.addReward(S, me, { name: ask('اسم الامتياز'), price: +ask('السعر بالنجمات'), cash: confirm('مكافأة نقدية ينفذها ولي الأمر خارج التطبيق؟') }, n)),
  adjust: () => act((n) => E.adminCorrection(S, me, 'm' + ask('رقم العضو'), +ask('المبلغ (+/-)'), ask('السبب'), n)),
  startpres: () => act((n) => E.startPresidency(S, 'm' + ask('رقم العضو'), n)),
  law: () => act((n) => E.proposeLaw(S, me, { title: ask('عنوان القانون'), text: ask('نص القانون') }, n)),
  vote: (id, y) => act((n) => E.vote(S, me, id, y === '1', n)),
  nc: () => act((n) => E.requestNoConfidence(S, me, ask('سبب الطلب'), n)),
  ncv: (y) => act((n) => E.voteNoConfidence(S, me, y === '1', n)),
  ministries: () => act((n) => { const ids = ask('أرقام الأعضاء الستة بالترتيب (نظافة،تعليم،مطبخ،ترفيه،رقمي،مالية) مثال: 1,2,3,4,5,6').split(',').map((x) => 'm' + x.trim()); E.proposeMinistries(S, me, Object.fromEntries(Object.keys(E.MINISTRIES).map((k, i) => [k, ids[i]])), n); }),
  meeting: () => { const r = E.chooseNext(S, Date.now()); alert(r.winner ? 'المرشح الأعلى التزاماً: ' + S.members.find((m) => m.id === r.winner).name : 'لا يوجد مرشح مؤهل؛ يلزم تصويت الأسرة.'); },
  export: () => { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([JSON.stringify(S)], { type: 'application/json' })); a.download = 'family-kingdom-backup.json'; a.click(); },
};
$.addEventListener('click', (e) => { const b = e.target.closest('[data-a]'); if (!b) return; const [k, ...r] = b.dataset.a.split(':'); A[k]?.(...r); });
if ('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(() => {});
render();
