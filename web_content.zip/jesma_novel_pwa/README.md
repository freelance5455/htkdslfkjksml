# Jesma Novel — PWA prototype

A mobile-first, offline-first Progressive Web App prototype for African stories.

## Included
- Home, Discover, Library, Write and Profile screens
- Six original fictional sample stories and fictional demo authors
- Search and genre filtering
- Reading view and adjustable text size
- Save stories to a local library
- Create and publish demo stories locally
- Save drafts in the browser's local storage
- Simulated online/offline mode
- PWA manifest and service worker for app-shell caching

## Run it
A PWA service worker requires HTTPS or localhost. Do not open `index.html` directly from the file manager.

### Option 1: Python
From this folder, run:
```bash
python -m http.server 8000
```
Then open `http://localhost:8000` in your browser.

### Option 2: Deploy
Upload the folder to a static HTTPS host such as GitHub Pages, Netlify or Cloudflare Pages.

On Android Chrome, open the hosted site and use the browser menu's **Install app** or **Add to Home screen** option.

## Offline test
1. Open the app once while connected.
2. Browse a few screens so the app shell is cached.
3. Turn off internet or use the ⇄ button to switch the in-app demo status.
4. Reload the hosted app while offline to test the cached app shell.

The ⇄ button only simulates the connection label. Real offline behavior is determined by the device connection and service worker cache.

## Prototype data and limitations
- Sample authors, stories and community content are fictional.
- Drafts, saved stories and demo publications are stored in the current browser on the current device.
- Clearing browser/site data can remove locally stored prototype data.
- This prototype does not yet have real accounts, cloud synchronization, public publishing, comments, payments, moderation tools or cross-device backups.
- The supplied Mhokore chapter excerpt was not copied into the sample library. Obtain the author's permission before publishing any existing work.

## Next development stage
Connect a secure backend for accounts, cloud storage, author verification, moderation, real publishing, comments, sync conflict handling and optional payments. Add IndexedDB for larger offline book collections and a reliable sync queue.
