# AI Fantasy Studio — Free Edition

A mobile-first, offline-capable PWA starter app for creating fictional adult characters, browsing sample profiles, running a local demo chat, and exporting character data.

## Run
Open `www/index.html` in a browser, or serve the `www` folder over localhost/HTTPS to enable PWA installation and offline caching. On Android Chrome, open the hosted app and use **Install app** / **Add to Home screen**.

## Included
- Home screen with four sample fictional adult characters
- Character creator with 18+ validation
- Local character list, gallery and delete controls
- Friendly non-explicit demo chat (not a connected AI)
- JSON export and local data reset
- PWA manifest, icon and service worker
- Capacitor configuration and Android build notes

## Important scope
This free build is a functional prototype, not a hosted AI image generator. It does not generate explicit sexual images, imitate real people, call an AI API, require payments, or provide cloud storage. All characters are fictional adults and content is non-explicit. No subscriptions or paid features are present.

## Android APK
See `android-wrapper/README.md`. An APK could not be compiled in the current environment because Android SDK / Gradle / signing tools are unavailable. Do not treat this source ZIP as an APK.
