# Android APK wrapper notes

This project is a working offline-first PWA. The current build environment did not include Android SDK, Gradle, adb, or signing tools, so an APK has not been compiled or tested here.

To produce an APK on a computer with Android Studio / Android SDK installed:

1. Install Node.js LTS and Android Studio.
2. From the project root run `npm install @capacitor/core @capacitor/cli @capacitor/android`.
3. Run `npx cap add android` (only once), then `npx cap sync android`.
4. Run `npx cap open android`, allow Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. For a signed release APK, use **Build > Generate Signed Bundle / APK** and create your own keystore. Keep that keystore private and backed up.

The web app itself runs locally without an account, subscription, or external API. Any later connection to an AI model or image service may have separate costs; none is included in this free edition.
