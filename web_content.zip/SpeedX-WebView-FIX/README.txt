SpeedX WebView compatibility fix

Replace the old index.html in your HTML-to-APK project with this one and rebuild.

This version removes the broken intent:// navigation that Android WebView was
trying to load as an appassets web URL. The Open button now gives clear
instructions instead of causing ERR_HTTP_RESPONSE_CODE_FAILURE.

Important: launching another installed app from a WebView requires native
Android code in the APK wrapper. Controlling another app's gameplay/audio
speed also cannot be done by this HTML page.
