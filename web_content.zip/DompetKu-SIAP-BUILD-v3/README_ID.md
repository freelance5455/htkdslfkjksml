# DompetKu 3.0 — Target Dana Final

Versi ini mempertahankan konsep dan tampilan pemilihan kategori seperti versi lama, tetapi kategori di bagian **Target Dana** diganti menjadi pilihan tujuan dana.

## Target Dana
- Pemilihan tujuan menggunakan daftar pilihan/radio button seperti menu lama; pengguna cukup mengetuk salah satu pilihan.
- Pilihan tujuan: Menikah, Rumah, Dana Darurat, Dana Cadangan, Restorasi Motor, Touring, Kendaraan, Pendidikan, Liburan, Gadget, Renovasi, Modal Usaha, Sedekah, Keinginan, Investasi, Kebutuhan Keluarga, dan Lainnya.
- Tidak perlu mengetik nama target.
- Nominal target ditentukan manual.
- Dana awal dapat dimasukkan.
- Tanggal mulai dan tanggal selesai ditentukan manual; durasi tidak dibatasi pada 1/3/6/12/24 bulan.
- Aplikasi menghitung progress, kekurangan dana, sisa waktu, kebutuhan per bulan/minggu/hari.
- Tersedia informasi tempat penyimpanan dana: Cash/Tunai, Bank, E-Wallet, atau Lainnya. Jika memilih Bank, dapat memilih nama bank.
- Tempat penyimpanan dapat diedit kemudian.
- Penambahan dana ke target tercatat sebagai transaksi Dana Target.

## Pengeluaran Bulanan
Tetap terpisah dari Target Dana dan menggunakan kategori pengeluaran seperti Makan & Minuman, Transportasi, BBM, Perbaikan Motor, Kebutuhan Bulanan, dan lainnya.

## Data
Aplikasi tetap offline dan menyimpan data secara lokal di perangkat.
