
const DB_NAME = 'BoockerthLibrary';
const DB_VERSION = 2;
let db = null;

function openDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onerror = () => reject(req.error);
    req.onsuccess = () => { db = req.result; resolve(db); };
    req.onupgradeneeded = (e) => {
      const d = e.target.result;
      if (!d.objectStoreNames.contains('livros')) {
        d.createObjectStore('livros', { keyPath: 'id' });
      }
      if (!d.objectStoreNames.contains('capas')) {
        d.createObjectStore('capas', { keyPath: 'id' });
      }
      if (!d.objectStoreNames.contains('conteudo')) {
        d.createObjectStore('conteudo', { keyPath: 'id' });
      }
    };
  });
}

async function ensureDB() {
  if (!db) await openDB();
  return db;
}

const LivrosOffline = {
  async saveBook(bookId, blob, metadata = {}) {
    const d = await ensureDB();
    // Lê o blob ANTES de abrir a transação — o FileReader é assíncrono, e uma
    // transação IndexedDB fecha-se sozinha assim que não há pedidos pendentes
    // nela; se ligássemos os dois passos com um FileReader no meio, a
    // transação expirava antes do segundo put() correr ("transaction has finished").
    const dataUrl = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = () => reject(reader.error);
      reader.readAsDataURL(blob);
    });
    return new Promise((resolve, reject) => {
      const tx = d.transaction(['livros', 'conteudo'], 'readwrite');
      tx.objectStore('livros').put({ id: bookId, ...metadata, savedAt: Date.now() });
      tx.objectStore('conteudo').put({ id: bookId, data: dataUrl });
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => reject(tx.error);
    });
  },

  async getBook(bookId) {
    const d = await ensureDB();
    return new Promise((resolve, reject) => {
      const tx = d.transaction('livros', 'readonly');
      const req = tx.objectStore('livros').get(bookId);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });
  },

  async getContent(bookId) {
    const d = await ensureDB();
    return new Promise((resolve, reject) => {
      const tx = d.transaction('conteudo', 'readonly');
      const req = tx.objectStore('conteudo').get(bookId);
      req.onsuccess = () => resolve(req.result ? req.result.data : null);
      req.onerror = () => reject(req.error);
    });
  },

  async abrirLivro(bookId, onlineUrl) {
    const content = await this.getContent(bookId);
    if (content) {
      const blob = await fetch(content).then(r => r.blob());
      const url = URL.createObjectURL(blob);
      window.open(url, '_blank');
      return true;
    }
    if (navigator.onLine && onlineUrl) {
      try {
        if (window.debugLog) window.debugLog('offline-livros.js: fetch', onlineUrl);
        const resp = await fetch(onlineUrl);
        if (window.debugLog) window.debugLog('offline-livros.js: status', String(resp.status));
        if (!resp.ok) throw new Error('HTTP ' + resp.status);
        const blob = await resp.blob();
        const meta = await this.getBook(bookId) || {};
        await this.saveBook(bookId, blob, meta);
        window.open(onlineUrl, '_blank');
        return true;
      } catch (e) {
        console.warn('Falha ao cachear livro:', e);
        if (window.debugLog) window.debugLog('offline-livros.js: erro', (e && e.message) || String(e));
      }
    }
    return false;
  },

  async saveCover(bookId, dataUrl) {
    const d = await ensureDB();
    return new Promise((resolve, reject) => {
      const tx = d.transaction('capas', 'readwrite');
      tx.objectStore('capas').put({ id: bookId, data: dataUrl, savedAt: Date.now() });
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => reject(tx.error);
    });
  },

  async getCover(bookId) {
    const d = await ensureDB();
    return new Promise((resolve, reject) => {
      const tx = d.transaction('capas', 'readonly');
      const req = tx.objectStore('capas').get(bookId);
      req.onsuccess = () => resolve(req.result ? req.result.data : null);
      req.onerror = () => reject(req.error);
    });
  },

  async deleteBook(bookId) {
    const d = await ensureDB();
    return new Promise((resolve, reject) => {
      const tx = d.transaction(['livros', 'capas', 'conteudo'], 'readwrite');
      tx.objectStore('livros').delete(bookId);
      tx.objectStore('capas').delete(bookId);
      tx.objectStore('conteudo').delete(bookId);
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => reject(tx.error);
    });
  }
};

window.LivrosOffline = LivrosOffline;
