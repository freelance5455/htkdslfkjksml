ILOSTAN POJAZDÓW TRAKCYJNYCH — v4

Uruchom index.html w Chrome.

Najważniejsza zmiana:
- przycisk „📷 Dodaj zdjęcie” jest prawdziwym przyciskiem i otwiera wybór pliku/galerię;
- zdjęcie jest OPCJONALNE — pojazd można dodać bez niego;
- zdjęcia są zapisywane jako Blob w IndexedDB, a nie jako ogromny tekst Base64 w pamięci aplikacji;
- jest podgląd i możliwość usunięcia wybranego zdjęcia przed zapisem.
