Ilostan pojazdów trakcyjnych v14

W tej wersji usunięto dodawanie zdjęć. Aplikacja służy do prowadzenia rejestru pojazdów bez fotografii. Dane są zapisywane lokalnie w przeglądarce.
