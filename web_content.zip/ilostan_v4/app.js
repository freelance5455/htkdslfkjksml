const categories=[
 ["Lokomotywy elektryczne","Lokomotywy zasilane napięciem elektrycznym."],["Elektryczne zespoły trakcyjne","Elektryczne zespoły trakcyjne."],["Lokomotywy spalinowe","Lokomotywy napędzane silnikiem spalinowym."],["Spalinowe zespoły trakcyjne","Spalinowe zespoły trakcyjne."],["Pojazdy dwutrakcyjne","Pojazdy wykorzystujące dwa rodzaje napędu."],["Drezyny, pojazdy robocze","Drezyny, pojazdy robocze i specjalne."],["Lokomotywy parowe","Lokomotywy napędzane siłą pary."],["Wagon motorowy","Wagony silnikowe."]
];
const DB="ilostan_v14_db",STORE="vehicles";let db,vehicles=[];
const $=s=>document.querySelector(s),gallery=$("#gallery"),select=$("#category");
function esc(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));}
function openDB(){return new Promise((res,rej)=>{const r=indexedDB.open(DB,1);r.onupgradeneeded=()=>r.result.createObjectStore(STORE,{keyPath:"id"});r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error);});}
function tx(mode,action){return new Promise((res,rej)=>{const t=db.transaction(STORE,mode),s=t.objectStore(STORE);let r;try{r=action(s)}catch(e){rej(e);return}t.oncomplete=()=>res(r?.result);t.onerror=()=>rej(t.error);});}
const all=()=>tx("readonly",s=>s.getAll()),put=x=>tx("readwrite",s=>s.put(x)),del=id=>tx("readwrite",s=>s.delete(id)),clear=()=>tx("readwrite",s=>s.clear());
function render(){
 $("#photoCount").textContent=vehicles.length;
 document.querySelectorAll("[data-cat]").forEach(x=>x.textContent=vehicles.filter(v=>v.category===x.dataset.cat).length);
 const q=$("#search").value.trim().toLowerCase();const list=vehicles.filter(v=>[v.number,v.series,v.railway,v.place,v.category,v.description].join(" ").toLowerCase().includes(q));gallery.innerHTML="";
 if(!list.length){gallery.innerHTML=`<div class="empty">${vehicles.length?"Brak wyników wyszukiwania.":"Nie dodano jeszcze żadnych pojazdów."}</div>`;return;}
 list.slice().reverse().forEach(v=>{const card=document.createElement("article");card.className="card";card.innerHTML=`<div class="card-body"><h3>${esc(v.number)}</h3><div class="meta">${esc(v.series||"Brak serii")} · ${esc(v.category)}<br>${esc(v.railway||"Brak linii")} · ${esc(v.place||"Brak miejsca")} · ${esc(v.date||"Brak daty")}</div>${v.description?`<div class="desc">${esc(v.description)}</div>`:""}<div class="card-actions"><button class="delete" data-delete="${esc(v.id)}" type="button">Usuń</button></div></div>`;gallery.appendChild(card);});
}
categories.forEach(([name,desc])=>{const o=document.createElement("option");o.value=name;o.textContent=name;select.appendChild(o);const row=document.createElement("div");row.className="cat";row.innerHTML=`<div class="cat-name">${esc(name)}<small>${esc(desc)}</small></div><div class="count" data-cat="${esc(name)}">0</div><button class="dark" data-filter="${esc(name)}" type="button">Otwórz</button>`;$("#categories").appendChild(row);});
$("#vehicleForm").addEventListener("submit",async e=>{e.preventDefault();const number=$("#number").value.trim();if(!number)return alert("Podaj numer pojazdu.");try{const v={id:crypto.randomUUID?crypto.randomUUID():Date.now()+"",number,series:$("#series").value.trim(),railway:$("#railway").value.trim(),category:select.value,place:$("#place").value.trim(),date:$("#date").value,description:$("#description").value.trim(),image:null};await put(v);vehicles=await all();e.target.reset();render();alert("Pojazd został dodany!");}catch(err){console.error(err);alert("Nie udało się zapisać pojazdu.");}});
$("#search").addEventListener("input",render);
$("#categories").addEventListener("click",e=>{if(e.target.dataset.filter){$("#search").value=e.target.dataset.filter;render();gallery.scrollIntoView({behavior:"smooth"});}});
gallery.addEventListener("click",e=>{const id=e.target.dataset.delete;if(id&&confirm("Usunąć ten pojazd?"))del(id).then(async()=>{vehicles=await all();render();});});
$("#clearAll").addEventListener("click",async()=>{if(confirm("Usunąć wszystkie zapisane pojazdy?")){await clear();vehicles=[];render();}});
$("#exportData").addEventListener("click",()=>{try{const b=new Blob([JSON.stringify(vehicles)],{type:"application/json"}),u=URL.createObjectURL(b),a=document.createElement("a");a.href=u;a.download="ilostan-kopia.json";a.click();setTimeout(()=>URL.revokeObjectURL(u),1000);}catch(e){alert("Nie udało się wyeksportować kopii.");}});
$("#importData").addEventListener("change",async e=>{const f=e.target.files?.[0];if(!f)return;try{const arr=JSON.parse(await f.text());if(!Array.isArray(arr))throw 0;await clear();for(const x of arr)await put({...x,image:null});vehicles=await all();render();alert("Kopia została wczytana.");}catch(err){console.error(err);alert("Nieprawidłowy plik kopii.");}finally{e.target.value="";}});
(async()=>{try{db=await openDB();vehicles=await all();render();}catch(e){console.error(e);gallery.innerHTML="<div class='empty'>Nie można uruchomić pamięci aplikacji. Otwórz Ilostan w Chrome.</div>";}})();
