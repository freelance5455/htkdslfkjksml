$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
Write-Host "=== Building Mizo_q TikTok Toolkit V6.0 Debug APK ==="
.\gradlew.bat :app:testDebugUnitTest :app:assembleDebug
Copy-Item "app\build\outputs\apk\debug\app-debug.apk" -Destination "mizo-q-tiktok-toolkit-v6.apk" -Force
Write-Host "Built APK successfully: .\mizo-q-tiktok-toolkit-v6.apk"
