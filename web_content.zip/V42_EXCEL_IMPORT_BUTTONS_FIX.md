# V42 — Excel Import Buttons Fix

Based directly on V41: `DailyProgressManager_TODAY_CASH_PULLS_v41_EXCEL_IMPORT_ANDROID_THREAD_FIX.zip`.

## Fixed
- **Download Excel template:** Android uses the native Save dialog; Web uses a browser download with a same-origin fetch/anchor fallback.
- **Choose File:** now a real button. Android explicitly launches the native document picker through `AndroidDPM.pickImportFile()`; Web triggers the file input directly.
- **Import Items:** existing parsed-row → Supabase batch insert flow is preserved; the button becomes enabled after a successful file selection and preview.

## Android reliability
- Native Save/Open document dialogs are launched on the Android UI thread.
- WebChromeClient file selection remains supported as a fallback.

## Preserved
- All V41 app features, including Supabase login/agent separation, Balance/Carol Bank Katwe, Banked delete, Productive Days, and Excel preview/import logic.
- No Supabase schema/functions were changed.
