package ru.putrazvitiya.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import android.text.TextUtils;
import java.util.*;

public class MainActivity extends Activity {
    int bg = Color.rgb(246,248,252), card = Color.WHITE, ink = Color.rgb(31,41,55),
        muted = Color.rgb(107,114,128), accent = Color.rgb(91,99,220), green = Color.rgb(34,160,112);
    LinearLayout root, content, nav;
    android.content.SharedPreferences prefs;
    int xp, level, completed;
    boolean dark;
    String page = "Главная";
    final String[] tabs = {"Главная","Тренировки","Учёба","Дисциплина","Профиль"};
    final String[] workouts = {"Мягкая зарядка — 5 минут","Спокойная прогулка","Лёгкая растяжка","Отдых и восстановление","Упражнения для осанки"};
    final String[] study = {"Решить 3 примера по математике","Прочитать 5–10 страниц","Повторить 5 новых слов","Решить одну логическую задачу","Повторить правило русского языка"};
    final String[] habits = {"Заправить кровать","Навести порядок 5 минут","Сделать часть домашнего задания","Помочь родителям","Подготовить вещи на завтра"};

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("progress", MODE_PRIVATE);
        xp = prefs.getInt("xp",0); completed = prefs.getInt("completed",0);
        dark = prefs.getBoolean("dark",false);
        updateColors(); show();
    }
    void updateColors() {
        if(dark){ bg=Color.rgb(18,23,38); card=Color.rgb(31,39,59); ink=Color.WHITE; muted=Color.rgb(190,198,215); accent=Color.rgb(145,151,255); }
        else { bg=Color.rgb(246,248,252); card=Color.WHITE; ink=Color.rgb(31,41,55); muted=Color.rgb(107,114,128); accent=Color.rgb(91,99,220); }
        level=Math.min(100, xp/100+1);
    }
    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+.5f); }
    TextView text(String s,int size, int color, boolean bold){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if(bold)t.setTypeface(null,Typeface.BOLD); t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }
    LinearLayout column(){ LinearLayout l=new LinearLayout(this); l.setOrientation(1); return l; }
    LinearLayout row(){ LinearLayout l=new LinearLayout(this); l.setOrientation(0); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    GradientDrawable shape(int color,int radius){
        GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    void pad(View v,int a){v.setPadding(dp(a),dp(a),dp(a),dp(a));}
    void gap(LinearLayout l,int h){ View v=new View(this); l.addView(v,new LinearLayout.LayoutParams(1,dp(h))); }
    void save(){ prefs.edit().putInt("xp",xp).putInt("completed",completed).putBoolean("dark",dark).apply(); updateColors(); }
    void show(){
        updateColors();
        root=column(); root.setBackgroundColor(bg);
        LinearLayout header=column(); pad(header,20);
        TextView brand=text("ПУТЬ РАЗВИТИЯ",13,accent,true); header.addView(brand);
        TextView title=text(page,27,ink,true); header.addView(title);
        root.addView(header);
        ScrollView scroll=new ScrollView(this);
        content=column(); content.setPadding(dp(16),0,dp(16),dp(20)); scroll.addView(content);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        nav=row(); nav.setPadding(dp(4),dp(8),dp(4),dp(8)); nav.setBackgroundColor(card);
        for(String tab:tabs){
            TextView b=text(icon(tab)+"\n"+tab,10,page.equals(tab)?accent:muted,true);
            b.setGravity(Gravity.CENTER); b.setPadding(dp(2),dp(5),dp(2),dp(5));
            nav.addView(b,new LinearLayout.LayoutParams(0,dp(52),1));
            b.setOnClickListener(v->{page=tab;show();});
        }
        root.addView(nav); setContentView(root);
        if(page.equals("Главная")) home(); else if(page.equals("Тренировки")) listPage("Тренировки",workouts,"💪"); else if(page.equals("Учёба")) listPage("Учёба",study,"📚"); else if(page.equals("Дисциплина")) listPage("Дисциплина",habits,"🎯"); else profile();
    }
    String icon(String t){ if(t.equals("Главная"))return "⌂"; if(t.equals("Тренировки"))return "✦"; if(t.equals("Учёба"))return "▤"; if(t.equals("Дисциплина"))return "✓"; return "☺"; }
    void panel(LinearLayout parent, View child){
        LinearLayout box=column(); box.setBackground(shape(card,18)); pad(box,16);
        box.addView(child); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.bottomMargin=dp(12); parent.addView(box,p);
    }
    void home(){
        LinearLayout hero=column(); TextView hello=text("Каждый маленький шаг — уже успех! 🌱",18,ink,true); hero.addView(hello);
        gap(hero,10); TextView lv=text("УРОВЕНЬ "+level+" из 100",14,accent,true); hero.addView(lv);
        TextView points=text(xp+" XP  •  "+(100-(xp%100))+" XP до следующего уровня",14,muted,false); hero.addView(points);
        ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); bar.setMax(100); bar.setProgress(xp%100); hero.addView(bar,new LinearLayout.LayoutParams(-1,dp(12)));
        panel(content,hero);
        LinearLayout stats=row();
        stats.addView(stat("✅ "+completed,"заданий"),new LinearLayout.LayoutParams(0,-2,1));
        stats.addView(stat("🏅 "+(xp/250),"наград"),new LinearLayout.LayoutParams(0,-2,1));
        panel(content,stats);
        addHeading(content,"План на сегодня");
        addTask(content,"💧","Начни с воды и спокойного утра",10);
        addTask(content,"📖","Почитай или позанимайся 10 минут",15);
        addTask(content,"🚶","Немного прогуляйся или сделай зарядку",15);
        addTask(content,"🧹","Наведи порядок в одном небольшом месте",10);
        addHeading(content,"Твой путь");
        TextView note=text("Уровни открываются постепенно. Пропущенный день не отнимает очки — отдых тоже часть развития.",14,muted,false); panel(content,note);
    }
    View stat(String big,String small){ LinearLayout l=column(); l.addView(text(big,20,ink,true)); l.addView(text(small,12,muted,false)); return l; }
    void addHeading(LinearLayout p,String s){ TextView t=text(s,19,ink,true); t.setPadding(dp(2),dp(8),0,dp(10)); p.addView(t); }
    void addTask(LinearLayout p,String emoji,String s,int points){
        LinearLayout r=row(); TextView e=text(emoji,23,ink,true); r.addView(e);
        LinearLayout mid=column(); mid.addView(text(s,15,ink,true)); mid.addView(text("+"+points+" XP • можно выполнить в своём темпе",11,muted,false));
        LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(0,-2,1); mp.leftMargin=dp(12); r.addView(mid,mp);
        Button b=new Button(this); b.setText("Готово"); b.setTextSize(11); b.setOnClickListener(v->finishTask(points));
        r.addView(b); panel(p,r);
    }
    void finishTask(int points){ xp+=points; completed++; save(); show(); Toast.makeText(this,"Отлично! +"+points+" XP 🌟",Toast.LENGTH_SHORT).show(); }
    void listPage(String title,String[] items,String emoji){
        TextView intro=text("Выбирай посильное задание. Можно остановиться, если устал(а).",14,muted,false); panel(content,intro);
        for(int i=0;i<items.length;i++) addTask(content,emoji,items[i],10+i*2);
        if(title.equals("Тренировки")){ TextView rest=text("Важно: тренируйся без боли и соревнования с другими. Чередуй активность с отдыхом. Если есть сомнения по нагрузке, обсуди её со взрослым.",13,muted,false); panel(content,rest); }
    }
    void profile(){
        addHeading(content,"Твой профиль");
        LinearLayout c=column(); c.addView(text("Уровень "+level,22,ink,true)); c.addView(text("Всего опыта: "+xp+" XP",15,muted,false)); c.addView(text("Выполнено заданий: "+completed,15,muted,false)); panel(content,c);
        addHeading(content,"Все 100 уровней");
        for(int i=1;i<=100;i+=10){ int end=Math.min(100,i+9); TextView t=text("Уровни "+i+"–"+end+(level>=i?"  •  доступно":"  •  впереди"),14,level>=i?green:muted,true); panel(content,t); }
        Button theme=new Button(this); theme.setText(dark?"Включить светлую тему":"Включить тёмную тему"); theme.setOnClickListener(v->{dark=!dark;save();show();}); content.addView(theme);
        Button reset=new Button(this); reset.setText("Сбросить прогресс"); reset.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Сбросить прогресс?").setMessage("Все XP и выполненные задания будут обнулены.").setNegativeButton("Отмена",null).setPositiveButton("Сбросить",(d,w)->{xp=0;completed=0;save();show();}).show()); content.addView(reset);
        Button reminder=new Button(this); reminder.setText("Настроить напоминание"); reminder.setOnClickListener(v->scheduleReminder()); content.addView(reminder);
        TextView privacy=text("Прогресс хранится только на этом устройстве. Родительский контроль и синхронизация пока не подключены.",13,muted,false); panel(content,privacy);
    }
    void scheduleReminder(){
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=android.content.pm.PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},7); return;
        }
        Calendar c=Calendar.getInstance(); c.add(Calendar.MINUTE,1);
        Intent intent=new Intent(this, ReminderReceiver.class);
        PendingIntent pi=PendingIntent.getBroadcast(this,1,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);
        am.set(AlarmManager.RTC_WAKEUP,c.getTimeInMillis(),pi);
        Toast.makeText(this,"Напоминание запланировано примерно через минуту.",Toast.LENGTH_LONG).show();
    }
}
