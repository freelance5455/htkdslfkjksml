// Run after "npx cap add android" / "npx cap sync": locks landscape, goes immersive fullscreen, keeps the screen on.
const fs = require('fs');
const path = require('path');
const android = path.join(__dirname, '..', 'android');
if (!fs.existsSync(android)) { console.log('No android/ folder yet, skipping'); process.exit(0); }

// 1. Landscape orientation
const manifestPath = path.join(android, 'app/src/main/AndroidManifest.xml');
let manifest = fs.readFileSync(manifestPath, 'utf8');
if (!manifest.includes('android:screenOrientation')) {
  manifest = manifest.replace('<activity', '<activity\n            android:screenOrientation="sensorLandscape"');
  fs.writeFileSync(manifestPath, manifest);
}

// 2. Immersive fullscreen + keep screen on
const javaDir = path.join(android, 'app/src/main/java/com/kartcircuit/game');
fs.mkdirSync(javaDir, { recursive: true });
fs.writeFileSync(path.join(javaDir, 'MainActivity.java'), `package com.kartcircuit.game;

import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }
}
`);
console.log('Android project patched (landscape, immersive, keep screen on)');
