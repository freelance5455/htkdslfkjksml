// Builds www/ from src/car-game-3d.html:
//  - copies Three.js and PeerJS from node_modules into www/lib so the app works OFFLINE
//  - rewrites the CDN <script> tags to those local files
//  - adds PWA bits (manifest + service worker registration) and hides the fullscreen button inside the app
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const www = path.join(root, 'www');

fs.rmSync(www, { recursive: true, force: true });
fs.mkdirSync(path.join(www, 'lib'), { recursive: true });

const libs = [
  ['three/build/three.min.js', 'lib/three.min.js'],
  ['peerjs/dist/peerjs.min.js', 'lib/peerjs.min.js']
];
for (const [from, to] of libs) {
  const src = path.join(root, 'node_modules', from);
  if (!fs.existsSync(src)) throw new Error('Missing ' + from + '. Run "npm install" first.');
  fs.copyFileSync(src, path.join(www, to));
}

let html = fs.readFileSync(path.join(root, 'src', 'car-game-3d.html'), 'utf8');
const threeTag = /<script src="https:\/\/cdnjs\.cloudflare\.com\/ajax\/libs\/three\.js\/r128\/three\.min\.js"><\/script>/;
const peerTag = /<script src="https:\/\/unpkg\.com\/peerjs@[^"]+"><\/script>/;
if (!threeTag.test(html) || !peerTag.test(html)) throw new Error('Could not find the CDN script tags in src/car-game-3d.html');
html = html.replace(threeTag, '<script src="lib/three.min.js"></script>')
           .replace(peerTag, '<script src="lib/peerjs.min.js"></script>');

html = html.replace('</head>', '<link rel="manifest" href="manifest.webmanifest">\n</head>');
html = html.replace('</body>', `<script>
  // Inside the Android app the screen is already fullscreen and locked to landscape
  if (window.Capacitor && Capacitor.isNativePlatform && Capacitor.isNativePlatform()) {
    var b = document.getElementById('fs-btn'); if (b) b.style.display = 'none';
  }
  // When hosted on the web, register the offline cache so it can be installed as a PWA
  if ('serviceWorker' in navigator && location.protocol.indexOf('http') === 0) navigator.serviceWorker.register('sw.js');
</script>
</body>`);
fs.writeFileSync(path.join(www, 'index.html'), html);

for (const f of ['manifest.webmanifest', 'sw.js', 'icon-192.png', 'icon-512.png']) {
  fs.copyFileSync(path.join(root, 'pwa', f), path.join(www, f));
}
console.log('www/ ready');
