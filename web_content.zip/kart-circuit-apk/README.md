# Kart Circuit 3D: Android APK project

This folder wraps the game (`src/car-game-3d.html`) in an Android app using Capacitor.
The app is locked to landscape, always fullscreen, keeps the screen on, and works offline
(Three.js and PeerJS are bundled instead of loaded from a CDN). Online multiplayer still needs internet.

## Option A: build in the cloud (no Android tools needed)
1. Create a free GitHub repository and upload everything in this folder (keep the `.github` folder).
2. Open the **Actions** tab, choose **Build Android APK**, press **Run workflow**.
3. When it finishes (about 5 minutes), download **kart-circuit-debug-apk** from the run page and unzip it.
4. Copy `app-debug.apk` to your phone and open it. Android will ask you to allow installs from your browser or file manager.

## Option B: build on your computer
Needs Node 18+, JDK 17 and Android Studio (it installs the Android SDK).
- macOS / Linux: `./build.sh`
- Windows: `build.bat`

The APK appears at `android/app/build/outputs/apk/debug/app-debug.apk`.
You can also run `npx cap open android` and press Run in Android Studio to launch it on a phone or emulator.

## Option C: no APK, install as a web app (PWA)
Run `npm install && npm run prepare:web`, then upload the `www/` folder to any HTTPS host
(GitHub Pages, Netlify, Cloudflare Pages). Open the link in Chrome on Android and choose **Add to Home screen**.

## Publishing on Google Play
The debug APK is for testing. For the Play Store you need a signed release build (an `.aab`):
1. Create a keystore: `keytool -genkey -v -keystore kart.keystore -alias kart -keyalg RSA -keysize 2048 -validity 10000`
2. In Android Studio: **Build > Generate Signed Bundle / APK**, choose Android App Bundle, select your keystore.
3. Upload the `.aab` in the Google Play Console. Keep the keystore safe, you need it for every update.

## Changing things
- Game code: edit `src/car-game-3d.html`, then rebuild. 
- App name / ID: `capacitor.config.json` (if you change the ID, also change the package path in `scripts/patch-android.js`).
- Icon: replace the PNGs in `assets/` and rebuild.
