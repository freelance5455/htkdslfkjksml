#!/usr/bin/env bash
# Local build (macOS / Linux). Needs Node 18+, JDK 17 and the Android SDK (ANDROID_HOME set; Android Studio installs it).
set -e
npm install
npm run prepare:web
[ -d android ] || npx cap add android
npx capacitor-assets generate --android || echo "icon generation skipped"
node scripts/patch-android.js
npx cap sync android
(cd android && chmod +x gradlew && ./gradlew assembleDebug)
echo
echo "APK: android/app/build/outputs/apk/debug/app-debug.apk"
