@echo off
REM Local build on Windows. Needs Node 18+, JDK 17 and the Android SDK (Android Studio installs it).
call npm install || exit /b 1
call npm run prepare:web || exit /b 1
if not exist android call npx cap add android || exit /b 1
call npx capacitor-assets generate --android
call node scripts\patch-android.js || exit /b 1
call npx cap sync android || exit /b 1
cd android
call gradlew.bat assembleDebug || exit /b 1
echo.
echo APK: android\app\build\outputs\apk\debug\app-debug.apk
