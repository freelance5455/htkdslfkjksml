(function () {
  if (screen && screen.orientation && typeof screen.orientation.lock === "function") {
    screen.orientation.lock("landscape").catch(function () {});
  }

  var style = document.createElement("style");
  style.id = "landscapeFixStyle";
  style.textContent =
    "html, body { width: 100%; height: 100%; margin: 0; padding: 0; overflow: hidden; }" +
    "canvas { max-width: 100vw; max-height: 100vh; object-fit: contain; }";
  document.head.appendChild(style);
})();
