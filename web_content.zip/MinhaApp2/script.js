function iniciarApp() {
  alert("MinhaApp 2 está funcionando! 🚀");
}

function mostrarInicio() {
  alert("🏠 Você está no Início.");
}

function mostrarPerfil() {
  alert("👤 Esta será a área do seu Perfil.");
}

function mostrarSobre() {
  alert("ℹ️ MinhaApp 2 - versão 1.0");
}
if ("serviceWorker" in navigator) {
  window.addEventListener("load", function() {
    navigator.serviceWorker.register("./service-worker.js")
      .then(function() {
        console.log("Service Worker registrado com sucesso.");
      })
      .catch(function(erro) {
        console.log("Erro no Service Worker:", erro);
      });
  });
}
if ("serviceWorker" in navigator) {
  window.addEventListener("load", function() {
    navigator.serviceWorker.register("./service-worker.js")
      .then(function() {
        console.log("Service Worker registrado com sucesso.");
      })
      .catch(function(erro) {
        console.log("Erro no Service Worker:", erro);
      });
  });
}