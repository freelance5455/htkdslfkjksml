#include<iostream>
using namespace std;

float calculoDeMedia(float teste1, float teste2, float exame)
{
    return (teste1 * 0.25) + (teste2 * 0.25) + (exame * 0.50);
}
void situacao (float media)
{
    if(media < 7)
        cout << "Situacao: Reprovado" << endl;

    else if(media >= 7 && media < 10)
        cout << "Situacao: Admitido a recorrencia" << endl;

    else if(media >= 10 && media < 14)
        cout << "Situacao: Suficiente" << endl;

    else if(media >= 14 && media < 16)
        cout << "Situacao: Bom" << endl;

    else
        cout << "Situacao: Dispensado" << endl;
}

int main()
{
    string nome;
    float teste1, teste2, exame, media;

    cout << "Digita o teu nome" << endl;
    cin >> nome;

    cout << "Ola " << nome << endl;

    do{
        cout << "Digita anota do primeiro teste: " << endl;
        cin >> teste1;

        if (teste1 < 0 && teste1 > 20)
            cout << "Nota invalida! Tenta novamente.\n";

    } while (teste1 < 0 && teste1 > 20);

    do{
        cout << "Digita a nota do segundo teste: " << endl;
        cin >> teste2;

        if (teste2 < 0 && teste2 > 20)
            cout << "Nota invalida! Tenta novamente.\n";

    } while (teste2 < 0 && teste2 > 20);

    do{
        cout << "Digita a nota do exame: " << endl;
        cin >> exame;

        if (exame < 0 && exame > 20)
            cout << "Nota invalida! Tenta novamente.\n";

    } while (exame < 0 && exame > 20);

    media = calculoDeMedia(teste1, teste2, exame);

    cout << nome << " voce tem a media de "
         << media << " valores" << endl;

    situacao(media);

    return 0;
}