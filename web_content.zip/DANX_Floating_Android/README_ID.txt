DANX STORE - Floating Window Android project

FITUR:
- Membuka panel DANX STORE dalam aplikasi Android.
- Tombol LOG TO MLBB memeriksa izin overlay.
- Jika izin sudah diberikan, bubble DANX muncul dan Mobile Legends dibuka.
- Bubble dapat digeser.
- Ketuk bubble untuk membuka panel mini RANK BOOSTER.
- Tombol — mengecilkan panel menjadi bubble.
- Tombol CLOSE menutup floating window.

PENTING:
1. Ini adalah SOURCE PROJECT Android Studio, bukan APK siap instal.
2. Buka folder project ini di Android Studio lalu build APK.
3. Instal APK di perangkat Android.
4. Jalankan DANX STORE, masuk ke panel, buka tab INJECT, tekan LOG TO MLBB.
5. Saat diminta, izinkan "Tampil di atas aplikasi lain" untuk DANX STORE.
6. Kembali ke DANX STORE dan tekan LOG TO MLBB sekali lagi.
7. Panel mengambang akan muncul di atas aplikasi lain.

Batasan:
- RANK BOOSTER di floating window adalah pintasan/tampilan UI saja.
  Tidak mengubah rank, matchmaking, file game, atau anti-cheat.
- Floating window membutuhkan izin khusus Android.
- Jika Mobile Legends tidak terpasang dengan package com.mobile.legends,
  sesuaikan package name game sesuai versi yang terpasang.
