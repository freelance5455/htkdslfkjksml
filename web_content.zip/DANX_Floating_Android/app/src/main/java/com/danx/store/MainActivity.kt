package com.danx.store

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var web: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(DanxBridge(), "DanxAndroid")
        setContentView(web)
        web.loadUrl("file:///android_asset/danx_store.html")
    }

    inner class DanxBridge {
        @JavascriptInterface
        fun launchMlbbWithFloating() {
            runOnUiThread {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(this@MainActivity,
                        "Izinkan DANX tampil di atas aplikasi agar floating bisa digunakan.",
                        Toast.LENGTH_LONG).show()
                    val permission = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                    startActivity(permission)
                    return@runOnUiThread
                }

                startService(Intent(this@MainActivity, FloatingService::class.java))
                val game = packageManager.getLaunchIntentForPackage("com.mobile.legends")
                if (game != null) {
                    startActivity(game)
                } else {
                    Toast.makeText(this@MainActivity,
                        "Mobile Legends belum terpasang.",
                        Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
