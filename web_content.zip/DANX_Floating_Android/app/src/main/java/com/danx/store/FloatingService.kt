package com.danx.store

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private var root: View? = null
    private var expanded = false
    private var params: WindowManager.LayoutParams? = null
    private var downX = 0
    private var downY = 0
    private var startX = 0
    private var startY = 0

    override fun onCreate() {
        super.onCreate()
        startForeground(71, makeNotification())
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    private fun makeNotification(): Notification {
        val channelId = "danx_floating"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "DANX Floating", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
        val builder = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, channelId) else Notification.Builder(this)
        return builder.setContentTitle("DANX Floating aktif")
            .setContentText("Panel mengambang DANX STORE sedang berjalan.")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true).build()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun bg(color: Int, radius: Int, stroke: Int = Color.TRANSPARENT): GradientDrawable {
        return GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke)
        }
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(7), dp(8), dp(7))
        }
    }

    private fun showBubble() {
        removeCurrent()
        expanded = false
        val bubble = label("DX", 17f, Color.WHITE, true).apply {
            background = bg(Color.rgb(55, 75, 224), 50, Color.rgb(91, 239, 185))
            elevation = dp(8).toFloat()
            setOnTouchListener(dragListener { togglePanel() })
        }
        attach(bubble, dp(58), dp(58))
    }

    private fun showPanel() {
        removeCurrent()
        expanded = true
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = bg(Color.rgb(5, 45, 40), 18, Color.rgb(31, 218, 155))
            elevation = dp(12).toFloat()
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = label("DANX MINI PANEL", 13f, Color.WHITE, true)
        title.gravity = Gravity.CENTER_VERTICAL or Gravity.START
        header.addView(title, LinearLayout.LayoutParams(0, dp(42), 1f))
        val minimize = label("—", 20f, Color.WHITE, true).apply {
            background = bg(Color.rgb(20, 91, 73), 9)
            setOnClickListener { showBubble() }
        }
        header.addView(minimize, LinearLayout.LayoutParams(dp(42), dp(38)))
        header.setOnTouchListener(dragListener(null))
        panel.addView(header)

        val rank = label("🏆  RANK BOOSTER", 14f, Color.rgb(112, 244, 190), true).apply {
            background = bg(Color.rgb(8, 79, 62), 12, Color.rgb(28, 170, 120))
            setOnClickListener {
                Toast.makeText(this@FloatingService,
                    "Pintasan Rank Booster. Tidak mengubah rank atau gameplay.",
                    Toast.LENGTH_SHORT).show()
            }
        }
        val rankParams = LinearLayout.LayoutParams(dp(230), dp(58))
        rankParams.topMargin = dp(10)
        panel.addView(rank, rankParams)

        val close = label("✕  CLOSE", 12f, Color.WHITE, true).apply {
            background = bg(Color.rgb(155, 48, 58), 10)
            setOnClickListener { stopSelf() }
        }
        val closeParams = LinearLayout.LayoutParams(dp(230), dp(42))
        closeParams.topMargin = dp(9)
        panel.addView(close, closeParams)

        attach(panel, dp(254), dp(174))
    }

    private fun togglePanel() {
        if (expanded) showBubble() else showPanel()
    }

    private fun dragListener(onTap: (() -> Unit)?): View.OnTouchListener {
        return View.OnTouchListener { view, event ->
            val p = params ?: return@OnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX.toInt()
                    downY = event.rawY.toInt()
                    startX = p.x
                    startY = p.y
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val dx = event.rawX.toInt() - downX
                    val dy = event.rawY.toInt() - downY
                    if (kotlin.math.abs(dx) < dp(7) && kotlin.math.abs(dy) < dp(7)) {
                        onTap?.invoke()
                    }
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    p.x = startX + (event.rawX.toInt() - downX)
                    p.y = startY + (event.rawY.toInt() - downY)
                    try { wm.updateViewLayout(view, p) } catch (_: Exception) {}
                    true
                }
                else -> false
            }
        }
    }

    private fun attach(view: View, width: Int, height: Int) {
        root = view
        val type = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        params = WindowManager.LayoutParams(
            width, height, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(14)
            y = dp(180)
        }
        wm.addView(view, params)
    }

    private fun removeCurrent() {
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        root = null
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int =
        START_NOT_STICKY

    override fun onDestroy() {
        removeCurrent()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
