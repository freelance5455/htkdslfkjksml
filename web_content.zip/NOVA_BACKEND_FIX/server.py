import os
import httpx
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

API_KEY = os.getenv("OPENAI_API_KEY")
app = FastAPI(title="NOVA Secure AI Backend")
# Em produção, substitua * pelos domínios exatos onde o NOVA será hospedado.
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=False, allow_methods=["POST", "OPTIONS"], allow_headers=["Content-Type"])

class ChatRequest(BaseModel):
    model: str = "gpt-4o-mini"
    messages: list[dict]

@app.get("/")
def health():
    return {"status": "NOVA backend online"}

@app.post("/chat")
async def chat(data: ChatRequest):
    if not API_KEY:
        raise HTTPException(status_code=500, detail="OPENAI_API_KEY não configurada no servidor")
    payload = {"model": data.model, "messages": data.messages}
    try:
        async with httpx.AsyncClient(timeout=60) as client:
            response = await client.post("https://api.openai.com/v1/chat/completions", headers={"Authorization": f"Bearer {API_KEY}"}, json=payload)
        if response.is_error:
            try: detail = response.json()
            except Exception: detail = response.text
            raise HTTPException(status_code=response.status_code, detail=detail)
        return response.json()
    except httpx.RequestError as exc:
        raise HTTPException(status_code=502, detail=f"Falha ao acessar OpenAI: {exc.__class__.__name__}")
