# አገናኝ — Android Project

This project packages the Agenagn V2 prototype as an Android WebView app.

## Build APK
1. Open this folder in Android Studio (latest stable version recommended).
2. Let Android Studio sync/download the Android Gradle Plugin and SDK.
3. Select **Build > Build APK(s)**.
4. The debug APK will be under `app/build/outputs/apk/debug/`.

Application ID: `com.agenagn.app`
Version: 1.0
Minimum Android: 6.0 (API 23)
