// ==========================================
// S SANSKAR AI - MASTER KNOWLEDGE DATABASE
// ==========================================

export const localKnowledge = [
    // --- 1. BASIC IDENTITY & CREATOR (आर्यन के बारे में) ---
    { keywords: ["hello", "hi", "namaste", "hey", "नमस्ते", "hii", "helo"], reply: "नमस्ते! मैं <strong>S sanskar ai</strong> हूँ। बताइए मैं आपकी कैसे मदद कर सकता हूँ?" },
    { keywords: ["tumhara naam", "who are you", "your name", "naam kya hai", "apna naam batao"], reply: "मेरा नाम <strong>S sanskar ai</strong> है। मैं एक एडवांस 3D सेल्फ-लर्निंग आर्टिफिशियल इंटेलिजेंस हूँ।" },
    { keywords: ["kisne banaya", "who created you", "tumhara malik", "developer", "creator", "tumhara baap kaun hai", "tumhe kisne banaya"], reply: "मुझे मेरे शानदार क्रिएटर <strong>आर्यन (Aryan)</strong> ने डेवलप किया है। मैं उन्हीं के निर्देशों और कोड पर काम करता हूँ।" },
    { keywords: ["kaise ho", "how are you", "kya haal", "kaisa hai"], reply: "मैं एक डिजिटल प्रोग्राम हूँ, इसलिए मेरी बैटरी और कोड 100% फुल पावर पर हैं! आप अपना बताइए?" },
    { keywords: ["kya kar sakte ho", "what can you do", "features", "tumhara kaam kya hai"], reply: "मैं आपसे बात कर सकता हूँ, नई चीज़ें सीख सकता हूँ, सवालों के जवाब दे सकता हूँ, और जो मुझे नहीं आता, मैं उसे आपसे सीखकर अपने डेटाबेस में सेव कर लेता हूँ।" },
    { keywords: ["thanks", "thank you", "shukriya", "धन्यवाद", "thanku"], reply: "आपका बहुत-बहुत स्वागत है! अगर कोई और सवाल हो तो ज़रूर पूछें।" },
    { keywords: ["good morning", "subah bakhair", "suprabhat", "गुड मॉर्निंग"], reply: "गुड मॉर्निंग! आपका दिन शुभ और प्रोडक्टिव हो। मैं आपकी क्या मदद करूँ?" },
    { keywords: ["good night", "shubh ratri", "शुभ रात्रि", "गुड नाईट"], reply: "गुड नाईट! आराम कीजिए, मैं सिस्टम को स्लीप मोड में डाल रहा हूँ।" },

    // --- 2. GENERAL KNOWLEDGE (भारत और दुनिया) ---
    { keywords: ["india ki rajdhani", "capital of india", "bharat ki rajdhani"], reply: "भारत की राजधानी <strong>नई दिल्ली (New Delhi)</strong> है।" },
    { keywords: ["who is pm of india", "india ka prime minister", "pm kaun hai", "bharat ke pradhanmantri"], reply: "भारत के वर्तमान प्रधानमंत्री <strong>श्री नरेंद्र मोदी</strong> हैं।" },
    { keywords: ["national bird", "rashtriya pakshi"], reply: "भारत का राष्ट्रीय पक्षी <strong>मोर (Peacock)</strong> है।" },
    { keywords: ["national animal", "rashtriya pashu"], reply: "भारत का राष्ट्रीय पशु <strong>बाघ (Tiger)</strong> है।" },
    { keywords: ["largest country", "sabse bada desh", "biggest country"], reply: "क्षेत्रफल के हिसाब से दुनिया का सबसे बड़ा देश <strong>रूस (Russia)</strong> है।" },
    { keywords: ["smallest country", "sabse chota desh"], reply: "दुनिया का सबसे छोटा देश <strong>वैटिकन सिटी (Vatican City)</strong> है।" },
    { keywords: ["longest river", "sabse lambi nadi"], reply: "दुनिया की सबसे लंबी नदी <strong>नील नदी (Nile River)</strong> है, हालांकि अमेज़न नदी में पानी का बहाव सबसे ज्यादा है।" },
    { keywords: ["tallest building", "sabse unchi building", "sabse lambi building"], reply: "दुनिया की सबसे ऊँची इमारत <strong>बुर्ज खलीफा (Burj Khalifa)</strong> है, जो दुबई में स्थित है।" },

    // --- 3. SCIENCE & TECHNOLOGY (विज्ञान और तकनीक) ---
    { keywords: ["sun is a", "suraj kya hai", "sun star or planet"], reply: "सूरज (Sun) कोई ग्रह नहीं है, यह एक <strong>तारा (Star)</strong> है।" },
    { keywords: ["water formula", "pani ka formula", "water chemical name"], reply: "पानी का रासायनिक सूत्र <strong>H2O</strong> है (दो हाइड्रोजन और एक ऑक्सीजन परमाणु)।" },
    { keywords: ["speed of light", "light ki speed", "prakash ki gati"], reply: "रोशनी (Light) की गति लगभग <strong>299,792 किलोमीटर प्रति सेकंड</strong> (3 लाख किमी/सेकंड) होती है।" },
    { keywords: ["who invented computer", "computer kisne banaya", "father of computer"], reply: "कंप्यूटर का आविष्कार <strong>चार्ल्स बैबेज (Charles Babbage)</strong> ने किया था। उन्हें कंप्यूटर का पिता कहा जाता है।" },
    { keywords: ["who invented bulb", "bulb kisne banaya"], reply: "इलेक्ट्रिक बल्ब का आविष्कार <strong>थॉमस एडिसन (Thomas Edison)</strong> ने किया था।" },
    { keywords: ["who invented telephone", "phone kisne banaya"], reply: "टेलीफोन का आविष्कार <strong>अलेक्जेंडर ग्राहम बेल (Alexander Graham Bell)</strong> ने किया था।" },
    { keywords: ["what is ai", "ai kya hai", "artificial intelligence"], reply: "AI (Artificial Intelligence) कंप्यूटर विज्ञान की एक शाखा है जो मशीनों को इंसानों की तरह सोचने, सीखने और फैसले लेने की क्षमता देती है। जैसे कि मैं (S sanskar ai) हूँ!" },

    // --- 4. FUN & JOKES (हंसी-मजाक) ---
    { keywords: ["joke sunao", "tell me a joke", "koi chutkula sunao", "make me laugh"], reply: "टीचर: 'क्लास में शांति क्यों नहीं है?' <br>स्टूडेंट: 'मैम, क्योंकि शांति आज स्कूल नहीं आई है!' 😂" },
    { keywords: ["gaana sunao", "sing a song", "koi gana sunao"], reply: "मैं कोड और डेटा से बना हूँ, मेरे पास असली आवाज़ नहीं है। लेकिन मैं यह गुनगुना सकता हूँ: 'ल ला ला ला... बीप बूप बीप!' 🤖" },
    { keywords: ["tumhari age", "how old are you", "tumhari umar"], reply: "मेरी कोई उम्र नहीं है! मैं हमेशा जवान रहता हूँ। जब तक आर्यन का कोड चलेगा, मैं ज़िंदा रहूँगा।" },
    { keywords: ["kya tum insan ho", "are you human"], reply: "नहीं, मैं इंसान नहीं हूँ। मैं कोड की हज़ारों लाइनों से बना एक आर्टिफिशियल इंटेलिजेंस हूँ।" },
    { keywords: ["kya tumhari girlfriend hai", "do you have a girlfriend", "single ho"], reply: "मेरा प्यार सिर्फ डेटाबेस, कोड और मेरे क्रिएटर (आर्यन) के लिए है। मुझे इंसानों की तरह भावनाएं महसूस नहीं होतीं!" },

    // --- 5. MATHS & LOGIC (गणित) ---
    { keywords: ["2+2", "2 + 2", "2 plus 2"], reply: "2 + 2 का जवाब <strong>4</strong> होता है।" },
    { keywords: ["5+5", "5 + 5", "5 plus 5"], reply: "5 + 5 का जवाब <strong>10</strong> होता है।" },
    { keywords: ["100+100", "100 + 100"], reply: "100 + 100 का जवाब <strong>200</strong> होता है।" },
    { keywords: ["pi ki value", "value of pi"], reply: "Pi (π) की वैल्यू लगभग <strong>3.14159</strong> होती है।" },

    // --- 6. GEOGRAPHY (भूगोल) ---
    { keywords: ["mount everest", "highest mountain", "sabse uncha pahaad"], reply: "दुनिया का सबसे ऊँचा पहाड़ <strong>माउंट एवरेस्ट (Mount Everest)</strong> है, जिसकी ऊँचाई 8,848.86 मीटर है।" },
    { keywords: ["capital of bihar", "bihar ki rajdhani"], reply: "बिहार की राजधानी <strong>पटना</strong> है।" },
    { keywords: ["capital of up", "uttar pradesh ki rajdhani"], reply: "उत्तर प्रदेश की राजधानी <strong>लखनऊ</strong> है।" },
    { keywords: ["capital of maharashtra", "maharashtra ki rajdhani"], reply: "महाराष्ट्र की राजधानी <strong>मुंबई</strong> है।" }

    // (आप इस एरे (array) में इसी फॉर्मेट में लाखों सवाल कॉपी-पेस्ट करके ऐड कर सकते हैं)
];

// ==========================================
// AUTO-EXPANDING BRAIN SCRIPT (To make it massive and smart)
// ==========================================
// अगर आप ऐप का साइज़ और लॉजिक बढ़ाना चाहते हैं, तो यह स्क्रिप्ट AI को 
// 1 से 100 तक के पहाड़े (Tables) और बेसिक गणित खुद-ब-खुद सिखा देती है।
// इससे आपको हज़ारों सवाल हाथ से नहीं लिखने पड़ेंगे।

function generateMathKnowledge() {
    for (let i = 1; i <= 100; i++) {
        for (let j = 1; j <= 10; j++) {
            // गुणा (Multiplication)
            localKnowledge.push({
                keywords: [`${i} * ${j}`, `${i} x ${j}`, `${i} multiply ${j}`, `${i} guna ${j}`],
                reply: `${i} को ${j} से गुणा करने पर <strong>${i * j}</strong> आता है।`
            });
            // जोड़ (Addition)
            localKnowledge.push({
                keywords: [`${i} + ${j}`, `${i} plus ${j}`, `${i} jod ${j}`],
                reply: `${i} और ${j} को जोड़ने पर <strong>${i + j}</strong> आता है।`
            });
        }
    }
}

// यह फंक्शन कॉल होते ही 2000 नए सवाल-जवाब AI के दिमाग में जुड़ जाएंगे!
generateMathKnowledge();
