package com.shopmanager.app

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.print.PrintManager
import android.print.PrintAttributes
import android.content.Context
import org.json.JSONObject
import android.webkit.JavascriptInterface
import android.webkit.*
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.Toast
import android.app.Dialog

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private val fileRequest = 4102
    private val backupRequest = 4103
    private val restoreRequest = 4104
    private var pendingBackupJson: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16, 28, 54)
        window.navigationBarColor = Color.rgb(11, 20, 38)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        webView = WebView(this)
        webView.layoutParams = FrameLayout.LayoutParams(-1, -1)
        setContentView(webView)
        configureWebView(webView)
        if (savedInstanceState == null) webView.loadUrl("file:///android_asset/index.html")
        else webView.restoreState(savedInstanceState)
    }

    private fun configureWebView(view: WebView) {
        view.setBackgroundColor(Color.rgb(11, 20, 38))
        view.settings.javaScriptEnabled = true
        view.settings.domStorageEnabled = true
        view.settings.allowFileAccess = true
        view.settings.allowContentAccess = true
        view.settings.javaScriptCanOpenWindowsAutomatically = true
        view.settings.setSupportMultipleWindows(true)
        view.settings.loadsImagesAutomatically = true
        view.settings.defaultTextEncodingName = "UTF-8"
        view.addJavascriptInterface(PrintBridge(view), "ShopPrint")
        view.addJavascriptInterface(FileBridge(), "ShopFiles")
        view.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                callback: ValueCallback<Array<Uri>>?,
                params: FileChooserParams?
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                val intent = params?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                return try {
                    startActivityForResult(intent, fileRequest)
                    true
                } catch (_: ActivityNotFoundException) {
                    fileCallback = null
                    Toast.makeText(this@MainActivity, "برنامه‌ای برای انتخاب فایل پیدا نشد", Toast.LENGTH_LONG).show()
                    false
                }
            }

            override fun onCreateWindow(
                view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message?
            ): Boolean {
                val popup = WebView(this@MainActivity)
                configureWebView(popup)
                val dialog = Dialog(this@MainActivity)
                dialog.setContentView(popup)
                dialog.window?.setLayout(-1, -1)
                dialog.show()
                dialog.window?.setLayout(-1, -1)
                popup.webChromeClient = object : WebChromeClient() {
                    override fun onCloseWindow(window: WebView?) {
                        dialog.dismiss()
                        popup.destroy()
                    }
                    override fun onShowFileChooser(webView: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?): Boolean {
                        return this@MainActivity.run {
                            fileCallback?.onReceiveValue(null)
                            fileCallback = callback
                            val intent = params?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                                addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
                            }
                            try { startActivityForResult(intent, fileRequest); true }
                            catch (_: Exception) { fileCallback = null; false }
                        }
                    }
                }
                val transport = resultMsg?.obj as? WebView.WebViewTransport ?: return false
                transport.webView = popup
                resultMsg.sendToTarget()
                return true
            }
        }
        view.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                if (uri.scheme == "http" || uri.scheme == "https") {
                    try { startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (_: Exception) {}
                    return true
                }
                return false
            }
        }
    }



    private inner class FileBridge {
        @JavascriptInterface
        fun saveBackup(json: String) {
            runOnUiThread {
                pendingBackupJson = json
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                    putExtra(Intent.EXTRA_TITLE, "shop-backup-${System.currentTimeMillis()}.json")
                }
                try {
                    startActivityForResult(intent, backupRequest)
                } catch (e: Exception) {
                    pendingBackupJson = null
                    Toast.makeText(this@MainActivity, "امکان ذخیره فایل وجود ندارد", Toast.LENGTH_LONG).show()
                }
            }
        }

        @JavascriptInterface
        fun restoreBackup() {
            runOnUiThread {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                try {
                    startActivityForResult(intent, restoreRequest)
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "امکان انتخاب فایل وجود ندارد", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private inner class PrintBridge(private val target: WebView) {
        @JavascriptInterface
        fun print() {
            runOnUiThread {
                try {
                    val manager = getSystemService(Context.PRINT_SERVICE) as PrintManager
                    val adapter = target.createPrintDocumentAdapter("فاکتور فروش")
                    manager.print(
                        "فاکتور فروش",
                        adapter,
                        PrintAttributes.Builder().build()
                    )
                } catch (e: Exception) {
                    Toast.makeText(
                        this@MainActivity,
                        "باز کردن پنجره چاپ ناموفق بود: ${e.localizedMessage}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == fileRequest) {
            val result = if (resultCode == Activity.RESULT_OK) {
                WebChromeClient.FileChooserParams.parseResult(resultCode, data)
            } else null
            fileCallback?.onReceiveValue(result)
            fileCallback = null
        }
        if (requestCode == backupRequest) {
            val json = pendingBackupJson
            pendingBackupJson = null
            if (resultCode == Activity.RESULT_OK && data?.data != null && json != null) {
                try {
                    contentResolver.openOutputStream(data.data!!)?.use { it.write(json.toByteArray(Charsets.UTF_8)) }
                        ?: throw IllegalStateException("فایل قابل نوشتن نیست")
                    Toast.makeText(this, "نسخه پشتیبان ذخیره شد", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "ذخیره پشتیبان ناموفق بود: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                }
            }
        }
        if (requestCode == restoreRequest && resultCode == Activity.RESULT_OK && data?.data != null) {
            try {
                val json = contentResolver.openInputStream(data.data!!)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                    ?: throw IllegalStateException("فایل قابل خواندن نیست")
                webView.evaluateJavascript("window.restoreBackupFromJson(${JSONObject.quote(json)});", null)
            } catch (e: Exception) {
                Toast.makeText(this, "خواندن فایل پشتیبان ناموفق بود: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
