package com.shopmanager.app

import android.app.Activity
import android.app.Dialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Message
import android.print.PrintAttributes
import android.print.PrintManager
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var pendingBackupJson: String? = null
    private val fileRequest = 4102
    private val backupRequest = 4103
    private val restoreRequest = 4104

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16, 28, 54)
        window.navigationBarColor = Color.rgb(11, 20, 38)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        webView = WebView(this)
        webView.layoutParams = FrameLayout.LayoutParams(-1, -1)
        setContentView(webView)
        configureWebView(webView)
        if (savedInstanceState == null) webView.loadUrl("file:///android_asset/index.html")
        else webView.restoreState(savedInstanceState)
    }

    private fun configureWebView(view: WebView, closeAction: (() -> Unit)? = null) {
        view.setBackgroundColor(Color.rgb(11, 20, 38))
        view.settings.javaScriptEnabled = true
        view.settings.domStorageEnabled = true
        view.settings.allowFileAccess = true
        view.settings.allowContentAccess = true
        view.settings.javaScriptCanOpenWindowsAutomatically = true
        view.settings.setSupportMultipleWindows(true)
        view.settings.loadsImagesAutomatically = true
        view.settings.defaultTextEncodingName = "UTF-8"
        view.addJavascriptInterface(AndroidBridge(view, closeAction), "AndroidApp")
        view.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(wv: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                val intent = params?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
                return try { startActivityForResult(intent, fileRequest); true } catch (_: ActivityNotFoundException) {
                    fileCallback = null
                    Toast.makeText(this@MainActivity, "برنامه‌ای برای انتخاب فایل پیدا نشد", Toast.LENGTH_LONG).show(); false
                }
            }
            override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message?): Boolean {
                val popup = WebView(this@MainActivity)
                val dialog = Dialog(this@MainActivity)
                dialog.setContentView(popup)
                dialog.setOnDismissListener { try { popup.destroy() } catch (_: Exception) {} }
                dialog.show()
                dialog.window?.setLayout(-1, -1)
                configureWebView(popup) { if (dialog.isShowing) dialog.dismiss() }
                val transport = resultMsg?.obj as? WebView.WebViewTransport ?: run { dialog.dismiss(); return false }
                transport.webView = popup
                resultMsg.sendToTarget()
                return true
            }
            override fun onCloseWindow(window: WebView?) { closeAction?.invoke() }
        }
        view.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                if (uri.scheme == "http" || uri.scheme == "https") {
                    try { startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (_: Exception) {}
                    return true
                }
                return false
            }
        }
    }

    private inner class AndroidBridge(private val target: WebView, private val closeAction: (() -> Unit)?) {
        @JavascriptInterface fun printInvoice() {
            runOnUiThread {
                try {
                    val manager = getSystemService(Context.PRINT_SERVICE) as PrintManager
                    manager.print("فاکتور فروش", target.createPrintDocumentAdapter("فاکتور فروش"), PrintAttributes.Builder().build())
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "باز کردن پنجره چاپ ناموفق بود: ${e.localizedMessage ?: ""}", Toast.LENGTH_LONG).show()
                }
            }
        }
        @JavascriptInterface fun closeInvoice() {
            runOnUiThread { if (closeAction != null) closeAction.invoke() else Toast.makeText(this@MainActivity, "این صفحه قابل بستن نیست", Toast.LENGTH_SHORT).show() }
        }
        @JavascriptInterface fun saveBackup(json: String) {
            runOnUiThread {
                pendingBackupJson = json
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"
                    putExtra(Intent.EXTRA_TITLE, "shop-backup-${System.currentTimeMillis()}.json")
                }
                try { startActivityForResult(intent, backupRequest) } catch (_: Exception) {
                    pendingBackupJson = null
                    Toast.makeText(this@MainActivity, "امکان ذخیره فایل پشتیبان وجود ندارد", Toast.LENGTH_LONG).show()
                }
            }
        }
        @JavascriptInterface fun restoreBackup() {
            runOnUiThread {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"; addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                try { startActivityForResult(intent, restoreRequest) } catch (_: Exception) {
                    Toast.makeText(this@MainActivity, "امکان انتخاب فایل پشتیبان وجود ندارد", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == fileRequest) {
            val result = if (resultCode == Activity.RESULT_OK) WebChromeClient.FileChooserParams.parseResult(resultCode, data) else null
            fileCallback?.onReceiveValue(result); fileCallback = null; return
        }
        if (requestCode == backupRequest) {
            val json = pendingBackupJson; pendingBackupJson = null
            if (resultCode == Activity.RESULT_OK && data?.data != null && json != null) {
                try {
                    contentResolver.openOutputStream(data.data!!)?.use { it.write(json.toByteArray(Charsets.UTF_8)); it.flush() }
                        ?: throw IllegalStateException("فایل قابل نوشتن نیست")
                    Toast.makeText(this, "نسخه پشتیبان با موفقیت ذخیره شد", Toast.LENGTH_LONG).show()
                } catch (e: Exception) { Toast.makeText(this, "ذخیره پشتیبان ناموفق بود: ${e.localizedMessage ?: ""}", Toast.LENGTH_LONG).show() }
            }
            return
        }
        if (requestCode == restoreRequest && resultCode == Activity.RESULT_OK && data?.data != null) {
            try {
                val json = contentResolver.openInputStream(data.data!!)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                    ?: throw IllegalStateException("فایل قابل خواندن نیست")
                webView.evaluateJavascript("window.restoreBackupFromJson(${JSONObject.quote(json)});", null)
            } catch (e: Exception) { Toast.makeText(this, "خواندن فایل پشتیبان ناموفق بود: ${e.localizedMessage ?: ""}", Toast.LENGTH_LONG).show() }
        }
    }
    override fun onSaveInstanceState(outState: Bundle) { webView.saveState(outState); super.onSaveInstanceState(outState) }
    @Suppress("DEPRECATION") override fun onBackPressed() { if (webView.canGoBack()) webView.goBack() else super.onBackPressed() }
    override fun onDestroy() { if (::webView.isInitialized) { webView.stopLoading(); webView.destroy() }; super.onDestroy() }
}
