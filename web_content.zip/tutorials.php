<?php
declare(strict_types=1);
require_once __DIR__.'/app/auth.php';
auth_require_user();
header('Location: tools-tutorials.php?tab=tutorials', true, 302);
exit;
