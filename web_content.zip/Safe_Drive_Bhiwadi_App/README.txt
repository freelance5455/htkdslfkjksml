SAFE DRIVE BHIWADI — Mobile App Starter
========================================

Included:
- index.html: mobile-friendly Hindi booking app/site
- Call button for 8685842774
- WhatsApp booking button and booking form
- Gold/black design

IMPORTANT:
This is a working mobile web app file, NOT a compiled Android APK yet.
You can open index.html in a browser to test it. To install as a true APK,
it must be packaged with an Android WebView project and built/signed using
an Android build service or Android Studio. This bundle does not pretend
that an APK has already been compiled.

For a quick phone test:
1. Extract the ZIP.
2. Open index.html in Chrome or another browser.
3. Try the Call and WhatsApp booking buttons.
