# Build the AI Reseller APK from GitHub

This project is configured so GitHub Actions can build an Android APK without a computer-side Android Studio setup.

## On your phone

1. Upload the changed `client/package.json`, `client/vite.config.ts`, `client/capacitor.config.ts`, and `.github/workflows/build-apk.yml` files to your GitHub repository.
2. In GitHub, open **Actions** → **Build Android APK** → **Run workflow**.
3. Wait for the workflow to finish.
4. Open the completed workflow run and download the artifact named **ai-reseller-debug-apk**.
5. Extract the artifact and install `app-debug.apk` on your Android phone.

## Backend

The APK contains the React frontend. The app's login, products, orders, analytics, AI assistant, and other data features require the Express/PostgreSQL backend from `/server` to be hosted online.

If the backend is hosted, set a GitHub repository variable named `VITE_API_URL` to its HTTPS base URL before running the workflow. Do not put OpenAI or database secrets in the frontend.
