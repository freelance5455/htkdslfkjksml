import QRCode from "qrcode";
import { Html5Qrcode } from "html5-qrcode";
import "./style.css";
import {api, configured, native, Billing, Ads, plans, saveSession, clearSession, adPremium} from './services.js';

const $ = s => document.querySelector(s);
const supportedLanguages=["ps","fa","en","ar","ur"];
const savedLanguage=localStorage.lang||"ps";
const state = {tab:"home",lang:supportedLanguages.includes(savedLanguage)?savedLanguage:"ps",user:null,premium:false,subscription:null,products:[],admin:null,adminUsers:[],scanner:null};
const words = {
 ps:{home:"کور",tools:"وسایل",quiz:"پوښتنې",code:"کوډ",premium:"پریمیم",account:"حساب",admin:"اډمین",welcome:"TechHub ته ښه راغلاست",search:"لټون...",generate:"جوړول",copy:"کاپي",save:"ساتل",login:"ننوتل",register:"نوی حساب",logout:"وتل",email:"ایمیل",password:"پټ نوم",name:"نوم",free:"وړیا",pro:"Pro",business:"Business"},
 en:{home:"Home",tools:"Tools",quiz:"Quiz",code:"Code",premium:"Premium",account:"Account",admin:"Admin",welcome:"Welcome to TechHub",search:"Search...",generate:"Generate",copy:"Copy",save:"Save",login:"Login",register:"Register",logout:"Logout",email:"Email",password:"Password",name:"Name",free:"Free",pro:"Pro",business:"Business"},
 fa:{home:"خانه",tools:"ابزارها",quiz:"آزمون",code:"کدنویسی",premium:"ویژه",account:"حساب",admin:"مدیریت",welcome:"به تک‌هاب خوش آمدید",search:"جستجو...",generate:"ایجاد",copy:"کپی",save:"ذخیره",login:"ورود",register:"ثبت نام",logout:"خروج",email:"ایمیل",password:"رمز عبور",name:"نام",free:"رایگان",pro:"پرو",business:"تجاری"},
 ar:{home:"الرئيسية",tools:"الأدوات",quiz:"اختبار",code:"البرمجة",premium:"مميز",account:"الحساب",admin:"الإدارة",welcome:"مرحباً بك في TechHub",search:"بحث...",generate:"إنشاء",copy:"نسخ",save:"حفظ",login:"دخول",register:"تسجيل",logout:"خروج",email:"البريد",password:"كلمة المرور",name:"الاسم",free:"مجاني",pro:"برو",business:"أعمال"},
 ur:{home:"ہوم",tools:"ٹولز",quiz:"کوئز",code:"کوڈ",premium:"پریمیم",account:"اکاؤنٹ",admin:"ایڈمن",welcome:"TechHub میں خوش آمدید",search:"تلاش...",generate:"بنائیں",copy:"کاپی",save:"محفوظ",login:"لاگ ان",register:"رجسٹر",logout:"لاگ آؤٹ",email:"ای میل",password:"پاس ورڈ",name:"نام",free:"مفت",pro:"پرو",business:"بزنس"}
};
const t=k => words[state.lang]?.[k]||words.en[k]||k;
// UI localization for all languages currently offered by TechHub.
const uiTranslations = {"Home":["کور","خانه","الرئيسية","ہوم"],"Tools":["وسایل","ابزارها","الأدوات","ٹولز"],"Quiz":["پوښتنې","آزمون","اختبار","کوئز"],"Code":["کوډ","کدنویسی","البرمجة","کوڈ"],"Premium":["پریمیم","ویژه","مميز","پریمیم"],"Account":["حساب","حساب","الحساب","اکاؤنٹ"],"Admin":["اډمین","مدیریت","الإدارة","ایڈمن"],"Welcome to TechHub":["TechHub ته ښه راغلاست","به تک‌هاب خوش آمدید","مرحباً بك في TechHub","TechHub میں خوش آمدید"],"Search...":["لټون...","جستجو...","بحث...","تلاش..."],"Generate":["جوړول","ایجاد","إنشاء","بنائیں"],"Copy":["کاپي","کپی","نسخ","کاپی"],"Save":["ساتل","ذخیره","حفظ","محفوظ کریں"],"Login":["ننوتل","ورود","دخول","لاگ ان"],"Register":["نوی حساب","ثبت نام","تسجيل","رجسٹر"],"Logout":["وتل","خروج","خروج","لاگ آؤٹ"],"Email":["ایمیل","ایمیل","البريد الإلكتروني","ای میل"],"Password":["پټ نوم","رمز عبور","كلمة المرور","پاس ورڈ"],"Name":["نوم","نام","الاسم","نام"],"Free":["وړیا","رایگان","مجاني","مفت"],"Explore TechHub":["TechHub وپلټئ","کاوش در تک‌هاب","استكشف TechHub","TechHub دریافت کریں"],"Tools, learning, coding and useful utilities in one place.":["وسایل، زده کړه، پروګرام‌لیکنه او ګټور امکانات په یوه ځای کې.","ابزارها، آموزش، برنامه‌نویسی و امکانات کاربردی در یک‌جا.","الأدوات والتعلم والبرمجة والمرافق المفيدة في مكان واحد.","ٹولز، سیکھنا، کوڈنگ اور مفید سہولیات ایک ہی جگہ۔"],"Explore tools":["وسایل وپلټئ","کاوش ابزارها","استكشف الأدوات","ٹولز دیکھیں"],"Quick access":["چټک لاسرسی","دسترسی سریع","وصول سريع","فوری رسائی"],"Popular tools":["مشهور وسایل","ابزارهای پرکاربرد","الأدوات الشائعة","مقبول ٹولز"],"Tools Library":["د وسایلو کتابتون","کتابخانه ابزارها","مكتبة الأدوات","ٹولز لائبریری"],"Password Generator":["د پټ نوم جوړوونکی","تولیدکننده رمز عبور","مولّد كلمات المرور","پاس ورڈ جنریٹر"],"Create a strong random password":["یو پیاوړی تصادفي پټ نوم جوړ کړئ","یک رمز عبور تصادفی و قوی بسازید","أنشئ كلمة مرور عشوائية قوية","ایک مضبوط بے ترتیب پاس ورڈ بنائیں"],"QR Generator & Scanner":["د QR جوړوونکی او سکینر","سازنده و اسکنر QR","إنشاء ومسح رمز QR","کیو آر بنانے اور اسکین کرنے کا آلہ"],"Create and scan QR codes":["QR کوډونه جوړ او سکین کړئ","کدهای QR را بسازید و اسکن کنید","أنشئ رموز QR وامسحها","کیو آر کوڈ بنائیں اور اسکین کریں"],"Unit Converter":["د واحدونو بدلوونکی","تبدیل واحد","محول الوحدات","یونٹ کنورٹر"],"Convert common measurements":["عامې اندازې بدلې کړئ","واحدهای رایج را تبدیل کنید","حوّل وحدات القياس الشائعة","عام پیمائشیں تبدیل کریں"],"Code Playground":["د کوډ تمرینځای","محیط آزمایش کد","ساحة تجربة البرمجة","کوڈ پلے گراؤنڈ"],"Write and run simple HTML":["ساده HTML ولیکئ او وچلوئ","HTML ساده بنویسید و اجرا کنید","اكتب وشغّل HTML بسيطاً","سادہ HTML لکھیں اور چلائیں"],"Knowledge Quiz":["د پوهې ازموینه","آزمون دانش","اختبار المعرفة","علمی کوئز"],"Test your knowledge":["خپله پوهه وازمویئ","دانش خود را بیازمایید","اختبر معلوماتك","اپنے علم کو جانچیں"],"Language Support":["د ژبو ملاتړ","پشتیبانی زبان‌ها","دعم اللغات","زبانوں کی معاونت"],"Pashto, Dari, English, Arabic, Urdu":["پښتو، دري، انګلیسي، عربي، اردو","پشتو، دری، انگلیسی، عربی، اردو","البشتوية، الدرية، الإنجليزية، العربية، الأردية","پشتو، دری، انگریزی، عربی، اردو"],"Length":["اوږدوالی","طول","الطول","لمبائی"],"Enter text or URL":["متن یا URL ولیکئ","متن یا نشانی اینترنتی وارد کنید","أدخل نصاً أو رابطاً","متن یا URL درج کریں"],"QR Code Generator":["د QR کوډ جوړوونکی","سازنده کد QR","منشئ رمز QR","کیو آر کوڈ جنریٹر"],"QR Scanner":["د QR سکینر","اسکنر QR","ماسح QR","کیو آر اسکینر"],"Start camera scan":["د کامرې سکین پیل کړئ","شروع اسکن با دوربین","ابدأ المسح بالكاميرا","کیمرے سے اسکین شروع کریں"],"Stop":["ودرول","توقف","إيقاف","روکیں"],"Convert":["بدلول","تبدیل","تحويل","تبدیل کریں"],"Kilometers → Miles":["کیلومتر → مایل","کیلومتر → مایل","كيلومتر → ميل","کلومیٹر → میل"],"Meters → Feet":["متر → فټه","متر → فوت","متر → قدم","میٹر → فٹ"],"Kilograms → Pounds":["کیلوګرام → پونډ","کیلوگرم → پوند","كيلوغرام → رطل","کلوگرام → پاؤنڈ"],"Centimeters → Inches":["سانتي‌متر → انچ","سانتی‌متر → اینچ","سنتيمتر → بوصة","سینٹی میٹر → انچ"],"Celsius → Fahrenheit":["سانتي‌ګراد → فارنهایټ","سلسیوس → فارنهایت","مئوية → فهرنهايت","سیلسیس → فارن ہائیٹ"],"Next question":["بله پوښتنه","پرسش بعدی","السؤال التالي","اگلا سوال"],"HTML / CSS / JS Playground":["د HTML / CSS / JS تمرینځای","محیط آزمایش HTML / CSS / JS","ساحة تجربة HTML / CSS / JS","HTML / CSS / JS پلے گراؤنڈ"],"Hello TechHub!":["سلام TechHub!","سلام تک‌هاب!","مرحباً TechHub!","ہیلو TechHub!"],"Edit this HTML and run it.":["دا HTML سم او وچلوئ.","این HTML را ویرایش و اجرا کنید.","حرّر HTML هذا وشغّله.","اس HTML میں ترمیم کریں اور چلائیں۔"],"Run code":["کوډ وچلوئ","اجرای کد","تشغيل الكود","کوڈ چلائیں"],"Cloud account ready":["کلاوډ حساب چمتو دی","حساب ابری آماده است","الحساب السحابي جاهز","کلاؤڈ اکاؤنٹ تیار ہے"],"د سرور نښلول پاتې دي":["د سرور نښلول پاتې دي","اتصال سرور باقی مانده است","لم يتم ربط الخادم بعد","سرور سے رابطہ باقی ہے"],"د اعلانونو محرمیت":["د اعلانونو محرمیت","حریم خصوصی تبلیغات","خصوصية الإعلانات","اشتہارات کی رازداری"],"د تادیاتو سرور او Google Play محصولات لا نه دي نښلول شوي؛ اوس هېڅ پیسې نه اخیستل کېږي.":["د تادیاتو سرور او Google Play محصولات لا نه دي نښلول شوي؛ اوس هېڅ پیسې نه اخیستل کېږي.","سرور پرداخت و محصولات Google Play هنوز متصل نشده‌اند؛ فعلاً هیچ پولی دریافت نمی‌شود.","لم يتم ربط خادم الدفع ومنتجات Google Play بعد؛ لا يتم تحصيل أي أموال حالياً.","ادائیگی سرور اور Google Play مصنوعات ابھی منسلک نہیں؛ فی الحال کوئی رقم وصول نہیں کی جا رہی۔"],"وړیا وسایل او زده کړه":["وړیا وسایل او زده کړه","ابزارها و آموزش رایگان","أدوات وتعلّم مجانيان","مفت ٹولز اور تعلیم"],"بیه له Google Play څخه اخیستل کېږي":["بیه له Google Play څخه اخیستل کېږي","قیمت از Google Play دریافت می‌شود","يتم جلب السعر من Google Play","قیمت Google Play سے حاصل کی جائے گی"],"له تایید وروسته بې‌اعلانه تجربه؛ اوسني وسایل ټولو ته وړیا دي.":["له تایید وروسته بې‌اعلانه تجربه؛ اوسني وسایل ټولو ته وړیا دي.","تجربه بدون تبلیغ پس از تأیید؛ ابزارهای فعلی برای همه رایگان‌اند.","تجربة بلا إعلانات بعد التأكيد؛ الأدوات الحالية مجانية للجميع.","تصدیق کے بعد اشتہارات کے بغیر تجربہ؛ موجودہ ٹولز سب کے لیے مفت ہیں۔"],"د Google Play له لارې ګډون":["د Google Play له لارې ګډون","اشتراک از طریق Google Play","الاشتراك عبر Google Play","Google Play کے ذریعے سبسکرپشن"],"پخوانی ګډون بېرته راوړل":["پخوانی ګډون بېرته راوړل","بازیابی اشتراک قبلی","استعادة الاشتراك السابق","پچھلی سبسکرپشن بحال کریں"],"د ګډون اداره / لغوه کول":["د ګډون اداره / لغوه کول","مدیریت / لغو اشتراک","إدارة الاشتراك / إلغاؤه","سبسکرپشن کا انتظام / منسوخی"],"اوسنی پلان: ":["اوسنی پلان: ","طرح فعلی: ","الخطة الحالية: ","موجودہ پلان: "],"حساب":["حساب","حساب","الحساب","اکاؤنٹ"],"رول: ":["رول: ","نقش: ","الدور: ","کردار: "],"خوندي ننوتل / نوی حساب":["خوندي ننوتل / نوی حساب","ورود امن / حساب جدید","تسجيل دخول آمن / حساب جديد","محفوظ لاگ ان / نیا اکاؤنٹ"],"سرور لا نه دی خپور شوی. اډمین او د کاروونکو ننوتل تر نښلولو پورې غیر فعال دي.":["سرور لا نه دی خپور شوی. اډمین او د کاروونکو ننوتل تر نښلولو پورې غیر فعال دي.","سرور هنوز منتشر نشده است. ورود مدیر و کاربران تا زمان اتصال غیرفعال است.","لم يتم نشر الخادم بعد. تسجيل دخول المدير والمستخدمين معطّل حتى الربط.","سرور ابھی شائع نہیں ہوا۔ منسلک ہونے تک ایڈمن اور صارفین کا لاگ ان غیر فعال ہے۔"],"اډمین ایمیل ټاکل شوی؛ اجازه یوازې په سرور کې ورکول کېږي، نه د ایمیل په لیکلو.":["اډمین ایمیل ټاکل شوی؛ اجازه یوازې په سرور کې ورکول کېږي، نه د ایمیل په لیکلو.","ایمیل مدیر تنظیم شده؛ دسترسی فقط در سرور اعطا می‌شود، نه با وارد کردن ایمیل.","تم تعيين بريد المدير؛ تُمنح الصلاحية على الخادم فقط، وليس بمجرد كتابة البريد.","ایڈمن ای میل مقرر ہے؛ اجازت صرف سرور پر دی جاتی ہے، صرف ای میل لکھنے سے نہیں۔"],"اډمین ته خوندي ننوتل اړین دي.":["اډمین ته خوندي ننوتل اړین دي.","ورود امن مدیر لازم است.","يلزم تسجيل دخول المدير بشكل آمن.","ایڈمن کا محفوظ لاگ ان ضروری ہے۔"],"د اډمین معلومات راوړل کېږي…":["د اډمین معلومات راوړل کېږي…","اطلاعات مدیر در حال دریافت است…","جارٍ جلب بيانات المدير…","ایڈمن کی معلومات حاصل کی جا رہی ہیں…"],"کاروونکي":["کاروونکي","کاربران","المستخدمون","صارفین"],"فعال ګډونونه":["فعال ګډونونه","اشتراک‌های فعال","الاشتراكات النشطة","فعال سبسکرپشنز"],"تایید شوي پیرودونه":["تایید شوي پیرودونه","خریدهای تأییدشده","عمليات الشراء المؤكدة","تصدیق شدہ خریداریاں"],"وروستي کاروونکي":["وروستي کاروونکي","کاربران اخیر","المستخدمون الأخيرون","حالیہ صارفین"],"سم ایمیل او لږ تر لږه ۱۰ توري پاسورډ ولیکئ.":["سم ایمیل او لږ تر لږه ۱۰ توري پاسورډ ولیکئ.","ایمیل معتبر و رمز عبور حداقل ۱۰ نویسه وارد کنید.","أدخل بريداً إلكترونياً صحيحاً وكلمة مرور من ١٠ أحرف على الأقل.","درست ای میل اور کم از کم ۱۰ حروف کا پاس ورڈ درج کریں۔"],"نوم ولیکئ.":["نوم ولیکئ.","نام را وارد کنید.","أدخل الاسم.","نام درج کریں۔"],"د پیرود مخکې خپل حساب ته ننوځئ.":["د پیرود مخکې خپل حساب ته ننوځئ.","پیش از خرید وارد حساب خود شوید.","سجّل الدخول إلى حسابك قبل الشراء.","خریداری سے پہلے اپنے اکاؤنٹ میں لاگ ان کریں۔"],"لومړی خپل حساب ته ننوځئ.":["لومړی خپل حساب ته ننوځئ.","ابتدا وارد حساب خود شوید.","سجّل الدخول إلى حسابك أولاً.","پہلے اپنے اکاؤنٹ میں لاگ ان کریں۔"],"تایید شوی پیرود نشته؛ کېدای شي تادیه لا انتظار کې وي.":["تایید شوی پیرود نشته؛ کېدای شي تادیه لا انتظار کې وي.","خرید تأییدشده‌ای نیست؛ ممکن است پرداخت هنوز در انتظار باشد.","لا توجد عملية شراء مؤكدة؛ قد تكون الدفعة قيد الانتظار.","تصدیق شدہ خریداری نہیں؛ ممکن ہے ادائیگی ابھی زیرِ انتظار ہو۔"],"ګډون د سرور له خوا تایید شو.":["ګډون د سرور له خوا تایید شو.","اشتراک توسط سرور تأیید شد.","تم تأكيد الاشتراك بواسطة الخادم.","سبسکرپشن سرور سے تصدیق ہو گئی۔"],"د حساب تایید ونه شو؛ بیا ننوځئ.":["د حساب تایید ونه شو؛ بیا ننوځئ.","حساب تأیید نشد؛ دوباره وارد شوید.","تعذر التحقق من الحساب؛ سجّل الدخول مجدداً.","اکاؤنٹ کی تصدیق نہیں ہوئی؛ دوبارہ لاگ ان کریں۔"],"اعلانونه یوازې په Android اپ کې دي.":["اعلانونه یوازې په Android اپ کې دي.","تبلیغات فقط در اپلیکیشن Android هستند.","الإعلانات متاحة في تطبيق Android فقط.","اشتہارات صرف Android ایپ میں ہیں۔"],"اعلانونه اوس شتون نه لري.":["اعلانونه اوس شتون نه لري.","تبلیغات اکنون در دسترس نیستند.","الإعلانات غير متاحة حالياً.","اشتہارات فی الحال دستیاب نہیں۔"],"Which language runs in a browser?":["کومه ژبه په براوزر کې چلېږي؟","کدام زبان در مرورگر اجرا می‌شود؟","ما اللغة التي تعمل في المتصفح؟","براؤزر میں کون سی زبان چلتی ہے؟"],"What does HTML define?":["HTML څه شی تعریفوي؟","HTML چه چیزی را تعریف می‌کند؟","ماذا تحدد HTML؟","HTML کیا متعین کرتا ہے؟"],"Web page structure":["د وېبپاڼې جوړښت","ساختار صفحه وب","بنية صفحة الويب","ویب صفحے کی ساخت"],"Database":["ډیټابېس","پایگاه داده","قاعدة بيانات","ڈیٹابیس"],"Network routing":["د شبکې مسیر ټاکنه","مسیریابی شبکه","توجيه الشبكة","نیٹ ورک روٹنگ"],"Operating system":["عملیاتي سیسټم","سیستم‌عامل","نظام التشغيل","آپریٹنگ سسٹم"],"What is 1 kilometer in meters?":["یو کیلومتر څو متره دی؟","یک کیلومتر چند متر است؟","كم متراً في كيلومتر واحد؟","ایک کلومیٹر میں کتنے میٹر ہوتے ہیں؟"],"Correct!":["سم ځواب!","درست است!","إجابة صحيحة!","درست!"],"Correct answer: ":["سم ځواب: ","پاسخ درست: ","الإجابة الصحيحة: ","درست جواب: "],"Scanned: ":["سکین شو: ","اسکن شد: ","تم المسح: ","اسکین ہوا: "],"Camera error: ":["د کامرې تېروتنه: ","خطای دوربین: ","خطأ الكاميرا: ","کیمرے کی خرابی: "],"One world. Many tools.":["یوه نړۍ، ډېر وسایل.","یک جهان، ابزارهای بسیار.","عالم واحد، أدوات كثيرة.","ایک دنیا، بہت سے ٹولز۔"],"Technology · Learning · Creativity · Productivity":["ټکنالوژي · زده کړه · نوښت · ګټورتیا","فناوری · آموزش · خلاقیت · بهره‌وری","التقنية · التعلم · الإبداع · الإنتاجية","ٹیکنالوجی · سیکھنا · تخلیق · پیداواریت"],"ALL-IN-ONE PLATFORM":["ټول‌په‌یو کې پلیټفارم","پلتفرم همه‌کاره","منصة متكاملة","آل اِن ون پلیٹ فارم"],"Open":["پرانیستل","باز کردن","فتح","کھولیں"],"Generated password":["جوړ شوی پټ نوم","رمز عبور تولیدشده","كلمة المرور المُنشأة","تیار کردہ پاس ورڈ"],"QR · Password · Converter · Code Playground · Quiz":["QR · پټ نوم · بدلوونکی · د کوډ تمرینځای · ازموینه","QR · رمز عبور · مبدل · محیط کدنویسی · آزمون","QR · كلمة المرور · المحوّل · ساحة البرمجة · الاختبار","QR · پاس ورڈ · کنورٹر · کوڈ پلے گراؤنڈ · کوئز"],"نوم":["نوم","نام","الاسم","نام"],"ایمیل":["ایمیل","ایمیل","البريد الإلكتروني","ای میل"],"پټ نوم":["پټ نوم","رمز عبور","كلمة المرور","پاس ورڈ"],"وتل":["وتل","خروج","تسجيل الخروج","لاگ آؤٹ"],"اډمین":["اډمین","مدیر","مدير","ایڈمن"],"کلاوډ حساب چمتو دی":["کلاوډ حساب چمتو دی","حساب ابری آماده است","الحساب السحابي جاهز","کلاؤڈ اکاؤنٹ تیار ہے"],"پیرود یوازې د Google Play له لارې او د سرور تر تایید وروسته فعالېږي.":["پیرود یوازې د Google Play له لارې او د سرور تر تایید وروسته فعالېږي.","خرید فقط از طریق Google Play و پس از تأیید سرور فعال می‌شود.","لا تتفعّل عمليات الشراء إلا عبر Google Play وبعد تأكيد الخادم.","خرید صرف Google Play کے ذریعے اور سرور کی تصدیق کے بعد فعال ہو گی۔"],"ګډون اتومات تمدیدېږي؛ بیه، موده او د لغوه کولو معلومات د Google Play د تایید پر پاڼه ښودل کېږي.":["ګډون اتومات تمدیدېږي؛ بیه، موده او د لغوه کولو معلومات د Google Play د تایید پر پاڼه ښودل کېږي.","اشتراک به‌طور خودکار تمدید می‌شود؛ قیمت، مدت و روش لغو در صفحه تأیید Google Play نمایش داده می‌شود.","يتجدد الاشتراك تلقائياً؛ ويظهر السعر والمدة ومعلومات الإلغاء في صفحة تأكيد Google Play.","سبسکرپشن خودکار طور پر تجدید ہو گی؛ قیمت، مدت اور منسوخی کی معلومات Google Play کی تصدیقی اسکرین پر دکھائی جائیں گی۔"],"د ازموینې APK پیرود نه بشپړوي؛ د Google Play د ازموینې له لارې نصب ته اړتیا ده.":["د ازموینې APK پیرود نه بشپړوي؛ د Google Play د ازموینې له لارې نصب ته اړتیا ده.","نسخه آزمایشی APK خرید را تکمیل نمی‌کند؛ نصب از طریق آزمایش Google Play لازم است.","لا يُكمل ملف APK التجريبي عمليات الشراء؛ يلزم التثبيت عبر اختبار Google Play.","ٹیسٹ APK خریداری مکمل نہیں کرتا؛ Google Play ٹیسٹنگ کے ذریعے انسٹال کرنا ضروری ہے۔"],"د اډمین ایمیل ټاکل شوی؛ اجازه یوازې په سرور کې ورکول کېږي، نه د ایمیل په لیکلو.":["د اډمین ایمیل ټاکل شوی؛ اجازه یوازې په سرور کې ورکول کېږي، نه د ایمیل په لیکلو.","ایمیل مدیر تعیین شده؛ دسترسی فقط در سرور اعطا می‌شود، نه با نوشتن ایمیل.","تم تعيين بريد المدير؛ تُمنح الصلاحية على الخادم فقط، وليس بمجرد كتابة البريد.","ایڈمن ای میل مقرر ہے؛ اجازت صرف سرور پر دی جاتی ہے، صرف ای میل لکھنے سے نہیں۔"],"Request failed":["غوښتنه ناکامه شوه","درخواست ناموفق بود","فشل الطلب","درخواست ناکام ہو گئی"],"admin":["اډمین","مدیر","مدير","ایڈمن"],"user":["کاروونکی","کاربر","مستخدم","صارف"]};
const localeIndex = {ps:0,fa:1,ar:2,ur:3};
function translateText(value) {
 const target=localeIndex[state.lang];
 if(target===undefined) return value;
 const entry=uiTranslations[value];
 return entry ? entry[target] : value;
}
function localizeDom(root=document) {
 const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);
 const nodes=[];
 while(walker.nextNode()) nodes.push(walker.currentNode);
 for(const node of nodes) {
   const raw=node.nodeValue, trimmed=raw.trim();
   if(!trimmed) continue;
   const translated=translateText(trimmed);
   if(translated!==trimmed) node.nodeValue=raw.replace(trimmed,translated);
 }
 root.querySelectorAll?.("[placeholder],[title],[aria-label]").forEach(el=>{
   for(const attr of ["placeholder","title","aria-label"]) {
     const value=el.getAttribute(attr);
     if(value) el.setAttribute(attr,translateText(value));
   }
 });
}

const escapeHTML = s => String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function render(){
 document.documentElement.lang=state.lang; document.documentElement.dir=["ps","fa","ar","ur"].includes(state.lang)?"rtl":"ltr";
 $("#app").innerHTML=`<header><div class="brand"><img class="logo" src="/techhub-logo.png" alt="TechHub logo"><small>One world. Many tools.</small></div><select id="lang"><option value="ps">پښتو</option><option value="fa">دری</option><option value="en">English</option><option value="ar">العربية</option><option value="ur">اردو</option></select></header>
 <main><section class="hero"><span class="eyebrow">ALL-IN-ONE PLATFORM</span><h1>${t("welcome")}</h1><p>Technology · Learning · Creativity · Productivity</p><input id="search" placeholder="${t("search")}"></section>
 <nav>${["home","tools","quiz","code","premium","account",...(["admin","super_admin"].includes(state.user?.role)?["admin"]:[])].map(x=>`<button data-tab="${x}" class="${state.tab===x?"active":""}">${t(x)}</button>`).join("")}</nav>
 <section id="view">${view()}</section></main><footer>TechHub · Version 1.1 · ${configured?"Cloud account ready":"د سرور نښلول پاتې دي"} <button id="privacy">د اعلانونو محرمیت</button><p id="globalstatus" role="status"></p></footer>`;
 localizeDom();
 $("#lang").value=state.lang; $("#lang").onchange=e=>{state.lang=e.target.value;localStorage.lang=state.lang;render()};
 document.querySelectorAll("[data-tab]").forEach(b=>b.onclick=()=>go(b.dataset.tab));
 $("#search").oninput=e=>{const q=e.target.value.toLowerCase();document.querySelectorAll(".tool-card").forEach(c=>c.hidden=!c.textContent.toLowerCase().includes(q))};
 wire();
}
function view(){
 if(state.tab==="home")return `<div class="grid"><article class="panel"><h2>Explore TechHub</h2><p>Tools, learning, coding and useful utilities in one place.</p><button class="primary" data-go="tools">Explore tools</button></article><article class="panel"><h2>Quick access</h2><p>QR · Password · Converter · Code Playground · Quiz</p></article></div><h2>Popular tools</h2>${toolCards()}`;
 if(state.tab==="tools")return `<h2>Tools Library</h2>${toolCards()}<div class="panel"><h3>QR Code Generator</h3><input id="qrtext" placeholder="Enter text or URL"><button class="primary" id="makeqr">${t("generate")}</button><div id="qrout"></div><h3>QR Scanner</h3><button id="scanstart">Start camera scan</button><button id="scanstop">Stop</button><div id="reader"></div><p id="scanresult"></p></div><div class="panel"><h3>Unit Converter</h3><input id="convnum" type="number" value="1"><select id="convtype"><option value="kmmi">Kilometers → Miles</option><option value="mft">Meters → Feet</option><option value="kglb">Kilograms → Pounds</option><option value="cmIn">Centimeters → Inches</option><option value="cF">Celsius → Fahrenheit</option></select><button id="convert" class="primary">Convert</button><p id="convout"></p></div>`;
 if(state.tab==="quiz")return `<div class="panel"><h2>Knowledge Quiz</h2><p id="question"></p><div id="answers"></div><p id="quizresult"></p><button id="nextq" class="primary">Next question</button></div>`;
 if(state.tab==="code")return `<div class="panel"><h2>HTML / CSS / JS Playground</h2><textarea id="codeinput" rows="12" spellcheck="false"><h1>Hello TechHub!</h1><p>Edit this HTML and run it.</p></textarea><button id="runCode" class="primary">Run code</button><iframe id="preview" sandbox="allow-scripts"></iframe></div>`;
 if(state.tab==="premium")return premiumView();
 if(state.tab==="account")return accountView();
 if(state.tab==="admin")return adminView();
}
function toolCards(){return `<div class="grid">${[["Password Generator","Create a strong random password"],["QR Generator & Scanner","Create and scan QR codes"],["Unit Converter","Convert common measurements"],["Code Playground","Write and run simple HTML"],["Knowledge Quiz","Test your knowledge"],["Language Support","Pashto, Dari, English, Arabic, Urdu"]].map(x=>`<article class="panel tool-card"><h3>${x[0]}</h3><p>${x[1]}</p><button data-tool="${x[0]}">Open</button></article>`).join("")}<article class="panel tool-card"><h3>Password Generator</h3><label>Length <input id="pwlen" type="number" min="8" max="64" value="18"></label><button id="makepw" class="primary">${t("generate")}</button><input id="pwout" readonly placeholder="Generated password"><button id="copypw">${t("copy")}</button></article></div>`}
const quiz=[["Which language runs in a browser?","JavaScript",["Python","JavaScript","C","Rust"]],["What does HTML define?","Web page structure",["Database","Web page structure","Network routing","Operating system"]],["What is 1 kilometer in meters?","1000",["10","100","1000","10000"]]];
let qi=0;
function wire(){
 document.querySelectorAll("[data-go]").forEach(b=>b.onclick=()=>{state.tab=b.dataset.go;render()});
 document.querySelectorAll("[data-tool]").forEach(b=>b.onclick=()=>{if(b.dataset.tool.startsWith("Password"))$("#pwlen")?.focus();else if(b.dataset.tool.startsWith("QR"))$("#qrtext")?.focus();else if(b.dataset.tool.startsWith("Unit"))$("#convnum")?.focus();else if(b.dataset.tool.startsWith("Code")){state.tab="code";render()}else if(b.dataset.tool.startsWith("Knowledge")){state.tab="quiz";render() }});
 $("#makepw")?.addEventListener("click",()=>{let n=Math.max(8,Math.min(64,+$("#pwlen").value||18));let a="ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%&*";let out="";for(let i=0;i<n;i++)out+=randomCharacter(a);$("#pwout").value=out});
 $("#copypw")?.addEventListener("click",()=>navigator.clipboard?.writeText($("#pwout").value));
 $("#adminSearchBtn")?.addEventListener("click",e=>guard(e.target,async()=>{
  const q=$("#adminSearch")?.value.trim()||"";
  const result=await api("/api/admin/users?limit=50"+(q?"&q="+encodeURIComponent(q):""));
  state.adminUsers=result.users||[];render();
 }));
 document.querySelectorAll("[data-user-status]").forEach(b=>b.addEventListener("click",e=>guard(e.target,async()=>{
  await api("/api/admin/user-update",{userId:b.dataset.userStatus,status:b.dataset.next});
  await loadAdminUsers();render();status("د کاروونکي حالت بدل شو.");
 })));
 document.querySelectorAll("[data-user-role]").forEach(b=>b.addEventListener("click",e=>guard(e.target,async()=>{
  await api("/api/admin/user-update",{userId:b.dataset.userRole,role:b.dataset.next});
  await loadAdminUsers();render();status("د کاروونکي رول بدل شو.");
 })));

 $("#makeqr")?.addEventListener("click",async()=>{let out=$("#qrout");out.innerHTML="";if(!$("#qrtext").value.trim())return;let c=document.createElement("canvas");out.append(c);await QRCode.toCanvas(c,$("#qrtext").value,{width:220});});
 $("#scanstart")?.addEventListener("click",async()=>{try{state.scanner=new Html5Qrcode("reader");await state.scanner.start({facingMode:"environment"},{fps:10,qrbox:230},txt=>{$("#scanresult").textContent=translateText("Scanned: ")+txt;state.scanner?.stop()});}catch(e){$("#scanresult").textContent=translateText("Camera error: ")+e.message}});
 $("#scanstop")?.addEventListener("click",()=>state.scanner?.stop().catch(()=>{}));
 $("#convert")?.addEventListener("click",()=>{let n=+$("#convnum").value, f={kmmi:n=>n*.621371,mft:n=>n*3.28084, kglb:n=>n*2.20462,cmIn:n=>n/2.54,cF:n=>n*9/5+32};$("#convout").textContent=f[$("#convtype").value](n).toFixed(3)});
 $("#runCode")?.addEventListener("click",()=>$("#preview").srcdoc=$("#codeinput").value);
 $("#nextq")?.addEventListener("click",()=>{qi=(qi+1)%quiz.length;showQuestion()}); if($("#question"))showQuestion();
 wireAccounts();
}
function showQuestion(){if(!$("#question"))return;$("#quizresult").textContent="";let q=quiz[qi];$("#question").textContent=translateText(q[0]);$("#answers").innerHTML=q[2].map(a=>`<button class="answer">${escapeHTML(translateText(a))}</button>`).join("");document.querySelectorAll(".answer").forEach(b=>b.onclick=()=>{$("#quizresult").textContent=b.textContent===translateText(q[1])?translateText("Correct!"):translateText("Correct answer: ")+translateText(q[1]);document.querySelectorAll(".answer").forEach(x=>x.disabled=true)})}
localStorage.removeItem('user');localStorage.removeItem('premium');
render();
initialize();

function randomCharacter(alphabet){
 const max=256-(256%alphabet.length);let value;const bytes=new Uint8Array(1);
 do{crypto.getRandomValues(bytes);value=bytes[0]}while(value>=max);
 return alphabet[value%alphabet.length];
}
async function go(tab){
 if(state.scanner){await state.scanner.stop().catch(()=>{});state.scanner=null}
 state.tab=tab;render();
 if(tab==='premium'&&native){try{state.products=(await Billing.getProducts()).products||[];if(state.tab===tab)render()}catch(e){status(e.message)}}
 if(tab==='admin'&&['admin','super_admin'].includes(state.user?.role)){try{state.admin=await api('/api/admin/overview');await loadAdminUsers();if(state.tab===tab)render()}catch(e){status(e.message)}}
}
function status(message){const el=$('#globalstatus');if(el)el.textContent=message||''}
function premiumView(){
 return '<div class="notice">'+(configured?'پیرود یوازې د Google Play له لارې او د سرور تر تایید وروسته فعالېږي.':'د تادیاتو سرور او Google Play محصولات لا نه دي نښلول شوي؛ اوس هېڅ پیسې نه اخیستل کېږي.')+'</div><div class="grid"><article class="panel"><h2>Free</h2><p>وړیا وسایل او زده کړه</p><b>$0</b></article>'+plans.map(plan=>{
 const product=state.products.find(p=>p.id===plan.id);
 return '<article class="panel"><h2>'+plan.name+'</h2><p>'+escapeHTML(product?.price||'بیه له Google Play څخه اخیستل کېږي')+'</p><p>له تایید وروسته بې‌اعلانه تجربه؛ اوسني وسایل ټولو ته وړیا دي.</p><button class="primary" data-buy="'+plan.id+'" '+(!configured||!native?'disabled':'')+'>د Google Play له لارې ګډون</button></article>';
 }).join('')+'</div><div class="panel"><p>اوسنی پلان: '+escapeHTML(state.subscription?.plan||'Free')+'</p><p>ګډون اتومات تمدیدېږي؛ بیه، موده او د لغوه کولو معلومات د Google Play د تایید پر پاڼه ښودل کېږي.</p><button id="restore" '+(!configured||!native?'disabled':'')+'>پخوانی ګډون بېرته راوړل</button><a href="https://play.google.com/store/account/subscriptions" target="_blank" rel="noopener noreferrer">د ګډون اداره / لغوه کول</a><p>د ازموینې APK پیرود نه بشپړوي؛ د Google Play د ازموینې له لارې نصب ته اړتیا ده.</p></div>';
}
function accountView(){
 if(state.user)return '<div class="panel"><h2>حساب</h2><p>'+escapeHTML(state.user.name)+' · '+escapeHTML(state.user.email)+'</p><p>رول: '+escapeHTML(state.user.role)+'</p><button id="logout">وتل</button></div>';
 return '<div class="panel"><h2>خوندي ننوتل / نوی حساب</h2>'+(!configured?'<p class="notice">سرور لا نه دی خپور شوی. اډمین او د کاروونکو ننوتل تر نښلولو پورې غیر فعال دي.</p>':'')+'<label>نوم<input id="username" autocomplete="name" maxlength="100"></label><label>ایمیل<input id="useremail" type="email" autocomplete="username" value="essa.mohammad.shahin@gmail.com"></label><label>پټ نوم<input id="userpass" type="password" autocomplete="current-password" minlength="10" maxlength="128"></label><button class="primary" id="signin" '+(!configured?'disabled':'')+'>ننوتل</button><button id="signup" '+(!configured?'disabled':'')+'>نوی حساب</button><p>د اډمین ایمیل ټاکل شوی؛ اجازه یوازې په سرور کې ورکول کېږي، نه د ایمیل په لیکلو.</p></div>';
}
async function loadAdminUsers(q=""){
 const result=await api("/api/admin/users?limit=50"+(q?"&q="+encodeURIComponent(q):""));
 state.adminUsers=result.users||[];
}
function adminView(){
 if(!['admin','super_admin'].includes(state.user?.role))return '<div class="panel">اډمین ته خوندي ننوتل اړین دي.</div>';
 const d=state.admin;if(!d)return '<div class="panel">د اډمین معلومات راوړل کېږي…</div>';
 const canManage=state.user?.role==='super_admin';
 const rows=(state.adminUsers||[]).map(u=>{
  const self=u.id===state.user?.id, protectedUser=u.role==='super_admin';
  const controls=canManage&&!self&&!protectedUser
   ? '<button data-user-status="'+escapeHTML(u.id)+'" data-next="'+(u.status==='suspended'?'active':'suspended')+'">'+(u.status==='suspended'?'فعالول':'ځنډول')+'</button> <button data-user-role="'+escapeHTML(u.id)+'" data-next="'+(u.role==='admin'?'user':'admin')+'">'+(u.role==='admin'?'عادي کاروونکی':'اډمین کول')+'</button>'
   : '<small>یوازې لوستل</small>';
  return '<div class="admin-user"><div><b>'+escapeHTML(u.name)+'</b><p>'+escapeHTML(u.email)+'</p><small>'+escapeHTML(u.role)+' · '+escapeHTML(u.status||'active')+'</small></div><div>'+controls+'</div></div>';
 }).join('');
 return '<div class="panel"><h2>اډمین</h2><div class="stats"><div><b>'+Number(d.users)+'</b><span>کاروونکي</span></div><div><b>'+Number(d.premiumUsers)+'</b><span>فعال ګډونونه</span></div><div><b>'+Number(d.verifiedPayments)+'</b><span>تایید شوي پیرودونه</span></div></div><h3>د کاروونکو مدیریت</h3><div class="admin-search"><input id="adminSearch" placeholder="د نوم یا ایمیل له مخې لټون"><button id="adminSearchBtn">لټون</button></div>'+(canManage?'<p class="notice">Super Admin: د عادي کاروونکو رول او حساب حالت بدلولی شې.</p>':'<p class="notice">د کاروونکو د بدلون اجازه یوازې Super Admin لري.</p>')+(rows||'<p>کاروونکي ونه موندل شول.</p>')+'</div>';
}
function updateAccount(data){
 state.user=data.user;state.subscription=data.subscription;state.premium=!!data.subscription;state.admin=null;
 adPremium(state.premium);
}
async function guard(button,fn){button.disabled=true;try{await fn()}catch(e){status(e.message||'Request failed')}finally{if(button.isConnected)button.disabled=false}}
function wireAccounts(){
 for(const action of ['signin','signup'])$('#'+action)?.addEventListener('click',e=>guard(e.target,async()=>{
  const email=$('#useremail').value.trim(),password=$('#userpass').value,name=$('#username').value.trim();
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||password.length<10)throw new Error('سم ایمیل او لږ تر لږه ۱۰ توري پاسورډ ولیکئ.');
  if(action==='signup'&&!name)throw new Error('نوم ولیکئ.');
  const data=await api(action==='signup'?'/api/register':'/api/login',{email,password,...(action==='signup'?{name}:{})});
  saveSession(data);updateAccount(data);render();
 }));
 $('#logout')?.addEventListener('click',e=>guard(e.target,async()=>{await api('/api/logout',{});clearSession();updateAccount({user:null,subscription:null});render()}));
 document.querySelectorAll('[data-buy]').forEach(b=>b.onclick=()=>guard(b,async()=>{
  if(!state.user)throw new Error('د پیرود مخکې خپل حساب ته ننوځئ.');
  const result=await Billing.purchase({productId:b.dataset.buy,accountId:state.user.id});await verifyPurchases(result);
 }));
 $('#restore')?.addEventListener('click',e=>guard(e.target,async()=>{if(!state.user)throw new Error('لومړی خپل حساب ته ننوځئ.');await verifyPurchases(await Billing.restore())}));
 $('#privacy')?.addEventListener('click',e=>guard(e.target,async()=>{
  if(native){const r=await Ads.privacyOptions();status(r.status||'د محرمیت تنظیمات وکتل شول.')}else status('اعلانونه یوازې په Android اپ کې دي.');
 }));
}
async function verifyPurchases(result){
 const purchases=(result.purchases||[]).filter(p=>p.state===1);
 if(!purchases.length)throw new Error('تایید شوی پیرود نشته؛ کېدای شي تادیه لا انتظار کې وي.');
 for(const p of purchases)await api('/api/billing/verify',{purchaseToken:p.purchaseToken,productId:p.productId});
 updateAccount(await api('/api/me'));render();status('ګډون د سرور له خوا تایید شو.');
}
async function initialize(){
 if(configured&&sessionStorage.getItem('techhub_token')){
  try{updateAccount(await api('/api/me'));render()}catch{clearSession();status('د حساب تایید ونه شو؛ بیا ننوځئ.')}
 }
 if(native){try{const r=await Ads.initialize({premium:state.premium});if(r.status)status(r.status)}catch{status('اعلانونه اوس شتون نه لري.')}}
}
