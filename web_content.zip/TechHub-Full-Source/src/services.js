import { Capacitor, registerPlugin } from '@capacitor/core';

const base = (import.meta.env.VITE_API_BASE_URL || '').replace(/\/$/, '');
export const configured = /^https:\/\//.test(base) && !base.includes('your-techhub-api');
export const native = Capacitor.isNativePlatform();
export const Billing = registerPlugin('TechHubBilling');
export const Ads = registerPlugin('TechHubAds');
export const plans = [
  {id:'techhub_pro_monthly',name:'Pro'},
  {id:'techhub_business_monthly',name:'Business'}
];
export async function api(path, body) {
  if (!configured) throw new Error('سرور لا نه دی نښلول شوی. د حساب او تادیاتو لپاره باید سرور خپور او د اپ پته تنظیم شي.');
  const token = sessionStorage.getItem('techhub_token');
  const response = await fetch(base + path, {
    method:body === undefined ? 'GET' : 'POST',
    headers:{'Content-Type':'application/json',...(token ? {Authorization:'Bearer '+token}: {})},
    ...(body === undefined ? {} : {body:JSON.stringify(body)}),
    signal:AbortSignal.timeout(20000)
  });
  const result = await response.json().catch(()=>({error:'Server response unavailable'}));
  if (!response.ok) throw new Error(typeof result.error === 'string' ? result.error : result.error?.message || 'Request failed');
  return result;
}
export function saveSession(data) {
  if (data.token) sessionStorage.setItem('techhub_token',data.token);
}
export function clearSession(){ sessionStorage.removeItem('techhub_token'); }
export async function adPremium(premium) {
  if(native) await Ads.setPremium({premium}).catch(()=>{});
}
