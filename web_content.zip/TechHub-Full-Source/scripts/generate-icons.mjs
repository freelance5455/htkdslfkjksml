import { mkdir, copyFile, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const res = path.join(root, 'android/app/src/main/res');
const source = path.join(root, 'resources/icon.png');
// Android can scale a large square PNG for each density. Copying avoids relying on
// ImageMagick, which is not guaranteed to exist in hosted builders.
for (const density of ['mdpi','hdpi','xhdpi','xxhdpi','xxxhdpi']) {
  const folder = path.join(res, `mipmap-${density}`);
  await mkdir(folder, { recursive: true });
  for (const name of ['ic_launcher','ic_launcher_round','ic_launcher_foreground']) {
    await copyFile(source, path.join(folder, `${name}.png`));
  }
}
const anydpi = path.join(res, 'mipmap-anydpi-v26');
await mkdir(anydpi, { recursive: true });
for (const name of ['ic_launcher','ic_launcher_round']) {
  await writeFile(path.join(anydpi, `${name}.xml`), `<?xml version="1.0" encoding="utf-8"?><adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android"><background android:drawable="@color/techhub_icon_background"/><foreground android:drawable="@mipmap/ic_launcher_foreground"/></adaptive-icon>`);
}
const values = path.join(res, 'values');
await mkdir(values, { recursive: true });
await writeFile(path.join(values, 'techhub-colors.xml'), '<?xml version="1.0" encoding="utf-8"?><resources><color name="techhub_icon_background">#020E2C</color></resources>');
console.log('TechHub launcher and adaptive icons generated.');
