import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

// Run after cap add/sync. Repeatable; never edits generated signing secrets.
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const android = path.join(root, 'android');
const read = p => readFile(path.join(android, p), 'utf8');
const write = (p, text) => writeFile(path.join(android, p), text);
const packageName = JSON.parse(await readFile(path.join(root, 'capacitor.config.json'), 'utf8')).appId;
if (!/^[a-zA-Z_]\w*(\.[a-zA-Z_]\w*)+$/.test(packageName)) throw new Error('Invalid Android appId');
const javaDir = path.join(android, 'app/src/main/java', ...packageName.split('.'));
await mkdir(javaDir, { recursive: true });
for (const filename of ['TechHubBillingPlugin.java', 'TechHubAdsPlugin.java']) {
  const source = await readFile(path.join(root, 'native', filename), 'utf8');
  await writeFile(path.join(javaDir, filename), source.replace('package com.techhub.app;', `package ${packageName};`));
}
const mainPath = `app/src/main/java/${packageName.replaceAll('.', '/')}/MainActivity.java`;
let main = await read(mainPath);
if (!main.includes('registerPlugin(TechHubBillingPlugin.class)')) {
  if (/void\s+onCreate\s*\(/.test(main)) {
    if (!main.includes('super.onCreate(')) throw new Error('Cannot locate MainActivity super.onCreate');
    main = main.replace(/super\.onCreate\(/, 'registerPlugin(TechHubBillingPlugin.class);\n        registerPlugin(TechHubAdsPlugin.class);\n        super.onCreate(');
  } else {
    const end = main.lastIndexOf('}');
    main = main.slice(0, end) + `\n    @Override\n    public void onCreate(android.os.Bundle savedInstanceState) {\n        registerPlugin(TechHubBillingPlugin.class);\n        registerPlugin(TechHubAdsPlugin.class);\n        super.onCreate(savedInstanceState);\n    }\n` + main.slice(end);
  }
  await write(mainPath, main);
}
const begin = '// BEGIN TECHHUB NATIVE';
const end = '// END TECHHUB NATIVE';
let gradle = await read('app/build.gradle');
gradle = gradle.replace(/\n?\/\/ BEGIN TECHHUB NATIVE[\s\S]*?\/\/ END TECHHUB NATIVE\n?/g, '\n');
gradle += `\n${begin}
def techhubAppId = providers.gradleProperty('TECHHUB_ADMOB_APP_ID').getOrElse('').trim()
def techhubBannerId = providers.gradleProperty('TECHHUB_ADMOB_BANNER_ID').getOrElse('').trim()
def techhubIdsPresent = !techhubAppId.isEmpty() && !techhubBannerId.isEmpty()
def techhubProductionAds = techhubAppId.matches('ca-app-pub-[0-9]{16}~[0-9]{10}') && techhubBannerId.matches('ca-app-pub-[0-9]{16}/[0-9]{10}') && !techhubAppId.startsWith('ca-app-pub-3940256099942544') && !techhubBannerId.startsWith('ca-app-pub-3940256099942544')
if (techhubIdsPresent && !techhubProductionAds) throw new GradleException('Use valid non-test TECHHUB_ADMOB_APP_ID and TECHHUB_ADMOB_BANNER_ID, or leave both unset.')
if (techhubAppId.isEmpty() != techhubBannerId.isEmpty()) throw new GradleException('Set both TECHHUB_ADMOB_APP_ID and TECHHUB_ADMOB_BANNER_ID, or neither.')
android {
    compileSdk 35
    buildFeatures { buildConfig true }
    defaultConfig { targetSdkVersion 35; versionCode 2; versionName '1.1.0' }
    compileOptions { sourceCompatibility JavaVersion.VERSION_21; targetCompatibility JavaVersion.VERSION_21 }
    buildTypes {
        debug {
            buildConfigField 'boolean', 'TECHHUB_ADS_ENABLED', 'false'
            buildConfigField 'String', 'TECHHUB_ADMOB_BANNER_ID', '\"ca-app-pub-3940256099942544/6300978111\"'
            manifestPlaceholders += [admobAppId: 'ca-app-pub-0000000000000000~0000000000', admobEnabled: 'false']
        }
        release {
            buildConfigField 'boolean', 'TECHHUB_ADS_ENABLED', 'false'
            buildConfigField 'String', 'TECHHUB_ADMOB_BANNER_ID', '\"' + techhubBannerId + '\"'
            manifestPlaceholders += [admobAppId: 'ca-app-pub-0000000000000000~0000000000', admobEnabled: 'false']
        }
    }
}
dependencies {
    implementation 'com.android.billingclient:billing:8.0.0'
    implementation 'com.google.android.gms:play-services-ads:24.5.0'
    implementation 'com.google.android.ump:user-messaging-platform:3.2.0'
}
${end}\n`;
await write('app/build.gradle', gradle);
let manifest = await read('app/src/main/AndroidManifest.xml');
if (!manifest.includes('xmlns:tools=')) manifest = manifest.replace('<manifest ', '<manifest xmlns:tools="http://schemas.android.com/tools" ');
if (!manifest.includes('android.permission.CAMERA')) manifest = manifest.replace('</manifest>', '    <uses-permission android:name="android.permission.CAMERA" />\n    <uses-feature android:name="android.hardware.camera" android:required="false" />\n</manifest>');
manifest = manifest.replace(/\s*<!-- BEGIN TECHHUB ADS -->[\s\S]*?<!-- END TECHHUB ADS -->/g, '');
manifest = manifest.replace('</application>', `    <!-- BEGIN TECHHUB ADS -->
        <meta-data android:name="com.google.android.gms.ads.APPLICATION_ID" android:value="\${admobAppId}" />
        <meta-data android:name="com.google.android.gms.ads.DELAY_APP_MEASUREMENT_INIT" android:value="true" />
        <provider android:name="com.google.android.gms.ads.MobileAdsInitProvider" android:authorities="\${applicationId}.mobileadsinitprovider" android:exported="false" android:enabled="\${admobEnabled}" tools:replace="android:enabled" />
        <!-- END TECHHUB ADS -->
    </application>`);
await write('app/src/main/AndroidManifest.xml', manifest);
console.log('TechHub Billing configured; AdMob remains disabled until explicitly enabled.');
console.log('Icons are intentionally managed separately: generate Android icons from resources/icon.png before release.');

// Generate launcher icons after the Android project exists.
const { execFile } = await import('node:child_process');
const { promisify } = await import('node:util');
await promisify(execFile)(process.execPath, [path.join(root, 'scripts/generate-icons.mjs')]);
