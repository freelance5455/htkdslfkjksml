#!/usr/bin/env node
// Generates a mode-0600 SQL file locally; never sends a password to Wrangler or stdout.
import {pbkdf2Sync, randomBytes, randomUUID} from 'node:crypto';
import {openSync, writeFileSync, closeSync} from 'node:fs';
import {resolve} from 'node:path';

const email = 'essa.mohammad.shahin@gmail.com';
function secret(prompt) {
  if (!process.stdin.isTTY || !process.stdin.setRawMode) throw new Error('An interactive terminal is required; passwords cannot be passed by argument or pipe.');
  return new Promise((resolve, reject) => {
    let input = '';
    const finish = () => { process.stdin.setRawMode(false); process.stdin.pause(); process.stdin.off('data', onData); process.stdout.write('\n'); };
    const onData = chunk => {
      for (const char of chunk.toString('utf8')) {
        if (char === '\u0003' || char === '\u0004') { finish(); reject(new Error('Cancelled.')); return; }
        if (char === '\r' || char === '\n') { finish(); resolve(input); return; }
        if (char === '\u007f' || char === '\b') input = Array.from(input).slice(0,-1).join('');
        else if (char >= ' ' && input.length < 512) input += char;
      }
    };
    // Disable terminal echo BEFORE displaying the prompt, including immediate paste.
    process.stdin.setEncoding('utf8'); process.stdin.setRawMode(true); process.stdin.resume(); process.stdin.on('data', onData);
    process.stdout.write(prompt);
  });
}
// Use UTF-8 hex SQL text literals: no password/name/email can introduce SQL syntax.
const literal = value => `CAST(X'${Buffer.from(String(value), 'utf8').toString('hex')}' AS TEXT)`;
try {
  if (process.argv.length > 3) throw new Error('Usage: node scripts/provision-admin.mjs [output.sql]');
  const password = await secret('New administrator password (hidden): ');
  if (password.length < 10 || Buffer.byteLength(password) > 256) throw new Error('Password must be 10+ characters and at most 256 UTF-8 bytes.');
  if (password !== await secret('Confirm password (hidden): ')) throw new Error('Passwords do not match.');
  const salt = randomBytes(16).toString('hex');
  const hash = `pbkdf2_sha256$100000$${salt}$${pbkdf2Sync(password, salt, 100000, 32, 'sha256').toString('hex')}`;
  const sql = `BEGIN TRANSACTION;\nINSERT INTO users(id,name,email,password_hash,role,status,created_at) VALUES(${literal(randomUUID())},${literal('TechHub Administrator')},${literal(email)},${literal(hash)},'super_admin','active',${Date.now()}) ON CONFLICT(email) DO UPDATE SET password_hash=excluded.password_hash,role='super_admin',status='active';\nDELETE FROM sessions WHERE user_id IN (SELECT id FROM users WHERE email=${literal(email)});\nCOMMIT;\n`;
  const output = resolve(process.argv[2] || 'admin-provision.sql');
  const fd = openSync(output, 'wx', 0o600); try { writeFileSync(fd, sql); } finally { closeSync(fd); }
  console.log(`Created ${output}. Treat this password-hash file as sensitive. Import with:\nnpx wrangler d1 execute techhub-db --remote --file ${JSON.stringify(output)}\nThen securely remove the SQL file. The same script rotates the admin password and revokes prior sessions.`);
} catch (error) { console.error(error.message); process.exitCode = 1; }
