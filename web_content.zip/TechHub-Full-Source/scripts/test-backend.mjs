#!/usr/bin/env node
// Node >=22.13; no packages, credentials, network calls, or persistent DB required.
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync} from 'node:fs';
import {generateKeyPairSync, verify} from 'node:crypto';
import worker from '../worker/index.js';

const sqlite = new DatabaseSync(':memory:');
sqlite.exec(readFileSync(new URL('../worker/schema.sql', import.meta.url), 'utf8'));
function prepared(sql, args = []) {
  return {
    bind: (...values) => prepared(sql, values),
    async first() { return sqlite.prepare(sql).get(...args) || null; },
    async all() { return {results: sqlite.prepare(sql).all(...args)}; },
    async run() { const result = sqlite.prepare(sql).run(...args); return {meta: {changes: Number(result.changes)}}; }
  };
}
const env = {APP_ORIGIN: 'https://app.example.com', ADDITIONAL_APP_ORIGINS: 'https://localhost', DB: {
  prepare: sql => prepared(sql),
  async batch(statements) {
    sqlite.exec('BEGIN');
    try { const results = []; for (const statement of statements) results.push(await statement.run()); sqlite.exec('COMMIT'); return results; }
    catch (error) { sqlite.exec('ROLLBACK'); throw error; }
  }
}};
let checks = 0;
const check = (actual, expected) => { assert.deepEqual(actual, expected); checks++; };
async function request(path, {method = 'GET', data, token, origin = env.APP_ORIGIN, headers = {}} = {}) {
  const req = new Request(`https://api.example.com${path}`, {method, headers: {
    ...(origin ? {origin} : {}), ...(data !== undefined ? {'content-type': 'application/json'} : {}),
    ...(token ? {authorization: `Bearer ${token}`} : {}), ...headers
  }, body: data !== undefined ? JSON.stringify(data) : undefined});
  const response = await worker.fetch(req, env);
  return {status: response.status, headers: response.headers, data: response.status === 204 ? null : await response.json()};
}
const resetLimits = () => sqlite.exec('DELETE FROM auth_rate_limits');
try {
  check((await request('/api/health')).status, 200);
  check((await request('/api/health', {origin: 'https://evil.example'})).status, 403);
  check((await request('/api/health', {origin: 'https://localhost'})).headers.get('access-control-allow-origin'), 'https://localhost');
  check((await request('/api/me', {method: 'OPTIONS'})).status, 204);
  check((await request('/api/me')).status, 401);
  check((await request('/api/register', {method: 'POST', data: {email: 'bad', password: 'long-enough-password', name: 'Bad'}})).status, 400);
  check((await request('/api/register', {method: 'POST', data: {email: 'bad@example.com', password: 'short', name: 'Bad'}})).status, 400);
  const account = {name: ' Alice ', email: ' ALICE@Example.com ', password: 'a good password 123', role: 'admin'};
  const registered = await request('/api/register', {method: 'POST', data: account});
  check(registered.status, 200);
  check(registered.data.user.role, 'user');
  check(registered.data.user.email, 'alice@example.com');
  check(registered.data.user.name, 'Alice');
  check(registered.data.subscription, null);
  const {user, token} = registered.data;
  check(token.length, 64);
  const stored = sqlite.prepare('SELECT password_hash FROM users WHERE id=?').get(user.id).password_hash;
  check(stored.startsWith('pbkdf2_sha256$100000$'), true);
  check(stored.includes(account.password), false);
  check(sqlite.prepare('SELECT token_hash FROM sessions').get().token_hash === token, false);
  check((await request('/api/register', {method: 'POST', data: account})).status, 409);
  check((await request('/api/login', {method: 'POST', data: {...account, password: 'wrong-password'}})).status, 401);
  check((await request('/api/login', {method: 'POST', data: account})).data.user, user);
  check((await request('/api/me', {token})).data, {user, subscription: null});
  check((await request('/api/admin/overview', {token})).status, 403);
  sqlite.prepare("UPDATE users SET role='super_admin' WHERE id=?").run(user.id);
  check((await request('/api/admin/overview', {token})).data.users, 1);
  check((await request('/api/admin/overview', {token})).data.recentUsers[0].email, user.email);
  sqlite.prepare("INSERT INTO users(id,name,email,password_hash,role,status,created_at) VALUES('other-account','Other','other@example.com',?,'user','active',?)").run(stored, Date.now());
  const userList = await request('/api/admin/users?limit=50', {token});
  check(userList.status, 200);
  check(userList.data.users.length, 2);
  check((await request('/api/admin/user-update', {method:'POST', token, data:{userId:'other-account',status:'suspended'}})).status, 200);
  check(sqlite.prepare("SELECT status FROM users WHERE id='other-account'").get().status, 'suspended');
  check((await request('/api/admin/user-update', {method:'POST', token, data:{userId:'other-account',role:'admin'}})).status, 200);
  check(sqlite.prepare("SELECT role FROM users WHERE id='other-account'").get().role, 'admin');
  check((await request('/api/admin/user-update', {method:'POST', token, data:{userId:user.id,role:'user'}})).status, 400);
  check((await request('/api/logout', {method: 'POST', token})).status, 200);
  check((await request('/api/me', {token})).status, 401);
  const login = await request('/api/login', {method: 'POST', data: account});
  const bearer = login.data.token;
  const verifyRequest = data => request('/api/billing/verify', {method: 'POST', data, token: bearer});
  check((await verifyRequest({productId: 'unknown', purchaseToken: 'test-token'})).status, 400);
  check((await verifyRequest({productId: 'techhub_pro_monthly', purchaseToken: 'test-token'})).status, 503);
  check(sqlite.prepare('SELECT COUNT(*) AS n FROM subscriptions').get().n, 0);

  const {privateKey, publicKey} = generateKeyPairSync('rsa', {modulusLength: 2048});
  env.GOOGLE_SERVICE_ACCOUNT_JSON = JSON.stringify({client_email: 'test@example.iam.gserviceaccount.com', private_key: privateKey.export({type: 'pkcs8', format: 'pem'})});
  let oauthCalls = 0, ackCalls = 0, playCalls = 0, mode = 'active';
  let expiry = Date.now() + 3600000;
  const realFetch = globalThis.fetch;
  globalThis.fetch = async (url, options) => {
    if (url === 'https://oauth2.googleapis.com/token') {
      oauthCalls++;
      const params = new URLSearchParams(options.body), jwt = params.get('assertion').split('.');
      check(verify('RSA-SHA256', Buffer.from(`${jwt[0]}.${jwt[1]}`), publicKey, Buffer.from(jwt[2], 'base64url')), true);
      const claim = JSON.parse(Buffer.from(jwt[1], 'base64url'));
      check(claim.scope, 'https://www.googleapis.com/auth/androidpublisher');
      check(claim.aud, 'https://oauth2.googleapis.com/token');
      return Response.json({access_token: 'mock-oauth-token'});
    }
    check(options.headers.authorization, 'Bearer mock-oauth-token');
    check(url.includes('/applications/com.techhub.app/'), true);
    if (url.endsWith(':acknowledge')) {
      ackCalls++; check(options.method, 'POST');
      return mode === 'ack-fail' ? new Response('', {status: 503}) : new Response(null, {status: 204});
    }
    playCalls++;
    check(url.includes('/purchases/subscriptionsv2/tokens/'), true);
    if (mode === 'not-found') return new Response('', {status: 404});
    return Response.json({
      subscriptionState: mode === 'inactive' ? 'SUBSCRIPTION_STATE_ON_HOLD' : mode === 'grace' ? 'SUBSCRIPTION_STATE_IN_GRACE_PERIOD' : 'SUBSCRIPTION_STATE_ACTIVE',
      acknowledgementState: mode === 'acked' ? 'ACKNOWLEDGEMENT_STATE_ACKNOWLEDGED' : 'ACKNOWLEDGEMENT_STATE_PENDING',
      externalAccountIdentifiers: {obfuscatedExternalAccountId: mode === 'mismatch' ? 'someone-else' : user.id},
      lineItems: [{productId: mode === 'wrong-product' ? 'techhub_business_monthly' : 'techhub_pro_monthly', expiryTime: new Date(expiry).toISOString()}]
    });
  };
  try {
    const purchase = {productId: 'techhub_pro_monthly', purchaseToken: 'test-token'};
    for (const [testMode, status] of [['mismatch',403],['wrong-product',422],['not-found',422],['ack-fail',503]]) {
      mode = testMode; check((await verifyRequest(purchase)).status, status);
      check(sqlite.prepare('SELECT COUNT(*) AS n FROM verified_payments').get().n, 0);
    }
    mode = 'active';
    const activated = await verifyRequest(purchase);
    check(activated.status, 200);
    check(activated.data.subscription, {plan: 'pro', expiresAt: expiry});
    check((await verifyRequest(purchase)).status, 200);
    check(sqlite.prepare('SELECT COUNT(*) AS n FROM verified_payments').get().n, 1);
    check((await request('/api/admin/overview', {token: bearer})).data.premiumUsers, 1);
    check((await request('/api/admin/overview', {token: bearer})).data.verifiedPayments, 1);
    const priorAcks = ackCalls; mode = 'acked'; check((await verifyRequest(purchase)).status, 200); check(ackCalls, priorAcks);
    mode = 'grace'; check((await verifyRequest(purchase)).status, 200);
    mode = 'inactive'; check((await verifyRequest(purchase)).status, 422);
    check((await request('/api/me', {token: bearer})).data.subscription, null);
    mode = 'active'; expiry = Date.now() - 1; check((await verifyRequest(purchase)).status, 422);
    expiry = Date.now() + 3600000; check((await verifyRequest(purchase)).status, 200);
    sqlite.prepare('UPDATE subscriptions SET expires_at=?').run(Date.now() - 1);
    check((await request('/api/me', {token: bearer})).data.subscription, null);
    sqlite.prepare("INSERT INTO users(id,name,email,password_hash,role,status,created_at) VALUES('third-account','Third','third@example.com',?,'user','active',?)").run(stored, Date.now());
    sqlite.prepare("UPDATE subscriptions SET user_id='third-account'").run();
    const priorCalls = playCalls;
    check((await verifyRequest(purchase)).status, 409); check(playCalls, priorCalls);
    check(oauthCalls > 0 && ackCalls > 0, true);
  } finally { globalThis.fetch = realFetch; }

  resetLimits();
  for (let i = 0; i < 10; i++) check((await request('/api/login', {method: 'POST', data: {email: 'absent@example.com', password: 'incorrect-password'}})).status, 401);
  check((await request('/api/login', {method: 'POST', data: {email: 'absent@example.com', password: 'incorrect-password'}})).status, 429);
  resetLimits();
  for (let i = 0; i < 5; i++) check((await request('/api/admin/bootstrap', {method: 'POST'})).status, 503);
  check((await request('/api/admin/bootstrap', {method: 'POST'})).status, 429);
  resetLimits();
  check((await request('/api/register', {method: 'POST', data: {large: 'x'.repeat(9000)}})).status, 413);
  sqlite.prepare('UPDATE sessions SET expires_at=?').run(Date.now() - 1);
  check((await request('/api/me', {token: bearer})).status, 401);
  await worker.scheduled(null, env);
  check(sqlite.prepare('SELECT COUNT(*) AS n FROM sessions').get().n, 0);
  check((await worker.fetch(new Request('https://api.example.com/api/me'), {})).status, 503);
  console.log(`PASS: ${checks} assertions. SQLite D1 adapter + mocked Google OAuth/Publisher; no external calls.`);
} finally { sqlite.close(); }
