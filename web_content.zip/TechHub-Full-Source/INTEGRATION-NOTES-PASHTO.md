# د TechHub د نښلولو حالت

## تازه شوي
- نوی TechHub برانډ لوګو د اپ په سرلیک کې شامل شو؛ د Android لانچر icon خوندي پاتې دی.
- د تولید API پته په `.env.production` کې د موجود Cloudflare Worker لپاره تنظیم شوه.
- د `admin` او `super_admin` رولونه پېژندل کېږي.
- اډمین ډشبورډ د عمومي شمېرنو، د کاروونکو لټون، د کاروونکي رول بدلولو او حساب ځنډولو/بېرته فعالولو لپاره له API سره ونښلول شو.
- د Worker فایل د پخوانۍ پروژې له زاړه Starter کوډ څخه د وروستي موجود Worker کوډ ته تازه شو.
- AdMob د Release لپاره بند پاتې دی؛ وروسته د خپلو AdMob IDs په ورکولو سره فعالېدای شي.

## د Cloudflare احتیاط
- په ZIP کې `worker/index.js` د وروستي ترلاسه شوي Worker کوډ دی.
- ستا موجود D1 ډیټابېس 16 جدولونه لري؛ دا Worker د حسابونو او تادیاتو لپاره له پنځو اصلي جدولونو (`users`, `sessions`, `auth_rate_limits`, `subscriptions`, `verified_payments`) څخه کار اخلي.
- **په موجود Live D1 کې `worker/schema.sql` بیا مه اجرا کوه**؛ دا د نوې/ازمایښتي ډیټابېس لپاره د جدولونو جوړولو فایل دی، د موجود ډیټابېس د migration فایل نه دی.
- د Worker Secret `ADMIN_BOOTSTRAP_SECRET` چې د Super Admin د لومړي جوړولو لپاره کارېده، له بریالي Bootstrap وروسته باید له Worker secrets څخه لرې شي.
- د کاروونکو مدیریت API اوس نښلول شوی؛ خو د تنظیماتو، feature flags، app modules، announcements، notifications، support tickets، reports او audit logs لپاره موجود Worker لا endpoints نه لري. د دې برخو بشپړول جلا backend پراختیا غواړي.

## ازموینې او پاتې خپرونه
- Backend: 162 assertions بریالي؛ د Google OAuth/Play غوښتنې mock شوې وې، حقیقي تادیه نه ده ترسره شوې.
- JavaScript syntax او د API/logo نښلونې checks بریالي.
- د دې چاپېریال npm dependency نصب بشپړ نه شو؛ له همدې امله Vite build او UI bundle test نه دي اجرا شوي.
- دا ZIP د APK فایل نه دی. APK باید د Node 22.13+، Java 21 او Android SDK لرونکي Builder کې جوړ او په حقیقي Android موبایل کې وازمویل شي.


## د موجود D1 سره د نوې نسخې مطابقت
- د Worker روغتیا لاره `/api/health` اوس د `DB` binding او د حسابونو د پنځو اړینو جدولونو/کالمونو یوازې لوستونکې ازموینه کوي.
- د ازموینې جدولونه: `users`, `sessions`, `auth_rate_limits`, `subscriptions`, `verified_payments`.
- که جدولونه/کالمونه برابر نه وي، API به `DATABASE_SCHEMA_MISMATCH` وښيي؛ هېڅ جدول نه جوړوي، نه بدلوي او نه حذفوي.
- د Capacitor د Android اصلي origins (`https://localhost` او نور محلي origins) په Worker کې په ډیفالټ اجازه لري، څو د CORS له امله `Failed to fetch` رامنځته نه شي.
- د Live D1 لپاره `worker/schema.sql` مه اجرا کوئ. یوازې د `worker/index.js` نوی کوډ په موجود `techhub-api` Worker کې Deploy کړئ او د موجود `DB` binding هماغسې وساتئ.
