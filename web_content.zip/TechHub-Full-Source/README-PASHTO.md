# TechHub 1.1 — د Android ازمایښتي نسخه

## د ژبو اصلاح — نسخه 1.1.1
- د پښتو، دري، انګلیسي، عربي او اردو ژبو لپاره د اپلیکیشن د ښکاره متنونو ژباړې پراخې شوې.
- د وسایلو کتابتون، QR، واحدونو بدلوونکی، کوډ تمرینځای، پوښتنې، حساب، اډمین او ګډون پاڼې ژبنۍ شوې.
- د پوښتنو ځوابونه، د سکین پایلې او د خطا/حالت پیغامونه هم د ټاکل شوې ژبې له مخې ښودل کېږي.
- د RTL ژبو (پښتو، دري، عربي، اردو) لپاره د متن لوری RTL پاتې کېږي؛ انګلیسي LTR ده.\n\n## څه چمتو شوي؟
- نوی TechHub لوګو، د Android ایکن او موبایل بڼه.
- پخواني وړیا وسایل، QR، کنورټر، کوډ او پوښتنې.
- د قوي تصادفي پاسورډ جوړول؛ پخوانی غیرخوندي تصادفي انتخاب بدل شوی.
- د حسابونو، Super Admin، کاروونکو لټون، د رول بدلولو او حساب ځنډولو لپاره د سرور نښلونې؛ هش شوي پاسورډونه او خوندي سیشنونه.
- Google Play Billing 8، د پیرود بېرته راوړل او د سرور له لارې تایید.
- AdMob او UMP محرمیت؛ Debug کې یوازې د Google ازمایښتي اعلانونه. په حقیقي نسخه کې بې له خپلو IDs اعلانونه بند وي.

## مهم: لا څه نه دي فعال؟
دا APK ازمایښتي او په debug کیلي لاسلیک شوی؛ د Play Store وروستۍ نسخه نه ده. د API پته په `.env.production` کې د موجود Cloudflare Worker لپاره تنظیم شوې؛ خو د موبایل له جوړولو مخکې باید د Worker او D1 ژوندۍ ازموینه وشي. حقیقي پیسې یوازې د Google Play د بشپړ تنظیم او تایید وروسته اخیستل کېږي. په Release نسخه کې AdMob بند دی؛ اوس عایداتي اعلانونه نه ښودل کېږي. په ریښتیني Android موبایل کې د اعلانونو او پیرود پای‌ترپایه ازموینه لا نه ده شوې.

## اډمین
ایمیل: `essa.mohammad.shahin@gmail.com`

پاسورډ په APK، Source یا دې فایل کې نشته. Super Admin د `/api/admin/bootstrap` له لارې جوړېږي. له بریالي جوړېدو وروسته `ADMIN_BOOTSTRAP_SECRET` له Worker secrets څخه لرې کړئ. د پټ نوم یا Token شریکول مه کوئ.

## سرور او تادیات
1. ستا Cloudflare Worker او D1 له مخکې جوړ دي؛ هماغه موجود تنظیمات وساته.
2. په موجود Live D1 کې `worker/schema.sql` بیا مه اجرا کوه. Worker یوازې هغه وخت بیا Deploy کړه چې د ژوندۍ نسخې د بدلون اړتیا او د D1 سازګاري دې تایید کړې وي.
3. د تولید API پته په `.env.production` کې له مخکې تنظیم شوې ده. که Worker URL بدل شي، `VITE_API_BASE_URL` تازه کړئ. پټ معلومات هېڅکله `VITE_*` کې مه ږدئ.
4. Google Play کې د `com.techhub.app` اپ او `techhub_pro_monthly` / `techhub_business_monthly` ګډونونه جوړ کړئ؛ بیې او وړاندیزونه په Play Console کې ټاکل کېږي.
5. د Google خدمت حساب ته اړینې اجازې ورکړئ؛ JSON یوازې د Worker په `GOOGLE_SERVICE_ACCOUNT_JSON` secret کې وساتئ.
6. AdMob اوس مه فعالوئ. د Release اعلانونه تر هغې بند دي چې وروسته خپل App ID او Banner ID په خصوصي Gradle تنظیماتو کې ورکړئ؛ لارښود: `native/README.md`.

## بیا جوړول
Node 22.13+، Java 21، Android SDK 35 او ImageMagick ته اړتیا ده.

```sh
npm ci
npm run test:backend
npm run build
npm run test:ui
npx cap add android
npx cap sync android
npm run android:configure
npm run android:icons
cd android
./gradlew assembleDebug
```

که Android مخکې موجود وي `cap add` بیا مه اجرا کوئ. GitHub Actions هم د Debug APK جوړولو لپاره برابر دی؛ API پته د repository په `VITE_API_BASE_URL` variable کې ورکړئ.

## د عامه خپرولو مخکې
Release signing/AAB، د Play د اوسني هدف Android شرط، د محرمیت تګلاره، Data Safety، د حساب حذف/بېرته ترلاسه کول، ایمیل تایید، د حقیقي وسیلې ازموینې او د پیرودونو RTDN/refund/renewal څارنه باید بشپړه شي. د تادیاتو کوډ د عامه سوداګریز خپرولو بشپړ تصدیق نه دی. تفصیل: `worker/README.md` او `native/README.md`.
