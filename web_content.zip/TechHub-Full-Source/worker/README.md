# TechHub Cloudflare Worker — current source contract

This source matches the currently supplied Worker version with `admin` and `super_admin` roles, user status, Google Play verification, and the existing D1 core tables. It does not implement modules, announcements, settings, support tickets, reports, or notifications endpoints.

## Deployment

- Keep the existing live Worker and D1 configuration. Do not overwrite production settings with placeholders.
- D1 binding name: `DB`.
- Required core tables: `users`, `sessions`, `auth_rate_limits`, `subscriptions`, `verified_payments`.
- The user's existing D1 also contains additional tables; this Worker does not currently use those extra tables.
- Native Capacitor origin is `https://localhost`. Configure exact origins only; never use `*`.
- Set `GOOGLE_SERVICE_ACCOUNT_JSON` using `wrangler secret put GOOGLE_SERVICE_ACCOUNT_JSON`. Never put it in `VITE_*`, source files, or `wrangler.toml`.

## Authentication

- `POST /api/admin/bootstrap` — first `super_admin` only; body `{name,email,password,secret}`. Requires `ADMIN_BOOTSTRAP_SECRET` Worker secret (32+ characters). After successful bootstrap, remove that secret from Worker settings.
- `POST /api/register` — body `{name,email,password}`.
- `POST /api/login` — body `{email,password}`.
- `GET /api/me` — current profile and verified subscription.
- `POST /api/logout` — revoke current session.
- Session tokens are random 256-bit bearer tokens; only SHA-256 hashes are stored. Session lifetime is seven days.
- Passwords use PBKDF2-SHA256, 100,000 iterations. Minimum 10 characters.

## Admin

- `GET /api/admin/overview` — counts for users, premium users and verified purchases, plus recent users.
- `GET /api/admin/users?q=<search>&limit=50&offset=0` — search/list users.
- `POST /api/admin/user-update` — `super_admin` only. Body `{userId,status}` where status is `active` or `suspended`, or `{userId,role}` where role is `user` or `admin`. The super admin cannot change their own account or another super-admin account.
- Suspended users' sessions are revoked.

## Billing

- `POST /api/billing/verify` — authenticated body `{purchaseToken,productId}`.
- Fixed package: `com.techhub.app`.
- Products: `techhub_pro_monthly`, `techhub_business_monthly`.
- Native BillingClient must set `obfuscatedAccountId` to the signed-in user's exact UUID.
- Google Play purchase verification and acknowledgement are server-side. A verified subscription is required for premium entitlement.
- Configure an Android Publisher service account as a Worker secret. Without it, billing fails closed.

## Tests and limits

- `npm run test:backend` runs isolated SQLite tests with mocked Google OAuth/Publisher calls; it does not prove the deployed Worker or Play Console configuration is correct.
- Rate limits apply to authentication, bootstrap and billing.
- No email verification, password reset, MFA, real-time renewal/refund notifications, or background reconciliation is implemented.
- This Worker does not expose admin CRUD for settings, feature flags, app modules, announcements, notifications, support tickets, reports, or audit logs, even though the D1 database has tables with those names.
