const enc = new TextEncoder();
const ITERATIONS = 100000;
const SESSION_MS = 7 * 24 * 60 * 60 * 1000;
const PRODUCTS = {
  techhub_pro_monthly: "pro",
  techhub_business_monthly: "business",
};

class ApiError extends Error {
  constructor(status, code, message) {
    super(message);
    this.status = status;
    this.code = code;
  }
}
const fail = (status, code, message) => { throw new ApiError(status, code, message); };
const hex = (bytes) =>
  Array.from(new Uint8Array(bytes), (b) => b.toString(16).padStart(2, "0")).join("");
const random = (n) => hex(crypto.getRandomValues(new Uint8Array(n)));
const sha = async (value) => hex(await crypto.subtle.digest("SHA-256", enc.encode(value)));
const b64url = (value) =>
  btoa(String.fromCharCode(...value)).replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");

async function passwordHash(password, salt = random(16)) {
  const key = await crypto.subtle.importKey("raw", enc.encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", hash: "SHA-256", salt: enc.encode(salt), iterations: ITERATIONS },
    key,
    256
  );
  return `pbkdf2_sha256$${ITERATIONS}$${salt}$${hex(bits)}`;
}
async function passwordMatches(password, stored) {
  const parts = String(stored || "").split("$");
  if (parts.length !== 4 || parts[0] !== "pbkdf2_sha256" || parts[1] !== String(ITERATIONS)) return false;
  const actual = await passwordHash(password, parts[2]);
  let diff = actual.length ^ stored.length;
  for (let i = 0; i < actual.length; i++) diff |= actual.charCodeAt(i) ^ (stored.charCodeAt(i) || 0);
  return diff === 0;
}
function normalizeEmail(value) {
  if (typeof value !== "string") fail(400, "INVALID_INPUT", "A valid email is required.");
  const result = value.trim().toLowerCase();
  if (result.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(result)) {
    fail(400, "INVALID_INPUT", "A valid email is required.");
  }
  return result;
}
function validatePassword(value) {
  if (typeof value !== "string" || value.length < 10 || enc.encode(value).length > 256) {
    fail(400, "INVALID_INPUT", "Password must be at least 10 characters and at most 256 UTF-8 bytes.");
  }
  return value;
}
async function readJson(req) {
  if (!/^application\/json(?:\s*;|$)/i.test(req.headers.get("content-type") || "")) {
    fail(415, "JSON_REQUIRED", "Use application/json.");
  }
  if (!req.body) fail(400, "INVALID_JSON", "A JSON object is required.");
  const reader = req.body.getReader();
  let size = 0;
  const chunks = [];
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    size += value.length;
    if (size > 8192) {
      await reader.cancel();
      fail(413, "BODY_TOO_LARGE", "Request exceeds 8 KiB.");
    }
    chunks.push(value);
  }
  const bytes = new Uint8Array(size);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.length;
  }
  let data;
  try {
    data = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes));
  } catch {
    fail(400, "INVALID_JSON", "Invalid JSON.");
  }
  if (!data || typeof data !== "object" || Array.isArray(data)) {
    fail(400, "INVALID_JSON", "A JSON object is required.");
  }
  return data;
}
async function rateLimit(env, key, max, windowMs = 900000) {
  const now = Date.now();
  const row = await env.DB.prepare(`
    INSERT INTO auth_rate_limits(bucket_key,hits,resets_at) VALUES(?,1,?)
    ON CONFLICT(bucket_key) DO UPDATE SET
      hits=CASE WHEN resets_at<=? THEN 1 ELSE hits+1 END,
      resets_at=CASE WHEN resets_at<=? THEN excluded.resets_at ELSE resets_at END
    RETURNING hits
  `).bind(await sha(key), now + windowMs, now, now).first();
  if (row.hits > max) fail(429, "RATE_LIMITED", "Too many requests. Try again later.");
}
async function authenticate(req, env) {
  const match = /^Bearer ([a-f0-9]{64})$/.exec(req.headers.get("authorization") || "");
  if (!match) fail(401, "UNAUTHORIZED", "Sign in required.");
  const tokenHash = await sha(match[1]);
  const user = await env.DB.prepare(`
    SELECT u.id,u.name,u.email,u.role,u.status
    FROM sessions s JOIN users u ON u.id=s.user_id
    WHERE s.token_hash=? AND s.expires_at>?
  `).bind(tokenHash, Date.now()).first();
  if (!user || user.status !== "active") fail(401, "UNAUTHORIZED", "Session expired or account unavailable.");
  return { user, tokenHash };
}
async function currentProfile(env, user) {
  const subscription = await env.DB.prepare(`
    SELECT plan,expires_at FROM subscriptions
    WHERE user_id=? AND expires_at>?
      AND state IN ('SUBSCRIPTION_STATE_ACTIVE','SUBSCRIPTION_STATE_IN_GRACE_PERIOD')
    ORDER BY CASE plan WHEN 'business' THEN 2 ELSE 1 END DESC, expires_at DESC LIMIT 1
  `).bind(user.id, Date.now()).first();
  return {
    user: { id: user.id, name: user.name, email: user.email, role: user.role },
    subscription: subscription ? { plan: subscription.plan, expiresAt: subscription.expires_at } : null,
  };
}
async function createSession(env, user) {
  const token = random(32);
  await env.DB.prepare("INSERT INTO sessions(token_hash,user_id,expires_at) VALUES(?,?,?)")
    .bind(await sha(token), user.id, Date.now() + SESSION_MS).run();
  return { ...(await currentProfile(env, user)), token };
}
async function remote(url, options) {
  try {
    return await fetch(url, { ...options, signal: AbortSignal.timeout(15000) });
  } catch {
    fail(503, "BILLING_UNAVAILABLE", "Purchase verification is temporarily unavailable.");
  }
}
async function googleAccessToken(env) {
  try {
    const sa = JSON.parse(env.GOOGLE_SERVICE_ACCOUNT_JSON || "null");
    if (!sa?.client_email || !sa?.private_key) throw new Error("Missing service account");
    const now = Math.floor(Date.now() / 1000);
    const head = b64url(enc.encode(JSON.stringify({ alg: "RS256", typ: "JWT" })));
    const claim = b64url(enc.encode(JSON.stringify({
      iss: sa.client_email,
      scope: "https://www.googleapis.com/auth/androidpublisher",
      aud: "https://oauth2.googleapis.com/token",
      iat: now,
      exp: now + 3600,
    })));
    const pem = sa.private_key.replace(/-----[^-]+-----/g, "").replace(/\s/g, "");
    const key = await crypto.subtle.importKey(
      "pkcs8",
      Uint8Array.from(atob(pem), (c) => c.charCodeAt(0)),
      { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
      false,
      ["sign"]
    );
    const signature = await crypto.subtle.sign("RSASSA-PKCS1-v1_5", key, enc.encode(`${head}.${claim}`));
    const response = await remote("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: { "content-type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
        assertion: `${head}.${claim}.${b64url(new Uint8Array(signature))}`,
      }),
    });
    if (!response.ok) throw new Error("Google token request failed");
    const result = await response.json();
    if (!result.access_token) throw new Error("No access token");
    return result.access_token;
  } catch {
    fail(503, "BILLING_NOT_CONFIGURED", "Google Play verification credentials are missing or unavailable.");
  }
}
async function verifyPurchase(env, user, data) {
  const { purchaseToken, productId } = data;
  if (
    typeof productId !== "string" ||
    !Object.hasOwn(PRODUCTS, productId) ||
    typeof purchaseToken !== "string" ||
    purchaseToken.length < 1 ||
    purchaseToken.length > 4096 ||
    /[\x00-\x20\x7f]/.test(purchaseToken)
  ) {
    fail(400, "INVALID_PURCHASE", "A supported product and purchase token are required.");
  }
  const tokenHash = await sha(purchaseToken);
  const owner = await env.DB.prepare("SELECT user_id FROM subscriptions WHERE token_hash=?")
    .bind(tokenHash).first();
  if (owner && owner.user_id !== user.id) {
    fail(409, "PURCHASE_ALREADY_BOUND", "Purchase is already assigned to another account.");
  }
  const accessToken = await googleAccessToken(env);
  const packageName = env.PLAY_PACKAGE_NAME || "com.techhub.app";
  const root = `https://androidpublisher.googleapis.com/androidpublisher/v3/applications/${encodeURIComponent(packageName)}`;
  const headers = { authorization: `Bearer ${accessToken}` };
  const response = await remote(
    `${root}/purchases/subscriptionsv2/tokens/${encodeURIComponent(purchaseToken)}`,
    { headers }
  );
  if ([400, 404, 410].includes(response.status)) {
    fail(422, "INVALID_PURCHASE", "Google Play could not validate this purchase.");
  }
  if (!response.ok) fail(503, "BILLING_UNAVAILABLE", "Google Play verification is unavailable.");
  let purchase;
  try {
    purchase = await response.json();
  } catch {
    fail(503, "BILLING_UNAVAILABLE", "Invalid Google Play response.");
  }
  if (purchase.externalAccountIdentifiers?.obfuscatedExternalAccountId !== user.id) {
    fail(403, "PURCHASE_ACCOUNT_MISMATCH", "Purchase does not belong to this account.");
  }
  const active = ["SUBSCRIPTION_STATE_ACTIVE", "SUBSCRIPTION_STATE_IN_GRACE_PERIOD"]
    .includes(purchase.subscriptionState);
  const expiries = (Array.isArray(purchase.lineItems) ? purchase.lineItems : [])
    .filter((item) => item.productId === productId)
    .map((item) => Date.parse(item.expiryTime))
    .filter(Number.isFinite);
  const expiresAt = Math.max(0, ...expiries);
  if (!active || expiresAt <= Date.now()) {
    await env.DB.prepare(`
      UPDATE subscriptions SET state=?,expires_at=?,verified_at=?
      WHERE token_hash=? AND user_id=?
    `).bind(
      String(purchase.subscriptionState || "INVALID"),
      Math.min(expiresAt, Date.now()),
      Date.now(),
      tokenHash,
      user.id
    ).run();
    fail(422, "INACTIVE_PURCHASE", "Subscription is not active or has expired.");
  }
  if (purchase.acknowledgementState !== "ACKNOWLEDGEMENT_STATE_ACKNOWLEDGED") {
    const ack = await remote(
      `${root}/purchases/subscriptions/${encodeURIComponent(productId)}/tokens/${encodeURIComponent(purchaseToken)}:acknowledge`,
      {
        method: "POST",
        headers: { ...headers, "content-type": "application/json" },
        body: "{}",
      }
    );
    if (!ack.ok) fail(503, "ACKNOWLEDGEMENT_FAILED", "Purchase acknowledgement failed. Retry verification.");
  }
  const now = Date.now();
  await env.DB.batch([
    env.DB.prepare(`
      INSERT INTO subscriptions(token_hash,user_id,product_id,plan,state,expires_at,verified_at)
      VALUES(?,?,?,?,?,?,?)
      ON CONFLICT(token_hash) DO UPDATE SET
        product_id=excluded.product_id,plan=excluded.plan,state=excluded.state,
        expires_at=excluded.expires_at,verified_at=excluded.verified_at
      WHERE subscriptions.user_id=excluded.user_id
    `).bind(tokenHash, user.id, productId, PRODUCTS[productId], purchase.subscriptionState, expiresAt, now),
    env.DB.prepare(`
      INSERT INTO verified_payments(token_hash,user_id,provider,product_id,verified_at)
      VALUES(?,?,'google_play',?,?)
      ON CONFLICT(token_hash) DO UPDATE SET
        product_id=excluded.product_id,verified_at=excluded.verified_at
      WHERE verified_payments.user_id=excluded.user_id
    `).bind(tokenHash, user.id, productId, now),
  ]);
  return currentProfile(env, user);
}
function requireMethod(req, method) {
  if (req.method !== method) fail(405, "METHOD_NOT_ALLOWED", `Use ${method}.`);
}
function requireAdmin(user) {
  if (!["admin", "super_admin"].includes(user.role)) fail(403, "FORBIDDEN", "Administrator access required.");
}
function requireSuperAdmin(user) {
  if (user.role !== "super_admin") fail(403, "FORBIDDEN", "Super administrator access required.");
}
async function route(req, env, path) {
  if (path === "/api/health") {
    requireMethod(req, "GET");
    if (!env.DB) fail(503, "DATABASE_UNAVAILABLE", "D1 binding DB is not configured.");
    try {
      // Read-only compatibility checks for the existing live D1 database.
      await Promise.all([
        env.DB.prepare("SELECT id,name,email,password_hash,role,status,created_at FROM users LIMIT 0").all(),
        env.DB.prepare("SELECT token_hash,user_id,expires_at FROM sessions LIMIT 0").all(),
        env.DB.prepare("SELECT bucket_key,hits,resets_at FROM auth_rate_limits LIMIT 0").all(),
        env.DB.prepare("SELECT token_hash,user_id,product_id,plan,state,expires_at,verified_at FROM subscriptions LIMIT 0").all(),
        env.DB.prepare("SELECT token_hash,user_id,provider,product_id,verified_at FROM verified_payments LIMIT 0").all(),
      ]);
    } catch {
      fail(503, "DATABASE_SCHEMA_MISMATCH", "D1 is connected, but one or more TechHub account tables or columns do not match this Worker. Existing data was not changed.");
    }
    return { ok: true, service: "TechHub API", status: "online", database: "connected", schema: "compatible" };
  }
  if (!env.DB) fail(503, "DATABASE_UNAVAILABLE", "Database is not configured.");

  if (path === "/api/admin/bootstrap") {
    requireMethod(req, "POST");
    await rateLimit(env, `bootstrap:ip:${req.headers.get("cf-connecting-ip") || "unknown"}`, 5);
    if (!env.ADMIN_BOOTSTRAP_SECRET || env.ADMIN_BOOTSTRAP_SECRET.length < 32) {
      fail(503, "BOOTSTRAP_NOT_CONFIGURED", "Set a strong ADMIN_BOOTSTRAP_SECRET in Worker secrets.");
    }
    const data = await readJson(req);
    if (typeof data.secret !== "string" || data.secret.length < 32 || data.secret !== env.ADMIN_BOOTSTRAP_SECRET) {
      fail(401, "INVALID_BOOTSTRAP_SECRET", "Bootstrap authorization failed.");
    }
    const count = await env.DB.prepare("SELECT COUNT(*) AS total FROM users WHERE role='super_admin'").first();
    if (count.total > 0) fail(409, "BOOTSTRAP_ALREADY_USED", "The first administrator has already been created.");
    const name = typeof data.name === "string" ? data.name.trim() : "";
    if (!name || name.length > 100 || /[\x00-\x1f\x7f]/.test(name)) {
      fail(400, "INVALID_INPUT", "Name must contain 1–100 printable characters.");
    }
    const normalized = normalizeEmail(data.email);
    const pass = validatePassword(data.password);
    const id = crypto.randomUUID();
    const hash = await passwordHash(pass);
    const result = await env.DB.prepare(`
      INSERT INTO users(id,name,email,password_hash,role,status,created_at)
      VALUES(?,?,?,?,'super_admin','active',?)
      ON CONFLICT(email) DO NOTHING
    `).bind(id, name, normalized, hash, Date.now()).run();
    if (!result.meta.changes) fail(409, "EMAIL_UNAVAILABLE", "Email is already registered.");
    return { ok: true, message: "Super administrator created. Remove ADMIN_BOOTSTRAP_SECRET after use." };
  }

  if (path === "/api/register" || path === "/api/login") {
    requireMethod(req, "POST");
    await rateLimit(env, `auth:ip:${req.headers.get("cf-connecting-ip") || "unknown"}`, 30);
    const data = await readJson(req);
    const normalized = normalizeEmail(data.email);
    await rateLimit(env, `auth:email:${normalized}`, 10);
    const pass = validatePassword(data.password);
    if (path === "/api/register") {
      const name = typeof data.name === "string" ? data.name.trim() : "";
      if (!name || name.length > 100 || /[\x00-\x1f\x7f]/.test(name)) {
        fail(400, "INVALID_INPUT", "Name must contain 1–100 printable characters.");
      }
      const user = { id: crypto.randomUUID(), name, email: normalized, role: "user", status: "active" };
      const hash = await passwordHash(pass);
      const result = await env.DB.prepare(`
        INSERT INTO users(id,name,email,password_hash,role,status,created_at)
        VALUES(?,?,?,?,'user','active',?) ON CONFLICT(email) DO NOTHING
      `).bind(user.id, user.name, user.email, hash, Date.now()).run();
      if (!result.meta.changes) fail(409, "EMAIL_UNAVAILABLE", "Email is already registered.");
      return createSession(env, user);
    }
    const row = await env.DB.prepare(`
      SELECT id,name,email,role,status,password_hash FROM users WHERE email=?
    `).bind(normalized).first();
    const dummy = `pbkdf2_sha256$100000$00000000000000000000000000000000$${"0".repeat(64)}`;
    if (!await passwordMatches(pass, row?.password_hash || dummy) || !row || row.status !== "active") {
      fail(401, "INVALID_CREDENTIALS", "Email or password is incorrect.");
    }
    const { password_hash, ...user } = row;
    return createSession(env, user);
  }

  const protectedPaths = [
    "/api/me", "/api/logout", "/api/admin/overview",
    "/api/admin/users", "/api/admin/user-update", "/api/billing/verify",
  ];
  if (!protectedPaths.includes(path)) fail(404, "NOT_FOUND", "Endpoint not found.");
  const { user, tokenHash } = await authenticate(req, env);

  if (path === "/api/me") {
    requireMethod(req, "GET");
    return currentProfile(env, user);
  }
  if (path === "/api/logout") {
    requireMethod(req, "POST");
    await env.DB.prepare("DELETE FROM sessions WHERE token_hash=?").bind(tokenHash).run();
    return { ok: true };
  }
  if (path === "/api/admin/overview") {
    requireMethod(req, "GET");
    requireAdmin(user);
    const [users, premium, payments, recent] = await Promise.all([
      env.DB.prepare("SELECT COUNT(*) AS total FROM users").first(),
      env.DB.prepare(`
        SELECT COUNT(DISTINCT user_id) AS total FROM subscriptions
        WHERE expires_at>? AND state IN ('SUBSCRIPTION_STATE_ACTIVE','SUBSCRIPTION_STATE_IN_GRACE_PERIOD')
      `).bind(Date.now()).first(),
      env.DB.prepare("SELECT COUNT(*) AS total FROM verified_payments").first(),
      env.DB.prepare(`
        SELECT id,name,email,role,status,created_at AS createdAt
        FROM users ORDER BY created_at DESC LIMIT 20
      `).all(),
    ]);
    return {
      users: users.total,
      premiumUsers: premium.total,
      verifiedPayments: payments.total,
      recentUsers: recent.results,
    };
  }
  if (path === "/api/admin/users") {
    requireMethod(req, "GET");
    requireAdmin(user);
    const url = new URL(req.url);
    const search = (url.searchParams.get("q") || "").trim().slice(0, 100);
    const limit = Math.min(100, Math.max(1, Number(url.searchParams.get("limit")) || 50));
    const offset = Math.max(0, Number(url.searchParams.get("offset")) || 0);
    const rows = search
      ? await env.DB.prepare(`
          SELECT id,name,email,role,status,created_at AS createdAt
          FROM users WHERE email LIKE ? OR name LIKE ?
          ORDER BY created_at DESC LIMIT ? OFFSET ?
        `).bind(`%${search}%`, `%${search}%`, limit, offset).all()
      : await env.DB.prepare(`
          SELECT id,name,email,role,status,created_at AS createdAt
          FROM users ORDER BY created_at DESC LIMIT ? OFFSET ?
        `).bind(limit, offset).all();
    return { users: rows.results, limit, offset };
  }
  if (path === "/api/admin/user-update") {
    requireMethod(req, "POST");
    requireSuperAdmin(user);
    const data = await readJson(req);
    if (typeof data.userId !== "string" || data.userId.length > 64) {
      fail(400, "INVALID_INPUT", "A valid userId is required.");
    }
    if (data.userId === user.id) fail(400, "SELF_UPDATE_DENIED", "You cannot change your own administrator account.");
    const target = await env.DB.prepare("SELECT id,role FROM users WHERE id=?").bind(data.userId).first();
    if (!target) fail(404, "USER_NOT_FOUND", "User not found.");
    if (target.role === "super_admin") fail(403, "PROTECTED_ACCOUNT", "The super administrator account is protected.");
    const updates = [];
    if (data.status !== undefined) {
      if (!["active", "suspended"].includes(data.status)) fail(400, "INVALID_INPUT", "Status must be active or suspended.");
      updates.push(env.DB.prepare("UPDATE users SET status=? WHERE id=?").bind(data.status, data.userId));
      if (data.status === "suspended") {
        updates.push(env.DB.prepare("DELETE FROM sessions WHERE user_id=?").bind(data.userId));
      }
    }
    if (data.role !== undefined) {
      if (!["user", "admin"].includes(data.role)) fail(400, "INVALID_INPUT", "Role must be user or admin.");
      updates.push(env.DB.prepare("UPDATE users SET role=? WHERE id=?").bind(data.role, data.userId));
    }
    if (!updates.length) fail(400, "INVALID_INPUT", "No supported changes supplied.");
    await env.DB.batch(updates);
    return { ok: true, userId: data.userId };
  }
  if (path === "/api/billing/verify") {
    requireMethod(req, "POST");
    await rateLimit(env, `billing:${user.id}`, 20);
    return verifyPurchase(env, user, await readJson(req));
  }
  fail(405, "METHOD_NOT_ALLOWED", "Method not allowed.");
}

export default {
  async fetch(req, env) {
    const origin = req.headers.get("origin");
    const configuredOrigins = [env.APP_ORIGIN, ...(env.ADDITIONAL_APP_ORIGINS || "").split(",")]
      .map((s) => (s || "").trim())
      .filter((s) => {
        if (!s || s === "*") return false;
        try { return new URL(s).origin === s; } catch { return false; }
      });
    // Capacitor Android's standard origins, plus local development origins.
    // These defaults keep the native app working even when optional Worker
    // vars have not yet been configured in the Cloudflare dashboard.
    const nativeOrigins = [
      "https://localhost",
      "http://localhost",
      "capacitor://localhost",
      "ionic://localhost",
      "https://127.0.0.1",
      "http://127.0.0.1",
    ];
    const allowed = new Set([...configuredOrigins, ...nativeOrigins]);
    const headers = {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
      "x-content-type-options": "nosniff",
      "referrer-policy": "no-referrer",
      "vary": "Origin",
    };
    if (origin && allowed.has(origin)) {
      headers["access-control-allow-origin"] = origin;
      headers["access-control-allow-headers"] = "Content-Type, Authorization";
      headers["access-control-allow-methods"] = "GET, POST, OPTIONS";
    }
    try {
      if (origin && !allowed.has(origin)) fail(403, "ORIGIN_DENIED", "Origin is not permitted.");
      if (req.method === "OPTIONS") return new Response(null, { status: 204, headers });
      const result = await route(req, env, new URL(req.url).pathname);
      return new Response(JSON.stringify(result), { status: 200, headers });
    } catch (error) {
      const status = error instanceof ApiError ? error.status : 500;
      const payload = {
        error: {
          code: error instanceof ApiError ? error.code : "INTERNAL_ERROR",
          message: error instanceof ApiError ? error.message : "An internal error occurred.",
        },
      };
      if (status === 429) headers["retry-after"] = "900";
      return new Response(JSON.stringify(payload), { status, headers });
    }
  },
  async scheduled(_event, env) {
    if (!env.DB) return;
    await env.DB.batch([
      env.DB.prepare("DELETE FROM sessions WHERE expires_at<=?").bind(Date.now()),
      env.DB.prepare("DELETE FROM auth_rate_limits WHERE resets_at<=?").bind(Date.now()),
    ]);
  },
};
