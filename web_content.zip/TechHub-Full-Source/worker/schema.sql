PRAGMA foreign_keys = ON;

-- Core schema for the current TechHub Worker.
-- The existing live D1 database already contains these tables plus additional tables.
-- Do not re-run this file against the live database as a migration.

CREATE TABLE IF NOT EXISTS users (
 id TEXT PRIMARY KEY,
 name TEXT NOT NULL,
 email TEXT NOT NULL UNIQUE COLLATE NOCASE,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL DEFAULT 'user' CHECK(role IN ('user','admin','super_admin')),
 status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','suspended')),
 created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (
 token_hash TEXT PRIMARY KEY,
 user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 expires_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS sessions_expiry ON sessions(expires_at);
CREATE INDEX IF NOT EXISTS sessions_user ON sessions(user_id);

CREATE TABLE IF NOT EXISTS auth_rate_limits (
 bucket_key TEXT PRIMARY KEY,
 hits INTEGER NOT NULL,
 resets_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS auth_rate_expiry ON auth_rate_limits(resets_at);

CREATE TABLE IF NOT EXISTS subscriptions (
 token_hash TEXT PRIMARY KEY,
 user_id TEXT NOT NULL REFERENCES users(id),
 product_id TEXT NOT NULL,
 plan TEXT NOT NULL CHECK(plan IN ('pro','business')),
 state TEXT NOT NULL,
 expires_at INTEGER NOT NULL,
 verified_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS subscriptions_user ON subscriptions(user_id,expires_at);

CREATE TABLE IF NOT EXISTS verified_payments (
 token_hash TEXT PRIMARY KEY REFERENCES subscriptions(token_hash),
 user_id TEXT NOT NULL REFERENCES users(id),
 provider TEXT NOT NULL CHECK(provider='google_play'),
 product_id TEXT NOT NULL,
 verified_at INTEGER NOT NULL
);
