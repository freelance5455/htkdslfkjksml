# TechHub Android native integrations

Run `node scripts/configure-android.mjs` **after** `npx cap add android` (and again after regeneration). It installs the two Java plugins into the configured appId package, registers them before `super.onCreate`, patches Gradle and the manifest, and can be rerun without duplicate blocks. Requires Capacitor 7, Java 21, compile/target SDK 35. Dependencies: Play Billing **8.0.0**, Mobile Ads **24.5.0**, UMP **3.2.0**. Icon generation is left to the main build workflow; use `resources/icon.png`, including adaptive foreground/background resources.

## JavaScript API

```js
import { registerPlugin } from '@capacitor/core';
const billing = registerPlugin('TechHubBilling');
const ads = registerPlugin('TechHubAds');
const { products } = await billing.getProducts();
// products: [{id, title, price}] — localized recurring price, available Play subscriptions only
const { purchases } = await billing.purchase({
  productId: 'techhub_pro_monthly', // or techhub_business_monthly
  accountId: authenticatedUser.id // UUID, EXACT same string server expects
});
// purchases: [{purchaseToken, productId, state}]
const restored = await billing.restore();
await ads.initialize({premium: true});
await ads.setPremium({premium: false});
await ads.privacyOptions();
```

Billing states use Play integers: **1 purchased**, **2 pending**, **0 unspecified**. Pending never grants premium. Forward purchased tokens and product IDs to an authenticated backend; the backend must independently verify package, product, purchase state, expiry, and `obfuscatedExternalAccountId` against the authenticated UUID, associate the token with a single account, and acknowledge accepted purchases using Google Play Developer API. Native code never grants an entitlement or acknowledges purchases. The account UUID is passed as Play's `obfuscatedAccountId`; never put an email or other personal data there. Tokens are not logged. Restore is evidence recovery, not an entitlement grant; restore on next launch after interruption. No local subscription state is authoritative.

Only one purchase may run at a time. Reject codes include `INVALID_PRODUCT`, `INVALID_ACCOUNT`, `PURCHASE_IN_PROGRESS`, `USER_CANCELLED`, `SERVICE_DISCONNECTED`, `SERVICE_UNAVAILABLE`, `BILLING_UNAVAILABLE`, `ITEM_ALREADY_OWNED`, `ITEM_UNAVAILABLE`, `NETWORK_ERROR`, `ACTIVITY_UNAVAILABLE`, `BILLING_ERROR`. On already-owned/interrupted flow, restore and verify with the backend. Product lists may be empty for an unconfigured Play account. Configure active monthly base plans in Play Console for both exact product IDs, publish to a test track, install through Play, and use license testers. When multiple offers exist the plugin prefers a non-promotional base plan, otherwise the first eligible offer; returned price is the final recurring pricing phase. Plan upgrades/downgrades with replacement/proration are not implemented; manage subscriptions in Play. Pending prepaid plans are not enabled.

## Ads and privacy

Ads are display-only and do not verify subscriptions. Feed `premium` from server-verified entitlement state; default is true (no ads) if omitted. Setting true immediately removes and destroys the banner and restores WebView margin. Setting false updates UMP consent and only requests an ad if `canRequestAds()` is true. Banner overlays the native screen bottom; its loaded height is reserved as WebView bottom margin when the view layout supports margins. Rotation and edge-to-edge insets should be checked on physical devices. Lifecycle pause/resume/destroy is supported.

Debug uses **only** Google's official sample app ID `ca-app-pub-3940256099942544~3347511713` and banner unit `ca-app-pub-3940256099942544/6300978111`, regardless of production properties. Release ads are **disabled by default** (including the Mobile Ads init provider). To enable production ads supply both Gradle properties externally, e.g. in your private `~/.gradle/gradle.properties` or CI `-P` arguments:

```properties
TECHHUB_ADMOB_APP_ID=your-own-app-id
TECHHUB_ADMOB_BANNER_ID=your-own-banner-id
```

These placeholders are documentation, not usable IDs. Partial, malformed, or Google's sample IDs in release properties cause a configuration error. No secrets or production IDs are generated. The disabled-release manifest contains a nonfunctional all-zero placeholder with provider disabled; it is never sent to the SDK.

Configure UMP privacy messages for your app in AdMob Console. Always expose a “Privacy choices” action calling `privacyOptions()`; UMP displays its form when required. No geography/debug consent overrides are enabled. UMP may decide consent isn't required based on jurisdiction. A failed consent update shows no ad. SDK initialization and banners happen only after the UMP gate. Age/child-directed treatment must be adapted before distributing an app aimed at children (the sample assumes not under the age of consent).

All ads methods resolve `{status: string}` unless activity is unavailable. Statuses: `disabled`, `premium`, `consent_in_progress`, `consent_required`, `consent_unavailable`, `initializing`, `loading`, `shown`, `ad_unavailable`, `activity_unavailable`, `not_required`, `privacy_unavailable`. SDK initialization and ad load are asynchronous, so `initializing`/`loading` do not mean an impression has occurred. There are no ad lifecycle JS events. UMP and Mobile Ads errors are deliberately fail-closed rather than bypassing consent. Test privacy withdrawal, network loss, process recreation, pending/cancelled purchases, and real device display/insets before production.
