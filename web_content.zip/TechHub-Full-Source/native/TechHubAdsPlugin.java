package com.techhub.app;

import android.app.Activity;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import com.getcapacitor.*;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.google.android.gms.ads.*;
import com.google.android.ump.*;

@CapacitorPlugin(name = "TechHubAds")
public class TechHubAdsPlugin extends Plugin {
    private boolean premium = true; // Fail closed until JS explicitly initializes ad display.
    private boolean initialized;
    private boolean initializing;
    private boolean requestingConsent;
    private boolean privacyFormShowing;
    private boolean destroyed;
    private AdView banner;
    private ConsentInformation consent;
    private int originalBottomMargin;
    private boolean marginCaptured;
    private String status = "disabled";

    @PluginMethod public void initialize(PluginCall call) {
        run(call, () -> {
            premium = call.getBoolean("premium", true);
            if (!BuildConfig.TECHHUB_ADS_ENABLED) { removeBanner(); resolve(call, "disabled"); return; }
            if (premium) { removeBanner(); resolve(call, "premium"); return; }
            consentAndShow(call);
        });
    }

    @PluginMethod public void setPremium(PluginCall call) {
        run(call, () -> {
            premium = call.getBoolean("premium", true);
            if (premium) { removeBanner(); resolve(call, "premium"); }
            else if (!BuildConfig.TECHHUB_ADS_ENABLED) resolve(call, "disabled");
            else consentAndShow(call);
        });
    }

    private void consentAndShow(PluginCall call) {
        if (requestingConsent) { resolve(call, "consent_in_progress"); return; }
        requestingConsent = true;
        consent = UserMessagingPlatform.getConsentInformation(getContext());
        consent.requestConsentInfoUpdate(getActivity(), new ConsentRequestParameters.Builder()
            .setTagForUnderAgeOfConsent(false).build(), () -> {
                if (destroyed) { requestingConsent = false; call.reject("Activity destroyed", "ACTIVITY_UNAVAILABLE"); return; }
                UserMessagingPlatform.loadAndShowConsentFormIfRequired(getActivity(), error -> {
                    requestingConsent = false;
                    // A failed update/form never bypasses the SDK's canRequestAds gate.
                    if (consent.canRequestAds()) { showBanner(); resolve(call, premium ? "premium" : status); }
                    else { removeBanner(); resolve(call, error == null ? "consent_required" : "consent_unavailable"); }
                });
            }, error -> {
                requestingConsent = false;
                removeBanner(); resolve(call, "consent_unavailable");
            });
    }

    @PluginMethod public void privacyOptions(PluginCall call) {
        run(call, () -> {
            if (!BuildConfig.TECHHUB_ADS_ENABLED) { resolve(call, "disabled"); return; }
            if (consent == null || consent.getPrivacyOptionsRequirementStatus() !=
                ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED) {
                resolve(call, "not_required"); return;
            }
            if (privacyFormShowing) { resolve(call, "consent_in_progress"); return; }
            privacyFormShowing = true;
            removeBanner();
            UserMessagingPlatform.showPrivacyOptionsForm(getActivity(), error -> {
                privacyFormShowing = false;
                if (error != null) { resolve(call, "privacy_unavailable"); return; }
                showBanner(); resolve(call, premium ? "premium" : status);
            });
        });
    }

    private void showBanner() {
        if (destroyed || premium || privacyFormShowing || requestingConsent || !BuildConfig.TECHHUB_ADS_ENABLED || consent == null || !consent.canRequestAds()) {
            status = "consent_required"; return;
        }
        if (!initialized) {
            status = "initializing";
            if (initializing) return;
            initializing = true;
            MobileAds.initialize(getContext(), result -> {
                initialized = true; initializing = false;
                Activity activity = getActivity();
                if (activity != null) activity.runOnUiThread(this::showBanner);
            });
            return;
        }
        if (banner != null) { status = "loading"; return; }
        Activity activity = getActivity();
        if (activity == null || activity.isFinishing()) { status = "activity_unavailable"; return; }
        int pixels = getBridge().getWebView().getWidth();
        if (pixels <= 0) pixels = getContext().getResources().getDisplayMetrics().widthPixels;
        int width = Math.max(1, (int) (pixels / getContext().getResources().getDisplayMetrics().density));
        AdSize size = AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(activity, width);
        banner = new AdView(activity);
        banner.setAdUnitId(BuildConfig.TECHHUB_ADMOB_BANNER_ID);
        banner.setAdSize(size);
        banner.setAdListener(new AdListener() {
            @Override public void onAdLoaded() { status = "shown"; reserveMargin(size.getHeightInPixels(activity)); }
            @Override public void onAdFailedToLoad(LoadAdError error) { status = "ad_unavailable"; reserveMargin(0); }
        });
        FrameLayout root = activity.findViewById(android.R.id.content);
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        root.addView(banner, params);
        status = "loading";
        banner.loadAd(new AdRequest.Builder().build());
    }

    private void reserveMargin(int height) {
        ViewGroup.LayoutParams raw = getBridge().getWebView().getLayoutParams();
        if (raw instanceof ViewGroup.MarginLayoutParams) {
            ViewGroup.MarginLayoutParams params = (ViewGroup.MarginLayoutParams) raw;
            if (!marginCaptured) { originalBottomMargin = params.bottomMargin; marginCaptured = true; }
            params.bottomMargin = originalBottomMargin + height;
            getBridge().getWebView().setLayoutParams(params);
        }
    }
    private void removeBanner() {
        if (banner != null) {
            banner.setAdListener(null);
            if (banner.getParent() instanceof ViewGroup) ((ViewGroup) banner.getParent()).removeView(banner);
            banner.destroy(); banner = null;
        }
        if (marginCaptured) reserveMargin(0);
    }
    private void run(PluginCall call, Runnable action) {
        Activity activity = getActivity();
        if (activity == null || activity.isFinishing()) { call.reject("No active activity", "ACTIVITY_UNAVAILABLE"); return; }
        activity.runOnUiThread(action);
    }
    private void resolve(PluginCall call, String value) {
        JSObject result = new JSObject(); result.put("status", value); call.resolve(result);
    }
    @Override protected void handleOnPause() { if (banner != null) banner.pause(); super.handleOnPause(); }
    @Override protected void handleOnResume() { super.handleOnResume(); if (banner != null) banner.resume(); }
    @Override protected void handleOnDestroy() { destroyed = true; removeBanner(); super.handleOnDestroy(); }
}
