package com.techhub.app;

import android.app.Activity;
import com.android.billingclient.api.*;
import com.getcapacitor.*;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.util.*;

/** Play returns evidence only. Entitlements and acknowledgement belong on the server. */
@CapacitorPlugin(name = "TechHubBilling")
public class TechHubBillingPlugin extends Plugin implements PurchasesUpdatedListener {
    private static final Set<String> IDS = Collections.unmodifiableSet(new HashSet<>(Arrays.asList(
        "techhub_pro_monthly", "techhub_business_monthly")));
    private BillingClient client;
    private boolean connecting;
    private final List<Runnable> waiting = new ArrayList<>();
    private final List<PluginCall> waitingCalls = new ArrayList<>();
    private PluginCall purchaseCall;
    private final Map<String, ProductDetails> products = new HashMap<>();

    @Override public void load() {
        client = BillingClient.newBuilder(getContext()).setListener(this)
            .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
            .enableAutoServiceReconnection().build();
    }

    private void ready(PluginCall call, Runnable operation) {
        getActivity().runOnUiThread(() -> {
            if (client.isReady()) { operation.run(); return; }
            waiting.add(operation); waitingCalls.add(call);
            if (connecting) return;
            connecting = true;
            client.startConnection(new BillingClientStateListener() {
                @Override public void onBillingSetupFinished(BillingResult result) {
                    connecting = false;
                    List<Runnable> tasks = new ArrayList<>(waiting);
                    List<PluginCall> calls = new ArrayList<>(waitingCalls);
                    waiting.clear(); waitingCalls.clear();
                    if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                        for (Runnable task : tasks) task.run();
                    } else for (PluginCall c : calls) fail(c, result);
                }
                @Override public void onBillingServiceDisconnected() {
                    connecting = false;
                    for (PluginCall c : new ArrayList<>(waitingCalls))
                        reject(c, "Billing service disconnected. Please retry.", "SERVICE_DISCONNECTED");
                    waiting.clear(); waitingCalls.clear();
                    if (purchaseCall != null) reject(purchaseCall, "Billing service disconnected. Restore purchases before retrying.", "SERVICE_DISCONNECTED");
                }
            });
        });
    }

    private interface DetailsCallback { void done(List<ProductDetails> details); }
    private void queryDetails(PluginCall call, DetailsCallback callback) {
        List<QueryProductDetailsParams.Product> requested = new ArrayList<>();
        for (String id : IDS) requested.add(QueryProductDetailsParams.Product.newBuilder()
            .setProductId(id).setProductType(BillingClient.ProductType.SUBS).build());
        client.queryProductDetailsAsync(QueryProductDetailsParams.newBuilder().setProductList(requested).build(),
            (result, queryResult) -> {
                if (result.getResponseCode() != BillingClient.BillingResponseCode.OK) { fail(call, result); return; }
                products.clear();
                for (ProductDetails detail : queryResult.getProductDetailsList()) products.put(detail.getProductId(), detail);
                callback.done(queryResult.getProductDetailsList());
            });
    }

    private ProductDetails.SubscriptionOfferDetails offer(ProductDetails product) {
        List<ProductDetails.SubscriptionOfferDetails> offers = product.getSubscriptionOfferDetails();
        if (offers == null || offers.isEmpty()) return null;
        // Prefer the ordinary base plan rather than silently choosing a trial/promotion.
        for (ProductDetails.SubscriptionOfferDetails o : offers) if (o.getOfferId() == null) return o;
        return offers.get(0);
    }

    @PluginMethod public void getProducts(PluginCall call) {
        if (!activityAvailable(call)) return;
        ready(call, () -> queryDetails(call, details -> {
            JSArray items = new JSArray();
            for (ProductDetails detail : details) {
                ProductDetails.SubscriptionOfferDetails selected = offer(detail);
                if (selected == null) continue;
                List<ProductDetails.PricingPhase> phases = selected.getPricingPhases().getPricingPhaseList();
                if (phases.isEmpty()) continue;
                JSObject item = new JSObject();
                item.put("id", detail.getProductId()); item.put("title", detail.getTitle());
                item.put("price", phases.get(phases.size() - 1).getFormattedPrice()); items.put(item);
            }
            JSObject response = new JSObject(); response.put("products", items); call.resolve(response);
        }));
    }

    @PluginMethod public void purchase(PluginCall call) {
        String id = call.getString("productId");
        String account = call.getString("accountId");
        if (!IDS.contains(id)) { call.reject("Unsupported subscription product", "INVALID_PRODUCT"); return; }
        if (account == null || !account.matches("[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}")) {
            call.reject("accountId must be the authenticated user's UUID", "INVALID_ACCOUNT"); return;
        }
        if (!activityAvailable(call)) return;
        getActivity().runOnUiThread(() -> {
            if (purchaseCall != null) { call.reject("Another purchase is in progress", "PURCHASE_IN_PROGRESS"); return; }
            purchaseCall = call;
            ready(call, () -> queryDetails(call, details -> {
                if (purchaseCall != call) return;
                ProductDetails product = null;
                for (ProductDetails candidate : details) if (id.equals(candidate.getProductId())) { product = candidate; break; }
                ProductDetails.SubscriptionOfferDetails selected = product == null ? null : offer(product);
                if (selected == null) { reject(call, "Product is not available for this Play account", "ITEM_UNAVAILABLE"); return; }
                Activity activity = getActivity();
                if (activity == null || activity.isFinishing()) { reject(call, "No active activity", "ACTIVITY_UNAVAILABLE"); return; }
                BillingFlowParams.ProductDetailsParams line = BillingFlowParams.ProductDetailsParams.newBuilder()
                    .setProductDetails(product).setOfferToken(selected.getOfferToken()).build();
                activity.runOnUiThread(() -> {
                    if (purchaseCall != call) return;
                    BillingResult result = client.launchBillingFlow(activity, BillingFlowParams.newBuilder()
                        .setProductDetailsParamsList(Collections.singletonList(line)).setObfuscatedAccountId(account).build());
                    if (result.getResponseCode() != BillingClient.BillingResponseCode.OK) fail(call, result);
                });
            }));
        });
    }

    @PluginMethod public void restore(PluginCall call) {
        if (!activityAvailable(call)) return;
        ready(call, () -> client.queryPurchasesAsync(QueryPurchasesParams.newBuilder()
            .setProductType(BillingClient.ProductType.SUBS).build(), (result, purchases) -> {
                if (result.getResponseCode() != BillingClient.BillingResponseCode.OK) fail(call, result);
                else call.resolve(serialize(purchases));
            }));
    }

    @Override public void onPurchasesUpdated(BillingResult result, List<Purchase> purchases) {
        PluginCall call = purchaseCall;
        if (call == null) return; // Restore recovers results after process/activity recreation.
        if (result.getResponseCode() != BillingClient.BillingResponseCode.OK) { fail(call, result); return; }
        purchaseCall = null;
        call.resolve(serialize(purchases == null ? Collections.emptyList() : purchases));
    }

    private JSObject serialize(List<Purchase> purchases) {
        JSArray items = new JSArray();
        for (Purchase p : purchases) for (String id : p.getProducts()) if (IDS.contains(id)) {
            JSObject item = new JSObject(); item.put("purchaseToken", p.getPurchaseToken());
            item.put("productId", id); item.put("state", p.getPurchaseState()); items.put(item);
        }
        JSObject response = new JSObject(); response.put("purchases", items); return response;
    }
    private boolean activityAvailable(PluginCall call) {
        Activity a = getActivity();
        if (a == null || a.isFinishing()) { reject(call, "No active activity", "ACTIVITY_UNAVAILABLE"); return false; }
        return true;
    }
    private void reject(PluginCall call, String message, String code) {
        if (purchaseCall == call) purchaseCall = null;
        call.reject(message, code);
    }
    private void fail(PluginCall call, BillingResult result) {
        String code;
        switch (result.getResponseCode()) {
            case BillingClient.BillingResponseCode.USER_CANCELED: code = "USER_CANCELLED"; break;
            case BillingClient.BillingResponseCode.SERVICE_DISCONNECTED: code = "SERVICE_DISCONNECTED"; break;
            case BillingClient.BillingResponseCode.SERVICE_UNAVAILABLE: code = "SERVICE_UNAVAILABLE"; break;
            case BillingClient.BillingResponseCode.BILLING_UNAVAILABLE: code = "BILLING_UNAVAILABLE"; break;
            case BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED: code = "ITEM_ALREADY_OWNED"; break;
            case BillingClient.BillingResponseCode.ITEM_UNAVAILABLE: code = "ITEM_UNAVAILABLE"; break;
            case BillingClient.BillingResponseCode.NETWORK_ERROR: code = "NETWORK_ERROR"; break;
            default: code = "BILLING_ERROR";
        }
        reject(call, result.getDebugMessage(), code);
    }
    @Override protected void handleOnDestroy() {
        if (purchaseCall != null) reject(purchaseCall, "Activity destroyed; restore purchases on next launch", "ACTIVITY_UNAVAILABLE");
        for (PluginCall c : new ArrayList<>(waitingCalls)) reject(c, "Activity destroyed", "ACTIVITY_UNAVAILABLE");
        waiting.clear(); waitingCalls.clear();
        if (client != null) client.endConnection();
        super.handleOnDestroy();
    }
}
