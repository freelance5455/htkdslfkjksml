Biznes Hisoblagich - offline ilova
Fayl: index.html (internet kerak emas, tashqi fayllar yoq)
APK qilish: WebIntoApp, Median, AppsGeyser yoki Capacitor/Android Studio WebView ichiga
shu papkani joylang. Boshlangich fayl: index.html
Malumotlar telefonda localStorage'da saqlanadi.
