SUBTAIN SHOOTER - Android Project

Zaroori baat:
Yeh Android Studio/Gradle project source hai, ready-signed APK nahi. Is chat ke environment mein Android SDK/Gradle build aur APK signing available nahi, is liye main APK file banne ka jhoota dawa nahi kar raha.

Project mein:
- app/src/main/assets/index.html : aapka HTML shooting game
- MainActivity.java : Android WebView wrapper
- AndroidManifest.xml : app settings

APK banane ka tareeqa:
1. Is ZIP ko extract karein.
2. Android Studio wale computer par project folder open karein.
3. Android SDK Platform 35 aur JDK 17 install hon.
4. Gradle sync hone dein.
5. Build > Build Bundle(s) / APK(s) > Build APK(s) par click karein.
6. APK app/build/outputs/apk/debug/app-debug.apk mein milegi.

Aap ke paas sirf Android mobile hai: Acode HTML edit kar sakta hai lekin aam tor par Android APK compile/sign nahi karta. Mobile se APK banane ke liye Android-compatible build environment ya trusted cloud build service ki zaroorat hogi. Apni private signing keys kisi unknown website par upload na karein.
