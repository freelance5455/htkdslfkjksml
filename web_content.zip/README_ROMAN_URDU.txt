SKYCRASH ADMIN ANDROID APP - SOURCE PROJECT (APK NAHI)

1. Android Studio mein is extracted folder ko Open karein.
2. Internet connection ke saath Gradle sync hone dein (Android SDK 35, JDK 17).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Generated APK app/build/outputs/apk/debug/app-debug.apk mein hogi.
5. App mein admin Firebase email/password se sign in karein.

IMPORTANT:
- Dashboard index.html local HTTPS asset origin se Firebase Realtime Database ko connect karta hai.
- Firebase Authentication mein email/password provider enabled hona chahiye.
- Admin UID ko original HTML code mein hardcoded check kiya gaya hai; Firebase Realtime Database rules mein bhi proper admin-only authorization lazmi hai. Sirf client-side UID check security nahi.
- Firebase auth agar appassets.androidplatform.net origin ko reject kare, Firebase Console > Authentication > Settings > Authorized domains mein domain add karne ki zarurat ho sakti hai (sirf agar supported/needed ho).
- Deposit/withdraw approve aur UID balance adjust original admin code aur deployed database rules par depend karta hai.
- User ke users/{uid}/balance mein numeric balance aur proper access zaroori hai. Existing deduction error APK se khud fix nahi hoga.
- Is project ko yahan compile, real phone par test ya Firebase live permissions validate nahi kiya gaya.
- Never use public read/write database rules. Do not distribute admin APK publicly.
