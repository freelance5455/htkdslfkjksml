# Still Waters — run on Node.js

1. Install Node.js (v18+): https://nodejs.org
2. In this folder run:  npm start
3. Open http://localhost:3000 in your browser.

On your phone (same Wi-Fi): open http://YOUR-COMPUTER-IP:3000
The app is public/index.html — edit it and refresh the page.
