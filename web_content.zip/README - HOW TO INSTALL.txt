VRIKSHA AI — "JPS Tree" APP PACKAGE
=====================================

This folder turns the Vriksha AI talking-tree website into an app
with your own app name and icon.

WHAT IS INSIDE
  manifest.json   -> app name, icon and display settings
  icon-192.png    -> app icon (small)
  icon-512.png    -> app icon (large)
  index.html      -> launcher that opens the talking tree

HOW TO INSTALL ON A PHONE (Android / Chrome)
  1. Unzip this folder.
  2. Put the folder online for free (drag-and-drop works on
     app.netlify.com/drop or use GitHub Pages).
  3. Open your link in Chrome, then tap the menu (3 dots) and
     choose "Add to Home screen" / "Install app".
  4. Your app appears on the home screen with YOUR app name
     and YOUR icon.

HOW TO INSTALL ON A LAPTOP (Chrome / Edge)
  1. Host the folder as above, or open the website directly.
  2. Click the install icon (screen with arrow) at the right
     end of the address bar, or menu -> Cast, save and share
     -> Install page as app.

OPENING WITHOUT HOSTING
  Double-click index.html. It opens the talking tree from:
  https://vrikshaaipro.lovable.app
  (Needs internet, like any website.)

NOTE: To change where the app opens, edit index.html and
replace the website address with your own published link.
