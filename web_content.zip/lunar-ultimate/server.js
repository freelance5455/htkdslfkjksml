// Optional secure backend for Lunar Insurance ULTRA 3D AI. Node.js 18+.
// Keep all API/email secrets on this server, never in the HTML.
const http = require('node:http');
const PORT = Number(process.env.PORT || 8787);
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || '';
const OPENAI_MODEL = process.env.OPENAI_MODEL || 'gpt-4.1-mini';
const RESEND_API_KEY = process.env.RESEND_API_KEY || '';
const REPORT_TO_EMAIL = process.env.REPORT_TO_EMAIL || '';
const REPORT_FROM_EMAIL = process.env.REPORT_FROM_EMAIL || '';
const WINDOW_MS=60_000, MAX_PER_WINDOW=12, hits=new Map();
function json(res,code,data){res.writeHead(code,{'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff'});res.end(JSON.stringify(data));}
function readBody(req){return new Promise((resolve,reject)=>{let s='';req.on('data',c=>{s+=c;if(s.length>20000){reject(new Error('Request too large'));req.destroy();}});req.on('end',()=>{try{resolve(JSON.parse(s||'{}'));}catch{reject(new Error('Invalid JSON'));}});req.on('error',reject);});}
function limited(req){const ip=(req.headers['x-forwarded-for']||req.socket.remoteAddress||'local').toString().split(',')[0];const now=Date.now(),a=(hits.get(ip)||[]).filter(t=>now-t<WINDOW_MS);if(a.length>=MAX_PER_WINDOW)return true;a.push(now);hits.set(ip,a);return false;}
async function aiAnswer(question,errors=[]){
 if(!OPENAI_API_KEY)return 'ИИ-сервер запущен, но OPENAI_API_KEY не настроен.';
 const safeErrors=Array.isArray(errors)?errors.slice(-5).map(x=>({message:String(x.message||'').slice(0,300),time:String(x.time||'').slice(0,40)})):[];
 const resp=await fetch('https://api.openai.com/v1/responses',{method:'POST',headers:{authorization:'Bearer '+OPENAI_API_KEY,'content-type':'application/json'},body:JSON.stringify({model:OPENAI_MODEL,input:[{role:'system',content:'Ты помощник диагностики игры Лунная страховка. Отвечай по-русски, кратко и безопасно. Помогай находить ошибки интерфейса и предлагай шаги проверки. Не проси пароли, коды, банковские данные или личную информацию. Если данных недостаточно, скажи об этом.'},{role:'user',content:'Проблема: '+String(question).slice(0,1800)+'\nТехнические ошибки: '+JSON.stringify(safeErrors)}],max_output_tokens:500})});
 const data=await resp.json();if(!resp.ok)throw new Error(data.error?.message||'AI provider error '+resp.status);
 return (data.output||[]).flatMap(o=>o.content||[]).filter(c=>c.type==='output_text').map(c=>c.text).join('\n')||'ИИ не смог сформировать ответ.';
}
async function sendEmail(report,analysis){
 if(!RESEND_API_KEY||!REPORT_TO_EMAIL||!REPORT_FROM_EMAIL)throw new Error('Email is not configured. Set RESEND_API_KEY, REPORT_TO_EMAIL and REPORT_FROM_EMAIL.');
 const errs=Array.isArray(report.errors)?report.errors.slice(-8):[];
 const body=['Лунная страховка — технический отчёт','Время: '+String(report.time||new Date().toISOString()),'Приложение: '+String(report.app||'Lunar Insurance').slice(0,100),'Страница: '+String(report.url||'').slice(0,500),'Браузер: '+String(report.userAgent||'').slice(0,250),'Сообщение: '+String(report.message||'').slice(0,500),'','Ошибки:',JSON.stringify(errs,null,2),'','Анализ ИИ:',String(analysis||'Анализ не настроен.')].join('\n');
 const resp=await fetch('https://api.resend.com/emails',{method:'POST',headers:{authorization:'Bearer '+RESEND_API_KEY,'content-type':'application/json'},body:JSON.stringify({from:REPORT_FROM_EMAIL,to:[REPORT_TO_EMAIL],subject:'[Лунная страховка] Технический отчёт',text:body})});
 const data=await resp.json();if(!resp.ok)throw new Error(data.message||'Email provider error '+resp.status);return data;
}
http.createServer(async(req,res)=>{
 const url=new URL(req.url,'http://localhost');
 if(req.method==='GET'&&url.pathname==='/api/health')return json(res,200,{ok:true,ai:!!OPENAI_API_KEY,email:!!(RESEND_API_KEY&&REPORT_TO_EMAIL&&REPORT_FROM_EMAIL)});
 if(req.method!=='POST'||!['/api/ai','/api/report'].includes(url.pathname))return json(res,404,{error:'Not found'});
 if(limited(req))return json(res,429,{error:'Too many requests'});
 try{
  const body=await readBody(req);
  if(url.pathname==='/api/ai'){const q=String(body.question||'').trim();if(!q)return json(res,400,{error:'Question is required'});return json(res,200,{answer:await aiAnswer(q,body.errors)});}
  const report={message:String(body.message||'').slice(0,500),errors:Array.isArray(body.errors)?body.errors.slice(-8):[],url:String(body.url||'').slice(0,500),userAgent:String(body.userAgent||'').slice(0,250),time:String(body.time||new Date().toISOString()),app:String(body.app||'Lunar Insurance').slice(0,100)};
  let analysis='AI analysis unavailable';try{analysis=await aiAnswer('Проанализируй технический отчёт и предложи вероятную причину и следующий шаг.',report.errors);}catch(e){analysis='Не удалось получить анализ ИИ: '+e.message;}
  const mail=await sendEmail(report,analysis);return json(res,200,{ok:true,id:mail.id||null});
 }catch(e){return json(res,500,{error:String(e.message||e).slice(0,400)});}
}).listen(PORT,()=>console.log('Lunar AI server listening on port '+PORT));
