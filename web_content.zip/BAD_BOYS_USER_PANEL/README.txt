BAD BOYS ESPORTS User Panel
user_panel.html SPCK Editor-এ খুলুন অথবা ওয়েব হোস্টিংয়ে আপলোড করুন।
Firebase Console-এ Email/Password Authentication চালু থাকতে হবে।
সতর্কতা: বাস্তব টাকা/ব্যালেন্স ব্যবহারের আগে Firestore Rules এবং সার্ভার-সাইড যাচাই ঠিক করুন।
