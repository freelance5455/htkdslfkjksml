# StudyOS — Capacitor (Android APK) প্রজেক্ট

এই ফোল্ডার দিয়ে StudyOS-কে আসল Android অ্যাপ (APK) বানানো যাবে। APK-তে **Export → আসল `.json` ফাইল** পাওয়া যায়
(ফোনের শেয়ার-মেনু খোলে — সেখান থেকে Drive / Files / WhatsApp / Gmail যেখানে ইচ্ছা সেভ করো)।

> ⚠️ এই প্রজেক্ট আমি নিজে APK বানিয়ে চালিয়ে দেখতে পারিনি (আমার পরিবেশে Android SDK ও npm নেই)।
> ফাইল ও কনফিগ স্ট্যান্ডার্ড Capacitor ৬ নিয়মে সাজানো। কোথাও আটকালে error-টা পাঠাও, ঠিক করে দেব।

## ফোল্ডারে কী আছে
| ফাইল | কাজ |
|---|---|
| `www/index.html` | তোমার StudyOS অ্যাপ (সম্পূর্ণ অফলাইন) |
| `capacitor.config.json` | অ্যাপের নাম (`StudyOS`) ও আইডি (`com.studyos.app`) |
| `package.json` | দরকারি প্লাগইন: App (Back বাটন), Filesystem + Share (ব্যাকআপ ফাইল) |
| `keystore/debug.keystore` | স্থায়ী সাইন-কী — এতে নতুন APK **পুরোনোটার ওপর ইনস্টল** হয়, ডেটা মোছে না |
| `.github/workflows/build-apk.yml` | GitHub-এ নিজে নিজে APK বানানোর স্ক্রিপ্ট |
| `samples/mcq-demo.json` | MCQ ইমপোর্টের ডেমো (১২টি প্রশ্ন, ৪ বিষয়) |
| `samples/mcq-demo-physics.csv` | CSV ডেমো (শুধু Physics) |

---
## পথ ১ — কিছু ইনস্টল না করে, GitHub দিয়ে (সবচেয়ে সহজ)
1. github.com-এ ফ্রি অ্যাকাউন্ট খুলে **New repository** বানাও (Private রাখতে পারো)।
2. ZIP খুলে ভেতরের **সব ফাইল ও ফোল্ডার** (`www`, `keystore`, `.github`, `package.json`, `capacitor.config.json` …) রিপোজিটরিতে আপলোড করো
   (**Add file → Upload files**-এ ফোল্ডারসহ ড্র্যাগ করো)।
   - `.github` ফোল্ডারটা লুকানো থাকে। না দেখালে: **Add file → Create new file** → নামের ঘরে লেখো `.github/workflows/build-apk.yml` →
     `extras/build-apk.yml` ফাইলের লেখা কপি-পেস্ট করে Commit করো।
3. রিপোজিটরির **Actions** ট্যাবে যাও → **Build StudyOS APK** → **Run workflow**।
4. ৫–১০ মিনিট পর কাজ শেষ হলে ওই রানে ঢুকে নিচে **Artifacts → StudyOS-APK** ডাউনলোড করো → ZIP খুললে `app-debug.apk`।
5. ফোনে APK ইনস্টল করো ("অজানা উৎস থেকে ইনস্টল" চালু করতে হতে পারে)।

## পথ ২ — নিজের কম্পিউটারে (Android Studio)
1. Node.js (১৮+) ও Android Studio ইনস্টল করো।
2. এই ফোল্ডারে টার্মিনাল খুলে:
   ```
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
   ```
3. Android Studio-তে **Build → Build Bundle(s)/APK(s) → Build APK(s)**।
   অথবা টার্মিনালে: `npm run apk` → APK থাকবে `android/app/build/outputs/apk/debug/app-debug.apk`।

---
## অ্যাপ আপডেট করতে
নতুন `studyos-upgraded.html` পেলে সেটার নাম `index.html` করে `www/` ফোল্ডারে আগেরটার জায়গায় বসাও, তারপর আবার বিল্ড করো
(GitHub-এ ফাইল রিপ্লেস করে Commit করলেই নিজে নিজে বিল্ড শুরু হবে)। `keystore/debug.keystore` না বদলালে নতুন APK পুরোনোর ওপর ইনস্টল হয়ে ডেটা থেকে যাবে।

## ব্যাকআপ কীভাবে কাজ করবে (APK-তে)
- **Settings → Backup → Export:** ফোনের শেয়ার-মেনু খোলে, `studyos-backup-তারিখ.json` ফাইলটা তাতে থাকে — Drive/Files/WhatsApp-এ সেভ করো।
- **Import backup → Choose file:** সেই `.json` ফাইল বাছো। (লগইন স্ক্রিনের **Restore from backup**-ও একই।)
- ফাইল না পেলে "ব্যাকআপ টেক্সট পেস্ট করো" পথটাও আছে।

## ⚠️ ডেটা নিয়ে সাবধানতা
- নতুন বানানো APK আগের অন্য-টুলে বানানো APK-র **ডেটা দেখতে পাবে না** (আলাদা অ্যাপ)। নতুন অ্যাপে প্রথমে ফাঁকা শুরু হবে।
  আগের APK-তে দরকারি ডেটা থাকলে ওটা ফেলে দেওয়ার আগে সেখান থেকে যেভাবে পারো ব্যাকআপ নাও।
- ফোন বদলানো/অ্যাপ ডিলিটের আগে সবসময় **Export** করে `.json` ফাইলটা নিরাপদ জায়গায় রাখো।

## MCQ ইমপোর্ট (`.json` / CSV / টেক্সট)
**MCQ → নিচের "Import"** → বিষয় বেছে → **CSV / JSON / টেক্সট ফাইল বেছে নাও** → **ইমপোর্ট করো**।

JSON-এর ফরম্যাট (নমুনা: `samples/mcq-demo.json`):
```json
[
  { "subject": "Physics",
    "question": "SI এককে বলের একক কোনটি?",
    "options": ["জুল", "প্যাসকেল", "ওয়াট", "নিউটন"],
    "answer": "D" }
]
```
- `answer`: `A`/`B`/`C`/`D`, অথবা `1`–`4`, অথবা অপশনের হুবহু লেখা। (`"answerIndex": 0–3` দিলে ০ থেকে গোনা হয়।)
- `subject` অ্যাপের বিষয়ের নামের সাথে মিললে প্রশ্ন সেই বিষয়ে যায়; না মিললে/না দিলে ওপরে বেছে নেওয়া বিষয়ে যায়।
- প্রতি প্রশ্নে ঠিক ৪টি অপশন লাগবে; ভুল প্রশ্ন বাদ পড়ে ও সংখ্যা দেখায়। একই বিষয়ে একই প্রশ্ন দ্বিতীয়বার যোগ হয় না।
- CSV-তে বিষয় থাকে না — যে বিষয় বেছেছ সবই সেখানে যায়। বাংলা থাকলে ফাইল **UTF-8** এ সেভ করো।

## আটকে গেলে
- `npx cap doctor` চালিয়ে দেখো কী কম আছে।
- Java ১৭ লাগে (Android Studio-র সাথেই আসে)।
- `npm install` ব্যর্থ হলে ইন্টারনেট/Node-এর ভার্সন (১৮+) দেখো।
