CARD SCHOOL PRO V5 - HTML TO APK FIX

IMPORTANT:
- index.html is at the ROOT of the ZIP.
- Keep all files in the same directory.
- Use index.html as the start page in HTML to APK Builder.
- Enable JavaScript.
- Camera/file permissions are optional depending on the Builder version; gallery/file input can work without premium camera permission in some versions.
