AVRIX Store - updated starter

This version starts with an EMPTY catalogue (no sample/demo products).
Features:
- Admin can add products with name, price, category, description, stock and photo.
- Customers can open product details, Add to Cart, or Buy Now.
- Cart checkout form collects name, phone and delivery address.
- Cash-on-delivery order message is prepared for WhatsApp.

IMPORTANT:
- This is still a local front-end prototype, not a production e-commerce system.
- Products are stored only on the device/browser where Admin adds them. Other customers on other phones will NOT see them.
- WhatsApp order messages are configured to open the business WhatsApp number previously provided by the store owner. Verify the number before sharing the app publicly.
- No online payments, shared database, customer login, secure admin login, inventory sync, or order dashboard.
- Before real customer sales, deploy a secure backend/database and configure seller contact, privacy/security, and delivery terms.
- Do not collect real customer details using this prototype until the order flow is properly configured and tested.

Preview: open index.html in a browser or wrap it with an Android WebView/Capacitor builder.
