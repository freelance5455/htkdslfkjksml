<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/1704626b-a01a-4b5e-98b8-77dc86ffd2bd

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`


## Pixel Art HD adaptation

The original archive contains no separate texture image pack: world textures are drawn procedurally in `src/engine/spriteRenderer.ts`. This adaptation adds a shared Pixel Art HD finishing pass to world tiles (pixel bevels, deterministic surface flecks and subtle glints), plus character silhouette and highlight details. The game systems and gameplay data are preserved. Review the in-game result before mobile packaging.
