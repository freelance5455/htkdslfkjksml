/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import { 
  PlayerStats, 
  ZoneId, 
  Quest, 
  MarketListing, 
  TradeHistoryItem, 
  InventorySlot, 
  ItemRarity, 
  NPC, 
  ResourceNode 
} from './types/game';
import { INITIAL_QUESTS } from './data/quests';
import { ZONES } from './data/worldMap';
import { ITEMS_DATABASE, RARITY_CONFIG } from './data/items';
import { generateInitialMarketplace, generateItemHash } from './services/marketplaceService';
import { soundManager } from './audio/soundManager';

import { TitleScreen } from './components/TitleScreen';
import { GameCanvas } from './engine/GameCanvas';
import { HUD } from './components/HUD';
import { VirtualControls } from './components/VirtualControls';
import { InventoryModal } from './components/InventoryModal';
import { CraftingModal } from './components/CraftingModal';
import { ShopModal } from './components/ShopModal';
import { QuestModal } from './components/QuestModal';
import { WorldMapModal } from './components/WorldMapModal';
import { FishingModal } from './components/FishingModal';
import { MarketplacePortal } from './components/MarketplacePortal';
import { SettingsModal } from './components/SettingsModal';

const SAVE_KEY = 'world_of_treasures_save_v1';

export default function App() {
  const [gameState, setGameState] = useState<'TITLE_MENU' | 'PLAYING'>('TITLE_MENU');
  const [currentZone, setCurrentZone] = useState<ZoneId>('starter_village');
  const [isMuted, setIsMuted] = useState(false);

  // Active Overlay Modals
  const [activeModal, setActiveModal] = useState<
    'none' | 'inventory' | 'crafting' | 'shop' | 'quests' | 'map' | 'fishing' | 'marketplace' | 'settings' | 'dialogue'
  >('none');

  const [activeDialogueNpc, setActiveDialogueNpc] = useState<NPC | null>(null);
  const [activeFishingSpot, setActiveFishingSpot] = useState<ResourceNode | null>(null);
  const [preselectedSellSlot, setPreselectedSellSlot] = useState<InventorySlot | null>(null);

  // Notification Toast state
  const [toast, setToast] = useState<{ message: string; color: string } | null>(null);
  const toastTimeoutRef = useRef<number | null>(null);

  const showToast = (message: string, color = '#facc15') => {
    if (toastTimeoutRef.current) clearTimeout(toastTimeoutRef.current);
    setToast({ message, color });
    toastTimeoutRef.current = window.setTimeout(() => setToast(null), 3000);
  };

  // Initial Player Stats
  const createInitialPlayerStats = (): PlayerStats => {
    const inv: (InventorySlot | null)[] = Array(24).fill(null);

    const starterItems: { id: string; count: number }[] = [
      { id: 'world_lock', count: 1 },
      { id: 'block_dirt', count: 20 },
      { id: 'seed_dirt', count: 6 },
      { id: 'block_wood', count: 12 },
      { id: 'seed_wood', count: 4 },
      { id: 'sword_wood', count: 1 },
      { id: 'potion_health', count: 3 },
    ];

    starterItems.forEach((st, idx) => {
      const itm = ITEMS_DATABASE[st.id];
      if (itm) {
        inv[idx] = {
          item: itm,
          count: st.count,
          hash: generateItemHash(itm.id),
          obtainedAt: Date.now(),
        };
      }
    });

    return {
      hp: 100,
      maxHp: 100,
      energy: 100,
      maxEnergy: 100,
      level: 1,
      xp: 0,
      xpToNextLevel: 100,
      gold: 50,
      gems: 250,
      worldLocks: 1,
      punchMode: 'fist',
      heldSlotIndex: 0,
      chatBubble: null,
      equippedTool: {
        sword: 'sword_wood',
        pickaxe: 'pickaxe_starter',
        axe: 'axe_starter',
        hoe: 'hoe_starter',
        rod: 'rod_starter',
      },
      selectedToolType: 'sword',
      inventory: inv,
      inventorySize: 24,
      unlockedZones: ['starter_village'],
      statsRecord: {
        treesChopped: 0,
        oresMined: 0,
        fishCaught: 0,
        cropsHarvested: 0,
        monstersDefeated: 0,
        itemsCrafted: 0,
        goldEarned: 50,
      },
    };
  };

  const [playerStats, setPlayerStats] = useState<PlayerStats>(createInitialPlayerStats);
  const [quests, setQuests] = useState<Quest[]>(INITIAL_QUESTS);

  // Marketplace Listings & Trade History
  const [marketplaceData, setMarketplaceData] = useState(() => generateInitialMarketplace());

  // Check saved game existence
  const [hasSavedGame, setHasSavedGame] = useState(() => {
    try {
      return !!localStorage.getItem(SAVE_KEY);
    } catch {
      return false;
    }
  });

  // Load Saved Game
  const loadGame = useCallback(() => {
    try {
      const dataStr = localStorage.getItem(SAVE_KEY);
      if (dataStr) {
        const parsed = JSON.parse(dataStr);
        if (parsed.playerStats) setPlayerStats(parsed.playerStats);
        if (parsed.currentZone) setCurrentZone(parsed.currentZone);
        if (parsed.quests) setQuests(parsed.quests);
        if (parsed.marketplaceData) setMarketplaceData(parsed.marketplaceData);
        showToast('Progres petualangan berhasil dimuat!', '#38bdf8');
      }
    } catch {
      // Ignore load errors
    }
  }, []);

  // Save Game
  const saveGame = useCallback(() => {
    try {
      const toSave = {
        playerStats,
        currentZone,
        quests,
        marketplaceData,
        savedAt: Date.now(),
      };
      localStorage.setItem(SAVE_KEY, JSON.stringify(toSave));
      setHasSavedGame(true);
    } catch {
      // Ignore save errors
    }
  }, [playerStats, currentZone, quests, marketplaceData]);

  // Auto-Save every 30 seconds
  useEffect(() => {
    if (gameState !== 'PLAYING') return;
    const interval = setInterval(() => {
      saveGame();
    }, 30000);
    return () => clearInterval(interval);
  }, [gameState, saveGame]);

  // Level Up Check
  useEffect(() => {
    if (playerStats.xp >= playerStats.xpToNextLevel) {
      soundManager.playLevelUp();
      setPlayerStats(prev => {
        const newLvl = prev.level + 1;
        const newMaxHp = prev.maxHp + 20;
        showToast(`🎉 NAIK LEVEL! Sekarang Anda Level ${newLvl}!`, '#facc15');

        // Check if new zones unlocked
        let unlocked = [...prev.unlockedZones];
        if (newLvl >= 2 && !unlocked.includes('mystic_forest')) unlocked.push('mystic_forest');
        if (newLvl >= 3 && !unlocked.includes('crystal_cave')) unlocked.push('crystal_cave');
        if (newLvl >= 4 && !unlocked.includes('ancient_ruins')) unlocked.push('ancient_ruins');

        return {
          ...prev,
          level: newLvl,
          hp: newMaxHp,
          maxHp: newMaxHp,
          xp: prev.xp - prev.xpToNextLevel,
          xpToNextLevel: Math.round(prev.xpToNextLevel * 1.6),
          unlockedZones: unlocked,
        };
      });
    }
  }, [playerStats.xp, playerStats.xpToNextLevel]);

  // Synchronize Quests with player stats
  useEffect(() => {
    setQuests(prev =>
      prev.map(q => {
        let count = q.currentCount;
        if (q.id === 'quest_harvest') count = playerStats.statsRecord.cropsHarvested;
        else if (q.id === 'quest_logging') count = playerStats.statsRecord.treesChopped;
        else if (q.id === 'quest_mining') count = playerStats.statsRecord.oresMined;
        else if (q.id === 'quest_fishing') count = playerStats.statsRecord.fishCaught;
        else if (q.id === 'quest_hunting') count = playerStats.statsRecord.monstersDefeated;
        else if (q.id === 'quest_trading') count = playerStats.gold;

        const isComplete = count >= q.targetCount;
        if (isComplete && !q.completed) {
          soundManager.playLevelUp();
          showToast(`Misi Selesai: ${q.title}!`, '#4ade80');
        }

        return {
          ...q,
          currentCount: count,
          completed: isComplete,
        };
      })
    );
  }, [playerStats.statsRecord, playerStats.gold]);

  // Keyboard hotkeys for HUD & Menu
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (gameState !== 'PLAYING') return;

      const k = e.key.toLowerCase();

      // Tool switching
      if (['1', '2', '3', '4', '5'].includes(k)) {
        const types: ('sword' | 'pickaxe' | 'axe' | 'hoe' | 'rod')[] = ['sword', 'pickaxe', 'axe', 'hoe', 'rod'];
        const selected = types[parseInt(k) - 1];
        if (selected) {
          soundManager.playMine();
          setPlayerStats(prev => ({ ...prev, selectedToolType: selected }));
        }
        return;
      }

      // Modals toggling
      if (k === 'i') {
        setActiveModal(prev => (prev === 'inventory' ? 'none' : 'inventory'));
      } else if (k === 'c') {
        setActiveModal(prev => (prev === 'crafting' ? 'none' : 'crafting'));
      } else if (k === 'q') {
        setActiveModal(prev => (prev === 'quests' ? 'none' : 'quests'));
      } else if (k === 'm') {
        setActiveModal(prev => (prev === 'map' ? 'none' : 'map'));
      } else if (k === 'p') {
        setActiveModal(prev => (prev === 'marketplace' ? 'none' : 'marketplace'));
      } else if (k === 'escape') {
        setActiveModal(prev => (prev === 'none' ? 'settings' : 'none'));
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [gameState]);

  // Touch & Virtual Control States
  const [touchVector, setTouchVector] = useState({ x: 0, y: 0 });
  const [isActionPressed, setIsActionPressed] = useState(false);
  const [isInteractPressed, setIsInteractPressed] = useState(false);
  const [isJumpPressed, setIsJumpPressed] = useState(false);
  const [inspectedInfo, setInspectedInfo] = useState<{ title: string; desc: string; icon: string } | null>(null);

  // Check if touch device / mobile screen
  const [isTouchDevice, setIsTouchDevice] = useState(false);
  useEffect(() => {
    setIsTouchDevice('ontouchstart' in window || navigator.maxTouchPoints > 0 || window.innerWidth <= 768);
  }, []);

  // Item Acquisition Handler
  const handleItemAcquired = useCallback((itemId: string, count: number, rarity: ItemRarity) => {
    const item = ITEMS_DATABASE[itemId];
    if (!item) return;

    soundManager.playHarvest();
    showToast(`+${count}x ${item.nameId || item.name} (${RARITY_CONFIG[rarity].labelId})`, RARITY_CONFIG[rarity].color);

    setPlayerStats(prev => {
      const inv = [...prev.inventory];
      const existing = item.stackable ? inv.find(s => s && s.item.id === itemId) : null;

      if (existing) {
        existing.count += count;
      } else {
        const emptyIdx = inv.findIndex(s => s === null);
        if (emptyIdx !== -1) {
          inv[emptyIdx] = {
            item,
            count,
            hash: generateItemHash(item.id),
            obtainedAt: Date.now(),
          };
        }
      }

      return {
        ...prev,
        inventory: inv,
      };
    });
  }, []);

  return (
    <div className="relative w-full h-screen bg-slate-950 text-slate-100 overflow-hidden select-none">
      {/* 1. Title Menu Screen */}
      {gameState === 'TITLE_MENU' ? (
        <TitleScreen
          onStartGame={() => {
            setGameState('PLAYING');
            soundManager.playZoneBGM(ZONES[currentZone].bgmTheme);
          }}
          hasSavedGame={hasSavedGame}
          onContinueGame={() => {
            loadGame();
            setGameState('PLAYING');
            soundManager.playZoneBGM(ZONES[currentZone].bgmTheme);
          }}
          onOpenMarketplace={() => {
            setActiveModal('marketplace');
          }}
        />
      ) : (
        /* 2. Active Game Screen */
        <div className="relative w-full h-full">
          {/* Main 2D Pixel Canvas */}
          <GameCanvas
            currentZone={currentZone}
            onZoneChange={newZone => {
              setCurrentZone(newZone);
              showToast(`Memasuki Wilayah: ${newZone.replace('_', ' ').toUpperCase()}`, '#a855f7');
            }}
            playerStats={playerStats}
            onUpdateStats={setPlayerStats}
            onOpenShop={() => setActiveModal('shop')}
            onOpenCrafting={() => setActiveModal('crafting')}
            onOpenQuests={() => setActiveModal('quests')}
            onItemAcquired={handleItemAcquired}
            movementInput={touchVector}
            isActionPressed={isActionPressed}
            isInteractPressed={isInteractPressed}
            isJumpPressed={isJumpPressed}
            onInspectTile={(tile, tx, ty) => {
              if (tile.tree) {
                setInspectedInfo({
                  title: tile.tree.seedName,
                  desc: tile.tree.ready ? 'Pohon telah berbuah! Pukul untuk memanen buah & gems.' : 'Pohon sedang bertumbuh.',
                  icon: '🌳',
                });
              } else if (tile.block === 'main_door') {
                setInspectedInfo({
                  title: 'White Exit Door',
                  desc: `Pintu portal menuju: ${tile.doorLabel || 'Dunia Lain'}`,
                  icon: '🚪',
                });
              } else if (tile.block === 'world_lock') {
                setInspectedInfo({
                  title: 'World Lock (WL)',
                  desc: 'World ini dilindungi oleh World Lock pemilik!',
                  icon: '🔒',
                });
              } else if (tile.block !== 'empty') {
                setInspectedInfo({
                  title: `Blok: ${tile.block.toUpperCase()}`,
                  desc: `Ketahanan Blok: ${tile.hitsTaken}/${tile.maxHits} Pukulan.`,
                  icon: '🟫',
                });
              }
            }}
          />

          {/* Low-Occlusion Growtopia HUD Overlay */}
          <HUD
            playerStats={playerStats}
            currentZone={currentZone}
            isMuted={isMuted}
            onToggleMute={() => {
              const next = !isMuted;
              setIsMuted(next);
              soundManager.setMuted(next);
            }}
            onOpenInventory={() => setActiveModal('inventory')}
            onOpenCrafting={() => setActiveModal('crafting')}
            onOpenQuests={() => setActiveModal('quests')}
            onOpenMap={() => setActiveModal('map')}
            onOpenMarketplace={() => {
              setPreselectedSellSlot(null);
              setActiveModal('marketplace');
            }}
            onOpenSettings={() => setActiveModal('settings')}
            onTogglePunchMode={() => {
              setPlayerStats(prev => ({
                ...prev,
                punchMode: prev.punchMode === 'fist' ? 'wrench' : 'fist',
              }));
              showToast(
                playerStats.punchMode === 'fist' ? '🔧 Mode Wrench (Periksa)' : '👊 Mode Tinju (Pukul/Hancurkan)',
                playerStats.punchMode === 'fist' ? '#f39c12' : '#e74c3c'
              );
            }}
            onSelectSlot={idx => {
              setPlayerStats(prev => ({ ...prev, heldSlotIndex: idx }));
            }}
            onSendChat={text => {
              soundManager.playHarvest();
              setPlayerStats(prev => ({
                ...prev,
                chatBubble: { text, timer: 4.0 },
              }));
              setTimeout(() => {
                setPlayerStats(prev => ({ ...prev, chatBubble: null }));
              }, 4000);
            }}
          />

          {/* Virtual Joystick & Action Buttons for Mobile / Touch Devices */}
          {isTouchDevice && (
            <VirtualControls
              onMoveChange={setTouchVector}
              onJumpDown={() => setIsJumpPressed(true)}
              onJumpUp={() => setIsJumpPressed(false)}
              onActionDown={() => setIsActionPressed(true)}
              onActionUp={() => setIsActionPressed(false)}
              punchMode={playerStats.punchMode}
            />
          )}

          {/* Floating Toast Notification */}
          {toast && (
            <div className="absolute top-20 left-1/2 -translate-x-1/2 pointer-events-none z-50 animate-bounce">
              <div 
                className="bg-slate-900/95 font-pixel text-xs sm:text-sm px-4 py-2 rounded-xl border shadow-xl flex items-center gap-2"
                style={{ borderColor: toast.color, color: toast.color }}
              >
                <span>{toast.message}</span>
              </div>
            </div>
          )}

          {/* Growtopia Wrench Inspection Modal */}
          {inspectedInfo && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs select-none">
              <div className="w-full max-w-sm bg-[#154360] border-4 border-[#2980b9] rounded-2xl p-6 shadow-2xl text-center">
                <div className="text-4xl mb-2">{inspectedInfo.icon}</div>
                <h3 className="font-pixel text-base font-bold text-white mb-2">{inspectedInfo.title}</h3>
                <p className="text-xs text-[#d4e6f1] leading-relaxed mb-6">{inspectedInfo.desc}</p>
                <button
                  onClick={() => setInspectedInfo(null)}
                  className="px-6 py-2 bg-[#27ae60] hover:bg-[#2ecc71] border-2 border-[#a9dfbf] text-white font-pixel font-bold text-xs rounded-xl shadow-md cursor-pointer active:scale-95"
                >
                  OK
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* --- MODALS --- */}
      {/* 1. Inventory Modal */}
      {activeModal === 'inventory' && (
        <InventoryModal
          playerStats={playerStats}
          onClose={() => setActiveModal('none')}
          onUpdateStats={setPlayerStats}
          onOpenMarketListing={slot => {
            setPreselectedSellSlot(slot);
            setActiveModal('marketplace');
          }}
        />
      )}

      {/* 2. Crafting Modal */}
      {activeModal === 'crafting' && (
        <CraftingModal
          playerStats={playerStats}
          onClose={() => setActiveModal('none')}
          onUpdateStats={setPlayerStats}
        />
      )}

      {/* 3. Shop Modal */}
      {activeModal === 'shop' && (
        <ShopModal
          playerStats={playerStats}
          onClose={() => setActiveModal('none')}
          onUpdateStats={setPlayerStats}
        />
      )}

      {/* 4. Quests Modal */}
      {activeModal === 'quests' && (
        <QuestModal
          quests={quests}
          playerStats={playerStats}
          onClose={() => setActiveModal('none')}
          onUpdateStats={setPlayerStats}
          onUpdateQuests={setQuests}
        />
      )}

      {/* 5. World Map Modal */}
      {activeModal === 'map' && (
        <WorldMapModal
          currentZone={currentZone}
          playerStats={playerStats}
          onClose={() => setActiveModal('none')}
          onFastTravel={zoneId => setCurrentZone(zoneId)}
        />
      )}

      {/* 6. Fishing Minigame Modal */}
      {activeModal === 'fishing' && (
        <FishingModal
          currentZone={currentZone}
          playerStats={playerStats}
          onClose={() => {
            setActiveFishingSpot(null);
            setActiveModal('none');
          }}
          onFishCaught={handleItemAcquired}
          onUpdateStats={setPlayerStats}
        />
      )}

      {/* 7. Marketplace Portal Website */}
      {activeModal === 'marketplace' && (
        <MarketplacePortal
          playerStats={playerStats}
          listings={marketplaceData.listings}
          tradeHistory={marketplaceData.history}
          preselectedSellSlot={preselectedSellSlot}
          onClose={() => {
            setPreselectedSellSlot(null);
            setActiveModal('none');
          }}
          onUpdateStats={setPlayerStats}
          onUpdateListings={updater => {
            setMarketplaceData(prev => ({
              ...prev,
              listings: updater(prev.listings),
            }));
          }}
          onAddTradeHistory={trade => {
            setMarketplaceData(prev => ({
              ...prev,
              history: [trade, ...prev.history],
            }));
          }}
        />
      )}

      {/* 8. Settings & Save/Load Modal */}
      {activeModal === 'settings' && (
        <SettingsModal
          playerStats={playerStats}
          currentZone={currentZone}
          isMuted={isMuted}
          onToggleMute={() => {
            const next = !isMuted;
            setIsMuted(next);
            soundManager.setMuted(next);
          }}
          onClose={() => setActiveModal('none')}
          onSaveGame={saveGame}
          onLoadGame={loadGame}
          onResetGame={() => {
            localStorage.removeItem(SAVE_KEY);
            setPlayerStats(createInitialPlayerStats());
            setCurrentZone('starter_village');
            setQuests(INITIAL_QUESTS);
            setMarketplaceData(generateInitialMarketplace());
            setHasSavedGame(false);
            showToast('Progres berhasil direset dari awal!', '#ef4444');
          }}
          onImportSave={jsonStr => {
            try {
              const parsed = JSON.parse(jsonStr);
              if (parsed.playerStats) setPlayerStats(parsed.playerStats);
              if (parsed.currentZone) setCurrentZone(parsed.currentZone);
              showToast('Berkas simpanan berhasil diimpor!', '#38bdf8');
            } catch {
              showToast('Format berkas simpanan tidak valid!', '#ef4444');
            }
          }}
        />
      )}

      {/* 9. NPC Dialogue Modal */}
      {activeModal === 'dialogue' && activeDialogueNpc && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm select-none">
          <div className="relative w-full max-w-lg bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-6 flex flex-col gap-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-3xl">
                {activeDialogueNpc.avatar}
              </div>
              <div>
                <h3 className="font-pixel text-base font-bold text-white">
                  {activeDialogueNpc.name}
                </h3>
                <span className="text-xs text-amber-400 font-semibold">{activeDialogueNpc.role}</span>
              </div>
            </div>

            <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800 space-y-2">
              {activeDialogueNpc.dialogue.map((line, i) => (
                <p key={i} className="text-xs text-slate-200 leading-relaxed">
                  "{line}"
                </p>
              ))}
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => {
                  soundManager.playMine();
                  setActiveDialogueNpc(null);
                  setActiveModal('none');
                }}
                className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl active:scale-95 transition-transform cursor-pointer"
              >
                Lanjutkan Petualangan
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
