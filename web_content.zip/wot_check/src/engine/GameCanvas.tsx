import React, { useEffect, useRef, useState } from 'react';
import { 
  ZoneId, 
  PlayerStats, 
  WorldTile, 
  FloatingDrop, 
  Particle, 
  ItemRarity,
  BlockType
} from '../types/game';
import { ZONES } from '../data/worldMap';
import { ITEMS_DATABASE, RARITY_CONFIG } from '../data/items';
import { generateGrowtopiaWorld, WORLD_WIDTH, WORLD_HEIGHT } from '../data/growtopiaWorld';
import { 
  drawSkyAndBackdrop, 
  drawWallpaper, 
  drawGrowtopiaBlock, 
  drawFloatingDrops, 
  drawGrowtopiaPlayer, 
  TILE_SIZE 
} from './spriteRenderer';
import { soundManager } from '../audio/soundManager';

interface GameCanvasProps {
  currentZone: ZoneId;
  onZoneChange: (newZone: ZoneId) => void;
  playerStats: PlayerStats;
  onUpdateStats: (updater: (prev: PlayerStats) => PlayerStats) => void;
  onOpenShop: () => void;
  onOpenCrafting: () => void;
  onOpenQuests: () => void;
  onItemAcquired: (itemId: string, count: number, rarity: ItemRarity) => void;
  movementInput: { x: number; y: number };
  isActionPressed: boolean;
  isInteractPressed: boolean;
  isJumpPressed: boolean;
  onInspectTile?: (tile: WorldTile, tx: number, ty: number) => void;
}

export const GameCanvas: React.FC<GameCanvasProps> = ({
  currentZone,
  onZoneChange,
  playerStats,
  onUpdateStats,
  onOpenShop,
  onOpenCrafting,
  onOpenQuests,
  onItemAcquired,
  movementInput,
  isActionPressed,
  isInteractPressed,
  isJumpPressed,
  onInspectTile,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // World Grids mapped by zone
  const worldGridsRef = useRef<Record<ZoneId, WorldTile[][]>>({
    starter_village: generateGrowtopiaWorld('starter_village'),
    mystic_forest: generateGrowtopiaWorld('mystic_forest'),
    crystal_cave: generateGrowtopiaWorld('crystal_cave'),
    ancient_ruins: generateGrowtopiaWorld('ancient_ruins'),
  });

  // Growtopia 2D Platformer Physics State
  const playerRef = useRef({
    x: 4 * TILE_SIZE,
    y: 10 * TILE_SIZE,
    vx: 0,
    vy: 0,
    width: 22,
    height: 30,
    facingRight: true,
    isGrounded: false,
    jumpCount: 0,
    punchAnim: 0,
    punchTimer: 0,
  });

  const dropsRef = useRef<FloatingDrop[]>([]);
  const particlesRef = useRef<Particle[]>([]);
  const lastTimeRef = useRef(performance.now());
  const keysHeld = useRef<Record<string, boolean>>({});

  // Keyboard input listeners
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      keysHeld.current[e.key.toLowerCase()] = true;
      keysHeld.current[e.code.toLowerCase()] = true;
    };
    const handleKeyUp = (e: KeyboardEvent) => {
      keysHeld.current[e.key.toLowerCase()] = false;
      keysHeld.current[e.code.toLowerCase()] = false;
    };
    const handleBlur = () => {
      keysHeld.current = {};
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    window.addEventListener('blur', handleBlur);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      window.removeEventListener('blur', handleBlur);
    };
  }, []);

  // Zone Change Spawn
  useEffect(() => {
    soundManager.playZoneBGM(ZONES[currentZone].bgmTheme);
    playerRef.current.x = 4 * TILE_SIZE;
    playerRef.current.y = 10 * TILE_SIZE;
    playerRef.current.vx = 0;
    playerRef.current.vy = 0;
  }, [currentZone]);

  // Handle direct touch/click on screen grid (Growtopia style click-to-punch / click-to-place)
  const handleCanvasInteraction = (clientX: number, clientY: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const clickX = clientX - rect.left;
    const clickY = clientY - rect.top;

    const p = playerRef.current;
    const camX = Math.round(canvas.width / 2 - (p.x + p.width / 2));
    const camY = Math.round(canvas.height / 2 - (p.y + p.height / 2));

    const worldClickX = clickX - camX;
    const worldClickY = clickY - camY;

    const tx = Math.floor(worldClickX / TILE_SIZE);
    const ty = Math.floor(worldClickY / TILE_SIZE);

    if (tx < 0 || tx >= WORLD_WIDTH || ty < 0 || ty >= WORLD_HEIGHT) return;

    // Check reach distance (radius of ~3.5 blocks)
    const pCenterTileX = (p.x + p.width / 2) / TILE_SIZE;
    const pCenterTileY = (p.y + p.height / 2) / TILE_SIZE;
    const dist = Math.hypot(tx + 0.5 - pCenterTileX, ty + 0.5 - pCenterTileY);

    if (dist > 4.5) return; // Out of reach

    triggerTileAction(tx, ty);
  };

  const triggerTileAction = (tx: number, ty: number) => {
    const p = playerRef.current;
    p.punchAnim = 1.0;
    p.punchTimer = 0.18;
    p.facingRight = tx >= Math.floor(p.x / TILE_SIZE);

    const grid = worldGridsRef.current[currentZone];
    const tile = grid[ty][tx];

    // 1. Wrench Mode Inspection
    if (playerStats.punchMode === 'wrench') {
      soundManager.playMine();
      if (onInspectTile) onInspectTile(tile, tx, ty);
      return;
    }

    // 2. Placing Block or Planting Seed from quickbar
    const heldSlot = playerStats.inventory[playerStats.heldSlotIndex];
    if (tile.block === 'empty' && !tile.tree && heldSlot && heldSlot.count > 0) {
      const item = heldSlot.item;

      if (item.category === 'seed') {
        // Plant seed tree on top of solid tile!
        const tileBelow = ty < WORLD_HEIGHT - 1 ? grid[ty + 1][tx] : null;
        if (tileBelow && tileBelow.block !== 'empty') {
          soundManager.playBlockPlace();
          tile.tree = {
            seedItemId: item.id,
            seedName: item.nameId || item.name,
            fruitItemId: item.id === 'seed_dirt' ? 'block_dirt' : item.id === 'seed_wood' ? 'block_wood' : 'block_amethyst',
            plantedAt: Date.now(),
            growDurationMs: 15000,
            fruitCount: 3,
            ready: false,
          };

          // Deduct 1 seed
          onUpdateStats(prev => {
            const inv = [...prev.inventory];
            if (inv[prev.heldSlotIndex]) {
              if (inv[prev.heldSlotIndex]!.count > 1) {
                inv[prev.heldSlotIndex]!.count -= 1;
              } else {
                inv[prev.heldSlotIndex] = null;
              }
            }
            return { ...prev, inventory: inv };
          });
          return;
        }
      } else if (item.id.startsWith('block_') || item.id === 'world_lock') {
        // Place solid block
        soundManager.playBlockPlace();
        let targetBlock: BlockType = 'dirt';
        if (item.id === 'block_rock') targetBlock = 'cave_rock';
        else if (item.id === 'block_wood') targetBlock = 'wood_block';
        else if (item.id === 'block_lava') targetBlock = 'lava';
        else if (item.id === 'block_amethyst') targetBlock = 'amethyst_block';
        else if (item.id === 'world_lock') targetBlock = 'world_lock';

        tile.block = targetBlock;
        tile.hitsTaken = 0;
        tile.maxHits = targetBlock === 'world_lock' ? 99999 : 4;

        // Deduct 1 block
        onUpdateStats(prev => {
          const inv = [...prev.inventory];
          if (inv[prev.heldSlotIndex]) {
            if (inv[prev.heldSlotIndex]!.count > 1) {
              inv[prev.heldSlotIndex]!.count -= 1;
            } else {
              inv[prev.heldSlotIndex] = null;
            }
          }
          return { ...prev, inventory: inv };
        });
        return;
      }
    }

    // 3. Tree Harvest
    if (tile.tree) {
      if (tile.tree.ready) {
        soundManager.playBlockBreak();
        const fruitId = tile.tree.fruitItemId;
        const count = tile.tree.fruitCount;
        const fruitItem = ITEMS_DATABASE[fruitId] || ITEMS_DATABASE['block_dirt'];

        onItemAcquired(fruitId, count, fruitItem.rarity);

        // Spawn gem drops
        spawnGems(tx * TILE_SIZE + 16, ty * TILE_SIZE + 16, 3);
        tile.tree = undefined;

        onUpdateStats(prev => ({
          ...prev,
          xp: prev.xp + 30,
          statsRecord: { ...prev.statsRecord, treesChopped: prev.statsRecord.treesChopped + 1 },
        }));
      } else {
        soundManager.playBlockCrack();
      }
      return;
    }

    // 4. White Door Entry
    if (tile.block === 'main_door' && tile.doorDestination) {
      soundManager.playLevelUp();
      onZoneChange(tile.doorDestination);
      return;
    }

    // 5. Punch & Break Solid Block
    if (tile.block !== 'empty' && tile.block !== 'bedrock' && tile.block !== 'world_lock') {
      tile.hitsTaken += 1;
      soundManager.playBlockCrack();

      // Check if block shatters
      if (tile.hitsTaken >= tile.maxHits) {
        soundManager.playBlockBreak();

        // Spawn block drops & floating gems!
        const dropItemId = tile.block === 'cave_rock' ? 'block_rock' : tile.block === 'wood_block' ? 'block_wood' : tile.block === 'amethyst_block' ? 'block_amethyst' : 'block_dirt';
        const item = ITEMS_DATABASE[dropItemId] || ITEMS_DATABASE['block_dirt'];

        onItemAcquired(dropItemId, 1, item.rarity);
        spawnGems(tx * TILE_SIZE + 16, ty * TILE_SIZE + 16, tile.block === 'amethyst_block' ? 6 : 2);

        tile.block = 'empty';
        tile.hitsTaken = 0;

        onUpdateStats(prev => ({
          ...prev,
          xp: prev.xp + 15,
          statsRecord: { ...prev.statsRecord, oresMined: prev.statsRecord.oresMined + 1 },
        }));
      }
    } else {
      soundManager.playPunch();
    }
  };

  const spawnGems = (x: number, y: number, count = 2) => {
    for (let i = 0; i < count; i++) {
      const val = Math.random() < 0.2 ? 5 : 1;
      dropsRef.current.push({
        id: `gem_${Date.now()}_${Math.random()}`,
        x: x + (Math.random() - 0.5) * 16,
        y: y - 8,
        vx: (Math.random() - 0.5) * 80,
        vy: -120 - Math.random() * 80,
        gemValue: val,
        count: 1,
        life: 20,
      });
    }
  };

  // Main 60fps Platformer Simulation Loop
  useEffect(() => {
    let animId: number;
    let wasJumpDown = false;
    let wasActionDown = false;

    const loop = (timestamp: number) => {
      const rawDt = (timestamp - lastTimeRef.current) / 1000;
      lastTimeRef.current = timestamp;
      const dt = Math.min(rawDt, 0.05);

      const p = playerRef.current;
      const keys = keysHeld.current;
      const grid = worldGridsRef.current[currentZone];

      // Horizontal movement input
      let moveDir = 0;
      if (keys['arrowleft'] || keys['a'] || movementInput.x < -0.2) moveDir -= 1;
      if (keys['arrowright'] || keys['d'] || movementInput.x > 0.2) moveDir += 1;

      const runSpeed = 160;
      p.vx = moveDir * runSpeed;
      if (moveDir !== 0) {
        p.facingRight = moveDir > 0;
      }

      // Jump Input (Growtopia double jump)
      const jumpHeld = keys['arrowup'] || keys['w'] || keys[' '] || isJumpPressed;
      if (jumpHeld && !wasJumpDown) {
        if (p.isGrounded) {
          p.vy = -380;
          p.isGrounded = false;
          p.jumpCount = 1;
          soundManager.playJump();
        } else if (p.jumpCount < 2) {
          // Double jump!
          p.vy = -340;
          p.jumpCount = 2;
          soundManager.playJump();
        }
      }
      wasJumpDown = jumpHeld;

      // Punch Key (K / Space / Action button)
      const actionHeld = keys['k'] || isActionPressed;
      if (actionHeld && !wasActionDown) {
        // Punch block directly in front of player
        const targetTileX = Math.floor((p.x + (p.facingRight ? p.width + 12 : -12)) / TILE_SIZE);
        const targetTileY = Math.floor((p.y + p.height / 2) / TILE_SIZE);
        if (targetTileX >= 0 && targetTileX < WORLD_WIDTH && targetTileY >= 0 && targetTileY < WORLD_HEIGHT) {
          triggerTileAction(targetTileX, targetTileY);
        }
      }
      wasActionDown = actionHeld;

      // Update punch anim timer
      if (p.punchTimer > 0) {
        p.punchTimer -= dt;
        p.punchAnim = Math.max(0, p.punchTimer / 0.18);
      }

      // Apply Gravity
      p.vy += 850 * dt;
      p.vy = Math.min(p.vy, 600); // Terminal velocity

      // --- TILE COLLISION RESOLUTION ---
      // Horizontal physics & collision
      p.x += p.vx * dt;
      // Boundaries
      p.x = Math.max(0, Math.min((WORLD_WIDTH - 1) * TILE_SIZE, p.x));

      // Vertical physics & collision
      p.y += p.vy * dt;
      p.isGrounded = false;

      // Check ground collision
      const checkMinTx = Math.floor(p.x / TILE_SIZE);
      const checkMaxTx = Math.floor((p.x + p.width) / TILE_SIZE);
      const footTileY = Math.floor((p.y + p.height) / TILE_SIZE);
      const headTileY = Math.floor(p.y / TILE_SIZE);

      if (footTileY >= 0 && footTileY < WORLD_HEIGHT) {
        for (let tx = checkMinTx; tx <= checkMaxTx; tx++) {
          if (tx >= 0 && tx < WORLD_WIDTH) {
            const block = grid[footTileY][tx].block;
            if (block !== 'empty' && block !== 'main_door' && p.vy >= 0) {
              const tileTopY = footTileY * TILE_SIZE;
              if (p.y + p.height >= tileTopY && p.y + p.height <= tileTopY + 14) {
                p.y = tileTopY - p.height;
                p.vy = 0;
                p.isGrounded = true;
                p.jumpCount = 0;
                break;
              }
            }
          }
        }
      }

      // Check ceiling collision
      if (headTileY >= 0 && headTileY < WORLD_HEIGHT && p.vy < 0) {
        for (let tx = checkMinTx; tx <= checkMaxTx; tx++) {
          if (tx >= 0 && tx < WORLD_WIDTH) {
            const block = grid[headTileY][tx].block;
            if (block !== 'empty' && block !== 'main_door') {
              p.y = (headTileY + 1) * TILE_SIZE;
              p.vy = 0;
              break;
            }
          }
        }
      }

      // Update Seed Tree growth timers
      const now = Date.now();
      for (let y = 0; y < WORLD_HEIGHT; y++) {
        for (let x = 0; x < WORLD_WIDTH; x++) {
          const t = grid[y][x].tree;
          if (t && !t.ready) {
            if (now - t.plantedAt >= t.growDurationMs) {
              t.ready = true;
            }
          }
        }
      }

      // Update Floating Gems & Drops (Gravity & Magnet towards player)
      for (let i = dropsRef.current.length - 1; i >= 0; i--) {
        const drop = dropsRef.current[i];
        drop.x += drop.vx * dt;
        drop.y += drop.vy * dt;
        drop.vy += 450 * dt; // Gem gravity

        // Magnet towards player if near
        const pCenterX = p.x + p.width / 2;
        const pCenterY = p.y + p.height / 2;
        const distToPlayer = Math.hypot(pCenterX - drop.x, pCenterY - drop.y);

        if (distToPlayer < 64) {
          // Magnet pull!
          drop.vx += ((pCenterX - drop.x) / distToPlayer) * 350 * dt;
          drop.vy += ((pCenterY - drop.y) / distToPlayer) * 350 * dt;
        }

        // Collect drop if touching player
        if (distToPlayer < 20) {
          soundManager.playGemCollect();
          const gemsGained = drop.gemValue || 1;

          onUpdateStats(prev => ({
            ...prev,
            gems: prev.gems + gemsGained,
          }));

          dropsRef.current.splice(i, 1);
        }
      }

      // --- RENDER PASS ---
      const canvas = canvasRef.current;
      if (canvas) {
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.imageSmoothingEnabled = false;

          // Camera setup (smoothly centered on player)
          const camX = Math.round(canvas.width / 2 - (p.x + p.width / 2));
          const camY = Math.round(canvas.height / 2 - (p.y + p.height / 2));

          // 1. Draw Sky & Clouds
          drawSkyAndBackdrop(ctx, currentZone, camX, camY, canvas.width, canvas.height, timestamp / 1000);

          ctx.save();
          ctx.translate(camX, camY);

          // 2. Draw Wallpapers
          for (let y = 0; y < WORLD_HEIGHT; y++) {
            for (let x = 0; x < WORLD_WIDTH; x++) {
              drawWallpaper(ctx, grid[y][x], x * TILE_SIZE, y * TILE_SIZE);
            }
          }

          // 3. Draw Foreground Blocks & Seed Trees
          for (let y = 0; y < WORLD_HEIGHT; y++) {
            for (let x = 0; x < WORLD_WIDTH; x++) {
              drawGrowtopiaBlock(ctx, grid[y][x], x, y, grid, timestamp / 1000);
            }
          }

          // 4. Draw Floating Gems & Drops
          drawFloatingDrops(ctx, dropsRef.current, timestamp / 1000);

          // 5. Draw Growtopia Avatar
          drawGrowtopiaPlayer(
            ctx,
            p.x,
            p.y,
            p.facingRight,
            Math.abs(p.vx) > 10,
            p.isGrounded,
            p.punchAnim,
            playerStats.punchMode,
            playerStats.chatBubble,
            timestamp / 1000
          );

          ctx.restore();
        }
      }

      animId = requestAnimationFrame(loop);
    };

    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [currentZone, playerStats.punchMode, playerStats.heldSlotIndex, playerStats.inventory, playerStats.chatBubble, isActionPressed, isJumpPressed, movementInput]);

  // Window resize handler
  useEffect(() => {
    const handleResize = () => {
      if (canvasRef.current) {
        canvasRef.current.width = window.innerWidth;
        canvasRef.current.height = window.innerHeight;
      }
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <div className="relative w-full h-full overflow-hidden select-none">
      <canvas
        ref={canvasRef}
        onPointerDown={e => handleCanvasInteraction(e.clientX, e.clientY)}
        className="w-full h-full block pixel-canvas touch-none cursor-crosshair"
      />
    </div>
  );
};
