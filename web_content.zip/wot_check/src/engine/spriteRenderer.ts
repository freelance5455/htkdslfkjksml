/**
 * Growtopia-Style 2D Side-Scrolling Pixel Art Renderer
 * Recreates the iconic Growtopia visual aesthetic:
 * - Chibi platformer avatar with punch & jump frames
 * - Block cracking overlays, seed trees, and floating bouncy gems
 * - Sky with moving clouds, cave wallpaper, and White Doors / World Locks
 */

import { WorldTile, FloatingDrop, Particle, ZoneId } from '../types/game';

export const TILE_SIZE = 32;

// Draw Sky & Clouds
export function drawSkyAndBackdrop(
  ctx: CanvasRenderingContext2D,
  zone: ZoneId,
  camX: number,
  camY: number,
  canvasW: number,
  canvasH: number,
  time: number
) {
  if (zone === 'starter_village') {
    // Growtopia sunny daylight sky gradient
    const grad = ctx.createLinearGradient(0, 0, 0, canvasH);
    grad.addColorStop(0, '#38bdf8');
    grad.addColorStop(0.5, '#7dd3fc');
    grad.addColorStop(1, '#bae6fd');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, canvasW, canvasH);

    // Warm pixel sun in top corner
    ctx.fillStyle = '#fef08a';
    ctx.beginPath();
    ctx.arc(canvasW - 80, 80, 36, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#facc15';
    ctx.beginPath();
    ctx.arc(canvasW - 80, 80, 30, 0, Math.PI * 2);
    ctx.fill();

    // Floating Growtopia pixel clouds with parallax
    const cloudOffset = (time * 12) % (canvasW + 300);
    drawCloud(ctx, (canvasW - cloudOffset), 60);
    drawCloud(ctx, (canvasW * 1.5 - cloudOffset * 0.8) % canvasW, 110);
  } else if (zone === 'mystic_forest') {
    // Emerald misty forest canopy
    const grad = ctx.createLinearGradient(0, 0, 0, canvasH);
    grad.addColorStop(0, '#064e3b');
    grad.addColorStop(0.6, '#065f46');
    grad.addColorStop(1, '#022c22');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, canvasW, canvasH);
  } else if (zone === 'crystal_cave') {
    // Deep dark purple-blue cavern background
    const grad = ctx.createLinearGradient(0, 0, 0, canvasH);
    grad.addColorStop(0, '#0f172a');
    grad.addColorStop(1, '#1e1b4b');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, canvasW, canvasH);
  } else {
    // Ancient ruins mystical dusk
    const grad = ctx.createLinearGradient(0, 0, 0, canvasH);
    grad.addColorStop(0, '#311042');
    grad.addColorStop(0.7, '#1f1329');
    grad.addColorStop(1, '#0f051d');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, canvasW, canvasH);
  }
}

function drawCloud(ctx: CanvasRenderingContext2D, x: number, y: number) {
  ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
  ctx.fillRect(x, y + 10, 80, 20);
  ctx.fillRect(x + 12, y, 56, 30);
  ctx.fillRect(x + 24, y - 10, 32, 40);
}

// Draw Background Wallpapers (Behind player and blocks)
export function drawWallpaper(
  ctx: CanvasRenderingContext2D,
  tile: WorldTile,
  px: number,
  py: number
) {
  if (tile.background === 'cave_bg') {
    ctx.fillStyle = '#1e293b';
    ctx.fillRect(px, py, TILE_SIZE, TILE_SIZE);
    ctx.strokeStyle = '#0f172a';
    ctx.lineWidth = 1;
    ctx.strokeRect(px + 0.5, py + 0.5, TILE_SIZE - 1, TILE_SIZE - 1);
  } else if (tile.background === 'wood_bg') {
    ctx.fillStyle = '#451a03';
    ctx.fillRect(px, py, TILE_SIZE, TILE_SIZE);
    ctx.fillStyle = '#291002';
    ctx.fillRect(px + 15, py, 2, TILE_SIZE);
    ctx.fillRect(px, py + 15, TILE_SIZE, 2);
  } else if (tile.background === 'ruin_bg') {
    ctx.fillStyle = '#261b2e';
    ctx.fillRect(px, py, TILE_SIZE, TILE_SIZE);
    ctx.strokeStyle = '#180e20';
    ctx.strokeRect(px, py, TILE_SIZE, TILE_SIZE);
  }
}

// Draw Foreground Block
export function drawGrowtopiaBlock(
  ctx: CanvasRenderingContext2D,
  tile: WorldTile,
  tx: number,
  ty: number,
  worldGrid: WorldTile[][],
  time: number
) {
  const px = tx * TILE_SIZE;
  const py = ty * TILE_SIZE;

  // Draw Tree on empty tile if planted
  if (tile.tree) {
    drawSeedTree(ctx, tile.tree, px, py, time);
  }

  if (tile.block === 'empty') return;

  switch (tile.block) {
    case 'dirt': {
      // Classic Growtopia Dirt with lush green grass on top if air above
      const isTopGrass = ty > 0 && worldGrid[ty - 1][tx]?.block === 'empty';
      ctx.fillStyle = '#78350f'; // Rich brown soil
      ctx.fillRect(px, py, TILE_SIZE, TILE_SIZE);

      // Dirt pebble details
      ctx.fillStyle = '#572608';
      ctx.fillRect(px + 4, py + 12, 6, 5);
      ctx.fillRect(px + 18, py + 18, 5, 4);
      ctx.fillRect(px + 12, py + 24, 7, 4);
      ctx.fillStyle = '#9a4713';
      ctx.fillRect(px + 14, py + 8, 4, 3);

      if (isTopGrass) {
        // Vibrant green grass fringe
        ctx.fillStyle = '#16a34a';
        ctx.fillRect(px, py, TILE_SIZE, 6);
        ctx.fillStyle = '#22c55e';
        ctx.fillRect(px + 1, py, TILE_SIZE - 2, 3);
        // Grass overhang blades
        ctx.fillStyle = '#15803d';
        ctx.fillRect(px + 3, py + 6, 3, 3);
        ctx.fillRect(px + 11, py + 6, 4, 4);
        ctx.fillRect(px + 21, py + 6, 3, 3);
      }
      break;
    }
    case 'cave_rock': {
      // Grey stone block with chisel bevels
      ctx.fillStyle = '#475569';
      ctx.fillRect(px, py, TILE_SIZE, TILE_SIZE);
      ctx.fillStyle = '#64748b';
      ctx.fillRect(px + 2, py + 2, TILE_SIZE - 4, TILE_SIZE - 4);
      ctx.fillStyle = '#334155';
      ctx.fillRect(px + 6, py + 6, 10, 8);
      ctx.fillRect(px + 18, py + 16, 9, 8);
      ctx.fillStyle = '#94a3b8';
      ctx.fillRect(px + 2, py + 2, TILE_SIZE - 4, 2);
      break;
    }
    case 'iron_block': {
      // Metallic iron block with silver rivets
      ctx.fillStyle = '#334155';
      ctx.fillRect(px, py, TILE_SIZE, TILE_SIZE);
      ctx.fillStyle = '#64748b';
      ctx.fillRect(px + 2, py + 2, 28, 28);
      ctx.fillStyle = '#cbd5e1';
      ctx.fillRect(px + 3, py + 3, 26, 2);
      // Rivets in 4 corners
      ctx.fillStyle = '#f8fafc';
      ctx.fillRect(px + 4, py + 4, 3, 3);
      ctx.fillRect(px + 25, py + 4, 3, 3);
      ctx.fillRect(px + 4, py + 25, 3, 3);
      ctx.fillRect(px + 25, py + 25, 3, 3);
      break;
    }
    case 'gold_block': {
      // Radiant golden ingot block
      ctx.fillStyle = '#b45309';
      ctx.fillRect(px, py, TILE_SIZE, TILE_SIZE);
      ctx.fillStyle = '#facc15';
      ctx.fillRect(px + 2, py + 2, 28, 28);
      ctx.fillStyle = '#fef08a';
      ctx.fillRect(px + 4, py + 4, 24, 3);
      ctx.fillStyle = '#eab308';
      ctx.fillRect(px + 6, py + 12, 20, 12);
      break;
    }
    case 'amethyst_block': {
      // Glowing amethyst block
      ctx.fillStyle = '#4c1d95';
      ctx.fillRect(px, py, TILE_SIZE, TILE_SIZE);
      ctx.fillStyle = '#7c3aed';
      ctx.fillRect(px + 2, py + 2, 28, 28);
      ctx.fillStyle = '#c084fc';
      ctx.fillRect(px + 6, py + 6, 8, 8);
      ctx.fillRect(px + 18, py + 14, 8, 8);
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(px + 8, py + 8, 3, 3);
      break;
    }
    case 'crystal_block': {
      // Pulsating cyan celestial crystal block
      const pulse = (Math.sin(time * 4 + tx + ty) + 1) * 0.5;
      ctx.fillStyle = '#0369a1';
      ctx.fillRect(px, py, TILE_SIZE, TILE_SIZE);
      ctx.fillStyle = `rgba(56, 189, 248, ${0.8 + pulse * 0.2})`;
      ctx.fillRect(px + 2, py + 2, 28, 28);
      ctx.fillStyle = '#e0f2fe';
      ctx.fillRect(px + 6, py + 6, 10, 10);
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(px + 8, py + 8, 4, 4);
      break;
    }
    case 'wood_block': {
      // Polished wooden board block
      ctx.fillStyle = '#78350f';
      ctx.fillRect(px, py, TILE_SIZE, TILE_SIZE);
      ctx.fillStyle = '#b45309';
      ctx.fillRect(px + 2, py + 2, 28, 13);
      ctx.fillRect(px + 2, py + 17, 28, 13);
      ctx.fillStyle = '#92400e';
      ctx.fillRect(px + 6, py + 6, 4, 4);
      ctx.fillRect(px + 20, py + 22, 4, 4);
      break;
    }
    case 'lava': {
      // Animated bubbling lava block
      const wave = Math.sin(time * 5 + tx * 3) * 2;
      ctx.fillStyle = '#991b1b';
      ctx.fillRect(px, py, TILE_SIZE, TILE_SIZE);
      ctx.fillStyle = '#ea580c';
      ctx.fillRect(px + 2, py + 2 + wave, 28, 28 - wave);
      ctx.fillStyle = '#facc15';
      ctx.fillRect(px + 6, py + 8 + wave, 8, 5);
      ctx.fillRect(px + 18, py + 16 - wave, 8, 6);
      break;
    }
    case 'main_door': {
      // Iconic Growtopia White Exit Door
      ctx.fillStyle = '#475569';
      ctx.fillRect(px + 2, py, 28, TILE_SIZE);
      // White door panel
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(px + 4, py + 2, 24, TILE_SIZE - 2);
      ctx.fillStyle = '#f1f5f9';
      ctx.fillRect(px + 6, py + 6, 20, 10);
      ctx.fillRect(px + 6, py + 18, 20, 10);
      // Golden brass door knob
      ctx.fillStyle = '#f59e0b';
      ctx.beginPath();
      ctx.arc(px + 8, py + 16, 2.5, 0, Math.PI * 2);
      ctx.fill();
      // "EXIT" / Portal Sign on top
      ctx.fillStyle = '#dc2626';
      ctx.fillRect(px + 5, py + 3, 22, 5);
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 5px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(tile.doorLabel ? tile.doorLabel.slice(0, 6) : 'EXIT', px + 16, py + 7);
      break;
    }
    case 'world_lock': {
      // Growtopia Golden World Lock 🔒
      ctx.fillStyle = '#78350f';
      ctx.fillRect(px + 2, py + 2, 28, 28);
      // Golden Lock Shackle & Body
      ctx.fillStyle = '#facc15';
      ctx.fillRect(px + 6, py + 10, 20, 18);
      ctx.fillStyle = '#fef08a';
      ctx.fillRect(px + 8, py + 12, 16, 4);
      // Silver shackle loop
      ctx.fillStyle = '#e2e8f0';
      ctx.fillRect(px + 10, py + 4, 12, 7);
      ctx.fillStyle = '#78350f';
      ctx.fillRect(px + 13, py + 6, 6, 5);
      // Keyhole
      ctx.fillStyle = '#451a03';
      ctx.fillRect(px + 14, py + 18, 4, 5);
      break;
    }
    case 'bedrock': {
      // Indestructible black bedrock
      ctx.fillStyle = '#09090b';
      ctx.fillRect(px, py, TILE_SIZE, TILE_SIZE);
      ctx.fillStyle = '#27272a';
      ctx.fillRect(px + 4, py + 4, 24, 24);
      ctx.fillStyle = '#52525b';
      ctx.fillRect(px + 8, py + 8, 6, 6);
      ctx.fillRect(px + 18, py + 18, 6, 6);
      break;
    }
    case 'ruin_brick': {
      // Ancient etched hieroglyphic stone
      ctx.fillStyle = '#3f3f46';
      ctx.fillRect(px, py, TILE_SIZE, TILE_SIZE);
      ctx.fillStyle = '#52525b';
      ctx.fillRect(px + 2, py + 2, 28, 28);
      // Cyan glowing rune
      ctx.fillStyle = '#22d3ee';
      ctx.fillRect(px + 8, py + 12, 16, 2);
      ctx.fillRect(px + 15, py + 8, 2, 16);
      break;
    }
  }

  // Pixel Art HD finish shared by all procedural world textures.
  if (tile.block !== 'empty') drawHdTileFinish(ctx, px, py, tx, ty, time);

  // Draw Block Cracking Overlay if damaged!
  if (tile.hitsTaken > 0 && tile.maxHits < 99999) {
    const crackRatio = tile.hitsTaken / tile.maxHits;
    drawBlockCracks(ctx, px, py, crackRatio);
  }
}

// Shared Pixel Art HD finishing pass: crisp bevels and stable pixel-grain details.
function drawHdTileFinish(ctx: CanvasRenderingContext2D, px: number, py: number, tx: number, ty: number, time: number) {
  ctx.save();
  ctx.globalAlpha = 0.34;
  ctx.fillStyle = '#fff4cf';
  ctx.fillRect(px + 1, py + 1, TILE_SIZE - 2, 2);
  ctx.fillRect(px + 1, py + 1, 2, TILE_SIZE - 2);
  ctx.fillStyle = '#100d1b';
  ctx.fillRect(px + 1, py + TILE_SIZE - 3, TILE_SIZE - 2, 2);
  ctx.fillRect(px + TILE_SIZE - 3, py + 1, 2, TILE_SIZE - 2);
  ctx.globalAlpha = 0.22;
  const seed = Math.abs((tx * 374761393 + ty * 668265263) | 0);
  for (let i = 0; i < 5; i++) {
    const n = (seed + i * 127) % 997;
    const sx = px + 4 + (n % 24);
    const sy = py + 5 + (Math.floor(n / 24) % 23);
    ctx.fillStyle = i % 2 === 0 ? '#fff7d6' : '#171326';
    ctx.fillRect(sx, sy, i % 3 === 0 ? 2 : 1, 1);
  }
  const glint = (Math.sin(time * 1.4 + tx * 0.7 + ty * 0.4) + 1) * 0.5;
  ctx.globalAlpha = 0.08 + glint * 0.10;
  ctx.fillStyle = '#fff8df';
  ctx.fillRect(px + 5, py + 4, 3, 1);
  ctx.restore();
}

// Draw Growtopia Block Cracking Lines (Stages 1, 2, 3)
function drawBlockCracks(
  ctx: CanvasRenderingContext2D,
  px: number,
  py: number,
  ratio: number
) {
  ctx.save();
  ctx.strokeStyle = '#000000';
  ctx.lineWidth = 2;
  ctx.beginPath();

  // Stage 1 crack
  ctx.moveTo(px + 8, py + 4);
  ctx.lineTo(px + 16, py + 14);
  ctx.lineTo(px + 12, py + 24);

  // Stage 2 crack
  if (ratio >= 0.4) {
    ctx.moveTo(px + 16, py + 14);
    ctx.lineTo(px + 26, py + 18);
    ctx.lineTo(px + 22, py + 28);
  }

  // Stage 3 heavy fractures
  if (ratio >= 0.7) {
    ctx.moveTo(px + 4, py + 20);
    ctx.lineTo(px + 12, py + 24);
    ctx.lineTo(px + 28, py + 8);
  }

  ctx.stroke();

  // White highlight crack lines
  ctx.strokeStyle = '#ffffff';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(px + 9, py + 4);
  ctx.lineTo(px + 17, py + 14);
  if (ratio >= 0.4) {
    ctx.lineTo(px + 27, py + 18);
  }
  ctx.stroke();
  ctx.restore();
}

// Draw Growtopia Seed Trees
function drawSeedTree(
  ctx: CanvasRenderingContext2D,
  tree: { seedName: string; fruitItemId: string; ready: boolean },
  px: number,
  py: number,
  time: number
) {
  const sway = Math.sin(time * 3 + px) * 2;

  // Tree Trunk
  ctx.fillStyle = '#78350f';
  ctx.fillRect(px + 13, py + 10, 6, 22);

  // Tree Foliage Crown
  ctx.fillStyle = '#15803d';
  ctx.beginPath();
  ctx.arc(px + 16 + sway, py + 6, 14, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = '#22c55e';
  ctx.beginPath();
  ctx.arc(px + 14 + sway, py + 4, 10, 0, Math.PI * 2);
  ctx.fill();

  // Hanging Fruits / Blocks if ready!
  if (tree.ready) {
    ctx.fillStyle = '#facc15';
    // Hanging fruit 1
    ctx.fillRect(px + 8 + sway, py + 8, 6, 6);
    // Hanging fruit 2
    ctx.fillRect(px + 18 + sway, py + 8, 6, 6);
    // Shimmer
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(px + 9 + sway, py + 9, 2, 2);
    ctx.fillRect(px + 19 + sway, py + 9, 2, 2);
  } else {
    // Little sprout bud
    ctx.fillStyle = '#fef08a';
    ctx.fillRect(px + 14 + sway, py + 2, 4, 4);
  }
}

// Draw Floating Gems & Drops with Growtopia Bouncy Physics
export function drawFloatingDrops(
  ctx: CanvasRenderingContext2D,
  drops: FloatingDrop[],
  time: number
) {
  for (const drop of drops) {
    const bob = Math.sin(time * 8 + drop.x) * 3;
    const dy = drop.y + bob;

    if (drop.gemValue) {
      // Classic Growtopia Gem (Faceted diamond shape)
      let color = '#facc15'; // 1 = Yellow
      if (drop.gemValue >= 50) color = '#38bdf8'; // 50 = Blue
      else if (drop.gemValue >= 10) color = '#22c55e'; // 10 = Green
      else if (drop.gemValue >= 5) color = '#ef4444'; // 5 = Red

      ctx.save();
      ctx.fillStyle = color;
      ctx.beginPath();
      ctx.moveTo(drop.x + 8, dy);
      ctx.lineTo(drop.x + 14, dy + 6);
      ctx.lineTo(drop.x + 8, dy + 14);
      ctx.lineTo(drop.x + 2, dy + 6);
      ctx.closePath();
      ctx.fill();

      // Shimmer highlight
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(drop.x + 6, dy + 3, 3, 3);
      ctx.restore();
    } else {
      // Floating miniature block drop
      ctx.fillStyle = '#78350f';
      ctx.fillRect(drop.x + 2, dy + 2, 12, 12);
      ctx.fillStyle = '#22c55e';
      ctx.fillRect(drop.x + 2, dy + 2, 12, 3);
      ctx.strokeStyle = '#facc15';
      ctx.strokeRect(drop.x + 2, dy + 2, 12, 12);
    }
  }
}

// Draw Growtopia Chibi Avatar (Side-scrolling platformer with punch & jump)
export function drawGrowtopiaPlayer(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  facingRight: boolean,
  isMoving: boolean,
  isGrounded: boolean,
  punchAnim: number, // 0 to 1
  punchMode: 'fist' | 'wrench',
  chatBubble: { text: string; timer: number } | null | undefined,
  time: number
) {
  ctx.save();

  // Flip horizontally if facing left
  if (!facingRight) {
    ctx.translate(x + 24, y);
    ctx.scale(-1, 1);
    ctx.translate(-x, -y);
  }

  const walkBob = isMoving && isGrounded ? Math.sin(time * 16) * 2 : 0;
  const legSwing = isMoving && isGrounded ? Math.sin(time * 16) * 4 : 0;

  // Shadow on ground
  if (isGrounded) {
    ctx.fillStyle = 'rgba(0, 0, 0, 0.35)';
    ctx.beginPath();
    ctx.ellipse(x + 12, y + 30, 10, 4, 0, 0, Math.PI * 2);
    ctx.fill();
  }

  // Pixel Art HD silhouette contour.
  ctx.fillStyle = '#241b2b';
  ctx.fillRect(x + 5, y + 1 + walkBob, 17, 14);
  ctx.fillRect(x + 6, y + 12 + walkBob, 15, 11);
  ctx.fillRect(x + 6, y + 20, 14, 11);

  // --- LEGS & SHOES ---
  ctx.fillStyle = '#1e293b'; // Dark blue trousers
  if (!isGrounded) {
    // Jump pose: legs tucked
    ctx.fillRect(x + 6, y + 20, 6, 8);
    ctx.fillRect(x + 14, y + 18, 6, 7);
    ctx.fillStyle = '#dc2626'; // Red sneakers
    ctx.fillRect(x + 6, y + 26, 7, 4);
    ctx.fillRect(x + 14, y + 23, 7, 4);
  } else {
    // Walking / Idle
    ctx.fillRect(x + 7 - legSwing, y + 20, 5, 8);
    ctx.fillRect(x + 14 + legSwing, y + 20, 5, 8);
    ctx.fillStyle = '#dc2626'; // Red sneakers
    ctx.fillRect(x + 7 - legSwing, y + 27, 7, 4);
    ctx.fillRect(x + 14 + legSwing, y + 27, 7, 4);
  }

  // --- BODY / SHIRT ---
  ctx.fillStyle = '#0284c7'; // Cyan Growtopia shirt
  ctx.fillRect(x + 7, y + 12 + walkBob, 12, 10);
  ctx.fillStyle = '#67e8f9';
  ctx.fillRect(x + 8, y + 13 + walkBob, 7, 2);
  ctx.fillStyle = '#0369a1';
  ctx.fillRect(x + 7, y + 19 + walkBob, 12, 3); // Belt

  // --- CHIBI HEAD (Big Growtopia head) ---
  ctx.fillStyle = '#fde047'; // Skin tone
  ctx.fillRect(x + 6, y + 2 + walkBob, 15, 12);

  // Big cute Growtopia eye
  ctx.fillStyle = '#0f172a';
  ctx.fillRect(x + 15, y + 6 + walkBob, 4, 5);
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(x + 16, y + 6 + walkBob, 2, 2);

  // Smile
  ctx.fillStyle = '#b45309';
  ctx.fillRect(x + 14, y + 11 + walkBob, 3, 1.5);

  // Brown Spiky Hair
  ctx.fillStyle = '#78350f';
  ctx.fillRect(x + 5, y - 2 + walkBob, 17, 6);
  ctx.fillRect(x + 4, y + 1 + walkBob, 4, 6);
  ctx.fillRect(x + 8, y - 5 + walkBob, 6, 4); // Spikes
  ctx.fillRect(x + 15, y - 4 + walkBob, 5, 3);
  ctx.fillStyle = '#b77945';
  ctx.fillRect(x + 8, y - 4 + walkBob, 5, 2);

  // --- PUNCHING ARM / HAND ---
  if (punchAnim > 0) {
    // Extended punching fist!
    const punchReach = punchAnim * 14;
    ctx.fillStyle = '#0284c7';
    ctx.fillRect(x + 14, y + 14 + walkBob, 6 + punchReach, 5); // Arm
    ctx.fillStyle = punchMode === 'wrench' ? '#94a3b8' : '#fde047';
    ctx.fillRect(x + 20 + punchReach, y + 13 + walkBob, 6, 6); // Hand/Fist

    if (punchMode === 'wrench') {
      // Wrench in hand
      ctx.fillStyle = '#64748b';
      ctx.fillRect(x + 24 + punchReach, y + 10 + walkBob, 6, 12);
      ctx.fillStyle = '#ef4444';
      ctx.fillRect(x + 23 + punchReach, y + 13 + walkBob, 3, 6);
    } else {
      // Punch swoosh impact lines
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(x + 24 + punchReach, y + 16 + walkBob, 8, -Math.PI / 3, Math.PI / 3);
      ctx.stroke();
    }
  } else {
    // Resting arm
    ctx.fillStyle = '#0284c7';
    ctx.fillRect(x + 12, y + 14 + walkBob, 4, 6);
    ctx.fillStyle = punchMode === 'wrench' ? '#94a3b8' : '#fde047';
    ctx.fillRect(x + 12, y + 18 + walkBob, 4, 4);
  }

  ctx.restore();

  // --- GROWTOPIA CHAT SPEECH BUBBLE ---
  if (chatBubble && chatBubble.timer > 0) {
    ctx.save();
    ctx.font = 'bold 11px sans-serif';
    const textWidth = ctx.measureText(chatBubble.text).width;
    const bubbleW = textWidth + 16;
    const bubbleH = 22;
    const bx = x + 12 - bubbleW / 2;
    const by = y - bubbleH - 12;

    // White rounded speech bubble
    ctx.fillStyle = '#ffffff';
    ctx.strokeStyle = '#0f172a';
    ctx.lineWidth = 2;

    ctx.beginPath();
    ctx.roundRect(bx, by, bubbleW, bubbleH, 6);
    ctx.fill();
    ctx.stroke();

    // Little tail pointing to player
    ctx.beginPath();
    ctx.moveTo(x + 10, by + bubbleH);
    ctx.lineTo(x + 12, by + bubbleH + 6);
    ctx.lineTo(x + 16, by + bubbleH);
    ctx.fillStyle = '#ffffff';
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(x + 10, by + bubbleH);
    ctx.lineTo(x + 12, by + bubbleH + 6);
    ctx.lineTo(x + 16, by + bubbleH);
    ctx.stroke();

    // Text inside bubble
    ctx.fillStyle = '#0f172a';
    ctx.textAlign = 'center';
    ctx.fillText(chatBubble.text, x + 12, by + 15);
    ctx.restore();
  }
}
