import React from 'react';
import { Quest, PlayerStats } from '../types/game';
import { ITEMS_DATABASE, RARITY_CONFIG } from '../data/items';
import { generateItemHash } from '../services/marketplaceService';
import { soundManager } from '../audio/soundManager';
import { X, Scroll, Award, CheckCircle2 } from 'lucide-react';

interface QuestModalProps {
  quests: Quest[];
  playerStats: PlayerStats;
  onClose: () => void;
  onUpdateStats: (updater: (prev: PlayerStats) => PlayerStats) => void;
  onUpdateQuests: (updater: (prev: Quest[]) => Quest[]) => void;
}

export const QuestModal: React.FC<QuestModalProps> = ({
  quests,
  onClose,
  onUpdateStats,
  onUpdateQuests,
}) => {
  const handleClaim = (questId: string) => {
    const quest = quests.find(q => q.id === questId);
    if (!quest || !quest.completed || quest.claimed) return;

    soundManager.playLevelUp();

    onUpdateQuests(prev =>
      prev.map(q => (q.id === questId ? { ...q, claimed: true } : q))
    );

    onUpdateStats(prev => {
      const inv = [...prev.inventory];

      // Grant reward items
      if (quest.rewardItems) {
        quest.rewardItems.forEach(rw => {
          const item = ITEMS_DATABASE[rw.itemId];
          if (item) {
            const emptyIdx = inv.findIndex(s => s === null);
            if (emptyIdx !== -1) {
              inv[emptyIdx] = {
                item,
                count: rw.count,
                hash: generateItemHash(item.id),
                obtainedAt: Date.now(),
              };
            }
          }
        });
      }

      return {
        ...prev,
        gold: prev.gold + quest.rewardGold,
        xp: prev.xp + quest.rewardXp,
        inventory: inv,
      };
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/65 backdrop-blur-xs select-none">
      <div className="relative w-full max-w-2xl bg-[#154360] border-4 border-[#2980b9] rounded-2xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-3.5 bg-[#1b4f72] border-b-2 border-[#2874a6]">
          <div className="flex items-center gap-2">
            <span className="text-xl">📜</span>
            <div>
              <h2 className="font-pixel text-base font-extrabold text-white tracking-wider">
                GROWTOPIA ACHIEVEMENTS & QUESTS
              </h2>
              <span className="text-[10px] text-[#f9e79f] font-semibold">Tugas & Hadiah Gems Petualang</span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-[#c0392b] hover:bg-[#e74c3c] border border-[#f1948a] text-white flex items-center justify-center font-bold cursor-pointer transition-transform active:scale-95"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quests List */}
        <div className="p-6 overflow-y-auto flex flex-col gap-3 max-h-[65vh]">
          {quests.map(quest => {
            const pct = Math.min(100, Math.round((quest.currentCount / quest.targetCount) * 100));

            return (
              <div
                key={quest.id}
                className={`p-4 rounded-xl border flex flex-col gap-3 transition-colors ${
                  quest.claimed
                    ? 'bg-slate-950/40 border-slate-800/60 opacity-60'
                    : quest.completed
                    ? 'bg-emerald-950/30 border-emerald-500/50'
                    : 'bg-slate-950/70 border-slate-800'
                }`}
              >
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <h3 className="font-pixel text-sm font-bold text-white">
                      {quest.title}
                    </h3>
                    <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                      {quest.description}
                    </p>
                  </div>

                  <div className="shrink-0 font-mono text-xs font-bold text-slate-400">
                    {quest.currentCount} / {quest.targetCount}
                  </div>
                </div>

                {/* Progress bar */}
                <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden border border-slate-700">
                  <div
                    className="h-full bg-emerald-500 transition-all duration-300"
                    style={{ width: `${pct}%` }}
                  />
                </div>

                {/* Rewards & Claim Button */}
                <div className="flex items-center justify-between pt-2 border-t border-slate-800/60">
                  <div className="flex items-center gap-3 text-xs">
                    <span className="text-slate-400">Hadiah:</span>
                    <span className="font-mono text-amber-300 font-bold">+{quest.rewardGold} Gold 🪙</span>
                    <span className="font-mono text-sky-400 font-bold">+{quest.rewardXp} XP</span>
                    {quest.rewardItems && quest.rewardItems.map(rw => {
                      const itm = ITEMS_DATABASE[rw.itemId];
                      return (
                        <span key={rw.itemId} className="text-emerald-400 font-semibold flex items-center gap-1">
                          {itm?.icon} {rw.count}x {itm?.nameId || itm?.name}
                        </span>
                      );
                    })}
                  </div>

                  {quest.claimed ? (
                    <div className="flex items-center gap-1 text-xs text-slate-500 font-semibold">
                      <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                      <span>Selesai</span>
                    </div>
                  ) : quest.completed ? (
                    <button
                      onClick={() => handleClaim(quest.id)}
                      className="px-4 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-pixel font-bold text-xs rounded-lg shadow-md active:scale-95 transition-transform cursor-pointer flex items-center gap-1.5"
                    >
                      <Award className="w-3.5 h-3.5" />
                      <span>Klaim Hadiah</span>
                    </button>
                  ) : (
                    <span className="text-xs text-slate-500 font-mono">Sedang Berjalan</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
