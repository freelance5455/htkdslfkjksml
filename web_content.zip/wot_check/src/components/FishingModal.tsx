import React, { useState, useEffect, useRef } from 'react';
import { PlayerStats, ZoneId, ItemRarity } from '../types/game';
import { ITEMS_DATABASE, RARITY_CONFIG } from '../data/items';
import { soundManager } from '../audio/soundManager';
import { X, Fish, Sparkles } from 'lucide-react';

interface FishingModalProps {
  currentZone: ZoneId;
  playerStats: PlayerStats;
  onClose: () => void;
  onFishCaught: (fishId: string, count: number, rarity: ItemRarity) => void;
  onUpdateStats: (updater: (prev: PlayerStats) => PlayerStats) => void;
}

export const FishingModal: React.FC<FishingModalProps> = ({
  currentZone,
  playerStats,
  onClose,
  onFishCaught,
  onUpdateStats,
}) => {
  const [gameState, setGameState] = useState<'waiting' | 'bite' | 'reeling' | 'caught' | 'escaped'>('waiting');
  const [reelProgress, setReelProgress] = useState(25); // 0 to 100
  const [barPosition, setBarPosition] = useState(50); // 0 to 100
  const [targetPosition, setTargetPosition] = useState(50);
  const [caughtFish, setCaughtFish] = useState<{ id: string; name: string; icon: string; rarity: ItemRarity } | null>(null);

  const isReelingRef = useRef(false);

  // Initial wait for fish bite
  useEffect(() => {
    const timer = setTimeout(() => {
      setGameState('bite');
      soundManager.playMine();
      // Auto transition to reeling minigame
      setTimeout(() => {
        setGameState('reeling');
      }, 700);
    }, 1200 + Math.random() * 1500);

    return () => clearTimeout(timer);
  }, []);

  // Reeling loop
  useEffect(() => {
    if (gameState !== 'reeling') return;

    const interval = setInterval(() => {
      // Fish erratic movement
      setTargetPosition(prev => {
        const delta = (Math.random() - 0.5) * 18;
        return Math.max(10, Math.min(90, prev + delta));
      });

      // Player bar movement based on reeling
      setBarPosition(prev => {
        if (isReelingRef.current) {
          return Math.min(100, prev + 5);
        } else {
          return Math.max(0, prev - 4);
        }
      });

      // Check if bar is overlapping target
      setReelProgress(currProg => {
        const diff = Math.abs(barPosition - targetPosition);
        let nextProg = currProg;

        if (diff < 18) {
          // Inside sweet spot!
          soundManager.playFishReel();
          nextProg = currProg + 2.5;
        } else {
          // Losing tension
          nextProg = currProg - 1.5;
        }

        if (nextProg >= 100) {
          // Success!
          clearInterval(interval);
          determineCaughtFish();
          return 100;
        } else if (nextProg <= 0) {
          // Fish escaped!
          clearInterval(interval);
          setGameState('escaped');
          soundManager.playHit();
          return 0;
        }

        return nextProg;
      });
    }, 50);

    return () => clearInterval(interval);
  }, [gameState, barPosition, targetPosition]);

  const determineCaughtFish = () => {
    soundManager.playFishCatch();
    setGameState('caught');

    let pool: string[] = ['fish_carp'];
    if (currentZone === 'starter_village') {
      pool = ['fish_carp', 'fish_carp', 'fish_golden_perch'];
    } else if (currentZone === 'mystic_forest') {
      pool = ['fish_golden_perch', 'fish_golden_perch', 'fish_mystic_eel'];
    } else if (currentZone === 'crystal_cave') {
      pool = ['fish_mystic_eel', 'fish_cave_angler', 'fish_cave_angler'];
    } else {
      pool = ['fish_cave_angler', 'fish_abyssal_leviathan'];
    }

    const rod = ITEMS_DATABASE[playerStats.equippedTool.rod] || ITEMS_DATABASE['rod_starter'];
    const luck = rod.luckBonus || 0;

    let pickedId = pool[Math.floor(Math.random() * pool.length)];
    if (luck > 10 && Math.random() < 0.25) {
      pickedId = currentZone === 'ancient_ruins' ? 'fish_abyssal_leviathan' : 'fish_cave_angler';
    }

    const fishItem = ITEMS_DATABASE[pickedId] || ITEMS_DATABASE['fish_carp'];
    setCaughtFish({
      id: fishItem.id,
      name: fishItem.nameId || fishItem.name,
      icon: fishItem.icon,
      rarity: fishItem.rarity,
    });

    onFishCaught(fishItem.id, 1, fishItem.rarity);
    onUpdateStats(prev => ({
      ...prev,
      xp: prev.xp + 45,
      statsRecord: {
        ...prev.statsRecord,
        fishCaught: prev.statsRecord.fishCaught + 1,
      },
    }));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm select-none">
      <div className="relative w-full max-w-md bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-6 flex flex-col items-center text-center">
        {/* Header */}
        <div className="flex items-center justify-between w-full mb-6">
          <div className="flex items-center gap-2">
            <Fish className="w-5 h-5 text-sky-400" />
            <h2 className="font-pixel text-base font-bold text-white">
              MEMANCING IKAN (FISHING)
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-white rounded-lg cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* State Display */}
        {gameState === 'waiting' && (
          <div className="py-12 flex flex-col items-center gap-3">
            <div className="w-16 h-16 rounded-full bg-sky-950/60 border border-sky-500/40 flex items-center justify-center text-3xl animate-bounce">
              🎣
            </div>
            <p className="font-pixel text-sm text-sky-300">Menunggu umpan disambar ikan...</p>
            <span className="text-xs text-slate-500">Bersiaplah menarik saat ada tanda seru!</span>
          </div>
        )}

        {gameState === 'bite' && (
          <div className="py-12 flex flex-col items-center gap-3">
            <div className="text-5xl font-extrabold text-amber-400 animate-ping">
              ❗
            </div>
            <p className="font-pixel text-base font-bold text-amber-300">IKAN MENYAMBAR! TARIK JORAN!</p>
          </div>
        )}

        {gameState === 'reeling' && (
          <div className="w-full flex flex-col items-center gap-5">
            {/* Catch Progress Bar */}
            <div className="w-full">
              <div className="flex justify-between text-xs font-semibold text-slate-300 mb-1">
                <span>Daya Tangkap</span>
                <span className="font-mono text-emerald-400">{Math.round(reelProgress)}%</span>
              </div>
              <div className="h-3 w-full bg-slate-800 rounded-full overflow-hidden border border-slate-700">
                <div
                  className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 transition-all duration-75"
                  style={{ width: `${reelProgress}%` }}
                />
              </div>
            </div>

            {/* Vertical Tension Gauge */}
            <div className="relative w-20 h-52 bg-slate-950 rounded-2xl border-2 border-slate-700 overflow-hidden flex items-center justify-center">
              {/* Sweet spot area (Target Fish) */}
              <div
                className="absolute w-full h-12 bg-sky-500/30 border-y border-sky-400 transition-all duration-100 flex items-center justify-center"
                style={{ bottom: `${targetPosition}%`, transform: 'translateY(50%)' }}
              >
                <span className="text-lg animate-pulse">🐟</span>
              </div>

              {/* Player Reel Bar */}
              <div
                className="absolute w-14 h-9 bg-amber-400/80 rounded-lg border-2 border-amber-200 transition-all duration-75 shadow-lg flex items-center justify-center"
                style={{ bottom: `${barPosition}%`, transform: 'translateY(50%)' }}
              >
                <div className="w-2 h-2 rounded-full bg-slate-950" />
              </div>
            </div>

            {/* Reel Button */}
            <button
              onMouseDown={() => { isReelingRef.current = true; }}
              onMouseUp={() => { isReelingRef.current = false; }}
              onTouchStart={e => { e.preventDefault(); isReelingRef.current = true; }}
              onTouchEnd={e => { e.preventDefault(); isReelingRef.current = false; }}
              className="w-full py-4 bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 text-white font-pixel font-bold text-sm rounded-xl shadow-lg shadow-sky-500/30 active:scale-95 transition-all select-none cursor-pointer"
            >
              TAHAN UNTUK TARIK JORAN (HOLD REEL)
            </button>
            <span className="text-[11px] text-slate-400">Jaga kotak kuning tetap berada di atas ikan!</span>
          </div>
        )}

        {gameState === 'caught' && caughtFish && (
          <div className="py-6 flex flex-col items-center gap-3">
            <div className="w-20 h-20 rounded-2xl border flex items-center justify-center text-5xl shadow-xl animate-bounce" style={{
              backgroundColor: RARITY_CONFIG[caughtFish.rarity].bg,
              borderColor: RARITY_CONFIG[caughtFish.rarity].color,
            }}>
              {caughtFish.icon}
            </div>
            <h3 className="font-pixel text-lg font-bold text-white">
              BERHASIL MENANGKAP!
            </h3>
            <p className="text-sm font-bold" style={{ color: RARITY_CONFIG[caughtFish.rarity].color }}>
              {caughtFish.name} ({RARITY_CONFIG[caughtFish.rarity].labelId})
            </p>
            <span className="text-xs text-sky-400 font-mono">+45 XP Ditambahkan ke Akun</span>

            <button
              onClick={onClose}
              className="mt-4 px-8 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl active:scale-95 transition-transform cursor-pointer"
            >
              Simpan ke Tas
            </button>
          </div>
        )}

        {gameState === 'escaped' && (
          <div className="py-8 flex flex-col items-center gap-3">
            <span className="text-4xl">💨</span>
            <h3 className="font-pixel text-base font-bold text-red-400">
              IKAN TERLEPAS!
            </h3>
            <p className="text-xs text-slate-400">
              Tarikan tali pancing kurang seimbang. Coba lagi di tempat pemancingan terdekat!
            </p>
            <button
              onClick={onClose}
              className="mt-3 px-6 py-2 bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs rounded-lg cursor-pointer"
            >
              Tutup
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
