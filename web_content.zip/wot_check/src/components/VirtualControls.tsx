import React from 'react';
import { ArrowLeft, ArrowRight, ArrowUp } from 'lucide-react';

interface VirtualControlsProps {
  onMoveChange: (vector: { x: number; y: number }) => void;
  onJumpDown: () => void;
  onJumpUp: () => void;
  onActionDown: () => void;
  onActionUp: () => void;
  punchMode: 'fist' | 'wrench';
}

export const VirtualControls: React.FC<VirtualControlsProps> = ({
  onMoveChange,
  onJumpDown,
  onJumpUp,
  onActionDown,
  onActionUp,
  punchMode,
}) => {
  return (
    <div className="absolute inset-0 pointer-events-none z-20 flex justify-between items-end p-3 sm:p-6 select-none">
      {/* Left / Right Directional Buttons (Growtopia Mobile D-Pad) */}
      <div className="pointer-events-auto flex items-center gap-2 mb-16 sm:mb-20">
        {/* Walk Left */}
        <button
          onTouchStart={e => { e.preventDefault(); onMoveChange({ x: -1, y: 0 }); }}
          onTouchEnd={e => { e.preventDefault(); onMoveChange({ x: 0, y: 0 }); }}
          className="w-14 h-14 rounded-2xl bg-[#1b4f72]/85 active:bg-[#2874a6] border-2 border-[#5dade2] text-white flex items-center justify-center shadow-2xl active:scale-95 transition-transform touch-none cursor-pointer"
        >
          <ArrowLeft className="w-8 h-8 text-sky-200" />
        </button>

        {/* Walk Right */}
        <button
          onTouchStart={e => { e.preventDefault(); onMoveChange({ x: 1, y: 0 }); }}
          onTouchEnd={e => { e.preventDefault(); onMoveChange({ x: 0, y: 0 }); }}
          className="w-14 h-14 rounded-2xl bg-[#1b4f72]/85 active:bg-[#2874a6] border-2 border-[#5dade2] text-white flex items-center justify-center shadow-2xl active:scale-95 transition-transform touch-none cursor-pointer"
        >
          <ArrowRight className="w-8 h-8 text-sky-200" />
        </button>
      </div>

      {/* Jump & Punch / Place Buttons (Growtopia Mobile Action Clusters) */}
      <div className="pointer-events-auto flex items-center gap-3 mb-16 sm:mb-20">
        {/* Jump Button (▲) */}
        <button
          onTouchStart={e => { e.preventDefault(); onJumpDown(); }}
          onTouchEnd={e => { e.preventDefault(); onJumpUp(); }}
          className="w-16 h-16 rounded-full bg-[#27ae60]/85 active:bg-[#2ecc71] border-2 border-[#a9dfbf] text-white flex flex-col items-center justify-center shadow-2xl active:scale-90 transition-transform touch-none cursor-pointer"
        >
          <ArrowUp className="w-8 h-8" />
          <span className="text-[9px] font-pixel font-bold mt-[-2px]">LOMPAT</span>
        </button>

        {/* Punch Button (👊 / 🔧) */}
        <button
          onTouchStart={e => { e.preventDefault(); onActionDown(); }}
          onTouchEnd={e => { e.preventDefault(); onActionUp(); }}
          className={`w-18 h-18 rounded-full border-2 text-white flex flex-col items-center justify-center shadow-2xl active:scale-90 transition-transform touch-none cursor-pointer ${
            punchMode === 'wrench'
              ? 'bg-[#e67e22]/90 active:bg-[#f39c12] border-[#f9e79f]'
              : 'bg-[#c0392b]/90 active:bg-[#e74c3c] border-[#f1948a]'
          }`}
        >
          <span className="text-2xl leading-none">{punchMode === 'wrench' ? '🔧' : '👊'}</span>
          <span className="text-[10px] font-pixel font-bold mt-0.5">
            {punchMode === 'wrench' ? 'PERIKSA' : 'PUKUL'}
          </span>
        </button>
      </div>
    </div>
  );
};
