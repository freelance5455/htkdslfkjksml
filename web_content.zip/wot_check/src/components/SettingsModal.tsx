import React, { useState } from 'react';
import { PlayerStats, ZoneId } from '../types/game';
import { soundManager } from '../audio/soundManager';
import { 
  X, 
  Save, 
  Download, 
  Upload, 
  RotateCcw, 
  Volume2, 
  VolumeX, 
  Keyboard, 
  Smartphone, 
  Check 
} from 'lucide-react';

interface SettingsModalProps {
  playerStats: PlayerStats;
  currentZone: ZoneId;
  isMuted: boolean;
  onToggleMute: () => void;
  onClose: () => void;
  onSaveGame: () => void;
  onLoadGame: () => void;
  onResetGame: () => void;
  onImportSave: (json: string) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  playerStats,
  currentZone,
  isMuted,
  onToggleMute,
  onClose,
  onSaveGame,
  onLoadGame,
  onResetGame,
  onImportSave,
}) => {
  const [saveNotification, setSaveNotification] = useState<string | null>(null);
  const [importJson, setImportJson] = useState('');
  const [showImportBox, setShowImportBox] = useState(false);

  const handleManualSave = () => {
    soundManager.playMine();
    onSaveGame();
    setSaveNotification('Progres game berhasil disimpan ke memori lokal browser!');
    setTimeout(() => setSaveNotification(null), 3000);
  };

  const handleExport = () => {
    soundManager.playCoin();
    const data = {
      playerStats,
      currentZone,
      savedAt: Date.now(),
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `world_of_treasures_save_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/65 backdrop-blur-xs select-none">
      <div className="relative w-full max-w-lg bg-[#154360] border-4 border-[#2980b9] rounded-2xl shadow-2xl p-6 flex flex-col gap-4 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b-2 border-[#2874a6] pb-3">
          <h2 className="font-pixel text-base font-extrabold text-white tracking-wider">
            GROWTOPIA OPTIONS & SAVE
          </h2>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-[#c0392b] hover:bg-[#e74c3c] border border-[#f1948a] text-white flex items-center justify-center font-bold cursor-pointer transition-transform active:scale-95"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Save / Load Progress */}
        <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800 flex flex-col gap-3">
          <h3 className="font-pixel text-xs font-bold text-amber-300">
            SIMPAN & MUAT PROGRES (SAVE / LOAD)
          </h3>
          <p className="text-xs text-slate-400">
            Game secara otomatis menyimpan progres setiap 30 detik. Anda juga dapat menyimpan atau mengekspor berkas penyimpanan manual.
          </p>

          {saveNotification && (
            <div className="p-2.5 bg-emerald-950/40 border border-emerald-600/50 rounded-lg text-emerald-400 text-xs flex items-center gap-2">
              <Check className="w-4 h-4 shrink-0" />
              <span>{saveNotification}</span>
            </div>
          )}

          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={handleManualSave}
              className="py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-lg flex items-center justify-center gap-1.5 active:scale-95 transition-transform cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>Simpan Sekarang</span>
            </button>
            <button
              onClick={() => {
                soundManager.playMine();
                onLoadGame();
                onClose();
              }}
              className="py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs rounded-lg active:scale-95 transition-transform cursor-pointer"
            >
              Muat Simpanan Terakhir
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2 mt-1">
            <button
              onClick={handleExport}
              className="py-1.5 bg-slate-800/80 hover:bg-slate-700 text-slate-300 text-[11px] rounded-lg flex items-center justify-center gap-1 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" /> Ekspor File Simpanan
            </button>
            <button
              onClick={() => setShowImportBox(!showImportBox)}
              className="py-1.5 bg-slate-800/80 hover:bg-slate-700 text-slate-300 text-[11px] rounded-lg flex items-center justify-center gap-1 cursor-pointer"
            >
              <Upload className="w-3.5 h-3.5" /> Impor Berkas JSON
            </button>
          </div>

          {showImportBox && (
            <div className="flex flex-col gap-2 mt-2 pt-2 border-t border-slate-800">
              <textarea
                value={importJson}
                onChange={e => setImportJson(e.target.value)}
                placeholder="Tempelkan isi JSON penyimpanan di sini..."
                className="w-full h-20 bg-slate-900 border border-slate-700 rounded-lg p-2 text-xs font-mono text-slate-200 focus:outline-hidden"
              />
              <button
                onClick={() => {
                  if (importJson.trim()) {
                    onImportSave(importJson);
                    setShowImportBox(false);
                    onClose();
                  }
                }}
                className="py-1.5 bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold rounded-lg cursor-pointer"
              >
                Konfirmasi Impor
              </button>
            </div>
          )}
        </div>

        {/* Audio Controls */}
        <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800 flex items-center justify-between">
          <div>
            <h4 className="font-pixel text-xs font-bold text-white">SUARA & MUSIK LATAR</h4>
            <span className="text-[11px] text-slate-400">Musik synthesizer fantasi 16-bit & SFX</span>
          </div>
          <button
            onClick={onToggleMute}
            className={`p-2.5 rounded-xl border flex items-center gap-1.5 text-xs font-bold transition-all cursor-pointer ${
              isMuted
                ? 'bg-red-950/40 border-red-800 text-red-400'
                : 'bg-emerald-950/40 border-emerald-800 text-emerald-300'
            }`}
          >
            {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            <span>{isMuted ? 'Muted' : 'Aktif'}</span>
          </button>
        </div>

        {/* Controls Guide */}
        <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800 flex flex-col gap-2 text-xs">
          <h4 className="font-pixel text-xs font-bold text-amber-300">PANDUAN KONTROL</h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-1 text-slate-300">
            <div className="flex flex-col gap-1">
              <span className="font-bold text-white flex items-center gap-1">
                <Keyboard className="w-3.5 h-3.5 text-amber-400" /> PC Keyboard:
              </span>
              <span>· WASD / Panah : Bergerak</span>
              <span>· Spasi : Aksi / Tebang / Tambang</span>
              <span>· E : Interaksi / Bicara</span>
              <span>· 1-5 : Ganti Alat Aktif</span>
              <span>· I : Buka Tas Inventaris</span>
            </div>
            <div className="flex flex-col gap-1">
              <span className="font-bold text-white flex items-center gap-1">
                <Smartphone className="w-3.5 h-3.5 text-sky-400" /> Android / Touch:
              </span>
              <span>· Virtual Joystick (Kiri bawah)</span>
              <span>· Tombol AKSI (Kanan bawah)</span>
              <span>· Tombol E (Bicara / Buka Peti)</span>
              <span>· Tombol SERANG (Lawan monster)</span>
              <span>· Ketuk ikon menu di layar</span>
            </div>
          </div>
        </div>

        {/* Reset Progress */}
        <div className="pt-2 flex justify-between items-center">
          <button
            onClick={() => {
              if (window.confirm('Apakah Anda yakin ingin mengatur ulang progres permainan dari awal?')) {
                onResetGame();
                onClose();
              }
            }}
            className="text-red-400 hover:text-red-300 text-xs flex items-center gap-1 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" /> Reset Progres Game
          </button>

          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-lg cursor-pointer"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
