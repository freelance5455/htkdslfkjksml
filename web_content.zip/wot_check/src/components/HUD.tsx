import React, { useState } from 'react';
import { PlayerStats, ZoneId } from '../types/game';
import { ZONES } from '../data/worldMap';
import { RARITY_CONFIG } from '../data/items';
import { 
  Backpack, 
  Store, 
  Settings, 
  Volume2, 
  VolumeX, 
  MessageSquare, 
  Wrench, 
  HandMetal, 
  Lock, 
  Sparkles,
  Map as MapIcon,
  Hammer,
  Scroll
} from 'lucide-react';
import { soundManager } from '../audio/soundManager';

interface HUDProps {
  playerStats: PlayerStats;
  currentZone: ZoneId;
  isMuted: boolean;
  onToggleMute: () => void;
  onOpenInventory: () => void;
  onOpenCrafting: () => void;
  onOpenQuests: () => void;
  onOpenMap: () => void;
  onOpenMarketplace: () => void;
  onOpenSettings: () => void;
  onTogglePunchMode: () => void;
  onSelectSlot: (index: number) => void;
  onSendChat: (text: string) => void;
}

export const HUD: React.FC<HUDProps> = ({
  playerStats,
  currentZone,
  isMuted,
  onToggleMute,
  onOpenInventory,
  onOpenCrafting,
  onOpenQuests,
  onOpenMap,
  onOpenMarketplace,
  onOpenSettings,
  onTogglePunchMode,
  onSelectSlot,
  onSendChat,
}) => {
  const [chatInput, setChatInput] = useState('');
  const [showChatInput, setShowChatInput] = useState(false);

  const zoneNames: Record<ZoneId, string> = {
    starter_village: 'START',
    mystic_forest: 'FOREST',
    crystal_cave: 'CAVE',
    ancient_ruins: 'RUINS',
  };

  const handleChatSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (chatInput.trim()) {
      onSendChat(chatInput.trim());
      setChatInput('');
      setShowChatInput(false);
    }
  };

  // 8 slots for Growtopia bottom quickbar
  const quickSlots = playerStats.inventory.slice(0, 8);

  return (
    <div className="absolute inset-0 pointer-events-none z-30 select-none flex flex-col justify-between p-2 sm:p-4">
      {/* --- TOP STATUS BAR (ICONIC GROWTOPIA BLUE BEVEL STRIP) --- */}
      <div className="flex items-center justify-between w-full gap-2">
        {/* Left: World Name & Gems / WLs */}
        <div className="pointer-events-auto flex items-center gap-1.5 sm:gap-2">
          {/* World Name Badge */}
          <div className="bg-[#1b4f72] border-2 border-[#5dade2] rounded-lg px-3 py-1.5 shadow-md flex items-center gap-1.5">
            <span className="text-[10px] sm:text-xs font-pixel font-bold text-[#aed6f1]">WORLD:</span>
            <span className="text-xs sm:text-sm font-pixel font-extrabold text-white tracking-wider">
              {zoneNames[currentZone]}
            </span>
          </div>

          {/* Gems Counter 💎 */}
          <div className="bg-[#154360] border-2 border-[#2980b9] rounded-lg px-2.5 py-1.5 shadow-md flex items-center gap-1.5">
            <span className="text-base leading-none">💎</span>
            <span className="font-pixel text-xs sm:text-sm font-extrabold text-[#f9e79f] tabular-nums">
              {playerStats.gems.toLocaleString()}
            </span>
          </div>

          {/* World Locks 🔒 */}
          <div className="bg-[#154360] border-2 border-[#f39c12] rounded-lg px-2.5 py-1.5 shadow-md flex items-center gap-1.5">
            <span className="text-base leading-none">🔒</span>
            <span className="font-pixel text-xs sm:text-sm font-extrabold text-[#f5b041] tabular-nums">
              {playerStats.worldLocks}
            </span>
          </div>
        </div>

        {/* Center: Chat Input Popup */}
        {showChatInput && (
          <form onSubmit={handleChatSubmit} className="pointer-events-auto flex items-center gap-1 bg-[#1b4f72] p-1 rounded-xl border-2 border-[#5dade2] shadow-xl">
            <input
              type="text"
              autoFocus
              value={chatInput}
              onChange={e => setChatInput(e.target.value)}
              placeholder="Ketik pesan chat..."
              className="px-3 py-1 text-xs bg-slate-900 text-white rounded-lg border border-[#2980b9] focus:outline-hidden w-40 sm:w-60"
            />
            <button type="submit" className="px-3 py-1 bg-[#27ae60] hover:bg-[#2ecc71] text-white text-xs font-bold rounded-lg cursor-pointer">
              Kirim
            </button>
          </form>
        )}

        {/* Right: Fist/Wrench Mode Toggle & Menu Icons */}
        <div className="pointer-events-auto flex items-center gap-1.5 sm:gap-2">
          {/* Fist 👊 vs Wrench 🔧 Toggle Button */}
          <button
            onClick={() => {
              soundManager.playMine();
              onTogglePunchMode();
            }}
            className={`w-10 h-10 sm:w-11 sm:h-11 rounded-xl border-2 flex items-center justify-center text-xl shadow-lg transition-transform active:scale-90 cursor-pointer ${
              playerStats.punchMode === 'wrench'
                ? 'bg-[#e67e22] border-[#f39c12] text-white ring-2 ring-amber-300'
                : 'bg-[#c0392b] border-[#e74c3c] text-white'
            }`}
            title={playerStats.punchMode === 'wrench' ? 'Mode Obeng / Wrench (Periksa)' : 'Mode Tinju / Fist (Pukul / Hancurkan)'}
          >
            {playerStats.punchMode === 'wrench' ? '🔧' : '👊'}
          </button>

          {/* Chat Bubble Button */}
          <button
            onClick={() => setShowChatInput(!showChatInput)}
            className="w-9 h-9 sm:w-10 sm:h-10 bg-[#1b4f72] hover:bg-[#2874a6] border-2 border-[#5dade2] rounded-xl flex items-center justify-center text-white active:scale-95 transition-transform cursor-pointer shadow-md"
            title="Chat Bubble"
          >
            <MessageSquare className="w-4 h-4 text-sky-200" />
          </button>

          {/* Growtopia Store / Marketplace */}
          <button
            onClick={onOpenMarketplace}
            className="w-9 h-9 sm:w-10 sm:h-10 bg-[#f39c12] hover:bg-[#f1c40f] border-2 border-[#f9e79f] rounded-xl flex items-center justify-center text-slate-950 font-bold active:scale-95 transition-transform cursor-pointer shadow-md"
            title="Growtopia Store & Marketplace"
          >
            <Store className="w-4 h-4" />
          </button>

          {/* Sound Mute Toggle */}
          <button
            onClick={onToggleMute}
            className="w-9 h-9 sm:w-10 sm:h-10 bg-[#1b4f72] hover:bg-[#2874a6] border-2 border-[#5dade2] rounded-xl flex items-center justify-center text-white active:scale-95 transition-transform cursor-pointer shadow-md"
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
          </button>

          {/* Settings Button */}
          <button
            onClick={onOpenSettings}
            className="w-9 h-9 sm:w-10 sm:h-10 bg-[#1b4f72] hover:bg-[#2874a6] border-2 border-[#5dade2] rounded-xl flex items-center justify-center text-white active:scale-95 transition-transform cursor-pointer shadow-md"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* --- BOTTOM QUICKBAR & INVENTORY STRIP --- */}
      <div className="flex items-end justify-between w-full">
        {/* Left: Quick Actions (Bag, Quest, Craft, Map) */}
        <div className="pointer-events-auto flex items-center gap-1 bg-[#154360]/90 backdrop-blur-xs p-1.5 rounded-xl border-2 border-[#2980b9] shadow-xl">
          <button
            onClick={onOpenInventory}
            className="p-2 sm:px-3 sm:py-2 bg-[#1b4f72] hover:bg-[#2874a6] active:scale-95 rounded-lg text-white font-pixel font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer border border-[#5dade2]"
            title="Buka Tas [I]"
          >
            <Backpack className="w-4 h-4 text-[#f9e79f]" />
            <span className="hidden sm:inline">TAS</span>
          </button>

          <button
            onClick={onOpenQuests}
            className="p-2 sm:px-3 sm:py-2 bg-[#1b4f72] hover:bg-[#2874a6] active:scale-95 rounded-lg text-white font-pixel font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer border border-[#5dade2]"
            title="Misi [Q]"
          >
            <Scroll className="w-4 h-4 text-emerald-400" />
            <span className="hidden sm:inline">MISI</span>
          </button>

          <button
            onClick={onOpenCrafting}
            className="p-2 sm:px-3 sm:py-2 bg-[#1b4f72] hover:bg-[#2874a6] active:scale-95 rounded-lg text-white font-pixel font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer border border-[#5dade2]"
            title="Splicing / Tempa [C]"
          >
            <Hammer className="w-4 h-4 text-amber-400" />
            <span className="hidden sm:inline">TEMPA</span>
          </button>

          <button
            onClick={onOpenMap}
            className="p-2 sm:px-3 sm:py-2 bg-[#1b4f72] hover:bg-[#2874a6] active:scale-95 rounded-lg text-white font-pixel font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer border border-[#5dade2]"
            title="Peta World [M]"
          >
            <MapIcon className="w-4 h-4 text-purple-400" />
            <span className="hidden sm:inline">WORLD</span>
          </button>
        </div>

        {/* Center/Right: Growtopia Quick Inventory Bar (8 slots) */}
        <div className="pointer-events-auto flex items-center gap-1.5 bg-[#154360]/95 backdrop-blur-xs p-1.5 rounded-xl border-2 border-[#2980b9] shadow-2xl">
          {quickSlots.map((slot, idx) => {
            const isSelected = playerStats.heldSlotIndex === idx;

            return (
              <button
                key={idx}
                onClick={() => {
                  soundManager.playMine();
                  onSelectSlot(idx);
                }}
                className={`relative w-11 h-11 sm:w-13 sm:h-13 rounded-lg border-2 flex flex-col items-center justify-center transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-[#2980b9] border-[#f1c40f] ring-2 ring-[#f39c12] scale-105 shadow-md'
                    : slot
                    ? 'bg-[#1b4f72] border-[#2c3e50] hover:border-[#5dade2]'
                    : 'bg-[#0e2f44] border-[#1a364a]'
                }`}
              >
                {slot ? (
                  <>
                    <span className="text-xl sm:text-2xl select-none leading-none">
                      {slot.item.icon}
                    </span>
                    <span className="absolute bottom-0.5 right-1 font-mono text-[9px] font-extrabold text-white bg-black/60 px-0.5 rounded-xs leading-none">
                      {slot.count}
                    </span>
                  </>
                ) : (
                  <span className="text-[10px] font-mono text-slate-600">{idx + 1}</span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
