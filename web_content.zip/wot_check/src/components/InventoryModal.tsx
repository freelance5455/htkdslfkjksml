import React, { useState } from 'react';
import { PlayerStats, InventorySlot } from '../types/game';
import { RARITY_CONFIG } from '../data/items';
import { soundManager } from '../audio/soundManager';
import { X, ShieldCheck, Sparkles, Trash2, ArrowUpRight } from 'lucide-react';

interface InventoryModalProps {
  playerStats: PlayerStats;
  onClose: () => void;
  onUpdateStats: (updater: (prev: PlayerStats) => PlayerStats) => void;
  onOpenMarketListing: (slot: InventorySlot) => void;
}

export const InventoryModal: React.FC<InventoryModalProps> = ({
  playerStats,
  onClose,
  onUpdateStats,
  onOpenMarketListing,
}) => {
  const [selectedSlotIndex, setSelectedSlotIndex] = useState<number | null>(null);

  const selectedSlot = selectedSlotIndex !== null ? playerStats.inventory[selectedSlotIndex] : null;

  const handleUseItem = () => {
    if (!selectedSlot) return;
    const item = selectedSlot.item;

    if (item.category === 'potion' || item.healAmount) {
      soundManager.playHarvest();
      const heal = item.healAmount || 30;

      onUpdateStats(prev => {
        const inv = [...prev.inventory];
        if (inv[selectedSlotIndex!]) {
          if (inv[selectedSlotIndex!]!.count > 1) {
            inv[selectedSlotIndex!]!.count -= 1;
          } else {
            inv[selectedSlotIndex!] = null;
          }
        }
        return {
          ...prev,
          hp: Math.min(prev.maxHp, prev.hp + heal),
          inventory: inv,
        };
      });
    } else if (item.category === 'tool' && item.toolType) {
      // Equip tool
      soundManager.playMine();
      onUpdateStats(prev => ({
        ...prev,
        equippedTool: {
          ...prev.equippedTool,
          [item.toolType!]: item.id,
        },
        selectedToolType: item.toolType!,
      }));
    }
  };

  const handleQuickSell = () => {
    if (!selectedSlot) return;
    const item = selectedSlot.item;
    const goldEarned = item.value * selectedSlot.count;

    soundManager.playCoin();
    onUpdateStats(prev => {
      const inv = [...prev.inventory];
      inv[selectedSlotIndex!] = null;
      return {
        ...prev,
        gold: prev.gold + goldEarned,
        inventory: inv,
        statsRecord: {
          ...prev.statsRecord,
          goldEarned: prev.statsRecord.goldEarned + goldEarned,
        },
      };
    });
    setSelectedSlotIndex(null);
  };

  const handleDiscard = () => {
    if (!selectedSlot) return;
    onUpdateStats(prev => {
      const inv = [...prev.inventory];
      inv[selectedSlotIndex!] = null;
      return {
        ...prev,
        inventory: inv,
      };
    });
    setSelectedSlotIndex(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/65 backdrop-blur-xs select-none">
      <div className="relative w-full max-w-3xl bg-[#154360] border-4 border-[#2980b9] rounded-2xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-3.5 bg-[#1b4f72] border-b-2 border-[#2874a6]">
          <div className="flex items-center gap-2">
            <span className="text-xl">🎒</span>
            <h2 className="font-pixel text-base font-extrabold text-white tracking-wider">
              GROWTOPIA INVENTORY
            </h2>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-[#c0392b] hover:bg-[#e74c3c] border border-[#f1948a] text-white flex items-center justify-center font-bold cursor-pointer transition-transform active:scale-95"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body: Slots Grid + Detail Panel */}
        <div className="p-6 grid grid-cols-1 md:grid-cols-3 gap-6 overflow-y-auto">
          {/* Inventory Grid */}
          <div className="md:col-span-2">
            <div className="flex items-center justify-between mb-3 text-xs font-semibold text-[#aed6f1]">
              <span>Kapasitas Tas: {playerStats.inventory.filter(Boolean).length}/{playerStats.inventorySize}</span>
              <span className="text-[#f9e79f] font-pixel">💎 {playerStats.gems.toLocaleString()} · 🔒 {playerStats.worldLocks} WL</span>
            </div>

            <div className="grid grid-cols-4 sm:grid-cols-6 gap-2.5">
              {playerStats.inventory.map((slot, index) => {
                const isSelected = selectedSlotIndex === index;
                const rarityStyle = slot ? RARITY_CONFIG[slot.item.rarity] : null;

                return (
                  <button
                    key={index}
                    onClick={() => {
                      if (slot) {
                        soundManager.playMine();
                        setSelectedSlotIndex(index);
                      }
                    }}
                    className={`relative aspect-square rounded-xl border flex flex-col items-center justify-center p-1 transition-all cursor-pointer ${
                      isSelected
                        ? 'border-amber-400 bg-amber-950/40 ring-2 ring-amber-400/50 scale-105'
                        : slot
                        ? `${rarityStyle?.border} ${rarityStyle?.bg} hover:border-slate-400`
                        : 'border-slate-800 bg-slate-950/50'
                    }`}
                  >
                    {slot ? (
                      <>
                        <span className="text-2xl sm:text-3xl select-none leading-none">
                          {slot.item.icon}
                        </span>
                        {slot.count > 1 && (
                          <span className="absolute bottom-1 right-1.5 font-mono text-[10px] font-bold text-white bg-slate-950/80 px-1 rounded-sm">
                            {slot.count}
                          </span>
                        )}
                      </>
                    ) : (
                      <span className="text-slate-800 text-xs font-mono">{index + 1}</span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Item Detail Panel */}
          <div className="md:col-span-1 bg-slate-950/60 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
            {selectedSlot ? (
              <div className="flex flex-col gap-3">
                <div className="flex items-center gap-3">
                  <div className={`w-14 h-14 rounded-xl border flex items-center justify-center text-3xl ${RARITY_CONFIG[selectedSlot.item.rarity].border} ${RARITY_CONFIG[selectedSlot.item.rarity].bg}`}>
                    {selectedSlot.item.icon}
                  </div>
                  <div>
                    <h3 className="font-pixel text-sm font-bold text-white leading-tight">
                      {selectedSlot.item.nameId || selectedSlot.item.name}
                    </h3>
                    <div className="flex items-center gap-1.5 mt-1">
                      <span
                        className="text-[10px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded-sm"
                        style={{
                          backgroundColor: `${RARITY_CONFIG[selectedSlot.item.rarity].color}20`,
                          color: RARITY_CONFIG[selectedSlot.item.rarity].color,
                        }}
                      >
                        {RARITY_CONFIG[selectedSlot.item.rarity].labelId}
                      </span>
                      <span className="text-[10px] text-slate-400">· {selectedSlot.item.category}</span>
                    </div>
                  </div>
                </div>

                {/* Description */}
                <p className="text-xs text-slate-300 leading-relaxed">
                  {selectedSlot.item.description}
                </p>

                {/* Stats */}
                <div className="bg-slate-900/80 p-2.5 rounded-lg border border-slate-800 text-xs flex flex-col gap-1 text-slate-300">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Nilai Jual Dasar:</span>
                    <span className="font-mono font-bold text-amber-300">{selectedSlot.item.value} Gold</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Jumlah Dimiliki:</span>
                    <span className="font-mono font-bold text-white">{selectedSlot.count}x</span>
                  </div>
                  {selectedSlot.item.toolPower && (
                    <div className="flex justify-between">
                      <span className="text-slate-400">Kekuatan Alat:</span>
                      <span className="font-mono font-bold text-emerald-400">+{selectedSlot.item.toolPower}</span>
                    </div>
                  )}
                  {selectedSlot.item.healAmount && (
                    <div className="flex justify-between">
                      <span className="text-slate-400">Pemulihan HP:</span>
                      <span className="font-mono font-bold text-rose-400">+{selectedSlot.item.healAmount} HP</span>
                    </div>
                  )}
                </div>

                {/* Authenticity Hash for Marketplace */}
                <div className="flex items-center gap-1.5 text-[10px] text-emerald-400 bg-emerald-950/40 p-2 rounded-lg border border-emerald-800/40">
                  <ShieldCheck className="w-3.5 h-3.5 shrink-0" />
                  <span className="font-mono truncate">{selectedSlot.hash}</span>
                </div>

                {/* Action Buttons */}
                <div className="flex flex-col gap-2 mt-2">
                  {(selectedSlot.item.category === 'potion' || selectedSlot.item.category === 'tool' || selectedSlot.item.healAmount) && (
                    <button
                      onClick={handleUseItem}
                      className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs rounded-lg active:scale-98 transition-transform cursor-pointer"
                    >
                      {selectedSlot.item.category === 'tool' ? 'Pasang / Pakai' : 'Gunakan'}
                    </button>
                  )}

                  <button
                    onClick={() => onOpenMarketListing(selectedSlot)}
                    className="w-full py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-lg flex items-center justify-center gap-1.5 active:scale-98 transition-transform cursor-pointer"
                  >
                    <ArrowUpRight className="w-3.5 h-3.5" />
                    <span>Jual di Marketplace</span>
                  </button>

                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={handleQuickSell}
                      className="py-1.5 bg-slate-800 hover:bg-slate-700 text-amber-300 font-semibold text-[11px] rounded-lg transition-colors cursor-pointer"
                    >
                      Jual Cepat (+{selectedSlot.item.value * selectedSlot.count}g)
                    </button>
                    <button
                      onClick={handleDiscard}
                      className="py-1.5 bg-slate-800 hover:bg-red-950/60 text-red-400 font-semibold text-[11px] rounded-lg transition-colors cursor-pointer flex items-center justify-center gap-1"
                    >
                      <Trash2 className="w-3 h-3" /> Buang
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-full text-center text-slate-500 text-xs py-10">
                <Sparkles className="w-8 h-8 text-slate-700 mb-2" />
                <span>Pilih item dari kotak tas untuk melihat detail atau menggunakannya.</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
