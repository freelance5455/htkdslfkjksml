import React, { useState } from 'react';
import { PlayerStats, MarketListing, TradeHistoryItem, ItemRarity, InventorySlot } from '../types/game';
import { RARITY_CONFIG } from '../data/items';
import { generateItemHash } from '../services/marketplaceService';
import { soundManager } from '../audio/soundManager';
import { 
  X, 
  Store, 
  Search, 
  ShieldCheck, 
  TrendingUp, 
  History, 
  Tag, 
  ArrowLeft, 
  CheckCircle2, 
  AlertTriangle 
} from 'lucide-react';

interface MarketplacePortalProps {
  playerStats: PlayerStats;
  listings: MarketListing[];
  tradeHistory: TradeHistoryItem[];
  preselectedSellSlot?: InventorySlot | null;
  onClose: () => void;
  onUpdateStats: (updater: (prev: PlayerStats) => PlayerStats) => void;
  onUpdateListings: (updater: (prev: MarketListing[]) => MarketListing[]) => void;
  onAddTradeHistory: (trade: TradeHistoryItem) => void;
}

export const MarketplacePortal: React.FC<MarketplacePortalProps> = ({
  playerStats,
  listings,
  tradeHistory,
  preselectedSellSlot,
  onClose,
  onUpdateStats,
  onUpdateListings,
  onAddTradeHistory,
}) => {
  const [activeTab, setActiveTab] = useState<'browse' | 'sell' | 'history' | 'security'>(
    preselectedSellSlot ? 'sell' : 'browse'
  );
  const [searchQuery, setSearchQuery] = useState('');
  const [rarityFilter, setRarityFilter] = useState<string>('all');

  // Sell state
  const [selectedInventorySlotIdx, setSelectedInventorySlotIdx] = useState<number | null>(() => {
    if (preselectedSellSlot) {
      return playerStats.inventory.findIndex(s => s && s.hash === preselectedSellSlot.hash);
    }
    return null;
  });
  const [sellPriceInput, setSellPriceInput] = useState<number>(20);
  const [sellSuccessMsg, setSellSuccessMsg] = useState<string | null>(null);

  // Filter listings
  const filteredListings = listings.filter(l => {
    const matchesSearch = l.item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          (l.item.nameId && l.item.nameId.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesRarity = rarityFilter === 'all' || l.item.rarity === rarityFilter;
    return matchesSearch && matchesRarity;
  });

  const handleBuyListing = (listing: MarketListing) => {
    if (playerStats.gold < listing.totalPrice) return;

    soundManager.playCoin();

    // Check if player has inventory space
    let hasSpace = false;
    for (const slot of playerStats.inventory) {
      if (!slot || (slot.item.id === listing.item.id && slot.item.stackable)) {
        hasSpace = true;
        break;
      }
    }
    if (!hasSpace) return;

    // Deduct listing from marketplace
    onUpdateListings(prev => prev.filter(l => l.id !== listing.id));

    // Add to history
    onAddTradeHistory({
      id: `tx_${Date.now()}`,
      timestamp: Date.now(),
      itemName: listing.item.name,
      itemRarity: listing.item.rarity,
      count: listing.count,
      price: listing.totalPrice,
      buyer: 'Anda (Player)',
      seller: listing.sellerName,
      txHash: `0x${Math.random().toString(16).substring(2, 10)}`,
    });

    // Update player gold and inventory
    onUpdateStats(prev => {
      const inv = [...prev.inventory];
      const existing = listing.item.stackable ? inv.find(s => s && s.item.id === listing.item.id) : null;

      if (existing) {
        existing.count += listing.count;
      } else {
        const emptyIdx = inv.findIndex(s => s === null);
        if (emptyIdx !== -1) {
          inv[emptyIdx] = {
            item: listing.item,
            count: listing.count,
            hash: listing.mintHash,
            obtainedAt: Date.now(),
          };
        }
      }

      return {
        ...prev,
        gold: prev.gold - listing.totalPrice,
        inventory: inv,
      };
    });
  };

  const handleCreateListing = () => {
    if (selectedInventorySlotIdx === null) return;
    const slot = playerStats.inventory[selectedInventorySlotIdx];
    if (!slot) return;
    if (sellPriceInput <= 0) return;

    soundManager.playCoin();

    const newListing: MarketListing = {
      id: `list_p_${Date.now()}`,
      sellerId: 'player_me',
      sellerName: 'Anda (Player)',
      item: slot.item,
      count: slot.count,
      pricePerUnit: sellPriceInput,
      totalPrice: sellPriceInput * slot.count,
      mintHash: slot.hash,
      listedAt: Date.now(),
      isPlayerListing: true,
    };

    onUpdateListings(prev => [newListing, ...prev]);

    // Remove item from inventory
    onUpdateStats(prev => {
      const inv = [...prev.inventory];
      inv[selectedInventorySlotIdx] = null;
      return {
        ...prev,
        inventory: inv,
      };
    });

    setSelectedInventorySlotIdx(null);
    setSellSuccessMsg(`Berhasil mendaftarkan ${slot.count}x ${slot.item.nameId || slot.item.name} ke Marketplace!`);
    setTimeout(() => setSellSuccessMsg(null), 4000);
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-slate-950 text-slate-100 select-none overflow-hidden">
      {/* Official Marketplace Portal Header */}
      <header className="flex items-center justify-between px-6 py-4 bg-slate-900 border-b border-slate-800 shrink-0">
        <div className="flex items-center gap-3">
          <button
            onClick={onClose}
            className="p-2 hover:bg-slate-800 text-slate-400 hover:text-white rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer text-xs"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="hidden sm:inline">Kembali ke Dunia Game</span>
          </button>
          <div className="h-5 w-px bg-slate-700 hidden sm:block" />
          <div className="flex items-center gap-2">
            <Store className="w-5 h-5 text-amber-400" />
            <h1 className="font-pixel text-base sm:text-lg font-bold text-white tracking-wider">
              MARKETPLACE RESMI <span className="text-amber-400">WORLD OF TREASURES</span>
            </h1>
          </div>
        </div>

        {/* Player Profile & Wallet */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Gems */}
          <div className="flex items-center gap-1.5 bg-[#0e2f44] px-2.5 py-1 rounded-xl border border-[#2980b9]">
            <span className="text-base leading-none">💎</span>
            <span className="font-pixel text-xs font-bold text-[#f9e79f]">
              {playerStats.gems.toLocaleString()}
            </span>
          </div>

          {/* World Locks */}
          <div className="flex items-center gap-1.5 bg-[#0e2f44] px-2.5 py-1 rounded-xl border border-[#f39c12]">
            <span className="text-base leading-none">🔒</span>
            <span className="font-pixel text-xs font-bold text-[#f5b041]">
              {playerStats.worldLocks} WL
            </span>
          </div>

          <div className="hidden sm:flex items-center gap-2 bg-slate-950 px-3 py-1 rounded-xl border border-amber-500/30">
            <span className="text-base">🪙</span>
            <span className="font-mono text-xs font-bold text-amber-300 tabular-nums">
              {playerStats.gold.toLocaleString()} Gold
            </span>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Navigation Sub-bar */}
      <div className="flex items-center justify-between px-6 py-2.5 bg-slate-900/60 border-b border-slate-800 shrink-0 overflow-x-auto">
        <div className="flex items-center gap-2 text-xs">
          <button
            onClick={() => setActiveTab('browse')}
            className={`px-3.5 py-1.5 rounded-lg font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
              activeTab === 'browse'
                ? 'bg-amber-500 text-slate-950'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            <Store className="w-3.5 h-3.5" /> Pasar Global
          </button>
          <button
            onClick={() => setActiveTab('sell')}
            className={`px-3.5 py-1.5 rounded-lg font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
              activeTab === 'sell'
                ? 'bg-amber-500 text-slate-950'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            <Tag className="w-3.5 h-3.5" /> Jual Item dari Tas
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`px-3.5 py-1.5 rounded-lg font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
              activeTab === 'history'
                ? 'bg-amber-500 text-slate-950'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            <History className="w-3.5 h-3.5" /> Riwayat Transaksi
          </button>
          <button
            onClick={() => setActiveTab('security')}
            className={`px-3.5 py-1.5 rounded-lg font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
              activeTab === 'security'
                ? 'bg-amber-500 text-slate-950'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" /> Keamanan & Regulasi
          </button>
        </div>

        {/* Live economy ticker */}
        <div className="hidden md:flex items-center gap-2 text-[11px] text-slate-400">
          <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
          <span>Indeks Ekonomi: <strong className="text-emerald-400">Stabil (+4.2%)</strong></span>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto p-6 max-w-6xl w-full mx-auto">
        {/* --- TAB 1: BROWSE GLOBAL LISTINGS --- */}
        {activeTab === 'browse' && (
          <div className="flex flex-col gap-5">
            {/* Search & Rarity Filters */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
              <div className="relative flex-1 max-w-md">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  placeholder="Cari item, kristal, kayu, atau artefak..."
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-hidden focus:border-amber-400"
                />
              </div>

              {/* Rarity Selectors */}
              <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0 text-xs">
                {(['all', 'common', 'uncommon', 'rare', 'epic', 'legendary', 'mythic'] as const).map(r => (
                  <button
                    key={r}
                    onClick={() => setRarityFilter(r)}
                    className={`px-3 py-1.5 rounded-lg font-medium capitalize whitespace-nowrap transition-colors cursor-pointer ${
                      rarityFilter === r
                        ? 'bg-slate-800 text-amber-300 border border-amber-400/50'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {r === 'all' ? 'Semua Rarity' : RARITY_CONFIG[r].labelId}
                  </button>
                ))}
              </div>
            </div>

            {/* Listings Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredListings.map(listing => {
                const item = listing.item;
                const rStyle = RARITY_CONFIG[item.rarity];
                const canAfford = playerStats.gold >= listing.totalPrice;

                return (
                  <div
                    key={listing.id}
                    className="bg-slate-900/80 border border-slate-800 hover:border-slate-700 rounded-xl p-4 flex flex-col justify-between gap-3 transition-all"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <div className="flex items-center gap-2.5">
                          <div className={`w-11 h-11 rounded-lg border flex items-center justify-center text-2xl ${rStyle.border} ${rStyle.bg}`}>
                            {item.icon}
                          </div>
                          <div>
                            <h3 className="font-semibold text-xs text-white leading-snug">
                              {item.nameId || item.name}
                            </h3>
                            <span className="text-[10px] font-bold" style={{ color: rStyle.color }}>
                              {rStyle.labelId} · x{listing.count}
                            </span>
                          </div>
                        </div>

                        <span className="text-[10px] text-slate-500 font-mono">
                          {listing.sellerName}
                        </span>
                      </div>

                      <p className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed">
                        {item.description}
                      </p>

                      {/* Mint Hash */}
                      <div className="mt-2 flex items-center gap-1 text-[9px] font-mono text-emerald-400/80">
                        <ShieldCheck className="w-3 h-3" />
                        <span className="truncate">{listing.mintHash}</span>
                      </div>
                    </div>

                    <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
                      <div className="flex flex-col">
                        <span className="text-[9px] text-slate-500">Harga Total:</span>
                        <span className="font-mono font-bold text-amber-300 text-sm">
                          {listing.totalPrice.toLocaleString()} 🪙
                        </span>
                      </div>

                      {listing.isPlayerListing ? (
                        <span className="text-xs text-amber-400 font-semibold">Listing Anda</span>
                      ) : (
                        <button
                          onClick={() => handleBuyListing(listing)}
                          disabled={!canAfford}
                          className={`px-4 py-1.5 rounded-lg font-bold text-xs font-mono transition-all cursor-pointer ${
                            canAfford
                              ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 active:scale-95'
                              : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                          }`}
                        >
                          Beli Sekarang
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* --- TAB 2: SELL FROM INVENTORY --- */}
        {activeTab === 'sell' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Inventory Selector */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
              <h3 className="font-pixel text-sm font-bold text-white mb-3">
                PILIH ITEM DARI TAS ANDA:
              </h3>
              <div className="grid grid-cols-4 sm:grid-cols-5 gap-2 max-h-[50vh] overflow-y-auto p-1">
                {playerStats.inventory.map((slot, idx) => {
                  if (!slot) return null;
                  const isSelected = selectedInventorySlotIdx === idx;
                  const rStyle = RARITY_CONFIG[slot.item.rarity];

                  return (
                    <button
                      key={idx}
                      onClick={() => {
                        setSelectedInventorySlotIdx(idx);
                        setSellPriceInput(Math.round(slot.item.value * 1.2));
                      }}
                      className={`relative aspect-square rounded-xl border flex flex-col items-center justify-center p-1 cursor-pointer transition-all ${
                        isSelected
                          ? 'border-amber-400 bg-amber-950/40 ring-2 ring-amber-400/50 scale-105'
                          : `${rStyle.border} ${rStyle.bg} hover:border-slate-500`
                      }`}
                    >
                      <span className="text-2xl">{slot.item.icon}</span>
                      <span className="absolute bottom-1 right-1 text-[9px] font-mono font-bold text-white bg-slate-950/70 px-1 rounded-sm">
                        x{slot.count}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Listing Form */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex flex-col justify-between">
              {selectedInventorySlotIdx !== null && playerStats.inventory[selectedInventorySlotIdx] ? (
                (() => {
                  const targetSlot = playerStats.inventory[selectedInventorySlotIdx]!;
                  const rStyle = RARITY_CONFIG[targetSlot.item.rarity];
                  const totalExpected = sellPriceInput * targetSlot.count;

                  return (
                    <div className="flex flex-col gap-4">
                      <div className="flex items-center gap-3">
                        <div className={`w-14 h-14 rounded-xl border flex items-center justify-center text-3xl ${rStyle.border} ${rStyle.bg}`}>
                          {targetSlot.item.icon}
                        </div>
                        <div>
                          <h4 className="font-pixel text-sm font-bold text-white">
                            {targetSlot.item.nameId || targetSlot.item.name}
                          </h4>
                          <span className="text-xs font-bold" style={{ color: rStyle.color }}>
                            {rStyle.labelId} · Jumlah: {targetSlot.count}x
                          </span>
                        </div>
                      </div>

                      {/* Serial Tag */}
                      <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800 text-xs flex flex-col gap-1">
                        <span className="text-slate-400">Kode Sertifikat Kepemilikan:</span>
                        <span className="font-mono text-emerald-400">{targetSlot.hash}</span>
                      </div>

                      {/* Price Setter */}
                      <div>
                        <label className="text-xs font-bold text-slate-300 block mb-1">
                          Tentukan Harga Jual per Unit (Gold):
                        </label>
                        <input
                          type="number"
                          min="1"
                          value={sellPriceInput}
                          onChange={e => setSellPriceInput(Math.max(1, parseInt(e.target.value) || 1))}
                          className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2 font-mono text-sm text-amber-300 font-bold focus:outline-hidden focus:border-amber-400"
                        />
                        <span className="text-[10px] text-slate-500 mt-1 block">
                          Nilai dasar toko: {targetSlot.item.value} Gold
                        </span>
                      </div>

                      <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs flex justify-between items-center">
                        <span className="text-slate-400">Total Yang Akan Diterima:</span>
                        <span className="font-mono text-base font-bold text-amber-300">
                          {totalExpected.toLocaleString()} Gold 🪙
                        </span>
                      </div>

                      <button
                        onClick={handleCreateListing}
                        className="w-full py-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-pixel font-bold text-xs rounded-xl shadow-lg active:scale-98 transition-all cursor-pointer"
                      >
                        DAFTARKAN KE PASAR GLOBAL
                      </button>
                    </div>
                  );
                })()
              ) : (
                <div className="flex flex-col items-center justify-center h-full text-center py-12 text-slate-500 text-xs">
                  {sellSuccessMsg ? (
                    <div className="flex flex-col items-center gap-2 text-emerald-400">
                      <CheckCircle2 className="w-8 h-8" />
                      <span className="font-bold text-sm">{sellSuccessMsg}</span>
                    </div>
                  ) : (
                    <span>Pilih item di sebelah kiri untuk menentukan harga dan mendaftarkannya ke pasar pemain.</span>
                  )}
                </div>
              )}
            </div>
          </div>
        )}

        {/* --- TAB 3: TRADE HISTORY --- */}
        {activeTab === 'history' && (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
            <h3 className="font-pixel text-sm font-bold text-white mb-4">
              RIWAYAT TRANSAKSI PASAR GLOBAL (LIVE AUDIT LOG)
            </h3>
            <div className="flex flex-col gap-2">
              {tradeHistory.map(th => {
                const rStyle = RARITY_CONFIG[th.itemRarity];

                return (
                  <div
                    key={th.id}
                    className="p-3 bg-slate-950/70 border border-slate-800/80 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs"
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-slate-500 font-mono text-[10px]">
                        {new Date(th.timestamp).toLocaleTimeString()}
                      </span>
                      <div>
                        <span className="font-semibold text-white">{th.itemName}</span>
                        <span className="text-slate-400 font-mono"> x{th.count}</span>
                        <span className="ml-2 font-bold text-[10px]" style={{ color: rStyle.color }}>
                          [{rStyle.labelId}]
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-4 text-slate-300">
                      <div className="text-[11px]">
                        <span className="text-slate-500">Penjual:</span> {th.seller} → <span className="text-slate-500">Pembeli:</span> {th.buyer}
                      </div>
                      <span className="font-mono font-bold text-amber-300">{th.price} 🪙</span>
                      <span className="font-mono text-[10px] text-slate-500">{th.txHash}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* --- TAB 4: SECURITY & REGULATORY NOTICE --- */}
        {activeTab === 'security' && (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 flex flex-col gap-5 max-w-2xl mx-auto">
            <div className="flex items-center gap-3">
              <ShieldCheck className="w-8 h-8 text-emerald-400" />
              <div>
                <h3 className="font-pixel text-base font-bold text-white">
                  KEAMANAN KEPEMILIKAN & STATUS REGULASI
                </h3>
                <span className="text-xs text-slate-400">Protokol Verifikasi Item & Sandbox Ekonomi</span>
              </div>
            </div>

            <div className="space-y-3 text-xs text-slate-300 leading-relaxed">
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                <h4 className="font-bold text-amber-300 mb-1">1. Keaslian & Anti-Duplikasi Item</h4>
                <p>
                  Setiap item yang ditambang, ditebang, dipancing, atau ditempa memiliki nomor seri kriptografi unik (Item Mint Hash). Sistem memastikan setiap barang memiliki riwayat kepemilikan transparan dan tidak dapat diduplikasi.
                </p>
              </div>

              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                <h4 className="font-bold text-amber-300 mb-1">2. Mata Uang Gold Dalam Game</h4>
                <p>
                  Semua transaksi perdagangan antar pemain saat ini menggunakan mata uang <strong>Gold</strong> dalam game, yang diperoleh murni dari aktivitas petualangan dan perdagangan.
                </p>
              </div>

              <div className="p-3 bg-amber-950/20 border border-amber-500/40 rounded-xl flex items-start gap-2.5">
                <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-amber-300 mb-1">3. Kepatuhan Marketplace Uang Asli (RMT)</h4>
                  <p className="text-slate-300">
                    Sesuai instruksi dan regulasi, sistem marketplace uang asli saat ini berada dalam tahap simulasi aman. Fitur uang fiat/asli hanya boleh diaktifkan setelah integrasi backend pembayaran, audit keamanan, dan perizinan terkait dinyatakan siap secara penuh.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
