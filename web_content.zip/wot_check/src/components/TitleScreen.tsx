import React, { useEffect } from 'react';
import { soundManager } from '../audio/soundManager';

interface TitleScreenProps {
  onStartGame: () => void;
  hasSavedGame: boolean;
  onContinueGame: () => void;
  onOpenMarketplace: () => void;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({
  onStartGame,
  hasSavedGame,
  onContinueGame,
  onOpenMarketplace,
}) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        soundManager.ensureContext();
        if (hasSavedGame) {
          onContinueGame();
        } else {
          onStartGame();
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [hasSavedGame, onContinueGame, onStartGame]);

  return (
    <div className="relative w-full h-screen bg-gradient-to-b from-[#38bdf8] via-[#7dd3fc] to-[#bae6fd] flex flex-col items-center justify-between p-6 sm:p-10 select-none overflow-hidden">
      {/* Growtopia Style Sky & Fluffy Pixel Clouds */}
      <div className="absolute inset-0 pointer-events-none">
        {/* Sun */}
        <div className="absolute top-8 right-12 w-20 h-20 rounded-full bg-yellow-300 border-4 border-yellow-400 shadow-xl" />
        {/* Clouds */}
        <div className="absolute top-16 left-12 w-48 h-12 bg-white/90 rounded-2xl shadow-sm" />
        <div className="absolute top-28 right-40 w-64 h-14 bg-white/85 rounded-2xl shadow-sm" />
        <div className="absolute top-44 left-1/3 w-56 h-12 bg-white/80 rounded-2xl shadow-sm" />
      </div>

      {/* Top Bar */}
      <div className="relative z-10 w-full max-w-4xl flex items-center justify-between text-xs sm:text-sm">
        <div className="flex items-center gap-2 bg-[#1b4f72] border-2 border-[#5dade2] px-3 py-1 rounded-lg text-white font-pixel font-bold">
          <span>🔒 WORLD OF TREASURES</span>
        </div>
        <button
          onClick={() => {
            soundManager.ensureContext();
            onOpenMarketplace();
          }}
          className="bg-[#f39c12] hover:bg-[#f1c40f] border-2 border-[#f9e79f] px-3.5 py-1.5 rounded-lg text-slate-950 font-pixel font-extrabold text-xs shadow-md active:scale-95 transition-transform cursor-pointer"
        >
          Growtopia Store & Marketplace
        </button>
      </div>

      {/* Hero Centerpiece: Growtopia Title Lockup */}
      <div className="relative z-10 flex flex-col items-center text-center my-auto">
        {/* Growtopia World Lock & Gem Icon Lockup */}
        <div className="mb-4 flex items-center gap-3">
          <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-[#78350f] border-4 border-[#facc15] shadow-2xl flex items-center justify-center text-4xl sm:text-5xl animate-bounce">
            🔒
          </div>
          <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-[#0e7490] border-4 border-[#38bdf8] shadow-2xl flex items-center justify-center text-3xl sm:text-4xl animate-pulse">
            💎
          </div>
        </div>

        {/* Chunky Beveled Title */}
        <div className="bg-[#154360] border-4 border-[#2980b9] rounded-2xl p-6 sm:p-8 shadow-2xl max-w-xl mx-4">
          <h1 className="font-pixel text-3xl sm:text-5xl font-black text-[#f1c40f] drop-shadow-[0_4px_0_#b7950b] tracking-wider">
            GROWTOPIA
          </h1>
          <h2 className="font-pixel text-lg sm:text-2xl font-extrabold text-white mt-1 drop-shadow-md">
            WORLD OF TREASURES
          </h2>
          <p className="mt-3 text-xs sm:text-sm text-[#d4e6f1] leading-relaxed font-medium">
            Game petualangan sandbox 2D ala Growtopia! Pukul dan pecahkan blok, tanam benih pohon benih, kumpulkan Gems & World Lock, dan bangun duniamu sendiri.
          </p>

          {/* Action Buttons (Growtopia Green & Yellow Style) */}
          <div className="mt-6 flex flex-col sm:flex-row items-center justify-center gap-3">
            {hasSavedGame && (
              <button
                onClick={() => {
                  soundManager.ensureContext();
                  onContinueGame();
                }}
                className="w-full sm:w-auto px-8 py-3 bg-[#27ae60] hover:bg-[#2ecc71] active:bg-[#229954] border-3 border-[#abebc6] text-white font-pixel font-black text-sm tracking-wide rounded-xl shadow-lg active:scale-95 transition-transform cursor-pointer"
              >
                LANJUTKAN DUNIA
              </button>
            )}

            <button
              onClick={() => {
                soundManager.ensureContext();
                onStartGame();
              }}
              className="w-full sm:w-auto px-8 py-3 bg-[#e67e22] hover:bg-[#f39c12] active:bg-[#d35400] border-3 border-[#f9e79f] text-white font-pixel font-black text-sm tracking-wide rounded-xl shadow-lg active:scale-95 transition-transform cursor-pointer"
            >
              {hasSavedGame ? 'MULAI BARU' : 'MULAI MAIN (PLAY)'}
            </button>
          </div>

          {/* Control Hint Line */}
          <div className="mt-5 text-[11px] text-[#aed6f1] font-semibold">
            <span>A/D Gerak</span>
            <span className="mx-2 text-[#5dade2]">·</span>
            <span>W/Spasi Lompat (Double Jump)</span>
            <span className="mx-2 text-[#5dade2]">·</span>
            <span>Klik Blok untuk Pukul/Pasang</span>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="relative z-10 text-center text-xs font-bold text-[#1b4f72]">
        World of Treasures · Edisi Sandbox Platformer Growtopia (Android & PC)
      </div>
    </div>
  );
};
