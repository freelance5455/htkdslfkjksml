import React, { useState } from 'react';
import { PlayerStats } from '../types/game';
import { CRAFTING_RECIPES, CraftingRecipe } from '../data/recipes';
import { ITEMS_DATABASE, RARITY_CONFIG } from '../data/items';
import { generateItemHash } from '../services/marketplaceService';
import { soundManager } from '../audio/soundManager';
import { X, Hammer, Check, AlertCircle } from 'lucide-react';

interface CraftingModalProps {
  playerStats: PlayerStats;
  onClose: () => void;
  onUpdateStats: (updater: (prev: PlayerStats) => PlayerStats) => void;
}

export const CraftingModal: React.FC<CraftingModalProps> = ({
  playerStats,
  onClose,
  onUpdateStats,
}) => {
  const [activeTab, setActiveTab] = useState<'all' | 'weapon' | 'tool' | 'potion'>('all');
  const [selectedRecipe, setSelectedRecipe] = useState<CraftingRecipe>(CRAFTING_RECIPES[0]);

  const filteredRecipes = activeTab === 'all' 
    ? CRAFTING_RECIPES 
    : CRAFTING_RECIPES.filter(r => r.category === activeTab);

  const getItemCount = (itemId: string): number => {
    return playerStats.inventory
      .filter(s => s && s.item.id === itemId)
      .reduce((sum, s) => sum + (s?.count || 0), 0);
  };

  const canCraft = (recipe: CraftingRecipe): boolean => {
    if (playerStats.level < recipe.levelRequired) return false;
    for (const ing of recipe.ingredients) {
      if (getItemCount(ing.itemId) < ing.count) return false;
    }
    return true;
  };

  const handleCraft = (recipe: CraftingRecipe) => {
    if (!canCraft(recipe)) return;

    soundManager.playMine();
    const resultItem = ITEMS_DATABASE[recipe.resultItemId];

    onUpdateStats(prev => {
      const inv = [...prev.inventory];

      // Deduct ingredients
      recipe.ingredients.forEach(ing => {
        let needed = ing.count;
        for (let i = 0; i < inv.length; i++) {
          const slot = inv[i];
          if (slot && slot.item.id === ing.itemId) {
            if (slot.count > needed) {
              slot.count -= needed;
              needed = 0;
              break;
            } else {
              needed -= slot.count;
              inv[i] = null;
            }
          }
          if (needed <= 0) break;
        }
      });

      // Add crafted item
      const emptySlotIndex = inv.findIndex(s => s === null);
      if (emptySlotIndex !== -1) {
        inv[emptySlotIndex] = {
          item: resultItem,
          count: recipe.resultCount,
          hash: generateItemHash(resultItem.id),
          obtainedAt: Date.now(),
        };
      }

      return {
        ...prev,
        inventory: inv,
        xp: prev.xp + 40 * recipe.levelRequired,
        statsRecord: {
          ...prev.statsRecord,
          itemsCrafted: prev.statsRecord.itemsCrafted + 1,
        },
      };
    });
  };

  const targetItem = ITEMS_DATABASE[selectedRecipe.resultItemId];
  const targetRarity = targetItem ? RARITY_CONFIG[targetItem.rarity] : null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/65 backdrop-blur-xs select-none">
      <div className="relative w-full max-w-3xl bg-[#154360] border-4 border-[#2980b9] rounded-2xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-3.5 bg-[#1b4f72] border-b-2 border-[#2874a6]">
          <div className="flex items-center gap-2">
            <span className="text-xl">🌱</span>
            <h2 className="font-pixel text-base font-extrabold text-white tracking-wider">
              GROWTOPIA SPLICING & BENGKEL TEMPA
            </h2>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-[#c0392b] hover:bg-[#e74c3c] border border-[#f1948a] text-white flex items-center justify-center font-bold cursor-pointer transition-transform active:scale-95"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filter Tabs */}
        <div className="flex items-center gap-2 px-6 py-2.5 bg-[#0e2f44] border-b-2 border-[#1b4f72] text-xs">
          {(['all', 'material', 'weapon', 'tool', 'potion'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab as any)}
              className={`px-3 py-1.5 rounded-lg font-pixel font-bold capitalize transition-colors cursor-pointer ${
                activeTab === tab
                  ? 'bg-[#f39c12] text-slate-950'
                  : 'text-[#aed6f1] hover:bg-[#1b4f72]'
              }`}
            >
              {tab === 'all' ? 'Semua' : tab === 'material' ? '🌱 Splicing Benih' : tab === 'weapon' ? '⚔️ Senjata' : tab === 'tool' ? '⛏️ Alat' : '🧪 Ramuan'}
            </button>
          ))}
        </div>

        {/* Body: Recipes list + Recipe Inspector */}
        <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6 overflow-y-auto">
          {/* Recipes List */}
          <div className="flex flex-col gap-2">
            {filteredRecipes.map(recipe => {
              const item = ITEMS_DATABASE[recipe.resultItemId];
              const isSelected = selectedRecipe.id === recipe.id;
              const craftable = canCraft(recipe);
              const rStyle = RARITY_CONFIG[item.rarity];

              return (
                <button
                  key={recipe.id}
                  onClick={() => setSelectedRecipe(recipe)}
                  className={`p-3 rounded-xl border flex items-center justify-between text-left transition-all cursor-pointer ${
                    isSelected
                      ? 'border-amber-400 bg-amber-950/30 ring-1 ring-amber-400/50'
                      : 'border-slate-800 bg-slate-950/50 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{item.icon}</span>
                    <div>
                      <h4 className="font-semibold text-xs text-white">{recipe.nameId || recipe.name}</h4>
                      <span className="text-[10px] font-bold" style={{ color: rStyle.color }}>
                        {rStyle.labelId}
                      </span>
                    </div>
                  </div>

                  {craftable ? (
                    <span className="text-[10px] bg-emerald-950/80 text-emerald-400 border border-emerald-800/60 px-2 py-0.5 rounded font-bold">
                      Siap Dibuat
                    </span>
                  ) : (
                    <span className="text-[10px] text-slate-500 font-mono">
                      Bahan Kurang
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Recipe Details & Crafting Action */}
          <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-5 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className={`w-14 h-14 rounded-xl border flex items-center justify-center text-3xl ${targetRarity?.border} ${targetRarity?.bg}`}>
                  {targetItem?.icon}
                </div>
                <div>
                  <h3 className="font-pixel text-sm font-bold text-white">
                    {selectedRecipe.nameId || selectedRecipe.name}
                  </h3>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className="text-[10px] font-bold" style={{ color: targetRarity?.color }}>
                      {targetRarity?.labelId}
                    </span>
                    <span className="text-[10px] text-slate-400">· Syarat Level: {selectedRecipe.levelRequired}</span>
                  </div>
                </div>
              </div>

              <p className="text-xs text-slate-300 mb-4">{selectedRecipe.description}</p>

              {/* Ingredients Checklist */}
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Bahan yang Dibutuhkan:</h4>
              <div className="flex flex-col gap-2">
                {selectedRecipe.ingredients.map(ing => {
                  const ingItem = ITEMS_DATABASE[ing.itemId];
                  const has = getItemCount(ing.itemId);
                  const isEnough = has >= ing.count;

                  return (
                    <div
                      key={ing.itemId}
                      className={`flex items-center justify-between p-2 rounded-lg border text-xs ${
                        isEnough
                          ? 'bg-emerald-950/20 border-emerald-800/30 text-slate-200'
                          : 'bg-red-950/20 border-red-800/30 text-slate-400'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span className="text-base">{ingItem?.icon}</span>
                        <span>{ingItem?.nameId || ingItem?.name}</span>
                      </div>
                      <div className="flex items-center gap-1.5 font-mono font-bold">
                        <span className={isEnough ? 'text-emerald-400' : 'text-red-400'}>
                          {has}/{ing.count}
                        </span>
                        {isEnough ? (
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <AlertCircle className="w-3.5 h-3.5 text-red-400" />
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Craft Button */}
            <div className="mt-6">
              <button
                onClick={() => handleCraft(selectedRecipe)}
                disabled={!canCraft(selectedRecipe)}
                className={`w-full py-3 rounded-xl font-pixel font-bold text-xs tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer ${
                  canCraft(selectedRecipe)
                    ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-lg shadow-amber-500/20 active:scale-98'
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                }`}
              >
                <Hammer className="w-4 h-4" />
                <span>TEMPA BARANG (CRAFT)</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
