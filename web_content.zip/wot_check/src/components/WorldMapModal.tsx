import React from 'react';
import { ZoneId, PlayerStats } from '../types/game';
import { ZONES } from '../data/worldMap';
import { X, MapPin, Lock, Navigation } from 'lucide-react';
import { soundManager } from '../audio/soundManager';

interface WorldMapModalProps {
  currentZone: ZoneId;
  playerStats: PlayerStats;
  onClose: () => void;
  onFastTravel: (zoneId: ZoneId) => void;
}

export const WorldMapModal: React.FC<WorldMapModalProps> = ({
  currentZone,
  playerStats,
  onClose,
  onFastTravel,
}) => {
  const zonesList: ZoneId[] = ['starter_village', 'mystic_forest', 'crystal_cave', 'ancient_ruins'];

  const zoneVisuals: Record<ZoneId, { icon: string; bg: string; border: string }> = {
    starter_village: {
      icon: '🏡',
      bg: 'bg-emerald-950/60',
      border: 'border-emerald-600/40',
    },
    mystic_forest: {
      icon: '🌲',
      bg: 'bg-green-950/60',
      border: 'border-green-600/40',
    },
    crystal_cave: {
      icon: '💎',
      bg: 'bg-blue-950/60',
      border: 'border-blue-600/40',
    },
    ancient_ruins: {
      icon: '🏛️',
      bg: 'bg-purple-950/60',
      border: 'border-purple-600/40',
    },
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/65 backdrop-blur-xs select-none">
      <div className="relative w-full max-w-3xl bg-[#154360] border-4 border-[#2980b9] rounded-2xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-3.5 bg-[#1b4f72] border-b-2 border-[#2874a6]">
          <div className="flex items-center gap-3">
            <span className="text-xl">🚪</span>
            <div>
              <h2 className="font-pixel text-base font-extrabold text-white tracking-wider">
                GROWTOPIA WORLDS (DOORS & PETA)
              </h2>
              <span className="text-[10px] text-[#f9e79f] font-semibold">Daftar World Portal & Fast Travel</span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-[#c0392b] hover:bg-[#e74c3c] border border-[#f1948a] text-white flex items-center justify-center font-bold cursor-pointer transition-transform active:scale-95"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Map Grid */}
        <div className="p-6 grid grid-cols-1 sm:grid-cols-2 gap-4 overflow-y-auto">
          {zonesList.map(zid => {
            const z = ZONES[zid];
            const isCurrent = currentZone === zid;
            const isUnlocked = playerStats.level >= z.levelRequirement || playerStats.unlockedZones.includes(zid);
            const vis = zoneVisuals[zid];

            return (
              <div
                key={zid}
                className={`p-5 rounded-2xl border flex flex-col justify-between gap-4 transition-all ${
                  isCurrent
                    ? 'border-amber-400 bg-amber-950/20 ring-2 ring-amber-400/50 shadow-lg'
                    : isUnlocked
                    ? `${vis.border} ${vis.bg} hover:border-slate-500`
                    : 'border-slate-800 bg-slate-950/60 opacity-60'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2.5">
                      <span className="text-2xl">{vis.icon}</span>
                      <h3 className="font-pixel text-sm font-bold text-white">
                        {z.nameId}
                      </h3>
                    </div>
                    {isCurrent && (
                      <span className="flex items-center gap-1 text-[10px] font-bold bg-amber-400 text-slate-950 px-2 py-0.5 rounded-full">
                        <MapPin className="w-3 h-3" /> Lokasi Anda
                      </span>
                    )}
                    {!isUnlocked && (
                      <span className="flex items-center gap-1 text-[10px] font-bold bg-slate-800 text-slate-400 px-2 py-0.5 rounded-full">
                        <Lock className="w-3 h-3" /> Butuh Lvl {z.levelRequirement}
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {z.description}
                  </p>
                </div>

                {/* Fast Travel Button */}
                <div className="pt-3 border-t border-slate-800/60 flex items-center justify-between">
                  <span className="text-[10px] text-slate-400">
                    Syarat Level: <span className="font-mono text-white">Lvl {z.levelRequirement}</span>
                  </span>

                  {isCurrent ? (
                    <span className="text-xs font-semibold text-amber-400">Sedang Di Sini</span>
                  ) : isUnlocked ? (
                    <button
                      onClick={() => {
                        soundManager.playZoneBGM(z.bgmTheme);
                        onFastTravel(zid);
                        onClose();
                      }}
                      className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-lg flex items-center gap-1 active:scale-95 transition-transform cursor-pointer"
                    >
                      <Navigation className="w-3.5 h-3.5" />
                      <span>Jelajahi Wilayah</span>
                    </button>
                  ) : (
                    <button
                      disabled
                      className="px-3 py-1.5 bg-slate-800 text-slate-500 font-bold text-xs rounded-lg cursor-not-allowed"
                    >
                      Terkunci
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
