import React, { useState } from 'react';
import { PlayerStats } from '../types/game';
import { ITEMS_DATABASE, RARITY_CONFIG } from '../data/items';
import { soundManager } from '../audio/soundManager';
import { generateItemHash } from '../services/marketplaceService';
import { X, ShoppingBag, Coins, Lock, Sparkles } from 'lucide-react';

interface ShopModalProps {
  playerStats: PlayerStats;
  onClose: () => void;
  onUpdateStats: (updater: (prev: PlayerStats) => PlayerStats) => void;
}

export const ShopModal: React.FC<ShopModalProps> = ({
  playerStats,
  onClose,
  onUpdateStats,
}) => {
  const [activeTab, setActiveTab] = useState<'store' | 'sell'>('store');

  // Growtopia Store Items (Purchasable with Gems or Gold)
  const storePacks = [
    { itemId: 'world_lock', gemCost: 2000, goldCost: 500, label: 'World Lock (WL)', icon: '🔒', desc: 'Kunci seluruh dunia Growtopia!' },
    { itemId: 'diamond_lock', gemCost: 200000, goldCost: 50000, label: 'Diamond Lock (DL)', icon: '💎🔒', desc: 'Worth 100 World Locks.' },
    { itemId: 'seed_dirt', gemCost: 20, goldCost: 5, label: 'Bibit Pohon Tanah x5', count: 5, icon: '🌱', desc: 'Tumbuh cepat dan hasilkan blok tanah & gems.' },
    { itemId: 'seed_rock', gemCost: 50, goldCost: 12, label: 'Bibit Pohon Batu x5', count: 5, icon: '🪨🌱', desc: 'Hasilkan batu keras dan gems melimpah.' },
    { itemId: 'seed_wood', gemCost: 120, goldCost: 30, label: 'Bibit Pohon Kayu x3', count: 3, icon: '🌲🌱', desc: 'Kayu bangunan Growtopia.' },
    { itemId: 'seed_lava', gemCost: 400, goldCost: 90, label: 'Bibit Pohon Lava x2', count: 2, icon: '🔥🌱', desc: 'Hasilkan blok lava berapi.' },
    { itemId: 'seed_amethyst', gemCost: 1200, goldCost: 250, label: 'Bibit Kristal Amethyst', count: 1, icon: '🔮🌱', desc: 'Pohon kristal permata langka.' },
    { itemId: 'potion_health', gemCost: 80, goldCost: 20, label: 'Ramuan HP x2', count: 2, icon: '🧪', desc: 'Memulihkan 50 HP.' },
  ];

  const handleBuyWithGems = (pack: typeof storePacks[0]) => {
    if (playerStats.gems < pack.gemCost) return;
    const item = ITEMS_DATABASE[pack.itemId];
    if (!item) return;

    soundManager.playCoin();
    const addCount = pack.count || 1;

    onUpdateStats(prev => {
      const inv = [...prev.inventory];
      const existing = item.stackable ? inv.find(s => s && s.item.id === item.id) : null;

      if (existing) {
        existing.count += addCount;
      } else {
        const emptyIdx = inv.findIndex(s => s === null);
        if (emptyIdx !== -1) {
          inv[emptyIdx] = {
            item,
            count: addCount,
            hash: generateItemHash(item.id),
            obtainedAt: Date.now(),
          };
        } else {
          return prev;
        }
      }

      // If buying World Lock, increment worldLocks counter too!
      const nextWLs = pack.itemId === 'world_lock' ? prev.worldLocks + 1 : prev.worldLocks;

      return {
        ...prev,
        gems: prev.gems - pack.gemCost,
        worldLocks: nextWLs,
        inventory: inv,
      };
    });
  };

  const handleSellSlot = (slotIndex: number) => {
    const slot = playerStats.inventory[slotIndex];
    if (!slot) return;

    const gemsEarned = Math.max(1, Math.round(slot.item.value * 2.5 * slot.count));
    soundManager.playGemCollect();

    onUpdateStats(prev => {
      const inv = [...prev.inventory];
      inv[slotIndex] = null;
      return {
        ...prev,
        gems: prev.gems + gemsEarned,
        inventory: inv,
      };
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/65 backdrop-blur-xs select-none">
      <div className="relative w-full max-w-2xl bg-[#154360] border-4 border-[#2980b9] rounded-2xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-3.5 bg-[#1b4f72] border-b-2 border-[#2874a6]">
          <div className="flex items-center gap-2">
            <span className="text-2xl">🏪</span>
            <div>
              <h2 className="font-pixel text-base font-extrabold text-white tracking-wider">
                GROWTOPIA STORE & TOKO
              </h2>
              <span className="text-[10px] text-[#f9e79f] font-semibold">Beli World Lock, Bibit Pohon & Blok</span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 bg-[#0e2f44] px-3 py-1 rounded-lg border border-[#2980b9]">
              <span className="text-base leading-none">💎</span>
              <span className="font-pixel font-bold text-[#f9e79f] text-xs">
                {playerStats.gems.toLocaleString()}
              </span>
            </div>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-lg bg-[#c0392b] hover:bg-[#e74c3c] border border-[#f1948a] text-white flex items-center justify-center font-bold cursor-pointer transition-transform active:scale-95"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Controls */}
        <div className="flex items-center justify-between px-6 py-2.5 bg-[#0e2f44] border-b-2 border-[#1b4f72]">
          <div className="flex items-center gap-2 text-xs">
            <button
              onClick={() => setActiveTab('store')}
              className={`px-4 py-1.5 rounded-lg font-pixel font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
                activeTab === 'store'
                  ? 'bg-[#f39c12] text-slate-950'
                  : 'text-[#aed6f1] hover:bg-[#1b4f72]'
              }`}
            >
              <ShoppingBag className="w-3.5 h-3.5" /> Toko Gems (Store)
            </button>
            <button
              onClick={() => setActiveTab('sell')}
              className={`px-4 py-1.5 rounded-lg font-pixel font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
                activeTab === 'sell'
                  ? 'bg-[#f39c12] text-slate-950'
                  : 'text-[#aed6f1] hover:bg-[#1b4f72]'
              }`}
            >
              <Coins className="w-3.5 h-3.5" /> Tukar Blok/Hasil Menjadi Gems
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto max-h-[60vh]">
          {activeTab === 'store' ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {storePacks.map(pack => {
                const canAfford = playerStats.gems >= pack.gemCost;

                return (
                  <div
                    key={pack.itemId}
                    className="p-3 bg-[#1b4f72] border-2 border-[#2874a6] hover:border-[#5dade2] rounded-xl flex items-center justify-between gap-3 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-xl bg-[#154360] border-2 border-[#2980b9] flex items-center justify-center text-3xl shrink-0">
                        {pack.icon}
                      </div>
                      <div>
                        <h4 className="font-pixel text-xs font-bold text-white">{pack.label}</h4>
                        <p className="text-[10px] text-[#aed6f1] line-clamp-1">{pack.desc}</p>
                      </div>
                    </div>

                    <button
                      onClick={() => handleBuyWithGems(pack)}
                      disabled={!canAfford}
                      className={`px-3 py-1.5 rounded-xl font-pixel text-xs font-extrabold flex items-center gap-1 transition-all cursor-pointer ${
                        canAfford
                          ? 'bg-[#27ae60] hover:bg-[#2ecc71] border-2 border-[#a9dfbf] text-white active:scale-95 shadow-md'
                          : 'bg-[#2c3e50] text-[#7f8c8d] border border-slate-700 cursor-not-allowed'
                      }`}
                    >
                      <span>{pack.gemCost.toLocaleString()}</span>
                      <span>💎</span>
                    </button>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="flex flex-col gap-2">
              {playerStats.inventory.filter(Boolean).length === 0 ? (
                <div className="text-center py-12 text-[#aed6f1] text-xs">
                  Tas Anda kosong. Pukul blok di world untuk mendapatkan blok tanah, batu, kayu atau kristal!
                </div>
              ) : (
                playerStats.inventory.map((slot, idx) => {
                  if (!slot) return null;
                  const item = slot.item;
                  const gemsValue = Math.max(1, Math.round(item.value * 2.5 * slot.count));

                  return (
                    <div
                      key={idx}
                      className="p-3 bg-[#1b4f72] border-2 border-[#2874a6] rounded-xl flex items-center justify-between"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-[#154360] border border-[#2980b9] flex items-center justify-center text-xl">
                          {item.icon}
                        </div>
                        <div>
                          <div className="flex items-center gap-1.5">
                            <h4 className="font-semibold text-xs text-white">{item.nameId || item.name}</h4>
                            <span className="text-[10px] font-mono text-[#f9e79f]">x{slot.count}</span>
                          </div>
                          <span className="text-[10px] text-[#aed6f1]">{item.category}</span>
                        </div>
                      </div>

                      <button
                        onClick={() => handleSellSlot(idx)}
                        className="px-3.5 py-1.5 bg-[#f39c12] hover:bg-[#f1c40f] border-2 border-[#f9e79f] text-slate-950 font-pixel font-bold text-xs rounded-xl flex items-center gap-1.5 active:scale-95 transition-transform cursor-pointer shadow-md"
                      >
                        <span>Tukar (+{gemsValue} 💎)</span>
                      </button>
                    </div>
                  );
                })
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
