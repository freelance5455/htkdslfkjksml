import { ZoneConfig, ZoneId, ResourceNode, Monster, NPC } from '../types/game';

export const ZONES: Record<ZoneId, ZoneConfig> = {
  starter_village: {
    id: 'starter_village',
    name: 'Starter Village (Desa Permulaan)',
    nameId: 'Desa Permulaan',
    description: 'Desa yang tenang dan damai, pusat perdagangan, lahan pertanian subur, dan kolam ikan.',
    width: 32,
    height: 24,
    bgmTheme: 'village',
    ambientColor: 'rgba(255, 245, 220, 0.05)',
    levelRequirement: 1,
  },
  mystic_forest: {
    id: 'mystic_forest',
    name: 'Mystic Forest (Hutan Mistis)',
    nameId: 'Hutan Mistis',
    description: 'Hutan lebat dengan pohon-pohon kuno, kayu berkualitas tinggi, dan satwa liar.',
    width: 36,
    height: 28,
    bgmTheme: 'forest',
    ambientColor: 'rgba(34, 197, 94, 0.08)',
    levelRequirement: 2,
  },
  crystal_cave: {
    id: 'crystal_cave',
    name: 'Crystal Cave (Gua Kristal)',
    nameId: 'Gua Kristal',
    description: 'Gua bawah tanah berkilauan dengan deposit besi, emas, kristal amethyst, dan monster golem.',
    width: 36,
    height: 28,
    bgmTheme: 'cave',
    ambientColor: 'rgba(59, 130, 246, 0.12)',
    levelRequirement: 3,
  },
  ancient_ruins: {
    id: 'ancient_ruins',
    name: 'Ancient Ruins (Reruntuhan Kuno)',
    nameId: 'Reruntuhan Kuno',
    description: 'Situs peradaban masa lalu penuh artefak legendaris, pilar kuno, dan penjaga abadi.',
    width: 34,
    height: 26,
    bgmTheme: 'ruins',
    ambientColor: 'rgba(168, 85, 247, 0.12)',
    levelRequirement: 4,
  },
};

export const INITIAL_NPCS: NPC[] = [
  {
    id: 'npc_mayor',
    name: 'Mayor Alden',
    role: 'Kepala Desa & Petualangan',
    x: 15,
    y: 8,
    zone: 'starter_village',
    avatar: '👨‍🌾',
    dialogue: [
      'Selamat datang di World of Treasures, petualang muda!',
      'Desa kami mengandalkan perdagangan sumber daya. Tebang pohon, tanam tanaman, dan pancing ikan!',
      'Gunakan emas hasil perdaganganmu untuk memperkuat peralatan di bengkel Thorne.',
    ],
    type: 'mayor',
  },
  {
    id: 'npc_merchant',
    name: 'Merchant Finn',
    role: 'Pedagang Pasar Desa',
    x: 18,
    y: 9,
    zone: 'starter_village',
    avatar: '🧙‍♂️',
    dialogue: [
      'Koin emas membuat dunia berputar! Mau membeli bibit atau menjual hasil panenmu?',
      'Aku menerima semua hasil tambang, kayu, ikan, dan barang langka dengan harga pasaran terbaik!',
    ],
    type: 'merchant',
  },
  {
    id: 'npc_blacksmith',
    name: 'Blacksmith Thorne',
    role: 'Penempa & Perajin Logam',
    x: 8,
    y: 14,
    zone: 'starter_village',
    avatar: '⚒️',
    dialogue: [
      'Bawa bijih besi dan kayu berkualitas ke anvi-ku, dan aku akan tempa peralatan berkekuatan dahsyat!',
      'Peralatan berkualitas tinggi memotong kayu dan menambang batu jauh lebih cepat.',
    ],
    type: 'blacksmith',
  },
  {
    id: 'npc_elder',
    name: 'Elder Vaelin',
    role: 'Penjaga Portal & Pengetahuan',
    x: 28,
    y: 12,
    zone: 'starter_village',
    avatar: '🧓',
    dialogue: [
      'Jalur timur mengarah ke Mystic Forest, utara ke Gua Kristal, dan lebih jauh lagi terdapat Reruntuhan Kuno.',
      'Di sana tersimpan harta karun berkekuatan mitos yang belum pernah disentuh manusia selama ribuan tahun.',
    ],
    type: 'elder',
  },
];

export function getInitialNodes(): ResourceNode[] {
  return [
    // --- STARTER VILLAGE NODES ---
    // Trees
    { id: 'v_tree_1', type: 'tree_oak', x: 4, y: 5, zone: 'starter_village', hp: 30, maxHp: 30, respawnTime: 20000 },
    { id: 'v_tree_2', type: 'tree_oak', x: 5, y: 7, zone: 'starter_village', hp: 30, maxHp: 30, respawnTime: 20000 },
    { id: 'v_tree_3', type: 'tree_oak', x: 10, y: 4, zone: 'starter_village', hp: 30, maxHp: 30, respawnTime: 20000 },
    { id: 'v_tree_4', type: 'tree_oak', x: 26, y: 6, zone: 'starter_village', hp: 30, maxHp: 30, respawnTime: 20000 },
    { id: 'v_tree_5', type: 'tree_oak', x: 27, y: 9, zone: 'starter_village', hp: 30, maxHp: 30, respawnTime: 20000 },
    
    // Rocks
    { id: 'v_rock_1', type: 'rock_stone', x: 5, y: 18, zone: 'starter_village', hp: 40, maxHp: 40, respawnTime: 25000 },
    { id: 'v_rock_2', type: 'rock_stone', x: 7, y: 19, zone: 'starter_village', hp: 40, maxHp: 40, respawnTime: 25000 },
    { id: 'v_rock_3', type: 'rock_iron', x: 11, y: 19, zone: 'starter_village', hp: 60, maxHp: 60, respawnTime: 35000 },

    // Farm Plots (ready to till / plant)
    { id: 'v_farm_1', type: 'farm_plot', x: 19, y: 15, zone: 'starter_village', hp: 1, maxHp: 1, respawnTime: 1000, farmState: { tilled: true, plantedSeedId: 'seed_wheat', plantedAt: Date.now() - 25000, growDurationMs: 20000, watered: true, ready: true } },
    { id: 'v_farm_2', type: 'farm_plot', x: 20, y: 15, zone: 'starter_village', hp: 1, maxHp: 1, respawnTime: 1000, farmState: { tilled: true, plantedSeedId: 'seed_carrot', plantedAt: Date.now() - 30000, growDurationMs: 25000, watered: true, ready: true } },
    { id: 'v_farm_3', type: 'farm_plot', x: 19, y: 16, zone: 'starter_village', hp: 1, maxHp: 1, respawnTime: 1000, farmState: { tilled: true, watered: false, ready: false } },
    { id: 'v_farm_4', type: 'farm_plot', x: 20, y: 16, zone: 'starter_village', hp: 1, maxHp: 1, respawnTime: 1000, farmState: { tilled: false, watered: false, ready: false } },
    { id: 'v_farm_5', type: 'farm_plot', x: 21, y: 15, zone: 'starter_village', hp: 1, maxHp: 1, respawnTime: 1000, farmState: { tilled: false, watered: false, ready: false } },
    { id: 'v_farm_6', type: 'farm_plot', x: 21, y: 16, zone: 'starter_village', hp: 1, maxHp: 1, respawnTime: 1000, farmState: { tilled: false, watered: false, ready: false } },

    // Fishing Pond spot
    { id: 'v_fish_1', type: 'fishing_spot', x: 6, y: 10, zone: 'starter_village', hp: 999, maxHp: 999, respawnTime: 5000 },
    { id: 'v_fish_2', type: 'fishing_spot', x: 7, y: 11, zone: 'starter_village', hp: 999, maxHp: 999, respawnTime: 5000 },

    // Starter Welcome Chest
    { id: 'v_chest_1', type: 'chest', x: 13, y: 6, zone: 'starter_village', hp: 1, maxHp: 1, respawnTime: 9999999, chestOpened: false, chestLoot: [{ itemId: 'wood_oak', count: 5 }, { itemId: 'seed_wheat', count: 3 }] },

    // --- MYSTIC FOREST NODES ---
    { id: 'f_tree_1', type: 'tree_pine', x: 6, y: 7, zone: 'mystic_forest', hp: 50, maxHp: 50, respawnTime: 25000 },
    { id: 'f_tree_2', type: 'tree_pine', x: 8, y: 9, zone: 'mystic_forest', hp: 50, maxHp: 50, respawnTime: 25000 },
    { id: 'f_tree_3', type: 'tree_mystic', x: 16, y: 8, zone: 'mystic_forest', hp: 90, maxHp: 90, respawnTime: 40000 },
    { id: 'f_tree_4', type: 'tree_mystic', x: 20, y: 12, zone: 'mystic_forest', hp: 90, maxHp: 90, respawnTime: 40000 },
    { id: 'f_tree_5', type: 'tree_oak', x: 28, y: 7, zone: 'mystic_forest', hp: 35, maxHp: 35, respawnTime: 20000 },
    { id: 'f_tree_6', type: 'tree_mystic', x: 26, y: 19, zone: 'mystic_forest', hp: 90, maxHp: 90, respawnTime: 40000 },
    { id: 'f_tree_7', type: 'tree_pine', x: 10, y: 22, zone: 'mystic_forest', hp: 50, maxHp: 50, respawnTime: 25000 },
    
    // Forest River Fishing
    { id: 'f_fish_1', type: 'fishing_spot', x: 15, y: 20, zone: 'mystic_forest', hp: 999, maxHp: 999, respawnTime: 5000 },
    { id: 'f_fish_2', type: 'fishing_spot', x: 17, y: 21, zone: 'mystic_forest', hp: 999, maxHp: 999, respawnTime: 5000 },

    // Forest Hidden Chest
    { id: 'f_chest_1', type: 'chest', x: 30, y: 23, zone: 'mystic_forest', hp: 1, maxHp: 1, respawnTime: 9999999, chestOpened: false, chestLoot: [{ itemId: 'wood_mystic', count: 4 }, { itemId: 'potion_energy', count: 1 }, { itemId: 'seed_sunberry', count: 2 }] },

    // --- CRYSTAL CAVE NODES ---
    { id: 'c_rock_1', type: 'rock_stone', x: 6, y: 6, zone: 'crystal_cave', hp: 40, maxHp: 40, respawnTime: 25000 },
    { id: 'c_rock_2', type: 'rock_iron', x: 9, y: 7, zone: 'crystal_cave', hp: 60, maxHp: 60, respawnTime: 30000 },
    { id: 'c_rock_3', type: 'rock_gold', x: 14, y: 9, zone: 'crystal_cave', hp: 80, maxHp: 80, respawnTime: 40000 },
    { id: 'c_rock_4', type: 'rock_amethyst', x: 22, y: 8, zone: 'crystal_cave', hp: 100, maxHp: 100, respawnTime: 50000 },
    { id: 'c_rock_5', type: 'rock_crystal', x: 28, y: 14, zone: 'crystal_cave', hp: 140, maxHp: 140, respawnTime: 65000 },
    { id: 'c_rock_6', type: 'rock_iron', x: 18, y: 20, zone: 'crystal_cave', hp: 60, maxHp: 60, respawnTime: 30000 },
    { id: 'c_rock_7', type: 'rock_gold', x: 8, y: 22, zone: 'crystal_cave', hp: 80, maxHp: 80, respawnTime: 40000 },

    // Subterranean Glowing Spring Fishing
    { id: 'c_fish_1', type: 'fishing_spot', x: 25, y: 22, zone: 'crystal_cave', hp: 999, maxHp: 999, respawnTime: 5000 },

    // Cave Treasure Chest
    { id: 'c_chest_1', type: 'chest', x: 31, y: 8, zone: 'crystal_cave', hp: 1, maxHp: 1, respawnTime: 9999999, chestOpened: false, chestLoot: [{ itemId: 'gem_amethyst', count: 2 }, { itemId: 'ore_gold', count: 4 }, { itemId: 'crystal_star', count: 1 }] },

    // --- ANCIENT RUINS NODES ---
    { id: 'r_pillar_1', type: 'ruin_pillar', x: 8, y: 8, zone: 'ancient_ruins', hp: 150, maxHp: 150, respawnTime: 60000 },
    { id: 'r_pillar_2', type: 'ruin_pillar', x: 25, y: 8, zone: 'ancient_ruins', hp: 150, maxHp: 150, respawnTime: 60000 },
    { id: 'r_pillar_3', type: 'ruin_pillar', x: 8, y: 18, zone: 'ancient_ruins', hp: 150, maxHp: 150, respawnTime: 60000 },
    { id: 'r_pillar_4', type: 'ruin_pillar', x: 25, y: 18, zone: 'ancient_ruins', hp: 150, maxHp: 150, respawnTime: 60000 },

    // Mythic Relic Chest
    { id: 'r_chest_mythic', type: 'chest', x: 17, y: 7, zone: 'ancient_ruins', hp: 1, maxHp: 1, respawnTime: 9999999, chestOpened: false, chestLoot: [{ itemId: 'crown_of_antiquity', count: 1 }, { itemId: 'heart_of_eternity', count: 1 }, { itemId: 'ancient_relic_shard', count: 3 }] },
  ];
}

export function getInitialMonsters(): Monster[] {
  return [
    // --- MYSTIC FOREST MONSTERS ---
    {
      id: 'm_boar_1',
      name: 'Wild Boar (Babi Hutan)',
      type: 'boar',
      x: 12 * 32,
      y: 12 * 32,
      zone: 'mystic_forest',
      hp: 45,
      maxHp: 45,
      speed: 1.1,
      damage: 8,
      xpReward: 35,
      goldReward: 14,
      drops: [
        { itemId: 'meat_beast', chance: 0.9, min: 1, max: 2 },
        { itemId: 'pelt_wolf', chance: 0.3, min: 1, max: 1 },
      ],
      direction: 'down',
      animFrame: 0,
      patrolCenter: { x: 12 * 32, y: 12 * 32 },
      state: 'patrol',
      hitTimer: 0,
    },
    {
      id: 'm_wolf_1',
      name: 'Shadow Wolf (Serigala Bayangan)',
      type: 'wolf',
      x: 22 * 32,
      y: 16 * 32,
      zone: 'mystic_forest',
      hp: 65,
      maxHp: 65,
      speed: 1.4,
      damage: 14,
      xpReward: 55,
      goldReward: 22,
      drops: [
        { itemId: 'pelt_wolf', chance: 0.85, min: 1, max: 2 },
        { itemId: 'meat_beast', chance: 0.5, min: 1, max: 2 },
      ],
      direction: 'left',
      animFrame: 0,
      patrolCenter: { x: 22 * 32, y: 16 * 32 },
      state: 'patrol',
      hitTimer: 0,
    },

    // --- CRYSTAL CAVE MONSTERS ---
    {
      id: 'm_golem_1',
      name: 'Crystal Golem (Golem Kristal)',
      type: 'crystal_golem',
      x: 16 * 32,
      y: 14 * 32,
      zone: 'crystal_cave',
      hp: 110,
      maxHp: 110,
      speed: 0.9,
      damage: 22,
      xpReward: 90,
      goldReward: 45,
      drops: [
        { itemId: 'golem_core', chance: 0.8, min: 1, max: 1 },
        { itemId: 'gem_amethyst', chance: 0.45, min: 1, max: 2 },
        { itemId: 'crystal_star', chance: 0.15, min: 1, max: 1 },
      ],
      direction: 'right',
      animFrame: 0,
      patrolCenter: { x: 16 * 32, y: 14 * 32 },
      state: 'patrol',
      hitTimer: 0,
    },

    // --- ANCIENT RUINS MONSTERS ---
    {
      id: 'm_guardian_1',
      name: 'Ancient Titan Guardian (Penjaga Reruntuhan Kuno)',
      type: 'ancient_guardian',
      x: 17 * 32,
      y: 13 * 32,
      zone: 'ancient_ruins',
      hp: 220,
      maxHp: 220,
      speed: 1.0,
      damage: 35,
      xpReward: 250,
      goldReward: 120,
      drops: [
        { itemId: 'ancient_relic_shard', chance: 1.0, min: 1, max: 3 },
        { itemId: 'heart_of_eternity', chance: 0.25, min: 1, max: 1 },
        { itemId: 'crystal_star', chance: 0.6, min: 1, max: 2 },
      ],
      direction: 'down',
      animFrame: 0,
      patrolCenter: { x: 17 * 32, y: 13 * 32 },
      state: 'patrol',
      hitTimer: 0,
    },
  ];
}
