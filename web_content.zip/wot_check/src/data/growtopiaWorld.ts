import { WorldTile, ZoneId, BlockType } from '../types/game';

export const WORLD_WIDTH = 54;
export const WORLD_HEIGHT = 28;

export function generateGrowtopiaWorld(zone: ZoneId): WorldTile[][] {
  const grid: WorldTile[][] = [];

  for (let y = 0; y < WORLD_HEIGHT; y++) {
    const row: WorldTile[] = [];
    for (let x = 0; x < WORLD_WIDTH; x++) {
      let block: BlockType = 'empty';
      let bg: 'sky' | 'cave_bg' | 'wood_bg' | 'ruin_bg' = 'sky';
      let maxHits = 3;

      if (zone === 'starter_village') {
        // --- STARTER VILLAGE (GROWTOPIA STYLE START WORLD) ---
        if (y < 12) {
          block = 'empty';
          bg = 'sky';
        } else if (y === 12) {
          block = 'dirt';
          bg = 'sky';
          maxHits = 3;
        } else if (y < 22) {
          block = Math.random() < 0.15 ? 'cave_rock' : 'dirt';
          bg = 'cave_bg';
          maxHits = block === 'cave_rock' ? 5 : 3;
        } else if (y < 27) {
          // Deep caverns with iron and lava
          if (Math.random() < 0.1) block = 'lava';
          else if (Math.random() < 0.2) block = 'iron_block';
          else block = 'cave_rock';
          bg = 'cave_bg';
          maxHits = 5;
        } else {
          // Bedrock bottom
          block = 'bedrock';
          bg = 'cave_bg';
          maxHits = 999999;
        }

        const tile: WorldTile = {
          block,
          background: bg,
          maxHits,
          hitsTaken: 0,
        };

        // White Exit Door at (4, 11)
        if (x === 4 && y === 11) {
          tile.block = 'main_door';
          tile.doorDestination = 'mystic_forest';
          tile.doorLabel = 'FOREST (Hutan)';
        }

        // World Lock at (6, 11)
        if (x === 6 && y === 11) {
          tile.block = 'world_lock';
        }

        // Starter Dirt Trees on surface
        if (y === 11 && (x === 10 || x === 16 || x === 22)) {
          tile.tree = {
            seedItemId: 'seed_dirt',
            seedName: 'Pohon Tanah',
            fruitItemId: 'block_dirt',
            plantedAt: Date.now() - 30000,
            growDurationMs: 15000,
            fruitCount: 3,
            ready: true,
          };
        }

        row.push(tile);
      } else if (zone === 'mystic_forest') {
        // --- MYSTIC FOREST WORLD ---
        if (y < 11) {
          block = 'empty';
          bg = 'sky';
        } else if (y === 11) {
          block = 'wood_block';
          bg = 'sky';
          maxHits = 4;
        } else if (y < 22) {
          block = Math.random() < 0.3 ? 'wood_block' : 'dirt';
          bg = 'wood_bg';
          maxHits = 4;
        } else if (y < 27) {
          block = Math.random() < 0.25 ? 'amethyst_block' : 'cave_rock';
          bg = 'cave_bg';
          maxHits = 6;
        } else {
          block = 'bedrock';
          bg = 'cave_bg';
          maxHits = 999999;
        }

        const tile: WorldTile = {
          block,
          background: bg,
          maxHits,
          hitsTaken: 0,
        };

        // Portal back to Village at (3, 10)
        if (x === 3 && y === 10) {
          tile.block = 'main_door';
          tile.doorDestination = 'starter_village';
          tile.doorLabel = 'START (Desa)';
        }

        // Portal to Crystal Cave at (48, 10)
        if (x === 48 && y === 10) {
          tile.block = 'main_door';
          tile.doorDestination = 'crystal_cave';
          tile.doorLabel = 'CAVE (Gua)';
        }

        // Wood Trees on surface
        if (y === 10 && (x === 12 || x === 18 || x === 26 || x === 34)) {
          tile.tree = {
            seedItemId: 'seed_wood',
            seedName: 'Pohon Kayu Mistik',
            fruitItemId: 'block_wood',
            plantedAt: Date.now() - 40000,
            growDurationMs: 25000,
            fruitCount: 4,
            ready: true,
          };
        }

        row.push(tile);
      } else if (zone === 'crystal_cave') {
        // --- CRYSTAL CAVE WORLD ---
        if (y < 9) {
          block = 'empty';
          bg = 'cave_bg';
        } else if (y === 9) {
          block = 'cave_rock';
          bg = 'cave_bg';
          maxHits = 5;
        } else if (y < 22) {
          const r = Math.random();
          if (r < 0.2) block = 'amethyst_block';
          else if (r < 0.35) block = 'gold_block';
          else if (r < 0.5) block = 'iron_block';
          else block = 'cave_rock';
          bg = 'cave_bg';
          maxHits = 6;
        } else if (y < 27) {
          block = Math.random() < 0.3 ? 'crystal_block' : 'lava';
          bg = 'cave_bg';
          maxHits = 8;
        } else {
          block = 'bedrock';
          bg = 'cave_bg';
          maxHits = 999999;
        }

        const tile: WorldTile = {
          block,
          background: bg,
          maxHits,
          hitsTaken: 0,
        };

        // Door to Forest at (3, 8)
        if (x === 3 && y === 8) {
          tile.block = 'main_door';
          tile.doorDestination = 'mystic_forest';
          tile.doorLabel = 'FOREST (Hutan)';
        }

        // Door to Ancient Ruins at (48, 8)
        if (x === 48 && y === 8) {
          tile.block = 'main_door';
          tile.doorDestination = 'ancient_ruins';
          tile.doorLabel = 'RUINS (Reruntuhan)';
        }

        // Crystal Trees on surface
        if (y === 8 && (x === 14 || x === 24 || x === 36)) {
          tile.tree = {
            seedItemId: 'seed_amethyst',
            seedName: 'Pohon Kristal Ungu',
            fruitItemId: 'block_amethyst',
            plantedAt: Date.now() - 50000,
            growDurationMs: 30000,
            fruitCount: 4,
            ready: true,
          };
        }

        row.push(tile);
      } else {
        // --- ANCIENT RUINS WORLD ---
        if (y < 10) {
          block = 'empty';
          bg = 'ruin_bg';
        } else if (y === 10) {
          block = 'ruin_brick';
          bg = 'ruin_bg';
          maxHits = 7;
        } else if (y < 22) {
          const r = Math.random();
          if (r < 0.25) block = 'crystal_block';
          else if (r < 0.45) block = 'gold_block';
          else block = 'ruin_brick';
          bg = 'ruin_bg';
          maxHits = 7;
        } else if (y < 27) {
          block = Math.random() < 0.4 ? 'crystal_block' : 'ruin_brick';
          bg = 'ruin_bg';
          maxHits = 9;
        } else {
          block = 'bedrock';
          bg = 'ruin_bg';
          maxHits = 999999;
        }

        const tile: WorldTile = {
          block,
          background: bg,
          maxHits,
          hitsTaken: 0,
        };

        // Door back to Cave at (3, 9)
        if (x === 3 && y === 9) {
          tile.block = 'main_door';
          tile.doorDestination = 'crystal_cave';
          tile.doorLabel = 'CAVE (Gua)';
        }

        // World Lock in Vault at (27, 9)
        if (x === 27 && y === 9) {
          tile.block = 'world_lock';
        }

        row.push(tile);
      }
    }
    grid.push(row);
  }

  return grid;
}
