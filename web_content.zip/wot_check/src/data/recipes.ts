export interface CraftingRecipe {
  id: string;
  name: string;
  nameId: string;
  category: 'tool' | 'weapon' | 'potion' | 'material';
  resultItemId: string;
  resultCount: number;
  levelRequired: number;
  ingredients: { itemId: string; count: number }[];
  description: string;
}

export const CRAFTING_RECIPES: CraftingRecipe[] = [
  // --- GROWTOPIA SEED SPLICING ---
  {
    id: 'splice_seed_wood',
    name: 'Wood Tree Seed (Bibit Kayu)',
    nameId: 'Splicing: Bibit Pohon Kayu',
    category: 'material',
    resultItemId: 'seed_wood',
    resultCount: 2,
    levelRequired: 1,
    ingredients: [
      { itemId: 'seed_dirt', count: 2 },
      { itemId: 'seed_rock', count: 2 },
    ],
    description: 'Gabungkan Bibit Tanah + Bibit Batu untuk menghasilkan Bibit Pohon Kayu Growtopia!',
  },
  {
    id: 'splice_seed_lava',
    name: 'Lava Tree Seed (Bibit Lava)',
    nameId: 'Splicing: Bibit Pohon Lava',
    category: 'material',
    resultItemId: 'seed_lava',
    resultCount: 1,
    levelRequired: 2,
    ingredients: [
      { itemId: 'seed_rock', count: 2 },
      { itemId: 'seed_wood', count: 2 },
    ],
    description: 'Gabungkan Bibit Batu + Bibit Kayu untuk menghasilkan Bibit Pohon Lava Panas!',
  },
  {
    id: 'splice_seed_amethyst',
    name: 'Amethyst Crystal Seed',
    nameId: 'Splicing: Bibit Kristal Amethyst',
    category: 'material',
    resultItemId: 'seed_amethyst',
    resultCount: 1,
    levelRequired: 3,
    ingredients: [
      { itemId: 'seed_wood', count: 2 },
      { itemId: 'seed_lava', count: 1 },
    ],
    description: 'Gabungkan Bibit Kayu + Bibit Lava untuk menghasilkan Bibit Kristal Permata Ungu!',
  },
  {
    id: 'forge_world_lock',
    name: 'World Lock (WL)',
    nameId: 'Tempa: World Lock Emas',
    category: 'material',
    resultItemId: 'world_lock',
    resultCount: 1,
    levelRequired: 3,
    ingredients: [
      { itemId: 'ore_gold', count: 5 },
      { itemId: 'gem_amethyst', count: 2 },
    ],
    description: 'Kunci seluruh world Growtopia! Lindungi blok dan gunakan untuk perdagangan resmi.',
  },
  // --- WEAPONS ---
  {
    id: 'craft_sword_iron',
    name: 'Refined Iron Broadsword',
    nameId: 'Pedang Besi Tempa',
    category: 'weapon',
    resultItemId: 'sword_iron',
    resultCount: 1,
    levelRequired: 2,
    ingredients: [
      { itemId: 'ore_iron', count: 6 },
      { itemId: 'wood_oak', count: 4 },
      { itemId: 'meat_beast', count: 2 },
    ],
    description: 'Forged iron sword providing 26 Attack Power against wild forest monsters.',
  },
  {
    id: 'craft_sword_crystal',
    name: 'Crystal Cleaver',
    nameId: 'Pedang Kristal Penembus',
    category: 'weapon',
    resultItemId: 'sword_crystal',
    resultCount: 1,
    levelRequired: 4,
    ingredients: [
      { itemId: 'gem_amethyst', count: 4 },
      { itemId: 'golem_core', count: 2 },
      { itemId: 'wood_mystic', count: 3 },
    ],
    description: 'Deals 45 Attack Power. Slices effortlessly through stone armor.',
  },
  {
    id: 'craft_sword_mythic',
    name: 'Aegis Excalibur',
    nameId: 'Pedang Mitos Excalibur',
    category: 'weapon',
    resultItemId: 'sword_mythic',
    resultCount: 1,
    levelRequired: 6,
    ingredients: [
      { itemId: 'crystal_star', count: 2 },
      { itemId: 'ancient_relic_shard', count: 3 },
      { itemId: 'heart_of_eternity', count: 1 },
      { itemId: 'yggdrasil_heartwood', count: 1 },
    ],
    description: 'Mythical blade radiating 90 Attack Power. Smites ancient guardians.',
  },

  // --- TOOLS ---
  {
    id: 'craft_pickaxe_iron',
    name: 'Reinforced Iron Pickaxe',
    nameId: 'Beliung Besi Kokoh',
    category: 'tool',
    resultItemId: 'pickaxe_iron',
    resultCount: 1,
    levelRequired: 2,
    ingredients: [
      { itemId: 'ore_iron', count: 5 },
      { itemId: 'wood_oak', count: 3 },
    ],
    description: 'Mines iron and gold deposits twice as fast as starter pick.',
  },
  {
    id: 'craft_pickaxe_crystal',
    name: 'Astral Crystal Pickaxe',
    nameId: 'Beliung Kristal Bintang',
    category: 'tool',
    resultItemId: 'pickaxe_crystal',
    resultCount: 1,
    levelRequired: 5,
    ingredients: [
      { itemId: 'crystal_star', count: 3 },
      { itemId: 'ore_gold', count: 6 },
      { itemId: 'wood_mystic', count: 4 },
    ],
    description: 'Legendary pickaxe capable of shattering deepest celestial star crystals.',
  },
  {
    id: 'craft_axe_iron',
    name: 'Steel Forester Axe',
    nameId: 'Kapak Baja Hutan',
    category: 'tool',
    resultItemId: 'axe_iron',
    resultCount: 1,
    levelRequired: 2,
    ingredients: [
      { itemId: 'ore_iron', count: 4 },
      { itemId: 'wood_oak', count: 4 },
    ],
    description: 'Fells mystic trees with high-grade steel edge.',
  },
  {
    id: 'craft_rod_master',
    name: 'Ocean Master Rod',
    nameId: 'Joran Master Samudra',
    category: 'tool',
    resultItemId: 'rod_master',
    resultCount: 1,
    levelRequired: 3,
    ingredients: [
      { itemId: 'wood_mystic', count: 3 },
      { itemId: 'gem_amethyst', count: 2 },
      { itemId: 'pelt_wolf', count: 2 },
    ],
    description: 'High-tension fishing rod that increases rare & legendary fish chances by +15%.',
  },

  // --- POTIONS & ALCHEMY ---
  {
    id: 'craft_potion_health',
    name: 'Herb Health Elixir',
    nameId: 'Ramuan Pemulih Darah',
    category: 'potion',
    resultItemId: 'potion_health',
    resultCount: 2,
    levelRequired: 1,
    ingredients: [
      { itemId: 'crop_wheat', count: 3 },
      { itemId: 'crop_carrot', count: 2 },
    ],
    description: 'Brews 2 healing elixirs restoring 50 HP each.',
  },
  {
    id: 'craft_potion_energy',
    name: 'Starlight Vitality Tonic',
    nameId: 'Tonik Vitalitas Energi',
    category: 'potion',
    resultItemId: 'potion_energy',
    resultCount: 1,
    levelRequired: 3,
    ingredients: [
      { itemId: 'crop_sunberry', count: 2 },
      { itemId: 'gem_amethyst', count: 1 },
    ],
    description: 'Potent tonic revitalizing 60 stamina points for heavy adventuring.',
  },
];
