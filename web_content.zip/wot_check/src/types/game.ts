export type ItemRarity = 'common' | 'uncommon' | 'rare' | 'epic' | 'legendary' | 'mythic';

export type ItemCategory = 
  | 'resource' 
  | 'tool' 
  | 'fish' 
  | 'crop' 
  | 'seed' 
  | 'potion' 
  | 'trophy' 
  | 'relic';

export interface Item {
  id: string;
  name: string;
  nameId?: string; // Indonesian localized name
  description: string;
  rarity: ItemRarity;
  category: ItemCategory;
  value: number; // Base Gold value
  icon: string; // Key for pixel icon renderer or emoji/svg representation
  stackable: boolean;
  maxStack?: number;
  toolType?: 'pickaxe' | 'axe' | 'rod' | 'hoe' | 'sword';
  toolPower?: number; // Gathering speed or damage
  healAmount?: number;
  luckBonus?: number;
}

export interface InventorySlot {
  item: Item;
  count: number;
  hash: string; // Unique cryptographic mint hash for marketplace security
  obtainedAt: number;
}

export type ZoneId = 'starter_village' | 'mystic_forest' | 'crystal_cave' | 'ancient_ruins';

export interface ZoneConfig {
  id: ZoneId;
  name: string;
  nameId: string;
  description: string;
  width: number; // in tiles
  height: number;
  bgmTheme: 'village' | 'forest' | 'cave' | 'ruins';
  ambientColor: string;
  levelRequirement: number;
}

export type BlockType = 
  | 'empty'
  | 'dirt'
  | 'cave_rock'
  | 'iron_block'
  | 'gold_block'
  | 'amethyst_block'
  | 'crystal_block'
  | 'wood_block'
  | 'lava'
  | 'main_door'
  | 'world_lock'
  | 'bedrock'
  | 'water_block'
  | 'ruin_brick';

export interface GrowTree {
  seedItemId: string;
  seedName: string;
  fruitItemId: string;
  plantedAt: number;
  growDurationMs: number;
  fruitCount: number;
  ready: boolean;
}

export interface WorldTile {
  block: BlockType;
  background: 'sky' | 'cave_bg' | 'wood_bg' | 'ruin_bg';
  maxHits: number;
  hitsTaken: number;
  tree?: GrowTree;
  doorDestination?: ZoneId;
  doorLabel?: string;
}

export interface FloatingDrop {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  gemValue?: number; // if gem (1, 5, 10, 50)
  itemId?: string;
  count: number;
  life: number;
}

export type ResourceNodeType = 
  | 'tree_oak' 
  | 'tree_pine' 
  | 'tree_mystic' 
  | 'rock_stone' 
  | 'rock_iron' 
  | 'rock_gold' 
  | 'rock_crystal' 
  | 'rock_amethyst'
  | 'farm_plot' 
  | 'fishing_spot'
  | 'chest'
  | 'ruin_pillar';

export interface ResourceNode {
  id: string;
  type: ResourceNodeType;
  x: number; // tile coordinates
  y: number;
  zone: ZoneId;
  hp: number;
  maxHp: number;
  respawnTime: number; // in ms
  lastHarvested?: number;
  farmState?: {
    tilled: boolean;
    plantedSeedId?: string;
    plantedAt?: number;
    growDurationMs?: number;
    watered: boolean;
    ready: boolean;
  };
  chestOpened?: boolean;
  chestLoot?: { itemId: string; count: number }[];
}

export interface Monster {
  id: string;
  name: string;
  type: 'boar' | 'wolf' | 'crystal_golem' | 'ancient_guardian';
  x: number; // pixel coordinates
  y: number;
  zone: ZoneId;
  hp: number;
  maxHp: number;
  speed: number;
  damage: number;
  xpReward: number;
  goldReward: number;
  drops: { itemId: string; chance: number; min: number; max: number }[];
  direction: 'down' | 'up' | 'left' | 'right';
  animFrame: number;
  patrolCenter: { x: number; y: number };
  state: 'idle' | 'patrol' | 'chase' | 'attack' | 'hit';
  hitTimer: number;
}

export interface NPC {
  id: string;
  name: string;
  role: string;
  x: number; // tile coordinates
  y: number;
  zone: ZoneId;
  avatar: string;
  dialogue: string[];
  type: 'mayor' | 'merchant' | 'blacksmith' | 'elder';
}

export interface Quest {
  id: string;
  title: string;
  description: string;
  category: 'farming' | 'logging' | 'mining' | 'hunting' | 'trading' | 'exploration' | 'fishing';
  targetType: string;
  targetCount: number;
  currentCount: number;
  rewardGold: number;
  rewardXp: number;
  rewardItems?: { itemId: string; count: number }[];
  completed: boolean;
  claimed: boolean;
}

export interface PlayerStats {
  hp: number;
  maxHp: number;
  energy: number;
  maxEnergy: number;
  level: number;
  xp: number;
  xpToNextLevel: number;
  gold: number;
  gems: number; // Growtopia Gems 💎
  worldLocks: number; // Growtopia World Locks 🔒
  punchMode: 'fist' | 'wrench'; // Growtopia Fist vs Wrench mode
  heldSlotIndex: number; // Selected slot in quickbar (to place or hold)
  chatBubble?: { text: string; timer: number } | null;
  equippedTool: {
    pickaxe: string;
    axe: string;
    rod: string;
    hoe: string;
    sword: string;
  };
  selectedToolType: 'sword' | 'pickaxe' | 'axe' | 'hoe' | 'rod';
  inventory: (InventorySlot | null)[];
  inventorySize: number;
  unlockedZones: ZoneId[];
  statsRecord: {
    treesChopped: number;
    oresMined: number;
    fishCaught: number;
    cropsHarvested: number;
    monstersDefeated: number;
    itemsCrafted: number;
    goldEarned: number;
  };
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  color: string;
  size: number;
  text?: string;
}

export interface MarketListing {
  id: string;
  sellerId: string;
  sellerName: string;
  item: Item;
  count: number;
  pricePerUnit: number;
  totalPrice: number;
  mintHash: string;
  listedAt: number;
  isPlayerListing: boolean;
}

export interface TradeHistoryItem {
  id: string;
  timestamp: number;
  itemName: string;
  itemRarity: ItemRarity;
  count: number;
  price: number;
  buyer: string;
  seller: string;
  txHash: string;
}
