import { MarketListing, TradeHistoryItem, Item } from '../types/game';
import { ITEMS_DATABASE } from '../data/items';

export function generateItemHash(itemId: string): string {
  const chars = '0123456789ABCDEF';
  let rand = '';
  for (let i = 0; i < 8; i++) {
    rand += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return `WOT-${itemId.slice(0, 4).toUpperCase()}-${rand}`;
}

export function generateInitialMarketplace(): {
  listings: MarketListing[];
  history: TradeHistoryItem[];
} {
  const sampleItems: { itemId: string; count: number; priceMult: number; seller: string }[] = [
    { itemId: 'wood_pine', count: 12, priceMult: 1.1, seller: 'Forester_Kael' },
    { itemId: 'wood_mystic', count: 5, priceMult: 1.25, seller: 'Druid_Lyra' },
    { itemId: 'ore_iron', count: 15, priceMult: 1.05, seller: 'Miner_Borin' },
    { itemId: 'ore_gold', count: 8, priceMult: 1.15, seller: 'GoldDigger_Gim' },
    { itemId: 'gem_amethyst', count: 3, priceMult: 1.3, seller: 'GemCutter_Vera' },
    { itemId: 'crop_wheat', count: 20, priceMult: 0.95, seller: 'Farmer_Giles' },
    { itemId: 'crop_sunberry', count: 4, priceMult: 1.2, seller: 'SunPriestess_Aria' },
    { itemId: 'fish_golden_perch', count: 6, priceMult: 1.1, seller: 'Angler_Sam' },
    { itemId: 'fish_cave_angler', count: 2, priceMult: 1.4, seller: 'DeepFisher_Zod' },
    { itemId: 'pelt_wolf', count: 5, priceMult: 1.1, seller: 'Hunter_Rowan' },
    { itemId: 'golem_core', count: 2, priceMult: 1.35, seller: 'Arcanist_Thorne' },
    { itemId: 'crystal_star', count: 1, priceMult: 1.5, seller: 'GuildMaster_Darius' },
  ];

  const listings: MarketListing[] = sampleItems.map((s, idx) => {
    const item = ITEMS_DATABASE[s.itemId] || ITEMS_DATABASE['stone'];
    const pricePerUnit = Math.round(item.value * s.priceMult);
    return {
      id: `list_${idx + 1}`,
      sellerId: `seller_${idx + 1}`,
      sellerName: s.seller,
      item,
      count: s.count,
      pricePerUnit,
      totalPrice: pricePerUnit * s.count,
      mintHash: generateItemHash(item.id),
      listedAt: Date.now() - Math.floor(Math.random() * 3600000),
      isPlayerListing: false,
    };
  });

  const history: TradeHistoryItem[] = [
    {
      id: 'tx_101',
      timestamp: Date.now() - 120000,
      itemName: 'Amethyst Cluster',
      itemRarity: 'epic',
      count: 2,
      price: 240,
      buyer: 'Arcanist_Vane',
      seller: 'GemCutter_Vera',
      txHash: '0x88f2a49b',
    },
    {
      id: 'tx_102',
      timestamp: Date.now() - 480000,
      itemName: 'Reinforced Iron Pickaxe',
      itemRarity: 'rare',
      count: 1,
      price: 95,
      buyer: 'Novice_Explorer',
      seller: 'Blacksmith_Guild',
      txHash: '0x33c1d904',
    },
    {
      id: 'tx_103',
      timestamp: Date.now() - 950000,
      itemName: 'Celestial Star Crystal',
      itemRarity: 'legendary',
      count: 1,
      price: 390,
      buyer: 'Lord_Castamere',
      seller: 'Explorer_Jax',
      txHash: '0x71e89b21',
    },
    {
      id: 'tx_104',
      timestamp: Date.now() - 1800000,
      itemName: 'Golden Wheat',
      itemRarity: 'common',
      count: 50,
      price: 400,
      buyer: 'Bakery_Consortium',
      seller: 'Farmer_Giles',
      txHash: '0x44b91f5a',
    },
  ];

  return { listings, history };
}
