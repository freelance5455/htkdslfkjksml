LDN OFFLINE — PROYEK ANDROID (BELUM APK SIAP INSTAL)

Isi:
- Satu aplikasi Android dengan dua menu: LDN Admin dan LDN Pelanggan.
- Aplikasi memuat prototipe offline yang disertakan sebagai assets/index.html.
- JavaScript dan DOM storage diaktifkan agar prototipe bisa mencoba menyimpan data lokal.

PENTING:
Paket ini adalah proyek sumber Android, bukan file APK yang sudah dikompilasi. Untuk menghasilkan APK, buka folder LDN_Android_Project dengan Android Studio pada komputer yang memiliki Android SDK dan koneksi untuk mengunduh komponen Gradle/SDK.

Cara membangun APK di Android Studio:
1. Buka Android Studio.
2. Pilih Open, lalu pilih folder LDN_Android_Project.
3. Tunggu Gradle Sync dan instal SDK yang diminta.
4. Pilih Build > Build APK(s).
5. APK debug biasanya berada di app/build/outputs/apk/debug/app-debug.apk.

Aplikasi ini masih prototipe uji coba offline. Data hanya ada di penyimpanan lokal aplikasi/perangkat, belum ada sinkronisasi server ke HP lain dan belum siap untuk data pelanggan sungguhan. Buat backup sebelum menghapus data aplikasi atau meng-uninstall.
