# Fluxo para Android — projeto inicial
Aplicativo Android em Java/WebView com as telas locais de controle financeiro. Funciona sem conexão bancária e guarda os registros no armazenamento do WebView. Exportação e importação usam o seletor de arquivos do Android.

## Gerar APK
Abra esta pasta no Android Studio com JDK 17, SDK Android 35 e acesso aos repositórios Google/Maven. Sincronize o Gradle e use Build > Build App Bundle(s) / APK(s) > Build APK(s). O Android Studio configura o Gradle; o wrapper não está incluído. Alternativamente instale Gradle 8.9 e execute `gradle assembleDebug` nesta pasta. APK esperado: app/build/outputs/apk/debug/app-debug.apk.

## Escopo
Visão geral, CRUD de lançamentos, contas, transferências, cartões, pagamento e estorno de compras, categorias, limites mensais, relatórios, CSV e backup JSON.
Compras no cartão são agrupadas por mês civil; não há ciclo de fechamento automático. Nesta versão não há parcelamento automático, recorrência, sincronização, login, notificações nem Open Finance.
O APK não foi compilado nem testado em dispositivo neste ambiente. O código web foi verificado por sintaxe e testes de saldos/pagamentos/backup. O Gradle/SDK não estão disponíveis no ambiente de criação.

## Dados
A primeira abertura começa sem registros, com a conta Minha carteira. Dados são locais e não acompanham a versão web. Exporte backup antes de desinstalar ou limpar os dados. Importação substitui os dados após confirmação.
