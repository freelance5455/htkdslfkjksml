# Fluxo para Android — versão 1.2
Aplicativo Android em Java/WebView com as telas locais de controle financeiro. Funciona sem conexão bancária e guarda os registros no armazenamento do WebView. Exportação e importação usam o seletor de arquivos do Android.

## Gerar APK
Abra esta pasta no Android Studio com JDK 17, SDK Android 35 e acesso aos repositórios Google/Maven. Sincronize o Gradle e use Build > Build App Bundle(s) / APK(s) > Build APK(s). O Android Studio configura o Gradle; o wrapper não está incluído. Alternativamente instale Gradle 8.9 e execute `gradle assembleDebug` nesta pasta. APK esperado: app/build/outputs/apk/debug/app-debug.apk.

## Novidades da versão 1.2
Cartões na barra inferior, detalhe por cartão, histórico mensal, total gasto, fatura pendente e limite disponível. Escolha de instituições com ícones tipográficos locais: Nubank, Itaú, Banco do Brasil, Bradesco, Santander, Caixa, Inter, C6 Bank, BTG Pactual, PicPay, Mercado Pago, Banese, Sicredi, Sicoob e Neon. Os ícones são identificadores visuais próprios, não arquivos oficiais dos logotipos.

## Receitas, repetições e parcelas
O painel de receitas abre a lista de receitas e permite adicionar novas. Receitas e despesas podem ocorrer uma vez, mensalmente por número definido de ocorrências ou mensalmente sem prazo. Apenas a primeira segue a situação escolhida; as seguintes ficam pendentes. As repetições são materializadas ao abrir o aplicativo ou navegar nos meses, sem serviço de background. É possível editar/excluir uma ocorrência ou parar as próximas, preservando as já pagas.
Compras de cartão recebem valor total e número de parcelas. Cada parcela é registrada num mês; o arredondamento distribui centavos nas primeiras parcelas. Todo o saldo não pago da compra compromete o limite. Dias 29–31 são ajustados ao último dia válido do mês. Editar uma parcela preserva seu valor e cartão; é possível excluir esta e as seguintes pendentes.
Backups antigos continuam aceitos; backups novos incluem as regras de repetição e os metadados das parcelas.

## Escopo
Visão geral, CRUD de lançamentos, contas, transferências, cartões, pagamento e estorno de compras, categorias, limites mensais, relatórios, CSV e backup JSON.
Compras no cartão são agrupadas por mês civil; não há ciclo de fechamento automático. Nesta versão não há sincronização, login, notificações nem Open Finance.
O APK não foi compilado nem testado em dispositivo neste ambiente. O código web foi verificado por sintaxe e testes de saldos/pagamentos/backup. O Gradle/SDK não estão disponíveis no ambiente de criação.

## Dados
A primeira abertura começa sem registros, com a conta Minha carteira. Dados são locais e não acompanham a versão web. Exporte backup antes de desinstalar ou limpar os dados. Importação substitui os dados após confirmação.
