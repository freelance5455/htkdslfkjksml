# NOVA AIM LAB

Aplicativo Android independente para treino de mira, movimentação e ajustes manuais.

## Interface
- Tema gamer RGB preto e roxo neon, com detalhes magenta.
- Transições suaves de entrada entre telas.
- Botões com resposta tátil animada.
- Cartões com entrada gradual e elementos de treino com microanimações.

## Funcionalidades
- Aim Trainer com alvos tocáveis e contador de acertos/tentativas.
- Treino de movimentação com comandos direcionais e pontuação.
- Ajustes manuais de sensibilidade por controle deslizante.
- Recomendações gerais para estabilidade de desempenho/FPS.
- Funciona offline e não solicita permissões especiais.

## Limites de funcionamento
Este projeto é um treinador independente. Não injeta comandos, não automatiza toques/disparos, não desenha mira sobre outros aplicativos, não oferece ESP/aimbot e não altera arquivos do jogo. As sensibilidades são referências iniciais e não garantem resultados específicos.

## Como gerar o APK
1. Abra a pasta `FF_AIM_MASTER_AI` no Android Studio.
2. Aguarde a sincronização do Gradle e instale o Android SDK 35, se solicitado.
3. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. O APK de teste será gerado em `app/build/outputs/apk/debug/app-debug.apk`.

## Requisitos
- Android Studio recente.
- JDK 17.
- Android SDK 35.
