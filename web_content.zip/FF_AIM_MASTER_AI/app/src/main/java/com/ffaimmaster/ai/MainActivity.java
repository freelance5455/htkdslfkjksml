package com.ffaimmaster.ai;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.content.res.ColorStateList;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.*;
import java.util.Random;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(9, 7, 18);
    private final int PANEL = Color.rgb(23, 17, 38);
    private final int PANEL2 = Color.rgb(34, 23, 55);
    private final int PURPLE = Color.rgb(183, 92, 255);
    private final int PINK = Color.rgb(255, 75, 205);
    private final int WHITE = Color.rgb(248, 244, 255);
    private final int MUTED = Color.rgb(177, 164, 197);
    private TextView scoreText, moveScoreText;
    private int score = 0, shots = 0, moveScore = 0, moveRounds = 0;
    private AimView aimView;
    private TextView directionPrompt;
    private String expectedDirection = "NORTE";
    private final Random random = new Random();

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        showHome();
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }

    private GradientDrawable gradient(int c1, int c2, int radius) {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{c1,c2});
        d.setCornerRadius(dp(radius)); return d;
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private LinearLayout base(String title) {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(20), dp(24), dp(20), dp(26));
        page.setBackgroundColor(BG);
        scroll.addView(page);
        setContentView(scroll);
        page.setAlpha(0f);
        page.animate().alpha(1f).setDuration(360).setInterpolator(new DecelerateInterpolator()).start();

        TextView brand = text("NOVA  /  AIM LAB", 12, PURPLE, true);
        brand.setLetterSpacing(0.16f);
        page.addView(brand);
        TextView heading = text(title, 23, WHITE, true);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1,-2);
        hp.topMargin = dp(8);
        page.addView(heading,hp);
        View line = new View(this);
        line.setBackground(gradient(PURPLE,PINK,3));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(64),dp(3));
        lp.topMargin=dp(12); lp.bottomMargin=dp(20); page.addView(line,lp);
        return page;
    }

    private TextView button(String label, LinearLayout parent, Runnable action) {
        TextView b = text(label, 14, WHITE, true);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(14),dp(17),dp(14),dp(17));
        b.setBackground(gradient(Color.rgb(104,45,160),Color.rgb(170,55,176),18));
        b.setElevation(dp(3));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2);
        p.bottomMargin = dp(11);
        parent.addView(b,p);
        b.setOnClickListener(v -> action.run());
        b.setOnTouchListener((v,e)->{
            if(e.getAction()==MotionEvent.ACTION_DOWN) v.animate().scaleX(.975f).scaleY(.975f).alpha(.88f).setDuration(90).start();
            if(e.getAction()==MotionEvent.ACTION_UP || e.getAction()==MotionEvent.ACTION_CANCEL)
                v.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(150).start();
            return false;
        });
        return b;
    }

    private void card(LinearLayout parent, String title, String detail) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16),dp(15),dp(16),dp(15));
        box.setBackground(shape(PANEL,16));
        TextView h=text(title,15,WHITE,true);
        TextView d=text(detail,12,MUTED,false);
        d.setPadding(0,dp(6),0,0);
        box.addView(h); box.addView(d);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);
        p.bottomMargin=dp(10); parent.addView(box,p);
        box.setAlpha(0f); box.animate().alpha(1f).setDuration(420).start();
    }

    private void showHome() {
        LinearLayout p = base("Treine com precisão.");
        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setGravity(Gravity.CENTER);
        hero.setPadding(dp(18),dp(24),dp(18),dp(24));
        hero.setBackground(gradient(Color.rgb(48,20,78),Color.rgb(25,14,42),22));
        TextView mark=text("✦",34,PINK,true); mark.setGravity(Gravity.CENTER);
        TextView title=text("AIM  /  MOVEMENT",20,WHITE,true); title.setGravity(Gravity.CENTER);
        TextView sub=text("SEU TREINO. SEU RITMO. SUA EVOLUÇÃO.",10,MUTED,true); sub.setGravity(Gravity.CENTER);
        sub.setLetterSpacing(.08f);
        hero.addView(mark); hero.addView(title); hero.addView(sub);
        LinearLayout.LayoutParams h=new LinearLayout.LayoutParams(-1,-2); h.bottomMargin=dp(18); p.addView(hero,h);
        card(p,"CENTRAL DE TREINO","Exercícios independentes para mira, reflexo e movimentação.");
        button("◎   TREINAMENTO DE MIRA",p,()->showTrainer());
        button("⌖   TREINO DE MOVIMENTAÇÃO",p,()->showMovement());
        button("◈   AJUSTE DE SENSIBILIDADE",p,()->showSensitivity());
        button("▥   DESEMPENHO E FPS",p,()->showPerformance());
        TextView note=text("Ferramenta de treino independente. Não injeta comandos, não automatiza ações e não altera arquivos do jogo.",11,MUTED,false);
        note.setPadding(dp(4),dp(18),dp(4),0); p.addView(note);
    }

    private void showSensitivity() {
        LinearLayout p = base("Ajuste de sensibilidade");
        TextView intro = text("Ajuste manualmente e teste cada perfil no modo de treino. Os valores são apenas referências iniciais.",13,MUTED,false);
        p.addView(intro);
        String[] names = {"Geral","Ponto vermelho","Mira 2x","Mira 4x","AWM","Olhadinha"};
        int[] values = {92,88,82,76,48,70};
        for(int i=0;i<names.length;i++){
            final int index=i;
            TextView label=text(names[i]+"  •  "+values[i],14,WHITE,true);
            LinearLayout.LayoutParams tl=new LinearLayout.LayoutParams(-1,-2); tl.topMargin=dp(17); p.addView(label,tl);
            SeekBar bar=new SeekBar(this); bar.setMax(100); bar.setProgress(values[i]);
            if(android.os.Build.VERSION.SDK_INT>=21) bar.setProgressTintList(ColorStateList.valueOf(PURPLE));
            p.addView(bar);
            bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
                public void onProgressChanged(SeekBar s,int v,boolean user){label.setText(names[index]+"  •  "+v);}
                public void onStartTrackingTouch(SeekBar s){}
                public void onStopTrackingTouch(SeekBar s){}
            });
        }
        button("SALVAR PERFIL DESTA SESSÃO",p,()->Toast.makeText(this,"Ajustes mantidos durante esta sessão.",Toast.LENGTH_SHORT).show());
        button("VOLTAR AO INÍCIO",p,()->showHome());
    }

    private void showTrainer() {
        LinearLayout p = base("Treinamento de mira");
        TextView desc=text("Toque no alvo assim que ele aparecer. O exercício mede sua precisão dentro deste aplicativo.",13,MUTED,false);
        p.addView(desc);
        scoreText=text("ACERTOS  0     /     TOQUES  0",13,PINK,true);
        scoreText.setPadding(0,dp(18),0,dp(14)); p.addView(scoreText);
        aimView=new AimView();
        LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,dp(390));
        p.addView(aimView,ap);
        button("REINICIAR EXERCÍCIO",p,()->{score=0;shots=0;updateScore();aimView.newTarget();});
        button("VOLTAR AO INÍCIO",p,()->showHome());
    }

    private void updateScore(){ if(scoreText!=null) scoreText.setText("ACERTOS  "+score+"     /     TOQUES  "+shots); }

    private class AimView extends View {
        Paint paint=new Paint(3); float x=150,y=150,r=42;
        AimView(){super(MainActivity.this);setBackground(shape(Color.rgb(18,12,30),18));}
        void newTarget(){
            int w=Math.max(getWidth(),1), h=Math.max(getHeight(),1);
            r=dp(31)+random.nextInt(dp(13));
            x=r+random.nextInt(Math.max(1,w-(int)(2*r)));
            y=r+random.nextInt(Math.max(1,h-(int)(2*r)));
            animate().alpha(.72f).setDuration(70).withEndAction(()->animate().alpha(1f).setDuration(180).start()).start();
            invalidate();
        }
        protected void onSizeChanged(int w,int h,int ow,int oh){newTarget();}
        protected void onDraw(Canvas c){
            super.onDraw(c);
            paint.setColor(Color.rgb(54,35,73));paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(1));
            for(int i=1;i<5;i++) c.drawLine(0,getHeight()*i/5f,getWidth(),getHeight()*i/5f,paint);
            for(int i=1;i<4;i++) c.drawLine(getWidth()*i/4f,0,getWidth()*i/4f,getHeight(),paint);
            paint.setStyle(Paint.Style.FILL);paint.setColor(PURPLE);c.drawCircle(x,y,r,paint);
            paint.setColor(Color.rgb(30,17,47));c.drawCircle(x,y,r*.65f,paint);
            paint.setColor(PINK);c.drawCircle(x,y,r*.28f,paint);
            paint.setColor(WHITE);c.drawCircle(x,y,r*.10f,paint);
        }
        public boolean onTouchEvent(MotionEvent e){
            if(e.getAction()==MotionEvent.ACTION_DOWN){
                shots++;
                float dx=e.getX()-x,dy=e.getY()-y;
                if(dx*dx+dy*dy<=r*r) score++;
                updateScore();newTarget();return true;
            } return true;
        }
    }

    private void showMovement() {
        LinearLayout p=base("Treino de movimentação");
        TextView desc=text("Observe a direção indicada e toque no comando correspondente. Treine leitura rápida e consistência.",13,MUTED,false);
        p.addView(desc);
        moveScoreText=text("RESPOSTAS CERTAS  0     /     RODADAS  0",12,PINK,true);
        moveScoreText.setPadding(0,dp(18),0,dp(12)); p.addView(moveScoreText);
        LinearLayout arena=new LinearLayout(this);
        arena.setOrientation(LinearLayout.VERTICAL); arena.setGravity(Gravity.CENTER);
        arena.setPadding(dp(18),dp(20),dp(18),dp(20)); arena.setBackground(shape(PANEL,18));
        TextView label=text("SIGA A DIREÇÃO",10,MUTED,true); label.setLetterSpacing(.12f);
        directionPrompt=text("↑  NORTE",30,WHITE,true); directionPrompt.setGravity(Gravity.CENTER);
        arena.addView(label); arena.addView(directionPrompt);
        LinearLayout.LayoutParams ar=new LinearLayout.LayoutParams(-1,-2); ar.topMargin=dp(18); ar.bottomMargin=dp(14); p.addView(arena,ar);
        String[][] keys={{"↖","↗"},{"←","→"},{"↙","↘"}};
        String[] dirs={{"NOROESTE","NORDESTE"},{"OESTE","LESTE"},{"SUDOESTE","SUDESTE"}};
        String[] symbols={"↑","↗","→","↘","↓","↙","←","↖"};
        String[] names={"NORTE","NORDESTE","LESTE","SUDESTE","SUL","SUDOESTE","OESTE","NOROESTE"};
        LinearLayout grid=new LinearLayout(this); grid.setOrientation(LinearLayout.VERTICAL);
        for(int row=0;row<3;row++){
            LinearLayout line=new LinearLayout(this); line.setOrientation(LinearLayout.HORIZONTAL);
            for(int col=0;col<2;col++){
                final String d=dirs[row][col];
                TextView key=text(keys[row][col]+"   "+d,12,WHITE,true); key.setGravity(Gravity.CENTER);
                key.setPadding(dp(6),dp(18),dp(6),dp(18)); key.setBackground(shape(PANEL2,14));
                LinearLayout.LayoutParams kp=new LinearLayout.LayoutParams(0,-2,1); kp.setMargins(dp(4),dp(4),dp(4),dp(4)); line.addView(key,kp);
                key.setOnClickListener(v->checkDirection(d));
            }
            grid.addView(line);
        }
        // Add the vertical directions as separate controls.
        LinearLayout vertical=new LinearLayout(this); vertical.setOrientation(LinearLayout.HORIZONTAL);
        addDirectionKey(vertical,"↑  NORTE","NORTE");
        addDirectionKey(vertical,"↓  SUL","SUL");
        grid.addView(vertical);
        p.addView(grid);
        button("NOVA DIREÇÃO",p,()->nextDirection());
        button("VOLTAR AO INÍCIO",p,()->showHome());
        nextDirection();
    }

    private void addDirectionKey(LinearLayout parent,String label,String direction){
        TextView key=text(label,12,WHITE,true); key.setGravity(Gravity.CENTER);
        key.setPadding(dp(5),dp(17),dp(5),dp(17)); key.setBackground(shape(PANEL2,14));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1); lp.setMargins(dp(4),dp(4),dp(4),dp(4)); parent.addView(key,lp);
        key.setOnClickListener(v->checkDirection(direction));
    }

    private void nextDirection(){
        String[] dirs={"NORTE","NORDESTE","LESTE","SUDESTE","SUL","SUDOESTE","OESTE","NOROESTE"};
        String[] arrows={"↑","↗","→","↘","↓","↙","←","↖"};
        int i=random.nextInt(dirs.length); expectedDirection=dirs[i];
        if(directionPrompt!=null){
            directionPrompt.setText(arrows[i]+"  "+dirs[i]);
            directionPrompt.setScaleX(.88f); directionPrompt.setScaleY(.88f);
            directionPrompt.animate().scaleX(1f).scaleY(1f).setDuration(180).start();
        }
    }

    private void checkDirection(String chosen){
        moveRounds++;
        if(chosen.equals(expectedDirection)) moveScore++;
        if(moveScoreText!=null) moveScoreText.setText("RESPOSTAS CERTAS  "+moveScore+"     /     RODADAS  "+moveRounds);
        nextDirection();
    }

    private void showPerformance() {
        LinearLayout p=base("Desempenho e FPS");
        TextView intro=text("Boas práticas para buscar uma experiência mais estável. O app não altera o limite de FPS do aparelho ou do jogo.",13,MUTED,false);
        p.addView(intro);
        card(p,"CONFIGURAÇÃO GRÁFICA","Comece por uma opção gráfica mais leve se houver quedas de quadros.");
        card(p,"ESTABILIDADE DE FPS","Prefira uma taxa de quadros que o aparelho consiga manter de forma consistente.");
        card(p,"APLICATIVOS EM SEGUNDO PLANO","Feche o que não estiver usando antes de iniciar uma partida.");
        card(p,"TEMPERATURA","Pausas ajudam a evitar aquecimento excessivo e redução automática de desempenho.");
        card(p,"BATERIA E ENERGIA","O modo de economia pode limitar o desempenho; confira as opções do Android.");
        card(p,"ARMAZENAMENTO","Mantenha espaço livre para o sistema funcionar adequadamente.");
        button("VOLTAR AO INÍCIO",p,()->showHome());
    }
}
