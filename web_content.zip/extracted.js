
/* Local Supabase REST/Auth client: avoids blank Android WebView when the CDN is unavailable. */
window.supabase={createClient:function(baseUrl,anonKey){
  const storage=window.localStorage;
  let token=storage.getItem('DPM_ACCESS_TOKEN')||null;
  let refresh=storage.getItem('DPM_REFRESH_TOKEN')||null;
  async function request(path,opts={}){
    const headers=Object.assign({'apikey':anonKey,'Content-Type':'application/json'},opts.headers||{});
    if(token) headers['Authorization']='Bearer '+token;
    const r=await fetch(baseUrl+path,Object.assign({},opts,{headers}));
    let data=null; try{data=await r.json()}catch(e){}
    if(!r.ok) return {data:null,error:{message:(data&&(data.msg||data.message||data.error_description||data.error))||('HTTP '+r.status)}};
    return {data,error:null};
  }
  const auth={
    async signInWithPassword({email,password}){
      const r=await request('/auth/v1/token?grant_type=password',{method:'POST',body:JSON.stringify({email,password})});
      if(!r.error){token=r.data.access_token;refresh=r.data.refresh_token||null;storage.setItem('DPM_ACCESS_TOKEN',token);if(refresh)storage.setItem('DPM_REFRESH_TOKEN',refresh);}
      return {data:r.data,error:r.error};
    },
    async getSession(){return {data:{session:token?{access_token:token,refresh_token:refresh}:null},error:null}},
    async getUser(){
      if(!token)return {data:{user:null},error:null};
      const r=await request('/auth/v1/user');
      return {data:{user:r.error?null:r.data},error:r.error};
    },
    async signOut(){token=null;refresh=null;storage.removeItem('DPM_ACCESS_TOKEN');storage.removeItem('DPM_REFRESH_TOKEN');return {error:null}},
    async resetPasswordForEmail(email,{redirectTo}={}){
      return await request('/auth/v1/recover',{method:'POST',body:JSON.stringify({email,redirect_to:redirectTo||location.origin})});
    }
  };
  function qbuilder(table,op,payload){
    let filters=[], orderBy=null, ascending=true, columns='*', singleRow=false;
    const q={
      select(cols='*'){op='select';columns=cols;return q},
      insert(body){op='insert';payload=body;return q},
      update(body){op='update';payload=body;return q},
      delete(){op='delete';return q},
      eq(col,val){filters.push([col,'eq',val]);return q},
      order(col,opt={}){orderBy=col;ascending=opt.ascending!==false;return q},
      single(){singleRow=true;return q},
      then(resolve,reject){return run().then(resolve,reject)}
    };
    async function run(){
      let url='/rest/v1/'+encodeURIComponent(table);
      const params=[];
      if(op==='select'){
        params.push('select='+encodeURIComponent(columns));
      } else if(op==='update'||op==='delete'){
        params.push('select='+encodeURIComponent('*'));
      }
      filters.forEach(f=>params.push(encodeURIComponent(f[0])+'='+encodeURIComponent(f[1]+'.'+String(f[2]))));
      if(orderBy)params.push('order='+encodeURIComponent(orderBy)+'.'+(ascending?'asc':'desc'));
      if(params.length)url+='?'+params.join('&');
      let opts={method:op==='select'?'GET':op==='insert'?'POST':op==='update'?'PATCH':'DELETE'};
      if(op==='insert'){opts.headers={'Prefer':'return=representation'};opts.body=JSON.stringify(payload)}
      if(op==='update'){opts.headers={'Prefer':'return=representation'};opts.body=JSON.stringify(payload)}
      const r=await request(url,opts);
      if(r.error)return r;
      if(op==='select'){const arr=Array.isArray(r.data)?r.data:(r.data?[r.data]:[]);if(singleRow){if(arr.length!==1)return {data:null,error:{message:arr.length?'Multiple rows returned':'No rows returned'}};return {data:arr[0],error:null}}return {data:arr,error:null}}
      return {data:r.data,error:null};
    }
    return q;
  }
  return {auth,from:(table)=>qbuilder(table,'select',null)};
}};


const SUPABASE_URL='https://iflqwjnyfgxkhfmsrqlq.supabase.co';const SUPABASE_ANON_KEY='sb_publishable_vQ8ToX3le-8zHi38EOdgUg_KjTMMnIL';
let sb=null,user=null,profile=null,items=[],trash=false,query='',viewOwnerId=null,viewOwnerName='';
const esc=s=>String(s??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');const today=()=>new Date().toISOString().slice(0,10);const monthKey=()=>today().slice(0,7);const money=n=>Number(n||0).toLocaleString(undefined,{maximumFractionDigits:2});
function configured(){return SUPABASE_URL.startsWith('http')&&SUPABASE_ANON_KEY.length>20}function configure(){let u=prompt('Supabase Project URL',SUPABASE_URL.startsWith('http')?SUPABASE_URL:'');if(!u)return;let k=prompt('Supabase anon/publishable key',SUPABASE_ANON_KEY.startsWith('YOUR_')?'':SUPABASE_ANON_KEY);if(!k)return;localStorage.setItem('DPM_SUPABASE_URL',u.trim());localStorage.setItem('DPM_SUPABASE_ANON_KEY',k.trim());location.reload()}function showLogin(msg=''){document.getElementById('root').innerHTML=`<div class="login"><div class="card"><h1>Daily Progress Manager</h1><div class="muted" style="margin-bottom:18px">Secure account login</div>${msg?`<div class="error">${esc(msg)}</div>`:''}<form id="login"><div class="field"><label>Email</label><input name="email" type="email" required autocomplete="username"></div><div class="field"><label>Password</label><input name="password" type="password" required autocomplete="current-password"></div><button class="primary" style="width:100%">Login</button></form><div style="margin-top:12px;text-align:center"><button onclick="forgotPassword()">Forgot password?</button></div><div style="margin-top:14px;text-align:center"><button type="button" onclick="configure()">Configure connection</button></div>${!configured()?'<p class="muted" style="font-size:12px;margin-top:14px">Connect this app to your Supabase project before logging in.</p>':''}</div></div>`;document.getElementById('login').onsubmit=login}
async function login(e){e.preventDefault();if(!configured())return showLogin('The app is not connected to Supabase yet. Follow SETUP.md.');let f=new FormData(e.target);let {error}=await sb.auth.signInWithPassword({email:f.get('email'),password:f.get('password')});if(error)return showLogin(error.message);await boot()}
async function forgotPassword(){if(!configured())return alert('Configure Supabase first.');let email=prompt('Enter the account email');if(!email)return;let {error}=await sb.auth.resetPasswordForEmail(email,{redirectTo:location.origin});alert(error?error.message:'Password reset email sent.')}
async function boot(){let r=await sb.auth.getUser();user=r.data.user;if(!user)return showLogin();let p=await sb.from('profiles').select('*').eq('id',user.id).single();if(p.error){await sb.auth.signOut();return showLogin('Your account profile has not been created by an administrator.')}profile=p.data;await loadItems();render()}
async function loadItems(){let q=sb.from('items').select('*').order('created_at',{ascending:false});const ownerToLoad=(profile.role==='admin'&&viewOwnerId)?viewOwnerId:user.id;q=q.eq('owner_id',ownerToLoad);if(!trash)q=q.eq('deleted',false);else q=q.eq('deleted',true);let r=await q;if(r.error)return alert(r.error.message);items=r.data||[]}
function mtdFor(x,ym=monthKey()){return (x.daily_progress||[]).filter(p=>p.date.startsWith(ym)).reduce((s,p)=>s+(+p.given||0),0)}
function render(){let active=items.filter(x=>(x.name+' '+(x.number||'')+' '+(x.location||'')+' '+(x.personal_number||'')).toLowerCase().includes(query.toLowerCase()));let activeAll=items.filter(x=>!x.deleted);let total=activeAll.length,givenToday=activeAll.reduce((s,x)=>s+(+((x.daily_progress||[]).find(p=>p.date===today())||{}).given||0),0),givenMTD=activeAll.reduce((s,x)=>s+mtdFor(x),0),visited=activeAll.filter(x=>(x.daily_progress||[]).some(p=>p.date===today()&&((+p.visits_count||0)>0||p.visited))).length,ym=monthKey(),monthVisited=activeAll.reduce((s,x)=>s+(x.daily_progress||[]).filter(p=>p.date.startsWith(ym)&&((+p.visits_count||0)>0||p.visited)).length,0);let visited5=activeAll.filter(x=>(x.daily_progress||[]).filter(p=>p.date.startsWith(ym)).reduce((n,p)=>n+(+p.visits_count||(p.visited?1:0)),0)>=5).length;let remaining=activeAll.reduce((s,x)=>s+(+x.float_target||0)-mtdFor(x),0),totalFloat=activeAll.reduce((s,x)=>s+(+x.float_target||0),0);let scopeLabel=viewOwnerId?`Viewing: ${esc(viewOwnerName)}`:'My items';document.getElementById('root').innerHTML=`<div class="app"><header><div><h1>Daily Progress Manager</h1><div class="muted">${scopeLabel} · ${esc(profile.full_name||user.email)} <span class="role">${esc(profile.role)}</span></div></div><div class="top-actions">${profile.role==='admin'?'<button onclick="usersModal()">Users</button>':''}${viewOwnerId?'<button onclick="clearOwnerView()">My Items</button>':''}<button onclick="logout()">Logout</button></div></header><div class="stats"><div class="stat"><span>Agent Base</span><b>${total}</b></div><div class="stat"><span>Float Base</span><b>${money(totalFloat)}</b></div><div class="stat"><span>Today Float Given</span><b>${money(givenToday)}</b></div><div class="stat"><span>Total Float Given MTD</span><b>${money(givenMTD)}</b></div><div class="stat"><span>Visited today</span><b>${visited}</b></div><div class="stat"><span>Visited this month</span><b>${monthVisited}</b></div><div class="stat"><span>Visited 5+ times</span><b>${visited5}</b></div><div class="stat"><span>Float variency</span><b>${money(remaining)}</b></div></div><div class="toolbar"><div class="search"><input id="q" placeholder="Search name, number or location" value="${esc(query)}"><button onclick="query=document.getElementById('q').value;render()">Search</button></div><div class="actions tabs"><button class="${!trash?'active':''}" onclick="trash=false;refresh()">Active</button>${profile.role==='admin'?`<button class="${trash?'active':''}" onclick="trash=true;refresh()">Recycle Bin</button>`:''}${!trash&&!viewOwnerId?'<button class="primary" onclick="formModal()">+ Add Item</button>':''}</div></div><div class="table-wrap card"><table><thead><tr><th>Name</th><th>Number</th><th>Target</th><th>Given today</th><th>MTD</th><th>Remaining</th><th>Visits Made</th><th>Location</th><th>Owner</th><th>Actions</th></tr></thead><tbody>${active.map(row).join('')||`<tr><td colspan="10" class="empty">${trash?'Recycle Bin is empty.':'No items found.'}</td></tr>`}</tbody></table></div></div>`}
function row(x){let p=(x.daily_progress||[]).find(p=>p.date===today())||{};let canEdit=profile.role==='admin'||x.owner_id===user.id;return `<tr><td><b>${esc(x.name)}</b><br><small>${esc(x.personal_number||'')}</small></td><td>${esc(x.number)||'—'}</td><td>${money(x.float_target)}</td><td>${p.given==null?'—':money(p.given)}</td><td>${money(mtdFor(x))}</td><td>${money((+x.float_target||0)-mtdFor(x))}</td><td><span class="badge ${(+(p.visits_count||0)>0||p.visited)?'yes':''}">${+p.visits_count||(p.visited?1:0)}</span></td><td>${esc(x.location)||'—'}</td><td>${esc(x.owner_name||'')}</td><td><div class="row-actions">${trash?`<button onclick="restore('${x.id}')">Restore</button><button class="danger" onclick="permanentDelete('${x.id}')">Delete</button>`:`<button onclick="progressModal('${x.id}')">Daily</button><button onclick="historyModal('${x.id}')">History</button>${canEdit?`<button onclick="formModal('${x.id}')">Edit</button>`:''}${profile.role==='admin'?'':' '}${profile.role==='admin'?`<button class="danger" onclick="del('${x.id}')">Delete</button>`:''}`}</div></td></tr>`}
async function refresh(){await loadItems();render()}
async function viewUserItems(id,name){if(profile.role!=='admin')return;viewOwnerId=id;viewOwnerName=name||'User';trash=false;query='';document.querySelectorAll('.modal-bg').forEach(x=>x.remove());await refresh()}
async function clearOwnerView(){viewOwnerId=null;viewOwnerName='';trash=false;query='';await refresh()}
function overlay(html){let d=document.createElement('div');d.className='modal-bg';d.innerHTML=html;document.body.appendChild(d);return d}
function formModal(id){let x=items.find(i=>i.id===id)||{};let d=overlay(`<form class="modal" id="f"><h2>${id?'Edit':'Add'} item</h2><div class="grid"><label>Name *<input name="name" required value="${esc(x.name)}"></label><label>Number<input name="number" value="${esc(x.number)}"></label><label>Float target<input name="target" type="number" step="0.01" value="${x.float_target||0}"></label><label>Location<input name="location" value="${esc(x.location)}"></label><label>Personal number<input name="personal" value="${esc(x.personal_number)}"></label><label>Details<input name="details" value="${esc(x.details)}"></label></div><div class="actions"><button type="button" onclick="this.closest('.modal-bg').remove()">Cancel</button><button class="primary">Save</button></div></form>`);d.querySelector('#f').onsubmit=async e=>{e.preventDefault();let f=new FormData(e.target);let payload={name:f.get('name').trim(),number:f.get('number').trim(),float_target:+f.get('target')||0,location:f.get('location').trim(),personal_number:f.get('personal').trim(),details:f.get('details').trim()};let r=id?await sb.from('items').update(payload).eq('id',id):await sb.from('items').insert({...payload,owner_id:user.id,deleted:false});if(r.error)alert(r.error.message);else{d.remove();refresh()}}}
function progressModal(id){let x=items.find(i=>i.id===id);let d=overlay(`<form class="modal" id="p"><h2>Record a visit — ${esc(x.name)}</h2><div class="muted" style="margin-bottom:12px">Each save records one visit and adds this amount to the day's total.</div><div class="grid"><label>Date<input name="date" type="date" value="${today()}"></label><label>Amount given this visit<input name="given" type="number" min="0" step="0.01" value="0" required></label></div><label style="display:block;margin-top:10px">Notes<textarea name="notes" placeholder="Optional visit notes"></textarea></label><div class="actions"><button type="button" onclick="this.closest('.modal-bg').remove()">Cancel</button><button class="primary">Add Visit</button></div></form>`);d.querySelector('#p').onsubmit=async e=>{e.preventDefault();let f=new FormData(e.target),day=f.get('date'),amount=Number(f.get('given'));if(!Number.isFinite(amount)||amount<0)return alert('Enter a valid non-negative amount.');let all=x.daily_progress||[],idx=all.findIndex(p=>p.date===day),entry=idx>=0?{...all[idx]}:{date:day,given:0,visited:false,visits_count:0,notes:''};if(!Array.isArray(entry.visits)){entry.legacy_given=+entry.given||0;entry.legacy_visits=+(entry.visits_count||0)||(entry.visited?1:0);entry.legacy_notes=entry.notes||'';entry.visits=[];}let note=String(f.get('notes')||'').trim();entry.visits.push({id:(crypto.randomUUID?crypto.randomUUID():String(Date.now())+'-'+Math.random()),given:amount,notes:note,created_at:new Date().toISOString()});entry.given=(+entry.legacy_given||0)+entry.visits.reduce((sum,v)=>sum+(+v.given||0),0);entry.visits_count=(+entry.legacy_visits||0)+entry.visits.length;entry.visited=entry.visits_count>0;entry.notes=[...(entry.legacy_notes?[entry.legacy_notes]:[]),...entry.visits.map(v=>v.notes).filter(Boolean)].join(' | ');let updated=all.filter(p=>p.date!==day);updated.push(entry);let r=await sb.from('items').update({daily_progress:updated}).eq('id',id);if(r.error)alert(r.error.message);else{d.remove();refresh()}}}
function historyModal(id){
  let x=items.find(i=>i.id===id),rows=[...(x.daily_progress||[])].sort((a,b)=>b.date.localeCompare(a.date));
  let canEdit=profile.role==='admin'||x.owner_id===user.id;
  let d=overlay(`<div class="modal"><h2>Progress history — ${esc(x.name)}</h2><div id="historyError" class="error" style="display:none"></div><div class="table-wrap"><table><tr><th>Date</th><th>Given</th><th>Remaining</th><th>Visits Made</th><th>Notes / Visit actions</th></tr>${rows.map(p=>`<tr><td>${p.date}</td><td>${money(p.given)}</td><td>${money((+x.float_target||0)-(x.daily_progress||[]).filter(q=>q.date.startsWith(p.date.slice(0,7))&&q.date<=p.date).reduce((s,q)=>s+(+q.given||0),0))}</td><td>${+p.visits_count||(p.visited?1:0)}</td><td>${Array.isArray(p.visits)&&p.visits.length?p.visits.map((v,i)=>`<div style="padding:5px 0;border-bottom:1px solid var(--border)"><b>Visit ${i+1}:</b> ${money(v.given)} ${esc(v.notes||'')}${canEdit?` <button type="button" class="danger" data-delete-visit="1" data-item-id="${esc(x.id)}" data-day="${esc(p.date)}" data-visit-id="${esc(String(v.id))}">Delete visit</button>`:''}</div>`).join(''):`${esc(p.notes||'')}${Array.isArray(p.visits)?'':' <small class="muted">(Older combined record; individual visit amounts were not stored.)'}`}</td></tr>`).join('')||'<tr><td colspan="5" class="empty">No daily records yet.</td></tr>'}</table></div><div class="actions"><button type="button" id="closeHistory">Close</button></div></div>`);
  d.querySelector('#closeHistory').onclick=()=>d.remove();
  d.querySelectorAll('[data-delete-visit]').forEach(btn=>btn.addEventListener('click',()=>confirmDeleteVisit(btn.dataset.itemId,btn.dataset.day,btn.dataset.visitId)));
}
function showHistoryError(message){
  let el=document.getElementById('historyError');
  if(el){el.textContent=message;el.style.display='block';}
}
function confirmDeleteVisit(id,day,visitId){
  let c=overlay(`<div class="modal" style="max-width:420px"><h2>Delete visit?</h2><p>This will remove this visit and its recorded amount from the daily history.</p><div class="actions"><button type="button" id="cancelDelete">Cancel</button><button type="button" class="danger" id="confirmDelete">Delete visit</button></div></div>`);
  c.querySelector('#cancelDelete').onclick=()=>c.remove();
  c.querySelector('#confirmDelete').onclick=async()=>{c.remove();await deleteVisit(id,day,visitId);};
}
async function deleteVisit(id,day,visitId){
  try{
    const x=items.find(i=>i.id===id);
    if(!x)throw new Error('The item could not be found in the current app data. Close History and reopen it.');
    const all=Array.isArray(x.daily_progress)?x.daily_progress:[];
    const original=all.find(p=>p.date===day);
    if(!original)throw new Error('The selected day could not be found. Close History and reopen it.');
    if(!Array.isArray(original.visits))throw new Error('This record does not contain individual visits, so there is no visit ID to delete.');
    const before=original.visits.length;
    const remainingVisits=original.visits.filter(v=>String(v.id)!==String(visitId));
    if(remainingVisits.length===before)throw new Error('The selected visit was not found. Close History and reopen it.');
    const next={...original,visits:remainingVisits};
    const legacyGiven=Number(original.legacy_given||0);
    const legacyVisits=Number(original.legacy_visits||0)||(original.visited && !Array.isArray(original.visits)?1:0);
    const legacyNotes=String(original.legacy_notes||'');
    next.given=legacyGiven+remainingVisits.reduce((sum,v)=>sum+(Number(v.given)||0),0);
    next.visits_count=legacyVisits+remainingVisits.length;
    next.visited=next.visits_count>0;
    next.notes=[...(legacyNotes?[legacyNotes]:[]),...remainingVisits.map(v=>String(v.notes||'').trim()).filter(Boolean)].join(' | ');
    const updated=all.map(p=>p.date===day?next:p).filter(p=>p.date!==day || next.visits_count>0 || next.given!==0 || next.notes);
    const access=await sb.auth.getSession();
    const token=access&&access.data&&access.data.session&&access.data.session.access_token;
    if(!token)throw new Error('Your login session has expired. Log in again and retry.');
    const res=await fetch(SUPABASE_URL+'/rest/v1/items?id=eq.'+encodeURIComponent(id),{method:'PATCH',headers:{'Content-Type':'application/json','apikey':SUPABASE_ANON_KEY,'Authorization':'Bearer '+token,'Prefer':'return=representation'},body:JSON.stringify({daily_progress:updated})});
    let body=null;try{body=await res.json()}catch(_){}
    if(!res.ok)throw new Error((body&&(body.message||body.msg||body.error||body.details))||('Supabase update failed (HTTP '+res.status+').'));
    if(!Array.isArray(body)||body.length===0)throw new Error('Supabase accepted the request but updated 0 items. Check your items UPDATE policy.');
    document.querySelectorAll('.modal-bg').forEach(m=>m.remove());
    await refresh();
    historyModal(id);
  }catch(err){
    let msg=err&&err.message?err.message:String(err);
    let historyOpen=[...document.querySelectorAll('.modal-bg')].some(m=>m.querySelector('#historyError'));
    if(historyOpen)showHistoryError(msg);else alert('Delete visit failed: '+msg);
  }
}

function confirmItemAction(id, permanent){
  const x=items.find(i=>i.id===id);
  if(!x)return alert('Item not found. Refresh the list and try again.');
  const title=permanent?'Permanently delete item?':'Delete item?';
  const message=permanent?`Permanently delete <b>${esc(x.name)}</b> and all of its saved history? This cannot be undone.`:`Move <b>${esc(x.name)}</b> to the Recycle Bin? You can restore it later.`;
  const actionText=permanent?'Delete permanently':'Move to Recycle Bin';
  const c=overlay(`<div class="modal" style="max-width:460px"><h2>${title}</h2><p>${message}</p><div class="actions"><button type="button" id="cancelItemAction">Cancel</button><button type="button" class="danger" id="confirmItemAction">${actionText}</button></div><div id="itemActionError" class="error" style="display:none;margin-top:10px"></div></div>`);
  c.querySelector('#cancelItemAction').onclick=()=>c.remove();
  c.querySelector('#confirmItemAction').onclick=async()=>{
    const b=c.querySelector('#confirmItemAction');
    const e=c.querySelector('#itemActionError');
    b.disabled=true;b.textContent=permanent?'Deleting...':'Moving...';
    try{
      const r=permanent?await sb.from('items').delete().eq('id',id):await sb.from('items').update({deleted:true}).eq('id',id);
      if(r.error)throw new Error(r.error.message||'Database request failed');
      c.remove();
      await refresh();
    }catch(err){
      b.disabled=false;b.textContent=actionText;
      e.textContent=err&&err.message?err.message:String(err);
      e.style.display='block';
    }
  };
}

async function del(id){confirmItemAction(id,false)}

async function restore(id){
  try{
    const r=await sb.from('items').update({deleted:false}).eq('id',id);
    if(r.error)throw new Error(r.error.message||'Could not restore item');
    await refresh();
  }catch(err){alert('Restore failed: '+(err&&err.message?err.message:String(err)));}
}

async function permanentDelete(id){confirmItemAction(id,true)}
async function usersModal(){
  if(profile.role!=='admin')return;
  let r=await sb.from('profiles').select('*').order('created_at');
  if(r.error)return alert(r.error.message);
  let d=overlay(`<div class="modal" id="usersModal"><h2>User Management</h2><p class="muted">Tap <b>View Items</b> to see only that user's items. Your own items remain separate.</p><div id="userDeleteError" class="error" style="display:none"></div><div class="table-wrap"><table><tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Actions</th></tr>${r.data.map(p=>{
    const targetName=String(p.full_name||p.email||'User');
    return `<tr><td><b>${esc(p.full_name||'')}</b></td><td>${esc(p.email||'')}</td><td>${esc(p.role)}</td><td>${p.disabled?'Disabled':'Active'}</td><td class="row-actions">${p.id===user.id?'<span class="muted">Current user</span>':`<button type="button" data-view-user="${esc(p.id)}" data-view-name="${esc(targetName)}">View Items</button><button type="button" data-change-password="${esc(p.id)}" data-change-name="${esc(targetName)}">Change Password</button><button type="button" class="danger" data-delete-user="${esc(p.id)}" data-delete-name="${esc(targetName)}">Delete</button>`}</td></tr>`;
  }).join('')}</table></div><div class="actions"><button type="button" id="createUserOpen">+ Create User</button><button type="button" id="closeUsers">Close</button></div></div>`);
  d.querySelector('#createUserOpen').onclick=()=>{d.remove();createUserModal();};
  d.querySelector('#closeUsers').onclick=()=>d.remove();
  d.querySelectorAll('[data-view-user]').forEach(btn=>btn.addEventListener('click',()=>viewUserItems(btn.dataset.viewUser,btn.dataset.viewName)));
  d.querySelectorAll('[data-delete-user]').forEach(btn=>btn.addEventListener('click',()=>confirmDeleteUser(btn.dataset.deleteUser,btn.dataset.deleteName)));
  d.querySelectorAll('[data-change-password]').forEach(btn=>btn.addEventListener('click',()=>changeUserPasswordModal(btn.dataset.changePassword,btn.dataset.changeName)));
}

function showUserDeleteError(message){
  let el=document.getElementById('userDeleteError');
  if(el){el.textContent=message;el.style.display='block';}
}

function confirmDeleteUser(id,name){
  if(id===user.id)return alert('You cannot delete your own administrator account here.');
  let c=overlay(`<div class="modal" style="max-width:460px"><h2>Delete user?</h2><p>Permanently delete <b>${esc(name)}</b>? This removes the user's login account, profile, items, and item history.</p><div class="actions"><button type="button" id="cancelUserDelete">Cancel</button><button type="button" class="danger" id="confirmUserDelete">Delete user</button></div></div>`);
  c.querySelector('#cancelUserDelete').onclick=()=>c.remove();
  c.querySelector('#confirmUserDelete').onclick=async()=>{const b=c.querySelector('#confirmUserDelete');b.disabled=true;b.textContent='Deleting...';await deleteUser(id,name);if(document.body.contains(c))c.remove();};
}

async function deleteUser(id,name){
  if(id===user.id)return alert('You cannot delete your own administrator account here.');
  try{
    const session=await sb.auth.getSession();
    const accessToken=session&&session.data&&session.data.session&&session.data.session.access_token;
    if(!accessToken)throw new Error('Your admin session has expired. Please log in again.');
    const res=await fetch(SUPABASE_URL+'/functions/v1/admin-delete-user',{
      method:'POST',
      headers:{'Content-Type':'application/json','apikey':SUPABASE_ANON_KEY,'Authorization':'Bearer '+accessToken},
      body:JSON.stringify({user_id:id})
    });
    let j={};try{j=await res.json()}catch(_){ }
    if(!res.ok)throw new Error(j.error||j.message||('Could not delete user (HTTP '+res.status+')'));
    document.querySelectorAll('.modal-bg').forEach(x=>x.remove());
    await refresh();
    await usersModal();
  }catch(err){
    const msg=err&&err.message?err.message:String(err);
    const open=document.getElementById('usersModal');
    if(open){
      open.querySelectorAll('[data-delete-user]').forEach(btn=>{btn.disabled=false;btn.textContent='Delete';});
      showUserDeleteError(msg);
    }else alert('Delete user failed: '+msg);
  }
}


function changeUserPasswordModal(id,name){
  if(id===user.id)return alert('Use your own account settings to change the administrator password.');
  document.querySelectorAll('.modal-bg').forEach(x=>x.remove());
  const d=overlay(`<form class="modal" id="changePasswordForm" onsubmit="return false"><h2>Change Password</h2><p class="muted">Set a new password for <b>${esc(name)}</b>.</p><div id="changePasswordError" class="error" style="display:none"></div><div class="grid"><label>New password<input name="password" type="password" minlength="8" required autocomplete="new-password"></label><label>Confirm password<input name="confirm" type="password" minlength="8" required autocomplete="new-password"></label></div><div class="actions"><button type="button" id="cancelPassword">Cancel</button><button type="button" class="primary" id="savePassword">Change Password</button></div></form>`);
  d.querySelector('#cancelPassword').onclick=()=>d.remove();
  d.querySelector('#savePassword').onclick=async()=>{
    const button=d.querySelector('#savePassword');
    const errorBox=d.querySelector('#changePasswordError');
    const password=String(d.querySelector('[name="password"]').value||'');
    const confirm=String(d.querySelector('[name="confirm"]').value||'');
    errorBox.style.display='none';errorBox.textContent='';
    if(password.length<8){errorBox.textContent='Password must be at least 8 characters.';errorBox.style.display='block';return;}
    if(password!==confirm){errorBox.textContent='The two passwords do not match.';errorBox.style.display='block';return;}
    button.disabled=true;button.textContent='Changing...';
    try{
      const session=await sb.auth.getSession();
      const accessToken=session&&session.data&&session.data.session&&session.data.session.access_token;
      if(!accessToken)throw new Error('Your admin session has expired. Please log in again.');
      const res=await fetch(SUPABASE_URL+'/functions/v1/admin-change-password',{
        method:'POST',
        headers:{'Content-Type':'application/json','apikey':SUPABASE_ANON_KEY,'Authorization':'Bearer '+accessToken},
        body:JSON.stringify({user_id:id,password})
      });
      let j={};try{j=await res.json()}catch(_){ }
      if(!res.ok)throw new Error(j.error||j.message||('Could not change password (HTTP '+res.status+')'));
      d.remove();
      alert('Password changed successfully for '+name+'.');
    }catch(err){
      errorBox.textContent=err&&err.message?err.message:String(err);
      errorBox.style.display='block';
      button.disabled=false;button.textContent='Change Password';
    }
  };
  d.querySelectorAll('input').forEach(el=>el.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();d.querySelector('#savePassword').click();}}));
  return d;
}

async function createUserSubmit(d,button){
  const form=d.querySelector('#u');
  const f=new FormData(form);
  const name=String(f.get('name')||'').trim();
  const email=String(f.get('email')||'').trim();
  const password=String(f.get('password')||'');
  const role=String(f.get('role')||'agent');
  const errorBox=d.querySelector('#createError');
  const setError=(msg)=>{errorBox.textContent=msg||'';errorBox.style.display=msg?'block':'none'};
  setError('');
  if(!name||!email||password.length<8){setError('Enter a full name, valid email, and a password of at least 8 characters.');return;}
  button.disabled=true;button.textContent='Creating...';
  try{
    const session=await sb.auth.getSession();
    const accessToken=session&&session.data&&session.data.session&&session.data.session.access_token;
    if(!accessToken)throw new Error('Your admin session has expired. Please log in again.');
    const res=await fetch(SUPABASE_URL+'/functions/v1/admin-create-user',{method:'POST',headers:{'Content-Type':'application/json','apikey':SUPABASE_ANON_KEY,Authorization:'Bearer '+accessToken},body:JSON.stringify({email,password,full_name:name,role})});
    let j={};try{j=await res.json()}catch(_){ }
    if(!res.ok)throw new Error(j.error||j.message||('Could not create user (HTTP '+res.status+')'));
    d.remove();
    await usersModal();
  }catch(err){setError(err&&err.message?err.message:String(err));button.disabled=false;button.textContent='Create';}
}
function createUserModal(){
  document.querySelectorAll('.modal-bg').forEach(x=>x.remove());
  const d=overlay(`<form class="modal" id="u" onsubmit="return false"><h2>Create User</h2><div id="createError" class="error" style="display:none"></div><div class="grid"><label>Full name<input name="name" required autocomplete="name"></label><label>Email<input name="email" type="email" required autocomplete="email"></label><label>Temporary password<input name="password" type="password" minlength="8" required autocomplete="new-password"></label><label>Role<select name="role"><option value="agent">Agent</option><option value="admin">Administrator</option></select></label></div><div class="actions"><button type="button" onclick="this.closest('.modal-bg').remove()">Cancel</button><button type="button" class="primary" id="createUserBtn">Create</button></div></form>`);
  const button=d.querySelector('#createUserBtn');
  button.addEventListener('click',()=>createUserSubmit(d,button));
  d.querySelectorAll('input,select').forEach(el=>el.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();button.click();}}));
  return d;
}
async function logout(){await sb.auth.signOut();showLogin()}
if(configured()){
  try{sb=window.supabase.createClient(SUPABASE_URL,SUPABASE_ANON_KEY);boot().catch(e=>showLogin('App startup error: '+(e.message||e)));}
  catch(e){showLogin('Could not start the app: '+(e.message||e));}
}else showLogin();
