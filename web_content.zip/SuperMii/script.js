// Database Soal
const questionsData = {
  mtk: [
    { q: "Jika 3 + 3 x 3 - 3 = ?", options: ["6", "9", "12", "15"], answer: 1 },
    { q: "Berapa 15% dari 200?", options: ["20", "25", "30", "35"], answer: 2 }
  ],
  spasial: [
    { q: "Bayangkan sebuah kubus dibuka. Ada berapa jumlah persegi pembentuk jaring-jaring kubus?", options: ["4", "5", "6", "8"], answer: 2 }
  ],
  logika: [
    { q: "Seorang ayah memiliki 4 anak perempuan. Setiap anak perempuan memiliki 1 saudara laki-laki. Berapa total anak ayah tersebut?", options: ["8 Anak", "5 Anak", "4 Anak", "9 Anak"], answer: 1 }
  ]
};

let selectedCategory = '';
let rulesTimer = null;
let gameTimer = null;

let rulesTimeLeft = 30;
let gameTimeLeft = 80 * 60; // 80 Menit dalam Detik (4800s)

// Statistik Hasil Jawaban
let totalAnswered = 0;
let correctCount = 0;
let wrongCount = 0;
let currentQuestionIndex = 0;

// Flag pemicu audio
let alertTriggered = false;
let countdown10Triggered = false;

// 1. Membuka Halaman Rules
function openRules(categoryKey) {
  selectedCategory = categoryKey;

  document.getElementById('home-screen').classList.remove('active');
  document.getElementById('rules-screen').classList.add('active');

  const rulesAudio = document.getElementById('audio-rules');
  if (rulesAudio) {
    try {
      rulesAudio.currentTime = 0;
      rulesAudio.play().catch(e => console.log(e));
    } catch(e){}
  }

  rulesTimeLeft = 30;
  const btnStart = document.getElementById('btn-start-quiz');
  btnStart.disabled = true;
  btnStart.innerHTML = `MULAI SOAL (<span id="timer-count">${rulesTimeLeft}</span>s)`;

  clearInterval(rulesTimer);
  rulesTimer = setInterval(() => {
    rulesTimeLeft--;
    const timerElem = document.getElementById('timer-count');
    if (timerElem) timerElem.innerText = rulesTimeLeft;

    if (rulesTimeLeft <= 0) {
      clearInterval(rulesTimer);
      btnStart.disabled = false;
      btnStart.innerText = "MULAI SOAL →";
    }
  }, 1000);
}

// 2. Memulai Kuis & Timer Game 80 Menit
function startQuiz() {
  const rulesAudio = document.getElementById('audio-rules');
  if (rulesAudio) rulesAudio.pause();

  document.getElementById('rules-screen').classList.remove('active');
  document.getElementById('quiz-screen').classList.add('active');

  // Reset Variabel
  totalAnswered = 0;
  correctCount = 0;
  wrongCount = 0;
  currentQuestionIndex = 0;
  alertTriggered = false;
  countdown10Triggered = false;

  // Set Waktu 80 Menit (4800 Detik)
  // *Untuk pengujian cepat, ganti 80 * 60 menjadi 35 (35 detik)*
  gameTimeLeft = 80 * 60; 

  showQuestion();
  startMainGameTimer();
}

// 3. Menjalankan Countdown 80 Menit, Alert 30s, & Audio 10s
function startMainGameTimer() {
  clearInterval(gameTimer);

  gameTimer = setInterval(() => {
    gameTimeLeft--;

    // Update Tampilan Timer M:S
    const mins = Math.floor(gameTimeLeft / 60);
    const secs = gameTimeLeft % 60;
    document.getElementById('game-timer').innerText = 
      `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;

    // A. Ketika waktu tersisa 30 Detik: Putar alert.mp3 & Efek Merah Samping
    if (gameTimeLeft <= 30 && !alertTriggered) {
      alertTriggered = true;
      document.getElementById('game-container').classList.add('critical-warning');
      document.getElementById('game-timer').style.color = '#ff4b2b';

      const audioAlert = document.getElementById('audio-alert');
      if (audioAlert) {
        audioAlert.currentTime = 0;
        audioAlert.play().catch(e => console.log(e));
      }
    }

    // B. Ketika waktu tersisa 10 Detik: Putar 10.mp3
    if (gameTimeLeft <= 10 && !countdown10Triggered) {
      countdown10Triggered = true;

      const audio10 = document.getElementById('audio-10');
      if (audio10) {
        audio10.currentTime = 0;
        audio10.play().catch(e => console.log(e));
      }
    }

    // C. Ketika Waktu Habis (0 Detik)
    if (gameTimeLeft <= 0) {
      clearInterval(gameTimer);
      finishGame();
    }
  }, 1000);
}

// 4. Menampilkan Pertanyaan Kuis
function showQuestion() {
  const categoryNames = {
    mtk: 'MATEMATIKA DASAR',
    spasial: 'SPASIAL',
    logika: 'LOGIKA'
  };
  
  document.getElementById('quiz-category').innerText = categoryNames[selectedCategory];
  
  const qList = questionsData[selectedCategory];
  if (currentQuestionIndex < qList.length) {
    const qData = qList[currentQuestionIndex];
    document.getElementById('question-text').innerText = `${currentQuestionIndex + 1}. ${qData.q}`;
    
    const optionsContainer = document.getElementById('options-container');
    optionsContainer.innerHTML = '';
    
    qData.options.forEach((optText, index) => {
      const btn = document.createElement('button');
      btn.className = 'opt-btn';
      btn.innerText = `${String.fromCharCode(65 + index)}. ${optText}`;
      btn.onclick = () => checkAnswer(index, qData.answer);
      optionsContainer.appendChild(btn);
    });
  } else {
    finishGame(); // Selesai jika semua soal habis
  }
}

// 5. Memeriksa Jawaban
function checkAnswer(selectedIndex, correctIndex) {
  totalAnswered++;
  if (selectedIndex === correctIndex) {
    correctCount++;
  } else {
    wrongCount++;
  }

  currentQuestionIndex++;
  showQuestion();
}

// 6. Menyelesaikan Permainan & Menampilkan Halaman Hasil Penilaian
function finishGame() {
  clearInterval(gameTimer);

  // Matikan semua audio
  const audioAlert = document.getElementById('audio-alert');
  const audio10 = document.getElementById('audio-10');
  if (audioAlert) audioAlert.pause();
  if (audio10) audio10.pause();

  // Reset Efek Merah Samping
  document.getElementById('game-container').classList.remove('critical-warning');
  document.getElementById('game-timer').style.color = '#00f2fe';
  document.getElementById('game-timer').innerText = "80:00";

  // Tampilkan Nilai di Result Screen
  document.getElementById('res-answered').innerText = totalAnswered;
  document.getElementById('res-correct').innerText = correctCount;
  document.getElementById('res-wrong').innerText = wrongCount;
  
  // Penilaian Skor (Contoh: Jawaban Benar x 10)
  document.getElementById('res-score').innerText = correctCount * 10;

  // Pindah Tampilan ke Result Screen
  document.getElementById('quiz-screen').classList.remove('active');
  document.getElementById('result-screen').classList.add('active');
}

// 7. Kembali ke Beranda
function goHome() {
  clearInterval(rulesTimer);
  clearInterval(gameTimer);
  
  const rulesAudio = document.getElementById('audio-rules');
  const audioAlert = document.getElementById('audio-alert');
  const audio10 = document.getElementById('audio-10');
  
  if (rulesAudio) rulesAudio.pause();
  if (audioAlert) audioAlert.pause();
  if (audio10) audio10.pause();

  document.getElementById('game-container').classList.remove('critical-warning');
  document.getElementById('game-timer').style.color = '#00f2fe';
  document.getElementById('game-timer').innerText = "80:00";

  document.getElementById('quiz-screen').classList.remove('active');
  document.getElementById('rules-screen').classList.remove('active');
  document.getElementById('result-screen').classList.remove('active');
  document.getElementById('home-screen').classList.add('active');
}
