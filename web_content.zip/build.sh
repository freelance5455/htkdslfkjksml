#!/usr/bin/env bash
# ==============================================================================
# Task Pro Earning 2 - Master Build Pipeline
# ==============================================================================
set -e

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
bash "$DIR/scripts/build-android-apk.sh"
