#!/data/data/com.termux/files/usr/bin/bash
set -e

mkdir -p ~/Connectly
cd ~/Connectly

cat > index.html <<'HTML'
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Connectly</title>
<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
<style>
*{box-sizing:border-box}
body{margin:0;background:#10151d;color:#f5f7fa;font-family:Arial}
header{padding:19px;background:#172331;color:#51d6ae;font-size:25px;font-weight:bold}
main{padding:15px;max-width:650px;margin:auto}
input,button{padding:13px;border:0;border-radius:10px;width:100%;margin:5px 0;font-size:15px}
input{background:#202c39;color:white}
button{background:#19b98c;color:#071b16;font-weight:bold}
.secondary{background:#26394a;color:white}
.card{background:#192431;padding:13px;border-radius:12px;margin:9px 0}
.row{display:flex;gap:7px;align-items:center}
.row input{flex:1;min-width:0}
.row button{width:auto;white-space:nowrap}
.small{font-size:12px;color:#a7b5c3}
#messages{height:42vh;overflow:auto;background:#141e29;padding:10px;border-radius:12px}
.msg{padding:11px;margin:7px 0;border-radius:12px;background:#26394a;max-width:85%;overflow-wrap:anywhere}
.mine{background:#087e67;margin-left:auto}
.msg audio{width:100%;max-width:240px}
.hidden{display:none!important}
.chat{display:flex;align-items:center;gap:10px;text-align:left}
.avatar{width:42px;height:42px;border-radius:50%;background:#087e67;display:grid;place-items:center;color:white;font-weight:bold;flex-shrink:0}
.chatinfo{flex:1;min-width:0}
.chatinfo div{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
#record{background:#b44c58;color:white}
</style>
</head>
<body>
<header>CONNECTLY <span class="small">●</span></header>
<main>
<section id="login">
<h2>Welcome to Connectly</h2>
<p class="small">Your conversations, all in one place.</p>
<input id="email" placeholder="Email address">
<input id="password" type="password" placeholder="Password">
<button onclick="signup()">Create Account</button>
<button class="secondary" onclick="login()">Login</button>
<p id="status" class="small"></p>
</section>

<section id="app" class="hidden">
<div class="card">
<div class="small">YOUR PROFILE</div>
<div id="user"></div>
<div class="row">
<input id="username" placeholder="Choose a username">
<button onclick="saveUsername()">Save</button>
</div>
<button class="secondary" onclick="logout()">Logout</button>
</div>

<h3>Find people</h3>
<div class="row">
<input id="search" placeholder="Search username or email">
<button onclick="findUsers()">Search</button>
</div>
<div id="results"></div>

<div class="row">
<h3 style="flex:1">Recent Chats</h3>
<button class="secondary" onclick="loadChats()">↻</button>
</div>
<button class="secondary" onclick="newGroup()">＋ Create Group</button>
<div id="chats"></div>

<section id="room" class="hidden">
<div class="row">
<h3 id="roomname" style="flex:1"></h3>
<button class="secondary" onclick="closeRoom()">Back</button>
</div>
<div id="messages"></div>
<p id="typing" class="small"></p>
<div class="row">
<input id="message" placeholder="Write a message..."
 onkeydown="if(event.key==='Enter')send()">
<button onclick="send()">Send</button>
</div>
<div class="row">
<button id="record" onclick="toggleRecording()">🎙 Record voice</button>
<span id="recordstatus" class="small"></span>
</div>
</section>
</section>
</main>

<script>
const SUPABASE_URL="https://fkaqmsrtllzsebbvyfxn.supabase.co";
const SUPABASE_KEY="sb_publishable_UVsn2XSJ0BiMPiGWevFxgw_HwNgGy-K";
const db=supabase.createClient(SUPABASE_URL,SUPABASE_KEY);

let me=null,active=null,channel=null,recorder=null,recordStream=null;
let chunks=[],recording=false;

const $=id=>document.getElementById(id);

async function signup(){
 const {data,error}=await db.auth.signUp({
  email:$('email').value.trim(),
  password:$('password').value
 });
 $('status').textContent=error?error.message:
 "Account created. Check your email if confirmation is enabled.";
 if(data.user && data.session)start(data.user);
}

async function login(){
 const {data,error}=await db.auth.signInWithPassword({
  email:$('email').value.trim(),
  password:$('password').value
 });
 if(error){$('status').textContent=error.message;return}
 start(data.user);
}

async function logout(){
 await db.auth.signOut();
 location.reload();
}

async function start(user){
 me=user;
 $('login').classList.add('hidden');
 $('app').classList.remove('hidden');
 $('user').textContent=user.email;

 const {data,error}=await db.from('profiles').upsert({
  id:user.id,email:user.email
 }).select().single();

 if(error)console.error(error);
 $('username').value=data?.username||'';
 loadChats();
}

async function saveUsername(){
 let name=$('username').value.trim().toLowerCase();
 if(!/^[a-z0-9_]{3,20}$/.test(name)){
  alert('Username must be 3-20 characters: letters, numbers or underscore.');
  return;
 }
 const {error}=await db.from('profiles')
 .update({username:name}).eq('id',me.id);
 if(error){alert(error.message);return}
 alert('Username saved!');
}

async function findUsers(){
 const q=$('search').value.trim();
 if(!q)return;
 const {data,error}=await db.from('profiles')
 .select('id,email,username')
 .neq('id',me.id)
 .or('username.ilike.%'+q+'%,email.ilike.%'+q+'%')
 .limit(15);

 $('results').innerHTML='';
 if(error){$('results').textContent=error.message;return}
 (data||[]).forEach(p=>{
  const b=document.createElement('button');
  b.className='secondary';
  b.textContent='@'+(p.username||p.email);
  b.onclick=()=>createChat(p.id,p.username||p.email);
  $('results').appendChild(b);
 });
}

async function createChat(other,name){
 const {data:existing,error}=await db.from('chat_members')
 .select('chat_id').eq('user_id',me.id);
 if(error){alert(error.message);return}

 for(const item of existing||[]){
  const {data:members}=await db.from('chat_members')
   .select('user_id').eq('chat_id',item.chat_id);
  if(members?.some(x=>x.user_id===other)){
   return openChat(item.chat_id,name);
  }
 }

 const {data:chat,error:e}=await db.from('chats')
 .insert({name,is_group:false,created_by:me.id})
 .select().single();
 if(e){alert(e.message);return}

 const {error:memberError}=await db.from('chat_members').insert([
  {chat_id:chat.id,user_id:me.id},
  {chat_id:chat.id,user_id:other}
 ]);
 if(memberError){alert(memberError.message);return}
 loadChats();
 openChat(chat.id,name);
}

async function newGroup(){
 const name=prompt('Enter group name');
 if(!name)return;
 const emails=prompt('Enter participant usernames or emails separated by commas');
 const ids=[me.id];

 if(emails){
  const terms=emails.split(',').map(x=>x.trim()).filter(Boolean);
  for(const term of terms){
   const {data}=await db.from('profiles')
    .select('id').or('email.ilike.'+term+',username.ilike.'+term);
   (data||[]).forEach(p=>ids.push(p.id));
  }
 }
 const {data:chat,error}=await db.from('chats')
 .insert({name,is_group:true,created_by:me.id})
 .select().single();
 if(error){alert(error.message);return}

 const {error:e}=await db.from('chat_members').insert(
  [...new Set(ids)].map(id=>({chat_id:chat.id,user_id:id}))
 );
 if(e){alert(e.message);return}
 loadChats();
 openChat(chat.id,name);
}

async function loadChats(){
 const {data,error}=await db.from('chat_members')
 .select('chat_id,chats(id,name,is_group,created_at,last_message_at)')
 .eq('user_id',me.id);

 $('chats').innerHTML='';
 if(error){$('chats').textContent=error.message;return}

 const list=(data||[]).filter(x=>x.chats).sort((a,b)=>
  new Date(b.chats.last_message_at||b.chats.created_at)-
  new Date(a.chats.last_message_at||a.chats.created_at)
 );

 for(const item of list){
  const c=item.chats;
  const {data:last}=await db.from('messages')
   .select('content,message_type,created_at')
   .eq('chat_id',c.id)
   .order('created_at',{ascending:false}).limit(1);

  const button=document.createElement('button');
  button.className='secondary chat';
  const avatar=document.createElement('div');
  avatar.className='avatar';
  avatar.textContent=c.is_group?'G':(c.name||'C')[0].toUpperCase();

  const info=document.createElement('div');
  info.className='chatinfo';
  const title=document.createElement('div');
  title.textContent=(c.is_group?'👥 ':'')+c.name;
  const preview=document.createElement('div');
  preview.className='small';
  preview.textContent=last?.[0]?
   (last[0].message_type==='voice'?'🎙 Voice message':last[0].content):
   'Start a conversation';

  info.append(title,preview);
  button.append(avatar,info);
  button.onclick=()=>openChat(c.id,c.name);
  $('chats').appendChild(button);
 }
}

async function openChat(id,name){
 active=id;
 $('room').classList.remove('hidden');
 $('roomname').textContent=name;
 await loadMessages();

 if(channel)await db.removeChannel(channel);
 channel=db.channel('room-'+id)
 .on('postgres_changes',{
  event:'INSERT',schema:'public',table:'messages',
  filter:'chat_id=eq.'+id
 },payload=>showMessage(payload.new))
 .subscribe();
}

async function loadMessages(){
 $('messages').innerHTML='';
 const {data,error}=await db.from('messages')
 .select('*').eq('chat_id',active)
 .order('created_at',{ascending:true}).limit(100);
 if(error){$('messages').textContent=error.message;return}
 for(const m of data||[])await showMessage(m);
}

async function showMessage(m){
 if(m.chat_id!==active)return;
 if(document.querySelector('[data-id="'+m.id+'"]'))return;

 const el=document.createElement('div');
 el.className='msg '+(m.sender_id===me.id?'mine':'');
 el.dataset.id=m.id;

 if(m.message_type==='voice'&&m.media_path){
  const {data,error}=await db.storage.from('connectly-voice')
   .createSignedUrl(m.media_path,3600);
  if(error){el.textContent='Voice message unavailable';}
  else{
   const audio=document.createElement('audio');
   audio.controls=true;
   audio.src=data.signedUrl;
   el.appendChild(audio);
  }
 }else{
  const content=document.createElement('div');
  content.textContent=m.content||'';
  el.appendChild(content);
 }
 const time=document.createElement('div');
 time.className='small';
 time.textContent=new Date(m.created_at).toLocaleTimeString();
 el.appendChild(time);
 $('messages').appendChild(el);
 $('messages').scrollTop=$('messages').scrollHeight;
}

async function send(){
 const content=$('message').value.trim();
 if(!content||!active)return;
 $('message').value='';
 const {error}=await db.from('messages').insert({
  chat_id:active,sender_id:me.id,content,
  message_type:'text'
 });
 if(error)alert(error.message);
 else loadChats();
}

async function toggleRecording(){
 if(recording){
  recorder.stop();
  return;
 }
 if(!navigator.mediaDevices?.getUserMedia||!window.MediaRecorder){
  alert('Voice recording is not supported by this app environment.');
  return;
 }
 try{
  recordStream=await navigator.mediaDevices.getUserMedia({audio:true});
  const types=['audio/webm;codecs=opus','audio/webm','audio/mp4'];
  const mime=types.find(t=>MediaRecorder.isTypeSupported(t));
  recorder=new MediaRecorder(recordStream,mime?{mimeType:mime}:{});
  chunks=[];
  recorder.ondataavailable=e=>{if(e.data.size)chunks.push(e.data)};
  recorder.onstop=uploadVoice;
  recorder.start();
  recording=true;
  $('record').textContent='■ Stop recording';
  $('recordstatus').textContent='Recording...';
 }catch(e){
  alert('Microphone permission required: '+e.message);
 }
}

async function uploadVoice(){
 recording=false;
 $('record').textContent='🎙 Record voice';
 $('recordstatus').textContent='Uploading...';
 recordStream?.getTracks().forEach(t=>t.stop());

 try{
  const blob=new Blob(chunks,{type:recorder.mimeType||'audio/webm'});
  if(blob.size>10*1024*1024){
   alert('Voice message is too large (maximum 10 MB).');
   $('recordstatus').textContent='';
   return;
  }
  const ext=blob.type.includes('mp4')?'mp4':
   blob.type.includes('ogg')?'ogg':'webm';
  const path=active+'/'+me.id+'/'+Date.now()+'.'+ext;

  const {error}=await db.storage.from('connectly-voice')
   .upload(path,blob,{contentType:blob.type});
  if(error)throw error;

  const {error:msgError}=await db.from('messages').insert({
   chat_id:active,sender_id:me.id,content:'',
   message_type:'voice',media_path:path
  });
  if(msgError)throw msgError;
  $('recordstatus').textContent='Voice sent';
  loadChats();
 }catch(e){
  alert('Voice upload failed: '+e.message);
  $('recordstatus').textContent='';
 }
}

function closeRoom(){
 active=null;
 $('room').classList.add('hidden');
 if(channel){db.removeChannel(channel);channel=null}
 loadChats();
}

db.auth.getSession().then(({data})=>{
 if(data.session)start(data.session.user);
});
</script>
</body>
</html>
HTML

cat > database-upgrade.sql <<'SQL'
-- CONNECTLY V2 DATABASE MIGRATION

-- Username and recent chat fields
ALTER TABLE public.profiles
ADD COLUMN IF NOT EXISTS username TEXT;

CREATE UNIQUE INDEX IF NOT EXISTS profiles_username_unique
ON public.profiles (LOWER(username))
WHERE username IS NOT NULL;

ALTER TABLE public.chats
ADD COLUMN IF NOT EXISTS last_message_at TIMESTAMPTZ;

UPDATE public.chats
SET last_message_at=created_at
WHERE last_message_at IS NULL;

ALTER TABLE public.messages
ADD COLUMN IF NOT EXISTS message_type TEXT NOT NULL DEFAULT 'text';

ALTER TABLE public.messages
ADD COLUMN IF NOT EXISTS media_path TEXT;

-- Safe membership function (avoids recursive RLS)
CREATE OR REPLACE FUNCTION public.is_connectly_member(p_chat_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path=public
AS $$
 SELECT EXISTS (
  SELECT 1 FROM public.chat_members
  WHERE chat_id=p_chat_id AND user_id=(SELECT auth.uid())
 );
$$;

CREATE OR REPLACE FUNCTION public.is_connectly_creator(p_chat_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path=public
AS $$
 SELECT EXISTS (
  SELECT 1 FROM public.chats
  WHERE id=p_chat_id AND created_by=(SELECT auth.uid())
 );
$$;

REVOKE ALL ON FUNCTION public.is_connectly_member(uuid) FROM public;
REVOKE ALL ON FUNCTION public.is_connectly_creator(uuid) FROM public;
GRANT EXECUTE ON FUNCTION public.is_connectly_member(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_connectly_creator(uuid) TO authenticated;

-- Repair chat and membership policies
DROP POLICY IF EXISTS "Read member chats" ON public.chats;
DROP POLICY IF EXISTS "Create chats" ON public.chats;
DROP POLICY IF EXISTS "Read memberships" ON public.chat_members;
DROP POLICY IF EXISTS "Add members" ON public.chat_members;
DROP POLICY IF EXISTS "Read messages" ON public.messages;
DROP POLICY IF EXISTS "Send messages" ON public.messages;

CREATE POLICY "Read member chats" ON public.chats
FOR SELECT TO authenticated
USING (
 created_by=(SELECT auth.uid())
 OR public.is_connectly_member(id)
);

CREATE POLICY "Create chats" ON public.chats
FOR INSERT TO authenticated
WITH CHECK (created_by=(SELECT auth.uid()));

CREATE POLICY "Read memberships" ON public.chat_members
FOR SELECT TO authenticated
USING (public.is_connectly_member(chat_id));

CREATE POLICY "Add members" ON public.chat_members
FOR INSERT TO authenticated
WITH CHECK (public.is_connectly_creator(chat_id));

CREATE POLICY "Read messages" ON public.messages
FOR SELECT TO authenticated
USING (public.is_connectly_member(chat_id));

CREATE POLICY "Send messages" ON public.messages
FOR INSERT TO authenticated
WITH CHECK (
 sender_id=(SELECT auth.uid())
 AND public.is_connectly_member(chat_id)
);

-- Recent chat timestamp trigger
CREATE OR REPLACE FUNCTION public.connectly_update_chat_time()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path=public
AS $$
BEGIN
 UPDATE public.chats
 SET last_message_at=NEW.created_at
 WHERE id=NEW.chat_id;
 RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS connectly_message_timestamp ON public.messages;

CREATE TRIGGER connectly_message_timestamp
AFTER INSERT ON public.messages
FOR EACH ROW
EXECUTE FUNCTION public.connectly_update_chat_time();

-- Private voice message storage
INSERT INTO storage.buckets
(id,name,public,file_size_limit,allowed_mime_types)
VALUES (
 'connectly-voice','connectly-voice',false,10485760,
 ARRAY['audio/webm','audio/ogg','audio/mp4','audio/mpeg','audio/wav','audio/aac']
)
ON CONFLICT(id) DO UPDATE SET
 public=false,file_size_limit=10485760,
 allowed_mime_types=EXCLUDED.allowed_mime_types;

DROP POLICY IF EXISTS "Connectly voice read" ON storage.objects;
DROP POLICY IF EXISTS "Connectly voice upload" ON storage.objects;

CREATE POLICY "Connectly voice read"
ON storage.objects FOR SELECT TO authenticated
USING (
 bucket_id='connectly-voice'
 AND public.is_connectly_member(
  (storage.foldername(name))[1]::uuid
 )
);

CREATE POLICY "Connectly voice upload"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (
 bucket_id='connectly-voice'
 AND (storage.foldername(name))[2]=(SELECT auth.uid())::text
 AND public.is_connectly_member(
  (storage.foldername(name))[1]::uuid
 )
);
SQL

cat > README.txt <<'TXT'
CONNECTLY V2

Features:
- Email registration and login
- Username profiles and search
- Recent chats
- One-to-one messaging
- Group creation
- Real-time text messages
- Voice recording and playback
- Private voice-message storage

SETUP:
1. Run database-upgrade.sql in your Connectly Supabase SQL Editor.
2. Enable Email authentication in Supabase.
3. Rebuild the ZIP after the SQL migration succeeds.
4. Convert the ZIP using a web-app-compatible APK converter.
5. Allow microphone permission in the Android app.

Voice messages require microphone permission and HTTPS/WebView support.
This is an MVP, not a production-audited messaging service.
TXT

zip -r -FS ~/Connectly.zip index.html database-upgrade.sql README.txt build.sh

mkdir -p ~/storage/shared
cp ~/Connectly.zip ~/storage/shared/Connectly.zip 2>/dev/null || true

echo
echo "CONNECTLY V2 ZIP CREATED"
echo "Location: ~/Connectly.zip"
echo "Shared storage: ~/storage/shared/Connectly.zip (if permitted)"
echo "SQL migration: ~/Connectly/database-upgrade.sql"
