# MyAI V1

A ChatGPT-style AI assistant starter app built with:

- HTML/CSS/JavaScript frontend
- Node.js + Express backend
- Secure server-side API key handling
- Chat history in browser localStorage
- New chat / clear chat
- Light/dark theme
- Mobile responsive UI
- Enter to send, Shift+Enter for a new line
- Basic Markdown/code-block rendering

## 1. Requirements

Install Node.js 18+.

## 2. Install

Open a terminal in this project folder:

```bash
npm install
```

## 3. Configure the AI API

Copy `.env.example` to `.env`.

Then put your API key in:

```env
OPENAI_API_KEY=your_real_key
OPENAI_MODEL=gpt-4o-mini
```

Do not put your API key inside `public/app.js` or any frontend file.

## 4. Run

```bash
npm start
```

Open:

http://localhost:3000

For development:

```bash
npm run dev
```

## Project structure

```text
MyAI-V1/
├── public/
│   ├── index.html
│   ├── style.css
│   └── app.js
├── .env.example
├── .gitignore
├── package.json
├── server.js
└── README.md
```

## Important

This is V1. It is a working foundation, not a production clone of ChatGPT.

Possible V2 upgrades:
- user accounts and authentication
- streaming responses
- persistent database chat history
- file upload
- image input
- voice input/output
- conversation search
- admin panel
- rate limiting
- model selector
- deployment configuration
