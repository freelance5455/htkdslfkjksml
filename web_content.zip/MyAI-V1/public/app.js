const state = {
  messages: [],
  chats: JSON.parse(localStorage.getItem("myai_chats") || "[]"),
  busy: false
};

const $ = (s) => document.querySelector(s);
const messagesEl = $("#messages");
const welcomeEl = $("#welcome");
const input = $("#input");
const sendBtn = $("#sendBtn");
const chatList = $("#chatList");

function escapeHtml(str) {
  return str.replace(/[&<>"']/g, ch => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#039;"
  }[ch]));
}

function renderText(text) {
  const safe = escapeHtml(text);
  return safe
    .replace(/```([\s\S]*?)```/g, "<pre><code>$1</code></pre>")
    .replace(/`([^`]+)`/g, "<code>$1</code>")
    .replace(/\n\n/g, "</p><p>")
    .replace(/\n/g, "<br>");
}

function addMessage(role, content, temporary = false) {
  const wrap = document.createElement("div");
  wrap.className = `message ${role}`;
  if (temporary) wrap.dataset.temp = "true";

  if (role === "user") {
    wrap.innerHTML = `<div class="bubble">${renderText(content)}</div>`;
  } else {
    wrap.innerHTML = `
      <div class="avatar">M</div>
      <div class="bubble"><p>${renderText(content)}</p></div>
    `;
  }

  messagesEl.appendChild(wrap);
  $("#chat").scrollTop = $("#chat").scrollHeight;
}

function clearRenderedMessages() {
  messagesEl.innerHTML = "";
  welcomeEl.style.display = "block";
}

function startNewChat() {
  state.messages = [];
  clearRenderedMessages();
  input.value = "";
  input.focus();
  renderChatList();
}

function saveCurrentChat() {
  if (!state.messages.length) return;

  const firstUser = state.messages.find(m => m.role === "user");
  const title = (firstUser?.content || "New chat").slice(0, 45);

  state.chats = state.chats.filter(c => c.id !== currentChatId);
  const chat = { id: currentChatId, title, messages: state.messages, updatedAt: Date.now() };
  state.chats.unshift(chat);
  state.chats = state.chats.slice(0, 30);
  localStorage.setItem("myai_chats", JSON.stringify(state.chats));
  renderChatList();
}

let currentChatId = crypto.randomUUID();

function renderChatList() {
  chatList.innerHTML = "";
  state.chats.forEach(chat => {
    const btn = document.createElement("button");
    btn.className = "chat-item";
    btn.textContent = chat.title;
    btn.onclick = () => loadChat(chat.id);
    chatList.appendChild(btn);
  });
}

function loadChat(id) {
  const chat = state.chats.find(c => c.id === id);
  if (!chat) return;
  currentChatId = id;
  state.messages = [...chat.messages];
  clearRenderedMessages();
  welcomeEl.style.display = "none";
  state.messages.forEach(m => addMessage(m.role, m.content));
}

async function sendMessage(text) {
  if (!text.trim() || state.busy) return;

  state.busy = true;
  sendBtn.disabled = true;
  welcomeEl.style.display = "none";

  const userText = text.trim();
  input.value = "";
  input.style.height = "auto";

  state.messages.push({ role: "user", content: userText });
  addMessage("user", userText);

  addMessage("assistant", '<span class="typing">MyAI is thinking<span class="dots"></span></span>', true);

  try {
    const res = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ messages: state.messages })
    });

    const data = await res.json();
    document.querySelector('[data-temp="true"]')?.remove();

    if (!res.ok) throw new Error(data.error || "Request failed.");

    state.messages.push({ role: "assistant", content: data.answer });
    addMessage("assistant", data.answer);
    saveCurrentChat();
  } catch (err) {
    document.querySelector('[data-temp="true"]')?.remove();
    addMessage("assistant", `Error: ${err.message}`);
  } finally {
    state.busy = false;
    sendBtn.disabled = false;
    input.focus();
  }
}

$("#composer").addEventListener("submit", e => {
  e.preventDefault();
  sendMessage(input.value);
});

input.addEventListener("input", () => {
  input.style.height = "auto";
  input.style.height = Math.min(input.scrollHeight, 180) + "px";
});

input.addEventListener("keydown", e => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    $("#composer").requestSubmit();
  }
});

document.querySelectorAll(".suggestions button").forEach(btn => {
  btn.addEventListener("click", () => sendMessage(btn.dataset.prompt));
});

$("#newChatBtn").onclick = startNewChat;

$("#clearBtn").onclick = () => {
  state.messages = [];
  clearRenderedMessages();
  state.chats = state.chats.filter(c => c.id !== currentChatId);
  localStorage.setItem("myai_chats", JSON.stringify(state.chats));
  renderChatList();
};

$("#themeBtn").onclick = () => {
  document.body.classList.toggle("dark");
  localStorage.setItem("myai_theme", document.body.classList.contains("dark") ? "dark" : "light");
};

$("#menuBtn").onclick = () => $("#sidebar").classList.toggle("open");

if (localStorage.getItem("myai_theme") === "dark") {
  document.body.classList.add("dark");
}

renderChatList();
