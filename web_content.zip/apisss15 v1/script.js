document.addEventListener('DOMContentLoaded', () => {
    // LOGIN LOGIC
    const loginBtn = document.getElementById('login-btn');
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    const loginError = document.getElementById('login-error');
    const loginScreen = document.getElementById('login-screen');
    const appScreen = document.getElementById('app-screen');

    loginBtn.addEventListener('click', () => {
        const u = usernameInput.value.trim();
        const p = passwordInput.value.trim();

        if (u === 'apisss' && p === 'apisss15') {
            loginScreen.classList.remove('active');
            appScreen.classList.add('active');
            showToast('Login Berhasil! Selamat datang Apisss');
        } else {
            loginError.textContent = 'Username / Password salah! (apisss / apisss15)';
        }
    });

    // SIDEBAR TOGGLE
    const menuToggle = document.getElementById('menu-toggle');
    const sidebar = document.getElementById('sidebar');
    const sidebarOverlay = document.getElementById('sidebar-overlay');
    const closeSidebar = document.getElementById('close-sidebar');

    function toggleSidebar() {
        sidebar.classList.toggle('open');
        sidebarOverlay.classList.toggle('active');
    }

    menuToggle.addEventListener('click', toggleSidebar);
    closeSidebar.addEventListener('click', toggleSidebar);
    sidebarOverlay.addEventListener('click', toggleSidebar);

    // LOGOUT LOGIC
    function performLogout() {
        appScreen.classList.remove('active');
        loginScreen.classList.add('active');
        usernameInput.value = 'apisss';
        passwordInput.value = 'apisss15';
        showToast('Berhasil Logout');
    }

    document.getElementById('logout-btn').addEventListener('click', () => { toggleSidebar(); performLogout(); });
    document.getElementById('logout-top-btn').addEventListener('click', performLogout);
    document.getElementById('btn-logout-action').addEventListener('click', performLogout);

    // PROFILE PHOTO CHANGE
    const avatarInput = document.getElementById('avatar-input');
    const bannerImg = document.getElementById('banner-img');

    function triggerPhotoUpload() {
        avatarInput.click();
    }

    document.getElementById('ganti-foto-top-btn').addEventListener('click', triggerPhotoUpload);
    document.getElementById('ganti-foto-menu-btn').addEventListener('click', () => { toggleSidebar(); triggerPhotoUpload(); });
    document.getElementById('btn-ganti-foto-action').addEventListener('click', triggerPhotoUpload);

    avatarInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (event) => {
                bannerImg.src = event.target.result;
                showToast('Foto Banner Berhasil Diganti!');
            };
            reader.readAsDataURL(file);
        }
    });

    // DEVELOPER MODAL
    const devModal = document.getElementById('developer-modal');
    function openDevModal() {
        devModal.classList.add('active');
    }

    document.getElementById('dev-modal-btn').addEventListener('click', openDevModal);
    document.getElementById('dev-menu-btn').addEventListener('click', () => { toggleSidebar(); openDevModal(); });
    document.getElementById('btn-developer-action').addEventListener('click', openDevModal);

    // SLIDE TABS
    const tabBtns = document.querySelectorAll('.tab-btn');
    const slides = document.querySelectorAll('.slide');

    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const index = btn.getAttribute('data-slide');
            tabBtns.forEach(b => b.classList.remove('active'));
            slides.forEach(s => s.classList.remove('active'));
            btn.classList.add('active');
            slides[index].classList.add('active');
        });
    });

    // PILIH TUJUAN (NOMOR / GRUP)
    const segmentBtns = document.querySelectorAll('.segment-btn');
    segmentBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            segmentBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            showToast(`Tujuan dipilih: ${btn.textContent}`);
        });
    });

    // FEATURE BUG TOGGLES (8 FITUR)
    const featureBtns = document.querySelectorAll('.feature-btn');
    featureBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            btn.classList.toggle('active');
            const featName = btn.getAttribute('data-feature');
            if (btn.classList.contains('active')) {
                showToast(`Fitur [${featName}] Aktif!`);
            } else {
                showToast(`Fitur [${featName}] Non-Aktif`);
            }
        });
    });

    // BUTTON MULAI
    document.getElementById('btn-mulai').addEventListener('click', () => {
        const targetNum = document.getElementById('target-number').value.trim();
        const activeSegment = document.querySelector('.segment-btn.active').textContent;
        const selectedFeats = Array.from(document.querySelectorAll('.feature-btn.active')).map(b => b.getAttribute('data-feature'));

        if (!targetNum) {
            showToast('Harap isi Target Number!');
            return;
        }

        showToast(`Memproses ${activeSegment}: ${targetNum}...`);
    });

    // MODALS CLOSE GENERAL
    const modals = document.querySelectorAll('.modal');
    document.querySelectorAll('.close-modal').forEach(btn => {
        btn.addEventListener('click', () => {
            modals.forEach(m => m.classList.remove('active'));
        });
    });

    document.querySelectorAll('.sidebar-menu li[data-modal]').forEach(item => {
        item.addEventListener('click', () => {
            toggleSidebar();
            const mId = item.getAttribute('data-modal');
            document.getElementById(mId).classList.add('active');
        });
    });

    // AUDIO PLAYER SYNTHESIZER
    let isPlaying = false;
    let audioCtx = null;
    let oscillator = null;
    const playSongBtn = document.getElementById('play-song');
    const playIcon = document.getElementById('play-icon');
    const songTitle = document.getElementById('song-title');
    const playlistItems = document.querySelectorAll('.playlist-item');

    playlistItems.forEach(item => {
        item.addEventListener('click', () => {
            playlistItems.forEach(i => i.classList.remove('active'));
            item.classList.add('active');
            songTitle.textContent = item.textContent.split('. ')[1];
            if (isPlaying) { stopTone(); startTone(); }
            showToast(`Lagu dipilih: ${songTitle.textContent}`);
        });
    });

    playSongBtn.addEventListener('click', () => {
        if (!isPlaying) {
            startTone();
            playIcon.className = 'fa-solid fa-pause';
            isPlaying = true;
            showToast('Memutar Audio Synth');
        } else {
            stopTone();
            playIcon.className = 'fa-solid fa-play';
            isPlaying = false;
            showToast('Audio Dijeda');
        }
    });

    function startTone() {
        if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        oscillator = audioCtx.createOscillator();
        const gainNode = audioCtx.createGain();
        oscillator.type = 'sawtooth';
        oscillator.frequency.setValueAtTime(320, audioCtx.currentTime);
        gainNode.gain.setValueAtTime(0.08, audioCtx.currentTime);
        oscillator.connect(gainNode);
        gainNode.connect(audioCtx.destination);
        oscillator.start();
    }

    function stopTone() {
        if (oscillator) {
            oscillator.stop();
            oscillator.disconnect();
            oscillator = null;
        }
    }

    // SHOP CLAIM
    window.buyItem = function(name) {
        showToast(`Item [${name}] diaktifkan!`);
    };

    // TOAST SYSTEM
    window.showToast = function(msg) {
        const toast = document.getElementById('toast');
        toast.textContent = msg;
        toast.classList.add('show');
        setTimeout(() => toast.classList.remove('show'), 2800);
    };
});

// SYSTEM 8 MINIGAMES
const gameModal = document.getElementById('game-modal');
const gameTitleHeader = document.getElementById('game-title-header');
const gameBody = document.getElementById('game-body');

window.openGame = function(type) {
    gameModal.classList.add('active');
    gameBody.innerHTML = '';

    if (type === 'clicker') {
        gameTitleHeader.textContent = '1. Tap Booster';
        let score = 0, time = 10, timer = null;
        gameBody.innerHTML = `
            <p style="font-size:0.8rem;">Klik tombol sebanyak mungkin dalam 10 detik!</p>
            <h1 id="score-display" style="color:#38bdf8; font-size:2.5rem;">0</h1>
            <p id="time-display" style="font-size:0.8rem;">Sisa Waktu: 10s</p>
            <button id="tap-act-btn" class="glass-btn primary-btn" style="padding:15px 30px;">TAP!</button>
        `;
        const btn = document.getElementById('tap-act-btn');
        btn.onclick = () => {
            if (!timer) {
                timer = setInterval(() => {
                    time--;
                    document.getElementById('time-display').textContent = `Sisa Waktu: ${time}s`;
                    if (time <= 0) {
                        clearInterval(timer);
                        btn.disabled = true;
                        showToast(`Game Selesai! Skor: ${score}`);
                    }
                }, 1000);
            }
            if (time > 0) { score++; document.getElementById('score-display').textContent = score; }
        };

    } else if (type === 'reaction') {
        gameTitleHeader.textContent = '2. Refleks Cepat';
        gameBody.innerHTML = `
            <div id="react-box" class="glass-card" style="padding:30px; background:rgba(239,68,68,0.3); cursor:pointer;">
                <h3 id="react-txt">Tunggu warna hijau...</h3>
            </div>
        `;
        const box = document.getElementById('react-box');
        const txt = document.getElementById('react-txt');
        let start = 0, ready = false;
        const tout = setTimeout(() => {
            ready = true;
            box.style.background = 'rgba(16,185,129,0.4)';
            txt.textContent = 'KLIK SEKARANG!';
            start = Date.now();
        }, Math.random() * 2000 + 1500);

        box.onclick = () => {
            if (!ready) {
                clearTimeout(tout);
                txt.textContent = 'Terlalu cepat! Coba lagi.';
            } else {
                const diff = Date.now() - start;
                txt.textContent = `Waktu Reaksi: ${diff} ms!`;
                showToast(`Waktu Reaksi: ${diff} ms`);
            }
        };

    } else if (type === 'guess') {
        gameTitleHeader.textContent = '3. Tebak Angka';
        const target = Math.floor(Math.random() * 100) + 1;
        let count = 0;
        gameBody.innerHTML = `
            <p style="font-size:0.8rem;">Tebak angka 1 - 100</p>
            <input type="number" id="num-guess" class="segment-btn" placeholder="Input angka..." style="width:80%; text-align:center;">
            <button id="btn-guess" class="glass-btn primary-btn" style="padding:8px 20px;">Tebak</button>
            <p id="guess-res" style="color:#38bdf8; font-size:0.8rem;"></p>
        `;
        document.getElementById('btn-guess').onclick = () => {
            const val = parseInt(document.getElementById('num-guess').value);
            if (!val) return;
            count++;
            const res = document.getElementById('guess-res');
            if (val === target) { res.textContent = `🎉 Benar! (${count}x coba)`; showToast('Tebakan Benar!'); }
            else if (val < target) { res.textContent = 'Terlalu KECIL!'; }
            else { res.textContent = 'Terlalu BESAR!'; }
        };

    } else if (type === 'tictactoe') {
        gameTitleHeader.textContent = '4. Tic Tac Toe';
        let b = ['', '', '', '', '', '', '', '', ''], p = 'X';
        let grid = '<div style="display:grid; grid-template-columns:repeat(3,55px); gap:6px;">';
        for(let i=0; i<9; i++) grid += `<button class="glass-btn tcell" data-i="${i}" style="height:55px; font-size:1.2rem;"></button>`;
        grid += '</div><p id="ttt-st" style="font-size:0.8rem;">Giliran: X</p>';
        gameBody.innerHTML = grid;

        document.querySelectorAll('.tcell').forEach(c => {
            c.onclick = () => {
                const i = c.getAttribute('data-i');
                if (b[i] !== '') return;
                b[i] = p; c.textContent = p;
                p = p === 'X' ? 'O' : 'X';
                document.getElementById('ttt-st').textContent = `Giliran: ${p}`;
            };
        });

    } else if (type === 'memory') {
        gameTitleHeader.textContent = '5. Memory Match';
        gameBody.innerHTML = `<p style="font-size:0.8rem;">Pilih kartu berpasangan</p><h3 style="color:#38bdf8;">🎮 🎮 🎲 🎲</h3><button class="glass-btn primary-btn" onclick="openGame('memory')">Acak Ulang</button>`;

    } else if (type === 'math') {
        gameTitleHeader.textContent = '6. Math Speed';
        const n1 = Math.floor(Math.random()*20)+1, n2 = Math.floor(Math.random()*20)+1;
        gameBody.innerHTML = `
            <p style="font-size:0.8rem;">Berapa hasil penjumlahan berikut?</p>
            <h2>${n1} + ${n2} = ?</h2>
            <input type="number" id="math-ans" class="segment-btn" style="width:70%; text-align:center;">
            <button id="math-btn" class="glass-btn primary-btn" style="padding:8px 20px;">Jawab</button>
        `;
        document.getElementById('math-btn').onclick = () => {
            const ans = parseInt(document.getElementById('math-ans').value);
            if (ans === (n1+n2)) { showToast('Jawaban Benar!'); openGame('math'); }
            else { showToast('Salah! Coba lagi'); }
        };

    } else if (type === 'coin') {
        gameTitleHeader.textContent = '7. Lempar Koin';
        gameBody.innerHTML = `
            <div id="coin-res" style="font-size:3rem; color:#f59e0b;"><i class="fa-solid fa-coins"></i></div>
            <button id="flip-btn" class="glass-btn primary-btn" style="padding:10px 25px;">Lempar Koin</button>
        `;
        document.getElementById('flip-btn').onclick = () => {
            const res = Math.random() > 0.5 ? 'ANGKA' : 'GAMBAR';
            document.getElementById('coin-res').textContent = res;
            showToast(`Hasil Koin: ${res}`);
        };

    } else if (type === 'rps') {
        gameTitleHeader.textContent = '8. Gunting Batu Kertas';
        gameBody.innerHTML = `
            <p style="font-size:0.8rem;">Pilih Pilihan Anda:</p>
            <div style="display:flex; gap:10px;">
                <button class="glass-btn" onclick="playRPS('Batu')">✊ Batu</button>
                <button class="glass-btn" onclick="playRPS('Gunting')">✌️ Gunting</button>
                <button class="glass-btn" onclick="playRPS('Kertas')">✋ Kertas</button>
            </div>
            <p id="rps-status" style="margin-top:10px; font-size:0.85rem; color:#38bdf8;"></p>
        `;
    }
};

window.playRPS = function(user) {
    const opts = ['Batu', 'Gunting', 'Kertas'];
    const bot = opts[Math.floor(Math.random() * 3)];
    let res = '';
    if (user === bot) res = 'Seri!';
    else if ((user==='Batu'&&bot==='Gunting') || (user==='Gunting'&&bot==='Kertas') || (user==='Kertas'&&bot==='Batu')) res = 'Anda Menang! 🎉';
    else res = 'Bot Menang!';
    document.getElementById('rps-status').textContent = `Anda: ${user} vs Bot: ${bot} -> ${res}`;
};

window.closeGameModal = function() { gameModal.classList.remove('active'); };
