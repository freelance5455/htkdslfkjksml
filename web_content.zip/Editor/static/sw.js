/* Global AI Editor Pro service worker: the photo + video editors work offline. Bump V on every release. */
const V = 'gae-v0-5-0';
const SHELL = ['./', 'index.html', 'style.css', 'native.css', 'native.js', 'native-cfg.js', 'pwa.js', 'common.js', 'i18n.js', 'photo.js', 'video.js', 'ai.js', 'app.js',
  'manifest.webmanifest', 'icons/icon-192.png', 'icons/icon-512.png', 'icons/icon-512-maskable.png', 'icons/favicon.png'];
self.addEventListener('install', e => { e.waitUntil(caches.open(V).then(c => c.addAll(SHELL)).then(() => self.skipWaiting())); });
self.addEventListener('activate', e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== V).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', e => {
  const r = e.request, u = new URL(r.url);
  if (r.method !== 'GET' || u.origin !== location.origin || u.pathname.startsWith('/api/')) return;   // API + generated files always go to the network
  e.respondWith(fetch(r).then(x => { if (x.ok && x.status === 200) { const c = x.clone(); caches.open(V).then(h => h.put(r, c)); } return x; })
    .catch(() => caches.match(r).then(m => m || caches.match('index.html'))));
});
