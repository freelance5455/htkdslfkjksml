window.NATIVE_CFG={navButtons:"#navPhoto,#navVideo,#navAi",home:"navPhoto"};
