let aimActive = false;
let aimSensitivity = 1.0;
let startX = 0, startY = 0;
let isDragging = false;

function initAim() {
  if (typeof Shizuku === 'undefined') return false;
  Shizuku.checkSelfPermission();
  return true;
}

function bindAimService() {
  Shizuku.bindUserService({
    action: 'com.toancube.AIM',
    package: 'com.toancube.app'
  }, (s) => { console.log('Aim service bound'); });
}

function toggleAim() {
  aimActive = !aimActive;
  console.log('Aim:', aimActive ? 'ON' : 'OFF');
}

function inputSwipe(x1, y1, x2, y2, d) {
  if (typeof Shizuku === 'undefined') return;
  Shizuku.newProcess(['input','swipe',String(x1),String(y1),String(x2),String(y2),String(d)], null, null);
}

// Kéo aim: chạm và kéo trên màn hình
document.addEventListener('touchstart', (e) => {
  if (!aimActive) return;
  const t = e.touches[0];
  startX = t.clientX;
  startY = t.clientY;
  isDragging = true;
}, { passive: true });

document.addEventListener('touchmove', (e) => {
  if (!aimActive || !isDragging) return;
  const t = e.touches[0];
  const dx = (t.clientX - startX) * aimSensitivity;
  const dy = (t.clientY - startY) * aimSensitivity;
  if (Math.abs(dx) > 2 || Math.abs(dy) > 2) {
    inputSwipe(startX, startY, startX + dx, startY + dy, 30);
  }
}, { passive: true });

document.addEventListener('touchend', () => {
  isDragging = false;
}, { passive: true });

initAim();
bindAimService();