let aimActive = false, aimSensitivity = 1.0;
let startX = 0, startY = 0, isDragging = false;

function initAim() {
  if (typeof Shizuku === 'undefined') return false;
  Shizuku.checkSelfPermission();
  return true;
}
function bindAimService() {
  Shizuku.bindUserService({action:'com.toancube.AIM',package:'com.toancube.app'},(s)=>{});
}
function toggleAim() { aimActive = !aimActive; }
function inputSwipe(x1,y1,x2,y2,d) {
  if (typeof Shizuku === 'undefined') return;
  Shizuku.newProcess(['input','swipe',String(x1),String(y1),String(x2),String(y2),String(d)],null,null);
}

document.addEventListener('touchstart', e => {
  if (!aimActive) return;
  const t = e.touches[0];
  const sw = window.innerWidth, sh = window.innerHeight;
  const fireX = sw - 90, fireY = sh - 90;
  const dist = Math.sqrt((t.clientX - fireX)**2 + (t.clientY - fireY)**2);
  if (dist > 150) return;
  startX = t.clientX; startY = t.clientY; isDragging = true;
}, {passive:true});

document.addEventListener('touchmove', e => {
  if (!aimActive || !isDragging) return;
  const t = e.touches[0];
  const dx = (t.clientX - startX) * aimSensitivity;
  const dy = (t.clientY - startY) * aimSensitivity;
  if (Math.abs(dx) > 2 || Math.abs(dy) > 2) {
    inputSwipe(startX, startY, startX + dx, startY + dy, 30);
  }
}, {passive:true});

document.addEventListener('touchend', () => { isDragging = false; }, {passive:true});
initAim(); bindAimService();