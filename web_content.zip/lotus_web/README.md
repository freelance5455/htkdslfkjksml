# LÓTUS 1.3.0 — Abra-se, Lótus
Projeto web/mobile do assistente pessoal LÓTUS.

Entrada principal: `index.html`.

Estrutura preparada para empacotamento com Capacitor Android. A interface, reconhecimento de voz, fala, histórico local e integração REST com Gemini ficam no código do projeto.
