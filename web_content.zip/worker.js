const cors = (origin) => ({
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Vary": "Origin"
});
const reply = (data, status = 200) => new Response(JSON.stringify(data), {
  status, headers: { "Content-Type": "application/json; charset=utf-8", ...cors() }
});
const hex = b => Array.from(new Uint8Array(b)).map(x => x.toString(16).padStart(2, "0")).join("");
async function hash(password, salt) {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveBits"]);
  return hex(await crypto.subtle.deriveBits({ name: "PBKDF2", salt: new TextEncoder().encode(salt), iterations: 210000, hash: "SHA-256" }, key, 256));
}
function constantTime(a, b) {
  if (typeof a !== "string" || typeof b !== "string") return false;
  let diff = a.length ^ b.length;
  for (let i = 0; i < Math.max(a.length, b.length); i++) diff |= (a.charCodeAt(i) || 0) ^ (b.charCodeAt(i) || 0);
  return diff === 0;
}
async function session(request, env) {
  const t = (request.headers.get("Authorization") || "").replace(/^Bearer\s+/i, "");
  if (!t) return null;
  const row = await env.DB.prepare("SELECT username, role, expires_at FROM sessions WHERE token_hash=?").bind(await hash(t, env.SESSION_SALT)).first();
  if (!row || row.expires_at < Date.now()) return null;
  return row;
}
function randomToken() { return hex(crypto.getRandomValues(new Uint8Array(32))); }
export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") return new Response(null, { headers: cors() });
    const url = new URL(request.url), path = url.pathname;
    if ((path === "/" || path === "/api/health") && request.method === "GET")
      return reply({ ok: true, service: "DARK CITY API" });
    try {
      if (!env.DB) return reply({ error: "قاعدة البيانات غير مربوطة. اربط D1 باسم DB." }, 503);
      if (!env.SESSION_SALT) return reply({ error: "إعداد SESSION_SALT غير موجود في Worker Secrets." }, 503);
      if (path === "/api/register" && request.method === "POST") {
        const { username, password } = await request.json();
        if (!/^[\p{L}\p{N}_]{3,24}$/u.test(username || "") || typeof password !== "string" || password.length < 8 || password.length > 128)
          return reply({ error: "بيانات التسجيل غير صحيحة. كلمة المرور 8 أحرف على الأقل." }, 400);
        if (!env.OWNER_USERNAME || username.toLowerCase() === env.OWNER_USERNAME.toLowerCase())
          return reply({ error: "اسم المستخدم مستخدم بالفعل." }, 409);
        const exists = await env.DB.prepare("SELECT username FROM users WHERE username_key=?").bind(username.toLowerCase()).first();
        if (exists) return reply({ error: "اسم المستخدم مستخدم بالفعل." }, 409);
        const salt = hex(crypto.getRandomValues(new Uint8Array(16))), ph = await hash(password, salt);
        await env.DB.prepare("INSERT INTO users(username,username_key,salt,password_hash,status,created_at) VALUES(?,?,?,?,?,?)")
          .bind(username, username.toLowerCase(), salt, ph, "pending", Date.now()).run();
        return reply({ ok: true, message: "تم استلام طلبك بنجاح. انتظر قبول الإدارة في أقرب وقت، وبالتوفيق." }, 201);
      }
      if (path === "/api/login" && request.method === "POST") {
        const { username, password } = await request.json();
        if (typeof username !== "string" || typeof password !== "string") return reply({ error: "اسم المستخدم أو كلمة المرور غير صحيحة." }, 400);
        let role = "member", valid = false, display = username;
        if (env.OWNER_USERNAME && username.toLowerCase() === env.OWNER_USERNAME.toLowerCase()) {
          if (!env.OWNER_PASSWORD) return reply({ error: "كلمة مرور المالك غير مضبوطة في Worker Secrets." }, 503);
          valid = constantTime(password, env.OWNER_PASSWORD); role = "owner"; display = env.OWNER_USERNAME;
        } else {
          const u = await env.DB.prepare("SELECT username,salt,password_hash,status FROM users WHERE username_key=?").bind(username.toLowerCase()).first();
          if (u) {
            valid = await hash(password, u.salt) === u.password_hash; display = u.username;
            if (valid && u.status !== "approved") return reply({ error: "تم استلام طلبك بنجاح. انتظر قبول الإدارة في أقرب وقت، وبالتوفيق." }, 403);
          }
        }
        if (!valid) return reply({ error: "اسم المستخدم أو كلمة المرور غير صحيحة." }, 401);
        const t = randomToken(), th = await hash(t, env.SESSION_SALT), expires = Date.now() + 12 * 60 * 60 * 1000;
        await env.DB.prepare("INSERT INTO sessions(token_hash,username,role,expires_at) VALUES(?,?,?,?)").bind(th, display, role, expires).run();
        return reply({ token: t, username: display, role }, 200);
      }
      if (path.startsWith("/api/salaries") || path.startsWith("/api/admin/")) {
        const who = await session(request, env);
        if (!who || who.role !== "owner") return reply({ error: "غير مصرح. هذه الخاصية للمالك فقط." }, 403);
        if (path === "/api/salaries" && request.method === "GET") {
          const rows = await env.DB.prepare("SELECT id,player,amount,note,created_at FROM salaries ORDER BY created_at DESC").all();
          return reply({ salaries: rows.results || [] });
        }
        if (path === "/api/salaries" && request.method === "POST") {
          const { player, amount, note = "" } = await request.json();
          if (typeof player !== "string" || !player.trim() || player.length > 40 || !Number.isFinite(amount) || amount < 0 || typeof note !== "string" || note.length > 500)
            return reply({ error: "راجع بيانات الراتب." }, 400);
          const r = await env.DB.prepare("INSERT INTO salaries(player,amount,note,created_at) VALUES(?,?,?,?)").bind(player.trim(), amount, note, Date.now()).run();
          return reply({ ok: true, id: r.meta.last_row_id }, 201);
        }
        const salaryMatch = path.match(/^\/api\/salaries\/(\d+)$/);
        if (salaryMatch && request.method === "PUT") {
          const { amount } = await request.json();
          if (!Number.isFinite(amount) || amount < 0) return reply({ error: "قيمة الراتب غير صحيحة." }, 400);
          await env.DB.prepare("UPDATE salaries SET amount=? WHERE id=?").bind(amount, Number(salaryMatch[1])).run();
          return reply({ ok: true });
        }
        if (salaryMatch && request.method === "DELETE") {
          await env.DB.prepare("DELETE FROM salaries WHERE id=?").bind(Number(salaryMatch[1])).run();
          return reply({ ok: true });
        }
        if (path === "/api/admin/pending" && request.method === "GET") {
          const rows = await env.DB.prepare("SELECT id,username,created_at FROM users WHERE status='pending' ORDER BY created_at ASC").all();
          return reply({ users: rows.results || [] });
        }
        const reviewMatch = path.match(/^\/api\/admin\/users\/(\d+)\/(approve|reject)$/);
        if (reviewMatch && request.method === "POST") {
          const id = Number(reviewMatch[1]), action = reviewMatch[2];
          if (action === "approve") {
            await env.DB.prepare("UPDATE users SET status='approved' WHERE id=? AND status='pending'").bind(id).run();
            return reply({ ok: true, status: "approved" });
          }
          await env.DB.prepare("DELETE FROM users WHERE id=? AND status='pending'").bind(id).run();
          return reply({ ok: true, status: "rejected" });
        }
      }
      return reply({ error: "Not found" }, 404);
    } catch (e) {
      return reply({ error: "حدث خطأ داخلي في الخادم. تأكد من تشغيل schema.sql وربط D1." }, 500);
    }
  }
};
