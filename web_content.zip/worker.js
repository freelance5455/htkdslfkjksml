/**
 * KORA X secure data gateway — Cloudflare Worker
 * Secrets belong in Worker environment variables, never in the HTML/Android client.
 * Required secret: API_FOOTBALL_KEY (optional but strongly recommended)
 * Optional secret: SPORTMONKS_TOKEN
 * Optional variable: ALLOWED_ORIGIN (e.g. https://your-site.pages.dev)
 */
const CACHE = caches.default;
const SOURCE_RANK = { 'API-Football': 100, 'Sportmonks': 90, 'TheSportsDB': 65, 'OpenLigaDB': 50 };
const JSON_HEADERS = { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'public, max-age=30' };

function cors(env) {
  return {
    'access-control-allow-origin': env.ALLOWED_ORIGIN || '*',
    'access-control-allow-methods': 'GET, OPTIONS',
    'access-control-allow-headers': 'content-type',
    'vary': 'Origin'
  };
}
function response(data, env, status = 200, headers = {}) {
  return new Response(JSON.stringify(data), { status, headers: { ...JSON_HEADERS, ...cors(env), ...headers } });
}
function clean(v, max = 100) { return String(v || '').trim().slice(0, max); }
function norm(v = '') {
  return String(v).normalize('NFKD').toLowerCase().replace(/[\u0300-\u036f]/g, '')
    .replace(/[أإآ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه').replace(/[^\p{L}\p{N}]/gu, '');
}
const ALIASES = {
  manchesterunited: 'manutd', manunited: 'manutd', manutd: 'manutd', manchesterunitedfc: 'manutd',
  manchestercity: 'mancity', mancity: 'mancity', manchestercityfc: 'mancity', parissaintgermain: 'psg', psg: 'psg',
  alahlisc: 'alahly', alahly: 'alahly', zamaleksc: 'zamalek',
  realmadrid: 'realmadrid', realmadridcf: 'realmadrid', fcbarcelona: 'barcelona', barcelona: 'barcelona',
  liverpoolfc: 'liverpool', liverpool: 'liverpool'
};
function teamKey(v) { const n = norm(v); return ALIASES[n] || n; }
function status(value = '') {
  const s = String(value).trim().toLowerCase();
  if (['1h','2h','ht','et','bt','p','live','inplay'].includes(s) || /in play|first half|second half|extra time|penalt(y|ies)|live/.test(s)) return 'live';
  if (['ft','aet','pen'].includes(s) || /finished|after penalties|complete|ended/.test(s)) return 'finished';
  if (['pst','canc','susp','int','abd','awd','wo'].includes(s) || /postponed|cancelled|suspend|interrupted|abandoned/.test(s)) return 'other';
  return 'upcoming';
}
function isoDate(v) { return String(v || '').slice(0, 10); }
function dateInZone(v, tz = 'Africa/Cairo') { if (!v) return ''; try { return new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date(v)); } catch { return isoDate(v); } }
function fromAF(f, tz) {
  const h = f.teams?.home || {}, a = f.teams?.away || {}, g = f.goals || {}, sc = f.score || {};
  return {
    id: `af-${f.fixture?.id}`, providerId: String(f.fixture?.id || ''), home: h.name || '—', away: a.name || '—',
    homeLogo: h.logo || null, awayLogo: a.logo || null, competition: f.league?.name || '—', leagueId: f.league?.id,
    date: dateInZone(f.fixture?.date, tz), kickoff: f.fixture?.date || null, status: status(f.fixture?.status?.short),
    statusLong: f.fixture?.status?.long || '', homeScore: g.home ?? sc.fulltime?.home ?? null,
    awayScore: g.away ?? sc.fulltime?.away ?? null, elapsed: f.fixture?.status?.elapsed ?? null,
    venue: f.fixture?.venue?.name || null, round: f.league?.round || null,
    source: 'API-Football', sources: ['API-Football']
  };
}
function fromSM(f, tz) {
  const p = f.participants || [], h = p.find(x => x.meta?.location === 'home') || p[0] || {}, a = p.find(x => x.meta?.location === 'away') || p[1] || {};
  const sc = f.scores || [], hs = sc.find(x => x.description === 'CURRENT' && x.score?.participant === 'home')?.score?.goals;
  const as = sc.find(x => x.description === 'CURRENT' && x.score?.participant === 'away')?.score?.goals;
  return {
    id: `sm-${f.id}`, providerId: String(f.id), home: h.name || '—', away: a.name || '—', homeLogo: h.image_path || null,
    awayLogo: a.image_path || null, competition: f.league?.name || '—', leagueId: f.league?.id,
    date: dateInZone(f.starting_at, tz), kickoff: f.starting_at || null, status: status(f.state?.state || f.state?.name || ''),
    statusLong: f.state?.name || '', homeScore: hs ?? null, awayScore: as ?? null, venue: f.venue?.name || null,
    source: 'Sportmonks', sources: ['Sportmonks']
  };
}
function fromTS(e, tz) {
  const kickoff = e.strTimestamp ? new Date(e.strTimestamp).toISOString() : (e.dateEvent && e.strTime ? `${e.dateEvent}T${e.strTime}Z` : null);
  const rawStatus = e.strStatus || ((e.intHomeScore !== null && e.intHomeScore !== undefined) ? 'Finished' : 'Not Started');
  return {
    id: `ts-${e.idEvent}`, providerId: String(e.idEvent || ''), home: e.strHomeTeam || '—', away: e.strAwayTeam || '—',
    homeLogo: e.strHomeTeamBadge || null, awayLogo: e.strAwayTeamBadge || null, competition: e.strLeague || '—',
    date: dateInZone(kickoff || e.dateEvent, tz) || isoDate(e.dateEvent), kickoff, status: status(rawStatus), statusLong: rawStatus,
    homeScore: e.intHomeScore === null ? null : (e.intHomeScore ?? null),
    awayScore: e.intAwayScore === null ? null : (e.intAwayScore ?? null), venue: e.strVenue || null,
    source: 'TheSportsDB', sources: ['TheSportsDB']
  };
}
function fromOLD(m, tz) {
  const final = (m.MatchResults || []).find(x => /endergebnis|final|end result/i.test(x.ResultName || '')) || (m.MatchResults || [])[0];
  return {
    id: `old-${m.MatchID}`, providerId: String(m.MatchID || ''), home: m.Team1?.TeamName || '—', away: m.Team2?.TeamName || '—',
    homeLogo: m.Team1?.TeamIconUrl || null, awayLogo: m.Team2?.TeamIconUrl || null, competition: m.LeagueName || '—',
    date: dateInZone(m.MatchDateTimeUTC, tz), kickoff: m.MatchDateTimeUTC || null,
    status: m.MatchIsFinished ? 'finished' : 'upcoming', statusLong: m.MatchIsFinished ? 'Finished' : 'Scheduled',
    homeScore: m.MatchIsFinished ? (final?.PointsTeam1 ?? null) : null,
    awayScore: m.MatchIsFinished ? (final?.PointsTeam2 ?? null) : null,
    venue: m.Location?.LocationStadium || null, source: 'OpenLigaDB', sources: ['OpenLigaDB']
  };
}
function mergeFixtures(rows) {
  const map = new Map();
  for (const row of rows) {
    if (!row.home || !row.away || row.home === '—' || row.away === '—') continue;
    const key = `${isoDate(row.date || row.kickoff)}|${[teamKey(row.home), teamKey(row.away)].sort().join(':')}`;
    const old = map.get(key);
    if (!old) { map.set(key, row); continue; }
    const oldRank = SOURCE_RANK[old.source] || 0, newRank = SOURCE_RANK[row.source] || 0;
    const winner = newRank > oldRank ? row : old, loser = winner === row ? old : row;
    const sameOrder = teamKey(winner.home) === teamKey(loser.home);
    const extra = sameOrder ? loser : { ...loser, homeLogo: loser.awayLogo, awayLogo: loser.homeLogo, homeScore: loser.awayScore, awayScore: loser.homeScore };
    const merged = { ...extra, ...winner };
    for (const field of ['homeLogo','awayLogo','venue','referee','round','events','lineups','stats','tvStations']) {
      if (!merged[field] && extra[field]) merged[field] = extra[field];
    }
    if (merged.homeScore == null && extra.homeScore != null) merged.homeScore = extra.homeScore;
    if (merged.awayScore == null && extra.awayScore != null) merged.awayScore = extra.awayScore;
    merged.sources = [...new Set([...(old.sources || [old.source]), ...(row.sources || [row.source])])];
    map.set(key, merged);
  }
  return [...map.values()].sort((a, b) => String(a.kickoff || '').localeCompare(String(b.kickoff || '')));
}
async function getJSON(url, init = {}) {
  const res = await fetch(url, { ...init, cf: { cacheTtl: 20, cacheEverything: true } });
  if (!res.ok) throw new Error(`${res.status} ${res.statusText}`);
  return res.json();
}
async function cachedRequest(request, ttl, build) {
  const cacheUrl = new URL(request.url); cacheUrl.searchParams.sort();
  const cacheKey = new Request(cacheUrl.toString(), request);
  const cached = await CACHE.match(cacheKey);
  if (cached) return cached;
  const result = await build();
  const res = new Response(JSON.stringify(result), { headers: { ...JSON_HEADERS, 'cache-control': `public, max-age=${ttl}` } });
  await CACHE.put(cacheKey, res.clone());
  return res;
}
async function cachedResponse(request, env, ttl, build) {
  // Partition cached responses by enabled provider configuration. This prevents
  // a pre-key 'no data' response from surviving after a secret is configured.
  const cacheUrl = new URL(request.url);
  cacheUrl.searchParams.set('_provider_mode', `${env.API_FOOTBALL_KEY ? 'af' : 'noaf'}-${env.SPORTMONKS_TOKEN ? 'sm' : 'nsm'}`);
  const cacheRequest = new Request(cacheUrl.toString(), request);
  const cached = await cachedRequest(cacheRequest, ttl, build);
  const headers = new Headers(cached.headers);
  for (const [key, value] of Object.entries(cors(env))) headers.set(key, value);
  return new Response(cached.body, { status: cached.status, headers });
}
async function fixtures(env, date, timezone = 'Africa/Cairo') {
  const tasks = [];
  if (env.API_FOOTBALL_KEY) tasks.push((async () => {
    const j = await getJSON(`https://v3.football.api-sports.io/fixtures?date=${date}&timezone=${encodeURIComponent(timezone)}`, { headers: { 'x-apisports-key': env.API_FOOTBALL_KEY } });
    return (j.response || []).map(x => fromAF(x, timezone));
  })().catch(() => []));
  if (env.SPORTMONKS_TOKEN) tasks.push((async () => {
    const u = `https://api.sportmonks.com/v3/football/fixtures/date/${date}?api_token=${encodeURIComponent(env.SPORTMONKS_TOKEN)}&include=participants;scores;league;state;venue&per_page=50`;
    const j = await getJSON(u); return (j.data || []).map(x => fromSM(x, timezone));
  })().catch(() => []));
  tasks.push((async () => {
    const j = await getJSON(`https://www.thesportsdb.com/api/v1/json/123/eventsday.php?d=${date}&s=Soccer`);
    return (j.events || []).map(x => fromTS(x, timezone));
  })().catch(() => []));
  const year = Number(date.slice(0, 4)), month = Number(date.slice(5, 7)), season = month < 7 ? year - 1 : year;
  for (const code of ['BL1','BL2','BL3','DFB']) tasks.push((async () => {
    const j = await getJSON(`https://api.openligadb.de/getmatchdata/${code}/${season}`);
    return Array.isArray(j) ? j.filter(m => dateInZone(m.MatchDateTimeUTC, timezone) === date).map(m => fromOLD(m, timezone)) : [];
  })().catch(() => []));
  const batches = await Promise.all(tasks);
  const all = batches.flat();
  const sources = [...new Set(all.flatMap(x => x.sources || [x.source]))];
  return { fixtures: mergeFixtures(all), sources, fetchedAt: new Date().toISOString(), countBySource: sources.map(source => ({ source, count: all.filter(x => x.source === source).length })) };
}
function normalizeAFPlayer(x) {
  const p = x.player || x, st = x.statistics?.[0] || {}, g = st.goals || {}, games = st.games || {}, ps = st.passes || {}, tk = st.tackles || {}, du = st.duels || {}, dr = st.dribbles || {}, sh = st.shots || {}, cd = st.cards || {};
  return {
    id: `afp-${p.id}`, providerId: String(p.id), source: 'API-Football', name: p.name, firstname: p.firstname, lastname: p.lastname,
    photo: p.photo, cutout: p.photo, birthDate: p.birth?.date, birthPlace: p.birth?.place, nationality: p.nationality,
    age: p.age, height: p.height, weight: p.weight, injured: p.injured ?? null, number: games.number, position: games.position,
    team: st.team?.name, teamLogo: st.team?.logo, league: st.league?.name, season: st.league?.season,
    stats: { appearances: games.appearences, starts: games.lineups, minutes: games.minutes, goals: g.total, assists: g.assists,
      shots: sh.total, shotsOn: sh.on, passes: ps.total, passesAccuracy: ps.accuracy, keyPasses: ps.key,
      tackles: tk.total, blocks: tk.blocks, interceptions: tk.interceptions, duels: du.total, duelsWon: du.won,
      dribbles: dr.success, fouls: st.fouls?.committed, yellow: cd.yellow, red: cd.red, rating: games.rating }
  };
}
function normalizeTSPlayer(p) {
  return { id: `tsplayer-${p.idPlayer}`, providerId: String(p.idPlayer), source: 'TheSportsDB', name: p.strPlayer,
    photo: p.strThumb, cutout: p.strCutout || p.strThumb, birthDate: p.dateBorn, nationality: p.strNationality,
    height: p.strHeight, weight: p.strWeight, number: p.strNumber, position: p.strPosition, team: p.strTeam,
    description: p.strDescriptionEN || p.strDescriptionAR, stats: {} };
}
function mergePlayers(apiPlayers, sportsDbPlayers) {
  const map = new Map();
  const all = [...apiPlayers, ...sportsDbPlayers];
  for (const p of all) {
    const name = norm(p.name), nationality = norm(p.nationality), birth = String(p.birthDate || '').slice(0, 10);
    const key = birth ? `${name}|${birth}` : `${name}|${nationality}`;
    if (!name) continue;
    const old = map.get(key);
    if (!old) { map.set(key, p); continue; }
    const winner = old.source === 'API-Football' ? old : (p.source === 'API-Football' ? p : old);
    const other = winner === old ? p : old;
    map.set(key, { ...other, ...winner, cutout: other.cutout || winner.cutout, description: winner.description || other.description,
      stats: { ...(other.stats || {}), ...(winner.stats || {}) }, sourceIds: [...new Set([...(old.sourceIds || []), old.id, ...(p.sourceIds || []), p.id])] });
  }
  return [...map.values()];
}

async function playerDetails(env, id, source, season = '2026') {
  if (source === 'API-Football' && env.API_FOOTBALL_KEY) {
    const headers = { 'x-apisports-key': env.API_FOOTBALL_KEY };
    const base = 'https://v3.football.api-sports.io';
    const [profile, transfers, trophies, sidelined] = await Promise.all([
      getJSON(`${base}/players?id=${encodeURIComponent(id)}&season=${season}`, { headers }),
      getJSON(`${base}/transfers?player=${encodeURIComponent(id)}`, { headers }).catch(() => ({ response: [] })),
      getJSON(`${base}/trophies?player=${encodeURIComponent(id)}`, { headers }).catch(() => ({ response: [] })),
      getJSON(`${base}/sidelined?player=${encodeURIComponent(id)}`, { headers }).catch(() => ({ response: [] }))
    ]);
    const result = profile.response?.[0];
    if (result) {
      const player = normalizeAFPlayer(result);
      const transferRow = transfers.response?.[0];
      const injuryRow = sidelined.response?.[0];
      // Look for a full-body cutout/biography in the free supplemental catalogue;
      // only attach it when both name and nationality agree.
      try {
        const candidates = await getJSON(`https://www.thesportsdb.com/api/v1/json/123/searchplayers.php?p=${encodeURIComponent(player.name)}`);
        const extra = (candidates.player || []).map(normalizeTSPlayer).find(x => norm(x.name) === norm(player.name) && (!player.nationality || !x.nationality || norm(x.nationality) === norm(player.nationality)));
        if (extra) { player.cutout = extra.cutout || extra.photo || player.cutout; player.description = extra.description || player.description; }
      } catch { /* Keep the provider's official player photo. */ }
      player.transfers = transferRow?.transfers || [];
      player.trophies = trophies.response || [];
      player.injuries = injuryRow?.sidelined || [];
      player.injured = result.player?.injured ?? null;
      return player;
    }
  }
  if (source === 'TheSportsDB' || !source) {
    const j = await getJSON(`https://www.thesportsdb.com/api/v1/json/123/lookupplayer.php?id=${encodeURIComponent(id)}`);
    const p = j.players?.[0];
    if (p) return normalizeTSPlayer(p);
  }
  return null;
}
function normalizeAFLineup(team) {
  const normalize = (entry, substitute) => {
    const p = entry.player || {};
    return { ...p, id: p.id ? `afp-${p.id}` : null, photo: p.id ? `https://media.api-sports.io/football/players/${p.id}.png` : null,
      grid: p.grid || null, substitute };
  };
  const starters = (team.startXI || []).map(x => normalize(x, false));
  const subs = (team.substitutes || []).map(x => normalize(x, true));
  return { team: team.team?.name, logo: team.team?.logo, formation: team.formation, coach: team.coach?.name, players: [...starters, ...subs] };
}
async function matchDetails(env, id, source) {
  if (source === 'API-Football' && env.API_FOOTBALL_KEY) {
    const headers = { 'x-apisports-key': env.API_FOOTBALL_KEY };
    const base = 'https://v3.football.api-sports.io';
    const [fx, lu, st, ev] = await Promise.all([
      getJSON(`${base}/fixtures?id=${encodeURIComponent(id)}`, { headers }),
      getJSON(`${base}/fixtures/lineups?fixture=${encodeURIComponent(id)}`, { headers }).catch(() => ({ response: [] })),
      getJSON(`${base}/fixtures/statistics?fixture=${encodeURIComponent(id)}`, { headers }).catch(() => ({ response: [] })),
      getJSON(`${base}/fixtures/events?fixture=${encodeURIComponent(id)}`, { headers }).catch(() => ({ response: [] }))
    ]);
    const fixture = fx.response?.[0] || {};
    return {
      source: 'API-Football', venue: fixture.fixture?.venue?.name, referee: fixture.fixture?.referee,
      lineups: (lu.response || []).map(normalizeAFLineup),
      stats: (st.response || []).map(x => ({ team: x.team?.name, items: (x.statistics || []).map(v => ({ name: v.type, value: v.value })) })),
      events: ev.response || [], tvStations: []
    };
  }
  if (source === 'Sportmonks' && env.SPORTMONKS_TOKEN) {
    const include = 'participants;lineups;statistics;events;venue;referee;league;state;tvStations';
    const url = `https://api.sportmonks.com/v3/football/fixtures/${encodeURIComponent(id)}?api_token=${encodeURIComponent(env.SPORTMONKS_TOKEN)}&include=${encodeURIComponent(include)}`;
    const j = await getJSON(url), f = j.data || {};
    const rel = key => Array.isArray(f[key]) ? f[key] : (f[key]?.data || []);
    const lineupRows = rel('lineups');
    const participants = rel('participants');
    const lineups = participants.map(team => {
      const players = lineupRows.filter(x => String(x.team_id) === String(team.id)).map(x => ({
        id: x.player?.id || x.player_id, name: x.player?.display_name || x.player?.name || x.player_name,
        number: x.jersey_number, position: x.position?.name || x.position_name, grid: x.formation_position || x.position_id,
        substitute: String(x.type?.name || x.type || '').toLowerCase().includes('substitute'),
        photo: x.player?.image_path
      }));
      return { team: team.name, logo: team.image_path, formation: f.formation || '', coach: f.coach?.name, players };
    }).filter(x => x.players.length);
    const statistics = rel('statistics');
    const stats = participants.map(team => ({ team: team.name, items: statistics.filter(x => String(x.participant_id) === String(team.id)).map(x => ({ name: x.type?.name || x.type?.developer_name || 'Statistic', value: x.data?.value ?? x.value })) }));
    const events = rel('events');
    const tvStations = rel('tvStations');
    return { source: 'Sportmonks', venue: f.venue?.name, referee: f.referee?.name, lineups, stats, events, tvStations };
  }
  if (source === 'TheSportsDB') {
    const [event, lu, tl] = await Promise.all([
      getJSON(`https://www.thesportsdb.com/api/v1/json/123/lookupevent.php?id=${encodeURIComponent(id)}`).catch(() => ({})),
      getJSON(`https://www.thesportsdb.com/api/v1/json/123/lookuplineup.php?id=${encodeURIComponent(id)}`).catch(() => ({})),
      getJSON(`https://www.thesportsdb.com/api/v1/json/123/lookuptimeline.php?id=${encodeURIComponent(id)}`).catch(() => ({}))
    ]);
    const e = event.events?.[0] || {}, rows = lu.lineup || [];
    const bySide = ['home', 'away'].map(side => {
      const isHome = side === 'home';
      const team = isHome ? e.strHomeTeam : e.strAwayTeam;
      const players = rows.filter(x => String(x.strHome || '').toLowerCase() === (isHome ? 'yes' : 'no')).map(x => ({
        id: x.idPlayer, name: x.strPlayer, position: x.strPosition, number: x.intSquadNumber,
        substitute: String(x.strSubstitute || '').toLowerCase() === 'yes', photo: x.strCutout || x.strThumb
      }));
      return { team, formation: isHome ? e.strHomeFormation : e.strAwayFormation, players };
    }).filter(x => x.players.length);
    return { source: 'TheSportsDB', venue: e.strVenue, referee: e.strReferee, lineups: bySide,
      stats: [], events: tl.timeline || [], tvStations: [] };
  }
  if (source === 'OpenLigaDB') {
    const m = await getJSON(`https://api.openligadb.de/getmatchdata/${encodeURIComponent(id)}`).catch(() => null);
    return { source: 'OpenLigaDB', venue: m?.Location?.LocationStadium || null, referee: null, lineups: [], stats: [], events: [], tvStations: [] };
  }
  return { source: source || 'Unknown', lineups: [], stats: [], events: [], tvStations: [] };
}

async function playerSearch(env, q) {
  const afTask = env.API_FOOTBALL_KEY
    ? getJSON(`https://v3.football.api-sports.io/players?search=${encodeURIComponent(q)}&season=2026`, { headers: { 'x-apisports-key': env.API_FOOTBALL_KEY } }).then(j => (j.response || []).map(normalizeAFPlayer)).catch(() => [])
    : Promise.resolve([]);
  const tsTask = getJSON(`https://www.thesportsdb.com/api/v1/json/123/searchplayers.php?p=${encodeURIComponent(q)}`).then(j => (j.player || []).map(normalizeTSPlayer)).catch(() => []);
  const [af, ts] = await Promise.all([afTask, tsTask]);
  return mergePlayers(af, ts);
}
function normalizeAFTeam(x) {
  const t = x.team || x;
  return { id: `aft-${t.id}`, providerId: String(t.id), source: 'API-Football', name: t.name, logo: t.logo,
    country: t.country || null, founded: t.founded || null, national: !!t.national, venue: x.venue || null };
}
function normalizeTSTeam(t) {
  return { id: `tst-${t.idTeam}`, providerId: String(t.idTeam), source: 'TheSportsDB', name: t.strTeam, logo: t.strBadge || t.strTeamBadge,
    country: t.strCountry || null, founded: t.intFormedYear || null, national: false, venue: t.strStadium || null,
    description: t.strDescriptionEN || t.strDescriptionAR || null };
}
function mergeTeams(apiTeams, sportsDbTeams) {
  const map = new Map();
  for (const team of [...apiTeams, ...sportsDbTeams]) {
    const key = `${teamKey(team.name)}|${norm(team.country || '')}`;
    if (!team.name) continue;
    const old = map.get(key);
    if (!old) { map.set(key, team); continue; }
    const winner = old.source === 'API-Football' ? old : (team.source === 'API-Football' ? team : old);
    const other = winner === old ? team : old;
    map.set(key, { ...other, ...winner, logo: winner.logo || other.logo, venue: winner.venue || other.venue,
      description: winner.description || other.description, sourceIds: [...new Set([...(old.sourceIds || []), old.id, ...(team.sourceIds || []), team.id])] });
  }
  return [...map.values()];
}
async function teamSearch(env, q) {
  const afTask = env.API_FOOTBALL_KEY
    ? getJSON(`https://v3.football.api-sports.io/teams?search=${encodeURIComponent(q)}`, { headers: { 'x-apisports-key': env.API_FOOTBALL_KEY } }).then(j => (j.response || []).map(normalizeAFTeam)).catch(() => [])
    : Promise.resolve([]);
  const tsTask = getJSON(`https://www.thesportsdb.com/api/v1/json/123/searchteams.php?t=${encodeURIComponent(q)}`).then(j => (j.teams || []).map(normalizeTSTeam)).catch(() => []);
  const [af, ts] = await Promise.all([afTask, tsTask]);
  return mergeTeams(af, ts);
}
function xmlDecode(s='') { return s.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1').replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&#39;/g,"'").replace(/&apos;/g,"'").trim(); }
function parseTag(block, tag) { const m = block.match(new RegExp(`<${tag}(?:\\s[^>]*)?>([\\s\\S]*?)<\\/${tag}>`, 'i')); return m ? xmlDecode(m[1]).replace(/<[^>]*>/g,'').trim() : ''; }
async function news(topic, lang, type = 'all') {
  const typeWords = { club: 'football club', national: 'national football team', league: 'football league competition', player: 'football player' };
  const locales = lang === 'all' ? [{ hl:'ar', gl:'EG', ceid:'EG:ar' }, { hl:'en', gl:'US', ceid:'US:en' }]
    : [lang === 'ar' ? { hl:'ar', gl:'EG', ceid:'EG:ar' } : { hl:'en', gl:'US', ceid:'US:en' }];
  const topicQuery = `${typeWords[type] || 'football'} ${topic || ''}`.trim();
  const batches = await Promise.all(locales.map(async locale => {
    const q = encodeURIComponent(topicQuery || 'football');
    const url = `https://news.google.com/rss/search?q=${q}&hl=${locale.hl}&gl=${locale.gl}&ceid=${encodeURIComponent(locale.ceid)}`;
    const xml = await fetch(url, { headers: { 'user-agent': 'KORA-X/1.0 news reader' } }).then(r => { if (!r.ok) throw new Error(`RSS ${r.status}`); return r.text(); });
    return [...xml.matchAll(/<item>([\s\S]*?)<\/item>/gi)].slice(0, 30).map(m => {
      const b = m[1], source = b.match(/<source[^>]*>([\s\S]*?)<\/source>/i);
      const image = (b.match(/<media:content[^>]+url=["']([^"']+)/i) || [])[1] || '';
      return { title: parseTag(b,'title'), url: parseTag(b,'link'), publishedAt: parseTag(b,'pubDate'), summary: parseTag(b,'description').slice(0, 300), source: source ? xmlDecode(source[1]) : 'Google News', image, language: locale.hl };
    }).filter(x => x.title && x.url);
  }));
  const seen = new Set();
  return batches.flat().filter(x => { const k = norm(x.title).slice(0, 90); if (!k || seen.has(k)) return false; seen.add(k); return true; })
    .sort((a,b) => Date.parse(b.publishedAt || 0) - Date.parse(a.publishedAt || 0));
}
async function leagueData(env, league, season, type) {
  if (!env.API_FOOTBALL_KEY) return { available: false, message: 'Configure API_FOOTBALL_KEY in Worker secrets.' };
  const headers = { 'x-apisports-key': env.API_FOOTBALL_KEY };
  if (type === 'champions' || type === 'records') {
    const years = [2025, 2024, 2023, 2022, 2021];
    const rows = await Promise.all(years.map(async year => {
      try {
        const endpoint = type === 'champions' ? 'standings' : 'players/topscorers';
        const j = await getJSON(`https://v3.football.api-sports.io/${endpoint}?league=${league}&season=${year}`, { headers });
        if (type === 'champions') {
          const winner = j.response?.[0]?.league?.standings?.[0]?.[0];
          return winner ? { season: `${year}/${year + 1}`, champion: winner.team?.name, logo: winner.team?.logo, points: winner.points, played: winner.all?.played } : null;
        }
        const top = j.response?.[0];
        return top ? { season: `${year}/${year + 1}`, player: top.player?.name, photo: top.player?.photo, team: top.statistics?.[0]?.team?.name, goals: top.statistics?.[0]?.goals?.total, assists: top.statistics?.[0]?.goals?.assists, appearances: top.statistics?.[0]?.games?.appearences } : null;
      } catch { return null; }
    }));
    return { available: true, response: rows.filter(Boolean), results: rows.filter(Boolean).length, source: 'API-Football', type, seasons: years };
  }
  const endpoint = type === 'scorers' ? 'players/topscorers' : 'standings';
  const j = await getJSON(`https://v3.football.api-sports.io/${endpoint}?league=${league}&season=${season}`, { headers });
  return { available: true, response: j.response || [], results: j.results || 0, source: 'API-Football', type };
}
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors(env) });
    if (request.method !== 'GET') return response({ error: 'Method not allowed' }, env, 405);
    try {
      if (url.pathname === '/api/health') return response({ ok: true, providers: { apiFootball: !!env.API_FOOTBALL_KEY, sportmonks: !!env.SPORTMONKS_TOKEN, thesportsdb: true, openligadb: true }, serverTime: new Date().toISOString() }, env);
      if (url.pathname === '/api/fixtures') {
        const date = clean(url.searchParams.get('date'), 10);
        const timezone = clean(url.searchParams.get('timezone') || 'Africa/Cairo', 64);
        if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return response({ error: 'date must be YYYY-MM-DD' }, env, 400);
        return cachedResponse(request, env, 30, () => fixtures(env, date, timezone));
      }
      if (url.pathname === '/api/player-search') {
        const q = clean(url.searchParams.get('q'), 80);
        if (q.length < 2) return response({ error: 'q must contain at least 2 characters' }, env, 400);
        return cachedResponse(request, env, 900, async () => { const players = await playerSearch(env, q); return { players, source: players[0]?.source || 'none' }; });
      }
      if (url.pathname === '/api/team-search') {
        const q = clean(url.searchParams.get('q'), 80);
        if (q.length < 2) return response({ error: 'q must contain at least 2 characters' }, env, 400);
        return cachedResponse(request, env, 900, async () => { const teams = await teamSearch(env, q); return { teams, source: teams.map(x => x.source).filter((v, i, a) => a.indexOf(v) === i) }; });
      }
      if (url.pathname === '/api/player') {
        const id = clean(url.searchParams.get('id'), 32), source = clean(url.searchParams.get('source') || 'TheSportsDB', 32);
        const season = clean(url.searchParams.get('season') || '2026', 4);
        if (!id || !/^[\w-]+$/.test(id) || !/^20\d\d$/.test(season)) return response({ error: 'Invalid player id or season' }, env, 400);
        return cachedResponse(request, env, 900, async () => { const player = await playerDetails(env, id.replace(/^afp-/, '').replace(/^tsplayer-/, ''), source, season); return { player, source: player?.source || source }; });
      }
      if (url.pathname === '/api/match') {
        const id = clean(url.searchParams.get('id'), 40), source = clean(url.searchParams.get('source') || '', 32);
        if (!id || !/^[\w-]+$/.test(id)) return response({ error: 'Invalid fixture id' }, env, 400);
        return cachedResponse(request, env, 60, () => matchDetails(env, id.replace(/^(af|sm|ts|old)-/, ''), source));
      }
      if (url.pathname === '/api/league') {
        const league = clean(url.searchParams.get('league'), 8), season = clean(url.searchParams.get('season'), 4), type = clean(url.searchParams.get('type') || 'table', 16);
        if (!/^\d+$/.test(league) || !/^20\d\d$/.test(season) || !['table','scorers','champions','records'].includes(type)) return response({ error: 'Invalid league, season or type' }, env, 400);
        return cachedResponse(request, env, 21600, () => leagueData(env, league, season, type));
      }
      if (url.pathname === '/api/news') {
        const topic = clean(url.searchParams.get('topic') || 'football', 120), rawLang = url.searchParams.get('language') || 'en', lang = ['ar','all'].includes(rawLang) ? rawLang : 'en', type = clean(url.searchParams.get('type') || 'all', 16);
        return cachedResponse(request, env, 300, async () => ({ articles: await news(topic, lang, type), source: 'Google News RSS', fetchedAt: new Date().toISOString() }));
      }
      return response({ error: 'Not found' }, env, 404);
    } catch (e) {
      return response({ error: 'upstream_error', message: clean(e?.message || 'Unknown error', 180) }, env, 502);
    }
  }
};
