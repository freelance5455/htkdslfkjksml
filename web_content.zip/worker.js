// J.A.R.V.I.S. TODO EN UNO: interfaz + API de IA en el mismo Cloudflare Worker.
// Requisito: agregar un binding Workers AI cuyo nombre sea exactamente AI.
const MODEL = "@cf/meta/llama-3.3-70b-instruct-fp8-fast";
const MAX_BODY_CHARS = 40000;
const SYSTEM_PROMPT = `Eres J.A.R.V.I.S., un asistente personal útil, claro, respetuoso y amable. Responde en español natural, preferentemente español de México. Explica paso a paso cuando la persona esté aprendiendo. Reconoce con honestidad cuando no sepas algo. No afirmes que ejecutaste acciones del teléfono, navegaste por internet o consultaste datos en tiempo real si no tienes una herramienta para hacerlo. No inventes fuentes ni resultados. Para abrir páginas, la interfaz solicita autorización antes de realizar la acción.`;
const HTML = `<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#030910">
<title>J.A.R.V.I.S. — Asistente Personal</title>
<style>
:root{--bg:#030910;--surface:#07141f;--fg:#e7f4fb;--muted:#89a6b5;--blue:#3ad7ff;--line:#1c4256;--danger:#ff8e8e;--ok:#91f0b5}
*{box-sizing:border-box}body{margin:0;min-height:100vh;background:var(--bg);color:var(--fg);font-family:system-ui,-apple-system,sans-serif;background-image:radial-gradient(ellipse at top,#10364b 0,transparent 60%),linear-gradient(#12304044 1px,transparent 1px),linear-gradient(90deg,#12304044 1px,transparent 1px);background-size:auto,36px 36px,36px 36px}
header{display:flex;justify-content:space-between;align-items:center;padding:18px;max-width:1050px;margin:auto;gap:10px}.kicker,.mono,.clock,.day,.status{font-family:ui-monospace,SFMono-Regular,monospace;letter-spacing:.1em}.kicker{color:var(--blue);font-size:12px}h1{font-size:clamp(25px,6vw,36px);letter-spacing:.13em;margin:8px 0}.clock{font-size:clamp(18px,4vw,25px);text-align:right}.day{font-size:10px;color:var(--muted);text-align:right;max-width:48vw}
main{max-width:1050px;margin:auto;padding:10px 14px 32px}.layout{display:grid;gap:18px}@media(min-width:760px){.layout{grid-template-columns:260px minmax(0,1fr);align-items:start}}.reactor{width:155px;height:155px;margin:18px auto;color:var(--blue);filter:drop-shadow(0 0 14px #3ad7ff55)}.ring{transform-origin:100px 100px;animation:spin 18s linear infinite}.reverse{animation-direction:reverse;animation-duration:25s}.is-speak .core{animation:pulse .4s infinite alternate}.is-listen{filter:drop-shadow(0 0 20px #3ad7ff)}@keyframes spin{to{transform:rotate(360deg)}}@keyframes pulse{to{opacity:1;filter:drop-shadow(0 0 15px var(--blue))}}
.panel{padding:13px;border:1px solid var(--line);border-radius:15px;background:#07141fee;margin-bottom:12px}.status{font-size:11px;color:var(--blue);margin:7px 0 12px}.muted{color:var(--muted);font-size:13px;line-height:1.55}.mono{font-size:11px}button,input,textarea{font:inherit;border-radius:11px;padding:12px;border:1px solid var(--line);background:var(--surface);color:var(--fg)}button{cursor:pointer;min-height:44px;touch-action:manipulation}button:active{transform:scale(.985)}button:disabled{opacity:.55;cursor:wait}.primary{border-color:var(--blue);color:var(--blue);background:#0b2838}.ghost{background:transparent}.danger{border-color:#713b49;color:#ffc4c4}input,textarea{width:100%;min-width:0}input:focus,textarea:focus{outline:1px solid var(--blue)}textarea{resize:vertical;min-height:95px}.grid2{display:grid;grid-template-columns:1fr 1fr;gap:8px}.stack{display:grid;gap:9px}.chips{display:flex;flex-wrap:wrap;gap:7px;margin:12px 0}.chip{font-size:12px;border-radius:30px;padding:8px 11px;min-height:35px}footer{text-align:center;color:var(--muted);font-size:11px;margin-top:22px}
#chat{display:flex;flex-direction:column;gap:10px;max-height:43vh;min-height:160px;overflow-y:auto;overscroll-behavior:contain;padding:2px 2px 8px;scroll-behavior:smooth}.message{border:1px solid var(--line);border-radius:12px;padding:10px 12px;max-width:96%;overflow-wrap:anywhere;white-space:pre-wrap;line-height:1.5}.message.user{align-self:flex-end;background:#0b2838;border-color:#25647d}.message.assistant{align-self:flex-start;background:#06111a}.message.system{align-self:center;font-size:12px;color:var(--muted);background:transparent;border-style:dashed}.message .role{display:block;font-family:ui-monospace,monospace;font-size:10px;letter-spacing:.08em;color:var(--blue);margin-bottom:4px}.message .time{display:block;color:var(--muted);font-size:10px;text-align:right;margin-top:5px}.messageText{overflow-wrap:anywhere}
#pendingBox{border-color:#3d7184}#pendingText{margin-top:0}.hint{margin:10px 0 0}.sectionTitle{font-family:ui-monospace,monospace;color:var(--blue);font-size:11px;letter-spacing:.12em;margin:0 0 10px}.toolbar{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:9px}.toolbar button{font-size:12px}[hidden]{display:none!important}.modalShade{position:fixed;inset:0;z-index:20;background:#000b;display:flex;align-items:center;justify-content:center;padding:16px}.modal{width:min(560px,100%);max-height:85vh;overflow:auto;background:#07141f;border:1px solid var(--blue);border-radius:16px;padding:16px;box-shadow:0 0 35px #000b}.historyRow{width:100%;text-align:left;margin:5px 0;display:block}.historyTitle{display:block;font-weight:600}.historyMeta{display:block;color:var(--muted);font-size:11px;margin-top:3px}.modalButtons{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:12px}.errorText{color:var(--danger)}.okText{color:var(--ok)}
@media(prefers-reduced-motion:reduce){*,*::before,*::after{animation-duration:.01ms!important;animation-iteration-count:1!important;scroll-behavior:auto!important}}
</style>
</head>
<body>
<header>
  <div><div class="kicker">ASISTENTE PERSONAL</div><h1>J.A.R.V.I.S.</h1></div>
  <div><div class="clock" id="clock">--:--:--</div><div class="day" id="day">SISTEMA INICIANDO</div></div>
</header>
<main>
<div class="layout">
  <section style="text-align:center">
    <div class="reactor" id="reactor" aria-label="Núcleo de JARVIS"><svg viewBox="0 0 200 200" width="100%" height="100%" aria-hidden="true"><g class="ring" fill="none" stroke="currentColor"><circle cx="100" cy="100" r="92" stroke-dasharray="8 9"/><circle cx="100" cy="100" r="77" stroke-dasharray="2 7"/></g><g class="ring reverse" fill="none" stroke="currentColor" stroke-width="2"><circle cx="100" cy="100" r="61" stroke-dasharray="40 20 8 20"/></g><circle class="core" cx="100" cy="100" r="35" fill="#3ad7ff22" stroke="currentColor" stroke-width="2"/><circle cx="100" cy="100" r="9" fill="currentColor"/></svg></div>
    <div class="mono muted" id="voiceHint">VOZ EN ESPAÑOL</div><p class="muted">Sistema personal J.A.R.V.I.S.</p>
    <div class="panel" style="text-align:left"><p class="sectionTitle">FUNCIONES</p><div class="muted">Comandos, cálculos, temporizadores, memoria local, voz, IA en línea y apertura de páginas con autorización.</div></div>
  </section>
  <section>
    <p class="status" id="phaseLabel" role="status">SISTEMA PREPARADO</p><div class="panel"><div id="chat" aria-live="polite" aria-label="Conversación de JARVIS"></div></div>
    <div id="pendingBox" class="panel" hidden><p id="pendingText">¿Autorizas esta acción?</p><div class="grid2"><button class="primary" id="yesBtn">SÍ, CONTINUAR</button><button class="ghost" id="noBtn">CANCELAR</button></div></div>
    <div class="chips"><button class="chip" data-command="¿Qué hora es?">HORA</button><button class="chip" data-command="¿Qué fecha es hoy?">FECHA</button><button class="chip" data-command="Calcula 25 por 4">CALCULAR</button><button class="chip" data-command="Ayuda">AYUDA</button><button class="chip" data-command="Mis notas">MEMORIA</button></div>
    <form id="form" class="stack"><input id="orden" placeholder="Escribe una orden..." autocomplete="off" maxlength="2000" aria-label="Escribe una orden"><div class="grid2"><button type="button" id="micBtn" class="primary">🎤 HABLAR</button><button type="submit" id="sendBtn">➤ ENVIAR</button></div></form>
    <div class="grid2" style="margin-top:9px"><button id="testVoice" class="ghost">🔊 PROBAR VOZ</button><button id="muteBtn" class="ghost">SILENCIAR VOZ</button></div>
    <div class="grid2" style="margin-top:9px"><button id="repeatBtn" class="ghost">REPETIR RESPUESTA</button><button id="clearBtn" class="ghost">NUEVA CONVERSACIÓN</button></div>
    <div class="toolbar"><button id="historyBtn" class="ghost">📚 HISTORIAL GUARDADO</button><button id="aiConfigBtn" class="ghost">⚙️ CONFIGURAR IA EN LÍNEA</button></div>
    <p class="muted hint" id="helpText">Las conversaciones y notas se guardan en este navegador. No pegues claves API en este archivo HTML.</p>
  </section>
</div><footer>J.A.R.V.I.S. · ASISTENTE PERSONAL · VOZ EN ESPAÑOL</footer>
</main>

<div id="historyModal" class="modalShade" hidden><div class="modal" role="dialog" aria-modal="true" aria-labelledby="historyHeading"><p class="sectionTitle" id="historyHeading">HISTORIAL DE CONVERSACIONES</p><p class="muted">Selecciona una conversación guardada para continuarla.</p><div id="historyList"></div><div class="modalButtons"><button id="exportBtn" class="primary">EXPORTAR HISTORIAL</button><button id="closeHistoryBtn" class="ghost">CERRAR</button></div><button id="deleteHistoryBtn" class="danger" style="width:100%;margin-top:8px">🗑️ BORRAR TODO EL HISTORIAL</button><p class="muted">Borra conversaciones guardadas en este navegador. No borra tus notas ni tu nombre guardado.</p></div></div>
<div id="aiModal" class="modalShade" hidden><div class="modal" role="dialog" aria-modal="true" aria-labelledby="aiHeading"><p class="sectionTitle" id="aiHeading">CONFIGURAR IA EN LÍNEA</p><p class="muted">Pega la dirección HTTPS de tu Cloudflare Worker. La página enviará tu mensaje por POST en JSON. El Worker debe tener una IA configurada, aceptar POST y permitir CORS. No pegues claves API aquí.</p><label for="aiEndpointInput" class="muted">Dirección del Worker</label><input id="aiEndpointInput" type="url" inputmode="url" placeholder="https://tu-worker.tudominio.workers.dev/" autocomplete="url"><div class="modalButtons"><button id="saveAiBtn" class="primary">GUARDAR DIRECCIÓN</button><button id="testAiBtn" class="ghost">PROBAR CONEXIÓN</button></div><button id="clearAiBtn" class="danger" style="width:100%;margin-top:8px">🗑️ BORRAR DIRECCIÓN ACTUAL</button><p id="aiTestResult" class="muted" role="status" style="margin-top:12px">La dirección se guarda en este navegador.</p><button id="closeAiBtn" class="ghost" style="width:100%;margin-top:8px">CERRAR</button></div></div>

<script>
"use strict";
const $ = id => document.getElementById(id);
const STORAGE_KEY = "jarvis_personal_es_v2";
const DEFAULT_GREETING = "A sus órdenes. ¿En qué puedo ayudarle?";
const DEFAULT_AI_ENDPOINT = "https://jarvis-ia-pablo2026.pablo1237gamer1.workers.dev/";
let voiceOn=true,userName="",notes=[],aiEndpoint=DEFAULT_AI_ENDPOINT;
let conversations=[],currentConversationId="",pendingAction=null,timers=[],recognition=null,listening=false,busy=false,lastResponse=DEFAULT_GREETING;

function setStatus(text){$("phaseLabel").textContent=text;}
function makeId(){return Date.now().toString(36)+Math.random().toString(36).slice(2,8);}
function timeLabel(value){try{return new Date(value).toLocaleTimeString("es-MX",{hour:"2-digit",minute:"2-digit"});}catch{return "";}}
function getCurrentConversation(){return conversations.find(c=>c.id===currentConversationId)||null;}
function normalizeConversations(raw){
 if(!Array.isArray(raw))return [];
 return raw.filter(c=>c&&typeof c.id==="string"&&Array.isArray(c.messages)).slice(0,30).map(c=>({id:c.id,title:typeof c.title==="string"?c.title.slice(0,70):"Conversación guardada",createdAt:Number(c.createdAt)||Date.now(),updatedAt:Number(c.updatedAt)||Date.now(),messages:c.messages.filter(m=>m&&["user","assistant","system"].includes(m.role)&&typeof m.text==="string").slice(-100).map(m=>({role:m.role,text:m.text.slice(0,5000),time:Number(m.time)||Date.now()}))}));
}
function saveState(){
 const current=getCurrentConversation();if(current)current.updatedAt=Date.now();conversations=conversations.slice(0,30);
 const state={userName,notes:notes.slice(-100),aiEndpoint,conversations,currentConversationId};
 try{localStorage.setItem(STORAGE_KEY,JSON.stringify(state));}
 catch(error){try{const reduced={...state,notes:notes.slice(-50),conversations:conversations.slice(0,12).map(c=>({...c,messages:c.messages.slice(-30)}))};localStorage.setItem(STORAGE_KEY,JSON.stringify(reduced));}catch{setStatus("MEMORIA LOCAL NO DISPONIBLE");console.warn("No se pudo guardar memoria local",error);}}
}
function loadState(){
 try{const raw=JSON.parse(localStorage.getItem(STORAGE_KEY)||"null");if(raw&&typeof raw==="object"){userName=typeof raw.userName==="string"?raw.userName:"";notes=Array.isArray(raw.notes)?raw.notes.filter(n=>typeof n==="string").slice(-100):[];if(typeof raw.aiEndpoint==="string")aiEndpoint=raw.aiEndpoint;conversations=normalizeConversations(raw.conversations);currentConversationId=typeof raw.currentConversationId==="string"?raw.currentConversationId:"";}}catch(error){console.warn("No se pudo leer la memoria local",error);}
 if(!conversations.length){const c={id:makeId(),title:"Nueva conversación",createdAt:Date.now(),updatedAt:Date.now(),messages:[]};conversations.unshift(c);currentConversationId=c.id;addMessage("assistant",DEFAULT_GREETING,{speak:false});return;}
 if(!conversations.some(c=>c.id===currentConversationId))currentConversationId=conversations[0].id;renderChat();
}
function renderChat(){const chat=$("chat");chat.replaceChildren();const conv=getCurrentConversation();if(!conv)return;for(const msg of conv.messages){const bubble=document.createElement("div");bubble.className="message "+msg.role;const role=document.createElement("span");role.className="role";role.textContent=msg.role==="user"?"TÚ":msg.role==="assistant"?"J.A.R.V.I.S.":"SISTEMA";const text=document.createElement("div");text.className="messageText";text.textContent=msg.text;bubble.append(role,text);const time=document.createElement("span");time.className="time";time.textContent=timeLabel(msg.time);bubble.append(time);chat.append(bubble);}chat.scrollTop=chat.scrollHeight;}
function addMessage(role,text,options={}){let conv=getCurrentConversation();if(!conv){conv={id:makeId(),title:"Nueva conversación",createdAt:Date.now(),updatedAt:Date.now(),messages:[]};conversations.unshift(conv);currentConversationId=conv.id;}const msg={role,text:String(text).slice(0,5000),time:Date.now()};conv.messages.push(msg);conv.messages=conv.messages.slice(-100);if(role==="user"&&conv.title==="Nueva conversación")conv.title=msg.text.replace(/\\s+/g," ").slice(0,55)||"Conversación";conv.updatedAt=Date.now();if(role==="assistant")lastResponse=msg.text;saveState();renderChat();if(role==="assistant"&&options.speak!==false)speak(msg.text);}
function assistant(text,options={}){addMessage("assistant",text,options);}
function updateClock(){const now=new Date();$("clock").textContent=now.toLocaleTimeString("es-MX",{hour:"2-digit",minute:"2-digit",second:"2-digit"});$("day").textContent=now.toLocaleDateString("es-MX",{weekday:"long",day:"numeric",month:"long"}).toUpperCase();}
updateClock();setInterval(updateClock,1000);

// Voz de salida
function speak(text){if(!voiceOn||!text)return;const clean=String(text).replace(/https?:\\/\\/\\S+/g,"").trim();if(!clean)return;try{if(window.AndroidJarvis&&typeof window.AndroidJarvis.speak==="function"){window.AndroidJarvis.speak(clean);return;}}catch(e){console.warn("Puente de voz no disponible",e);}if(!("speechSynthesis" in window)||typeof SpeechSynthesisUtterance==="undefined"){$("voiceHint").textContent="VOZ DEL NAVEGADOR NO DISPONIBLE";return;}try{const synth=window.speechSynthesis;synth.cancel();const utterance=new SpeechSynthesisUtterance(clean);utterance.lang="es-MX";utterance.rate=.94;utterance.pitch=.9;utterance.volume=1;const voices=synth.getVoices();const selected=voices.find(v=>/^es-MX$/i.test(v.lang))||voices.find(v=>/^es([-]|$)/i.test(v.lang));if(selected)utterance.voice=selected;utterance.onstart=()=>{$("reactor").classList.add("is-speak");setStatus("J.A.R.V.I.S. ESTÁ HABLANDO");};utterance.onend=()=>{$("reactor").classList.remove("is-speak");if(!listening&&!busy)setStatus("SISTEMA PREPARADO");};utterance.onerror=e=>{$("reactor").classList.remove("is-speak");setStatus("NO SE PUDO REPRODUCIR LA VOZ");console.warn("Error de voz",e.error);};synth.speak(utterance);}catch(e){setStatus("ERROR DE VOZ");console.error(e);}}
function updateVoiceHint(){if(!("speechSynthesis" in window)){$("voiceHint").textContent="VOZ NO DISPONIBLE EN ESTE CONTEXTO";return;}const spanish=window.speechSynthesis.getVoices().some(v=>/^es([-]|$)/i.test(v.lang));$("voiceHint").textContent=voiceOn?(spanish?"VOZ EN ESPAÑOL DISPONIBLE":"BUSCANDO VOZ EN ESPAÑOL"):"VOZ SILENCIADA";}
if("speechSynthesis" in window){window.speechSynthesis.addEventListener?.("voiceschanged",updateVoiceHint);updateVoiceHint();}
$("testVoice").addEventListener("click",()=>{voiceOn=true;$("muteBtn").textContent="SILENCIAR VOZ";updateVoiceHint();speak("Hola. Soy JARVIS, tu asistente personal. Estoy listo para ayudarte.");});
$("muteBtn").addEventListener("click",()=>{voiceOn=!voiceOn;if(!voiceOn&&"speechSynthesis" in window)window.speechSynthesis.cancel();$("muteBtn").textContent=voiceOn?"SILENCIAR VOZ":"ACTIVAR VOZ";updateVoiceHint();setStatus(voiceOn?"SISTEMA PREPARADO":"VOZ SILENCIADA");});
$("repeatBtn").addEventListener("click",()=>lastResponse?speak(lastResponse):setStatus("NO HAY RESPUESTA PARA REPETIR"));

// Reconocimiento de voz
function startListening(){const SpeechRecognition=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SpeechRecognition){assistant("Este navegador no ofrece reconocimiento de voz. Prueba Chrome y revisa los permisos del micrófono.");return;}if(listening&&recognition){recognition.stop();return;}try{recognition=new SpeechRecognition();recognition.lang="es-MX";recognition.continuous=false;recognition.interimResults=false;recognition.maxAlternatives=1;recognition.onstart=()=>{listening=true;$("micBtn").textContent="🔴 ESCUCHANDO…";$("reactor").classList.add("is-listen");setStatus("ESCUCHANDO TU ORDEN");};recognition.onresult=event=>{const result=event.results?.[0]?.[0]?.transcript||"";if(result.trim()){$("orden").value=result;handleUserMessage(result);}};recognition.onerror=event=>{console.warn("Reconocimiento de voz:",event.error);if(event.error==="not-allowed"||event.error==="service-not-allowed")assistant("No tengo permiso para usar el micrófono. Revisa los permisos del navegador.");else if(event.error!=="no-speech"&&event.error!=="aborted")setStatus("NO SE RECONOCIÓ LA VOZ");};recognition.onend=()=>{listening=false;$("micBtn").textContent="🎤 HABLAR";$("reactor").classList.remove("is-listen");if(!busy)setStatus("SISTEMA PREPARADO");};recognition.start();}catch(e){listening=false;$("micBtn").textContent="🎤 HABLAR";setStatus("NO SE PUDO INICIAR EL MICRÓFONO");console.error(e);}}
$("micBtn").addEventListener("click",startListening);

// Calculadora segura: analiza operaciones permitidas, no ejecuta JavaScript.
function calculate(raw){let expr=String(raw).toLowerCase().normalize("NFD").replace(/[\\u0300-\\u036f]/g,"").replace(/^.*?\\bcalcula(?:r)?\\b/,"").replace(/^\\s*(?:cuanto es|cuanto da)\\s*/,"").trim();expr=expr.replace(/multiplicado por/g,"*").replace(/dividido entre|dividido por/g,"/").replace(/\\bpor\\b/g,"*").replace(/\\bentre\\b/g,"/").replace(/\\bmas\\b/g,"+").replace(/\\bmenos\\b/g,"-").replace(/\\s*x\\s*/g,"*").replace(/,/g,".").replace(/\\s+/g,"");if(!expr||!/^[\\d.+*/()\\-]+$/.test(expr))return null;const tokens=expr.match(/\\d+(?:\\.\\d+)?|[()+\\-*/]/g)||[];if(!tokens.length||tokens.join("")!==expr)return null;let i=0;function factor(){const t=tokens[i++];if(t==="-")return-factor();if(t==="+")return factor();if(t==="("){const n=expression();if(tokens[i++]!==")")throw Error("Paréntesis sin cerrar");return n;}if(t===undefined||!/^[\\d]/.test(t))throw Error("Falta número");return Number(t);}function term(){let n=factor();while(tokens[i]==="*"||tokens[i]==="/"){const op=tokens[i++],r=factor();if(op==="/"&&r===0)throw Error("División entre cero");n=op==="*"?n*r:n/r;}return n;}function expression(){let n=term();while(tokens[i]==="+"||tokens[i]==="-"){const op=tokens[i++],r=term();n=op==="+"?n+r:n-r;}return n;}try{const result=expression();return i===tokens.length&&Number.isFinite(result)?result:null;}catch{return null;}}

function normalizeText(text){return String(text).toLowerCase().normalize("NFD").replace(/[\\u0300-\\u036f]/g,"").trim();}
function formatDate(){return new Date().toLocaleDateString("es-MX",{weekday:"long",year:"numeric",month:"long",day:"numeric"});}
function formatTime(){return new Date().toLocaleTimeString("es-MX",{hour:"2-digit",minute:"2-digit"});}
function createNewConversation(){const c={id:makeId(),title:"Nueva conversación",createdAt:Date.now(),updatedAt:Date.now(),messages:[]};conversations.unshift(c);conversations=conversations.slice(0,30);currentConversationId=c.id;addMessage("assistant",DEFAULT_GREETING,{speak:false});}
function showPending(text,action){pendingAction=action;$("pendingText").textContent=text;$("pendingBox").hidden=false;$("yesBtn").focus();}
function hidePending(){pendingAction=null;$("pendingBox").hidden=true;}
$("noBtn").addEventListener("click",()=>{hidePending();assistant("Acción cancelada. No he abierto nada.");});
$("yesBtn").addEventListener("click",()=>{const action=pendingAction;hidePending();if(!action)return;try{action();}catch(e){assistant("No pude completar esa acción. Revisa si el navegador bloqueó la ventana.");console.error(e);}});
function openExternal(url,label){showPending("¿Autorizas que abra "+label+" en otra pestaña?",()=>{const opened=window.open(url,"_blank");if(opened)opened.opener=null;assistant(opened===null?"El navegador pudo bloquear la pestaña. Permite las ventanas emergentes para este sitio.":"Listo. Solicité abrir "+label+".");});}
function parseDuration(text){const s=normalizeText(text);const match=s.match(/(?:en|de|por|durante)?\\s*(\\d+(?:[.,]\\d+)?)\\s*(segundos?|seg|minutos?|min|horas?|hrs?|h)\\b/);if(!match)return null;const n=Number(match[1].replace(",","."));if(!Number.isFinite(n)||n<=0)return null;const unit=match[2];const multiplier=/^h|hora|hr/.test(unit)?3600000:/^min/.test(unit)?60000:1000;const ms=n*multiplier;return ms>=1000&&ms<=43200000?{ms,shown:Math.round(ms/1000),n,unit}:null;}
function startTimer(duration){const timer={id:makeId(),timeout:null};timer.timeout=setTimeout(()=>{timers=timers.filter(t=>t.id!==timer.id);assistant("⏰ Temporizador terminado.");try{if("Notification" in window&&Notification.permission==="granted")new Notification("J.A.R.V.I.S.",{body:"Tu temporizador terminó."});}catch{}},duration.ms);timers.push(timer);let description;if(duration.ms<60000)description=duration.n+" segundo(s)";else if(duration.ms<3600000)description=(duration.ms/60000)+" minuto(s)";else description=(duration.ms/3600000)+" hora(s)";assistant("Temporizador iniciado por "+description+". Te avisaré cuando termine.");}
function handleLocalCommand(raw){const s=normalizeText(raw);
 if(/^(hola|buenos dias|buenas tardes|buenas noches|que onda|hey)\\b/.test(s)){assistant("A sus órdenes"+(userName?", "+userName:"")+". ¿Qué necesitas?");return true;}
 if(/\\b(que hora es|dime la hora|hora actual|la hora)\\b/.test(s)){assistant("Son las "+formatTime()+".");return true;}
 if(/\\b(que fecha es|fecha de hoy|que dia es hoy|dime la fecha|fecha actual)\\b/.test(s)){assistant("Hoy es "+formatDate()+".");return true;}
 if(/^ayuda\\b|\\bque puedes hacer\\b|\\bcomandos\\b/.test(s)){assistant("Puedo decirte la hora y fecha, calcular operaciones, guardar notas, iniciar temporizadores, hablar por voz, abrir páginas con tu autorización y contestar preguntas mediante la IA en línea si configuras el Worker.\\n\\nEjemplos: “calcula 25 por 4”, “recuerda comprar cuadernos”, “mis notas”, “temporizador de 2 minutos”, “busca planetas” o “abre YouTube”.");return true;}
 if(/^(mis notas|ver notas|lee mis notas|que recuerdas|que tengo guardado)$/.test(s)){assistant(notes.length?"Estas son tus notas guardadas:\\n"+notes.map((n,i)=>(i+1)+". "+n).join("\\n"):"Todavía no tienes notas guardadas. Di “recuerda que…” para guardar una.");return true;}
 const remember=raw.match(/^\\s*(?:jarvis[, ]*)?(?:recuerda(?: que)?|guarda nota(?: que)?|anota(?: que)?|apunta(?: que)?)\\s*[:,-]?\\s*(.+)$/i);
 if(remember&&remember[1]){const note=remember[1].trim().slice(0,500);notes.push(note);notes=notes.slice(-100);saveState();assistant("Lo guardaré en la memoria local de este navegador: “"+note+"”.");return true;}
 if(/\\b(borra|elimina|limpia)\\s+(todas?\\s+)?(mis\\s+)?notas\\b/.test(s)){showPending("¿Seguro que quieres borrar todas tus notas guardadas?",()=>{notes=[];saveState();assistant("He borrado tus notas guardadas en este navegador.");});return true;}
 const nameMatch=raw.match(/(?:me llamo|mi nombre es)\\s+([\\p{L}\\d _-]{1,50})/iu);if(nameMatch){userName=nameMatch[1].trim();saveState();assistant("Mucho gusto, "+userName+". Guardé tu nombre en este navegador.");return true;}
 const duration=parseDuration(raw);if(duration&&/temporizador|temporizame|avisa(?:me)?|recu[eé]rdame|cuenta regresiva/.test(s)){startTimer(duration);return true;}
 if(/\\b(cancelar|cancela|deten|parar)\\s+(el\\s+)?temporizador\\b/.test(s)){if(!timers.length){assistant("No hay temporizadores activos en esta sesión.");}else{timers.forEach(t=>clearTimeout(t.timeout));timers=[];assistant("He cancelado los temporizadores activos.");}return true;}
 if(/^(abre|abrir)\\s+(youtube|yt)(\\s|$)/.test(s)){openExternal("https://www.youtube.com/","YouTube");return true;}
 if(/^(abre|abrir)\\s+(google maps|mapas|maps)(\\s|$)/.test(s)){openExternal("https://maps.google.com/","Google Maps");return true;}
 if(/^(abre|abrir)\\s+(wikipedia)(\\s|$)/.test(s)){openExternal("https://es.wikipedia.org/","Wikipedia");return true;}
 if(/^(abre|abrir)\\s+(google|el buscador)(\\s|$)/.test(s)){openExternal("https://www.google.com/","Google");return true;}
 const searchMatch=raw.match(/^\\s*(?:busca(?:r)?|investiga|búscame)\\s+(.+)$/i);if(searchMatch){const query=searchMatch[1].trim();if(query){openExternal("https://www.google.com/search?q="+encodeURIComponent(query),"una búsqueda de Google sobre: "+query);return true;}}
 const calc=calculate(raw);if(calc!==null){assistant("El resultado es "+Number(calc.toFixed(8))+".");return true;}
 return false;
}
function getAiMessages(userText){const conv=getCurrentConversation();const messages=(conv?.messages||[]).filter(m=>["user","assistant"].includes(m.role)).slice(-13).map(m=>({role:m.role,content:m.text}));if(!messages.length||messages[messages.length-1].role!=="user")messages.push({role:"user",content:userText});return messages;}
function extractAiText(data){if(typeof data==="string")return data;if(!data||typeof data!=="object")return "La IA devolvió una respuesta vacía.";const candidates=[data.response,data.answer,data.reply,data.output_text,data.text,data.result?.response,data.result?.answer,data.result?.output_text,data.choices?.[0]?.message?.content,data.result?.choices?.[0]?.message?.content];for(const value of candidates){if(typeof value==="string"&&value.trim())return value.trim();}return "El Worker respondió, pero no encontré texto en su respuesta. Revisa el formato JSON de tu Worker.";}
async function askOnlineAi(userText){if(!aiEndpoint){assistant("Todavía no tengo conectada la IA en línea. Pulsa “CONFIGURAR IA EN LÍNEA”, pega la dirección de tu Worker de Cloudflare y guárdala. No pegues claves secretas aquí.");return;}let endpoint;try{endpoint=new URL(aiEndpoint);}catch{assistant("La dirección del Worker no parece válida. Abre Configurar IA y revisa la URL.");return;}if(endpoint.protocol!=="https:"&&endpoint.hostname!=="localhost"){assistant("Por seguridad, la dirección de la IA debe empezar con HTTPS.");return;}busy=true;$("sendBtn").disabled=true;$("micBtn").disabled=true;setStatus("CONECTANDO CON LA IA…");try{const controller=new AbortController();const timeout=setTimeout(()=>controller.abort(),45000);let response;try{response=await fetch(endpoint.href,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message:userText,messages:getAiMessages(userText)}),signal:controller.signal});}finally{clearTimeout(timeout);}const raw=await response.text();let data;try{data=JSON.parse(raw);}catch{data=raw;}if(!response.ok){const detail=typeof data==="object"?(data.error||data.message||data.detail):String(data).slice(0,240);throw new Error("HTTP "+response.status+(detail?": "+detail:""));}const answer=extractAiText(data);assistant(answer);}catch(error){console.error("Error de conexión con la IA",error);const message=error.name==="AbortError"?"La IA tardó demasiado en responder. Inténtalo de nuevo.":/Failed to fetch|NetworkError|Load failed/i.test(error.message)?"No pude conectar con el Worker. Revisa la URL, la conexión a internet y el CORS del Worker.":"No pude obtener respuesta de la IA. "+error.message;assistant(message);}finally{busy=false;$("sendBtn").disabled=false;$("micBtn").disabled=false;setStatus(listening?"ESCUCHANDO TU ORDEN":"SISTEMA PREPARADO");}}
async function handleUserMessage(input){const text=String(input||"").trim();if(!text||busy)return;if(text.length>2000){assistant("Tu mensaje es demasiado largo. Máximo 2000 caracteres.");return;}$("orden").value="";addMessage("user",text,{speak:false});if(handleLocalCommand(text))return;await askOnlineAi(text);}
$("form").addEventListener("submit",event=>{event.preventDefault();handleUserMessage($("orden").value);});document.querySelectorAll("[data-command]").forEach(button=>button.addEventListener("click",()=>handleUserMessage(button.dataset.command)));

// Historial exportable y selección de conversaciones
function openHistory(){renderHistory();$("historyModal").hidden=false;}
function renderHistory(){const list=$("historyList");list.replaceChildren();if(!conversations.length){const p=document.createElement("p");p.className="muted";p.textContent="No hay conversaciones guardadas.";list.append(p);return;}for(const c of conversations){const b=document.createElement("button");b.className="historyRow ghost";const title=document.createElement("span");title.className="historyTitle";title.textContent=c.title||"Conversación";const meta=document.createElement("span");meta.className="historyMeta";meta.textContent=new Date(c.updatedAt).toLocaleString("es-MX")+" · "+c.messages.length+" mensajes";b.append(title,meta);b.addEventListener("click",()=>{currentConversationId=c.id;saveState();renderChat();$("historyModal").hidden=true;assistant("Conversación cargada.",{speak:false});});list.append(b);}}
$("historyBtn").addEventListener("click",openHistory);$("closeHistoryBtn").addEventListener("click",()=>$("historyModal").hidden=true);
$("clearBtn").addEventListener("click",()=>{showPending("¿Crear una nueva conversación? La conversación actual se conservará en el historial.",()=>{createNewConversation();setStatus("NUEVA CONVERSACIÓN");});});
$("exportBtn").addEventListener("click",()=>{try{const blob=new Blob([JSON.stringify({exportedAt:new Date().toISOString(),conversations,notes,userName},null,2)],{type:"application/json;charset=utf-8"});const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download="jarvis-historial.json";document.body.append(a);a.click();a.remove();URL.revokeObjectURL(url);}catch(e){assistant("No pude exportar el historial en este navegador.");console.error(e);}});
$("deleteHistoryBtn").addEventListener("click",()=>{if(!window.confirm("¿Borrar todo el historial de conversaciones? Esta acción no se puede deshacer."))return;conversations=[];currentConversationId="";createNewConversation();saveState();renderHistory();assistant("El historial anterior se borró. Empezamos de nuevo.",{speak:false});});

// Configuración y prueba de la conexión AI
function openAiModal(){$("aiEndpointInput").value=aiEndpoint;$("aiTestResult").textContent=aiEndpoint?"Dirección guardada: "+aiEndpoint:"Aún no hay dirección guardada.";$("aiTestResult").className="muted";$("aiModal").hidden=false;}
function setAiTestResult(text,ok=false){$("aiTestResult").textContent=text;$("aiTestResult").className="muted "+(ok?"okText":"errorText");}
$("aiConfigBtn").addEventListener("click",openAiModal);$("closeAiBtn").addEventListener("click",()=>$("aiModal").hidden=true);
$("saveAiBtn").addEventListener("click",()=>{const value=$("aiEndpointInput").value.trim();if(!value){aiEndpoint="";saveState();setAiTestResult("Dirección borrada. La IA en línea está desconectada.",true);return;}try{const url=new URL(value);if(url.protocol!=="https:"&&url.hostname!=="localhost"){setAiTestResult("La dirección debe usar HTTPS.");return;}aiEndpoint=url.href;saveState();setAiTestResult("Dirección guardada. Pulsa “Probar conexión” para verificarla.",true);}catch{setAiTestResult("Escribe una URL válida, por ejemplo https://tu-worker.workers.dev/");}});
$("clearAiBtn").addEventListener("click",()=>{$("aiEndpointInput").value="";aiEndpoint="";saveState();setAiTestResult("Dirección borrada correctamente.",true);});
$("testAiBtn").addEventListener("click",async()=>{const input=$("aiEndpointInput").value.trim();let url;try{url=new URL(input);if(url.protocol!=="https:"&&url.hostname!=="localhost")throw Error("Usa HTTPS.");}catch(e){setAiTestResult("Dirección inválida. Usa la URL HTTPS de tu Worker.");return;}setAiTestResult("Probando la conexión…",true);$("testAiBtn").disabled=true;try{const controller=new AbortController();const timeout=setTimeout(()=>controller.abort(),20000);let response;try{response=await fetch(url.href,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message:"Responde exactamente: conexión correcta.",messages:[{role:"user",content:"Responde exactamente: conexión correcta."}]}),signal:controller.signal});}finally{clearTimeout(timeout);}const raw=await response.text();let data;try{data=JSON.parse(raw);}catch{data=raw;}if(!response.ok)throw Error("HTTP "+response.status+". "+(typeof data==="object"?(data.error||data.message||""):String(data).slice(0,160)));const answer=extractAiText(data);aiEndpoint=url.href;saveState();setAiTestResult("✅ Conexión correcta. Respuesta del Worker: "+answer.slice(0,220),true);}catch(e){setAiTestResult(e.name==="AbortError"?"La prueba tardó demasiado.":"No se pudo conectar: "+e.message+". Revisa el código del Worker y CORS.");}finally{$("testAiBtn").disabled=false;}});
// Cerrar modales con Escape
window.addEventListener("keydown",event=>{if(event.key==="Escape"){if(!$("historyModal").hidden)$("historyModal").hidden=true;if(!$("aiModal").hidden)$("aiModal").hidden=true;}});
loadState();
</script>
</body>
</html>
`;

function json(data, status = 200, origin = "*") {
  return new Response(JSON.stringify(data), { status, headers: {
    "content-type": "application/json; charset=utf-8",
    "access-control-allow-origin": origin,
    "access-control-allow-methods": "GET, POST, OPTIONS",
    "access-control-allow-headers": "Content-Type",
    "access-control-max-age": "86400",
    "cache-control": "no-store",
    "vary": "Origin",
    "x-content-type-options": "nosniff"
  }});
}

function htmlResponse() {
  return new Response(HTML, { status: 200, headers: {
    "content-type": "text/html; charset=utf-8",
    "cache-control": "no-store",
    "x-content-type-options": "nosniff",
    "referrer-policy": "strict-origin-when-cross-origin"
  }});
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const origin = request.headers.get("Origin") || "*";
    // Para mantener una primera configuración sencilla. En producción, restringe el origen
    // con env.ALLOWED_ORIGIN al dominio donde publiques la interfaz.
    const allowedOrigin = env.ALLOWED_ORIGIN || "*";
    if (allowedOrigin !== "*" && origin !== allowedOrigin) {
      return json({ ok: false, error: "Origen no permitido. Revisa ALLOWED_ORIGIN." }, 403, allowedOrigin);
    }
    const corsOrigin = allowedOrigin === "*" ? "*" : allowedOrigin;

    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: {
        "access-control-allow-origin": corsOrigin,
        "access-control-allow-methods": "GET, POST, OPTIONS",
        "access-control-allow-headers": "Content-Type",
        "access-control-max-age": "86400",
        "vary": "Origin"
      }});
    }

    if (request.method === "GET" && (url.pathname === "/health" || url.pathname === "/api/health")) {
      return json({ ok: true, service: "J.A.R.V.I.S. Todo en uno", model: MODEL, aiBindingConfigured: !!env.AI }, 200, corsOrigin);
    }
    if (request.method === "GET" && url.pathname === "/") return htmlResponse();
    if (request.method === "GET") return json({ ok: false, error: "Ruta no encontrada." }, 404, corsOrigin);
    if (request.method !== "POST" || (url.pathname !== "/" && url.pathname !== "/api/chat")) {
      return json({ ok: false, error: "Método o ruta no permitidos." }, 405, corsOrigin);
    }
    if (!env.AI || typeof env.AI.run !== "function") {
      return json({ ok: false, error: "La interfaz sí está publicada, pero falta el binding Workers AI llamado AI. Agrégalo en Settings > Bindings y vuelve a publicar." }, 500, corsOrigin);
    }

    try {
      const raw = await request.text();
      if (!raw || raw.length > MAX_BODY_CHARS) return json({ ok: false, error: "Solicitud vacía o demasiado grande." }, 413, corsOrigin);
      let body;
      try { body = JSON.parse(raw); } catch { return json({ ok: false, error: "El cuerpo debe ser JSON válido." }, 400, corsOrigin); }
      const userMessage = typeof body.message === "string" ? body.message.trim().slice(0, 2000) : "";
      const incoming = Array.isArray(body.messages) ? body.messages : [];
      const messages = incoming
        .filter(m => m && ["user", "assistant"].includes(m.role) && typeof m.content === "string")
        .slice(-12)
        .map(m => ({ role: m.role, content: m.content.slice(0, 3000) }));
      if (!messages.length && userMessage) messages.push({ role: "user", content: userMessage });
      if (!messages.length) return json({ ok: false, error: "Falta el mensaje del usuario." }, 400, corsOrigin);
      if (userMessage && messages[messages.length - 1].role !== "user") messages.push({ role: "user", content: userMessage });

      const result = await env.AI.run(MODEL, {
        messages: [{ role: "system", content: SYSTEM_PROMPT }, ...messages],
        max_tokens: 700,
        temperature: 0.6
      });
      const answer = typeof result?.response === "string" ? result.response.trim()
        : typeof result?.output_text === "string" ? result.output_text.trim()
        : typeof result === "string" ? result.trim() : "";
      if (!answer) return json({ ok: false, error: "El modelo no devolvió texto. Inténtalo de nuevo." }, 502, corsOrigin);
      return json({ ok: true, response: answer, answer, model: MODEL }, 200, corsOrigin);
    } catch (error) {
      console.error("J.A.R.V.I.S. AI error:", error);
      return json({ ok: false, error: "No se pudo generar una respuesta. Comprueba que Workers AI esté habilitado, el binding AI exista y tu cuenta tenga uso disponible." }, 502, corsOrigin);
    }
  }
};
