// Cloudflare Worker: يخفي مفتاح الذكاء الاصطناعي عن المتصفح
// 1) أنشئ Worker جديد والصق هذا الكود
// 2) Settings > Variables > أضف سر (Secret) باسم ANTHROPIC_API_KEY
// 3) غيّر ALLOWED_ORIGIN إلى رابط موقعك

const ALLOWED_ORIGIN = "*"; // مثال: "https://yoursite.com"

const cors = {
  "Access-Control-Allow-Origin": ALLOWED_ORIGIN,
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};

export default {
  async fetch(req, env) {
    if (req.method === "OPTIONS") return new Response(null, { headers: cors });
    if (req.method !== "POST") return new Response("Method not allowed", { status: 405, headers: cors });

    let prompt = "", messages = null;
    try { ({ prompt, messages } = await req.json()); } catch (e) {}
    if (!messages && prompt) messages = [{ role: "user", content: prompt }];
    const size = JSON.stringify(messages || "").length;
    if (!Array.isArray(messages) || !messages.length || messages.length > 12 || size > 8000) {
      return Response.json({ error: "bad request" }, { status: 400, headers: cors });
    }

    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-haiku-5-5",
        max_tokens: 1000,
        messages,
      }),
    });

    if (!r.ok) return Response.json({ error: "ai error" }, { status: 502, headers: cors });
    const d = await r.json();
    const text = (d.content || []).map((c) => c.text || "").join("\n");
    return Response.json({ text }, { headers: cors });
  },
};
