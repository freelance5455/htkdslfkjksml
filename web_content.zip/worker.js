// Cloudflare Worker — API backend pour Togo AI Ultra.
// Configure GEMINI_API_KEY comme secret dans les paramètres du Worker.
// Ne mets JAMAIS la clé API dans index.html.
const cors = {
  "Access-Control-Allow-Origin": "*", // En production, remplace * par le domaine exact de ton site.
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};
function json(data, status=200){return new Response(JSON.stringify(data),{status,headers:{"Content-Type":"application/json; charset=utf-8",...cors}})}
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if(request.method==="OPTIONS") return new Response(null,{status:204,headers:cors});
    if(url.pathname==="/api/health" && request.method==="GET") return json({ok:true,service:"Togo AI Ultra"});
    if(url.pathname!=="/api/chat") return json({error:"Route introuvable."},404);
    if(request.method!=="POST") return json({error:"Méthode non autorisée."},405);
    if(!env.GEMINI_API_KEY) return json({error:"La clé GEMINI_API_KEY n'est pas configurée dans le serveur."},503);
    let body;
    try { body=await request.json(); } catch { return json({error:"Requête JSON invalide."},400); }
    const message=typeof body.message==="string"?body.message.trim():"";
    if(!message) return json({error:"Écris une question."},400);
    if(message.length>5000) return json({error:"Question trop longue (maximum 5000 caractères)."},413);
    try {
      // Le nom de modèle peut évoluer : vérifie les modèles disponibles pour ton compte Gemini.
      const model = env.GEMINI_MODEL || "gemini-2.5-flash";
      const upstream=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(env.GEMINI_API_KEY)}`,{
        method:"POST",headers:{"Content-Type":"application/json"},
        body:JSON.stringify({
          systemInstruction:{parts:[{text:"Tu es Togo AI Ultra, un assistant utile, honnête et clair. Réponds dans la langue de l'utilisateur, privilégie le français simple, tiens compte du contexte du Togo si pertinent. N'invente pas des faits ni des preuves. Pour les devoirs, explique les étapes."}]},
          contents:[{role:"user",parts:[{text:message}]}],
          generationConfig:{temperature:0.7,maxOutputTokens:1200}
        })
      });
      const data=await upstream.json().catch(()=>({}));
      if(!upstream.ok) return json({error:data.error?.message||"Le fournisseur IA a refusé la requête. Vérifie la clé, le modèle et les quotas."},502);
      const reply=(data.candidates||[]).flatMap(c=>c.content?.parts||[]).map(p=>p.text||"").join("\n").trim();
      if(!reply) return json({error:"Aucune réponse générée. Réessaie."},502);
      return json({reply});
    } catch(e) {
      return json({error:"Erreur de connexion au fournisseur IA. Réessaie plus tard."},502);
    }
  }
};