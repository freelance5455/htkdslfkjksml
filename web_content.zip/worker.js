/**
 * ============================================================================
 * Cloudflare Worker — وسيط آمن لخدمة Gemini AI (تطبيق يقظة بلادي)
 * ============================================================================
 * الغرض: يحمل مفتاح Gemini API على الخادم (Cloudflare) بدل المتصفح، بحيث لا
 * يظهر المفتاح أبداً لأي زائر يفحص كود الموقع (Ctrl+U أو DevTools). المتصفح
 * يرسل فقط نص الحادثة لهذا الـ Worker، والـ Worker هو من يتصل بـ Google
 * ويستعمل المفتاح السري (الذي لا يغادر إعدادات Cloudflare إطلاقاً).
 *
 * ---------------------------------------------------------------------------
 * خطوات النشر (5 دقائق تقريباً، بدون أي أدوات سطر أوامر):
 * ---------------------------------------------------------------------------
 * 1) اذهب إلى dash.cloudflare.com ← Workers & Pages ← Create ← Create Worker
 * 2) اختر اسماً (مثال: yakada-ai-proxy) ← Deploy
 * 3) اضغط "Edit code" ← احذف كل الكود الموجود ← الصق محتوى هذا الملف بالكامل ← Deploy
 * 4) من صفحة الـ Worker: Settings ← Variables and Secrets ← Add
 *    الاسم: GEMINI_API_KEY   |  القيمة: مفتاحك الحقيقي من aistudio.google.com/apikey
 *    ⚠️ مهم: اختر النوع "Secret" وليس "Text" حتى يبقى مخفياً تماماً حتى عنك أنت لاحقاً.
 * 5) بعد الحفظ، انسخ رابط الـ Worker (يظهر أعلى الصفحة، شكله:
 *    https://yakada-ai-proxy.<اسمك>.workers.dev)
 * 6) افتح index.html ← ابحث عن AI_PROXY_URL ← الصق الرابط بين علامتي التنصيص
 * 7) احذف المفتاح القديم من GEMINI_API_KEY في index.html (لم يعد يُستعمل، ويفضّل
 *    عدم ترك مفتاح حقيقي ظاهراً حتى لو غير مُستخدَم فعلياً)
 * ============================================================================
 */

// ✅ عدّل هذا إن أردت تقييد الوصول لنطاق موقعك فقط بدل "*" (أكثر أماناً لاحقاً)
const ALLOWED_ORIGIN = '*';

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': ALLOWED_ORIGIN,
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type',
};

export default {
  async fetch(request, env) {
    // طلب التحقق المبدئي من المتصفح (CORS preflight) — يجب الرد عليه فوراً بدون منطق إضافي
    if (request.method === 'OPTIONS') {
      return new Response(null, { headers: CORS_HEADERS });
    }

    // ✅ مسار اختياري: جلب وحدات الحماية المدنية (دليل DGPC عبر GeoAlgeria) من الخادم — يتفادى قيود CORS بالمتصفح
    const url = new URL(request.url);
    if (request.method === 'GET' && url.pathname === '/api/dgpc-units') {
      return dgpcUnits();
    }

    // ✅ مسار: بيانات اعتماد TURN قصيرة الأجل للاتصال الصوتي (WebRTC) — المفتاح الطويل الأمد
    // (TURN_KEY_ID / TURN_KEY_API_TOKEN) يبقى سرّاً على الخادم فقط، ولا يصل أبداً للمتصفح
    if (request.method === 'GET' && url.pathname === '/api/turn-credentials') {
      return turnCredentials(env);
    }

    if (request.method !== 'POST') {
      return jsonResponse({ error: { message: 'يُقبل فقط POST' } }, 405);
    }

    if (!env.GEMINI_API_KEY) {
      return jsonResponse({ error: { message: 'GEMINI_API_KEY غير مضبوط في إعدادات الـ Worker (Settings → Variables and Secrets)' } }, 500);
    }

    let payload;
    try {
      payload = await request.json();
    } catch (e) {
      return jsonResponse({ error: { message: 'جسم الطلب ليس JSON صالحاً' } }, 400);
    }

    const { input, systemPrompt, models, tools } = payload;
    if (!input || typeof input !== 'string') {
      return jsonResponse({ error: { message: 'الحقل input مفقود أو غير نصي' } }, 400);
    }
    const modelChain = Array.isArray(models) && models.length > 0
      ? models
      : ['gemini-3.8-flash', 'gemini-3.5-flash-lite', 'gemini-3.1-flash-lite', 'gemini-3.7-flash', 'gemini-3.6-flash', 'gemini-3.5-flash', 'gemini-2.5-flash-lite', 'gemini-2.5-flash']; // الأحدث أولاً (3.8 GA) — نماذج 2.5 احتياط فقط

    // ✅ نفس منطق التراجع التلقائي بين النماذج، لكن الآن على الخادم بدل المتصفح
    let lastError = null;
    for (const model of modelChain) {
      try {
        const googleRes = await fetch('https://generativelanguage.googleapis.com/v1beta/interactions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-goog-api-key': env.GEMINI_API_KEY,
          },
          body: JSON.stringify({
            model,
            input,
            system_instruction: systemPrompt || undefined,
            tools: Array.isArray(tools) && tools.length ? tools : undefined,
            generation_config: { max_output_tokens: 1200, temperature: 0.3 },
          }),
        });

        const data = await googleRes.json().catch(() => ({}));

        if (googleRes.ok) {
          // نُعيد استجابة Google كما هي — الواجهة الأمامية مبنية أصلاً لفهم هذا الشكل مباشرة
          return jsonResponse(data, 200);
        }

        lastError = data.error?.message || `HTTP ${googleRes.status}`;
        // ✅ تصحيح: خطأ حصة/معدّل منتهٍ لهذا النموذج تحديداً (شائع مع النماذج الأحدث كـ gemini-3.8-flash
        // على الحصة المجانية) يستحق أيضاً تجربة النموذج التالي، لأن لكل نموذج حصة مستقلة عن الآخر
        const isModelSpecificFailure = googleRes.status !== 401 && googleRes.status !== 403 && (
          [400, 404, 429, 500, 503].includes(googleRes.status)
          || /no longer available|not found|NOT_FOUND|RESOURCE_EXHAUSTED|quota|overloaded|unavailable|not supported|unsupported/i.test(lastError));
        if (!isModelSpecificFailure) break;
      } catch (networkErr) {
        lastError = networkErr.message;
      }
    }

    return jsonResponse({ error: { message: lastError || 'تعذر الاتصال بأي نموذج من سلسلة Gemini' } }, 502);
  },
};

function jsonResponse(obj, status) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { 'Content-Type': 'application/json', ...CORS_HEADERS },
  });
}

// ✅ مصدر بيانات وحدات الحماية المدنية: دليل المديرية العامة للحماية المدنية (dgpc.dz) كما تنشره GeoAlgeria
// كبيانات مفتوحة GeoJSON (سجلات: الاسم، النوع، العنوان، الهاتف، الإحداثيات). الصفحة: geoalgeria.com/ar/protection-civile
const DGPC_SOURCES = [
  'https://geoalgeria.com/geodata/protection-civile.geojson',
];

async function dgpcUnits() {
  let lastErr = 'لا مصدر متاح';
  for (const src of DGPC_SOURCES) {
    try {
      const res = await fetch(src, { headers: { 'Accept': 'application/geo+json, application/json' } });
      if (!res.ok) { lastErr = `HTTP ${res.status} من ${src}`; continue; }
      const geojson = await res.json();
      if (!geojson || !Array.isArray(geojson.features) || geojson.features.length === 0) { lastErr = `ملف بلا وحدات: ${src}`; continue; }
      return new Response(JSON.stringify(geojson), {
        status: 200,
        headers: { 'Content-Type': 'application/geo+json', 'Cache-Control': 'public, max-age=21600', ...CORS_HEADERS },
      });
    } catch (e) {
      lastErr = e.message || String(e);
    }
  }
  return jsonResponse({ error: { message: 'تعذر جلب وحدات الحماية المدنية: ' + lastErr } }, 502);
}

// ✅ يولّد بيانات اعتماد TURN صالحة لمدة ساعتين فقط لكل مكالمة (وليس مفتاحاً دائماً) — حسب توصية
// Cloudflare الرسمية: https://developers.cloudflare.com/realtime/turn/generate-credentials/
// TURN_KEY_ID و TURN_KEY_API_TOKEN يُضبطان كأسرار على الـ Worker (Settings → Variables → Secret)
async function turnCredentials(env) {
  const FALLBACK = { iceServers: [{ urls: ['stun:stun.l.google.com:19302'] }] }; // بدون TURN — يعمل بين شبكتين مفتوحتين فقط
  if (!env.TURN_KEY_ID || !env.TURN_KEY_API_TOKEN) {
    return new Response(JSON.stringify({ ...FALLBACK, warning: 'TURN غير مُفعَّل على الخادم — الاتصال قد يفشل عبر بعض شبكات الهاتف' }), {
      status: 200, headers: { 'Content-Type': 'application/json', ...CORS_HEADERS },
    });
  }
  try {
    const res = await fetch(
      `https://rtc.live.cloudflare.com/v1/turn/keys/${env.TURN_KEY_ID}/credentials/generate-ice-servers`,
      { method: 'POST', headers: { 'Authorization': `Bearer ${env.TURN_KEY_API_TOKEN}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ ttl: 7200 }) }
    );
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const data = await res.json();
    return new Response(JSON.stringify(data), { status: 200, headers: { 'Content-Type': 'application/json', ...CORS_HEADERS } });
  } catch (e) {
    return new Response(JSON.stringify({ ...FALLBACK, warning: 'تعذر توليد TURN: ' + (e.message || e) }), {
      status: 200, headers: { 'Content-Type': 'application/json', ...CORS_HEADERS },
    });
  }
}

