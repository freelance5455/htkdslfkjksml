CLIO 25.0 — Android PWA starter

CONTENTS
- index.html: existing CLIO 10.0 app carried forward as the starting version
- manifest.webmanifest: installable app metadata
- sw.js: basic offline shell cache
- icon-*.png: app icons

IMPORTANT
This is a PWA-ready starter bundle, not a published website or compiled APK yet.
The current HTML still contains the CLIO 10.0 feature set and its AI backend is not connected.
Do not put an AI provider secret/API key in index.html or any public browser file. A secure server endpoint must be configured for live AI answers.

PUBLISHING OVERVIEW
1. Upload all files in this folder to a static HTTPS host, keeping them together in the site root.
2. Open the published HTTPS URL in Chrome on Android and test all sections.
3. Enter that URL into PWABuilder and generate an Android package.
4. Test the APK before any store submission. Keep the signing key safe.

The Android package flow requires a publicly hosted HTTPS PWA. Store publication also requires a developer account and store review.
