package com.chameleon.voice;

import android.Manifest;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.media.AudioDeviceInfo;
import android.media.AudioFocusRequest;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.media.AudioDeviceCallback;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;

/**
 * Chameleon Voice — Android shell.
 * Native low-latency audio engine + WebView UI (assets/ui.html).
 */
public class MainActivity extends Activity {

    private static final int SR = 48000;
    private static final int REQ_MIC = 1001;
    private static final String CHANNEL_ID = "chameleon";

    private WebView web;
    private final VoiceProcessor processor = new VoiceProcessor(SR);
    private AudioEngine engine;
    private AudioManager am;
    private Handler ui = new Handler(Looper.getMainLooper());

    private int pendingMode = -1;
    private String preferredDeviceId = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().setStatusBarColor(0xFF0A0F18);
            getWindow().setNavigationBarColor(0xFF06090F);
        }

        am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        engine = new AudioEngine();

        web = new WebView(this);
        web.setBackgroundColor(0xFF06090F);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setTextZoom(100);
        web.setWebViewClient(new WebViewClient());
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl("file:///android_asset/ui.html");
        setContentView(web);

        createNotificationChannel();
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else moveTaskToBack(true);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (engine != null) engine.stop();
        if (am != null) {
            try { am.setMode(AudioManager.MODE_NORMAL); } catch (Exception ignored) {}
        }
    }

    /* ================================================================== */
    /* permissions                                                        */
    /* ================================================================== */
    private void requestMicThenStart(int mode) {
        if (Build.VERSION.SDK_INT >= 23 &&
                checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingMode = mode;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            return;
        }
        engine.start(mode);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_MIC) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                engine.start(pendingMode < 0 ? 0 : pendingMode);
            } else {
                toastJs("Без доступа к микрофону обработка невозможна", true);
            }
            pendingMode = -1;
        }
    }

    private void toastJs(String msg, boolean error) {
        final String js = "window.__nativeToast && window.__nativeToast(" + JSONObject.quote(msg) + "," + error + ")";
        ui.post(new Runnable() {
            @Override public void run() { if (web != null) web.evaluateJavascript(js, null); }
        });
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Обработка голоса",
                    NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Показывает, что голос обрабатывается");
            ch.setShowBadge(false);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }

    private void showNotification(boolean on) {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        if (!on) { nm.cancel(1); return; }
        Intent i = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, i,
                Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        b.setContentTitle("Chameleon Voice")
         .setContentText("Голос обрабатывается в реальном времени")
         .setSmallIcon(android.R.drawable.ic_btn_speak_now)
         .setOngoing(true)
         .setContentIntent(pi);
        nm.notify(1, b.build());
    }

    /* ================================================================== */
    /* audio engine                                                       */
    /* ================================================================== */
    private final class AudioEngine extends Thread {
        private volatile boolean running = false;
        private AudioRecord record;
        private AudioTrack track;
        private int mode = 0;          // 0 = practice (speaker), 1 = call
        private AudioFocusRequest focus;
        private volatile boolean recording = false;
        private File recordFile;
        private FileOutputStream recordOut;
        private long recordedBytes = 0;

        volatile float inputPeak = 0f;
        volatile boolean monitorOn = true;

        @Override
        public void run() {
            running = true;
            final int minBuf = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT);
            int bufBytes = Math.max(minBuf * 2, 4096);

            try {
                record = buildRecorder(bufBytes);
                int outMin = AudioTrack.getMinBufferSize(SR, AudioFormat.CHANNEL_OUT_MONO,
                        AudioFormat.ENCODING_PCM_16BIT);
                track = buildTrack(Math.max(outMin * 2, 4096));

                applyRoute();

                record.startRecording();
                track.setVolume(monitorOn ? 1f : 0f);
                track.play();

                short[] in = new short[480];   // 10 ms blocks -> low latency
                short[] out = new short[480];

                while (running) {
                    int n = record.read(in, 0, in.length);
                    if (n <= 0) continue;

                    float peak = 0f;
                    for (int i = 0; i < n; i++) {
                        float v = in[i] / 32768f;
                        float a = v < 0 ? -v : v;
                        if (a > peak) peak = a;
                    }
                    inputPeak = peak;

                    processor.process(in, n, out);
                    track.write(out, 0, n);

                    if (recording) writeWav(out, n);
                }
            } catch (Throwable t) {
                final String msg = t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage();
                toastJs("Ошибка аудио: " + msg, true);
            } finally {
                cleanup();
            }
        }

        private AudioRecord buildRecorder(int bufBytes) {
            int source = mode == 1 ? MediaRecorder.AudioSource.VOICE_COMMUNICATION
                                   : MediaRecorder.AudioSource.MIC;
            if (Build.VERSION.SDK_INT >= 23) {
                return new AudioRecord.Builder()
                        .setAudioSource(source)
                        .setAudioFormat(new AudioFormat.Builder()
                                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                                .setSampleRate(SR)
                                .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                                .build())
                        .setBufferSizeInBytes(bufBytes)
                        .build();
            }
            return new AudioRecord(source, SR, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, bufBytes);
        }

        private AudioTrack buildTrack(int bufBytes) {
            if (Build.VERSION.SDK_INT >= 23) {
                return new AudioTrack.Builder()
                        .setAudioAttributes(new AudioAttributes.Builder()
                                .setUsage(mode == 1 ? AudioAttributes.USAGE_VOICE_COMMUNICATION
                                                    : AudioAttributes.USAGE_MEDIA)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                                .build())
                        .setAudioFormat(new AudioFormat.Builder()
                                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                                .setSampleRate(SR)
                                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                                .build())
                        .setBufferSizeInBytes(bufBytes)
                        .setTransferMode(AudioTrack.MODE_STREAM)
                        .build();
            }
            return new AudioTrack(AudioManager.STREAM_VOICE_CALL, SR,
                    AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    bufBytes, AudioTrack.MODE_STREAM);
        }

        private void applyRoute() {
            try {
                if (mode == 1) {
                    // voice-call path: keep the earpiece / headset / bluetooth, no speakerphone
                    am.setMode(AudioManager.MODE_IN_COMMUNICATION);
                    am.setSpeakerphoneOn(routeSpeaker);
                    am.setBluetoothScoOn(true);
                    if (Build.VERSION.SDK_INT < 31) am.startBluetoothSco();
                } else {
                    // practice: play the processed voice out loud
                    am.setMode(AudioManager.MODE_NORMAL);
                    am.setSpeakerphoneOn(true);
                }
            } catch (Exception ignored) {}
        }

        private void writeWav(short[] data, int n) {
            try {
                if (recordOut == null) return;
                byte[] b = new byte[n * 2];
                for (int i = 0; i < n; i++) {
                    b[i * 2] = (byte) (data[i] & 0xff);
                    b[i * 2 + 1] = (byte) ((data[i] >> 8) & 0xff);
                }
                recordOut.write(b);
                recordedBytes += b.length;
            } catch (Exception ignored) {}
        }

        void start(int m) {
            if (running) return;
            this.mode = m;
            start();
        }

        void stopEngine() {
            running = false;
            try { join(600); } catch (InterruptedException ignored) {}
        }

        boolean isRunning() { return running; }

        void setMonitor(boolean on) {
            try { if (track != null) track.setVolume(on ? 1f : 0f); } catch (Exception ignored) {}
            monitorOn = on;
        }

        void beginRecording(File f) {
            try {
                recordFile = f;
                recordOut = new FileOutputStream(f);
                recordedBytes = 0;
                recordOut.write(new byte[44]); // WAV header placeholder
                recording = true;
            } catch (Exception e) {
                recording = false;
            }
        }

        File endRecording() {
            recording = false;
            try {
                if (recordOut != null) {
                    recordOut.close();
                    patchWavHeader(recordFile, recordedBytes);
                }
            } catch (Exception ignored) {}
            recordOut = null;
            return recordFile;
        }

        int modeValue() { return mode; }

        private void cleanup() {
            running = false;
            try { if (record != null) { record.stop(); record.release(); } } catch (Exception ignored) {}
            record = null;
            try { if (track != null) { track.pause(); track.flush(); track.release(); } } catch (Exception ignored) {}
            track = null;
            try {
                am.stopBluetoothSco();
                am.setBluetoothScoOn(false);
                am.setMode(AudioManager.MODE_NORMAL);
            } catch (Exception ignored) {}
            showNotification(false);
            final String js = "window.__nativeState && window.__nativeState('stopped')";
            ui.post(new Runnable() {
                @Override public void run() { if (web != null) web.evaluateJavascript(js, null); }
            });
        }
    }

    private volatile boolean routeSpeaker = false;

    private static void patchWavHeader(File f, long dataLen) {
        try {
            RandomAccessFile raf = new RandomAccessFile(f, "rw");
            raf.seek(0);
            int total = (int) dataLen + 36;
            raf.writeBytes("RIFF");
            writeIntLE(raf, total);
            raf.writeBytes("WAVEfmt ");
            writeIntLE(raf, 16);
            writeShortLE(raf, 1);      // PCM
            writeShortLE(raf, 1);      // mono
            writeIntLE(raf, SR);
            writeIntLE(raf, SR * 2);   // byte rate
            writeShortLE(raf, 2);      // block align
            writeShortLE(raf, 16);     // bits
            raf.writeBytes("data");
            writeIntLE(raf, (int) dataLen);
            raf.close();
        } catch (Exception ignored) {}
    }

    private static void writeIntLE(RandomAccessFile r, int v) throws Exception {
        r.write(v & 0xff);
        r.write((v >> 8) & 0xff);
        r.write((v >> 16) & 0xff);
        r.write((v >> 24) & 0xff);
    }

    private static void writeShortLE(RandomAccessFile r, int v) throws Exception {
        r.write(v & 0xff);
        r.write((v >> 8) & 0xff);
    }

    /* ================================================================== */
    /* JS bridge                                                          */
    /* ================================================================== */
    private final class Bridge {

        @JavascriptInterface
        public String info() {
            JSONObject o = new JSONObject();
            try {
                o.put("model", Build.MANUFACTURER + " " + Build.MODEL);
                o.put("android", Build.VERSION.RELEASE);
                o.put("sdk", Build.VERSION.SDK_INT);
                o.put("sampleRate", SR);
                o.put("device", Build.DEVICE);
                o.put("board", Build.BOARD);
            } catch (Exception ignored) {}
            return o.toString();
        }

        @JavascriptInterface
        public String presets() {
            JSONArray arr = new JSONArray();
            try {
                for (int i = 0; i < VoiceProcessor.PRESET_IDS.length; i++) {
                    JSONObject o = new JSONObject();
                    o.put("id", VoiceProcessor.PRESET_IDS[i]);
                    o.put("label", VoiceProcessor.PRESET_LABELS[i]);
                    o.put("tag", VoiceProcessor.PRESET_TAGS[i]);
                    arr.put(o);
                }
            } catch (Exception ignored) {}
            return arr.toString();
        }

        @JavascriptInterface
        public void setPreset(String id) {
            processor.applyPreset(id);
        }

        @JavascriptInterface
        public void setParams(String json) {
            try {
                JSONObject o = new JSONObject(json);
                processor.pitch = (float) o.optDouble("pitch", processor.pitch);
                processor.formant = (float) o.optDouble("formant", processor.formant);
                processor.robot = (float) o.optDouble("robot", processor.robot);
                processor.breath = (float) o.optDouble("breath", processor.breath);
                processor.ringHz = (float) o.optDouble("ringHz", processor.ringHz);
                processor.ringMix = (float) o.optDouble("ringMix", processor.ringMix);
                processor.echoMs = (float) o.optDouble("echoMs", processor.echoMs);
                processor.echoMix = (float) o.optDouble("echoMix", processor.echoMix);
                processor.reverb = (float) o.optDouble("reverb", processor.reverb);
                processor.reverbMix = (float) o.optDouble("reverbMix", processor.reverbMix);
                processor.lowcut = (float) o.optDouble("lowcut", processor.lowcut);
                processor.highcut = (float) o.optDouble("highcut", processor.highcut);
                processor.distortion = (float) o.optDouble("distortion", processor.distortion);
                processor.tremolo = (float) o.optDouble("tremolo", processor.tremolo);
                processor.noise = (float) o.optDouble("noise", processor.noise);
                processor.gain = (float) o.optDouble("gain", processor.gain);
                processor.dryMix = (float) o.optDouble("dryMix", processor.dryMix);
                processor.updateFilters();
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public String presetValues(String id) {
            VoiceProcessor tmp = new VoiceProcessor(SR);
            tmp.applyPreset(id);
            JSONObject o = new JSONObject();
            try {
                o.put("pitch", tmp.pitch);
                o.put("formant", tmp.formant);
                o.put("robot", tmp.robot);
                o.put("breath", tmp.breath);
                o.put("ringHz", tmp.ringHz);
                o.put("ringMix", tmp.ringMix);
                o.put("echoMs", tmp.echoMs);
                o.put("echoMix", tmp.echoMix);
                o.put("reverb", tmp.reverb);
                o.put("reverbMix", tmp.reverbMix);
                o.put("lowcut", tmp.lowcut);
                o.put("highcut", tmp.highcut);
                o.put("distortion", tmp.distortion);
                o.put("tremolo", tmp.tremolo);
                o.put("noise", tmp.noise);
                o.put("gain", tmp.gain);
            } catch (Exception ignored) {}
            return o.toString();
        }

        @JavascriptInterface
        public void start(int mode) {
            if (mode == 1) routeSpeaker = false;
            showNotification(true);
            requestMicThenStart(mode);
        }

        @JavascriptInterface
        public void stop() {
            engine.stopEngine();
            showNotification(false);
        }

        @JavascriptInterface
        public void setMonitor(boolean on) {
            engine.setMonitor(on);
        }

        @JavascriptInterface
        public void setRoute(String route) {
            routeSpeaker = "speaker".equals(route);
            if (am != null) {
                try {
                    am.setSpeakerphoneOn(routeSpeaker);
                    if (!routeSpeaker && Build.VERSION.SDK_INT >= 31) {
                        // keep default (earpiece / wired / bt)
                    }
                } catch (Exception ignored) {}
            }
        }

        @JavascriptInterface
        public String state() {
            JSONObject o = new JSONObject();
            try {
                o.put("running", engine.isRunning());
                o.put("mode", engine.modeValue());
                o.put("outPeak", processor.lastPeak);
                o.put("inPeak", engine.inputPeak);
            } catch (Exception ignored) {}
            return o.toString();
        }

        @JavascriptInterface
        public void vibrate() {
            try {
                Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                if (v != null && v.hasVibrator()) {
                    if (Build.VERSION.SDK_INT >= 26) {
                        v.vibrate(VibrationEffect.createOneShot(18, VibrationEffect.DEFAULT_AMPLITUDE));
                    } else {
                        v.vibrate(18);
                    }
                }
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public String audioInterfaces() {
            JSONArray arr = new JSONArray();
            try {
                if (Build.VERSION.SDK_INT >= 23) {
                    for (AudioDeviceInfo d : am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)) {
                        JSONObject o = new JSONObject();
                        o.put("id", String.valueOf(d.getId()));
                        o.put("name", typeName(d.getType()) + (d.getProductName() != null ? " · " + d.getProductName() : ""));
                        arr.put(o);
                    }
                }
            } catch (Exception ignored) {}
            return arr.toString();
        }

        private String typeName(int t) {
            switch (t) {
                case AudioDeviceInfo.TYPE_BUILTIN_EARPIECE: return "Динамик у уха";
                case AudioDeviceInfo.TYPE_BUILTIN_SPEAKER: return "Громкая связь";
                case AudioDeviceInfo.TYPE_WIRED_HEADSET:
                case AudioDeviceInfo.TYPE_WIRED_HEADPHONES: return "Проводная гарнитура";
                case AudioDeviceInfo.TYPE_BLUETOOTH_A2DP:
                case AudioDeviceInfo.TYPE_BLUETOOTH_SCO: return "Bluetooth";
                case AudioDeviceInfo.TYPE_USB_HEADSET:
                case AudioDeviceInfo.TYPE_USB_DEVICE: return "USB-гарнитура";
                default: return "Аудиовыход " + t;
            }
        }

        @JavascriptInterface
        public void setPreferredDevice(String id) {
            preferredDeviceId = id == null ? "" : id;
        }

        @JavascriptInterface
        public void startRecording() {
            File dir = new File(getFilesDir(), "recordings");
            if (!dir.exists()) dir.mkdirs();
            File f = new File(dir, "demo-" + System.currentTimeMillis() + ".wav");
            engine.beginRecording(f);
        }

        @JavascriptInterface
        public String stopRecording() {
            File f = engine.endRecording();
            return f == null ? "" : f.getAbsolutePath();
        }

        @JavascriptInterface
        public boolean isRecording() {
            return engine.recording;
        }

        @JavascriptInterface
        public void openFile(String path) {
            try {
                Intent i = new Intent(Intent.ACTION_VIEW);
                Uri uri = Uri.parse("file://" + path);
                i.setDataAndType(uri, "audio/wav");
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } catch (Exception e) {
                toastJs("Не нашлось приложения для проигрывания WAV", true);
            }
        }

        @JavascriptInterface
        public void shareRecordings() {
            try {
                File dir = new File(getFilesDir(), "recordings");
                File[] files = dir.listFiles();
                if (files == null || files.length == 0) { toastJs("Записей пока нет", true); return; }
                File last = files[0];
                for (File f : files) if (f.lastModified() > last.lastModified()) last = f;
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("audio/wav");
                i.putExtra(Intent.EXTRA_STREAM, Uri.parse("file://" + last.getAbsolutePath()));
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(i, "Отправить запись"));
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public void openUrl(String url) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            } catch (Exception ignored) {}
        }
    }
}
