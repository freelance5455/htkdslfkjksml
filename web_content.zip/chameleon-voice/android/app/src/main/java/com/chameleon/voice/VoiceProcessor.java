package com.chameleon.voice;

import java.util.Arrays;

/**
 * Chameleon DSP — real-time voice effects, pure Java (no dependencies).
 *
 * Signal path:
 *   in -> highpass -> drive -> lowpass -> FORMANT -> PITCH -> tremolo
 *        -> breath -> ring mod -> echo -> reverb -> gain -> out
 *
 * Everything is driven by {@link #process(short[], int, short[])} so it can run
 * inside an AudioTrack/AudioRecord loop with a fixed small buffer.
 */
public final class VoiceProcessor {

    /* ------------------------------------------------------------------ */
    /* parameters                                                          */
    /* ------------------------------------------------------------------ */
    public float pitch = 0f;      // semitones  -12..12
    public float formant = 0f;    // semitones  -12..12
    public float robot = 0f;      // 0..100
    public float breath = 0f;     // 0..100
    public float ringHz = 1.1f;   // 0.1..4
    public float ringMix = 0f;    // 0..100
    public float echoMs = 0f;     // 0..600
    public float echoMix = 0f;    // 0..100
    public float reverb = 14f;    // 0..100
    public float reverbMix = 0f;  // 0..100
    public float lowcut = 70f;    // Hz
    public float highcut = 8000f; // Hz
    public float distortion = 0f; // 0..100
    public float tremolo = 0f;    // Hz
    public float noise = 0f;      // 0..100
    public float gain = 1f;       // 0.2..2

    public float dryMix = 0f;     // 0..1 direct (ungated) signal

    private final int sampleRate;

    /* ------------------------------------------------------------------ */
    /* state                                                               */
    /* ------------------------------------------------------------------ */
    private final Doppler pitchShifter;

    // biquads
    private final Biquad hp = new Biquad();
    private final Biquad lp = new Biquad();
    private final Biquad formantLow = new Biquad();
    private final Biquad formantHigh = new Biquad();
    private final Biquad breathHp = new Biquad();
    private final Biquad breathLp = new Biquad();

    // modulation
    private double tremPhase = 0, ringPhase = 0;

    // echo
    private final float[] echoBuf;
    private int echoW = 0;

    // reverb (small stereo-free Schroeder: 4 combs + 2 allpass)
    private final float[][] combs = new float[4][];
    private final int[] combIdx = new int[4];
    private final float[] combDamp = new float[4];
    private final float[][] allpass = new float[2][];
    private final int[] apIdx = new int[2];

    // noise gate envelope
    private float env = 0f;

    // scratch
    private float lastIn = 0f;

    public VoiceProcessor(int sampleRate) {
        this.sampleRate = sampleRate;
        pitchShifter = new Doppler(sampleRate, 2048);

        echoBuf = new float[(int) (sampleRate * 0.75f) + 8];
        int[] combLen = { 1116, 1188, 1277, 1356 };
        for (int i = 0; i < 4; i++) {
            int len = Math.max(64, combLen[i] * sampleRate / 44100);
            combs[i] = new float[len];
        }
        int[] apLen = { 556, 441 };
        for (int i = 0; i < 2; i++) {
            int len = Math.max(32, apLen[i] * sampleRate / 44100);
            allpass[i] = new float[len];
        }
        updateFilters();
    }

    /* ------------------------------------------------------------------ */
    /* coefficient updates (cheap; called once per buffer)                 */
    /* ------------------------------------------------------------------ */
    public void updateFilters() {
        // gentle high-pass
        hp.setHighpass(Math.max(20f, Math.min(2000f, lowcut)), 0.707f, sampleRate);
        // low-pass above the Nyquist-safe limit
        lp.setLowpass(Math.max(400f, Math.min(sampleRate * 0.45f, highcut)), 0.707f, sampleRate);

        // formant tilt: negative -> boost lows / cut highs (bigger voice)
        float tilt = Math.max(-12f, Math.min(12f, formant)) * 0.75f;
        formantLow.setLowShelf(420f, -tilt, sampleRate);
        formantHigh.setHighShelf(2600f, tilt, sampleRate);

        breathHp.setHighpass(800f, 0.7f, sampleRate);
        breathLp.setLowpass(5200f, 0.7f, sampleRate);

        pitchShifter.setRatio((float) Math.pow(2.0, pitch / 12.0));
    }

    /* ------------------------------------------------------------------ */
    /* main block processing                                               */
    /* ------------------------------------------------------------------ */
    public void process(short[] in, int n, short[] out) {
        final boolean hasPitch = Math.abs(pitch) > 0.05f;
        pitchShifter.setRatio((float) Math.pow(2.0, pitch / 12.0));

        final float tremInc = (float) (2 * Math.PI * tremolo / sampleRate);
        final float ringInc = (float) (2 * Math.PI * ringHz / sampleRate);
        final float tremDepth = tremolo > 0.1f ? 0.5f : 0f;
        final float ringGain = Math.min(1f, ringMix / 100f);
        final int echoSamples = Math.max(1, (int) (echoMs * sampleRate / 1000f));
        final float echoFb = echoMs > 25 ? 0.33f : 0f;
        final float echoWet = Math.min(1f, echoMix / 100f) * 0.8f;
        final float breathAmt = Math.min(1f, breath / 100f);
        final float driveK = 1f + Math.min(1f, distortion / 100f) * 6f;

        // reverb mix from the preset "size"
        final float revWet = Math.min(1f, reverbMix / 100f) * 0.9f;
        final int combFeedbackQ = (int) (Math.max(0.55f, Math.min(0.86f, 0.55f + reverb / 100f * 0.31f)) * 1000f);

        float noiseAmt = Math.min(1f, noise / 100f) * 0.45f;
        float envAttack = 1f - (float) Math.exp(-1.0 / (0.004f * sampleRate));
        float envRelease = 1f - (float) Math.exp(-1.0 / (0.09f * sampleRate));

        final float masterGain = Math.max(0.05f, Math.min(2f, gain));
        float peak = 0f;

        for (int i = 0; i < n; i++) {
            float x = in[i] * (1f / 32768f);

            /* envelope follower for the noise gate / -- */
            float ax = Math.abs(x);
            env += (ax > env ? envAttack : envRelease) * (ax - env);

            lastIn = x;

            /* tone: HP -> drive -> LP */
            float s = hp.process(x);
            if (distortion > 0.5f) {
                float d = s * driveK;
                s = (float) (Math.tanh(d) / Math.tanh(driveK * 0.7 + 0.3));
            }
            s = lp.process(s);

            /* formant */
            s = formantLow.process(s);
            s = formantHigh.process(s);

            /* pitch */
            if (hasPitch) {
                s = pitchShifter.process(s) * (1f + Math.min(0.4f, Math.abs(pitch) * 0.012f));
            }

            /* tremolo */
            if (tremDepth > 0f) {
                tremPhase += tremInc;
                if (tremPhase > 6.2831853) tremPhase -= 6.2831853;
                s *= (1f - tremDepth) + tremDepth * (float) Math.cos(tremPhase);
            }

            /* breath: band-passed noise following the voice envelope */
            if (breathAmt > 0f) {
                float nz = (float) (Math.random() * 2 - 1) * 0.35f;
                float b = breathLp.process(breathHp.process(nz));
                s += b * breathAmt * 0.9f * Math.min(1f, env * 9f);
            }

            /* ring modulation */
            if (ringGain > 0.01f) {
                ringPhase += ringInc;
                if (ringPhase > 6.2831853) ringPhase -= 6.2831853;
                float mod = (float) Math.sin(ringPhase);
                s = s * (1f - ringGain) + (s * mod) * ringGain * 1.25f;
            }

            /* echo */
            if (echoWet > 0.01f) {
                int r = echoW - echoSamples;
                if (r < 0) r += echoBuf.length;
                float e = echoBuf[r];
                echoBuf[echoW] = s + e * echoFb;
                echoW++;
                if (echoW >= echoBuf.length) echoW = 0;
                s = s + e * echoWet;
            }

            /* reverb */
            if (revWet > 0.01f) {
                s = s + reverb(s, combFeedbackQ / 1000f) * revWet;
            }

            /* radio crackle */
            if (noiseAmt > 0f) {
                float gate = env > 0.006f ? Math.min(1f, 0.2f + env * 7f) : 0f;
                s += (float) (Math.random() * 2 - 1) * noiseAmt * gate * 0.5f;
            }

            /* robot effect: sample-and-hold ring at a fixed rate */
            if (robot > 0.5f) {
                robotAcc += robotStep;
                if (robotAcc >= 1f) { robotAcc -= 1f; robotHold = s; }
                float rm = Math.min(1f, robot / 100f);
                s = s * (1f - rm) + robotHold * rm;
            }

            /* dry blend (unity path) + output gain */
            s = s * (1f - dryMix) + x * dryMix;
            s *= masterGain;

            if (s > 1f) s = 1f; else if (s < -1f) s = -1f;
            out[i] = (short) (s * 32767f);
            float av = s < 0 ? -s : s;
            if (av > peak) peak = av;
        }
        lastPeak = peak;
    }

    private float robotHold = 0f;
    private float robotAcc = 0f;
    private final float robotStep = 1f / 70f; // ~70 Hz sample & hold

    /* ------------------------------------------------------------------ */
    private float reverb(float x, float feedback) {
        float sum = 0f;
        for (int i = 0; i < 4; i++) {
            float[] buf = combs[i];
            int idx = combIdx[i];
            float y = buf[idx];
            combDamp[i] = y * 0.75f + combDamp[i] * 0.25f;
            buf[idx] = x * 0.25f + combDamp[i] * feedback;
            if (++idx >= buf.length) idx = 0;
            combIdx[i] = idx;
            sum += y;
        }
        float v = sum * 0.25f;
        /* allpass diffusion */
        for (int i = 0; i < 2; i++) {
            float[] buf = allpass[i];
            int idx = apIdx[i];
            float buffered = buf[idx];
            float y = -v + buffered;
            buf[idx] = v + buffered * 0.5f;
            if (++idx >= buf.length) idx = 0;
            apIdx[i] = idx;
            v = y;
        }
        return v;
    }

    /* ================================================================== */
    /* Doppler (granular) pitch shifter                                    */
    /* ================================================================== */
    static final class Doppler {
        private final float[] buf;
        private final int size, mask, half;
        private int w = 0;
        private float delay;
        private float ratio = 1f;
        private boolean bypass = true;

        Doppler(int sampleRate, int sizePow2) {
            this.size = sizePow2;
            this.mask = sizePow2 - 1;
            this.half = sizePow2 >> 1;
            this.buf = new float[sizePow2];
            this.delay = sizePow2 * 0.25f;
        }

        void setRatio(float r) {
            if (r < 0.25f) r = 0.25f; else if (r > 4f) r = 4f;
            ratio = r;
            bypass = Math.abs(r - 1f) < 0.0008f;
        }

        private float read(float d) {
            float pos = w - d;
            if (pos < 0) pos += size;
            int i = (int) pos;
            float f = pos - i;
            float a = buf[i & mask];
            float b = buf[(i + 1) & mask];
            return a + (b - a) * f;
        }

        float process(float x) {
            buf[w] = x;
            float out;
            if (bypass) {
                out = read(half);
            } else {
                float d = delay;
                if (d >= size) d -= size; else if (d < 0) d += size;

                float ph = d / size;
                float s = (float) Math.sin(Math.PI * ph);
                float gA = s * s;
                float gB = 1f - gA;

                float dA = d + 1.5f;
                float dB = d + half;
                if (dB >= size) dB -= size;
                dB += 1.5f;

                out = read(dA) * gA + read(dB) * gB;
                delay += 1f - ratio;
            }
            w = (w + 1) & mask;
            return out;
        }
    }

    /* ================================================================== */
    /* Biquad (RBJ cookbook)                                               */
    /* ================================================================== */
    static final class Biquad {
        private float b0 = 1, b1, b2, a1, a2;
        private float x1, x2, y1, y2;

        void setHighpass(float f, float q, int sr) {
            float w0 = (float) (2 * Math.PI * f / sr);
            float cos = (float) Math.cos(w0);
            float alpha = (float) Math.sin(w0) / (2 * q);
            float a0 = 1 + alpha;
            b0 = (1 + cos) / 2 / a0;
            b1 = -(1 + cos) / a0;
            b2 = b0;
            a1 = -2 * cos / a0;
            a2 = (1 - alpha) / a0;
        }

        void setLowpass(float f, float q, int sr) {
            float w0 = (float) (2 * Math.PI * f / sr);
            float cos = (float) Math.cos(w0);
            float alpha = (float) Math.sin(w0) / (2 * q);
            float a0 = 1 + alpha;
            b0 = (1 - cos) / 2 / a0;
            b1 = (1 - cos) / a0;
            b2 = b0;
            a1 = -2 * cos / a0;
            a2 = (1 - alpha) / a0;
        }

        void setLowShelf(float f, float gainDb, int sr) {
            float A = (float) Math.pow(10, gainDb / 40);
            float w0 = (float) (2 * Math.PI * f / sr);
            float cos = (float) Math.cos(w0);
            float sin = (float) Math.sin(w0);
            float alpha = sin / (float) (2 * Math.sqrt(2) / 2);
            float beta = 2 * (float) Math.sqrt(A) * alpha;
            float a0 = (A + 1) + (A - 1) * cos + beta;
            b0 = A * ((A + 1) - (A - 1) * cos + beta) / a0;
            b1 = 2 * A * ((A - 1) - (A + 1) * cos) / a0;
            b2 = A * ((A + 1) - (A - 1) * cos - beta) / a0;
            a1 = -2 * ((A - 1) + (A + 1) * cos) / a0;
            a2 = ((A + 1) + (A - 1) * cos - beta) / a0;
        }

        void setHighShelf(float f, float gainDb, int sr) {
            float A = (float) Math.pow(10, gainDb / 40);
            float w0 = (float) (2 * Math.PI * f / sr);
            float cos = (float) Math.cos(w0);
            float sin = (float) Math.sin(w0);
            float alpha = sin / (float) (2 * Math.sqrt(2) / 2);
            float beta = 2 * (float) Math.sqrt(A) * alpha;
            float a0 = (A + 1) - (A - 1) * cos + beta;
            b0 = A * ((A + 1) + (A - 1) * cos + beta) / a0;
            b1 = -2 * A * ((A - 1) + (A + 1) * cos) / a0;
            b2 = A * ((A + 1) + (A - 1) * cos - beta) / a0;
            a1 = 2 * ((A - 1) - (A + 1) * cos) / a0;
            a2 = ((A + 1) - (A - 1) * cos - beta) / a0;
        }

        float process(float x) {
            float y = b0 * x + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2;
            x2 = x1; x1 = x;
            y2 = y1; y1 = y;
            return y;
        }
    }

    /* ================================================================== */
    /* presets                                                             */
    /* ================================================================== */
    public static final String[] PRESET_IDS = {
            "original", "deep", "deeper", "chipmunk", "robot", "alien",
            "radio", "phone", "ghost", "monster", "drone", "creature", "android"
    };

    public static final String[] PRESET_LABELS = {
            "Оригинал", "Глубокий", "Демон", "Бурундук", "Робот", "Пришелец",
            "Рация", "Телефон", "Призрак", "Монстр", "Гул", "Существо", "Андроид"
    };

    public static final String[] PRESET_TAGS = {
            "Без эффектов", "Солидный баритон", "Максимально низко", "Высоко и быстро",
            "Синтетический голос", "Космос и модуляция", "Узкая полоса", "Как из трубки",
            "Шёпот из тумана", "Глубоко и злобно", "Плоский футуризм", "Нереальный тембр", "Гладкая машина"
    };

    /** Applies the built-in preset (cols: pitch, formant, robot, breath, ringMix, echo, reverb, lowcut, highcut, dist, trem, noise, gain) */
    public void applyPreset(String id) {
        switch (id) {
            case "deep":     set(-4, -3, 0, 0, 0, 0, 40, 70, 15000, 0, 0, 0, 1.1f); break;
            case "deeper":   set(-10, -7, 0, 0, 18, 0, 65, 50, 9000, 14, 0, 0, 1.15f); break;
            case "chipmunk": set(8, 5, 0, 0, 0, 0, 22, 120, 16000, 0, 0, 0, 1.05f); break;
            case "robot":    set(0, 0, 100, 0, 0, 0, 0, 90, 7000, 8, 0, 0, 1.1f); break;
            case "alien":    set(5, 4, 0, 0, 55, 220, 55, 150, 12000, 4, 9, 0, 1f); break;
            case "radio":    set(0, 0, 18, 0, 0, 0, 0, 450, 3200, 22, 0, 16, 1.5f); break;
            case "phone":    set(0, 0, 0, 0, 0, 0, 0, 380, 3400, 10, 0, 4, 1.6f); break;
            case "ghost":    set(-2, 2, 0, 42, 30, 320, 80, 140, 8000, 0, 6, 8, 1.1f); break;
            case "monster":  set(-8, -9, 12, 20, 22, 0, 45, 60, 7000, 26, 3, 6, 1.1f); break;
            case "drone":    set(-2, 0, 55, 0, 40, 0, 40, 80, 9000, 12, 4, 0, 1.05f); break;
            case "creature": set(3, -5, 0, 10, 34, 120, 40, 70, 11000, 18, 5, 0, 1.05f); break;
            case "android":  set(-1, 1, 34, 0, 8, 0, 30, 110, 8000, 4, 2, 0, 1.1f); break;
            case "original":
            default:         set(0, 0, 0, 0, 0, 0, 0, 70, 16000, 0, 0, 0, 1f); break;
        }
        updateFilters();
    }

    private void set(float pitch, float formant, float robot, float breath, float ringMix,
                     float echo, float reverb, float lowcut, float highcut, float dist,
                     float trem, float noise, float gain) {
        this.pitch = pitch;
        this.formant = formant;
        this.robot = robot;
        this.breath = breath;
        this.ringMix = ringMix;
        this.echoMs = echo;
        this.echoMix = echo > 0 ? Math.min(45f, echo * 0.12f) : 0f;
        this.reverb = reverb;
        this.reverbMix = Math.min(90f, reverb * 0.65f);
        this.lowcut = lowcut;
        this.highcut = highcut;
        this.distortion = dist;
        this.tremolo = trem;
        this.noise = noise;
        this.gain = gain;
        this.ringHz = 1.1f;
        this.dryMix = 0f;
    }

    /** peak level of the last processed block, for UI meters (0..1) */
    public float lastPeak = 0f;
}
