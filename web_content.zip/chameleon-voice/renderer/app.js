/* ============================================================
   Chameleon Voice — application controller
   ============================================================ */
(function () {
  'use strict';

  const DSP = window.ChameleonDSP;
  const STORE_KEY = 'chameleon.settings.v1';

  const $ = (sel, root) => (root || document).querySelector(sel);
  const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const round1 = (v) => Math.round(v * 10) / 10;

  const safeGet = (k) => { try { return localStorage.getItem(k); } catch { return null; } };
  const safeSet = (k, v) => { try { localStorage.setItem(k, v); } catch {} };
  const safeRemove = (k) => { try { localStorage.removeItem(k); } catch {} };

  const SLIDER_GROUPS = {
    voice: ['pitch', 'formant', 'robot', 'breath'],
    space: ['ring', 'ringMix', 'echo', 'echoMix', 'reverb', 'reverbMix'],
    tone: ['lowcut', 'highcut', 'distortion', 'tremolo', 'noise', 'gain']
  };

  /* ------------------------------------------------------------ state */
  const state = {
    preset: 'original',
    params: { ...PRESETS.original, dryMix: 0 },
    powered: false,
    micId: '',
    outId: '',
    mode: 'speakers',
    monitor: true,
    latency: 1024,
    customPresets: {},
    recordings: [],
    devices: { mics: [], outputs: [] }
  };

  const audio = {
    ctx: null,
    chain: null,
    chain2: null,
    micStream: null,
    src: null,
    dest: null,
    ready: false
  };

  let rafId = 0;
  let analyserSrc = null;

  /* ------------------------------------------------------------ storage */
  function loadStore() {
    try {
      const raw = safeGet(STORE_KEY);
      return raw ? JSON.parse(raw) : {};
    } catch { return {}; }
  }

  function saveStore() {
    const data = {
      params: state.params,
      preset: state.preset,
      micId: state.micId,
      outId: state.outId,
      mode: state.mode,
      monitor: state.monitor,
      latency: state.latency,
      customPresets: state.customPresets,
      powered: state.powered
    };
    safeSet(STORE_KEY, JSON.stringify(data));
    if (window.chameleon && window.chameleon.saveSettings) {
      window.chameleon.saveSettings(data);
    }
  }

  function restoreStore() {
    const data = loadStore();
    if (data.customPresets) state.customPresets = data.customPresets;
    if (data.params) state.params = { ...state.params, ...data.params };
    if (data.preset) state.preset = data.preset;
    if (data.micId) state.micId = data.micId;
    if (data.outId) state.outId = data.outId;
    if (data.mode) state.mode = data.mode;
    if (typeof data.monitor === 'boolean') state.monitor = data.monitor;
    if (data.latency) state.latency = data.latency;
    state.powered = false; // always start switched off for safety
  }

  /* ------------------------------------------------------------ toasts */
  function toast(text, kind) {
    const el = document.createElement('div');
    el.className = 'toast' + (kind ? ' ' + kind : '');
    el.textContent = text;
    $('#toasts').appendChild(el);
    setTimeout(() => {
      el.style.transition = 'opacity .3s, transform .3s';
      el.style.opacity = '0';
      el.style.transform = 'translateY(6px)';
      setTimeout(() => el.remove(), 320);
    }, 3000);
  }

  /* ------------------------------------------------------------ modal */
  function openModal(html) {
    $('#modal').innerHTML = html;
    $('#modalBack').classList.add('show');
    return $('#modal');
  }
  function closeModal() { $('#modalBack').classList.remove('show'); }
  $('#modalBack').addEventListener('click', (e) => {
    if (e.target.id === 'modalBack') closeModal();
  });

  /* ------------------------------------------------------------ view switching */
  function switchView(name) {
    $$('.nav-item').forEach(b => b.classList.toggle('active', b.dataset.view === name));
    $$('.view').forEach(v => v.classList.toggle('active', v.id === 'view-' + name));
    const titles = {
      studio: ['Студия голоса', 'Выберите пресет или настройте параметры вручную'],
      guide: ['Подключение', 'Виртуальный микрофон для игр, Discord и звонков'],
      settings: ['Настройки', 'Горячие клавиши, данные и информация о приложении']
    };
    $('#pageTitle').textContent = titles[name][0];
    $('#pageSub').textContent = titles[name][1];
    if (name === 'guide') renderCables();
  }

  $$('.nav-item').forEach(btn => btn.addEventListener('click', () => switchView(btn.dataset.view)));
  $$('[data-go]').forEach(btn => btn.addEventListener('click', () => switchView(btn.dataset.go)));

  /* ------------------------------------------------------------ audio engine */
  function ensureContext() {
    if (audio.ctx) return audio.ctx;
    const Ctx = window.AudioContext || window.webkitAudioContext;
    audio.ctx = new Ctx({ latencyHint: 'interactive' });
    return audio.ctx;
  }

  function buildChain() {
    const ctx = ensureContext();
    if (!audio.chain) {
      audio.chain = new DSP.VoiceChain(ctx);
      audio.chain.setLatency(state.latency);
      audio.chain.update(state.params, true);
    }
    return audio.chain;
  }

  async function listDevices() {
    if (!navigator.mediaDevices || !navigator.mediaDevices.enumerateDevices) {
      renderDevices();
      return;
    }
    try {
      const devices = await navigator.mediaDevices.enumerateDevices();
      state.devices.mics = devices.filter(d => d.kind === 'audioinput');
      state.devices.outputs = devices.filter(d => d.kind === 'audiooutput');
      renderDevices();
    } catch {
      renderDevices();
    }
  }

  function fillSelect(sel, items, selected, fallbackLabel) {
    sel.innerHTML = '';
    const seen = new Set();
    items.forEach((d, i) => {
      const id = d.deviceId || '';
      if (id && seen.has(id)) return;
      seen.add(id);
      const opt = document.createElement('option');
      opt.value = id;
      opt.textContent = d.label || `${fallbackLabel} ${i + 1}`;
      if (id === selected) opt.selected = true;
      sel.appendChild(opt);
    });
    if (!items.length) {
      const opt = document.createElement('option');
      opt.value = '';
      opt.textContent = 'Устройства не найдены';
      sel.appendChild(opt);
    }
    if (selected && !seen.has(selected)) sel.selectedIndex = 0;
  }

  function renderDevices() {
    const mics = state.devices.mics;
    const outs = state.devices.outputs;

    fillSelect($('#micSelect'), mics, state.micId, 'Микрофон');
    // virtual cable first, then outputs
    const sorted = outs.slice().sort((a, b) => {
      const va = /cable|virtual|blackhole|voicemeeter|line/i.test(a.label || '') ? 0 : 1;
      const vb = /cable|virtual|blackhole|voicemeeter|line/i.test(b.label || '') ? 0 : 1;
      return va - vb;
    });
    fillSelect($('#outSelect'), sorted, state.outId, 'Выход');

    const micLabel = (mics.find(m => m.deviceId === state.micId) || {}).label;
    $('#chipInputName').textContent = micLabel ? shorten(micLabel) : 'не выбран';
    const outSel = $('#outSelect');
    const outLabel = outSel.selectedOptions[0] ? outSel.selectedOptions[0].textContent : '—';
    $('#chipOutName').textContent = shorten(outLabel);

    $('#chipInput').classList.toggle('on', !!state.micId);
    $('#chipOut').classList.toggle('on', !!outLabel && outLabel !== '—');
    updateRoutingHint(outLabel, true, isVirtualLabel(outLabel));

    if (!mics.length) {
      $('#micError').classList.add('show');
    }
  }

  function shorten(s, n) {
    const max = n || 26;
    return s.length > max ? s.slice(0, max - 1) + '…' : s;
  }

  async function refreshMicPermission() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      stream.getTracks().forEach(t => t.stop());
      $('#micError').classList.remove('show');
    } catch {
      $('#micError').classList.add('show');
    }
    await listDevices();
  }

  async function startAudio() {
    const ctx = ensureContext();
    try {
      await ctx.resume();
    } catch {}

    let constraints;
    if (state.micId) {
      constraints = { audio: { deviceId: { exact: state.micId }, echoCancellation: false, noiseSuppression: false, autoGainControl: false } };
    } else {
      constraints = { audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false } };
    }

    try {
      audio.micStream = await navigator.mediaDevices.getUserMedia(constraints);
      $('#micError').classList.remove('show');
    } catch (err) {
      try {
        audio.micStream = await navigator.mediaDevices.getUserMedia({ audio: true });
        $('#micError').classList.remove('show');
      } catch (err2) {
        $('#micError').classList.add('show');
        toast('Микрофон недоступен. Разрешите доступ к микрофону.', 'err');
        throw err2;
      }
    }

    const track = audio.micStream.getAudioTracks()[0];
    const settings = (track && track.getSettings) ? track.getSettings() : {};
    if (!state.micId && settings.deviceId) {
      state.micId = settings.deviceId;
    }

    const chain = buildChain();
    audio.src = ctx.createMediaStreamSource(audio.micStream);
    chain.setSource(audio.src);
    chain.setLatency(state.latency);
    chain.update(state.params, true);

    // ensure monitoring state
    setMonitor(state.monitor);
    await listDevices();
    if (state.outId) await attachOutput(state.outId);
    return true;
  }

  function stopAudio() {
    if (audio.src) {
      try { audio.src.disconnect(); } catch {}
      audio.src = null;
    }
    if (audio.micStream) {
      audio.micStream.getTracks().forEach(t => t.stop());
      audio.micStream = null;
    }
  }

  /* ------------------------------------------------------------ power */
  async function togglePower(force) {
    const target = typeof force === 'boolean' ? force : !state.powered;
    if (target === state.powered) return;

    if (target) {
      try {
        await startAudio();
      } catch (err) {
        console.warn('[chameleon] start failed:', err);
        toast('Не удалось запустить обработку звука. Проверьте микрофон.', 'err');
        return;
      }
      state.powered = true;
    } else {
      stopAudio();
      state.powered = false;
    }
    updatePowerUI();
    saveStore();
  }

  function updatePowerUI() {
    $('#powerBtn').classList.toggle('on', state.powered);
    $('#powerLabel').textContent = state.powered ? 'Выключить' : 'Включить';
    $('#chipInput').classList.toggle('on', state.powered && !!state.micId);
    document.body.classList.toggle('live', state.powered);
  }

  function setMonitor(on) {
    state.monitor = on;
    ['#monitorSwitch', '#monitorSwitchTop'].forEach(sel => {
      const el = $(sel);
      if (el) el.classList.toggle('on', on);
    });
    if (!audio.chain) return;

    if (audio.needMonitorEl && audio.monitorEl) {
      // virtual cable is the output: play a separate local monitor to headphones/speakers
      audio.monitorEl.muted = !on;
      if (on) audio.monitorEl.play().catch(() => {});
      audio.chain.setOutputEnabled(true);
    } else {
      // ordinary output device: just mute the context path
      audio.chain.setOutputEnabled(on);
    }
  }

  /* ------------------------------------------------------------ presets */
  function allPresets() {
    return { ...PRESETS, ...state.customPresets };
  }

  function applyPreset(id, silent) {
    const p = allPresets()[id];
    if (!p) return;
    state.preset = id;
    const params = {};
    Object.keys(PRESETS.original).forEach(k => { params[k] = p[k] !== undefined ? p[k] : PRESETS.original[k]; });
    params.dryMix = p.dryMix || 0;
    state.params = params;
    syncControls();
    if (audio.chain) audio.chain.update(state.params);
    updateStage();
    renderPresets();
    if (!silent) saveStore();
  }

  function applyParam(key, value, silent) {
    state.params[key] = value;
    state.preset = null;
    if (audio.chain) audio.chain.update(state.params);
    syncSliderValue(key, value);
    updateStage();
    $$('.preset-card').forEach(c => c.classList.remove('active'));
    $('.quick-btn') && $$('.quick-btn').forEach(b => b.classList.remove('active'));
    if (!silent) saveStore();
  }

  function renderPresets() {
    const grid = $('#presetGrid');
    grid.innerHTML = '';
    const presets = allPresets();
    const ids = [...PRESET_ORDER, ...Object.keys(state.customPresets).filter(k => !PRESET_ORDER.includes(k))];
    ids.forEach(id => {
      const p = presets[id];
      if (!p) return;
      const btn = document.createElement('button');
      btn.className = 'preset-card' + (state.preset === id ? ' active' : '');
      btn.dataset.preset = id;
      btn.innerHTML = `<span class="ico">${p.icon || '🎚️'}</span>
        <span style="min-width:0">
          <span class="p-name">${escapeHtml(p.label)}</span>
          <span class="p-tag">${escapeHtml(p.tag || '')}</span>
        </span>`;
      btn.addEventListener('click', () => {
        applyPreset(id);
        toast(`Пресет: ${p.label}`);
      });
      btn.addEventListener('contextmenu', (e) => {
        if (!state.customPresets[id]) return;
        e.preventDefault();
        if (confirm(`Удалить пресет «${p.label}»?`)) {
          delete state.customPresets[id];
          state.preset = 'original';
          applyPreset('original');
          toast('Пресет удалён', 'info');
        }
      });
      grid.appendChild(btn);
    });
    $('#presetCount').textContent = ids.length + ' шт.';
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  function updateStage() {
    const presets = allPresets();
    const p = state.preset ? presets[state.preset] : null;
    $('#stageEmoji').textContent = p ? p.icon : '🎛️';
    $('#stagePresetName').textContent = p ? p.label : 'Своя настройка';
    $('#stagePresetTag').textContent = p ? p.tag : 'Ручная настройка параметров';
  }

  /* ------------------------------------------------------------ sliders */
  function buildSliders() {
    const groups = { voice: $('#slidersVoice'), space: $('#slidersSpace'), tone: $('#slidersTone') };
    Object.keys(groups).forEach(g => { groups[g].innerHTML = ''; });

    SLIDERS.forEach(s => {
      const group = Object.keys(SLIDER_GROUPS).find(g => SLIDER_GROUPS[g].includes(s.key));
      const row = document.createElement('div');
      row.className = 'slider-row';
      row.innerHTML = `
        <div class="slider-top">
          <label for="sl-${s.key}">${s.label}</label>
          <output id="out-${s.key}">${s.fmt(state.params[s.key])}</output>
        </div>
        <input type="range" id="sl-${s.key}" min="${s.min}" max="${s.max}" step="${s.step}"
               value="${state.params[s.key]}" />
      `;
      const input = row.querySelector('input');
      input.addEventListener('input', () => {
        const v = parseFloat(input.value);
        applyParam(s.key, v);
      });
      groups[group].appendChild(row);
    });
    syncControls();
  }

  function syncSliderValue(key, value) {
    const input = $('#sl-' + key);
    const out = $('#out-' + key);
    if (input) input.value = value;
    const def = SLIDERS.find(s => s.key === key);
    if (out && def) out.textContent = def.fmt(value);
    paintSlider(input);
  }

  function paintSlider(input) {
    if (!input) return;
    const min = parseFloat(input.min), max = parseFloat(input.max);
    const pct = ((parseFloat(input.value) - min) / (max - min)) * 100;
    input.style.setProperty('--p', pct.toFixed(1) + '%');
  }

  function syncControls() {
    SLIDERS.forEach(s => {
      const input = $('#sl-' + s.key);
      const out = $('#out-' + s.key);
      if (input) { input.value = state.params[s.key]; paintSlider(input); }
      if (out) out.textContent = s.fmt(state.params[s.key]);
    });
    // quick buttons
    $$('.quick-btn').forEach(b => b.classList.toggle('active', b.dataset.preset === state.preset));
    // toggles
    ['#monitorSwitch', '#monitorSwitchTop'].forEach(sel => { const el = $(sel); if (el) el.classList.toggle('on', state.monitor); });
    $$('#qualitySeg button').forEach(b => b.classList.toggle('active', Number(b.dataset.q) === state.latency));
    $('#qualityHint').textContent = state.latency === 512 ? '≈12 мс · минимум задержки, чуть больше артефактов'
      : state.latency === 2048 ? '≈53 мс · максимум качества, для записей'
      : '≈26 мс · подходит для игр и звонков';
  }

  function buildQuickRow() {
    const row = $('#quickRow');
    row.innerHTML = '';
    QUICK_EFFECTS.forEach(q => {
      const btn = document.createElement('button');
      btn.className = 'quick-btn';
      btn.dataset.preset = q.id;
      btn.innerHTML = `<span>${q.icon}</span>${q.label}`;
      btn.addEventListener('click', () => { applyPreset(q.id); syncControls(); });
      row.appendChild(btn);
    });
  }

  /* ------------------------------------------------------------ events */
  $('#powerBtn').addEventListener('click', () => togglePower());

  $('#micSelect').addEventListener('change', async (e) => {
    state.micId = e.target.value;
    saveStore();
    if (state.powered) {
      stopAudio();
      try { await startAudio(); } catch { state.powered = false; updatePowerUI(); }
    }
    renderDevices();
    toast('Микрофон переключён');
  });

  $('#outSelect').addEventListener('change', async (e) => {
    state.outId = e.target.value;
    saveStore();
    renderDevices();
    await attachOutput(e.target.value);
    toast('Выход переключён');
  });

  $('#refreshDevicesBtn').addEventListener('click', async () => {
    await refreshMicPermission();
    toast('Список устройств обновлён', 'info');
  });

  ['#monitorSwitch', '#monitorSwitchTop'].forEach(sel => {
    const el = $(sel);
    if (el) el.addEventListener('click', () => { setMonitor(!state.monitor); saveStore(); });
  });

  $$('#qualitySeg button').forEach(btn => btn.addEventListener('click', () => {
    state.latency = Number(btn.dataset.q);
    if (audio.chain) audio.chain.setLatency(state.latency);
    syncControls();
    saveStore();
    toast('Задержка: ' + $('#qualityHint').textContent.split('·')[0].trim(), 'info');
  }));

  $$('#sliderTabs .tab-btn').forEach(btn => btn.addEventListener('click', () => {
    $$('#sliderTabs .tab-btn').forEach(b => b.classList.toggle('active', b === btn));
    const g = btn.dataset.group;
    $('#slidersVoice').style.display = g === 'voice' ? 'grid' : 'none';
    $('#slidersSpace').style.display = g === 'space' ? 'grid' : 'none';
    $('#slidersTone').style.display = g === 'tone' ? 'grid' : 'none';
  }));

  $('#resetPresetBtn').addEventListener('click', () => {
    applyPreset('original');
    toast('Сброшено к оригиналу');
  });

  $('#randomBtn').addEventListener('click', () => {
    const keys = Object.keys(PRESETS.original);
    const params = {};
    keys.forEach(k => {
      const def = SLIDERS.find(s => s.key === k);
      params[k] = def ? def.min + Math.random() * (def.max - def.min) : PRESETS.original[k];
    });
    // tame the chaos a bit
    params.gain = 1 + Math.random() * 0.3;
    params.pitch = round1(-8 + Math.random() * 16);
    params.formant = round1(-8 + Math.random() * 16);
    params.robot = Math.random() < 0.5 ? 0 : Math.round(Math.random() * 60);
    params.breath = Math.random() < 0.6 ? 0 : Math.round(Math.random() * 45);
    params.echo = Math.random() < 0.6 ? 0 : Math.round(Math.random() * 400 / 10) * 10;
    params.echoMix = params.echo ? Math.round(Math.random() * 40) : 0;
    params.reverbMix = Math.round(Math.random() * 40);
    params.reverb = 30 + Math.round(Math.random() * 60);
    params.ringMix = Math.random() < 0.5 ? 0 : Math.round(Math.random() * 50);
    params.distortion = Math.round(Math.random() * 35);
    state.params = { ...state.params, ...params };
    state.preset = null;
    SLIDERS.forEach(s => syncSliderValue(s.key, state.params[s.key]));
    if (audio.chain) audio.chain.update(state.params);
    $$('.preset-card').forEach(c => c.classList.remove('active'));
    $$('.quick-btn').forEach(b => b.classList.remove('active'));
    updateStage();
    saveStore();
    toast('Случайная настройка 🎲', 'info');
  });

  $('#savePresetBtn').addEventListener('click', () => {
    const modal = openModal(`
      <h3>Сохранить как пресет</h3>
      <p>Текущие настройки станут доступны в списке пресетов этого приложения.</p>
      <div class="field-label">Название</div>
      <div class="select-wrap" style="margin-bottom:10px">
        <input id="presetNameInput" placeholder="Например, Злодей" maxlength="24"
          style="width:100%;padding:10px 11px;border-radius:10px;border:1px solid var(--line);background:rgba(9,14,22,.9);color:var(--text);font-size:13px;outline:none" />
      </div>
      <div class="field-label">Иконка</div>
      <div class="row-inline" id="emojiPick" style="flex-wrap:wrap">
        ${['🎭', '😈', '🐸', '🦇', '🐺', '🦄', '🧛', '🧙', '🛸', '💀', '🎃', '🎤'].map((e, i) =>
          `<button class="icon-btn" data-emoji="${e}" style="font-size:15px;${i === 0 ? 'border-color:rgba(62,224,166,.5)' : ''}">${e}</button>`).join('')}
      </div>
      <div class="row-inline">
        <button class="btn" data-close>Отмена</button>
        <button class="btn primary" id="presetSaveOk">Сохранить</button>
      </div>
    `);

    let emoji = '🎭';
    $$('#emojiPick .icon-btn', modal).forEach(b => b.addEventListener('click', () => {
      emoji = b.dataset.emoji;
      $$('#emojiPick .icon-btn', modal).forEach(x => x.style.borderColor = 'var(--line)');
      b.style.borderColor = 'rgba(62,224,166,.5)';
    }));
    const input = $('#presetNameInput', modal);
    input.focus();
    modal.querySelector('[data-close]').addEventListener('click', closeModal);
    $('#presetSaveOk', modal).addEventListener('click', () => {
      const name = (input.value || '').trim();
      if (!name) { toast('Введите название', 'err'); return; }
      const id = 'custom_' + Date.now();
      state.customPresets[id] = {
        ...state.params,
        label: name,
        icon: emoji,
        tag: 'Свой пресет'
      };
      state.preset = id;
      renderPresets();
      saveStore();
      closeModal();
      toast(`Пресет «${name}» сохранён`);
    });
    input.addEventListener('keydown', e => { if (e.key === 'Enter') $('#presetSaveOk', modal).click(); });
  });

  /* ------------------------------------------------------------ recording */
  const rec = { recorder: null, chunks: [], started: 0, timer: 0, active: false, analyser: null };

  async function startRecording() {
    if (!audio.chain) {
      if (!state.powered) await togglePower(true);
      if (!audio.chain) return;
    }
    const stream = audio.chain.getMicStream();
    const mime = MediaRecorder.isTypeSupported('audio/webm;codecs=opus') ? 'audio/webm;codecs=opus' : '';
    try {
      rec.recorder = new MediaRecorder(stream, mime ? { mimeType: mime } : undefined);
    } catch (e) {
      toast('Запись не поддерживается в этой системе', 'err');
      return;
    }
    rec.chunks = [];
    rec.recorder.ondataavailable = (e) => { if (e.data && e.data.size) rec.chunks.push(e.data); };
    rec.recorder.onstop = () => {
      const blob = new Blob(rec.chunks, { type: 'audio/webm' });
      const url = URL.createObjectURL(blob);
      const item = { url, time: Date.now(), duration: (Date.now() - rec.started) / 1000 };
      state.recordings.unshift(item);
      if (state.recordings.length > 6) {
        const old = state.recordings.pop();
        URL.revokeObjectURL(old.url);
      }
      renderRecordings();
      const a = new Audio(url);
      a.volume = 0.9;
      a.play().catch(() => {});
    };
    rec.recorder.start();
    rec.started = Date.now();
    rec.active = true;
    $('#recLabel').textContent = 'Стоп';
    $('#recDot').classList.add('on');
    $('#recBtn').classList.add('danger');
    rec.timer = setInterval(() => {
      const s = Math.floor((Date.now() - rec.started) / 1000);
      $('#recTimer').textContent = String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0');
    }, 250);
  }

  function stopRecording() {
    if (rec.recorder && rec.recorder.state !== 'inactive') rec.recorder.stop();
    rec.active = false;
    clearInterval(rec.timer);
    $('#recLabel').textContent = 'Записать';
    $('#recDot').classList.remove('on');
    $('#recBtn').classList.remove('danger');
    $('#recTimer').textContent = '00:00';
  }

  $('#recBtn').addEventListener('click', () => {
    if (rec.active) stopRecording();
    else startRecording();
  });

  $('#playLastBtn').addEventListener('click', () => {
    if (!state.recordings.length) { toast('Пока нет записей', 'info'); return; }
    const a = new Audio(state.recordings[0].url);
    a.play().catch(() => toast('Не удалось воспроизвести', 'err'));
  });

  function renderRecordings() {
    const box = $('#recordings');
    box.innerHTML = '';
    state.recordings.forEach((r, i) => {
      const el = document.createElement('div');
      el.className = 'rec-item';
      const d = new Date(r.time);
      el.innerHTML = `
        <div class="rec-meta">
          <b>Запись ${state.recordings.length - i}</b>
          <span>${d.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })} · ${r.duration.toFixed(1)} с</span>
        </div>
        <button class="rec-del" title="Удалить">✕</button>
      `;
      el.querySelector('.rec-del').addEventListener('click', () => {
        URL.revokeObjectURL(r.url);
        state.recordings.splice(i, 1);
        renderRecordings();
      });
      box.appendChild(el);
    });
  }

  /* ------------------------------------------------------------ guide */
  function renderCables() {
    const grid = $('#cableGrid');
    if (grid.dataset.rendered) return;
    const platform = (window.chameleon && window.chameleon.platform) || navigator.platform.toLowerCase().includes('mac') ? 'mac' : 'win';
    const plat = (window.chameleon && window.chameleon.platform) || (navigator.userAgent.includes('Mac') ? 'mac' : navigator.userAgent.includes('Linux') ? 'linux' : 'win');
    const items = CABLES.filter(c => c.os === plat);
    const list = items.length ? items : CABLES;
    grid.innerHTML = list.map(c => `
      <div class="cable-card">
        <h3>${escapeHtml(c.name)}</h3>
        <p>${escapeHtml(c.desc)}</p>
        <ol>${c.steps.map(s => `<li>${formatStep(s)}</li>`).join('')}</ol>
        <div class="row-inline">
          <button class="btn primary" data-url="${c.url}">Скачать</button>
          <button class="btn" data-copysteps="${escapeHtml(c.name)}">Скопировать шаги</button>
        </div>
      </div>
    `).join('');
    grid.dataset.rendered = '1';

    $$('[data-url]', grid).forEach(b => b.addEventListener('click', () => {
      if (window.chameleon && window.chameleon.openExternal) window.chameleon.openExternal(b.dataset.url);
      else window.open(b.dataset.url, '_blank');
    }));
    $$('[data-copysteps]', grid).forEach(b => b.addEventListener('click', () => {
      const card = b.closest('.cable-card');
      const text = card.querySelector('ol').innerText;
      navigator.clipboard.writeText(text).then(() => toast('Шаги скопированы')).catch(() => {});
    }));
  }

  function formatStep(s) {
    return escapeHtml(s).replace(/`([^`]+)`/g, '<code>$1</code>');
  }

  $('#openTestBtn').addEventListener('click', () => {
    const url = location.href.replace(/index\.html.*$/, 'test.html').replace(/\/$/, '/test.html');
    if (window.chameleon && window.chameleon.openExternal && url.startsWith('http')) {
      window.chameleon.openExternal(url);
    } else {
      window.open(url, '_blank');
    }
  });

  /* ------------------------------------------------------------ settings view */
  async function fillAbout() {
    $('#aboutRate').textContent = audio.ctx ? audio.ctx.sampleRate + ' Гц' : '—';
    if (window.chameleon) {
      try {
        const info = await window.chameleon.appInfo();
        $('#aboutVersion').textContent = 'v' + info.version;
        $('#aboutPlatform').textContent = info.platform + ' / ' + info.arch;
        $('#aboutElectron').textContent = info.electron;
        $('#aboutChrome').textContent = info.chrome;
        $('#buildVersion').textContent = 'v' + info.version;
      } catch {}
    } else {
      $('#aboutVersion').textContent = 'Web-версия';
      $('#aboutPlatform').textContent = navigator.platform;
      $('#aboutElectron').textContent = '—';
      $('#aboutChrome').textContent = (navigator.userAgent.match(/Chrome\/([\d.]+)/) || [])[1] || '—';
      $('#buildVersion').textContent = 'Web demo';
    }
  }

  $('#exportPresetsBtn').addEventListener('click', () => {
    const data = JSON.stringify({ presets: state.customPresets, params: state.params }, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'chameleon-presets.json';
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
    toast('Пресеты экспортированы');
  });

  $('#clearPresetsBtn').addEventListener('click', () => {
    if (!Object.keys(state.customPresets).length) { toast('Нет пользовательских пресетов', 'info'); return; }
    if (!confirm('Удалить все пользовательские пресеты?')) return;
    state.customPresets = {};
    applyPreset('original');
    toast('Пользовательские пресеты удалены');
  });

  $('#resetAllBtn').addEventListener('click', () => {
    if (!confirm('Сбросить все настройки приложения?')) return;
    safeRemove(STORE_KEY);
    location.reload();
  });

  /* ------------------------------------------------------------ hotkeys */
  document.addEventListener('keydown', (e) => {
    const mod = e.ctrlKey || e.metaKey;
    if (!mod) return;
    if (e.key.toLowerCase() === 'v' && e.shiftKey) {
      e.preventDefault();
      togglePower();
    } else if (e.key === 'ArrowRight') {
      e.preventDefault();
      stepPreset(1);
    } else if (e.key === 'ArrowLeft') {
      e.preventDefault();
      stepPreset(-1);
    } else if (e.key === '0') {
      e.preventDefault();
      applyPreset('original');
      toast('Сброшено к оригиналу');
    }
  });

  function stepPreset(dir) {
    const ids = PRESET_ORDER;
    const i = ids.indexOf(state.preset);
    const next = ids[(i + dir + ids.length) % ids.length];
    applyPreset(next);
    toast('Пресет: ' + allPresets()[next].label);
  }

  /* ------------------------------------------------------------ visualizer */
  const vis = { canvas: null, ctx: null, dpr: 1 };
  const recVis = { canvas: null, ctx: null };

  function setupCanvases() {
    vis.canvas = $('#visualizer');
    vis.ctx = vis.canvas.getContext('2d');
    recVis.canvas = $('#recCanvas');
    recVis.ctx = recVis.canvas.getContext('2d');
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);
  }

  function resizeCanvas() {
    if (!vis.canvas) return;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const rect = vis.canvas.getBoundingClientRect();
    vis.canvas.width = Math.max(1, Math.floor(rect.width * dpr));
    vis.canvas.height = Math.max(1, Math.floor(rect.height * dpr));
    vis.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    vis.dpr = dpr;

    const r2 = recVis.canvas.getBoundingClientRect();
    recVis.canvas.width = Math.max(1, Math.floor(r2.width * dpr));
    recVis.canvas.height = Math.max(1, Math.floor(r2.height * dpr));
    recVis.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  function drawIdle(t) {
    const c = vis.ctx, w = vis.canvas.clientWidth, h = vis.canvas.clientHeight;
    c.clearRect(0, 0, w, h);

    // grid
    c.strokeStyle = 'rgba(255,255,255,0.035)';
    c.lineWidth = 1;
    for (let x = 0; x < w; x += 32) {
      c.beginPath(); c.moveTo(x + .5, 0); c.lineTo(x + .5, h); c.stroke();
    }

    // static-ish harmonics
    const bars = Math.floor(w / 13);
    for (let i = 0; i < bars; i++) {
      const seed = Math.sin(i * 1.7) * Math.cos(i * 0.37 + t * 0.0002);
      const amp = 0.16 + Math.abs(seed) * 0.22;
      const bh = amp * h * 0.5;
      const x = i * 13 + 4;
      const y = h * 0.62 - bh;
      const g = c.createLinearGradient(0, y, 0, y + bh * 2);
      g.addColorStop(0, 'rgba(62,224,166,0.34)');
      g.addColorStop(0.5, 'rgba(51,214,240,0.22)');
      g.addColorStop(1, 'rgba(167,139,250,0.06)');
      c.fillStyle = g;
      roundRect(c, x, y, 6, bh * 2, 3);
      c.fill();
      roundRect(c, x, h * 0.62 + 6, 6, bh * 0.5, 3);
      c.fill();
    }

    // centre line
    c.strokeStyle = 'rgba(233,240,250,0.09)';
    c.beginPath(); c.moveTo(0, h * 0.62); c.lineTo(w, h * 0.62); c.stroke();
  }

  function roundRect(c, x, y, w, h, r) {
    const rr = Math.min(r, w / 2, h / 2);
    c.beginPath();
    c.moveTo(x + rr, y);
    c.arcTo(x + w, y, x + w, y + h, rr);
    c.arcTo(x + w, y + h, x, y + h, rr);
    c.arcTo(x, y + h, x, y, rr);
    c.arcTo(x, y, x + w, y, rr);
    c.closePath();
  }

  let lastMeter = 0;

  function drawActive(t) {
    const c = vis.ctx, w = vis.canvas.clientWidth, h = vis.canvas.clientHeight;
    c.clearRect(0, 0, w, h);

    const freq = audio.chain.getFrequencyData();
    const wave = audio.chain.getWaveformData();
    const bins = 56;
    const barW = w / bins;

    // --- spectrum ---
    for (let i = 0; i < bins; i++) {
      const from = Math.floor(Math.pow(i / bins, 1.7) * freq.length * 0.72);
      const to = Math.max(from + 1, Math.floor(Math.pow((i + 1) / bins, 1.7) * freq.length * 0.72));
      let sum = 0;
      for (let k = from; k < to; k++) sum += freq[k];
      const v = sum / (to - from) / 255;
      const bh = Math.max(2, Math.pow(v, 1.25) * h * 0.78);
      const x = i * barW + barW * 0.22;
      const bw = barW * 0.56;
      const y = h * 0.86 - bh;

      const g = c.createLinearGradient(0, y, 0, h * 0.86);
      g.addColorStop(0, 'rgba(62,224,166,0.95)');
      g.addColorStop(0.45, 'rgba(51,214,240,0.72)');
      g.addColorStop(1, 'rgba(167,139,250,0.22)');
      c.fillStyle = g;
      roundRect(c, x, y, bw, bh, bw / 2.4);
      c.fill();

      c.fillStyle = 'rgba(62,224,166,0.22)';
      roundRect(c, x, h * 0.86 + 4, bw, 3, 1.5);
      c.fill();
    }

    // --- waveform ---
    c.beginPath();
    c.lineWidth = 1.6;
    const grad = c.createLinearGradient(0, 0, w, 0);
    grad.addColorStop(0, 'rgba(51,214,240,0.0)');
    grad.addColorStop(0.2, 'rgba(51,214,240,0.75)');
    grad.addColorStop(0.8, 'rgba(167,139,250,0.75)');
    grad.addColorStop(1, 'rgba(167,139,250,0.0)');
    c.strokeStyle = grad;
    for (let i = 0; i < wave.length; i += 2) {
      const x = (i / wave.length) * w;
      const v = (wave[i] - 128) / 128;
      const y = h * 0.86 + v * h * 0.16;
      if (i === 0) c.moveTo(x, y); else c.lineTo(x, y);
    }
    c.stroke();

    // --- meters ---
    const now = performance.now();
    if (now - lastMeter > 33) {
      lastMeter = now;
      const m = audio.chain.readLevels();
      const inPct = clamp(m.inLevel * 220, 0, 100);
      const outPct = clamp(m.outLevel * 220, 0, 100);
      $('#inMeter').style.width = inPct + '%';
      $('#outMeter').style.width = outPct + '%';
      $('#outMeter').classList.toggle('clip', m.clip);
      $('#inDb').textContent = m.inLevel > 0.001 ? Math.round(20 * Math.log10(m.inLevel)) + ' дБ' : '−∞';
      $('#outDb').textContent = m.outLevel > 0.001 ? Math.round(20 * Math.log10(m.outLevel)) + ' дБ' : '−∞';
      $('#stageNote').textContent = m.pitchNote;
      $('#stageSemis').textContent = (m.semis > 0 ? '+' : '') + round1(m.semis) + ' пт';

      // record mini waveform
      const rc = recVis.ctx, rw = recVis.canvas.clientWidth, rh = recVis.canvas.clientHeight;
      rc.clearRect(0, 0, rw, rh);
      rc.strokeStyle = rec.active ? 'rgba(251,106,106,0.9)' : 'rgba(62,224,166,0.5)';
      rc.lineWidth = 1.3;
      rc.beginPath();
      for (let i = 0; i < wave.length; i += 4) {
        const x = (i / wave.length) * rw;
        const v = (wave[i] - 128) / 128;
        const y = rh / 2 + v * rh * 0.45;
        if (i === 0) rc.moveTo(x, y); else rc.lineTo(x, y);
      }
      rc.stroke();
    }
  }

  function loop(t) {
    if (vis.canvas.clientWidth === 0) resizeCanvas();
    if (state.powered && audio.chain && audio.chain.state && audio.chain.inputGain) {
      try { drawActive(t); } catch { drawIdle(t); }
    } else {
      drawIdle(t);
      $('#inMeter').style.width = '0%';
      $('#outMeter').style.width = '0%';
      $('#inDb').textContent = '−∞';
      $('#outDb').textContent = '−∞';
      $('#stageNote').textContent = '—';
      $('#stageSemis').textContent = '—';
    }
    rafId = requestAnimationFrame(loop);
  }

  /* ------------------------------------------------------------ output routing */
  function isVirtualLabel(label) {
    return /cable|virtual|blackhole|voicemeeter|loopback|null|monitor of|line 1/i.test(label || '');
  }

  async function attachOutput(deviceId) {
    const outSel = $('#outSelect');
    const label = outSel && outSel.selectedOptions[0] ? outSel.selectedOptions[0].textContent : '';
    const virtual = isVirtualLabel(label);
    const sink = deviceId && deviceId !== 'default' ? deviceId : '';
    const ctx = audio.ctx;

    if (!ctx || !audio.chain) { updateRoutingHint(label, true, virtual); return; }

    /* 1. Feed the chosen device with the whole processed graph */
    let routed = false;
    if (typeof ctx.setSinkId === 'function') {
      try {
        await ctx.setSinkId(sink);
        routed = true;
      } catch (e) { routed = false; }
    }

    /* 2. Fallback: stream the processed audio into an <audio> element routed to the device */
    if (!routed) {
      if (!audio.sinkEl) {
        audio.sinkEl = new Audio();
        audio.sinkEl.srcObject = audio.chain.getMicStream();
        audio.sinkEl.autoplay = true;
      }
      try {
        if (typeof audio.sinkEl.setSinkId === 'function') await audio.sinkEl.setSinkId(sink);
        await audio.sinkEl.play().catch(() => {});
        routed = true;
      } catch (e) { routed = false; }
    }

    /* 3. When the voice goes into a virtual cable, the user hears nothing —
          add a local monitor on the default device so they can hear themselves. */
    audio.needMonitorEl = virtual;
    if (virtual) {
      if (!audio.monitorEl) {
        audio.monitorEl = new Audio();
        audio.monitorEl.srcObject = audio.chain.getMicStream();
        audio.monitorEl.autoplay = true;
        audio.monitorEl.volume = 0.85;
      }
      try { if (typeof audio.monitorEl.setSinkId === 'function') await audio.monitorEl.setSinkId(''); } catch {}
      audio.monitorEl.muted = !state.monitor;
      if (state.monitor) audio.monitorEl.play().catch(() => {});
    } else if (audio.monitorEl) {
      audio.monitorEl.muted = true;
      audio.monitorEl.pause();
    }

    setMonitor(state.monitor);
    updateRoutingHint(label, routed, virtual);
  }

  function updateRoutingHint(label, ok, virtual) {
    const hint = $('#monitorHint');
    if (!ok) {
      hint.textContent = 'Не удалось направить звук в выбранное устройство. Проверьте драйвер или выберите другое.';
      hint.className = 'mini-note warn';
      return;
    }
    hint.className = 'mini-note';
    hint.textContent = virtual
      ? 'Звук уходит в виртуальный кабель. В игре или звонке выберите соответствующий вход (например, «CABLE Output») как микрофон.'
      : 'Выбран обычный выход. Для игр и звонков выберите виртуальный кабель — иначе обработка слышна только вам.';
  }

  /* ------------------------------------------------------------ boot */
  async function boot() {
    restoreStore();
    buildQuickRow();
    buildSliders();
    renderPresets();
    updateStage();
    syncControls();
    setupCanvases();
    renderRecordings();
    switchView('studio');

    await listDevices().catch(() => {});
    if (!state.micId && state.devices.mics.length) {
      const first = state.devices.mics[0];
      if (first && first.deviceId) state.micId = first.deviceId;
    }
    if (!state.outId && state.devices.outputs.length) {
      const first = state.devices.outputs[0];
      if (first && first.deviceId) state.outId = first.deviceId;
    }
    renderDevices();

    // first-launch onboarding
    const onboardingSeen = safeGet('chameleon.onboarded');
    if (!onboardingSeen) {
      const modal = openModal(`
        <h3>Добро пожаловать в Chameleon Voice</h3>
        <p>Меняйте голос в реальном времени и отправляйте его в игры, Discord, Zoom и OBS.</p>
        <div class="step-list" style="margin-bottom:6px">
          <div class="step"><div class="num">1</div><div><h4>Нажмите «Включить»</h4><p>Приложение попросит доступ к микрофону — разрешите его.</p></div></div>
          <div class="step"><div class="num">2</div><div><h4>Выберите пресет</h4><p>Или подкрутите высоту и тембр вручную.</p></div></div>
          <div class="step"><div class="num">3</div><div><h4>Отправьте звук в виртуальный кабель</h4><p>Инструкция — в разделе «Подключение». Там же проверка через браузер.</p></div></div>
        </div>
        <div class="row-inline">
          <button class="btn" data-close>Позже</button>
          <button class="btn primary" data-go>Хорошо</button>
        </div>
      `);
      modal.querySelectorAll('[data-close]').forEach(b => b.addEventListener('click', closeModal));
      const go = modal.querySelector('[data-go]');
      go.addEventListener('click', () => { safeSet('chameleon.onboarded', '1'); closeModal(); switchView('studio'); });
      modal.querySelector('[data-close]').addEventListener('click', () => safeSet('chameleon.onboarded', '1'));
    }

    fillAbout();
    requestAnimationFrame(loop);
  }

  // keep device list fresh
  if (navigator.mediaDevices && navigator.mediaDevices.addEventListener) {
    navigator.mediaDevices.addEventListener('devicechange', () => listDevices().catch(() => {}));
  }

  window.addEventListener('beforeunload', () => { saveStore(); stopAudio(); });

  boot();
})();
