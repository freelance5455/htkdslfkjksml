/* ============================================================
   Chameleon Voice — voice presets
   Each preset is a full state of the effects chain.
   ============================================================ */

const PRESET_ORDER = [
  'original', 'deep', 'deeper', 'chipmunk', 'robot', 'alien',
  'radio', 'phone', 'ghost', 'monster', 'drone', 'creature', 'android'
];

const PRESETS = {
  original: {
    label: 'Оригинал', icon: '🎙️', tag: 'Без эффектов',
    pitch: 0, formant: 0, robot: 0, breath: 0, ring: 1.1, ringMix: 0,
    echo: 0, echoMix: 0, reverb: 0, reverbMix: 0,
    lowcut: 70, highcut: 16000, distortion: 0, tremolo: 0, noise: 0, gain: 1
  },
  deep: {
    label: 'Глубокий', icon: '🌊', tag: 'Солидный баритон',
    pitch: -4, formant: -3, robot: 0, breath: 0, ring: 1.1, ringMix: 0,
    echo: 0, echoMix: 0, reverb: 14, reverbMix: 14,
    lowcut: 70, highcut: 15000, distortion: 0, tremolo: 0, noise: 0, gain: 1.1
  },
  deeper: {
    label: 'Демон', icon: '🔥', tag: 'Максимально низко',
    pitch: -10, formant: -7, robot: 0, breath: 0, ring: -1.6, ringMix: 18,
    echo: 0, echoMix: 0, reverb: 30, reverbMix: 26,
    lowcut: 50, highcut: 9000, distortion: 14, tremolo: 0, noise: 0, gain: 1.15
  },
  chipmunk: {
    label: 'Бурундук', icon: '🐿️', tag: 'Высоко и быстро',
    pitch: 8, formant: 5, robot: 0, breath: 0, ring: 1.2, ringMix: 0,
    echo: 0, echoMix: 0, reverb: 6, reverbMix: 10,
    lowcut: 120, highcut: 16000, distortion: 0, tremolo: 0, noise: 0, gain: 1.05
  },
  robot: {
    label: 'Робот', icon: '🤖', tag: 'Синтетический голос',
    pitch: 0, formant: 0, robot: 100, breath: 0, ring: 1.1, ringMix: 0,
    echo: 0, echoMix: 0, reverb: 0, reverbMix: 0,
    lowcut: 90, highcut: 7000, distortion: 8, tremolo: 0, noise: 0, gain: 1.1
  },
  alien: {
    label: 'Пришелец', icon: '👽', tag: 'Космос и модуляция',
    pitch: 5, formant: 4, robot: 0, breath: 0, ring: 0.6, ringMix: 55,
    echo: 220, echoMix: 25, reverb: 25, reverbMix: 24,
    lowcut: 150, highcut: 12000, distortion: 4, tremolo: 9, noise: 0, gain: 1
  },
  radio: {
    label: 'Рация', icon: '📻', tag: 'Узкая полоса частот',
    pitch: 0, formant: 0, robot: 18, breath: 0, ring: 1.1, ringMix: 0,
    echo: 0, echoMix: 0, reverb: 0, reverbMix: 0,
    lowcut: 450, highcut: 3200, distortion: 22, tremolo: 0, noise: 16, gain: 1.5
  },
  phone: {
    label: 'Телефон', icon: '☎️', tag: 'Как из трубки',
    pitch: 0, formant: 0, robot: 0, breath: 0, ring: 1.1, ringMix: 0,
    echo: 0, echoMix: 0, reverb: 0, reverbMix: 0,
    lowcut: 380, highcut: 3400, distortion: 10, tremolo: 0, noise: 4, gain: 1.6
  },
  ghost: {
    label: 'Призрак', icon: '👻', tag: 'Шёпот из тумана',
    pitch: -2, formant: 2, robot: 0, breath: 42, ring: 0.5, ringMix: 30,
    echo: 320, echoMix: 30, reverb: 55, reverbMix: 46,
    lowcut: 140, highcut: 8000, distortion: 0, tremolo: 6, noise: 8, gain: 1.1
  },
  monster: {
    label: 'Монстр', icon: '👹', tag: 'Глубоко и злобно',
    pitch: -8, formant: -9, robot: 12, breath: 20, ring: -0.9, ringMix: 22,
    echo: 0, echoMix: 0, reverb: 22, reverbMix: 20,
    lowcut: 60, highcut: 7000, distortion: 26, tremolo: 3, noise: 6, gain: 1.1
  },
  drone: {
    label: 'Гул', icon: '🛸', tag: 'Плоский футуризм',
    pitch: -2, formant: 0, robot: 55, breath: 0, ring: 2.4, ringMix: 40,
    echo: 0, echoMix: 0, reverb: 18, reverbMix: 20,
    lowcut: 80, highcut: 9000, distortion: 12, tremolo: 4, noise: 0, gain: 1.05
  },
  creature: {
    label: 'Существо', icon: '🦎', tag: 'Нереальный тембр',
    pitch: 3, formant: -5, robot: 0, breath: 10, ring: -1.1, ringMix: 34,
    echo: 120, echoMix: 18, reverb: 20, reverbMix: 18,
    lowcut: 70, highcut: 11000, distortion: 18, tremolo: 5, noise: 0, gain: 1.05
  },
  android: {
    label: 'Андроид', icon: '⚙️', tag: 'Гладкая машина',
    pitch: -1, formant: 1, robot: 34, breath: 0, ring: 1.5, ringMix: 8,
    echo: 0, echoMix: 0, reverb: 10, reverbMix: 12,
    lowcut: 110, highcut: 8000, distortion: 4, tremolo: 2, noise: 0, gain: 1.1
  }
};

const SLIDERS = [
  { key: 'pitch',       label: 'Высота голоса',  min: -12,  max: 12,  step: 0.5, unit: 'пт', fmt: v => (v > 0 ? '+' : '') + v },
  { key: 'formant',     label: 'Формант (тембр)', min: -12, max: 12,  step: 0.5, unit: 'пт', fmt: v => (v > 0 ? '+' : '') + v },
  { key: 'robot',       label: 'Робот-эффект',   min: 0,    max: 100, step: 1,   unit: '%', fmt: v => v + '%' },
  { key: 'breath',      label: 'Шёпот',          min: 0,    max: 100, step: 1,   unit: '%', fmt: v => v + '%' },
  { key: 'ring',        label: 'Кольцевая модуляция', min: 0.1, max: 4, step: 0.1, unit: 'Гц', fmt: v => (+v).toFixed(1) + ' Гц' },
  { key: 'ringMix',     label: 'Микс модуляции', min: 0,    max: 100, step: 1,   unit: '%', fmt: v => v + '%' },
  { key: 'echo',        label: 'Задержка',       min: 0,    max: 600, step: 10,  unit: 'мс', fmt: v => v + ' мс' },
  { key: 'echoMix',     label: 'Микс задержки',  min: 0,    max: 100, step: 1,   unit: '%', fmt: v => v + '%' },
  { key: 'reverb',      label: 'Реверберация',   min: 0,    max: 100, step: 1,   unit: '%', fmt: v => v + '%' },
  { key: 'reverbMix',   label: 'Микс реверба',   min: 0,    max: 100, step: 1,   unit: '%', fmt: v => v + '%' },
  { key: 'lowcut',      label: 'Срез низов',     min: 20,   max: 1000, step: 10, unit: 'Гц', fmt: v => v + ' Гц' },
  { key: 'highcut',     label: 'Срез верхов',    min: 1000, max: 16000, step: 100, unit: 'Гц', fmt: v => (v / 1000).toFixed(1) + ' кГц' },
  { key: 'distortion',  label: 'Драйв',          min: 0,    max: 100, step: 1,   unit: '%', fmt: v => v + '%' },
  { key: 'tremolo',     label: 'Тремоло',        min: 0,    max: 20,  step: 0.5, unit: 'Гц', fmt: v => v + ' Гц' },
  { key: 'noise',       label: 'Шум / треск',    min: 0,    max: 100, step: 1,   unit: '%', fmt: v => v + '%' },
  { key: 'gain',        label: 'Громкость',      min: 0.2,  max: 2,   step: 0.05, unit: '×', fmt: v => (+v).toFixed(2) + '×' }
];

/* Latency-oriented quality levels. value = fftSize */
const QUALITY = {
  low:    { label: 'Минимум задержки', fft: 512,  hint: '≈12 мс' },
  medium: { label: 'Баланс',           fft: 1024, hint: '≈26 мс' },
  high:   { label: 'Максимум качества', fft: 2048, hint: '≈53 мс' }
};

/* Virtual audio cable drivers shown in the setup guide */
const CABLES = [
  {
    os: 'win',
    name: 'VB-Audio Virtual Cable',
    desc: 'Бесплатный виртуальный кабель. Установите драйвер, затем выберите «CABLE Input» как устройство вывода в Chameleon, а «CABLE Output» — как микрофон в игре или Discord.',
    url: 'https://vb-audio.com/Cable/',
    steps: [
      'Скачайте и установите VB-CABLE (запустите VBCABLE_Setup_x64.exe от имени администратора, затем перезагрузите ПК).',
      'В Chameleon Voice в блоке «Выход» выберите CABLE Input (VB-Audio Virtual Cable).',
      'В игре / Discord / Zoom выберите CABLE Output (VB-Audio Virtual Cable) как устройство ввода — ваш микрофон.'
    ]
  },
  {
    os: 'win',
    name: 'VoiceMeeter (для стримеров)',
    desc: 'Микшер, который умеет отправлять обработанный голос сразу в несколько приложений и записывать его отдельной дорожкой.',
    url: 'https://vb-audio.com/Voicemeeter/',
    steps: [
      'Установите VoiceMeeter и перезагрузите ПК.',
      'Выход Chameleon Voice направьте на VoiceMeeter Input (VAIO).',
      'В VoiceMeeter назначьте VAIO на B1/B2 и выберите VoiceMeeter Out B1 как микрофон в играх.'
    ]
  },
  {
    os: 'mac',
    name: 'BlackHole 2ch',
    desc: 'Бесплатный виртуальный аудиодрайвер для macOS. После установки станет доступен как устройство вывода и ввода.',
    url: 'https://existential.audio/blackhole/',
    steps: [
      'Установите BlackHole 2ch (нужно разрешение в «Настройки → Безопасность»).',
      'В Chameleon Voice в блоке «Выход» выберите BlackHole 2ch.',
      'В игре или звонке выберите BlackHole 2ch как микрофон.'
    ]
  },
  {
    os: 'linux',
    name: 'PipeWire / PulseAudio null-sink',
    desc: 'Виртуальный микрофон создаётся средствами системы, драйверы не нужны.',
    url: 'https://pipewire.org/',
    steps: [
      'Создайте виртуальный микрофон: pactl load-module module-null-sink sink_name=chameleon sink_properties=device.description=Chameleon',
      'Выберите Chameleon как устройство вывода в Chameleon Voice.',
      'В браузере или приложении выберите «Monitor of Chameleon» как вход.'
    ]
  }
];

/* One-click effect quick buttons on the stage */
const QUICK_EFFECTS = [
  { id: 'deep',     label: 'Ниже',      icon: '⬇️' },
  { id: 'chipmunk', label: 'Выше',      icon: '⬆️' },
  { id: 'robot',    label: 'Робот',     icon: '🤖' },
  { id: 'alien',    label: 'Пришелец',  icon: '👽' },
  { id: 'radio',    label: 'Рация',     icon: '📻' },
  { id: 'ghost',    label: 'Призрак',   icon: '👻' }
];

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { PRESETS, PRESET_ORDER, SLIDERS, QUALITY, CABLES, QUICK_EFFECTS };
}
