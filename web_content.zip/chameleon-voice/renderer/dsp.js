/* ============================================================
   Chameleon Voice — DSP engine (Web Audio API)

   Signal path:
     mic ─► inputGain ─┬─► alignDelay ─► dry ────────────────────────────┐
                       └─► hum ─► drive ─► EQ ─► formant ─► PITCH ──────┤
                                                          │             │
                       ┌──────────────────────────────────┘             │
                       ├─► tremolo ─► breath ─► ring ─► echo ─► reverb  │
                       └─► master ─► analyser ─► monitor ─► micDest ────┘
   ============================================================ */
(function (global) {
  'use strict';

  const MIN_FFT = 512;
  const MAX_FFT = 4096;

  const NOTE_NAMES = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
  const noteFor = (ratio) => {
    const semis = 12 * Math.log2(Math.max(0.01, ratio));
    const idx = Math.round(semis) + 12;
    const octave = Math.floor(idx / 12) + 1;
    return NOTE_NAMES[((idx % 12) + 12) % 12] + octave;
  };

  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);

  /* ----------------------------------------------------------
     DopplerShifter — dual-tap granular pitch shifter.
     Two read heads sweep through a circular buffer at `ratio`
     samples per output sample and are cross-faded with a
     raised-cosine window, so the output is a clean, continuous
     resampling of the input at a new pitch.
     ---------------------------------------------------------- */
  class DopplerShifter {
    constructor(sampleRate, size) {
      this.sr = sampleRate;
      this.size = size;              // power of two
      this.mask = size - 1;
      this.half = size >> 1;
      this.buf = new Float32Array(size);
      this.w = 0;
      this.delay = size * 0.25;
      this.ratio = 1;
      this.bypass = true;
      this._fixedBypass = this.half;
    }

    setRatio(r) {
      const v = clamp(r || 1, 0.25, 4);
      this.ratio = v;
      this.bypass = Math.abs(v - 1) < 0.0008;
    }

    _read(delay) {
      const size = this.size, mask = this.mask;
      let pos = this.w - delay;
      while (pos < 0) pos += size;
      const i = pos | 0;
      const f = pos - i;
      const a = this.buf[i & mask];
      const b = this.buf[(i + 1) & mask];
      return a + (b - a) * f;
    }

    process(x) {
      this.buf[this.w] = x;

      let out;
      if (this.bypass) {
        out = this._read(this._fixedBypass);
      } else {
        const size = this.size;
        let d = this.delay;
        d -= Math.floor(d / size) * size;
        if (d < 0) d += size;

        const ph = d / size;                    // 0..1
        const s = Math.sin(Math.PI * ph);
        const gA = s * s;                       // sin^2
        const gB = 1 - gA;                      // sin^2(ph + .5)

        const dA = d + 1.5;
        let dB = d + this.half;
        dB -= Math.floor(dB / size) * size;
        dB += 1.5;

        out = this._read(dA) * gA + this._read(dB) * gB;
        this.delay += 1 - this.ratio;
      }

      this.w = (this.w + 1) & this.mask;
      return out;
    }
  }

  /* ----------------------------------------------------------
     ScriptProcessor wrapper
     ---------------------------------------------------------- */
  function createShiftNode(ctx, size) {
    const quantum = 1024;
    const node = ctx.createScriptProcessor(quantum, 1, 1);
    const shifter = new DopplerShifter(ctx.sampleRate, size);
    let ratio = 1;

    node.onaudioprocess = (e) => {
      const inBuf = e.inputBuffer.getChannelData(0);
      const outBuf = e.outputBuffer.getChannelData(0);
      for (let i = 0; i < inBuf.length; i++) outBuf[i] = shifter.process(inBuf[i]);
    };

    node.setRatio = (r) => {
      if (r === ratio) return;
      ratio = r;
      shifter.setRatio(r);
    };
    node.latencySamples = () => shifter._fixedBypass;
    node.setSize = (s) => { shifter.size = s; };
    return node;
  }

  /* ----------------------------------------------------------
     Reverb impulse response
     ---------------------------------------------------------- */
  function makeImpulse(ctx, decay) {
    const sr = ctx.sampleRate;
    const seconds = Math.max(0.35, decay);
    const len = Math.floor(sr * seconds);
    const buf = ctx.createBuffer(2, len, sr);
    for (let ch = 0; ch < 2; ch++) {
      const d = buf.getChannelData(ch);
      let lp = 0;
      for (let i = 0; i < len; i++) {
        const t = i / len;
        const env = Math.pow(1 - t, 2.6);
        /* darken the tail so it doesn't sound like white noise */
        const n = Math.random() * 2 - 1;
        lp += (n - lp) * (0.32 * Math.pow(1 - t, 0.7) + 0.06);
        const early = i < sr * 0.05 && i % 1013 === 0 ? 0.5 : 0;
        d[i] = lp * env * 0.7 + early;
      }
    }
    return buf;
  }

  /* ----------------------------------------------------------
     VoiceChain
     ---------------------------------------------------------- */
  class VoiceChain {
    constructor(ctx) {
      this.ctx = ctx;
      this.bufSize = 2048;
      this.source = null;
      this.mode = 'speakers';
      this.state = null;
      this._driveAmount = -1;
      this._revAmount = -1;
      this._noiseTarget = -1;
      this._build();
    }

    _build() {
      const ctx = this.ctx;

      /* ---------- input ---------- */
      this.inputGain = ctx.createGain();
      this.inAnalyser = ctx.createAnalyser();
      this.inAnalyser.fftSize = 1024;
      this.inAnalyser.smoothingTimeConstant = 0.6;
      this.inputGain.connect(this.inAnalyser);

      /* dry path, aligned to the pitch shifter's latency */
      this.alignDelay = ctx.createDelay(0.2);
      this.alignDelay.delayTime.value = (this.bufSize / 2) / ctx.sampleRate;
      this.dryGain = ctx.createGain();
      this.dryGain.gain.value = 0;

      /* ---------- tone ---------- */
      this.hum = ctx.createBiquadFilter();
      this.hum.type = 'highpass';
      this.hum.frequency.value = 45;
      this.hum.Q.value = 0.7;

      this.drive = ctx.createWaveShaper();
      this.drive.oversample = '2x';
      this.driveGain = ctx.createGain();
      this._setDriveCurve(0);

      this.lowcut = ctx.createBiquadFilter();
      this.lowcut.type = 'highpass';
      this.lowcut.frequency.value = 70;
      this.lowcut.Q.value = 0.9;

      this.highcut = ctx.createBiquadFilter();
      this.highcut.type = 'lowpass';
      this.highcut.frequency.value = 16000;
      this.highcut.Q.value = 0.9;

      /* formant / timbre tilt */
      this.formantLow = ctx.createBiquadFilter();
      this.formantLow.type = 'lowshelf';
      this.formantLow.frequency.value = 420;
      this.formantLow.gain.value = 0;

      this.formantHigh = ctx.createBiquadFilter();
      this.formantHigh.type = 'highshelf';
      this.formantHigh.frequency.value = 2600;
      this.formantHigh.gain.value = 0;

      /* ---------- pitch ---------- */
      this.pitchNode = createShiftNode(ctx, this.bufSize);
      this.pitchGain = ctx.createGain();
      this.pitchBypass = ctx.createGain();
      this.pitchBypass.gain.value = 0;

      /* ---------- tremolo ---------- */
      this.tremolo = ctx.createGain();
      this.tremOsc = ctx.createOscillator();
      this.tremOsc.type = 'sine';
      this.tremOsc.frequency.value = 5;
      this.tremDepth = ctx.createGain();
      this.tremDepth.gain.value = 0;
      this.tremOsc.connect(this.tremDepth);
      this.tremDepth.connect(this.tremolo.gain);
      this.tremOsc.start();

      this.postTrem = ctx.createGain();

      /* ---------- breath ---------- */
      this.breathSend = ctx.createGain();
      this.breathSend.gain.value = 0;
      this.breathHP = ctx.createBiquadFilter();
      this.breathHP.type = 'highpass';
      this.breathHP.frequency.value = 800;
      this.breathHP.Q.value = 0.4;
      this.breathLP = ctx.createBiquadFilter();
      this.breathLP.type = 'lowpass';
      this.breathLP.frequency.value = 5200;
      this.breathPeak = ctx.createBiquadFilter();
      this.breathPeak.type = 'peaking';
      this.breathPeak.frequency.value = 2600;
      this.breathPeak.Q.value = 0.9;
      this.breathPeak.gain.value = 6;
      this.breathSend.connect(this.breathHP);
      this.breathHP.connect(this.breathLP);
      this.breathLP.connect(this.breathPeak);
      this.breathPeak.connect(this.postTrem);

      /* ---------- ring mod ---------- */
      this.ringDry = ctx.createGain();
      this.ringWet = ctx.createGain();
      this.ringWet.gain.value = 0;
      this.ringGain = ctx.createGain();
      this.ringGain.gain.value = 0;
      this.ringOsc = ctx.createOscillator();
      this.ringOsc.type = 'sine';
      this.ringOsc.frequency.value = 1.1;
      this.ringOsc.connect(this.ringGain.gain);
      this.ringOsc.start();
      this.ringSum = ctx.createGain();

      /* ---------- echo ---------- */
      this.echoIn = ctx.createGain();
      this.echoDry = ctx.createGain();
      this.echoDelay = ctx.createDelay(1.5);
      this.echoDelay.delayTime.value = 0.25;
      this.echoFB = ctx.createGain();
      this.echoFB.gain.value = 0;
      this.echoWet = ctx.createGain();
      this.echoWet.gain.value = 0;
      this.echoSum = ctx.createGain();

      /* ---------- reverb ---------- */
      this.verbIn = ctx.createGain();
      this.verbDry = ctx.createGain();
      this.convolver = ctx.createConvolver();
      this.convolver.buffer = makeImpulse(ctx, 2.2);
      this.verbWet = ctx.createGain();
      this.verbWet.gain.value = 0;
      this.verbSum = ctx.createGain();

      /* ---------- noise ---------- */
      this.noiseGain = ctx.createGain();
      this.noiseGain.gain.value = 0;
      this._startNoise();

      /* ---------- output ---------- */
      this.master = ctx.createGain();
      this.outAnalyser = ctx.createAnalyser();
      this.outAnalyser.fftSize = 2048;
      this.outAnalyser.smoothingTimeConstant = 0.72;
      /* local output gain -> ctx.destination (routed to the chosen device) */
      this.monitor = ctx.createGain();
      this.monitor.gain.value = 1;
      /* processed stream: recording, in-browser virtual mic, headphone monitor */
      this.micDest = ctx.createMediaStreamDestination();

      /* ---------- wiring ---------- */
      this.inputGain.connect(this.alignDelay);
      this.alignDelay.connect(this.dryGain);
      this.dryGain.connect(this.master);

      this.inputGain.connect(this.hum);
      this.hum.connect(this.drive);
      this.drive.connect(this.lowcut);
      this.lowcut.connect(this.highcut);
      this.highcut.connect(this.formantLow);
      this.formantLow.connect(this.formantHigh);
      this.formantHigh.connect(this.pitchNode);
      this.formantHigh.connect(this.pitchBypass);
      this.pitchNode.connect(this.pitchGain);
      this.pitchGain.connect(this.tremolo);
      this.pitchBypass.connect(this.tremolo);

      this.tremolo.connect(this.postTrem);
      this.postTrem.connect(this.breathSend);
      this.postTrem.connect(this.ringDry);
      this.postTrem.connect(this.ringGain);
      this.ringGain.connect(this.ringWet);
      this.ringDry.connect(this.ringSum);
      this.ringWet.connect(this.ringSum);

      this.ringSum.connect(this.echoIn);
      this.echoIn.connect(this.echoDry);
      this.echoDry.connect(this.echoSum);
      this.echoIn.connect(this.echoDelay);
      this.echoDelay.connect(this.echoFB);
      this.echoFB.connect(this.echoDelay);
      this.echoDelay.connect(this.echoWet);
      this.echoWet.connect(this.echoSum);

      this.echoSum.connect(this.verbIn);
      this.verbIn.connect(this.verbDry);
      this.verbDry.connect(this.verbSum);
      this.verbIn.connect(this.convolver);
      this.convolver.connect(this.verbWet);
      this.verbWet.connect(this.verbSum);

      this.verbSum.connect(this.master);
      this.noiseGain.connect(this.master);

      this.master.connect(this.outAnalyser);
      this.outAnalyser.connect(this.micDest);
      this.outAnalyser.connect(this.monitor);
      this.monitor.connect(this.ctx.destination);
    }

    _startNoise() {
      const ctx = this.ctx;
      const len = Math.floor(ctx.sampleRate * 2);
      const buf = ctx.createBuffer(1, len, ctx.sampleRate);
      const d = buf.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * 0.6;
      this.noiseSrc = ctx.createBufferSource();
      this.noiseSrc.buffer = buf;
      this.noiseSrc.loop = true;
      this.noiseSrc.connect(this.noiseGain);
      this.noiseSrc.start();
    }

    _setDriveCurve(amount) {
      if (!amount) {
        const lin = new Float32Array(2048);
        for (let i = 0; i < lin.length; i++) lin[i] = (i / (lin.length - 1)) * 2 - 1;
        this.drive.curve = lin;
        return;
      }
      const k = 1 + amount * 0.45;
      const n = 2048;
      const curve = new Float32Array(n);
      for (let i = 0; i < n; i++) {
        const x = (i / (n - 1)) * 2 - 1;
        curve[i] = Math.tanh(k * x) / Math.tanh(k);
      }
      this.drive.curve = curve;
    }

    /* ---------------- public API ---------------- */

    setSource(node) {
      if (this.source && this.source !== node) {
        try { this.source.disconnect(this.inputGain); } catch {}
      }
      this.source = node;
      node.connect(this.inputGain);
    }

    /** mute / unmute the local output while the stream keeps running */
    setOutputEnabled(on) {
      try { this.monitor.gain.setTargetAtTime(on ? 1 : 0, this.ctx.currentTime, 0.03); }
      catch { this.monitor.gain.value = on ? 1 : 0; }
    }

    /** processed stream (recording, in-browser virtual mic, headphone monitor) */
    getMicStream() {
      return this.micDest.stream;
    }

    setLatency(size) {
      if (size === this.bufSize) return;
      this.bufSize = size;
      const old = this.pitchNode;
      this.pitchNode = createShiftNode(this.ctx, size);
      this.formantHigh.connect(this.pitchNode);
      this.pitchNode.connect(this.pitchGain);
      try { this.formantHigh.disconnect(old); } catch {}
      try { old.disconnect(); } catch {}
      try { old.onaudioprocess = null; } catch {}
      this.alignDelay.delayTime.value = (size / 2) / this.ctx.sampleRate;
      if (this.state) this.update(this.state, true);
    }

    update(s, immediate) {
      this.state = s;
      const ctx = this.ctx;
      const tc = immediate ? 0.008 : 0.05;
      const set = (param, v) => {
        try { param.setTargetAtTime(v, ctx.currentTime, tc); }
        catch { param.value = v; }
      };

      const pitch = Number(s.pitch) || 0;
      const formant = Number(s.formant) || 0;

      /* pitch */
      const ratio = Math.pow(2, pitch / 12);
      this.pitchNode.setRatio(ratio);
      const usePitch = Math.abs(pitch) > 0.05;
      set(this.pitchGain.gain, usePitch ? 1 : 0);
      set(this.pitchBypass.gain, usePitch ? 0 : 1);

      /* formant tilt: negative = bigger/throatier, positive = smaller/brighter */
      const tilt = clamp(formant, -12, 12) * 0.75;
      set(this.formantLow.gain, -tilt);
      set(this.formantHigh.gain, tilt);

      /* tone */
      set(this.lowcut.frequency, clamp(Number(s.lowcut) || 70, 20, 2000));
      set(this.highcut.frequency, clamp(Number(s.highcut) || 16000, 800, 18000));
      const dist = Number(s.distortion) || 0;
      if (this._driveAmount !== dist) {
        this._driveAmount = dist;
        this._setDriveCurve(dist / 100);
      }
      set(this.driveGain.gain, 1);

      /* tremolo */
      const trem = Number(s.tremolo) || 0;
      set(this.tremOsc.frequency, Math.max(0.1, trem));
      set(this.tremDepth.gain, trem > 0.1 ? 0.5 : 0);
      set(this.tremolo.gain, trem > 0.1 ? 0.5 : 1);

      /* breath */
      const breath = (Number(s.breath) || 0) / 100;
      set(this.breathSend.gain, breath > 0.01 ? 0.06 + breath * 0.6 : 0);

      /* ring */
      const ringMix = clamp((Number(s.ringMix) || 0) / 100, 0, 1);
      set(this.ringOsc.frequency, Math.max(0.1, Number(s.ring) || 1));
      set(this.ringDry.gain, 1 - ringMix);
      set(this.ringWet.gain, ringMix > 0.01 ? ringMix * 1.25 : 0);

      /* echo */
      const echoMs = Number(s.echo) || 0;
      const echoMix = clamp((Number(s.echoMix) || 0) / 100, 0, 1);
      set(this.echoDelay.delayTime, clamp(echoMs / 1000, 0.03, 1.4));
      set(this.echoFB.gain, echoMs > 25 ? 0.33 : 0);
      set(this.echoWet.gain, echoMix > 0.01 ? echoMix * 0.8 : 0);

      /* reverb */
      const rev = Number(s.reverb) || 0;
      const revMix = clamp((Number(s.reverbMix) || 0) / 100, 0, 1);
      if (Math.abs(this._revAmount - rev) > 4) {
        this._revAmount = rev;
        this.convolver.buffer = makeImpulse(ctx, 0.4 + rev / 100 * 3.4);
      }
      set(this.verbWet.gain, revMix > 0.01 ? revMix * 0.9 : 0);

      /* dry monitor mix + master */
      set(this.dryGain.gain, clamp(Number(s.dryMix) || 0, 0, 1) * 0.9);
      set(this.master.gain, clamp(Number(s.gain) || 1, 0.05, 2));
    }

    /** Read current levels from the analyser nodes (call from rAF). */
    readLevels() {
      if (!this._inBuf) {
        this._inBuf = new Float32Array(this.inAnalyser.fftSize);
        this._outBuf = new Float32Array(this.outAnalyser.fftSize);
      }
      const inTime = this._inBuf, outTime = this._outBuf;
      this.inAnalyser.getFloatTimeDomainData(inTime);
      this.outAnalyser.getFloatTimeDomainData(outTime);

      let inSum = 0, outSum = 0, peak = 0;
      for (let i = 0; i < inTime.length; i++) {
        const v = inTime[i];
        inSum += v * v;
        const a = v < 0 ? -v : v;
        if (a > peak) peak = a;
      }
      for (let i = 0; i < outTime.length; i++) outSum += outTime[i] * outTime[i];

      const inLevel = Math.sqrt(inSum / inTime.length);
      const outLevel = Math.sqrt(outSum / outTime.length);

      /* radio crackle follows speech, silent in pauses */
      const noiseAmt = ((this.state && this.state.noise) || 0) / 100;
      const gate = inLevel > 0.008 ? Math.min(1, 0.25 + inLevel * 7) : 0;
      const target = noiseAmt * 0.45 * gate;
      if (Math.abs(this._noiseTarget - target) > 0.003) {
        this._noiseTarget = target;
        try { this.noiseGain.gain.setTargetAtTime(target, this.ctx.currentTime, 0.06); } catch {}
      }

      const pitch = (this.state && this.state.pitch) || 0;
      return {
        inLevel,
        outLevel,
        inPeak: peak,
        clip: outLevel > 0.9,
        pitchNote: noteFor(Math.pow(2, pitch / 12)),
        semis: pitch
      };
    }

    getFrequencyData() {
      const arr = new Uint8Array(this.outAnalyser.frequencyBinCount);
      this.outAnalyser.getByteFrequencyData(arr);
      return arr;
    }

    getWaveformData() {
      const arr = new Uint8Array(this.outAnalyser.fftSize);
      this.outAnalyser.getByteTimeDomainData(arr);
      return arr;
    }
  }

  global.ChameleonDSP = { VoiceChain, DopplerShifter, noteFor, MIN_FFT, MAX_FFT };
})(typeof window !== 'undefined' ? window : globalThis);
