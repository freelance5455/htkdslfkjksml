const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('chameleon', {
  isDesktop: true,
  platform: process.platform,
  loadSettings: () => ipcRenderer.invoke('settings:load'),
  saveSettings: (data) => ipcRenderer.invoke('settings:save', data),
  appInfo: () => ipcRenderer.invoke('app:info'),
  openExternal: (url) => ipcRenderer.invoke('app:openExternal', url)
});
