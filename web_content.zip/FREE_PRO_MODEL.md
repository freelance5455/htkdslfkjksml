# Smart Free + Pro
Free mode: 10 requests per day. When the limit is reached, Smart opens the Pro screen.
Pro: Google Play subscriptions `smart_pro_monthly` and `smart_pro_yearly`.
Production: verify purchases server-side before granting Pro; store usage and entitlement on the backend for multi-device accounts.
AI note: this package contains the Smart app/action architecture, not a bundled ChatGPT model. A real ChatGPT-like experience requires connecting a server-side AI model provider and keeping its secret off the APK.
