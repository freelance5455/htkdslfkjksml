# Orvian AI Assistant — Starter Project

A responsive dark-blue neon assistant interface built with plain HTML, CSS and JavaScript.

## Run it
1. Extract the ZIP.
2. Open `index.html` in a modern browser, or use VS Code Live Server / a local static server.
3. On Android, import the folder into SPCK Editor and preview `index.html`.

## Included
- Responsive desktop/mobile layout
- New conversation and suggested prompts
- Local conversation history (`localStorage`)
- Google Search hand-off in a new tab
- About screen with Founder & CEO: Ansh Sharan
- Clearly labelled local demo responses

## Important: this is not a live AI model
The current `demoReply()` function returns predefined responses. It does not call ChatGPT, Gemini, or another model. Google Search opens a Google results page; this app does not scrape or summarise results.

## How to connect real AI later
Recommended low-cost architecture:
- Frontend: this HTML/CSS/JS project
- Backend: a small server or serverless function
- Model: a local model on a capable device, or a provider's free/low-cost tier if available
- Store API keys only in server-side environment variables. Never hard-code private API keys into `js/app.js`.
- Add rate limits, input limits, and privacy disclosure before public release.

## Project structure
```text
orvian-ai/
├── index.html
├── README.md
├── css/
│   └── style.css
└── js/
    └── app.js
```

Conversations are stored in this browser only. Clearing browser site data may remove them. This starter has no account system, cloud sync, or backend.
