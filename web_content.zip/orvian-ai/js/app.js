(() => {
  "use strict";
  const $ = (selector) => document.querySelector(selector);
  const $$ = (selector) => [...document.querySelectorAll(selector)];
  const STORAGE_KEY = "orvian_demo_chats_v1";
  const state = { chats: loadChats(), currentId: null, view: "chat", webSearch: false, busy: false };

  const els = {
    sidebar: $("#sidebar"), scrim: $("#mobileScrim"), welcome: $("#welcome"), messages: $("#messages"),
    input: $("#promptInput"), form: $("#chatForm"), historyList: $("#historyList"),
    historyCards: $("#historyCards"), topTitle: $("#topTitle"), chatView: $("#chatView"),
    searchView: $("#searchView"), historyView: $("#historyView"), aboutView: $("#aboutView")
  };

  function loadChats() {
    try {
      const data = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
      return Array.isArray(data) ? data : [];
    } catch { return []; }
  }
  function saveChats() {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state.chats)); }
    catch { /* Storage can be disabled; app still works for this session. */ }
  }
  function makeId() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 7); }
  function currentChat() { return state.chats.find(c => c.id === state.currentId); }
  function newChat() {
    state.currentId = null;
    state.busy = false;
    els.messages.innerHTML = "";
    els.messages.classList.remove("visible");
    els.welcome.classList.remove("hidden");
    els.input.value = "";
    autoSize();
    renderHistory();
    showView("chat");
    els.input.focus();
  }
  function ensureChat(firstMessage) {
    let chat = currentChat();
    if (!chat) {
      chat = { id: makeId(), title: firstMessage.slice(0, 42) || "New conversation", updatedAt: Date.now(), messages: [] };
      state.chats.unshift(chat);
      state.currentId = chat.id;
    }
    return chat;
  }
  function renderHistory() {
    const recent = state.chats.slice(0, 7);
    els.historyList.innerHTML = "";
    if (!recent.length) {
      els.historyList.innerHTML = '<div class="empty-history">Your conversations will appear here.</div>';
    } else {
      recent.forEach(chat => {
        const btn = document.createElement("button");
        btn.className = "history-entry";
        btn.textContent = chat.title;
        btn.title = chat.title;
        btn.addEventListener("click", () => openChat(chat.id));
        els.historyList.appendChild(btn);
      });
    }
    els.historyCards.innerHTML = "";
    if (!state.chats.length) {
      els.historyCards.innerHTML = '<div class="empty-history">No saved conversations yet. Start a new chat to see it here.</div>';
      return;
    }
    state.chats.forEach(chat => {
      const btn = document.createElement("button");
      btn.className = "history-card";
      const icon = document.createElement("span"); icon.className = "hc-icon"; icon.textContent = "◈";
      const copy = document.createElement("span");
      const title = document.createElement("strong"); title.textContent = chat.title;
      const sub = document.createElement("small"); sub.textContent = `${chat.messages.length} messages · ${new Date(chat.updatedAt).toLocaleDateString()}`;
      copy.append(title, sub);
      const arrow = document.createElement("span"); arrow.className = "hc-open"; arrow.textContent = "↗";
      btn.append(icon, copy, arrow);
      btn.addEventListener("click", () => openChat(chat.id));
      els.historyCards.appendChild(btn);
    });
  }
  function showView(view) {
    state.view = view;
    const views = { chat: els.chatView, search: els.searchView, history: els.historyView, about: els.aboutView };
    Object.entries(views).forEach(([key, el]) => el.classList.toggle("hidden", key !== view));
    els.topTitle.textContent = ({chat:"Assistant",search:"Web search",history:"Conversation history",about:"About Orvian"})[view] || "Assistant";
    $$(".nav-item").forEach(btn => btn.classList.toggle("active", btn.dataset.view === view));
    closeSidebar();
    if (view === "history") renderHistory();
  }
  function openChat(id) {
    const chat = state.chats.find(c => c.id === id);
    if (!chat) return;
    state.currentId = id;
    els.messages.innerHTML = "";
    els.welcome.classList.add("hidden");
    els.messages.classList.add("visible");
    chat.messages.forEach(m => addMessage(m.role, m.content, false));
    showView("chat");
  }
  function addMessage(role, content, persist = true) {
    const row = document.createElement("div"); row.className = `message ${role}`;
    const avatar = document.createElement("div"); avatar.className = "message-avatar"; avatar.textContent = role === "user" ? "AS" : "O";
    const body = document.createElement("div"); body.className = "message-body";
    const label = document.createElement("div"); label.className = "message-label"; label.textContent = role === "user" ? "YOU" : "ORVIAN · DEMO";
    const text = document.createElement("div"); text.className = "message-text"; text.textContent = content;
    body.append(label, text); row.append(avatar, body); els.messages.appendChild(row);
    if (persist) els.messages.scrollTop = els.messages.scrollHeight;
    return row;
  }
  function addTyping() {
    const row = document.createElement("div"); row.className = "message";
    row.innerHTML = '<div class="message-avatar">O</div><div class="message-body"><div class="message-label">ORVIAN · DEMO</div><div class="message-text"><div class="typing"><span></span><span></span><span></span></div></div></div>';
    els.messages.appendChild(row); row.scrollIntoView({behavior:"smooth",block:"nearest"}); return row;
  }
  function demoReply(prompt) {
    const q = prompt.toLowerCase();
    if (/\b(hi|hello|hey|namaste|hii)\b/.test(q)) return "Hey! I'm Orvian, your assistant interface. ✨\n\nThis starter is running in demo mode, so I can show the chat flow, but I’m not connected to a real AI model yet.\n\nTry asking for a study plan, a coding example, or use Web search to open Google.";
    if (q.includes("study") || q.includes("plan my day") || q.includes("timetable")) return "Let’s make a practical plan:\n\n1. Choose one clear goal for each study session.\n2. Work for 25–40 minutes, then take a short break.\n3. Practise questions instead of only rereading.\n4. Finish with a 10-minute recap and note doubts.\n\nTell me your subjects and available time and I can help draft a more specific schedule. (Demo response — not generated by a live AI model.)";
    if (q.includes("javascript") || q.includes("code") || q.includes("coding")) return "Here’s a tiny JavaScript example:\n\nconst greet = (name) => `Hello, ${name}!`;\nconsole.log(greet('Ansh'));\n\n`greet` is a function that accepts a name and returns a greeting. `console.log` prints the result. (Demo response — connect a real model for open-ended coding help.)";
    if (q.includes("google") || q.includes("search") || state.webSearch) return "For current information, use Orvian’s Web search tab or click the Web search control below the message box. It opens a Google search in a new tab.\n\nThis demo does not fetch Google results directly or summarise pages automatically.";
    if (q.includes("who are you") || q.includes("orvian")) return "I’m Orvian — a futuristic AI assistant interface created for a project by Ansh Sharan.\n\nCurrent capabilities: chat UI, local conversation history, suggested prompts, and Google search hand-off. A live AI model is not connected yet.";
    return "Thanks for your message. Orvian’s chat interface is working, but this is currently a local demo responder rather than a real AI model.\n\nTo get genuine AI-generated answers, connect a model running locally on your device or create a small backend that calls an AI provider. Keep any secret API key on the backend — never put it in browser JavaScript.\n\nFor up-to-date facts, try the Web search option to open Google.";
  }
  function autoSize() { els.input.style.height = "auto"; els.input.style.height = Math.min(els.input.scrollHeight, 160) + "px"; }
  async function sendMessage(text) {
    const prompt = text.trim();
    if (!prompt || state.busy) return;
    state.busy = true;
    showView("chat");
    const chat = ensureChat(prompt);
    chat.messages.push({role:"user",content:prompt});
    chat.updatedAt = Date.now();
    if (chat.messages.length === 1) chat.title = prompt.slice(0,42) + (prompt.length > 42 ? "…" : "");
    saveChats(); renderHistory();
    els.welcome.classList.add("hidden"); els.messages.classList.add("visible");
    addMessage("user", prompt);
    els.input.value = ""; autoSize();
    const typing = addTyping();
    els.input.disabled = true;
    // Simulate a short response delay to make the demo feel interactive.
    await new Promise(resolve => setTimeout(resolve, 500));
    const reply = demoReply(prompt);
    typing.remove();
    addMessage("assistant", reply);
    chat.messages.push({role:"assistant",content:reply}); chat.updatedAt = Date.now();
    saveChats(); renderHistory();
    els.input.disabled = false; state.busy = false; els.input.focus();
  }
  function doGoogleSearch(query) {
    const clean = (query || "").trim();
    if (!clean) { showView("search"); $("#webSearchInput").focus(); return; }
    window.open("https://www.google.com/search?q=" + encodeURIComponent(clean), "_blank", "noopener,noreferrer");
  }
  function closeSidebar() { els.sidebar.classList.remove("open"); els.scrim.classList.remove("show"); }
  function openSidebar() { els.sidebar.classList.add("open"); els.scrim.classList.add("show"); }

  els.form.addEventListener("submit", e => { e.preventDefault(); sendMessage(els.input.value); });
  els.input.addEventListener("input", autoSize);
  els.input.addEventListener("keydown", e => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); els.form.requestSubmit(); }
  });
  $("#newChatBtn").addEventListener("click", newChat);
  $("#menuToggle").addEventListener("click", openSidebar);
  $("#closeSidebar").addEventListener("click", closeSidebar);
  els.scrim.addEventListener("click", closeSidebar);
  $("#aboutBtn").addEventListener("click", () => showView("about"));
  $("#themeInfo").addEventListener("click", () => showView("about"));
  $$(".nav-item").forEach(btn => btn.addEventListener("click", () => {
    if (btn.dataset.view === "search") showView("search");
    else if (btn.dataset.view === "history") showView("history");
    else showView("chat");
  }));
  $$(".suggestion").forEach(btn => btn.addEventListener("click", () => sendMessage(btn.dataset.prompt)));
  $("#searchToggle").addEventListener("click", () => {
    state.webSearch = !state.webSearch;
    $("#searchToggle").classList.toggle("enabled", state.webSearch);
    $("#searchToggle").innerHTML = state.webSearch ? "<span>⌕</span> Search enabled" : "<span>⌕</span> Web search";
    if (state.webSearch) {
      const current = els.input.value.trim();
      if (current) doGoogleSearch(current);
      else showView("search");
    }
  });
  $("#webSearchForm").addEventListener("submit", e => { e.preventDefault(); doGoogleSearch($("#webSearchInput").value); });
  $("#clearHistory").addEventListener("click", () => {
    if (!state.chats.length || !confirm("Clear all locally saved Orvian conversations?")) return;
    state.chats = []; state.currentId = null; saveChats(); renderHistory(); newChat();
  });
  document.addEventListener("keydown", e => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") { e.preventDefault(); newChat(); }
    if (e.key === "Escape") closeSidebar();
  });

  renderHistory();
  // Reopen the last chat only if the user selects it; start on the clean welcome screen.
})();