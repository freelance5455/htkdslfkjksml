AI SIGNAL LAB — Android-ready PWA prototype

What it does:
- Live crypto candle feed from Binance public API when reachable
- Pair selection: BTCUSDT, ETHUSDT, BNBUSDT, SOLUSDT, XRPUSDT
- Duration: 5s, 10s, 15s, 30s, 1m
- Separate signal lead-time setting
- UP/DOWN/WAIT signals
- EMA trend + RSI + short momentum analysis
- Confidence score and signal history
- OTC DEMO mode clearly labeled as simulated data
- Paper signals only; no automatic trading

Install on Android:
1. Put these files on any HTTPS web host.
2. Open index.html URL in Chrome on Android.
3. Chrome menu -> Add to Home screen / Install app.

Important:
- This prototype does NOT guarantee 90% accuracy.
- OTC feeds are broker-specific and cannot honestly be treated as live OTC without the broker's data/API.
- It does not place trades.
