# PHONE INFO — KNOW YOUR DEVICE

Ứng dụng Android (Kotlin + Jetpack Compose, minSdk 29 / Android 10+) hiển thị thông tin và tình trạng thiết bị
bằng dữ liệu thật từ API chính thức của Android.

## Mở và build bằng Android Studio
1. Cài **Android Studio Koala (2024.1.1)** trở lên (JDK 17 đi kèm).
2. Giải nén ZIP → **File ▸ Open** → chọn thư mục `PhoneInfo`.
3. Chờ **Gradle Sync** hoàn tất (cần Internet lần đầu; Studio tự tải Gradle 8.7 và Android SDK 34 nếu thiếu —
   chọn *Install missing SDK packages* khi được hỏi).
4. Chạy thử: cắm điện thoại (bật *Tùy chọn nhà phát triển ▸ Gỡ lỗi USB*) hoặc dùng emulator → nhấn **Run ▶**.

## Xuất APK
- APK debug (cài ngay được): **Build ▸ Build Bundle(s) / APK(s) ▸ Build APK(s)**
  → `app/build/outputs/apk/debug/app-debug.apk`. Chép sang điện thoại và cài (cho phép "cài từ nguồn không rõ").
- APK release: **Build ▸ Generate Signed App Bundle / APK ▸ APK** → tạo keystore → chọn `release`.
- Dòng lệnh (sau khi Studio đã sync): `gradle assembleDebug` hoặc tạo wrapper bằng `gradle wrapper`.

## Cấu trúc
- `data/DeviceRepository.kt` – đọc thiết bị, pin, mạng, cảm biến, dựng báo cáo
- `data/SystemTests.kt` – kiểm tra RAM, bộ nhớ, loa, micro, camera, pin
- `data/SpeedTest.kt` – đo tốc độ (chỉ khi người dùng đồng ý)
- `data/PdfExporter.kt` – xuất PDF vào Downloads (MediaStore, không cần quyền lưu trữ)
- `ui/*` – giao diện Compose (Tổng quan, Pin, Mạng, Kiểm tra, Báo cáo)

## Tab "Quyền" và Shizuku
- Danh sách quyền nằm trong `shizuku/PermissionCenter.kt` (runtime, đặc biệt, và quyền chỉ cấp được bằng Shizuku như DUMP, READ_LOGS, WRITE_SECURE_SETTINGS).
- Không có Shizuku: nút "Cấp tất cả" xin quyền runtime theo đợt; quyền đặc biệt mở đúng trang cài đặt.
- Có Shizuku: cài Shizuku, khởi động (Gỡ lỗi không dây / ADB / root), mở PHONE INFO ▸ tab Quyền ▸ "Cấp quyền Shizuku" ▸ "Cấp tất cả" (dùng `pm grant`, `appops`, `cmd deviceidle`).
- Với Shizuku, app đọc thêm: số sê-ri, IMEI (thử nhiều cách, tùy ROM), chu kỳ sạc, dung lượng pin thực/thiết kế, nhiệt độ các vùng, xung nhịp CPU, trạng thái bootloader/SELinux, Wi-Fi.
- Số sê-ri và IMEI chỉ hiện trên màn hình, không đưa vào PDF. Không có chức năng gửi dữ liệu đi.
- Thêm quyền khác (ví dụ danh bạ, SMS): khai báo trong AndroidManifest và thêm một dòng vào `PermissionCenter.items`.

## Quyền riêng tư
- Không có tính năng gửi dữ liệu thiết bị lên máy chủ. Quyền INTERNET chỉ dùng cho bài đo tốc độ (tải tệp thử) sau khi bạn bấm Đồng ý.
- Không đọc IMEI, số sê-ri, vị trí, tên Wi-Fi, danh bạ, tin nhắn, ảnh, tài khoản.
- Quyền micro / camera / trạng thái điện thoại chỉ xin khi bấm nút tương ứng; từ chối vẫn dùng được phần còn lại.
- Thông số hệ thống không cung cấp sẽ hiển thị: "Không được hệ thống hỗ trợ".
