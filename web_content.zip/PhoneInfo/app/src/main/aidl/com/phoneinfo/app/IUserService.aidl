package com.phoneinfo.app;

interface IUserService {
    void destroy() = 16777114;
    String exec(String command) = 1;
}
