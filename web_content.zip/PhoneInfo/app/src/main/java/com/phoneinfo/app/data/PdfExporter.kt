package com.phoneinfo.app.data

import android.content.ContentValues
import android.content.Context
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Xuất báo cáo ra PDF trong thư mục Downloads (MediaStore, không cần quyền lưu trữ). */
object PdfExporter {
    private const val W = 595
    private const val H = 842
    private const val M = 40f

    fun export(ctx: Context, sections: List<ReportSection>): Uri {
        val doc = PdfDocument()
        var pageNo = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(W, H, pageNo).create())
        var canvas = page.canvas
        var y = M + 10f

        val pTitle = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(0, 150, 80); textSize = 24f; isFakeBoldText = true }
        val pSub = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.GRAY; textSize = 11f }
        val pHead = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(41, 121, 255); textSize = 15f; isFakeBoldText = true }
        val pLabel = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.DKGRAY; textSize = 11f }
        val pValue = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; textSize = 11f }

        fun ensure(space: Float) {
            if (y + space > H - M) {
                doc.finishPage(page)
                pageNo++
                page = doc.startPage(PdfDocument.PageInfo.Builder(W, H, pageNo).create())
                canvas = page.canvas
                y = M + 10f
            }
        }

        canvas.drawText("PHONE INFO – Báo cáo thiết bị", M, y, pTitle); y += 20f
        val date = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())
        canvas.drawText("KNOW YOUR DEVICE • ${Build.MANUFACTURER} ${Build.MODEL} • $date", M, y, pSub); y += 28f

        for (s in sections) {
            ensure(60f)
            val tag = when (s.status) { Status.GOOD -> "Tốt"; Status.WARNING -> "Cần chú ý"; Status.UNKNOWN -> "Không rõ" }
            canvas.drawText("${s.title}  [$tag]", M, y, pHead); y += 16f
            canvas.drawText(s.summary.take(90), M, y, pSub); y += 16f
            for (it in s.items) {
                ensure(18f)
                canvas.drawText(it.label, M, y, pLabel)
                val n = pValue.breakText(it.value, true, W - M - 200f - M, null)
                canvas.drawText(it.value.take(n), M + 200f, y, pValue)
                y += 15f
            }
            y += 14f
        }
        doc.finishPage(page)

        val name = "PhoneInfo_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".pdf"
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, "application/pdf")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
        }
        val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: error("Không tạo được tệp")
        ctx.contentResolver.openOutputStream(uri)?.use { doc.writeTo(it) } ?: error("Không ghi được tệp")
        doc.close()
        return uri
    }
}
