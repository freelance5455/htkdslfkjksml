package com.phoneinfo.app

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.phoneinfo.app.data.BatterySnapshot
import com.phoneinfo.app.data.DeviceRepository
import com.phoneinfo.app.data.PrivData
import com.phoneinfo.app.shizuku.PrivilegedInfo
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {
    val repo = DeviceRepository(app)
    val batterySamples = mutableStateListOf<BatterySnapshot>()
    var battery by mutableStateOf(repo.readBattery())
        private set

    /** Dữ liệu đọc qua Shizuku (null nếu chưa đọc). */
    var priv by mutableStateOf<PrivData?>(null)
        private set
    var privLoading by mutableStateOf(false)
        private set

    fun loadPriv() {
        if (privLoading) return
        privLoading = true
        viewModelScope.launch {
            priv = try { PrivilegedInfo.read() } catch (e: Exception) { null }
            privLoading = false
        }
    }

    /** Chỉ được gọi khi ứng dụng đang mở (xem MainActivity). */
    fun sampleBattery() {
        val b = repo.readBattery()
        battery = b
        if (b.percent != null) {
            batterySamples.add(b)
            if (batterySamples.size > 120) batterySamples.removeAt(0)
        }
    }
}
