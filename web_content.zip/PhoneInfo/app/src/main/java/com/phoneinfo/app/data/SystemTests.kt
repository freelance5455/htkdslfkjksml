package com.phoneinfo.app.data

import android.annotation.SuppressLint
import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.ToneGenerator
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.coroutines.resume

/** ok = true (đạt), false (lỗi), null (trung tính / cần người dùng tự đánh giá) */
data class TestResult(val ok: Boolean?, val message: String)

object SystemTests {

    suspend fun ram(ctx: Context): TestResult = withContext(Dispatchers.Default) {
        val avail = ctx.getSystemService(android.app.ActivityManager::class.java)
            .let { am -> android.app.ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }.availMem }
        val mb = min(64L, avail / 1024 / 1024 / 4).toInt().coerceAtLeast(8)
        try {
            val buf = ByteArray(mb * 1024 * 1024)
            for (i in buf.indices) buf[i] = (i * 31 + 7).toByte()
            var errors = 0L
            for (i in buf.indices) if (buf[i] != (i * 31 + 7).toByte()) errors++
            if (errors == 0L) TestResult(true, "Đã ghi/đọc $mb MB, không có lỗi.")
            else TestResult(false, "Phát hiện $errors byte sai trong $mb MB.")
        } catch (t: Throwable) {
            TestResult(false, "Không cấp phát được $mb MB: ${t.javaClass.simpleName}")
        }
    }

    suspend fun storage(ctx: Context): TestResult = withContext(Dispatchers.IO) {
        val f = File(ctx.cacheDir, "storage_test.bin")
        try {
            val size = 32 * 1024 * 1024
            val chunk = ByteArray(1024 * 1024) { (it * 13).toByte() }
            val t0 = SystemClock.elapsedRealtime()
            f.outputStream().use { o -> repeat(size / chunk.size) { o.write(chunk) }; o.fd.sync() }
            val t1 = SystemClock.elapsedRealtime()
            var read = 0L
            f.inputStream().use { i -> val b = ByteArray(1024 * 1024); while (true) { val n = i.read(b); if (n < 0) break; read += n } }
            val t2 = SystemClock.elapsedRealtime()
            val w = 32.0 / max(1L, t1 - t0) * 1000
            val r = 32.0 / max(1L, t2 - t1) * 1000
            if (read == size.toLong()) TestResult(true, "Ghi %.0f MB/s • Đọc %.0f MB/s (32 MB).".format(w, r))
            else TestResult(false, "Dữ liệu đọc lại không khớp.")
        } catch (t: Throwable) {
            TestResult(false, "Lỗi: ${t.message}")
        } finally {
            f.delete()
        }
    }

    suspend fun speaker(): TestResult {
        return try {
            val tg = ToneGenerator(AudioManager.STREAM_MUSIC, 80)
            tg.startTone(ToneGenerator.TONE_DTMF_5, 900)
            delay(1000)
            tg.release()
            TestResult(null, "Đã phát âm thử. Nếu bạn nghe thấy âm thanh, loa hoạt động.")
        } catch (t: Throwable) {
            TestResult(false, "Không phát được âm thanh: ${t.message}")
        }
    }

    @SuppressLint("MissingPermission")
    suspend fun mic(): TestResult = withContext(Dispatchers.IO) {
        val rate = 44100
        val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBuf <= 0) return@withContext TestResult(false, NOT_SUPPORTED)
        val rec = AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT, minBuf * 2)
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            return@withContext TestResult(false, "Không khởi tạo được micro.")
        }
        // Chỉ đo mức âm lượng trong 3 giây; không lưu hay gửi âm thanh.
        val buf = ShortArray(minBuf)
        var peak = 0
        rec.startRecording()
        val end = SystemClock.elapsedRealtime() + 3000
        while (SystemClock.elapsedRealtime() < end) {
            val n = rec.read(buf, 0, buf.size)
            for (i in 0 until max(0, n)) peak = max(peak, abs(buf[i].toInt()))
        }
        rec.stop()
        rec.release()
        val pct = peak * 100 / 32767
        if (pct >= 2) TestResult(true, "Micro hoạt động. Mức âm lớn nhất: $pct%.")
        else TestResult(false, "Gần như không thu được âm thanh (mức $pct%). Hãy nói to hơn rồi thử lại.")
    }

    @SuppressLint("MissingPermission")
    private suspend fun openClose(cm: CameraManager, id: String): Boolean =
        suspendCancellableCoroutine { cont ->
            try {
                cm.openCamera(id, object : CameraDevice.StateCallback() {
                    override fun onOpened(c: CameraDevice) { c.close(); if (cont.isActive) cont.resume(true) }
                    override fun onDisconnected(c: CameraDevice) { c.close(); if (cont.isActive) cont.resume(false) }
                    override fun onError(c: CameraDevice, error: Int) { c.close(); if (cont.isActive) cont.resume(false) }
                }, Handler(Looper.getMainLooper()))
            } catch (e: Exception) {
                if (cont.isActive) cont.resume(false)
            }
        }

    suspend fun camera(ctx: Context): TestResult {
        val cm = ctx.getSystemService(CameraManager::class.java) ?: return TestResult(false, NOT_SUPPORTED)
        val ids = runCatching { cm.cameraIdList }.getOrDefault(emptyArray())
        if (ids.isEmpty()) return TestResult(false, "Không tìm thấy camera.")
        val lines = mutableListOf<String>()
        var allOk = true
        for (id in ids) {
            val facing = when (cm.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING)) {
                CameraCharacteristics.LENS_FACING_FRONT -> "trước"
                CameraCharacteristics.LENS_FACING_BACK -> "sau"
                else -> "ngoài"
            }
            val ok = openClose(cm, id)
            if (!ok) allOk = false
            lines += "Camera $id ($facing): ${if (ok) "mở được" else "không mở được"}"
        }
        return TestResult(allOk, lines.joinToString("\n"))
    }

    fun batteryHealth(b: BatterySnapshot): TestResult {
        if (b.percent == null) return TestResult(null, NOT_SUPPORTED)
        val problems = mutableListOf<String>()
        if (b.healthGood == false) problems += "Tình trạng pin: ${b.health}"
        if ((b.temperatureC ?: 0f) >= 45f) problems += "Nhiệt độ cao (%.1f °C)".format(b.temperatureC)
        if ((b.voltageV ?: 4f) < 3.3f) problems += "Điện áp thấp"
        return if (problems.isEmpty())
            TestResult(true, "Pin ổn: ${b.health ?: "không rõ sức khỏe"}, ${b.temperatureC?.let { "%.1f °C".format(it) } ?: "không có nhiệt độ"}.")
        else TestResult(false, problems.joinToString("; "))
    }
}
