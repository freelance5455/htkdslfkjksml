package com.phoneinfo.app.data

const val NOT_SUPPORTED = "Không được hệ thống hỗ trợ"

data class InfoItem(val label: String, val value: String)

enum class Status { GOOD, WARNING, UNKNOWN }

data class ReportSection(
    val title: String,
    val status: Status,
    val summary: String,
    val items: List<InfoItem>
)

data class BatterySnapshot(
    val percent: Int?,
    val charging: Boolean?,
    val source: String?,
    val temperatureC: Float?,
    val voltageV: Float?,
    val technology: String?,
    val health: String?,
    val healthGood: Boolean?,
    val cycleCount: Int?,
    val timeMillis: Long = System.currentTimeMillis()
)

data class SensorDef(val name: String, val type: Int, val unit: String)

fun formatBytes(bytes: Long): String {
    val gb = bytes / 1024.0 / 1024.0 / 1024.0
    return if (gb >= 1.0) "%.1f GB".format(gb) else "%.0f MB".format(bytes / 1024.0 / 1024.0)
}

/** Dữ liệu đọc qua Shizuku (chỉ giữ trong bộ nhớ, không gửi đi). */
data class PrivData(
    val device: List<InfoItem>,
    val battery: List<InfoItem>,
    val cpu: List<InfoItem>,
    val wifi: List<InfoItem>
)
