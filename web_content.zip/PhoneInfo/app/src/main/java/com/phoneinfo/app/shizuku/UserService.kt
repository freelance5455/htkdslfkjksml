package com.phoneinfo.app.shizuku

import android.content.Context
import androidx.annotation.Keep
import com.phoneinfo.app.IUserService
import java.util.concurrent.TimeUnit
import kotlin.system.exitProcess

/** Chạy trong tiến trình có quyền shell/root do Shizuku khởi tạo. */
class UserService() : IUserService.Stub() {

    @Keep
    constructor(@Suppress("UNUSED_PARAMETER") context: Context) : this()

    override fun destroy() {
        exitProcess(0)
    }

    override fun exec(command: String): String {
        return try {
            val p = ProcessBuilder("sh", "-c", command).redirectErrorStream(true).start()
            val out = p.inputStream.bufferedReader().use { it.readText() }
            p.waitFor(10, TimeUnit.SECONDS)
            if (out.length > 30000) out.take(30000) else out
        } catch (e: Exception) {
            "ERR: ${e.message}"
        }
    }
}
