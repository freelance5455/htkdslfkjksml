package com.phoneinfo.app.ui

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.sp
import com.phoneinfo.app.MainViewModel
import com.phoneinfo.app.data.PdfExporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun ReportScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(5000); tick++ } }
    val priv = vm.priv
    val sections = remember(tick, vm.battery, priv) {
        vm.repo.buildReport(vm.battery) + listOfNotNull(
            priv?.let {
                com.phoneinfo.app.data.ReportSection(
                    "Đặc quyền (Shizuku)", com.phoneinfo.app.data.Status.GOOD,
                    "Pin chi tiết, CPU, nhiệt độ", it.battery + it.cpu
                )
            }
        )
    }

    var exporting by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var savedUri by remember { mutableStateOf<Uri?>(null) }

    val icons = listOf(
        Icons.Filled.PhoneAndroid, Icons.Filled.Storage, Icons.Filled.BatteryChargingFull,
        Icons.Filled.Memory, Icons.Filled.Wifi, Icons.Filled.Sensors
    )

    ScreenColumn {
        Text("Báo cáo tình trạng", fontSize = 22.sp, color = Pal.Green)

        sections.forEachIndexed { i, s ->
            InfoCard(s.title, icons[i % icons.size], if (i % 2 == 0) Pal.Green else Pal.Blue) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically) {
                    Text(s.summary, color = Pal.Muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
                    StatusChip(s.status)
                }
                s.items.forEach { InfoRow(it) }
            }
        }

        InfoCard("Xuất báo cáo", Icons.Filled.PictureAsPdf, Pal.Blue) {
            Text("Lưu báo cáo thành tệp PDF trong thư mục Downloads. Tệp chỉ nằm trên máy của bạn.",
                color = Pal.Muted, fontSize = 13.sp)
            PrimaryButton(if (exporting) "Đang xuất…" else "Xuất PDF", enabled = !exporting, accent = Pal.Blue) {
                exporting = true
                message = null
                savedUri = null
                scope.launch {
                    val r = runCatching { withContext(Dispatchers.IO) { PdfExporter.export(ctx, sections) } }
                    r.onSuccess { savedUri = it; message = "Đã lưu PDF vào thư mục Downloads." }
                    r.onFailure { message = "Xuất thất bại: ${it.message}" }
                    exporting = false
                }
            }
            message?.let { Text(it, fontSize = 13.sp, color = if (savedUri != null) Pal.Green else Pal.Red) }
            savedUri?.let { uri ->
                TextButton(onClick = {
                    val i = Intent(Intent.ACTION_VIEW)
                        .setDataAndType(uri, "application/pdf")
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    try { ctx.startActivity(i) } catch (e: ActivityNotFoundException) {
                        message = "Không có ứng dụng đọc PDF. Hãy mở tệp trong Downloads."
                    }
                }) { Text("Mở tệp PDF") }
            }
        }
    }
}
