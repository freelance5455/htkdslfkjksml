package com.phoneinfo.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.phoneinfo.app.MainViewModel
import com.phoneinfo.app.data.formatBytes
import com.phoneinfo.app.shizuku.RamBooster
import com.phoneinfo.app.shizuku.ShizukuManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(vm: MainViewModel) {
    val repo = vm.repo
    val deviceItems = remember { repo.deviceItems() }
    val sensors = remember { repo.sensorItems() }
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(3000); tick++ } }
    val mem = remember(tick) { repo.memory() }
    val st = remember(tick) { repo.storage() }
    val net = remember(tick) { repo.networkSummary() }
    val b = vm.battery
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var boosting by remember { mutableStateOf(false) }
    var boostMsg by remember { mutableStateOf<String?>(null) }

    ScreenColumn {
        Column {
            Text("PHONE INFO", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = Pal.Green)
            Text("KNOW YOUR DEVICE", fontSize = 12.sp, letterSpacing = 4.sp, color = Pal.Blue)
        }

        InfoCard("Pin", Icons.Filled.PhoneAndroid, Pal.Green) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                RingGauge(
                    fraction = (b.percent ?: 0) / 100f,
                    centerText = b.percent?.let { "$it%" } ?: "—",
                    sub = when (b.charging) { true -> "Đang sạc"; false -> "Không sạc"; null -> "Không rõ" },
                    color = if ((b.percent ?: 100) <= 20 && b.charging != true) Pal.Red else Pal.Green
                )
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile("Tên thiết bị", repo.deviceName(), Icons.Filled.PhoneAndroid, Pal.Green, Modifier.weight(1f))
            StatTile("Hãng", repo.manufacturer(), Icons.Filled.Business, Pal.Blue, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile("Phiên bản Android", repo.androidVersion(), Icons.Filled.Android, Pal.Green, Modifier.weight(1f))
            StatTile("Kết nối mạng", net, Icons.Filled.Wifi, Pal.Blue, Modifier.weight(1f))
        }

        InfoCard("RAM & Bộ nhớ", Icons.Filled.Memory, Pal.Blue) {
            val ramUsed = mem.first - mem.second
            ProgressBarRow("RAM", "${formatBytes(ramUsed)} / ${formatBytes(mem.first)}",
                ramUsed.toFloat() / mem.first, Pal.Blue)
            val stUsed = st.first - st.second
            ProgressBarRow("Bộ nhớ trong", "${formatBytes(stUsed)} / ${formatBytes(st.first)}",
                stUsed.toFloat() / st.first, Pal.Green)
        }

        InfoCard("Dọn RAM", Icons.Filled.Speed, Pal.Green) {
            Text(
                "Đóng các ứng dụng chạy nền để giải phóng RAM. Android vốn tự quản lý RAM nên hiệu quả thường " +
                    "chỉ tạm thời, và ứng dụng bị đóng sẽ mở lại chậm hơn.",
                color = Pal.Muted, fontSize = 12.sp
            )
            Text(
                if (ShizukuManager.state == ShizukuManager.State.READY)
                    "Chế độ: Shizuku — đóng toàn bộ tiến trình nền an toàn" + if (ShizukuManager.isRoot) " + xóa bộ nhớ đệm (root)" else ""
                else "Chế độ thường: đóng ứng dụng nền do bạn cài (kết nối Shizuku để dọn sâu hơn)",
                fontSize = 12.sp, color = Pal.Blue
            )
            boostMsg?.let { Text(it, fontSize = 13.sp, color = Pal.Green) }
            PrimaryButton(if (boosting) "Đang dọn…" else "Dọn RAM ngay", enabled = !boosting) {
                boosting = true
                boostMsg = null
                scope.launch {
                    val r = try { RamBooster.boost(ctx, repo) } catch (e: Exception) { null }
                    boostMsg = if (r == null) "Dọn RAM thất bại." else {
                        val diff = r.afterAvail - r.beforeAvail
                        "RAM trống: ${formatBytes(r.beforeAvail)} → ${formatBytes(r.afterAvail)} " +
                            (if (diff > 1024 * 1024) "(+${formatBytes(diff)})" else "(thay đổi không đáng kể)") +
                            " • Chế độ ${r.mode}"
                    }
                    boosting = false
                    tick++
                }
            }
        }

        InfoCard("Thông tin thiết bị", Icons.Filled.Storage, Pal.Green) {
            deviceItems.forEach { InfoRow(it) }
        }

        InfoCard("Cảm biến có trên máy", Icons.Filled.Sensors, Pal.Blue) {
            sensors.forEach { InfoRow(it) }
        }
    }
}
