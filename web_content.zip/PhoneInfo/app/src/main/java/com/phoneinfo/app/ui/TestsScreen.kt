package com.phoneinfo.app.ui

import android.Manifest
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import com.phoneinfo.app.MainViewModel
import com.phoneinfo.app.data.DeviceRepository
import com.phoneinfo.app.data.InfoItem
import com.phoneinfo.app.data.NOT_SUPPORTED
import com.phoneinfo.app.data.SensorDef
import com.phoneinfo.app.data.SystemTests
import com.phoneinfo.app.data.TestResult
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import kotlin.math.atan2

class TestState {
    var result by mutableStateOf<TestResult?>(null)
    var running by mutableStateOf(false)

    fun run(scope: CoroutineScope, block: suspend () -> TestResult) {
        if (running) return
        running = true
        result = null
        scope.launch {
            result = try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (t: Throwable) {
                TestResult(false, "Lỗi: ${t.message}")
            }
            running = false
        }
    }
}

private const val DENIED = "Bạn đã từ chối quyền. Các chức năng khác vẫn dùng bình thường."

@Composable
private fun TestCard(
    title: String, desc: String, icon: ImageVector, accent: Color,
    state: TestState, buttonLabel: String = "Chạy kiểm tra", onRun: () -> Unit
) {
    InfoCard(title, icon, accent) {
        Text(desc, color = Pal.Muted, fontSize = 13.sp)
        state.result?.let { r ->
            Text(
                r.message, fontSize = 13.sp,
                color = when (r.ok) { true -> Pal.Green; false -> Pal.Red; null -> Pal.Text }
            )
        }
        PrimaryButton(if (state.running) "Đang chạy…" else buttonLabel, enabled = !state.running, accent = accent, onClick = onRun)
    }
}

@Composable
fun TestsScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    val ram = remember { TestState() }
    val storage = remember { TestState() }
    val screen = remember { TestState() }
    val touch = remember { TestState() }
    val speaker = remember { TestState() }
    val mic = remember { TestState() }
    val camera = remember { TestState() }
    val batt = remember { TestState() }
    var screenDialog by remember { mutableStateOf(false) }
    var touchDialog by remember { mutableStateOf(false) }

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) mic.run(scope) { SystemTests.mic() } else mic.result = TestResult(null, DENIED)
    }
    val camLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) camera.run(scope) { SystemTests.camera(ctx) } else camera.result = TestResult(null, DENIED)
    }
    fun granted(p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

    ScreenColumn {
        Text("Kiểm tra hệ thống", fontSize = 22.sp, color = Pal.Green)

        TestCard("Kiểm tra RAM", "Ghi rồi đọc lại một vùng RAM để phát hiện lỗi dữ liệu.",
            Icons.Filled.Memory, Pal.Green, ram) { ram.run(scope) { SystemTests.ram(ctx) } }

        TestCard("Kiểm tra bộ nhớ", "Ghi/đọc tệp thử 32 MB để đo tốc độ và kiểm tra tính toàn vẹn (tệp được xóa ngay).",
            Icons.Filled.Storage, Pal.Blue, storage) { storage.run(scope) { SystemTests.storage(ctx) } }

        TestCard("Kiểm tra màn hình", "Hiển thị lần lượt đỏ, xanh lá, xanh dương, trắng, đen. Quan sát điểm chết hoặc ngả màu.",
            Icons.Filled.Fullscreen, Pal.Green, screen, "Bắt đầu") { screenDialog = true }

        TestCard("Kiểm tra cảm ứng", "Chạm hoặc vuốt để tô sáng toàn bộ các ô trên màn hình.",
            Icons.Filled.TouchApp, Pal.Blue, touch, "Bắt đầu") { touchDialog = true }

        TestCard("Kiểm tra loa", "Phát một âm thử ngắn. Hãy tăng âm lượng media.",
            Icons.Filled.VolumeUp, Pal.Green, speaker, "Phát âm thử") { speaker.run(scope) { SystemTests.speaker() } }

        TestCard("Kiểm tra micro", "Đo mức âm lượng trong 3 giây (hãy nói hoặc vỗ tay). Âm thanh không được lưu hay gửi đi. Cần cấp quyền micro.",
            Icons.Filled.Mic, Pal.Blue, mic, "Cho phép & kiểm tra") {
            if (granted(Manifest.permission.RECORD_AUDIO)) mic.run(scope) { SystemTests.mic() }
            else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }

        TestCard("Kiểm tra camera", "Mở thử từng camera rồi đóng lại (không chụp, không lưu ảnh). Cần cấp quyền camera.",
            Icons.Filled.CameraAlt, Pal.Green, camera, "Cho phép & kiểm tra") {
            if (granted(Manifest.permission.CAMERA)) camera.run(scope) { SystemTests.camera(ctx) }
            else camLauncher.launch(Manifest.permission.CAMERA)
        }

        TestCard("Kiểm tra tình trạng pin", "Đánh giá sức khỏe, nhiệt độ và điện áp pin hiện tại.",
            Icons.Filled.BatteryChargingFull, Pal.Blue, batt) { batt.result = SystemTests.batteryHealth(vm.battery) }

        InfoCard("Kiểm tra cảm biến", Icons.Filled.Sensors, Pal.Green) {
            Text("Nhấn “Thử” rồi di chuyển máy, che cảm biến ánh sáng/tiệm cận hoặc xoay máy để xem giá trị thay đổi.",
                color = Pal.Muted, fontSize = 13.sp)
            DeviceRepository.SENSOR_DEFS.forEach { SensorTestRow(it) }
            vm.repo.sensorItems().filter { it.label == "Cảm biến vân tay" }.forEach { InfoRow(it) }
        }
    }

    if (screenDialog) {
        ScreenTestDialog {
            screenDialog = false
            screen.result = TestResult(null, "Đã chạy xong. Nếu thấy điểm chết, vệt sáng hoặc ngả màu, màn hình có thể có lỗi.")
        }
    }
    if (touchDialog) {
        TouchTestDialog { allTouched ->
            touchDialog = false
            touch.result = if (allTouched) TestResult(true, "Tất cả các ô đều nhận cảm ứng.")
            else TestResult(false, "Còn ô chưa nhận cảm ứng. Hãy thử lại và vuốt qua mọi vùng.")
        }
    }
}

@Composable
private fun ScreenTestDialog(onDone: () -> Unit) {
    val colors = listOf(Color.Red, Color.Green, Color.Blue, Color.White, Color.Black)
    var idx by remember { mutableIntStateOf(0) }
    Dialog(
        onDismissRequest = onDone,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        Box(
            Modifier.fillMaxSize().background(colors[idx]).clickable(
                interactionSource = remember { MutableInteractionSource() }, indication = null
            ) { if (idx < colors.lastIndex) idx++ else onDone() },
            contentAlignment = Alignment.BottomCenter
        ) {
            Text("Chạm để đổi màu (${idx + 1}/${colors.size})", color = Color.Gray,
                modifier = Modifier.padding(bottom = 56.dp))
        }
    }
}

@Composable
private fun TouchTestDialog(onFinish: (Boolean) -> Unit) {
    val cols = 6
    val rows = 10
    val touched = remember { mutableStateListOf<Boolean>().apply { repeat(cols * rows) { add(false) } } }
    val count = touched.count { it }
    Dialog(
        onDismissRequest = { onFinish(count == cols * rows) },
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        Column(Modifier.fillMaxSize().background(Color.Black)) {
            Box(
                Modifier.weight(1f).fillMaxWidth().pointerInput(Unit) {
                    awaitPointerEventScope {
                        while (true) {
                            val ev = awaitPointerEvent()
                            ev.changes.forEach { c ->
                                if (size.width > 0 && size.height > 0) {
                                    val cx = (c.position.x / size.width * cols).toInt().coerceIn(0, cols - 1)
                                    val cy = (c.position.y / size.height * rows).toInt().coerceIn(0, rows - 1)
                                    touched[cy * cols + cx] = true
                                }
                                c.consume()
                            }
                        }
                    }
                }
            ) {
                Canvas(Modifier.fillMaxSize()) {
                    val cw = size.width / cols
                    val ch = size.height / rows
                    for (r in 0 until rows) for (c in 0 until cols) {
                        drawRect(
                            color = if (touched[r * cols + c]) Pal.Green.copy(alpha = 0.75f) else Pal.SurfaceHi,
                            topLeft = Offset(c * cw + 2f, r * ch + 2f),
                            size = Size(cw - 4f, ch - 4f)
                        )
                    }
                }
            }
            Row(
                Modifier.fillMaxWidth().background(Pal.Surface).navigationBarsPadding().padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    if (count == cols * rows) "Hoàn tất ✔" else "$count/${cols * rows} ô",
                    color = if (count == cols * rows) Pal.Green else Pal.Text,
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = { onFinish(count == cols * rows) }) { Text("Đóng") }
            }
        }
    }
}

@Composable
private fun SensorTestRow(def: SensorDef) {
    val ctx = LocalContext.current
    val sm = remember { ctx.getSystemService(SensorManager::class.java) }
    val sensor = remember { sm.getDefaultSensor(def.type) }
    var active by remember { mutableStateOf(false) }
    var values by remember { mutableStateOf<FloatArray?>(null) }

    DisposableEffect(active) {
        if (active && sensor != null) {
            val l = object : SensorEventListener {
                override fun onSensorChanged(e: SensorEvent) { values = e.values.clone() }
                override fun onAccuracyChanged(s: Sensor?, accuracy: Int) {}
            }
            sm.registerListener(l, sensor, SensorManager.SENSOR_DELAY_UI)
            onDispose { sm.unregisterListener(l) }
        } else {
            onDispose { }
        }
    }

    val v = values
    val text = when {
        sensor == null -> NOT_SUPPORTED
        !active -> sensor.name
        v == null -> "Đang chờ dữ liệu…"
        else -> formatSensor(def, sensor, v)
    }
    Column {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(def.name, modifier = Modifier.weight(1f), fontSize = 14.sp)
            if (sensor != null) {
                TextButton(onClick = { active = !active; if (!active) values = null }) {
                    Text(if (active) "Dừng" else "Thử")
                }
            }
        }
        Text(text, fontSize = 12.sp, color = if (sensor == null) Pal.Amber else Pal.Muted)
    }
}

private fun formatSensor(def: SensorDef, s: Sensor, v: FloatArray): String = when (def.type) {
    Sensor.TYPE_LIGHT -> "%.0f lx".format(v[0])
    Sensor.TYPE_PROXIMITY ->
        (if (v[0] < s.maximumRange) "GẦN" else "XA") + " • %.1f cm".format(v[0])
    Sensor.TYPE_MAGNETIC_FIELD -> {
        val heading = (360 - Math.toDegrees(atan2(v[0].toDouble(), v[1].toDouble())) + 360) % 360
        "x %.1f  y %.1f  z %.1f µT\nHướng ≈ %.0f° (giữ máy nằm ngang)".format(v[0], v[1], v[2], heading)
    }
    else -> "x %.2f  y %.2f  z %.2f %s".format(v[0], v[1], v[2], def.unit)
}
