package com.phoneinfo.app.data

import android.Manifest
import android.app.ActivityManager
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorManager
import android.hardware.display.DisplayManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiInfo
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.telephony.TelephonyManager
import android.util.DisplayMetrics
import android.view.Display
import android.view.WindowManager
import androidx.core.content.ContextCompat
import java.net.Inet4Address

/**
 * Đọc dữ liệu trực tiếp từ API chính thức của Android.
 * Không đọc IMEI, số sê-ri, vị trí, tên Wi-Fi, danh bạ, tin nhắn hay tài khoản.
 */
class DeviceRepository(context: Context) {
    private val ctx: Context = context.applicationContext

    companion object {
        val SENSOR_DEFS = listOf(
            SensorDef("Gia tốc kế", Sensor.TYPE_ACCELEROMETER, "m/s²"),
            SensorDef("Con quay hồi chuyển", Sensor.TYPE_GYROSCOPE, "rad/s"),
            SensorDef("Cảm biến ánh sáng", Sensor.TYPE_LIGHT, "lx"),
            SensorDef("Cảm biến tiệm cận", Sensor.TYPE_PROXIMITY, "cm"),
            SensorDef("La bàn (từ trường)", Sensor.TYPE_MAGNETIC_FIELD, "µT")
        )
    }

    // ---------- Tổng quan ----------
    fun deviceName(): String {
        val n = runCatching { Settings.Global.getString(ctx.contentResolver, "device_name") }.getOrNull()
        return if (!n.isNullOrBlank()) n else "${manufacturer()} ${Build.MODEL}"
    }

    fun manufacturer(): String = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }

    fun androidVersion(): String = "Android ${Build.VERSION.RELEASE}"

    /** (tổng, còn trống) */
    fun memory(): Pair<Long, Long> {
        val am = ctx.getSystemService(ActivityManager::class.java)
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return mi.totalMem to mi.availMem
    }

    /** (tổng, còn trống) */
    fun storage(): Pair<Long, Long> {
        val s = StatFs(Environment.getDataDirectory().path)
        return s.totalBytes to s.availableBytes
    }

    // ---------- Thiết bị ----------
    @Suppress("DEPRECATION")
    fun resolution(): Pair<Int, Int> {
        val wm = ctx.getSystemService(WindowManager::class.java)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val b = wm.maximumWindowMetrics.bounds
            b.width() to b.height()
        } else {
            val dm = DisplayMetrics()
            wm.defaultDisplay.getRealMetrics(dm)
            dm.widthPixels to dm.heightPixels
        }
    }

    private fun processorName(): String {
        val soc = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            listOf(Build.SOC_MANUFACTURER, Build.SOC_MODEL)
                .filter { it.isNotBlank() && it != Build.UNKNOWN }
                .joinToString(" ")
        } else ""
        return soc.ifBlank { Build.HARDWARE }.ifBlank { NOT_SUPPORTED }
    }

    fun deviceItems(): List<InfoItem> {
        val (w, h) = resolution()
        val dm = ctx.resources.displayMetrics
        val display = ctx.getSystemService(DisplayManager::class.java)?.getDisplay(Display.DEFAULT_DISPLAY)
        val hz = display?.refreshRate?.let { "%.0f Hz".format(it) } ?: NOT_SUPPORTED
        val (ramTotal, _) = memory()
        val (storTotal, _) = storage()
        return listOf(
            InfoItem("Nhà sản xuất", manufacturer()),
            InfoItem("Tên thiết bị", deviceName()),
            InfoItem("Model", Build.MODEL),
            InfoItem("Phiên bản Android", Build.VERSION.RELEASE),
            InfoItem("Phiên bản SDK", Build.VERSION.SDK_INT.toString()),
            InfoItem("Bản vá bảo mật", Build.VERSION.SECURITY_PATCH.ifBlank { NOT_SUPPORTED }),
            InfoItem("Kiến trúc CPU", Build.SUPPORTED_ABIS.joinToString(", ").ifBlank { NOT_SUPPORTED }),
            InfoItem("Bộ xử lý", processorName()),
            InfoItem("Số lõi CPU", Runtime.getRuntime().availableProcessors().toString()),
            InfoItem("Độ phân giải", "$w × $h px"),
            InfoItem("Tần số quét", hz),
            InfoItem("Mật độ điểm ảnh", "${dm.densityDpi} dpi"),
            InfoItem("RAM", formatBytes(ramTotal)),
            InfoItem("Bộ nhớ trong", formatBytes(storTotal))
        )
    }

    // ---------- Pin ----------
    fun readBattery(): BatterySnapshot {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            ?: return BatterySnapshot(null, null, null, null, null, null, null, null, null)

        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else null

        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = if (status == -1) null
        else status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL

        val source = when (i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)) {
            BatteryManager.BATTERY_PLUGGED_AC -> "Sạc AC"
            BatteryManager.BATTERY_PLUGGED_USB -> "USB"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Sạc không dây"
            0 -> "Không cắm sạc"
            else -> "Khác"
        }

        val t = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        val v = i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1)

        val healthCode = i.getIntExtra(BatteryManager.EXTRA_HEALTH, -1)
        val health = when (healthCode) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "Tốt"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Quá nóng"
            BatteryManager.BATTERY_HEALTH_DEAD -> "Hỏng"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Quá áp"
            BatteryManager.BATTERY_HEALTH_COLD -> "Quá lạnh"
            BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "Lỗi không xác định"
            else -> null
        }

        val cycles = if (Build.VERSION.SDK_INT >= 34) {
            i.getIntExtra(BatteryManager.EXTRA_CYCLE_COUNT, -1).takeIf { it >= 0 }
        } else null

        return BatterySnapshot(
            percent = pct,
            charging = charging,
            source = source,
            temperatureC = if (t != Int.MIN_VALUE) t / 10f else null,
            voltageV = if (v > 0) v / 1000f else null,
            technology = i.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY)?.takeIf { it.isNotBlank() },
            health = health,
            healthGood = health?.let { healthCode == BatteryManager.BATTERY_HEALTH_GOOD },
            cycleCount = cycles
        )
    }

    fun batteryItems(b: BatterySnapshot): List<InfoItem> = listOf(
        InfoItem("Phần trăm pin", b.percent?.let { "$it%" } ?: NOT_SUPPORTED),
        InfoItem("Trạng thái", when (b.charging) { true -> "Đang sạc"; false -> "Không sạc"; null -> NOT_SUPPORTED }),
        InfoItem("Nguồn cắm", b.source ?: NOT_SUPPORTED),
        InfoItem("Nhiệt độ", b.temperatureC?.let { "%.1f °C".format(it) } ?: NOT_SUPPORTED),
        InfoItem("Điện áp", b.voltageV?.let { "%.2f V".format(it) } ?: NOT_SUPPORTED),
        InfoItem("Công nghệ pin", b.technology ?: NOT_SUPPORTED),
        InfoItem("Tình trạng sức khỏe", b.health ?: NOT_SUPPORTED),
        InfoItem("Số chu kỳ sạc", b.cycleCount?.toString() ?: NOT_SUPPORTED)
    )

    // ---------- Mạng ----------
    private val cm: ConnectivityManager get() = ctx.getSystemService(ConnectivityManager::class.java)

    private fun activeCaps(): NetworkCapabilities? {
        val n = cm.activeNetwork ?: return null
        return cm.getNetworkCapabilities(n)
    }

    fun isInternetOk(): Boolean =
        activeCaps()?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true

    fun hasPhoneStatePermission(): Boolean =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED

    fun networkSummary(): String {
        val c = activeCaps() ?: return "Ngoại tuyến"
        val t = when {
            c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Di động"
            c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> "Khác"
        }
        return t + if (isInternetOk()) " • Online" else " • Không Internet"
    }

    @Suppress("DEPRECATION", "MissingPermission")
    private fun cellularType(): String {
        if (!hasPhoneStatePermission()) return "Cần cấp quyền (tùy chọn)"
        val tm = ctx.getSystemService(TelephonyManager::class.java) ?: return NOT_SUPPORTED
        return runCatching {
            when (tm.dataNetworkType) {
                TelephonyManager.NETWORK_TYPE_NR -> "5G"
                TelephonyManager.NETWORK_TYPE_LTE -> "4G (LTE)"
                TelephonyManager.NETWORK_TYPE_HSPAP, TelephonyManager.NETWORK_TYPE_HSPA,
                TelephonyManager.NETWORK_TYPE_HSDPA, TelephonyManager.NETWORK_TYPE_HSUPA,
                TelephonyManager.NETWORK_TYPE_UMTS, TelephonyManager.NETWORK_TYPE_EVDO_0,
                TelephonyManager.NETWORK_TYPE_EVDO_A, TelephonyManager.NETWORK_TYPE_EVDO_B -> "3G"
                TelephonyManager.NETWORK_TYPE_EDGE, TelephonyManager.NETWORK_TYPE_GPRS,
                TelephonyManager.NETWORK_TYPE_CDMA, TelephonyManager.NETWORK_TYPE_1xRTT -> "2G"
                TelephonyManager.NETWORK_TYPE_UNKNOWN -> "Không có dữ liệu di động"
                else -> NOT_SUPPORTED
            }
        }.getOrDefault(NOT_SUPPORTED)
    }

    @Suppress("DEPRECATION")
    private fun wifiName(wifiOn: Boolean): String {
        if (!wifiOn) return "—"
        val ok = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!ok) return "Cần quyền vị trí (tab Quyền)"
        val ssid = runCatching { ctx.getSystemService(WifiManager::class.java).connectionInfo.ssid }
            .getOrNull()?.trim('"')
        return if (ssid.isNullOrBlank() || ssid == "<unknown ssid>") NOT_SUPPORTED else ssid
    }

    fun networkItems(): List<InfoItem> {
        val caps = activeCaps()
        val wifiOn = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        val cellOn = caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true
        val wifi = caps?.takeIf { wifiOn }?.transportInfo as? WifiInfo

        val ip = cm.activeNetwork
            ?.let { cm.getLinkProperties(it) }
            ?.linkAddresses?.map { it.address }
            ?.firstOrNull { it is Inet4Address && !it.isLoopbackAddress }
            ?.hostAddress

        val bt = runCatching {
            val adapter = ctx.getSystemService(BluetoothManager::class.java)?.adapter
            when {
                adapter == null -> "Thiết bị không có Bluetooth"
                adapter.isEnabled -> "Đang bật"
                else -> "Đang tắt"
            }
        }.getOrDefault(NOT_SUPPORTED)

        return listOf(
            InfoItem("Wi-Fi", if (wifiOn) "Đã kết nối" else "Không kết nối"),
            InfoItem("Tên Wi-Fi", wifiName(wifiOn)),
            InfoItem("Tốc độ liên kết Wi-Fi",
                wifi?.linkSpeed?.takeIf { it > 0 }?.let { "$it Mbps" } ?: if (wifiOn) NOT_SUPPORTED else "—"),
            InfoItem("Mạng di động", if (cellOn) "Đang dùng" else "Không dùng"),
            InfoItem("Loại mạng di động", cellularType()),
            InfoItem("Trạng thái Internet", if (isInternetOk()) "Có kết nối Internet" else "Không có Internet"),
            InfoItem("Địa chỉ IP nội bộ", ip ?: NOT_SUPPORTED),
            InfoItem("Bluetooth", bt)
        )
    }

    // ---------- Cảm biến ----------
    fun sensorItems(): List<InfoItem> {
        val sm = ctx.getSystemService(SensorManager::class.java)
        val list = SENSOR_DEFS.map {
            InfoItem(it.name, if (sm.getDefaultSensor(it.type) != null) "Có" else "Không có")
        }
        val fp = if (ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_FINGERPRINT)) "Có" else "Không có"
        return list + InfoItem("Cảm biến vân tay", fp)
    }

    // ---------- Báo cáo ----------
    fun buildReport(b: BatterySnapshot): List<ReportSection> {
        val (ramT, ramA) = memory()
        val (stT, stA) = storage()
        val sensors = sensorItems()
        val sensorCount = sensors.count { it.value == "Có" }

        val dev = deviceItems()
        val hardware = ReportSection(
            "Phần cứng", Status.GOOD, "${Build.MODEL} • ${Runtime.getRuntime().availableProcessors()} lõi",
            dev.filter { it.label in listOf("Nhà sản xuất", "Model", "Bộ xử lý", "Số lõi CPU", "Kiến trúc CPU", "Độ phân giải", "Tần số quét", "Mật độ điểm ảnh") }
        )
        val software = ReportSection(
            "Phần mềm", Status.GOOD, "Android ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})",
            dev.filter { it.label in listOf("Phiên bản Android", "Phiên bản SDK", "Bản vá bảo mật") }
        )
        val batteryWarn = b.healthGood == false || (b.temperatureC ?: 0f) >= 45f
        val battery = ReportSection(
            "Pin",
            when { b.percent == null -> Status.UNKNOWN; batteryWarn -> Status.WARNING; else -> Status.GOOD },
            b.percent?.let { "$it% • ${b.health ?: "Không rõ sức khỏe"}" } ?: NOT_SUPPORTED,
            batteryItems(b)
        )
        val lowMem = ramA * 100 / ramT < 10 || stA * 100 / stT < 10
        val memory = ReportSection(
            "Bộ nhớ", if (lowMem) Status.WARNING else Status.GOOD,
            "RAM trống ${formatBytes(ramA)} • Lưu trữ trống ${formatBytes(stA)}",
            listOf(
                InfoItem("RAM tổng", formatBytes(ramT)), InfoItem("RAM còn trống", formatBytes(ramA)),
                InfoItem("Bộ nhớ trong tổng", formatBytes(stT)), InfoItem("Bộ nhớ trong còn trống", formatBytes(stA))
            )
        )
        val network = ReportSection(
            "Mạng", if (isInternetOk()) Status.GOOD else Status.WARNING, networkSummary(), networkItems()
        )
        val sensor = ReportSection(
            "Cảm biến", if (sensorCount > 0) Status.GOOD else Status.UNKNOWN,
            "$sensorCount/${sensors.size} cảm biến có mặt", sensors
        )
        return listOf(hardware, software, battery, memory, network, sensor)
    }
}
