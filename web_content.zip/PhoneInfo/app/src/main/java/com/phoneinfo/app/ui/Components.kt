package com.phoneinfo.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.phoneinfo.app.data.InfoItem
import com.phoneinfo.app.data.NOT_SUPPORTED
import com.phoneinfo.app.data.Status

@Composable
fun ScreenColumn(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        content = content
    )
}

@Composable
fun InfoCard(
    title: String,
    icon: ImageVector,
    accent: Color = Pal.Green,
    content: @Composable ColumnScope.() -> Unit
) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { visible = true }
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(450)) + slideInVertically(tween(450)) { it / 8 }
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Pal.Surface),
            border = BorderStroke(1.dp, accent.copy(alpha = 0.28f))
        ) {
            Column(
                Modifier.padding(16.dp).animateContentSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(36.dp).clip(RoundedCornerShape(10.dp)).background(accent.copy(alpha = 0.16f)),
                        contentAlignment = Alignment.Center
                    ) { Icon(icon, null, tint = accent, modifier = Modifier.size(20.dp)) }
                    Spacer(Modifier.width(12.dp))
                    Text(title, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                }
                content()
            }
        }
    }
}

@Composable
fun InfoRow(item: InfoItem) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.Top) {
        Text(item.label, color = Pal.Muted, fontSize = 13.sp, modifier = Modifier.weight(1f))
        Text(
            item.value, fontSize = 13.sp, textAlign = TextAlign.End,
            color = if (item.value == NOT_SUPPORTED) Pal.Amber else Pal.Text,
            modifier = Modifier.weight(1.3f)
        )
    }
}

@Composable
fun StatTile(title: String, value: String, icon: ImageVector, accent: Color, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Pal.Surface),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.28f))
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Icon(icon, null, tint = accent, modifier = Modifier.size(22.dp))
            Text(title, color = Pal.Muted, fontSize = 12.sp)
            Text(value, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 2)
        }
    }
}

@Composable
fun ProgressBarRow(label: String, valueText: String, fraction: Float, accent: Color) {
    val anim by animateFloatAsState(fraction.coerceIn(0f, 1f), tween(800), label = "bar")
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(Modifier.fillMaxWidth()) {
            Text(label, color = Pal.Muted, fontSize = 13.sp, modifier = Modifier.weight(1f))
            Text(valueText, fontSize = 13.sp)
        }
        Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(Pal.SurfaceHi)) {
            Box(Modifier.fillMaxHeight().fillMaxWidth(anim).clip(RoundedCornerShape(4.dp)).background(accent))
        }
    }
}

@Composable
fun RingGauge(fraction: Float, centerText: String, sub: String, color: Color, diameter: Dp = 150.dp) {
    val anim by animateFloatAsState(fraction.coerceIn(0f, 1f), tween(900), label = "ring")
    Box(Modifier.size(diameter), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 14.dp.toPx()
            val tl = Offset(stroke / 2, stroke / 2)
            val sz = Size(size.width - stroke, size.height - stroke)
            drawArc(Pal.SurfaceHi, 135f, 270f, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
            drawArc(color, 135f, 270f * anim, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(centerText, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text(sub, fontSize = 12.sp, color = Pal.Muted)
        }
    }
}

@Composable
fun StatusChip(status: Status) {
    val (txt, col) = when (status) {
        Status.GOOD -> "Tốt" to Pal.Green
        Status.WARNING -> "Cần chú ý" to Pal.Amber
        Status.UNKNOWN -> "Không rõ" to Pal.Muted
    }
    Box(
        Modifier.clip(RoundedCornerShape(50)).background(col.copy(alpha = 0.16f)).padding(horizontal = 10.dp, vertical = 4.dp)
    ) { Text(txt, color = col, fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
}

@Composable
fun LineChart(values: List<Float>, minY: Float, maxY: Float, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier.fillMaxWidth().height(150.dp)) {
        val w = size.width
        val h = size.height
        for (i in 0..4) {
            val y = h * i / 4f
            drawLine(Pal.SurfaceHi, Offset(0f, y), Offset(w, y), strokeWidth = 1.dp.toPx())
        }
        if (values.size < 2) return@Canvas
        val range = (maxY - minY).coerceAtLeast(0.001f)
        fun pt(i: Int): Offset {
            val x = w * i / (values.size - 1).toFloat()
            val y = h * (1f - ((values[i] - minY) / range).coerceIn(0f, 1f))
            return Offset(x, y)
        }
        val line = Path().apply {
            moveTo(pt(0).x, pt(0).y)
            for (i in 1 until values.size) lineTo(pt(i).x, pt(i).y)
        }
        val fill = Path().apply {
            addPath(line)
            lineTo(w, h); lineTo(0f, h); close()
        }
        drawPath(fill, Brush.verticalGradient(listOf(color.copy(alpha = 0.35f), Color.Transparent)))
        drawPath(line, color, style = Stroke(2.5.dp.toPx(), cap = StrokeCap.Round))
    }
}
