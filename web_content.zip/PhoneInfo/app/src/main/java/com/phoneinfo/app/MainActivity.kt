package com.phoneinfo.app

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.phoneinfo.app.ui.PhoneInfoApp
import com.phoneinfo.app.shizuku.ShizukuManager
import com.phoneinfo.app.ui.PhoneInfoTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        ShizukuManager.start(applicationContext)
        // Chỉ lấy mẫu pin khi ứng dụng hiển thị trên màn hình (STARTED); dừng khi ẩn.
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                while (true) {
                    vm.sampleBattery()
                    delay(5000)
                }
            }
        }
        setContent { PhoneInfoTheme { PhoneInfoApp(vm) } }
    }

    override fun onResume() {
        super.onResume()
        ShizukuManager.refresh()
    }
}
