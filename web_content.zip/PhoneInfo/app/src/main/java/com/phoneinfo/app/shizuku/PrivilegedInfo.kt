package com.phoneinfo.app.shizuku

import com.phoneinfo.app.data.InfoItem
import com.phoneinfo.app.data.NOT_SUPPORTED
import com.phoneinfo.app.data.PrivData

/**
 * Đọc thông tin mà ứng dụng thường không truy cập được, thông qua lệnh shell của Shizuku.
 * Kết quả chỉ hiển thị trên màn hình, không lưu và không gửi đi đâu.
 * Lưu ý: cấu trúc lệnh/đường dẫn sysfs khác nhau theo hãng và đời Android nên có mục có thể trống.
 */
object PrivilegedInfo {
    private const val BAT = "/sys/class/power_supply/battery"

    private suspend fun sh(c: String) = ShizukuManager.exec(c).trim()

    private fun bad(s: String) = s.isBlank() || s.startsWith("ERR:") || s.contains("No such file") ||
        s.contains("Permission denied") || s.contains("not found")

    private suspend fun file(path: String): String? = sh("cat $path 2>&1").takeIf { !bad(it) }

    private suspend fun prop(name: String): String? = sh("getprop $name").takeIf { !bad(it) }

    private fun field(text: String, key: String): String? =
        Regex("(?m)^\\s*" + Regex.escape(key) + ":\\s*(.+)$").find(text)?.groupValues?.get(1)?.trim()

    private suspend fun imei(): String? {
        val tries = listOf(
            "service call iphonesubinfo 1 s16 com.android.shell",
            "service call iphonesubinfo 1 s16 com.android.shell s16 null",
            "service call iphonesubinfo 3 i32 0 s16 com.android.shell"
        )
        for (c in tries) {
            val out = sh(c)
            val sb = StringBuilder()
            Regex("'([^']*)'").findAll(out).forEach { sb.append(it.groupValues[1]) }
            val digits = sb.toString().filter { it.isDigit() }
            if (digits.length >= 15) return digits.take(15)
        }
        return null
    }

    private fun healthName(code: Int?): String? = when (code) {
        2 -> "Tốt"; 3 -> "Quá nóng"; 4 -> "Hỏng"; 5 -> "Quá áp"; 6 -> "Lỗi không xác định"; 7 -> "Quá lạnh"
        else -> null
    }

    suspend fun read(): PrivData {
        // --- Thiết bị / hệ thống ---
        val serial = prop("ro.serialno") ?: prop("ro.boot.serialno")
        val uptime = file("/proc/uptime")?.substringBefore(' ')?.toDoubleOrNull()
            ?.let { "%.1f giờ".format(it / 3600) }
        val device = listOf(
            InfoItem("Số sê-ri", serial ?: NOT_SUPPORTED),
            InfoItem("IMEI (khe 1)", imei() ?: NOT_SUPPORTED),
            InfoItem("Bản dựng (fingerprint)", prop("ro.build.fingerprint") ?: NOT_SUPPORTED),
            InfoItem("Kernel", sh("uname -r").takeIf { !bad(it) } ?: NOT_SUPPORTED),
            InfoItem("Trạng thái khởi động xác minh", prop("ro.boot.verifiedbootstate") ?: NOT_SUPPORTED),
            InfoItem("Bootloader khóa", prop("ro.boot.flash.locked")?.let { if (it == "1") "Đã khóa" else "Đã mở khóa" } ?: NOT_SUPPORTED),
            InfoItem("SELinux", sh("getenforce").takeIf { !bad(it) } ?: NOT_SUPPORTED),
            InfoItem("Thời gian chạy từ lần khởi động", uptime ?: NOT_SUPPORTED)
        )

        // --- Pin ---
        val d = sh("dumpsys battery")
        val dumpOk = !bad(d)
        val full = file("$BAT/charge_full")?.toLongOrNull()
        val design = file("$BAT/charge_full_design")?.toLongOrNull()
        val healthPct = if (full != null && design != null && design > 0)
            "%.0f%% (%d / %d mAh)".format(full * 100.0 / design, full / 1000, design / 1000) else null
        val battery = listOf(
            InfoItem("Nhiệt độ", (if (dumpOk) field(d, "temperature")?.toIntOrNull() else null)?.let { "%.1f °C".format(it / 10f) } ?: NOT_SUPPORTED),
            InfoItem("Điện áp", (if (dumpOk) field(d, "voltage")?.toIntOrNull() else null)?.let { "%.3f V".format(it / 1000f) } ?: NOT_SUPPORTED),
            InfoItem("Tình trạng", (if (dumpOk) healthName(field(d, "health")?.toIntOrNull()) else null) ?: NOT_SUPPORTED),
            InfoItem("Công nghệ", (if (dumpOk) field(d, "technology") else null) ?: NOT_SUPPORTED),
            InfoItem("Bộ đếm điện tích", (if (dumpOk) field(d, "Charge counter")?.toLongOrNull() else null)?.let { "${it / 1000} mAh" } ?: NOT_SUPPORTED),
            InfoItem("Số chu kỳ sạc", file("$BAT/cycle_count")?.toIntOrNull()?.toString() ?: NOT_SUPPORTED),
            InfoItem("Dung lượng thực / thiết kế", healthPct ?: NOT_SUPPORTED),
            InfoItem("Dòng điện hiện tại", file("$BAT/current_now")?.toLongOrNull()?.let { "${it / 1000} mA" } ?: NOT_SUPPORTED)
        )

        // --- CPU / nhiệt ---
        val hw = sh("grep -m1 -i '^Hardware' /proc/cpuinfo").substringAfter(':', "").trim()
        val freqs = sh("for f in /sys/devices/system/cpu/cpu[0-9]*/cpufreq/cpuinfo_max_freq; do cat \$f; done")
            .lines().mapNotNull { it.trim().toLongOrNull() }.map { it / 1000 }
        val thermal = sh("for z in /sys/class/thermal/thermal_zone*; do echo \"\$(cat \$z/type 2>/dev/null)=\$(cat \$z/temp 2>/dev/null)\"; done")
            .lines().mapNotNull { line ->
                val type = line.substringBefore('=')
                val t = line.substringAfter('=', "").trim().toLongOrNull() ?: return@mapNotNull null
                if (type.isBlank()) null else InfoItem("Nhiệt: $type", "%.1f °C".format(if (t > 1000) t / 1000.0 else t.toDouble()))
            }.take(8)
        val cpu = listOf(
            InfoItem("Phần cứng (cpuinfo)", hw.ifBlank { NOT_SUPPORTED }),
            InfoItem("Xung nhịp tối đa mỗi lõi", if (freqs.isEmpty()) NOT_SUPPORTED else freqs.joinToString(", ") + " MHz")
        ) + thermal

        // --- Wi-Fi ---
        val w = sh("cmd wifi status").lines().map { it.trim() }.filter { it.isNotEmpty() }.take(4)
        val wifi = if (w.isEmpty() || bad(w.joinToString("\n")))
            listOf(InfoItem("Trạng thái Wi-Fi (shell)", NOT_SUPPORTED))
        else listOf(InfoItem("Trạng thái Wi-Fi (shell)", w.joinToString("\n")))

        return PrivData(device, battery, cpu, wifi)
    }
}
