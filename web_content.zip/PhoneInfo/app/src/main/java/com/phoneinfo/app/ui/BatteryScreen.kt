package com.phoneinfo.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import com.phoneinfo.app.shizuku.ShizukuManager
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.sp
import com.phoneinfo.app.MainViewModel
import kotlin.math.max
import kotlin.math.min

@Composable
fun BatteryScreen(vm: MainViewModel) {
    val b = vm.battery
    val samples = vm.batterySamples
    LaunchedEffect(ShizukuManager.state) {
        if (ShizukuManager.state == ShizukuManager.State.READY && vm.priv == null) vm.loadPriv()
    }
    ScreenColumn {
        InfoCard("Mức pin", Icons.Filled.BatteryChargingFull, Pal.Green) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                RingGauge(
                    fraction = (b.percent ?: 0) / 100f,
                    centerText = b.percent?.let { "$it%" } ?: "—",
                    sub = when (b.charging) { true -> "Đang sạc"; false -> "Không sạc"; null -> "Không rõ" },
                    color = if ((b.percent ?: 100) <= 20 && b.charging != true) Pal.Red else Pal.Green
                )
            }
        }

        InfoCard("Chi tiết pin", Icons.Filled.Speed, Pal.Blue) {
            vm.repo.batteryItems(b).forEach { InfoRow(it) }
        }

        vm.priv?.let { p ->
            InfoCard("Pin chi tiết (Shizuku)", Icons.Filled.Speed, Pal.Green) { p.battery.forEach { InfoRow(it) } }
        }

        InfoCard("Biểu đồ pin (%)", Icons.Filled.BatteryChargingFull, Pal.Green) {
            if (samples.size < 2) {
                Text("Đang thu thập dữ liệu… (cập nhật mỗi 5 giây khi ứng dụng đang mở)", color = Pal.Muted, fontSize = 12.sp)
            }
            LineChart(samples.map { it.percent!!.toFloat() }, 0f, 100f, Pal.Green)
            Text("${samples.size} mẫu gần nhất • trục 0–100%", color = Pal.Muted, fontSize = 11.sp)
        }

        val temps = samples.mapNotNull { it.temperatureC }
        InfoCard("Biểu đồ nhiệt độ (°C)", Icons.Filled.Thermostat, Pal.Blue) {
            if (temps.size < 2) {
                Text(
                    if (b.temperatureC == null) "Không được hệ thống hỗ trợ" else "Đang thu thập dữ liệu…",
                    color = Pal.Muted, fontSize = 12.sp
                )
            } else {
                val lo = temps.minOf { it }
                val hi = temps.maxOf { it }
                LineChart(temps, min(lo - 2f, 20f), max(hi + 2f, 40f), Pal.Blue)
                Text("Hiện tại %.1f °C".format(temps.last()), color = Pal.Muted, fontSize = 11.sp)
            }
        }
    }
}
