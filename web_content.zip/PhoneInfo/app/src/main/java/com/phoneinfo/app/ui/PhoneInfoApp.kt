package com.phoneinfo.app.ui

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.FactCheck
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.sp
import com.phoneinfo.app.MainViewModel

enum class Tab(val label: String, val icon: ImageVector) {
    HOME("Tổng quan", Icons.Filled.Dashboard),
    BATTERY("Pin", Icons.Filled.BatteryChargingFull),
    NETWORK("Mạng", Icons.Filled.Wifi),
    TESTS("Kiểm tra", Icons.Filled.FactCheck),
    REPORT("Báo cáo", Icons.Filled.Assessment),
    ACCESS("Quyền", Icons.Filled.AdminPanelSettings)
}

@Composable
fun PhoneInfoApp(vm: MainViewModel) {
    var tab by rememberSaveable { mutableStateOf(Tab.HOME) }
    Scaffold(
        containerColor = Pal.Bg,
        bottomBar = {
            NavigationBar(containerColor = Pal.Surface) {
                Tab.values().forEach { t ->
                    NavigationBarItem(
                        selected = tab == t,
                        onClick = { tab = t },
                        icon = { Icon(t.icon, contentDescription = t.label) },
                        label = { Text(t.label, fontSize = 10.sp, maxLines = 1) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.Black,
                            selectedTextColor = Pal.Green,
                            indicatorColor = Pal.Green,
                            unselectedIconColor = Pal.Muted,
                            unselectedTextColor = Pal.Muted
                        )
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).statusBarsPadding().fillMaxSize()) {
            Crossfade(targetState = tab, animationSpec = tween(300), label = "tab") { t ->
                when (t) {
                    Tab.HOME -> HomeScreen(vm)
                    Tab.BATTERY -> BatteryScreen(vm)
                    Tab.NETWORK -> NetworkScreen(vm)
                    Tab.TESTS -> TestsScreen(vm)
                    Tab.REPORT -> ReportScreen(vm)
                    Tab.ACCESS -> AccessScreen(vm)
                }
            }
        }
    }
}
