package com.phoneinfo.app.shizuku

import android.app.ActivityManager
import android.content.Context
import android.content.pm.ApplicationInfo
import com.phoneinfo.app.data.DeviceRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/**
 * Dọn RAM bằng cách đóng tiến trình nền.
 * - Có Shizuku: `am kill-all` (đóng mọi tiến trình nền/cache an toàn để đóng); nếu là root thì thêm drop_caches.
 * - Không có Shizuku: killBackgroundProcesses cho các ứng dụng người dùng cài (không đụng ứng dụng hệ thống).
 * Android tự quản lý RAM nên lượng RAM trống tăng chỉ mang tính tạm thời.
 */
object RamBooster {
    data class Result(val beforeAvail: Long, val afterAvail: Long, val targets: Int, val mode: String)

    suspend fun boost(ctx: Context, repo: DeviceRepository): Result {
        val before = repo.memory().second
        var targets = 0
        val mode: String
        if (ShizukuManager.state == ShizukuManager.State.READY) {
            mode = if (ShizukuManager.isRoot) "Shizuku (root)" else "Shizuku (adb)"
            ShizukuManager.exec("am kill-all")
            if (ShizukuManager.isRoot) ShizukuManager.exec("sync; echo 3 > /proc/sys/vm/drop_caches")
        } else {
            mode = "Thường"
            targets = withContext(Dispatchers.Default) {
                val am = ctx.getSystemService(ActivityManager::class.java)
                val apps = ctx.packageManager.getInstalledApplications(0).filter {
                    (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 && it.packageName != ctx.packageName
                }
                apps.forEach { am.killBackgroundProcesses(it.packageName) }
                apps.size
            }
        }
        System.gc()
        delay(1500)
        return Result(before, repo.memory().second, targets, mode)
    }
}
