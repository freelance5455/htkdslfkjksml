package com.phoneinfo.app.ui

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.unit.sp
import com.phoneinfo.app.MainViewModel
import com.phoneinfo.app.data.SpeedTest
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun NetworkScreen(vm: MainViewModel) {
    val repo = vm.repo
    val scope = rememberCoroutineScope()
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(3000); tick++ } }
    val items = remember(tick) { repo.networkItems() }
    val hasPhonePerm = remember(tick) { repo.hasPhoneStatePermission() }

    var permDenied by remember { mutableStateOf(false) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        permDenied = !ok
        tick++
    }

    var consentOpen by remember { mutableStateOf(false) }
    var running by remember { mutableStateOf(false) }
    var speedText by remember { mutableStateOf<String?>(null) }

    ScreenColumn {
        InfoCard("Thông tin mạng", Icons.Filled.Wifi, Pal.Blue) {
            items.forEach { InfoRow(it) }
            if (!hasPhonePerm) {
                Text(
                    "Loại mạng di động (4G/5G) cần quyền “Trạng thái điện thoại”. Quyền này chỉ dùng để đọc loại mạng; " +
                        "ứng dụng không đọc IMEI, số điện thoại hay số sê-ri.",
                    color = Pal.Muted, fontSize = 12.sp
                )
                PrimaryButton("Cho phép xem loại mạng di động", accent = Pal.Blue) {
                    permLauncher.launch(Manifest.permission.READ_PHONE_STATE)
                }
                if (permDenied) Text("Bạn đã từ chối quyền. Các chức năng khác vẫn dùng bình thường.", color = Pal.Amber, fontSize = 12.sp)
            }
        }

        InfoCard("Đo tốc độ mạng", Icons.Filled.Speed, Pal.Green) {
            Text(
                "Bài đo tải một tệp thử khoảng 10 MB để tính tốc độ tải xuống. Chỉ chạy khi bạn đồng ý.",
                color = Pal.Muted, fontSize = 13.sp
            )
            speedText?.let { Text(it, fontSize = 15.sp) }
            PrimaryButton(if (running) "Đang đo…" else "Bắt đầu đo", enabled = !running) { consentOpen = true }
        }

        InfoCard("Quyền riêng tư", Icons.Filled.Public, Pal.Blue) {
            Text(
                "Ứng dụng không đọc mật khẩu Wi-Fi. Tên Wi-Fi chỉ hiện khi bạn cấp quyền vị trí (Android bắt buộc); " +
                    "ứng dụng không đọc GPS. Mọi thông tin chỉ nằm trên máy của bạn.",
                color = Pal.Muted, fontSize = 13.sp
            )
        }
    }

    if (consentOpen) {
        AlertDialog(
            onDismissRequest = { consentOpen = false },
            title = { Text("Đồng ý đo tốc độ?") },
            text = {
                Text(
                    "Ứng dụng sẽ tải một tệp dữ liệu thử (~10 MB) từ máy chủ ${SpeedTest.SERVER}. " +
                        "Không có thông tin cá nhân hay thông tin thiết bị nào được gửi đi. Có thể tốn dữ liệu di động."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    consentOpen = false
                    running = true
                    speedText = null
                    scope.launch {
                        val r = SpeedTest.run()
                        speedText = r.fold(
                            onSuccess = { "Tốc độ tải xuống: %.1f Mbps".format(it) },
                            onFailure = { "Đo thất bại: ${it.message ?: "không có kết nối"}" }
                        )
                        running = false
                    }
                }) { Text("Đồng ý") }
            },
            dismissButton = { TextButton(onClick = { consentOpen = false }) { Text("Hủy") } }
        )
    }
}
