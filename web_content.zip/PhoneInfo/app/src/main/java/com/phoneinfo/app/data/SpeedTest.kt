package com.phoneinfo.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

/**
 * Bài đo tốc độ tải xuống. Chỉ chạy khi người dùng đồng ý.
 * Chỉ tải một tệp dữ liệu ngẫu nhiên; KHÔNG gửi bất kỳ thông tin thiết bị/cá nhân nào.
 */
object SpeedTest {
    const val SERVER = "speed.cloudflare.com"
    private const val URL_TEST = "https://speed.cloudflare.com/__down?bytes=10000000"

    /** Trả về Mbps. */
    suspend fun run(): Result<Double> = withContext(Dispatchers.IO) {
        runCatching {
            val conn = URL(URL_TEST).openConnection() as HttpURLConnection
            conn.connectTimeout = 5000
            conn.readTimeout = 5000
            try {
                val start = System.nanoTime()
                var total = 0L
                val buf = ByteArray(32 * 1024)
                conn.inputStream.use { ins ->
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        total += n
                        if (System.nanoTime() - start > 10_000_000_000L) break
                    }
                }
                val sec = (System.nanoTime() - start) / 1e9
                total * 8 / sec / 1e6
            } finally {
                conn.disconnect()
            }
        }
    }
}
