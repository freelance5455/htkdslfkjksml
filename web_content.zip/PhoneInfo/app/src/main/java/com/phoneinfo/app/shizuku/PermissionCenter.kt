package com.phoneinfo.app.shizuku

import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.os.Process
import android.provider.Settings
import androidx.core.content.ContextCompat

enum class PermKind { RUNTIME, SPECIAL, PRIVILEGED }

data class PermItem(
    val id: String,
    val label: String,
    val why: String,
    val kind: PermKind,
    val minSdk: Int = 29
)

/**
 * Danh mục quyền của ứng dụng. Muốn thêm quyền khác: khai báo trong AndroidManifest
 * rồi thêm một dòng PermItem vào danh sách bên dưới.
 */
object PermissionCenter {
    const val ALL_FILES = "special.all_files"
    const val USAGE = "special.usage_stats"
    const val WRITE_SETTINGS = "special.write_settings"
    const val OVERLAY = "special.overlay"
    const val BATTERY_OPT = "special.battery_opt"

    private fun rt(name: String, label: String, why: String, minSdk: Int = 29) =
        PermItem("android.permission.$name", label, why, PermKind.RUNTIME, minSdk)

    private fun pv(name: String, label: String, why: String) =
        PermItem("android.permission.$name", label, why, PermKind.PRIVILEGED)

    val items: List<PermItem> = listOf(
        rt("CAMERA", "Camera", "Kiểm tra camera"),
        rt("RECORD_AUDIO", "Micro", "Kiểm tra micro"),
        rt("READ_PHONE_STATE", "Trạng thái điện thoại", "Đọc loại mạng di động (4G/5G)"),
        rt("READ_PHONE_NUMBERS", "Số điện thoại", "Thông tin SIM/đường truyền"),
        rt("ACCESS_FINE_LOCATION", "Vị trí chính xác", "Android chỉ cho đọc tên Wi-Fi khi có quyền này (app không đọc GPS)"),
        rt("ACCESS_COARSE_LOCATION", "Vị trí gần đúng", "Đi kèm quyền vị trí để đọc tên Wi-Fi"),
        rt("BODY_SENSORS", "Cảm biến cơ thể", "Phát hiện cảm biến nhịp tim"),
        rt("ACTIVITY_RECOGNITION", "Nhận dạng hoạt động", "Cảm biến đếm bước chân"),
        rt("BLUETOOTH_CONNECT", "Bluetooth: kết nối", "Trạng thái Bluetooth", 31),
        rt("BLUETOOTH_SCAN", "Bluetooth: quét", "Phát hiện thiết bị Bluetooth", 31),
        rt("NEARBY_WIFI_DEVICES", "Thiết bị Wi-Fi lân cận", "Thông tin Wi-Fi", 33),
        rt("POST_NOTIFICATIONS", "Thông báo", "Hiển thị thông báo", 33),
        PermItem(ALL_FILES, "Truy cập mọi tệp", "Kiểm tra dung lượng, ghi/đọc bộ nhớ", PermKind.SPECIAL),
        PermItem(USAGE, "Thống kê sử dụng", "Quyền truy cập dữ liệu sử dụng", PermKind.SPECIAL),
        PermItem(WRITE_SETTINGS, "Sửa cài đặt hệ thống", "Quyền ghi cài đặt hệ thống", PermKind.SPECIAL),
        PermItem(OVERLAY, "Hiển thị trên ứng dụng khác", "Quyền vẽ lên màn hình", PermKind.SPECIAL),
        PermItem(BATTERY_OPT, "Bỏ tối ưu hóa pin", "Cho phép chạy nền không bị hạn chế", PermKind.SPECIAL),
        pv("DUMP", "DUMP (dumpsys)", "Đọc thông tin dịch vụ hệ thống — chỉ cấp được bằng Shizuku/ADB"),
        pv("READ_LOGS", "Đọc nhật ký hệ thống", "Chỉ cấp được bằng Shizuku/ADB"),
        pv("WRITE_SECURE_SETTINGS", "Ghi cài đặt bảo mật", "Chỉ cấp được bằng Shizuku/ADB")
    ).filter { Build.VERSION.SDK_INT >= it.minSdk }

    fun isGranted(ctx: Context, item: PermItem): Boolean = when (item.kind) {
        PermKind.SPECIAL -> special(ctx, item.id)
        else -> ContextCompat.checkSelfPermission(ctx, item.id) == PackageManager.PERMISSION_GRANTED
    }

    private fun special(ctx: Context, id: String): Boolean = try {
        when (id) {
            ALL_FILES -> if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager() else true
            USAGE -> ctx.getSystemService(AppOpsManager::class.java)
                .unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName) ==
                AppOpsManager.MODE_ALLOWED
            WRITE_SETTINGS -> Settings.System.canWrite(ctx)
            OVERLAY -> Settings.canDrawOverlays(ctx)
            BATTERY_OPT -> ctx.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName)
            else -> false
        }
    } catch (e: Exception) {
        false
    }

    /** Mở đúng trang cài đặt để người dùng tự bật quyền đặc biệt. */
    fun openSettings(ctx: Context, id: String) {
        val pkgUri = Uri.parse("package:${ctx.packageName}")
        val intent = when (id) {
            ALL_FILES ->
                if (Build.VERSION.SDK_INT >= 30) Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, pkgUri)
                else Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkgUri)
            USAGE -> Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
            WRITE_SETTINGS -> Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, pkgUri)
            OVERLAY -> Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkgUri)
            BATTERY_OPT -> Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkgUri)
            else -> Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkgUri)
        }.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            ctx.startActivity(intent)
        } catch (e: Exception) {
            ctx.startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkgUri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }

    private fun shellCommand(pkg: String, item: PermItem): String = when (item.id) {
        ALL_FILES -> "appops set $pkg MANAGE_EXTERNAL_STORAGE allow"
        USAGE -> "appops set $pkg GET_USAGE_STATS allow"
        WRITE_SETTINGS -> "appops set $pkg WRITE_SETTINGS allow"
        OVERLAY -> "appops set $pkg SYSTEM_ALERT_WINDOW allow"
        BATTERY_OPT -> "cmd deviceidle whitelist +$pkg"
        else -> "pm grant $pkg ${item.id}"
    }

    /** Cấp (không cần bấm hộp thoại) bằng quyền shell của Shizuku. Trả về log lỗi (nếu có). */
    suspend fun grantWithShizuku(pkg: String, list: List<PermItem>): String =
        ShizukuManager.exec(list.joinToString("; ") { shellCommand(pkg, it) }).trim()
}
