package com.phoneinfo.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object Pal {
    val Bg = Color(0xFF05080C)
    val Surface = Color(0xFF0E1620)
    val SurfaceHi = Color(0xFF172536)
    val Green = Color(0xFF00E676)
    val Blue = Color(0xFF2979FF)
    val Amber = Color(0xFFFFB300)
    val Red = Color(0xFFFF5252)
    val Text = Color(0xFFE8F0F7)
    val Muted = Color(0xFF8CA0B3)
}

@Composable
fun PhoneInfoTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Pal.Green, secondary = Pal.Blue,
            background = Pal.Bg, surface = Pal.Surface,
            onPrimary = Color.Black, onBackground = Pal.Text, onSurface = Pal.Text
        ),
        content = content
    )
}
