package com.phoneinfo.app.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.sp
import com.phoneinfo.app.MainViewModel
import com.phoneinfo.app.data.Status
import com.phoneinfo.app.shizuku.PermItem
import com.phoneinfo.app.shizuku.PermKind
import com.phoneinfo.app.shizuku.PermissionCenter
import com.phoneinfo.app.shizuku.ShizukuManager
import com.phoneinfo.app.shizuku.ShizukuManager.State
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun AccessScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(1500); tick++ } }

    val items = remember { PermissionCenter.items }
    val granted = remember(tick) { items.associate { it.id to PermissionCenter.isGranted(ctx, it) } }
    val missing = items.filter { granted[it.id] != true }
    var msg by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val shizuku = ShizukuManager.state

    LaunchedEffect(shizuku) { if (shizuku == State.READY && vm.priv == null) vm.loadPriv() }

    val multi = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        tick++
        msg = "Đã xử lý ${r.size} quyền. Quyền đặc biệt cần bật ở từng dòng bên dưới hoặc dùng Shizuku."
    }
    val single = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }

    fun grantOne(item: PermItem) {
        if (ShizukuManager.state == State.READY) {
            scope.launch {
                val out = PermissionCenter.grantWithShizuku(ctx.packageName, listOf(item))
                msg = if (out.isBlank()) "Đã cấp: ${item.label}" else out.lineSequence().first()
                tick++
            }
            return
        }
        when (item.kind) {
            PermKind.RUNTIME -> single.launch(item.id)
            PermKind.SPECIAL -> PermissionCenter.openSettings(ctx, item.id)
            PermKind.PRIVILEGED -> msg = "Quyền “${item.label}” chỉ cấp được bằng Shizuku/ADB."
        }
    }

    ScreenColumn {
        Text("Quyền & Shizuku", fontSize = 22.sp, color = Pal.Green)

        // ---- Shizuku ----
        InfoCard("Shizuku", Icons.Filled.Terminal, Pal.Blue) {
            when (shizuku) {
                State.NOT_INSTALLED -> {
                    Text("Chưa cài Shizuku. Cài ứng dụng Shizuku rồi quay lại đây.", color = Pal.Amber, fontSize = 13.sp)
                    PrimaryButton("Mở trang tải Shizuku", accent = Pal.Blue) {
                        ctx.startActivity(
                            Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/"))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                }
                State.NOT_RUNNING -> {
                    Text(
                        "Shizuku đã cài nhưng chưa chạy. Mở Shizuku và khởi động bằng Gỡ lỗi không dây (Android 11+) " +
                            "hoặc ADB / root, rồi quay lại.",
                        color = Pal.Amber, fontSize = 13.sp
                    )
                    PrimaryButton("Mở ứng dụng Shizuku", accent = Pal.Blue) {
                        ctx.packageManager.getLaunchIntentForPackage(ShizukuManager.SHIZUKU_PACKAGE)?.let {
                            ctx.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        }
                    }
                }
                State.NEED_PERMISSION -> {
                    Text("Shizuku đang chạy. Hãy cấp quyền cho PHONE INFO.", fontSize = 13.sp)
                    if (ShizukuManager.denied) {
                        Text(
                            "Quyền đã bị từ chối. Mở Shizuku ▸ Ứng dụng đã ủy quyền để cấp cho PHONE INFO.",
                            color = Pal.Amber, fontSize = 12.sp
                        )
                    }
                    PrimaryButton("Cấp quyền Shizuku", accent = Pal.Blue) { ShizukuManager.requestPermission() }
                }
                State.READY -> {
                    Text("Đã kết nối: ${ShizukuManager.detail}", color = Pal.Green, fontSize = 13.sp)
                }
                State.UNSUPPORTED -> Text("Phiên bản Shizuku quá cũ (cần v11 trở lên).", color = Pal.Red, fontSize = 13.sp)
            }
        }

        // ---- Cấp tất cả ----
        InfoCard("Cấp tất cả quyền", Icons.Filled.AdminPanelSettings, Pal.Green) {
            Text(
                if (missing.isEmpty()) "Đã cấp đủ ${items.size}/${items.size} quyền ✔"
                else "Đã cấp ${items.size - missing.size}/${items.size} quyền. Còn thiếu ${missing.size}.",
                color = if (missing.isEmpty()) Pal.Green else Pal.Text, fontSize = 14.sp
            )
            Text(
                if (shizuku == State.READY) "Có Shizuku: cấp toàn bộ ngay, kể cả quyền đặc biệt, không cần bấm từng hộp thoại."
                else "Chưa có Shizuku: xin các quyền runtime theo đợt; quyền đặc biệt mở trang cài đặt ở từng dòng.",
                color = Pal.Muted, fontSize = 12.sp
            )
            PrimaryButton(if (busy) "Đang cấp…" else "Cấp tất cả", enabled = !busy && missing.isNotEmpty()) {
                if (ShizukuManager.state == State.READY) {
                    busy = true
                    scope.launch {
                        val out = PermissionCenter.grantWithShizuku(ctx.packageName, missing)
                        msg = if (out.isBlank()) "Đã gửi lệnh cấp quyền qua Shizuku." else "Shizuku trả về: " + out.lineSequence().first()
                        busy = false
                        tick++
                    }
                } else {
                    val runtime = missing.filter { it.kind == PermKind.RUNTIME }.map { it.id }.toTypedArray()
                    if (runtime.isNotEmpty()) multi.launch(runtime)
                    else msg = "Còn lại là quyền đặc biệt: bấm “Cấp” ở từng dòng."
                }
            }
            msg?.let { Text(it, fontSize = 12.sp, color = Pal.Muted) }
        }

        // ---- Danh sách quyền ----
        InfoCard("Danh sách quyền", Icons.Filled.PhoneAndroid, Pal.Blue) {
            items.forEach { item ->
                val ok = granted[item.id] == true
                Column {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically) {
                        Text(item.label, fontSize = 14.sp, modifier = Modifier.weight(1f))
                        if (ok) StatusChip(Status.GOOD)
                        else TextButton(onClick = { grantOne(item) }) {
                            Text(if (item.kind == PermKind.SPECIAL && shizuku != State.READY) "Mở cài đặt" else "Cấp")
                        }
                    }
                    Text(item.why, fontSize = 11.sp, color = Pal.Muted)
                }
            }
        }

        // ---- Thông tin đặc quyền ----
        if (shizuku == State.READY) {
            val p = vm.priv
            if (p == null) {
                InfoCard("Thông tin đặc quyền", Icons.Filled.Memory, Pal.Green) {
                    Text(if (vm.privLoading) "Đang đọc qua Shizuku…" else "Chưa có dữ liệu.", color = Pal.Muted, fontSize = 13.sp)
                }
            } else {
                InfoCard("Thiết bị & hệ thống (Shizuku)", Icons.Filled.PhoneAndroid, Pal.Green) {
                    p.device.forEach { InfoRow(it) }
                    Text("Số sê-ri và IMEI chỉ hiện trên màn hình này, không đưa vào báo cáo PDF.", color = Pal.Muted, fontSize = 11.sp)
                }
                InfoCard("Pin chi tiết (Shizuku)", Icons.Filled.BatteryChargingFull, Pal.Blue) { p.battery.forEach { InfoRow(it) } }
                InfoCard("CPU & nhiệt độ (Shizuku)", Icons.Filled.Memory, Pal.Green) { p.cpu.forEach { InfoRow(it) } }
                InfoCard("Wi-Fi (Shizuku)", Icons.Filled.Wifi, Pal.Blue) { p.wifi.forEach { InfoRow(it) } }
            }
            PrimaryButton(if (vm.privLoading) "Đang đọc…" else "Làm mới dữ liệu Shizuku", enabled = !vm.privLoading) { vm.loadPriv() }
        }
    }
}
