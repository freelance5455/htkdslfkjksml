package com.phoneinfo.app.shizuku

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.phoneinfo.app.IUserService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import rikka.shizuku.Shizuku

object ShizukuManager {
    enum class State { NOT_INSTALLED, NOT_RUNNING, NEED_PERMISSION, READY, UNSUPPORTED }

    const val SHIZUKU_PACKAGE = "moe.shizuku.privileged.api"
    private const val REQ = 4242

    var state by mutableStateOf(State.NOT_RUNNING)
        private set
    var detail by mutableStateOf("")
        private set
    var denied by mutableStateOf(false)
        private set
    var isRoot by mutableStateOf(false)
        private set

    @Volatile private var service: IUserService? = null
    private var app: Context? = null
    private var started = false
    private var binding = false

    private val binderReceived = Shizuku.OnBinderReceivedListener { refresh() }
    private val binderDead = Shizuku.OnBinderDeadListener {
        service = null
        binding = false
        refresh()
    }
    private val permResult = Shizuku.OnRequestPermissionResultListener { _, result ->
        denied = result != PackageManager.PERMISSION_GRANTED
        refresh()
    }

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            service = if (binder != null && binder.pingBinder()) IUserService.Stub.asInterface(binder) else null
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            service = null
            binding = false
        }
    }

    fun start(context: Context) {
        if (started) return
        started = true
        app = context.applicationContext
        Shizuku.addBinderReceivedListenerSticky(binderReceived)
        Shizuku.addBinderDeadListener(binderDead)
        Shizuku.addRequestPermissionResultListener(permResult)
        refresh()
    }

    private fun installed(ctx: Context): Boolean = try {
        ctx.packageManager.getPackageInfo(SHIZUKU_PACKAGE, 0)
        true
    } catch (e: PackageManager.NameNotFoundException) {
        false
    }

    fun refresh() {
        val ctx = app ?: return
        try {
            if (!Shizuku.pingBinder()) {
                service = null
                binding = false
                state = if (installed(ctx)) State.NOT_RUNNING else State.NOT_INSTALLED
                return
            }
            if (Shizuku.isPreV11()) { state = State.UNSUPPORTED; return }
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                state = State.NEED_PERMISSION
                return
            }
            isRoot = Shizuku.getUid() == 0
            detail = (if (Shizuku.getUid() == 0) "root" else "adb (shell)") + " · Shizuku v${Shizuku.getVersion()}"
            state = State.READY
            bind(ctx)
        } catch (e: Throwable) {
            state = State.NOT_RUNNING
        }
    }

    fun requestPermission() {
        try {
            if (!Shizuku.pingBinder() || Shizuku.isPreV11()) return
            if (Shizuku.shouldShowRequestPermissionRationale()) denied = true
            else Shizuku.requestPermission(REQ)
        } catch (e: Throwable) {
            denied = true
        }
    }

    private fun bind(ctx: Context) {
        if (service != null || binding) return
        binding = true
        val args = Shizuku.UserServiceArgs(ComponentName(ctx.packageName, UserService::class.java.name))
            .daemon(false)
            .processNameSuffix("service")
            .debuggable(false)
            .version(1)
        try {
            Shizuku.bindUserService(args, connection)
        } catch (e: Throwable) {
            binding = false
        }
    }

    /** Chạy lệnh shell với quyền Shizuku. Trả về stdout+stderr. */
    suspend fun exec(command: String): String {
        if (state != State.READY) return "ERR: Shizuku chưa sẵn sàng"
        withTimeoutOrNull(6000) { while (service == null) delay(100) }
        val s = service ?: return "ERR: không kết nối được dịch vụ Shizuku"
        return withContext(Dispatchers.IO) {
            try { s.exec(command) } catch (e: Exception) { "ERR: ${e.message}" }
        }
    }
}
