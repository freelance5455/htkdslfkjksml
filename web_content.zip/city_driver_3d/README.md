# City Driver 3D
A mobile-friendly 3D city-driving mini game inspired by everyday driving and parking games. It features a daytime city road, traffic, steering, gas/brake controls, a destination mission, gentle parking finish, and local credits/best-trip storage.

## Play
Open `index.html` in a modern browser with an internet connection. The Three.js library is loaded from jsDelivr CDN.

## Controls
- Left / Right: steer
- GAS: accelerate
- BRAKE: slow down and stop
- Keyboard: arrow keys or WASD

## Android APK
Package `index.html` as an Android WebView asset at `app/src/main/assets/index.html`, enable JavaScript and DOM storage, and add the INTERNET permission because Three.js is loaded from a CDN. For a fully offline app, download and bundle the Three.js module locally and update the import path.

This is an original prototype inspired by the broad city-driving / parking genre, not a copy of any specific game's art or assets.
