IPHONE / iOS BUILD INSTRUCTIONS

An iPhone app is distributed as an iOS app/IPA, not an APK. This ZIP is the iOS source/build project. Building and signing iOS apps requires a Mac running macOS with Xcode; Windows or Linux cannot produce a signed iPhone installation package.

1. Extract this ZIP on a Mac. Install current Xcode and Node.js 20+.
2. Open Terminal in the extracted folder.
3. Run: npm install
4. Run: npx cap add ios
   (If an ios/ folder already exists, skip this step.)
5. Run: npx cap sync ios
6. Run: npx cap open ios
7. In Xcode, select the app target, set your Apple Developer Team and a unique Bundle Identifier, then configure signing.
8. For testing, choose an iPhone simulator or connected iPhone and press Run. For a distributable build, use Product > Archive and follow Apple's distribution process.

A ready-to-install IPA is not included: Xcode, macOS, and Apple signing/provisioning are required.
