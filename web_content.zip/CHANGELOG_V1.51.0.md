# Carreira de Craque v1.51.0 — Sistema de Clássicos

- Cadastro central de rivalidades brasileiras e inglesas.
- Reconhecimento nos dois sentidos do confronto, com verificação de que ambos os clubes existem nos elencos do jogo.
- Identificação visual do clássico na partida e no calendário da carreira.
- Notícia pré-jogo e manchete pós-jogo baseadas no placar efetivamente registrado.
- Chaves por temporada/confronto para evitar notícias repetidas.
- Nenhuma partida é criada ou alterada pelo sistema de clássicos.

Nota: as rivalidades são ignoradas automaticamente quando os dois clubes não estão cadastrados nos elencos suportados.
