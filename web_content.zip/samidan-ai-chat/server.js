// SAMIDAN AI CHAT - small Node.js server
// Keep OPENAI_API_KEY on the server. Never put it in public/index.html.
const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");

const PORT = process.env.PORT || 3000;
const API_KEY = process.env.OPENAI_API_KEY;
const MODEL = process.env.OPENAI_MODEL || "gpt-6-luna";
const INDEX = path.join(__dirname, "public", "index.html");

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
  res.setHeader("X-Content-Type-Options", "nosniff");

  if (req.method === "GET" && (url.pathname === "/" || url.pathname === "/index.html")) {
    res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
    return fs.createReadStream(INDEX).pipe(res);
  }

  if (req.method === "POST" && url.pathname === "/api/chat") {
    if (!API_KEY) {
      res.writeHead(500, { "Content-Type": "application/json; charset=utf-8" });
      return res.end(JSON.stringify({ error: "Server owner must set OPENAI_API_KEY." }));
    }
    let raw = "";
    req.on("data", chunk => {
      raw += chunk;
      if (raw.length > 100_000) req.destroy();
    });
    req.on("end", async () => {
      try {
        const body = JSON.parse(raw || "{}");
        const allowed = Array.isArray(body.messages) ? body.messages : [];
        const messages = allowed
          .filter(m => m && ["user", "assistant"].includes(m.role) && typeof m.content === "string")
          .slice(-20)
          .map(m => ({ role: m.role, content: m.content.slice(0, 6000) }));
        if (!messages.length || messages[messages.length - 1].role !== "user") {
          res.writeHead(400, { "Content-Type": "application/json; charset=utf-8" });
          return res.end(JSON.stringify({ error: "Send a message first." }));
        }
        const language = body.language === "am" ? "Reply in Amharic." :
          body.language === "en" ? "Reply in English." :
          "Reply in the language used by the user. You can understand Amharic and English.";
        const apiResponse = await fetch("https://api.openai.com/v1/responses", {
          method: "POST",
          headers: {
            "Authorization": `Bearer ${API_KEY}`,
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            model: MODEL,
            instructions: `You are SAMIDAN AI CHAT, a helpful assistant. ${language} Be clear, accurate, and friendly.`,
            input: messages
          })
        });
        const data = await apiResponse.json();
        if (!apiResponse.ok) {
          const msg = data && data.error && data.error.message ? data.error.message : "AI API request failed.";
          res.writeHead(apiResponse.status, { "Content-Type": "application/json; charset=utf-8" });
          return res.end(JSON.stringify({ error: msg }));
        }
        const reply = (data.output || [])
          .filter(item => item.type === "message")
          .flatMap(item => item.content || [])
          .filter(part => part.type === "output_text")
          .map(part => part.text)
          .join("\n").trim();
        res.writeHead(200, { "Content-Type": "application/json; charset=utf-8" });
        res.end(JSON.stringify({ reply: reply || "No text reply was returned." }));
      } catch (err) {
        res.writeHead(500, { "Content-Type": "application/json; charset=utf-8" });
        res.end(JSON.stringify({ error: "Server error. Check server logs and configuration." }));
      }
    });
    return;
  }

  res.writeHead(404, { "Content-Type": "application/json; charset=utf-8" });
  res.end(JSON.stringify({ error: "Not found" }));
});

server.listen(PORT, "0.0.0.0", () => {
  console.log(`SAMIDAN AI CHAT server listening on port ${PORT}`);
});
