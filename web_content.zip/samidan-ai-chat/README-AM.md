# SAMIDAN AI CHAT

Amharic/English chat web app for mobile browsers.

## Important
- The HTML user interface is not enough by itself for real AI answers.
- This project includes a Node.js server that calls the OpenAI Responses API.
- Keep `OPENAI_API_KEY` secret. Never put it in `public/index.html`, share it, or upload it to a public repository.
- API usage may cost money and requires an API account with available billing/credits. ChatGPT subscription does not automatically include API usage.

## Run on a computer or supported hosting service
1. Install Node.js 18+.
2. Open a terminal in this folder.
3. Set your API key as an environment variable:
   - Linux/macOS: `export OPENAI_API_KEY="your_key_here"`
   - Windows PowerShell: `$env:OPENAI_API_KEY="your_key_here"`
4. Optional: set the model if your account has access to another model:
   - Linux/macOS: `export OPENAI_MODEL="gpt-6-luna"`
   - Windows PowerShell: `$env:OPENAI_MODEL="gpt-6-luna"`
5. Run: `node server.js`
6. Open `http://localhost:3000` in a browser.

## Hosting
Deploy the folder to a Node.js host that supports environment variables. Set `OPENAI_API_KEY` in the host's secret/environment-variable settings, then open the deployed website URL on your Samsung A07.

## Note
The endpoint in the HTML is `/api/chat`. The included server implements it. Do not open the HTML as a local file and expect live AI to work: it must be served by the Node.js server or compatible hosting.
