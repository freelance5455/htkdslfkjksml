# GIGA AUXÍLIO — projeto-base para APK Android

Projeto com interface mobile vermelha neon, feito para empacotamento como app Android usando Capacitor. A configuração é voltada ao Samsung Galaxy A07 com Android 16, mas a compatibilidade final depende da versão do Android SDK/Gradle instalada no computador.

## O que funciona no painel
- Tela de entrada demonstrativa com senha `123` (não é autenticação segura).
- Perfis de referência de sensibilidade salvos localmente.
- Exportação do perfil de sensibilidade em JSON.
- Importação de arquivo XML e verificação de XML bem formado (limite de 2 MB).
- Atalhos de ajuda e tentativa de abertura do Free Fire.

## Limitações importantes
- **Este ZIP não é um APK compilado.** É o código-fonte do projeto.
- Os interruptores são lembretes/preferências locais, não modificam toque, mira, FPS ou arquivos do Free Fire.
- A validação XML verifica sintaxe, não compatibilidade com o jogo. O XML não é injetado nem instalado no Free Fire.
- A abertura do jogo depende do Android, do navegador/WebView e do pacote do jogo instalado.
- A senha `123` serve apenas para demonstração e pode ser vista no código.
- O importador usa o seletor de arquivos do WebView. Se não abrir corretamente dentro do APK, será necessário integrar um seletor nativo Android (Storage Access Framework).

## Como compilar o APK
Você precisa de um computador com Node.js LTS, Android Studio e Android SDK. Não é possível compilar um APK instalável apenas renomeando este ZIP.

1. Extraia o ZIP.
2. Abra um terminal na pasta do projeto.
3. Execute:
   ```bash
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
   ```
4. No Android Studio, espere a sincronização do Gradle terminar.
5. Para gerar um APK de teste, use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Instale o APK de teste no Galaxy A07 e teste seleção de XML, exportação e abertura do jogo.

## Privacidade
Os perfis ficam no armazenamento local do app/navegador. A validação de XML acontece no próprio dispositivo; o conteúdo do arquivo não é enviado a um servidor.
