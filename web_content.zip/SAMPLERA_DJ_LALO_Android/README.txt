SAMPLERA DJ (LALO) - Proyecto Android

Este proyecto envuelve el archivo HTML original en una app Android WebView para uso local.

Para generar el APK:
1. Instala Android Studio en una computadora.
2. Abre Android Studio y selecciona Open; elige la carpeta descomprimida SAMPLERA_DJ_LALO_Android.
3. Espera a que Gradle sincronice e instala el SDK Android 35 si lo solicita.
4. En el menú Build, elige Build Bundle(s) / APK(s) > Build APK(s).
5. El APK se genera normalmente en app/build/outputs/apk/debug/app-debug.apk.

Nota: este ZIP contiene el proyecto fuente, no un APK ya compilado. La compilación requiere Android Studio/Android SDK.
