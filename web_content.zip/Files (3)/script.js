var DB=JSON.parse(localStorage.getItem('restDB')||'null')||{cats:['کباب','پیش‌غذا','نوشیدنی','دسر'],foods:[{name:'چلوکباب کوبیده',price:285000,cat:'کباب'},{name:'جوجه کباب',price:265000,cat:'کباب'},{name:'سالاد سزار',price:145000,cat:'پیش‌غذا'},{name:'دوغ سنتی',price:35000,cat:'نوشیدنی'}],tables:[{name:'میز ۱',status:'free'},{name:'میز ۲',status:'free'},{name:'میز ۳',status:'free'},{name:'میز ۴',status:'free'}],orders:[],sales:[],inv:[{name:'برنج',qty:50,min:10},{name:'گوشت',qty:20,min:5}],users:[{name:'مدیر',pass:'1234',role:'manager'}]};
function save(){localStorage.setItem('restDB',JSON.stringify(DB));render();}
function showTab(id,el){var p=document.querySelectorAll('.page');for(var i=0;i<p.length;i++)p[i].classList.remove('active');document.getElementById(id).classList.add('active');var t=document.querySelectorAll('.tab');for(var j=0;j<t.length;j++)t[j].classList.remove('active');el.classList.add('active');window.scrollTo(0,0);}
function fa(n){return Number(n||0).toLocaleString('fa-IR')+' تومان';}
function addCategory(){var v=document.getElementById('catName').value.trim();if(!v)return;DB.cats.push(v);document.getElementById('catName').value='';save();}
function addFood(){var n=document.getElementById('foodName').value.trim(),p=+document.getElementById('foodPrice').value,c=document.getElementById('foodCat').value;if(!n||!p){alert('نام و قیمت را وارد کنید');return;}DB.foods.push({name:n,price:p,cat:c});document.getElementById('foodName').value='';document.getElementById('foodPrice').value='';save();}
function delFood(i){if(confirm('حذف شود؟')){DB.foods.splice(i,1);save();}}
function addTable(){var v=document.getElementById('tableName').value.trim();if(!v)return;DB.tables.push({name:v,status:'free'});document.getElementById('tableName').value='';save();}
function setTable(i,s){DB.tables[i].status=s;save();}
function delTable(i){DB.tables.splice(i,1);save();}
function addOrder(){var t=document.getElementById('orderTable').value;var fv=document.getElementById('orderFood').value;var f=fv.split(' | ')[0];var q=+document.getElementById('orderCount').value||1;var food=null;for(var i=0;i<DB.foods.length;i++)if(DB.foods[i].name===f)food=DB.foods[i];if(!food)return;DB.orders.push({table:t,food:f,price:food.price,qty:q,status:'new',time:new Date().toLocaleString('fa-IR')});save();}
function setOrder(i,s){if(s==='done'){DB.sales.push(DB.orders[i]);DB.orders.splice(i,1);}else{DB.orders[i].status=s;}save();}
function delOrder(i){DB.orders.splice(i,1);save();}
function printInvoice(){var t=document.getElementById('orderTable').value;var list=[];for(var i=0;i<DB.orders.length;i++)if(DB.orders[i].table===t)list.push(DB.orders[i]);if(!list.length){alert('این میز سفارشی ندارد');return;}var sum=0;var h='<h3>فاکتور '+t+'</h3>';for(var j=0;j<list.length;j++){sum+=list[j].price*list[j].qty;h+='<div>'+list[j].food+' × '+list[j].qty+' - '+fa(list[j].price*list[j].qty)+'</div>';}h+='<hr><b>جمع کل: '+fa(sum)+'</b><br><br><button onclick="closeTable(\''+t+'\')">تسویه و بستن میز</button> <button onclick="window.print()">چاپ</button>';document.getElementById('invoice').innerHTML=h;}
function closeTable(t){var keep=[];for(var i=0;i<DB.orders.length;i++){if(DB.orders[i].table===t)DB.sales.push(DB.orders[i]);else keep.push(DB.orders[i]);}DB.orders=keep;document.getElementById('invoice').innerHTML='<p>تسویه شد ✅</p>';save();}
function addInv(){var n=document.getElementById('invName').value;var q=+document.getElementById('invQty').value||0;var m=+document.getElementById('invMin').value||5;if(!n)return;DB.inv.push({name:n,qty:q,min:m});save();}
function addUser(){var n=document.getElementById('uName').value;if(!n)return;DB.users.push({name:n,pass:document.getElementById('uPass').value,role:document.getElementById('uRole').value});save();}
function render(){
document.getElementById('foodCat').innerHTML=DB.cats.map(function(c){return '<option>'+c+'</option>';}).join('');
document.getElementById('orderTable').innerHTML=DB.tables.map(function(t){return '<option>'+t.name+'</option>';}).join('');
document.getElementById('orderFood').innerHTML=DB.foods.map(function(f){return '<option>'+f.name+' | '+f.price+'</option>';}).join('');
document.getElementById('menuList').innerHTML=DB.foods.map(function(f,i){return '<div class="food"><h4>'+f.name+'</h4><p>'+f.cat+'<br>'+fa(f.price)+'</p><button onclick="delFood('+i+')">حذف</button></div>';}).join('');
document.getElementById('quickMenu').innerHTML=DB.foods.map(function(f){return '<div class="food"><h4>'+f.name+'</h4><p>'+fa(f.price)+'</p></div>';}).join('');
document.getElementById('tablesList').innerHTML=DB.tables.map(function(t,i){var s=t.status==='free'?'خالی ✅':'اشغال 🔴';return '<div class="table"><h4>'+t.name+'</h4><p>'+s+'</p><button onclick="setTable('+i+',\'free\')">خالی</button> <button onclick="setTable('+i+',\'busy\')">اشغال</button> <button onclick="delTable('+i+')">حذف</button></div>';}).join('');
document.getElementById('ordersList').innerHTML=DB.orders.length?DB.orders.map(function(o,i){return '<div class="order"><span>'+o.table+' | '+o.food+' × '+o.qty+'<br>'+fa(o.price*o.qty)+'</span><span><button onclick="setOrder('+i+',\'done\')">تحویل ✅</button><button onclick="delOrder('+i+')">❌</button></span></div>';}).join(''):'<p>سفارشی نیست</p>';
document.getElementById('kitchenList').innerHTML=DB.orders.length?DB.orders.map(function(o,i){return '<div class="order"><span>'+o.table+' - '+o.food+' × '+o.qty+'</span><button onclick="setOrder('+i+',\'done\')">آماده شد ✅</button></div>';}).join(''):'<p>آشپزخانه خلوت است</p>';
document.getElementById('invList').innerHTML=DB.inv.map(function(v,i){var w=v.qty<=v.min?' ⚠️ کمبود!':'';return '<div class="order"><span>'+v.name+' : '+v.qty+w+'</span><span><button onclick="DB.inv['+i+'].qty++;save()">+</button><button onclick="DB.inv['+i+'].qty--;save()">-</button></span></div>';}).join('');
document.getElementById('usersList').innerHTML=DB.users.map(function(u){return '<div class="order"><span>'+u.name+' - '+u.role+'</span></div>';}).join('');
var s=0;for(var k=0;k<DB.sales.length;k++)s+=DB.sales[k].price*DB.sales[k].qty;
document.getElementById('todaySale').textContent=fa(s);document.getElementById('totalSale').textContent=fa(s);
document.getElementById('activeOrders').textContent=DB.orders.length;document.getElementById('busyTables').textContent=DB.tables.length;
document.getElementById('lowStock').textContent=DB.inv.filter(function(v){return v.qty<=v.min;}).length;
document.getElementById('totalInvoices').textContent=DB.sales.length;
document.getElementById('reportList').innerHTML=DB.sales.map(function(x){return '<div class="order"><span>'+x.time+' - '+x.table+' - '+x.food+' × '+x.qty+'</span><b>'+fa(x.price*x.qty)+'</b></div>';}).join('');
}
render();
</script>