"""
IMPOSTER X – Online Multiplayer Server
Create Room / Join Room · FastAPI WebSockets
"""
from __future__ import annotations

import json
import random
import string
import time
from pathlib import Path
from typing import Any, Optional

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

WORDS: dict[str, list[dict[str, str]]] = {
    "FOOD": [
        {"ml": "ചോറ്", "en": "Rice"}, {"ml": "ദോശ", "en": "Dosa"}, {"ml": "ഇഡലി", "en": "Idli"},
        {"ml": "പുട്ട്", "en": "Puttu"}, {"ml": "അപ്പം", "en": "Appam"}, {"ml": "ചപ്പാത്തി", "en": "Chapathi"},
        {"ml": "ബിരിയാണി", "en": "Biryani"}, {"ml": "സദ്യ", "en": "Sadhya"}, {"ml": "പായസം", "en": "Payasam"},
        {"ml": "ഉപ്പുമാവ്", "en": "Uppumavu"}, {"ml": "പൊറോട്ട", "en": "Porotta"}, {"ml": "സമോസ", "en": "Samosa"},
        {"ml": "പഴംപൊരി", "en": "Pazhampori"}, {"ml": "വട", "en": "Vada"}, {"ml": "പക്കോഡ", "en": "Pakoda"},
        {"ml": "പിസ്സ", "en": "Pizza"}, {"ml": "ബർഗർ", "en": "Burger"}, {"ml": "നൂഡിൽസ്", "en": "Noodles"},
        {"ml": "ഐസ്ക്രീം", "en": "Ice Cream"}, {"ml": "കേക്ക്", "en": "Cake"}, {"ml": "ചോക്ലേറ്റ്", "en": "Chocolate"},
        {"ml": "ബിസ്കറ്റ്", "en": "Biscuit"}, {"ml": "പഴം", "en": "Fruit"}, {"ml": "സാൻഡ്‌വിച്ച്", "en": "Sandwich"},
        {"ml": "പാൽ", "en": "Milk"}, {"ml": "തൈര്", "en": "Curd"}, {"ml": "നെയ്യ്", "en": "Ghee"},
        {"ml": "അരി", "en": "Rice Grain"}, {"ml": "പപ്പടം", "en": "Papadam"}, {"ml": "അച്ചാർ", "en": "Pickle"},
        {"ml": "സാമ്പാർ", "en": "Sambar"}, {"ml": "രസം", "en": "Rasam"}, {"ml": "മോര്", "en": "Buttermilk"},
        {"ml": "ലസ്സി", "en": "Lassi"}, {"ml": "ഷേക്ക്", "en": "Shake"}, {"ml": "ജ്യൂസ്", "en": "Juice"},
        {"ml": "ചായ", "en": "Tea"}, {"ml": "കാപ്പി", "en": "Coffee"}, {"ml": "മസാല", "en": "Masala"},
        {"ml": "മഞ്ഞൾ", "en": "Turmeric"}, {"ml": "മുളക്", "en": "Chilli"}, {"ml": "ഉപ്പ്", "en": "Salt"},
        {"ml": "പഞ്ചസാര", "en": "Sugar"}, {"ml": "കറി", "en": "Curry"}, {"ml": "മീൻ", "en": "Fish"},
        {"ml": "ചിക്കൻ", "en": "Chicken"}, {"ml": "മട്ടൺ", "en": "Mutton"}, {"ml": "മുട്ട", "en": "Egg"},
        {"ml": "പനീർ", "en": "Paneer"}, {"ml": "മഷ്റൂം", "en": "Mushroom"}, {"ml": "ബീൻസ്", "en": "Beans"},
        {"ml": "കാബേജ്", "en": "Cabbage"}, {"ml": "കാരറ്റ്", "en": "Carrot"}, {"ml": "മത്തങ്ങ", "en": "Pumpkin"},
        {"ml": "വെണ്ട", "en": "Okra"}, {"ml": "തക്കാളി", "en": "Tomato"}, {"ml": "ഉള്ളി", "en": "Onion"},
        {"ml": "വെളുത്തുള്ളി", "en": "Garlic"}, {"ml": "ഇഞ്ചി", "en": "Ginger"}, {"ml": "മാങ്ങ", "en": "Mango"},
        {"ml": "ആപ്പിൾ", "en": "Apple"}, {"ml": "ഓറഞ്ച്", "en": "Orange"}, {"ml": "മുന്തിരി", "en": "Grape"},
        {"ml": "മാതളം", "en": "Pomegranate"}, {"ml": "നാരങ്ങ", "en": "Lemon"}, {"ml": "പപ്പായ", "en": "Papaya"},
        {"ml": "തണ്ണിമത്തൻ", "en": "Watermelon"}, {"ml": "ഉരുളക്കിഴങ്ങ്", "en": "Potato"}, {"ml": "ചീര", "en": "Spinach"},
        {"ml": "പുളി", "en": "Tamarind"}, {"ml": "കറിവേപ്പ്", "en": "Curry Leaf"},
    ],
    "OBJECTS": [
        {"ml": "കസേര", "en": "Chair"}, {"ml": "മേശ", "en": "Table"}, {"ml": "കിടക്ക", "en": "Bed"},
        {"ml": "അലമാര", "en": "Wardrobe"}, {"ml": "വാതിൽ", "en": "Door"}, {"ml": "ജനൽ", "en": "Window"},
        {"ml": "കണ്ണാടി", "en": "Mirror"}, {"ml": "പുസ്തകം", "en": "Book"}, {"ml": "പേന", "en": "Pen"},
        {"ml": "പെൻസിൽ", "en": "Pencil"}, {"ml": "ബാഗ്", "en": "Bag"}, {"ml": "കുട", "en": "Umbrella"},
        {"ml": "ചെരുപ്പ്", "en": "Slipper"}, {"ml": "വാച്ച്", "en": "Watch"}, {"ml": "മൊബൈൽ", "en": "Mobile"},
        {"ml": "കമ്പ്യൂട്ടർ", "en": "Computer"}, {"ml": "ടെലിവിഷൻ", "en": "Television"}, {"ml": "ഹെഡ്‌ഫോൺ", "en": "Headphone"},
        {"ml": "ക്യാമറ", "en": "Camera"}, {"ml": "കുപ്പി", "en": "Bottle"}, {"ml": "ഗ്ലാസ്", "en": "Glass"},
        {"ml": "പ്ലേറ്റ്", "en": "Plate"}, {"ml": "സ്പൂൺ", "en": "Spoon"}, {"ml": "താക്കോൽ", "en": "Key"},
        {"ml": "പന്ത്", "en": "Ball"}, {"ml": "കത്തി", "en": "Knife"}, {"ml": "ചുറ്റിക", "en": "Hammer"},
        {"ml": "ബാറ്ററി", "en": "Battery"}, {"ml": "ബൾബ്", "en": "Bulb"}, {"ml": "ഫാൻ", "en": "Fan"},
        {"ml": "ഹീറ്റർ", "en": "Heater"}, {"ml": "മൈക്രോവേവ്", "en": "Microwave"}, {"ml": "ഫ്രിഡ്ജ്", "en": "Fridge"},
        {"ml": "അടുപ്പ്", "en": "Stove"}, {"ml": "പാത്രം", "en": "Vessel"}, {"ml": "ചട്ടി", "en": "Pan"},
        {"ml": "കപ്പ്", "en": "Cup"}, {"ml": "മഗ്", "en": "Mug"}, {"ml": "ബൗൾ", "en": "Bowl"},
        {"ml": "തൂവാല", "en": "Towel"}, {"ml": "പുതപ്പ്", "en": "Blanket"}, {"ml": "തലയണ", "en": "Pillow"},
        {"ml": "മെത്ത", "en": "Mattress"}, {"ml": "സോഫ", "en": "Sofa"}, {"ml": "റബ്ബർ", "en": "Rubber"},
        {"ml": "മാപ്പ്", "en": "Map"}, {"ml": "ഗ്ലോബ്", "en": "Globe"}, {"ml": "കാൽക്കുലേറ്റർ", "en": "Calculator"},
        {"ml": "ലാപ്ടോപ്പ്", "en": "Laptop"}, {"ml": "ടാബ്ലെറ്റ്", "en": "Tablet"}, {"ml": "സ്പീക്കർ", "en": "Speaker"},
        {"ml": "മൈക്ക്", "en": "Mic"}, {"ml": "ക്ലോക്ക്", "en": "Clock"}, {"ml": "കർട്ടൻ", "en": "Curtain"},
        {"ml": "ലാമ്പ്", "en": "Lamp"}, {"ml": "എസി", "en": "AC"}, {"ml": "വാഷിംഗ് മെഷീൻ", "en": "Washing Machine"},
        {"ml": "ഓവൻ", "en": "Oven"}, {"ml": "മിക്സർ", "en": "Mixer"}, {"ml": "ബ്ലെൻഡർ", "en": "Blender"},
        {"ml": "ടോസ്റ്റർ", "en": "Toaster"}, {"ml": "കെറ്റിൽ", "en": "Kettle"}, {"ml": "ഫ്രീസർ", "en": "Freezer"},
    ],
    "VEHICLES": [
        {"ml": "കാർ", "en": "Car"}, {"ml": "ബസ്", "en": "Bus"}, {"ml": "ട്രെയിൻ", "en": "Train"},
        {"ml": "വിമാനം", "en": "Aeroplane"}, {"ml": "ബോട്ട്", "en": "Boat"}, {"ml": "ബൈക്ക്", "en": "Bike"},
        {"ml": "സ്കൂട്ടർ", "en": "Scooter"}, {"ml": "സൈക്കിൾ", "en": "Cycle"}, {"ml": "ഓട്ടോ", "en": "Auto"},
        {"ml": "ടാക്സി", "en": "Taxi"}, {"ml": "വാൻ", "en": "Van"}, {"ml": "ട്രക്ക്", "en": "Truck"},
        {"ml": "ലോറി", "en": "Lorry"}, {"ml": "അംബുലൻസ്", "en": "Ambulance"}, {"ml": "ഫയർ എൻജിൻ", "en": "Fire Engine"},
        {"ml": "പൊലീസ് കാർ", "en": "Police Car"}, {"ml": "റിക്ഷ", "en": "Rickshaw"}, {"ml": "ബുള്ളറ്റ്", "en": "Bullet Bike"},
        {"ml": "ഹെലികോപ്റ്റർ", "en": "Helicopter"}, {"ml": "ജെറ്റ്", "en": "Jet"}, {"ml": "റോക്കറ്റ്", "en": "Rocket"},
        {"ml": "സ്പേസ് ഷട്ടിൽ", "en": "Space Shuttle"}, {"ml": "ഡ്രോൺ", "en": "Drone"}, {"ml": "ബോയിംഗ്", "en": "Boeing"},
        {"ml": "എയർബസ്", "en": "Airbus"}, {"ml": "ഫെറി", "en": "Ferry"}, {"ml": "വള്ളം", "en": "Canoe"},
        {"ml": "സബ് മറൈൻ", "en": "Submarine"}, {"ml": "ഇലക്ട്രിക് കാർ", "en": "Electric Car"}, {"ml": "സ്കൂട്ടി", "en": "Scooty"},
        {"ml": "ജീപ്പ്", "en": "Jeep"}, {"ml": "മിനി ബസ്", "en": "Mini Bus"}, {"ml": "ട്രാക്ടർ", "en": "Tractor"},
        {"ml": "ബുള്ളോസർ", "en": "Bulldozer"}, {"ml": "ക്രെയിൻ", "en": "Crane"}, {"ml": "ഡംപർ", "en": "Dumper"},
        {"ml": "ടാങ്കർ", "en": "Tanker"}, {"ml": "റേസിംഗ് കാർ", "en": "Racing Car"}, {"ml": "ഫോർമുല 1", "en": "Formula 1"},
        {"ml": "ഗ്ലൈഡർ", "en": "Glider"}, {"ml": "അൾട്രാലൈറ്റ്", "en": "Ultralight"},
    ],
    "COMMON": [
        {"ml": "വീട്", "en": "Home"}, {"ml": "സ്കൂൾ", "en": "School"}, {"ml": "ഓഫീസ്", "en": "Office"},
        {"ml": "ഹോസ്പിറ്റൽ", "en": "Hospital"}, {"ml": "ബാങ്ക്", "en": "Bank"}, {"ml": "ക്ഷേത്രം", "en": "Temple"},
        {"ml": "പള്ളി", "en": "Mosque"}, {"ml": "ചർച്ച്", "en": "Church"}, {"ml": "പാർക്ക്", "en": "Park"},
        {"ml": "ഗാർഡൻ", "en": "Garden"}, {"ml": "മൃഗശാല", "en": "Zoo"}, {"ml": "ലൈബ്രറി", "en": "Library"},
        {"ml": "മ്യൂസിയം", "en": "Museum"}, {"ml": "ഹോട്ടൽ", "en": "Hotel"}, {"ml": "റെസ്റ്റോറന്റ്", "en": "Restaurant"},
        {"ml": "മാൾ", "en": "Mall"}, {"ml": "മാർക്കറ്റ്", "en": "Market"}, {"ml": "തുറമുഖം", "en": "Port"},
        {"ml": "വിമാനത്താവളം", "en": "Airport"}, {"ml": "റെയിൽവേ സ്റ്റേഷൻ", "en": "Railway Station"}, {"ml": "ബസ് സ്റ്റാൻഡ്", "en": "Bus Stand"},
        {"ml": "മഴ", "en": "Rain"}, {"ml": "വെയിൽ", "en": "Sunlight"}, {"ml": "കാറ്റ്", "en": "Wind"},
        {"ml": "മണ്ണ്", "en": "Soil"}, {"ml": "ജലം", "en": "Water"}, {"ml": "തീ", "en": "Fire"},
        {"ml": "ആകാശം", "en": "Sky"}, {"ml": "മല", "en": "Mountain"}, {"ml": "നദി", "en": "River"},
        {"ml": "കടൽ", "en": "Sea"}, {"ml": "സമുദ്രം", "en": "Ocean"}, {"ml": "മരം", "en": "Tree"},
        {"ml": "ചെടി", "en": "Plant"}, {"ml": "പൂവ്", "en": "Flower"}, {"ml": "ഫലം", "en": "Fruit"},
        {"ml": "ഇല", "en": "Leaf"}, {"ml": "വിത്ത്", "en": "Seed"}, {"ml": "കാട്", "en": "Forest"},
        {"ml": "വനം", "en": "Jungle"}, {"ml": "മരുഭൂമി", "en": "Desert"}, {"ml": "തടാകം", "en": "Lake"},
        {"ml": "മഞ്ഞ്", "en": "Snow"}, {"ml": "ഐസ്", "en": "Ice"}, {"ml": "മഴവില്ല്", "en": "Rainbow"},
        {"ml": "നക്ഷത്രം", "en": "Star"}, {"ml": "ചന്ദ്രൻ", "en": "Moon"}, {"ml": "സൂര്യൻ", "en": "Sun"},
        {"ml": "ഗ്രഹം", "en": "Planet"}, {"ml": "പ്രകാശം", "en": "Light"}, {"ml": "ഇരുട്ട്", "en": "Darkness"},
        {"ml": "ഉറക്കം", "en": "Sleep"}, {"ml": "ഭക്ഷണം", "en": "Food"}, {"ml": "വെള്ളം", "en": "Water"},
        {"ml": "വായു", "en": "Air"}, {"ml": "കുടുംബം", "en": "Family"}, {"ml": "സുഹൃത്ത്", "en": "Friend"},
        {"ml": "ജോലി", "en": "Work"}, {"ml": "പണം", "en": "Money"}, {"ml": "സമയം", "en": "Time"},
        {"ml": "ദിവസം", "en": "Day"}, {"ml": "രാത്രി", "en": "Night"}, {"ml": "പകൽ", "en": "Daytime"},
        {"ml": "രാവിലെ", "en": "Morning"}, {"ml": "വൈകിട്ട്", "en": "Evening"}, {"ml": "വടക്ക്", "en": "North"},
        {"ml": "തെക്ക്", "en": "South"}, {"ml": "കിഴക്ക്", "en": "East"}, {"ml": "പടിഞ്ഞാറ്", "en": "West"},
        {"ml": "നിശബ്ദം", "en": "Silence"}, {"ml": "ശബ്ദം", "en": "Sound"}, {"ml": "നിറം", "en": "Color"},
        {"ml": "രൂപം", "en": "Shape"},
    ],
}


def get_words(cat: str) -> list[dict[str, str]]:
    if cat == "ALL":
        out: list[dict[str, str]] = []
        for v in WORDS.values():
            out.extend(v)
        return out
    return WORDS.get(cat, WORDS["COMMON"])


def random_word(cat: str) -> dict[str, str]:
    return random.choice(get_words(cat))


def make_code() -> str:
    chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    return "".join(random.choice(chars) for _ in range(6))


class Player:
    def __init__(self, pid: str, name: str, is_host: bool = False):
        self.id = pid
        self.name = name
        self.is_host = is_host
        self.is_imposter = False
        self.card_revealed = False
        self.vote: Optional[str] = None
        self.ws: Optional[WebSocket] = None


class Room:
    def __init__(self, code: str, host: Player):
        self.code = code
        self.host_id = host.id
        self.players: list[Player] = [host]
        self.state = "LOBBY"
        self.imposter_count = 1
        self.category = "ALL"
        self.hints_enabled = True
        self.voting_enabled = True
        self.secret_word: Optional[dict[str, str]] = None
        self.imposters: list[str] = []
        self.starter_player: Optional[str] = None
        self.votes: dict[str, str] = {}
        self.vote_result: Optional[dict] = None
        self.created_at = time.time()

    def find(self, pid: str) -> Optional[Player]:
        for p in self.players:
            if p.id == pid:
                return p
        return None

    def public_for(self, pid: str) -> dict[str, Any]:
        me = self.find(pid)
        my_role = None
        if me and self.state != "LOBBY" and self.secret_word:
            if me.is_imposter:
                my_role = {
                    "isImposter": True,
                    "cardRevealed": me.card_revealed,
                    "word": {
                        "hint": self.secret_word["ml"][0] if self.hints_enabled else None,
                        "full": None,
                    },
                }
            else:
                my_role = {
                    "isImposter": False,
                    "cardRevealed": me.card_revealed,
                    "word": {"hint": None, "full": self.secret_word},
                }
        results = None
        if self.state == "RESULTS":
            results = {
                "imposters": self.imposters,
                "secretWord": self.secret_word,
                "voteResult": self.vote_result,
            }
        return {
            "code": self.code,
            "state": self.state,
            "hostId": self.host_id,
            "players": [
                {"id": p.id, "name": p.name, "isHost": p.is_host, "cardRevealed": p.card_revealed}
                for p in self.players
            ],
            "imposterCount": self.imposter_count,
            "category": self.category,
            "hintsEnabled": self.hints_enabled,
            "votingEnabled": self.voting_enabled,
            "starterPlayer": self.starter_player,
            "myRole": my_role,
            "results": results,
            "votesCast": len(self.votes) if self.state == "VOTING" else 0,
            "totalPlayers": len(self.players),
        }


rooms: dict[str, Room] = {}
connections: dict[str, str] = {}


async def emit_room(room: Room) -> None:
    for p in room.players:
        if p.ws:
            try:
                await p.ws.send_json({"event": "room:update", "data": room.public_for(p.id)})
            except Exception:
                pass


async def send_error(ws: WebSocket, msg: str) -> None:
    try:
        await ws.send_json({"event": "error", "data": {"message": msg}})
    except Exception:
        pass


def finish_voting(room: Room) -> None:
    tally: dict[str, int] = {}
    for target in room.votes.values():
        tally[target] = tally.get(target, 0) + 1
    max_v, top = 0, []
    for name, cnt in tally.items():
        if cnt > max_v:
            max_v, top = cnt, [name]
        elif cnt == max_v:
            top.append(name)
    tie = len(top) > 1
    eliminated = None if tie else top[0]
    is_imp = bool(eliminated and eliminated in room.imposters)
    room.vote_result = {
        "tally": tally,
        "tie": tie,
        "eliminated": eliminated,
        "isImposter": is_imp,
        "civiliansWin": bool(eliminated and is_imp),
    }
    room.state = "RESULTS"


app = FastAPI(title="IMPOSTER X Online")
PUBLIC = Path(__file__).resolve().parent.parent / "public"


@app.get("/")
async def index():
    return FileResponse(PUBLIC / "index.html")


if PUBLIC.exists():
    app.mount("/assets", StaticFiles(directory=str(PUBLIC)), name="assets")


@app.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    await ws.accept()
    pid = f"{id(ws)}-{''.join(random.choices(string.hexdigits, k=6))}"
    player_name = ""
    room_code: Optional[str] = None

    try:
        await ws.send_json({"event": "connected", "data": {"id": pid}})
        while True:
            raw = await ws.receive_text()
            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                continue
            event = msg.get("event")
            data = msg.get("data") or {}

            if event == "room:create":
                name = str(data.get("name", "")).strip()[:20]
                if not name:
                    await send_error(ws, "Enter a name")
                    continue
                settings = data.get("settings") or {}
                code = make_code()
                while code in rooms:
                    code = make_code()
                host = Player(pid, name, is_host=True)
                host.ws = ws
                room = Room(code, host)
                room.imposter_count = max(1, min(3, int(settings.get("imposterCount", 1))))
                room.category = settings.get("category", "ALL")
                room.hints_enabled = settings.get("hintsEnabled", True) is not False
                room.voting_enabled = settings.get("votingEnabled", True) is not False
                rooms[code] = room
                connections[pid] = code
                room_code = code
                player_name = name
                await ws.send_json({"event": "room:created", "data": {"code": code}})
                await emit_room(room)
                print(f"[CREATE] {code} by {name}")

            elif event == "room:join":
                code = str(data.get("code", "")).strip().upper()
                name = str(data.get("name", "")).strip()[:20]
                if not name:
                    await send_error(ws, "Enter a name")
                    continue
                if not code:
                    await send_error(ws, "Enter room code")
                    continue
                room = rooms.get(code)
                if not room:
                    await send_error(ws, "Room not found")
                    continue
                if room.state != "LOBBY":
                    await send_error(ws, "Game already started")
                    continue
                if len(room.players) >= 20:
                    await send_error(ws, "Room is full")
                    continue
                if any(p.name.lower() == name.lower() for p in room.players):
                    await send_error(ws, "Name already taken")
                    continue
                p = Player(pid, name)
                p.ws = ws
                room.players.append(p)
                connections[pid] = code
                room_code = code
                player_name = name
                await ws.send_json({"event": "room:joined", "data": {"code": code}})
                await emit_room(room)
                print(f"[JOIN] {name} → {code}")

            elif event == "room:settings":
                room = rooms.get(room_code or "")
                if not room or room.host_id != pid or room.state != "LOBBY":
                    continue
                if "imposterCount" in data:
                    room.imposter_count = max(1, min(3, int(data["imposterCount"])))
                    half = max(1, len(room.players) // 2)
                    if room.imposter_count > half:
                        room.imposter_count = half
                if "category" in data:
                    room.category = data["category"]
                if "hintsEnabled" in data:
                    room.hints_enabled = bool(data["hintsEnabled"])
                if "votingEnabled" in data:
                    room.voting_enabled = bool(data["votingEnabled"])
                await emit_room(room)

            elif event == "room:kick":
                room = rooms.get(room_code or "")
                if not room or room.host_id != pid or room.state != "LOBBY":
                    continue
                target_id = data.get("playerId")
                if not target_id or target_id == pid:
                    continue
                target = room.find(target_id)
                if not target:
                    continue
                room.players = [p for p in room.players if p.id != target_id]
                if target.ws:
                    try:
                        await target.ws.send_json({"event": "room:kicked", "data": {}})
                        await target.ws.close()
                    except Exception:
                        pass
                connections.pop(target_id, None)
                await emit_room(room)

            elif event == "game:start":
                room = rooms.get(room_code or "")
                if not room or room.host_id != pid or room.state != "LOBBY":
                    continue
                if len(room.players) < 4:
                    await send_error(ws, "Minimum 4 players required")
                    continue
                room.secret_word = random_word(room.category)
                names = [p.name for p in room.players]
                random.shuffle(names)
                room.imposters = names[: room.imposter_count]
                room.starter_player = random.choice(room.players).name
                room.votes = {}
                room.vote_result = None
                for p in room.players:
                    p.is_imposter = p.name in room.imposters
                    p.card_revealed = False
                    p.vote = None
                room.state = "CARD_REVEAL"
                await emit_room(room)
                print(f"[START] {room.code} · {room.secret_word['en']}")

            elif event == "card:reveal":
                room = rooms.get(room_code or "")
                if not room or room.state != "CARD_REVEAL":
                    continue
                me = room.find(pid)
                if not me or me.card_revealed:
                    continue
                me.card_revealed = True
                await emit_room(room)
                if all(p.card_revealed for p in room.players):
                    room.state = "DISCUSSION"
                    await emit_room(room)

            elif event == "game:startVoting":
                room = rooms.get(room_code or "")
                if not room or room.host_id != pid:
                    continue
                if room.state not in ("DISCUSSION", "CARD_REVEAL") or not room.voting_enabled:
                    continue
                room.state = "VOTING"
                room.votes = {}
                for p in room.players:
                    p.vote = None
                await emit_room(room)

            elif event == "game:skipToReveal":
                room = rooms.get(room_code or "")
                if not room or room.host_id != pid:
                    continue
                if room.state not in ("DISCUSSION", "CARD_REVEAL"):
                    continue
                room.state = "RESULTS"
                room.vote_result = None
                await emit_room(room)

            elif event == "vote:cast":
                room = rooms.get(room_code or "")
                if not room or room.state != "VOTING":
                    continue
                me = room.find(pid)
                if not me or me.vote:
                    continue
                target = str(data.get("target", "")).strip()
                if not target or target == me.name:
                    continue
                if not any(p.name == target for p in room.players):
                    continue
                me.vote = target
                room.votes[me.name] = target
                await emit_room(room)
                if len(room.votes) >= len(room.players):
                    finish_voting(room)
                    await emit_room(room)

            elif event == "game:playAgain":
                room = rooms.get(room_code or "")
                if not room or room.host_id != pid:
                    continue
                room.secret_word = random_word(room.category)
                names = [p.name for p in room.players]
                random.shuffle(names)
                ic = min(room.imposter_count, max(1, len(room.players) // 2))
                room.imposters = names[:ic]
                room.starter_player = random.choice(room.players).name
                room.votes = {}
                room.vote_result = None
                for p in room.players:
                    p.is_imposter = p.name in room.imposters
                    p.card_revealed = False
                    p.vote = None
                room.state = "CARD_REVEAL"
                await emit_room(room)

            elif event == "game:backToLobby":
                room = rooms.get(room_code or "")
                if not room or room.host_id != pid:
                    continue
                room.state = "LOBBY"
                room.secret_word = None
                room.imposters = []
                room.starter_player = None
                room.votes = {}
                room.vote_result = None
                for p in room.players:
                    p.is_imposter = False
                    p.card_revealed = False
                    p.vote = None
                await emit_room(room)

    except WebSocketDisconnect:
        pass
    finally:
        code = connections.pop(pid, None) or room_code
        if code and code in rooms:
            room = rooms[code]
            room.players = [p for p in room.players if p.id != pid]
            if not room.players:
                del rooms[code]
            else:
                if room.host_id == pid:
                    room.host_id = room.players[0].id
                    room.players[0].is_host = True
                    for p in room.players[1:]:
                        p.is_host = False
                if room.state == "VOTING" and len(room.votes) >= len(room.players):
                    finish_voting(room)
                await emit_room(room)


if __name__ == "__main__":
    import os
    import uvicorn

    port = int(os.environ.get("PORT", 3000))
    print(f"\n  IMPOSTER X Online · port {port}\n")
    uvicorn.run(app, host="0.0.0.0", port=port)
