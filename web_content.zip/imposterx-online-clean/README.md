# IMPOSTER X · Online Multiplayer

Real-time multiplayer — **Create Room / Join Room**.
Everyone plays on their **own phone**. No login.

## Run

```bash
cd imposterx-online
pip install fastapi uvicorn
python server/app.py
```

Open **http://localhost:3000** on every device (same network or public host).

```bash
PORT=8080 python server/app.py
```

## How to play

1. **Host** → Create Room → share the 6-letter code
2. **Friends** → Join Room → enter code + name
3. Host starts when **≥ 4 players**
4. Everyone taps **their own card** privately
5. Discuss (random player starts)
6. Vote (if enabled) or host reveals Imposter

## Features

- Create / Join room with 6-character code
- Live lobby (kick, settings)
- Private role cards per device
- Optional Imposter hint + voting
- Play Again (same players) / Back to Lobby

## Tech

- Backend: Python · FastAPI · WebSockets
- Frontend: Vanilla JS
- Rooms: In-memory

© 2026 IMPOSTER X · MRXg60
