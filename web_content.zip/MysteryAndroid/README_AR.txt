MYSTERY ULTIMATE — مشروع Android

هذا مشروع Android Studio جاهز لفتحِه وبناء APK، لكنه ليس ملف APK مُجمّعاً.
لم أتمكن من إخراج APK موقّع/قابل للتثبيت مباشرة في بيئة المحادثة لعدم توفر Android SDK وGradle.

طريقة بناء APK:
1) ثبّت Android Studio على حاسوب.
2) افتح مجلد MysteryAndroid عبر File > Open.
3) انتظر Gradle Sync واوافق على تثبيت مكونات Android SDK إذا طُلب ذلك.
4) من القائمة اختر Build > Build Bundle(s) / APK(s) > Build APK(s).
5) بعد نجاح البناء اضغط Locate للحصول على app-debug.apk.
6) انقل APK إلى هاتف Android وثبّته. ثبّت فقط الملف الذي بنيته من هذا المشروع.

اللعبة موجودة داخل:
app/src/main/assets/index.html

ملاحظة: حفظ النقاط والتقدم يتم محلياً على الجهاز داخل WebView.
