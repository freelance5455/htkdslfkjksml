/* ============================================================
   PENGGILAS — BAZI DATA FOUNDATION
   Standard: English + Pinyin + Hanzi
   Registry: STATIC DATA / REFERENCE ONLY
   No calculation / interpretation
   ============================================================ */

const CLASSICAL_RULE_REGISTRY = {
  version: "CRR-1.3",
  language: "English + Pinyin + Hanzi",
  policy: "Compatibility metadata only. Executable B/C authority is data/rules/classical_rules_B_C.js; no unsupported numeric weights are introduced.",
  auditMatrixId: "AC-RULE-AUDIT-1.0",
  sources: [
    {
      id: "ZPZQ",
      title: "Zi Ping Zhen Quan (子平真诠)",
      chapters: ["Lun Yong Shen (论用神)", "Lun Yong Shen Bian Hua (论用神变化)"],
      url: "https://luckclub.cn/bazi/002/010/",
      notes: "Month Command (月令) is the primary basis; five classical approaches are recorded: Support-Suppress (扶抑), Disease-Medicine (病药), Climate Regulation (调候), Follow the Dominant Qi (专旺), and Communication/Bridging (通关)."
    },
    {
      id: "ZPZQ-BH",
      title: "Zi Ping Zhen Quan — Yong Shen Changes (子平真诠·论用神变化)",
      url: "https://luckclub.cn/bazi/002/012/",
      notes: "Useful-God/pattern function can change through Stem Exposure (透干) and Branch Combinations / Assemblies (会合); a change does not automatically erase the original pattern."
    },
    {
      id: "QTBJ",
      title: "Qiong Tong Bao Jian (穷通宝鉴)",
      url: "https://zh.wikisource.org/zh/%E7%A9%B7%E9%80%9A%E5%AE%9D%E9%91%91",
      notes: "Climate Regulation (调候) is treated as a distinct seasonal method. Source-locked month × Day-Master rules are added only where the classical text explicitly supplies them."
    },
    {
      id: "ZPZQ-REN-YUAN",
      title: "Zi Ping Zhen Quan — Ren Yuan Si Ling (子平真诠·Day-Precise Seasonal Qi (人元司令分野))",
      url: "https://www.anhappy.com/share/books/others/books/%E5%9B%BD%E5%AD%A6/%E5%AD%90%E5%B9%B3%E7%9C%9F%E8%AF%A0%E8%AF%84%E6%B3%A8.pdf",
      notes: "Day-precise month-command reference table. Locked variant: Wu Month (午月): Bing 10 (丙10) / Ji 9 (己9) / Ding 11 (丁11); other months use the corresponding source table. Used as supporting temporal-Qi evidence, not as a one-shot Ge Ju override. San Ming Tong Hui — Human Element Seasonal Allocation (三命通会·论人元司事) preserves a different allocation table, so PENGGILAS does not blend the two variants."
    },
    {
      id: "ZPZQ-YANGREN",
      title: "Zi Ping Zhen Quan — Yang Ren (子平真诠·论阳刃)",
      url: "https://shuyuan.zhiming.life/read/%E5%AD%90%E5%B9%B3%E7%9C%9F%E8%AF%A0/43",
      notes: "Yang Ren (阳刃) is a distinct structural pattern for the relevant Yang Day Masters. Officer / Killing control (官/煞) and Wealth / Resource support (财/印) are source-screened; Output Stars (食伤) are reported as a competing factor rather than an automatic failure. Full Formation / Breaking / Rescue (Pattern Formation (成格)/败格/救应) remains rule-status dependent."
    },
    {
      id: "ZPZQ-JIANLU",
      title: "Zi Ping Zhen Quan — Jian Lu / Yue Jie (子平真诠·论建禄月劫)",
      url: "https://www.8bei8.com/book/zipingzhenquanpingzhu_47.html",
      notes: "Establishing Prosperity / Month Robbery (建禄/月劫) does not itself serve as the final Useful God; the chart selects among Wealth / Officer / Killing / Output (Wealth/Officer (财官)煞食) through the natal structure, with source-described support requirements."
    },
    {
      id: "QTBJ-BING-WU",
      title: "Qiong Tong Bao Jian — Bing Fire in Wu Month (穷通宝鉴·五月丙火)",
      url: "https://luckclub.cn/bazi/004/029/",
      notes: "Bing Fire in the Fifth Month (五月丙火): Ren Water (壬水) is the primary climate-regulation candidate; Geng Metal (庚金) is an assisting source. The text warns about Wu/Ji Earth stem interference (戊己干) and Ding-Ren Combination (丁壬合). This rule is source-derived and does not equate Gui Water (癸水) with Ren Water (壬水)."
    }
  ],
  methods: {
    fuYi: {
      id: "ZP-FUYI-001",
      english: "Support-Suppress",
      hanzi: "扶抑",
      status: "SOURCE_DERIVED",
      rule: "Strong Day Master is restrained; weak Day Master is supported. Do not collapse Balanced/Borderline into either side."
    },
    bingYao: {
      id: "ZP-BINGYAO-001",
      english: "Disease-Medicine",
      hanzi: "病药",
      status: "SOURCE_DERIVED",
      rule: "Identify the factor that damages the desired support/suppression arrangement (病), then identify what removes that problem (药)."
    },
    tiaoHou: {
      id: "ZP-TIAOHOU-001",
      english: "Climate Regulation",
      hanzi: "调候",
      status: "SOURCE_DERIVED",
      rule: "When seasonal climate is excessively cold or dry/hot, climate regulation becomes a priority. Exact element/stem selection is NOT deterministic here until the Qiong Tong Bao Jian table is source-locked."
    },
    zhuanWang: {
      id: "ZP-ZHUANWANG-001",
      english: "Follow the Dominant Qi",
      hanzi: "专旺",
      status: "SOURCE_DERIVED",
      rule: "Use the source-specific Follow-the-Dominant-Qi / Follow-Strength conditions (从旺/从强): 从旺 requires overwhelming 比劫, Resource generation/support (印生) and no Officer/Killing control (官杀制); 从强 requires strong Resource + Companion emphasis and Day-Master Month Command support (印比重、日主当令) and no Wealth/Officer (财官). Do not infer 专旺 from one dominant element or a project weight alone."
    },
    tongGuan: {
      id: "ZP-TONGGUAN-001",
      english: "Communication / Bridging",
      hanzi: "通关",
      status: "SOURCE_DERIVED",
      rule: "When two forces are in active active controlling conflict / obstruction (克战/关隔), identify the intervening Sheng-cycle element and test whether it actually connects the two sides. Mediator presence is only a passage candidate; no unsupported quantitative threshold is invented."
    }
,
    renYuan: {
      id: "ZPZQ-REN-YUAN-001", english: "Day-precise Seasonal Qi", hanzi: "Day-Precise Seasonal Qi (人元司令分野)", status: "SOURCE_DERIVED",
      rule: "Use the locked month/day commander table as a supporting temporal-Qi reference; do not replace Month Command / Stem Exposure / Branch Combinations (月令/透干/会合) pattern logic solely from the day number."
    },
    yangRen: {
      id: "ZPZQ-YANGREN-001", english: "Yang Blade Pattern", hanzi: "阳刃格", status: "SOURCE_SCREENED",
      rule: "For the selected Zi Ping profile, recognize the relevant Yang Day Master + Yang Ren month configuration; screen exposed 官/煞 and exposed 财印; treat Hurting Officer (伤官) as a base-forming exclusion; evaluate source-described Output rescue (伤食救应) separately; do not confirm final Formation / Breaking / Rescue (成格/败格/救应) until the applicable closure conditions are satisfied."
    },
    huaProfile: {
      id: "ZP-HUA-SCREEN-001", english: "Stem Combination Transformation Screen", hanzi: "天干合化", status: "SOURCE_SCREENED",
      rule: "Month Command support is required. A configured clash involving either combining stem's sitting branch blocks confirmation. This is a selected source-screen profile, not a universal school rule."
    },
    rootHierarchy: {
      id: "ZP-ROOT-HIER-001", english: "Root Quality Hierarchy", hanzi: "根气层级", status: "QUALITATIVE",
      rule: "Main Qi root is reported above Middle/Residual root qualitatively; no numeric root bonus is invented."
    },
    strengthScreen: {
      id: "ZP-WANGSHU-SCREEN-001", english: "Day-Master Strength Evidence Screen", hanzi: "旺衰证据筛", status: "SOURCE_SCREENED",
      rule: "Use 月令 as the primary coordinate, then inspect Day-Master strength/weakness (旺弱) through the remaining 干支. This screen is qualitative only; it does not invent a universal numeric Day-Master Strength score (旺衰) or replace school-specific reconciliation."
    },
    tiaoHouBingWu: {
      id: "QTBJ-BING-WU-001", english: "Bing Fire in Wu Month", hanzi: "五月丙火", status: "SOURCE_DERIVED",
      rule: "For Bing Day Master in Wu Month (丙日午月), 壬水 is the primary climate-regulation candidate and 庚金 an assisting source; visible/hidden presence is reported separately and no automatic substitution of Gui Water (癸水) for Ren Water (壬水) is made."
    }
  }
};

const AC_RULE_AUDIT_MATRIX = [
  // A — FOUNDATION
  {id:"A-A1-01",section:"A1",field:"completenessStatus",type:"DOC",status:"IMPLEMENTED",finding:"Foundation-data completeness is distinct from Classical-rule completeness.",source:"PENGGILAS audit policy"},
  {id:"A-A2-01",section:"A2",field:"Da Yun direction",type:"SOURCE_LOCK",status:"CONFIGURED",finding:"Gender + year-stem polarity convention is configured and should remain school-labelled.",source:"Project convention; source registry required"},
  {id:"A-A3-01",section:"A3",field:"BaZi time",type:"PROJECT_PARAMETER",status:"LOCKED",finding:"True Solar Time is used for the BaZi calculation path.",source:"PENGGILAS project lock"},
  {id:"A-A3-02",section:"A3",field:"Jie Qi boundary",type:"VERIFICATION",status:"IMPLEMENTED",finding:"Second-level Jie Qi timestamps are retained; boundary tests are required for regression.",source:"PENGGILAS solar/Jie Qi engine"},
  {id:"A-A5-01",section:"A5",field:"Hidden Stems",type:"METHOD",status:"STRUCTURAL_ONLY",finding:"Hidden-Stem presence must not be treated as equal Qi strength without a source-locked weighting rule.",source:"PENGGILAS method policy"},
  {id:"A-A7-01",section:"A7",field:"Seasonal state",type:"SOURCE_DERIVED",status:"IMPLEMENTED",finding:"Day-precise seasonal Qi segmentation (Day-Precise Seasonal Qi (人元司令分野)) is implemented as a source-locked supporting reference using the selected Zi Ping Zhen Quan table.",source:"ZPZQ-REN-YUAN-001"},
  {id:"A-A8-01",section:"A8",field:"Adjusted weight",type:"HEURISTIC",status:"PROJECT_METRIC",finding:"Wang/Xiang/Xiu/Qiu/Si multipliers are project-defined descriptive weights, not a complete Classical 旺衰 formula.",source:"PENGGILAS project metric"},
  {id:"A-A8-02",section:"A8",field:"Five-element strength",type:"RULE_GAP",status:"OPEN",finding:"No source-locked quantitative hierarchy combines month command, roots, visible stems, hidden stems, season and interactions into one Classical strength score.",source:"Rule registry; source extraction pending"},
  {id:"A-A9-01",section:"A9",field:"Yin/Yang ratio",type:"METHOD",status:"STRUCTURAL_COUNT",finding:"Ratio is a structural count, not weighted energetic balance.",source:"PENGGILAS method policy"},
  {id:"A-A10-01",section:"A10",field:"Ten-God frequency",type:"METHOD",status:"STRUCTURAL_COUNT",finding:"Frequency is presence distribution, not automatic structural dominance.",source:"PENGGILAS method policy"},
  {id:"A-A11-01",section:"A11",field:"Root classification",type:"SOURCE_SCREENED",status:"IMPLEMENTED",finding:"Qualitative root hierarchy is implemented: Main Qi > Middle/Residual; no numeric root bonus is added.",source:"ZP-ROOT-HIER-001"},
  {id:"A-A12.2-01",section:"A12.2",field:"十二长生",type:"SOURCE_LOCK",status:"REFERENCE_ONLY",finding:"Cycle calculation is available; interpretive use as strength evidence is not independently asserted.",source:"PENGGILAS registry"},
  {id:"A-A12.3-01",section:"A12.3",field:"空亡",type:"SCOPE",status:"REFERENCE_ONLY",finding:"Kong Wang is calculated as a reference; downstream effect rules are not activated without source-locked conditions.",source:"PENGGILAS registry"},
  {id:"A-A12.4-01",section:"A12.4",field:"神煞",type:"SOURCE_LOCK",status:"PARTIAL",finding:"Shen Sha entries require per-rule source, reference point and school convention; they are not strength determinants.",source:"PENGGILAS registry"},
  {id:"A-A12.5-01",section:"A12.5",field:"Stem relations",type:"METHOD_GAP",status:"PARTIAL",finding:"Combination / Clash detection (合/冲) is mechanical; transformation or structural effect requires separate conditions.",source:"PENGGILAS interaction registry"},
  {id:"A-A12.6-01",section:"A12.6",field:"Branch relations",type:"METHOD_GAP",status:"PARTIAL",finding:"Six Combinations / Three Harmonies / Three Meetings / Half Combination / Clash / Punishment / Harm / Break (六合/三合/三会/半合/冲/刑/害/破) detection exists; precedence among competing interactions is not source-locked.",source:"PENGGILAS interaction registry"},
  {id:"A-A12.7-01",section:"A12.7",field:"Hua / 化",type:"SOURCE_SCREENED",status:"IMPLEMENTED_RULE_STATUS",finding:"Configured source-screen now checks Month-Command support and sitting-branch obstruction; no unsupported final Hua is emitted.",source:"ZP-HUA-SCREEN-001; ZPZQ-BH"},
  {id:"A-A12.9-01",section:"A12.9",field:"Ge Ju candidate",type:"DATAFLOW",status:"SYNCED",finding:"A12.9 remains the Section-A display slot and is synchronized from authoritative B3 after Core B execution.",source:"Core A → Core B dataflow"},
  {id:"A-A13-01",section:"A13",field:"命宫/胎元",type:"VERIFICATION",status:"CALCULATED",finding:"Internal/library cross-check is not independent Classical-source verification.",source:"PENGGILAS calculation provenance"},
  {id:"A-A14-01",section:"A14",field:"Da Yun direction",type:"SOURCE_LOCK",status:"CONFIGURED",finding:"Direction convention is configured; school provenance should remain explicit.",source:"Project convention"},
  {id:"A-A14-02",section:"A14",field:"Starting age",type:"PROJECT_PARAMETER",status:"LOCKED",finding:"Actual/Elapsed Age (周岁) is the display convention; library Nominal Age (虚岁) is not used for display.",source:"PENGGILAS project lock"},
  {id:"A-A15-01",section:"A15",field:"Integrity",type:"VERIFICATION",status:"INTERNAL_ONLY",finding:"Internal registry/format integrity is verified; independent astronomical verification is not claimed.",source:"Core A internal checks"},
  {id:"A-A16-01",section:"A16",field:"Verification notes",type:"VERIFICATION",status:"SCOPED",finding:"Verification rows record concrete checks; they do not upgrade results to independent source verification.",source:"Core A audit ledger"},
  {id:"A-A17-01",section:"A17",field:"Documentation",type:"DOC",status:"FIXED",finding:"Additional Notes are kept compact; the full A-C audit matrix is stored separately for machine-readable provenance.",source:"PENGGILAS documentation policy — audit matrix is non-runtime"},

  // B — PROFILE & STRUCTURE
  {id:"B-B1-01",section:"B1",field:"Day Master strength",type:"SOURCE_SCREENED",status:"IMPLEMENTED_RULE_STATUS",finding:"B1 now exposes a qualitative Classical strength evidence screen using 月令 first, then root and Resource / Companion support (印/比) signals; the existing numeric Support-Suppress comparison remains a project metric.",source:"ZP-WANGSHU-SCREEN-001; ZPZQ"},
  {id:"B-B1-02",section:"B1",field:"Balanced state",type:"METHOD",status:"IMPLEMENTED",finding:"Equal project support/drain remains Balanced/Borderline; the qualitative Classical screen does not force a final 旺衰 label when evidence is mixed.",source:"PENGGILAS rule patch; ZP-WANGSHU-SCREEN-001"},
  {id:"B-B2-01",section:"B2",field:"Month Command",type:"SOURCE_SCREENED",status:"IMPLEMENTED_RULE_STATUS",finding:"B2 now exposes a qualitative hierarchy: Month Command (月令) → Main Qi (本气) → Middle / Residual Qi (中气/余气), with day-precise Day-Precise Seasonal Qi (人元司令分野) as supporting temporal evidence. No numeric classical weighting is invented, and the selected Zi Ping Zhen Quan table is not blended with the different 三命通会 allocation table.",source:"ZPZQ-REN-YUAN-001; San Ming Tong Hui — Human Element Seasonal Allocation (三命通会·论人元司事) comparison policy"},
  {id:"B-B3-01",section:"B3",field:"Ge Ju",type:"SOURCE_SCREENED",status:"IMPLEMENTED_RULE_STATUS",finding:"Yang Ren screening reports Officer / Killing (官/煞), Wealth (财), Resource (印), and Output Stars (食伤) separately; final Formation / Breaking / Rescue (成格/败格/救应) remains rule-status dependent.",source:"ZPZQ-YANGREN-001; ZPZQ-JIANLU"},
  {id:"B-B3-02",section:"B3",field:"Special patterns",type:"RULE_SCOPE",status:"RULE_STATUS_DEPENDENT",finding:"Yang Ren is source-screened; complete Following / Transformation Patterns (从格 / 化格) evaluators remain rule-status dependent and are not inferred from a single structural condition.",source:"Classical Rule Registry"},
  {id:"B-B4-01",section:"B4",field:"Ten-God distribution",type:"METHOD",status:"STRUCTURAL_COUNT",finding:"Frequency summary must not be presented as dominant structural role.",source:"PENGGILAS method policy"},
  {id:"B-B5-01",section:"B5",field:"Root strength",type:"SOURCE_SCREENED",status:"IMPLEMENTED",finding:"Root quality is classified qualitatively without an invented numeric bonus; B1 consumes the existing aggregate once.",source:"ZP-ROOT-HIER-001"},
  {id:"B-B6-01",section:"B6",field:"Stem relations",type:"METHOD_GAP",status:"SOURCE-SCOPED",finding:"Detection and provenance are implemented; simultaneous-relation effect precedence remains school-sensitive and is therefore not silently collapsed into a universal ranking.",source:"PENGGILAS interaction registry"},
  {id:"B-B7-01",section:"B7",field:"Branch relations",type:"METHOD_GAP",status:"SOURCE-SCOPED",finding:"Detection and classification are implemented; multiple simultaneous interactions are retained without a universal precedence claim because school-specific precedence is not source-locked.",source:"PENGGILAS interaction registry"},
  {id:"B-B8-01",section:"B8",field:"Hua",type:"SOURCE_SCREENED",status:"IMPLEMENTED_RULE_STATUS",finding:"Configured Hua obstruction screening is implemented; school-specific variants remain explicitly scoped.",source:"ZP-HUA-SCREEN-001"},
  {id:"B-B9-01",section:"B9",field:"Structural configuration",type:"DERIVED",status:"DERIVED_FROM_B3",finding:"B9 packages B3 evidence; it is not an independent evaluator.",source:"Core B architecture"},
  {id:"B-B11-01",section:"B11",field:"Qi Flow",type:"METHOD_GAP",status:"EXPLICITLY_SCOPED",finding:"UI field is retained for contract compatibility, but the result explicitly identifies itself as Element Presence / Sheng-Cycle Continuity and not a complete Qi-Flow receiver/blockage model (气流).",source:"Core B implementation"},
  {id:"B-B12-01",section:"B12",field:"Balance",type:"HEURISTIC",status:"PROJECT_METRIC",finding:"Highest project weight is not automatically Excessive Strength (太旺/太过); absence is not automatically deficiency.",source:"PENGGILAS project metric"},
  {id:"B-B13-01",section:"B13",field:"扶抑",type:"PROVISIONAL",status:"RULE_STATUS_DEPENDENT",finding:"Support-Suppress produces a candidate through B1; it does not by itself finalize Useful God (用神).",source:"Zi Ping Zhen Quan framework"},
  {id:"B-B13-02",section:"B13",field:"调候",type:"SOURCE_DERIVED",status:"PARTIAL_IMPLEMENTED",finding:"Source-locked Bing Fire in the Fifth Month rule (五月丙火) is implemented: Ren Water (壬水) primary, Geng Metal (庚金) assisting; other month × Day-Master combinations remain rule-status dependent until source-locked.",source:"QTBJ-BING-WU-001"},
  {id:"B-B13-03",section:"B13",field:"Disease-Medicine",type:"SOURCE_SCREENED",status:"IMPLEMENTED_RULE_STATUS",finding:"B13 now records structural disease signals explicitly and refuses to infer a disease or medicine winner from raw element dominance alone; final Disease-Medicine closure remains source-profile dependent.",source:"ZP-BINGYAO-001; Core B13 disease screen"},
  {id:"B-B13-04",section:"B13",field:"Communication / Bridging",type:"SOURCE_SCREENED",status:"IMPLEMENTED_RULE_STATUS",finding:"B13 consumes B11 opposed-force, mediator, and passage-candidate evidence; mediator presence alone never closes Communication / Bridging (通关).",source:"ZP-TONGGUAN-001; Core B11/B13"},
  {id:"B-B13-05",section:"B13",field:"Following Structures",type:"SOURCE_SCREENED",status:"IMPLEMENTED_RULE_STATUS",finding:"B13 supports only Follow-Dominant Pattern (从旺), Follow-Strength Pattern (从强), and Follow-the-Trend Pattern (从势). Follow-Weakness Pattern (从弱), Follow-Wealth (从财), and Follow-Officer / Follow-Killing (从官/从杀) are not executable subtypes and must remain fail-closed.",source:"DTT_WANG; Core B13 following profiles"},
  {id:"B-B13-06",section:"B13",field:"Final Useful God (用神)",type:"METHOD_RECONCILIATION",status:"IMPLEMENTED_RULE_STATUS",finding:"Multi-method conflict is surfaced explicitly; Support-Suppress and source-specific Climate Regulation candidates are not silently collapsed.",source:"ZP-FUYI-001; QTBJ-BING-WU-001; B13 rule status"},
  {id:"B-B15-01",section:"B15",field:"Structural priority",type:"PROJECT_PARAMETER",status:"PROJECT_MODEL",finding:"Yue Ling → Root → Yong Shen → Ge Ju ordering is a PENGGILAS synthesis priority, not a universal Classical ranking.",source:"PENGGILAS project model"},
  {id:"B-B16-01",section:"B16",field:"Synthesis",type:"DERIVED",status:"PROVISIONAL",finding:"Synthesis consumes B1/B3/B13; unresolved upstream rules propagate downstream.",source:"Core B architecture"},
  {id:"B-B17-01",section:"B17",field:"Verification",type:"VERIFICATION",status:"SCOPED",finding:"Cross-engine checks are rule-level checks, not independent astronomical/Classical verification.",source:"Core B audit scope"},

  // C — TEMPORAL DYNAMICS
  {id:"C-C1-01",section:"C1",field:"Tou Qing / 透清",type:"METHOD_GAP",status:"INDICATOR_ONLY",finding:"Current logic is elemental alignment, not a complete 透清 determination.",source:"Core C implementation"},
  {id:"C-C2-01",section:"C2",field:"Hua under time",type:"SOURCE_SCREENED",status:"RULE_STATUS_DEPENDENT",finding:"Temporal He/Hua consumes the source-screened transformation status and does not independently confirm Hua.",source:"ZP-HUA-SCREEN-001; Core C rule status"},
  {id:"C-C2-02",section:"C2",field:"Conflict wording",type:"DOC",status:"FIXED",finding:"Interpretive wording such as ‘potential instability’ is replaced by mechanical interaction evidence.",source:"PENGGILAS documentation policy — audit matrix is non-runtime"},
  {id:"C-C3-01",section:"C3",field:"Qi response",type:"METHOD_GAP",status:"PARTIAL",finding:"Current response uses temporal stem/branch/hidden-stem presence; it is not a full weighted temporal Qi model.",source:"Core C implementation"},
  {id:"C-C3-02",section:"C3",field:"Natal absence",type:"METHOD",status:"STRUCTURAL_ONLY",finding:"‘Gap’ means A8 structural absence; it does not imply Classical deficiency.",source:"PENGGILAS method policy"},
  {id:"C-C4-01",section:"C4",field:"Cheng Ge",type:"RULE_GAP",status:"PROVISIONAL",finding:"Da Yun Ten-God reinforcement alone does not confirm Pattern Formation (成格).",source:"Zi Ping Zhen Quan framework"},
  {id:"C-C4-02",section:"C4",field:"Bian Ge",type:"RULE_GAP",status:"PROVISIONAL",finding:"Month-Branch clash is disruption evidence, not automatic Pattern Transformation / Change (变格).",source:"Core C rule status policy"},
  {id:"C-C5-01",section:"C5",field:"Temporal elements",type:"METHOD_GAP",status:"PRESENCE_ONLY",finding:"Temporal composition now preserves counts and directional support/drain indicators, but no weighted temporal 旺衰 score or ranking is claimed.",source:"Core C implementation"},
  {id:"C-C5-02",section:"C5",field:"Dominance wording",type:"DOC",status:"FIXED",finding:"‘Dominant’ is reserved for the natal B12 project metric; temporal output reports composition and matches only.",source:"PENGGILAS documentation policy — audit matrix is non-runtime"},
  {id:"C-C6-01",section:"C6",field:"Temporal determination",type:"RULE_STATUS_PROPAGATION",status:"IMPLEMENTED",finding:"C6 propagates upstream B3/B13 rule-status propagation and does not emit deterministic temporal determination while upstream methods conflict or remain unresolved.",source:"Core C architecture; B13 rule status"},
  {id:"C-C7-01",section:"C7",field:"Evidence & verification",type:"VERIFICATION",status:"SCOPED",finding:"C7 is provenance assembly; it does not itself perform independent verification.",source:"Core C audit scope"}
];

const BAZI_DATA = {

  /* ==========================================================
     01. FIVE ELEMENTS / 五行
     ========================================================== */

  fiveElements: {
    Wood: {
      id: "Wood",
      english: "Wood",
      pinyin: "Mu",
      hanzi: "木"
    },
    Fire: {
      id: "Fire",
      english: "Fire",
      pinyin: "Huo",
      hanzi: "火"
    },
    Earth: {
      id: "Earth",
      english: "Earth",
      pinyin: "Tu",
      hanzi: "土"
    },
    Metal: {
      id: "Metal",
      english: "Metal",
      pinyin: "Jin",
      hanzi: "金"
    },
    Water: {
      id: "Water",
      english: "Water",
      pinyin: "Shui",
      hanzi: "水"
    }
  },


  /* ==========================================================
     02. HEAVENLY STEMS / 天干
     ========================================================== */

  heavenlyStems: {
    Jia: {
      id: "Jia",
      english: "Jia",
      pinyin: "Jiǎ",
      hanzi: "甲",
      element: "Wood",
      polarity: "Yang"
    },
    Yi: {
      id: "Yi",
      english: "Yi",
      pinyin: "Yǐ",
      hanzi: "乙",
      element: "Wood",
      polarity: "Yin"
    },
    Bing: {
      id: "Bing",
      english: "Bing",
      pinyin: "Bǐng",
      hanzi: "丙",
      element: "Fire",
      polarity: "Yang"
    },
    Ding: {
      id: "Ding",
      english: "Ding",
      pinyin: "Dīng",
      hanzi: "丁",
      element: "Fire",
      polarity: "Yin"
    },
    Wu: {
      id: "Wu",
      english: "Wu",
      pinyin: "Wù",
      hanzi: "戊",
      element: "Earth",
      polarity: "Yang"
    },
    Ji: {
      id: "Ji",
      english: "Ji",
      pinyin: "Jǐ",
      hanzi: "己",
      element: "Earth",
      polarity: "Yin"
    },
    Geng: {
      id: "Geng",
      english: "Geng",
      pinyin: "Gēng",
      hanzi: "庚",
      element: "Metal",
      polarity: "Yang"
    },
    Xin: {
      id: "Xin",
      english: "Xin",
      pinyin: "Xīn",
      hanzi: "辛",
      element: "Metal",
      polarity: "Yin"
    },
    Ren: {
      id: "Ren",
      english: "Ren",
      pinyin: "Rén",
      hanzi: "壬",
      element: "Water",
      polarity: "Yang"
    },
    Gui: {
      id: "Gui",
      english: "Gui",
      pinyin: "Guǐ",
      hanzi: "癸",
      element: "Water",
      polarity: "Yin"
    }
  },


  /* ==========================================================
     03. EARTHLY BRANCHES / 地支
     ========================================================== */

  earthlyBranches: {
    Zi: {
      id: "Zi",
      english: "Zi",
      pinyin: "Zǐ",
      hanzi: "子",
      element: "Water",
      polarity: "Yang"
    },
    Chou: {
      id: "Chou",
      english: "Chou",
      pinyin: "Chǒu",
      hanzi: "丑",
      element: "Earth",
      polarity: "Yin"
    },
    Yin: {
      id: "Yin",
      english: "Yin",
      pinyin: "Yín",
      hanzi: "寅",
      element: "Wood",
      polarity: "Yang"
    },
    Mao: {
      id: "Mao",
      english: "Mao",
      pinyin: "Mǎo",
      hanzi: "卯",
      element: "Wood",
      polarity: "Yin"
    },
    Chen: {
      id: "Chen",
      english: "Chen",
      pinyin: "Chén",
      hanzi: "辰",
      element: "Earth",
      polarity: "Yang"
    },
    Si: {
      id: "Si",
      english: "Si",
      pinyin: "Sì",
      hanzi: "巳",
      element: "Fire",
      polarity: "Yin"
    },
    Wu: {
      id: "Wu",
      english: "Wu",
      pinyin: "Wǔ",
      hanzi: "午",
      element: "Fire",
      polarity: "Yang"
    },
    Wei: {
      id: "Wei",
      english: "Wei",
      pinyin: "Wèi",
      hanzi: "未",
      element: "Earth",
      polarity: "Yin"
    },
    Shen: {
      id: "Shen",
      english: "Shen",
      pinyin: "Shēn",
      hanzi: "申",
      element: "Metal",
      polarity: "Yang"
    },
    You: {
      id: "You",
      english: "You",
      pinyin: "Yǒu",
      hanzi: "酉",
      element: "Metal",
      polarity: "Yin"
    },
    Xu: {
      id: "Xu",
      english: "Xu",
      pinyin: "Xū",
      hanzi: "戌",
      element: "Earth",
      polarity: "Yang"
    },
    Hai: {
      id: "Hai",
      english: "Hai",
      pinyin: "Hài",
      hanzi: "亥",
      element: "Water",
      polarity: "Yin"
    }
  },


  /* ==========================================================
     04. HIDDEN STEMS / 藏干
     ========================================================== */

  hiddenStems: {
    Zi: [
      ["Gui", "Main", "Ben Qi", "本气"]
    ],

    Chou: [
      ["Ji", "Main", "Ben Qi", "本气"],
      ["Gui", "Middle", "Zhong Qi", "中气"],
      ["Xin", "Residual", "Yu Qi", "余气"]
    ],

    Yin: [
      ["Jia", "Main", "Ben Qi", "本气"],
      ["Bing", "Middle", "Zhong Qi", "中气"],
      ["Wu", "Residual", "Yu Qi", "余气"]
    ],

    Mao: [
      ["Yi", "Main", "Ben Qi", "本气"]
    ],

    Chen: [
      ["Wu", "Main", "Ben Qi", "本气"],
      ["Yi", "Middle", "Zhong Qi", "中气"],
      ["Gui", "Residual", "Yu Qi", "余气"]
    ],

    Si: [
      ["Bing", "Main", "Ben Qi", "本气"],
      ["Geng", "Middle", "Zhong Qi", "中气"],
      ["Wu", "Residual", "Yu Qi", "余气"]
    ],

    Wu: [
      ["Ding", "Main", "Ben Qi", "本气"],
      ["Ji", "Residual", "Yu Qi", "余气"]
    ],

    Wei: [
      ["Ji", "Main", "Ben Qi", "本气"],
      ["Ding", "Middle", "Zhong Qi", "中气"],
      ["Yi", "Residual", "Yu Qi", "余气"]
    ],

    Shen: [
      ["Geng", "Main", "Ben Qi", "本气"],
      ["Ren", "Middle", "Zhong Qi", "中气"],
      ["Wu", "Residual", "Yu Qi", "余气"]
    ],

    You: [
      ["Xin", "Main", "Ben Qi", "本气"]
    ],

    Xu: [
      ["Wu", "Main", "Ben Qi", "本气"],
      ["Xin", "Middle", "Zhong Qi", "中气"],
      ["Ding", "Residual", "Yu Qi", "余气"]
    ],

    Hai: [
      ["Ren", "Main", "Ben Qi", "本气"],
      ["Jia", "Residual", "Yu Qi", "余气"]
    ]
  },


  /* ==========================================================
     05. POLARITY
     ========================================================== */

  polarity: {
    Yang: {
      english: "Yang",
      hanzi: "阳"
    },
    Yin: {
      english: "Yin",
      hanzi: "阴"
    }
  },


  /* ==========================================================
     06. QI POSITION
     ========================================================== */

  qiPosition: {
    Main: {
      english: "Main Qi",
      pinyin: "Ben Qi",
      hanzi: "本气"
    },
    Middle: {
      english: "Middle Qi",
      pinyin: "Zhong Qi",
      hanzi: "中气"
    },
    Residual: {
      english: "Residual Qi",
      pinyin: "Yu Qi",
      hanzi: "余气"
    }
  },


  /* ==========================================================
     07. TWELVE LIFE STAGES / 十二长生
     ========================================================== */

  lifeStages: {

    sequence: [
      {
        index: 1,
        id: "ChangSheng",
        english: "Birth/Growth",
        pinyin: "Chang Sheng",
        hanzi: "长生"
      },
      {
        index: 2,
        id: "MuYu",
        english: "Bath",
        pinyin: "Mu Yu",
        hanzi: "沐浴"
      },
      {
        index: 3,
        id: "GuanDai",
        english: "Attire",
        pinyin: "Guan Dai",
        hanzi: "冠带"
      },
      {
        index: 4,
        id: "LinGuan",
        english: "Officer",
        pinyin: "Lin Guan",
        hanzi: "临官"
      },
      {
        index: 5,
        id: "DiWang",
        english: "Emperor/Peak",
        pinyin: "Di Wang",
        hanzi: "帝旺"
      },
      {
        index: 6,
        id: "Shuai",
        english: "Fading",
        pinyin: "Shuai",
        hanzi: "衰"
      },
      {
        index: 7,
        id: "Bing",
        english: "Sickness",
        pinyin: "Bing",
        hanzi: "病"
      },
      {
        index: 8,
        id: "Si",
        english: "Death",
        pinyin: "Si",
        hanzi: "死"
      },
      {
        index: 9,
        id: "Mu",
        english: "Tomb",
        pinyin: "Mu",
        hanzi: "墓"
      },
      {
        index: 10,
        id: "Jue",
        english: "Extinction",
        pinyin: "Jue",
        hanzi: "绝"
      },
      {
        index: 11,
        id: "Tai",
        english: "Conception",
        pinyin: "Tai",
        hanzi: "胎"
      },
      {
        index: 12,
        id: "Yang",
        english: "Nourishment",
        pinyin: "Yang",
        hanzi: "养"
      }
    ],

    changShengStart: {
      Jia: {
        branch: "Hai",
        direction: "Shun"
      },
      Yi: {
        branch: "Wu",
        direction: "Ni"
      },
      Bing: {
        branch: "Yin",
        direction: "Shun"
      },
      Wu: {
        branch: "Yin",
        direction: "Shun"
      },
      Ding: {
        branch: "You",
        direction: "Ni"
      },
      Ji: {
        branch: "You",
        direction: "Ni"
      },
      Geng: {
        branch: "Si",
        direction: "Shun"
      },
      Xin: {
        branch: "Zi",
        direction: "Ni"
      },
      Ren: {
        branch: "Shen",
        direction: "Shun"
      },
      Gui: {
        branch: "Mao",
        direction: "Ni"
      }
    }
  },


  /* ==========================================================
     08. TEN GODS / 十神
     ========================================================== */

  tenGods: {
    BiJian: {
      english: "Companion / Friend",
      pinyin: "Bi Jian",
      hanzi: "比肩"
    },
    JieCai: {
      english: "Rob Wealth",
      pinyin: "Jie Cai",
      hanzi: "劫财"
    },
    ShiShen: {
      english: "Eating God",
      pinyin: "Shi Shen",
      hanzi: "食神"
    },
    ShangGuan: {
      english: "Hurting Officer",
      pinyin: "Shang Guan",
      hanzi: "伤官"
    },
    PianCai: {
      english: "Indirect Wealth",
      pinyin: "Pian Cai",
      hanzi: "偏财"
    },
    ZhengCai: {
      english: "Direct Wealth",
      pinyin: "Zheng Cai",
      hanzi: "正财"
    },
    QiSha: {
      english: "Seven Killings",
      pinyin: "Qi Sha",
      hanzi: "七杀"
    },
    ZhengGuan: {
      english: "Direct Officer",
      pinyin: "Zheng Guan",
      hanzi: "正官"
    },
    PianYin: {
      english: "Indirect Resource",
      pinyin: "Pian Yin",
      hanzi: "偏印"
    },
    ZhengYin: {
      english: "Direct Resource",
      pinyin: "Zheng Yin",
      hanzi: "正印"
    }
  },


  /* ==========================================================
     09. PILLARS
     ========================================================== */

  pillars: [
    "Year",
    "Month",
    "Day",
    "Hour"
  ],

  /* Runtime configuration used by the PENGGILAS project.
     These are explicit project parameters, not silently inferred
     from the classical registry. */
  projectConfig: {
    pillarKeys: ["year", "month", "day", "hour"],
    pillarLabels: { year: "Year", month: "Month", day: "Day", hour: "Hour" },
    eightCharSect: 2,
    seasonWeight: { Wang: 2.0, Xiang: 1.5, Xiu: 1.0, Qiu: 0.5, Si: 0.3 },
    shengCycle: { Wood: "Fire", Fire: "Earth", Earth: "Metal", Metal: "Water", Water: "Wood" },
    keCycle: { Wood: "Earth", Earth: "Water", Water: "Fire", Fire: "Metal", Metal: "Wood" }
  },


  /* ==========================================================
     10. JIA ZI
     ========================================================== */

  jiaZi: [],


  /* ==========================================================
     11. SEASONAL STATE / 旺相休囚死
     Registry only — no calculation / interpretation
     ========================================================== */

  seasonalState: {

    states: [
      {
        id: "Wang",
        english: "Prosperous",
        pinyin: "Wang",
        hanzi: "旺"
      },
      {
        id: "Xiang",
        english: "Supporting",
        pinyin: "Xiang",
        hanzi: "相"
      },
      {
        id: "Xiu",
        english: "Resting",
        pinyin: "Xiu",
        hanzi: "休"
      },
      {
        id: "Qiu",
        english: "Constrained",
        pinyin: "Qiu",
        hanzi: "囚"
      },
      {
        id: "Si",
        english: "Exhausted",
        pinyin: "Si",
        hanzi: "死"
      }
    ],

    seasonalOrder: [
      "Wood",
      "Fire",
      "Earth",
      "Metal",
      "Water"
    ],

    stateBySeason: {

      Wood: {
        Wang: "Wood",
        Xiang: "Fire",
        Xiu: "Water",
        Qiu: "Earth",
        Si: "Metal"
      },

      Fire: {
        Wang: "Fire",
        Xiang: "Earth",
        Xiu: "Wood",
        Qiu: "Metal",
        Si: "Water"
      },

      Earth: {
        Wang: "Earth",
        Xiang: "Metal",
        Xiu: "Fire",
        Qiu: "Water",
        Si: "Wood"
      },

      Metal: {
        Wang: "Metal",
        Xiang: "Water",
        Xiu: "Earth",
        Qiu: "Wood",
        Si: "Fire"
      },

      Water: {
        Wang: "Water",
        Xiang: "Wood",
        Xiu: "Metal",
        Qiu: "Fire",
        Si: "Earth"
      }
    },

    seasonByMonthBranch: {
      Yin: "Wood",
      Mao: "Wood",
      Chen: "Earth",

      Si: "Fire",
      Wu: "Fire",
      Wei: "Earth",

      Shen: "Metal",
      You: "Metal",
      Xu: "Earth",

      Hai: "Water",
      Zi: "Water",
      Chou: "Earth"
    }
  },


  /* ==========================================================
     12. XUN / 旬
     Registry only — no calculation / interpretation
     ========================================================== */

  xun: {

    cycles: [

      {
        id: "JiaZiXun",
        index: 1,
        startGanZhi: "Jia Zi",
        startStem: "Jia",
        startBranch: "Zi",
        endGanZhi: "Gui You",
        endStem: "Gui",
        endBranch: "You",
        emptyBranches: ["Xu", "Hai"]
      },

      {
        id: "JiaXuXun",
        index: 2,
        startGanZhi: "Jia Xu",
        startStem: "Jia",
        startBranch: "Xu",
        endGanZhi: "Gui Wei",
        endStem: "Gui",
        endBranch: "Wei",
        emptyBranches: ["Shen", "You"]
      },

      {
        id: "JiaShenXun",
        index: 3,
        startGanZhi: "Jia Shen",
        startStem: "Jia",
        startBranch: "Shen",
        endGanZhi: "Gui Si",
        endStem: "Gui",
        endBranch: "Si",
        emptyBranches: ["Wu", "Wei"]
      },

      {
        id: "JiaWuXun",
        index: 4,
        startGanZhi: "Jia Wu",
        startStem: "Jia",
        startBranch: "Wu",
        endGanZhi: "Gui Mao",
        endStem: "Gui",
        endBranch: "Mao",
        emptyBranches: ["Chen", "Si"]
      },

      {
        id: "JiaChenXun",
        index: 5,
        startGanZhi: "Jia Chen",
        startStem: "Jia",
        startBranch: "Chen",
        endGanZhi: "Gui Chou",
        endStem: "Gui",
        endBranch: "Chou",
        emptyBranches: ["Yin", "Mao"]
      },

      {
        id: "JiaYinXun",
        index: 6,
        startGanZhi: "Jia Yin",
        startStem: "Jia",
        startBranch: "Yin",
        endGanZhi: "Gui Hai",
        endStem: "Gui",
        endBranch: "Hai",
        emptyBranches: ["Zi", "Chou"]
      }
    ]
  },


  /* ==========================================================
     13. KONG WANG / 空亡
     Derived reference registry
     Registry only — no calculation / interpretation
     ========================================================== */

  kongWang: {

    reference: "Xun",

    fieldDefinitions: {
      xunNumber: "Xun cycle number",
      xunCycle: "Xun cycle identifier",
      emptyBranches: "Two Kong Wang / Empty Branches",
      applicationScope:
        "Reference point / pillar to which Kong Wang is applied"
    },

    emptyBranchesByXun: {
      JiaZiXun: ["Xu", "Hai"],
      JiaXuXun: ["Shen", "You"],
      JiaShenXun: ["Wu", "Wei"],
      JiaWuXun: ["Chen", "Si"],
      JiaChenXun: ["Yin", "Mao"],
      JiaYinXun: ["Zi", "Chou"]
    }
  },


  /* ==========================================================
     14. SHEN SHA / 神煞
     Registry only — no calculation / interpretation
     ========================================================== */

  shenSha: {

    registry: [

      {
        id: "YiMa",
        english: "Traveling Horse",
        pinyin: "Yi Ma",
        hanzi: "驿马",
        definition: "Mobility / movement reference",
        referenceType: "Day Branch or Year Branch",
        referencePoint: [
          "DayBranch",
          "YearBranch"
        ],
        requiredCondition: "Shen-Zi-Chen group",
        resultBranch: "Yin",
        ruleSource: "Yi Ma rule registry"
      },

      {
        id: "TaoHua",
        english: "Peach Blossom",
        pinyin: "Tao Hua",
        hanzi: "桃花",
        definition: "Peach Blossom reference",
        referenceType: "Day Branch or Year Branch",
        referencePoint: [
          "DayBranch",
          "YearBranch"
        ],
        requiredCondition: "Shen-Zi-Chen group",
        resultBranch: "You",
        ruleSource: "Tao Hua rule registry"
      },

      {
        id: "TianYiGuiRen",
        english: "Heavenly Virtue Nobleman",
        pinyin: "Tian Yi Gui Ren",
        hanzi: "天乙贵人",
        definition: "Nobleman reference",
        referenceType: "Day Master or Year Stem",
        referencePoint: [
          "DayMaster",
          "YearStem"
        ],
        requiredCondition: "Jia-Wu",
        resultBranches: [
          "Chou",
          "Wei"
        ],
        ruleSource: "Tian Yi Gui Ren rule registry"
      },

      {
        id: "HuaGai",
        english: "Canopy Star",
        pinyin: "Hua Gai",
        hanzi: "华盖",
        definition: "Canopy reference",
        referenceType: "Day Branch or Year Branch",
        referencePoint: [
          "DayBranch",
          "YearBranch"
        ],
        requiredCondition: "Shen-Zi-Chen group",
        resultBranch: "Chen",
        ruleSource: "Hua Gai rule registry"
      },

      {
        id: "LuShen",
        english: "Prosperity Star",
        pinyin: "Lu Shen",
        hanzi: "禄神",
        definition: "Same branch as Lin Guan reference",
        referenceType: "Heavenly Stem",
        referencePoint: [
          "DayMaster",
          "YearStem"
        ],
        calculationBasis: "Lin Guan",
        ruleSource: "Lu Shen rule registry"
      },

      {
        id: "YangRen",
        english: "Goat Blade",
        pinyin: "Yang Ren",
        hanzi: "羊刃",
        definition: "Yang Stem blade reference",
        referenceType: "Yang Heavenly Stem",
        referencePoint: [
          "DayMaster",
          "YearStem"
        ],
        calculationBasis:
          "One branch after Lu Shen / Di Wang",
        ruleSource: "Yang Ren rule registry"
      }

    ]
  },


  /* ==========================================================
     15. STANDARD ORDER
     ========================================================== */

  stemOrder: [
    "Jia",
    "Yi",
    "Bing",
    "Ding",
    "Wu",
    "Ji",
    "Geng",
    "Xin",
    "Ren",
    "Gui"
  ],

  branchOrder: [
    "Zi",
    "Chou",
    "Yin",
    "Mao",
    "Chen",
    "Si",
    "Wu",
    "Wei",
    "Shen",
    "You",
    "Xu",
    "Hai"
  ]

};


/* ============================================================
   16. 60 JIA ZI / 六十甲子 + NA YIN / 纳音
   ============================================================ */

const NAYIN = [

  ["Jia Zi", "甲子", "Hai Zhong Jin", "海中金", "Metal"],
  ["Yi Chou", "乙丑", "Hai Zhong Jin", "海中金", "Metal"],
  ["Bing Yin", "丙寅", "Lu Zhong Huo", "炉中火", "Fire"],
  ["Ding Mao", "丁卯", "Lu Zhong Huo", "炉中火", "Fire"],
  ["Wu Chen", "戊辰", "Da Lin Mu", "大林木", "Wood"],
  ["Ji Si", "己巳", "Da Lin Mu", "大林木", "Wood"],
  ["Geng Wu", "庚午", "Lu Pang Tu", "路旁土", "Earth"],
  ["Xin Wei", "辛未", "Lu Pang Tu", "路旁土", "Earth"],
  ["Ren Shen", "壬申", "Jian Feng Jin", "剑锋金", "Metal"],
  ["Gui You", "癸酉", "Jian Feng Jin", "剑锋金", "Metal"],

  ["Jia Xu", "甲戌", "Shan Tou Huo", "山头火", "Fire"],
  ["Yi Hai", "乙亥", "Shan Tou Huo", "山头火", "Fire"],
  ["Bing Zi", "丙子", "Jian Xia Shui", "涧下水", "Water"],
  ["Ding Chou", "丁丑", "Jian Xia Shui", "涧下水", "Water"],
  ["Wu Yin", "戊寅", "Cheng Tou Tu", "城头土", "Earth"],
  ["Ji Mao", "己卯", "Cheng Tou Tu", "城头土", "Earth"],
  ["Geng Chen", "庚辰", "Bai La Jin", "白蜡金", "Metal"],
  ["Xin Si", "辛巳", "Bai La Jin", "白蜡金", "Metal"],
  ["Ren Wu", "壬午", "Yang Liu Mu", "杨柳木", "Wood"],
  ["Gui Wei", "癸未", "Yang Liu Mu", "杨柳木", "Wood"],

  ["Jia Shen", "甲申", "Quan Zhong Shui", "泉中水", "Water"],
  ["Yi You", "乙酉", "Quan Zhong Shui", "泉中水", "Water"],
  ["Bing Xu", "丙戌", "Wu Shang Tu", "屋上土", "Earth"],
  ["Ding Hai", "丁亥", "Wu Shang Tu", "屋上土", "Earth"],
  ["Wu Zi", "戊子", "Pi Li Huo", "霹雳火", "Fire"],
  ["Ji Chou", "己丑", "Pi Li Huo", "霹雳火", "Fire"],
  ["Geng Yin", "庚寅", "Song Bai Mu", "松柏木", "Wood"],
  ["Xin Mao", "辛卯", "Song Bai Mu", "松柏木", "Wood"],
  ["Ren Chen", "壬辰", "Chang Liu Shui", "长流水", "Water"],
  ["Gui Si", "癸巳", "Chang Liu Shui", "长流水", "Water"],

  ["Jia Wu", "甲午", "Sha Zhong Jin", "沙中金", "Metal"],
  ["Yi Wei", "乙未", "Sha Zhong Jin", "沙中金", "Metal"],
  ["Bing Shen", "丙申", "Shan Xia Huo", "山下火", "Fire"],
  ["Ding You", "丁酉", "Shan Xia Huo", "山下火", "Fire"],
  ["Wu Xu", "戊戌", "Ping Di Mu", "平地木", "Wood"],
  ["Ji Hai", "己亥", "Ping Di Mu", "平地木", "Wood"],
  ["Geng Zi", "庚子", "Bi Shang Tu", "壁上土", "Earth"],
  ["Xin Chou", "辛丑", "Bi Shang Tu", "壁上土", "Earth"],
  ["Ren Yin", "壬寅", "Jin Bo Jin", "金箔金", "Metal"],
  ["Gui Mao", "癸卯", "Jin Bo Jin", "金箔金", "Metal"],

  ["Jia Chen", "甲辰", "Fu Deng Huo", "覆灯火", "Fire"],
  ["Yi Si", "乙巳", "Fu Deng Huo", "覆灯火", "Fire"],
  ["Bing Wu", "丙午", "Tian He Shui", "天河水", "Water"],
  ["Ding Wei", "丁未", "Tian He Shui", "天河水", "Water"],
  ["Wu Shen", "戊申", "Da Yi Tu", "大驿土", "Earth"],
  ["Ji You", "己酉", "Da Yi Tu", "大驿土", "Earth"],
  ["Geng Xu", "庚戌", "Chai Chuan Jin", "钗钏金", "Metal"],
  ["Xin Hai", "辛亥", "Chai Chuan Jin", "钗钏金", "Metal"],
  ["Ren Zi", "壬子", "Sang Tuo Mu", "桑柘木", "Wood"],
  ["Gui Chou", "癸丑", "Sang Tuo Mu", "桑柘木", "Wood"],

  ["Jia Yin", "甲寅", "Da Xi Shui", "大溪水", "Water"],
  ["Yi Mao", "乙卯", "Da Xi Shui", "大溪水", "Water"],
  ["Bing Chen", "丙辰", "Sha Zhong Tu", "沙中土", "Earth"],
  ["Ding Si", "丁巳", "Sha Zhong Tu", "沙中土", "Earth"],
  ["Wu Wu", "戊午", "Tian Shang Huo", "天上火", "Fire"],
  ["Ji Wei", "己未", "Tian Shang Huo", "天上火", "Fire"],
  ["Geng Shen", "庚申", "Shi Liu Mu", "石榴木", "Wood"],
  ["Xin You", "辛酉", "Shi Liu Mu", "石榴木", "Wood"],
  ["Ren Xu", "壬戌", "Da Hai Shui", "大海水", "Water"],
  ["Gui Hai", "癸亥", "Da Hai Shui", "大海水", "Water"]
];


/* ============================================================
   17. BUILD JIA ZI REFERENCE
   ============================================================ */

BAZI_DATA.jiaZi = NAYIN.map((x, i) => ({
  index: i + 1,
  ganZhi: x[0],
  hanzi: x[1],
  naYin: x[2],
  naYinHanzi: x[3],
  naYinElement: x[4],
  stem: x[0].split(" ")[0],
  branch: x[0].split(" ")[1]
}));


/* ============================================================
   18. TEN GODS MATRIX / 十神矩阵
   ============================================================ */

BAZI_DATA.tenGodsMatrix = {

  Jia: {
    Jia: "BiJian",
    Yi: "JieCai",
    Bing: "ShiShen",
    Ding: "ShangGuan",
    Wu: "PianCai",
    Ji: "ZhengCai",
    Geng: "QiSha",
    Xin: "ZhengGuan",
    Ren: "PianYin",
    Gui: "ZhengYin"
  },

  Yi: {
    Jia: "JieCai",
    Yi: "BiJian",
    Bing: "ShangGuan",
    Ding: "ShiShen",
    Wu: "ZhengCai",
    Ji: "PianCai",
    Geng: "ZhengGuan",
    Xin: "QiSha",
    Ren: "ZhengYin",
    Gui: "PianYin"
  },

  Bing: {
    Jia: "PianYin",
    Yi: "ZhengYin",
    Bing: "BiJian",
    Ding: "JieCai",
    Wu: "ShiShen",
    Ji: "ShangGuan",
    Geng: "PianCai",
    Xin: "ZhengCai",
    Ren: "QiSha",
    Gui: "ZhengGuan"
  },

  Ding: {
    Jia: "ZhengYin",
    Yi: "PianYin",
    Bing: "JieCai",
    Ding: "BiJian",
    Wu: "ShangGuan",
    Ji: "ShiShen",
    Geng: "ZhengCai",
    Xin: "PianCai",
    Ren: "ZhengGuan",
    Gui: "QiSha"
  },

  Wu: {
    Jia: "QiSha",
    Yi: "ZhengGuan",
    Bing: "PianYin",
    Ding: "ZhengYin",
    Wu: "BiJian",
    Ji: "JieCai",
    Geng: "ShiShen",
    Xin: "ShangGuan",
    Ren: "PianCai",
    Gui: "ZhengCai"
  },

  Ji: {
    Jia: "ZhengGuan",
    Yi: "QiSha",
    Bing: "ZhengYin",
    Ding: "PianYin",
    Wu: "JieCai",
    Ji: "BiJian",
    Geng: "ShangGuan",
    Xin: "ShiShen",
    Ren: "ZhengCai",
    Gui: "PianCai"
  },

  Geng: {
    Jia: "PianCai",
    Yi: "ZhengCai",
    Bing: "QiSha",
    Ding: "ZhengGuan",
    Wu: "PianYin",
    Ji: "ZhengYin",
    Geng: "BiJian",
    Xin: "JieCai",
    Ren: "ShiShen",
    Gui: "ShangGuan"
  },

  Xin: {
    Jia: "ZhengCai",
    Yi: "PianCai",
    Bing: "ZhengGuan",
    Ding: "QiSha",
    Wu: "ZhengYin",
    Ji: "PianYin",
    Geng: "JieCai",
    Xin: "BiJian",
    Ren: "ShangGuan",
    Gui: "ShiShen"
  },

  Ren: {
    Jia: "ShiShen",
    Yi: "ShangGuan",
    Bing: "PianCai",
    Ding: "ZhengCai",
    Wu: "QiSha",
    Ji: "ZhengGuan",
    Geng: "PianYin",
    Xin: "ZhengYin",
    Ren: "BiJian",
    Gui: "JieCai"
  },

  Gui: {
    Jia: "ShangGuan",
    Yi: "ShiShen",
    Bing: "ZhengCai",
    Ding: "PianCai",
    Wu: "ZhengGuan",
    Ji: "QiSha",
    Geng: "ZhengYin",
    Xin: "PianYin",
    Ren: "JieCai",
    Gui: "BiJian"
  }

};


/* ============================================================
   19. RESOLVED HIDDEN STEM DATA
   ============================================================ */

BAZI_DATA.hiddenStemResolved = {};

Object.entries(BAZI_DATA.hiddenStems).forEach(
  ([branch, list]) => {

    BAZI_DATA.hiddenStemResolved[branch] =
      list.map(x => {

        const stem = x[0];
        const pos = x[1];
        const qi = x[2];
        const hanzi = x[3];

        return {
          stem,
          qiPosition: pos,
          qiEnglish: qi,
          qiHanzi: hanzi,
          element:
            BAZI_DATA.heavenlyStems[stem].element,
          polarity:
            BAZI_DATA.heavenlyStems[stem].polarity
        };

      });

  }
);


/* ============================================================
   20. DATA ACCESS HELPERS
   ============================================================ */

BAZI_DATA.getStem = stem =>
  BAZI_DATA.heavenlyStems[stem] || null;

BAZI_DATA.getBranch = branch =>
  BAZI_DATA.earthlyBranches[branch] || null;

BAZI_DATA.getHiddenStems = branch =>
  BAZI_DATA.hiddenStemResolved[branch] || [];

BAZI_DATA.getTenGod = (dayMaster, stem) =>
  BAZI_DATA.tenGodsMatrix[dayMaster]?.[stem] || null;

BAZI_DATA.getJiaZi = (stem, branch) =>
  BAZI_DATA.jiaZi.find(
    x => x.stem === stem && x.branch === branch
  ) || null;


/* ============================================================
   22. BRANCH & STEM INTERACTION TABLES (Section A12)
   ------------------------------------------------------------
   Ditambahkan untuk Core A. Registry shenSha/xun di atas hanya
   memuat metadata + satu contoh kelompok; tabel klasik lengkap
   (San He, Liu He, Chong, Xing, Hai, Po, Wu He) belum ada, jadi
   ditambahkan di sini mengikuti rujukan Zi Ping standar.
   ============================================================ */

// Tiga kelompok San He (segitiga) — juga dipakai untuk Yi Ma / Tao Hua / Hua Gai
BAZI_DATA.sanHeGroups = [
  { branches: ["Shen", "Zi", "Chen"], element: "Water", yiMa: "Yin", taoHua: "You", huaGai: "Chen" },
  { branches: ["Yin", "Wu", "Xu"], element: "Fire", yiMa: "Shen", taoHua: "Mao", huaGai: "Xu" },
  { branches: ["Si", "You", "Chou"], element: "Metal", yiMa: "Hai", taoHua: "Wu", huaGai: "Chou" },
  { branches: ["Hai", "Mao", "Wei"], element: "Wood", yiMa: "Si", taoHua: "Zi", huaGai: "Wei" }
];

// San Hui (kelompok arah musiman)
BAZI_DATA.sanHuiGroups = [
  { branches: ["Yin", "Mao", "Chen"], element: "Wood" },
  { branches: ["Si", "Wu", "Wei"], element: "Fire" },
  { branches: ["Shen", "You", "Xu"], element: "Metal" },
  { branches: ["Hai", "Zi", "Chou"], element: "Water" }
];

// Liu He (kombinasi enam) — pasangan
BAZI_DATA.liuHePairs = [
  { pair: ["Zi", "Chou"], element: "Earth" },
  { pair: ["Yin", "Hai"], element: "Wood" },
  { pair: ["Mao", "Xu"], element: "Fire" },
  { pair: ["Chen", "You"], element: "Metal" },
  { pair: ["Si", "Shen"], element: "Water" },
  { pair: ["Wu", "Wei"], element: "None (combines, no fixed transformation element)" }
];

// Chong (tabrakan) — 6 pasang berlawanan
BAZI_DATA.chongPairs = [
  ["Zi", "Wu"], ["Chou", "Wei"], ["Yin", "Shen"], ["Mao", "You"], ["Chen", "Xu"], ["Si", "Hai"]
];

// Hai (kerusakan/harm) — 6 pasang
BAZI_DATA.haiPairs = [
  ["Zi", "Wei"], ["Chou", "Wu"], ["Yin", "Si"], ["Mao", "Chen"], ["Shen", "Hai"], ["You", "Xu"]
];

// Po (destruction) — 6 pasang (catatan: Yin-Hai & Si-Shen juga tercatat di Liu He;
// ini variasi rujukan yang umum dijumpai, dicatat apa adanya)
BAZI_DATA.poPairs = [
  ["Zi", "You"], ["Wu", "Mao"], ["Chen", "Chou"], ["Xu", "Wei"], ["Yin", "Hai"], ["Si", "Shen"]
];

// Xing (hukuman) — 3 tipe
// Xing (hukuman) — 3 tipe co-occurrence (dua/tiga cabang berbeda harus
// hadir bersama) + 1 tipe repetition (satu cabang yang sama muncul ≥2x).
// `mode` dan `minMembers` eksplisit di sini (bukan ditebak dari nama key
// atau panjang array di interactionEngine.js) supaya mesin interaksi
// murni membaca aturan, tidak menyimpan aturannya sendiri.
BAZI_DATA.xingGroups = {
  shiShi: { branches: ["Yin", "Si", "Shen"], name: "Ambitious Punishment (\u6043\u52bf\u4e4b\u5211)", mode: "cooccurrence", minMembers: 2 },
  wuEn: { branches: ["Chou", "Xu", "Wei"], name: "Uncourteous Punishment (\u65e0\u6069\u4e4b\u5211)", mode: "cooccurrence", minMembers: 2 },
  wuLi: { branches: ["Zi", "Mao"], name: "Bullying Punishment (\u65e0\u793c\u4e4b\u5211)", mode: "cooccurrence", minMembers: 2 },
  ziXing: { branches: ["Chen", "Wu", "You", "Hai"], name: "Self-Punishment (\u81ea\u5211)", mode: "repetition", minMembers: 2 }
};

// Wu He (kombinasi lima Tian Gan) + target transformasi
BAZI_DATA.wuHePairs = [
  { pair: ["Jia", "Ji"], element: "Earth" },
  { pair: ["Yi", "Geng"], element: "Metal" },
  { pair: ["Bing", "Xin"], element: "Water" },
  { pair: ["Ding", "Ren"], element: "Wood" },
  { pair: ["Wu", "Gui"], element: "Fire" }
];

// Chong Tian Gan (tabrakan batang, versi yang umum dipakai — 4 pasang)
BAZI_DATA.stemChongPairs = [
  ["Jia", "Geng"], ["Yi", "Xin"], ["Bing", "Ren"], ["Ding", "Gui"]
];

// Tian Yi Gui Ren — tabel klasik lengkap per Day Master / Year Stem
// (甲戊庚牛羊, 乙己鼠猴乡, 丙丁猪鸡位, 壬癸兔蛇藏, 六辛逢马虎)
BAZI_DATA.tianYiGuiRenTable = {
  Jia: ["Chou", "Wei"], Wu: ["Chou", "Wei"], Geng: ["Chou", "Wei"],
  Yi: ["Zi", "Shen"], Ji: ["Zi", "Shen"],
  Bing: ["Hai", "You"], Ding: ["Hai", "You"],
  Ren: ["Mao", "Si"], Gui: ["Mao", "Si"],
  Xin: ["Wu", "Yin"]
};

/* ============================================================
   21. HANZI BRIDGE
   ------------------------------------------------------------
   Ditambahkan untuk Core A.
   Engine astronomi (engine/lunar.js — pustaka lunar-javascript)
   mengeluarkan Gan/Zhi dalam aksara Hanzi (甲, 乙, 子, 丑, dst),
   sedangkan seluruh registry di atas menggunakan kunci Pinyin
   (Jia, Yi, Zi, Chou, dst). Jembatan ini menyambungkan jalur
   antara kedua sisi tanpa mengubah struktur registry yang sudah
   ada.
   ============================================================ */

const HANZI_TO_STEM_KEY = {
  "甲": "Jia", "乙": "Yi", "丙": "Bing", "丁": "Ding", "戊": "Wu",
  "己": "Ji", "庚": "Geng", "辛": "Xin", "壬": "Ren", "癸": "Gui"
};

const HANZI_TO_BRANCH_KEY = {
  "子": "Zi", "丑": "Chou", "寅": "Yin", "卯": "Mao", "辰": "Chen",
  "巳": "Si", "午": "Wu", "未": "Wei", "申": "Shen", "酉": "You",
  "戌": "Xu", "亥": "Hai"
};

BAZI_DATA.hanziToStemKey = hanzi =>
  HANZI_TO_STEM_KEY[hanzi] || null;

BAZI_DATA.hanziToBranchKey = hanzi =>
  HANZI_TO_BRANCH_KEY[hanzi] || null;

BAZI_DATA.getStemByHanzi = hanzi =>
  BAZI_DATA.getStem(HANZI_TO_STEM_KEY[hanzi]);

BAZI_DATA.getBranchByHanzi = hanzi =>
  BAZI_DATA.getBranch(HANZI_TO_BRANCH_KEY[hanzi]);

BAZI_DATA.getHiddenStemsByHanzi = hanzi =>
  BAZI_DATA.getHiddenStems(HANZI_TO_BRANCH_KEY[hanzi]);

BAZI_DATA.getTenGodByHanzi = (dayMasterHanzi, stemHanzi) =>
  BAZI_DATA.getTenGod(
    HANZI_TO_STEM_KEY[dayMasterHanzi],
    HANZI_TO_STEM_KEY[stemHanzi]
  );


/* ============================================================
   EXPORT
   ============================================================ */

if (typeof window !== "undefined") {
  window.BAZI_DATA = BAZI_DATA;
  window.CLASSICAL_RULE_REGISTRY = CLASSICAL_RULE_REGISTRY;
  window.AC_RULE_AUDIT_MATRIX = AC_RULE_AUDIT_MATRIX;
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = BAZI_DATA;
  module.exports.CLASSICAL_RULE_REGISTRY = CLASSICAL_RULE_REGISTRY;
  module.exports.AC_RULE_AUDIT_MATRIX = AC_RULE_AUDIT_MATRIX;
}