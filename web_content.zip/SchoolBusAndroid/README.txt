School Bus Driver Android project.
Open this folder in Android Studio and Build > Build APK(s).
The generated APK will be in app/build/outputs/apk/debug/.
