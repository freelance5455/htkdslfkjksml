package com.registro.cigarrillos;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private static final int CREATE_FILE = 4101;
    private static final int OPEN_FILE = 4102;
    private static final String START_URL = "file:///android_asset/www/index.html";
    private static final int MAX_BASE64_CHARS = 28 * 1024 * 1024; // ~20 MB de datos

    private WebView webView;
    private String pendingBase64;
    private ValueCallback<Uri[]> filePathCallback;

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(16, 24, 32));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(16, 24, 32));

        webView = new WebView(this);
        webView.setBackgroundColor(android.graphics.Color.rgb(16, 24, 32));

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        // Los recursos de file:///android_asset siguen funcionando con el acceso a archivos desactivado.
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setGeolocationEnabled(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSupportZoom(false);

        webView.addJavascriptInterface(new NativeBridge(), "Android");

        // La interfaz "Android" solo debe ser accesible desde la página local:
        // se bloquea cualquier navegación a otras direcciones.
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !request.getUrl().toString().startsWith("file:///android_asset/");
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                // "*/*": algunos proveedores de archivos marcan los .json como octet-stream
                // y no aparecerían con un filtro estricto. La app valida el contenido.
                intent.setType("*/*");
                try {
                    startActivityForResult(intent, OPEN_FILE);
                } catch (Exception e) {
                    filePathCallback = null;
                    callback.onReceiveValue(null);
                    Toast.makeText(MainActivity.this, "No se pudo abrir el selector de archivos", Toast.LENGTH_LONG).show();
                }
                return true;
            }
        });

        setContentView(webView);
        webView.loadUrl(START_URL);
    }

    private class NativeBridge {
        @JavascriptInterface
        public void saveFile(String name, String mime, String base64) {
            if (base64 == null || base64.length() > MAX_BASE64_CHARS) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "El archivo es demasiado grande", Toast.LENGTH_LONG).show());
                return;
            }
            runOnUiThread(() -> {
                pendingBase64 = base64;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                // Se quita ";charset=utf-8": un tipo MIME con parámetros no es válido para ACTION_CREATE_DOCUMENT.
                String cleanMime = mime == null ? "" : mime.split(";")[0].trim();
                intent.setType(cleanMime.isEmpty() ? "application/octet-stream" : cleanMime);
                intent.putExtra(Intent.EXTRA_TITLE, name == null || name.isEmpty() ? "copia-registro" : name);
                try {
                    startActivityForResult(intent, CREATE_FILE);
                } catch (Exception e) {
                    pendingBase64 = null;
                    Toast.makeText(MainActivity.this, "No se pudo abrir el selector de archivos", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void printPage() {
            runOnUiThread(() -> {
                PrintManager manager = (PrintManager) getSystemService(PRINT_SERVICE);
                if (manager != null) {
                    manager.print("Registro de Cigarrillos",
                            webView.createPrintDocumentAdapter("Registro de Cigarrillos"),
                            new PrintAttributes.Builder().build());
                }
            });
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CREATE_FILE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingBase64 != null) {
                // "wt" trunca el archivo: sin esto, al sobrescribir un archivo más largo
                // pueden quedar bytes viejos al final y la copia JSON queda corrupta.
                try (OutputStream out = getContentResolver().openOutputStream(data.getData(), "wt")) {
                    if (out == null) throw new IllegalStateException("Sin flujo de salida");
                    out.write(Base64.decode(pendingBase64, Base64.DEFAULT));
                    Toast.makeText(this, "Copia guardada correctamente", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(this, "No se pudo guardar el archivo", Toast.LENGTH_LONG).show();
                }
            }
            pendingBase64 = null;
        } else if (requestCode == OPEN_FILE) {
            if (filePathCallback != null) {
                Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
                filePathCallback.onReceiveValue(result);
                filePathCallback = null;
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (webView != null) webView.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
    }

    @Override
    protected void onDestroy() {
        if (filePathCallback != null) {
            filePathCallback.onReceiveValue(null);
            filePathCallback = null;
        }
        if (webView != null) {
            webView.removeJavascriptInterface("Android");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (webView == null) {
            super.onBackPressed();
            return;
        }
        // Si hay un diálogo abierto, el botón Atrás lo cierra en vez de salir de la app.
        webView.evaluateJavascript(
                "(function(){var d=document.querySelector('dialog[open]');if(d){d.close();return 'closed';}return 'none';})()",
                value -> {
                    if (value == null || !value.contains("closed")) MainActivity.super.onBackPressed();
                });
    }
}
