'use strict';
/* Registro de Cigarrillos 2.5 */
const $ = id => document.getElementById(id);
const KEY = 'registro-cigarrillos-v2'; // misma clave: conserva los datos de versiones anteriores
const DAY_RE = /^\d{4}-\d{2}-\d{2}$/;
const pad = n => String(n).padStart(2, '0');

/* ---------- Fechas (todo en hora local, formato YYYY-MM-DDTHH:mm) ---------- */
function keyDate(d = new Date()) { return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; }
function localInput(d = new Date()) { return `${keyDate(d)}T${pad(d.getHours())}:${pad(d.getMinutes())}`; }
function parseLocal(s) {
  const [date, time = '00:00'] = String(s).split('T');
  const [y, m, d] = date.split('-').map(Number);
  const [h, mi] = time.split(':').map(Number);
  return new Date(y, m - 1, d, h || 0, mi || 0);
}
/* Acepta fechas locales, ISO con Z/offset o solo día; devuelve formato local o null. */
function normDate(s) {
  if (typeof s !== 'string') return null;
  if (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(:\d{2}(\.\d+)?)?$/.test(s)) return s.slice(0, 16);
  if (DAY_RE.test(s)) return s + 'T00:00';
  const t = Date.parse(s);
  return Number.isFinite(t) ? localInput(new Date(t)) : null;
}
const ts = r => parseLocal(r.date).getTime();
function fmtTime(s) { const d = parseLocal(s); return `${pad(d.getHours())}:${pad(d.getMinutes())}`; }
function fmtDate(s) { const d = parseLocal(s); return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()}`; }
function fmtGap(ms) {
  if (ms == null || !Number.isFinite(ms) || ms < 0) return '—';
  const m = Math.round(ms / 60000);
  return m < 60 ? `${m} min` : `${Math.floor(m / 60)} h ${m % 60} min`;
}

/* ---------- Estado y validación ---------- */
const txt = (v, max) => String(v ?? '').trim().slice(0, max);
const lvl = v => { const n = Math.round(Number(v)); return Number.isFinite(n) ? Math.min(10, Math.max(0, n)) : 0; };
function newId() {
  try { if (crypto.randomUUID) return crypto.randomUUID(); } catch { /* sigue */ }
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
}
const isHttps = s => /^https:\/\//i.test(s);

/* ---------- Desencadenantes: UNA sola lista, sin repetidos ----------
   Se usa en el registro, en Antojos y en el filtro del historial.
   Orden de importancia: 'Principales' y 'Más importantes' van siempre primero.
   Los 9 primeros conservan exactamente el nombre de versiones anteriores. */
const trigKey = s => String(s ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();
const TRIGGER_GROUPS_RAW = [
  ['Principales', ['Ansiedad', 'Estrés', 'Aburrimiento', 'Tristeza', 'Mate', 'Después de comer', 'Costumbre', 'Social', 'Otro']],
  ['Más importantes', ['Nervios', 'Tiempo libre', 'Al despertarse', 'Después de una siesta', 'Mientras escribís', 'Mientras lees', 'Mientras jugás', 'Al caminar', 'Salir de casa', 'Esperar respuestas o acontecimientos', 'Preocupación', 'Necesidad de tranquilidad', 'Necesidad de alivio emocional']],
  ['Emociones y estado de ánimo', ['Angustia', 'Enojo', 'Frustración', 'Irritabilidad', 'Vacío', 'Soledad', 'Sentirse solo', 'Sentirse incomprendido', 'Miedo', 'Incertidumbre', 'Sobrepasado emocionalmente', 'Vulnerabilidad emocional', 'Una situación difícil', 'Discusiones']],
  ['Cuerpo y necesidad', ['Necesidad', 'Abstinencia', 'Mucho tiempo sin fumar', 'Cansancio', 'Agotamiento', 'Inquietud', 'Dificultad para relajarse', 'Tensión física']],
  ['Momentos y rutinas', ['Café', 'Alguna bebida', 'Antes de acostarse', 'Durante descansos', 'Después de alguna actividad', 'Determinados horarios del día', 'Esperar', 'Demasiado tiempo libre', 'Asociado a descanso']],
  ['Entorno y situaciones', ['Ver a alguien fumar', 'Lugares', 'Cigarrillos a mano', 'Estar en la calle']],
  ['Motivos y recompensas', ['Para concentrarte', 'Para disfrutar un momento', 'Recompensa']]
];
/* Protección: si alguna vez se agrega un nombre repetido (ignorando mayúsculas y tildes), se descarta. */
const TRIGGER_GROUPS = (() => {
  const seen = new Set();
  return TRIGGER_GROUPS_RAW.map(([label, items]) => [label, items.filter(t => { const k = trigKey(t); if (seen.has(k)) return false; seen.add(k); return true; })]);
})();
const TRIGGER_CANON = new Map(TRIGGER_GROUPS.flatMap(g => g[1]).map(t => [trigKey(t), t]));
/* Nombres combinados de la versión 2.4 (ya separados): sus registros pasan al desencadenante principal. */
const TRIGGER_LEGACY = { 'ansiedad y nervios': 'Ansiedad', 'aburrimiento y tiempo libre': 'Aburrimiento', 'soledad / sentirse solo': 'Soledad', 'esperar demasiado tiempo libre': 'Demasiado tiempo libre' };
const CUSTOM_TRIGGERS = new Map(); // nombres propios (de copias importadas): una sola grafía por nombre
function canonTrigger(t) {
  const k = trigKey(t);
  if (!k) return 'Otro';
  if (TRIGGER_CANON.has(k)) return TRIGGER_CANON.get(k);
  if (TRIGGER_LEGACY[k]) return TRIGGER_LEGACY[k];
  if (!CUSTOM_TRIGGERS.has(k)) CUSTOM_TRIGGERS.set(k, txt(t, 60).replace(/\s+/g, ' '));
  return CUSTOM_TRIGGERS.get(k);
}

function sanitizeState(x) {
  x = x && typeof x === 'object' ? x : {};
  const seen = new Set();
  const records = (Array.isArray(x.records) ? x.records : []).map(r => {
    if (!r || typeof r !== 'object') return null;
    const date = normDate(r.date);
    if (!date) return null;
    let id = txt(r.id, 80);
    if (!id || seen.has(id)) id = newId();
    seen.add(id);
    return { id, date, trigger: canonTrigger(r.trigger), anxiety: lvl(r.anxiety), urge: lvl(r.urge), activity: txt(r.activity, 200), note: txt(r.note, 1000) };
  }).filter(Boolean);
  const cravings = (Array.isArray(x.cravings) ? x.cravings : []).map(c => {
    if (!c || typeof c !== 'object') return null;
    const date = normDate(c.date);
    return date ? { date, intensity: lvl(c.intensity), trigger: canonTrigger(c.trigger), strategy: txt(c.strategy, 400) } : null;
  }).filter(Boolean);
  const daily = {};
  if (x.daily && typeof x.daily === 'object') {
    for (const [d, q] of Object.entries(x.daily)) {
      if (!DAY_RE.test(d) || !q || typeof q !== 'object') continue;
      daily[d] = { anxiety: lvl(q.anxiety), hard: txt(q.hard, 300), help: txt(q.help, 600), delay: txt(q.delay, 30), feel: txt(q.feel, 30), tomorrow: txt(q.tomorrow, 600), updated: txt(q.updated, 40) };
    }
  }
  const goal = Number.isInteger(x.goal) && x.goal >= 1 && x.goal <= 100 ? x.goal : 17;
  const ep = txt(x.aiEndpoint, 300);
  return { records, cravings, daily, goal, aiEndpoint: isHttps(ep) ? ep : '', aiToken: txt(x.aiToken, 200) };
}
function load() {
  let raw = null;
  try {
    raw = localStorage.getItem(KEY);
    return sanitizeState(raw ? JSON.parse(raw) : null);
  } catch {
    // Datos ilegibles: se guarda una copia cruda antes de que se sobrescriban.
    try { if (raw) localStorage.setItem(KEY + '-corrupto', raw); } catch { /* sin espacio */ }
    return sanitizeState(null);
  }
}
let state = load();
function save() {
  try { localStorage.setItem(KEY, JSON.stringify(state)); }
  catch { alert('No se pudieron guardar los datos. Exportá una copia y revisá el espacio disponible.'); }
  render();
}


/* ---------- Utilidades de datos ---------- */
function esc(s) { return String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
function recordsSorted() { return [...state.records].sort((a, b) => ts(a) - ts(b)); }
function dayRecords(day) { return recordsSorted().filter(r => r.date.slice(0, 10) === day); }
/* Intervalos entre cigarrillos del MISMO día (la noche no cuenta como intervalo). */
function gaps(rs) {
  const out = [];
  for (let i = 1; i < rs.length; i++) {
    if (rs[i].date.slice(0, 10) !== rs[i - 1].date.slice(0, 10)) continue;
    const g = ts(rs[i]) - ts(rs[i - 1]);
    if (g >= 0) out.push(g);
  }
  return out;
}
function avg(a) { return a.length ? a.reduce((x, y) => x + y, 0) / a.length : null; }
function topOf(obj, n = 1) { return Object.entries(obj).sort((x, y) => y[1] - x[1]).slice(0, n); }
function rangeFor(period) {
  const now = new Date();
  if (period === 'day') return [keyDate(), keyDate(), 'Hoy'];
  if (period === 'week') { const s = new Date(now); s.setDate(now.getDate() - 6); return [keyDate(s), keyDate(now), 'Últimos 7 días']; }
  return [`${now.getFullYear()}-${pad(now.getMonth() + 1)}-01`, keyDate(now), 'Este mes'];
}
function inRange(r, a, b) { const d = r.date.slice(0, 10); return d >= a && d <= b; }
function daysBetween(a, b) { return Math.max(1, Math.round((parseLocal(b) - parseLocal(a)) / 86400000) + 1); }

/* ---------- Selectores de desencadenantes ---------- */
/* all: agrega "Todos" (filtro). Conserva la selección actual. Ningún desencadenante aparece dos veces. */
function fillTriggerSelect(sel, { all = false } = {}) {
  const prev = sel.value;
  sel.innerHTML = '';
  const opt = (parent, value, label) => { const o = document.createElement('option'); o.value = value; o.textContent = label; parent.appendChild(o); };
  const group = (label, items) => { const g = document.createElement('optgroup'); g.label = label; items.forEach(t => opt(g, t, t)); sel.appendChild(g); };
  if (all) opt(sel, '', 'Todos');
  TRIGGER_GROUPS.forEach(([label, items]) => group(label, items));
  /* Nombres personalizados que vengan de copias importadas (sin repetir) */
  const extra = new Map();
  state.records.forEach(r => { const k = trigKey(r.trigger); if (!TRIGGER_CANON.has(k) && !extra.has(k)) extra.set(k, r.trigger); });
  if (extra.size) group('Otros guardados', [...extra.values()].sort());
  if (prev && [...sel.options].some(o => o.value === prev)) sel.value = prev;
}

/* ---------- Render ---------- */
let renderedDay = keyDate();
function recordCard(r, withDate) {
  return `<div class="card record"><div><b>${withDate ? fmtDate(r.date) + ' · ' : ''}${fmtTime(r.date)}</b> <span class="pill">${esc(r.trigger)}</span><p>Ansiedad ${r.anxiety}/10 · Ganas ${r.urge}/10${r.activity ? ' · ' + esc(r.activity) : ''}</p>${r.note ? `<p>${esc(r.note)}</p>` : ''}</div><button class="danger" data-delete="${esc(r.id)}" aria-label="Eliminar registro">✕</button></div>`;
}
function updateLive() {
  if (keyDate() !== renderedDay) { render(); return; }
  const today = dayRecords(keyDate());
  const last = today[today.length - 1];
  $('sinceLast').textContent = last ? fmtGap(Date.now() - ts(last)) : '—';
}
function render() {
  renderedDay = keyDate();
  const today = dayRecords(renderedDay), sorted = recordsSorted();
  $('todayCount').textContent = today.length;
  $('goalValue').textContent = state.goal;
  $('goalInput').value = state.goal;
  $('aiEndpoint').value = state.aiEndpoint || '';
  $('aiToken').value = state.aiToken || '';
  const over = today.length - state.goal;
  $('goalText').textContent = `${today.length} de ${state.goal}` + (over > 0 ? ` (+${over})` : '');
  $('goalText').className = over > 0 ? 'warn' : 'good';
  $('goalBar').style.width = Math.min(100, Math.round(today.length / state.goal * 100)) + '%';
  $('goalBar').className = over > 0 ? 'over' : '';
  updateLive();
  $('avgGap').textContent = fmtGap(avg(gaps(today)));
  $('todayList').innerHTML = today.length ? today.slice().reverse().map(r => recordCard(r, false)).join('') : '<div class="empty">Todavía no registraste cigarrillos hoy.</div>';
  $('historyTotal').textContent = `${sorted.length} cigarrillos registrados en total`;
  fillTriggerSelect($('filterTrigger'), { all: true });
  const fd = $('filterDate').value, ft = $('filterTrigger').value;
  const filtered = sorted.filter(r => (!fd || r.date.slice(0, 10) === fd) && (!ft || r.trigger === ft));
  $('historyList').innerHTML = filtered.length ? filtered.slice().reverse().map(r => recordCard(r, true)).join('') : '<div class="empty">No hay registros para esos filtros.</div>';
  $('dailyStatus').textContent = state.daily[renderedDay] ? 'Preguntas de hoy completadas ✓' : 'Todavía no respondiste las preguntas de hoy.';
  renderReport();
}
function active(tab) {
  document.querySelectorAll('main section').forEach(s => s.classList.toggle('hidden', s.id !== tab));
  document.querySelectorAll('.tabs button').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
  $('heading').textContent = ({ today: 'Tu día, bajo control', history: 'Historial de consumo', reports: 'Análisis y evolución', tools: 'Manejar las ganas', settings: 'Configuración', ai: 'Centro de inteligencia' })[tab];
  window.scrollTo(0, 0);
}
document.querySelectorAll('[data-tab]').forEach(b => b.onclick = () => active(b.dataset.tab));

/* ---------- Registro de cigarrillos ---------- */
$('add').onclick = () => { fillTriggerSelect($('trigger')); $('entryDate').value = localInput(); $('entry').showModal(); };
$('cancelEntry').onclick = () => $('entry').close();
['anxiety', 'urge'].forEach(id => $(id).oninput = () => $(id + 'Val').textContent = $(id).value);
$('entryForm').onsubmit = e => {
  e.preventDefault();
  const date = normDate($('entryDate').value);
  if (!date) { alert('Revisá la fecha y hora.'); return; }
  state.records.push({ id: newId(), date, trigger: $('trigger').value, anxiety: +$('anxiety').value, urge: +$('urge').value, activity: $('activity').value.trim(), note: $('note').value.trim() });
  $('entry').close(); $('activity').value = ''; $('note').value = '';
  save();
};
document.addEventListener('click', e => {
  const btn = e.target instanceof Element ? e.target.closest('[data-delete]') : null;
  if (!btn) return;
  const id = btn.dataset.delete;
  if (id && confirm('¿Eliminar este registro? Esta acción no se puede deshacer.')) {
    state.records = state.records.filter(r => String(r.id) !== id);
    save();
  }
});
$('filterDate').onchange = render;
$('filterTrigger').onchange = render;

/* ---------- Cuestionario diario ---------- */
$('qAnxiety').oninput = () => $('qAnxietyVal').textContent = $('qAnxiety').value;
function openQuestions() {
  const q = state.daily[keyDate()] || {};
  for (const [id, k] of [['qAnxiety', 'anxiety'], ['qHard', 'hard'], ['qHelp', 'help'], ['qDelay', 'delay'], ['qFeel', 'feel'], ['qTomorrow', 'tomorrow']]) $(id).value = q[k] ?? (id === 'qAnxiety' ? 5 : '');
  $('qAnxietyVal').textContent = $('qAnxiety').value;
  $('questions').showModal();
}
$('questionnaire').onclick = openQuestions;
$('openQuestionnaire').onclick = openQuestions;
$('cancelQuestions').onclick = () => $('questions').close();
$('questionForm').onsubmit = e => {
  e.preventDefault();
  state.daily[keyDate()] = { anxiety: +$('qAnxiety').value, hard: $('qHard').value.trim(), help: $('qHelp').value.trim(), delay: $('qDelay').value, feel: $('qFeel').value, tomorrow: $('qTomorrow').value.trim(), updated: new Date().toISOString() };
  $('questions').close();
  save();
};

/* ---------- Antojos ---------- */
const tips = [
  'Respirá suave: inhalá durante 4 segundos y exhalá durante 6. Repetilo sin forzar durante un minuto.',
  'Cambiá de contexto: levantate, andá a otra habitación y tomá un vaso de agua.',
  'Ocupá las manos durante cinco minutos: ordená algo pequeño, dibujá o sostené una pelota.',
  'Si estás con mate, cambiá de lugar o pausá el mate unos minutos para romper la asociación automática.',
  'Nombrá cinco cosas que ves, cuatro que sentís con el tacto y tres que escuchás. Volvé al presente.',
  'Mandale un mensaje a alguien de confianza y contale que estás atravesando un impulso.'
];
let tipIndex = 0;
$('craving').onclick = () => active('tools');
$('craveIntensity').oninput = () => $('craveVal').textContent = $('craveIntensity').value;
$('nextTip').onclick = () => { $('strategy').textContent = tips[tipIndex++ % tips.length]; };

/* El temporizador usa la hora de fin (no un setTimeout) para que siga siendo exacto si la pantalla se apaga. */
const DELAY_MS = 300000;
let delayEnd = 0, delayTick = null;
function tickDelay() {
  if (!delayEnd) return;
  const left = delayEnd - Date.now(), btn = $('startDelay');
  if (left <= 0) {
    clearInterval(delayTick); delayTick = null; delayEnd = 0;
    $('delayResult').textContent = 'Pasaron cinco minutos. ¿Cómo está ahora el impulso? Podés volver a medirlo o guardar lo que pasó.';
    btn.textContent = 'Probar otros 5 minutos';
    return;
  }
  const s = Math.ceil(left / 1000);
  btn.textContent = `Quedan ${Math.floor(s / 60)}:${pad(s % 60)}`;
}
$('startDelay').onclick = () => {
  if (delayTick) clearInterval(delayTick);
  delayEnd = Date.now() + DELAY_MS;
  $('delayResult').textContent = 'Durante cinco minutos: alejá los cigarrillos, elegí una estrategia y observá cómo cambia el impulso. No hace falta que desaparezca por completo.';
  tickDelay();
  delayTick = setInterval(tickDelay, 1000);
};
$('saveCraving').onclick = () => {
  state.cravings.push({ date: localInput(), intensity: +$('craveIntensity').value, trigger: $('craveTrigger').value, strategy: $('strategy').textContent });
  save();
  alert('Impulso guardado en tu historial.');
};

/* ---------- Ajustes ---------- */
$('saveGoal').onclick = () => {
  const n = Number($('goalInput').value);
  if (!Number.isInteger(n) || n < 1 || n > 100) { alert('Ingresá una meta entre 1 y 100.'); return; }
  state.goal = n; save(); alert('Objetivo actualizado.');
};

/* ---------- Informes ---------- */
function renderReport() {
  const [a, b, label] = rangeFor($('period').value);
  const rs = recordsSorted().filter(r => inRange(r, a, b));
  const days = daysBetween(a, b);
  const triggerCounts = {}, hourCounts = {}, perDay = {};
  rs.forEach(r => {
    triggerCounts[r.trigger] = (triggerCounts[r.trigger] || 0) + 1;
    const h = pad(parseLocal(r.date).getHours());
    hourCounts[h] = (hourCounts[h] || 0) + 1;
    const d = r.date.slice(0, 10);
    perDay[d] = (perDay[d] || 0) + 1;
  });
  const tr = topOf(triggerCounts)[0], hr = topOf(hourCounts)[0];
  const meanAnx = avg(rs.map(r => r.anxiety)), meanUrge = avg(rs.map(r => r.urge));
  const qEntries = Object.entries(state.daily).filter(([d]) => d >= a && d <= b).map(x => x[1]);
  const qAnx = avg(qEntries.map(q => q.anxiety).filter(Number.isFinite));
  let bars = '';
  if (days > 1) {
    const max = Math.max(state.goal, ...Object.values(perDay));
    const d = parseLocal(a);
    for (let i = 0; i < days; i++, d.setDate(d.getDate() + 1)) {
      const k = keyDate(d), n = perDay[k] || 0;
      bars += `<div class="dayrow"><span>${pad(d.getDate())}/${pad(d.getMonth() + 1)}</span><div class="bar"><span class="${n > state.goal ? 'over' : ''}" style="width:${Math.round(n / max * 100)}%"></span></div><b>${n}</b></div>`;
    }
    bars = `<div class="section-title">CIGARRILLOS POR DÍA (meta ${state.goal})</div>${bars}`;
  }
  $('reportContent').innerHTML = `<h2>${label}</h2><div class="stats"><div class="card stat"><small>TOTAL</small><strong>${rs.length}</strong><span class="muted small">cigarrillos</span></div><div class="card stat"><small>PROMEDIO / DÍA</small><strong>${(rs.length / days).toFixed(1)}</strong><span class="muted small">registros por día</span></div><div class="card stat"><small>INTERVALO MEDIO</small><strong>${fmtGap(avg(gaps(rs)))}</strong><span class="muted small">entre registros del mismo día</span></div><div class="card stat"><small>ANSIEDAD MEDIA</small><strong>${meanAnx === null ? '—' : meanAnx.toFixed(1) + '/10'}</strong><span class="muted small">al registrar</span></div></div>${bars}<div class="metric"><span>Ganas medias de fumar</span><b>${meanUrge === null ? '—' : meanUrge.toFixed(1) + '/10'}</b></div><div class="metric"><span>Desencadenante principal</span><b>${tr ? `${esc(tr[0])} (${tr[1]})` : 'Sin datos'}</b></div><div class="metric"><span>Hora más frecuente</span><b>${hr ? `${hr[0]}:00 (${hr[1]})` : 'Sin datos'}</b></div><div class="metric"><span>Cuestionarios completados</span><b>${qEntries.length}</b></div><div class="metric"><span>Ansiedad en cuestionarios</span><b>${qAnx === null ? '—' : qAnx.toFixed(1) + '/10'}</b></div><p class="hint">${rs.length ? 'Estos resultados describen tus registros guardados. Si faltan cigarrillos o días, las cifras pueden subestimar el consumo real.' : 'Todavía no hay registros en este período.'}</p>`;
}
$('period').onchange = renderReport;

function reportText() {
  const [a, b, label] = rangeFor($('period').value);
  const rs = recordsSorted().filter(r => inRange(r, a, b));
  const qs = Object.entries(state.daily).filter(([d]) => d >= a && d <= b);
  const cs = state.cravings.filter(c => c.date.slice(0, 10) >= a && c.date.slice(0, 10) <= b);
  return `Analizá mi registro de cigarrillos del período ${label} (${a} a ${b}). Hacé un análisis psicológico-conductual cuidadoso, sin diagnosticar ni juzgar. Revisá cantidad, horarios, intervalos, desencadenantes, ansiedad, ganas, actividades, respuestas al impulso, logros, dificultades y propuestas concretas para mañana/próxima semana. Señalá límites si faltan datos.\n\nREGISTROS:\n${rs.map(r => `${r.date.replace('T', ' ')} | ${r.trigger} | ansiedad ${r.anxiety}/10 | ganas ${r.urge}/10 | actividad: ${r.activity} | nota: ${r.note}`).join('\n') || 'Sin registros'}\n\nPREGUNTAS DIARIAS:\n${qs.map(([d, q]) => `${d}: ansiedad ${q.anxiety}/10; momento difícil: ${q.hard}; ayudó: ${q.help}; retrasó/evitó: ${q.delay}; cómo se sintió: ${q.feel}; mañana: ${q.tomorrow}`).join('\n') || 'Sin cuestionarios'}\n\nIMPULSOS REGISTRADOS:\n${cs.map(c => `${c.date.replace('T', ' ')}: intensidad ${c.intensity}/10; desencadenante ${c.trigger}; estrategia ${c.strategy}`).join('\n') || 'Sin impulsos registrados'}`;
}
$('makeAnalysis').onclick = () => download(`analisis-cigarrillos-${$('period').value}.txt`, reportText(), 'text/plain;charset=utf-8');

/* ---------- Exportar / importar ---------- */
function download(name, data, type) {
  if (window.Android && typeof Android.saveFile === 'function') {
    const bytes = new TextEncoder().encode(data);
    let binary = '';
    for (let i = 0; i < bytes.length; i += 0x8000) binary += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    Android.saveFile(name, type, btoa(binary));
    return;
  }
  const blob = new Blob([data], { type }), url = URL.createObjectURL(blob), a = document.createElement('a');
  a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
$('export').onclick = () => {
  const copy = { ...state, aiToken: '' }; // el token de acceso no se incluye en las copias
  download('registro-cigarrillos-copia.json', JSON.stringify(copy, null, 2), 'application/json');
};
/* Protege contra inyección de fórmulas al abrir el CSV en Excel/Sheets. */
const csvCell = v => { let s = String(v ?? ''); if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; return '"' + s.replace(/"/g, '""') + '"'; };
$('csv').onclick = () => {
  const rows = [['fecha_hora', 'desencadenante', 'ansiedad', 'ganas', 'actividad', 'nota'], ...recordsSorted().map(r => [r.date, r.trigger, r.anxiety, r.urge, r.activity, r.note])];
  download('registros-cigarrillos.csv', '\ufeff' + rows.map(row => row.map(csvCell).join(';')).join('\r\n'), 'text/csv;charset=utf-8');
};
$('importFile').onchange = async e => {
  try {
    const f = e.target.files[0];
    if (!f) return;
    if (f.size > 20 * 1024 * 1024) throw Error('Tamaño');
    const obj = JSON.parse(await f.text());
    if (!obj || !Array.isArray(obj.records)) throw Error('Formato');
    const clean = sanitizeState(obj);
    const skipped = obj.records.length - clean.records.length;
    const msg = `La copia tiene ${clean.records.length} registros${skipped ? ` (${skipped} descartados por datos inválidos)` : ''}.\n\nLa restauración REEMPLAZARÁ los datos actuales (${state.records.length} registros). ¿Continuar?`;
    if (!confirm(msg)) return;
    // Se conservan la dirección y el token de IA actuales: una copia ajena no debe poder redirigir tus datos.
    state = { ...clean, aiEndpoint: state.aiEndpoint, aiToken: state.aiToken };
    save();
    alert('Copia restaurada correctamente.');
  } catch {
    alert('El archivo no es una copia válida de Registro de Cigarrillos.');
  } finally {
    e.target.value = '';
  }
};

/* Imprimir: el informe está en la pestaña "Informes", no en Ajustes (desde donde se pulsa el botón). */
let tabBeforePrint = null;
$('pdf').onclick = () => {
  tabBeforePrint = (document.querySelector('.tabs button.active') || {}).dataset?.tab || 'today';
  active('reports');
  setTimeout(() => {
    if (window.Android && typeof Android.printPage === 'function') { tabBeforePrint = null; Android.printPage(); }
    else window.print();
  }, 250);
};
window.addEventListener('afterprint', () => { if (tabBeforePrint) { active(tabBeforePrint); tabBeforePrint = null; } });

/* ---------- Centro de IA: análisis local + servidor opcional ---------- */
function selectedRangeSummary(period = 'week') {
  const [a, b, label] = rangeFor(period), rs = recordsSorted().filter(r => inRange(r, a, b));
  const days = daysBetween(a, b), triggers = {}, hours = {}, dailyCounts = {};
  rs.forEach(r => {
    triggers[r.trigger] = (triggers[r.trigger] || 0) + 1;
    const h = pad(parseLocal(r.date).getHours());
    hours[h] = (hours[h] || 0) + 1;
    const d = r.date.slice(0, 10);
    dailyCounts[d] = (dailyCounts[d] || 0) + 1;
  });
  const top = o => topOf(o, 5).map(([name, count]) => ({ name, count }));
  const qs = Object.entries(state.daily).filter(([d]) => d >= a && d <= b).map(x => x[1]);
  const impulses = state.cravings.filter(c => c.date.slice(0, 10) >= a && c.date.slice(0, 10) <= b);
  return {
    period: label, from: a, to: b, total: rs.length, calendarDays: days,
    averagePerDay: Number((rs.length / days).toFixed(2)), dailyCounts,
    averageAnxiety: avg(rs.map(r => r.anxiety)), averageUrge: avg(rs.map(r => r.urge)),
    averageIntervalMinutes: avg(gaps(rs).map(x => x / 60000)),
    topTriggers: top(triggers), topHours: top(hours),
    questionnaires: qs.length, questionnaireAverageAnxiety: avg(qs.map(q => q.anxiety).filter(Number.isFinite)),
    cravings: impulses.length, averageCravingIntensity: avg(impulses.map(c => c.intensity)),
    dailyGoal: state.goal
  };
}
function localInsights(period = 'week') {
  const d = selectedRangeSummary(period), lines = [];
  lines.push(`Período: ${d.period} (${d.from} a ${d.to}).`);
  lines.push(`Registros: ${d.total} cigarrillos en ${d.calendarDays} días; promedio ${d.averagePerDay} por día. Objetivo actual: ${d.dailyGoal}/día.`);
  if (d.averageAnxiety !== null) lines.push(`Ansiedad media al registrar: ${d.averageAnxiety.toFixed(1)}/10.`);
  if (d.averageUrge !== null) lines.push(`Ganas medias de fumar: ${d.averageUrge.toFixed(1)}/10.`);
  if (d.averageIntervalMinutes !== null) lines.push(`Intervalo medio entre registros: ${fmtGap(d.averageIntervalMinutes * 60000)}.`);
  if (d.topTriggers.length) lines.push(`Desencadenantes más frecuentes: ${d.topTriggers.map(x => `${x.name} (${x.count})`).join(', ')}.`);
  if (d.topHours.length) lines.push(`Franjas horarias más frecuentes: ${d.topHours.map(x => `${x.name}:00 (${x.count})`).join(', ')}.`);
  lines.push(`Cuestionarios: ${d.questionnaires}; impulsos guardados: ${d.cravings}${d.averageCravingIntensity !== null ? `; intensidad media de impulsos ${d.averageCravingIntensity.toFixed(1)}/10` : ''}.`);
  const risks = [];
  if (d.averageAnxiety !== null && d.averageAnxiety >= 7) risks.push('ansiedad media elevada');
  if (d.averageUrge !== null && d.averageUrge >= 7) risks.push('ganas medias intensas');
  if (d.averagePerDay > d.dailyGoal) risks.push('promedio por encima del objetivo');
  lines.push(risks.length ? `Señales para prestar atención: ${risks.join('; ')}. Son indicadores descriptivos, no una predicción clínica.` : 'No aparecen alertas simples en estos indicadores agregados; esto no significa ausencia de dificultades.');
  lines.push('Sugerencia: elegí un desencadenante frecuente y prepará una alternativa concreta para ese momento. Registrá también los impulsos que logres atravesar sin fumar.');
  lines.push('Limitación: el análisis depende de los registros ingresados y puede subestimar el consumo si faltan datos.');
  return lines.join('\n');
}
function localAssistantResponse(question) {
  const q = String(question || '').toLowerCase(), d = selectedRangeSummary('week');
  let answer;
  if (/desencaden|dispar|gatill|trigger/.test(q)) answer = 'Tus desencadenantes más frecuentes en los últimos 7 días son: ' + (d.topTriggers.length ? d.topTriggers.map(x => `${x.name} (${x.count})`).join(', ') : 'todavía no hay suficientes registros') + '. Esto muestra asociaciones en los registros, no demuestra que sean la causa del consumo.';
  else if (/horar|momento|cu[aá]ndo|hora/.test(q)) answer = 'Las horas con más registros son: ' + (d.topHours.length ? d.topHours.map(x => `${x.name}:00 (${x.count})`).join(', ') : 'todavía no hay datos suficientes') + '. Podés preparar una alternativa para esos momentos.';
  else if (/ansiedad|nerv|angust/.test(q)) answer = 'La ansiedad media registrada es ' + (d.averageAnxiety === null ? 'todavía no disponible' : d.averageAnxiety.toFixed(1) + '/10') + '. Si notás ansiedad intensa, probá una pausa breve, respiración suave y apoyo de alguien de confianza. El registro no permite hacer un diagnóstico.';
  else if (/progres|mejor|objetiv|meta|consumo|cigarr/.test(q)) answer = localInsights('week');
  else answer = 'Puedo revisar tus patrones básicos sin conexión. ' + localInsights('week') + ' Para responder preguntas más específicas, conectá el servidor GPT cuando tengas internet.';
  return answer + '\n\nModo local: respuesta basada en estadísticas del teléfono; no es un análisis clínico.';
}
function updateAiStatus() {
  const el = $('aiStatus'), online = navigator.onLine;
  el.className = 'status ' + (online ? 'online' : 'offline');
  el.textContent = !online ? 'Sin internet: el motor de análisis local está disponible.'
    : state.aiEndpoint ? 'Conexión disponible y servidor GPT configurado.'
    : 'Conexión a internet disponible. GPT requiere configurar el servidor seguro en Ajustes.';
}
function addBubble(text, who = 'ai') {
  const el = document.createElement('div');
  el.className = 'bubble ' + who; el.textContent = text;
  $('chatLog').appendChild(el); $('chatLog').scrollTop = $('chatLog').scrollHeight;
}
async function callAi(task, message, period = 'week') {
  const endpoint = (state.aiEndpoint || '').trim();
  if (!endpoint) throw new Error('Falta configurar la URL del servidor seguro en Ajustes.');
  if (!isHttps(endpoint)) throw new Error('La dirección del servidor debe comenzar con https://');
  const headers = { 'Content-Type': 'application/json' };
  if (state.aiToken) headers['X-App-Token'] = state.aiToken;
  const ctrl = new AbortController(), timer = setTimeout(() => ctrl.abort(), 30000);
  try {
    const response = await fetch(endpoint, { method: 'POST', headers, signal: ctrl.signal, body: JSON.stringify({ task, message: String(message || '').slice(0, 1200), summary: selectedRangeSummary(period) }) });
    if (response.status === 401) throw new Error('El servidor rechazó el token de acceso. Revisalo en Ajustes.');
    if (!response.ok) throw new Error(`El servidor respondió con el estado ${response.status}.`);
    const data = await response.json();
    if (!data || typeof data.text !== 'string' || !data.text.trim()) throw new Error('El servidor no devolvió una respuesta válida.');
    return data.text.trim();
  } catch (e) {
    if (e.name === 'AbortError') throw new Error('El servidor tardó demasiado en responder.');
    throw e;
  } finally { clearTimeout(timer); }
}
$('saveAiEndpoint').onclick = () => {
  const v = $('aiEndpoint').value.trim();
  if (v && !isHttps(v)) { alert('Usá una dirección HTTPS.'); return; }
  state.aiEndpoint = v; state.aiToken = $('aiToken').value.trim();
  save(); updateAiStatus();
  alert(v ? 'Dirección del servidor guardada.' : 'Conexión GPT desactivada.');
};
$('localAnalysis').onclick = () => { $('localAnalysisResult').textContent = localInsights('week'); };
$('sendChat').onclick = async () => {
  const msg = $('chatInput').value.trim();
  if (!msg) return;
  addBubble(msg, 'user'); $('chatInput').value = '';
  if (!navigator.onLine || !state.aiEndpoint) { addBubble('Modo local (sin GPT):\n' + localAssistantResponse(msg)); return; }
  if (!confirm('¿Enviar a GPT tu consulta y un resumen estadístico agregado? No se enviarán notas personales ni respuestas abiertas del cuestionario.')) return;
  const b = $('sendChat'); b.disabled = true; b.textContent = 'Consultando…';
  try { addBubble(await callAi('chat', msg, 'week')); }
  catch (e) { addBubble('No pude conectar con GPT: ' + e.message + '\nPodés seguir usando el análisis local.'); }
  finally { b.disabled = false; b.textContent = 'Enviar consulta'; }
};
$('gptReport').onclick = async () => {
  if (!navigator.onLine || !state.aiEndpoint) { $('gptReportResult').textContent = 'GPT no está disponible. Análisis local:\n' + localInsights($('period').value); return; }
  if (!confirm('¿Enviar a GPT únicamente el resumen estadístico agregado de este período? No se enviarán notas personales ni respuestas abiertas.')) return;
  const b = $('gptReport'); b.disabled = true; b.textContent = 'Generando…';
  try { $('gptReportResult').textContent = await callAi('report', 'Prepará un informe cuidadoso, psicológico-conductual y no diagnóstico. Explicá tendencias, posibles desencadenantes, logros, límites de los datos y tres acciones concretas. No afirmes causalidad ni predicciones seguras.', $('period').value); }
  catch (e) { $('gptReportResult').textContent = 'No se pudo generar el informe GPT: ' + e.message + '\n\nAnálisis local:\n' + localInsights($('period').value); }
  finally { b.disabled = false; b.textContent = 'Generar informe con GPT'; }
};
window.addEventListener('online', updateAiStatus);
window.addEventListener('offline', updateAiStatus);

/* ---------- Arranque ---------- */
fillTriggerSelect($('trigger'));
fillTriggerSelect($('craveTrigger'));
updateAiStatus();
render();
setInterval(updateLive, 30000);
document.addEventListener('visibilitychange', () => { if (!document.hidden) { updateLive(); tickDelay(); } });
