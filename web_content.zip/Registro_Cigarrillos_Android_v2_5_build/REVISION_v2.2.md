# Revisión y correcciones (2.1 → 2.2)

## Errores corregidos
| # | Dónde | Problema | Corrección |
|---|-------|----------|------------|
| 1 | app.js | "Hora más frecuente" se calculaba con `toLocaleTimeString('es-AR').slice(0,2)`; con formato 12 h daba horas como "1:" o "09" mal agrupadas | Se usa `getHours()` |
| 2 | app.js | Los impulsos se guardaban en UTC (`toISOString`) y se filtraban por fecha local: de noche caían en el día equivocado | Se guardan en hora local; los datos viejos se convierten al cargar |
| 3 | app.js | El botón "Imprimir / PDF" está en Ajustes y por eso imprimía la pantalla de Ajustes | Cambia a Informes antes de imprimir |
| 4 | app.js | El historial mostraba solo la hora, sin fecha | Ahora muestra fecha y hora |
| 5 | app.js | El intervalo medio semanal/mensual incluía las horas nocturnas entre días | Solo cuenta intervalos del mismo día |
| 6 | app.js | "Desde el último" no se actualizaba solo ni al cambiar de día | Se refresca cada 30 s y al volver a la app |
| 7 | app.js | El temporizador de 5 min (`setTimeout`) falla si la pantalla se apaga | Usa hora de fin + cuenta regresiva |
| 8 | app.js | `Array.at()` rompe en WebView antiguos | Reemplazado |
| 9 | app.js | Restaurar JSON aceptaba datos sin validar (ids duplicados/vacíos, textos enormes) y copiaba `aiEndpoint` de la copia (podía redirigir tus datos) | Sanitización completa; se conserva el servidor propio |
| 10 | app.js | CSV vulnerable a inyección de fórmulas (`=`, `+`, `-`, `@`) | Escapado |
| 11 | app.js | Si el JSON local se corrompía, el siguiente guardado lo borraba | Se guarda copia cruda `-corrupto` |
| 12 | index.html | Referencia a `manifest.json` y `sw.js` inexistentes | Eliminados |
| 13 | index.html | Botón "Restaurar copia" (label) sin padding | Estilo corregido |
| 14 | index.html | Pregunta "¿Cómo te sentís?" sin opción vacía (quedaba sin selección) | Opción "Elegir" |
| 15 | MainActivity | `openOutputStream` sin modo `"wt"`: al sobrescribir un archivo más largo la copia JSON quedaba corrupta | Modo `"wt"` |
| 16 | MainActivity | WebView podía navegar a cualquier URL con el puente `Android` expuesto | Navegación bloqueada fuera de assets |
| 17 | MainActivity | Selector de archivos solo `application/json` (muchos proveedores marcan .json como octet-stream) | `*/*` + validación en JS |
| 18 | MainActivity | `allowFileAccess`/`allowContentAccess` activos sin necesidad; sin ciclo de vida del WebView | Desactivados; `onPause/onResume/onDestroy` |
| 19 | Manifest/Gradle | `targetSdk 28` (Android 14+ lo advierte/bloquea), sin icono, `configChanges` incompleto | `targetSdk 34`, icono, más `configChanges` |
| 20 | Docs | LEEME decía "sin permisos de Internet" pero el manifest los pide | Corregido |
| 21 | worker | Sin autenticación (cualquiera podía gastar tu crédito); tamaño medido por cabecera; sin try/catch en llamada a OpenAI | `APP_TOKEN`, límite sobre el cuerpo real, manejo de errores, `store:false`, campos saneados |

## Mejoras
Barra de progreso hacia la meta, gráfico de barras por día en Informes (semana/mes), botón Atrás cierra diálogos, timeout de 30 s en la consulta a GPT, código de app.js legible (ya no minificado).

## No verificado
No pude compilar el APK aquí (sin Gradle ni acceso a red). El JS y el Worker se probaron con Node; el Java y XML no se compilaron: la primera ejecución del workflow de GitHub lo confirmará.

---
# Versión 2.3
- Lista de desencadenantes ampliada a 60 opciones, definida en un solo lugar (`TRIGGER_GROUPS` en app.js) y usada por el registro, el selector de antojos y el filtro del historial.
- Orden: 1) Principales (los 9 originales, con el mismo nombre que antes, por lo que los registros viejos siguen contando igual), 2) Más importantes, 3) Emociones, 4) Cuerpo y necesidad, 5) Momentos y rutinas, 6) Entorno, 7) Motivos y recompensas.
- Al registrar aparece arriba "★ Tus más usados" (según tu historial). El filtro incluye "Otros guardados" para nombres que existan en copias importadas.
- Nombres duplicados del pedido (estrés, mate, ansiedad, caminar, etc.) se unificaron: cada desencadenante existe una sola vez para que las estadísticas no se dividan.
- Corregido: el tipo MIME con ";charset=utf-8" se pasaba tal cual a ACTION_CREATE_DOCUMENT (podía fallar o guardar con extensión incorrecta al exportar CSV/TXT). Ahora se limpia en MainActivity.
- Límite de longitud de nombre de desencadenante subido de 40 a 60 caracteres (app y Worker).

---
# Versión 2.4 (sin desencadenantes repetidos)
- Eliminado el grupo "★ Tus más usados": repetía opciones que ya estaban más abajo en la misma lista.
- Fusionados los sinónimos: "Nervios" → incluido en "Ansiedad y nervios"; "Soledad" y "Sentirse solo" → "Soledad / sentirse solo"; "Esperar demasiado tiempo libre" → incluido en "Aburrimiento y tiempo libre".
- Los registros guardados con esos nombres (o con otra mayúscula/tilde, ej. "estres", "ESTRÉS") se unifican automáticamente al abrir la app o restaurar una copia. Los nombres propios también se unifican entre sí.
- El código descarta cualquier nombre repetido (sin distinguir mayúsculas ni tildes) si en el futuro se agrega por error.
- Orden: Principales (9 originales) → Más importantes (13) → resto por grupos. 57 desencadenantes únicos.

---
# Versión 2.5 (desencadenantes separados)
- Deshecha la fusión de 2.4: ahora cada uno es una opción independiente: Ansiedad, Nervios, Soledad, Sentirse solo, Aburrimiento, Tiempo libre, Esperar y Demasiado tiempo libre.
- Ninguna opción combina dos ("X y Y", "X / Y"). 60 desencadenantes únicos, sin repetidos (comprobado en los 3 selectores).
- Los registros guardados con los nombres combinados de 2.4 pasan al principal: "Ansiedad y nervios" → Ansiedad, "Aburrimiento y tiempo libre" → Aburrimiento, "Soledad / sentirse solo" → Soledad, "Esperar demasiado tiempo libre" → Demasiado tiempo libre.
- Orden: Principales (9 originales) → Más importantes (Nervios y Tiempo libre ocupan el lugar de los dos combinados) → resto por grupos.
