// Registro de Cigarrillos - proxy seguro para OpenAI Responses API
// Secretos/variables en Cloudflare (nunca en la app ni en GitHub):
//   OPENAI_API_KEY (secreto, obligatorio)
//   APP_TOKEN      (secreto, MUY recomendado: la app lo envía en el encabezado X-App-Token)
//   MODEL          (opcional, por defecto gpt-4.1-mini)
const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, X-App-Token",
  "Access-Control-Max-Age": "86400"
};
const json = (data, status = 200) =>
  new Response(JSON.stringify(data), { status, headers: { ...cors, "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" } });

const str = (v, n) => (typeof v === "string" ? v.slice(0, n) : null);
const num = v => (typeof v === "number" && Number.isFinite(v) ? v : null);
const list = a => (Array.isArray(a) ? a.slice(0, 5).map(x => ({ name: str(x && x.name, 60), count: num(x && x.count) })) : []);

function safeEqual(a, b) {
  if (a.length !== b.length) return false;
  let r = 0;
  for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") return new Response(null, { headers: cors });
    if (request.method !== "POST") return json({ error: "Método no permitido" }, 405);
    if (!env.OPENAI_API_KEY) return json({ error: "Falta configurar OPENAI_API_KEY en el servidor" }, 500);

    if (env.APP_TOKEN) {
      const sent = request.headers.get("X-App-Token") || "";
      if (!safeEqual(sent, String(env.APP_TOKEN))) return json({ error: "No autorizado" }, 401);
    }

    // Se mide el cuerpo real: el encabezado content-length puede faltar o mentir.
    let raw;
    try { raw = await request.text(); } catch { return json({ error: "Solicitud inválida" }, 400); }
    if (raw.length > 18000) return json({ error: "Solicitud demasiado grande" }, 413);
    let body;
    try { body = JSON.parse(raw); } catch { return json({ error: "JSON inválido" }, 400); }
    if (!body || typeof body !== "object") return json({ error: "JSON inválido" }, 400);

    const task = body.task === "report" ? "report" : "chat";
    const message = String(body.message || "").slice(0, 1200);
    const s = body.summary && typeof body.summary === "object" ? body.summary : {};
    const dailyCounts = {};
    if (s.dailyCounts && typeof s.dailyCounts === "object") {
      for (const [k, v] of Object.entries(s.dailyCounts).slice(0, 31)) {
        if (/^\d{4}-\d{2}-\d{2}$/.test(k) && num(v) !== null) dailyCounts[k] = v;
      }
    }
    // Solo se reenvían campos conocidos, con tipo y longitud controlados (evita inyección de texto arbitrario).
    const safeSummary = {
      period: str(s.period, 40), from: str(s.from, 10), to: str(s.to, 10),
      total: num(s.total), calendarDays: num(s.calendarDays), averagePerDay: num(s.averagePerDay), dailyGoal: num(s.dailyGoal),
      dailyCounts,
      averageAnxiety: num(s.averageAnxiety), averageUrge: num(s.averageUrge), averageIntervalMinutes: num(s.averageIntervalMinutes),
      topTriggers: list(s.topTriggers), topHours: list(s.topHours),
      questionnaires: num(s.questionnaires), cravings: num(s.cravings), averageCravingIntensity: num(s.averageCravingIntensity)
    };

    const instructions = "Sos un asistente de apoyo para reducción del consumo de tabaco. Respondé en español rioplatense claro, cálido y sin juzgar. Analizá solo los datos agregados entregados; no inventes información, no diagnostiques, no atribuyas causalidad ni presentes estimaciones como predicciones seguras. Ofrecé pasos pequeños y realistas. No reemplazás a profesionales de salud. Si hay señales de malestar intenso, recomendá buscar apoyo profesional o de confianza.";
    const input = `Tarea: ${task}\nConsulta: ${message}\nResumen estadístico (sin notas ni respuestas abiertas): ${JSON.stringify(safeSummary)}`;

    let upstream, result;
    try {
      upstream = await fetch("https://api.openai.com/v1/responses", {
        method: "POST",
        headers: { "Authorization": `Bearer ${env.OPENAI_API_KEY}`, "Content-Type": "application/json" },
        body: JSON.stringify({ model: env.MODEL || "gpt-4.1-mini", instructions, input, max_output_tokens: 900, store: false }),
        signal: AbortSignal.timeout(25000)
      });
      result = await upstream.json().catch(() => ({}));
    } catch {
      return json({ error: "No se pudo contactar al proveedor de IA" }, 504);
    }
    if (!upstream.ok) return json({ error: (result.error && result.error.message) || "Error del proveedor de IA" }, 502);

    let text = result.output_text || "";
    if (!text && Array.isArray(result.output)) {
      text = result.output.flatMap(x => x.content || []).filter(x => x.type === "output_text").map(x => x.text).join("\n");
    }
    if (!text) return json({ error: "Respuesta vacía del modelo" }, 502);
    return json({ text });
  }
};
