# Servidor de IA (Cloudflare Workers)

1. Crear un Worker en https://dash.cloudflare.com/ .
2. Copiar el contenido de `cloudflare-worker.js` al editor del Worker y desplegarlo.
3. En Settings → Variables and Secrets crear estos **secretos**:
   - `OPENAI_API_KEY`: tu clave de OpenAI.
   - `APP_TOKEN`: una cadena larga y aleatoria que inventes (ej. 32+ caracteres). **Muy recomendado**: sin él, cualquiera que conozca la URL del Worker puede gastar tu crédito de OpenAI.
4. (Opcional) Variable `MODEL` con un modelo habilitado en tu cuenta; por defecto usa `gpt-4.1-mini`. Si OpenAI lo retira, cambiá este valor sin tocar el código.
5. Configurar rate limiting en Cloudflare y revisar el consumo/facturación en OpenAI.
6. En la app: Ajustes → Conexión de IA → pegar la URL HTTPS del Worker y el mismo valor de `APP_TOKEN`.

La app manda únicamente agregados estadísticos y la consulta escrita. No envía notas de cigarrillos ni texto libre de cuestionarios. El Worker solo reenvía campos conocidos y pide a OpenAI que no almacene la respuesta (`store:false`).
La clave OpenAI y el token nunca van dentro del APK ni del repositorio. El token tampoco se incluye en las copias JSON exportadas.
