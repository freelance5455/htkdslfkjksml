# Registro de Cigarrillos 2.5 - integración híbrida

## Incluido
- Se conserva la interfaz existente y los registros en `localStorage`.
- Nuevo Centro de IA con análisis local, chat y solicitud de informes GPT.
- El análisis local resume cantidad, promedio diario, intervalo, ansiedad, ganas, desencadenantes, horarios e impulsos.
- Alertas locales descriptivas; no son predicciones clínicas.
- Conexión GPT opcional mediante proxy HTTPS; confirmación antes de cada envío.
- Se envían agregados estadísticos y la consulta; no se envían notas personales ni respuestas abiertas del cuestionario.
- API key solamente en el secreto del servidor.

## Activar GPT
Seguir `server/README.md`, desplegar el Worker y pegar su URL y el token en Ajustes → Conexión de IA. Sin esa configuración, el modo local funciona sin internet.

## Importante
El motor sin conexión es un analizador basado en reglas y estadísticas, no un modelo GPT local. La conexión a GPT requiere internet, servidor configurado y facturación de API habilitada.
