# ATTENOVA Money — Version 2.0

A premium, offline-first personal expense manager with an ATTENOVA-inspired interface.

## Features
- Dashboard with balance, monthly income, expenses, daily average and spending breakdown
- Add, edit, search, filter and delete income/expense transactions
- Category-based monthly budgets with progress and over-limit warnings
- Monthly reports with downloadable CSV expenditure data
- JSON backup and restore
- Profile name, currency selection, persistent light/dark theme
- Responsive side navigation and mobile drawer
- Local browser storage; no account or server required

## Run
Open `index.html` in a modern browser, or serve this folder using a local web server. Install as an app from the browser menu when supported. The service worker enables offline caching when served over HTTPS or localhost.

## Data
Data is stored in browser localStorage on the current device. Export a backup regularly before clearing browser data or changing devices.
