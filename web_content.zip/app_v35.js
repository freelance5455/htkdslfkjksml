const APP_DIAG_VERSION = "HTMLTOAPK_MULTI_TEACHER_V34_STUDENT_REPORT";
console.log(APP_DIAG_VERSION);
const SURAH_DATA = [["الفاتحة",7],["البقرة",286],["آل عمران",200],["النساء",176],["المائدة",120],["الأنعام",165],["الأعراف",206],["الأنفال",75],["التوبة",129],["يونس",109],["هود",123],["يوسف",111],["الرعد",43],["إبراهيم",52],["الحجر",99],["النحل",128],["الإسراء",111],["الكهف",110],["مريم",98],["طه",135],["الأنبياء",112],["الحج",78],["المؤمنون",118],["النور",64],["الفرقان",77],["الشعراء",227],["النمل",93],["القصص",88],["العنكبوت",69],["الروم",60],["لقمان",34],["السجدة",30],["الأحزاب",73],["سبأ",54],["فاطر",45],["يس",83],["الصافات",182],["ص",88],["الزمر",75],["غافر",85],["فصلت",54],["الشورى",53],["الزخرف",89],["الدخان",59],["الجاثية",37],["الأحقاف",35],["محمد",38],["الفتح",29],["الحجرات",18],["ق",45],["الذاريات",60],["الطور",49],["النجم",62],["القمر",55],["الرحمن",78],["الواقعة",96],["الحديد",29],["المجادلة",22],["الحشر",24],["الممتحنة",13],["الصف",14],["الجمعة",11],["المنافقون",11],["التغابن",18],["الطلاق",12],["التحريم",12],["الملك",30],["القلم",52],["الحاقة",52],["المعارج",44],["نوح",28],["الجن",28],["المزمل",20],["المدثر",56],["القيامة",40],["الإنسان",31],["المرسلات",50],["النبأ",40],["النازعات",46],["عبس",42],["التكوير",29],["الانفطار",19],["المطففين",36],["الانشقاق",25],["البروج",22],["الطارق",17],["الأعلى",19],["الغاشية",26],["الفجر",30],["البلد",20],["الشمس",15],["الليل",21],["الضحى",11],["الشرح",8],["التين",8],["العلق",19],["القدر",5],["البينة",8],["الزلزلة",8],["العاديات",11],["القارعة",11],["التكاثر",8],["العصر",3],["الهمزة",9],["الفيل",5],["قريش",4],["الماعون",7],["الكوثر",3],["الكافرون",6],["النصر",3],["المسد",5],["الإخلاص",4],["الفلق",5],["الناس",6]];
let user=null,circles=[],students=[],activeCircle=null,activeStudent=null,lessonType='new',editingRecitationId=null;
let teacherName=localStorage.getItem('madar_teacher_name')||'';
let teacherProfile=null;
function loadTeacherName(){const e=document.getElementById('teacherName');if(e)e.value=teacherName;}
function saveTeacherName(){const e=document.getElementById('teacherName');if(e&&e.value.trim()){teacherName=e.value.trim();localStorage.setItem('madar_teacher_name',teacherName);}}
async function ensureTeacherProfile(){
  let name=(localStorage.getItem('madar_teacher_name')||'').trim();
  if(!name){name=prompt('اكتب اسم المحفظ الذي يستخدم هذا الجهاز:','');if(!name||!name.trim())throw new Error('يجب كتابة اسم المحفظ أولاً.');name=name.trim();localStorage.setItem('madar_teacher_name',name);}
  const existing=await sb.from('teacher_profiles').select('*').eq('auth_user_id',user.id).eq('teacher_name',name).maybeSingle();
  if(existing.error && !/relation .* does not exist|schema cache/i.test(existing.error.message)) throw existing.error;
  if(existing.data){teacherProfile=existing.data;return null}
  const code='T-'+crypto.randomUUID().slice(0,8).toUpperCase();
  const ins=await sb.from('teacher_profiles').insert({auth_user_id:user.id,teacher_name:name,teacher_code:code}).select('*').single();
  if(ins.error) return ins.error;
  teacherProfile=ins.data; return null;
}
function profileRequired(){return teacherProfile?.id||null;}
const $=id=>document.getElementById(id);
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
const msg=(id,text,ok=false)=>{const e=$(id);if(!e)return;e.textContent=text;e.className=ok?'ok':'err';};
function screen(id){document.querySelectorAll('.screen').forEach(x=>x.classList.add('hidden'));const e=$(id);if(e)e.classList.remove('hidden');window.scrollTo(0,0)}
function empty(t){return `<div class="empty">${esc(t)}</div>`}
function goHome(){screen('home')}
function openCircles(){screen('circles');loadCircles()}
async function openReport(){screen('report'); $('reportDate').value=localDate(); $('reportNotes').value=''; await renderAllCircleReports()}
function openCircleView(){if(!activeCircle)return openCircles();screen('circle');loadStudents()}
function openStudentView(){if(!activeStudent)return openCircleView();screen('student');loadHistory()}

async function login(){
  const email=$('email').value.trim(),password=$('password').value;
  if(!email||!password){msg('loginMsg','اكتب البريد الإلكتروني وكلمة المرور.');return}
  const b=$('loginBtn');b.disabled=true;msg('loginMsg','جاري الدخول...');
  try{
    const r=await sb.auth.signInWithPassword({email,password});
    if(r.error){msg('loginMsg',r.error.message);return}
    user=r.data?.user||null;
    if(!user){msg('loginMsg','تعذر الحصول على جلسة الدخول.');return}
    await checkRole();
  }catch(e){console.error(e);msg('loginMsg','تعذر الاتصال بـ Supabase: '+(e?.message||e))}
  finally{b.disabled=false}
}
async function checkRole(){
  const r=await sb.from('profiles').select('role').eq('id',user.id).maybeSingle();
  if(r.error){msg('loginMsg','خطأ في قراءة صلاحية الحساب: '+r.error.message);return}
  if(!r.data||r.data.role!=='teacher'){await sb.auth.signOut();msg('loginMsg','هذا الحساب ليس حساب محفظ.');return}
  const pe=await ensureTeacherProfile();if(pe){msg('loginMsg','تعذر حفظ هوية المحفظ: '+pe.message);return}
  $('login').classList.add('hidden');$('app').classList.remove('hidden');await loadCircles();goHome();loadTeacherName();
}
async function loadCircles(){
  const r=await sb.from('circles').select('*').eq('teacher_id',user.id).eq('teacher_profile_id',profileRequired()).order('created_at',{ascending:true});
  if(r.error){msg('circleMsg',r.error.message);return}
  circles=r.data||[];$('circleCount').textContent=circles.length+' حلقة';
  $('circleList').innerHTML=circles.map(c=>`<div class="circle-row cardRow"><button type="button" class="circle-open" data-circle-id="${c.id}"><span class="rowIcon">📚</span><span class="rowText"><b>${esc(c.name)}</b><small>فتح الحلقة والطلاب</small></span><span class="arrow">‹</span></button><button type="button" class="circle-delete" data-delete-circle="${c.id}">🗑️ حذف الحلقة</button></div>`).join('')||empty('لا توجد حلقات بعد. أضف أول حلقة.');
  document.querySelectorAll('[data-circle-id]').forEach(b=>b.onclick=()=>chooseCircle(b.dataset.circleId));
  document.querySelectorAll('[data-delete-circle]').forEach(b=>b.onclick=(e)=>{e.preventDefault();e.stopPropagation();deleteCircle(b.dataset.deleteCircle)});
}
async function addCircle(){
  const name=$('circleName').value.trim();if(!name){msg('circleMsg','اكتب اسم الحلقة أولاً.');return}
  const b=$('addCircle');b.disabled=true;msg('circleMsg','جاري الإضافة...');
  try{const r=await sb.from('circles').insert({teacher_id:user.id,teacher_profile_id:profileRequired(),name});if(r.error){msg('circleMsg',r.error.message);return}$('circleName').value='';msg('circleMsg','تمت إضافة الحلقة.',true);await loadCircles()}finally{b.disabled=false}
}

let deleteCircleArmed=null;
let deleteCircleTimer=null;
async function deleteCircle(id){
  const c=circles.find(x=>x.id===id);
  if(!c)return;
  const b=[...document.querySelectorAll('[data-delete-circle]')].find(x=>x.dataset.deleteCircle===id);
  if(deleteCircleArmed!==id){
    deleteCircleArmed=id;
    if(b){b.textContent='اضغط مرة أخرى للحذف';b.dataset.armed='1';}
    msg('circleMsg',`تأكيد حذف «${c.name}»: اضغط زر الحذف مرة ثانية خلال 5 ثوانٍ.`);
    clearTimeout(deleteCircleTimer);
    deleteCircleTimer=setTimeout(()=>{
      if(deleteCircleArmed===id){deleteCircleArmed=null;loadCircles();}
    },5000);
    return;
  }
  deleteCircleArmed=null; clearTimeout(deleteCircleTimer);
  if(b){b.disabled=true;b.textContent='جاري الحذف...';}
  msg('circleMsg','جاري حذف الحلقة وكل بياناتها...');
  try{
    const r=await sb.rpc('delete_teacher_circle',{p_circle_id:id});
    if(r.error) throw r.error;
    circles=circles.filter(x=>x.id!==id);
    activeCircle=null; activeStudent=null;
    await loadCircles();
    msg('circleMsg','تم حذف الحلقة وكل بياناتها نهائيًا.',true);
  }catch(e){
    console.error('deleteCircle',e);
    msg('circleMsg','تعذر حذف الحلقة: '+(e?.message||String(e)));
    if(b){b.disabled=false;b.textContent='🗑️ حذف الحلقة';}
  }
}

let deleteAllArmed=false;
let deleteAllTimer=null;
async function deleteAllTeacherData(){
  const b=document.getElementById('deleteAllData');
  if(!deleteAllArmed){
    deleteAllArmed=true;
    if(b)b.querySelector('span')?.replaceChildren(document.createTextNode('اضغط مرة أخرى للحذف النهائي'));
    msg('dangerMsg','تأكيد الحذف النهائي: اضغط الزر مرة ثانية خلال 5 ثوانٍ.');
    clearTimeout(deleteAllTimer);
    deleteAllTimer=setTimeout(()=>{deleteAllArmed=false;loadCircles();},5000);
    return;
  }
  deleteAllArmed=false;clearTimeout(deleteAllTimer);
  if(b)b.disabled=true;
  msg('dangerMsg','جاري حذف جميع البيانات...');
  try{
    const r=await sb.rpc('delete_all_teacher_data');
    if(r.error)throw r.error;
    Object.keys(localStorage).filter(k=>k.startsWith('madar_report_drafts_')).forEach(k=>localStorage.removeItem(k));
    circles=[];students=[];activeCircle=null;activeStudent=null;
    msg('dangerMsg','تم حذف جميع بيانات المحفظ نهائيًا.',true); await loadCircles(); goHome();
  }catch(e){console.error('deleteAllTeacherData',e);msg('dangerMsg','تعذر حذف البيانات: '+(e?.message||String(e)))}
  finally{if(b)b.disabled=false}
}

async function chooseCircle(id){activeCircle=circles.find(c=>c.id===id)||null;if(!activeCircle)return;$('circleTitle').textContent=activeCircle.name;screen('circle');await loadStudents()}
async function loadStudents(){
  const r=await sb.from('students').select('*').eq('circle_id',activeCircle.id).eq('active',true).order('name');
  if(r.error){$('studentList').innerHTML=empty(r.error.message);return}students=r.data||[];
  $('studentList').innerHTML=students.map(s=>`<button class="cardRow" data-student-id="${s.id}"><span class="avatar">${esc(s.name).slice(0,1)}</span><span class="rowText"><b>${esc(s.name)}</b><small>فتح ملف الطالب</small></span><span class="arrow">‹</span></button>`).join('')||empty('لا يوجد طلاب في هذه الحلقة.');
  document.querySelectorAll('[data-student-id]').forEach(b=>b.onclick=()=>chooseStudent(b.dataset.studentId));
}
async function addStudent(){
  const name=$('studentName').value.trim();if(!name){msg('studentMsg','اكتب اسم الطالب أولاً.');return}
  const b=$('addStudent');b.disabled=true;msg('studentMsg','جاري الإضافة...');
  try{const r=await sb.from('students').insert({circle_id:activeCircle.id,name});if(r.error){msg('studentMsg',r.error.message);return}$('studentName').value='';msg('studentMsg','تمت إضافة الطالب.',true);await loadStudents()}finally{b.disabled=false}
}

let deleteStudentArmed=null;
let deleteStudentTimer=null;
async function deleteStudent(id){
  const st=students.find(x=>x.id===id)||activeStudent;
  if(!st)return;
  const b=document.getElementById('deleteStudentBtn');
  if(deleteStudentArmed!==id){
    deleteStudentArmed=id;
    if(b){b.textContent='⚠️ اضغط مرة أخرى للحذف النهائي';b.disabled=false;}
    msg('studentDeleteMsg',`تأكيد حذف الطالب «${st.name}»: اضغط الزر مرة ثانية خلال 5 ثوانٍ.`);
    clearTimeout(deleteStudentTimer);
    deleteStudentTimer=setTimeout(()=>{if(deleteStudentArmed===id){deleteStudentArmed=null;if(b)b.textContent='🗑️ حذف الطالب';}},5000);
    return;
  }
  deleteStudentArmed=null;clearTimeout(deleteStudentTimer);
  if(b){b.disabled=true;b.textContent='جاري الحذف...';}
  msg('studentDeleteMsg','جاري حذف الطالب وسجل حضوره وحفظه...');
  try{
    const r1=await sb.from('recitations').delete().eq('student_id',id);
    if(r1.error)throw r1.error;
    const r2=await sb.from('attendance').delete().eq('student_id',id);
    if(r2.error)throw r2.error;
    const r3=await sb.from('students').delete().eq('id',id).eq('circle_id',activeCircle.id);
    if(r3.error)throw r3.error;
    if(!r3.data && r3.status!==204){
      const chk=await sb.from('students').select('id').eq('id',id).maybeSingle();
      if(chk.data)throw new Error('لم يتم حذف الطالب. تأكد من صلاحية الحذف للمحفظ.');
    }
    students=students.filter(x=>x.id!==id);
    if(activeStudent?.id===id){activeStudent=null;await loadStudents();openCircleView();}
    else await loadStudents();
    msg('studentMsg','تم حذف الطالب وجميع سجلاته بنجاح.',true);
  }catch(e){
    console.error('deleteStudent',e);
    msg('studentDeleteMsg','تعذر حذف الطالب: '+(e?.message||String(e)));
  }finally{if(b){b.disabled=false;b.textContent='🗑️ حذف الطالب';}}
}
function chooseStudent(id){activeStudent=students.find(s=>s.id===id)||null;if(!activeStudent)return;$('studentTitle').textContent=activeStudent.name;screen('student');loadHistory()}
function localDate(){const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`}
function recitationDate(x){return String(x.recitation_date||x.date||x.created_at||'').slice(0,10)}
function recitationInfo(x){
  const fa=x.from_ayah??x.from_verse??x.start_ayah??x.start_verse??x.ayah_from??x.from??'—';
  const ta=x.to_ayah??x.to_verse??x.end_ayah??x.end_verse??x.ayah_to??x.to??'—';
  const sn=x.surah_number??x.surah??1;
  return {fa,ta,sn,name:SURAH_DATA[(Number(sn)||1)-1]?.[0]||'سورة'};
}
async function loadHistory(){
  const r=await sb.from('recitations').select('*').eq('student_id',activeStudent.id).order('created_at',{ascending:false}).limit(100);
  if(r.error){$('history').innerHTML=empty(r.error.message);return}
  const rows=r.data||[];
  const groups={};
  for(const x of rows){
    const d=recitationDate(x)||'غير محدد';
    if(!groups[d])groups[d]=[];
    groups[d].push(x);
  }
  const dates=Object.keys(groups).sort((a,b)=>b.localeCompare(a));
  const html=dates.map(date=>{
    const items=groups[date].map(x=>{
      const q=recitationInfo(x);
      return `<span class="today-item"><span class="type-pill ${x.type==='new'?'new':'review'}">${x.type==='new'?'📖 حفظ جديد':'🔄 مراجعة'}</span><span>${esc(q.name)} ${esc(q.fa)}–${esc(q.ta)}</span><span class="history-actions"><button type="button" class="mini edit" data-edit-recitation="${esc(x.id)}">تعديل</button><button type="button" class="mini delete" data-delete-recitation="${esc(x.id)}">حذف</button></span></span>`;
    }).join('');
    return `<div class="history date-history"><div class="history-main"><b>📅 ${esc(date)}</b><div class="today-items">${items}</div></div></div>`;
  }).join('');
  $('history').innerHTML=html||empty('لا يوجد سجل لهذا الطالب.');
  document.querySelectorAll('[data-edit-recitation]').forEach(b=>b.onclick=(e)=>{e.preventDefault();e.stopPropagation();editRecitation(b.dataset.editRecitation)});
  document.querySelectorAll('[data-delete-recitation]').forEach(b=>b.onclick=(e)=>{e.preventDefault();e.stopPropagation();deleteRecitation(b.dataset.deleteRecitation)});
}

function attendanceDate(x){
  return String(x.attendance_date||x.date||x.created_at||'').slice(0,10);
}
function formatArabicDate(d){
  if(!d || d.length<10) return d||'غير محدد';
  const [y,m,day]=d.split('-');
  return `${day}/${m}/${y}`;
}
function pct(n,d){return d?Math.round((n/d)*1000)/10:0}
let currentStudentReportText='';
async function openStudentReport(){
  if(!activeStudent || !activeCircle) return;
  const panel=$('studentReportPanel');
  if(panel) panel.classList.remove('hidden');
  msg('studentReportMsg','جاري تحميل تقرير الطالب...');
  $('studentReportStats').innerHTML='';
  $('studentReportBody').innerHTML=empty('جاري تحميل البيانات...');
  $('studentReportSub').textContent=`${activeStudent.name} — الحلقة: ${activeCircle.name}`;
  try{
    const [ar, rr]=await Promise.all([
      sb.from('attendance').select('*').eq('student_id',activeStudent.id),
      sb.from('recitations').select('*').eq('student_id',activeStudent.id).order('created_at',{ascending:false}).limit(500)
    ]);
    if(ar.error) throw ar.error;
    if(rr.error) throw rr.error;
    const attendanceRows=ar.data||[];
    const recRows=rr.data||[];
    const byDate={};
    attendanceRows.forEach(x=>{
      const d=attendanceDate(x); if(!d)return;
      if(!byDate[d])byDate[d]=[];
      byDate[d].push(x);
    });
    const dates=Object.keys(byDate).sort((a,b)=>b.localeCompare(a));
    let present=0, absent=0;
    const seenPresent=new Set(), seenAbsent=new Set();
    for(const x of attendanceRows){
      const d=attendanceDate(x)||String(x.id);
      const status=String(x.status||'present').toLowerCase();
      if(status==='absent'||status==='غائب') { if(!seenAbsent.has(d)){absent++;seenAbsent.add(d)} }
      else { if(!seenPresent.has(d)){present++;seenPresent.add(d)} }
    }
    const total=Math.max(present+absent, dates.length);
    const attendancePct=pct(present,total);
    const newCount=recRows.filter(x=>x.type==='new').length;
    const reviewCount=recRows.filter(x=>x.type==='review').length;
    $('studentReportStats').innerHTML=[
      ['عدد الحصص',total,''],
      ['الحضور',present,'good'],
      ['الغياب',absent,'bad'],
      ['نسبة الحضور',attendancePct+'%','good']
    ].map(([l,v,c])=>`<div class="student-stat ${c}"><b>${esc(v)}</b><span>${l}</span></div>`).join('');
    let body=`<div class="student-report-extra"><span>📖 حفظ جديد: <b>${newCount}</b></span><span>🔄 مراجعة: <b>${reviewCount}</b></span></div>`;
    if(!dates.length){
      body+=empty('لا يوجد سجل حضور لهذا الطالب حتى الآن.');
    }else{
      body+=`<h4>سجل الحضور</h4><div class="student-attendance-list">`;
      for(const d of dates){
        const dayRows=byDate[d];
        const isAbsent=dayRows.some(x=>String(x.status||'present').toLowerCase()==='absent'||String(x.status||'').includes('غائب'));
        body+=`<div class="student-attendance-row"><span>📅 ${esc(formatArabicDate(d))}</span><b class="${isAbsent?'badText':'goodText'}">${isAbsent?'❌ غائب':'✅ حاضر'}</b></div>`;
      }
      body+=`</div>`;
    }
    $('studentReportBody').innerHTML=body;
    currentStudentReportText=
`تقرير الطالب
اسم الطالب: ${activeStudent.name}
الحلقة: ${activeCircle.name}

عدد الحصص: ${total}
الحضور: ${present}
الغياب: ${absent}
نسبة الحضور: ${attendancePct}%
حفظ جديد: ${newCount}
مراجعة: ${reviewCount}

سجل الحضور:
${dates.length?dates.map(d=>{
  const dayRows=byDate[d];
  const isAbsent=dayRows.some(x=>String(x.status||'present').toLowerCase()==='absent'||String(x.status||'').includes('غائب'));
  return `${formatArabicDate(d)} — ${isAbsent?'غائب':'حاضر'}`;
}).join('\n'):'لا يوجد سجل حضور.'}`;
    msg('studentReportMsg','تم تحميل التقرير.',true);
  }catch(e){
    console.error('openStudentReport',e);
    $('studentReportStats').innerHTML='';
    $('studentReportBody').innerHTML=empty('تعذر تحميل تقرير الطالب: '+(e?.message||String(e)));
    currentStudentReportText='';
    msg('studentReportMsg','تعذر تحميل التقرير: '+(e?.message||String(e)));
  }
}
function closeStudentReport(){
  const panel=$('studentReportPanel'); if(panel) panel.classList.add('hidden');
}
async function copyStudentReport(){
  if(!currentStudentReportText){msg('studentReportMsg','افتح تقرير الطالب أولًا.');return}
  try{
    if(navigator.clipboard && window.isSecureContext){
      await navigator.clipboard.writeText(currentStudentReportText);
    }else{
      const ta=$('studentReportCopyText');
      ta.value=currentStudentReportText; ta.classList.remove('hidden'); ta.select();
      document.execCommand('copy'); ta.classList.add('hidden');
    }
    msg('studentReportMsg','تم نسخ التقرير بنجاح، ويمكنك إرساله لولي الأمر.',true);
  }catch(e){
    try{
      const ta=$('studentReportCopyText');
      ta.value=currentStudentReportText; ta.classList.remove('hidden'); ta.select();
      document.execCommand('copy'); ta.classList.add('hidden');
      msg('studentReportMsg','تم نسخ التقرير.',true);
    }catch(e2){msg('studentReportMsg','تعذر نسخ التقرير: '+(e2?.message||String(e2)))}
  }
}

function openLesson(t){
  editingRecitationId=null;lessonType=t;
  $('lessonTitle').textContent=t==='new'?'حفظ جديد':'مراجعة';
  $('saveLesson').textContent='حفظ';$('lessonMsg').textContent='';
  $('lessonDate').value=localDate();$('fromAyah').value='';$('toAyah').value='';$('surah').value='0';
  updateAyahLimit();screen('lesson')
}
async function editRecitation(id){
  const r=await sb.from('recitations').select('*').eq('id',id).eq('student_id',activeStudent.id).maybeSingle();
  if(r.error||!r.data){msg('lessonMsg','تعذر فتح السجل للتعديل: '+(r.error?.message||'السجل غير موجود'));return}
  const x=r.data,q=recitationInfo(x);editingRecitationId=id;lessonType=x.type==='review'?'review':'new';$('lessonTitle').textContent=lessonType==='new'?'تعديل الحفظ الجديد':'تعديل المراجعة';$('saveLesson').textContent='حفظ التعديل';$('lessonDate').value=recitationDate(x)||localDate();$('surah').value=String((Number(q.sn)||1)-1);updateAyahLimit();$('fromAyah').value=q.fa;$('toAyah').value=q.ta;$('lessonMsg').textContent='';screen('lesson');
}
async function deleteRecitation(id){
  if(!id||!activeStudent)return;
  if(!confirm('هل تريد حذف هذا السجل نهائيًا؟'))return;
  try{
    const r=await sb.rpc('delete_teacher_recitation',{p_recitation_id:id});
    if(r.error){alert('تعذر الحذف: '+r.error.message);return}
    await loadHistory();
  }catch(e){alert('تعذر الحذف: '+(e?.message||e))}
}

function updateAyahLimit(){const m=SURAH_DATA[Number($('surah').value)][1];$('fromAyah').max=m;$('toAyah').max=m;$('surahHint').textContent='عدد آيات السورة: '+m}
function serverMissingColumn(msg){
  const m=String(msg||'').match(/(?:Could not find the '([^']+)' column|column ["']([^"']+)["'])/i);
  return m?.[1]||m?.[2]||null;
}
function serverNotNullColumn(msg){
  const m=String(msg||'').match(/null value in column ["']([^"']+)["']/i);
  return m?.[1]||null;
}
function valueForColumn(col,ctx){
  const c=String(col||'').toLowerCase();
  if(c==='circle_id') return ctx.circle_id;
  if(c==='student_id') return ctx.student_id;
  if(c==='teacher_id') return ctx.teacher_id;
  if(c==='type') return ctx.type;
  if(c.includes('surah') && c.includes('number')) return ctx.surah_number;
  if(c==='surah_from') return ctx.surah_number;
  if(c==='surah_to') return ctx.surah_number;
  if(c.includes('from') && (c.includes('ayah')||c.includes('verse'))) return ctx.from_ayah;
  if(c.includes('to') && (c.includes('ayah')||c.includes('verse'))) return ctx.to_ayah;
  if(c==='from_ayah') return ctx.from_ayah;
  if(c==='to_ayah') return ctx.to_ayah;
  if(c==='recitation_date') return ctx.date;
  if(c==='attendance_date') return ctx.date;
  if(c==='report_date') return ctx.date;
  if(c==='date') return ctx.date;
  if(c==='created_at') return ctx.created_at||new Date().toISOString();
  if(c==='updated_at') return new Date().toISOString();
  if(c==='hours') return ctx.hours??0;
  if(c==='notes') return ctx.notes??'';
  if(c==='status') return ctx.status||'present';
  return undefined;
}
async function adaptiveInsert(table, initial, ctx, maxTries=12){
  let payload={...initial};
  for(let attempt=0;attempt<maxTries;attempt++){
    const r=await sb.from(table).insert(payload);
    if(!r.error) return null;
    const msg=String(r.error.message||r.error);
    const missing=serverMissingColumn(msg);
    if(missing && Object.prototype.hasOwnProperty.call(payload,missing)){
      delete payload[missing];
      continue;
    }
    const nn=serverNotNullColumn(msg);
    if(nn && !Object.prototype.hasOwnProperty.call(payload,nn)){
      const v=valueForColumn(nn,ctx);
      if(v!==undefined){payload[nn]=v;continue}
    }
    return new Error('['+APP_DIAG_VERSION+'] '+table+': '+msg);
  }
  return new Error('['+APP_DIAG_VERSION+'] '+table+': تعذر تجهيز البيانات تلقائياً.');
}
async function adaptiveUpdate(table,id,initial,ctx,maxTries=12){
  let payload={...initial};
  for(let attempt=0;attempt<maxTries;attempt++){
    const r=await sb.from(table).update(payload).eq('id',id);
    if(!r.error)return null;
    const missing=serverMissingColumn(r.error.message);
    if(missing&&Object.prototype.hasOwnProperty.call(payload,missing)){delete payload[missing];continue}
    const nn=serverNotNullColumn(r.error.message);
    if(nn&&!Object.prototype.hasOwnProperty.call(payload,nn)){const v=valueForColumn(nn,ctx);if(v!==undefined){payload[nn]=v;continue}}
    return new Error(r.error.message);
  }
  return new Error('تعذر تعديل السجل تلقائياً.');
}
async function saveLesson(e){
  if(e){e.preventDefault();e.stopPropagation()}
  try{
    if(!activeCircle || !activeStudent){msg('lessonMsg','اختر الحلقة والطالب أولاً.');return}
    const surahSel=$('surah'),fromEl=$('fromAyah'),toEl=$('toAyah');
    if(!surahSel||!fromEl||!toEl){msg('lessonMsg','خطأ في واجهة الحفظ: عناصر الإدخال غير موجودة.');return}
    const i=Number(surahSel.value||0),from=Number(fromEl.value||0),to=Number(toEl.value||0);
    if(!Number.isInteger(i)||i<0||!from||!to){msg('lessonMsg','اختر السورة وأدخل الآيات.');return}
    const max=SURAH_DATA[i]?.[1]||0;
    if(from<1||to<1||from>to||to>max){msg('lessonMsg','رقم الآيات غير صحيح لهذه السورة.');return}
    const selectedDate=$('lessonDate')?.value||localDate();
    if(!/^\d{4}-\d{2}-\d{2}$/.test(selectedDate)){msg('lessonMsg','اختر تاريخًا صحيحًا.');return}
    const ctx={circle_id:activeCircle.id,student_id:activeStudent.id,teacher_id:user?.id,teacher_profile_id:profileRequired(),type:lessonType,surah_number:i+1,from_ayah:from,to_ayah:to,date:selectedDate};
    const broad={circle_id:ctx.circle_id,student_id:ctx.student_id,teacher_id:ctx.teacher_id,teacher_profile_id:ctx.teacher_profile_id,type:ctx.type,surah_number:i+1,surah_from:i+1,surah_to:i+1,from_ayah:from,to_ayah:to,start_ayah:from,end_ayah:to,from_verse:from,to_verse:to,recitation_date:selectedDate,date:selectedDate};
    const b=$('saveLesson');if(b)b.disabled=true;msg('lessonMsg',editingRecitationId?'جاري تعديل السجل...':'جاري الحفظ...');
    let err=null;
    if(editingRecitationId){
      const upd={type:ctx.type,surah_number:i+1,surah_from:i+1,surah_to:i+1,from_ayah:from,to_ayah:to,start_ayah:from,end_ayah:to,from_verse:from,to_verse:to,recitation_date:selectedDate,date:selectedDate};
      err=await adaptiveUpdate('recitations',editingRecitationId,upd,ctx);
      if(!err) editingRecitationId=null;
    }else{
      err=await adaptiveInsert('recitations',broad,ctx);
    }
    if(err){console.error(err);msg('lessonMsg',(editingRecitationId?'فشل التعديل: ':'فشل الحفظ: ')+err.message);return}
    $('saveLesson').textContent='حفظ';msg('lessonMsg','تم الحفظ بنجاح.',true);await loadHistory();
  }catch(err){console.error(APP_DIAG_VERSION,err);msg('lessonMsg','خطأ أثناء الحفظ: '+(err?.message||String(err)))}
  finally{const b=$('saveLesson');if(b)b.disabled=false}
}

function reportDraftKey(date){return `madar_report_drafts_${user?.id||'guest'}_${date}`}
function readReportDrafts(date){
  try{return JSON.parse(localStorage.getItem(reportDraftKey(date))||'{}')||{}}catch{return {}}
}
function writeReportDrafts(date,drafts){localStorage.setItem(reportDraftKey(date),JSON.stringify(drafts||{}))}
function clearReportDrafts(date){localStorage.removeItem(reportDraftKey(date))}
function getDraftForCircle(date,cid){return readReportDrafts(date)[cid]||null}
function setDraftForCircle(date,cid,draft){const all=readReportDrafts(date);all[cid]={circle_id:cid,hours:Number(draft.hours||0),studentIds:[...(draft.studentIds||[])],notes:String(draft.notes||'')};writeReportDrafts(date,all)}

async function saveCircleDraft(card){
  const date=$('reportDate')?.value;
  const cid=card?.dataset.circle;
  if(!date||!cid)return false;
  const hours=Number(card.querySelector('.circle-hours')?.value||0);
  const studentIds=[...card.querySelectorAll('.circle-att:checked')].map(x=>x.dataset.student);
  const notes=$('reportNotes')?.value?.trim()||'';
  setDraftForCircle(date,cid,{hours,studentIds,notes});
  card.dataset.saved='1';
  const b=card.querySelector('.save-circle-draft');
  if(b){b.textContent='✓ تم حفظ الحلقة';b.disabled=true;setTimeout(()=>{b.disabled=false;b.textContent='💾 حفظ الحلقة'},900)}
  const st=card.querySelector('.draft-status');if(st)st.textContent='محفوظ داخل التطبيق — جاهز للإرسال';
  return true;
}

async function renderAllCircleReports(){
  const box=$('allCircleReports');
  if(!circles.length){box.innerHTML=empty('لا توجد حلقات.');return}
  const date=$('reportDate')?.value||localDate();
  box.innerHTML=empty('جاري تحميل الحلقات...');
  const drafts=readReportDrafts(date);
  const parts=[];
  for(const c of circles){
    const r=await sb.from('students').select('id,name').eq('circle_id',c.id).eq('active',true).order('name');
    if(r.error){box.innerHTML=empty(r.error.message);return}
    const list=r.data||[],d=drafts[c.id]||null;
    const checked=new Set(d?.studentIds||[]);
    parts.push(`<div class="report-card ${d?'draft-saved':''}" data-circle="${c.id}" data-saved="${d?'1':'0'}">
      <div class="report-card-head"><h3>📚 ${esc(c.name)}</h3><span class="draft-status">${d?'محفوظ داخل التطبيق — جاهز للإرسال':'لم يتم حفظ هذه الحلقة بعد'}</span></div>
      <label>ساعات الحلقة</label><input class="circle-hours" type="number" min="0" step="0.5" value="${d?esc(d.hours):''}" placeholder="مثال: 2">
      <div class="attendance-box"><b>الحضور:</b>${list.length?list.map(s=>`<label class="att"><input type="checkbox" class="circle-att" data-student="${s.id}" ${checked.has(s.id)?'checked':''}><span>${esc(s.name)}</span></label>`).join(''):'<p class="muted">لا يوجد طلاب.</p>'}</div>
      <button type="button" class="primary wide save-circle-draft">💾 حفظ الحلقة</button>
    </div>`)
  }
  box.innerHTML=parts.join('');
  box.querySelectorAll('.report-card').forEach(card=>{
    card.querySelector('.save-circle-draft')?.addEventListener('click',()=>saveCircleDraft(card));
  });
}

async function saveAttendance(cid,date,studentIds){
  for(const student_id of studentIds){
    const ctx={circle_id:cid,student_id,teacher_id:user?.id,date,status:'present'};
    const broad={circle_id:cid,student_id,teacher_id:user?.id,date,attendance_date:date,status:'present'};
    const err=await adaptiveInsert('attendance',broad,ctx);
    if(err && !/duplicate|already exists|unique/i.test(err.message)) return err;
  }
  return null;
}

async function saveOrUpdateReport(cid,date,hours,notes){
  const profile=profileRequired();
  // Find the existing report without maybeSingle(), so an old duplicate row
  // cannot block sending the current report.
  let existing=await sb.from('daily_reports').select('id').eq('circle_id',cid)
    .eq('teacher_profile_id',profile).eq('report_date',date).order('created_at',{ascending:true}).limit(1);
  if(existing.error && /column .*report_date.*does not exist|schema cache/i.test(existing.error.message)){
    existing=await sb.from('daily_reports').select('id').eq('circle_id',cid)
      .eq('teacher_profile_id',profile).eq('date',date).order('created_at',{ascending:true}).limit(1);
  }
  if(existing.error)return existing.error;
  const existingId=existing.data?.[0]?.id||null;
  const updatePayload={hours,notes,teacher_name:teacherName};
  if(existingId){
    return await adaptiveUpdate('daily_reports',existingId,updatePayload,
      {circle_id:cid,date,hours,notes,teacher_id:user.id,teacher_profile_id:profile,teacher_name:teacherName});
  }
  const payload={teacher_id:user.id,teacher_profile_id:profile,teacher_name:teacherName,circle_id:cid,report_date:date,date:date,hours,notes};
  return await adaptiveInsert('daily_reports',payload,
    {teacher_id:user.id,teacher_profile_id:profile,teacher_name:teacherName,circle_id:cid,date,report_date:date,hours,notes});
}

async function sendReport(e){
  if(e){e.preventDefault();e.stopPropagation()}
  try{
    const b=$('sendReport'),date=$('reportDate')?.value;
    if(!date){msg('reportMsg','اختر التاريخ.');return}
    if(!user){msg('reportMsg','جلسة الدخول انتهت. سجّل الدخول مرة أخرى.');return}
    const drafts=readReportDrafts(date), entries=Object.values(drafts);
    if(!entries.length){msg('reportMsg','احفظ كل حلقة تريد إرسالها أولًا، ثم اضغط إرسال التقرير.');return}
    if(b)b.disabled=true;msg('reportMsg','جاري إرسال التقارير المحفوظة...');
    for(let n=0;n<entries.length;n++){
      const d=entries[n];
      msg('reportMsg',`جاري إرسال الحلقة ${n+1} من ${entries.length}...`);
      const ae=await saveAttendance(d.circle_id,date,d.studentIds||[]);if(ae)throw new Error('الحضور: '+ae.message);
      const re=await saveOrUpdateReport(d.circle_id,date,Number(d.hours||0),d.notes||'');if(re)throw new Error('التقرير: '+re.message);
    }
    clearReportDrafts(date);
    msg('reportMsg','تم إرسال جميع الحلقات المحفوظة للمدير بنجاح.',true);
    await renderAllCircleReports();
  }catch(e2){console.error(APP_DIAG_VERSION,e2);msg('reportMsg','لم يتم الإرسال: '+(e2?.message||String(e2)))}
  finally{const b=$('sendReport');if(b)b.disabled=false}
}

function bind(){
  SURAH_DATA.forEach((s,i)=>$('surah').insertAdjacentHTML('beforeend',`<option value="${i}">${i+1} — ${s[0]}</option>`));
  $('surah').onchange=updateAyahLimit;
  $('loginBtn').onclick=login;
  $('logout').onclick=async()=>{await sb.auth.signOut();location.reload()};
  $('addCircle').addEventListener('click',addCircle);$('addStudent').addEventListener('click',addStudent);const delAll=$('deleteAllData');if(delAll){delAll.onclick=deleteAllTeacherData;}$('saveLesson').addEventListener('click',saveLesson);$('sendReport').addEventListener('click',sendReport);$('reportDate').addEventListener('change',async()=>{await renderAllCircleReports()});
}
async function init(){
  bind();
  loadTeacherName();
  try{
    const r=await sb.auth.getSession();
    if(r.error)throw r.error;
    user=r.data?.session?.user||null;
    if(user) await checkRole(); else {$('login').classList.remove('hidden');$('app').classList.add('hidden')}
  }catch(e){console.error(e);msg('loginMsg','تعذر الاتصال بالخادم: '+(e?.message||e))}
}
sb.auth.onAuthStateChange((event,session)=>{if(event==='SIGNED_OUT'){user=null;$('app').classList.add('hidden');$('login').classList.remove('hidden')}});
init();
