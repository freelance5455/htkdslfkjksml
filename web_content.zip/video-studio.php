<?php require_once __DIR__.'/app/bootstrap.php'; workspace_legacy_redirect('video/'); require_once __DIR__.'/app/platform.php'; require_once __DIR__.'/app/auth.php'; require_once __DIR__.'/app/magichour.php'; require_once __DIR__.'/app/credits.php'; $user=auth_require_user(); $videoCreditPrice=billing_price('video')??50; $lipSyncCreditPrice=max(1,(int)mh_setting('credit_price','30')); $initialMode=(($_GET['mode']??'')==='lipsync')?'lipsync':'transform'; $pageTitle=$initialMode==='lipsync'?'AI Lip Sync':'Video Edit Studio'; $model25Enabled=platform_model_enabled('lucy-2.5'); $model26Enabled=platform_model_enabled('lucy-2.6'); $mhEnabled=mh_ready(); $mhModes=mh_modes(); $mhRequestKey=bin2hex(random_bytes(16)); $presetPrompt=trim((string)($_GET['preset']??'')); if(strlen($presetPrompt)>2000)$presetPrompt=substr($presetPrompt,0,2000); require __DIR__.'/app/platform_header.php'; ?>
<section class="workspace-intro"><div><div class="eyebrow"><span class="eyebrow-line"></span> <?=$initialMode==='lipsync'?'AUDIO + VIDEO':'VIDEO EDITING'?></div><h1><?=$initialMode==='lipsync'?'AI Lip Sync <em>Studio.</em>':'Video <em>Edit Studio.</em>'?></h1><p class="intro-copy"><?=$initialMode==='lipsync'?'Synchronize replacement audio with your source video and track the confirmed render.':'Transform videos with Decart or synchronize speech with Magic Hour.'?></p></div><span class="studio-tag">DECart · MAGIC HOUR</span></section>
<div class="video-mode-switch" role="tablist" aria-label="Video editing mode">
 <button type="button" class="video-mode-tab <?=$initialMode==='transform'?'is-active':''?>" role="tab" aria-selected="<?=$initialMode==='transform'?'true':'false'?>" data-video-mode="transform">Video Transform <small>Decart</small></button>
 <button type="button" class="video-mode-tab <?=$initialMode==='lipsync'?'is-active':''?>" role="tab" aria-selected="<?=$initialMode==='lipsync'?'true':'false'?>" data-video-mode="lipsync" <?=$mhEnabled?'':'disabled'?>>AI Lip Sync <small>Magic Hour</small></button>
</div>
<?php if(!$mhEnabled): ?><div class="workspace-note">AI Lip Sync is currently unavailable. An administrator must configure the Magic Hour API key and enable the feature.</div><?php endif; ?>
<div class="workspace-note"><strong>Workspace pricing:</strong> Video transformation <?=number_format($videoCreditPrice)?> credits per generation · Lip Sync <?=number_format($lipSyncCreditPrice)?> credits per generation. The upload is submitted as a provider job. Status is reported from the provider; no invented progress percentage is shown.</div>
<form id="videoForm" class="creative-form" enctype="multipart/form-data" data-video-mode-panel="transform" <?=$initialMode==='transform'?'':'hidden'?> >
<section class="panel media-panel"><div class="section-heading"><div><span class="section-index">01</span><h2>Source media</h2></div><span class="section-hint">Tall frames · side by side</span></div>
<div class="media-pair">
<label class="media-card"><span class="media-label"><b>A</b> SOURCE VIDEO</span><div class="media-preview portrait-preview"><video id="videoSourcePreview" muted playsinline controls hidden></video><span class="preview-empty" id="videoSourceEmpty"><i>▶</i><strong>Choose source video</strong><small>MP4 · WebM · MOV</small></span></div><span class="media-action">＋ Upload video</span><input id="videoSource" name="data" type="file" accept="video/mp4,video/webm,video/quicktime" required></label>
<label class="media-card"><span class="media-label"><b>B</b> REFERENCE IMAGE <small>OPTIONAL</small></span><div class="media-preview portrait-preview"><img id="videoReferencePreview" alt="Video reference preview" hidden><span class="preview-empty" id="videoReferenceEmpty"><i>＋</i><strong>Add reference</strong><small>Optional visual guidance</small></span></div><span class="media-action">＋ Upload reference</span><input id="videoReference" name="reference_image" type="file" accept="image/jpeg,image/png,image/webp"></label>
</div></section>
<section class="panel prompt-library-panel" data-prompt-library="video" data-target="videoPrompt">
  <div class="section-heading"><div><span class="section-index">PROMPTS</span><h2>Prompt library</h2></div><span class="section-hint">Tap a card to insert</span></div>
  <div class="prompt-library-tools">
    <label class="prompt-search-wrap"><span class="sr-only">Search prompts</span><input class="prompt-search" type="search" placeholder="Search prompts…" autocomplete="off"></label>
    <div class="prompt-category-list" role="group" aria-label="Filter prompt categories"></div>
  </div>
  <div class="prompt-library-row" role="list" aria-label="Ready-to-use editing prompts">
    <div class="prompt-library-loading">Loading prompt collection…</div>
  </div>
  <p class="prompt-library-footnote">Prompts are starting points, not separate model features. Use only source and reference media you own or have permission to edit. Identity changes and virtual try-on are intended for consenting adults.</p>
  <div class="prompt-library-feedback" aria-live="polite"></div>
</section>
<section class="panel compact-setup"><div class="section-heading"><div><span class="section-index">02</span><h2>Quick setup</h2></div><span class="section-hint">Batch processing</span></div>
<div class="model-choice-row" role="group" aria-label="Video model"><label><input type="radio" name="model" value="lucy-2.5" <?=$model25Enabled && !$model26Enabled?'checked':''?> <?=$model25Enabled?'':'disabled'?>><span>Lucy 2.5 <?=$model25Enabled?'':'(disabled)'?></span></label><label><input type="radio" name="model" value="lucy-2.6" <?=$model26Enabled?'checked':''?> <?=$model26Enabled?'':'disabled'?>><span>Lucy 2.6 <?=$model26Enabled?'':'(disabled)'?></span></label></div>
<label class="field-label" for="videoPrompt">EDITING PROMPT</label><textarea id="videoPrompt" name="prompt" rows="3" maxlength="2000" placeholder="Describe the changes you want in the video..."><?=htmlspecialchars($presetPrompt,ENT_QUOTES,'UTF-8')?></textarea>
<div class="setup-grid"><label><span class="field-label">OUTPUT RESOLUTION</span><select name="resolution"><option value="720p">720p · supported</option></select></label><label><span class="field-label">RANDOM SEED <small>OPTIONAL</small></span><input name="seed" type="number" min="0" max="4294967295" placeholder="Random"></label></div>
<label class="switch-row"><input type="checkbox" name="enhance_prompt" value="true" checked><span>Enhance prompt</span></label>
<label class="switch-row"><input type="checkbox" name="self_anchor" value="true" checked><span>Self-anchor (Lucy 2.5/2.6 job option)</span></label>
<button class="primary-button generate-button" id="videoGenerate" type="submit" <?=($model25Enabled||$model26Enabled)?'':'disabled'?>>Submit video edit <span>↗</span></button><div class="form-status" id="videoStatus" role="status" aria-live="polite"><?=($model25Enabled||$model26Enabled)?'Ready when your source video is selected.':'Video models are currently disabled by the administrator.'?></div>
</section></form>
<form id="magicHourForm" class="creative-form" enctype="multipart/form-data" data-video-mode-panel="lipsync" <?=$initialMode==='lipsync'?'':'hidden'?> >
<input type="hidden" name="request_key" value="<?=htmlspecialchars($mhRequestKey,ENT_QUOTES,'UTF-8')?>">
<section class="panel media-panel">
 <div class="section-heading"><div><span class="section-index">01</span><h2>Lip Sync source media</h2></div><span class="section-hint">Video + replacement audio</span></div>
 <div class="media-pair">
  <label class="media-card"><span class="media-label"><b>A</b> SOURCE VIDEO</span><div class="media-preview portrait-preview"><video id="mhVideoPreview" muted playsinline controls hidden></video><span class="preview-empty" id="mhVideoEmpty"><i>▶</i><strong>Choose source video</strong><small>MP4 · M4V · MOV · WebM</small></span></div><span class="media-action">＋ Upload video</span><input id="mhVideoFile" name="video" type="file" accept=".mp4,.m4v,.mov,.webm,video/mp4,video/quicktime,video/webm" required></label>
  <label class="media-card"><span class="media-label"><b>B</b> REPLACEMENT AUDIO</span><div class="media-preview portrait-preview"><div class="preview-empty" id="mhAudioEmpty"><i>♫</i><strong>Choose audio track</strong><small>MP3 · WAV · AAC · M4A · OGG and supported formats</small></div><audio id="mhAudioPreview" controls hidden style="width:92%"></audio></div><span class="media-action">＋ Upload audio</span><input id="mhAudioFile" name="audio" type="file" accept=".mp3,.wav,.aac,.flac,.m4a,.opus,.ogg,.oga,.aiff,.amr,.weba,.webm,audio/*" required></label>
 </div>
</section>
<section class="panel compact-setup">
 <div class="section-heading"><div><span class="section-index">02</span><h2>Generation settings</h2></div><span class="section-hint">Magic Hour API</span></div>
 <label class="field-label" for="mhProjectName">PROJECT NAME</label><input id="mhProjectName" name="name" maxlength="120" placeholder="My lip sync project">
 <div class="setup-grid">
  <label><span class="field-label">GENERATION MODE</span><select name="mode" required><?php foreach($mhModes as $mode): ?><option value="<?=$e=htmlspecialchars($mode,ENT_QUOTES,'UTF-8')?>"><?=htmlspecialchars(ucfirst(str_replace(['-','_'],' ',$mode)),ENT_QUOTES,'UTF-8')?></option><?php endforeach; ?></select></label>
  <label><span class="field-label">MAXIMUM FPS</span><select name="fps"><option value="12">12 FPS</option><option value="24">24 FPS</option><option value="30">30 FPS</option><option value="60">60 FPS</option></select></label>
  <label><span class="field-label">START (SECONDS)</span><input name="start_seconds" type="number" min="0" max="3599" step="0.1" value="0" required></label>
  <label><span class="field-label">END (SECONDS)</span><input name="end_seconds" type="number" min="0.1" max="3600" step="0.1" value="5" required></label>
 </div>
 <p class="workspace-note">Use only videos and audio you own or have permission to use. Obtain the depicted person’s consent before creating or sharing a lip-synced result.</p>
 <div class="mh-credit-note">Estimated Anonymoux charge: <strong><?=number_format(max(1,(int)mh_setting('credit_price','30')))?></strong> credits per generation. Final charge is confirmed before submission.</div>
 <button class="primary-button generate-button" id="mhGenerate" type="submit" <?=$mhEnabled?'':'disabled'?>>Generate Lip Sync <span>↗</span></button>
 <div class="form-status" id="mhStatus" role="status" aria-live="polite"><?=$mhEnabled?'Upload a video and replacement audio to begin.':'Magic Hour is not configured.'?></div>
</section>
</form>
<section class="panel result-panel" data-video-mode-panel="lipsync" <?=$initialMode==='lipsync'?'':'hidden'?> >
 <div class="section-heading"><div><span class="section-index">03</span><h2>Lip Sync result</h2></div><span class="section-hint">Magic Hour confirmed output</span></div>
 <div class="job-state" id="mhJobState" hidden><span class="job-indicator"></span><strong id="mhJobLabel">Submitted</strong><small id="mhJobDetail">Waiting for provider status.</small></div>
 <div class="result-stage video-result-stage"><div class="result-empty" id="mhResultEmpty"><span>♫</span><strong>Your synchronized video appears here</strong><small>Processing status is retrieved from Magic Hour. No progress percentage is invented.</small></div><video id="mhResultVideo" controls playsinline hidden></video></div>
 <div class="result-actions" id="mhResultActions" hidden><a class="outline-button" id="mhDownload" href="#" download>Download synchronized video</a><a class="outline-button" href="history.php">View shared history</a></div>
</section>
<section class="panel result-panel" data-video-mode-panel="transform"><div class="section-heading"><div><span class="section-index">03</span><h2>Generated result</h2></div><span class="section-hint" id="videoResultMeta">Provider-confirmed result</span></div>
<div class="job-state" id="videoJobState" hidden><span class="job-indicator"></span><strong id="videoJobLabel">Job submitted</strong><small id="videoJobDetail">Waiting for provider status.</small></div>
<div class="result-stage video-result-stage" id="videoResultStage"><div class="result-empty"><span>▶</span><strong>Your edited video appears here</strong><small>The result is retrieved only after provider completion.</small></div><video id="videoResult" controls playsinline hidden></video></div>
<div class="result-actions" id="videoResultActions" hidden><a class="outline-button" id="videoDownload" href="#" download>Download edited video</a></div></section>
<?php require __DIR__.'/app/platform_footer.php'; ?>
