MR,KHORASANI — سورس Android نسخه 2.10.0

این ZIP سورس پروژه Android Studio/Gradle و دارایی‌های وب بسته‌بندی‌شده را شامل می‌شود؛ APK آماده نصب نیست.

پیش‌نیاز ساخت:
- JDK 17
- Android SDK Platform 35 و Build Tools 35.0.0
- Gradle 8.9

روش ساخت:
1) پوشه android را در Android Studio باز کنید یا وارد آن شوید.
2) دستور gradle --no-daemon assembleDebug را اجرا کنید.
3) خروجی: android/app/build/outputs/apk/debug/app-debug.apk

ورود Android به صفحه ورود سازمانی است و مسیر مهمان در برنامه native غیرفعال است.
