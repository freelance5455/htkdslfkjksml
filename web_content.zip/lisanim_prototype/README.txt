Lisanım - Prototype 0.1

This ZIP is a browser-based prototype, not a native Android APK or a ready-to-build Android Studio project.

Included: responsive Arabic home page, sample lessons, flashcards, sample quiz, demo AI tutor page, and local progress storage.

To try it: extract the ZIP and open index.html in a browser, or host the folder on a static web host. Speech uses the device/browser speechSynthesis engine if available; Turkish voice availability depends on the device and may require installing a Turkish voice. This is not a bundled AI voice.

Not included yet: real AI chat, cloud sync, accounts, subscriptions/payments, packaged offline audio, complete A1-C2 curriculum, or native APK packaging. These need further implementation and testing.
