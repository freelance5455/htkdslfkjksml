const audio = document.getElementById('audio');
const fileInput = document.getElementById('file-input');
const list = document.getElementById('track-list');
const search = document.getElementById('search');
let tracks = [];
let current = -1;
let view = 'all';

function render() {
  const query = search.value.trim().toLowerCase();
  const shown = tracks.map((t,i)=>({...t,index:i})).filter(t =>
    (view !== 'favorites' || t.liked) &&
    (t.name.toLowerCase().includes(query) || t.artist.toLowerCase().includes(query))
  );
  document.getElementById('list-title').textContent = view === 'favorites' ? '我喜欢' : '最近添加';
  if (!shown.length) {
    list.innerHTML = `<div class="empty"><div class="empty-icon">♫</div><b>${tracks.length ? '没有找到歌曲' : '这里还没有歌曲'}</b><p>${tracks.length ? '试试其他关键词，或切换到本地音乐。' : '点击「导入音乐」，选择手机里的音频文件即可播放。'}</p></div>`;
    return;
  }
  list.innerHTML = shown.map(t=>`<div class="track">
    <div class="track-cover" data-play="${t.index}">♫</div>
    <div class="track-meta" data-play="${t.index}"><b>${escapeHtml(t.name)}</b><small>${escapeHtml(t.artist)}</small></div>
    <button class="${t.liked?'liked':''}" data-like="${t.index}" aria-label="收藏">${t.liked?'♥':'♡'}</button>
    <button data-play="${t.index}" aria-label="播放">▶</button>
  </div>`).join('');
}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function play(index){
  const t=tracks[index]; if(!t)return;
  current=index; audio.src=t.url; audio.play().catch(()=>{});
  document.getElementById('now-title').textContent=t.name;
  document.getElementById('now-artist').textContent=t.artist;
  document.getElementById('play-toggle').textContent='Ⅱ';
}
fileInput.addEventListener('change',e=>{
  [...e.target.files].filter(f=>f.type.startsWith('audio/')).forEach(file=>{
    tracks.push({name:file.name.replace(/\.[^.]+$/,''),artist:'本地音频',url:URL.createObjectURL(file),liked:false});
  });
  render(); fileInput.value='';
});
list.addEventListener('click',e=>{
  const like=e.target.closest('[data-like]'); const playBtn=e.target.closest('[data-play]');
  if(like){const i=Number(like.dataset.like);tracks[i].liked=!tracks[i].liked;render();}
  if(playBtn)play(Number(playBtn.dataset.play));
});
document.getElementById('play-toggle').addEventListener('click',()=>{
  if(current<0){if(tracks.length)play(0);return;}
  if(audio.paused){audio.play();document.getElementById('play-toggle').textContent='Ⅱ';}
  else{audio.pause();document.getElementById('play-toggle').textContent='▶';}
});
audio.addEventListener('ended',()=>{if(current+1<tracks.length)play(current+1);else document.getElementById('play-toggle').textContent='▶';});
search.addEventListener('input',render);
function switchView(next){
  view=next;
  document.querySelectorAll('[data-view]').forEach(el=>el.classList.toggle('selected',el.dataset.view===next));
  document.querySelectorAll('.quick-card').forEach(el=>el.classList.toggle('active',el.dataset.view===next));
  render();
}
document.querySelectorAll('[data-view]').forEach(el=>el.addEventListener('click',()=>switchView(el.dataset.view)));
document.getElementById('nav-import').addEventListener('click',()=>fileInput.click());
render();
