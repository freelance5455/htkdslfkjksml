# BLOOM Fitness Android project

This is an Android Studio project wrapping the BLOOM responsive HTML app in a native Android WebView. It includes the app as a local asset, so the core app can run offline. Browser-local data is stored in the app's WebView storage and does not automatically sync with the desktop browser.

## Build an APK
1. Install Android Studio on your PC.
2. Open Android Studio and choose **Open**, then select this `BLOOM-Android` folder.
3. Allow Gradle sync and install any requested Android SDK platform (API 35) and build tools.
4. From the menu select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. The debug APK will be created at `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer that APK to your Android phone and install it. If Android asks, allow installation from that file manager.

Package name: `com.bloom.fit`
App name: `BLOOM Fitness`
Minimum Android version: Android 7.0 (API 24)

Note: This folder is source code, not a precompiled APK. An Android SDK/Gradle build environment is required to produce the APK.
