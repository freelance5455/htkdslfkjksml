import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = {
  appId: 'com.mtmfoundation.app',
  appName: 'MTM Foundation',
  webDir: 'dist',
  android: { allowMixedContent: false },
  plugins: {
    SplashScreen: { launchShowDuration: 1500, backgroundColor: '#153d28', showSpinner: false },
    Keyboard: { resize: 'body' }
  }
};
export default config;
