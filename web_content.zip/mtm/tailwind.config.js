export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: { extend: { colors: {
    forest: { 50:'#f0f6f2', 100:'#dcebe1', 500:'#2f6b4a', 700:'#1d4d33', 800:'#153d28', 900:'#0e2c1c' },
    cream: { 50:'#fdfbf5', 100:'#f8f3e6', 200:'#efe6cf' },
    gold: { 400:'#d4b45a', 500:'#c19a3a', 600:'#a37f26' } } } },
  plugins: []
};
