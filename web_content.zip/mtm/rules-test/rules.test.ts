// Run: npm run test:rules   (needs Java + firebase-tools; uses the local Firestore emulator)
import { readFileSync } from 'fs';
import { initializeTestEnvironment, assertFails, assertSucceeds, RulesTestEnvironment } from '@firebase/rules-unit-testing';
import { doc, getDoc, setDoc, updateDoc, deleteDoc, serverTimestamp } from 'firebase/firestore';
import { beforeAll, afterAll, beforeEach, describe, it } from 'vitest';

const OWNER = 'owner-uid';
let env: RulesTestEnvironment;

beforeAll(async () => {
  const rules = readFileSync('firestore.rules', 'utf8').replace('REPLACE_WITH_OWNER_UID', OWNER);
  env = await initializeTestEnvironment({ projectId: 'mtm-test', firestore: { rules } });
});
afterAll(() => env.cleanup());
beforeEach(async () => {
  await env.clearFirestore();
  await env.withSecurityRulesDisabled(async (c) => {
    const db = c.firestore();
    await setDoc(doc(db, 'admin_access/fin'), { role: 'finance_admin' });
    await setDoc(doc(db, 'admin_access/con'), { role: 'content_admin' });
    await setDoc(doc(db, 'admin_access/sup'), { role: 'super_admin' });
    await setDoc(doc(db, 'users/m1'), { uid: 'm1', fullName: 'A', phone: '', email: 'a@x.com', memberId: 'MTM-M1', role: 'member', status: 'active', language: 'en', photoUrl: '' });
    await setDoc(doc(db, 'users/m2'), { uid: 'm2', fullName: 'B', phone: '', email: 'b@x.com', memberId: 'MTM-M2', role: 'member', status: 'active', language: 'en', photoUrl: '' });
    await setDoc(doc(db, 'contributions/m1_2026-09'), { uid: 'm1', period: '2026-09', amount: 100, status: 'paid' });
    await setDoc(doc(db, 'contributions/m2_2026-09'), { uid: 'm2', period: '2026-09', amount: 100, status: 'paid' });
    await setDoc(doc(db, 'financial_transactions/t1'), { type: 'income', amount: 100 });
    await setDoc(doc(db, 'announcements/draft'), { status: 'draft', authorId: 'con' });
    await setDoc(doc(db, 'announcements/pub'), { status: 'published', authorId: 'con' });
  });
});
const as = (uid: string) => env.authenticatedContext(uid, { email: uid + '@x.com' }).firestore();

describe('new member', () => {
  it('can create own profile as member', async () => {
    await assertSucceeds(setDoc(doc(as('new1'), 'users/new1'), { uid: 'new1', fullName: 'N', phone: '1', email: 'new1@x.com', memberId: 'MTM-NEW1', role: 'member', status: 'active', language: 'en', photoUrl: '', createdAt: serverTimestamp(), updatedAt: serverTimestamp() }));
  });
  it('cannot register as admin', async () => {
    await assertFails(setDoc(doc(as('new2'), 'users/new2'), { uid: 'new2', fullName: 'N', phone: '1', email: 'new2@x.com', memberId: 'X', role: 'owner', status: 'active', language: 'en', photoUrl: '', createdAt: serverTimestamp(), updatedAt: serverTimestamp() }));
  });
  it('cannot self-appoint', async () => {
    await assertFails(setDoc(doc(as('new3'), 'admin_access/new3'), { role: 'super_admin' }));
  });
});

describe('ordinary member', () => {
  it('reads own contribution but not others', async () => {
    await assertSucceeds(getDoc(doc(as('m1'), 'contributions/m1_2026-09')));
    await assertFails(getDoc(doc(as('m1'), 'contributions/m2_2026-09')));
  });
  it('cannot mark paid / edit contributions', async () => {
    await assertFails(setDoc(doc(as('m1'), 'contributions/m1_2026-10'), { uid: 'm1', period: '2026-10', amount: 100, status: 'paid', recordedBy: 'm1', createdAt: serverTimestamp() }));
    await assertFails(updateDoc(doc(as('m1'), 'contributions/m1_2026-09'), { amount: 1 }));
  });
  it('cannot read finance, drafts, audit logs or others\' profiles', async () => {
    await assertFails(getDoc(doc(as('m1'), 'financial_transactions/t1')));
    await assertFails(getDoc(doc(as('m1'), 'announcements/draft')));
    await assertFails(getDoc(doc(as('m1'), 'audit_logs/x')));
    await assertFails(getDoc(doc(as('m1'), 'users/m2')));
  });
  it('reads published announcement', async () => {
    await assertSucceeds(getDoc(doc(as('m1'), 'announcements/pub')));
  });
  it('can edit own name but not status/role', async () => {
    await assertSucceeds(updateDoc(doc(as('m1'), 'users/m1'), { fullName: 'New', updatedAt: serverTimestamp() }));
    await assertFails(updateDoc(doc(as('m1'), 'users/m1'), { status: 'suspended' }));
    await assertFails(updateDoc(doc(as('m1'), 'users/m1'), { role: 'owner' }));
  });
  it('cannot change settings', async () => {
    await assertFails(setDoc(doc(as('m1'), 'foundation_settings/general'), { monthlyAmount: 1 }));
  });
});

describe('finance admin', () => {
  it('records contribution and transactions', async () => {
    await assertSucceeds(setDoc(doc(as('fin'), 'contributions/m1_2026-10'), { uid: 'm1', period: '2026-10', amount: 100, status: 'paid', recordedBy: 'fin', createdAt: serverTimestamp() }));
    await assertSucceeds(setDoc(doc(as('fin'), 'financial_transactions/t2'), { type: 'expense', amount: 50, createdBy: 'fin', createdAt: serverTimestamp() }));
    await assertSucceeds(getDoc(doc(as('fin'), 'financial_transactions/t1')));
  });
  it('rejects wrong doc id (duplicate protection)', async () => {
    await assertFails(setDoc(doc(as('fin'), 'contributions/random'), { uid: 'm1', period: '2026-10', amount: 100, status: 'paid', recordedBy: 'fin', createdAt: serverTimestamp() }));
  });
  it('cannot publish announcements, appoint admins or change settings', async () => {
    await assertFails(setDoc(doc(as('fin'), 'announcements/a'), { status: 'published', authorId: 'fin' }));
    await assertFails(setDoc(doc(as('fin'), 'admin_access/x'), { role: 'super_admin' }));
    await assertFails(setDoc(doc(as('fin'), 'foundation_settings/general'), { monthlyAmount: 1 }));
  });
});

describe('content admin', () => {
  it('manages announcements', async () => {
    await assertSucceeds(setDoc(doc(as('con'), 'announcements/a'), { status: 'draft', authorId: 'con' }));
    await assertSucceeds(getDoc(doc(as('con'), 'announcements/draft')));
  });
  it('cannot touch finance', async () => {
    await assertFails(getDoc(doc(as('con'), 'financial_transactions/t1')));
    await assertFails(getDoc(doc(as('con'), 'contributions/m1_2026-09')));
  });
});

describe('super admin', () => {
  it('manages members, committee, finance, announcements', async () => {
    await assertSucceeds(updateDoc(doc(as('sup'), 'users/m1'), { position: 'Sadr', updatedAt: serverTimestamp() }));
    await assertSucceeds(setDoc(doc(as('sup'), 'committee_members/c1'), { name: 'X', position: 'amir' }));
    await assertSucceeds(getDoc(doc(as('sup'), 'financial_transactions/t1')));
  });
  it('cannot appoint admins or change settings', async () => {
    await assertFails(setDoc(doc(as('sup'), 'admin_access/m1'), { role: 'finance_admin' }));
    await assertFails(setDoc(doc(as('sup'), 'foundation_settings/general'), { monthlyAmount: 1 }));
  });
});

describe('primary owner', () => {
  it('appoints and removes admins', async () => {
    await assertSucceeds(setDoc(doc(as(OWNER), 'admin_access/m1'), { role: 'finance_admin' }));
    await assertSucceeds(deleteDoc(doc(as(OWNER), 'admin_access/m1')));
  });
  it('owner doc cannot be created as admin by anyone', async () => {
    await assertFails(setDoc(doc(as(OWNER), 'admin_access/' + OWNER), { role: 'content_admin' }));
    await assertFails(setDoc(doc(as('sup'), 'admin_access/' + OWNER), { role: 'content_admin' }));
  });
  it('edits settings', async () => {
    await assertSucceeds(setDoc(doc(as(OWNER), 'foundation_settings/general'), { monthlyAmount: 100 }));
  });
  it('audit logs are append-only', async () => {
    await assertSucceeds(setDoc(doc(as(OWNER), 'audit_logs/l1'), { uid: OWNER, action: 'x', ref: '', detail: '', createdAt: serverTimestamp() }));
    await assertFails(updateDoc(doc(as(OWNER), 'audit_logs/l1'), { action: 'y' }));
    await assertFails(deleteDoc(doc(as(OWNER), 'audit_logs/l1')));
  });
});
