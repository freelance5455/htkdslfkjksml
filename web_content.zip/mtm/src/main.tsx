import React from 'react';
import ReactDOM from 'react-dom/client';
import { HashRouter } from 'react-router-dom';
import './index.css';
import { LangProvider } from './lib/i18n';
import { SessionProvider } from './lib/session';
import { UiProvider } from './components/ui';
import App from './App';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <LangProvider>
      <UiProvider>
        <SessionProvider>
          <HashRouter><App /></HashRouter>
        </SessionProvider>
      </UiProvider>
    </LangProvider>
  </React.StrictMode>
);
