import { FormEvent, useState } from 'react';
import { Link } from 'react-router-dom';
import { createUserWithEmailAndPassword, sendPasswordResetEmail, signInWithEmailAndPassword, signOut, updateProfile } from 'firebase/auth';
import { collection, doc, serverTimestamp, writeBatch } from 'firebase/firestore';
import { auth, db } from '../lib/firebase';
import { useLang } from '../lib/i18n';
import { memberIdFor } from '../lib/session';
import { cleanPhone } from '../lib/util';
import { Btn, Field, LangPicker } from '../components/ui';
import { Logo } from '../components/Logo';

const authErr = (code: string, t: (k: string) => string) => {
  const map: Record<string, string> = {
    'auth/email-already-in-use': 'err.emailInUse', 'auth/weak-password': 'err.weakPassword', 'auth/invalid-email': 'err.invalidEmail',
    'auth/invalid-credential': 'err.badLogin', 'auth/wrong-password': 'err.badLogin', 'auth/user-not-found': 'err.badLogin',
    'auth/network-request-failed': 'err.offline', 'auth/too-many-requests': 'err.tooMany'
  };
  return t(map[code] || 'err.generic');
};
const codeOf = (e: unknown) => (e as { code?: string })?.code || '';

function Shell({ children }: { children: React.ReactNode }) {
  const { t } = useLang();
  return (
    <div className="min-h-screen bg-gradient-to-b from-forest-900 to-forest-700 flex flex-col items-center px-4" style={{ paddingTop: 'calc(2rem + var(--safe-top))', paddingBottom: 'calc(2rem + var(--safe-bottom))' }}>
      <Logo size={96} />
      <h1 className="text-white text-xl mt-3 font-semibold">MTM Foundation</h1>
      <div className="arabic-original text-gold-400" style={{ fontSize: 18 }}>مؤسسة الطلاب المسلمين</div>
      <div className="text-white/70 text-xs mb-1">Mu'assasatut Tullab Al Muslimeen (MTM)</div>
      <div className="arabic-original text-white/80 mb-4" style={{ fontSize: 15 }}>طلاب اليوم، مستقبل القوم</div>
      <div className="bg-cream-50 rounded-3xl w-full max-w-sm p-5 shadow-xl">
        <div className="mb-4"><div className="text-xs text-gray-500 mb-1">{t('lang.choose')}</div><LangPicker /></div>
        {children}
      </div>
    </div>
  );
}

export function Login({ logoutOnly }: { logoutOnly?: boolean }) {
  const { t } = useLang();
  const [email, setEmail] = useState(''); const [pw, setPw] = useState('');
  const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  if (logoutOnly) return <Btn className="mt-4" onClick={() => signOut(auth)}>{t('auth.logout')}</Btn>;
  const submit = async (e: FormEvent) => {
    e.preventDefault(); setErr(''); setBusy(true);
    try { await signInWithEmailAndPassword(auth, email.trim(), pw); } catch (x) { setErr(authErr(codeOf(x), t)); }
    setBusy(false);
  };
  return (
    <Shell>
      <form onSubmit={submit}>
        <Field label={t('auth.email')} type="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} required dir="ltr" />
        <Field label={t('auth.password')} type="password" autoComplete="current-password" value={pw} onChange={(e) => setPw(e.target.value)} required dir="ltr" />
        {err && <p className="text-red-600 text-sm mb-3">{err}</p>}
        <Btn full disabled={busy}>{busy ? t('common.wait') : t('auth.login')}</Btn>
      </form>
      <div className="flex justify-between text-sm mt-4 text-forest-700">
        <Link to="/register">{t('auth.createAccount')}</Link><Link to="/reset">{t('auth.forgot')}</Link>
      </div>
    </Shell>
  );
}

export function Register() {
  const { t, lang } = useLang();
  const [f, setF] = useState({ fullName: '', phone: '', email: '', password: '' });
  const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement>) => setF({ ...f, [k]: e.target.value });
  const submit = async (e: FormEvent) => {
    e.preventDefault(); setErr('');
    if (f.fullName.trim().length < 2) return setErr(t('err.name'));
    if (cleanPhone(f.phone).length < 10) return setErr(t('err.phone'));
    setBusy(true);
    try {
      const cred = await createUserWithEmailAndPassword(auth, f.email.trim(), f.password);
      const uid = cred.user.uid; const memberId = memberIdFor(uid); const fullName = f.fullName.trim();
      await updateProfile(cred.user, { displayName: fullName });
      const b = writeBatch(db);
      b.set(doc(db, 'users', uid), { uid, fullName, phone: cleanPhone(f.phone), email: f.email.trim(), memberId, role: 'member', status: 'active', language: lang, photoUrl: '', createdAt: serverTimestamp(), updatedAt: serverTimestamp() });
      b.set(doc(db, 'member_directory', uid), { uid, fullName, memberId, status: 'active', position: '', joinedAt: serverTimestamp() });
      b.set(doc(collection(db, 'audit_logs')), { uid, action: 'member_registered', ref: `users/${uid}`, detail: memberId, createdAt: serverTimestamp() });
      await b.commit();
    } catch (x) { setErr(authErr(codeOf(x), t)); }
    setBusy(false);
  };
  return (
    <Shell>
      <form onSubmit={submit}>
        <Field label={t('auth.fullName')} value={f.fullName} onChange={set('fullName')} required />
        <Field label={t('auth.phone')} type="tel" value={f.phone} onChange={set('phone')} required dir="ltr" />
        <Field label={t('auth.email')} type="email" value={f.email} onChange={set('email')} required dir="ltr" />
        <Field label={t('auth.password')} type="password" minLength={6} value={f.password} onChange={set('password')} required dir="ltr" />
        {err && <p className="text-red-600 text-sm mb-3">{err}</p>}
        <Btn full disabled={busy}>{busy ? t('common.wait') : t('auth.register')}</Btn>
      </form>
      <div className="text-sm mt-4 text-forest-700"><Link to="/">{t('auth.haveAccount')}</Link></div>
    </Shell>
  );
}

export function Reset() {
  const { t } = useLang();
  const [email, setEmail] = useState(''); const [msg, setMsg] = useState(''); const [err, setErr] = useState('');
  const submit = async (e: FormEvent) => {
    e.preventDefault(); setErr(''); setMsg('');
    try { await sendPasswordResetEmail(auth, email.trim()); setMsg(t('auth.resetSent')); } catch (x) { setErr(authErr(codeOf(x), t)); }
  };
  return (
    <Shell>
      <form onSubmit={submit}>
        <Field label={t('auth.email')} type="email" value={email} onChange={(e) => setEmail(e.target.value)} required dir="ltr" />
        {err && <p className="text-red-600 text-sm mb-3">{err}</p>}
        {msg && <p className="text-forest-700 text-sm mb-3">{msg}</p>}
        <Btn full>{t('auth.sendReset')}</Btn>
      </form>
      <div className="text-sm mt-4 text-forest-700"><Link to="/">{t('auth.haveAccount')}</Link></div>
    </Shell>
  );
}
