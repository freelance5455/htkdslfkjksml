import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { sendPasswordResetEmail, signOut } from 'firebase/auth';
import { doc, serverTimestamp, where, writeBatch, updateDoc, Timestamp } from 'firebase/firestore';
import { auth, db } from '../lib/firebase';
import { useLang } from '../lib/i18n';
import { useCol, useSession } from '../lib/session';
import { amountFor, audit, cleanPhone, fmtDate, fmtMoney, hijriLabel, lastPeriods, monthLabel, periodOf, specialKind, HIJRI_MONTHS } from '../lib/util';
import { Arrow, Badge, Btn, Card, Empty, ErrorBox, Field, H, LangPicker, Spinner, useUi } from '../components/ui';
import { Constitution } from '../components/Constitution';
import { Logo } from '../components/Logo';

export type L4Text = { en?: string; bn?: string; ur?: string; ar?: string };
export const pickText = (v: L4Text | undefined, lang: keyof L4Text) => (v && (v[lang] || v.en || v.bn || v.ur || v.ar)) || '';
export const POSITIONS = ['amir', 'naib_amir', 'sadr', 'masul', 'nazim_maliyat', 'member', 'other'] as const;
export const posLabel = (t: (k: string) => string, p?: string) => (p && (POSITIONS as readonly string[]).includes(p) ? t('pos.' + p) : p || '');

interface Contribution { uid: string; period: string; amount: number; paidDate: string; status: string }
interface Announcement { title: L4Text; content: L4Text; imageUrl?: string; status: string; publishedAt?: Timestamp; authorName?: string }
export const useAnnouncements = () => {
  const r = useCol<Announcement>('announcements', 'pub', where('status', '==', 'published'));
  const data = [...r.data].sort((a, b) => (b.publishedAt?.toMillis() || 0) - (a.publishedAt?.toMillis() || 0));
  return { ...r, data };
};
export function AnnouncementCard({ a }: { a: Announcement & { id: string } }) {
  const { lang } = useLang();
  return (
    <Card className="mb-3">
      {a.imageUrl && <img src={a.imageUrl} alt="" className="rounded-xl mb-3 w-full max-h-48 object-cover" loading="lazy" />}
      <h3 className="font-semibold text-forest-800 tight">{pickText(a.title, lang)}</h3>
      <p className="text-xs text-gray-400 mb-2">{fmtDate(a.publishedAt, lang)}</p>
      <p className="whitespace-pre-wrap text-gray-700">{pickText(a.content, lang)}</p>
    </Card>
  );
}

export function Home() {
  const { t, lang } = useLang();
  const { profile, settings, calendar, user } = useSession();
  const ann = useAnnouncements();
  const mine = useCol<Contribution>('contributions', 'm' + user!.uid, where('uid', '==', user!.uid));
  const period = periodOf();
  const paid = mine.data.find((c) => c.period === period);
  const kind = specialKind(period, calendar);
  const today = new Date().getDate();
  return (
    <div>
      <Card className="bg-gradient-to-br from-forest-800 to-forest-700 text-white mb-4 border-0">
        <div className="flex items-center gap-3"><Logo size={52} />
          <div><div className="text-sm text-white/70">{t('home.welcome')}</div><div className="text-lg font-semibold tight">{profile!.fullName}</div></div></div>
        <div className="grid grid-cols-2 gap-2 mt-4 text-sm">
          <div><div className="text-white/60 text-xs">{t('home.memberId')}</div><div className="font-mono" dir="ltr">{profile!.memberId}</div></div>
          <div><div className="text-white/60 text-xs">{t('home.since')}</div><div>{fmtDate(profile!.createdAt, lang)}</div></div>
        </div>
        <div className="text-xs text-gold-400 mt-3">{hijriLabel(new Date(), lang)}</div>
      </Card>
      <Card className="mb-4">
        <div className="text-sm text-gray-500">{t('home.thisMonth')} — {monthLabel(period, lang)}</div>
        <div className="flex items-center justify-between mt-1">
          <div className="text-2xl font-semibold text-forest-800">{fmtMoney(amountFor(period, settings, calendar))}</div>
          {mine.loading ? null : paid ? <Badge tone="green">{t('contrib.paid')}</Badge> : <Badge tone={today > 10 ? 'red' : 'gold'}>{t('contrib.unpaid')}</Badge>}
        </div>
        {kind && <p className="text-xs text-gold-600 mt-1">{t(kind === 'fitr' ? 'contrib.fitrMonth' : 'contrib.adhaMonth')}</p>}
        <p className="text-xs text-gray-500 mt-2">{t('contrib.window')}</p>
        {!paid && <Link to="/donate"><Btn className="mt-3" v="gold">{t('home.payHow')}</Btn></Link>}
      </Card>
      <div className="text-sm font-semibold text-forest-800 mb-2">{t('home.latest')}</div>
      {ann.loading ? <Spinner /> : ann.data[0] ? <AnnouncementCard a={ann.data[0]} /> : <Empty text={t('empty.announcements')} />}
    </div>
  );
}

export function Profile() {
  const { t, lang } = useLang();
  const { profile, user } = useSession();
  const { toast } = useUi();
  const [name, setName] = useState(profile!.fullName); const [phone, setPhone] = useState(profile!.phone); const [photo, setPhoto] = useState(profile!.photoUrl || '');
  const [busy, setBusy] = useState(false);
  const save = async () => {
    if (name.trim().length < 2) return toast(t('err.name'));
    setBusy(true);
    try {
      const b = writeBatch(db);
      b.update(doc(db, 'users', user!.uid), { fullName: name.trim(), phone: cleanPhone(phone), photoUrl: photo.trim(), updatedAt: serverTimestamp() });
      b.update(doc(db, 'member_directory', user!.uid), { fullName: name.trim() });
      await b.commit(); audit('profile_updated', `users/${user!.uid}`); toast(t('common.saved'));
    } catch { toast(t('err.generic')); }
    setBusy(false);
  };
  return (
    <div>
      <H>{t('nav.profile')}</H>
      <Card>
        <div className="flex items-center gap-3 mb-4">
          {photo ? <img src={photo} alt="" className="h-16 w-16 rounded-full object-cover" /> : <div className="h-16 w-16 rounded-full bg-forest-100 text-forest-800 text-2xl flex items-center justify-center">{name.slice(0, 1)}</div>}
          <div><div className="font-semibold tight">{profile!.fullName}</div><div className="text-sm text-gray-500" dir="ltr">{profile!.memberId}</div>
            <Badge tone="green">{t('member.statusActive')}</Badge></div>
        </div>
        <Field label={t('auth.fullName')} value={name} onChange={(e) => setName(e.target.value)} />
        <Field label={t('auth.phone')} value={phone} onChange={(e) => setPhone(e.target.value)} dir="ltr" type="tel" />
        <Field label={t('auth.email')} value={profile!.email} disabled dir="ltr" />
        <Field label={t('profile.photoUrl')} value={photo} onChange={(e) => setPhoto(e.target.value)} dir="ltr" placeholder="https://" />
        <p className="text-xs text-gray-400 mb-3">{t('home.since')}: {fmtDate(profile!.createdAt, lang)}{profile!.position ? ' · ' + posLabel(t, profile!.position) : ''}</p>
        <Btn full onClick={save} disabled={busy}>{t('common.save')}</Btn>
      </Card>
    </div>
  );
}

export function Directory() {
  const { t } = useLang();
  const { data, loading, error } = useCol<{ fullName: string; memberId: string; status: string; position: string }>('member_directory', 'all');
  const [q, setQ] = useState('');
  const list = useMemo(() => data.filter((m) => m.status === 'active' && (m.fullName + m.memberId).toLowerCase().includes(q.toLowerCase())).sort((a, b) => a.fullName.localeCompare(b.fullName)), [data, q]);
  return (
    <div>
      <H sub={t('dir.privacy')}>{t('nav.directory')}</H>
      <Field label={t('common.search')} value={q} onChange={(e) => setQ(e.target.value)} />
      <ErrorBox code={error} />
      {loading ? <Spinner /> : list.length === 0 ? <Empty text={t('empty.members')} /> : list.map((m) => (
        <Card key={m.id} className="mb-2 flex justify-between items-center">
          <div><div className="font-semibold tight">{m.fullName}</div><div className="text-xs text-gray-500" dir="ltr">{m.memberId}</div></div>
          {m.position && <Badge tone="gold">{posLabel(t, m.position)}</Badge>}
        </Card>
      ))}
    </div>
  );
}

export function BaitulMaal() {
  const { t, lang } = useLang();
  const { settings, calendar } = useSession();
  const sorted = [...calendar].sort((a, b) => b.hijriYear - a.hijriYear);
  return (
    <div>
      <H>{t('nav.baitulmaal')}</H>
      <Card className="mb-3">
        <div className="flex justify-between"><span>{t('bm.normal')}</span><b>{fmtMoney(settings.monthlyAmount)}</b></div>
        <div className="flex justify-between mt-1"><span>{t('bm.eid')}</span><b>{fmtMoney(settings.specialAmount)}</b></div>
        <p className="text-sm text-gray-500 mt-2">{t('contrib.window')}</p>
        <p className="text-sm text-gray-500 mt-1">{t('bm.manual')}</p>
      </Card>
      <Card className="mb-3">
        <div className="font-semibold text-forest-800 mb-2">{t('bm.calendar')}</div>
        {sorted.length === 0 ? <p className="text-sm text-gray-400">{t('bm.noCalendar')}</p> : sorted.map((c) => (
          <div key={c.id} className="text-sm border-b border-cream-100 py-1.5">
            <b>{c.hijriYear} {t('bm.ah')}</b>
            <div>{HIJRI_MONTHS[lang][9]}: {c.fitrPeriod ? monthLabel(c.fitrPeriod, lang) : '—'}</div>
            <div>{HIJRI_MONTHS[lang][11]}: {c.adhaPeriod ? monthLabel(c.adhaPeriod, lang) : '—'}</div>
          </div>))}
      </Card>
      {(settings.custodianAmir || settings.custodianFinance || settings.custodianNote) && (
        <Card className="mb-3">
          <div className="font-semibold text-forest-800 mb-2">{t('bm.custodians')}</div>
          {settings.custodianAmir && <div className="text-sm">{t('pos.amir')}: {settings.custodianAmir}</div>}
          {settings.custodianFinance && <div className="text-sm">{t('pos.nazim_maliyat')}: {settings.custodianFinance}</div>}
          {settings.custodianNote && <p className="text-sm text-gray-600 mt-1">{settings.custodianNote}</p>}
        </Card>)}
      <Link to="/rules" className="block"><Card className="flex justify-between"><span>{t('nav.rules')}</span><Arrow /></Card></Link>
    </div>
  );
}

export function MyContributions() {
  const { t, lang } = useLang();
  const { user, profile, settings, calendar } = useSession();
  const { data, loading, error } = useCol<Contribution>('contributions', 'm' + user!.uid, where('uid', '==', user!.uid));
  const joined = profile!.createdAt ? periodOf(new Date(profile!.createdAt.toMillis())) : '0000-00';
  const periods = lastPeriods(12).filter((p) => p >= joined);
  const total = data.reduce((s, c) => s + (c.amount || 0), 0);
  return (
    <div>
      <H>{t('nav.contributions')}</H>
      <ErrorBox code={error} />
      <Card className="mb-3"><div className="text-sm text-gray-500">{t('contrib.totalPaid')}</div><div className="text-2xl font-semibold text-forest-800">{fmtMoney(total)}</div></Card>
      {loading ? <Spinner /> : periods.map((p) => {
        const c = data.find((x) => x.period === p);
        return (
          <Card key={p} className="mb-2 flex justify-between items-center">
            <div><div className="font-semibold tight">{monthLabel(p, lang)}</div>
              <div className="text-xs text-gray-500">{c ? `${fmtMoney(c.amount)} · ${fmtDate(c.paidDate, lang)}` : `${t('contrib.due')}: ${fmtMoney(amountFor(p, settings, calendar))}`}</div></div>
            <Badge tone={c ? 'green' : 'red'}>{c ? t('contrib.paid') : t('contrib.unpaid')}</Badge>
          </Card>);
      })}
      <p className="text-xs text-gray-400 mt-3">{t('contrib.manualNote')}</p>
    </div>
  );
}

export const ConstitutionPage = () => { const { t } = useLang(); return <div><H>{t('nav.constitution')}</H><Constitution /></div>; };
export const RulesPage = () => { const { t } = useLang(); return <div><H>{t('nav.rules')}</H><Constitution only={['membership', 'administration', 'baitulmaal']} withIntro={false} /></div>; };

export function Announcements() {
  const { t } = useLang();
  const { data, loading, error } = useAnnouncements();
  return <div><H>{t('nav.announcements')}</H><ErrorBox code={error} />{loading ? <Spinner /> : data.length ? data.map((a) => <AnnouncementCard key={a.id} a={a} />) : <Empty text={t('empty.announcements')} />}</div>;
}

export interface Official { name: string; position: string; customTitle?: string; committeeYear?: string; appointmentDate?: string; termStart?: string; termEnd?: string; status: 'current' | 'former' }
export function OfficialList({ items }: { items: (Official & { id: string })[] }) {
  const { t, lang } = useLang();
  if (!items.length) return <Empty text={t('empty.committee')} />;
  return <>{items.map((m) => (
    <Card key={m.id} className="mb-2">
      <div className="font-semibold tight">{m.name}</div>
      <div className="text-sm text-gold-600 tight">{m.position === 'other' || !m.position ? m.customTitle : t('pos.' + m.position)}{m.position !== 'other' && m.customTitle ? ` — ${m.customTitle}` : ''}</div>
      <div className="text-xs text-gray-500 mt-1">{m.committeeYear && `${t('com.year')}: ${m.committeeYear} · `}{t('com.term')}: {fmtDate(m.termStart, lang)} → {fmtDate(m.termEnd, lang)}</div>
    </Card>))}</>;
}
export function Committee() {
  const { t } = useLang();
  const ec = useCol<Official>('committee_members', 'ec'); const ac = useCol<Official>('advisory_council', 'ac');
  const [tab, setTab] = useState<'ec' | 'ac'>('ec'); const [former, setFormer] = useState(false);
  const src = tab === 'ec' ? ec : ac;
  const items = src.data.filter((m) => (m.status === 'former') === former);
  return (
    <div>
      <H>{t('nav.committee')}</H>
      <div className="flex gap-2 mb-3">
        <Btn v={tab === 'ec' ? 'primary' : 'ghost'} onClick={() => setTab('ec')}>{t('com.executive')}</Btn>
        <Btn v={tab === 'ac' ? 'primary' : 'ghost'} onClick={() => setTab('ac')}>{t('com.advisory')} <span className="arabic-original text-sm">(المجلس الاستشاري)</span></Btn>
      </div>
      <div className="flex gap-2 mb-3 text-sm">
        <button className={!former ? 'font-semibold text-forest-800' : 'text-gray-400'} onClick={() => setFormer(false)}>{t('com.current')}</button>
        <span>|</span>
        <button className={former ? 'font-semibold text-forest-800' : 'text-gray-400'} onClick={() => setFormer(true)}>{t('com.former')}</button>
      </div>
      <ErrorBox code={src.error} />
      {src.loading ? <Spinner /> : <OfficialList items={items} />}
    </div>
  );
}

function PayRow({ label, number, link }: { label: string; number: string; link?: string }) {
  const { t } = useLang(); const { toast } = useUi();
  if (!number) return null;
  const copy = async () => { try { await navigator.clipboard.writeText(number); toast(t('common.copied')); } catch { toast(number); } };
  return (
    <div className="flex items-center justify-between border-b border-cream-100 py-3">
      <div><div className="text-sm text-gray-500">{label}</div><div className="text-lg font-mono" dir="ltr">{number}</div></div>
      <div className="flex gap-2"><Btn v="ghost" onClick={copy}>{t('common.copy')}</Btn>{link && <a href={link} target="_blank" rel="noreferrer"><Btn>{t('pay.openApp')}</Btn></a>}</div>
    </div>
  );
}
export function Donate() {
  const { t } = useLang(); const { settings } = useSession();
  const any = settings.bkash || settings.nagad;
  return (
    <div>
      <H>{t('nav.donate')}</H>
      <Card className="mb-3">
        {any ? <><PayRow label="bKash" number={settings.bkash} link={settings.bkashLink} /><PayRow label="Nagad" number={settings.nagad} link={settings.nagadLink} /></> : <Empty text={t('pay.notSet')} />}
        {settings.accountType && <p className="text-sm mt-2">{t('pay.accountType')}: {settings.accountType}</p>}
      </Card>
      <Card className="mb-3">
        <div className="font-semibold text-forest-800 mb-1">{t('pay.instructions')}</div>
        <p className="text-sm whitespace-pre-wrap text-gray-700">{settings.paymentInstructions || t('pay.defaultInstructions')}</p>
        <p className="text-xs text-red-700 mt-3">{t('pay.manualWarning')}</p>
      </Card>
      {settings.donationInfo && <Card><p className="text-sm whitespace-pre-wrap">{settings.donationInfo}</p></Card>}
    </div>
  );
}

export function Contact() {
  const { t } = useLang(); const { settings } = useSession();
  return (
    <div>
      <H>{t('nav.contact')}</H>
      <Card className="text-center">
        <Logo size={80} />
        <div className="font-semibold mt-3">MTM Foundation</div>
        <div className="arabic-original text-forest-800">مؤسسة الطلاب المسلمين</div>
        <div className="text-sm text-gray-500 mb-3">Mu'assasatut Tullab Al Muslimeen (MTM)</div>
        <a href={`tel:${settings.contactNumber}`} className="block text-lg font-mono text-forest-700" dir="ltr">{settings.contactNumber}</a>
        <p className="text-sm mt-3 text-gray-700" dir="ltr">{settings.address}</p>
      </Card>
    </div>
  );
}

export function Settings() {
  const { t } = useLang(); const { user, isAdmin } = useSession(); const { toast, confirm } = useUi();
  const { lang } = useLang();
  const saveLang = async () => { try { await updateDoc(doc(db, 'users', user!.uid), { language: lang, updatedAt: serverTimestamp() }); toast(t('common.saved')); } catch { toast(t('err.generic')); } };
  const reset = async () => { try { await sendPasswordResetEmail(auth, user!.email!); toast(t('auth.resetSent')); } catch { toast(t('err.generic')); } };
  const logout = async () => { if (await confirm(t('auth.logoutConfirm'))) await signOut(auth); };
  return (
    <div>
      <H>{t('nav.settings')}</H>
      <Card className="mb-3">
        <div className="font-semibold mb-2">{t('lang.choose')}</div><LangPicker />
        <Btn v="ghost" className="mt-3" onClick={saveLang}>{t('lang.remember')}</Btn>
      </Card>
      <Card className="mb-3"><Btn v="ghost" full onClick={reset}>{t('auth.changePassword')}</Btn></Card>
      {isAdmin && <Link to="/admin"><Card className="mb-3 flex justify-between"><span>{t('adm.panel')}</span><Arrow /></Card></Link>}
      <Btn v="danger" full onClick={logout}>{t('auth.logout')}</Btn>
      <p className="text-center text-xs text-gray-400 mt-4">v1.0.0 · com.mtmfoundation.app</p>
    </div>
  );
}

export function More() {
  const { t } = useLang(); const { isAdmin } = useSession();
  const items = [['/profile', 'nav.profile'], ['/directory', 'nav.directory'], ['/baitulmaal', 'nav.baitulmaal'], ['/constitution', 'nav.constitution'], ['/rules', 'nav.rules'], ['/donate', 'nav.donate'], ['/contact', 'nav.contact'], ['/settings', 'nav.settings']];
  if (isAdmin) items.unshift(['/admin', 'adm.panel']);
  return (
    <div>
      <H>{t('nav.more')}</H>
      {items.map(([to, k]) => <Link key={to} to={to}><Card className="mb-2 flex justify-between items-center"><span className="tight">{t(k)}</span><Arrow /></Card></Link>)}
    </div>
  );
}
