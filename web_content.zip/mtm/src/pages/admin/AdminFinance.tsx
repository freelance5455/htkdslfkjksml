import { useMemo, useState } from 'react';
import { addDoc, collection, deleteDoc, doc, serverTimestamp, updateDoc } from 'firebase/firestore';
import { auth, db } from '../../lib/firebase';
import { useLang } from '../../lib/i18n';
import { useCol, useSession } from '../../lib/session';
import { audit, fmtDate, fmtMoney, todayISO } from '../../lib/util';
import { Area, Badge, Btn, Card, Empty, ErrorBox, Field, H, Modal, Sel, Spinner, useUi } from '../../components/ui';

type Decision = 'pending' | 'approved' | 'rejected';
interface Approval { role: 'amir' | 'naib_amir' | 'sadr'; name: string; decision: Decision; date: string }
interface Tx { type: 'income' | 'expense'; amount: number; description: string; date: string; category: string; approvals?: Approval[]; approvalNote?: string; ref?: string; createdBy: string; updatedBy?: string }
const CATS = ['contribution', 'donation', 'event', 'relief', 'education', 'administration', 'other'];
const ROLES = ['amir', 'naib_amir', 'sadr'] as const;
const emptyApprovals = (): Approval[] => ROLES.map((role) => ({ role, name: '', decision: 'pending', date: '' }));

export function AdminFinance() {
  const { t, lang } = useLang(); const { toast, confirm } = useUi(); const { canManage } = useSession();
  const { data, loading, error } = useCol<Tx>('financial_transactions', 'all');
  const [tab, setTab] = useState<'list' | 'report'>('list');
  const [from, setFrom] = useState(''); const [to, setTo] = useState(''); const [type, setType] = useState('');
  const [edit, setEdit] = useState<(Partial<Tx> & { id?: string }) | null>(null);
  const [year, setYear] = useState(new Date().getFullYear());

  const all = useMemo(() => [...data].sort((a, b) => (b.date || '').localeCompare(a.date || '')), [data]);
  const list = all.filter((x) => (!from || x.date >= from) && (!to || x.date <= to) && (!type || x.type === type));
  const sum = (a: Tx[], ty: string) => a.filter((x) => x.type === ty).reduce((s, x) => s + x.amount, 0);
  const inc = sum(list, 'income'), exp = sum(list, 'expense');

  const startNew = (ty: 'income' | 'expense') => setEdit({ type: ty, amount: undefined, description: '', date: todayISO(), category: ty === 'income' ? 'donation' : 'relief', approvals: ty === 'expense' ? emptyApprovals() : undefined, approvalNote: '' });
  const save = async () => {
    if (!edit) return;
    const amt = Number(edit.amount);
    if (!(amt > 0)) return toast(t('err.amount'));
    if (!edit.description?.trim()) return toast(t('err.required'));
    const uid = auth.currentUser!.uid;
    const body: Record<string, unknown> = { type: edit.type, amount: amt, description: edit.description.trim(), date: edit.date || todayISO(), category: edit.category || 'other', updatedBy: uid, updatedAt: serverTimestamp() };
    if (edit.type === 'expense') { body.approvals = edit.approvals || emptyApprovals(); body.approvalNote = edit.approvalNote || ''; }
    try {
      if (edit.id) { await updateDoc(doc(db, 'financial_transactions', edit.id), body); audit('transaction_updated', `financial_transactions/${edit.id}`, `${edit.type}:${amt}`); }
      else { const r = await addDoc(collection(db, 'financial_transactions'), { ...body, createdBy: uid, createdAt: serverTimestamp() }); audit(edit.type === 'income' ? 'income_added' : 'expense_added', `financial_transactions/${r.id}`, String(amt)); }
      toast(t('common.saved')); setEdit(null);
    } catch { toast(t('err.generic')); }
  };
  const del = async () => {
    if (!edit?.id || !(await confirm(t('common.deleteConfirm')))) return;
    try { await deleteDoc(doc(db, 'financial_transactions', edit.id)); audit('transaction_deleted', `financial_transactions/${edit.id}`); setEdit(null); } catch { toast(t('err.generic')); }
  };
  const setApproval = (i: number, patch: Partial<Approval>) => setEdit((e) => e && ({ ...e, approvals: (e.approvals || emptyApprovals()).map((a, j) => (j === i ? { ...a, ...patch } : a)) }));

  // ---- annual report ----
  const yr = all.filter((x) => (x.date || '').startsWith(String(year)));
  const months = Array.from({ length: 12 }, (_, i) => { const p = `${year}-${String(i + 1).padStart(2, '0')}`; const m = yr.filter((x) => x.date.startsWith(p)); return { p, inc: sum(m, 'income'), exp: sum(m, 'expense') }; });
  const byCat = CATS.map((c) => ({ c, inc: sum(yr.filter((x) => x.category === c), 'income'), exp: sum(yr.filter((x) => x.category === c), 'expense') })).filter((x) => x.inc || x.exp);
  const copyReport = async () => {
    const lines = [`MTM Foundation — ${year}`, ...months.map((m) => `${m.p}: +${m.inc} / -${m.exp}`), `Total income: ${sum(yr, 'income')}`, `Total expense: ${sum(yr, 'expense')}`, `Balance: ${sum(yr, 'income') - sum(yr, 'expense')}`];
    try { await navigator.clipboard.writeText(lines.join('\n')); toast(t('common.copied')); } catch { toast(t('err.generic')); }
  };
  const allBalance = sum(all, 'income') - sum(all, 'expense');
  const linked = !!edit?.ref;

  return (
    <div>
      <H>{t('adm.finance')}</H>
      <Card className="mb-3 grid grid-cols-3 gap-2 text-center">
        <div><div className="text-xs text-gray-500">{t('fin.income')}</div><b className="text-forest-700">{fmtMoney(sum(all, 'income'))}</b></div>
        <div><div className="text-xs text-gray-500">{t('fin.expense')}</div><b className="text-red-700">{fmtMoney(sum(all, 'expense'))}</b></div>
        <div><div className="text-xs text-gray-500">{t('fin.balance')}</div><b>{fmtMoney(allBalance)}</b></div>
      </Card>
      <p className="text-xs text-gray-400 mb-3">{t('fin.recordedOnly')}</p>
      <div className="flex gap-2 mb-3"><Btn v={tab === 'list' ? 'primary' : 'ghost'} onClick={() => setTab('list')}>{t('fin.transactions')}</Btn><Btn v={tab === 'report' ? 'primary' : 'ghost'} onClick={() => setTab('report')}>{t('fin.reports')}</Btn></div>
      <ErrorBox code={error} />
      {tab === 'list' ? (<>
        <div className="flex gap-2 mb-3"><Btn onClick={() => startNew('income')}>+ {t('fin.addIncome')}</Btn><Btn v="gold" onClick={() => startNew('expense')}>+ {t('fin.addExpense')}</Btn></div>
        <div className="grid grid-cols-3 gap-2">
          <Field label={t('fin.from')} type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
          <Field label={t('fin.to')} type="date" value={to} onChange={(e) => setTo(e.target.value)} />
          <Sel label={t('fin.type')} value={type} onChange={(e) => setType(e.target.value)}><option value="">—</option><option value="income">{t('fin.income')}</option><option value="expense">{t('fin.expense')}</option></Sel>
        </div>
        {(from || to || type) && <p className="text-sm mb-2">{t('fin.filtered')}: +{fmtMoney(inc)} / −{fmtMoney(exp)}</p>}
        {loading ? <Spinner /> : list.length === 0 ? <Empty text={t('empty.transactions')} /> : list.map((x) => (
          <Card key={x.id} className="mb-2" >
            <button className="w-full text-start" onClick={() => setEdit(x)}>
              <div className="flex justify-between"><span className="font-semibold tight">{x.description}</span><b className={x.type === 'income' ? 'text-forest-700' : 'text-red-700'}>{x.type === 'income' ? '+' : '−'}{fmtMoney(x.amount)}</b></div>
              <div className="text-xs text-gray-500">{fmtDate(x.date, lang)} · {t('cat.' + x.category)}</div>
              {x.type === 'expense' && <div className="mt-1"><Badge tone={(x.approvals || []).filter((a) => a.decision === 'approved').length === 3 ? 'green' : 'gold'}>{t('fin.approvals')}: {(x.approvals || []).filter((a) => a.decision === 'approved').length}/3</Badge></div>}
            </button>
          </Card>))}
      </>) : (<>
        <Field label={t('fin.year')} type="number" value={year} onChange={(e) => setYear(Number(e.target.value) || year)} />
        <Card className="mb-3 overflow-x-auto"><table className="w-full text-sm"><thead><tr className="text-gray-500"><th className="text-start">{t('fin.month')}</th><th>{t('fin.income')}</th><th>{t('fin.expense')}</th></tr></thead>
          <tbody>{months.map((m) => <tr key={m.p} className="border-t border-cream-100"><td>{m.p}</td><td className="text-center">{fmtMoney(m.inc)}</td><td className="text-center">{fmtMoney(m.exp)}</td></tr>)}
            <tr className="border-t-2 font-bold"><td>{t('fin.total')}</td><td className="text-center">{fmtMoney(sum(yr, 'income'))}</td><td className="text-center">{fmtMoney(sum(yr, 'expense'))}</td></tr></tbody></table></Card>
        {byCat.length > 0 && <Card className="mb-3"><div className="font-semibold mb-1">{t('fin.byCategory')}</div>{byCat.map((c) => <div key={c.c} className="flex justify-between text-sm"><span>{t('cat.' + c.c)}</span><span>+{c.inc} / −{c.exp}</span></div>)}</Card>}
        <Btn full v="ghost" onClick={copyReport}>{t('fin.copyReport')}</Btn>
      </>)}

      <Modal open={!!edit} onClose={() => setEdit(null)} title={edit?.id ? t('common.edit') : edit?.type === 'income' ? t('fin.addIncome') : t('fin.addExpense')}>
        {linked && <p className="text-xs text-gold-600 mb-2">{t('fin.linkedNote')}</p>}
        <Field label={t('fin.amount')} type="number" inputMode="numeric" disabled={linked} value={edit?.amount ?? ''} onChange={(e) => setEdit({ ...edit, amount: e.target.value as unknown as number })} />
        <Field label={t('fin.description')} disabled={linked} value={edit?.description || ''} onChange={(e) => setEdit({ ...edit, description: e.target.value })} />
        <Field label={t('fin.date')} type="date" disabled={linked} value={edit?.date || ''} onChange={(e) => setEdit({ ...edit, date: e.target.value })} />
        <Sel label={t('fin.category')} disabled={linked} value={edit?.category || 'other'} onChange={(e) => setEdit({ ...edit, category: e.target.value })}>{CATS.map((c) => <option key={c} value={c}>{t('cat.' + c)}</option>)}</Sel>
        {edit?.type === 'expense' && (<div className="border-t border-cream-200 pt-3 mb-3">
          <div className="font-semibold text-forest-800">{t('fin.approvals')}</div><p className="text-xs text-gray-500 mb-2">{t('fin.approvalHelp')}</p>
          {(edit.approvals || emptyApprovals()).map((a, i) => (
            <div key={a.role} className="mb-2 bg-white rounded-xl p-2 border border-cream-200">
              <div className="text-sm font-semibold">{t('pos.' + a.role)}</div>
              <Field label={t('fin.approverName')} value={a.name} onChange={(e) => setApproval(i, { name: e.target.value })} />
              <div className="grid grid-cols-2 gap-2"><Sel label={t('fin.decision')} value={a.decision} onChange={(e) => setApproval(i, { decision: e.target.value as Decision, date: e.target.value === 'pending' ? '' : a.date || todayISO() })}>
                {(['pending', 'approved', 'rejected'] as const).map((d) => <option key={d} value={d}>{t('fin.d.' + d)}</option>)}</Sel>
                <Field label={t('fin.date')} type="date" value={a.date} onChange={(e) => setApproval(i, { date: e.target.value })} /></div>
            </div>))}
          <Area label={t('fin.altArrangement')} value={edit.approvalNote || ''} onChange={(e) => setEdit({ ...edit, approvalNote: e.target.value })} />
        </div>)}
        {!linked && <Btn full onClick={save}>{t('common.save')}</Btn>}
        {edit?.id && canManage && !linked && <Btn full v="danger" className="mt-2" onClick={del}>{t('common.delete')}</Btn>}
      </Modal>
    </div>
  );
}
