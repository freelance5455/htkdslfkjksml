import { useState } from 'react';
import { deleteDoc, doc, serverTimestamp, setDoc } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { useLang } from '../../lib/i18n';
import { useSession } from '../../lib/session';
import { audit, DEFAULT_SETTINGS, HIJRI_MONTHS, monthLabel, periodOf, Settings, suggestPeriod, hijriParts } from '../../lib/util';
import { Area, Btn, Card, Field, H, LangPicker, Sel, useUi } from '../../components/ui';

export function AdminSettings() {
  const { t, lang } = useLang(); const { toast, confirm } = useUi();
  const { settings, calendar } = useSession();
  const [f, setF] = useState<Settings>({ ...DEFAULT_SETTINGS, ...settings });
  const set = <K extends keyof Settings>(k: K, v: Settings[K]) => setF((x) => ({ ...x, [k]: v }));
  const save = async () => {
    try {
      await setDoc(doc(db, 'foundation_settings', 'general'), { ...f, monthlyAmount: Number(f.monthlyAmount) || 100, specialAmount: Number(f.specialAmount) || 150, updatedAt: serverTimestamp() });
      audit('settings_changed', 'foundation_settings/general'); toast(t('common.saved'));
    } catch { toast(t('err.generic')); }
  };
  const thisHijri = hijriParts(new Date()).y;
  const [hy, setHy] = useState(String(thisHijri + 1)); const [fitr, setFitr] = useState(''); const [adha, setAdha] = useState('');
  const suggest = () => { const y = Number(hy); if (y > 1400) { setFitr(suggestPeriod(y, 10)); setAdha(suggestPeriod(y, 12)); } };
  const saveCal = async () => {
    const y = Number(hy); if (!(y > 1400) || !fitr || !adha) return toast(t('err.required'));
    try { await setDoc(doc(db, 'contribution_calendar', String(y)), { hijriYear: y, fitrPeriod: fitr, adhaPeriod: adha, updatedAt: serverTimestamp() }); audit('settings_changed', `contribution_calendar/${y}`); toast(t('common.saved')); } catch { toast(t('err.generic')); }
  };
  const delCal = async (id: string) => { if (await confirm(t('common.deleteConfirm'))) { await deleteDoc(doc(db, 'contribution_calendar', id)); audit('settings_changed', `contribution_calendar/${id}`, 'deleted'); } };
  return (
    <div>
      <H>{t('adm.settings')}</H>
      <Card className="mb-4">
        <Field label={t('set.logoUrl')} dir="ltr" placeholder="https://" value={f.logoUrl} onChange={(e) => set('logoUrl', e.target.value)} />
        <Field label={t('set.contact')} dir="ltr" value={f.contactNumber} onChange={(e) => set('contactNumber', e.target.value)} />
        <Area label={t('set.address')} rows={2} dir="ltr" value={f.address} onChange={(e) => set('address', e.target.value)} />
        <div className="grid grid-cols-2 gap-2"><Field label={t('set.monthly')} type="number" value={f.monthlyAmount} onChange={(e) => set('monthlyAmount', Number(e.target.value))} /><Field label={t('set.special')} type="number" value={f.specialAmount} onChange={(e) => set('specialAmount', Number(e.target.value))} /></div>
        <Sel label={t('set.defaultLang')} value={f.defaultLanguage} onChange={(e) => set('defaultLanguage', e.target.value as Settings['defaultLanguage'])}>{(['bn', 'en', 'ur', 'ar'] as const).map((c) => <option key={c} value={c}>{{ bn: 'বাংলা', en: 'English', ur: 'اردو', ar: 'العربية' }[c]}</option>)}</Sel>
      </Card>
      <Card className="mb-4">
        <div className="font-semibold text-forest-800 mb-2">{t('nav.donate')}</div>
        <Field label="bKash" dir="ltr" value={f.bkash} onChange={(e) => set('bkash', e.target.value)} />
        <Field label={`bKash ${t('set.appLink')}`} dir="ltr" placeholder="https://" value={f.bkashLink} onChange={(e) => set('bkashLink', e.target.value)} />
        <Field label="Nagad" dir="ltr" value={f.nagad} onChange={(e) => set('nagad', e.target.value)} />
        <Field label={`Nagad ${t('set.appLink')}`} dir="ltr" placeholder="https://" value={f.nagadLink} onChange={(e) => set('nagadLink', e.target.value)} />
        <Field label={t('pay.accountType')} value={f.accountType} onChange={(e) => set('accountType', e.target.value)} />
        <Area label={t('pay.instructions')} value={f.paymentInstructions} onChange={(e) => set('paymentInstructions', e.target.value)} />
        <Area label={t('set.donationInfo')} value={f.donationInfo} onChange={(e) => set('donationInfo', e.target.value)} />
      </Card>
      <Card className="mb-4">
        <div className="font-semibold text-forest-800 mb-2">{t('bm.custodians')}</div>
        <Field label={t('pos.amir')} value={f.custodianAmir} onChange={(e) => set('custodianAmir', e.target.value)} />
        <Field label={t('pos.nazim_maliyat')} value={f.custodianFinance} onChange={(e) => set('custodianFinance', e.target.value)} />
        <Area label={t('set.custodianNote')} value={f.custodianNote} onChange={(e) => set('custodianNote', e.target.value)} />
      </Card>
      <Btn full onClick={save}>{t('common.save')}</Btn>

      <H sub={t('cal.help')}>{t('bm.calendar')}</H>
      <Card className="mb-3">
        <Field label={t('cal.hijriYear')} type="number" value={hy} onChange={(e) => setHy(e.target.value)} />
        <Btn v="ghost" className="mb-3" onClick={suggest}>{t('cal.suggest')}</Btn>
        <Field label={`${HIJRI_MONTHS[lang][9]} (${t('cal.billingMonth')})`} type="month" value={fitr} onChange={(e) => setFitr(e.target.value)} />
        <Field label={`${HIJRI_MONTHS[lang][11]} (${t('cal.billingMonth')})`} type="month" value={adha} onChange={(e) => setAdha(e.target.value)} />
        <p className="text-xs text-gray-500 mb-3">{t('cal.verify')}</p>
        <Btn full onClick={saveCal}>{t('common.save')}</Btn>
      </Card>
      {[...calendar].sort((a, b) => b.hijriYear - a.hijriYear).map((c) => (
        <Card key={c.id} className="mb-2 flex justify-between items-center text-sm">
          <div><b>{c.hijriYear}</b><div>{HIJRI_MONTHS[lang][9]}: {c.fitrPeriod ? monthLabel(c.fitrPeriod, lang) : '—'}</div><div>{HIJRI_MONTHS[lang][11]}: {c.adhaPeriod ? monthLabel(c.adhaPeriod, lang) : '—'}</div></div>
          <div className="flex gap-2"><Btn v="ghost" onClick={() => { setHy(String(c.hijriYear)); setFitr(c.fitrPeriod); setAdha(c.adhaPeriod); }}>{t('common.edit')}</Btn><Btn v="danger" onClick={() => delCal(c.id)}>{t('common.delete')}</Btn></div>
        </Card>))}
      <Card className="mt-4"><div className="text-sm mb-2">{t('lang.choose')}</div><LangPicker /><p className="text-xs text-gray-400 mt-2">{periodOf()}</p></Card>
    </div>
  );
}
