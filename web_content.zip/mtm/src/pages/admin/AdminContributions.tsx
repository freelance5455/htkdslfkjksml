import { useMemo, useState } from 'react';
import { doc, serverTimestamp, where, writeBatch } from 'firebase/firestore';
import { auth, db } from '../../lib/firebase';
import { useLang } from '../../lib/i18n';
import { useCol, useSession } from '../../lib/session';
import { amountFor, audit, fmtDate, fmtMoney, lastPeriods, monthLabel, specialKind, todayISO } from '../../lib/util';
import { Badge, Btn, Card, ErrorBox, Field, H, Modal, Sel, Spinner, useUi } from '../../components/ui';

interface Dir { fullName: string; memberId: string; status: string }
interface Con { uid: string; period: string; amount: number; paidDate: string; memberName: string }

export function AdminContributions() {
  const { t, lang } = useLang(); const { toast, confirm } = useUi();
  const { settings, calendar } = useSession();
  const periods = useMemo(() => lastPeriods(18, new Date(new Date().getFullYear(), new Date().getMonth() + 1, 1)), []);
  const [period, setPeriod] = useState(lastPeriods(1)[0]);
  const members = useCol<Dir>('member_directory', 'all');
  const cons = useCol<Con>('contributions', 'p' + period, where('period', '==', period));
  const [q, setQ] = useState(''); const [filter, setFilter] = useState<'all' | 'paid' | 'unpaid'>('all');
  const [target, setTarget] = useState<(Dir & { id: string }) | null>(null);
  const [amount, setAmount] = useState(''); const [date, setDate] = useState(todayISO());
  const byUid = new Map(cons.data.map((c) => [c.uid, c]));
  const due = amountFor(period, settings, calendar); const kind = specialKind(period, calendar);
  const active = members.data.filter((m) => m.status === 'active');
  const rows = active.filter((m) => (m.fullName + m.memberId).toLowerCase().includes(q.toLowerCase()) && (filter === 'all' || (filter === 'paid') === byUid.has(m.id))).sort((a, b) => a.fullName.localeCompare(b.fullName));
  const collected = cons.data.reduce((s, c) => s + c.amount, 0);

  const open = (m: Dir & { id: string }) => { const c = byUid.get(m.id); setTarget(m); setAmount(String(c ? c.amount : due)); setDate(c ? c.paidDate : todayISO()); };
  const save = async () => {
    if (!target) return; const amt = Number(amount);
    if (!(amt > 0)) return toast(t('err.amount'));
    const id = `${target.id}_${period}`; const uid = auth.currentUser!.uid; const existing = byUid.get(target.id);
    try {
      const b = writeBatch(db);
      if (existing) {
        b.update(doc(db, 'contributions', id), { amount: amt, paidDate: date, updatedBy: uid, updatedAt: serverTimestamp() });
        b.update(doc(db, 'financial_transactions', `contrib_${id}`), { amount: amt, date, updatedBy: uid, updatedAt: serverTimestamp() });
      } else {
        b.set(doc(db, 'contributions', id), { uid: target.id, memberId: target.memberId, memberName: target.fullName, period, amount: amt, paidDate: date, status: 'paid', recordedBy: uid, createdAt: serverTimestamp() });
        b.set(doc(db, 'financial_transactions', `contrib_${id}`), { type: 'income', amount: amt, description: `${target.fullName} (${target.memberId}) — ${period}`, date, category: 'contribution', ref: id, createdBy: uid, updatedBy: uid, createdAt: serverTimestamp() });
      }
      await b.commit(); audit(existing ? 'contribution_corrected' : 'contribution_paid', `contributions/${id}`, String(amt)); toast(t('common.saved')); setTarget(null);
    } catch { toast(t('err.generic')); }
  };
  const unpay = async () => {
    if (!target || !(await confirm(t('contrib.unmarkConfirm')))) return;
    const id = `${target.id}_${period}`;
    try {
      const b = writeBatch(db); b.delete(doc(db, 'contributions', id)); b.delete(doc(db, 'financial_transactions', `contrib_${id}`));
      await b.commit(); audit('contribution_voided', `contributions/${id}`); toast(t('common.saved')); setTarget(null);
    } catch { toast(t('err.generic')); }
  };
  return (
    <div>
      <H>{t('adm.contributions')}</H>
      <Sel label={t('contrib.period')} value={period} onChange={(e) => setPeriod(e.target.value)}>{periods.map((p) => <option key={p} value={p}>{monthLabel(p, lang)}</option>)}</Sel>
      <Card className="mb-3 text-sm">
        <div className="flex justify-between"><span>{t('contrib.due')}</span><b>{fmtMoney(due)}</b></div>
        {kind && <div className="text-gold-600 text-xs">{t(kind === 'fitr' ? 'contrib.fitrMonth' : 'contrib.adhaMonth')}</div>}
        <div className="flex justify-between"><span>{t('contrib.paid')}</span><b>{cons.data.length} / {active.length}</b></div>
        <div className="flex justify-between"><span>{t('contrib.collected')}</span><b>{fmtMoney(collected)}</b></div>
      </Card>
      <div className="flex gap-2 mb-2">{(['all', 'paid', 'unpaid'] as const).map((f) => <Btn key={f} v={filter === f ? 'primary' : 'ghost'} onClick={() => setFilter(f)}>{t('filter.' + f)}</Btn>)}</div>
      <Field label={t('common.search')} value={q} onChange={(e) => setQ(e.target.value)} />
      <ErrorBox code={cons.error || members.error} />
      {cons.loading || members.loading ? <Spinner /> : rows.map((m) => {
        const c = byUid.get(m.id);
        return (
          <Card key={m.id} className="mb-2 flex justify-between items-center">
            <div className="min-w-0"><div className="font-semibold tight truncate">{m.fullName}</div><div className="text-xs text-gray-500" dir="ltr">{m.memberId}</div>
              {c && <div className="text-xs text-gray-500">{fmtMoney(c.amount)} · {fmtDate(c.paidDate, lang)}</div>}</div>
            <div className="text-end space-y-1"><Badge tone={c ? 'green' : 'red'}>{c ? t('contrib.paid') : t('contrib.unpaid')}</Badge>
              <div><Btn v={c ? 'ghost' : 'primary'} onClick={() => open(m)}>{c ? t('common.edit') : t('contrib.markPaid')}</Btn></div></div>
          </Card>);
      })}
      <Modal open={!!target} onClose={() => setTarget(null)} title={target?.fullName || ''}>
        <p className="text-sm text-gray-500 mb-3">{monthLabel(period, lang)}</p>
        <Field label={t('fin.amount')} type="number" inputMode="numeric" value={amount} onChange={(e) => setAmount(e.target.value)} />
        <Field label={t('contrib.paidDate')} type="date" value={date} onChange={(e) => setDate(e.target.value)} />
        <p className="text-xs text-gray-500 mb-3">{t('contrib.verifyFirst')}</p>
        <Btn full onClick={save}>{target && byUid.has(target.id) ? t('common.save') : t('contrib.markPaid')}</Btn>
        {target && byUid.has(target.id) && <Btn full v="danger" className="mt-2" onClick={unpay}>{t('contrib.markUnpaid')}</Btn>}
      </Modal>
    </div>
  );
}
