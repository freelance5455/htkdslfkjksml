import { useState } from 'react';
import { deleteDoc, doc, serverTimestamp, setDoc } from 'firebase/firestore';
import { auth, db } from '../../lib/firebase';
import { useLang } from '../../lib/i18n';
import { useCol, useSession } from '../../lib/session';
import type { Profile } from '../../lib/session';
import { audit } from '../../lib/util';
import { Badge, Btn, Card, ErrorBox, Field, H, Modal, Sel, Spinner, useUi } from '../../components/ui';

interface Admin { role: string; name: string; email: string; memberId: string }
const ROLES = ['super_admin', 'finance_admin', 'content_admin'];
export function AdminAdmins() {
  const { t } = useLang(); const { toast, confirm } = useUi(); const { profile } = useSession();
  const admins = useCol<Admin>('admin_access', 'all'); const users = useCol<Profile>('users', 'all');
  const [open, setOpen] = useState(false); const [q, setQ] = useState(''); const [pick, setPick] = useState<(Profile & { id: string }) | null>(null); const [role, setRole] = useState('finance_admin');
  const adminIds = new Set(admins.data.map((a) => a.id));
  const cand = q.length < 2 ? [] : users.data.filter((u) => !adminIds.has(u.id) && (u.fullName + u.email + u.memberId).toLowerCase().includes(q.toLowerCase())).slice(0, 8);
  const grant = async (uid: string, u: { fullName?: string; email?: string; memberId?: string; name?: string }, r: string) => {
    try {
      await setDoc(doc(db, 'admin_access', uid), { role: r, name: u.fullName || u.name || '', email: u.email || '', memberId: u.memberId || '', appointedBy: auth.currentUser!.uid, appointedAt: serverTimestamp() });
      audit('admin_appointed', `admin_access/${uid}`, r); toast(t('common.saved')); setOpen(false); setPick(null); setQ('');
    } catch { toast(t('err.generic')); }
  };
  const remove = async (a: Admin & { id: string }) => {
    if (!(await confirm(t('adm.removeConfirm', { name: a.name })))) return;
    try { await deleteDoc(doc(db, 'admin_access', a.id)); audit('admin_removed', `admin_access/${a.id}`, a.role); } catch { toast(t('err.generic')); }
  };
  return (
    <div>
      <H>{t('adm.admins')}</H>
      <Card className="mb-3 flex justify-between items-center"><div><div className="font-semibold tight">{profile?.fullName}</div><div className="text-xs text-gray-500">{t('role.owner')}</div></div><Badge tone="gold">{t('role.owner')}</Badge></Card>
      <p className="text-xs text-gray-500 mb-3">{t('adm.ownerLocked')}</p>
      <Btn className="mb-3" onClick={() => setOpen(true)}>+ {t('adm.appoint')}</Btn>
      <ErrorBox code={admins.error} />
      {admins.loading ? <Spinner /> : admins.data.map((a) => (
        <Card key={a.id} className="mb-2">
          <div className="flex justify-between"><div><div className="font-semibold tight">{a.name}</div><div className="text-xs text-gray-500" dir="ltr">{a.email}</div></div><Badge tone="green">{t('role.' + a.role)}</Badge></div>
          <div className="flex gap-2 mt-2 items-end">
            <Sel label={t('adm.changeRole')} value={a.role} onChange={(e) => grant(a.id, a, e.target.value)}>{ROLES.map((r) => <option key={r} value={r}>{t('role.' + r)}</option>)}</Sel>
            <Btn v="danger" className="mb-3" onClick={() => remove(a)}>{t('adm.remove')}</Btn>
          </div>
        </Card>))}
      <Modal open={open} onClose={() => setOpen(false)} title={t('adm.appoint')}>
        <Field label={t('adm.findMember')} value={q} onChange={(e) => setQ(e.target.value)} />
        {cand.map((u) => <button key={u.id} onClick={() => setPick(u)} className={`block w-full text-start rounded-xl p-2 mb-1 border ${pick?.id === u.id ? 'border-forest-700 bg-forest-50' : 'border-cream-200 bg-white'}`}><div className="tight">{u.fullName}</div><div className="text-xs text-gray-500" dir="ltr">{u.memberId} · {u.email}</div></button>)}
        <Sel label={t('adm.role')} value={role} onChange={(e) => setRole(e.target.value)}>{ROLES.map((r) => <option key={r} value={r}>{t('role.' + r)}</option>)}</Sel>
        <Btn full disabled={!pick} onClick={() => pick && grant(pick.id, pick, role)}>{t('adm.appoint')}</Btn>
      </Modal>
    </div>
  );
}
