import { useMemo, useState } from 'react';
import { doc, serverTimestamp, writeBatch } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { useLang } from '../../lib/i18n';
import { useCol } from '../../lib/session';
import type { Profile } from '../../lib/session';
import { audit, fmtDate } from '../../lib/util';
import { Badge, Btn, Card, Empty, ErrorBox, Field, H, Modal, Sel, Spinner, useUi } from '../../components/ui';
import { POSITIONS, posLabel } from '../Member';

export function AdminMembers() {
  const { t, lang } = useLang(); const { toast } = useUi();
  const { data, loading, error } = useCol<Profile>('users', 'all');
  const [q, setQ] = useState(''); const [edit, setEdit] = useState<(Profile & { id: string }) | null>(null);
  const [status, setStatus] = useState('active'); const [pos, setPos] = useState(''); const [custom, setCustom] = useState('');
  const list = useMemo(() => data.filter((m) => (m.fullName + m.email + m.phone + m.memberId).toLowerCase().includes(q.toLowerCase())).sort((a, b) => a.fullName.localeCompare(b.fullName)), [data, q]);
  const open = (m: Profile & { id: string }) => {
    setEdit(m); setStatus(m.status);
    const p = m.position || ''; const known = (POSITIONS as readonly string[]).includes(p);
    setPos(known ? p : p ? 'other' : ''); setCustom(known ? '' : p);
  };
  const save = async () => {
    if (!edit) return;
    const position = pos === 'other' ? custom.trim() : pos;
    try {
      const b = writeBatch(db);
      b.update(doc(db, 'users', edit.id), { status, position, updatedAt: serverTimestamp() });
      b.update(doc(db, 'member_directory', edit.id), { status, position });
      await b.commit(); audit('member_updated', `users/${edit.id}`, `${status}|${position}`); toast(t('common.saved')); setEdit(null);
    } catch { toast(t('err.generic')); }
  };
  return (
    <div>
      <H sub={`${data.length}`}>{t('adm.members')}</H>
      <Field label={t('common.search')} value={q} onChange={(e) => setQ(e.target.value)} />
      <ErrorBox code={error} />
      {loading ? <Spinner /> : list.length === 0 ? <Empty text={t('empty.members')} /> : list.map((m) => (
        <Card key={m.id} className="mb-2" >
          <div className="flex justify-between items-start gap-2">
            <div className="min-w-0"><div className="font-semibold tight">{m.fullName}</div>
              <div className="text-xs text-gray-500" dir="ltr">{m.memberId} · {m.phone}</div><div className="text-xs text-gray-500 truncate" dir="ltr">{m.email}</div>
              <div className="text-xs text-gray-400">{fmtDate(m.createdAt, lang)}</div></div>
            <div className="text-end space-y-1"><Badge tone={m.status === 'active' ? 'green' : 'red'}>{t('member.status.' + m.status)}</Badge>
              {m.position && <div><Badge tone="gold">{posLabel(t, m.position)}</Badge></div>}
              <div><Btn v="ghost" onClick={() => open(m)}>{t('common.edit')}</Btn></div></div>
          </div>
        </Card>))}
      <Modal open={!!edit} onClose={() => setEdit(null)} title={edit?.fullName || ''}>
        <Sel label={t('member.status')} value={status} onChange={(e) => setStatus(e.target.value)}>
          {['active', 'inactive', 'suspended'].map((s) => <option key={s} value={s}>{t('member.status.' + s)}</option>)}</Sel>
        <Sel label={t('com.position')} value={pos} onChange={(e) => setPos(e.target.value)}>
          <option value="">—</option>{POSITIONS.map((p) => <option key={p} value={p}>{t('pos.' + p)}</option>)}</Sel>
        {pos === 'other' && <Field label={t('com.customTitle')} value={custom} onChange={(e) => setCustom(e.target.value)} />}
        <p className="text-xs text-gray-500 mb-3">{t('adm.noAutoSuspend')}</p>
        <Btn full onClick={save}>{t('common.save')}</Btn>
      </Modal>
    </div>
  );
}
