import { useState } from 'react';
import { addDoc, collection, deleteDoc, doc, serverTimestamp, updateDoc } from 'firebase/firestore';
import { auth, db } from '../../lib/firebase';
import { useLang, Lang } from '../../lib/i18n';
import { useCol, useSession } from '../../lib/session';
import { audit, fmtDate } from '../../lib/util';
import { Area, Badge, Btn, Card, Empty, ErrorBox, Field, H, Modal, Spinner, useUi } from '../../components/ui';
import { L4Text, pickText } from '../Member';

interface Ann { title: L4Text; content: L4Text; imageUrl?: string; status: 'draft' | 'published'; publishedAt?: unknown; authorId: string }

export function AdminAnnouncements() {
  const { t, lang } = useLang(); const { toast, confirm } = useUi(); const { profile } = useSession();
  const { data, loading, error } = useCol<Ann>('announcements', 'all');
  const [edit, setEdit] = useState<(Partial<Ann> & { id?: string }) | null>(null);
  const [tl, setTl] = useState<Lang>(lang);
  const list = [...data].sort((a, b) => ((b.publishedAt as { toMillis?: () => number })?.toMillis?.() || 9e15) - ((a.publishedAt as { toMillis?: () => number })?.toMillis?.() || 9e15));
  const setField = (k: 'title' | 'content', v: string) => setEdit((e) => ({ ...e, [k]: { ...(e?.[k] || {}), [tl]: v } }));

  const save = async (status: 'draft' | 'published') => {
    if (!edit) return;
    const has = Object.values(edit.title || {}).some((x) => x?.trim());
    if (!has) return toast(t('err.required'));
    const uid = auth.currentUser!.uid; const wasPublished = edit.status === 'published';
    const body: Record<string, unknown> = { title: edit.title || {}, content: edit.content || {}, imageUrl: edit.imageUrl || '', status, updatedAt: serverTimestamp() };
    if (status === 'published' && !wasPublished) body.publishedAt = serverTimestamp();
    try {
      if (edit.id) await updateDoc(doc(db, 'announcements', edit.id), body);
      else await addDoc(collection(db, 'announcements'), { ...body, authorId: uid, authorName: profile?.fullName || '', createdAt: serverTimestamp() });
      if (status === 'published' && !wasPublished) audit('announcement_published', edit.id ? `announcements/${edit.id}` : 'announcements');
      toast(t('common.saved')); setEdit(null);
    } catch { toast(t('err.generic')); }
  };
  const toggle = async (a: Ann & { id: string }) => {
    try {
      if (a.status === 'published') { await updateDoc(doc(db, 'announcements', a.id), { status: 'draft', updatedAt: serverTimestamp() }); audit('announcement_unpublished', `announcements/${a.id}`); }
      else { await updateDoc(doc(db, 'announcements', a.id), { status: 'published', publishedAt: serverTimestamp(), updatedAt: serverTimestamp() }); audit('announcement_published', `announcements/${a.id}`); }
    } catch { toast(t('err.generic')); }
  };
  const del = async (a: { id: string }) => { if (await confirm(t('common.deleteConfirm'))) { try { await deleteDoc(doc(db, 'announcements', a.id)); audit('announcement_deleted', `announcements/${a.id}`); } catch { toast(t('err.generic')); } } };

  return (
    <div>
      <H>{t('adm.announcements')}</H>
      <Btn className="mb-3" onClick={() => { setEdit({ title: {}, content: {}, status: 'draft' }); setTl(lang); }}>+ {t('common.new')}</Btn>
      <ErrorBox code={error} />
      {loading ? <Spinner /> : list.length === 0 ? <Empty text={t('empty.announcements')} /> : list.map((a) => (
        <Card key={a.id} className="mb-2">
          <div className="flex justify-between gap-2"><div className="font-semibold tight">{pickText(a.title, lang)}</div><Badge tone={a.status === 'published' ? 'green' : 'gray'}>{t('ann.' + a.status)}</Badge></div>
          <div className="text-xs text-gray-400">{fmtDate(a.publishedAt, lang)}</div>
          <div className="flex gap-2 mt-2 flex-wrap"><Btn v="ghost" onClick={() => { setEdit(a); setTl(lang); }}>{t('common.edit')}</Btn>
            <Btn v="ghost" onClick={() => toggle(a)}>{a.status === 'published' ? t('ann.unpublish') : t('ann.publish')}</Btn><Btn v="danger" onClick={() => del(a)}>{t('common.delete')}</Btn></div>
        </Card>))}
      <Modal open={!!edit} onClose={() => setEdit(null)} title={t('adm.announcements')}>
        <div className="mb-3"><div className="text-xs text-gray-500 mb-1">{t('ann.editingLang')}</div>
          <div className="flex gap-1 flex-wrap">{(['bn', 'en', 'ur', 'ar'] as Lang[]).map((c) => <button key={c} onClick={() => setTl(c)} className={`px-3 py-1 rounded-full text-sm border ${tl === c ? 'bg-forest-700 text-white' : 'bg-white'}`}>{{ bn: 'বাংলা', en: 'English', ur: 'اردو', ar: 'العربية' }[c]}</button>)}</div></div>
        <Field label={t('ann.title')} dir={tl === 'ur' || tl === 'ar' ? 'rtl' : 'ltr'} value={edit?.title?.[tl] || ''} onChange={(e) => setField('title', e.target.value)} />
        <Area label={t('ann.content')} dir={tl === 'ur' || tl === 'ar' ? 'rtl' : 'ltr'} rows={7} value={edit?.content?.[tl] || ''} onChange={(e) => setField('content', e.target.value)} />
        <Field label={t('ann.imageUrl')} dir="ltr" placeholder="https://" value={edit?.imageUrl || ''} onChange={(e) => setEdit({ ...edit, imageUrl: e.target.value })} />
        <div className="flex gap-2"><Btn full v="ghost" onClick={() => save('draft')}>{t('ann.saveDraft')}</Btn><Btn full onClick={() => save('published')}>{t('ann.publish')}</Btn></div>
      </Modal>
    </div>
  );
}
