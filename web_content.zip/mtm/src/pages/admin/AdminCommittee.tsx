import { useState } from 'react';
import { addDoc, collection, deleteDoc, doc, serverTimestamp, updateDoc } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { useLang } from '../../lib/i18n';
import { useCol } from '../../lib/session';
import { audit } from '../../lib/util';
import { Btn, Card, ErrorBox, Field, H, Modal, Sel, Spinner, useUi } from '../../components/ui';
import { Official, OfficialList, POSITIONS } from '../Member';

type Edit = Partial<Official> & { id?: string };
export function AdminCommittee() {
  const { t } = useLang(); const { toast, confirm } = useUi();
  const [tab, setTab] = useState<'committee_members' | 'advisory_council'>('committee_members');
  const { data, loading, error } = useCol<Official>(tab, tab);
  const [edit, setEdit] = useState<Edit | null>(null);
  const currentCount = data.filter((m) => m.status === 'current').length;
  const set = (k: keyof Official, v: string) => setEdit((e) => ({ ...e, [k]: v }));
  const save = async () => {
    if (!edit?.name?.trim()) return toast(t('err.required'));
    const body = { name: edit.name.trim(), position: edit.position || 'member', customTitle: edit.customTitle || '', committeeYear: edit.committeeYear || '', appointmentDate: edit.appointmentDate || '', termStart: edit.termStart || '', termEnd: edit.termEnd || '', status: edit.status || 'current', updatedAt: serverTimestamp() };
    try {
      if (edit.id) await updateDoc(doc(db, tab, edit.id), body); else await addDoc(collection(db, tab), { ...body, createdAt: serverTimestamp() });
      audit('committee_updated', tab, body.name); toast(t('common.saved')); setEdit(null);
    } catch { toast(t('err.generic')); }
  };
  const del = async () => { if (edit?.id && (await confirm(t('common.deleteConfirm')))) { try { await deleteDoc(doc(db, tab, edit.id)); audit('committee_updated', tab, 'deleted'); setEdit(null); } catch { toast(t('err.generic')); } } };
  return (
    <div>
      <H sub={tab === 'committee_members' ? `${currentCount} / 15 ${t('com.current')}` : undefined}>{t('adm.committee')}</H>
      <div className="flex gap-2 mb-3"><Btn v={tab === 'committee_members' ? 'primary' : 'ghost'} onClick={() => setTab('committee_members')}>{t('com.executive')}</Btn><Btn v={tab === 'advisory_council' ? 'primary' : 'ghost'} onClick={() => setTab('advisory_council')}>{t('com.advisory')}</Btn></div>
      <Btn className="mb-3" onClick={() => setEdit({ status: 'current', position: tab === 'advisory_council' ? 'other' : 'member' })}>+ {t('common.new')}</Btn>
      <ErrorBox code={error} />
      {loading ? <Spinner /> : <>{data.map((m) => (<div key={m.id} onClick={() => setEdit(m)}><OfficialList items={[m]} /><p className="text-xs text-gray-400 -mt-1 mb-2">{t('com.' + m.status)} · {t('common.tapEdit')}</p></div>))}{!data.length && <Card className="text-center text-gray-400">{t('empty.committee')}</Card>}</>}
      <Modal open={!!edit} onClose={() => setEdit(null)} title={t('adm.committee')}>
        <Field label={t('common.name')} value={edit?.name || ''} onChange={(e) => set('name', e.target.value)} />
        <Sel label={t('com.position')} value={edit?.position || 'member'} onChange={(e) => set('position', e.target.value)}>{POSITIONS.map((p) => <option key={p} value={p}>{t('pos.' + p)}</option>)}</Sel>
        <Field label={t('com.customTitle')} value={edit?.customTitle || ''} onChange={(e) => set('customTitle', e.target.value)} />
        <Field label={t('com.year')} value={edit?.committeeYear || ''} onChange={(e) => set('committeeYear', e.target.value)} placeholder="1448 / 2026-27" />
        <Field label={t('com.appointmentDate')} type="date" value={edit?.appointmentDate || ''} onChange={(e) => set('appointmentDate', e.target.value)} />
        <div className="grid grid-cols-2 gap-2"><Field label={t('com.termStart')} type="date" value={edit?.termStart || ''} onChange={(e) => set('termStart', e.target.value)} /><Field label={t('com.termEnd')} type="date" value={edit?.termEnd || ''} onChange={(e) => set('termEnd', e.target.value)} /></div>
        <Sel label={t('member.status')} value={edit?.status || 'current'} onChange={(e) => set('status', e.target.value)}><option value="current">{t('com.current')}</option><option value="former">{t('com.former')}</option></Sel>
        <Btn full onClick={save}>{t('common.save')}</Btn>
        {edit?.id && <Btn full v="danger" className="mt-2" onClick={del}>{t('common.delete')}</Btn>}
      </Modal>
    </div>
  );
}
