import { limit, orderBy } from 'firebase/firestore';
import { useLang } from '../../lib/i18n';
import { useCol } from '../../lib/session';
import { fmtDate } from '../../lib/util';
import { Card, Empty, ErrorBox, H, Spinner } from '../../components/ui';

export function AdminAudit() {
  const { t, lang } = useLang();
  const { data, loading, error } = useCol<{ action: string; uid: string; ref: string; detail: string; createdAt?: { toDate(): Date } }>('audit_logs', 'l100', orderBy('createdAt', 'desc'), limit(100));
  return (
    <div>
      <H>{t('adm.audit')}</H><ErrorBox code={error} />
      {loading ? <Spinner /> : !data.length ? <Empty text={t('empty.activity')} /> : data.map((l) => (
        <Card key={l.id} className="mb-2 text-sm">
          <div className="flex justify-between"><b>{t('audit.' + l.action) === 'audit.' + l.action ? l.action : t('audit.' + l.action)}</b><span className="text-gray-400 text-xs">{fmtDate(l.createdAt, lang)}{l.createdAt ? ' ' + l.createdAt.toDate().toLocaleTimeString() : ''}</span></div>
          <div className="text-xs text-gray-500 break-all" dir="ltr">{l.uid.slice(0, 8)} · {l.ref}{l.detail ? ' · ' + l.detail : ''}</div>
        </Card>))}
    </div>
  );
}
