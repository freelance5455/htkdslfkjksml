import { limit, orderBy, where } from 'firebase/firestore';
import { Link } from 'react-router-dom';
import { useLang } from '../../lib/i18n';
import { useCol, useSession } from '../../lib/session';
import { fmtDate, fmtMoney, periodOf } from '../../lib/util';
import { Card, H, Spinner, Empty } from '../../components/ui';
import { pickText } from '../Member';

const Stat = ({ label, value }: { label: string; value: string | number }) => (
  <Card><div className="text-xs text-gray-500 tight">{label}</div><div className="text-2xl font-semibold text-forest-800">{value}</div></Card>
);
function FinanceStats() {
  const { t } = useLang();
  const tx = useCol<{ type: string; amount: number }>('financial_transactions', 'all');
  const paid = useCol<{ amount: number }>('contributions', 'p' + periodOf(), where('period', '==', periodOf()));
  if (tx.loading) return <Spinner />;
  const inc = tx.data.filter((x) => x.type === 'income').reduce((s, x) => s + x.amount, 0);
  const exp = tx.data.filter((x) => x.type === 'expense').reduce((s, x) => s + x.amount, 0);
  return (
    <>
      <Stat label={t('adm.paidThisMonth')} value={`${paid.data.length} · ${fmtMoney(paid.data.reduce((s, c) => s + c.amount, 0))}`} />
      <Stat label={t('fin.income')} value={fmtMoney(inc)} /><Stat label={t('fin.expense')} value={fmtMoney(exp)} />
      <Stat label={t('fin.balance')} value={fmtMoney(inc - exp)} />
    </>
  );
}
function Recent() {
  const { t, lang } = useLang();
  const { canContent } = useSession();
  const a = useCol<{ title: Record<string, string>; status: string; publishedAt?: unknown }>(canContent ? 'announcements' : null, 'recent', limit(30));
  if (!canContent) return null;
  const list = a.data.filter((x) => x.status === 'published').slice(0, 3);
  return (<><div className="font-semibold text-forest-800 mt-5 mb-2">{t('adm.recentAnn')}</div>
    {list.length ? list.map((x) => <Card key={x.id} className="mb-2 text-sm">{pickText(x.title, lang)} <span className="text-gray-400">· {fmtDate(x.publishedAt, lang)}</span></Card>) : <Empty text={t('empty.announcements')} />}</>);
}
function Activity() {
  const { t, lang } = useLang();
  const { canManage } = useSession();
  const l = useCol<{ action: string; uid: string; createdAt?: unknown }>(canManage ? 'audit_logs' : null, 'recent5', orderBy('createdAt', 'desc'), limit(5));
  if (!canManage) return null;
  return (<><div className="font-semibold text-forest-800 mt-5 mb-2">{t('adm.recentActivity')}</div>
    {l.data.length ? l.data.map((x) => <Card key={x.id} className="mb-2 text-sm flex justify-between"><span>{t('audit.' + x.action) === 'audit.' + x.action ? x.action : t('audit.' + x.action)}</span><span className="text-gray-400">{fmtDate(x.createdAt, lang)}</span></Card>) : <Empty text={t('empty.activity')} />}</>);
}
export function AdminHome() {
  const { t } = useLang();
  const s = useSession();
  const dir = useCol<{ status: string }>('member_directory', 'all');
  const ec = useCol<{ status: string }>('committee_members', 'ec');
  return (
    <div>
      <H>{t('adm.dashboard')}</H>
      <div className="grid grid-cols-2 gap-3">
        <Stat label={t('adm.totalMembers')} value={dir.loading ? '…' : dir.data.length} />
        <Stat label={t('adm.activeMembers')} value={dir.loading ? '…' : dir.data.filter((m) => m.status === 'active').length} />
        <Stat label={t('adm.currentCommittee')} value={`${ec.data.filter((m) => m.status === 'current').length} / 15`} />
        {s.canFinance && <FinanceStats />}
      </div>
      <Recent /><Activity />
      <div className="grid grid-cols-2 gap-2 mt-5">
        {s.canFinance && <Link to="/admin/contributions" className="bg-forest-700 text-white rounded-xl p-3 text-center tight">{t('adm.contributions')}</Link>}
        {s.canFinance && <Link to="/admin/finance" className="bg-forest-700 text-white rounded-xl p-3 text-center tight">{t('adm.finance')}</Link>}
        {s.canContent && <Link to="/admin/announcements" className="bg-forest-700 text-white rounded-xl p-3 text-center tight">{t('adm.announcements')}</Link>}
      </div>
    </div>
  );
}
