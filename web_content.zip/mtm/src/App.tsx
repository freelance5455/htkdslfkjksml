import { useEffect, useState } from 'react';
import { Navigate, Route, Routes, useLocation, useNavigate } from 'react-router-dom';
import { Capacitor } from '@capacitor/core';
import { App as CapApp } from '@capacitor/app';
import { StatusBar, Style } from '@capacitor/status-bar';
import { SplashScreen } from '@capacitor/splash-screen';
import { useSession } from './lib/session';
import { useLang } from './lib/i18n';
import { firebaseConfigured } from './lib/firebase';
import { Logo } from './components/Logo';
import { MemberLayout, AdminLayout } from './components/Layouts';
import { Login, Register, Reset } from './pages/Auth';
import { Home, Profile, Directory, BaitulMaal, MyContributions, ConstitutionPage, RulesPage, Announcements, Committee, Donate, Contact, Settings, More } from './pages/Member';
import { AdminHome } from './pages/admin/AdminHome';
import { AdminMembers } from './pages/admin/AdminMembers';
import { AdminContributions } from './pages/admin/AdminContributions';
import { AdminFinance } from './pages/admin/AdminFinance';
import { AdminAnnouncements } from './pages/admin/AdminAnnouncements';
import { AdminCommittee } from './pages/admin/AdminCommittee';
import { AdminAdmins } from './pages/admin/AdminAdmins';
import { AdminSettings } from './pages/admin/AdminSettings';
import { AdminAudit } from './pages/admin/AdminAudit';

function Splash() {
  return (
    <div className="min-h-screen bg-forest-900 flex flex-col items-center justify-center text-white gap-4">
      <Logo size={120} /><div className="text-lg tracking-wide">MTM Foundation</div>
      <div className="h-6 w-6 rounded-full border-2 border-gold-400 border-t-transparent animate-spin" />
    </div>
  );
}
function Guard({ ok, to = '/', children }: { ok: boolean; to?: string; children: JSX.Element }) { return ok ? children : <Navigate to={to} replace />; }

export default function App() {
  const s = useSession();
  const { t } = useLang();
  const nav = useNavigate();
  const loc = useLocation();
  const [online, setOnline] = useState(navigator.onLine);

  useEffect(() => {
    const on = () => setOnline(true), off = () => setOnline(false);
    window.addEventListener('online', on); window.addEventListener('offline', off);
    return () => { window.removeEventListener('online', on); window.removeEventListener('offline', off); };
  }, []);

  useEffect(() => {
    if (!Capacitor.isNativePlatform()) return;
    StatusBar.setStyle({ style: Style.Dark }).catch(() => undefined);
    StatusBar.setBackgroundColor({ color: '#153d28' }).catch(() => undefined);
    SplashScreen.hide().catch(() => undefined);
  }, []);

  // Android back button: go back in history, exit only from a root screen.
  useEffect(() => {
    if (!Capacitor.isNativePlatform()) return;
    const h = CapApp.addListener('backButton', () => {
      const root = ['/', '/login'].includes(loc.pathname);
      if (root) CapApp.exitApp(); else nav(-1);
    });
    return () => { h.then((x) => x.remove()); };
  }, [loc.pathname, nav]);

  if (!firebaseConfigured) {
    return <div className="p-6 text-center"><Logo size={90} /><p className="mt-4 text-red-700">Firebase is not configured. Copy .env.example to .env, fill the values and rebuild (see README).</p></div>;
  }
  if (!s.ready) return <Splash />;

  const banner = !online && <div className="bg-red-600 text-white text-center text-xs py-1" style={{ paddingTop: 'calc(0.25rem + var(--safe-top))' }}>{t('err.offline')}</div>;

  if (!s.user) {
    return (<>{banner}<Routes>
      <Route path="/register" element={<Register />} />
      <Route path="/reset" element={<Reset />} />
      <Route path="*" element={<Login />} />
    </Routes></>);
  }
  if (!s.profile) return <Splash />;
  if (s.profile.status !== 'active') {
    return <div className="p-8 text-center"><Logo size={90} /><p className="mt-4">{t('auth.inactive')}</p><Login logoutOnly /></div>;
  }
  return (<>{banner}
    <Routes>
      <Route element={<MemberLayout />}>
        <Route path="/" element={<Home />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/directory" element={<Directory />} />
        <Route path="/baitulmaal" element={<BaitulMaal />} />
        <Route path="/contributions" element={<MyContributions />} />
        <Route path="/constitution" element={<ConstitutionPage />} />
        <Route path="/rules" element={<RulesPage />} />
        <Route path="/announcements" element={<Announcements />} />
        <Route path="/committee" element={<Committee />} />
        <Route path="/donate" element={<Donate />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/settings" element={<Settings />} />
        <Route path="/more" element={<More />} />
      </Route>
      <Route path="/admin" element={<Guard ok={s.isAdmin}><AdminLayout /></Guard>}>
        <Route index element={<AdminHome />} />
        <Route path="members" element={<Guard ok={s.canManage} to="/admin"><AdminMembers /></Guard>} />
        <Route path="contributions" element={<Guard ok={s.canFinance} to="/admin"><AdminContributions /></Guard>} />
        <Route path="finance" element={<Guard ok={s.canFinance} to="/admin"><AdminFinance /></Guard>} />
        <Route path="announcements" element={<Guard ok={s.canContent} to="/admin"><AdminAnnouncements /></Guard>} />
        <Route path="committee" element={<Guard ok={s.canManage} to="/admin"><AdminCommittee /></Guard>} />
        <Route path="admins" element={<Guard ok={s.isOwner} to="/admin"><AdminAdmins /></Guard>} />
        <Route path="settings" element={<Guard ok={s.isOwner} to="/admin"><AdminSettings /></Guard>} />
        <Route path="audit" element={<Guard ok={s.canManage} to="/admin"><AdminAudit /></Guard>} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes></>);
}
