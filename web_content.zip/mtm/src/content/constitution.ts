// Official MTM Foundation document. Arabic and Urdu text is the ORIGINAL source, preserved verbatim.
// English / Bengali / Arabic-of-Urdu-clauses are faithful translations flagged `needsReview`.
export type L4 = { en: string[]; bn: string[]; ar: string[] };
export interface Clause extends L4 { n: string; ur: string[] }
export interface Chapter {
  id: string;
  title: { en: string; bn: string; ur: string; ar: string };
  clauses: Clause[];
  note?: { ur: string; en: string; bn: string; ar: string };
}

export const needsReview = true;

export const openingArabic: string[] = [
  'بسم الله الرحمن الرحيم',
  'مؤسسة الطلاب المسلمين',
  'تأسيس: ٧ / ٣ / ١٤٤٨هـ',
  'الموافق: ٢٠ / ٨ / ٢٠٢٦م',
  'الحمد لله الذي أمرنا بالاعتصام والوحدة، ونهانا عن الاختلاف والفرقة، فقال تعالى:',
  '﴿وَاعْتَصِمُوا بِحَبْلِ اللَّهِ جَمِيعًا وَلَا تَفَرَّقُوا﴾',
  'والصلاة والسلام على النبي الكريم، الذي أرشدنا إلى لزوم الجماعة، وحذّرنا من الفرقة ، فقال صلى الله عليه وسلم:',
  '«عليكم بالجماعة، وإياكم والفرقة»',
  'وقال صلى الله عليه وسلم: «يد الله على الجماعة».',
  'وعلى آله وأصحابه الذين ألّف الله بين قلوبهم، وجعلهم إخوة متحابين متعاونين على البر والتقوى، قال تعالى:',
  '﴿فَأَلَّفَ بَيْنَ قُلُوبِكُمْ فَأَصْبَحْتُمْ بِنِعْمَتِهِ إِخْوَانًا﴾'
];

export const introUrdu: string[] = [
  'جامتلی اور شفیع اللہ کاٹا کے معزز علماء کرام، طلبہ عزیز اور تمام برادرانِ اسلام کی خدمت میں ہماری طرف سے سلامِ مسنون اور دلی دعاؤں کے بعد یہ معروضہ باأدب پیشِ خدمت ہے کہ ہمارے لیے یہ انتہائی خوشی اور مسرت کی بات ہے کہ ہماری قوم و ملت کا درد رکھنے والے چند مخلص بھائیوں کی جان توڑ جدوجہد کے نتیجے میں ایک مؤسسہ وجود میں آیا ہے۔',
  'ہم آپ حضرات سے مؤدبانہ گزارش کرتے ہیں کہ اس مؤسسہ (MTM) میں بھرپور جذبے اور اخلاص کے ساتھ شریک ہو کر دین و ملت کی خدمت میں اپنا حصہ ادا کرنے کی کوشش فرمائیں۔ امید ہے کہ یہ مؤسسہ ہم سب کے لیے باعثِ سعادت اور ملتِ اسلامیہ کے لیے نافع و مفید ثابت ہوگا، إن شاء الله تعالى۔',
  'ہمیں امید ہے کہ آپ حضرات اس عریضے کو غور سے پڑھ کر اس کے مقاصد و اصول کو اچھی طرح سمجھیں گے اور اللہ تعالیٰ کی رضا کے لیے دل سے اسے قبول کرتے ہوئے اس کے فروغ و ترقی میں اپنا کردار ادا فرمائیں گے۔'
];
export const introTr: L4 = {
  en: [
    'To the respected scholars, dear students and all Muslim brothers of Jamtoli and Shofiullahkhata: after the Sunnah greeting and sincere prayers, we humbly present that it is a matter of great joy that, through the tireless efforts of a few sincere brothers who care for their people and community, an organization has come into being.',
    'We respectfully request you to join this organization (MTM) with full enthusiasm and sincerity and to play your part in serving the religion and the community. We hope it will be a source of blessing for all of us and beneficial for the Muslim community, in sha Allah.',
    'We hope you will read this document carefully, understand its objectives and principles well, accept it wholeheartedly for the pleasure of Allah, and play your role in its promotion and progress.'
  ],
  bn: [
    'জামতলী ও শফিউল্লাহকাটার সম্মানিত উলামায়ে কেরাম, প্রিয় ছাত্রবৃন্দ এবং সকল মুসলিম ভাইদের প্রতি সুন্নতী সালাম ও আন্তরিক দোয়ার পর বিনীত নিবেদন এই যে, আমাদের জন্য অত্যন্ত আনন্দের বিষয়, জাতি ও মিল্লাতের জন্য দরদী কয়েকজন নিষ্ঠাবান ভাইয়ের নিরলস প্রচেষ্টার ফলে একটি প্রতিষ্ঠান অস্তিত্ব লাভ করেছে।',
    'আমরা বিনয়ের সাথে আপনাদের অনুরোধ করছি, পূর্ণ উদ্দীপনা ও ইখলাসের সাথে এই প্রতিষ্ঠানে (MTM) শরিক হয়ে দ্বীন ও মিল্লাতের খেদমতে আপনার অংশ আদায়ের চেষ্টা করুন। আশা করি এটি আমাদের সবার জন্য সৌভাগ্যের কারণ এবং মুসলিম উম্মাহর জন্য উপকারী হবে, ইনশাআল্লাহ।',
    'আমরা আশা করি, আপনারা এই পত্রটি মনোযোগ দিয়ে পড়ে এর উদ্দেশ্য ও নীতিমালা ভালোভাবে বুঝবেন এবং আল্লাহ তাআলার সন্তুষ্টির জন্য আন্তরিকভাবে গ্রহণ করে এর প্রসার ও উন্নতিতে ভূমিকা রাখবেন।'
  ],
  ar: [
    'إلى العلماء الكرام والطلبة الأعزاء وجميع الإخوة المسلمين في جامتلي وشفيع الله كاتا: بعد السلام المسنون والدعاء الصادق، نتقدم بكل أدب بأنه من دواعي سرورنا البالغ أن تأسست مؤسسة بفضل جهود مخلصة بذلها بعض الإخوة الحريصين على قومهم وملتهم.',
    'نرجو منكم بكل أدب أن تشاركوا في هذه المؤسسة (MTM) بكامل الحماس والإخلاص، وتسهموا في خدمة الدين والملة. ونأمل أن تكون سبب سعادة لنا جميعًا ونافعة للأمة الإسلامية، إن شاء الله تعالى.',
    'ونأمل أن تقرؤوا هذه الوثيقة بتمعّن، وتفهموا مقاصدها ومبادئها جيدًا، وتقبلوها من القلب ابتغاء رضا الله تعالى، وتؤدوا دوركم في نشرها وتقدمها.'
  ]
};

export const chapters: Chapter[] = [
  {
    id: 'name',
    title: { en: 'First — Name', bn: 'প্রথম — নাম', ur: 'اول — نام', ar: 'أولاً — الاسم' },
    clauses: [
      { n: '', ur: ['مؤسسة الطلاب المسلمين', 'المؤسسة', "Mu'assasatut Tullab Al Muslimeen (MTM)"],
        en: ['Arabic name: مؤسسة الطلاب المسلمين', 'Short name: المؤسسة', "English name: Mu'assasatut Tullab Al Muslimeen (MTM)"],
        bn: ['আরবি নাম: مؤسسة الطلاب المسلمين', 'সংক্ষিপ্ত নাম: المؤسسة', "ইংরেজি নাম: Mu'assasatut Tullab Al Muslimeen (MTM)"],
        ar: ['الاسم: مؤسسة الطلاب المسلمين', 'الاسم المختصر: المؤسسة', "الاسم الإنجليزي: Mu'assasatut Tullab Al Muslimeen (MTM)"] }
    ],
    note: {
      ur: 'The foundation name must not be translated into other languages. Use the original name in every language.',
      en: 'The foundation name is never translated. The original name is used in every language.',
      bn: 'ফাউন্ডেশনের নাম কোনো ভাষায় অনূদিত হয় না। সব ভাষায় মূল নাম ব্যবহৃত হয়।',
      ar: 'لا يُترجم اسم المؤسسة إلى أي لغة، ويُستخدم الاسم الأصلي في كل اللغات.'
    }
  },
  {
    id: 'objective',
    title: { en: 'Second — Objective', bn: 'দ্বিতীয় — উদ্দেশ্য', ur: 'دوم — مقصد', ar: 'ثانياً — الهدف' },
    clauses: [
      { n: '١',
        ur: ['باہمی اتفاق و اتحاد کو برقرار رکھتے ہوئے دینِ اسلام کی حفاظت، سماجی خدمات اور ملتِ اسلامیہ کی جائز و ضروری حاجات میں حتی المقدور تعاون، أمت مسلمہ سے ہر منکرات کو دفع کرکے اللہ تعالیٰ کی رضا و خوشنودی حاصل کرنا۔'],
        en: ['To preserve mutual harmony and unity; to protect the religion of Islam; to provide social services and, as far as possible, help with the legitimate and necessary needs of the Muslim community; and to seek the pleasure of Allah by removing all evils from the Muslim Ummah.'],
        bn: ['পারস্পরিক ঐক্য ও সম্প্রীতি বজায় রেখে ইসলাম ধর্মের হেফাজত, সামাজিক সেবা এবং মিল্লাতে ইসলামিয়ার বৈধ ও প্রয়োজনীয় চাহিদায় যথাসাধ্য সহযোগিতা করা এবং উম্মতে মুসলিমা থেকে সকল অন্যায় দূর করে আল্লাহ তাআলার সন্তুষ্টি অর্জন করা।'],
        ar: ['الحفاظ على الاتفاق والوحدة بين الأعضاء، وحماية دين الإسلام، والخدمات الاجتماعية، والتعاون قدر الإمكان في الحاجات المشروعة والضرورية للأمة الإسلامية، ودفع المنكرات عن الأمة المسلمة ابتغاء رضا الله تعالى.'] }
    ],
    note: {
      ur: 'یہ ایک غیر سیاسی انجمن ہے جس کا ہر کام قرآن و سنت کے موافق انجام دئے جاتے ہیں اور مذکورہ ہدف کو سامنے رکھتے ہوئے تاسیس کیا گیا ہے۔',
      en: 'This is a non-political association; every activity is carried out in accordance with the Qur\'an and Sunnah, and it was founded with the above objective in view.',
      bn: 'এটি একটি অরাজনৈতিক সংগঠন; এর প্রতিটি কাজ কুরআন ও সুন্নাহ অনুযায়ী সম্পন্ন হয় এবং উপরোক্ত লক্ষ্য সামনে রেখেই এটি প্রতিষ্ঠিত।',
      ar: 'هذه جمعية غير سياسية، تُنجَز جميع أعمالها وفق القرآن والسنة، وقد أُسست مراعاةً للهدف المذكور.'
    }
  },
  {
    id: 'membership',
    title: { en: 'Third — Membership Conditions', bn: 'তৃতীয় — সদস্যপদের শর্তাবলি', ur: 'سوم — رکنیت کی شرائط', ar: 'ثالثاً — شروط العضوية' },
    clauses: [
      { n: '١', ur: ['غیرِ معصیت اور جائز امور میں امیر کی اطاعت کرنا لازم ہوگا۔'],
        en: ['Obeying the Amir in matters that are lawful and not disobedience to Allah is obligatory.'],
        bn: ['পাপমুক্ত ও বৈধ বিষয়ে আমীরের আনুগত্য করা আবশ্যক।'],
        ar: ['تجب طاعة الأمير في الأمور المشروعة التي ليس فيها معصية.'] },
      { n: '٢', ur: ['تمام اراکین کے درمیان بغض، عداوت، باہمی نزاع , فساد اور تمام سیاسی منظمات سے اجتناب لازم ہوگا؛ کیونکہ یہ چیزیں اختلاف و تفرقے کا سبب بنتی ہیں۔ ہر ایسے عمل سے گریز کیا جائے گا جو فتنے کو جنم دے، مؤسسہ کی وحدت کو کمزور کرے یا اس کے مقاصد کو نقصان پہنچائے۔ خصوصاً کسی فرد کو یہ حق نہیں ہوگا کہ وہ اپنی ذاتی دشمنی، ناراضی یا نفرت کو مؤسسہ کے اجتماعی معاملات میں داخل کرے۔'],
        en: ['Members must avoid hatred, enmity, mutual quarrels, corruption and all political organizations, because these cause disagreement and division. Every act that gives rise to discord, weakens the unity of the foundation or harms its objectives will be avoided. In particular, no individual has the right to bring personal enmity, resentment or hatred into the collective affairs of the foundation.'],
        bn: ['সকল সদস্যের মধ্যে বিদ্বেষ, শত্রুতা, পারস্পরিক কলহ, ফাসাদ এবং সব রাজনৈতিক সংগঠন থেকে বিরত থাকা আবশ্যক; কারণ এগুলো মতবিরোধ ও বিভেদের কারণ হয়। যে কাজ ফিতনা সৃষ্টি করে, প্রতিষ্ঠানের ঐক্য দুর্বল করে বা এর উদ্দেশ্যের ক্ষতি করে তা থেকে বিরত থাকা হবে। বিশেষত কোনো ব্যক্তির এই অধিকার থাকবে না যে সে নিজের ব্যক্তিগত শত্রুতা, অসন্তোষ বা ঘৃণা প্রতিষ্ঠানের সম্মিলিত বিষয়ে প্রবেশ করাবে।'],
        ar: ['يجب على جميع الأعضاء الابتعاد عن البغض والعداوة والنزاع والفساد وعن جميع التنظيمات السياسية، لأنها سبب الاختلاف والفرقة. ويُجتنب كل عمل يثير الفتنة أو يضعف وحدة المؤسسة أو يضر بمقاصدها. وليس لأي فرد الحق في إدخال عداوته الشخصية أو سخطه أو بغضه في الشؤون الجماعية للمؤسسة.'] },
      { n: '٣', ur: ['اگر کسی رکن کو کسی مجبوری کی وجہ سے مؤسسہ سے علیحدگی اختیار کرنا پڑے تو اس کے جانب سے پہلے ادا کیے گئے بیت المال کی واپسی کا مطالبہ نہیں کیا جائے گا، کیونکہ یہ رقم دینِ اسلام اور مسلمانوں کی خدمت کے لیے بطورِ صدقہ ادا کی گئی ہوگی۔ تاہم اگر کوئی رکن اپنے ادا کردہ بیت المال کا حساب دیکھنا چاہے تو متعلقہ ذمہ دار حضرات اس کے لیے حتی المقدور حساب پیش کرنے کے پابند ہوں گے۔'],
        en: ['If a member has to leave the foundation due to some compulsion, no refund of the Baitul Maal previously paid will be demanded, because this money was given as sadaqah for the service of Islam and Muslims. However, if a member wishes to see the account of the Baitul Maal he paid, the responsible persons are bound to present the account as far as possible.'],
        bn: ['কোনো সদস্য যদি বাধ্য হয়ে প্রতিষ্ঠান ত্যাগ করেন, তবে তাঁর পূর্বে প্রদত্ত বাইতুল মাল ফেরত চাওয়া যাবে না; কারণ এই অর্থ দ্বীন ইসলাম ও মুসলমানদের খেদমতে সদকা হিসেবে প্রদান করা হয়েছে। তবে কোনো সদস্য তাঁর প্রদত্ত বাইতুল মালের হিসাব দেখতে চাইলে সংশ্লিষ্ট দায়িত্বশীলগণ যথাসাধ্য হিসাব পেশ করতে বাধ্য থাকবেন।'],
        ar: ['إذا اضطر عضو إلى مفارقة المؤسسة لعذر، فلا يُطالَب برد ما دفعه سابقًا إلى بيت المال، لأن هذا المال دُفع صدقةً لخدمة دين الإسلام والمسلمين. لكن إن أراد العضو الاطلاع على حساب ما دفعه فالمسؤولون ملزمون بتقديم الحساب قدر الإمكان.'] },
      { n: '٤', ur: ['ہر رکن کے لیے ہر ماہ مقررہ بیت المال ادا کرنا لازم ہوگا۔'],
        en: ['Every member must pay the fixed Baitul Maal every month.'],
        bn: ['প্রত্যেক সদস্যের জন্য প্রতি মাসে নির্ধারিত বাইতুল মাল প্রদান করা আবশ্যক।'],
        ar: ['يجب على كل عضو دفع بيت المال المقرر كل شهر.'] }
    ]
  },
  {
    id: 'administration',
    title: { en: 'Fourth — Administration and Organizational Guidelines', bn: 'চতুর্থ — প্রশাসন ও সাংগঠনিক নির্দেশনা', ur: 'چہارم — انتظامی و تنظیمی ہدایات', ar: 'رابعاً — الإدارة والتوجيهات التنظيمية' },
    clauses: [
      { n: '١', ur: ['مؤسسہ میں امیر، نائب امیر، صدر، دو مسؤولین اور دیگر اراکین پر مشتمل کل ۱۵ رکنی انتظامی کمیٹی ہوگی۔ مؤسسہ کی تمام انتظامی و سرکاری ذمہ داریاں اس کمیٹی کے سپرد ہوں گی۔'],
        en: ['The foundation will have an executive committee of 15 members in total, consisting of the Amir, Naib Amir, Sadr, two Mas\'uls and other members. All administrative and official responsibilities of the foundation are entrusted to this committee.'],
        bn: ['প্রতিষ্ঠানে আমীর, নায়েবে আমীর, সদর, দুইজন মাসউল ও অন্যান্য সদস্য নিয়ে মোট ১৫ সদস্যবিশিষ্ট একটি নির্বাহী কমিটি থাকবে। প্রতিষ্ঠানের সকল প্রশাসনিক ও দাপ্তরিক দায়িত্ব এই কমিটির উপর ন্যস্ত থাকবে।'],
        ar: ['تكون في المؤسسة لجنة إدارية من ١٥ عضوًا تضم الأمير ونائب الأمير والصدر ومسؤولَين وسائر الأعضاء، وتُسند إليها جميع المسؤوليات الإدارية والرسمية للمؤسسة.'] },
      { n: '٢', ur: ['مؤسسہ میں ایک مجلسِ مشاورت (المجلس الاستشاري) ہوگی، جو مختلف اہم معاملات میں رہنمائی، مشاورت اور فیصلہ سازی میں معاونت کرے گی۔'],
        en: ['The foundation will have an Advisory Council (المجلس الاستشاري) that will provide guidance, consultation and assistance in decision-making in various important matters.'],
        bn: ['প্রতিষ্ঠানে একটি উপদেষ্টা পরিষদ (المجلس الاستشاري) থাকবে, যা বিভিন্ন গুরুত্বপূর্ণ বিষয়ে দিকনির্দেশনা, পরামর্শ ও সিদ্ধান্ত গ্রহণে সহায়তা করবে।'],
        ar: ['يكون في المؤسسة مجلس استشاري (المجلس الاستشاري) يقدّم التوجيه والمشورة ويعين على اتخاذ القرار في الأمور المهمة.'] },
      { n: '٣', ur: [
          'مؤسسہ کا کوئی بھی منصب دائمی نہیں ہوگا، خواہ وہ امارت ہو، صدارت ہو یا کوئی دوسری ذمہ داری۔ ہر منصب کی مدت ایک سال ہوگی۔',
          'ہر سال عید الفطر کے موقع پر ایک عمومی اجلاس (مجلسِ عمومی) منعقد ہوگا، جس میں گزشتہ سال کے مکمل حسابات پیش کیے جائیں گے اور آئندہ سال کے لیے مختلف مناصب کے ذمہ داران اراکین کی رائے اور باہمی مشاورت سے منتخب کیے جائیں گے۔',
          'سابقہ ذمہ داران کو دوبارہ اسی منصب پر برقرار رکھنا اگر مجلس کی مصلحت اور مؤسسہ کے مفاد میں مناسب سمجھا جائے تو انہیں دوبارہ منتخب کیا جا سکتا ہے، بصورتِ دیگر نئے ذمہ داران منتخب کیے جائیں گے۔'],
        en: ['No position in the foundation is permanent, whether Amir, President (Sadr) or any other responsibility. The term of every position is one year.',
             'Every year on the occasion of Eid al-Fitr a General Assembly (Majlis-e-Umumi) will be held, in which the full accounts of the previous year will be presented and office-bearers for the coming year will be chosen with the opinion and mutual consultation of the members.',
             'If it is considered appropriate in the interest of the assembly and the foundation, previous office-bearers may be re-elected to the same position; otherwise new office-bearers will be chosen.'],
        bn: ['প্রতিষ্ঠানের কোনো পদই স্থায়ী হবে না—তা আমীরাত হোক, সদারত হোক বা অন্য কোনো দায়িত্ব। প্রতিটি পদের মেয়াদ এক বছর।',
             'প্রতি বছর ঈদুল ফিতরের সময় একটি সাধারণ সভা (মজলিসে উমুমী) অনুষ্ঠিত হবে, যেখানে গত বছরের পূর্ণ হিসাব পেশ করা হবে এবং সদস্যদের মতামত ও পারস্পরিক পরামর্শের ভিত্তিতে আগামী বছরের জন্য বিভিন্ন পদের দায়িত্বশীল নির্বাচিত হবেন।',
             'পূর্ববর্তী দায়িত্বশীলদের একই পদে বহাল রাখা মজলিসের কল্যাণ ও প্রতিষ্ঠানের স্বার্থে উপযুক্ত মনে হলে তাঁদের পুনর্নির্বাচিত করা যাবে; অন্যথায় নতুন দায়িত্বশীল নির্বাচিত হবেন।'],
        ar: ['لا يكون أي منصب في المؤسسة دائمًا، سواء كان الإمارة أو الصدارة أو غيرها، ومدة كل منصب سنة واحدة.',
             'يُعقد كل عام في عيد الفطر اجتماع عام (المجلس العمومي) تُعرض فيه الحسابات الكاملة للعام الماضي، ويُنتخب فيه المسؤولون للعام القادم برأي الأعضاء وتشاورهم.',
             'يجوز إعادة انتخاب المسؤولين السابقين في المنصب نفسه إذا رُئي ذلك مناسبًا لمصلحة المجلس والمؤسسة، وإلا انتُخب مسؤولون جدد.'] },
      { n: '٤', ur: ['مؤسسہ کے امیر اہم فیصلے صدر، نائب امیر، مسؤولین اور انتظامی کمیٹی کے باہمی مشورے سے کریں گے۔ انفرادی طور پر اہم اجتماعی فیصلے کرنے سے حتی المقدور اجتناب کیا جائے گا۔'],
        en: ['The Amir will take important decisions in mutual consultation with the Sadr, Naib Amir, Mas\'uls and the executive committee. Taking important collective decisions individually will be avoided as far as possible.'],
        bn: ['প্রতিষ্ঠানের আমীর গুরুত্বপূর্ণ সিদ্ধান্ত সদর, নায়েবে আমীর, মাসউলগণ ও নির্বাহী কমিটির পারস্পরিক পরামর্শে গ্রহণ করবেন। ব্যক্তিগতভাবে গুরুত্বপূর্ণ সম্মিলিত সিদ্ধান্ত নেওয়া থেকে যথাসম্ভব বিরত থাকা হবে।'],
        ar: ['يتخذ أمير المؤسسة القرارات المهمة بالتشاور مع الصدر ونائب الأمير والمسؤولين واللجنة الإدارية، ويُجتنب قدر الإمكان اتخاذ القرارات الجماعية المهمة بصورة فردية.'] },
      { n: '٥', ur: ['ہر ذمہ دار پر لازم ہوگا کہ وہ اپنی ذمہ داری محنت، دیانت، مہارت اور پوری کوشش کے ساتھ ادا کرے اور کسی قسم کی کوتاہی سے گریز کرے۔'],
        en: ['Every office-bearer must discharge his responsibility with hard work, honesty, skill and full effort, and avoid any negligence.'],
        bn: ['প্রত্যেক দায়িত্বশীলের জন্য আবশ্যক যে তিনি পরিশ্রম, আমানতদারি, দক্ষতা ও পূর্ণ প্রচেষ্টার সাথে দায়িত্ব পালন করবেন এবং যেকোনো অবহেলা থেকে বিরত থাকবেন।'],
        ar: ['يجب على كل مسؤول أن يؤدي مسؤوليته بجد وأمانة ومهارة وبذل كامل الجهد، وأن يجتنب أي تقصير.'] },
      { n: '٦', ur: ['مؤسسہ میں قرآن و سنت اور مؤسسہ کے طے شدہ اصول و ضوابط کے خلاف کسی فرد کو کوئی کام کرنے کی اجازت نہیں ہوگی۔'],
        en: ['No individual will be permitted to do anything in the foundation contrary to the Qur\'an and Sunnah and the foundation\'s established principles and rules.'],
        bn: ['প্রতিষ্ঠানে কুরআন-সুন্নাহ এবং প্রতিষ্ঠানের নির্ধারিত নীতিমালার বিপরীত কোনো কাজ করার অনুমতি কোনো ব্যক্তির থাকবে না।'],
        ar: ['لا يُسمح لأي فرد في المؤسسة بفعل ما يخالف القرآن والسنة ومبادئ المؤسسة وضوابطها المقررة.'] },
      { n: '٧', ur: ['اساتذہ، اہلِ علم اور عوام الناس کی شمولیت بھی ممکن ہوگی، البتہ ان کے مالی حسابات اراکین کے حسابات سے علیحدہ رکھے جائیں گے۔'],
        en: ['Teachers, scholars and the general public may also join; however, their financial accounts will be kept separate from the accounts of members.'],
        bn: ['শিক্ষক, আহলে ইলম ও সাধারণ মানুষের অংশগ্রহণও সম্ভব হবে; তবে তাঁদের আর্থিক হিসাব সদস্যদের হিসাব থেকে আলাদা রাখা হবে।'],
        ar: ['يمكن أيضًا مشاركة الأساتذة وأهل العلم وعامة الناس، على أن تُفصل حساباتهم المالية عن حسابات الأعضاء.'] },
      { n: '٨', ur: ['فی الحال یہ مؤسسہ جامتلی اور شفیع اللہ کاٹا کے لیے مخصوص ہوگا۔ تاہم مستقبل میں اس کے دائرۂ کار کو وسعت دینا اور پوری دنیا میں إعلاء كلمة الله اور خدمتِ دین و ملت کو اپنا وسیع تر ہدف بنانا مقصود ہوگا، إن شاء الله تعالى۔'],
        en: ['For now this foundation is specific to Jamtoli and Shofiullahkhata. However, in the future the aim is to widen its scope and make the exaltation of the word of Allah and service of the religion and community across the whole world its broader goal, in sha Allah.'],
        bn: ['আপাতত এই প্রতিষ্ঠান জামতলী ও শফিউল্লাহকাটার জন্য নির্দিষ্ট থাকবে। তবে ভবিষ্যতে এর পরিধি বিস্তৃত করা এবং সারা বিশ্বে ই\'লায়ে কালিমাতুল্লাহ ও দ্বীন-মিল্লাতের খেদমতকে বৃহত্তর লক্ষ্য বানানো উদ্দেশ্য, ইনশাআল্লাহ।'],
        ar: ['المؤسسة مخصصة حاليًا لجامتلي وشفيع الله كاتا. وفي المستقبل يُقصد توسيع نطاقها وجعل إعلاء كلمة الله وخدمة الدين والملة في العالم كله هدفها الأوسع، إن شاء الله تعالى.'] }
    ]
  },
  {
    id: 'baitulmaal',
    title: { en: 'Fifth — Baitul Maal', bn: 'পঞ্চম — বাইতুল মাল', ur: 'پنجم — بیت المال', ar: 'خامساً — بيت المال' },
    clauses: [
      { n: '١', ur: ['مؤسسہ کے تمام مالی معاملات کا باقاعدہ حساب و کتاب محفوظ رکھا جائے گا اور اس کی نگرانی امیر کی ذمہ داری ہوگی۔'],
        en: ['Regular accounts of all financial affairs of the foundation will be kept, and supervising them is the responsibility of the Amir.'],
        bn: ['প্রতিষ্ঠানের সকল আর্থিক বিষয়ের নিয়মিত হিসাব সংরক্ষণ করা হবে এবং এর তত্ত্বাবধান আমীরের দায়িত্ব।'],
        ar: ['تُحفظ حسابات جميع الشؤون المالية للمؤسسة بانتظام، ومراقبتها من مسؤولية الأمير.'] },
      { n: '٢', ur: ['بیت المال سے کسی بھی قسم کی امداد یا خرچ امیر، نائب امیر اور صدر کی منظوری اور اجازت سے کیا جائے گا۔'],
        en: ['Any aid or expenditure from the Baitul Maal will be made with the approval and permission of the Amir, Naib Amir and Sadr.'],
        bn: ['বাইতুল মাল থেকে যেকোনো সাহায্য বা খরচ আমীর, নায়েবে আমীর ও সদরের অনুমোদন ও অনুমতিক্রমে করা হবে।'],
        ar: ['يكون أي إنفاق أو مساعدة من بيت المال بموافقة وإذن الأمير ونائب الأمير والصدر.'] },
      { n: '٣', ur: ['دو حضرات کے پاس بیت المال رہے گا آدھی امیر کے پاس, نصف مابقیہ ناظمِ مالیات کے پاس رہے گا، تاکہ مالی معاملات میں شفافیت اور باہمی اعتماد برقرار رہے۔ تاہم اگر امیر، صدر اور متعلقہ مجلس کے اراکین باہمی رضامندی سے رقم کسی ایک ذمہ دار کے پاس رکھنا مناسب سمجھیں تو اس کی گنجائش ہوگی۔'],
        en: ['The Baitul Maal will be held by two persons: half with the Amir and the remaining half with the Nazim-e-Maliyat (Finance Responsible), so that transparency and mutual trust are maintained. However, if the Amir, Sadr and members of the relevant council consider it appropriate by mutual consent to keep the money with a single responsible person, that is permitted.'],
        bn: ['বাইতুল মাল দুইজনের কাছে থাকবে: অর্ধেক আমীরের কাছে এবং বাকি অর্ধেক নাজিমে মালিয়াত (অর্থ দায়িত্বশীল)-এর কাছে, যাতে আর্থিক বিষয়ে স্বচ্ছতা ও পারস্পরিক আস্থা বজায় থাকে। তবে আমীর, সদর ও সংশ্লিষ্ট মজলিসের সদস্যরা পারস্পরিক সম্মতিতে অর্থ একজন দায়িত্বশীলের কাছে রাখা উপযুক্ত মনে করলে তার সুযোগ থাকবে।'],
        ar: ['يكون بيت المال عند شخصين: نصفه عند الأمير والنصف الباقي عند ناظم المالية، ليبقى التعامل المالي شفافًا وقائمًا على الثقة المتبادلة. ولكن إذا رأى الأمير والصدر وأعضاء المجلس المعني بالتراضي أن يُحفظ المال عند مسؤول واحد فذلك جائز.'] },
      { n: '٤', ur: ['جس ذمہ دار کے پاس بیت المال کی رقم رکھی جائے گی، وہ اسے بطورِ ضمانت محفوظ رکھے گا اور اس کے استعمال یا خرچ کا مکمل حساب پیش کرنے کا پابند ہوگا۔'],
        en: ['The office-bearer with whom Baitul Maal money is kept will hold it as a trust and is bound to present a full account of its use or expenditure.'],
        bn: ['যে দায়িত্বশীলের কাছে বাইতুল মালের অর্থ রাখা হবে, তিনি তা আমানত হিসেবে সংরক্ষণ করবেন এবং এর ব্যবহার বা খরচের পূর্ণ হিসাব পেশ করতে বাধ্য থাকবেন।'],
        ar: ['المسؤول الذي يُحفظ عنده مال بيت المال يحفظه ضمانةً وأمانةً، وهو ملزم بتقديم حساب كامل عن استعماله أو إنفاقه.'] },
      { n: '٥', ur: ['امیر، صدر اور متعلقہ ذمہ داران بیت المال کو صرف حلال و جائز ذرائع سے بڑھانے اور مؤسسہ کے مالی وسائل میں اضافہ کرنے کی کوشش کریں گے۔'],
        en: ['The Amir, Sadr and relevant office-bearers will strive to grow the Baitul Maal and the foundation\'s financial resources only through halal and lawful means.'],
        bn: ['আমীর, সদর ও সংশ্লিষ্ট দায়িত্বশীলগণ কেবল হালাল ও বৈধ উপায়ে বাইতুল মাল বৃদ্ধি এবং প্রতিষ্ঠানের আর্থিক সম্পদ বাড়ানোর চেষ্টা করবেন।'],
        ar: ['يسعى الأمير والصدر والمسؤولون المعنيون إلى تنمية بيت المال وزيادة موارد المؤسسة المالية من المصادر الحلال المشروعة فقط.'] },
      { n: '٦', ur: ['ہر سال عید الفطر کے موقع پر منعقد ہونے والی مجلسِ عمومی میں بیت المال کا مکمل حساب پیش کیا جائے گا اور موجودہ نقد رقم و دیگر مالی اثاثوں کی تفصیل مجلس کے سامنے پیش کی جائے گی۔'],
        en: ['At the General Assembly held every year on Eid al-Fitr, the full account of the Baitul Maal will be presented, along with details of the current cash and other financial assets.'],
        bn: ['প্রতি বছর ঈদুল ফিতরের সময় অনুষ্ঠিত সাধারণ সভায় বাইতুল মালের পূর্ণ হিসাব এবং বর্তমান নগদ অর্থ ও অন্যান্য আর্থিক সম্পদের বিবরণ সভার সামনে পেশ করা হবে।'],
        ar: ['يُعرض في المجلس العمومي الذي يُعقد كل عام في عيد الفطر الحساب الكامل لبيت المال، وتفاصيل النقد الحالي وسائر الأصول المالية.'] },
      { n: '٧', ur: ['ماہانہ رکنیت/بیت المال کی مقدار ۱۰۰ ٹاکا مقرر ہوگی۔ البتہ عید الفطر اور عید الاضحی کے مہینے میں یہ مقدار ۱۵۰ ٹاکا ہوگا۔ ان مہینوں میں منعقد ہونے والی مجلسِ عمومی کے حاضرین کے لیے حسبِ استطاعت مناسب مہمان نوازی کا بھی انتظام کیا جائے گا۔'],
        en: ['The monthly membership/Baitul Maal amount is fixed at 100 Taka. In the months of Eid al-Fitr and Eid al-Adha it will be 150 Taka. For those attending the General Assembly held in these months, suitable hospitality will also be arranged as far as means allow.'],
        bn: ['মাসিক সদস্যপদ/বাইতুল মালের পরিমাণ ১০০ টাকা নির্ধারিত। তবে ঈদুল ফিতর ও ঈদুল আযহার মাসে এটি ১৫০ টাকা হবে। এসব মাসে অনুষ্ঠিত সাধারণ সভার উপস্থিতদের জন্য সামর্থ্য অনুযায়ী যথাযথ আপ্যায়নেরও ব্যবস্থা করা হবে।'],
        ar: ['مقدار العضوية الشهرية/بيت المال ١٠٠ تاكا. وفي شهري عيد الفطر وعيد الأضحى يكون ١٥٠ تاكا. ويُرتَّب لحاضري المجلس العمومي في هذين الشهرين ضيافة مناسبة حسب الاستطاعة.'] },
      { n: '٨', ur: ['ہر رکن پر لازم ہوگا کہ وہ ہر ماہ کی پہلی تاریخ سے دسویں تاریخ کے اندر اپنا بیت المال ادا کرے۔ اگر کسی وجہ سے مقررہ وقت میں ادائیگی ممکن نہ ہو تو متعلقہ ذمہ دار کو اطلاع دے کر بعد میں جلد از جلد ادائیگی کی کوشش کرے۔'],
        en: ['Every member must pay his Baitul Maal between the 1st and 10th of each month. If payment is not possible within the fixed time for some reason, he should inform the responsible person and try to pay as soon as possible afterwards.'],
        bn: ['প্রত্যেক সদস্যকে প্রতি মাসের ১ তারিখ থেকে ১০ তারিখের মধ্যে নিজের বাইতুল মাল পরিশোধ করতে হবে। কোনো কারণে নির্ধারিত সময়ে পরিশোধ সম্ভব না হলে সংশ্লিষ্ট দায়িত্বশীলকে জানিয়ে পরে যথাশীঘ্র পরিশোধের চেষ্টা করবেন।'],
        ar: ['يجب على كل عضو دفع بيت المال بين اليوم الأول والعاشر من كل شهر. وإن تعذّر الدفع في الوقت المحدد لسبب ما فليُخبر المسؤول المعني ويحرص على الدفع في أقرب وقت.'] }
    ],
    note: {
      ur: 'اگر کسی مجبوری کی وجہ سے کسی فرد کو بیت المال کی ادائیگی میں کوتاہی ہو جائے تو دو, تین ماہ کے اندر جواب دہی کا مسؤول ہوگا.',
      en: 'If, due to some compulsion, a person falls short in paying the Baitul Maal, he will be answerable within two to three months.',
      bn: 'কোনো বাধ্যবাধকতার কারণে কেউ বাইতুল মাল পরিশোধে ত্রুটি করলে দুই-তিন মাসের মধ্যে তিনি জবাবদিহির দায়িত্বে থাকবেন।',
      ar: 'إذا قصّر شخص في دفع بيت المال لعذر فإنه يكون مسؤولًا عن المساءلة خلال شهرين أو ثلاثة أشهر.'
    }
  }
];

export const closingArabic = ['فقط، والسلام', 'منجانب:', 'مؤسسة الطلاب المسلمين أرکان (المؤسسة MTM)', 'رابطہ: 01630086396'];
export const motto = 'طلاب اليوم، مستقبل القوم';
