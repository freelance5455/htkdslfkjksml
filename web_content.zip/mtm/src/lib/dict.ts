// Generated dictionary: key -> [English, Bengali, Urdu, Arabic]
export const DICT: Record<string, string[]> = {
 "nav.home": [
  "Home",
  "হোম",
  "ہوم",
  "الرئيسية"
 ],
 "nav.contributions": [
  "Contributions",
  "চাঁদা",
  "عطیات",
  "المساهمات"
 ],
 "nav.announcements": [
  "Announcements",
  "ঘোষণা",
  "اعلانات",
  "الإعلانات"
 ],
 "nav.committee": [
  "Committee",
  "কমিটি",
  "کمیٹی",
  "اللجنة"
 ],
 "nav.more": [
  "More",
  "আরও",
  "مزید",
  "المزيد"
 ],
 "nav.profile": [
  "My Profile",
  "আমার প্রোফাইল",
  "میری پروفائل",
  "ملفي الشخصي"
 ],
 "nav.directory": [
  "Member Information",
  "সদস্য তথ্য",
  "اراکین کی معلومات",
  "معلومات الأعضاء"
 ],
 "nav.baitulmaal": [
  "Baitul Maal",
  "বাইতুল মাল",
  "بیت المال",
  "بيت المال"
 ],
 "nav.constitution": [
  "Foundation Constitution",
  "ফাউন্ডেশনের গঠনতন্ত্র",
  "مؤسسہ کا دستور",
  "دستور المؤسسة"
 ],
 "nav.rules": [
  "Foundation Rules",
  "ফাউন্ডেশনের নিয়মাবলি",
  "مؤسسہ کے قواعد",
  "قواعد المؤسسة"
 ],
 "nav.donate": [
  "Donation Information",
  "অনুদান তথ্য",
  "عطیہ کی معلومات",
  "معلومات التبرع"
 ],
 "nav.contact": [
  "Contact",
  "যোগাযোগ",
  "رابطہ",
  "اتصال"
 ],
 "nav.settings": [
  "Settings",
  "সেটিংস",
  "ترتیبات",
  "الإعدادات"
 ],
 "lang.choose": [
  "Language",
  "ভাষা",
  "زبان",
  "اللغة"
 ],
 "lang.remember": [
  "Remember my language",
  "আমার ভাষা সংরক্ষণ করুন",
  "میری زبان محفوظ کریں",
  "احفظ لغتي"
 ],
 "common.cancel": [
  "Cancel",
  "বাতিল",
  "منسوخ",
  "إلغاء"
 ],
 "common.confirm": [
  "Confirm",
  "নিশ্চিত করুন",
  "تصدیق کریں",
  "تأكيد"
 ],
 "common.yes": [
  "Yes",
  "হ্যাঁ",
  "ہاں",
  "نعم"
 ],
 "common.save": [
  "Save",
  "সংরক্ষণ",
  "محفوظ کریں",
  "حفظ"
 ],
 "common.saved": [
  "Saved",
  "সংরক্ষিত হয়েছে",
  "محفوظ ہو گیا",
  "تم الحفظ"
 ],
 "common.edit": [
  "Edit",
  "সম্পাদনা",
  "ترمیم",
  "تعديل"
 ],
 "common.delete": [
  "Delete",
  "মুছুন",
  "حذف کریں",
  "حذف"
 ],
 "common.deleteConfirm": [
  "Delete this item? This cannot be undone.",
  "এটি মুছবেন? এটি ফেরানো যাবে না।",
  "کیا اسے حذف کریں؟ یہ واپس نہیں ہو سکے گا۔",
  "هل تريد حذف هذا العنصر؟ لا يمكن التراجع."
 ],
 "common.new": [
  "New",
  "নতুন",
  "نیا",
  "جديد"
 ],
 "common.name": [
  "Name",
  "নাম",
  "نام",
  "الاسم"
 ],
 "common.search": [
  "Search",
  "খুঁজুন",
  "تلاش",
  "بحث"
 ],
 "common.wait": [
  "Please wait…",
  "অপেক্ষা করুন…",
  "براہ کرم انتظار کریں…",
  "يرجى الانتظار…"
 ],
 "common.copy": [
  "Copy",
  "কপি",
  "کاپی",
  "نسخ"
 ],
 "common.copied": [
  "Copied",
  "কপি হয়েছে",
  "کاپی ہو گیا",
  "تم النسخ"
 ],
 "common.tapEdit": [
  "tap to edit",
  "সম্পাদনা করতে ট্যাপ করুন",
  "ترمیم کے لیے ٹیپ کریں",
  "اضغط للتعديل"
 ],
 "auth.email": [
  "Email",
  "ইমেইল",
  "ای میل",
  "البريد الإلكتروني"
 ],
 "auth.password": [
  "Password",
  "পাসওয়ার্ড",
  "پاس ورڈ",
  "كلمة المرور"
 ],
 "auth.fullName": [
  "Full name",
  "পূর্ণ নাম",
  "پورا نام",
  "الاسم الكامل"
 ],
 "auth.phone": [
  "Phone number",
  "ফোন নম্বর",
  "فون نمبر",
  "رقم الهاتف"
 ],
 "auth.login": [
  "Log in",
  "লগইন",
  "لاگ اِن",
  "تسجيل الدخول"
 ],
 "auth.register": [
  "Create account",
  "অ্যাকাউন্ট তৈরি করুন",
  "اکاؤنٹ بنائیں",
  "إنشاء حساب"
 ],
 "auth.createAccount": [
  "Create a new account",
  "নতুন অ্যাকাউন্ট খুলুন",
  "نیا اکاؤنٹ بنائیں",
  "إنشاء حساب جديد"
 ],
 "auth.haveAccount": [
  "I already have an account",
  "আমার অ্যাকাউন্ট আছে",
  "میرا اکاؤنٹ موجود ہے",
  "لدي حساب بالفعل"
 ],
 "auth.forgot": [
  "Forgot password?",
  "পাসওয়ার্ড ভুলে গেছেন?",
  "پاس ورڈ بھول گئے؟",
  "نسيت كلمة المرور؟"
 ],
 "auth.sendReset": [
  "Send reset link",
  "রিসেট লিংক পাঠান",
  "ری سیٹ لنک بھیجیں",
  "إرسال رابط الاستعادة"
 ],
 "auth.resetSent": [
  "If this email is registered, a reset link has been sent.",
  "এই ইমেইল নিবন্ধিত থাকলে রিসেট লিংক পাঠানো হয়েছে।",
  "اگر یہ ای میل رجسٹرڈ ہے تو ری سیٹ لنک بھیج دیا گیا ہے۔",
  "إذا كان هذا البريد مسجلاً فقد أُرسل رابط الاستعادة."
 ],
 "auth.changePassword": [
  "Change password (email link)",
  "পাসওয়ার্ড পরিবর্তন (ইমেইল লিংক)",
  "پاس ورڈ تبدیل کریں (ای میل لنک)",
  "تغيير كلمة المرور (رابط بالبريد)"
 ],
 "auth.logout": [
  "Log out",
  "লগআউট",
  "لاگ آؤٹ",
  "تسجيل الخروج"
 ],
 "auth.logoutConfirm": [
  "Log out of the app?",
  "অ্যাপ থেকে লগআউট করবেন?",
  "کیا ایپ سے لاگ آؤٹ کریں؟",
  "هل تريد تسجيل الخروج من التطبيق؟"
 ],
 "auth.inactive": [
  "Your membership is not active. Please contact the foundation.",
  "আপনার সদস্যপদ সক্রিয় নয়। ফাউন্ডেশনের সাথে যোগাযোগ করুন।",
  "آپ کی رکنیت فعال نہیں ہے۔ براہ کرم مؤسسہ سے رابطہ کریں۔",
  "عضويتك غير نشطة. يرجى التواصل مع المؤسسة."
 ],
 "err.generic": [
  "Something went wrong. Please try again.",
  "কিছু ভুল হয়েছে। আবার চেষ্টা করুন।",
  "کچھ غلط ہو گیا۔ دوبارہ کوشش کریں۔",
  "حدث خطأ. حاول مرة أخرى."
 ],
 "err.permission": [
  "You do not have permission to see this.",
  "এটি দেখার অনুমতি আপনার নেই।",
  "آپ کو اسے دیکھنے کی اجازت نہیں ہے۔",
  "ليست لديك صلاحية لعرض هذا."
 ],
 "err.offline": [
  "No internet connection.",
  "ইন্টারনেট সংযোগ নেই।",
  "انٹرنیٹ کنکشن نہیں ہے۔",
  "لا يوجد اتصال بالإنترنت."
 ],
 "err.emailInUse": [
  "This email is already registered.",
  "এই ইমেইল আগে থেকেই নিবন্ধিত।",
  "یہ ای میل پہلے سے رجسٹرڈ ہے۔",
  "هذا البريد مسجل مسبقاً."
 ],
 "err.weakPassword": [
  "Password must be at least 6 characters.",
  "পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।",
  "پاس ورڈ کم از کم 6 حروف کا ہونا چاہیے۔",
  "يجب ألا تقل كلمة المرور عن 6 أحرف."
 ],
 "err.invalidEmail": [
  "Invalid email address.",
  "ইমেইল ঠিকানা সঠিক নয়।",
  "ای میل پتہ درست نہیں۔",
  "عنوان البريد غير صالح."
 ],
 "err.badLogin": [
  "Incorrect email or password.",
  "ইমেইল বা পাসওয়ার্ড ভুল।",
  "ای میل یا پاس ورڈ غلط ہے۔",
  "البريد أو كلمة المرور غير صحيحة."
 ],
 "err.tooMany": [
  "Too many attempts. Try again later.",
  "অনেকবার চেষ্টা হয়েছে। পরে আবার চেষ্টা করুন।",
  "بہت زیادہ کوششیں۔ بعد میں کوشش کریں۔",
  "محاولات كثيرة. حاول لاحقاً."
 ],
 "err.name": [
  "Please enter your full name.",
  "আপনার পূর্ণ নাম লিখুন।",
  "اپنا پورا نام لکھیں۔",
  "يرجى إدخال الاسم الكامل."
 ],
 "err.phone": [
  "Please enter a valid phone number.",
  "সঠিক ফোন নম্বর দিন।",
  "درست فون نمبر درج کریں۔",
  "يرجى إدخال رقم هاتف صحيح."
 ],
 "err.amount": [
  "Enter an amount greater than zero.",
  "শূন্যের বেশি পরিমাণ লিখুন।",
  "صفر سے زیادہ رقم درج کریں۔",
  "أدخل مبلغاً أكبر من صفر."
 ],
 "err.required": [
  "Please fill the required fields.",
  "প্রয়োজনীয় ঘরগুলো পূরণ করুন।",
  "ضروری خانے پُر کریں۔",
  "يرجى تعبئة الحقول المطلوبة."
 ],
 "home.welcome": [
  "Welcome",
  "স্বাগতম",
  "خوش آمدید",
  "مرحباً"
 ],
 "home.memberId": [
  "Member ID",
  "সদস্য আইডি",
  "رکن آئی ڈی",
  "رقم العضوية"
 ],
 "home.since": [
  "Member since",
  "সদস্য হয়েছেন",
  "رکنیت کی تاریخ",
  "عضو منذ"
 ],
 "home.thisMonth": [
  "This month's contribution",
  "এই মাসের চাঁদা",
  "اس ماہ کا بیت المال",
  "مساهمة هذا الشهر"
 ],
 "home.latest": [
  "Latest announcement",
  "সর্বশেষ ঘোষণা",
  "تازہ ترین اعلان",
  "آخر إعلان"
 ],
 "home.payHow": [
  "How to pay",
  "কীভাবে পরিশোধ করবেন",
  "ادائیگی کا طریقہ",
  "طريقة الدفع"
 ],
 "contrib.paid": [
  "Paid",
  "পরিশোধিত",
  "ادا شدہ",
  "مدفوع"
 ],
 "contrib.unpaid": [
  "Unpaid",
  "অপরিশোধিত",
  "غیر ادا شدہ",
  "غير مدفوع"
 ],
 "contrib.window": [
  "Please pay between the 1st and 10th of each month. If you cannot, inform the responsible person and pay as soon as possible.",
  "প্রতি মাসের ১ থেকে ১০ তারিখের মধ্যে পরিশোধ করুন। সম্ভব না হলে দায়িত্বশীলকে জানিয়ে যথাশীঘ্র পরিশোধ করুন।",
  "ہر ماہ کی پہلی سے دسویں تاریخ کے اندر ادا کریں۔ ممکن نہ ہو تو متعلقہ ذمہ دار کو اطلاع دے کر جلد ادا کریں۔",
  "يرجى الدفع بين اليوم الأول والعاشر من كل شهر، وإن تعذر فأخبر المسؤول وادفع في أقرب وقت."
 ],
 "contrib.fitrMonth": [
  "Eid al-Fitr month (Shawwal) rate",
  "ঈদুল ফিতর মাসের (শাওয়াল) হার",
  "عید الفطر (شوال) کے مہینے کی شرح",
  "مقدار شهر عيد الفطر (شوال)"
 ],
 "contrib.adhaMonth": [
  "Eid al-Adha month (Dhul Hijjah) rate",
  "ঈদুল আযহা মাসের (যিলহজ) হার",
  "عید الاضحیٰ (ذوالحجہ) کے مہینے کی شرح",
  "مقدار شهر عيد الأضحى (ذو الحجة)"
 ],
 "contrib.totalPaid": [
  "Total paid by me",
  "আমার মোট পরিশোধ",
  "میری کل ادائیگی",
  "مجموع ما دفعته"
 ],
 "contrib.due": [
  "Amount due",
  "প্রদেয়",
  "واجب الادا رقم",
  "المبلغ المستحق"
 ],
 "contrib.manualNote": [
  "Payments are confirmed manually by an administrator after they verify your payment outside the app.",
  "অ্যাপের বাইরে আপনার পেমেন্ট যাচাই করার পর অ্যাডমিন ম্যানুয়ালি তা নিশ্চিত করেন।",
  "ایپ کے باہر آپ کی ادائیگی کی تصدیق کے بعد ایڈمن دستی طور پر اسے درج کرتا ہے۔",
  "يؤكد المسؤول الدفعة يدوياً بعد التحقق منها خارج التطبيق."
 ],
 "contrib.period": [
  "Month",
  "মাস",
  "مہینہ",
  "الشهر"
 ],
 "contrib.collected": [
  "Collected",
  "সংগৃহীত",
  "وصول شدہ",
  "المحصّل"
 ],
 "contrib.markPaid": [
  "Mark as paid",
  "পরিশোধিত চিহ্নিত করুন",
  "ادا شدہ نشان زد کریں",
  "تسجيل كمدفوع"
 ],
 "contrib.markUnpaid": [
  "Mark as unpaid (remove record)",
  "অপরিশোধিত করুন (রেকর্ড মুছুন)",
  "غیر ادا شدہ کریں (ریکارڈ ہٹائیں)",
  "تحويل إلى غير مدفوع (حذف السجل)"
 ],
 "contrib.unmarkConfirm": [
  "Remove this paid record and its income entry?",
  "এই পরিশোধ রেকর্ড ও এর আয়ের এন্ট্রি মুছবেন?",
  "کیا یہ ادائیگی ریکارڈ اور اس کی آمدنی کی اندراج حذف کریں؟",
  "هل تريد حذف سجل الدفع وقيد الإيراد المرتبط به؟"
 ],
 "contrib.paidDate": [
  "Payment date",
  "পরিশোধের তারিখ",
  "ادائیگی کی تاریخ",
  "تاريخ الدفع"
 ],
 "contrib.verifyFirst": [
  "Mark as paid only after you have confirmed receipt of the payment.",
  "পেমেন্ট প্রাপ্তি নিশ্চিত হওয়ার পরই পরিশোধিত চিহ্নিত করুন।",
  "ادائیگی موصول ہونے کی تصدیق کے بعد ہی ادا شدہ نشان زد کریں۔",
  "لا تسجّل كمدفوع إلا بعد التأكد من استلام المبلغ."
 ],
 "empty.announcements": [
  "No announcements yet.",
  "এখনো কোনো ঘোষণা নেই।",
  "ابھی کوئی اعلان نہیں۔",
  "لا توجد إعلانات بعد."
 ],
 "empty.members": [
  "No members found.",
  "কোনো সদস্য পাওয়া যায়নি।",
  "کوئی رکن نہیں ملا۔",
  "لا يوجد أعضاء."
 ],
 "empty.committee": [
  "No entries yet.",
  "এখনো কোনো তথ্য নেই।",
  "ابھی کوئی اندراج نہیں۔",
  "لا توجد بيانات بعد."
 ],
 "empty.transactions": [
  "No transactions recorded.",
  "কোনো লেনদেন নথিভুক্ত নেই।",
  "کوئی لین دین درج نہیں۔",
  "لا توجد معاملات مسجلة."
 ],
 "empty.activity": [
  "No activity yet.",
  "এখনো কোনো কার্যক্রম নেই।",
  "ابھی کوئی سرگرمی نہیں۔",
  "لا يوجد نشاط بعد."
 ],
 "member.status": [
  "Status",
  "অবস্থা",
  "حیثیت",
  "الحالة"
 ],
 "member.statusActive": [
  "Active member",
  "সক্রিয় সদস্য",
  "فعال رکن",
  "عضو نشط"
 ],
 "member.status.active": [
  "Active",
  "সক্রিয়",
  "فعال",
  "نشط"
 ],
 "member.status.inactive": [
  "Inactive",
  "নিষ্ক্রিয়",
  "غیر فعال",
  "غير نشط"
 ],
 "member.status.suspended": [
  "Suspended",
  "স্থগিত",
  "معطل",
  "موقوف"
 ],
 "profile.photoUrl": [
  "Photo URL (optional)",
  "ছবির লিংক (ঐচ্ছিক)",
  "تصویر کا لنک (اختیاری)",
  "رابط الصورة (اختياري)"
 ],
 "dir.privacy": [
  "Only name, ID and position are shown. Phone and email stay private.",
  "শুধু নাম, আইডি ও পদ দেখানো হয়। ফোন ও ইমেইল গোপন থাকে।",
  "صرف نام، آئی ڈی اور عہدہ دکھایا جاتا ہے۔ فون اور ای میل نجی رہتے ہیں۔",
  "يظهر الاسم والرقم والمنصب فقط. الهاتف والبريد خاصان."
 ],
 "bm.normal": [
  "Normal month",
  "সাধারণ মাস",
  "عام مہینہ",
  "الشهر العادي"
 ],
 "bm.eid": [
  "Eid al-Fitr / Eid al-Adha month",
  "ঈদুল ফিতর / ঈদুল আযহার মাস",
  "عید الفطر / عید الاضحیٰ کا مہینہ",
  "شهر عيد الفطر / عيد الأضحى"
 ],
 "bm.manual": [
  "Payments are manual. An administrator records each confirmed payment.",
  "পেমেন্ট ম্যানুয়াল। নিশ্চিত প্রতিটি পেমেন্ট অ্যাডমিন নথিভুক্ত করেন।",
  "ادائیگیاں دستی ہیں۔ ایڈمن ہر تصدیق شدہ ادائیگی درج کرتا ہے۔",
  "المدفوعات يدوية، ويسجل المسؤول كل دفعة مؤكدة."
 ],
 "bm.calendar": [
  "Contribution calendar",
  "চাঁদার ক্যালেন্ডার",
  "بیت المال کیلنڈر",
  "تقويم المساهمات"
 ],
 "bm.noCalendar": [
  "The Eid months have not been set yet.",
  "ঈদের মাসগুলো এখনো নির্ধারণ করা হয়নি।",
  "عید کے مہینے ابھی مقرر نہیں ہوئے۔",
  "لم تُحدد أشهر العيد بعد."
 ],
 "bm.ah": [
  "AH",
  "হিজরি",
  "ھ",
  "هـ"
 ],
 "bm.custodians": [
  "Baitul Maal custodians",
  "বাইতুল মালের তত্ত্বাবধায়ক",
  "بیت المال کے امین",
  "أمناء بيت المال"
 ],
 "com.executive": [
  "Executive Committee",
  "নির্বাহী কমিটি",
  "انتظامی کمیٹی",
  "اللجنة الإدارية"
 ],
 "com.advisory": [
  "Advisory Council",
  "উপদেষ্টা পরিষদ",
  "مجلسِ مشاورت",
  "المجلس الاستشاري"
 ],
 "com.current": [
  "Current",
  "বর্তমান",
  "موجودہ",
  "الحالية"
 ],
 "com.former": [
  "Former",
  "সাবেক",
  "سابقہ",
  "السابقة"
 ],
 "com.year": [
  "Committee year",
  "কমিটির বছর",
  "کمیٹی کا سال",
  "سنة اللجنة"
 ],
 "com.term": [
  "Term",
  "মেয়াদ",
  "مدت",
  "المدة"
 ],
 "com.position": [
  "Position",
  "পদ",
  "عہدہ",
  "المنصب"
 ],
 "com.customTitle": [
  "Designation / title",
  "পদবি / শিরোনাম",
  "عہدے کا نام",
  "المسمى"
 ],
 "com.appointmentDate": [
  "Appointment date",
  "নিয়োগের তারিখ",
  "تقرری کی تاریخ",
  "تاريخ التعيين"
 ],
 "com.termStart": [
  "Term start",
  "মেয়াদ শুরু",
  "مدت کا آغاز",
  "بداية المدة"
 ],
 "com.termEnd": [
  "Term end",
  "মেয়াদ শেষ",
  "مدت کا اختتام",
  "نهاية المدة"
 ],
 "pos.amir": [
  "Amir",
  "আমীর",
  "امیر",
  "أمير"
 ],
 "pos.naib_amir": [
  "Naib Amir",
  "নায়েবে আমীর",
  "نائب امیر",
  "نائب أمير"
 ],
 "pos.sadr": [
  "Sadr",
  "সদর",
  "صدر",
  "صدر"
 ],
 "pos.masul": [
  "Mas'ul",
  "মাসউল",
  "مسؤول",
  "مسؤول"
 ],
 "pos.nazim_maliyat": [
  "Nazim-e-Maliyat (Finance)",
  "নাজিমে মালিয়াত (অর্থ)",
  "ناظمِ مالیات",
  "ناظم المالية"
 ],
 "pos.member": [
  "Committee member",
  "কমিটি সদস্য",
  "رکنِ کمیٹی",
  "عضو اللجنة"
 ],
 "pos.other": [
  "Other",
  "অন্যান্য",
  "دیگر",
  "أخرى"
 ],
 "pay.notSet": [
  "Payment numbers have not been set by the administrator yet.",
  "পেমেন্ট নম্বর এখনো অ্যাডমিন নির্ধারণ করেননি।",
  "ادائیگی کے نمبر ابھی ایڈمن نے مقرر نہیں کیے۔",
  "لم يحدد المسؤول أرقام الدفع بعد."
 ],
 "pay.accountType": [
  "Account type",
  "অ্যাকাউন্টের ধরন",
  "اکاؤنٹ کی قسم",
  "نوع الحساب"
 ],
 "pay.instructions": [
  "Payment instructions",
  "পেমেন্টের নির্দেশনা",
  "ادائیگی کی ہدایات",
  "تعليمات الدفع"
 ],
 "pay.defaultInstructions": [
  "Send your contribution to the number above, then inform the responsible person with your name and member ID.",
  "উপরের নম্বরে আপনার চাঁদা পাঠান, তারপর নাম ও সদস্য আইডি সহ দায়িত্বশীলকে জানান।",
  "اوپر دیے گئے نمبر پر رقم بھیجیں، پھر اپنا نام اور رکن آئی ڈی ذمہ دار کو بتائیں۔",
  "أرسل مساهمتك إلى الرقم أعلاه ثم أبلغ المسؤول باسمك ورقم عضويتك."
 ],
 "pay.manualWarning": [
  "The app does not process payments. Your status changes to Paid only after an administrator confirms your payment.",
  "অ্যাপ পেমেন্ট প্রক্রিয়া করে না। অ্যাডমিন যাচাই করলেই আপনার অবস্থা 'পরিশোধিত' হবে।",
  "ایپ ادائیگی پراسیس نہیں کرتی۔ ایڈمن کی تصدیق کے بعد ہی آپ کی حیثیت ادا شدہ ہوگی۔",
  "لا يعالج التطبيق المدفوعات. تصبح حالتك «مدفوع» بعد تأكيد المسؤول فقط."
 ],
 "pay.openApp": [
  "Open app",
  "অ্যাপ খুলুন",
  "ایپ کھولیں",
  "افتح التطبيق"
 ],
 "const.review": [
  "Translation needs review",
  "অনুবাদ পর্যালোচনা প্রয়োজন",
  "ترجمہ نظرثانی کا محتاج",
  "الترجمة تحتاج مراجعة"
 ],
 "const.original": [
  "Show original Urdu text",
  "মূল উর্দু পাঠ দেখুন",
  "اصل اردو متن دیکھیں",
  "عرض النص الأردي الأصلي"
 ],
 "const.note": [
  "Official note",
  "সরকারি নোট",
  "سرکاری نوٹ",
  "ملاحظة رسمية"
 ],
 "adm.panel": [
  "Admin Panel",
  "অ্যাডমিন প্যানেল",
  "ایڈمن پینل",
  "لوحة الإدارة"
 ],
 "adm.exit": [
  "Member view",
  "সদস্য ভিউ",
  "رکن منظر",
  "عرض العضو"
 ],
 "adm.dashboard": [
  "Dashboard",
  "ড্যাশবোর্ড",
  "ڈیش بورڈ",
  "لوحة المعلومات"
 ],
 "adm.members": [
  "Members",
  "সদস্যগণ",
  "اراکین",
  "الأعضاء"
 ],
 "adm.contributions": [
  "Monthly contributions",
  "মাসিক চাঁদা",
  "ماہانہ بیت المال",
  "المساهمات الشهرية"
 ],
 "adm.finance": [
  "Income & expenses",
  "আয় ও ব্যয়",
  "آمدنی و اخراجات",
  "الإيرادات والمصروفات"
 ],
 "adm.announcements": [
  "Announcements",
  "ঘোষণা",
  "اعلانات",
  "الإعلانات"
 ],
 "adm.committee": [
  "Committee & council",
  "কমিটি ও পরিষদ",
  "کمیٹی و مجلس",
  "اللجنة والمجلس"
 ],
 "adm.admins": [
  "Administrators",
  "অ্যাডমিনগণ",
  "ایڈمنز",
  "المسؤولون"
 ],
 "adm.settings": [
  "Foundation settings",
  "ফাউন্ডেশন সেটিংস",
  "مؤسسہ کی ترتیبات",
  "إعدادات المؤسسة"
 ],
 "adm.audit": [
  "Activity log",
  "কার্যক্রম লগ",
  "سرگرمی لاگ",
  "سجل النشاط"
 ],
 "adm.totalMembers": [
  "Registered members",
  "নিবন্ধিত সদস্য",
  "رجسٹرڈ اراکین",
  "الأعضاء المسجلون"
 ],
 "adm.activeMembers": [
  "Active members",
  "সক্রিয় সদস্য",
  "فعال اراکین",
  "الأعضاء النشطون"
 ],
 "adm.currentCommittee": [
  "Current committee",
  "বর্তমান কমিটি",
  "موجودہ کمیٹی",
  "اللجنة الحالية"
 ],
 "adm.paidThisMonth": [
  "Paid this month",
  "এই মাসে পরিশোধিত",
  "اس ماہ ادا شدہ",
  "المدفوع هذا الشهر"
 ],
 "adm.recentAnn": [
  "Recent announcements",
  "সাম্প্রতিক ঘোষণা",
  "حالیہ اعلانات",
  "أحدث الإعلانات"
 ],
 "adm.recentActivity": [
  "Recent activity",
  "সাম্প্রতিক কার্যক্রম",
  "حالیہ سرگرمی",
  "النشاط الأخير"
 ],
 "adm.noAutoSuspend": [
  "Overdue status never suspends a member automatically.",
  "বকেয়া থাকলেও সদস্য স্বয়ংক্রিয়ভাবে স্থগিত হয় না।",
  "بقایا ہونے پر رکن خودکار طور پر معطل نہیں ہوتا۔",
  "التأخر في الدفع لا يوقف العضو تلقائياً."
 ],
 "adm.appoint": [
  "Appoint administrator",
  "অ্যাডমিন নিয়োগ",
  "ایڈمن مقرر کریں",
  "تعيين مسؤول"
 ],
 "adm.findMember": [
  "Find member (name, email or ID)",
  "সদস্য খুঁজুন (নাম, ইমেইল বা আইডি)",
  "رکن تلاش کریں (نام، ای میل یا آئی ڈی)",
  "ابحث عن عضو (الاسم أو البريد أو الرقم)"
 ],
 "adm.role": [
  "Role",
  "ভূমিকা",
  "کردار",
  "الدور"
 ],
 "adm.changeRole": [
  "Change role",
  "ভূমিকা পরিবর্তন",
  "کردار تبدیل کریں",
  "تغيير الدور"
 ],
 "adm.remove": [
  "Remove",
  "অপসারণ",
  "ہٹائیں",
  "إزالة"
 ],
 "adm.removeConfirm": [
  "Remove administrator access for {name}?",
  "{name}-এর অ্যাডমিন অ্যাক্সেস সরাবেন?",
  "کیا {name} کی ایڈمن رسائی ختم کریں؟",
  "هل تريد إزالة صلاحية الإدارة عن {name}؟"
 ],
 "adm.ownerLocked": [
  "The Primary Owner cannot be removed or changed by anyone.",
  "প্রাইমারি ওনারকে কেউ অপসারণ বা পরিবর্তন করতে পারবেন না।",
  "پرائمری اونر کو کوئی ہٹا یا تبدیل نہیں کر سکتا۔",
  "لا يمكن لأحد إزالة المالك الأساسي أو تغييره."
 ],
 "role.owner": [
  "Primary Owner",
  "প্রাইমারি ওনার",
  "پرائمری اونر",
  "المالك الأساسي"
 ],
 "role.super_admin": [
  "Super Admin",
  "সুপার অ্যাডমিন",
  "سپر ایڈمن",
  "مسؤول عام"
 ],
 "role.finance_admin": [
  "Finance Admin",
  "ফাইন্যান্স অ্যাডমিন",
  "فنانس ایڈمن",
  "مسؤول مالي"
 ],
 "role.content_admin": [
  "Content Admin",
  "কনটেন্ট অ্যাডমিন",
  "کنٹنٹ ایڈمن",
  "مسؤول المحتوى"
 ],
 "role.member": [
  "Member",
  "সদস্য",
  "رکن",
  "عضو"
 ],
 "filter.all": [
  "All",
  "সব",
  "سب",
  "الكل"
 ],
 "filter.paid": [
  "Paid",
  "পরিশোধিত",
  "ادا شدہ",
  "المدفوع"
 ],
 "filter.unpaid": [
  "Unpaid",
  "অপরিশোধিত",
  "غیر ادا شدہ",
  "غير المدفوع"
 ],
 "fin.income": [
  "Income",
  "আয়",
  "آمدنی",
  "الإيرادات"
 ],
 "fin.expense": [
  "Expenses",
  "ব্যয়",
  "اخراجات",
  "المصروفات"
 ],
 "fin.balance": [
  "Recorded balance",
  "নথিভুক্ত স্থিতি",
  "درج شدہ بیلنس",
  "الرصيد المسجل"
 ],
 "fin.recordedOnly": [
  "Totals include only recorded transactions. Unpaid contributions are never counted.",
  "শুধু নথিভুক্ত লেনদেন গণনা হয়। অপরিশোধিত চাঁদা কখনো গণনা হয় না।",
  "صرف درج شدہ لین دین شمار ہوتے ہیں۔ غیر ادا شدہ رقم کبھی شمار نہیں ہوتی۔",
  "تُحسب المعاملات المسجلة فقط، ولا تُحتسب المساهمات غير المدفوعة."
 ],
 "fin.transactions": [
  "Transactions",
  "লেনদেন",
  "لین دین",
  "المعاملات"
 ],
 "fin.reports": [
  "Reports",
  "প্রতিবেদন",
  "رپورٹیں",
  "التقارير"
 ],
 "fin.addIncome": [
  "Add income",
  "আয় যোগ করুন",
  "آمدنی شامل کریں",
  "إضافة إيراد"
 ],
 "fin.addExpense": [
  "Add expense",
  "ব্যয় যোগ করুন",
  "خرچ شامل کریں",
  "إضافة مصروف"
 ],
 "fin.from": [
  "From",
  "শুরু",
  "از",
  "من"
 ],
 "fin.to": [
  "To",
  "শেষ",
  "تا",
  "إلى"
 ],
 "fin.type": [
  "Type",
  "ধরন",
  "قسم",
  "النوع"
 ],
 "fin.filtered": [
  "Filtered",
  "ফিল্টারকৃত",
  "فلٹر شدہ",
  "المصفّى"
 ],
 "fin.amount": [
  "Amount (BDT)",
  "পরিমাণ (টাকা)",
  "رقم (ٹاکا)",
  "المبلغ (تاكا)"
 ],
 "fin.description": [
  "Description",
  "বিবরণ",
  "تفصیل",
  "الوصف"
 ],
 "fin.date": [
  "Date",
  "তারিখ",
  "تاریخ",
  "التاريخ"
 ],
 "fin.category": [
  "Category",
  "বিভাগ",
  "زمرہ",
  "الفئة"
 ],
 "fin.approvals": [
  "Approvals",
  "অনুমোদন",
  "منظوری",
  "الموافقات"
 ],
 "fin.approvalHelp": [
  "Baitul Maal expenses need approval of the Amir, Naib Amir and Sadr. Record each decision here.",
  "বাইতুল মালের খরচে আমীর, নায়েবে আমীর ও সদরের অনুমোদন লাগে। প্রতিটি সিদ্ধান্ত এখানে লিখুন।",
  "بیت المال کے خرچ کے لیے امیر، نائب امیر اور صدر کی منظوری ضروری ہے۔ ہر فیصلہ یہاں درج کریں۔",
  "يحتاج الإنفاق من بيت المال إلى موافقة الأمير ونائبه والصدر. سجّل كل قرار هنا."
 ],
 "fin.approverName": [
  "Approver name",
  "অনুমোদনকারীর নাম",
  "منظور کنندہ کا نام",
  "اسم الموافق"
 ],
 "fin.decision": [
  "Decision",
  "সিদ্ধান্ত",
  "فیصلہ",
  "القرار"
 ],
 "fin.d.pending": [
  "Pending",
  "অপেক্ষমাণ",
  "زیر التواء",
  "قيد الانتظار"
 ],
 "fin.d.approved": [
  "Approved",
  "অনুমোদিত",
  "منظور",
  "موافَق عليه"
 ],
 "fin.d.rejected": [
  "Rejected",
  "প্রত্যাখ্যাত",
  "مسترد",
  "مرفوض"
 ],
 "fin.altArrangement": [
  "Approved alternative arrangement (optional)",
  "অনুমোদিত বিকল্প ব্যবস্থা (ঐচ্ছিক)",
  "منظور شدہ متبادل انتظام (اختیاری)",
  "ترتيب بديل معتمد (اختياري)"
 ],
 "fin.linkedNote": [
  "This income entry was created from a contribution. Edit it from Monthly contributions.",
  "এই আয় চাঁদার রেকর্ড থেকে তৈরি। মাসিক চাঁদা পাতা থেকে সম্পাদনা করুন।",
  "یہ آمدنی بیت المال ریکارڈ سے بنی ہے۔ اسے ماہانہ بیت المال صفحے سے بدلیں۔",
  "أُنشئ هذا القيد من سجل مساهمة. عدّله من صفحة المساهمات الشهرية."
 ],
 "fin.year": [
  "Year",
  "বছর",
  "سال",
  "السنة"
 ],
 "fin.month": [
  "Month",
  "মাস",
  "مہینہ",
  "الشهر"
 ],
 "fin.total": [
  "Total",
  "মোট",
  "کل",
  "المجموع"
 ],
 "fin.byCategory": [
  "By category",
  "বিভাগ অনুযায়ী",
  "زمرے کے لحاظ سے",
  "حسب الفئة"
 ],
 "fin.copyReport": [
  "Copy report text",
  "প্রতিবেদনের লেখা কপি করুন",
  "رپورٹ کا متن کاپی کریں",
  "نسخ نص التقرير"
 ],
 "cat.contribution": [
  "Member contribution",
  "সদস্য চাঁদা",
  "رکن کا بیت المال",
  "مساهمة عضو"
 ],
 "cat.donation": [
  "Donation",
  "অনুদান",
  "عطیہ",
  "تبرع"
 ],
 "cat.event": [
  "Event",
  "অনুষ্ঠান",
  "تقریب",
  "فعالية"
 ],
 "cat.relief": [
  "Relief / aid",
  "ত্রাণ / সাহায্য",
  "امداد",
  "إغاثة / مساعدة"
 ],
 "cat.education": [
  "Education",
  "শিক্ষা",
  "تعلیم",
  "تعليم"
 ],
 "cat.administration": [
  "Administration",
  "প্রশাসন",
  "انتظامیہ",
  "إدارة"
 ],
 "cat.other": [
  "Other",
  "অন্যান্য",
  "دیگر",
  "أخرى"
 ],
 "ann.draft": [
  "Draft",
  "খসড়া",
  "مسودہ",
  "مسودة"
 ],
 "ann.published": [
  "Published",
  "প্রকাশিত",
  "شائع شدہ",
  "منشور"
 ],
 "ann.title": [
  "Title",
  "শিরোনাম",
  "عنوان",
  "العنوان"
 ],
 "ann.content": [
  "Content",
  "বিষয়বস্তু",
  "مضمون",
  "المحتوى"
 ],
 "ann.imageUrl": [
  "Image URL (optional)",
  "ছবির লিংক (ঐচ্ছিক)",
  "تصویر کا لنک (اختیاری)",
  "رابط الصورة (اختياري)"
 ],
 "ann.saveDraft": [
  "Save draft",
  "খসড়া সংরক্ষণ",
  "مسودہ محفوظ کریں",
  "حفظ كمسودة"
 ],
 "ann.publish": [
  "Publish",
  "প্রকাশ করুন",
  "شائع کریں",
  "نشر"
 ],
 "ann.unpublish": [
  "Unpublish",
  "প্রকাশ বন্ধ করুন",
  "اشاعت روکیں",
  "إلغاء النشر"
 ],
 "ann.editingLang": [
  "Editing language",
  "সম্পাদনার ভাষা",
  "ترمیم کی زبان",
  "لغة التحرير"
 ],
 "set.logoUrl": [
  "Logo URL",
  "লোগোর লিংক",
  "لوگو کا لنک",
  "رابط الشعار"
 ],
 "set.contact": [
  "Contact number",
  "যোগাযোগ নম্বর",
  "رابطہ نمبر",
  "رقم الاتصال"
 ],
 "set.address": [
  "Address",
  "ঠিকানা",
  "پتہ",
  "العنوان"
 ],
 "set.monthly": [
  "Monthly amount (৳)",
  "মাসিক পরিমাণ (৳)",
  "ماہانہ رقم (৳)",
  "المبلغ الشهري (৳)"
 ],
 "set.special": [
  "Eid month amount (৳)",
  "ঈদের মাসের পরিমাণ (৳)",
  "عید کے مہینے کی رقم (৳)",
  "مبلغ شهر العيد (৳)"
 ],
 "set.defaultLang": [
  "Default language",
  "ডিফল্ট ভাষা",
  "ڈیفالٹ زبان",
  "اللغة الافتراضية"
 ],
 "set.appLink": [
  "app link (optional)",
  "অ্যাপ লিংক (ঐচ্ছিক)",
  "ایپ لنک (اختیاری)",
  "رابط التطبيق (اختياري)"
 ],
 "set.donationInfo": [
  "Other donation information",
  "অন্যান্য অনুদান তথ্য",
  "دیگر عطیہ معلومات",
  "معلومات تبرع أخرى"
 ],
 "set.custodianNote": [
  "Approved alternative arrangement / note",
  "অনুমোদিত বিকল্প ব্যবস্থা / নোট",
  "منظور شدہ متبادل انتظام / نوٹ",
  "ترتيب بديل معتمد / ملاحظة"
 ],
 "cal.help": [
  "Map each Hijri year's Shawwal and Dhul Hijjah to the Gregorian billing month.",
  "প্রতি হিজরি বছরের শাওয়াল ও যিলহজকে ইংরেজি বিলিং মাসের সাথে মেলান।",
  "ہر ہجری سال کے شوال اور ذوالحجہ کو عیسوی بلنگ مہینے سے ملائیں۔",
  "اربط شوال وذا الحجة لكل سنة هجرية بشهر الفوترة الميلادي."
 ],
 "cal.hijriYear": [
  "Hijri year",
  "হিজরি বছর",
  "ہجری سال",
  "السنة الهجرية"
 ],
 "cal.suggest": [
  "Suggest months",
  "মাস প্রস্তাব করুন",
  "مہینے تجویز کریں",
  "اقتراح الأشهر"
 ],
 "cal.billingMonth": [
  "billing month",
  "বিলিং মাস",
  "بلنگ مہینہ",
  "شهر الفوترة"
 ],
 "cal.verify": [
  "Suggestions use the Umm al-Qura calendar. Confirm with your local moon sighting.",
  "প্রস্তাব উম্মুল কুরা ক্যালেন্ডার অনুযায়ী। স্থানীয় চাঁদ দেখার সাথে মিলিয়ে নিন।",
  "تجویز ام القریٰ کیلنڈر پر مبنی ہے۔ مقامی رؤیتِ ہلال سے تصدیق کریں۔",
  "الاقتراحات وفق تقويم أم القرى، فتأكد بحسب الرؤية المحلية."
 ],
 "audit.member_registered": [
  "Member registered",
  "সদস্য নিবন্ধিত",
  "رکن رجسٹر ہوا",
  "تسجيل عضو"
 ],
 "audit.profile_updated": [
  "Profile updated",
  "প্রোফাইল হালনাগাদ",
  "پروفائل اپڈیٹ",
  "تحديث الملف"
 ],
 "audit.member_updated": [
  "Member updated",
  "সদস্য হালনাগাদ",
  "رکن اپڈیٹ",
  "تحديث عضو"
 ],
 "audit.contribution_paid": [
  "Contribution marked paid",
  "চাঁদা পরিশোধিত",
  "بیت المال ادا شدہ",
  "تسجيل مساهمة مدفوعة"
 ],
 "audit.contribution_corrected": [
  "Contribution corrected",
  "চাঁদা সংশোধিত",
  "بیت المال درست",
  "تصحيح مساهمة"
 ],
 "audit.contribution_voided": [
  "Contribution removed",
  "চাঁদা রেকর্ড মুছেছে",
  "بیت المال ریکارڈ حذف",
  "حذف سجل مساهمة"
 ],
 "audit.income_added": [
  "Income added",
  "আয় যোগ",
  "آمدنی شامل",
  "إضافة إيراد"
 ],
 "audit.expense_added": [
  "Expense added",
  "ব্যয় যোগ",
  "خرچ شامل",
  "إضافة مصروف"
 ],
 "audit.transaction_updated": [
  "Transaction updated",
  "লেনদেন হালনাগাদ",
  "لین دین اپڈیٹ",
  "تحديث معاملة"
 ],
 "audit.transaction_deleted": [
  "Transaction deleted",
  "লেনদেন মুছেছে",
  "لین دین حذف",
  "حذف معاملة"
 ],
 "audit.announcement_published": [
  "Announcement published",
  "ঘোষণা প্রকাশিত",
  "اعلان شائع",
  "نشر إعلان"
 ],
 "audit.announcement_unpublished": [
  "Announcement unpublished",
  "ঘোষণা প্রকাশ বন্ধ",
  "اعلان کی اشاعت بند",
  "إلغاء نشر إعلان"
 ],
 "audit.announcement_deleted": [
  "Announcement deleted",
  "ঘোষণা মুছেছে",
  "اعلان حذف",
  "حذف إعلان"
 ],
 "audit.admin_appointed": [
  "Administrator appointed",
  "অ্যাডমিন নিয়োগ",
  "ایڈمن مقرر",
  "تعيين مسؤول"
 ],
 "audit.admin_removed": [
  "Administrator removed",
  "অ্যাডমিন অপসারিত",
  "ایڈمن ہٹایا گیا",
  "إزالة مسؤول"
 ],
 "audit.committee_updated": [
  "Committee updated",
  "কমিটি হালনাগাদ",
  "کمیٹی اپڈیٹ",
  "تحديث اللجنة"
 ],
 "audit.settings_changed": [
  "Settings changed",
  "সেটিংস পরিবর্তিত",
  "ترتیبات تبدیل",
  "تغيير الإعدادات"
 ]
};
