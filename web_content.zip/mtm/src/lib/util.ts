import { addDoc, collection, serverTimestamp, Timestamp } from 'firebase/firestore';
import { auth, db } from './firebase';
import type { Lang } from './i18n';

export interface Settings {
  logoUrl: string; contactNumber: string; address: string;
  bkash: string; nagad: string; bkashLink: string; nagadLink: string; accountType: string; paymentInstructions: string;
  donationInfo: string; monthlyAmount: number; specialAmount: number; defaultLanguage: Lang;
  custodianAmir: string; custodianFinance: string; custodianNote: string;
}
export const DEFAULT_SETTINGS: Settings = {
  logoUrl: '', contactNumber: '01630086396',
  address: "Jam Toli, Shofiullahkhata, Ukhiya, Cox's Bazar, Bangladesh",
  bkash: '', nagad: '', bkashLink: '', nagadLink: '', accountType: '', paymentInstructions: '', donationInfo: '',
  monthlyAmount: 100, specialAmount: 150, defaultLanguage: 'bn',
  custodianAmir: '', custodianFinance: '', custodianNote: ''
};
export interface CalendarDoc { id: string; hijriYear: number; fitrPeriod: string; adhaPeriod: string }

export const fmtMoney = (n: number) => '৳' + new Intl.NumberFormat('en-US').format(n || 0);
export const pad = (n: number) => String(n).padStart(2, '0');
export const periodOf = (d = new Date()) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}`;
export const todayISO = () => { const d = new Date(); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; };
const LOCALE: Record<Lang, string> = { en: 'en-US-u-nu-latn', bn: 'bn-BD-u-nu-latn', ur: 'ur-PK-u-nu-latn', ar: 'ar-u-nu-latn' };
export const monthLabel = (period: string, lang: Lang) => {
  const [y, m] = period.split('-').map(Number);
  return new Intl.DateTimeFormat(LOCALE[lang], { month: 'long', year: 'numeric' }).format(new Date(y, m - 1, 1));
};
export const fmtDate = (v: unknown, lang: Lang) => {
  const d = v && typeof (v as Timestamp).toDate === 'function' ? (v as Timestamp).toDate() : typeof v === 'string' && v ? new Date(v + (v.length === 10 ? 'T00:00:00' : '')) : null;
  return d && !isNaN(d.getTime()) ? new Intl.DateTimeFormat(LOCALE[lang], { dateStyle: 'medium' }).format(d) : '—';
};
export const lastPeriods = (n: number, from = new Date()) =>
  Array.from({ length: n }, (_, i) => periodOf(new Date(from.getFullYear(), from.getMonth() - i, 1)));

/** Contribution amount for a billing period: special months are those the owner mapped in the contribution calendar. */
export const amountFor = (period: string, s: Settings, cal: CalendarDoc[]) =>
  cal.some((c) => c.fitrPeriod === period || c.adhaPeriod === period) ? s.specialAmount : s.monthlyAmount;
export const specialKind = (period: string, cal: CalendarDoc[]): 'fitr' | 'adha' | null =>
  cal.some((c) => c.fitrPeriod === period) ? 'fitr' : cal.some((c) => c.adhaPeriod === period) ? 'adha' : null;

// ---- Hijri helpers (Umm al-Qura via Intl; owner must confirm with local moon sighting) ----
const hf = () => new Intl.DateTimeFormat('en-u-ca-islamic-umalqura-nu-latn', { day: 'numeric', month: 'numeric', year: 'numeric' });
export const hijriParts = (d: Date, f = hf()) => {
  const p = f.formatToParts(d); const g = (t: string) => Number(p.find((x) => x.type === t)?.value);
  return { y: g('year'), m: g('month'), d: g('day') };
};
export const HIJRI_MONTHS: Record<Lang, string[]> = {
  en: ['Muharram', 'Safar', "Rabi' al-Awwal", "Rabi' al-Thani", 'Jumada al-Awwal', 'Jumada al-Thani', 'Rajab', "Sha'ban", 'Ramadan', 'Shawwal', "Dhul Qa'dah", 'Dhul Hijjah'],
  bn: ['মুহাররম', 'সফর', 'রবিউল আউয়াল', 'রবিউস সানি', 'জুমাদাল উলা', 'জুমাদাস সানি', 'রজব', 'শাবান', 'রমযান', 'শাওয়াল', 'যিলকদ', 'যিলহজ'],
  ur: ['محرم', 'صفر', 'ربیع الاول', 'ربیع الثانی', 'جمادی الاولیٰ', 'جمادی الآخرہ', 'رجب', 'شعبان', 'رمضان', 'شوال', 'ذیقعدہ', 'ذوالحجہ'],
  ar: ['محرم', 'صفر', 'ربيع الأول', 'ربيع الآخر', 'جمادى الأولى', 'جمادى الآخرة', 'رجب', 'شعبان', 'رمضان', 'شوال', 'ذو القعدة', 'ذو الحجة']
};
export const hijriLabel = (d: Date, lang: Lang) => { const h = hijriParts(d); return `${h.d} ${HIJRI_MONTHS[lang][h.m - 1]} ${h.y}`; };
/** Gregorian billing period (YYYY-MM) in which the 1st of the given Hijri month falls. */
export function suggestPeriod(hijriYear: number, hijriMonth: number): string {
  const f = hf(); const gy = Math.floor(hijriYear * 0.970229 + 621.5744);
  for (let t = new Date(gy - 1, 0, 1).getTime(); t < new Date(gy + 2, 0, 1).getTime(); t += 86400000) {
    const h = hijriParts(new Date(t), f);
    if (h.y === hijriYear && h.m === hijriMonth && h.d === 1) return periodOf(new Date(t + 43200000));
  }
  return '';
}

export async function audit(action: string, ref = '', detail = '') {
  const u = auth.currentUser; if (!u) return;
  try { await addDoc(collection(db, 'audit_logs'), { uid: u.uid, action, ref, detail: detail.slice(0, 300), createdAt: serverTimestamp() }); } catch { /* non-fatal */ }
}
export const cleanPhone = (s: string) => s.replace(/[^\d+]/g, '');
export const errMsg = (e: unknown) => (e && typeof e === 'object' && 'code' in e ? String((e as { code: string }).code) : 'unknown');
