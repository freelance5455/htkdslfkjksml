import { createContext, useCallback, useContext, useEffect, useMemo, useState, ReactNode } from 'react';
import { DICT } from './dict';

export type Lang = 'en' | 'bn' | 'ur' | 'ar';
export const LANGS: { code: Lang; label: string }[] = [
  { code: 'bn', label: 'বাংলা' }, { code: 'en', label: 'English' }, { code: 'ur', label: 'اردو' }, { code: 'ar', label: 'العربية' }
];
export const isRTL = (l: Lang) => l === 'ur' || l === 'ar';
const IDX: Record<Lang, number> = { en: 0, bn: 1, ur: 2, ar: 3 };
const KEY = 'mtm.lang';

interface Ctx { lang: Lang; dir: 'rtl' | 'ltr'; rtl: boolean; setLang: (l: Lang) => void; t: (k: string, vars?: Record<string, string | number>) => string }
const LangCtx = createContext<Ctx>(null as unknown as Ctx);
export const useLang = () => useContext(LangCtx);

export function LangProvider({ children, defaultLang = 'bn' }: { children: ReactNode; defaultLang?: Lang }) {
  const [lang, setL] = useState<Lang>(() => (localStorage.getItem(KEY) as Lang) || defaultLang);
  const setLang = useCallback((l: Lang) => { localStorage.setItem(KEY, l); setL(l); }, []);
  useEffect(() => {
    const h = document.documentElement;
    h.lang = lang; h.dir = isRTL(lang) ? 'rtl' : 'ltr'; h.dataset.lang = lang;
  }, [lang]);
  const t = useCallback((k: string, vars?: Record<string, string | number>) => {
    const row = DICT[k];
    let s = row ? row[IDX[lang]] || row[0] : k;
    if (vars) for (const [a, b] of Object.entries(vars)) s = s.replace(`{${a}}`, String(b));
    return s;
  }, [lang]);
  const value = useMemo(() => ({ lang, dir: isRTL(lang) ? 'rtl' as const : 'ltr' as const, rtl: isRTL(lang), setLang, t }), [lang, setLang, t]);
  return <LangCtx.Provider value={value}>{children}</LangCtx.Provider>;
}
export const hasLocalLang = () => !!localStorage.getItem(KEY);
