import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { onAuthStateChanged, User } from 'firebase/auth';
import { collection, doc, onSnapshot, query, QueryConstraint, serverTimestamp, writeBatch, Timestamp } from 'firebase/firestore';
import { auth, db, OWNER_UID } from './firebase';
import { CalendarDoc, DEFAULT_SETTINGS, Settings } from './util';
import { Lang, useLang, hasLocalLang } from './i18n';

export type Role = 'owner' | 'super_admin' | 'finance_admin' | 'content_admin' | 'member';
export interface Profile {
  uid: string; fullName: string; phone: string; email: string; memberId: string; role: string;
  status: 'active' | 'inactive' | 'suspended'; language: Lang; photoUrl: string; position?: string; createdAt?: Timestamp;
}
interface Session {
  ready: boolean; user: User | null; profile: Profile | null; role: Role; isOwner: boolean;
  canManage: boolean; canFinance: boolean; canContent: boolean; isAdmin: boolean;
  settings: Settings; calendar: CalendarDoc[];
}
const Ctx = createContext<Session>(null as unknown as Session);
export const useSession = () => useContext(Ctx);

export const memberIdFor = (uid: string) => 'MTM-' + uid.slice(0, 6).toUpperCase();

export function SessionProvider({ children }: { children: ReactNode }) {
  const { setLang } = useLang();
  const [ready, setReady] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [adminRole, setAdminRole] = useState<Role>('member');
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);
  const [calendar, setCalendar] = useState<CalendarDoc[]>([]);

  useEffect(() => onAuthStateChanged(auth, (u) => { setUser(u); if (!u) { setProfile(null); setAdminRole('member'); setReady(true); } }), []);

  useEffect(() => {
    if (!user) return;
    let first = true;
    const off: Array<() => void> = [];
    off.push(onSnapshot(doc(db, 'users', user.uid), async (s) => {
      if (s.exists()) {
        const p = s.data() as Profile; setProfile(p);
        if (first && p.language) setLang(p.language);
        first = false; setReady(true);
      } else if (first) {
        // Recovery: account exists but profile write failed during registration.
        first = false;
        try {
          const b = writeBatch(db);
          const fullName = user.displayName || user.email || 'Member';
          b.set(doc(db, 'users', user.uid), { uid: user.uid, fullName, phone: '', email: user.email, memberId: memberIdFor(user.uid), role: 'member', status: 'active', language: 'bn', photoUrl: '', createdAt: serverTimestamp(), updatedAt: serverTimestamp() });
          b.set(doc(db, 'member_directory', user.uid), { uid: user.uid, fullName, memberId: memberIdFor(user.uid), status: 'active', position: '', joinedAt: serverTimestamp() });
          await b.commit();
        } catch { setReady(true); }
      }
    }, () => setReady(true)));
    off.push(onSnapshot(doc(db, 'admin_access', user.uid), (s) => setAdminRole(s.exists() ? (s.data().role as Role) : 'member'), () => setAdminRole('member')));
    off.push(onSnapshot(doc(db, 'foundation_settings', 'general'), (s) => {
      const d = { ...DEFAULT_SETTINGS, ...(s.exists() ? (s.data() as Partial<Settings>) : {}) } as Settings;
      setSettings(d);
      if (!hasLocalLang() && d.defaultLanguage) setLang(d.defaultLanguage);
    }, () => undefined));
    off.push(onSnapshot(collection(db, 'contribution_calendar'), (s) => setCalendar(s.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<CalendarDoc, 'id'>) }))), () => undefined));
    return () => off.forEach((f) => f());
  }, [user, setLang]);

  const isOwner = !!user && !!OWNER_UID && user.uid === OWNER_UID;
  const role: Role = isOwner ? 'owner' : adminRole;
  const canManage = role === 'owner' || role === 'super_admin';
  const value: Session = {
    ready, user, profile, role, isOwner, canManage,
    canFinance: canManage || role === 'finance_admin',
    canContent: canManage || role === 'content_admin',
    isAdmin: role !== 'member', settings, calendar
  };
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

/** Live Firestore query hook. Pass a stable key; constraints are rebuilt when the key changes. */
export function useCol<T>(path: string | null, key: string, ...cons: QueryConstraint[]) {
  const [data, setData] = useState<(T & { id: string })[]>([]);
  const [loading, setLoading] = useState(!!path);
  const [error, setError] = useState('');
  useEffect(() => {
    if (!path) { setLoading(false); return; }
    setLoading(true);
    return onSnapshot(query(collection(db, path), ...cons), (s) => {
      setData(s.docs.map((d) => ({ id: d.id, ...(d.data() as T) }))); setLoading(false); setError('');
    }, (e) => { setError(e.code); setLoading(false); });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [path, key]);
  return { data, loading, error };
}
