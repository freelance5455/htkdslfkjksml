import { useSession } from '../lib/session';
export function Logo({ size = 80 }: { size?: number }) {
  const { settings } = useSession();
  const src = settings.logoUrl || `${import.meta.env.BASE_URL}logo.jpg`;
  return <img src={src} width={size} height={size} alt="MTM" className="rounded-full bg-white object-cover" style={{ width: size, height: size }} onError={(e) => { (e.target as HTMLImageElement).src = `${import.meta.env.BASE_URL}logo.jpg`; }} />;
}
