import { useState } from 'react';
import { NavLink, Outlet, Link, useLocation, useNavigate } from 'react-router-dom';
import { useLang } from '../lib/i18n';
import { useSession } from '../lib/session';
import { Logo } from './Logo';

const Icon = ({ d }: { d: string }) => (
  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d={d} /></svg>
);
const ICONS = {
  home: 'M3 11l9-8 9 8v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z',
  coins: 'M12 3c4.4 0 8 1.3 8 3s-3.6 3-8 3-8-1.3-8-3 3.6-3 8-3zm8 3v6c0 1.7-3.6 3-8 3s-8-1.3-8-3V6m16 6v6c0 1.7-3.6 3-8 3s-8-1.3-8-3v-6',
  bell: 'M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9M13.7 21a2 2 0 0 1-3.4 0',
  users: 'M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8M23 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8',
  more: 'M4 6h16M4 12h16M4 18h16'
};

export function MemberLayout() {
  const { t } = useLang();
  const { settings } = useSession();
  const nav = useNavigate();
  const loc = useLocation();
  const tabs = [
    { to: '/', k: 'nav.home', i: ICONS.home }, { to: '/contributions', k: 'nav.contributions', i: ICONS.coins },
    { to: '/announcements', k: 'nav.announcements', i: ICONS.bell }, { to: '/committee', k: 'nav.committee', i: ICONS.users },
    { to: '/more', k: 'nav.more', i: ICONS.more }
  ];
  const root = ['/', '/contributions', '/announcements', '/committee', '/more'].includes(loc.pathname);
  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-forest-800 text-white sticky top-0 z-30" style={{ paddingTop: 'var(--safe-top)' }}>
        <div className="flex items-center gap-3 px-4 py-2.5">
          {!root ? <button onClick={() => nav(-1)} aria-label="back" className="text-2xl rtl-flip leading-none">‹</button> : <Logo size={34} />}
          <div className="flex-1 leading-tight min-w-0"><div className="font-semibold truncate tight">MTM Foundation</div>
            <div className="text-[11px] text-gold-400 truncate arabic-original" style={{ fontSize: 12, lineHeight: 1.4 }}>مؤسسة الطلاب المسلمين</div></div>
          <span className="text-[11px] text-white/60 hidden">{settings.contactNumber}</span>
        </div>
      </header>
      <main className="flex-1 p-4 pb-28 max-w-2xl w-full mx-auto"><Outlet /></main>
      <nav className="fixed bottom-0 inset-x-0 bg-white border-t border-cream-200 z-30 grid grid-cols-5" style={{ paddingBottom: 'var(--safe-bottom)' }}>
        {tabs.map((x) => (
          <NavLink key={x.to} to={x.to} end className={({ isActive }) => `flex flex-col items-center py-2 text-[11px] gap-0.5 ${isActive ? 'text-forest-700 font-semibold' : 'text-gray-400'}`}>
            <Icon d={x.i} /><span className="tight">{t(x.k)}</span>
          </NavLink>
        ))}
      </nav>
    </div>
  );
}

export function AdminLayout() {
  const { t } = useLang();
  const s = useSession();
  const [open, setOpen] = useState(false);
  const links = [
    { to: '/admin', k: 'adm.dashboard', show: true, end: true },
    { to: '/admin/members', k: 'adm.members', show: s.canManage },
    { to: '/admin/contributions', k: 'adm.contributions', show: s.canFinance },
    { to: '/admin/finance', k: 'adm.finance', show: s.canFinance },
    { to: '/admin/announcements', k: 'adm.announcements', show: s.canContent },
    { to: '/admin/committee', k: 'adm.committee', show: s.canManage },
    { to: '/admin/admins', k: 'adm.admins', show: s.isOwner },
    { to: '/admin/settings', k: 'adm.settings', show: s.isOwner },
    { to: '/admin/audit', k: 'adm.audit', show: s.canManage }
  ].filter((l) => l.show);
  return (
    <div className="min-h-screen">
      <header className="bg-forest-900 text-white sticky top-0 z-30" style={{ paddingTop: 'var(--safe-top)' }}>
        <div className="flex items-center gap-3 px-4 py-3">
          <button onClick={() => setOpen(true)} aria-label="menu"><Icon d={ICONS.more} /></button>
          <div className="flex-1 font-semibold tight">{t('adm.panel')}</div>
          <Link to="/" className="text-sm text-gold-400 tight">{t('adm.exit')}</Link>
        </div>
      </header>
      {open && (
        <div className="fixed inset-0 z-40 bg-black/40" onClick={() => setOpen(false)}>
          <aside className="bg-forest-900 text-white w-72 max-w-[80%] h-full p-4" style={{ paddingTop: 'calc(1rem + var(--safe-top))' }} onClick={(e) => e.stopPropagation()}>
            <div className="mb-4"><Logo size={56} /></div>
            {links.map((l) => (
              <NavLink key={l.to} to={l.to} end={l.end} onClick={() => setOpen(false)} className={({ isActive }) => `block rounded-xl px-3 py-3 mb-1 tight ${isActive ? 'bg-forest-700' : 'text-white/80'}`}>{t(l.k)}</NavLink>
            ))}
          </aside>
        </div>
      )}
      <main className="p-4 pb-16 max-w-3xl mx-auto"><Outlet /></main>
    </div>
  );
}
