import { ReactNode, createContext, useCallback, useContext, useState, ButtonHTMLAttributes, InputHTMLAttributes } from 'react';
import { useLang } from '../lib/i18n';

export const Card = ({ children, className = '' }: { children: ReactNode; className?: string }) => (
  <div className={`bg-white rounded-2xl border border-cream-200 shadow-sm p-4 ${className}`}>{children}</div>
);
export const H = ({ children, sub }: { children: ReactNode; sub?: string }) => (
  <div className="mb-3"><h1 className="text-xl font-semibold text-forest-800 tight">{children}</h1>{sub && <p className="text-sm text-gray-500">{sub}</p>}</div>
);
type BtnProps = ButtonHTMLAttributes<HTMLButtonElement> & { v?: 'primary' | 'gold' | 'ghost' | 'danger'; full?: boolean };
export const Btn = ({ v = 'primary', full, className = '', ...p }: BtnProps) => {
  const c = { primary: 'bg-forest-700 text-white active:bg-forest-900', gold: 'bg-gold-500 text-white active:bg-gold-600', ghost: 'bg-forest-50 text-forest-800 border border-forest-100', danger: 'bg-red-600 text-white' }[v];
  return <button {...p} className={`${c} ${full ? 'w-full' : ''} rounded-xl px-4 py-2.5 text-sm font-semibold disabled:opacity-50 ${className}`} />;
};
export const Field = ({ label, ...p }: InputHTMLAttributes<HTMLInputElement> & { label: string }) => (
  <label className="block mb-3"><span className="block text-sm text-gray-600 mb-1">{label}</span>
    <input {...p} className="w-full rounded-xl border border-cream-200 bg-cream-50 px-3 py-2.5 text-base outline-none focus:border-forest-500" /></label>
);
export const Area = ({ label, ...p }: React.TextareaHTMLAttributes<HTMLTextAreaElement> & { label: string }) => (
  <label className="block mb-3"><span className="block text-sm text-gray-600 mb-1">{label}</span>
    <textarea rows={4} {...p} className="w-full rounded-xl border border-cream-200 bg-cream-50 px-3 py-2.5 text-base outline-none focus:border-forest-500" /></label>
);
export const Sel = ({ label, children, ...p }: React.SelectHTMLAttributes<HTMLSelectElement> & { label: string }) => (
  <label className="block mb-3"><span className="block text-sm text-gray-600 mb-1">{label}</span>
    <select {...p} className="w-full rounded-xl border border-cream-200 bg-cream-50 px-3 py-2.5 text-base">{children}</select></label>
);
export const Badge = ({ children, tone = 'gray' }: { children: ReactNode; tone?: 'green' | 'red' | 'gold' | 'gray' }) => {
  const c = { green: 'bg-forest-100 text-forest-800', red: 'bg-red-100 text-red-700', gold: 'bg-yellow-100 text-yellow-800', gray: 'bg-gray-100 text-gray-600' }[tone];
  return <span className={`inline-block rounded-full px-2.5 py-0.5 text-xs font-semibold ${c}`}>{children}</span>;
};
export const Spinner = () => <div className="flex justify-center py-10"><div className="h-8 w-8 rounded-full border-4 border-forest-100 border-t-forest-700 animate-spin" /></div>;
export const Empty = ({ text }: { text: string }) => <div className="text-center text-gray-400 py-10 text-sm">{text}</div>;
export const ErrorBox = ({ code }: { code: string }) => {
  const { t } = useLang();
  return code ? <div className="rounded-xl bg-red-50 text-red-700 text-sm p-3 mb-3">{t(code === 'permission-denied' ? 'err.permission' : 'err.generic')}</div> : null;
};
export function Modal({ open, onClose, title, children }: { open: boolean; onClose: () => void; title: string; children: ReactNode }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-end sm:items-center justify-center" onClick={onClose}>
      <div className="bg-cream-50 w-full max-w-lg rounded-t-3xl sm:rounded-3xl p-5 max-h-[90vh] overflow-y-auto" style={{ paddingBottom: 'calc(1.25rem + var(--safe-bottom))' }} onClick={(e) => e.stopPropagation()}>
        <div className="flex justify-between items-center mb-3"><h2 className="font-semibold text-forest-800">{title}</h2>
          <button onClick={onClose} aria-label="close" className="text-2xl leading-none text-gray-400">×</button></div>
        {children}
      </div>
    </div>
  );
}

// ---- toast + confirm ----
interface UiCtx { toast: (m: string) => void; confirm: (m: string) => Promise<boolean> }
const Ui = createContext<UiCtx>(null as unknown as UiCtx);
export const useUi = () => useContext(Ui);
export function UiProvider({ children }: { children: ReactNode }) {
  const { t } = useLang();
  const [msg, setMsg] = useState('');
  const [ask, setAsk] = useState<{ m: string; res: (b: boolean) => void } | null>(null);
  const toast = useCallback((m: string) => { setMsg(m); setTimeout(() => setMsg(''), 2600); }, []);
  const confirm = useCallback((m: string) => new Promise<boolean>((res) => setAsk({ m, res })), []);
  const done = (b: boolean) => { ask?.res(b); setAsk(null); };
  return (
    <Ui.Provider value={{ toast, confirm }}>
      {children}
      {msg && <div className="fixed left-1/2 -translate-x-1/2 z-[60] bg-forest-900 text-white text-sm rounded-full px-4 py-2 shadow-lg" style={{ bottom: 'calc(90px + var(--safe-bottom))' }}>{msg}</div>}
      <Modal open={!!ask} onClose={() => done(false)} title={t('common.confirm')}>
        <p className="mb-4 text-gray-700">{ask?.m}</p>
        <div className="flex gap-2"><Btn full onClick={() => done(true)}>{t('common.yes')}</Btn><Btn full v="ghost" onClick={() => done(false)}>{t('common.cancel')}</Btn></div>
      </Modal>
    </Ui.Provider>
  );
}
export function LangPicker({ className = '' }: { className?: string }) {
  const { lang, setLang } = useLang();
  return (
    <div className={`flex gap-1 flex-wrap ${className}`}>
      {(['bn', 'en', 'ur', 'ar'] as const).map((c) => (
        <button key={c} onClick={() => setLang(c)} className={`px-3 py-1 rounded-full text-sm border tight ${lang === c ? 'bg-forest-700 text-white border-forest-700' : 'bg-white text-forest-800 border-cream-200'}`}>
          {{ bn: 'বাংলা', en: 'English', ur: 'اردو', ar: 'العربية' }[c]}
        </button>
      ))}
    </div>
  );
}
export const Arrow = () => <span className="rtl-flip inline-block">›</span>;
