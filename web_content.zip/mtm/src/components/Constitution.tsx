import { useLang } from '../lib/i18n';
import { Card, Badge } from './ui';
import { chapters, closingArabic, introTr, introUrdu, motto, openingArabic, Chapter } from '../content/constitution';

export function Constitution({ only, withIntro = true }: { only?: string[]; withIntro?: boolean }) {
  const { lang, t } = useLang();
  const list: Chapter[] = only ? chapters.filter((c) => only.includes(c.id)) : chapters;
  const review = lang !== 'ur' ? <Badge tone="gold">{t('const.review')}</Badge> : null;
  const pick = (c: { ur: string[]; en: string[]; bn: string[]; ar: string[] }) => (lang === 'ur' ? c.ur : c[lang]);
  const introBody = lang === 'ur' ? introUrdu : introTr[lang];
  return (
    <div className="space-y-4">
      {withIntro && (
        <Card className="text-center">
          {openingArabic.map((l, i) => <p key={i} dir="rtl" className={`arabic-original ${i < 4 ? 'font-bold text-forest-800' : ''}`}>{l}</p>)}
          <hr className="my-3 border-cream-200" />
          <div className="text-start space-y-2">{review}
            {introBody.map((p, i) => <p key={i} className={lang === 'ur' ? 'urdu-original' : ''}>{p}</p>)}
            {lang !== 'ur' && <details><summary className="text-sm text-forest-700">{t('const.original')}</summary>
              {introUrdu.map((p, i) => <p key={i} dir="rtl" className="urdu-original text-sm">{p}</p>)}</details>}
          </div>
        </Card>
      )}
      {list.map((ch) => (
        <Card key={ch.id}>
          <h2 className="text-lg font-semibold text-forest-800 mb-1 tight">{ch.title[lang]}</h2>
          {review}
          <ol className="mt-3 space-y-4">
            {ch.clauses.map((c, i) => (
              <li key={i} className="border-s-4 border-gold-400 ps-3">
                {c.n && <span className="text-gold-600 font-semibold me-2">{lang === 'ur' || lang === 'ar' ? c.n : String(i + 1)}.</span>}
                {pick(c).map((p, j) => <p key={j} className={`mb-2 ${lang === 'ur' ? 'urdu-original' : ''}`}>{p}</p>)}
                {lang !== 'ur' && ch.id !== 'name' && (
                  <details className="text-sm"><summary className="text-forest-700">{t('const.original')}</summary>
                    {c.ur.map((p, j) => <p key={j} dir="rtl" className="urdu-original">{p}</p>)}</details>)}
              </li>
            ))}
          </ol>
          {ch.note && (
            <div className="mt-3 bg-cream-100 rounded-xl p-3 text-sm">
              <div className="font-semibold text-forest-800 mb-1">{t('const.note')}</div>
              <p className={lang === 'ur' && ch.id !== 'name' ? 'urdu-original' : ''}>{lang === 'ur' ? ch.note.ur : ch.note[lang]}</p>
              {lang !== 'ur' && ch.id !== 'name' && <details><summary className="text-forest-700">{t('const.original')}</summary><p dir="rtl" className="urdu-original">{ch.note.ur}</p></details>}
            </div>
          )}
        </Card>
      ))}
      {withIntro && (
        <Card className="text-center">
          <p dir="rtl" className="arabic-original text-forest-800 font-bold">{motto}</p>
          {closingArabic.map((l, i) => <p key={i} dir="rtl" className="arabic-original">{l}</p>)}
        </Card>
      )}
    </div>
  );
}
