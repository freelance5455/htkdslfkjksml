# MTM Foundation — React + Capacitor + Firebase (Spark)

Mu'assasatut Tullab Al Muslimeen (MTM) · مؤسسة الطلاب المسلمين
One app for members and administrators. Bengali, English, Urdu (RTL, Nastaliq) and Arabic (RTL, Amiri).

> **Status of this package (please read):** the source was written and syntax-checked in an environment
> with **no internet, no npm registry and no Android SDK**. It has therefore **not** been installed,
> type-checked against the real libraries, run in a browser, or compiled to an APK, and the Firestore
> rules tests have not been executed. Expect to fix a few small compile errors on first `npm run build`.
> No APK is included.

## 1. Prerequisites
Node 18+, Java 17+, Android Studio (SDK 34), a Firebase project of your choice (Spark plan).

## 2. Firebase setup (use ONE existing project; nothing is created or deleted automatically)
1. Console → Build → **Authentication** → Sign-in method → enable **Email/Password**.
2. Build → **Firestore Database** → create (production mode).
3. Project settings → Your apps → add a **Web app** → copy the config into `.env` (copy `.env.example`).
4. Register the owner account **first** inside the app (Create account), then open Firebase Console →
   Authentication → Users → copy that user's **UID**.
5. **Owner UID setup (two places, same UID):**
   - `firestore.rules`: replace `REPLACE_WITH_OWNER_UID`.
   - `.env`: `VITE_OWNER_UID=<uid>` (only shows the owner screens; rules are the real authority).
6. Deploy rules: `npx firebase login && npx firebase use <your-project-id> && npx firebase deploy --only firestore:rules`
   (never use `allow read, write: if true`). Only rules are deployed; no other project is touched.
7. Log in as the owner → More → Admin Panel → Foundation settings: set bKash/Nagad numbers, logo URL, custodians,
   and the **contribution calendar** (Hijri year → Gregorian billing month for Shawwal and Dhul Hijjah).

## 3. Run / build
```
npm install
npm run dev            # browser test
npm run build          # type-check + bundle to dist/
```

## 4. Android APK
```
npm run cap:add        # creates android/ (Capacitor, appId com.mtmfoundation.app)
npm run assets         # generates launcher icon + splash from resources/
npm run cap:sync
npx cap open android   # Android Studio → Build → Build APK(s)
```
Debug APK: `cd android && ./gradlew assembleDebug` → `android/app/build/outputs/apk/debug/`.
Release: create a keystore (keep it private) and use Build → Generate Signed Bundle / APK.

## 5. Roles
| Role | Can |
|---|---|
| Primary Owner (UID in rules) | everything, only one who appoints/removes admins and edits settings/calendar |
| Super Admin | members, committee, contributions, finance, announcements, audit log |
| Finance Admin | contributions + income/expenses/approvals |
| Content Admin | announcements |
| Member | own profile, own contributions, published content |
Authority lives only in `admin_access/{uid}` (+ the owner UID in rules). The `role` field in `users` is display-only and rules force it to `member`.

## 6. Data model
`users` (private profile) · `member_directory` (name/ID/position only, so phone/email stay private) ·
`admin_access` · `committee_members` · `advisory_council` · `contributions` (id = `uid_YYYY-MM`, only PAID records exist,
so duplicates are impossible and unpaid = no document) · `financial_transactions` (marking a contribution paid also writes
income entry `contrib_<id>` atomically; approvals for expenses are stored inside the expense) ·
`announcements` · `foundation_settings/general` · `contribution_calendar/{hijriYear}` · `audit_logs` (append-only).
`member_directory` is the one collection added beyond the suggested list, because Firestore cannot hide fields.

## 7. Deviations from the brief (honest list)
- Constitution/Rules are **bundled in source** (`src/content/constitution.ts`) so the Arabic/Urdu text can never be altered
  by a database edit; there is no in-app constitution editor, so no `foundation_constitution` / `foundation_rules` collections.
- English, Bengali and the Arabic rendering of the Urdu clauses are marked **"Translation needs review"**; the original
  Urdu is one tap away on every clause. Have a scholar review them.
- The Eid contribution calendar is stored per Hijri year; "Suggest months" uses the Umm al-Qura calendar via `Intl`.
- The dashboard sums all transactions client-side (fine for a modest organization; it costs one read per transaction per load).
- Payment app buttons only appear if the owner enters an app link; no links are invented.
- Realtime sync uses Firestore listeners. Offline cache is enabled.

## 8. Security rules tests
`npm run test:rules` (needs Java + firebase-tools) runs `rules-test/rules.test.ts` covering: new member, ordinary member,
Finance Admin, Content Admin, Super Admin, Primary Owner.

## 9. Fonts
Amiri and Noto Nastaliq Urdu are bundled in `public/fonts/` (your uploaded files); Inter and Noto Sans Bengali come from `@fontsource`.
