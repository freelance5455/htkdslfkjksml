# Arcade Lab — Mundo dos Desafios

Projeto de jogo web mobile, sem bibliotecas externas e sem necessidade de internet para jogar.

## Recursos

- Minigames: memória das letras, memória de símbolos, matemática, sequência lógica e reflexo rápido.
- Área 2 de números de 1 a 10, desbloqueada por 100 moedas.
- Moedas e progresso persistidos no armazenamento local.
- Loja de acessórios com filtros e prévia fixa do avatar durante a rolagem do catálogo.
- Personalização de chapéu, roupa, pet, aura e cenário.
- Sala de testes ADM com senha `2143`.
- Efeitos sonoros gerados localmente por Web Audio.
- Narração em português via voz instalada no Android/browser (prioriza Google pt-BR quando disponível).
- Manifesto PWA e service worker para cache offline em navegadores compatíveis.

## Teste local

Extraia o projeto e abra `index.html` em Chrome ou outro navegador moderno. A voz deve ser testada após tocar em **Ajustes → Testar voz**.

## Preparar APK

Use um construtor que aceite importar um site local ou criar um APK com WebView. Aponte a página inicial para `index.html` e habilite JavaScript, DOM Storage/localStorage e áudio. Para narração, o WebView precisa suportar `SpeechSynthesis` ou oferecer integração com o Text-to-Speech nativo do Android.

## Sobre a voz

Este pacote não contém um arquivo de voz gravado. O próprio aparelho fala as frases do jogo, usando o mecanismo de Texto para fala instalado. Para uma voz Google em português do Brasil, configure o mecanismo Google Text-to-Speech e instale a voz pt-BR nas configurações do Android. A disponibilidade e o nome dos menus variam conforme o aparelho.

## Arquivos

- `index.html`: documento principal.
- `css/styles.css`: layout, cores e adaptação para celular.
- `js/app.js`: minigames, loja, avatar, ADM, som, voz e salvamento.
- `manifest.webmanifest`: metadados PWA.
- `service-worker.js`: cache offline.
- `assets/icon.svg`: ícone vetorial.
