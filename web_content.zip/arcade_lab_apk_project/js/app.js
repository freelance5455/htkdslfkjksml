(() => {
  'use strict';
  const $ = (selector, scope = document) => scope.querySelector(selector);
  const $$ = (selector, scope = document) => [...scope.querySelectorAll(selector)];
  const STORAGE_KEY = 'arcade_lab_progress_v2';
  const defaults = {
    coins: 0, wins: 0, played: 0, streak: 0, bestStreak: 0,
    area2: false, sound: true, voice: true,
    owned: [], equipped: { head: 'none', shirt: 'blue-basic', pet: 'none', aura: 'none', background: 'classic' }
  };
  let state = loadState();
  let page = 'home';
  let activeGame = null;
  let gameTimer = null;
  let toastTimer = null;
  let audioContext = null;
  let adminSession = false;
  let currentShopCategory = 'all';
  const main = $('#mainContent');

  const items = [
    { id:'cap', slot:'head', icon:'🧢', name:'Boné street', cost:35, description:'Visual urbano para a sua aventura.' },
    { id:'crown', slot:'head', icon:'👑', name:'Coroa real', cost:95, description:'Para quem domina os desafios.' },
    { id:'wizard', slot:'head', icon:'🧙', name:'Chapéu mágico', cost:70, description:'Um toque de fantasia.' },
    { id:'headphones', slot:'head', icon:'🎧', name:'Fone gamer', cost:55, description:'Pronto para entrar na partida.' },
    { id:'shirt-red', slot:'shirt', icon:'🔴', name:'Uniforme vermelho', cost:25, color:'#dc5268', description:'Cor vibrante.' },
    { id:'shirt-green', slot:'shirt', icon:'🟢', name:'Uniforme verde', cost:25, color:'#28a77c', description:'Estilo aventureiro.' },
    { id:'shirt-purple', slot:'shirt', icon:'🟣', name:'Uniforme violeta', cost:40, color:'#8b67d9', description:'Edição especial.' },
    { id:'shirt-gold', slot:'shirt', icon:'🌟', name:'Uniforme dourado', cost:85, color:'#d9a92f', description:'Brilhe na arena.' },
    { id:'pet-cat', slot:'pet', icon:'🐱', name:'Gatinho', cost:55, description:'Um companheiro fofo.' },
    { id:'pet-fox', slot:'pet', icon:'🦊', name:'Raposa', cost:75, description:'Esperta e veloz.' },
    { id:'pet-dragon', slot:'pet', icon:'🐉', name:'Dragão mini', cost:140, description:'Um parceiro lendário.' },
    { id:'pet-robot', slot:'pet', icon:'🤖', name:'Robô ajudante', cost:110, description:'Seu amigo tecnológico.' },
    { id:'aura-star', slot:'aura', icon:'✨', name:'Brilho estelar', cost:65, description:'Uma aura de estrelas.' },
    { id:'aura-purple', slot:'aura', icon:'💜', name:'Aura violeta', cost:100, description:'Energia misteriosa.' },
    { id:'aura-fire', slot:'aura', icon:'🔥', name:'Aura flamejante', cost:125, description:'Energia de campeão.' },
    { id:'bg-space', slot:'background', icon:'🌌', name:'Cenário espacial', cost:115, description:'Uma galáxia ao fundo.' },
    { id:'bg-sunset', slot:'background', icon:'🌇', name:'Pôr do sol', cost:90, description:'Um cenário dourado.' }
  ];
  const categories = [
    { id:'all', label:'Tudo' }, { id:'head', label:'Chapéus' }, { id:'shirt', label:'Roupas' },
    { id:'pet', label:'Pets' }, { id:'aura', label:'Auras' }, { id:'background', label:'Cenários' }
  ];
  const games = [
    { id:'letters', icon:'🔤', name:'Memória das letras', detail:'Veja uma letra e encontre a resposta.', reward:10, area:1 },
    { id:'symbols', icon:'🧩', name:'Memória de símbolos', detail:'Observe os símbolos e lembre a posição.', reward:12, area:1 },
    { id:'math', icon:'➕', name:'Conta relâmpago', detail:'Resolva a conta e marque o resultado.', reward:12, area:1 },
    { id:'sequence', icon:'🔢', name:'Sequência lógica', detail:'Descubra o próximo número.', reward:15, area:1 },
    { id:'reflex', icon:'⚡', name:'Reflexo rápido', detail:'Encontre o símbolo indicado.', reward:12, area:1 },
    { id:'numbers', icon:'🔟', name:'Área 2: números', detail:'Memorize números de 1 a 10.', reward:18, area:2 }
  ];

  function loadState() {
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
      return {
        ...structuredCloneSafe(defaults), ...saved,
        owned: Array.isArray(saved.owned) ? saved.owned : [],
        equipped: { ...defaults.equipped, ...(saved.equipped || {}) }
      };
    } catch (_) { return structuredCloneSafe(defaults); }
  }
  function structuredCloneSafe(obj) { return JSON.parse(JSON.stringify(obj)); }
  function save() {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch (_) { toast('Não foi possível salvar. Verifique o espaço do navegador.'); }
    updateWallet();
  }
  function updateWallet() { $('#walletAmount').textContent = state.coins.toLocaleString('pt-BR'); }
  function toast(message) {
    const node = $('#toast');
    node.textContent = message;
    node.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => node.classList.remove('show'), 2400);
  }
  function setNotice(message) { $('#noticeText').textContent = message; }
  function escapeHTML(value) {
    return String(value).replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
  }

  // Efeitos sonoros curtos gerados localmente. Nenhum arquivo ou internet é necessário.
  function playSound(type = 'tap') {
    if (!state.sound) return;
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return;
      audioContext = audioContext || new AudioCtx();
      if (audioContext.state === 'suspended') audioContext.resume();
      const notes = type === 'win' ? [523,659,784,1046] : type === 'coin' ? [740,990] : type === 'bad' ? [230,175] : [420];
      const start = audioContext.currentTime;
      notes.forEach((frequency, index) => {
        const oscillator = audioContext.createOscillator();
        const gain = audioContext.createGain();
        oscillator.type = 'sine';
        oscillator.frequency.setValueAtTime(frequency, start + index * .085);
        gain.gain.setValueAtTime(.0001, start + index * .085);
        gain.gain.exponentialRampToValueAtTime(.075, start + index * .085 + .018);
        gain.gain.exponentialRampToValueAtTime(.0001, start + index * .085 + .18);
        oscillator.connect(gain); gain.connect(audioContext.destination);
        oscillator.start(start + index * .085); oscillator.stop(start + index * .085 + .19);
      });
    } catch (_) { /* Som opcional: o jogo continua mesmo se o aparelho não o suportar. */ }
  }

  // Usa a voz instalada no Android/navegador. Quando disponível, prioriza uma voz Google em pt-BR.
  function speak(message) {
    if (!state.voice) return;
    if (!('speechSynthesis' in window) || !('SpeechSynthesisUtterance' in window)) {
      toast('Este construtor de APK não liberou a voz do Android. Use um WebView com suporte a Text-to-Speech.');
      return;
    }
    try {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(message);
      utterance.lang = 'pt-BR';
      utterance.rate = 0.96;
      utterance.pitch = 1.02;
      const voices = window.speechSynthesis.getVoices() || [];
      const portuguese = voices.filter(v => /^pt(-|_)?BR$/i.test(v.lang) || /portugu[eê]s.*brasil|portuguese.*brazil/i.test(v.name));
      const chosen = portuguese.find(v => /google/i.test(v.name)) || portuguese.find(v => /natural|neural/i.test(v.name)) || portuguese[0];
      if (chosen) utterance.voice = chosen;
      window.speechSynthesis.speak(utterance);
    } catch (_) { toast('Não consegui iniciar a voz neste aparelho.'); }
  }
  if ('speechSynthesis' in window) window.speechSynthesis.onvoiceschanged = () => {};

  function itemById(id) { return items.find(item => item.id === id); }
  function equipped(slot) { return itemById(state.equipped[slot]); }
  function avatarMarkup(compact = false) {
    const head = equipped('head');
    const shirt = equipped('shirt');
    const pet = equipped('pet');
    const aura = equipped('aura');
    const background = equipped('background');
    const bgClass = background?.id === 'bg-space' ? 'space' : '';
    const bg = background?.id === 'bg-sunset' ? 'linear-gradient(135deg,#d77762,#e8b85e 55%,#65528c)' : '';
    return `<div class="avatar-card ${compact ? 'compact' : ''}">
      <div class="avatar-stage ${bgClass}" ${bg ? `style="background:${bg}"` : ''}>
        ${aura ? `<div class="avatar-aura" style="border-color:${aura.id === 'aura-purple' ? '#c28cff' : aura.id === 'aura-fire' ? '#ff9a55' : '#ffe28c'}"></div>` : ''}
        <div class="avatar-figure">
          ${head ? `<div class="avatar-hat">${head.icon}</div>` : ''}
          <div class="avatar-head">🙂</div>
          <div class="avatar-torso" style="background:${shirt?.color || '#638cde'}"></div>
          <div class="avatar-legs"><i></i><i></i></div>
        </div>
        ${pet ? `<div class="avatar-pet">${pet.icon}</div>` : ''}
      </div>
      <div><h3>SEU PERSONAGEM</h3><div class="avatar-meta">${state.wins} vitórias • ${state.played} partidas</div></div>
      <div class="side-shortcuts"><button data-page="character">✏️ Editar</button><button data-page="shop">🛍️ Loja</button></div>
    </div>`;
  }

  function pageHeader(kicker, title, description) {
    return `<header class="page-heading"><div class="eyebrow">${kicker}</div><h2>${title}</h2><p>${description}</p></header>`;
  }
  function gameCardMarkup(game) {
    const locked = game.area === 2 && !state.area2;
    return `<button class="game-card" data-start-game="${game.id}" ${locked ? 'disabled' : ''}>
      ${locked ? '<span class="lock">🔒</span>' : ''}<span class="game-icon">${game.icon}</span>
      <strong>${game.name}</strong><p>${game.detail}</p><span class="reward-tag">🪙 ${game.reward} moedas</span>
    </button>`;
  }
  function renderHome() {
    main.innerHTML = `<section class="hero">
      <div class="eyebrow">🎮 SUA AVENTURA COMEÇA AGORA</div>
      <h1>Entre no jogo.<br>Mostre do que é capaz.</h1>
      <p>Explore desafios de memória, lógica, matemática e reflexo. Ganhe moedas, monte seu visual e conquiste novas áreas.</p>
      <div class="hero-actions"><button class="gold-button" data-page="games">▶ JOGAR AGORA</button><button class="secondary" data-page="character">✦ Personalizar</button></div>
    </section>
    <div class="stats-grid">
      <div class="stat-card"><strong>${state.coins.toLocaleString('pt-BR')} 🪙</strong><small>Suas moedas</small></div>
      <div class="stat-card"><strong>${state.wins}</strong><small>Vitórias</small></div>
      <div class="stat-card"><strong>${state.streak}</strong><small>Sequência atual</small></div>
      <div class="stat-card"><strong>${state.bestStreak}</strong><small>Melhor sequência</small></div>
    </div>
    <div class="section-heading"><div><h2>Escolha seu desafio</h2><p>Partidas rápidas, recompensas de verdade no jogo.</p></div><span class="pill">${state.area2 ? '2 áreas abertas' : 'Área 1 aberta'}</span></div>
    <div class="game-grid">${games.filter(g => g.area === 1).map(gameCardMarkup).join('')}</div>
    ${state.area2 ? `<div class="section-heading"><div><h2>Área 2 desbloqueada</h2><p>Agora os números de 1 a 10 também estão disponíveis.</p></div></div><div class="game-grid">${gameCardMarkup(games.find(g=>g.id==='numbers'))}</div>` : ''}`;
  }
  function renderGames() {
    main.innerHTML = `${pageHeader('CENTRAL DE DESAFIOS','Qual minigame vamos jogar?','Escolha um jogo. Cada acerto aumenta seu saldo de moedas.')}
      <div class="game-grid">${games.map(gameCardMarkup).join('')}</div>
      ${!state.area2 ? `<section class="area-unlock"><strong>🔐 Área 2: Desafio dos números</strong><p>Junte 100 moedas e desbloqueie um novo minigame com números de 1 a 10.</p><button class="gold-button" data-page="shop">VER COMO DESBLOQUEAR</button></section>` : ''}`;
  }
  function renderShop() {
    const list = items.filter(item => currentShopCategory === 'all' || item.slot === currentShopCategory);
    const categoryTabs = categories.map(cat => `<button class="equip-chip ${currentShopCategory===cat.id?'selected':''}" data-category="${cat.id}">${cat.label}</button>`).join('');
    const cards = list.map(item => {
      const owned = state.owned.includes(item.id);
      const active = state.equipped[item.slot] === item.id;
      return `<article class="shop-item"><div class="item-emoji">${item.icon}</div><strong>${item.name}</strong><p>${item.description}</p><div class="price">🪙 ${item.cost} moedas</div>
        <button data-shop-item="${item.id}" class="${owned?'owned':''}" ${!owned && state.coins<item.cost?'disabled':''}>${active?'EM USO':owned?'EQUIPAR':'COMPRAR'}</button></article>`;
    }).join('');
    main.innerHTML = `${pageHeader('MERCADO DO ARCADE','Loja de personalização','A lista rola dentro da própria loja; a prévia do personagem permanece fixa ao lado.')}
      <div class="shop-layout">
        <div class="shop-scroll"><div class="equip-grid" style="margin-bottom:12px">${categoryTabs}</div><div class="shop-grid">${cards || '<div class="empty">Nenhum item nesta categoria.</div>'}</div></div>
        <aside class="sticky-avatar">${avatarMarkup(false)}
          <section class="area-unlock"><strong>🔓 Próxima área</strong><p>${state.area2 ? 'Área 2 já desbloqueada!' : 'Desbloqueie o minigame de números de 1 a 10.'}</p>
          <button class="gold-button" style="width:100%" data-unlock-area ${state.area2 || state.coins<100?'disabled':''}>${state.area2?'DESBLOQUEADA':'100 🪙 • DESBLOQUEAR'}</button></section>
        </aside>
      </div>`;
  }
  function renderCharacter() {
    const slotLabels = { head:'Chapéus e acessórios', shirt:'Uniformes', pet:'Companheiros', aura:'Auras', background:'Cenários' };
    const sections = Object.entries(slotLabels).map(([slot,label]) => {
      const ownedItems = items.filter(item => item.slot === slot && state.owned.includes(item.id));
      const noneChip = slot === 'head' || slot === 'pet' || slot === 'aura' ? `<button class="equip-chip ${state.equipped[slot]==='none'?'selected':''}" data-equip="none:${slot}">Sem item</button>` : '';
      const chips = ownedItems.map(item => `<button class="equip-chip ${state.equipped[slot]===item.id?'selected':''}" data-equip="${item.id}">${item.icon} ${item.name}</button>`).join('');
      return `<section class="equip-group"><h3>${label}</h3><div class="equip-grid">${noneChip}${chips || (!noneChip ? '<span class="subtle">Ainda não há itens comprados aqui.</span>' : '')}</div></section>`;
    }).join('');
    main.innerHTML = `${pageHeader('ESTÚDIO DO AVATAR','Monte seu personagem','Equipe o que já comprou. A prévia é atualizada imediatamente.')}
      <div class="game-layout"><div class="panel character-sections">${sections}<button class="secondary" data-page="shop">🛍️ VISITAR A LOJA</button></div><aside class="game-side">${avatarMarkup(false)}</aside></div>`;
  }
  function renderSettings() {
    main.innerHTML = `${pageHeader('PREFERÊNCIAS','Ajustes do jogo','Configure os sons, a narração e o funcionamento do Arcade Lab.')}
      <div class="settings-grid">
        <section class="panel"><div class="setting-row"><div><strong>🔊 Efeitos sonoros</strong><p>Toques, acertos e recompensas.</p></div><button class="switch ${state.sound?'on':''}" data-setting="sound" aria-label="Alternar sons"></button></div>
          <div class="setting-row" style="margin-top:9px"><div><strong>🗣️ Narração por voz</strong><p>O jogo fala em português usando a voz instalada no aparelho.</p></div><button class="switch ${state.voice?'on':''}" data-setting="voice" aria-label="Alternar narração"></button></div>
          <button class="primary" style="width:100%;margin-top:13px" data-test-voice>▶ TESTAR VOZ</button>
          <p class="subtle" style="margin-top:10px">Preferência de voz: português do Brasil, priorizando uma voz Google quando disponível. A voz depende do mecanismo Text-to-Speech instalado no Android.</p>
        </section>
        <section class="panel"><h3 style="margin-top:0">📱 Sobre o jogo</h3><p class="subtle">Arcade Lab é um jogo offline. As moedas, compras, vitórias e itens ficam salvos neste dispositivo.</p><p class="subtle">Não é necessário criar conta nem conectar à internet para jogar.</p><button class="secondary" data-page="admin">🔐 Abrir sala ADM</button></section>
      </div>`;
  }

  function avatarSideCompact() { return `<aside class="game-side">${avatarMarkup(true)}</aside>`; }
  function chooseUnique(correct, pool, count=4) {
    const unique = [...new Set(pool.filter(x => String(x) !== String(correct)))];
    for (let i=unique.length-1;i>0;i--) { const j=Math.floor(Math.random()*(i+1)); [unique[i],unique[j]]=[unique[j],unique[i]]; }
    return [correct,...unique.slice(0,count-1)].sort(()=>Math.random()-.5);
  }
  function makeChallenge(type) {
    const config = games.find(g=>g.id===type);
    if (!config || (config.area===2 && !state.area2)) { toast('Desbloqueie a Área 2 primeiro.'); return null; }
    const data = { type, name:config.name, reward:config.reward, phase:'question', answered:false, attempts:0, instruction:'Escolha a resposta correta.' };
    if (type==='letters') {
      const alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split(''); data.answer=alphabet[Math.floor(Math.random()*alphabet.length)]; data.options=chooseUnique(data.answer,alphabet,4);
      data.phase='memorize'; data.instruction='Memorize a letra. Ela vai desaparecer antes da pergunta.'; data.memoryText=data.answer;
    } else if (type==='numbers') {
      data.answer=1+Math.floor(Math.random()*10); data.options=chooseUnique(data.answer,[1,2,3,4,5,6,7,8,9,10],4);
      data.phase='memorize'; data.instruction='Guarde o número que aparece na tela.'; data.memoryText=String(data.answer);
    } else if (type==='symbols') {
      const symbols=['🍎','🚀','⭐','🎈','🐱','⚽','🌈','🍀','🎲','🍉'];
      data.sequence=Array.from({length:4},()=>symbols[Math.floor(Math.random()*symbols.length)]);
      data.answer=data.sequence[1]; data.options=chooseUnique(data.answer,symbols,4);
      data.phase='memorize'; data.instruction='Memorize o segundo símbolo da sequência.'; data.memoryText=data.sequence.join('　');
    } else if (type==='math') {
      const a=2+Math.floor(Math.random()*18), b=1+Math.floor(Math.random()*12), subtract=Math.random()>.55;
      data.answer=subtract?Math.abs(a-b):a+b; data.question=subtract?`${Math.max(a,b)} − ${Math.min(a,b)} = ?`:`${a} + ${b} = ?`;
      data.options=chooseUnique(data.answer,Array.from({length:22},(_,i)=>i+1),4); data.instruction='Resolva a conta e toque no resultado.';
    } else if (type==='sequence') {
      const start=1+Math.floor(Math.random()*8), step=1+Math.floor(Math.random()*5);
      data.sequence=[start,start+step,start+2*step]; data.answer=start+3*step;
      data.options=chooseUnique(data.answer,[data.answer-2,data.answer-1,data.answer+1,data.answer+2,data.answer+4],4);
      data.question=`${data.sequence.join('　')}　?`; data.instruction='Descubra quanto aumenta a cada passo.';
    } else if (type==='reflex') {
      const symbols=['🍀','⭐','🔷','❤️','⚡','🌙','🔥','🎯'];
      data.answer=symbols[Math.floor(Math.random()*symbols.length)]; data.options=chooseUnique(data.answer,symbols,6);
      data.instruction=`Encontre rapidamente o símbolo ${data.answer}.`;
    }
    return data;
  }
  function startGame(type) {
    clearTimeout(gameTimer); activeGame=makeChallenge(type); if(!activeGame)return;
    page='game'; render(); playSound('tap');
    speak(`Vamos jogar ${activeGame.name}. ${activeGame.instruction}`);
    if(activeGame.phase==='memorize') {
      gameTimer=setTimeout(()=>{ if(activeGame && activeGame.phase==='memorize') hideMemory(); },3400);
    }
  }
  function hideMemory() {
    if(!activeGame || activeGame.phase!=='memorize')return;
    clearTimeout(gameTimer); activeGame.phase='question'; renderGame(); playSound('tap'); speak('Agora escolha a resposta que você memorizou.');
  }
  function renderGame() {
    if(!activeGame){page='games';render();return;}
    const g=activeGame;
    if(g.phase==='reward') {
      main.innerHTML = `<div class="game-layout"><section class="panel game-main reward-view"><div class="reward-medal">🏆</div><div class="eyebrow">MISSÃO CONCLUÍDA</div><h2>Mandou muito bem!</h2><p class="subtle">Você acertou o desafio e ganhou uma recompensa.</p><div class="reward-amount">+${g.reward} 🪙</div><p class="subtle">Seu saldo agora é de ${state.coins} moedas.</p><div class="hero-actions" style="justify-content:center"><button class="gold-button" data-next-game>PRÓXIMA PARTIDA</button><button class="secondary" data-page="games">ESCOLHER JOGO</button></div></section>${avatarSideCompact()}</div>`;
      speak(`Parabéns! Você ganhou ${g.reward} moedas.`); return;
    }
    const memorizing=g.phase==='memorize';
    let display='';
    if(memorizing) {
      const visual = g.type==='symbols' ? `<strong class="symbols">${g.memoryText}</strong>` : `<strong>${escapeHTML(g.memoryText)}</strong>`;
      display=`<div class="memory-display">${visual}</div><div class="game-status">Memorize com atenção. O jogo esconde automaticamente.</div><button class="gold-button" style="width:100%" data-hide-memory>JÁ MEMORIZEI — CONTINUAR</button>`;
    } else if(g.type==='math' || g.type==='sequence') {
      display=`<div class="memory-display"><strong style="font-size:clamp(33px,9vw,51px)">${escapeHTML(g.question)}</strong></div><p class="game-instruction">${g.instruction}</p>`;
    } else {
      display=`<p class="game-instruction">${g.type==='reflex'?'Toque no símbolo indicado.':'Qual era a resposta que apareceu antes?'}</p>`;
    }
    const options=memorizing?'':`<div class="choice-grid">${g.options.map((option,index)=>`<button class="choice" data-answer-index="${index}">${escapeHTML(option)}</button>`).join('')}</div>`;
    main.innerHTML=`<div class="game-layout"><section class="panel game-main">
      <div class="eyebrow">MINIGAME • RECOMPENSA ${g.reward} MOEDAS</div><h2 style="margin:5px 0 0">${g.name}</h2>
      <div class="progress-track"><span style="width:${memorizing?38:78}%"></span></div>
      ${display}${options}<div class="game-status" id="gameStatus" aria-live="polite"></div>
      <div style="display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap;margin-top:12px"><button class="secondary" data-page="games">SAIR DO JOGO</button><button class="secondary" data-repeat-game>RECOMEÇAR</button></div>
    </section>${avatarSideCompact()}</div>`;
  }
  function answerGame(index) {
    if(!activeGame || activeGame.answered || activeGame.phase!=='question')return;
    const g=activeGame; const chosen=g.options[index]; const correct=String(chosen)===String(g.answer);
    const buttons=$$('[data-answer-index]',main);
    buttons.forEach((button,i)=>{
      const value=g.options[i];
      if(String(value)===String(g.answer))button.classList.add('correct');
      if(i===index&&!correct)button.classList.add('wrong');
      button.disabled=true;
    });
    const status=$('#gameStatus');
    if(correct) {
      g.answered=true; if(status)status.textContent='✅ Resposta certa! Preparando sua recompensa...';
      playSound('win'); speak('Resposta correta! Muito bem!');
      gameTimer=setTimeout(()=>{
        state.coins+=g.reward; state.wins++; state.played++; state.streak++; state.bestStreak=Math.max(state.bestStreak,state.streak);
        g.phase='reward'; save(); renderGame(); playSound('coin');
      },1000);
    } else {
      g.answered=true; state.played++; state.streak=0; save(); playSound('bad');
      if(status)status.textContent=`Não foi dessa vez. A resposta certa era ${g.answer}. Tente novamente!`;
      speak(`Não foi dessa vez. A resposta era ${g.answer}. Você pode tentar outra partida.`);
      const retry=document.createElement('button'); retry.className='primary'; retry.textContent='TENTAR DE NOVO'; retry.style.width='100%'; retry.style.marginTop='10px'; retry.dataset.repeatGame='true';
      status?.insertAdjacentElement('afterend',retry);
    }
  }
  function renderAdmin() {
    if(!adminSession) {
      main.innerHTML=`${pageHeader('ÁREA PROTEGIDA','Sala ADM','Digite a senha de administrador para abrir as ferramentas de teste.')}
        <section class="panel" style="max-width:470px;margin:0 auto;text-align:center"><div style="font-size:48px">🔐</div><h3>Acesso de administrador</h3><p class="subtle">A senha abre uma sessão de teste. O painel não fica aberto depois que o jogo é reiniciado.</p><form id="adminForm"><input class="input" id="adminPassword" type="password" inputmode="numeric" maxlength="8" autocomplete="off" placeholder="Senha de acesso" aria-label="Senha de administrador"><button class="primary" style="width:100%" type="submit">ENTRAR NA SALA ADM</button></form><p id="adminError" class="subtle" role="alert"></p></section>`;
    } else {
      main.innerHTML=`${pageHeader('SESSÃO ADM ATIVA','Painel de testes','Use estas ferramentas para testar a loja, as moedas e as áreas do jogo.')}
        <section class="panel"><div class="stats-grid"><div class="stat-card"><strong>${state.coins}</strong><small>Saldo atual</small></div><div class="stat-card"><strong>${state.wins}</strong><small>Vitórias</small></div><div class="stat-card"><strong>${state.played}</strong><small>Partidas</small></div><div class="stat-card"><strong>${state.owned.length}</strong><small>Itens comprados</small></div></div>
        <h3>Adicionar moedas de teste</h3><div class="admin-actions"><button class="gold-button" data-add-coins="100">+100 moedas</button><button class="gold-button" data-add-coins="500">+500 moedas</button><button class="gold-button" data-add-coins="1000">+1.000 moedas</button><button class="gold-button" data-add-coins="5000">+5.000 moedas</button></div>
        <h3 style="margin-top:22px">Testes especiais</h3><div class="admin-actions"><button class="primary" data-admin-unlock-area>🔓 Liberar Área 2</button><button class="secondary" data-reset-demo>↺ Zerar progresso</button><button class="secondary" data-admin-logout>Fechar sessão ADM</button></div>
        <p class="subtle" style="margin-top:15px">As moedas adicionadas ficam salvas para você testar compras e desbloqueios.</p></section>`;
    }
  }
  function render() {
    updateWallet();
    $$('.bottom-nav button').forEach(button=>button.classList.toggle('active',button.dataset.page===page || (page==='game'&&button.dataset.page==='games') || (page==='admin'&&button.dataset.page==='settings')));
    if(page==='home')renderHome();
    else if(page==='games')renderGames();
    else if(page==='game')renderGame();
    else if(page==='shop')renderShop();
    else if(page==='character')renderCharacter();
    else if(page==='settings')renderSettings();
    else if(page==='admin')renderAdmin();
  }

  function navigate(nextPage) {
    if(nextPage==='admin') adminSession=false;
    clearTimeout(gameTimer);
    page=nextPage;
    if(nextPage!=='game')activeGame=null;
    render(); playSound('tap');
    const labels={home:'Bem-vindo de volta!',games:'Escolha um minigame e conquiste moedas.',shop:'A loja está aberta. Sua prévia fica fixa na tela.',character:'Personalize seu personagem.',settings:'Ajuste som e narração.'};
    setNotice(labels[nextPage] || 'Arcade Lab');
    main.focus({preventScroll:true});
  }

  // Eventos delegados: funcionam mesmo depois de trocar de tela várias vezes.
  document.addEventListener('click', event => {
    const button=event.target.closest('button'); if(!button || !document.getElementById('app').contains(button))return;
    if(button.dataset.page){navigate(button.dataset.page);return;}
    if(button.dataset.startGame){startGame(button.dataset.startGame);return;}
    if(button.hasAttribute('data-hide-memory')){hideMemory();return;}
    if(button.hasAttribute('data-answer-index')){answerGame(Number(button.dataset.answerIndex));return;}
    if(button.hasAttribute('data-repeat-game')){if(activeGame)startGame(activeGame.type);return;}
    if(button.hasAttribute('data-next-game')){
      const available=games.filter(g=>g.area===1 || state.area2);
      const next=available[Math.floor(Math.random()*available.length)]; startGame(next.id);return;
    }
    if(button.dataset.category){currentShopCategory=button.dataset.category;renderShop();return;}
    if(button.dataset.shopItem){purchaseOrEquip(button.dataset.shopItem);return;}
    if(button.dataset.equip){equipItem(button.dataset.equip);return;}
    if(button.hasAttribute('data-unlock-area')){unlockArea();return;}
    if(button.dataset.setting){state[button.dataset.setting]=!state[button.dataset.setting];save();renderSettings();if(button.dataset.setting==='voice'&&state.voice)speak('Narração ativada. Bem-vindo ao Arcade Lab!');return;}
    if(button.hasAttribute('data-test-voice')){state.voice=true;save();renderSettings();speak('Olá! Esta é a voz do Arcade Lab. Vamos jogar e conquistar muitas moedas!');return;}
    if(button.id==='soundToggle'){state.sound=!state.sound;save();syncHeaderToggles();playSound('tap');return;}
    if(button.id==='voiceToggle'){state.voice=!state.voice;save();syncHeaderToggles();if(state.voice)speak('Narração ativada.');return;}
    if(button.dataset.addCoins){state.coins+=Number(button.dataset.addCoins);save();renderAdmin();playSound('coin');toast(`${button.dataset.addCoins} moedas adicionadas.`);return;}
    if(button.hasAttribute('data-admin-unlock-area')){state.area2=true;save();renderAdmin();playSound('win');toast('Área 2 liberada!');return;}
    if(button.hasAttribute('data-admin-logout')){adminSession=false;renderAdmin();return;}
    if(button.hasAttribute('data-reset-demo')){if(window.confirm('Quer realmente apagar todo o progresso deste jogo?')){state=structuredCloneSafe(defaults);save();adminSession=true;renderAdmin();toast('Progresso zerado.');}return;}
  });

  document.addEventListener('submit', event => {
    if(event.target.id!=='adminForm')return;
    event.preventDefault();
    const input=$('#adminPassword');
    if(input && input.value==='2143'){adminSession=true;renderAdmin();playSound('win');speak('Acesso autorizado. Sala de administrador aberta.');}
    else {const error=$('#adminError');if(error)error.textContent='Senha incorreta. Confira os números e tente novamente.';playSound('bad');}
  });

  function purchaseOrEquip(id) {
    const item=itemById(id); if(!item)return;
    if(state.owned.includes(id)){state.equipped[item.slot]=id;save();renderShop();playSound('tap');toast(`${item.name} equipado!`);return;}
    if(state.coins<item.cost){toast('Você ainda não tem moedas suficientes.');return;}
    state.coins-=item.cost;state.owned.push(id);state.equipped[item.slot]=id;save();renderShop();playSound('coin');speak(`${item.name} comprado e equipado!`);toast(`${item.name} comprado!`);
  }
  function equipItem(idAndSlot) {
    if(idAndSlot.startsWith('none:')){
      const slot=idAndSlot.split(':')[1];state.equipped[slot]='none';save();renderCharacter();playSound('tap');return;
    }
    const item=itemById(idAndSlot);if(!item||!state.owned.includes(idAndSlot))return;
    state.equipped[item.slot]=idAndSlot;save();renderCharacter();playSound('tap');toast('Visual atualizado!');
  }
  function unlockArea() {
    if(state.area2){toast('A Área 2 já está desbloqueada.');return;}
    if(state.coins<100){toast('Você precisa juntar 100 moedas.');return;}
    state.coins-=100;state.area2=true;save();renderShop();playSound('win');speak('Parabéns! A Área 2 foi desbloqueada.');toast('Área 2 desbloqueada!');
  }
  function syncHeaderToggles(){
    $('#soundToggle').textContent=state.sound?'🔊':'🔇';
    $('#voiceToggle').textContent=state.voice?'🗣️':'🔕';
    $('#soundToggle').setAttribute('aria-pressed',String(state.sound));
    $('#voiceToggle').setAttribute('aria-pressed',String(state.voice));
  }

  // Inicialização do jogo.
  syncHeaderToggles();
  render();
  setNotice('Sua aventura está pronta. Escolha um desafio!');
  if ('serviceWorker' in navigator && location.protocol !== 'file:') {
    window.addEventListener('load', () => navigator.serviceWorker.register('./service-worker.js').catch(()=>{}));
  }
})();
