package app.green.panel

import android.app.Activity
import android.os.Bundle
import android.content.pm.PackageManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.JavascriptInterface
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private val requestCode = 2407
    private val permissionListener = Shizuku.OnRequestPermissionResultListener { code, result ->
        if (code == requestCode) {
            // A interface pode consultar novamente o estado após a resposta do usuário.
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Shizuku.addRequestPermissionResultListener(permissionListener)
        val web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(GreenBridge(), "GreenBridge")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class GreenBridge {
        @JavascriptInterface
        fun checkShizuku(): String {
            return try {
                if (!Shizuku.pingBinder()) return "Shizuku não está iniciado."
                if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                    "Shizuku conectado e autorizado. UID: ${Shizuku.getUid()}"
                } else {
                    runOnUiThread { Shizuku.requestPermission(requestCode) }
                    "Shizuku encontrado. Solicitação de autorização enviada."
                }
            } catch (e: Exception) {
                "Falha ao verificar Shizuku: ${e.message}"
            }
        }
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        super.onDestroy()
    }
}
