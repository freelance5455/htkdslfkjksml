#include <jni.h>

extern "C"
JNIEXPORT jstring JNICALL
Java_app_green_panel_NativeStatus_message(JNIEnv *env, jobject) {
    return env->NewStringUTF("GREEN native demo ready");
}
