# GREEN — protótipo Android

Este pacote contém uma interface HTML funcional de demonstração. O ESP desenhado é fictício: não lê memória, não identifica jogadores e não interage com o Free Fire.

## Sobre a porta do Shizuku
A porta de pareamento é usada pelo próprio Shizuku para iniciar o serviço via Depuração sem fio. Aplicativos integrados usam a API Binder do Shizuku e solicitam autorização; não devem pedir que o usuário copie a porta para um campo HTML.

## Abrir a interface
Abra `index.html` no navegador para testar os botões e a aparência.

## Integração Android
A pasta `android/` é um esqueleto de integração Kotlin/Java com a API oficial do Shizuku. Abra-a no Android Studio, sincronize o Gradle e compile. A dependência e o manifesto seguem o guia oficial:
https://github.com/RikkaApps/Shizuku-API

O módulo C++ é apenas uma ponte JNI de demonstração. Não possui funções de leitura de processos ou memória de jogos.
