DATA X USER V89 — DIRECT SESSION BALANCE SETTLEMENT

V89 changes:
• Session earning is settled directly into users/<UID>/balance from the user app transaction path; it no longer waits on a deployed Functions trigger for the normal stop flow.
• totalEarned and totalDataSold are updated immediately after the balance transaction.
• The stopped session gets balanceSettled=true / settlementVersion=V89_DIRECT.
• Login recovery retries stopped sessions that were not marked balanceSettled.
• V88 earning-claim / Functions path remains as a backup when direct settlement fails.
• Existing activation helper text remains: Contact Telegram @DATAXPROO.

IMPORTANT: V89 intentionally allows the signed-in user to write only the balance-related profile fields needed for session settlement. The rest of the protected profile fields remain Admin-only.
