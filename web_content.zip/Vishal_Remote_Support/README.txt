Vishal Remote Support - QR Pairing Prototype

1. Extract the ZIP.
2. Open index.html in a modern browser.
3. Internet is needed to load the QR generation/scanning libraries.
4. Camera and screen capture generally require HTTPS or localhost and explicit browser permission.

Important:
- QR pairing currently exchanges a demo room code only.
- It does NOT create a real connection or transmit screen/camera to another phone.
- Real two-device sharing requires a secure WebRTC signaling server and consent on the sharing device.
- This prototype does not support hidden capture or bypassing a locked phone.
