let net='local',mySeat=null,conns=[],lastFace=1,vsCpu=false,bt=0,teamMode=false,quickMode=false;
// Board shape depends on the number of players: 2-4 = square, 5 = star, 6 = hexagon, 7-8 = octagon
let A=8,R=5,D0=4,CH=11,L=88,HC=87,GOAL=91,V=11.6,AP=10.6,RB=8.9;
const PAL={
  4:[['#1e88e5','Blue'],['#e53935','Red'],['#43a047','Green'],['#fdd835','Yellow']],
  5:[['#e53935','Red'],['#fdd835','Yellow'],['#43a047','Green'],['#1e88e5','Blue'],['#8e24aa','Purple']],
  6:[['#e53935','Red'],['#fb8c00','Orange'],['#43a047','Green'],['#00bcd4','Cyan'],['#1e88e5','Blue'],['#8e24aa','Purple']],
  8:[['#e53935','Red'],['#fb8c00','Orange'],['#fdd835','Yellow'],['#43a047','Green'],['#00bcd4','Cyan'],['#1e88e5','Blue'],['#8e24aa','Purple'],['#ec407a','Pink']]
};
let COL=PAL[8].map(x=>x[0]),NAME=PAL[8].map(x=>x[1]);
const SETS={2:[0,2],3:[0,1,2],4:[0,1,2,3],5:[0,1,2,3,4],6:[0,1,2,3,4,5],7:[0,1,2,3,5,6,7],8:[0,1,2,3,4,5,6,7]};
const rad=k=>(90+360/A*k)*Math.PI/180;
const arm=(k,t,l)=>{const a=rad(k),d=D0+t;return [d*Math.cos(a)-l*Math.sin(a),d*Math.sin(a)+l*Math.cos(a)];};
const cellOf=m=>{const k=Math.floor(m/CH),q=m%CH;return q<R?[k,q,-1]:q===R?[k,R-1,0]:[k,2*R-q,1];};
const SK=k=>k*CH+R+2;
const SAFE=new Set();
const baseXY=k=>{const b=rad(k)+Math.PI/A;return [RB*Math.cos(b),RB*Math.sin(b)];};

let ACT=[],turn=0,rolled=null,busy=false,T={};
const EL=[],rings=[];
const board=document.getElementById('board');
const msg=document.getElementById('msg');
const dice=document.getElementById('dice');
const sleep=ms=>new Promise(r=>setTimeout(r,ms));

function makeTokens(){
  for(let k=0;k<8;k++){
    EL[k]=[];
    for(let i=0;i<4;i++){
      const t=document.createElement('div');t.className='tok';
      t.onclick=()=>move(k,i);
      board.appendChild(t);EL[k].push(t);
    }
  }
}
function outline(){
  const out=[];
  if(A===5){   // star: long arms with notches between them
    const h=Math.PI/A,VAL=RB+2.25;
    for(let k=0;k<A;k++){
      const v=rad(k)-h;out.push([VAL*Math.cos(v),VAL*Math.sin(v)]);
      out.push(arm(k,AP-D0,-1.9));out.push(arm(k,AP-D0,1.9));
    }
  }else{
    const rv=AP/Math.cos(Math.PI/A);
    for(let j=0;j<A;j++){const a=rad(0)+Math.PI/A+2*Math.PI/A*j;out.push([rv*Math.cos(a),rv*Math.sin(a)]);}
  }
  return out;
}
function drawBoard(){
  const poly=outline().map(p=>p[0].toFixed(2)+','+p[1].toFixed(2)).join(' ');
  const rect=(x,y,k,f)=>`<rect x="-.48" y="-.48" width=".96" height=".96" rx=".08" fill="${f}" stroke="#888" stroke-width=".05" transform="translate(${x.toFixed(2)} ${y.toFixed(2)}) rotate(${360/A*k})"/>`;
  const cr=(D0-.5)/Math.cos(Math.PI/A);
  let W='',ST='';const G=[];
  for(let k=0;k<A;k++){
    const a=rad(k),f=COL[k],h=Math.PI/A;
    const [bx,by]=baseXY(k);
    G[k]=`<polygon points="0,0 ${(cr*Math.cos(a-h)).toFixed(2)},${(cr*Math.sin(a-h)).toFixed(2)} ${(cr*Math.cos(a+h)).toFixed(2)},${(cr*Math.sin(a+h)).toFixed(2)}" fill="${f}"/>`
      +`<circle cx="${bx.toFixed(2)}" cy="${by.toFixed(2)}" r="1.9" fill="${f}"/><circle cx="${bx.toFixed(2)}" cy="${by.toFixed(2)}" r="1.45" fill="#fff"/>`;
    if(A===4)G[k]=G[k].split('<circle')[0]+`<rect x="${(bx-3).toFixed(2)}" y="${(by-3).toFixed(2)}" width="6" height="6" fill="${f}"/><rect x="${(bx-2).toFixed(2)}" y="${(by-2).toFixed(2)}" width="4" height="4" rx=".2" fill="#fff"/>`+[[-1,-1],[1,-1],[-1,1],[1,1]].map(([u,v])=>`<circle cx="${(bx+u*1.1).toFixed(2)}" cy="${(by+v*1.1).toFixed(2)}" r=".75" fill="${f}"/>`).join('');
    if(A===4)G[k]+=`<text x="${bx.toFixed(2)}" y="${(by+(by>0?2.72:-2.3)).toFixed(2)}" font-size=".85" font-weight="900" text-anchor="middle" fill="#fff" stroke="#0007" stroke-width=".12" paint-order="stroke">${k===0?'You':'Player '+(k+1)}</text>`;
    for(let t=0;t<R-1;t++){const [x,y]=arm(k,t,0);G[k]+=rect(x,y,k,f);}
  }
  for(let m=0;m<L;m++){
    const [k,t,l]=cellOf(m);
    const [x,y]=arm(k,t,l);
    let owner=-1;for(let j=0;j<A;j++)if(SK(j)===m)owner=j;
    if(owner>=0)G[owner]+=rect(x,y,k,COL[owner]);else W+=rect(x,y,k,'#fff');
    if(SAFE.has(m))ST+=`<text x="${x.toFixed(2)}" y="${(y+.22).toFixed(2)}" font-size=".7" text-anchor="middle" fill="#555">\u2605</text>`;
  }
  let s=`<svg viewBox="${-V} ${-V} ${2*V} ${2*V}" style="position:absolute;inset:0;width:100%;height:100%">`;
  s+=`<polygon points="${poly}" fill="#fff" stroke="#fff" stroke-width=".3" stroke-linejoin="round"/>`+W;
  for(let k=0;k<A;k++)s+=`<g id="g${k}">${G[k]}</g>`;
  s+=ST+'</svg>';
  const old=board.querySelector('svg');if(old)old.remove();
  board.insertAdjacentHTML('afterbegin',s);
}
function setBoard(n){
  const a=n<=4?4:n===5?5:n===6?6:8;
  if(a===A&&board.querySelector('svg'))return;
  A=a;R=a===4?6:a===5?7:5;D0=a===4?2:a===5?2.5:a===6?3:4;CH=2*R+1;L=A*CH;HC=L-1;GOAL=L+R-2;
  AP=a===4?7.5:D0+R+1.6;RB=a===4?6.36:a===5?6.3:a===6?7.3:8.9;
  COL=PAL[a].map(x=>x[0]);NAME=PAL[a].map(x=>x[1]);
  const ex=Math.max(...outline().flat().map(Math.abs));
  V=Math.ceil((ex+.4)*10)/10;
  SAFE.clear();for(let k=0;k<A;k++){SAFE.add(SK(k));SAFE.add((SK(k)+8)%L);}
  drawBoard();
  board.style.setProperty('--u',(100/(2*V))+'%');
  for(let k=0;k<8;k++)EL[k].forEach(e=>{e.style.background=COL[k]||'#888';e.style.setProperty('--tc',COL[k]||'#888');});
  for(let k=0;k<8;k++){
    const r=rings[k];if(!r)continue;
    if(k<A){const [x,y]=baseXY(k);r.style.display='';r.style.left=(x+V)/(2*V)*100+'%';r.style.top=(y+V)/(2*V)*100+'%';}
    else r.style.display='none';
  }
}
function buildBoard(){makeTokens();setBoard(8);}

// token position: -1 base, 0..L-2 main path, L-1..GOAL-1 home column, GOAL finished
function unit(k,i,p){
  if(p===-1){const [bx,by]=baseXY(k);const o=A===4?1.1:.7;return [bx+(i%2?o:-o),by+(i>>1?o:-o)];}
  if(p<=L-2){return arm(...cellOf((SK(k)+p)%L));}
  if(p<GOAL){return arm(k,R-2-(p-HC),0);}
  const fr=Math.min(1.6,(D0-.5)*.55);return [fr*Math.cos(rad(k)),fr*Math.sin(rad(k))];
}

function layout(){
  const g={};
  ACT.forEach(k=>T[k].forEach((p,i)=>{
    const [x,y]=unit(k,i,p);
    const key=x.toFixed(2)+','+y.toFixed(2);
    (g[key]=g[key]||[]).push([k,i,x,y,p]);
  }));
  const sz=.8/(2*V)*100;
  for(const key in g){
    const a=g[key];
    a.forEach(([k,i,x,y,p],j)=>{
      const e=EL[k][i];
      const off=a.length>1?(j-(a.length-1)/2)*.28:0;
      e.style.left=((x+off+V)/(2*V)*100-sz/2)+'%';
      e.style.top=((y+V)/(2*V)*100-sz/2)+'%';
      e.classList.toggle('done',p===GOAL);
    });
  }
  sync();
}

const movable=(k,d)=>[0,1,2,3].filter(i=>{
  const p=T[k][i];
  return p===-1?d===6:(p<GOAL&&p+d<=GOAL);
});

function placeDice(){
  const k=ACT[turn];if(k===undefined)return;
  const [bx,by]=baseXY(k),x=bx+(A===4?(by<0?-2.4:2.4):0),y=(by<0?-1:1)*(V+1.3);
  dice.style.left=(x+V)/(2*V)*100+'%';
  dice.style.top=(y+V)/(2*V)*100+'%';
  dice.style.boxShadow='0 0 0 3px '+COL[k]+',0 0 14px '+COL[k];
}
function say(t){
  msg.textContent=t;
  msg.style.color=COL[ACT[turn]]||'#fff';
  placeDice();
  sync();
  botTick();
}
function clearHL(){EL.forEach(a=>a.forEach(e=>e.classList.remove('hl')));}

function face(n){lastFace=n;
  const pips=[[4],[0,8],[0,4,8],[0,2,6,8],[0,2,4,6,8],[0,2,3,5,6,8]][n-1];
  dice.innerHTML='';
  for(let q=0;q<9;q++){const i=document.createElement('i');if(pips.includes(q))i.className='on';dice.appendChild(i);}
}

function reset(){
  const pn=+document.getElementById('np').value;
  setBoard(pn);ACT=SETS[pn];
  T={};ACT.forEach(k=>T[k]=[-1,-1,-1,-1]);
  for(let k=0;k<8;k++){
    const on=ACT.includes(k);
    const gg=document.getElementById('g'+k);if(gg)gg.style.opacity=on?1:.15;
    EL[k].forEach(e=>{e.style.display=on?'block':'none';e.classList.remove('hl');});
  }
  turn=0;rolled=null;busy=false;
  layout();face(1);
  say(NAME[ACT[0]]+'\u2019s turn \u2013 tap the dice');
}

const dn=k=>T[k].filter(q=>q===GOAL).length;
function next(){
  turn=(turn+1)%ACT.length;
  if(teamMode)for(let g=0;g<4&&dn(ACT[turn])===4;g++)turn=(turn+1)%ACT.length;
  say(NAME[ACT[turn]]+'\u2019s turn \u2013 tap the dice');
}

function roll(){
  if(busy||rolled!==null)return;
  busy=true;dice.classList.add('spin');bc({t:'spin'});
  let n=0;
  const t=setInterval(()=>{
    face(1+Math.random()*6|0);beep(260+Math.random()*340,.05,'square',.05);
    if(++n>8){
      clearInterval(t);
      const d=1+Math.random()*6|0;
      face(d);beep(d===6?988:587,.18,'triangle',.14);dice.classList.remove('spin');
      rolled=d;busy=false;afterRoll();
    }
  },70);
}

function afterRoll(){
  const k=ACT[turn],d=rolled,mv=movable(k,d);
  if(!mv.length){
    say(NAME[k]+' rolled '+d+' \u2013 no moves');
    busy=true;
    setTimeout(()=>{busy=false;rolled=null;next();},1000);
    return;
  }
  mv.forEach(i=>EL[k][i].classList.add('hl'));
  say(NAME[k]+' rolled '+d+' \u2013 tap a glowing token');
}

async function move(k,i){
  if(busy||rolled===null||k!==ACT[turn]||!movable(k,rolled).includes(i))return;
  busy=true;clearHL();
  const d=rolled;
  if(T[k][i]===-1){T[k][i]=0;beep(880,.1,'sine',.12);layout();await sleep(300);}
  else for(let s=0;s<d;s++){T[k][i]++;beep(420+s*40,.07,'triangle',.09);layout();await sleep(200);}
  let bonus=d===6;
  const p=T[k][i];
  if(p<=L-2){
    const a=(SK(k)+p)%L;
    if(!SAFE.has(a)){
      for(const o of ACT){
        if(o===k||(teamMode&&o===(k+2)%4))continue;
        T[o].forEach((q,j)=>{
          if(q>=0&&q<=L-2&&(SK(o)+q)%L===a){T[o][j]=-1;bonus=true;}
        });
      }
      layout();
    }
  }
  if(p===GOAL){bonus=true;[784,988,1175].forEach((f,i)=>setTimeout(()=>beep(f,.18,'triangle',.12),i*110));}
  const pr=(k+2)%4,need=quickMode?2:4,win=teamMode?dn(k)+dn(pr)>=need*2:dn(k)>=need;
  if(win){
    msg.textContent='\uD83C\uDFC6 '+(teamMode?NAME[k]+' & '+NAME[pr]+' win!':NAME[k]+' wins!');
    msg.style.color=COL[k];
    sync();
    return;
  }
  rolled=null;busy=false;
  if(bonus)say(NAME[k]+' gets another turn \u2013 roll!');
  else next();
}

dice.onclick=roll;
document.getElementById('ng').onclick=reset;
document.getElementById('np').onchange=reset;
buildBoard();
reset();

/* ===== Chat, emojis, mic ===== */
const $=id=>document.getElementById(id);
const pct=(x,y)=>[(x+V)/(2*V)*100+'%',(y+V)/(2*V)*100+'%'];
const me=()=>mySeat!==null?mySeat:ACT[turn]; // local mode: the player whose turn it is. Online: your own seat.

// ONLINE HOOK: replace receive(ev) below with a Firebase/Socket push,
// and call receive(ev) when data arrives from the other players.
function emit(ev){
  if(net==='local')receive(ev);
  else if(net==='host'){receive(ev);bc(ev);}
  else if(hostConn)hostConn.send(ev);
}

function toast(t){const e=$('toast');if($('stt')&&$('lob').classList.contains('show'))$('stt').textContent=t;e.textContent=t;e.classList.add('show');clearTimeout(toast.t);toast.t=setTimeout(()=>e.classList.remove('show'),2500);}

for(let k=0;k<8;k++){
  const r=document.createElement('div');r.className='ring';
  const [l,t]=pct(...baseXY(k));r.style.left=l;r.style.top=t;
  board.appendChild(r);rings.push(r);
}

// Emojis
const EMO=[['\u{1F602}','shake'],['\u{1F60D}','pulse'],['\u{1F621}','shake'],['\u{1F62D}','bounce'],['\u{1F44F}','bounce'],['\u{1F525}','pulse'],['\u{1F389}','spin'],['\u{1F60E}','bounce']];
EMO.forEach(([e,a])=>{
  const b=document.createElement('button');b.className='eb';b.textContent=e;
  b.onclick=()=>emit({t:'emo',k:me(),e:e,a:a});
  $('tray').appendChild(b);
});
$('emo').onclick=()=>$('tray').classList.toggle('show');

function floatEmo(k,e,a){
  const d=document.createElement('div');d.className='fl';
  const [l,t]=pct(...baseXY(k));d.style.left=l;d.style.top=t;
  const s=document.createElement('span');s.className='a-'+a;s.textContent=e;
  d.appendChild(s);board.appendChild(d);
  setTimeout(()=>d.remove(),2000);
}

// Chat
let unread=0;
function addMsg(k,x){
  const row=document.createElement('div');
  const n=document.createElement('b');n.textContent=NAME[k]+': ';n.style.color=COL[k];
  row.appendChild(n);row.appendChild(document.createTextNode(x));
  $('cm').appendChild(row);$('cm').scrollTop=1e6;
  if(!$('chat').classList.contains('open')){unread++;$('bd').textContent=unread;$('bd').style.display='block';}
}
function receive(ev){
  if(ev.t==='chat')addMsg(ev.k,ev.x);
  if(ev.t==='emo')floatEmo(ev.k,ev.e,ev.a);
  if(ev.t==='spk')rings[ev.k].classList.toggle('speak',ev.on);
}
$('cht').onclick=()=>{
  const c=$('chat');c.classList.toggle('open');
  if(c.classList.contains('open')){unread=0;$('bd').style.display='none';}
};
function sendChat(){
  const v=$('ci').value.trim();if(!v)return;
  emit({t:'chat',k:me(),x:v});$('ci').value='';
}
$('cs').onclick=sendChat;
$('ci').onkeydown=e=>{if(e.key==='Enter')sendChat();};
document.addEventListener('click',e=>{
  const c=$('chat');
  if(c.classList.contains('open')&&!c.contains(e.target)&&!$('cht').contains(e.target))c.classList.remove('open');
});

// Mic: tap once to turn on, then tap to mute / unmute
let stream=null,an=null,micState='off';
async function micTap(){
  if(net!=='local'&&!roomVoice){toast('Voice chat is off in this room');return;}
  if(micState==='off'){
    if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia){toast('Mic needs an https link. Publish the game first.');return;}
    try{
      stream=await navigator.mediaDevices.getUserMedia({audio:true});
    }catch(e){toast('Mic blocked. Allow microphone in browser settings.');return;}
    const ac=new (window.AudioContext||window.webkitAudioContext)();
    an=ac.createAnalyser();an.fftSize=256;
    ac.createMediaStreamSource(stream).connect(an);
    micState='live';callAll();
    toast('Mic on');
  }else{
    micState=micState==='live'?'mute':'live';
    stream.getAudioTracks().forEach(t=>t.enabled=micState==='live');
    toast(micState==='live'?'Mic on':'Muted');
  }
  $('mic').className='rb '+micState;
}
$('mic').onclick=micTap;
const buf=new Uint8Array(128);
let wasSpk=false;
setInterval(()=>{
  let spk=false;
  if(micState==='live'&&an){an.getByteFrequencyData(buf);let s=0;for(let i=0;i<buf.length;i++)s+=buf[i];spk=s/buf.length>18;}
  $('mic').classList.toggle('speak',spk);
  if(net==='local'){rings.forEach(r=>r.classList.remove('speak'));if(spk)rings[me()].classList.add('speak');}
  else if(spk!==wasSpk){wasSpk=spk;emit({t:'spk',k:me(),on:spk});}
},120);
board.appendChild(dice);placeDice();

/* ===== Home screen ===== */
const home=$('home'),pick=$('pick');
document.querySelectorAll('.soon').forEach(b=>b.onclick=()=>toast('Coming soon!'));
$('pnp').onclick=()=>pick.classList.add('show');
$('pc').onclick=()=>pick.classList.remove('show');
for(let n=2;n<=8;n++){
  const b=document.createElement('button');b.textContent=n;
  b.onclick=()=>{
    $('np').value=n;pick.classList.remove('show');
    home.style.display='none';$('gm').style.display='flex';
    reset();
  };
  $('pg').appendChild(b);
}
$('hb').onclick=()=>{$('gm').style.display='none';home.style.display='block';};

/* ===== Play with friends (PeerJS) ===== */
let peer=null,hostConn=null,started=false,peersList=[],myName='Player',sp=null,roomPw='',peerTm=0,peerTried=0,peerCt=0,quick=false,qt=0,qTry=0;
const CODEC='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const bc=ev=>conns.forEach(c=>{try{if(c.open&&c.auth)c.send(ev);}catch(e){}});
function sync(){
  if(net!=='host')return;
  bc({t:'state',ACT:ACT,T:T,turn:turn,rolled:rolled,busy:busy,face:lastFace,msg:msg.textContent,col:msg.style.color});
}
function setActive(){
  for(let k=0;k<8;k++){
    const on=ACT.includes(k);
    const gg=$('g'+k);if(gg)gg.style.opacity=on?1:.15;
    EL[k].forEach(e=>{e.style.display=on?'block':'none';});
  }
}
function enterGame(){
  $('lob').classList.remove('show');home.style.display='none';$('gm').style.display='flex';
  $('np').style.display='none';$('ng').style.display=net==='host'?'':'none';
}
function leaveNet(){
  try{if(peer)peer.destroy();}catch(e){}
  peer=null;hostConn=null;conns=[];started=false;net='local';mySeat=null;peersList=[];roomPw='';quick=false;clearTimeout(qt);roomMin=2;roomMax=8;roomVoice=true;autoCode=false;
  $('np').style.display='';$('ng').style.display='';
  $('l1').style.display='';$('l2').style.display='none';$('lob').classList.remove('rm');
  clearHL();
}
let curCode='',roomMin=2,roomMax=8,roomVoice=true,autoCode=false;
function showRoom(code){
  curCode=code;
  if(quick)$('lob').classList.add('show');
  $('l1').style.display='none';$('l2').style.display='';$('lob').classList.add('rm');
  $('rcode').textContent=code;
  $('rbox').style.display=quick?'none':'';
}
function avFor(n){let h=0;for(const c of n)h=(h*31+c.charCodeAt(0))>>>0;return AVS[h%AVS.length];}
function lobbyList(list,max){
  const mx=max||roomMax;
  const nm=(list[0]||'').replace(/ \(host\)$/,'');
  $('hav').textContent=nm===pname?pav:avFor(nm);$('hname').textContent=nm;
  const s=$('slots');s.innerHTML='';
  for(let i=1;i<mx;i++){
    const d=mk('div','','slot'+(list[i]?' on':''));
    if(list[i]){d.appendChild(mk('div',list[i]===pname?pav:avFor(list[i]),'sav'));d.appendChild(mk('div',list[i],'snm'));}
    else d.appendChild(mk('div','\uD83D\uDC64+','sadd'));
    s.appendChild(d);
  }
  $('rmode').textContent='Classic \u203A Players: '+list.length+' / '+mx;
  if(!hostConn){const ok=list.length>=roomMin;$('st').disabled=!ok;$('st').textContent=ok?'Start game':'Need '+roomMin+' players';}
}
function lobbyUpdate(){
  const list=[myName+' (host)',...conns.filter(c=>c.auth).map(c=>c.name||'Player')];
  lobbyList(list,roomMax);bc({t:'lobby',list:list,max:roomMax,min:roomMin,voice:roomVoice});
  if(quick&&!started){
    if(list.length>=8)startGame();
    else if(list.length>=2){clearTimeout(qt);qt=setTimeout(()=>{if(!started)startGame();},10000);toast('Game starts in 10 seconds');}
  }
}
function getName(){myName=($('nm').value.trim()||'Player').slice(0,12);}
function netOK(){if(typeof Peer==='undefined'){toast('Needs internet to load PeerJS');return false;}return true;}

const PSRC=['https://cdn.jsdelivr.net/npm/peerjs@1.5.4/dist/peerjs.min.js','https://unpkg.com/peerjs@1.5.4/dist/peerjs.min.js','https://cdnjs.cloudflare.com/ajax/libs/peerjs/1.5.4/peerjs.min.js'];
function loadPeer(retry){
  if(peerTried>=PSRC.length){peerTried=0;toast('Cannot load online mode. Check internet and open the game in Chrome.');return;}
  toast('Loading online mode...');
  const s=document.createElement('script');s.src=PSRC[peerTried++];
  s.onload=()=>{if(typeof Peer==='undefined'){loadPeer(retry);return;}peerTried=0;retry();};
  s.onerror=()=>loadPeer(retry);
  document.head.appendChild(s);
}
function createRoom(){
  if(typeof Peer==='undefined'){loadPeer(createRoom);return;}getName();$('stt').textContent='Connecting...';
  const code=$('pw').value.trim();
  if(code.length<4){toast('Room number needs 4 to 6 digits');return;}
  peer=new Peer('lodu-'+code);
  clearTimeout(peerTm);peerTm=setTimeout(()=>{clearInterval(peerCt);if(quick){$('lob').classList.add('show');$('l1').style.display='';}diag();},12000);
  let sec=0;clearInterval(peerCt);peerCt=setInterval(()=>{$('stt').textContent='Connecting... '+(++sec)+'s';},1000);
  peer.on('open',()=>{clearTimeout(peerTm);clearInterval(peerCt);showRoom(code);$('st').style.display='';lobbyUpdate();});
  peer.on('error',e=>{
    if(e.type==='unavailable-id'){try{peer.destroy();}catch(x){}peer=null;clearTimeout(peerTm);if(quick&&++qTry<4)joinRoom();else if(autoCode&&++qTry<6){$('pw').value=genCode();createRoom();}else toast('That number is already used. Pick another.');}
    else{clearTimeout(peerTm);clearInterval(peerCt);toast('Server error ('+e.type+'). Try Wi-Fi or Chrome.');}
  });
  peer.on('connection',c=>{
    if(started||conns.length>=roomMax-1){c.on('open',()=>{c.send({t:'full'});setTimeout(()=>c.close(),300);});return;}
    conns.push(c);
    c.on('data',d=>onHost(c,d));
    c.on('close',()=>{conns=conns.filter(x=>x!==c);if(started)toast((c.name||'A player')+' left');else lobbyUpdate();});
  });
  peer.on('call',onCall);
}
function onHost(c,d){
  if(d.t==='hello'){
    if(roomPw&&String(d.pw||'')!==roomPw){conns=conns.filter(x=>x!==c);try{c.send({t:'bad'});}catch(e){}setTimeout(()=>c.close(),400);return;}
    c.auth=true;c.name=String(d.name||'Player').slice(0,12);lobbyUpdate();return;
  }
  if(!c.auth||!started)return;
  if(d.t==='roll'&&ACT[turn]===c.seat)roll();
  else if(d.t==='move'&&ACT[turn]===c.seat)move(c.seat,d.i);
  else if(d.t==='chat'||d.t==='emo'||d.t==='spk'){d.k=c.seat;receive(d);bc(d);}
}
function startGame(){
  conns=conns.filter(c=>c.auth);
  const n=1+conns.length;
  if(n<roomMin){toast('Need '+roomMin+' players to start');return;}
  started=true;net='host';
  $('np').value=n;mySeat=SETS[n][0];
  conns.forEach((c,i)=>{c.seat=SETS[n][i+1];});
  peersList=[peer.id,...conns.map(c=>c.peer)];
  conns.forEach(c=>c.send({t:'start',seat:c.seat,ACT:SETS[n],peers:peersList,voice:roomVoice}));
  enterGame();
  reset();
}
function joinRoom(){
  if(typeof Peer==='undefined'){loadPeer(joinRoom);return;}getName();
  const code=$('rc').value.trim().toUpperCase();
  if(code.length<4){toast('Enter the room number');return;}
  peer=new Peer();
  peer.on('open',()=>{
    hostConn=peer.connect('lodu-'+code,{reliable:true});
    clearTimeout(peerTm);peerTm=setTimeout(()=>{if(hostConn&&!hostConn.open)toast('Could not connect. Check the code, or try Wi-Fi.');},12000);
    hostConn.on('open',()=>{clearTimeout(peerTm);hostConn.send({t:'hello',name:myName});showRoom(code);$('st').style.display='none';});
    hostConn.on('data',onClient);
    hostConn.on('close',()=>{
      toast('Host left the room');leaveNet();
      $('lob').classList.remove('show');$('gm').style.display='none';home.style.display='block';
    });
  });
  peer.on('error',e=>{
    if(e.type==='peer-unavailable'&&quick&&++qTry<4){try{peer.destroy();}catch(x){}peer=null;createRoom();return;}
    toast(e.type==='peer-unavailable'?'Room not found':'Server error ('+e.type+'). Try Wi-Fi or Chrome.');
  });
  peer.on('call',onCall);
}
function stopSpin(){clearInterval(sp);dice.classList.remove('spin');}
function spinFx(){stopSpin();dice.classList.add('spin');sp=setInterval(()=>face(1+Math.random()*6|0),70);setTimeout(stopSpin,1500);}
function onClient(d){
  if(d.t==='lobby'){roomMax=d.max||8;roomMin=d.min||2;roomVoice=d.voice!==false;lobbyList(d.list,roomMax);}
  else if(d.t==='full'){toast('Room is full or already started');leaveNet();}
  else if(d.t==='bad'){toast('Wrong password');leaveNet();}
  else if(d.t==='start'){net='client';started=true;mySeat=d.seat;ACT=d.ACT;peersList=d.peers;roomVoice=d.voice!==false;setBoard(ACT.length);setActive();enterGame();}
  else if(d.t==='spin')spinFx();
  else if(d.t==='state'){
    ACT=d.ACT;T=d.T;turn=d.turn;rolled=d.rolled;
    stopSpin();face(d.face);layout();
    msg.textContent=d.msg;msg.style.color=d.col;placeDice();clearHL();
    if(rolled!==null&&!d.busy&&ACT[turn]===mySeat)movable(mySeat,rolled).forEach(i=>EL[mySeat][i].classList.add('hl'));
  }
  else if(d.t==='chat'||d.t==='emo'||d.t==='spk')receive(d);
}

// Voice between phones
function onCall(call){
  call.answer();
  call.on('stream',st=>{
    const a=document.createElement('audio');a.srcObject=st;a.autoplay=true;a.setAttribute('playsinline','');
    document.body.appendChild(a);if(a.play)a.play().catch(()=>{});
  });
}
function callAll(){
  if(!peer||!stream)return;
  peersList.forEach(id=>{if(id!==peer.id)peer.call(id,stream);});
}

// Inputs
dice.onclick=()=>{
  if(net==='client')hostConn.send({t:'roll'});
  else if(net==='host'&&ACT[turn]!==mySeat)toast('Not your turn');
  else if(vsCpu&&ACT[turn]!==0)return;
  else roll();
};
const tokClick=(k,i)=>{
  if(net==='client'){if(k===mySeat)hostConn.send({t:'move',i:i});}
  else if(net==='host'&&k!==mySeat)return;
  else if(vsCpu&&k!==0)return;
  else move(k,i);
};
for(let k=0;k<8;k++)for(let i=0;i<4;i++)EL[k][i].onclick=()=>tokClick(k,i);

['pw','rc'].forEach(id=>$(id).addEventListener('input',e=>{e.target.value=e.target.value.replace(/\D/g,'');}));
async function diag(){
  const out=[],show=()=>{$('stt').textContent=out.join(' | ');};
  out.push(navigator.onLine?'Internet: yes':'Internet: NO');
  out.push(typeof Peer!=='undefined'?'Library: ok':'Library: MISSING');
  out.push(window.RTCPeerConnection?'WebRTC: ok':'WebRTC: NOT supported');
  out.push('Server: testing...');show();
  const ok=await new Promise(res=>{
    try{
      const w=new WebSocket('wss://0.peerjs.com/peerjs?key=peerjs&id=lodutest'+Date.now()+'&token=t1');
      const t=setTimeout(()=>{try{w.close();}catch(e){}res(false);},8000);
      w.onopen=()=>{clearTimeout(t);try{w.close();}catch(e){}res(true);};
      w.onerror=()=>{clearTimeout(t);res(false);};
    }catch(e){res(false);}
  });
  out[out.length-1]=ok?'Server: ok':'Server: CANNOT REACH';show();
}
$('dg').onclick=diag;
$('frd').onclick=()=>$('lob').classList.add('show');
$('jn').onclick=joinRoom;
$('st').onclick=startGame;
$('lc').onclick=()=>{if(started)return;leaveNet();$('lob').classList.remove('show');};
$('hb').onclick=()=>{clearTimeout(bt);vsCpu=false;leaveNet();$('gm').style.display='none';home.style.display='block';};

/* ===== Computer players, Event, Inventory, Social, Adda ===== */
function botPick(k,mv,d){
  let best=mv[0],bs=-1;
  mv.forEach(i=>{
    const p=T[k][i],np=p===-1?0:p+d;let s=np/10;
    if(p===-1)s+=40;
    if(np===GOAL)s+=90;else if(np>=HC)s+=50;
    if(np<=L-2){
      const a=(SK(k)+np)%L;
      if(SAFE.has(a))s+=30;
      else for(const o of ACT){if(o===k)continue;if(T[o].some(q=>q>=0&&q<=L-2&&(SK(o)+q)%L===a))s+=100;}
    }
    if(s>bs){bs=s;best=i;}
  });
  return best;
}
function botTick(){
  if(!vsCpu||net!=='local')return;
  const k=ACT[turn];if(k===undefined||k===0)return;
  clearTimeout(bt);
  bt=setTimeout(()=>{
    if(!vsCpu||k!==ACT[turn])return;
    if(busy){botTick();return;}
    if(rolled===null)roll();
    else{const mv=movable(k,rolled);if(mv.length)move(k,botPick(k,mv,rolled));}
  },rolled===null?900:700);
}
const ST={get(k,d){try{const v=localStorage.getItem('lf_'+k);return v===null?d:JSON.parse(v);}catch(e){return d;}},set(k,v){try{localStorage.setItem('lf_'+k,JSON.stringify(v));}catch(e){}}};
let coins=ST.get('coins',1000),gems=ST.get('gems',50),pname=ST.get('name','Player'),pav=ST.get('av','\u{1F9D1}');
let owned=ST.get('owned',['#fff']),diceC=ST.get('dice','#fff');
function refresh(){$('cn').textContent=coins;$('gm2').textContent=gems;$('av').textContent=pav;dice.style.background=diceC;ST.set('coins',coins);ST.set('gems',gems);}
const mk=(tag,txt,cls)=>{const e=document.createElement(tag);if(txt)e.textContent=txt;if(cls)e.className=cls;return e;};
function panel(title,fn){$('pt').classList.remove('set');$('pt').textContent=title;$('pb').innerHTML='';fn($('pb'));$('pnl').classList.add('show');}
$('px').onclick=()=>$('pnl').classList.remove('show');
function openLobby(){$('nm').value=pname;$('lc1').textContent=coins;$('lg1').textContent=gems;$('lob').classList.add('show');}
const QID='99999';
function quickPlay(){quick=true;qTry=0;roomMin=2;roomMax=8;roomVoice=true;autoCode=false;$('nm').value=pname;$('pw').value=QID;$('rc').value=QID;toast('Finding players...');createRoom();}
$('frd').onclick=openLobby;$('onl').onclick=quickPlay;
function gameMenu(title,opts){
  panel(title,b=>{
    b.appendChild(mk('div','Quick = first to get 2 tokens home. Team Up = 2 vs 2, partners sit opposite.','hint'));
    opts.forEach(([ic,label,t,q])=>{
      const x=mk('button',ic+' '+label,'sbtn big');
      x.onclick=()=>{
        teamMode=t;quickMode=q;vsCpu=false;document.body.classList.add('pnp');$('pnl').classList.remove('show');
        if(t){$('np').value=4;home.style.display='none';$('gm').style.display='flex';reset();toast((q?'Quick ':'Classic ')+'Team Up: '+NAME[0]+' + '+NAME[2]+' vs '+NAME[1]+' + '+NAME[3]);}
        else pick.classList.add('show');
      };
      b.appendChild(x);
    });
  });
}
$('pnp').onclick=()=>gameMenu('SELECT GAME',[['🎲','Classic',false,false],['⚡','Quick',false,true],['🤝','Classic Team Up',true,false]]);
$('tup').onclick=()=>gameMenu('TEAM UP',[['🤝','Classic Team Up',true,false],['⚡','Quick Team Up',true,true]]);
$('bcpu').onclick=()=>{document.body.classList.remove('pnp');teamMode=quickMode=false;vsCpu=true;$('np').value=4;home.style.display='none';$('gm').style.display='flex';reset();};
['onl','frd'].forEach(id=>$(id).addEventListener('click',()=>{document.body.classList.remove('pnp');teamMode=quickMode=false;}));

const DAYS=[100,150,200,250,300,400,500];
$('nEv').onclick=()=>panel('Daily reward',b=>{
  const today=new Date().toDateString(),y=new Date(Date.now()-864e5).toDateString();
  let st=ST.get('daily',{last:'',streak:0});
  let cur=(st.last===today||st.last===y)?st.streak:0;
  if(cur>=7&&st.last!==today)cur=0;
  const done=st.last===today;
  const g=mk('div',null,'dy');
  DAYS.forEach((v,i)=>{const d=mk('div','Day '+(i+1)+'\n'+v);if(i<cur)d.className='got';else if(i===cur&&!done)d.className='now';g.appendChild(d);});
  b.appendChild(g);
  const c=mk('button',done?'Come back tomorrow':'Claim '+DAYS[cur]+' coins');
  c.disabled=done;
  c.onclick=()=>{coins+=DAYS[cur];ST.set('daily',{last:today,streak:cur+1});refresh();toast('+'+DAYS[cur]+' coins');$('pnl').classList.remove('show');};
  b.appendChild(c);
});

const ITEMS=[['White','#fff',0],['Gold','#ffd54f',200],['Mint','#a5f3d0',100],['Pink','#ffc1e3',100],['Sky','#a8d8ff',100]];
$('nIn').onclick=()=>panel('Inventory: dice color',b=>{
  const draw=()=>{
    b.innerHTML='';b.appendChild(mk('div','Coins: '+coins));
    ITEMS.forEach(([n,c,pr])=>{
      const r=mk('div',null,'rw');const sw=mk('span','\u{1F3B2} '+n);sw.style.color=c;r.appendChild(sw);
      const have=owned.includes(c);
      const b2=mk('button',diceC===c?'In use':have?'Use':'Buy '+pr);
      b2.disabled=diceC===c||(!have&&coins<pr);
      b2.onclick=()=>{if(!have){coins-=pr;owned.push(c);ST.set('owned',owned);}diceC=c;ST.set('dice',c);refresh();draw();};
      r.appendChild(b2);b.appendChild(r);
    });
  };
  draw();
});

const AVS=['\u{1F9D1}','\u{1F466}','\u{1F467}','\u{1F468}','\u{1F469}','\u{1F9D4}','\u{1F60E}','\u{1F431}','\u{1F436}','\u{1F981}'];
$('nSo').onclick=()=>panel('Profile and invite',b=>{
  const inp=mk('input');inp.maxLength=12;inp.value=pname;inp.placeholder='Your name';b.appendChild(inp);
  const av=mk('div',null,'avs');let sel=pav;
  AVS.forEach(a=>{const s=mk('span',a,a===sel?'sel':'');s.onclick=()=>{sel=a;[...av.children].forEach(x=>{x.className=x.textContent===a?'sel':'';});};av.appendChild(s);});
  b.appendChild(av);
  const sv=mk('button','Save');
  sv.onclick=()=>{pname=(inp.value.trim()||'Player').slice(0,12);pav=sel;ST.set('name',pname);ST.set('av',pav);refresh();toast('Saved');};
  const sh=mk('button','Invite friends');
  sh.onclick=()=>{const d={title:'Ludo Family',text:'Play Ludo Family with me!',url:location.href};if(navigator.share)navigator.share(d).catch(()=>{});else toast('Send your friends the game link');};
  b.appendChild(sv);b.appendChild(sh);
  const lo=mk('button','Log out');lo.onclick=()=>{ST.set('auth',null);ST.set('logged',false);$('pnl').classList.remove('show');showLogin();};b.appendChild(lo);
});

$('nAd').onclick=()=>panel('Adda (voice room)',b=>{
  b.appendChild(mk('div','Talk with friends while you play. Create a room, share the number, start the game, then tap the mic button.'));
  const o=mk('button','Open room');o.onclick=()=>{$('pnl').classList.remove('show');openLobby();};b.appendChild(o);
});
refresh();
/* ===== Login: Google or Facebook is required ===== */
const REQUIRE_LOGIN=true;      // true = nobody can play without signing in. Set to false only to test the game (login screen is skipped).
const ALLOW_GUEST=true;      // true = show a Play as Guest button (players can skip Google/Facebook)
const GOOGLE_CLIENT_ID='';     // paste your Google Client ID between the quotes
const FACEBOOK_APP_ID='';      // paste your Facebook App ID between the quotes
const authed=()=>!REQUIRE_LOGIN||!!ST.get('auth',null);
function finishLogin(provider,name){
  if(!ST.get('bonus',false)){gems+=100;ST.set('bonus',true);}
  pname=(name||'Player').slice(0,12);
  ST.set('name',pname);ST.set('auth',provider);ST.set('logged',true);
  refresh();$('login').classList.remove('show');toast('Welcome '+pname+'!');
}
// Google
function onGoogle(r){
  try{
    const b=r.credential.split('.')[1].replace(/-/g,'+').replace(/_/g,'/');
    const d=JSON.parse(decodeURIComponent(escape(atob(b))));
    ST.set('email',d.email||'');
    finishLogin('google',d.given_name||d.name);
  }catch(e){$('lge').textContent='Google login failed. Try again.';}
}
function initGoogle(){
  if(!GOOGLE_CLIENT_ID)return;
  const go=()=>{
    google.accounts.id.initialize({client_id:GOOGLE_CLIENT_ID,callback:onGoogle});
    $('lgo').style.display='none';
    $('lgb').innerHTML='';
    google.accounts.id.renderButton($('lgb'),{theme:'filled_blue',size:'large',text:'continue_with',width:260});
  };
  if(window.google&&google.accounts){go();return;}
  const s=document.createElement('script');s.src='https://accounts.google.com/gsi/client';
  s.onload=go;s.onerror=()=>{$('lge').textContent='Cannot load Google. Check internet.';};
  document.head.appendChild(s);
}
$('lgo').onclick=()=>{$('lge').textContent=GOOGLE_CLIENT_ID?'Loading Google...':'Google login is not set up yet.';};
// Facebook
let fbReady=false;
function preloadFB(){
  if(!FACEBOOK_APP_ID||fbReady)return;
  const go=()=>{FB.init({appId:FACEBOOK_APP_ID,cookie:true,xfbml:false,version:'v19.0'});fbReady=true;};
  if(window.FB){go();return;}
  const s=document.createElement('script');s.src='https://connect.facebook.net/en_US/sdk.js';
  s.onload=go;s.onerror=()=>{$('lge').textContent='Cannot load Facebook. Check internet.';};
  document.head.appendChild(s);
}
$('lfb').onclick=()=>{
  if(!FACEBOOK_APP_ID){$('lge').textContent='Facebook login is not set up yet.';return;}
  if(!fbReady){$('lge').textContent='Facebook is loading. Tap again in a moment.';preloadFB();return;}
  FB.login(r=>{
    if(!r||!r.authResponse){$('lge').textContent='Facebook login was cancelled.';return;}
    FB.api('/me',{fields:'first_name,name'},u=>{
      if(!u||u.error){$('lge').textContent='Facebook login failed. Try again.';return;}
      ST.set('fbid',u.id||'');
      finishLogin('facebook',u.first_name||u.name);
    });
  },{scope:'public_profile'});
};
function showLogin(){
  $('lge').textContent=(REQUIRE_LOGIN&&!ALLOW_GUEST&&!GOOGLE_CLIENT_ID&&!FACEBOOK_APP_ID)?'Login is not set up yet. The game owner must add a Google or Facebook ID.':'';
  $('login').classList.add('show');initGoogle();preloadFB();
}
$('lgg').style.display=ALLOW_GUEST?'block':'none';
$('lor').style.display=ALLOW_GUEST?'block':'none';
$('lgg').onclick=()=>finishLogin('guest','Guest'+(100+Math.random()*900|0));
// No game can start unless signed in
['pnp','tup','bcpu','onl','frd'].forEach(id=>{
  const e=$(id),o=e.onclick;
  e.onclick=ev=>{if(!authed()){showLogin();return;}return o&&o.call(e,ev);};
});
if(!authed())showLogin();

/* ===== Settings ===== */
const SET={sound:ST.get('sound',true),vib:ST.get('vib',true)};
let actx=null;
function beep(f,d,type,v){
  if(!SET.sound)return;
  try{
    if(navigator.userActivation&&!navigator.userActivation.hasBeenActive)return;
    actx=actx||new (window.AudioContext||window.webkitAudioContext)();
    const o=actx.createOscillator(),g=actx.createGain();
    o.type=type||'sine';o.frequency.value=f;g.gain.value=v||.12;
    o.connect(g);g.connect(actx.destination);o.start();
    g.gain.exponentialRampToValueAtTime(.001,actx.currentTime+d);o.stop(actx.currentTime+d);
  }catch(e){}
}
function buzz(p){if(SET.vib&&navigator.vibrate){try{navigator.vibrate(p);}catch(e){}}}
const _face0=face;
face=function(n){_face0(n);beep(300+Math.random()*250,.04,'square',.05);};
let _pb,_ps,_won=false;
const _lay0=layout;
layout=function(){
  _lay0();
  try{
    const flat=ACT.flatMap(k=>T[k]);
    const base=flat.filter(p=>p===-1).length,sum=flat.reduce((a,b)=>a+b,0);
    if(_pb!==undefined){
      if(base>_pb&&base-_pb<=4&&sum<_ps){beep(160,.3,'sawtooth',.15);buzz(150);}
      else if(sum>_ps)beep(520,.06,'square',.07);
    }
    _pb=base;_ps=sum;
    const win=ACT.some(k=>T[k].every(q=>q===GOAL));
    if(win&&!_won){_won=true;addHist();[523,659,784,1047].forEach((f,i)=>setTimeout(()=>beep(f,.25,'triangle',.12),i*160));buzz([200,100,200]);}
    if(!win)_won=false;
  }catch(e){}
};
function shareGame(){
  const d={title:'Ludo Family',text:'Play Ludo Family with me!',url:location.href};
  if(navigator.share)navigator.share(d).catch(()=>{});
  else{try{navigator.clipboard.writeText(location.href);toast('Link copied');}catch(e){toast(location.href);}}
}
function textPanel(title,lines){
  panel(title,b=>{
    const t=mk('div','','rtx');lines.forEach(l=>t.appendChild(mk('div',l)));b.appendChild(t);
    const bk=mk('button','Back');bk.onclick=openSettings;b.appendChild(bk);
  });
}
const HOWTO=[
  '1. Tap the dice on your turn.',
  '2. Roll a 6 to bring a token out of your base.',
  '3. Tap a glowing token to move it clockwise.',
  '4. Land on another player\u2019s token to send it back to base (not on a \u2605 safe square).',
  '5. A 6, a capture, or reaching the center gives you another turn.',
  '6. You need the exact number to reach the center.',
  '7. Bring all 4 tokens to the center to win.'
];
const RULES=[
  'Boards: 2 to 4 players = square, 5 players = star, 6 players = hexagon, 7 to 8 players = octagon.',
  'Safe squares (\u2605): your start square and the squares marked with a star cannot be captured on.',
  'If you cannot move, your turn passes.',
  'In online rooms the host runs the game. If the host leaves, the room closes.'
];
const PRIVACY=[
  'Your name, coins, gems and settings are saved only on this phone.',
  'Google or Facebook login is used only to read your name. Nothing is posted.',
  'Online and Friends rooms connect phones directly through a free public room server. Chat and moves are shared only with players in your room.',
  'Voice is sent only to players in your room, and only while your mic is on.'
];
function openSettings(){
  panel('Settings',b=>{
    $('pt').classList.add('set');
    const row=(label,...els)=>{const r=mk('div','','srow');r.appendChild(mk('span',label));els.forEach(e=>r.appendChild(e));b.appendChild(r);};
    const tog=(key,on,off)=>{
      const x=mk('button',SET[key]?on:off,'sbtn'+(SET[key]?'':' off'));
      x.onclick=()=>{SET[key]=!SET[key];ST.set(key,SET[key]);x.textContent=SET[key]?on:off;x.classList.toggle('off',!SET[key]);if(key==='sound')beep(660,.1,'triangle',.12);if(key==='vib')buzz(80);};
      return x;
    };
    row('Audio',tog('sound','\uD83D\uDD0A','\uD83D\uDD07'));
    row('Vibration',tog('vib','\uD83D\uDCF3','\u274C'));
    const tu=mk('button','Play','sbtn');tu.onclick=()=>textPanel('How to play',HOWTO);row('Tutorial',tu);
    const ru=mk('button','View','sbtn');ru.onclick=()=>textPanel('Rules',RULES);row('Rules',ru);
    const st=mk('button','View','sbtn');st.onclick=()=>$('nIn').click();row('Store',st);
    const pv=mk('button','View','sbtn');pv.onclick=()=>textPanel('Privacy info',PRIVACY);row('Privacy info',pv);
    const inv=mk('button','\u2795 Invite friends','sbtn big');inv.onclick=shareGame;b.appendChild(inv);
  });
  $('pnl').dataset.set='1';
}
$('px').addEventListener('click',()=>$('pt').classList.remove('set'));
$('gear').onclick=openSettings;

/* ===== Room screen buttons ===== */
function roomText(){return 'Join my Ludo Family game! Room code: '+curCode+'\nOpen: '+location.href;}
$('rsh').onclick=()=>{
  const d={title:'Ludo Family',text:roomText()};
  if(navigator.share)navigator.share(d).catch(()=>{});
  else{try{navigator.clipboard.writeText(roomText());toast('Room code copied');}catch(e){toast('Room code: '+curCode);}}
};
$('rwa').onclick=()=>window.open('https://wa.me/?text='+encodeURIComponent(roomText()),'_blank');
$('rsn').onclick=()=>{SET.sound=!SET.sound;ST.set('sound',SET.sound);$('rsn').textContent=SET.sound?'\uD83D\uDD0A':'\uD83D\uDD07';};
$('rin').onclick=()=>toast('Share the code. Friends tap FRIENDS, type it, and tap Join. The host taps Start game.');

/* ===== Select players, Create / Join, history ===== */
const RT={4:{min:2,max:4,label:'2P/3P/4P'},5:{min:5,max:5,label:'5P'},6:{min:6,max:6,label:'6P'},8:{min:7,max:8,label:'7P/8P'}};
let pickT=4,pickVoice=true;
function genCode(){return String(100000+Math.random()*900000|0);}
function typeSvg(a){
  const r=27,P=n=>{const t=(-90+180/a+360/a*n)*Math.PI/180;return [r*Math.cos(t),r*Math.sin(t)];};
  let s='<svg viewBox="-30 -30 60 60" width="54" height="54">';
  for(let k=0;k<a;k++){const p=P(k),q=P(k+1);s+=`<polygon points="0,0 ${p[0].toFixed(1)},${p[1].toFixed(1)} ${q[0].toFixed(1)},${q[1].toFixed(1)}" fill="${PAL[a][k][0]}" stroke="#fff" stroke-width="1"/>`;}
  return s+'</svg>';
}
function drawTypes(){
  const box=$('ptypes');box.innerHTML='';
  [4,5,6,8].forEach(a=>{
    const d=mk('div','','pt'+(a===pickT?' on':''));
    d.appendChild(mk('b',RT[a].label));
    const sv=mk('div');sv.innerHTML=typeSvg(a);d.appendChild(sv);
    d.appendChild(mk('div',a===pickT?'\u2714':'','ck'));
    d.onclick=()=>{pickT=a;drawTypes();};
    box.appendChild(d);
  });
}
drawTypes();
$('tabC').onclick=()=>{$('tabC').classList.add('on');$('tabJ').classList.remove('on');$('paneC').style.display='';$('paneJ').style.display='none';};
$('tabJ').onclick=()=>{$('tabJ').classList.add('on');$('tabC').classList.remove('on');$('paneJ').style.display='';$('paneC').style.display='none';};
$('vcb').onclick=()=>{pickVoice=!pickVoice;$('vcb').classList.toggle('on',pickVoice);};
$('nx').onclick=()=>{
  const t=RT[pickT];roomMin=t.min;roomMax=t.max;roomVoice=pickVoice;
  quick=false;autoCode=true;qTry=0;$('pw').value=genCode();createRoom();
};
$('how').onclick=()=>panel('How to play',b=>{const t=mk('div','','rtx');HOWTO.forEach(l=>t.appendChild(mk('div',l)));b.appendChild(t);});
const HIST=ST.get('hist',[]);
function addHist(){
  try{
    const w=ACT.find(k=>T[k].every(q=>q===GOAL));if(w===undefined)return;
    HIST.unshift({d:Date.now(),n:ACT.length,w:NAME[w],m:net==='local'?'Offline':'Online'});
    HIST.length=Math.min(HIST.length,20);ST.set('hist',HIST);
  }catch(e){}
}
$('gh').onclick=()=>panel('Game history',b=>{
  if(!HIST.length){b.appendChild(mk('div','No games finished yet.'));return;}
  const t=mk('div','','rtx');
  HIST.forEach(g=>t.appendChild(mk('div',new Date(g.d).toLocaleDateString()+' \u00B7 '+g.n+' players \u00B7 '+g.m+' \u00B7 Winner: '+g.w)));
  b.appendChild(t);
});
const hbOld=$('hb').onclick;
SET.music=ST.get('music',true);
let mus=0,mi=0;
function mnote(f,d,t,v){const o=actx.createOscillator(),g=actx.createGain();o.type=t;o.frequency.value=f;g.gain.value=v;o.connect(g);g.connect(actx.destination);o.start();g.gain.exponentialRampToValueAtTime(.001,actx.currentTime+d);o.stop(actx.currentTime+d);}
const MN=[262,330,392,330,294,349,440,349,262,330,392,523,494,392,349,330];
function musicTick(){
  clearTimeout(mus);mus=0;
  if(!SET.music||$('gm').style.display!=='flex')return;
  try{
    if(navigator.userActivation&&!navigator.userActivation.hasBeenActive){mus=setTimeout(musicTick,1000);return;}
    actx=actx||new (window.AudioContext||window.webkitAudioContext)();
    const n=mi++;
    mnote(MN[n%16],.3,'sine',.05);mnote(MN[n%16]*2,.18,'triangle',.015);
    if(n%4===0)mnote([131,110,87,98][(n>>2)%4],1.2,'triangle',.07);
    if(n%2===1)mnote(1568,.05,'square',.012);
  }catch(e){}
  mus=setTimeout(musicTick,340);
}
const musicOn=()=>{clearTimeout(mus);mus=0;musicTick();};
setInterval(()=>{if(!mus)musicTick();},1500);
$('mn').onclick=()=>panel('Menu',b=>{
  $('pt').classList.add('set');
  const row=(label,el)=>{const r=mk('div','','srow');r.appendChild(mk('span',label));r.appendChild(el);b.appendChild(r);};
  const tog=(key,on,off,cb)=>{const x=mk('button',SET[key]?on:off,'sbtn'+(SET[key]?'':' off'));x.onclick=()=>{SET[key]=!SET[key];ST.set(key,SET[key]);x.textContent=SET[key]?on:off;x.classList.toggle('off',!SET[key]);if(cb)cb();};return x;};
  row('Sound',tog('sound','🔊 On','🔇 Off',()=>beep(660,.1,'triangle',.12)));
  row('Music',tog('music','🎵 On','🎵 Off',musicOn));
  row('Tokens',(()=>{const x=mk('button',TKS[tki][1],'sbtn');x.onclick=()=>{cycleTk();x.textContent=TKS[tki][1];};return x;})());
  const ex=mk('button','✕ Exit game','sbtn big');
  ex.onclick=()=>{$('pnl').classList.remove('show');$('pt').classList.remove('set');$('hb').click();};
  b.appendChild(ex);
});
$('hb').onclick=()=>{
  $('xt').textContent=net==='local'?'Your current game will be lost.':'You will leave this online game.';
  $('xq').classList.add('show');
};
$('xn').onclick=()=>$('xq').classList.remove('show');
$('xy').onclick=()=>{$('xq').classList.remove('show');hbOld();};
const TKS=[['bead','⚪ Bead'],['pin','📍 Pin'],['star','⭐ Star'],['diamond','💎 Diamond'],['crown','👑 Crown']];
let tki=Math.max(0,TKS.findIndex(t=>t[0]===ST.get('tk','pin')));
const applyTk=()=>{board.dataset.tk=TKS[tki][0];};applyTk();
function cycleTk(){tki=(tki+1)%TKS.length;ST.set('tk',TKS[tki][0]);applyTk();toast('Tokens: '+TKS[tki][1]);beep(700,.08,'triangle',.1);}
$('tkb').onclick=cycleTk;
(function(){
  const cv=$('gb');if(!cv)return;
  const c=cv.getContext('2d'),CX=150,CY=128,R=76,S=2*R+2,TW=256,TH=128;
  const og=document.createElement('canvas');og.width=og.height=S;const oc=og.getContext('2d'),img=oc.createImageData(S,S),D=img.data;
  const rnd=(x,y,s)=>{const n=Math.sin(x*127.1+y*311.7+s*74.7)*43758.5453;return n-Math.floor(n);};
  const vn=(u,v,f,s)=>{const x=u*f,y=v*f,xi=Math.floor(x),yi=Math.floor(y),xf=x-xi,yf=y-yi,fx=xf*xf*(3-2*xf),fy=yf*yf*(3-2*yf);
    const a=rnd(xi%f,yi,s),b=rnd((xi+1)%f,yi,s),e=rnd(xi%f,yi+1,s),d=rnd((xi+1)%f,yi+1,s);return a+(b-a)*fx+(e-a)*fy+(a-b-e+d)*fx*fy;};
  const fb=(u,v,s,o0)=>{let h=0,a=.5,t=0;for(let o=0;o<4;o++){h+=a*vn(u,v,o0<<o,s+o);t+=a;a/=2;}return h/t;};
  const hm=new Float32Array(TW*TH),cl=new Float32Array(TW*TH);
  for(let j=0;j<TH;j++)for(let i=0;i<TW;i++){hm[j*TW+i]=fb(i/TW,j/TH,1,4);cl[j*TW+i]=fb(i/TW,j/TH,9,6);}
  const N=S*S,LON=new Float32Array(N),ROW=new Int16Array(N),DF=new Float32Array(N),RM=new Float32Array(N),OK=new Uint8Array(N),IC=new Uint8Array(N);
  const tl=.45,ct=Math.cos(tl),st=Math.sin(tl),Lx=-.5,Ly=.45,Lz=.74,Ll=Math.hypot(Lx,Ly,Lz);
  for(let py=0;py<S;py++)for(let px=0;px<S;px++){
    const nx=(px-S/2)/R,ny=(py-S/2)/R,r2=nx*nx+ny*ny,k=py*S+px;
    if(r2>1){const g=Math.max(0,1-(Math.sqrt(r2)-1)*14);RM[k]=g*.55;OK[k]=g>0?2:0;continue;}
    OK[k]=1;const z=Math.sqrt(1-r2),y=-ny,y2=y*ct-z*st,z2=y*st+z*ct;
    const lat=Math.asin(Math.max(-1,Math.min(1,y2)));LON[k]=Math.atan2(nx,z2);ROW[k]=Math.max(0,Math.min(TH-1,Math.floor((.5-lat/Math.PI)*TH)));
    IC[k]=Math.abs(lat)>1.18?1:0;DF[k]=Math.max(0,(nx*Lx-ny*Ly+z*Lz)/Ll);RM[k]=Math.pow(1-z,3);
  }
  const items=[['#1e88e5',0],['#e53935',1.2566],['#43a047',2.5133],['#fdd835',3.77],['🎲',5.0265]];
  const phi=-.12,OA=118,OB=34;
  const pos=a=>[CX+OA*Math.cos(a)*Math.cos(phi)-OB*Math.sin(a)*Math.sin(phi),CY+OA*Math.cos(a)*Math.sin(phi)+OB*Math.sin(a)*Math.cos(phi),Math.sin(a)];
  function item(it,a){
    const [x,y,d]=pos(a),s=11+5*d;
    c.save();c.globalAlpha=d<0?.8:1;
    if(it[0].length>2||it[0][0]!=='#'){c.font=Math.round(s*2.2)+'px serif';c.textAlign='center';c.textBaseline='middle';c.fillText(it[0],x,y);}
    else{c.fillStyle='#0005';c.beginPath();c.ellipse(x,y+s*.9,s*.9,s*.35,0,0,7);c.fill();
      const g=c.createRadialGradient(x-s*.3,y-s*.35,s*.1,x,y,s);g.addColorStop(0,'#fff');g.addColorStop(.35,it[0]);g.addColorStop(1,'#0008');
      c.fillStyle=g;c.beginPath();c.arc(x,y,s,0,7);c.fill();c.lineWidth=2;c.strokeStyle='#fff';c.stroke();}
    c.restore();
  }
  let last=0;
  function frame(t){
    requestAnimationFrame(frame);
    if(t-last<33||document.hidden)return;last=t;
    const h=$('home');if(!h||h.offsetParent===null)return;
    const rot=t/1000*.35,u0=rot/(2*Math.PI);
    for(let k=0;k<N;k++){
      const o=OK[k]*0,p=k*4;
      if(OK[k]===0){D[p+3]=0;continue;}
      if(OK[k]===2){D[p]=90;D[p+1]=170;D[p+2]=255;D[p+3]=RM[k]*255;continue;}
      let u=(LON[k]/(2*Math.PI)+u0);u-=Math.floor(u);
      const ti=ROW[k]*TW+((u*TW)|0),hv=hm[ti];
      let r,g,b;
      if(IC[k]){r=235;g=245;b=255;}
      else if(hv>.5){const e=Math.min(1,(hv-.5)*5);r=60+90*e;g=150-20*e;b=60+30*e;}
      else{const e=Math.min(1,(.5-hv)*4);r=25-15*e;g=100-45*e;b=210-60*e;}
      let u2=u-u0*.4;u2-=Math.floor(u2);const cv2=cl[ROW[k]*TW+((u2*TW)|0)];
      if(cv2>.56){const w=Math.min(1,(cv2-.56)*6)*.75;r+=(255-r)*w;g+=(255-g)*w;b+=(255-b)*w;}
      const df=.2+.85*DF[k],rm=RM[k];
      D[p]=Math.min(255,r*df+60*rm);D[p+1]=Math.min(255,g*df+120*rm);D[p+2]=Math.min(255,b*df+255*rm*.8);D[p+3]=255;
    }
    oc.putImageData(img,0,0);
    c.clearRect(0,0,300,260);
    c.strokeStyle='rgba(255,255,255,.28)';c.lineWidth=2;c.beginPath();c.ellipse(CX,CY,OA,OB,phi,0,7);c.stroke();
    const T=t/1000*.9;
    items.forEach(it=>{const a=T+it[1];if(Math.sin(a)<0)item(it,a);});
    c.drawImage(og,CX-S/2,CY-S/2);
    items.forEach(it=>{const a=T+it[1];if(Math.sin(a)>=0)item(it,a);});
  }
  requestAnimationFrame(frame);
})();
(function(){
  const w=$('dw');if(!w)return;
  const P=[[4],[0,8],[0,4,8],[0,2,6,8],[0,2,4,6,8],[0,2,3,5,6,8]];
  const TF=['rotateY(0)','rotateY(90deg)','rotateX(90deg)','rotateX(-90deg)','rotateY(-90deg)','rotateY(180deg)'];
  [['0','20px',null,46,'#e53935','0s','6s'],[null,'90px','0',54,'#1e88e5','-2s','8s'],['14px','150px',null,38,'#43a047','-1s','7s'],[null,'172px','16px',42,'#f9a825','-3s','9s']].forEach(([l,t,r,s,col,dl,du],n)=>{
    const cw=mk('div','','cw');cw.style.top=t;if(l!==null)cw.style.left=l;if(r!==null)cw.style.right=r;
    cw.style.width=cw.style.height=s+'px';cw.style.animationDelay=dl;
    const cb=mk('div','','cube');cb.style.cssText='width:'+s+'px;height:'+s+'px;--c:'+col+';animation-duration:'+du+';animation-delay:'+dl;
    P.forEach((pp,fi)=>{
      const f=mk('div','','f');f.style.transform=TF[fi]+' translateZ('+s/2+'px)';
      for(let g=0;g<9;g++){const i=document.createElement('i');if(!pp.includes(g))i.style.visibility='hidden';f.appendChild(i);}
      cb.appendChild(f);
    });
    cw.appendChild(cb);w.appendChild(cw);
  });
})();
(function(){
  const w=$('dw');if(!w)return;
  let s='<svg viewBox="0 0 150 150" xmlns="http://www.w3.org/2000/svg"><rect width="150" height="150" fill="#fff"/>';
  const Q=[[0,0,'#e53935'],[90,0,'#43a047'],[0,90,'#1e88e5'],[90,90,'#fdd835']];
  Q.forEach(([x,y,c])=>{s+='<rect x="'+x+'" y="'+y+'" width="60" height="60" fill="'+c+'"/><rect x="'+(x+10)+'" y="'+(y+10)+'" width="40" height="40" rx="3" fill="#fff"/>';
    [[20,20],[40,20],[20,40],[40,40]].forEach(([a,b])=>{s+='<circle cx="'+(x+a)+'" cy="'+(y+b)+'" r="5" fill="'+c+'"/>';});});
  for(let i=0;i<=15;i++){s+='<path d="M'+i*10+' 0V150M0 '+i*10+'H150" stroke="#bbb" stroke-width=".6"/>';}
  s+='<rect x="70" y="10" width="10" height="50" fill="#43a047"/><rect x="10" y="70" width="50" height="10" fill="#e53935"/><rect x="90" y="70" width="50" height="10" fill="#fdd835"/><rect x="70" y="90" width="10" height="50" fill="#1e88e5"/>';
  s+='<polygon points="60,60 90,60 75,75" fill="#43a047"/><polygon points="60,60 60,90 75,75" fill="#e53935"/><polygon points="90,60 90,90 75,75" fill="#fdd835"/><polygon points="60,90 90,90 75,75" fill="#1e88e5"/></svg>';
  const b=mk('div','','bd3');b.innerHTML=s;w.insertBefore(b,w.firstChild);
})();
document.addEventListener('click',function fsOnce(){
  try{const e=document.documentElement;(e.requestFullscreen||e.webkitRequestFullscreen).call(e).catch(()=>{});}catch(x){}
  document.removeEventListener('click',fsOnce);
});
