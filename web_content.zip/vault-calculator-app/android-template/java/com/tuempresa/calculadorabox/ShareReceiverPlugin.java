package com.tuempresa.calculadorabox;

import android.content.Intent;
import android.net.Uri;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;

/**
 * Plugin de Capacitor que implementa el lado nativo de "recibir mediante
 * Compartir" (Android Share Sheet): ACTION_SEND y ACTION_SEND_MULTIPLE.
 *
 * Flujo real (no simulado):
 *  1. Otra app (WhatsApp, Galería, Telegram...) llama a ACTION_SEND con un
 *     content:// Uri del archivo, y el sistema muestra nuestra app como
 *     destino (gracias a los intent-filter del AndroidManifest.xml).
 *  2. Aquí leemos el/los Uri reales con ContentResolver y copiamos los
 *     bytes al caché privado de la app (no son archivos ficticios).
 *  3. Se notifica a JavaScript (evento "shareReceived") con las rutas
 *     locales resultantes, para mostrar la vista previa "Guardar en Bóveda".
 */
@CapacitorPlugin(name = "ShareReceiver")
public class ShareReceiverPlugin extends Plugin {

    @Override
    public void load() {
        // procesa el intent que abrió la app en frío (cold start desde "Compartir")
        handleIntent(getActivity().getIntent());
    }

    public void handleIntent(Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        String type = intent.getType();
        if (type == null) return;
        if (!(Intent.ACTION_SEND.equals(action) || Intent.ACTION_SEND_MULTIPLE.equals(action))) return;

        ArrayList<Uri> uris = new ArrayList<>();
        if (Intent.ACTION_SEND.equals(action)) {
            Uri uri = intent.getParcelableExtra(Intent.EXTRA_STREAM);
            if (uri != null) uris.add(uri);
        } else {
            ArrayList<Uri> list = intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
            if (list != null) uris.addAll(list);
        }
        if (uris.isEmpty()) return;

        JSArray items = new JSArray();
        for (Uri uri : uris) {
            String localPath = copyToCache(uri);
            if (localPath == null) continue;
            JSObject item = new JSObject();
            item.put("path", localPath);
            item.put("mimeType", getContext().getContentResolver().getType(uri));
            items.put(item);
        }
        if (items.length() == 0) return;

        JSObject data = new JSObject();
        data.put("items", items);
        notifyListeners("shareReceived", data);

        // evita volver a procesar el mismo intent si la actividad se recrea
        intent.setAction(null);
    }

    private String copyToCache(Uri uri) {
        try (InputStream in = getContext().getContentResolver().openInputStream(uri)) {
            if (in == null) return null;
            String name = "shared_" + System.currentTimeMillis();
            File out = new File(getContext().getCacheDir(), name);
            try (FileOutputStream fos = new FileOutputStream(out)) {
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) fos.write(buf, 0, n);
            }
            return out.getAbsolutePath();
        } catch (Exception e) {
            return null;
        }
    }

    /** Permite a JS volver a preguntar si hay un share pendiente tras cargar la app. */
    @PluginMethod
    public void checkPending(PluginCall call) {
        handleIntent(getActivity().getIntent());
        call.resolve();
    }
}
