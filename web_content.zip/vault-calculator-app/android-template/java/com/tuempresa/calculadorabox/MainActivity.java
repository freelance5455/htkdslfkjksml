package com.tuempresa.calculadorabox;

import android.content.Intent;
import android.os.Bundle;
import com.getcapacitor.BridgeActivity;
import com.getcapacitor.PluginHandle;

/**
 * Actividad principal de la app.
 * - Registra el plugin nativo ShareReceiver (recibe fotos/videos/archivos
 *   compartidos desde WhatsApp, Galería, Google Fotos, etc.).
 * - launchMode="singleTask" (ver AndroidManifest.xml) hace que si la app ya
 *   está abierta y el usuario comparte otro archivo, NO se cree una nueva
 *   instancia: en su lugar llega aquí a onNewIntent().
 */
public class MainActivity extends BridgeActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(ShareReceiverPlugin.class);
        super.onCreate(savedInstanceState);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);

        PluginHandle handle = getBridge().getPlugin("ShareReceiver");
        if (handle != null && handle.getInstance() instanceof ShareReceiverPlugin) {
            ((ShareReceiverPlugin) handle.getInstance()).handleIntent(intent);
        }
    }
}
