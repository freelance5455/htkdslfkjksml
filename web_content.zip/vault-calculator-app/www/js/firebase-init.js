/**
 * Configuración de Firebase.
 *
 * 1. Crea un proyecto en https://console.firebase.google.com
 * 2. Activa Authentication -> método "Google".
 * 3. Activa Firestore Database y Storage.
 * 4. Registra una app Android con el mismo applicationId que capacitor.config.json
 *    (com.tuempresa.calculadorabox) y descarga google-services.json
 *    -> colócalo en android/app/google-services.json (ver README.md).
 * 5. Registra también una app "Web" dentro del mismo proyecto Firebase y
 *    pega aquí abajo su configuración (Project settings -> General -> Your apps -> Web).
 *
 * Esta config "web" es la que usan los SDK de Firestore/Storage que corren
 * dentro del WebView. El login de Google en sí lo maneja el plugin nativo
 * @capacitor-community/firebase-authentication (usa google-services.json).
 */
const firebaseConfig = {
  apiKey: "TU_API_KEY",
  authDomain: "tu-proyecto.firebaseapp.com",
  projectId: "tu-proyecto",
  storageBucket: "tu-proyecto.appspot.com",
  messagingSenderId: "TU_SENDER_ID",
  appId: "TU_APP_ID_WEB"
};

// Se cargan como scripts "compat" en index.html (ver más abajo, sección README).
firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();
const storage = firebase.storage();
