/* =========================================================
   Utilidades de Capacitor (disponibles solo dentro del APK;
   en un navegador normal simplemente no se usan)
   ========================================================= */
const Cap = window.Capacitor;
const hasCapacitor = !!(Cap && Cap.isNativePlatform && Cap.isNativePlatform());
const Preferences = hasCapacitor ? Cap.Plugins.Preferences : null;
const FirebaseAuthentication = hasCapacitor ? Cap.Plugins.FirebaseAuthentication : null;
const ShareReceiver = hasCapacitor ? Cap.Plugins.ShareReceiver : null;

function fileSrc(path){
  return hasCapacitor ? Cap.convertFileSrc(path) : path;
}

/* =========================================================
   CALCULADORA
   ========================================================= */
const display = document.getElementById('display');
const historyEl = document.getElementById('display-history');

let current = '0', previous = null, operator = null, overwrite = true, isError = false;
let secretBuffer = [];
const MAX_DIGITS = 15;

function render(){
  display.textContent = current;
  display.classList.toggle('err', isError);
  display.style.fontSize = current.length > 12 ? '38px' : current.length > 9 ? '52px' : '72px';
  historyEl.textContent = (previous !== null && operator) ? `${formatNum(previous)} ${operator}` : '';
  document.querySelectorAll('.key.op').forEach(k=>{
    k.classList.toggle('active', operator === k.dataset.op && overwrite);
  });
}
function formatNum(n){
  if(!isFinite(n)) return 'Error';
  let s = parseFloat(n.toPrecision(12)).toString();
  if(s.length > MAX_DIGITS) s = n.toExponential(6);
  return s;
}
function resetAll(){ current='0'; previous=null; operator=null; overwrite=true; isError=false; secretBuffer=[]; render(); }
function inputDigit(d){
  if(isError) resetAll();
  secretBuffer.push(d);
  if(overwrite){ current = (d==='0') ? '0' : d; overwrite=false; }
  else { if(current.replace('-','').replace('.','').length>=MAX_DIGITS) return; current = current==='0'?d:current+d; }
  render();
}
function inputDecimal(){
  if(isError) resetAll();
  secretBuffer.push('dec');
  if(overwrite){ current='0.'; overwrite=false; render(); return; }
  if(!current.includes('.')) current+='.';
  render();
}
function toggleSign(){
  if(isError) return;
  secretBuffer.push('sign');
  if(current==='0') return;
  current = current.startsWith('-') ? current.slice(1) : '-'+current;
  render();
}
function inputPercent(){
  if(isError) return;
  secretBuffer.push('pct');
  const val = parseFloat(current);
  const result = (previous!==null && operator) ? previous*(val/100) : val/100;
  current = formatNum(result); overwrite=true; render();
}
function compute(a,op,b){
  switch(op){
    case '+': return a+b;
    case '−': return a-b;
    case '×': return a*b;
    case '÷': return b===0 ? null : a/b;
  }
  return b;
}
function chooseOperator(op){
  if(isError) resetAll();
  secretBuffer.push('op');
  const val = parseFloat(current);
  if(operator && !overwrite){
    const result = compute(previous, operator, val);
    if(result===null){ showError(); return; }
    previous = result; current = formatNum(result);
  } else { previous = val; }
  operator = op; overwrite = true; render();
}
function showError(){
  isError = true; current = 'Error: no se puede dividir entre 0';
  previous=null; operator=null; overwrite=true; render();
}
function equals(){
  if(secretBuffer.length===4 && secretBuffer.every(v=>v==='0')){
    secretBuffer=[]; openPin(); resetAll(); return;
  }
  secretBuffer=[];
  if(isError){ resetAll(); return; }
  if(operator===null){ overwrite=true; render(); return; }
  const a = previous!==null ? previous : parseFloat(current);
  const b = parseFloat(current);
  const result = compute(a, operator, b);
  if(result===null){ showError(); return; }
  current = formatNum(result); previous=null; operator=null; overwrite=true; render();
}
document.getElementById('keypad').addEventListener('click', (e)=>{
  const btn = e.target.closest('.key'); if(!btn) return;
  const a = btn.dataset.action;
  if(a==='digit') inputDigit(btn.dataset.val);
  else if(a==='decimal') inputDecimal();
  else if(a==='sign') toggleSign();
  else if(a==='percent') inputPercent();
  else if(a==='op') chooseOperator(btn.dataset.op);
  else if(a==='equals') equals();
  else if(a==='clear'){ if(current!=='0'||previous!==null||operator!==null||isError) resetAll(); else secretBuffer=[]; }
});
render();

/* =========================================================
   PIN (hash persistente por usuario, vía Capacitor Preferences)
   ========================================================= */
const pinOverlay=document.getElementById('pin-overlay'), pinInputBox=document.getElementById('pin-input-box');
const pinTitle=document.getElementById('pin-title'), pinSub=document.getElementById('pin-sub'), pinError=document.getElementById('pin-error');
let pinEntry='', pinMode='enter', pendingNewPin='';

async function hashPin(pin){
  const enc = new TextEncoder().encode('vault-salt::'+pin);
  const buf = await crypto.subtle.digest('SHA-256', enc);
  return Array.from(new Uint8Array(buf)).map(b=>b.toString(16).padStart(2,'0')).join('');
}
async function prefKey(){
  // el PIN se guarda por usuario autenticado (cada cuenta tiene su propio PIN)
  const uid = currentUser ? currentUser.uid : 'local';
  return 'pin_hash_'+uid;
}
async function getStoredPinHash(){
  if(!hasCapacitor) return window.__pinHash || null;
  const { value } = await Preferences.get({ key: await prefKey() });
  return value || null;
}
async function setStoredPinHash(hash){
  if(!hasCapacitor){ window.__pinHash = hash; return; }
  await Preferences.set({ key: await prefKey(), value: hash });
}

async function openPin(){
  pinEntry=''; pinError.textContent='';
  const stored = await getStoredPinHash();
  if(stored===null){
    pinMode='create'; pinTitle.textContent='Crea tu PIN'; pinSub.textContent='Elige un PIN de 4 dígitos';
  } else {
    pinMode='enter'; pinTitle.textContent='PIN de acceso'; pinSub.textContent='Introduce tu PIN';
  }
  updatePinBox(); pinOverlay.classList.add('show');
}
function updatePinBox(){ pinInputBox.textContent = '• • • •'.split(' ').map((d,i)=> i<pinEntry.length?'●':'•').join(' '); }

document.getElementById('pin-keypad').addEventListener('click', async (e)=>{
  const btn = e.target.closest('button'); if(!btn) return;
  if(btn.id==='pin-del'){ pinEntry=pinEntry.slice(0,-1); updatePinBox(); return; }
  if(btn.id==='pin-ok'){ submitPin(); return; }
  if(btn.dataset.d!==undefined && pinEntry.length<4){
    pinEntry+=btn.dataset.d; updatePinBox();
    if(pinEntry.length===4) await submitPin();
  }
});
document.getElementById('pin-close').addEventListener('click', ()=>{ pinOverlay.classList.remove('show'); pinEntry=''; });

async function submitPin(){
  if(pinEntry.length!==4){ pinError.textContent='El PIN debe tener 4 dígitos.'; return; }
  if(pinMode==='create'){
    pendingNewPin=pinEntry; pinEntry=''; pinMode='confirm';
    pinTitle.textContent='Confirma tu PIN'; pinSub.textContent='Vuelve a escribirlo'; pinError.textContent='';
    updatePinBox(); return;
  }
  if(pinMode==='confirm'){
    if(pinEntry!==pendingNewPin){
      pinError.textContent='Los PIN no coinciden. Intenta de nuevo.';
      pinEntry=''; pendingNewPin=''; pinMode='create';
      pinTitle.textContent='Crea tu PIN'; pinSub.textContent='Elige un PIN de 4 dígitos';
      updatePinBox(); return;
    }
    await setStoredPinHash(await hashPin(pinEntry));
    pinOverlay.classList.remove('show');
    proceedToVault();
    return;
  }
  const stored = await getStoredPinHash();
  if(await hashPin(pinEntry) === stored){
    pinOverlay.classList.remove('show');
    proceedToVault();
  } else {
    pinError.textContent='PIN incorrecto.'; pinEntry=''; updatePinBox();
  }
}

/* =========================================================
   LOGIN CON GOOGLE (obligatorio solo para entrar a la bóveda)
   ========================================================= */
const loginOverlay = document.getElementById('login-overlay');
let currentUser = null;

async function proceedToVault(){
  if(!hasCapacitor){
    // en navegador de escritorio (modo demo) saltamos el login nativo
    openVault(); return;
  }
  if(currentUser){ openVault(); return; }
  loginOverlay.classList.add('show');
}
document.getElementById('google-signin-btn').addEventListener('click', async ()=>{
  try{
    const result = await FirebaseAuthentication.signInWithGoogle();
    currentUser = result.user;
    loginOverlay.classList.remove('show');
    openVault();
  }catch(err){
    showToast('No se pudo iniciar sesión. Intenta de nuevo.');
  }
});
document.getElementById('login-cancel').addEventListener('click', ()=> loginOverlay.classList.remove('show'));

if(hasCapacitor && FirebaseAuthentication){
  FirebaseAuthentication.getCurrentUser().then(r=>{ if(r && r.user) currentUser = r.user; }).catch(()=>{});
}

document.getElementById('vault-signout').addEventListener('click', async ()=>{
  if(hasCapacitor && FirebaseAuthentication) await FirebaseAuthentication.signOut().catch(()=>{});
  currentUser = null;
  closeVault();
  showToast('Sesión cerrada.');
});

/* =========================================================
   BOVEDA (Firestore + Firebase Storage, aislado por uid)
   ========================================================= */
const vaultScreen=document.getElementById('vault-screen');
const vaultHiddenState=document.getElementById('vault-hidden-state');
const vaultShownState=document.getElementById('vault-shown-state');
const vaultGrid=document.getElementById('vault-grid');
const vaultGridEmpty=document.getElementById('vault-grid-empty');
const fileInput=document.getElementById('file-input');

let vaultRevealed = false;   // siempre arranca oculta por seguridad
let vaultFiles = [];         // cache en memoria de metadatos del usuario actual
let currentFilter = 'all';

function vaultCollection(){
  const uid = currentUser ? currentUser.uid : 'local-demo';
  return db.collection('vaults').doc(uid).collection('files');
}
function vaultStoragePath(fileId, name){
  const uid = currentUser ? currentUser.uid : 'local-demo';
  return `vaults/${uid}/${fileId}_${name}`;
}

async function openVault(){
  vaultScreen.classList.add('show');
  vaultRevealed = false;
  renderVaultMode();
  await loadVaultFiles();
}
document.getElementById('vault-back').addEventListener('click', closeVault);
function closeVault(){ vaultScreen.classList.remove('show'); }

// doble toque en el área principal alterna oculto <-> mostrar
let lastTap = 0;
document.getElementById('vault-body').addEventListener('click', ()=>{
  const now = Date.now();
  if(now - lastTap < 350){ vaultRevealed = !vaultRevealed; renderVaultMode(); }
  lastTap = now;
});

function renderVaultMode(){
  vaultHiddenState.style.display = vaultRevealed ? 'none' : 'block';
  vaultShownState.style.display = vaultRevealed ? 'block' : 'none';
  if(vaultRevealed) renderVaultGrid();
}

document.getElementById('hide-files-btn').addEventListener('click', ()=> fileInput.click());
fileInput.addEventListener('change', async (e)=>{
  const files = Array.from(e.target.files || []);
  fileInput.value = '';
  for(const f of files) await importFileToVault(f, f.name, f.type);
});

async function importFileToVault(fileBlob, name, mimeType){
  const type = mimeType.startsWith('image/') ? 'image' : mimeType.startsWith('video/') ? 'video' : 'file';
  const fileId = 'f_' + Date.now() + '_' + Math.random().toString(36).slice(2,8);
  showToast('Guardando...');
  try{
    const path = vaultStoragePath(fileId, name);
    const ref = storage.ref(path);
    await ref.put(fileBlob);
    const url = await ref.getDownloadURL();
    await vaultCollection().doc(fileId).set({
      name, type, storagePath: path, url, createdAt: Date.now()
    });
    vaultFiles.push({ id: fileId, name, type, url });
    if(vaultRevealed) renderVaultGrid();
    showToast('Guardado en la bóveda.');
  }catch(err){
    showToast('No se pudo subir el archivo.');
  }
}

async function loadVaultFiles(){
  try{
    const snap = await vaultCollection().orderBy('createdAt','desc').get();
    vaultFiles = snap.docs.map(d=>({ id:d.id, ...d.data() }));
  }catch(err){
    vaultFiles = [];
  }
  if(vaultRevealed) renderVaultGrid();
}

document.getElementById('vault-tabs').addEventListener('click', (e)=>{
  const btn = e.target.closest('button'); if(!btn) return;
  currentFilter = btn.dataset.filter;
  document.querySelectorAll('#vault-tabs button').forEach(b=>b.classList.toggle('active', b===btn));
  renderVaultGrid();
});

function renderVaultGrid(){
  const items = currentFilter==='all' ? vaultFiles : vaultFiles.filter(f=>f.type===currentFilter);
  if(items.length===0){ vaultGridEmpty.style.display='flex'; vaultGrid.style.display='none'; return; }
  vaultGridEmpty.style.display='none'; vaultGrid.style.display='grid';
  vaultGrid.innerHTML = items.map(f=>{
    let inner;
    if(f.type==='image') inner = `<img src="${f.url}" alt="${escapeHtml(f.name)}">`;
    else if(f.type==='video') inner = `<video src="${f.url}" muted></video>`;
    else inner = `<div class="file-chip">📄<br>${escapeHtml(f.name)}</div>`;
    const tag = f.type==='image' ? 'Foto' : f.type==='video' ? 'Video' : 'Archivo';
    return `<div class="vault-item" data-id="${f.id}">${inner}<span class="type-tag">${tag}</span><button class="remove" data-id="${f.id}">✕</button></div>`;
  }).join('');
}
vaultGrid.addEventListener('click', async (e)=>{
  const btn = e.target.closest('.remove'); if(!btn) return;
  const id = btn.dataset.id;
  const item = vaultFiles.find(f=>f.id===id);
  vaultFiles = vaultFiles.filter(f=>f.id!==id);
  renderVaultGrid();
  if(item){
    try{ await storage.ref(item.storagePath || vaultStoragePath(id,item.name)).delete(); }catch(e){}
    try{ await vaultCollection().doc(id).delete(); }catch(e){}
  }
});
function escapeHtml(s){ return s.replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

/* =========================================================
   RECEPCION DESDE EL MENU "COMPARTIR" DE ANDROID
   ========================================================= */
const shareOverlay=document.getElementById('share-overlay');
const sharePreviewList=document.getElementById('share-preview-list');
let pendingShareItems = [];

function showSharePreview(items){
  pendingShareItems = items;
  sharePreviewList.innerHTML = items.map(it=>{
    const src = fileSrc(it.path);
    if(it.mimeType && it.mimeType.startsWith('image/')) return `<img src="${src}">`;
    if(it.mimeType && it.mimeType.startsWith('video/')) return `<video src="${src}" muted></video>`;
    return `<div class="file-chip">📄</div>`;
  }).join('');
  shareOverlay.classList.add('show');
}
document.getElementById('share-discard-btn').addEventListener('click', ()=>{
  shareOverlay.classList.remove('show'); pendingShareItems = [];
});
document.getElementById('share-save-btn').addEventListener('click', async ()=>{
  shareOverlay.classList.remove('show');
  // exige PIN + login antes de guardar, igual que el flujo normal de la boveda
  const proceed = async ()=>{
    for(const it of pendingShareItems){
      try{
        const res = await fetch(fileSrc(it.path));
        const blob = await res.blob();
        const name = it.path.split('/').pop();
        await importFileToVault(blob, name, it.mimeType || blob.type || 'application/octet-stream');
      }catch(e){ showToast('No se pudo importar un archivo.'); }
    }
    pendingShareItems = [];
  };
  if(!currentUser){
    // guarda un callback pendiente: al completar login, se procesa el guardado
    window.__afterAuth = proceed;
    await proceedToVault();
  } else {
    await proceed();
  }
});

if(hasCapacitor && ShareReceiver){
  ShareReceiver.addListener('shareReceived', (data)=>{
    if(data && data.items && data.items.length) showSharePreview(data.items);
  });
  ShareReceiver.checkPending();
}

/* =========================================================
   TOAST
   ========================================================= */
const toastEl = document.getElementById('toast');
function showToast(msg){
  toastEl.textContent = msg; toastEl.classList.add('show');
  setTimeout(()=> toastEl.classList.remove('show'), 2200);
}
