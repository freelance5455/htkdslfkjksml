# Calculadora con Bóveda — proyecto Capacitor listo para APK

Este proyecto entrega el **código fuente completo** (interfaz, lógica de la
calculadora, PIN, bóveda, login con Google y recepción vía "Compartir" de
Android) más las plantillas nativas necesarias para compilar un **APK real**.

> **Importante sobre este entorno:** el código se generó en un entorno sin
> Android SDK ni acceso a internet, así que no pude ejecutar `npm install`,
> `gradle` ni generar el `.apk` binario aquí. Lo que tienes es el proyecto
> completo, listo para compilar en tu máquina (o en la nube, p. ej. con
> Android Studio o un runner CI). Los pasos de abajo son exactamente los que
> necesitas seguir.

## Estructura

```
vault-calculator-app/
├─ package.json
├─ capacitor.config.json
├─ www/                        ← la app web (se empaqueta dentro del APK)
│   ├─ index.html
│   ├─ css/style.css
│   └─ js/ (app.js, firebase-init.js)
├─ android-template/           ← archivos nativos a copiar dentro de android/
│   ├─ AndroidManifest.xml     ← con los intent-filter de "Compartir"
│   ├─ xml/file_paths.xml
│   └─ java/com/tuempresa/calculadorabox/
│        ├─ MainActivity.java
│        └─ ShareReceiverPlugin.java   ← recibe fotos/videos reales por Android Share
└─ firebase/
    ├─ firestore.rules         ← aísla los archivos por usuario
    └─ storage.rules
```

## 1. Requisitos previos

- Node.js 18+ y npm
- Android Studio (con Android SDK y un emulador o teléfono conectado)
- Una cuenta de Firebase (gratuita)

## 2. Configurar Firebase (backend real + Google Login)

1. Ve a https://console.firebase.google.com y crea un proyecto.
2. **Authentication** → método **Google** → actívalo.
3. **Firestore Database** → crear base de datos → pega el contenido de
   `firebase/firestore.rules` en la pestaña "Reglas".
4. **Storage** → crear bucket → pega el contenido de `firebase/storage.rules`.
5. **Project settings → General → Your apps**:
   - Agrega una app **Android** con `applicationId` = `com.tuempresa.calculadorabox`
     (o cambia ese id en `capacitor.config.json` y aquí para que coincidan).
     Descarga `google-services.json` (lo usarás en el paso 4).
   - Agrega también una app **Web** y copia su configuración dentro de
     `www/js/firebase-init.js` (reemplaza los valores `TU_API_KEY`, etc.).
6. Para que el login nativo de Google funcione necesitas registrar el
   **SHA-1** de tu certificado de firma en la app Android de Firebase
   (Project settings → tu app Android → "Add fingerprint"). Para obtenerlo
   en modo debug: `keytool -list -v -keystore ~/.android/debug.keystore -alias androiddebugkey -storepass android -keypass android`

## 3. Instalar dependencias y añadir la plataforma Android

```bash
npm install
npx cap add android
```

Esto genera la carpeta `android/` completa (Gradle, manifest por defecto, etc.).

## 4. Copiar las plantillas nativas dentro de `android/`

```bash
# Manifest con los intent-filter de "Compartir"
cp android-template/AndroidManifest.xml android/app/src/main/AndroidManifest.xml

# FileProvider
cp android-template/xml/file_paths.xml android/app/src/main/res/xml/file_paths.xml

# Plugin nativo que recibe archivos compartidos
mkdir -p android/app/src/main/java/com/tuempresa/calculadorabox
cp android-template/java/com/tuempresa/calculadorabox/*.java \
   android/app/src/main/java/com/tuempresa/calculadorabox/

# Firebase
cp google-services.json android/app/google-services.json
```

En `android/app/build.gradle` agrega (si `npx cap add android` no lo hizo ya):

```gradle
apply plugin: 'com.google.gms.google-services'
```

y en `android/build.gradle`, dentro de `dependencies` del bloque `buildscript`:

```gradle
classpath 'com.google.gms:google-services:4.4.2'
```

## 5. Sincronizar e instalar los plugins nativos

```bash
npx cap sync android
```

## 6. Icono y nombre de la app

- Nombre: `android/app/src/main/res/values/strings.xml` → `app_name`.
- Icono: reemplaza los archivos en `android/app/src/main/res/mipmap-*/` con
  Android Studio → clic derecho en `res` → New → Image Asset.

## 7. Compilar y probar

```bash
npx cap open android
```

Esto abre el proyecto en Android Studio. Desde ahí:
- **Run ▶** para instalar en un emulador/dispositivo y probar.
- **Build → Generate Signed Bundle / APK → APK** para generar el `.apk`
  firmado, listo para instalar en cualquier Android (necesitas crear o usar
  un keystore de firma).

## 8. Verificar el flujo pedido

- Calculadora funcional (+, −, ×, ÷, %, +/-, decimales, encadenadas, AC).
- `0000=` → PIN de acceso → (si no hay sesión) Google Login → Mi Bóveda.
- Doble toque en el área de la bóveda alterna oculto ↔ mostrar archivos.
- "Ocultar archivos" abre el selector real de Android.
- Desde WhatsApp/Galería/Telegram → Compartir → debería aparecer tu app en
  la lista → al elegirla se abre la vista previa → "Guardar en Bóveda".

## Notas honestas sobre el alcance de este entrego

- El **backend real** elegido es Firebase (Auth + Firestore + Storage), que
  cumple los requisitos de: cuenta propia por usuario, aislamiento real de
  archivos (reglas de seguridad en el servidor, no solo ocultar botones), y
  persistencia real entre reinicios/actualizaciones (los archivos viven en
  la nube, asociados al `uid`). Es la opción más rápida de dejar funcionando
  sin que tengas que levantar y mantener tu propio servidor.
- El código de `app.js` es un punto de partida funcional y comentado, no un
  producto terminado: te recomiendo añadir manejo de errores más robusto,
  estados de carga, y pruebas en dispositivos reales antes de publicar.
- No pude compilar ni firmar el `.apk` en este entorno (sin Android SDK ni
  red). Todo lo demás — manifest, intent-filters, plugin nativo, reglas de
  Firebase — está listo para que la compilación en tu máquina funcione tal
  como se describe en el flujo pedido.
