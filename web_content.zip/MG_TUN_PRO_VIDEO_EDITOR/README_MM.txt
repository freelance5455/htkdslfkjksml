MG TUN PRO VIDEO EDITOR — Version 1.0

ပါဝင်သောအရာများ
- Android WebView App project (Java + HTML/CSS/JavaScript)
- မြန်မာ UI
- ဖုန်းထဲမှ ဗီဒီယိုရွေးပြီး Preview ကြည့်နိုင်ခြင်း
- မြန်မာစာတန်း၊ စာလုံးအရွယ်၊ အပေါ်/အလယ်/အောက် နေရာနှင့် စာတန်းပုံစံ
- Preview အချိုးအစား 9:16 / 16:9 / 1:1
- Project JSON သိမ်း/ပြန်ဖွင့်
- App icon drawable

အရေးကြီးသော ကန့်သတ်ချက်
ဒီ Version 1 သည် အခြေခံ caption preview/editor ဖြစ်သည်။ စာတန်းပါသော MP4 အသစ်ကို Render/Export လုပ်ခြင်း၊ video trimming၊ transition/effects တို့ မပါသေးပါ။ APK ဖိုင်ကို ဒီ source zip ထဲမှာ ကြိုတင်ထည့်မထားပါ။ AndroidIDE ကနေ Build လုပ်ပြီးမှ APK ရမည်။

ဖုန်းနဲ့ APK Build လုပ်နည်း (အင်တာနက်လိုနိုင်သည်)
1. Android ဖုန်းတွင် AndroidIDE ကို ယုံကြည်ရသော တရားဝင် source မှ install လုပ်ပါ။
2. ZIP ကို Extract လုပ်ပါ။ Folder အတွင်း settings.gradle, build.gradle, app/ ရှိရမည်။
3. AndroidIDE ထဲက Open Project ကိုနှိပ်ပြီး MG_TUN_PRO_VIDEO_EDITOR folder ကိုရွေးပါ။
4. Gradle Sync/Build ပြီးအောင်စောင့်ပါ။ ပထမဆုံးအကြိမ် SDK/Gradle download လိုနိုင်သည်။
5. Build > Assemble Debug (သို့) Run ကိုရွေးပါ။
6. APK အများအားဖြင့် app/build/outputs/apk/debug/app-debug.apk ထဲတွင် ရမည်။
7. APK ကိုနှိပ်ပြီး Android က မေးလျှင် ဒီ source မှ install ခွင့်ပြုပါ။ မသိတဲ့ APK များကို မတပ်ဆင်ပါနှင့်။

မှတ်ချက်
- compileSdk 35 အတွက် AndroidIDE မှ လိုအပ်သော Android SDK/Gradle components ကို ထည့်သွင်းထားရမည်။
- APK build လုပ်ခြင်းသည် ဖုန်းမော်ဒယ်၊ AndroidIDE version၊ SDK download ရရှိမှုအပေါ် မူတည်သည်။
- ဒီ project ကို release/signing key မပါသော debug build အဖြစ် စတင်အသုံးပြုရန် ရည်ရွယ်ထားသည်။
