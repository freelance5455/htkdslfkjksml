// GUNTURRES7 FF OLD - starter WebSocket server
// This is a small multiplayer prototype, NOT an official Free Fire server.
const http = require("http");
const fs = require("fs");
const path = require("path");
const WebSocket = require("ws");

const PORT = Number(process.env.PORT || 8080);
const publicDir = __dirname;
const players = new Map();

const server = http.createServer((req, res) => {
  const pathname = new URL(req.url, `http://${req.headers.host}`).pathname;
  const file = pathname === "/" ? "index.html" : pathname.replace(/^\/+/, "");
  const full = path.join(publicDir, file);
  if (!full.startsWith(publicDir) || !fs.existsSync(full) || !fs.statSync(full).isFile()) {
    res.writeHead(404); return res.end("Not found");
  }
  const ext = path.extname(full);
  const types = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8" };
  res.writeHead(200, { "Content-Type": types[ext] || "application/octet-stream" });
  fs.createReadStream(full).pipe(res);
});

const wss = new WebSocket.Server({ server });
function broadcast() {
  const list = {};
  for (const [id, p] of players) list[id] = p;
  const msg = JSON.stringify({ type: "players", players: list });
  for (const ws of wss.clients) if (ws.readyState === WebSocket.OPEN) ws.send(msg);
}
wss.on("connection", ws => {
  let ownId = null;
  ws.on("message", raw => {
    if (raw.length > 4096) return;
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { return; }
    if (msg.type === "hello") {
      const id = String(msg.id || "").replace(/\D/g, "").slice(0, 8);
      if (id.length !== 8) return ws.close(1008, "Player ID must be 8 digits");
      ownId = id;
      players.set(ownId, { id: ownId, name: String(msg.name || "Player").slice(0, 18), x: 100, y: 100, playing: false });
      broadcast();
    } else if (msg.type === "state" && ownId && players.has(ownId)) {
      const old = players.get(ownId);
      const x = Number(msg.x), y = Number(msg.y);
      if (!Number.isFinite(x) || !Number.isFinite(y)) return;
      players.set(ownId, {
        id: ownId,
        name: String(msg.name || old.name).slice(0, 18),
        x: Math.max(0, Math.min(10000, x)),
        y: Math.max(0, Math.min(10000, y)),
        mode: String(msg.mode || "rank").slice(0, 16),
        playing: Boolean(msg.playing)
      });
      broadcast();
    }
  });
  ws.on("close", () => { if (ownId) { players.delete(ownId); broadcast(); } });
});
server.listen(PORT, "0.0.0.0", () => console.log(`GUNTURRES7 server running on port ${PORT}`));
