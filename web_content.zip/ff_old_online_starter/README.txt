# GUNTURRES7 FF OLD — Online Starter

Ini prototipe multiplayer awal, bukan server resmi Free Fire dan bukan rank resmi.

## Jalankan di komputer
1. Install Node.js versi LTS.
2. Ekstrak folder ini.
3. Buka terminal di folder tersebut.
4. Jalankan `npm install`
5. Jalankan `npm start`
6. Buka `http://localhost:8080`

Untuk perangkat lain, host server di layanan yang mendukung Node.js + WebSocket dan HTTPS/WSS. Masukkan URL WebSocket server pada menu **Mabar Teman** bila tidak memakai alamat default.

## Batasan yang perlu diketahui
- Server ini menyinkronkan posisi pemain dasar.
- Bot pro, hit detection, loot, zona, anti-cheat, room matchmaking, dan rank kompetitif yang aman masih perlu dipindahkan/diterapkan secara authoritative di server.
- Poin rank dalam HTML masih lokal dan bisa diubah pengguna; jangan anggap sebagai rank online kompetitif.
- Tidak terhubung ke akun, server, aset, atau sistem resmi Garena/Free Fire.
