# GUNTURRES7 FREE FIRE OLD ONLINE — HTML fan-made

Prototipe game browser dengan lobby bergaya Free Fire Old, profil ID 8 digit, pilihan avatar, menu skin/senjata demo, zona aman, mode latihan melawan bot, dan multiplayer dasar melalui WebSocket.

## Menjalankan di komputer
1. Pasang Node.js versi LTS.
2. Ekstrak ZIP ini.
3. Buka terminal di folder `ff_old_online_starter`.
4. Jalankan `npm install`
5. Jalankan `npm start`
6. Buka `http://localhost:8080`

Untuk mencoba bersama teman di jaringan lokal, teman harus membuka alamat IP komputer server pada port 8080 (misalnya `http://192.168.x.x:8080`) dan firewall mengizinkan koneksi. Untuk internet publik, host aplikasi pada layanan yang mendukung Node.js dan WebSocket; gunakan HTTPS/WSS pada hosting publik dan isi URL WebSocket di menu **Mabar Teman** jika alamat server WebSocket berbeda.

## Fitur online prototipe
- Status koneksi WebSocket dan jumlah pemain lain yang terhubung.
- ID pemain 8 digit dan nama profil.
- Server menyebarkan status posisi pemain; pemain lain yang sedang bermain dapat digambar pada arena lokal.
- Lobby Mabar demo, menu zona, pilihan avatar, skin, senjata, dan mode latihan bot.
- Tombol layar penuh dan tata letak responsif untuk layar HP.

## Batasan penting
- Ini bukan server resmi Garena/Free Fire, tidak mengakses akun resmi, aset resmi, atau sistem matchmaking Free Fire.
- Multiplayer hanya prototipe sinkronisasi posisi; belum ada room matchmaking sungguhan, database akun, otoritas server untuk hit detection/loot/zona, anti-cheat, atau penyimpanan rank.
- Poin rank, skin, koin, diamond, dan hasil match masih berupa simulasi lokal yang dapat diubah di browser. Jangan gunakan untuk kompetisi atau menganggapnya sebagai rank/item resmi.
- Gunakan aset buatan sendiri atau aset yang kamu punya izin untuk pakai.


## Fitur layar miring untuk HP
- Tombol LAYAR MIRING mencoba masuk layar penuh dan mengunci orientasi landscape pada browser yang mendukungnya.
- Jika browser menolak rotasi otomatis, putar HP ke samping dan aktifkan Rotasi Otomatis dari panel cepat Android.
- Tata letak arena menyesuaikan layar horizontal.
