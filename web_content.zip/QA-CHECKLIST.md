# Release QA checklist

Run these checks against a Netlify deploy preview before promoting it to production.

## Basic access
- [ ] Setup screen explains configuration if Supabase is unavailable.
- [ ] Email/OTP and Google sign-in work.
- [ ] Existing invite links still open and invite-only sign-up remains enforced.
- [ ] Sign-out returns to the authentication screen.
- [ ] Keyboard users can tab to the skip link and jump to main content.

## Artist workflows
- [ ] Dashboard, release list, release detail, profile, and settings load.
- [ ] Draft creation/editing and each wizard step work on desktop and mobile.
- [ ] JPG artwork validation accepts exactly 3000×3000 images and rejects invalid files.
- [ ] Audio validation, upload, and playback work.
- [ ] Submit release, comment, and view notifications work.
- [ ] Artist-facing release notifications use generic release-processing language and do not mention the distributor.
- [ ] Downloaded internal handoff sheet uses readable line breaks and includes the current release and track details.
- [ ] Artist sees only permitted releases, files, earnings, and band information.

## Label workflows
- [ ] Roster, invite, review, status changes, internal notes, earnings, and announcements work.
- [ ] Admin-only actions are not merely hidden in the UI; database policies/RPC grants enforce authorization.
- [ ] Band invitations and band membership changes work as expected.

## Deployment / security
- [ ] Check browser console and Network tab for CSP violations or failed requests.
- [ ] Verify Google OAuth and Turnstile/CAPTCHA after Netlify headers are applied.
- [ ] Confirm `/config.js` is not cached and contains only the public Supabase URL/key and public Turnstile site key.
- [ ] Confirm no service-role key, database password, or private API secret is present in shipped files.
- [ ] Verify private storage access and signed URLs with different account roles.
- [ ] Check mobile navigation, narrow viewport layouts, keyboard focus, and reduced-motion settings.
- [ ] Confirm the new service-worker cache version refreshes a previously installed app.

## RouteNote manual handoff
- [ ] Handoff sheet matches the release and track list.
- [ ] Label manually enters all fields in RouteNote; no automatic sync is implied.
- [ ] Actual RouteNote stores/territories are selected in RouteNote.
- [ ] RouteNote audio/artwork specifications are checked before upload.
- [ ] “Sent to distributor” is set only after RouteNote submission to moderation.
- [ ] “Live” is set only after confirming store availability.


## v16 security regression checks
- [ ] As an authenticated user, inserting a release event for an unrelated release is rejected by RLS.
- [ ] As an owner, label admin, or band member, inserting an event for an accessible release succeeds.
- [ ] Trigger-driven notifications, release-task seeding/shifting, and profile protection still work after direct function EXECUTE grants are revoked.
- [ ] Supabase advisors are reviewed after database changes; remaining SECURITY DEFINER findings are documented and intentional.
- [ ] Enable and test leaked-password protection in Supabase Auth settings (not changed by the website ZIP).


## v18 language regression checks
- [ ] Change language in the header and Settings; the UI changes without logging out or losing the current view.
- [ ] Switch English → Spanish → French → English; labels correctly change each time and return to their original English wording.
- [ ] Add/render a new screen after changing language; supported labels on the newly rendered screen translate.
- [ ] Refresh and sign in again; a signed-in user's saved language preference is restored from `profiles.preferred_language`.
- [ ] Choose a language before login; after login the preference syncs to the user's profile.
- [ ] If profile preference sync fails, local language selection still works and the portal remains usable.
- [ ] Verify artist-entered release title, artist name, track title, lyrics and other metadata are not translated or modified by switching UI language.
- [ ] Check language selector, keyboard access and responsive header on mobile and desktop.

## v23 additions (run on a deploy preview with a real artist and a real label account)
- Artist: open Discography; a saved draft appears under Drafts; Continue editing loads its title, tracks and artwork; Cancel returns to Discography.
- Artist: delete a draft; it disappears and cannot be deleted again. A submitted release has no Delete button.
- Label: request changes on a submitted release; the artist sees it under Changes requested with the note and can Edit & resubmit it.
- Label: on a Live release add stats (All platforms, then a single platform for another date); totals and chart update; saving the same date and platform replaces the row; the artist sees the stats but no form.
- Artist: Request update on a live release; the label gets a notification and a comment starting "Update request:".
- Label: Reopen for edits on an approved or live release returns it to Changes requested.
- Artist: no screen shows the words distributor or RouteNote; "Sent to distributor" reads "Processing".
- Switch tabs away and back while writing a comment; the text must still be there.
- Mobile: menu includes Discography and Sign out and closes after choosing an item; no sideways scrolling on Discography.
- Artist: after submitting, the release cannot be edited or deleted (the portal hides the buttons, and the database now refuses it too).

