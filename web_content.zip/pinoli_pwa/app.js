(() => {
const $=id=>document.getElementById(id), screens=['feedScreen','loginScreen','adminScreen','profileScreen'];
let videos=[],current=0,db;
const DB_NAME='pinoli-local-media', STORE='videos';
function show(id){screens.forEach(s=>$(s).classList.toggle('active',s===id));if(id==='adminScreen')renderAdmin()}
function toast(s){$('toast').textContent=s;$('toast').hidden=false;setTimeout(()=>$('toast').hidden=true,2800)}
function digits(n){return String(n).replace(/\d/g,d=>'۰۱۲۳۴۵۶۷۸۹'[+d])}
function openDB(){return new Promise((resolve,reject)=>{const req=indexedDB.open(DB_NAME,1);req.onupgradeneeded=()=>{const d=req.result;if(!d.objectStoreNames.contains(STORE))d.createObjectStore(STORE,{keyPath:'id',autoIncrement:true})};req.onsuccess=()=>{db=req.result;resolve(db)};req.onerror=()=>reject(req.error)})}
function allVideos(){return new Promise((resolve,reject)=>{const r=db.transaction(STORE,'readonly').objectStore(STORE).getAll();r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
function addVideo(file){return new Promise((resolve,reject)=>{const tx=db.transaction(STORE,'readwrite');tx.objectStore(STORE).add({name:file.name,type:file.type,blob:file,created:Date.now()});tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error)})}
function deleteVideo(id){return new Promise((resolve,reject)=>{const tx=db.transaction(STORE,'readwrite');tx.objectStore(STORE).delete(id);tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error)})}
function clearAll(){return new Promise((resolve,reject)=>{const tx=db.transaction(STORE,'readwrite');tx.objectStore(STORE).clear();tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error)})}
function releaseURL(){const v=$('video');v.pause();if(v.dataset.url)URL.revokeObjectURL(v.dataset.url);v.dataset.url='';v.removeAttribute('src');v.load()}
async function refresh(){videos=await allVideos();if(current>=videos.length)current=Math.max(0,videos.length-1);renderFeed();renderAdmin()}
function renderFeed(){const v=$('video');$('videoCounter').textContent=digits(videos.length)+' ویدیو';if(!videos.length){releaseURL();v.hidden=true;$('empty').hidden=false;$('videoInfo').hidden=true;return}current=Math.max(0,Math.min(current,videos.length-1));const item=videos[current];if(v.dataset.item!==String(item.id)){releaseURL();const u=URL.createObjectURL(item.blob);v.src=u;v.dataset.url=u;v.dataset.item=String(item.id);v.load()}v.hidden=false;$('empty').hidden=true;$('videoInfo').hidden=false;$('videoTitle').textContent=item.name;v.play().catch(()=>{})}
function renderAdmin(){$('count').textContent=digits(videos.length);const list=$('videoList');list.innerHTML='';if(!videos.length){const p=document.createElement('p');p.className='muted';p.textContent='ویدیویی ذخیره نشده است.';list.appendChild(p);return}videos.forEach(item=>{const row=document.createElement('div');row.className='video-row';const span=document.createElement('span');span.textContent=item.name;const btn=document.createElement('button');btn.className='secondary';btn.textContent='حذف';btn.onclick=async()=>{await deleteVideo(item.id);if(current>=videos.length-1)current=Math.max(0,current-1);await refresh();toast('ویدیو از دستگاه حذف شد.')};row.append(span,btn);list.appendChild(row)})}
async function pickFiles(files){for(const f of files){if(!f.type.startsWith('video/'))continue;try{await addVideo(f)}catch(e){toast('ذخیره انجام نشد؛ فضای آزاد دستگاه را بررسی کن.');return}}current=videos.length;await refresh();if(videos.length)current=videos.length-1;renderFeed();toast('ویدیو روی همین دستگاه ذخیره شد و بعداً هم در دسترس می‌ماند.')}
$('adminOpen').onclick=()=>{$('password').value='';$('loginMessage').textContent='';show('loginScreen')};
$('loginForm').onsubmit=e=>{e.preventDefault();if($('password').value==='123456#@'){$('password').value='';show('adminScreen')}else $('loginMessage').textContent='رمز واردشده صحیح نیست.'};
$('logout').onclick=()=>show('feedScreen');document.querySelectorAll('[data-home]').forEach(b=>b.onclick=()=>show('feedScreen'));
['choose','upload','profileChoose'].forEach(id=>$(id).onclick=()=> $('file').click());
$('file').onchange=async e=>{await pickFiles(Array.from(e.target.files||[]));e.target.value=''};
$('profile').onclick=()=>show('profileScreen');
$('deleteAll').onclick=async()=>{if(confirm('همه ویدیوهای ذخیره‌شده از این دستگاه حذف شوند؟')){await clearAll();current=0;await refresh();toast('همه ویدیوها حذف شدند.')}};
$('prevVideo').onclick=()=>{if(videos.length){current=(current-1+videos.length)%videos.length;renderFeed()}};
$('nextVideo').onclick=()=>{if(videos.length){current=(current+1)%videos.length;renderFeed()}};
(async()=>{try{await openDB();await refresh()}catch(e){toast('ذخیره‌سازی محلی در این مرورگر در دسترس نیست.')}if('serviceWorker'in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}))})();
})();