const firebaseConfig = {
  apiKey: "AIzaSyDwbvLTYIAdewmfdC3MlbpH9zNWdOGPpA",
  authDomain: "sumrid-holiday-s-adventure.firebaseapp.com",
  projectId: "sumrid-holiday-s-adventure",
  storageBucket: "sumrid-holiday-s-adventure.firebasestorage.app",
  messagingSenderId: "734806717701",
  appId: "1:734806717701:web:d05d167b82287eab24b36c",
  measurementId: "G-Q5YH5QN2PZ"
};