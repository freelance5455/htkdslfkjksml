SUMRID HOLIDAYS ADVENTURE® — CUSTOMER WEBSITE TEST BUILD

Start page: index.html
This ZIP contains the CUSTOMER website only. The Admin/Manager website is not included.

Important:
- The page expects active Firestore trips with fields: active=true, from, to, date (YYYY-MM-DD), fare (number), vehicleName, capacity, optional time/serviceType/vehicleId, and optional seatLayout.seats.
- Booking writes go to bookings; seat locks go to seatReservations.
- Add the seatReservations rule block from FIRESTORE_RULES_SEAT_RESERVATION_PATCH.txt to the existing Firestore rules. Do not replace existing rules. Test with a test trip first.
- Opening index.html by tapping it in a file manager may not reliably run Firebase. Serve this folder through a web server/hosting environment to test Firebase.
- Live Firebase booking and concurrent seat reservation have NOT been verified from this environment. Do not use for real customers until tested.
