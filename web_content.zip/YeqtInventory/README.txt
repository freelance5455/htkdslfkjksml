Yeqt Inventory Android project
================================

This project wraps your HTML inventory app in an Android WebView.
The HTML file is in app/src/main/assets/index.html.
JavaScript and DOM storage are enabled so the app's localStorage can save inventory on the device.

Build an APK:
1. Install Android Studio on a computer: https://developer.android.com/studio
2. Extract this ZIP file.
3. In Android Studio, choose Open and select the extracted YeqtInventory folder.
4. Allow Gradle sync and install any requested Android SDK components.
5. For a test APK, choose Build > Build Bundle(s) / APK(s) > Build APK(s).
6. When the build completes, click "locate" in the notification.
   The APK is normally at app/build/outputs/apk/debug/app-debug.apk.

Important:
- This ZIP is Android Studio source code, not the APK itself.
- The first build needs internet to download Gradle/Android dependencies.
- Inventory data is stored locally on the device/browser storage. Uninstalling the app or clearing its data may erase that data.
