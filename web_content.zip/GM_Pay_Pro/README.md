# GM Pay Pro

Cette archive est une base professionnelle pour continuer GM Pay.

## Ce qui est inclus
- Application web mobile (`web/index.html`)
- Authentification Firebase
- Profil et historique
- Politique de confidentialité
- Conditions d'utilisation
- Support
- Demande de suppression de compte
- Règles Firestore plus strictes
- Squelette backend Firebase Functions
- Checklist Google Play
- Texte de fiche Play Store

## Limite essentielle
Cette version ne doit PAS être présentée comme un service de paiement réel. Le solde interne ne doit jamais être modifiable par le client. Pour de vrais dépôts/retraits, il faut intégrer un prestataire de paiement autorisé, vérifier ses webhooks côté serveur et respecter les obligations légales/réglementaires.

## Installation
1. Renseigner l'apiKey Firebase dans `web/index.html`.
2. Activer Email/Password dans Firebase Authentication.
3. Créer Firestore.
4. Publier les règles `firebase/firestore.rules`.
5. Déployer le backend après configuration de l'environnement Firebase.
6. Héberger `web/` en HTTPS pour les pages légales.
7. Construire ensuite une application Android signée en AAB avec un outil compatible.

## Taille
Ne gonfle pas artificiellement l'application à 80 Mo. Une taille élevée n'améliore ni la sécurité ni les chances d'acceptation sur Google Play.
