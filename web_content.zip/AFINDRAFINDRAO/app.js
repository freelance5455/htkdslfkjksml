const fileInput = document.getElementById('fileInput');
const chooseFiles = document.getElementById('chooseFiles');
const dropzone = document.getElementById('dropzone');
const fileList = document.getElementById('fileList');
const fileCount = document.getElementById('fileCount');
const totalSize = document.getElementById('totalSize');
const notice = document.getElementById('notice');
const qrDialog = document.getElementById('qrDialog');
let selectedFiles = [];

function formatSize(bytes) {
  if (bytes === 0) return '0 octet';
  const units = ['octets', 'Ko', 'Mo', 'Go', 'To'];
  const index = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
  return `${(bytes / Math.pow(1024, index)).toLocaleString('fr-FR', {maximumFractionDigits: 2})} ${units[index]}`;
}
function fileType(name) {
  const ext = (name.split('.').pop() || 'FILE').toUpperCase();
  return ext.length > 5 ? 'FICHIER' : ext;
}
function renderFiles() {
  fileList.replaceChildren();
  const total = selectedFiles.reduce((sum, file) => sum + file.size, 0);
  fileCount.textContent = `${selectedFiles.length} fichier${selectedFiles.length > 1 ? 's' : ''}`;
  totalSize.textContent = formatSize(total);
  if (!selectedFiles.length) {
    const empty = document.createElement('div'); empty.className = 'empty-state';
    const icon = document.createElement('span'); icon.textContent = '▤';
    const title = document.createElement('p'); title.textContent = 'Aucun fichier sélectionné';
    const hint = document.createElement('small'); hint.textContent = 'Les fichiers choisis apparaîtront ici.';
    empty.append(icon, title, hint); fileList.append(empty); return;
  }
  selectedFiles.forEach((file, index) => {
    const item = document.createElement('div'); item.className = 'file-item';
    const type = document.createElement('div'); type.className = 'file-type'; type.textContent = fileType(file.name);
    const meta = document.createElement('div'); meta.className = 'file-meta';
    const name = document.createElement('div'); name.className = 'file-name'; name.textContent = file.name;
    const size = document.createElement('div'); size.className = 'file-size'; size.textContent = formatSize(file.size);
    meta.append(name, size);
    const remove = document.createElement('button'); remove.className = 'remove-file'; remove.type = 'button'; remove.textContent = '×'; remove.setAttribute('aria-label', `Retirer ${file.name}`);
    remove.addEventListener('click', () => { selectedFiles.splice(index, 1); renderFiles(); });
    item.append(type, meta, remove); fileList.append(item);
  });
}
function addFiles(files) {
  const known = new Set(selectedFiles.map(f => `${f.name}|${f.size}|${f.lastModified}`));
  for (const file of files) {
    const key = `${file.name}|${file.size}|${file.lastModified}`;
    if (!known.has(key)) { selectedFiles.push(file); known.add(key); }
  }
  renderFiles();
}
chooseFiles.addEventListener('click', (event) => { event.stopPropagation(); fileInput.click(); });
dropzone.addEventListener('click', (event) => { if (event.target !== chooseFiles) fileInput.click(); });
dropzone.addEventListener('keydown', (event) => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); fileInput.click(); } });
fileInput.addEventListener('change', () => { addFiles(fileInput.files); fileInput.value = ''; });
document.getElementById('clearFiles').addEventListener('click', () => { selectedFiles = []; renderFiles(); });
['dragenter','dragover'].forEach(type => dropzone.addEventListener(type, event => { event.preventDefault(); dropzone.classList.add('dragging'); }));
['dragleave','drop'].forEach(type => dropzone.addEventListener(type, event => { event.preventDefault(); dropzone.classList.remove('dragging'); }));
dropzone.addEventListener('drop', event => addFiles(event.dataTransfer.files));
function showDialog(title, message) {
  document.getElementById('modalTitle').textContent = title;
  document.getElementById('modalText').textContent = message;
  qrDialog.showModal();
}
document.getElementById('closeDialog').addEventListener('click', () => qrDialog.close());
document.getElementById('modalOk').addEventListener('click', () => qrDialog.close());
document.getElementById('showQrButton').addEventListener('click', () => showDialog('Votre QR local', 'Le code QR de connexion ne peut pas être finalisé dans cette interface seule. Il sera généré après intégration du service Android de découverte et de transfert local.'));
document.getElementById('scanButton').addEventListener('click', async () => {
  if (!('BarcodeDetector' in window) || !navigator.mediaDevices?.getUserMedia) {
    showDialog('Scanner QR', 'Ce navigateur ne fournit pas le scanner QR requis. Sur Android, la version finale utilisera le scanner natif. Autorisez la caméra uniquement lorsque cette fonction sera activée.');
    return;
  }
  showDialog('Scanner QR', 'Le scanner natif sera connecté dans la version Android. Cette maquette ne rejoint pas encore un autre téléphone.');
});
document.getElementById('sendButton').addEventListener('click', () => {
  document.getElementById('filePanel')?.scrollIntoView({behavior:'smooth', block:'start'});
  document.querySelector('.file-panel').scrollIntoView({behavior:'smooth', block:'start'});
  notice.textContent = selectedFiles.length ? `${selectedFiles.length} fichier(s) prêt(s) à être préparé(s). Le transfert réel nécessite encore le moteur local Android.` : 'Choisissez d’abord les fichiers à envoyer. Le transfert réel nécessite encore le moteur local Android.';
});
document.getElementById('receiveButton').addEventListener('click', () => {
  document.getElementById('connectPanel').scrollIntoView({behavior:'smooth', block:'start'});
  notice.textContent = 'Mode réception sélectionné. Reliez les téléphones au même réseau Wi-Fi local ; la réception réelle sera activée par le service Android natif.';
});
if ('serviceWorker' in navigator && location.protocol.startsWith('http')) {
  window.addEventListener('load', () => navigator.serviceWorker.register('./service-worker.js').catch(() => {}));
}
renderFiles();
