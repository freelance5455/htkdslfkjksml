/**
 * NEXUS — Persistência
 * Garante que nada se perde. Snapshot sob demanda + backup simples.
 */

const fs = require('fs');
const path = require('path');

class Persistence {
  constructor(dataDir) {
    this.dataDir = dataDir || path.join(__dirname, '..', 'data');
    if (!fs.existsSync(this.dataDir)) {
      fs.mkdirSync(this.dataDir, { recursive: true });
    }
  }

  snapshot(name = 'manual') {
    const src = path.join(this.dataDir, 'knowledge_graph.json');
    if (!fs.existsSync(src)) return { ok: false, error: 'Sem grafo para copiar' };

    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    const dest = path.join(this.dataDir, `backup_${name}_${stamp}.json`);
    fs.copyFileSync(src, dest);
    return { ok: true, path: dest };
  }

  listBackups() {
    return fs.readdirSync(this.dataDir)
      .filter(f => f.startsWith('backup_') && f.endsWith('.json'))
      .sort()
      .reverse();
  }

  restore(backupFile) {
    const src = path.join(this.dataDir, backupFile);
    const dest = path.join(this.dataDir, 'knowledge_graph.json');
    if (!fs.existsSync(src)) return { ok: false, error: 'Backup não encontrado' };
    fs.copyFileSync(src, dest);
    return { ok: true, message: 'Grafo restaurado' };
  }
}

module.exports = Persistence;
