/**
 * NEXUS — Agendador de Tarefas Automáticas
 * A cada 6h: consolidação de memória
 * Diariamente: detecção de contradições
 */

class Scheduler {
  constructor(loop) {
    this.loop = loop;
    this.timers = [];
  }

  start() {
    // Consolidação a cada 6 horas
    const sixHours = 6 * 60 * 60 * 1000;
    this.timers.push(setInterval(async () => {
      try {
        const stats = await this.loop.grower.consolidate();
        console.log(`[scheduler] consolidação: ${stats.totalNodes} nós`);
      } catch (e) {
        console.warn('[scheduler] erro na consolidação:', e.message);
      }
    }, sixHours));

    // Reflexão diária (24h)
    const day = 24 * 60 * 60 * 1000;
    this.timers.push(setInterval(async () => {
      try {
        const snap = await this.loop.reflect();
        console.log('[scheduler] reflexão diária:\n' + snap);
      } catch (e) {
        console.warn('[scheduler] erro na reflexão:', e.message);
      }
    }, day));

    console.log('[scheduler] tarefas automáticas ativas (6h consolidação, 24h reflexão)');
  }

  stop() {
    for (const t of this.timers) clearInterval(t);
    this.timers = [];
  }
}

module.exports = Scheduler;
