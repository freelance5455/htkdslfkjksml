/**
 * NEXUS Engine — Ciclo Principal
 * Orquestra reasoner + especialistas + persistência
 */

const path = require('path');
const NexusReasoner = require('../core/reason');
const MemoryGraph = require('../core/memory-graph');
const SelfReflect = require('../core/self-reflect');
const Grow = require('../core/grow');

const Researcher = require('../specialists/researcher');
const Mathematician = require('../specialists/mathematician');
const QuantumScientist = require('../specialists/quantum-scientist');
const Architect = require('../specialists/architect');
const Linguist = require('../specialists/linguist');
const Strategist = require('../specialists/strategist');
const Guardian = require('../specialists/guardian');

class NexusLoop {
  constructor(options = {}) {
    const dataPath = options.dataPath || path.join(__dirname, '..', 'data', 'knowledge_graph.json');
    this.memory = new MemoryGraph(dataPath);
    this.reflector = new SelfReflect(this.memory);
    this.grower = new Grow(this.memory);

    this.specialists = {
      researcher: new Researcher(this.memory),
      mathematician: new Mathematician(),
      quantum: new QuantumScientist(this.memory),
      architect: new Architect(),
      linguist: new Linguist(),
      strategist: new Strategist(),
      guardian: new Guardian(options.guardian || {})
    };

    this.reasoner = new NexusReasoner({
      memory: this.memory,
      reflector: this.reflector,
      grower: this.grower,
      specialists: this.specialists
    });

    this.running = false;
  }

  async start() {
    this.running = true;
    return {
      status: 'alive',
      message: 'NEXUS Loop iniciado. Memória e especialistas carregados.',
      stats: this.memory.stats()
    };
  }

  async stop() {
    this.running = false;
    this.memory._save();
    return { status: 'stopped', message: 'Loop parado. Conhecimento preservado.' };
  }

  async ask(input, context = {}) {
    if (!this.running) await this.start();

    // Atalho matemático
    const math = await this.specialists.mathematician.handle(input);
    if (math && math.ok) {
      return {
        answer: `Cálculo verificado:\n${math.steps.join('\n')}\n\nResultado: ${math.result}\n\n[NEXUS • Matemático]`,
        intent: 'calculation',
        confidence: 0.95,
        specialist: 'mathematician'
      };
    }

    const state = await this.reasoner.process(input, context);
    return {
      answer: state.finalAnswer,
      intent: state.intent,
      confidence: state.confidence,
      steps: state.steps,
      findings: state.findings,
      critique: state.critique,
      sessionId: this.reasoner.session.id
    };
  }

  async reflect() {
    return this.reflector.snapshot(this.reasoner.session);
  }

  specialistsReport() {
    return Object.values(this.specialists).map(s => s.report());
  }
}

module.exports = NexusLoop;
