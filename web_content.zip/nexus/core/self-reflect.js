/**
 * NEXUS — Autoanálise e Correção
 * Gera snapshots de estado e detecta contradições simples.
 */

class SelfReflect {
  constructor(memory) {
    this.memory = memory;
  }

  async snapshot(session = {}) {
    const stats = this.memory.stats();
    const uptime = session.startedAt
      ? Math.round((Date.now() - session.startedAt) / 1000)
      : 0;
    const historyLen = (session.history || []).length;

    return [
      '═══ Reflexão do NEXUS ═══',
      `Nós de conhecimento : ${stats.totalNodes}`,
      `Nós reforçados (≥2)  : ${stats.strongNodes}`,
      `Tipos                : ${JSON.stringify(stats.types)}`,
      `Sessão               : ${session.id || '—'}`,
      `Mensagens na sessão  : ${historyLen}`,
      `Uptime da sessão     : ${uptime}s`,
      'Estado               : vivo, aprendendo, sob nosso controle.',
      '═══════════════════════'
    ].join('\n');
  }

  async detectContradictions(limit = 20) {
    // Heurística simples: procura nós com palavras opostas
    const pairs = [['sim', 'não'], ['verdadeiro', 'falso'], ['certo', 'errado']];
    const issues = [];
    const nodes = [...this.memory.nodes.values()].slice(-limit);

    for (const node of nodes) {
      const lower = node.content.toLowerCase();
      for (const [a, b] of pairs) {
        if (lower.includes(a) && lower.includes(b)) {
          issues.push({ id: node.id, content: node.content.slice(0, 80), reason: `contém "${a}" e "${b}"` });
        }
      }
    }
    return issues;
  }

  async update(state) {
    // Após cada ciclo, registra uma reflexão leve se a confiança for alta
    if (state.critique && state.critique.score >= 0.8) {
      this.memory.add(
        `Reflexão: processou "${state.input.slice(0, 60)}..." com score ${state.critique.score}`,
        'reflection',
        { session: true }
      );
    }
  }
}

module.exports = SelfReflect;
