/**
 * NEXUS — Ciclo de Aprendizado Contínuo
 * Recebe → Processa → Aprende → Reflete → Melhora → Guarda
 */

class Grow {
  constructor(memory) {
    this.memory = memory;
  }

  async learn(state) {
    if (!state || !state.input) return;

    // Guarda a interação como experiência se for útil
    const useful =
      state.intent === 'statement' ||
      state.intent === 'correction' ||
      state.intent === 'memory' ||
      (state.critique && state.critique.score > 0.65);

    if (useful) {
      const summary = `Interação: ${state.input.slice(0, 100)} → ${(state.finalAnswer || '').slice(0, 100)}`;
      this.memory.add(summary, 'experience', {
        intent: state.intent,
        confidence: state.confidence,
        ts: Date.now()
      });
    }

    // Reforça nós que foram usados
    if (state.findings && state.findings.length) {
      for (const f of state.findings.slice(0, 3)) {
        if (f.id) {
          const node = this.memory.get(f.id);
          if (node) {
            node.strength = Math.min(10, (node.strength || 1) + 0.15);
            node.lastAccessed = new Date().toISOString();
          }
        }
      }
      this.memory._save();
    }
  }

  /**
   * Ciclo periódico (chamado pelo scheduler)
   * Consolida, remove ruído leve, reforça padrões.
   */
  async consolidate() {
    const stats = this.memory.stats();
    this.memory.add(
      `Consolidação automática: ${stats.totalNodes} nós, ${stats.strongNodes} reforçados.`,
      'reflection',
      { auto: true, ts: Date.now() }
    );
    return stats;
  }
}

module.exports = Grow;
