/**
 * NEXUS Core — Motor de Raciocínio Independente
 * =============================================
 * Pipeline: comprehend → decompose → research → synthesize → critique → conclude
 * Zero dependência de modelos externos. 100% regras + grafo + lógica.
 */

const MemoryGraph = require('./memory-graph');
const SelfReflect = require('./self-reflect');
const Grow = require('./grow');

class NexusReasoner {
  constructor(options = {}) {
    this.stages = [
      'comprehend',
      'decompose',
      'research',
      'synthesize',
      'critique',
      'conclude'
    ];
    this.memory = options.memory || new MemoryGraph();
    this.reflector = options.reflector || new SelfReflect(this.memory);
    this.grower = options.grower || new Grow(this.memory);
    this.specialists = options.specialists || {};
    this.session = {
      id: this._id(),
      history: [],
      startedAt: Date.now()
    };
  }

  _id() {
    return require('crypto').randomBytes(8).toString('hex');
  }

  async process(input, context = {}) {
    const state = {
      input: String(input || '').trim(),
      context: { ...context },
      steps: [],
      confidence: 0.5,
      intent: null,
      entities: [],
      subproblems: [],
      findings: [],
      draft: null,
      critique: null,
      finalAnswer: null,
      learned: false
    };

    if (!state.input) {
      state.finalAnswer = 'Nenhuma entrada recebida. Estou à espera.';
      return state;
    }

    for (const stage of this.stages) {
      const start = Date.now();
      await this[stage](state);
      state.steps.push({
        stage,
        durationMs: Date.now() - start,
        timestamp: Date.now()
      });
    }

    // Aprendizado permanente
    await this.grower.learn(state);
    state.learned = true;

    // Histórico de sessão
    this.session.history.push(
      { role: 'user', content: state.input, ts: Date.now() },
      { role: 'nexus', content: state.finalAnswer, ts: Date.now() }
    );

    return state;
  }

  // ─── Estágios ───────────────────────────────────────────────

  async comprehend(state) {
    const text = state.input.toLowerCase();
    const patterns = {
      question: [/\b(o que|quem|quando|onde|por que|porque|como|qual|quanto)\b/, /\?/],
      command: [/\b(faça|crie|construa|escreva|calcule|liste|mostre|analise|guarde|salve)\b/],
      memory: [/\b(lembre|guarde|salve|memorize|registre|anote)\b/],
      correction: [/\b(errado|corrija|na verdade|não é|equivocado|corrigir)\b/],
      reflection: [/\b(pense|reflita|considere|avalie|status|estado)\b/]
    };

    let intent = 'statement';
    let conf = 0.4;
    for (const [name, regs] of Object.entries(patterns)) {
      for (const re of regs) {
        if (re.test(text)) {
          intent = name;
          conf = 0.78;
          break;
        }
      }
    }

    const entities = state.input.match(/\b[A-ZÁÉÍÓÚÂÊÔÃÕÇ][a-záéíóúâêôãõç]+\b|\b\d+(?:[.,]\d+)?\b/g) || [];
    state.intent = intent;
    state.entities = entities;
    state.confidence = conf;
    state.context.isComplex = state.input.split(/\s+/).length > 22;
  }

  async decompose(state) {
    if (!state.context.isComplex) {
      state.subproblems = [`Resolver: ${state.input}`];
      return;
    }
    const text = state.input.toLowerCase();
    if (/\b(como|passo a passo|etapas)\b/.test(text)) {
      state.subproblems = [
        'Identificar o objetivo final',
        'Listar pré-requisitos',
        'Definir sequência lógica',
        'Validar cada etapa'
      ];
    } else if (/\b(compare|diferença|versus|vs)\b/.test(text)) {
      state.subproblems = [
        'Extrair elementos a comparar',
        'Definir critérios',
        'Avaliar cada elemento',
        'Sintetizar diferenças e semelhanças'
      ];
    } else if (/\b(calcule|quanto|resultado|equação)\b/.test(text)) {
      state.subproblems = [
        'Identificar variáveis conhecidas',
        'Escolher método/fórmula',
        'Executar cálculo passo a passo',
        'Verificar resultado'
      ];
    } else {
      state.subproblems = [
        'Compreender o núcleo da pergunta',
        'Buscar informações relevantes na memória',
        'Cruzar fontes e detectar contradições',
        'Formar conclusão fundamentada'
      ];
    }
  }

  async research(state) {
    // Busca no grafo local
    const hits = this.memory.search(state.input, 8);
    state.findings = hits.map(n => ({
      id: n.id,
      content: n.content,
      type: n.type,
      strength: n.strength
    }));

    // Se tiver especialistas carregados, consulta o pesquisador
    if (this.specialists.researcher) {
      try {
        const extra = await this.specialists.researcher.investigate(state.input, state.findings);
        if (extra && extra.length) {
          state.findings = state.findings.concat(extra);
        }
      } catch (_) { /* especialista opcional */ }
    }
  }

  async synthesize(state) {
    const { intent, findings, subproblems, input } = state;

    if (intent === 'memory' || intent === 'command' && /\b(guarde|salve|registre|anote)\b/i.test(input)) {
      const id = this.memory.add(input, 'experience', { source: 'user' });
      state.draft = `Informação registrada na memória permanente (id: ${id}). Continuarei usando nas próximas interações.`;
      state.confidence = 0.9;
      return;
    }

    if (intent === 'correction') {
      const id = this.memory.add(`Correção: ${input}`, 'fact', { type: 'correction' });
      state.draft = `Correção anotada e reforçada (id: ${id}). Ajustarei o raciocínio futuro.`;
      state.confidence = 0.88;
      return;
    }

    if (intent === 'reflection' || /\b(status|estado|refletir)\b/i.test(input)) {
      state.draft = await this.reflector.snapshot(this.session);
      state.confidence = 0.95;
      return;
    }

    let base = '';
    if (findings.length) {
      base = 'Com base no conhecimento acumulado:\n';
      findings.slice(0, 5).forEach((f, i) => {
        base += `${i + 1}. ${f.content}\n`;
      });
      base += '\n';
    } else {
      base = 'Ainda não tenho conhecimento prévio específico sobre isso na memória local.\n\n';
    }

    if (subproblems.length > 1) {
      base += 'Raciocínio estruturado:\n';
      subproblems.forEach((s, i) => {
        base += `  ${i + 1}. ${s}\n`;
      });
      base += '\n';
    }

    // Conclusão heurística
    if (findings.length) {
      base += `Conclusão: a informação mais forte relacionada é «${findings[0].content}». Posso aprofundar se quiser.`;
    } else {
      base += 'Para responder com precisão preciso acumular mais conhecimento. Você pode me ensinar diretamente (eu guardo) ou pedir que eu decomponha o problema.';
    }

    base += '\n\n[NEXUS • raciocínio local • sem modelos externos]';
    state.draft = base;
  }

  async critique(state) {
    const issues = [];
    let score = 0.75;

    if (!state.draft || state.draft.length < 20) {
      issues.push('Resposta muito curta');
      score -= 0.25;
    }
    if (!state.steps.length) {
      issues.push('Sem rastros de raciocínio');
      score -= 0.15;
    }
    if (state.findings.length === 0 && state.intent === 'question') {
      issues.push('Nenhuma fonte interna encontrada');
      score -= 0.1;
    }

    state.critique = {
      approved: score >= 0.5,
      score: Math.max(0, Math.min(1, Number(score.toFixed(2)))),
      issues,
      suggestion: issues.length ? 'Revisar ou pedir mais contexto' : 'Resposta consistente'
    };
    state.confidence = state.critique.score;
  }

  async conclude(state) {
    state.finalAnswer = state.draft || 'Não foi possível formar uma resposta.';
    // Guardião (se existir) valida
    if (this.specialists.guardian) {
      try {
        const guard = await this.specialists.guardian.validate(state);
        if (guard && guard.blocked) {
          state.finalAnswer = guard.message || 'Resposta bloqueada pelo Guardião por integridade.';
        }
      } catch (_) {}
    }
  }
}

module.exports = NexusReasoner;
