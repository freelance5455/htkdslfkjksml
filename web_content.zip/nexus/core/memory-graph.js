/**
 * NEXUS — Grafo de Conhecimento (Memória Infinita)
 * Cada fato = nó. Cada relação = aresta.
 * Persistência em JSON (evolutivo para SQLite/LevelDB depois).
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

class MemoryGraph {
  constructor(storagePath) {
    this.storagePath = storagePath || path.join(__dirname, '..', 'data', 'knowledge_graph.json');
    this.nodes = new Map();
    this._load();
    this._seed();
  }

  _id(content) {
    return crypto.createHash('sha256').update(content).digest('hex').slice(0, 16);
  }

  _load() {
    try {
      if (fs.existsSync(this.storagePath)) {
        const raw = JSON.parse(fs.readFileSync(this.storagePath, 'utf8'));
        for (const [id, data] of Object.entries(raw)) {
          this.nodes.set(id, data);
        }
      }
    } catch (e) {
      this.nodes = new Map();
    }
  }

  _save() {
    try {
      const dir = path.dirname(this.storagePath);
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      const obj = {};
      for (const [id, node] of this.nodes) obj[id] = node;
      const tmp = this.storagePath + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify(obj, null, 2), 'utf8');
      fs.renameSync(tmp, this.storagePath);
    } catch (e) {
      console.warn('[memória] falha ao persistir:', e.message);
    }
  }

  _seed() {
    if (this.nodes.size > 0) return;
    const seeds = [
      ['NEXUS é um sistema de raciocínio independente construído do zero.', 'concept'],
      ['O pipeline de raciocínio do NEXUS é: Compreensão → Decomposição → Pesquisa → Síntese → Crítica → Conclusão.', 'rule'],
      ['Toda informação armazenada no NEXUS pertence exclusivamente aos seus criadores.', 'fact'],
      ['O NEXUS aprende continuamente a cada interação, sem necessidade de retreinamento externo.', 'rule'],
      ['Segurança no NEXUS significa controle total do código, dos dados e das chaves de acesso.', 'concept'],
      ['Os sete especialistas (Pesquisador, Matemático, Cientista Quântico, Arquiteto, Linguista, Estrategista, Guardião) colaboram sem hierarquia de verdade.', 'concept']
    ];
    for (const [content, type] of seeds) {
      this.add(content, type, { seed: true });
    }
  }

  add(content, type = 'fact', metadata = {}, connections = []) {
    const id = this._id(content);
    if (this.nodes.has(id)) {
      const node = this.nodes.get(id);
      node.strength = Math.min(10, (node.strength || 1) + 0.3);
      node.lastAccessed = new Date().toISOString();
      this.nodes.set(id, node);
    } else {
      this.nodes.set(id, {
        id,
        content,
        type,
        connections: connections || [],
        strength: 1.0,
        created: new Date().toISOString(),
        lastAccessed: new Date().toISOString(),
        metadata: metadata || {}
      });
    }
    this._save();
    return id;
  }

  search(query, limit = 8) {
    const terms = new Set((query || '').toLowerCase().match(/\w+/g) || []);
    if (terms.size === 0) return [];

    const scored = [];
    for (const node of this.nodes.values()) {
      const contentTerms = new Set(node.content.toLowerCase().match(/\w+/g) || []);
      let overlap = 0;
      for (const t of terms) if (contentTerms.has(t)) overlap++;
      if (overlap > 0) {
        const score = (overlap / terms.size) * (node.strength || 1);
        scored.push({ score, node });
      }
    }
    scored.sort((a, b) => b.score - a.score);
    const results = scored.slice(0, limit).map(s => {
      s.node.lastAccessed = new Date().toISOString();
      return s.node;
    });
    return results;
  }

  connect(id1, id2) {
    const n1 = this.nodes.get(id1);
    const n2 = this.nodes.get(id2);
    if (!n1 || !n2) return;
    if (!n1.connections.includes(id2)) n1.connections.push(id2);
    if (!n2.connections.includes(id1)) n2.connections.push(id1);
    this._save();
  }

  get(id) {
    return this.nodes.get(id) || null;
  }

  stats() {
    let strong = 0;
    for (const n of this.nodes.values()) if ((n.strength || 1) >= 2) strong++;
    return {
      totalNodes: this.nodes.size,
      strongNodes: strong,
      types: this._countTypes()
    };
  }

  _countTypes() {
    const c = {};
    for (const n of this.nodes.values()) {
      c[n.type] = (c[n.type] || 0) + 1;
    }
    return c;
  }
}

module.exports = MemoryGraph;
