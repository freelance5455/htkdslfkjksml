/**
 * NEXUS Server — Instância Independente
 * Porta padrão: 4242
 * Serve a interface + API do núcleo
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

const NexusLoop = require('../engine/loop');
const Scheduler = require('../engine/scheduler');
const Persistence = require('../engine/persistence');

const PORT = process.env.NEXUS_PORT || 4242;
const ROOT = path.join(__dirname, '..');
const INTERFACE = path.join(ROOT, 'interface');

const loop = new NexusLoop();
const scheduler = new Scheduler(loop);
const persistence = new Persistence(path.join(ROOT, 'data'));

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon'
};

function send(res, status, body, type = 'application/json; charset=utf-8') {
  res.writeHead(status, {
    'Content-Type': type,
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type'
  });
  res.end(typeof body === 'string' ? body : JSON.stringify(body));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', chunk => { data += chunk; if (data.length > 1e6) req.destroy(); });
    req.on('end', () => {
      try { resolve(data ? JSON.parse(data) : {}); }
      catch (e) { reject(e); }
    });
    req.on('error', reject);
  });
}

const server = http.createServer(async (req, res) => {
  const parsed = url.parse(req.url, true);
  const pathname = parsed.pathname;

  // CORS preflight
  if (req.method === 'OPTIONS') {
    return send(res, 204, '');
  }

  // ── API ──────────────────────────────────────────────
  if (pathname === '/api/health') {
    const stats = loop.memory.stats();
    return send(res, 200, {
      status: 'ok',
      version: '1.0.0',
      stats,
      specialists: loop.specialistsReport()
    });
  }

  if (pathname === '/api/ask' && req.method === 'POST') {
    try {
      const body = await readBody(req);
      const result = await loop.ask(body.input || '');
      return send(res, 200, result);
    } catch (e) {
      return send(res, 500, { error: e.message });
    }
  }

  if (pathname === '/api/reflect') {
    const snap = await loop.reflect();
    return send(res, 200, { reflection: snap });
  }

  if (pathname === '/api/backup' && req.method === 'POST') {
    const result = persistence.snapshot('api');
    return send(res, 200, result);
  }

  // ── Arquivos estáticos da interface ──────────────────
  let filePath = path.join(INTERFACE, pathname === '/' ? 'index.html' : pathname);
  // Segurança: não sai da pasta interface
  if (!filePath.startsWith(INTERFACE)) {
    return send(res, 403, { error: 'Forbidden' });
  }

  fs.readFile(filePath, (err, data) => {
    if (err) {
      return send(res, 404, { error: 'Not found' });
    }
    const ext = path.extname(filePath);
    send(res, 200, data, MIME[ext] || 'application/octet-stream');
  });
});

async function main() {
  await loop.start();
  scheduler.start();

  server.listen(PORT, '0.0.0.0', () => {
    console.log('');
    console.log('╔══════════════════════════════════════════╗');
    console.log('║           N E X U S  v1.0                ║');
    console.log('║   Sistema Independente • Online          ║');
    console.log('╚══════════════════════════════════════════╝');
    console.log(`  → http://localhost:${PORT}`);
    console.log(`  → http://0.0.0.0:${PORT}`);
    console.log('  Memória e especialistas carregados.');
    console.log('  Ctrl+C para encerrar (conhecimento preservado).');
    console.log('');
  });
}

process.on('SIGINT', async () => {
  console.log('\n[NEXUS] Encerrando…');
  scheduler.stop();
  await loop.stop();
  process.exit(0);
});

main().catch(e => {
  console.error('Falha ao iniciar:', e);
  process.exit(1);
});
