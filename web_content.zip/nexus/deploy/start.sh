#!/usr/bin/env bash
# NEXUS — Inicializador Universal
set -e

DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║         NEXUS — Iniciando                ║"
echo "╚══════════════════════════════════════════╝"
echo ""

# Verifica Node
if ! command -v node >/dev/null 2>&1; then
  echo "❌ Node.js não encontrado. Instale Node 16+ e tente novamente."
  exit 1
fi

echo "✓ Node $(node -v)"
echo "✓ Diretório: $DIR"
echo ""

# Garante pasta de dados
mkdir -p ../data

# Inicia o servidor
echo "→ Subindo núcleo na porta ${NEXUS_PORT:-4242}…"
echo ""
exec node server.js
