# NEXUS
- Navegador/PWA: sirva `www/` por HTTPS (ex.: `npx serve www`) e instale pelo navegador.
- Android: `npm install`, `npx cap add android`, `npm run sync`, `npm run open` (Android Studio).
- No AndroidManifest.xml adicione `<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>`.
  Nao adicione SCHEDULE_EXACT_ALARM: avisos nao exatos podem atrasar.
- Tamanho da interface: Configuracoes > Tamanho (80% a 140%).
- Testes obrigatorios em aparelho real: app fechado, reinicio, mudanca de fuso, edicao/exclusao, economia de bateria, restauracao de backup.
- Limites: cancelar/remarcar um unico dia nao cancela o aviso semanal nativo; so o modo navegador respeita excecoes.
