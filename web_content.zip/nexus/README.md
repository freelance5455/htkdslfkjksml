# NEXUS

Notas (links, grafo, canvas), tarefas, projetos e rotina com lembretes — app Capacitor, 100% offline.

- Auditoria e correções: **[AUDIT.md](AUDIT.md)**
- Publicação na Play Store: **[store/play-console-checklist.md](store/play-console-checklist.md)**

## Requisitos
Node 22+, JDK 21 e Android Studio (ou apenas o Android SDK com `ANDROID_HOME` configurado).

## Navegador / PWA
`npm run serve` (HTTPS necessário para instalar como PWA em produção).

## Android (passo a passo)
```bash
npm install
npm run android:setup     # cria android/, copia ícones/splash, ajusta manifest, liga assinatura e versão
npm run android:keystore  # UMA vez: gera release.keystore + keystore.properties (faça backup!)
npm run android:aab       # gera android/app/build/outputs/bundle/release/app-release.aab
```
- Teste local no aparelho: `npm run android:apk` (ou `npm run open` e rode pelo Android Studio).
- Nova versão na loja: aumente `versionCode` (e `versionName`) em `release.json` e rode `npm run android:aab`.
- `npm run android:setup` é idempotente; rode de novo após mudar ícones ou atualizar o Capacitor.
- Alternativa sem instalar nada: `.github/workflows/android-release.yml` gera o AAB no GitHub (veja o cabeçalho do arquivo).

## Testes obrigatórios em aparelho real (antes de publicar)
App fechado (lembrete chega), reinício do aparelho, mudança de fuso, edição/exclusão de atividade, economia de bateria,
Android 13+ (permissão de notificação), botão voltar (fecha folha → canvas → aba Início → sai), exportar backup (abre o
compartilhamento) e restaurar, barras do sistema/notch (layout edge-to-edge do targetSdk 36).

## Limites conhecidos
- No Android, cancelar/remarcar **um único dia** não cancela o lembrete semanal nativo (o modo navegador respeita exceções).
- Sem alarmes exatos (`SCHEDULE_EXACT_ALARM` propositalmente ausente): a economia de bateria pode atrasar avisos.
- Máx. 400 lembretes agendados (o app avisa em Configurações > Notificações).
- Dados vivem no IndexedDB do WebView; faça backups periódicos (Configurações > Backup).
