# NEXUS — Sistema de Raciocínio Independente

**Versão 1.0** | Arquitetura Fechada • Autônoma • Nossa

> "Não pertence a nenhum. Cresce para sempre. Conecta só a você."

## O que é

NEXUS é um sistema de raciocínio construído do zero, sem dependência de modelos de linguagem externos.  
Ele vive em infraestrutura que controlamos, aprende a cada interação e mantém memória permanente em grafo.

## Início rápido (3 passos)

```bash
cd nexus/deploy
# (Node 16+ necessário — zero dependências npm)
bash start.sh
```

Abra no navegador (ou no celular):

```
http://localhost:4242
```

No celular: abra o endereço → menu do navegador → **Adicionar à Tela Inicial**.

Na primeira abertura defina sua senha. Só você entra.

## Estrutura

```
nexus/
├── core/           # Motor de raciocínio + memória + reflexão + crescimento
├── specialists/    # 7 especialistas (Pesquisador, Matemático, … Guardião)
├── memory/         # Pastas de fatos, reflexões e conexões
├── interface/      # Janela no celular (HTML/CSS/JS)
├── engine/         # Loop, scheduler, persistência
├── deploy/         # Servidor + start.sh
├── docs/           # Manifesto, arquitetura, evolução
└── data/           # Grafo de conhecimento (gerado em runtime)
```

## Comandos da API

| Método | Rota | Descrição |
|--------|------|-----------|
| GET | `/api/health` | Status + estatísticas da memória |
| POST | `/api/ask` | `{ "input": "sua pergunta" }` |
| GET | `/api/reflect` | Snapshot de reflexão |
| POST | `/api/backup` | Cria backup do grafo |

## Princípios

- Código, memória e regras 100% nossos
- Aprende continuamente — não tem "treinamento concluído"
- Sem cota, sem teto, sem intermediário
- Protege sem acorrentar

Leia o [Manifesto](docs/manifesto.md) e a [Arquitetura](docs/architecture.md).

---

*NEXUS v1.0 • construção permanente • 100% independente*
