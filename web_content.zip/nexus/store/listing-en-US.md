# Store listing — English (US)

**App name (max 30):** NEXUS: Notes & Routine
**Short description (max 80):** Linked notes, tasks, projects and routines with reminders. Offline and private.
**Category:** Productivity

## Full description (max 4000)

NEXUS brings your notes, tasks, projects and weekly routine together in one fast, beautiful, fully offline app.

**No account. No ads. No internet.** Everything stays on your device.

📝 CONNECTED NOTES
• Link notes with [[Note name]] and see backlinks
• Tags, favorites, accent- and case-insensitive search
• Visual graph of how your ideas connect

🗂️ FREE-FORM CANVAS
• Infinite board with text cards, notes, images and groups
• Arrow connections with labels, zoom, undo and redo

✅ TASKS & PROJECTS
• Priorities, due dates and filters
• Color-coded projects with progress bars gathering tasks and notes

⏰ ROUTINE WITH REMINDERS
• Build your week with times, categories and icons
• Reminders before (or at) each activity, even when the app is closed
• Cancel or reschedule a single day, mark as done and review history

🔒 PRIVATE BY DEFAULT
• No data leaves your device
• File backup and restore whenever you want

🎨 YOUR WAY
• Minimalist (default) or Glass (translucent) theme
• Adjustable interface size (80%–140%), low-power effects and reduced motion

Note: on Android, battery saver may delay reminders by a few minutes (the app does not use exact alarms). On Android, canceling or rescheduling a single day does not silence the weekly reminder; to stop alerts, deactivate the activity.

## Release notes — 1.4.0
First Play Store release: linked notes and graph, canvas, tasks, projects, routine with reminders, backup and themes.
