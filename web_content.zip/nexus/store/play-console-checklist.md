# Checklist de publicação — Google Play Console

> Preencha os campos marcados ☐ na Play Console. Valores sugeridos já estão prontos abaixo.

## 0. Antes de tudo
☐ Conta de desenvolvedor criada (taxa única). Se for conta **pessoal nova**, a Play costuma exigir um **teste fechado** (mín. de testadores por ~14 dias) antes da produção — confira o que a sua conta exige em *Painel → Testes*.
☐ **Hospede** `store/privacy-policy.html` numa URL pública (ex.: GitHub Pages) e **troque o e-mail** no arquivo.
☐ `appId` `app.nexus.pessoal` é definitivo após a 1ª publicação. Se quiser outro, altere em `capacitor.config.json` **antes** de rodar `npm run android:setup`.

## 1. Gerar o AAB (ver README.md)
1. `npm install` → `npm run android:setup` → `npm run android:keystore` (faça backup do `release.keystore` + senha!)
2. `npm run android:aab` → `android/app/build/outputs/bundle/release/app-release.aab`
3. A cada nova versão enviada: aumente `versionCode` em `release.json`.

## 2. Criar o app
- Nome: **NEXUS: Notas e Rotina** · Idioma padrão: Português (Brasil) · Tipo: App · Gratuito
- Declarações: sem anúncios; "Play App Signing" ligado (padrão); envie o `.aab` assinado com a chave de upload.

## 3. Ficha da loja (pasta `store/`)
- Textos: `listing-pt-BR.md` e `listing-en-US.md`
- Ícone 512×512: `graphics/icon-512.png`
- Gráfico de recursos 1024×500: `graphics/feature-graphic-1024x500.png`
- Capturas de tela de telefone (1080×1920): `screenshots/01…07`  (mín. 2; recomendado 4–8)

## 4. Conteúdo do app (Política → Conteúdo do app)
| Item | Resposta sugerida |
|---|---|
| Política de privacidade | URL pública do passo 0 |
| Anúncios | **Não** contém anúncios |
| Acesso ao app | Todas as funções disponíveis sem login/credenciais |
| Público-alvo | **18+** (não direcionado a crianças) |
| Classificação de conteúdo (IARC) | Categoria **Utilitário/Produtividade**; responda **Não** a violência, sexo, drogas, jogos de azar, UGC compartilhado e compartilhamento de localização |
| Apps de notícias / COVID / governo / saúde / finanças | **Não** |
| ID de publicidade | **Não** usa |
| Permissões sensíveis | Nenhuma (só notificações) — **não** declarar alarmes exatos |

## 5. Segurança dos dados (Data safety)
- *O app coleta ou compartilha algum dos tipos de dados exigidos?* → **Não**
- Dados trafegam criptografados? → n/a (nenhum dado sai do aparelho)
- Oferece exclusão de dados? → n/a (sem conta; desinstalar remove os dados)
(Verificado: `www/app.js` não contém `fetch`, `XMLHttpRequest`, `WebSocket` nem URLs externas; CSP `connect-src 'self'`.)

## 6. Lançamento
☐ Teste em aparelho real (lista no README, seção "Testes obrigatórios").
☐ Envie o `.aab` para **Teste interno** primeiro e instale pelo link.
☐ Avance para Produção → país/região → enviar para análise.
