# Ficha da loja — Português (Brasil)

**Nome do app (máx. 30):** NEXUS: Notas e Rotina
**Descrição curta (máx. 80):** Notas com links, tarefas, projetos e rotina com lembretes. Offline e privado.
**Categoria:** Produtividade  ·  **Tags sugeridas:** notas, tarefas, rotina, produtividade, organização

## Descrição completa (máx. 4000)

NEXUS reúne suas notas, tarefas, projetos e rotina semanal em um só app — rápido, bonito e 100% offline.

**Sem conta. Sem anúncios. Sem internet.** Tudo fica guardado no seu aparelho.

📝 NOTAS CONECTADAS
• Crie links entre notas com [[Nome da nota]] e veja os backlinks
• Tags, favoritas, busca ignorando acentos e maiúsculas
• Grafo visual mostrando como suas ideias se conectam

🗂️ CANVAS LIVRE
• Quadro infinito com cartões de texto, notas, imagens e grupos
• Conexões com setas e rótulos, zoom, desfazer e refazer

✅ TAREFAS E PROJETOS
• Prioridades, prazos e filtros
• Projetos com cor e barra de progresso, reunindo tarefas e notas

⏰ ROTINA COM LEMBRETES
• Monte sua semana com horários, categorias e ícones
• Lembretes antes (ou no início) de cada atividade, mesmo com o app fechado
• Cancele ou remarque só um dia, marque como concluída e consulte o histórico

🔒 PRIVADO POR PADRÃO
• Nenhum dado sai do seu aparelho
• Backup e restauração em arquivo, quando você quiser

🎨 SEU JEITO
• Tema Minimalista (padrão) ou Glass (translúcido)
• Tamanho da interface ajustável de 80% a 140%, efeitos econômicos e opção de reduzir animações

Observação: no Android, avisos de economia de bateria podem atrasar lembretes em alguns minutos (o app não usa alarmes exatos). No Android, cancelar ou remarcar um único dia não silencia o lembrete semanal; para parar os avisos, desative a atividade.

## Notas de versão (máx. 500) — 1.4.0
Primeira versão na Play Store: notas com links e grafo, canvas, tarefas, projetos, rotina com lembretes, backup e temas (Minimalista por padrão).
