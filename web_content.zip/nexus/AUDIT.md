# Auditoria NEXUS 1.3.0 → 1.4.0

Método: leitura integral do código + teste ponta a ponta no Chromium (web e Capacitor simulado) + capturas de tela em 360×640.
Resultado final: **24 verificações automatizadas passando**, sem erros de console, sem overflow horizontal em 360 px.
Atualização: tema **Minimalista** é o padrão (Glass continua disponível em Configurações).

## Bloqueadores da Play Store
| # | Problema | Correção |
|---|---|---|
| 1 | Capacitor 6 → `targetSdk 34`. Desde 31/08/2026 a Play exige **API 36** para apps novos/atualizações | Migrado para Capacitor **8** (`targetSdk 36`, minSdk 24); `android:setup` avisa se `targetSdk < 36` |
| 2 | Sem assinatura, versionCode ou fluxo de AAB | `release.json`, `keystore.properties`, `signing.gradle`, scripts `android:keystore` / `android:aab` |
| 3 | Ícones/splash padrão do Capacitor; `ic_stat_nexus` (ícone de notificação) **não existia** | Ícones adaptativos (+monocromático), legado, splash próprio e vetor `ic_stat_nexus` |
| 4 | Passo manual no manifest (`POST_NOTIFICATIONS`) fácil de esquecer | Aplicado automaticamente (+ `RECEIVE_BOOT_COMPLETED`); sem alarmes exatos |
| 5 | Sem política de privacidade, ficha, capturas, Data safety | Pasta `store/` completa |

## Bugs corrigidos
| # | Gravidade | Bug | Correção |
|---|---|---|---|
| 6 | Alta | **Botão voltar do Android** fechava o app mesmo com folha/canvas aberto | Handler (`@capacitor/app`): fecha folha → canvas → volta à Início → sai |
| 7 | Alta | **Exportar backup não funcionava no app** (WebView ignora download de blob) | Salva em cache + compartilhamento nativo (`Filesystem`+`Share`); web mantém download |
| 8 | Alta | **Service worker cache-first** com nome fixo: após atualizar, usuários ficavam com versão antiga | Rede primeiro, cache versionado, desligado no app nativo |
| 9 | Média | Permissão de notificação só pedida se o usuário achasse o botão; Android 13+ = nenhum lembrete | Pede ao criar a 1ª atividade com lembrete e ao ligar lembretes |
| 10 | Média | `Notify.run` concorrente (cancel/schedule intercalados) podia perder agendamentos; reagendamento no boot esperava 15 s | Execuções serializadas; reagenda logo ao abrir |
| 11 | Média | Backup importado com canvas/atividade incompleta **quebrava a UI** ou injetava CSS (`left:${n.x}px` sem sanitizar) | Sanitização de números, lados, tipos; normalização de atividades; `esc()` em horários |
| 12 | Média | Folhas altas (Grafo, listas) abriam **roladas até o fim** (foco no último botão) | Foco só em campos de texto, sem scroll |
| 13 | Média | Cards de **Projetos** e linhas da **Rotina** sem padding (`.nb` zerava `.card`) | CSS corrigido |
| 14 | Baixa | Botões ‹ Hoje › da Rotina quebravam em 3 linhas | Layout `.rnav` |
| 15 | Baixa | Esc fechava **todas** as folhas empilhadas; `closeAll` vazava listeners | Fecha só a do topo; `closeAll` usa os closers |
| 16 | Baixa | Limite de 400 lembretes cortava em silêncio | Aviso em Configurações |
| 17 | Baixa | Grafo apertado, rótulos sobrepostos | Layout com mais espaço |
| 18 | Baixa | ~120 linhas de código morto (2× `openCanvas`, 2× `searchSheet`, views antigas) sobrescritas silenciosamente | Removidas |
| 19 | Baixa | Targetsdk 35+ força edge-to-edge: barras do sistema sobre o conteúdo | `max(env(safe-area…), var(--safe-area-…))` |

## Endurecimento
- JS movido para `app.js` e **CSP estrita** (`script-src 'self'`, `connect-src 'self'`): sem scripts inline nem rede.
- Manifest PWA com `id`, `scope`, ícones maskable e categorias.

## Não alterado (decisões suas)
- Exceções de um dia não valem para o agendamento nativo semanal (limitação já documentada).
- Imagens do canvas ficam em base64 no IndexedDB; backups com muitas imagens ficam grandes.
- Backup JSON não é criptografado.

## Não foi possível fazer aqui
- **Compilar o AAB**: o ambiente não tem JDK/Android SDK nem rede para baixar Gradle/Capacitor. Os scripts foram testados contra um projeto Android simulado, não contra um real.
- **Testar em aparelho** (notificações com app fechado, edge-to-edge, compartilhamento): faça a lista do README.
- Versões `^8.0.0` dos plugins `app/share/filesystem` seguem a linha do Capacitor 8; se o `npm install` reclamar, use a versão que ele sugerir.
