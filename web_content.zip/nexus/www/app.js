"use strict";
const VERSION="1.4.0";
const $=(s,r=document)=>r.querySelector(s);
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const norm=s=>String(s||"").normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase();
const uid=()=>crypto.randomUUID?crypto.randomUUID():Date.now().toString(36)+Math.random().toString(36).slice(2);
const now=()=>new Date().toISOString();
const IC={
home:'<path d="M3 11l9-8 9 8M5 10v10h5v-6h4v6h5V10"/>',
notes:'<path d="M6 3h9l4 4v14H6zM14 3v5h5M9 13h7M9 17h5"/>',
tasks:'<rect x="4" y="4" width="16" height="16" rx="4"/><path d="M8 12l3 3 5-6"/>',
routine:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
proj:'<path d="M3 7h7l2 2h9v10H3z"/>'};
const svg=n=>`<svg class="i" viewBox="0 0 24 24">${IC[n]}</svg>`;
const TABS=[["home","Início"],["notes","Notas"],["tasks","Tarefas"],["routine","Rotina"],["proj","Projetos"]];

/* ===== Camada de dados (IndexedDB v1) ===== */
const DB={db:null,
stores:{notes:"id",tasks:"id",projects:"id",categories:"id",activities:"id",exceptions:"id",completions:"id",canvases:"id",settings:"key"},
open(){return new Promise((ok,no)=>{
 if(!window.indexedDB)return no(new Error("IndexedDB indisponível neste navegador."));
 const r=indexedDB.open("nexus",2);
 r.onupgradeneeded=()=>{for(const[s,k]of Object.entries(this.stores))if(!r.result.objectStoreNames.contains(s))r.result.createObjectStore(s,{keyPath:k})};
 r.onsuccess=()=>{this.db=r.result;this.db.onversionchange=()=>this.db.close();ok()};
 r.onerror=()=>no(r.error);r.onblocked=()=>no(new Error("Banco bloqueado por outra aba."))})},
tx(s,m,f){return new Promise((ok,no)=>{const t=this.db.transaction(s,m);const q=f(t.objectStore(s));
 t.oncomplete=()=>ok(q&&q.result);t.onerror=()=>no(t.error);t.onabort=()=>no(t.error||new Error("Transação abortada"))})},
all(s){return this.tx(s,"readonly",o=>o.getAll())},
get(s,k){return this.tx(s,"readonly",o=>o.get(k))},
put(s,v){return this.tx(s,"readwrite",o=>o.put(v))},
del(s,k){return this.tx(s,"readwrite",o=>o.delete(k))}};

/* ===== Estado, preferências ===== */
const S={tab:"home",prefs:{fx:"bal",rm:false,theme:"min"}};
function applyPrefs(){const r=document.documentElement;r.dataset.fx=S.prefs.fx;r.dataset.theme=S.prefs.theme||"min";const mt=document.querySelector("meta[name=theme-color]");if(mt)mt.content=(S.prefs.theme||"min")==="min"?"#1e1e1e":"#080F16";r.dataset.rm=S.prefs.rm?"on":"off";r.style.setProperty("--ui",supZoom()?(S.prefs.ui||100)/100:1)}
async function loadPrefs(){const p=await DB.get("settings","prefs");if(p)S.prefs={...S.prefs,...p.value};applyPrefs()}
const savePrefs=()=>DB.put("settings",{key:"prefs",value:S.prefs});

/* ===== Componentes ===== */
let tt;function toast(msg,err){const t=$("#toast");t.textContent=msg;t.style.color=err?"#ff8a8f":"";t.classList.add("on");clearTimeout(tt);tt=setTimeout(()=>t.classList.remove("on"),err?4500:2200)}
const fail=e=>{console.error(e);toast("Erro: "+(e&&e.message||e),true)};
function sheet(html){const ov=document.createElement("div");ov.className="ov";
 ov.innerHTML=`<div class="sheet g g-modal" role="dialog" aria-modal="true">${html}</div>`;
 const close=()=>{ov.remove();document.removeEventListener("keydown",kd)};
 const kd=e=>{if(e.key==="Escape"&&ov===[...document.querySelectorAll(".ov")].pop())close()};document.addEventListener("keydown",kd);ov._close=close;
 ov.addEventListener("click",e=>{if(e.target===ov)close()});document.body.appendChild(ov);
 const f=$("input:not([type=checkbox]):not([type=range]):not([type=file]),textarea",ov),box=ov.firstElementChild;box.tabIndex=-1;(f||box).focus({preventScroll:true});return{el:ov,close}}
function confirmBox(msg,label,fn){const s=sheet(`<h3>Confirmar</h3><p class="sub">${esc(msg)}</p><div class="acts"><button class="btn sec" id="n">Cancelar</button><button class="btn dan" id="y">${esc(label)}</button></div>`);
 $("#n",s.el).onclick=s.close;$("#y",s.el).onclick=async()=>{s.close();try{await fn()}catch(e){fail(e)}}}
const empty=(t,d)=>`<div class="g g-light card empty"><b>${esc(t)}</b>${esc(d)}</div>`;

/* ===== Telas ===== */
function greet(){const h=new Date().getHours();return h<5?"Boa madrugada":h<12?"Bom dia":h<18?"Boa tarde":"Boa noite"}
const dateStr=()=>new Date().toLocaleDateString("pt-BR",{weekday:"long",day:"numeric",month:"long"});
const timeStr=()=>new Date().toLocaleTimeString("pt-BR",{hour:"2-digit",minute:"2-digit"});

async function vHome(){
 const[n,t,p,a]=await Promise.all([DB.all("notes"),DB.all("tasks"),DB.all("projects"),DB.all("activities")]);
 const open=t.filter(x=>x.status!=="done"),done=t.length-open.length;
 const pct=t.length?Math.round(done/t.length*100):0;
 const recent=[...n].sort((x,y)=>y.updatedAt.localeCompare(x.updatedAt)).slice(0,3);
 return`<div class="enter"><div><h1>${greet()}</h1><p class="sub">${esc(dateStr())} · <span id="clock">${timeStr()}</span></p></div>
 <div class="g g-std card"><div class="lbl">Próxima atividade</div>${await homeRoutine()}</div>
 <div class="grid"><div class="g g-std card"><div class="num">${open.length}</div><div class="lbl">Tarefas pendentes</div></div>
 <div class="g g-std card"><div class="num">${p.filter(x=>x.status!=="done").length}</div><div class="lbl">Projetos ativos</div></div></div>
 <h2>Produtividade</h2>
 ${t.length?`<div class="g g-std card"><b>${done} de ${t.length} tarefas concluídas</b><div class="bar"><i style="width:${pct}%"></i></div></div>`:empty("Sem tarefas","Crie uma tarefa com o botão + para acompanhar seu progresso.")}
 <h2>Notas recentes</h2>
 ${recent.length?recent.map(x=>`<div class="g g-std row" data-open="${esc(x.id)}"><div class="t"><b>${esc(x.title)}</b><div class="m">${new Date(x.updatedAt).toLocaleDateString("pt-BR")}</div></div></div>`).join(""):empty("Nenhuma nota","Toque em + e registre seu primeiro pensamento.")}</div>`}

const PRI={low:"Baixa",med:"Média",high:"Alta",urg:"Urgente"};
const VIEWS={home:vHome,notes:vNotes2,tasks:vTasks2,routine:vRoutine,proj:vProj};

async function render(){
 try{S.projs=await DB.all("projects");const v=$("#view");v.innerHTML=await VIEWS[S.tab]();if(S.tab==="notes")await fillNotes();if(S.tab==="tasks")await fillTasks();if(S.tab==="proj")await fillProj();if(S.tab==="routine")await fillRoutine();}catch(e){fail(e)}
}
function go(tab){S.tab=tab;[...$("#nav").children].forEach(b=>b.setAttribute("aria-current",b.dataset.t===tab?"page":"false"));$("#view").scrollTop=0;render()}

/* ===== Ações ===== */
$("#view").addEventListener("click",async e=>{
 try{const tg=e.target.closest("[data-tg]");
 if(tg){const t=await DB.get("tasks",tg.dataset.tg);const d=t.status==="done";
  await DB.put("tasks",{...t,status:d?"open":"done",completedAt:d?null:now()});toast(d?"Tarefa reaberta":"Tarefa concluída");return render()}
 const dl=e.target.closest("[data-del]");
 if(dl){const[s,id]=dl.dataset.del.split(":");confirmBox("Esta ação não pode ser desfeita.","Excluir",async()=>{await DB.del(s,id);toast("Excluído");render()})}}
 catch(x){fail(x)}});

function quickCreate(){
 let kind="note";
 const s=sheet(`<h3>Criação rápida</h3><div class="seg" role="group"><button data-k="note" aria-pressed="true">Nota</button><button data-k="task" aria-pressed="false">Tarefa</button></div>
 <label for="qt">Título</label><input id="qt" maxlength="200" autocomplete="off">
 <div id="nb"><label for="qb">Conteúdo</label><textarea id="qb"></textarea></div>
 <div id="tb" hidden><label for="qp">Prioridade</label><select id="qp"><option value="low">Baixa</option><option value="med" selected>Média</option><option value="high">Alta</option><option value="urg">Urgente</option></select></div>
 <div class="err" id="qe"></div><div class="acts"><button class="btn sec" id="qc">Cancelar</button><button class="btn" id="qs">Salvar</button></div>`);
 const el=s.el;
 el.querySelectorAll("[data-k]").forEach(b=>b.onclick=()=>{kind=b.dataset.k;el.querySelectorAll("[data-k]").forEach(x=>x.setAttribute("aria-pressed",x===b));$("#nb",el).hidden=kind!=="note";$("#tb",el).hidden=kind!=="task"});
 $("#qc",el).onclick=s.close;
 $("#qs",el).onclick=async()=>{const title=$("#qt",el).value.trim();
  if(!title){$("#qe",el).textContent="Digite um título para salvar.";return $("#qt",el).focus()}
  try{const ts=now();
   if(kind==="note")await DB.put("notes",{id:uid(),title,body:$("#qb",el).value,tags:[],favorite:false,projectId:null,createdAt:ts,updatedAt:ts});
   else await DB.put("tasks",{id:uid(),title,description:"",priority:$("#qp",el).value,dueDate:null,status:"open",projectId:null,createdAt:ts,completedAt:null});
   s.close();toast(kind==="note"?"Nota salva":"Tarefa salva");S.tab==="home"||S.tab===(kind==="note"?"notes":"tasks")?render():go(kind==="note"?"notes":"tasks")}
  catch(e){$("#qe",el).textContent="Não foi possível salvar: "+e.message}}}

async function settingsSheet(){
 let sz="";try{const e=await navigator.storage.estimate();sz=` · ${(e.usage/1024).toFixed(1)} KB usados`}catch{}
 const cnt=await Promise.all(["notes","tasks","projects","activities"].map(k=>DB.all(k).then(r=>r.length)));
 const s=sheet(`<h3>Configurações</h3>${themeBlock()}<label>Intensidade dos efeitos</label>
 <div class="seg" role="group">${[["eco","Econômico"],["bal","Equilibrado"],["max","Máximo"]].map(([k,l])=>`<button data-fx="${k}" aria-pressed="${S.prefs.fx===k}">${l}</button>`).join("")}</div>
 <div class="sw" style="margin-top:12px"><label for="rm" style="margin:0">Reduzir animações</label><input type="checkbox" id="rm" ${S.prefs.rm?"checked":""}></div>
 <label>Armazenamento</label><p class="sub">${cnt[0]} notas · ${cnt[1]} tarefas · ${cnt[2]} projetos · ${cnt[3]} atividades${sz}</p>
 ${sizeBlock()}${notifBlock()}${backupBlock()}<label>Versão</label><p class="sub">${VERSION}</p><div class="acts"><button class="btn" id="ok">Fechar</button></div>`);
 s.el.querySelectorAll("[data-fx]").forEach(b=>b.onclick=async()=>{S.prefs.fx=b.dataset.fx;applyPrefs();s.el.querySelectorAll("[data-fx]").forEach(x=>x.setAttribute("aria-pressed",x===b));try{await savePrefs()}catch(e){fail(e)}});
 $("#rm",s.el).onchange=async e=>{S.prefs.rm=e.target.checked;applyPrefs();try{await savePrefs()}catch(x){fail(x)}};
 $("#ok",s.el).onclick=s.close;notifStatus();$("#nen",s.el).onchange=async e=>{S.prefs.notif=e.target.checked;try{await savePrefs();if(S.prefs.notif)await Notify.ensure();await Notify.run();notifStatus()}catch(x){fail(x)}}}

/* ===== Etapa 2: Notas, tags, links e backlinks ===== */
Object.assign(S,{nq:"",nsort:"date",ntag:null,nfav:false});
const fmt=d=>new Date(d).toLocaleString("pt-BR",{dateStyle:"short",timeStyle:"short"});
const parseTags=s=>[...new Set(s.split(/[,\n]/).map(t=>t.trim().replace(/^#/,"")).filter(Boolean))].slice(0,20);
const LINK=/\[\[([^\[\]\n]{1,120})\]\]/g;
const nkey=t=>norm(String(t).trim());
const linkKeys=b=>[...new Set([...(b||"").matchAll(LINK)].map(m=>nkey(m[1])))];
const renderBody=(b,known)=>esc(b).replace(LINK,(_,n)=>`<button class="lk${known.has(nkey(n))?"":" un"}" data-lk="${n.trim()}">${n.trim()}</button>`);
const closeAll=()=>document.querySelectorAll(".ov").forEach(o=>o._close?o._close():o.remove());

async function vNotes2(){return`<div class="enter"><h1>Notas</h1>
<div class="acts" style="margin:0 0 10px"><button class="btn" data-newnote>Nova nota</button><button class="btn sec" data-graph>Grafo</button><button class="btn sec" data-canvas>Canvas</button></div>
<input id="nq" type="search" placeholder="Buscar notas…" aria-label="Buscar notas" value="${esc(S.nq)}">
<div class="seg" style="margin:10px 0"><button data-nsort="date" aria-pressed="${S.nsort==="date"}">Recentes</button><button data-nsort="title" aria-pressed="${S.nsort==="title"}">Título</button><button data-nfavf aria-pressed="${S.nfav}">★ Favoritas</button></div>
<div id="nt" style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px"></div><div id="nl"></div></div>`}

async function fillNotes(){
 const all=await DB.all("notes");
 if(S.ntag&&!all.some(n=>(n.tags||[]).includes(S.ntag)))S.ntag=null;
 const tags=[...new Set(all.flatMap(n=>n.tags||[]))].sort();
 const q=norm(S.nq);
 const l=all.filter(n=>(!S.nfav||n.favorite)&&(!S.ntag||(n.tags||[]).includes(S.ntag))&&(!q||norm(n.title+" "+n.body+" "+(n.tags||[]).join(" ")).includes(q)));
 l.sort(S.nsort==="title"?(a,b)=>a.title.localeCompare(b.title,"pt-BR"):(a,b)=>b.updatedAt.localeCompare(a.updatedAt));
 $("#nt").innerHTML=tags.map(t=>`<button class="chip" data-ntag="${esc(t)}" aria-pressed="${S.ntag===t}">#${esc(t)}</button>`).join("");
 $("#nl").innerHTML=l.length?l.map(n=>`<div class="g g-std row"><button class="t nb" data-open="${esc(n.id)}"><b>${esc(n.title)}</b><div class="m">${esc((n.body||"").slice(0,90))}</div>${(n.tags||[]).map(t=>`<span class="tag">#${esc(t)}</span>`).join(" ")}</button><button class="btn sec xs" data-nf="${esc(n.id)}" aria-label="Favoritar">${n.favorite?"★":"☆"}</button><button class="btn sec xs" data-del="notes:${esc(n.id)}" aria-label="Excluir nota">Excluir</button></div>`).join(""):empty(all.length?"Nada encontrado":"Nenhuma nota ainda",all.length?"Ajuste a busca ou os filtros.":"Toque em Nova nota para começar.");
}

async function openNote(id){
 const all=await DB.all("notes"),n=all.find(x=>x.id===id);
 if(!n)return toast("Nota não encontrada",true);
 const key=nkey(n.title),known=new Set(all.map(x=>nkey(x.title)));
 const back=all.filter(x=>x.id!==n.id&&linkKeys(x.body).includes(key));
 const dup=all.some(x=>x.id!==n.id&&nkey(x.title)===key);
 const s=sheet(`<h3>${esc(n.title)} ${n.favorite?"★":""}</h3><div class="sub">Criada ${fmt(n.createdAt)} · editada ${fmt(n.updatedAt)}</div>
${(n.tags||[]).map(t=>`<span class="tag">#${esc(t)}</span>`).join(" ")}
${dup?'<div class="err">Existe outra nota com este título; links para ele pedirão que você escolha.</div>':""}
<div class="g g-deep card read" style="margin-top:12px">${n.body?renderBody(n.body,known):'<span class="sub">Nota vazia.</span>'}</div>
<h2>Backlinks (${back.length})</h2>${back.length?back.map(x=>`<div class="g g-std row" data-open="${esc(x.id)}"><div class="t"><b>${esc(x.title)}</b></div></div>`).join(""):'<p class="sub">Nenhuma nota aponta para esta.</p>'}
<div class="acts"><button class="btn sec" id="c">Fechar</button><button class="btn" id="e">Editar</button></div>`);
 $("#c",s.el).onclick=s.close;$("#e",s.el).onclick=()=>{s.close();editNote(n)}}

async function openLink(name){
 const all=await DB.all("notes"),m=all.filter(x=>nkey(x.title)===nkey(name));
 if(m.length===1)return openNote(m[0].id);
 if(m.length>1){const s=sheet(`<h3>Qual nota?</h3><p class="sub">Há ${m.length} notas chamadas “${esc(name)}”.</p>${m.map(x=>`<div class="g g-std row" data-open="${esc(x.id)}"><div class="t"><b>${esc(x.title)}</b><div class="m">Criada ${fmt(x.createdAt)}</div></div></div>`).join("")}<div class="acts"><button class="btn sec" id="c">Cancelar</button></div>`);return void($("#c",s.el).onclick=s.close)}
 confirmBox(`A nota “${name}” ainda não existe. Criar agora?`,"Criar nota",async()=>{const ts=now(),n={id:uid(),title:name.trim(),body:"",tags:[],favorite:false,projectId:null,createdAt:ts,updatedAt:ts};await DB.put("notes",n);render();editNote(n)});
}

function editNote(n,pid){
 let cur=n?{...n}:null,tm;
 const s=sheet(`<h3>${n?"Editar nota":"Nova nota"}</h3>
<label for="et">Título</label><input id="et" maxlength="200" value="${esc(n&&n.title)}">
<label for="eg">Tags (separadas por vírgula)</label><input id="eg" value="${esc(n?(n.tags||[]).join(", "):"")}">
<label for="ep">Projeto</label><select id="ep"><option value="">Nenhum</option>${S.projs.map(p=>`<option value='${esc(p.id)}' ${(n?n.projectId:pid)===p.id?'selected':''}>${esc(p.name)}</option>`).join('')}</select>
<label for="eb">Conteúdo — use [[Nome da nota]] para criar links</label><textarea id="eb" style="min-height:200px">${esc(n&&n.body)}</textarea>
<div class="sw"><label for="ef" style="margin:0">Favorita</label><input type="checkbox" id="ef" ${n&&n.favorite?"checked":""}></div>
<div class="sub" id="st">Salvamento automático ativado.</div><div class="err" id="ee"></div>
<div class="acts"><button class="btn" id="d">Concluir</button></div>`);
 const el=s.el;
 const save=async()=>{const title=$("#et",el).value.trim();
  if(!title){$("#ee",el).textContent="Digite um título para salvar.";return false}
  $("#ee",el).textContent="";const ts=now(),base=cur||{id:uid(),projectId:null,createdAt:ts};
  cur={...base,title,body:$("#eb",el).value,tags:parseTags($("#eg",el).value),favorite:$("#ef",el).checked,projectId:$("#ep",el).value||null,updatedAt:ts};
  try{await DB.put("notes",cur);$("#st",el).textContent="Salvo às "+timeStr();render();return true}
  catch(e){$("#ee",el).textContent="Falha ao salvar: "+e.message;return false}};
 el.querySelectorAll("input,textarea,select").forEach(i=>i.addEventListener("input",()=>{clearTimeout(tm);$("#st",el).textContent="Salvando…";tm=setTimeout(save,700)}));
 $("#d",el).onclick=async()=>{clearTimeout(tm);if(!cur&&!$("#et",el).value.trim()&&!$("#eb",el).value.trim())return s.close();if(await save()){s.close();openNote(cur.id)}}}

document.addEventListener("click",async e=>{
 try{const t=e.target;let b;
  if(b=t.closest("[data-lk]")){closeAll();return openLink(b.dataset.lk)}
  if(b=t.closest("[data-open]")){closeAll();return openNote(b.dataset.open)}
  if(t.closest("[data-newnote]"))return editNote(null);
  if(b=t.closest("[data-nf]")){const n=await DB.get("notes",b.dataset.nf);await DB.put("notes",{...n,favorite:!n.favorite,updatedAt:now()});return fillNotes()}
  if(b=t.closest("[data-nsort]")){S.nsort=b.dataset.nsort;document.querySelectorAll("[data-nsort]").forEach(x=>x.setAttribute("aria-pressed",x===b));return fillNotes()}
  if(b=t.closest("[data-nfavf]")){S.nfav=!S.nfav;b.setAttribute("aria-pressed",S.nfav);return fillNotes()}
  if(b=t.closest("[data-ntag]")){S.ntag=S.ntag===b.dataset.ntag?null:b.dataset.ntag;return fillNotes()}
 }catch(x){fail(x)}});
document.addEventListener("input",e=>{if(e.target.id==="nq"){S.nq=e.target.value;fillNotes().catch(fail)}});

/* ===== Etapa 3: Tarefas, Projetos e Grafo ===== */
Object.assign(S,{tq:'',tf:'open',ts:'due',curProj:null,projs:[]});
const PO={urg:0,high:1,med:2,low:3},STAT={active:'Ativo',paused:'Pausado',done:'Concluído'};
const projOf=id=>S.projs.find(p=>p.id===id);
const today=()=>{const d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')};
const dueFmt=d=>new Date(d+'T00:00:00').toLocaleDateString('pt-BR',{day:'2-digit',month:'short'});
const okColor=c=>/^#[0-9a-f]{6}$/i.test(c)?c:'#54D6E8';
const seg=(a,cur,it)=>it.map(([k,l])=>`<button data-${a}='${k}' aria-pressed='${cur===k}'>${l}</button>`).join('');
const taskRow=t=>{const p=projOf(t.projectId),late=t.dueDate&&t.status!=='done'&&t.dueDate<today(),dn=t.status==='done';
 return`<div class='g g-std row ${dn?'done':''}'><button class='chk ${dn?'on':''}' data-tg='${esc(t.id)}' aria-label='${dn?'Reabrir':'Concluir'} tarefa'>${dn?'✓':''}</button><button class='t nb' data-tedit='${esc(t.id)}'><b>${esc(t.title)}</b><div class='m'><span class='tag'>${PRI[t.priority]||'Média'}</span>${t.dueDate?` <span ${late?"style='color:#ff8a8f'":''}>${dueFmt(t.dueDate)}${late?' · atrasada':''}</span>`:''}${p?` <span style='color:${okColor(p.color)}'>● ${esc(p.name)}</span>`:''}</div></button></div>`};

async function vTasks2(){return`<div class='enter'><h1>Tarefas</h1><div class='acts' style='margin:0 0 10px'><button class='btn' data-newtask>Nova tarefa</button></div>
<input id='tq' type='search' placeholder='Buscar tarefas…' aria-label='Buscar tarefas' value='${esc(S.tq)}'>
<div class='seg' style='margin:10px 0'>${seg('tf',S.tf,[['open','Abertas'],['done','Concluídas'],['all','Todas']])}</div>
<div class='seg' style='margin:0 0 12px'>${seg('ts',S.ts,[['due','Prazo'],['pri','Prioridade'],['new','Recentes']])}</div><div id='tl'></div></div>`}
async function fillTasks(){const all=await DB.all('tasks'),q=norm(S.tq);
 const l=all.filter(t=>(S.tf==='all'||(S.tf==='done')===(t.status==='done'))&&(!q||norm(t.title+' '+(t.description||'')+' '+((projOf(t.projectId)||{}).name||'')).includes(q)));
 const c={due:(a,b)=>(a.dueDate||'9')<(b.dueDate||'9')?-1:(a.dueDate||'9')>(b.dueDate||'9')?1:0,pri:(a,b)=>(PO[a.priority]??2)-(PO[b.priority]??2),new:(a,b)=>b.createdAt.localeCompare(a.createdAt)}[S.ts];
 l.sort((a,b)=>(a.status==='done')-(b.status==='done')||c(a,b));
 $('#tl').innerHTML=l.length?l.map(t=>taskRow(t)).join(''):empty(all.length?'Nada encontrado':'Nenhuma tarefa ainda',all.length?'Ajuste a busca ou os filtros.':'Toque em Nova tarefa para começar.')}

function editTask(t,pid,ret){
 const s=sheet(`<h3>${t?'Editar tarefa':'Nova tarefa'}</h3><label for='tt'>Título</label><input id='tt' maxlength='200' value='${esc(t&&t.title)}'>
<label for='td'>Descrição</label><textarea id='td'>${esc(t&&t.description)}</textarea>
<label for='tp'>Prioridade</label><select id='tp'>${Object.entries(PRI).map(([k,v])=>`<option value='${k}' ${(t?t.priority:'med')===k?'selected':''}>${v}</option>`).join('')}</select>
<label for='tdd'>Prazo (opcional)</label><input type='date' id='tdd' value='${esc((t&&t.dueDate)||'')}'>
<label for='tpr'>Projeto</label><select id='tpr'><option value=''>Nenhum</option>${S.projs.map(p=>`<option value='${esc(p.id)}' ${(t?t.projectId:pid)===p.id?'selected':''}>${esc(p.name)}</option>`).join('')}</select>
<div class='err' id='te'></div><div class='acts'>${t?`<button class='btn dan' id='tx'>Excluir</button>`:`<button class='btn sec' id='tc'>Cancelar</button>`}<button class='btn' id='ts2'>Salvar</button></div>`);
 const el=s.el,back=()=>{if(ret)openProject(ret)};
 if(!t)$('#tc',el).onclick=()=>{s.close();back()};else $('#tx',el).onclick=()=>confirmBox('Excluir esta tarefa?','Excluir',async()=>{await DB.del('tasks',t.id);s.close();toast('Tarefa excluída');render();back()});
 $('#ts2',el).onclick=async()=>{const title=$('#tt',el).value.trim();if(!title){$('#te',el).textContent='Digite um título para salvar.';return}
  const o=t||{id:uid(),status:'open',createdAt:now(),completedAt:null};
  try{await DB.put('tasks',{...o,title,description:$('#td',el).value,priority:$('#tp',el).value,dueDate:$('#tdd',el).value||null,projectId:$('#tpr',el).value||null});s.close();toast('Tarefa salva');render();back()}
  catch(e){$('#te',el).textContent='Falha ao salvar: '+e.message}}}

async function vProj(){return`<div class='enter'><h1>Projetos</h1><div class='acts' style='margin:0 0 10px'><button class='btn' data-newproj>Novo projeto</button></div><div id='pl'></div></div>`}
async function fillProj(){const[ps,ts,ns]=await Promise.all([DB.all('projects'),DB.all('tasks'),DB.all('notes')]);
 $('#pl').innerHTML=ps.length?ps.sort((a,b)=>b.createdAt.localeCompare(a.createdAt)).map(p=>{const t=ts.filter(x=>x.projectId===p.id),d=t.filter(x=>x.status==='done').length,pc=t.length?Math.round(d/t.length*100):0,c=okColor(p.color);
 return`<button class='g g-std card nb' style='width:100%;display:block;border-left:4px solid ${c}' data-proj='${esc(p.id)}'><b style='color:${c}'>${esc(p.name)}</b> <span class='tag'>${STAT[p.status]||''}</span><div class='sub' style='margin:4px 0 0'>${t.length} tarefa(s) · ${ns.filter(x=>x.projectId===p.id).length} nota(s)</div>${t.length?`<div class='bar'><i style='width:${pc}%;background:${c}'></i></div><div class='sub' style='margin:4px 0 0'>${pc}% concluído</div>`:`<div class='sub' style='margin:4px 0 0'>Sem tarefas: sem progresso para exibir.</div>`}</button>`}).join(''):empty('Nenhum projeto','Toque em Novo projeto para organizar suas notas e tarefas.')}

function editProject(p){
 const s=sheet(`<h3>${p?'Editar projeto':'Novo projeto'}</h3><label for='pn'>Nome</label><input id='pn' maxlength='120' value='${esc(p&&p.name)}'>
<label for='pd'>Descrição</label><textarea id='pd'>${esc(p&&p.description)}</textarea>
<label for='ps'>Status</label><select id='ps'>${Object.entries(STAT).map(([k,v])=>`<option value='${k}' ${(p?p.status:'active')===k?'selected':''}>${v}</option>`).join('')}</select>
<label for='pco'>Cor</label><input type='color' id='pco' value='${okColor(p&&p.color)}'>
<div class='err' id='pe2'></div><div class='acts'>${p?`<button class='btn dan' id='px'>Excluir</button>`:`<button class='btn sec' id='pc2'>Cancelar</button>`}<button class='btn' id='pv'>Salvar</button></div>`);
 const el=s.el;
 if(!p)$('#pc2',el).onclick=s.close;else $('#px',el).onclick=()=>confirmBox('Notas e tarefas serão mantidas; apenas a associação com o projeto será removida.','Excluir projeto',async()=>{s.close();for(const st of ['tasks','notes'])for(const x of await DB.all(st))if(x.projectId===p.id)await DB.put(st,{...x,projectId:null});await DB.del('projects',p.id);S.curProj=null;toast('Projeto excluído');render()});
 $('#pv',el).onclick=async()=>{const name=$('#pn',el).value.trim();if(!name){$('#pe2',el).textContent='Digite um nome para o projeto.';return}
  const o=p||{id:uid(),createdAt:now()};
  try{await DB.put('projects',{...o,name,description:$('#pd',el).value,status:$('#ps',el).value,color:okColor($('#pco',el).value)});s.close();toast('Projeto salvo');await render();openProject(o.id)}
  catch(e){$('#pe2',el).textContent='Falha ao salvar: '+e.message}}}

async function openProject(id){
 const p=await DB.get('projects',id);if(!p)return;S.curProj=id;
 const tasks=(await DB.all('tasks')).filter(x=>x.projectId===id),notes=(await DB.all('notes')).filter(x=>x.projectId===id);
 const done=tasks.filter(x=>x.status==='done').length,pc=tasks.length?Math.round(done/tasks.length*100):0,c=okColor(p.color);
 const s=sheet(`<h3 style='color:${c}'>${esc(p.name)}</h3><p class='sub'>${STAT[p.status]||''}${p.description?' · '+esc(p.description):''}</p>
${tasks.length?`<b>${done} de ${tasks.length} tarefas (${pc}%)</b><div class='bar'><i style='width:${pc}%;background:${c}'></i></div>`:`<p class='sub'>Sem tarefas: o progresso aparece quando houver alguma.</p>`}
<h2>Tarefas</h2>${tasks.map(t=>taskRow(t)).join('')}<button class='btn sec' data-ptask='${esc(id)}'>Nova tarefa</button>
<h2>Notas (${notes.length})</h2>${notes.map(n=>`<div class='g g-std row' data-open='${esc(n.id)}'><div class='t'><b>${esc(n.title)}</b></div></div>`).join('')}<button class='btn sec' data-pnote='${esc(id)}'>Nova nota</button>
<div class='acts'><button class='btn sec' id='pe'>Editar projeto</button><button class='btn' id='pcl'>Fechar</button></div>`);
 $('#pcl',s.el).onclick=s.close;$('#pe',s.el).onclick=()=>{s.close();editProject(p)}}

function layout(nodes,edges,W,H){
 nodes.forEach((n,i)=>{const a=i*2.4;n.x=W/2+Math.cos(a)*(30+i*5);n.y=H/2+Math.sin(a)*(30+i*5);n.vx=n.vy=0});
 for(let it=0;it<250;it++){const k=1-it/250;
  for(const a of nodes){for(const b of nodes){if(a===b)continue;const dx=a.x-b.x,dy=a.y-b.y,d=dx*dx+dy*dy+.01,r=Math.sqrt(d),f=7000/d*k;a.vx+=dx/r*f;a.vy+=dy/r*f}a.vx+=(W/2-a.x)*.01;a.vy+=(H/2-a.y)*.01}
  for(const[s,t]of edges){const dx=t.x-s.x,dy=t.y-s.y,d=Math.sqrt(dx*dx+dy*dy)||1,f=(d-95)*.03;s.vx+=dx/d*f;s.vy+=dy/d*f;t.vx-=dx/d*f;t.vy-=dy/d*f}
  for(const n of nodes){n.x=Math.min(W-25,Math.max(25,n.x+n.vx*.5));n.y=Math.min(H-25,Math.max(25,n.y+n.vy*.5));n.vx*=.6;n.vy*=.6}}}

async function openGraph(){
 const[notes,projs]=await Promise.all([DB.all('notes'),DB.all('projects')]);
 const nodes=[],edges=[],byKey=new Map(),ghosts=new Map(),pn=new Map(),nn=new Map();
 const add=o=>{o.deg=0;nodes.push(o);return o},link=(a,b)=>{edges.push([a,b]);a.deg++;b.deg++};
 projs.forEach(p=>pn.set(p.id,add({t:'p',id:p.id,l:p.name,c:okColor(p.color)})));
 notes.slice(0,120).forEach(n=>{const o=add({t:'n',id:n.id,l:n.title,n});nn.set(n.id,o);const k=nkey(n.title);byKey.set(k,[...(byKey.get(k)||[]),o])});
 nn.forEach(o=>{const n=o.n,seen=new Set();
  for(const m of (n.body||'').matchAll(LINK)){const nm=m[1].trim(),k=nkey(nm);if(seen.has(k))continue;seen.add(k);
   const tg=(byKey.get(k)||[]).filter(x=>x!==o);
   if(tg.length)tg.forEach(x=>link(o,x));else if(!byKey.has(k)){if(!ghosts.has(k))ghosts.set(k,add({t:'g',l:nm}));link(o,ghosts.get(k))}}
  if(n.projectId&&pn.has(n.projectId))link(o,pn.get(n.projectId))});
 if(!nodes.length)return void sheet(`<h3>Grafo</h3>${empty('Nada para conectar','Crie notas e links [[ ]] para ver o grafo.')}<div class='acts'><button class='btn' data-x>Fechar</button></div>`).el.querySelector('[data-x]').addEventListener('click',closeAll);
 const W=360,H=460;layout(nodes,edges,W,H);
 const R=o=>(o.t==='p'?9:o.t==='g'?4:5)+Math.min(o.deg,6);
 const sv=`<svg viewBox='0 0 ${W} ${H}' style='width:100%;height:auto;display:block' role='img' aria-label='Grafo de notas'>`+edges.map(([a,b])=>`<line x1='${a.x.toFixed(1)}' y1='${a.y.toFixed(1)}' x2='${b.x.toFixed(1)}' y2='${b.y.toFixed(1)}' stroke='var(--cy)' stroke-opacity='.35'/>`).join('')+nodes.map(o=>{const r=R(o),at=o.t==='n'?`data-open='${esc(o.id)}'`:o.t==='p'?`data-proj='${esc(o.id)}'`:`data-lk='${esc(o.l)}'`,fill=o.t==='p'?o.c:o.t==='g'?'none':'var(--cy)',st=o.t==='g'?` stroke='#ffb454' stroke-dasharray='3'`:'',x=o.x.toFixed(1),y=o.y.toFixed(1);
  return`<g ${at} style='cursor:pointer'><circle cx='${x}' cy='${y}' r='${r+9}' fill='transparent'/><circle cx='${x}' cy='${y}' r='${r}' fill='${fill}'${st}/><text x='${x}' y='${(o.y+r+11).toFixed(1)}' text-anchor='middle' font-size='9' fill='#91AFC2'>${esc(o.l.length>16?o.l.slice(0,15)+'…':o.l)}</text></g>`}).join('')+'</svg>';
 const s=sheet(`<h3>Grafo</h3><p class='sub'>Destaque: notas · colorido: projetos · tracejado laranja: links sem nota. Toque num nó para abrir.</p><div class='g g-deep' style='padding:6px'>${sv}</div><div class='acts'><button class='btn' data-x>Fechar</button></div>`);
 $('[data-x]',s.el).onclick=s.close}

document.addEventListener('click',async e=>{try{const t=e.target;let b;
 if(t.closest('[data-newtask]'))return editTask(null);
 if(b=t.closest('[data-tedit]')){const ret=t.closest('.ov')?S.curProj:null,k=await DB.get('tasks',b.dataset.tedit);closeAll();return editTask(k,null,ret)}
 if(b=t.closest('[data-ptask]')){closeAll();return editTask(null,b.dataset.ptask,b.dataset.ptask)}
 if(b=t.closest('[data-pnote]')){closeAll();return editNote(null,b.dataset.pnote)}
 if(t.closest('[data-newproj]'))return editProject(null);
 if(b=t.closest('[data-proj]')){closeAll();return openProject(b.dataset.proj)}
 if(t.closest('[data-graph]'))return openGraph();
 if((b=t.closest('[data-tg]'))&&t.closest('.ov')){const k=await DB.get('tasks',b.dataset.tg),d=k.status==='done';await DB.put('tasks',{...k,status:d?'open':'done',completedAt:d?null:now()});closeAll();render();return openProject(S.curProj)}
 if(b=t.closest('[data-tf]')){S.tf=b.dataset.tf;document.querySelectorAll('[data-tf]').forEach(x=>x.setAttribute('aria-pressed',x===b));return fillTasks()}
 if(b=t.closest('[data-ts]')){S.ts=b.dataset.ts;document.querySelectorAll('[data-ts]').forEach(x=>x.setAttribute('aria-pressed',x===b));return fillTasks()}
}catch(x){fail(x)}});
document.addEventListener('input',e=>{if(e.target.id==='tq'){S.tq=e.target.value;fillTasks().catch(fail)}});

/* ===== Etapa 4: Rotina ===== */
Object.assign(S,{rv:'day',ro:0,rd:null,cats:[]});
const DN=['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'],DL=['Domingo','Segunda-feira','Terça-feira','Quarta-feira','Quinta-feira','Sexta-feira','Sábado'];
const ICONS=['📌','📚','🥊','🎸','🏃','💼','🧘','🍽️','💤','🎯','💻','🛒'];
const iso=d=>d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
const pd=s=>new Date(s+'T12:00:00');
const addD=(s,n)=>{const d=pd(s);d.setDate(d.getDate()+n);return iso(d)};
const monday=s=>addD(s,-((pd(s).getDay()+6)%7));
const toM=t=>{const[h,m]=t.split(':');return+h*60+ +m};
const dur=m=>m>=60?Math.floor(m/60)+'h'+(m%60?' '+m%60+'min':''):m+' min';
const nowMin=()=>{const d=new Date();return d.getHours()*60+d.getMinutes()};

function occs(date,R){const dow=pd(date).getDay(),out=[];
 for(const a of R.acts){if(!a.active||!a.days.includes(dow))continue;const k=a.id+'|'+date,ex=R.exc.get(k);
  out.push({a,date,k,s:a.start,e:a.end,st:!ex?'n':ex.type==='cancel'?'c':'o',ex,done:R.cmp.has(k)})}
 for(const ex of R.exc.values())if(ex.type==='move'&&ex.newDate===date){const a=R.acts.find(x=>x.id===ex.activityId);if(a&&a.active)out.push({a,date,k:ex.id,s:ex.start,e:ex.end,st:'i',ex,done:R.cmp.has(ex.id)})}
 return out.sort((x,y)=>toM(x.s)-toM(y.s))}
async function loadR(){const[acts,exc,cmp,cats]=await Promise.all([DB.all('activities'),DB.all('exceptions'),DB.all('completions'),DB.all('categories')]);S.cats=cats;return{acts,exc:new Map(exc.map(x=>[x.id,x])),cmp:new Map(cmp.map(x=>[x.id,x])),cats}}
function routineSummary(R){const n=nowMin(),to=occs(today(),R).filter(o=>o.st==='n'||o.st==='i'),cur=to.find(o=>toM(o.s)<=n&&n<toM(o.e)),nx=to.find(o=>toM(o.s)>n);
 return`<div class='sub' style='margin:6px 0 0'>${cur?`Em andamento: ${esc(cur.a.icon)} ${esc(cur.a.name)} (até ${esc(cur.e)})`:'Nenhuma atividade em andamento.'}<br>${nx?`Próxima: ${esc(nx.a.name)} às ${esc(nx.s)} (em ${dur(toM(nx.s)-n)})`:'Sem mais atividades hoje.'}<br>${to.filter(o=>o.done).length} de ${to.length} concluídas hoje.</div>`}
async function homeRoutine(){const R=await loadR();return R.acts.length?routineSummary(R):`<div style='margin-top:6px'>Nenhuma atividade na rotina ainda. Crie a primeira na aba Rotina.</div>`}
const occRow=o=>{const a=o.a,off=o.st==='c'||o.st==='o';
 return`<button class='g g-std row nb' style='width:100%;border-left:4px solid ${okColor(a.color)};${off?'opacity:.5':''}' data-occ='${esc(o.k)}'><div class='t'><b>${esc(a.icon)} ${esc(a.name)}</b><div class='m'>${esc(o.s)}–${esc(o.e)}${o.st==='c'?' · cancelada':o.st==='o'?' · remarcada':o.st==='i'?' · remarcada para este dia':''}${o.done?' · ✔ concluída':''}</div></div></button>`};

async function vRoutine(){S.rd=S.rd||today();return`<div class='enter'><h1>Rotina</h1>
<div class='acts' style='margin:0 0 10px;flex-wrap:wrap'><button class='btn' data-newact>Nova atividade</button><button class='btn sec' data-cats>Categorias</button><button class='btn sec' data-hist>Histórico</button></div>
<div id='rdash'></div><div class='seg' style='margin:10px 0'>${seg('rv',S.rv,[['day','Dia'],['week','Semana']])}</div>
<div class='rnav' style='margin:0 0 10px'><button class='btn sec xs' data-rnav='-1' aria-label='Semana anterior'>‹</button><button class='btn sec' data-rnav='0'>Hoje</button><button class='btn sec xs' data-rnav='1' aria-label='Próxima semana'>›</button></div>
<div id='rbody'></div></div>`}
async function fillRoutine(){const R=await loadR(),t=today(),ws=monday(addD(t,S.ro*7)),days=[...Array(7)].map((_,i)=>addD(ws,i));
 if(!days.includes(S.rd))S.rd=days[0];
 $('#rdash').innerHTML=`<div class='g g-std card'><b>Hoje</b>${routineSummary(R)}</div>`;
 const dayHtml=d=>{const l=occs(d,R);return l.length?l.map(occRow).join(''):`<p class='sub'>Nada programado.</p>`};
 const strip=`<div style='display:flex;gap:6px;margin-bottom:12px'>${days.map(d=>{const n=occs(d,R).filter(o=>o.st==='n'||o.st==='i').length;return`<button class='chip' style='flex:1;padding:0;min-height:58px;${d===t?'border-color:var(--cy);':''}' data-rday='${d}' aria-pressed='${d===S.rd}'>${DN[pd(d).getDay()]}<br><b>${pd(d).getDate()}</b>${n?`<span style='color:var(--cy)'> •${n}</span>`:''}</button>`}).join('')}</div>`;
 $('#rbody').innerHTML=S.rv==='day'?strip+`<h2>${DL[pd(S.rd).getDay()]}, ${pd(S.rd).toLocaleDateString('pt-BR',{day:'numeric',month:'long'})}${S.rd===t?' · hoje':''}</h2>`+dayHtml(S.rd)+`<button class='btn sec' data-copyday style='margin-top:6px'>Copiar este dia para…</button>`:days.map(d=>`<h2 style='${d===t?'color:var(--cy)':''}'>${DL[pd(d).getDay()]} ${pd(d).getDate()}${d===t?' · hoje':''}</h2>`+dayHtml(d)).join('')}

async function openOcc(k){const R=await loadR(),[aid,od]=k.split('|'),a=R.acts.find(x=>x.id===aid);if(!a)return;
 const ex=R.exc.get(k),done=R.cmp.get(k),cat=R.cats.find(c=>c.id===a.categoryId),task=a.taskId?await DB.get('tasks',a.taskId):null;
 const s=sheet(`<h3>${esc(a.icon)} ${esc(a.name)}</h3><p class='sub'>${DL[pd(od).getDay()]}, ${pd(od).toLocaleDateString('pt-BR')} · ${ex&&ex.type==='move'?`${esc(ex.start)}–${esc(ex.end)} (remarcada para ${pd(ex.newDate).toLocaleDateString('pt-BR')})`:`${esc(a.start)}–${esc(a.end)}`}${cat?' · '+esc(cat.name):''}${ex&&ex.type==='cancel'?' · cancelada':''}</p>${a.description?`<p>${esc(a.description)}</p>`:''}${task?`<p class='sub'>Tarefa vinculada: ${esc(task.title)}</p>`:''}${done?`<p class='sub'>✔ Concluída em ${fmt(done.doneAt)}</p>`:''}<div class='err' id='oe'></div>
<div class='acts' style='flex-wrap:wrap'><button class='btn' id='od1'>${done?'Desmarcar conclusão':'Marcar como concluída'}</button></div>
<div class='acts' style='flex-wrap:wrap'>${ex?`<button class='btn sec' id='ore'>Restaurar horário original</button>`:`<button class='btn sec' id='oca'>Cancelar só este dia</button><button class='btn sec' id='omv'>Remarcar</button>`}</div>
<div class='acts'><button class='btn sec' id='oed'>Editar atividade</button><button class='btn sec' id='ocl'>Fechar</button></div>`);
 const el=s.el,go2=async f=>{try{await f();s.close();await render()}catch(e){fail(e)}};
 $('#od1',el).onclick=()=>go2(async()=>{done?await DB.del('completions',k):await DB.put('completions',{id:k,activityId:aid,date:od,doneAt:now()});toast(done?'Conclusão removida':'Atividade concluída')});
 $('#ocl',el).onclick=s.close;$('#oed',el).onclick=()=>{s.close();editAct(a)};
 if(ex)$('#ore',el).onclick=()=>go2(()=>DB.del('exceptions',k));
 else{$('#oca',el).onclick=()=>go2(async()=>{await DB.put('exceptions',{id:k,activityId:aid,date:od,type:'cancel'});toast('Cancelada só em '+pd(od).toLocaleDateString('pt-BR'))});
  $('#omv',el).onclick=()=>{s.close();const m=sheet(`<h3>Remarcar ocorrência</h3><p class='sub'>Só afeta este dia; a repetição semanal continua.</p><label for='md'>Nova data</label><input type='date' id='md' value='${od}'><label for='ms'>Início</label><input type='time' id='ms' value='${a.start}'><label for='me'>Término</label><input type='time' id='me' value='${a.end}'><div class='err' id='mr'></div><div class='acts'><button class='btn sec' id='mc'>Cancelar</button><button class='btn' id='mo'>Remarcar</button></div>`);
   $('#mc',m.el).onclick=m.close;$('#mo',m.el).onclick=async()=>{const nd=$('#md',m.el).value,st=$('#ms',m.el).value,en=$('#me',m.el).value;
    if(!nd||!st||!en||toM(en)<=toM(st)){$('#mr',m.el).textContent='Informe data e horários válidos (término depois do início).';return}
    try{await DB.put('exceptions',{id:k,activityId:aid,date:od,type:'move',newDate:nd,start:st,end:en});m.close();toast('Ocorrência remarcada');render()}catch(e){fail(e)}}}}}

function editAct(a){
 const days=new Set(a?a.days:[new Date().getDay()]);
 const s=sheet(`<h3>${a?'Editar atividade':'Nova atividade'}</h3><label for='an'>Nome</label><input id='an' maxlength='120' value='${esc(a&&a.name)}'>
<label for='ad'>Descrição (opcional)</label><textarea id='ad' style='min-height:70px'>${esc(a&&a.description)}</textarea>
<label for='ac'>Categoria</label><select id='ac'><option value=''>Sem categoria</option>${S.cats.map(c=>`<option value='${esc(c.id)}' ${a&&a.categoryId===c.id?'selected':''}>${esc(c.name)}</option>`).join('')}</select>
<label for='ai'>Ícone</label><select id='ai'>${ICONS.map(i=>`<option ${(a?a.icon:'📌')===i?'selected':''}>${i}</option>`).join('')}</select>
<label for='aco'>Cor</label><input type='color' id='aco' value='${okColor(a&&a.color)}'>
<label for='as'>Início</label><input type='time' id='as' value='${a?a.start:'09:00'}'><label for='ae'>Término</label><input type='time' id='ae' value='${a?a.end:'10:00'}'>
<label>Dias da semana</label><div style='display:flex;gap:6px;flex-wrap:wrap'>${[1,2,3,4,5,6,0].map(d=>`<button class='chip' data-d='${d}' aria-pressed='${days.has(d)}'>${DN[d]}</button>`).join('')}</div>
<div style='display:flex;gap:6px;margin-top:8px;flex-wrap:wrap'><button class='chip' data-p='1,2,3,4,5,6,0'>Todos os dias</button><button class='chip' data-p='1,2,3,4,5'>Dias úteis</button><button class='chip' data-p='6,0'>Fim de semana</button></div>
<label for='ar'>Lembretes (minutos antes; 0 = no início)</label><input id='ar' value='${esc(a?(a.reminders||[]).join(', '):'10')}' placeholder='10, 0'>
<label for='anm'>Título do lembrete (opcional)</label><input id='anm' maxlength='80' value='${esc(a&&a.notifTitle)}'><label for='anb'>Mensagem do lembrete (opcional)</label><input id='anb' maxlength='160' value='${esc(a&&a.notifMsg)}'>
<label for='at'>Tarefa vinculada (opcional)</label><select id='at'><option value=''>Nenhuma</option></select>
<div class='sw'><label for='aa' style='margin:0'>Atividade ativa</label><input type='checkbox' id='aa' ${!a||a.active?'checked':''}></div>
<div class='err' id='ae2'></div><div class='acts' style='flex-wrap:wrap'>${a?`<button class='btn dan' id='ax'>Excluir</button><button class='btn sec' id='adu'>Duplicar</button>`:`<button class='btn sec' id='acn'>Cancelar</button>`}<button class='btn' id='asv'>Salvar</button></div>`);
 const el=s.el,chips=()=>el.querySelectorAll('[data-d]');
 DB.all('tasks').then(ts=>{$('#at',el).insertAdjacentHTML('beforeend',ts.filter(t=>t.status!=='done'||(a&&a.taskId===t.id)).map(t=>`<option value='${esc(t.id)}' ${a&&a.taskId===t.id?'selected':''}>${esc(t.title)}</option>`).join(''))}).catch(fail);
 chips().forEach(b=>b.onclick=()=>b.setAttribute('aria-pressed',b.getAttribute('aria-pressed')!=='true'));
 el.querySelectorAll('[data-p]').forEach(b=>b.onclick=()=>{const p=b.dataset.p.split(',');chips().forEach(c=>c.setAttribute('aria-pressed',p.includes(c.dataset.d)))});
 $('#ac',el).onchange=e=>{const c=S.cats.find(x=>x.id===e.target.value);if(c)$('#aco',el).value=okColor(c.color)};
 const read=()=>{const err=m=>{$('#ae2',el).textContent=m;return null};
  const name=$('#an',el).value.trim(),st=$('#as',el).value,en=$('#ae',el).value,dys=[...chips()].filter(c=>c.getAttribute('aria-pressed')==='true').map(c=>+c.dataset.d);
  if(!name)return err('Digite um nome para a atividade.');if(!st||!en)return err('Informe início e término.');if(toM(en)<=toM(st))return err('O término deve ser depois do início.');if(!dys.length)return err('Escolha ao menos um dia da semana.');
  const rem=[...new Set($('#ar',el).value.split(/[,;\s]+/).filter(Boolean).map(Number))];if(rem.some(n=>!Number.isInteger(n)||n<0||n>1440))return err('Lembretes: use minutos inteiros entre 0 e 1440.');
  $('#ae2',el).textContent='';return{name,description:$('#ad',el).value,categoryId:$('#ac',el).value||null,icon:$('#ai',el).value,color:okColor($('#aco',el).value),start:st,end:en,days:dys,active:$('#aa',el).checked,reminders:rem.sort((x,y)=>y-x),taskId:$('#at',el).value||null,notifTitle:$('#anm',el).value.trim(),notifMsg:$('#anb',el).value.trim()}};
 const put=async(o,msg)=>{try{await DB.put('activities',o);s.close();toast(msg);render();if((o.reminders||[]).length)Notify.ensure().then(()=>Notify.run()).catch(()=>{})}catch(e){$('#ae2',el).textContent='Falha ao salvar: '+e.message}};
 if(!a)$('#acn',el).onclick=s.close;else{
  $('#adu',el).onclick=()=>{const d=read();if(d){const ts=now();put({...d,id:uid(),name:d.name+' (cópia)',createdAt:ts,updatedAt:ts},'Atividade duplicada')}};
  $('#ax',el).onclick=()=>confirmBox('Excluir esta atividade e suas exceções? O histórico de conclusões é mantido.','Excluir',async()=>{for(const x of await DB.all('exceptions'))if(x.activityId===a.id)await DB.del('exceptions',x.id);await DB.del('activities',a.id);s.close();toast('Atividade excluída');render()})}
 $('#asv',el).onclick=()=>{const d=read();if(d){const ts=now();put({...(a||{id:uid(),createdAt:ts}),...d,updatedAt:ts},'Atividade salva')}}}

async function catsSheet(){const cats=await DB.all('categories');
 const s=sheet(`<h3>Categorias</h3>${cats.map(c=>`<div class='row' style='padding:6px 0'><input data-cn='${esc(c.id)}' value='${esc(c.name)}' maxlength='40' aria-label='Nome da categoria'><input type='color' data-cc='${esc(c.id)}' value='${okColor(c.color)}' style='width:60px;padding:4px' aria-label='Cor'><button class='btn sec xs' data-cd='${esc(c.id)}' aria-label='Excluir categoria'>✕</button></div>`).join('')||`<p class='sub'>Nenhuma categoria ainda.</p>`}<label for='cnn'>Nova categoria</label><input id='cnn' maxlength='40'><div class='err' id='ce'></div><div class='acts'><button class='btn' id='cad'>Adicionar</button><button class='btn sec' id='ccl'>Fechar</button></div>`),el=s.el;
 $('#ccl',el).onclick=s.close;
 $('#cad',el).onclick=async()=>{const n=$('#cnn',el).value.trim();if(!n){$('#ce',el).textContent='Digite um nome.';return}try{await DB.put('categories',{id:uid(),name:n,color:'#54D6E8'});s.close();render();catsSheet()}catch(e){fail(e)}};
 el.onchange=async e=>{const t=e.target,id=t.dataset.cn||t.dataset.cc,c=cats.find(x=>x.id===id);if(!c)return;try{if(t.dataset.cn){const v=t.value.trim();if(!v){t.value=c.name;return}c.name=v}else c.color=okColor(t.value);await DB.put('categories',c);toast('Categoria salva');render()}catch(x){fail(x)}};
 el.addEventListener('click',e=>{const b=e.target.closest('[data-cd]');if(!b)return;confirmBox('As atividades desta categoria ficarão sem categoria.','Excluir',async()=>{for(const x of await DB.all('activities'))if(x.categoryId===b.dataset.cd)await DB.put('activities',{...x,categoryId:null});await DB.del('categories',b.dataset.cd);s.close();render();catsSheet()})})}

async function histSheet(){const[c,a]=await Promise.all([DB.all('completions'),DB.all('activities')]),l=c.sort((x,y)=>y.doneAt.localeCompare(x.doneAt)).slice(0,50);
 const s=sheet(`<h3>Histórico</h3>${l.length?l.map(x=>{const ac=a.find(y=>y.id===x.activityId);return`<div class='g g-std row'><div class='t'><b>${ac?esc(ac.icon+' '+ac.name):'Atividade excluída'}</b><div class='m'>${pd(x.date).toLocaleDateString('pt-BR')} · registrada em ${fmt(x.doneAt)}</div></div></div>`}).join(''):empty('Sem histórico','Marque atividades como concluídas para vê-las aqui.')}<div class='acts'><button class='btn' id='hx'>Fechar</button></div>`);$('#hx',s.el).onclick=s.close}

function copyDay(){const sd=pd(S.rd).getDay();
 const s=sheet(`<h3>Copiar ${DL[sd]}</h3><p class='sub'>As atividades ativas de ${DL[sd]} passarão a se repetir também nos dias escolhidos (mesmos horários).</p><div style='display:flex;gap:6px;flex-wrap:wrap'>${[1,2,3,4,5,6,0].filter(d=>d!==sd).map(d=>`<button class='chip' data-d='${d}' aria-pressed='false'>${DN[d]}</button>`).join('')}</div><div class='err' id='cpe'></div><div class='acts'><button class='btn sec' id='cpc'>Cancelar</button><button class='btn' id='cpo'>Copiar</button></div>`),el=s.el;
 el.querySelectorAll('[data-d]').forEach(b=>b.onclick=()=>b.setAttribute('aria-pressed',b.getAttribute('aria-pressed')!=='true'));
 $('#cpc',el).onclick=s.close;
 $('#cpo',el).onclick=async()=>{const tg=[...el.querySelectorAll('[data-d][aria-pressed=true]')].map(b=>+b.dataset.d);if(!tg.length){$('#cpe',el).textContent='Escolha ao menos um dia.';return}
  try{let n=0;for(const a of await DB.all('activities'))if(a.active&&a.days.includes(sd)){await DB.put('activities',{...a,days:[...new Set([...a.days,...tg])],updatedAt:now()});n++}s.close();toast(n+' atividade(s) copiada(s)');render()}catch(e){fail(e)}}}

document.addEventListener('click',async e=>{try{const t=e.target;let b;
 if(t.closest('[data-newact]')){await loadR();return editAct(null)}
 if(t.closest('[data-cats]'))return catsSheet();
 if(t.closest('[data-hist]'))return histSheet();
 if(t.closest('[data-copyday]'))return copyDay();
 if(b=t.closest('[data-occ]'))return openOcc(b.dataset.occ);
 if(b=t.closest('[data-rv]')){S.rv=b.dataset.rv;document.querySelectorAll('[data-rv]').forEach(x=>x.setAttribute('aria-pressed',x===b));return fillRoutine()}
 if(b=t.closest('[data-rday]')){S.rd=b.dataset.rday;return fillRoutine()}
 if(b=t.closest('[data-rnav]')){const n=+b.dataset.rnav;if(n===0){S.ro=0;S.rd=today()}else{S.ro+=n;S.rd=addD(S.rd,7*n)}return fillRoutine()}
}catch(x){fail(x)}});

/* ===== Etapa 5: Notificações (adaptador Web + Android nativo via Capacitor) ===== */
const isNative=()=>{const c=window.Capacitor;return !!(c&&c.isNativePlatform&&c.isNativePlatform())};
const LN=()=>{const c=window.Capacitor;return c&&c.isNativePlatform&&c.isNativePlatform()&&c.Plugins&&c.Plugins.LocalNotifications};
const hash=s=>{let h=0;for(const c of s)h=(h*31+c.charCodeAt(0))|0;return Math.abs(h)%2147483000+1};
const Notify={fired:new Set(),last:Date.now(),init:false,tz:null,t:0,
 needsAsk(p){return p==='prompt'||p==='prompt-with-rationale'||p==='default'},
 async ensure(){if(this.mode()==='none'||!this.enabled())return;try{if(this.needsAsk(await this.perm()))await this.ask()}catch(e){console.warn(e)}},
 mode(){return LN()?'native':('Notification' in window)?'web':'none'},
 enabled(){return S.prefs.notif!==false},
 async perm(){const n=LN();if(n)return(await n.checkPermissions()).display;return 'Notification' in window?Notification.permission:'denied'},
 async ask(){const n=LN();if(n)return(await n.requestPermissions()).display;return 'Notification' in window?Notification.requestPermission():'denied'},
 msg(a,m){return{title:a.notifTitle||`${a.icon} ${a.name}`,body:a.notifMsg||(m>0?`${a.name} começa em ${m} min.`:`${a.name} começa agora.`)}},
 plan(R){const out=new Map();
  for(const a of R.acts){if(!a.active)continue;for(const m of a.reminders||[])for(const d of a.days){let mm=toM(a.start)-m,day=d;while(mm<0){mm+=1440;day=(day+6)%7}
   const id=hash(a.id+'|'+d+'|'+m);out.set(id,{id,wd:day+1,h:Math.floor(mm/60),mi:mm%60,...this.msg(a,m)})}}
  const all=[...out.values()];S.nover=all.length>400;return all.slice(0,400)},
 sync(){clearTimeout(this.t);this.t=setTimeout(()=>this.run().catch(fail),400)},
 run(){this.q=(this.q||Promise.resolve()).catch(()=>{}).then(()=>this._run());return this.q},
 async _run(){const n=LN();if(!n)return;
  const ok=this.enabled()&&(await this.perm())==='granted',want=ok?this.plan(await loadR()):[];
  const pend=(await n.getPending()).notifications;if(pend.length)await n.cancel({notifications:pend.map(x=>({id:x.id}))});
  if(want.length)await n.schedule({notifications:want.map(w=>({id:w.id,title:w.title,body:w.body,schedule:{on:{weekday:w.wd,hour:w.h,minute:w.mi},allowWhileIdle:true}}))});
  S.nsched=want.length;await DB.put('settings',{key:'notifSync',value:{tz:Intl.DateTimeFormat().resolvedOptions().timeZone,at:now(),count:want.length}})},
 show(m,tag){try{const r=navigator.serviceWorker&&navigator.serviceWorker.getRegistration?navigator.serviceWorker.getRegistration():Promise.resolve(null);
  r.then(g=>g?g.showNotification(m.title,{body:m.body,tag}):new Notification(m.title,{body:m.body,tag})).catch(()=>{try{new Notification(m.title,{body:m.body,tag})}catch(e){fail(e)}})}catch(e){fail(e)}},
 async test(){const p=await this.perm();if(p!=='granted')return toast('Permita as notificações primeiro.',true);
  const m={title:'🔔 NEXUS',body:'Notificação de teste funcionando.'},n=LN();
  if(n){await n.schedule({notifications:[{id:1,title:m.title,body:m.body,schedule:{at:new Date(Date.now()+5000),allowWhileIdle:true}}]});toast('Teste em 5 segundos (pode fechar o app).')}else{this.show(m,'teste');toast('Teste enviado.')}},
 async tick(){if(!DB.db)return;
  const tz=Intl.DateTimeFormat().resolvedOptions().timeZone;if(!this.init){this.init=true;this.tz=tz;this.run().catch(fail)}else if(this.tz!==tz){this.tz=tz;this.sync()}
  if(this.mode()!=='web'||!this.enabled()||await this.perm()!=='granted')return;
  const nowT=Date.now(),from=this.last;this.last=nowT;if(nowT-from>3600000)return;
  const R=await loadR();
  for(const off of[-1,0,1]){const date=addD(iso(new Date(nowT)),off),[y,mo,da]=date.split('-').map(Number),b0=new Date(y,mo-1,da).getTime();
   for(const o of occs(date,R)){if(o.st==='c'||o.st==='o')continue;
    for(const m of o.a.reminders||[]){const at=b0+toM(o.s)*60000-m*60000,key=o.k+'|'+m+'|'+date;
     if(at>from&&at<=nowT&&!this.fired.has(key)){this.fired.add(key);this.show(this.msg(o.a,m),key)}}}}}};
['put','del'].forEach(k=>{const f=DB[k].bind(DB);DB[k]=async(s,...a)=>{const r=await f(s,...a);if(s==='activities'||s==='exceptions')Notify.sync();return r}});
setInterval(()=>Notify.tick().catch(fail),15000);
document.addEventListener('visibilitychange',()=>{if(!document.hidden)Notify.tick().catch(fail)});
function notifBlock(){return`<h2 style='margin:18px 0 6px'>Notificações</h2><p class='sub' id='nst'>Verificando…</p><div class='sw'><label for='nen' style='margin:0'>Lembretes da rotina</label><input type='checkbox' id='nen' ${Notify.enabled()?'checked':''}></div><div class='acts'><button class='btn sec' data-nperm>Permitir</button><button class='btn sec' data-ntest>Testar</button><button class='btn sec' data-nsync>Reagendar</button></div>`}
async function notifStatus(){const el=$('#nst');if(!el)return;const p=await Notify.perm(),m=Notify.mode();
 el.textContent=(m==='native'?'Android nativo: agendamento semanal com o app fechado. O Android pode atrasar avisos com economia de bateria (sem alarme exato).':m==='web'?'Navegador: avisa somente com o app aberto. Para avisos com o app fechado, use o app Android (Capacitor). Exceções são respeitadas.':'Este ambiente não suporta notificações.')+' Permissão: '+p+'.'+(S.nsched!=null?' Agendadas: '+S.nsched+'.':'')+(S.nover?' Atenção: limite de 400 lembretes atingido; reduza lembretes ou dias.':'')}
document.addEventListener('click',async e=>{try{const t=e.target;
 if(t.closest('[data-nperm]')){const p=await Notify.ask();toast(p==='granted'?'Notificações permitidas':'Permissão: '+p,p!=='granted');await Notify.run();return notifStatus()}
 if(t.closest('[data-ntest]'))return Notify.test();
 if(t.closest('[data-nsync]')){await Notify.run();toast(Notify.mode()==='native'?'Agendamentos atualizados':'No navegador não há agendamento nativo.');notifStatus()}
}catch(x){fail(x)}});

/* ===== Etapa 6: Tamanho da interface, busca global e backup ===== */
const supZoom=()=>!!(window.CSS&&CSS.supports&&CSS.supports('zoom','1'));
function sizeBlock(){const v=S.prefs.ui||100;return`<h2 style='margin:18px 0 6px'>Tamanho</h2><label for='uis'>Tamanho da interface: <b id='uiv'>${v}%</b></label><input type='range' id='uis' min='80' max='140' step='5' value='${v}'><div class='acts'><button class='btn sec' data-uireset>Restaurar 100%</button></div>${supZoom()?'':`<p class='sub'>Este navegador não suporta o ajuste de tamanho.</p>`}`}
document.addEventListener('input',e=>{if(e.target.id==='uis'){S.prefs.ui=+e.target.value;$('#uiv').textContent=S.prefs.ui+'%';applyPrefs();clearTimeout(S._ut);S._ut=setTimeout(()=>savePrefs().catch(fail),300)}});

async function searchSheet(){
 const s=sheet(`<h3>Busca</h3><input id='sq' type='search' placeholder='Notas, tarefas, projetos, rotina, tags…' aria-label='Buscar' autocomplete='off'><div id='sr' style='margin-top:14px'><p class='sub'>Digite para buscar. Ignora maiúsculas e acentos.</p></div>`),out=$('#sr',s.el);
 out.addEventListener('click',()=>{S.curProj=null},true);
 $('#sq',s.el).oninput=async e=>{const q=norm(e.target.value.trim());if(!q){out.innerHTML=`<p class='sub'>Digite para buscar.</p>`;return}
  try{const[n,t,p,a]=await Promise.all(['notes','tasks','projects','activities'].map(k=>DB.all(k))),has=(...f)=>norm(f.join(' ')).includes(q),
   tags=[...new Set(n.flatMap(x=>x.tags||[]))].filter(x=>has(x)),
   G=[['Notas',n.filter(x=>has(x.title,x.body,(x.tags||[]).join(' '))),x=>`data-open='${esc(x.id)}'`,x=>esc(x.title)],
    ['Tarefas',t.filter(x=>has(x.title,x.description||'')),x=>`data-tedit='${esc(x.id)}'`,x=>esc(x.title)],
    ['Projetos',p.filter(x=>has(x.name,x.description||'')),x=>`data-proj='${esc(x.id)}'`,x=>esc(x.name)],
    ['Rotina',a.filter(x=>has(x.name,x.description||'')),x=>`data-act='${esc(x.id)}'`,x=>esc(x.icon+' '+x.name)],
    ['Tags',tags,x=>`data-tagf='${esc(x)}'`,x=>'#'+esc(x)]],
   html=G.filter(g=>g[1].length).map(([h,l,at,lb])=>`<h2>${h}</h2>`+l.slice(0,15).map(x=>`<div class='g g-std row' ${at(x)} style='cursor:pointer'><div class='t'><b>${lb(x)}</b></div></div>`).join('')).join('');
   out.innerHTML=html||`<p class='sub'>Nenhum resultado.</p>`}catch(x){fail(x)}}}

function backupBlock(){return`<h2 style='margin:18px 0 6px'>Backup</h2><p class='sub'>Notas, tarefas, projetos, rotina, categorias e configurações.</p><div class='acts'><button class='btn sec' data-bexp>Exportar</button><button class='btn sec' data-bimp>Importar</button></div>`}
async function buildBackup(){const data={};for(const k of Object.keys(DB.stores))data[k]=await DB.all(k);return{app:'nexus',schema:1,exportedAt:now(),version:VERSION,data}}
function validateBackup(o){
 if(!o||o.app!=='nexus'||typeof o.data!=='object'||o.data===null)throw new Error('O arquivo não é um backup do NEXUS.');
 if(!Number.isInteger(o.schema)||o.schema>1)throw new Error('Backup de versão mais nova ('+o.schema+') que este app.');
 const nm={notes:'title',tasks:'title',projects:'name',activities:'name'};
 for(const[k,key]of Object.entries(DB.stores)){const l=o.data[k];if(l===undefined)continue;if(!Array.isArray(l))throw new Error('Dados inválidos em '+k+'.');
  l.forEach(r=>{if(!r||typeof r!=='object'||typeof r[key]!=='string'||(nm[k]&&typeof r[nm[k]]!=='string'))throw new Error('Registro inválido em '+k+'.');
   if(k==='activities'&&!(Array.isArray(r.days)&&/^[0-9]{2}:[0-9]{2}$/.test(r.start)&&/^[0-9]{2}:[0-9]{2}$/.test(r.end)))throw new Error('Atividade inválida no backup.')})}
 return Object.keys(DB.stores).reduce((m,k)=>(m[k]=(o.data[k]||[]).length,m),{})}
function normAct(a){return{icon:'📌',color:'#54D6E8',active:true,reminders:[],...a,reminders:Array.isArray(a.reminders)?a.reminders.filter(n=>Number.isInteger(n)&&n>=0&&n<=1440):[],days:a.days.filter(d=>Number.isInteger(d)&&d>=0&&d<=6)}}
function restore(data){data={...data,activities:(data.activities||[]).map(normAct)};return new Promise((ok,no)=>{const names=Object.keys(DB.stores),t=DB.db.transaction(names,'readwrite');
 names.forEach(n=>{const o=t.objectStore(n);o.clear();(data[n]||[]).forEach(v=>o.put(v))});
 t.oncomplete=ok;t.onerror=()=>no(t.error);t.onabort=()=>no(t.error||new Error('Restauração abortada; nada foi alterado.'))})}
async function exportSheet(){const b=await buildBackup(),txt=JSON.stringify(b,null,1);
 const s=sheet(`<h3>Exportar backup</h3><p class='sub'>${Object.entries(b.data).map(([k,v])=>k+': '+v.length).join(' · ')}</p><textarea id='bt' readonly style='min-height:120px;font-size:12px'></textarea><div class='acts'><button class='btn' id='bdl'>Baixar arquivo</button><button class='btn sec' id='bcp'>Copiar</button></div><div class='acts'><button class='btn sec' id='bcl'>Fechar</button></div>`);
 $('#bt',s.el).value=txt;
 $('#bdl',s.el).onclick=async()=>{try{const nm='nexus-backup-'+today()+'.json',P=window.Capacitor&&window.Capacitor.Plugins;if(isNative()&&P&&P.Filesystem&&P.Share){const r=await P.Filesystem.writeFile({path:nm,data:txt,directory:'CACHE',encoding:'utf8'});await P.Share.share({title:'Backup NEXUS',files:[r.uri],dialogTitle:'Salvar backup'});return}const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([txt],{type:'application/json'}));a.download='nexus-backup-'+today()+'.json';document.body.appendChild(a);a.click();a.remove();toast('Download iniciado. Se nada baixar, use Copiar e salve num arquivo .json.')}catch(e){fail(e)}};
 $('#bcp',s.el).onclick=async()=>{try{await navigator.clipboard.writeText(txt);toast('Backup copiado')}catch{$('#bt',s.el).select();toast('Selecione e copie manualmente.',true)}};
 $('#bcl',s.el).onclick=s.close}
function importSheet(){
 const s=sheet(`<h3>Importar backup</h3><p class='sub'>Substitui todos os dados atuais. Exporte um backup antes.</p><input type='file' id='bf' accept='application/json,.json'><label for='bi'>Ou cole o conteúdo do backup</label><textarea id='bi' style='min-height:110px;font-size:12px'></textarea><div class='err' id='bie'></div><div class='acts'><button class='btn sec' id='bc'>Cancelar</button><button class='btn' id='bo'>Validar e importar</button></div>`),el=s.el;
 $('#bf',el).onchange=async e=>{const f=e.target.files[0];if(f)try{$('#bi',el).value=await f.text()}catch(x){$('#bie',el).textContent='Não foi possível ler o arquivo.'}};
 $('#bc',el).onclick=s.close;
 $('#bo',el).onclick=()=>{let o,c;
  try{o=JSON.parse($('#bi',el).value);c=validateBackup(o)}catch(x){$('#bie',el).textContent=x instanceof SyntaxError?'Arquivo inválido: não é JSON.':x.message;return}
  confirmBox('Substituir TODOS os dados atuais por: '+(Object.entries(c).filter(([,v])=>v).map(([k,v])=>k+' '+v).join(', ')||'dados vazios')+'?','Substituir',async()=>{await restore(o.data);s.close();await loadPrefs();Notify.run().catch(fail);await render();toast('Backup restaurado')})}}

document.addEventListener('click',async e=>{try{const t=e.target;let b;
 if(t.closest('[data-bexp]'))return exportSheet();
 if(t.closest('[data-bimp]'))return importSheet();
 if(t.closest('[data-uireset]')){S.prefs.ui=100;applyPrefs();$('#uis').value=100;$('#uiv').textContent='100%';return savePrefs()}
 if(b=t.closest('[data-act]')){const R=await loadR(),a=R.acts.find(x=>x.id===b.dataset.act);closeAll();return a&&editAct(a)}
 if(b=t.closest('[data-tagf]')){closeAll();S.ntag=b.dataset.tagf;S.nq='';return go('notes')}
}catch(x){fail(x)}});

/* ===== Canvas (estilo Obsidian): cartões de texto e notas, conexões, pan e zoom ===== */
const CVC=['#54D6E8','#169DFF','#9b7bff','#2fd08a','#ffb454','#ff6b81'];
async function canvasList(){
 const l=(await DB.all('canvases')).sort((a,b)=>b.updatedAt.localeCompare(a.updatedAt));
 const s=sheet(`<h3>Canvas</h3>${l.map(c=>`<div class='g g-std row'><button class='t nb' data-cvo='${esc(c.id)}'><b>${esc(c.name)}</b><div class='m'>${c.nodes.length} cartão(ões) · ${c.edges.length} conexão(ões)</div></button><button class='btn sec xs' data-cvd='${esc(c.id)}' aria-label='Excluir canvas'>Excluir</button></div>`).join('')||`<p class='sub'>Nenhum canvas ainda. Crie um quadro livre para organizar ideias.</p>`}<label for='cvn'>Novo canvas</label><input id='cvn' maxlength='80' placeholder='Ex.: Plano da semana'><div class='err' id='cve'></div><div class='acts'><button class='btn' id='cvc'>Criar</button><button class='btn sec' id='cvx'>Fechar</button></div>`);
 $('#cvx',s.el).onclick=s.close;
 $('#cvc',s.el).onclick=async()=>{const name=$('#cvn',s.el).value.trim();if(!name){$('#cve',s.el).textContent='Digite um nome para o canvas.';return}
  const ts=now(),c={id:uid(),name,nodes:[],edges:[],view:{x:0,y:0,z:1},createdAt:ts,updatedAt:ts};
  try{await DB.put('canvases',c);s.close();openCanvas(c.id)}catch(e){fail(e)}}}

document.addEventListener('click',async e=>{try{const t=e.target;let b;
 if(t.closest('[data-canvas]'))return canvasList();
 if(b=t.closest('[data-cvo]')){closeAll();return openCanvas(b.dataset.cvo)}
 if(b=t.closest('[data-cvd]')){const i=b.dataset.cvd;return confirmBox('Excluir este canvas? As notas não são afetadas.','Excluir',async()=>{await DB.del('canvases',i);closeAll();canvasList()})}
}catch(x){fail(x)}});

/* ===== Canvas v2: igual ao Obsidian (cartões, grupos, imagens, conexões, desfazer) ===== */
const CVCOL=['','#fb464c','#e9973f','#e0de71','#44cf6e','#53dfdd','#a882ff'];
const SD={t:[0,-1],b:[0,1],l:[-1,0],r:[1,0]};
const cvCol=c=>CVCOL.includes(c)?c:'';
function mdLite(src){return String(src||'').split('\n').map(l=>{
 const e=esc(l).replace(/`([^`]+)`/g,'<code>$1</code>').replace(/[*][*]([^*]+)[*][*]/g,'<b>$1</b>').replace(/[*]([^*]+)[*]/g,'<i>$1</i>').replace(LINK,(m,n)=>`<a data-cl='${n.trim()}'>${n.trim()}</a>`);let m;
 if(m=e.match(/^(#{1,3}) (.*)$/))return`<div style='font-weight:700;font-size:${22-m[1].length*3}px'>${m[2]}</div>`;
 if(m=e.match(/^ *[-*] \[( |x)\] (.*)$/))return`<div>${m[1]==='x'?'☑':'☐'} ${m[2]}</div>`;
 if(m=e.match(/^ *[-*] (.*)$/))return`<div>• ${m[1]}</div>`;
 if(m=e.match(/^ *([0-9]+)[.] (.*)$/))return`<div>${m[1]}. ${m[2]}</div>`;
 return`<div>${e||'&nbsp;'}</div>`}).join('')}
const compressImg=f=>new Promise((ok,no)=>{const u=URL.createObjectURL(f),im=new Image();
 im.onload=()=>{const k=Math.min(1,1600/Math.max(im.width,im.height)),q=document.createElement('canvas');q.width=Math.round(im.width*k);q.height=Math.round(im.height*k);q.getContext('2d').drawImage(im,0,0,q.width,q.height);
  let src=q.toDataURL('image/webp',.85);if(!src.startsWith('data:image/webp'))src=q.toDataURL('image/jpeg',.85);URL.revokeObjectURL(u);ok({src,w:q.width,h:q.height})};
 im.onerror=()=>{URL.revokeObjectURL(u);no(new Error('Não foi possível ler a imagem.'))};im.src=u});

const node0=(c,i)=>c.nodes.some(n=>n.id===i);
async function openCanvas(id){
 const c=await DB.get('canvases',id);if(!c)return;
 const NM=new Map((await DB.all('notes')).map(n=>[n.id,n]));
 c.nodes=(c.nodes||[]).filter(n=>n&&typeof n.id==='string');c.edges=(c.edges||[]).filter(e=>e&&typeof e.id==='string');
 const num=(x,d)=>Number.isFinite(+x)&&x!==null&&x!==''?+x:d;
 c.nodes.forEach(n=>{n.x=num(n.x,0);n.y=num(n.y,0);n.w=Math.max(40,num(n.w,260));n.h=Math.max(30,num(n.h,n.type==='group'?300:n.type==='image'?200:120));n.color=cvCol(n.color);if(!['text','note','image','group'].includes(n.type))n.type='text'});
 c.edges=c.edges.filter(e=>node0(c,e.from)&&node0(c,e.to));
 c.edges.forEach(e=>{if(!['t','b','l','r'].includes(e.fromSide))delete e.fromSide;if(!['t','b','l','r'].includes(e.toSide))delete e.toSide;if(!e.fromSide||!e.toSide){delete e.fromSide;delete e.toSide}});
 const v=c.view=c.view||{x:0,y:0,z:1};v.x=num(v.x,0);v.y=num(v.y,0);v.z=Math.min(2.5,Math.max(.2,num(v.z,1)));const node=i=>c.nodes.find(n=>n.id===i);
 c.edges.forEach(e=>{e.dir=['to','both','none'].includes(e.dir)?e.dir:'to';if(!e.fromSide){const a=node(e.from),b=node(e.to);if(a&&b){const dx=b.x+b.w/2-a.x-a.w/2,dy=b.y+b.h/2-a.y-a.h/2;if(Math.abs(dx)>Math.abs(dy)){e.fromSide=dx>0?'r':'l';e.toSide=dx>0?'l':'r'}else{e.fromSide=dy>0?'b':'t';e.toSide=dy>0?'t':'b'}}}});
 const sel=new Set(),EM={},H=[],RD=[];let selE=null,multi=false,tbm='main',st=0,lastTap={t:0,k:''};
 const ov=document.createElement('div');ov.className='cvov';
 ov.innerHTML=`<div class='cvp' id='cv'><div class='cww' id='cw'><div id='cg'></div><svg class='cvs'><g id='es'></g><path id='pv' fill='none' stroke='#54D6E8' stroke-width='3.2' stroke-linecap='round' stroke-dasharray='0.1 9'/></svg><div id='cn'></div></div><div id='bx'></div></div>
<div class='cvh g g-float'><button class='btn sec xs' data-a='back' aria-label='Voltar'>‹</button><button class='cvt nb' data-a='ren' style='color:var(--tx);font:600 16px var(--font);text-align:left'>${esc(c.name)}</button><button class='btn sec xs' data-a='undo' aria-label='Desfazer'>↶</button><button class='btn sec xs' data-a='redo' aria-label='Refazer'>↷</button></div>
<div class='cvz g g-float'><button class='btn sec xs' data-a='zi' aria-label='Aumentar zoom'>+</button><button class='btn sec xs' data-a='zo' aria-label='Diminuir zoom'>−</button><button class='btn sec xs' data-a='fit' aria-label='Ajustar à tela'>⤢</button></div>
<div id='cvf' class='g g-float'></div><div class='cvb g g-float' id='cvb'></div><input type='file' id='cvi' accept='image/*' multiple style='display:none'>`;
 document.body.appendChild(ov);
 const cv=$('#cv',ov),elOf=i=>ov.querySelector(`[data-n='${i}']`);
 const snap=()=>({n:c.nodes.map(x=>({...x})),e:c.edges.map(x=>({...x}))});
 const hist=()=>{H.push(snap());if(H.length>60)H.shift();RD.length=0};
 const flush=async()=>{c.updatedAt=now();try{await DB.put('canvases',c)}catch(x){fail(x)}};
 const save=()=>{clearTimeout(st);st=setTimeout(flush,400)};
 const load=s=>{c.nodes=s.n;c.edges=s.e;sel.clear();selE=null;render()};
 const undo=()=>{if(!H.length)return toast('Nada para desfazer.');RD.push(snap());load(H.pop());save()};
 const redo=()=>{if(!RD.length)return toast('Nada para refazer.');H.push(snap());load(RD.pop());save()};
 const anc=(n,s)=>s==='t'?[n.x+n.w/2,n.y]:s==='b'?[n.x+n.w/2,n.y+n.h]:s==='l'?[n.x,n.y+n.h/2]:[n.x+n.w,n.y+n.h/2];
 const nearSide=(n,px,py)=>{const dx=(px-(n.x+n.w/2))/n.w,dy=(py-(n.y+n.h/2))/n.h;return Math.abs(dx)>Math.abs(dy)?(dx>0?'r':'l'):(dy>0?'b':'t')};
 const bbox=ids=>{const l=ids.map(node).filter(Boolean);if(!l.length)return null;const x0=Math.min(...l.map(n=>n.x)),y0=Math.min(...l.map(n=>n.y));return{x:x0,y:y0,w:Math.max(...l.map(n=>n.x+n.w))-x0,h:Math.max(...l.map(n=>n.y+n.h))-y0}};
 const ctr=()=>{const r=cv.getBoundingClientRect();return[(r.width/2-v.x)/v.z,(r.height/2-v.y)/v.z]};
 const wpt=e=>{const r=cv.getBoundingClientRect();return[(e.clientX-r.left-v.x)/v.z,(e.clientY-r.top-v.y)/v.z]};
 const place=()=>{const f=$('#cvf',ov);let b=null;if(selE&&EM[selE])b={x:EM[selE][0],y:EM[selE][1],w:0,h:0};else if(sel.size)b=bbox([...sel]);
  if(!b){f.style.display='none';return}f.style.display='flex';
  const sx=v.x+b.x*v.z,sy=v.y+b.y*v.z,sw=b.w*v.z,sh=b.h*v.z,fw=f.offsetWidth,ty=sy-58<70?sy+sh+12:sy-58;
  f.style.left=Math.min(Math.max(8,sx+sw/2-fw/2),ov.clientWidth-fw-8)+'px';f.style.top=Math.max(70,Math.min(ty,ov.clientHeight-150))+'px'};
 const draw=()=>{$('#cw',ov).style.transform=`translate(${v.x}px,${v.y}px) scale(${v.z})`;cv.style.backgroundPosition=`${v.x}px ${v.y}px`;cv.style.backgroundSize=`${24*v.z}px ${24*v.z}px`;place()};
 const zoomAt=(mx,my,z)=>{z=Math.min(2.5,Math.max(.2,z));const wx=(mx-v.x)/v.z,wy=(my-v.y)/v.z;v.x=mx-wx*z;v.y=my-wy*z;v.z=z;draw()};
 const fitTo=b=>{const r=cv.getBoundingClientRect();if(!b){v.x=0;v.y=0;v.z=1}else{const z=Math.min(1.5,Math.max(.2,Math.min((r.width-60)/Math.max(b.w,1),(r.height-220)/Math.max(b.h,1))));v.z=z;v.x=(r.width-b.w*z)/2-b.x*z;v.y=(r.height-b.h*z)/2-b.y*z+20}draw();save()};
 const edges=()=>{$('#es',ov).innerHTML=c.edges.map(e=>{const a=node(e.from),b=node(e.to);if(!a||!b)return'';
   const p1=anc(a,e.fromSide),p2=anc(b,e.toSide),d1=SD[e.fromSide],d2=SD[e.toSide],on=e.id===selE,
   dist=Math.hypot(p2[0]-p1[0],p2[1]-p1[1]),k=Math.min(220,Math.max(50,dist*.45)),
   base=cvCol(e.color)||'',c0=on?'#ffffff':(base||(document.documentElement.dataset.theme==='min'?'#8a8a8a':'#54D6E8')),c9=on?'#9be9f4':(base||(document.documentElement.dataset.theme==='min'?'#8a8a8a':'#169DFF')),
   s0=e.dir==='both'?11:0,s1=e.dir==='none'?0:11,
   q1=[p1[0]+d1[0]*s0,p1[1]+d1[1]*s0],q2=[p2[0]+d2[0]*s1,p2[1]+d2[1]*s1],
   c1=[p1[0]+d1[0]*k,p1[1]+d1[1]*k],c2=[p2[0]+d2[0]*k,p2[1]+d2[1]*k],
   d=`M${q1}C${c1} ${c2} ${q2}`,gid='g'+String(e.id).replace(/[^a-z0-9]/gi,''),
   tri=(p,n,col)=>{const px=-n[1],py=n[0],L=12.5,Wd=6.5;return`<path d='M${p[0]+n[0]*1.5},${p[1]+n[1]*1.5}L${p[0]+n[0]*L+px*Wd},${p[1]+n[1]*L+py*Wd}L${p[0]+n[0]*L-px*Wd},${p[1]+n[1]*L-py*Wd}Z' fill='${col}' stroke='${col}' stroke-width='2.5' stroke-linejoin='round'/>`},
   dot=(p,col)=>`<circle cx='${p[0]}' cy='${p[1]}' r='3.4' fill='#0b1620' stroke='${col}' stroke-width='2'/>`,
   mx=(p1[0]+3*c1[0]+3*c2[0]+p2[0])/8,my=(p1[1]+3*c1[1]+3*c2[1]+p2[1])/8;EM[e.id]=[mx,my];
   const lb=e.label?(e.label.length>28?e.label.slice(0,27)+'…':e.label):'',lw=Math.min(230,lb.length*7.4+24);
   return`<g><defs><linearGradient id='${gid}' gradientUnits='userSpaceOnUse' x1='${p1[0]}' y1='${p1[1]}' x2='${p2[0]}' y2='${p2[1]}'><stop offset='0' stop-color='${c0}'/><stop offset='1' stop-color='${c9}'/></linearGradient></defs>`
   +`<path d='${d}' fill='none' stroke='url(#${gid})' stroke-width='${on?11:8}' stroke-linecap='round' opacity='${on?.3:.13}'/>`
   +`<path d='${d}' fill='none' stroke='url(#${gid})' stroke-width='${on?3.6:2.6}' stroke-linecap='round'/>`
   +(on?`<path d='${d}' fill='none' stroke='#fff' stroke-width='1.6' stroke-linecap='round' stroke-dasharray='2 12' style='animation:cvflow 1s linear infinite'/>`:'')
   +(e.dir==='both'?tri(p1,d1,c0):dot(p1,c0))+(e.dir==='none'?dot(p2,c9):tri(p2,d2,c9))
   +(lb?`<rect x='${mx-lw/2}' y='${my-13}' width='${lw}' height='26' rx='13' fill='rgba(11,22,32,.95)' stroke='${on?'#fff':c9}' stroke-width='1.4' data-e='${esc(e.id)}'/><text x='${mx}' y='${my}' fill='#E9F3FA' font-size='13' font-weight='600' text-anchor='middle' dominant-baseline='central' style='pointer-events:none'>${esc(lb)}</text>`:'')
   +`<path d='${d}' fill='none' stroke='transparent' stroke-width='30' data-e='${esc(e.id)}' style='pointer-events:stroke'/></g>`}).join('')};
 const nodeEl=n=>{const s=sel.has(n.id),one=s&&sel.size===1&&!selE;let inner;
  if(n.type==='group')inner=`<div class='cgl'>${esc(n.label||'')}</div>`;
  else if(n.type==='image')inner=n.src&&n.src.startsWith('data:image/')&&!/['<>" ]/.test(n.src)?`<img src='${n.src}' draggable='false' alt=''>`:`<i>Imagem inválida</i>`;
  else if(n.type==='note'){const nt=NM.get(n.noteId);inner=nt?`<div class='cmd'><div style='font-weight:700;font-size:19px'>📝 ${esc(nt.title)}</div>${mdLite((nt.body||'').slice(0,1200))}</div>`:`<div class='cmd'><i>Nota removida</i></div>`}
  else inner=`<div class='cmd'>${n.text?mdLite(n.text):`<i style='opacity:.5'>Toque duas vezes para editar</i>`}</div>`;
  const hd=one?['t','r','b','l'].map(k=>`<i class='hs hs-${k}' data-h='${k}'></i>`).join('')+['nw','ne','sw','se'].map(k=>`<i class='hr hr-${k}' data-r='${k}'></i>`).join(''):'';
  return`<div class='cn cn-${n.type}${s?' sel':''}' data-n='${esc(n.id)}' style='left:${n.x}px;top:${n.y}px;width:${n.w}px;height:${n.h}px;--c:${cvCol(n.color)||'#7f93a8'}'><div class='ci'>${inner}</div>${hd}</div>`};
 const bt=(a,l,cls)=>`<button class='btn ${cls||'sec'} xs' data-a='${a}'>${l}</button>`;
 const bar=()=>{const f=$('#cvf',ov);
  if(tbm==='color'&&(sel.size||selE))f.innerHTML=CVCOL.map(k=>`<button class='sw2' data-col='${k}' aria-label='Cor' style='background:${k||'#7f93a8'}'></button>`).join('')+bt('cx','✕');
  else if(selE)f.innerHTML=bt('col','Cor')+bt('elab','Rótulo')+bt('edir','Direção')+bt('edel','Excluir','dan');
  else if(sel.size){const one=sel.size===1&&node([...sel][0]);f.innerHTML=bt('col','Cor')+(one?bt('zs','Zoom')+(one.type==='image'?'':bt('edit','Editar')):'')+bt('del','Excluir','dan')}
  place()};
 const pal=()=>{$('#cvb',ov).innerHTML=bt('addt','Texto','')+bt('addn','Nota','')+bt('addi','Imagem','')+bt('addg','Grupo','')+bt('multi','Multi',multi?'':'sec')};
 const render=()=>{$('#cg',ov).innerHTML=c.nodes.filter(n=>n.type==='group').map(nodeEl).join('');$('#cn',ov).innerHTML=c.nodes.filter(n=>n.type!=='group').map(nodeEl).join('');edges();bar()};
 const ask=(t,val,cb)=>{const s=sheet(`<h3>${t}</h3><input id='ak' maxlength='80'><div class='acts'><button class='btn sec' id='akc'>Cancelar</button><button class='btn' id='aks'>Salvar</button></div>`);$('#ak',s.el).value=val||'';$('#akc',s.el).onclick=s.close;$('#aks',s.el).onclick=()=>{cb($('#ak',s.el).value.trim());s.close()}};
 const editNode=n=>{if(!n)return;if(n.type==='note')return openNote(n.noteId);
  if(n.type==='group')return ask('Rótulo do grupo',n.label,t=>{hist();n.label=t;render();save()});
  if(n.type!=='text')return;
  const el=elOf(n.id);if(!el)return;const ci=el.querySelector('.ci'),ta=document.createElement('textarea');ta.className='cta';ta.value=n.text||'';ci.replaceChildren(ta);ta.focus();
  let done=false;const fin=()=>{if(done)return;done=true;if(ta.value!==(n.text||'')){hist();n.text=ta.value;save()}render()};
  ta.addEventListener('blur',fin);ta.addEventListener('keydown',ev=>{if(ev.key==='Escape')ta.blur()})};
 const addNode=(o,at)=>{const d={text:[260,120],note:[300,200],group:[420,300],image:[300,200]}[o.type],[x,y]=at||ctr(),n={id:uid(),w:d[0],h:d[1],color:'',text:'',...o};
  n.x=Math.round(x-n.w/2);n.y=Math.round(y-n.h/2);hist();c.nodes.push(n);sel.clear();sel.add(n.id);selE=null;tbm='main';render();save();if(n.type==='text')setTimeout(()=>editNode(n),40);return n};
 const pick=()=>{const l=[...NM.values()].sort((a,b)=>b.updatedAt.localeCompare(a.updatedAt)).slice(0,80);if(!l.length)return toast('Crie uma nota primeiro.',true);
  const s=sheet(`<h3>Adicionar nota</h3>${l.map(n=>`<div class='g g-std row' data-pn='${esc(n.id)}' style='cursor:pointer'><div class='t'><b>${esc(n.title)}</b></div></div>`).join('')}`);
  s.el.addEventListener('click',e=>{const b=e.target.closest('[data-pn]');if(b){s.close();addNode({type:'note',noteId:b.dataset.pn})}})};
 const addImgs=async files=>{let i=0;for(const f of files){if(!f.type.startsWith('image/'))continue;if(f.size>25e6){toast('Imagem acima de 25 MB ignorada.',true);continue}
  try{const r=await compressImg(f),[cx,cy]=ctr(),w=Math.min(320,r.w);addNode({type:'image',src:r.src,w,h:Math.round(w*r.h/r.w)},[cx+i*30,cy+i*30]);i++}catch(x){fail(x)}}};
 const delSel=()=>{hist();if(selE){c.edges=c.edges.filter(x=>x.id!==selE);selE=null}else{c.nodes=c.nodes.filter(n=>!sel.has(n.id));c.edges=c.edges.filter(x=>!sel.has(x.from)&&!sel.has(x.to));sel.clear()}render();save();toast('Excluído. Toque em ↶ para desfazer.')};
 const prepMove=d=>{const n=d.n,ids=new Set(sel.has(n.id)?sel:[n.id]);if(n.type==='group')c.nodes.forEach(m=>{const mx=m.x+m.w/2,my=m.y+m.h/2;if(m.type!=='group'&&mx>n.x&&mx<n.x+n.w&&my>n.y&&my<n.y+n.h)ids.add(m.id)});d.o=new Map([...ids].map(i=>[i,[node(i).x,node(i).y]]))};
 const finishConn=(d,e,w)=>{const el=document.elementsFromPoint(e.clientX,e.clientY).find(x=>x.dataset&&x.dataset.n&&x.dataset.n!==d.n.id),tid=el&&el.dataset.n,opp={t:'b',b:'t',l:'r',r:'l'};
  if(tid){hist();c.edges.push({id:uid(),from:d.n.id,fromSide:d.side,to:tid,toSide:nearSide(node(tid),w[0],w[1]),dir:'to'})}
  else{const n=addNode({type:'text'},[w[0]+(d.side==='r'?130:d.side==='l'?-130:0),w[1]+(d.side==='b'?60:d.side==='t'?-60:0)]);c.edges.push({id:uid(),from:d.n.id,fromSide:d.side,to:n.id,toSide:opp[d.side],dir:'to'})}
  save();render()};
 const tap=(d,e,w)=>{const T=d.T,ts=Date.now(),cl=T.closest&&T.closest('[data-cl]');if(cl)return openLink(cl.dataset.cl);
  const ed=T.closest('[data-e]'),nd=T.closest('[data-n]'),key=ed?'e'+ed.dataset.e:nd?nd.dataset.n:'bg',dbl=lastTap.k===key&&ts-lastTap.t<350;lastTap={t:ts,k:key};
  if(ed){sel.clear();selE=ed.dataset.e}
  else if(nd){const i=nd.dataset.n;if(multi||e.shiftKey){sel.has(i)?sel.delete(i):sel.add(i)}else{sel.clear();sel.add(i)}selE=null;if(dbl){render();return editNode(node(i))}}
  else{if(dbl&&!multi)return addNode({type:'text'},w);sel.clear();selE=null}
  tbm='main';render()};
 const P=new Map();let drag=null,pinch=null;
 cv.addEventListener('pointerdown',e=>{if(e.target.closest('textarea,input'))return;try{cv.setPointerCapture(e.pointerId)}catch{}
  P.set(e.pointerId,[e.clientX,e.clientY]);
  if(P.size===2){const[a,b]=[...P.values()];pinch={d:Math.hypot(a[0]-b[0],a[1]-b[1])||1,z:v.z};drag=null;return}
  const T=e.target,h=T.closest('[data-h]'),r=T.closest('[data-r]'),nd=T.closest('[data-n]'),d={sx:e.clientX,sy:e.clientY,moved:false,T};
  if(h)Object.assign(d,{t:'conn',n:node(h.closest('[data-n]').dataset.n),side:h.dataset.h});
  else if(r){const n=node(r.closest('[data-n]').dataset.n);Object.assign(d,{t:'rs',n,k:r.dataset.r,o:{x:n.x,y:n.y,w:n.w,h:n.h}})}
  else if(nd){const n=node(nd.dataset.n);if(!sel.has(n.id)&&!multi&&!e.shiftKey){sel.clear();sel.add(n.id);selE=null}Object.assign(d,{t:'mv',n})}
  else Object.assign(d,{t:multi?'box':'pan',ox:v.x,oy:v.y});
  drag=d});
 cv.addEventListener('pointermove',e=>{if(!P.has(e.pointerId))return;P.set(e.pointerId,[e.clientX,e.clientY]);
  if(pinch&&P.size===2){const[a,b]=[...P.values()],r=cv.getBoundingClientRect();zoomAt((a[0]+b[0])/2-r.left,(a[1]+b[1])/2-r.top,pinch.z*Math.hypot(a[0]-b[0],a[1]-b[1])/pinch.d);save();return}
  if(!drag)return;const dx=e.clientX-drag.sx,dy=e.clientY-drag.sy;
  if(!drag.moved){if(Math.abs(dx)+Math.abs(dy)<7)return;drag.moved=true;if(drag.t==='mv'||drag.t==='rs')hist();if(drag.t==='mv')prepMove(drag)}
  const w=wpt(e);
  if(drag.t==='pan'){v.x=drag.ox+dx;v.y=drag.oy+dy;draw()}
  else if(drag.t==='mv'){drag.o.forEach(([ox,oy],i)=>{const n=node(i),el=elOf(i);n.x=Math.round(ox+dx/v.z);n.y=Math.round(oy+dy/v.z);if(el){el.style.left=n.x+'px';el.style.top=n.y+'px'}});edges();place()}
  else if(drag.t==='rs'){const o=drag.o,n=drag.n,k=drag.k,ddx=dx/v.z,ddy=dy/v.z;let nw=o.w,nh=o.h;
   if(k.includes('e'))nw=o.w+ddx;if(k.includes('w'))nw=o.w-ddx;if(k.includes('s'))nh=o.h+ddy;if(k.includes('n'))nh=o.h-ddy;
   nw=Math.max(60,nw);nh=n.type==='image'?nw*o.h/o.w:Math.max(40,nh);
   n.w=Math.round(nw);n.h=Math.round(nh);n.x=Math.round(k.includes('w')?o.x+o.w-nw:o.x);n.y=Math.round(k.includes('n')?o.y+o.h-nh:o.y);
   const el=elOf(n.id);Object.assign(el.style,{left:n.x+'px',top:n.y+'px',width:n.w+'px',height:n.h+'px'});edges();place()}
  else if(drag.t==='conn'){const a=anc(drag.n,drag.side);$('#pv',ov).setAttribute('d',`M${a}L${w}`);ov.querySelectorAll('.cn.tg').forEach(x=>x.classList.remove('tg'));
   const el=document.elementsFromPoint(e.clientX,e.clientY).find(x=>x.classList&&x.classList.contains('cn')&&x.dataset.n!==drag.n.id);if(el)el.classList.add('tg')}
  else if(drag.t==='box'){const r=cv.getBoundingClientRect(),b=$('#bx',ov);Object.assign(b.style,{display:'block',left:Math.min(drag.sx,e.clientX)-r.left+'px',top:Math.min(drag.sy,e.clientY)-r.top+'px',width:Math.abs(dx)+'px',height:Math.abs(dy)+'px'})}});
 const up=e=>{const was=P.has(e.pointerId);P.delete(e.pointerId);if(P.size<2)pinch=null;if(!was)return;const d=drag;if(!P.size)drag=null;if(!d)return;
  if(e.type==='pointercancel'){render();return}
  const w=wpt(e);
  if(d.moved){
   if(d.t==='pan'){save();return}
   if(d.t==='conn'){$('#pv',ov).setAttribute('d','');ov.querySelectorAll('.cn.tg').forEach(x=>x.classList.remove('tg'));finishConn(d,e,w);return}
   if(d.t==='box'){$('#bx',ov).style.display='none';const r=cv.getBoundingClientRect(),x1=(Math.min(d.sx,e.clientX)-r.left-v.x)/v.z,x2=(Math.max(d.sx,e.clientX)-r.left-v.x)/v.z,y1=(Math.min(d.sy,e.clientY)-r.top-v.y)/v.z,y2=(Math.max(d.sy,e.clientY)-r.top-v.y)/v.z;
    sel.clear();c.nodes.forEach(n=>{const inside=n.x>=x1&&n.y>=y1&&n.x+n.w<=x2&&n.y+n.h<=y2,hit=n.x<x2&&n.x+n.w>x1&&n.y<y2&&n.y+n.h>y1;if(n.type==='group'?inside:hit)sel.add(n.id)});selE=null;render();return}
   save();render();return}
  tap(d,e,w)};
 cv.addEventListener('pointerup',up);cv.addEventListener('pointercancel',up);
 cv.addEventListener('wheel',e=>{e.preventDefault();const r=cv.getBoundingClientRect();zoomAt(e.clientX-r.left,e.clientY-r.top,v.z*(e.deltaY<0?1.1:.9));save()},{passive:false});
 cv.addEventListener('dragover',e=>e.preventDefault());cv.addEventListener('drop',e=>{e.preventDefault();addImgs([...e.dataTransfer.files])});
 const onPaste=e=>{if(e.target.closest&&e.target.closest('textarea,input'))return;const fs=[...(e.clipboardData?e.clipboardData.files:[])];if(fs.length){e.preventDefault();addImgs(fs)}};
 const kd=e=>{if(e.target.closest&&e.target.closest('textarea,input'))return;const k=e.key.toLowerCase();
  if((e.key==='Delete'||e.key==='Backspace')&&(sel.size||selE)){e.preventDefault();delSel()}
  else if((e.ctrlKey||e.metaKey)&&k==='z'){e.preventDefault();e.shiftKey?redo():undo()}
  else if((e.ctrlKey||e.metaKey)&&k==='y'){e.preventDefault();redo()}};
 document.addEventListener('paste',onPaste);document.addEventListener('keydown',kd);
 $('#cvi',ov).onchange=async e=>{const fs=[...e.target.files];e.target.value='';await addImgs(fs)};
 ov.addEventListener('click',async e=>{const col=e.target.closest('[data-col]'),b=e.target.closest('[data-a]');
  try{if(col){hist();const k=col.dataset.col;if(selE){const x=c.edges.find(y=>y.id===selE);x.color=k}else c.nodes.forEach(n=>{if(sel.has(n.id))n.color=k});tbm='main';render();save();return}
  if(!b)return;const a=b.dataset.a;
  if(a==='back'){clearTimeout(st);await flush();document.removeEventListener('paste',onPaste);document.removeEventListener('keydown',kd);ov.remove();return render_main()}
  if(a==='undo')undo();else if(a==='redo')redo();
  else if(a==='zi'||a==='zo'){const r=cv.getBoundingClientRect();zoomAt(r.width/2,r.height/2,v.z*(a==='zi'?1.25:.8));save()}
  else if(a==='fit')fitTo(bbox(c.nodes.map(n=>n.id)));
  else if(a==='zs')fitTo(bbox([...sel]));
  else if(a==='ren')ask('Renomear canvas',c.name,t=>{if(t){c.name=t;b.textContent=t;save()}});
  else if(a==='addt')addNode({type:'text'});else if(a==='addn')pick();else if(a==='addg')addNode({type:'group',label:'Grupo'});
  else if(a==='addi')$('#cvi',ov).click();
  else if(a==='multi'){multi=!multi;pal();toast(multi?'Multi: toque para selecionar vários; arraste no vazio para caixa de seleção.':'Multi desligado.')}
  else if(a==='col'){tbm='color';bar()}else if(a==='cx'){tbm='main';bar()}
  else if(a==='edit')editNode(node([...sel][0]));
  else if(a==='del'||a==='edel')delSel();
  else if(a==='elab'){const x=c.edges.find(y=>y.id===selE);ask('Rótulo da conexão',x.label,t=>{hist();x.label=t;render();save()})}
  else if(a==='edir'){const x=c.edges.find(y=>y.id===selE);hist();x.dir=x.dir==='to'?'both':x.dir==='both'?'none':'to';render();save()}}catch(x){fail(x)}});
 pal();draw();render()}
const render_main=()=>render();

function themeBlock(){const t=S.prefs.theme||'min';return`<label>Tema</label><div class='seg' role='group'>${seg('th',t,[['min','Minimalista'],['glass','Glass (Aero)']])}</div>`}
document.addEventListener('click',async e=>{try{const b=e.target.closest('[data-th]');if(!b)return;S.prefs.theme=b.dataset.th;applyPrefs();document.querySelectorAll('[data-th]').forEach(x=>x.setAttribute('aria-pressed',x===b));await savePrefs();render()}catch(x){fail(x)}});

/* ===== Nativo (Capacitor): botão voltar do Android ===== */
function backAction(){
 const cvov=document.querySelector(".cvov"),ovs=[...document.querySelectorAll(".ov")];
 if(ovs.length){const o=ovs[ovs.length-1];o._close?o._close():o.remove();return true}
 if(cvov){const b=cvov.querySelector("[data-a=back]");b&&b.click();return true}
 if(S.tab!=="home"){go("home");return true}
 return false}
(()=>{const P=window.Capacitor&&window.Capacitor.Plugins,A=P&&P.App;
 if(isNative()&&A&&A.addListener)A.addListener("backButton",()=>{if(!backAction())A.exitApp()})})();

/* Service worker só no navegador (no app nativo os arquivos já vêm no pacote e o cache causaria versão antiga após atualizar) */
if("serviceWorker" in navigator&&location.protocol.startsWith("http")&&!isNative())navigator.serviceWorker.register("sw.js").catch(e=>console.warn("SW:",e));
/* ===== Boot ===== */
(async()=>{
 $("#nav").innerHTML=TABS.map(([k,l])=>`<button data-t="${k}">${svg(k)}${l}</button>`).join("");
 $("#nav").onclick=e=>{const b=e.target.closest("[data-t]");b&&go(b.dataset.t)};
 $("#fab").onclick=quickCreate;$("#bSearch").onclick=searchSheet;$("#bSet").onclick=()=>settingsSheet().catch(fail);
 applyPrefs();
 try{await DB.open();await loadPrefs();go("home");Notify.tick().catch(fail);
  setInterval(()=>{const c=$("#clock");if(c)c.textContent=timeStr()},30000);
  if(navigator.storage&&navigator.storage.persist)navigator.storage.persist().catch(()=>{})}
 catch(e){$("#view").innerHTML=empty("Banco de dados indisponível",e.message+" Verifique se o navegador permite armazenamento local (fora de modo privado).")}
})();
