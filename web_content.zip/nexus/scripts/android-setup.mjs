// Cria/atualiza o projeto Android a partir de www/ + android-assets/.  Uso: npm run android:setup
// Idempotente: pode rodar quantas vezes quiser (ex.: após trocar ícones ou versão do Capacitor).
import { existsSync, readFileSync, writeFileSync, cpSync, readdirSync, rmSync, statSync, mkdirSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..');
const A = join(ROOT, 'android');
const run = (cmd, args) => {
  const r = spawnSync(cmd, args, { cwd: ROOT, stdio: 'inherit', shell: process.platform === 'win32' });
  if (r.status !== 0) { console.error(`\n✖ Falhou: ${cmd} ${args.join(' ')}`); process.exit(r.status || 1); }
};
const log = (m) => console.log('• ' + m);

if (!existsSync(join(ROOT, 'node_modules', '@capacitor', 'android'))) run('npm', ['install']);
if (!existsSync(A)) { log('Criando projeto Android (cap add android)…'); run('npx', ['cap', 'add', 'android']); }

// 1) Recursos: ícones adaptativos, ícone de notificação, splash próprio (sem logo do Capacitor)
const RES = join(A, 'app', 'src', 'main', 'res');
for (const d of readdirSync(RES)) {
  if (!d.startsWith('drawable')) continue;
  const f = join(RES, d, 'splash.png');
  if (existsSync(f)) rmSync(f);
}
cpSync(join(ROOT, 'android-assets', 'res'), RES, { recursive: true });
log('Ícones, splash e ícone de notificação copiados.');

// 2) AndroidManifest: permissão de notificações (Android 13+) e reagendamento após reboot
const MF = join(A, 'app', 'src', 'main', 'AndroidManifest.xml');
let mf = readFileSync(MF, 'utf8');
const need = ['android.permission.POST_NOTIFICATIONS', 'android.permission.RECEIVE_BOOT_COMPLETED'];
let changed = false;
for (const p of need) {
  if (!mf.includes(p)) { mf = mf.replace('</manifest>', `    <uses-permission android:name="${p}" />\n</manifest>`); changed = true; }
}
// NÃO adicionar SCHEDULE_EXACT_ALARM / USE_EXACT_ALARM: exigem justificativa na Play Console e o app não precisa.
if (changed) writeFileSync(MF, mf);
log('AndroidManifest.xml verificado.');

// 3) Assinatura + versão (lidas de keystore.properties e release.json)
const G = join(A, 'app', 'build.gradle');
cpSync(join(ROOT, 'android-assets', 'signing.gradle'), join(A, 'app', 'signing.gradle'));
let g = readFileSync(G, 'utf8');
if (!g.includes("apply from: 'signing.gradle'")) { g += "\napply from: 'signing.gradle'\n"; writeFileSync(G, g); }
log('Assinatura/versão ligadas ao build.gradle (release.json + keystore.properties).');

// 4) Confere targetSdk (a Play exige >= 36 para apps novos/atualizações desde 31/08/2026)
const VG = join(A, 'variables.gradle');
if (existsSync(VG)) {
  const m = /targetSdkVersion\s*=\s*(\d+)/.exec(readFileSync(VG, 'utf8'));
  if (m && +m[1] < 36) console.warn(`⚠ targetSdkVersion=${m[1]} (<36). Atualize @capacitor/android para ^8 e rode "npm install".`);
  else if (m) log(`targetSdkVersion=${m[1]} OK.`);
}

run('npx', ['cap', 'sync', 'android']);
console.log('\n✔ Pronto. Próximos passos: "npm run android:keystore" (uma vez) e "npm run android:aab".');
