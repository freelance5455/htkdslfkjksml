// Cria a chave de UPLOAD (use com "Play App Signing" ligado — padrão da Play Console).
// Uso: npm run android:keystore   (opcional: KS_PASSWORD=... KS_DNAME="CN=Seu Nome, O=Sua Org, C=BR")
import { existsSync, writeFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
import { randomBytes } from 'node:crypto';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..');
const KS = join(ROOT, 'release.keystore'), PR = join(ROOT, 'keystore.properties');
if (existsSync(KS) || existsSync(PR)) { console.error('✖ release.keystore/keystore.properties já existem. Não vou sobrescrever (perder a chave = perder o app).'); process.exit(1); }
const pw = process.env.KS_PASSWORD || randomBytes(18).toString('base64url');
const dn = process.env.KS_DNAME || 'CN=NEXUS, O=NEXUS, C=BR';
const r = spawnSync('keytool', ['-genkeypair', '-v', '-keystore', KS, '-alias', 'nexus', '-keyalg', 'RSA', '-keysize', '2048', '-validity', '10000',
  '-storepass', pw, '-keypass', pw, '-dname', dn], { stdio: 'inherit', shell: process.platform === 'win32' });
if (r.status !== 0) { console.error('✖ keytool falhou (instale o JDK 21).'); process.exit(1); }
writeFileSync(PR, `storeFile=release.keystore\nstorePassword=${pw}\nkeyAlias=nexus\nkeyPassword=${pw}\n`);
console.log('\n✔ Criados release.keystore e keystore.properties.\n⚠ FAÇA BACKUP dos dois arquivos agora (cofre de senhas/drive privado). Não commite.');
