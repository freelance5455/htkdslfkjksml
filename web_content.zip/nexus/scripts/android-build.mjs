// Gera o pacote de release.  Uso: node scripts/android-build.mjs bundleRelease|assembleRelease
import { existsSync, readFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..');
const task = process.argv[2] || 'bundleRelease';
const fail = (m) => { console.error('✖ ' + m); process.exit(1); };
const win = process.platform === 'win32';

if (!existsSync(join(ROOT, 'android'))) fail('Projeto Android não existe. Rode: npm run android:setup');
if (!existsSync(join(ROOT, 'keystore.properties'))) fail('keystore.properties não encontrado. Rode: npm run android:keystore');
const ks = readFileSync(join(ROOT, 'keystore.properties'), 'utf8');
if (/TROQUE/.test(ks)) fail('keystore.properties ainda tem senhas de exemplo ("TROQUE").');

const sh = (cmd, args, cwd) => {
  const r = spawnSync(cmd, args, { cwd, stdio: 'inherit', shell: win });
  if (r.status !== 0) fail(`Falhou: ${cmd} ${args.join(' ')}`);
};
sh('npx', ['cap', 'sync', 'android'], ROOT);
sh(win ? 'gradlew.bat' : './gradlew', [task], join(ROOT, 'android'));
const out = task === 'bundleRelease' ? 'android/app/build/outputs/bundle/release/app-release.aab' : 'android/app/build/outputs/apk/release/app-release.apk';
console.log('\n✔ Gerado: ' + out + '\nLembre: a cada nova publicação aumente "versionCode" em release.json.');
