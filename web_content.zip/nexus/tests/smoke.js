/**
 * NEXUS — Smoke test
 * Roda sem servidor: testa motor + memória + especialistas
 */

const path = require('path');
const NexusLoop = require('../engine/loop');

async function run() {
  console.log('═══ NEXUS Smoke Test ═══\n');
  const loop = new NexusLoop({
    dataPath: path.join(__dirname, '..', 'data', 'test_graph.json')
  });
  await loop.start();

  // 1. Reflexão
  const snap = await loop.reflect();
  console.log(snap);
  console.log('');

  // 2. Pergunta sobre si
  const r1 = await loop.ask('O que é o NEXUS?');
  console.log('Pergunta: O que é o NEXUS?');
  console.log('Resposta:', r1.answer.slice(0, 200) + '…');
  console.log('Intent:', r1.intent, '| Confidence:', r1.confidence);
  console.log('');

  // 3. Guardar conhecimento
  const r2 = await loop.ask('Guarde isso: a gravidade é uma curvatura do espaço-tempo');
  console.log('Comando de memória:', r2.answer);
  console.log('');

  // 4. Recuperar
  const r3 = await loop.ask('O que você sabe sobre gravidade?');
  console.log('Recuperação:', r3.answer.slice(0, 250) + '…');
  console.log('');

  // 5. Cálculo
  const r4 = await loop.ask('Calcule 15 * 7 + 3');
  console.log('Matemático:', r4.answer);
  console.log('');

  // 6. Especialistas
  console.log('Especialistas:');
  loop.specialistsReport().forEach(s => {
    console.log(`  • ${s.specialist}: ${s.status}`);
  });

  const stats = loop.memory.stats();
  console.log('\nNós finais:', stats.totalNodes);
  console.log('\n✅ Smoke test concluído com sucesso.');
  await loop.stop();
}

run().catch(e => {
  console.error('Falha no smoke test:', e);
  process.exit(1);
});
