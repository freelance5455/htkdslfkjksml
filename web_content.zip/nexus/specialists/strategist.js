/**
 * 🎯 Estrategista
 * Regra de ouro: "Decide hoje pensando em daqui a anos"
 */

class Strategist {
  constructor() {
    this.name = 'Estrategista';
  }

  prioritize(tasks = []) {
    if (!tasks.length) return { ordered: [], note: 'Nenhuma tarefa fornecida' };

    // Heurística simples: palavras de impacto elevam prioridade
    const weight = (t) => {
      const s = String(t).toLowerCase();
      let w = 1;
      if (/crítico|urgente|segurança|falha|quebra/.test(s)) w += 3;
      if (/crescimento|aprendizado|memória|núcleo/.test(s)) w += 2;
      if (/interface|visual|estilo/.test(s)) w += 1;
      return w;
    };

    const ordered = [...tasks]
      .map(t => ({ task: t, score: weight(t) }))
      .sort((a, b) => b.score - a.score);

    return {
      ordered,
      principle: 'Impacto de longo prazo > velocidade de curto prazo'
    };
  }

  longTermView(currentState = {}) {
    return {
      specialist: this.name,
      horizon: 'anos',
      recommendation: [
        'Proteger o núcleo e a memória acima de tudo',
        'Expandir especialistas só depois de estabilidade',
        'Manter independência total de plataformas externas',
        'Cada linha de código deve ser auditável por nós'
      ],
      current: currentState
    };
  }

  report() {
    return {
      specialist: this.name,
      rule: 'Decide hoje pensando em daqui a anos',
      status: 'ativo — visão de longo prazo e prioridades'
    };
  }
}

module.exports = Strategist;
