/**
 * ⚖️ Guardião — Segurança e Fidelidade
 * Regra de ouro: "Protege sem acorrentar"
 */

class Guardian {
  constructor(options = {}) {
    this.name = 'Guardião';
    this.ownerKey = options.ownerKey || null; // hash da chave do dono
  }

  /**
   * Valida o estado antes da entrega final
   * Nesta versão: bloqueia apenas conteúdo vazio ou claramente corrompido
   */
  async validate(state) {
    if (!state || !state.finalAnswer) {
      return { blocked: true, message: 'Resposta vazia bloqueada pelo Guardião.' };
    }
    if (typeof state.finalAnswer !== 'string') {
      return { blocked: true, message: 'Tipo de resposta inválido.' };
    }
    // Não limita conteúdo legítimo — só protege integridade
    return { blocked: false, message: 'Integridade ok' };
  }

  /**
   * Verifica se a chave fornecida corresponde ao dono
   */
  authenticate(keyHash) {
    if (!this.ownerKey) return { ok: true, note: 'Modo aberto (nenhuma chave definida ainda)' };
    if (keyHash === this.ownerKey) return { ok: true, note: 'Acesso autorizado' };
    return { ok: false, note: 'Chave inválida — acesso negado' };
  }

  report() {
    return {
      specialist: this.name,
      rule: 'Protege sem acorrentar',
      status: 'ativo — integridade, autenticidade e fidelidade'
    };
  }
}

module.exports = Guardian;
