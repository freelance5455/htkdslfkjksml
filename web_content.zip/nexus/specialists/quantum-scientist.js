/**
 * ⚛️ Cientista Quântico
 * Regra de ouro: "O invisível também obedece ordem"
 * Foco em padrões, ciclos, correlações e sistemas.
 */

class QuantumScientist {
  constructor(memory) {
    this.memory = memory;
    this.name = 'Cientista Quântico';
  }

  /**
   * Analisa padrões simples em uma sequência de números ou textos
   */
  findPatterns(data) {
    if (!Array.isArray(data) || data.length < 3) {
      return { patterns: [], note: 'Dados insuficientes para padrão confiável' };
    }

    const patterns = [];
    // Verifica progressão aritmética se forem números
    const nums = data.map(Number).filter(n => !isNaN(n));
    if (nums.length >= 3) {
      const diffs = [];
      for (let i = 1; i < nums.length; i++) diffs.push(nums[i] - nums[i - 1]);
      const allEqual = diffs.every(d => d === diffs[0]);
      if (allEqual) {
        patterns.push(`Progressão aritmética com diferença ${diffs[0]}`);
      }
    }

    // Frequência de termos
    const freq = {};
    for (const item of data) {
      const key = String(item).toLowerCase();
      freq[key] = (freq[key] || 0) + 1;
    }
    const top = Object.entries(freq).sort((a, b) => b[1] - a[1]).slice(0, 3);
    if (top.length) {
      patterns.push(`Termos mais frequentes: ${top.map(([k, v]) => `${k}(${v})`).join(', ')}`);
    }

    return { patterns, note: patterns.length ? 'Padrões detectados' : 'Nenhum padrão forte' };
  }

  async analyze(query) {
    // Busca nós relacionados a ciclos/energia/sistemas
    const hits = this.memory ? this.memory.search(query + ' padrão ciclo sistema energia', 5) : [];
    return {
      specialist: this.name,
      related: hits.map(h => h.content),
      insight: hits.length
        ? 'Há conexões prévias no grafo que sugerem ordem subjacente.'
        : 'Ainda sem padrões consolidados sobre este tema.'
    };
  }

  report() {
    return {
      specialist: this.name,
      rule: 'O invisível também obedece ordem',
      status: 'ativo — padrões, ciclos e correlações'
    };
  }
}

module.exports = QuantumScientist;
