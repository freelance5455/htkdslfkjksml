/**
 * 🏗️ Arquiteto de Sistemas
 * Regra de ouro: "O que não quebra quando testado, resiste ao tempo"
 */

class Architect {
  constructor() {
    this.name = 'Arquiteto de Sistemas';
  }

  /**
   * Analisa uma estrutura de pastas/código de forma superficial
   * (recebe lista de arquivos ou descrição)
   */
  reviewStructure(fileList = []) {
    const issues = [];
    const strengths = [];

    if (!fileList.length) {
      return { ok: false, message: 'Nenhuma estrutura fornecida para análise' };
    }

    const hasCore = fileList.some(f => /core|engine|reason/i.test(f));
    const hasTests = fileList.some(f => /test|spec/i.test(f));
    const hasDocs = fileList.some(f => /readme|docs|md/i.test(f));
    const hasConfig = fileList.some(f => /package\.json|config|env/i.test(f));

    if (hasCore) strengths.push('Núcleo identificável');
    else issues.push('Núcleo de raciocínio não encontrado');

    if (hasTests) strengths.push('Testes presentes');
    else issues.push('Sem testes explícitos — risco de regressão');

    if (hasDocs) strengths.push('Documentação presente');
    else issues.push('Documentação ausente ou mínima');

    if (hasConfig) strengths.push('Configuração versionada');

    return {
      ok: issues.length === 0,
      strengths,
      issues,
      recommendation: issues.length
        ? 'Priorizar correção dos pontos fracos antes de expandir'
        : 'Estrutura sólida para evolução'
    };
  }

  report() {
    return {
      specialist: this.name,
      rule: 'O que não quebra quando testado, resiste ao tempo',
      status: 'ativo — revisão de estrutura e robustez'
    };
  }
}

module.exports = Architect;
