/**
 * 🔬 Pesquisador Sênior
 * Regra de ouro: "Não confia sem confirmar em 3"
 * Nesta versão: pesquisa apenas na memória local + validação cruzada de nós.
 * (Fase futura: navegador autônomo com regras de confiança.)
 */

class Researcher {
  constructor(memory) {
    this.memory = memory;
    this.name = 'Pesquisador';
  }

  async investigate(query, existingFindings = []) {
    // Busca adicional com termos extraídos
    const terms = (query || '').toLowerCase().match(/\w{4,}/g) || [];
    const extra = [];

    for (const term of terms.slice(0, 5)) {
      const hits = this.memory.search(term, 3);
      for (const h of hits) {
        if (!existingFindings.find(f => f.id === h.id) && !extra.find(e => e.id === h.id)) {
          extra.push({
            id: h.id,
            content: h.content,
            type: h.type,
            strength: h.strength,
            source: 'researcher-local'
          });
        }
      }
    }

    // Validação cruzada simples: se ≥2 nós falam de algo similar, marca como confirmado
    if (extra.length + existingFindings.length >= 3) {
      extra.forEach(e => { e.validated = true; });
    }

    return extra;
  }

  report() {
    return {
      specialist: this.name,
      rule: 'Não confia sem confirmar em 3',
      status: 'ativo — busca local + validação cruzada'
    };
  }
}

module.exports = Researcher;
