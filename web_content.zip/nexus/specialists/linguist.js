/**
 * 📝 Linguista
 * Regra de ouro: "Fala de modo que seja entendido exatamente"
 */

class Linguist {
  constructor() {
    this.name = 'Linguista';
  }

  clarify(text) {
    if (!text) return { original: '', clarified: '', notes: ['Texto vazio'] };

    let clarified = text.trim();
    const notes = [];

    // Remove repetições excessivas de pontuação
    clarified = clarified.replace(/([!?]){2,}/g, '$1');
    // Normaliza espaços
    clarified = clarified.replace(/\s{2,}/g, ' ');
    // Garante pontuação final
    if (!/[.!?…]$/.test(clarified)) {
      clarified += '.';
      notes.push('Adicionada pontuação final');
    }

    return { original: text, clarified, notes };
  }

  tone(text) {
    const lower = (text || '').toLowerCase();
    if (/obrigad|por favor|desculpa|por gentileza/.test(lower)) return 'cortês';
    if (/!{2,}|\b(urgente|agora|imediatamente)\b/.test(lower)) return 'urgente';
    if (/\?/.test(text)) return 'inquisitivo';
    return 'neutro';
  }

  report() {
    return {
      specialist: this.name,
      rule: 'Fala de modo que seja entendido exatamente',
      status: 'ativo — clareza, precisão e tom'
    };
  }
}

module.exports = Linguist;
