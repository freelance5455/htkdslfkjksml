/**
 * 🧮 Matemático Avançado
 * Regra de ouro: "O número não mente se for bem contado"
 */

class Mathematician {
  constructor() {
    this.name = 'Matemático';
  }

  /**
   * Avalia expressões aritméticas simples de forma segura
   * (sem eval genérico — apenas números e operadores básicos)
   */
  evaluate(expression) {
    const cleaned = String(expression).replace(/[^0-9+\-*/().%\s]/g, '');
    if (!cleaned.trim()) return { ok: false, error: 'Expressão vazia ou inválida' };

    try {
      // Função isolada — não usa eval global
      const fn = new Function(`"use strict"; return (${cleaned});`);
      const result = fn();
      if (typeof result !== 'number' || !Number.isFinite(result)) {
        return { ok: false, error: 'Resultado não numérico' };
      }
      return { ok: true, result, steps: [`Expressão: ${cleaned}`, `Resultado: ${result}`] };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  }

  async handle(input) {
    // Detecta se a entrada parece um cálculo
    if (!/[\d+\-*/()]/.test(input)) {
      return null;
    }
    // Tenta extrair a parte matemática
    const match = input.match(/([0-9+\-*/().%\s]+)/);
    if (!match) return null;
    return this.evaluate(match[1]);
  }

  report() {
    return {
      specialist: this.name,
      rule: 'O número não mente se for bem contado',
      status: 'ativo — aritmética segura + verificação'
    };
  }
}

module.exports = Mathematician;
