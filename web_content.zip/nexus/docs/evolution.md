# Registro de Evolução — NEXUS

## v1.0.0 — Fundação (2026-10-07)

- Estrutura completa de pastas
- Motor de raciocínio (6 estágios) em JavaScript puro
- Grafo de conhecimento persistente
- 7 especialistas implementados (versão base)
- Loop + scheduler + persistência
- Servidor HTTP independente (porta 4242)
- Interface web responsiva (PWA-ready)
- Auth local por senha
- Manifesto, arquitetura e este registro

### O que ainda não está (próximas versões)

- Navegador autônomo real no Pesquisador (hoje só memória local)
- Embeddings locais / busca semântica
- APK nativo (hoje: "Adicionar à Tela Inicial")
- Criptografia ponta a ponta forte
- Multi-dispositivo com sincronização controlada

Cada evolução será registrada aqui. Nada se perde.
