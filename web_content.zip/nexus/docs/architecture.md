# Arquitetura NEXUS v1.0

## Visão Geral

NEXUS é um sistema de raciocínio independente composto por 7 camadas:

1. **Cérebro (core/)** — Pipeline de raciocínio estruturado
2. **Memória (memory/ + data/)** — Grafo de conhecimento persistente
3. **Especialistas (specialists/)** — 7 módulos com metodologias próprias
4. **Coração (engine/)** — Loop, scheduler e persistência
5. **Mundo (deploy/)** — Servidor sob nosso controle
6. **Linha (interface/)** — Janela no celular/navegador
7. **Segurança** — Auth local + Guardião

## Pipeline de Raciocínio

```
Entrada
  → Compreensão (intenção, entidades)
  → Decomposição (passos)
  → Pesquisa (grafo + especialista)
  → Síntese (rascunho)
  → Crítica (score + issues)
  → Conclusão (resposta final + aprendizado)
```

## Especialistas

| Módulo | Função | Regra de ouro |
|--------|--------|---------------|
| researcher | Busca e validação cruzada | Não confia sem confirmar em 3 |
| mathematician | Cálculo seguro | O número não mente se for bem contado |
| quantum-scientist | Padrões e ciclos | O invisível também obedece ordem |
| architect | Estrutura e robustez | O que não quebra quando testado, resiste |
| linguist | Clareza e tom | Fala de modo que seja entendido exatamente |
| strategist | Visão de longo prazo | Decide hoje pensando em daqui a anos |
| guardian | Integridade e fidelidade | Protege sem acorrentar |

## Persistência

- Grafo: `data/knowledge_graph.json`
- Backups sob demanda via `/api/backup`
- Escrita atômica (tmp + rename)

## Comunicação

- Cliente → `POST /api/ask` { input }
- Health → `GET /api/health`
- Reflect → `GET /api/reflect`
- Interface servida como estático na mesma porta
