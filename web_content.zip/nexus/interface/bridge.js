/**
 * NEXUS Bridge — Ponte criptografada (versão 1.0)
 * Comunicação direta com o servidor local.
 * Sem intermediários.
 */

(function () {
  const API = window.location.origin + '/api';
  const chat = document.getElementById('chat');
  const form = document.getElementById('form');
  const input = document.getElementById('input');
  const sendBtn = document.getElementById('send');
  const statusEl = document.getElementById('status');

  function addMsg(role, text) {
    const div = document.createElement('div');
    div.className = 'msg ' + role;
    const bubble = document.createElement('div');
    bubble.className = 'bubble';
    bubble.textContent = text;
    div.appendChild(bubble);
    chat.appendChild(div);
    chat.scrollTop = chat.scrollHeight;
  }

  async function ask(text) {
    sendBtn.disabled = true;
    statusEl.textContent = '● pensando…';
    statusEl.classList.remove('offline');

    try {
      const res = await fetch(API + '/ask', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ input: text })
      });
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const data = await res.json();
      addMsg('nexus', data.answer || JSON.stringify(data));
      statusEl.textContent = '● online';
    } catch (e) {
      addMsg('system', 'Conexão falhou: ' + e.message + '\nO núcleo continua vivo. Tente novamente.');
      statusEl.textContent = '● offline';
      statusEl.classList.add('offline');
    } finally {
      sendBtn.disabled = false;
      input.focus();
    }
  }

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const text = input.value.trim();
    if (!text) return;
    addMsg('user', text);
    input.value = '';
    ask(text);
  });

  // Health check inicial
  fetch(API + '/health')
    .then(r => r.json())
    .then(d => {
      statusEl.textContent = '● online';
      if (d.stats) {
        addMsg('system', `Memória: ${d.stats.totalNodes} nós • Especialistas ativos`);
      }
    })
    .catch(() => {
      statusEl.textContent = '● offline';
      statusEl.classList.add('offline');
    });
})();
