/**
 * NEXUS Auth — Entrada exclusiva
 * Versão 1.0: senha local simples (expandir para chave criptográfica depois)
 * A senha fica apenas no dispositivo / sessão.
 */

(function () {
  const KEY = 'nexus_auth_ok';
  const PASS_KEY = 'nexus_owner_pass';

  // Se já autenticado nesta sessão, não pede de novo
  if (sessionStorage.getItem(KEY) === '1') return;

  // Primeira vez: define senha
  let stored = localStorage.getItem(PASS_KEY);
  if (!stored) {
    const p = prompt('NEXUS — Defina sua senha de acesso (só você terá):');
    if (p && p.length >= 4) {
      localStorage.setItem(PASS_KEY, btoa(p));
      sessionStorage.setItem(KEY, '1');
      return;
    }
    // Sem senha definida — modo aberto por enquanto
    sessionStorage.setItem(KEY, '1');
    return;
  }

  // Já tem senha — pede
  const attempt = prompt('NEXUS — Digite sua senha:');
  if (attempt && btoa(attempt) === stored) {
    sessionStorage.setItem(KEY, '1');
  } else {
    document.body.innerHTML = '<div style="display:flex;height:100vh;align-items:center;justify-content:center;background:#0a0a12;color:#f87171;font-family:sans-serif;">Acesso negado. Recarregue para tentar novamente.</div>';
  }
})();
