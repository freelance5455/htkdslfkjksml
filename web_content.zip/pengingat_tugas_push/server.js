import express from "express";
import webpush from "web-push";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
app.use(express.json({limit:"1mb"}));
app.use(express.static(path.join(__dirname, "public")));

const PORT = process.env.PORT || 3000;
const VAPID_PUBLIC_KEY = process.env.VAPID_PUBLIC_KEY;
const VAPID_PRIVATE_KEY = process.env.VAPID_PRIVATE_KEY;
const VAPID_SUBJECT = process.env.VAPID_SUBJECT || "mailto:admin@example.com";
const DB_FILE = path.join(__dirname, "data.json");

if (!VAPID_PUBLIC_KEY || !VAPID_PRIVATE_KEY) {
  console.error("Isi VAPID_PUBLIC_KEY dan VAPID_PRIVATE_KEY di environment hosting.");
  process.exit(1);
}
webpush.setVapidDetails(VAPID_SUBJECT, VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY);

function loadDB() {
  try { return JSON.parse(fs.readFileSync(DB_FILE, "utf8")); }
  catch { return {subscriptions:[], reminders:[]}; }
}
function saveDB(db) { fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2)); }

app.get("/api/config", (_req,res) => res.json({publicKey:VAPID_PUBLIC_KEY}));

function cleanTasks(tasks) {
  if (!Array.isArray(tasks)) return [];
  return tasks.filter(t => t && typeof t.title === "string" && t.remind && !t.done)
    .map(t => ({id:String(t.id), title:t.title.slice(0,100), subject:String(t.subject||"").slice(0,50),
      due:String(t.due||""), remind:String(t.remind)}))
    .filter(t => Number.isFinite(new Date(t.remind).getTime()));
}
function upsert(req,res) {
  const {subscription,tasks} = req.body || {};
  if (!subscription?.endpoint || !subscription?.keys) return res.status(400).json({error:"Subscription tidak valid."});
  const db=loadDB();
  const key=subscription.endpoint;
  db.subscriptions=db.subscriptions.filter(s=>s.endpoint!==key);
  db.subscriptions.push(subscription);
  const valid=cleanTasks(tasks);
  db.reminders=db.reminders.filter(r=>r.endpoint!==key);
  for (const task of valid) db.reminders.push({...task, endpoint:key, sent:false});
  saveDB(db);
  res.json({ok:true, scheduled:valid.length});
}
app.post("/api/subscribe", upsert);
app.post("/api/sync", upsert);

// Poll due reminders once per minute. The hosting service must remain running.
async function sendDue() {
  const db=loadDB();
  const now=Date.now();
  let changed=false;
  for (const reminder of db.reminders) {
    if (reminder.sent || new Date(reminder.remind).getTime()>now) continue;
    const subscription=db.subscriptions.find(s=>s.endpoint===reminder.endpoint);
    reminder.sent=true; changed=true;
    if (!subscription) continue;
    const payload=JSON.stringify({
      title:"Pengingat Tugas: "+reminder.title,
      body:(reminder.subject ? reminder.subject+" · " : "")+"Tenggat: "+(reminder.due||"periksa tugasmu")
    });
    try { await webpush.sendNotification(subscription,payload); }
    catch(err) {
      if (err.statusCode===404 || err.statusCode===410) {
        db.subscriptions=db.subscriptions.filter(s=>s.endpoint!==reminder.endpoint);
        db.reminders=db.reminders.filter(r=>r.endpoint!==reminder.endpoint);
      } else console.error("Push gagal:",err.message);
    }
  }
  if (changed) saveDB(db);
}
setInterval(sendDue, 30_000);
sendDue();

app.get("/health", (_req,res)=>res.json({ok:true}));
app.listen(PORT,()=>console.log(`Pengingat Tugas berjalan di port ${PORT}`));
