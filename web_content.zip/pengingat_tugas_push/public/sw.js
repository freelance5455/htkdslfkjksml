const CACHE = "pengingat-tugas-push-v1";
self.addEventListener("install", e => { self.skipWaiting(); });
self.addEventListener("activate", e => { e.waitUntil(self.clients.claim()); });
self.addEventListener("fetch", e => {
  if (e.request.method !== "GET" || new URL(e.request.url).origin !== self.location.origin) return;
  e.respondWith(fetch(e.request).then(r => {
    const copy = r.clone(); caches.open(CACHE).then(c => c.put(e.request, copy)); return r;
  }).catch(() => caches.match(e.request).then(r => r || caches.match("/index.html"))));
});
self.addEventListener("push", event => {
  let data = {title:"Pengingat Tugas", body:"Ada tugas yang perlu kamu periksa."};
  try { if (event.data) data = {...data, ...event.data.json()}; } catch(e) {}
  event.waitUntil(self.registration.showNotification(data.title, {
    body:data.body, icon:"/icons/icon-192.png", badge:"/icons/icon-192.png",
    data:{url:data.url || "/"}
  }));
});
self.addEventListener("notificationclick", event => {
  event.notification.close();
  event.waitUntil(clients.matchAll({type:"window", includeUncontrolled:true}).then(list => {
    for (const client of list) if ("focus" in client) return client.focus();
    return clients.openWindow(event.notification.data?.url || "/");
  }));
});
