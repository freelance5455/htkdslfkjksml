# Kako napraviti APK od ovog projekta

Ovaj folder je spreman Capacitor projekat. Aplikacija (`www/index.html`) je
ista ona koju već imaš — samo je sad upakovana tako da može da se pretvori
u pravu Android aplikaciju.

## Šta ti treba (instalira se jednom)

1. **Node.js** — preuzmi sa https://nodejs.org (LTS verzija)
2. **Android Studio** — preuzmi sa https://developer.android.com/studio
   - Pri prvom pokretanju, pusti da instalira Android SDK (podrazumevana
     podešavanja su dovoljna)

## Koraci

Otpakuj ovaj zip negde na računaru, otvori terminal (cmd/PowerShell na
Windows-u, Terminal na Mac-u) u tom folderu i ukucaj redom:

```bash
npm install
npx cap add android
npx cap sync
npx cap open android
```

Poslednja komanda otvara projekat u Android Studio-u. Tu:

1. Sačekaj da Android Studio završi indeksiranje (može par minuta prvi put)
2. Idi na meni **Build → Build Bundle(s) / APK(s) → Build APK(s)**
3. Kad završi, izađe obaveštenje "APK(s) generated successfully" —
   klikni na **locate** da vidiš gde je fajl (obično u
   `android/app/build/outputs/apk/debug/app-debug.apk`)

Taj `.apk` fajl možeš direktno da prebaciš na telefon i instaliraš
(potrebno je da na telefonu dozvoliš instalaciju iz "nepoznatih izvora").

## Napomena o localStorage-u

Aplikacija čuva unose i alarme preko `localStorage` — to radi normalno
unutar Capacitor/WebView okruženja, isto kao u browseru, samo su podaci
sada vezani za telefon na kom je instalirana app.

## Ako želiš da promeniš ime aplikacije ili ikonicu

- Ime: izmeni `appName` u `capacitor.config.json`
- Ikonica: Capacitor ima alat `@capacitor/assets` koji automatski generiše
  sve potrebne veličine ikonica iz jedne slike — javi ako želiš uputstvo
  i za to.

## Ako želiš pravi (potpisani) APK za Google Play

Ovaj debug APK je samo za testiranje na tvom telefonu. Za objavljivanje
na Google Play potreban je "signed" (potpisan) APK/AAB — to je poseban,
malo duži proces (generisanje keystore fajla i sl.) — javi ako stigneš
do te faze pa ti dam uputstvo.
