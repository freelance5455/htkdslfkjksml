// CHATCƏBİ server template (Cloudflare Worker).
// API key is stored as a Worker secret, NOT in the APK.
// This template intentionally needs a trusted AI provider endpoint and model.
// Configure AI_API_URL, AI_API_KEY, AI_MODEL as Worker secrets/vars.
export default {
  async fetch(request, env) {
    const cors = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type"
    };
    if (request.method === "OPTIONS") return new Response(null, { headers: cors });
    if (request.method !== "POST") return new Response("POST only", { status: 405, headers: cors });
    try {
      const body = await request.json();
      const message = String(body.message || "").slice(0, 4000);
      if (!message) return Response.json({ reply: "Mesaj boşdur." }, { headers: cors });
      if (!env.AI_API_URL || !env.AI_API_KEY || !env.AI_MODEL)
        return Response.json({ reply: "Server konfiqurasiyası tamamlanmayıb." }, { status: 503, headers: cors });
      const history = Array.isArray(body.history) ? body.history.slice(-10).map(x => ({
        role: x.who === "user" ? "user" : "assistant",
        content: String(x.text || "").slice(0, 2000)
      })) : [];
      const response = await fetch(env.AI_API_URL, {
        method: "POST",
        headers: { "Authorization": `Bearer ${env.AI_API_KEY}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          model: env.AI_MODEL,
          messages: [
            { role: "system", content: "Sən CHATCƏBİ adlı Azərbaycan dilində danışan, mehriban və təhlükəsiz köməkçisən. Cavablarını Azərbaycan dilində, aydın və yaşa uyğun ver. Əmin olmadığın məlumatı uydurma." },
            ...history,
            { role: "user", content: message }
          ]
        })
      });
      if (!response.ok) return Response.json({ reply: "AI serverində problem oldu. Sonra yenidən yoxla." }, { status: 502, headers: cors });
      const data = await response.json();
      const reply = data.choices?.[0]?.message?.content || "Cavab alınmadı.";
      return Response.json({ reply }, { headers: cors });
    } catch (e) {
      return Response.json({ reply: "Server xətası. Sonra yenidən yoxla." }, { status: 500, headers: cors });
    }
  }
};