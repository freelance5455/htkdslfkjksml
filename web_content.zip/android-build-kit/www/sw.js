/* Loonie Academy v13: cache the complete core for offline use. No network/API needed for university or inquiry. */
const V = "loonie-20261116-v13", RT = "loonie-runtime";
const CORE = [
  "./", "./index.html", "./curriculum-v6.js", "./curriculum-v7.js",
  "./university-v8.js", "./university-v8.css", "./inquiry-v9.js", "./inquiry-v9.css", "./kingdom-v10.js", "./kingdom-v10.css", "./career-v11.js", "./career-v11.css", "./life-v12.js", "./life-v12.css", "./curriculum-v13.js", "./academy-v13.js", "./academy-v13.css", "./manifest.webmanifest",
  "./icon-192.png", "./icon-512.png", "./icon-maskable-512.png"
];
self.addEventListener("install", event => {
  event.waitUntil(caches.open(V).then(cache => cache.addAll(CORE)).then(() => self.skipWaiting()));
});
self.addEventListener("activate", event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== V && k !== RT).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener("fetch", event => {
  const request = event.request;
  if (request.method !== "GET") return;
  const url = new URL(request.url);
  if (url.origin === self.location.origin) {
    // Online navigation can receive new releases; cached index remains available in airplane mode.
    if (request.mode === "navigate") {
      event.respondWith(fetch(request).then(response => {
        if (response && response.ok) caches.open(V).then(c => c.put("./index.html", response.clone())).catch(() => {});
        return response;
      }).catch(() => caches.match("./index.html")));
    } else {
      event.respondWith(caches.match(request, {ignoreSearch:true}).then(hit => hit || fetch(request).then(response => {
        if (response && response.ok) caches.open(V).then(c => c.put(request, response.clone())).catch(() => {});
        return response;
      })));
    }
  } else if (/^(fonts\.googleapis\.com|fonts\.gstatic\.com|cdn\.jsdelivr\.net)$/.test(url.host)) {
    // Optional decorative fonts/Python runtime. The core curriculum and university don't need these.
    event.respondWith(caches.open(RT).then(c => c.match(request).then(hit => hit || fetch(request).then(response => {
      if (response && (response.ok || response.type === "opaque")) c.put(request, response.clone()).catch(() => {});
      return response;
    }))));
  }
});
