/* Loonie Academy v8 | Personal University. Offline, deterministic, no backend or API. */
(() => {
"use strict";
const UNI_VERSION = 8, PASS = 70;
const RUBRIC = [
  ["Accuracy", "Check facts, calculations, units and assumptions"],
  ["Evidence", "Show how lesson concepts or source observations support your work"],
  ["Practicality", "Make recommendations feasible, safe and appropriate to the situation"],
  ["Communication", "Explain steps and limitations so another person can follow them"]
];
const S = (v) => esc(String(v == null ? "" : v)).replace(/"/g,"&quot;").replace(/'/g,"&#39;");
const T = (key) => { const m=/^(\d{4})-(\d{2})-(\d{2})$/.exec(key); const d=m?new Date(+m[1],+m[2]-1,+m[3],12):new Date(key); return isNaN(+d) ? "Not set" : d.toLocaleDateString("en-CA", {year:"numeric",month:"short",day:"numeric"}); };
const PCT = (v) => v == null ? "—" : `${Math.round(v)}%`;
const SRC = (l,q) => ({type:"lesson",lid:l.id,qi:q,ref:l.title});
const CASES = {
  acct: [
    {title:"The Community Market Ledger",context:"A Calgary community market buys supplies, takes cash and card payments, and wants records that a second person can inspect.",
     questions:[
       ["The market receives $800 cash from customers. Which evidence best supports recording sales?", "Dated sales summaries and receipts reconciled to cash","An unsigned guess made next month","The owner's memory alone","The social media follower count","Source documents make a record verifiable."],
       ["The market earns $1,500 and incurs $950 in expenses. What is profit before tax?","$550","$2,450","$950","$1,500","Profit = revenue less expenses: 1,500 − 950 = 550."]],
     milestones:["Draft a simple chart of accounts and explain two choices.","Record five sample market transactions with a clear audit trail.","Reconcile a cash summary against your transaction record; explain any difference.","Write a one-page closing summary with two limitations of your records."]},
    {title:"Pricing the Pop-up Shop",context:"A small pop-up sells reusable drink bottles. Its owner must compare cost, price and demand before expanding.",
     questions:[
       ["A bottle costs $18 and sells for $30. What is the gross margin?","40%","66.7%","60%","12%","(30 − 18) / 30 = 40%."],
       ["The business needs to compare two product lines. Which report helps most?","Contribution margin by product with assumptions","Only total website traffic","The owner's favourite colour","A list of staff birthdays","Product-level contribution analysis supports decisions."]],
     milestones:["Set out customer, cost, pricing and sales-volume assumptions.","Prepare a simple budget with a base and low-sales case.","Compare two prices using contribution margin and break-even reasoning.","Recommend a price with evidence, risks and next measurements."]},
    {title:"Find the Control Gap",context:"A service business has late-paying customers and unexplained differences between its bank and ledger balances.",
     questions:[
       ["Which control best limits a single employee's ability to hide an error?","Independent review and separation of duties","Let one person approve and reconcile everything","Avoid keeping source documents","Stop reconciling accounts","Independent checks improve the control environment."],
       ["What is the first step when bank and ledger balances disagree?","Identify timing items and errors using reconciliation evidence","Record the difference as profit","Ignore it until year-end","Delete older transactions","Reconciling identifies timing differences and errors before corrections."]],
     milestones:["Map the transaction-to-bank process and possible failure points.","Draft a bank reconciliation using a documented sample dataset.","Propose two proportionate internal controls and who performs them.","Write an exception report that separates evidence from hypotheses."]},
    {title:"Boardroom Decision Pack",context:"A Canadian small business is considering a second location and needs a defensible recommendation—not a guaranteed forecast.",
     questions:[
       ["Which choice makes a forecast most credible?","Explicit assumptions and sensitivity scenarios","One certain-looking revenue number","No cost estimate","Ignoring uncertainty","Decision-makers need assumptions and downside scenarios."],
       ["A project costs $12,000 now and returns $13,200 in one year. At a 10% discount rate, approximate NPV?","$0","$1,200","$13,200","-$12,000","13,200 / 1.10 − 12,000 = 0." ]],
     milestones:["Create a short financial statement and cash-flow interpretation.","Build a two-scenario cash forecast and identify key assumptions.","Compare expansion and delay, including non-financial risks.","Deliver a board-style recommendation with citations to your calculations."]}
  ],
  trade: [
    {title:"Safe Workshop Brief",context:"A team is preparing a supervised workshop exercise. Conditions can change, and a form alone is not a substitute for a hazard assessment.",
     questions:[
       ["The work area layout changes after the safety plan is signed. What now?","Stop and reassess hazards and controls","Continue because the form is signed","Remove barriers to save time","Wait for an incident","Changes to the work require reassessment."],
       ["Which is generally stronger than PPE alone?","Eliminating or isolating the hazard","Buying brighter clothing only","Posting an encouraging sign","Asking people to hurry","The hierarchy of controls favours controlling hazards at their source."]],
     milestones:["Describe the exercise scope, boundaries and people involved.","Build a hazard register with severity, likelihood and controls.","Specify stop-work triggers and who must be contacted.","Write a safe pre-task briefing, including what requires qualified supervision."]},
    {title:"Estimate a Small Build",context:"A community organization wants a small non-structural display unit. You must quote conceptually without promising unverified installation or code compliance.",
     questions:[
       ["Materials cost $240, estimated labour $360 and contingency $60. Estimated direct cost?","$660","$600","$420","$900","240 + 360 + 60 = 660."],
       ["A client asks to add new work after approving a quote. Best response?","Document revised scope, price and approval","Do it silently and bill later","Say every change is free","Erase the original quote","A written change order reduces scope confusion."]],
     milestones:["List the proposed materials, sizes and constraints with units.","Prepare a quantity takeoff and labour estimate with assumptions.","Write scope, exclusions, revisions and safe work boundaries.","Compare actual vs estimated cost in a simulated outcome."]},
    {title:"Troubleshoot by Evidence",context:"A training mock-up appears to have a fault. The task is to reason from symptoms and documentation, not conduct hazardous live interventions.",
     questions:[
       ["What should happen before a risky physical diagnostic task?","Use authorized procedures and qualified supervision","Bypass isolation to save time","Guess which component failed","Touch unknown energized parts","Safety authorization and isolation come before hazardous work."],
       ["Which troubleshooting approach reduces unnecessary part replacement?","Test hypotheses against observations","Replace everything at once","Ignore the drawings","Change two variables without notes","Evidence-based testing makes conclusions traceable."]],
     milestones:["Write a clear fault statement with symptoms and operating context.","List three plausible causes and predicted observations.","Design a non-hazardous simulated test sequence with stop conditions.","Explain the likely root cause, remaining uncertainty and verification steps."]},
    {title:"Integrated Trade Project Review",context:"A small facility upgrade is proposed. Your role is to produce an educational planning package for qualified review—not engineering approval.",
     questions:[
       ["Which result is appropriate for a classroom project?","A documented proposal for qualified review","An automatic permit to perform regulated work","A professional licence","A guarantee the design is safe","The app cannot certify practical competence or authorize work."],
       ["Which change best strengthens a proposal?","Traceable scope, costs, constraints, risks and review points","More decorative renderings only","Remove assumptions","Skip site conditions","Evidence and explicit constraints support review."]],
     milestones:["State requirements, site assumptions and limits of authority.","Prepare a conceptual work sequence and resource estimate.","Produce a risk-and-quality review checklist for qualified supervisors.","Present alternatives, trade-offs and your final review-ready brief."]}
  ],
  tech: [
    {title:"Clean the Community Dataset",context:"A nonprofit has a fictional spreadsheet with missing values, duplicated rows and inconsistent units.",
     questions:[
       ["Which action best protects original data during cleaning?","Keep a raw copy and document each transformation","Overwrite the only copy","Delete all outliers without review","Assume blanks are zero","Reproducibility requires preserving the source and changes."],
       ["A value rises from 40 to 50. What is its percent increase?","25%","10%","20%","125%","(50 − 40) / 40 = 25%." ]],
     milestones:["Define a fictional dataset, fields, units and data dictionary.","Identify and document duplicates, missing values and outliers.","Create three checks or formulas for data quality.","Explain what the cleaned dataset can and cannot establish."]},
    {title:"Build a Useful Dashboard",context:"A neighborhood program needs a readable dashboard showing participation and spending over time.",
     questions:[
       ["Which chart is often suitable for comparing values over time?","A line chart with a labelled time axis","An unlabeled decorative image","A random colour swatch","A single total with no dates","Time-series comparisons benefit from explicit dates and scale."],
       ["What is a useful way to prevent a misleading visual?","Use truthful axis labels, units and context","Hide low values","Truncate labels without disclosure","Use every colour available","A chart should preserve the meaning of the data." ]],
     milestones:["Define audience, key decisions and three useful metrics.","Sketch a data table and formulas with explicit units.","Create a conceptual dashboard layout and explain your chart choices.","Test interpretation with two questions and describe caveats."]},
    {title:"Privacy-aware Workflow",context:"A small team wants to automate a repetitive reporting task with user data and must understand privacy and failure modes.",
     questions:[
       ["Which approach limits personal-data exposure?","Collect only necessary fields and restrict access","Share every record publicly","Store passwords inside plain reports","Keep data forever without a reason","Data minimization and access controls reduce exposure."],
       ["An AI-generated summary cites facts absent from the dataset. What next?","Verify against source records before using it","Publish because AI is confident","Delete the source records","Assume a confidence label is proof","AI output must be checked against actual evidence." ]],
     milestones:["Map the reporting workflow, data inputs and authorized users.","Threat-model realistic privacy, accuracy and access risks.","Propose validations, error handling and human checkpoints.","Compare the automated and manual workflow including trade-offs."]},
    {title:"Decision-ready Technology Portfolio",context:"A fictional startup asks for a data-informed recommendation on a simple workflow automation project.",
     questions:[
       ["Which prototype claim is appropriate?","A tested result under stated assumptions","Guaranteed zero future errors","Proof of certification","No need for user testing","Prototypes require test limits and documented assumptions."],
       ["How should you compare two solutions?","Use agreed criteria, evidence, costs and limitations","Choose the flashiest demo","Ignore security risks","Change the goal after seeing results","Comparable criteria make decisions transparent." ]],
     milestones:["Write user stories, acceptance criteria and an ethical-data plan.","Create a small pseudocode, spreadsheet or mock-data demonstration.","Record test cases, failures, revisions and security considerations.","Deliver a concise product recommendation and next-step roadmap."]}
  ],
  open: [
    {title:"Evidence Notebook",context:"You are exploring a subject of your choice. Build a learning journal rather than simply collecting facts.",
     questions:[
       ["Which learning note is strongest?","A claim with source and an explanation in your own words","A copied paragraph with no citation","A confident unsupported statement","Only a list of emojis","Traceable evidence and explanation make notes useful."],
       ["What best checks understanding of a concept?","Explain it and apply it to a new example","Only re-read the heading","Count study minutes as proof","Skip every practice question","Retrieval and transfer show more than recognition." ]],
     milestones:["Formulate two answerable study questions and a learning goal.","Define key terms and collect notes from lesson examples.","Apply one concept to a new realistic scenario.","Write a source-aware summary and what remains uncertain."]},
    {title:"Compare Explanations",context:"Two apparently reasonable approaches lead to different results. Your job is to investigate why.",
     questions:[
       ["Which is the best response to conflicting evidence?","Check definitions, assumptions and source quality","Choose whichever answer you prefer","Ignore dates and units","Assume both must be identical","Differences can arise from premises, data and methods."],
       ["What should a comparison include?","Consistent criteria and trade-offs","Different measures for each option","Only the final winner","No limitations","A fair comparison needs the same criteria." ]],
     milestones:["Describe a relevant question with at least two possible approaches.","List consistent comparison criteria and evidence.","Analyze the main agreement, disagreement and assumptions.","Make a provisional recommendation and state what might change it."]},
    {title:"Applied Skill Demonstration",context:"Demonstrate a concept using an invented case that can be evaluated without specialized equipment.",
     questions:[
       ["How should you make a practical claim?","Connect it to observable or calculated evidence","State it as certain without checking","Hide how it was produced","Use an anecdote as universal proof","Support conclusions with verifiable work."],
       ["What is a useful revision after failed practice?","Identify the error and retest the changed step","Repeat without changing anything","Erase earlier attempts","Skip feedback","Targeted revision can improve the method." ]],
     milestones:["Define a safe, measurable task and success criterion.","Build a small worked example or simulation with your own inputs.","Check and revise the output against the criteria.","Document the result, failure modes and a repeatable method."]},
    {title:"Independent Learning Portfolio",context:"Pull your learning together into a clear portfolio piece that separates achievement from claims of qualification.",
     questions:[
       ["Which portfolio statement is most defensible?","Here is a practice project with methods and limitations","This app awarded me a professional licence","All skills are proven by hours studied","No supporting work is needed","Evidence-based descriptions avoid overstating competence."],
       ["What belongs in a strong next-steps plan?","Specific gaps, resources and a way to check progress","A promise to know everything soon","Only an attractive cover page","No learning goals","An actionable plan needs clear gaps and measurements." ]],
     milestones:["Choose two substantive practice artifacts and explain their purpose.","Summarize strengths with citations to completed work.","Critically assess limitations, remaining gaps and feedback needed.","Present an honest portfolio summary and continuing-study roadmap."]}
  ]
};
const PROGRAMS = [
 {id:"acct",icon:"📒",name:"Accounting & Business",desc:"Financial records, pricing, controls and decision-making",focus:"acct",termNames:["Financial Foundations","Management & Analysis","Reporting & Controls","Strategic Finance"],mix:[["acct",3],["biz",2],["math",2],["excel",1]]},
 {id:"trade",icon:"🛠️",name:"Skilled Trades",desc:"Safety, estimates, technical reasoning and supervised practice planning",focus:"carp",termNames:["Safe Foundations","Planning & Estimating","Technical Diagnosis","Applied Project Review"],mix:[["carp",3],["safety",2],["math",2],["eng",1]]},
 {id:"tech",icon:"💻",name:"Technology & Data",desc:"Coding, data quality, security and portfolio projects",focus:"code",termNames:["Digital Foundations","Data & Visualization","Reliable Systems","Applied Technology"],mix:[["code",3],["excel",2],["math",2],["cyber",1]]},
 {id:"open",icon:"🌐",name:"Independent Studies",desc:"Choose any of the 37 subjects and assemble a supported learning path",focus:"math",termNames:["Inquiry & Foundations","Comparative Study","Applied Investigation","Independent Portfolio"],mix:[["math",4],["commun",2],["brain",1],["career",1]]}
];
const TRADE_IDS = () => SUBJECTS.filter(s => s.cat === "trades").map(s => s.id);
function init(){
 if (!state.university || typeof state.university !== "object" || !state.university.plans) {
   if (typeof snapshot === "function") snapshot("Before activating Personal University v8");
   state.university = {active:"acct",weeklyMinutes:180,plans:{},version:UNI_VERSION}; save();
 }
 if (!state.university.weeklyMinutes || state.university.weeklyMinutes < 30) state.university.weeklyMinutes = 180;
 return state.university;
}
function getProgram(){const u=init(), [id, focus] = String(u.active||"acct").split(":");return {p:PROGRAMS.find(x=>x.id===id)||PROGRAMS[0],focus};}
function keyFor(p,focus){return (p.id==="trade"||p.id==="open") ? p.id+":"+focus : p.id;}
function active(){
 const u=init(), {p,focus:raw}=getProgram(), focus = p.id==="trade" ? (TRADE_IDS().includes(raw) ? raw : "carp") : p.id==="open" ? (SUBJ(raw)?raw:"math") : p.focus;
 const id=keyFor(p,focus); if(!u.plans[id]) { u.plans[id]={joined:Date.now(),terms:{},focus}; save(); }
 return {u,p,focus,id,pr:u.plans[id],terms:planTerms(p,focus)};
}
function planTerms(p,focus){
 const mix = p.id==="acct" ? [
  [["acct",3],["biz",2],["math",2],["excel",1]],[["acct",3],["excel",2],["biz",2],["math",1]],[["acct",4],["biz",1],["fin",2],["econ",1]],[["acct",3],["fin",2],["biz",2],["excel",1]]
 ] : p.id==="trade" ? [
  [[focus,3],["safety",2],["math",2],["eng",1]],[[focus,3],["safety",1],["math",1],["commun",2],["eng",1]],[[focus,3],["eng",2],["physics",1],["safety",1],["biz",1]],[[focus,4],["eng",2],["biz",1],["commun",1]]
 ] : p.id==="tech" ? [
  [["code",3],["excel",2],["math",2],["cyber",1]],[["code",3],["excel",3],["math",1],["commun",1]],[["code",3],["cyber",2],["ai",2],["math",1]],[["code",3],["excel",2],["ai",1],["cyber",1],["biz",1]]
 ] : [
  [[focus,4],["commun",2],["brain",1],["math",1]],[[focus,3],["history",1],["commun",2],["brain",1]],[[focus,4],["eng",1],["math",1],["career",1]],[[focus,4],["career",1],["commun",1],["biz",1]]
 ];
 const used=new Set();
 const order = n => n===0?["Beginner","Intermediate","Advanced"]:n===1?["Intermediate","Beginner","Advanced"]:n===2?["Intermediate","Advanced","Beginner"]:["Advanced","Intermediate","Beginner"];
 function take(sid,n,term){
  const subj=SUBJ(sid); if(!subj) return [];
  const pool=subjIds(subj).filter(id=>LES(id)&&!used.has(id));
  pool.sort((a,b)=>order(term).indexOf(LEVEL(a))-order(term).indexOf(LEVEL(b)));
  const ids=pool.slice(0,n); ids.forEach(x=>used.add(x)); return ids;
 }
 return mix.map((parts,i)=>{
  let ids=[]; for (const [sid,n] of parts) ids.push(...take(sid,n,i));
  const fallbacks=[focus,"math","commun","eng","biz","brain","code","career","acct","excel"];
  for(const sid of fallbacks){if(ids.length>=7) break; ids.push(...take(sid,7-ids.length,i));}
  return {index:i, name:p.termNames[i], lessons:ids, spec:CASES[p.id][i], dependsOn:i===0?null:i-1};
 });
}
function termData(a,i){if(!a.pr.terms[i])a.pr.terms[i]={drafts:{},results:{},target:""};return a.pr.terms[i];}
function record(a,i,type){return termData(a,i).results[type]||{best:null,history:[]};}
function score(a,i,type){return record(a,i,type).best;}
function passes(a,i,type){return (score(a,i,type)||0)>=PASS;}
function finished(a,i){return ["assignment","exam","capstone"].every(t=>passes(a,i,t));}
function unlocked(a,i){return i===0 || finished(a,i-1);}
function lessonsDone(a,i){const ids=a.terms[i].lessons; return ids.filter(id=>!!state.done[id]).length;}
function gate(a,i,type){return unlocked(a,i) && (type==="assignment" ? lessonsDone(a,i)===a.terms[i].lessons.length : type==="exam" ? passes(a,i,"assignment") : passes(a,i,"exam"));}
function grade(a,i){const x=[score(a,i,"assignment"),score(a,i,"exam"),score(a,i,"capstone")];return x.every(v=>v!=null)?Math.round(x[0]*.25+x[1]*.5+x[2]*.25):null;}
function totalTime(t){return t.lessons.reduce((n,id)=>n+(LES(id)?.mins||15),0)+120;}
function levelLabel(n){return n===0?"Foundation semester":n===1?"Applied semester":n===2?"Intermediate semester":"Advanced semester";}
function stamp(v){return v?new Date(v).toLocaleString("en-CA",{year:"numeric",month:"short",day:"numeric",hour:"numeric",minute:"2-digit"}):"Not attempted";}
const subjName = (sid)=>SUBJ(sid)?.name||sid;
function lead(title,back="uni",sub=""){
 return `<div class="row" style="gap:10px;align-items:center;margin-bottom:12px"><a class="pill" href="#${back}" aria-label="Back">←</a><h1 class="h-xl" style="margin:0;font-size:clamp(23px,5vw,32px)">${title}</h1></div>${sub?`<p class="h-sub" style="margin:0 0 18px">${sub}</p>`:""}`;
}
function badge(ok,text){return `<span class="uni-badge ${ok?'yes':'no'}">${text}</span>`;}
function renderUni(){
 const a=active(), completed=a.terms.filter((_,i)=>finished(a,i)).length, total=a.terms.reduce((n,t)=>n+t.lessons.length,0), learned=a.terms.reduce((n,t)=>n+t.lessons.filter(id=>state.done[id]).length,0);
 const options=PROGRAMS.map(p=>`<option value="${p.id}" ${p.id===a.p.id?'selected':''}>${p.icon} ${S(p.name)}</option>`).join("");
 const focusOptions=(a.p.id==="trade"?SUBJECTS.filter(s=>s.cat==="trades"):SUBJECTS).map(s=>`<option value="${s.id}" ${s.id===a.focus?'selected':''}>${s.icon} ${S(s.name)}</option>`).join("");
 scr().innerHTML=lead("🎓 Personal University","learn","Four structured semesters built from your existing lessons, with graded practice assignments, mixed exams and applied projects.")+
 `<div class="uni-hero"><div class="uni-kicker">YOUR PERSONAL CAMPUS · V8</div><h2>${a.p.icon} ${S(a.p.name)}</h2><p>${S(a.p.desc)}</p><div class="uni-metrics"><span><b>${completed}/4</b> semesters passed</span><span><b>${learned}/${total}</b> scheduled lessons</span><span><b>${Math.round(completed/4*100)}%</b> program completion</span></div></div>
 <div class="uni-card"><h3 style="margin:0 0 10px">Choose your pathway</h3><div class="uni-form"><label>Program<select id="uni-prog">${options}</select></label>${a.p.id==="trade"||a.p.id==="open"?`<label>${a.p.id==="trade"?"Trade specialization":"Primary subject"}<select id="uni-focus">${focusOptions}</select></label>`:""}<label>Weekly study target<select id="uni-week">${[60,120,180,240,360,480,600].map(n=>`<option value="${n}" ${a.u.weeklyMinutes===n?'selected':''}>${n} minutes</option>`).join("")}</select></label></div><p class="uni-note">Switching programs keeps each pathway's university results separate. Existing lesson completion remains shared across the app.</p></div>
 <div class="uni-section">Your semester map</div>${a.terms.map((t,i)=>{
  const on=unlocked(a,i), n=lessonsDone(a,i), d=termData(a,i), mins=totalTime(t), weeks=Math.max(1,Math.ceil(mins/a.u.weeklyMinutes));
  return `<a href="#uni-term-${i}" class="uni-sem ${on?'':'locked'}" aria-label="View semester ${i+1}"><div class="uni-num">${on?(finished(a,i)?"✓":i+1):"🔒"}</div><div class="uni-sem-main"><span class="uni-kicker">SEMESTER ${i+1} · ${levelLabel(i)}</span><b>${S(t.name)}</b><small>${n}/${t.lessons.length} lessons · ${Math.round(mins/60*10)/10} h estimated work · about ${weeks} week${weeks>1?'s':''} at your target</small><div class="uni-progress"><i style="width:${Math.round(n/Math.max(1,t.lessons.length)*100)}%"></i></div><div class="uni-chips">${badge(passes(a,i,'assignment'),'Assignment '+PCT(score(a,i,'assignment')))}${badge(passes(a,i,'exam'),'Exam '+PCT(score(a,i,'exam')))}${badge(passes(a,i,'capstone'),'Project '+PCT(score(a,i,'capstone')))}</div></div><div class="uni-arrow">›</div></a>`;}).join('')}
 <a href="#uni-transcript" class="gbtn uni-full">📊 Open university transcript & gradebook</a><a href="#backup" class="gbtn alt uni-full">💾 Back up my Academy progress</a><div class="uni-disclaimer">Personal University is a self-directed study tool. Grades are formative, exams are unproctored and projects include self-review. This app does not grant university credits, a degree, a trade ticket or any professional credential.</div>`;
 const pg=$("#uni-prog"); pg.onchange=e=>{const np=PROGRAMS.find(x=>x.id===e.target.value);a.u.active=keyFor(np,np.focus);save();renderUni();};
 const foc=$("#uni-focus");if(foc)foc.onchange=e=>{a.u.active=keyFor(a.p,e.target.value);save();renderUni();};
 $("#uni-week").onchange=e=>{a.u.weeklyMinutes=+e.target.value;save();renderUni();};
}
function weeklyPlan(a,i){
 const d=termData(a,i), t=a.terms[i], budget=a.u.weeklyMinutes;
 const tasks=t.lessons.map(id=>({name:LES(id).title,done:!!state.done[id],mins:LES(id).mins})).concat([
  {name:"Submit the applied assignment",done:passes(a,i,'assignment'),mins:30},
  {name:"Pass the mixed semester exam",done:passes(a,i,'exam'),mins:30},
  {name:"Prepare and submit the capstone project",done:passes(a,i,'capstone'),mins:60}
 ]);
 const weeks=[]; let group=[],minutes=0;
 tasks.forEach(task=>{if(group.length&&minutes+task.mins>budget){weeks.push({tasks:group,mins:minutes});group=[];minutes=0;}group.push(task);minutes+=task.mins;});
 if(group.length)weeks.push({tasks:group,mins:minutes});
 const target=d.target?new Date(d.target+'T12:00:00'):null;
 return `<details class="uni-card uni-week"><summary>🗓️ Suggested weekly schedule (${weeks.length} week${weeks.length===1?'':'s'})</summary><p class="uni-note">A flexible plan, not a mandatory deadline. Your ${budget}-minute weekly target is used to group lesson work and assessments. Replan any time.</p>${weeks.map((w,n)=>{
  const end=target?new Date(+target-(weeks.length-n-1)*7*86400000):null;
  return `<div class="uni-weekbox"><b>Week ${n+1}${end?' · by '+T(end.toISOString().slice(0,10)):''}</b><small>~${w.mins} minutes</small>${w.tasks.map(task=>`<div class="uni-week-task">${task.done?'✅':'○'} ${S(task.name)}</div>`).join('')}</div>`;
 }).join('')}</details>`;
}
function renderTerm(i){
 const a=active(), t=a.terms[i]; if(!t)return renderUni();
 const d=termData(a,i), on=unlocked(a,i), nd=lessonsDone(a,i), ready=nd===t.lessons.length;
 const prior=i?`Semester ${i} must be passed (all three assessments ≥${PASS}%) before this semester opens.`:"";
 scr().innerHTML=lead(`Semester ${i+1}: ${S(t.name)}`,"uni",`${levelLabel(i)} · ${t.lessons.length} lessons · target ${a.u.weeklyMinutes} minutes per week`)+
 `${on?'':`<div class="uni-warn">🔒 ${prior} You can preview the syllabus and visit its lessons, but assessments are locked.</div>`}
 <div class="uni-card"><h3 style="margin:0">Semester study plan</h3><p class="uni-note">Follow the lesson sequence, pass the assignment, then take the mixed exam and finish the practical project. Previous v7 lesson completions count automatically.</p><div class="uni-form"><label>My target completion date<input id="uni-date" type="date" value="${S(d.target)}"></label><div class="uni-target">Estimated effort: <b>${totalTime(t)} min</b> · ${nd}/${t.lessons.length} lessons finished</div></div></div>
 ${weeklyPlan(a,i)}<div class="uni-section">Required reading & lesson quizzes</div><div class="uni-lessonlist">${t.lessons.map((id,n)=>{const l=LES(id),su=subjectOf(id);return `<a href="#l-${id}" class="uni-lesson"><span class="uni-check">${state.done[id]?'✅':(n+1)+'.'}</span><div><b>${S(l.title)}</b><small>${S(su?.name||'Academy')} · ${S(LEVEL(id))} · ${l.mins} min</small></div><span>›</span></a>`;}).join("")}</div>
 <div class="uni-section">Graded assessments</div>${[
   ["assignment","📝","Applied assignment",ready&&on?"6 practice questions + a written reflection":"Finish every required lesson quiz first."],
   ["exam","📋","Cumulative mixed exam",passes(a,i,"assignment")&&on?"14 mixed questions · pass at 70%":"Pass this semester's assignment first."],
   ["capstone","🧪","Applied project & self-review",passes(a,i,"exam")&&on?"4 evidence milestones + knowledge checks + rubric":"Pass the mixed exam first."]
 ].map(([type,icon,name,desc])=>{
  const pass=passes(a,i,type), enabled=gate(a,i,type), r=record(a,i,type), qs=type==="capstone"?`uni-capstone-${i}`:`uni-assess-${type}-${i}`;
  return `<div class="uni-assessment"><div><span class="uni-kicker">${icon} ${S(name)}</span><h3>${PCT(r.best)} ${pass?'· Passed':'· Not yet passed'}</h3><small>${S(desc)}</small><small>${r.history.length} submitted attempt${r.history.length===1?'':'s'}</small></div>${enabled?`<a class="gbtn" href="#${qs}">${pass?'Review / retry':'Open'} ›</a>`:badge(false,'🔒 Locked')}</div>`;
 }).join("")}
 <div class="uni-card"><h3 style="margin:0">Semester decision</h3><p class="uni-note">${finished(a,i)?`✅ All assessment requirements met. Weighted personal-practice grade: ${PCT(grade(a,i))}. ${i<3?'Your next semester is unlocked.':'Your four-semester pathway is complete!'}`:"An assignment, exam and project score of at least 70% each is required. You can retry without losing your best grade."}</p><a class="gbtn alt" href="#uni-transcript">View gradebook ›</a></div>`;
 $("#uni-date").onchange=e=>{d.target=e.target.value;save();};
}
function rng(seed){let x=seed|0;return ()=>{x^=x<<13;x^=x>>>17;x^=x<<5;return (x>>>0)/4294967296;};}
function strSeed(s){let h=2166136261;for(let i=0;i<s.length;i++)h=Math.imul(h^s.charCodeAt(i),16777619);return h>>>0;}
function shuffled(arr,rand){const a=arr.slice();for(let i=a.length-1;i>0;i--){let j=Math.floor(rand()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;}
function buildQuestions(a,i,type,attempt){
 const t=a.terms[i], random=rng(strSeed(`${a.id}|${i}|${type}|${attempt}`)), questions=[];
 if(type==="assignment")t.spec.questions.forEach((v,k)=>questions.push({type:"new",q:v[0],o:v.slice(1,5),a:0,why:v[5],ref:"Applied case study"}));
 const ids=shuffled(t.lessons,random), target=type==="exam"?14:6;
 const usedQ=new Set(); let j=0;
 while(questions.length<target && j<120){
   const id=ids[j%ids.length],l=LES(id);j++;if(!l||!l.quiz.length)continue;
   const choices=shuffled(l.quiz.map((_,n)=>n).filter(qi=>!usedQ.has(id+":"+qi)),random);
   if(!choices.length)continue;
   const qi=choices[0];usedQ.add(id+":"+qi);questions.push({type:"lesson",lid:id,qi,ref:l.title});
 }
 return shuffled(questions,random).map(q=>({...q,order:shuffled([0,1,2,3],random)}));
}
function resolveQ(x){const q=x.type==="new"?x:LES(x.lid)?.quiz[x.qi];if(!q)return null;return {...q,ref:x.ref,order:x.order};}
function draft(a,i,type){const d=termData(a,i); if(!d.drafts[type]) {
 const count=(record(a,i,type).history||[]).length;
 d.drafts[type]={started:Date.now(),qs:buildQuestions(a,i,type,count),answers:{},reflection:""};save();
 }return d.drafts[type];}
function submitResult(a,i,type,scoreVal,meta={}){
 const d=termData(a,i), rec=record(a,i,type);
 rec.history.push({when:Date.now(),score:scoreVal,...meta});rec.best=Math.max(scoreVal,rec.best==null?0:rec.best);
 d.results[type]=rec;delete d.drafts[type];save();checkAch();
 if(scoreVal>=PASS){SFX.good();toast2("🎓",`${type==='exam'?'Exam':type==='assignment'?'Assignment':'Project'} passed`,`${scoreVal}% · your best result is saved`);}
 else{SFX.bad();toast2("📚","Keep practicing",`${scoreVal}% · review and try again`);}
}
function renderAssessment(type,i,review=false){
 const a=active(),t=a.terms[i];if(!t||!["assignment","exam"].includes(type))return renderUni();
 if(!gate(a,i,type)){location.hash=`uni-term-${i}`;return;}
 const d=draft(a,i,type),rec=record(a,i,type),ttl=type==="exam"?"Cumulative mixed exam":"Applied assignment",qs=d.qs.map(resolveQ),answered=Object.keys(d.answers).length;
 scr().innerHTML=lead(`${type==='exam'?'📋':'📝'} ${ttl}`,`uni-term-${i}`,`${S(t.name)} · ${qs.length} questions · 70% to pass · practice only`)+
 `<div class="uni-card"><p class="uni-note" style="margin:0">${type==='exam'?"This is a mixed, unproctored exam drawn from the semester's actual lesson quizzes. Choices are reshuffled for every attempt.":`${S(t.spec.context)} Two original scenario questions are combined with lesson-based checks.`} Your selected answers are saved as a draft on this device; results and explanations appear after submission.</p><div class="uni-progress"><i style="width:${Math.round(answered/qs.length*100)}%"></i></div><small>${answered}/${qs.length} answered · best previous score ${PCT(rec.best)}</small></div>
 ${qs.map((q,n)=>q?`<fieldset class="uni-q"><legend><span class="uni-kicker">QUESTION ${n+1} / ${qs.length} · ${S(q.ref)}</span><b>${S(q.q)}</b></legend><div class="uni-opts">${q.order.map((idx,oi)=>`<button type="button" class="uni-option ${d.answers[n]===idx?'selected':''}" data-n="${n}" data-choice="${idx}" aria-pressed="${d.answers[n]===idx}"><span>${String.fromCharCode(65+oi)}</span>${S(q.o[idx])}</button>`).join('')}</div></fieldset>`:'').join("")}
 ${type==='assignment'?`<div class="uni-card"><h3>Short written reflection</h3><p class="uni-note">Describe one mistake you avoided, a calculation or assumption you checked, and how the lesson would apply beyond the example. This writing is saved but <b>not automatically graded for quality</b>.</p><textarea id="uni-reflect" class="uni-textarea" placeholder="My reflection…">${S(d.reflection)}</textarea><small>At least 25 characters: ${d.reflection.trim().length} written</small></div>`:''}
 <button class="gbtn uni-full" id="uni-submit" ${answered!==qs.length||(type==='assignment'&&d.reflection.trim().length<25)?'disabled':''}>Submit for grading · ${answered}/${qs.length}</button><div class="uni-disclaimer">Once submitted, your attempt cannot be edited. You can start another attempt; your best score is retained.</div>`;
 scr().querySelectorAll('[data-choice]').forEach(b=>b.onclick=()=>{
  const y=scrollY;d.answers[+b.dataset.n]=+b.dataset.choice;save();renderAssessment(type,i);window.scrollTo(0,y);
 });
 if(type==='assignment')$('#uni-reflect').oninput=e=>{d.reflection=e.target.value;save();const ok=Object.keys(d.answers).length===qs.length&&d.reflection.trim().length>=25;$('#uni-submit').disabled=!ok;};
 $('#uni-submit').onclick=()=>{
  if(Object.keys(d.answers).length!==qs.length||(type==='assignment'&&d.reflection.trim().length<25))return;
  const correct=qs.reduce((n,q,j)=>n+Number(+d.answers[j]===q.a),0),scoreVal=Math.round(100*correct/qs.length);
  const snap={score:scoreVal,correct,total:qs.length,answers:{...d.answers},qs:d.qs,reflection:type==='assignment'?d.reflection:null};
  submitResult(a,i,type,scoreVal,{correct,total:qs.length,reflection:type==='assignment'?d.reflection:null});
  renderFeedback(type,i,snap);
 };
}
function renderFeedback(type,i,snap){
 const a=active(),qs=snap.qs.map(resolveQ),done=snap.score>=PASS;
 scr().innerHTML=lead(done?"✅ Assessment passed":"📚 Review your attempt",`uni-term-${i}`,`${snap.correct} / ${snap.total} correct · ${snap.score}% · best ${PCT(score(a,i,type))}`)+
 `<div class="uni-hero"><h2>${done?'Nicely done':'Keep working at it'}</h2><p>${done?'Your next requirement is available.':'Review these explanations and try a new question mix.'} Practice scores are saved in the local gradebook.</p></div>
 ${qs.map((q,j)=>`<div class="uni-q uni-review"><div class="uni-kicker">QUESTION ${j+1} · ${S(q.ref)}</div><b>${S(q.q)}</b><p class="${+snap.answers[j]===q.a?'uni-good':'uni-bad'}">Your answer: ${S(q.o[snap.answers[j]])} ${+snap.answers[j]===q.a?'✓':'✕'}</p><p><b>Correct:</b> ${S(q.o[q.a])}</p><small>${S(q.why||'Review the linked lesson to understand this answer.')}</small></div>`).join("")}
 <a class="gbtn uni-full" href="#uni-term-${i}">Return to semester</a><button class="gbtn alt uni-full" id="uni-retake">Try a fresh attempt</button>`;
 $('#uni-retake').onclick=()=>renderAssessment(type,i);
}
function capDraft(a,i){const d=termData(a,i); if(!d.drafts.capstone){
 const attempt=record(a,i,'capstone').history.length;
 const pool=buildQuestions(a,i,'assignment',attempt+1234);
 const authored=pool.filter(q=>q.type==='new'), fromLessons=pool.filter(q=>q.type==='lesson');
 const qs=[authored[0],fromLessons[0],authored[1],fromLessons[1]]; // scenario reasoning + lesson transfer
 d.drafts.capstone={started:Date.now(),responses:["","","",""],answers:{},rubric:{},qs};save();}
 return d.drafts.capstone;
}
function renderCapstone(i){
 const a=active(),t=a.terms[i];if(!t)return renderUni();if(!gate(a,i,'capstone')){location.hash=`uni-term-${i}`;return;}
 const d=capDraft(a,i),qs=d.qs.map(resolveQ),r=record(a,i,'capstone');
 const full=()=>d.responses.every(v=>v.trim().length>=40)&&qs.every((q,j)=>d.answers[j]!=null)&&RUBRIC.every((_,j)=>d.rubric[j]>=1&&d.rubric[j]<=4);
 scr().innerHTML=lead("🧪 Applied semester project",`uni-term-${i}`,`${S(t.spec.title)} · 4 evidence milestones · independent practice work`)+
 `<div class="uni-hero"><div class="uni-kicker">SIMULATED CASE STUDY</div><h2>${S(t.spec.title)}</h2><p>${S(t.spec.context)}</p></div><div class="uni-card"><b>How your project is scored</b><p class="uni-note">Four knowledge checks count for 60%. Your own four rubric ratings count for 40% (self-assessment, <b>not independent grading</b>). Each milestone also requires written evidence, but the app can check only that you wrote it, not whether it is high quality. A score of 70% passes this self-directed exercise.</p><small>Best previous score: ${PCT(r.best)} · ${r.history.length} submitted attempts</small></div>
 ${t.spec.milestones.map((m,j)=>`<div class="uni-card uni-milestone"><span class="uni-kicker">MILESTONE ${j+1} / 4</span><h3>${S(m)}</h3><label>My evidence and reasoning <small>(minimum 40 characters)</small><textarea class="uni-textarea" data-note="${j}" placeholder="Explain your steps, assumptions and decisions…">${S(d.responses[j])}</textarea></label><div class="uni-q" style="margin-top:14px"><b>${S(qs[j].q)}</b><div class="uni-opts">${qs[j].order.map((idx,oi)=>`<button class="uni-option ${d.answers[j]===idx?'selected':''}" data-check="${j}" data-choice="${idx}" aria-pressed="${d.answers[j]===idx}"><span>${String.fromCharCode(65+oi)}</span>${S(qs[j].o[idx])}</button>`).join('')}</div></div></div>`).join('')}
 <div class="uni-section">Project quality rubric · your own assessment</div><div class="uni-card"><p class="uni-note">Rate each criterion honestly after reviewing your evidence: 1 = needs major revision, 2 = developing, 3 = meets expectations, 4 = strong with evidence.</p>${RUBRIC.map(([name,hint],j)=>`<div class="uni-rubric"><div><b>${S(name)}</b><small>${S(hint)}</small></div><div class="uni-rating">${[1,2,3,4].map(n=>`<button data-r="${j}" data-v="${n}" class="${d.rubric[j]===n?'selected':''}" aria-pressed="${d.rubric[j]===n}">${n}</button>`).join('')}</div></div>`).join('')}</div>
 <button class="gbtn uni-full" id="uni-cap-submit" ${full()?'':'disabled'}>Submit project for practice scoring</button><p class="uni-note">Your writing, choices and self-ratings are saved locally while you work. Submit only after checking your work.</p>`;
 const sub=$('#uni-cap-submit');
 scr().querySelectorAll('[data-note]').forEach(x=>x.oninput=e=>{d.responses[+x.dataset.note]=e.target.value;save();sub.disabled=!full();});
 scr().querySelectorAll('[data-check]').forEach(b=>b.onclick=()=>{const y=scrollY;d.answers[+b.dataset.check]=+b.dataset.choice;save();renderCapstone(i);scrollTo(0,y);});
 scr().querySelectorAll('[data-r]').forEach(b=>b.onclick=()=>{const y=scrollY;d.rubric[+b.dataset.r]=+b.dataset.v;save();renderCapstone(i);scrollTo(0,y);});
 sub.onclick=()=>{if(!full())return;
  const correct=qs.filter((q,j)=>+d.answers[j]===q.a).length;
  const knowledge=15*correct,quality=Math.round(Object.values(d.rubric).reduce((sum,v)=>sum+Number(v),0)/16*40);
  const points=knowledge+quality,review={correct,knowledge,quality,answers:{...d.answers},qs:d.qs,rubric:{...d.rubric},responses:d.responses.slice()};
  submitResult(a,i,'capstone',points,{knowledge,quality,correct,rubric:{...d.rubric},evidence:d.responses.slice()});
  scr().innerHTML=lead("🧪 Project review",`uni-term-${i}`,`${points}% personal-practice score · knowledge checks ${correct}/4 correct`)+
    `<div class="uni-hero"><h2>${points>=PASS?'Project marked complete':'Revise and resubmit'}</h2><p>Knowledge checks: ${knowledge}/60. Your self-review: ${quality}/40. This is not an instructor-verified project grade.</p></div>
    ${qs.map((q,j)=>`<div class="uni-q"><b>Milestone ${j+1}: ${S(t.spec.milestones[j])}</b><p class="${+review.answers[j]===q.a?'uni-good':'uni-bad'}">${+review.answers[j]===q.a?'✓ Correct':'✕ Review this concept'}</p><small>${S(q.why||'Use your lesson notes to check your reasoning.')}</small><p class="uni-note" style="white-space:pre-wrap">${S(review.responses[j])}</p></div>`).join('')}
    <a class="gbtn uni-full" href="#uni-term-${i}">Back to semester</a><button class="gbtn alt uni-full" id="uni-retry-cap">Revise with a new attempt</button>`;
  $('#uni-retry-cap').onclick=()=>renderCapstone(i);
 };
}
function renderTranscript(){
 const a=active(),earned=a.terms.filter((_,i)=>finished(a,i)).length, grades=a.terms.map((t,i)=>({i,t,pass:finished(a,i),grade:grade(a,i)}));
 const vals=grades.filter(g=>g.pass).map(g=>g.grade), avg=vals.length?Math.round(vals.reduce((x,y)=>x+y,0)/vals.length):null;
 scr().innerHTML=lead("📊 University gradebook","uni","Your cumulative self-directed work, including historical attempts and assessment requirements.")+
 `<div class="uni-hero"><div class="uni-kicker">PERSONAL LEARNING TRANSCRIPT · UNOFFICIAL</div><h2>${S(a.p.name)}</h2><div class="uni-metrics"><span><b>${earned}/4</b> semesters completed</span><span><b>${PCT(avg)}</b> completed-term average</span><span><b>${a.terms.reduce((n,t)=>n+t.lessons.filter(id=>state.done[id]).length,0)}</b> lessons done</span></div></div>
 <div class="uni-card"><div class="uni-tablewrap"><table class="uni-table"><thead><tr><th>Semester</th><th>Lessons</th><th>Assignment</th><th>Exam</th><th>Project*</th><th>Weighted</th><th>Status</th></tr></thead><tbody>${grades.map(({i,t,pass,grade:g})=>`<tr><td><a href="#uni-term-${i}">${i+1}. ${S(t.name)}</a></td><td>${lessonsDone(a,i)}/${t.lessons.length}</td><td>${PCT(score(a,i,'assignment'))}</td><td>${PCT(score(a,i,'exam'))}</td><td>${PCT(score(a,i,'capstone'))}</td><td>${PCT(g)}</td><td>${pass?'Completed':'In progress'}</td></tr>`).join('')}</tbody></table></div><p class="uni-note">* Project mark includes a self-assessment component. Weighted term score = 25% assignment + 50% mixed exam + 25% project. Completion requires at least 70% on each element, regardless of weighted average.</p></div>
 <div class="uni-section">Assessment attempt history</div><div class="uni-card">${grades.map(g=>`<details class="uni-history"><summary>Semester ${g.i+1} · ${S(g.t.name)} · ${g.pass?'Complete':'In progress'}</summary>${['assignment','exam','capstone'].map(type=>{const attempts=record(a,g.i,type).history;return `<div class="uni-history-item"><b>${type==='capstone'?'Project (self-reviewed)':type==='exam'?'Mixed exam':'Applied assignment'}</b>${attempts.length?attempts.map((x,j)=>`<small>Attempt ${j+1} · ${PCT(x.score)} · ${stamp(x.when)}${type==='capstone'?' · '+(x.correct||0)+'/4 knowledge checks':''}</small>`).join(''):`<small>Not attempted</small>`}</div>`;}).join('')}</details>`).join('')}</div>
 <div class="uni-section">Export your learning record</div><div class="uni-card"><div class="uni-actions"><button class="gbtn" id="uni-csv">⬇️ Download transcript (.csv)</button><button class="gbtn alt" id="uni-json">⬇️ Download full record (.json)</button></div><p class="uni-note">Both exports are local downloads. The full JSON includes your saved written evidence and assessment history for this pathway; review it before sharing.</p></div>
 <div class="uni-disclaimer"><b>Important:</b> This document is a personal practice record, not an official transcript. No academic credit, degree, recognized certification, professional licence or employer-verified competence is awarded. Grades come from unproctored knowledge checks and self-reviewed projects.</div>`;
 $('#uni-csv').onclick=()=>{
  const csv=[["Loonie Academy Personal University — UNOFFICIAL SELF-DIRECTED PRACTICE RECORD"],["Program",a.p.name],["Specialization",subjName(a.focus)],["Exported",new Date().toISOString()],[],["Semester","Title","Lessons completed","Total lessons","Assignment %","Exam %","Project % (self-reviewed)","Weighted %","Status"],...grades.map(g=>[g.i+1,g.t.name,lessonsDone(a,g.i),g.t.lessons.length,score(a,g.i,'assignment')??'',score(a,g.i,'exam')??'',score(a,g.i,'capstone')??'',g.grade??'',g.pass?'Completed':'In progress'])].map(r=>r.map(c=>'"'+String(c).replace(/"/g,'""')+'"').join(',')).join('\r\n');
  downloadUni(`loonie-university-transcript-${a.id.replace(':','-')}.csv`,csv,'text/csv;charset=utf-8');
 };
 $('#uni-json').onclick=()=>downloadUni(`loonie-university-record-${a.id.replace(':','-')}.json`,JSON.stringify({title:'Unofficial personal learning record',version:UNI_VERSION,exportedAt:new Date().toISOString(),planId:a.id,program:a.p.name,specialization:a.focus,semesters:grades.map(g=>({semester:g.i+1,title:g.t.name,lessonIds:g.t.lessons,complete:g.pass,grade:g.grade})),saved:a.pr,notice:'Practice only: unproctored checks and self-reviewed projects. No accredited credential.'},null,2),'application/json');
}
function downloadUni(filename,body,mime){const u=URL.createObjectURL(new Blob([body],{type:mime}));const link=document.createElement('a');link.href=u;link.download=filename;document.body.appendChild(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(u),2500);}
function addEntry(){const old=viewLearn;viewLearn=function(){old();const target=$('.tracktabs',scr());if(target)target.insertAdjacentHTML('beforebegin',`<a class="pcard uni-entry" href="#uni"><div class="ic">🎓</div><div><b>Personal University · v8</b><span>Choose a pathway, study by semester, submit assignments, sit mixed exams and build a portfolio</span></div><div class="go">›</div></a>`);};
 const prev=viewMe;viewMe=function(){prev();const grid=$('.statgrid',scr());if(grid)grid.insertAdjacentHTML('afterend',`<a class="pcard uni-entry" href="#uni-transcript"><div class="ic">📊</div><div><b>University gradebook</b><span>Practice transcript, achievements and local exports</span></div><div class="go">›</div></a>`);};}
function validate(){
 const errs=[];for(const p of PROGRAMS){const focuses=p.id==='trade'?TRADE_IDS():p.id==='open'?SUBJECTS.map(x=>x.id):[p.focus];for(const focus of focuses){const terms=planTerms(p,focus),all=terms.flatMap(t=>t.lessons);if(terms.length!==4||terms.some(x=>x.lessons.length<5))errs.push('too few lessons '+p.id+':'+focus);if(new Set(all).size!==all.length)errs.push('duplicate lessons '+p.id+':'+focus);if(all.some(x=>!LES(x)))errs.push('invalid lesson ID '+p.id+':'+focus);if(terms.some(t=>t.spec.milestones.length!==4||t.spec.questions.length!==2))errs.push('invalid case '+p.id+':'+focus);}}
 return {ok:!errs.length,errors:errs,programs:PROGRAMS.length,subjects:SUBJECTS.length,lessons:LESSONS.length,questionCount:LESSONS.reduce((n,l)=>n+l.quiz.length,0)};
}
init();addEntry();
Object.assign(V4,{uni:renderUni,"uni-transcript":renderTranscript});
V4P.push(["uni-term-",x=>renderTerm(+x)],["uni-assess-",x=>{const m=/^(assignment|exam)-(\d+)$/.exec(x);return m?renderAssessment(m[1],+m[2]):renderUni();}],["uni-capstone-",x=>renderCapstone(+x)]);
const oldTab=tabFor;tabFor=function(h){return h.startsWith('uni')?'learn':oldTab(h);};
ACH.push(["uni-sem1","🎓","University Freshman","Complete your first Personal University semester",()=>{const a=active();return finished(a,0);}],["uni-grad","🏛️","University Explorer","Complete all four self-directed semesters",()=>{const a=active();return a.terms.every((_,i)=>finished(a,i));}]);
window.LOONIE_V8={version:UNI_VERSION,validate,planTerms,active,finished,score,grade,gate,buildQuestions,resolveQ,renderUni,renderTerm,renderAssessment,renderCapstone,renderTranscript};
})();
