@echo off
setlocal
cd /d "%~dp0"
echo Building Loonie Academy Android debug APK from the v12 app files...
where npm >nul 2>&1 || (echo ERROR: Install Node.js 22 LTS first. & exit /b 1)
call npm install || exit /b 1
call npm run prepare:web || exit /b 1
if not exist android\gradlew.bat (
  call npx cap add android || exit /b 1
)
call npx cap sync android || exit /b 1
cd android
call gradlew.bat assembleDebug || exit /b 1
echo.
echo APK created at android-build-kit\android\app\build\outputs\apk\debug\app-debug.apk
pause
