LOONIE ACADEMY v13 — ANDROID APK BUILD KIT (NO HOSTING REQUIRED)
===============================================================
This is an Android-ready Capacitor project scaffold, NOT a prebuilt APK.
It packages the 21 static website/PWA assets directly into a native Android
WebView wrapper. There is no public web hosting, login or website URL needed
for the core app. Developer builds still require internet to download tools.

RECOMMENDED WINDOWS METHOD
1. Extract the ENTIRE v13 ZIP (keep android-build-kit next to index.html).
2. Install current Node.js 22 LTS and Android Studio with Android SDK installed.
   Capacitor 8 documentation requires a recent Android Studio (2025.2.1+) and
   supports Android 7.0/API 24 or newer.
3. Double-click android-build-kit/build-debug-apk.bat.
   Or open a terminal in android-build-kit and run:
       npm install
       npm run prepare:web
       npx cap add android
       npx cap sync android
       cd android
       gradlew.bat assembleDebug
4. Find the built file at:
       android-build-kit/android/app/build/outputs/apk/debug/app-debug.apk
5. Transfer app-debug.apk to your Android phone, open it, and permit
   installing an app from that file manager/source when Android prompts.
6. Test while online first and then with airplane mode enabled. The core
   lessons, Kingdom, Inquiry, University, Career, and Life features are local.

IF YOU ALREADY GENERATED THE ANDROID PROJECT
- Do NOT run `npx cap add android` again.
- After modifying site files, run `npm run android:sync` and rebuild.

ALTERNATIVE CLOUD BUILD
- The root ZIP also includes .github/workflows/build-android-debug.yml.
- Upload the complete extracted project to a PRIVATE GitHub repository,
  then trigger the Build Loonie Academy APK workflow (Actions tab).
- The resulting APK appears as a workflow artifact; no Android Studio
  installation is needed on your computer, but GitHub/network are needed.
  A debug build's key may vary across environments; make backups before
  replacing/uninstalling any test APK.

IMPORTANT LIMITATIONS
- No APK compiled or physically installed by ChatGPT in this environment:
  Android SDK is unavailable here. Treat all physical Android operation,
  local file downloads/backup sharing, native WebView storage behavior,
  and actual airplane-mode launching as UNVERIFIED until you test them.
- The optional historical Python playground downloads a remote runtime
  the first time, and Google Fonts use a network when not cached. Standard
  game lessons and new v8-v13 feature modules are bundled locally.
- Capacitor's app storage is separate from browser/PWA data. To migrate
  data from an old browser copy, export its Academy backup and restore
  it INSIDE the Android app after installation.
- Never clear the app's storage or uninstall without exporting backups.
- This is a DEBUG APK for personal testing, not a Play Store release. A
  production release needs an owner-controlled keystore, a stable package
  ID/signing certificate, release QA, privacy review and store compliance.
- All earnings and expenses in Loonie Life are fictional educational figures.

OFFICIAL DOCUMENTATION
Capacitor: https://capacitorjs.com/docs/android
Android APK builds: https://developer.android.com/build/building-cmdline
