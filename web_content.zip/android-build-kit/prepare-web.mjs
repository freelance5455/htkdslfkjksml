/* Local-only staging: copies EVERY REQUIRED PWA ASSET into www for Capacitor.
   Run from android-build-kit after extracting the COMPLETE v13 ZIP. */
import { copyFileSync, existsSync, mkdirSync, readFileSync } from 'node:fs';
import { join, dirname, resolve } from 'node:path';
const base=resolve(import.meta.dirname,'..');
const dest=resolve(import.meta.dirname,'www');
const names=[
  'index.html', 'curriculum-v6.js', 'curriculum-v7.js',
  'university-v8.js','university-v8.css','inquiry-v9.js','inquiry-v9.css',
  'kingdom-v10.js','kingdom-v10.css','career-v11.js','career-v11.css',
  'life-v12.js','life-v12.css','curriculum-v13.js','academy-v13.js','academy-v13.css','sw.js','manifest.webmanifest',
  'icon-192.png','icon-512.png','icon-maskable-512.png'
];
for(const name of names){
  const src=join(base,name),to=join(dest,name);
  if(!existsSync(src))throw new Error(`Missing Loonie Academy file: ${name}. Extract the WHOLE ZIP.`);
  mkdirSync(dirname(to),{recursive:true});copyFileSync(src,to);
}
const index=readFileSync(join(dest,'index.html'),'utf8');
for(const asset of names.filter(x=>x.endsWith('.js')||x.endsWith('.css'))){
  if(asset==='sw.js')continue;
  if(!index.includes(asset))throw new Error('App does not reference expected core asset '+asset);
}
console.log(`Prepared ${names.length} offline-first app files for Android in ${dest}`);
