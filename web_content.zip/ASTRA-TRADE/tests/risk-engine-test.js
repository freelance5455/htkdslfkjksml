'use strict';
const assert = require('node:assert/strict');
const RE = require('../js/risk/risk-engine.js');
const TT = require('../js/trading/transaction-types.js');

const NOW = 1_800_000_000_000;
const fresh = { providerId: 'BINANCE_SPOT', freshness: 'FRESH', timestamp: NOW - 1000, isBrokerQuote: false };
const flex = (o) => Object.assign({ transactionType: 'FLEX', direction: 'BUY', amountIDR: 20000, durationMinutes: 1, quote: fresh }, o || {});
const ev = (i, c, l) => RE.evaluate(i, Object.assign({ mode: 'DRY_RUN', now: NOW }, c || {}), l);
const ids = (r) => r.blockers.map((b) => b.id);

assert.equal(ev(flex()).ok, true, 'Intent Flex valid lolos di DRY_RUN');
assert.deepEqual(ids(ev(flex(), { emergencyStop: true })), ['emergency-stop']);
assert.ok(ids(ev(flex({ amountIDR: 500000 }))).includes('amount-limit'));
assert.ok(ids(ev(flex({ amountIDR: -5 }))).includes('amount-valid'));
assert.ok(ids(ev(flex({ quote: { freshness: 'STALE' } }))).includes('quote-fresh'));
assert.ok(ids(ev(flex({ quote: { freshness: 'UNAVAILABLE' } }))).includes('quote-fresh'));
assert.ok(ids(ev(flex({ quote: Object.assign({}, fresh, { timestamp: NOW - 200000 }) }))).includes('quote-fresh'), 'Timestamp lama dianggap tidak segar walau berlabel FRESH');
assert.ok(ids(ev(flex(), { openPositions: 1 })).includes('open-positions'));
assert.ok(ids(ev(flex(), { tradesToday: 20 })).includes('trades-per-day'));
assert.ok(ids(ev(flex(), { lastTradeAt: NOW - 10000 })).includes('cooldown'));
assert.equal(ev(flex(), { lastTradeAt: NOW - 61000 }).ok, true);
assert.ok(ids(ev(flex(), { todayLossIDR: 300000 })).includes('daily-loss'));
assert.ok(ids(ev(flex({ amountIDR: 90000 }), { todayLossIDR: 250000 })).includes('risk-within-daily-budget'), 'Kerugian terburuk tidak boleh melewati sisa batas harian');
assert.ok(ids(ev(flex(), { equity: 70, peakEquity: 100 })).includes('drawdown'));
assert.equal(ev(flex(), { equity: 95, peakEquity: 100 }).ok, true);
assert.ok(ids(ev(flex(), {}, { maxTradeAmountIDR: 10000 })).includes('amount-limit'), 'Batas pengguna dapat diubah');
assert.ok(ids(ev(flex({ direction: null }))).includes('intent-shape'));
assert.ok(ids(ev(flex({ transactionType: 'ZZZ' }))).includes('transaction-type'));

// InZone: rentang wajib, tidak memakai arah BUY/SELL.
const zone = (o) => Object.assign({ transactionType: 'INZONE', direction: null, amountIDR: 20000, zoneLower: 100, zoneUpper: 101, expiryMinutes: 1, quote: fresh }, o || {});
assert.equal(ev(zone()).ok, true);
assert.ok(ids(ev(zone({ zoneUpper: 99 }))).includes('intent-shape'));
assert.ok(ids(ev(zone({ direction: 'BUY' }))).includes('intent-shape'));
assert.ok(ids(ev(zone({ expiryMinutes: 0 }))).includes('intent-shape'));

// Forex: risiko hanya dapat dihitung bila multiplier & Stop Loss tersedia.
const fx = (o) => Object.assign({ transactionType: 'FOREX', direction: 'SELL', amountIDR: 20000, multiplier: 10, stopLossPct: 1, quote: Object.assign({}, fresh, { freshness: 'FRESH' }) }, o || {});
assert.equal(ev(fx()).ok, true);
assert.ok(ids(ev(fx({ multiplier: null }))).includes('risk-computable'), 'Tanpa multiplier risiko Forex tidak dapat dihitung → tolak');
assert.ok(ids(ev(fx({ stopLossPct: null }))).includes('risk-computable'), 'Tanpa Stop Loss risiko Forex tidak dapat dihitung → tolak');
assert.equal(ev(fx()).estimate.basis, 'ESTIMATE_MULTIPLIER_X_STOPLOSS_CAPPED_AT_MARGIN');
assert.equal(ev(fx({ multiplier: 1000, stopLossPct: 50 })).estimate.lossIDR, 20000, 'Estimasi rugi dibatasi sebesar margin');
assert.equal(ev(flex()).estimate.basis, 'ESTIMATE_STAKE_AT_RISK');
assert.equal(ev(fx({ quote: { freshness: 'DAILY_REFERENCE' } })).ok, true, 'Referensi harian boleh untuk simulasi');
assert.ok(ids(RE.evaluate(fx({ quote: { freshness: 'DAILY_REFERENCE' } }), { mode: 'LIVE', now: NOW })).includes('quote-fresh'), 'Referensi harian tidak pernah cukup untuk LIVE');

// LIVE: parameter broker hanya dipakai bila TERVERIFIKASI. Saat ini tidak ada → selalu diblokir.
const liveNow = RE.evaluate(flex(), { mode: 'LIVE', now: NOW });
assert.equal(liveNow.ok, false);
assert.ok(ids(liveNow).includes('broker-spec-verified') && ids(liveNow).includes('broker-quote'));
assert.ok(liveNow.checks.find((c) => c.id === 'broker-spec-verified').missing.includes('minAmount'));
assert.equal(RE.evaluate(flex(), { mode: 'BEBAS', now: NOW }).mode, 'LIVE', 'Mode tidak dikenal diperlakukan paling ketat');
assert.equal(ev(flex()).mode, 'DRY_RUN');
assert.match(ev(flex()).estimate.specNote, /UNVERIFIED/, 'DRY_RUN menyebut spesifikasi UNVERIFIED sebagai ESTIMATE');

// Setelah spesifikasi + kuotasi broker terbukti (hanya di test), risk engine meloloskan — membuktikan gating berbasis bukti.
for (const k of TT.liveRequired('FLEX')) TT.registerVerified({ type: 'FLEX', key: k, value: 1, evidence: 'dokumen resmi uji ' + k });
const brokerQuote = Object.assign({}, fresh, { isBrokerQuote: true, providerId: 'OLYMPTRADE' });
assert.equal(RE.evaluate(flex({ quote: brokerQuote }), { mode: 'LIVE', now: NOW }).ok, true);
assert.equal(RE.evaluate(flex({ quote: fresh }), { mode: 'LIVE', now: NOW }).ok, false, 'Tanpa kuotasi broker tetap diblokir');
TT._resetVerified();
assert.equal(RE.evaluate(flex({ quote: brokerQuote }), { mode: 'LIVE', now: NOW }).ok, false);
console.log('PASS: risk-engine (emergency, nominal, freshness, posisi, harian, cooldown, drawdown, risiko per jenis hanya dari parameter terverifikasi/ESTIMATE, LIVE diblokir tanpa bukti).');
