'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const sw = fs.readFileSync(path.join(root, 'service-worker.js'), 'utf8');
assert.match(html, /src="js\/integrations\/olymptrade-adapter\.js"/);
assert.match(sw, /'\.\/js\/integrations\/olymptrade-adapter\.js'/, 'PWA shell must cache the adapter');
const ctx = { Promise, Error, JSON, Object, String };
ctx.window = ctx;
vm.createContext(ctx);
for (const file of ['js/integrations/olymptrade-adapter.js', 'js/integrations/integration-manager.js']) {
  vm.runInContext(fs.readFileSync(path.join(root, file), 'utf8'), ctx, { filename: file });
}
(async () => {
  const A = ctx.ASTRA;
  assert.equal(A.OlympTradeAdapter.available, false);
  assert.equal(A.OlympTradeAdapter.status().connectionState, 'NOT_CONNECTED');
  assert.equal(A.OlympTradeAdapter.status().integrationState, 'UNVERIFIED');
  assert.equal(A.OlympTradeAdapter.capabilities().publicDeveloperApi, 'UNVERIFIED');
  assert.equal(A.OlympTradeAdapter.capabilities().liveExecution, 'NOT_AVAILABLE');
  assert.match(A.OlympTradeAdapter.officialLinks().website, /^https:\/\/olymptrade\.com\//);
  await assert.rejects(A.OlympTradeAdapter.connect(), (e) => e.code === 'OFFICIAL_API_UNVERIFIED');
  await assert.rejects(A.OlympTradeAdapter.getAccount(), (e) => e.code === 'ACCOUNT_READ_UNAVAILABLE');
  await assert.rejects(A.OlympTradeAdapter.placeOrder(), (e) => e.code === 'LIVE_EXECUTION_UNAVAILABLE');
  await assert.rejects(A.OlympTradeAdapter.closePosition(), (e) => e.code === 'LIVE_EXECUTION_UNAVAILABLE');
  assert.equal(A.OlympTradeAdapter.disconnect().state, 'NOT_CONNECTED');
  const item = A.Integrations.list().find((x) => x.id === 'olymptrade');
  assert.ok(item && item.available === false && item.mode === 'unverified');
  await assert.rejects(A.Integrations.connectPrivateAccount('olymptrade'), (e) => e.code === 'OFFICIAL_API_UNVERIFIED');
  console.log('PASS: Olymptrade capability gate, official links, explicit UNVERIFIED/NOT_AVAILABLE states, and safe rejection of unverified account/order operations.');
})().catch((e) => { console.error(e); process.exitCode = 1; });
