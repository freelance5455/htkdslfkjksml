'use strict';
const { readdirSync } = require('node:fs');
const { spawnSync } = require('node:child_process');
const path = require('node:path');
const files = readdirSync(__dirname).filter((f) => /-test\.js$/.test(f)).sort();
let failed = 0;
for (const f of files) {
  const r = spawnSync(process.execPath, [path.join(__dirname, f)], { encoding: 'utf8', timeout: 120000 });
  const ok = r.status === 0;
  if (!ok) failed++;
  console.log((ok ? 'PASS ' : 'FAIL ') + f + (ok ? '' : '\n' + (r.stdout || '') + (r.stderr || '')));
}
console.log(failed ? failed + ' test gagal' : 'Semua ' + files.length + ' test PASS');
process.exit(failed ? 1 : 0);
