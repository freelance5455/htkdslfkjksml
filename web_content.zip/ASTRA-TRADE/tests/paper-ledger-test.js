'use strict';
const assert = require('node:assert/strict');
const { makeStore } = require('./helpers/load-astra');
const RE = require('../js/risk/risk-engine.js');
const TT = require('../js/trading/transaction-types.js');
const PL = require('../js/ledger/paper-ledger.js');

let NOW = 1_800_000_000_000;
const MIN = 60000;
const mkStorage = (store) => ({ get: (k) => store.getItem(k), set: (k, v) => { store.setItem(k, v); return true; }, remove: (k) => store.removeItem(k) });
const store = makeStore();
const KEY = 'astra.test.paper';
const make = () => PL.create({ storage: mkStorage(store), key: KEY, riskEngine: RE, types: TT, clock: () => NOW });
let ledger = make();

const quote = { providerId: 'BINANCE_SPOT', provider: 'Binance public spot data', marketType: 'spot', freshness: 'FRESH', isBrokerQuote: false };
const sig = (o) => Object.assign({ id: 'FLEX|BTCUSDT|BUY|1', transactionType: 'FLEX', symbol: 'BTCUSDT', direction: 'BUY', priceAtSignal: 100, quote,
  params: { amountIDR: 20000, durationMinutes: 1, assumedPayoutPct: 80, market: 'BTCUSDT' } }, o || {});
const noCd = { limits: { cooldownSeconds: 0 } };

// Engine tidak pernah auto-start.
assert.equal(ledger.isRunning(), false); assert.equal(ledger.engineState(), 'STOPPED');

// --- FLEX -----------------------------------------------------------------------------------
const o1 = ledger.open(sig(), null, noCd);
assert.equal(o1.ok, true); assert.equal(o1.position.status, 'OPEN'); assert.equal(o1.position.basis, 'ESTIMATE'); assert.equal(o1.position.brokerSpecific, false);
assert.equal(o1.position.sourceId, 'BINANCE_SPOT');
assert.equal(ledger.open(sig(), null, noCd).duplicate, true, 'Idempoten: intent id sama tidak dicatat dua kali');
assert.equal(ledger.positions('FLEX', 'BINANCE_SPOT').length, 1);
assert.equal(ledger.summary('FLEX', 'BINANCE_SPOT').balance, PL.DEFAULT_START - 20000);
// Penutupan lebih awal belum terverifikasi → ditolak.
const early = ledger.settle(o1.position.id, 101, NOW + 10000);
assert.equal(early.ok, false); assert.equal(early.code, 'EARLY_CLOSE_UNVERIFIED');
// Belum jatuh tempo → settleDue tidak menyentuh.
assert.equal(ledger.settleDue(() => ({ price: 101, fresh: true }), NOW + 30000).settled.length, 0);
// Harga basi saat jatuh tempo → menunggu, tidak ditutup memakai harga lama.
const waiting = ledger.settleDue(() => ({ price: 101, fresh: false }), NOW + MIN);
assert.equal(waiting.settled.length, 0); assert.equal(waiting.waiting.length, 1);
const done = ledger.settleDue(() => ({ price: 101, fresh: true }), NOW + MIN);
assert.equal(done.settled.length, 1); assert.equal(done.settled[0].outcome, 'WIN'); assert.equal(done.settled[0].pnlIDR, 16000); assert.equal(done.settled[0].pnlBasis, 'ESTIMATE');
assert.equal(ledger.summary('FLEX', 'BINANCE_SPOT').balance, PL.DEFAULT_START + 16000);

NOW += 5 * MIN;
const lossOpen = ledger.open(sig({ id: 'FLEX|BTCUSDT|SELL|2', direction: 'SELL' }), null, noCd);
const lossDone = ledger.settle(lossOpen.position.id, 105, lossOpen.position.expiresAt);
assert.equal(lossDone.record.outcome, 'LOSS'); assert.equal(lossDone.record.pnlIDR, -20000);
NOW += 5 * MIN;
const tie = ledger.open(sig({ id: 'FLEX|BTCUSDT|BUY|3' }), null, noCd);
assert.equal(ledger.settle(tie.position.id, 100, tie.position.expiresAt).record.outcome, 'TIE_UNVERIFIED');

// Payout tidak diketahui → simulasi ditolak (tidak mengarang payout).
NOW += 5 * MIN;
const noPayout = ledger.open(sig({ id: 'x-nopay', params: { amountIDR: 20000, durationMinutes: 1, market: 'BTCUSDT' } }), null, noCd);
assert.equal(noPayout.ok, false); assert.equal(noPayout.code, 'PAYOUT_UNKNOWN');

// --- Sumber harga: Olymptrade/tanpa sumber ditolak; kuotasi basi ditolak ----------------------
assert.equal(ledger.open(sig({ id: 'o1', quote: { providerId: 'OLYMPTRADE', freshness: 'FRESH' } }), null, noCd).code, 'NO_PAPER_SOURCE');
assert.equal(ledger.open(sig({ id: 'o2', quote: { providerId: 'NONE', freshness: 'UNAVAILABLE' } }), null, noCd).code, 'NO_PAPER_SOURCE');
assert.equal(ledger.open(sig({ id: 'o3', quote: Object.assign({}, quote, { freshness: 'STALE' }) }), null, noCd).code, 'QUOTE_NOT_FRESH');
assert.equal(ledger.open(sig({ id: 'o4', quote: { providerId: 'ECB_REFERENCE', freshness: 'DAILY_REFERENCE' } }), null, noCd).code, 'QUOTE_NOT_FRESH', 'Kurs harian ECB tidak dipakai untuk membuka simulasi intraday');
assert.equal(ledger.open(sig({ id: undefined }), null, noCd).code, 'NO_ID');

// --- INZONE: ledger terpisah, dinilai pada harga kedaluwarsa ------------------------------------
NOW += 5 * MIN;
const zsig = (id, extra) => ({ id, transactionType: 'INZONE', symbol: 'BTCUSDT', direction: null, priceAtSignal: 100, quote, zone: { lower: 99, upper: 101, assessment: 'UNCERTAIN' },
  params: Object.assign({ amountIDR: 20000, expiryMinutes: 1, assumedPayoutPct: 70, market: 'BTCUSDT' }, extra || {}) });
const z1 = ledger.open(zsig('z1'), null, noCd);
assert.equal(z1.ok, true); assert.equal(z1.position.zoneLower, 99);
assert.equal(ledger.summary('FLEX', 'BINANCE_SPOT').open, 0, 'Posisi InZone tidak masuk ledger Flex');
assert.equal(ledger.positions('INZONE', 'BINANCE_SPOT').length, 1);
const zr = ledger.settleDue(() => ({ price: 100.4, fresh: true }), NOW + MIN);
assert.equal(zr.settled[0].outcome, 'WIN'); assert.equal(zr.settled[0].zone, 'IN_ZONE'); assert.equal(zr.settled[0].pnlIDR, 14000);
NOW += 5 * MIN;
const z2 = ledger.open(zsig('z2'), null, noCd);
assert.equal(ledger.settle(z2.position.id, 101.2, NOW + MIN).record.outcome, 'LOSS');
NOW += 5 * MIN;
const z3 = ledger.open(zsig('z3'), null, noCd);
const zb = ledger.settle(z3.position.id, 101, NOW + MIN);
assert.equal(zb.record.outcome, 'BOUNDARY_UNVERIFIED'); assert.equal(zb.record.pnlIDR, 0);
assert.equal(ledger.open(zsig('zbad', { zoneLower: 5, zoneUpper: 4 }) && Object.assign(zsig('zbad'), { zone: { lower: 102, upper: 101 } }), null, noCd).ok, false);

// --- FOREX: multiplier wajib, SL/TP, pnl dibatasi margin -----------------------------------------
NOW += 5 * MIN;
const fsig = (id, extra, top) => Object.assign({ id, transactionType: 'FOREX', symbol: 'EURUSD', direction: 'BUY', priceAtSignal: 1.1, quote,
  params: Object.assign({ market: 'EURUSD', amountIDR: 20000, multiplier: 10, stopLossPct: 1, takeProfitPct: 2 }, extra || {}) }, top || {});
assert.equal(ledger.open(fsig('f0', { multiplier: null }), null, noCd).code, 'MULTIPLIER_UNKNOWN');
assert.equal(ledger.open(fsig('f0b', { stopLossPct: null }), null, noCd).code, 'RISK_BLOCKED', 'Tanpa SL risiko tak dapat dihitung');
const f1 = ledger.open(fsig('f1'), null, noCd);
assert.equal(f1.ok, true); assert.ok(Math.abs(f1.position.stopLossPrice - 1.089) < 1e-9); assert.ok(Math.abs(f1.position.takeProfitPrice - 1.122) < 1e-9);
assert.equal(ledger.markToMarket('EURUSD', 1.11, NOW).closed.length, 0);
const tp = ledger.markToMarket('EURUSD', 1.123, NOW + 1000);
assert.equal(tp.closed[0].closeReason, 'TAKE_PROFIT');
assert.ok(Math.abs(tp.closed[0].pnlIDR - (1.123 - 1.1) / 1.1 * 20000 * 10) < 1e-6);
NOW += 5 * MIN;
const f2 = ledger.open(fsig('f2', {}, { direction: 'SELL' }), null, noCd);
const sl = ledger.markToMarket('EURUSD', 1.25, NOW + 1000); // rugi mentah > margin → dibatasi
assert.equal(sl.closed[0].closeReason, 'STOP_LOSS'); assert.equal(sl.closed[0].pnlIDR, -20000); assert.equal(sl.closed[0].capped, true);
NOW += 5 * MIN;
const f3 = ledger.open(fsig('f3'), null, noCd);
assert.equal(ledger.settle(f3.position.id, 1.1055, NOW + 1000).record.closeReason, 'MANUAL_CLOSE', 'Forex dapat ditutup manual');

// --- Ledger terpisah per jenis & sumber ------------------------------------------------------------
const keys = ledger.books().map((b) => b.key).sort();
assert.deepEqual(keys, ['FLEX|BINANCE_SPOT', 'FOREX|BINANCE_SPOT', 'INZONE|BINANCE_SPOT']);
const sums = ['FLEX', 'INZONE', 'FOREX'].map((t) => ledger.summary(t, 'BINANCE_SPOT'));
assert.ok(sums.every((s) => s.basis === 'ESTIMATE' && s.brokerSpecific === false && s.engine === 'STOPPED'));
assert.notEqual(sums[0].realizedPnlIDR, sums[1].realizedPnlIDR);
assert.equal(ledger.summary('FLEX', 'ECB_REFERENCE').exists, false);

// --- Persistensi: reload memulihkan data, tetap STOPPED, tanpa duplikasi ------------------------------
const before = JSON.stringify(ledger.summary('FLEX', 'BINANCE_SPOT'));
ledger = make();
assert.equal(ledger.loadInfo().restored, true); assert.equal(ledger.isRunning(), false);
assert.equal(JSON.stringify(ledger.summary('FLEX', 'BINANCE_SPOT')), before);
assert.equal(ledger.open(sig(), null, noCd).duplicate, true, 'Idempotensi bertahan setelah reload');
assert.equal(ledger.history('FLEX', 'BINANCE_SPOT').length, 3);
// Posisi terbuka juga dipulihkan.
NOW += 5 * MIN;
const keep = ledger.open(sig({ id: 'persist-open' }), null, noCd);
assert.equal(keep.ok, true);
ledger = make();
assert.equal(ledger.positions('FLEX', 'BINANCE_SPOT').length, 1);
assert.equal(ledger.positions('FLEX', 'BINANCE_SPOT')[0].intentId, 'persist-open');
assert.equal(ledger.isRunning(), false, 'Tidak ada auto-start setelah reload');

// --- Batas risiko dihubungkan ke alur paper -------------------------------------------------------
const cd = ledger.open(sig({ id: 'cool' }), null, {});
assert.equal(cd.code, 'RISK_BLOCKED'); assert.ok(cd.blockers.some((b) => b.id === 'open-positions' || b.id === 'cooldown'));
assert.equal(ledger.open(sig({ id: 'em' }), null, { ctx: { emergencyStop: true }, limits: { cooldownSeconds: 0, maxOpenPositions: 5 } }).blockers[0].id, 'emergency-stop');
assert.equal(ledger.open(sig({ id: 'big', params: { amountIDR: 5000000, durationMinutes: 1, assumedPayoutPct: 80, market: 'BTCUSDT' } }), null, { limits: { cooldownSeconds: 0, maxOpenPositions: 5 } }).ok, false);

// --- State rusak / skema tidak valid: dikarantina, mulai bersih, tidak melempar ---------------------------
for (const bad of ['{not json', JSON.stringify({ version: 1 }), JSON.stringify({ version: 2, books: { 'FLEX|X': { transactionType: 'INZONE' } } }),
  JSON.stringify({ version: 2, books: { 'FLEX|BINANCE_SPOT': { transactionType: 'FLEX', sourceId: 'BINANCE_SPOT', startBalance: 'x', balance: 1, peakEquity: 1, positions: [], history: [], seenIds: [] } } })]) {
  store.setItem(KEY, bad);
  const l = make();
  assert.equal(l.loadInfo().corrupt, true, 'State rusak terdeteksi: ' + bad.slice(0, 30));
  assert.equal(l.books().length, 0); assert.equal(l.isRunning(), false);
  assert.equal(store.getItem(KEY + '.corrupt').length > 0, true, 'Data rusak dikarantina, bukan dihapus diam-diam');
}
store.removeItem(KEY); store.removeItem(KEY + '.corrupt');
const fresh = make(); assert.equal(fresh.loadInfo().restored, false); assert.equal(fresh.loadInfo().corrupt, false);

// --- Reset eksplisit & ekspor berlabel --------------------------------------------------------------------
fresh.open(sig({ id: 'r1' }), null, noCd);
assert.equal(fresh.reset('FLEX', 'BINANCE_SPOT').existed, true); assert.equal(fresh.summary('FLEX', 'BINANCE_SPOT').exists, false);
assert.match(fresh.exportJSON(), /paper-simulation-not-broker-trades/);
console.log('PASS: paper-ledger (ledger per jenis×sumber, idempotensi, persistensi & restore STOPPED, state rusak dikarantina, payout/multiplier tidak dikarang, kuotasi non-broker/basi ditolak, SL/TP/expiry/boundary).');
