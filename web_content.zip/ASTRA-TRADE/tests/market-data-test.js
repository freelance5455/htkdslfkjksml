'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const rootDir = path.resolve(__dirname, '..');
const store = new Map();
let failRequests = false;
const symbols = ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'BNBUSDT', 'XRPUSDT', 'DOGEUSDT', 'ADAUSDT', 'LTCUSDT'];
const tickerRows = symbols.map((s, i) => ({ s, c: String(100 + i), P: '1.5', h: String(120 + i), l: String(90 + i), v: '10', q: '1000' }));
const candleRows = Array.from({ length: 30 }, (_, i) => [i * 60000, String(100 + i), String(102 + i), String(99 + i), String(101 + i), '12', i * 60000 + 59999, '1200', 20, '5', '500', '0']);
const context = {
  console, Date, Math, Number, String, Array, Object, JSON, RegExp, Promise, Map, AbortController,
  setInterval, clearInterval, setTimeout, clearTimeout,
  localStorage: {
    getItem(k) { return store.has(k) ? store.get(k) : null; },
    setItem(k, v) { store.set(k, String(v)); }, removeItem(k) { store.delete(k); },
    key(i) { return Array.from(store.keys())[i] ?? null; }, get length() { return store.size; }
  },
  fetch: async (url) => {
    if (failRequests) return { ok: false, status: 503, json: async () => ({}) };
    if (String(url).includes('/api/v3/klines?')) return { ok: true, status: 200, json: async () => candleRows };
    if (String(url).includes('/api/v3/ticker/24hr?')) return { ok: true, status: 200, json: async () => tickerRows };
    return { ok: false, status: 404, json: async () => ({}) };
  }
};
context.window = context;
vm.createContext(context);
function load(rel) { vm.runInContext(fs.readFileSync(path.join(rootDir, rel), 'utf8'), context, { filename: rel }); }
load('js/event-bus.js');
load('js/storage/storage-manager.js');
load('js/integrations/connection-status.js');
load('js/integrations/market-data-provider.js');

(async () => {
  const A = context.ASTRA;
  const initialStatus = A.MarketData.status();
  assert.equal(initialStatus.hasData, false, 'No ticker received must be distinguished from an old ticker');
  assert.equal(initialStatus.stale, false, 'Missing data must be UNAVAILABLE, not incorrectly marked STALE');
  assert.equal(initialStatus.dataStatus, 'UNAVAILABLE', 'Initial connection state must expose UNAVAILABLE data status');
  const result = await A.MarketData.refresh();
  assert.equal(result.length, 8, 'Ticker refresh should return supported public symbols');
  assert.equal(A.MarketData.get('BTCUSDT').price, 100, 'Ticker price should be normalized');
  assert.equal(A.MarketData.get('BTCUSDT').marketType, 'spot', 'Market type must be explicit');
  assert.equal(A.MarketData.status().stale, false, 'Fresh ticker must not be marked stale');
  assert.equal(A.MarketData.status().dataStatus, 'LIVE DATA', 'Fresh public spot quotes must carry an explicit data status');

  const candles = await A.MarketData.fetchCandles('BTCUSDT', '1m', 30, true);
  assert.equal(candles.length, 30, 'Historical candle response should be normalized');
  assert.equal(candles[0].close, 101, 'Candle close should be preserved');
  assert.equal(candles[0].source, 'Binance public spot klines', 'Historical source should be explicit');
  assert.equal(A.MarketData.chartHistory('BTCUSDT').kind, 'historical-1m+quote', 'Chart should distinguish candle history and latest quote');
  assert.ok(A.MarketData.history('BTCUSDT').length >= 30, 'Scanner history should contain candle closes and latest quote');
  await assert.rejects(A.MarketData.fetchCandles('FAKE', '1m', 30), /Simbol spot tidak didukung/, 'Unsupported symbols should reject');

  assert.equal(A.MarketData.isStale('BTCUSDT', Date.now() + 60000), true, 'Old quote must be marked stale');
  failRequests = true;
  await assert.rejects(A.MarketData.refresh(), /HTTP 503/, 'HTTP failures should be reported');
  assert.match(A.MarketData.status().error, /HTTP 503/, 'Failure status should be surfaced');
  assert.equal(A.MarketData.get('BTCUSDT').price, 100, 'Last received quote may remain visible but is explicitly staleness-aware');
  console.log('PASS: initial UNAVAILABLE state, public ticker normalization, explicit LIVE DATA state, candle loading, source/market-type labels, chart history, stale detection, and HTTP error reporting.');
})().catch((error) => { console.error(error); process.exitCode = 1; });
