'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const olymptradeUi = fs.readFileSync(path.join(root, 'js/app.js'), 'utf8');
assert.ok(olymptradeUi.includes('Olymptrade Account Connection') && olymptradeUi.includes('NOT_CONNECTED') && olymptradeUi.includes('UNVERIFIED'), 'Account Connection must display honest Olymptrade status');
assert.ok(!olymptradeUi.includes('Stockity'), 'The previous broker name must not remain in active UI code');
for (const [, ref] of html.matchAll(/(?:src|href)="([^"#?]+\.(?:js|css))"/g)) {
  assert.ok(fs.existsSync(path.join(root, ref)), `Missing index asset: ${ref}`);
}
for (const relative of ['js/ledger/analysis-history.js']) {
  assert.ok(html.includes(`src="${relative}"`), `New module must be loaded: ${relative}`);
}

const data = new Map();
const store = {
  getItem(k) { return data.has(k) ? data.get(k) : null; },
  setItem(k, v) { data.set(k, String(v)); },
  removeItem(k) { data.delete(k); },
  key(i) { return [...data.keys()][i] ?? null; },
  get length() { return data.size; }
};
const context = {
  console, Date, Math, Number, String, Array, Object, JSON, RegExp, Promise, Map,
  localStorage: store,
  setInterval: () => 1, clearInterval: () => {}, setTimeout, clearTimeout,
  location: { hash: '' }
};
context.window = context;
vm.createContext(context);
const load = (relative) => vm.runInContext(fs.readFileSync(path.join(root, relative), 'utf8'), context, { filename: relative });
load('js/event-bus.js');
load('js/storage/storage-manager.js');
load('js/strategy/indicators.js');
load('js/strategy/strategy-manager.js');
load('js/ai/market-scanner.js');
load('js/bot/bot-schedules.js');
load('js/bot/schedule-runner.js');
load('js/bot/trading-mode-manager.js');
load('js/risk/risk-rules.js');
load('js/ledger/analysis-history.js');

const A = context.ASTRA;
const observations = Array.from({ length: 30 }, (_, i) => 100 + i * 0.4 + Math.sin(i) * 0.1);
A.MarketData = { symbols: ['BTCUSDT'], history: () => observations.slice(), get: () => ({ stale: false }), getCandles: () => [] };
A.Storage.set('selectedMarket', 'BTCUSDT');

A.Storage.set('strategy', 'technical-trend');
const trend = A.MarketScanner.scan('BTCUSDT');
assert.equal(trend.ready, true, 'Scanner should be ready at 22+ observations');
assert.ok(trend.indicators.ema9 !== null && trend.indicators.ema21 !== null, 'EMA indicators should be computed');
assert.ok(trend.indicators.rsi14 !== null, 'RSI should be computed for sufficient observations');
assert.ok(trend.indicators.momentum5 !== null, 'Momentum should be computed');
assert.ok(trend.indicators.volatilityPct !== null, 'Return volatility should be computed');
assert.equal(trend.aiModelConnected, false, 'Scanner must not claim a connected AI model');
assert.equal(trend.orderSignal, null, 'Scanner must not invent an order signal');

A.Storage.set('strategy', 'momentum-observation');
assert.match(A.MarketScanner.scan('BTCUSDT').observation, /Momentum observasi/);
A.Storage.set('strategy', 'volatility-observation');
assert.match(A.MarketScanner.scan('BTCUSDT').observation, /Rentang sampel/);

const invalid = A.BotSchedules.save({ enabled: true, time: '25:77', days: [1] });
assert.equal(invalid.ok, false, 'Invalid schedule time must be rejected');
const noDays = A.BotSchedules.save({ enabled: true, time: '09:00', days: [] });
assert.equal(noDays.ok, false, 'Enabled schedule without selected days must be rejected');
const normalized = A.BotSchedules.save({ enabled: false, time: '09:00', days: [1, 1, 6] });
assert.equal(normalized.ok, true, 'A valid schedule should save');
assert.deepEqual(Array.from(A.Storage.get('schedule', {}).days), [1, 6], 'Duplicate days must be normalized');
const now = new Date(2026, 9, 26, 9, 0, 0);
A.Storage.set('schedule', { enabled: true, time: '09:00', days: [now.getDay()], mode: 'market-scan-only' });
let triggered = 0;
A.EventBus.on('schedule:trigger', () => { triggered++; });
const first = A.ScheduleRunner.check(now);
assert.equal(first.triggered, true, 'Schedule should run at the selected local time/day');
assert.equal(triggered, 1, 'Schedule should emit one event');
assert.equal(A.ScheduleRunner.check(now).triggered, false, 'Schedule must not trigger twice in the same minute');
assert.equal(triggered, 1, 'Duplicate check should not emit another event');

const goodConfig = A.RiskRules.validateConfig({ amountIDR: 15000, durationMinutes: 5, timerSeconds: 15, market: 'BTCUSDT', strategy: 'technical-trend' });
assert.equal(goodConfig.ok, true, 'Valid local analysis configuration should pass');
assert.equal(A.RiskRules.validateConfig({ amountIDR: 100, durationMinutes: 9, timerSeconds: 4, market: 'UNKNOWN', strategy: 'fake' }).ok, false, 'Invalid config must be rejected');
assert.equal(A.RiskRules.validateConfig({ amountIDR: 15000, durationMinutes: 15, timerSeconds: 15, market: 'BTCUSDT', strategy: 'technical-trend' }).ok, false, 'Durations outside the reference-aligned options must be rejected');
assert.equal(A.RiskRules.validateConfig({ amountIDR: 15000, durationMinutes: 5, timerSeconds: 15, market: 'BTCUSDT', strategy: 'technical-trend', botTimerMinutes: 2 }).ok, false, 'Unsupported Bot Timer duration must be rejected');
assert.equal(A.RiskRules.canExecuteOrder().ok, false, 'Live order execution must remain disabled');
for (const duration of [0.25, 1, 5]) {
  assert.equal(A.RiskRules.validateConfig({ amountIDR: 15000, durationMinutes: duration, timerSeconds: 15, market: 'BTCUSDT', strategy: 'technical-trend' }).ok, true, `Reference duration ${duration} minute(s) should be accepted`);
}
assert.equal(A.RiskRules.validateConfig({ amountIDR: 15000, durationMinutes: 5, timerSeconds: 15, market: 'BTCUSDT', strategy: 'technical-trend', martingaleEnabled: true, martingaleLevel: 'K3' }).ok, true, 'Martingale can be stored as a simulation-only preference');
assert.deepEqual(Array.from(A.TradingModeManager.available()), ['manual', 'semi-auto', 'auto'], 'All three analysis workflow modes should be available');
assert.equal(A.TradingModeManager.select('auto').executionEnabled, false, 'Trading modes must not grant broker-order permission');
A.Storage.set('botConfig', { tradingMode: 'semi-auto' });
assert.equal(A.TradingModeManager.current(), 'semi-auto', 'Trading Mode should read the saved local preference');
assert.equal(A.TradingModeManager.select('unsupported').ok, false, 'Unknown Trading Modes must be rejected');
const appSource = fs.readFileSync(path.join(root, 'js/app.js'), 'utf8');
for (const control of ['Martingale Compensation (K1–K5)', 'Bot Timer', 'Auto Trade Loop', 'Trade Interval', 'Trading Mode', 'Session Duration', 'BTCUSD_OTC', 'AI Prediction Method']) assert.ok(appSource.includes(control), `Config should expose the reviewed video feature: ${control}`);
const renderStart = appSource.indexOf('function renderConfigPanel(cfg){');
const renderEnd = appSource.indexOf('\nfunction renderTerminal(){', renderStart);
assert.ok(renderStart >= 0 && renderEnd > renderStart, 'Config renderer should exist before terminal rendering');
const uiContext = { ASTRA: { AssetList: { all: () => [{ symbol: 'BTCUSDT', ticker: 'BTC' }, { symbol: 'ETHUSDT', ticker: 'ETH' }] } }, cfg: { amountIDR: 15000, durationMinutes: 5, market: 'BTCUSDT', strategy: 'technical-trend', tradingMode: 'manual', timerSeconds: 15, autoLoop: false, autoLoopIntervalMinutes: 5, botTimerEnabled: false, botTimerMinutes: 1440, martingaleEnabled: false, martingaleLevel: 'K1' }, statusBadge: (label, kind) => `<span class=\"badge ${kind || ''}\">${label}</span>` };
vm.createContext(uiContext);
const renderedConfig = vm.runInContext('var A = ASTRA;' + appSource.slice(renderStart, renderEnd) + '; renderConfigPanel(cfg)', uiContext);
for (const control of ['Trade Amount (IDR)', 'Duration', '15 detik', 'Market / Asset', 'Execution Strategy', 'Trading Mode', 'Martingale Compensation (K1–K5)', 'Bot Timer', '1 menit', '3 menit', '24 jam', 'Auto Trade Loop', '5 menit', 'BTCUSD_OTC', 'AI Prediction Method', 'Simpan konfigurasi']) assert.ok(renderedConfig.includes(control), `Rendered Config should contain: ${control}`);
assert.ok(appSource.includes('function renderMarket(){') && appSource.includes('Crypto Composite Index') && appSource.includes('UNAVAILABLE'), 'Market Watch must retain reference OTC/index instruments with honest unavailability labels');
assert.ok(appSource.includes('function updateFeedBadge(){') && appSource.includes("txt='STALE'") && appSource.includes("txt='DISCONNECTED'"), 'Feed badge must distinguish stale data from a disconnected feed');
const configStart = appSource.indexOf('function configValue(){');
const configEnd = appSource.indexOf('\nfunction clearBotSessionTimer()', configStart);
assert.ok(configStart >= 0 && configEnd > configStart, 'Config normalization must be available');
const configCtx = { ASTRA: { Storage: { get: (key, fallback) => key === 'botConfig' ? { botTimerHours: 24, market: 'BTCUSDT' } : fallback }, AssetList: { all: () => [{ symbol: 'BTCUSDT' }] } }, state: { selectedAsset: 'BTCUSDT' } };
vm.createContext(configCtx);
const migratedConfig = vm.runInContext('var A = ASTRA;' + appSource.slice(configStart, configEnd) + '; configValue()', configCtx);
assert.equal(migratedConfig.botTimerMinutes, 1440, 'Legacy 24-hour Bot Timer should migrate to 1440 minutes');
assert.equal(migratedConfig.durationMinutes, 5, 'Reference-aligned duration should default to five minutes');
const timerAppSource = appSource;
const timerStart = timerAppSource.indexOf('function clearBotSessionTimer(){');
const timerEnd = timerAppSource.indexOf('\nfunction syncAutoLoop(', timerStart);
assert.ok(timerStart >= 0 && timerEnd > timerStart, 'Bot Timer callbacks should be available');
const timerCtx = {
  state: { botTimerHandle: null },
  root: { setTimeout(fn, ms) { this.pendingCallback = fn; this.pendingDelay = ms; return 77; }, clearTimeout(id) { this.cleared = id; } },
  A: { BotController: { isRunning: () => true, stop() { timerCtx.engineStopped = true; } }, AutoTradeLoop: { stop() { timerCtx.loopStopped = true; } } },
  toast(message) { timerCtx.toastMessage = message; }, render(screen) { timerCtx.renderedScreen = screen; }
};
vm.createContext(timerCtx);
vm.runInContext(timerAppSource.slice(timerStart, timerEnd) + '; syncBotSessionTimer({botTimerEnabled:true,botTimerMinutes:5});', timerCtx);
assert.equal(timerCtx.root.pendingDelay, 300000, 'Five-minute Bot Timer should schedule a 300000ms timeout');
assert.equal(timerCtx.state.botTimerHandle, 77, 'Bot Timer handle should be stored for cancellation');
timerCtx.root.pendingCallback();
assert.equal(timerCtx.engineStopped, true, 'Bot Timer should stop the local analysis engine');
assert.equal(timerCtx.loopStopped, true, 'Bot Timer should stop the local scan loop');
assert.match(timerCtx.toastMessage, /tidak ada order yang dikirim/i, 'Bot Timer must disclose that no orders are sent');
assert.equal(timerCtx.renderedScreen, 'terminal', 'Bot Timer completion should refresh the terminal view');
const marketStart = appSource.indexOf('function renderMarket(){');
const marketEnd = appSource.indexOf('\nfunction renderLedger(){', marketStart);
const marketCtx = {
  ASTRA: { AssetList: { all: () => [{ symbol: 'BTCUSDT', ticker: 'BTC', name: 'Bitcoin' }], get: () => ({ name: 'Bitcoin', symbol: 'BTCUSDT', icon: '₿' }) }, ConnectionStatus: { get: () => ({ lastUpdate: null, latencyMs: null }) }, Format: { time: () => '12:00', price: () => '—', pct: () => '—' } },
  REFERENCE_MARKETS: [
    { symbol: 'BTCUSD_OTC', ticker: 'BTCUSD OTC', name: 'Bitcoin OTC' }, { symbol: 'ETHUSD_OTC', ticker: 'ETHUSD OTC', name: 'Ethereum OTC' },
    { symbol: 'LTCUSD_OTC', ticker: 'LTCUSD OTC', name: 'Litecoin OTC' }, { symbol: 'CRYPTO_X', ticker: 'CRYPTO_X', name: 'Crypto Composite Index' },
    { symbol: 'NHI_X', ticker: 'NHI_X', name: 'NHI Index' }, { symbol: 'ASIA_X', ticker: 'ASIA_X', name: 'Asia Composite Index' }, { symbol: 'EUROPE_X', ticker: 'EUROPE_X', name: 'Europe Composite Index' }
  ], state: { marketSearch: '', selectedAsset: 'BTCUSDT' },
  head: () => '<header>Market</header>', escape: (v) => String(v), quote: (v) => '<button>'+v+'</button>', statusBadge: (v) => '<span>'+v+'</span>',
  currentAsset: () => null, fmtPrice: () => 'Belum tersedia', miniChart: () => ''
};
vm.createContext(marketCtx);
const renderedMarket = vm.runInContext('var A = ASTRA;' + appSource.slice(marketStart, marketEnd) + '; renderMarket()', marketCtx);
for (const name of ['Bitcoin OTC', 'Ethereum OTC', 'Litecoin OTC', 'Crypto Composite Index', 'NHI Index', 'Asia Composite Index', 'Europe Composite Index', 'UNAVAILABLE']) assert.ok(renderedMarket.includes(name), `Market Watch must render honest reference state for ${name}`);


const saved = A.AnalysisHistory.record(trend, 'test');
assert.equal(saved.ok, true, 'A real analysis observation should be recorded');
assert.equal(A.AnalysisHistory.list().length, 1, 'Observation history should persist locally');
assert.equal(A.AnalysisHistory.list()[0].classification, 'OBSERVATION_ONLY', 'Saved rows must be explicitly non-trade observations');
assert.equal(A.AnalysisHistory.record(trend, 'test').duplicate, true, 'Same symbol/strategy/minute should not duplicate');
assert.match(A.AnalysisHistory.exportJSON(), /local-analysis-observations-not-trades/);
assert.equal(A.Storage.set('exchangeApiSecret', 'not-allowed'), false, 'Secret-like storage keys must be rejected');

console.log('PASS: asset references, indicators/scanner, schedule validation and deduplication, local observations/export, config validation, live-order denial, Trading Mode persistence, reference-aligned Config rendering and durations, OTC/index UNAVAILABLE rows, Bot Timer migration/callback, and secret-key storage guard.');
