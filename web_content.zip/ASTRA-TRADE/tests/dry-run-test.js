'use strict';
const assert = require('node:assert/strict');
const { loadAstra, series } = require('./helpers/load-astra');

const files = ['js/event-bus.js', 'js/storage/storage-manager.js', 'js/trading/transaction-types.js', 'js/strategy/indicators.js', 'js/strategy/strategy-manager.js',
  'js/integrations/olymptrade-adapter.js', 'js/integrations/quote-source.js', 'js/ai/market-scanner.js', 'js/risk/risk-engine.js', 'js/risk/risk-rules.js',
  'js/ai/entry-signal.js', 'js/trading/dry-run.js', 'js/trading/live-gate.js'];
const { A } = loadAstra(files);
const NOW = 1_800_000_000_000;

// Adapter broker diganti spy: SETIAP pemanggilan fungsi (apa pun namanya) dihitung.
const calls = [];
const makeSpy = (name) => new Proxy({}, { get: (_, prop) => (typeof prop === 'string' ? (...args) => { calls.push(name + '.' + prop); return Promise.reject(new Error('spy')); } : undefined) });
A.OlympTradeAdapter = makeSpy('OlympTradeAdapter');
A.Integrations = makeSpy('Integrations');
A.BaseAdapter = makeSpy('BaseAdapter');
const fetchSpy = []; const ctxFetch = () => { fetchSpy.push(1); throw new Error('fetch tidak boleh dipanggil'); };
globalThis.fetch = ctxFetch;

const values = series('up', 40, 100);
const feed = { values, price: values[39], updatedAt: NOW - 500 };
A.MarketData = { symbols: ['BTCUSDT'], history: () => feed.values.slice(), get: () => ({ price: feed.price, updatedAt: feed.updatedAt, stale: false }), getCandles: () => feed.values.map((c) => ({ close: c })) };
A.ForexReference = { get: () => null };
// QuoteSources.describe memakai adapter hanya untuk brokerCapability → siapkan sinyal tanpa spy, lalu pasang spy.
const realAdapter = A.OlympTradeAdapter; A.OlympTradeAdapter = { capabilities: () => ({ publicMarketData: 'UNVERIFIED' }) };
let emergency = false;
A.BotController = { isEmergency: () => emergency };
const flexSig = A.EntrySignal.evaluate('BTCUSDT', { transactionType: 'FLEX', now: NOW, params: { amountIDR: 20000, durationMinutes: 1 } });
const zoneSig = A.EntrySignal.evaluate('BTCUSDT', { transactionType: 'INZONE', now: NOW, params: { zoneLower: feed.price - 5, zoneUpper: feed.price + 5, amountIDR: 20000, expiryMinutes: 1 } });
const noSig = A.EntrySignal.evaluate('BTCUSD_OTC', { transactionType: 'FLEX', now: NOW });
A.OlympTradeAdapter = realAdapter; calls.length = 0;
assert.equal(flexSig.direction, 'BUY'); assert.equal(zoneSig.status, 'ZONE_EVALUATED');

// --- Dry Run: lolos preflight, tapi nol panggilan broker -------------------------------------------------
const r1 = A.DryRun.run(flexSig, { now: NOW });
assert.equal(r1.ok, true); assert.equal(r1.record.kind, 'DRY_RUN'); assert.equal(r1.record.label, 'DRY RUN');
assert.equal(r1.record.verdict, 'PASSED_PREFLIGHT', JSON.stringify(r1.record.blockers));
assert.equal(r1.record.transactionType, 'FLEX'); assert.equal(r1.record.direction, 'BUY');
assert.equal(r1.record.brokerCalls, 0); assert.equal(r1.record.orderSent, false); assert.equal(r1.record.balanceChanged, false);
assert.equal(r1.record.liveReady, false);
assert.ok(r1.record.liveBlockers.includes('broker-spec-verified') && r1.record.liveBlockers.includes('broker-quote'), 'Kesiapan live dilaporkan terpisah dan tetap diblokir');
assert.equal(r1.record.providerId, 'BINANCE_SPOT'); assert.equal(r1.record.freshness, 'FRESH');
assert.equal(r1.record.riskEstimate.basis, 'ESTIMATE_STAKE_AT_RISK');
const r2 = A.DryRun.run(zoneSig, { now: NOW });
assert.equal(r2.record.verdict, 'PASSED_PREFLIGHT', JSON.stringify(r2.record.blockers)); assert.equal(r2.record.direction, null); assert.ok(r2.record.zone);
assert.equal(calls.length, 0, 'Dry Run tidak boleh memanggil adapter/integrasi broker sama sekali: ' + calls.join(','));
assert.equal(fetchSpy.length, 0, 'Dry Run tidak boleh melakukan request jaringan');

// --- Penolakan --------------------------------------------------------------------------------------------
const rNo = A.DryRun.run(noSig, { now: NOW });
assert.equal(rNo.record.verdict, 'REJECTED'); assert.ok(rNo.record.blockers.some((b) => b.id === 'signal-actionable'));
emergency = true;
const rEm = A.DryRun.run(Object.assign({}, flexSig, { id: 'em-1' }), { now: NOW });
assert.equal(rEm.record.verdict, 'REJECTED'); assert.ok(rEm.record.blockers.some((b) => b.id === 'risk:emergency-stop'));
emergency = false;
const rBadCfg = A.DryRun.run(Object.assign({}, flexSig, { id: 'bad-1', params: { amountIDR: 50, durationMinutes: 1, market: 'BTCUSDT' } }), { now: NOW });
assert.equal(rBadCfg.record.verdict, 'REJECTED'); assert.ok(rBadCfg.record.blockers.some((b) => b.id === 'config-valid'));
const rStale = A.DryRun.run(Object.assign({}, flexSig, { id: 'st-1', quote: Object.assign({}, flexSig.quote, { freshness: 'STALE' }) }), { now: NOW });
assert.ok(rStale.record.blockers.some((b) => b.id === 'risk:quote-fresh'));
const rBadType = A.DryRun.run({ id: 'bt', transactionType: 'ZZZ' }, { now: NOW });
assert.equal(rBadType.record.verdict, 'REJECTED');
const rLoss = A.DryRun.run(Object.assign({}, flexSig, { id: 'loss-1' }), { now: NOW, ctx: { todayLossIDR: 400000 } });
assert.ok(rLoss.record.blockers.some((b) => b.id === 'risk:daily-loss'));
assert.equal(calls.length, 0, 'Tetap nol panggilan broker setelah semua skenario penolakan');

// --- Idempotensi & pemisahan catatan ------------------------------------------------------------------------
assert.equal(A.DryRun.run(flexSig, { now: NOW }).duplicate, true);
assert.equal(A.DryRun.list('FLEX').every((r) => r.transactionType === 'FLEX' && r.kind === 'DRY_RUN'), true);
assert.equal(A.DryRun.list('INZONE').length, 1);
assert.equal(A.Storage.get('dryRunRecords', []).length, A.DryRun.list().length);
assert.equal(A.Storage.get('paperLedger.v2', null), null, 'Dry Run tidak menulis ke ledger paper');
assert.equal(A.Storage.get('analysisHistory', null), null, 'Dry Run tidak bercampur dengan observasi/transaksi');
assert.match(A.DryRun.exportJSON(), /dry-run-records-not-trades/);

// --- Live Gate: tertutup; adapter tidak disentuh --------------------------------------------------------------
const orderCalls = []; A.OlympTradeAdapter = { capabilities: () => ({ publicDeveloperApi: 'UNVERIFIED' }), placeOrder() { orderCalls.push('placeOrder'); }, connect() { orderCalls.push('connect'); }, closePosition() { orderCalls.push('close'); } };
const gate = A.LiveGate.check({ transactionType: 'FLEX', direction: 'BUY', amountIDR: 20000, durationMinutes: 1, quote: flexSig.quote }, { userConfirmedLive: true });
assert.equal(gate.ok, false); assert.equal(gate.state, 'LIVE_BLOCKED');
for (const id of ['official-api', 'automation-permission', 'account-auth', 'live-execution', 'broker-quote', 'risk-rules']) assert.ok(gate.blockers.some((b) => b.id === id), 'blocker ' + id);
(async () => {
  await assert.rejects(A.LiveGate.submitLive({ transactionType: 'FLEX', direction: 'BUY', amountIDR: 20000, durationMinutes: 1, quote: flexSig.quote }, { userConfirmedLive: true }), (e) => e.code === 'LIVE_GATE_CLOSED' && e.blockers.length > 3);
  assert.equal(orderCalls.length, 0, 'Gerbang tertutup: placeOrder/connect/close tidak dipanggil');
  assert.equal(A.RiskRules.canExecuteOrder().ok, false);
  console.log('PASS: dry-run (nol panggilan broker/jaringan, verdict & blockers, idempotensi, catatan terpisah dari paper/observasi/live) + live-gate tertutup tanpa menyentuh adapter.');
})().catch((e) => { console.error(e); process.exitCode = 1; });
