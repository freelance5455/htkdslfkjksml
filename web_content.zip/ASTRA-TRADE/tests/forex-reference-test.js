'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const rootDir = path.resolve(__dirname, '..');
const context = {
  Date, Math, Number, String, Array, Object, JSON, Promise,
  fetch: async (url) => {
    assert.match(String(url), /frankfurter\.app\/latest/);
    return { ok: true, status: 200, json: async () => ({
      base: 'USD', date: '2026-10-29', rates: { EUR: 0.9, GBP: 0.8, JPY: 150, CHF: 0.8, CAD: 1.4, AUD: 1.5, NZD: 1.7 }
    }) };
  },
  ASTRA: { EventBus: { emit() {} } }
};
context.window = context;
vm.createContext(context);
vm.runInContext(fs.readFileSync(path.join(rootDir, 'js/integrations/forex-reference-provider.js'), 'utf8'), context);
(async () => {
  const A = context.ASTRA;
  assert.equal(A.ForexReference.getAll().length, 7);
  assert.equal(A.ForexReference.status().status, 'UNAVAILABLE');
  await A.ForexReference.refresh();
  assert.ok(Math.abs(A.ForexReference.get('EURUSD').price - (1 / 0.9)) < 1e-9);
  assert.equal(A.ForexReference.get('USDJPY').price, 150);
  assert.equal(A.ForexReference.get('EURUSD').rateDate, '2026-10-29');
  assert.equal(A.ForexReference.get('EURUSD').status, 'REFERENCE RATE');
  console.log('PASS: seven major Forex reference pairs, inversion math, date and honest REFERENCE RATE status.');
})().catch((e) => { console.error(e); process.exitCode = 1; });
