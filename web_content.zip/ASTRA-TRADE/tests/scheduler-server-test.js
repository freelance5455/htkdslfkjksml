'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'astra-sched-'));
process.env.ASTRA_DATA_DIR = dir;
process.env.ASTRA_REQUIRE_VERIFICATION = '0';
const TT = require('../js/trading/transaction-types.js');
const S = require('../server/scheduler.js');
const { createServer, loadDb } = require('../server/server.js');

// 2026-10-30 09:00 WIB (Jumat) = 02:00 UTC
const T0 = Date.UTC(2026, 9, 30, 2, 0, 0);
const base = { name: 'Pagi', time: '09:00', timezone: 'Asia/Jakarta', days: [5], mode: 'dry-run', transactionType: 'FLEX', symbol: 'BTCUSDT' };

(async () => {
  // validasi
  assert.equal(S.validateSchedule({ ...base, time: '25:00' }, TT).ok, false);
  assert.equal(S.validateSchedule({ ...base, timezone: 'Mars/Olympus' }, TT).ok, false);
  assert.equal(S.validateSchedule({ ...base, days: [] }, TT).ok, false);
  assert.equal(S.validateSchedule({ ...base, days: [7] }, TT).ok, false);
  assert.equal(S.validateSchedule({ ...base, transactionType: 'MARTINGALE' }, TT).ok, false);
  const live = S.validateSchedule({ ...base, mode: 'live' }, TT);
  assert.equal(live.ok, false); assert.match(live.errors.join(' '), /LIVE_NOT_ALLOWED/);
  assert.deepEqual(S.localParts(T0, 'Asia/Jakarta'), { date: '2026-10-30', time: '09:00', day: 5 });
  assert.equal(S.localParts(T0, 'UTC').time, '02:00');

  // pemicu: zona waktu eksplisit, tanpa duplikasi, restart aman
  const triggers = [];
  const mk = () => S.create({ dataDir: dir, types: TT, now: () => T0, onTrigger: (s) => { triggers.push(s.id); return 'DRY_RUN_QUEUED'; } });
  let sch = mk();
  const up = sch.upsert('a@x.com', base); assert.equal(up.ok, true);
  assert.equal(sch.upsert('a@x.com', { ...base, mode: 'live' }).code, 'LIVE_NOT_ALLOWED');
  assert.equal(sch.tick(T0 - 60000).fired.length, 0, 'Belum waktunya (08:59 WIB)');
  assert.equal(sch.tick(T0).fired.length, 1);
  assert.equal(sch.tick(T0 + 20000).fired.length, 0, 'Menit sama tidak terpicu dua kali');
  sch = mk(); // "restart server"
  assert.equal(sch.tick(T0 + 30000).fired.length, 0, 'Setelah restart: tidak terpicu ulang pada menit yang sama');
  assert.equal(sch.tick(T0 + 3 * 3600_000).fired.length, 0, 'Tidak ada catch-up untuk jadwal yang terlewat');
  assert.equal(sch.tick(T0 + 24 * 3600_000).fired.length, 0, 'Sabtu bukan hari terjadwal');
  assert.equal(sch.tick(T0 + 7 * 24 * 3600_000).fired.length, 1, 'Jumat berikutnya terpicu');
  assert.equal(triggers.length, 2);
  const runs = sch.runsFor('a@x.com'); assert.equal(runs[0].ordersSent, 0); assert.equal(runs[0].status, 'DRY_RUN_QUEUED');
  assert.equal(sch.list('b@x.com').length, 0, 'Jadwal terisolasi per akun');
  assert.equal(sch.remove('b@x.com', up.schedule.id).ok, false);

  // Emergency Stop persisten memblokir pemicu & bertahan setelah restart
  sch.setEmergency(true);
  sch = mk();
  assert.equal(sch.isEmergency(), true);
  const T2 = T0 + 14 * 24 * 3600_000;
  assert.equal(sch.tick(T2).fired.length, 0);
  assert.equal(sch.runsFor('a@x.com')[0].status, 'SKIPPED_EMERGENCY_STOP');
  assert.equal(triggers.length, 2, 'Handler tidak dipanggil saat Emergency Stop');
  sch.setEmergency(false); assert.equal(mk().isEmergency(), false);

  // lock: satu scheduler per direktori
  const a = mk(); assert.equal(a.start(60000).ok, true);
  const lock = JSON.parse(fs.readFileSync(path.join(dir, 'scheduler.lock'), 'utf8')); assert.equal(lock.pid, process.pid);
  assert.equal(a.status().running, true); a.stop(); assert.equal(a.status().running, false);

  // HTTP: autentikasi wajib, validasi, live ditolak, emergency tidak dapat di-override klien
  loadDb();
  const server = createServer();
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const url = 'http://127.0.0.1:' + server.address().port;
  let cookie = '';
  const call = async (method, p, body) => {
    const r = await fetch(url + p, { method, headers: { 'Content-Type': 'application/json', ...(cookie ? { Cookie: cookie } : {}) }, body: body ? JSON.stringify(body) : undefined });
    const sc = r.headers.get('set-cookie'); if (sc) cookie = sc.split(';')[0];
    return { status: r.status, json: await r.json() };
  };
  assert.equal((await call('GET', '/api/scheduler')).status, 401);
  assert.equal((await call('POST', '/api/trading/emergency', { action: 'activate' })).status, 401);
  assert.equal((await call('POST', '/api/auth/register', { email: 'u@contoh.com', password: 'rahasia123', name: 'User' })).status, 201);
  assert.equal((await call('POST', '/api/auth/login', { email: 'u@contoh.com', password: 'rahasia123' })).status, 200);
  const st = await call('GET', '/api/trading/status');
  assert.equal(st.json.liveGate.state, 'LIVE_BLOCKED'); assert.equal(st.json.broker.connection, 'NOT_CONNECTED');
  assert.equal((await call('POST', '/api/scheduler', { action: 'upsert', schedule: { ...base, mode: 'live' } })).json.code, 'LIVE_NOT_ALLOWED');
  assert.equal((await call('POST', '/api/scheduler', { action: 'upsert', schedule: { ...base, time: 'xx' } })).status, 400);
  const add = await call('POST', '/api/scheduler', { action: 'upsert', schedule: base });
  assert.equal(add.status, 200);
  const lst = await call('GET', '/api/scheduler'); assert.equal(lst.json.schedules.length, 1); assert.equal(lst.json.status.running, false);
  const intent = { transactionType: 'FLEX', direction: 'BUY', amountIDR: 20000, durationMinutes: 1, quote: { freshness: 'FRESH', providerId: 'BINANCE_SPOT', timestamp: Date.now() } };
  const ok = await call('POST', '/api/trading/risk-check', { mode: 'DRY_RUN', intent });
  assert.equal(ok.json.verdict.ok, true); assert.equal(ok.json.orderSent, false);
  assert.equal((await call('POST', '/api/trading/risk-check', { mode: 'LIVE', intent })).json.verdict.ok, false);
  assert.equal((await call('POST', '/api/trading/emergency', { action: 'activate' })).json.emergencyStop, true);
  const blocked = await call('POST', '/api/trading/risk-check', { mode: 'DRY_RUN', intent, context: { emergencyStop: false } });
  assert.equal(blocked.json.verdict.blockers[0].id, 'emergency-stop', 'Klien tidak dapat menimpa Emergency Stop server');
  assert.equal((await call('POST', '/api/trading/emergency', { action: 'reset' })).json.emergencyStop, false);
  assert.equal((await call('POST', '/api/scheduler', { action: 'delete', id: add.json.schedule.id })).status, 200);
  server.close();
  console.log('PASS: scheduler-server (validasi, zona waktu, tanpa duplikasi, restart tanpa catch-up, Emergency Stop persisten, live ditolak, lock, endpoint wajib login, risk-check server).');
  process.exit(0);
})().catch((e) => { console.error(e); process.exit(1); });
