'use strict';
const assert = require('node:assert/strict');
const { loadAstra, series } = require('./helpers/load-astra');

const files = ['js/event-bus.js', 'js/storage/storage-manager.js', 'js/trading/transaction-types.js', 'js/strategy/indicators.js', 'js/strategy/strategy-manager.js',
  'js/integrations/olymptrade-adapter.js', 'js/integrations/quote-source.js', 'js/ai/market-scanner.js', 'js/ai/entry-signal.js'];
const { A } = loadAstra(files);

const NOW = 1_800_000_000_000;
const feed = {};            // symbol -> { values, price, updatedAt, stale, candles }
const forexRows = {};
A.MarketData = {
  symbols: ['BTCUSDT', 'ETHUSDT'],
  history: (s) => (feed[s] ? feed[s].values.slice() : []),
  get: (s) => (feed[s] && feed[s].price !== null ? { price: feed[s].price, updatedAt: feed[s].updatedAt, stale: !!feed[s].stale } : null),
  getCandles: (s) => (feed[s] && feed[s].candles ? feed[s].candles.slice() : [])
};
A.ForexReference = { get: (s) => forexRows[s] || null };
function setCrypto(sym, kind, opts = {}) {
  const values = series(kind, 40, 100);
  feed[sym] = { values, price: values[values.length - 1], updatedAt: NOW - (opts.ageMs ?? 1000), stale: !!opts.stale,
    candles: values.map((c) => ({ close: c })) };
}

// --- Provenance: tiga sumber tidak boleh tertukar -------------------------------------------
setCrypto('BTCUSDT', 'up');
const q = A.QuoteSources.describe('BTCUSDT', NOW);
assert.equal(q.providerId, 'BINANCE_SPOT'); assert.equal(q.marketType, 'spot'); assert.equal(q.isBrokerQuote, false); assert.equal(q.freshness, 'FRESH');
forexRows.EURUSD = { price: 1.08, updatedAt: NOW - 3600_000, rateDate: '2026-10-29' };
const fx = A.QuoteSources.describe('EURUSD', NOW);
assert.equal(fx.providerId, 'ECB_REFERENCE'); assert.equal(fx.marketType, 'reference-daily'); assert.equal(fx.freshness, 'DAILY_REFERENCE'); assert.equal(fx.isBrokerQuote, false);
const otc = A.QuoteSources.describe('BTCUSD_OTC', NOW);
assert.equal(otc.providerId, 'NONE'); assert.equal(otc.freshness, 'UNAVAILABLE');
const bq = A.QuoteSources.brokerQuote('BTCUSDT');
assert.equal(bq.available, false); assert.equal(bq.providerId, 'OLYMPTRADE'); assert.equal(bq.status, 'UNVERIFIED');
assert.notEqual(q.providerId, bq.providerId, 'Binance bukan Olymptrade');
assert.notEqual(fx.providerId, bq.providerId, 'ECB bukan Olymptrade');

// --- FLEX: BUY / SELL ------------------------------------------------------------------------
const buy = A.EntrySignal.evaluate('BTCUSDT', { transactionType: 'FLEX', now: NOW });
assert.equal(buy.status, 'SIGNAL'); assert.equal(buy.direction, 'BUY'); assert.equal(buy.transactionType, 'FLEX');
assert.equal(buy.ruleBased, true); assert.equal(buy.aiModel, false); assert.match(buy.label, /RULE-BASED/);
assert.ok(buy.reasons.length >= 3 && buy.reasons.some((r) => /EMA9/.test(r)) && buy.reasons.some((r) => /RSI14/.test(r)));
assert.equal(buy.timestamp, NOW); assert.equal(buy.quote.providerId, 'BINANCE_SPOT'); assert.equal(buy.quote.freshness, 'FRESH');
assert.equal(buy.quote.isBrokerQuote, false); assert.equal(buy.validation.executable, false);
assert.ok(buy.validation.blockers.some((b) => /NO_BROKER_QUOTE/.test(b)) && buy.validation.blockers.some((b) => /LIVE_GATE_CLOSED/.test(b)));
assert.equal(buy.assetAvailability, 'UNVERIFIED');
assert.equal(buy.validation.status, 'COMPARISON_ONLY');

setCrypto('BTCUSDT', 'down');
const sell = A.EntrySignal.evaluate('BTCUSDT', { transactionType: 'FLEX', now: NOW });
assert.equal(sell.direction, 'SELL'); assert.equal(sell.status, 'SIGNAL');

setCrypto('BTCUSDT', 'hot-up');
const hot = A.EntrySignal.evaluate('BTCUSDT', { transactionType: 'FLEX', now: NOW });
assert.equal(hot.direction, null); assert.equal(hot.status, 'NO_SIGNAL'); assert.equal(hot.noSignalReason, 'RSI_OVERBOUGHT');
feed.BTCUSDT = { values: Array(40).fill(100), price: 100, updatedAt: NOW - 1000, stale: false, candles: [] };
const flatSig = A.EntrySignal.evaluate('BTCUSDT', { transactionType: 'FLEX', now: NOW });
assert.equal(flatSig.direction, null); assert.equal(flatSig.status, 'NO_SIGNAL');

// Metode volatilitas tidak menghasilkan arah.
setCrypto('BTCUSDT', 'up');
A.Storage.set('strategy', 'volatility-observation');
assert.equal(A.EntrySignal.evaluate('BTCUSDT', { transactionType: 'FLEX', now: NOW }).noSignalReason, 'METHOD_NO_DIRECTION');
A.Storage.set('strategy', 'technical-trend');

// --- Data stale / hilang tidak menghasilkan entry yang bisa dieksekusi --------------------------
setCrypto('BTCUSDT', 'up', { stale: true, ageMs: 120000 });
const stale = A.EntrySignal.evaluate('BTCUSDT', { transactionType: 'FLEX', now: NOW });
assert.equal(stale.status, 'STALE'); assert.equal(stale.direction, null); assert.equal(stale.available, false); assert.equal(stale.validation.executable, false);
delete feed.ETHUSDT;
const missing = A.EntrySignal.evaluate('ETHUSDT', { transactionType: 'FLEX', now: NOW });
assert.equal(missing.status, 'NO_DATA'); assert.equal(missing.direction, null); assert.equal(missing.available, false);
const otcSig = A.EntrySignal.evaluate('BTCUSD_OTC', { transactionType: 'FLEX', now: NOW });
assert.equal(otcSig.status, 'NO_DATA'); assert.equal(otcSig.validation.executable, false);
// Eksekusi tidak pernah true — bahkan untuk sinyal yang valid.
setCrypto('BTCUSDT', 'up');
for (const t of ['FLEX', 'INZONE']) assert.equal(A.EntrySignal.evaluate('BTCUSDT', { transactionType: t, now: NOW }).validation.executable, false);

// --- FOREX: wajib instrumen Forex; sumber ECB harian bukan seri intraday --------------------------
const fxMismatch = A.EntrySignal.evaluate('BTCUSDT', { transactionType: 'FOREX', now: NOW });
assert.equal(fxMismatch.status, 'INVALID_PARAMS');
const fxNoSeries = A.EntrySignal.evaluate('EURUSD', { transactionType: 'FOREX', now: NOW });
assert.equal(fxNoSeries.status, 'NO_DATA'); assert.equal(fxNoSeries.direction, null, 'Tanpa seri harga intraday tidak ada sinyal Forex');
assert.equal(fxNoSeries.quote.providerId, 'ECB_REFERENCE');
// Jika sumber data menyediakan seri (mis. feed FX masa depan / mock), BUY/SELL dihasilkan namun tetap bukan executable.
const fxv = series('up', 40, 1.08, 0.0005);
A.MarketData.history = (s) => (s === 'EURUSD' ? fxv.slice() : feed[s] ? feed[s].values.slice() : []);
const fxBuy = A.EntrySignal.evaluate('EURUSD', { transactionType: 'FOREX', now: NOW });
assert.equal(fxBuy.direction, 'BUY'); assert.equal(fxBuy.transactionType, 'FOREX');
assert.ok(fxBuy.reasons.some((r) => /referensi harian/.test(r)));
assert.equal(fxBuy.validation.executable, false); assert.equal(fxBuy.quote.isBrokerQuote, false);
const fxd = series('down', 40, 1.08, 0.0005);
A.MarketData.history = (s) => (s === 'EURUSD' ? fxd.slice() : []);
assert.equal(A.EntrySignal.evaluate('EURUSD', { transactionType: 'FOREX', now: NOW }).direction, 'SELL');

// --- INZONE: rentang & kedaluwarsa, bukan BUY/SELL -----------------------------------------------
setCrypto('BTCUSDT', 'up');
const price = feed.BTCUSDT.price;
A.MarketData.history = (s) => (feed[s] ? feed[s].values.slice() : []);
const zin = A.EntrySignal.evaluate('BTCUSDT', { transactionType: 'INZONE', now: NOW, params: { zoneLower: price - 5, zoneUpper: price + 5, expiryMinutes: 1 } });
assert.equal(zin.transactionType, 'INZONE'); assert.equal(zin.direction, null, 'InZone tidak memakai BUY/SELL');
assert.equal(zin.status, 'ZONE_EVALUATED'); assert.equal(zin.zone.insideNow, true); assert.equal(zin.zone.lower, price - 5);
assert.ok(['LIKELY_STAY_INSIDE', 'UNCERTAIN', 'LIKELY_EXIT'].includes(zin.zone.assessment));
assert.ok(zin.zone.sigmaPerMinutePct > 0 && zin.zone.expectedMovePct > 0);
const wide = A.EntrySignal.evaluate('BTCUSDT', { transactionType: 'INZONE', now: NOW, params: { zoneLower: price - 50, zoneUpper: price + 50, expiryMinutes: 1 } });
assert.equal(wide.zone.assessment, 'LIKELY_STAY_INSIDE');
const tight = A.EntrySignal.evaluate('BTCUSDT', { transactionType: 'INZONE', now: NOW, params: { zoneLower: price - 0.01, zoneUpper: price + 0.01, expiryMinutes: 5 } });
assert.equal(tight.zone.assessment, 'LIKELY_EXIT');
const outside = A.EntrySignal.evaluate('BTCUSDT', { transactionType: 'INZONE', now: NOW, params: { zoneLower: price + 1, zoneUpper: price + 3, expiryMinutes: 1 } });
assert.equal(outside.zone.insideNow, false); assert.equal(outside.zone.assessment, 'OUTSIDE_NOW');
const auto = A.EntrySignal.evaluate('BTCUSDT', { transactionType: 'INZONE', now: NOW, params: { zoneLower: null, zoneUpper: null, zoneWidthPct: 1, expiryMinutes: 1 } });
assert.ok(Math.abs(auto.zone.widthPct - 1) < 0.001, 'Rentang otomatis memakai lebar % yang diminta');
assert.ok(auto.reasons.some((r) => /dibentuk otomatis/.test(r)));
assert.equal(A.EntrySignal.evaluate('BTCUSDT', { transactionType: 'INZONE', now: NOW, params: { zoneLower: 5 } }).status, 'INVALID_PARAMS');

// Penilaian hasil memakai harga saat kedaluwarsa dan aturan rentang tervalidasi.
assert.equal(A.EntrySignal.settleInZone(100, 102, 101).outcome, 'IN_ZONE');
assert.equal(A.EntrySignal.settleInZone(100, 102, 102.5).outcome, 'OUT_OF_ZONE');
assert.equal(A.EntrySignal.settleInZone(100, 102, 99).outcome, 'OUT_OF_ZONE');
assert.equal(A.EntrySignal.settleInZone(100, 102, 100).outcome, 'BOUNDARY_UNVERIFIED');
assert.equal(A.EntrySignal.settleInZone(102, 100, 101).outcome, 'INVALID');

// --- Output berbeda per jenis untuk aset yang sama ------------------------------------------------
const f = A.EntrySignal.evaluate('BTCUSDT', { transactionType: 'FLEX', now: NOW });
const z = A.EntrySignal.evaluate('BTCUSDT', { transactionType: 'INZONE', now: NOW });
assert.ok(f.direction && !f.zone); assert.ok(z.zone && !z.direction); assert.notEqual(f.id, z.id);
assert.equal(A.EntrySignal.evaluate('BTCUSDT', { transactionType: 'XYZ', now: NOW }).status, 'INVALID_TYPE');
// id deterministik per menit → dasar idempotensi.
assert.equal(A.EntrySignal.evaluate('BTCUSDT', { transactionType: 'FLEX', now: NOW }).id, f.id);
console.log('PASS: entry-signal (Flex/Forex BUY-SELL, InZone rentang+expiry, stale/missing/OTC tanpa entry, provenance Binance/ECB/Olymptrade terpisah, tidak pernah executable).');
