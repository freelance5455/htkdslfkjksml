'use strict';
const assert = require('node:assert/strict');
const { loadAstra } = require('./helpers/load-astra');
const calls = [];
let mode = 'ok';
const fetchMock = async (url, opt) => {
  calls.push({ url, headers: opt.headers });
  const u = new URL(url);
  const body = (j, status = 200) => ({ ok: status < 400, status, text: async () => JSON.stringify(j) });
  if (u.pathname === '/api/v3/time') return body({ serverTime: Date.now() + 1500 });
  if (u.pathname === '/api/v3/account') {
    if (mode === 'badkey') return body({ code: -2015, msg: 'Invalid API-key, IP, or permissions for action.' }, 401);
    return body({ accountType: 'SPOT', canTrade: true, balances: [{ asset: 'BTC', free: '1.5', locked: '0' }, { asset: 'ETH', free: '0', locked: '0' }, { asset: 'USDT', free: '10000', locked: '5' }] });
  }
  return body({ code: -1, msg: 'x' }, 404);
};
const { A, store, ctx } = loadAstra(['js/integrations/binance-testnet.js'], { fetch: fetchMock, TextEncoder, AbortController, crypto: globalThis.crypto });
(async () => {
  // Vektor tanda tangan resmi dari dokumentasi Binance
  const sig = await A.BinanceTestnet._sign('NhqPtmdSJYdKjVHjA7PZj4Mge3R5YNiP1e3UZjInClVN65XAbvqqM6A7H5fATj0j',
    'symbol=LTCBTC&side=BUY&type=LIMIT&timeInForce=GTC&quantity=1&price=0.1&recvWindow=5000&timestamp=1499827319559');
  assert.equal(sig, 'c8db56825ae71d6d79447849e617115f4a920fa2acdcab2b053c4b2838bd6b71');
  assert.equal(A.BinanceTestnet.status().state, 'NOT_CONNECTED');
  assert.equal(A.BinanceTestnet.status().realMoney, false);
  await assert.rejects(A.BinanceTestnet.refresh(), (e) => e.code === 'NOT_CONNECTED');
  await assert.rejects(A.BinanceTestnet.connect('pendek', 'x'), (e) => e.code === 'BAD_CREDENTIALS');
  assert.equal(calls.length, 0, 'Tidak ada request untuk kredensial yang jelas tidak valid');

  const KEY = 'K'.repeat(64), SEC = 'S'.repeat(64);
  mode = 'badkey';
  await assert.rejects(A.BinanceTestnet.connect(KEY, SEC), (e) => e.code === 'BINANCE_-2015');
  assert.equal(A.BinanceTestnet.status().state, 'NOT_CONNECTED', 'Gagal → tidak pernah CONNECTED, kredensial dihapus');
  await assert.rejects(A.BinanceTestnet.refresh(), (e) => e.code === 'NOT_CONNECTED');

  mode = 'ok'; calls.length = 0;
  const acc = await A.BinanceTestnet.connect(KEY, SEC);
  assert.equal(A.BinanceTestnet.status().state, 'CONNECTED_TESTNET');
  assert.equal(acc.canTrade, true); assert.deepEqual(acc.balances.map((b) => b.asset), ['BTC', 'USDT']);
  for (const c of calls) assert.equal(new URL(c.url).origin, 'https://testnet.binance.vision', 'Hanya host testnet');
  const signedCall = calls.find((c) => c.url.includes('/account'));
  assert.equal(signedCall.headers['X-MBX-APIKEY'], KEY);
  assert.match(signedCall.url, /timestamp=\d+&recvWindow=5000&signature=[0-9a-f]{64}$/);
  assert.ok(!calls.some((c) => c.url.includes(SEC)), 'Secret tidak pernah dikirim sebagai parameter');
  assert.equal(store.data.size, 0, 'Tidak ada yang ditulis ke localStorage');
  assert.ok(!JSON.stringify(A.BinanceTestnet.status()).includes(KEY));
  A.BinanceTestnet.disconnect();
  assert.equal(A.BinanceTestnet.status().state, 'NOT_CONNECTED'); assert.equal(A.BinanceTestnet.account(), null);
  console.log('PASS: binance-testnet (vektor tanda tangan resmi, host testnet saja, CONNECTED hanya setelah balasan akun, gagal menghapus kredensial, secret tidak dikirim/disimpan).');
})().catch((e) => { console.error(e); process.exit(1); });
