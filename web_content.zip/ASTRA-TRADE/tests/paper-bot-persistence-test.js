 'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.resolve(__dirname, '..');
const elements = new Map();
function element(id) {
  if (!elements.has(id)) elements.set(id, { id, value: id === 'symbol' ? 'BTCUSDT' : id === 'risk' ? '1' : id === 'equityStart' ? '1000' : '', textContent: '', innerHTML: '', className: '', disabled: false, listeners: {}, addEventListener(name, fn) { this.listeners[name] = fn; } });
  return elements.get(id);
}
const stored = new Map();
const state = { version: 1, updatedAt: Date.now(), equity: 1234.5, startEquity: 1000, realized: 234.5,
  trades: [{ time: '12:00:00', symbol: 'BTCUSDT', action: 'CLOSE', price: 100, pnl: 234.5, reason: 'restored paper record' }],
  position: { symbol: 'BTCUSDT', entry: 100, qty: 0.1, stop: 98.5, target: 103, openedAt: Date.now() },
  lossToday: 0, dayKey: new Date().toISOString().slice(0, 10), lastBar: 1000, symbol: 'BTCUSDT', risk: '0.75' };
stored.set('astra.trade.v1.paper-bot.state', JSON.stringify(state));
const ctx = {
  console, Date, Math, Number, String, Array, Object, JSON, Promise, RegExp, Error, AbortController,
  document: { getElementById: element },
  localStorage: { getItem: (k) => stored.has(k) ? stored.get(k) : null, setItem: (k, v) => stored.set(k, String(v)), removeItem: (k) => stored.delete(k) },
  setTimeout: (fn) => 1, clearTimeout() {}, setInterval: () => 2, clearInterval() {},
  fetch: async () => ({ ok: false, status: 503 }),
  confirm: () => true,
  addEventListener() {}
};
ctx.window = ctx;
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(path.join(root, 'js/paper-bot.js'), 'utf8'), ctx, { filename: 'js/paper-bot.js' });
assert.equal(element('equity').textContent, '$1,234.50', 'Saved paper equity should restore');
assert.equal(element('positions').textContent, '1', 'Saved virtual position should restore');
assert.match(element('positionList').innerHTML, /BTCUSDT/);
assert.equal(element('symbol').value, 'BTCUSDT');
assert.equal(element('risk').value, '0.75');
element('symbol').value = 'ETHUSDT';
element('symbol').listeners.change.call(element('symbol'));
assert.equal(element('symbol').value, 'BTCUSDT', 'Open virtual position must pin the selected symbol after restoration');
assert.equal(element('start').disabled, false, 'Bot must not auto-start after reload');
assert.equal(element('stop').disabled, true, 'Restored state is not a running loop');
(async () => {
  element('start').listeners.click();
  await new Promise((resolve) => setImmediate(resolve));
  const saved = JSON.parse(stored.get('astra.trade.v1.paper-bot.state'));
  assert.equal(saved.equity, 1234.5, 'Starting a restored paper session must not reset its equity');
  assert.equal(saved.position.entry, 100, 'Virtual position should remain persistent');
  element('stop').listeners.click();
  assert.equal(element('stop').disabled, true);
  console.log('PASS: Paper Trading state restore, equity/history/position persistence, explicit manual restart, and no automatic background execution.');
})().catch((e) => { console.error(e); process.exitCode = 1; });
