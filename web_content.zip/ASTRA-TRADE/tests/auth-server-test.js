'use strict';
// Tes integrasi server autentikasi NYATA (HTTP sungguhan ke server lokal, data sementara).
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
process.env.ASTRA_DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'astra-auth-'));
process.env.ASTRA_MAIL = 'console';
const { createServer, loadDb } = require('../server/server.js');

const mails = [];
const realLog = console.log;
console.log = (...a) => { const s = a.join(' '); if (s.startsWith('[mail:console]')) mails.push(s); else realLog(...a); };
const lastToken = () => decodeURIComponent(/token=([^\s&]+)/.exec(mails[mails.length - 1])[1]);

(async () => {
  loadDb();
  const server = createServer();
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const base = 'http://127.0.0.1:' + server.address().port;
  let cookie = '';
  async function call(method, url, body, extra) {
    const res = await fetch(base + url, { method, redirect: 'manual', headers: Object.assign({ 'Content-Type': 'application/json' }, cookie ? { Cookie: cookie } : {}, extra || {}), body: body ? JSON.stringify(body) : undefined });
    const sc = res.headers.get('set-cookie');
    if (sc) cookie = sc.startsWith('astra_sid=;') || /Max-Age=0/.test(sc) ? '' : sc.split(';')[0];
    const text = await res.text(); let json = null; try { json = JSON.parse(text); } catch (e) {}
    return { status: res.status, json, text, headers: res.headers };
  }
  const good = { email: 'Tes@Contoh.com', password: 'rahasia123', name: 'Tester' };

  // validasi registrasi
  assert.equal((await call('POST', '/api/auth/register', { ...good, email: 'bukan-email' })).json.code, 'BAD_EMAIL');
  assert.equal((await call('POST', '/api/auth/register', { ...good, password: 'pendek1' })).json.code, 'BAD_PASSWORD');
  assert.equal((await call('POST', '/api/auth/register', { ...good, password: 'hurufsajaaa' })).json.code, 'BAD_PASSWORD');
  assert.equal((await call('POST', '/api/auth/register', { ...good, name: '<b>' })).json.code, 'BAD_NAME');
  // registrasi sukses + duplikat (email dinormalisasi)
  const reg = await call('POST', '/api/auth/register', good);
  assert.equal(reg.status, 201); assert.equal(reg.json.verificationRequired, true); assert.equal(reg.json.mail.delivered, false);
  assert.equal((await call('POST', '/api/auth/register', { ...good, email: 'tes@contoh.com' })).status, 409);
  // password tidak tersimpan polos
  assert.ok(!fs.readFileSync(path.join(process.env.ASTRA_DATA_DIR, 'db.json'), 'utf8').includes('rahasia123'));
  // belum diverifikasi: password benar tetap ditolak, tanpa cookie sesi
  const unv = await call('POST', '/api/auth/login', { email: 'tes@contoh.com', password: 'rahasia123' });
  assert.equal(unv.status, 403); assert.equal(unv.json.code, 'UNVERIFIED'); assert.equal(cookie, '');
  // verifikasi: token salah ditolak, token benar diterima, token sekali pakai
  assert.equal((await call('GET', '/api/auth/verify?token=salah')).status, 400);
  const vtoken = lastToken();
  assert.equal((await call('GET', '/api/auth/verify?token=' + vtoken)).status, 200);
  assert.equal((await call('GET', '/api/auth/verify?token=' + vtoken)).status, 400);
  // login: akun tak dikenal dan password salah memberi pesan sama (tanpa enumerasi)
  const unk = await call('POST', '/api/auth/login', { email: 'tidak@ada.com', password: 'apasaja123' });
  const bad = await call('POST', '/api/auth/login', { email: 'tes@contoh.com', password: 'salahsalah1' });
  assert.equal(unk.status, 401); assert.equal(bad.status, 401); assert.equal(unk.json.message, bad.json.message);
  assert.equal((await call('POST', '/api/auth/login', { email: 'x', password: 'y' })).json.code, 'BAD_EMAIL');
  // login benar -> cookie HttpOnly + SameSite
  const ok = await call('POST', '/api/auth/login', { email: 'tes@contoh.com', password: 'rahasia123' });
  assert.equal(ok.status, 200); assert.match(ok.headers.get('set-cookie'), /HttpOnly/); assert.match(ok.headers.get('set-cookie'), /SameSite=Strict/);
  assert.equal(ok.json.user.name, 'Tester');
  assert.equal((await call('GET', '/api/auth/me')).json.authenticated, true);
  // CSRF: origin asing ditolak, content-type non-JSON ditolak
  assert.equal((await call('POST', '/api/auth/logout', {}, { Origin: 'http://evil.example' })).status, 403);
  assert.equal((await call('POST', '/api/auth/logout', {}, { 'Content-Type': 'text/plain' })).status, 415);
  assert.equal((await call('GET', '/api/auth/me')).json.authenticated, true, 'serangan CSRF tidak boleh mengakhiri sesi');
  // logout benar-benar mematikan sesi di server
  const oldCookie = cookie;
  assert.equal((await call('POST', '/api/auth/logout', {})).status, 200);
  cookie = oldCookie;
  assert.equal((await call('GET', '/api/auth/me')).json.authenticated, false, 'cookie lama tidak boleh valid setelah logout');
  cookie = '';
  // forgot: respons sama untuk akun ada/tidak; reset mengakhiri sesi lama dan token sekali pakai
  const f1 = await call('POST', '/api/auth/forgot', { email: 'tidak@ada.com' });
  assert.equal(f1.status, 200);
  await call('POST', '/api/auth/login', { email: 'tes@contoh.com', password: 'rahasia123' });
  const sessionCookie = cookie;
  const f2 = await call('POST', '/api/auth/forgot', { email: 'tes@contoh.com' });
  assert.equal(f2.status, 200); assert.equal(f2.json.message, f1.json.message);
  const rtoken = lastToken();
  cookie = '';
  assert.equal((await call('POST', '/api/auth/reset', { token: rtoken, password: 'lemah' })).json.code, 'BAD_PASSWORD');
  assert.equal((await call('POST', '/api/auth/reset', { token: rtoken, password: 'passwordbaru9' })).status, 200);
  assert.equal((await call('POST', '/api/auth/reset', { token: rtoken, password: 'passwordbaru9' })).json.code, 'BAD_TOKEN');
  cookie = sessionCookie;
  assert.equal((await call('GET', '/api/auth/me')).json.authenticated, false, 'reset harus mengakhiri sesi lama');
  cookie = '';
  assert.equal((await call('POST', '/api/auth/login', { email: 'tes@contoh.com', password: 'rahasia123' })).status, 401);
  assert.equal((await call('POST', '/api/auth/login', { email: 'tes@contoh.com', password: 'passwordbaru9' })).status, 200);
  cookie = '';
  // penguncian akun setelah 5 gagal (akun baru); password benar pun ditolak saat terkunci
  await call('POST', '/api/auth/register', { email: 'kunci@contoh.com', password: 'rahasia123', name: 'Kunci' });
  await call('GET', '/api/auth/verify?token=' + lastToken());
  for (let i = 0; i < 5; i++) assert.equal((await call('POST', '/api/auth/login', { email: 'kunci@contoh.com', password: 'salahsalah' + i })).status, 401);
  const locked = await call('POST', '/api/auth/login', { email: 'kunci@contoh.com', password: 'rahasia123' });
  assert.equal(locked.status, 423); assert.equal(locked.json.code, 'LOCKED');
  // berkas statis: aplikasi tampil, server/data/tests/docs tidak bocor, path traversal ditolak
  assert.equal((await call('GET', '/index.html')).status, 200);
  for (const p of ['/server/server.js', '/server/data/db.json', '/tests/smoke-test.js', '/docs/FEATURES.md', '/android-app/app/build.gradle.kts', '/..%2f..%2fetc%2fpasswd', '/.gitignore']) {
    assert.equal((await call('GET', p)).status, 404, 'harus 404: ' + p);
  }
  assert.match((await call('GET', '/index.html')).headers.get('content-security-policy'), /script-src 'self'/);
  server.close();
  console.log = realLog;
  console.log('PASS: auth-server (registrasi, validasi, duplikat, hash, verifikasi, login/gagal/terkunci, cookie HttpOnly, CSRF, logout server-side, forgot/reset, statis aman).');
  process.exit(0);
})().catch((e) => { console.log = realLog; console.error('FAIL:', e); process.exit(1); });
