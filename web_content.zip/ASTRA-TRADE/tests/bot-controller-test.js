'use strict';
// Tes mesin status bot: tombol Control harus mengubah status nyata (bukan sekadar teks).
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.resolve(__dirname, '..');
const calls = [];
const ctx = { console, Date, Promise, Error, setTimeout, clearTimeout };
ctx.window = ctx;
vm.createContext(ctx);
ctx.ASTRA = { Logger: { info() {}, warn() {}, error() {} }, EventBus: { emit: (n, d) => calls.push([n, d]) },
  RealtimeEngine: { running: false, start() { this.running = true; }, stop() { this.running = false; } },
  AutoTradeLoop: { stopped: 0, stop() { this.stopped++; } },
  RiskRules: { canExecuteOrder: () => ({ ok: false, reason: 'ORDER EXECUTION DISABLED' }) } };
vm.runInContext(fs.readFileSync(path.join(root, 'js/bot/bot-controller.js'), 'utf8'), ctx);
const B = ctx.ASTRA.BotController, E = ctx.ASTRA.RealtimeEngine;

assert.equal(B.status().state, 'STOPPED');
assert.equal(B.pause().ok, false, 'pause saat STOPPED harus ditolak');
assert.equal(B.resume().ok, false);
assert.equal(B.start().ok, true); assert.equal(E.running, true); assert.equal(B.isRunning(), true);
assert.equal(B.pause().ok, true); assert.equal(E.running, false, 'pause harus menghentikan mesin analisis'); assert.equal(B.isRunning(), false); assert.equal(B.status().state, 'PAUSED');
assert.equal(B.resume().ok, true); assert.equal(E.running, true); assert.equal(B.status().state, 'RUNNING');
assert.equal(B.stop().ok, true); assert.equal(E.running, false); assert.equal(B.status().state, 'STOPPED');
B.start(); const r = B.emergencyStop();
assert.equal(r.state, 'EMERGENCY_STOP'); assert.equal(E.running, false); assert.ok(ctx.ASTRA.AutoTradeLoop.stopped >= 1);
assert.equal(B.start().ok, false, 'start dikunci saat emergency'); assert.equal(B.stop().ok, false); assert.equal(E.running, false);
assert.equal(B.resetEmergency().ok, true); assert.equal(B.status().state, 'STOPPED');
assert.equal(B.start().ok, true);
const st = B.status();
assert.equal(st.tradingConnection, 'NOT CONNECTED'); assert.equal(st.orderPermission, 'DENIED');
assert.ok(calls.some(([n, d]) => n === 'engine:status' && d.state === 'EMERGENCY_STOP'));
B.placeOrder().then(() => { throw new Error('order tidak boleh lolos'); }, () => { console.log('PASS: bot-controller (STOPPED/RUNNING/PAUSED/EMERGENCY, penguncian, efek nyata pada engine, order ditolak).'); });
