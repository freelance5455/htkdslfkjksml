'use strict';
/* Memuat modul browser ASTRA ke konteks vm dengan localStorage tiruan (hanya untuk test). */
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.resolve(__dirname, '..', '..');

function makeStore() {
  const data = new Map();
  return {
    data,
    getItem(k) { return data.has(k) ? data.get(k) : null; },
    setItem(k, v) { data.set(k, String(v)); },
    removeItem(k) { data.delete(k); },
    key(i) { return [...data.keys()][i] ?? null; },
    get length() { return data.size; }
  };
}

function loadAstra(files, extra) {
  const store = makeStore();
  const ctx = Object.assign({
    console, Date, Math, Number, String, Array, Object, JSON, RegExp, Promise, Map, Set, Error, Proxy, Reflect,
    localStorage: store, setInterval: () => 1, clearInterval() {}, setTimeout, clearTimeout, location: { hash: '' }
  }, extra || {});
  ctx.window = ctx;
  vm.createContext(ctx);
  for (const f of files) vm.runInContext(fs.readFileSync(path.join(root, f), 'utf8'), ctx, { filename: f });
  return { ctx, A: ctx.ASTRA, store, root };
}

/* Deret harga: 'up'/'down' = tren dengan riak (RSI sedang), 'hot-up'/'hot-down' = ekstrem (RSI jenuh), 'flat'. */
function series(kind, n, start, scale) {
  const out = []; let p = start || 100; const k = scale || 1;
  const pat = [0.6, -0.3, 0.2, -0.2, 0.1];
  for (let i = 0; i < n; i++) {
    const step = kind === 'up' ? pat[i % 5] : kind === 'down' ? -pat[i % 5]
      : kind === 'hot-up' ? (i % 3 === 2 ? -0.35 : 0.5) : kind === 'hot-down' ? (i % 3 === 2 ? 0.35 : -0.5)
      : (i % 2 ? 0.2 : -0.2);
    p += step * k; out.push(Number(p.toFixed(6)));
  }
  return out;
}

module.exports = { loadAstra, series, root, makeStore };
