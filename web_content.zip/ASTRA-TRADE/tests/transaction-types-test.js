'use strict';
const assert = require('node:assert/strict');
const { loadAstra } = require('./helpers/load-astra');
const TT = require('../js/trading/transaction-types.js');

// 1. Tiga jenis transaksi broker, bukan strategi/AI Method/mode bot.
assert.deepEqual(TT.TYPES, ['FLEX', 'INZONE', 'FOREX']);
for (const d of TT.list()) assert.equal(d.brokerProduct, true, `${d.id} adalah produk/jenis transaksi broker`);
const { A } = loadAstra(['js/event-bus.js', 'js/storage/storage-manager.js', 'js/strategy/indicators.js', 'js/strategy/strategy-manager.js', 'js/bot/trading-mode-manager.js', 'js/trading/transaction-types.js']);
for (const t of TT.TYPES) {
  assert.ok(!A.StrategyManager.list().some((s) => s.id.toUpperCase() === t || s.name.toUpperCase().includes(t)), `${t} tidak boleh menjadi strategi/AI Method`);
  assert.ok(!A.TradingModeManager.available().map((m) => m.toUpperCase()).includes(t), `${t} tidak boleh menjadi mode bot`);
}

// 2. Validasi per jenis: field berbeda, tidak tercampur.
const flex = TT.normalize('FLEX', { amountIDR: 20000, market: 'BTCUSDT', durationMinutes: 1, zoneLower: 5, multiplier: 10 });
assert.equal(flex.ok, true);
assert.deepEqual(Object.keys(flex.value).sort(), ['amountIDR', 'assumedPayoutPct', 'durationMinutes', 'market']);
assert.equal('zoneLower' in flex.value || 'multiplier' in flex.value, false, 'Field InZone/Forex tidak ikut ke Flex');
assert.equal(TT.normalize('FLEX', { durationMinutes: 0 }).ok, false);
assert.equal(TT.normalize('FLEX', { amountIDR: 100 }).ok, false);
assert.equal(TT.normalize('NOPE', {}).ok, false);

assert.equal(TT.normalize('INZONE', { zoneLower: 100 }).ok, false, 'Satu batas saja ditolak');
assert.equal(TT.normalize('INZONE', { zoneLower: 110, zoneUpper: 100 }).ok, false, 'Bawah >= atas ditolak');
assert.equal(TT.normalize('INZONE', { zoneLower: 100, zoneUpper: 101 }).ok, true);
assert.equal(TT.normalize('INZONE', { zoneLower: null, zoneUpper: null, zoneWidthPct: 0.3 }).ok, true);
assert.equal(TT.normalize('INZONE', { zoneLower: null, zoneUpper: null, zoneWidthPct: null }).ok, false);

assert.equal(TT.normalize('FOREX', { market: 'BTCUSDT' }).ok, false, 'Forex menolak aset non-Forex');
assert.equal(TT.normalize('FOREX', { market: 'EURUSD' }).ok, true);
assert.equal(TT.normalize('FOREX', { market: 'EURUSD', multiplier: -3 }).ok, false);
assert.equal(TT.normalize('FOREX', { market: 'EURUSD', stopLossPct: 120 }).ok, false);

// 3. Spesifikasi broker tetap UNVERIFIED; tidak ada nilai ditanam.
for (const t of TT.TYPES) {
  const s = TT.spec(t);
  assert.equal(s.status, 'UNVERIFIED');
  assert.ok(Object.values(s.attributes).every((a) => a.status === 'UNVERIFIED' && a.value === null), `${t}: semua atribut UNVERIFIED tanpa nilai`);
  assert.ok(s.missingForLive.length >= 6);
}
assert.throws(() => TT.registerVerified({ type: 'FLEX', key: 'minAmount', value: 15000 }), /evidence/i, 'Nilai terverifikasi wajib bukti');
assert.throws(() => TT.registerVerified({ type: 'FLEX', key: 'tidakAda', value: 1, evidence: 'dokumen resmi 123' }));
assert.equal(TT.assetAvailability('FLEX', 'BTCUSDT').status, 'UNVERIFIED');
assert.equal(TT.assetAvailability('FLEX', 'BTCUSD_OTC').status, 'NOT_AVAILABLE');
assert.equal(TT.assetAvailability('FOREX', 'BTCUSDT').status, 'MISMATCH');
assert.equal(TT.assetClass('EURUSD'), 'forex');
assert.equal(TT.assetClass('BTCUSDT'), 'crypto-spot');

// 4. Konfigurasi terpisah per jenis + persistensi + pergantian jenis tidak mencampur.
const store = A.TransactionConfig;
assert.equal(store.getActive(), 'FLEX');
assert.equal(store.save('FLEX', { amountIDR: 25000, durationMinutes: 1 }).ok, true);
assert.equal(store.save('INZONE', { zoneLower: 100, zoneUpper: 102, expiryMinutes: 1 }).ok, true);
assert.equal(store.save('FOREX', { market: 'EURUSD', multiplier: 5, stopLossPct: 1 }).ok, true);
assert.equal(store.setActive('INZONE').ok, true);
assert.equal(store.getActive(), 'INZONE');
assert.equal(store.setActive('MARTINGALE').ok, false);
assert.equal(store.get('FLEX').amountIDR, 25000);
assert.equal(store.get('FLEX').durationMinutes, 1);
assert.equal(store.get('INZONE').zoneUpper, 102);
assert.equal(store.get('FOREX').multiplier, 5);
assert.equal('multiplier' in store.get('FLEX'), false);
assert.equal('zoneLower' in store.get('FOREX'), false);
assert.equal(store.save('FLEX', { amountIDR: 1 }).ok, false, 'Simpan tidak valid ditolak dan tidak mengubah data');
assert.equal(store.get('FLEX').amountIDR, 25000);
store.setActive('FOREX');
assert.equal(store.get('INZONE').zoneLower, 100, 'Mengganti jenis tidak menghapus parameter jenis lain');
// Persisten setelah "reload": store baru atas storage yang sama.
const reload = TT.createStore(A.Storage);
assert.equal(reload.getActive(), 'FOREX');
assert.equal(reload.get('INZONE').zoneLower, 100);
// Data rusak jatuh ke default, tidak melempar.
A.Storage.set('txConfig.FLEX', { amountIDR: 'abc', durationMinutes: -1 });
assert.equal(reload.get('FLEX').amountIDR, 15000);
console.log('PASS: transaction-types (Flex/InZone/Forex sebagai transactionType terpisah dari strategi & mode, validasi per jenis, spec UNVERIFIED, konfigurasi terpisah & persisten).');
