'use strict';
/*
 * ASTRA TRADE — scheduler backend + status trading persisten.
 *
 * Jujur soal batasan:
 *  - Hanya berjalan selama proses server ini hidup (bukan klaim 24/7).
 *  - Mode: 'scan-only' dan 'dry-run'. Mode 'live' DITOLAK saat validasi. Tidak ada order dikirim.
 *  - Setelah restart tidak ada "catch-up": jadwal yang terlewat tidak dijalankan ulang; kunci lastFired
 *    tersimpan sehingga menit yang sama tidak terpicu dua kali.
 *  - Satu scheduler per direktori data (lock file + pid).
 *  - Emergency Stop tersimpan di disk dan memblokir semua pemicu.
 */
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const MODES = ['scan-only', 'dry-run'];
const MAX_SCHEDULES_PER_USER = 20;
const MAX_RUNS = 200;

function validTimezone(tz) {
  if (typeof tz !== 'string' || !tz || tz.length > 60) return false;
  try { new Intl.DateTimeFormat('en-US', { timeZone: tz }); return true; } catch (e) { return false; }
}
/* Waktu lokal pada zona tertentu: { date:'YYYY-MM-DD', time:'HH:MM', day:0-6 } */
function localParts(ms, tz) {
  const f = new Intl.DateTimeFormat('en-US', { timeZone: tz, hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', weekday: 'short' });
  const p = {}; f.formatToParts(new Date(ms)).forEach((x) => { p[x.type] = x.value; });
  const day = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 }[p.weekday];
  return { date: p.year + '-' + p.month + '-' + p.day, time: p.hour + ':' + p.minute, day };
}

function validateSchedule(input, types) {
  const errors = [];
  const s = input && typeof input === 'object' ? input : {};
  const out = {
    id: typeof s.id === 'string' && /^[A-Za-z0-9_-]{4,40}$/.test(s.id) ? s.id : null,
    name: String(s.name || 'Jadwal').slice(0, 60),
    time: String(s.time || ''), timezone: String(s.timezone || ''), enabled: s.enabled !== false,
    mode: String(s.mode || 'scan-only'), transactionType: String(s.transactionType || '').toUpperCase(),
    symbol: String(s.symbol || '').toUpperCase()
  };
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(out.time)) errors.push('Format waktu harus HH:MM.');
  if (!validTimezone(out.timezone)) errors.push('Zona waktu IANA tidak valid (mis. Asia/Jakarta).');
  const days = Array.isArray(s.days) ? s.days.map(Number) : [];
  if (!days.length || days.some((d) => !Number.isInteger(d) || d < 0 || d > 6)) errors.push('Hari harus berisi angka 0–6 (minimal satu).');
  out.days = Array.from(new Set(days)).sort((a, b) => a - b);
  if (out.mode === 'live') errors.push('LIVE_NOT_ALLOWED: mode live tidak diizinkan; gerbang live tertutup.');
  else if (MODES.indexOf(out.mode) < 0) errors.push('Mode harus scan-only atau dry-run.');
  if (!types || !types.isType(out.transactionType)) errors.push('Jenis transaksi harus FLEX, INZONE, atau FOREX.');
  else if (!/^[A-Z0-9_]{3,20}$/.test(out.symbol)) errors.push('Simbol tidak valid.');
  return { ok: errors.length === 0, errors, value: out };
}

function atomicWrite(file, data) {
  const tmp = file + '.' + process.pid + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(data), { mode: 0o600 });
  fs.renameSync(tmp, file);
}
function readJson(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch (e) { return fallback; }
}

function create(opts) {
  const dataDir = opts.dataDir, types = opts.types;
  const now = opts.now || (() => Date.now());
  const onTrigger = opts.onTrigger || null;
  fs.mkdirSync(dataDir, { recursive: true, mode: 0o700 });
  const F = { state: path.join(dataDir, 'trading-state.json'), sched: path.join(dataDir, 'schedules.json'), lock: path.join(dataDir, 'scheduler.lock') };
  let timer = null, startedAt = null, lastTickAt = null, hasLock = false;

  const load = () => {
    const st = readJson(F.state, {});
    const sc = readJson(F.sched, {});
    return { state: { emergencyStop: !!st.emergencyStop, emergencyAt: st.emergencyAt || null }, schedules: Array.isArray(sc.schedules) ? sc.schedules : [], lastFired: sc.lastFired && typeof sc.lastFired === 'object' ? sc.lastFired : {}, runs: Array.isArray(sc.runs) ? sc.runs : [] };
  };
  const save = (m) => { atomicWrite(F.state, m.state); atomicWrite(F.sched, { schedules: m.schedules, lastFired: m.lastFired, runs: m.runs.slice(0, MAX_RUNS) }); };

  function setEmergency(on) {
    const m = load(); m.state.emergencyStop = !!on; m.state.emergencyAt = on ? now() : null; save(m);
    return { ok: true, emergencyStop: m.state.emergencyStop };
  }
  const isEmergency = () => load().state.emergencyStop;

  function upsert(owner, input) {
    const v = validateSchedule(input, types);
    if (!v.ok) return { ok: false, code: v.errors.some((e) => /LIVE_NOT_ALLOWED/.test(e)) ? 'LIVE_NOT_ALLOWED' : 'INVALID', errors: v.errors };
    const m = load();
    const mine = m.schedules.filter((s) => s.owner === owner);
    let rec = v.value.id ? m.schedules.find((s) => s.id === v.value.id && s.owner === owner) : null;
    if (!rec && mine.length >= MAX_SCHEDULES_PER_USER) return { ok: false, code: 'LIMIT', errors: ['Batas ' + MAX_SCHEDULES_PER_USER + ' jadwal per akun.'] };
    if (rec) Object.assign(rec, v.value, { id: rec.id, owner });
    else { rec = Object.assign(v.value, { id: 's_' + crypto.randomBytes(6).toString('hex'), owner, createdAt: now() }); m.schedules.push(rec); }
    save(m);
    return { ok: true, schedule: rec };
  }
  function remove(owner, id) {
    const m = load(); const n = m.schedules.length;
    m.schedules = m.schedules.filter((s) => !(s.id === id && s.owner === owner));
    delete m.lastFired[id]; save(m);
    return { ok: m.schedules.length < n };
  }
  const list = (owner) => load().schedules.filter((s) => s.owner === owner);
  const runsFor = (owner) => load().runs.filter((r) => r.owner === owner).slice(0, 20);

  function record(m, s, status, extra) {
    m.runs.unshift(Object.assign({ id: 'r_' + crypto.randomBytes(5).toString('hex'), at: now(), scheduleId: s.id, owner: s.owner, mode: s.mode, transactionType: s.transactionType, symbol: s.symbol, status, ordersSent: 0 }, extra || {}));
  }

  /* Satu langkah pemeriksaan; dipanggil timer atau langsung oleh test. */
  function tick(at) {
    const t = Number(at) || now();
    lastTickAt = t;
    const m = load(); const fired = [];
    for (const s of m.schedules) {
      if (!s.enabled) continue;
      const lp = localParts(t, s.timezone);
      if (lp.time !== s.time || s.days.indexOf(lp.day) < 0) continue;
      const key = lp.date + 'T' + lp.time;
      if (m.lastFired[s.id] === key) continue;
      m.lastFired[s.id] = key;
      if (m.state.emergencyStop) { record(m, s, 'SKIPPED_EMERGENCY_STOP'); continue; }
      let status = 'DUE_RECORDED';
      try { if (onTrigger) status = onTrigger(s, t) || 'TRIGGERED'; } catch (e) { status = 'HANDLER_ERROR'; }
      record(m, s, status); fired.push(s.id);
    }
    if (fired.length || m.runs.length !== load().runs.length || Object.keys(m.lastFired).length) save(m);
    return { fired, at: t };
  }

  function acquireLock() {
    try {
      const cur = readJson(F.lock, null);
      if (cur && cur.pid && cur.pid !== process.pid) { try { process.kill(cur.pid, 0); return false; } catch (e) { if (e.code === 'EPERM') return false; } }
      fs.writeFileSync(F.lock, JSON.stringify({ pid: process.pid, at: now() }), { mode: 0o600 }); hasLock = true; return true;
    } catch (e) { return false; }
  }
  function start(intervalMs) {
    if (timer) return { ok: true, alreadyRunning: true };
    if (!acquireLock()) return { ok: false, code: 'LOCKED', reason: 'Scheduler lain sudah berjalan pada direktori data ini.' };
    startedAt = now();
    timer = setInterval(() => { try { tick(); } catch (e) { /* tidak menjatuhkan server */ } }, intervalMs || 15000);
    if (timer.unref) timer.unref();
    return { ok: true };
  }
  function stop() { if (timer) clearInterval(timer); timer = null; if (hasLock) { try { fs.unlinkSync(F.lock); } catch (e) { /* abaikan */ } hasLock = false; } startedAt = null; }
  const status = () => ({ running: !!timer, startedAt, lastTickAt, modes: MODES.slice(), note: 'Berjalan hanya selama proses server aktif; tidak ada catch-up setelah restart; tidak ada order live.' });

  return { upsert, remove, list, runsFor, tick, start, stop, status, setEmergency, isEmergency };
}

module.exports = { create, validateSchedule, validTimezone, localParts, MODES };
