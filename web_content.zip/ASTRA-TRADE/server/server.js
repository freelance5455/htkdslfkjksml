#!/usr/bin/env node
'use strict';
/*
 * ASTRA TRADE — server autentikasi + file statis (tanpa dependensi npm).
 *
 * Jalankan:   node server/server.js            (default http://127.0.0.1:8080)
 * Admin CLI:  node server/server.js verify email@contoh.com
 *
 * Yang NYATA di sini: hashing scrypt, sesi cookie HttpOnly, verifikasi email via token,
 * reset password via token sekali-pakai, pembatasan percobaan login, penguncian akun.
 * Yang BELUM ADA: pengiriman email sungguhan (SMTP). Lihat ASTRA_MAIL di bawah.
 *
 * Variabel lingkungan:
 *   PORT, HOST                  (default 8080 / 127.0.0.1)
 *   ASTRA_DATA_DIR              (default server/data)
 *   ASTRA_REQUIRE_VERIFICATION  (default 1; 0 = akun langsung aktif tanpa verifikasi email)
 *   ASTRA_MAIL                  'none' (default: email TIDAK terkirim) | 'console' (cetak tautan di terminal server)
 *   ASTRA_COOKIE_SECURE         1 = paksa atribut Secure (wajib bila dipasang di belakang HTTPS)
 */
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const ROOT = path.resolve(__dirname, '..');
const DATA_DIR = path.resolve(process.env.ASTRA_DATA_DIR || path.join(__dirname, 'data'));
const DB_FILE = path.join(DATA_DIR, 'db.json');
const REQUIRE_VERIFICATION = process.env.ASTRA_REQUIRE_VERIFICATION !== '0';
const MAIL_MODE = process.env.ASTRA_MAIL === 'console' ? 'console' : 'none';
const SESSION_TTL_MS = 7 * 24 * 3600 * 1000;
const VERIFY_TTL_MS = 24 * 3600 * 1000;
const RESET_TTL_MS = 60 * 60 * 1000;
const MAX_FAILS = 5;
const LOCK_MS = 15 * 60 * 1000;
const COOKIE = 'astra_sid';
const TransactionTypes = require('../js/trading/transaction-types.js');
const RiskEngine = require('../js/risk/risk-engine.js');
const SchedulerLib = require('./scheduler.js');
let scheduler = null;
function getScheduler() {
  if (!scheduler) scheduler = SchedulerLib.create({ dataDir: DATA_DIR, types: TransactionTypes });
  return scheduler;
}

/* ---------- penyimpanan (berkas JSON, tulis atomik) ---------- */
let db = { users: {}, sessions: {}, tokens: {} };
function loadDb() {
  fs.mkdirSync(DATA_DIR, { recursive: true, mode: 0o700 });
  try { db = JSON.parse(fs.readFileSync(DB_FILE, 'utf8')); } catch (e) { if (e.code !== 'ENOENT') throw e; }
  db.users = db.users || {}; db.sessions = db.sessions || {}; db.tokens = db.tokens || {};
}
let dbMtime = 0;
/* CLI admin (mis. `verify`) menulis berkas langsung; muat ulang bila berkas berubah di luar proses ini. */
function refreshDb() {
  try { const m = fs.statSync(DB_FILE).mtimeMs; if (m !== dbMtime) { db = JSON.parse(fs.readFileSync(DB_FILE, 'utf8')); db.users = db.users || {}; db.sessions = db.sessions || {}; db.tokens = db.tokens || {}; dbMtime = m; } } catch (e) { /* berkas belum ada */ }
}
function saveDb() {
  const tmp = DB_FILE + '.' + process.pid + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(db), { mode: 0o600 });
  fs.renameSync(tmp, DB_FILE);
  try { dbMtime = fs.statSync(DB_FILE).mtimeMs; } catch (e) { /* abaikan */ }
}
const sha = (s) => crypto.createHash('sha256').update(s).digest('hex');
const rand = () => crypto.randomBytes(32).toString('base64url');

/* ---------- password ---------- */
function hashPassword(pw) {
  const salt = crypto.randomBytes(16);
  const key = crypto.scryptSync(pw, salt, 64, { N: 16384, r: 8, p: 1 });
  return 'scrypt$' + salt.toString('hex') + '$' + key.toString('hex');
}
function checkPassword(pw, stored) {
  const parts = String(stored || '').split('$');
  if (parts.length !== 3 || parts[0] !== 'scrypt') return false;
  const salt = Buffer.from(parts[1], 'hex'), want = Buffer.from(parts[2], 'hex');
  const got = crypto.scryptSync(pw, salt, want.length, { N: 16384, r: 8, p: 1 });
  return crypto.timingSafeEqual(got, want);
}
function passwordProblem(pw) {
  if (typeof pw !== 'string' || pw.length < 8) return 'Password minimal 8 karakter.';
  if (pw.length > 128) return 'Password maksimal 128 karakter.';
  if (!/[A-Za-z]/.test(pw) || !/[0-9]/.test(pw)) return 'Password harus mengandung huruf dan angka.';
  return null;
}
const EMAIL_RE = /^[^\s@]{1,64}@[^\s@]{1,190}\.[^\s@]{2,}$/;
const normEmail = (e) => String(e || '').trim().toLowerCase();
const safeName = (n) => { const s = String(n || '').trim(); return s.length >= 2 && s.length <= 50 && !/[<>]/.test(s); };

/* ---------- email (jujur: tidak ada SMTP) ---------- */
function sendMail(to, subject, link) {
  if (MAIL_MODE === 'console') {
    console.log('[mail:console] to=%s subject=%s\n  %s', to, subject, link);
    return { delivered: false, channel: 'console', note: 'Tautan dicetak di terminal server; tidak ada email terkirim.' };
  }
  return { delivered: false, channel: 'none', note: 'Pengiriman email belum dikonfigurasi (NOT CONNECTED).' };
}

/* ---------- pembatasan laju sederhana (memori) ---------- */
const hits = new Map();
function rateLimited(key, max, windowMs) {
  const now = Date.now();
  const arr = (hits.get(key) || []).filter((t) => now - t < windowMs);
  arr.push(now); hits.set(key, arr);
  return arr.length > max;
}

/* ---------- util HTTP ---------- */
function send(res, status, body, headers) {
  const h = Object.assign({
    'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'no-referrer'
  }, headers || {});
  res.writeHead(status, h);
  res.end(typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body));
}
function readJson(req) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', (c) => { size += c.length; if (size > 10000) { reject(Object.assign(new Error('too large'), { status: 413 })); req.destroy(); } else chunks.push(c); });
    req.on('end', () => { try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}')); } catch (e) { reject(Object.assign(new Error('bad json'), { status: 400 })); } });
    req.on('error', reject);
  });
}
function parseCookies(req) {
  const out = {};
  String(req.headers.cookie || '').split(';').forEach((p) => { const i = p.indexOf('='); if (i > 0) out[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim()); });
  return out;
}
function isHttps(req) { return process.env.ASTRA_COOKIE_SECURE === '1' || req.headers['x-forwarded-proto'] === 'https'; }
function cookieHeader(req, value, maxAgeSec) {
  return COOKIE + '=' + value + '; HttpOnly; SameSite=Strict; Path=/; Max-Age=' + maxAgeSec + (isHttps(req) ? '; Secure' : '');
}
function sameOrigin(req) {
  const origin = req.headers.origin;
  if (!origin) return true;
  try { return new URL(origin).host === req.headers.host; } catch (e) { return false; }
}
function currentSession(req) {
  const sid = parseCookies(req)[COOKIE];
  if (!sid) return null;
  const s = db.sessions[sha(sid)];
  if (!s) return null;
  if (s.expiresAt < Date.now() || !db.users[s.email]) { delete db.sessions[sha(sid)]; saveDb(); return null; }
  return Object.assign({ key: sha(sid) }, s);
}
function publicUser(u) { return { name: u.name, email: u.email, verified: !!u.verified, createdAt: u.createdAt }; }
function startSession(req, res, user, status, body) {
  const sid = rand();
  db.sessions[sha(sid)] = { email: user.email, createdAt: Date.now(), expiresAt: Date.now() + SESSION_TTL_MS };
  user.lastLoginAt = Date.now(); user.fails = 0; user.lockedUntil = 0;
  user.loginHistory = (user.loginHistory || []).concat({ at: Date.now(), ok: true }).slice(-20);
  saveDb();
  send(res, status, body, { 'Set-Cookie': cookieHeader(req, sid, SESSION_TTL_MS / 1000) });
}
function purgeExpired() {
  const now = Date.now();
  for (const k of Object.keys(db.sessions)) if (db.sessions[k].expiresAt < now) delete db.sessions[k];
  for (const k of Object.keys(db.tokens)) if (db.tokens[k].expiresAt < now) delete db.tokens[k];
}
function issueToken(email, kind, ttl) {
  const raw = rand();
  db.tokens[sha(raw)] = { email, kind, expiresAt: Date.now() + ttl };
  return raw;
}
function consumeToken(raw, kind) {
  const key = sha(String(raw || ''));
  const t = db.tokens[key];
  if (!t || t.kind !== kind || t.expiresAt < Date.now()) return null;
  delete db.tokens[key];
  return t;
}
const baseUrl = (req) => (isHttps(req) ? 'https://' : 'http://') + req.headers.host;

/* ---------- endpoint auth ---------- */
async function api(req, res, route) {
  refreshDb();
  if (req.method === 'POST') {
    if (!sameOrigin(req)) return send(res, 403, { ok: false, code: 'BAD_ORIGIN', message: 'Origin tidak diizinkan.' });
    if (!/^application\/json/i.test(req.headers['content-type'] || '')) return send(res, 415, { ok: false, code: 'BAD_TYPE', message: 'Content-Type harus application/json.' });
  }
  const ip = req.socket.remoteAddress || 'ip';
  if (rateLimited('ip:' + ip, 60, 60000)) return send(res, 429, { ok: false, code: 'RATE_LIMIT', message: 'Terlalu banyak permintaan. Coba lagi sebentar.' });

  if (route === 'status' && req.method === 'GET') {
    return send(res, 200, { ok: true, service: 'astra-auth', requireVerification: REQUIRE_VERIFICATION, mail: MAIL_MODE === 'console' ? 'console' : 'NOT_CONNECTED' });
  }
  if (route === 'me' && req.method === 'GET') {
    const s = currentSession(req);
    if (!s) return send(res, 200, { ok: true, authenticated: false });
    return send(res, 200, { ok: true, authenticated: true, user: publicUser(db.users[s.email]) });
  }
  if (route === 'logout' && req.method === 'POST') {
    const s = currentSession(req);
    if (s) { delete db.sessions[s.key]; saveDb(); }
    return send(res, 200, { ok: true }, { 'Set-Cookie': cookieHeader(req, '', 0) });
  }
  if (route === 'verify' && req.method === 'GET') {
    const token = new URL(req.url, 'http://x').searchParams.get('token');
    const t = consumeToken(token, 'verify');
    const page = (msg) => '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><body style="font-family:system-ui;background:#07110e;color:#e9f5ee;padding:32px"><h2>ASTRA TRADE</h2><p>' + msg + '</p><p><a style="color:#67f0a0" href="/">Kembali ke aplikasi</a></p>';
    if (!t || !db.users[t.email]) return send(res, 400, page('Tautan verifikasi tidak valid atau sudah kedaluwarsa.'), { 'Content-Type': 'text/html; charset=utf-8' });
    db.users[t.email].verified = true; saveDb();
    return send(res, 200, page('Email terverifikasi. Silakan masuk.'), { 'Content-Type': 'text/html; charset=utf-8' });
  }
  if (req.method !== 'POST') return send(res, 404, { ok: false, code: 'NOT_FOUND', message: 'Endpoint tidak ada.' });

  let body;
  try { body = await readJson(req); } catch (e) { return send(res, e.status || 400, { ok: false, code: 'BAD_BODY', message: 'Body permintaan tidak valid.' }); }

  if (route === 'register') {
    const email = normEmail(body.email), name = String(body.name || '').trim() || email.split('@')[0];
    if (!EMAIL_RE.test(email)) return send(res, 400, { ok: false, code: 'BAD_EMAIL', field: 'email', message: 'Format email tidak valid.' });
    if (!safeName(name)) return send(res, 400, { ok: false, code: 'BAD_NAME', field: 'name', message: 'Nama tampilan harus 2–50 karakter tanpa < atau >.' });
    const pwErr = passwordProblem(body.password);
    if (pwErr) return send(res, 400, { ok: false, code: 'BAD_PASSWORD', field: 'password', message: pwErr });
    if (db.users[email]) return send(res, 409, { ok: false, code: 'EMAIL_EXISTS', field: 'email', message: 'Email ini sudah terdaftar. Silakan masuk atau pulihkan password.' });
    const user = { email, name, passwordHash: hashPassword(body.password), verified: !REQUIRE_VERIFICATION, createdAt: Date.now(), fails: 0, lockedUntil: 0, loginHistory: [] };
    db.users[email] = user;
    let mail = null;
    if (REQUIRE_VERIFICATION) mail = sendMail(email, 'Verifikasi akun ASTRA TRADE', baseUrl(req) + '/api/auth/verify?token=' + issueToken(email, 'verify', VERIFY_TTL_MS));
    saveDb();
    return send(res, 201, { ok: true, verificationRequired: REQUIRE_VERIFICATION, mail, message: REQUIRE_VERIFICATION ? 'Akun dibuat. Verifikasi email diperlukan sebelum masuk.' : 'Akun dibuat. Silakan masuk.' });
  }

  if (route === 'login') {
    const email = normEmail(body.email), pw = typeof body.password === 'string' ? body.password : '';
    if (!EMAIL_RE.test(email)) return send(res, 400, { ok: false, code: 'BAD_EMAIL', field: 'email', message: 'Format email tidak valid.' });
    if (!pw) return send(res, 400, { ok: false, code: 'BAD_PASSWORD', field: 'password', message: 'Password wajib diisi.' });
    if (rateLimited('login:' + email, 10, 10 * 60000)) return send(res, 429, { ok: false, code: 'RATE_LIMIT', message: 'Terlalu banyak percobaan untuk akun ini. Coba lagi nanti.' });
    const user = db.users[email];
    if (!user) { crypto.scryptSync(pw, 'x'.repeat(16), 64, { N: 16384, r: 8, p: 1 }); return send(res, 401, { ok: false, code: 'BAD_CREDENTIALS', message: 'Email atau password salah.' }); }
    if (user.lockedUntil && user.lockedUntil > Date.now()) return send(res, 423, { ok: false, code: 'LOCKED', message: 'Akun dikunci sementara karena terlalu banyak percobaan gagal. Coba lagi dalam ' + Math.ceil((user.lockedUntil - Date.now()) / 60000) + ' menit.' });
    if (!checkPassword(pw, user.passwordHash)) {
      user.fails = (user.fails || 0) + 1;
      user.loginHistory = (user.loginHistory || []).concat({ at: Date.now(), ok: false }).slice(-20);
      if (user.fails >= MAX_FAILS) { user.lockedUntil = Date.now() + LOCK_MS; user.fails = 0; }
      saveDb();
      return send(res, 401, { ok: false, code: 'BAD_CREDENTIALS', message: 'Email atau password salah.' });
    }
    if (REQUIRE_VERIFICATION && !user.verified) return send(res, 403, { ok: false, code: 'UNVERIFIED', message: 'Akun belum diverifikasi. Buka tautan verifikasi yang dikirim ke email Anda.' });
    return startSession(req, res, user, 200, { ok: true, user: publicUser(user) });
  }

  if (route === 'resend-verification') {
    const email = normEmail(body.email), user = db.users[email];
    let mail = null;
    if (user && !user.verified && !rateLimited('resend:' + email, 3, 3600000)) mail = sendMail(email, 'Verifikasi akun ASTRA TRADE', baseUrl(req) + '/api/auth/verify?token=' + issueToken(email, 'verify', VERIFY_TTL_MS));
    saveDb();
    return send(res, 200, { ok: true, mail, message: 'Jika akun ada dan belum diverifikasi, tautan baru diproses.' });
  }

  if (route === 'forgot') {
    const email = normEmail(body.email);
    if (!EMAIL_RE.test(email)) return send(res, 400, { ok: false, code: 'BAD_EMAIL', field: 'email', message: 'Format email tidak valid.' });
    let mail = null;
    if (db.users[email] && !rateLimited('forgot:' + email, 3, 3600000)) mail = sendMail(email, 'Reset password ASTRA TRADE', baseUrl(req) + '/#/reset?token=' + issueToken(email, 'reset', RESET_TTL_MS));
    saveDb();
    return send(res, 200, { ok: true, mail: mail ? { delivered: mail.delivered, channel: mail.channel, note: mail.note } : { delivered: false, channel: MAIL_MODE, note: MAIL_MODE === 'none' ? 'Pengiriman email belum dikonfigurasi (NOT CONNECTED).' : '' }, message: 'Jika email terdaftar, instruksi reset diproses.' });
  }

  if (route === 'reset') {
    const pwErr = passwordProblem(body.password);
    if (pwErr) return send(res, 400, { ok: false, code: 'BAD_PASSWORD', field: 'password', message: pwErr });
    const t = consumeToken(body.token, 'reset');
    if (!t || !db.users[t.email]) return send(res, 400, { ok: false, code: 'BAD_TOKEN', message: 'Token reset tidak valid atau sudah kedaluwarsa.' });
    const user = db.users[t.email];
    user.passwordHash = hashPassword(body.password); user.verified = true; user.fails = 0; user.lockedUntil = 0;
    for (const k of Object.keys(db.sessions)) if (db.sessions[k].email === t.email) delete db.sessions[k];
    saveDb();
    return send(res, 200, { ok: true, message: 'Password diganti. Semua sesi lama diakhiri. Silakan masuk.' });
  }
  return send(res, 404, { ok: false, code: 'NOT_FOUND', message: 'Endpoint tidak ada.' });
}

/* ---------- endpoint trading + scheduler (wajib sesi akun ASTRA; tidak ada order live) ---------- */
async function tradingApi(req, res, route) {
  refreshDb();
  if (req.method === 'POST') {
    if (!sameOrigin(req)) return send(res, 403, { ok: false, code: 'BAD_ORIGIN', message: 'Origin tidak diizinkan.' });
    if (!/^application\/json/i.test(req.headers['content-type'] || '')) return send(res, 415, { ok: false, code: 'BAD_TYPE', message: 'Content-Type harus application/json.' });
  }
  const sess = currentSession(req);
  if (!sess) return send(res, 401, { ok: false, code: 'UNAUTHENTICATED', message: 'Masuk dengan akun ASTRA terlebih dahulu.' });
  const sch = getScheduler(), owner = sess.email;
  if (route === 'scheduler' && req.method === 'GET') {
    return send(res, 200, { ok: true, status: sch.status(), emergencyStop: sch.isEmergency(), schedules: sch.list(owner), runs: sch.runsFor(owner) });
  }
  if (route === 'trading/status' && req.method === 'GET') {
    return send(res, 200, { ok: true, emergencyStop: sch.isEmergency(), scheduler: sch.status(), liveGate: { state: 'LIVE_BLOCKED', reason: 'API/izin resmi Olymptrade belum terverifikasi; tidak ada order live.' }, broker: { provider: 'Olymptrade', connection: 'NOT_CONNECTED', integration: 'UNVERIFIED' } });
  }
  if (req.method !== 'POST') return send(res, 404, { ok: false, code: 'NOT_FOUND', message: 'Endpoint tidak ada.' });
  let body;
  try { body = await readJson(req); } catch (e) { return send(res, e.status || 400, { ok: false, code: 'BAD_BODY', message: 'Body permintaan tidak valid.' }); }
  if (route === 'scheduler') {
    if (body.action === 'upsert') {
      const r = sch.upsert(owner, body.schedule);
      return send(res, r.ok ? 200 : 400, r.ok ? { ok: true, schedule: r.schedule } : { ok: false, code: r.code, message: r.errors.join(' '), errors: r.errors });
    }
    if (body.action === 'delete') { const r = sch.remove(owner, String(body.id || '')); return send(res, r.ok ? 200 : 404, { ok: r.ok, message: r.ok ? 'Dihapus.' : 'Jadwal tidak ditemukan.' }); }
    return send(res, 400, { ok: false, code: 'BAD_ACTION', message: 'action harus upsert atau delete.' });
  }
  if (route === 'trading/emergency') {
    if (body.action !== 'activate' && body.action !== 'reset') return send(res, 400, { ok: false, code: 'BAD_ACTION', message: 'action harus activate atau reset.' });
    return send(res, 200, sch.setEmergency(body.action === 'activate'));
  }
  if (route === 'trading/risk-check') {
    const mode = body.mode === 'LIVE' ? 'LIVE' : 'DRY_RUN';
    const intent = body.intent && typeof body.intent === 'object' ? body.intent : {};
    const ctx = Object.assign({}, body.context && typeof body.context === 'object' ? body.context : {}, { mode, emergencyStop: sch.isEmergency() }); // status emergency server tidak dapat di-override klien
    const verdict = RiskEngine.evaluate(intent, ctx, body.limits);
    return send(res, 200, { ok: true, verdict, liveGate: 'LIVE_BLOCKED', orderSent: false });
  }
  return send(res, 404, { ok: false, code: 'NOT_FOUND', message: 'Endpoint tidak ada.' });
}

/* ---------- berkas statis ---------- */
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.webmanifest': 'application/manifest+json', '.json': 'application/json' };
const BLOCKED = /^\/(server|tests|docs|android-app|node_modules)(\/|$)/;
const CSP = "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self' https://testnet.binance.vision https://data-api.binance.vision https://api.frankfurter.app wss://data-stream.binance.vision; frame-ancestors 'none'; base-uri 'none'; form-action 'self'";
function serveStatic(req, res) {
  let p;
  try { p = decodeURIComponent(new URL(req.url, 'http://x').pathname); } catch (e) { return send(res, 400, 'Bad request', { 'Content-Type': 'text/plain' }); }
  if (p.endsWith('/')) p += 'index.html';
  const file = path.resolve(ROOT, '.' + p);
  if (!file.startsWith(ROOT + path.sep) || BLOCKED.test(p) || /\/\./.test(p) || !MIME[path.extname(file)]) return send(res, 404, 'Not found', { 'Content-Type': 'text/plain' });
  fs.readFile(file, (err, buf) => {
    if (err) return send(res, 404, 'Not found', { 'Content-Type': 'text/plain' });
    send(res, 200, buf, { 'Content-Type': MIME[path.extname(file)], 'Cache-Control': file.endsWith('service-worker.js') ? 'no-cache' : 'no-cache', 'Content-Security-Policy': CSP });
  });
}

function createServer() {
  return http.createServer((req, res) => {
    const u = new URL(req.url, 'http://x');
    if (u.pathname.startsWith('/api/auth/')) {
      api(req, res, u.pathname.slice('/api/auth/'.length)).catch((e) => { console.error(e); if (!res.headersSent) send(res, 500, { ok: false, code: 'SERVER_ERROR', message: 'Kesalahan server.' }); });
    } else if (u.pathname === '/api/scheduler' || u.pathname.startsWith('/api/trading/')) {
      const route = u.pathname === '/api/scheduler' ? 'scheduler' : u.pathname.slice('/api/'.length);
      tradingApi(req, res, route).catch((e) => { console.error(e); if (!res.headersSent) send(res, 500, { ok: false, code: 'SERVER_ERROR', message: 'Kesalahan server.' }); });
    } else if (req.method === 'GET' || req.method === 'HEAD') serveStatic(req, res);
    else send(res, 405, { ok: false, message: 'Method tidak diizinkan.' });
  });
}

/* ---------- main ---------- */
function main() {
  loadDb();
  const [cmd, arg] = process.argv.slice(2);
  if (cmd === 'verify') {
    const email = normEmail(arg), u = db.users[email];
    if (!u) { console.error('Akun tidak ditemukan: ' + email); process.exit(1); }
    u.verified = true; saveDb(); console.log('Terverifikasi: ' + email); return;
  }
  setInterval(() => { purgeExpired(); saveDb(); }, 600000).unref();
  const sr = getScheduler().start(); console.log('Scheduler backend: ' + (sr.ok ? 'aktif (scan-only/dry-run, tanpa order)' : 'tidak aktif - ' + sr.reason));
  const port = Number(process.env.PORT || 8080), host = process.env.HOST || '127.0.0.1';
  createServer().listen(port, host, () => console.log('ASTRA server http://' + host + ':' + port + '  verifikasi=' + (REQUIRE_VERIFICATION ? 'wajib' : 'mati') + '  mail=' + MAIL_MODE));
}
if (require.main === module) main();
module.exports = { createServer, loadDb, getScheduler, _db: () => db };
