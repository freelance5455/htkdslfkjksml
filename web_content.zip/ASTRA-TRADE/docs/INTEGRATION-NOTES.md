# Integration notes — Advanced build

## Public market data

Provider di `js/integrations/market-data-provider.js` memakai endpoint data pasar spot publik:

- `GET https://data-api.binance.vision/api/v3/ticker/24hr?symbols=...` untuk statistik ticker.
- `GET https://data-api.binance.vision/api/v3/klines?symbol=...&interval=1m&limit=100` untuk candle historis aset terpilih.
- WebSocket `wss://data-stream.binance.vision/stream?...` untuk stream ticker publik.

Rujukan teknis: [Market Data Only](https://github.com/binance/binance-spot-api-docs/blob/master/faqs/market_data_only.md), [REST API](https://github.com/binance/binance-spot-api-docs/blob/master/rest-api.md), dan [WebSocket Streams](https://github.com/binance/binance-spot-api-docs/blob/master/web-socket-streams.md). Endpoint market-data-only tidak memberi akses ke user/account data.

Provider menormalisasi tipe data, memakai timeout permintaan, mencatat status error, mencoba reconnect WebSocket dengan backoff, dan menandai quote lama sebagai stale setelah 45 detik. Candle yang berhasil diperoleh dibedakan dari ticker/observasi sesi. Feed eksternal tidak disimpan di service-worker cache. Jika koneksi gagal, hasil pengujian tidak dapat membuktikan data live tersedia pada perangkat pengguna.

## Scanner dan observasi

Scanner memakai penutupan candle spot jika telah diambil, lalu memasukkan kuotasi terbaru sebagai titik terakhir jika berbeda. Jika candle historis tidak tersedia, ia memakai sampel ticker yang diterima selama sesi. Indikator adalah ringkasan deskriptif sederhana dan tidak menghasilkan sinyal transaksi.

`js/ledger/analysis-history.js` menyimpan observasi scanner lokal, bukan order. Maksimum 200 catatan; deduplikasi dibuat per simbol, metode, dan menit. Data disimpan di `localStorage`, sehingga merupakan catatan lokal perangkat dan bukan riwayat akun yang diaudit broker.

## Mode, risiko, dan eksekusi

`js/bot/bot-controller.js`, `js/bot/auto-trade-loop.js`, dan `js/bot/schedule-runner.js` hanya menjalankan observasi. `js/risk/risk-rules.js` memvalidasi konfigurasi analisis serta selalu menolak order live. K1–K5 tetap OFF. Tidak ada API order, private account endpoint, atau secret di frontend.

## Broker / OTC

`js/integrations/olymptrade-adapter.js` tetap disabled. Paket ini tidak mengimplementasikan koneksi akun privat atau otomatisasi order broker OTC. Jangan menyamakan harga spot publik dengan harga OTC, indeks, atau instrumen pada platform lain. Tidak dilakukan scraping login atau rekayasa protokol privat.

## Profil dan keamanan

Login adalah profil lokal; bukan autentikasi server. `localStorage` hanya menyimpan preferensi dan catatan observasi. `js/security/secure-storage.js` menolak penyimpanan rahasia. Jangan menambahkan API secret, password, token privat, atau kredensial broker ke HTML, JS client, ZIP publik, atau repo.
