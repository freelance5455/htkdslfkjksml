# Integration notes — Advanced build

## Public market data

Provider di `js/integrations/market-data-provider.js` memakai endpoint data pasar spot publik:

- `GET https://data-api.binance.vision/api/v3/ticker/24hr?symbols=...` untuk statistik ticker.
- `GET https://data-api.binance.vision/api/v3/klines?symbol=...&interval=1m&limit=100` untuk candle historis aset terpilih.
- WebSocket `wss://data-stream.binance.vision/stream?...` untuk stream ticker publik.

Rujukan teknis: [Market Data Only](https://github.com/binance/binance-spot-api-docs/blob/master/faqs/market_data_only.md), [REST API](https://github.com/binance/binance-spot-api-docs/blob/master/rest-api.md), dan [WebSocket Streams](https://github.com/binance/binance-spot-api-docs/blob/master/web-socket-streams.md). Endpoint market-data-only tidak memberi akses ke user/account data.

Provider menormalisasi tipe data, memakai timeout permintaan, mencatat status error, mencoba reconnect WebSocket dengan backoff, dan menandai quote lama sebagai stale setelah 45 detik. Candle yang berhasil diperoleh dibedakan dari ticker/observasi sesi. Feed eksternal tidak disimpan di service-worker cache. Jika koneksi gagal, hasil pengujian tidak dapat membuktikan data live tersedia pada perangkat pengguna.

## Scanner dan observasi

Scanner memakai penutupan candle spot jika telah diambil, lalu memasukkan kuotasi terbaru sebagai titik terakhir jika berbeda. Jika candle historis tidak tersedia, ia memakai sampel ticker yang diterima selama sesi. Indikator adalah ringkasan deskriptif sederhana dan tidak menghasilkan sinyal transaksi.

`js/ledger/analysis-history.js` menyimpan observasi scanner lokal, bukan order. Maksimum 200 catatan; deduplikasi dibuat per simbol, metode, dan menit. Data disimpan di `localStorage`, sehingga merupakan catatan lokal perangkat dan bukan riwayat akun yang diaudit broker.

## Mode, risiko, dan eksekusi

`js/bot/bot-controller.js`, `js/bot/auto-trade-loop.js`, dan `js/bot/schedule-runner.js` hanya menjalankan observasi. `js/risk/risk-rules.js` memvalidasi konfigurasi analisis serta selalu menolak order live. K1–K5 tetap OFF. Tidak ada API order, private account endpoint, atau secret di frontend.

## Olymptrade broker / OTC

Target broker saat ini adalah Olymptrade. `js/integrations/olymptrade-adapter.js` menyediakan capability gate yang aman, bukan konektor akun. Status developer API publik, private account read, posisi/riwayat, dan automatic order execution tetap `UNVERIFIED`; metode connect/getAccount/placeOrder/closePosition menolak secara eksplisit dan tidak mengirim request. Tidak ada form password/API secret karena metode resmi belum terverifikasi.

Penelusuran dokumentasi publik resmi yang diperiksa tidak menemukan spesifikasi developer API pihak ketiga yang dapat digunakan untuk memverifikasi endpoint, autentikasi, account read, atau order lifecycle. Ini bukan bukti mutlak bahwa tidak ada integrasi privat/partner; status harus tetap `UNVERIFIED` sampai Olymptrade memberikan dokumentasi/otorisasi resmi secara langsung. Library pihak ketiga atau endpoint privat platform tidak dipakai.

Sumber resmi yang ditinjau pada 2026-10-30:
- [Olymptrade Help Center — Robot trading](https://plus.olymptrade.com/id/help/category/trading/can-i-use-robots-when-trading-on-the-platform): menyatakan robot diperbolehkan kecuali digunakan untuk merusak platform atau melanggar prinsip kejujuran eksekusi transaksi.
- [Olymptrade Service Agreement, Part 2](https://olymptrade.com/id-id/pages/about/legal/service-agreement-part-two/): klausul 8.3(b) mengatur kerugian akibat penyalahgunaan layanan, termasuk algoritme transaksi otomatis/perangkat lunak yang memfasilitasi pelanggaran integritas, kejujuran, dan keadilan. Klausul ini bukan dokumentasi API dan bukan izin blanket untuk semua bentuk bot.
- Klausul 2.2 mendefinisikan instrumen Transaksi sebagai derivatif/contract-for-difference; jangan menganggapnya sebagai spot crypto exchange.
- Klausul 4.4.1 menyatakan klien tidak boleh memberikan password Terminal Trading kepada pihak ketiga. ASTRA tidak meminta atau mengambil password, OTP, cookie, maupun token sesi browser.

Karena penggunaan robot dinyatakan bersyarat dan dokumentasi akses programatik belum diverifikasi, minta konfirmasi tertulis dari dukungan Olymptrade sebelum memakai otomatisasi transaksi pada akun live. Data Binance spot yang masih ada di aplikasi hanya untuk latihan/analisis crypto spot; bukan quote atau harga eksekusi Olymptrade/OTC.

## Profil dan keamanan

Login adalah profil lokal; bukan autentikasi server. `localStorage` hanya menyimpan preferensi dan catatan observasi. `js/security/secure-storage.js` menolak penyimpanan rahasia. Jangan menambahkan API secret, password, token privat, atau kredensial broker ke HTML, JS client, ZIP publik, atau repo.
