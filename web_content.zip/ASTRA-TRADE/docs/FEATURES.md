# Feature checklist — ASTRA TRADE V1 Advanced

## Implemented and locally tested

- [x] Proyek dan UI lama dipertahankan; tidak ada halaman inti yang dihapus.
- [x] Splash/login profil lokal, empat tab utama, Terminal Control / Config / Schedule.
- [x] Ticker publik spot melalui REST + percobaan WebSocket, dengan normalisasi data dan status koneksi.
- [x] Candle historis 1 menit hingga 100 bar dari endpoint spot publik; grafik menyebut jenis sumber.
- [x] Penandaan snapshot lama (`STALE`) setelah 45 detik; feed error tidak menyamarkan update terakhir sebagai data segar.
- [x] EMA 9, EMA 21, RSI 14 Wilder, momentum 5 sampel, volatilitas return, dan rentang sampel.
- [x] Scanner menghasilkan observasi deskriptif; tidak membuat sinyal order BUY/SELL.
- [x] Config video-aligned: nominal, Duration 15 detik/1 menit/5 menit, strategi, market, mode analisis, Martingale sebagai preferensi simulasi, Bot Timer 1/3/5/10/15/30 menit atau 24 jam, Auto Trade Loop dan interval scan.
- [x] Baris referensi untuk BTCUSD OTC, ETHUSD OTC, Litecoin OTC, Crypto Composite Index, NHI Index, Asia Composite Index, dan Europe Composite Index; setiap sumber OTC/index yang belum tersedia diberi label `UNAVAILABLE`.
- [x] Validasi konfigurasi pasar/metode/durasi/interval dan penolakan eksplisit untuk eksekusi order.
- [x] Jadwal scan-only dengan validasi hari/waktu dan pencegahan pemicu ganda pada menit yang sama.
- [x] Riwayat observasi scanner lokal maksimum 200 catatan, deduplikasi per simbol/metode/menit, tampilan Ledger > Observations, dan ekspor JSON.
- [x] P&L/transaksi nyata tetap tidak tersedia tanpa data akun yang terverifikasi.
- [x] Secret-key storage guard tetap aktif; service worker cache shell versi baru tanpa menyimpan feed eksternal.

## Deliberately not implemented / external dependency

- [ ] Model AI terlatih atau AI eksternal: belum ada.
- [ ] Prediksi hasil atau rekomendasi transaksi otomatis: tidak disediakan.
- [ ] Integrasi akun privat/broker dan order live: tidak tersedia.
- [ ] Auto-open/close posisi, eksekusi Manual/Semi-Auto/Auto, dan Martingale K1–K5: tetap nonaktif.
- [ ] Saldo akun, P&L akun, win rate, serta transaksi nyata: belum tersedia.
- [x] Autentikasi server, verifikasi email, reset password (lihat docs/AUDIT-V1.md); pengiriman email (SMTP) belum terhubung.
- [ ] 2FA server dan biometric login: belum tersedia.
- [ ] Pengujian visual penuh pada Chrome Android: belum terselesaikan di lingkungan pembuatan paket.

Item di bagian kedua tidak boleh digambarkan sebagai fitur yang bekerja hanya karena ada elemen UI atau modul placeholder.

## Status sesi 2026-10-31 (WORKING = ada test; PARTIAL; NOT AVAILABLE; UNVERIFIED)

| Fitur | Status |
|---|---|
| Pilihan Jenis Transaksi Flex/InZone/Forex + konfigurasi terpisah | WORKING (lokal) |
| Spesifikasi broker per jenis | UNVERIFIED |
| Sinyal Flex/Forex BUY-SELL, InZone rentang/expiry (RULE-BASED) | WORKING pada data pembanding; bukan executable |
| Dry Run | WORKING |
| Paper Ledger per jenis × sumber | WORKING (browser-local, ESTIMATE) |
| Risk Engine (browser + backend) | WORKING; LIVE selalu diblokir |
| Scheduler backend scan-only/dry-run | PARTIAL (mencatat pemicu; pemindaian di server NOT IMPLEMENTED) |
| Koneksi akun / saldo / posisi Olymptrade | NOT AVAILABLE (UNVERIFIED) |
| Kuotasi Olymptrade / OTC / Index | NOT AVAILABLE |
| Live execution | NOT AVAILABLE |
| Model AI terlatih | NOT IMPLEMENTED |
| Android APK | NOT IMPLEMENTED (source only) |
