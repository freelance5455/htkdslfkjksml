# ASTRA TRADE V1 — Pemulihan Config berdasar Record

## Acuan
- ZIP `ASTRA-TRADE.zip` yang diserahkan untuk tugas ini.
- Video `Record_2026-10-29-11-59-28.mp4` berdurasi sekitar 97 detik.

## Perubahan
- Config memuat Trade Amount, Duration, Market/Asset, Execution Strategy, Trading Mode, scan polling interval, Martingale K1–K5 (preferensi simulasi), Bot Timer (batas durasi sesi 1/3/5/10/15/30 menit atau 24 jam), dan Auto Trade Loop (interval antar-observasi 1/5/15 menit).
- Auto loop memindai dan mencatat observasi saja. Mode Manual tidak dapat menjalankan Auto Trade Loop; Semi-Auto dan Auto dapat menjalankannya saat mesin analisis aktif.
- Bot Timer menghentikan mesin analisis setelah durasi yang dipilih (1/3/5/10/15/30 menit atau 24 jam) selama tab/browser tetap berjalan. Preferensi lama dalam jam dimigrasikan ke menit. Browser dapat membatasi timer di latar belakang.
- Martingale disimpan hanya sebagai parameter skenario; tidak ada penggandaan nominal atau order yang dilakukan.
- Pilihan OTC/index dari video tampil di Market Watch dan Config sebagai UNAVAILABLE/disabled sebab feed yang ada adalah data spot publik Binance. Sumber OTC tidak dipalsukan.
- AI Prediction Method ditandai belum tersedia; strategi teknikal yang sudah ada tetap dipakai.
- Trading Mode manager kini dimuat oleh `index.html` dan menjelaskan workflow analisis, tanpa memberikan izin order.

## Batasan yang tetap ada
- Tidak ada eksekusi order broker, pembukaan/penutupan posisi nyata, akun broker privat, atau P&L nyata.
- Data Binance Spot bukan harga OTC.
- Tidak ada model AI terlatih yang terbukti tersedia dalam proyek ini.
- Jadwal dan timer bergantung pada aplikasi/browser tetap berjalan.
