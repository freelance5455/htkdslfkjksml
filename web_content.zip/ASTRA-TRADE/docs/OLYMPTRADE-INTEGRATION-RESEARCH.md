# Olymptrade integration research and implementation status

**Review date:** 2026-10-30

## Decision summary

ASTRA's target broker is Olymptrade. The current source code does **not** claim account connectivity or trading execution. The official public resources reviewed did not yield a verifiable third-party developer API specification for private account reads, positions/history, quote delivery, or automated order submission. Therefore these capability statuses remain `UNVERIFIED`; account connection and live execution are `NOT AVAILABLE` in this build.

This is a bounded research conclusion, not a claim that Olymptrade has no private, partner-only, or support-provided integration. If Olymptrade provides official documentation or written authorization for a supported interface, re-audit its endpoints and terms before implementation.

## Official sources reviewed

1. [Olymptrade Help Center — Robot trading](https://plus.olymptrade.com/id/help/category/trading/can-i-use-robots-when-trading-on-the-platform). The official help article says robots are allowed unless used to damage the platform or violate honest transaction execution.
2. [Olymptrade Service Agreement — Part 2](https://olymptrade.com/id-id/pages/about/legal/service-agreement-part-two/). Clause 8.3(b) describes customer responsibility for damage resulting from abuse of services, including automated/robotized transaction algorithms or special software/tools that facilitate a breach of integrity, honesty, and fairness. This is a conditional restriction, not a blanket API grant.
3. The same Service Agreement, clause 2.2, describes the relevant trading transactions as derivative contracts based on underlying asset-price differences. ASTRA must not retain Indodax/crypto Spot assumptions for Olymptrade instruments.
4. The same Service Agreement, clause 4.4.1, says the client must not provide the Trading Terminal password to a third party. ASTRA therefore must not request or collect that password.
5. [Olymptrade official legal information](https://olymptrade.com/id-id/pages/about/legal/) links the current service agreement documents and risk disclosures.

No public API endpoints, request-signing method, API key format, official WebSocket contract, account-data schema, or order-submission contract have been verified in this review. Community libraries and undocumented/private terminal protocols are deliberately excluded.

## Source-code changes in this patch

- `js/integrations/olymptrade-adapter.js`: capability gate with explicit `UNVERIFIED` and `NOT_AVAILABLE` states; methods reject rather than simulate connectivity or execution.
- `js/integrations/integration-manager.js`: lists Olymptrade separately from public market-data provider and exposes status.
- `index.html`: loads the adapter before the integration manager.
- `js/app.js`: Account Connection dialog now names Olymptrade, provides official links, explains the current capability limitation, and warns against password/OTP/cookie/session collection.
- `tests/olymptrade-adapter-test.js`: checks the safe rejection and status behavior.

## Paper Lab improvements

- `js/paper-bot.js` now saves/restores virtual equity, P&L, virtual open position, paper trade history, risk preference, and current paper symbol in local browser storage.
- A reload restores the paper ledger but **does not restart the bot automatically**. User must press Start.
- The Reset Simulation control requires explicit browser confirmation.
- The interface makes clear that the price feed is Binance crypto spot, not Olymptrade quote data.
- `tests/paper-bot-persistence-test.js` checks state restoration and explicit manual restart.

## Capability matrix

| Capability | Status | Evidence / reason |
|---|---|---|
| Official robot policy | `CONDITIONAL` | Help Center and Service Agreement; do not interpret as unconditional approval. |
| Public third-party developer API | `UNVERIFIED` | No verifiable official public developer specification identified in this review. |
| Private account authentication | `UNVERIFIED` | No official auth contract verified. |
| Balance / account overview | `UNVERIFIED` | No official private account schema verified. |
| Positions / history | `UNVERIFIED` | No official data contract verified. |
| Official account market feed / OTC quotes | `UNVERIFIED` | Existing Binance/ECB sources are not Olymptrade feed. |
| Order opening / closing | `NOT AVAILABLE` | No verified authorized request contract; adapter rejects. |
| Live trading | `NOT AVAILABLE` | Requires verified interface and broker permission first. |
| Binance Crypto Spot Paper Lab | `PARTIAL` | Simulated only; now persists locally; not Olymptrade pricing. |

## Next required steps

1. Ask Olymptrade support whether a documented API/partner interface exists for individual accounts in the user's account region and whether automated opening/closing of the relevant instruments is authorized. Request official documentation, API access terms, demo environment (if any), auth and order specifications.
2. If official documentation is supplied, independently verify endpoint domains, auth, account scopes, instrument identifiers, quote timestamp semantics, min/max amount, expiration, payout/fee model, rate limits, request idempotency, result reconciliation, and regional availability.
3. Implement server-side integration only after verification. Never use the user's terminal password, OTP, browser cookie, session token, or private undocumented protocol.
4. Build a broker-specific demo/test adapter if officially available; test full lifecycle and restart reconciliation.
5. Keep live execution unavailable until legal, technical, risk, and security gates are passed.

## Verification

Run from project root:

```bash
node tests/olymptrade-adapter-test.js
node tests/paper-bot-persistence-test.js
```

These are code-level tests only. They do not authenticate an Olymptrade account, verify external connectivity, or place an order.

## Re-audit 2026-10-31

Tidak ada dokumen resmi/API credential baru di unggahan. Pencarian web hanya menemukan library komunitas (tidak resmi, memakai protokol privat) yang **sengaja tidak dipakai**. Screenshot pilihan Flex/InZone/Forex bukan bukti API.

| Kemampuan | Flex | InZone | Forex |
|---|---|---|---|
| API/partner resmi | UNVERIFIED | UNVERIFIED | UNVERIFIED |
| Autentikasi akun | NOT_AVAILABLE | NOT_AVAILABLE | NOT_AVAILABLE |
| Saldo / posisi / riwayat | UNVERIFIED | UNVERIFIED | UNVERIFIED |
| Instrument list & kuotasi broker | UNVERIFIED | UNVERIFIED | UNVERIFIED |
| Order open/close/status | NOT_AVAILABLE | NOT_AVAILABLE | NOT_AVAILABLE |
| Demo/sandbox | UNVERIFIED | UNVERIFIED | UNVERIFIED |
| Izin automated trading | CONDITIONAL (Help Center) — bukan hibah API | idem | idem |
| Spesifikasi (aset, jam, min/maks, durasi, payout, multiplier, spread, margin, kontrak) | UNVERIFIED | UNVERIFIED | UNVERIFIED |
| Simulasi lokal (Dry Run/Paper, data pembanding) | WORKING | WORKING | PARTIAL (hanya ECB harian → sinyal NO_DATA) |

**Dibutuhkan dari Olymptrade (tertulis/resmi):** dokumentasi API atau konfirmasi partner untuk akun individu & wilayah pengguna; metode autentikasi resmi dan scope; daftar instrumen per jenis; kuotasi dan timestamp; aturan min/maks, durasi, payout/fee, rentang & aturan batas InZone, multiplier/SL/TP/margin Forex; lingkungan demo; rate limit; izin automated trading. Dilarang: password Terminal, OTP, cookie/token sesi, scraping, endpoint privat, library komunitas.
