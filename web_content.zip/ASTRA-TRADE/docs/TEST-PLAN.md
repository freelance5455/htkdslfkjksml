# Test plan — ASTRA TRADE V1 Advanced

## Automated tests

From the project directory:

```bash
node tests/smoke-test.js
node tests/market-data-test.js
```

The smoke test covers HTML asset references, indicator calculations, strategy descriptions, schedule validation and duplicate prevention, local observation history, config validation, live-order denial, and secret-key storage guard.

The market-data test uses mock HTTP responses to cover ticker normalization, historical candle normalization, source labels, chart history, stale detection, and HTTP failure reporting. It does not test connectivity to the real external service.

## Data integrity

- Online-device check: verify real ticker and candle values arrive from the public endpoint and note the update time.
- Offline or blocked network: verify UI labels unavailable/error/stale rather than fabricating prices.
- Verify public spot data is not labelled as OTC/index data from another platform.
- Verify P&L, trades, wins, losses and win rate remain unavailable without verified transaction records.

## UI / navigation (manual required)

- Verify splash/login, local profile setup, Terminal / Market / Ledger / Profile navigation.
- Verify Terminal Control / Config / Schedule tabs.
- Select each supported market and check that candle fetch failure falls back to correctly labelled observation history.
- Visit Ledger > Observations after the scanner receives sufficient samples and export JSON; confirm the exported data is explicitly non-trade data.
- Verify stale quote label, error status, and refresh behavior on the target phone.

## Safety / storage

- Verify Start/Halt controls only control analysis and do not place orders.
- Verify K1–K5 remain OFF and `RiskRules.canExecuteOrder()` returns `ok:false`.
- Verify 2FA/biometric and private account features remain unavailable.
- Verify no secret credentials are persisted in localStorage or packaged frontend files.

## Compatibility / remaining manual tests

- Chrome Android portrait and landscape.
- HTTPS hosting + service worker install/activate/offline shell.
- Real feed availability, REST timeout, WebSocket reconnect, and Android background throttling.
- Manual browser/UI testing is required before any distribution. No full browser test is claimed by the package build report.
