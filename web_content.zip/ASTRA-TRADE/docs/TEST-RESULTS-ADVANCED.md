# Test results — Advanced package

Tanggal pemeriksaan: 29 Oktober 2026 (waktu lingkungan pembuatan).

## PASS

- `node tests/smoke-test.js` — lulus. Memeriksa referensi asset di `index.html`, indikator, strategi observasi, jadwal, riwayat observasi lokal, validasi konfigurasi, penolakan order live, opsi Config/durasi yang dirender, instrumen OTC/index berlabel `UNAVAILABLE`, migrasi serta callback Bot Timer, dan secret-key storage guard.
- `node tests/market-data-test.js` — lulus. Memakai respons mock untuk normalisasi ticker, normalisasi candle, sumber data, grafik candle, deteksi data stale, dan penanganan HTTP 503.
- `node --check` pada semua file JavaScript — lulus.
- Total 70 referensi lokal HTML `src`/`href`, CSS `url()`, dan ikon manifest diperiksa — tidak ada referensi yang hilang.
- Tidak ada file proyek kosong yang terdeteksi saat audit.
- Order live tetap dinonaktifkan dan `RiskRules.canExecuteOrder()` diuji mengembalikan `ok: false`.

## NOT TESTED / terbatas

- Feed live REST/WebSocket dari jaringan eksternal: NOT TESTED. Tes provider menggunakan mock.
- Interaksi UI penuh dalam Chromium headless: percobaan timeout di lingkungan build; tidak dicatat sebagai PASS.
- Pengujian Chrome Android portrait/landscape: NOT TESTED.
- Service worker/PWA dan perilaku offline end-to-end pada hosting HTTPS: NOT TESTED.
- Keamanan backend, autentikasi server, integrasi akun privat, transaksi, dan order broker: NOT TESTED dan tidak termasuk dalam build ini.

## Kesimpulan

Pemeriksaan statis dan tes logika yang tersedia lulus. Paket ini layak disebut build pengembangan **read-only market analytics**, bukan aplikasi trading live dan bukan sistem AI trading yang sudah terbukti.
