# Android setup (phone-only)

## Quick visual test

1. Extract the ZIP in ZArchiver.
2. Open `ASTRA-TRADE/index.html` with Chrome.
3. The interface works locally, but the external feed may not work reliably from a `file://` origin.

## For real public quotes and PWA install

1. Host the contents of this folder on an HTTPS static host you control.
2. Do not upload any API key, secret, account password, or private data.
3. Open the HTTPS page in Chrome while online.
4. Check the feed status: `LIVE DATA`, `LIVE DATA · REST`, `STALE`, `DISCONNECTED`, or `UNAVAILABLE`.
5. If the feed is unavailable, try refresh once and verify connectivity; the app must show `Belum tersedia` rather than a fabricated value.
6. On a compatible browser, open the browser menu and choose **Add to Home screen** / **Install app** if offered.

This is a web/PWA project. The ZIP itself is not an APK. A static build does not provide server login, private account integration, or order execution.
