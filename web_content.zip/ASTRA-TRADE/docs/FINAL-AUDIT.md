# ASTRA TRADE V1 — catatan pemeriksaan paket

## Pemeriksaan yang dijalankan

- Referensi file JS/CSS yang ditautkan dari `index.html` diperiksa dengan smoke test.
- Semua file JavaScript diperiksa sintaksnya dengan `node --check`.
- `node tests/smoke-test.js` dijalankan untuk memeriksa asset utama, perhitungan indikator, mode metode analisis, validasi/normalisasi jadwal, pencegahan pemicu jadwal duplikat, dan penolakan key penyimpanan yang tampak seperti secret.
- Modul tambahan yang belum terhubung langsung ke UI tetap dipertahankan, tetapi tidak diklaim aktif. Beberapa di antaranya adalah stub yang secara eksplisit menyatakan bahwa fitur (misalnya AI Mentor, adaptive learning, Olymp Trade adapter, atau export/import modular) belum diimplementasikan.
- ZIP final diperiksa kembali dengan `unzip -t`.

## Batas pemeriksaan

Uji browser penuh pada Chromium headless tidak selesai dalam batas waktu lingkungan ini, sehingga tidak dicatat sebagai lulus. Feed REST/WebSocket juga bergantung pada koneksi, kebijakan jaringan, dan dukungan hosting. Sebelum rilis, lakukan pengujian visual dan jaringan pada Chrome Android melalui HTTPS.

## Batas fungsional yang tetap berlaku

- Feed harga publik Binance spot, bukan feed OTC dari video.
- Tidak ada API akun privat, autentikasi server, order live, open/close posisi otomatis, atau riwayat transaksi akun.
- Scanner merupakan observasi indikator sederhana dan bukan model AI.
- Jadwal hanya menjalankan scan lokal saat aplikasi terbuka; browser dapat membatasi timer latar belakang.

## Pembaruan restorasi Config berdasarkan video Record

- Config dirender dan diuji secara terpisah untuk memastikan field Trade Amount, Duration, Market/Asset, Execution Strategy, Trading Mode, scan interval, Martingale K1–K5, Bot Timer, Auto Trade Loop, dan tombol simpan muncul.
- `node tests/smoke-test.js` mencakup pemeriksaan renderer Config, tiga Trading Mode, preferensi Martingale simulasi, dan penolakan izin order nyata.
- Seluruh file JavaScript di `js/` dan `tests/` kembali lulus `node --check`.
- Pengujian Chromium headless tidak berhasil diselesaikan karena proses browser tidak keluar di lingkungan ini; tampilan visual penuh di Chrome Android belum dinyatakan lulus.
- Sumber OTC resmi, model AI terlatih, akun broker privat, dan order live tetap belum tersedia dalam build ini.
