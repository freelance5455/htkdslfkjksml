# Changelog — Advanced package

Basis: `ASTRA-TRADE-V1-FINAL.zip` / input yang diunggah. Struktur dan desain inti dipertahankan.

- Market data provider: normalisasi nilai lebih ketat, label jenis pasar spot, timeout permintaan, error surfacing, freshness 45 detik, stale flag per simbol, dan reconnect WebSocket dengan backoff.
- Chart history: tambah endpoint candle spot 1 menit, cache hasil singkat, pelabelan `historical candles + latest quote`, serta fallback ke observasi feed tanpa harga buatan.
- Indicators: tambah momentum 5 sampel, standard deviation return, rentang sampel; RSI dihitung dengan smoothing Wilder.
- Scanner: status ketersediaan/kedaluwarsa data, sumber spot publik, disclaimer yang lebih tegas, dan tidak ada output sinyal order.
- Risk rules: validasi batas nominal/durasi/interval/market/metode dan penolakan eksplisit order live.
- Ledger: tambah `js/ledger/analysis-history.js`, tab Observations, ekspor JSON; catatan diberi klasifikasi `OBSERVATION_ONLY`, bukan transaksi.
- PWA: nama cache dinaikkan ke `astra-trade-shell-v4` agar browser memperbarui shell setelah perubahan terbaru; modul riwayat observasi masuk shell cache.
- Penyelarasan video: Market Watch memisahkan aset spot publik dan instrumen OTC/index referensi yang berstatus `UNAVAILABLE`; opsi Duration 15 detik/1 menit/5 menit; Bot Timer 1/3/5/10/15/30 menit atau 24 jam dengan migrasi preferensi lama; status feed tanpa data awal tidak lagi salah disebut `STALE`.
- Tests: tambah `tests/market-data-test.js`, perluas `tests/smoke-test.js`.
- Docs: audit, changelog, test results, feature status dan integration notes diperbarui.

Tidak ditambahkan: API akun privat, order placement/cancellation, broker OTC adapter, model AI terlatih, Martingale eksekusi, atau transaksi dummy.

- Follow-up: added seven major Forex pairs in Market Watch using dated Frankfurter/ECB daily reference rates; labelled explicitly as REFERENCE RATE (not streaming/live broker ticks). Added forex-reference-test.js.
