# Architecture — ASTRA TRADE V1

## Layer

1. `index.html`: app shell, splash, local login, top bar, view region, bottom navigation.
2. `css/`: theme tokens, base reset, controls, page-level styles, animation and responsive rules.
3. `js/event-bus.js`: decoupled pub/sub event channel.
4. `js/config/`: defaults for app, account, exchange, bot, strategy, risk, security, schedule, scanner and storage. `config-registry.js` validates override keys and types.
5. `js/storage/`: local UI preferences only. It rejects secret-like key names.
6. `js/integrations/market-data-provider.js`: public ticker REST + public websocket feed; read-only.
7. `js/strategy/` and `js/ai/`: indicator calculations and explicitly labelled rule-based observation. No trained AI model or execution signal is claimed.
8. `js/risk/`: nominal validation and hard denial for order execution.
9. `js/bot/`: control of analysis loop and local scan schedule only. Slot modules are separate and disabled.
10. `js/ledger/`: returns unavailable when private account/trade history is not connected.
11. `js/router.js` + `js/app.js`: hash router and rendered four-tab UI.

## Data flow

`Public REST/WebSocket -> MarketData -> EventBus -> UI / indicator scanner`.
Private account and order routes are intentionally absent. `OlympTradeAdapter` is loaded as a capability gate only: unknown official API capability is reported as UNVERIFIED and connection/account/order calls reject. The public Binance spot feed can update the UI without credentials. No sample ticker, fake broker trade, seeded P&L, or invented win-rate is provided.

## Security boundary

This is a static client-side web app, not a secure account service. Do not add API secrets to JavaScript, HTML, `localStorage`, a public repository, or chat. Any future private-account or order service must use an officially documented and authorized Olymptrade interface, run server-side with authenticated sessions, least-privilege credentials, rate limits, audit logs, and explicit authorization. Do not reverse-engineer private terminal protocols or collect Terminal Trading passwords.

## Tambahan 2026-10-31

- `js/trading/transaction-types.js` (UMD): FLEX/INZONE/FOREX, validasi per jenis, spesifikasi UNVERIFIED, store konfigurasi per jenis.
- `js/integrations/quote-source.js`: provenance BINANCE_SPOT / ECB_REFERENCE / OLYMPTRADE (tidak tersedia).
- `js/ai/entry-signal.js`: sinyal RULE-BASED per jenis transaksi; tidak pernah executable.
- `js/risk/risk-engine.js` (UMD): dipakai browser (Dry Run, Paper, Live Gate) dan `server/server.js` (`/api/trading/risk-check`).
- `js/trading/dry-run.js`, `js/ledger/paper-ledger.js`, `js/trading/live-gate.js`, `js/ui/trade-panel.js`.
- `server/scheduler.js`: scheduler persisten + status Emergency Stop (`trading-state.json`, `schedules.json`, `scheduler.lock` di `ASTRA_DATA_DIR`).

Alur: Quote → Scanner → EntrySignal(transactionType) → RiskEngine → {DryRun | PaperLedger | LiveGate(tertutup)}. Hanya LiveGate yang berpotensi menyentuh adapter, dan saat ini selalu menolak.
