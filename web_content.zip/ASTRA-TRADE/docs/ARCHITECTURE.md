# Architecture — ASTRA TRADE V1

## Layer

1. `index.html`: app shell, splash, local login, top bar, view region, bottom navigation.
2. `css/`: theme tokens, base reset, controls, page-level styles, animation and responsive rules.
3. `js/event-bus.js`: decoupled pub/sub event channel.
4. `js/config/`: defaults for app, account, exchange, bot, strategy, risk, security, schedule, scanner and storage. `config-registry.js` validates override keys and types.
5. `js/storage/`: local UI preferences only. It rejects secret-like key names.
6. `js/integrations/market-data-provider.js`: public ticker REST + public websocket feed; read-only.
7. `js/strategy/` and `js/ai/`: indicator calculations and explicitly labelled rule-based observation. No trained AI model or execution signal is claimed.
8. `js/risk/`: nominal validation and hard denial for order execution.
9. `js/bot/`: control of analysis loop and local scan schedule only. Slot modules are separate and disabled.
10. `js/ledger/`: returns unavailable when private account/trade history is not connected.
11. `js/router.js` + `js/app.js`: hash router and rendered four-tab UI.

## Data flow

`Public REST/WebSocket -> MarketData -> EventBus -> UI / indicator scanner`.
Private account and order routes are intentionally absent. The public feed can update the UI without credentials. No sample ticker, fake trade, seeded P&L, or invented win-rate is provided.

## Security boundary

This is a static client-side web app, not a secure account service. Do not add API secrets to JavaScript, HTML, `localStorage`, a public repository, or chat. Private account and order services must be implemented server-side with authenticated sessions, least-privilege credentials, request signing, rate limits, audit logs, and explicit authorization before any future production release.
