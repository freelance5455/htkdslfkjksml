# Prompt sesi berikutnya — ASTRA TRADE V1

Lanjutkan proyek dari ZIP terbaru (jangan bangun ulang). Baca `docs/CONTINUATION-STATUS.md`, `docs/OLYMPTRADE-INTEGRATION-RESEARCH.md`, `docs/AUDIT-V1.md`; jalankan `node tests/run-all.js` lebih dulu.

Prioritas:
1. Jika saya melampirkan dokumen/API resmi Olymptrade: audit per kemampuan dan per jenis (Flex/InZone/Forex), daftarkan spesifikasi terverifikasi via `TransactionTypes.registerVerified()` dengan bukti, implementasikan adapter backend resmi, uji demo, lalu buka Live Gate bertahap (konfirmasi eksplisit, idempotensi, rekonsiliasi). Jika tidak ada: jangan menebak endpoint.
2. Scheduler backend: pemindaian di server (fetch data pasar publik → EntrySignal/DryRun) dengan test mock.
3. Paper ledger backend (persisten server) bila diperlukan.
4. Android: bangun APK bila Android SDK tersedia; sertakan bukti build.
5. Tetap: RULE-BASED (tanpa klaim AI), Binance/ECB bukan harga Olymptrade, tidak ada order uji dengan dana nyata.
