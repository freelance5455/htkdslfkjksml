# ASTRA TRADE V1 — Android Native Continuation

## Product target
Personal Android EA/bot, flexible platform/account choice, automatic strategy, live market data, and real order execution only after a platform connector is implemented and verified. The bot starts when the user presses START BOT and should continue while the app is backgrounded through a user-started foreground service. No VPS/server is assumed.

## Added in this continuation
- `android-app/`: native Android/Kotlin starter project structure.
- `MainActivity`: START BOT / STOP BOT controls and transparent connector status.
- `TradingEngineService`: user-started foreground service with persistent notification.
- `TradingConnector`: platform-neutral interface for quote, account snapshot, submit order, status, and disconnect.
- `RiskManager`: quote freshness/validity guard; live execution remains locked until a concrete adapter is verified.

## Honest implementation status
This is a native Android source scaffold, not a built APK and not yet a live trading bot. No exchange/broker is connected, no account credentials are requested, and no live orders are sent. The prior PWA and its paper-trading lab remain included for continuity, but neither should be mistaken for live execution.

## Flexible account strategy
The strategy engine is intended to be platform-independent. Platform-specific connectors are optional modules. The connector contract does not mandate one vendor's official API as the only design, but each concrete connector must use a method that actually works, is authorized for the account, and can verify order outcomes. UI automation, where considered, must be platform-specific and must not bypass authentication, defeat platform restrictions, or blindly click financial controls without state verification.

## Android background behavior
The user starts the service from the visible activity; a persistent notification makes the ongoing process visible. Android/OEM battery management can still stop the process. Network loss means no fresh quotes or order submissions until reconnection. On restart, the app must reconcile remote positions/orders before resuming any strategy. Foreground service permissions and behavior must be checked against the target Android version and distribution method.

## Next implementation gates
1. Implement market-data parsing and freshness state in the native engine.
2. Define a strategy interface with explicit `BUY`, `SELL`, `HOLD`, and `NO_TRADE` decisions.
3. Implement risk limits and a persistent local trade/event journal.
4. Select and implement one concrete platform connector with a verified, authorized live execution path.
5. Add order idempotency, order-status reconciliation, reconnect/backoff, daily loss limits, and emergency stop.
6. Build/sign the APK with Android SDK/Gradle and test on the target phone. This environment did not build or install an APK.

## Important
Never describe a connector as live until a real account connection, a real quote, a deliberately authorized small test order, and order-status reconciliation have been verified. Do not put account passwords, session cookies, or API secrets in source code or chat.
