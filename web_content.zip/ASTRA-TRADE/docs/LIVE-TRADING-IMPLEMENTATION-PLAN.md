# ASTRA TRADE V1 — Rencana Implementasi Live Trading (Broker Belum Dipilih)

Tanggal audit: 2026-10-30

## Status saat ini berdasarkan kode proyek

- Proyek adalah web/PWA statis dengan JavaScript vanilla, bukan APK native.
- `js/integrations/market-data-provider.js` mengambil ticker 24 jam, candle, dan WebSocket dari Binance Spot untuk BTCUSDT, ETHUSDT, SOLUSDT, BNBUSDT, XRPUSDT, DOGEUSDT, ADAUSDT, LTCUSDT. Ini read-only dan bukan harga OTC.
- `js/integrations/forex-reference-provider.js` menyediakan kurs referensi harian; bukan tick Forex real-time.
- `js/integrations/integration-manager.js` menandai private account/order execution unavailable.
- `js/integrations/base-adapter.js` menolak `placeOrder`; `js/integrations/olymptrade-adapter.js` disabled.
- `js/risk/risk-rules.js` secara sengaja menolak order live. BotController/AutoTradeLoop saat ini merupakan mesin observasi/analisis.
- Login/profil dan penyimpanan preferensi lokal bukan autentikasi broker.

## Rekomendasi teknis sementara

Karena broker belum dipilih, jangan aktifkan live execution dan jangan menanam API key dalam browser. Pertahankan frontend PWA, dan tambahkan backend gateway terpisah untuk data privat dan order. Kontrak adapter dibuat broker-neutral, tetapi adapter konkret baru boleh dibuat setelah broker, negara/entitas akun, jenis akun, dan instrumen diverifikasi.

Kandidat yang bisa diteliti, bukan dipilih otomatis:

1. **MetaTrader 5 (MT5)**: dokumentasi resmi MQL5 menyediakan integrasi Python melalui terminal MT5, termasuk simbol, tick, candle, posisi, pemeriksaan order, dan `order_send`. Cocok bila broker pengguna menyediakan MT5 dan mengizinkan algo trading. Perlu gateway backend yang menjaga terminal tetap berjalan; PWA tidak boleh langsung memanggil library MT5.
2. **OANDA v20**: dokumentasi resminya menyebut harga real-time, histori, dan endpoint order untuk akun v20 yang memenuhi syarat. Ketersediaan bergantung pada divisi/negara dan jenis akun. Harus diperiksa apakah pengguna dapat membuka akun serta apakah XAU/USD dan semua instrumen yang diminta tersedia pada akun itu.
3. **Binance**: API spot publik yang sudah ada dapat dipakai untuk data kripto. Trading privat memerlukan integrasi akun terpisah dan kebijakan izin API; tidak menyediakan Forex spot/CFD atau XAU/USD hanya karena ada pair kripto.

Dokumentasi resmi untuk validasi awal:
- MT5 Python: https://www.mql5.com/en/docs/python_metatrader5
- OANDA v20 introduction: https://developer.oanda.com/rest-live-v20/introduction/
- OANDA pricing: https://developer.oanda.com/rest-live-v20/pricing-ep/
- OANDA order endpoints: https://developer.oanda.com/rest-live-v20/order-ep/

## Tahap implementasi yang spesifik

### Tahap 0 — Kunci pilihan broker (wajib sebelum coding order live)

Dapatkan nama broker dan entitas hukumnya, negara akun, akun demo/live, dokumentasi API resmi, serta daftar simbol yang benar-benar tersedia. Verifikasi: akses legal dari negara pengguna, izin algo/API, rate limits, autentikasi, harga bid/ask, tick/candle, jam pasar, order market/pending, stop loss/take profit, close/modify, minimum volume, lot step, leverage/margin, komisi, swap, dan kode simbol broker. Jangan menganggap `EURUSD`, `XAUUSD`, atau `BTCUSD` tersedia dengan nama yang sama pada semua broker.

**Gate:** jika broker tidak menyediakan API resmi/diizinkan atau simbol yang diperlukan, tandai integrasi `UNAVAILABLE`; jangan scraping halaman login atau meniru protokol privat.

### Tahap 1 — Pisahkan provider data

Pertahankan `MarketData` Binance sebagai provider spot read-only. Buat interface `MarketDataAdapter` (`connect`, `disconnect`, `getSymbols`, `getQuote`, `getCandles`, `status`) dan adapter khusus provider terpilih. Normalisasi setiap quote dengan `provider`, `instrument`, `marketType`, `bid`, `ask`, `last`, `timestamp`, `receivedAt`, `stale`, dan `sourceType`. Simpan jenis data `LIVE`, `REFERENCE`, `DELAYED`, `PAPER`, `STALE`, `UNAVAILABLE` secara eksplisit. Jangan gabungkan quote Binance dengan quote OTC/CFD seolah satu feed.

### Tahap 2 — Tambahkan backend gateway

Tambahkan service terpisah (misalnya Python FastAPI untuk MT5 bridge atau Node/Python service sesuai API broker) di luar static frontend. Browser hanya berbicara ke gateway melalui HTTPS/WSS dengan sesi terautentikasi. Secret broker disimpan pada environment/secret store server, tidak di `localStorage`, HTML, JavaScript frontend, ZIP publik, atau chat. Terapkan allowlist origin, autentikasi pengguna, pembatasan request, audit log, timeout, retry aman, dan pemutusan koneksi.

### Tahap 3 — Mode demo dan observabilitas

Buat mode `READ_ONLY`, `PAPER`, `BROKER_DEMO`, dan `LIVE` yang eksplisit. Default `READ_ONLY`; live off secara default. Broker demo harus menggunakan akun demo terpisah. UI selalu menunjukkan provider, jenis pasar, waktu tick, umur data, bid/ask, koneksi, mode akun, dan status order yang berasal dari respons broker. Jangan tampilkan `LIVE DATA` hanya karena WebSocket terbuka; harus ada quote valid yang belum kedaluwarsa.

### Tahap 4 — Scanner dan strategi

Ubah scanner agar menerima interface feed dan candle yang terpilih, bukan mengasumsikan semua simbol adalah Binance spot. Validasi perhitungan EMA 9/21, RSI 14, momentum, volatilitas, spread, candle belum selesai, gap data, zona waktu, dan simbol yang tidak tersedia. Setiap sinyal harus menyertakan input, timestamp, metode, dan alasan; tidak boleh disebut AI jika hanya aturan deterministik. Backtest harus memasukkan spread, komisi, slippage, swap, latency, dan survivorship/look-ahead checks.

### Tahap 5 — Paper trading

Implementasikan ledger simulasi terpisah dengan entry/exit, ukuran posisi, biaya, P&L terealisasi/tidak terealisasi, dan alasan penutupan. Gunakan candle/tick dari provider yang sama dengan instrumen sasaran. Jalankan periode paper trading dan bandingkan hasil dengan fill dan spread realistis. K1–K5 tidak boleh menggandakan nominal secara otomatis tanpa batas kerugian keras; default OFF. Tambahkan batas posisi, batas risiko per trade/hari, max drawdown, max spread, stale-data block, market-hours block, emergency stop, dan order deduplication.

### Tahap 6 — Broker demo end-to-end

Bangun order lifecycle: preflight → submit → ack/reject → partial fill/fill → amend/cancel/close → reconcile dengan posisi/riwayat broker. Pakai client order ID/idempotency bila didukung. Jangan menganggap request HTTP sukses sebagai fill. Rekonsiliasi state setelah reconnect dan restart. Uji disconnect, timeout saat order sedang diproses, partial fill, market closed, insufficient margin, invalid volume, slippage, duplicate click, serta restart service.

### Tahap 7 — Live trading dengan gate manual

Aktifkan hanya setelah: API resmi terverifikasi; demo tests lulus; risk limits teruji; audit keamanan selesai; pengguna menyetujui broker/simbol/ukuran risiko; tombol kill switch dan monitoring aktif. Mulai dengan ukuran minimum dan tanpa Martingale. Live execution harus memerlukan konfirmasi eksplisit terpisah; jangan otomatis mengubah demo menjadi live.

### Tahap 8 — Android dan deployment

Karena proyek ini PWA, uji instalasi PWA di Android setelah deployment HTTPS. Untuk gateway live, gunakan server yang selalu hidup, monitoring, alert, backup, rotasi secret, dan pembatasan jaringan. Jangan mengklaim bot tetap bekerja ketika browser/ponsel ditutup kecuali loop benar-benar berjalan pada backend terkelola dan statusnya bisa dipantau.

## Kriteria penerimaan (belum dinyatakan lulus)

- Data real: quote bersumber dari provider resmi, timestamp dan bid/ask valid, stale/disconnected diuji.
- Instrumen: setiap simbol dikonfirmasi dari daftar simbol akun broker, termasuk XAU/USD bila diminta.
- Orders: lifecycle lengkap diverifikasi melalui akun demo dan direkonsiliasi dengan broker.
- Keamanan: tidak ada secret di frontend; endpoint terlindungi; audit log dan kill switch diuji.
- Risiko: limit dan stale-data block diuji, K1–K5 OFF default, tidak ada order duplikat.
- UI: halaman asli dipertahankan; status mode/provider terlihat; uji Android dilakukan di perangkat nyata sebelum klaim.
- Reproducibility: tes otomatis, versi dependency, langkah deployment, dan laporan hasil disertakan.

## Yang belum dapat dipastikan tanpa pilihan broker

Dukungan Forex, XAU/USD, kripto, OTC, izin algo trading, harga live, jenis order, dan ketersediaan API di negara akun. Tidak ada live trading yang diaktifkan dalam build ini. Dokumen ini adalah rencana implementasi, bukan bukti bahwa order live telah diuji.
