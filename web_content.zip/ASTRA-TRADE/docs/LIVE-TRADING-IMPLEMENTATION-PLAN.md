# ASTRA TRADE V1 — Olymptrade Integration & Live Execution Plan

**Tanggal pembaruan:** 30 Oktober 2026  
**Target broker:** Olymptrade  
**Status:** PARTIAL — research/capability gate and UI completed; account API and live order interface UNVERIFIED.

## Status kode saat ini

- Proyek tetap web/PWA JavaScript vanilla dengan backend Node.js untuk autentikasi ASTRA dan starter Android.
- `js/integrations/market-data-provider.js` mengambil data publik Binance Spot untuk pasangan crypto yang ditentukan. Ini bukan data OTC atau harga eksekusi Olymptrade.
- `js/integrations/forex-reference-provider.js` mengambil kurs referensi harian ECB/Frankfurter. Ini bukan bid/ask Forex broker real-time.
- `js/integrations/olymptrade-adapter.js` kini merupakan capability gate, bukan konektor akun. Public developer API, private account read, position/history, dan feed resmi tetap UNVERIFIED; connect/getAccount/order/close menolak secara eksplisit.
- `js/integrations/integration-manager.js` menampilkan Olymptrade sebagai UNVERIFIED dan eksekusi sebagai NOT AVAILABLE.
- Account Connection dialog menyatakan keterbatasan dan menautkan situs, Help Center, serta perjanjian layanan resmi.
- `js/risk/risk-rules.js` masih menolak order; tidak ada order live yang dikirim.
- Bot Lab masih memakai crypto spot Binance untuk simulasi, tetapi ledger virtualnya sekarang disimpan lokal dan dipulihkan dalam keadaan STOPPED.

## Hasil verifikasi broker

Dokumentasi publik resmi yang diperiksa tidak menghasilkan kontrak developer API pihak ketiga yang cukup untuk memverifikasi autentikasi, account data, quotes, order request, order state, atau reconciliation. Ini bukan bukti mutlak bahwa program API partner/private tidak ada. Pertahankan status UNVERIFIED sampai Olymptrade memberikan dokumentasi resmi atau konfirmasi tertulis.

Sumber resmi:

- [Help Center — Robot trading](https://plus.olymptrade.com/id/help/category/trading/can-i-use-robots-when-trading-on-the-platform): robot diperbolehkan dengan batasan terkait kerusakan platform dan prinsip kejujuran eksekusi.
- [Service Agreement Part 2](https://olymptrade.com/id-id/pages/about/legal/service-agreement-part-two/): klausul 8.3(b) membahas penyalahgunaan algoritme transaksi robotik/otomatis yang memfasilitasi pelanggaran integritas, kejujuran, dan keadilan. Klausul 2.2 mendefinisikan transaksi sebagai derivatif berdasarkan perbedaan harga aset dasar. Klausul 4.4.1 melarang klien memberikan password Terminal Trading kepada pihak ketiga.

Kesimpulan: pernyataan bahwa robot diperbolehkan secara bersyarat bukan bukti adanya API publik, dan bukan persetujuan untuk memakai endpoint privat yang tidak terdokumentasi. Minta konfirmasi tertulis dari broker mengenai akses pihak ketiga dan automated trading untuk wilayah/jenis akun pengguna.

## Tahap lanjutan

### Gate 0 — dokumentasi dan otorisasi resmi

Minta Olymptrade mengonfirmasi apakah tersedia API resmi/partner untuk akun individu, scope baca akun, quote feed, pembukaan/penutupan posisi, dukungan demo, autentikasi, rate limit, dan ketentuan otomatisasi. Jangan implementasikan koneksi sampai bukti ini tersedia.

### Tahap 1 — account service

Jika dan hanya jika interface resmi diberikan: buat backend broker gateway, penyimpanan secret yang terenkripsi dengan key terpisah, session authorization, audit log yang disanitasi, rate limit, dan endpoint status/sinkronisasi. Jangan meminta password, OTP, cookie, atau session token Trading Terminal.

### Tahap 2 — instrument & market data

Verifikasi daftar instrumen, jenis kontrak, jam pasar, quote source, timestamp, bid/ask, minimum jumlah, payout/fee/commission, expiry/duration, leverage/margin bila relevan, serta perubahan spesifikasi. Jangan gunakan Binance/ECB sebagai quote Olymptrade.

### Tahap 3 — strategy, risk, paper & dry run

Pisahkan provider data dari strategi. Tetap beri label RULE-BASED jika tak ada model AI nyata. Paper Trading harus memakai feed dan mekanisme fill yang relevan; saat ini Bot Lab hanya simulasi crypto spot Binance dan tidak mewakili Olymptrade. Dry Run di main terminal masih perlu diimplementasikan dan dites agar tidak memanggil broker.

### Tahap 4 — demo lifecycle

Jika broker menyediakan interface demo resmi: uji preflight, order intent, submit, ack/reject, partial/fill, close, cancellation jika didukung, timeout, duplicate prevention, reconnect, dan reconciliation setelah restart. Jangan gunakan dana sungguhan untuk tes otomatis.

### Tahap 5 — live release

Aktifkan hanya setelah API resmi dan izin, dukungan akun/wilayah, legal review, security review, risk limits, demo test, monitoring, idempotency, dan emergency stop diverifikasi. Live activation harus memerlukan konfirmasi eksplisit pengguna. Jangan auto-switch dari demo ke live.

## Kriteria penerimaan

- Tidak ada CONNECTED tanpa respons autentikasi broker yang benar.
- Tidak ada saldo/posisi/P&L nyata tanpa respons dan timestamp aktual.
- Tidak ada order yang diklaim submitted/filled tanpa response dan reconciliation.
- Timeout tidak memicu submit ulang sebelum status transaksi awal dipastikan.
- Tidak ada secret broker di frontend, localStorage, log, ZIP, atau repository.
- Emergency Stop memblokir transaksi baru dan menampilkan hasil pembatalan yang benar-benar terkonfirmasi.
- Quote memiliki provider, instrument, market type, timestamp, dan freshness yang jelas.
- Paper/Dry Run tidak memanggil endpoint order.
- Tes otomatis dan dokumentasi status diperbarui untuk setiap tahap.

**Dokumen detail riset dan sumber:** `docs/OLYMPTRADE-INTEGRATION-RESEARCH.md`.  
**Checkpoint dan prompt Claude Free:** `docs/CONTINUATION-STATUS.md` dan `docs/NEXT-SESSION-PROMPT.md`.

## Pembaruan 2026-10-31
Selesai tanpa broker: Jenis Transaksi, Risk Engine, Dry Run, Paper Ledger, Live Gate (tertutup), scheduler backend scan-only/dry-run. `LiveGate.submitLive()` menolak tanpa menyentuh adapter dan diuji dengan spy. Gate 0 (dokumentasi/otorisasi resmi) tetap blocker; Tahap 1–5 belum dimulai. Lihat `docs/OLYMPTRADE-INTEGRATION-RESEARCH.md`.
