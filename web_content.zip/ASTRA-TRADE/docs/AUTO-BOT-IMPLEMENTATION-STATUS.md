# ASTRA TRADE V1 — Auto Bot Implementation Status

## Delivered in this build
- Added `bot-lab.html`, a standalone responsive Android-friendly paper-trading screen.
- Added `js/paper-bot.js`: fetches public 1-minute candles for supported Crypto spot symbols; uses EMA(9)/EMA(21), RSI(14), and 5-candle momentum as a sample rule set.
- Simulated LONG entry/exit only; target risk 1% by default (adjustable 0.25–1%), simulated 1.5% stop, 3% target, max 95% simulated equity notional, and a 3% simulated daily loss guard.
- Explicit stop button and visible public-feed/error status.
- No API keys, no private-account calls, no live order endpoint, and no claim of guaranteed profit.

## Known limitations
- The paper ledger and equity are in-memory only and reset on reload.
- Browser timer/WebSocket operation is not guaranteed in the Android background. This is not a 24/7 production bot.
- It uses Crypto spot candles only. It does not provide Forex, Gold, derivatives, or OTC quotes.
- The sample strategy is not validated for profitability. Slippage, fees, spread, partial fills, latency, and exchange outages are not modelled.
- This is a web/PWA project, not a native Android APK.

## Live-trading gates (not yet passed)
1. Select an officially supported broker/exchange for the user's account and jurisdiction.
2. Implement backend-held secrets and official authenticated account/order adapters.
3. Verify product availability, account permissions, lot/tick/min-notional filters, rate limits and regional rules.
4. Run sandbox/demo end-to-end tests, including duplicate-submit/idempotency, rejected orders, partial fills, reconnect, stale quotes, position reconciliation, stop handling, and emergency stop.
5. Complete security review and strategy backtesting/paper-forward testing.
6. Keep live execution disabled until an explicit release decision after all gates pass.

## Tests performed for this change
- JavaScript syntax check: `node --check js/paper-bot.js`.
- HTML/JS static assertions: verified the page identifies itself as paper-only and contains no live-order endpoint or API-key fields.
- Archive integrity: `unzip -t` on the produced ZIP.
- No real broker authentication, live order, Android device, or profitability test was performed.

## UI bug-fix pass (2026-10-30)
- Improved mobile schedule/config tab wrapping, spacing, and text overflow so controls remain readable on narrow screens.
- Connect Exchange now opens an explanatory dialog instead of a generic toast. It clearly distinguishes public market data from private account connection and warns not to paste credentials/cookies.
- Olymptrade private account/order integration remains UNVERIFIED until an official, documented public API and the exact permission for the intended third-party integration are confirmed. The UI now discloses this and does not request credentials or submit orders. No private endpoints, browser-session scraping, or live orders were added.
- Tests for this patch: pending static syntax and archive checks in delivery report.


## Olymptrade continuation patch (2026-10-30)
- Added an explicit Olymptrade adapter capability gate. It returns `UNVERIFIED` for public developer API/private-account capabilities and `NOT_AVAILABLE` for connection and live execution until official support is verifiable.
- Added automated tests proving connection/account/order methods reject with explicit reason codes instead of simulating success.
- Replaced old Stockity connection copy with an Olymptrade-specific Account Connection explainer and official links.
- Paper Bot Lab now persists only virtual paper state in local browser storage and restores it stopped (never auto-starts after reload).
- Paper Lab labels its feed as Binance crypto spot and explicitly warns this is not Olymptrade pricing.
- These changes do not create an Olymptrade account connection, broker feed, or live order capability.
