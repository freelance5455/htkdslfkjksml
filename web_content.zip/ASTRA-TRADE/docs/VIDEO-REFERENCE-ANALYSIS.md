# ASTRA TRADE V1 — Analisis video referensi berbasis timestamp

## Sumber dan metode

- Video: `Record_2026-10-29-11-59-28.mp4`.
- Durasi dari metadata media: sekitar **96,53 detik**; resolusi **720 × 1612** (portrait Android).
- Pemeriksaan dilakukan dari awal sampai akhir dengan sampel visual per 1 detik, kemudian tiap rentang diperiksa melalui contact sheet. Timestamp di bawah merupakan perkiraan posisi perubahan layar, bukan penandaan frame-by-frame presisi.
- Bukti video menunjukkan apa yang tampil, bukan membuktikan bahwa harga, saldo, P&L, autentikasi, atau transaksi di layar berasal dari layanan sungguhan.

## Timeline layar dan interaksi yang terlihat

| Timestamp | Halaman / adegan | Tampilan dan kontrol yang terlihat | Perubahan / batas kesimpulan |
|---|---|---|---|
| 00:00–00:03 | Home Android → membuka aplikasi | Ikon aplikasi tampak pada layar beranda; layar kemudian meredup ketika ikon dibuka. | Membuktikan alur peluncuran dari layar Android, bukan detail APK di dalam ZIP. |
| 00:03–00:08 | Splash | Logo putih bergaya monogram pada latar hitam. | Logo bertahan beberapa detik sebelum login. |
| 00:07–00:19 | Welcome Back / login | Judul Welcome Back, keterangan AI trading, kolom email, password tersembunyi, Forgot?, tombol Masuk, tautan New Account. | Terminal muncul sekitar detik 14. Video tidak membuktikan server auth ataupun penyimpanan kredensial. |
| 00:14–00:25 | Terminal → Control | Label Live Trading Terminal, status inactive, `BTCUSD_OTC`, angka harga bergerak, metrik P&L/trade/win-rate, tab Control/Config/Schedule, Start Engine, Halt Bot, parameter Rp15000 / 5m / AI / BTCUSD_OTC, Schedule Summary kosong. | Angka harga berubah antarsampel, tetapi asal data, harga OTC resmi, dan status order tidak dapat dipastikan dari video. |
| 00:26–00:29 | Market Watch | Daftar Bitcoin OTC, Ethereum OTC, Litecoin OTC, Crypto Composite Index, NHI Index; baris menampilkan harga, perubahan persentase, high/low dan sparkline. Daftar dapat digulir hingga Asia/Europe Composite Index. | UI menampilkan harga OTC/index, tetapi video tidak mengidentifikasi sumber data yang dapat diverifikasi. |
| 00:30–00:39 | Trading Ledger / Performance | Total P&L `$0`, wins/losses/total bernilai nol, filter All/Demo/Real, tab Trades dan Win/Loss Ratio, area riwayat kosong / 0 entries. | Tidak cukup bukti bahwa ini ledger transaksi broker nyata atau data yang tersinkron dengan akun. |
| 00:33–00:47 | Profile & Security | Profil nama/email, Logout, Connect Exchange, Connection Node, status Disconnected, Session Expired, kolom signature, sakelar 2FA terlihat aktif, Biometric Login nonaktif, Access Logs. | Tampilan sakelar tidak membuktikan 2FA/biometrik sungguhan aktif. Status koneksi tetap terputus. |
| 00:48–00:52 | Browser eksternal / Olymp Trade | Header `Olymp Trad...`, opsi Logout & Refresh, spinner Menghubungkan, kemudian pesan `Gagal memuat halaman login`, `net::ERR_CONNECTION_REFUSED`, tombol Coba Lagi. | Percobaan memuat halaman gagal dalam video; tidak membuktikan integrasi akun atau session bridge. |
| 00:53–00:59 | Kembali ke Profile & Security | Kembali ke profil; koneksi masih Disconnected, token visual berubah dari Session Expired ke Reconnect Needed; kontrol keamanan terlihat. | Reconnect Needed tetap hanya status UI; tidak ada koneksi yang terkonfirmasi. |
| 01:00–01:02 | Market Watch | Kembali ke daftar instrumen OTC/index, grafik mini dan angka quote. | Sumber quote belum terverifikasi. |
| 01:03–01:05 | Terminal → Control | Kembali ke BTCUSD_OTC, metrik, tombol Start Engine/Halt Bot, parameter perdagangan. | Tidak terlihat bukti order real. |
| 01:06–01:08 | Config (awal) | Trade Amount (min Rp15.000), Duration 5m, Market BTCUSD_OTC, Execution Strategy `AI Prediction Method`, Martingale K1–K5 dengan K1 terpilih; Martingale tampak aktif, Bot Timer awalnya nonaktif, Auto Trade Loop aktif, Trade Interval 5m. | Nilai dan pilihan adalah yang terlihat pada UI, bukan bukti bahwa fungsi trading/AI di belakangnya bekerja. |
| 01:09–01:12 | Config / Bot Timer | Bot Timer diaktifkan; pilihan yang terlihat mencakup 24 jam. | Aktivasi sakelar terlihat, hasil eksekusi timer tidak ditunggu hingga selesai di video. |
| 01:13–01:15 | Config / Timer dropdown | Daftar durasi terlihat: 1m, 3m, 5m, 10m, 15m, 30m; 5m tampil sebagai pilihan terpilih pada beberapa frame. | Konteks dropdown menunjukkan pilihan durasi singkat; tidak membuktikan apakah timer mengukur sesi, eksekusi, atau candle secara internal. |
| 01:16–01:19 | Config / Duration dan Strategy dropdown | Durasi tampak dengan pilihan 15s, 1m, 5m. Strategy menu menampilkan AI Prediction Method, EMA Cross Strategy, RSI Scalper. | Video memperlihatkan nama opsi, bukan validasi algoritma atau model AI. |
| 01:20–01:22 | Config / Market dropdown | Opsi BTCUSD_OTC, ETHUSD_OTC, LTCUSD_OTC, CRYPTO_X, NHI_X, ASIA_X, EUROPE_X. | Tidak ada endpoint/sumber quote resmi yang dibuktikan. |
| 01:23–01:26 | Config / nominal | Nominal diedit menjadi `15000`; keyboard numerik Android tampil, lalu ditutup. | Edit input terlihat; status simpan persisten tidak dapat dipastikan hanya dari rekaman. |
| 01:27–01:30 | Schedule | Label Next Trade In `00:00`, teks no pending trades, area Trade Schedule kosong dengan ajakan Tap Start Engine. | Tidak ada antrean jadwal/posisi yang terlihat pada saat itu. |
| 01:31–01:36 (91–96 dtk) | Kembali ke Terminal → Control | Terminal kembali; quote BTCUSD_OTC dan parameter ringkas tampil. | Terminal tetap terlihat hingga video berakhir pada sekitar 01:36. Sumber quote dan eksekusi order tidak terbukti dari tampilan. |

## Interpretasi yang aman

- **Terlihat dengan yakin:** urutan halaman, teks label, pilihan nominal/durasi/metode/instrumen, tombol utama, dan perubahan navigasi di atas.
- **Belum terverifikasi dari video:** sumber quote OTC/index, apakah P&L berasal dari akun nyata, apakah Start Engine mengeksekusi order, apakah AI model terhubung, keamanan autentikasi, efek permanen tombol 2FA, dan koneksi broker yang berhasil.
- **Batas yang diterapkan dalam proyek:** harga Binance Spot dipisahkan dari instrumen OTC/index; instrumen yang tidak memiliki feed resmi diberi `UNAVAILABLE`; saldo/P&L/riwayat transaksi nyata tidak dibuat; AI terlatih dan order broker tidak diklaim tersedia.
