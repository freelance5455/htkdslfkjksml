plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.astra.trade"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.astra.trade"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0-dev"
    }
}
