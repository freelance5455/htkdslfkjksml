package com.astra.trade

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNotificationPermissionIfNeeded()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 36)
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(0xFF0B1110.toInt())
        }
        val title = TextView(this).apply {
            text = "ASTRA TRADE V1"
            textSize = 26f
            setTextColor(0xFF55F28A.toInt())
        }
        status = TextView(this).apply {
            text = "STATUS: STOPPED\nAkun: fleksibel\nLive execution: belum tersedia — konektor belum diverifikasi"
            textSize = 15f
            setTextColor(0xFFE2E8E5.toInt())
            setPadding(0, 28, 0, 28)
        }
        val start = Button(this).apply {
            text = "START BOT"
            setOnClickListener {
                val intent = Intent(this@MainActivity, TradingEngineService::class.java).setAction(TradingEngineService.ACTION_START)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
                status.text = "STATUS: ENGINE ACTIVE\nKonektor: belum dikonfigurasi\nOrder live: terkunci sampai konektor terverifikasi"
            }
        }
        val stop = Button(this).apply {
            text = "STOP BOT"
            setOnClickListener {
                stopService(Intent(this@MainActivity, TradingEngineService::class.java))
                status.text = "STATUS: STOPPED\nTidak ada order baru yang dikirim oleh scaffold ini."
            }
        }
        val note = TextView(this).apply {
            text = "APK native starter. Belum mengirim transaksi. Setiap platform memerlukan adapter yang dapat membaca quote dan mengeksekusi order dengan benar."
            textSize = 12f
            setTextColor(0xFF9AA8A0.toInt())
            setPadding(0, 24, 0, 0)
        }
        root.addView(title)
        root.addView(status, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        root.addView(start, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        root.addView(stop, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        root.addView(note, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        setContentView(root)
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 71)
        }
    }
}
