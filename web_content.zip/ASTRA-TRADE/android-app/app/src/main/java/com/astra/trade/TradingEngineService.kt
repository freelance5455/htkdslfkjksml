package com.astra.trade

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder

class TradingEngineService : Service() {
    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(NOTIFICATION_ID, buildNotification("Service siap • belum menjalankan analisis atau order"))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_START -> {
                // Intentionally no order loop until a verified platform connector is installed.
                getSystemService(NotificationManager::class.java)
                    .notify(NOTIFICATION_ID, buildNotification("Service siap • tidak ada loop analisis/order; live belum tersedia"))
            }
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "ASTRA Trading Engine", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return builder.setContentTitle("ASTRA TRADE V1").setContentText(text)
            .setSmallIcon(android.R.drawable.ic_media_play).setOngoing(true).build()
    }

    companion object {
        const val ACTION_START = "com.astra.trade.START"
        const val ACTION_STOP = "com.astra.trade.STOP"
        private const val CHANNEL_ID = "astra_trading_engine"
        private const val NOTIFICATION_ID = 701
    }
}
