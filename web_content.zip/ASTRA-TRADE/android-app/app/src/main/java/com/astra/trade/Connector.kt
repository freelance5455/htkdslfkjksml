package com.astra.trade

/**
 * Platform-neutral boundary for a user-selected trading platform.
 * A concrete adapter must be implemented and verified for each supported platform.
 * No adapter is registered by default, so this scaffold cannot place live orders.
 */
interface TradingConnector {
    val platformName: String
    suspend fun connect(): ConnectorResult
    suspend fun latestQuote(instrument: String): QuoteResult
    suspend fun accountSnapshot(): AccountSnapshotResult
    suspend fun submitOrder(order: OrderRequest): OrderResult
    suspend fun orderStatus(clientOrderId: String): OrderResult
    suspend fun disconnect()
}

data class ConnectorResult(val connected: Boolean, val message: String)
data class QuoteResult(val instrument: String, val bid: Double?, val ask: Double?, val timestampMs: Long, val source: String)
data class AccountSnapshotResult(val available: Boolean, val currency: String?, val equity: Double?, val message: String)
data class OrderRequest(val instrument: String, val side: String, val quantity: Double, val clientOrderId: String)
data class OrderResult(val accepted: Boolean, val status: String, val message: String, val clientOrderId: String)
