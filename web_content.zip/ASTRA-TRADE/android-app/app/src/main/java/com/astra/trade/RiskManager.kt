package com.astra.trade

/** Local pre-trade guard. Values must be populated from a verified account snapshot before live use. */
data class RiskConfig(
    val riskPercent: Double = 1.0,
    val maxDailyLossPercent: Double = 3.0,
    val maxOpenPositions: Int = 1,
    val maxQuoteAgeMs: Long = 5_000L
)

data class RiskDecision(val allowed: Boolean, val reason: String)

class RiskManager(private val config: RiskConfig = RiskConfig()) {
    fun validateQuote(quote: QuoteResult, nowMs: Long = System.currentTimeMillis()): RiskDecision {
        if (quote.bid == null || quote.ask == null || quote.bid <= 0.0 || quote.ask <= 0.0) {
            return RiskDecision(false, "Quote tidak valid")
        }
        if (quote.ask < quote.bid) return RiskDecision(false, "Bid/ask tidak konsisten")
        if (nowMs - quote.timestampMs > config.maxQuoteAgeMs || quote.timestampMs > nowMs + 2_000L) {
            return RiskDecision(false, "Quote basi atau timestamp tidak valid")
        }
        return RiskDecision(false, "Eksekusi live terkunci: konektor platform belum diverifikasi")
    }
}
