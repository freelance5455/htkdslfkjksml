# ASTRA TRADE V1 — Advanced Read-Only Analytics

ASTRA TRADE V1 adalah proyek web/PWA pemantauan pasar dengan tema gelap dan aksen hijau neon. Paket ZIP ini **bukan APK Android** dan tidak berisi project native/Gradle untuk membangun APK. Paket ini mempertahankan struktur dan UI proyek sebelumnya, lalu meningkatkan kualitas data spot publik, penandaan status data, Config sesuai video, dan catatan observasi lokal.

> **Batas penting:** build ini hanya untuk pemantauan dan pembelajaran analisis pasar spot. Ini bukan bot trading live, tidak terhubung ke akun broker, tidak mengirim order, dan tidak memiliki model AI terlatih (analisis = RULE-BASED). Harga spot publik bukan harga OTC/indeks dari layanan lain.

## Status fitur

- **Ticker publik:** mencoba mengambil statistik ticker spot publik dan WebSocket dari Binance. Tidak memerlukan API key untuk endpoint market-data-only. Feed dapat gagal tergantung jaringan, browser, atau hosting; nilai tidak dibuat-buat.
- **Candle historis:** ketika koneksi tersedia, aplikasi mengambil hingga 100 candle 1 menit untuk aset yang dipilih dari endpoint publik `/api/v3/klines`. Grafik menyatakan sumber candle dan kuotasi terbaru; jika pengambilan gagal, grafik kembali ke observasi feed dan diberi label yang sesuai.
- **Freshness:** snapshot diberi status kedaluwarsa jika lebih tua dari 45 detik. Harga lama tidak ditandai sebagai feed segar; setiap baris aset dapat menunjukkan `STALE`.
- **Scanner indikator:** EMA 9, EMA 21, RSI 14 (perhitungan smoothing Wilder), momentum 5 sampel, volatilitas return, dan rentang sampel. Hasil berupa uraian deskriptif, bukan sinyal BUY/SELL, rekomendasi investasi, atau prediksi hasil.
- **Riwayat observasi:** ketika scan yang memiliki sampel cukup berjalan, aplikasi dapat menyimpan maksimum 200 observasi lokal. Riwayat itu diberi label `OBSERVATION_ONLY`, terpisah dari transaksi, dapat dilihat di Ledger > Observations, dan dapat diekspor dalam JSON.
- **Config dan schedule:** preferensi tersimpan lokal dan divalidasi. Jadwal menjalankan pemindaian lokal pada waktu/hari yang dipilih selama halaman terbuka; browser bisa menunda timer di latar belakang.
- **Order / bot / K1–K5:** eksekusi order, koneksi akun privat, auto-open/close posisi, dan Martingale tetap dinonaktifkan. Tidak ada API rahasia yang disimpan di browser.
- **P&L dan riwayat transaksi nyata:** belum tersedia karena tidak ada integrasi akun resmi dan tidak ada transaksi yang dihasilkan aplikasi.
- **Login / akun:** diverifikasi oleh `server/server.js` (scrypt, sesi cookie HttpOnly, verifikasi email, reset password). Tanpa server = **NOT CONNECTED** dan login ditolak. Email belum bisa terkirim (tanpa SMTP). Lihat `docs/AUDIT-V1.md`.

## Menjalankan dengan autentikasi (wajib untuk login)

```bash
node server/server.js            # http://127.0.0.1:8080, melayani aplikasi + /api/auth
ASTRA_MAIL=console node server/server.js   # tautan verifikasi/reset dicetak di terminal
node server/server.js verify email@kamu.com # verifikasi akun manual
```

Buka aplikasi lewat alamat server itu (bukan `file://`).

## Cara menjalankan di Android (pratinjau tanpa login)

1. Ekstrak ZIP ke folder `ASTRA-TRADE`.
2. Untuk pratinjau UI, buka `index.html` di Chrome Android atau browser desktop. Beberapa API dan feed dapat tidak bekerja jika halaman dibuka langsung dengan `file://`.
3. Untuk pengujian yang lebih representatif, sajikan **isi folder `ASTRA-TRADE`** dari web server atau hosting HTTPS statis.
4. Buka URL tersebut di Chrome Android. Untuk memasang sebagai PWA, gunakan menu Chrome → **Add to Home screen / Tambahkan ke layar utama** bila opsi tersedia.
5. Feed publik memerlukan koneksi internet; OTC/index tetap `UNAVAILABLE`. Langkah ini tidak menghasilkan APK dan belum menggantikan pengujian perangkat nyata.

## Pengujian

Dari folder `ASTRA-TRADE`, jalankan:

```bash
node tests/run-all.js     # semua test (14 berkas); atau: npm test
```

Tes data pasar memakai respons mock untuk memeriksa normalisasi, candle, freshness, dan kegagalan HTTP. Itu **bukan** bukti koneksi langsung ke layanan publik berhasil pada perangkat pengguna. Lihat `docs/TEST-RESULTS-ADVANCED.md` untuk hasil dan keterbatasan pengujian.

## Dokumentasi

- `docs/ADVANCED-AUDIT.md` — tabel audit kondisi fitur, tindakan, hasil, dan batasan.
- `docs/CHANGELOG-ADVANCED.md` — perubahan terhadap ZIP sebelumnya.
- `docs/TEST-RESULTS-ADVANCED.md` — hasil uji aktual dan bagian yang belum diuji.
- `docs/FEATURES.md` — checklist fitur.
- `docs/INTEGRATION-NOTES.md` — sumber data dan batas integrasi.
- `docs/VIDEO-REFERENCE-ANALYSIS.md` — timeline video referensi dengan timestamp dan catatan kepastian.
- `docs/FINAL-DELIVERY-REPORT.md` — laporan akhir, matriks perbandingan, daftar perubahan, dan hasil pengujian aktual.

## Referensi teknis data pasar

Endpoint ticker/klines dan WebSocket publik merujuk pada dokumentasi Binance Spot API. Endpoint market-data-only ditujukan untuk data pasar publik dan tidak menyediakan user data stream: [Market Data Only](https://github.com/binance/binance-spot-api-docs/blob/master/faqs/market_data_only.md), [REST API](https://github.com/binance/binance-spot-api-docs/blob/master/rest-api.md), [WebSocket Streams](https://github.com/binance/binance-spot-api-docs/blob/master/web-socket-streams.md).

Preferensi UI menggunakan `localStorage` dengan prefix `astra.trade.v1.`. Jangan menganggapnya penyimpanan rahasia. Integrasi akun/order memerlukan desain backend dan verifikasi terpisah, serta tidak termasuk dalam build ini.


## Forex reference rates (added)

Market Watch now includes EURUSD, GBPUSD, USDJPY, USDCHF, USDCAD, AUDUSD, and NZDUSD from the public Frankfurter API (ECB reference rates). These are **daily reference rates**, not streaming FX broker quotes, bid/ask spreads, or prices suitable for live entry/exit. The app labels them `REFERENCE RATE` and shows the source date. A real-time Forex feed still requires a suitable FX data provider and may require an API key. Test with `node tests/forex-reference-test.js`.

## Auto Bot Lab (implementasi simulasi)

Buka `bot-lab.html` melalui hosting HTTPS untuk menjalankan paper-trading lab terpisah. Lab mengambil candle publik 1 menit dari endpoint market-data Binance, menghitung kombinasi EMA 9/21, RSI 14, dan momentum, lalu membuat simulasi posisi LONG dengan risiko target 0,25–1% saldo simulasi, stop-loss simulasi 1,5%, target simulasi 3%, satu posisi terbuka, dan pengaman rugi harian simulasi 3%. Saldo, posisi virtual, dan riwayat disimpan di localStorage browser dan dipulihkan setelah reload dalam keadaan STOPPED (tidak auto-start); reset memerlukan konfirmasi. Ini tidak mengirim order, tidak membaca saldo akun asli, dan tidak boleh dipakai sebagai bukti strategi menguntungkan.

**Batas operasional Android:** simulasi berjalan hanya saat halaman tetap aktif. Android/Chrome dapat menangguhkan timer dan koneksi saat layar terkunci atau tab di latar belakang. Untuk bot sungguhan 24/7, arsitektur produksi harus memakai backend/server yang selalu aktif dengan monitoring, bukan mengandalkan browser Android.

**Live order tetap terkunci.** Jangan menambahkan API secret ke frontend. Integrasi live berikutnya memerlukan backend aman, API resmi yang cocok untuk akun/wilayah, sandbox/demo, pengujian rekonsiliasi order, idempotensi, perlindungan data basi, batas rugi, dan prosedur emergency stop.

## Native Android EA starter (added)

Folder `android-app/` now contains a native Kotlin/Gradle starter for the intended Android-first EA: START/STOP controls, a user-started foreground service, a platform-neutral connector interface, and a quote freshness guard. It is source code only; no APK was built in this environment. Live execution remains unavailable until a concrete platform connector is implemented and verified. See `docs/ANDROID-NATIVE-ROADMAP.md`. The existing PWA/paper-trading lab is retained for project continuity and is not live trading.


## Olymptrade continuation status (2026-10-30)

The selected broker for future integration is **Olymptrade**. A safe `OlympTradeAdapter` capability gate and an Account Connection explainer are now included. The official public resources reviewed do not provide a verifiable third-party developer API specification for private account reads or automated order execution, so these capabilities remain **UNVERIFIED / NOT AVAILABLE**. ASTRA does not ask for an Olymptrade password, OTP, browser cookie, or session token and does not call undocumented/private terminal endpoints.

Olymptrade's official Help Center describes robot use as conditionally permitted, subject to platform integrity and honest execution. Service Agreement Part 2 clause 8.3(b) addresses abusive automated algorithms; this is not a public API specification or blanket permission for every bot. Obtain broker clarification before any live automation. See [`docs/OLYMPTRADE-INTEGRATION-RESEARCH.md`](docs/OLYMPTRADE-INTEGRATION-RESEARCH.md).

The Bot Lab paper ledger is now persisted in browser-local storage and restored in STOPPED state after reload. This persistence is only for simulated crypto-spot data from Binance; it is not an Olymptrade account ledger and does not run in the background.

Additional tests: `node tests/olymptrade-adapter-test.js` and `node tests/paper-bot-persistence-test.js`.


## Jenis Transaksi Olymptrade (Flex / InZone / Forex) — sesi 2026-10-31

Flex, InZone, dan Forex adalah **pilihan jenis transaksi/produk broker** (field `transactionType`), terpisah dari AI Method/strategi, Trading Mode (Manual/Semi-Auto/Auto), dan Scheduler. Pilihan ada di Terminal → Config; tiap jenis menyimpan parameter sendiri (`txConfig.FLEX|INZONE|FOREX`). Jenis aktif tampil di Terminal, sinyal, ledger (Paper/Dry Run/Observations), dan catatan.

- **Flex / Forex:** sinyal BUY/SELL RULE-BASED (EMA9/21 + RSI14 + momentum). **InZone:** evaluasi rentang bawah/atas + perkiraan gerak sampai kedaluwarsa; hasil dinilai pada harga saat kedaluwarsa.
- **Spesifikasi broker semuanya UNVERIFIED** (aset per jenis, jam, min/maks, durasi, payout, multiplier, spread, margin, ukuran kontrak). Tidak ada yang ditanam; nilai hanya masuk lewat `registerVerified()` dengan bukti.
- **Dry Run** (`js/trading/dry-run.js`): validasi preflight, nol panggilan broker/jaringan, catatan terpisah (`dryRunRecords`).
- **Paper Ledger** (`js/ledger/paper-ledger.js`): ledger per jenis × sumber data, berlabel ESTIMATE, idempoten, tahan reload, state rusak dikarantina, selalu STOPPED setelah reload.
- **Risk Engine** (`js/risk/risk-engine.js`, dipakai browser dan backend): emergency stop, nominal, kesegaran data, posisi, harian, cooldown, drawdown, risiko per jenis.
- **Live Gate** (`js/trading/live-gate.js`): selalu tertutup; tidak ada order live.
- **Scheduler backend** (`server/scheduler.js`): scan-only/dry-run, zona waktu IANA, persisten, tanpa catch-up, lock, Emergency Stop server persisten. Hanya aktif selama proses server hidup. Endpoint `/api/scheduler`, `/api/trading/*` (wajib login ASTRA).
- Sumber harga dipisah: `BINANCE_SPOT` (pembanding), `ECB_REFERENCE` (harian), `OLYMPTRADE` (tidak tersedia). Tidak ada yang dipakai sebagai harga Olymptrade.
- Android: source only; tidak ada APK (SDK Android tidak tersedia). Notifikasi service tidak lagi mengklaim "bot aktif".
