# ASTRA TRADE V1 — Advanced Read-Only Analytics

ASTRA TRADE V1 adalah proyek web/PWA pemantauan pasar dengan tema gelap dan aksen hijau neon. Paket ZIP ini **bukan APK Android** dan tidak berisi project native/Gradle untuk membangun APK. Paket ini mempertahankan struktur dan UI proyek sebelumnya, lalu meningkatkan kualitas data spot publik, penandaan status data, Config sesuai video, dan catatan observasi lokal.

> **Batas penting:** build ini hanya untuk pemantauan dan pembelajaran analisis pasar spot. Ini bukan bot trading live, tidak terhubung ke akun broker, tidak mengirim order, dan tidak memiliki model AI terlatih. Harga spot publik bukan harga OTC/indeks dari layanan lain.

## Status fitur

- **Ticker publik:** mencoba mengambil statistik ticker spot publik dan WebSocket dari Binance. Tidak memerlukan API key untuk endpoint market-data-only. Feed dapat gagal tergantung jaringan, browser, atau hosting; nilai tidak dibuat-buat.
- **Candle historis:** ketika koneksi tersedia, aplikasi mengambil hingga 100 candle 1 menit untuk aset yang dipilih dari endpoint publik `/api/v3/klines`. Grafik menyatakan sumber candle dan kuotasi terbaru; jika pengambilan gagal, grafik kembali ke observasi feed dan diberi label yang sesuai.
- **Freshness:** snapshot diberi status kedaluwarsa jika lebih tua dari 45 detik. Harga lama tidak ditandai sebagai feed segar; setiap baris aset dapat menunjukkan `STALE`.
- **Scanner indikator:** EMA 9, EMA 21, RSI 14 (perhitungan smoothing Wilder), momentum 5 sampel, volatilitas return, dan rentang sampel. Hasil berupa uraian deskriptif, bukan sinyal BUY/SELL, rekomendasi investasi, atau prediksi hasil.
- **Riwayat observasi:** ketika scan yang memiliki sampel cukup berjalan, aplikasi dapat menyimpan maksimum 200 observasi lokal. Riwayat itu diberi label `OBSERVATION_ONLY`, terpisah dari transaksi, dapat dilihat di Ledger > Observations, dan dapat diekspor dalam JSON.
- **Config dan schedule:** preferensi tersimpan lokal dan divalidasi. Jadwal menjalankan pemindaian lokal pada waktu/hari yang dipilih selama halaman terbuka; browser bisa menunda timer di latar belakang.
- **Order / bot / K1–K5:** eksekusi order, koneksi akun privat, auto-open/close posisi, dan Martingale tetap dinonaktifkan. Tidak ada API rahasia yang disimpan di browser.
- **P&L dan riwayat transaksi nyata:** belum tersedia karena tidak ada integrasi akun resmi dan tidak ada transaksi yang dihasilkan aplikasi.
- **Login / profil:** lokal untuk tampilan, bukan autentikasi server. Password tidak disimpan atau dikirim ke server.

## Cara menjalankan di Android

1. Ekstrak ZIP ke folder `ASTRA-TRADE`.
2. Untuk pratinjau UI, buka `index.html` di Chrome Android atau browser desktop. Beberapa API dan feed dapat tidak bekerja jika halaman dibuka langsung dengan `file://`.
3. Untuk pengujian yang lebih representatif, sajikan **isi folder `ASTRA-TRADE`** dari web server atau hosting HTTPS statis.
4. Buka URL tersebut di Chrome Android. Untuk memasang sebagai PWA, gunakan menu Chrome → **Add to Home screen / Tambahkan ke layar utama** bila opsi tersedia.
5. Feed publik memerlukan koneksi internet; OTC/index tetap `UNAVAILABLE`. Langkah ini tidak menghasilkan APK dan belum menggantikan pengujian perangkat nyata.

## Pengujian

Dari folder `ASTRA-TRADE`, jalankan:

```bash
node tests/smoke-test.js
node tests/market-data-test.js
```

Tes data pasar memakai respons mock untuk memeriksa normalisasi, candle, freshness, dan kegagalan HTTP. Itu **bukan** bukti koneksi langsung ke layanan publik berhasil pada perangkat pengguna. Lihat `docs/TEST-RESULTS-ADVANCED.md` untuk hasil dan keterbatasan pengujian.

## Dokumentasi

- `docs/ADVANCED-AUDIT.md` — tabel audit kondisi fitur, tindakan, hasil, dan batasan.
- `docs/CHANGELOG-ADVANCED.md` — perubahan terhadap ZIP sebelumnya.
- `docs/TEST-RESULTS-ADVANCED.md` — hasil uji aktual dan bagian yang belum diuji.
- `docs/FEATURES.md` — checklist fitur.
- `docs/INTEGRATION-NOTES.md` — sumber data dan batas integrasi.
- `docs/VIDEO-REFERENCE-ANALYSIS.md` — timeline video referensi dengan timestamp dan catatan kepastian.
- `docs/FINAL-DELIVERY-REPORT.md` — laporan akhir, matriks perbandingan, daftar perubahan, dan hasil pengujian aktual.

## Referensi teknis data pasar

Endpoint ticker/klines dan WebSocket publik merujuk pada dokumentasi Binance Spot API. Endpoint market-data-only ditujukan untuk data pasar publik dan tidak menyediakan user data stream: [Market Data Only](https://github.com/binance/binance-spot-api-docs/blob/master/faqs/market_data_only.md), [REST API](https://github.com/binance/binance-spot-api-docs/blob/master/rest-api.md), [WebSocket Streams](https://github.com/binance/binance-spot-api-docs/blob/master/web-socket-streams.md).

Preferensi UI menggunakan `localStorage` dengan prefix `astra.trade.v1.`. Jangan menganggapnya penyimpanan rahasia. Integrasi akun/order memerlukan desain backend dan verifikasi terpisah, serta tidak termasuk dalam build ini.


## Forex reference rates (added)

Market Watch now includes EURUSD, GBPUSD, USDJPY, USDCHF, USDCAD, AUDUSD, and NZDUSD from the public Frankfurter API (ECB reference rates). These are **daily reference rates**, not streaming FX broker quotes, bid/ask spreads, or prices suitable for live entry/exit. The app labels them `REFERENCE RATE` and shows the source date. A real-time Forex feed still requires a suitable FX data provider and may require an API key. Test with `node tests/forex-reference-test.js`.

## Auto Bot Lab (implementasi simulasi)

Buka `bot-lab.html` melalui hosting HTTPS untuk menjalankan paper-trading lab terpisah. Lab mengambil candle publik 1 menit dari endpoint market-data Binance, menghitung kombinasi EMA 9/21, RSI 14, dan momentum, lalu membuat simulasi posisi LONG dengan risiko target 0,25–1% saldo simulasi, stop-loss simulasi 1,5%, target simulasi 3%, satu posisi terbuka, dan pengaman rugi harian simulasi 3%. Riwayat dan saldo hanya berada di memori halaman; reload akan meresetnya. Ini tidak mengirim order, tidak membaca saldo akun asli, dan tidak boleh dipakai sebagai bukti strategi menguntungkan.

**Batas operasional Android:** simulasi berjalan hanya saat halaman tetap aktif. Android/Chrome dapat menangguhkan timer dan koneksi saat layar terkunci atau tab di latar belakang. Untuk bot sungguhan 24/7, arsitektur produksi harus memakai backend/server yang selalu aktif dengan monitoring, bukan mengandalkan browser Android.

**Live order tetap terkunci.** Jangan menambahkan API secret ke frontend. Integrasi live berikutnya memerlukan backend aman, API resmi yang cocok untuk akun/wilayah, sandbox/demo, pengujian rekonsiliasi order, idempotensi, perlindungan data basi, batas rugi, dan prosedur emergency stop.
