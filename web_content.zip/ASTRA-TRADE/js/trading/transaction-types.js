/* ASTRA TRADE — Jenis Transaksi Olymptrade: FLEX, INZONE, FOREX.
 *
 * Ketiganya adalah PILIHAN PRODUK/JENIS TRANSAKSI BROKER, bukan AI Method, bukan strategi ASTRA,
 * dan bukan mode bot (Manual/Semi-Auto/Auto). Modul ini hanya mendeskripsikan jenis transaksi,
 * memvalidasi parameter masukan per jenis, dan menyimpan konfigurasi terpisah per jenis.
 *
 * Spesifikasi broker (ketersediaan aset, jam transaksi, min/maks nominal, durasi, payout/biaya,
 * multiplier, spread, margin, ukuran kontrak, dst.) BELUM terverifikasi. Semuanya berstatus
 * UNVERIFIED dan tidak ditanam sebagai konstanta. Nilai baru hanya boleh masuk lewat
 * registerVerified() dengan bukti (evidence) tertulis.
 *
 * UMD: berjalan di browser (window.ASTRA.TransactionTypes) dan Node (require).
 */
(function (root, factory) {
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else {
    var A = root.ASTRA = root.ASTRA || {};
    A.TransactionTypes = api;
    if (A.Storage) A.TransactionConfig = api.createStore(A.Storage);
  }
})(typeof window !== 'undefined' ? window : globalThis, function () {
  'use strict';

  var TYPES = ['FLEX', 'INZONE', 'FOREX'];
  var DEFAULT_TYPE = 'FLEX';

  /* Atribut spesifikasi broker yang harus terverifikasi sebelum LIVE (lihat RiskEngine mode LIVE). */
  var LIVE_REQUIRED = {
    FLEX: ['assetAvailability', 'tradingHours', 'minAmount', 'maxAmount', 'durations', 'payoutOrFee'],
    INZONE: ['assetAvailability', 'tradingHours', 'minAmount', 'maxAmount', 'durations', 'rangeWidthRules', 'payoutOrFee'],
    FOREX: ['assetAvailability', 'tradingHours', 'minAmount', 'maxAmount', 'multiplierOptions', 'spread', 'marginLeverage', 'pipValueContractSize', 'stopLossTakeProfitRules']
  };
  var OPTIONAL_SPEC = {
    FLEX: ['earlyClose'],
    INZONE: ['earlyClose'],
    FOREX: []
  };

  var DEFINITIONS = {
    FLEX: {
      id: 'FLEX', label: 'Flex', brokerProduct: true, directionModel: 'BUY_SELL',
      summary: 'Arah BUY atau SELL pada aset dengan nominal dan durasi.',
      helpUrl: 'https://plus.olymptrade.com/id/help/category/flex-guide/opening-a-flex-trade',
      fields: [
        { key: 'market', label: 'Market / Asset', kind: 'market', required: true },
        { key: 'amountIDR', label: 'Nominal (IDR)', kind: 'number', required: true },
        { key: 'durationMinutes', label: 'Durasi (menit)', kind: 'select', options: [0.25, 1, 5], required: true },
        { key: 'assumedPayoutPct', label: 'Asumsi payout % (ESTIMATE, bukan data broker)', kind: 'number', required: false, estimate: true }
      ]
    },
    INZONE: {
      id: 'INZONE', label: 'InZone', brokerProduct: true, directionModel: 'RANGE',
      summary: 'Harga berada di dalam atau di luar rentang saat transaksi kedaluwarsa; bukan sinyal BUY/SELL.',
      helpUrl: 'https://olymptrade.com/id-id/pages/trading/inzone/',
      fields: [
        { key: 'market', label: 'Market / Asset', kind: 'market', required: true },
        { key: 'amountIDR', label: 'Nominal (IDR)', kind: 'number', required: true },
        { key: 'expiryMinutes', label: 'Kedaluwarsa (menit)', kind: 'select', options: [0.25, 1, 5], required: true },
        { key: 'zoneLower', label: 'Batas bawah rentang (harga)', kind: 'number', required: false },
        { key: 'zoneUpper', label: 'Batas atas rentang (harga)', kind: 'number', required: false },
        { key: 'zoneWidthPct', label: 'Lebar rentang % (bila batas tidak diisi)', kind: 'number', required: false },
        { key: 'assumedPayoutPct', label: 'Asumsi payout % (ESTIMATE, bukan data broker)', kind: 'number', required: false, estimate: true }
      ]
    },
    FOREX: {
      id: 'FOREX', label: 'Forex', brokerProduct: true, directionModel: 'BUY_SELL_MANAGED',
      summary: 'Arah BUY/SELL dengan pengelolaan posisi (multiplier, Stop Loss, Take Profit) sesuai instrumen terverifikasi.',
      helpUrl: 'https://plus.olymptrade.com/id/help/category/forex-guide/instructions',
      fields: [
        { key: 'market', label: 'Instrumen Forex', kind: 'market', required: true },
        { key: 'amountIDR', label: 'Nominal / margin (IDR)', kind: 'number', required: true },
        { key: 'multiplier', label: 'Multiplier (asumsi pengguna, ESTIMATE)', kind: 'number', required: false, estimate: true },
        { key: 'stopLossPct', label: 'Stop Loss % dari harga masuk', kind: 'number', required: false },
        { key: 'takeProfitPct', label: 'Take Profit % dari harga masuk', kind: 'number', required: false }
      ]
    }
  };

  var DEFAULTS = {
    FLEX: { market: 'BTCUSDT', amountIDR: 15000, durationMinutes: 5, assumedPayoutPct: null },
    INZONE: { market: 'BTCUSDT', amountIDR: 15000, expiryMinutes: 5, zoneLower: null, zoneUpper: null, zoneWidthPct: 0.2, assumedPayoutPct: null },
    FOREX: { market: 'EURUSD', amountIDR: 15000, multiplier: null, stopLossPct: null, takeProfitPct: null }
  };

  /* Batas sanity masukan ASTRA (bukan spesifikasi broker). */
  var SANITY = { minAmountIDR: 15000, maxAmountIDR: 1000000000, maxMinutes: 1440, maxPct: 100 };

  var verified = {}; // { 'FLEX.minAmount': { value, evidence, at } }

  function clone(v) { return v === undefined ? v : JSON.parse(JSON.stringify(v)); }
  function isType(t) { return TYPES.indexOf(t) >= 0; }
  function norm(t) { return String(t || '').toUpperCase(); }
  function finite(v) { return typeof v === 'number' && isFinite(v); }
  function numOrNull(v) {
    if (v === null || v === undefined || v === '') return null;
    var n = Number(v);
    return isFinite(n) ? n : NaN;
  }

  function assetClass(symbol) {
    var s = String(symbol || '').toUpperCase();
    if (/_OTC$/.test(s)) return 'otc';
    if (/_X$/.test(s)) return 'index';
    if (/^[A-Z0-9]{2,10}USDT$/.test(s)) return 'crypto-spot';
    if (/^[A-Z]{6}$/.test(s)) return 'forex';
    return 'unknown';
  }

  function specKeys(type) { return LIVE_REQUIRED[type].concat(OPTIONAL_SPEC[type]); }

  function spec(type) {
    type = norm(type);
    if (!isType(type)) return null;
    var attrs = {};
    specKeys(type).forEach(function (k) {
      var v = verified[type + '.' + k];
      attrs[k] = v
        ? { status: 'VERIFIED', value: clone(v.value), evidence: v.evidence }
        : { status: 'UNVERIFIED', value: null, evidence: null };
    });
    var missing = LIVE_REQUIRED[type].filter(function (k) { return !verified[type + '.' + k]; });
    return { type: type, status: missing.length ? 'UNVERIFIED' : 'VERIFIED', attributes: attrs, missingForLive: missing };
  }
  function isVerified(type, key) { return !!verified[norm(type) + '.' + key]; }
  function verifiedValue(type, key) { var v = verified[norm(type) + '.' + key]; return v ? clone(v.value) : undefined; }
  function registerVerified(entry) {
    entry = entry || {};
    var type = norm(entry.type);
    if (!isType(type)) throw new Error('Jenis transaksi tidak dikenal.');
    if (specKeys(type).indexOf(entry.key) < 0) throw new Error('Atribut spesifikasi tidak dikenal: ' + entry.key);
    if (!entry.evidence || typeof entry.evidence !== 'string' || entry.evidence.length < 8) throw new Error('Bukti (evidence) resmi wajib diisi.');
    verified[type + '.' + entry.key] = { value: clone(entry.value), evidence: entry.evidence, at: Date.now() };
    return true;
  }
  function _resetVerified() { verified = {}; }

  function defaults(type) { type = norm(type); return isType(type) ? clone(DEFAULTS[type]) : null; }

  /* Mengembalikan { ok, errors, value } — value hanya berisi field milik jenis tsb (tidak tercampur). */
  function normalize(type, input) {
    type = norm(type);
    if (!isType(type)) return { ok: false, errors: ['Jenis transaksi tidak dikenal: ' + type], value: null };
    var src = input && typeof input === 'object' ? input : {};
    var base = DEFAULTS[type], out = {}, errors = [];
    Object.keys(base).forEach(function (k) { out[k] = Object.prototype.hasOwnProperty.call(src, k) ? src[k] : base[k]; });

    var amount = Number(out.amountIDR);
    if (!finite(amount) || amount < SANITY.minAmountIDR || amount > SANITY.maxAmountIDR) errors.push('Nominal harus angka antara Rp15.000 dan Rp1.000.000.000 (batas masukan ASTRA, bukan spesifikasi broker).');
    out.amountIDR = amount;
    out.market = String(out.market || '').toUpperCase();
    var cls = assetClass(out.market);
    if (cls === 'unknown') errors.push('Market tidak dikenal.');
    if (type === 'FOREX' && cls !== 'forex') errors.push('Jenis FOREX memerlukan instrumen Forex (mis. EURUSD); ' + (out.market || 'kosong') + ' bukan instrumen Forex.');

    var payout = numOrNull(out.assumedPayoutPct);
    if (type !== 'FOREX') {
      if (Number.isNaN(payout) || (payout !== null && (payout <= 0 || payout > SANITY.maxPct * 10))) errors.push('Asumsi payout harus angka positif atau kosong.');
      out.assumedPayoutPct = Number.isNaN(payout) ? null : payout;
    }

    if (type === 'FLEX') {
      var d = Number(out.durationMinutes);
      if (!finite(d) || d <= 0 || d > SANITY.maxMinutes) errors.push('Durasi Flex tidak valid.');
      out.durationMinutes = d;
    }
    if (type === 'INZONE') {
      var e = Number(out.expiryMinutes);
      if (!finite(e) || e <= 0 || e > SANITY.maxMinutes) errors.push('Waktu kedaluwarsa InZone tidak valid.');
      out.expiryMinutes = e;
      var lo = numOrNull(out.zoneLower), hi = numOrNull(out.zoneUpper), w = numOrNull(out.zoneWidthPct);
      if (Number.isNaN(lo) || Number.isNaN(hi) || Number.isNaN(w)) errors.push('Batas/lebar rentang InZone harus angka.');
      else {
        if ((lo === null) !== (hi === null)) errors.push('Isi batas bawah DAN batas atas, atau kosongkan keduanya.');
        if (lo !== null && hi !== null && !(lo > 0 && hi > lo)) errors.push('Batas rentang InZone tidak valid: harus 0 < bawah < atas.');
        if (lo === null && (w === null || !(w > 0 && w < SANITY.maxPct))) errors.push('Tanpa batas harga, lebar rentang % harus antara 0 dan 100.');
      }
      out.zoneLower = Number.isNaN(lo) ? null : lo; out.zoneUpper = Number.isNaN(hi) ? null : hi; out.zoneWidthPct = Number.isNaN(w) ? null : w;
    }
    if (type === 'FOREX') {
      ['multiplier', 'stopLossPct', 'takeProfitPct'].forEach(function (k) {
        var n = numOrNull(out[k]);
        if (Number.isNaN(n) || (n !== null && n <= 0)) errors.push(k + ' harus angka positif atau kosong.');
        else if (n !== null && k !== 'multiplier' && n >= SANITY.maxPct) errors.push(k + ' harus di bawah 100%.');
        out[k] = Number.isNaN(n) ? null : n;
      });
    }
    return { ok: errors.length === 0, errors: errors, value: out };
  }
  function validate(type, input) { var r = normalize(type, input); return { ok: r.ok, errors: r.errors }; }

  /* Ketersediaan aset per jenis transaksi: tidak ada aset yang terbukti tersedia di broker. */
  function assetAvailability(type, symbol) {
    type = norm(type);
    var cls = assetClass(symbol);
    if (!isType(type)) return { status: 'UNKNOWN', reason: 'Jenis transaksi tidak dikenal.' };
    if (cls === 'otc' || cls === 'index') return { status: 'NOT_AVAILABLE', assetClass: cls, reason: 'Sumber kuotasi OTC/Index belum tersedia.' };
    if (type === 'FOREX' && cls !== 'forex') return { status: 'MISMATCH', assetClass: cls, reason: 'FOREX memerlukan instrumen Forex.' };
    if (isVerified(type, 'assetAvailability')) {
      var list = verifiedValue(type, 'assetAvailability');
      if (Array.isArray(list)) return { status: list.indexOf(String(symbol).toUpperCase()) >= 0 ? 'VERIFIED_AVAILABLE' : 'VERIFIED_UNAVAILABLE', assetClass: cls };
    }
    return { status: 'UNVERIFIED', assetClass: cls, reason: 'Ketersediaan aset pada jenis transaksi ini di akun broker belum terverifikasi.' };
  }

  function list() { return TYPES.map(function (t) { return clone(DEFINITIONS[t]); }); }
  function describe(type) { type = norm(type); return isType(type) ? clone(DEFINITIONS[type]) : null; }

  /* Penyimpanan konfigurasi: satu kunci per jenis; mengganti jenis tidak menyentuh kunci jenis lain. */
  function createStore(storage) {
    var ACTIVE_KEY = 'txActive';
    function key(type) { return 'txConfig.' + type; }
    return {
      types: TYPES.slice(),
      getActive: function () { var t = norm(storage.get(ACTIVE_KEY, DEFAULT_TYPE)); return isType(t) ? t : DEFAULT_TYPE; },
      setActive: function (type) {
        type = norm(type);
        if (!isType(type)) return { ok: false, reason: 'Jenis transaksi tidak dikenal.' };
        if (!storage.set(ACTIVE_KEY, type)) return { ok: false, reason: 'Penyimpanan tidak tersedia.' };
        return { ok: true, type: type };
      },
      get: function (type) {
        type = norm(type);
        if (!isType(type)) return null;
        var saved = storage.get(key(type), null);
        var n = normalize(type, saved && typeof saved === 'object' ? saved : {});
        return n.ok ? n.value : DEFAULTS[type] ? clone(DEFAULTS[type]) : null;
      },
      save: function (type, patch) {
        type = norm(type);
        if (!isType(type)) return { ok: false, errors: ['Jenis transaksi tidak dikenal.'] };
        var merged = Object.assign({}, this.get(type), patch && typeof patch === 'object' ? patch : {});
        var n = normalize(type, merged);
        if (!n.ok) return { ok: false, errors: n.errors };
        if (!storage.set(key(type), n.value)) return { ok: false, errors: ['Penyimpanan tidak tersedia.'] };
        return { ok: true, value: n.value };
      },
      all: function () { var self = this, o = {}; TYPES.forEach(function (t) { o[t] = self.get(t); }); return o; }
    };
  }

  return {
    TYPES: TYPES.slice(), DEFAULT_TYPE: DEFAULT_TYPE, SANITY: clone(SANITY),
    isType: function (t) { return isType(norm(t)); },
    list: list, describe: describe, defaults: defaults, normalize: normalize, validate: validate,
    assetClass: assetClass, assetAvailability: assetAvailability,
    spec: spec, isVerified: isVerified, verifiedValue: verifiedValue, registerVerified: registerVerified,
    liveRequired: function (t) { t = norm(t); return isType(t) ? LIVE_REQUIRED[t].slice() : []; },
    createStore: createStore, _resetVerified: _resetVerified
  };
});
