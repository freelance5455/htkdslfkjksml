/* ASTRA TRADE — DRY RUN.
 *
 * Jalur validasi order yang terpisah dari Live dan Paper Trading. Dry Run memeriksa konfigurasi,
 * jenis transaksi, aturan risiko, freshness kuotasi, dan kesiapan intent, lalu mencatat hasilnya.
 *
 *  - TIDAK memanggil adapter/endpoint broker (modul ini tidak merujuk A.OlympTradeAdapter / A.Integrations).
 *  - TIDAK mengirim order dan TIDAK mengubah saldo/posisi broker maupun ledger paper.
 *  - Catatan disimpan di key terpisah ('dryRunRecords'), berlabel DRY RUN, tidak bercampur dengan transaksi live.
 */
(function (root) {
  'use strict';
  var A = root.ASTRA = root.ASTRA || {};
  var KEY = 'dryRunRecords', MAX = 200;

  function rows() { var r = A.Storage ? A.Storage.get(KEY, []) : []; return Array.isArray(r) ? r.filter(function (x) { return x && typeof x === 'object'; }) : []; }
  function emergency() { return !!(A.BotController && A.BotController.isEmergency && A.BotController.isEmergency()); }

  function run(signal, opts) {
    opts = opts || {};
    var now = Number(opts.now) || Date.now();
    var sig = signal && typeof signal === 'object' ? signal : {};
    var type = String(sig.transactionType || '').toUpperCase();
    var params = Object.assign({}, sig.params || {}, opts.params || {});
    var checks = [];
    function chk(id, ok, reason) { checks.push({ id: id, ok: !!ok, reason: ok ? 'OK' : reason }); }

    var typeOk = !!(A.TransactionTypes && A.TransactionTypes.isType(type));
    chk('transaction-type', typeOk, 'Jenis transaksi tidak dikenal.');
    var cfgOk = false;
    if (typeOk) {
      var norm = A.TransactionTypes.normalize(type, Object.assign({}, params, { market: sig.symbol }));
      cfgOk = norm.ok; params = norm.value || params;
      chk('config-valid', norm.ok, norm.errors.join(' '));
    }
    chk('signal-actionable', !!(sig.available && (sig.direction || sig.zone)), 'Tidak ada sinyal/rentang yang dapat diuji (status: ' + (sig.status || 'UNKNOWN') + ').');
    chk('provenance-recorded', !!(sig.quote && sig.quote.providerId), 'Provider harga tidak tercatat pada sinyal.');

    var intent = {
      transactionType: type, symbol: sig.symbol, direction: sig.direction || null, amountIDR: params.amountIDR,
      durationMinutes: params.durationMinutes, expiryMinutes: params.expiryMinutes,
      zoneLower: sig.zone ? sig.zone.lower : params.zoneLower, zoneUpper: sig.zone ? sig.zone.upper : params.zoneUpper,
      multiplier: params.multiplier, stopLossPct: params.stopLossPct, takeProfitPct: params.takeProfitPct,
      priceAtSignal: sig.priceAtSignal, quote: sig.quote || {}
    };
    var verdict = null;
    if (A.RiskEngine && typeOk) {
      verdict = A.RiskEngine.evaluate(intent, Object.assign({ mode: 'DRY_RUN', now: now, emergencyStop: emergency() }, opts.ctx || {}), opts.limits);
      verdict.checks.forEach(function (c) { checks.push({ id: 'risk:' + c.id, ok: c.ok, reason: c.reason }); });
    } else chk('risk-engine', false, 'Risk Engine tidak tersedia.');

    // Kesiapan LIVE dilaporkan sebagai informasi terpisah (tanpa menyentuh broker).
    var liveReadiness = A.RiskEngine && typeOk ? A.RiskEngine.evaluate(intent, { mode: 'LIVE', now: now, emergencyStop: emergency() }, opts.limits) : null;

    var failed = checks.filter(function (c) { return !c.ok; });
    var rec = {
      id: 'dry:' + (sig.id || (type + '|' + sig.symbol + '|' + Math.floor(now / 60000))),
      kind: 'DRY_RUN', label: 'DRY RUN', timestamp: now, transactionType: type, symbol: sig.symbol || null,
      direction: intent.direction, zone: sig.zone ? { lower: sig.zone.lower, upper: sig.zone.upper, assessment: sig.zone.assessment } : null,
      amountIDR: Number.isFinite(Number(intent.amountIDR)) ? Number(intent.amountIDR) : null,
      verdict: failed.length === 0 ? 'PASSED_PREFLIGHT' : 'REJECTED',
      checks: checks, blockers: failed.map(function (c) { return { id: c.id, reason: c.reason }; }),
      riskEstimate: verdict ? verdict.estimate : null,
      liveReady: false, liveBlockers: liveReadiness ? liveReadiness.blockers.map(function (b) { return b.id; }) : ['risk-engine'],
      brokerCalls: 0, orderSent: false, balanceChanged: false,
      provider: sig.quote ? sig.quote.provider : null, providerId: sig.quote ? sig.quote.providerId : null,
      freshness: sig.quote ? sig.quote.freshness : null, ruleBased: true,
      note: 'DRY RUN: simulasi validasi. Tidak ada request ke broker dan tidak ada order.'
    };

    var list = rows();
    var dup = list.some(function (r) { return r.id === rec.id; });
    if (dup) return { ok: true, duplicate: true, record: list.filter(function (r) { return r.id === rec.id; })[0] };
    list.unshift(rec);
    if (A.Storage) A.Storage.set(KEY, list.slice(0, MAX));
    if (A.EventBus) A.EventBus.emit('dryrun:recorded', { id: rec.id, verdict: rec.verdict, transactionType: type });
    return { ok: true, record: rec };
  }

  function list(type) {
    var r = rows();
    return type ? r.filter(function (x) { return x.transactionType === String(type).toUpperCase(); }) : r;
  }
  function clear() { return A.Storage ? A.Storage.remove(KEY) : false; }
  function exportJSON() { return JSON.stringify({ exportedAt: new Date().toISOString(), dataType: 'dry-run-records-not-trades', records: rows() }, null, 2); }

  A.DryRun = { run: run, list: list, clear: clear, exportJSON: exportJSON, maxRows: MAX };
})(window);
