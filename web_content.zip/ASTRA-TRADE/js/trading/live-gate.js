/* ASTRA TRADE — Live Gate.
 * Gerbang tunggal sebelum order live. Saat ini SELALU tertutup: akses API/izin resmi Olymptrade,
 * kuotasi broker, dan spesifikasi produk belum terverifikasi. Adapter hanya boleh dipanggil jika
 * SEMUA gerbang lulus; selama tertutup submitLive() menolak tanpa menyentuh adapter.
 * Tidak ada tombol/jalur live palsu: tidak pernah menghasilkan ORDER SUBMITTED / FILLED / LIVE READY.
 */
(function (root) {
  'use strict';
  var A = root.ASTRA = root.ASTRA || {};

  function caps() { return A.OlympTradeAdapter && A.OlympTradeAdapter.capabilities ? A.OlympTradeAdapter.capabilities() : null; }

  /* Mengembalikan { ok, state, blockers[] }. ok hanya true bila setiap gerbang lulus. */
  function check(intent, ctx) {
    intent = intent || {}; ctx = ctx || {};
    var c = caps(), blockers = [];
    function need(id, ok, reason) { if (!ok) blockers.push({ id: id, reason: reason }); }
    need('official-api', !!c && c.publicDeveloperApi === 'VERIFIED', 'API/partner interface resmi Olymptrade belum terverifikasi.');
    need('automation-permission', !!c && c.officialAutomatedOrderExecution === 'VERIFIED', 'Izin automated trading dari broker belum terverifikasi.');
    need('account-auth', !!c && c.credentialConnection === 'VERIFIED', 'Autentikasi akun resmi belum tersedia.');
    need('live-execution', !!c && c.liveExecution === 'VERIFIED', 'Eksekusi live belum tersedia.');
    need('broker-quote', !!(intent.quote && intent.quote.isBrokerQuote === true), 'Kuotasi bukan dari feed broker terverifikasi.');
    var type = String(intent.transactionType || '').toUpperCase();
    need('transaction-type', !!(A.TransactionTypes && A.TransactionTypes.isType(type)), 'Jenis transaksi tidak valid.');
    if (A.RiskEngine && A.TransactionTypes && A.TransactionTypes.isType(type)) {
      var v = A.RiskEngine.evaluate(intent, Object.assign({ mode: 'LIVE' }, ctx));
      v.blockers.forEach(function (b) { blockers.push({ id: 'risk:' + b.id, reason: b.reason }); });
    } else need('risk-engine', false, 'Risk Engine tidak tersedia.');
    need('explicit-user-confirmation', ctx.userConfirmedLive === true, 'Konfirmasi eksplisit pengguna untuk live belum diberikan.');
    if (A.RiskRules && A.RiskRules.canExecuteOrder().ok !== true) blockers.push({ id: 'risk-rules', reason: A.RiskRules.canExecuteOrder().reason });
    return { ok: blockers.length === 0, state: blockers.length === 0 ? 'OPEN' : 'LIVE_BLOCKED', blockers: blockers };
  }

  function submitLive(intent, ctx) {
    var gate = check(intent, ctx);
    if (!gate.ok) {
      var e = new Error('LIVE ditolak: gerbang live tertutup (' + gate.blockers.length + ' blocker). Tidak ada request yang dikirim.');
      e.code = 'LIVE_GATE_CLOSED'; e.blockers = gate.blockers;
      return Promise.reject(e);
    }
    // Jalur ini baru dapat tercapai setelah integrasi resmi diimplementasikan dan diverifikasi.
    var e2 = new Error('Integrasi order resmi belum diimplementasikan.');
    e2.code = 'LIVE_NOT_IMPLEMENTED';
    return Promise.reject(e2);
  }

  A.LiveGate = { check: check, submitLive: submitLive };
})(window);
