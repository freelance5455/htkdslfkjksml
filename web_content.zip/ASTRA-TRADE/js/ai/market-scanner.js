(function (root) {
  'use strict';
  var A = root.ASTRA = root.ASTRA || {};
  function pct(value) { return value === null || !Number.isFinite(value) ? 'belum tersedia' : (value >= 0 ? '+' : '') + value.toFixed(3) + '%'; }
  function observeMomentum(history, indicators) {
    var delta = indicators.momentum5;
    if (delta === null || !Number.isFinite(delta)) return 'Data momentum belum tersedia';
    return Math.abs(delta) < 0.02 ? 'Momentum observasi relatif datar (' + pct(delta) + ')' : delta > 0 ? 'Momentum observasi naik (' + pct(delta) + ')' : 'Momentum observasi turun (' + pct(delta) + ')';
  }
  function observeVolatility(history, indicators) {
    var range = indicators.rangePct;
    if (range === null || !Number.isFinite(range)) return 'Rentang observasi belum tersedia';
    var band = range < 0.25 ? 'rentang sampel relatif sempit' : range < 0.75 ? 'rentang sampel sedang' : 'rentang sampel lebar';
    var volatility = indicators.volatilityPct;
    return 'Rentang sampel ' + pct(range) + ' · ' + band + ' · volatilitas return ' + pct(volatility);
  }
  A.MarketScanner = {
    scan: function (symbol) {
      symbol = String(symbol || 'BTCUSDT').toUpperCase();
      var history = A.MarketData.history(symbol);
      var indicators = A.Indicators.analyze(history);
      var ready = history.length >= 22;
      var strategy = A.StrategyManager ? A.StrategyManager.get(A.Storage.get('strategy', 'technical-trend')) : { id: 'technical-trend', name: 'Technical Trend' };
      var observation = 'Data belum cukup';
      if (ready) {
        if (strategy.id === 'momentum-observation') observation = observeMomentum(history, indicators);
        else if (strategy.id === 'volatility-observation') observation = observeVolatility(history, indicators);
        else if (indicators.ema9 !== null && indicators.ema21 !== null) {
          var diffPct = indicators.ema21 ? (indicators.ema9 / indicators.ema21 - 1) * 100 : 0;
          observation = indicators.ema9 > indicators.ema21 ? 'EMA 9 di atas EMA 21 (' + pct(diffPct) + ')' : indicators.ema9 < indicators.ema21 ? 'EMA 9 di bawah EMA 21 (' + pct(diffPct) + ')' : 'EMA 9 dan EMA 21 berdekatan';
        }
      }
      var quote = A.MarketData.get ? A.MarketData.get(symbol) : null;
      var hasHistorical = A.MarketData.getCandles && A.MarketData.getCandles(symbol, '1m').length > 0;
      var dataStatus = quote && quote.stale ? 'STALE' : quote ? 'FRESH_PUBLIC_SPOT' : hasHistorical ? 'HISTORICAL_PUBLIC_SPOT' : 'UNAVAILABLE';
      return {
        symbol: symbol, ready: ready, sampleCount: history.length, indicators: indicators,
        observation: observation, strategy: strategy, dataStatus: dataStatus,
        marketType: 'spot', dataSource: 'Binance public spot data', aiModelConnected: false,
        orderSignal: null, actionableSignalAvailable: false,
        disclaimer: 'Observasi teknikal edukatif dari data spot publik. Bukan model AI terlatih, bukan sinyal transaksi, bukan rekomendasi investasi, dan bukan prediksi hasil.'
      };
    }
  };
})(window);
