/* ASTRA TRADE — Entry Signal RULE-BASED (bukan model AI).
 *
 * Output selalu menyebut: jenis transaksi, aset, alasan indikator, timestamp, provider harga,
 * freshness, dan status validasi. Sinyal TIDAK PERNAH executable selama kuotasi bukan dari feed
 * broker terverifikasi dan gerbang live tertutup.
 *
 *  FLEX / FOREX : arah BUY/SELL dari EMA9/EMA21 + RSI14 + momentum (searah semua syarat).
 *  INZONE       : bukan BUY/SELL. Mengevaluasi rentang (bawah/atas) terhadap harga saat ini dan
 *                 perkiraan gerak sampai kedaluwarsa dari volatilitas candle 1 menit.
 *                 Penilaian hasil memakai harga saat kedaluwarsa (lihat settleInZone).
 */
(function (root) {
  'use strict';
  var A = root.ASTRA = root.ASTRA || {};

  function T() { return A.TransactionTypes; }
  function activeType() { return A.TransactionConfig ? A.TransactionConfig.getActive() : (T() ? T().DEFAULT_TYPE : 'FLEX'); }
  function cfgFor(type) { return A.TransactionConfig ? A.TransactionConfig.get(type) : (T() ? T().defaults(type) : {}); }
  function r(v, d) { return Number.isFinite(v) ? Number(v.toFixed(d === undefined ? 4 : d)) : null; }

  function closes1m(symbol) {
    var c = A.MarketData && A.MarketData.getCandles ? A.MarketData.getCandles(symbol, '1m') : [];
    return c.map(function (x) { return Number(x.close); }).filter(function (x) { return Number.isFinite(x) && x > 0; });
  }
  function stdevReturnsPct(values) {
    if (values.length < 3) return null;
    var rets = [];
    for (var i = 1; i < values.length; i++) rets.push((values[i] / values[i - 1] - 1) * 100);
    var mean = rets.reduce(function (s, v) { return s + v; }, 0) / rets.length;
    var varr = rets.reduce(function (s, v) { return s + (v - mean) * (v - mean); }, 0) / (rets.length - 1);
    return Math.sqrt(varr);
  }

  /* Hasil InZone pada saat kedaluwarsa. Tepat di batas = BOUNDARY_UNVERIFIED (aturan batas belum terverifikasi). */
  function settleInZone(lower, upper, expiryPrice) {
    lower = Number(lower); upper = Number(upper); expiryPrice = Number(expiryPrice);
    if (!(lower > 0 && upper > lower) || !Number.isFinite(expiryPrice) || expiryPrice <= 0) return { outcome: 'INVALID', reason: 'Rentang atau harga kedaluwarsa tidak valid.' };
    if (expiryPrice === lower || expiryPrice === upper) return { outcome: 'BOUNDARY_UNVERIFIED', reason: 'Harga tepat di batas rentang; aturan penilaian batas belum terverifikasi.' };
    return { outcome: expiryPrice > lower && expiryPrice < upper ? 'IN_ZONE' : 'OUT_OF_ZONE' };
  }

  function evaluateInZone(price, lower, upper, expiryMinutes, closes) {
    var inside = price > lower && price < upper;
    var distLowerPct = (price - lower) / price * 100, distUpperPct = (upper - price) / price * 100;
    var sigma = stdevReturnsPct(closes);
    var out = { lower: lower, upper: upper, widthPct: r((upper - lower) / price * 100), expiryMinutes: expiryMinutes,
      insideNow: inside, distanceToLowerPct: r(distLowerPct), distanceToUpperPct: r(distUpperPct), sigmaPerMinutePct: r(sigma, 5) };
    if (sigma === null || sigma <= 0) { out.assessment = 'UNASSESSED'; out.note = 'Candle 1 menit belum cukup untuk memperkirakan gerak sampai kedaluwarsa.'; return out; }
    var expectedMovePct = sigma * Math.sqrt(expiryMinutes);
    var nearest = Math.min(distLowerPct, distUpperPct);
    out.expectedMovePct = r(expectedMovePct);
    out.nearestBoundaryZ = r(nearest / expectedMovePct, 2);
    if (!inside) out.assessment = 'OUTSIDE_NOW';
    else out.assessment = nearest / expectedMovePct >= 1 ? 'LIKELY_STAY_INSIDE' : nearest / expectedMovePct >= 0.5 ? 'UNCERTAIN' : 'LIKELY_EXIT';
    out.note = 'Heuristik berbasis volatilitas historis 1 menit (RULE-BASED); bukan probabilitas hasil.';
    return out;
  }

  function directional(scan, strategyId) {
    var i = scan.indicators, reasons = [];
    var e9 = i.ema9, e21 = i.ema21, rsi = i.rsi14, mom = i.momentum5;
    if (![e9, e21, rsi, mom].every(Number.isFinite)) return { direction: null, reasons: ['Indikator belum lengkap.'], noSignal: 'INDICATORS_INCOMPLETE' };
    if (strategyId === 'volatility-observation') return { direction: null, reasons: ['Metode volatilitas tidak menghasilkan arah BUY/SELL.'], noSignal: 'METHOD_NO_DIRECTION' };
    var up = e9 > e21 && mom > 0, down = e9 < e21 && mom < 0;
    if (strategyId === 'momentum-observation') { up = mom >= 0.02 && e9 >= e21; down = mom <= -0.02 && e9 <= e21; }
    if (up && rsi >= 50 && rsi <= 70) {
      reasons.push('EMA9 ' + r(e9) + ' > EMA21 ' + r(e21), 'RSI14 ' + r(rsi, 1) + ' pada zona 50–70', 'Momentum 5 sampel ' + r(mom, 3) + '% positif');
      return { direction: 'BUY', reasons: reasons };
    }
    if (down && rsi <= 50 && rsi >= 30) {
      reasons.push('EMA9 ' + r(e9) + ' < EMA21 ' + r(e21), 'RSI14 ' + r(rsi, 1) + ' pada zona 30–50', 'Momentum 5 sampel ' + r(mom, 3) + '% negatif');
      return { direction: 'SELL', reasons: reasons };
    }
    if (up && rsi > 70) return { direction: null, reasons: ['Arah naik tetapi RSI14 ' + r(rsi, 1) + ' > 70 (jenuh beli); tidak ada sinyal BUY.'], noSignal: 'RSI_OVERBOUGHT' };
    if (down && rsi < 30) return { direction: null, reasons: ['Arah turun tetapi RSI14 ' + r(rsi, 1) + ' < 30 (jenuh jual); tidak ada sinyal SELL.'], noSignal: 'RSI_OVERSOLD' };
    return { direction: null, reasons: ['Indikator belum searah (EMA/RSI/momentum).'], noSignal: 'NOT_ALIGNED' };
  }

  function base(symbol, type, scan, quote, now) {
    var strategy = scan && scan.strategy ? scan.strategy : { id: 'technical-trend', name: 'Technical Trend' };
    return {
      id: null, symbol: symbol, transactionType: type, ruleBased: true, aiModel: false, label: 'RULE-BASED · NO AI MODEL',
      method: strategy.name, methodId: strategy.id, available: false, direction: null, zone: null, status: 'NO_DATA',
      reasons: [], indicators: scan && scan.indicators ? {
        ema9: r(scan.indicators.ema9), ema21: r(scan.indicators.ema21), rsi14: r(scan.indicators.rsi14, 2),
        momentum5: r(scan.indicators.momentum5, 4), volatilityPct: r(scan.indicators.volatilityPct, 4) } : null,
      timestamp: now, priceAtSignal: quote && Number.isFinite(quote.price) ? quote.price : null,
      quote: { providerId: quote.providerId, provider: quote.provider, marketType: quote.marketType, isBrokerQuote: false,
        timestamp: quote.timestamp, ageMs: quote.ageMs, freshness: quote.freshness, status: quote.status },
      validation: { status: 'BLOCKED', executable: false, blockers: [] },
      disclaimer: 'Analisis teknikal RULE-BASED dari data pembanding. Bukan model AI terlatih, bukan prediksi hasil, dan bukan instruksi live.'
    };
  }
  function finish(sig, type, now) {
    var bl = sig.validation.blockers;
    if (sig.quote.isBrokerQuote !== true) bl.push('NO_BROKER_QUOTE: harga bukan dari feed Olymptrade (' + sig.quote.providerId + ').');
    bl.push('LIVE_GATE_CLOSED: akses API/izin broker belum terverifikasi.');
    if (T()) {
      var av = T().assetAvailability(type, sig.symbol);
      sig.assetAvailability = av.status;
      if (av.status !== 'VERIFIED_AVAILABLE') bl.push('ASSET_' + av.status + (av.reason ? ': ' + av.reason : ''));
    }
    sig.validation.status = sig.available ? 'COMPARISON_ONLY' : 'BLOCKED';
    sig.validation.executable = false;
    var minute = Math.floor(now / 60000);
    sig.id = [type, sig.symbol, sig.direction || (sig.zone ? 'ZONE' : 'NONE'), minute].join('|');
    return sig;
  }

  /* opts: { transactionType, params (override konfigurasi jenis), now } */
  function evaluate(symbol, opts) {
    opts = opts || {};
    var now = Number(opts.now) || Date.now();
    var type = String(opts.transactionType || activeType()).toUpperCase();
    symbol = String(symbol || (cfgFor(type) || {}).market || 'BTCUSDT').toUpperCase();
    var quote = A.QuoteSources ? A.QuoteSources.describe(symbol, now) : { providerId: 'NONE', provider: 'Tidak ada sumber', marketType: 'unavailable', freshness: 'UNAVAILABLE', status: 'UNAVAILABLE', price: null };
    var scan = A.MarketScanner ? A.MarketScanner.scan(symbol) : null;
    var sig = base(symbol, type, scan, quote, now);

    if (!T() || !T().isType(type)) { sig.status = 'INVALID_TYPE'; sig.reasons.push('Jenis transaksi tidak dikenal: ' + type + '.'); return finish(sig, type, now); }
    var cfg = Object.assign({}, cfgFor(type), opts.params || {});
    var norm = T().normalize(type, Object.assign({}, cfg, { market: symbol }));
    if (!norm.ok) { sig.status = 'INVALID_PARAMS'; sig.reasons = norm.errors.slice(); return finish(sig, type, now); }
    cfg = norm.value;
    sig.params = cfg;

    var cls = T().assetClass(symbol);
    if (type === 'FOREX' && cls !== 'forex') { sig.status = 'ASSET_MISMATCH'; sig.reasons.push('FOREX hanya untuk instrumen Forex.'); return finish(sig, type, now); }
    if (cls === 'otc' || cls === 'index') { sig.status = 'NO_DATA'; sig.reasons.push('Sumber kuotasi OTC/Index belum tersedia.'); return finish(sig, type, now); }
    if (quote.freshness === 'UNAVAILABLE') { sig.status = 'NO_DATA'; sig.reasons.push('Kuotasi ' + quote.provider + ' belum tersedia.'); return finish(sig, type, now); }
    if (quote.freshness === 'STALE') { sig.status = 'STALE'; sig.reasons.push('Kuotasi kedaluwarsa; tidak ada sinyal dari data lama.'); return finish(sig, type, now); }
    if (!scan || !scan.ready) { sig.status = 'NO_DATA'; sig.reasons.push('Sampel harga belum cukup (butuh ≥ 22).'); return finish(sig, type, now); }
    if (quote.freshness === 'DAILY_REFERENCE') {
      sig.reasons.push('Sumber hanya kurs referensi harian; bukan seri intraday.');
    }

    if (type === 'INZONE') {
      var price = quote.price;
      var lo = cfg.zoneLower, hi = cfg.zoneUpper;
      if (lo === null || hi === null) { var half = price * (cfg.zoneWidthPct / 100) / 2; lo = price - half; hi = price + half; sig.reasons.push('Rentang dibentuk otomatis ±' + r(cfg.zoneWidthPct / 2, 3) + '% dari harga saat ini.'); }
      sig.zone = evaluateInZone(price, lo, hi, cfg.expiryMinutes, closes1m(symbol));
      sig.available = sig.zone.assessment !== 'UNASSESSED';
      sig.status = sig.available ? 'ZONE_EVALUATED' : 'NO_DATA';
      sig.reasons.push('Posisi harga ' + (sig.zone.insideNow ? 'di dalam' : 'di luar') + ' rentang; jarak ke batas bawah ' + sig.zone.distanceToLowerPct + '%, atas ' + sig.zone.distanceToUpperPct + '%.');
      if (sig.zone.expectedMovePct !== undefined) sig.reasons.push('Perkiraan gerak sampai kedaluwarsa ±' + sig.zone.expectedMovePct + '% → penilaian ' + sig.zone.assessment + '.');
      return finish(sig, type, now);
    }

    var d = directional(scan, scan.strategy && scan.strategy.id);
    sig.reasons = sig.reasons.concat(d.reasons);
    if (d.direction) { sig.direction = d.direction; sig.available = true; sig.status = 'SIGNAL'; }
    else { sig.status = 'NO_SIGNAL'; sig.noSignalReason = d.noSignal; }
    return finish(sig, type, now);
  }

  A.EntrySignal = { evaluate: evaluate, settleInZone: settleInZone, evaluateInZone: evaluateInZone };
})(window);
