/* ASTRA TRADE V1 — js/core/logger.js
 * Pencatat aktivitas dan error.
 * - Level: debug < info < warn < error
 * - Data sensitif (apiKey, secret, password, token, dst.) otomatis disamarkan
 * - Menyimpan maksimal N entri terakhir di memori
 * Muat SETELAH event-bus.js. */
(function (root) {
  'use strict';

  var ASTRA = (root.ASTRA = root.ASTRA || {});
  if (ASTRA.Logger) return;

  var LEVELS = { debug: 10, info: 20, warn: 30, error: 40 };
  // Dicocokkan sebagai potongan nama kunci (huruf kecil, tanpa simbol).
  var SENSITIVE = ['apikey', 'secret', 'password', 'passwd', 'token',
                   'signature', 'authorization', 'cookie', 'privatekey'];
  var MAX_DEPTH = 5;

  var cfg = { level: 'info', maxEntries: 2000, consoleOutput: true };
  var entries = [];
  var seq = 0;

  function isSensitiveKey(key) {
    var k = String(key).toLowerCase().replace(/[^a-z0-9]/g, '');
    return SENSITIVE.some(function (s) { return k.indexOf(s) !== -1; });
  }

  // Salinan aman dari data, dengan kunci sensitif disamarkan.
  function redact(value, depth) {
    if (value === null || value === undefined) return value;
    if (value instanceof Error) return { name: value.name, message: value.message };
    if (value instanceof Date) return value.toISOString();
    var t = typeof value;
    if (t === 'function') return '[function]';
    if (t !== 'object') return value;
    if (depth >= MAX_DEPTH) return '[terlalu dalam]';
    if (Array.isArray(value)) {
      return value.map(function (v) { return redact(v, depth + 1); });
    }
    var out = {};
    Object.keys(value).forEach(function (k) {
      out[k] = isSensitiveKey(k) ? '[DISAMARKAN]' : redact(value[k], depth + 1);
    });
    return out;
  }

  function trim() {
    if (entries.length > cfg.maxEntries) {
      entries.splice(0, entries.length - cfg.maxEntries);
    }
  }

  function log(level, category, message, data) {
    if (!LEVELS[level]) return null;
    if (LEVELS[level] < LEVELS[cfg.level]) return null;

    var entry = {
      id: ++seq,
      ts: Date.now(),
      time: new Date().toISOString(),
      level: level,
      category: String(category || 'app'),
      message: String(message),
      data: data === undefined ? null : redact(data, 0)
    };

    entries.push(entry);
    trim();

    if (cfg.consoleOutput && typeof console !== 'undefined') {
      var fn = (level === 'debug' ? console.log : console[level]) || console.log;
      fn.call(console, '[' + level.toUpperCase() + '][' + entry.category + '] ' + entry.message,
              entry.data !== null ? entry.data : '');
    }

    if (ASTRA.EventBus) ASTRA.EventBus.emit('log:entry', entry);
    return entry;
  }

  function configure(opts) {
    opts = opts || {};
    if (opts.level !== undefined) {
      if (!LEVELS[opts.level]) throw new TypeError('Logger.configure: level tidak dikenal: ' + opts.level);
      cfg.level = opts.level;
    }
    if (opts.maxEntries !== undefined) {
      if (typeof opts.maxEntries !== 'number' || opts.maxEntries < 1 || opts.maxEntries % 1 !== 0) {
        throw new TypeError('Logger.configure: maxEntries harus bilangan bulat >= 1');
      }
      cfg.maxEntries = opts.maxEntries;
      trim();
    }
    if (opts.consoleOutput !== undefined) cfg.consoleOutput = !!opts.consoleOutput;
    return { level: cfg.level, maxEntries: cfg.maxEntries, consoleOutput: cfg.consoleOutput };
  }

  // filter opsional: { level: 'warn' (minimal), category: 'bot', since: timestampMs, limit: 50 }
  function getEntries(filter) {
    filter = filter || {};
    var out = entries.filter(function (e) {
      if (filter.level && LEVELS[e.level] < LEVELS[filter.level]) return false;
      if (filter.category && e.category !== filter.category) return false;
      if (filter.since && e.ts < filter.since) return false;
      return true;
    });
    if (filter.limit) out = out.slice(-filter.limit);
    return out;
  }

  function clear() { entries = []; }
  function exportJSON() { return JSON.stringify(entries); }

  ASTRA.Logger = {
    debug: function (c, m, d) { return log('debug', c, m, d); },
    info:  function (c, m, d) { return log('info',  c, m, d); },
    warn:  function (c, m, d) { return log('warn',  c, m, d); },
    error: function (c, m, d) { return log('error', c, m, d); },
    configure: configure,
    getEntries: getEntries,
    clear: clear,
    exportJSON: exportJSON
  };
})(typeof window !== 'undefined' ? window : globalThis);