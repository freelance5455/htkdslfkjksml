/* ASTRA TRADE — panel koneksi Binance Testnet (di halaman Profile). Key/secret hanya di memori. */
(function (root) {
  'use strict';
  var A = root.ASTRA = root.ASTRA || {};
  var doc = root.document, busy = false, msg = '', msgKind = '';
  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function inner() {
    var st = A.BinanceTestnet.status(), acc = A.BinanceTestnet.account();
    var h = '<div class="section-head"><h2 class="section-title">Binance Testnet</h2><span class="badge ' + (acc ? '' : 'badge--warn') + '">' + esc(st.state) + '</span></div>';
    h += '<p class="tiny muted">Uang virtual. Bukan akun asli. Key hanya di memori halaman: hilang saat halaman ditutup dan tidak pernah disimpan.</p>';
    if (msg) h += '<p class="small ' + (msgKind === 'ok' ? '' : 'warn') + '">' + esc(msg) + '</p>';
    if (!acc) {
      h += '<label class="field"><span class="field-label">API Key (testnet)</span><input class="input" id="tn-key" type="text" autocomplete="off" autocapitalize="off" spellcheck="false"></label>';
      h += '<label class="field"><span class="field-label">Secret Key (testnet)</span><input class="input" id="tn-secret" type="password" autocomplete="off" autocapitalize="off" spellcheck="false"></label>';
      h += '<button class="btn btn--primary btn--block" data-action="tn-connect"' + (busy ? ' disabled' : '') + '>' + (busy ? 'Menghubungkan…' : 'Hubungkan testnet') + '</button>';
      h += '<p class="tiny muted">Buat key di testnet.binance.vision (login GitHub) → API Key → pilih HMAC → aktifkan izin trading.</p>';
    } else {
      h += '<div class="indicator-item"><span>Izin trading</span><strong class="mono">' + (acc.canTrade ? 'YA' : 'TIDAK') + '</strong></div>';
      h += acc.balances.slice(0, 12).map(function (b) { return '<div class="list-row"><span>' + esc(b.asset) + '</span><strong class="mono">' + esc(b.free) + (b.locked ? ' (terkunci ' + esc(b.locked) + ')' : '') + '</strong></div>'; }).join('') || '<p class="small muted">Saldo kosong.</p>';
      h += '<div class="control-row"><button class="btn btn--outline" data-action="tn-refresh"' + (busy ? ' disabled' : '') + '>Segarkan</button><button class="btn btn--danger" data-action="tn-disconnect">Putuskan</button></div>';
    }
    return h;
  }
  function html() { return '<section class="card" id="tn-panel">' + inner() + '</section>'; }
  function redraw() { var el = doc.getElementById('tn-panel'); if (el) el.innerHTML = inner(); }
  function run(p, okMsg) {
    busy = true; msg = ''; redraw();
    return p.then(function () { msg = okMsg; msgKind = 'ok'; }).catch(function (e) { msg = e.message; msgKind = 'err'; })
      .then(function () { busy = false; redraw(); });
  }
  doc.addEventListener('click', function (e) {
    var t = e.target.closest && e.target.closest('[data-action^="tn-"]'); if (!t || busy) return;
    var act = t.dataset.action;
    if (act === 'tn-connect') {
      var k = doc.getElementById('tn-key'), s = doc.getElementById('tn-secret');
      var kv = k ? k.value : '', sv = s ? s.value : '';
      if (k) k.value = ''; if (s) s.value = '';
      run(A.BinanceTestnet.connect(kv, sv), 'Terhubung ke testnet. Saldo dibaca dari Binance.');
    } else if (act === 'tn-refresh') run(A.BinanceTestnet.refresh(), 'Saldo diperbarui.');
    else if (act === 'tn-disconnect') { A.BinanceTestnet.disconnect(); msg = 'Terputus. Key dihapus dari memori.'; msgKind = 'ok'; redraw(); }
  });
  A.TestnetPanel = { html: html };
})(window);