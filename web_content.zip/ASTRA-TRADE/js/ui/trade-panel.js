/* ASTRA TRADE — panel UI Jenis Transaksi (Flex / InZone / Forex), sinyal, Dry Run, Paper, dan scheduler backend.
 * app.js hanya memanggil hook di sini; semua aksi data-action "tx-*" ditangani di handle().
 * Tidak ada tombol order live: gerbang live tertutup dan ditampilkan apa adanya. */
(function (root) {
  'use strict';
  var A = root.ASTRA = root.ASTRA || {};
  var doc = root.document;
  var ctx = { render: function () {}, toast: function () {} };
  var lastSignal = {};
  var sched = { loaded: false, loading: false, error: null, data: null };
  var lastSettleAt = 0;

  function esc(s) { return A.Format ? A.Format.escape(s) : String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function badge(text, kind) { return '<span class="badge ' + (kind ? 'badge--' + kind : '') + '">' + esc(text) + '</span>'; }
  function active() { return A.TransactionConfig ? A.TransactionConfig.getActive() : 'FLEX'; }
  function def(type) { return A.TransactionTypes ? A.TransactionTypes.describe(type) : null; }
  function money(n) { return Number.isFinite(n) ? 'Rp' + Math.round(n).toLocaleString('id-ID') : '—'; }
  function fmtTime(ts) { return ts && A.Format && A.Format.datetime ? A.Format.datetime(ts) : ts ? new Date(ts).toLocaleString() : '—'; }

  /* ---------- badge / strip jenis transaksi aktif ---------- */
  function typeBadge() { return badge('JENIS: ' + active(), 'muted'); }
  function typeStrip() {
    var t = active(), s = A.TransactionTypes ? A.TransactionTypes.spec(t) : null;
    return '<div class="notice"><span>◈</span><span>Jenis Transaksi aktif: <strong>' + esc(t) + '</strong> (' + esc((def(t) || {}).label || t) + ') · spesifikasi broker: <strong>' +
      esc(s ? s.status : 'UNVERIFIED') + '</strong>. Ini pilihan produk Olymptrade, bukan AI Method.</span></div>';
  }

  /* ---------- Config: pilihan jenis + parameter per jenis ---------- */
  function marketOptions(type, current) {
    if (type === 'FOREX') {
      var pairs = A.ForexReference ? A.ForexReference.pairs : [];
      return pairs.map(function (p) { return '<option value="' + p.symbol + '" ' + (p.symbol === current ? 'selected' : '') + '>' + esc(p.symbol) + ' · kurs referensi harian ECB</option>'; }).join('');
    }
    return (A.AssetList ? A.AssetList.all() : []).map(function (x) { return '<option value="' + x.symbol + '" ' + (x.symbol === current ? 'selected' : '') + '>' + esc(x.ticker) + '/USDT · Spot Binance (pembanding)</option>'; }).join('');
  }
  function durLabel(v) { return v === 0.25 ? '15 detik' : v + ' menit'; }
  function fieldHtml(type, f, cfg) {
    var v = cfg[f.key], id = 'tx-' + f.key;
    var help = f.estimate ? '<span class="config-help">ESTIMATE: asumsi Anda sendiri; bukan data broker. Kosong = simulasi yang membutuhkannya ditolak.</span>' : '';
    if (f.kind === 'market') return '<label class="field"><span class="field-label">' + esc(f.label) + '</span><div class="select"><select data-tx-field="' + f.key + '" id="' + id + '">' + marketOptions(type, v) + '</select></div></label>';
    if (f.kind === 'select') return '<label class="field"><span class="field-label">' + esc(f.label) + '</span><div class="select"><select data-tx-field="' + f.key + '" id="' + id + '">' +
      f.options.map(function (o) { return '<option value="' + o + '" ' + (Number(v) === o ? 'selected' : '') + '>' + durLabel(o) + '</option>'; }).join('') + '</select></div><span class="config-help">Opsi UI ASTRA; durasi yang diizinkan broker belum terverifikasi.</span></label>';
    return '<label class="field"><span class="field-label">' + esc(f.label) + '</span><input class="input" data-tx-field="' + f.key + '" id="' + id + '" type="number" step="any" inputmode="decimal" value="' + (v === null || v === undefined ? '' : esc(v)) + '">' + help + '</label>';
  }
  function configHtml() {
    if (!A.TransactionTypes || !A.TransactionConfig) return '';
    var t = active(), d = def(t), cfg = A.TransactionConfig.get(t), spec = A.TransactionTypes.spec(t);
    var h = '<section class="card terminal-section" data-tx-config="' + t + '"><div class="section-head"><h2 class="section-title">Jenis Transaksi Olymptrade</h2>' + badge('SPEC ' + spec.status, 'warn') + '</div>';
    h += '<div class="notice"><span>ⓘ</span><span>Flex, InZone, dan Forex adalah <strong>jenis transaksi/produk broker</strong>. Pilihan ini terpisah dari AI Method/strategi, Trading Mode, dan Scheduler. Setiap jenis menyimpan parameter sendiri.</span></div>';
    h += '<div class="tabs" role="tablist" aria-label="Jenis Transaksi">' + A.TransactionTypes.TYPES.map(function (x) {
      return '<button class="tab ' + (x === t ? 'is-active' : '') + '" data-action="tx-select" data-type="' + x + '" role="tab" aria-selected="' + (x === t) + '">' + esc((def(x) || {}).label || x) + '</button>'; }).join('') + '</div>';
    h += '<p class="small" style="margin:10px 0 4px"><strong>' + esc(d.label) + '</strong> · ' + esc(d.summary) + ' <a href="' + esc(d.helpUrl) + '" target="_blank" rel="noopener noreferrer">Panduan resmi</a></p>';
    h += '<div class="config-grid">' + d.fields.map(function (f) { return fieldHtml(t, f, cfg); }).join('') + '</div>';
    h += '<button class="btn btn--primary btn--block" data-action="tx-save">Simpan parameter ' + esc(d.label) + '</button>';
    h += '<details class="config-block"><summary class="small">Spesifikasi broker untuk ' + esc(d.label) + ' (' + spec.missingForLive.length + ' belum terverifikasi)</summary><div class="tiny muted" style="margin-top:8px">' +
      Object.keys(spec.attributes).map(function (k) { var a = spec.attributes[k]; return '<div class="list-row"><span>' + esc(k) + '</span>' + badge(a.status, a.status === 'VERIFIED' ? '' : 'warn') + '</div>'; }).join('') +
      '<p>Ketersediaan aset, jam transaksi, nominal min/maks, durasi, payout/biaya, multiplier, spread, margin, dan ukuran kontrak harus dikonfirmasi dari informasi resmi/akun. ASTRA tidak menanam nilai tersebut.</p></div></details>';
    return h + '</section>';
  }

  /* ---------- Control: sinyal, Dry Run, Paper ---------- */
  function signalCard(sig) {
    if (!sig) return '<p class="small muted">Belum ada evaluasi. Tekan "Evaluasi sinyal".</p>';
    var tone = sig.available ? '' : 'warn';
    var main = sig.transactionType === 'INZONE'
      ? (sig.zone ? 'Rentang ' + esc(sig.zone.lower.toFixed(4)) + ' – ' + esc(sig.zone.upper.toFixed(4)) + ' · ' + esc(sig.zone.assessment) : 'Rentang belum dapat dinilai')
      : (sig.direction ? 'Arah ' + esc(sig.direction) : 'Tanpa arah');
    var h = '<div class="signal-card"><div class="signal-icon">⌁</div><div><div class="signal-title">' + esc(sig.transactionType) + ' · ' + esc(sig.symbol) + ' · ' + main + '</div>' +
      '<div class="signal-text">Status ' + esc(sig.status) + ' · ' + esc(sig.method) + ' · ' + esc(sig.label) + '</div></div></div>';
    h += '<div class="indicator-item"><span>Provider harga</span><strong class="mono">' + esc(sig.quote.provider) + '</strong></div>';
    h += '<div class="indicator-item"><span>Tipe pasar / freshness</span><strong class="mono">' + esc(sig.quote.marketType) + ' · ' + esc(sig.quote.freshness) + '</strong></div>';
    h += '<div class="indicator-item"><span>Waktu sinyal</span><strong class="mono">' + esc(fmtTime(sig.timestamp)) + '</strong></div>';
    h += '<div class="indicator-item"><span>Validasi</span><strong class="mono ' + tone + '">' + esc(sig.validation.status) + ' · executable=' + sig.validation.executable + '</strong></div>';
    h += '<div class="tiny muted" style="margin-top:6px">' + sig.reasons.map(function (r) { return '• ' + esc(r); }).join('<br>') + '</div>';
    h += '<details class="config-block"><summary class="small">Blocker live (' + sig.validation.blockers.length + ')</summary><div class="tiny muted">' + sig.validation.blockers.map(function (b) { return '• ' + esc(b); }).join('<br>') + '</div></details>';
    return h;
  }
  function controlHtml() {
    if (!A.EntrySignal || !A.TransactionConfig) return '';
    var t = active(), d = def(t), cfg = A.TransactionConfig.get(t);
    var h = '<section class="card terminal-section"><div class="section-head"><h2 class="section-title">Sinyal · ' + esc(d.label) + '</h2>' + badge('RULE-BASED · NO AI MODEL', 'muted') + '</div>';
    h += '<div class="grid-2"><div class="stat"><span class="stat-label">JENIS TRANSAKSI</span><span class="stat-value">' + esc(t) + '</span></div><div class="stat"><span class="stat-label">ASET</span><span class="stat-value">' + esc(cfg.market) + '</span></div></div>';
    h += '<div class="control-row"><button class="btn btn--outline" data-action="tx-evaluate">Evaluasi sinyal</button><button class="btn btn--outline" data-action="tx-dryrun">Dry Run</button><button class="btn btn--outline" data-action="tx-paper">Paper entry</button></div>';
    h += signalCard(lastSignal[t]);
    h += '<div class="risk-line"><i class="dot dot--warn"></i> LIVE: ' + badge('GERBANG TERTUTUP', 'warn') + ' API/izin resmi Olymptrade, kuotasi broker, dan spesifikasi produk belum terverifikasi. Dry Run & Paper tidak memanggil broker.</div></section>';
    return h;
  }

  /* ---------- Ledger: Paper dan Dry Run per jenis ---------- */
  function paperHtml() {
    var h = typeStrip();
    if (!A.PaperLedger) return h + '<p class="small muted">Paper ledger tidak tersedia (penyimpanan lokal tidak aktif).</p>';
    var li = A.PaperLedger.loadInfo();
    if (li.corrupt) h += '<div class="notice"><span>⚠</span><span>' + esc(li.reason) + ' Salinan dikarantina.</span></div>';
    h += '<div class="notice"><span>ⓘ</span><span>PAPER = simulasi lokal, berlabel <strong>ESTIMATE</strong> (payout/multiplier/biaya adalah asumsi Anda). Harga dari Binance Spot/ECB, <strong>bukan</strong> simulasi harga Olymptrade. Engine: <strong>STOPPED</strong> setelah reload.</span></div>';
    var books = A.PaperLedger.books();
    h += '<div class="control-row"><button class="btn btn--outline" data-action="tx-paper-settle">Selesaikan yang jatuh tempo</button><button class="btn btn--outline" data-action="tx-paper-export">Export paper</button></div>';
    if (!books.length) return h + '<div class="ledger-empty"><div class="section-title">Belum ada ledger paper</div><p class="small muted">Buat sinyal lalu tekan "Paper entry" di Terminal. Tidak ada data contoh.</p></div>';
    books.forEach(function (b) {
      var s = A.PaperLedger.summary(b.transactionType, b.sourceId), pos = A.PaperLedger.positions(b.transactionType, b.sourceId), hist = A.PaperLedger.history(b.transactionType, b.sourceId).slice(0, 15);
      h += '<section class="card"><div class="section-head"><h3 class="section-title">' + esc(b.transactionType) + ' · ' + esc(b.sourceId) + '</h3>' + badge('ESTIMATE', 'warn') + '</div>';
      h += '<div class="stats-grid"><div class="stat"><span class="stat-label">SALDO</span><span class="stat-value">' + money(s.balance) + '</span></div><div class="stat"><span class="stat-label">P&L</span><span class="stat-value">' + money(s.realizedPnlIDR) + '</span></div><div class="stat"><span class="stat-label">W/L</span><span class="stat-value">' + s.wins + '/' + s.losses + '</span></div></div>';
      h += pos.map(function (p) { return '<div class="list-row"><div><div class="setting-title">OPEN · ' + esc(p.symbol) + ' · ' + esc(p.direction || (p.zoneLower + '–' + p.zoneUpper)) + '</div><div class="setting-sub">' + money(p.stakeIDR) + ' @ ' + esc(p.entryPrice) + (p.expiresAt ? ' · jatuh tempo ' + esc(fmtTime(p.expiresAt)) : '') + '</div></div>' + badge('OPEN') + '</div>'; }).join('');
      h += hist.map(function (x) { return '<div class="list-row"><div><div class="setting-title">' + esc(x.outcome) + ' · ' + esc(x.symbol) + ' · ' + esc(x.closeReason) + '</div><div class="setting-sub">' + money(x.pnlIDR) + ' (ESTIMATE) · ' + esc(fmtTime(x.closedAt)) + '</div></div>' + badge(x.outcome, x.pnlIDR < 0 ? 'down' : 'muted') + '</div>'; }).join('');
      h += '<button class="btn btn--small btn--outline" data-action="tx-paper-reset" data-type="' + esc(b.transactionType) + '" data-source="' + esc(b.sourceId) + '">Reset ledger ini</button></section>';
    });
    return h;
  }
  function dryrunHtml() {
    var h = typeStrip();
    var rows = A.DryRun ? A.DryRun.list() : [];
    h += '<div class="notice"><span>ⓘ</span><span><strong>DRY RUN</strong> memvalidasi konfigurasi, risiko, dan kesegaran data. Tidak ada request ke broker, tidak ada order, tidak mengubah saldo/posisi.</span></div>';
    h += '<div class="control-row"><button class="btn btn--outline" data-action="tx-dry-export">Export Dry Run</button><button class="btn btn--outline" data-action="tx-dry-clear">Hapus catatan</button></div>';
    if (!rows.length) return h + '<div class="ledger-empty"><div class="section-title">Belum ada catatan Dry Run</div></div>';
    return h + rows.slice(0, 100).map(function (r) {
      return '<div class="list-row"><div style="min-width:0;flex:1"><div class="setting-title">' + esc(r.transactionType) + ' · ' + esc(r.symbol) + ' · ' + esc(r.direction || (r.zone ? 'ZONE' : '—')) + '</div><div class="setting-sub">' + esc(fmtTime(r.timestamp)) + ' · ' + esc(r.provider || '—') + ' · ' + esc(r.freshness || '—') +
        (r.blockers.length ? ' · ' + r.blockers.map(function (b) { return esc(b.id); }).join(', ') : '') + '</div></div>' + badge('DRY RUN · ' + r.verdict, r.verdict === 'REJECTED' ? 'warn' : 'muted') + '</div>'; }).join('');
  }
  function ledgerHtml(tab) { return tab === 'dryrun' ? dryrunHtml() : paperHtml(); }

  /* ---------- Scheduler backend ---------- */
  function api(method, url, body) {
    var opt = { method: method, credentials: 'same-origin', headers: { Accept: 'application/json' } };
    if (body !== undefined) { opt.headers['Content-Type'] = 'application/json'; opt.body = JSON.stringify(body); }
    return root.fetch(url, opt).then(function (r) { return r.json().then(function (j) { j._status = r.status; return j; }); });
  }
  function loadScheduler(force) {
    if (sched.loading || (sched.loaded && !force)) return;
    sched.loading = true;
    api('GET', '/api/scheduler').then(function (j) { sched.data = j.ok ? j : null; sched.error = j.ok ? null : (j.message || 'Gagal memuat scheduler'); }).catch(function (e) { sched.error = 'Server tidak terjangkau: ' + (e && e.message || 'error'); sched.data = null; })
      .then(function () { sched.loading = false; sched.loaded = true; if (location.hash === '#/terminal') ctx.render('terminal'); });
  }
  function scheduleHtml() {
    if (!sched.loaded) loadScheduler(false);
    var tz = '';
    try { tz = Intl.DateTimeFormat().resolvedOptions().timeZone || ''; } catch (e) { tz = ''; }
    var h = '<section class="card terminal-section"><div class="section-head"><h2 class="section-title">Scheduler Backend</h2>' + badge(sched.data && sched.data.status && sched.data.status.running ? 'SERVER AKTIF' : 'TIDAK AKTIF', sched.data && sched.data.status && sched.data.status.running ? '' : 'warn') + '</div>';
    h += '<div class="notice"><span>ⓘ</span><span>Berjalan hanya selama proses server ASTRA aktif (bukan klaim 24/7). Mode tersedia: <strong>scan-only</strong> dan <strong>dry-run</strong>. Tidak ada order live; Emergency Stop menghentikan semua jadwal.</span></div>';
    if (sched.loading && !sched.data) h += '<p class="small muted">Memuat…</p>';
    else if (sched.error) h += '<p class="small warn">' + esc(sched.error) + ' Masuk dengan akun ASTRA (bukan mode lokal) dan jalankan <code>node server/server.js</code>.</p>';
    else if (sched.data) {
      var st = sched.data.status || {};
      h += '<div class="indicator-item"><span>Emergency Stop (server)</span><strong class="mono">' + (sched.data.emergencyStop ? 'AKTIF' : 'tidak aktif') + '</strong></div>';
      h += '<div class="indicator-item"><span>Tick terakhir</span><strong class="mono">' + esc(st.lastTickAt ? fmtTime(st.lastTickAt) : '—') + '</strong></div>';
      h += (sched.data.schedules || []).map(function (s) {
        return '<div class="list-row"><div style="min-width:0;flex:1"><div class="setting-title">' + esc(s.name || s.id) + ' · ' + esc(s.transactionType) + ' ' + esc(s.symbol) + '</div><div class="setting-sub">' + esc(s.time) + ' ' + esc(s.timezone) + ' · hari ' + esc(s.days.join(',')) + ' · ' + esc(s.mode) + ' · ' + (s.enabled ? 'ON' : 'OFF') + '</div></div><button class="btn btn--small btn--outline" data-action="tx-sched-delete" data-id="' + esc(s.id) + '">Hapus</button></div>'; }).join('') || '<p class="small muted">Belum ada jadwal backend.</p>';
      var runs = (sched.data.runs || []).slice(0, 5);
      if (runs.length) h += '<div class="tiny muted" style="margin-top:8px">Eksekusi terakhir:<br>' + runs.map(function (r) { return esc(fmtTime(r.at)) + ' · ' + esc(r.status) + ' · order=' + r.ordersSent; }).join('<br>') + '</div>';
    }
    h += '<div class="config-block"><div class="section-title">Tambah jadwal</div><div class="config-grid">' +
      '<label class="field"><span class="field-label">Waktu</span><input class="input" id="tx-sched-time" type="time" value="09:00"></label>' +
      '<label class="field"><span class="field-label">Zona waktu (IANA)</span><input class="input" id="tx-sched-tz" type="text" value="' + esc(tz || 'Asia/Jakarta') + '"></label>' +
      '<label class="field"><span class="field-label">Hari (0=Min … 6=Sab, pisah koma)</span><input class="input" id="tx-sched-days" type="text" value="1,2,3,4,5"></label>' +
      '<label class="field"><span class="field-label">Mode</span><div class="select"><select id="tx-sched-mode"><option value="scan-only">scan-only</option><option value="dry-run">dry-run</option></select></div></label></div>' +
      '<p class="config-help">Jadwal memakai jenis transaksi aktif (' + esc(active()) + ') dan asetnya.</p><button class="btn btn--primary btn--block" data-action="tx-sched-add">Simpan jadwal backend</button></div></section>';
    return h;
  }

  /* ---------- aksi ---------- */
  function evaluate() {
    var t = active(), cfg = A.TransactionConfig.get(t);
    lastSignal[t] = A.EntrySignal.evaluate(cfg.market, { transactionType: t, params: cfg });
    return lastSignal[t];
  }
  function readFields() {
    var out = {};
    doc.querySelectorAll('[data-tx-field]').forEach(function (el) { out[el.dataset.txField] = el.value === '' ? null : (el.tagName === 'SELECT' && /^[A-Z]/.test(el.value) ? el.value : Number.isNaN(Number(el.value)) ? el.value : Number(el.value)); });
    return out;
  }
  function postEmergency(action) {
    api('POST', '/api/trading/emergency', { action: action }).then(function (j) { if (j && j.ok === false && j._status !== 401) ctx.toast('Emergency Stop server: ' + (j.message || 'gagal'), 'warn'); }).catch(function () { /* tanpa server: hanya lokal */ });
  }

  function handle(act, el) {
    if (act.indexOf('tx-') !== 0) return false;
    if (act === 'tx-select') {
      var r = A.TransactionConfig.setActive(el.dataset.type);
      ctx.toast(r.ok ? 'Jenis Transaksi: ' + r.type + '. Parameter jenis lain tetap tersimpan terpisah.' : r.reason, r.ok ? 'good' : 'warn'); ctx.render('terminal');
    } else if (act === 'tx-save') {
      var t = active(), res = A.TransactionConfig.save(t, readFields());
      ctx.toast(res.ok ? 'Parameter ' + t + ' disimpan.' : res.errors.join(' '), res.ok ? 'good' : 'warn'); if (res.ok) ctx.render('terminal');
    } else if (act === 'tx-evaluate') {
      var s = evaluate(); ctx.toast('Sinyal ' + s.transactionType + ': ' + s.status + (s.direction ? ' ' + s.direction : '') + '. Tidak ada order.', s.available ? 'good' : 'warn'); ctx.render('terminal');
    } else if (act === 'tx-dryrun') {
      var sg = lastSignal[active()] || evaluate(), dr = A.DryRun.run(sg);
      ctx.toast('DRY RUN ' + dr.record.verdict + (dr.duplicate ? ' (sudah tercatat)' : '') + '. Tidak ada request ke broker.', dr.record.verdict === 'REJECTED' ? 'warn' : 'good'); ctx.render('terminal');
    } else if (act === 'tx-paper') {
      var sp = lastSignal[active()] || evaluate();
      if (!sp.available) { ctx.toast('Tidak ada sinyal yang dapat disimulasikan (' + sp.status + ').', 'warn'); return true; }
      var po = A.PaperLedger ? A.PaperLedger.open(sp, A.TransactionConfig.get(active())) : { ok: false, reason: 'Paper ledger tidak tersedia.' };
      ctx.toast(po.ok ? (po.duplicate ? 'Paper entry sudah tercatat (idempoten).' : 'Paper entry dibuka (ESTIMATE, bukan transaksi broker).') : po.reason, po.ok ? 'good' : 'warn'); ctx.render('terminal');
    } else if (act === 'tx-paper-settle') {
      var rs = settleDue(true); ctx.toast(rs.settled.length + ' posisi paper diselesaikan; ' + rs.waiting.length + ' menunggu harga segar.', rs.settled.length ? 'good' : 'warn'); ctx.render('ledger');
    } else if (act === 'tx-paper-reset') {
      if (root.confirm('Hapus ledger paper ' + el.dataset.type + ' · ' + el.dataset.source + '? Ini tidak mengubah akun broker.')) { A.PaperLedger.reset(el.dataset.type, el.dataset.source); ctx.render('ledger'); }
    } else if (act === 'tx-paper-export') { ctx.download('astra-paper-ledger.json', A.PaperLedger.exportJSON(), 'application/json');
    } else if (act === 'tx-dry-export') { ctx.download('astra-dry-run.json', A.DryRun.exportJSON(), 'application/json');
    } else if (act === 'tx-dry-clear') { if (root.confirm('Hapus semua catatan Dry Run?')) { A.DryRun.clear(); ctx.render('ledger'); }
    } else if (act === 'tx-sched-add') {
      var days = String(($('tx-sched-days') || {}).value || '').split(',').map(function (x) { return Number(x.trim()); });
      var payload = { action: 'upsert', schedule: { time: $('tx-sched-time').value, timezone: $('tx-sched-tz').value.trim(), days: days, mode: $('tx-sched-mode').value, enabled: true,
        transactionType: active(), symbol: A.TransactionConfig.get(active()).market, name: 'Jadwal ' + active() } };
      api('POST', '/api/scheduler', payload).then(function (j) { ctx.toast(j.ok ? 'Jadwal backend disimpan.' : (j.message || 'Jadwal ditolak.'), j.ok ? 'good' : 'warn'); loadScheduler(true); }).catch(function () { ctx.toast('Server tidak terjangkau.', 'warn'); });
    } else if (act === 'tx-sched-delete') {
      api('POST', '/api/scheduler', { action: 'delete', id: el.dataset.id }).then(function (j) { ctx.toast(j.ok ? 'Jadwal dihapus.' : (j.message || 'Gagal.'), j.ok ? 'good' : 'warn'); loadScheduler(true); }).catch(function () { ctx.toast('Server tidak terjangkau.', 'warn'); });
    } else return false;
    return true;
  }
  function $(id) { return doc.getElementById(id); }

  function settleDue(force) {
    if (!A.PaperLedger) return { settled: [], waiting: [] };
    var now = Date.now();
    if (!force && now - lastSettleAt < 5000) return { settled: [], waiting: [] };
    lastSettleAt = now;
    return A.PaperLedger.settleDue(function (symbol) { var q = A.QuoteSources.describe(symbol, now); return { price: q.price, fresh: q.freshness === 'FRESH' }; }, now);
  }

  function init(c) {
    ctx = Object.assign(ctx, c || {});
    if (!A.EventBus) return;
    A.EventBus.on('market:update', function () { var r = settleDue(false); if (r.settled.length && location.hash === '#/ledger') ctx.render('ledger'); });
    A.EventBus.on('engine:status', function (e) {
      if (!e) return;
      if (e.state === 'EMERGENCY_STOP') postEmergency('activate');
      else if (e.prev === 'EMERGENCY_STOP' && e.state === 'STOPPED') postEmergency('reset');
    });
    /* Mode Auto: setiap hasil pindai terjadwal menghasilkan sinyal + Dry Run (aman). Paper/Live tetap tindakan pengguna. */
    A.EventBus.on('scan:result', function () {
      if (!A.BotController || !A.BotController.isRunning() || !A.TradingModeManager || A.TradingModeManager.current() !== 'auto') return;
      if (!A.EntrySignal || !A.DryRun) return;
      var sg = evaluate(); A.DryRun.run(sg);
      if (location.hash === '#/ledger') ctx.render('ledger');
    });
  }

  A.TradePanel = { init: init, typeBadge: typeBadge, typeStrip: typeStrip, configHtml: configHtml, controlHtml: controlHtml, ledgerHtml: ledgerHtml, scheduleHtml: scheduleHtml, handle: handle, evaluate: evaluate, lastSignal: function (t) { return lastSignal[t || active()] || null; } };
})(window);
