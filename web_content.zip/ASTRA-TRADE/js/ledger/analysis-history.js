/* Stores real local analysis observations only. This is not a trade/order ledger. */
(function (root) {
  'use strict';
  var A = root.ASTRA = root.ASTRA || {};
  var STORE_KEY = 'analysisHistory';
  var MAX_ROWS = 200;
  function all() {
    var rows = A.Storage ? A.Storage.get(STORE_KEY, []) : [];
    return Array.isArray(rows) ? rows.filter(function (r) { return r && typeof r === 'object'; }) : [];
  }
  function record(scan, source) {
    if (!scan || !scan.ready || !scan.symbol || !scan.indicators) return { ok: false, reason: 'Observasi belum memiliki cukup data.' };
    var at = Date.now();
    var minute = Math.floor(at / 60000);
    var rows = all();
    var duplicate = rows.some(function (row) { return row.symbol === scan.symbol && row.strategyId === (scan.strategy && scan.strategy.id || 'technical-trend') && Math.floor(Number(row.timestamp) / 60000) === minute; });
    if (duplicate) return { ok: true, duplicate: true };
    var i = scan.indicators;
    var row = {
      id: scan.symbol + '-' + minute + '-' + (scan.strategy && scan.strategy.id || 'technical-trend'),
      timestamp: at,
      symbol: scan.symbol,
      marketType: 'spot',
      source: String(source || 'manual-observation'),
      dataSource: scan.dataSource || 'Binance public spot data',
      dataStatus: scan.dataStatus || 'UNAVAILABLE',
      strategyId: scan.strategy && scan.strategy.id || 'technical-trend',
      strategyName: scan.strategy && scan.strategy.name || 'Technical Trend',
      observation: String(scan.observation || 'Belum tersedia').slice(0, 400),
      sampleCount: Number(scan.sampleCount) || 0,
      indicators: {
        ema9: Number.isFinite(i.ema9) ? i.ema9 : null,
        ema21: Number.isFinite(i.ema21) ? i.ema21 : null,
        rsi14: Number.isFinite(i.rsi14) ? i.rsi14 : null,
        momentum5: Number.isFinite(i.momentum5) ? i.momentum5 : null,
        volatilityPct: Number.isFinite(i.volatilityPct) ? i.volatilityPct : null,
        rangePct: Number.isFinite(i.rangePct) ? i.rangePct : null
      },
      classification: 'OBSERVATION_ONLY'
    };
    rows.unshift(row);
    rows = rows.slice(0, MAX_ROWS);
    if (!A.Storage || !A.Storage.set(STORE_KEY, rows)) return { ok: false, reason: 'Penyimpanan lokal tidak tersedia.' };
    if (A.Logger) A.Logger.info('analysis-history', 'Observasi teknikal disimpan', { symbol: row.symbol, source: row.source, classification: row.classification });
    if (A.EventBus) A.EventBus.emit('analysis-history:updated', { count: rows.length, symbol: row.symbol });
    return { ok: true, record: row };
  }
  function list() { return all().slice().sort(function (a, b) { return Number(b.timestamp) - Number(a.timestamp); }); }
  function clear() { return A.Storage ? A.Storage.remove(STORE_KEY) : false; }
  function exportJSON() {
    return JSON.stringify({ exportedAt: new Date().toISOString(), dataType: 'local-analysis-observations-not-trades', records: list() }, null, 2);
  }
  A.AnalysisHistory = { record: record, list: list, clear: clear, exportJSON: exportJSON, maxRows: MAX_ROWS };
})(window);
