/* ASTRA TRADE — Paper Ledger (UMD).
 *
 * Ledger simulasi per (jenis transaksi × sumber data): FLEX / INZONE / FOREX tidak pernah tercampur.
 * Setiap hasil berlabel ESTIMATE dan brokerSpecific:false: payout, multiplier, biaya, spread, dan
 * model kerugian broker BELUM terverifikasi, sehingga hanya asumsi eksplisit pengguna yang dipakai.
 * Harga Binance Spot / ECB bukan harga Olymptrade; ledger memuat sumbernya dan tidak menyebut
 * hasilnya sebagai simulasi Olymptrade.
 *
 * Tahan reload (storage), skema divalidasi, state rusak dikarantina (key + '.corrupt'),
 * idempoten per intent id, dan TIDAK pernah menjalankan timer / auto-start (engine selalu STOPPED).
 * Tidak ada panggilan ke broker.
 */
(function (root, factory) {
  var api = factory(root);
  if (typeof module === 'object' && module.exports) module.exports = api;
  else {
    var A = root.ASTRA = root.ASTRA || {};
    A.PaperLedgerFactory = api;
    if (A.Storage && A.RiskEngine && A.TransactionTypes) {
      A.PaperLedger = api.create({ storage: { get: function (k) { var v = A.Storage.get(k, null); return v === null ? null : JSON.stringify(v); }, set: function (k, v) { return A.Storage.set(k, JSON.parse(v)); }, remove: function (k) { return A.Storage.remove(k); } },
        key: 'paperLedger.v2', riskEngine: A.RiskEngine, types: A.TransactionTypes });
    }
  }
})(typeof window !== 'undefined' ? window : globalThis, function () {
  'use strict';

  var VERSION = 2, MAX_HISTORY = 500, MAX_SEEN = 1000, DEFAULT_START = 10000000;
  var PAPER_SOURCES = { BINANCE_SPOT: 'BINANCE_SPOT', ECB_REFERENCE: 'ECB_REFERENCE' };

  function fin(v) { return typeof v === 'number' && isFinite(v); }
  function clone(v) { return JSON.parse(JSON.stringify(v)); }
  function dayKey(ts) { return new Date(ts).toISOString().slice(0, 10); }
  function bookKey(type, source) { return type + '|' + source; }

  function create(opts) {
    opts = opts || {};
    var storage = opts.storage, KEY = opts.key || 'paperLedger.v2';
    var risk = opts.riskEngine, TT = opts.types;
    var clock = opts.clock || function () { return Date.now(); };
    var state = { version: VERSION, engine: 'STOPPED', updatedAt: 0, books: {} };
    var loadInfo = { ok: true, restored: false, corrupt: false };

    function validBook(b, key) {
      if (!b || typeof b !== 'object') return false;
      var parts = String(key).split('|');
      if (parts.length !== 2 || !TT.isType(parts[0]) || b.transactionType !== parts[0] || b.sourceId !== parts[1]) return false;
      if (!fin(b.startBalance) || b.startBalance <= 0 || !fin(b.balance) || b.balance < 0 || !fin(b.peakEquity)) return false;
      if (!Array.isArray(b.positions) || !Array.isArray(b.history) || !Array.isArray(b.seenIds)) return false;
      var okPos = b.positions.every(function (p) {
        return p && typeof p.id === 'string' && p.transactionType === b.transactionType && fin(p.stakeIDR) && p.stakeIDR > 0 &&
          fin(p.entryPrice) && p.entryPrice > 0 && fin(p.openedAt) && (p.expiresAt === null || fin(p.expiresAt)) && p.status === 'OPEN';
      });
      var okHist = b.history.every(function (h) {
        return h && typeof h.id === 'string' && h.transactionType === b.transactionType && fin(h.pnlIDR) && fin(h.closedAt) && typeof h.outcome === 'string';
      });
      return okPos && okHist && b.seenIds.every(function (s) { return typeof s === 'string'; });
    }

    function load() {
      var raw = null;
      try { raw = storage.get(KEY); } catch (e) { raw = null; }
      state = { version: VERSION, engine: 'STOPPED', updatedAt: 0, books: {} };
      if (raw === null || raw === undefined) { loadInfo = { ok: true, restored: false, corrupt: false }; return loadInfo; }
      try {
        var d = JSON.parse(raw);
        if (!d || d.version !== VERSION || !d.books || typeof d.books !== 'object') throw new Error('schema');
        Object.keys(d.books).forEach(function (k) { if (!validBook(d.books[k], k)) throw new Error('book ' + k); });
        state.books = d.books; state.updatedAt = fin(d.updatedAt) ? d.updatedAt : 0;
        loadInfo = { ok: true, restored: true, corrupt: false, books: Object.keys(state.books).length };
      } catch (e) {
        try { storage.set(KEY + '.corrupt', String(raw).slice(0, 200000)); } catch (e2) { /* abaikan */ }
        try { storage.remove(KEY); } catch (e3) { /* abaikan */ }
        loadInfo = { ok: false, restored: false, corrupt: true, reason: 'State paper ledger rusak; dikarantina dan dimulai bersih.' };
      }
      state.engine = 'STOPPED'; // tidak pernah auto-start
      return loadInfo;
    }
    function save() {
      state.updatedAt = clock();
      try { return storage.set(KEY, JSON.stringify(state)) !== false; } catch (e) { return false; }
    }

    function makeBook(type, source, start) {
      start = typeof start === 'number' && start > 0 ? start : DEFAULT_START;
      return { transactionType: type, sourceId: source, startBalance: start, balance: start, peakEquity: start,
        positions: [], history: [], seenIds: [], createdAt: clock(), updatedAt: clock(), basis: 'ESTIMATE', brokerSpecific: false };
    }
    function book(type, source, create) {
      if (!TT.isType(type)) return null;
      var k = bookKey(type, source);
      if (!state.books[k] && create) state.books[k] = makeBook(type, source, create);
      return state.books[k] || null;
    }

    function stakeAtRisk(b) { return b.positions.reduce(function (s, p) { return s + p.stakeIDR; }, 0); }
    function equity(b) { return b.balance + stakeAtRisk(b); } // posisi dinilai pada nilai pokok sampai ditutup
    function todayLoss(b, now) {
      var d = dayKey(now);
      return b.history.reduce(function (s, h) { return dayKey(h.closedAt) === d && h.pnlIDR < 0 ? s - h.pnlIDR : s; }, 0);
    }
    function ctxFor(b, now, extra) {
      var d = dayKey(now);
      var tradesToday = b.history.filter(function (h) { return dayKey(h.openedAt || h.closedAt) === d; }).length + b.positions.filter(function (p) { return dayKey(p.openedAt) === d; }).length;
      var last = b.positions.concat(b.history).reduce(function (m, x) { return Math.max(m, x.openedAt || 0); }, 0) || null;
      return Object.assign({ mode: 'PAPER', now: now, openPositions: b.positions.length, tradesToday: tradesToday, todayLossIDR: todayLoss(b, now),
        lastTradeAt: last, equity: equity(b), peakEquity: Math.max(b.peakEquity, equity(b)) }, extra || {});
    }

    function intentFrom(sig, params) {
      sig = sig || {}; params = Object.assign({}, sig.params || {}, params || {});
      var z = sig.zone || null;
      return {
        id: sig.id, transactionType: String(sig.transactionType || '').toUpperCase(), symbol: sig.symbol, direction: sig.direction || null,
        amountIDR: params.amountIDR, durationMinutes: params.durationMinutes, expiryMinutes: params.expiryMinutes,
        zoneLower: z ? z.lower : params.zoneLower, zoneUpper: z ? z.upper : params.zoneUpper,
        multiplier: params.multiplier, stopLossPct: params.stopLossPct, takeProfitPct: params.takeProfitPct, assumedPayoutPct: params.assumedPayoutPct,
        priceAtSignal: sig.priceAtSignal, quote: sig.quote || {}
      };
    }

    /* Membuka posisi paper dari sinyal/intent. Idempoten per intent.id. */
    function open(sig, params, extra) {
      var now = (extra && extra.now) || clock();
      var intent = intentFrom(sig, params);
      var type = intent.transactionType;
      if (!TT.isType(type)) return { ok: false, code: 'BAD_TYPE', reason: 'Jenis transaksi tidak dikenal.' };
      var q = intent.quote || {};
      var source = PAPER_SOURCES[q.providerId];
      if (!source) return { ok: false, code: 'NO_PAPER_SOURCE', reason: 'Sumber harga (' + (q.providerId || 'tidak ada') + ') tidak dapat dipakai untuk simulasi; Olymptrade belum menyediakan feed terverifikasi.' };
      if (!intent.id) return { ok: false, code: 'NO_ID', reason: 'Intent tanpa id tidak dapat dicatat secara idempoten.' };
      var b = book(type, source, false) || makeBook(type, source); // buku baru hanya disimpan bila posisi berhasil dibuka
      if (b.seenIds.indexOf(intent.id) >= 0) return { ok: true, duplicate: true, intentId: intent.id };
      if (q.freshness !== 'FRESH') return { ok: false, code: 'QUOTE_NOT_FRESH', reason: 'Simulasi hanya dibuka dari kuotasi segar (status: ' + (q.freshness || 'UNKNOWN') + ').' };
      if (!fin(intent.priceAtSignal) || intent.priceAtSignal <= 0) return { ok: false, code: 'NO_PRICE', reason: 'Harga masuk tidak tersedia.' };

      var norm = TT.normalize(type, Object.assign({}, intent, { market: intent.symbol }));
      if (!norm.ok) return { ok: false, code: 'BAD_PARAMS', reason: norm.errors.join(' ') };
      if ((type === 'FLEX' || type === 'INZONE') && !fin(Number(intent.assumedPayoutPct))) {
        return { ok: false, code: 'PAYOUT_UNKNOWN', reason: 'Payout broker belum terverifikasi. Isi "Asumsi payout %" (ESTIMATE) atau simulasi ditolak.' };
      }
      if (type === 'FOREX' && !(Number(intent.multiplier) > 0)) {
        return { ok: false, code: 'MULTIPLIER_UNKNOWN', reason: 'Multiplier Forex belum terverifikasi. Isi asumsi multiplier (ESTIMATE) atau simulasi ditolak.' };
      }
      var verdict = risk.evaluate(Object.assign({}, intent, { amountIDR: norm.value.amountIDR }), ctxFor(b, now, extra && extra.ctx), extra && extra.limits);
      if (!verdict.ok) return { ok: false, code: 'RISK_BLOCKED', reason: verdict.blockers.map(function (x) { return x.reason; }).join(' '), blockers: verdict.blockers, risk: verdict };
      if (norm.value.amountIDR > b.balance) return { ok: false, code: 'INSUFFICIENT_BALANCE', reason: 'Saldo paper tidak cukup.' };

      var entry = intent.priceAtSignal, minutes = type === 'FLEX' ? Number(intent.durationMinutes) : type === 'INZONE' ? Number(intent.expiryMinutes) : null;
      var pos = {
        id: 'P-' + now.toString(36) + '-' + (b.seenIds.length + 1), intentId: intent.id, transactionType: type, symbol: intent.symbol,
        direction: intent.direction, stakeIDR: norm.value.amountIDR, entryPrice: entry, openedAt: now,
        expiresAt: minutes ? now + minutes * 60000 : null,
        zoneLower: type === 'INZONE' ? Number(intent.zoneLower) : null, zoneUpper: type === 'INZONE' ? Number(intent.zoneUpper) : null,
        multiplier: type === 'FOREX' ? Number(intent.multiplier) : null,
        stopLossPrice: type === 'FOREX' && Number(intent.stopLossPct) > 0 ? entry * (1 + (intent.direction === 'BUY' ? -1 : 1) * Number(intent.stopLossPct) / 100) : null,
        takeProfitPrice: type === 'FOREX' && Number(intent.takeProfitPct) > 0 ? entry * (1 + (intent.direction === 'BUY' ? 1 : -1) * Number(intent.takeProfitPct) / 100) : null,
        assumedPayoutPct: type === 'FOREX' ? null : Number(intent.assumedPayoutPct),
        sourceId: source, provider: q.provider || source, marketType: q.marketType || null,
        basis: 'ESTIMATE', brokerSpecific: false, status: 'OPEN'
      };
      if (type === 'INZONE' && !(pos.zoneLower > 0 && pos.zoneUpper > pos.zoneLower)) return { ok: false, code: 'BAD_ZONE', reason: 'Rentang InZone tidak valid.' };
      if (!state.books[bookKey(type, source)]) state.books[bookKey(type, source)] = b;
      b.balance -= pos.stakeIDR;
      b.positions.push(pos);
      b.seenIds.push(intent.id); if (b.seenIds.length > MAX_SEEN) b.seenIds = b.seenIds.slice(-MAX_SEEN);
      b.updatedAt = now;
      save();
      return { ok: true, position: clone(pos), risk: verdict };
    }

    function pnlFor(pos, exitPrice) {
      var t = pos.transactionType;
      if (t === 'FLEX') {
        if (exitPrice === pos.entryPrice) return { outcome: 'TIE_UNVERIFIED', pnlIDR: 0, note: 'Harga sama; perlakuan seri broker belum terverifikasi (dianggap 0).' };
        var win = pos.direction === 'BUY' ? exitPrice > pos.entryPrice : exitPrice < pos.entryPrice;
        return win ? { outcome: 'WIN', pnlIDR: pos.stakeIDR * pos.assumedPayoutPct / 100 } : { outcome: 'LOSS', pnlIDR: -pos.stakeIDR };
      }
      if (t === 'INZONE') {
        var lo = pos.zoneLower, hi = pos.zoneUpper;
        if (exitPrice === lo || exitPrice === hi) return { outcome: 'BOUNDARY_UNVERIFIED', pnlIDR: 0, note: 'Harga tepat di batas rentang; aturan batas belum terverifikasi (dianggap 0).' };
        return exitPrice > lo && exitPrice < hi ? { outcome: 'WIN', pnlIDR: pos.stakeIDR * pos.assumedPayoutPct / 100, zone: 'IN_ZONE' } : { outcome: 'LOSS', pnlIDR: -pos.stakeIDR, zone: 'OUT_OF_ZONE' };
      }
      var sign = pos.direction === 'BUY' ? 1 : -1;
      var raw = sign * (exitPrice - pos.entryPrice) / pos.entryPrice * pos.stakeIDR * pos.multiplier;
      var pnl = Math.max(-pos.stakeIDR, raw);
      return { outcome: pnl > 0 ? 'WIN' : pnl < 0 ? 'LOSS' : 'FLAT', pnlIDR: pnl, capped: raw < -pos.stakeIDR };
    }

    function close(b, idx, exitPrice, ts, reason, extra) {
      var pos = b.positions[idx];
      var r = pnlFor(pos, exitPrice);
      var rec = Object.assign({}, pos, r, { status: 'CLOSED', exitPrice: exitPrice, closedAt: ts, closeReason: reason, pnlBasis: 'ESTIMATE', brokerSpecific: false }, extra || {});
      b.positions.splice(idx, 1);
      b.balance += pos.stakeIDR + r.pnlIDR;
      b.history.unshift(rec); b.history = b.history.slice(0, MAX_HISTORY);
      b.peakEquity = Math.max(b.peakEquity, equity(b));
      b.updatedAt = ts;
      return rec;
    }

    function findPos(positionId) {
      var keys = Object.keys(state.books);
      for (var i = 0; i < keys.length; i++) {
        var b = state.books[keys[i]], idx = b.positions.findIndex(function (p) { return p.id === positionId; });
        if (idx >= 0) return { b: b, idx: idx };
      }
      return null;
    }

    /* Menutup posisi dengan harga yang diberikan. FLEX/INZONE: hanya saat/ setelah kedaluwarsa
       (penutupan lebih awal ditolak sebelum spesifikasi earlyClose terverifikasi). */
    function settle(positionId, price, ts) {
      var hit = findPos(positionId);
      if (!hit) return { ok: false, code: 'NOT_FOUND', reason: 'Posisi tidak ditemukan.' };
      price = Number(price); ts = Number(ts) || clock();
      if (!fin(price) || price <= 0) return { ok: false, code: 'BAD_PRICE', reason: 'Harga penutupan tidak valid.' };
      var pos = hit.b.positions[hit.idx];
      if (pos.expiresAt !== null && ts < pos.expiresAt && !TT.isVerified(pos.transactionType, 'earlyClose')) {
        return { ok: false, code: 'EARLY_CLOSE_UNVERIFIED', reason: 'Penutupan lebih awal untuk ' + pos.transactionType + ' belum terverifikasi; tunggu kedaluwarsa.' };
      }
      var rec = close(hit.b, hit.idx, price, ts, pos.expiresAt !== null ? 'EXPIRED' : 'MANUAL_CLOSE');
      save();
      return { ok: true, record: clone(rec) };
    }

    /* Menyelesaikan semua FLEX/INZONE yang jatuh tempo. priceFor(symbol, now) → { price, fresh } atau null. */
    function settleDue(priceFor, now) {
      now = Number(now) || clock();
      var settled = [], waiting = [];
      Object.keys(state.books).forEach(function (k) {
        var b = state.books[k];
        for (var i = b.positions.length - 1; i >= 0; i--) {
          var p = b.positions[i];
          if (p.expiresAt === null || p.expiresAt > now) continue;
          var q = priceFor ? priceFor(p.symbol, now) : null;
          if (!q || !fin(q.price) || q.fresh !== true) { waiting.push(p.id); continue; }
          settled.push(clone(close(b, i, q.price, now, 'EXPIRED')));
        }
      });
      if (settled.length) save();
      return { settled: settled, waiting: waiting };
    }

    /* FOREX: tutup otomatis bila harga menyentuh Stop Loss / Take Profit. */
    function markToMarket(symbol, price, ts) {
      price = Number(price); ts = Number(ts) || clock();
      var closed = [];
      if (!fin(price) || price <= 0) return { closed: closed };
      Object.keys(state.books).forEach(function (k) {
        var b = state.books[k];
        for (var i = b.positions.length - 1; i >= 0; i--) {
          var p = b.positions[i];
          if (p.transactionType !== 'FOREX' || p.symbol !== symbol) continue;
          var sl = p.stopLossPrice !== null && (p.direction === 'BUY' ? price <= p.stopLossPrice : price >= p.stopLossPrice);
          var tp = p.takeProfitPrice !== null && (p.direction === 'BUY' ? price >= p.takeProfitPrice : price <= p.takeProfitPrice);
          if (sl || tp) closed.push(clone(close(b, i, price, ts, sl ? 'STOP_LOSS' : 'TAKE_PROFIT')));
        }
      });
      if (closed.length) save();
      return { closed: closed };
    }

    function summary(type, source) {
      var b = book(type, source, false);
      if (!b) return { transactionType: type, sourceId: source, exists: false };
      var wins = b.history.filter(function (h) { return h.outcome === 'WIN'; }).length;
      var losses = b.history.filter(function (h) { return h.outcome === 'LOSS'; }).length;
      return { exists: true, transactionType: type, sourceId: source, startBalance: b.startBalance, balance: b.balance, equity: equity(b),
        realizedPnlIDR: b.history.reduce(function (s, h) { return s + h.pnlIDR; }, 0), wins: wins, losses: losses, closed: b.history.length,
        open: b.positions.length, basis: 'ESTIMATE', brokerSpecific: false, engine: 'STOPPED' };
    }
    function books() { return Object.keys(state.books).map(function (k) { return { key: k, transactionType: state.books[k].transactionType, sourceId: state.books[k].sourceId }; }); }
    function positions(type, source) { var b = book(type, source, false); return b ? clone(b.positions) : []; }
    function history(type, source) { var b = book(type, source, false); return b ? clone(b.history) : []; }
    function reset(type, source) {
      var k = bookKey(type, source);
      if (!state.books[k]) return { ok: true, existed: false };
      delete state.books[k]; save(); return { ok: true, existed: true };
    }
    function exportJSON() {
      return JSON.stringify({ exportedAt: new Date(clock()).toISOString(), dataType: 'paper-simulation-not-broker-trades', basis: 'ESTIMATE', state: state }, null, 2);
    }

    load();
    return {
      open: open, settle: settle, settleDue: settleDue, markToMarket: markToMarket, summary: summary, books: books,
      positions: positions, history: history, reset: reset, exportJSON: exportJSON, load: load, save: save,
      loadInfo: function () { return Object.assign({}, loadInfo); }, isRunning: function () { return false; },
      engineState: function () { return state.engine; }, setStartBalance: function (type, source, amount) {
        var b = book(type, source, false);
        if (b && (b.history.length || b.positions.length)) return { ok: false, reason: 'Saldo awal tidak dapat diubah setelah ada aktivitas; reset dulu.' };
        if (!(Number(amount) > 0)) return { ok: false, reason: 'Saldo awal tidak valid.' };
        if (b) { b.startBalance = b.balance = b.peakEquity = Number(amount); save(); }
        return { ok: true };
      }, ensureBook: function (type, source, start) { var b = book(type, source, start || true); save(); return !!b; },
      sources: PAPER_SOURCES, VERSION: VERSION
    };
  }

  return { create: create, VERSION: VERSION, SOURCES: PAPER_SOURCES, DEFAULT_START: DEFAULT_START };
});
