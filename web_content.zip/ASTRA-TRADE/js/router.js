/* ASTRA TRADE V1 — js/router.js
 * Router berbasis hash (#/terminal). Tiap view mendaftar dengan
 * Router.register(nama, { title, render(container) }).
 * Muat setelah event-bus.js, sebelum app.js. */
(function (root) {
  'use strict';

  var ASTRA = (root.ASTRA = root.ASTRA || {});
  if (ASTRA.Router) return;

  var views = {};
  var container = null;
  var fallback = null;
  var current = null;

  function register(name, view) {
    if (typeof name !== 'string' || !name) throw new TypeError('Router.register: nama view tidak valid');
    if (!view || typeof view.render !== 'function') throw new TypeError('Router.register: view harus punya render()');
    views[name] = view;
    if (!fallback) fallback = name; // view pertama = default
  }

  function nameFromHash() {
    var m = /^#\/([a-z0-9-]+)/i.exec(root.location.hash || '');
    return m && views[m[1]] ? m[1] : null;
  }

  function show(name) {
    var view = views[name];
    if (!view || !container) return false;
    if (current && views[current] && typeof views[current].destroy === 'function') {
      try { views[current].destroy(); } catch (e) { console.error('[Router] destroy gagal:', e); }
    }
    container.innerHTML = '';
    container.scrollTop = 0;
    container.classList.remove('view-enter');
    void container.offsetWidth; // restart animasi
    container.classList.add('view-enter');
    try {
      view.render(container);
    } catch (e) {
      console.error('[Router] render gagal untuk "' + name + '":', e);
      container.textContent = 'Tampilan gagal dimuat.';
    }
    var prev = current;
    current = name;
    if (ASTRA.EventBus) ASTRA.EventBus.emit('route:change', { name: name, prev: prev });
    return true;
  }

  function go(name) {
    if (!views[name]) return false;
    if (nameFromHash() === name) return show(name);
    root.location.hash = '#/' + name; // memicu hashchange -> show
    return true;
  }

  function onHashChange() { show(nameFromHash() || fallback); }

  function start(el) {
    container = el;
    root.removeEventListener('hashchange', onHashChange);
    root.addEventListener('hashchange', onHashChange);
    show(nameFromHash() || fallback);
  }

  function stop() {
    root.removeEventListener('hashchange', onHashChange);
    current = null;
  }

  ASTRA.Router = {
    register: register,
    start: start,
    stop: stop,
    go: go,
    current: function () { return current; },
    has: function (n) { return !!views[n]; }
  };
})(typeof window !== 'undefined' ? window : globalThis);
