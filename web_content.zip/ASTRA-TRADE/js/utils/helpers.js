/* ASTRA TRADE V1 module: Helpers. Functionality is exposed by the active app/core modules. */
(function(root){'use strict';var A=root.ASTRA=root.ASTRA||{};var key='helpers';if(!A.Modules)A.Modules={};A.Modules[key]={available:false,reason:'Modul ini belum diaktifkan dalam build baca-saja; tidak ada data atau operasi palsu.'};})(window);
