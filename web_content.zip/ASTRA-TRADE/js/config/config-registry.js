/* ASTRA TRADE V1 — js/config/config-registry.js
 * Registri konfigurasi modular. Setiap *.config.js mendaftarkan nilai default-nya.
 * Nilai aktif = default + override yang tervalidasi (kunci dan tipe harus sama).
 * Muat setelah event-bus.js dan logger.js, SEBELUM semua *.config.js. */
(function (root) {
  'use strict';

  var ASTRA = (root.ASTRA = root.ASTRA || {});
  if (ASTRA.Config) return;

  var defaults = {};
  var current = {};

  function isObj(v) { return v !== null && typeof v === 'object' && !Array.isArray(v); }
  function clone(v) { return v === undefined ? v : JSON.parse(JSON.stringify(v)); }

  function deepFreeze(o) {
    if (o && typeof o === 'object' && !Object.isFrozen(o)) {
      Object.freeze(o);
      Object.keys(o).forEach(function (k) { deepFreeze(o[k]); });
    }
    return o;
  }

  function getPath(obj, path) {
    var parts = String(path).split('.');
    var cur = obj;
    for (var i = 0; i < parts.length; i++) {
      if (cur === null || cur === undefined) return undefined;
      cur = cur[parts[i]];
    }
    return cur;
  }

  // Aturan validasi terhadap default:
  // - kunci harus sudah ada di default
  // - tipe harus sama (angka harus valid, bukan NaN/Infinity)
  // - default null = bebas tipe; array/object kosong = bebas isi
  function validate(def, patch, path, errors) {
    Object.keys(patch).forEach(function (k) {
      var p = path ? path + '.' + k : k;
      if (!Object.prototype.hasOwnProperty.call(def, k)) {
        errors.push('Kunci tidak dikenal: ' + p);
        return;
      }
      var d = def[k], v = patch[k];
      if (d === null || d === undefined) return;
      if (Array.isArray(d)) {
        if (!Array.isArray(v)) errors.push(p + ' harus array');
        return;
      }
      if (isObj(d)) {
        if (!isObj(v)) { errors.push(p + ' harus object'); return; }
        if (Object.keys(d).length) validate(d, v, p, errors);
        return;
      }
      if (typeof d === 'number') {
        if (typeof v !== 'number' || !isFinite(v)) errors.push(p + ' harus angka valid');
        return;
      }
      if (typeof v !== typeof d) errors.push(p + ' harus bertipe ' + typeof d);
    });
  }

  function merge(base, patch) {
    var out = clone(base);
    Object.keys(patch).forEach(function (k) {
      if (isObj(out[k]) && isObj(patch[k]) && Object.keys(out[k]).length) {
        out[k] = merge(out[k], patch[k]);
      } else {
        out[k] = clone(patch[k]);
      }
    });
    return out;
  }

  function emit(evt, payload) {
    if (ASTRA.EventBus) ASTRA.EventBus.emit(evt, payload);
  }

  function register(name, def) {
    if (typeof name !== 'string' || !name) {
      throw new TypeError('Config.register: nama harus string tidak kosong');
    }
    if (!isObj(def)) {
      throw new TypeError('Config.register: default "' + name + '" harus object');
    }
    if (defaults[name]) throw new Error('Config "' + name + '" sudah terdaftar');
    defaults[name] = deepFreeze(clone(def));
    current[name] = defaults[name];
    return current[name];
  }

  // get('risk') atau get('risk.maxDailyLossPct'); fallback dipakai jika undefined.
  function get(path, fallback) {
    var v = getPath(current, path);
    return v === undefined ? fallback : v;
  }

  // Mengembalikan { ok, errors }. Tidak melempar error; semua-atau-tidak sama sekali.
  function override(name, patch) {
    if (!current[name]) return { ok: false, errors: ['Config "' + name + '" belum terdaftar'] };
    if (!isObj(patch)) return { ok: false, errors: ['Patch harus object'] };
    var errors = [];
    validate(defaults[name], patch, '', errors);
    if (errors.length) return { ok: false, errors: errors };
    current[name] = deepFreeze(merge(current[name], patch));
    emit('config:changed', { name: name, patch: clone(patch) });
    return { ok: true, errors: [] };
  }

  function reset(name) {
    if (!defaults[name]) return false;
    current[name] = defaults[name];
    emit('config:reset', { name: name });
    return true;
  }

  function list() { return Object.keys(defaults); }
  function snapshot() { return clone(current); }

  ASTRA.Config = {
    register: register, get: get, override: override,
    reset: reset, list: list, snapshot: snapshot
  };
})(typeof window !== 'undefined' ? window : globalThis);