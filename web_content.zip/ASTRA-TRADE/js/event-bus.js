/* ASTRA TRADE V1 — js/event-bus.js
 * Pub/sub ringan untuk komunikasi antar-modul.
 * Error di satu handler tidak menghentikan handler lain.
 * Muat PERTAMA, sebelum file js lainnya. */
(function (root) {
  'use strict';

  var ASTRA = (root.ASTRA = root.ASTRA || {});
  if (ASTRA.EventBus) return; // jaga-jaga kalau file termuat dua kali

  var handlers = {}; // namaEvent -> [{ fn, once }]

  function on(evt, fn, opts) {
    if (typeof evt !== 'string' || !evt) {
      throw new TypeError('EventBus.on: nama event harus string tidak kosong');
    }
    if (typeof fn !== 'function') {
      throw new TypeError('EventBus.on: handler harus function');
    }
    (handlers[evt] = handlers[evt] || []).push({ fn: fn, once: !!(opts && opts.once) });
    return function unsubscribe() { off(evt, fn); };
  }

  function once(evt, fn) {
    return on(evt, fn, { once: true });
  }

  function off(evt, fn) {
    var list = handlers[evt];
    if (!list) return;
    if (!fn) { delete handlers[evt]; return; } // tanpa handler: lepas semua
    var rest = list.filter(function (h) { return h.fn !== fn; });
    if (rest.length) handlers[evt] = rest;
    else delete handlers[evt];
  }

  // Mengembalikan jumlah handler yang berhasil dipanggil.
  function emit(evt, data) {
    var list = handlers[evt];
    if (!list || !list.length) return 0;

    var snapshot = list.slice(); // salin supaya aman kalau daftar berubah saat emit
    var called = 0;

    snapshot.forEach(function (h) {
      if (h.once) off(evt, h.fn);
      try {
        h.fn(data, evt);
        called++;
      } catch (err) {
        // Logger belum ada di langkah ini; cukup console.
        if (typeof console !== 'undefined') {
          console.error('[EventBus] error pada handler "' + evt + '":', err);
        }
      }
    });
    return called;
  }

  function clear() { handlers = {}; }

  ASTRA.EventBus = { on: on, once: once, off: off, emit: emit, clear: clear };
})(typeof window !== 'undefined' ? window : globalThis);