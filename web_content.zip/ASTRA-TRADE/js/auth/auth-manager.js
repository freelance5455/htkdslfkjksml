/* ASTRA TRADE — klien autentikasi.
 * Kredensial diverifikasi OLEH SERVER (server/server.js). Klien tidak pernah memutuskan login sendiri,
 * tidak menyimpan password/token, dan tidak menyimpan sesi di localStorage; sesi = cookie HttpOnly dari server.
 * Bila server tidak terjangkau, status = NOT_CONNECTED dan login ditolak (tidak ada login lokal palsu).
 * "Mode lokal" hanya masuk sebagai tamu tanpa akun: bukan login, tidak diverifikasi siapa pun. */
(function (root) {
  'use strict';
  var A = root.ASTRA = root.ASTRA || {};
  var session = null;      // { name, email, verified, mode: 'account' | 'local-guest' }
  var backend = { state: 'UNKNOWN', requireVerification: true, mail: 'NOT_CONNECTED', checkedAt: 0 };
  var EMAIL_RE = /^[^\s@]{1,64}@[^\s@]{1,190}\.[^\s@]{2,}$/;
  var NOT_CONNECTED_MSG = 'NOT CONNECTED: server autentikasi ASTRA tidak terjangkau. Jalankan "node server/server.js" lalu buka aplikasi lewat alamat server itu. Login tidak dapat diverifikasi tanpa server.';

  function log(level, msg, meta) { if (A.Logger && A.Logger[level]) A.Logger[level]('auth', msg, meta); }

  function request(method, url, body) {
    var ctrl = typeof AbortController === 'function' ? new AbortController() : null;
    var timer = ctrl ? root.setTimeout(function () { ctrl.abort(); }, 8000) : null;
    var opts = { method: method, credentials: 'same-origin', cache: 'no-store', headers: {}, signal: ctrl ? ctrl.signal : undefined };
    if (body !== undefined) { opts.headers['Content-Type'] = 'application/json'; opts.body = JSON.stringify(body); }
    return root.fetch(url, opts).then(function (res) {
      return res.text().then(function (text) {
        var json = null;
        try { json = JSON.parse(text); } catch (e) { /* bukan server ASTRA (mis. hosting statis mengembalikan HTML) */ }
        return { status: res.status, json: json };
      });
    }).then(function (r) { if (timer) root.clearTimeout(timer); return r; },
            function (e) { if (timer) root.clearTimeout(timer); throw e; });
  }

  function notConnected() {
    backend.state = 'NOT_CONNECTED'; backend.checkedAt = Date.now();
    return { ok: false, code: 'NOT_CONNECTED', message: NOT_CONNECTED_MSG };
  }

  /* Panggilan API: respons non-JSON atau galat jaringan => NOT_CONNECTED, bukan sukses. */
  function call(method, path, body) {
    return request(method, '/api/auth/' + path, body).then(function (r) {
      if (!r.json || typeof r.json.ok !== 'boolean') return notConnected();
      backend.state = 'CONNECTED';
      return Object.assign({ httpStatus: r.status }, r.json);
    }, function () { return notConnected(); });
  }

  function probe() {
    return call('GET', 'status').then(function (r) {
      if (r.ok && r.service === 'astra-auth') {
        backend.state = 'CONNECTED'; backend.requireVerification = !!r.requireVerification; backend.mail = r.mail; backend.checkedAt = Date.now();
      } else if (r.code !== 'NOT_CONNECTED') { backend.state = 'NOT_CONNECTED'; }
      return Object.assign({}, backend);
    });
  }

  /* Pulihkan sesi dari cookie server (bila ada). */
  function restore() {
    return call('GET', 'me').then(function (r) {
      if (r.ok && r.authenticated && r.user) { session = { name: r.user.name, email: r.user.email, verified: r.user.verified, mode: 'account' }; return session; }
      return null;
    });
  }

  function badEmail(email) { return !EMAIL_RE.test(email) ? { ok: false, field: 'email', message: email ? 'Format email tidak valid.' : 'Email wajib diisi.' } : null; }
  function pwProblem(pw) {
    if (!pw || pw.length < 8) return 'Password minimal 8 karakter.';
    if (pw.length > 128) return 'Password maksimal 128 karakter.';
    if (!/[A-Za-z]/.test(pw) || !/[0-9]/.test(pw)) return 'Password harus mengandung huruf dan angka.';
    return null;
  }
  function norm(email) { return String(email || '').trim().toLowerCase(); }

  A.Auth = {
    /* true hanya bila server benar-benar menjawab. */
    backend: function () { return Object.assign({}, backend); },
    probe: probe,
    restore: restore,

    login: function (email, password) {
      email = norm(email); password = String(password || '');
      var e = badEmail(email); if (e) return Promise.resolve(e);
      if (!password) return Promise.resolve({ ok: false, field: 'password', message: 'Password wajib diisi.' });
      return call('POST', 'login', { email: email, password: password }).then(function (r) {
        if (r.ok && r.user) { session = { name: r.user.name, email: r.user.email, verified: r.user.verified, mode: 'account' }; log('info', 'Login berhasil'); return { ok: true, profile: session }; }
        log('warn', 'Login ditolak', { code: r.code });
        return r;
      });
    },

    register: function (email, password, confirm, name) {
      email = norm(email); password = String(password || '');
      var e = badEmail(email); if (e) return Promise.resolve(e);
      var p = pwProblem(password); if (p) return Promise.resolve({ ok: false, field: 'password', message: p });
      if (password !== String(confirm || '')) return Promise.resolve({ ok: false, field: 'confirm', message: 'Konfirmasi password tidak sama.' });
      var display = String(name || '').trim() || email.split('@')[0];
      if (display.length < 2 || display.length > 50 || /[<>]/.test(display)) return Promise.resolve({ ok: false, field: 'name', message: 'Nama tampilan harus 2–50 karakter tanpa < atau >.' });
      return call('POST', 'register', { email: email, password: password, name: display });
    },

    forgot: function (email) {
      email = norm(email);
      var e = badEmail(email); if (e) return Promise.resolve(e);
      return call('POST', 'forgot', { email: email });
    },

    reset: function (token, password, confirm) {
      password = String(password || '');
      var p = pwProblem(password); if (p) return Promise.resolve({ ok: false, field: 'password', message: p });
      if (password !== String(confirm || '')) return Promise.resolve({ ok: false, field: 'confirm', message: 'Konfirmasi password tidak sama.' });
      if (!token) return Promise.resolve({ ok: false, message: 'Token reset tidak ada. Buka tautan dari email pemulihan.' });
      return call('POST', 'reset', { token: token, password: password });
    },

    resendVerification: function (email) { return call('POST', 'resend-verification', { email: norm(email) }); },

    /* Tamu lokal: BUKAN login. Tidak ada akun, tidak ada verifikasi. */
    continueLocal: function () { session = { name: 'Tamu lokal', email: null, verified: false, mode: 'local-guest' }; log('info', 'Masuk mode lokal tanpa akun'); return session; },

    signOut: function () {
      var was = session; session = null;
      if (was && was.mode === 'account') return call('POST', 'logout', {}).then(function (r) { log('info', 'Logout', { serverAck: !!r.ok }); return { ok: !!r.ok, serverAck: !!r.ok }; });
      return Promise.resolve({ ok: true, serverAck: false });
    },

    current: function () { return session; },
    isSignedIn: function () { return !!session; },
    isAccount: function () { return !!session && session.mode === 'account'; }
  };
})(window);
