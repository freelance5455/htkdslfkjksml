(function (root) {
  'use strict';
  var A = root.ASTRA = root.ASTRA || {};
  function mean(values) { return values.length ? values.reduce(function (sum, value) { return sum + value; }, 0) / values.length : null; }
  function ema(values, period) {
    if (!Array.isArray(values) || values.length < period) return null;
    var k = 2 / (period + 1), value = mean(values.slice(0, period));
    for (var i = period; i < values.length; i++) value = values[i] * k + value * (1 - k);
    return value;
  }
  function rsi(values, period) {
    period = period || 14;
    if (!Array.isArray(values) || values.length < period + 1) return null;
    var gains = 0, losses = 0;
    for (var i = 1; i <= period; i++) {
      var initial = values[i] - values[i - 1];
      if (initial > 0) gains += initial; else losses -= initial;
    }
    var avgGain = gains / period, avgLoss = losses / period;
    for (var j = period + 1; j < values.length; j++) {
      var delta = values[j] - values[j - 1];
      avgGain = (avgGain * (period - 1) + Math.max(delta, 0)) / period;
      avgLoss = (avgLoss * (period - 1) + Math.max(-delta, 0)) / period;
    }
    if (avgLoss === 0) return avgGain === 0 ? 50 : 100;
    var rs = avgGain / avgLoss;
    return 100 - (100 / (1 + rs));
  }
  function percentChange(values) {
    if (!Array.isArray(values) || values.length < 2 || !Number.isFinite(values[0]) || values[0] === 0) return null;
    return (values[values.length - 1] / values[0] - 1) * 100;
  }
  function momentum(values, periods) {
    periods = periods || 5;
    if (!Array.isArray(values) || values.length <= periods) return null;
    var start = values[values.length - 1 - periods], end = values[values.length - 1];
    return Number.isFinite(start) && start !== 0 && Number.isFinite(end) ? (end / start - 1) * 100 : null;
  }
  function returnVolatility(values, periods) {
    periods = periods || 20;
    if (!Array.isArray(values) || values.length < 3) return null;
    var returns = [], start = Math.max(1, values.length - periods);
    for (var i = start; i < values.length; i++) {
      if (Number.isFinite(values[i]) && Number.isFinite(values[i - 1]) && values[i - 1] !== 0) returns.push((values[i] / values[i - 1] - 1) * 100);
    }
    if (returns.length < 2) return null;
    var avg = mean(returns), variance = returns.reduce(function (sum, value) { return sum + Math.pow(value - avg, 2); }, 0) / (returns.length - 1);
    return Math.sqrt(variance);
  }
  function rangePct(values, periods) {
    if (!Array.isArray(values) || values.length < 2) return null;
    var sample = values.slice(-Math.max(2, periods || 22));
    var lo = Math.min.apply(null, sample), hi = Math.max.apply(null, sample), avg = mean(sample);
    return avg > 0 ? (hi - lo) / avg * 100 : null;
  }
  A.Indicators = {
    mean: mean, ema: ema, rsi: rsi, percentChange: percentChange, momentum: momentum,
    returnVolatility: returnVolatility, rangePct: rangePct,
    analyze: function (values) {
      values = Array.isArray(values) ? values.filter(function (value) { return Number.isFinite(value) && value > 0; }) : [];
      return {
        sampleCount: values.length,
        ema9: ema(values, 9),
        ema21: ema(values, 21),
        rsi14: rsi(values, 14),
        changePct: percentChange(values),
        momentum5: momentum(values, 5),
        volatilityPct: returnVolatility(values, 20),
        rangePct: rangePct(values, 22)
      };
    }
  };
})(window);
