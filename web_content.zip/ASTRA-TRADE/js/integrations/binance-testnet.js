/* ASTRA TRADE — konektor Binance SPOT TESTNET (uang virtual).
 * Hanya host testnet.binance.vision. API key/secret hanya di memori halaman (tidak disimpan, tidak di log).
 * Status CONNECTED baru muncul setelah Binance membalas /api/v3/account dengan benar. */
(function (root) {
  'use strict';
  var A = root.ASTRA = root.ASTRA || {};
  var BASE = 'https://testnet.binance.vision';
  var key = null, secret = null, offset = 0, connectedAt = null, account = null;

  function hex(buf) { return Array.prototype.map.call(new Uint8Array(buf), function (b) { return ('0' + b.toString(16)).slice(-2); }).join(''); }
  function sign(sec, payload) {
    var enc = new TextEncoder();
    return root.crypto.subtle.importKey('raw', enc.encode(sec), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign'])
      .then(function (k) { return root.crypto.subtle.sign('HMAC', k, enc.encode(payload)); }).then(hex);
  }
  function qs(p) { return Object.keys(p).map(function (k) { return k + '=' + encodeURIComponent(p[k]); }).join('&'); }
  function fail(code, msg) { var e = new Error(msg); e.code = code; e.provider = 'binance-testnet'; return e; }

  function request(method, path, params, signed) {
    if (typeof root.fetch !== 'function') return Promise.reject(fail('NO_FETCH', 'Browser tidak mendukung fetch.'));
    params = Object.assign({}, params || {});
    var headers = { Accept: 'application/json' };
    var ready = Promise.resolve();
    var query = '';
    if (signed) {
      if (!key || !secret) return Promise.reject(fail('NOT_CONNECTED', 'API key testnet belum dimasukkan.'));
      params.timestamp = Date.now() + offset; params.recvWindow = 5000;
      query = qs(params); headers['X-MBX-APIKEY'] = key;
      ready = sign(secret, query).then(function (sig) { query += '&signature=' + sig; });
    } else query = qs(params);
    return ready.then(function () {
      var ctrl = typeof root.AbortController === 'function' ? new root.AbortController() : null;
      var t = ctrl ? root.setTimeout(function () { ctrl.abort(); }, 10000) : null;
      return root.fetch(BASE + path + (query ? '?' + query : ''), { method: method, headers: headers, cache: 'no-store', signal: ctrl ? ctrl.signal : undefined })
        .then(function (res) { if (t) root.clearTimeout(t); return res.text().then(function (txt) { var j = null; try { j = JSON.parse(txt); } catch (e) { /* bukan JSON */ } return { ok: res.ok, status: res.status, json: j }; }); })
        .catch(function (e) { if (t) root.clearTimeout(t); throw fail('NETWORK', 'Tidak bisa menjangkau testnet Binance: ' + (e && e.message || 'error') + '. Bisa karena jaringan atau pembatasan CORS.'); });
    }).then(function (r) {
      if (!r.ok || !r.json || (r.json.code && r.json.code < 0)) throw fail('BINANCE_' + (r.json && r.json.code || r.status), 'Binance menolak: ' + (r.json && r.json.msg || 'HTTP ' + r.status));
      return r.json;
    });
  }

  function wipe() { key = null; secret = null; connectedAt = null; account = null; }

  function connect(apiKey, apiSecret) {
    apiKey = String(apiKey || '').trim(); apiSecret = String(apiSecret || '').trim();
    if (apiKey.length < 16 || apiSecret.length < 16) return Promise.reject(fail('BAD_CREDENTIALS', 'API key/secret terlalu pendek. Gunakan key HMAC dari testnet.binance.vision.'));
    wipe(); key = apiKey; secret = apiSecret;
    return request('GET', '/api/v3/time', {}, false).then(function (t) { offset = Number(t.serverTime) - Date.now(); })
      .then(function () { return account_(); })
      .catch(function (e) { wipe(); throw e; });
  }
  function account_() {
    return request('GET', '/api/v3/account', {}, true).then(function (a) {
      if (!a || !Array.isArray(a.balances)) throw fail('BAD_RESPONSE', 'Balasan akun tidak valid.');
      account = {
        accountType: a.accountType, canTrade: !!a.canTrade, fetchedAt: Date.now(),
        balances: a.balances.map(function (b) { return { asset: b.asset, free: Number(b.free), locked: Number(b.locked) }; }).filter(function (b) { return b.free > 0 || b.locked > 0; })
      };
      if (!connectedAt) connectedAt = Date.now();
      return account;
    });
  }
  function status() {
    return { provider: 'Binance Spot Testnet', environment: 'TESTNET', realMoney: false, host: BASE,
      state: account ? 'CONNECTED_TESTNET' : 'NOT_CONNECTED', connectedAt: connectedAt, canTrade: account ? account.canTrade : null };
  }
  A.BinanceTestnet = { connect: connect, refresh: account_, disconnect: function () { wipe(); return { ok: true, state: 'NOT_CONNECTED' }; },
    status: status, account: function () { return account ? JSON.parse(JSON.stringify(account)) : null; }, _sign: sign, _request: request, baseUrl: BASE };
})(window);