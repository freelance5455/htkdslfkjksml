/* ASTRA TRADE — provenance kuotasi.
 * Memisahkan tiga hal yang TIDAK boleh tertukar:
 *   BINANCE_SPOT   = harga spot crypto publik Binance (pembanding; bukan harga transaksi Olymptrade)
 *   ECB_REFERENCE  = kurs referensi harian ECB/Frankfurter (bukan kuotasi Forex real-time)
 *   OLYMPTRADE     = kuotasi broker; BELUM tersedia/terverifikasi, selalu UNAVAILABLE
 * isBrokerQuote selalu false selama feed resmi broker belum terbukti ada.
 */
(function (root) {
  'use strict';
  var A = root.ASTRA = root.ASTRA || {};
  var STALE_MS = 45000;

  function assetClass(symbol) {
    return A.TransactionTypes ? A.TransactionTypes.assetClass(symbol) : 'unknown';
  }
  function brokerCapability() {
    var caps = A.OlympTradeAdapter && A.OlympTradeAdapter.capabilities ? A.OlympTradeAdapter.capabilities() : null;
    return caps && caps.publicMarketData ? caps.publicMarketData : 'UNVERIFIED';
  }

  /* Deskripsi kuotasi terkini untuk simbol: provider, tipe pasar, timestamp, freshness. */
  function describe(symbol, now) {
    var sym = String(symbol || '').toUpperCase();
    var cls = assetClass(sym);
    var t = Number(now) || Date.now();
    var base = {
      symbol: sym, assetClass: cls, isBrokerQuote: false, brokerQuoteStatus: brokerCapability(),
      timestamp: null, ageMs: null, price: null, usableForBrokerExecution: false
    };
    if (cls === 'crypto-spot') {
      var q = A.MarketData && A.MarketData.get ? A.MarketData.get(sym) : null;
      if (!q || !Number.isFinite(q.price)) {
        var hasCandles = A.MarketData && A.MarketData.getCandles && A.MarketData.getCandles(sym, '1m').length > 0;
        return Object.assign(base, { providerId: 'BINANCE_SPOT', provider: 'Binance public spot data', marketType: 'spot',
          status: hasCandles ? 'HISTORICAL_ONLY' : 'UNAVAILABLE', freshness: hasCandles ? 'STALE' : 'UNAVAILABLE' });
      }
      var ts = Number(q.updatedAt) || null;
      var age = ts ? Math.max(0, t - ts) : null;
      var stale = !!q.stale || (age !== null && age > STALE_MS);
      return Object.assign(base, { providerId: 'BINANCE_SPOT', provider: 'Binance public spot data', marketType: 'spot',
        price: q.price, timestamp: ts, ageMs: age, status: stale ? 'STALE' : 'FRESH', freshness: stale ? 'STALE' : 'FRESH' });
    }
    if (cls === 'forex') {
      var row = A.ForexReference && A.ForexReference.get ? A.ForexReference.get(sym) : null;
      if (!row || !Number.isFinite(row.price)) {
        return Object.assign(base, { providerId: 'ECB_REFERENCE', provider: 'Frankfurter / ECB reference rates', marketType: 'reference-daily',
          status: 'UNAVAILABLE', freshness: 'UNAVAILABLE' });
      }
      return Object.assign(base, { providerId: 'ECB_REFERENCE', provider: 'Frankfurter / ECB reference rates', marketType: 'reference-daily',
        price: row.price, timestamp: Number(row.updatedAt) || null, ageMs: row.updatedAt ? Math.max(0, t - Number(row.updatedAt)) : null,
        rateDate: row.rateDate || null, status: 'REFERENCE_RATE', freshness: 'DAILY_REFERENCE' });
    }
    return Object.assign(base, { providerId: 'NONE', provider: 'Tidak ada sumber', marketType: 'unavailable',
      status: 'UNAVAILABLE', freshness: 'UNAVAILABLE' });
  }

  /* Kuotasi broker Olymptrade: tidak pernah tersedia pada build ini. */
  function brokerQuote(symbol) {
    var status = brokerCapability();
    return {
      available: false, provider: 'OLYMPTRADE', providerId: 'OLYMPTRADE', symbol: String(symbol || '').toUpperCase(),
      status: status === 'VERIFIED' ? 'NOT_IMPLEMENTED' : status,
      reason: 'Feed kuotasi resmi Olymptrade belum terverifikasi/diimplementasikan. Harga Binance/ECB tidak dipakai sebagai pengganti.'
    };
  }

  A.QuoteSources = { describe: describe, brokerQuote: brokerQuote, staleMs: STALE_MS, assetClass: assetClass };
})(window);
