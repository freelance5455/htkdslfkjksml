/* ASTRA TRADE V1 — daily reference FX rates. This is NOT a streaming broker quote feed. */
(function (root) {
  'use strict';
  var A = root.ASTRA = root.ASTRA || {};
  var PAIRS = [
    { symbol: 'EURUSD', base: 'EUR', quote: 'USD', name: 'Euro / US Dollar', invert: true },
    { symbol: 'GBPUSD', base: 'GBP', quote: 'USD', name: 'British Pound / US Dollar', invert: true },
    { symbol: 'USDJPY', base: 'USD', quote: 'JPY', name: 'US Dollar / Japanese Yen', invert: false },
    { symbol: 'USDCHF', base: 'USD', quote: 'CHF', name: 'US Dollar / Swiss Franc', invert: false },
    { symbol: 'USDCAD', base: 'USD', quote: 'CAD', name: 'US Dollar / Canadian Dollar', invert: false },
    { symbol: 'AUDUSD', base: 'AUD', quote: 'USD', name: 'Australian Dollar / US Dollar', invert: true },
    { symbol: 'NZDUSD', base: 'NZD', quote: 'USD', name: 'New Zealand Dollar / US Dollar', invert: true }
  ];
  var rows = Object.create(null), lastUpdate = null, rateDate = null, error = null, request = null;
  function getAll() { return PAIRS.map(function (p) { return Object.assign({}, p, rows[p.symbol] || { price: null, source: null, rateDate: null, status: 'UNAVAILABLE' }); }); }
  function refresh() {
    if (request) return request;
    request = root.fetch('https://api.frankfurter.app/latest?from=USD&to=EUR,GBP,JPY,CHF,CAD,AUD,NZD', { method: 'GET', cache: 'no-store', headers: { Accept: 'application/json' } })
      .then(function (res) { if (!res || !res.ok) throw new Error('HTTP ' + (res ? res.status : 'unknown')); return res.json(); })
      .then(function (data) {
        if (!data || !data.rates || !data.date) throw new Error('Format kurs referensi tidak valid.');
        PAIRS.forEach(function (p) {
          var raw = p.quote === 'USD' ? data.rates[p.base] : data.rates[p.quote];
          var price = Number(raw);
          if (!Number.isFinite(price) || price <= 0) { rows[p.symbol] = { price: null, source: null, rateDate: data.date, status: 'UNAVAILABLE' }; return; }
          if (p.invert) price = 1 / price;
          rows[p.symbol] = { price: price, source: 'Frankfurter / ECB reference rates', rateDate: data.date, updatedAt: Date.now(), status: 'REFERENCE RATE' };
        });
        rateDate = data.date; lastUpdate = Date.now(); error = null;
        if (A.EventBus) A.EventBus.emit('forex:reference-update', { pairs: getAll(), rateDate: rateDate, updatedAt: lastUpdate, status: 'REFERENCE RATE' });
        return getAll();
      }).catch(function (e) { error = e && e.message || 'Kurs referensi tidak tersedia'; if (A.EventBus) A.EventBus.emit('forex:reference-error', { error: error }); throw e; })
      .finally(function () { request = null; });
    return request;
  }
  A.ForexReference = { pairs: PAIRS.map(function (p) { return Object.assign({}, p); }), getAll: getAll, get: function (symbol) { var row = getAll().filter(function (p) { return p.symbol === String(symbol || '').toUpperCase(); })[0]; return row || null; }, refresh: refresh, status: function () { return { rateDate: rateDate, lastUpdate: lastUpdate, error: error, status: lastUpdate ? 'REFERENCE RATE' : error ? 'DISCONNECTED' : 'UNAVAILABLE' }; } };
})(window);
