(function (root) {
  'use strict';
  var A = root.ASTRA = root.ASTRA || {};
  function olymptradeStatus() {
    return A.OlympTradeAdapter ? A.OlympTradeAdapter.status() : {
      provider: 'Olymptrade', connectionState: 'NOT_CONNECTED', integrationState: 'UNVERIFIED',
      execution: 'NOT_AVAILABLE', reason: 'Adapter Olymptrade belum dimuat.'
    };
  }
  A.Integrations = {
    list: function () {
      return [
        { id: 'public-market', label: 'Binance public market data', available: true, mode: 'read-only', connectionState: 'provider-dependent' },
        { id: 'olymptrade', label: 'Olymptrade', available: false, mode: 'unverified', status: olymptradeStatus() },
        { id: 'private-account', label: 'Private account data', available: false, mode: 'not-connected' },
        { id: 'order-execution', label: 'Broker order execution', available: false, mode: 'not-available' }
      ];
    },
    status: function (id) {
      if (id === 'olymptrade') return olymptradeStatus();
      var entry = this.list().find(function (item) { return item.id === id; });
      return entry || { id: id, available: false, mode: 'unknown' };
    },
    connectPrivateAccount: function (provider) {
      if (provider && provider !== 'olymptrade') return Promise.reject(new Error('Provider tidak didukung.'));
      if (A.OlympTradeAdapter) return A.OlympTradeAdapter.connect();
      return Promise.reject(new Error('Koneksi akun privat belum tersedia.'));
    }
  };
})(window);
