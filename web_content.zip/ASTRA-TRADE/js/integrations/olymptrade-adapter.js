/*
 * Olymptrade capability gate.
 * No undocumented/private protocol, browser session, password, OTP or cookie is used.
 * The public official resources reviewed do not provide a verifiable third-party
 * developer API specification for private account reads or order execution.
 */
(function (root) {
  'use strict';
  var A = root.ASTRA = root.ASTRA || {};
  var official = {
    website: 'https://olymptrade.com/id-id/',
    robotHelp: 'https://plus.olymptrade.com/id/help/category/trading/can-i-use-robots-when-trading-on-the-platform',
    serviceAgreement: 'https://olymptrade.com/id-id/pages/about/legal/service-agreement-part-two/'
  };
  var capabilities = {
    broker: 'Olymptrade',
    publicDeveloperApi: 'UNVERIFIED',
    privateAccountRead: 'UNVERIFIED',
    positionsAndHistory: 'UNVERIFIED',
    officialAutomatedOrderExecution: 'UNVERIFIED',
    publicMarketData: 'UNVERIFIED',
    credentialConnection: 'NOT_AVAILABLE',
    liveExecution: 'NOT_AVAILABLE',
    reason: 'Belum ditemukan spesifikasi developer API publik resmi yang dapat diverifikasi untuk membaca akun privat atau mengirim transaksi pihak ketiga. Connector tidak menggunakan protokol privat yang tidak terdokumentasi.'
  };
  function makeError(code, message) {
    var error = new Error(message);
    error.code = code;
    error.provider = 'olymptrade';
    return error;
  }
  var adapter = {
    id: 'olymptrade',
    name: 'Olymptrade',
    available: false,
    status: function () {
      return {
        provider: 'Olymptrade',
        connectionState: 'NOT_CONNECTED',
        integrationState: 'UNVERIFIED',
        accountRead: 'UNVERIFIED',
        execution: 'NOT_AVAILABLE',
        checkedAt: null,
        reason: capabilities.reason,
        official: Object.assign({}, official)
      };
    },
    capabilities: function () { return JSON.parse(JSON.stringify(capabilities)); },
    connect: function () {
      return Promise.reject(makeError('OFFICIAL_API_UNVERIFIED', capabilities.reason));
    },
    getAccount: function () {
      return Promise.reject(makeError('ACCOUNT_READ_UNAVAILABLE', 'Pembacaan akun Olymptrade belum tersedia melalui adapter resmi yang terverifikasi.'));
    },
    placeOrder: function () {
      return Promise.reject(makeError('LIVE_EXECUTION_UNAVAILABLE', 'Eksekusi live Olymptrade tidak tersedia karena jalur API resmi belum terverifikasi. Tidak ada request yang dikirim.'));
    },
    closePosition: function () {
      return Promise.reject(makeError('LIVE_EXECUTION_UNAVAILABLE', 'Penutupan posisi otomatis belum tersedia melalui integrasi resmi yang terverifikasi.'));
    },
    disconnect: function () { return { ok: true, state: 'NOT_CONNECTED' }; },
    officialLinks: function () { return Object.assign({}, official); }
  };
  A.OlympTradeAdapter = adapter;
})(window);
