/* ASTRA TRADE V1 — public spot market data only. No credentials or order endpoints. */
(function (root) {
  'use strict';
  var A = root.ASTRA = root.ASTRA || {};
  var SYMBOLS = ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'BNBUSDT', 'XRPUSDT', 'DOGEUSDT', 'ADAUSDT', 'LTCUSDT'];
  var STALE_AFTER_MS = 45000;
  var REQUEST_TIMEOUT_MS = 12000;
  var snapshots = Object.create(null);
  var histories = Object.create(null);
  var candles = Object.create(null);
  var candleFetchedAt = Object.create(null);
  var candleRequests = Object.create(null);
  var socket = null;
  var retryTimer = null;
  var retryDelay = 1500;
  var stopped = true;
  var refreshTimer = null;
  var latency = null;
  var lastUpdate = null;
  var error = null;
  var listeners = [];
  var refreshPromise = null;

  function safeEmit(name, payload) {
    if (A.EventBus) A.EventBus.emit(name, payload);
  }
  function isStale(symbol, at) {
    var row = snapshots[String(symbol || '').toUpperCase()];
    if (!row || !row.updatedAt) return true;
    return (Number(at) || Date.now()) - row.updatedAt > STALE_AFTER_MS;
  }
  function publish() {
    var payload = { assets: getAll(), latencyMs: latency, lastUpdate: lastUpdate, error: error, staleAfterMs: STALE_AFTER_MS };
    safeEmit('market:update', payload);
    listeners.slice().forEach(function (fn) { try { fn(getAll()); } catch (e) { /* A subscriber must not break the feed. */ } });
  }
  function numberOrNull(value) {
    if (value === null || value === undefined || value === '') return null;
    var n = Number(value);
    return Number.isFinite(n) ? n : null;
  }
  function normalize(raw) {
    if (!raw || typeof raw !== 'object') return null;
    var price = numberOrNull(raw.c !== undefined ? raw.c : (raw.lastPrice !== undefined ? raw.lastPrice : raw.price));
    var symbol = String(raw.s || raw.symbol || '').toUpperCase();
    if (!price || price <= 0 || SYMBOLS.indexOf(symbol) < 0) return null;
    return {
      symbol: symbol,
      price: price,
      changePct: numberOrNull(raw.P !== undefined ? raw.P : raw.priceChangePercent),
      high: numberOrNull(raw.h !== undefined ? raw.h : raw.highPrice),
      low: numberOrNull(raw.l !== undefined ? raw.l : raw.lowPrice),
      volume: numberOrNull(raw.v !== undefined ? raw.v : raw.volume),
      quoteVolume: numberOrNull(raw.q !== undefined ? raw.q : raw.quoteVolume),
      updatedAt: Date.now(),
      source: 'Binance public spot ticker',
      marketType: 'spot',
      stale: false
    };
  }
  function accept(raw, quiet) {
    var row = normalize(raw);
    if (!row) return false;
    snapshots[row.symbol] = row;
    var h = histories[row.symbol] || (histories[row.symbol] = []);
    if (!h.length || h[h.length - 1] !== row.price) {
      h.push(row.price);
      if (h.length > 180) h.shift();
    }
    lastUpdate = row.updatedAt;
    error = null;
    if (!quiet) publish();
    return true;
  }
  function getAll() {
    return SYMBOLS.map(function (symbol) {
      var row = snapshots[symbol];
      return row ? Object.assign({}, row, { stale: isStale(symbol) }) : {
        symbol: symbol, price: null, changePct: null, high: null, low: null,
        volume: null, quoteVolume: null, updatedAt: null, source: null,
        marketType: 'spot', stale: true
      };
    });
  }
  function get(symbol) {
    var key = String(symbol || '').toUpperCase();
    var row = snapshots[key];
    return row ? Object.assign({}, row, { stale: isStale(key) }) : null;
  }
  function getCandles(symbol, interval) {
    return (candles[String(symbol || '').toUpperCase() + ':' + (interval || '1m')] || []).slice();
  }
  function history(symbol) {
    var key = String(symbol || '').toUpperCase();
    var historical = getCandles(key, '1m');
    var values = historical.length ? historical.map(function (c) { return c.close; }) : (histories[key] || []).slice();
    var current = snapshots[key];
    if (current && (!values.length || values[values.length - 1] !== current.price)) {
      values.push(current.price);
      if (values.length > 181) values.shift();
    }
    return values;
  }
  function chartHistory(symbol) {
    var key = String(symbol || '').toUpperCase();
    var historical = getCandles(key, '1m');
    if (historical.length) {
      var values = historical.map(function (c) { return c.close; });
      var quote = snapshots[key];
      if (quote && (!values.length || values[values.length - 1] !== quote.price)) values.push(quote.price);
      return { values: values, kind: 'historical-1m+quote', candles: historical };
    }
    return { values: history(key), kind: 'live-observations', candles: [] };
  }
  function requestJson(url, timeoutMs) {
    if (typeof root.fetch !== 'function') return Promise.reject(new Error('Fetch API tidak tersedia pada browser ini.'));
    var controller = typeof root.AbortController === 'function' ? new root.AbortController() : null;
    var timer = null;
    if (controller) timer = root.setTimeout(function () { controller.abort(); }, timeoutMs || REQUEST_TIMEOUT_MS);
    return root.fetch(url, {
      method: 'GET', cache: 'no-store', headers: { 'Accept': 'application/json' },
      signal: controller ? controller.signal : undefined
    }).then(function (response) {
      if (!response || !response.ok) throw new Error('HTTP ' + (response ? response.status : 'unknown'));
      return response.json();
    }).catch(function (e) {
      if (e && e.name === 'AbortError') throw new Error('Permintaan data melewati batas waktu.');
      throw e;
    }).finally(function () { if (timer !== null) root.clearTimeout(timer); });
  }
  function refresh() {
    if (refreshPromise) return refreshPromise;
    var startedAt = Date.now();
    var url = 'https://data-api.binance.vision/api/v3/ticker/24hr?symbols=' + encodeURIComponent(JSON.stringify(SYMBOLS));
    refreshPromise = requestJson(url, REQUEST_TIMEOUT_MS).then(function (rows) {
      if (!Array.isArray(rows) || !rows.length) throw new Error('Format respons ticker tidak dikenali atau kosong.');
      var count = 0;
      rows.forEach(function (row) { if (accept(row, true)) count++; });
      if (!count) throw new Error('Respons tidak memuat simbol pasar yang dikenali.');
      latency = Date.now() - startedAt;
      error = null;
      safeEmit('connection:status', { state: socket && socket.readyState === 1 ? 'live' : 'available', provider: 'Binance Public Spot Market Data', latencyMs: latency, lastUpdate: lastUpdate, error: null, marketType: 'spot' });
      publish();
      return getAll();
    }).catch(function (e) {
      error = e && e.message ? e.message : 'Feed publik tidak dapat diakses';
      safeEmit('connection:status', { state: 'error', provider: 'Binance Public Spot Market Data', latencyMs: latency, lastUpdate: lastUpdate, error: error, marketType: 'spot' });
      if (A.Logger) A.Logger.warn('market-data', 'Gagal memperbarui feed spot publik', { message: error });
      publish();
      throw e;
    }).finally(function () { refreshPromise = null; });
    return refreshPromise;
  }
  function fetchCandles(symbol, interval, limit, force) {
    var key = String(symbol || '').toUpperCase();
    var tf = String(interval || '1m');
    var n = Math.max(10, Math.min(500, Number(limit) || 100));
    if (SYMBOLS.indexOf(key) < 0) return Promise.reject(new Error('Simbol spot tidak didukung.'));
    if (!/^(1m|3m|5m|15m|30m|1h|2h|4h|6h|12h|1d|3d|1w|1M)$/.test(tf)) return Promise.reject(new Error('Interval candle tidak valid.'));
    var cacheKey = key + ':' + tf;
    var existing = candles[cacheKey];
    if (!force && existing && Date.now() - (candleFetchedAt[cacheKey] || 0) < 30000) return Promise.resolve(existing.slice());
    if (candleRequests[cacheKey]) return candleRequests[cacheKey];
    var url = 'https://data-api.binance.vision/api/v3/klines?symbol=' + encodeURIComponent(key) + '&interval=' + encodeURIComponent(tf) + '&limit=' + n;
    candleRequests[cacheKey] = requestJson(url, REQUEST_TIMEOUT_MS).then(function (rows) {
      if (!Array.isArray(rows)) throw new Error('Format respons candle tidak dikenali.');
      var normalized = rows.map(function (r) {
        if (!Array.isArray(r) || r.length < 7) return null;
        var open = Number(r[1]), high = Number(r[2]), low = Number(r[3]), close = Number(r[4]);
        if (![open, high, low, close].every(Number.isFinite) || close <= 0 || high < low) return null;
        return { openTime: Number(r[0]), open: open, high: high, low: low, close: close, volume: numberOrNull(r[5]), closeTime: Number(r[6]), trades: Number(r[8] || 0), interval: tf, symbol: key, source: 'Binance public spot klines', marketType: 'spot' };
      }).filter(Boolean);
      if (!normalized.length) throw new Error('Tidak ada candle valid yang diterima.');
      candles[cacheKey] = normalized;
      candleFetchedAt[cacheKey] = Date.now();
      safeEmit('market:candles', { symbol: key, interval: tf, count: normalized.length, fetchedAt: candleFetchedAt[cacheKey], source: 'Binance public spot klines' });
      publish();
      return normalized.slice();
    }).catch(function (e) {
      if (A.Logger) A.Logger.warn('market-candles', 'Gagal mengambil candle historis', { symbol: key, interval: tf, message: e && e.message || 'error' });
      throw e;
    }).finally(function () { delete candleRequests[cacheKey]; });
    return candleRequests[cacheKey];
  }
  function connectSocket() {
    if (stopped || !root.WebSocket) return;
    try {
      var streams = SYMBOLS.map(function (symbol) { return symbol.toLowerCase() + '@ticker'; }).join('/');
      socket = new root.WebSocket('wss://data-stream.binance.vision/stream?streams=' + streams);
      socket.onopen = function () {
        retryDelay = 1500;
        safeEmit('connection:status', { state: 'live', provider: 'Binance Public Spot WebSocket', latencyMs: latency, lastUpdate: lastUpdate, error: null, marketType: 'spot' });
      };
      socket.onmessage = function (event) {
        try {
          var payload = JSON.parse(event.data);
          if (payload && payload.data) accept(payload.data, false);
        } catch (e) { /* Ignore malformed frames; next valid update can recover. */ }
      };
      socket.onerror = function () {
        safeEmit('connection:status', { state: 'available', provider: 'Binance REST fallback', latencyMs: latency, lastUpdate: lastUpdate, error: 'WebSocket tidak tersedia; REST akan dicoba kembali.', marketType: 'spot' });
      };
      socket.onclose = function () {
        socket = null;
        if (!stopped) {
          if (retryTimer !== null) root.clearTimeout(retryTimer);
          retryTimer = root.setTimeout(connectSocket, retryDelay);
          retryDelay = Math.min(30000, retryDelay * 2);
        }
      };
    } catch (e) { socket = null; }
  }
  function start() {
    if (!stopped) return;
    stopped = false;
    refresh().catch(function () {});
    connectSocket();
    if (refreshTimer !== null) root.clearInterval(refreshTimer);
    refreshTimer = root.setInterval(function () { if (!stopped) refresh().catch(function () {}); }, 20000);
  }
  function stop() {
    stopped = true;
    if (socket) { socket.onclose = null; try { socket.close(); } catch (e) {} socket = null; }
    if (retryTimer !== null) root.clearTimeout(retryTimer);
    if (refreshTimer !== null) root.clearInterval(refreshTimer);
    retryTimer = null;
    refreshTimer = null;
  }
  function status() {
    var age = lastUpdate === null ? null : Math.max(0, Date.now() - lastUpdate);
    var hasData = lastUpdate !== null; var stale = hasData && age > STALE_AFTER_MS; return { latencyMs: latency, lastUpdate: lastUpdate, error: error, connected: !!(socket && socket.readyState === 1), state: socket && socket.readyState === 1 ? 'live' : error ? 'error' : hasData ? 'available' : 'connecting', dataAgeMs: age, hasData: hasData, dataStatus: !hasData ? (error ? 'DISCONNECTED' : 'UNAVAILABLE') : stale ? 'STALE' : 'LIVE DATA', stale: stale, staleAfterMs: STALE_AFTER_MS, marketType: 'spot' };
  }
  A.MarketData = {
    symbols: SYMBOLS.slice(), start: start, stop: stop, refresh: refresh, fetchCandles: fetchCandles,
    getCandles: getCandles, chartHistory: chartHistory, isStale: isStale,
    get: get, getAll: getAll, history: history,
    subscribe: function (fn) { if (typeof fn !== 'function') return function () {}; listeners.push(fn); return function () { listeners = listeners.filter(function (item) { return item !== fn; }); }; },
    status: status
  };
})(window);
