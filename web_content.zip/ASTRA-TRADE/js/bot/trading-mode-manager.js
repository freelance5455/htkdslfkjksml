/* Trading Mode is an analysis workflow preference only. This module grants no broker-order permission. */
(function(root){'use strict';var A=root.ASTRA=root.ASTRA||{};var modes=['manual','semi-auto','auto'];
function read(){var cfg=A.Storage?A.Storage.get('botConfig',{}):{};return cfg&&modes.indexOf(cfg.tradingMode)>=0?cfg.tradingMode:'manual';}
function describe(mode){if(mode==='semi-auto')return 'Pemindaian berkala; setiap tindakan lanjutan memerlukan konfirmasi pengguna.';if(mode==='auto')return 'Pemantauan dan pencatatan observasi otomatis; order broker tetap nonaktif.';return 'Kontrol analisis dilakukan pengguna; loop otomatis tidak berjalan.';}
A.TradingModeManager={current:read,available:function(){return modes.slice();},describe:describe,select:function(mode){if(modes.indexOf(mode)<0)return {ok:false,reason:'Trading Mode tidak dikenal.'};if(A.EventBus)A.EventBus.emit('trading-mode:changed',{mode:mode,description:describe(mode),executionEnabled:false});return {ok:true,mode:mode,executionEnabled:false,description:describe(mode)};},canExecuteOrder:function(){return false;}};
})(window);
