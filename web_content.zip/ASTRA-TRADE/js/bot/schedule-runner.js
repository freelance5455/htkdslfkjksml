/* ASTRA TRADE — scheduled observation only. It never starts an order or changes positions. */
(function (root) {
  'use strict';
  var A = root.ASTRA = root.ASTRA || {};
  var timer = null;
  var active = false;
  var CHECK_MS = 15000;

  function dayKey(date, time) {
    return date.getFullYear() + '-' + String(date.getMonth() + 1).padStart(2, '0') + '-' +
      String(date.getDate()).padStart(2, '0') + 'T' + time;
  }

  function check(at) {
    var schedule = A.BotSchedules ? A.BotSchedules.get() : null;
    if (!schedule || !schedule.enabled) return { triggered: false, reason: 'disabled' };
    if (A.BotController && A.BotController.isEmergency && A.BotController.isEmergency()) return { triggered: false, reason: 'emergency-stop' };
    var now = at instanceof Date ? at : new Date();
    var time = String(schedule.time || '');
    if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(time)) return { triggered: false, reason: 'invalid-time' };
    if (String(now.getHours()).padStart(2, '0') + ':' + String(now.getMinutes()).padStart(2, '0') !== time) {
      return { triggered: false, reason: 'not-due' };
    }
    var days = Array.isArray(schedule.days) ? schedule.days.map(Number) : [];
    if (days.indexOf(now.getDay()) < 0) return { triggered: false, reason: 'not-scheduled-day' };

    var key = dayKey(now, time);
    if (A.Storage.get('scheduleLastFired', '') === key) return { triggered: false, reason: 'already-fired' };
    if (!A.Storage.set('scheduleLastFired', key)) return { triggered: false, reason: 'storage-unavailable' };

    var symbol = A.Storage.get('selectedMarket', 'BTCUSDT');
    var scan = A.MarketScanner ? A.MarketScanner.scan(symbol) : null;
    var detail = { key: key, symbol: symbol, scan: scan, mode: 'scan-only', triggeredAt: now.getTime() };
    if (A.Logger) A.Logger.info('schedule', 'Jadwal pemantauan dijalankan; tidak ada order dikirim', { symbol: symbol, key: key });
    if (A.EventBus) A.EventBus.emit('schedule:trigger', detail);
    return { triggered: true, detail: detail };
  }

  function start() {
    if (active) return { ok: true, alreadyActive: true, mode: 'scan-only' };
    active = true;
    check(new Date());
    timer = root.setInterval(function () { check(new Date()); }, CHECK_MS);
    return { ok: true, mode: 'scan-only', intervalMs: CHECK_MS };
  }

  function stop() {
    if (timer !== null) root.clearInterval(timer);
    timer = null;
    active = false;
    return true;
  }

  A.ScheduleRunner = { start: start, stop: stop, check: check, active: function () { return active; } };
})(window);
