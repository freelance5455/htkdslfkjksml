/* ASTRA TRADE — mesin status bot (analisis-saja).
 * Status nyata: STOPPED -> RUNNING <-> PAUSED, dan EMERGENCY_STOP (terkunci sampai di-reset eksplisit).
 * Tombol di UI memanggil modul ini; mengubah status di sini benar-benar menghidupkan/mematikan RealtimeEngine.
 * Tidak ada eksekusi order: izin transaksi selalu ditolak (lihat RiskRules.canExecuteOrder). */
(function (root) {
  'use strict';
  var A = root.ASTRA = root.ASTRA || {};
  var S = { STOPPED: 'STOPPED', RUNNING: 'RUNNING', PAUSED: 'PAUSED', EMERGENCY: 'EMERGENCY_STOP' };
  var state = S.STOPPED, since = Date.now(), lastReason = 'Belum pernah dijalankan';

  function set(next, reason) {
    var prev = state; state = next; since = Date.now(); lastReason = reason || '';
    if (A.Logger) A.Logger.info('engine', 'Status ' + prev + ' -> ' + next + (reason ? ' (' + reason + ')' : ''));
    if (A.EventBus) A.EventBus.emit('engine:status', { running: next === S.RUNNING, state: next, prev: prev, reason: reason || '' });
  }
  function deny(reason) { return { ok: false, state: state, reason: reason }; }

  A.BotController = {
    STATES: S,
    start: function () {
      if (state === S.EMERGENCY) return deny('Emergency Stop aktif. Tekan Reset Emergency terlebih dahulu.');
      if (state === S.RUNNING) return { ok: true, state: state, mode: 'analysis-only', alreadyRunning: true };
      if (state === S.PAUSED) return this.resume();
      if (A.RealtimeEngine) A.RealtimeEngine.start();
      set(S.RUNNING, 'Start');
      return { ok: true, state: state, mode: 'analysis-only' };
    },
    pause: function () {
      if (state !== S.RUNNING) return deny('Pause hanya bisa saat mesin berjalan (status: ' + state + ').');
      if (A.RealtimeEngine) A.RealtimeEngine.stop();
      set(S.PAUSED, 'Pause');
      return { ok: true, state: state };
    },
    resume: function () {
      if (state !== S.PAUSED) return deny('Resume hanya bisa saat mesin di-pause (status: ' + state + ').');
      if (A.RealtimeEngine) A.RealtimeEngine.start();
      set(S.RUNNING, 'Resume');
      return { ok: true, state: state };
    },
    stop: function () {
      if (state === S.EMERGENCY) return deny('Emergency Stop aktif. Tekan Reset Emergency untuk melepas kunci.');
      if (A.RealtimeEngine) A.RealtimeEngine.stop();
      set(S.STOPPED, 'Stop');
      return { ok: true, state: state };
    },
    /* Menghentikan segalanya segera dan mengunci start sampai reset eksplisit. */
    emergencyStop: function () {
      if (A.RealtimeEngine) A.RealtimeEngine.stop();
      if (A.AutoTradeLoop) A.AutoTradeLoop.stop();
      set(S.EMERGENCY, 'Emergency Stop');
      return { ok: true, state: state };
    },
    resetEmergency: function () {
      if (state !== S.EMERGENCY) return deny('Tidak ada Emergency Stop yang aktif.');
      set(S.STOPPED, 'Reset Emergency');
      return { ok: true, state: state };
    },
    isRunning: function () { return state === S.RUNNING; },
    isPaused: function () { return state === S.PAUSED; },
    isEmergency: function () { return state === S.EMERGENCY; },
    /* Snapshot status untuk panel Control. Koneksi trading dan izin transaksi dilaporkan jujur. */
    status: function () {
      var perm = A.RiskRules ? A.RiskRules.canExecuteOrder() : { ok: false, reason: 'Tidak tersedia' };
      var strat = A.StrategyManager && A.Storage ? A.StrategyManager.get(A.Storage.get('strategy', 'technical-trend')) : null;
      return {
        state: state, since: since, reason: lastReason, mode: 'analysis-only',
        tradingConnection: 'NOT CONNECTED', orderPermission: perm.ok ? 'ALLOWED' : 'DENIED', orderPermissionReason: perm.reason,
        strategy: strat ? strat.name : 'Belum tersedia'
      };
    },
    placeOrder: function () { return Promise.reject(new Error(A.RiskRules.canExecuteOrder().reason)); }
  };
})(window);
