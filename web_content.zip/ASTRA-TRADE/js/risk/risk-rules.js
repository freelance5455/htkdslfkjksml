/* Read-only preflight checks. This module intentionally exposes no live-order permission. */
(function (root) {
  'use strict';
  var A = root.ASTRA = root.ASTRA || {};
  var MIN_AMOUNT = 15000;
  var MAX_AMOUNT = 1000000000;
  var ALLOWED_DURATIONS = [0.25, 1, 5];
  var ALLOWED_INTERVALS = [5, 15, 30];
  var ALLOWED_BOT_TIMER_MINUTES = [1, 3, 5, 10, 15, 30, 1440];
  function validMarket(symbol) {
    return !!(A.MarketData && A.MarketData.symbols && A.MarketData.symbols.indexOf(String(symbol || '').toUpperCase()) >= 0);
  }
  function validateConfig(config) {
    config = config || {};
    var errors = [];
    var amount = Number(config.amountIDR);
    if (!Number.isFinite(amount) || amount < MIN_AMOUNT || amount > MAX_AMOUNT) errors.push('Nominal harus antara Rp15.000 dan Rp1.000.000.000.');
    if (config.durationMinutes !== undefined && ALLOWED_DURATIONS.indexOf(Number(config.durationMinutes)) < 0) errors.push('Durasi analisis tidak valid.');
    if (config.timerSeconds !== undefined && ALLOWED_INTERVALS.indexOf(Number(config.timerSeconds)) < 0) errors.push('Interval pemindaian harus 5, 15, atau 30 detik.');
    if (config.botTimerMinutes !== undefined && ALLOWED_BOT_TIMER_MINUTES.indexOf(Number(config.botTimerMinutes)) < 0) errors.push('Durasi Bot Timer tidak valid.');
    if (config.market !== undefined && !validMarket(config.market)) errors.push('Simbol tidak termasuk daftar pasar spot publik yang didukung.');
    if (config.strategy !== undefined && A.StrategyManager && !A.StrategyManager.list().some(function (strategy) { return strategy.id === config.strategy; })) errors.push('Metode observasi tidak dikenal.');
    if (config.martingaleEnabled && ['K1', 'K2', 'K3', 'K4', 'K5'].indexOf(config.martingaleLevel) < 0) errors.push('Level Martingale simulasi tidak valid.');
    return { ok: errors.length === 0, errors: errors, mode: 'analysis-only' };
  }
  function preflightObservation(scan) {
    if (!scan || !scan.symbol) return { ok: false, reason: 'Observasi belum tersedia.' };
    if (!validMarket(scan.symbol)) return { ok: false, reason: 'Simbol bukan pasar spot publik yang didukung.' };
    if (scan.dataStatus === 'STALE') return { ok: false, reason: 'Data kuotasi sudah kedaluwarsa; tunggu data baru sebelum membaca observasi.' };
    if (scan.dataStatus === 'UNAVAILABLE') return { ok: false, reason: 'Data kuotasi publik belum tersedia.' };
    if (!scan.ready) return { ok: false, reason: 'Jumlah sampel belum cukup untuk analisis.' };
    return { ok: true, reason: 'Data memenuhi syarat untuk observasi teknikal, bukan transaksi.' };
  }
  function canExecuteOrder() {
    return { ok: false, reason: 'ORDER EXECUTION DISABLED: build ini hanya menyediakan data spot publik dan analisis edukatif. Tidak ada koneksi akun/order broker.' };
  }
  A.RiskRules = { validateConfig: validateConfig, preflightObservation: preflightObservation, canExecuteOrder: canExecuteOrder, constants: { minAmountIDR: MIN_AMOUNT, maxAmountIDR: MAX_AMOUNT, allowedDurations: ALLOWED_DURATIONS.slice(), allowedScanIntervals: ALLOWED_INTERVALS.slice(), allowedBotTimerMinutes: ALLOWED_BOT_TIMER_MINUTES.slice() } };
})(window);
