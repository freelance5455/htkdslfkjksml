/* ASTRA TRADE — Risk Engine (UMD: browser + Node/backend).
 *
 * Mengevaluasi sebuah entry intent terhadap batas risiko PENGGUNA (preferensi ASTRA) dan
 * kesiapan spesifikasi broker. Tidak mengarang minimum/maksimum, payout, spread, multiplier,
 * margin, expiry, fee, atau ukuran kontrak milik broker.
 *
 * mode:
 *   DRY_RUN / PAPER : boleh memakai ASUMSI pengguna (ditandai ESTIMATE). Tidak pernah menyentuh broker.
 *   LIVE            : seluruh atribut spesifikasi yang diwajibkan harus VERIFIED; selain itu BLOCKED.
 *
 * Hasil: { ok, mode, checks[], blockers[], estimate, evaluatedAt }
 */
(function (root, factory) {
  var api = factory(root);
  if (typeof module === 'object' && module.exports) module.exports = api;
  else { var A = root.ASTRA = root.ASTRA || {}; A.RiskEngine = api; }
})(typeof window !== 'undefined' ? window : globalThis, function (root) {
  'use strict';

  function TT() {
    if (typeof module === 'object' && module.exports && typeof require === 'function') {
      try { return require('../trading/transaction-types.js'); } catch (e) { /* fallthrough */ }
    }
    return root.ASTRA && root.ASTRA.TransactionTypes;
  }

  /* Batas risiko pengguna. Default konservatif milik ASTRA — bukan spesifikasi broker. */
  var DEFAULT_LIMITS = {
    maxTradeAmountIDR: 100000,
    maxOpenPositions: 1,
    maxTradesPerDay: 20,
    maxDailyLossIDR: 300000,
    cooldownSeconds: 60,
    maxDrawdownPct: 20,
    maxQuoteAgeMs: 45000
  };

  function num(v) { var n = Number(v); return isFinite(n) ? n : NaN; }
  function check(id, ok, reason, extra) { return Object.assign({ id: id, ok: !!ok, reason: ok ? 'OK' : reason }, extra || {}); }

  function limitsFrom(cfg) {
    var l = Object.assign({}, DEFAULT_LIMITS);
    if (cfg && typeof cfg === 'object') Object.keys(DEFAULT_LIMITS).forEach(function (k) {
      if (cfg[k] !== undefined && cfg[k] !== null && isFinite(Number(cfg[k])) && Number(cfg[k]) >= 0) l[k] = Number(cfg[k]);
    });
    return l;
  }

  /* Estimasi kerugian terburuk. Model berlabel ESTIMATE; null bila tidak dapat dihitung. */
  function worstCase(type, intent) {
    var amount = num(intent.amountIDR);
    if (!isFinite(amount) || amount <= 0) return { computable: false, reason: 'Nominal tidak valid.' };
    if (type === 'FLEX' || type === 'INZONE') {
      return { computable: true, lossIDR: amount, basis: 'ESTIMATE_STAKE_AT_RISK',
        note: 'Asumsi: rugi maksimum = nominal. Model kerugian broker belum terverifikasi.' };
    }
    // FOREX: perlu multiplier dan Stop Loss supaya rugi dapat dibatasi.
    var m = num(intent.multiplier), sl = num(intent.stopLossPct);
    if (!isFinite(m) || m <= 0) return { computable: false, reason: 'Multiplier tidak tersedia; risiko Forex tidak dapat dihitung.' };
    if (!isFinite(sl) || sl <= 0) return { computable: false, reason: 'Stop Loss tidak tersedia; risiko Forex tidak dapat dihitung.' };
    var raw = amount * m * (sl / 100);
    return { computable: true, lossIDR: Math.min(amount, raw), basis: 'ESTIMATE_MULTIPLIER_X_STOPLOSS_CAPPED_AT_MARGIN',
      note: 'Estimasi dari multiplier & SL asumsi pengguna; spread, biaya, margin call dan slippage broker belum terverifikasi.' };
  }

  function evaluate(intent, ctx, cfg) {
    intent = intent && typeof intent === 'object' ? intent : {};
    ctx = ctx && typeof ctx === 'object' ? ctx : {};
    var tt = TT();
    var mode = String(ctx.mode || 'DRY_RUN').toUpperCase();
    if (['DRY_RUN', 'PAPER', 'LIVE'].indexOf(mode) < 0) mode = 'LIVE'; // mode tak dikenal diperlakukan paling ketat
    var now = Number(ctx.now) || Date.now();
    var L = limitsFrom(cfg);
    var type = String(intent.transactionType || '').toUpperCase();
    var checks = [];

    // 1. Emergency Stop selalu menang.
    checks.push(check('emergency-stop', !ctx.emergencyStop, 'Emergency Stop aktif; semua entry baru diblokir.'));

    // 2. Jenis transaksi + field wajib per jenis.
    var typeOk = !!(tt && tt.isType(type));
    checks.push(check('transaction-type', typeOk, 'Jenis transaksi tidak dikenal atau kosong.'));
    if (typeOk) {
      var shape = [];
      if (type === 'FLEX' || type === 'FOREX') {
        if (['BUY', 'SELL'].indexOf(intent.direction) < 0) shape.push('arah BUY/SELL wajib untuk ' + type);
      }
      if (type === 'INZONE') {
        var lo = num(intent.zoneLower), hi = num(intent.zoneUpper);
        if (!(lo > 0 && hi > lo)) shape.push('rentang InZone (bawah < atas) wajib');
        if (intent.direction) shape.push('InZone tidak memakai arah BUY/SELL');
        if (!(num(intent.expiryMinutes) > 0)) shape.push('waktu kedaluwarsa wajib');
      }
      if (type === 'FLEX' && !(num(intent.durationMinutes) > 0)) shape.push('durasi wajib untuk FLEX');
      checks.push(check('intent-shape', shape.length === 0, 'Intent tidak lengkap: ' + shape.join('; ') + '.'));
    }

    // 3. Nominal.
    var amount = num(intent.amountIDR);
    checks.push(check('amount-valid', isFinite(amount) && amount > 0, 'Nominal tidak valid.'));
    checks.push(check('amount-limit', isFinite(amount) && amount <= L.maxTradeAmountIDR,
      'Nominal melebihi batas risiko pengguna (' + L.maxTradeAmountIDR + ' IDR).', { limit: L.maxTradeAmountIDR }));

    // 4. Kesegaran data kuotasi.
    var q = intent.quote || {};
    var fresh = q.freshness === 'FRESH' || (q.freshness === 'DAILY_REFERENCE' && mode !== 'LIVE');
    if (q.timestamp && now - Number(q.timestamp) > L.maxQuoteAgeMs && q.freshness === 'FRESH') fresh = false;
    checks.push(check('quote-fresh', fresh, 'Kuotasi tidak segar/tidak tersedia (' + (q.freshness || 'UNKNOWN') + ').'));

    // 5. Batas operasional.
    var open = num(ctx.openPositions || 0), today = num(ctx.tradesToday || 0), loss = num(ctx.todayLossIDR || 0);
    checks.push(check('open-positions', open < L.maxOpenPositions, 'Jumlah posisi terbuka mencapai batas (' + L.maxOpenPositions + ').', { limit: L.maxOpenPositions }));
    checks.push(check('trades-per-day', today < L.maxTradesPerDay, 'Jumlah transaksi harian mencapai batas (' + L.maxTradesPerDay + ').', { limit: L.maxTradesPerDay }));
    var cdLeft = ctx.lastTradeAt ? L.cooldownSeconds * 1000 - (now - Number(ctx.lastTradeAt)) : 0;
    checks.push(check('cooldown', cdLeft <= 0, 'Cooldown aktif; tunggu ' + Math.ceil(cdLeft / 1000) + ' detik.', { remainingMs: Math.max(0, cdLeft) }));
    checks.push(check('daily-loss', loss < L.maxDailyLossIDR, 'Batas rugi harian tercapai (' + L.maxDailyLossIDR + ' IDR).', { limit: L.maxDailyLossIDR }));
    var peak = num(ctx.peakEquity), eq = num(ctx.equity);
    var dd = isFinite(peak) && peak > 0 && isFinite(eq) ? (peak - eq) / peak * 100 : 0;
    checks.push(check('drawdown', dd < L.maxDrawdownPct, 'Drawdown ' + dd.toFixed(2) + '% mencapai batas ' + L.maxDrawdownPct + '%.', { drawdownPct: dd, limit: L.maxDrawdownPct }));

    // 6. Risiko terburuk harus dapat dihitung & muat dalam sisa batas rugi harian.
    var estimate = null;
    if (typeOk) {
      estimate = worstCase(type, intent);
      checks.push(check('risk-computable', estimate.computable, estimate.reason || 'Risiko tidak dapat dihitung.'));
      if (estimate.computable) {
        checks.push(check('risk-within-daily-budget', loss + estimate.lossIDR <= L.maxDailyLossIDR,
          'Kerugian terburuk (' + Math.round(estimate.lossIDR) + ') melampaui sisa batas rugi harian.', { worstCaseIDR: estimate.lossIDR }));
      }
    }

    // 7. Spesifikasi broker: ESTIMATE boleh untuk DRY_RUN/PAPER, tidak untuk LIVE.
    var spec = typeOk && tt ? tt.spec(type) : null;
    if (mode === 'LIVE') {
      var missing = spec ? spec.missingForLive : ['spec'];
      checks.push(check('broker-spec-verified', missing.length === 0, 'Spesifikasi broker belum terverifikasi: ' + missing.join(', ') + '.', { missing: missing }));
      checks.push(check('broker-quote', !!(q.isBrokerQuote === true), 'Kuotasi bukan dari feed broker terverifikasi (sumber: ' + (q.providerId || 'tidak ada') + ').'));
    } else if (spec && spec.missingForLive.length) {
      estimate = estimate || {};
      estimate.specNote = 'Spesifikasi broker UNVERIFIED (' + spec.missingForLive.length + ' atribut); hasil hanya ESTIMATE/simulasi.';
    }

    var blockers = checks.filter(function (c) { return !c.ok; }).map(function (c) { return { id: c.id, reason: c.reason }; });
    return { ok: blockers.length === 0, mode: mode, transactionType: type || null, checks: checks, blockers: blockers,
      estimate: estimate, limits: L, evaluatedAt: now };
  }

  return { DEFAULT_LIMITS: Object.assign({}, DEFAULT_LIMITS), limitsFrom: limitsFrom, worstCase: worstCase, evaluate: evaluate };
});
