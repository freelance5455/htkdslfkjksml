PHONE TYCOON — Android Studio project
=====================================

Что внутри:
- app/src/main/assets/index.html — сама игра (можно открыть в браузере для теста)
- Android WebView wrapper — приложение Android, запускающее игру
- локальное сохранение через localStorage
- магазин, покупки, инвентарь, продажа, объявления, чаты, кабинет и финансовая история

ВАЖНО:
Этот архив — исходный Android-проект, а не уже собранный APK. В этой среде нет Android SDK/Gradle,
поэтому подписанный APK собрать здесь не получилось.

Как собрать APK:
1. Установите Android Studio.
2. Откройте папку PhoneSimulatorAndroid в Android Studio.
3. Дождитесь синхронизации Gradle и установки Android SDK 35 (если попросит).
4. Для тестовой сборки выберите Build -> Build Bundle(s) / APK(s) -> Build APK(s).
5. APK появится в app/build/outputs/apk/debug/app-debug.apk.

Для тестирования самой игры можно открыть app/src/main/assets/index.html в Chrome на компьютере/телефоне.
Финансовая статистика — игровая, данные хранятся локально на устройстве и не синхронизируются между устройствами.
