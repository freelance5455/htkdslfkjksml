UJC LIVE - Designed by UJC, The Unknown Joint Community

Open index.html in Chrome / Edge / Safari (phone or desktop). Works offline.
Features: live rooms, voice chat parties (8 seats, real mic), Go Live with camera,
gifts and coins, chats, profile. 5-day free trial, then PKR 30 Premium (unlimited coins + VIP gift effects).

IMPORTANT (read me):
- Viewers, chat and party members are SIMULATED. Real multi-user live video/voice
  needs a server (WebRTC/SFU such as LiveKit, Agora, Zego) - not possible in one offline file.
- Payment is MANUAL, not automatic: the user sends PKR 30 to +923407371300 on Easypaisa,
  messages you their Device ID + transaction ID on WhatsApp (+923231314074), you check it, then generate
  their code with the separate owner generator (never share it) and send it back.
- The trial/lock lives in the user's browser, so a technical user can bypass it.
  Real enforcement needs a backend.
