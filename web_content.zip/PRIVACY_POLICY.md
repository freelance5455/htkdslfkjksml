# Smart Privacy Policy

Smart is an Android assistant. The app performs actions only through Android APIs and permissions that the user explicitly enables.

## Device data
Smart may process commands entered by the user and the result of supported actions on the device. Accessibility access and notification access are optional and must be enabled by the user in Android Settings.

## Network services
The project includes an optional backend API. A deployed version should use HTTPS, authentication, access controls, and a clearly disclosed privacy policy before processing company or customer data.

## Contact
Replace this section with the operator's legal business name and support email before commercial release.
