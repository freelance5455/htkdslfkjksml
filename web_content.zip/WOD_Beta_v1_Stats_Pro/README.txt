WOD Beta v1 — Stats & Records Pro patch

Key changes:
- Difficulty rest: Easy 75s, Moderate 60s, Hard 50s, Brutal 40s, Psycho 30s, Impossible 30s.
- Mandatory 45s setup/transition rest after completing an exercise before the next exercise.
- No unnecessary rest after the final set of the final exercise.
- Individual history records can be deleted.
- Weekly, monthly, yearly and all-time training statistics.
- Hours trained, estimated calories, workouts, sets, reps, full rounds, completed exercises and average session time.
- Bodyweight setting used for calorie estimates.
- Trophy-style announcements for first clean finishes, personal bests and workout milestones.
- Existing backup/import functionality retained.

This is still the offline web-wrapper build. It has been syntax-checked and packaged, but an Android APK has not been compiled/verified in this environment.
