UBD AI — starter prototype
==========================
Files:
- index.html: dark neon UBD AI interface and limited browser voice-command demo
- ubaid-background.jpg: the photo supplied for the background

How to try on your Realme Note 50:
1. Extract UBD_AI_Starter.zip.
2. Open index.html in Chrome (or upload the files to your Netlify site).
3. Allow microphone permission and tap the glowing circle.
4. Try simple commands such as "WhatsApp kholo", "YouTube kholo", or "time batao".

Important limitations:
- This is a web prototype, not a native Android APK.
- Browser speech recognition may require internet and Chrome support; it is not guaranteed offline.
- "Hey UBD" wake-word listening while the app is closed is NOT implemented in this prototype.
- For privacy and reliability, the message demo opens WhatsApp with a prepared message; review it and send it yourself.
- A full native Android app with offline speech recognition and background wake-word detection requires an Android build environment and additional permissions/testing.
