STEAL AN EGG - WEB APK PATH FIX

This archive contains the game files both at the ZIP root and inside web/. The error URL appassets.androidplatform.net/web/index.html indicates the wrapper is looking for web/index.html, which the previous ZIP did not include.

Import this ZIP into your APK builder and rebuild the APK. This fixes the missing entry-file path if the builder uses this folder convention. It does not itself create an APK or guarantee native orientation locking; that requires a builder/native Android wrapper that supports landscape orientation.
