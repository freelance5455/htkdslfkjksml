import sharp from 'sharp';
import fs from 'fs';
import path from 'path';

const publicDir = path.resolve('public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

// 1. Standard SVG Icon
const iconSvg = `
<svg width="512" height="512" viewBox="0 0 512 512" fill="none" xmlns="http://www.w3.org/2000/svg">
  <rect width="512" height="512" rx="104" fill="#0f232b"/>
  <!-- Decorative border ring -->
  <rect x="16" y="16" width="480" height="480" rx="90" stroke="#C79A6A" stroke-width="4" stroke-opacity="0.4" fill="none"/>
  
  <defs>
    <linearGradient id="crossGold" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stopColor="#FFF2DE"/>
      <stop offset="40%" stopColor="#E2B67E"/>
      <stop offset="80%" stopColor="#C79A6A"/>
      <stop offset="100%" stopColor="#2D6F8B"/>
    </linearGradient>
    <radialGradient id="glow" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stopColor="#C79A6A" stop-opacity="0.3"/>
      <stop offset="100%" stopColor="#0f232b" stop-opacity="0"/>
    </radialGradient>
  </defs>

  <circle cx="256" cy="230" r="170" fill="url(#glow)"/>

  <!-- Scaled Ethiopian Processional Cross in Center -->
  <g transform="translate(136, 60) scale(2.4)">
    <!-- Central Vertical Beam -->
    <rect x="46" y="10" width="8" height="100" rx="2" fill="url(#crossGold)"/>
    <!-- Central Horizontal Beam -->
    <rect x="20" y="36" width="60" height="8" rx="2" fill="url(#crossGold)"/>

    <!-- Top Finial / Crown -->
    <path d="M 50 4 L 56 12 L 44 12 Z" fill="url(#crossGold)"/>
    <circle cx="50" cy="14" r="3" fill="#16323D" stroke="url(#crossGold)" stroke-width="1.5"/>

    <!-- Left Arm Finials -->
    <circle cx="18" cy="40" r="5" fill="#16323D" stroke="url(#crossGold)" stroke-width="2"/>
    <path d="M 12 37 L 12 43 L 6 40 Z" fill="url(#crossGold)"/>

    <!-- Right Arm Finials -->
    <circle cx="82" cy="40" r="5" fill="#16323D" stroke="url(#crossGold)" stroke-width="2"/>
    <path d="M 88 37 L 88 43 L 94 40 Z" fill="url(#crossGold)"/>

    <!-- Diagonal Cross-Bars / Lattice Braces -->
    <path d="M 30 20 L 70 60 M 70 20 L 30 60" stroke="url(#crossGold)" stroke-width="3.5" stroke-linecap="round"/>

    <!-- Decorative Inner Ring -->
    <circle cx="50" cy="40" r="16" stroke="url(#crossGold)" stroke-width="2.5" fill="none"/>
    <circle cx="50" cy="40" r="4" fill="url(#crossGold)"/>

    <!-- Lower Processional Wings -->
    <path d="M 36 68 Q 30 82 46 86 M 64 68 Q 70 82 54 86" stroke="url(#crossGold)" stroke-width="3" fill="none" stroke-linecap="round"/>

    <!-- Base Pedestal Handle -->
    <path d="M 42 98 L 58 98 L 54 114 L 46 114 Z" fill="url(#crossGold)"/>
    <line x1="40" y1="114" x2="60" y2="114" stroke="url(#crossGold)" stroke-width="2.5" stroke-linecap="round"/>
  </g>

  <!-- Open Bible Banner Motif at the bottom -->
  <g transform="translate(146, 370)">
    <path d="M 10 30 Q 55 15 110 32 Q 165 15 210 30 L 210 52 Q 165 37 110 54 Q 55 37 10 52 Z" fill="#16323D" stroke="#C79A6A" stroke-width="2.5"/>
    <path d="M 110 32 L 110 54" stroke="#C79A6A" stroke-width="2"/>
    <circle cx="110" cy="22" r="4" fill="#C79A6A"/>
  </g>

  <!-- 365 Subtitle text -->
  <text x="256" y="460" text-anchor="middle" fill="#F2E7D8" font-family="system-ui, sans-serif" font-size="28" font-weight="bold" letter-spacing="4">365 DAYS BIBLE</text>
</svg>
`;

// 2. Maskable SVG Icon (Safe zone margin: elements restricted to inner 75-80%)
const maskableSvg = `
<svg width="512" height="512" viewBox="0 0 512 512" fill="none" xmlns="http://www.w3.org/2000/svg">
  <!-- Full bleed background without rounded corners so Android can crop arbitrarily -->
  <rect width="512" height="512" fill="#0f232b"/>
  
  <defs>
    <linearGradient id="maskCrossGold" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stopColor="#FFF2DE"/>
      <stop offset="40%" stopColor="#E2B67E"/>
      <stop offset="80%" stopColor="#C79A6A"/>
      <stop offset="100%" stopColor="#2D6F8B"/>
    </linearGradient>
    <radialGradient id="maskGlow" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stopColor="#C79A6A" stop-opacity="0.35"/>
      <stop offset="100%" stopColor="#0f232b" stop-opacity="0"/>
    </radialGradient>
  </defs>

  <circle cx="256" cy="256" r="190" fill="url(#maskGlow)"/>

  <!-- Scaled down to fit within 75% safe area (center circle diameter ~384px) -->
  <g transform="translate(156, 90) scale(2.0)">
    <rect x="46" y="10" width="8" height="100" rx="2" fill="url(#maskCrossGold)"/>
    <rect x="20" y="36" width="60" height="8" rx="2" fill="url(#maskCrossGold)"/>
    <path d="M 50 4 L 56 12 L 44 12 Z" fill="url(#maskCrossGold)"/>
    <circle cx="50" cy="14" r="3" fill="#16323D" stroke="url(#maskCrossGold)" stroke-width="1.5"/>
    <circle cx="18" cy="40" r="5" fill="#16323D" stroke="url(#maskCrossGold)" stroke-width="2"/>
    <path d="M 12 37 L 12 43 L 6 40 Z" fill="url(#maskCrossGold)"/>
    <circle cx="82" cy="40" r="5" fill="#16323D" stroke="url(#maskCrossGold)" stroke-width="2"/>
    <path d="M 88 37 L 88 43 L 94 40 Z" fill="url(#maskCrossGold)"/>
    <path d="M 30 20 L 70 60 M 70 20 L 30 60" stroke="url(#maskCrossGold)" stroke-width="3.5" stroke-linecap="round"/>
    <circle cx="50" cy="40" r="16" stroke="url(#maskCrossGold)" stroke-width="2.5" fill="none"/>
    <circle cx="50" cy="40" r="4" fill="url(#maskCrossGold)"/>
    <path d="M 36 68 Q 30 82 46 86 M 64 68 Q 70 82 54 86" stroke="url(#maskCrossGold)" stroke-width="3" fill="none" stroke-linecap="round"/>
    <path d="M 42 98 L 58 98 L 54 114 L 46 114 Z" fill="url(#maskCrossGold)"/>
    <line x1="40" y1="114" x2="60" y2="114" stroke="url(#maskCrossGold)" stroke-width="2.5" stroke-linecap="round"/>
  </g>

  <!-- Open Bible -->
  <g transform="translate(166, 350) scale(0.9)">
    <path d="M 10 30 Q 55 15 110 32 Q 165 15 210 30 L 210 52 Q 165 37 110 54 Q 55 37 10 52 Z" fill="#16323D" stroke="#C79A6A" stroke-width="2.5"/>
    <path d="M 110 32 L 110 54" stroke="#C79A6A" stroke-width="2"/>
    <circle cx="110" cy="22" r="4" fill="#C79A6A"/>
  </g>

  <text x="256" y="426" text-anchor="middle" fill="#F2E7D8" font-family="system-ui, sans-serif" font-size="22" font-weight="bold" letter-spacing="3">365 BIBLE PLAN</text>
</svg>
`;

async function generate() {
  fs.writeFileSync(path.join(publicDir, 'icon.svg'), iconSvg.trim());
  console.log('Written icon.svg');

  const svgBuffer = Buffer.from(iconSvg);
  const maskableBuffer = Buffer.from(maskableSvg);

  // 512x512 standard
  await sharp(svgBuffer)
    .resize(512, 512)
    .png()
    .toFile(path.join(publicDir, 'pwa-512x512.png'));
  console.log('Generated pwa-512x512.png');

  // 192x192 standard
  await sharp(svgBuffer)
    .resize(192, 192)
    .png()
    .toFile(path.join(publicDir, 'pwa-192x192.png'));
  console.log('Generated pwa-192x192.png');

  // 180x180 Apple touch icon
  await sharp(svgBuffer)
    .resize(180, 180)
    .png()
    .toFile(path.join(publicDir, 'apple-touch-icon.png'));
  console.log('Generated apple-touch-icon.png');

  // 512x512 Maskable icon
  await sharp(maskableBuffer)
    .resize(512, 512)
    .png()
    .toFile(path.join(publicDir, 'pwa-maskable-512x512.png'));
  console.log('Generated pwa-maskable-512x512.png');

  // Favicon 64x64 png
  await sharp(svgBuffer)
    .resize(64, 64)
    .png()
    .toFile(path.join(publicDir, 'favicon.png'));
  console.log('Generated favicon.png');
}

generate().catch((err) => {
  console.error(err);
  process.exit(1);
});
