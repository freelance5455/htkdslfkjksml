import { Capacitor } from '@capacitor/core';
import { App as CapacitorApp } from '@capacitor/app';
import { StatusBar, Style } from '@capacitor/status-bar';
import { SplashScreen } from '@capacitor/splash-screen';
import { Keyboard } from '@capacitor/keyboard';

let initialized = false;

export async function initializeCapacitor() {
  if (initialized || !Capacitor.isNativePlatform()) return;
  initialized = true;

  try {
    await StatusBar.setStyle({ style: Style.Dark });
    await StatusBar.setBackgroundColor({ color: '#0f232b' });
  } catch {
    // Safe to ignore on unsupported Android versions.
  }

  try {
    await Keyboard.setResizeMode({ mode: 'body' });
  } catch {
    // Plugin may be unavailable during a web/PWA build.
  }

  try {
    await SplashScreen.hide();
  } catch {
    // Safe fallback.
  }

  // Browser history handles normal modal/navigation state. The app-level
  // listener prevents Android back from unexpectedly exiting while a dialog
  // or overlay is open. App.tsx can register its own state-aware handler.
  CapacitorApp.addListener('backButton', ({ canGoBack }) => {
    if (window.history.length > 1 && canGoBack) {
      window.history.back();
    } else {
      CapacitorApp.exitApp();
    }
  });
}
