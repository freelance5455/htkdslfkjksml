import React, { useState, useEffect, useMemo } from 'react';
import confetti from 'canvas-confetti';
import { generate365BiblePlan, ETHIOPIAN_MONTHS } from './data/biblePlanData';
import { ReadingDay } from './types';
import { soundEngine } from './utils/soundEffects';
import { HeaderProgress } from './components/HeaderProgress';
import { MonthSelector } from './components/MonthSelector';
import { DayCardGrid } from './components/DayCardGrid';
import { PassageModal } from './components/PassageModal';
import { AudioPlayerBar } from './components/AudioPlayerBar';
import { MotivationBanner } from './components/MotivationBanner';
import { BibleReaderModal } from './components/BibleReaderModal';
import { OfflineIndicator } from './components/OfflineIndicator';
import { Sparkles, BookOpen, AlertTriangle } from 'lucide-react';

const STORAGE_KEYS = {
  COMPLETED: 'bible_plan_completed_days',
  NOTES: 'bible_plan_user_notes',
  STREAK: 'bible_plan_user_streak',
  LAST_DATE: 'bible_plan_last_read_date',
  LANG: 'bible_plan_user_language',
  MONTH: 'bible_plan_selected_month',
};

export default function App() {
  const allDays = useMemo(() => generate365BiblePlan(), []);

  // State: Completed day map { [dayNumber]: boolean }
  const [completedDays, setCompletedDays] = useState<Record<number, boolean>>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.COMPLETED);
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  // State: User personal notes { [dayNumber]: string }
  const [notes, setNotes] = useState<Record<number, string>>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.NOTES);
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  // State: Streak counter
  const [streak, setStreak] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.STREAK);
      return saved ? parseInt(saved, 10) : 0;
    } catch {
      return 0;
    }
  });

  // State: Active month index (0 to 12)
  const [selectedMonthIndex, setSelectedMonthIndex] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.MONTH);
      return saved ? parseInt(saved, 10) : 0;
    } catch {
      return 0;
    }
  });

  // State: Language ('am' = Amharic, 'en' = English)
  const [language, setLanguage] = useState<'am' | 'en'>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.LANG);
      return (saved as 'am' | 'en') || 'am';
    } catch {
      return 'am';
    }
  });

  // State: Modals
  const [activeModalDay, setActiveModalDay] = useState<ReadingDay | null>(null);
  const [isMotivationOpen, setIsMotivationOpen] = useState<boolean>(false);
  const [showResetConfirm, setShowResetConfirm] = useState<boolean>(false);
  const [isBibleReaderOpen, setIsBibleReaderOpen] = useState<boolean>(false);
  const [readerBook, setReaderBook] = useState<string>('ዘፍጥረት');
  const [readerChapter, setReaderChapter] = useState<number>(1);

  // Sync state to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.COMPLETED, JSON.stringify(completedDays));
    } catch (e) {
      console.warn('Failed to save progress to localStorage', e);
    }
  }, [completedDays]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.NOTES, JSON.stringify(notes));
    } catch (e) {
      console.warn('Failed to save notes to localStorage', e);
    }
  }, [notes]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.STREAK, streak.toString());
  }, [streak]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.LANG, language);
  }, [language]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.MONTH, selectedMonthIndex.toString());
  }, [selectedMonthIndex]);

  // Update streak when marking a day complete
  const updateStreakOnRead = () => {
    const todayStr = new Date().toISOString().slice(0, 10);
    const lastRead = localStorage.getItem(STORAGE_KEYS.LAST_DATE);

    if (lastRead !== todayStr) {
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const yesterdayStr = yesterday.toISOString().slice(0, 10);

      if (lastRead === yesterdayStr) {
        setStreak((prev) => prev + 1);
      } else if (!lastRead) {
        setStreak(1);
      } else {
        // Reset or restart streak
        setStreak(1);
      }
      localStorage.setItem(STORAGE_KEYS.LAST_DATE, todayStr);
    }
  };

  // Toggle single day completed / ticked
  const handleToggleDay = (dayNumber: number, event?: React.MouseEvent) => {
    if (event) {
      event.stopPropagation();
    }

    setCompletedDays((prev) => {
      const willBeCompleted = !prev[dayNumber];
      const updated = { ...prev, [dayNumber]: willBeCompleted };

      // Play tactical audio tick
      soundEngine.playTick(willBeCompleted);

      if (willBeCompleted) {
        updateStreakOnRead();

        // Calculate count after tick
        const count = Object.values(updated).filter(Boolean).length;

        // Trigger confetti celebration on milestones!
        if (count % 30 === 0 || count === 10 || count === 100 || count === 180 || count === 365) {
          soundEngine.playMilestoneCelebration();
          confetti({
            particleCount: count === 365 ? 120 : 60,
            spread: 70,
            origin: { y: 0.6 },
            colors: ['#C79A6A', '#F2E7D8', '#8FB7C7', '#2D6F8B'],
          });
        }
      }

      return updated;
    });
  };

  // Batch toggle an entire month
  const handleMarkMonthAll = (monthDays: ReadingDay[], complete: boolean) => {
    setCompletedDays((prev) => {
      const updated = { ...prev };
      monthDays.forEach((d) => {
        updated[d.dayNumber] = complete;
      });
      return updated;
    });

    soundEngine.playTick(complete);
    if (complete) {
      soundEngine.playMilestoneCelebration();
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.6 },
        colors: ['#C79A6A', '#F2E7D8', '#8FB7C7', '#2D6F8B'],
      });
    }
  };

  // Save personal note for day
  const handleSaveNote = (dayNumber: number, noteText: string) => {
    setNotes((prev) => ({
      ...prev,
      [dayNumber]: noteText,
    }));
  };

  // Navigate next / previous day in modal
  const handleNavigateDayInModal = (offset: number) => {
    if (!activeModalDay) return;
    const newDayNum = activeModalDay.dayNumber + offset;
    if (newDayNum >= 1 && newDayNum <= 365) {
      const target = allDays[newDayNum - 1];
      if (target) {
        setActiveModalDay(target);
        if (target.monthIndex !== selectedMonthIndex) {
          setSelectedMonthIndex(target.monthIndex);
        }
      }
    }
  };

  // Jump to today or first unread day
  const handleJumpToToday = () => {
    // Find first unread day
    const nextUnread = allDays.find((d) => !completedDays[d.dayNumber]) || allDays[0];
    setSelectedMonthIndex(nextUnread.monthIndex);
    setActiveModalDay(nextUnread);

    // Scroll smoothly to top
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Reset progress with safety confirmation
  const handleConfirmReset = () => {
    setCompletedDays({});
    setStreak(0);
    localStorage.removeItem(STORAGE_KEYS.COMPLETED);
    localStorage.removeItem(STORAGE_KEYS.STREAK);
    localStorage.removeItem(STORAGE_KEYS.LAST_DATE);
    setShowResetConfirm(false);
  };

  const completedCount = Object.values(completedDays).filter(Boolean).length;
  const currentMonth = ETHIOPIAN_MONTHS[selectedMonthIndex] || ETHIOPIAN_MONTHS[0];

  return (
    <div className="min-h-screen bg-[#0f232b] text-[#F2E7D8] pb-24 selection:bg-[#2D6F8B]/40 selection:text-[#F2E7D8]">
      {/* Ambient background glow elements */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden opacity-35 z-0">
        <div className="absolute -top-40 left-1/2 -translate-x-1/2 w-[700px] h-[500px] bg-gradient-to-b from-[#2D6F8B]/25 via-[#16323D]/20 to-transparent rounded-full blur-3xl" />
        <div className="absolute bottom-10 -left-20 w-80 h-80 bg-[#C79A6A]/12 rounded-full blur-3xl" />
        <div className="absolute top-1/3 -right-20 w-80 h-80 bg-[#8FB7C7]/12 rounded-full blur-3xl" />
      </div>

      {/* Main Container */}
      <main className="relative z-10 container mx-auto px-3 sm:px-6 pt-6 sm:pt-10 max-w-5xl">
        {/* Header with Title & Recessed Progress Bar */}
        <HeaderProgress
          completedCount={completedCount}
          totalDays={365}
          streak={streak}
          language={language}
          onToggleLanguage={() => setLanguage((prev) => (prev === 'am' ? 'en' : 'am'))}
          onJumpToToday={handleJumpToToday}
          onOpenMotivation={() => setIsMotivationOpen(true)}
          onResetProgress={() => setShowResetConfirm(true)}
          onOpenBibleReader={() => {
            setReaderBook('ዘፍጥረት');
            setReaderChapter(1);
            setIsBibleReaderOpen(true);
          }}
        />

        {/* 13 Ethiopian Calendar Month Tabs (Matching Screenshot) */}
        <MonthSelector
          selectedMonthIndex={selectedMonthIndex}
          onSelectMonth={(idx) => setSelectedMonthIndex(idx)}
          completedDays={completedDays}
          language={language}
        />

        {/* Day Card Grid for Selected Month */}
        <DayCardGrid
          currentMonth={currentMonth}
          days={allDays}
          completedDays={completedDays}
          onToggleDay={handleToggleDay}
          onOpenDayModal={(day) => setActiveModalDay(day)}
          onMarkMonthAll={handleMarkMonthAll}
          language={language}
        />
      </main>

      {/* Interactive Scripture Reading Modal */}
      <PassageModal
        day={activeModalDay}
        isOpen={activeModalDay !== null}
        onClose={() => setActiveModalDay(null)}
        isCompleted={activeModalDay ? !!completedDays[activeModalDay.dayNumber] : false}
        onToggleComplete={(dayNum) => handleToggleDay(dayNum)}
        onNavigateDay={handleNavigateDayInModal}
        savedNote={activeModalDay ? notes[activeModalDay.dayNumber] || '' : ''}
        onSaveNote={handleSaveNote}
        language={language}
        onOpenFullBibleReader={(book, chapter) => {
          setReaderBook(book);
          setReaderChapter(chapter);
          setIsBibleReaderOpen(true);
        }}
      />

      {/* Dedicated Full Holy Bible Reader (66 Books, 2 Amharic Translations) */}
      <BibleReaderModal
        isOpen={isBibleReaderOpen}
        onClose={() => setIsBibleReaderOpen(false)}
        initialBook={readerBook}
        initialChapter={readerChapter}
        initialVersion="nasv"
      />

      {/* Daily Motivation & Milestones Modal */}
      <MotivationBanner
        completedCount={completedCount}
        totalDays={365}
        streak={streak}
        language={language}
        isOpen={isMotivationOpen}
        onClose={() => setIsMotivationOpen(false)}
        onJumpToNextUnread={handleJumpToToday}
      />

      {/* Background Music Player (YouTube & Ambient Audio) */}
      <AudioPlayerBar language={language} />

      {/* Offline Status Indicator */}
      <OfflineIndicator language={language} />

      {/* Reset Confirmation Dialog */}
      {showResetConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="relative w-full max-w-sm rounded-2xl bg-[#16323D] border-2 border-[#2D6F8B] p-6 text-center shadow-2xl">
            <div className="w-12 h-12 rounded-full bg-[#0e2027] text-[#C79A6A] flex items-center justify-center mx-auto mb-3">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-[#F2E7D8] mb-2 font-serif-header">
              {language === 'am' ? 'ሂደትን እንደገና መጀመር?' : 'Reset Progress?'}
            </h3>
            <p className="text-xs text-[#8FB7C7] mb-5 leading-relaxed">
              {language === 'am'
                ? 'የተነበቡትን ቀናት በሙሉ እና የንባብ ሪከርድዎን ያጠፋል። እርግጠኛ ነዎት?'
                : 'This will reset all your checked readings and streak records. Are you sure?'}
            </p>
            <div className="flex items-center gap-2 justify-center">
              <button
                onClick={() => setShowResetConfirm(false)}
                className="px-4 py-2 rounded-xl bg-[#10232b] hover:bg-[#1a3845] text-xs font-semibold text-[#F2E7D8] border border-[#2D6F8B]/60 cursor-pointer"
              >
                {language === 'am' ? 'ይቅር' : 'Cancel'}
              </button>
              <button
                onClick={handleConfirmReset}
                className="px-4 py-2 rounded-xl bg-[#8c2d19] hover:bg-[#a8361e] text-xs font-bold text-white shadow cursor-pointer"
              >
                {language === 'am' ? 'አዎ እንደገና ጀምር' : 'Yes, Reset'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
