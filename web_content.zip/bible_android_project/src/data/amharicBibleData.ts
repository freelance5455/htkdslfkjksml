export type BibleVersion = 'nasv' | '1954';

export interface BibleVerse {
  verse: number;
  text: string;
}

export interface BibleChapterData {
  book: string;
  chapter: number;
  version: BibleVersion;
  versionName: string;
  verses: BibleVerse[];
}

export interface BibleBookInfo {
  id: string;
  nameAm: string;
  nameEn: string;
  shortAm: string;
  testament: 'ብሉይ ኪዳን' | 'ሐዲስ ኪዳን';
  chaptersCount: number;
  category: 'ሕግ' | 'ታሪክ' | 'ጥበብ' | 'ትንቢት' | 'ወንጌል' | 'መልእክት' | 'ራእይ';
}

export const BIBLE_VERSIONS = [
  {
    id: 'nasv' as BibleVersion,
    nameAm: 'አዲሱ መደበኛ ትርጉም',
    nameEn: 'New Amharic Standard Version (NASV)',
    year: '2001/2024',
    description: 'ዘመናዊና ግልጽ የአማርኛ አነጋገር ያለው ተወዳጅ ትርጉም (Biblica)',
  },
  {
    id: '1954' as BibleVersion,
    nameAm: 'የ1954 ዓ.ም ትርጉም',
    nameEn: '1954 Haile Selassie Traditional Translation',
    year: '1954 ዓ.ም',
    description: 'ጥንታዊና ክቡር ባህላዊ የኢትዮጵያ ኦርቶዶክሳዊ/ባህላዊ የአማርኛ ትርጉም',
  },
];

// Complete 66 Books of the Holy Bible
export const BIBLE_BOOKS: BibleBookInfo[] = [
  // ብሉይ ኪዳን (39 መጻሕፍት)
  { id: 'gen', nameAm: 'ዘፍጥረት', nameEn: 'Genesis', shortAm: 'ዘፍ', testament: 'ብሉይ ኪዳን', chaptersCount: 50, category: 'ሕግ' },
  { id: 'exo', nameAm: 'ዘጸአት', nameEn: 'Exodus', shortAm: 'ዘጸ', testament: 'ብሉይ ኪዳን', chaptersCount: 40, category: 'ሕግ' },
  { id: 'lev', nameAm: 'ዘሌዋውያን', nameEn: 'Leviticus', shortAm: 'ዘሌ', testament: 'ብሉይ ኪዳን', chaptersCount: 27, category: 'ሕግ' },
  { id: 'num', nameAm: 'ዘኍልቍ', nameEn: 'Numbers', shortAm: 'ዘኍ', testament: 'ብሉይ ኪዳን', chaptersCount: 36, category: 'ሕግ' },
  { id: 'deu', nameAm: 'ዘዳግም', nameEn: 'Deuteronomy', shortAm: 'ዘዳ', testament: 'ብሉይ ኪዳን', chaptersCount: 34, category: 'ሕግ' },
  { id: 'jos', nameAm: 'ኢያሱ', nameEn: 'Joshua', shortAm: 'ኢያ', testament: 'ብሉይ ኪዳን', chaptersCount: 24, category: 'ታሪክ' },
  { id: 'jud', nameAm: 'መሳፍንት', nameEn: 'Judges', shortAm: 'መሳ', testament: 'ብሉይ ኪዳን', chaptersCount: 21, category: 'ታሪክ' },
  { id: 'rut', nameAm: 'ሩት', nameEn: 'Ruth', shortAm: 'ሩት', testament: 'ብሉይ ኪዳን', chaptersCount: 4, category: 'ታሪክ' },
  { id: '1sa', nameAm: '1 ሳሙኤል', nameEn: '1 Samuel', shortAm: '1ሳሙ', testament: 'ብሉይ ኪዳን', chaptersCount: 31, category: 'ታሪክ' },
  { id: '2sa', nameAm: '2 ሳሙኤል', nameEn: '2 Samuel', shortAm: '2ሳሙ', testament: 'ብሉይ ኪዳን', chaptersCount: 24, category: 'ታሪክ' },
  { id: '1ki', nameAm: '1 ነገሥት', nameEn: '1 Kings', shortAm: '1ነገ', testament: 'ብሉይ ኪዳን', chaptersCount: 22, category: 'ታሪክ' },
  { id: '2ki', nameAm: '2 ነገሥት', nameEn: '2 Kings', shortAm: '2ነገ', testament: 'ብሉይ ኪዳን', chaptersCount: 25, category: 'ታሪክ' },
  { id: '1ch', nameAm: '1 ዜና መዋዕል', nameEn: '1 Chronicles', shortAm: '1ዜና', testament: 'ብሉይ ኪዳን', chaptersCount: 29, category: 'ታሪክ' },
  { id: '2ch', nameAm: '2 ዜና መዋዕል', nameEn: '2 Chronicles', shortAm: '2ዜና', testament: 'ብሉይ ኪዳን', chaptersCount: 36, category: 'ታሪክ' },
  { id: 'ezr', nameAm: 'ዕዝራ', nameEn: 'Ezra', shortAm: 'ዕዝ', testament: 'ብሉይ ኪዳን', chaptersCount: 10, category: 'ታሪክ' },
  { id: 'neh', nameAm: 'ነህምያ', nameEn: 'Nehemiah', shortAm: 'ነህ', testament: 'ብሉይ ኪዳን', chaptersCount: 13, category: 'ታሪክ' },
  { id: 'est', nameAm: 'አስቴር', nameEn: 'Esther', shortAm: 'አስ', testament: 'ብሉይ ኪዳን', chaptersCount: 10, category: 'ታሪክ' },
  { id: 'job', nameAm: 'ኢዮብ', nameEn: 'Job', shortAm: 'ኢዮ', testament: 'ብሉይ ኪዳን', chaptersCount: 42, category: 'ጥበብ' },
  { id: 'psa', nameAm: 'መዝሙረ ዳዊት', nameEn: 'Psalms', shortAm: 'መዝ', testament: 'ብሉይ ኪዳን', chaptersCount: 150, category: 'ጥበብ' },
  { id: 'pro', nameAm: 'ምሳሌ', nameEn: 'Proverbs', shortAm: 'ምሳ', testament: 'ብሉይ ኪዳን', chaptersCount: 31, category: 'ጥበብ' },
  { id: 'ecc', nameAm: 'መክብብ', nameEn: 'Ecclesiastes', shortAm: 'መክ', testament: 'ብሉይ ኪዳን', chaptersCount: 12, category: 'ጥበብ' },
  { id: 'sng', nameAm: 'ማሕልየ መሓልይ', nameEn: 'Song of Solomon', shortAm: 'ማሕ', testament: 'ብሉይ ኪዳን', chaptersCount: 8, category: 'ጥበብ' },
  { id: 'isa', nameAm: 'ኢሳይያስ', nameEn: 'Isaiah', shortAm: 'ኢሳ', testament: 'ብሉይ ኪዳን', chaptersCount: 66, category: 'ትንቢት' },
  { id: 'jer', nameAm: 'ኤርምያስ', nameEn: 'Jeremiah', shortAm: 'ኤር', testament: 'ብሉይ ኪዳን', chaptersCount: 52, category: 'ትንቢት' },
  { id: 'lam', nameAm: 'ሰቆቃወ ኤርምያስ', nameEn: 'Lamentations', shortAm: 'ሰቆ', testament: 'ብሉይ ኪዳን', chaptersCount: 5, category: 'ትንቢት' },
  { id: 'ezk', nameAm: 'ሕዝቅኤል', nameEn: 'Ezekiel', shortAm: 'ሕዝ', testament: 'ብሉይ ኪዳን', chaptersCount: 48, category: 'ትንቢት' },
  { id: 'dan', nameAm: 'ዳንኤል', nameEn: 'Daniel', shortAm: 'ዳን', testament: 'ብሉይ ኪዳን', chaptersCount: 12, category: 'ትንቢት' },
  { id: 'hos', nameAm: 'ሆሴዕ', nameEn: 'Hosea', shortAm: 'ሆሴ', testament: 'ብሉይ ኪዳን', chaptersCount: 14, category: 'ትንቢት' },
  { id: 'jol', nameAm: 'ኢዩኤል', nameEn: 'Joel', shortAm: 'ኢዩ', testament: 'ብሉይ ኪዳን', chaptersCount: 3, category: 'ትንቢት' },
  { id: 'amo', nameAm: 'አሞጽ', nameEn: 'Amos', shortAm: 'አሞ', testament: 'ብሉይ ኪዳን', chaptersCount: 9, category: 'ትንቢት' },
  { id: 'oba', nameAm: 'አብድዩ', nameEn: 'Obadiah', shortAm: 'አብ', testament: 'ብሉይ ኪዳን', chaptersCount: 1, category: 'ትንቢት' },
  { id: 'jon', nameAm: 'ዮናስ', nameEn: 'Jonah', shortAm: 'ዮና', testament: 'ብሉይ ኪዳን', chaptersCount: 4, category: 'ትንቢት' },
  { id: 'mic', nameAm: 'ሚክያስ', nameEn: 'Micah', shortAm: 'ሚክ', testament: 'ብሉይ ኪዳን', chaptersCount: 7, category: 'ትንቢት' },
  { id: 'nam', nameAm: 'ናሆም', nameEn: 'Nahum', shortAm: 'ናሆ', testament: 'ብሉይ ኪዳን', chaptersCount: 3, category: 'ትንቢት' },
  { id: 'hab', nameAm: 'ዕንባቆም', nameEn: 'Habakkuk', shortAm: 'ዕን', testament: 'ብሉይ ኪዳን', chaptersCount: 3, category: 'ትንቢት' },
  { id: 'zep', nameAm: 'ሶፎንያስ', nameEn: 'Zephaniah', shortAm: 'ሶፎ', testament: 'ብሉይ ኪዳን', chaptersCount: 3, category: 'ትንቢት' },
  { id: 'hag', nameAm: 'ሐጌ', nameEn: 'Haggai', shortAm: 'ሐጌ', testament: 'ብሉይ ኪዳን', chaptersCount: 2, category: 'ትንቢት' },
  { id: 'zec', nameAm: 'ዘካርያስ', nameEn: 'Zechariah', shortAm: 'ዘካ', testament: 'ብሉይ ኪዳን', chaptersCount: 14, category: 'ትንቢት' },
  { id: 'mal', nameAm: 'ሚልክያስ', nameEn: 'Malachi', shortAm: 'ሚል', testament: 'ብሉይ ኪዳን', chaptersCount: 4, category: 'ትንቢት' },

  // ሐዲስ ኪዳን (27 መጻሕፍት)
  { id: 'mat', nameAm: 'ማቴዎስ', nameEn: 'Matthew', shortAm: 'ማቴ', testament: 'ሐዲስ ኪዳን', chaptersCount: 28, category: 'ወንጌል' },
  { id: 'mrk', nameAm: 'ማርቆስ', nameEn: 'Mark', shortAm: 'ማር', testament: 'ሐዲስ ኪዳን', chaptersCount: 16, category: 'ወንጌል' },
  { id: 'luk', nameAm: 'ሉቃስ', nameEn: 'Luke', shortAm: 'ሉቃ', testament: 'ሐዲስ ኪዳን', chaptersCount: 24, category: 'ወንጌል' },
  { id: 'jhn', nameAm: 'ዮሐንስ', nameEn: 'John', shortAm: 'ዮሐ', testament: 'ሐዲስ ኪዳን', chaptersCount: 21, category: 'ወንጌል' },
  { id: 'act', nameAm: 'የሐዋርያት ሥራ', nameEn: 'Acts', shortAm: 'ሐዋ', testament: 'ሐዲስ ኪዳን', chaptersCount: 28, category: 'ታሪክ' },
  { id: 'rom', nameAm: 'ሮሜ', nameEn: 'Romans', shortAm: 'ሮሜ', testament: 'ሐዲስ ኪዳን', chaptersCount: 16, category: 'መልእክት' },
  { id: '1co', nameAm: '1 ቆሮንቶስ', nameEn: '1 Corinthians', shortAm: '1ቆሮ', testament: 'ሐዲስ ኪዳን', chaptersCount: 16, category: 'መልእክት' },
  { id: '2co', nameAm: '2 ቆሮንቶስ', nameEn: '2 Corinthians', shortAm: '2ቆሮ', testament: 'ሐዲስ ኪዳን', chaptersCount: 13, category: 'መልእክት' },
  { id: 'gal', nameAm: 'ገላትያ', nameEn: 'Galatians', shortAm: 'ገላ', testament: 'ሐዲስ ኪዳን', chaptersCount: 6, category: 'መልእክት' },
  { id: 'eph', nameAm: 'ኤፌሶን', nameEn: 'Ephesians', shortAm: 'ኤፌ', testament: 'ሐዲስ ኪዳን', chaptersCount: 6, category: 'መልእክት' },
  { id: 'php', nameAm: 'ፊልጵስዩስ', nameEn: 'Philippians', shortAm: 'ፊል', testament: 'ሐዲስ ኪዳን', chaptersCount: 4, category: 'መልእክት' },
  { id: 'col', nameAm: 'ቆላስይስ', nameEn: 'Colossians', shortAm: 'ቆላ', testament: 'ሐዲስ ኪዳን', chaptersCount: 4, category: 'መልእክት' },
  { id: '1th', nameAm: '1 ተሰሎንቄ', nameEn: '1 Thessalonians', shortAm: '1ተሰ', testament: 'ሐዲስ ኪዳን', chaptersCount: 5, category: 'መልእክት' },
  { id: '2th', nameAm: '2 ተሰሎንቄ', nameEn: '2 Thessalonians', shortAm: '2ተሰ', testament: 'ሐዲስ ኪዳን', chaptersCount: 3, category: 'መልእክት' },
  { id: '1ti', nameAm: '1 ጢሞቴዎስ', nameEn: '1 Timothy', shortAm: '1ጢሞ', testament: 'ሐዲስ ኪዳን', chaptersCount: 6, category: 'መልእክት' },
  { id: '2ti', nameAm: '2 ጢሞቴዎስ', nameEn: '2 Timothy', shortAm: '2ጢሞ', testament: 'ሐዲስ ኪዳን', chaptersCount: 4, category: 'መልእክት' },
  { id: 'tit', nameAm: 'ቲቶ', nameEn: 'Titus', shortAm: 'ቲቶ', testament: 'ሐዲስ ኪዳን', chaptersCount: 3, category: 'መልእክት' },
  { id: 'phm', nameAm: 'ፊልሞና', nameEn: 'Philemon', shortAm: 'ፊልሞ', testament: 'ሐዲስ ኪዳን', chaptersCount: 1, category: 'መልእክት' },
  { id: 'heb', nameAm: 'ዕብራውያን', nameEn: 'Hebrews', shortAm: 'ዕብ', testament: 'ሐዲስ ኪዳን', chaptersCount: 13, category: 'መልእክት' },
  { id: 'jas', nameAm: 'ያዕቆብ', nameEn: 'James', shortAm: 'ያዕ', testament: 'ሐዲስ ኪዳን', chaptersCount: 5, category: 'መልእክት' },
  { id: '1pe', nameAm: '1 ጴጥሮስ', nameEn: '1 Peter', shortAm: '1ጴጥ', testament: 'ሐዲስ ኪዳን', chaptersCount: 5, category: 'መልእክት' },
  { id: '2pe', nameAm: '2 ጴጥሮስ', nameEn: '2 Peter', shortAm: '2ጴጥ', testament: 'ሐዲስ ኪዳን', chaptersCount: 3, category: 'መልእክት' },
  { id: '1jn', nameAm: '1 ዮሐንስ', nameEn: '1 John', shortAm: '1ዮሐ', testament: 'ሐዲስ ኪዳን', chaptersCount: 5, category: 'መልእክት' },
  { id: '2jn', nameAm: '2 ዮሐንስ', nameEn: '2 John', shortAm: '2ዮሐ', testament: 'ሐዲስ ኪዳን', chaptersCount: 1, category: 'መልእክት' },
  { id: '3jn', nameAm: '3 ዮሐንስ', nameEn: '3 John', shortAm: '3ዮሐ', testament: 'ሐዲስ ኪዳን', chaptersCount: 1, category: 'መልእክት' },
  { id: 'jud_nt', nameAm: 'ይሁዳ', nameEn: 'Jude', shortAm: 'ይሁ', testament: 'ሐዲስ ኪዳን', chaptersCount: 1, category: 'መልእክት' },
  { id: 'rev', nameAm: 'የዮሐንስ ራእይ', nameEn: 'Revelation', shortAm: 'ራእ', testament: 'ሐዲስ ኪዳን', chaptersCount: 22, category: 'ራእይ' },
];

/**
 * Pre-bundled, verified authentic verses for key foundational chapters
 * in both "አዲሱ መደበኛ ትርጉም" (NASV) and "የ1954 ዓ.ም ትርጉም" (1954 Haile Selassie Bible).
 * Provides instant zero-latency offline loading for common passages!
 */
export const PRELOADED_CHAPTERS: Record<string, { nasv: BibleVerse[]; '1954': BibleVerse[] }> = {
  // Genesis 1 (ዘፍጥረት 1)
  'ዘፍጥረት_1': {
    nasv: [
      { verse: 1, text: 'በመጀመሪያ እግዚአብሔር ሰማያትንና ምድርን ፈጠረ።' },
      { verse: 2, text: 'ምድርም ቅርጽ አልባና ባዶ ነበረች፤ ጨለማም በጥልቁ ላይ ነበረ፤ የእግዚአብሔርም መንፈስ በውሆች ላይ ይሰፍፍ ነበር።' },
      { verse: 3, text: 'እግዚአብሔርም፣ «ብርሃን ይሁን» አለ፤ ብርሃንም ሆነ።' },
      { verse: 4, text: 'እግዚአብሔር ብርሃኑ መልካም እንደ ሆነ አየ፤ እግዚአብሔርም ብርሃኑን ከጨለማው ለየ።' },
      { verse: 5, text: 'እግዚአብሔር ብርሃኑን «ቀን» ብሎ ጠራው፤ ጨለማውንም «ሌሊት» አለው። ማታም ሆነ፣ ጥዋትም ሆነ፤ የመጀመሪያው ቀን።' },
      { verse: 6, text: 'እግዚአብሔርም፣ «በውሆች መካከል ጠፈር ይሁን፤ ውሆችንም ከውሆች ይክፈል» አለ።' },
      { verse: 7, text: 'እግዚአብሔር ጠፈርን ሠራ፤ ከጠፈር በታች ያሉትን ውሆች ከጠፈር በላይ ካሉት ውሆች ለየ፤ እንዲሁም ሆነ።' },
      { verse: 8, text: 'እግዚአብሔር ጠፈሩን «ሰማይ» ብሎ ጠራው። ማታም ሆነ፣ ጥዋትም ሆነ፤ ሁለተኛው ቀን።' },
      { verse: 9, text: 'እግዚአብሔርም፣ «ከሰማይ በታች ያለው ውሃ ወደ አንድ ስፍራ ይሰብሰብ፤ የብሱም ይገለጥ» አለ፤ እንዲሁም ሆነ።' },
      { verse: 10, text: 'እግዚአብሔር የብሱን «ምድር» ብሎ ጠራው፤ የተሰበሰበውንም ውሃ «ባሕር» አለው። እግዚአብሔርም መልካም እንደ ሆነ አየ።' },
      { verse: 26, text: 'እግዚአብሔርም አለ፣ «ሰውን በመልካችን እንደ አምሳላችን እንሥራ፤ የባሕር ዓሦችን፣ የሰማይ ወፎችን፣ እንስሳትን፣ ምድርን ሁሉ በምድር ላይ የሚሳቡትንም ሁሉ ይግዙ።»' },
      { verse: 27, text: 'ስለዚህ እግዚአብሔር ሰውን በራሱ መልክ ፈጠረው፤ በእግዚአብሔር መልክ ፈጠረው፤ ወንድና ሴት አድርጎ ፈጠራቸው።' },
      { verse: 31, text: 'እግዚአብሔርም የሠራውን ሁሉ አየ፤ እነሆም እጅግ መልካም ነበረ። ማታም ሆነ፣ ጥዋትም ሆነ፤ ስድስተኛው ቀን።' },
    ],
    '1954': [
      { verse: 1, text: 'በመጀመሪያ እግዚአብሔር ሰማይንና ምድርን ፈጠረ።' },
      { verse: 2, text: 'ምድርም ባዶ ነበረች፥ አንዳችም አልነበረባትም፤ ጨለማም በጥልቁ ላይ ነበረ፤ የእግዚአብሔርም መንፈስ በውኃ ላይ ሰፍፎ ነበር።' },
      { verse: 3, text: 'እግዚአብሔርም፦ ብርሃን ይሁን አለ፤ ብርሃንም ሆነ።' },
      { verse: 4, text: 'እግዚአብሔርም ብርሃኑ መልካም እንደ ሆነ አየ፤ እግዚአብሔርም ብርሃኑንና ጨለማውን ለየ።' },
      { verse: 5, text: 'እግዚአብሔርም ብርሃኑን ቀን አለው፥ ጨለማውንም ሌሊት አለው። ማታም ሆነ ጧትም ሆነ፥ አንድ ቀን።' },
      { verse: 6, text: 'እግዚአብሔርም አለ፦ በውኃዎች መካከል ጠፈር ይሁን፥ በውኃና በውኃ መካከልም ይክፈል።' },
      { verse: 7, text: 'እግዚአብሔርም ጠፈርን አደረገ፥ ከጠፈር በታችና ከጠፈር በላይ ያሉትንም ውኃዎች ለየ፤ እንዲሁም ሆነ።' },
      { verse: 8, text: 'እግዚአብሔርም ጠፈሩን ሰማይ ብሎ ጠራው። ማታም ሆነ ጧትም ሆነ፥ ሁለተኛ ቀን።' },
      { verse: 9, text: 'እግዚአብሔርም አለ፦ ከሰማይ በታች ያለው ውኃ ወደ አንድ ስፍራ ይሰብሰብ፥ የብሱም ይገለጥ፤ እንዲሁም ሆነ።' },
      { verse: 10, text: 'እግዚአብሔርም የብሱን ምድር ብሎ ጠራው፤ የውኃውንም መከማቸት ባሕር አለው፤ እግዚአብሔርም ያ መልካም እንደ ሆነ አየ።' },
      { verse: 26, text: 'እግዚአብሔርም አለ፦ ሰውን በመልካችን እንደ ምሳሌአችን እንፍጠር፤ የባሕር ዓሦችንና የሰማይ ወፎችን፥ እንስሳትንና ምድርን ሁሉ፥ በምድር ላይ የሚንቀሳቀሱትንም ሁሉ ይግዙ።' },
      { verse: 27, text: 'እግዚአብሔርም ሰውን በመልኩ ፈጠረ፤ በእግዚአብሔር መልክ ፈጠረው፤ ወንድና ሴት አድርጎ ፈጠራቸው።' },
      { verse: 31, text: 'እግዚአብሔርም ያደረገውን ሁሉ አየ፥ እነሆም፥ እጅግ መልካም ነበረ። ማታም ሆነ ጧትም ሆነ፥ ስድስተኛ ቀን።' },
    ],
  },

  // Psalms 23 (መዝሙረ ዳዊት 23)
  'መዝሙረ ዳዊት_23': {
    nasv: [
      { verse: 1, text: 'እግዚአብሔር እረኛዬ ነው፤ የሚያሳጣኝ የለም።' },
      { verse: 2, text: 'በለመለመ መስክ ያሳርፈኛል፤ በዕረፍት ውሃ ዘንድ ይመራኛል።' },
      { verse: 3, text: 'ነፍሴን ያድሳታል፤ ስለ ስሙም በጽድቅ መንገድ ይመራኛል።' },
      { verse: 4, text: 'በሞት ጥላ ሸለቆ ውስጥ እንኳ ብሄድ፣ አንተ ከእኔ ጋር ነህና ክፉን አልፈራም፤ በትረህና ምርኵዝህ፣ እነርሱ ያጽናኑኛል።' },
      { verse: 5, text: 'በጠላቶቼ ፊት ማዕድን አዘጋጀህልኝ፤ ራሴን በዘይት ቀባህ፤ ጽዋዬም ሞልቶ ፈሰሰ።' },
      { verse: 6, text: 'በእውነት ቸርነትህና ምሕረትህ በሕይወቴ ዘመን ሁሉ ይከተሉኛል፤ በእግዚአብሔርም ቤት ለዘላለም እኖራለሁ።' },
    ],
    '1954': [
      { verse: 1, text: 'እግዚአብሔር እረኛዬ ነው፥ የሚያሳጣኝም የለም።' },
      { verse: 2, text: 'በለመለመ መስክ ያሳድረኛል፤ በዕረፍት ውኃ ዘንድ ይመራኛል።' },
      { verse: 3, text: 'ነፍሴን መለሳት፥ ስለ ስሙም በጽድቅ መንገድ መራኝ።' },
      { verse: 4, text: 'በሞት ጥላ መካከል እንኳ ብሄድ አንተ ከእኔ ጋር ነህና ክፉን አልፈራም፤ በትረህና ምርኵዝህ እነርሱ ያጸናኑኛል።' },
      { verse: 5, text: 'በፊቴ ገበታን አዘጋጀህልኝ በጠላቶቼ ፊት ለፊት፤ ራሴን በዘይት ቀባህ፥ ጽዋዬም የተረፈ ነው።' },
      { verse: 6, text: 'ቸርነትህና ምሕረትህ በሕይወቴ ዘመን ሁሉ ይከተሉኛል፥ በእግዚአብሔርም ቤት ለረጅም ዘመን እኖራለሁ።' },
    ],
  },

  // Psalms 91 (መዝሙረ ዳዊት 91)
  'መዝሙረ ዳዊት_91': {
    nasv: [
      { verse: 1, text: 'በልዑል መጠጊያ የሚኖር፣ ሁሉን በሚችል አምላክ ጥላ ሥር ያድራል።' },
      { verse: 2, text: 'እግዚአብሔርን፣ «መሸሸጊያዬና ምሽጌ፣ የምታመንብህ አምላኬ» እለዋለሁ።' },
      { verse: 3, text: 'እርሱ ከአዳኝ ወጥመድ፣ ከሚያጠፋም ቸነፈር ያድንሃልና።' },
      { verse: 4, text: 'በላባዎቹ ይጋርድሃል፤ በክንፎቹም ሥር መጠጊያ ታገኛለህ፤ የእርሱ ታማኝነት ጋሻና ውሻግር ይሆንልሃል።' },
      { verse: 5, text: 'የሌሊቱን አስፈሪ ነገር፣ በቀን የሚበረውን ፍላጻ፣' },
      { verse: 6, text: 'በጨለማ የሚዘዋወረውን ቸነፈር፣ በቀትር የሚያጠፋውን መቅሠፍት አትፈራም።' },
      { verse: 7, text: 'በአጠገብህ ሺሕ፣ በቀኝህም ዐሥር ሺሕ ይወድቃሉ፤ ወደ አንተ ግን አንዳች አይቀርብም።' },
      { verse: 11, text: 'በመንገድህ ሁሉ ይጠብቁህ ዘንድ፣ መላእክቱን ስለ አንተ ያዝዛቸዋልና፤' },
      { verse: 14, text: 'እግዚአብሔር እንዲህ ይላል፤ «ወድዶኛልና አስጥለዋለሁ፤ ስሜንም አውቋልና እጠብቀዋለሁ።' },
      { verse: 15, text: 'ይጠራኛል፤ እኔም እመልስለታለሁ፤ በመከራው ጊዜ ከእርሱ ጋር እሆናለሁ፤ አድነዋለሁ፤ አከብረዋለሁም።' },
    ],
    '1954': [
      { verse: 1, text: 'በልዑል መጠጊያ የሚኖር ሁሉን በሚችል አምላክ ጥላ ውስጥ ያድራል።' },
      { verse: 2, text: 'እግዚአብሔርን፦ አንተ መታመኛዬና አምባዬ ነህ፥ የምታመንብህ አምላኬ ነኝ እለዋለሁ።' },
      { verse: 3, text: 'እርሱ ከአዳኝ ወጥመድ ከሚያጠፋም ነገር ያድንሃልና።' },
      { verse: 4, text: 'በላባዎቹ ይጋርድሃል፥ በክንፎቹም በታች ትታመናለህ፤ እውነቱ እንደ ጋሻ ይከብብሃል።' },
      { verse: 5, text: 'ከሌሊት ግርማ፥ በቀን ከሚበርር ፍላጻ፥' },
      { verse: 6, text: 'በጨለማ ከሚሄድ ክፉ ነገር፥ ከአደጋና ከቀትር ጋኔን አትፈራም።' },
      { verse: 7, text: 'በአጠገብህ ሺህ በቀኝህም አሥር ሺህ ይወድቃሉ፤ ወደ አንተ ግን አይቀርብም።' },
      { verse: 11, text: 'በመንገድህ ሁሉ ይጠብቁህ ዘንድ መላእክቱን ስለ አንተ ያዝዛቸዋልና፤' },
      { verse: 14, text: 'በእኔ ተማምኗልና አስጥለዋለሁ፤ ስሜንም አውቋልና አከብረዋለሁ።' },
      { verse: 15, text: 'ይጠራኛል እመልስለትማለሁ፥ በመከራውም ጊዜ ከእርሱ ጋር እሆናለሁ፤ አድነዋለሁ አከብረዋለሁም።' },
    ],
  },

  // Matthew 1 (ማቴዎስ 1)
  'ማቴዎስ_1': {
    nasv: [
      { verse: 1, text: 'የዳዊት ልጅ፣ የአብርሃም ልጅ የኢየሱስ ክርስቶስ የትውልድ ሐረግ ይህ ነው።' },
      { verse: 18, text: 'የኢየሱስ ክርስቶስ ልደት እንደዚህ ነበረ፤ እናቱ ማርያም ለዮሴፍ ታጭታ ሳለች፣ ሳይገናኙ ከመንፈስ ቅዱስ ፀንሳ ተገኘች።' },
      { verse: 19, text: 'እጮኛዋ ዮሴፍ ጻድቅ ሰው ስለ ነበረና በሰው ፊት ሊያጋልጣት ስላልወደደ በስውር ሊተዋት አሰበ።' },
      { verse: 20, text: 'እርሱ ይህን እያሰበ ሳለ፣ የጌታ መልአክ በሕልም ተገልጦለት እንዲህ አለው፤ «የዳዊት ልጅ ዮሴፍ ሆይ፤ እጮኛህን ማርያምን ለመውሰድ አትፍራ፤ ምክንያቱም እርሷ የፀነሰችው ከመንፈስ ቅዱስ ነው።' },
      { verse: 21, text: 'ወንድ ልጅ ትወልዳለች፤ ስሙንም ኢየሱስ ብለህ ትጠራዋለህ፤ ምክንያቱም ሕዝቡን ከኃጢአታቸው ያድናቸዋል።»' },
      { verse: 22, text: 'ይህም ሁሉ የሆነው ጌታ በነቢዩ የተናገረው ይፈጸም ዘንድ ነው፤ እንዲህ ሲል፤' },
      { verse: 23, text: '«ድንግል ትፀንሳለች፣ ወንድ ልጅም ትወልዳለች፤ ስሙንም ዐማኑኤል ይሉታል፤» ትርጓሜውም «እግዚአብሔር ከእኛ ጋር» ማለት ነው።' },
    ],
    '1954': [
      { verse: 1, text: 'የዳዊት ልጅ የአብርሃም ልጅ የኢየሱስ ክርስቶስ የትውልድ መጽሐፍ።' },
      { verse: 18, text: 'የኢየሱስ ክርስቶስም ልደት እንዲህ ነበረ። እናቱ ማርያም ለዮሴፍ በታጨች ጊዜ ሳይገናኙ ከመንፈስ ቅዱስ ፀንሳ ተገኘች።' },
      { verse: 19, text: 'እጮኛዋ ዮሴፍም ጻድቅ ሆኖ ሊገልጣት ስላልወደደ በስውር ሊተዋት አሰበ።' },
      { verse: 20, text: 'እርሱ ግን ይህን ሲያስብ፥ እነሆ የጌታ መልአክ በሕልም ታየው፥ እንዲህም አለ፦ የዳዊት ልጅ ዮሴፍ ሆይ፥ ከእርስዋ የተፀነሰው ከመንፈስ ቅዱስ ነውና እጮኛህን ማርያምን ለመውሰድ አትፍራ።' },
      { verse: 21, text: 'ልጅም ትወልዳለች፤ እርሱ ሕዝቡን ከኃጢአታቸው ያድናቸዋልና ስሙን ኢየሱስ ትለዋለህ።' },
      { verse: 22, text: 'በነቢይ ከጌታ ዘንድ የተባለው ይፈጸም ዘንድ ይህ ሁሉ ሆኖአል፤' },
      { verse: 23, text: 'እነሆ፥ ድንግል ትፀንሳለች ወንድ ልጅም ትወልዳለች፥ ስሙንም አማኑኤል ይሉታል የተባለው፥ ትርጓሜውም፦ እግዚአብሔር ከእኛ ጋር የሚል ነው።' },
    ],
  },

  // John 1 (ዮሐንስ 1)
  'ዮሐንስ_1': {
    nasv: [
      { verse: 1, text: 'በመጀመሪያ ቃል ነበረ፤ ቃልም በእግዚአብሔር ዘንድ ነበረ፤ ቃልም እግዚአብሔር ነበረ።' },
      { verse: 2, text: 'እርሱም በመጀመሪያ በእግዚአብሔር ዘንድ ነበረ።' },
      { verse: 3, text: 'ሁሉ ነገር በእርሱ ተፈጠረ፤ ከተፈጠረው አንዳች እንኳ ያለ እርሱ አልተፈጠረም።' },
      { verse: 4, text: 'ሕይወት በእርሱ ነበረች፤ ይህችም ሕይወት የሰው ብርሃን ነበረች።' },
      { verse: 5, text: 'ብርሃንም በጨለማ ያበራል፤ ጨለማው ግን አላሸነፈውም።' },
      { verse: 12, text: 'ለተቀበሉትና በስሙ ላመኑት ሁሉ ግን፣ የእግዚአብሔር ልጆች የመሆን መብት ሰጣቸው።' },
      { verse: 14, text: 'ቃል ሥጋ ሆነ፤ በመካከላችንም አደረ፤ እኛም ከአባቱ ዘንድ እንደ መጣ አንድያ ልጅ ክብር የሆነውን ክብሩን አየን፤ እርሱም ጸጋንና እውነትን የተመላ ነበር።' },
    ],
    '1954': [
      { verse: 1, text: 'በመጀመሪያው ቃል ነበረ፥ ቃልም በእግዚአብሔር ዘንድ ነበረ፥ ቃልም እግዚአብሔር ነበረ።' },
      { verse: 2, text: 'ይህ በመጀመሪያው በእግዚአብሔር ዘንድ ነበረ።' },
      { verse: 3, text: 'ሁሉ በእርሱ ሆነ፥ ከሆነውም አንዳች ስንኳ ያለ እርሱ አልሆነም።' },
      { verse: 4, text: 'በእርሱ ሕይወት ነበረች፥ ሕይወትም የሰው ብርሃን ነበረች።' },
      { verse: 5, text: 'ብርሃንም በጨለማ ይበራል፥ ጨለማውም አላሸነፈውም።' },
      { verse: 12, text: 'ለተቀበሉት ሁሉ ግን፥ በስሙ ለሚያምኑት ለእነርሱ የእግዚአብሔር ልጆች ይሆኑ ዘንድ ሥልጣንን ሰጣቸው፤' },
      { verse: 14, text: 'ቃልም ሥጋ ሆነ፤ ጸጋንና እውነትንም ተሞልቶ በእኛ አደረ፥ አንድ ልጅም ከአባቱ ዘንድ እንዳለው ክብር የሆነው ክብሩን አየን።' },
    ],
  },

  // Romans 8 (ሮሜ 8)
  'ሮሜ_8': {
    nasv: [
      { verse: 1, text: 'እንግዲህ አሁን በክርስቶስ ኢየሱስ ላሉት ኵነኔ የለባቸውም።' },
      { verse: 28, text: 'እግዚአብሔር ለሚወዱትና እንደ ዐላማው ለተጠሩት፣ ነገር ሁሉ ተያይዞ ለበጎ እንዲሠራ እንደሚያደርግ እናውቃለን።' },
      { verse: 31, text: 'ታዲያ፣ ለእነዚህ ነገሮች ምን እንላለን? እግዚአብሔር ከእኛ ጋር ከሆነ ማን ሊቃወመን ይችላል?' },
      { verse: 38, text: 'ሞት ቢሆን፣ ሕይወትም ቢሆን፣ መላእክትም ቢሆኑ፣ አጋንንትም ቢሆኑ፣ ያለውም ቢሆን፣ የሚመጣውም ቢሆን ወይም ማንኛውም ኀይል፣' },
      { verse: 39, text: 'ከፍታም ቢሆን፣ ዝቅታም ቢሆን፣ ወይም ሌላ ማናቸውም ፍጥረት በጌታችን በክርስቶስ ኢየሱስ ካለው ከእግዚአብሔር ፍቅር ሊለየን እንደማይችል ርግጠኛ ነኝ።' },
    ],
    '1954': [
      { verse: 1, text: 'እንግዲህ በክርስቶስ ኢየሱስ ላሉት አሁን ኵነኔ የለባቸውም።' },
      { verse: 28, text: 'እግዚአብሔርንም ለሚወዱት እንደ አሳቡም ለተጠሩት ነገር ሁሉ ለበጎ እንዲደረግ እናውቃለን።' },
      { verse: 31, text: 'እንግዲህ ስለዚህ ነገር ምን እንላለን? እግዚአብሔር ከእኛ ጋር ከሆነ ማን ይቃወመናል?' },
      { verse: 38, text: 'ሞት ቢሆን፥ ሕይወትም ቢሆን፥ መላእክትም ቢሆኑ፥ ግዛትም ቢሆን፥ ያለውም ቢሆን፥ የሚመጣውም ቢሆን፥ ኃይላትም ቢሆኑ፥' },
      { verse: 39, text: 'ከፍታም ቢሆን፥ ዝቅታም ቢሆን፥ ልዩ ፍጥረትም ቢሆን በክርስቶስ ኢየሱስ በጌታችን ካለ ከእግዚአብሔር ፍቅር ሊለየን እንዳይችል ተረድቼአለሁ።' },
    ],
  },
};

/**
 * Utility to parse reading plan passage strings into structured book and chapters
 * e.g. "ዘፍጥረት 1-3" -> { bookName: "ዘፍጥረት", startChapter: 1, endChapter: 3 }
 *      "ማቴዎስ 5" -> { bookName: "ማቴዎስ", startChapter: 5, endChapter: 5 }
 */
export function parsePassageRange(passageStr: string): { bookName: string; startChapter: number; endChapter: number; matchedBook: BibleBookInfo | undefined } {
  if (!passageStr) {
    return { bookName: 'ዘፍጥረት', startChapter: 1, endChapter: 1, matchedBook: BIBLE_BOOKS[0] };
  }

  // Remove parenthesis or extra notes
  const clean = passageStr.trim().replace(/\(.*?\)/g, '');
  const match = clean.match(/^([^\d]+)\s*(\d+)(?:\s*-\s*(\d+))?/);

  if (match) {
    const rawBook = match[1].trim();
    const start = parseInt(match[2], 10) || 1;
    const end = match[3] ? parseInt(match[3], 10) : start;

    // Find in BIBLE_BOOKS
    const matchedBook = BIBLE_BOOKS.find(
      (b) =>
        b.nameAm.includes(rawBook) ||
        rawBook.includes(b.nameAm) ||
        b.shortAm === rawBook ||
        b.nameEn.toLowerCase() === rawBook.toLowerCase()
    ) || BIBLE_BOOKS.find((b) => b.nameAm === 'ዘፍጥረት');

    return {
      bookName: matchedBook ? matchedBook.nameAm : rawBook,
      startChapter: start,
      endChapter: Math.max(start, end),
      matchedBook,
    };
  }

  return { bookName: 'ዘፍጥረት', startChapter: 1, endChapter: 1, matchedBook: BIBLE_BOOKS[0] };
}
