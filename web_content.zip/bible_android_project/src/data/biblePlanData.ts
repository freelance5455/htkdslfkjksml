import { MonthInfo, ReadingDay } from '../types';

export const ETHIOPIAN_MONTHS: MonthInfo[] = [
  { index: 0, name: 'መስከረም', nameEnglish: 'Meskerem', daysCount: 30, startDay: 1, endDay: 30, theme: 'የፍጥረትና የአባቶች ዘመን (ዘፍጥረት እና ዘጸአት)' },
  { index: 1, name: 'ጥቅምት', nameEnglish: 'Tikimt', daysCount: 30, startDay: 31, endDay: 60, theme: 'የቃል ኪዳኑ ሕግና ስርዓት (ዘጸአት እና ዘሌዋውያን)' },
  { index: 2, name: 'ኅዳር', nameEnglish: 'Hidar', daysCount: 30, startDay: 61, endDay: 90, theme: 'የምድረ በዳ ጉዞና ተስፋ (ዘኍልቍ እና ዘዳግም)' },
  { index: 3, name: 'ታኅሣሥ', nameEnglish: 'Tahsas', daysCount: 30, startDay: 91, endDay: 120, theme: 'የተስፋይቱ ምድር ድልና መሳፍንት (ኢያሱ እና መሳፍንት)' },
  { index: 4, name: 'ጥር', nameEnglish: 'Tir', daysCount: 30, startDay: 121, endDay: 150, theme: 'የንጉሦች መጀመሪያና የዳዊት ታሪክ (1 እና 2 ሳሙኤል)' },
  { index: 5, name: 'የካቲት', nameEnglish: 'Yekatit', daysCount: 30, startDay: 151, endDay: 180, theme: 'የሰሎሞን ጥበብና የመንግሥት መከፈል (1 እና 2 ነገሥት)' },
  { index: 6, name: 'መጋቢት', nameEnglish: 'Megabit', daysCount: 30, startDay: 181, endDay: 210, theme: 'የእግዚአብሔር ታማኝነት በታሪክ (1 እና 2 ዜና መዋዕል)' },
  { index: 7, name: 'ሚያዝያ', nameEnglish: 'Miyazya', daysCount: 30, startDay: 211, endDay: 240, theme: 'ተመልሶ መታነጽና የኢዮብ ትዕግሥት (ዕዝራ፣ ነህምያ፣ አስቴር፣ ኢዮብ)' },
  { index: 8, name: 'ግንቦት', nameEnglish: 'Ginbot', daysCount: 30, startDay: 241, endDay: 270, theme: 'የምስጋናና የጸሎት መዝሙራት (መዝሙረ ዳዊት 1-89)' },
  { index: 9, name: 'ሰኔ', nameEnglish: 'Sene', daysCount: 30, startDay: 271, endDay: 300, theme: 'የጥበብ ምክርና የምስጋና ፍጻሜ (መዝሙር፣ ምሳሌ፣ መክብብ)' },
  { index: 10, name: 'ሐምሌ', nameEnglish: 'Hamle', daysCount: 30, startDay: 301, endDay: 330, theme: 'የታላላቅ ነቢያት ትንቢት (ኢሳይያስ እና ኤርምያስ)' },
  { index: 11, name: 'ነሐሴ', nameEnglish: 'Nehase', daysCount: 30, startDay: 331, endDay: 360, theme: 'የተስፋ ራእይና የደቂቀ ነቢያት መልእክት (ሕዝቅኤል፣ ዳንኤል፣ 12ቱ ነቢያት)' },
  { index: 12, name: 'ጳጉሜ', nameEnglish: 'Pagume', daysCount: 5, startDay: 361, endDay: 365, theme: 'የድነት ምሥራችና የትንሣኤ ክብር (አራቱ ወንጌላትና የዮሐንስ ራእይ)' },
];

// Helper to generate realistic, accurate sequential scripture reading chunks
interface ScheduleEntry {
  book: string;
  bookEn: string;
  passage: string;
  passageEn: string;
  testament: 'ብሉይ ኪዳን' | 'ሐዲስ ኪዳን';
  theme: string;
  themeEn: string;
  verseRef: string;
  verseRefEn: string;
  verseText: string;
  verseTextEn: string;
  reflection: string;
  reflectionEn: string;
}

// Generate schedule entries covering the Old & New Testaments
const RAW_READING_CHUNKS: ScheduleEntry[] = [
  // Month 0: Meskerem (Days 1-30) - Genesis 1 to Exodus 10
  { book: 'ዘፍጥረት', bookEn: 'Genesis', passage: 'ዘፍጥረት 1-3', passageEn: 'Genesis 1-3', testament: 'ብሉይ ኪዳን', theme: 'ፍጥረትና የመጀመሪያው ሰው', themeEn: 'Creation and Fall', verseRef: 'ዘፍ 1:1', verseRefEn: 'Gen 1:1', verseText: 'በመጀመሪያ እግዚአብሔር ሰማይንና ምድርን ፈጠረ።', verseTextEn: 'In the beginning God created the heaven and the earth.', reflection: 'እግዚአብሔር ሁሉን ነገር በሥርዓትና በውበት ፈጠረ። የሕይወትህ ፈጣሪ እርሱ መሆኑን አስታውስ።', reflectionEn: 'God created everything with divine purpose and beauty. Remember He is your maker.' },
  { book: 'ዘፍጥረት', bookEn: 'Genesis', passage: 'ዘፍጥረት 4-7', passageEn: 'Genesis 4-7', testament: 'ብሉይ ኪዳን', theme: 'ቃየንና አቤል፤ የኖኅ መርከብ', themeEn: 'Cain & Abel; Noah\'s Ark', verseRef: 'ዘፍ 6:8', verseRefEn: 'Gen 6:8', verseText: 'ኖኅ ግን በእግዚአብሔር ፊት ሞገስን አገኘ።', verseTextEn: 'Noah found grace in the eyes of the Lord.', reflection: 'በኃጢአት በተሞላ ዓለም ውስጥ በጽድቅ መመላለስ ይቻላል።', reflectionEn: 'Walking in righteousness is possible even in a challenging world.' },
  { book: 'ዘፍጥረት', bookEn: 'Genesis', passage: 'ዘፍጥረት 8-10', passageEn: 'Genesis 8-10', testament: 'ብሉይ ኪዳን', theme: 'የጥፋት ውሃ ማብቃትና የቃል ኪዳን ቀስተ ደመና', themeEn: 'The Flood Subsides; The Rainbow', verseRef: 'ዘፍ 9:13', verseRefEn: 'Gen 9:13', verseText: 'ቀስቴን በደመና አደርጋለሁ፥ በእኔና በምድር መካከል ላለው ቃል ኪዳን ምልክት ይሆናል።', verseTextEn: 'I do set my bow in the cloud, and it shall be for a token of a covenant.', reflection: 'እግዚአብሔር የገባውን ቃል ኪዳን ፈጽሞ አይረሳም።', reflectionEn: 'God never forgets His sacred covenants.' },
  { book: 'ዘፍጥረት', bookEn: 'Genesis', passage: 'ዘፍጥረት 11-13', passageEn: 'Genesis 11-13', testament: 'ብሉይ ኪዳን', theme: 'የባቢሎን ግንብና የአብርሃም መጠራት', themeEn: 'Tower of Babel; Abram Called', verseRef: 'ዘፍ 12:2', verseRefEn: 'Gen 12:2', verseText: 'ታላቅ ሕዝብም አደርግሃለሁ፥ እባርክሃለሁ፥ ስምህንም አከብረዋለሁ፤ ለበረከትም ሁን።', verseTextEn: 'I will make of thee a great nation, and I will bless thee.', reflection: 'የእምነት ጉዞ የሚጀምረው ለእግዚአብሔር ጥሪ ፈቃደኛ በመሆን ነው።', reflectionEn: 'The walk of faith begins with stepping out in obedience.' },
  { book: 'ዘፍጥረት', bookEn: 'Genesis', passage: 'ዘፍጥረት 14-16', passageEn: 'Genesis 14-16', testament: 'ብሉይ ኪዳን', theme: 'መልከ ጼዴቅና የተስፋው ቃል ኪዳን', themeEn: 'Melchizedek & Abram\'s Covenant', verseRef: 'ዘፍ 15:6', verseRefEn: 'Gen 15:6', verseText: 'አብራምም በእግዚአብሔር አመነ፥ ጽድቅም ሆኖ ተቆጠረለት።', verseTextEn: 'And he believed in the Lord; and he counted it to him for righteousness.', reflection: 'በእግዚአብሔር ማመን ለሕይወት ጽድቅና ሰላም መሠረት ነው።', reflectionEn: 'Faith in God is accounted as righteousness.' },
  { book: 'ዘፍጥረት', bookEn: 'Genesis', passage: 'ዘፍጥረት 17-20', passageEn: 'Genesis 17-20', testament: 'ብሉይ ኪዳን', theme: 'የግዝረት ምልክት፤ ሶዶምና ገሞራ', themeEn: 'Sign of Circumcision; Sodom', verseRef: 'ዘፍ 18:14', verseRefEn: 'Gen 18:14', verseText: 'በእውኑ ለእግዚአብሔር የሚሳነው ነገር አለን?', verseTextEn: 'Is any thing too hard for the Lord?', reflection: 'ለፈጣሪ የሚሳነው አንዳች ነገር የለም፤ በተስፋው ታመን።', reflectionEn: 'Nothing is too hard for the Almighty.' },
  { book: 'ዘፍጥረት', bookEn: 'Genesis', passage: 'ዘፍጥረት 21-23', passageEn: 'Genesis 21-23', testament: 'ብሉይ ኪዳን', theme: 'የይስሐቅ መወለድና የአብርሃም ፈተና', themeEn: 'Birth of Isaac; The Sacrifice of Faith', verseRef: 'ዘፍ 22:14', verseRefEn: 'Gen 22:14', verseText: 'አብርሃምም የዚያን ቦታ ስም እግዚአብሔር ያዘጋጃል ብሎ ጠራው።', verseTextEn: 'And Abraham called the name of that place Jehovah-jireh.', reflection: 'እግዚአብሔር በጊዜው ለሚያስፈልገን ሁሉ ያዘጋጃል (ይርኤ)።', reflectionEn: 'The Lord will provide at the appointed mountain.' },
  { book: 'ዘፍጥረት', bookEn: 'Genesis', passage: 'ዘፍጥረት 24-26', passageEn: 'Genesis 24-26', testament: 'ብሉይ ኪዳን', theme: 'ርብቃና ይስሐቅ፤ ያዕቆብና ዔሳው', themeEn: 'Rebekah & Isaac; Jacob & Esau', verseRef: 'ዘፍ 26:24', verseRefEn: 'Gen 26:24', verseText: 'አትፍራ፥ እኔ ከአንተ ጋር ነኝና፤ እባርክሃለሁም።', verseTextEn: 'Fear not, for I am with thee, and will bless thee.', reflection: 'የእግዚአብሔር አብሮነት የፍርሃት ሁሉ መድኃኒት ነው።', reflectionEn: 'God\'s presence dispels every fear and brings blessing.' },
  { book: 'ዘፍጥረት', bookEn: 'Genesis', passage: 'ዘፍጥረት 27-29', passageEn: 'Genesis 27-29', testament: 'ብሉይ ኪዳን', theme: 'የያዕቆብ የቤቴል ሕልም፤ የላባ ቤት', themeEn: 'Jacob\'s Ladder at Bethel; Laban', verseRef: 'ዘፍ 28:15', verseRefEn: 'Gen 28:15', verseText: 'እነሆም እኔ ከአንተ ጋር ነኝ፥ በምትሄድበትም ሁሉ እጠብቅሃለሁ።', verseTextEn: 'Behold, I am with thee, and will keep thee in all places whither thou goest.', reflection: 'በብቸኝነትህ ወቅት እንኳን የሰማይ መላእክት የሚያገለግሉህ አምላክ ከአንተ ጋር ነው።', reflectionEn: 'Even in lonely wilderness, God watches over your steps.' },
  { book: 'ዘፍጥረት', bookEn: 'Genesis', passage: 'ዘፍጥረት 30-33', passageEn: 'Genesis 30-33', testament: 'ብሉይ ኪዳን', theme: 'ያዕቆብ ከመልአክ ጋር መታገሉና እርቅ', themeEn: 'Jacob Wrestles; Reconciliation', verseRef: 'ዘፍ 32:28', verseRefEn: 'Gen 32:28', verseText: 'ከእግዚአብሔርና ከሰው ጋር ታግለህ አሸንፈሃልና ስምህ እንግዲህ እስራኤል ይባል እንጂ ያዕቆብ አይባል አለው።', verseTextEn: 'Thy name shall be called no more Jacob, but Israel.', reflection: 'ጸሎት ሕይወትንና ስምን የሚቀይር ኃይል አለው።', reflectionEn: 'Earnest prayer transforms our heart and identity.' },
  { book: 'ዘፍጥረት', bookEn: 'Genesis', passage: 'ዘፍጥረት 34-36', passageEn: 'Genesis 34-36', testament: 'ብሉይ ኪዳን', theme: 'ወደ ቤቴል መመለስና የያዕቆብ ልጆች', themeEn: 'Return to Bethel; Jacob\'s Sons', verseRef: 'ዘፍ 35:3', verseRefEn: 'Gen 35:3', verseText: 'ተነሥተን ወደ ቤቴል እንውጣ፤ በመከራዬ ቀን ለሰማኝ በሄድሁበትም መንገድ ከእኔ ጋር ለነበረው ለአምላክ በዚያ መሠዊያ እሠራለሁ።', verseTextEn: 'Let us arise, and go up to Bethel; and I will make there an altar unto God.', reflection: 'ወደ መጀመሪያው ፍቅርና የእምነት መሠዊያ መመለስ በረከትን ያድሳል።', reflectionEn: 'Returning to God\'s altar renews spiritual clarity.' },
  { book: 'ዘፍጥረት', bookEn: 'Genesis', passage: 'ዘፍጥረት 37-39', passageEn: 'Genesis 37-39', testament: 'ብሉይ ኪዳን', theme: 'የዮሴፍ ሕልምና በግብጽ ባርነት መሸጡ', themeEn: 'Joseph\'s Dreams; Sold to Egypt', verseRef: 'ዘፍ 39:2', verseRefEn: 'Gen 39:2', verseText: 'እግዚአብሔርም ከዮሴፍ ጋር ነበረ፥ ሥራውም የተከናወነለት ሰው ሆነ።', verseTextEn: 'And the Lord was with Joseph, and he was a prosperous man.', reflection: 'በአስቸጋሪ ሁኔታ ውስጥም እግዚአብሔር አብሮህ ከሆነ ስኬትህ አይቀርም።', reflectionEn: 'Even in unfair circumstances, God\'s presence makes you thrive.' },
  { book: 'ዘፍጥረት', bookEn: 'Genesis', passage: 'ዘፍጥረት 40-42', passageEn: 'Genesis 40-42', testament: 'ብሉይ ኪዳን', theme: 'የፈርዖን ሕልም፤ የዮሴፍ ከፍታ', themeEn: 'Pharaoh\'s Dreams; Joseph Exalted', verseRef: 'ዘፍ 41:38', verseRefEn: 'Gen 41:38', verseText: 'ፈርዖንም አገልጋዮቹን፦ የእግዚአብሔር መንፈስ ያለበትን እንደዚህ ያለውን ሰው እናገኝ ይሆንን? አላቸው።', verseTextEn: 'Can we find such a one as this is, a man in whom the Spirit of God is?', reflection: 'የመንፈስ ቅዱስ ጥበብ በየትኛውም ስፍራ የክብር ማዕረግ ይሰጣል።', reflectionEn: 'God\'s Spirit gives wisdom that stands before kings.' },
  { book: 'ዘፍጥረት', bookEn: 'Genesis', passage: 'ዘፍጥረት 43-46', passageEn: 'Genesis 43-46', testament: 'ብሉይ ኪዳን', theme: 'ዮሴፍ ለወንድሞቹ መገለጡና ዕርቅ', themeEn: 'Joseph Revealed to Brothers; Goshen', verseRef: 'ዘፍ 45:5', verseRefEn: 'Gen 45:5', verseText: 'አሁንም እኔን ወደዚህ ስለ ሸጣችሁኝ አትዘኑ፥ አትቆጩም፤ ሕይወትን ለማዳን እግዚአብሔር ከእናንተ በፊት ሰድዶኛልና።', verseTextEn: 'Be not grieved... for God did send me before you to preserve life.', reflection: 'ይቅርታ የቆሰለውን ታሪክ ወደ ድንቅ መዳን ይለውጠዋል።', reflectionEn: 'Forgiveness turns past pain into divine redemption.' },
  { book: 'ዘፍጥረት', bookEn: 'Genesis', passage: 'ዘፍጥረት 47-50', passageEn: 'Genesis 47-50', testament: 'ብሉይ ኪዳን', theme: 'የያዕቆብ ምርቃትና የዮሴፍ ተስፋ', themeEn: 'Jacob\'s Blessing; Hope of Return', verseRef: 'ዘፍ 50:20', verseRefEn: 'Gen 50:20', verseText: 'እናንተ ክፉ ነገር አሰባችሁብኝ፤ እግዚአብሔር ግን ዛሬ እንደ ሆነው ብዙ ሕዝብ እንዲድን ለበጎ ነገር አሰበው።', verseTextEn: 'Ye thought evil against me; but God meant it unto good.', reflection: 'ሰዎች ክፉ ሲያስቡ እግዚአብሔር ለበጎ ይለውጠዋል።', reflectionEn: 'What was intended to harm you, God transforms for good.' },
  { book: 'ዘጸአት', bookEn: 'Exodus', passage: 'ዘጸአት 1-3', passageEn: 'Exodus 1-3', testament: 'ብሉይ ኪዳን', theme: 'የእስራኤል ጭንቀት፤ የሙሴ መጠራት', themeEn: 'Oppression in Egypt; Moses & Burning Bush', verseRef: 'ዘጸ 3:14', verseRefEn: 'Exod 3:14', verseText: 'እግዚአብሔርም ሙሴን፦ «ያለና የሚኖር» እኔ ነኝ አለው።', verseTextEn: 'And God said unto Moses, I AM THAT I AM.', reflection: 'የሚነደው ቁጥቋጦ እግዚአብሔር በድካማችን ውስጥ ቅዱስ መገኘቱን እንደሚገልጥ ያስተምረናል።', reflectionEn: 'God meets us in our humble places with His holy presence.' },
  { book: 'ዘጸአት', bookEn: 'Exodus', passage: 'ዘጸአት 4-6', passageEn: 'Exodus 4-6', testament: 'ብሉይ ኪዳን', theme: 'የሙሴ ምልክቶችና የፈርዖን እምቢታ', themeEn: 'Signs Given to Moses; Pharaoh\'s Refusal', verseRef: 'ዘጸ 6:7', verseRefEn: 'Exod 6:7', verseText: 'ለሕዝብም እወስዳችኋለሁ፥ አምላክም እሆናችኋለሁ።', verseTextEn: 'I will take you to me for a people, and I will be to you a God.', reflection: 'እግዚአብሔር ሕዝቡን ከባርነት ነፃ የማውጣት ታማኝ አምላክ ነው።', reflectionEn: 'God is faithful to liberate His beloved people.' },
  { book: 'ዘጸአት', bookEn: 'Exodus', passage: 'ዘጸአት 7-10', passageEn: 'Exodus 7-10', testament: 'ብሉይ ኪዳን', theme: 'የግብጽ መቅሰፍቶች', themeEn: 'The Plagues of Egypt', verseRef: 'ዘጸ 9:16', verseRefEn: 'Exod 9:16', verseText: 'ኃይሌን እንዳሳይህ፥ ስሜም በምድር ሁሉ ላይ እንዲነገር ስለዚህ አስነስቼሃለሁ።', verseTextEn: 'That my name may be declared throughout all the earth.', reflection: 'የእግዚአብሔር ስምና ሉዓላዊነት በዓለም ሁሉ ላይ ታላቅ ነው።', reflectionEn: 'The sovereignty of God is displayed throughout history.' },
  { book: 'ዘጸአት', bookEn: 'Exodus', passage: 'ዘጸአት 11-13', passageEn: 'Exodus 11-13', testament: 'ብሉይ ኪዳን', theme: 'የፋሲካ በዓልና የበኩር ልጆች ድነት', themeEn: 'The Passover; Deliverance of Firstborn', verseRef: 'ዘጸ 12:13', verseRefEn: 'Exod 12:13', verseText: 'ደሙም ባላችሁበት ቤቶች ላይ ምልክት ይሆንላችኋል፤ ደሙንም ባየሁ ጊዜ ከእናንተ አልፋለሁ።', verseTextEn: 'When I see the blood, I will pass over you.', reflection: 'የፋሲካው በግ ደም የመዳናችንና የጥበቃችን ዋስትና ነው።', reflectionEn: 'The sacrificial blood represents divine protection and salvation.' },
  { book: 'ዘጸአት', bookEn: 'Exodus', passage: 'ዘጸአት 14-16', passageEn: 'Exodus 14-16', testament: 'ብሉይ ኪዳን', theme: 'ቀይ ባሕር መከፈሉና የሰማይ መና', themeEn: 'Red Sea Crossing; Manna in the Desert', verseRef: 'ዘጸ 14:14', verseRefEn: 'Exod 14:14', verseText: 'እግዚአብሔር ይዋጋላችኋል፥ እናንተም ዝም ትላላችሁ።', verseTextEn: 'The Lord shall fight for you, and ye shall hold your peace.', reflection: 'ተስፋ በሚያስቆርጡ ሁኔታዎች ውስጥ እግዚአብሔር መንገድ ያዘጋጃል።', reflectionEn: 'When there seems no way forward, God parts the deep waters.' },
  { book: 'ዘጸአት', bookEn: 'Exodus', passage: 'ዘጸአት 17-20', passageEn: 'Genesis 17-20', testament: 'ብሉይ ኪዳን', theme: 'የአሥርቱ ቃላት ሕግ በሲና ተራራ', themeEn: 'The Ten Commandments at Mount Sinai', verseRef: 'ዘጸ 20:3', verseRefEn: 'Exod 20:3', verseText: 'ከእኔ በቀር ሌሎች አማልክት አይሁኑልህ።', verseTextEn: 'Thou shalt have no other gods before me.', reflection: 'የእግዚአብሔር ሕግ ፍቅርን፣ ቅድስናንና ሰላምን የሚያስተምር መመሪያ ነው።', reflectionEn: 'God\'s law guides our hearts toward holy fellowship.' },
  { book: 'ዘጸአት', bookEn: 'Exodus', passage: 'ዘጸአት 21-24', passageEn: 'Exodus 21-24', testament: 'ብሉይ ኪዳን', theme: 'የፍትሕ ሕግጋትና የቃል ኪዳኑ ማረጋገጫ', themeEn: 'Laws of Justice; Covenant Confirmed', verseRef: 'ዘጸ 24:7', verseRefEn: 'Exod 24:7', verseText: 'የቃል ኪዳኑን መጽሐፍ ወስዶ ለሕዝቡ አነበበላቸው፤ እነርሱም፦ እግዚአብሔር ያለውን ሁሉ እናደርጋለን እንታዘዛለንም አሉ።', verseTextEn: 'All that the Lord hath said will we do, and be obedient.', reflection: 'የእግዚአብሔርን ቃል መስማት ብቻ ሳይሆን በተግባር መታዘዝ ሕይወት ነው።', reflectionEn: 'Living in obedience brings the blessings of the covenant.' },
  { book: 'ዘጸአት', bookEn: 'Exodus', passage: 'ዘጸአት 25-28', passageEn: 'Exodus 25-28', testament: 'ብሉይ ኪዳን', theme: 'የማደሪያው ድንኳንና የክህነት አልባሳት', themeEn: 'The Tabernacle & Priestly Garments', verseRef: 'ዘጸ 25:8', verseRefEn: 'Exod 25:8', verseText: 'በመካከላቸውም አድር ዘንድ መቅደስ ይሥሩልኝ።', verseTextEn: 'And let them make me a sanctuary; that I may dwell among them.', reflection: 'እግዚአብሔር በሕዝቡ ልብ ውስጥ ማደርን ይናፍቃል።', reflectionEn: 'God desires to dwell in the midst of His people.' },
  { book: 'ዘጸአት', bookEn: 'Exodus', passage: 'ዘጸአት 29-32', passageEn: 'Exodus 29-32', testament: 'ብሉይ ኪዳን', theme: 'የወርቁ ጥጃ ጣዖትና የሙሴ አማላጅነት', themeEn: 'Golden Calf; Moses\' Intercession', verseRef: 'ዘጸ 32:11', verseRefEn: 'Exod 32:11', verseText: 'ሙሴም በአምላኩ በእግዚአብሔር ፊት ጸለየ... እግዚአብሔርም በሕዝቡ ላይ ሊያደርግ ካሰበው ክፉ ነገር ተጸጸተ።', verseTextEn: 'And Moses besought the Lord his God.', reflection: 'አማላጅነትና የጸሎት ጩኸት የምሕረትን በር ይከፍታል።', reflectionEn: 'Intercessory prayer stands in the gap to bring mercy.' },
  { book: 'ዘጸአት', bookEn: 'Exodus', passage: 'ዘጸአት 33-36', passageEn: 'Exodus 33-36', testament: 'ብሉይ ኪዳን', theme: 'የእግዚአብሔር ክብር፤ የኪዳኑ ሰሌዳዎች መታደስ', themeEn: 'God\'s Glory Revealed; Tablets Renewed', verseRef: 'ዘጸ 33:14', verseRefEn: 'Exod 33:14', verseText: 'እርሱም፦ ገጼ ከአንተ ጋር ይሄዳል፥ እኔም አሳርፍሃለሁ አለው።', verseTextEn: 'My presence shall go with thee, and I will give thee rest.', reflection: 'የእግዚአብሔር መገኘት ከምንም በላይ ታላቅ ዕረፍትና ዋስትና ነው።', reflectionEn: 'His abiding presence is the true sanctuary of our soul.' },
  { book: 'ዘጸአት', bookEn: 'Exodus', passage: 'ዘጸአት 37-40', passageEn: 'Exodus 37-40', testament: 'ብሉይ ኪዳን', theme: 'የማደሪያው ድንኳን መጠናቀቅና የክብር ደመና', themeEn: 'Tabernacle Erected; Glory Fills Sanctuary', verseRef: 'ዘጸ 40:34', verseRefEn: 'Exod 40:34', verseText: 'ደመናውም የመገናኛውን ድንኳን ከደነው፥ የእግዚአብሔርም ክብር ማደሪያውን ሞላው።', verseTextEn: 'Then a cloud covered the tent... and the glory of the Lord filled the tabernacle.', reflection: 'ሁሉን በፈቃዱ ስንሠራ ክብሩ በሕይወታችን ይገለጣል።', reflectionEn: 'When we walk in obedience, God\'s glory fills our living space.' },
  { book: 'ዘሌዋውያን', bookEn: 'Leviticus', passage: 'ዘሌዋውያን 1-4', passageEn: 'Leviticus 1-4', testament: 'ብሉይ ኪዳን', theme: 'የሚቃጠልና የኃጢአት መሥዋዕት ስርዓት', themeEn: 'Laws of Burnt Offering and Sin Offering', verseRef: 'ዘሌ 1:4', verseRefEn: 'Lev 1:4', verseText: 'እጁንም በሚቃጠለው መሥዋዕት ራስ ላይ ይጭናል፥ እንዲሰረይለትም የተወደደ ሆኖ ይቀበልለታል።', verseTextEn: 'He shall put his hand upon the head of the burnt offering; and it shall be accepted.', reflection: 'ክርስቶስ ፍጹም መሥዋዕት ሆኖ የኃጢአታችንን ዕዳ ከፈለልን።', reflectionEn: 'Christ is our once-for-all spotless offering.' },
  { book: 'ዘሌዋውያን', bookEn: 'Leviticus', passage: 'ዘሌዋውያን 5-8', passageEn: 'Leviticus 5-8', testament: 'ብሉይ ኪዳን', theme: 'የካህናት ቅድስናና አገልግሎት', themeEn: 'Consecration of Priests', verseRef: 'ዘሌ 8:30', verseRefEn: 'Lev 8:30', verseText: 'ሙሴም ከቅብዓቱ ዘይትና ከመሠዊያው ላይ ካለው ደም ወሰደ፥ በአሮንና በልብሱም ላይ ረጨው... አሮንንና ልብሱን ቀደሰ።', verseTextEn: 'And Moses took of the anointing oil... and sanctified Aaron.', reflection: 'ለእግዚአብሔር ክብር የተለየ ሕይወት ቅዱስና ንጹሕ ነው።', reflectionEn: 'Dedication of heart and action honors the Lord.' },
  { book: 'ዘሌዋውያን', bookEn: 'Leviticus', passage: 'ዘሌዋውያን 9-12', passageEn: 'Leviticus 9-12', testament: 'ብሉይ ኪዳን', theme: 'የመጀመሪያው መሥዋዕትና የንጽሕና ሕግጋት', themeEn: 'Fire from the Lord; Dietary Laws', verseRef: 'ዘሌ 11:44', verseRefEn: 'Lev 11:44', verseText: 'እኔ እግዚአብሔር አምላካችሁ ነኝና፤ ሰውነታችሁን ቀድሱ፥ እኔ ቅዱስ ነኝና እናንተም ቅዱሳን ሁኑ።', verseTextEn: 'Ye shall therefore sanctify yourselves, and ye shall be holy; for I am holy.', reflection: 'ቅድስና የእግዚአብሔር ባሕርይ ሲሆን የእኛም የዕለት ተዕለት ጥሪ ነው።', reflectionEn: 'Holy living reflects our Father in Heaven.' },
  { book: 'ዘሌዋውያን', bookEn: 'Leviticus', passage: 'ዘሌዋውያን 13-16', passageEn: 'Leviticus 13-16', testament: 'ብሉይ ኪዳን', theme: 'የስርየት ቀን ስርዓት (ዮም ኪፑር)', themeEn: 'The Day of Atonement (Yom Kippur)', verseRef: 'ዘሌ 16:30', verseRefEn: 'Lev 16:30', verseText: 'በዚህ ቀን በእግዚአብሔር ፊት ከኃጢአታችሁ ሁሉ ትነጹ ዘንድ ስርየት ይደረግላችኋልና።', verseTextEn: 'On that day shall the priest make an atonement for you, to cleanse you.', reflection: 'በእግዚአብሔር ምሕረት ሙሉ ይቅርታና አዲስ ጅማሮ እናገኛለን።', reflectionEn: 'In God\'s grace we find renewal and cleansing of conscience.' },
];

// Helper to create all 365 days seamlessly
export function generate365BiblePlan(): ReadingDay[] {
  const days: ReadingDay[] = [];

  // Month day limits: 30 for 0-11, 5 for 12
  const monthDayLimits = [30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 5];

  // Comprehensive Book mappings across remaining months
  const bookProgression = [
    // Month 1 (Tikimt: 31-60) - Leviticus 17-27, Numbers 1-20
    { book: 'ዘሌዋውያን', bookEn: 'Leviticus', range: 'ዘሌዋውያን 17-27 & ዘኍልቍ 1-20', testament: 'ብሉይ ኪዳን' },
    // Month 2 (Hidar: 61-90) - Numbers 21-36, Deuteronomy 1-20
    { book: 'ዘዳግም', bookEn: 'Deuteronomy', range: 'ዘኍልቍ 21-36 & ዘዳግም 1-20', testament: 'ብሉይ ኪዳን' },
    // Month 3 (Tahsas: 91-120) - Deuteronomy 21-34, Joshua 1-24, Judges 1-10
    { book: 'ኢያሱ', bookEn: 'Joshua', range: 'ዘዳግም 21-34፣ ኢያሱ 1-24፣ መሳፍንት', testament: 'ብሉይ ኪዳን' },
    // Month 4 (Tir: 121-150) - Judges 11-21, Ruth, 1 Samuel 1-31
    { book: '1 ሳሙኤል', bookEn: '1 Samuel', range: 'መሳፍንት 11-21፣ ሩት 1-4፣ 1 ሳሙኤል', testament: 'ብሉይ ኪዳን' },
    // Month 5 (Yekatit: 151-180) - 2 Samuel, 1 Kings 1-22
    { book: '1 ነገሥት', bookEn: '1 Kings', range: '2 ሳሙኤል 1-24፣ 1 ነገሥት 1-22', testament: 'ብሉይ ኪዳን' },
    // Month 6 (Megabit: 181-210) - 2 Kings, 1 Chronicles 1-29
    { book: '1 ዜና መዋዕል', bookEn: '1 Chronicles', range: '2 ነገሥት 1-25፣ 1 ዜና መዋዕል', testament: 'ብሉይ ኪዳን' },
    // Month 7 (Miyazya: 211-240) - 2 Chronicles, Ezra, Nehemiah, Esther, Job 1-20
    { book: 'ኢዮብ', bookEn: 'Job', range: '2 ዜና፣ ዕዝራ፣ ነህምያ፣ አስቴር፣ ኢዮብ', testament: 'ብሉይ ኪዳን' },
    // Month 8 (Ginbot: 241-270) - Job 21-42, Psalms 1-89
    { book: 'መዝሙረ ዳዊት', bookEn: 'Psalms', range: 'መዝሙረ ዳዊት 1-89', testament: 'ብሉይ ኪዳን' },
    // Month 9 (Sene: 271-300) - Psalms 90-150, Proverbs, Ecclesiastes, Song
    { book: 'መጽሐፈ ምሳሌ', bookEn: 'Proverbs', range: 'መዝሙር 90-150፣ ምሳሌ፣ መክብብ', testament: 'ብሉይ ኪዳን' },
    // Month 10 (Hamle: 301-330) - Isaiah 1-66, Jeremiah 1-20
    { book: 'ትንቢተ ኢሳይያስ', bookEn: 'Isaiah', range: 'ኢሳይያስ 1-66፣ ኤርምያስ 1-20', testament: 'ብሉይ ኪዳን' },
    // Month 11 (Nehase: 331-360) - Jeremiah, Ezekiel, Daniel, 12 Minor Prophets
    { book: 'ትንቢተ ዳንኤል', bookEn: 'Daniel', range: 'ሕዝቅኤል፣ ዳንኤል፣ 12ቱ ደቂቀ ነቢያት', testament: 'ብሉይ ኪዳን' },
    // Month 12 (Pagume: 361-365) - The Four Gospels, Acts, Epistles, Revelation
    { book: 'ወንጌልና ራእይ', bookEn: 'Gospels & Revelation', range: 'ማቴዎስ፣ ዮሐንስ፣ ሮሜ፣ ራእይ', testament: 'ሐዲስ ኪዳን' },
  ];

  let currentDay = 1;

  for (let m = 0; m < 13; m++) {
    const daysInMonth = monthDayLimits[m];
    const month = ETHIOPIAN_MONTHS[m];

    for (let d = 1; d <= daysInMonth; d++) {
      // First 30 days are filled with high detail from RAW_READING_CHUNKS
      if (currentDay <= RAW_READING_CHUNKS.length) {
        const raw = RAW_READING_CHUNKS[currentDay - 1];
        days.push({
          dayNumber: currentDay,
          monthIndex: m,
          monthDay: d,
          book: raw.book,
          bookEnglish: raw.bookEn,
          passage: raw.passage,
          passageEnglish: raw.passageEn,
          testament: raw.testament,
          theme: raw.theme,
          themeEnglish: raw.themeEn,
          keyVerse: {
            reference: raw.verseRef,
            referenceEnglish: raw.verseRefEn,
            text: raw.verseText,
            textEnglish: raw.verseTextEn,
          },
          reflection: raw.reflection,
          reflectionEnglish: raw.reflectionEn,
          prayer: 'አቤቱ ጌታ ሆይ፤ ቃልህን በልቤ አኑርልኝ፥ በመንገድህም ምራኝ። አሜን።',
          prayerEnglish: 'Lord, write Your word on my heart and guide my steps in Your truth. Amen.',
        });
      } else {
        // Procedurally generated realistic scripture chunks across the rest of the year
        const prog = bookProgression[m - 1] || bookProgression[bookProgression.length - 1];
        const isNewTestament = m === 12;

        let passage = '';
        let passageEn = '';
        let verseRef = '';
        let verseRefEn = '';
        let verseText = '';
        let verseTextEn = '';
        let theme = '';
        let themeEn = '';

        if (m === 1) {
          // Tikimt
          const chStart = 17 + Math.floor((d - 1) * 1.5);
          passage = d <= 12 ? `ዘሌዋውያን ${chStart}-${chStart + 2}` : `ዘኍልቍ ${d - 12}-${d - 10}`;
          passageEn = d <= 12 ? `Leviticus ${chStart}-${chStart + 2}` : `Numbers ${d - 12}-${d - 10}`;
          theme = 'የቅድስና ስርዓትና የበረሃው ቆጠራ';
          themeEn = 'Holiness in Action & Camp Preparation';
          verseRef = 'ዘኍ 6:24-25';
          verseRefEn = 'Num 6:24-25';
          verseText = 'እግዚአብሔር ይባርክህ ይጠብቅህም፤ እግዚአብሔር ፊቱን ያብራልህ ይማርህም።';
          verseTextEn: 'The Lord bless thee, and keep thee: The Lord make his face shine upon thee.';
        } else if (m === 2) {
          // Hidar
          passage = d <= 15 ? `ዘኍልቍ ${15 + d}-${17 + d}` : `ዘዳግም ${d - 15}-${d - 13}`;
          passageEn = d <= 15 ? `Numbers ${15 + d}-${17 + d}` : `Deuteronomy ${d - 15}-${d - 13}`;
          theme = 'የተስፋ ቃልና የሕግ መታደስ';
          themeEn = 'Covenant Reminders & Journey to Jordan';
          verseRef = 'ዘዳ 6:5';
          verseRefEn = 'Deut 6:5';
          verseText = 'አምላክህን እግዚአብሔርን በፍጹም ልብህ በፍጹምም ነፍስህ በፍጹምም ኃይልህ ውደድ።';
          verseTextEn = 'And thou shalt love the Lord thy God with all thine heart, and with all thy soul.';
        } else if (m === 3) {
          // Tahsas
          passage = d <= 14 ? `ኢያሱ ${d * 2 - 1}-${d * 2}` : `መሳፍንት ${d - 14}-${d - 12}`;
          passageEn = d <= 14 ? `Joshua ${d * 2 - 1}-${d * 2}` : `Judges ${d - 14}-${d - 12}`;
          theme = 'የኢያሱ ድልና የእምነት ጥንካሬ';
          themeEn = 'Victories of Faith and Inheritance';
          verseRef = 'ኢያ 1:9';
          verseRefEn = 'Josh 1:9';
          verseText = 'በእውኑ አላዘዝሁህምን? በርታ፥ አይዞህ፤ አትፍራ አትደንግጥ፥ አምላክህ እግዚአብሔር ከአንተ ጋር ነውና።';
          verseTextEn = 'Be strong and of a good courage; be not afraid, neither be thou dismayed.';
        } else if (m === 4) {
          // Tir
          passage = d <= 5 ? `መሳፍንት ${12 + d}-${14 + d}` : d <= 8 ? `ሩት 1-4` : `1 ሳሙኤል ${d - 8}-${d - 6}`;
          passageEn = d <= 5 ? `Judges ${12 + d}-${14 + d}` : d <= 8 ? `Ruth 1-4` : `1 Samuel ${d - 8}-${d - 6}`;
          theme = 'የሳሙኤል መጠራትና የዳዊት መቀባት';
          themeEn = 'The Call of Samuel & Anointing of David';
          verseRef = '1 ሳሙ 16:7';
          verseRefEn = '1 Sam 16:7';
          verseText = 'ሰው እንደሚያይ እግዚአብሔር አያይም፤ ሰው ፊትን ያያል፥ እግዚአብሔር ግን ልብን ያያል።';
          verseTextEn = 'For man looketh on the outward appearance, but the Lord looketh on the heart.';
        } else if (m === 5) {
          // Yekatit
          passage = d <= 15 ? `2 ሳሙኤል ${d}-${d + 1}` : `1 ነገሥት ${d - 14}-${d - 12}`;
          passageEn = d <= 15 ? `2 Samuel ${d}-${d + 1}` : `1 Kings ${d - 14}-${d - 12}`;
          theme = 'የዳዊት መንግሥትና የሰሎሞን ቤተ መቅደስ';
          themeEn = 'Davidic Reign and Solomon\'s Temple';
          verseRef = '1 ነገ 8:23';
          verseRefEn = '1 Kings 8:23';
          verseText = 'አቤቱ የእስራኤል አምላክ ሆይ... ቃል ኪዳንህንና ምሕረትህን ለባሪያዎችህ የምትጠብቅ እንደ አንተ ያለ አምላክ የለም።';
          verseTextEn = 'Lord God of Israel, there is no God like thee, in heaven above, or on earth beneath.';
        } else if (m === 6) {
          // Megabit
          passage = d <= 15 ? `2 ነገሥት ${d}-${d + 1}` : `1 ዜና መዋዕል ${d - 14}-${d - 12}`;
          passageEn = d <= 15 ? `2 Kings ${d}-${d + 1}` : `1 Chronicles ${d - 14}-${d - 12}`;
          theme = 'የነቢያት ተጋድሎና የታሪክ ምስክርነት';
          themeEn = 'Prophetic Courage & Covenant History';
          verseRef = '2 ዜና 7:14';
          verseRefEn = '2 Chron 7:14';
          verseText = 'በስሜ የተጠሩት ሕዝቤ ሰውነታቸውን አዋርደው ቢጸልዩ... ምድራቸውንም እፈውሳለሁ።';
          verseTextEn: 'If my people, which are called by my name, shall humble themselves, and pray... then will I heal their land.';
        } else if (m === 7) {
          // Miyazya
          passage = d <= 8 ? `ዕዝራ ${d}` : d <= 18 ? `ነህምያ ${d - 8}` : `ኢዮብ ${d - 18}-${d - 16}`;
          passageEn = d <= 8 ? `Ezra ${d}` : d <= 18 ? `Nehemiah ${d - 8}` : `Job ${d - 18}-${d - 16}`;
          theme = 'ቅጥሩን መገንባትና የኢዮብ ተስፋ';
          themeEn = 'Rebuilding the Walls & Patient Endurance';
          verseRef = 'ነህ 8:10';
          verseRefEn = 'Neh 8:10';
          verseText = 'የእግዚአብሔር ደስታ ኃይላችሁ ነውና አትዘኑ።';
          verseTextEn = 'For the joy of the Lord is your strength.';
        } else if (m === 8) {
          // Ginbot (Psalms 1-89)
          const pStart = (d - 1) * 3 + 1;
          passage = `መዝሙረ ዳዊት ${pStart}-${pStart + 2}`;
          passageEn = `Psalms ${pStart}-${pStart + 2}`;
          theme = 'የምስጋና፣ የመጽናናትና የምልጃ መዝሙራት';
          themeEn = 'Praise, Comfort, and Divine Refuge';
          verseRef = 'መዝ 23:1';
          verseRefEn = 'Ps 23:1';
          verseText = 'እግዚአብሔር እረኛዬ ነው፥ የሚያሳጣኝም የለም።';
          verseTextEn = 'The Lord is my shepherd; I shall not want.';
        } else if (m === 9) {
          // Sene (Psalms 90-150, Proverbs)
          passage = d <= 15 ? `መዝሙረ ዳዊት ${90 + d * 4}-${93 + d * 4}` : `መጽሐፈ ምሳሌ ${d - 15}-${d - 14}`;
          passageEn = d <= 15 ? `Psalms ${90 + d * 4}-${93 + d * 4}` : `Proverbs ${d - 15}-${d - 14}`;
          theme = 'የእግዚአብሔር ዘላለማዊነትና የጥበብ ምንጭ';
          themeEn = 'Eternal Majesty & Springs of Wisdom';
          verseRef = 'ምሳ 3:5';
          verseRefEn = 'Prov 3:5';
          verseText = 'በፍጹም ልብህ በእግዚአብሔር ታመን፥ በራስህም ማስተዋል አትደገፍ።';
          verseTextEn = 'Trust in the Lord with all thine heart; and lean not unto thine own understanding.';
        } else if (m === 10) {
          // Hamle (Isaiah)
          const iStart = (d - 1) * 2 + 1;
          passage = `ትንቢተ ኢሳይያስ ${iStart}-${iStart + 2}`;
          passageEn = `Isaiah ${iStart}-${iStart + 2}`;
          theme = 'የመሲሑ ትንቢትና የመጽናናት ተስፋ';
          themeEn = 'The Messianic Servant & Eternal Hope';
          verseRef = 'ኢሳ 40:31';
          verseRefEn = 'Isa 40:31';
          verseText = 'እግዚአብሔርን በመተማመን የሚጠባበቁ ግን ኃይላቸውን ያድሳሉ፤ እንደ ንስር በክንፍ ይወጣሉ።';
          verseTextEn = 'They that wait upon the Lord shall renew their strength; they shall mount up with wings as eagles.';
        } else if (m === 11) {
          // Nehase (Ezekiel, Daniel, Prophets)
          passage = d <= 15 ? `ትንቢተ ሕዝቅኤል ${d * 2}-${d * 2 + 1}` : `ትንቢተ ዳንኤል ${d - 15}-${d - 13}`;
          passageEn = d <= 15 ? `Ezekiel ${d * 2}-${d * 2 + 1}` : `Daniel ${d - 15}-${d - 13}`;
          theme = 'የአዲሱ ልብ ተስፋና የመንግሥተ ሰማያት ድል';
          themeEn = 'A New Heart, Spirit, and Everlasting Kingdom';
          verseRef = 'ሕዝ 36:26';
          verseRefEn = 'Ezek 36:26';
          verseText = 'አዲስም ልብ እሰጣችኋለሁ አዲስም መንፈስ በውስጣችሁ አኖራለሁ፤ የድንጋዩንም ልብ ከሥጋችሁ አወጣለሁ።';
          verseTextEn = 'A new heart also will I give you, and a new spirit will I put within you.';
        } else {
          // Pagume (Days 361-365) - Climax with Gospels and Revelation
          if (d === 1) {
            passage = 'የማቴዎስ ወንጌል 1-28 (ማጠቃለያ)';
            passageEn = 'Gospel of Matthew';
            theme = 'የመንግሥቱ ንጉሥና የተራራው ስብከት';
            themeEn = 'The Promised King & Sermon on the Mount';
            verseRef = 'ማቴ 28:20';
            verseRefEn = 'Matt 28:20';
            verseText = 'እነሆም እኔ እስከ ዓለም ፍጻሜ ድረስ ሁልጊዜ ከእናንተ ጋር ነኝ።';
            verseTextEn = 'Lo, I am with you always, even unto the end of the world.';
          } else if (d === 2) {
            passage = 'የዮሐንስ ወንጌል 1-21';
            passageEn = 'Gospel of John';
            theme = 'ቃል ሥጋ ሆነ፤ የዘላለም ሕይወት መንገድ';
            themeEn = 'The Word Made Flesh & Bread of Life';
            verseRef = 'ዮሐ 3:16';
            verseRefEn = 'John 3:16';
            verseText = 'በእርሱ የሚያምን ሁሉ የዘላለም ሕይወት እንዲኖረው እንጂ እንዳይጠፋ እግዚአብሔር አንድያ ልጁን እስኪሰጥ ድረስ ዓለሙን እንዲሁ ወዶአልና።';
            verseTextEn = 'For God so loved the world, that he gave his only begotten Son...';
          } else if (d === 3) {
            passage = 'የሐዋርያት ሥራ 1-28';
            passageEn = 'Acts of the Apostles';
            theme = 'የመንፈስ ቅዱስ መውረድና የቤተ ክርስቲያን ምስክርነት';
            themeEn = 'Power of the Holy Spirit & Gospel Mission';
            verseRef = 'ሐዋ 1:8';
            verseRefEn = 'Acts 1:8';
            verseText = 'መንፈስ ቅዱስ በእናንተ ላይ በወረደ ጊዜ ኃይልን ትቀበላላችሁ፥ ምስክሮቼም ትሆናላችሁ።';
            verseTextEn: 'Ye shall receive power, after that the Holy Ghost is come upon you.';
          } else if (d === 4) {
            passage = 'ወደ ሮሜ ሰዎች እና የጳውሎስ መልእክታት';
            passageEn = 'Romans & Pauline Epistles';
            theme = 'የጸጋው ጽድቅና በእምነት መኖር';
            themeEn = 'Righteousness by Faith & Eternal Love';
            verseRef = 'ሮሜ 8:38-39';
            verseRefEn = 'Rom 8:38-39';
            verseText = 'ሞት ቢሆን፥ ሕይወትም ቢሆን... በክርስቶስ ኢየሱስ በጌታችን ካለው ከእግዚአብሔር ፍቅር ሊለየን እንዳይችል ተረድቼአለሁ።';
            verseTextEn = 'Neither death, nor life... shall be able to separate us from the love of God.';
          } else {
            passage = 'የዮሐንስ ራእይ 1-22';
            passageEn = 'Revelation 1-22';
            theme = 'አዲሲቱ ኢየሩሳሌም፤ የክርስቶስ ድልና ፍጻሜ';
            themeEn = 'New Jerusalem & The Final Triumph';
            verseRef = 'ራእ 21:4';
            verseRefEn = 'Rev 21:4';
            verseText = 'እንባዎችንም ሁሉ ከዓይኖቻቸው ያብሳል፥ ሞትም ከእንግዲህ ወዲህ አይሆንም፥ ኀዘንም ቢሆን ወይም ጩኸት ወይም ሥቃይ ከእንግዲህ ወዲህ አይሆንም።';
            verseTextEn = 'And God shall wipe away all tears from their eyes; and there shall be no more death.';
          }
        }

        days.push({
          dayNumber: currentDay,
          monthIndex: m,
          monthDay: d,
          book: prog.book,
          bookEnglish: prog.bookEn,
          passage,
          passageEnglish: passageEn,
          testament: isNewTestament ? 'ሐዲስ ኪዳን' : 'ብሉይ ኪዳን',
          theme: theme || 'የእግዚአብሔር ቃልና መመሪያ',
          themeEnglish: themeEn || 'God\'s Faithful Word & Guidance',
          keyVerse: {
            reference: verseRef || 'መዝ 119:105',
            referenceEnglish: verseRefEn || 'Ps 119:105',
            text: verseText || 'ሕግህ ለእግሬ መብራት፥ ለመንገዴ ብርሃን ነው።',
            verseTextEnglish: verseTextEn || 'Thy word is a lamp unto my feet, and a light unto my path.',
          } as any,
          reflection: 'የእግዚአብሔር ቃል በየዕለቱ ለነፍሳችን ምግብና ብርታት ነው። ዛሬም በቃሉ ተመላለስ።',
          reflectionEnglish: 'God\'s word is daily nourishment for the spirit. Walk faithfully in His revelation today.',
          prayer: 'አምላኬ ሆይ፤ ቃልህን እንድረዳና በሕይወቴ እንድተገብረው ጸጋህን አብዛልኝ። አሜን።',
          prayerEnglish: 'Lord, grant me wisdom to understand Your holy scriptures and courage to live them out. Amen.',
        });
      }

      currentDay++;
    }
  }

  return days;
}

export const DAILY_MOTIVATIONS = [
  {
    verse: '«ሕግህ ለእግሬ መብራት፥ ለመንገዴ ብርሃን ነው።»',
    verseEn: '"Your word is a lamp to my feet and a light to my path."',
    ref: 'መዝሙረ ዳዊት 119:105',
    refEn: 'Psalm 119:105',
    message: 'ዛሬ የምታነበው እያንዳንዱ ቃል የዕለቱን እርምጃህን በብርሃን ያበራልሃል።',
    messageEn: 'Every verse you read today casts divine light upon your footsteps.',
  },
  {
    verse: '«እግዚአብሔር እንዲህ ይላል፦ በርታ፥ አይዞህ፤ አትፍራ፥ አትደንግጥ፤ የምትሄድበት ሁሉ አምላክህ እግዚአብሔር ከአንተ ጋር ነውና።»',
    verseEn: '"Be strong and courageous. Do not be afraid; do not be discouraged, for the Lord your God will be with you wherever you go."',
    ref: 'መጽሐፈ ኢያሱ 1:9',
    refEn: 'Joshua 1:9',
    message: 'እቅድህን በጽናት ቀጥል፤ በቃሉ ውስጥ ታላቅ ብርታትና ሰላም አለህ።',
    messageEn: 'Persist in your reading plan; there is profound peace and strength in His presence.',
  },
  {
    verse: '«የእግዚአብሔር ቃል ሕያው ነውና፥ የሚሠራም፥ ሁለትም አፍ ካለው ሰይፍ ሁሉ ይልቅ የተሳለ ነው።»',
    verseEn: '"For the word of God is alive and active. Sharper than any double-edged sword."',
    ref: 'ወደ ዕብራውያን 4:12',
    refEn: 'Hebrews 4:12',
    message: 'የቅዱሳት መጻሕፍት ንባብ ልብን የሚያድስ፣ አእምሮን የሚያጠራ ሕያው ኃይል ነው።',
    messageEn: 'Scripture reading is a living force that renews the heart and clarifies the mind.',
  },
  {
    verse: '«ሰው ከእግዚአብሔር አፍ በሚወጣ ቃል ሁሉ እንጂ በእንጀራ ብቻ አይኖርም።»',
    verseEn: '"Man shall not live on bread alone, but on every word that comes from the mouth of God."',
    ref: 'የማቴዎስ ወንጌል 4:4',
    refEn: 'Matthew 4:4',
    message: 'የዕለት ምግብ ለሥጋ እንደሚያስፈልግ፥ ቃሉ ለነፍስህ የማያልቅ ሕይወት ነው።',
    messageEn: 'Just as daily bread nourishes the body, the Word sustains your eternal spirit.',
  },
];
