/**
 * Pure Web Audio API Sound Engine
 * Provides realistic acoustic sound synthesis without external MP3 files or network dependencies.
 * Includes interactive tick sound, milestone fanfare, and 4 soothing ambient background music tracks.
 */

class SoundEngine {
  private ctx: AudioContext | null = null;
  private isMusicPlaying = false;
  private currentTrack: string = 'youtube';
  private masterGain: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private activeOscillators: (OscillatorNode | AudioNode)[] = [];
  private loopTimer: number | null = null;
  private volume = 0.6;
  private isMuted = false;

  private initContext() {
    if (!this.ctx) {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      this.ctx = new AudioContextClass();

      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(this.isMuted ? 0 : this.volume, this.ctx.currentTime);
      this.masterGain.connect(this.ctx.destination);

      this.musicGain = this.ctx.createGain();
      this.musicGain.gain.setValueAtTime(0.5, this.ctx.currentTime);
      this.musicGain.connect(this.masterGain);

      this.sfxGain = this.ctx.createGain();
      this.sfxGain.gain.setValueAtTime(0.8, this.ctx.currentTime);
      this.sfxGain.connect(this.masterGain);
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public setVolume(val: number) {
    this.volume = Math.max(0, Math.min(1, val));
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(this.isMuted ? 0 : this.volume, this.ctx.currentTime, 0.05);
    }
  }

  public getVolume(): number {
    return this.volume;
  }

  public toggleMute(): boolean {
    this.isMuted = !this.isMuted;
    this.setVolume(this.volume);
    return this.isMuted;
  }

  public isSoundMuted(): boolean {
    return this.isMuted;
  }

  /**
   * High-tactility, soothing spiritual tick chime
   * Plays when user marks a day as completed.
   */
  public playTick(checked: boolean = true) {
    try {
      this.initContext();
      if (!this.ctx || !this.sfxGain) return;

      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      // Pitch: high harmonious bell for tick, gentle lower woodblock for untick
      const baseFreq = checked ? 880 : 520; // A5 for check, C5 for uncheck
      osc.type = 'sine';
      osc.frequency.setValueAtTime(baseFreq, now);
      osc.frequency.exponentialRampToValueAtTime(baseFreq * (checked ? 1.5 : 0.8), now + 0.15);

      gain.gain.setValueAtTime(0.001, now);
      gain.gain.exponentialRampToValueAtTime(0.4, now + 0.015);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + (checked ? 0.45 : 0.2));

      // Add harmonic shimmer for checked
      if (checked) {
        const harmonic = this.ctx.createOscillator();
        const harmGain = this.ctx.createGain();
        harmonic.type = 'triangle';
        harmonic.frequency.setValueAtTime(baseFreq * 2, now);
        harmGain.gain.setValueAtTime(0.15, now);
        harmGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.3);
        harmonic.connect(harmGain);
        harmGain.connect(this.sfxGain);
        harmonic.start(now);
        harmonic.stop(now + 0.35);
      }

      osc.connect(gain);
      gain.connect(this.sfxGain);

      osc.start(now);
      osc.stop(now + 0.5);
    } catch (e) {
      console.warn('Audio tick failed:', e);
    }
  }

  /**
   * Milestone Fanfare: Radiant harp arpeggio
   */
  public playMilestoneCelebration() {
    try {
      this.initContext();
      if (!this.ctx || !this.sfxGain) return;

      const now = this.ctx.currentTime;
      // Traditional peaceful pentatonic chord: C4, E4, G4, A4, C5, E5
      const notes = [261.63, 329.63, 392.00, 440.00, 523.25, 659.25];

      notes.forEach((freq, idx) => {
        if (!this.ctx || !this.sfxGain) return;
        const noteTime = now + idx * 0.1;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, noteTime);

        gain.gain.setValueAtTime(0.0001, noteTime);
        gain.gain.exponentialRampToValueAtTime(0.25, noteTime + 0.04);
        gain.gain.exponentialRampToValueAtTime(0.0001, noteTime + 1.2);

        osc.connect(gain);
        gain.connect(this.sfxGain);

        osc.start(noteTime);
        osc.stop(noteTime + 1.3);
      });
    } catch (e) {
      console.warn('Celebration audio failed:', e);
    }
  }

  /**
   * Start / Stop Ambient Background Music
   */
  public startMusic(trackId: string = 'begena') {
    this.initContext();
    this.stopMusic();
    this.currentTrack = trackId;
    this.isMusicPlaying = true;

    if (trackId === 'begena') {
      this.runBegenaHarpLoop();
    } else if (trackId === 'ambient') {
      this.runSanctuaryPadsLoop();
    } else if (trackId === 'chimes') {
      this.runMonasteryChimesLoop();
    } else if (trackId === 'rain') {
      this.runGentleRainLoop();
    }
  }

  public stopMusic() {
    this.isMusicPlaying = false;
    if (this.loopTimer !== null) {
      window.clearTimeout(this.loopTimer);
      this.loopTimer = null;
    }
    this.activeOscillators.forEach((node) => {
      try {
        if ('stop' in node) (node as OscillatorNode).stop();
        node.disconnect();
      } catch (e) {
        // ignore
      }
    });
    this.activeOscillators = [];
  }

  public toggleMusic(trackId?: string): boolean {
    if (this.isMusicPlaying) {
      this.stopMusic();
      return false;
    } else {
      this.startMusic(trackId || this.currentTrack);
      return true;
    }
  }

  public getIsMusicPlaying(): boolean {
    return this.isMusicPlaying;
  }

  public getCurrentTrack(): string {
    return this.currentTrack;
  }

  // --- Track 1: ሰላማዊ በገና (Ethiopian Begena / David's Harp Harp scale) ---
  private runBegenaHarpLoop() {
    if (!this.isMusicPlaying || !this.ctx || !this.musicGain) return;

    // Tizita Minor / Begena meditative notes (Hz)
    const scale = [196.00, 220.00, 261.63, 293.66, 349.23, 392.00, 440.00, 523.25];
    const bassNote = 98.00; // G2 root drone

    // Pluck a low meditative drone occasionally
    const now = this.ctx.currentTime;
    const droneOsc = this.ctx.createOscillator();
    const droneGain = this.ctx.createGain();
    droneOsc.type = 'triangle';
    droneOsc.frequency.setValueAtTime(bassNote, now);

    droneGain.gain.setValueAtTime(0.001, now);
    droneGain.gain.linearRampToValueAtTime(0.12, now + 0.8);
    droneGain.gain.exponentialRampToValueAtTime(0.0001, now + 4.5);

    droneOsc.connect(droneGain);
    droneGain.connect(this.musicGain);
    droneOsc.start(now);
    droneOsc.stop(now + 4.6);
    this.activeOscillators.push(droneOsc);

    // Sequence 3-5 gentle harp plucks with natural timing
    const plucksCount = 4;
    for (let i = 0; i < plucksCount; i++) {
      const delay = i * 1.1 + Math.random() * 0.3;
      const noteTime = now + delay;
      const noteFreq = scale[Math.floor(Math.random() * scale.length)];

      const pluckOsc = this.ctx.createOscillator();
      const pluckHarmonic = this.ctx.createOscillator();
      const pluckGain = this.ctx.createGain();
      const filter = this.ctx.createBiquadFilter();

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(1400, noteTime);
      filter.frequency.exponentialRampToValueAtTime(300, noteTime + 1.8);

      pluckOsc.type = 'triangle';
      pluckOsc.frequency.setValueAtTime(noteFreq, noteTime);

      pluckHarmonic.type = 'sine';
      pluckHarmonic.frequency.setValueAtTime(noteFreq * 2, noteTime);

      pluckGain.gain.setValueAtTime(0.001, noteTime);
      pluckGain.gain.exponentialRampToValueAtTime(0.14, noteTime + 0.04);
      pluckGain.gain.exponentialRampToValueAtTime(0.0001, noteTime + 2.4);

      pluckOsc.connect(filter);
      pluckHarmonic.connect(filter);
      filter.connect(pluckGain);
      pluckGain.connect(this.musicGain);

      pluckOsc.start(noteTime);
      pluckHarmonic.start(noteTime);
      pluckOsc.stop(noteTime + 2.5);
      pluckHarmonic.stop(noteTime + 2.5);
      this.activeOscillators.push(pluckOsc, pluckHarmonic);
    }

    // Schedule next cycle
    this.loopTimer = window.setTimeout(() => {
      this.runBegenaHarpLoop();
    }, 4800);
  }

  // --- Track 2: የማለዳ ጸሎት (Morning Sanctuary Ambient Pads) ---
  private runSanctuaryPadsLoop() {
    if (!this.isMusicPlaying || !this.ctx || !this.musicGain) return;

    const chords = [
      [130.81, 196.00, 261.63, 329.63], // C major
      [110.00, 164.81, 220.00, 261.63], // A minor
      [146.83, 196.00, 220.00, 293.66], // F sus2
      [146.83, 196.00, 246.94, 293.66], // G
    ];

    const chord = chords[Math.floor(Math.random() * chords.length)];
    const now = this.ctx.currentTime;
    const duration = 6.5;

    chord.forEach((freq) => {
      if (!this.ctx || !this.musicGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const filter = this.ctx.createBiquadFilter();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now);

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(600, now);
      filter.frequency.linearRampToValueAtTime(900, now + duration / 2);
      filter.frequency.linearRampToValueAtTime(500, now + duration);

      gain.gain.setValueAtTime(0.001, now);
      gain.gain.linearRampToValueAtTime(0.06, now + 2.0);
      gain.gain.linearRampToValueAtTime(0.001, now + duration);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.musicGain);

      osc.start(now);
      osc.stop(now + duration);
      this.activeOscillators.push(osc);
    });

    this.loopTimer = window.setTimeout(() => {
      this.runSanctuaryPadsLoop();
    }, 5500);
  }

  // --- Track 3: የሰላም ቃጭል (Sanctuary Chimes & Soft Bells) ---
  private runMonasteryChimesLoop() {
    if (!this.isMusicPlaying || !this.ctx || !this.musicGain) return;

    const bellPitches = [523.25, 659.25, 783.99, 1046.50, 1174.66, 1318.51];
    const now = this.ctx.currentTime;

    const pitch = bellPitches[Math.floor(Math.random() * bellPitches.length)];
    const osc = this.ctx.createOscillator();
    const oscHarm = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(pitch, now);

    oscHarm.type = 'sine';
    oscHarm.frequency.setValueAtTime(pitch * 2.76, now); // inharmonic bell overtone

    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(0.12, now + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 4.0);

    osc.connect(gain);
    oscHarm.connect(gain);
    gain.connect(this.musicGain);

    osc.start(now);
    oscHarm.start(now);
    osc.stop(now + 4.2);
    oscHarm.stop(now + 4.2);
    this.activeOscillators.push(osc, oscHarm);

    this.loopTimer = window.setTimeout(() => {
      this.runMonasteryChimesLoop();
    }, 2800 + Math.random() * 2000);
  }

  // --- Track 4: የጸጥታ ዝናብ (Gentle Rain & Calm Breeze) ---
  private runGentleRainLoop() {
    if (!this.isMusicPlaying || !this.ctx || !this.musicGain) return;

    // Synthesize gentle pink noise burst
    const bufferSize = this.ctx.sampleRate * 2;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;

    for (let i = 0; i < bufferSize; i++) {
      const white = Math.random() * 2 - 1;
      b0 = 0.99886 * b0 + white * 0.0555179;
      b1 = 0.99332 * b1 + white * 0.0750759;
      b2 = 0.96900 * b2 + white * 0.1538520;
      b3 = 0.86650 * b3 + white * 0.3104856;
      b4 = 0.55000 * b4 + white * 0.5329522;
      b5 = -0.7616 * b5 - white * 0.0168980;
      data[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362) * 0.025;
      b6 = white * 0.115926;
    }

    const noiseSource = this.ctx.createBufferSource();
    noiseSource.buffer = buffer;
    noiseSource.loop = true;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(800, this.ctx.currentTime);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.001, this.ctx.currentTime);
    gain.gain.linearRampToValueAtTime(0.18, this.ctx.currentTime + 1.5);

    noiseSource.connect(filter);
    filter.connect(gain);
    gain.connect(this.musicGain);

    noiseSource.start();
    this.activeOscillators.push(noiseSource);
  }
}

export const soundEngine = new SoundEngine();
