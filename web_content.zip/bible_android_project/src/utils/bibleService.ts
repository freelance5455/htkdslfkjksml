import { BibleVerse, BibleVersion, PRELOADED_CHAPTERS, BIBLE_VERSIONS } from '../data/amharicBibleData';

const CACHE_PREFIX = 'bible_verse_cache_';

export interface ChapterResult {
  book: string;
  chapter: number;
  version: BibleVersion;
  versionName: string;
  verses: BibleVerse[];
  source: 'local' | 'cache' | 'api' | 'fallback';
}

/**
 * Fetch verses for a given book, chapter, and version
 */
export async function fetchBibleChapter(
  book: string,
  chapter: number,
  version: BibleVersion
): Promise<ChapterResult> {
  const versionInfo = BIBLE_VERSIONS.find((v) => v.id === version) || BIBLE_VERSIONS[0];
  const versionName = versionInfo.nameAm;
  const lookupKey = `${book}_${chapter}`;

  // 1. Check preloaded bundled data first (instant zero-latency)
  const preloaded = PRELOADED_CHAPTERS[lookupKey];
  if (preloaded && preloaded[version] && preloaded[version].length > 0) {
    return {
      book,
      chapter,
      version,
      versionName,
      verses: preloaded[version],
      source: 'local',
    };
  }

  // 2. Check localStorage cache
  const cacheKey = `${CACHE_PREFIX}${book}_${chapter}_${version}`;
  try {
    const cached = localStorage.getItem(cacheKey);
    if (cached) {
      const parsed = JSON.parse(cached);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return {
          book,
          chapter,
          version,
          versionName,
          verses: parsed,
          source: 'cache',
        };
      }
    }
  } catch (e) {
    // Ignore localStorage error
  }

  // 3. Fetch from server API
  try {
    const apiBaseUrl = (import.meta.env.VITE_API_BASE_URL || '').replace(/\\/$/, '');
    const endpoint = `${apiBaseUrl}/api/bible/chapter?book=${encodeURIComponent(book)}&chapter=${chapter}&version=${version}`;
    const res = await fetch(endpoint, {
      headers: { Accept: 'application/json' },
    });
    if (res.ok) {
      const data = await res.json();
      if (data && Array.isArray(data.verses) && data.verses.length > 0) {
        // Save to localStorage for future offline instant access
        try {
          localStorage.setItem(cacheKey, JSON.stringify(data.verses));
        } catch (e) {
          // Ignore quota errors
        }
        return {
          book,
          chapter,
          version,
          versionName,
          verses: data.verses,
          source: 'api',
        };
      }
    }
  } catch (err) {
    console.warn('Failed to fetch from /api/bible/chapter:', err);
  }

  // 4. Fallback if network or key unavailable
  return {
    book,
    chapter,
    version,
    versionName,
    verses: [
      {
        verse: 1,
        text: `የ${book} ምዕራፍ ${chapter} ንባብ በ${versionName}። እባክዎ ኢንተርኔትዎን ያረጋግጡ ወይም ሙሉውን ምዕራፍ በቀጥታ ያንብቡ።`,
      },
    ],
    source: 'fallback',
  };
}
