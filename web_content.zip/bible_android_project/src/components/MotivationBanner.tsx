import React, { useState } from 'react';
import { DAILY_MOTIVATIONS } from '../data/biblePlanData';
import { Sparkles, Trophy, Award, Target, Flame, ChevronRight, X } from 'lucide-react';

interface MotivationBannerProps {
  completedCount: number;
  totalDays: number;
  streak: number;
  language: 'am' | 'en';
  isOpen: boolean;
  onClose: () => void;
  onJumpToNextUnread: () => void;
}

export const MotivationBanner: React.FC<MotivationBannerProps> = ({
  completedCount,
  totalDays,
  streak,
  language,
  isOpen,
  onClose,
  onJumpToNextUnread,
}) => {
  const [motivationIdx, setMotivationIdx] = useState(0);

  if (!isOpen) return null;

  const currentQuote = DAILY_MOTIVATIONS[motivationIdx % DAILY_MOTIVATIONS.length];

  // Milestones badges
  const milestones = [
    { threshold: 1, titleAm: 'የመጀመሪያ እርምጃ', titleEn: 'First Step', descAm: 'የ365 ቀናት ጉዞህን ጀምረሃል!', descEn: 'Started the 365-day plan!', icon: '🌱' },
    { threshold: 7, titleAm: 'የሳምንቱ ጽናት', titleEn: '7-Day Devotion', descAm: 'ለአንድ ሳምንት በተከታታይ አንብበሃል', descEn: 'One full week of devotion', icon: '🔥' },
    { threshold: 30, titleAm: 'የመጀመሪያው ወር (መስከረም)', titleEn: 'First Month Complete', descAm: '30 ቀናትን አጠናቀሃል!', descEn: '30 days completed!', icon: '⭐' },
    { threshold: 100, titleAm: 'የመቶ ቀናት ክብር', titleEn: 'Centurion of Faith', descAm: '100 ቀናት የእግዚአብሔርን ቃል አጠናክረሃል', descEn: '100 days of scripture', icon: '🏆' },
    { threshold: 180, titleAm: 'የመንገዱ ግማሽ', titleEn: 'Halfway Journey', descAm: 'ግማሹን መጽሐፍ ቅዱስ አጠናቀሃል', descEn: '50% through the holy scriptures', icon: '⚔️' },
    { threshold: 365, titleAm: 'የፍጹምነት ዘውድ', titleEn: 'Crown of Completion', descAm: 'መላውን መጽሐፍ ቅዱስ አንብበህ ጨርሰሃል!', descEn: 'Read the entire Bible in one year!', icon: '👑' },
  ];

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-xl max-h-[90vh] overflow-y-auto rounded-2xl bg-gradient-to-b from-[#16323D] to-[#0f232b] border-2 border-[#2D6F8B] p-6 sm:p-7 text-[#F2E7D8] shadow-2xl my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="absolute inset-1.5 rounded-xl border border-[#8FB7C7]/20 pointer-events-none" />

        {/* Header */}
        <div className="flex items-center justify-between pb-3 mb-4 border-b border-[#2D6F8B]/40">
          <div className="flex items-center gap-2 text-[#C79A6A]">
            <Sparkles className="w-5 h-5" />
            <h3 className="text-lg font-bold font-serif-header">
              {language === 'am' ? 'የዕለቱ ቃልና ማበረታቻ' : 'Daily Inspiration & Milestones'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-[#8FB7C7] hover:text-[#F2E7D8] hover:bg-[#10232b] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Motivational Verse Card */}
        <div className="rounded-xl bg-[#0d1e25] border border-[#2D6F8B]/50 p-5 mb-5 shadow-inner text-center">
          <span className="text-xs uppercase font-bold text-[#8FB7C7] tracking-widest block mb-2">
            {language === 'am' ? 'የብርታት ቃል' : 'Encouraging Scripture'}
          </span>
          <blockquote className="text-base sm:text-lg italic text-[#F2E7D8] leading-relaxed mb-2 font-serif">
            {language === 'am' ? currentQuote.verse : currentQuote.verseEn}
          </blockquote>
          <p className="text-xs font-bold text-[#C79A6A] mb-3">
            — {language === 'am' ? currentQuote.ref : currentQuote.refEn}
          </p>
          <p className="text-xs sm:text-sm text-[#8FB7C7] leading-relaxed">
            {language === 'am' ? currentQuote.message : currentQuote.messageEn}
          </p>

          <button
            onClick={() => setMotivationIdx((prev) => prev + 1)}
            className="mt-4 px-3 py-1 rounded-full bg-[#10232b] hover:bg-[#1a3845] border border-[#2D6F8B]/70 text-xs text-[#C79A6A] transition-colors cursor-pointer"
          >
            {language === 'am' ? 'ሌላ የማበረታቻ ቃል አሳይ ↻' : 'Next Inspirational Verse ↻'}
          </button>
        </div>

        {/* Overall Progress Stats Overview */}
        <div className="grid grid-cols-3 gap-2.5 mb-5 text-center">
          <div className="p-3 rounded-xl bg-[#10232b] border border-[#2D6F8B]/50">
            <div className="text-xs text-[#8FB7C7] mb-0.5">{language === 'am' ? 'የተነበበ' : 'Read'}</div>
            <div className="text-lg font-bold text-[#C79A6A] font-serif-header">
              {completedCount}
            </div>
            <div className="text-[10px] text-[#8FB7C7]/70">/ {totalDays} {language === 'am' ? 'ቀን' : 'days'}</div>
          </div>

          <div className="p-3 rounded-xl bg-[#10232b] border border-[#2D6F8B]/50">
            <div className="text-xs text-[#8FB7C7] mb-0.5">{language === 'am' ? 'የቀረው' : 'Remaining'}</div>
            <div className="text-lg font-bold text-[#F2E7D8] font-serif-header">
              {totalDays - completedCount}
            </div>
            <div className="text-[10px] text-[#8FB7C7]/70">{language === 'am' ? 'ቀናት' : 'days'}</div>
          </div>

          <div className="p-3 rounded-xl bg-[#10232b] border border-[#2D6F8B]/50">
            <div className="text-xs text-[#8FB7C7] mb-0.5">{language === 'am' ? 'ተከታታይ' : 'Streak'}</div>
            <div className="text-lg font-bold text-[#C79A6A] font-serif-header flex items-center justify-center gap-1">
              <Flame className="w-4 h-4 fill-current text-[#C79A6A]" />
              {streak}
            </div>
            <div className="text-[10px] text-[#8FB7C7]/70">{language === 'am' ? 'ቀናት' : 'days'}</div>
          </div>
        </div>

        {/* Milestones & Badges List */}
        <div className="mb-6">
          <h4 className="flex items-center gap-1.5 text-xs font-bold text-[#8FB7C7] uppercase tracking-wider mb-3">
            <Trophy className="w-3.5 h-3.5 text-[#C79A6A]" />
            {language === 'am' ? 'የመንፈሳዊ ጉዞ ደረጃዎች' : 'Reading Milestones'}
          </h4>

          <div className="space-y-2">
            {milestones.map((m, idx) => {
              const isUnlocked = completedCount >= m.threshold;

              return (
                <div
                  key={idx}
                  className={`flex items-center gap-3 p-2.5 rounded-xl border transition-all ${
                    isUnlocked
                      ? 'bg-[#1a3845] border-[#2D6F8B] text-[#F2E7D8]'
                      : 'bg-[#0e2027]/60 border-[#1f4553]/40 text-[#8FB7C7]/50 opacity-60'
                  }`}
                >
                  <span className="text-2xl">{m.icon}</span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <h5 className="text-xs font-bold truncate">
                        {language === 'am' ? m.titleAm : m.titleEn}
                      </h5>
                      {isUnlocked && (
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#10232b] text-[#C79A6A] border border-[#2D6F8B]">
                          {language === 'am' ? 'ተሳክቷል ✓' : 'Unlocked ✓'}
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] truncate text-[#8FB7C7]">
                      {language === 'am' ? m.descAm : m.descEn}
                    </p>
                  </div>
                  <span className="text-[11px] font-bold text-[#C79A6A]">
                    {m.threshold} {language === 'am' ? 'ቀን' : 'd'}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Action Button: Jump to Next Unread Day */}
        <button
          onClick={() => {
            onJumpToNextUnread();
            onClose();
          }}
          className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-gradient-to-r from-[#2D6F8B] via-[#8FB7C7] to-[#C79A6A] hover:brightness-110 text-[#0f232b] font-bold text-sm shadow-lg transition-all cursor-pointer"
        >
          <span>{language === 'am' ? 'ቀጣዩን ያልተነበበ ቀን አንብብ' : 'Continue to Next Unread Day'}</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
