import React from 'react';
import { ETHIOPIAN_MONTHS } from '../data/biblePlanData';
import { CheckCircle2 } from 'lucide-react';

interface MonthSelectorProps {
  selectedMonthIndex: number;
  onSelectMonth: (index: number) => void;
  completedDays: Record<number, boolean>;
  language: 'am' | 'en';
}

export const MonthSelector: React.FC<MonthSelectorProps> = ({
  selectedMonthIndex,
  onSelectMonth,
  completedDays,
  language,
}) => {
  // First 12 months (Meskerem to Nehase - 30 days each)
  const mainMonths = ETHIOPIAN_MONTHS.slice(0, 12);
  // 13th month: Pagume (5 days)
  const pagumeMonth = ETHIOPIAN_MONTHS[12];

  const getMonthCompletedCount = (monthIdx: number): number => {
    const month = ETHIOPIAN_MONTHS[monthIdx];
    let count = 0;
    for (let day = month.startDay; day <= month.endDay; day++) {
      if (completedDays[day]) count++;
    }
    return count;
  };

  const renderMonthButton = (month: typeof ETHIOPIAN_MONTHS[0], isPagume: boolean = false) => {
    const isSelected = selectedMonthIndex === month.index;
    const completed = getMonthCompletedCount(month.index);
    const isFullyComplete = completed === month.daysCount;

    return (
      <button
        key={month.index}
        id={`month-btn-${month.index}`}
        onClick={() => onSelectMonth(month.index)}
        className={`group relative flex flex-col items-center justify-center py-2 px-3 rounded-lg text-xs sm:text-sm font-medium transition-all duration-200 cursor-pointer min-h-[52px] ${
          isSelected
            ? 'bg-gradient-to-b from-[#C79A6A] to-[#b38555] text-[#16323D] font-bold shadow-[0_0_15px_rgba(199,154,106,0.35)] scale-[1.03] ring-1 ring-[#F2E7D8]'
            : 'bg-[#16323D] hover:bg-[#1f4553] text-[#F2E7D8] border border-[#2D6F8B]/70 hover:border-[#8FB7C7] shadow-sm'
        } ${isPagume ? 'min-w-[90px]' : 'flex-1 min-w-[72px]'}`}
      >
        {/* Month Name */}
        <span className="truncate leading-tight mb-1">
          {language === 'am' ? month.name : month.nameEnglish}
        </span>

        {/* Fraction Count or Completed Check */}
        <div className="flex items-center gap-1">
          {isFullyComplete ? (
            <span
              className={`flex items-center gap-0.5 text-[11px] ${
                isSelected ? 'text-[#16323D]' : 'text-[#8FB7C7]'
              }`}
            >
              <CheckCircle2 className="w-3 h-3 text-current" />
              <span>{completed}/{month.daysCount}</span>
            </span>
          ) : (
            <span
              className={`text-[11px] ${
                isSelected ? 'text-[#16323D]/90 font-bold' : 'text-[#8FB7C7]'
              }`}
            >
              {completed}/{month.daysCount}
            </span>
          )}
        </div>
      </button>
    );
  };

  return (
    <div className="w-full max-w-5xl mx-auto mb-8">
      {/* 12 Months Row (Meskerem to Nehase) */}
      <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-12 gap-1.5 sm:gap-2 mb-2">
        {mainMonths.map((m) => renderMonthButton(m))}
      </div>

      {/* 13th Month: Pagume (Centered Below, Exactly Like Screenshot) */}
      <div className="flex justify-center mt-2">
        {pagumeMonth && renderMonthButton(pagumeMonth, true)}
      </div>
    </div>
  );
};
