import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  X,
  BookOpen,
  Columns2,
  Maximize2,
  Minimize2,
  ChevronLeft,
  ChevronRight,
  Search,
  Type,
  Copy,
  Check,
  RotateCcw,
  Sparkles,
  Bookmark,
  Share2,
} from 'lucide-react';
import {
  BIBLE_BOOKS,
  BIBLE_VERSIONS,
  BibleBookInfo,
  BibleVersion,
  BibleVerse,
} from '../data/amharicBibleData';
import { fetchBibleChapter, ChapterResult } from '../utils/bibleService';

interface BibleReaderModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialBook?: string;
  initialChapter?: number;
  initialVersion?: BibleVersion;
}

export const BibleReaderModal: React.FC<BibleReaderModalProps> = ({
  isOpen,
  onClose,
  initialBook = 'ዘፍጥረት',
  initialChapter = 1,
  initialVersion = 'nasv',
}) => {
  const [selectedBookName, setSelectedBookName] = useState<string>(initialBook);
  const [selectedChapter, setSelectedChapter] = useState<number>(initialChapter);
  const [selectedVersion, setSelectedVersion] = useState<BibleVersion>(initialVersion);
  const [isSideBySide, setIsSideBySide] = useState<boolean>(false);
  const [readerTheme, setReaderTheme] = useState<'parchment' | 'clean' | 'night'>('parchment');
  const [fontSize, setFontSize] = useState<number>(18);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [showBookPicker, setShowBookPicker] = useState<boolean>(false);
  const [bookTab, setBookTab] = useState<'all' | 'old' | 'new'>('all');

  // Verses data
  const [primaryChapterData, setPrimaryChapterData] = useState<ChapterResult | null>(null);
  const [comparisonChapterData, setComparisonChapterData] = useState<ChapterResult | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [copiedVerse, setCopiedVerse] = useState<number | null>(null);
  const [copiedAll, setCopiedAll] = useState<boolean>(false);

  // Find book info
  const currentBook = useMemo(() => {
    return (
      BIBLE_BOOKS.find((b) => b.nameAm === selectedBookName) ||
      BIBLE_BOOKS.find((b) => b.nameEn.toLowerCase() === selectedBookName.toLowerCase()) ||
      BIBLE_BOOKS[0]
    );
  }, [selectedBookName]);

  // Sync initial props when opened
  useEffect(() => {
    if (isOpen) {
      if (initialBook) setSelectedBookName(initialBook);
      if (initialChapter) setSelectedChapter(initialChapter);
      if (initialVersion) setSelectedVersion(initialVersion);
    }
  }, [isOpen, initialBook, initialChapter, initialVersion]);

  // Fetch chapter data when book, chapter, or version changes
  useEffect(() => {
    if (!isOpen) return;

    let isMounted = true;
    const loadChapter = async () => {
      setIsLoading(true);
      try {
        const primary = await fetchBibleChapter(currentBook.nameAm, selectedChapter, selectedVersion);
        if (isMounted) setPrimaryChapterData(primary);

        if (isSideBySide) {
          const compVersion: BibleVersion = selectedVersion === 'nasv' ? '1954' : 'nasv';
          const comparison = await fetchBibleChapter(currentBook.nameAm, selectedChapter, compVersion);
          if (isMounted) setComparisonChapterData(comparison);
        }
      } catch (e) {
        console.error('Failed to load chapter in modal:', e);
      } finally {
        if (isMounted) setIsLoading(false);
      }
    };

    loadChapter();

    return () => {
      isMounted = false;
    };
  }, [isOpen, currentBook.nameAm, selectedChapter, selectedVersion, isSideBySide]);

  // Filtered books for picker
  const filteredBooks = useMemo(() => {
    return BIBLE_BOOKS.filter((b) => {
      const matchSearch =
        !searchQuery ||
        b.nameAm.includes(searchQuery) ||
        b.nameEn.toLowerCase().includes(searchQuery.toLowerCase()) ||
        b.shortAm.includes(searchQuery);

      if (!matchSearch) return false;
      if (bookTab === 'old') return b.testament === 'ብሉይ ኪዳን';
      if (bookTab === 'new') return b.testament === 'ሐዲስ ኪዳን';
      return true;
    });
  }, [searchQuery, bookTab]);

  // Handle Chapter change
  const handlePrevChapter = () => {
    if (selectedChapter > 1) {
      setSelectedChapter((prev) => prev - 1);
    } else {
      // Go to previous book if available
      const currentIndex = BIBLE_BOOKS.findIndex((b) => b.id === currentBook.id);
      if (currentIndex > 0) {
        const prevBook = BIBLE_BOOKS[currentIndex - 1];
        setSelectedBookName(prevBook.nameAm);
        setSelectedChapter(prevBook.chaptersCount);
      }
    }
  };

  const handleNextChapter = () => {
    if (selectedChapter < currentBook.chaptersCount) {
      setSelectedChapter((prev) => prev + 1);
    } else {
      // Go to next book if available
      const currentIndex = BIBLE_BOOKS.findIndex((b) => b.id === currentBook.id);
      if (currentIndex < BIBLE_BOOKS.length - 1) {
        const nextBook = BIBLE_BOOKS[currentIndex + 1];
        setSelectedBookName(nextBook.nameAm);
        setSelectedChapter(1);
      }
    }
  };

  const handleCopyVerse = (verseNum: number, text: string) => {
    const fullText = `${currentBook.nameAm} ${selectedChapter}:${verseNum} (${selectedVersion === 'nasv' ? 'አዲሱ መደበኛ' : '1954'}) - "${text}"`;
    navigator.clipboard.writeText(fullText);
    setCopiedVerse(verseNum);
    setTimeout(() => setCopiedVerse(null), 2000);
  };

  const handleCopyEntireChapter = () => {
    if (!primaryChapterData?.verses?.length) return;
    const all = primaryChapterData.verses
      .map((v) => `${v.verse}. ${v.text}`)
      .join('\n');
    const fullHeading = `${currentBook.nameAm} ምዕራፍ ${selectedChapter} (${primaryChapterData.versionName})\n\n${all}`;
    navigator.clipboard.writeText(fullHeading);
    setCopiedAll(true);
    setTimeout(() => setCopiedAll(false), 2000);
  };

  if (!isOpen) return null;

  // Background styling based on selected reading theme
  const themeClasses = {
    parchment: 'bg-[#FAF6EF] text-[#2C221E] border-amber-200/80',
    clean: 'bg-white text-slate-800 border-slate-200',
    night: 'bg-[#181615] text-[#EBE6DF] border-stone-800',
  }[readerTheme];

  const headerThemeClasses = {
    parchment: 'bg-[#F4EFE6] border-amber-200/60 text-[#2C221E]',
    clean: 'bg-slate-50 border-slate-200 text-slate-800',
    night: 'bg-[#201D1A] border-stone-800 text-[#EBE6DF]',
  }[readerTheme];

  const cardThemeClasses = {
    parchment: 'bg-[#FCF9F3] border-amber-100/80 hover:border-amber-300/80',
    clean: 'bg-white border-slate-100 hover:border-slate-300',
    night: 'bg-[#1E1B19] border-stone-800 hover:border-stone-700',
  }[readerTheme];

  return (
    <div
      id="bible-reader-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/65 backdrop-blur-sm animate-fade-in"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        id="bible-reader-container"
        className={`w-full max-w-5xl h-[92vh] max-h-[900px] flex flex-col rounded-2xl shadow-2xl overflow-hidden border ${themeClasses}`}
      >
        {/* Top App Bar */}
        <div className={`px-4 py-3 border-b flex items-center justify-between gap-2 sm:gap-4 ${headerThemeClasses}`}>
          {/* Book & Chapter Selector Trigger */}
          <div className="flex items-center gap-2">
            <button
              id="bible-book-picker-btn"
              onClick={() => setShowBookPicker(!showBookPicker)}
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-amber-600/10 hover:bg-amber-600/20 text-amber-900 font-bold text-sm sm:text-base transition-colors border border-amber-600/30"
              title="መጽሐፍና ምዕራፍ ምረጥ"
            >
              <BookOpen className="w-4 h-4 text-amber-700" />
              <span>{currentBook.nameAm}</span>
              <span className="bg-amber-700 text-white text-xs px-2 py-0.5 rounded-full font-sans">
                ምዕ {selectedChapter}
              </span>
            </button>

            {/* Quick Version Selectors */}
            <div className="hidden sm:flex items-center bg-black/5 dark:bg-white/5 p-1 rounded-xl border border-amber-900/10">
              <button
                id="select-version-nasv-btn"
                onClick={() => setSelectedVersion('nasv')}
                className={`px-3 py-1 text-xs font-semibold rounded-lg transition-all ${
                  selectedVersion === 'nasv'
                    ? 'bg-amber-700 text-white shadow-sm'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                አዲሱ መደበኛ
              </button>
              <button
                id="select-version-1954-btn"
                onClick={() => setSelectedVersion('1954')}
                className={`px-3 py-1 text-xs font-semibold rounded-lg transition-all ${
                  selectedVersion === '1954'
                    ? 'bg-amber-700 text-white shadow-sm'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                የ1954 ዓ.ም
              </button>
            </div>

            {/* Side-by-Side Comparison Toggle */}
            <button
              id="toggle-side-by-side-btn"
              onClick={() => setIsSideBySide(!isSideBySide)}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors border ${
                isSideBySide
                  ? 'bg-amber-100 text-amber-900 border-amber-400 font-bold'
                  : 'bg-transparent text-stone-600 border-stone-300 hover:bg-black/5'
              }`}
              title="ሁለቱንም ትርጉሞች ጎን ለጎን አወዳድር"
            >
              <Columns2 className="w-3.5 h-3.5" />
              <span className="hidden md:inline">ጎን ለጎን አወዳድር</span>
            </button>
          </div>

          {/* Reader Preferences & Controls */}
          <div className="flex items-center gap-1 sm:gap-2">
            {/* Font Size controls */}
            <div className="flex items-center bg-black/5 rounded-lg p-0.5">
              <button
                id="font-size-dec-btn"
                onClick={() => setFontSize((f) => Math.max(14, f - 2))}
                className="w-7 h-7 flex items-center justify-center text-xs font-bold rounded hover:bg-black/10"
                title="የፊደል መጠን ቀንስ"
              >
                A-
              </button>
              <button
                id="font-size-inc-btn"
                onClick={() => setFontSize((f) => Math.min(28, f + 2))}
                className="w-7 h-7 flex items-center justify-center text-xs font-bold rounded hover:bg-black/10"
                title="የፊደል መጠን ጨምር"
              >
                A+
              </button>
            </div>

            {/* Theme Toggle */}
            <div className="hidden sm:flex items-center gap-1 bg-black/5 rounded-lg p-0.5">
              <button
                id="theme-parchment-btn"
                onClick={() => setReaderTheme('parchment')}
                className={`w-6 h-6 rounded-full border ${readerTheme === 'parchment' ? 'ring-2 ring-amber-600' : ''}`}
                style={{ backgroundColor: '#FAF6EF' }}
                title="የብራና ቀለም"
              />
              <button
                id="theme-clean-btn"
                onClick={() => setReaderTheme('clean')}
                className={`w-6 h-6 rounded-full border ${readerTheme === 'clean' ? 'ring-2 ring-amber-600' : ''}`}
                style={{ backgroundColor: '#FFFFFF' }}
                title="ንጹሕ ነጭ"
              />
              <button
                id="theme-night-btn"
                onClick={() => setReaderTheme('night')}
                className={`w-6 h-6 rounded-full border ${readerTheme === 'night' ? 'ring-2 ring-amber-600' : ''}`}
                style={{ backgroundColor: '#181615' }}
                title="የሌሊት ንባብ"
              />
            </div>

            {/* Copy Whole Chapter */}
            <button
              id="copy-chapter-btn"
              onClick={handleCopyEntireChapter}
              className="p-1.5 rounded-lg text-stone-600 hover:text-amber-800 hover:bg-amber-100/50 transition-colors"
              title="ሙሉውን ምዕራፍ ገልብጥ"
            >
              {copiedAll ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
            </button>

            {/* Close Modal */}
            <button
              id="close-bible-modal-btn"
              onClick={onClose}
              className="p-1.5 rounded-lg text-stone-600 hover:text-rose-600 hover:bg-rose-50 transition-colors"
              title="ዝጋ"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Mobile Version Selector Banner */}
        <div className="sm:hidden px-3 py-1.5 bg-amber-500/10 border-b border-amber-500/20 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <span className="text-stone-500">ትርጉም:</span>
            <button
              onClick={() => setSelectedVersion('nasv')}
              className={`px-2 py-0.5 rounded font-semibold ${selectedVersion === 'nasv' ? 'bg-amber-700 text-white' : 'text-stone-700'}`}
            >
              አዲሱ መደበኛ
            </button>
            <button
              onClick={() => setSelectedVersion('1954')}
              className={`px-2 py-0.5 rounded font-semibold ${selectedVersion === '1954' ? 'bg-amber-700 text-white' : 'text-stone-700'}`}
            >
              የ1954
            </button>
          </div>
          <button
            onClick={() => setIsSideBySide(!isSideBySide)}
            className="text-amber-800 underline font-medium"
          >
            {isSideBySide ? 'አንድ አምድ' : 'ጎን ለጎን'}
          </button>
        </div>

        {/* Book & Chapter Navigation Dropdown Drawer */}
        {showBookPicker && (
          <div className="p-4 bg-amber-50/95 dark:bg-stone-900/95 border-b border-amber-200 backdrop-blur shadow-md max-h-72 overflow-y-auto z-20">
            <div className="flex flex-col sm:flex-row gap-3 items-center justify-between mb-3">
              {/* Search input */}
              <div className="relative w-full sm:w-64">
                <Search className="w-4 h-4 absolute left-3 top-2.5 text-stone-400" />
                <input
                  type="text"
                  placeholder="መጽሐፍ ፈልግ (ምሳሌ፦ ዘፍጥረት፣ ሮሜ)..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-1.5 text-sm bg-white dark:bg-stone-800 border rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>

              {/* Testament filter tabs */}
              <div className="flex items-center gap-1 text-xs">
                <button
                  onClick={() => setBookTab('all')}
                  className={`px-2.5 py-1 rounded-md font-medium ${bookTab === 'all' ? 'bg-amber-700 text-white' : 'bg-white dark:bg-stone-800 text-stone-700'}`}
                >
                  ሁሉም (66)
                </button>
                <button
                  onClick={() => setBookTab('old')}
                  className={`px-2.5 py-1 rounded-md font-medium ${bookTab === 'old' ? 'bg-amber-700 text-white' : 'bg-white dark:bg-stone-800 text-stone-700'}`}
                >
                  ብሉይ ኪዳን (39)
                </button>
                <button
                  onClick={() => setBookTab('new')}
                  className={`px-2.5 py-1 rounded-md font-medium ${bookTab === 'new' ? 'bg-amber-700 text-white' : 'bg-white dark:bg-stone-800 text-stone-700'}`}
                >
                  ሐዲስ ኪዳን (27)
                </button>
              </div>
            </div>

            {/* Books grid */}
            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-1.5 mb-4">
              {filteredBooks.map((b) => (
                <button
                  key={b.id}
                  onClick={() => {
                    setSelectedBookName(b.nameAm);
                    setSelectedChapter(1);
                  }}
                  className={`px-2 py-1.5 rounded-lg text-xs text-left truncate transition-all ${
                    b.nameAm === currentBook.nameAm
                      ? 'bg-amber-700 text-white font-bold shadow'
                      : 'bg-white dark:bg-stone-800 text-stone-700 dark:text-stone-300 hover:bg-amber-100 border border-stone-200 dark:border-stone-700'
                  }`}
                >
                  <span className="font-semibold">{b.nameAm}</span>
                  <span className="block text-[10px] opacity-70 truncate">{b.nameEn}</span>
                </button>
              ))}
            </div>

            {/* Chapters list for the active book */}
            <div className="border-t border-amber-200/60 pt-3">
              <div className="text-xs font-bold text-amber-900 dark:text-amber-200 mb-2">
                የ{currentBook.nameAm} ምዕራፍ ምረጥ ({currentBook.chaptersCount} ምዕራፎች)፦
              </div>
              <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto">
                {Array.from({ length: currentBook.chaptersCount }, (_, i) => i + 1).map((ch) => (
                  <button
                    key={ch}
                    onClick={() => {
                      setSelectedChapter(ch);
                      setShowBookPicker(false);
                    }}
                    className={`w-8 h-8 rounded-lg text-xs font-bold flex items-center justify-center transition-all ${
                      ch === selectedChapter
                        ? 'bg-amber-700 text-white shadow-md scale-105'
                        : 'bg-white dark:bg-stone-800 text-stone-700 dark:text-stone-300 hover:bg-amber-200/60 border border-stone-200 dark:border-stone-700'
                    }`}
                  >
                    {ch}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Chapter Header Banner */}
        <div className="px-6 py-3 border-b border-amber-200/30 flex items-center justify-between text-xs opacity-80">
          <div className="flex items-center gap-2">
            <span className="font-bold text-amber-800 dark:text-amber-300 text-sm">
              {currentBook.nameAm} ምዕራፍ {selectedChapter}
            </span>
            <span>•</span>
            <span>{currentBook.nameEn} {selectedChapter}</span>
            <span>•</span>
            <span className="font-semibold text-amber-700">
              {isSideBySide
                ? 'አዲሱ መደበኛ ትርጉም vs የ1954 ዓ.ም ትርጉም'
                : selectedVersion === 'nasv'
                ? 'አዲሱ መደበኛ ትርጉም (NASV)'
                : 'የ1954 ዓ.ም ጥንታዊ ትርጉም'}
            </span>
          </div>
          <div className="text-[11px] text-stone-500">
            {primaryChapterData?.verses?.length || 0} ቁጥሮች
          </div>
        </div>

        {/* Reading Main Content Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-8 space-y-4">
          {isLoading ? (
            <div className="flex flex-col items-center justify-center h-64 space-y-3">
              <div className="w-10 h-10 border-3 border-amber-600 border-t-transparent rounded-full animate-spin" />
              <div className="text-sm font-medium text-amber-800">
                የ{currentBook.nameAm} ምዕራፍ {selectedChapter} ቃላት በመጫን ላይ...
              </div>
              <p className="text-xs text-stone-500">
                {selectedVersion === 'nasv' ? 'አዲሱ መደበኛ ትርጉም' : 'የ1954 ዓ.ም ትርጉም'}
              </p>
            </div>
          ) : isSideBySide ? (
            /* Side-by-Side Comparison Layout */
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
              {/* Column 1: አዲሱ መደበኛ ትርጉም */}
              <div className="space-y-4 p-4 rounded-xl border border-amber-300/40 bg-white/40 dark:bg-black/20">
                <div className="sticky top-0 bg-amber-100/90 dark:bg-stone-800/90 backdrop-blur px-3 py-1.5 rounded-lg text-xs font-bold text-amber-900 dark:text-amber-200 border border-amber-300 flex items-center justify-between">
                  <span>አዲሱ መደበኛ ትርጉም (NASV)</span>
                  <span className="text-[10px] font-normal opacity-80">ዘመናዊ ግልጽ አማርኛ</span>
                </div>
                <div className="space-y-3" style={{ fontSize: `${fontSize}px`, lineHeight: 1.7 }}>
                  {(selectedVersion === 'nasv' ? primaryChapterData?.verses : comparisonChapterData?.verses)?.map((v) => (
                    <div
                      key={`nasv-${v.verse}`}
                      className="group flex items-start gap-2 p-1.5 rounded-lg hover:bg-amber-100/40 transition-colors"
                    >
                      <span className="shrink-0 text-xs font-bold text-amber-700 select-none pt-1">
                        {v.verse}
                      </span>
                      <p className="flex-1 font-serif tracking-normal">{v.text}</p>
                      <button
                        onClick={() => handleCopyVerse(v.verse, v.text)}
                        className="opacity-0 group-hover:opacity-100 transition-opacity p-1 text-stone-400 hover:text-amber-700"
                        title="ይህን ቁጥር ገልብጥ"
                      >
                        {copiedVerse === v.verse ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Column 2: የ1954 ዓ.ም ትርጉም */}
              <div className="space-y-4 p-4 rounded-xl border border-amber-300/40 bg-white/40 dark:bg-black/20">
                <div className="sticky top-0 bg-amber-100/90 dark:bg-stone-800/90 backdrop-blur px-3 py-1.5 rounded-lg text-xs font-bold text-amber-900 dark:text-amber-200 border border-amber-300 flex items-center justify-between">
                  <span>የ1954 ዓ.ም ትርጉም (ጥንታዊ)</span>
                  <span className="text-[10px] font-normal opacity-80">ባህላዊ የኢትዮጵያ ንባብ</span>
                </div>
                <div className="space-y-3" style={{ fontSize: `${fontSize}px`, lineHeight: 1.7 }}>
                  {(selectedVersion === '1954' ? primaryChapterData?.verses : comparisonChapterData?.verses)?.map((v) => (
                    <div
                      key={`1954-${v.verse}`}
                      className="group flex items-start gap-2 p-1.5 rounded-lg hover:bg-amber-100/40 transition-colors"
                    >
                      <span className="shrink-0 text-xs font-bold text-amber-700 select-none pt-1">
                        {v.verse}
                      </span>
                      <p className="flex-1 font-serif tracking-normal">{v.text}</p>
                      <button
                        onClick={() => handleCopyVerse(v.verse, v.text)}
                        className="opacity-0 group-hover:opacity-100 transition-opacity p-1 text-stone-400 hover:text-amber-700"
                        title="ይህን ቁጥር ገልብጥ"
                      >
                        {copiedVerse === v.verse ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            /* Single Version Reading Layout */
            <div className="max-w-3xl mx-auto space-y-4">
              <div className="space-y-3" style={{ fontSize: `${fontSize}px`, lineHeight: 1.75 }}>
                {primaryChapterData?.verses?.map((v) => (
                  <div
                    key={v.verse}
                    className={`group flex items-start gap-3 p-2.5 rounded-xl border transition-all ${cardThemeClasses}`}
                  >
                    <span className="shrink-0 flex items-center justify-center w-6 h-6 rounded-full bg-amber-600/15 text-amber-800 dark:text-amber-300 text-xs font-bold font-sans select-none mt-0.5">
                      {v.verse}
                    </span>
                    <p className="flex-1 font-serif font-normal tracking-wide text-justify">
                      {v.text}
                    </p>
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button
                        onClick={() => handleCopyVerse(v.verse, v.text)}
                        className="p-1.5 rounded text-stone-400 hover:text-amber-800 hover:bg-black/5"
                        title="ይህን ቁጥር ገልብጥ"
                      >
                        {copiedVerse === v.verse ? (
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Bottom Chapter Navigation Bar */}
        <div className={`px-4 py-3 border-t flex items-center justify-between ${headerThemeClasses}`}>
          <button
            id="prev-chapter-btn"
            onClick={handlePrevChapter}
            className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs sm:text-sm font-semibold hover:bg-black/5 transition-colors border border-stone-300 dark:border-stone-700"
          >
            <ChevronLeft className="w-4 h-4" />
            <span>ቀዳሚ ምዕራፍ</span>
          </button>

          <div className="flex items-center gap-2 text-xs font-medium text-stone-600 dark:text-stone-400">
            <span>
              {currentBook.nameAm} : {selectedChapter} / {currentBook.chaptersCount}
            </span>
          </div>

          <button
            id="next-chapter-btn"
            onClick={handleNextChapter}
            className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs sm:text-sm font-semibold bg-amber-700 text-white hover:bg-amber-800 transition-colors shadow-sm"
          >
            <span>ቀጣይ ምዕራፍ</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
