import React, { useState } from 'react';
import { ReadingDay, MonthInfo } from '../types';
import { Check, BookOpen, CheckCheck, Filter } from 'lucide-react';

interface DayCardGridProps {
  currentMonth: MonthInfo;
  days: ReadingDay[];
  completedDays: Record<number, boolean>;
  onToggleDay: (dayNumber: number, event?: React.MouseEvent) => void;
  onOpenDayModal: (day: ReadingDay) => void;
  onMarkMonthAll: (monthDays: ReadingDay[], complete: boolean) => void;
  language: 'am' | 'en';
}

export const DayCardGrid: React.FC<DayCardGridProps> = ({
  currentMonth,
  days,
  completedDays,
  onToggleDay,
  onOpenDayModal,
  onMarkMonthAll,
  language,
}) => {
  const [filter, setFilter] = useState<'all' | 'unread' | 'completed'>('all');

  // Filter days for current month
  const monthDays = days.filter((d) => d.monthIndex === currentMonth.index);

  const filteredDays = monthDays.filter((d) => {
    const isCompleted = !!completedDays[d.dayNumber];
    if (filter === 'unread') return !isCompleted;
    if (filter === 'completed') return isCompleted;
    return true;
  });

  const monthCompletedCount = monthDays.filter((d) => completedDays[d.dayNumber]).length;
  const isMonthAllCompleted = monthCompletedCount === monthDays.length && monthDays.length > 0;

  return (
    <div className="w-full max-w-5xl mx-auto mb-16">
      {/* Month Section Header matching screenshot */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-6 pb-2 border-b border-[#2D6F8B]/40">
        <div className="text-center sm:text-left">
          <h2 className="text-lg sm:text-xl font-bold text-[#F2E7D8] tracking-wide font-serif-header">
            {language === 'am' ? currentMonth.name : currentMonth.nameEnglish} —{' '}
            <span className="text-[#C79A6A]">
              {currentMonth.daysCount} {language === 'am' ? 'ቀናት' : 'days'}
            </span>
          </h2>
          <p className="text-xs text-[#8FB7C7] mt-0.5">
            {currentMonth.theme}
          </p>
        </div>

        {/* Filters & Month Action Controls */}
        <div className="flex items-center gap-2 flex-wrap justify-center">
          <div className="inline-flex rounded-lg p-1 bg-[#10232b] border border-[#2D6F8B]/60">
            <button
              onClick={() => setFilter('all')}
              className={`px-2.5 py-1 text-xs rounded-md transition-all cursor-pointer ${
                filter === 'all'
                  ? 'bg-[#2D6F8B] text-[#F2E7D8] font-medium shadow'
                  : 'text-[#8FB7C7] hover:text-[#F2E7D8]'
              }`}
            >
              {language === 'am' ? 'ሁሉም' : 'All'} ({monthDays.length})
            </button>
            <button
              onClick={() => setFilter('unread')}
              className={`px-2.5 py-1 text-xs rounded-md transition-all cursor-pointer ${
                filter === 'unread'
                  ? 'bg-[#2D6F8B] text-[#F2E7D8] font-medium shadow'
                  : 'text-[#8FB7C7] hover:text-[#F2E7D8]'
              }`}
            >
              {language === 'am' ? 'ያልተነበቡ' : 'Unread'} ({monthDays.length - monthCompletedCount})
            </button>
            <button
              onClick={() => setFilter('completed')}
              className={`px-2.5 py-1 text-xs rounded-md transition-all cursor-pointer ${
                filter === 'completed'
                  ? 'bg-[#2D6F8B] text-[#F2E7D8] font-medium shadow'
                  : 'text-[#8FB7C7] hover:text-[#F2E7D8]'
              }`}
            >
              {language === 'am' ? 'የተጠናቀቁ' : 'Done'} ({monthCompletedCount})
            </button>
          </div>

          {/* Quick toggle all month */}
          <button
            onClick={() => onMarkMonthAll(monthDays, !isMonthAllCompleted)}
            id="mark-month-all-btn"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs bg-[#16323D] hover:bg-[#1f4553] text-[#8FB7C7] hover:text-[#F2E7D8] border border-[#2D6F8B]/70 hover:border-[#8FB7C7] transition-colors cursor-pointer"
            title={language === 'am' ? 'የወሩን ንባብ በሙሉ እንደተጠናቀቀ ምልክት አድርግ' : 'Toggle all days in this month'}
          >
            <CheckCheck className="w-3.5 h-3.5 text-[#C79A6A]" />
            <span>
              {isMonthAllCompleted
                ? (language === 'am' ? 'ሁሉንም ሰርዝ' : 'Unmark All')
                : (language === 'am' ? 'ወሩን ሙሉ አጠናቅቅ' : 'Complete Month')}
            </span>
          </button>
        </div>
      </div>

      {/* Grid of Day Cards Matching Screenshot */}
      {filteredDays.length === 0 ? (
        <div className="py-12 text-center rounded-xl bg-[#10232b] border border-[#2D6F8B]/40 text-[#8FB7C7]">
          <Filter className="w-8 h-8 mx-auto mb-2 text-[#2D6F8B]" />
          <p className="text-sm">
            {filter === 'unread'
              ? (language === 'am' ? 'በዚህ ወር የተጠናቀቁ ንባቦች በሙሉ ተነበዋል! ድንቅ ነው!' : 'All readings for this month are completed!')
              : (language === 'am' ? 'እስካሁን የተነበበ የለም። የመጀመሪያውን ቀን ይጀምሩ!' : 'No completed readings yet. Start reading!')}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3 sm:gap-4">
          {filteredDays.map((day) => {
            const isCompleted = !!completedDays[day.dayNumber];

            return (
              <div
                key={day.dayNumber}
                id={`day-card-${day.dayNumber}`}
                onClick={() => onOpenDayModal(day)}
                className={`group relative flex flex-col justify-between p-4 rounded-xl border transition-all duration-200 cursor-pointer shadow-md min-h-[110px] select-none ${
                  isCompleted
                    ? 'bg-gradient-to-b from-[#193a47] to-[#122832] border-[#C79A6A]/80 hover:border-[#F2E7D8] shadow-[0_4px_14px_rgba(0,0,0,0.4)]'
                    : 'bg-gradient-to-b from-[#16323D] to-[#11262f] border-[#2D6F8B]/50 hover:border-[#8FB7C7] hover:shadow-lg hover:-translate-y-0.5'
                }`}
              >
                {/* Top Row: Day Label + Circular Tick Checkbox */}
                <div className="flex items-center justify-between mb-2">
                  <span
                    className={`text-xs font-semibold tracking-wide ${
                      isCompleted ? 'text-[#C79A6A]' : 'text-[#8FB7C7] group-hover:text-[#F2E7D8]'
                    }`}
                  >
                    {language === 'am' ? `ቀን ${day.monthDay}` : `Day ${day.monthDay}`}
                    <span className="text-[10px] font-normal text-[#8FB7C7]/70 ml-1.5">
                      (#{day.dayNumber})
                    </span>
                  </span>

                  {/* Circular Tick Button matching screenshot */}
                  <button
                    type="button"
                    id={`tick-btn-${day.dayNumber}`}
                    onClick={(e) => {
                      e.stopPropagation();
                      onToggleDay(day.dayNumber, e);
                    }}
                    className={`w-6 h-6 rounded-full flex items-center justify-center transition-all duration-200 cursor-pointer ${
                      isCompleted
                        ? 'bg-[#C79A6A] text-[#16323D] shadow-[0_0_8px_rgba(199,154,106,0.5)] ring-2 ring-[#F2E7D8]'
                        : 'bg-[#10232b] border border-[#2D6F8B] hover:border-[#8FB7C7] hover:bg-[#1a3845] text-transparent'
                    }`}
                    title={isCompleted ? (language === 'am' ? 'እንደተነበበ ተመዝግቧል' : 'Mark as unread') : (language === 'am' ? 'አንብቤያለሁ (ምልክት አድርግ)' : 'Mark as read')}
                  >
                    <Check className={`w-3.5 h-3.5 stroke-[3] ${isCompleted ? 'opacity-100' : 'opacity-0'}`} />
                  </button>
                </div>

                {/* Main Passage Text matching screenshot */}
                <div className="my-1">
                  <h3
                    className={`text-sm sm:text-base font-bold tracking-tight transition-colors line-clamp-2 ${
                      isCompleted ? 'text-[#8FB7C7] line-through decoration-[#C79A6A]/60' : 'text-[#F2E7D8] group-hover:text-[#F2E7D8]'
                    }`}
                  >
                    {language === 'am' ? day.passage : day.passageEnglish}
                  </h3>
                </div>

                {/* Bottom Row: Key Verse Hint & Testament Badge */}
                <div className="flex items-center justify-between text-[11px] text-[#8FB7C7] pt-1 mt-1 border-t border-[#2D6F8B]/30">
                  <span className="truncate max-w-[120px]" title={day.keyVerse.reference}>
                    {language === 'am' ? day.keyVerse.reference : day.keyVerse.referenceEnglish}
                  </span>
                  <div className="flex items-center gap-1 text-[#8FB7C7] group-hover:text-[#C79A6A]">
                    <BookOpen className="w-3 h-3" />
                    <span className="text-[10px]">{language === 'am' ? 'አንብብ' : 'Read'}</span>
                  </div>
                </div>

                {/* Completed subtle glow aura */}
                {isCompleted && (
                  <div className="absolute top-1 right-1 w-2 h-2 rounded-full bg-[#C79A6A] shadow-[0_0_6px_#C79A6A]" />
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
