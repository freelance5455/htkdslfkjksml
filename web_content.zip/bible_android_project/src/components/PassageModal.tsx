import React, { useState, useEffect, useMemo } from 'react';
import { ReadingDay } from '../types';
import {
  X,
  Check,
  BookOpen,
  ChevronLeft,
  ChevronRight,
  Copy,
  CheckCircle,
  Heart,
  Columns2,
  Maximize2,
  Share2,
} from 'lucide-react';
import { parsePassageRange, BibleVersion, BibleVerse } from '../data/amharicBibleData';
import { fetchBibleChapter, ChapterResult } from '../utils/bibleService';

interface PassageModalProps {
  day: ReadingDay | null;
  isOpen: boolean;
  onClose: () => void;
  isCompleted: boolean;
  onToggleComplete: (dayNumber: number) => void;
  onNavigateDay: (offset: number) => void;
  savedNote?: string;
  onSaveNote: (dayNumber: number, note: string) => void;
  language: 'am' | 'en';
  onOpenFullBibleReader?: (book: string, chapter: number) => void;
}

export const PassageModal: React.FC<PassageModalProps> = ({
  day,
  isOpen,
  onClose,
  isCompleted,
  onToggleComplete,
  onNavigateDay,
  savedNote = '',
  onSaveNote,
  language,
  onOpenFullBibleReader,
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'reader'>('overview');
  const [noteText, setNoteText] = useState(savedNote);
  const [copied, setCopied] = useState(false);
  const [isNoteSaved, setIsNoteSaved] = useState(false);

  // In-modal Bible reader state
  const [selectedVersion, setSelectedVersion] = useState<BibleVersion>('nasv');
  const [isSideBySide, setIsSideBySide] = useState<boolean>(false);
  const [fontSize, setFontSize] = useState<number>(16);
  const [copiedVerseNum, setCopiedVerseNum] = useState<number | null>(null);

  // Parse chapters for the current day
  const passageInfo = useMemo(() => {
    if (!day) return { bookName: 'ዘፍጥረት', startChapter: 1, endChapter: 1 };
    return parsePassageRange(day.passage);
  }, [day?.passage]);

  const [activeChapter, setActiveChapter] = useState<number>(1);

  // Chapter verses state
  const [primaryChapterData, setPrimaryChapterData] = useState<ChapterResult | null>(null);
  const [compChapterData, setCompChapterData] = useState<ChapterResult | null>(null);
  const [isLoadingVerses, setIsLoadingVerses] = useState<boolean>(false);

  useEffect(() => {
    setNoteText(savedNote);
  }, [savedNote, day?.dayNumber]);

  // Reset active chapter when day changes
  useEffect(() => {
    if (passageInfo) {
      setActiveChapter(passageInfo.startChapter);
    }
  }, [passageInfo.bookName, passageInfo.startChapter]);

  // Load verses whenever reader tab is active or chapter/version changes
  useEffect(() => {
    if (!isOpen || !day) return;

    let isMounted = true;
    const loadVerses = async () => {
      setIsLoadingVerses(true);
      try {
        const primary = await fetchBibleChapter(passageInfo.bookName, activeChapter, selectedVersion);
        if (isMounted) setPrimaryChapterData(primary);

        if (isSideBySide) {
          const compVer: BibleVersion = selectedVersion === 'nasv' ? '1954' : 'nasv';
          const comparison = await fetchBibleChapter(passageInfo.bookName, activeChapter, compVer);
          if (isMounted) setCompChapterData(comparison);
        }
      } catch (err) {
        console.error('Failed to load in-modal verses:', err);
      } finally {
        if (isMounted) setIsLoadingVerses(false);
      }
    };

    loadVerses();

    return () => {
      isMounted = false;
    };
  }, [isOpen, day, passageInfo.bookName, activeChapter, selectedVersion, isSideBySide]);

  if (!isOpen || !day) return null;

  const handleCopyVerse = () => {
    const textToCopy = `${day.keyVerse.text} — ${day.keyVerse.reference}`;
    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleCopySingleVerse = (verseNum: number, text: string) => {
    const fullText = `${passageInfo.bookName} ${activeChapter}:${verseNum} (${selectedVersion === 'nasv' ? 'አዲሱ መደበኛ' : '1954'}) - "${text}"`;
    navigator.clipboard.writeText(fullText);
    setCopiedVerseNum(verseNum);
    setTimeout(() => setCopiedVerseNum(null), 2000);
  };

  const handleNoteChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const val = e.target.value;
    setNoteText(val);
    onSaveNote(day.dayNumber, val);
    setIsNoteSaved(true);
    setTimeout(() => setIsNoteSaved(false), 1500);
  };

  // Generate chapter list for the day e.g. [1, 2, 3]
  const dayChapters = [];
  for (let c = passageInfo.startChapter; c <= passageInfo.endChapter; c++) {
    dayChapters.push(c);
  }

  return (
    <div
      id="passage-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/80 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-3xl max-h-[92vh] flex flex-col rounded-2xl bg-gradient-to-b from-[#16323D] to-[#0f232b] border-2 border-[#2D6F8B] text-[#F2E7D8] shadow-2xl my-auto overflow-hidden"
        onClick={(e) => e.stopPropagation()}
        id="passage-modal-content"
      >
        {/* Subtle interior border */}
        <div className="absolute inset-1.5 rounded-xl border border-[#8FB7C7]/20 pointer-events-none" />

        {/* Top Navigation & Tab Bar */}
        <div className="relative z-10 flex items-center justify-between p-4 sm:px-6 sm:py-4 border-b border-[#2D6F8B]/40 bg-[#122831]/80">
          <div className="flex items-center gap-2">
            <button
              onClick={() => onNavigateDay(-1)}
              disabled={day.dayNumber <= 1}
              className="p-1.5 rounded-lg bg-[#10232b] hover:bg-[#1a3845] text-[#8FB7C7] hover:text-[#F2E7D8] disabled:opacity-40 disabled:cursor-not-allowed transition-colors cursor-pointer"
              title={language === 'am' ? 'ያለፈው ቀን' : 'Previous Day'}
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="text-xs font-semibold text-[#C79A6A] tracking-wider uppercase">
              {language === 'am' ? `ቀን ${day.monthDay} (ከ365)` : `Day ${day.monthDay} of 365`}
            </span>
            <button
              onClick={() => onNavigateDay(1)}
              disabled={day.dayNumber >= 365}
              className="p-1.5 rounded-lg bg-[#10232b] hover:bg-[#1a3845] text-[#8FB7C7] hover:text-[#F2E7D8] disabled:opacity-40 disabled:cursor-not-allowed transition-colors cursor-pointer"
              title={language === 'am' ? 'ቀጣዩ ቀን' : 'Next Day'}
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {/* View Mode Tabs (Overview vs Read Scripture) */}
          <div className="flex items-center bg-[#0a171c] p-1 rounded-xl border border-[#2D6F8B]/60">
            <button
              id="tab-overview-btn"
              onClick={() => setActiveTab('overview')}
              className={`px-3 py-1 text-xs font-bold rounded-lg transition-all ${
                activeTab === 'overview'
                  ? 'bg-[#2D6F8B] text-[#F2E7D8] shadow'
                  : 'text-[#8FB7C7] hover:text-[#F2E7D8]'
              }`}
            >
              {language === 'am' ? 'የዕለቱ ማጠቃለያ' : 'Overview'}
            </button>
            <button
              id="tab-reader-btn"
              onClick={() => setActiveTab('reader')}
              className={`flex items-center gap-1.5 px-3 py-1 text-xs font-bold rounded-lg transition-all ${
                activeTab === 'reader'
                  ? 'bg-amber-600 text-white shadow'
                  : 'text-[#8FB7C7] hover:text-[#F2E7D8]'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>{language === 'am' ? 'መጽሐፍ ቅዱስ አንብብ (2 ትርጉሞች)' : 'Read Scripture (2 Versions)'}</span>
            </button>
          </div>

          <button
            onClick={onClose}
            id="close-modal-btn"
            className="p-1.5 rounded-lg text-[#8FB7C7] hover:text-[#F2E7D8] hover:bg-[#10232b] transition-colors cursor-pointer"
            title={language === 'am' ? 'ዝጋ' : 'Close'}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5">
          {activeTab === 'overview' ? (
            /* ================= OVERVIEW TAB ================= */
            <>
              {/* Passage Title */}
              <div className="text-center mb-2">
                <span className="inline-block px-3 py-1 rounded-full text-xs font-medium bg-[#10232b] text-[#C79A6A] border border-[#2D6F8B]/70 mb-2">
                  {day.testament}
                </span>
                <h2 className="text-2xl sm:text-3xl font-bold text-[#F2E7D8] font-serif-header">
                  {language === 'am' ? day.passage : day.passageEnglish}
                </h2>
                <p className="text-sm text-[#8FB7C7] mt-1 font-medium">
                  {language === 'am' ? day.theme : day.themeEnglish}
                </p>

                {/* Direct quick button to switch to reader */}
                <div className="mt-3 flex items-center justify-center gap-2">
                  <button
                    onClick={() => setActiveTab('reader')}
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-amber-600/20 hover:bg-amber-600/30 text-amber-300 border border-amber-500/50 text-xs font-bold transition-colors"
                  >
                    <BookOpen className="w-4 h-4 text-amber-400" />
                    <span>ይህን ክፍል በአማርኛ መጽሐፍ ቅዱስ አንብብ (አዲሱ መደበኛ & 1954)</span>
                  </button>
                </div>
              </div>

              {/* Key Memory Verse Box */}
              <div className="relative rounded-xl bg-[#0d1e25] border border-[#2D6F8B]/60 p-5 shadow-inner">
                <div className="flex items-center justify-between text-xs text-[#C79A6A] font-semibold mb-2">
                  <span className="flex items-center gap-1.5">
                    <BookOpen className="w-3.5 h-3.5 text-[#8FB7C7]" />
                    {language === 'am' ? 'የዕለቱ ዋና ቃል' : 'Key Scripture Verse'}
                  </span>
                  <button
                    onClick={handleCopyVerse}
                    className="flex items-center gap-1 text-[11px] text-[#8FB7C7] hover:text-[#F2E7D8] transition-colors cursor-pointer"
                    title="Copy verse"
                  >
                    {copied ? (
                      <>
                        <CheckCircle className="w-3.5 h-3.5 text-teal-400" />
                        <span className="text-teal-300">{language === 'am' ? 'ተቀድቷል' : 'Copied'}</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>{language === 'am' ? 'ቅዳ' : 'Copy'}</span>
                      </>
                    )}
                  </button>
                </div>
                <blockquote className="text-base sm:text-lg italic text-[#F2E7D8] leading-relaxed mb-2 font-serif">
                  {language === 'am' ? day.keyVerse.text : day.keyVerse.textEnglish}
                </blockquote>
                <div className="text-right text-xs font-bold text-[#C79A6A]">
                  — {language === 'am' ? day.keyVerse.reference : day.keyVerse.referenceEnglish}
                </div>
              </div>

              {/* Daily Reflection & Meditation */}
              <div className="p-4 rounded-xl bg-[#10232b] border border-[#2D6F8B]/50">
                <h4 className="flex items-center gap-2 text-xs font-bold text-[#C79A6A] uppercase tracking-wider mb-2">
                  <Heart className="w-3.5 h-3.5 text-[#8FB7C7]" />
                  {language === 'am' ? 'የማሰላሰያ ነጥብ' : 'Daily Reflection'}
                </h4>
                <p className="text-sm text-[#F2E7D8]/90 leading-relaxed">
                  {language === 'am' ? day.reflection : day.reflectionEnglish}
                </p>
              </div>

              {/* Guided Prayer */}
              <div className="p-4 rounded-xl bg-[#0e2027]/90 border border-[#2D6F8B]/40">
                <h4 className="text-xs font-bold text-[#8FB7C7] uppercase tracking-wider mb-1.5">
                  {language === 'am' ? 'የዕለት ጸሎት' : 'Daily Prayer'}
                </h4>
                <p className="text-xs sm:text-sm italic text-[#F2E7D8]/80 leading-relaxed">
                  {language === 'am' ? day.prayer : day.prayerEnglish}
                </p>
              </div>

              {/* Personal Notes Box (Stored locally) */}
              <div>
                <div className="flex items-center justify-between mb-1.5 text-xs text-[#8FB7C7]">
                  <label htmlFor="user-note-input" className="font-medium text-[#8FB7C7]">
                    {language === 'am' ? 'የግል ማስታወሻና ሐሳቦች (በራስ-ሰር ይቀመጣል)' : 'Personal Notes & Thoughts (Auto-saved)'}
                  </label>
                  {isNoteSaved && (
                    <span className="text-[11px] text-[#C79A6A] animate-pulse">
                      {language === 'am' ? 'ተቀምጧል ✓' : 'Saved ✓'}
                    </span>
                  )}
                </div>
                <textarea
                  id="user-note-input"
                  rows={3}
                  value={noteText}
                  onChange={handleNoteChange}
                  placeholder={
                    language === 'am'
                      ? 'በዚህ ንባብ ያገኘኸውን መንፈሳዊ ትምህርት እዚህ ጻፍ...'
                      : 'Write your reflections or takeaways from this reading...'
                  }
                  className="w-full p-3 rounded-xl bg-[#0a171c] border border-[#2D6F8B]/60 focus:border-[#C79A6A] focus:ring-1 focus:ring-[#C79A6A] text-sm text-[#F2E7D8] placeholder-[#8FB7C7]/50 outline-none transition-all resize-none"
                />
              </div>
            </>
          ) : (
            /* ================= SCRIPTURE READER TAB ================= */
            <div className="space-y-4">
              {/* Reader Subheader: Chapter selector & Version selector */}
              <div className="flex flex-wrap items-center justify-between gap-2 p-3 bg-[#0d1e25] rounded-xl border border-[#2D6F8B]/60">
                {/* Chapters tabs for the day */}
                <div className="flex items-center gap-1.5 overflow-x-auto py-1">
                  <span className="text-xs text-[#8FB7C7] mr-1">ምዕራፍ፦</span>
                  {dayChapters.map((ch) => (
                    <button
                      key={ch}
                      onClick={() => setActiveChapter(ch)}
                      className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                        ch === activeChapter
                          ? 'bg-amber-600 text-white shadow'
                          : 'bg-[#16323D] text-[#8FB7C7] hover:text-[#F2E7D8]'
                      }`}
                    >
                      {passageInfo.bookName} {ch}
                    </button>
                  ))}
                </div>

                {/* Translation switchers */}
                <div className="flex items-center gap-1 bg-[#10232b] p-1 rounded-lg border border-[#2D6F8B]/40 text-xs">
                  <button
                    onClick={() => setSelectedVersion('nasv')}
                    className={`px-2.5 py-1 rounded-md font-semibold transition-colors ${
                      selectedVersion === 'nasv'
                        ? 'bg-amber-700 text-white'
                        : 'text-[#8FB7C7] hover:text-[#F2E7D8]'
                    }`}
                  >
                    አዲሱ መደበኛ
                  </button>
                  <button
                    onClick={() => setSelectedVersion('1954')}
                    className={`px-2.5 py-1 rounded-md font-semibold transition-colors ${
                      selectedVersion === '1954'
                        ? 'bg-amber-700 text-white'
                        : 'text-[#8FB7C7] hover:text-[#F2E7D8]'
                    }`}
                  >
                    የ1954 ዓ.ም
                  </button>
                  <button
                    onClick={() => setIsSideBySide(!isSideBySide)}
                    className={`flex items-center gap-1 px-2.5 py-1 rounded-md transition-colors ${
                      isSideBySide
                        ? 'bg-amber-600/30 text-amber-300 font-bold border border-amber-500'
                        : 'text-[#8FB7C7] hover:text-[#F2E7D8]'
                    }`}
                    title="ሁለቱንም ትርጉሞች ጎን ለጎን አወዳድር"
                  >
                    <Columns2 className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">ጎን ለጎን</span>
                  </button>
                </div>

                {/* Font Size & Fullscreen Action */}
                <div className="flex items-center gap-1.5">
                  <div className="flex items-center bg-[#10232b] rounded-lg p-0.5 border border-[#2D6F8B]/40">
                    <button
                      onClick={() => setFontSize((f) => Math.max(13, f - 2))}
                      className="px-2 py-0.5 text-xs font-bold text-[#8FB7C7] hover:text-[#F2E7D8]"
                      title="ፊደል ቀንስ"
                    >
                      A-
                    </button>
                    <button
                      onClick={() => setFontSize((f) => Math.min(26, f + 2))}
                      className="px-2 py-0.5 text-xs font-bold text-[#8FB7C7] hover:text-[#F2E7D8]"
                      title="ፊደል ጨምር"
                    >
                      A+
                    </button>
                  </div>

                  {onOpenFullBibleReader && (
                    <button
                      onClick={() => {
                        onClose();
                        onOpenFullBibleReader(passageInfo.bookName, activeChapter);
                      }}
                      className="p-1.5 rounded-lg bg-[#16323D] hover:bg-[#1f4553] text-[#8FB7C7] hover:text-[#F2E7D8] border border-[#2D6F8B]/60"
                      title="ሙሉ የመጽሐፍ ቅዱስ ንባብ መስኮት ክፈት"
                    >
                      <Maximize2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>

              {/* Verses Render Area */}
              {isLoadingVerses ? (
                <div className="flex flex-col items-center justify-center py-16 space-y-3">
                  <div className="w-8 h-8 border-2 border-amber-500 border-t-transparent rounded-full animate-spin" />
                  <div className="text-xs text-[#8FB7C7]">
                    የ{passageInfo.bookName} ምዕራፍ {activeChapter} ቃላት በመጫን ላይ...
                  </div>
                </div>
              ) : isSideBySide ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* NASV Column */}
                  <div className="p-3 rounded-xl bg-[#0d1e25] border border-amber-500/30">
                    <div className="text-xs font-bold text-amber-300 pb-2 mb-2 border-b border-[#2D6F8B]/40 flex items-center justify-between">
                      <span>አዲሱ መደበኛ ትርጉም</span>
                      <span className="text-[10px] text-[#8FB7C7]">NASV</span>
                    </div>
                    <div className="space-y-2.5" style={{ fontSize: `${fontSize}px`, lineHeight: 1.7 }}>
                      {(selectedVersion === 'nasv' ? primaryChapterData?.verses : compChapterData?.verses)?.map((v) => (
                        <div key={`nasv-${v.verse}`} className="flex items-start gap-2">
                          <span className="text-xs font-bold text-amber-500 select-none pt-0.5">{v.verse}</span>
                          <p className="flex-1 font-serif text-[#F2E7D8]/95">{v.text}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* 1954 Column */}
                  <div className="p-3 rounded-xl bg-[#0d1e25] border border-amber-500/30">
                    <div className="text-xs font-bold text-amber-300 pb-2 mb-2 border-b border-[#2D6F8B]/40 flex items-center justify-between">
                      <span>የ1954 ዓ.ም ትርጉም</span>
                      <span className="text-[10px] text-[#8FB7C7]">ባህላዊ</span>
                    </div>
                    <div className="space-y-2.5" style={{ fontSize: `${fontSize}px`, lineHeight: 1.7 }}>
                      {(selectedVersion === '1954' ? primaryChapterData?.verses : compChapterData?.verses)?.map((v) => (
                        <div key={`1954-${v.verse}`} className="flex items-start gap-2">
                          <span className="text-xs font-bold text-amber-500 select-none pt-0.5">{v.verse}</span>
                          <p className="flex-1 font-serif text-[#F2E7D8]/95">{v.text}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="p-4 rounded-xl bg-[#0a171c] border border-[#2D6F8B]/50 space-y-3">
                  <div className="flex items-center justify-between text-xs text-[#C79A6A] border-b border-[#2D6F8B]/40 pb-2">
                    <span className="font-bold">
                      {passageInfo.bookName} ምዕራፍ {activeChapter} ({primaryChapterData?.versionName})
                    </span>
                    <span>{primaryChapterData?.verses?.length || 0} ቁጥሮች</span>
                  </div>
                  <div className="space-y-2.5" style={{ fontSize: `${fontSize}px`, lineHeight: 1.75 }}>
                    {primaryChapterData?.verses?.map((v) => (
                      <div
                        key={v.verse}
                        className="group flex items-start gap-2.5 p-1.5 rounded-lg hover:bg-[#16323D]/50 transition-colors"
                      >
                        <span className="shrink-0 text-xs font-bold text-amber-400 select-none pt-0.5 min-w-[20px]">
                          {v.verse}
                        </span>
                        <p className="flex-1 font-serif text-[#F2E7D8] text-justify">{v.text}</p>
                        <button
                          onClick={() => handleCopySingleVerse(v.verse, v.text)}
                          className="opacity-0 group-hover:opacity-100 transition-opacity p-1 text-[#8FB7C7] hover:text-[#F2E7D8]"
                          title="ይህን ቁጥር ቅዳ"
                        >
                          {copiedVerseNum === v.verse ? (
                            <Check className="w-3.5 h-3.5 text-teal-400" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Bottom Actions Bar */}
        <div className="relative z-10 flex flex-col sm:flex-row items-center justify-between gap-3 p-4 sm:px-6 border-t border-[#2D6F8B]/40 bg-[#122831]/90">
          <button
            type="button"
            onClick={() => setActiveTab((t) => (t === 'overview' ? 'reader' : 'overview'))}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-[#10232b] hover:bg-[#1a3845] text-[#8FB7C7] hover:text-[#F2E7D8] border border-[#2D6F8B]/60 text-xs font-semibold transition-colors cursor-pointer"
          >
            <BookOpen className="w-3.5 h-3.5 text-[#C79A6A]" />
            <span>
              {activeTab === 'overview'
                ? 'መጽሐፍ ቅዱስ አንብብ (አዲሱ መደበኛ / 1954)'
                : 'ወደ ዕለቱ ማጠቃለያ ተመለስ'}
            </span>
          </button>

          <button
            type="button"
            id="modal-toggle-complete-btn"
            onClick={() => onToggleComplete(day.dayNumber)}
            className={`w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-2.5 rounded-xl font-bold text-sm transition-all duration-200 shadow-lg cursor-pointer ${
              isCompleted
                ? 'bg-[#10232b] hover:bg-[#1a3845] text-[#C79A6A] border border-[#2D6F8B]'
                : 'bg-gradient-to-r from-[#2D6F8B] via-[#8FB7C7] to-[#C79A6A] hover:brightness-110 text-[#0f232b] shadow-[0_0_15px_rgba(143,183,199,0.35)]'
            }`}
          >
            <Check className={`w-4 h-4 stroke-[3] ${isCompleted ? 'text-[#C79A6A]' : 'text-[#0f232b]'}`} />
            <span>
              {isCompleted
                ? language === 'am'
                  ? 'ተነቧል ✓ (ለመሰረዝ ጠቅ አድርግ)'
                  : 'Completed ✓ (Click to Undo)'
                : language === 'am'
                ? 'አንብቤያለሁ (ምልክት አድርግ)'
                : 'Mark as Read & Tick'}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
