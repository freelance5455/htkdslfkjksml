import React from 'react';
import { EthiopianCrossIcon } from './EthiopianCrossIcon';
import { Flame, Compass, Sparkles, BookOpen, RotateCcw } from 'lucide-react';
import { PWAInstallButton } from './PWAInstallButton';

interface HeaderProgressProps {
  completedCount: number;
  totalDays: number;
  streak: number;
  language: 'am' | 'en';
  onToggleLanguage: () => void;
  onJumpToToday: () => void;
  onOpenMotivation: () => void;
  onResetProgress: () => void;
  onOpenBibleReader: () => void;
}

export const HeaderProgress: React.FC<HeaderProgressProps> = ({
  completedCount,
  totalDays,
  streak,
  language,
  onToggleLanguage,
  onJumpToToday,
  onOpenMotivation,
  onResetProgress,
  onOpenBibleReader,
}) => {
  const percentage = Math.round((completedCount / totalDays) * 100);

  return (
    <header className="relative w-full max-w-5xl mx-auto mb-8">
      {/* Top Utility Controls */}
      <div className="flex items-center justify-between px-2 mb-3 text-xs text-[#8FB7C7]">
        <div className="flex items-center gap-2">
          {streak > 0 ? (
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#16323D] border border-[#2D6F8B] text-[#C79A6A] font-medium shadow-sm">
              <Flame className="w-3.5 h-3.5 fill-[#C79A6A] text-[#C79A6A]" />
              <span>{streak} {language === 'am' ? 'ቀናት ተከታታይ ንባብ' : 'Days Streak'}</span>
            </span>
          ) : (
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#16323D]/80 border border-[#2D6F8B]/50 text-[#8FB7C7]">
              <Sparkles className="w-3.5 h-3.5 text-[#8FB7C7]" />
              <span>{language === 'am' ? '365 ቀናት መንፈሳዊ ጉዞ' : '365 Days Spiritual Journey'}</span>
            </span>
          )}
        </div>

        <div className="flex items-center gap-2">
          {/* APK / Mobile App Install Button */}
          <PWAInstallButton language={language} />

          {/* Bible Reader Trigger (2 Amharic Translations) */}
          <button
            onClick={onOpenBibleReader}
            id="open-bible-reader-btn"
            className="flex items-center gap-1.5 px-3 py-1 rounded-md bg-gradient-to-r from-amber-700 to-amber-800 hover:from-amber-600 hover:to-amber-700 text-amber-100 font-bold border border-amber-600/70 shadow-sm transition-all cursor-pointer"
            title={language === 'am' ? 'ሙሉውን አማርኛ መጽሐፍ ቅዱስ አንብብ (አዲሱ መደበኛ & 1954)' : 'Read Full Amharic Bible (NASV & 1954)'}
          >
            <BookOpen className="w-3.5 h-3.5 text-amber-200" />
            <span>{language === 'am' ? 'መጽሐፍ ቅዱስ (2 ትርጉሞች)' : 'Bible Reader'}</span>
          </button>

          {/* Daily Motivation Trigger */}
          <button
            onClick={onOpenMotivation}
            id="motivation-btn"
            className="flex items-center gap-1 px-2.5 py-1 rounded-md bg-[#16323D] hover:bg-[#1f4553] border border-[#2D6F8B]/60 hover:border-[#8FB7C7] text-[#F2E7D8] transition-all cursor-pointer"
            title={language === 'am' ? 'የዕለቱ ቃልና ማበረታቻ' : 'Daily Verse & Motivation'}
          >
            <BookOpen className="w-3.5 h-3.5 text-[#C79A6A]" />
            <span>{language === 'am' ? 'የዕለቱ ቃል' : 'Daily Verse'}</span>
          </button>

          {/* Jump to Today's Reading */}
          <button
            onClick={onJumpToToday}
            id="jump-today-btn"
            className="flex items-center gap-1 px-2.5 py-1 rounded-md bg-[#16323D] hover:bg-[#1f4553] border border-[#2D6F8B]/60 hover:border-[#8FB7C7] text-[#F2E7D8] transition-all cursor-pointer"
            title={language === 'am' ? 'የዛሬ ንባብ ላይ ዝለል' : 'Jump to Today\'s Reading'}
          >
            <Compass className="w-3.5 h-3.5 text-[#8FB7C7]" />
            <span>{language === 'am' ? 'የዛሬ ንባብ' : 'Today'}</span>
          </button>

          {/* Language Toggle */}
          <button
            onClick={onToggleLanguage}
            id="lang-toggle-btn"
            className="px-2.5 py-1 rounded-md bg-[#1f4553] hover:bg-[#2D6F8B] border border-[#2D6F8B] text-[#F2E7D8] font-medium transition-all cursor-pointer"
          >
            {language === 'am' ? 'EN' : 'አማ'}
          </button>

          {/* Reset option with safety */}
          {completedCount > 0 && (
            <button
              onClick={onResetProgress}
              id="reset-btn"
              className="p-1 rounded-md text-[#8FB7C7]/70 hover:text-[#e06d53] hover:bg-[#241318] transition-colors cursor-pointer"
              title={language === 'am' ? 'ሂደትን እንደገና ጀምር' : 'Reset Progress'}
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Main Classical Frame Matching Screenshot */}
      <div className="relative rounded-2xl bg-gradient-to-b from-[#16323D] to-[#10242c] border-2 border-[#2D6F8B] p-6 sm:p-8 shadow-2xl text-center overflow-hidden">
        {/* Subtle decorative inner framing outline */}
        <div className="absolute inset-1.5 rounded-xl border border-[#8FB7C7]/20 pointer-events-none" />

        {/* Top Center Ethiopian Cross Icon */}
        <div className="flex justify-center mb-4">
          <div className="relative p-2.5 rounded-full bg-[#0e2027]/70 border border-[#2D6F8B]/60 shadow-inner">
            <EthiopianCrossIcon size={46} className="text-[#C79A6A] drop-shadow-md" />
          </div>
        </div>

        {/* Main Title */}
        <h1
          id="main-app-title"
          className="text-2xl sm:text-4xl md:text-[2.6rem] font-bold text-[#C79A6A] tracking-wide mb-2 font-serif-header drop-shadow-[0_2px_4px_rgba(0,0,0,0.6)]"
        >
          {language === 'am' ? 'የመጽሐፍ ቅዱስ ንባብ እቅድ' : 'Bible Reading Plan'}
        </h1>

        {/* Subtitle */}
        <p className="text-sm sm:text-base text-[#8FB7C7] max-w-2xl mx-auto mb-7 leading-relaxed font-light">
          {language === 'am'
            ? 'መጽሐፍ ቅዱስን በአንድ ዓመት ውስጥ ለመጨረስ የተዘጋጀ የ365 ቀናት እቅድ'
            : 'A 365-day plan designed to read through the Holy Bible in one year'}
        </p>

        {/* Progress Recessed Box Matching Screenshot */}
        <div className="relative max-w-3xl mx-auto rounded-xl bg-[#0d1f26] border border-[#1f4553] p-4 sm:p-5 shadow-inner">
          <div className="flex items-center justify-between mb-3 text-sm sm:text-base font-medium">
            {/* Left Label */}
            <span className="text-[#8FB7C7] tracking-wider uppercase">
              {language === 'am' ? 'እድገት' : 'Progress'}
            </span>

            {/* Center Large Percentage */}
            <span className="text-xl sm:text-2xl font-bold text-[#F2E7D8] font-serif-header">
              {percentage}%
            </span>

            {/* Right Fraction */}
            <span className="text-[#8FB7C7]">
              {completedCount} / {totalDays} {language === 'am' ? 'ቀናት' : 'days'}
            </span>
          </div>

          {/* Deep Recessed Progress Bar */}
          <div className="w-full h-4 sm:h-5 bg-[#081318] rounded-full p-0.5 border border-[#16323D] overflow-hidden shadow-inner">
            <div
              className="h-full rounded-full transition-all duration-700 ease-out bg-gradient-to-r from-[#2D6F8B] via-[#8FB7C7] to-[#C79A6A] shadow-[0_0_12px_rgba(143,183,199,0.4)]"
              style={{ width: `${Math.min(100, Math.max(0, percentage))}%` }}
            />
          </div>
        </div>
      </div>
    </header>
  );
};
