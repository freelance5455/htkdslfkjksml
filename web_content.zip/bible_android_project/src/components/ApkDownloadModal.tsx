import React, { useState } from 'react';
import { EthiopianCrossIcon } from './EthiopianCrossIcon';
import { 
  X, 
  Smartphone, 
  Download, 
  CheckCircle2, 
  Copy, 
  ExternalLink, 
  Sparkles, 
  Wifi, 
  ShieldCheck, 
  Share2 
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  language: 'am' | 'en';
}

export const ApkDownloadModal: React.FC<Props> = ({ isOpen, onClose, language }) => {
  const { isInstallable, isInstalled, install, isIOS } = usePWAInstall();
  const [copied, setCopied] = useState(false);
  const [installing, setInstalling] = useState(false);

  if (!isOpen) return null;

  const currentUrl = typeof window !== 'undefined' ? window.location.origin : '';
  const pwaBuilderUrl = `https://www.pwabuilder.com/?site=${encodeURIComponent(currentUrl)}`;

  const handleCopyUrl = async () => {
    try {
      await navigator.clipboard.writeText(currentUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch (err) {
      console.error('Failed to copy', err);
    }
  };

  const handleTriggerInstall = async () => {
    setInstalling(true);
    try {
      await install();
    } finally {
      setInstalling(false);
    }
  };

  return (
    <div
      id="apk-download-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        id="apk-download-modal-content"
        className="relative max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-2xl border border-[#C79A6A]/30 bg-[#0f232b] p-6 text-[#F2E7D8] shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          id="close-apk-modal-btn"
          onClick={onClose}
          className="absolute right-4 top-4 rounded-lg p-1.5 text-[#8FB7C7] hover:bg-[#16323D] hover:text-[#F2E7D8] transition"
          aria-label="Close"
        >
          <X className="h-5 w-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 border-b border-[#16323D] pb-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl border border-[#C79A6A]/40 bg-[#16323D]/70 shadow-inner">
            <EthiopianCrossIcon size={34} />
          </div>
          <div>
            <h2 className="font-serif-header text-lg font-bold text-[#F2E7D8]">
              {language === 'am' ? 'የAndroid መተግበሪያ (APK) እና ጭነት' : 'Android App (APK) & Installation'}
            </h2>
            <p className="text-xs text-[#8FB7C7]">
              {language === 'am'
                ? 'በስልክዎ ላይ እንደ ራሱን የቻለ መተግበሪያ አድርገው ይጫኑ'
                : 'Install as a standalone native-grade app on your phone'}
            </p>
          </div>
        </div>

        {/* Status Badge */}
        {isInstalled && (
          <div className="mt-4 flex items-center gap-2 rounded-xl border border-emerald-500/30 bg-emerald-950/40 p-3 text-xs text-emerald-300">
            <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-400" />
            <span>
              {language === 'am'
                ? 'ይህ መተግበሪያ በዚህ መሳሪያ ላይ ተጭኗል!'
                : 'This application is already installed on this device!'}
            </span>
          </div>
        )}

        {/* Primary Action 1: Instant Direct Install to Phone */}
        <div className="mt-5 rounded-xl border border-[#C79A6A]/20 bg-[#16323D]/50 p-4">
          <div className="flex items-start gap-3">
            <div className="rounded-lg bg-[#C79A6A]/20 p-2 text-[#C79A6A]">
              <Smartphone className="h-5 w-5" />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-semibold text-[#F2E7D8]">
                  {language === 'am' ? 'አማራጭ 1፡ በቀጥታ ወደ ስልክ መጫን (ቀላሉ መንገድ)' : 'Option 1: Direct Install (Fastest)'}
                </h3>
                <span className="rounded bg-[#C79A6A]/20 px-1.5 py-0.5 text-[10px] font-medium text-[#C79A6A]">
                  {language === 'am' ? 'ይመከራል' : 'Recommended'}
                </span>
              </div>
              <p className="mt-1 text-xs leading-relaxed text-[#8FB7C7]">
                {language === 'am'
                  ? 'ምንም የፋይል ማውረድ ሳያስፈልግ በስልክዎ መነሻ ገጽ (Home Screen) ላይ እንደ መደበኛ መተግበሪያ ይጫናል። ያለ ኢንተርኔት (Offline) ይሰራል!'
                  : 'Install directly to your Android home screen with no file download required. Works 100% offline with zero storage bloat.'}
              </p>

              <div className="mt-3 flex flex-wrap gap-2">
                {isInstallable ? (
                  <button
                    id="trigger-direct-install-btn"
                    onClick={handleTriggerInstall}
                    disabled={installing}
                    className="flex items-center gap-2 rounded-lg bg-gradient-to-r from-[#C79A6A] to-[#b38555] px-4 py-2 text-xs font-semibold text-[#0f232b] shadow-md hover:brightness-110 transition active:scale-95"
                  >
                    <Download className="h-4 w-4" />
                    {installing
                      ? (language === 'am' ? 'እየተጫነ ነው...' : 'Installing...')
                      : (language === 'am' ? 'አሁን ስልክ ላይ ጫን (Install)' : 'Install to Device Now')}
                  </button>
                ) : (
                  <div className="rounded-lg border border-[#2D6F8B]/40 bg-[#0f232b]/80 p-2.5 text-xs text-[#8FB7C7]">
                    <div className="flex items-center gap-1.5 font-medium text-[#F2E7D8]">
                      <span>📱 {language === 'am' ? 'ከChrome ለመጫን፡' : 'To install via Chrome on Android:'}</span>
                    </div>
                    <ol className="mt-1.5 list-decimal list-inside space-y-1 text-[11px] text-[#F2E7D8]/80">
                      <li>{language === 'am' ? 'በስልክዎ Chrome ላይ የላይኛውን 3 ነጥቦች (⋮) ይንኩ' : 'Tap Chrome menu (⋮) in the top right'}</li>
                      <li>{language === 'am' ? '"መተግበሪያ ጫን" ወይም "Add to Home screen" የሚለውን ይምረጡ' : 'Select "Install app" or "Add to Home screen"'}</li>
                      <li>{language === 'am' ? '"ጫን" (Install) ሲሉት ወዲያውኑ በስልክዎ ይገባል' : 'Confirm "Install" — the app icon appears on your phone!'}</li>
                    </ol>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Primary Action 2: Generate Signed APK File via PWABuilder */}
        <div className="mt-4 rounded-xl border border-[#2D6F8B]/30 bg-[#16323D]/30 p-4">
          <div className="flex items-start gap-3">
            <div className="rounded-lg bg-[#2D6F8B]/20 p-2 text-[#8FB7C7]">
              <Download className="h-5 w-5" />
            </div>
            <div className="flex-1">
              <h3 className="text-sm font-semibold text-[#F2E7D8]">
                {language === 'am' ? 'አማራጭ 2፡ ነፃ የAPK ፋይል ማመንጨት (PWABuilder)' : 'Option 2: Generate Standalone .APK File'}
              </h3>
              <p className="mt-1 text-xs leading-relaxed text-[#8FB7C7]">
                {language === 'am'
                  ? 'ራሱን የቻለ የተፈረመ የ.apk ፋይል ማውረድ ከፈለጉ፣ ክፍት ምንጭ የሆነው PWABuilder ይህን ድረ-ገጽ በቀጥታ ወደ APK ይቀይርልዎታል።'
                  : 'To download a physical signed .apk or Google Play .aab installer file, open PWABuilder with this app:'}
              </p>

              <div className="mt-3 flex flex-wrap items-center gap-2">
                <a
                  id="open-pwabuilder-apk-link"
                  href={pwaBuilderUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 rounded-lg border border-[#C79A6A]/60 bg-[#16323D] px-3.5 py-2 text-xs font-medium text-[#C79A6A] hover:bg-[#C79A6A] hover:text-[#0f232b] transition"
                >
                  <span>{language === 'am' ? 'APK ፍጠር (Generate APK)' : 'Package as APK on PWABuilder'}</span>
                  <ExternalLink className="h-3.5 w-3.5" />
                </a>

                <button
                  id="copy-app-url-btn"
                  onClick={handleCopyUrl}
                  className="flex items-center gap-1.5 rounded-lg border border-[#2D6F8B]/40 bg-[#0f232b] px-3 py-2 text-xs text-[#8FB7C7] hover:text-[#F2E7D8] transition"
                >
                  <Copy className="h-3.5 w-3.5" />
                  <span>{copied ? (language === 'am' ? 'ተቀድቷል!' : 'Copied!') : (language === 'am' ? 'የመተግበሪያ ሊንክ ቅዳ' : 'Copy App Link')}</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Feature Highlights of the Android App */}
        <div className="mt-5 grid grid-cols-2 gap-2.5 text-xs">
          <div className="flex items-center gap-2 rounded-lg border border-[#16323D] bg-[#0f232b]/60 p-2.5 text-[#8FB7C7]">
            <Wifi className="h-4 w-4 text-[#C79A6A] shrink-0" />
            <span>{language === 'am' ? 'ሙሉ ከመስመር ውጭ (Offline) ይሰራል' : 'Full Offline support'}</span>
          </div>
          <div className="flex items-center gap-2 rounded-lg border border-[#16323D] bg-[#0f232b]/60 p-2.5 text-[#8FB7C7]">
            <ShieldCheck className="h-4 w-4 text-[#C79A6A] shrink-0" />
            <span>{language === 'am' ? 'ፈጣን እና ደህንነቱ የተጠበቀ' : 'Lightweight & secure'}</span>
          </div>
          <div className="flex items-center gap-2 rounded-lg border border-[#16323D] bg-[#0f232b]/60 p-2.5 text-[#8FB7C7]">
            <Sparkles className="h-4 w-4 text-[#C79A6A] shrink-0" />
            <span>{language === 'am' ? '365 ቀናት ሙሉ ንባብ' : '365 Days complete plan'}</span>
          </div>
          <div className="flex items-center gap-2 rounded-lg border border-[#16323D] bg-[#0f232b]/60 p-2.5 text-[#8FB7C7]">
            <Share2 className="h-4 w-4 text-[#C79A6A] shrink-0" />
            <span>{language === 'am' ? 'እድገትን በስልክ ያስቀምጣል' : 'Local progress sync'}</span>
          </div>
        </div>

        {/* Footer info */}
        <div className="mt-5 border-t border-[#16323D] pt-4 text-center">
          <button
            id="close-apk-modal-bottom-btn"
            onClick={onClose}
            className="w-full rounded-xl border border-[#C79A6A]/30 bg-[#16323D]/60 py-2.5 text-xs font-semibold text-[#F2E7D8] hover:bg-[#16323D] transition"
          >
            {language === 'am' ? 'ተመለስ' : 'Done / Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
