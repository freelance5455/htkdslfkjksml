import React from 'react';

interface Props {
  className?: string;
  size?: number;
}

export const EthiopianCrossIcon: React.FC<Props> = ({ className = 'text-[#C79A6A]', size = 44 }) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 120"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-label="Ethiopian Cross"
    >
      {/* Intricate Lalibela / Gondar style Ethiopian Cross */}
      <defs>
        <linearGradient id="ethCrossGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#F2E7D8" />
          <stop offset="45%" stopColor="#C79A6A" />
          <stop offset="100%" stopColor="#2D6F8B" />
        </linearGradient>
        <filter id="goldGlow" x="-20%" y="-20%" width="140%" height="140%">
          <feGaussianBlur stdDeviation="2.5" result="blur" />
          <feComposite in="SourceGraphic" in2="blur" operator="over" />
        </filter>
      </defs>

      <g filter="url(#goldGlow)">
        {/* Central Vertical Beam */}
        <rect x="46" y="10" width="8" height="100" rx="2" fill="url(#ethCrossGrad)" />
        {/* Central Horizontal Beam */}
        <rect x="20" y="36" width="60" height="8" rx="2" fill="url(#ethCrossGrad)" />

        {/* Top Finial / Crown */}
        <path
          d="M 50 4 L 56 12 L 44 12 Z"
          fill="url(#ethCrossGrad)"
        />
        <circle cx="50" cy="14" r="3" fill="#16323D" stroke="url(#ethCrossGrad)" strokeWidth="1.5" />

        {/* Left Arm Finials */}
        <circle cx="18" cy="40" r="5" fill="#16323D" stroke="url(#ethCrossGrad)" strokeWidth="2" />
        <path d="M 12 37 L 12 43 L 6 40 Z" fill="url(#ethCrossGrad)" />

        {/* Right Arm Finials */}
        <circle cx="82" cy="40" r="5" fill="#16323D" stroke="url(#ethCrossGrad)" strokeWidth="2" />
        <path d="M 88 37 L 88 43 L 94 40 Z" fill="url(#ethCrossGrad)" />

        {/* Diagonal Cross-Bars / Lattice Braces */}
        <path
          d="M 30 20 L 70 60 M 70 20 L 30 60"
          stroke="url(#ethCrossGrad)"
          strokeWidth="3.5"
          strokeLinecap="round"
        />

        {/* Decorative Inner Ring / Trellis */}
        <circle
          cx="50"
          cy="40"
          r="16"
          stroke="url(#ethCrossGrad)"
          strokeWidth="2.5"
          fill="none"
        />
        <circle cx="50" cy="40" r="4" fill="url(#ethCrossGrad)" />

        {/* Lower Processional Wings */}
        <path
          d="M 36 68 Q 30 82 46 86 M 64 68 Q 70 82 54 86"
          stroke="url(#ethCrossGrad)"
          strokeWidth="3"
          fill="none"
          strokeLinecap="round"
        />

        {/* Base Pedestal Handle */}
        <path
          d="M 42 98 L 58 98 L 54 114 L 46 114 Z"
          fill="url(#ethCrossGrad)"
        />
        <line x1="40" y1="114" x2="60" y2="114" stroke="url(#ethCrossGrad)" strokeWidth="2.5" strokeLinecap="round" />
      </g>
    </svg>
  );
};
