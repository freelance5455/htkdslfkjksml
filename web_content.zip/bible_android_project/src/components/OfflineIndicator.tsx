import React from 'react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';
import { WifiOff } from 'lucide-react';

interface Props {
  language?: 'am' | 'en';
}

export const OfflineIndicator: React.FC<Props> = ({ language = 'am' }) => {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <aside
      aria-label="Offline status"
      className="fixed bottom-20 left-4 z-40 flex items-center gap-2.5 rounded-xl border border-[#C79A6A]/30 bg-[#16323D]/95 px-3.5 py-2 text-xs font-medium text-[#F2E7D8] shadow-lg backdrop-blur-md"
    >
      <WifiOff className="h-4 w-4 text-[#C79A6A] animate-pulse" />
      <span>
        {language === 'am'
          ? 'ከመስመር ውጭ (Offline) — የተጫነው እቅድ እና ንባብ ይሰራል።'
          : 'Offline Mode — Cached reading plan & notes are fully active.'}
      </span>
    </aside>
  );
};
