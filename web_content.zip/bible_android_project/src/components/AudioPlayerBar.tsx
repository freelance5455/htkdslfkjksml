import React, { useState, useEffect, useRef } from 'react';
import { soundEngine } from '../utils/soundEffects';
import { Volume2, VolumeX, Play, Pause, Music, ChevronDown, ExternalLink, Tv, X, Radio } from 'lucide-react';

declare global {
  interface Window {
    YT: any;
    onYouTubeIframeAPIReady: (() => void) | undefined;
  }
}

interface AudioPlayerBarProps {
  language: 'am' | 'en';
}

export const YOUTUBE_BACKGROUND_URL = 'https://www.youtube.com/watch?v=qCZAynQU_-8&list=RDqCZAynQU_-8&start_radio=1';
export const YOUTUBE_VIDEO_ID = 'qCZAynQU_-8';
export const YOUTUBE_LIST_ID = 'RDqCZAynQU_-8';

interface TrackItem {
  id: string;
  name: string;
  nameEn: string;
  isYoutube?: boolean;
  badge?: string;
}

const TRACKS: TrackItem[] = [
  {
    id: 'youtube',
    name: 'የጸሎትና አምልኮ ዜማ (YouTube Music)',
    nameEn: 'Prayer & Worship Music (YouTube Radio)',
    isYoutube: true,
    badge: 'YouTube',
  },
  { id: 'begena', name: 'ሰላማዊ በገና (የዳዊት በገና)', nameEn: "Peaceful Begena (David's Harp)" },
  { id: 'ambient', name: 'የማለዳ ጸሎት (Sanctuary Chords)', nameEn: 'Morning Prayer & Chords' },
  { id: 'chimes', name: 'የሰላም ቃጭል (Monastery Chimes)', nameEn: 'Peaceful Monastery Chimes' },
  { id: 'rain', name: 'የጸጥታ ዝናብ (Gentle Raindrops)', nameEn: 'Gentle Raindrops & Calm' },
];

export const AudioPlayerBar: React.FC<AudioPlayerBarProps> = ({ language }) => {
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTrackId, setCurrentTrackId] = useState<string>('youtube');
  const [volume, setVolume] = useState<number>(0.7);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isMenuOpen, setIsMenuOpen] = useState<boolean>(false);
  const [showVideo, setShowVideo] = useState<boolean>(false);
  const [isPlayerReady, setIsPlayerReady] = useState<boolean>(false);

  const ytPlayerRef = useRef<any>(null);
  const pendingPlayRef = useRef<boolean>(false);

  // Initialize YouTube Iframe Player
  useEffect(() => {
    let isMounted = true;

    const createPlayer = () => {
      if (!window.YT || !window.YT.Player) return;
      if (ytPlayerRef.current) return;

      const mountEl = document.getElementById('youtube-player-mount');
      if (!mountEl) return;

      try {
        ytPlayerRef.current = new window.YT.Player('youtube-player-mount', {
          videoId: YOUTUBE_VIDEO_ID,
          playerVars: {
            list: YOUTUBE_LIST_ID,
            listType: 'playlist',
            autoplay: 0,
            controls: 1,
            playsinline: 1,
            rel: 0,
            modestbranding: 1,
            loop: 1,
            playlist: YOUTUBE_VIDEO_ID,
          },
          events: {
            onReady: (event: any) => {
              if (!isMounted) return;
              setIsPlayerReady(true);
              try {
                event.target.setVolume(Math.round(volume * 100));
                if (isMuted) {
                  event.target.mute();
                }
              } catch (e) {
                // ignore
              }

              if (pendingPlayRef.current) {
                pendingPlayRef.current = false;
                try {
                  event.target.playVideo();
                } catch (e) {
                  console.warn('Auto-play attempt blocked or failed', e);
                }
              }
            },
            onStateChange: (event: any) => {
              if (!isMounted) return;
              // YT.PlayerState: 1 is PLAYING, 2 is PAUSED, 0 is ENDED
              if (event.data === 1) {
                setIsPlaying(true);
              } else if (event.data === 2) {
                setIsPlaying(false);
              } else if (event.data === 0) {
                // If loop finished, restart playlist/video
                try {
                  event.target.playVideo();
                } catch (e) {
                  setIsPlaying(false);
                }
              }
            },
            onError: (err: any) => {
              console.warn('YouTube Player error:', err);
            },
          },
        });
      } catch (err) {
        console.warn('Error mounting YouTube Player:', err);
      }
    };

    if (!window.YT) {
      const existingScript = document.getElementById('youtube-iframe-api');
      if (!existingScript) {
        const tag = document.createElement('script');
        tag.id = 'youtube-iframe-api';
        tag.src = 'https://www.youtube.com/iframe_api';
        const firstScriptTag = document.getElementsByTagName('script')[0];
        firstScriptTag?.parentNode?.insertBefore(tag, firstScriptTag);
      }

      const prevReady = window.onYouTubeIframeAPIReady;
      window.onYouTubeIframeAPIReady = () => {
        if (prevReady) prevReady();
        createPlayer();
      };
    } else {
      createPlayer();
    }

    return () => {
      isMounted = false;
    };
  }, []);

  // Handle Play/Pause
  const handleTogglePlay = () => {
    if (currentTrackId === 'youtube') {
      soundEngine.stopMusic();
      if (isPlaying) {
        if (ytPlayerRef.current && typeof ytPlayerRef.current.pauseVideo === 'function') {
          ytPlayerRef.current.pauseVideo();
        }
        setIsPlaying(false);
      } else {
        if (ytPlayerRef.current && typeof ytPlayerRef.current.playVideo === 'function') {
          ytPlayerRef.current.playVideo();
          setIsPlaying(true);
        } else {
          pendingPlayRef.current = true;
          setIsPlaying(true);
        }
      }
    } else {
      // Internal synthesizer track
      if (ytPlayerRef.current && typeof ytPlayerRef.current.pauseVideo === 'function') {
        ytPlayerRef.current.pauseVideo();
      }
      const newState = soundEngine.toggleMusic(currentTrackId);
      setIsPlaying(newState);
    }
  };

  // Switch Track
  const handleSelectTrack = (trackId: string) => {
    setCurrentTrackId(trackId);
    setIsMenuOpen(false);

    if (trackId === 'youtube') {
      soundEngine.stopMusic();
      if (isPlaying) {
        if (ytPlayerRef.current && typeof ytPlayerRef.current.playVideo === 'function') {
          ytPlayerRef.current.playVideo();
        }
      }
    } else {
      if (ytPlayerRef.current && typeof ytPlayerRef.current.pauseVideo === 'function') {
        ytPlayerRef.current.pauseVideo();
      }
      if (isPlaying) {
        soundEngine.startMusic(trackId);
      }
    }
  };

  // Volume Slider
  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setVolume(val);
    soundEngine.setVolume(val);

    if (ytPlayerRef.current && typeof ytPlayerRef.current.setVolume === 'function') {
      ytPlayerRef.current.setVolume(Math.round(val * 100));
      if (isMuted && val > 0) {
        ytPlayerRef.current.unMute();
      }
    }

    if (isMuted && val > 0) {
      setIsMuted(false);
    }
  };

  // Mute / Unmute
  const handleToggleMute = () => {
    const nextMuted = !isMuted;
    setIsMuted(nextMuted);
    soundEngine.toggleMute();

    if (ytPlayerRef.current) {
      if (nextMuted) {
        if (typeof ytPlayerRef.current.mute === 'function') {
          ytPlayerRef.current.mute();
        }
      } else {
        if (typeof ytPlayerRef.current.unMute === 'function') {
          ytPlayerRef.current.unMute();
          ytPlayerRef.current.setVolume(Math.round(volume * 100));
        }
      }
    }
  };

  const currentTrack = TRACKS.find((t) => t.id === currentTrackId) || TRACKS[0];

  return (
    <>
      {/* Persistent YouTube Player Mount:
          Kept mounted in DOM to prevent iframe reloading and maintain continuous background audio.
          When showVideo is true, appears as a floating mini-player popup above the bar.
          When showVideo is false, remains mounted discreetly off-screen while streaming audio. */}
      <div
        id="youtube-player-container"
        className={
          showVideo
            ? 'fixed bottom-20 right-4 z-50 w-72 sm:w-84 rounded-2xl bg-[#10232b]/95 border border-[#2D6F8B] shadow-2xl p-2.5 backdrop-blur-md transition-all duration-200 animate-in fade-in slide-in-from-bottom-2'
            : 'fixed -bottom-96 -right-96 w-4 h-4 opacity-0 pointer-events-none -z-50 overflow-hidden'
        }
      >
        {showVideo && (
          <div className="flex items-center justify-between pb-2 mb-2 border-b border-[#2D6F8B]/40 text-[#F2E7D8]">
            <div className="flex items-center gap-1.5 text-xs font-semibold">
              <Radio className="w-3.5 h-3.5 text-[#C79A6A] animate-pulse" />
              <span className="truncate max-w-[180px]">
                {language === 'am' ? 'የጸሎትና አምልኮ ዜማ (YouTube)' : 'Prayer & Worship Music (YouTube)'}
              </span>
            </div>
            <div className="flex items-center gap-1">
              <a
                href={YOUTUBE_BACKGROUND_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="p-1 rounded-md hover:bg-[#16323D] text-[#8FB7C7] hover:text-[#F2E7D8] transition-colors"
                title={language === 'am' ? 'በዩቲዩብ ክፈት' : 'Open in YouTube'}
              >
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
              <button
                type="button"
                onClick={() => setShowVideo(false)}
                className="p-1 rounded-md hover:bg-[#16323D] text-[#8FB7C7] hover:text-[#F2E7D8] transition-colors cursor-pointer"
                title={language === 'am' ? 'ቪዲዮ ደብቅ' : 'Minimize Video'}
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {/* 16:9 Video Container */}
        <div className={`relative rounded-xl overflow-hidden bg-black ${showVideo ? 'w-full aspect-video shadow-inner' : 'w-1 h-1'}`}>
          <div id="youtube-player-mount" className="w-full h-full" />
        </div>

        {showVideo && (
          <div className="mt-2 text-[11px] text-[#8FB7C7] flex items-center justify-between px-1">
            <span>{language === 'am' ? 'የጀርባ ሙዚቃ ሆኖ ይቀጥላል' : 'Keeps playing in background'}</span>
            <span className="text-[10px] bg-[#C79A6A]/20 text-[#C79A6A] px-1.5 py-0.5 rounded font-mono">
              qCZAynQU_-8
            </span>
          </div>
        )}
      </div>

      {/* Floating Audio Controller Bar */}
      <div className="fixed bottom-4 right-4 z-40 max-w-sm sm:max-w-md">
        <div className="relative flex items-center gap-2 sm:gap-3 px-3.5 py-2.5 rounded-2xl bg-[#16323D]/95 border border-[#2D6F8B] text-[#F2E7D8] shadow-2xl backdrop-blur-md">
          {/* Play/Pause Button */}
          <button
            type="button"
            id="music-play-pause-btn"
            onClick={handleTogglePlay}
            className={`w-10 h-10 rounded-full flex items-center justify-center transition-all duration-200 cursor-pointer shadow-md shrink-0 ${
              isPlaying
                ? 'bg-[#C79A6A] text-[#16323D] ring-2 ring-[#F2E7D8] shadow-[0_0_12px_rgba(199,154,106,0.5)]'
                : 'bg-[#10232b] hover:bg-[#1f4553] text-[#F2E7D8] border border-[#2D6F8B]'
            }`}
            title={
              isPlaying
                ? language === 'am'
                  ? 'ሙዚቃውን አቁም'
                  : 'Pause Background Music'
                : language === 'am'
                ? 'የጸሎትና አምልኮ ሙዚቃ አጫውት'
                : 'Play Background Music'
            }
          >
            {isPlaying ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current ml-0.5" />}
          </button>

          {/* Track Title and Controls */}
          <div className="relative flex-1 min-w-[130px]">
            <button
              type="button"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="flex items-center justify-between w-full text-left group cursor-pointer"
            >
              <div>
                <div className="flex items-center gap-1.5 text-[10px] uppercase font-bold text-[#8FB7C7] tracking-wider">
                  <Music className="w-3 h-3 text-[#C79A6A]" />
                  <span>{language === 'am' ? 'የጀርባ ጸሎት ሙዚቃ' : 'Background Music'}</span>
                  {currentTrack.badge && (
                    <span className="bg-[#8c2d19]/80 text-[#F2E7D8] text-[9px] px-1.5 py-0.2 rounded font-mono font-normal">
                      {currentTrack.badge}
                    </span>
                  )}
                </div>
                <p className="text-xs font-semibold text-[#F2E7D8] truncate group-hover:text-[#C79A6A] max-w-[170px] sm:max-w-[210px]">
                  {language === 'am' ? currentTrack.name : currentTrack.nameEn}
                </p>
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-[#8FB7C7] group-hover:text-[#F2E7D8] transition-transform ml-1 shrink-0" />
            </button>

            {/* Animated Equalizer Wave Bars when playing */}
            {isPlaying && (
              <div className="flex items-end gap-0.5 h-2 mt-1">
                <span className="w-0.5 bg-[#C79A6A] animate-[pulse_0.8s_ease-in-out_infinite] h-2" />
                <span className="w-0.5 bg-[#8FB7C7] animate-[pulse_1.2s_ease-in-out_infinite_0.2s] h-3.5" />
                <span className="w-0.5 bg-[#2D6F8B] animate-[pulse_0.9s_ease-in-out_infinite_0.4s] h-1.5" />
                <span className="w-0.5 bg-[#C79A6A] animate-[pulse_1.1s_ease-in-out_infinite_0.1s] h-3" />
              </div>
            )}

            {/* Track Selection Dropdown Menu */}
            {isMenuOpen && (
              <div className="absolute bottom-full left-0 mb-3 w-68 rounded-xl bg-[#10232b] border border-[#2D6F8B] p-1.5 shadow-2xl z-50 animate-in fade-in slide-in-from-bottom-2">
                <div className="text-[11px] font-semibold text-[#8FB7C7] px-2.5 py-1 mb-1 border-b border-[#2D6F8B]/40 flex items-center justify-between">
                  <span>{language === 'am' ? 'የጀርባ ዜማ ይምረጡ' : 'Select Background Music'}</span>
                  <a
                    href={YOUTUBE_BACKGROUND_URL}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[10px] text-[#C79A6A] hover:underline flex items-center gap-0.5"
                  >
                    <span>YouTube</span>
                    <ExternalLink className="w-2.5 h-2.5" />
                  </a>
                </div>
                {TRACKS.map((t) => (
                  <button
                    key={t.id}
                    onClick={() => handleSelectTrack(t.id)}
                    className={`w-full text-left px-2.5 py-2 rounded-lg text-xs transition-colors flex items-center justify-between cursor-pointer mb-0.5 ${
                      currentTrackId === t.id
                        ? 'bg-[#2D6F8B] text-[#F2E7D8] font-bold'
                        : 'text-[#8FB7C7] hover:bg-[#1a3845] hover:text-[#F2E7D8]'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 truncate">
                      {t.isYoutube && <Radio className="w-3 h-3 text-[#C79A6A] shrink-0" />}
                      <span className="truncate">{language === 'am' ? t.name : t.nameEn}</span>
                    </div>
                    {currentTrackId === t.id && <span className="w-1.5 h-1.5 rounded-full bg-[#C79A6A] shrink-0 ml-1" />}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Mini-Player Video View Toggle (for YouTube track) */}
          {currentTrackId === 'youtube' && (
            <button
              type="button"
              onClick={() => setShowVideo(!showVideo)}
              className={`p-2 rounded-xl transition-all duration-150 cursor-pointer ${
                showVideo
                  ? 'bg-[#C79A6A] text-[#16323D]'
                  : 'bg-[#10232b] text-[#8FB7C7] hover:text-[#F2E7D8] hover:bg-[#1a3845] border border-[#2D6F8B]/40'
              }`}
              title={
                showVideo
                  ? language === 'am'
                    ? 'ቪዲዮውን ደብቅ'
                    : 'Hide Video'
                  : language === 'am'
                  ? 'የዩቲዩብ ቪዲዮውን አሳይ'
                  : 'Show YouTube Video'
              }
            >
              <Tv className="w-3.5 h-3.5" />
            </button>
          )}

          {/* External YouTube Link Button */}
          {currentTrackId === 'youtube' && (
            <a
              href={YOUTUBE_BACKGROUND_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 rounded-xl bg-[#10232b] text-[#8FB7C7] hover:text-[#C79A6A] hover:bg-[#1a3845] border border-[#2D6F8B]/40 transition-colors"
              title={language === 'am' ? 'በዩቲዩብ ይክፈቱ' : 'Open link on YouTube'}
            >
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          )}

          {/* Volume Controls */}
          <div className="hidden sm:flex items-center gap-1.5 pl-2 border-l border-[#2D6F8B]/40">
            <button
              type="button"
              onClick={handleToggleMute}
              className="p-1 text-[#8FB7C7] hover:text-[#F2E7D8] transition-colors cursor-pointer"
              title={isMuted ? 'Unmute' : 'Mute'}
            >
              {isMuted || volume === 0 ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={isMuted ? 0 : volume}
              onChange={handleVolumeChange}
              aria-label="Volume slider"
              className="w-14 sm:w-16 h-1 bg-[#10232b] accent-[#C79A6A] rounded-lg cursor-pointer"
            />
          </div>
        </div>
      </div>
    </>
  );
};
