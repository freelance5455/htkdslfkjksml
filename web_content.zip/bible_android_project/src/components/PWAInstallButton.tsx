import React, { useState } from 'react';
import { Smartphone, Download } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { ApkDownloadModal } from './ApkDownloadModal';

interface Props {
  language: 'am' | 'en';
}

export const PWAInstallButton: React.FC<Props> = ({ language }) => {
  const { isInstallable, isInstalled } = usePWAInstall();
  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <>
      <button
        id="apk-install-header-btn"
        onClick={() => setIsModalOpen(true)}
        className="flex items-center gap-1.5 rounded-xl border border-[#C79A6A]/40 bg-gradient-to-r from-[#16323D] to-[#1c3d4a] px-3 py-1.5 text-xs font-medium text-[#C79A6A] shadow-sm hover:border-[#C79A6A] hover:text-[#F2E7D8] transition active:scale-95"
        title={language === 'am' ? 'የAndroid መተግበሪያ እና APK ፋይል' : 'Android App & APK installer'}
      >
        <Smartphone className="h-3.5 w-3.5 text-[#C79A6A]" />
        <span className="font-semibold">
          {language === 'am' ? 'APK / መተግበሪያ ጫን' : 'APK / Install App'}
        </span>
        {isInstallable && (
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#C79A6A] opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-[#C79A6A]"></span>
          </span>
        )}
      </button>

      <ApkDownloadModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        language={language}
      />
    </>
  );
};
