export interface KeyVerse {
  reference: string;
  referenceEnglish: string;
  text: string;
  textEnglish: string;
}

export interface ReadingDay {
  dayNumber: number; // 1 - 365
  monthIndex: number; // 0 - 12
  monthDay: number; // 1 - 30 (or 1 - 5 for Pagume)
  book: string;
  bookEnglish: string;
  passage: string; // e.g. "ዘፍጥረት 1-3"
  passageEnglish: string; // e.g. "Genesis 1-3"
  testament: 'ብሉይ ኪዳን' | 'ሐዲስ ኪዳን';
  theme: string;
  themeEnglish: string;
  keyVerse: KeyVerse;
  reflection: string;
  reflectionEnglish: string;
  prayer: string;
  prayerEnglish: string;
}

export interface MonthInfo {
  index: number;
  name: string;
  nameEnglish: string;
  daysCount: number;
  startDay: number;
  endDay: number;
  theme: string;
}

export interface AudioTrack {
  id: string;
  title: string;
  titleEnglish: string;
  description: string;
  type: 'begena' | 'ambient' | 'chimes' | 'rain';
}
