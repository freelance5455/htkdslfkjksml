# በየዕለቱ ከቃሉ ጋር — Android / Capacitor build

This project is the existing Google AI Studio React/Vite application packaged for Android with Capacitor. The existing UI, colors, typography, reading-plan logic, local progress/notes, Bible reader, audio controls, motivation features, PWA support, and bundled Amharic data are retained.

## 1. Architecture audit

- UI: React 19 + TypeScript
- Build: Vite 6
- Styling: Tailwind CSS 4 via `@tailwindcss/vite` plus existing custom CSS
- Icons: lucide-react
- Animation: motion
- Local persistence: browser `localStorage`
- Offline/PWA: `vite-plugin-pwa`
- Audio: Web Audio/synthesized tracks plus YouTube IFrame player
- Existing server: Express + Vite middleware
- AI: `@google/genai` on the Express server
- Existing bundled Bible data: `src/data/amharicBibleData.ts`
- Reading plan: `src/data/biblePlanData.ts`

### Important architecture change for Android

A Capacitor Android WebView cannot run the Node/Express `server.ts` process inside the APK. Therefore the Android app uses the existing web UI as its frontend and calls a deployed HTTPS API for `/api/bible/chapter`.

The Gemini API key remains server-side in `GEMINI_API_KEY`. It is NOT exposed to the Android client.

Set:

```text
VITE_API_BASE_URL=https://YOUR-API-DOMAIN.example.com
```

The API server must expose:

```text
GET /api/health
GET /api/bible/chapter?book=...&chapter=...&version=...
```

## 2. Install prerequisites

Install:

- Node.js 20+ (Node 22 recommended)
- Android Studio
- Android SDK / platform tools
- JDK 21 if required by the selected Capacitor/Android Gradle configuration
- A physical Android device or emulator

Then:

```bash
npm install
```

## 3. Configure the AI/API server

On the server, configure:

```text
GEMINI_API_KEY=YOUR_REAL_KEY
```

Do NOT configure it as:

```text
VITE_GEMINI_API_KEY=...
```

and do not hard-code it in React/TypeScript.

Deploy the Express server (`server.ts`) to a public HTTPS endpoint, then set:

```text
VITE_API_BASE_URL=https://your-api.example.com
```

before building the Android app.

If the app is used without that API, bundled/local chapters and cached chapters continue to work, while chapters requiring the server return the existing fallback state.

## 4. Add Android

The uploaded source did not contain a generated Capacitor `android/` directory. Generate it once from the project root:

```bash
npm install
npx cap add android
```

Then:

```bash
npm run build
npx cap sync android
```

After the first generation, `android/` is the complete native Android project managed by Capacitor.

## 5. Open in Android Studio

```bash
npx cap open android
```

Or open the `android/` directory directly in Android Studio.

## 6. Run on an Android phone

Enable Developer Options and USB debugging on the phone, connect it, verify:

```bash
adb devices
```

Then:

```bash
npm run android:run
```

Alternatively, select the connected device in Android Studio and press Run.

## 7. Debug APK

```bash
npm run android:debug
```

Output:

```text
android/app/build/outputs/apk/debug/app-debug.apk
```

Install manually:

```bash
adb install -r android/app/build/outputs/apk/debug/app-debug.apk
```

## 8. Release APK

For a release build:

```bash
npm run android:release
```

This creates an unsigned release APK unless signing is configured in `android/app/build.gradle`.

For distribution, configure an Android keystore and Gradle signing configuration in Android Studio/Gradle, then rebuild.

## 9. Signed release APK

Generate a keystore, for example:

```bash
keytool -genkeypair -v   -keystore bible365-release.keystore   -alias bible365   -keyalg RSA   -keysize 2048   -validity 10000
```

Store the keystore securely. Do NOT commit it to Git.

Then configure the `release` signing block in:

```text
android/app/build.gradle
```

using environment variables or a private `keystore.properties` file.

Build:

```bash
cd android
./gradlew assembleRelease
```

Windows:

```powershell
cd android
gradlew.bat assembleRelease
```

The signed APK will be under:

```text
android/app/build/outputs/apk/release/
```

## 10. Android App Bundle (Google Play)

```bash
npm run android:aab
```

Windows/macOS/Linux Gradle equivalent:

```bash
cd android
./gradlew bundleRelease
```

Windows:

```powershell
cd android
gradlew.bat bundleRelease
```

Output:

```text
android/app/build/outputs/bundle/release/app-release.aab
```

The AAB must be signed with the release key for Play distribution.

## 11. Normal development cycle

After changing React/TypeScript/CSS:

```bash
npm run build
npx cap sync android
npx cap open android
```

For a device:

```bash
npm run android:run
```

## 12. What was adapted for Android

The conversion adds:

- Capacitor Android packaging
- Android application ID: `com.bible365.amharic`
- Native app name: `በየዕለቱ ከቃሉ ጋር`
- Native status-bar configuration
- Native splash-screen configuration
- Android keyboard resize handling
- Android safe-area CSS
- Android back-button integration
- HTTPS API base URL support
- Preservation of existing localStorage persistence
- Existing PWA configuration remains available for the web version

The application is still a React/Vite UI inside a Capacitor WebView; Capacitor provides the Android application shell rather than replacing the existing UI.

## 13. Verification checklist

Before distribution, verify:

1. 365-day plan loads.
2. Ethiopian month selector works.
3. Day completion/ticks persist after restart.
4. Streak calculation persists.
5. Notes persist after restart.
6. Amharic/English language switch persists.
7. Passage modal opens and navigation works.
8. Bible reader opens.
9. Bundled Bible chapters work offline.
10. Cached chapters work offline.
11. API-backed chapters work online.
12. API errors display fallback behavior.
13. Motivation banner works.
14. Confetti/completion effects work.
15. Sound effects work.
16. Ambient audio tracks work.
17. YouTube audio/player behavior works on Android with network access.
18. Offline indicator works.
19. Forms are not hidden by the Android keyboard.
20. Tables/content can scroll horizontally where required.
21. Modal content scrolls correctly.
22. Android back button closes/navigates through the UI without unexpected exits.
23. App survives rotation/activity recreation as applicable.
24. App launches without network access.
25. Release build contains no Gemini secret.
26. API requests use HTTPS.
27. App installs and launches on a physical Android device.
28. Tablet layout is usable.
