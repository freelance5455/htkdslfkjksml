import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Lazy initialize Gemini client
  let aiClient: GoogleGenAI | null = null;
  function getGeminiClient(): GoogleGenAI {
    if (!aiClient) {
      aiClient = new GoogleGenAI({
        apiKey: process.env.GEMINI_API_KEY,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });
    }
    return aiClient;
  }

  // In-memory cache for fast verse retrieval
  const chapterCache = new Map<string, any>();

  // API Health
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', time: new Date().toISOString() });
  });

  // API: Fetch Amharic Bible Chapter
  app.get('/api/bible/chapter', async (req, res) => {
    try {
      const book = (req.query.book as string) || 'ዘፍጥረት';
      const chapter = parseInt((req.query.chapter as string) || '1', 10);
      const version = (req.query.version as string) === '1954' ? '1954' : 'nasv';
      const versionLabel = version === '1954' ? 'የ1954 ዓ.ም ትርጉም' : 'አዲሱ መደበኛ ትርጉም';

      const cacheKey = `${book}_${chapter}_${version}`;
      if (chapterCache.has(cacheKey)) {
        return res.json(chapterCache.get(cacheKey));
      }

      if (!process.env.GEMINI_API_KEY) {
        return res.status(503).json({
          error: 'GEMINI_API_KEY is not configured',
          fallback: true,
          book,
          chapter,
          version,
        });
      }

      const ai = getGeminiClient();

      const systemInstruction = `You are an authoritative Amharic Bible database and biblical scholar.
You provide authentic Amharic scripture text for any requested Bible book and chapter.
You strictly distinguish and provide the text according to the requested Ethiopian Amharic translation:
1. "አዲሱ መደበኛ ትርጉም" (New Amharic Standard Version - NASV, contemporary & clear Amharic)
2. "የ1954 ዓ.ም ትርጉም" (1954 Traditional/Haile Selassie Orthodox Amharic Bible, traditional Ge'ez/Amharic style)

Return authentic verses sequentially numbered 1, 2, 3... with genuine Amharic wording for the selected translation.`;

      const prompt = `እባክዎ የሚከተለውን የመጽሐፍ ቅዱስ ምዕራፍ ሙሉ ቁጥሮች በ${versionLabel} ያቅርቡ፡
መጽሐፍ: ${book}
ምዕራፍ: ${chapter}
የትርጉም ዓይነት: ${versionLabel}

እያንዳንዱን ቁጥር በትክክለኛው የቁጥር ተራ እና በ${versionLabel} ትክክለኛ ቃላት በJSON ቅርጸት ይስጡ።`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          systemInstruction,
          temperature: 0.1,
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              book: { type: Type.STRING },
              chapter: { type: Type.INTEGER },
              version: { type: Type.STRING },
              versionName: { type: Type.STRING },
              verses: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    verse: { type: Type.INTEGER },
                    text: { type: Type.STRING },
                  },
                  required: ['verse', 'text'],
                },
              },
            },
            required: ['book', 'chapter', 'version', 'verses'],
          },
        },
      });

      const responseText = response.text ? response.text.trim() : '';
      if (!responseText) {
        throw new Error('Empty response from model');
      }

      const parsedData = JSON.parse(responseText);
      const result = {
        book,
        chapter,
        version,
        versionName: versionLabel,
        verses: parsedData.verses || [],
      };

      // Save to memory cache
      chapterCache.set(cacheKey, result);

      return res.json(result);
    } catch (error: any) {
      console.error('Error fetching Bible chapter:', error);
      return res.status(500).json({
        error: error.message || 'Failed to fetch Bible chapter',
        book: req.query.book,
        chapter: req.query.chapter,
        version: req.query.version,
      });
    }
  });

  // Vite middleware for development vs static build in production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
