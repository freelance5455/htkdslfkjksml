/* AHMADI WIFI v4 — tiny animation helper (no dependencies, safe on hotspot) */
(function(){
var d=document,reduce=window.matchMedia&&matchMedia('(prefers-reduced-motion:reduce)').matches;
function ready(f){d.readyState!=='loading'?f():d.addEventListener('DOMContentLoaded',f)}
ready(function(){
  d.body.classList.add('ready');

  /* scroll reveal */
  var sel='.pk,.pc,.chip,.ans,.row2,.soc,.inf,.sheet,.pgrid,.nums,.pill2,.brush';
  var els=[].slice.call(d.querySelectorAll(sel)).filter(function(e){
    var cs=getComputedStyle(e);return cs.animationName==='none'||!cs.animationName;});
  if('IntersectionObserver' in window&&!reduce){
    var io=new IntersectionObserver(function(es){es.forEach(function(e){
      if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}})},{threshold:.12});
    els.forEach(function(e,i){e.classList.add('rv');e.style.transitionDelay=(i%4)*70+'ms';io.observe(e)});
  }

  /* ripple on any button / nav link */
  d.addEventListener('click',function(ev){
    var b=ev.target.closest&&ev.target.closest('.btn,.buy,.nav a,.tabbar a,.lg');
    if(!b||reduce||b.querySelector('.rip'))return;
    var r=b.getBoundingClientRect(),s=Math.max(r.width,r.height),x=d.createElement('span');
    x.className='rip';
    x.style.cssText='width:'+s+'px;height:'+s+'px;left:'+(ev.clientX-r.left-s/2)+'px;top:'+(ev.clientY-r.top-s/2)+'px';
    b.appendChild(x);setTimeout(function(){x.remove()},600);
  },true);

  /* smooth page leave for internal links */
  d.addEventListener('click',function(ev){
    var a=ev.target.closest&&ev.target.closest('a[href]');
    if(!a||reduce||ev.defaultPrevented||ev.metaKey||ev.ctrlKey||a.target)return;
    var h=a.getAttribute('href');
    if(!h||h.charAt(0)==='#'||/^(https?:|mailto:|tel:|javascript:)/i.test(h)||h.indexOf('$(')>-1)return;
    ev.preventDefault();d.body.classList.add('leave');
    setTimeout(function(){location.href=h},200);
  });
  window.addEventListener('pageshow',function(){d.body.classList.remove('leave')});


  /* v5: spotlight that follows finger / mouse on glass cards */
  if(!reduce){
    var spot=function(ev){
      var pt=ev.touches?ev.touches[0]:ev,c=pt.target.closest&&pt.target.closest('.card,.pk');
      if(!c)return;var r=c.getBoundingClientRect();
      c.style.setProperty('--mx',(pt.clientX-r.left)+'px');c.style.setProperty('--my',(pt.clientY-r.top)+'px');
    };
    d.addEventListener('pointermove',spot,{passive:true});
    d.addEventListener('touchmove',spot,{passive:true});
    d.addEventListener('touchstart',spot,{passive:true});
  }

  /* gauges: animate ring + count-up number */
  var C=2*Math.PI*40;
  [].forEach.call(d.querySelectorAll('.gg'),function(g){
    var pct=Math.max(0,Math.min(100,parseFloat(g.getAttribute('data-pct'))||0));
    var fg=g.querySelector('.fg');
    fg.style.setProperty('--len',C);fg.style.setProperty('--off',C*(1-pct/100));
    setTimeout(function(){g.classList.add('go')},reduce?0:60);
    var n=g.querySelector('[data-count]');
    if(n){
      var to=parseFloat(n.getAttribute('data-count'))||0,dec=to<10&&to%1?1:0,t0=null;
      if(reduce){n.textContent=to.toFixed(dec);return}
      (function step(t){t0=t0||t;var p=Math.min(1,(t-t0)/1500),e=1-Math.pow(1-p,3);
        n.textContent=(to*e).toFixed(dec);if(p<1)requestAnimationFrame(step)})(performance.now());
    }
  });
});
})();
