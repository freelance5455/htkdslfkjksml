# AHMADI WIFI — MikroTik Hotspot theme

Upload ALL files (including `img/`, `md5.js`, `style.css`, `favicon.ico`) to the router hotspot folder.

- Design: header / logo / icon / background cropped from the brand sheet (`img/header.jpg`, `img/banner.jpg`, `img/bg.jpg`, `img/logo.png`, `img/icon.png`).
- Change phone / WhatsApp: search `93700082554` in `paket.html` and `contact.html`.
- Colors: edit variables at the top of `style.css`.

## v4 — animations
- `style.css` (bottom, "v4 ANIMATION LAYER") + new `anim.js` — upload both. `anim.js` is already linked in every page.
- Added: page enter/leave fade, scroll reveal, ripple on all buttons, drawing icons, glowing icon circles, neon card sweep, staggered stat tiles, animated usage gauges + count-up numbers on `status.html`.
- Respects "reduce motion" settings on the phone.

## v5 — Modern theme
- New look appended at the bottom of `style.css` ("v5 MODERN THEME"): aurora background, floating glass header, glass cards, neon gradients, floating bottom bar.
- `anim.js` adds a light spotlight that follows the finger / mouse on cards.
- Upload `style.css` + `anim.js` + all pages as before.

## v7 — White theme (logo colours)
- New look from the brand logo: cyan → blue → purple gradient on a clean WHITE background.
- `style.css` fully re-coloured (all green removed); all pages updated (`theme-color`, SVG gradients).
- `img/logo.png`, `img/logo2.png`, `img/icon.png`, `favicon.ico` replaced with the new circular logo.
- Upload ALL files again to the router hotspot folder.
