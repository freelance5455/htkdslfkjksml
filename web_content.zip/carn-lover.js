const $ = selector => document.querySelector(selector);
const choiceScreen = $('#choice-screen');
const outcomeScreen = $('#outcome-screen');
const feedbackScreen = $('#feedback-screen');
const confessButton = $('#confess-button');
const sceneTitle = $('#scene-title');
const sceneStep = $('#scene-step');
const progressKey = 'carn-lover:progress:v1';
const selectedFlower = () => document.querySelector('input[name="flower"]:checked')?.value;

function readProgress() {
  try {
    const saved = JSON.parse(localStorage.getItem(progressKey) || '{}');
    return ['rose', 'sunflower'].includes(saved.flower) ? saved : { flower: null, stage: 'choice' };
  } catch { return { flower: null, stage: 'choice' }; }
}
let progress = readProgress();
function saveProgress() {
  try { localStorage.setItem(progressKey, JSON.stringify(progress)); } catch { /* Keep playing if storage is unavailable. */ }
}
function showOutcome(flower) {
  const rose = flower === 'rose';
  sceneStep.textContent = '02 / 03';
  sceneTitle.textContent = rose ? 'A lovely choice!' : 'Oh no...';
  $('#outcome-art').textContent = rose ? '🧍🏻‍♂️　🧍🏻‍♀️' : '😵　🌻　😠';
  $('#outcome-title').textContent = rose ? 'She hugs you. Hooray!' : 'What have you done? 😠';
  $('#outcome-copy').textContent = rose
    ? 'You gave her roses and confessed your love. She gives you a big hug!'
    : 'She has a sunflower allergy! She hits you with the flower, gets angry, and gets spots.';
  choiceScreen.hidden = true;
  feedbackScreen.hidden = true;
  outcomeScreen.hidden = false;
}
function showFeedback() {
  sceneStep.textContent = '03 / 03';
  sceneTitle.textContent = 'One last question...';
  outcomeScreen.hidden = true;
  choiceScreen.hidden = true;
  feedbackScreen.hidden = false;
}
function showFeedbackReply(answer) {
  $('#feedback-question').hidden = true;
  $('#feedback-actions').hidden = true;
  const reply = $('#feedback-reply');
  reply.hidden = false;
  reply.textContent = answer === 'yes'
    ? "Wow! That's good! We're glad you like this. Thank you! You made our day!"
    : "Oh! We're sorry. We knew it was rough! We'll try to make a good version sooner. It's okay, you can play different games on Websim.";
  $('#restart-button').hidden = false;
}

document.querySelectorAll('input[name="flower"]').forEach(input => {
  input.addEventListener('change', () => {
    confessButton.disabled = !selectedFlower();
    progress = { flower: selectedFlower(), stage: 'choice', answer: null };
    saveProgress();
  });
});

confessButton.addEventListener('click', () => {
  const flower = selectedFlower();
  if (!flower) return;
  progress = { flower, stage: 'outcome', answer: null };
  saveProgress();
  showOutcome(flower);
  $('#next-button').focus();
});

$('#next-button').addEventListener('click', () => {
  progress.stage = 'feedback';
  saveProgress();
  showFeedback();
  $('[data-feedback="yes"]').focus();
});

$('#feedback-actions').addEventListener('click', event => {
  const button = event.target.closest('[data-feedback]');
  if (!button) return;
  progress.stage = 'complete';
  progress.answer = button.dataset.feedback;
  saveProgress();
  showFeedbackReply(progress.answer);
  $('#restart-button').focus();
});

$('#restart-button').addEventListener('click', () => {
  try { localStorage.removeItem(progressKey); } catch { /* The current game can still reset. */ }
  progress = { flower: null, stage: 'choice', answer: null };
  document.querySelectorAll('input[name="flower"]').forEach(input => { input.checked = false; });
  confessButton.disabled = true;
  choiceScreen.hidden = false;
  outcomeScreen.hidden = true;
  feedbackScreen.hidden = true;
  $('#feedback-question').hidden = false;
  $('#feedback-actions').hidden = false;
  $('#feedback-reply').hidden = true;
  $('#restart-button').hidden = true;
  sceneStep.textContent = '01 / 03';
  sceneTitle.textContent = 'Choose her flowers!';
  $('#rose-choice').focus();
});

if (progress.flower) {
  const savedChoice = document.querySelector('input[name="flower"][value="' + progress.flower + '"]');
  if (savedChoice) {
    savedChoice.checked = true;
    confessButton.disabled = false;
    if (progress.stage === 'outcome') showOutcome(progress.flower);
    if (progress.stage === 'feedback' || progress.stage === 'complete') showFeedback();
    if (progress.stage === 'complete' && ['yes', 'no'].includes(progress.answer)) showFeedbackReply(progress.answer);
  }
}