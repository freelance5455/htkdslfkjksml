/* blure theme v0.7: auto is the default */
(function(){
 const KEY='blure-theme';
 const valid=['auto','light','dark'];
 function saved(){try{const x=localStorage.getItem(KEY);return valid.includes(x)?x:'auto'}catch(_){return 'auto'}}
 function apply(){const v=saved();const effective=v==='auto'?(window.matchMedia&&matchMedia('(prefers-color-scheme: light)').matches?'light':'dark'):v;document.documentElement.dataset.theme=effective;document.documentElement.dataset.themePreference=v;document.querySelectorAll('[data-blure-theme]').forEach(x=>x.value=v);const meta=document.querySelector('meta[name="theme-color"]');if(meta)meta.content=effective==='light'?'#f5f7fc':'#0b1221'}
 window.blureSetTheme=function(v){if(!valid.includes(v))return;try{localStorage.setItem(KEY,v)}catch(_){}apply()};
 apply();
 const mq=window.matchMedia&&matchMedia('(prefers-color-scheme: light)');if(mq){if(mq.addEventListener)mq.addEventListener('change',apply);else if(mq.addListener)mq.addListener(apply)}
 document.addEventListener('DOMContentLoaded',apply);
})();
