/* Tema yöneticisi: "light" | "dark" | "system" (varsayılan: system)
   <head> içinde, senkron yüklenmeli ki sayfa yanıp sönmesin. */
(function () {
  var KEY = 'theme-preference';
  var root = document.documentElement;
  var mq = window.matchMedia('(prefers-color-scheme: dark)');

  function get() {
    var v = null;
    try { v = localStorage.getItem(KEY); } catch (e) {}
    return v === 'light' || v === 'dark' ? v : 'system';
  }

  function sync() {
    var pref = get();
    document.querySelectorAll('[data-theme-set]').forEach(function (el) {
      el.setAttribute('aria-pressed', String(el.getAttribute('data-theme-set') === pref));
    });
    document.querySelectorAll('[data-theme-status]').forEach(function (el) {
      el.textContent = pref === 'system'
        ? 'Cihaz ayarı izleniyor (şu an: ' + (mq.matches ? 'koyu' : 'açık') + ')'
        : (pref === 'dark' ? 'Koyu tema her zaman açık' : 'Açık tema her zaman açık');
    });
  }

  function apply() {
    var pref = get();
    var dark = pref === 'dark' || (pref === 'system' && mq.matches);
    root.classList.toggle('dark', dark);
    sync();
  }

  function set(pref) {
    try {
      if (pref === 'system') localStorage.removeItem(KEY);
      else localStorage.setItem(KEY, pref);
    } catch (e) {}
    apply();
  }

  if (mq.addEventListener) mq.addEventListener('change', apply);
  else if (mq.addListener) mq.addListener(apply);
  window.addEventListener('storage', function (e) { if (e.key === KEY) apply(); });
  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('[data-theme-set]');
    if (b) set(b.getAttribute('data-theme-set'));
  });
  document.addEventListener('DOMContentLoaded', sync);

  apply();
  window.Theme = { get: get, set: set };
})();
