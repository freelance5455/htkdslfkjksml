/* JOSTECH — CHAPITRE COMPLET FORMAT LIVRE : WEB-2-1-1 */
registerLessonDetail(3, 2, "web-2-1-1", {
  title: "Leçon 1 : JavaScript Moderne, DOM, Asynchronisme et Sécurité XSS",
  duration: "50 min (Manuel universitaire complet)",
  objectives: [
    "Comprendre comment le navigateur construit l'arbre DOM en mémoire RAM.",
    "Manipuler le DOM proprement avec querySelector, createElement et addEventListener.",
    "Maîtriser l'asynchronisme mono-thread : Promesses, async/await, fetch() et JSON.",
    "Identifier et neutraliser les failles de sécurité XSS côté client."
  ],
  prerequisites: ["Niveau 1 Web (HTML5/CSS3) et bases d'algorithmique."],
  sections: [
    {
      type: "definition",
      term: "Le DOM (Document Object Model)",
      text: "Lorsque le navigateur reçoit un fichier HTML, il le lit de haut en bas et construit en mémoire RAM une arborescence d'objets appelée DOM : chaque balise (<body>, <article>, <button>) devient un « nœud » manipulable.\n\nJavaScript (seul langage natif des navigateurs Web) accède à cet arbre grâce à l'objet global « document » pour lire des saisies, modifier des textes ou créer de nouveaux éléments en direct sans recharger la page."
    },
    {
      type: "theory",
      title: "1. Manipulation moderne et Événements (Event-Driven)",
      text: "Contrairement à un script classique qui s'exécute du début à la fin puis s'arrête, une application Web ou mobile attend en permanence les actions de l'utilisateur (clics, touches clavier, défilement). C'est la programmation événementielle.\n\nAvec « element.addEventListener('click', fonction) », on branche un écouteur sur un bouton. Bonne pratique universitaire : manipulez toujours les styles en ajoutant/retirant une classe CSS (element.classList.toggle('active')) plutôt qu'en écrivant du CSS brut dans JavaScript."
    },
    {
      type: "theory",
      title: "2. Mono-thread, Event Loop et Asynchronisme (async / await)",
      text: "JavaScript s'exécute sur un seul fil d'exécution principal (Single-Threaded) pour la page. Si demander un cours à un serveur distant (via réseau 4G) bloquait ce fil pendant 2 secondes, tout l'écran de votre smartphone gèlerait complètement !\n\nPour éviter ce blocage, le navigateur délègue les tâches lentes (réseau, minuteurs) en arrière-plan via l'Event Loop, et renvoie une Promesse (Promise) : un objet représentant une valeur future (En attente → Résolue ou Rejetée). La syntaxe moderne « async / await » permet d'écrire ce code asynchrone de manière linéaire et lisible, toujours protégée par « try { ... } catch (err) { ... } »."
    },
    {
      type: "code",
      lang: "JavaScript ES6+ — Fetch JSON, DOM sécurisé et LocalStorage",
      code: [
        "const btn = document.querySelector('#btn-sync');",
        "const liste = document.querySelector('#liste-cours');",
        "",
        "btn.addEventListener('click', async () => {",
        "  btn.disabled = true;",
        "  try {",
        "    const rep = await fetch('https://api.jostech.edu/cours');",
        "    if (!rep.ok) throw new Error('Erreur HTTP ' + rep.status);",
        "    const cours = await rep.json(); // Convertit le texte JSON en objet JS",
        "",
        "    liste.innerHTML = ''; // Vide la liste précédente",
        "    cours.forEach(c => {",
        "      const li = document.createElement('li');",
        "      li.textContent = c.titre; // SÉCURISÉ contre XSS !",
        "      liste.appendChild(li);",
        "    });",
        "    localStorage.setItem('cache_cours', JSON.stringify(cours));",
        "  } catch (err) {",
        "    liste.textContent = 'Hors connexion : chargement impossible.';",
        "  } finally {",
        "    btn.disabled = false;",
        "  }",
        "});"
      ].join("\n")
    },
    {
      type: "table",
      title: "3. Stockage local & Format JSON",
      headers: ["Outil JS", "Rôle exact", "Usage typique"],
      rows: [
        ["JSON.stringify(obj)", "Transforme un objet/tableau JS en chaîne texte.", "Préparer des données avant envoi API ou sauvegarde."],
        ["JSON.parse(texte)", "Reconstruit l'objet JS depuis du texte JSON.", "Relire des données sauvegardées."],
        ["localStorage", "Stockage clé/valeur persistant (~5 Mo).", "Préférences (thème, taille texte, progression)."],
        ["IndexedDB", "Base de données NoSQL locale plus vaste.", "Stockage de gros cours hors ligne (Phase 5)."]
      ]
    },
    {
      type: "warning",
      title: "Sécurité critique : Faille XSS (Cross-Site Scripting)",
      text: "C'est l'une des failles Web les plus graves : si un utilisateur malveillant saisit son prénom comme « <img src=x onerror=volerSession()> » et que votre code affiche « div.innerHTML = prenom », le navigateur exécute le script pirate !\n\nRègle d'or absolue : n'utilisez JAMAIS innerHTML avec des données venant d'un utilisateur ou d'un champ texte. Utilisez toujours « textContent » (ou échappez <, >, &, \" avant affichage)."
    }
  ],
  exercises: [
    {
      title: "Exercice 1 — Ordre d'exécution de l'Event Loop",
      question: "Dans quel ordre exact s'affichent ces trois console.log() ? Expliquez pourquoi :\nconsole.log('1 - Début');\nsetTimeout(() => console.log('2 - Minuteur 0ms'), 0);\nconsole.log('3 - Fin');",
      solution: "Ordre affiché : '1 - Début', puis '3 - Fin', puis '2 - Minuteur 0ms' !\nPourquoi ? Même avec un délai de 0 ms, setTimeout passe par la file asynchrone de l'Event Loop et attend que tout le code synchrone en cours (1 et 3) soit terminé."
    },
    {
      title: "Exercice 2 — Audit de sécurité XSS",
      question: "Un développeur affiche les commentaires d'un forum étudiant avec : carte.innerHTML = `<p>${commentaire}</p>`;\nExpliquez le danger et réécrivez ces 2 lignes de façon 100 % sûre.",
      solution: "Danger : un étudiant peut poster <script>... ou <img onerror=...> et pirater tous les lecteurs (XSS Stocké).\nCorrection sûre :\nconst p = document.createElement('p');\np.textContent = commentaire;\ncarte.appendChild(p);"
    },
    {
      title: "Exercice 3 — Sauvegarde JSON dans localStorage",
      question: "Pourquoi écrire localStorage.setItem('notes', [15, 18]) est-il faux, et comment sauvegarder puis relire correctement ce tableau ?",
      solution: "localStorage ne stocke que du texte brut (il convertirait le tableau en chaîne '15,18').\nIl faut sérialiser en JSON :\nlocalStorage.setItem('notes', JSON.stringify([15, 18]));\nconst notes = JSON.parse(localStorage.getItem('notes') || '[]');"
    }
  ],
  summary: "JavaScript anime l'arbre DOM par événements, communique en asynchrone sans geler l'interface grâce à l'Event Loop et async/await, sauvegarde localement en JSON et protège les utilisateurs contre le XSS via textContent.",
  references: [
    "Haverbeke, M. — Eloquent JavaScript (4th Ed.).",
    "MDN Web Docs — Document Object Model, Fetch API et OWASP XSS Prevention."
  ]
});