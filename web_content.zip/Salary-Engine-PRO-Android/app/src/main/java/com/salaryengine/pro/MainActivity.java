package com.salaryengine.pro;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.DownloadListener;
import android.content.ContentValues;
import android.content.ContentResolver;
import android.content.Context;
import android.widget.Toast;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 4102;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(11,17,32));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(11,17,32));
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportMultipleWindows(false);
        webView.addJavascriptInterface(new NativeBridge(this), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                String js = "(function(){"
                    + "window.print=function(){AndroidBridge.printPage();};"
                    + "try{Object.defineProperty(navigator,'clipboard',{configurable:true,value:{writeText:function(t){AndroidBridge.copyText(String(t));return Promise.resolve();}}});}catch(e){}"
                    + "if(typeof downloadBlob==='function'){window.downloadBlob=function(blob,filename){var r=new FileReader();r.onload=function(){AndroidBridge.saveFile(String(r.result),String(filename),blob.type||'application/octet-stream');};r.readAsText(blob);};}"
                    + "})();";
                view.evaluateJavascript(js, null);
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent = params.createIntent();
                try { startActivityForResult(intent, FILE_CHOOSER_REQUEST); }
                catch (Exception e) { filePathCallback = null; Toast.makeText(MainActivity.this, "تعذر فتح منتقي الملفات", Toast.LENGTH_SHORT).show(); return false; }
                return true;
            }
        });
        webView.setDownloadListener((url, userAgent, contentDisposition, mimetype, contentLength) -> {
            try {
                DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
                req.setMimeType(mimetype);
                req.addRequestHeader("User-Agent", userAgent);
                req.setTitle("Salary Engine PRO");
                req.setDescription("Downloading file");
                req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "salary-engine-export");
                ((DownloadManager)getSystemService(DOWNLOAD_SERVICE)).enqueue(req);
            } catch (Exception e) { Toast.makeText(this, "تعذر تنزيل الملف", Toast.LENGTH_SHORT).show(); }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && filePathCallback != null) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                Uri uri = data.getData();
                if (uri != null) results = new Uri[]{uri};
                else if (data.getClipData() != null) {
                    ClipData clip = data.getClipData(); results = new Uri[clip.getItemCount()];
                    for (int i=0;i<clip.getItemCount();i++) results[i]=clip.getItemAt(i).getUri();
                }
            }
            filePathCallback.onReceiveValue(results); filePathCallback = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    public class NativeBridge {
        private final Context context;
        NativeBridge(Context c) { context = c; }
        @JavascriptInterface public void copyText(String value) {
            android.content.ClipboardManager cm = (android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("Salary Engine PRO", value));
            runOnUiThread(() -> Toast.makeText(context, "تم النسخ", Toast.LENGTH_SHORT).show());
        }
        @JavascriptInterface public void printPage() {
            runOnUiThread(() -> {
                PrintManager pm = (PrintManager)getSystemService(PRINT_SERVICE);
                pm.print("Salary Engine PRO", webView.createPrintDocumentAdapter("Salary Engine PRO"), new PrintAttributes.Builder().build());
            });
        }
        @JavascriptInterface public void saveFile(String content, String filename, String mime) {
            runOnUiThread(() -> {
                try {
                    String safe = filename.replaceAll("[^a-zA-Z0-9._-]", "_");
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME, safe);
                    values.put(MediaStore.Downloads.MIME_TYPE, mime);
                    values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    ContentResolver resolver = getContentResolver();
                    Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new Exception("No destination");
                    try (OutputStream out = resolver.openOutputStream(uri)) { out.write(content.getBytes(StandardCharsets.UTF_8)); }
                    Toast.makeText(context, "تم حفظ الملف في Downloads", Toast.LENGTH_LONG).show();
                } catch (Exception e) { Toast.makeText(context, "تعذر حفظ الملف", Toast.LENGTH_LONG).show(); }
            });
        }
    }
}
