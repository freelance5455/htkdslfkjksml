# Salary Engine PRO — Android Studio project

هذا مشروع Android أصلي صغير يضمّن ملف HTML الذي أرسلته داخل Android WebView. اسم التطبيق **Salary Engine PRO** ومعرّف الحزمة `com.salaryengine.pro`، والأيقونة ذهبية برمز المال.

## ما تم الحفاظ عليه
- ملف HTML الأصلي موجود كما هو في `app/src/main/assets/index.html` وكذلك نسخة العمل في `www/index.html`.
- واجهة العربية والفرنسية والإنجليزية، التصميم، الحاسبة والتدقيق، التحليلات، المقارنة، المحاكاة، السجل، المسودات و`localStorage`.
- أضيف جسر Android للطباعة وحفظ PDF، النسخ إلى الحافظة، حفظ تصدير CSV/JSON في مجلد Downloads، وفتح منتقي الملفات لاستيراد JSON.
- الاتصال بالإنترنت مسموح لتحميل Tailwind CSS وخط Cairo من المصادر الخارجية؛ لم يُشترط وضع Offline.

## إنشاء APK
1. ثبّت Android Studio وAndroid SDK وJDK 17.
2. فك ضغط مجلد المشروع.
3. من Android Studio اختر **Open** وحدد مجلد `Salary-Engine-PRO-Android` (المجلد الذي يحتوي `settings.gradle`).
4. وافق على تنزيل Gradle/Android Gradle Plugin ومكونات SDK المطلوبة عند الطلب، ثم انتظر اكتمال Gradle Sync.
5. اختر **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. ستجد APK التجريبي عادةً في:
   `app/build/outputs/apk/debug/app-debug.apk`

لإنشاء نسخة موقعة للتوزيع: **Build → Generate Signed Bundle / APK** واتبع معالج Android Studio.

## تعديل التطبيق لاحقاً
استبدل `app/src/main/assets/index.html` بالملف الجديد، ثم أعد بناء APK. لا تعدّل `www/index.html` وحده؛ إنه نسخة مرجعية إضافية.

## ملاحظات اختبار
- لم أستطع إنتاج APK نهائي داخل بيئة العمل الحالية لعدم توفر Android SDK/Android Studio وتعذر تنزيل حزم Gradle عبر الشبكة هنا. الحزمة المرفقة هي مشروع Android Studio جاهز للبناء، وليست ملف APK مثبتاً.
- اختبر على هاتف حقيقي: الاستيراد من منتقي الملفات، التصدير إلى Downloads، النسخ، والطباعة/حفظ PDF.
- يعتمد تحميل Tailwind CSS وخط Cairo على اتصال الإنترنت، وفق اختيارك.

الحد الأدنى لإصدار Android في إعداد المشروع هو Android 10 (API 29) لتوفير حفظ الملفات عبر MediaStore دون طلب أذونات تخزين واسعة.
