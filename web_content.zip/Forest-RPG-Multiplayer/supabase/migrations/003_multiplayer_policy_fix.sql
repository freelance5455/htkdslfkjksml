-- Fix recursive RLS checks for room membership reads.
-- Run after 002_multiplayer.sql in Supabase SQL Editor.
create or replace function public.game_is_room_member(p_room_id uuid)
returns boolean
language sql stable security definer
set search_path = public, pg_temp
as $$
  select exists (
    select 1 from public.game_room_members
    where room_id = p_room_id and user_id = auth.uid()
  );
$$;
revoke all on function public.game_is_room_member(uuid) from public, anon;
grant execute on function public.game_is_room_member(uuid) to authenticated;

drop policy if exists members_read_same_room on public.game_room_members;
create policy members_read_same_room on public.game_room_members
for select to authenticated using (public.game_is_room_member(room_id));

drop policy if exists world_read_same_room on public.game_world_state;
create policy world_read_same_room on public.game_world_state
for select to authenticated using (public.game_is_room_member(room_id));

drop policy if exists rooms_read_open_or_member on public.game_rooms;
create policy rooms_read_open_or_member on public.game_rooms
for select to authenticated using (is_open = true or public.game_is_room_member(id));
