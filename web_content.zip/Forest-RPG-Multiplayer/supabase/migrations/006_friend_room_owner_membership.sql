-- Forest RPG V11.2.3: require the selected friend to still be a member of the open room.
-- Run once after migrations 001-005.
create or replace function public.game_join_friend_room(p_owner_id uuid)
returns table(room_id uuid, room_code text)
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_uid uuid := auth.uid();
  v_room public.game_rooms%rowtype;
  v_old_room uuid;
  v_old_owner uuid;
  v_count integer;
begin
  if v_uid is null then raise exception 'กรุณาเข้าสู่ระบบก่อน'; end if;
  if p_owner_id is null or p_owner_id = v_uid then raise exception 'ไม่พบเจ้าของเซิร์ฟเวอร์เพื่อน'; end if;
  perform pg_advisory_xact_lock(hashtextextended(v_uid::text, 0));
  if not exists(select 1 from public.game_friends f where f.user_id=v_uid and f.friend_id=p_owner_id) then
    raise exception 'ผู้เล่นนี้ยังไม่ได้เป็นเพื่อนของคุณ';
  end if;
  select r.* into v_room from public.game_rooms r
   where r.owner_id=p_owner_id and r.is_open=true
   order by r.created_at desc limit 1 for update;
  if not found then raise exception 'เพื่อนไม่ได้เปิดเซิร์ฟเวอร์อยู่'; end if;
  if not exists(select 1 from public.game_room_members m where m.room_id=v_room.id and m.user_id=p_owner_id) then
    raise exception 'เจ้าของห้องไม่ได้อยู่ในเซิร์ฟเวอร์ กรุณาให้เพื่อนเปิดห้องใหม่';
  end if;
  select m.room_id into v_old_room from public.game_room_members m where m.user_id=v_uid for update;
  if v_old_room=v_room.id then return query select v_room.id,v_room.room_code; return; end if;
  if v_old_room is not null then
    select r.owner_id into v_old_owner from public.game_rooms r where r.id=v_old_room for update;
    if v_old_owner=v_uid then
      select count(*) into v_count from public.game_room_members m where m.room_id=v_old_room and m.user_id<>v_uid;
      if v_count>0 then raise exception 'คุณเป็นเจ้าของห้องเดิมที่ยังมีผู้เล่นอยู่ กรุณาปิดห้องเดิมก่อน'; end if;
      delete from public.game_room_members where room_id=v_old_room and user_id=v_uid;
      update public.game_rooms set is_open=false where id=v_old_room;
    else
      delete from public.game_room_members where room_id=v_old_room and user_id=v_uid;
      if not exists(select 1 from public.game_room_members m where m.room_id=v_old_room) then
        update public.game_rooms set is_open=false where id=v_old_room;
      end if;
    end if;
  end if;
  select count(*) into v_count from public.game_room_members m where m.room_id=v_room.id;
  if v_count>=v_room.max_players then raise exception 'ห้องเต็มแล้ว (สูงสุด 4 คน)'; end if;
  insert into public.game_room_members(room_id,user_id) values(v_room.id,v_uid);
  return query select v_room.id,v_room.room_code;
end;
$$;
revoke all on function public.game_join_friend_room(uuid) from public, anon;
grant execute on function public.game_join_friend_room(uuid) to authenticated;
