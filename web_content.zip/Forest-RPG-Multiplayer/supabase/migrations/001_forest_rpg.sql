create extension if not exists pgcrypto;

create table if not exists public.game_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  game_id text not null unique check (char_length(game_id) between 3 and 16),
  display_name text not null default '',
  game_state jsonb not null default '{}'::jsonb,
  is_banned boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.game_sessions (
  user_id uuid primary key references auth.users(id) on delete cascade,
  room_id text,
  online boolean not null default true,
  last_heartbeat timestamptz not null default now()
);

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create index if not exists game_profiles_created_idx on public.game_profiles(created_at desc);
create index if not exists game_sessions_online_idx on public.game_sessions(online, last_heartbeat desc);

alter table public.game_profiles enable row level security;
alter table public.game_sessions enable row level security;
alter table public.admin_users enable row level security;

drop policy if exists "player reads own profile" on public.game_profiles;
create policy "player reads own profile" on public.game_profiles for select to authenticated using (id = auth.uid());
drop policy if exists "player creates own profile" on public.game_profiles;
create policy "player creates own profile" on public.game_profiles for insert to authenticated with check (id = auth.uid() and is_banned = false);
drop policy if exists "player updates own profile" on public.game_profiles;
create policy "player updates own profile" on public.game_profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

revoke all on public.game_profiles from anon, authenticated;
grant select on public.game_profiles to authenticated;
grant insert (id, game_id, display_name, game_state) on public.game_profiles to authenticated;
grant update (game_state) on public.game_profiles to authenticated;

drop policy if exists "player reads own session" on public.game_sessions;
create policy "player reads own session" on public.game_sessions for select to authenticated using (user_id = auth.uid());
drop policy if exists "player inserts own session" on public.game_sessions;
create policy "player inserts own session" on public.game_sessions for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "player updates own session" on public.game_sessions;
create policy "player updates own session" on public.game_sessions for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
revoke all on public.game_sessions from anon, authenticated;
grant select, insert, update on public.game_sessions to authenticated;
revoke all on public.admin_users from anon, authenticated;

create or replace function public.set_updated_at() returns trigger language plpgsql set search_path = public as $$
begin new.updated_at = now(); return new; end;
$$;
drop trigger if exists game_profiles_updated_at on public.game_profiles;
create trigger game_profiles_updated_at before update on public.game_profiles for each row execute function public.set_updated_at();
