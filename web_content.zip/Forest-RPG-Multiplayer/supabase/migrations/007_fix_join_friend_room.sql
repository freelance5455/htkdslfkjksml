-- Forest RPG V11.2.6 - fix "เข้าห้องเพื่อนไม่สำเร็จ"
-- Run ONCE in the Supabase SQL Editor AFTER migrations 001-006. Safe to re-run (create or replace only; no tables are created).
--
-- ROOT CAUSE
--   game_join_friend_room (migrations 005 and 006) is declared "returns table(room_id uuid, room_code text)".
--   Inside plpgsql those OUT columns are variables named room_id / room_code, so the unqualified
--       delete from public.game_room_members where room_id = v_old_room and user_id = v_uid;
--   fails with  ERROR: column reference "room_id" is ambiguous.
--   That statement only runs when the joining player is ALREADY in another room (for example the room they
--   created for themselves), which is exactly the normal case -> every such join was rejected and the player never
--   reached the owner's room_id.
--
-- FIX: qualify every column and also tell plpgsql to prefer columns (#variable_conflict use_column).

create or replace function public.game_join_friend_room(p_owner_id uuid)
returns table(room_id uuid, room_code text)
language plpgsql
security definer
set search_path = public, pg_temp
as $$
#variable_conflict use_column
declare
  v_uid uuid := auth.uid();
  v_room public.game_rooms%rowtype;
  v_old_room uuid;
  v_old_owner uuid;
  v_count integer;
begin
  if v_uid is null then raise exception 'กรุณาเข้าสู่ระบบก่อน'; end if;
  if p_owner_id is null or p_owner_id = v_uid then raise exception 'ไม่พบเจ้าของเซิร์ฟเวอร์เพื่อน'; end if;

  -- serialise room changes of this account (no duplicate memberships on double taps / retries)
  perform pg_advisory_xact_lock(hashtextextended(v_uid::text, 0));

  if not exists (select 1 from public.game_friends f where f.user_id = v_uid and f.friend_id = p_owner_id) then
    raise exception 'ผู้เล่นนี้ยังไม่ได้เป็นเพื่อนของคุณ';
  end if;

  select r.* into v_room
  from public.game_rooms r
  where r.owner_id = p_owner_id and r.is_open = true
  order by r.created_at desc
  limit 1
  for update;
  if not found then raise exception 'เพื่อนไม่ได้เปิดเซิร์ฟเวอร์อยู่'; end if;

  -- the owner must still be a member of this exact room
  if not exists (select 1 from public.game_room_members om where om.room_id = v_room.id and om.user_id = p_owner_id) then
    raise exception 'เจ้าของห้องไม่ได้อยู่ในเซิร์ฟเวอร์ กรุณาให้เพื่อนเปิดห้องใหม่';
  end if;

  select m.room_id into v_old_room from public.game_room_members m where m.user_id = v_uid for update;

  -- already in the requested room: a retry is a success and returns the SAME room_id
  if v_old_room = v_room.id then
    return query select v_room.id, v_room.room_code;
    return;
  end if;

  -- leave the previous room first (atomic: same transaction as the insert below)
  if v_old_room is not null then
    select r.owner_id into v_old_owner from public.game_rooms r where r.id = v_old_room for update;
    if v_old_owner = v_uid then
      select count(*) into v_count from public.game_room_members m where m.room_id = v_old_room and m.user_id <> v_uid;
      if v_count > 0 then
        raise exception 'คุณเป็นเจ้าของห้องเดิมที่ยังมีผู้เล่นอยู่ กรุณาปิดห้องเดิมก่อน';
      end if;
      delete from public.game_room_members dm where dm.room_id = v_old_room and dm.user_id = v_uid;
      update public.game_rooms gr set is_open = false where gr.id = v_old_room;
    else
      delete from public.game_room_members dm where dm.room_id = v_old_room and dm.user_id = v_uid;
      if not exists (select 1 from public.game_room_members m2 where m2.room_id = v_old_room) then
        update public.game_rooms gr set is_open = false where gr.id = v_old_room;
      end if;
    end if;
  end if;

  select count(*) into v_count from public.game_room_members m3 where m3.room_id = v_room.id;
  if v_count >= v_room.max_players then raise exception 'ห้องเต็มแล้ว (สูงสุด 4 คน)'; end if;

  insert into public.game_room_members(room_id, user_id) values (v_room.id, v_uid);
  return query select v_room.id, v_room.room_code;
end;
$$;
revoke all on function public.game_join_friend_room(uuid) from public, anon;
grant execute on function public.game_join_friend_room(uuid) to authenticated;

-- Friends' rooms that are really joinable: open, owner is still a member and was seen in the last 2 minutes
-- (the V11.2.6 client sends a heartbeat through game_update_presence every 20 s while a room is connected).
create or replace function public.game_list_friend_rooms()
returns table(room_id uuid, owner_id uuid, name text, room_code text, member_count integer, owner_seen timestamptz)
language plpgsql
stable
security definer
set search_path = public, pg_temp
as $$
#variable_conflict use_column
begin
  if auth.uid() is null then raise exception 'กรุณาเข้าสู่ระบบก่อน'; end if;
  return query
    select r.id, r.owner_id, r.name, r.room_code,
           (select count(*)::integer from public.game_room_members c where c.room_id = r.id),
           om.last_seen
    from public.game_rooms r
    join public.game_friends f on f.user_id = auth.uid() and f.friend_id = r.owner_id
    join public.game_room_members om on om.room_id = r.id and om.user_id = r.owner_id
    where r.is_open = true
      and om.last_seen > now() - interval '2 minutes'
    order by r.created_at desc;
end;
$$;
revoke all on function public.game_list_friend_rooms() from public, anon;
grant execute on function public.game_list_friend_rooms() to authenticated;
