-- Forest RPG Multiplayer v1: friends, 4-player rooms, shared world snapshot.
-- Run AFTER 001_forest_rpg.sql in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.game_friends (
  user_id uuid not null references auth.users(id) on delete cascade,
  friend_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, friend_id),
  constraint game_friends_no_self check (user_id <> friend_id)
);

create table if not exists public.game_friend_requests (
  id uuid primary key default gen_random_uuid(),
  from_user uuid not null references auth.users(id) on delete cascade,
  to_user uuid not null references auth.users(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','accepted','declined')),
  created_at timestamptz not null default now(),
  unique (from_user,to_user),
  check (from_user <> to_user)
);

create table if not exists public.game_rooms (
  id uuid primary key default gen_random_uuid(),
  room_code text not null unique,
  name text not null default 'Forest Room',
  owner_id uuid not null references auth.users(id) on delete cascade,
  max_players int not null default 4 check (max_players = 4),
  is_open boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.game_room_members (
  room_id uuid not null references public.game_rooms(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  joined_at timestamptz not null default now(),
  last_seen timestamptz not null default now(),
  primary key (room_id,user_id),
  unique (user_id)
);

create table if not exists public.game_world_state (
  room_id uuid primary key references public.game_rooms(id) on delete cascade,
  world jsonb not null default '{}'::jsonb,
  revision bigint not null default 0,
  updated_by uuid references auth.users(id),
  updated_at timestamptz not null default now()
);

create index if not exists game_friend_requests_to_idx on public.game_friend_requests(to_user,status);
create index if not exists game_rooms_open_idx on public.game_rooms(is_open,created_at desc);
create index if not exists game_room_members_seen_idx on public.game_room_members(room_id,last_seen desc);

alter table public.game_friends enable row level security;
alter table public.game_friend_requests enable row level security;
alter table public.game_rooms enable row level security;
alter table public.game_room_members enable row level security;
alter table public.game_world_state enable row level security;

-- No direct client writes: mutations go through authenticated RPCs.
revoke all on public.game_friends, public.game_friend_requests, public.game_rooms,
  public.game_room_members, public.game_world_state from anon, authenticated;
grant select on public.game_friends, public.game_friend_requests, public.game_rooms,
  public.game_room_members, public.game_world_state to authenticated;

-- Read access is scoped to the signed-in player and their current room.
drop policy if exists friends_read_own on public.game_friends;
create policy friends_read_own on public.game_friends for select to authenticated
  using (user_id=auth.uid());
drop policy if exists requests_read_involved on public.game_friend_requests;
create policy requests_read_involved on public.game_friend_requests for select to authenticated
  using (from_user=auth.uid() or to_user=auth.uid());
drop policy if exists rooms_read_open_or_member on public.game_rooms;
create policy rooms_read_open_or_member on public.game_rooms for select to authenticated
  using (is_open=true or exists(select 1 from public.game_room_members m where m.room_id=id and m.user_id=auth.uid()));
drop policy if exists members_read_same_room on public.game_room_members;
create policy members_read_same_room on public.game_room_members for select to authenticated
  using (exists(select 1 from public.game_room_members mine where mine.room_id=game_room_members.room_id and mine.user_id=auth.uid()));
drop policy if exists world_read_same_room on public.game_world_state;
create policy world_read_same_room on public.game_world_state for select to authenticated
  using (exists(select 1 from public.game_room_members m where m.room_id=game_world_state.room_id and m.user_id=auth.uid()));

create or replace function public.game_create_room(p_name text default 'Forest Room')
returns table(room_id uuid, room_code text)
language plpgsql security definer set search_path = public, pg_temp as $$
declare v_uid uuid := auth.uid(); v_id uuid; v_code text;
begin
  if v_uid is null then raise exception 'กรุณาเข้าสู่ระบบก่อน'; end if;
  if exists(select 1 from game_room_members where user_id=v_uid) then
    raise exception 'คุณอยู่ในห้องอื่นแล้ว กรุณาออกจากห้องเดิมก่อน';
  end if;
  v_code := upper(encode(gen_random_bytes(4),'hex'));
  insert into game_rooms(room_code,name,owner_id)
    values(v_code,left(coalesce(nullif(trim(p_name),''),'Forest Room'),32),v_uid)
    returning id into v_id;
  insert into game_room_members(room_id,user_id) values(v_id,v_uid);
  insert into game_world_state(room_id,world,updated_by) values(v_id,'{}'::jsonb,v_uid);
  return query select v_id,v_code;
end $$;

create or replace function public.game_join_room(p_code text)
returns uuid
language plpgsql security definer set search_path = public, pg_temp as $$
declare v_uid uuid := auth.uid(); v_room game_rooms%rowtype; v_count int;
begin
  if v_uid is null then raise exception 'กรุณาเข้าสู่ระบบก่อน'; end if;
  if exists(select 1 from game_room_members where user_id=v_uid) then
    raise exception 'คุณอยู่ในห้องอื่นแล้ว กรุณาออกจากห้องเดิมก่อน';
  end if;
  select * into v_room from game_rooms where room_code=upper(trim(p_code)) and is_open=true for update;
  if not found then raise exception 'ไม่พบห้องหรือห้องปิดแล้ว'; end if;
  select count(*) into v_count from game_room_members where room_id=v_room.id;
  if v_count >= 4 then raise exception 'ห้องเต็มแล้ว (สูงสุด 4 คน)'; end if;
  insert into game_room_members(room_id,user_id) values(v_room.id,v_uid);
  return v_room.id;
end $$;

create or replace function public.game_leave_room()
returns void language plpgsql security definer set search_path = public, pg_temp as $$
declare v_uid uuid := auth.uid(); v_room uuid; v_owner uuid;
begin
  if v_uid is null then raise exception 'กรุณาเข้าสู่ระบบก่อน'; end if;
  select room_id into v_room from game_room_members where user_id=v_uid;
  if v_room is null then return; end if;
  select owner_id into v_owner from game_rooms where id=v_room;
  delete from game_room_members where room_id=v_room and user_id=v_uid;
  if v_owner=v_uid then
    update game_rooms set is_open=false where id=v_room;
    delete from game_room_members where room_id=v_room;
  elsif not exists(select 1 from game_room_members where room_id=v_room) then
    update game_rooms set is_open=false where id=v_room;
  end if;
end $$;

create or replace function public.game_send_friend_request(p_game_id text)
returns uuid language plpgsql security definer set search_path = public, pg_temp as $$
declare v_uid uuid := auth.uid(); v_target uuid; v_req uuid;
begin
  if v_uid is null then raise exception 'กรุณาเข้าสู่ระบบก่อน'; end if;
  select id into v_target from game_profiles where lower(game_id)=lower(trim(p_game_id));
  if v_target is null then raise exception 'ไม่พบ Game ID นี้'; end if;
  if v_target=v_uid then raise exception 'เพิ่มตัวเองเป็นเพื่อนไม่ได้'; end if;
  if exists(select 1 from game_friends where user_id=v_uid and friend_id=v_target) then
    raise exception 'เป็นเพื่อนกันอยู่แล้ว';
  end if;
  insert into game_friend_requests(from_user,to_user,status)
    values(v_uid,v_target,'pending')
    on conflict(from_user,to_user) do update set status='pending',created_at=now()
    returning id into v_req;
  return v_req;
end $$;

create or replace function public.game_respond_friend_request(p_request_id uuid,p_accept boolean)
returns void language plpgsql security definer set search_path = public, pg_temp as $$
declare v_uid uuid := auth.uid(); v_from uuid;
begin
  if v_uid is null then raise exception 'กรุณาเข้าสู่ระบบก่อน'; end if;
  select from_user into v_from from game_friend_requests
    where id=p_request_id and to_user=v_uid and status='pending' for update;
  if v_from is null then raise exception 'ไม่พบคำขอเป็นเพื่อน'; end if;
  update game_friend_requests set status=case when p_accept then 'accepted' else 'declined' end where id=p_request_id;
  if p_accept then
    insert into game_friends(user_id,friend_id) values(v_uid,v_from),(v_from,v_uid) on conflict do nothing;
  end if;
end $$;

create or replace function public.game_update_presence()
returns void language plpgsql security definer set search_path = public, pg_temp as $$
begin
  if auth.uid() is null then raise exception 'กรุณาเข้าสู่ระบบก่อน'; end if;
  update game_room_members set last_seen=now() where user_id=auth.uid();
end $$;

create or replace function public.game_publish_world(p_world jsonb,p_expected_revision bigint default null)
returns bigint language plpgsql security definer set search_path = public, pg_temp as $$
declare v_uid uuid := auth.uid(); v_room uuid; v_rev bigint;
begin
  if v_uid is null then raise exception 'กรุณาเข้าสู่ระบบก่อน'; end if;
  select room_id into v_room from game_room_members where user_id=v_uid;
  if v_room is null then raise exception 'คุณไม่ได้อยู่ในห้อง'; end if;
  if pg_column_size(p_world)>200000 then raise exception 'ข้อมูลโลกมีขนาดใหญ่เกินไป'; end if;
  update game_world_state set world=p_world,revision=revision+1,updated_by=v_uid,updated_at=now()
    where room_id=v_room and (p_expected_revision is null or revision=p_expected_revision)
    returning revision into v_rev;
  if v_rev is null then raise exception 'ข้อมูลโลกเปลี่ยนไปแล้ว กรุณาโหลดใหม่'; end if;
  return v_rev;
end $$;

revoke all on function public.game_create_room(text), public.game_join_room(text), public.game_leave_room(),
  public.game_send_friend_request(text), public.game_respond_friend_request(uuid,boolean),
  public.game_update_presence(), public.game_publish_world(jsonb,bigint) from public, anon;
grant execute on function public.game_create_room(text), public.game_join_room(text), public.game_leave_room(),
  public.game_send_friend_request(text), public.game_respond_friend_request(uuid,boolean),
  public.game_update_presence(), public.game_publish_world(jsonb,bigint) to authenticated;

-- Enable Realtime for room/member/world changes (safe to rerun).
do $$ begin
  alter publication supabase_realtime add table public.game_rooms;
exception when duplicate_object then null; when undefined_object then null; end $$;
do $$ begin
  alter publication supabase_realtime add table public.game_room_members;
exception when duplicate_object then null; when undefined_object then null; end $$;
do $$ begin
  alter publication supabase_realtime add table public.game_world_state;
exception when duplicate_object then null; when undefined_object then null; end $$;
