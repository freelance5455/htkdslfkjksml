-- Forest RPG co-op room world persistence (safe additive migration)
-- Run once in Supabase SQL Editor after migrations 002 and 003.
create or replace function public.game_publish_room_world(
  p_world jsonb,
  p_expected_revision bigint default null
)
returns bigint
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_uid uuid := auth.uid();
  v_room uuid;
  v_owner uuid;
  v_rev bigint;
begin
  if v_uid is null then raise exception 'กรุณาเข้าสู่ระบบก่อน'; end if;
  select m.room_id, r.owner_id into v_room, v_owner
  from public.game_room_members m
  join public.game_rooms r on r.id=m.room_id
  where m.user_id=v_uid;
  if v_room is null then raise exception 'คุณไม่ได้อยู่ในห้อง'; end if;
  if v_owner <> v_uid then raise exception 'เฉพาะหัวห้องเท่านั้นที่บันทึกโลกส่วนกลางได้'; end if;
  if p_world is null or pg_column_size(p_world)>200000 then raise exception 'ข้อมูลโลกมีขนาดใหญ่เกินไป'; end if;
  update public.game_world_state
    set world=p_world, revision=revision+1, updated_by=v_uid, updated_at=now()
    where room_id=v_room
    and (p_expected_revision is null or revision=p_expected_revision)
    returning revision into v_rev;
  if v_rev is null then raise exception 'บันทึกโลกไม่สำเร็จ กรุณาโหลดใหม่'; end if;
  return v_rev;
end;
$$;
revoke all on function public.game_publish_room_world(jsonb,bigint) from public, anon;
grant execute on function public.game_publish_room_world(jsonb,bigint) to authenticated;
