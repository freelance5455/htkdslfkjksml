# Forest RPG Multiplayer — V11.2

## แก้ไขจาก V11.1

1. **เข้าห้องเพื่อนแบบยืนยันผลจริง**
   - รอ Supabase session ก่อนเรียก RPC
   - ตรวจสอบรหัสห้องที่เข้ากับห้องในฐานข้อมูลอีกครั้ง
   - รอให้ Supabase Realtime subscribe สำเร็จและโหลดสถานะโลกก่อนเปิดให้เล่น
   - หากยืนยันการเชื่อมต่อไม่ได้ จะแสดงข้อผิดพลาดแทนการแสดงว่าเข้าเกมสำเร็จ

2. **หยุดเกมเมื่อเปิดเมนู**
   - หยุดการเคลื่อนที่ การต่อสู้ AI มอนสเตอร์ เวลาในเกม และคิวคราฟระหว่างเปิดเมนู/หน้าต่าง Multiplayer
   - ป้องกันคีย์บอร์ด จอยสติ๊ก ปุ่มโจมตี ปุ่มวิ่ง และปุ่มยาไม่ให้ส่งคำสั่งทะลุหน้าต่างเมนู
   - ปิดเมนูแล้วเกมจึงทำงานต่อ

3. **ปรับเมนูเลือกเซิร์ฟเวอร์ให้พอดีจอ**
   - จำกัดความกว้างและความสูงตาม viewport
   - รองรับจอเล็ก จอใหญ่ แนวตั้ง แนวนอน และ safe area
   - แยกพื้นที่เลื่อนรายชื่อเซิร์ฟเวอร์/ห้องเพื่อน เพื่อให้ปุ่มเข้าห้องยังเข้าถึงได้

## หมายเหตุการทดสอบ

ตรวจสอบไวยากรณ์ JavaScript และความสมบูรณ์ของ ZIP แล้ว แต่การยืนยันการทำงานจริงของ Supabase Realtime ต้องทดสอบด้วยบัญชี 2 บัญชีบนอุปกรณ์/เบราว์เซอร์แยกกัน และต้องใช้ Supabase project ที่มี migrations และ policies ของ V11 ครบถ้วน

## V11.2.1 — Friend room join fix
- Friend server list now shows only rooms that are open.
- Joining from the friend-server list now targets the friend's owner UUID, not a copied room-code route.
- Added `game_join_friend_room(uuid)` RPC to verify friendship, resolve the owner's open room, safely switch membership, and return the exact room UUID/code.
- Added client verification that the returned Room ID matches the subscribed room before entering gameplay.
- Required Supabase migration: `supabase/migrations/005_friend_room_join_fix.sql` (run after migrations 001–004).
- Live two-account Supabase testing is still required; this archive has not been connected to the user's Supabase project.
