import {chromium,newClient,signup,waitPlay,snap,sceneColors,sleep,ev} from './lib.mjs';
import {createBackend} from './backend.mjs';
for(const [label,index] of [['ORIGINAL V11.2.5','/home/claude/test/orig_index.html'],['FIXED V11.2.6','/home/claude/work/Forest-RPG-Multiplayer/index.html']]){
 const be=await createBackend({fix:true});const br=await chromium.launch();
 const A=await newClient(br,be,'A',index);await signup(A,'alice01');
 await A.page.click('#srvcreate');await waitPlay(A);await sleep(800);
 // a remote player whose data makes drawP() throw (corrupt network record)
 await ev(A,()=>{const r={x:P.x+40,y:P.y,dx:0,dy:1,ph:0,mvn:0,at:-1,cb:0,n:'x',eq:{},tl:[],sel:-1,dr:-1,ip:-1,it:0,run:0,fx:1};Object.defineProperty(r,'hurt',{get(){throw new Error('boom')}});Object.defineProperty(r,'ph',{get(){throw new Error('boom')},set(){}});rp['sb-bad']=r;window.__realP=P});
 await sleep(2500);
 const o=await ev(A,()=>({PisRemote:P===rp['sb-bad'],PisReal:P===window.__realP,err:window.__forestGameLoopError&&window.__forestGameLoopError.message}));
 const col=await sceneColors(A);
 console.log(label,JSON.stringify(o),'scene colours:',col);
 await br.close();await be.close();
}
