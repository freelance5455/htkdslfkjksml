import {PGlite} from '@electric-sql/pglite';
import {pgcrypto} from '@electric-sql/pglite/contrib/pgcrypto';
import {readFileSync} from 'fs';
import {randomUUID} from 'crypto';
const MIG='/home/claude/work/Forest-RPG-Multiplayer/supabase/migrations/';
const ident=s=>{if(!/^[a-z_][a-z0-9_]*$/i.test(s))throw new Error('bad ident '+s);return s};
export async function createBackend({fix=true}={}){
  const db=new PGlite({extensions:{pgcrypto}});
  await db.exec(`create schema auth;create table auth.users(id uuid primary key default gen_random_uuid(),email text unique,pw text);
  create function auth.uid() returns uuid language sql stable as $$ select nullif(current_setting('app.uid',true),'')::uuid $$;
  create role anon; create role authenticated; create publication supabase_realtime;
  grant usage on schema auth to authenticated; grant usage on schema public to authenticated;`);
  const files=['001_forest_rpg','002_multiplayer','003_multiplayer_policy_fix','004_coop_room_world','005_friend_room_join_fix','006_friend_room_owner_membership'];
  if(fix)files.push('007_fix_join_friend_room');
  for(const f of files)await db.exec(readFileSync(MIG+f+'.sql','utf8'));
  const clients=new Map();   // cid -> {page,uid,eps,bucket:{t,n},dropped}
  const channels=new Map();  // name -> Map(cid -> {key,payload,pg:[]})
  const stats={sent:0,dropped:0,calls:0};
  let queue=Promise.resolve();
  const serial=fn=>{const p=queue.then(fn,fn);queue=p.catch(()=>{});return p};   // PGlite = one connection
  const deliver=(cid,msg)=>{const c=clients.get(cid);if(!c||!c.page||c.page.isClosed())return;c.chain=(c.chain||Promise.resolve()).then(()=>c.page.evaluate(m=>window.__mockRecv&&window.__mockRecv(m),msg)).catch(()=>{})};
  const presenceOf=name=>{const st={};for(const [cid,m] of channels.get(name)||[]){if(m.payload!==undefined)st[m.key]=[m.payload]}return st};
  const syncPresence=name=>{const st=presenceOf(name);for(const cid of (channels.get(name)||new Map()).keys())deliver(cid,{ch:name,kind:'presence',state:st})};
  const rate=(cid)=>{const c=clients.get(cid);const now=Date.now();if(!c.bucket||now-c.bucket.t>=1000)c.bucket={t:now,n:0};c.bucket.n++;if(c.bucket.n>c.eps){c.dropped=(c.dropped||0)+1;stats.dropped++;return false}stats.sent++;return true};
  const asUser=async(uid,sql,params)=>{
    return db.transaction(async tx=>{
      await tx.query(`select set_config('app.uid',$1,true)`,[uid||'']);
      await tx.exec('set local role authenticated');
      const r=await tx.query(sql,params);
      return r;
    });
  };
  const err=e=>({message:e.message,code:e.code||'P0001'});
  const emitChange=async(rooms)=>{ // coarse postgres_changes emulation: tell subscribers of the affected rooms
    for(const [name,members] of channels)for(const [cid,m] of members)for(const p of m.pg){
      for(const rid of rooms){
        const fk=(p.table==='game_rooms'?'id=eq.':'room_id=eq.')+rid;
        if(p.filter===fk)deliver(cid,{ch:name,kind:'pg',table:p.table,event:'*',filterKey:p.filter,new:{}});
      }
    }
  };
  const membersSnapshot=async()=> (await db.query('select room_id,user_id from public.game_room_members')).rows;
  const handlers={
    async 'auth.signUp'(c,{email,password,meta}){const ex=await db.query('select 1 from auth.users where email=$1',[email]);if(ex.rows.length)return {error:{message:'User already registered'}};const r=await db.query('insert into auth.users(email,pw) values($1,$2) returning id',[email,password]);c.uid=r.rows[0].id;return {id:c.uid}},
    async 'auth.signIn'(c,{email,password}){const r=await db.query('select id from auth.users where email=$1 and pw=$2',[email,password]);if(!r.rows.length)return {error:{message:'Invalid login credentials'}};c.uid=r.rows[0].id;return {id:c.uid}},
    async 'auth.signOut'(c){c.uid=null;return {}},
    async 'auth.getSession'(c){return {id:c.uid}},
    async rpc(c,{name,args}){
      ident(name);const keys=Object.keys(args);const params=keys.map(k=>args[k]);
      const sql=`select * from public.${name}(${keys.map((k,i)=>`${ident(k)} => $${i+1}${typeof args[k]==='object'&&args[k]!==null?'::jsonb':''}`).join(',')})`;
      const before=await membersSnapshot();
      try{
        const p=params.map(v=>typeof v==='object'&&v!==null?JSON.stringify(v):v);
        const r=await asUser(c.uid,sql,p);
        const after=await membersSnapshot();
        const rooms=new Set([...before,...after].map(x=>x.room_id));
        const changed=JSON.stringify(before)!==JSON.stringify(after);
        if(changed)emitChange(rooms);
        if(name==='game_publish_room_world'){const rr=await db.query('select room_id,world,revision from public.game_world_state where room_id=(select room_id from public.game_room_members where user_id=$1)',[c.uid]);for(const row of rr.rows){for(const [n,mm] of channels)for(const [cid,m] of mm)for(const pgf of m.pg)if(pgf.table==='game_world_state'&&pgf.filter==='room_id=eq.'+row.room_id)deliver(cid,{ch:n,kind:'pg',table:'game_world_state',event:'UPDATE',filterKey:pgf.filter,new:row})}}
        const rows=r.rows;
        // functions returning a scalar come back as one column named after the function
        const data=rows.length===1&&Object.keys(rows[0]).length===1&&Object.keys(rows[0])[0]===name?rows[0][name]:rows;
        return {data,error:null};
      }catch(e){return {data:null,error:err(e)}}
    },
    async from(c,q){
      try{
        const cols=q.cols==='*'?'*':q.cols.split(',').map(x=>ident(x.trim())).join(',');
        const params=[];const where=q.filters.map(f=>{if(f.t==='eq'){params.push(f.v);return `${ident(f.c)}=$${params.length}`}params.push(f.v);return `${ident(f.c)}=any($${params.length})`}).join(' and ');
        let sql,r;
        if(q.op==='select'){sql=`select ${cols} from public.${ident(q.table)}`+(where?` where ${where}`:'')+(q.order.length?' order by '+q.order.map(o=>ident(o.c)+(o.asc?'':' desc')).join(','):'')+(q.limit?` limit ${+q.limit}`:'');r=await asUser(c.uid,sql,params)}
        else if(q.op==='update'){const ks=Object.keys(q.values);const sets=ks.map((k,i)=>{params.unshift();return null});
          const p2=[];const setSql=ks.map(k=>{p2.push(typeof q.values[k]==='object'?JSON.stringify(q.values[k]):q.values[k]);return `${ident(k)}=$${p2.length}${typeof q.values[k]==='object'?'::jsonb':''}`}).join(',');
          const w2=q.filters.map(f=>{p2.push(f.v);return `${ident(f.c)}=$${p2.length}`}).join(' and ');
          r=await asUser(c.uid,`update public.${ident(q.table)} set ${setSql} where ${w2} returning *`,p2)}
        else{const vals=q.values;const ks=Object.keys(vals);const p2=ks.map(k=>typeof vals[k]==='object'&&vals[k]!==null?JSON.stringify(vals[k]):vals[k]);
          const conflict=q.op==='upsert'?` on conflict (${ident(q.onConflict||ks[0])}) do update set ${ks.filter(k=>k!==(q.onConflict||ks[0])).map(k=>`${ident(k)}=excluded.${ident(k)}`).join(',')}`:'';
          r=await asUser(c.uid,`insert into public.${ident(q.table)}(${ks.map(ident).join(',')}) values(${ks.map((k,i)=>`$${i+1}${typeof vals[k]==='object'&&vals[k]!==null?'::jsonb':''}`).join(',')})${conflict} returning *`,p2)}
        let data=r.rows;
        if(q.single==='single'){if(data.length!==1)return {data:null,error:{message:'JSON object requested, multiple (or no) rows returned',code:'PGRST116'}};data=data[0]}
        else if(q.single==='maybe'){if(data.length>1)return {data:null,error:{message:'multiple rows',code:'PGRST116'}};data=data[0]||null}
        return {data,error:null};
      }catch(e){return {data:null,error:err(e)}}
    },
    async 'chan.join'(c,{name,key,pg}){let m=channels.get(name);if(!m){m=new Map();channels.set(name,m)}m.set(c.cid,{key,payload:undefined,pg});syncPresence(name);return {ok:true}},
    async 'chan.track'(c,{name,payload}){if(!rate(c.cid))return {ok:false,err:'rate limited'};const m=channels.get(name)?.get(c.cid);if(!m)return {ok:false,err:'not joined'};m.payload=payload;syncPresence(name);return {ok:true}},
    async 'chan.untrack'(c,{name}){const m=channels.get(name)?.get(c.cid);if(m)m.payload=undefined;syncPresence(name);return {ok:true}},
    async 'chan.send'(c,{name,event,payload}){if(!rate(c.cid))return {ok:false,err:'rate limited'};const m=channels.get(name);if(!m||!m.has(c.cid))return {ok:false,err:'not joined'};for(const cid of m.keys())if(cid!==c.cid)deliver(cid,{ch:name,kind:'broadcast',event,payload});return {ok:true}},
    async 'chan.leave'(c,{name}){const m=channels.get(name);if(m){m.delete(c.cid);if(!m.size)channels.delete(name);else syncPresence(name)}return {ok:true}},
  };
  const clientJS=readFileSync('/home/claude/test/mockclient.js','utf8');
  return {
    db,stats,clients,channels,
    async attach(ctx,page,cid){
      const c={cid,page,uid:null,eps:10,dropped:0};clients.set(cid,c);
      await page.addInitScript(id=>{window.__CID=id},cid);
      await page.exposeFunction('__mockHello',(id,eps)=>{c.eps=eps});
      await page.exposeFunction('__mockCall',async(id,op,args)=>{
        stats.calls++;
        const h=handlers[op];if(!h)return {error:{message:'unknown op '+op}};
        if(op.startsWith('chan.'))return h(c,args);          // realtime path is not serialised behind SQL
        return serial(()=>h(c,args));
      });
      await ctx.route('https://esm.sh/**',r=>r.fulfill({status:200,contentType:'text/javascript',body:clientJS}));
    },
    async kill(cid){for(const [n,m] of channels){if(m.delete(cid)){if(!m.size)channels.delete(n);else syncPresence(n)}}},
    async close(){await db.close()}
  };
}
