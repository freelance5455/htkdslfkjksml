import {PGlite} from '@electric-sql/pglite';
import {pgcrypto} from '@electric-sql/pglite/contrib/pgcrypto';
import {readFileSync} from 'fs';
const dir='/home/claude/work/Forest-RPG-Multiplayer/supabase/migrations/';
const withFix=process.argv[2]==='fix';
const db=new PGlite({extensions:{pgcrypto}});
await db.exec(`create schema auth;create table auth.users(id uuid primary key default gen_random_uuid());
create function auth.uid() returns uuid language sql stable as $$ select nullif(current_setting('app.uid',true),'')::uuid $$;
create role anon; create role authenticated; create publication supabase_realtime;`);
const files=['001_forest_rpg','002_multiplayer','003_multiplayer_policy_fix','004_coop_room_world','005_friend_room_join_fix','006_friend_room_owner_membership'];
if(withFix)files.push('007_fix_join_friend_room');
for(const f of files){try{await db.exec(readFileSync(dir+f+'.sql','utf8'))}catch(e){console.log('MIGRATION FAIL',f,e.message)}}
const q=async(sql)=>(await db.query(sql)).rows, as=u=>db.exec(`select set_config('app.uid','${u}',false)`);
const nu=async()=> (await q(`insert into auth.users default values returning id`))[0].id;
const A=await nu(),B=await nu(),C=await nu();
for(const [x,y] of [[A,B],[B,A],[A,C],[C,A]])await db.exec(`insert into game_friends values('${x}','${y}')`);
let pass=0,fail=0;const ok=(c,m)=>{console.log((c?'PASS ':'FAIL ')+m);c?pass++:fail++};
const err=async(f)=>{try{await f();return null}catch(e){return e.message}};
await as(A);const ra=(await q(`select * from game_create_room('A')`))[0];
// 1. B owns its own room, then joins A  (the broken case)
await as(B);await q(`select * from game_create_room('B')`);
let r;let e=await err(async()=>{r=await q(`select * from game_join_friend_room('${A}')`)});
ok(!e&&r?.[0]?.room_id===ra.room_id,'joiner who already owns a room gets the OWNER room_id '+(e||''));
let mem=await q(`select room_id,user_id from game_room_members order by user_id`);
ok(mem.length===2&&mem.every(m=>m.room_id===ra.room_id),'both players are members of the same room');
ok((await q(`select count(*)::int c from game_rooms where is_open`))[0].c===1,"joiner's old empty room was closed");
// 2. idempotent retry
await as(B);e=await err(async()=>{r=await q(`select * from game_join_friend_room('${A}')`)});
ok(!e&&r[0].room_id===ra.room_id,'retry is idempotent '+(e||''));
// 3. list friend rooms (heartbeat)
await as(B);let l=await q(`select * from game_list_friend_rooms()`);
ok(l.length===1&&l[0].owner_id===A&&l[0].member_count===2,'friend room list shows A with 2 members');
// 4. owner leaves => closed, nobody can join
await as(A);await q(`select game_leave_room()`);
await as(C);e=await err(()=>q(`select * from game_join_friend_room('${A}')`));
ok(!!e,'joining a closed room is refused: '+e);
// 5. stale owner (membership gone but room open)
await as(A);const rb=(await q(`select * from game_create_room('A2')`))[0];
await db.exec(`delete from game_room_members where user_id='${A}'`);
await as(C);e=await err(()=>q(`select * from game_join_friend_room('${A}')`));
ok(!!e&&/ไม่ได้อยู่ในเซิร์ฟเวอร์/.test(e),'owner not in room is refused: '+e);
// 6. full room
await db.exec(`insert into game_room_members values('${rb.room_id}','${A}')`);
const D=await nu(),E_=await nu();await db.exec(`insert into game_friends values('${D}','${A}'),('${E_}','${A}')`);
for(const u of [B,C,D]){await as(u);await q(`select * from game_leave_room()`).catch(()=>{});await q(`select * from game_join_friend_room('${A}')`).catch(x=>console.log('  join err',u.slice(0,4),x.message))}
await as(E_);e=await err(()=>q(`select * from game_join_friend_room('${A}')`));
ok(!!e&&/เต็ม/.test(e),'5th player refused: '+e);
// 7. stale heartbeat hidden from list
await db.exec(`update game_room_members set last_seen=now()-interval '10 minutes' where user_id='${A}'`);
await as(B);l=await q(`select * from game_list_friend_rooms()`);ok(l.length===0,'owner without heartbeat is hidden from the list');
console.log(`\n${pass} passed, ${fail} failed`);
