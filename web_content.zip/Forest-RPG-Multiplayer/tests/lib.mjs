import {createRequire} from 'module';
const require=createRequire(import.meta.url);
export const {chromium}=require('playwright');
export const sleep=ms=>new Promise(r=>setTimeout(r,ms));
export async function newClient(browser,backend,cid,index){
  const ctx=await browser.newContext({viewport:{width:844,height:390},deviceScaleFactor:1});
  const page=await ctx.newPage();
  const log={errors:[],warns:[],pageerrors:[]};
  page.on('console',m=>{const t=m.type();if(t==='error')log.errors.push(m.text().slice(0,300));else if(t==='warning')log.warns.push(m.text().slice(0,300))});
  page.on('pageerror',e=>log.pageerrors.push(String(e).slice(0,300)));
  await ctx.route(u=>!u.href.startsWith('file:')&&!u.href.startsWith('https://esm.sh/'),r=>r.abort());
  await backend.attach(ctx,page,cid);
  await page.goto('file://'+index);
  await page.waitForFunction(()=>typeof state!=='undefined'&&state==='login',null,{timeout:10000});
  return {cid,ctx,page,log};
}
export const ev=(c,fn,arg)=>c.page.evaluate(fn,arg);
export async function signup(c,id,pin='123456'){
  await c.page.fill('#uid',id);await c.page.fill('#pin',pin);await c.page.click('#bn');
  await c.page.waitForFunction(()=>state==='server',null,{timeout:15000});
  c.id=id;c.uid=await ev(c,()=>sbUser.id);
}
export async function waitPlay(c,timeout=30000){
  await c.page.waitForFunction(()=>state==='play'||(document.getElementById('forest-join-loading')?.classList.contains('failed')),null,{timeout});
  return ev(c,()=>({state,failed:document.getElementById('forest-join-loading')?.classList.contains('failed')||false,msg:document.querySelector('#forest-join-loading .forest-join-message')?.textContent||'',srvm:document.getElementById('srvm')?.textContent||''}));
}
export const snap=(c)=>ev(c,()=>({state,roomId:window.__forestMpRoomId||null,owner:window.__forestMpOwnerId||null,auth:!!window.__forestMpIsMapAuthority?.(),rp:Object.keys(rp),Pisremote:Object.values(rp).includes(P),frame:__forestLoopFrame,loopErr:window.__forestGameLoopError||null,E:E.length,drops:drops.length}));
// count distinct colours on the game canvas: a flat green screen has 1-2, a rendered scene has many
export async function sceneColors(c){return ev(c,()=>{const cv=document.getElementById('c')||document.querySelector('canvas');const w=cv.width,h=cv.height;const t=document.createElement('canvas');t.width=w;t.height=h;const x=t.getContext('2d');x.drawImage(cv,0,0);const d=x.getImageData(0,0,w,h).data;const set=new Set();for(let i=0;i<d.length;i+=4*7)set.add((d[i]>>3)<<10|(d[i+1]>>3)<<5|(d[i+2]>>3));return set.size})}
