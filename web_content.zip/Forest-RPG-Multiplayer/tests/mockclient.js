// Mock of @supabase/supabase-js served to the page in place of esm.sh. All data/realtime lives in the Node backend.
const CID=window.__CID;
const call=(op,args)=>window.__mockCall(CID,op,args);
const chans=new Map();
window.__mockRecv=m=>{
  const ch=chans.get(m.ch);if(!ch)return;
  if(m.kind==='broadcast'){(ch.bc[m.event]||[]).forEach(cb=>{try{cb({payload:m.payload,event:m.event,type:'broadcast'})}catch(e){console.error('mock bc cb',e)}})}
  else if(m.kind==='presence'){ch.pres=m.state;(ch.pr.sync||[]).forEach(cb=>{try{cb()}catch(e){console.error('mock pr cb',e)}})}
  else if(m.kind==='pg'){ch.pg.forEach(p=>{if(p.filter.table===m.table&&(p.filter.event==='*'||p.filter.event===m.event)&&(!p.filter.filter||p.filter.filter===m.filterKey)){try{p.cb({eventType:m.event,new:m.new||{},old:{}})}catch(e){console.error('mock pg cb',e)}}})}
};
class Ch{
  constructor(name,cfg){this.name=name;this.cfg=cfg||{};this.bc={};this.pr={};this.pg=[];this.pres={};this.closed=false}
  on(type,filter,cb){if(type==='postgres_changes')this.pg.push({filter,cb});else if(type==='broadcast')(this.bc[filter.event]=this.bc[filter.event]||[]).push(cb);else if(type==='presence')(this.pr[filter.event]=this.pr[filter.event]||[]).push(cb);return this}
  subscribe(cb){chans.set(this.name,this);call('chan.join',{name:this.name,key:this.cfg?.config?.presence?.key||CID,pg:this.pg.map(p=>({table:p.filter.table,filter:p.filter.filter||''}))}).then(r=>{if(this.closed)return;cb&&cb(r&&r.ok?'SUBSCRIBED':'CHANNEL_ERROR',r&&r.err?{message:r.err}:undefined)});return this}
  track(p){return call('chan.track',{name:this.name,payload:p}).then(r=>r.ok?'ok':'error')}
  untrack(){return call('chan.untrack',{name:this.name})}
  send(m){return call('chan.send',{name:this.name,event:m.event,payload:m.payload}).then(r=>{if(!r.ok)throw new Error(r.err||'send failed');return 'ok'})}
  presenceState(){return this.pres}
}
function builder(table){
  const q={table,op:'select',cols:'*',filters:[],order:[],limit:null,single:null,values:null};
  const run=()=>call('from',q).then(r=>{if(r.error&&!r.error.message)r.error=null;return r});
  const b={
    select(c){q.cols=c||'*';return b},eq(c,v){q.filters.push({t:'eq',c,v});return b},in(c,v){q.filters.push({t:'in',c,v});return b},
    order(c,o){q.order.push({c,asc:!(o&&o.ascending===false)});return b},limit(n){q.limit=n;return b},
    maybeSingle(){q.single='maybe';return b},single(){q.single='single';return b},
    update(v){q.op='update';q.values=v;return b},insert(v){q.op='insert';q.values=v;return b},upsert(v,o){q.op='upsert';q.values=v;q.onConflict=o&&o.onConflict;return b},
    then(res,rej){return run().then(res,rej)}
  };return b;
}
export function createClient(url,key,opts){
  const eps=opts?.realtime?.params?.eventsPerSecond??10;
  window.__mockHello(CID,eps);
  return {
    auth:{
      async signUp({email,password,options}){const r=await call('auth.signUp',{email,password,meta:options?.data});return r.error?{data:{user:null,session:null},error:r.error}:{data:{user:{id:r.id},session:{user:{id:r.id}}},error:null}},
      async signInWithPassword({email,password}){const r=await call('auth.signIn',{email,password});return r.error?{data:{user:null},error:r.error}:{data:{user:{id:r.id},session:{user:{id:r.id}}},error:null}},
      async signOut(){await call('auth.signOut',{});return {error:null}},
      async getSession(){const r=await call('auth.getSession',{});return {data:{session:r.id?{user:{id:r.id}}:null},error:null}}
    },
    from:builder,
    rpc(name,args){return call('rpc',{name,args:args||{}}).then(r=>{if(r.error&&!r.error.message)r.error=null;return r})},
    channel(name,cfg){return new Ch(name,cfg)},
    async removeChannel(ch){ch.closed=true;chans.delete(ch.name);await call('chan.leave',{name:ch.name});return 'ok'}
  };
}
