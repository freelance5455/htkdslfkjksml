import {chromium,newClient,signup,waitPlay,snap,sceneColors,sleep,ev} from './lib.mjs';
import {createBackend} from './backend.mjs';
const index=process.argv[2]||'/home/claude/work/Forest-RPG-Multiplayer/index.html';
const fix=process.argv[3]!=='nofix';
const be=await createBackend({fix});
const browser=await chromium.launch();
const res=[];const T=(n,c,d='')=>{res.push([n,!!c]);console.log((c?'PASS ':'FAIL ')+n+(d?'  -> '+d:''))};
const A=await newClient(browser,be,'A',index),B=await newClient(browser,be,'B',index);
await signup(A,'alice01');await signup(B,'bobby02');
// 1 owner creates room + plays
await A.page.click('#srvcreate');let r=await waitPlay(A);
let sa=await snap(A);T('1 เจ้าของสร้างห้องและเข้าเล่น',r.state==='play'&&sa.auth&&sa.roomId,JSON.stringify(r.srvm||sa.roomId));
// B first creates own room (the normal situation that broke the join RPC), then goes back
await B.page.click('#srvcreate');await waitPlay(B);
await ev(B,()=>forestBackToServers());await B.page.waitForFunction(()=>state==='server');
// 2 friend request
await ev(B,()=>document.getElementById('bf').click());await B.page.fill('#mp-friendid','alice01');await B.page.click('#mp-send');await sleep(600);
await ev(A,()=>document.getElementById('bf').click());await sleep(800);
const acc=await A.page.$('[data-accept]');T('2 เพื่อนส่งคำขอ และเจ้าของเห็นคำขอ',!!acc);
if(acc){await acc.click();await sleep(600)}
await ev(A,()=>document.getElementById('mp-close').click());await ev(B,()=>document.getElementById('mp-close').click());
// 3 B joins A through the friend-room list
await B.page.waitForFunction(()=>document.querySelector('#srvfriendrooms button'),null,{timeout:15000}).catch(()=>{});
const btn=await B.page.$('#srvfriendrooms button');T('3a ห้องเพื่อนขึ้นในรายการ',!!btn);
await btn.click();r=await waitPlay(B);
let sb=await snap(B);sa=await snap(A);
T('3b เพื่อนเข้าห้องเดียวกับเจ้าของจริง (room_id ตรงกัน)',r.state==='play'&&sb.roomId&&sb.roomId===sa.roomId&&sb.owner===A.uid&&!sb.auth,r.msg||r.srvm);
await sleep(2500);sb=await snap(B);sa=await snap(A);
T('4 ทั้งสองมองเห็นกัน',sa.rp.includes('sb-'+B.uid)&&sb.rp.includes('sb-'+A.uid),JSON.stringify([sa.rp.length,sb.rp.length]));
// 5 walking
await ev(B,()=>{keys.d=1});await sleep(1500);await ev(B,()=>{keys.d=0});await sleep(900);
const pos=await ev(B,()=>({x:P.x,y:P.y}));const seen=await ev(A,uid=>{const r=rp['sb-'+uid];return r?{x:r.x,y:r.y,tx:r.tx}:null},B.uid);
T('5 เดินแล้วตำแหน่งตรงกัน',seen&&Math.abs(seen.x-pos.x)<4&&Math.abs(seen.y-pos.y)<4,JSON.stringify({pos,seen}));
// 6 attack -> hp sync (B stands next to a monster of the authority)
const mon=await ev(A,()=>{const e=E[0];e.hp=e.max=60;e.sp=0;e.id=e.id||'m-test';return {id:e.id,x:e.x,y:e.y}});
await ev(B,m=>{P.x=m.x-26;P.y=m.y;P.dx=1;P.dy=0;P.st=100;P.tl=P.tl&&P.tl.length?P.tl:[];},mon);await sleep(700);
await ev(B,()=>{attack()});await sleep(1500);
const hpA=await ev(A,id=>E.find(e=>e.id===id)?.hp,mon.id),hpB=await ev(B,id=>E.find(e=>e.id===id)?.hp,mon.id);
T('6 โจมตีมอนสเตอร์ HP ลดและตรงกันทั้งสองเครื่อง',hpA<60&&hpA===hpB,`A=${hpA} B=${hpB}`);
// 7 kill -> drops identical
await ev(A,id=>{const e=E.find(x=>x.id===id);e.hp=1},mon.id);
await ev(B,m=>{P.x=m.x-20;P.y=m.y;P.dx=1;P.dy=0;P.st=100},mon);await sleep(600);
await ev(B,()=>{attack()});await sleep(500);await ev(A,()=>{P.x=100;P.y=100});await ev(B,()=>{P.x=120;P.y=100});await sleep(1500);
const goneA=await ev(A,id=>!E.some(e=>e.id===id),mon.id),goneB=await ev(B,id=>!E.some(e=>e.id===id),mon.id);
const dA=await ev(A,()=>drops.filter(d=>d.shared).map(d=>d.id+'@'+Math.round(d.x)+','+Math.round(d.y)).sort());
const dB=await ev(B,()=>drops.filter(d=>d.shared).map(d=>d.id+'@'+Math.round(d.x)+','+Math.round(d.y)).sort());
console.log('   dA',dA,'dB',dB);T('7 ฆ่ามอนสเตอร์: ตายทั้งคู่ + ของดรอปเหมือนกัน',goneA&&goneB&&JSON.stringify(dA)===JSON.stringify(dB),`A=${dA.length} B=${dB.length}`);
// 8 loot race
const inv=c=>ev(c,()=>(P.bone|0)+(P.jel|0)+(P.pot|0));
await ev(A,()=>{drops=drops.filter(d=>!d.shared);drops.push({x:P.x+400,y:P.y,k:'bone',shared:true,id:'race-1'},{x:P.x+400,y:P.y+60,k:'jel',shared:true,id:'race-2'})});await sleep(700);
const [a0,b0]=[await inv(A),await inv(B)];
const dd=await ev(A,()=>drops.filter(d=>d.id&&d.id.startsWith('race')).map(d=>({id:d.id,x:d.x,y:d.y})));
// both players stand on race-1 at the same moment; B alone reaches race-2
await ev(A,d=>{P.x=d[0].x;P.y=d[0].y},dd);await ev(B,d=>{P.x=d[0].x;P.y=d[0].y},dd);await sleep(1500);
await ev(B,d=>{P.x=d[1].x;P.y=d[1].y},dd);await sleep(1500);
const [a1,b1]=[await inv(A),await inv(B)];
const left=await ev(A,()=>drops.filter(d=>d.id&&d.id.startsWith('race')).length),leftB=await ev(B,()=>drops.filter(d=>d.id&&d.id.startsWith('race')).length);
T('8 แย่งเก็บไอเทม ไม่ได้ของซ้ำ (รวม +2 พอดี, หายจากพื้นทั้งคู่)',(a1-a0)+(b1-b0)===2&&left===0&&leftB===0,`dA=${a1-a0} dB=${b1-b0} left=${left}/${leftB}`);
// 9/10 leave / rejoin repeatedly
let okLoop=true,detail=[];
for(let i=0;i<5;i++){
  await ev(B,()=>forestBackToServers());await B.page.waitForFunction(()=>state==='server',null,{timeout:15000});
  await sleep(400);
  await B.page.waitForFunction(()=>document.querySelector('#srvfriendrooms button'),null,{timeout:15000}).catch(()=>{});
  const b=await B.page.$('#srvfriendrooms button');if(!b){okLoop=false;detail.push('no button '+i);break}
  await b.click();const rr=await waitPlay(B);await sleep(1200);
  const s1=await snap(B),s0=await snap(A);const col=await sceneColors(B);
  const ok=rr.state==='play'&&s1.roomId===s0.roomId&&!s1.Pisremote&&col>40&&s0.rp.includes('sb-'+B.uid);
  if(!ok){okLoop=false;detail.push(JSON.stringify({i,rr,s1,col}))}
}
T('9/10 ออก-เข้าห้องซ้ำ 5 รอบ ไม่ค้าง/ไม่จอเขียว/ห้องเดิม',okLoop,detail.join(' | '));
// owner leaves too and re-enters own room
await ev(A,()=>forestBackToServers());await A.page.waitForFunction(()=>state==='server');
await A.page.waitForFunction(()=>true);
await A.page.click('#srvcreate');r=await waitPlay(A);const s2=await snap(A);
T('9b เจ้าของกลับหน้าเซิร์ฟเวอร์แล้วเข้าห้องเดิมใหม่ได้',r.state==='play'&&s2.roomId===sb.roomId,r.srvm||r.msg);
await sleep(2500);const s3=await snap(B);
T('9c หลังเจ้าของกลับเข้า (seq รีเซ็ต) เพื่อนยังเห็นมอนสเตอร์/ผู้เล่นอัปเดต',s3.rp.includes('sb-'+A.uid));
const mv0=await ev(A,()=>({x:P.x}));await ev(A,()=>{keys.d=1});await sleep(1200);await ev(A,()=>{keys.d=0});await sleep(800);
const mv1=await ev(A,()=>P.x),seenA=await ev(B,u=>rp['sb-'+u]?.x,A.uid);
T('9d เจ้าของเดินหลังกลับเข้าห้อง เพื่อนเห็นตรงกัน',Math.abs(mv1-seenA)<4&&mv1>mv0.x+20,`${mv0.x}->${mv1} seen ${seenA}`);
// failure path: owner offline (leaves channel) while B tries
await ev(B,()=>forestBackToServers());await B.page.waitForFunction(()=>state==='server');
await ev(A,()=>window.__forestMpLeaveChannel());await sleep(500);
await B.page.waitForFunction(()=>document.querySelector('#srvfriendrooms button'),null,{timeout:15000}).catch(()=>{});
const b2=await B.page.$('#srvfriendrooms button');
if(b2){await b2.click();r=await waitPlay(B,40000);
 const vis=await ev(B,()=>({retry:getComputedStyle(document.querySelector('.fj-retry')).display,back:getComputedStyle(document.querySelector('.fj-back')).display,st:state}));
 T('10 เจ้าของออฟไลน์: แจ้งสาเหตุ + ปุ่มลองใหม่/กลับ ไม่จอเขียว',r.failed&&vis.retry!=='none'&&vis.st==='server',r.msg.slice(0,90));
 await ev(B,()=>document.querySelector('.fj-back').click());
}else T('10 เจ้าของออฟไลน์',false,'room list empty');
console.log('\nrealtime msgs sent',be.stats.sent,'dropped by rate limit',be.stats.dropped);
console.log('page errors A',A.log.pageerrors.slice(0,3),'B',B.log.pageerrors.slice(0,3));
console.log('console errors B',B.log.errors.slice(0,4));
console.log(`\n${res.filter(x=>x[1]).length}/${res.length} passed`);
await browser.close();await be.close();
