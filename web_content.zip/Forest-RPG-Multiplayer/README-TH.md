# Forest RPG — เชื่อม Supabase

## ไฟล์
- `index.html` — เกมเดิมที่แก้ระบบบัญชี/เซฟให้ใช้ Supabase โดยคงระบบเกมเดิม
- `supabase/migrations/001_forest_rpg.sql` — ตาราง, RLS, column grants
- `supabase/functions/admin-api/index.ts` — Backend นับบัญชี/ออนไลน์ เฉพาะ Admin
- `README-TH.md` — คู่มือนี้

## ก่อนใช้งาน
Publishable Key ไม่ได้อยู่ในไฟล์แนบที่ได้รับ จึงเว้น `ใส่_PUBLISHABLE_KEY_ที่นี่` ไว้ให้ใส่เอง:
1. เปิด Supabase Dashboard → Project Settings → API.
2. คัดลอก **Publishable key** (หรือ legacy anon public key).
3. เปิด `index.html` แล้วแทนข้อความ `ใส่_PUBLISHABLE_KEY_ที่นี่` ด้วยคีย์ดังกล่าว.
4. ห้ามนำ Secret Key หรือ Service Role Key มาใส่ใน HTML.

## 1. ตั้งค่า Auth ให้ Game ID + PIN ใช้ได้
เกมนี้แปลง Game ID เป็นอีเมลภายในรูปแบบ `u-...@players.forestrpg.invalid` เพื่อให้ใช้ Supabase Auth โดยไม่ต้องขออีเมลจากผู้เล่นจริง
- Supabase Dashboard → Authentication → Providers → Email.
- เปิด Email provider.
- ปิด Confirm email (บัญชีเกมใช้ Game ID ไม่ใช่อีเมลรับจดหมาย).
- ตั้ง minimum password length อย่างน้อย 6.
PIN จึงต้องยาวอย่างน้อย 6 ตัว. อย่าใช้ PIN ที่ใช้กับบัญชีอื่น.

## 2. สร้างตาราง
- เปิด SQL Editor ในโปรเจกต์ `zzkjhkyipnukmybikicw`.
- วางเนื้อหาจาก `supabase/migrations/001_forest_rpg.sql` แล้ว Run.
- RLS และสิทธิ์คอลัมน์จะป้องกันไม่ให้ผู้เล่นแก้ `game_id`, `is_banned` หรือข้อมูลผู้เล่นคนอื่นได้.

## 3. เปิดเกม
โฮสต์ `index.html` ผ่าน HTTPS หรือ localhost (ไม่แนะนำเปิดเป็น `file://` เพราะ dynamic import และ Auth อาจถูกบล็อก).
ผู้เล่นเลือก Game ID + PIN:
- สร้างไอดีใหม่ → Supabase Auth signUp และสร้าง `game_profiles`.
- เข้าสู่ระบบ → Supabase Auth signIn แล้วโหลด `game_state`.
- ระบบเซฟเดิม `snap()` / `apply()` ยังใช้โครงสร้างตัวละครเดิม: เลเวล, EXP, HP, เงิน, ไอเทม, อุปกรณ์, เควสต์, จำนวนมอนสเตอร์ที่กำจัด, สิ่งปลูกสร้าง และแผนที่.
- การเซฟจะอัปเดต `game_profiles.game_state` แบบหน่วงสั้น ๆ; Local Storage ใช้เป็น cache เท่านั้น ไม่ใช่แหล่งบัญชีหลัก.
- Heartbeat ส่งทุก 25 วินาที; สถานะออนไลน์นับเมื่อ heartbeat ภายใน 90 วินาที. ถ้าปิดแอปทันที request ออฟไลน์อาจส่งไม่ทัน แต่สถานะจะหมดอายุเองภายใน 90 วินาที.

## 4. นับจำนวนบัญชีและออนไลน์ (Admin เท่านั้น)
Deploy Edge Function:
```bash
supabase login
supabase link --project-ref zzkjhkyipnukmybikicw
supabase secrets set SUPABASE_URL=https://zzkjhkyipnukmybikicw.supabase.co
supabase secrets set SUPABASE_ANON_KEY=YOUR_PUBLISHABLE_OR_ANON_KEY
supabase secrets set SUPABASE_SERVICE_ROLE_KEY=YOUR_SERVICE_ROLE_SECRET
supabase functions deploy admin-api
```
Service Role Key ใช้เฉพาะเป็น Edge Function Secret เท่านั้น. ห้ามใส่ใน HTML, Git หรือ client.
สร้างผู้ใช้เจ้าของเกมที่ Authentication → Users แล้วคัดลอก UUID จากนั้น SQL:
```sql
insert into public.admin_users(user_id)
values ('ใส่-AUTH-USER-UUID')
on conflict do nothing;
```
Edge Function ตรวจ JWT และตรวจ `admin_users` ก่อนนับบัญชี/ผู้เล่นออนไลน์. ผู้เล่นทั่วไปเรียกแล้วจะได้ 403.

## 5. ทดสอบ
1. สมัคร Game ID ใหม่ที่ไม่เคยใช้ + PIN 6 หลักขึ้นไป.
2. ตรวจ Table Editor → `game_profiles` ว่ามีแถวใหม่และ `game_id` ตรงกัน.
3. เข้าเกม เก็บของ/เพิ่มเลเวล/เปลี่ยนเงิน แล้วรอให้เซฟ (ประมาณ 1 วินาที).
4. ตรวจ `game_state` ว่ามีข้อมูล JSON เปลี่ยน.
5. ออกจากระบบ แล้วล็อกอิน Game ID เดิมจากอีกอุปกรณ์หนึ่ง; ตัวละครควรโหลดจากฐานข้อมูล.
6. ตรวจ `game_sessions` ว่า `last_heartbeat` เปลี่ยนทุก 25 วินาที.
7. ปิดเกมและรอ 90 วินาที; Dashboard/Admin stats จะไม่นับ session ที่ heartbeat หมดอายุ.
8. ทดสอบ RLS ด้วยบัญชีผู้เล่น: query profile คนอื่น / admin_users ต้องไม่สำเร็จ.

## ข้อจำกัด / สิ่งที่ยังต้องทำกับโปรเจกต์จริง
- ผมตรวจและแก้ source code ในไฟล์นี้ได้ แต่ไม่สามารถล็อกอินเข้า Supabase โปรเจกต์ของคุณเพื่อ deploy หรือสร้างบัญชีทดสอบจริงแทนคุณได้.
- ยังไม่ได้รัน browser E2E กับโปรเจกต์จริง เพราะต้องใช้ Publishable Key, การตั้งค่า Auth และการ deploy ที่เจ้าของโปรเจกต์ควบคุม.
- ระบบ PIN เดิมที่อยู่เฉพาะ Local Storage ไม่สามารถย้ายเป็น Supabase Auth โดยอัตโนมัติ; ผู้เล่นต้องสมัครบัญชีบนระบบใหม่นี้. ฟีเจอร์นำเข้าโค้ดเซฟเดิมยังคงอยู่เพื่อย้ายตัวละครหลังล็อกอิน.
- Game ID ถูกแปลงเป็น synthetic email แบบ deterministic. ไม่ต้องมีอีเมลจริง แต่ผู้เล่นต้องจำ Game ID และ PIN ให้ถูกต้อง.
- ระบบเพื่อน/เซิร์ฟเวอร์เดิมของเกมยังคงอยู่ แต่ backend ของระบบเพื่อนที่เดิมพึ่งพาสภาพแวดล้อมเดิมอาจมีข้อจำกัดแยกต่างหาก; การบันทึกตัวละครและบัญชีหลักย้ายไป Supabase แล้ว.
