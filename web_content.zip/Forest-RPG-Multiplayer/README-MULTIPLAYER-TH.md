# Forest RPG Multiplayer v1 — Thai

แพ็กเกจนี้ต่อจาก Forest-RPG-GameID-PIN.zip โดยคงบัญชี Game ID + PIN และระบบเซฟเดิมไว้

## สิ่งที่มีในรุ่นนี้
- หน้าต่าง Multiplayer ในเกม: ปุ่ม “เพื่อน / Multiplayer”
- ส่งคำขอเป็นเพื่อนด้วย Game ID และยอมรับ/ปฏิเสธคำขอ
- สร้างห้องและเข้าห้องด้วยรหัส
- จำกัดสมาชิกสูงสุด 4 คนรวมเจ้าของห้อง
- แสดงสมาชิกห้องและอัปเดตสมาชิกผ่าน Supabase Realtime

## SQL ที่ต้องทำ
คุณได้รัน `002_multiplayer.sql` แล้วและเห็นตารางครบ ให้รันไฟล์เพิ่มอีกไฟล์เดียว:
`supabase/migrations/003_multiplayer_policy_fix.sql`

ไฟล์นี้แก้ policy การอ่านสมาชิกห้องเพื่อหลีกเลี่ยง RLS recursion ที่อาจเกิดจาก policy อ้างตารางสมาชิกซ้ำ

## วิธีนำไปใช้กับ html2app.dev
1. สำรองโปรเจกต์/Build เดิมไว้ก่อน ห้ามลบ APK เดิมหรือข้อมูลเซฟ
2. ใช้ `index.html` ในโฟลเดอร์นี้แทนไฟล์หน้าเกมเดิมในโปรเจกต์ html2app
3. Build APK ใหม่ด้วย Package ID และ signing key เดิม หากต้องการอัปเดตทับแอปเดิม
4. ทดสอบด้วยบัญชี 2 เครื่องก่อน แล้วค่อยทดสอบครบ 4 บัญชี

## ข้อจำกัดที่ต้องทราบ
รุ่นนี้เชื่อมระบบเพื่อนและห้องกับ Supabase แล้ว แต่ยังไม่ใช่ co-op gameplay เต็มรูปแบบ: ยังไม่ได้ซิงก์ตำแหน่งตัวละครลงแผนที่จริง, inventory ที่เก็บร่วมกัน, การคำนวณดาเมจ หรือ HP/การตายของมอนสเตอร์ร่วมกัน เพราะต้องผูกกับระบบ movement, item pickup และ combat ภายในเกมต้นฉบับเพิ่มเติม และทดสอบหลายเครื่องก่อน

## ความปลอดภัย
- ใน HTML ใช้เฉพาะ Supabase Publishable Key
- ห้ามใส่ Service Role Key หรือ secret ใน APK
- การเพิ่มเพื่อน/สร้างห้อง/เข้าห้อง/ออกห้องทำผ่าน RPC ที่ตรวจ auth.uid() ฝั่งฐานข้อมูล


## Multiplayer v3: ซิงก์ตัวละครผ่าน Supabase
- ผู้เล่นในห้อง Supabase เดียวกันจะส่งตำแหน่ง/ทิศทาง/ท่าทางผ่าน Realtime Broadcast และเห็นตัวละครกันในแผนที่
- Presence ใช้ตรวจผู้เล่นที่ออนไลน์ในช่องห้องเดียวกัน
- ระบบไอเทมร่วมกันและเลือด/มอนสเตอร์ร่วมกันยังไม่รวมในรุ่นนี้
- หลังเปลี่ยนไฟล์ HTML ต้องสร้าง APK ใหม่จากไฟล์นี้; APK เก่าจะไม่เปลี่ยนเอง

## Multiplayer monster sync + landscape update
- The room owner is the authoritative source for monster positions, HP, spawns, and removals. Monster snapshots are broadcast to room members through Supabase Realtime.
- Attacks from non-owner players are sent to the room owner so monster HP changes are applied to the shared monster state.
- The HTML requests fullscreen and `screen.orientation.lock('landscape')` after the first user interaction where supported.
- For APK builders that control native orientation, set the app / Activity orientation to **Landscape** in the builder settings as well. HTML cannot override a native WebView orientation lock imposed by the APK wrapper.


## Co-op A: ช่วยกันตีมอนสเตอร์ (รุ่นปรับปรุง)
1. รัน SQL เพิ่ม `supabase/migrations/004_coop_room_world.sql` หลังไฟล์ 002 และ 003 โดยไม่ต้องลบตารางหรือข้อมูลเดิม
2. หัวห้องเป็นผู้จำลองมอนสเตอร์และบันทึกสถานะมอนสเตอร์ลง `game_world_state`
3. สมาชิกส่งคำสั่งโจมตีไปยังหัวห้อง แล้วรับสถานะ HP/ตำแหน่ง/การเกิดใหม่ผ่าน Realtime และข้อมูลสำรองจากฐานข้อมูล
4. เลเวล อาวุธ ชุดเกราะ กระเป๋า และเซฟตัวละครยังแยกตามบัญชีผู้เล่น; สมาชิกที่ได้รับเหตุการณ์มอนสเตอร์ตายจะได้ XP/ทอง/ดรอปของตัวเอง
5. การซิงก์นี้ต้องทดสอบบนอุปกรณ์จริง 2 เครื่องขึ้นไปก่อนเปิดใช้จริง; หัวห้องต้องออนไลน์ระหว่างเล่น

หมายเหตุ: รุ่นนี้ยังไม่ใช่เซิร์ฟเวอร์ dedicated และการโจมตี/การซิงก์มอนสเตอร์พึ่งหัวห้องเป็นหลัก หากหัวห้องหลุด ห้องจะไม่ย้ายเจ้าของอัตโนมัติ

## V11.1 – สิ่งก่อสร้างร่วมกันและเข้าใช้งานบ้าน
- เพิ่มการซิงก์บ้าน กองไฟ ท่อนไฟ ต้นอ่อน และเฟอร์นิเจอร์ภายในบ้านผ่าน Supabase Realtime ในห้องเดียวกัน
- ข้อมูลสิ่งก่อสร้างแยกตามแมพภายใน `game_world_state.world.buildings` และบันทึกผ่าน RPC `game_publish_room_world` เดิม จึงไม่ต้องเพิ่มตารางหรือรัน migration ใหม่
- ผู้เล่นในห้องเดียวกันเห็นเฟอร์นิเจอร์ที่วาง/ทุบ และเห็นผู้เล่นที่อยู่ในบ้านเดียวกัน
- ซิงก์สถานะนั่งเก้าอี้และตำแหน่งผู้เล่นในบ้านผ่าน presence/broadcast
- เมื่อสลับแมพ จะโหลดชุดสิ่งก่อสร้างของแมพนั้นเท่านั้น ไม่ยกสิ่งก่อสร้างจากแมพก่อนหน้าตามไป

หมายเหตุ: ทดสอบตรวจไวยากรณ์ JavaScript และโครงสร้าง ZIP แล้ว แต่ยังต้องทดสอบเล่นจริงอย่างน้อย 2 บัญชี/2 เครื่อง เพื่อยืนยัน Realtime, การบันทึกถาวร และการเข้า-ออกบ้านพร้อมกัน
