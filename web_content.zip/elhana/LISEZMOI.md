# El Hana · Application Android synchronisée avec le PC

Le **même fichier `www/index.html`** sert au programme Windows (Electron) et à l'application Android.
Toutes les fonctions sont donc disponibles sur le téléphone : caisse, stock, entrées et sorties, inventaire, scanner, articles et prix.

## Comment fonctionne la synchronisation

- Chaque modification devient une petite opération (ex. « Riz : −3 », « Sucre : prix 3,600 », « ticket ajouté »).
- **Hors-ligne :** les opérations sont gardées sur l'appareil, puis envoyées automatiquement au retour du réseau.
- **En ligne :** les autres appareils les reçoivent en quelques secondes. Ils sont prévenus en temps réel, et vérifient de toute façon toutes les 15 s.
- **Stock :** les mouvements s'additionnent. Si le PC vend 2 Riz et le téléphone 3 Riz pendant une coupure, le stock final est −5 sur les deux.
- **Articles, prix de vente, inventaire :** si le même article est modifié sur deux appareils, la modification la plus récente gagne.
- **Restent propres à chaque appareil :** thème, apparence, réglages de l'imprimante, tickets en attente.
- **Numéros de ticket :** le PC (poste 0) continue sa numérotation. Le téléphone poste 1 commence à 100001, le poste 2 à 200001, etc. Il n'y a donc jamais de doublon.
- Un point de couleur en haut de l'écran indique l'état : vert = à jour, orange = envoi en attente, gris = hors-ligne, rouge = erreur. Touchez-le pour ouvrir les Paramètres.

---

## Étape 1 · Créer le serveur Supabase (gratuit, environ 10 minutes)

1. Créez un compte sur **supabase.com**, puis un projet (« New project »). Choisissez la région la plus proche, par exemple Europe (Frankfurt ou Paris).
2. Menu **SQL Editor** → **New query** → collez tout le contenu de `supabase/schema.sql` → **Run**.
3. Menu **Authentication → Users → Add user → Create new user** : entrez l'e-mail et le mot de passe du magasin, et cochez **Auto Confirm User**.
   Ce compte unique sera utilisé par le PC et tous les téléphones.
4. Menu **Project Settings → API** : notez l'**URL du projet** (`https://xxxx.supabase.co`) et la clé **anon public**.

> Astuce : pour ne pas retaper l'adresse et la clé sur chaque appareil, ajoutez cette ligne au début de `www/index.html`, juste après `<head>` :
> `<script>window.ELHANA_SYNC_DEFAULTS={url:'https://xxxx.supabase.co',anonKey:'eyJ...'}</script>`
> La clé anon est faite pour être publique. Vos données restent protégées par l'e-mail et le mot de passe du magasin.

## Étape 2 · Programme Windows (à faire en premier)

1. Dans l'ancienne version, faites **Paramètres → Exporter JSON** pour garder une sauvegarde.
2. Dans votre projet Electron, remplacez votre `index.html` par `www/index.html`, puis refaites le `.exe` comme d'habitude (par exemple `npm run build` / electron-builder).
3. Ouvrez le programme → **Paramètres → Synchronisation PC ⇄ téléphone**. Remplissez l'adresse, la clé, l'e-mail et le mot de passe, le nom (« PC caisse ») et le **poste 0** → **Connecter cet appareil**.
   → Le PC est le premier appareil : il envoie tous ses articles, stocks, ventes et l'historique au serveur.

## Étape 3 · Fabriquer l'application Android (APK)

Il faut sur le PC : **Node.js 20 ou plus récent** (nodejs.org) et **Android Studio** (developer.android.com/studio).

Dans ce dossier, ouvrez un terminal :

```bat
npm install
npx cap add android
npm run android:prep
npx cap open android
```

Dans Android Studio : **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
Vous trouverez l'APK dans `android/app/build/outputs/apk/debug/app-debug.apk`. Copiez-le sur le téléphone et installez-le (autorisez « sources inconnues »).

À chaque mise à jour de `www/index.html`, relancez `npm run android:prep`, puis refaites l'APK.

## Étape 4 · Connecter le téléphone

Ouvrez l'application → menu → **Paramètres → Synchronisation**. Entrez la même adresse, la même clé, l'e-mail et le mot de passe du magasin, un nom (« Téléphone Jamel ») et le **poste 1** (2 pour un deuxième téléphone…) → **Connecter cet appareil** → acceptez.
Le téléphone reçoit toutes les données du magasin et redémarre.

---

## Limites à connaître

- **Impression des tickets sur le téléphone :** l'impression du navigateur ne fonctionne pas dans une application Android. Il faudra plus tard une imprimante Bluetooth et un module dédié. Les ventes sont bien enregistrées et synchronisées.
- **Mémoire du téléphone :** environ 10 Mo, photos comprises. L'application vous prévient déjà quand elle se remplit.
- **« Remettre tous les stocks à zéro »** sur un appareil met tout à zéro chez tous. Les ventes faites hors-ligne ailleurs pendant ce temps seront déduites ensuite.
- **Ne pas connecter deux fois le même appareil comme « premier »** : seul le premier appareil (PC) envoie ses données. Tous les autres les reçoivent.
- **Polices :** sans Internet, l'application utilise la police du système.

## Contenu du dossier

| Élément | Rôle |
|---|---|
| `www/index.html` | votre application + synchronisation (PC et Android) |
| `src/elhana-sync.js` | le code de synchronisation (déjà inclus dans `index.html`) |
| `supabase/schema.sql` | la base de données et sa sécurité |
| `package.json`, `capacitor.config.json`, `scripts/` | projet Android (Capacitor) |
| `outils/build.py` | réinjecte la synchro si vous modifiez votre `index.html` d'origine : `python outils/build.py chemin\index.html` |
| `outils/test/` | test automatique (faux serveur + 2 appareils simulés) |
