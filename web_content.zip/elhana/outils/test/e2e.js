const { chromium } = require('playwright');
const URL = 'http://localhost:8787/app/index.html', API = 'http://localhost:8787';
const sleep = ms => new Promise(r => setTimeout(r, ms));
let fails = 0; const ok = (c, m) => { console.log((c ? '  ✔ ' : '  ✘ ') + m); if (!c) fails++; };
const stats = () => fetch(API + '/__stats').then(r => r.json());

(async () => {
  const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });
  const mk = async (seed) => {
    const ctx = await browser.newContext();
    if (seed) await ctx.addInitScript(() => {
      if (localStorage.getItem('__seed')) return; localStorage.setItem('__seed', '1');
      localStorage.setItem('elhana_liste_prix_v2', JSON.stringify([{ code: '111', nom: 'Riz 1kg', prix: 4.9 }, { code: '222', nom: 'Sucre 1kg', prix: 3.2 }, { code: '', nom: 'Pain', prix: 0.6 }]));
      localStorage.setItem('elhana_stock_v2', JSON.stringify({ '111': 10, '222': 20, Pain: 50 }));
      localStorage.setItem('elhana_pos_v1', JSON.stringify({ extra: { '111': { poids: false, codes: [], cat: 'Épicerie', pv: 5.5 } }, ventes: [], n: 41, park: [], mv: [] }));
    });
    const page = await ctx.newPage();
    const errs = []; page.on('pageerror', e => errs.push(e.message));
    page.on('dialog', d => d.accept());
    await page.goto(URL); await sleep(500);
    return { ctx, page, errs };
  };
  const connectUI = async (p, name, poste) => {
    await p.evaluate(() => showPage('parametres'));
    await p.fill('#elhSU', API); await p.fill('#elhSK', 'anon'); await p.fill('#elhSE', 'elhana@test.tn');
    await p.fill('#elhSP', 'secret'); await p.fill('#elhSN', name); await p.fill('#elhSPo', String(poste));
    await p.click('#elhSGo');
  };
  const state = p => p.evaluate(() => ({ lp: listePrix.map(x => x.nom + '=' + x.prix).sort(), stock, ventes: window.__elhanaPOS.D().ventes.length, n: window.__elhanaPOS.D().n, pv111: (window.__elhanaPOS.D().extra['111'] || {}).pv, hist: historique.length, sync: elhanaSync.status() }));

  console.log('1. PC (premier appareil) se connecte et envoie ses données');
  const A = await mk(true);
  await connectUI(A.page, 'PC caisse', 0); await sleep(2500);
  let s = await stats(); ok(s.count >= 7, 'opérations envoyées au serveur : ' + s.count);
  ok((await state(A.page)).sync.state === 'ok', 'statut PC : ' + (await state(A.page)).sync.msg);

  console.log('2. Téléphone rejoint le magasin');
  const B = await mk(false);
  ok((await state(B.page)).lp.length > 3, 'téléphone neuf : articles de démonstration présents avant connexion');
  await connectUI(B.page, 'Téléphone', 1); await sleep(3000); await B.page.waitForLoadState('load'); await sleep(800);
  let a = await state(A.page), b = await state(B.page);
  ok(JSON.stringify(a.lp) === JSON.stringify(b.lp), 'mêmes articles : ' + b.lp.join(', '));
  ok(JSON.stringify(a.stock) === JSON.stringify(b.stock), 'mêmes stocks : ' + JSON.stringify(b.stock));
  ok(b.pv111 === 5.5, 'prix de vente reçu sur le téléphone');
  ok(b.n === 100000, 'tickets du téléphone numérotés à partir de 100001 (n=' + b.n + ')');
  ok((await stats()).count === s.count, 'le téléphone n\'a renvoyé aucun écho (' + (await stats()).count + ' ops)');

  console.log('3. Les deux hors-ligne : ventes simultanées du même article');
  await A.ctx.setOffline(true); await B.ctx.setOffline(true);
  await A.page.evaluate(() => { stock['111'] -= 2; saveStock(); historique.push({ date: new Date().toISOString(), nom: 'Riz 1kg', code: '111', quantite: 2, prix: 5.5, total: 11, type: 'sortie' }); saveHistorique(); });
  await B.page.evaluate(() => { stock['111'] -= 3; saveStock(); const D = __elhanaPOS.D(); D.ventes.push({ no: ++D.n, d: new Date().toISOString(), s: 16.5, r: 0, t: 16.5, recu: 20, mode: 'Espèces', l: [{ k: '111', n: 'Riz 1kg', q: 3, p: 5.5, a: 4.9, su: 3 }], b: 1.8 }); __elhanaPOS.sv(); });
  await sleep(1500);
  await A.page.evaluate(() => elhanaSync.syncNow()); await sleep(300);
  a = await state(A.page); b = await state(B.page);
  ok(a.sync.queue > 0 && b.sync.queue > 0, `modifications gardées hors-ligne (PC ${a.sync.queue}, tél. ${b.sync.queue}) : ${b.sync.msg}`);
  ok(a.stock['111'] === 8 && b.stock['111'] === 7, 'chaque appareil voit sa propre vente');

  console.log('4. Retour du réseau');
  await A.ctx.setOffline(false); await B.ctx.setOffline(false);
  for (const P of [A, B, A, B]) { await P.page.evaluate(() => elhanaSync.syncNow()); await sleep(900); }
  a = await state(A.page); b = await state(B.page);
  ok(a.stock['111'] === 5 && b.stock['111'] === 5, `stock Riz = 10 − 2 − 3 = 5 sur les deux (PC ${a.stock['111']}, tél. ${b.stock['111']})`);
  ok(a.ventes === 1 && b.ventes === 1, 'la vente du téléphone apparaît sur le PC');
  ok(a.hist === b.hist && a.hist >= 1, 'historique identique (' + a.hist + ' lignes)');
  ok(a.sync.queue === 0 && b.sync.queue === 0, 'files vides');
  const c1 = (await stats()).count; for (const P of [A, B, A]) { await P.page.evaluate(() => elhanaSync.syncNow()); await sleep(500); }
  ok((await stats()).count === c1, 'aucune boucle d\'écho après plusieurs synchros');

  console.log('5. Même article modifié sur les deux appareils : la dernière modification gagne');
  await A.ctx.setOffline(true); await B.ctx.setOffline(true);
  await A.page.evaluate(() => { listePrix.find(p => p.code === '222').prix = 3.4; saveListePrix(); });
  await sleep(50);
  await B.page.evaluate(() => { listePrix.find(p => p.code === '222').prix = 3.6; saveListePrix(); });
  await sleep(1200); await A.ctx.setOffline(false); await B.ctx.setOffline(false);
  for (const P of [A, B, A, B]) { await P.page.evaluate(() => elhanaSync.syncNow()); await sleep(900); }
  a = await state(A.page); b = await state(B.page);
  ok(a.lp.includes('Sucre 1kg=3.6') && b.lp.includes('Sucre 1kg=3.6'), 'prix Sucre = 3,600 partout');

  console.log('6. Nouvel article ajouté sur le téléphone, supprimé ensuite sur le PC');
  await B.page.evaluate(() => { listePrix.push({ code: '333', nom: 'Thé 100g', prix: 2.1 }); saveListePrix(); stock['333'] = 12; saveStock(); });
  await sleep(1200); await B.page.evaluate(() => elhanaSync.syncNow()); await A.page.evaluate(() => elhanaSync.syncNow()); await sleep(800);
  a = await state(A.page);
  ok(a.lp.includes('Thé 100g=2.1') && a.stock['333'] === 12, 'article et stock reçus sur le PC');
  const shown = await A.page.evaluate(() => { showPage('liste-prix'); return document.getElementById('page-liste-prix').innerText.includes('Thé 100g'); });
  ok(shown, 'affiché dans la liste des articles du PC sans recharger');
  await A.page.evaluate(() => { listePrix = listePrix.filter(p => p.code !== '333'); saveListePrix(); });
  await sleep(1200); await A.page.evaluate(() => elhanaSync.syncNow()); await B.page.evaluate(() => elhanaSync.syncNow()); await sleep(800);
  b = await state(B.page); ok(!b.lp.includes('Thé 100g=2.1'), 'suppression reçue sur le téléphone');

  console.log('7. Redémarrage du téléphone : données conservées');
  await B.page.reload(); await sleep(1500); b = await state(B.page); a = await state(A.page);
  ok(JSON.stringify(a.stock) === JSON.stringify(b.stock) && b.sync.state === 'ok', 'stocks identiques après redémarrage, statut : ' + b.sync.msg);

  ok(A.errs.length === 0 && B.errs.length === 0, 'aucune erreur JavaScript' + (A.errs.concat(B.errs).length ? ' : ' + A.errs.concat(B.errs).join(' | ') : ''));
  await A.page.evaluate(() => showPage('parametres')); await A.page.screenshot({ path: '/home/claude/test/pc-parametres.png', fullPage: false });
  await browser.close();
  console.log(fails ? `\n${fails} échec(s)` : '\nTOUT EST OK'); process.exit(fails ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
