// Faux Supabase minimal (auth + table ops) pour tester la synchro. Sert aussi l'appli.
const http = require('http'), fs = require('fs'), path = require('path');
const WWW = process.argv[2];
let ops = [], nextId = 1;
const USER = { id: '11111111-1111-1111-1111-111111111111', email: 'elhana@test.tn' };
const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': '*', 'Access-Control-Allow-Methods': 'GET,POST,OPTIONS' };
function send(res, code, body, type = 'application/json') { res.writeHead(code, { ...cors, 'Content-Type': type }); res.end(typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body)); }
http.createServer((req, res) => {
  const u = new URL(req.url, 'http://x');
  if (req.method === 'OPTIONS') return send(res, 204, '');
  if (u.pathname.startsWith('/app/')) { const f = path.join(WWW, u.pathname.slice(5) || 'index.html'); return fs.existsSync(f) ? send(res, 200, fs.readFileSync(f), f.endsWith('.html') ? 'text/html' : 'application/javascript') : send(res, 404, 'nf', 'text/plain'); }
  if (u.pathname === '/__stats') return send(res, 200, { count: ops.length, ops });
  let body = ''; req.on('data', c => body += c); req.on('end', () => {
    if (u.pathname === '/auth/v1/token') {
      const b = JSON.parse(body || '{}');
      if (u.searchParams.get('grant_type') === 'password' && b.password !== 'secret') return send(res, 400, { error: 'invalid_grant' });
      return send(res, 200, { access_token: 'tok', refresh_token: 'ref', expires_in: 3600, user: USER });
    }
    if (u.pathname === '/rest/v1/ops') {
      if (req.headers.authorization !== 'Bearer tok') return send(res, 401, { message: 'jwt' });
      if (req.method === 'POST') {
        for (const o of JSON.parse(body)) if (!ops.some(x => x.op_id === o.op_id)) ops.push({ id: nextId++, ...o });
        return send(res, 201, '');
      }
      let r = ops;
      const gt = u.searchParams.get('id'); if (gt) r = r.filter(o => o.id > Number(gt.slice(3)));
      const dv = u.searchParams.get('device'); if (dv) r = r.filter(o => o.device !== dv.slice(4));
      r = r.slice(0, Number(u.searchParams.get('limit') || 1000));
      return send(res, 200, r);
    }
    send(res, 404, { message: 'nf' });
  });
}).listen(8787, () => console.log('fake supabase on 8787'));
