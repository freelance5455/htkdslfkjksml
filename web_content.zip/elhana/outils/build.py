#!/usr/bin/env python3
"""Fabrique www/index.html (synchronisation incluse) à partir de votre index.html d'origine.
Usage : python3 build.py chemin/vers/index.html_origine
Le même fichier sert au programme Windows (Electron) et à l'application Android."""
import sys, pathlib, re

here = pathlib.Path(__file__).resolve().parent.parent
src = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else here / 'original' / 'index.html')
html = src.read_text(encoding='utf-8')
sync = (here / 'src' / 'elhana-sync.js').read_text(encoding='utf-8')

if 'window.elhanaSync' in html:
    sys.exit("Ce fichier contient déjà la synchronisation : donnez l'index.html d'origine.")

def patch(old, new, label):
    global html
    n = html.count(old)
    if n != 1:
        sys.exit(f'Repère introuvable ou ambigu ({n}) : {label}')
    html = html.replace(old, new)

# 1) module de synchronisation, juste après le stockage Windows et le thème (avant l'application)
patch('<!-- Manifest PWA intégré -->',
      '<script>/* Synchronisation PC ⇄ Android */\n' + sync + '\n</script>\n\n  <!-- Manifest PWA intégré -->',
      'manifest')

# 2) la caisse expose son état pour recevoir les ventes / prix des autres appareils
patch("const sv=()=>{try{localStorage.setItem(K,JSON.stringify(D))}catch(e){toast('Stockage plein')}};",
      "const sv=()=>{try{localStorage.setItem(K,JSON.stringify(D))}catch(e){toast('Stockage plein')}};"
      "window.__elhanaPOS={D:()=>D,sv:()=>sv(),refresh:()=>{[()=>draw(),()=>res(),()=>st5(),()=>pl()].forEach(f=>{try{f()}catch(e){}})}};",
      'caisse')

# 3) scanner : bibliothèque locale d'abord (fonctionne sans Internet), sinon Internet
patch("s.src = 'https://cdn.jsdelivr.net/npm/@zxing/library@0.21.3/umd/index.min.js';\n        s.onload = ok; s.onerror = () => ko(new Error('zxing'));",
      "s.src = 'zxing.min.js';\n        s.onload = ok; s.onerror = () => { const t = document.createElement('script'); t.src = 'https://cdn.jsdelivr.net/npm/@zxing/library@0.21.3/umd/index.min.js'; t.onload = ok; t.onerror = () => ko(new Error('zxing')); document.head.appendChild(t); };",
      'scanner')

out = here / 'www' / 'index.html'
out.parent.mkdir(exist_ok=True)
out.write_text(html, encoding='utf-8')
print('OK →', out)
