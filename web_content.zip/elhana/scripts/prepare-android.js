// Prépare l'application Android : scanner hors-ligne + permission caméra.
const fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..');

// 1) bibliothèque du scanner copiée dans l'appli (le scanner marche sans Internet)
const zx = path.join(root, 'node_modules/@zxing/library/umd/index.min.js');
if (fs.existsSync(zx)) { fs.copyFileSync(zx, path.join(root, 'www/zxing.min.js')); console.log('✔ scanner copié'); }
else console.warn('⚠ Lancez d\'abord : npm install');

// 2) permissions Android (caméra pour le scanner, Internet pour la synchro)
const mf = path.join(root, 'android/app/src/main/AndroidManifest.xml');
if (!fs.existsSync(mf)) { console.warn('⚠ Dossier android absent : lancez d\'abord « npx cap add android »'); process.exit(0); }
let x = fs.readFileSync(mf, 'utf8');
const perms = ['android.permission.INTERNET', 'android.permission.CAMERA', 'android.permission.ACCESS_NETWORK_STATE'];
let added = 0;
for (const p of perms) if (!x.includes(p)) { x = x.replace('</manifest>', `    <uses-permission android:name="${p}" />\n</manifest>`); added++; }
if (!x.includes('android.hardware.camera')) x = x.replace('</manifest>', '    <uses-feature android:name="android.hardware.camera" android:required="false" />\n</manifest>');
fs.writeFileSync(mf, x);
console.log('✔ permissions Android (' + added + ' ajoutée(s))');
