-- =====================================================================
-- EL HANA · Base de synchronisation (Supabase)
-- À coller une seule fois dans : Supabase → SQL Editor → New query → Run
-- =====================================================================

-- Journal des opérations : chaque modification faite sur un appareil
create table if not exists public.ops (
  id          bigint generated always as identity primary key,
  owner       uuid not null default auth.uid() references auth.users(id) on delete cascade,
  op_id       text not null unique,          -- identifiant unique (évite les doublons si un envoi est répété)
  device      text not null,                 -- appareil qui a fait la modification
  ts          bigint not null,               -- heure de la modification sur l'appareil (ms)
  col         text not null,                 -- p=articles s=stock h=historique i=inventaire x=prix de vente/catégories v=ventes m=mouvements
  act         text not null,                 -- put / del / add
  k           text not null,                 -- clé (code-barres ou nom de l'article, ou empreinte)
  delta       numeric,                       -- variation de stock (+3, -2…)
  data        jsonb,                         -- contenu (article, vente…)
  created_at  timestamptz not null default now()
);

create index if not exists ops_owner_id on public.ops (owner, id);

-- Sécurité : chaque compte magasin ne voit et n'écrit que ses propres données
alter table public.ops enable row level security;

drop policy if exists "lecture magasin" on public.ops;
create policy "lecture magasin" on public.ops
  for select to authenticated using (owner = auth.uid());

drop policy if exists "ajout magasin" on public.ops;
create policy "ajout magasin" on public.ops
  for insert to authenticated with check (owner = auth.uid());

-- Pas de modification ni de suppression depuis les appareils (journal en ajout seul)
revoke update, delete on public.ops from anon, authenticated;

-- Temps réel : prévenir les appareils dès qu'une opération est ajoutée
do $$ begin
  alter publication supabase_realtime add table public.ops;
exception when duplicate_object then null; end $$;
