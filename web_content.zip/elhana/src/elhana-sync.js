/* =====================================================================
   EL HANA · Synchronisation PC Windows ⇄ Android (Supabase)
   ---------------------------------------------------------------------
   Principe : chaque modification locale est transformée en « opération »
   (article modifié, +3 / −2 sur un stock, vente ajoutée…). Les opérations
   sont gardées dans une file sur l'appareil (fonctionne hors-ligne), puis
   envoyées au serveur dès que le réseau revient. Les autres appareils les
   reçoivent en temps réel et les appliquent.
   - Stock : additions de mouvements → deux ventes hors-ligne simultanées
     sur deux appareils s'additionnent correctement.
   - Articles, prix de vente, inventaire : la dernière modification gagne.
   - Ventes, historique, mouvements : ensembles (ajout / suppression).
   - Restent propres à chaque appareil : thème, apparence, imprimante,
     tickets en attente, numéro de ticket.
   ===================================================================== */
(function () {
  'use strict';
  if (window.elhanaSync) return;

  var DEFAULTS = window.ELHANA_SYNC_DEFAULTS || {}; // { url, anonKey } facultatif
  var RAW = window.localStorage; // stockage réel (fichiers sur PC, WebView sur Android)
  var K_CONF = '__elhana_sync_conf', K_META = '__elhana_sync_meta', K_QUEUE = '__elhana_sync_queue';
  var KEYS = { LP: 'elhana_liste_prix_v2', STOCK: 'elhana_stock_v2', HIST: 'elhana_historique_v2', INV: 'elhana_inventaire_v2', POS: 'elhana_pos_v1' };
  var TRACKED = {}; Object.keys(KEYS).forEach(function (n) { TRACKED[KEYS[n]] = n; });
  var OVERLAP = 500, PAGE = 1000, POLL_MS = 15000, PUSH_DELAY = 800, DIFF_DELAY = 500;

  /* ---------------- outils ---------------- */
  function jget(k, d) { try { var v = RAW.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } }
  function jset(k, v) { try { RAW.setItem(k, JSON.stringify(v)); return true; } catch (e) { console.error('[sync] écriture', k, e); return false; } }
  function r3(x) { return Math.round(x * 1000) / 1000; }
  function hash(str) { // cyrb53
    var h1 = 0xdeadbeef, h2 = 0x41c6ce57;
    for (var i = 0, ch; i < str.length; i++) { ch = str.charCodeAt(i); h1 = Math.imul(h1 ^ ch, 2654435761); h2 = Math.imul(h2 ^ ch, 1597334677); }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
    return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(36);
  }
  function hobj(o) { return hash(JSON.stringify(o)); }
  function uid() { return Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10); }
  function newer(a, b) { if (!b) return true; return a[0] !== b[0] ? a[0] > b[0] : String(a[1]) > String(b[1]); }
  var keyP = function (p) { return p && (p.code || p.nom) || ''; };
  var keyI = function (l) { return l && (l.code || l.nom) || ('#' + hobj(l)); };
  function dateOf(x) { return x && (x.d || x.date) || ''; }

  /* ---------------- état persistant ---------------- */
  var conf = jget(K_CONF, null) || {};
  if (!conf.device) { conf.device = 'dev-' + uid(); }
  if (!conf.url && DEFAULTS.url) conf.url = DEFAULTS.url;
  if (!conf.anonKey && DEFAULTS.anonKey) conf.anonKey = DEFAULTS.anonKey;
  jset(K_CONF, conf);
  var meta = jget(K_META, null) || {};
  function resetMeta() { meta = { base: { p: {}, s: {}, h: {}, i: {}, x: {}, v: {}, m: {} }, ver: {}, cursor: 0, applied: [], active: false }; }
  if (!meta.base) resetMeta();
  var appliedSet = new Set(meta.applied || []);
  var queue = jget(K_QUEUE, []);
  function saveMeta() { meta.applied = Array.from(appliedSet).slice(-5000); appliedSet = new Set(meta.applied); jset(K_META, meta); }
  function saveQueue() { jset(K_QUEUE, queue); }

  /* ---------------- interception du stockage ---------------- */
  var pending = {}, diffTimer = null, applying = false, frozen = false;
  var W = {
    getItem: function (k) { return RAW.getItem(k); },
    setItem: function (k, v) { if (frozen && TRACKED[k]) return; RAW.setItem(k, v); if (TRACKED[k] && meta.active && !applying) { pending[k] = String(v); scheduleDiff(); } },
    removeItem: function (k) { RAW.removeItem(k); },
    clear: function () { RAW.clear(); },
    key: function (i) { return RAW.key(i); },
    get length() { return RAW.length; }
  };
  try { Object.defineProperty(window, 'localStorage', { configurable: true, get: function () { return W; } }); }
  catch (e) { console.error('[sync] interception impossible', e); }

  function scheduleDiff() { clearTimeout(diffTimer); diffTimer = setTimeout(flushDiff, DIFF_DELAY); }
  function flushDiff() {
    clearTimeout(diffTimer); diffTimer = null;
    var ks = Object.keys(pending); if (!ks.length) return;
    var ops = [];
    ks.forEach(function (k) { var s = pending[k]; delete pending[k]; try { diffKey(TRACKED[k], s == null ? null : JSON.parse(s), ops); } catch (e) { console.error('[sync] diff', k, e); } });
    if (ops.length) { Array.prototype.push.apply(queue, ops); saveQueue(); saveMeta(); setStatus(); schedulePush(); }
  }

  /* ---------------- calcul des différences ---------------- */
  function mkOp(col, act, k, data, delta) {
    var ts = Date.now(), op = { op_id: conf.device + ':' + uid(), device: conf.device, ts: ts, col: col, act: act, k: String(k), delta: delta == null ? null : delta, data: data == null ? null : data };
    if (col === 'p' || col === 'i' || col === 'x') meta.ver[col + '|' + k] = [ts, conf.device];
    return op;
  }
  function diffMap(col, items, keyFn, ops) { // items : tableau ou objet clé→valeur
    var base = meta.base[col], cur = {};
    if (Array.isArray(items)) items.forEach(function (it) { if (it) cur[keyFn(it)] = it; });
    else if (items && typeof items === 'object') Object.keys(items).forEach(function (k) { cur[k] = items[k]; });
    Object.keys(cur).forEach(function (k) { var h = hobj(cur[k]); if (base[k] !== h) { base[k] = h; ops.push(mkOp(col, 'put', k, cur[k])); } });
    Object.keys(base).forEach(function (k) { if (!(k in cur)) { delete base[k]; ops.push(mkOp(col, 'del', k)); } });
  }
  function diffSet(col, arr, ops) {
    var base = meta.base[col], cnt = {}, ex = {};
    (Array.isArray(arr) ? arr : []).forEach(function (it) { var h = hobj(it); cnt[h] = (cnt[h] || 0) + 1; ex[h] = it; });
    Object.keys(cnt).forEach(function (h) { for (var n = cnt[h] - (base[h] || 0); n > 0; n--) ops.push(mkOp(col, 'add', h, ex[h])); });
    Object.keys(base).forEach(function (h) { for (var n = base[h] - (cnt[h] || 0); n > 0; n--) ops.push(mkOp(col, 'del', h)); });
    meta.base[col] = cnt;
  }
  function diffCounter(obj, ops) {
    var base = meta.base.s, cur = obj && typeof obj === 'object' ? obj : {}, all = {};
    Object.keys(base).forEach(function (k) { all[k] = 1; }); Object.keys(cur).forEach(function (k) { all[k] = 1; });
    Object.keys(all).forEach(function (k) {
      var c = Number(cur[k]) || 0, b = Number(base[k]) || 0, d = r3(c - b);
      if (Math.abs(d) > 1e-9) ops.push(mkOp('s', 'add', k, null, d));
      if (Math.abs(c) > 1e-9) base[k] = c; else delete base[k];
    });
  }
  function diffKey(name, val, ops) {
    if (name === 'LP') diffMap('p', val || [], keyP, ops);
    else if (name === 'INV') diffMap('i', val || [], keyI, ops);
    else if (name === 'STOCK') diffCounter(val || {}, ops);
    else if (name === 'HIST') diffSet('h', val || [], ops);
    else if (name === 'POS') { val = val || {}; diffMap('x', val.extra || {}, null, ops); diffSet('v', val.ventes || [], ops); diffSet('m', val.mv || [], ops); }
  }
  function diffAllFromStorage() {
    Object.keys(TRACKED).forEach(function (k) { var s = RAW.getItem(k); if (s != null) pending[k] = s; });
    flushDiff();
  }

  /* ---------------- application des opérations reçues ---------------- */
  function memory() { // variables de l'application (si elle est chargée)
    var m = {};
    try { m.LP = listePrix; } catch (e) {}           // eslint-disable-line no-undef
    try { m.STOCK = stock; } catch (e) {}            // eslint-disable-line no-undef
    try { m.HIST = historique; } catch (e) {}        // eslint-disable-line no-undef
    try { m.INV = inventaire; } catch (e) {}         // eslint-disable-line no-undef
    try { if (window.__elhanaPOS) m.POS = window.__elhanaPOS.D(); } catch (e) {}
    return m;
  }
  function containers(useMemory) {
    var m = useMemory ? memory() : {}, c = {};
    c.LP = Array.isArray(m.LP) ? m.LP : jget(KEYS.LP, []);
    c.STOCK = m.STOCK && typeof m.STOCK === 'object' ? m.STOCK : jget(KEYS.STOCK, {});
    c.HIST = Array.isArray(m.HIST) ? m.HIST : jget(KEYS.HIST, []);
    c.INV = Array.isArray(m.INV) ? m.INV : jget(KEYS.INV, []);
    c.POS = m.POS && typeof m.POS === 'object' ? m.POS : (jget(KEYS.POS, null) || {});
    c.POS.extra = c.POS.extra || {}; c.POS.ventes = c.POS.ventes || []; c.POS.mv = c.POS.mv || [];
    return c;
  }
  function insertByDate(arr, it) {
    var d = dateOf(it), i = arr.length;
    while (i > 0 && d && dateOf(arr[i - 1]) > d) i--;
    arr.splice(i, 0, it);
  }
  function applyOp(op, c, touched) {
    var col = op.col, k = op.k;
    if (col === 'p' || col === 'i' || col === 'x') {
      var vk = col + '|' + k, ver = [Number(op.ts) || 0, op.device];
      if (!newer(ver, meta.ver[vk])) return; // une modification plus récente existe déjà ici
      meta.ver[vk] = ver;
      if (col === 'x') {
        if (op.act === 'put') { c.POS.extra[k] = op.data; meta.base.x[k] = hobj(op.data); }
        else { delete c.POS.extra[k]; delete meta.base.x[k]; }
        touched.POS = 1; return;
      }
      var arr = col === 'p' ? c.LP : c.INV, kf = col === 'p' ? keyP : keyI, idx = -1;
      for (var i = 0; i < arr.length; i++) if (kf(arr[i]) === k) { idx = i; break; }
      if (op.act === 'put') { if (idx >= 0) arr[idx] = op.data; else arr.push(op.data); meta.base[col][k] = hobj(op.data); }
      else { if (idx >= 0) arr.splice(idx, 1); delete meta.base[col][k]; }
      touched[col === 'p' ? 'LP' : 'INV'] = 1; return;
    }
    if (col === 's') {
      var v = r3((Number(c.STOCK[k]) || 0) + (Number(op.delta) || 0));
      if (Math.abs(v) > 1e-9) c.STOCK[k] = v; else delete c.STOCK[k];
      var b = r3((Number(meta.base.s[k]) || 0) + (Number(op.delta) || 0));
      if (Math.abs(b) > 1e-9) meta.base.s[k] = b; else delete meta.base.s[k];
      touched.STOCK = 1; return;
    }
    if (col === 'h' || col === 'v' || col === 'm') {
      var list = col === 'h' ? c.HIST : col === 'v' ? c.POS.ventes : c.POS.mv, base = meta.base[col];
      if (op.act === 'add') { insertByDate(list, op.data); base[k] = (base[k] || 0) + 1; }
      else {
        for (var j = list.length - 1; j >= 0; j--) if (hobj(list[j]) === k) { list.splice(j, 1); break; }
        if (base[k] > 1) base[k]--; else delete base[k];
      }
      touched[col === 'h' ? 'HIST' : 'POS'] = 1;
    }
  }
  function applyRemote(rows, useMemory) {
    if (!rows.length) return 0;
    flushDiff(); // d'abord enregistrer les modifications locales en attente
    var c = containers(useMemory), touched = {}, n = 0;
    rows.forEach(function (op) {
      if (op.id > meta.cursor) meta.cursor = op.id;
      if (appliedSet.has(op.op_id) || op.device === conf.device) return;
      appliedSet.add(op.op_id); n++;
      try { applyOp(op, c, touched); } catch (e) { console.error('[sync] opération ignorée', op, e); }
    });
    applying = true;
    try {
      if (touched.LP) jset(KEYS.LP, c.LP);
      if (touched.STOCK) jset(KEYS.STOCK, c.STOCK);
      if (touched.HIST) jset(KEYS.HIST, c.HIST);
      if (touched.INV) jset(KEYS.INV, c.INV);
      if (touched.POS) jset(KEYS.POS, c.POS);
    } finally { applying = false; }
    saveMeta();
    if (n && useMemory) refreshUI(touched);
    return n;
  }

  /* ---------------- rafraîchissement de l'écran ---------------- */
  var uiTimer = null, uiTouched = {};
  function refreshUI(t) {
    Object.keys(t).forEach(function (k) { uiTouched[k] = 1; });
    clearTimeout(uiTimer); uiTimer = setTimeout(doRefresh, 400);
  }
  function doRefresh() {
    var a = document.activeElement;
    if (a && /^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName) && a.type !== 'button') { // ne pas gêner la saisie
      a.addEventListener('blur', function () { setTimeout(doRefresh, 50); }, { once: true }); return;
    }
    uiTouched = {};
    ['renderDashboard', 'renderListePrix', 'renderInventaire', 'renderHistorique', 'renderRapports'].forEach(function (f) {
      try { if (typeof window[f] === 'function') window[f](); } catch (e) {}
    });
    try { if (window.__elhanaPOS) window.__elhanaPOS.refresh(); } catch (e) {}
  }

  /* ---------------- réseau : Supabase ---------------- */
  var status = { state: 'off', msg: 'Non configurée', last: null };
  function api(path, opt, retried) {
    opt = opt || {};
    var h = { apikey: conf.anonKey, 'Content-Type': 'application/json' };
    if (conf.session && conf.session.access_token) h.Authorization = 'Bearer ' + conf.session.access_token;
    Object.keys(opt.headers || {}).forEach(function (x) { h[x] = opt.headers[x]; });
    return fetch(conf.url.replace(/\/+$/, '') + path, { method: opt.method || 'GET', headers: h, body: opt.body }).then(function (r) {
      if (r.status === 401 && !retried && conf.session && conf.session.refresh_token) return refresh().then(function () { return api(path, opt, true); });
      if (!r.ok) return r.text().then(function (t) { var e = new Error('HTTP ' + r.status + ' ' + t.slice(0, 200)); e.status = r.status; throw e; });
      return r.text().then(function (t) { if (!t) return null; try { return JSON.parse(t); } catch (e) { return t; } });
    });
  }
  function storeSession(s) {
    conf.session = { access_token: s.access_token, refresh_token: s.refresh_token, expires_at: Date.now() + (s.expires_in || 3600) * 1000, user: s.user && s.user.id, email: s.user && s.user.email };
    jset(K_CONF, conf); rt.token();
  }
  function login(email, password) {
    return api('/auth/v1/token?grant_type=password', { method: 'POST', body: JSON.stringify({ email: email, password: password }) }, true).then(storeSession);
  }
  var refreshing = null;
  function refresh() {
    if (refreshing) return refreshing;
    refreshing = api('/auth/v1/token?grant_type=refresh_token', { method: 'POST', body: JSON.stringify({ refresh_token: conf.session.refresh_token }) }, true)
      .then(storeSession, function (e) { if (e.status === 400 || e.status === 401) { conf.session = null; jset(K_CONF, conf); setStatus('err', 'Reconnexion nécessaire (Paramètres)'); } throw e; })
      .then(function (x) { refreshing = null; return x; }, function (e) { refreshing = null; throw e; });
    return refreshing;
  }
  function ready() { return !!(meta.active && conf.url && conf.anonKey && conf.session); }

  var pushing = false, pushTimer = null;
  function schedulePush() { clearTimeout(pushTimer); pushTimer = setTimeout(push, PUSH_DELAY); }
  function push() {
    if (!ready() || pushing || !queue.length) return Promise.resolve();
    pushing = true;
    var batch = [], size = 0;
    for (var i = 0; i < queue.length && batch.length < 300; i++) { var s = JSON.stringify(queue[i]).length; if (batch.length && size + s > 1500000) break; batch.push(queue[i]); size += s; }
    return api('/rest/v1/ops?on_conflict=op_id', { method: 'POST', headers: { Prefer: 'resolution=ignore-duplicates,return=minimal' }, body: JSON.stringify(batch) })
      .then(function () {
        var sent = new Set(batch.map(function (o) { return o.op_id; }));
        queue = queue.filter(function (o) { return !sent.has(o.op_id); }); saveQueue();
        pushing = false; status.last = new Date(); setStatus();
        if (queue.length) return push();
      }, function (e) { pushing = false; netError(e); });
  }
  var pulling = false;
  function pull(useMemory) {
    if (!ready() || pulling) return Promise.resolve(0);
    pulling = true; var total = 0;
    function page(from) {
      var q = '/rest/v1/ops?select=id,op_id,device,ts,col,act,k,delta,data&order=id.asc&limit=' + PAGE + '&id=gt.' + Math.max(0, from) + '&device=neq.' + encodeURIComponent(conf.device);
      return api(q).then(function (rows) {
        total += applyRemote(rows, useMemory !== false);
        if (rows.length === PAGE) return page(rows[rows.length - 1].id);
      });
    }
    return page(meta.cursor - OVERLAP).then(function () { pulling = false; status.last = new Date(); setStatus(); return total; },
      function (e) { pulling = false; netError(e); return total; });
  }
  function syncNow() { flushDiff(); return push().then(function () { return pull(); }).then(function (n) { return push().then(function () { return n; }); }); }
  function netError(e) {
    console.warn('[sync]', e);
    if (e && e.status && e.status !== 401) setStatus('err', 'Erreur serveur ' + e.status);
    else setStatus('offline', 'Hors-ligne : les données seront envoyées au retour du réseau');
    rt.close();
  }

  /* ---------------- temps réel (Supabase Realtime, protocole Phoenix) ---------------- */
  var rt = (function () {
    var ws = null, hb = null, ref = 0, retry = 0, timer = null;
    var topic = 'realtime:elhana-ops';
    function send(o) { if (ws && ws.readyState === 1) ws.send(JSON.stringify(o)); }
    function open() {
      if (!ready() || ws || typeof WebSocket === 'undefined') return;
      try { ws = new WebSocket(conf.url.replace(/^http/, 'ws').replace(/\/+$/, '') + '/realtime/v1/websocket?apikey=' + encodeURIComponent(conf.anonKey) + '&vsn=1.0.0'); }
      catch (e) { ws = null; return; }
      ws.onopen = function () {
        retry = 0;
        send({ topic: topic, event: 'phx_join', ref: String(++ref), join_ref: '1', payload: { config: { broadcast: { self: false }, presence: { key: '' }, postgres_changes: [{ event: 'INSERT', schema: 'public', table: 'ops' }] }, access_token: conf.session.access_token } });
        hb = setInterval(function () { send({ topic: 'phoenix', event: 'heartbeat', payload: {}, ref: String(++ref) }); }, 25000);
        setStatus();
      };
      ws.onmessage = function (m) {
        try { var d = JSON.parse(m.data); if (d.event === 'postgres_changes' || d.event === 'INSERT') { var rec = d.payload && d.payload.data && d.payload.data.record; if (!rec || rec.device !== conf.device) schedulePull(); } } catch (e) {}
      };
      ws.onclose = function () { clearInterval(hb); ws = null; setStatus(); clearTimeout(timer); if (ready()) timer = setTimeout(open, Math.min(30000, 1000 * Math.pow(2, retry++))); };
      ws.onerror = function () { try { ws.close(); } catch (e) {} };
    }
    return {
      open: open,
      close: function () { if (ws) try { ws.close(); } catch (e) {} },
      token: function () { if (ws && conf.session) send({ topic: topic, event: 'access_token', ref: String(++ref), payload: { access_token: conf.session.access_token } }); },
      live: function () { return !!(ws && ws.readyState === 1); }
    };
  })();
  var pullTimer = null;
  function schedulePull() { clearTimeout(pullTimer); pullTimer = setTimeout(function () { pull(); }, 300); }

  /* ---------------- connexion d'un appareil ---------------- */
  function connect(o) {
    conf.url = (o.url || conf.url || '').trim(); conf.anonKey = (o.anonKey || conf.anonKey || '').trim();
    conf.name = (o.name || conf.name || 'Appareil').trim(); conf.poste = parseInt(o.poste, 10) || 0;
    jset(K_CONF, conf);
    if (!/^https?:\/\//.test(conf.url) || !conf.anonKey) return Promise.reject(new Error('Adresse Supabase ou clé manquante'));
    var relogin = meta.active; // session expirée : on se reconnecte sans rien effacer
    return login(o.email, o.password)
      .then(function () { return relogin ? 'relogin' : api('/rest/v1/ops?select=id&limit=1'); })
      .then(function (rows) {
        if (rows === 'relogin') return { mode: 'relogin' };
        flushDiff();
        resetMeta(); queue = []; saveQueue(); appliedSet = new Set();
        if (!rows.length) { // premier appareil : il envoie ses données
          meta.active = true; saveMeta(); diffAllFromStorage(); setTicketStart(true);
          return push().then(function () { return { mode: 'first' }; });
        }
        if (o.confirmReplace && !o.confirmReplace()) { meta.active = false; saveMeta(); throw new Error('Annulé'); }
        // appareil supplémentaire : ses données sont remplacées par celles du magasin.
        // Jusqu'au redémarrage, l'application ne peut plus réécrire ses anciennes données.
        frozen = true; pending = {};
        applying = true;
        try {
          jset(KEYS.LP, []); jset(KEYS.STOCK, {}); jset(KEYS.HIST, []); jset(KEYS.INV, []);
          var pos = jget(KEYS.POS, null) || {}; pos.extra = {}; pos.ventes = []; pos.mv = []; jset(KEYS.POS, pos);
        } finally { applying = false; }
        meta.active = true; saveMeta();
        return pull(false).then(function (n) { setTicketStart(false); return { mode: 'join', ops: n, reload: true }; });
      });
  }
  function setTicketStart(inMemory) { // numérotation des tickets propre à chaque poste (poste 1 → 100001…)
    if (!conf.poste) return;
    var start = conf.poste * 100000;
    if (inMemory && window.__elhanaPOS) { var D = window.__elhanaPOS.D(); if ((D.n || 0) < start) { D.n = start; window.__elhanaPOS.sv(); } return; }
    var pos = jget(KEYS.POS, null) || {}; if ((pos.n || 0) < start) { pos.n = start; applying = true; try { jset(KEYS.POS, pos); } finally { applying = false; } }
  }
  function disconnect() { flushDiff(); meta.active = false; saveMeta(); conf.session = null; jset(K_CONF, conf); rt.close(); setStatus(); }

  /* ---------------- statut + écran Paramètres ---------------- */
  function setStatus(state, msg) {
    if (state) { status.state = state; status.msg = msg; }
    else if (!meta.active || !conf.session) { status.state = 'off'; status.msg = 'Non configurée'; }
    else { status.state = queue.length ? 'pending' : 'ok'; status.msg = queue.length ? queue.length + ' modification(s) en attente d\'envoi' : (rt.live() ? 'À jour · temps réel actif' : 'À jour'); }
    paint();
  }
  var COLORS = { ok: '#16a34a', pending: '#f59e0b', offline: '#94a3b8', err: '#dc2626', off: 'transparent' };
  function paint() {
    var dot = document.getElementById('elhSyncDot'); if (dot) { dot.style.background = COLORS[status.state]; dot.title = 'Synchronisation : ' + status.msg; dot.style.display = status.state === 'off' ? 'none' : 'block'; }
    var t = document.getElementById('elhSyncState');
    if (t) t.innerHTML = '<span style="display:inline-block;width:10px;height:10px;border-radius:50%;margin-right:6px;background:' + (status.state === 'off' ? '#cbd5e1' : COLORS[status.state]) + '"></span>' + status.msg + (status.last ? ' <small style="opacity:.7">(' + status.last.toLocaleTimeString('fr-FR') + ')</small>' : '');
    var c = document.getElementById('elhSyncConnected'), f = document.getElementById('elhSyncForm');
    if (c && f) { var on = meta.active && conf.session; c.style.display = on ? '' : 'none'; f.style.display = on ? 'none' : ''; var w = document.getElementById('elhSyncWho'); if (w && on) w.textContent = (conf.name || 'Appareil') + ' · ' + (conf.session.email || '') + (conf.poste ? ' · poste ' + conf.poste : ''); }
  }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function buildUI() {
    var dot = document.createElement('div'); dot.id = 'elhSyncDot';
    dot.style.cssText = 'position:fixed;top:calc(env(safe-area-inset-top,0px) + 4px);left:50%;transform:translateX(-50%);width:9px;height:9px;border-radius:50%;z-index:99999;box-shadow:0 0 0 2px rgba(255,255,255,.85);cursor:pointer;display:none';
    dot.onclick = function () { try { showPage('parametres'); } catch (e) {} }; // eslint-disable-line no-undef
    document.body.appendChild(dot);
    var anchor = document.getElementById('settingsExtra'); if (!anchor) return;
    var box = document.createElement('div');
    box.innerHTML = '<h4 class="set-h">Synchronisation PC ⇄ téléphone</h4><div class="form-card" style="max-width:560px">' +
      '<p id="elhSyncState" style="margin-bottom:12px"></p>' +
      '<div id="elhSyncConnected"><p id="elhSyncWho" style="margin-bottom:12px;opacity:.8"></p>' +
      '<button class="btn" id="elhSyncNow" style="width:100%;margin-bottom:10px">Synchroniser maintenant</button>' +
      '<button class="btn btn-secondary" id="elhSyncOff" style="width:100%">Déconnecter cet appareil</button></div>' +
      '<div id="elhSyncForm">' +
      '<label class="field-label">Adresse du projet Supabase</label><input class="input-field" id="elhSU" placeholder="https://xxxx.supabase.co" value="' + esc(conf.url) + '" style="width:100%;margin:4px 0 10px">' +
      '<label class="field-label">Clé publique (anon)</label><input class="input-field" id="elhSK" value="' + esc(conf.anonKey) + '" style="width:100%;margin:4px 0 10px">' +
      '<label class="field-label">E-mail du compte magasin</label><input class="input-field" id="elhSE" type="email" autocomplete="username" style="width:100%;margin:4px 0 10px">' +
      '<label class="field-label">Mot de passe</label><input class="input-field" id="elhSP" type="password" autocomplete="current-password" style="width:100%;margin:4px 0 10px">' +
      '<label class="field-label">Nom de cet appareil</label><input class="input-field" id="elhSN" placeholder="PC caisse, Téléphone Jamel…" value="' + esc(conf.name || '') + '" style="width:100%;margin:4px 0 10px">' +
      '<label class="field-label">Numéro de poste (0 pour le PC, 1, 2… pour les téléphones)</label><input class="input-field" id="elhSPo" type="number" min="0" max="9" value="' + (conf.poste || 0) + '" style="width:100%;margin-bottom:12px">' +
      '<button class="btn" id="elhSGo" style="width:100%">Connecter cet appareil</button>' +
      '<p style="margin-top:10px;font-size:12px;opacity:.75">Le premier appareil connecté (le PC) envoie ses données au serveur. Les appareils suivants reçoivent les données du magasin : leurs propres données sont remplacées.</p></div></div>';
    anchor.parentNode.insertBefore(box, anchor.nextSibling);
    var $ = function (id) { return document.getElementById(id); };
    var say = function (m) { try { toast(m); } catch (e) { alert(m); } }; // eslint-disable-line no-undef
    $('elhSyncNow').onclick = function () { setStatus('pending', 'Synchronisation…'); syncNow().then(function (n) { say(n ? n + ' modification(s) reçue(s)' : 'Synchronisation terminée'); }); };
    $('elhSyncOff').onclick = function () { flushDiff(); if (confirm((queue.length ? '⚠ ' + queue.length + ' modification(s) pas encore envoyée(s) seront perdues pour les autres appareils.\n\n' : '') + 'Déconnecter cet appareil ? Ses données restent sur l\'appareil mais ne seront plus synchronisées.')) disconnect(); };
    $('elhSGo').onclick = function () {
      var b = this; b.disabled = true; b.textContent = 'Connexion…';
      connect({ url: $('elhSU').value, anonKey: $('elhSK').value, email: $('elhSE').value.trim(), password: $('elhSP').value, name: $('elhSN').value, poste: $('elhSPo').value,
        confirmReplace: function () { return confirm('Le magasin contient déjà des données sur le serveur.\n\nLes articles, stocks, ventes et l\'historique de CET appareil vont être remplacés par ceux du magasin. Continuer ?\n\n(Conseil : faites d\'abord « Exporter JSON » si cet appareil contient des données importantes.)'); } })
        .then(function (r) {
          $('elhSP').value = '';
          if (r.reload) { say('Données du magasin reçues. Redémarrage…'); setTimeout(function () { location.reload(); }, 800); }
          else { say(r.mode === 'relogin' ? 'Reconnecté.' : 'Appareil connecté : données envoyées au serveur.'); start(); }
        }, function (e) { if (e.message !== 'Annulé') say('Connexion impossible : ' + (e.status === 400 ? 'e-mail ou mot de passe incorrect' : e.message)); setStatus(); })
        .then(function () { b.disabled = false; b.textContent = 'Connecter cet appareil'; });
    };
    paint();
  }

  /* ---------------- démarrage ---------------- */
  var pollTimer = null;
  function start() {
    setStatus();
    if (!ready()) return;
    syncNow().then(function () { rt.open(); });
    clearInterval(pollTimer); pollTimer = setInterval(function () { if (!rt.live()) pull().then(function () { rt.open(); }); push(); }, POLL_MS);
  }
  window.addEventListener('online', function () { if (ready()) syncNow().then(rt.open); });
  window.addEventListener('offline', function () { setStatus('offline', 'Hors-ligne : les données seront envoyées au retour du réseau'); });
  document.addEventListener('visibilitychange', function () { if (!document.hidden && ready()) syncNow().then(rt.open); else flushDiff(); });
  window.addEventListener('pagehide', flushDiff);
  window.addEventListener('beforeunload', flushDiff);
  function boot() { buildUI(); start(); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else setTimeout(boot, 0);

  window.elhanaSync = {
    status: function () { return Object.assign({ queue: queue.length, device: conf.device, name: conf.name, poste: conf.poste, live: rt.live() }, status); },
    syncNow: syncNow, connect: connect, disconnect: disconnect,
    _flush: flushDiff, _meta: function () { return meta; }, _queue: function () { return queue; }
  };
})();
