export const DEFAULT_INTERVALS = [1, 3, 7, 14, 30, 60, 120];
export const DAY = 86400000;
export function localISO(date = new Date()) {
  const d = new Date(date);
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
}
export function addDaysISO(iso, days) {
  const [y,m,d] = iso.split('-').map(Number);
  const date = new Date(y, m-1, d, 12, 0, 0, 0);
  date.setDate(date.getDate() + days);
  return localISO(date);
}
export function dayDiff(fromISO, toISO) {
  const [y1,m1,d1] = fromISO.split('-').map(Number), [y2,m2,d2] = toISO.split('-').map(Number);
  return Math.round((Date.UTC(y2,m2-1,d2)-Date.UTC(y1,m1-1,d1))/DAY);
}
export function nextReview(chapter, rating, today, intervals = DEFAULT_INTERVALS) {
  const prior = Math.max(0, Number(chapter.intervalDays || 0));
  const step = Math.max(0, Number(chapter.step || 0));
  let interval, nextStep;
  if (rating === 'again') {
    interval = Math.min(3, Math.max(1, Math.ceil(prior * 0.25)));
    nextStep = Math.max(0, step - 1);
  } else if (rating === 'hard') {
    interval = Math.max(1, Math.ceil(prior * 1.2));
    nextStep = step;
  } else if (rating === 'good') {
    interval = intervals[Math.min(step, intervals.length - 1)];
    nextStep = Math.min(step + 1, intervals.length - 1);
  } else if (rating === 'easy') {
    interval = Math.max(intervals[Math.min(step + 1, intervals.length - 1)], Math.ceil(prior * 1.5));
    nextStep = Math.min(step + 2, intervals.length - 1);
  } else throw new Error('Unknown recall rating');
  return { intervalDays: interval, step: nextStep, dueDate: addDaysISO(today, interval) };
}
export function sortDue(chapters, today = localISO()) {
  return chapters.filter(c => c.status === 'completed' && c.dueDate && c.dueDate <= today)
    .sort((a,b) => a.dueDate.localeCompare(b.dueDate) || a.name.localeCompare(b.name));
}
export function isValidISODate(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value || '')) return false;
  const [y,m,d] = value.split('-').map(Number), dt = new Date(y,m-1,d,12);
  return dt.getFullYear() === y && dt.getMonth() === m-1 && dt.getDate() === d;
}
