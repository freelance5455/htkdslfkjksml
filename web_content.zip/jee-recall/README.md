# Recall — JEE Main revision planner

A mobile-first, local-first PWA for managing JEE Main chapter revision. Built with plain HTML, CSS and JavaScript so it has no paid services or runtime dependencies.

## Run it

**Fastest:** serve this folder over HTTP. With Node installed, run:

```bash
npm run start
```

If `serve` is not already available, `npx` may download it the first time. Alternatively use Python:

```bash
python -m http.server 8080
```

Then open `http://localhost:8080`. Service workers and installability require HTTPS or localhost. To use on Android, deploy this folder to any static HTTPS host (for example, GitHub Pages or Netlify), open the URL in Chrome, and choose **Install app** / **Add to Home screen**. There is no backend.

## Data and privacy

The app stores the entire state in IndexedDB on the current browser/device, with a localStorage fallback. It does not upload data. Browser data clearing can erase it; export a JSON backup in Settings. Import replaces the current state after confirmation. There is no automatic cross-device sync.

## Scheduling rules

- Completing a chapter schedules the first review at the first configured interval (default 1 day).
- Good uses the next rung of the interval ladder; Easy advances two rungs and uses at least 1.5× the prior interval; Hard uses about 1.2× the prior interval without advancing the ladder; Again schedules a short 1–3 day return and moves the ladder back one rung.
- The date is computed in local calendar days, not by adding 24 hours to a UTC timestamp. Reviews rated today cannot return today.
- Overdue items remain due until reviewed or explicitly rescheduled. The daily limit limits how many items are offered in one session; it does not erase the others. Postponements are recorded separately from recall history.
- A session queue, current step and completed IDs are persisted. Opening a chapter never records a review; only a recall rating does.

This is a transparent interval-ladder scheduler, not FSRS. FSRS can be more adaptive but needs a tested implementation and a richer memory model; this simple rule set is easier to inspect and reliable for a personal tool. Intervals can be changed in Settings. Changing the ladder affects future ratings, not existing due dates.

## Syllabus

The prefilled chapter list is organized around the official JEE Main 2026 Paper 1 (B.E./B.Tech.) syllabus units and can be edited. Official reference: https://jeemain.nta.nic.in/document/syllabus-2026/ . The list uses familiar chapter groupings, which do not always map one-to-one to NTA unit titles. Check NTA's latest syllabus for the exam year you're taking.

## Tests

Run the scheduling/date unit tests with `npm test`. The browser UI also supports manual smoke testing of chapter completion, review rating, queue resume, date filtering, and JSON backup/restore.
