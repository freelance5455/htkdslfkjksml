import test from 'node:test';
import assert from 'node:assert/strict';
import {addDaysISO, dayDiff, nextReview, sortDue, isValidISODate} from './engine.js';
test('calendar date arithmetic handles month boundaries', () => { assert.equal(addDaysISO('2026-10-31',1),'2026-11-01'); assert.equal(dayDiff('2026-10-31','2026-11-02'),2); });
test('good advances through default interval ladder', () => { const c={step:0,intervalDays:1}; const r=nextReview(c,'good','2026-10-11'); assert.equal(r.intervalDays,1); assert.equal(r.step,1); assert.equal(r.dueDate,'2026-10-12'); });
test('again schedules a short future interval, never same day', () => { const r=nextReview({step:2,intervalDays:7},'again','2026-10-11'); assert.ok(r.intervalDays>=1); assert.equal(r.dueDate,'2026-10-13'); });
test('overdue reviews stay in queue and sort oldest first', () => { const r=sortDue([{status:'completed',name:'B',dueDate:'2026-10-09'},{status:'completed',name:'A',dueDate:'2026-10-11'},{status:'studying',name:'C',dueDate:'2026-10-01'}],'2026-10-11'); assert.deepEqual(r.map(c=>c.name),['B','A']); });
test('rejects impossible dates', () => { assert.equal(isValidISODate('2026-02-30'),false); assert.equal(isValidISODate('2026-02-28'),true); });

test('easy extends the next interval beyond the first rung', () => { const r=nextReview({step:0,intervalDays:1},'easy','2026-10-11'); assert.equal(r.intervalDays,3); assert.equal(r.dueDate,'2026-10-14'); });
