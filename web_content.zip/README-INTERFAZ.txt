Cambios visuales:
- Ocultados los avatares marcados en la captura (cabecera y respuestas).
- Las respuestas de Miércoles ahora aparecen directamente sobre el fondo, sin burbuja, borde ni sombra.
- Los mensajes del usuario conservan su burbuja morada.

Este ZIP modifica únicamente la interfaz; no cambia ni verifica la conexión con Groq.
