# iPhone Reseller PRO — сервер (Python)

## Запуск
1. Установите Python 3.8+ (https://python.org). При установке на Windows поставьте галочку "Add Python to PATH".
2. Запустите:
   - Windows: двойной клик по `start.bat`
   - Mac/Linux: `./start.command` или `python3 server.py`
3. Откроется http://localhost:3000

С телефона в той же Wi-Fi сети: `http://<IP-компьютера>:3000`

## Настройки (переменные окружения)
- `PORT` — порт (по умолчанию 3000)
- `ADMIN_PASSWORD` — пароль админки (по умолчанию старый 01087987 — лучше сменить)
  Windows:  `set ADMIN_PASSWORD=мойпароль` и затем `python server.py`
  Mac/Linux: `ADMIN_PASSWORD=мойпароль python3 server.py`
- `DATA_DIR` — папка для базы (по умолчанию ./data)
- `TRUST_PROXY=1` — если сервер за nginx/Cloudflare

## Файлы
- `server.py` — сервер (без зависимостей)
- `public/index.html` — игра (аккаунты и сохранения теперь на сервере)
- `data/db.json` — аккаунты и сохранения (создаётся сам; делайте бэкап)

## API
POST /api/register, /api/login, /api/save · GET /api/leaderboard, /api/health
Админ: POST /api/admin/login · GET /api/admin/accounts · POST /api/admin/ban, /delete, /delete-all

Для интернета поставьте перед сервером HTTPS (Caddy / nginx / Cloudflare) — иначе пароли идут открытым текстом.
