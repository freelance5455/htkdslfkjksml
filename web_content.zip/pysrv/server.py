"""
iPhone Reseller PRO — игровой сервер на Python
Без зависимостей: нужен только Python 3.8+   →   python server.py

Что делает:
 - раздаёт игру (папка public/)
 - регистрация / вход (пароли хешируются scrypt)
 - хранит сохранения игроков на сервере (data/db.json)
 - админка: список, бан/разбан, удаление (пароль проверяется на сервере)
 - таблица лидеров: GET /api/leaderboard
"""
import base64
import hashlib
import hmac
import json
import os
import re
import secrets
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import unquote, urlparse

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

BASE = os.path.dirname(os.path.abspath(__file__))
PORT = int(os.environ.get("PORT", 3000))
HOST = os.environ.get("HOST", "0.0.0.0")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "01087987")
DATA_DIR = os.environ.get("DATA_DIR", os.path.join(BASE, "data"))
PUBLIC_DIR = os.path.realpath(os.path.join(BASE, "public"))
DB_FILE = os.path.join(DATA_DIR, "db.json")
SECRET_FILE = os.path.join(DATA_DIR, "secret.key")
TRUST_PROXY = bool(os.environ.get("TRUST_PROXY"))
MAX_BODY = 4 * 1024 * 1024
TOKEN_TTL = 30 * 24 * 3600
ADMIN_TOKEN_TTL = 6 * 3600
NAME_RE = re.compile(r"^[\w\-. ]{3,20}$", re.UNICODE)
BAD_NAMES = {"__proto__", "constructor", "prototype", "admin"}

os.makedirs(DATA_DIR, exist_ok=True)

# ---------- секрет для подписи токенов ----------
if os.path.exists(SECRET_FILE):
    with open(SECRET_FILE, "rb") as f:
        SECRET = f.read()
else:
    SECRET = secrets.token_bytes(32)
    with open(SECRET_FILE, "wb") as f:
        f.write(SECRET)

# ---------- база (JSON-файл) ----------
lock = threading.RLock()
db = {"users": {}}
try:
    with open(DB_FILE, "r", encoding="utf-8") as f:
        loaded = json.load(f)
        if isinstance(loaded, dict) and "users" in loaded:
            db = loaded
except (FileNotFoundError, ValueError):
    pass

_write_timer = None


def flush_db():
    global _write_timer
    with lock:
        if _write_timer:
            _write_timer.cancel()
            _write_timer = None
        tmp = DB_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(db, f, ensure_ascii=False)
        os.replace(tmp, DB_FILE)


def schedule_write():
    global _write_timer
    with lock:
        if _write_timer:
            return

        def job():
            try:
                flush_db()
            except Exception as e:
                print("DB write error:", e)

        _write_timer = threading.Timer(0.5, job)
        _write_timer.daemon = True
        _write_timer.start()


# ---------- пароли и токены ----------
def hash_password(pw):
    salt = secrets.token_bytes(16)
    h = hashlib.scrypt(pw.encode(), salt=salt, n=16384, r=8, p=1, dklen=32)
    return salt.hex() + ":" + h.hex()


def check_password(pw, stored):
    try:
        s, h = str(stored).split(":")
        calc = hashlib.scrypt(pw.encode(), salt=bytes.fromhex(s), n=16384, r=8, p=1, dklen=32)
        return hmac.compare_digest(calc, bytes.fromhex(h))
    except Exception:
        return False


def b64e(b):
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


def b64d(s):
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def make_token(sub, ttl):
    body = b64e(json.dumps({"s": sub, "e": time.time() + ttl}).encode())
    sig = b64e(hmac.new(SECRET, body.encode(), hashlib.sha256).digest())
    return body + "." + sig


def read_token(tok):
    if not isinstance(tok, str) or "." not in tok:
        return None
    body, _, sig = tok.partition(".")
    good = b64e(hmac.new(SECRET, body.encode(), hashlib.sha256).digest())
    if not hmac.compare_digest(sig, good):
        return None
    try:
        p = json.loads(b64d(body))
        return p["s"] if p["e"] > time.time() else None
    except Exception:
        return None


# ---------- ограничение попыток ----------
attempts = {}


def rate_limited(ip):
    now = time.time()
    with lock:
        for k in [k for k, v in attempts.items() if now - v[1] > 60]:
            del attempts[k]
        a = attempts.get(ip)
        if not a:
            attempts[ip] = [1, now]
            return False
        a[0] += 1
        return a[0] > 15


class ApiError(Exception):
    def __init__(self, code, msg):
        self.code, self.msg = code, msg


def user_exists(name):
    return isinstance(name, str) and name in db["users"]


# ---------- API ----------
def handle_api(method, path, body, token, ip):
    route = method + " " + path

    if route == "GET /api/health":
        return {"ok": True, "users": len(db["users"])}

    if route == "GET /api/leaderboard":
        with lock:
            rows = []
            for name, u in db["users"].items():
                g = u.get("game")
                if not g or u.get("banned"):
                    continue
                cash, debt = g.get("cash") or 0, g.get("debt") or 0
                rows.append({"name": name, "cash": round(cash), "debt": round(debt),
                             "worth": round(cash - debt), "level": g.get("level") or 1,
                             "day": g.get("day") or 1})
        rows.sort(key=lambda r: r["worth"], reverse=True)
        return {"leaderboard": rows[:20]}

    if route == "POST /api/register":
        if rate_limited(ip):
            raise ApiError(429, "Слишком много попыток, подождите минуту")
        username, password = body.get("username"), body.get("password")
        if not isinstance(username, str) or not isinstance(password, str):
            raise ApiError(400, "Введите данные")
        name = username.strip()
        if len(name) < 3:
            raise ApiError(400, "Имя < 3")
        if not NAME_RE.match(name) or name.lower() in BAD_NAMES:
            raise ApiError(400, "Недопустимое имя (3–20 символов: буквы, цифры, _ - .)")
        if len(password) < 4:
            raise ApiError(400, "Пароль < 4")
        if len(password) > 100:
            raise ApiError(400, "Пароль слишком длинный")
        pw_hash = hash_password(password)
        with lock:
            if any(k.lower() == name.lower() for k in db["users"]):
                raise ApiError(409, "Существует")
            db["users"][name] = {"password": pw_hash, "game": None, "banned": False,
                                 "created": time.time() * 1000, "lastLogin": 0, "savedAt": 0}
        schedule_write()
        return {"ok": True}

    if route == "POST /api/login":
        if rate_limited(ip):
            raise ApiError(429, "Слишком много попыток, подождите минуту")
        username, password = body.get("username"), body.get("password")
        name = username.strip() if isinstance(username, str) else ""
        if not name or not isinstance(password, str):
            raise ApiError(400, "Введите данные")
        with lock:
            u = db["users"].get(name)
        if u is None:
            raise ApiError(404, "Не найден")
        if u.get("banned"):
            raise ApiError(403, "Забанен")
        if not check_password(password, u["password"]):
            raise ApiError(401, "Неверный пароль")
        with lock:
            u["lastLogin"] = time.time() * 1000
            game = u.get("game")
        schedule_write()
        return {"token": make_token(name, TOKEN_TTL), "game": game}

    if route == "POST /api/save":
        name = read_token(token or body.get("token"))
        if not name or not user_exists(name):
            raise ApiError(401, "Сессия истекла, войдите заново")
        g = body.get("game")
        if (not isinstance(g, dict) or isinstance(g.get("cash"), bool)
                or not isinstance(g.get("cash"), (int, float))):
            raise ApiError(400, "Неверные данные сохранения")
        try:
            at = float(body.get("savedAt") or time.time() * 1000)
        except (TypeError, ValueError):
            at = time.time() * 1000
        with lock:
            u = db["users"][name]
            if u.get("banned"):
                raise ApiError(403, "Забанен")
            if at < u.get("savedAt", 0):
                return {"ok": True, "stale": True}
            u["game"], u["savedAt"] = g, at
        schedule_write()
        return {"ok": True}

    # ----- админ -----
    if route == "POST /api/admin/login":
        if rate_limited(ip):
            raise ApiError(429, "Слишком много попыток, подождите минуту")
        pw = str(body.get("password", ""))
        if not hmac.compare_digest(hashlib.sha256(pw.encode()).digest(),
                                   hashlib.sha256(ADMIN_PASSWORD.encode()).digest()):
            raise ApiError(401, "Неверный пароль")
        return {"token": make_token("__admin__", ADMIN_TOKEN_TTL)}

    if path.startswith("/api/admin/"):
        if read_token(token) != "__admin__":
            raise ApiError(401, "Нет доступа")

        if route == "GET /api/admin/accounts":
            with lock:
                acc = {}
                for n, u in db["users"].items():
                    g = u.get("game")
                    acc[n] = {"banned": bool(u.get("banned")), "lastLogin": u.get("lastLogin", 0),
                              "game": {"cash": g.get("cash") or 0, "day": g.get("day") or 1,
                                       "level": g.get("level") or 1} if g else None}
            return {"accounts": acc}

        if route == "POST /api/admin/ban":
            with lock:
                if not user_exists(body.get("user")):
                    raise ApiError(404, "Не найден")
                db["users"][body["user"]]["banned"] = bool(body.get("banned"))
            schedule_write()
            return {"ok": True}

        if route == "POST /api/admin/delete":
            with lock:
                if not user_exists(body.get("user")):
                    raise ApiError(404, "Не найден")
                del db["users"][body["user"]]
            schedule_write()
            return {"ok": True}

        if route == "POST /api/admin/delete-all":
            with lock:
                db["users"] = {}
            schedule_write()
            return {"ok": True}

    raise ApiError(404, "Нет такого метода")


# ---------- HTTP ----------
MIME = {
    ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8",
    ".css": "text/css; charset=utf-8", ".json": "application/json", ".png": "image/png",
    ".jpg": "image/jpeg", ".svg": "image/svg+xml", ".ico": "image/x-icon",
    ".webp": "image/webp", ".mp3": "audio/mpeg", ".woff2": "font/woff2",
}


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "GameServer"

    def log_message(self, fmt, *args):
        pass  # тихий режим

    def client_ip(self):
        if TRUST_PROXY:
            fwd = self.headers.get("X-Forwarded-For", "").split(",")[0].strip()
            if fwd:
                return fwd
        return self.client_address[0]

    def send_json(self, code, obj):
        data = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def read_json(self):
        n = int(self.headers.get("Content-Length") or 0)
        if n > MAX_BODY:
            self.close_connection = True
            raise ApiError(413, "Слишком большой запрос")
        if n == 0:
            return {}
        try:
            data = json.loads(self.rfile.read(n).decode("utf-8"))
        except ValueError:
            raise ApiError(400, "Неверный JSON")
        if not isinstance(data, dict):
            raise ApiError(400, "Неверный JSON")
        return data

    def api(self, method, path):
        try:
            body = self.read_json() if method == "POST" else {}
            auth = self.headers.get("Authorization", "")
            token = auth[7:] if auth.startswith("Bearer ") else None
            self.send_json(200, handle_api(method, path, body, token, self.client_ip()))
        except ApiError as e:
            self.send_json(e.code, {"error": e.msg})
        except Exception as e:
            print("Ошибка:", repr(e))
            self.send_json(500, {"error": "Ошибка сервера"})

    def static(self, head_only=False):
        p = unquote(urlparse(self.path).path)
        if p == "/":
            p = "/index.html"
        full = os.path.realpath(os.path.join(PUBLIC_DIR, p.lstrip("/")))
        if not full.startswith(PUBLIC_DIR + os.sep):
            self.send_error(403)
            return
        if not os.path.isfile(full):
            data = "404 Not Found".encode()
            self.send_response(404)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return
        ext = os.path.splitext(full)[1].lower()
        with open(full, "rb") as f:
            data = f.read()
        self.send_response(200)
        self.send_header("Content-Type", MIME.get(ext, "application/octet-stream"))
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-cache" if ext == ".html" else "public, max-age=3600")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        if not head_only:
            self.wfile.write(data)

    def do_GET(self):
        path = urlparse(self.path).path
        self.api("GET", path) if path.startswith("/api/") else self.static()

    def do_HEAD(self):
        self.static(head_only=True)

    def do_POST(self):
        path = urlparse(self.path).path
        if path.startswith("/api/"):
            self.api("POST", path)
        else:
            self.send_error(405)


class Server(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def main():
    srv = Server((HOST, PORT), Handler)
    print("\n🎮 iPhone Reseller PRO — сервер запущен")
    print(f"   Открыть:  http://localhost:{PORT}")
    print(f"   Данные:   {DB_FILE}")
    if "ADMIN_PASSWORD" not in os.environ:
        print("   ⚠️  Используется админ-пароль по умолчанию. Задайте свой: ADMIN_PASSWORD=...")
    print("   Остановить: Ctrl+C\n")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        try:
            flush_db()
        except Exception:
            pass
        print("Сервер остановлен, данные сохранены.")


if __name__ == "__main__":
    main()
