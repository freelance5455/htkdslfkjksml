/* =====================================================================
   TokClip frontend — talks to the Node/SQLite backend
   ===================================================================== */
(function () {
  'use strict';

  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));

  const TOKEN_KEY = 'tokclip_token';
  let token = localStorage.getItem(TOKEN_KEY) || '';
  let meUser = null;

  /* ---------------------------------------------------------------- */
  /* api                                                               */
  /* ---------------------------------------------------------------- */
  async function api(path, opts) {
    opts = opts || {};
    const headers = Object.assign({}, opts.headers || {});
    if (token) headers['Authorization'] = 'Bearer ' + token;
    let body = opts.body;
    if (body && !(body instanceof FormData)) {
      headers['Content-Type'] = 'application/json';
      body = JSON.stringify(body);
    }
    const res = await fetch('/api' + path, { method: opts.method || 'GET', headers, body });
    let data = null;
    try { data = await res.json(); } catch (e) { data = null; }
    if (!res.ok) {
      const err = new Error((data && data.error) || 'Request failed (' + res.status + ')');
      err.data = data;
      err.status = res.status;
      if (res.status === 401) logout(true);
      if (res.status === 403 && data && data.banned) { logout(true); showBanned(data); }
      throw err;
    }
    return data;
  }

  /* ---------------------------------------------------------------- */
  /* util                                                              */
  /* ---------------------------------------------------------------- */
  const fmt = n => {
    n = Math.max(0, Math.round(Number(n) || 0));
    if (n >= 1e9) return (n / 1e9).toFixed(n % 1e9 === 0 ? 0 : 1).replace(/\.0$/, '') + 'B';
    if (n >= 1e6) return (n / 1e6).toFixed(n % 1e6 === 0 ? 0 : 1).replace(/\.0$/, '') + 'M';
    if (n >= 1e3) return (n / 1e3).toFixed(n % 1e3 === 0 ? 0 : 1).replace(/\.0$/, '') + 'K';
    return String(n);
  };
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const hue = s => { let h = 0; s = String(s || 'x'); for (let i = 0; i < s.length; i++) h = (h * 17 + s.charCodeAt(i)) % 360; return h; };

  function avatarHTML(u, cls) {
    const c1 = 'hsl(' + hue(u && u.username) + ' 78% 62%)';
    const c2 = 'hsl(' + ((hue(u && u.username) + 48) % 360) + ' 82% 56%)';
    const letter = esc(((u && (u.name || u.username)) || '?').trim().slice(0, 1).toUpperCase());
    return '<div class="' + (cls || 'avatar') + '" style="background:linear-gradient(135deg,' + c1 + ',' + c2 + ')">' + letter + '</div>';
  }

  let toastTimer = null;
  function toast(msg) {
    const t = $('#toast');
    t.textContent = msg; t.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove('show'), 2000);
  }

  /* ---------------------------------------------------------------- */
  /* auth                                                              */
  /* ---------------------------------------------------------------- */
  let authMode = 'login';
  let pendingEmail = '';

  function showPanel(name) {
    ['Auth', 'Verify', 'Forgot', 'Reset'].forEach(p => {
      const el = $('#panel' + p);
      if (el) el.classList.toggle('hidden', p !== name);
    });
  }

  function setAuthMode(m) {
    authMode = m;
    showPanel('Auth');
    $$('#authFields [data-signup]').forEach(el => el.classList.toggle('hidden', m !== 'signup'));
    $('#authBtn').textContent = m === 'signup' ? 'Sign up' : 'Log in';
    $('#switchTxt').textContent = m === 'signup' ? 'Already have an account?' : 'New here?';
    $('#switchBtn').textContent = m === 'signup' ? 'Log in' : 'Create account';
    $('#authErr').textContent = '';
  }

  $('#switchBtn').addEventListener('click', () => setAuthMode(authMode === 'signup' ? 'login' : 'signup'));
  $('#authBtn').addEventListener('click', doAuth);
  $('#fPass').addEventListener('keydown', e => { if (e.key === 'Enter') doAuth(); });

  function devNote(el, data) {
    if (data && data.devCode) {
      el.innerHTML = '⚙ Dev mode (SMTP set nahi): aapka code <b>' + esc(data.devCode) + '</b>';
      el.classList.remove('hidden');
    } else el.classList.add('hidden');
  }

  function goVerify(email, data) {
    pendingEmail = email;
    showPanel('Verify');
    $('#verEmail').textContent = email;
    $('#verErr').textContent = '';
    $('#verCode').value = '';
    devNote($('#devCode'), data);
    setTimeout(() => $('#verCode').focus(), 80);
  }

  async function doAuth() {
    const btn = $('#authBtn');
    const err = $('#authErr');
    err.textContent = '';
    btn.disabled = true;
    const wasSignup = authMode === 'signup';
    const email = $('#fEmail').value.trim();
    const password = $('#fPass').value;
    try {
      const payload = { email, password };
      if (wasSignup) {
        payload.name = $('#fName').value.trim();
        payload.username = $('#fUser').value.trim();
      }
      const data = await api(wasSignup ? '/auth/signup' : '/auth/login', { method: 'POST', body: payload });

      if (data.needsVerification) {
        if (data.error) err.textContent = data.error;
        goVerify(data.email || email, data);
        return;
      }

      token = data.token;
      localStorage.setItem(TOKEN_KEY, token);
      meUser = data.user;
      enterApp();
      toast(wasSignup ? 'Account ban gaya — welcome ' + meUser.name.split(' ')[0] + '!' : 'Welcome back, ' + meUser.name.split(' ')[0] + '!');
    } catch (e) {
      if (e.data && e.data.banned) {
        showBanned(e.data, { email: email, password: password });
      } else if (e.data && e.data.needsVerification) {
        goVerify(e.data.email || email, e.data);
        err.textContent = e.message;
      } else {
        err.textContent = e.message;
      }
    } finally {
      btn.disabled = false;
    }
  }

  /* -------- verify email -------- */
  $('#verBtn').addEventListener('click', async () => {
    const btn = $('#verBtn');
    const err = $('#verErr');
    err.textContent = '';
    btn.disabled = true;
    try {
      const data = await api('/auth/verify', { method: 'POST', body: { email: pendingEmail, code: $('#verCode').value.trim() } });
      token = data.token;
      localStorage.setItem(TOKEN_KEY, token);
      meUser = data.user;
      enterApp();
      toast('Email verify ho gayi ✅ Welcome!');
    } catch (e) {
      if (e.data && e.data.banned) showBanned(e.data, { email: pendingEmail, password: $('#fPass').value });
      else err.textContent = e.message;
    } finally { btn.disabled = false; }
  });
  $('#verCode').addEventListener('keydown', e => { if (e.key === 'Enter') $('#verBtn').click(); });
  $('#verCode').addEventListener('input', e => {
    e.target.value = e.target.value.replace(/\D/g, '').slice(0, 6);
    if (e.target.value.length === 6) $('#verBtn').click();
  });

  $('#resendBtn').addEventListener('click', async () => {
    const el = $('#resendBtn');
    el.textContent = 'Bhej rahe hain...';
    try {
      const data = await api('/auth/resend', { method: 'POST', body: { email: pendingEmail, purpose: 'verify' } });
      devNote($('#devCode'), data);
      toast('Code dobara bhej diya 📧');
      $('#verErr').textContent = '';
    } catch (e) { toast(e.message); }
    finally { el.textContent = 'Code dobara bhejein'; }
  });

  $('#verBack').addEventListener('click', () => setAuthMode('login'));

  /* -------- forgot / reset password -------- */
  $('#forgotBtn').addEventListener('click', () => { showPanel('Forgot'); $('#fgErr').textContent = ''; $('#fgEmail').value = $('#fEmail').value.trim(); });
  $('#fgBack').addEventListener('click', () => setAuthMode('login'));
  $('#rsBack').addEventListener('click', () => setAuthMode('login'));

  $('#fgBtn').addEventListener('click', async () => {
    const email = $('#fgEmail').value.trim();
    const err = $('#fgErr');
    err.textContent = '';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) { err.textContent = 'Valid email daalein.'; return; }
    const btn = $('#fgBtn');
    btn.disabled = true;
    try {
      const data = await api('/auth/forgot', { method: 'POST', body: { email } });
      pendingEmail = email;
      $('#rsEmail').textContent = email;
      $('#rsCode').value = '';
      $('#rsPass').value = '';
      $('#rsErr').textContent = '';
      devNote($('#rsDevCode'), data);
      showPanel('Reset');
      setTimeout(() => $('#rsCode').focus(), 80);
    } catch (e) { err.textContent = e.message; }
    finally { btn.disabled = false; }
  });

  $('#rsBtn').addEventListener('click', async () => {
    const btn = $('#rsBtn');
    const err = $('#rsErr');
    err.textContent = '';
    btn.disabled = true;
    try {
      const data = await api('/auth/reset', {
        method: 'POST',
        body: { email: pendingEmail, code: $('#rsCode').value.trim(), password: $('#rsPass').value }
      });
      token = data.token;
      localStorage.setItem(TOKEN_KEY, token);
      meUser = data.user;
      enterApp();
      toast('Password badal gaya ✅');
    } catch (e) { err.textContent = e.message; }
    finally { btn.disabled = false; }
  });

  /* ---------------- banned screen + appeal ---------------- */
  function showBanned(data, creds) {
    const reason = (data && data.reason) || 'Admin ne ye account suspend kiya hai.';
    $('#banReason').textContent = reason;
    $('#app').classList.add('hidden');
    $('#view-auth').classList.add('hidden');
    $('#view-banned').classList.remove('hidden');
    $('#aErr').textContent = '';

    const state = $('#banAppealState');
    const form = $('#appealForm');
    const ap = data && data.appeal;
    state.innerHTML = '';

    if (ap) {
      const cls = ap.status === 'pending' ? 'pending' : ap.status === 'approved' ? 'approved' : 'rejected';
      const label = ap.status === 'pending' ? '⏳ Appeal pending hai'
        : ap.status === 'approved' ? '✅ Appeal approve ho gayi'
        : '❌ Appeal reject ho gayi';
      state.innerHTML =
        '<div class="appeal-state ' + cls + '"><b>' + label + '</b><br>' +
        'Aapki appeal: \u201c' + esc(ap.message) + '\u201d' +
        (ap.note ? '<br><b>Admin note:</b> ' + esc(ap.note) : '') +
        (ap.status === 'pending' ? '<br>Admin review karega — thoda intezaar karein.' : '') +
        (ap.status === 'rejected' ? '<br>Aap dobara appeal bhej sakte hain.' : '') +
        '</div>';
      form.classList.toggle('hidden', ap.status === 'pending' || ap.status === 'approved');
    } else {
      form.classList.remove('hidden');
    }

    const credsBox = $('#banCreds');
    if (creds && creds.email) {
      $('#aEmail').value = creds.email;
      $('#aPass').value = creds.password || '';
      credsBox.classList.add('hidden');
    } else {
      credsBox.classList.remove('hidden');
    }
  }

  $('#aBack').addEventListener('click', () => {
    $('#view-banned').classList.add('hidden');
    $('#view-auth').classList.remove('hidden');
    setAuthMode('login');
  });

  $('#aBtn').addEventListener('click', submitAppeal);

  async function submitAppeal() {
    const btn = $('#aBtn');
    const err = $('#aErr');
    err.textContent = '';
    const message = $('#aMsg').value.trim();
    const needsCreds = !$('#banCreds').classList.contains('hidden');
    const email = $('#aEmail').value.trim();
    const password = $('#aPass').value;

    if (message.length < 10) { err.textContent = 'Appeal kam az kam 10 characters likhein.'; return; }
    if (needsCreds && (!email || !password)) { err.textContent = 'Email aur password daalein.'; return; }

    btn.disabled = true;
    btn.textContent = 'Bhej rahe hain...';
    try {
      await api('/appeal', { method: 'POST', body: { email, password, message } });
      showBanned({ reason: $('#banReason').textContent, appeal: { status: 'pending', message } });
      toast('Appeal bhej di gayi ✅');
    } catch (e) {
      if (e.data && e.data.pending) {
        showBanned({ reason: $('#banReason').textContent, appeal: { status: 'pending', message } });
      } else {
        err.textContent = e.message;
      }
    } finally {
      btn.disabled = false;
      btn.textContent = 'Appeal bhejein';
    }
  }

  function logout(silent) {
    token = '';
    localStorage.removeItem(TOKEN_KEY);
    meUser = null;
    feed.items = []; feed.cursor = null; feed.hasMore = true; feed.loading = false;
    viewed.clear();
    $('#app').classList.add('hidden');
    $('#view-auth').classList.remove('hidden');
    $('#fPass').value = '';
    setAuthMode('login');
    clearInterval(unreadTimer);
    clearInterval(presenceTimer);
    clearInterval(chat.timer);
    setNavUnread(0);
    officialUnread = 0;
    renderOfficialBadge();
    renderOfficialBanner();
    if (!silent) toast('Log out ho gaya');
  }

  let unreadTimer = null, presenceTimer = null;
  function startPresenceHeartbeat() {
    clearInterval(presenceTimer);
    const ping = () => { if (token) api('/presence/ping', { method: 'POST' }).catch(() => {}); };
    ping();
    presenceTimer = setInterval(ping, 25000);
    document.addEventListener('visibilitychange', () => { if (!document.hidden) ping(); });
  }
  function enterApp() {
    $('#view-auth').classList.add('hidden');
    $('#app').classList.remove('hidden');
    go('feed');
    refreshUnread();
    clearInterval(unreadTimer);
    unreadTimer = setInterval(refreshUnread, 20000);
    startPresenceHeartbeat();
  }

  /* ---------------------------------------------------------------- */
  /* router                                                            */
  /* ---------------------------------------------------------------- */
  let currentView = 'feed';
  function go(view) {
    currentView = view;
    $$('.view').forEach(v => v.classList.add('hidden'));
    const el = $('#view-' + view);
    if (el) el.classList.remove('hidden');
    $$('#nav button').forEach(b => b.classList.toggle('active',
      b.dataset.go === view || (view === 'chat' && b.dataset.go === 'inbox')));
    if (view === 'feed') { if (!feed.items.length) refreshFeed(); }
    if (view === 'discover') loadDiscover();
    if (view === 'inbox') loadInbox();
    if (view === 'profile') loadProfile();
  }
  $('#nav').addEventListener('click', e => {
    const b = e.target.closest('button[data-go]');
    if (b) go(b.dataset.go);
  });

  /* ---------------------------------------------------------------- */
  /* feed                                                              */
  /* ---------------------------------------------------------------- */
  const feed = { tab: 'foryou', items: [], cursor: null, hasMore: true, loading: false };
  const viewed = new Set();
  let io = null;

  $('#topTabs').addEventListener('click', e => {
    const b = e.target.closest('button[data-tab]');
    if (!b) return;
    feed.tab = b.dataset.tab;
    $$('#topTabs button').forEach(x => x.classList.toggle('active', x === b));
    refreshFeed();
  });

  async function refreshFeed() {
    const box = $('#feed');
    box.innerHTML = skeletonSlides(2);
    feed.items = []; feed.cursor = null; feed.hasMore = true;
    try {
      await loadFeedPage(true);
      if (!feed.items.length) {
        if (feed.tab === 'following') { renderFollowingEmpty(box); return; }
        box.innerHTML = '<div class="slide"><div class="fallback"><div>' +
          '<div style="font-size:40px;margin-bottom:14px">🎬</div>' +
          '<div style="font-size:15px;font-weight:700;margin-bottom:8px">Abhi koi video nahi</div>' +
          '<div style="font-size:13px;color:#8a8a96;line-height:1.6">Sab se pehli video aap upload karein — neeche “+” dabayein.</div>' +
          '</div></div></div>';
      }
    } catch (e) {
      box.innerHTML = '<div class="slide"><div class="fallback"><span>' + esc(e.message) + '</span></div></div>';
    }
  }

  /* skeletons */
  function skeletonSlides(n) {
    let html = '';
    for (let i = 0; i < n; i++) {
      html += '<div class="sk-slide"><div class="sk-bg sk"></div>' +
        '<div class="sk-rail"><div class="sk"></div><div class="sq sk"></div><div class="sq sk"></div><div class="sq sk"></div></div>' +
        '<div class="sk-meta"><div class="sk-line sk w40"></div><div class="sk-line sk w75"></div><div class="sk-line sk w55"></div></div></div>';
    }
    return html;
  }
  function skeletonRows(n) {
    let html = '';
    for (let i = 0; i < n; i++) {
      html += '<div class="sk-row"><div class="sk-av sk"></div><div class="sk-col">' +
        '<div class="sk-line sk" style="width:45%"></div><div class="sk-line sk" style="width:65%"></div></div></div>';
    }
    return html;
  }
  function skeletonGrid(n) {
    let html = '<div class="disc-grid">';
    for (let i = 0; i < n; i++) html += '<div class="sk-cell sk"></div>';
    return html + '</div>';
  }

  /* following feed khali ho to suggested creators */
  async function renderFollowingEmpty(box) {
    box.innerHTML =
      '<div class="follow-empty">' +
        '<h3>Aapki Following feed khali hai</h3>' +
        '<p>Kisi creator ko follow karein — unki nayi videos yahan sab se pehle dikhengi.</p>' +
        '<div id="fuList">' + skeletonRows(4) + '</div>' +
      '</div>';
    try {
      const data = await api('/suggested');
      const items = (data.items || []).slice(0, 6);
      if (!items.length) {
        $('#fuList').innerHTML = '<p class="search-empty">Abhi koi creator nahi hai. “For You” tab try karein.</p>';
        return;
      }
      $('#fuList').innerHTML = items.map(userRowHTML).join('');
      wireFollowButtons($('#fuList'), () => refreshFeed());
    } catch (e) {
      $('#fuList').innerHTML = '<p class="search-empty">' + esc(e.message) + '</p>';
    }
  }

  /* user row + follow buttons (discover, search, following-empty mein reuse) */
  function userRowHTML(u) {
    return '<div class="user-row" data-uid="' + u.id + '">' + avatarHTML(u) +
      '<div class="u-info"><div class="u-name">' + esc(u.name || u.username) + '</div>' +
      '<div class="u-sub">@' + esc(u.username) + ' · ' + fmt(u.followers) + ' followers</div></div>' +
      '<button class="follow-sm' + (u.isFollowing ? ' on' : '') + '" data-follow="' + u.id + '">' +
      (u.isFollowing ? 'Following' : 'Follow') + '</button></div>';
  }

  function wireFollowButtons(scope, cb) {
    $$('[data-follow]', scope).forEach(btn => btn.addEventListener('click', async () => {
      const uid = btn.dataset.follow;
      btn.disabled = true;
      try {
        const r = await api('/users/' + uid + '/follow', { method: 'POST' });
        btn.classList.toggle('on', r.following);
        btn.textContent = r.following ? 'Following' : 'Follow';
        $$('#feed .slide').forEach(s => {
          if (!s._data || s._data.author.id !== uid) return;
          s._data.author.isFollowing = r.following;
          s._data.author.followers = r.followers;
          const b = $('[data-act="follow"]', s);
          if (b) { b.classList.toggle('on', r.following); b.textContent = r.following ? '✓' : '+'; }
        });
        if (cb) cb(r);
      } catch (e) { toast(e.message); }
      finally { btn.disabled = false; }
    }));
  }

  const hiddenKey = 'tokclip_hidden';
  function hiddenIds() {
    try { return JSON.parse(localStorage.getItem(hiddenKey) || '[]'); } catch (e) { return []; }
  }
  function hideVideo(id) {
    const arr = hiddenIds();
    if (arr.indexOf(id) === -1) arr.push(id);
    localStorage.setItem(hiddenKey, JSON.stringify(arr.slice(-300)));
  }

  async function loadFeedPage(first) {
    if (!token) { refreshFeedAnon(); return; }
    const params = new URLSearchParams({ tab: feed.tab, limit: '6' });
    if (feed.cursor) params.set('before', String(feed.cursor));
    const data = await api('/feed?' + params.toString());
    const hidden = hiddenIds();
    const items = (data.items || []).filter(v => hidden.indexOf(v.id) === -1);
    if (first) $('#feed').innerHTML = '';

    if (!items.length) {
      // loop the feed forever (TikTok-style endless scroll)
      if (!first) { feed.cursor = null; feed.hasMore = true; }
      return;
    }
    feed.cursor = items[items.length - 1].createdAt;
    feed.hasMore = data.hasMore;
    items.forEach(v => { feed.items.push(v); $('#feed').appendChild(makeSlide(v)); });
    setTimeout(setupIO, 30);
  }

  function refreshFeedAnon() { /* handled by auth gate */ }

  $('#feed').addEventListener('scroll', () => {
    const box = $('#feed');
    if (feed.loading) return;
    if (box.scrollTop + box.clientHeight > box.scrollHeight - box.clientHeight * 1.4) {
      if (!feed.hasMore) feed.cursor = null;   // restart from top → endless
      feed.loading = true;
      loadFeedPage(false).catch(() => {}).finally(() => { feed.loading = false; });
    }
  });

  function makeSlide(v) {
    const liked = !!v.liked;
    const el = document.createElement('div');
    el.className = 'slide';
    el.dataset.vid = v.id;
    el.dataset.uid = v.author.id;

    const followBtn = (!v.mine)
      ? '<div class="plus ' + (v.author.isFollowing ? 'on' : '') + '" data-act="follow">' +
        (v.author.isFollowing ? '✓' : '+') + '</div>'
      : '';

    el.innerHTML =
      '<div class="fallback"><span>' + esc(v.caption || 'Video') + '</span></div>' +
      '<video playsinline loop preload="metadata" muted></video>' +
      '<div class="grad"></div>' +
      '<button class="mutebtn" data-act="mute">🔇</button>' +
      '<div class="bigheart">❤️</div>' +
      '<div class="rail">' +
        '<div class="avatar-wrap">' + avatarHTML(v.author) + followBtn + '</div>' +
        '<div class="item ' + (liked ? 'liked' : '') + '" data-act="like"><span class="ico">' + (liked ? '❤️' : '🤍') + '</span><span class="cnt" data-role="likes">' + fmt(v.likes) + '</span></div>' +
        '<div class="item" data-act="comments"><span class="ico">💬</span><span class="cnt" data-role="comments">' + fmt(v.comments) + '</span></div>' +
        '<div class="item" data-act="share"><span class="ico">↗️</span><span class="cnt">Share</span></div>' +
      '</div>' +
      '<div class="meta">' +
        '<div class="who"><span class="handle">@' + esc(v.author.username) + '</span>' +
          '<span class="dot">·</span><span class="dot">' + esc(v.author.name || '') + '</span></div>' +
        '<p class="cap">' + esc(v.caption || '') + '</p>' +
        '<div class="sound"><span class="eq"><i></i><i></i><i></i></span>' + esc(v.sound || 'original sound') + '</div>' +
      '</div>';

    const vid = $('video', el);
    vid.addEventListener('loadeddata', () => el.classList.add('ready'), { once: true });
    vid.addEventListener('error', () => el.classList.remove('ready'), { once: true });
    vid.src = v.url;
    el._data = v;
    return el;
  }

  function setupIO() {
    if (io) io.disconnect();
    io = new IntersectionObserver(entries => {
      entries.forEach(en => {
        const slide = en.target;
        const vid = $('video', slide);
        if (!vid) return;
        if (en.isIntersecting && en.intersectionRatio > 0.6) {
          $$('#feed video').forEach(o => { if (o !== vid) o.pause(); });
          const p = vid.play();
          if (p && p.catch) p.catch(() => {});
          countView(slide);
        } else {
          vid.pause();
        }
      });
    }, { root: $('#feed'), threshold: [0, 0.6, 0.95] });
    $$('#feed .slide').forEach(s => io.observe(s));
  }

  async function countView(slide) {
    const v = slide._data;
    if (!v || viewed.has(v.id)) return;
    viewed.add(v.id);
    try { await api('/videos/' + v.id + '/view', { method: 'POST' }); } catch (e) { /* ignore */ }
  }

  /* ---------------- feed interactions ---------------- */
  $('#feed').addEventListener('click', e => {
    const slide = e.target.closest('.slide');
    if (!slide || !slide._data) return;
    const act = e.target.closest('[data-act]');
    if (lpFired && !act) return;

    if (!act) {
      const vid = $('video', slide);
      if (vid) {
        vid.muted = !vid.muted;
        const b = $('.mutebtn', slide);
        if (b) b.textContent = vid.muted ? '🔇' : '🔊';
      }
      return;
    }

    const a = act.dataset.act;
    if (a === 'like') doLike(slide);
    else if (a === 'comments') openComments(slide._data);
    else if (a === 'share') shareVideo(slide._data);
    else if (a === 'follow') doFollow(slide);
    else if (a === 'mute') {
      const vid = $('video', slide);
      if (vid) { vid.muted = !vid.muted; act.textContent = vid.muted ? '🔇' : '🔊'; }
    }
  });

  $('#feed').addEventListener('dblclick', e => {
    const slide = e.target.closest('.slide');
    if (!slide || !slide._data) return;
    bigHeart(slide);
    if (!slide._data.liked) doLike(slide, true);
  });

  function bigHeart(slide) {
    const h = $('.bigheart', slide);
    if (!h) return;
    h.classList.remove('pop');
    void h.offsetWidth;
    h.classList.add('pop');
  }

  const slidesFor = id => $$('#feed .slide').filter(s => s._data && s._data.id === id);

  async function doLike(slide, silent) {
    const v = slide._data;
    try {
      const r = await api('/videos/' + v.id + '/like', { method: 'POST' });
      v.liked = r.liked; v.likes = r.likes;
      slidesFor(v.id).forEach(s => {
        s._data.liked = r.liked; s._data.likes = r.likes;
        const btn = $('[data-act="like"]', s);
        if (!btn) return;
        btn.classList.toggle('liked', r.liked);
        $('.ico', btn).textContent = r.liked ? '❤️' : '🤍';
        $('[data-role="likes"]', btn).textContent = fmt(r.likes);
      });
      if (r.liked && !silent) { /* no toast, too noisy */ }
    } catch (e) { toast(e.message); }
  }

  async function doFollow(slide) {
    const v = slide._data;
    try {
      const r = await api('/users/' + v.author.id + '/follow', { method: 'POST' });
      $$('#feed .slide').forEach(s => {
        if (!s._data || s._data.author.id !== v.author.id) return;
        s._data.author.isFollowing = r.following;
        s._data.author.followers = r.followers;
        const b = $('[data-act="follow"]', s);
        if (b) { b.classList.toggle('on', r.following); b.textContent = r.following ? '✓' : '+'; }
      });
      toast(r.following ? 'Following @' + v.author.username : 'Unfollowed @' + v.author.username);
      if (feed.tab === 'following') refreshFeed();
    } catch (e) { toast(e.message); }
  }

  function shareVideo(v) {
    const link = location.origin + '/?v=' + v.id;
    openSheet(
      '<h3>Options</h3>' +
      '<p class="sub">' + esc((v.caption || 'Video').slice(0, 60)) + '</p>' +
      '<div class="row"><button class="btn ghost" id="copyLink">🔗 Copy link</button></div>' +
      '<div class="row" style="margin-top:10px"><button class="btn ghost" id="reportBtn" style="color:#ff6b81">🚩 Report video</button></div>' +
      '<p class="note">Report seedha admin panel mein jayegi.</p>'
    );
    $('#copyLink').addEventListener('click', () => {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(link).then(() => { closeSheet(); toast('Link copy ho gaya'); }).catch(() => toast(link));
      } else toast(link);
    });
    $('#reportBtn').addEventListener('click', () => openReport(v));
  }

  function openReport(v) {
    const reasons = ['Spam', 'Nudity', 'Violence', 'Harassment', 'Copyright', 'Other'];
    openSheet(
      '<h3>Report video</h3><p class="sub">Wajah chunein — admin review karega.</p>' +
      '<div class="chips" id="reasons">' +
        reasons.map(r => '<button data-r="' + r + '">' + r + '</button>').join('') +
      '</div>' +
      '<div class="row"><button class="btn" id="sendReport" disabled>Send report</button></div>'
    );
    let picked = null;
    $$('#reasons button').forEach(b => b.addEventListener('click', () => {
      $$('#reasons button').forEach(x => x.style.background = '');
      b.style.background = 'rgba(254,44,85,.28)';
      b.style.borderColor = '#fe2c55';
      picked = b.dataset.r;
      $('#sendReport').disabled = false;
    }));
    $('#sendReport').addEventListener('click', async () => {
      if (!picked) return;
      const btn = $('#sendReport');
      btn.disabled = true;
      try {
        await api('/videos/' + v.id + '/report', { method: 'POST', body: { reason: picked } });
        closeSheet();
        toast('Report bhej di gayi — admin check karega ✅');
      } catch (e) { toast(e.message); btn.disabled = false; }
    });
  }

  /* ---------------- long-press → video options ---------------- */
  let lpTimer = null, lpStart = null, lpFired = false;

  $('#feed').addEventListener('pointerdown', e => {
    const slide = e.target.closest('.slide');
    if (!slide || !slide._data) return;
    if (e.target.closest('[data-act]')) return;
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    lpStart = { x: e.clientX, y: e.clientY };
    clearTimeout(lpTimer);
    lpTimer = setTimeout(() => {
      lpFired = true;
      if (navigator.vibrate) { try { navigator.vibrate(12); } catch (err) {} }
      openVideoOptions(slide);
      setTimeout(() => { lpFired = false; }, 700);
    }, 480);
  });

  $('#feed').addEventListener('pointermove', e => {
    if (!lpStart) return;
    if (Math.abs(e.clientX - lpStart.x) > 12 || Math.abs(e.clientY - lpStart.y) > 12) clearTimeout(lpTimer);
  }, true);

  ['pointerup', 'pointercancel'].forEach(ev =>
    document.addEventListener(ev, () => { clearTimeout(lpTimer); lpStart = null; }, true));

  $('#feed').addEventListener('contextmenu', e => {
    const slide = e.target.closest('.slide');
    if (!slide || !slide._data) return;
    e.preventDefault();
    openVideoOptions(slide);
  });

  function openVideoOptions(slide) {
    const v = slide._data;
    openSheet(
      '<h3>@' + esc(v.author.username) + '</h3>' +
      '<p class="sub">' + esc((v.caption || '').slice(0, 90)) + '</p>' +
      '<button class="vopt" id="optSave"><span class="vi">⬇️</span>Save video<span class="vsub">device</span></button>' +
      '<button class="vopt" id="optCopy"><span class="vi">🔗</span>Copy link</button>' +
      (v.mine ? '' : '<button class="vopt" id="optMsg"><span class="vi">✉️</span>Message @' + esc(v.author.username) + '</button>') +
      (v.mine ? '' : '<button class="vopt" id="optFollow"><span class="vi">' + (v.author.isFollowing ? '✓' : '➕') + '</span>' +
        (v.author.isFollowing ? 'Unfollow' : 'Follow') + ' @' + esc(v.author.username) + '</button>') +
      '<button class="vopt" id="optNotInterested"><span class="vi">🚫</span>Not interested<span class="vsub">is video ko chhupayein</span></button>' +
      '<button class="vopt danger" id="optReport"><span class="vi">🚩</span>Report</button>'
    );

    $('#optSave').addEventListener('click', () => {
      const a = document.createElement('a');
      a.href = v.url;
      a.download = 'tokclip-' + v.id + '.mp4';
      document.body.appendChild(a);
      a.click();
      a.remove();
      closeSheet();
      toast('Video download ho rahi hai...');
    });

    $('#optCopy').addEventListener('click', () => {
      const link = location.origin + '/?v=' + v.id;
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(link).then(() => { closeSheet(); toast('Link copy ho gaya'); }).catch(() => toast(link));
      } else { closeSheet(); toast(link); }
    });

    if ($('#optMsg')) {
      $('#optMsg').addEventListener('click', () => { closeSheet(); openChat(v.author, v.author.isAdmin); });
    }

    if ($('#optFollow')) {
      $('#optFollow').addEventListener('click', () => { closeSheet(); doFollow(slide); });
    }

    $('#optNotInterested').addEventListener('click', () => {
      hideVideo(v.id);
      feed.items = feed.items.filter(x => x.id !== v.id);
      slidesFor(v.id).forEach(s => s.remove());
      closeSheet();
      toast('Samajh gaya — aise videos kam dikhengi');
      setTimeout(() => { if (!$('#feed .slide')) refreshFeed(); }, 250);
    });

    $('#optReport').addEventListener('click', () => { closeSheet(); openReport(v); });
  }

  /* ---------------------------------------------------------------- */
  /* upload                                                            */
  /* ---------------------------------------------------------------- */
  let pendingFile = null;

  $('#drop').addEventListener('click', () => $('#file').click());

  ['dragenter', 'dragover'].forEach(ev => $('#drop').addEventListener(ev, e => {
    e.preventDefault(); $('#drop').classList.add('drag');
  }));
  ['dragleave', 'drop'].forEach(ev => $('#drop').addEventListener(ev, e => {
    e.preventDefault(); $('#drop').classList.remove('drag');
  }));
  $('#drop').addEventListener('drop', e => {
    const f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
    if (f) acceptFile(f);
  });

  $('#file').addEventListener('change', e => {
    const f = e.target.files && e.target.files[0];
    if (f) acceptFile(f);
  });

  function humanSize(b) {
    if (b > 1048576) return (b / 1048576).toFixed(1) + ' MB';
    if (b > 1024) return (b / 1024).toFixed(0) + ' KB';
    return b + ' B';
  }

  function acceptFile(f) {
    if (!/^video\//.test(f.type) && !/\.(mp4|webm|mov|m4v|ogv)$/i.test(f.name)) {
      toast('Sirf video file chunein');
      return;
    }
    if (f.size > 300 * 1024 * 1024) { toast('Video 300MB se choti honi chahiye'); return; }
    pendingFile = f;
    const p = $('#preview');
    if (p.src) URL.revokeObjectURL(p.src);
    p.src = URL.createObjectURL(f);
    $('#fileName').textContent = f.name || 'video.mp4';
    $('#fileSub').textContent = humanSize(f.size) + ' · processing...';
    $('#fileCard').classList.remove('hidden');
    $('#drop').classList.add('hidden');
    $('#postBtn').disabled = false;

    p.onloadedmetadata = () => {
      const secs = isFinite(p.duration) ? p.duration : 0;
      const mm = Math.floor(secs / 60), ss = Math.round(secs % 60);
      $('#fileSub').textContent = humanSize(f.size) + ' · ' + mm + ':' + String(ss).padStart(2, '0');
    };
  }

  $('#clearBtn').addEventListener('click', clearUpload);

  function clearUpload() {
    pendingFile = null;
    $('#file').value = '';
    $('#cap').value = '';
    updateCapCount();
    const p = $('#preview');
    if (p.src) URL.revokeObjectURL(p.src);
    p.removeAttribute('src');
    $('#fileCard').classList.add('hidden');
    $('#drop').classList.remove('hidden');
    $('#progWrap').classList.add('hidden');
    $('#progBar').style.width = '0%';
    $('#postBtn').disabled = true;
    $('#postBtn').textContent = 'Post video';
  }

  /* caption counter + hashtag chips */
  function updateCapCount() {
    const len = $('#cap').value.length;
    $('#capCount').textContent = len + '/300';
  }
  $('#cap').addEventListener('input', updateCapCount);

  $('#capTags').addEventListener('click', e => {
    const b = e.target.closest('button[data-tag]');
    if (!b) return;
    const tag = '#' + b.dataset.tag;
    const cap = $('#cap');
    if (cap.value.indexOf(tag) !== -1) { toast(tag + ' already hai'); return; }
    cap.value = (cap.value.trim() + ' ' + tag).trim().slice(0, 300);
    updateCapCount();
    cap.focus();
  });

  $('#postBtn').disabled = true;

  $('#postBtn').addEventListener('click', () => {
    if (!pendingFile) { toast('Pehle video select karein'); return; }
    const btn = $('#postBtn');
    const fd = new FormData();
    fd.append('video', pendingFile);
    fd.append('caption', $('#cap').value.trim());

    const xhr = new XMLHttpRequest();
    xhr.open('POST', '/api/videos');
    xhr.setRequestHeader('Authorization', 'Bearer ' + token);
    $('#progWrap').classList.remove('hidden');
    btn.disabled = true; btn.textContent = 'Uploading 0%';

    xhr.upload.onprogress = ev => {
      if (!ev.lengthComputable) return;
      const pct = Math.round((ev.loaded / ev.total) * 100);
      $('#progBar').style.width = pct + '%';
      btn.textContent = 'Uploading ' + pct + '%';
    };

    xhr.onload = () => {
      btn.disabled = false; btn.textContent = 'Post video';
      let data = null;
      try { data = JSON.parse(xhr.responseText); } catch (e) {}
      if (xhr.status >= 200 && xhr.status < 300) {
        clearUpload();
        toast('Video post ho gayi ✅');
        feed.items = []; feed.cursor = null; feed.hasMore = true;
        discoverLoaded = false;
        go('profile');
      } else {
        toast((data && data.error) || 'Upload fail ho gaya');
        $('#progWrap').classList.add('hidden');
      }
    };
    xhr.onerror = () => {
      btn.disabled = false; btn.textContent = 'Post video';
      $('#progWrap').classList.add('hidden');
      toast('Network error — dobara try karein');
    };
    xhr.send(fd);
  });

  /* ---------------------------------------------------------------- */
  /* discover + search                                                 */
  /* ---------------------------------------------------------------- */
  let discoverLoaded = false;
  let searchTimer = null;
  let searchSeq = 0;

  async function loadDiscover(force) {
    const box = $('#discoverDefault');
    if (discoverLoaded && !force) return;
    box.innerHTML =
      '<div class="sec-title">Trending hashtags</div>' + skeletonRows(1) +
      '<div class="sec-title">Suggested creators</div>' + skeletonRows(3) +
      '<div class="sec-title">Popular now</div>' + skeletonGrid(6);
    try {
      const d = await api('/discover');
      renderDiscover(d);
      discoverLoaded = true;
    } catch (e) {
      box.innerHTML = '<div class="search-empty">' + esc(e.message) + '</div>';
    }
  }

  function hashtagChipsHTML(tags) {
    if (!tags || !tags.length) return '';
    return '<div class="tag-chips">' + tags.map(t =>
      '<button data-hashtag="' + esc(t.tag) + '">#' + esc(t.tag) + '<span class="cnt">' + fmt(t.count) + '</span></button>'
    ).join('') + '</div>';
  }

  function videoGridHTML(videos) {
    return '<div class="disc-grid">' + videos.map(v =>
      '<div class="disc-cell" data-vid="' + v.id + '">' +
        '<video preload="metadata" muted playsinline src="' + esc(v.url) + '#t=0.1"></video>' +
        '<div class="views">▶ ' + fmt(v.views) + '</div>' +
      '</div>').join('') + '</div>';
  }

  function renderDiscover(d) {
    const tags = d.hashtags || [];
    const creators = d.creators || [];
    const trending = d.trending || [];

    $('#discoverDefault').innerHTML =
      '<div class="sec-title">Trending hashtags</div>' +
      (tags.length ? hashtagChipsHTML(tags) : '<p class="search-empty" style="padding:0 0 16px">Abhi koi hashtag nahi — pehli video par #fyp lagaayein.</p>') +
      '<div class="sec-title">Suggested creators <small>swipe →</small></div>' +
      '<div class="creator-row">' + (creators.length
        ? creators.slice(0, 10).map(c =>
            '<div class="creator-card">' + avatarHTML(c) +
            '<div class="cname">' + esc(c.name || c.username) + '</div>' +
            '<div class="csub">@' + esc(c.username) + '</div>' +
            '<div class="csub">' + fmt(c.followers) + ' followers</div>' +
            '<button class="btn-mini' + (c.isFollowing ? ' on' : '') + '" data-follow="' + c.id + '">' +
              (c.isFollowing ? 'Following' : 'Follow') + '</button></div>').join('')
        : '<span class="search-empty" style="padding:0">Abhi koi creator nahi</span>') + '</div>' +
      '<div class="sec-title">Popular now</div>' +
      (trending.length ? videoGridHTML(trending) : '<p class="search-empty">Abhi koi video nahi</p>');

    wireFollowButtons($('#discoverDefault'), () => {});
    $$('#discoverDefault [data-hashtag]').forEach(b => b.addEventListener('click', () => {
      $('#searchInput').value = '#' + b.dataset.hashtag;
      $('#searchClear').classList.remove('hidden');
      doSearch('#' + b.dataset.hashtag);
    }));
    $$('#discoverDefault [data-vid]').forEach(cell => cell.addEventListener('click', () => {
      const v = trending.find(x => x.id === cell.dataset.vid);
      if (v) openVideoPreview(v);
    }));
  }

  /* video preview sheet (discover/search se) */
  function openVideoPreview(v) {
    openSheet(
      '<div class="preview-wrap"><video src="' + esc(v.url) + '" controls autoplay loop playsinline></video></div>' +
      '<div class="preview-meta">' +
        '<div class="pm-user"><b>@' + esc(v.author.username) + '</b><span class="pm-name">' + esc(v.author.name || '') + '</span></div>' +
        '<div class="pm-cap">' + esc(v.caption || '') + '</div>' +
        '<div class="pm-stats">▶ ' + fmt(v.views) + ' views · ❤️ ' + fmt(v.likes) + ' · 💬 ' + fmt(v.comments) + '</div>' +
      '</div>' +
      '<div class="preview-actions">' +
        '<button class="mini-btn' + (v.liked ? ' ok-btn' : '') + '" id="pvLike">' + (v.liked ? '❤️ Liked' : '🤍 Like') + '</button>' +
        (v.mine ? '<span class="mini-btn">Your video</span>'
          : '<button class="mini-btn' + (v.author.isFollowing ? ' ok-btn' : '') + '" id="pvFollow">' + (v.author.isFollowing ? 'Following' : 'Follow') + '</button>') +
        '<button class="mini-btn" id="pvShare">Share</button>' +
      '</div>'
    );

    $('#pvLike').addEventListener('click', async () => {
      if (v.mine) return;
      try {
        const r = await api('/videos/' + v.id + '/like', { method: 'POST' });
        v.liked = r.liked; v.likes = r.likes;
        const b = $('#pvLike');
        b.textContent = r.liked ? '❤️ Liked' : '🤍 Like';
        b.classList.toggle('ok-btn', r.liked);
      } catch (e) { toast(e.message); }
    });

    if ($('#pvFollow')) $('#pvFollow').addEventListener('click', async () => {
      try {
        const r = await api('/users/' + v.author.id + '/follow', { method: 'POST' });
        v.author.isFollowing = r.following;
        const b = $('#pvFollow');
        b.textContent = r.following ? 'Following' : 'Follow';
        b.classList.toggle('ok-btn', r.following);
      } catch (e) { toast(e.message); }
    });

    $('#pvShare').addEventListener('click', () => {
      const link = location.origin + '/?v=' + v.id;
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(link).then(() => toast('Link copy ho gaya')).catch(() => toast(link));
      } else toast(link);
    });
  }

  /* search */
  $('#searchInput').addEventListener('input', e => {
    const q = e.target.value.trim();
    $('#searchClear').classList.toggle('hidden', !q);
    clearTimeout(searchTimer);
    if (!q) {
      $('#searchResults').classList.add('hidden');
      $('#discoverDefault').classList.remove('hidden');
      $('#searchResults').innerHTML = '';
      return;
    }
    searchTimer = setTimeout(() => doSearch(q), 280);
  });

  $('#searchClear').addEventListener('click', () => {
    $('#searchInput').value = '';
    $('#searchClear').classList.add('hidden');
    $('#searchResults').classList.add('hidden');
    $('#searchResults').innerHTML = '';
    $('#discoverDefault').classList.remove('hidden');
    $('#searchInput').focus();
  });

  async function doSearch(q) {
    const box = $('#searchResults');
    $('#discoverDefault').classList.add('hidden');
    box.classList.remove('hidden');
    box.innerHTML = '<div class="sec-title">Searching…</div>' + skeletonRows(3) + skeletonGrid(6);
    const seq = ++searchSeq;
    try {
      const d = await api('/search?q=' + encodeURIComponent(q));
      if (seq !== searchSeq) return;
      const users = d.users || [];
      const videos = d.videos || [];
      const tags = d.hashtags || [];

      if (!users.length && !videos.length && !tags.length) {
        box.innerHTML = '<div class="search-empty">“' + esc(q) + '” ke liye kuch nahi mila.<br>Doosra keyword try karein.</div>';
        return;
      }

      box.innerHTML =
        (tags.length ? '<div class="sec-title">Hashtags</div>' + hashtagChipsHTML(tags) : '') +
        (users.length ? '<div class="sec-title">Creators</div>' + users.map(userRowHTML).join('') : '') +
        (videos.length ? '<div class="sec-title">Videos</div>' + videoGridHTML(videos) : '');

      wireFollowButtons(box, () => {});
      $$('[data-hashtag]', box).forEach(b => b.addEventListener('click', () => {
        $('#searchInput').value = '#' + b.dataset.hashtag;
        doSearch('#' + b.dataset.hashtag);
      }));
      $$('[data-vid]', box).forEach(cell => cell.addEventListener('click', () => {
        const v = videos.find(x => x.id === cell.dataset.vid);
        if (v) openVideoPreview(v);
      }));
    } catch (e) {
      if (seq === searchSeq) box.innerHTML = '<div class="search-empty">' + esc(e.message) + '</div>';
    }
  }

  /* ---------------------------------------------------------------- */
  /* chat / DMs                                                        */
  /* ---------------------------------------------------------------- */
  const chat = { userId: null, user: null, timer: null, typingTimer: null, presenceTimer: null, lastKey: '', typingOn: false, lastPing: 0, online: null, lastSeen: 0, archOpen: false };

  function setNavUnread(n) {
    const el = $('#navUnread');
    if (!el) return;
    if (n > 0) {
      el.textContent = n > 99 ? '99+' : String(n);
      el.classList.remove('hidden');
    } else {
      el.classList.add('hidden');
    }
  }

  let officialUnread = 0;
  let officialNotifyMode = 'all';   // all | badge | inbox
  let bannerDismissed = Number(localStorage.getItem('tokclip_off_dismissed') || 0);

  function renderOfficialBadge() {
    const el = $('#offBadge');
    if (!el) return;
    const showBadge = officialNotifyMode !== 'inbox';
    if (officialUnread > 0 && showBadge) {
      el.textContent = officialUnread > 99 ? '99+' : officialUnread;
      el.classList.remove('hidden');
    } else el.classList.add('hidden');
  }

  function renderOfficialBanner() {
    const el = $('#officialBanner');
    if (!el) return;
    const show = officialNotifyMode === 'all' && officialUnread > 0 && officialUnread > bannerDismissed;
    el.classList.toggle('hidden', !show);
    if (show) {
      $('#obTitle').textContent = officialUnread === 1
        ? 'Admin ki taraf se 1 naya official message'
        : 'Admin ki taraf se ' + officialUnread + ' naye official messages';
      $('#obSub').textContent = 'Inbox → 🛡 Official tab mein dekhein';
    }
  }

  async function refreshUnread() {
    if (!token) return;
    try {
      const d = await api('/unread');
      officialUnread = d.official || 0;
      if (d.officialNotify) officialNotifyMode = d.officialNotify;
      // 'inbox' mode: official messages nav counter mein count na hon
      const navTotal = officialNotifyMode === 'inbox'
        ? Math.max(0, (d.total || 0) - officialUnread)
        : (d.total || 0);
      setNavUnread(navTotal);
      renderOfficialBadge();
      renderOfficialBanner();
    } catch (e) { /* ignore */ }
  }

  $('#obClose').addEventListener('click', () => {
    bannerDismissed = officialUnread;
    localStorage.setItem('tokclip_off_dismissed', String(bannerDismissed));
    renderOfficialBanner();
  });

  /* ---------------- official notification settings ---------------- */
  const OFFICIAL_MODES = [
    { v: 'all', t: 'Banner + Badge', d: 'top banner aur Official tab par count — dono dikhein' },
    { v: 'badge', t: 'Sirf badge', d: 'banner nahi aayega, sirf Official tab par count' },
    { v: 'inbox', t: 'Sirf inbox', d: 'na banner na badge — messages Official tab ke andar hi' }
  ];

  function openOfficialSettings() {
    openSheet(
      '<h3>Official message settings</h3>' +
      '<p class="sub">Admin (official) messages ke notifications choose karein.</p>' +
      OFFICIAL_MODES.map(m =>
        '<button class="set-opt' + (officialNotifyMode === m.v ? ' active' : '') + '" data-mode="' + m.v + '">' +
          '<span class="so-radio">' + (officialNotifyMode === m.v ? '●' : '○') + '</span>' +
          '<span class="so-body"><b>' + m.t + '</b><span>' + m.d + '</span></span>' +
        '</button>').join('') +
      '<p class="note">Ye setting aapke account ke saath save hoti hai (har device par same).</p>'
    );

    $$('#sheet [data-mode]').forEach(btn => btn.addEventListener('click', async () => {
      const mode = btn.dataset.mode;
      if (mode === officialNotifyMode) { closeSheet(); return; }
      try {
        await api('/me/official-notify', { method: 'POST', body: { mode } });
        officialNotifyMode = mode;
        if (meUser) meUser.officialNotify = mode;
        renderOfficialBadge();
        renderOfficialBanner();
        refreshUnread();
        closeSheet();
        toast(mode === 'all' ? 'Banner + badge ON'
          : mode === 'badge' ? 'Sirf badge — banner band'
          : 'Sirf inbox — banner aur badge band');
      } catch (e) { toast(e.message); }
    }));
  }

  $('#officialSettings').addEventListener('click', openOfficialSettings);

  $('#obOpen').addEventListener('click', () => {
    bannerDismissed = officialUnread;
    localStorage.setItem('tokclip_off_dismissed', String(bannerDismissed));
    renderOfficialBanner();
    inboxTab = 'official';
    const btn = $('#inboxTabs') && $$('#inboxTabs button').find(b => b.dataset.itab === 'official');
    if (btn) btn.classList.add('active');
    const all = $$('#inboxTabs button').find(b => b.dataset.itab === 'all');
    if (all) all.classList.remove('active');
    go('inbox');
  });

  function timeAgoShort(ts) {
    const d = Date.now() - ts;
    const m = Math.floor(d / 60000);
    if (m < 1) return 'now';
    if (m < 60) return m + 'm';
    const h = Math.floor(m / 60);
    if (h < 24) return h + 'h';
    const dd = Math.floor(h / 24);
    if (dd < 7) return dd + 'd';
    return new Date(ts).toLocaleDateString();
  }

  let inboxTab = 'all';
  let inboxItems = [];

  $('#inboxTabs').addEventListener('click', e => {
    const b = e.target.closest('button[data-itab]');
    if (!b) return;
    inboxTab = b.dataset.itab;
    $$('#inboxTabs button').forEach(x => x.classList.toggle('active', x === b));
    renderInboxList();
  });

  function updateOfficialBadge() {
    const el = $('#offBadge');
    if (!el) return;
    // server ke official unread count ko priority; warna local sum
    const local = inboxItems.filter(i => i.official).reduce((s, i) => s + (i.unread || 0), 0);
    const n = officialUnread || local;
    if (n > 0 && officialNotifyMode !== 'inbox') { el.textContent = n > 99 ? '99+' : n; el.classList.remove('hidden'); }
    else el.classList.add('hidden');
  }

  function mediaLabel(kind, body) {
    if (kind === 'image') return '📷 Photo';
    if (kind === 'video') return '🎬 Video';
    if (kind === 'audio') return '🎤 Voice note';
    return esc(body || '');
  }

  function convHTML(it) {
    const u = it.user;
    const lm = it.lastMessage;
    let preview = lm
      ? (lm.fromMe ? '<span class="me-prefix">Aap: </span>' : (lm.fromAdmin ? '<span class="admin-tag sm">OFFICIAL</span> ' : '')) +
        mediaLabel(lm.kind, lm.body)
      : '';
    if (it.typing) preview = '<span class="typing">typing…</span>';

    // pinned official row par last OFFICIAL message ka preview
    if (it.pinned && it.lastOfficial) {
      preview = '<span class="admin-tag sm">OFFICIAL</span> ' + mediaLabel(it.lastOfficial.kind, it.lastOfficial.body);
    }

    const wrapCls = 'conv-wrap' + (it.official ? ' has-action' : '');
    const action = it.official
      ? '<button class="conv-action' + (it.pinned ? '' : ' pin') + '" data-pinfor="' + u.id + '">' +
          (it.pinned ? 'Unpin' : 'Pin') + '</button>'
      : '';

    return '<div class="' + wrapCls + '">' + action +
      '<div class="conv' + (it.official ? ' official' : '') + (it.pinned ? ' pinned' : '') + '" data-uid="' + u.id + '">' +
        '<div class="conv-av">' + avatarHTML(u) + (it.online ? '<span class="on-dot"></span>' : '') + '</div>' +
        '<div class="conv-main">' +
          '<div class="conv-top"><span class="conv-name">' +
            (it.pinned ? '<span class="pin-ico">📌</span> ' : '') +
            esc(u.name || u.username) +
            (it.official ? ' <span class="off-chip">Official</span>' : '') + '</span>' +
          '<span class="conv-time">' + timeAgoShort(it.updatedAt) + '</span></div>' +
          '<div class="conv-last">' + preview + '</div>' +
        '</div>' +
        (it.unread ? '<span class="conv-badge">' + it.unread + '</span>' : '') +
      '</div>' +
    '</div>';
  }

  async function toggleChatPin(it, pinned) {
    try {
      await api('/conversations/' + it.user.id + '/pin', { method: 'POST', body: { pinned: pinned } });
      toast(pinned ? 'Chat pin ho gayi 📌' : 'Chat unpin ho gayi');
      await loadInbox();
    } catch (e) { toast(e.message); }
  }

  function openConvActions(it) {
    openSheet(
      '<h3>@' + esc(it.user.username) + '</h3>' +
      '<p class="sub">' + (it.official ? 'Official conversation' : 'Conversation') + '</p>' +
      '<button class="vopt" id="caOpen"><span class="vi">💬</span>Open chat</button>' +
      (it.official
        ? '<button class="vopt" id="caPin"><span class="vi">📌</span>' + (it.pinned ? 'Unpin from top' : 'Pin to top') + '</button>'
        : '') +
      '<button class="vopt" id="caCancel"><span class="vi">✕</span>Cancel</button>'
    );
    $('#caOpen').addEventListener('click', () => { closeSheet(); openChat(it.user, it.official); });
    $('#caCancel').addEventListener('click', closeSheet);
    if ($('#caPin')) {
      $('#caPin').addEventListener('click', async () => {
        closeSheet();
        await toggleChatPin(it, !it.pinned);
      });
    }
  }

  function renderInboxList() {
    const body = $('#inboxBody');
    if (!body) return;

    const items = inboxTab === 'official' ? inboxItems.filter(i => i.official) : inboxItems;

    if (!items.length) {
      body.innerHTML = inboxTab === 'official'
        ? '<div class="inbox-empty"><div class="ie-ico">🛡</div><b>Koi official message nahi</b>' +
          '<span>Admin ki taraf se bheje gaye messages yahan alag dikhte hain.</span></div>'
        : '<div class="inbox-empty"><div class="ie-ico">✉️</div><b>Koi message nahi</b>' +
          '<span>Kisi creator ko message bhejein — baatein yahan dikhengi.</span>' +
          '<button class="btn" id="emptyNewChat">Naya message</button></div>';
      const b = $('#emptyNewChat');
      if (b) b.addEventListener('click', () => toggleInboxSearch(true));
      return;
    }

    const pinned = items.filter(i => i.official);
    const others = items.filter(i => !i.official);

    let html = '';
    if (pinned.length) {
      html += '<div class="conv-group">📌 Pinned · Official</div>' + pinned.map(convHTML).join('');
    }
    if (others.length) {
      if (pinned.length) html += '<div class="conv-group">Messages</div>';
      html += others.map(convHTML).join('');
    }

    body.innerHTML = html;

    $$('.conv', body).forEach(el => {
      const it = items.find(x => x.user.id === el.dataset.uid);
      if (!it) return;

      let lpTimer = null, startX = 0, dx = 0, moved = false, swiping = false;
      const reset = () => { el.style.transform = ''; el.classList.remove('swiped'); el._sw = false; };

      el.addEventListener('click', () => {
        if (el._sw) { reset(); return; }
        openChat(it.user, it.official);
      });

      el.addEventListener('pointerdown', e => {
        if (e.pointerType === 'mouse' && e.button !== 0) return;
        startX = e.clientX; dx = 0; moved = false; swiping = false;
        clearTimeout(lpTimer);
        lpTimer = setTimeout(() => {
          if (!moved) {
            if (navigator.vibrate) { try { navigator.vibrate(12); } catch (err) {} }
            el._lp = true;
            openConvActions(it);
            setTimeout(() => { el._lp = false; }, 600);
          }
        }, 520);
      });

      el.addEventListener('pointermove', e => {
        dx = e.clientX - startX;
        if (Math.abs(dx) > 8) { clearTimeout(lpTimer); moved = true; }
        if (dx < -8 && it.official) {
          swiping = true;
          el.style.transform = 'translateX(' + Math.max(-92, dx) + 'px)';
        }
      });

      const finish = () => {
        clearTimeout(lpTimer);
        if (swiping) {
          if (dx < -45) { el.style.transform = 'translateX(-92px)'; el.classList.add('swiped'); el._sw = true; }
          else reset();
          swiping = false;
        }
      };
      el.addEventListener('pointerup', finish);
      el.addEventListener('pointercancel', () => { clearTimeout(lpTimer); if (swiping) reset(); });
    });

    $$('[data-pinfor]', body).forEach(btn => btn.addEventListener('click', async e => {
      e.stopPropagation();
      const it = items.find(x => x.user.id === btn.dataset.pinfor);
      if (it) await toggleChatPin(it, !it.pinned);
    }));
  }

  async function loadInbox() {
    const body = $('#inboxBody');
    body.innerHTML = skeletonRows(5);
    try {
      const d = await api('/conversations');
      inboxItems = d.items || [];
      updateOfficialBadge();
      renderInboxList();
      refreshUnread();

      // typing poll (inbox visible hone tak)
      clearInterval(inboxTypingTimer);
      inboxTypingTimer = setInterval(async () => {
        if (currentView !== 'inbox') { clearInterval(inboxTypingTimer); return; }
        try {
          const t = await api('/typing');
          const active = new Set(t.users || []);
          $$('.conv', body).forEach(el => {
            const last = $('.conv-last', el);
            if (!last) return;
            if (active.has(el.dataset.uid)) {
              if (!last._orig) last._orig = last.innerHTML;
              last.innerHTML = '<span class="typing">typing…</span>';
            } else if (last._orig) {
              last.innerHTML = last._orig;
              last._orig = null;
            }
          });
        } catch (e) { /* ignore */ }
      }, 3000);
    } catch (e) {
      body.innerHTML = '<div class="search-empty">' + esc(e.message) + '</div>';
    }
  }

  function toggleInboxSearch(force) {
    const wrap = $('#inboxSearchWrap');
    const show = force === undefined ? wrap.classList.contains('hidden') : force;
    wrap.classList.toggle('hidden', !show);
    if (show) setTimeout(() => $('#inboxSearch').focus(), 60);
    else {
      $('#inboxSearch').value = '';
      $('#inboxSearchClear').classList.add('hidden');
      loadInbox();
    }
  }

  let inboxSearchTimer = null, inboxSeq = 0, inboxTypingTimer = null;

  $('#newChatBtn').addEventListener('click', () => toggleInboxSearch());

  $('#inboxSearch').addEventListener('input', e => {
    const q = e.target.value.trim();
    $('#inboxSearchClear').classList.toggle('hidden', !q);
    clearTimeout(inboxSearchTimer);
    if (!q) { loadInbox(); return; }
    inboxSearchTimer = setTimeout(() => doInboxSearch(q), 260);
  });

  $('#inboxSearchClear').addEventListener('click', () => {
    $('#inboxSearch').value = '';
    $('#inboxSearchClear').classList.add('hidden');
    loadInbox();
    $('#inboxSearch').focus();
  });

  async function doInboxSearch(q) {
    const body = $('#inboxBody');
    body.innerHTML = skeletonRows(4);
    const seq = ++inboxSeq;
    try {
      const d = await api('/search?q=' + encodeURIComponent(q));
      if (seq !== inboxSeq) return;
      const users = (d.users || []).filter(u => u.id !== (meUser && meUser.id));
      if (!users.length) {
        body.innerHTML = '<div class="search-empty">Koi user nahi mila.</div>';
        return;
      }
      body.innerHTML = users.map(userRowHTML).join('');
      wireFollowButtons(body, () => {});
      $$('.user-row', body).forEach(row => row.addEventListener('click', ev => {
        if (ev.target.closest('[data-follow]')) return;
        const u = users.find(x => x.id === row.dataset.uid);
        if (u) openChat(u);
      }));
    } catch (e) {
      body.innerHTML = '<div class="search-empty">' + esc(e.message) + '</div>';
    }
  }

  async function openChat(user, official) {
    chat.userId = user.id;
    chat.user = user;
    chat.official = !!official || !!(user && user.isAdmin);
    chat.lastKey = '';

    $('#view-chat').classList.toggle('official-chat', chat.official);
    $('#officialThreadBar').classList.toggle('hidden', !chat.official);
    chat.archOpen = false;
    $('#chatUser').innerHTML = avatarHTML(user) +
      '<div><div class="cu-name">' + esc(user.name || user.username) +
        (user.isAdmin ? ' <span class="off-chip">Official</span>' : '') + '</div>' +
      '<div class="cu-sub">@' + esc(user.username) + '</div></div>';
    $('#chatBody').innerHTML = skeletonRows(3);
    $('#chatInput').value = '';
    $('#chatSend').disabled = true;
    go('chat');
    await loadThread();
    clearInterval(chat.timer);
    chat.timer = setInterval(() => { if (currentView === 'chat') loadThread(); }, 4000);
    clearInterval(chat.typingTimer);
    chat.typingTimer = setInterval(() => { if (currentView === 'chat') refreshTyping(); }, 2000);
    chat.typingOn = false;
    refreshTyping();

    chat.online = null;
    refreshPresence();
    clearInterval(chat.presenceTimer);
    chat.presenceTimer = setInterval(() => { if (currentView === 'chat') refreshPresence(); }, 6000);
  }

  async function loadThread() {
    if (!chat.userId) return;
    try {
      const d = await api('/messages/' + chat.userId);
      const msgs = d.messages || [];
      const key = msgs.length ? msgs[msgs.length - 1].id : 'empty';
      const body = $('#chatBody');
      if (key === chat.lastKey) { refreshUnread(); return; }
      const wasFirst = chat.lastKey === '';
      const atBottom = body.scrollHeight - body.scrollTop - body.clientHeight < 90;
      chat.lastKey = key;
      body.innerHTML = msgs.length ? threadHTML(msgs) : '<div class="chat-empty">Koi message nahi — pehla message bhejein 👋</div>';
      wireChatMedia(body);
      wireArchiveToggle(body);
      if (wasFirst || atBottom) scrollToLatest(false);
      refreshUnread();
    } catch (e) { toast(e.message); }
  }

  function threadHTML(msgs) {
    const archived = msgs.filter(m => m.archived);
    const fresh = msgs.filter(m => !m.archived);

    if (!archived.length) return msgs.map(msgHTML).join('');

    const open = chat.archOpen;
    let html = '<button class="arch-toggle" id="archToggle">' +
      '<span class="at-ico">📦</span>' +
      '<span class="at-txt">' + archived.length + ' purane official message archived</span>' +
      '<span class="at-arrow">' + (open ? '▲' : '▼') + '</span>' +
    '</button>' +
    '<div class="arch-block' + (open ? '' : ' hidden') + '" id="archBlock">' +
      archived.map(msgHTML).join('') +
    '</div>';

    if (fresh.length) {
      html += '<div class="thread-sep"><span>✨ Naye messages</span></div>' + fresh.map(msgHTML).join('');
    }
    return html;
  }

  function wireArchiveToggle(scope) {
    const btn = $('#archToggle', scope);
    if (btn) btn.addEventListener('click', () => {
      chat.archOpen = !chat.archOpen;
      const block = $('#archBlock', scope);
      if (block) block.classList.toggle('hidden', !chat.archOpen);
      const ar = $('.at-arrow', btn);
      if (ar) ar.textContent = chat.archOpen ? '▲' : '▼';
    });
  }

  async function archiveOfficial() {
    if (!chat.userId) return;
    const ok = confirm('Padhe hue saare official messages archive karein?\n\nWo collapse ho kar "archived" section mein chale jayenge — delete nahi honge.');
    if (!ok) return;
    try {
      const r = await api('/official/archive', { method: 'POST', body: { userId: chat.userId, action: 'archive' } });
      chat.lastKey = '';
      chat.archOpen = false;
      await loadThread();
      toast(r.count ? r.count + ' messages archive ho gaye 📦' : 'Koi naya read message nahi mila');
    } catch (e) { toast(e.message); }
  }

  function msgHTML(m) {
    let inner;
    if (m.kind === 'image' && m.url) {
      inner = '<img class="chat-media" src="' + esc(m.url) + '" alt="photo" loading="lazy" data-media="' + esc(m.url) + '">';
    } else if (m.kind === 'video' && m.url) {
      inner = '<video class="chat-media" src="' + esc(m.url) + '#t=0.1" controls preload="metadata" playsinline></video>';
    } else if (m.kind === 'audio' && m.url) {
      inner = voiceHTML(m);
    } else {
      inner = '<div class="bubble">' + esc(m.body) + '</div>';
    }
    const isMedia = m.kind === 'image' || m.kind === 'video' || m.kind === 'audio';
    const adminCls = m.fromAdmin ? ' admin' : '';
    let adminTag = '';
    if (m.fromAdmin) adminTag = '<span class="admin-tag">ADMIN</span>';
    let ticks = '';
    if (m.mine) {
      const read = !!m.readAt;
      ticks = '<span class="ticks' + (read ? ' read' : '') + '" title="' +
        (read ? 'Read ' + timeAgoShort(m.readAt) : 'Sent') + '">' + (read ? '✓✓' : '✓') + '</span>';
    }
    return '<div class="msg ' + (m.mine ? 'mine' : 'theirs') + adminCls + (isMedia ? ' media' : '') + '">' +
      inner +
      '<div class="msg-time">' + adminTag + timeAgoShort(m.createdAt) + ticks + '</div>' +
    '</div>';
  }

  function wireChatMedia(scope) {
    $$('[data-media]', scope).forEach(img => {
      img.addEventListener('click', () => openMediaViewer(img.dataset.media));
    });
    wireVoicePlayers(scope);
  }

  /* ---------------- voice notes ---------------- */
  function fmtDur(sec) {
    sec = Math.max(0, Math.round(sec || 0));
    const m = Math.floor(sec / 60);
    return m + ':' + String(sec % 60).padStart(2, '0');
  }

  function voiceHTML(m) {
    let peaks = Array.isArray(m.peaks) && m.peaks.length ? m.peaks : null;
    if (!peaks) {
      peaks = [];
      const seed = String(m.id || '');
      for (let i = 0; i < 30; i++) {
        const c = seed.charCodeAt(i % Math.max(1, seed.length)) || 7;
        peaks.push(28 + ((c * (i + 3)) % 62));
      }
    }
    const dur = (m.duration || 0) / 1000;
    return '<div class="voice" data-src="' + esc(m.url) + '">' +
      '<button type="button" class="v-play">▶</button>' +
      '<div class="v-wave">' + peaks.map(p => '<i style="height:' + Math.max(14, p) + '%"></i>').join('') + '</div>' +
      '<span class="v-time">' + fmtDur(dur) + '</span>' +
      '<button type="button" class="v-speed" title="Playback speed">' + fmtSpeed(voiceSpeed) + '</button>' +
    '</div>';
  }

  const SPEED_KEY = 'tokclip_voice_speed';
  let voiceSpeed = (() => {
    const v = Number(localStorage.getItem(SPEED_KEY));
    return [1, 1.5, 2].indexOf(v) !== -1 ? v : 1;
  })();
  const SPEED_STEPS = [1, 1.5, 2];
  const fmtSpeed = v => (v === 2 ? '2x' : v === 1.5 ? '1.5x' : '1x');

  function applySpeedEverywhere() {
    localStorage.setItem(SPEED_KEY, String(voiceSpeed));
    $$('.v-speed').forEach(b => { b.textContent = fmtSpeed(voiceSpeed); });
    $$('.voice').forEach(el => { if (el._audio) el._audio.playbackRate = voiceSpeed; });
  }

  function cycleSpeed() {
    const idx = SPEED_STEPS.indexOf(voiceSpeed);
    voiceSpeed = SPEED_STEPS[(idx + 1) % SPEED_STEPS.length];
    applySpeedEverywhere();
    toast('Speed: ' + fmtSpeed(voiceSpeed));
  }

  function scrollToLatest(smooth) {
    const body = $('#chatBody');
    if (!body) return;
    body.scrollTo({ top: body.scrollHeight, behavior: smooth ? 'smooth' : 'auto' });
  }

  function wireVoicePlayers(scope) {
    $$('.voice', scope).forEach(el => {
      if (el._wired) return;
      el._wired = true;
      const btn = $('.v-play', el);
      const wave = $('.v-wave', el);
      const time = $('.v-time', el);
      const speedBtn = $('.v-speed', el);
      const bars = Array.from(wave.children);
      if (speedBtn) speedBtn.textContent = fmtSpeed(voiceSpeed);

      const ensure = () => {
        if (el._audio) return el._audio;
        const a = new Audio(el.dataset.src);
        a.preload = 'metadata';
        a.playbackRate = voiceSpeed;
        a.addEventListener('loadedmetadata', () => {
          if (a.duration && isFinite(a.duration)) time.textContent = fmtDur(a.duration);
          a.playbackRate = voiceSpeed;
        });
        a.addEventListener('timeupdate', () => {
          const p = a.duration ? a.currentTime / a.duration : 0;
          const upto = Math.floor(p * bars.length);
          bars.forEach((b, i) => b.classList.toggle('on', i < upto));
          time.textContent = fmtDur(a.currentTime);
        });
        a.addEventListener('ended', () => {
          btn.textContent = '▶';
          bars.forEach(b => b.classList.remove('on'));
          time.textContent = fmtDur(a.duration);
        });
        el._audio = a;
        return a;
      };

      btn.addEventListener('click', () => {
        // baaki voice notes pause
        $$('.voice').forEach(o => {
          if (o !== el && o._audio && !o._audio.paused) {
            o._audio.pause();
            const ob = $('.v-play', o);
            if (ob) ob.textContent = '▶';
          }
        });
        const a = ensure();
        if (a.paused) {
          a.playbackRate = voiceSpeed;
          a.play().then(() => {
            btn.textContent = '⏸';
            // play hote hi latest message tak auto-scroll
            const msg = el.closest('.msg');
            scrollToLatest(true);
            if (msg) {
              setTimeout(() => {
                const b = $('#chatBody');
                const mr = msg.getBoundingClientRect();
                const br = b.getBoundingClientRect();
                if (mr.top < br.top || mr.bottom > br.bottom) {
                  msg.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }
              }, 360);
            }
          }).catch(() => toast('Audio play nahi hui'));
        } else {
          a.pause();
          btn.textContent = '▶';
        }
      });

      if (speedBtn) {
        speedBtn.addEventListener('click', e => { e.stopPropagation(); cycleSpeed(); });
      }
    });
  }

  /* ---------------- recording ---------------- */
  const rec = { mr: null, chunks: [], stream: null, startedAt: 0, timer: null, raf: null, ctx: null, analyser: null, cancelled: false };

  function recCleanup() {
    clearInterval(rec.timer);
    if (rec.raf) cancelAnimationFrame(rec.raf);
    if (rec.stream) rec.stream.getTracks().forEach(t => t.stop());
    if (rec.ctx && rec.ctx.state !== 'closed') rec.ctx.close().catch(() => {});
    rec.timer = null; rec.raf = null; rec.stream = null; rec.ctx = null; rec.analyser = null;
    $('#recBar').classList.add('hidden');
    $('#chatForm').classList.remove('hidden');
    $('#chatMic').disabled = false;
  }

  function voiceBlockReason() {
    if (!window.isSecureContext) {
      return {
        title: 'Mic blocked — HTTPS chahiye',
        text: 'Browser microphone sirf HTTPS ya localhost par deta hai.\n\nAap abhi ' + location.origin + ' par hain.\n\nServer is tarah chalayein:\n  HTTPS=1 npm start\nphir https:// wale address se kholein (self-signed cert par "Advanced → Proceed" karein).'
      };
    }
    if (!navigator.mediaDevices || !window.MediaRecorder) {
      return {
        title: 'Recording support nahi',
        text: 'Ye browser MediaRecorder support nahi karta. Chrome, Edge ya naya Safari try karein.'
      };
    }
    return null;
  }

  function showVoiceHelp(info) {
    openSheet(
      '<h3>' + esc(info.title) + '</h3>' +
      '<p class="sub" style="white-space:pre-wrap;line-height:1.7;font-size:12.5px">' + esc(info.text) + '</p>' +
      '<div class="row"><button class="btn" id="voiceHelpOk">Samajh gaya</button></div>'
    );
    $('#voiceHelpOk').addEventListener('click', closeSheet);
  }

  async function startRecording() {
    const block = voiceBlockReason();
    if (block) { showVoiceHelp(block); return; }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      rec.stream = stream;
      rec.chunks = [];
      rec.peaks = [];
      rec.cancelled = false;
      rec.startedAt = Date.now();

      const Ctx = window.AudioContext || window.webkitAudioContext;
      const ctx = new Ctx();
      rec.ctx = ctx;
      const src = ctx.createMediaStreamSource(stream);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 512;
      src.connect(analyser);
      rec.analyser = analyser;

      const mime = MediaRecorder.isTypeSupported('audio/webm;codecs=opus') ? 'audio/webm;codecs=opus'
        : MediaRecorder.isTypeSupported('audio/webm') ? 'audio/webm'
        : MediaRecorder.isTypeSupported('audio/mp4') ? 'audio/mp4' : '';
      const mr = mime ? new MediaRecorder(stream, { mimeType: mime }) : new MediaRecorder(stream);
      rec.mr = mr;
      mr.ondataavailable = e => { if (e.data && e.data.size) rec.chunks.push(e.data); };
      mr.onstop = onRecStop;
      mr.start(200);

      $('#chatForm').classList.add('hidden');
      $('#recBar').classList.remove('hidden');
      $('#chatMic').disabled = true;

      rec.timer = setInterval(() => {
        const s = (Date.now() - rec.startedAt) / 1000;
        $('#recTime').textContent = fmtDur(s);
        if (s >= 120) stopRecording();          // max 2 minute
      }, 200);

      drawLiveWave();
    } catch (e) {
      if (e && (e.name === 'NotAllowedError' || e.name === 'SecurityError')) {
        showVoiceHelp({
          title: 'Mic permission nahi mili',
          text: 'Address bar ke lock/mic icon par tap karein → Microphone ko Allow karein → dobara 🎤 dabayein.\n\nAgar option hi nahi hai to page HTTPS par kholna hoga.'
        });
      } else if (e && e.name === 'NotFoundError') {
        toast('Koi microphone nahi mila');
      } else {
        toast('Mic error: ' + ((e && e.message) || 'unknown'));
      }
      recCleanup();
    }
  }

  function drawLiveWave() {
    const canvas = $('#recWave');
    const ctx2 = canvas.getContext('2d');
    const data = new Uint8Array(rec.analyser.frequencyBinCount);
    const W = canvas.width, H = canvas.height;
    const bars = 42;

    const loop = () => {
      if (!rec.analyser) return;
      rec.analyser.getByteTimeDomainData(data);
      let sum = 0;
      for (let i = 0; i < data.length; i++) {
        const v = (data[i] - 128) / 128;
        sum += v * v;
      }
      const rms = Math.sqrt(sum / data.length);
      rec.peaks = rec.peaks || [];
      rec.peaks.push(Math.min(100, Math.round(rms * 320)));
      if (rec.peaks.length > 60) rec.peaks.shift();

      ctx2.clearRect(0, 0, W, H);
      const step = W / bars;
      const src2 = rec.peaks.slice(-bars);
      for (let i = 0; i < bars; i++) {
        const val = src2[i] !== undefined ? src2[i] : 8;
        const h = Math.max(6, (val / 100) * H);
        ctx2.fillStyle = i > bars - 8 ? '#fe2c55' : 'rgba(255,255,255,.75)';
        const x = i * step + 1;
        ctx2.fillRect(x, (H - h) / 2, Math.max(2, step - 2), h);
      }
      rec.raf = requestAnimationFrame(loop);
    };
    ctx2.clearRect(0, 0, W, H);
    loop();
  }

  function stopRecording() {
    if (rec.mr && rec.mr.state !== 'inactive') rec.mr.stop();
  }

  function onRecStop() {
    const duration = Date.now() - rec.startedAt;
    const peaks = (rec.peaks || []).slice(-40);
    const mime = (rec.mr && rec.mr.mimeType) || 'audio/webm';
    const blob = new Blob(rec.chunks, { type: mime });
    const cancelled = rec.cancelled;
    rec.mr = null;
    recCleanup();

    if (cancelled) { toast('Recording cancel ho gayi'); return; }
    if (!blob.size || duration < 400) { toast('Recording bahut choti thi'); return; }
    uploadVoice(blob, duration, peaks);
  }

  function uploadVoice(blob, duration, peaks) {
    const fd = new FormData();
    const ext = blob.type.indexOf('mp4') !== -1 ? 'm4a' : 'webm';
    fd.append('file', blob, 'voice-' + Date.now() + '.' + ext);
    fd.append('to', chat.userId);
    fd.append('duration', String(duration));
    fd.append('peaks', JSON.stringify(peaks || []));

    const mic = $('#chatMic');
    mic.disabled = true;
    mic.textContent = '⏳';
    toast('Voice note bhej rahe hain...');

    const xhr = new XMLHttpRequest();
    xhr.open('POST', '/api/messages/media');
    xhr.setRequestHeader('Authorization', 'Bearer ' + token);
    xhr.onload = async () => {
      mic.disabled = false;
      mic.textContent = '🎤';
      let d = null;
      try { d = JSON.parse(xhr.responseText); } catch (e) {}
      if (xhr.status >= 200 && xhr.status < 300) {
        chat.lastKey = '';
        await loadThread();
        toast('Voice note bhej di 🎤');
      } else {
        toast((d && d.error) || 'Voice note nahi gaya');
      }
    };
    xhr.onerror = () => {
      mic.disabled = false;
      mic.textContent = '🎤';
      toast('Network error — dobara try karein');
    };
    xhr.send(fd);
  }

  $('#chatMic').addEventListener('click', () => {
    if (rec.mr) { stopRecording(); return; }
    startRecording();
  });
  $('#recSend').addEventListener('click', () => { rec.cancelled = false; stopRecording(); });
  $('#recCancel').addEventListener('click', () => { rec.cancelled = true; stopRecording(); });

  function openMediaViewer(url) {
    $('#mvBody').innerHTML = '<img src="' + esc(url) + '" alt="photo">';
    $('#mediaViewer').classList.remove('hidden');
  }

  function closeMediaViewer() {
    $('#mediaViewer').classList.add('hidden');
    $('#mvBody').innerHTML = '';
  }

  $('#mvClose').addEventListener('click', closeMediaViewer);
  $('#mediaViewer').addEventListener('click', e => {
    if (e.target.id === 'mediaViewer') closeMediaViewer();
  });

  /* attach (photo / video) */
  $('#chatAttach').addEventListener('click', () => $('#chatFile').click());
  $('#chatFile').addEventListener('change', e => {
    const f = e.target.files && e.target.files[0];
    if (f && chat.userId) uploadChatMedia(f);
    e.target.value = '';
  });

  function uploadChatMedia(f) {
    if (f.size > 25 * 1024 * 1024) { toast('File 25MB se choti honi chahiye'); return; }
    if (!/^image\//.test(f.type) && !/^video\//.test(f.type)) { toast('Sirf photo ya video bhejein'); return; }

    const fd = new FormData();
    fd.append('file', f);
    fd.append('to', chat.userId);

    const btn = $('#chatAttach');
    const old = btn.textContent;
    btn.disabled = true;
    btn.textContent = '⏳';

    const xhr = new XMLHttpRequest();
    xhr.open('POST', '/api/messages/media');
    xhr.setRequestHeader('Authorization', 'Bearer ' + token);
    xhr.onload = async () => {
      btn.disabled = false;
      btn.textContent = old;
      let d = null;
      try { d = JSON.parse(xhr.responseText); } catch (e) {}
      if (xhr.status >= 200 && xhr.status < 300) {
        chat.lastKey = '';
        await loadThread();
        toast(f.type.indexOf('video') === 0 ? 'Video bhej di 🎬' : 'Photo bhej di 📷');
      } else {
        toast((d && d.error) || 'Media bhejne mein masla hua');
      }
    };
    xhr.onerror = () => {
      btn.disabled = false;
      btn.textContent = old;
      toast('Network error — dobara try karein');
    };
    xhr.send(fd);
  }

  /* ---------------- typing indicator ---------------- */
  function pingTyping() {
    if (!chat.userId) return;
    const t = Date.now();
    if (t - chat.lastPing < 2000) return;
    chat.lastPing = t;
    api('/typing', { method: 'POST', body: { to: chat.userId } }).catch(() => {});
  }

  function stopTyping() {
    if (!chat.userId) return;
    try { api('/typing', { method: 'POST', body: { to: chat.userId, typing: false } }).catch(() => {}); } catch (e) {}
    chat.lastPing = 0;
  }

  async function refreshTyping() {
    if (!chat.userId) return;
    try {
      const d = await api('/typing/' + chat.userId);
      setTypingUI(!!d.typing);
    } catch (e) { /* ignore */ }
  }

  function setTypingUI(on) {
    if (chat.typingOn === on) return;
    chat.typingOn = on;

    if (on) {
      const sub0 = $('.cu-sub');
      if (sub0) sub0.innerHTML = '<span class="typing">typing…</span>';
    } else {
      renderChatStatus();
    }

    const body = $('#chatBody');
    if (!body) return;
    let bubble = $('#typingBubble');
    if (on) {
      if (!bubble) {
        bubble = document.createElement('div');
        bubble.id = 'typingBubble';
        bubble.className = 'typing-bubble';
        bubble.innerHTML = '<i></i><i></i><i></i>';
        body.appendChild(bubble);
      }
      body.appendChild(bubble);
      const atBottom = body.scrollHeight - body.scrollTop - body.clientHeight < 120;
      if (atBottom) scrollToLatest(true);
    } else if (bubble) {
      bubble.remove();
    }
  }

  /* ---------------- presence (online / last seen) ---------------- */
  async function refreshPresence() {
    if (!chat.userId) return;
    try {
      const p = await api('/presence/' + chat.userId);
      chat.online = !!p.online;
      chat.lastSeen = p.lastSeen || 0;
      renderChatStatus();
    } catch (e) { /* ignore */ }
  }

  function lastSeenText(ts) {
    if (!ts) return 'last seen recently';
    const diff = Date.now() - ts;
    const m = Math.floor(diff / 60000);
    if (m < 1) return 'last seen just now';
    if (m < 60) return 'last seen ' + m + 'm ago';
    const h = Math.floor(m / 60);
    if (h < 24) return 'last seen ' + h + 'h ago';
    const d = Math.floor(h / 24);
    if (d < 7) return 'last seen ' + d + 'd ago';
    return 'last seen ' + new Date(ts).toLocaleDateString();
  }

  function renderChatStatus() {
    const sub = $('.cu-sub');
    if (!sub || !chat.user) return;
    if (chat.typingOn) return;                 // typing… ki priority hai
    if (chat.online) {
      sub.innerHTML = '<span class="presence-dot"></span>online';
    } else {
      sub.textContent = lastSeenText(chat.lastSeen);
    }
  }

  function closeChat() {
    if (rec.mr) { rec.cancelled = true; stopRecording(); }
    $('#view-chat').classList.remove('official-chat');
    $('#officialThreadBar').classList.add('hidden');
    stopTyping();
    clearInterval(chat.timer);
    clearInterval(chat.typingTimer);
    clearInterval(chat.presenceTimer);
    setTypingUI(false);
    chat.userId = null;
    chat.user = null;
    go('inbox');
  }

  $('#archBtn').addEventListener('click', archiveOfficial);

  $('#chatBack').addEventListener('click', closeChat);

  $('#chatInput').addEventListener('input', e => {
    $('#chatSend').disabled = !e.target.value.trim();
    if (e.target.value.trim()) pingTyping();
    else stopTyping();
  });

  $('#chatForm').addEventListener('submit', async e => {
    e.preventDefault();
    const input = $('#chatInput');
    const body = input.value.trim();
    if (!body || !chat.userId) return;
    input.value = '';
    $('#chatSend').disabled = true;
    stopTyping();
    try {
      await api('/messages', { method: 'POST', body: { to: chat.userId, body } });
      chat.lastKey = '';
      await loadThread();
    } catch (err) {
      toast(err.message);
      input.value = body;
      $('#chatSend').disabled = false;
    }
  });

  /* ---------------------------------------------------------------- */
  /* profile                                                           */
  /* ---------------------------------------------------------------- */
  let profileData = null;

  async function loadProfile() {
    const body = $('#profileBody');
    body.innerHTML =
      '<div class="sk-prof"><div class="sk-av sk"></div>' +
      '<div class="sk-line sk" style="width:120px;height:14px;border-radius:7px"></div>' +
      '<div class="sk-line sk" style="width:78px"></div>' +
      '<div class="sk-line sk" style="width:150px"></div></div>' +
      '<div class="sk-grid">' +
      Array.from({ length: 6 }).map(() => '<div class="sk-cell sk"></div>').join('') + '</div>';
    try {
      if (!meUser) meUser = (await api('/me')).user;
      const data = await api('/users/' + meUser.username);
      profileData = data;
      renderProfile(data);
    } catch (e) {
      body.innerHTML = '<div class="empty">' + esc(e.message) + '</div>';
    }
  }

  function renderProfile(data) {
    const u = data.user;
    const vids = data.videos || [];
    const totalLikes = vids.reduce((s, v) => s + (v.likes || 0), 0);
    const totalViews = vids.reduce((s, v) => s + (v.views || 0), 0);

    const cells = vids.length
      ? vids.map(v =>
          '<div class="vcell">' +
            '🎬' +
            '<div class="play">▶ ' + fmt(v.views) + '</div>' +
          '</div>').join('')
      : '<div class="empty">Abhi koi video nahi.<br>Neeche "+" dabaa kar apni pehli video upload karein.</div>';

    $('#profileBody').innerHTML =
      '<div class="prof-head">' +
        avatarHTML(u) +
        '<div class="name">' + esc(u.name) + '</div>' +
        '<div class="user">@' + esc(u.username) + '</div>' +
        (u.bio ? '<div class="bio">' + esc(u.bio) + '</div>' : '') +
        '<div class="stats">' +
          '<div><b>' + fmt(u.following || 0) + '</b><span>Following</span></div>' +
          '<div><b data-role="followers">' + fmt(u.followers) + '</b><span>Followers</span></div>' +
          '<div><b>' + fmt(totalLikes) + '</b><span>Likes</span></div>' +
        '</div>' +
        '<div class="stats" style="margin-top:10px;gap:34px">' +
          '<div><b>' + fmt(vids.length) + '</b><span>Videos</span></div>' +
          '<div><b>' + fmt(totalViews) + '</b><span>Views</span></div>' +
        '</div>' +
        '<div class="prof-actions">' +
          '<button class="btn ghost" data-act="editProfile">Edit profile</button>' +
          '<button class="btn ghost" data-act="logout" style="color:#ff6b81">Log out</button>' +
        '</div>' +
        (u.isAdmin ? '<div class="prof-actions"><a class="btn ghost" href="/admin" style="display:grid;place-items:center;text-decoration:none">🛡 Admin panel</a></div>' : '') +
      '</div>' +
      '<div class="grid-tabs"><button class="active">▦ My videos</button></div>' +
      '<div class="vgrid">' + cells + '</div>';

    $('[data-act="editProfile"]').addEventListener('click', openEditProfile);
    $('[data-act="logout"]').addEventListener('click', () => logout());
  }

  /* ---------------------------------------------------------------- */
  /* sheets                                                            */
  /* ---------------------------------------------------------------- */
  function openSheet(html) {
    $('#sheet').innerHTML = '<div class="grab"></div>' + html;
    $('#sheet').classList.remove('hidden');
    $('#backdrop').classList.remove('hidden');
  }
  function closeSheet() {
    $('#sheet').classList.add('hidden');
    $('#backdrop').classList.add('hidden');
    $('#sheet').innerHTML = '';
  }
  $('#backdrop').addEventListener('click', closeSheet);

  /* NOTE: views/likes/followers boost sirf admin panel se hota hai. */

  function openEditProfile() {
    const u = (profileData && profileData.user) || meUser;
    openSheet(
      '<h3>Edit profile</h3><p class="sub">Naam, username aur bio badlein.</p>' +
      '<div class="field"><label>Display name</label><input id="eName" value="' + esc(u.name) + '"></div>' +
      '<div class="field"><label>Username</label><input id="eUser" value="' + esc(u.username) + '"></div>' +
      '<div class="field"><label>Bio</label><input id="eBio" value="' + esc(u.bio || '') + '" placeholder="Apne baare mein likhein"></div>' +
      '<div class="row"><button class="btn" id="saveProfile">Save</button></div>'
    );
    $('#saveProfile').addEventListener('click', async () => {
      const btn = $('#saveProfile');
      btn.disabled = true;
      try {
        const r = await api('/me', {
          method: 'PATCH',
          body: {
            name: $('#eName').value.trim(),
            username: $('#eUser').value.trim(),
            bio: $('#eBio').value.trim()
          }
        });
        meUser = r.user;
        closeSheet(); toast('Profile save ho gaya');
        feed.items = []; feed.cursor = null; feed.hasMore = true;
        await loadProfile();
      } catch (e) { toast(e.message); }
      finally { btn.disabled = false; }
    });
  }

  /* ---------------------------------------------------------------- */
  /* comments                                                          */
  /* ---------------------------------------------------------------- */
  async function openComments(video) {
    openSheet('<h3>Comments</h3>' + skeletonRows(4));
    let items = [];
    try {
      const r = await api('/videos/' + video.id + '/comments');
      items = r.items || [];
    } catch (e) { toast(e.message); }

    const rows = items.length
      ? items.map(c =>
          '<div class="cmt">' + avatarHTML(c.author) +
          '<div class="body"><div class="n">@' + esc(c.author.username) + '</div>' +
          '<div class="t">' + esc(c.text) + '</div></div></div>').join('')
      : '<p class="sub" style="text-align:center;padding:18px 0">Pehla comment aap karein 🙂</p>';

    $('#sheet').innerHTML =
      '<div class="grab"></div><h3>Comments · ' + fmt(items.length) + '</h3>' +
      '<div style="max-height:46vh;overflow-y:auto;margin:14px 0 4px">' + rows + '</div>' +
      '<div class="cmt-input"><input id="cmtText" maxlength="240" placeholder="Comment likhein..."><button id="cmtSend">Post</button></div>';

    const send = async () => {
      const t = $('#cmtText').value.trim();
      if (!t) return;
      $('#cmtSend').disabled = true;
      try {
        const r = await api('/videos/' + video.id + '/comments', { method: 'POST', body: { text: t } });
        video.comments = r.count;
        slidesFor(video.id).forEach(s => {
          s._data.comments = r.count;
          const el = $('[data-role="comments"]', s);
          if (el) el.textContent = fmt(r.count);
        });
        closeSheet(); toast('Comment added');
      } catch (e) { toast(e.message); }
      finally { const b = $('#cmtSend'); if (b) b.disabled = false; }
    };
    $('#cmtSend').addEventListener('click', send);
    $('#cmtText').addEventListener('keydown', e => { if (e.key === 'Enter') send(); });
    setTimeout(() => { const i = $('#cmtText'); if (i) i.focus(); }, 80);
  }

  /* ---------------------------------------------------------------- */
  /* boot                                                              */
  /* ---------------------------------------------------------------- */
  async function boot() {
    setAuthMode('login');
    if (!token) {
      $('#app').classList.add('hidden');
      return;
    }
    try {
      const me = await api('/me');
      meUser = me.user;
      if (meUser.officialNotify) officialNotifyMode = meUser.officialNotify;
      enterApp();
    } catch (e) {
      logout(true);
    }
  }

  boot();
})();
