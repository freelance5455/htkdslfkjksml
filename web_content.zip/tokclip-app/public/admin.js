/* =====================================================================
   TokClip admin panel
   ===================================================================== */
(function () {
  'use strict';

  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const TOKEN_KEY = 'tokclip_token';

  let token = localStorage.getItem(TOKEN_KEY) || '';
  let meUser = null;
  let tab = 'videos';
  let searchTerm = '';
  let reportFilter = 'pending';

  /* ---------------- helpers ---------------- */
  const fmt = n => {
    n = Math.max(0, Math.round(Number(n) || 0));
    if (n >= 1e9) return (n / 1e9).toFixed(1).replace(/\.0$/, '') + 'B';
    if (n >= 1e6) return (n / 1e6).toFixed(1).replace(/\.0$/, '') + 'M';
    if (n >= 1e3) return (n / 1e3).toFixed(1).replace(/\.0$/, '') + 'K';
    return String(n);
  };
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const bytes = b => {
    b = Number(b) || 0;
    if (b > 1073741824) return (b / 1073741824).toFixed(1) + ' GB';
    if (b > 1048576) return (b / 1048576).toFixed(1) + ' MB';
    if (b > 1024) return (b / 1024).toFixed(0) + ' KB';
    return b + ' B';
  };
  const ago = ts => {
    const d = Date.now() - ts;
    const m = Math.floor(d / 60000);
    if (m < 1) return 'just now';
    if (m < 60) return m + 'm ago';
    const h = Math.floor(m / 60);
    if (h < 24) return h + 'h ago';
    const dd = Math.floor(h / 24);
    if (dd < 30) return dd + 'd ago';
    return new Date(ts).toLocaleDateString();
  };

  let toastTimer = null;
  function toast(msg) {
    const t = $('#toast');
    t.textContent = msg; t.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove('show'), 2200);
  }

  async function api(path, opts) {
    opts = opts || {};
    const headers = Object.assign({}, opts.headers || {});
    if (token) headers['Authorization'] = 'Bearer ' + token;
    let body = opts.body;
    if (body && !(body instanceof FormData)) {
      headers['Content-Type'] = 'application/json';
      body = JSON.stringify(body);
    }
    const res = await fetch('/api' + path, { method: opts.method || 'GET', headers, body });
    let data = null;
    try { data = await res.json(); } catch (e) {}
    if (!res.ok) throw new Error((data && data.error) || ('Request failed (' + res.status + ')'));
    return data;
  }

  /* ---------------- auth gate ---------------- */
  $('#gBtn').addEventListener('click', doLogin);
  $('#gPass').addEventListener('keydown', e => { if (e.key === 'Enter') doLogin(); });

  async function doLogin() {
    const btn = $('#gBtn');
    const err = $('#gErr');
    err.textContent = '';
    btn.disabled = true;
    try {
      const data = await api('/auth/login', {
        method: 'POST',
        body: { email: $('#gEmail').value.trim(), password: $('#gPass').value }
      });
      if (!data.user.isAdmin) throw new Error('Ye account admin nahi hai.');
      token = data.token;
      localStorage.setItem(TOKEN_KEY, token);
      meUser = data.user;
      showPanel();
    } catch (e) {
      err.textContent = e.message;
    } finally { btn.disabled = false; }
  }

  function showPanel() {
    $('#gate').classList.add('hidden');
    $('#panel').classList.remove('hidden');
    $('#whoami').textContent = '@' + meUser.username;
    boot();
  }

  $('#logoutBtn').addEventListener('click', () => {
    localStorage.removeItem(TOKEN_KEY);
    location.reload();
  });

  /* ---------------- tabs ---------------- */
  $('#tabs').addEventListener('click', e => {
    const b = e.target.closest('button[data-tab]');
    if (!b) return;
    tab = b.dataset.tab;
    $$('#tabs button').forEach(x => x.classList.toggle('active', x === b));
    searchTerm = '';
    $('#search').value = '';
    $('#search').placeholder = tab === 'videos' ? 'Caption ya @username...' : tab === 'users' ? 'Naam, username ya email...' : 'Search reports...';
    $('#search').style.visibility = (tab === 'reports' || tab === 'appeals') ? 'hidden' : 'visible';
    if (tab === 'chats') $('#search').placeholder = '@username se chat dhundein...';
    render();
  });

  $('#refreshBtn').addEventListener('click', () => { loadStats(); render(); });

  let searchTimer = null;
  $('#search').addEventListener('input', e => {
    searchTerm = e.target.value.trim();
    clearTimeout(searchTimer);
    searchTimer = setTimeout(render, 250);
  });

  /* ---------------- modal ---------------- */
  function openModal(title, sub, fields, onSubmit) {
    $('#mTitle').textContent = title;
    $('#mSub').textContent = sub || '';
    $('#mBody').innerHTML = fields.map(f =>
      '<div class="field"><label>' + f.label + '</label>' +
      '<input id="mf_' + f.key + '" type="number" min="0" step="1" value="' + (Number(f.value) || 0) + '"></div>' +
      (f.chips ? '<div class="chips">' + f.chips.map(c =>
        '<button type="button" data-add="' + c + '" data-for="' + f.key + '">+' + (c >= 1000000 ? (c / 1000000) + 'M' : c >= 1000 ? (c / 1000) + 'K' : c) + '</button>'
      ).join('') + '</div>' : '')
    ).join('');
    $('#modal').classList.remove('hidden');

    $$('#mBody [data-add]').forEach(btn => btn.addEventListener('click', () => {
      const inp = $('#mf_' + btn.dataset.for);
      inp.value = (Number(inp.value) || 0) + Number(btn.dataset.add);
    }));

    $('#mSave').onclick = async () => {
      const values = {};
      fields.forEach(f => { values[f.key] = Math.max(0, Math.floor(Number($('#mf_' + f.key).value) || 0)); });
      $('#mSave').disabled = true;
      try { await onSubmit(values); closeModal(); }
      catch (e) { toast(e.message); }
      finally { $('#mSave').disabled = false; }
    };
    $('#mCancel').onclick = closeModal;
  }

  function closeModal() { $('#modal').classList.add('hidden'); }

  /* ---------------- data ---------------- */
  let stats = null;

  let lastSync = 0;
  let lbMetric = localStorage.getItem('tokclip_lb_metric') === 'likes' ? 'likes' : 'views';
  let lastOverview = null;

  let chartRange = (() => {
    const r = localStorage.getItem('tokclip_chart_range');
    return ['24h', '7d', '30d'].indexOf(r) !== -1 ? r : '24h';
  })();

  async function loadStats() {
    try {
      const d = await api('/admin/overview?range=' + encodeURIComponent(chartRange));
      lastOverview = d;
      stats = d.stats;
      lastSync = Date.now();
      renderStats();
      renderDash(d);
      const badge = $('#repBadge');
      if (stats.reportsPending > 0) {
        badge.textContent = stats.reportsPending;
        badge.classList.remove('hidden');
      } else badge.classList.add('hidden');
      const ab = $('#appBadge');
      if (stats.appealsPending > 0) {
        ab.textContent = stats.appealsPending;
        ab.classList.remove('hidden');
      } else ab.classList.add('hidden');
    } catch (e) { toast(e.message); }
  }

  function gotoTab(name, silent) {
    const btn = $$('#tabs button').find(b => b.dataset.tab === name);
    if (!btn) return;
    btn.click();

    if (!silent) {
      // content tak scroll (dashboard neeche push kar deta hai)
      const tabsEl = $('#tabs');
      if (tabsEl) {
        const y = tabsEl.getBoundingClientRect().top + window.scrollY - 64;
        window.scrollTo({ top: Math.max(0, y), behavior: 'smooth' });
      }
      const c = $('#content');
      if (c) { c.classList.remove('flash'); void c.offsetWidth; c.classList.add('flash'); }
      try { history.replaceState(null, '', '#' + name); } catch (e) {}
    }
  }

  function sparkPath(values, w, h) {
    const n = values.length;
    const max = Math.max(1, ...values);
    const stepX = n > 1 ? w / (n - 1) : w;
    const y = v => (h - 3) - (v / max) * (h - 8);
    let line = '';
    values.forEach((v, i) => {
      line += (i === 0 ? 'M' : 'L') + (i * stepX).toFixed(2) + ' ' + y(v).toFixed(2) + ' ';
    });
    const area = line + 'L' + w + ' ' + h + ' L0 ' + h + ' Z';
    const peakIdx = values.indexOf(Math.max(...values));
    return {
      line, area, max,
      peak: { x: (peakIdx * stepX).toFixed(2), y: y(values[peakIdx]).toFixed(2) },
      last: { x: ((n - 1) * stepX).toFixed(2), y: y(values[n - 1]).toFixed(2) }
    };
  }

  function renderChart(chart) {
    if (!chart || !chart.series) return '';

    const defs = [
      { key: 'users', label: 'New users', cls: 'c-users' },
      { key: 'videos', label: 'New videos', cls: 'c-videos' },
      { key: 'reports', label: 'Reports', cls: 'c-reports' },
      { key: 'messages', label: 'Messages', cls: 'c-messages' }
    ];

    const rng = chart.range || '24h';
    const unit = chart.unit === 'day' ? '/d' : '/h';
    const title = rng === '24h' ? 'Last 24 hours' : rng === '7d' ? 'Last 7 days' : 'Last 30 days';
    const startLabel = rng === '24h' ? '24h ago' : rng === '7d' ? '7 days ago' : '30 days ago';

    const cells = defs.map(d => {
      const vals = chart.series[d.key] || [];
      const p = sparkPath(vals, 100, 34);
      const total = (chart.totals && chart.totals[d.key]) || 0;
      return '<div class="chart-cell ' + d.cls + '">' +
        '<div class="cc-head"><span class="cc-l">' + d.label + '</span>' +
          '<span class="cc-v">' + fmt(total) + '</span></div>' +
        '<svg class="spark" viewBox="0 0 100 34" preserveAspectRatio="none" aria-hidden="true">' +
          '<path class="sp-area" d="' + p.area + '"></path>' +
          '<path class="sp-line" d="' + p.line + '" vector-effect="non-scaling-stroke"></path>' +
          (p.max > 0
            ? '<circle class="sp-dot" cx="' + p.last.x + '" cy="' + p.last.y + '" r="1.7" vector-effect="non-scaling-stroke"></circle>'
            : '') +
        '</svg>' +
        '<div class="cc-foot"><span>' + startLabel + '</span><span>peak ' + p.max + unit + '</span><span>now</span></div>' +
      '</div>';
    }).join('');

    const tabs = ['24h', '7d', '30d'].map(r =>
      '<button class="range-btn' + (r === rng ? ' active' : '') + '" data-range="' + r + '">' + r.toUpperCase() + '</button>'
    ).join('');

    return '<div class="chart-card">' +
      '<div class="act-head">' +
        '<span>' + title + ' <small>auto-refresh 30s</small></span>' +
        '<span class="range-tabs">' + tabs + '</span>' +
      '</div>' +
      '<div class="chart-grid">' + cells + '</div>' +
      '<div class="chart-axis"><span>' + esc((chart.labels || [])[0] || '') + '</span>' +
        '<span>' + esc((chart.labels || [])[Math.floor(((chart.labels || []).length - 1) / 2)] || '') + '</span>' +
        '<span>' + esc((chart.labels || [])[(chart.labels || []).length - 1] || '') + '</span></div>' +
    '</div>';
  }

  function wireChartToggles() {
    $$('[data-range]').forEach(btn => btn.addEventListener('click', async () => {
      const r = btn.dataset.range;
      if (r === chartRange) return;
      chartRange = r;
      localStorage.setItem('tokclip_chart_range', r);
      $$('[data-range]').forEach(b => b.classList.toggle('active', b.dataset.range === r));
      await loadStats();
    }));
  }

  function renderLeaderboard(lb) {
    if (!lb) return '';

    const metric = lbMetric;
    const creators = (lb.creators && lb.creators[metric === 'likes' ? 'byLikes' : 'byViews']) || [];
    const videos = (lb.videos && lb.videos[metric === 'likes' ? 'byLikes' : 'byViews']) || [];

    const toggle =
      '<span class="range-tabs">' +
        ['views', 'likes'].map(m =>
          '<button class="range-btn' + (m === metric ? ' active' : '') + '" data-lb="' + m + '">' + m.toUpperCase() + '</button>'
        ).join('') +
      '</span>';

    const medal = i => ['🥇', '🥈', '🥉'][i] || ('#' + (i + 1));
    const val = n => fmt(n);

    const rankMove = e => {
      if (e.rankChange === null || e.rankChange === undefined) {
        return '<span class="rc new" title="Pehli baar list mein">NEW</span>';
      }
      if (e.rankChange > 0) return '<span class="rc up" title="' + (e.prevRank || '') + ' se upar">▲' + e.rankChange + '</span>';
      if (e.rankChange < 0) return '<span class="rc down" title="' + (e.prevRank || '') + ' se neeche">▼' + Math.abs(e.rankChange) + '</span>';
      return '<span class="rc flat" title="koi change nahi">—</span>';
    };

    const basis = lb.basisAt
      ? 'vs ' + ago(lb.basisAt)
      : 'vs 24h (kal se compare hoga)';

    const creatorRows = creators.length
      ? creators.map((c, i) =>
          '<div class="lb-row clickable" data-user="' + c.id + '" title="Profile kholein">' +
            '<span class="lb-rank' + (i < 3 ? ' top' : '') + '">' + medal(i) + '</span>' +
            rankMove(c) +
            '<div class="mini-avatar">' + esc((c.name || c.username || '?').slice(0, 1).toUpperCase()) + '</div>' +
            '<div class="lb-body">' +
              '<div class="lb-t">@' + esc(c.username) + '</div>' +
              '<div class="lb-s">' + fmt(c.videos) + ' videos · ' + fmt(c.followers) + ' followers</div>' +
            '</div>' +
            '<div class="lb-val">' + val(metric === 'likes' ? c.likes : c.views) +
              '<span>' + (metric === 'likes' ? 'likes' : 'views') + '</span></div>' +
          '</div>').join('')
      : '<div class="empty" style="padding:14px">Abhi koi data nahi</div>';

    const videoRows = videos.length
      ? videos.map((v, i) =>
          '<div class="lb-row">' +
            '<span class="lb-rank' + (i < 3 ? ' top' : '') + '">' + medal(i) + '</span>' +
            rankMove(v) +
            '<a class="lb-thumb" href="' + esc(v.url) + '" target="_blank" rel="noopener">🎬</a>' +
            '<div class="lb-body">' +
              '<div class="lb-t">' + esc((v.caption || '(no caption)').slice(0, 42)) + '</div>' +
              '<div class="lb-s">@' + esc(v.author.username) + ' · ' + ago(v.createdAt) + '</div>' +
            '</div>' +
            '<div class="lb-val">' + val(metric === 'likes' ? v.likes : v.views) +
              '<span>' + (metric === 'likes' ? 'likes' : 'views') + '</span></div>' +
          '</div>').join('')
      : '<div class="empty" style="padding:14px">Abhi koi video nahi</div>';

    return '<div class="lb-wrap">' +
      '<div class="act-head">' +
        '<span>🏆 Leaderboards <small>' + esc(basis) + ' · 30s auto-refresh</small></span>' + toggle +
      '</div>' +
      '<div class="lb-grid">' +
        '<div class="lb-card"><div class="lb-head">Top creators</div>' + creatorRows + '</div>' +
        '<div class="lb-card"><div class="lb-head">Top videos</div>' + videoRows + '</div>' +
      '</div>' +
    '</div>';
  }

  function wireLeaderboardToggle() {
    $$('[data-user]').forEach(row => row.addEventListener('click', () => openCreator(row.dataset.user)));
    $$('[data-lb]').forEach(btn => btn.addEventListener('click', () => {
      const m = btn.dataset.lb;
      if (m === lbMetric) return;
      lbMetric = m;
      localStorage.setItem('tokclip_lb_metric', m);
      const dash = $('#dash');
      if (!dash || !lastOverview) return;
      // sirf leaderboard section refresh karein
      const wrap = $('.lb-wrap');
      if (wrap) {
        const tmp = document.createElement('div');
        tmp.innerHTML = renderLeaderboard(lastOverview.leaderboard);
        wrap.replaceWith(tmp.firstElementChild);
        wireLeaderboardToggle();
      }
    }));
  }

  function renderDash(d) {
    const a = d.alerts || {};
    const card = (key, label, value, tone, hint) =>
      '<button class="alert-card ' + tone + (value ? '' : ' zero') + '" data-goto="' + key + '" ' +
        'title="' + esc(label) + ' — open ' + key + ' tab">' +
        '<span class="ac-top"><span class="ac-v">' + fmt(value) + '</span><span class="ac-go">→</span></span>' +
        '<span class="ac-l">' + label + '</span>' +
        '<span class="ac-h">' + hint + '</span>' +
      '</button>';

    const icons = { report: '🚩', appeal: '📨', ban: '🚫', message: '💬', user: '👤' };
    const items = (d.activity || []).map(ev =>
      '<div class="act-row">' +
        '<span class="act-ico">' + (icons[ev.type] || '•') + '</span>' +
        '<div class="act-body">' +
          '<div class="act-t">' + esc(ev.text) + '</div>' +
          (ev.sub ? '<div class="act-s">' + esc(ev.sub) + '</div>' : '') +
        '</div>' +
        '<span class="act-at">' + ago(ev.at) + '</span>' +
      '</div>').join('');

    $('#dash').innerHTML =
      renderChart(d.chart) +
      '<div class="alert-grid">' +
        card('reports', 'Pending reports', a.reports, 'red', 'review chahiye') +
        card('appeals', 'Ban appeals', a.appeals, 'amber', 'approve / reject') +
        card('chats', 'Unread chats', a.chatUnread, 'blue', 'messages unread') +
        card('users', 'Banned users', a.banned, 'orange', 'suspended') +
        card('users', 'Unverified', a.unverified, 'gray', 'email pending') +
      '</div>' +
      renderLeaderboard(d.leaderboard) +
      '<div class="activity-card">' +
        '<div class="act-head">Recent activity <small>auto-refresh every 30s</small></div>' +
        (items || '<div class="empty" style="padding:16px">Koi activity nahi</div>') +
      '</div>';

    $$('[data-goto]').forEach(b => b.addEventListener('click', () => gotoTab(b.dataset.goto)));
    wireChartToggles();
    wireLeaderboardToggle();
  }

  /* auto-refresh (30s) + live sync label */
  setInterval(() => {
    if (!lastSync) return;
    const s = Math.floor((Date.now() - lastSync) / 1000);
    const el = $('#syncText');
    if (el) el.textContent = 'updated ' + s + 's ago · refresh in ' + Math.max(0, 30 - s) + 's';
  }, 1000);

  setInterval(() => { if (!document.hidden && token) loadStats(); }, 30000);

  document.addEventListener('visibilitychange', () => {
    if (!document.hidden && token && Date.now() - lastSync > 25000) loadStats();
  });

  function renderStats() {
    if (!stats) return;
    const card = (label, value, sub, tone) =>
      '<div class="card ' + (tone || '') + '"><div class="card-l">' + label + '</div>' +
      '<div class="card-v">' + value + '</div>' +
      (sub ? '<div class="card-s">' + sub + '</div>' : '') + '</div>';

    $('#cards').innerHTML =
      card('Users', fmt(stats.users), '+' + fmt(stats.newUsers24h) + ' last 24h') +
      card('Videos', fmt(stats.videos), '+' + fmt(stats.newVideos24h) + ' last 24h') +
      card('Total views', fmt(stats.views), 'all videos') +
      card('Likes', fmt(stats.likes), 'real + boosted') +
      card('Comments', fmt(stats.comments), '') +
      card('Messages', fmt(stats.messages), 'DMs') +
      card('Follows', fmt(stats.follows), '') +
      card('Reports', fmt(stats.reportsPending), 'pending review', stats.reportsPending > 0 ? 'warn' : '') +
      card('Appeals', fmt(stats.appealsPending), 'ban appeals waiting', stats.appealsPending > 0 ? 'warn' : '') +
      card('Banned', fmt(stats.banned), 'suspended accounts', stats.banned > 0 ? 'warn' : '') +
      card('Unverified', fmt(stats.unverified), 'email not verified') +
      card('Storage', bytes(stats.storageBytes), 'videos on disk');
  }

  async function render() {
    if (tab === 'videos') return renderVideos();
    if (tab === 'users') return renderUsers();
    if (tab === 'appeals') return renderAppeals();
    if (tab === 'chats') return renderChats();
    return renderReports();
  }

  /* ---------------- videos ---------------- */
  async function renderVideos() {
    $('#content').innerHTML = '<div class="spinner"></div>';
    try {
      const data = await api('/admin/videos?limit=100&q=' + encodeURIComponent(searchTerm));
      if (!data.items.length) {
        $('#content').innerHTML = '<div class="empty">Koi video nahi mili.</div>';
        return;
      }
      $('#content').innerHTML =
        '<div class="table-wrap"><table class="table">' +
        '<thead><tr><th>Video</th><th>Author</th><th class="num">Views</th><th class="num">Likes</th><th class="num">Comments</th><th class="num">Reports</th><th>Added</th><th></th></tr></thead><tbody>' +
        data.items.map(v =>
          '<tr>' +
            '<td class="cell-video">' +
              '<div class="thumb">' + (v.url && v.url.startsWith('http') ? '🌐' : '🎬') + '</div>' +
              '<div class="vtxt"><div class="cap">' + esc((v.caption || '').slice(0, 64) || '(no caption)') + '</div>' +
              '<a class="mini-link" href="' + esc(v.url) + '" target="_blank" rel="noopener">view file ↗</a></div>' +
            '</td>' +
            '<td><a class="mini-link" href="/?u=' + esc(v.author.username) + '" target="_blank" rel="noopener">@' + esc(v.author.username) + '</a>' +
              '<div class="sub2">' + esc(v.author.name || '') + '</div></td>' +
            '<td class="num">' + fmt(v.views) + '</td>' +
            '<td class="num">' + fmt(v.likes) + '</td>' +
            '<td class="num">' + fmt(v.comments) + '</td>' +
            '<td class="num">' + (v.reports ? '<span class="flag">' + v.reports + '</span>' : '—') + '</td>' +
            '<td class="nowrap">' + ago(v.createdAt) + '</td>' +
            '<td class="acts">' +
              '<button class="mini-btn ok-btn" data-bvid="' + v.id + '">Boost</button> ' +
              '<button class="mini-btn danger" data-del="' + v.id + '" data-cap="' + esc((v.caption || '').slice(0, 40)) + '">Remove</button></td>' +
          '</tr>').join('') +
        '</tbody></table></div>';

      $$('[data-del]').forEach(b => b.addEventListener('click', async () => {
        if (!confirm('Video remove karni hai?\n\n"' + b.dataset.cap + '"\n\nYe action undo nahi ho sakta.')) return;
        b.disabled = true;
        try {
          await api('/admin/videos/' + b.dataset.del, { method: 'DELETE' });
          toast('Video remove ho gayi');
          loadStats(); render();
        } catch (e) { toast(e.message); b.disabled = false; }
      }));

      // boost (sirf admin)
      $$('[data-bvid]').forEach(b => b.addEventListener('click', () => {
        const v = data.items.find(x => x.id === b.dataset.bvid);
        if (!v) return;
        openModal('Boost video', '@' + v.author.username + ' · ' + (v.caption || '').slice(0, 50), [
          { key: 'views', label: 'Views', value: v.views, chips: [1000, 10000, 100000, 1000000] },
          { key: 'likes', label: 'Likes', value: v.likes, chips: [100, 1000, 10000, 100000] }
        ], async (vals) => {
          await api('/admin/videos/' + v.id + '/boost', { method: 'POST', body: vals });
          toast('Video stats update ho gaye ✅');
          loadStats(); render();
        });
      }));
    } catch (e) {
      $('#content').innerHTML = '<div class="empty">' + esc(e.message) + '</div>';
    }
  }

  /* ---------------- users ---------------- */
  async function renderUsers() {
    $('#content').innerHTML = '<div class="spinner"></div>';
    try {
      const data = await api('/admin/users?limit=100&q=' + encodeURIComponent(searchTerm));
      if (!data.items.length) {
        $('#content').innerHTML = '<div class="empty">Koi user nahi mila.</div>';
        return;
      }
      $('#content').innerHTML =
        '<div class="table-wrap"><table class="table">' +
        '<thead><tr><th>User</th><th>Email</th><th class="num">Videos</th><th class="num">Views</th><th class="num">Followers</th><th>Joined</th><th></th></tr></thead><tbody>' +
        data.items.map(u =>
          '<tr class="clickable' + (u.banned ? ' row-banned' : '') + '" data-openuser="' + u.id + '">' +
            '<td><div class="u-cell"><div class="mini-avatar">' + esc((u.name || u.username).slice(0, 1).toUpperCase()) + '</div>' +
              '<div><b>@' + esc(u.username) + '</b>' +
              (u.isAdmin ? ' <span class="tag">admin</span>' : '') +
              (u.banned ? ' <span class="tag banned">banned</span>' : '') +
              '<div class="sub2">' + esc(u.name) + (u.banned && u.banReason ? ' \u00b7 ' + esc(u.banReason) : '') + '</div></div></div></td>'+
            '<td class="mono">' + esc(u.email) + '</td>' +
            '<td class="num">' + fmt(u.videos) + '</td>' +
            '<td class="num">' + fmt(u.views) + '</td>' +
            '<td class="num">' + fmt(u.followers) + '</td>' +
            '<td class="nowrap">' + ago(u.createdAt) + '</td>' +
            '<td class="acts">' +
              '<button class="mini-btn ok-btn" data-bfol="' + u.id + '" data-name="' + esc(u.username) + '" data-fol="' + u.followers + '">Boost</button> ' +
              '<button class="mini-btn ' + (u.banned ? '' : 'warn-btn') + '" data-ban="' + u.id + '" data-banned="' + (u.banned ? 1 : 0) + '" data-name="' + esc(u.username) + '">' +
                (u.banned ? 'Unban' : 'Ban') + '</button> ' +
              (u.isAdmin ? '' : '<button class="mini-btn" data-adm="' + u.id + '" data-on="1">Make admin</button> ') +
              '<button class="mini-btn danger" data-deluser="' + u.id + '" data-name="' + esc(u.username) + '">Delete</button>' +
            '</td>' +
          '</tr>').join('') +
        '</tbody></table></div>';

      $$('[data-openuser]').forEach(row => row.addEventListener('click', ev => {
        if (ev.target.closest('button')) return;
        openCreator(row.dataset.openuser);
      }));

      $$('[data-adm]').forEach(b => b.addEventListener('click', async () => {
        if (!confirm('Is user ko admin banana hai? Admin poora panel access kar sakega.')) return;
        try {
          await api('/admin/users/' + b.dataset.adm + '/admin', { method: 'POST', body: { isAdmin: true } });
          toast('User admin ban gaya'); loadStats(); render();
        } catch (e) { toast(e.message); }
      }));

      $$('[data-ban]').forEach(b => b.addEventListener('click', async () => {        const isBanned = b.dataset.banned === '1';
        let reason = '';
        if (isBanned) {
          if (!confirm('@' + b.dataset.name + ' ka ban hata dein? Wo dobara login kar sakega.')) return;
        } else {
          reason = prompt('@' + b.dataset.name + ' ko ban karne ki wajah (user ko dikhayi jayegi):', 'Community guidelines violation');
          if (reason === null) return;
        }
        b.disabled = true;
        try {
          await api('/admin/users/' + b.dataset.ban + '/ban', {
            method: 'POST', body: { banned: !isBanned, reason: reason }
          });
          toast(isBanned ? 'Ban hata diya — user wapas active' : 'User ban ho gaya — login block + videos feed se hat gayi');
          loadStats(); render();
        } catch (e) { toast(e.message); b.disabled = false; }
      }));

      // boost followers (sirf admin)
      $$('[data-bfol]').forEach(b => b.addEventListener('click', () => {
        openModal('Boost followers', '@' + b.dataset.name + ' ka follower count set karein', [
          { key: 'followers', label: 'Followers', value: Number(b.dataset.fol) || 0, chips: [1000, 10000, 100000, 1000000] }
        ], async (vals) => {
          await api('/admin/users/' + b.dataset.bfol + '/followers', { method: 'POST', body: { count: vals.followers } });
          toast('Followers update ho gaye ✅');
          loadStats(); render();
        });
      }));

      $$('[data-deluser]').forEach(b => b.addEventListener('click', async () => {
        if (!confirm('@' + b.dataset.name + ' ka account delete karein? Uski saari videos aur data chala jayega.')) return;
        b.disabled = true;
        try {
          await api('/admin/users/' + b.dataset.deluser, { method: 'DELETE' });
          toast('User delete ho gaya'); loadStats(); render();
        } catch (e) { toast(e.message); b.disabled = false; }
      }));
    } catch (e) {
      $('#content').innerHTML = '<div class="empty">' + esc(e.message) + '</div>';
    }
  }

  /* ---------------- appeals ---------------- */
  let appealFilter = 'pending';

  async function renderAppeals() {
    $('#content').innerHTML = '<div class="spinner"></div>';
    try {
      const data = await api('/admin/appeals?status=' + encodeURIComponent(appealFilter));
      const filters =
        '<div class="filters">' +
        ['pending', 'approved', 'rejected'].map(s =>
          '<button class="mini-btn ' + (appealFilter === s ? 'active' : '') + '" data-af="' + s + '">' + s + '</button>').join('') +
        '</div>';

      if (!data.items.length) {
        $('#content').innerHTML = filters + '<div class="empty">Koi ' + appealFilter + ' appeal nahi hai.</div>';
      } else {
        $('#content').innerHTML = filters +
          '<div class="table-wrap"><table class="table">' +
          '<thead><tr><th>User</th><th>Ban reason</th><th>Appeal</th><th>When</th><th></th></tr></thead><tbody>' +
          data.items.map(a =>
            '<tr>' +
              '<td><div class="u-cell"><div class="mini-avatar">' + esc((a.user.name || a.user.username).slice(0, 1).toUpperCase()) + '</div>' +
                '<div><b>@' + esc(a.user.username) + '</b>' +
                (a.stillBanned ? ' <span class="tag banned">banned</span>' : ' <span class="tag">active</span>') +
                '<div class="sub2">' + esc(a.user.email) + '</div></div></div></td>' +
              '<td style="max-width:220px"><span class="tag">' + esc(a.banReason || '—') + '</span></td>' +
              '<td style="max-width:340px">' +
                '<div class="cap">“' + esc(a.message) + '”</div>' +
                (a.adminNote ? '<div class="sub2">Admin note: ' + esc(a.adminNote) + '</div>' : '') +
              '</td>' +
              '<td class="nowrap">' + ago(a.createdAt) +
                (a.reviewedAt ? '<div class="sub2">reviewed ' + ago(a.reviewedAt) + '</div>' : '') + '</td>' +
              '<td class="acts">' +
                (appealFilter === 'pending'
                  ? '<button class="mini-btn ok-btn" data-approve="' + a.id + '" data-name="' + esc(a.user.username) + '">Approve &amp; unban</button> ' +
                    '<button class="mini-btn danger" data-reject="' + a.id + '" data-name="' + esc(a.user.username) + '">Reject</button>'
                  : '<button class="mini-btn" data-reopen-appeal="' + a.id + '">Reopen</button>') +
              '</td>' +
            '</tr>').join('') +
          '</tbody></table></div>';
      }

      $$('[data-af]').forEach(b => b.addEventListener('click', () => { appealFilter = b.dataset.af; renderAppeals(); }));

      $$('[data-approve]').forEach(b => b.addEventListener('click', async () => {
        if (!confirm('@' + b.dataset.name + ' ki appeal approve karein?\n\nBan hat jayega aur account dobara active ho jayega.')) return;
        b.disabled = true;
        try {
          await api('/admin/appeals/' + b.dataset.approve, { method: 'POST', body: { status: 'approved' } });
          toast('Approve ✅ — user ka ban hat gaya');
          loadStats(); renderAppeals();
        } catch (e) { toast(e.message); b.disabled = false; }
      }));

      $$('[data-reject]').forEach(b => b.addEventListener('click', async () => {
        const note = prompt('@' + b.dataset.name + ' ki appeal reject karne ki wajah (user ko dikhegi):', 'Community guidelines still violated');
        if (note === null) return;
        b.disabled = true;
        try {
          await api('/admin/appeals/' + b.dataset.reject, { method: 'POST', body: { status: 'rejected', note: note } });
          toast('Appeal reject ho gayi');
          loadStats(); renderAppeals();
        } catch (e) { toast(e.message); b.disabled = false; }
      }));

      $$('[data-reopen-appeal]').forEach(b => b.addEventListener('click', async () => {
        try {
          await api('/admin/appeals/' + b.dataset.reopenAppeal, { method: 'POST', body: { status: 'pending' } });
          toast('Appeal dobara pending ho gayi');
          loadStats(); renderAppeals();
        } catch (e) { toast(e.message); }
      }));
    } catch (e) {
      $('#content').innerHTML = '<div class="empty">' + esc(e.message) + '</div>';
    }
  }

  /* ---------------- creator drawer ---------------- */
  function openDrawer() {
    $('#drawerWrap').classList.remove('hidden');
    requestAnimationFrame(() => $('#drawer').classList.add('open'));
  }

  function closeDrawer() {
    $('#drawer').classList.remove('open');
    setTimeout(() => $('#drawerWrap').classList.add('hidden'), 220);
  }

  $('#dwClose').addEventListener('click', closeDrawer);
  $('#drawerOverlay').addEventListener('click', closeDrawer);
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeDrawer(); });

  let creatorData = null;

  async function openCreator(userId) {
    openDrawer();
    $('#dwBody').innerHTML = '<div class="spinner"></div>';
    try {
      const d = await api('/admin/users/' + userId + '/profile');
      creatorData = d;
      renderCreator(d);
    } catch (e) {
      $('#dwBody').innerHTML = '<div class="empty">' + esc(e.message) + '</div>';
    }
  }

  function previewOf(last) {
    if (!last) return '—';
    if (last.kind === 'image') return '📷 Photo';
    if (last.kind === 'video') return '🎬 Video';
    if (last.kind === 'audio') return '🎤 Voice note';
    return (last.body || '').slice(0, 60);
  }

  function renderCreatorChats(d) {
    const chats = d.chats || [];
    if (!chats.length) {
      return '<div class="dw-sec">Direct messages <small>0</small></div>' +
        '<div class="dw-empty">Is creator ki koi DM conversation nahi.</div>';
    }

    const rows = chats.map(c =>
      '<div class="dw-chat" data-chat-with="' + c.other.id + '" title="Conversation padhein">' +
        '<div class="mini-avatar">' + esc((c.other.name || c.other.username || '?').slice(0, 1).toUpperCase()) + '</div>' +
        '<div class="dw-chat-body">' +
          '<div class="dw-chat-top"><b>@' + esc(c.other.username) + '</b>' +
            '<span class="dw-chat-time">' + ago(c.lastAt) + '</span></div>' +
          '<div class="dw-chat-last">' +
            (c.last ? '<span class="sub2">' + (c.last.fromId === d.user.id ? esc(d.user.username) : esc(c.other.username)) + ':</span> ' : '') +
            esc(previewOf(c.last)) +
          '</div>' +
        '</div>' +
        (c.unread ? '<span class="flag">' + c.unread + '</span>' : '<span class="dw-chat-n">' + c.total + '</span>') +
      '</div>').join('');

    return '<div class="dw-sec">Direct messages <small>' + chats.length + '</small></div>' +
      '<div class="dw-chats">' + rows + '</div>';
  }

  function renderDmNotes() {
    const box = $('#dwNotes');
    if (!box || !creatorData) return;
    const notes = creatorData.adminNotes || [];
    box.innerHTML = notes.length
      ? notes.map(n =>
          '<div class="dw-note">' +
            '<div class="dw-note-body">' + esc(n.body) + '</div>' +
            '<div class="dw-note-meta">@' + esc(n.from) + ' · ' + ago(n.createdAt) +
              (n.readAt ? ' · read' : ' · unread') + '</div>' +
          '</div>').join('')
      : '<div class="dw-empty" style="margin-bottom:8px">Abhi koi admin message nahi bheja gaya.</div>';
  }

  async function reloadCreator() {
    if (!creatorData) return;
    creatorData = await api('/admin/users/' + creatorData.user.id + '/profile');
  }

  async function sendAdminNote() {
    const input = $('#dwAdminInput');
    const btn = $('#dwAdminSend');
    if (!input || !creatorData) return;
    const body = input.value.trim();
    if (!body) { toast('Message likhein'); return; }

    btn.disabled = true;
    try {
      await api('/admin/users/' + creatorData.user.id + '/reply', { method: 'POST', body: { body } });
      input.value = '';
      await reloadCreator();
      renderDmNotes();
      toast('Admin message bhej diya ✅');
    } catch (e) {
      toast(e.message);
    } finally {
      btn.disabled = false;
    }
  }

  async function openCreatorChat(otherId) {
    if (!creatorData) return;
    const me = creatorData.user;
    const other = (creatorData.chats || []).find(c => c.other.id === otherId);
    const otherName = other ? '@' + other.other.username : 'chat';

    $('#dwBody').innerHTML =
      '<div class="dw-thread-head">' +
        '<button class="mini-btn" id="dwThreadBack">← Profile</button>' +
        '<span>@' + esc(me.username) + ' ↔ ' + esc(otherName) + '</span>' +
      '</div>' +
      '<div class="dw-thread" id="dwThread"><div class="spinner"></div></div>' +
      '<div class="dw-admin-box">' +
        '<div class="dw-sec">Admin message to @' + esc(me.username) + ' <small>private · sirf creator ko</small></div>' +
        '<div class="dw-notes" id="dwNotes"></div>' +
        '<div class="dw-composer">' +
          '<input id="dwAdminInput" maxlength="800" placeholder="Admin ki taraf se message likhein...">' +
          '<button class="mini-btn ok-btn" id="dwAdminSend">Send</button>' +
        '</div>' +
      '</div>';

    $('#dwThreadBack').addEventListener('click', () => { if (creatorData) renderCreator(creatorData); });

    renderDmNotes();
    $('#dwAdminSend').addEventListener('click', sendAdminNote);
    $('#dwAdminInput').addEventListener('keydown', e => { if (e.key === 'Enter') sendAdminNote(); });

    try {
      const d = await api('/admin/chats/' + me.id + '/' + otherId);
      const box = $('#dwThread');

      if (!d.messages.length) {
        box.innerHTML = '<div class="empty">Koi message nahi.</div>';
        return;
      }

      box.innerHTML = d.messages.map(m => {
        const mine = m.fromId === me.id;
        const who = mine ? me.username : otherName.replace('@', '');
        const isMedia = m.kind === 'image' || m.kind === 'video' || m.kind === 'audio';
        const inner = m.kind === 'image' && m.url
          ? '<a href="' + esc(m.url) + '" target="_blank" rel="noopener"><img class="chat-media" src="' + esc(m.url) + '" alt="photo" loading="lazy"></a>'
          : m.kind === 'video' && m.url
            ? '<video class="chat-media" src="' + esc(m.url) + '#t=0.1" controls preload="metadata" playsinline></video>'
            : m.kind === 'audio' && m.url
              ? '<div class="voice" data-src="' + esc(m.url) + '">' +
                  '<button type="button" class="v-play">▶</button>' +
                  '<div class="v-wave">' + (Array.isArray(m.peaks) && m.peaks.length ? m.peaks : Array.from({ length: 24 }, (_, i) => 30 + ((i * 37) % 60)))
                    .map(p => '<i style="height:' + Math.max(14, p) + '%"></i>').join('') + '</div>' +
                  '<span class="v-time">' + adminDur((m.duration || 0) / 1000) + '</span>' +
                  '<button type="button" class="v-speed">' + adminSpeedLabel() + '</button>' +
                '</div>'
              : '<div class="bubble">' + esc(m.body) + '</div>';

        return '<div class="msg ' + (mine ? 'theirs' : 'mine') + (isMedia ? ' media' : '') + '">' +
          inner +
          '<div class="msg-time">@' + esc(who) + ' · ' + new Date(m.createdAt).toLocaleString() +
            (m.readAt ? ' · read' : ' · unread') + '</div>' +
        '</div>';
      }).join('');

      wireAdminVoices(box);
      box.scrollTop = box.scrollHeight;
    } catch (e) {
      $('#dwThread').innerHTML = '<div class="empty">' + esc(e.message) + '</div>';
    }
  }

  function renderCreator(d) {
    const u = d.user;
    const s = d.stats || {};
    const status = [];
    if (u.banned) status.push('<span class="tag banned">banned</span>');
    if (u.isAdmin) status.push('<span class="tag">admin</span>');
    status.push(u.verified ? '<span class="tag">verified</span>' : '<span class="tag">unverified</span>');
    status.push(u.online
      ? '<span class="tag online">● online</span>'
      : '<span class="tag">' + esc(ago(u.lastSeen || u.createdAt)) + ' last seen</span>');

    const stat = (l, v) => '<div class="dw-stat"><b>' + fmt(v) + '</b><span>' + l + '</span></div>';

    const vids = (d.videos || []).length
      ? d.videos.map(v =>
          '<div class="dw-vid">' +
            '<a class="lb-thumb" href="' + esc(v.url) + '" target="_blank" rel="noopener">🎬</a>' +
            '<div class="dw-vid-body">' +
              '<div class="lb-t">' + esc((v.caption || '(no caption)').slice(0, 46)) + '</div>' +
              '<div class="lb-s">▶ ' + fmt(v.views) + ' · ❤️ ' + fmt(v.likes) + ' · 💬 ' + fmt(v.comments) + ' · ' + ago(v.createdAt) + '</div>' +
            '</div>' +
            '<button class="mini-btn" data-vboost="' + v.id + '" data-vv="' + v.views + '" data-vl="' + v.likes + '" data-vcap="' + esc((v.caption || '').slice(0, 40)) + '">Boost</button>' +
          '</div>').join('')
      : '<div class="empty" style="padding:14px">Is creator ki koi video nahi</div>';

    $('#dwBody').innerHTML =
      '<div class="dw-profile">' +
        '<div class="mini-avatar lg">' + esc((u.name || u.username || '?').slice(0, 1).toUpperCase()) + '</div>' +
        '<div class="dw-name">' + esc(u.name || u.username) + '</div>' +
        '<div class="dw-user">@' + esc(u.username) + '</div>' +
        '<div class="dw-status">' + status.join(' ') + '</div>' +
        (u.bio ? '<div class="dw-bio">' + esc(u.bio) + '</div>' : '') +
        '<div class="dw-meta">' + esc(u.email) + ' · joined ' + ago(u.createdAt) + '</div>' +
        (u.banned && u.banReason ? '<div class="dw-ban">🚫 Ban reason: ' + esc(u.banReason) + '</div>' : '') +
      '</div>' +
      '<div class="dw-stats">' +
        stat('Videos', s.videos || 0) + stat('Views', s.views || 0) +
        stat('Likes', s.likes || 0) + stat('Comments', s.comments || 0) +
        stat('Followers', u.followers || 0) + stat('Following', d.following || 0) +
      '</div>' +
      '<div class="dw-actions">' +
        '<button class="mini-btn ok-btn" id="dwBoostFol">Boost followers</button>' +
        '<button class="mini-btn ' + (u.banned ? '' : 'warn-btn') + '" id="dwBan">' + (u.banned ? 'Unban' : 'Ban') + '</button>' +
        (u.isAdmin ? '' : '<button class="mini-btn danger" id="dwDelete">Delete user</button>') +
      '</div>' +
      renderCreatorChats(d) +
      '<div class="dw-sec">Videos <small>' + (d.videos || []).length + '</small></div>' +
      '<div class="dw-vids">' + vids + '</div>';

    $('#dwBoostFol').addEventListener('click', () => {
      openModal('Boost followers', '@' + u.username, [
        { key: 'followers', label: 'Followers', value: u.followers || 0, chips: [1000, 10000, 100000, 1000000] }
      ], async (vals) => {
        await api('/admin/users/' + u.id + '/followers', { method: 'POST', body: { count: vals.followers } });
        toast('Followers update ho gaye ✅');
        await openCreator(u.id);
        loadStats();
      });
    });

    $('#dwBan').addEventListener('click', async () => {
      const banning = !u.banned;
      let reason = '';
      if (banning) {
        reason = prompt('@' + u.username + ' ko ban karne ki wajah:', u.banReason || 'Community guidelines violation');
        if (reason === null) return;
      } else if (!confirm('@' + u.username + ' ka ban hata dein?')) return;
      try {
        await api('/admin/users/' + u.id + '/ban', { method: 'POST', body: { banned: banning, reason: reason } });
        toast(banning ? 'User ban ho gaya' : 'Ban hata diya');
        await openCreator(u.id);
        loadStats();
      } catch (e) { toast(e.message); }
    });

    if ($('#dwDelete')) {
      $('#dwDelete').addEventListener('click', async () => {
        if (!confirm('@' + u.username + ' ka account delete karein? Saari videos bhi delete hongi.')) return;
        try {
          await api('/admin/users/' + u.id, { method: 'DELETE' });
          toast('User delete ho gaya');
          closeDrawer();
          loadStats(); render();
        } catch (e) { toast(e.message); }
      });
    }

    $$('[data-chat-with]').forEach(row => row.addEventListener('click', () => openCreatorChat(row.dataset.chatWith)));

    $$('[data-vboost]').forEach(btn => btn.addEventListener('click', () => {
      const id = btn.dataset.vboost;
      openModal('Boost video', (btn.dataset.vcap || '') + ' · @' + u.username, [
        { key: 'views', label: 'Views', value: Number(btn.dataset.vv) || 0, chips: [1000, 10000, 100000, 1000000] },
        { key: 'likes', label: 'Likes', value: Number(btn.dataset.vl) || 0, chips: [100, 1000, 10000, 100000] }
      ], async (vals) => {
        await api('/admin/videos/' + id + '/boost', { method: 'POST', body: vals });
        toast('Video stats update ho gaye ✅');
        await openCreator(u.id);
        loadStats();
      });
    }));
  }

  /* ---------------- chats ---------------- */
  async function renderChats() {
    $('#content').innerHTML = '<div class="spinner"></div>';
    try {
      const data = await api('/admin/chats?q=' + encodeURIComponent(searchTerm));
      if (!data.items.length) {
        $('#content').innerHTML = '<div class="empty">Koi chat nahi mili.</div>';
        return;
      }
      $('#content').innerHTML =
        '<div class="table-wrap"><table class="table">' +
        '<thead><tr><th>Participants</th><th class="num">Messages</th><th class="num">Unread</th><th>Last message</th><th>When</th><th></th></tr></thead><tbody>' +
        data.items.map(c =>
          '<tr>' +
            '<td><div class="u-cell"><div class="mini-avatar">' + esc((c.a.username || '?').slice(0, 1).toUpperCase()) + '</div>' +
              '<div><b>@' + esc(c.a.username) + '</b> <span class="sub2" style="display:inline">↔</span> <b>@' + esc(c.b.username) + '</b>' +
              '<div class="sub2">' + esc(c.a.name || '') + ' · ' + esc(c.b.name || '') + '</div></div></div></td>' +
            '<td class="num">' + fmt(c.total) + '</td>' +
            '<td class="num">' + (c.unread ? '<span class="flag">' + c.unread + '</span>' : '—') + '</td>' +
            '<td style="max-width:320px"><div class="cap">' +
              (c.last ? '<span class="sub2">@' + esc(c.last.fromId === c.a.id ? c.a.username : c.b.username) + ':</span> ' +
                (c.last.kind === 'image' ? '📷 Photo' : c.last.kind === 'video' ? '🎬 Video'
                  : c.last.kind === 'audio' ? '🎤 Voice note' : esc(c.last.body.slice(0, 80))) : '—') +
              '</div></td>' +
            '<td class="nowrap">' + ago(c.lastAt) + '</td>' +
            '<td class="acts"><button class="mini-btn" data-chat="' + esc(c.a.id) + '|' + esc(c.b.id) + '" data-names="' + esc('@' + c.a.username + ' ↔ @' + c.b.username) + '">View</button></td>' +
          '</tr>').join('') +
        '</tbody></table></div>';

      $$('[data-chat]').forEach(b => b.addEventListener('click', () => {
        const parts = b.dataset.chat.split('|');
        openAdminChat(parts[0], parts[1], b.dataset.names);
      }));
    } catch (e) {
      $('#content').innerHTML = '<div class="empty">' + esc(e.message) + '</div>';
    }
  }

  function adminDur(sec) {
    sec = Math.max(0, Math.round(sec || 0));
    return Math.floor(sec / 60) + ':' + String(sec % 60).padStart(2, '0');
  }

  const ADMIN_SPEED_KEY = 'tokclip_voice_speed';
  function adminSpeed() {
    const v = Number(localStorage.getItem(ADMIN_SPEED_KEY));
    return [1, 1.5, 2].indexOf(v) !== -1 ? v : 1;
  }
  function adminSpeedLabel() {
    const v = adminSpeed();
    return v === 2 ? '2x' : v === 1.5 ? '1.5x' : '1x';
  }
  function adminCycleSpeed() {
    const steps = [1, 1.5, 2];
    const cur = adminSpeed();
    const next = steps[(steps.indexOf(cur) + 1) % steps.length];
    localStorage.setItem(ADMIN_SPEED_KEY, String(next));
    $$('.v-speed').forEach(b => { b.textContent = adminSpeedLabel(); });
    $$('.voice').forEach(el => { if (el._audio) el._audio.playbackRate = next; });
    toast('Speed: ' + adminSpeedLabel());
  }

  function wireAdminVoices(scope) {
    $$('.voice', scope).forEach(el => {
      if (el._wired) return;
      el._wired = true;
      const btn = $('.v-play', el);
      const wave = $('.v-wave', el);
      const time = $('.v-time', el);
      const speedBtn = $('.v-speed', el);
      const bars = Array.from(wave.children);
      if (speedBtn) {
        speedBtn.textContent = adminSpeedLabel();
        speedBtn.addEventListener('click', e => { e.stopPropagation(); adminCycleSpeed(); });
      }

      btn.addEventListener('click', () => {
        $$('.voice', scope).forEach(o => {
          if (o !== el && o._audio && !o._audio.paused) {
            o._audio.pause();
            const ob = $('.v-play', o);
            if (ob) ob.textContent = '▶';
          }
        });
        if (!el._audio) {
          const a = new Audio(el.dataset.src);
          a.preload = 'metadata';
          a.playbackRate = adminSpeed();
          a.addEventListener('loadedmetadata', () => {
            if (isFinite(a.duration)) time.textContent = adminDur(a.duration);
            a.playbackRate = adminSpeed();
          });
          a.addEventListener('timeupdate', () => {
            const p = a.duration ? a.currentTime / a.duration : 0;
            const upto = Math.floor(p * bars.length);
            bars.forEach((b, i) => b.classList.toggle('on', i < upto));
            time.textContent = adminDur(a.currentTime);
          });
          a.addEventListener('ended', () => {
            btn.textContent = '▶';
            bars.forEach(b => b.classList.remove('on'));
            time.textContent = adminDur(a.duration);
          });
          el._audio = a;
        }
        const a = el._audio;
        if (a.paused) {
          a.playbackRate = adminSpeed();
          a.play().then(() => {
            btn.textContent = '⏸';
            const body = $('#cmBody');
            if (body) body.scrollTo({ top: body.scrollHeight, behavior: 'smooth' });
          }).catch(() => toast('Play nahi hui'));
        } else {
          a.pause();
          btn.textContent = '▶';
        }
      });
    });
  }

  async function openAdminChat(a, b, title) {
    $('#cmTitle').textContent = title || 'Chat';
    $('#cmSub').textContent = '';
    $('#cmBody').innerHTML = '<div class="spinner"></div>';
    $('#chatModal').classList.remove('hidden');
    try {
      const d = await api('/admin/chats/' + a + '/' + b);
      $('#cmSub').textContent = d.messages.length + ' messages · ' + (d.a.name || d.a.username) + ' ↔ ' + (d.b.name || d.b.username);
      if (!d.messages.length) {
        $('#cmBody').innerHTML = '<div class="empty">Koi message nahi.</div>';
        return;
      }
      $('#cmBody').innerHTML = d.messages.map(m => {
        const mine = m.fromId === d.a.id;
        const who = mine ? d.a.username : d.b.username;
        const isMedia = m.kind === 'image' || m.kind === 'video' || m.kind === 'audio';
        const inner = m.kind === 'image' && m.url
          ? '<a href="' + esc(m.url) + '" target="_blank" rel="noopener"><img class="chat-media" src="' + esc(m.url) + '" alt="photo" loading="lazy"></a>'
          : m.kind === 'video' && m.url
            ? '<video class="chat-media" src="' + esc(m.url) + '#t=0.1" controls preload="metadata" playsinline></video>'
            : m.kind === 'audio' && m.url
              ? '<div class="voice" data-src="' + esc(m.url) + '">' +
                  '<button type="button" class="v-play">▶</button>' +
                  '<div class="v-wave">' + (Array.isArray(m.peaks) && m.peaks.length ? m.peaks : Array.from({ length: 28 }, (_, i) => 30 + ((i * 37) % 60)))
                    .map(p => '<i style="height:' + Math.max(14, p) + '%"></i>').join('') + '</div>' +
                  '<span class="v-time">' + adminDur((m.duration || 0) / 1000) + '</span>' +
                  '<button type="button" class="v-speed">' + adminSpeedLabel() + '</button>' +
                '</div>'
              : '<div class="bubble">' + esc(m.body) + '</div>';
        return '<div class="msg ' + (mine ? 'theirs' : 'mine') + (isMedia ? ' media' : '') + '">' +
          inner +
          '<div class="msg-time">@' + esc(who) + ' · ' +
            new Date(m.createdAt).toLocaleString() +
            (m.readAt ? ' · read' : ' · unread') +
            ' <button class="mini-link" data-delmsg="' + m.id + '" style="border:0;background:none;color:#ff8098;cursor:pointer">delete</button>' +
          '</div></div>';
      }).join('');
      $('#cmBody').scrollTop = $('#cmBody').scrollHeight;
      wireAdminVoices($('#cmBody'));

      $$('[data-delmsg]').forEach(btn => btn.addEventListener('click', async () => {
        if (!confirm('Ye message delete karein?')) return;
        try {
          await api('/admin/messages/' + btn.dataset.delmsg, { method: 'DELETE' });
          toast('Message delete ho gaya');
          openAdminChat(a, b, title);
          loadStats();
        } catch (e) { toast(e.message); }
      }));
    } catch (e) {
      $('#cmBody').innerHTML = '<div class="empty">' + esc(e.message) + '</div>';
    }
  }

  $('#cmClose').addEventListener('click', () => $('#chatModal').classList.add('hidden'));

  /* ---------------- reports ---------------- */
  async function renderReports() {
    $('#content').innerHTML = '<div class="spinner"></div>';
    try {
      const data = await api('/admin/reports?status=' + encodeURIComponent(reportFilter));
      const filters =
        '<div class="filters">' +
        ['pending', 'resolved', 'dismissed'].map(s =>
          '<button class="mini-btn ' + (reportFilter === s ? 'active' : '') + '" data-f="' + s + '">' + s + '</button>').join('') +
        '</div>';

      if (!data.items.length) {
        $('#content').innerHTML = filters + '<div class="empty">Koi ' + reportFilter + ' report nahi hai.</div>';
      } else {
        $('#content').innerHTML = filters +
          '<div class="table-wrap"><table class="table">' +
          '<thead><tr><th>Video</th><th>Reported by</th><th>Reason</th><th>When</th><th></th></tr></thead><tbody>' +
          data.items.map(r =>
            '<tr>' +
              '<td class="cell-video">' +
                '<div class="thumb">🎬</div>' +
                '<div class="vtxt"><div class="cap">' + esc((r.video.caption || '').slice(0, 60) || '(no caption)') + '</div>' +
                '<a class="mini-link" href="' + esc(r.video.url) + '" target="_blank" rel="noopener">@' + esc(r.video.author.username) + ' · view ↗</a></div>' +
              '</td>' +
              '<td>@' + esc(r.reporter.username) + '<div class="sub2">' + esc(r.reporter.name || '') + '</div></td>' +
              '<td><span class="tag">' + esc(r.reason) + '</span></td>' +
              '<td class="nowrap">' + ago(r.createdAt) + '</td>' +
              '<td class="acts">' +
                (reportFilter === 'pending'
                  ? '<button class="mini-btn danger" data-rm="' + r.video.id + '">Remove video</button> ' +
                    '<button class="mini-btn" data-ok="' + r.id + '">Keep</button>'
                  : '<button class="mini-btn" data-reopen="' + r.id + '">Reopen</button>') +
              '</td>' +
            '</tr>').join('') +
          '</tbody></table></div>';
      }

      $$('[data-f]').forEach(b => b.addEventListener('click', () => { reportFilter = b.dataset.f; renderReports(); }));

      $$('[data-rm]').forEach(b => b.addEventListener('click', async () => {
        if (!confirm('Ye reported video remove karein?')) return;
        b.disabled = true;
        try {
          await api('/admin/videos/' + b.dataset.rm, { method: 'DELETE' });
          toast('Video remove ho gayi (report bhi band)');
          loadStats(); renderReports();
        } catch (e) { toast(e.message); b.disabled = false; }
      }));

      $$('[data-ok]').forEach(b => b.addEventListener('click', async () => {
        try {
          await api('/admin/reports/' + b.dataset.ok, { method: 'POST', body: { status: 'resolved' } });
          toast('Report resolved — video rakhi gayi');
          loadStats(); renderReports();
        } catch (e) { toast(e.message); }
      }));

      $$('[data-reopen]').forEach(b => b.addEventListener('click', async () => {
        try {
          await api('/admin/reports/' + b.dataset.reopen, { method: 'POST', body: { status: 'pending' } });
          toast('Report dobara pending ho gayi');
          loadStats(); renderReports();
        } catch (e) { toast(e.message); }
      }));
    } catch (e) {
      $('#content').innerHTML = '<div class="empty">' + esc(e.message) + '</div>';
    }
  }

  /* ---------------- boot ---------------- */
  async function boot() {
    await loadStats();
    $('#search').placeholder = 'Caption ya @username...';

    // URL hash se seedha tab kholein (#reports / #appeals / #chats ...)
    const valid = ['videos', 'users', 'reports', 'appeals', 'chats'];
    const hash = String(location.hash || '').replace('#', '');
    if (valid.indexOf(hash) !== -1) {
      gotoTab(hash, true);
      return;
    }
    await render();
  }

  async function init() {
    if (!token) return;                      // gate visible
    try {
      const data = await api('/me');
      if (!data.user.isAdmin) { localStorage.removeItem(TOKEN_KEY); return; }
      meUser = data.user;
      showPanel();
    } catch (e) {
      localStorage.removeItem(TOKEN_KEY);
    }
  }

  init();
})();
