'use strict';
/**
 * TokClip server — multi-user short-video app
 * Node + Express + SQLite (better-sqlite3) + local file uploads
 */

const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const os = require('os');

const express = require('express');
const multer = require('multer');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const Database = require('better-sqlite3');

/* ------------------------------------------------------------------ */
/* config                                                              */
/* ------------------------------------------------------------------ */
const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '0.0.0.0';
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');
const MAX_UPLOAD_MB = Number(process.env.MAX_UPLOAD_MB || 300);

fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const db = new Database(path.join(DATA_DIR, 'app.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id             TEXT PRIMARY KEY,
  name           TEXT NOT NULL,
  username       TEXT NOT NULL UNIQUE,
  email          TEXT NOT NULL UNIQUE,
  pass_hash      TEXT NOT NULL,
  bio            TEXT NOT NULL DEFAULT '',
  extra_followers INTEGER NOT NULL DEFAULT 0,
  is_admin       INTEGER NOT NULL DEFAULT 0,
  email_verified INTEGER NOT NULL DEFAULT 1,
  banned         INTEGER NOT NULL DEFAULT 0,
  ban_reason     TEXT NOT NULL DEFAULT '',
  banned_at      INTEGER,
  created_at     INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS videos (
  id          TEXT PRIMARY KEY,
  user_id     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  caption     TEXT NOT NULL DEFAULT '',
  filename    TEXT,
  url         TEXT,
  sound       TEXT NOT NULL DEFAULT '',
  views       INTEGER NOT NULL DEFAULT 0,
  extra_likes INTEGER NOT NULL DEFAULT 0,
  created_at  INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_videos_created ON videos(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_videos_user ON videos(user_id);

CREATE TABLE IF NOT EXISTS likes (
  video_id TEXT NOT NULL REFERENCES videos(id) ON DELETE CASCADE,
  user_id  TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  PRIMARY KEY (video_id, user_id)
);

CREATE TABLE IF NOT EXISTS follows (
  follower_id  TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  following_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  PRIMARY KEY (follower_id, following_id)
);
CREATE INDEX IF NOT EXISTS idx_follows_following ON follows(following_id);

CREATE TABLE IF NOT EXISTS comments (
  id         TEXT PRIMARY KEY,
  video_id   TEXT NOT NULL REFERENCES videos(id) ON DELETE CASCADE,
  user_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  text       TEXT NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_comments_video ON comments(video_id);

CREATE TABLE IF NOT EXISTS reports (
  id         TEXT PRIMARY KEY,
  video_id   TEXT NOT NULL REFERENCES videos(id) ON DELETE CASCADE,
  user_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  reason     TEXT NOT NULL,
  status     TEXT NOT NULL DEFAULT 'pending',
  created_at INTEGER NOT NULL,
  UNIQUE (video_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_reports_status ON reports(status, created_at DESC);

CREATE TABLE IF NOT EXISTS appeals (
  id          TEXT PRIMARY KEY,
  user_id     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  message     TEXT NOT NULL,
  status      TEXT NOT NULL DEFAULT 'pending',
  admin_note  TEXT NOT NULL DEFAULT '',
  created_at  INTEGER NOT NULL,
  reviewed_at INTEGER
);
CREATE INDEX IF NOT EXISTS idx_appeals_status ON appeals(status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_appeals_user ON appeals(user_id);

CREATE TABLE IF NOT EXISTS email_codes (
  id         TEXT PRIMARY KEY,
  email      TEXT NOT NULL,
  user_id    TEXT REFERENCES users(id) ON DELETE CASCADE,
  purpose    TEXT NOT NULL DEFAULT 'verify',
  code_hash  TEXT NOT NULL,
  tries      INTEGER NOT NULL DEFAULT 0,
  expires_at INTEGER NOT NULL,
  used       INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_email_codes_email ON email_codes(email, purpose, used);

CREATE TABLE IF NOT EXISTS messages (
  id         TEXT PRIMARY KEY,
  from_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  to_id      TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  body       TEXT NOT NULL,
  kind       TEXT NOT NULL DEFAULT 'text',
  file       TEXT,
  mime       TEXT,
  duration   INTEGER NOT NULL DEFAULT 0,
  peaks      TEXT,
  is_admin   INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL,
  read_at    INTEGER
);
CREATE INDEX IF NOT EXISTS idx_messages_pair ON messages(from_id, to_id, created_at);
CREATE INDEX IF NOT EXISTS idx_messages_to ON messages(to_id, read_at);

CREATE TABLE IF NOT EXISTS official_archives (
  user_id     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  message_id  TEXT NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
  archived_at INTEGER NOT NULL,
  PRIMARY KEY (user_id, message_id)
);

CREATE TABLE IF NOT EXISTS chat_pins (
  user_id  TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  other_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  pinned   INTEGER NOT NULL DEFAULT 1,
  PRIMARY KEY (user_id, other_id)
);

CREATE TABLE IF NOT EXISTS leaderboard_snapshots (
  scope       TEXT NOT NULL,
  metric      TEXT NOT NULL,
  entity_id   TEXT NOT NULL,
  rank        INTEGER NOT NULL,
  value       INTEGER NOT NULL,
  captured_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_lb_snap ON leaderboard_snapshots(scope, metric, captured_at);
`);

/* lightweight migrations for existing databases */
function ensureColumn(table, column, definition) {
  const cols = db.prepare('PRAGMA table_info(' + table + ')').all();
  if (!cols.some(c => c.name === column)) {
    db.exec('ALTER TABLE ' + table + ' ADD COLUMN ' + column + ' ' + definition);
    console.log('• migration: ' + table + '.' + column + ' added');
  }
}
ensureColumn('users', 'is_admin', 'INTEGER NOT NULL DEFAULT 0');
ensureColumn('users', 'banned', 'INTEGER NOT NULL DEFAULT 0');
ensureColumn('users', 'ban_reason', "TEXT NOT NULL DEFAULT ''");
ensureColumn('users', 'banned_at', 'INTEGER');
ensureColumn('users', 'email_verified', 'INTEGER NOT NULL DEFAULT 1');
ensureColumn('users', 'last_seen', 'INTEGER NOT NULL DEFAULT 0');
ensureColumn('users', 'official_notify', "TEXT NOT NULL DEFAULT 'all'");
ensureColumn('messages', 'kind', "TEXT NOT NULL DEFAULT 'text'");
ensureColumn('messages', 'file', 'TEXT');
ensureColumn('messages', 'mime', 'TEXT');
ensureColumn('messages', 'duration', 'INTEGER NOT NULL DEFAULT 0');
ensureColumn('messages', 'peaks', 'TEXT');
ensureColumn('messages', 'is_admin', 'INTEGER NOT NULL DEFAULT 0');

/* JWT secret: env var, else generated once and stored in data/ */
const SECRET_FILE = path.join(DATA_DIR, 'jwt.secret');
const SECRET = process.env.JWT_SECRET || (() => {
  if (fs.existsSync(SECRET_FILE)) return fs.readFileSync(SECRET_FILE, 'utf8').trim();
  const s = crypto.randomBytes(32).toString('hex');
  fs.writeFileSync(SECRET_FILE, s, { mode: 0o600 });
  return s;
})();

/* ------------------------------------------------------------------ */
/* email (SMTP)                                                        */
/* ------------------------------------------------------------------ */
const SMTP_HOST = process.env.SMTP_HOST || '';
const MAIL_FROM = process.env.MAIL_FROM || ('TokClip <' + (process.env.SMTP_USER || 'no-reply@tokclip.app') + '>');
let transporter = null;

if (SMTP_HOST) {
  try {
    const nodemailer = require('nodemailer');
    transporter = nodemailer.createTransport({
      host: SMTP_HOST,
      port: Number(process.env.SMTP_PORT || 587),
      secure: String(process.env.SMTP_SECURE || '').toLowerCase() === 'true' || Number(process.env.SMTP_PORT) === 465,
      auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } : undefined
    });
  } catch (e) {
    console.error('!! nodemailer load nahi hua:', e.message);
  }
}
const DEV_MAIL = !transporter;

async function sendMail(to, subject, text, html) {
  if (!transporter) {
    console.log('\n[MAIL — DEV MODE] to: ' + to + '\n  subject: ' + subject + '\n  ' + text.replace(/\n/g, '\n  ') + '\n');
    return { dev: true };
  }
  await transporter.sendMail({ from: MAIL_FROM, to, subject, text, html });
  return { dev: false };
}

/* ------------------------------------------------------------------ */
/* helpers                                                             */
/* ------------------------------------------------------------------ */
const uid = () => crypto.randomUUID();
const now = () => Date.now();

/* ---------------- presence (online / last seen) ---------------- */
const presenceMap = new Map();      // userId -> expiry
const lastSeenWrite = new Map();    // userId -> last DB write
const PRESENCE_TTL = 45000;         // 45s heartbeat window

function touchPresence(u) {
  if (!u) return;
  presenceMap.set(u.id, now() + PRESENCE_TTL);
  const last = lastSeenWrite.get(u.id) || 0;
  if (now() - last > 30000) {
    lastSeenWrite.set(u.id, now());
    try { db.prepare('UPDATE users SET last_seen = ? WHERE id = ?').run(now(), u.id); } catch (e) { /* ignore */ }
  }
}

function presenceOf(id) {
  const u = q.userById.get(id);
  return {
    online: (presenceMap.get(id) || 0) > now(),
    lastSeen: u ? (u.last_seen || 0) : 0
  };
}

const q = {
  userById:      db.prepare('SELECT * FROM users WHERE id = ?'),
  userByEmail:   db.prepare('SELECT * FROM users WHERE email = ?'),
  userByUser:    db.prepare('SELECT * FROM users WHERE username = ?'),
  insertUser:    db.prepare(`INSERT INTO users (id,name,username,email,pass_hash,bio,extra_followers,created_at)
                             VALUES (@id,@name,@username,@email,@pass_hash,@bio,0,@created_at)`),
  realFollowers: db.prepare('SELECT COUNT(*) AS c FROM follows WHERE following_id = ?'),
  realFollowing: db.prepare('SELECT COUNT(*) AS c FROM follows WHERE follower_id = ?'),
  realLikes:     db.prepare('SELECT COUNT(*) AS c FROM likes WHERE video_id = ?'),
  commentCount:  db.prepare('SELECT COUNT(*) AS c FROM comments WHERE video_id = ?'),
  isLiked:       db.prepare('SELECT 1 FROM likes WHERE video_id = ? AND user_id = ?'),
  isFollowing:   db.prepare('SELECT 1 FROM follows WHERE follower_id = ? AND following_id = ?'),
  videoById:     db.prepare(`SELECT v.*, u.username, u.name AS author_name, u.extra_followers
                             FROM videos v JOIN users u ON u.id = v.user_id WHERE v.id = ?`),
  insertVideo:   db.prepare(`INSERT INTO videos (id,user_id,caption,filename,url,sound,views,extra_likes,created_at)
                             VALUES (@id,@user_id,@caption,@filename,@url,@sound,0,0,@created_at)`),
  deleteVideo:   db.prepare('DELETE FROM videos WHERE id = ? AND user_id = ?'),
  videosByUser:  db.prepare(`SELECT v.*, u.username, u.name AS author_name, u.extra_followers
                             FROM videos v JOIN users u ON u.id = v.user_id
                             WHERE v.user_id = ? ORDER BY v.created_at DESC LIMIT 60`)
};

function publicUser(u) {
  const real = q.realFollowers.get(u.id).c;
  return {
    id: u.id,
    name: u.name,
    username: u.username,
    email: u.email,
    bio: u.bio,
    followers: real + (u.extra_followers || 0),
    realFollowers: real,
    isAdmin: !!u.is_admin,
    emailVerified: !!u.email_verified,
    officialNotify: u.official_notify || 'all',
    createdAt: u.created_at
  };
}

function serializeVideo(row, viewerId) {
  const realLikes = q.realLikes.get(row.id).c;
  return {
    id: row.id,
    caption: row.caption,
    url: row.url || '/media/' + row.filename,
    sound: row.sound || 'original sound',
    views: row.views || 0,
    likes: realLikes + (row.extra_likes || 0),
    realLikes,
    comments: q.commentCount.get(row.id).c,
    liked: viewerId ? !!q.isLiked.get(row.id, viewerId) : false,
    mine: viewerId === row.user_id,
    createdAt: row.created_at,
    author: {
      id: row.user_id,
      username: row.username,
      name: row.author_name,
      followers: q.realFollowers.get(row.user_id).c + (row.extra_followers || 0),
      isFollowing: viewerId ? !!q.isFollowing.get(viewerId, row.user_id) : false
    }
  };
}

function signToken(user) {
  return jwt.sign({ sub: user.id }, SECRET, { expiresIn: '90d' });
}

function safeName(s) {
  return String(s || '').trim().replace(/[^a-zA-Z0-9._]/g, '').toLowerCase().slice(0, 24);
}

/* ---------------- email verification codes ---------------- */
const CODE_TTL_MS = 15 * 60 * 1000;
const hashCode = (email, code) => crypto.createHash('sha256').update('tokclip|' + email + '|' + code).digest('hex');
const genCode = () => String(Math.floor(100000 + Math.random() * 900000));

function issueCode(email, userId, purpose) {
  const code = genCode();
  db.prepare('UPDATE email_codes SET used = 1 WHERE email = ? AND purpose = ? AND used = 0').run(email, purpose);
  db.prepare(`INSERT INTO email_codes (id,email,user_id,purpose,code_hash,tries,expires_at,used,created_at)
              VALUES (?,?,?,?,?,0,?,0,?)`)
    .run(uid(), email, userId || null, purpose, hashCode(email, code), now() + CODE_TTL_MS, now());
  return code;
}

function checkCode(email, purpose, code) {
  const row = db.prepare(`SELECT * FROM email_codes WHERE email = ? AND purpose = ? AND used = 0
                          ORDER BY created_at DESC LIMIT 1`).get(email, purpose);
  if (!row) return { ok: false, error: 'Koi active code nahi mila — dobara bhejein.' };
  if (row.expires_at < now()) return { ok: false, error: 'Code expire ho gaya — naya code bhejein.' };
  if (row.tries >= 6) return { ok: false, error: 'Bahut zyada galat koshish — naya code bhejein.' };
  if (row.code_hash !== hashCode(email, String(code))) {
    db.prepare('UPDATE email_codes SET tries = tries + 1 WHERE id = ?').run(row.id);
    return { ok: false, error: 'Code galat hai.' };
  }
  db.prepare('UPDATE email_codes SET used = 1 WHERE id = ?').run(row.id);
  return { ok: true, row };
}

async function sendCode(email, code, purpose) {
  const isReset = purpose === 'reset';
  const subject = isReset ? 'TokClip — password reset code' : 'TokClip — email verification code';
  const text = (isReset ? 'Aapka password reset code' : 'Aapka TokClip verification code') + ': ' + code +
    '\n\nYe code 15 minute tak valid hai. Agar aapne ye request nahi ki to ignore karein.';
  const html = '<div style="font-family:system-ui,sans-serif;padding:8px">' +
    '<h2 style="margin:0 0 8px">TokClip</h2>' +
    '<p>' + (isReset ? 'Password reset code' : 'Email verification code') + ':</p>' +
    '<p style="font-size:30px;font-weight:800;letter-spacing:8px;margin:12px 0">' + code + '</p>' +
    '<p style="color:#666;font-size:13px">15 minute tak valid. Agar aapne request nahi ki, ignore karein.</p></div>';
  return sendMail(email, subject, text, html);
}

/* ------------------------------------------------------------------ */
/* app                                                                 */
/* ------------------------------------------------------------------ */
const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '1mb' }));

/* auth middleware */
app.use((req, res, next) => {
  const h = req.headers.authorization || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : null;
  if (token) {
    try {
      const payload = jwt.verify(token, SECRET);
      const u = q.userById.get(payload.sub);
      if (u) {
        if (u.banned) req.bannedUser = u;   // banned users ko koi API access nahi
        else { req.user = u; touchPresence(u); }
      }
    } catch (e) { /* invalid token -> anonymous */ }
  }
  next();
});

/* banned account gate — har API call block (appeals exception) */
app.use('/api', (req, res, next) => {
  if (req.bannedUser && req.path !== '/appeal' && req.path !== '/appeal/status') {
    const ap = db.prepare('SELECT * FROM appeals WHERE user_id = ? ORDER BY created_at DESC LIMIT 1').get(req.bannedUser.id);
    return res.status(403).json({
      error: 'Ye account ban hai' + (req.bannedUser.ban_reason ? ': ' + req.bannedUser.ban_reason : ''),
      banned: true,
      reason: req.bannedUser.ban_reason || '',
      appeal: ap ? { status: ap.status, message: ap.message, note: ap.admin_note, createdAt: ap.created_at, reviewedAt: ap.reviewed_at } : null
    });
  }
  next();
});

const authRequired = (req, res, next) => {
  if (!req.user) return res.status(401).json({ error: 'Login required' });
  next();
};

const adminRequired = (req, res, next) => {
  if (!req.user) return res.status(401).json({ error: 'Login required' });
  if (!req.user.is_admin) return res.status(403).json({ error: 'Admin access required' });
  next();
};

/* ---------------------------- auth ---------------------------- */
app.post('/api/auth/signup', async (req, res) => {
  try {
    const name = String(req.body.name || '').trim().slice(0, 40);
    const username = safeName(req.body.username);
    const email = String(req.body.email || '').trim().toLowerCase();
    const password = String(req.body.password || '');

    if (name.length < 2) return res.status(400).json({ error: 'Naam kam az kam 2 characters ka ho.' });
    if (username.length < 3) return res.status(400).json({ error: 'Username kam az kam 3 characters (a-z, 0-9, . _).' });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) return res.status(400).json({ error: 'Valid email daalein.' });
    if (password.length < 6) return res.status(400).json({ error: 'Password kam az kam 6 characters ka ho.' });
    if (q.userByEmail.get(email)) return res.status(400).json({ error: 'Ye email pehle se registered hai.' });
    if (q.userByUser.get(username)) return res.status(400).json({ error: 'Ye username already taken hai.' });

    const user = {
      id: uid(), name, username, email,
      pass_hash: await bcrypt.hash(password, 10),
      bio: '', created_at: now()
    };
    q.insertUser.run(user);
    // naye accounts default unverified (owner wala niche exception hai)
    db.prepare('UPDATE users SET email_verified = 0 WHERE id = ?').run(user.id);

    // email verification
    if (email === String(process.env.ADMIN_EMAIL || 'badmashik742@gmail.com').toLowerCase()) {
      db.prepare('UPDATE users SET email_verified = 1, is_admin = 1 WHERE id = ?').run(user.id);
      return res.json({ token: signToken(user), user: publicUser(q.userById.get(user.id)) });
    }

    const code = issueCode(email, user.id, 'verify');
    let devCode;
    try {
      const r = await sendCode(email, code, 'verify');
      if (r && r.dev) devCode = code;
    } catch (mailErr) {
      console.error('mail error:', mailErr.message);
      return res.json({
        needsVerification: true, email,
        error: 'Account ban gaya lekin email nahi bhej paya. "Code dobara bhejein" try karein.',
        mailError: true
      });
    }
    res.json({ needsVerification: true, email, devMode: DEV_MAIL, devCode });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Server error' });
  }
});

/* email code verify → token */
app.post('/api/auth/verify', async (req, res) => {
  try {
    const email = String(req.body.email || '').trim().toLowerCase();
    const code = String(req.body.code || '').trim();
    if (!email || !/^\d{6}$/.test(code)) return res.status(400).json({ error: '6-digit code daalein.' });

    const check = checkCode(email, 'verify', code);
    if (!check.ok) return res.status(400).json({ error: check.error });

    const u = q.userByEmail.get(email);
    if (!u) return res.status(400).json({ error: 'Account nahi mila.' });
    db.prepare('UPDATE users SET email_verified = 1 WHERE id = ?').run(u.id);
    const fresh = q.userById.get(u.id);
    if (fresh.banned) return res.status(403).json({ banned: true, reason: fresh.ban_reason || '' });
    res.json({ token: signToken(fresh), user: publicUser(fresh) });
  } catch (e) { console.error(e); res.status(500).json({ error: 'Server error' }); }
});

/* code dobara bhejein */
app.post('/api/auth/resend', async (req, res) => {
  try {
    const email = String(req.body.email || '').trim().toLowerCase();
    const purpose = req.body.purpose === 'reset' ? 'reset' : 'verify';
    const u = q.userByEmail.get(email);
    if (!u) return res.status(400).json({ error: 'Is email se koi account nahi mila.' });
    if (purpose === 'verify' && u.email_verified) return res.status(400).json({ error: 'Ye email pehle se verified hai — login karein.' });

    const last = db.prepare(`SELECT created_at FROM email_codes WHERE email = ? AND purpose = ?
                             ORDER BY created_at DESC LIMIT 1`).get(email, purpose);
    if (last && now() - last.created_at < 45 * 1000) {
      return res.status(429).json({ error: 'Thodi der baad try karein (45 second).' });
    }

    const code = issueCode(email, u.id, purpose);
    const r = await sendCode(email, code, purpose);
    res.json({ ok: true, devMode: r.dev, devCode: r.dev ? code : undefined });
  } catch (e) { console.error(e); res.status(500).json({ error: 'Email bhejne mein masla hua.' }); }
});

/* password bhool gaye */
app.post('/api/auth/forgot', async (req, res) => {
  try {
    const email = String(req.body.email || '').trim().toLowerCase();
    const u = q.userByEmail.get(email);
    // security: email exist kare ya na kare, same response
    if (u) {
      const code = issueCode(email, u.id, 'reset');
      const r = await sendCode(email, code, 'reset');
      return res.json({ ok: true, devMode: r.dev, devCode: r.dev ? code : undefined });
    }
    res.json({ ok: true, devMode: DEV_MAIL });
  } catch (e) { console.error(e); res.status(500).json({ error: 'Email bhejne mein masla hua.' }); }
});

/* reset code + naya password */
app.post('/api/auth/reset', async (req, res) => {
  try {
    const email = String(req.body.email || '').trim().toLowerCase();
    const code = String(req.body.code || '').trim();
    const password = String(req.body.password || '');
    if (password.length < 6) return res.status(400).json({ error: 'Password kam az kam 6 characters ka ho.' });

    const check = checkCode(email, 'reset', code);
    if (!check.ok) return res.status(400).json({ error: check.error });

    const u = q.userByEmail.get(email);
    if (!u) return res.status(400).json({ error: 'Account nahi mila.' });
    db.prepare('UPDATE users SET pass_hash = ?, email_verified = 1 WHERE id = ?')
      .run(await bcrypt.hash(password, 10), u.id);
    const fresh = q.userById.get(u.id);
    if (fresh.banned) return res.status(403).json({ banned: true, reason: fresh.ban_reason || '' });
    res.json({ token: signToken(fresh), user: publicUser(fresh) });
  } catch (e) { console.error(e); res.status(500).json({ error: 'Server error' }); }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const email = String(req.body.email || '').trim().toLowerCase();
    const password = String(req.body.password || '');
    const u = q.userByEmail.get(email) || q.userByUser.get(safeName(email));
    if (!u) return res.status(400).json({ error: 'Is email se koi account nahi mila.' });
    if (u.banned) {
      const ap = db.prepare('SELECT * FROM appeals WHERE user_id = ? ORDER BY created_at DESC LIMIT 1').get(u.id);
      return res.status(403).json({
        error: 'Ye account ban hai' + (u.ban_reason ? '. Wajah: ' + u.ban_reason : '') + '. Admin se rabta karein.',
        banned: true,
        reason: u.ban_reason || '',
        appeal: ap ? { status: ap.status, message: ap.message, note: ap.admin_note, createdAt: ap.created_at } : null
      });
    }
    const ok = await bcrypt.compare(password, u.pass_hash);
    if (!ok) return res.status(400).json({ error: 'Password galat hai.' });
    if (!u.email_verified) {
      const code = issueCode(u.email, u.id, 'verify');
      const r = await sendCode(u.email, code, 'verify').catch(() => ({ dev: DEV_MAIL }));
      return res.status(403).json({
        error: 'Pehle apni email verify karein — humne 6-digit code bhej diya hai.',
        needsVerification: true,
        email: u.email,
        devMode: r.dev,
        devCode: r.dev ? code : undefined
      });
    }
    res.json({ token: signToken(u), user: publicUser(u) });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Server error' });
  }
});

/* ---------------------------- appeals ---------------------------- */
/* banned user apni ban ke khilaf appeal bhej sakta hai (token ya email+password se) */
const appealHits = new Map();
function tooManyAppeals(ip) {
  const nowMs = Date.now();
  const arr = (appealHits.get(ip) || []).filter(t => nowMs - t < 10 * 60 * 1000);
  arr.push(nowMs);
  appealHits.set(ip, arr);
  return arr.length > 10;
}

app.post('/api/appeal', async (req, res) => {
  try {
    const ip = req.ip || 'x';
    if (tooManyAppeals(ip)) return res.status(429).json({ error: 'Bahut zyada koshishein — thodi der baad try karein.' });

    let user = req.bannedUser || null;
    if (!user) {
      const email = String(req.body.email || '').trim().toLowerCase();
      const password = String(req.body.password || '');
      if (!email || !password) return res.status(400).json({ error: 'Email aur password chahiye.' });
      const found = q.userByEmail.get(email) || q.userByUser.get(safeName(email));
      if (!found) return res.status(400).json({ error: 'Is email se koi account nahi mila.' });
      const ok = await bcrypt.compare(password, found.pass_hash);
      if (!ok) return res.status(400).json({ error: 'Email ya password galat hai.' });
      user = found;
    }

    if (!user.banned) return res.status(400).json({ error: 'Ye account ban nahi hai — aap normal login kar sakte hain.' });

    const message = String(req.body.message || '').trim().slice(0, 600);
    if (message.length < 10) return res.status(400).json({ error: 'Appeal kam az kam 10 characters likhein.' });

    const pending = db.prepare("SELECT * FROM appeals WHERE user_id = ? AND status = 'pending'").get(user.id);
    if (pending) {
      return res.status(400).json({ error: 'Aapki appeal pehle se review ke liye pending hai.', pending: true });
    }

    const appeal = { id: uid(), user_id: user.id, message, status: 'pending', admin_note: '', created_at: now() };
    db.prepare('INSERT INTO appeals (id,user_id,message,status,admin_note,created_at) VALUES (@id,@user_id,@message,@status,@admin_note,@created_at)').run(appeal);
    res.json({ ok: true, appeal: { status: 'pending', message, createdAt: appeal.created_at } });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Server error' });
  }
});

/* banned user apni appeal ka status dekh sake */
app.post('/api/appeal/status', async (req, res) => {
  try {
    let user = req.bannedUser || null;
    if (!user) {
      const email = String(req.body.email || '').trim().toLowerCase();
      const password = String(req.body.password || '');
      const found = q.userByEmail.get(email) || q.userByUser.get(safeName(email));
      if (!found) return res.status(400).json({ error: 'Account nahi mila' });
      if (!(await bcrypt.compare(password, found.pass_hash))) return res.status(400).json({ error: 'Email ya password galat hai.' });
      user = found;
    }
    const ap = db.prepare('SELECT * FROM appeals WHERE user_id = ? ORDER BY created_at DESC LIMIT 1').get(user.id);
    res.json({
      banned: !!user.banned,
      reason: user.ban_reason || '',
      appeal: ap ? { status: ap.status, message: ap.message, note: ap.admin_note, createdAt: ap.created_at, reviewedAt: ap.reviewed_at } : null
    });
  } catch (e) { res.status(500).json({ error: 'Server error' }); }
});

/* ---------------------------- me ---------------------------- */
app.get('/api/me', authRequired, (req, res) => {
  const u = req.user;
  const vids = q.videosByUser.all(u.id);
  const totalViews = vids.reduce((s, v) => s + (v.views || 0), 0);
  const totalLikes = vids.reduce((s, v) => s + q.realLikes.get(v.id).c + (v.extra_likes || 0), 0);
  res.json({
    user: publicUser(u),
    following: q.realFollowing.get(u.id).c,
    videos: vids.length,
    totalViews,
    totalLikes
  });
});

app.patch('/api/me', authRequired, (req, res) => {
  const u = req.user;
  const name = req.body.name != null ? String(req.body.name).trim().slice(0, 40) : u.name;
  const bio = req.body.bio != null ? String(req.body.bio).trim().slice(0, 160) : u.bio;
  let username = u.username;
  if (req.body.username != null) {
    username = safeName(req.body.username);
    if (username.length < 3) return res.status(400).json({ error: 'Username kam az kam 3 characters.' });
    const other = q.userByUser.get(username);
    if (other && other.id !== u.id) return res.status(400).json({ error: 'Username already taken.' });
  }
  if (name.length < 2) return res.status(400).json({ error: 'Naam chhota hai.' });
  db.prepare('UPDATE users SET name=?, bio=?, username=? WHERE id=?').run(name, bio, username, u.id);
  res.json({ user: publicUser(q.userById.get(u.id)) });
});

/* followers sirf admin set kar sakta hai (kisi ka bhi) */
function setFollowersHandler(req, res) {
  const target = Math.max(0, Math.floor(Number(req.body.count) || 0));
  const u = req.params.id ? q.userById.get(req.params.id) : req.user;
  if (!u) return res.status(404).json({ error: 'User not found' });
  const real = q.realFollowers.get(u.id).c;
  db.prepare('UPDATE users SET extra_followers=? WHERE id=?').run(Math.max(0, target - real), u.id);
  res.json({ user: publicUser(q.userById.get(u.id)) });
}
app.post('/api/me/followers', authRequired, adminRequired, setFollowersHandler);
app.post('/api/admin/users/:id/followers', authRequired, adminRequired, setFollowersHandler);

/* official messages notification mode: all | badge | inbox */
app.post('/api/me/official-notify', authRequired, (req, res) => {
  const mode = String(req.body.mode || '');
  if (['all', 'badge', 'inbox'].indexOf(mode) === -1) {
    return res.status(400).json({ error: 'mode all / badge / inbox hona chahiye' });
  }
  db.prepare('UPDATE users SET official_notify = ? WHERE id = ?').run(mode, req.user.id);
  res.json({ ok: true, officialNotify: mode });
});

/* ---------------------------- feed ---------------------------- */
app.get('/api/feed', (req, res) => {
  const viewer = req.user ? req.user.id : null;
  const tab = req.query.tab === 'following' ? 'following' : 'foryou';
  const limit = Math.min(30, Math.max(1, Number(req.query.limit) || 8));
  const before = Number(req.query.before) || Number.MAX_SAFE_INTEGER;

  let rows;
  if (tab === 'following') {
    if (!viewer) return res.json({ items: [], hasMore: false });
    rows = db.prepare(`
      SELECT v.*, u.username, u.name AS author_name, u.extra_followers
      FROM videos v JOIN users u ON u.id = v.user_id
      WHERE v.created_at < ? AND u.banned = 0
        AND (v.user_id = ? OR v.user_id IN (SELECT following_id FROM follows WHERE follower_id = ?))
      ORDER BY v.created_at DESC LIMIT ?
    `).all(before, viewer, viewer, limit);
  } else {
    rows = db.prepare(`
      SELECT v.*, u.username, u.name AS author_name, u.extra_followers
      FROM videos v JOIN users u ON u.id = v.user_id
      WHERE v.created_at < ? AND u.banned = 0
      ORDER BY v.created_at DESC LIMIT ?
    `).all(before, limit);
  }

  res.json({
    items: rows.map(r => serializeVideo(r, viewer)),
    hasMore: rows.length === limit
  });
});

/* ---------------------------- discover / search ---------------------------- */
function topHashtags(limit, captionLike) {
  const rows = db.prepare('SELECT caption FROM videos WHERE caption LIKE ? LIMIT 1000').all(captionLike || '%#%');
  const map = new Map();
  const re = /#([\p{L}\p{N}_]{1,30})/gu;
  for (const r of rows) {
    const c = r.caption || '';
    let m;
    while ((m = re.exec(c))) {
      const tag = m[1].toLowerCase();
      map.set(tag, (map.get(tag) || 0) + 1);
    }
  }
  return Array.from(map.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, limit || 10)
    .map(([tag, count]) => ({ tag, count }));
}

function publicUserLite(u, viewerId) {
  const real = q.realFollowers.get(u.id).c;
  return {
    id: u.id,
    username: u.username,
    name: u.name,
    bio: u.bio || '',
    followers: real + (u.extra_followers || 0),
    isAdmin: !!u.is_admin,
    isFollowing: viewerId ? !!q.isFollowing.get(viewerId, u.id) : false
  };
}

app.get('/api/discover', (req, res) => {
  const viewer = req.user ? req.user.id : null;
  const trending = db.prepare(`
    SELECT v.*, u.username, u.name AS author_name, u.extra_followers
    FROM videos v JOIN users u ON u.id = v.user_id
    WHERE u.banned = 0 ORDER BY v.views DESC LIMIT 12
  `).all().map(r => serializeVideo(r, viewer));

  const creators = db.prepare(`
    SELECT u.* FROM users u WHERE u.banned = 0 AND u.is_admin = 0 AND u.id != ?
    ORDER BY (SELECT COUNT(*) FROM follows f WHERE f.following_id = u.id) + u.extra_followers DESC
    LIMIT 10
  `).all(viewer || '').map(u => publicUserLite(u, viewer));

  res.json({ trending, creators, hashtags: topHashtags(12) });
});

app.get('/api/suggested', (req, res) => {
  const viewer = req.user ? req.user.id : null;
  const rows = db.prepare(`
    SELECT u.* FROM users u
    WHERE u.banned = 0 AND u.is_admin = 0 AND (? IS NULL OR u.id != ?)
      AND (? IS NULL OR u.id NOT IN (SELECT following_id FROM follows WHERE follower_id = ?))
    ORDER BY (SELECT COUNT(*) FROM follows f WHERE f.following_id = u.id) + u.extra_followers DESC
    LIMIT 10
  `).all(viewer, viewer, viewer, viewer);
  res.json({ items: rows.map(u => publicUserLite(u, viewer)) });
});

app.get('/api/search', (req, res) => {
  const viewer = req.user ? req.user.id : null;
  const raw = String(req.query.q || '').trim();
  const qq = raw.replace(/^#/, '').replace(/^@/, '');
  if (qq.length < 1) return res.json({ users: [], videos: [], hashtags: [] });
  const like = '%' + qq + '%';

  const users = db.prepare(`
    SELECT u.* FROM users u
    WHERE u.banned = 0 AND (u.username LIKE ? OR u.name LIKE ?)
    ORDER BY (SELECT COUNT(*) FROM follows f WHERE f.following_id = u.id) + u.extra_followers DESC
    LIMIT 12
  `).all(like, like).map(u => publicUserLite(u, viewer));

  const videos = db.prepare(`
    SELECT v.*, u.username, u.name AS author_name, u.extra_followers
    FROM videos v JOIN users u ON u.id = v.user_id
    WHERE u.banned = 0 AND (v.caption LIKE ? OR u.username LIKE ?)
    ORDER BY v.views DESC LIMIT 24
  `).all(like, like).map(r => serializeVideo(r, viewer));

  res.json({ users, videos, hashtags: topHashtags(10, '%#' + qq + '%') });
});

/* ---------------------------- users ---------------------------- */
app.get('/api/users/:username', (req, res) => {
  const u = q.userByUser.get(safeName(req.params.username));
  if (!u) return res.status(404).json({ error: 'User not found' });
  const viewer = req.user ? req.user.id : null;
  const isAdminViewer = !!(req.user && req.user.is_admin);
  if (u.banned && !isAdminViewer) {
    return res.status(404).json({ error: 'Ye account band (banned) hai.' });
  }
  const rows = q.videosByUser.all(u.id);
  res.json({
    user: {
      ...publicUser(u),
      ...presenceOf(u.id),
      following: q.realFollowing.get(u.id).c,
      isFollowing: viewer ? !!q.isFollowing.get(viewer, u.id) : false,
      isMe: viewer === u.id
    },
    videos: rows.map(r => serializeVideo(r, viewer))
  });
});

app.post('/api/users/:id/follow', authRequired, (req, res) => {
  const targetId = req.params.id;
  if (targetId === req.user.id) return res.status(400).json({ error: 'Apne aap ko follow nahi kar sakte' });
  const target = q.userById.get(targetId);
  if (!target) return res.status(404).json({ error: 'User not found' });

  const existing = q.isFollowing.get(req.user.id, targetId);
  if (existing) db.prepare('DELETE FROM follows WHERE follower_id=? AND following_id=?').run(req.user.id, targetId);
  else db.prepare('INSERT INTO follows (follower_id, following_id) VALUES (?,?)').run(req.user.id, targetId);

  res.json({
    following: !existing,
    followers: q.realFollowers.get(targetId).c + (target.extra_followers || 0)
  });
});

/* ---------------------------- videos ---------------------------- */
const upload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => cb(null, UPLOAD_DIR),
    filename: (req, file, cb) => {
      const ext = (path.extname(file.originalname || '') || '.mp4').toLowerCase().slice(0, 6);
      cb(null, uid() + ext);
    }
  }),
  limits: { fileSize: MAX_UPLOAD_MB * 1024 * 1024, files: 1 },
  fileFilter: (req, file, cb) => {
    const ext = String(path.extname(file.originalname || '')).toLowerCase();
    const okMime = /^video\//.test(file.mimetype || '');
    const okExt = ['.mp4', '.m4v', '.webm', '.mov', '.ogv', '.ogg', '.avi', '.mkv', '.3gp'].indexOf(ext) !== -1;
    if (!okMime && !okExt) return cb(new Error('Sirf video file allowed hai'));
    cb(null, true);
  }
});

app.post('/api/videos', authRequired, (req, res, next) => {
  upload.single('video')(req, res, err => {
    if (err) {
      const msg = err.code === 'LIMIT_FILE_SIZE'
        ? `Video ${MAX_UPLOAD_MB}MB se choti honi chahiye.`
        : err.message || 'Upload failed';
      return res.status(400).json({ error: msg });
    }
    try {
      const caption = String((req.body && req.body.caption) || '').trim().slice(0, 300);
      let filename = null;
      let url = null;

      if (req.file) {
        filename = req.file.filename;
      } else if (req.body && /^https?:\/\//i.test(String(req.body.url || ''))) {
        url = String(req.body.url);
      } else {
        return res.status(400).json({ error: 'Video file ya video URL chahiye.' });
      }

      const video = {
        id: uid(),
        user_id: req.user.id,
        caption: caption || 'My new video',
        filename,
        url,
        sound: 'original sound — ' + req.user.username,
        created_at: now()
      };
      q.insertVideo.run(video);
      res.json({ video: serializeVideo(q.videoById.get(video.id), req.user.id) });
    } catch (e) {
      console.error(e);
      res.status(500).json({ error: 'Server error' });
    }
  });
});

app.delete('/api/videos/:id', authRequired, (req, res) => {
  const row = q.videoById.get(req.params.id);
  if (!row) return res.status(404).json({ error: 'Video not found' });
  if (row.user_id !== req.user.id) return res.status(403).json({ error: 'Not your video' });
  const info = q.deleteVideo.run(req.params.id, req.user.id);
  if (info.changes && row.filename) {
    fs.promises.unlink(path.join(UPLOAD_DIR, row.filename)).catch(() => {});
  }
  res.json({ ok: true });
});

/* like toggle */
app.post('/api/videos/:id/like', authRequired, (req, res) => {
  const row = q.videoById.get(req.params.id);
  if (!row) return res.status(404).json({ error: 'Video not found' });
  const existing = q.isLiked.get(row.id, req.user.id);
  if (existing) db.prepare('DELETE FROM likes WHERE video_id=? AND user_id=?').run(row.id, req.user.id);
  else db.prepare('INSERT INTO likes (video_id, user_id) VALUES (?,?)').run(row.id, req.user.id);
  res.json({
    liked: !existing,
    likes: q.realLikes.get(row.id).c + (row.extra_likes || 0)
  });
});

/* view counter (increment on each view signal from the client) */
app.post('/api/videos/:id/view', (req, res) => {
  const row = q.videoById.get(req.params.id);
  if (!row) return res.status(404).json({ error: 'Video not found' });
  db.prepare('UPDATE videos SET views = views + 1 WHERE id = ?').run(row.id);
  res.json({ views: (row.views || 0) + 1 });
});

/* views / likes sirf admin (owner) badha sakta hai */
function boostVideoHandler(req, res) {
  const row = q.videoById.get(req.params.id);
  if (!row) return res.status(404).json({ error: 'Video not found' });

  if (req.body.views != null) {
    const v = Math.max(0, Math.floor(Number(req.body.views) || 0));
    db.prepare('UPDATE videos SET views=? WHERE id=?').run(v, row.id);
  }
  if (req.body.likes != null) {
    const target = Math.max(0, Math.floor(Number(req.body.likes) || 0));
    const real = q.realLikes.get(row.id).c;
    db.prepare('UPDATE videos SET extra_likes=? WHERE id=?').run(Math.max(0, target - real), row.id);
  }
  res.json({ video: serializeVideo(q.videoById.get(row.id), req.user.id) });
}
app.post('/api/videos/:id/boost', authRequired, adminRequired, boostVideoHandler);
app.post('/api/admin/videos/:id/boost', authRequired, adminRequired, boostVideoHandler);

/* ---------------------------- comments ---------------------------- */
app.get('/api/videos/:id/comments', (req, res) => {
  const rows = db.prepare(`
    SELECT c.*, u.username, u.name FROM comments c JOIN users u ON u.id = c.user_id
    WHERE c.video_id = ? ORDER BY c.created_at DESC LIMIT 200
  `).all(req.params.id);
  res.json({
    items: rows.map(r => ({
      id: r.id, text: r.text, createdAt: r.created_at,
      author: { id: r.user_id, username: r.username, name: r.name }
    }))
  });
});

app.post('/api/videos/:id/comments', authRequired, (req, res) => {
  const row = q.videoById.get(req.params.id);
  if (!row) return res.status(404).json({ error: 'Video not found' });
  const text = String(req.body.text || '').trim().slice(0, 240);
  if (!text) return res.status(400).json({ error: 'Comment khali hai' });
  const c = { id: uid(), video_id: row.id, user_id: req.user.id, text, created_at: now() };
  db.prepare('INSERT INTO comments (id,video_id,user_id,text,created_at) VALUES (@id,@video_id,@user_id,@text,@created_at)').run(c);
  res.json({
    comment: { id: c.id, text, createdAt: c.created_at, author: { id: req.user.id, username: req.user.username, name: req.user.name } },
    count: q.commentCount.get(row.id).c
  });
});

/* ---------------------------- reports ---------------------------- */
app.post('/api/videos/:id/report', authRequired, (req, res) => {
  const row = q.videoById.get(req.params.id);
  if (!row) return res.status(404).json({ error: 'Video not found' });
  if (row.user_id === req.user.id) return res.status(400).json({ error: 'Apni video report nahi kar sakte' });
  const reason = String(req.body.reason || 'Other').trim().slice(0, 120) || 'Other';
  try {
    db.prepare('INSERT INTO reports (id,video_id,user_id,reason,status,created_at) VALUES (?,?,?,?,?,?)')
      .run(uid(), row.id, req.user.id, reason, 'pending', now());
  } catch (e) {
    if (String(e.message).includes('UNIQUE')) return res.status(400).json({ error: 'Aap ye video pehle report kar chuke hain' });
    throw e;
  }
  res.json({ ok: true });
});

/* ---------------------------- admin ---------------------------- */
function dirSize(dir) {
  let total = 0;
  try {
    for (const f of fs.readdirSync(dir)) {
      try { total += fs.statSync(path.join(dir, f)).size; } catch (e) { /* skip */ }
    }
  } catch (e) { /* skip */ }
  return total;
}

function removeVideo(id) {
  const row = q.videoById.get(id);
  if (!row) return false;
  db.prepare('DELETE FROM videos WHERE id = ?').run(id);
  if (row.filename) fs.promises.unlink(path.join(UPLOAD_DIR, row.filename)).catch(() => {});
  return true;
}

app.get('/api/admin/stats', authRequired, adminRequired, (req, res) => {
  const one = (sql, ...a) => { const r = db.prepare(sql).get(...a); return r ? Object.values(r)[0] || 0 : 0; };
  const since = now() - 24 * 3600 * 1000;
  res.json({
    users: one('SELECT COUNT(*) FROM users'),
    admins: one('SELECT COUNT(*) FROM users WHERE is_admin = 1'),
    videos: one('SELECT COUNT(*) FROM videos'),
    views: one('SELECT COALESCE(SUM(views),0) FROM videos'),
    likes: one('SELECT COUNT(*) FROM likes') + one('SELECT COALESCE(SUM(extra_likes),0) FROM videos'),
    comments: one('SELECT COUNT(*) FROM comments'),
    follows: one('SELECT COUNT(*) FROM follows'),
    reportsPending: one("SELECT COUNT(*) FROM reports WHERE status = 'pending'"),
    reportsTotal: one('SELECT COUNT(*) FROM reports'),
    appealsPending: one("SELECT COUNT(*) FROM appeals WHERE status = 'pending'"),
    appealsTotal: one('SELECT COUNT(*) FROM appeals'),
    verified: one('SELECT COUNT(*) FROM users WHERE email_verified = 1'),
    unverified: one('SELECT COUNT(*) FROM users WHERE email_verified = 0'),
    messages: one('SELECT COUNT(*) FROM messages'),
    banned: one('SELECT COUNT(*) FROM users WHERE banned = 1'),
    newUsers24h: one('SELECT COUNT(*) FROM users WHERE created_at > ?', since),
    newVideos24h: one('SELECT COUNT(*) FROM videos WHERE created_at > ?', since),
    storageBytes: dirSize(UPLOAD_DIR),
    dbBytes: (() => { try { return fs.statSync(path.join(DATA_DIR, 'app.db')).size; } catch (e) { return 0; } })()
  });
});

/* ---------------- leaderboard snapshots (rank change vs 24h) ---------------- */
const LB_SNAP_INTERVAL = 3600000;   // har ghante ek snapshot
const LB_SNAP_KEEP = 8 * 86400000;  // 8 din rakhein

function snapshotLeaderboard(lists) {
  const lastAt = db.prepare('SELECT MAX(captured_at) AS t FROM leaderboard_snapshots').get().t || 0;
  if (now() - lastAt < LB_SNAP_INTERVAL) return;

  const t = now();
  const ins = db.prepare(`INSERT INTO leaderboard_snapshots (scope,metric,entity_id,rank,value,captured_at)
                          VALUES (?,?,?,?,?,?)`);
  const write = (scope, metric, arr) => {
    arr.slice(0, 20).forEach((e, i) => {
      ins.run(scope, metric, e.id, i + 1, metric === 'likes' ? (e.likes || 0) : (e.views || 0), t);
    });
  };

  const tx = db.transaction(() => {
    write('creator', 'views', lists.creators.byViews);
    write('creator', 'likes', lists.creators.byLikes);
    write('video', 'views', lists.videos.byViews);
    write('video', 'likes', lists.videos.byLikes);
    db.prepare('DELETE FROM leaderboard_snapshots WHERE captured_at < ?').run(t - LB_SNAP_KEEP);
  });
  tx();
}

function previousRanks(scope, metric) {
  const cutoff = now() - 24 * 3600000;
  let t = db.prepare(`SELECT MAX(captured_at) AS t FROM leaderboard_snapshots
                      WHERE scope = ? AND metric = ? AND captured_at <= ?`).get(scope, metric, cutoff).t || 0;
  if (!t) {
    const oldest = db.prepare(`SELECT MIN(captured_at) AS t FROM leaderboard_snapshots
                               WHERE scope = ? AND metric = ?`).get(scope, metric).t || 0;
    // agar sirf abhi-ka snapshot hai (koi history nahi) to compare mat karo → NEW
    if (!oldest || now() - oldest < 3600000) return { map: new Map(), at: 0 };
    t = oldest;
  }
  if (!t) return { map: new Map(), at: 0 };
  const rows = db.prepare(`SELECT entity_id, rank FROM leaderboard_snapshots
                           WHERE scope = ? AND metric = ? AND captured_at = ?`).all(scope, metric, t);
  return { map: new Map(rows.map(r => [r.entity_id, r.rank])), at: t };
}

function annotateRanks(arr, scope, metric) {
  const prev = previousRanks(scope, metric);
  const items = arr.map((e, i) => {
    const rank = i + 1;
    const p = prev.map.get(e.id);
    return Object.assign({}, e, {
      rank,
      prevRank: p || null,
      rankChange: p ? (p - rank) : null     // + = upar gaya, - = neeche gira
    });
  });
  return { items, basisAt: prev.at };
}

/* dashboard summary + alerts + recent activity (30s auto-refresh ke liye) */
app.get('/api/admin/overview', authRequired, adminRequired, (req, res) => {
  const one = (sql, ...a) => { const r = db.prepare(sql).get(...a); return r ? Object.values(r)[0] || 0 : 0; };
  const since = now() - 24 * 3600 * 1000;

  const stats = {
    users: one('SELECT COUNT(*) FROM users'),
    admins: one('SELECT COUNT(*) FROM users WHERE is_admin = 1'),
    videos: one('SELECT COUNT(*) FROM videos'),
    views: one('SELECT COALESCE(SUM(views),0) FROM videos'),
    likes: one('SELECT COUNT(*) FROM likes') + one('SELECT COALESCE(SUM(extra_likes),0) FROM videos'),
    comments: one('SELECT COUNT(*) FROM comments'),
    messages: one('SELECT COUNT(*) FROM messages'),
    chatUnread: one('SELECT COUNT(*) FROM messages WHERE read_at IS NULL'),
    follows: one('SELECT COUNT(*) FROM follows'),
    reportsPending: one("SELECT COUNT(*) FROM reports WHERE status = 'pending'"),
    reportsTotal: one('SELECT COUNT(*) FROM reports'),
    appealsPending: one("SELECT COUNT(*) FROM appeals WHERE status = 'pending'"),
    appealsTotal: one('SELECT COUNT(*) FROM appeals'),
    banned: one('SELECT COUNT(*) FROM users WHERE banned = 1'),
    verified: one('SELECT COUNT(*) FROM users WHERE email_verified = 1'),
    unverified: one('SELECT COUNT(*) FROM users WHERE email_verified = 0'),
    newUsers24h: one('SELECT COUNT(*) FROM users WHERE created_at > ?', since),
    newVideos24h: one('SELECT COUNT(*) FROM videos WHERE created_at > ?', since),
    newReports24h: one('SELECT COUNT(*) FROM reports WHERE created_at > ?', since),
    newMessages24h: one('SELECT COUNT(*) FROM messages WHERE created_at > ?', since),
    storageBytes: dirSize(UPLOAD_DIR),
    dbBytes: (() => { try { return fs.statSync(path.join(DATA_DIR, 'app.db')).size; } catch (e) { return 0; } })()
  };

  const activity = [];

  db.prepare(`SELECT r.reason, r.created_at, v.caption, u.username
              FROM reports r JOIN videos v ON v.id = r.video_id JOIN users u ON u.id = v.user_id
              WHERE r.status = 'pending' ORDER BY r.created_at DESC LIMIT 4`).all()
    .forEach(r => activity.push({
      type: 'report', at: r.created_at,
      text: '@' + r.username + ' ki video report hui',
      sub: r.reason || 'Other'
    }));

  db.prepare(`SELECT a.created_at, a.message, u.username
              FROM appeals a JOIN users u ON u.id = a.user_id
              WHERE a.status = 'pending' ORDER BY a.created_at DESC LIMIT 4`).all()
    .forEach(a => activity.push({
      type: 'appeal', at: a.created_at,
      text: '@' + a.username + ' ne ban appeal bheji',
      sub: (a.message || '').slice(0, 60)
    }));

  db.prepare(`SELECT username, ban_reason, banned_at FROM users
              WHERE banned = 1 AND banned_at IS NOT NULL ORDER BY banned_at DESC LIMIT 3`).all()
    .forEach(b => activity.push({
      type: 'ban', at: b.banned_at,
      text: '@' + b.username + ' ban hua',
      sub: b.ban_reason || ''
    }));

  db.prepare(`SELECT m.created_at, m.kind, a.username AS from_u, b.username AS to_u
              FROM messages m JOIN users a ON a.id = m.from_id JOIN users b ON b.id = m.to_id
              ORDER BY m.created_at DESC LIMIT 4`).all()
    .forEach(m => activity.push({
      type: 'message', at: m.created_at,
      text: '@' + m.from_u + ' → @' + m.to_u,
      sub: m.kind === 'image' ? '📷 Photo' : m.kind === 'video' ? '🎬 Video' : m.kind === 'audio' ? '🎤 Voice note' : 'Text message'
    }));

  db.prepare(`SELECT name, username, created_at FROM users ORDER BY created_at DESC LIMIT 3`).all()
    .forEach(u => activity.push({
      type: 'user', at: u.created_at,
      text: 'Naya user: @' + u.username,
      sub: u.name || ''
    }));

  activity.sort((a, b) => b.at - a.at);

  /* ---------- trend chart: 24h / 7d / 30d ---------- */
  const HOUR = 3600000;
  const DAY = 86400000;
  const range = ['24h', '7d', '30d'].indexOf(String(req.query.range)) !== -1 ? String(req.query.range) : '24h';

  let bucketCount, stepMs, startTs, endTs, unit;
  if (range === '24h') {
    unit = 'hour';
    bucketCount = 24;
    stepMs = HOUR;
    endTs = Math.floor(now() / HOUR) * HOUR + HOUR;   // current hour ka end
    startTs = endTs - 24 * HOUR;
  } else {
    unit = 'day';
    bucketCount = range === '7d' ? 7 : 30;
    stepMs = DAY;
    const midnight = new Date();
    midnight.setHours(0, 0, 0, 0);
    const todayStart = midnight.getTime();
    endTs = todayStart + DAY;                          // kal raat 00:00
    startTs = endTs - bucketCount * DAY;
  }

  const bucketOf = ts => Math.max(0, Math.min(bucketCount - 1, Math.floor((ts - startTs) / stepMs)));
  const empty = () => new Array(bucketCount).fill(0);

  const series = { users: empty(), videos: empty(), reports: empty(), messages: empty() };

  const fill = (sql, key) => {
    db.prepare(sql).all(startTs, endTs).forEach(r => { series[key][bucketOf(r.created_at)] += 1; });
  };
  fill('SELECT created_at FROM users WHERE created_at >= ? AND created_at < ?', 'users');
  fill('SELECT created_at FROM videos WHERE created_at >= ? AND created_at < ?', 'videos');
  fill('SELECT created_at FROM reports WHERE created_at >= ? AND created_at < ?', 'reports');
  fill('SELECT created_at FROM messages WHERE created_at >= ? AND created_at < ?', 'messages');

  const WD = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const labels = [];
  for (let i = 0; i < bucketCount; i++) {
    const d = new Date(startTs + i * stepMs);
    if (unit === 'hour') {
      labels.push(String(d.getHours()).padStart(2, '0') + ':00');
    } else if (range === '7d') {
      labels.push(WD[d.getDay()] + ' ' + d.getDate());
    } else {
      labels.push(String(d.getDate()).padStart(2, '0') + '/' + String(d.getMonth() + 1).padStart(2, '0'));
    }
  }

  const chart = {
    range,
    unit,
    start: startTs,
    end: endTs,
    labels,
    series,
    totals: {
      users: series.users.reduce((a, b) => a + b, 0),
      videos: series.videos.reduce((a, b) => a + b, 0),
      reports: series.reports.reduce((a, b) => a + b, 0),
      messages: series.messages.reduce((a, b) => a + b, 0)
    }
  };

  /* ---------- leaderboards (top creators + top videos) ---------- */
  const allVids = db.prepare(`
    SELECT v.id, v.user_id, v.caption, v.url, v.filename, v.views, v.extra_likes, v.created_at,
           u.username, u.name AS author_name,
           (SELECT COUNT(*) FROM likes l WHERE l.video_id = v.id) AS real_likes
    FROM videos v JOIN users u ON u.id = v.user_id
    WHERE u.banned = 0
  `).all();

  const videoRows = allVids.map(v => ({
    id: v.id,
    caption: v.caption || '',
    url: v.url || ('/media/' + v.filename),
    views: v.views || 0,
    likes: (v.real_likes || 0) + (v.extra_likes || 0),
    createdAt: v.created_at,
    author: { id: v.user_id, username: v.username, name: v.author_name }
  }));

  const creatorMap = new Map();
  videoRows.forEach(v => {
    const c = creatorMap.get(v.author.id) || {
      id: v.author.id, username: v.author.username, name: v.author.name,
      videos: 0, views: 0, likes: 0
    };
    c.videos += 1;
    c.views += v.views;
    c.likes += v.likes;
    creatorMap.set(v.author.id, c);
  });

  const creators = Array.from(creatorMap.values()).map(c => {
    const real = q.realFollowers.get(c.id).c;
    const u = q.userById.get(c.id);
    return Object.assign(c, { followers: real + ((u && u.extra_followers) || 0) });
  });

  const rank = (arr, key) => arr.slice()
    .sort((a, b) => (b[key] - a[key]) || (b.views - a.views))
    .slice(0, 8);

  const rawLb = {
    creators: { byViews: rank(creators, 'views'), byLikes: rank(creators, 'likes') },
    videos: { byViews: rank(videoRows, 'views'), byLikes: rank(videoRows, 'likes') }
  };

  // snapshot (max once per hour) — rank change vs pichhle 24h ke liye
  try { snapshotLeaderboard(rawLb); } catch (e) { /* snapshot fail ho to bhi dashboard chale */ }

  const cV = annotateRanks(rawLb.creators.byViews, 'creator', 'views');
  const cL = annotateRanks(rawLb.creators.byLikes, 'creator', 'likes');
  const vV = annotateRanks(rawLb.videos.byViews, 'video', 'views');
  const vL = annotateRanks(rawLb.videos.byLikes, 'video', 'likes');

  const leaderboard = {
    basisAt: cV.basisAt || vV.basisAt || 0,
    creators: { byViews: cV.items, byLikes: cL.items },
    videos: { byViews: vV.items, byLikes: vL.items }
  };

  res.json({
    stats,
    chart,
    leaderboard,
    activity: activity.slice(0, 8),
    alerts: {
      reports: stats.reportsPending,
      appeals: stats.appealsPending,
      banned: stats.banned,
      chatUnread: stats.chatUnread,
      unverified: stats.unverified
    },
    syncedAt: now()
  });
});

app.get('/api/admin/users', authRequired, adminRequired, (req, res) => {
  const qq = String(req.query.q || '').trim();
  const limit = Math.min(100, Math.max(1, Number(req.query.limit) || 50));
  const offset = Math.max(0, Number(req.query.offset) || 0);
  const like = '%' + qq + '%';
  const rows = db.prepare(`
    SELECT u.*,
      (SELECT COUNT(*) FROM videos v WHERE v.user_id = u.id) AS video_count,
      (SELECT COALESCE(SUM(v.views),0) FROM videos v WHERE v.user_id = u.id) AS view_count,
      (SELECT COUNT(*) FROM follows f WHERE f.following_id = u.id) AS real_followers
    FROM users u
    WHERE (? = '' OR u.username LIKE ? OR u.email LIKE ? OR u.name LIKE ?)
    ORDER BY u.created_at DESC LIMIT ? OFFSET ?
  `).all(qq, like, like, like, limit, offset);
  res.json({
    items: rows.map(u => ({
      id: u.id, name: u.name, username: u.username, email: u.email, bio: u.bio,
      isAdmin: !!u.is_admin,
      videos: u.video_count,
      views: u.view_count,
      followers: u.real_followers + (u.extra_followers || 0),
      banned: !!u.banned,
      banReason: u.ban_reason || '',
      bannedAt: u.banned_at || null,
      createdAt: u.created_at
    }))
  });
});

/* admin: kisi bhi creator ka poora profile + uski videos */
app.get('/api/admin/users/:id/profile', authRequired, adminRequired, (req, res) => {
  const u = q.userById.get(req.params.id);
  if (!u) return res.status(404).json({ error: 'User not found' });

  const rows = db.prepare(`SELECT v.* FROM videos v WHERE v.user_id = ? ORDER BY v.created_at DESC LIMIT 30`).all(u.id);
  const videos = rows.map(v => ({
    id: v.id,
    caption: v.caption || '',
    url: v.url || ('/media/' + v.filename),
    views: v.views || 0,
    likes: q.realLikes.get(v.id).c + (v.extra_likes || 0),
    comments: q.commentCount.get(v.id).c,
    createdAt: v.created_at
  }));

  const totals = videos.reduce((a, v) => {
    a.views += v.views; a.likes += v.likes; a.comments += v.comments;
    return a;
  }, { views: 0, likes: 0, comments: 0 });

  /* is creator ki DM conversations */
  const chatRows = db.prepare(`
    SELECT CASE WHEN from_id = ? THEN to_id ELSE from_id END AS other_id,
           COUNT(*) AS total, MAX(created_at) AS last_at,
           SUM(CASE WHEN read_at IS NULL THEN 1 ELSE 0 END) AS unread
    FROM messages WHERE from_id = ? OR to_id = ?
    GROUP BY other_id ORDER BY last_at DESC LIMIT 20
  `).all(u.id, u.id, u.id);

  const chats = chatRows.map(r => {
    const o = q.userById.get(r.other_id);
    const last = db.prepare(`SELECT body, kind, from_id, created_at FROM messages
      WHERE (from_id = ? AND to_id = ?) OR (from_id = ? AND to_id = ?)
      ORDER BY created_at DESC LIMIT 1`).get(u.id, r.other_id, r.other_id, u.id);
    return {
      other: o ? { id: o.id, username: o.username, name: o.name } : { id: r.other_id, username: 'deleted', name: '' },
      total: r.total,
      unread: r.unread || 0,
      lastAt: r.last_at,
      last: last ? { body: last.body, kind: last.kind || 'text', fromId: last.from_id, createdAt: last.created_at } : null
    };
  });

  /* admin ke bheje hue private messages (is_admin = 1) */
  const adminNotes = db.prepare(`
    SELECT m.id, m.body, m.kind, m.created_at, m.read_at, a.username AS from_username
    FROM messages m JOIN users a ON a.id = m.from_id
    WHERE m.to_id = ? AND m.is_admin = 1
    ORDER BY m.created_at DESC LIMIT 20
  `).all(u.id).map(m => ({
    id: m.id,
    body: m.body,
    kind: m.kind || 'text',
    createdAt: m.created_at,
    readAt: m.read_at,
    from: m.from_username
  }));

  res.json({
    user: Object.assign(publicUser(u), presenceOf(u.id), {
      isAdmin: !!u.is_admin,
      banned: !!u.banned,
      banReason: u.ban_reason || '',
      bannedAt: u.banned_at || null,
      verified: !!u.email_verified,
      createdAt: u.created_at
    }),
    following: q.realFollowing.get(u.id).c,
    stats: { videos: videos.length, views: totals.views, likes: totals.likes, comments: totals.comments },
    videos,
    chats,
    adminNotes
  });
});

/* admin → creator private message */
app.post('/api/admin/users/:id/reply', authRequired, adminRequired, (req, res) => {
  const target = q.userById.get(req.params.id);
  if (!target) return res.status(404).json({ error: 'User not found' });
  if (target.id === req.user.id) return res.status(400).json({ error: 'Apne aap ko admin message nahi bhej sakte.' });

  const body = String(req.body.body || '').trim().slice(0, 800);
  if (!body) return res.status(400).json({ error: 'Message khali hai.' });

  const m = {
    id: uid(), from_id: req.user.id, to_id: target.id, body,
    kind: 'text', file: null, mime: null, duration: 0, peaks: null,
    is_admin: 1, created_at: now(), read_at: null
  };
  db.prepare(`INSERT INTO messages (id,from_id,to_id,body,kind,file,mime,duration,peaks,is_admin,created_at,read_at)
              VALUES (@id,@from_id,@to_id,@body,@kind,@file,@mime,@duration,@peaks,@is_admin,@created_at,@read_at)`).run(m);

  res.json({
    message: {
      id: m.id, body, kind: 'text', fromAdmin: true,
      fromId: req.user.id, toId: target.id,
      createdAt: m.created_at, readAt: null
    }
  });
});

app.delete('/api/admin/users/:id', authRequired, adminRequired, (req, res) => {
  const u = q.userById.get(req.params.id);
  if (!u) return res.status(404).json({ error: 'User not found' });
  if (u.id === req.user.id) return res.status(400).json({ error: 'Apna hi admin account delete nahi kar sakte' });
  const vids = db.prepare('SELECT filename FROM videos WHERE user_id = ?').all(u.id);
  db.prepare('DELETE FROM users WHERE id = ?').run(u.id);
  vids.forEach(v => { if (v.filename) fs.promises.unlink(path.join(UPLOAD_DIR, v.filename)).catch(() => {}); });
  res.json({ ok: true });
});

app.post('/api/admin/users/:id/admin', authRequired, adminRequired, (req, res) => {
  const u = q.userById.get(req.params.id);
  if (!u) return res.status(404).json({ error: 'User not found' });
  if (u.id === req.user.id) return res.status(400).json({ error: 'Apna admin status change nahi kar sakte' });
  const make = req.body.isAdmin ? 1 : 0;
  db.prepare('UPDATE users SET is_admin = ? WHERE id = ?').run(make, u.id);
  res.json({ ok: true, isAdmin: !!make });
});

/* ban / unban */
app.post('/api/admin/users/:id/ban', authRequired, adminRequired, (req, res) => {
  const u = q.userById.get(req.params.id);
  if (!u) return res.status(404).json({ error: 'User not found' });
  if (u.id === req.user.id) return res.status(400).json({ error: 'Apne aap ko ban nahi kar sakte' });
  const banned = req.body.banned ? 1 : 0;
  const reason = banned ? String(req.body.reason || '').trim().slice(0, 160) : '';
  db.prepare('UPDATE users SET banned = ?, ban_reason = ?, banned_at = ? WHERE id = ?')
    .run(banned, reason, banned ? now() : null, u.id);
  res.json({ ok: true, banned: !!banned, reason });
});

/* ---------------- admin: appeals ---------------- */
app.get('/api/admin/appeals', authRequired, adminRequired, (req, res) => {
  const status = ['pending', 'approved', 'rejected'].includes(String(req.query.status)) ? String(req.query.status) : 'pending';
  const rows = db.prepare(`
    SELECT a.*, u.username, u.name AS user_name, u.email, u.banned, u.ban_reason, u.banned_at
    FROM appeals a JOIN users u ON u.id = a.user_id
    WHERE a.status = ? ORDER BY a.created_at DESC LIMIT 200
  `).all(status);
  res.json({
    items: rows.map(a => ({
      id: a.id,
      message: a.message,
      status: a.status,
      adminNote: a.admin_note,
      createdAt: a.created_at,
      reviewedAt: a.reviewed_at,
      banReason: a.ban_reason || '',
      stillBanned: !!a.banned,
      user: { id: a.user_id, username: a.username, name: a.user_name, email: a.email }
    }))
  });
});

app.post('/api/admin/appeals/:id', authRequired, adminRequired, (req, res) => {
  const status = String(req.body.status || '');
  if (!['approved', 'rejected'].includes(status)) return res.status(400).json({ error: 'status approved ya rejected hona chahiye' });
  const ap = db.prepare('SELECT * FROM appeals WHERE id = ?').get(req.params.id);
  if (!ap) return res.status(404).json({ error: 'Appeal not found' });
  const note = String(req.body.note || '').trim().slice(0, 200);

  db.prepare('UPDATE appeals SET status = ?, admin_note = ?, reviewed_at = ? WHERE id = ?')
    .run(status, note, now(), ap.id);

  if (status === 'approved') {
    // appeal approve = user ka ban khud hat jata hai
    db.prepare("UPDATE users SET banned = 0, ban_reason = '', banned_at = NULL WHERE id = ?").run(ap.user_id);
  }

  res.json({ ok: true, status, unbanned: status === 'approved' });
});

/* ---------------- admin: chats ---------------- */
app.get('/api/admin/chats', authRequired, adminRequired, (req, res) => {
  const qq = String(req.query.q || '').trim();
  const like = '%' + qq + '%';
  const rows = db.prepare(`
    SELECT MIN(from_id, to_id) AS a, MAX(from_id, to_id) AS b,
           COUNT(*) AS total, MAX(created_at) AS last_at,
           SUM(CASE WHEN read_at IS NULL THEN 1 ELSE 0 END) AS unread
    FROM messages
    GROUP BY a, b
    HAVING (? = '' OR a IN (SELECT id FROM users WHERE username LIKE ? OR name LIKE ?)
            OR b IN (SELECT id FROM users WHERE username LIKE ? OR name LIKE ?))
    ORDER BY last_at DESC LIMIT 100
  `).all(qq, like, like, like, like);

  const items = rows.map(r => {
    const ua = q.userById.get(r.a);
    const ub = q.userById.get(r.b);
    const last = db.prepare('SELECT body, kind, from_id, created_at FROM messages WHERE (from_id=? AND to_id=?) OR (from_id=? AND to_id=?) ORDER BY created_at DESC LIMIT 1')
      .get(r.a, r.b, r.b, r.a);
    return {
      a: ua ? { id: ua.id, username: ua.username, name: ua.name } : { id: r.a, username: 'deleted', name: '' },
      b: ub ? { id: ub.id, username: ub.username, name: ub.name } : { id: r.b, username: 'deleted', name: '' },
      total: r.total,
      unread: r.unread,
      lastAt: r.last_at,
      last: last ? { body: last.body, kind: last.kind || 'text', fromId: last.from_id, createdAt: last.created_at } : null
    };
  });
  res.json({ items });
});

app.get('/api/admin/chats/:a/:b', authRequired, adminRequired, (req, res) => {
  const a = req.params.a;
  const b = req.params.b;
  const rows = db.prepare(`
    SELECT * FROM messages WHERE (from_id=? AND to_id=?) OR (from_id=? AND to_id=?)
    ORDER BY created_at ASC LIMIT 500
  `).all(a, b, b, a);
  const ua = q.userById.get(a);
  const ub = q.userById.get(b);
  res.json({
    a: ua ? { id: ua.id, username: ua.username, name: ua.name } : { id: a, username: 'deleted', name: '' },
    b: ub ? { id: ub.id, username: ub.username, name: ub.name } : { id: b, username: 'deleted', name: '' },
    messages: rows.map(m => Object.assign(serializeMsg(m, null), { toId: m.to_id }))
  });
});

app.delete('/api/admin/messages/:id', authRequired, adminRequired, (req, res) => {
  const row = db.prepare('SELECT * FROM messages WHERE id = ?').get(req.params.id);
  if (!row) return res.status(404).json({ error: 'Message not found' });
  db.prepare('DELETE FROM messages WHERE id = ?').run(req.params.id);
  if (row.file) fs.promises.unlink(path.join(UPLOAD_DIR, row.file)).catch(() => {});
  res.json({ ok: true });
});

app.get('/api/admin/videos', authRequired, adminRequired, (req, res) => {
  const qq = String(req.query.q || '').trim();
  const limit = Math.min(100, Math.max(1, Number(req.query.limit) || 50));
  const offset = Math.max(0, Number(req.query.offset) || 0);
  const like = '%' + qq + '%';
  const rows = db.prepare(`
    SELECT v.*, u.username, u.name AS author_name,
      (SELECT COUNT(*) FROM likes l WHERE l.video_id = v.id) AS real_likes,
      (SELECT COUNT(*) FROM comments c WHERE c.video_id = v.id) AS comment_count,
      (SELECT COUNT(*) FROM reports r WHERE r.video_id = v.id AND r.status = 'pending') AS report_count
    FROM videos v JOIN users u ON u.id = v.user_id
    WHERE (? = '' OR v.caption LIKE ? OR u.username LIKE ?)
    ORDER BY v.created_at DESC LIMIT ? OFFSET ?
  `).all(qq, like, like, limit, offset);
  res.json({
    items: rows.map(v => ({
      id: v.id, caption: v.caption, url: v.url || ('/media/' + v.filename),
      author: { id: v.user_id, username: v.username, name: v.author_name },
      views: v.views, likes: v.real_likes + (v.extra_likes || 0),
      comments: v.comment_count, reports: v.report_count, createdAt: v.created_at
    }))
  });
});

app.delete('/api/admin/videos/:id', authRequired, adminRequired, (req, res) => {
  if (!removeVideo(req.params.id)) return res.status(404).json({ error: 'Video not found' });
  res.json({ ok: true });
});

app.get('/api/admin/reports', authRequired, adminRequired, (req, res) => {
  const status = ['pending', 'resolved', 'dismissed'].includes(String(req.query.status)) ? String(req.query.status) : 'pending';
  const rows = db.prepare(`
    SELECT r.*, v.caption, v.filename, v.url, v.user_id AS owner_id,
           u.username AS owner_username, rep.username AS reporter_username, rep.name AS reporter_name
    FROM reports r
    JOIN videos v ON v.id = r.video_id
    JOIN users u ON u.id = v.user_id
    JOIN users rep ON rep.id = r.user_id
    WHERE r.status = ?
    ORDER BY r.created_at DESC LIMIT 200
  `).all(status);
  res.json({
    items: rows.map(r => ({
      id: r.id, reason: r.reason, status: r.status, createdAt: r.created_at,
      video: {
        id: r.video_id, caption: r.caption,
        url: r.url || ('/media/' + r.filename),
        author: { id: r.owner_id, username: r.owner_username }
      },
      reporter: { username: r.reporter_username, name: r.reporter_name }
    }))
  });
});

app.post('/api/admin/reports/:id', authRequired, adminRequired, (req, res) => {
  const status = String(req.body.status || '');
  if (!['resolved', 'dismissed', 'pending'].includes(status)) return res.status(400).json({ error: 'Invalid status' });
  const info = db.prepare('UPDATE reports SET status = ? WHERE id = ?').run(status, req.params.id);
  if (!info.changes) return res.status(404).json({ error: 'Report not found' });
  res.json({ ok: true });
});

/* ---------------- official message archive (per user) ---------------- */
app.post('/api/official/archive', authRequired, (req, res) => {
  const me = req.user.id;
  const otherId = String(req.body.userId || '');
  const other = q.userById.get(otherId);
  if (!other) return res.status(404).json({ error: 'User not found' });
  const action = req.body.action === 'unarchive' ? 'unarchive' : 'archive';

  const adminIds = db.prepare('SELECT id FROM users WHERE is_admin = 1').all().map(r => r.id);

  if (action === 'unarchive') {
    const info = db.prepare(`DELETE FROM official_archives WHERE user_id = ?
      AND message_id IN (SELECT id FROM messages
        WHERE (from_id = ? AND to_id = ?) OR (from_id = ? AND to_id = ?))`)
      .run(me, me, otherId, otherId, me);
    return res.json({ ok: true, action, count: info.changes });
  }

  // sirf woh official messages jo mujhe mile aur padhe ja chuke hain
  const rows = db.prepare(`SELECT id FROM messages
    WHERE to_id = ? AND from_id = ? AND read_at IS NOT NULL
      AND (is_admin = 1 OR from_id IN (${adminIds.map(() => '?').join(',') || "''"}))
    ORDER BY created_at ASC`).all(me, otherId, ...adminIds);

  const ins = db.prepare('INSERT OR IGNORE INTO official_archives (user_id, message_id, archived_at) VALUES (?,?,?)');
  let count = 0;
  const tx = db.transaction(() => { rows.forEach(r => { count += ins.run(me, r.id, now()).changes; }); });
  tx();

  res.json({ ok: true, action: 'archive', count });
});

/* ---------------------------- chat / DMs ---------------------------- */
function serializeMsg(m, meId) {
  return {
    id: m.id,
    body: m.body,
    kind: m.kind || 'text',
    url: m.file ? '/media/' + m.file : null,
    mime: m.mime || null,
    duration: m.duration || 0,
    fromAdmin: !!m.is_admin,
    peaks: (() => { try { return m.peaks ? JSON.parse(m.peaks) : null; } catch (e) { return null; } })(),
    fromId: m.from_id,
    mine: meId ? m.from_id === meId : undefined,
    createdAt: m.created_at,
    readAt: m.read_at
  };
}

function otherUserLite(id, viewerId) {
  const u = q.userById.get(id);
  if (!u) return null;
  return publicUserLite(u, viewerId);
}

app.get('/api/unread', authRequired, (req, res) => {
  const rows = db.prepare(`SELECT from_id, COUNT(*) AS c FROM messages
                           WHERE to_id = ? AND read_at IS NULL GROUP BY from_id`).all(req.user.id);
  const total = rows.reduce((s, r) => s + r.c, 0);
  const byUser = {};
  rows.forEach(r => { byUser[r.from_id] = r.c; });

  // official (admin) unread
  const official = db.prepare(`
    SELECT COUNT(*) AS c FROM messages m JOIN users u ON u.id = m.from_id
    WHERE m.to_id = ? AND m.read_at IS NULL AND (m.is_admin = 1 OR u.is_admin = 1)
  `).get(req.user.id).c;

  res.json({ total, official, byUser, officialNotify: req.user.official_notify || 'all' });
});

/* ---------------- presence routes ---------------- */
app.post('/api/presence/ping', authRequired, (req, res) => {
  touchPresence(req.user);
  res.json({ ok: true });
});

app.get('/api/presence/:userId', authRequired, (req, res) => {
  res.json(presenceOf(req.params.userId));
});

/* ---------------- typing indicator (in-memory, ephemeral) ---------------- */
const typingState = new Map();   // "from>to" -> expiry timestamp
const TYPING_TTL = 5000;

function typingCleanup() {
  const t = now();
  for (const [k, v] of typingState) if (v < t) typingState.delete(k);
}

app.post('/api/typing', authRequired, (req, res) => {
  const to = String(req.body.to || '');
  if (!to || to === req.user.id) return res.json({ ok: false });
  const key = req.user.id + '>' + to;
  if (req.body.typing === false) typingState.delete(key);
  else typingState.set(key, now() + TYPING_TTL);
  if (typingState.size > 2000) typingCleanup();
  res.json({ ok: true });
});

/* kis kis user(s) ne mujhe message likhna shuru kiya hai */
app.get('/api/typing', authRequired, (req, res) => {
  const me = req.user.id;
  const t = now();
  const users = [];
  for (const [k, v] of typingState) {
    if (v < t) continue;
    const idx = k.indexOf('>');
    if (k.slice(idx + 1) === me) users.push(k.slice(0, idx));
  }
  res.json({ users });
});

/* ek specific user typing hai ya nahi */
app.get('/api/typing/:userId', authRequired, (req, res) => {
  const key = req.params.userId + '>' + req.user.id;
  const exp = typingState.get(key) || 0;
  const typing = exp > now();
  if (!typing && exp) typingState.delete(key);
  res.json({ typing });
});

app.get('/api/conversations', authRequired, (req, res) => {
  const me = req.user.id;
  const rows = db.prepare(`
    SELECT CASE WHEN from_id = ? THEN to_id ELSE from_id END AS other_id,
           MAX(created_at) AS last_at, COUNT(*) AS total
    FROM messages WHERE from_id = ? OR to_id = ?
    GROUP BY other_id ORDER BY last_at DESC LIMIT 100
  `).all(me, me, me);

  const pinRows = db.prepare('SELECT other_id, pinned FROM chat_pins WHERE user_id = ?').all(me);
  const pinMap = new Map(pinRows.map(r => [r.other_id, r.pinned]));

  const items = rows.map(r => {
    const user = otherUserLite(r.other_id, me);
    if (!user) return null;
    const last = db.prepare(`
      SELECT body, kind, from_id, is_admin, created_at FROM messages
      WHERE (from_id = ? AND to_id = ?) OR (from_id = ? AND to_id = ?)
      ORDER BY created_at DESC LIMIT 1
    `).get(me, r.other_id, r.other_id, me);
    const unread = db.prepare('SELECT COUNT(*) AS c FROM messages WHERE from_id = ? AND to_id = ? AND read_at IS NULL')
      .get(r.other_id, me).c;
    const typing = (typingState.get(r.other_id + '>' + me) || 0) > now();
    const pres = presenceOf(r.other_id);
    const hasAdminMsg = !!db.prepare(`SELECT 1 FROM messages
      WHERE is_admin = 1 AND ((from_id = ? AND to_id = ?) OR (from_id = ? AND to_id = ?)) LIMIT 1`)
      .get(me, r.other_id, r.other_id, me);
    const official = hasAdminMsg || !!(q.userById.get(r.other_id) || {}).is_admin;

    // last OFFICIAL message (pinned row ka preview)
    const lo = db.prepare(`SELECT body, kind, is_admin, created_at FROM messages m
      WHERE (m.is_admin = 1 OR m.from_id IN (SELECT id FROM users WHERE is_admin = 1))
        AND ((m.from_id = ? AND m.to_id = ?) OR (m.from_id = ? AND m.to_id = ?))
      ORDER BY m.created_at DESC LIMIT 1`).get(me, r.other_id, r.other_id, me);
    const lastOfficial = lo ? { body: lo.body, kind: lo.kind || 'text', createdAt: lo.created_at } : null;
    return {
      user,
      lastMessage: last ? {
        body: last.body, kind: last.kind || 'text',
        fromMe: last.from_id === me, fromAdmin: !!last.is_admin,
        createdAt: last.created_at
      } : null,
      unread,
      typing,
      official,
      lastOfficial,
      online: pres.online,
      lastSeen: pres.lastSeen,
      total: r.total,
      updatedAt: r.last_at
    };
  }).filter(Boolean);

  // official (admin) chats pin ho kar sab se upar — user unpin kar sakta hai
  items.forEach(i => {
    i.canPin = !!i.official;
    i.pinned = !!i.official && pinMap.get(i.user.id) !== 0;
  });
  items.sort((a, b) => (Number(b.pinned) - Number(a.pinned)) ||
                       (Number(b.official) - Number(a.official)) ||
                       (b.updatedAt - a.updatedAt));

  res.json({ items });
});

/* official chat pin / unpin (per user) */
app.post('/api/conversations/:userId/pin', authRequired, (req, res) => {
  const me = req.user.id;
  const other = q.userById.get(req.params.userId);
  if (!other) return res.status(404).json({ error: 'User not found' });
  const pinned = req.body.pinned === false ? 0 : 1;

  db.prepare(`INSERT INTO chat_pins (user_id, other_id, pinned) VALUES (?,?,?)
              ON CONFLICT(user_id, other_id) DO UPDATE SET pinned = excluded.pinned`)
    .run(me, other.id, pinned);

  res.json({ ok: true, pinned: !!pinned });
});

app.get('/api/messages/:userId', authRequired, (req, res) => {
  const me = req.user.id;
  const other = q.userById.get(req.params.userId);
  if (!other) return res.status(404).json({ error: 'User not found' });
  const before = Number(req.query.before) || Number.MAX_SAFE_INTEGER;
  const limit = Math.min(100, Math.max(1, Number(req.query.limit) || 50));

  // pehle incoming messages ko read mark karein (taake response mein bhi readAt aa jaye)
  db.prepare('UPDATE messages SET read_at = ? WHERE from_id = ? AND to_id = ? AND read_at IS NULL')
    .run(now(), other.id, me);

  const rows = db.prepare(`
    SELECT * FROM messages
    WHERE ((from_id = ? AND to_id = ?) OR (from_id = ? AND to_id = ?)) AND created_at < ?
    ORDER BY created_at DESC LIMIT ?
  `).all(me, other.id, other.id, me, before, limit);

  const archSet = new Set(
    db.prepare('SELECT message_id FROM official_archives WHERE user_id = ?').all(me).map(r => r.message_id)
  );

  res.json({
    user: Object.assign(publicUserLite(other, me), presenceOf(other.id)),
    messages: rows.reverse().map(m => Object.assign(serializeMsg(m, me), { archived: archSet.has(m.id) })),
    hasMore: rows.length === limit
  });
});

app.post('/api/messages', authRequired, (req, res) => {
  const me = req.user.id;
  const to = String(req.body.to || '');
  const body = String(req.body.body || '').trim().slice(0, 1000);
  if (!body) return res.status(400).json({ error: 'Message khali hai.' });
  if (to === me) return res.status(400).json({ error: 'Apne aap ko message nahi bhej sakte.' });
  const other = q.userById.get(to);
  if (!other) return res.status(404).json({ error: 'User not found' });
  if (other.banned) return res.status(400).json({ error: 'Ye user banned hai — message nahi bhej sakte.' });

  const m = { id: uid(), from_id: me, to_id: other.id, body, created_at: now(), read_at: null };
  db.prepare('INSERT INTO messages (id,from_id,to_id,body,created_at,read_at) VALUES (@id,@from_id,@to_id,@body,@created_at,@read_at)').run(m);
  res.json({ message: serializeMsg(m, me) });
});

/* photo / video DM */
const dmUpload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => cb(null, UPLOAD_DIR),
    filename: (req, file, cb) => {
      let ext = (path.extname(file.originalname || '') || '').toLowerCase();
      if (!/^\.[a-z0-9]{2,5}$/.test(ext)) ext = /^image\//.test(file.mimetype) ? '.jpg' : '.mp4';
      cb(null, 'dm_' + uid() + ext);
    }
  }),
  limits: { fileSize: 25 * 1024 * 1024, files: 1 },
  fileFilter: (req, file, cb) => {
    const okImg = /^image\/(jpeg|jpg|png|webp|gif)$/i.test(file.mimetype);
    const okVid = /^video\/(mp4|webm|quicktime|x-m4v)$/i.test(file.mimetype);
    const okAud = /^audio\//i.test(file.mimetype) || /^video\/webm$/i.test(file.mimetype) && /voice|audio/i.test(file.originalname || '');
    if (!okImg && !okVid && !okAud) return cb(new Error('Sirf photo, video ya voice note bhej sakte hain.'));
    cb(null, true);
  }
});

app.post('/api/messages/media', authRequired, (req, res) => {
  dmUpload.single('file')(req, res, err => {
    const cleanup = () => { if (req.file) fs.promises.unlink(path.join(UPLOAD_DIR, req.file.filename)).catch(() => {}); };
    if (err) {
      return res.status(400).json({
        error: err.code === 'LIMIT_FILE_SIZE' ? 'File 25MB se choti honi chahiye.' : (err.message || 'Upload failed')
      });
    }
    try {
      if (!req.file) return res.status(400).json({ error: 'File chahiye.' });
      const to = String(req.body.to || '');
      if (to === req.user.id) { cleanup(); return res.status(400).json({ error: 'Apne aap ko message nahi bhej sakte.' }); }
      const other = q.userById.get(to);
      if (!other) { cleanup(); return res.status(404).json({ error: 'User not found' }); }
      if (other.banned) { cleanup(); return res.status(400).json({ error: 'Ye user banned hai.' }); }

      const mime = req.file.mimetype || '';
      const isAudio = /^audio\//i.test(mime) || /voice/i.test(req.file.originalname || '');
      const kind = /^image\//.test(mime) ? 'image' : isAudio ? 'audio' : 'video';
      const duration = Math.max(0, Math.min(600000, Math.floor(Number(req.body.duration) || 0)));
      let peaks = null;
      try {
        const raw = JSON.parse(req.body.peaks || 'null');
        if (Array.isArray(raw)) {
          peaks = raw.slice(0, 80).map(v => Math.max(0, Math.min(100, Math.round(Number(v) || 0))));
        }
      } catch (e) { peaks = null; }

      const m = {
        id: uid(), from_id: req.user.id, to_id: other.id, body: '',
        kind, file: req.file.filename, mime,
        duration, peaks: peaks ? JSON.stringify(peaks) : null,
        created_at: now(), read_at: null
      };
      db.prepare(`INSERT INTO messages (id,from_id,to_id,body,kind,file,mime,duration,peaks,created_at,read_at)
                  VALUES (@id,@from_id,@to_id,@body,@kind,@file,@mime,@duration,@peaks,@created_at,@read_at)`).run(m);
      res.json({ message: serializeMsg(m, req.user.id) });
    } catch (e) {
      console.error(e);
      cleanup();
      res.status(500).json({ error: 'Server error' });
    }
  });
});

/* ---------------------------- media ---------------------------- */
/* banned user ki video file direct URL se bhi na khule */
app.use('/media', (req, res, next) => {
  const file = decodeURIComponent(String(req.path || '').replace(/^\/+/, ''));
  if (!/^[A-Za-z0-9._-]+$/.test(file)) return res.status(400).end();
  try {
    const row = db.prepare(`SELECT u.banned FROM videos v JOIN users u ON u.id = v.user_id
                            WHERE v.filename = ?`).get(file);
    if (row && row.banned) return res.status(404).end();

    // DM media (voice notes) ka sahi content-type
    const dm = db.prepare('SELECT mime FROM messages WHERE file = ?').get(file);
    if (dm && dm.mime) res.setHeader('Content-Type', dm.mime);
  } catch (e) { /* fall through */ }
  next();
}, express.static(UPLOAD_DIR, {
  acceptRanges: true,
  maxAge: '7d',
  setHeaders: (res) => res.setHeader('Cache-Control', 'public, max-age=604800')
}));

/* ---------------------------- static ---------------------------- */
app.use(express.static(path.join(__dirname, 'public'), { extensions: ['html'] }));

app.get('/api/health', (req, res) => res.json({ ok: true, users: db.prepare('SELECT COUNT(*) c FROM users').get().c }));

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Server error' });
});

/* ------------------------------------------------------------------ */
/* owner / admin account                                               */
/* ------------------------------------------------------------------ */
function ensureAdmin() {
  const email = String(process.env.ADMIN_EMAIL || 'badmashik742@gmail.com').toLowerCase();
  const pass = String(process.env.ADMIN_PASSWORD || 'admin1234');
  const existing = q.userByEmail.get(email);
  if (!existing) {
    let uname = 'owner';
    let i = 1;
    while (q.userByUser.get(uname)) uname = 'owner' + (++i);
    db.prepare(`INSERT INTO users (id,name,username,email,pass_hash,bio,is_admin,email_verified,created_at)
                VALUES (?,?,?,?,?,?,1,1,?)`)
      .run(uid(), 'Owner', uname, email, bcrypt.hashSync(pass, 10), 'Platform owner', now());
    console.log('• owner/admin account ready: ' + email + '  (password: ' + pass + ')');
  } else {
    db.prepare('UPDATE users SET is_admin = 1, email_verified = 1 WHERE id = ?').run(existing.id);
  }
}
ensureAdmin();

/* ------------------------------------------------------------------ */
/* listen                                                              */
/* ------------------------------------------------------------------ */
/* ---------------- HTTPS (voice notes ke liye zaroori phone par) ---------------- */
const HTTPS_ON = String(process.env.HTTPS || '').toLowerCase() === '1' || String(process.env.HTTPS || '').toLowerCase() === 'true';

function ensureCert() {
  if (!HTTPS_ON && !process.env.HTTPS_CERT) return null;
  const dir = path.join(DATA_DIR, 'tls');
  const cert = process.env.HTTPS_CERT || path.join(dir, 'cert.pem');
  const key = process.env.HTTPS_KEY || path.join(dir, 'key.pem');
  if (fs.existsSync(cert) && fs.existsSync(key)) return { cert, key };
  fs.mkdirSync(dir, { recursive: true });
  try {
    require('child_process').execFileSync('openssl', [
      'req', '-x509', '-newkey', 'rsa:2048', '-nodes',
      '-keyout', key, '-out', cert, '-days', '365',
      '-subj', '/CN=' + (os.hostname() || 'tokclip.local')
    ], { stdio: 'ignore' });
    console.log('• self-signed TLS certificate ban gaya: ' + dir);
    return { cert, key };
  } catch (e) {
    console.log('⚠ self-signed certificate nahi ban saka (openssl missing) — HTTP par chal raha hai');
    return null;
  }
}

const tls = ensureCert();
const scheme = tls ? 'https' : 'http';

function onListen() {
  console.log('\n  TokClip server chal raha hai');
  console.log('  ─────────────────────────────');
  console.log('  Local:    ' + scheme + '://localhost:' + PORT);
  console.log('  Admin:    ' + scheme + '://localhost:' + PORT + '/admin');
  console.log('  Owner:    ' + String(process.env.ADMIN_EMAIL || 'badmashik742@gmail.com'));
  if (DEV_MAIL) console.log('  ⚠  SMTP set nahi hai — verification code server console + screen par dikhega');
  else console.log('  ✉  Email (SMTP): ' + SMTP_HOST + '  ·  from: ' + MAIL_FROM);
  if (!process.env.ADMIN_PASSWORD) console.log('  ⚠  ADMIN_PASSWORD set nahi hai — demo password "admin1234" use ho raha hai');

  const nets = os.networkInterfaces();
  Object.keys(nets).forEach(name => {
    (nets[name] || []).forEach(net => {
      if (net.family === 'IPv4' && !net.internal) {
        console.log('  Network:  ' + scheme + '://' + net.address + ':' + PORT + '   (' + name + ')');
      }
    });
  });

  if (tls) {
    console.log('  🔒 HTTPS ON — voice notes/mic phone par bhi chalenge');
    console.log('     (self-signed cert hai: browser "Advanced → Proceed" maangega)');
  } else {
    console.log('  🎤 Voice notes: browser mic sirf HTTPS/localhost par milta hai.');
    console.log('     Phone se test karna ho to: HTTPS=1 npm start');
  }
  console.log('  Data dir: ' + DATA_DIR);
  console.log('');
}

if (tls) {
  require('https')
    .createServer({ key: fs.readFileSync(tls.key), cert: fs.readFileSync(tls.cert) }, app)
    .listen(PORT, HOST, onListen);
} else {
  app.listen(PORT, HOST, onListen);
}
