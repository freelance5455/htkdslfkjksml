# TokClip — real short-video app (Node + SQLite)

TikTok jaisa full-stack video app: **email se signup + email verification**, video upload,
infinite feed, like / comment / follow, banned users ke liye appeal, aur ek **admin (owner) panel**.

- **Real users only** — koi fake/demo accounts nahi. Har account email verify karke banta hai.
- **Boost (views/likes/followers) sirf admin** kar sakta hai — koi user apne aap apne numbers nahi badha sakta.
- Sab kuch ek hi server par — same WiFi ya internet par alag alag devices ke log ek doosre ki videos dekhte hain.

---

## 1. Requirements

- **Node.js 18+** (`node -v`)
- npm

## 2. Install & run

```bash
cd tokclip-app
npm install
npm start
```

Terminal:

```
  Local:    http://localhost:3000
  Admin:    http://localhost:3000/admin
  Owner:    badmashik742@gmail.com
```

Phone/doosre device se: wahi **Network** address khol lein (`http://192.168.x.x:3000`).

## 3. Owner (admin) account

Owner email **`badmashik742@gmail.com`** hai — pehli baar server chalne par ye account
khud ban jata hai aur ye hi `/admin` panel ka maalik hota hai.

Password server start karte waqt set karein (recommended):

```bash
ADMIN_PASSWORD='mera-strong-password' npm start
```

Default (agar set na karein) `admin1234` hai — **public deployment par kabhi na rakhein.**

Badalna ho to:

```bash
ADMIN_EMAIL=badmashik742@gmail.com ADMIN_PASSWORD='naya-password' npm start
```

> Agar owner email se koi normal user pehle se bana hua ho, to server usi account ko
> admin + verified bana deta hai.

## 4. Real email verification (SMTP)

Signup par user ko **6-digit code** email hota hai. Mail bhejne ke liye SMTP chahiye.

### Gmail se (sab se aasan)

1. Google Account → **Security** → **2-Step Verification** on karein
2. Phir **App passwords** (https://myaccount.google.com/apppasswords) se 16-character password banayein
3. Server is tarah chalayein:

```bash
SMTP_HOST=smtp.gmail.com \
SMTP_PORT=587 \
SMTP_USER=badmashik742@gmail.com \
SMTP_PASS='abcd efgh ijkl mnop' \
ADMIN_PASSWORD='strong-password' \
npm start
```

Ya `.env` file banayein (dekhein `.env.example`) aur `.env` load karne ke liye:

```bash
node --env-file=.env server.js
```

### Bina SMTP (testing)

Agar SMTP set nahi hai to server **dev mode** mein chalta hai: code terminal mein
print hota hai aur signup screen par bhi dikh jata hai (taake test kar sakein).
Production/deployment par SMTP zaroor set karein.

## 5. Features

**User app (`/`)**

| Feature | Detail |
|---|---|
| Signup | naam + username + email + password → **email verification code** |
| Login | email + password (unverified account par pehle code bhejta hai) |
| Forgot password | email par reset code → naya password |
| Feed | For You / Following, infinite scroll, autoplay, mute, double-tap ❤️, **skeleton loading** |
| Discover tab | search (users / videos / hashtags), trending hashtags, suggested creators, popular grid, video preview sheet |
| Long-press | kisi bhi video par daba kar rakhein → **Save video · Copy link · Follow/Unfollow · Not interested · Report** (desktop par right-click) |
| Upload | drag & drop / tap, MP4 · WebM · MOV (300MB tak), file info + duration, live caption counter, hashtag chips, upload progress |
| Following feed | khali ho to suggested creators (Follow buttons) — follow karte hi feed bhar jati hai |
| Social | like, comment, follow/unfollow, share link, **report** video |
| **Official tab** | Inbox mein **All / 🛡 Official** tabs — admin ki taraf se bheje messages alag list mein; tab par **unread official count** badge |
| **Official archive** | official thread mein **📦 Archive** button — padhe hue admin messages collapse ho kar "N archived" section mein chale jate hain, naye messages **✨ Naye messages** section mein alag dikhte hain (expand/collapse toggle, kuch delete nahi hota) |
| **Pinned official chat** | admin ke saath chat Inbox mein **sab se upar 📌 Pinned** group mein fix rehti hai (amber border + pin icon); pinned row par **last official message ka preview** (`OFFICIAL …`); **swipe-left** ya **long-press** se Unpin/Pin; thread ka apna **official theme** |
| **Official notification settings** | Inbox header ke ⚙️ se choose karein: **Banner + Badge** (default) / **Sirf badge** / **Sirf inbox** — setting account par save hoti hai (har device par same) |
| **Official banner** | nayi official message aane par app ke top par **amber highlight banner** ("Admin ki taraf se N naye official messages") → **Dekhein** se seedha Official tab, ✕ se dismiss (dismiss count yaad rehta hai) |
| **Admin bubbles** | Admin ke messages chat mein **amber bubble** + `ADMIN` tag, inbox preview par `OFFICIAL` |
| **Inbox / DMs** | users ek doosre ko message bhejein — text + **photos & short videos** (25MB tak), unread badge (nav par), 4s polling, new-chat user search |
| Chat media | bubble mein thumbnail — photo tap → full-screen viewer, video inline controls |
| **Typing indicator** | doosra banda likh raha ho to chat header + chat mein animated "typing…" bubble, inbox list mein bhi "typing…" |
| **Read receipts** | apne message par ✓ (sent) aur padh liya jaye to **✓✓ blue tick** (read time tooltip) |
| **Online / last seen** | chat header mein 🟢 online ya "last seen 5m ago", inbox avatars par green dot |
| **Voice notes** | 🎤 mic button → live waveform recording (max 2 min), cancel/send, waveform player (play/pause + progress), **playback speed 1x / 1.5x / 2x**, play par latest message tak **auto-scroll** |
| Profile | apni videos, followers/following/likes/views, edit profile |
| Banned screen | ban ka reason + **appeal form** |

**Admin panel (`/admin`)**

| Tab | Kya hai |
|---|---|
| **Leaderboards** | **Top creators** (views/likes/followers/videos) aur **Top videos** (views/likes) — medal ranks 🥇🥈🥉, **rank change vs 24h (▲/▼/—/NEW)**, VIEWS/LIKES toggle, 30s auto-refresh |
| **Creator drawer** | leaderboard ke kisi bhi creator (ya Users tab ki row) par click → side panel: profile, status (online/banned/verified), 6 stats, actions (Boost followers / Ban / Delete), uski saari videos with per-video Boost, aur **Direct messages** — kisi bhi chat par click karke poori conversation (text/photo/video/voice) padh sakte hain, plus **Admin message** box se creator ko seedha private message bhej sakte hain |
| **Trend chart** | **24H / 7D / 30D toggle** — naye users / videos / reports / messages (4 sparklines, peak + totals). 24h = hourly buckets, 7d/30d = daily buckets. Range localStorage mein yaad rehti hai, 30s auto-refresh |
| **Dashboard summary** | alerts cards (pending reports / appeals / unread chats / banned / unverified) + recent activity feed — **har 30s auto-refresh**. Card par click = seedha us tab par (auto-scroll + flash highlight + URL hash `#reports`, `#appeals`, `#chats`, `#users`) |
| Stats | users, videos, views, likes, comments, messages, follows, reports, appeals, banned, unverified, storage |
| Videos | saari videos, search, **Boost** (views/likes), **Remove** |
| Users | search, **Boost** (followers), **Ban/Unban** (reason ke saath), **Make admin**, **Delete** |
| Reports | pending/resolved/dismissed, **Remove video** ya **Keep** |
| Appeals | pending/approved/rejected, **Approve & unban** / **Reject** (note) / **Reopen** |
| Chats | saari DM conversations (participants, count, unread, last message) → **View** = poori chat read-only (photos/videos ke saath), koi bhi message **delete** |

### Boost policy

- Sirf **admin** kisi bhi video ke **views / likes** aur kisi bhi user ke **followers** set kar sakta hai.
- Normal user ke liye ye endpoints `403 Admin access required` dete hain — profile par koi boost button nahi hai.

### Ban hone par

Login `403` (reason ke saath) · purana token bhi block · videos feed se hat jati hain ·
profile aur video file `404` · appeal bhej sakta hai · admin approve kare to ban khud hat jata hai.

## 5b. Voice notes + HTTPS (mic ke liye zaroori)

Chat mein 🎤 button se voice note record hota hai (waveform ke saath). Browser ka
microphone sirf **secure context** mein milta hai:

| Address | Mic | Voice note |
|---|---|---|
| `http://localhost:3000` | ✅ | chalta hai |
| `http://192.168.x.x:3000` (phone/LAN) | ❌ | browser block karta hai |
| `https://...` | ✅ | chalta hai |

LAN/phone par bhi chalane ke liye HTTPS on karein:

```bash
npm run https          # ya: HTTPS=1 npm start
```

Pehli baar server khud **self-signed certificate** bana leta hai (`data/tls/cert.pem`
+ `key.pem`, openssl se). Phir `https://<ip>:3000` kholein aur browser ke
"Advanced → Proceed" par click karein — uske baad 🎤 kaam karega.

Apna asli certificate (Let's Encrypt / nginx) use karna ho to:

```bash
HTTPS=1 HTTPS_CERT=/etc/letsencrypt/live/app/fullchain.pem \
        HTTPS_KEY=/etc/letsencrypt/live/app/privkey.pem npm start
```

> Note: agar mic ka option hi nahi mil raha to address bar ke lock icon se
> Microphone → Allow karein. App khud bhi batati hai ke HTTPS chahiye.

## 6. Folder structure

```
tokclip-app/
├── server.js          # Express API + SQLite + uploads + email + admin
├── public/
│   ├── index.html     # main app
│   ├── styles.css
│   ├── app.js
│   ├── admin.html     # /admin panel
│   └── admin.js
├── data/              # auto: app.db, uploads/, jwt.secret
├── .env.example
└── package.json
```

## 7. API (short)

| Method | Path | Description |
|---|---|---|
| POST | `/api/auth/signup` | account banao → verification code email |
| POST | `/api/auth/verify` | `{email, code}` → token |
| POST | `/api/auth/resend` | code dobara bhejein |
| POST | `/api/auth/login` | `{email, password}` → token |
| POST | `/api/auth/forgot` / `/api/auth/reset` | password reset via email code |
| GET | `/api/me` | current user + totals |
| PATCH | `/api/me` | name / username / bio |
| GET | `/api/feed?tab=foryou\|following&before=<ts>` | feed pages |
| GET | `/api/discover` | trending videos + popular creators + hashtags |
| GET | `/api/search?q=` | users, videos aur hashtags search |
| GET | `/api/suggested` | follow karne ke liye suggested creators |
| POST | `/api/videos` | multipart `video` + `caption` |
| POST | `/api/videos/:id/like` · `/view` · `/report` | interactions |
| GET/POST | `/api/videos/:id/comments` | comments |
| POST | `/api/users/:id/follow` | follow toggle |
| GET | `/api/conversations` | DM conversations + unread + `official` / `pinned` / `lastOfficial` (official sab se upar) |
| POST | `/api/conversations/:userId/pin` | `{pinned}` → official chat pin/unpin (per user) |
| POST | `/api/official/archive` | `{userId, action: archive\|unarchive}` → read official messages collapse |
| GET | `/api/messages/:userId` | chat thread (incoming read mark) |
| POST | `/api/messages` | `{to, body}` text DM |
| POST | `/api/messages/media` | multipart `file` + `to` (+ `duration`, `peaks` for voice) → photo / video / **voice note** (25MB) |
| GET | `/api/unread` | `{total, official, byUser, officialNotify}` |
| POST | `/api/me/official-notify` | `{mode: all\|badge\|inbox}` → official notifications setting |
| POST | `/api/typing` | `{to, typing?}` → typing state (5s TTL) |
| GET | `/api/typing/:userId` | kya wo user typing hai |
| GET | `/api/typing` | kaun kaun mujhe likh raha hai |
| POST | `/api/presence/ping` | heartbeat (client har 25s) |
| GET | `/api/presence/:userId` | `{online, lastSeen}` |
| POST | `/api/appeal` | banned user ki appeal |
| GET | `/api/admin/overview?range=24h\|7d\|30d` | stats + chart series + **leaderboards** (by views & by likes) + alerts + activity |
| — | `/api/admin/*` | stats, users, videos, reports, appeals, chats, boost, ban |

Auth header: `Authorization: Bearer <token>`.

## 8. Environment variables

| Variable | Default | Description |
|---|---|---|
| `PORT` | `3000` | port |
| `HOST` | `0.0.0.0` | bind address |
| `DATA_DIR` | `./data` | database + uploads |
| `JWT_SECRET` | auto | token secret |
| `ADMIN_EMAIL` | `badmashik742@gmail.com` | owner login |
| `ADMIN_PASSWORD` | `admin1234` | owner password (**badlein**) |
| `SMTP_HOST` / `SMTP_PORT` / `SMTP_SECURE` | — | mail server |
| `SMTP_USER` / `SMTP_PASS` | — | SMTP credentials (Gmail app password) |
| `MAIL_FROM` | — | sender name/address |
| `MAX_UPLOAD_MB` | `300` | max video size |
| `HTTPS` | off | `1` = HTTPS on (self-signed cert auto) |
| `HTTPS_CERT` / `HTTPS_KEY` | — | apne certificate ke paths |

## 9. Internet par deploy

**Render / Railway / Fly.io (Node app):**

1. Folder GitHub par push karein
2. Build: `npm install`, Start: `npm start`
3. **Persistent disk** add karein → `DATA_DIR=/var/data` (warna redeploy par data delete)
4. Env vars: `JWT_SECRET`, `ADMIN_EMAIL`, `ADMIN_PASSWORD`, `SMTP_*`
5. Deploy ke baad: app `https://your-app.onrender.com`, admin `https://your-app.onrender.com/admin`

**VPS:**

```bash
DATA_DIR=/var/lib/tokclip PORT=3000 JWT_SECRET='...' ADMIN_PASSWORD='...' \
SMTP_HOST=smtp.gmail.com SMTP_USER=badmashik742@gmail.com SMTP_PASS='app-password' \
node server.js
# aage nginx reverse proxy + certbot (HTTPS)
```

## 10. Backup

```bash
tar -czf tokclip-backup.tar.gz data/
```

## 11. Notes

- Videos `data/uploads/` mein disk par save hoti hain; DB `data/app.db` (SQLite, WAL mode).
- Passwords bcrypt; JWT 90 din valid.
- Email codes 15 minute valid, 6 galat tries par block, resend par 45 sec cooldown.
- Purane databases par server khud migration chalata hai (`email_verified`, `banned`, `is_admin`).
- Chat/DM messages `messages` table mein; admin panel ke **Chats** tab se sab conversations
  padhi ja sakti hain aur koi bhi message delete kiya ja sakta hai.
- Chat media (`kind` = `image` / `video` / `audio`) `data/uploads/dm_*` mein save hota hai; message
  delete karne par file bhi delete hoti hai.
- Voice note speed preference `localStorage` mein yaad rehti hai (chat + admin dono jagah same).
- Typing indicator memory mein rehta hai (5 second TTL), DB mein save nahi hota — server restart
  par reset ho jata hai. Client har 2 second par check karta hai, inbox har 3 second par.
- Admin dashboard har 30s `/api/admin/overview` call karta hai (tab hidden ho to pause, wapas
  aane par turant refresh).
- Admin ke bheje messages `messages.is_admin = 1` ke saath save hote hain; conversations API `official`
  flag bhi deti hai (admin message ya admin user ke saath chat); user app mein un par
  **ADMIN** badge dikhta hai aur inbox preview mein bhi `ADMIN` prefix aata hai.
- Rank change ke liye server har ghante `leaderboard_snapshots` mein top-20 ranks ka snapshot leta hai
  (8 din tak rakhta hai). Comparison 24h purane snapshot se hota hai; agar itni history nahi hai
  to `NEW` dikhta hai aur header par "kal se compare hoga" likha aata hai.
- Leaderboard top 8 deta hai — `leaderboard.creators.byViews/byLikes` aur `leaderboard.videos.byViews/byLikes`; toggle se switch instant hota hai (dobara fetch nahi).
- Chart buckets server par bante hain: `24h` = 24 hourly, `7d` = 7 daily, `30d` = 30 daily
  (`chart.series.{users,videos,reports,messages}`); labels local time (`23:00`, `Mon 28`, `28/10`).
- Presence: client har 25s heartbeat bhejta hai; 45s tak koi activity na ho to offline.
  `users.last_seen` DB mein save hota hai (30s throttle) — restart ke baad bhi "last seen" sahi rehta hai.
- Read receipt: thread kholte hi incoming messages par `read_at` set hota hai; sender ke client ko
  agle poll (4s) par ✓✓ blue tick dikh jata hai.
- Voice notes browser ke `MediaRecorder` se record hote hain (audio/webm; Safari par mp4) aur
  waveform peaks ke saath DB mein save hote hain — is liye receiver aur admin dono ko same
  waveform dikhta hai. Mic ke liye HTTPS ya localhost zaroori hai (browser rule).
- Agar signup par "email nahi bhej paya" aaye to SMTP settings check karein, ya dev mode mein code terminal se lein.
