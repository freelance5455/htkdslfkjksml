# Shadow AI

تطبيق دردشة ذكاء اصطناعي (أسود/بنفسجي، عربي/إنجليزي) — Backend Node.js + واجهة PWA قابلة للتثبيت على Android.
الإجابات حقيقية من OpenAI عبر Streaming. مفتاح API يبقى في الخادم فقط.

## التشغيل على الحاسوب
1. ثبّت Node.js 18+ ثم: `npm install`
2. `cp .env.example .env` وضع مفتاحك في `OPENAI_API_KEY=` (أو صدّره كمتغير بيئة)
3. `npm start` ثم افتح http://localhost:3000

## التشغيل من الهاتف (Android) — 3 طرق
- **Termux (بدون حاسوب):** `pkg install nodejs git` → انسخ المجلد → `npm install` → `export OPENAI_API_KEY="sk-..."` → `npm start` → افتح `http://localhost:3000` في Chrome → ⋮ → «إضافة إلى الشاشة الرئيسية».
- **نفس الشبكة:** شغّل على الحاسوب ثم افتح `http://IP-الحاسوب:3000` في هاتفك.
- **نشر عام (للاستعمال في أي مكان):** ارفع المشروع إلى Render/Railway/Fly.io، أضف `OPENAI_API_KEY` في Environment Variables، وافتح الرابط (HTTPS) ثم «تثبيت التطبيق».

## APK
بعد النشر على رابط HTTPS، حوّله إلى APK بـ PWABuilder.com أو Bubblewrap (TWA).

## الهيكل
`server.js` (API + Streaming + حدّ طلبات + معالجة أخطاء) · `public/` (الواجهة، PWA) · `.env.example`

## التطوير لاحقاً
تسجيل دخول وقاعدة بيانات للسجل (مثلاً Supabase)، رفع PDF، توليد صور، تغيير النموذج عبر `OPENAI_MODEL`.
