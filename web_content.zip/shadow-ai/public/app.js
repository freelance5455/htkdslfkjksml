'use strict';
const $ = (s) => document.querySelector(s);
const I18N = {
  ar: { dir: 'rtl', ph: 'اكتب رسالتك…', new: '＋ محادثة جديدة', title: 'محادثة جديدة', hello: 'كيف أساعدك اليوم؟',
    sug: ['لخّص لي نصاً', 'اشرح لي درساً', 'ساعدني في كود', 'حل تمرين خطوة بخطوة'],
    copy: 'نسخ', copied: 'تم', file: 'ملف', big: 'الملف كبير جداً (الحد 8 ميغابايت للصور).', type: 'نوع الملف غير مدعوم (استعمل صورة أو ملف نصي/كود).',
    e: { invalid_key: 'مفتاح OpenAI على الخادم غير صالح.', quota: 'تم تجاوز الحد أو الرصيد غير كافٍ. حاول لاحقاً.', rate_limit: 'طلبات كثيرة، انتظر قليلاً.', bad_request: 'الطلب غير صالح (قد يكون الملف كبيراً).', upstream: 'تعذّر الوصول إلى OpenAI. حاول مرة أخرى.', network: 'تعذّر الاتصال بالخادم. تحقق من الشبكة.' } },
  en: { dir: 'ltr', ph: 'Type your message…', new: '＋ New chat', title: 'New chat', hello: 'How can I help today?',
    sug: ['Summarize a text', 'Explain a lesson', 'Help me with code', 'Solve an exercise step by step'],
    copy: 'Copy', copied: 'Done', file: 'file', big: 'File too large (images max 8 MB).', type: 'Unsupported file (use an image or a text/code file).',
    e: { invalid_key: 'The OpenAI key on the server is invalid.', quota: 'Rate limit or quota exceeded. Try again later.', rate_limit: 'Too many requests, please wait.', bad_request: 'Invalid request (file may be too large).', upstream: 'Could not reach OpenAI. Try again.', network: 'Cannot reach the server. Check your network.' } }
};
const store = {
  get(k, d) { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} }
};
let lang = store.get('sh.lang', navigator.language?.startsWith('en') ? 'en' : 'ar');
let convs = store.get('sh.convs', []);
let cur = null, pending = [], ctrl = null, busy = false;
const T = () => I18N[lang];
const save = () => store.set('sh.convs', convs.map((c) => ({ ...c, messages: c.messages.map(({ images, ...m }) => ({ ...m, imgCount: images?.length || m.imgCount || 0 })) })));

function esc(s) { return s.replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }
function md(src) {
  const blocks = [];
  let s = esc(src).replace(/```(\w*)\n?([\s\S]*?)(```|$)/g, (_, l, c) => { blocks.push(`<pre><button class="copy">${T().copy}</button><code>${c.replace(/\n$/, '')}</code></pre>`); return `\u0000${blocks.length - 1}\u0000`; });
  const inline = (t) => t.replace(/`([^`]+)`/g, '<code>$1</code>').replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>').replace(/(^|\W)\*([^*\n]+)\*/g, '$1<i>$2</i>');
  const out = []; let list = null;
  const close = () => { if (list) { out.push(`</${list}>`); list = null; } };
  for (const line of s.split('\n')) {
    let m;
    if ((m = line.match(/^\s*[-*•]\s+(.*)/))) { if (list !== 'ul') { close(); out.push('<ul>'); list = 'ul'; } out.push(`<li>${inline(m[1])}</li>`); }
    else if ((m = line.match(/^\s*\d+[.)]\s+(.*)/))) { if (list !== 'ol') { close(); out.push('<ol>'); list = 'ol'; } out.push(`<li>${inline(m[1])}</li>`); }
    else if ((m = line.match(/^#{1,4}\s+(.*)/))) { close(); out.push(`<h3>${inline(m[1])}</h3>`); }
    else if (!line.trim()) close();
    else { close(); out.push(/^\u0000\d+\u0000$/.test(line.trim()) ? line : `<p>${inline(line)}</p>`); }
  }
  close();
  return out.join('').replace(/\u0000(\d+)\u0000/g, (_, i) => blocks[i]);
}

function applyLang() {
  document.documentElement.lang = lang; document.documentElement.dir = T().dir;
  $('#input').placeholder = T().ph; $('#langBtn').textContent = lang === 'ar' ? 'EN' : 'عربي';
  document.querySelectorAll('[data-i18n]').forEach((el) => (el.textContent = T()[el.dataset.i18n]));
  renderList(); renderChat();
}
function renderList() {
  const l = $('#list'); l.innerHTML = '';
  convs.forEach((c) => {
    const d = document.createElement('div'); d.className = 'item' + (c === cur ? ' on' : '');
    const b = document.createElement('button'); b.className = 't'; b.textContent = c.title || T().title;
    b.onclick = () => { if (busy) return; cur = c; closeDrawer(); renderList(); renderChat(); };
    const x = document.createElement('button'); x.className = 'x'; x.textContent = '✕';
    x.onclick = () => { if (busy) return; convs = convs.filter((v) => v !== c); if (cur === c) cur = null; save(); renderList(); renderChat(); };
    d.append(b, x); l.append(d);
  });
}
function msgEl(m, streaming) {
  const w = document.createElement('div'); w.className = 'msg ' + (m.role === 'user' ? 'user' : 'ai');
  const n = (m.images?.length || m.imgCount || 0);
  if (n || m.files?.length) {
    const t = document.createElement('div'); t.className = 'thumbs';
    (m.images || []).forEach((u) => { const i = document.createElement('img'); i.src = u; t.append(i); });
    if (!m.images?.length && n) t.insertAdjacentHTML('beforeend', `<span>🖼 ×${n}</span>`);
    (m.files || []).forEach((f) => t.insertAdjacentHTML('beforeend', `<span>📄 ${esc(f)}</span>`));
    w.append(t);
  }
  const b = document.createElement('div'); b.className = 'body';
  if (m.role === 'user') b.textContent = m.shown ?? m.content; else b.innerHTML = md(m.content || '');
  if (streaming) b.classList.add('cursor');
  if (m.error) b.classList.add('err');
  w.append(b); return w;
}
function renderChat() {
  const c = $('#chat'); c.innerHTML = '';
  if (!cur || !cur.messages.length) {
    c.innerHTML = `<div class="empty"><img src="/logo.svg" alt="Shadow AI"><h1>Shadow AI</h1><div>${T().hello}</div><div class="sug"></div></div>`;
    T().sug.forEach((s) => { const b = document.createElement('button'); b.textContent = s; b.onclick = () => { $('#input').value = s; send(); }; c.querySelector('.sug').append(b); });
    return;
  }
  cur.messages.forEach((m) => c.append(msgEl(m)));
  c.scrollTop = c.scrollHeight;
}
function renderChips() {
  $('#chips').innerHTML = '';
  pending.forEach((p, i) => {
    const d = document.createElement('div'); d.className = 'chip';
    d.innerHTML = `<span>${p.image ? '🖼' : '📄'} ${esc(p.name)}</span>`;
    const x = document.createElement('button'); x.textContent = '✕'; x.onclick = () => { pending.splice(i, 1); renderChips(); };
    d.append(x); $('#chips').append(d);
  });
}
const openDrawer = () => document.body.classList.add('open');
const closeDrawer = () => document.body.classList.remove('open');
function newChat() { if (busy) return; cur = null; pending = []; renderChips(); closeDrawer(); renderList(); renderChat(); $('#input').focus(); }

function fileToDataURL(f) { return new Promise((ok, no) => { const r = new FileReader(); r.onload = () => ok(r.result); r.onerror = no; r.readAsDataURL(f); }); }
async function shrink(f) { // تصغير الصور لتسريع الإرسال
  const url = await fileToDataURL(f); if (f.type === 'image/gif') return url;
  const img = await new Promise((ok, no) => { const i = new Image(); i.onload = () => ok(i); i.onerror = no; i.src = url; });
  const k = Math.min(1, 1600 / Math.max(img.width, img.height)); const cv = document.createElement('canvas');
  cv.width = img.width * k; cv.height = img.height * k; cv.getContext('2d').drawImage(img, 0, 0, cv.width, cv.height);
  return cv.toDataURL('image/jpeg', 0.85);
}
async function onFiles(files) {
  for (const f of files) {
    if (f.type.startsWith('image/')) { if (f.size > 8e6) { alert(T().big); continue; } pending.push({ name: f.name, image: await shrink(f) }); }
    else if (f.type.startsWith('text/') || /\.(txt|md|csv|json|js|ts|py|html|css|java|c|cpp|php|xml|log)$/i.test(f.name)) {
      if (f.size > 2e6) { alert(T().big); continue; } pending.push({ name: f.name, text: (await f.text()).slice(0, 60000) });
    } else alert(T().type);
  }
  renderChips();
}

async function send() {
  if (busy) return;
  const input = $('#input'); const text = input.value.trim();
  if (!text && !pending.length) return;
  if (!cur) { cur = { id: Date.now(), title: '', messages: [] }; convs.unshift(cur); }
  const images = pending.filter((p) => p.image).map((p) => p.image);
  const texts = pending.filter((p) => p.text);
  const content = [text, ...texts.map((p) => `\n\n[${T().file}: ${p.name}]\n\`\`\`\n${p.text}\n\`\`\``)].join('');
  const um = { role: 'user', content, shown: text, images, files: texts.map((p) => p.name) };
  if (!cur.title) cur.title = (text || pending[0]?.name || '').slice(0, 40);
  cur.messages.push(um);
  const am = { role: 'assistant', content: '' }; cur.messages.push(am);
  input.value = ''; input.style.height = 'auto'; pending = []; renderChips(); renderList(); renderChat();
  const chat = $('#chat'); const el = msgEl(am, true); chat.append(el); chat.scrollTop = chat.scrollHeight;
  const body = el.querySelector('.body');
  setBusy(true); ctrl = new AbortController();
  const payload = cur.messages.slice(0, -1).map((m) => ({ role: m.role, content: m.content, images: m.images }));
  try {
    const r = await fetch('/api/chat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ messages: payload }), signal: ctrl.signal });
    if (!r.ok) { const j = await r.json().catch(() => ({})); throw new Error(j.error || 'upstream'); }
    const rd = r.body.getReader(), dec = new TextDecoder(); let buf = '';
    for (;;) {
      const { done, value } = await rd.read(); if (done) break;
      buf += dec.decode(value, { stream: true }); const parts = buf.split('\n\n'); buf = parts.pop();
      for (const p of parts) {
        if (!p.startsWith('data: ')) continue; const d = p.slice(6); if (d === '[DONE]') continue;
        const j = JSON.parse(d); if (j.error) throw new Error(j.error);
        if (j.t) { am.content += j.t; body.innerHTML = md(am.content); chat.scrollTop = chat.scrollHeight; }
      }
    }
  } catch (e) {
    if (e.name !== 'AbortError') {
      const code = T().e[e.message] ? e.message : 'network';
      am.error = true; am.content = (am.content ? am.content + '\n\n' : '') + '⚠️ ' + T().e[code];
    }
  } finally {
    if (!am.content) cur.messages.splice(-2, 2);
    setBusy(false); ctrl = null; save(); renderList(); renderChat();
  }
}
function setBusy(b) { busy = b; const s = $('#send'); s.textContent = b ? '■' : '➤'; s.classList.toggle('stop', b); }

$('#send').onclick = () => (busy ? ctrl?.abort() : send());
$('#input').addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey && matchMedia('(hover:hover)').matches) { e.preventDefault(); send(); } });
$('#input').addEventListener('input', (e) => { e.target.style.height = 'auto'; e.target.style.height = Math.min(e.target.scrollHeight, 140) + 'px'; });
$('#attach').onclick = () => $('#file').click();
$('#file').onchange = (e) => { onFiles([...e.target.files]); e.target.value = ''; };
$('#newBtn').onclick = $('#newBtn2').onclick = newChat;
$('#menuBtn').onclick = openDrawer; $('#scrim').onclick = closeDrawer;
$('#langBtn').onclick = () => { lang = lang === 'ar' ? 'en' : 'ar'; store.set('sh.lang', lang); applyLang(); };
$('#chat').addEventListener('click', (e) => {
  if (!e.target.classList.contains('copy')) return;
  navigator.clipboard?.writeText(e.target.nextElementSibling.textContent); e.target.textContent = T().copied; setTimeout(() => (e.target.textContent = T().copy), 1200);
});
if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => {});
applyLang();
