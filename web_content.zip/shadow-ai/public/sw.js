const C = 'shadow-v1', SHELL = ['/', '/style.css', '/app.js', '/logo.svg', '/manifest.json'];
self.addEventListener('install', (e) => e.waitUntil(caches.open(C).then((c) => c.addAll(SHELL))));
self.addEventListener('activate', (e) => e.waitUntil(caches.keys().then((k) => Promise.all(k.filter((x) => x !== C).map((x) => caches.delete(x))))));
self.addEventListener('fetch', (e) => {
  const u = new URL(e.request.url);
  if (e.request.method !== 'GET' || u.pathname.startsWith('/api')) return;
  e.respondWith(fetch(e.request).then((r) => { caches.open(C).then((c) => c.put(e.request, r.clone())); return r; }).catch(() => caches.match(e.request)));
});
