import 'dotenv/config';
import express from 'express';
import OpenAI from 'openai';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT || 3000;
const MODEL = process.env.OPENAI_MODEL || 'gpt-4o-mini'; // يدعم النص والصور

if (!process.env.OPENAI_API_KEY) {
  console.error('❌ OPENAI_API_KEY غير موجود. عيّنه كمتغير بيئة أو في ملف .env');
  process.exit(1);
}
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const SYSTEM_PROMPT =
  'You are Shadow AI, a fast and precise assistant. Always reply in the language the user writes in ' +
  '(Arabic or English). Help with chat, writing, summarizing, explaining lessons, solving exercises step by step, ' +
  'and programming (use fenced code blocks). Be clear and concise.';

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '25mb' }));

// حدّ بسيط للطلبات (30 طلب/دقيقة لكل IP)
const hits = new Map();
app.use('/api', (req, res, next) => {
  const now = Date.now();
  const arr = (hits.get(req.ip) || []).filter((t) => now - t < 60_000);
  if (arr.length >= 30) return res.status(429).json({ error: 'rate_limit' });
  arr.push(now);
  hits.set(req.ip, arr);
  next();
});

function buildMessages(raw) {
  if (!Array.isArray(raw) || raw.length === 0) throw new Error('bad_request');
  return raw.slice(-40).map((m) => {
    const role = m.role === 'assistant' ? 'assistant' : 'user';
    const text = String(m.content || '').slice(0, 100_000);
    const images = role === 'user' && Array.isArray(m.images)
      ? m.images.filter((u) => typeof u === 'string' && /^data:image\/(png|jpe?g|webp|gif);base64,/.test(u)).slice(0, 4)
      : [];
    if (!images.length) return { role, content: text };
    return {
      role,
      content: [
        { type: 'text', text: text || 'Describe this image.' },
        ...images.map((url) => ({ type: 'image_url', image_url: { url } })),
      ],
    };
  });
}

function errorCode(e) {
  if (e?.message === 'bad_request') return [400, 'bad_request'];
  if (e?.status === 401) return [502, 'invalid_key'];
  if (e?.status === 429) return [429, 'quota'];
  if (e?.status === 400) return [400, 'bad_request'];
  if (e?.name === 'AbortError') return [499, 'aborted'];
  return [502, 'upstream'];
}

app.post('/api/chat', async (req, res) => {
  let messages;
  try { messages = buildMessages(req.body?.messages); }
  catch { return res.status(400).json({ error: 'bad_request' }); }

  const ac = new AbortController();
  res.on('close', () => { if (!res.writableFinished) ac.abort(); });

  try {
    const stream = await openai.chat.completions.create(
      { model: MODEL, stream: true, messages: [{ role: 'system', content: SYSTEM_PROMPT }, ...messages] },
      { signal: ac.signal }
    );
    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' });
    for await (const chunk of stream) {
      const t = chunk.choices?.[0]?.delta?.content;
      if (t) res.write(`data: ${JSON.stringify({ t })}\n\n`);
    }
    res.write('data: [DONE]\n\n');
    res.end();
  } catch (e) {
    const [status, code] = errorCode(e);
    console.error('OpenAI error:', e?.status, e?.message);
    if (res.headersSent) { res.write(`data: ${JSON.stringify({ error: code })}\n\n`); res.end(); }
    else res.status(status).json({ error: code });
  }
});

app.get('/api/health', (_req, res) => res.json({ ok: true, model: MODEL }));
app.use(express.static(path.join(__dirname, 'public')));

app.listen(PORT, '0.0.0.0', () => console.log(`✅ Shadow AI → http://localhost:${PORT}  (model: ${MODEL})`));
