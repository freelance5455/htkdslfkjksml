# V117 — Socle 1.6 : Coupe Lunaire AGD

## Audit historique V116
- Organisateur : AGD.
- Édition annuelle.
- Huit représentants galactiques : Astra Nova, Orion, Andromède, Nébula, Vega, Solarys, Éclipse et Lyris.
- Élimination directe : quarts de finale, demi-finales, finale.
- 4 + 2 + 1 = 7 rencontres ; aucune petite finale.
- Scheduler tardif V116 V92 : les rencontres sont placées dans le mois 12, sur trois créneaux internes espacés de sept jours. Le code calcule les offsets de saison 342, 349 et 356 ; V117 conserve ces offsets sans prétendre convertir les dates en jour lunaire civil.
- Les égalités sont départagées ; V117 utilise un hash déterministe à la place du hasard non reproductible du V116.
- Le manager peut choisir une galaxie à représenter ; sinon l'IA simule toutes les rencontres.

## Intégration V117
- Moteur dédié `src/lunar-cup.js`.
- Fixtures inscrites au calendrier central.
- Simulation IA par le moteur commun de dames.
- Match de la galaxie choisie jouable sur le damier 10×10.
- Progression automatique des quarts aux demi-finales puis à la finale.
- Palmarès annuel conservé dans l'état de carrière.
- Offsets internes V116 342, 349 et 356, conservés dans le calendrier de saison V117 et séparés de sept jours.
- Les conflits avec les dates officielles AGD bloquent la validation plutôt que de déplacer les dates officielles.

## Limites
- Les calendriers officiels FGD/AGD et les jeudis lunaires de la Coupe des Clubs doivent être fournis par les organismes.
- Les moteurs de la Coupe Intergalactique des galaxies, de l'Intergalactique des Clubs et de la Dame d'Or restent à intégrer.
- Tests navigateur/mobile réel non exécutés.
