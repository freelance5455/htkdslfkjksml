# Swap Player → Android APK (Capacitor)

## Requirements

- Node.js 18+ ([nodejs.org](https://nodejs.org))
- Android Studio ([developer.android.com/studio](https://developer.android.com/studio))
- Android SDK + a device/emulator

## Steps

```bash
# 1. Open this folder in a terminal
cd swap-capacitor

# 2. Install dependencies
npm install

# 3. Add the Android platform (first time only)
npx cap add android

# 4. Copy web files into the Android project
npx cap sync

# 5. Open in Android Studio
npx cap open android
```

In Android Studio:

1. Wait for Gradle sync to finish
2. **Build → Build Bundle(s) / APK(s) → Build APK(s)**
3. Install the APK on your phone (or run on an emulator)

## After you change the web app

```bash
npx cap sync
```

Then rebuild the APK in Android Studio.

## Optional: change package name / app name

Edit `capacitor.config.json`:

- `appId` → e.g. `com.yourname.swapplayer`
- `appName` → launcher name

Then run `npx cap sync` again.

## Notes

- Files stay inside the app (IndexedDB). Same storage behaviour as the browser version.
- For true background playback / lock-screen controls later, add Capacitor media plugins.
- First build downloads Gradle dependencies — can take several minutes.
