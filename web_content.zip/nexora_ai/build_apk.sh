#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v flutter >/dev/null 2>&1; then
  echo "ERROR: Flutter SDK nahi mila. Flutter install karke PATH me add karein."
  echo "Guide: https://docs.flutter.dev/get-started/install"
  exit 1
fi
if [[ ! -x android/gradlew ]]; then
  echo "Android platform files nahi mile. Flutter Android scaffolding generate kar raha hai..."
  flutter create --platforms=android --org com.zenit --project-name nexora_ai --no-pub .
fi
flutter pub get
flutter build apk --release
echo "APK: $(pwd)/build/app/outputs/flutter-apk/app-release.apk"
