# NEXORA AI backend — not implemented yet

This directory reserves a place for the secure API service. No working backend routes or AI provider integration are included in this starter package yet.

Planned implementation:
- Node.js + TypeScript + Express
- Request validation and rate limiting
- Provider adapter using server-side environment secrets
- Allowlisted tool execution
- Minimal privacy-conscious logging
- Tests for malformed requests and tool validation

Do not put provider API keys in Flutter assets, Dart files, or this repository.
