@echo off
setlocal
cd /d "%~dp0"
echo ==========================================
echo       NEXORA AI - Android APK Builder
echo ==========================================
where flutter >nul 2>nul
if errorlevel 1 (
  echo ERROR: Flutter SDK nahi mila. Flutter install karke PATH me add karein.
  echo Guide: https://docs.flutter.dev/get-started/install
  pause
  exit /b 1
)
if not exist "android\gradlew.bat" (
  echo Android platform files nahi mile. Flutter Android scaffolding generate kar raha hai...
  flutter create --platforms=android --org com.zenit --project-name nexora_ai --no-pub .
  if errorlevel 1 goto fail
)
flutter pub get
if errorlevel 1 goto fail
flutter build apk --release
if errorlevel 1 goto fail
echo.
echo SUCCESS! APK yahan milega:
echo %CD%\build\app\outputs\flutter-apk\app-release.apk
pause
exit /b 0
:fail
echo.
echo Build fail hua. Upar dikhaye gaye error ko check karein.
pause
exit /b 1
