import 'package:flutter/material.dart';
import '../features/home/home_screen.dart';

class NexoraApp extends StatelessWidget {
  const NexoraApp({super.key});

  static const Color background = Color(0xFF090B10);
  static const Color surface = Color(0xFF171C25);
  static const Color accent = Color(0xFF78A9FF);
  static const Color primaryText = Color(0xFFE7ECF4);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'NEXORA AI',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: background,
        colorScheme: const ColorScheme.dark(
          primary: accent,
          surface: surface,
          onSurface: primaryText,
          error: Color(0xFFFF7070),
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: background,
          foregroundColor: primaryText,
          elevation: 0,
          centerTitle: false,
        ),
        cardTheme: CardTheme(
          color: surface,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: const BorderSide(color: Color(0xFF2A303C)),
          ),
        ),
      ),
      home: const HomeScreen(),
    );
  }
}
