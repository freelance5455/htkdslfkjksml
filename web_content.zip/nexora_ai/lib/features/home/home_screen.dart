import 'package:flutter/material.dart';
import '../../app/nexora_app.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'NEXORA AI',
              style: TextStyle(
                fontWeight: FontWeight.w800,
                letterSpacing: 1.5,
              ),
            ),
            Text(
              'Created by Zenit',
              style: TextStyle(fontSize: 11, letterSpacing: 0.5),
            ),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Settings',
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Settings module is not implemented yet.'),
                ),
              );
            },
            icon: const Icon(Icons.settings_outlined),
          ),
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'BEYOND COMMANDS.\\nINTO INTELLIGENCE.',
                style: TextStyle(
                  color: NexoraApp.primaryText,
                  fontSize: 20,
                  fontWeight: FontWeight.w700,
                  height: 1.4,
                  letterSpacing: 1,
                ),
              ),
              const SizedBox(height: 28),
              Expanded(
                child: Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 172,
                        height: 172,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: const RadialGradient(
                            colors: [
                              Color(0xFF263E69),
                              Color(0xFF121C30),
                              Color(0xFF090B10),
                            ],
                          ),
                          border: Border.all(
                            color: NexoraApp.accent.withOpacity(0.7),
                            width: 1.5,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: NexoraApp.accent.withOpacity(0.15),
                              blurRadius: 36,
                              spreadRadius: 4,
                            ),
                          ],
                        ),
                        child: const Icon(
                          Icons.graphic_eq_rounded,
                          size: 72,
                          color: NexoraApp.accent,
                        ),
                      ),
                      const SizedBox(height: 24),
                      const Text(
                        'NEXORA CORE',
                        style: TextStyle(
                          fontWeight: FontWeight.w700,
                          letterSpacing: 2,
                        ),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        'Interface ready · Voice service not connected',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Colors.white60,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Row(
                        children: [
                          Icon(Icons.mic_none_rounded,
                              color: NexoraApp.accent),
                          SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              'VOICE ASSISTANT',
                              style: TextStyle(
                                fontWeight: FontWeight.w700,
                                letterSpacing: 1,
                              ),
                            ),
                          ),
                          Icon(Icons.circle,
                              size: 9, color: Colors.orangeAccent),
                          SizedBox(width: 6),
                          Text('Offline', style: TextStyle(fontSize: 12)),
                        ],
                      ),
                      const SizedBox(height: 12),
                      const Text(
                        'Voice activation will become available after '
                        'permissions and the native voice service are '
                        'configured.',
                        style: TextStyle(
                          color: Colors.white60,
                          height: 1.5,
                          fontSize: 13,
                        ),
                      ),
                      const SizedBox(height: 14),
                      SizedBox(
                        width: double.infinity,
                        child: OutlinedButton.icon(
                          onPressed: () {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text(
                                  'Voice service integration is the next step.',
                                ),
                              ),
                            );
                          },
                          icon: const Icon(Icons.mic),
                          label: const Text('VOICE SETUP'),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              const Center(
                child: Text(
                  'Created by Zenit  •  v0.1.0',
                  style: TextStyle(color: Colors.white38, fontSize: 11),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
