import 'package:flutter/material.dart';
import 'app/nexora_app.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const NexoraApp());
}
