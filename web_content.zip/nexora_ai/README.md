# NEXORA AI

**Beyond Commands. Into Intelligence.**  
Created by Zenit.

This folder contains the initial Flutter project foundation, not the complete assistant described in the master specification. The home screen is a starter UI; AI chat, background wake-word detection, Kotlin service, backend, and production APK are not implemented yet.

## Requirements
- Flutter SDK with Dart compatible with `pubspec.yaml`
- Android Studio / Android SDK
- A physical Android device for microphone and background-service testing

## Run
```bash
flutter doctor
flutter pub get
dart format lib test
flutter analyze
flutter test
flutter run
```

## Android project files
Generate platform scaffolding with Flutter if it is not present:
```bash
flutter create --org com.zenit --project-name nexora_ai .
```
Review generated files before overwriting anything. Android background microphone access requires version-specific permissions, a user-started foreground service, a visible notification, and runtime permission grants.

## Important status
- UI: starter home screen implemented
- Wake-word engine: not integrated; requires engine SDK, custom keyword model(s), and license/configuration
- AI backend: not implemented
- Chat, memory, tasks, web search, Android actions: not implemented
- APK: not built or tested in this environment

Never place private AI-provider keys in the mobile app. Configure secrets on a backend when that component is implemented.

## Build Android APK
For a guided build, see [`BUILD_APK_HINDI.md`](BUILD_APK_HINDI.md). On Windows, run `build_apk.bat`; on macOS/Linux, run `./build_apk.sh`. These scripts generate missing Android platform scaffolding with Flutter, fetch packages, and attempt a release build.
