import 'package:flutter_test/flutter_test.dart';
import 'package:nexora_ai/app/nexora_app.dart';

void main() {
  testWidgets('shows NEXORA AI branding and voice status', (tester) async {
    await tester.pumpWidget(const NexoraApp());

    expect(find.text('NEXORA AI'), findsOneWidget);
    expect(find.text('Created by Zenit'), findsOneWidget);
    expect(find.text('VOICE ASSISTANT'), findsOneWidget);
    expect(find.text('Offline'), findsOneWidget);
  });
}
