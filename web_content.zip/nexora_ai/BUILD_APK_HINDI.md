# NEXORA AI — Android APK banana (Hindi)

## Sabse aasaan tareeka (Windows)
1. Flutter SDK aur Android Studio install karein. Flutter ko PATH me add karein.
   Guide: https://docs.flutter.dev/get-started/install
2. ZIP ko extract karein aur `nexora_ai` folder kholein.
3. `build_apk.bat` par double-click karein. Script Android platform files na hone par Flutter se generate karne ki koshish karegi, dependencies download karegi aur release APK build karegi.
4. Successful build ke baad APK is path par milega:
   `build/app/outputs/flutter-apk/app-release.apk`

## macOS / Linux
Terminal me project folder ke andar:
```bash
chmod +x build_apk.sh
./build_apk.sh
```

## Zaroori baatein
- Is archive me Android Gradle project pehle se nahi tha; `android/` folder me sirf `.gitkeep` tha. Isliye build script Flutter se Android scaffolding generate karti hai.
- APK build karne ke liye Flutter SDK, Android SDK, internet/dependency access aur compatible Java/Gradle setup chahiye.
- Is environment me Flutter SDK available nahi tha, isliye APK compile ya test nahi kiya gaya. Script sirf build process ko taiyar karti hai; build successful hone ki guarantee nahi hai.
- Yeh starter project hai. AI chat/backend aur kuch planned features abhi implement nahi hain. APK banne par bhi wahi features chalenge jo code me maujood hain.
- Provider API keys ko app ke andar hard-code na karein; unhe secure backend par rakhein.
