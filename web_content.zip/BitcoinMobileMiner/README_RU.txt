BITCOIN MOBILE MINER — проект Android Studio

Это демонстрационный интерфейс, не настоящий майнер. Он не добывает BTC и не создаёт выплаты. Никогда не вводите seed-фразу или приватный ключ кошелька.

Сборка APK:
1. Распакуйте ZIP на компьютере.
2. Установите Android Studio с developer.android.com/studio
3. В Android Studio выберите Open и откройте папку BitcoinMobileMiner.
4. Дождитесь Gradle Sync.
5. Выберите Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK обычно находится в app/build/outputs/apk/debug/app-debug.apk

Исправление ошибки appassets: HTML хранится в app/src/main/assets/index.html и загружается внутри приложения через file:///android_asset/index.html, а не с внешнего сайта.
