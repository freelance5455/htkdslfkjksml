package com.bitcoin.mobileminer;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.view.View;
import android.graphics.Color;

public class MainActivity extends Activity {
 @Override public void onCreate(Bundle savedInstanceState) {
  super.onCreate(savedInstanceState);
  getWindow().setStatusBarColor(Color.rgb(18,18,18));
  getWindow().setNavigationBarColor(Color.rgb(18,18,18));
  WebView w = new WebView(this);
  w.setBackgroundColor(Color.rgb(18,18,18));
  w.setWebViewClient(new WebViewClient());
  w.setWebChromeClient(new WebChromeClient());
  w.getSettings().setJavaScriptEnabled(true);
  w.getSettings().setDomStorageEnabled(true);
  w.setOverScrollMode(View.OVER_SCROLL_NEVER);
  setContentView(w);
  w.loadUrl("file:///android_asset/index.html");
 }
}
