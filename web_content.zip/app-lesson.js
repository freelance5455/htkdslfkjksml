/* JOSTECH — AFFICHAGE COMPLET DU LECTEUR DE COURS */
function renderLessonView(d, discId, lvl, ls) {
  currentDiscId = discId; currentLevelNum = lvl; currentLessonId = ls.id;
  saveRecentLesson(d, lvl, ls);
  $("btn-back-to-disc").onclick = () => openDiscipline(discId, lvl);
  $("lesson-duration").textContent = ls.duration;
  $("lesson-breadcrumb").textContent = `${d.title} • Niveau ${lvl}`;
  $("lesson-title").textContent = ls.title;
  if ($("btn-lesson-quiz")) $("btn-lesson-quiz").onclick = () => {
    if (typeof QUIZZES !== "undefined" && typeof startQuiz === "function") {
      const m = QUIZZES.find(q => q.discId === discId && q.mode === "training") || QUIZZES.find(q => q.discId === discId);
      if (m) return startQuiz(m.id);
    }
    navigateTo("exams");
  };
  updateFavButton(ls.id);
  if ($("btn-fav-lesson")) $("btn-fav-lesson").onclick = () => { if (typeof toggleFavoriteLesson === "function") { toggleFavoriteLesson(d, lvl, ls); updateFavButton(ls.id); } };

  $("lesson-objectives-box").innerHTML = `<h4>Objectifs pédagogiques</h4><ul>${ls.objectives.map(o => `<li>${escapeHtml(o)}</li>`).join("")}</ul>`;
  $("lesson-prereq-box").innerHTML = `<h4>Prérequis</h4><ul>${ls.prerequisites.map(p => `<li>${escapeHtml(p)}</li>`).join("")}</ul>`;

  const secBox = $("lesson-sections"); secBox.innerHTML = "";
  ls.sections.forEach(sec => {
    const el = document.createElement("div");
    const bul = (sec.bullets && sec.bullets.length) ? `<ul style="margin-top:8px;">${sec.bullets.map(b => `<li>${escapeHtml(b)}</li>`).join("")}</ul>` : "";
    if (sec.type === "definition") { el.className = "lesson-box definition"; el.innerHTML = `<h4>Définition — ${escapeHtml(sec.term)}</h4>${renderParagraphsHtml(sec.text)}${bul}`; }
    else if (sec.type === "theory") { el.className = "lesson-box"; el.innerHTML = `<h4>${escapeHtml(sec.title)}</h4>${renderParagraphsHtml(sec.text)}${bul}`; }
    else if (sec.type === "example") { el.className = "lesson-box example"; el.innerHTML = `<h4>Exemple — ${escapeHtml(sec.title)}</h4>${renderParagraphsHtml(sec.text)}${bul}`; }
    else if (sec.type === "warning") { el.className = "lesson-box"; el.style.borderLeft = "4px solid #f59e0b"; el.innerHTML = `<h4>⚠ ${escapeHtml(sec.title)}</h4>${renderParagraphsHtml(sec.text)}${bul}`; }
    else if (sec.type === "table") {
      el.className = "lesson-box";
      el.innerHTML = `<h4>${escapeHtml(sec.title)}</h4><div class="table-wrap"><table class="lesson-table"><thead><tr>${sec.headers.map(h => `<th>${escapeHtml(h)}</th>`).join("")}</tr></thead><tbody>${sec.rows.map(r => `<tr>${r.map(c => `<td>${escapeHtml(c)}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`;
    } else if (sec.type === "code") {
      el.className = "code-card";
      const hd = document.createElement("div"); hd.className = "code-header";
      const sp = document.createElement("span"); sp.textContent = sec.lang;
      const bt = document.createElement("button"); bt.className = "copy-btn"; bt.textContent = "Copier"; bt.onclick = () => copyTextSafe(sec.code);
      hd.appendChild(sp); hd.appendChild(bt);
      const pre = document.createElement("pre"); pre.className = "code-pre"; pre.textContent = sec.code;
      el.appendChild(hd); el.appendChild(pre);
    }
    secBox.appendChild(el);
  });

  const exBox = $("lesson-exercise-box"); exBox.innerHTML = "";
  const exList = Array.isArray(ls.exercises) ? ls.exercises : (ls.exercise ? [ls.exercise] : []);
  exBox.style.display = exList.length ? "block" : "none";
  exList.forEach((ex, i) => {
    const w = document.createElement("div");
    if (i > 0) w.style.cssText = "margin-top:18px;padding-top:16px;border-top:1px solid var(--border-metal);";
    const eh = document.createElement("h4"); eh.textContent = ex.title || (exList.length > 1 ? `Exercice ${i + 1}` : "Exercice");
    const eq = document.createElement("div"); eq.style.marginBottom = "12px"; eq.innerHTML = renderParagraphsHtml(ex.question);
    const eb = document.createElement("button"); eb.className = "btn-secondary"; eb.textContent = "Voir le corrigé détaillé";
    const es = document.createElement("div"); es.className = "solution-box"; es.textContent = ex.solution;
    eb.onclick = () => { eb.textContent = es.classList.toggle("open") ? "Masquer le corrigé" : "Voir le corrigé détaillé"; };
    w.appendChild(eh); w.appendChild(eq); w.appendChild(eb); w.appendChild(es); exBox.appendChild(w);
  });

  $("lesson-summary-box").innerHTML = `<h4>Résumé à retenir</h4>${renderParagraphsHtml(ls.summary)}`;
  $("lesson-refs-box").innerHTML = `<h4>Références bibliographiques</h4><ul>${ls.references.map(r => `<li>${escapeHtml(r)}</li>`).join("")}</ul>`;
  updateCompleteButton(ls.id);
  $("btn-complete-lesson").onclick = () => toggleLessonComplete(ls.id);
  $("btn-report-error").onclick = () => openReportModal(ls);

  const seq = []; [1, 2, 3].forEach(l => { if (d.levels[l]) d.levels[l].chapters.forEach(c => c.lessons.forEach(x => seq.push({ l, x }))); });
  const idx = seq.findIndex(item => item.x.id === ls.id);
  $("btn-prev-lesson").disabled = idx <= 0;
  $("btn-prev-lesson").onclick = () => { if (idx > 0) openLesson(discId, seq[idx - 1].l, seq[idx - 1].x.id); };
  $("btn-next-lesson").disabled = idx < 0 || idx >= seq.length - 1;
  $("btn-next-lesson").onclick = () => { if (idx >= 0 && idx < seq.length - 1) openLesson(discId, seq[idx + 1].l, seq[idx + 1].x.id); };
  navigateTo("lesson");
}