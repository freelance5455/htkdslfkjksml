-- MARCO HUB initial Supabase schema
-- Run in Supabase SQL Editor. Review policies before production use.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  player_tag text unique not null default ('MH-' || upper(substr(replace(gen_random_uuid()::text,'-',''),1,8))),
  username text unique not null,
  avatar_url text,
  points integer not null default 0 check (points >= 0),
  xp integer not null default 0 check (xp >= 0),
  level integer not null default 1 check (level >= 1),
  wins integer not null default 0,
  losses integer not null default 0,
  created_at timestamptz not null default now()
);
create table if not exists public.user_roles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'player' check (role in ('player','admin'))
);
create table if not exists public.tournaments (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  game text not null,
  description text,
  starts_at timestamptz not null,
  max_players integer not null check (max_players >= 2),
  prize_points integer not null default 0,
  status text not null default 'registration' check (status in ('registration','in_progress','completed','cancelled')),
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);
create table if not exists public.tournament_participants (
  tournament_id uuid references public.tournaments(id) on delete cascade,
  player_id uuid references public.profiles(id) on delete cascade,
  seed integer,
  registered_at timestamptz not null default now(),
  primary key (tournament_id, player_id)
);
create table if not exists public.matches (
  id uuid primary key default gen_random_uuid(),
  tournament_id uuid references public.tournaments(id) on delete cascade,
  round_number integer not null default 1,
  player_one uuid references public.profiles(id),
  player_two uuid references public.profiles(id),
  score_one integer,
  score_two integer,
  winner_id uuid references public.profiles(id),
  status text not null default 'pending' check (status in ('pending','in_progress','completed')),
  scheduled_at timestamptz,
  created_at timestamptz not null default now()
);
create table if not exists public.challenges (
  id uuid primary key default gen_random_uuid(),
  challenger_id uuid not null references public.profiles(id) on delete cascade,
  challenged_id uuid not null references public.profiles(id) on delete cascade,
  game text not null,
  status text not null default 'pending' check (status in ('pending','accepted','rejected','completed','cancelled')),
  winner_id uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  check (challenger_id <> challenged_id)
);
create table if not exists public.friendships (
  requester_id uuid references public.profiles(id) on delete cascade,
  addressee_id uuid references public.profiles(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','accepted','rejected')),
  created_at timestamptz not null default now(),
  primary key (requester_id, addressee_id),
  check (requester_id <> addressee_id)
);
create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now()
);
create table if not exists public.conversation_members (
  conversation_id uuid references public.conversations(id) on delete cascade,
  user_id uuid references auth.users(id) on delete cascade,
  primary key (conversation_id,user_id)
);
create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references auth.users(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 4000),
  created_at timestamptz not null default now()
);
create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  kind text not null,
  title text not null,
  body text not null,
  read_at timestamptz,
  created_at timestamptz not null default now()
);
create table if not exists public.news (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  body text not null,
  published boolean not null default false,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);
create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references auth.users(id) on delete cascade,
  reported_user_id uuid references auth.users(id) on delete set null,
  details text not null,
  status text not null default 'open' check (status in ('open','reviewing','resolved','dismissed')),
  created_at timestamptz not null default now()
);

-- Profile creation on signup
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles(id, username)
  values(new.id, coalesce(new.raw_user_meta_data->>'username', 'player_' || substr(new.id::text,1,8)));
  insert into public.user_roles(user_id, role) values(new.id,'player');
  return new;
end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public as $$
  select exists(select 1 from public.user_roles where user_id = auth.uid() and role = 'admin');
$$;

-- Enable RLS
alter table public.profiles enable row level security;
alter table public.user_roles enable row level security;
alter table public.tournaments enable row level security;
alter table public.tournament_participants enable row level security;
alter table public.matches enable row level security;
alter table public.challenges enable row level security;
alter table public.friendships enable row level security;
alter table public.conversations enable row level security;
alter table public.conversation_members enable row level security;
alter table public.messages enable row level security;
alter table public.notifications enable row level security;
alter table public.news enable row level security;
alter table public.reports enable row level security;

-- Profiles: public read, owner/admin update
create policy "profiles readable" on public.profiles for select using (true);
create policy "profile owner update" on public.profiles for update using (auth.uid()=id or public.is_admin());
create policy "roles visible to self or admin" on public.user_roles for select using (auth.uid()=user_id or public.is_admin());
-- Never allow clients to grant themselves admin. Promote through SQL dashboard only.
create policy "tournaments public read" on public.tournaments for select using (true);
create policy "admin manage tournaments" on public.tournaments for all using (public.is_admin()) with check (public.is_admin());
create policy "participants visible" on public.tournament_participants for select using (true);
create policy "join as self" on public.tournament_participants for insert with check (auth.uid()=player_id);
create policy "admin manage participants" on public.tournament_participants for delete using (public.is_admin());
create policy "matches public read" on public.matches for select using (true);
create policy "admin manage matches" on public.matches for all using (public.is_admin()) with check (public.is_admin());
create policy "challenge participants read" on public.challenges for select using (auth.uid()=challenger_id or auth.uid()=challenged_id or public.is_admin());
create policy "send challenge" on public.challenges for insert with check (auth.uid()=challenger_id);
create policy "challenge receiver update" on public.challenges for update using (auth.uid()=challenged_id or public.is_admin());
create policy "friendship participants read" on public.friendships for select using (auth.uid()=requester_id or auth.uid()=addressee_id);
create policy "send friend request" on public.friendships for insert with check (auth.uid()=requester_id);
create policy "friend request receiver update" on public.friendships for update using (auth.uid()=addressee_id);
create policy "conversation member read" on public.conversations for select using (exists(select 1 from public.conversation_members cm where cm.conversation_id=id and cm.user_id=auth.uid()));
create policy "members read" on public.conversation_members for select using (user_id=auth.uid() or exists(select 1 from public.conversation_members cm where cm.conversation_id=conversation_id and cm.user_id=auth.uid()));
create policy "message member read" on public.messages for select using (exists(select 1 from public.conversation_members cm where cm.conversation_id=messages.conversation_id and cm.user_id=auth.uid()));
create policy "message member send" on public.messages for insert with check (sender_id=auth.uid() and exists(select 1 from public.conversation_members cm where cm.conversation_id=messages.conversation_id and cm.user_id=auth.uid()));
create policy "notification owner read" on public.notifications for select using (user_id=auth.uid() or public.is_admin());
create policy "notification owner update" on public.notifications for update using (user_id=auth.uid() or public.is_admin());
create policy "published news read" on public.news for select using (published=true or public.is_admin());
create policy "admin manage news" on public.news for all using (public.is_admin()) with check (public.is_admin());
create policy "report owner create" on public.reports for insert with check (reporter_id=auth.uid());
create policy "report owner/admin read" on public.reports for select using (reporter_id=auth.uid() or public.is_admin());
create policy "admin manage reports" on public.reports for update using (public.is_admin());

-- Enable realtime for chat messages from Dashboard > Database > Publications if not already enabled.
-- To promote the first administrator, run manually in SQL editor:
-- insert into public.user_roles(user_id, role) values ('AUTH-USER-UUID','admin')
-- on conflict (user_id) do update set role='admin';
