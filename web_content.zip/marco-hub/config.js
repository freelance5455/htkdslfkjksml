// ضع بيانات مشروع Supabase هنا بعد إنشائه. اترك القيم فارغة لتشغيل وضع المعاينة المحلي.
window.MARCO_CONFIG = {
  SUPABASE_URL: "",
  SUPABASE_ANON_KEY: ""
};