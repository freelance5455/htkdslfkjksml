# MARCO HUB

واجهة مجتمع ألعاب عربية RTL مبنية بـ HTML وCSS وJavaScript، ومهيأة للنشر على Netlify. تحتوي النسخة المرفقة على وضع معاينة محلي تفاعلي، ومخطط قاعدة بيانات Supabase لبدء تحويلها إلى منصة متعددة المستخدمين.

## 1) تشغيل محلي سريع
- فك ضغط `marco-hub.zip`.
- افتح `index.html` في متصفح حديث. الأفضل تشغيل خادم محلي (مثل VS Code Live Server) لأن التطبيق يستخدم JavaScript Modules.
- في وضع المعاينة، تُحفظ التغييرات في `localStorage` على نفس المتصفح والجهاز.

## 2) النشر على Netlify
1. أنشئ حساباً على https://www.netlify.com/
2. فك ضغط المشروع على جهازك.
3. من Netlify اختر **Add new site → Deploy manually**.
4. اسحب مجلد `marco-hub` (أو محتوياته) إلى منطقة الرفع.
5. بعد اكتمال النشر سيظهر رابط `*.netlify.app`.
6. عند تحديث الملفات، ارفع المجلد مرة أخرى أو اربط مستودع GitHub للنشر التلقائي.

ملف `netlify.toml` يحدد مجلد النشر وإعدادات أساسية للرؤوس.

## 3) إعداد قاعدة بيانات Supabase
1. أنشئ مشروعاً جديداً على https://supabase.com/
2. افتح **SQL Editor** وشغّل محتوى `supabase/schema.sql`.
3. من **Project Settings → API** انسخ Project URL و anon/public key.
4. ضع القيم في `config.js`:
   ```js
   window.MARCO_CONFIG = {
     SUPABASE_URL: "https://YOUR-PROJECT.supabase.co",
     SUPABASE_ANON_KEY: "YOUR-ANON-PUBLIC-KEY"
   };
   ```
5. في Supabase → Authentication → URL Configuration أضف رابط Netlify ضمن Site URL و Redirect URLs.
6. لتسجيل Google: فعّل Google provider في Authentication → Providers، وأدخل OAuth Client ID/Secret من Google Cloud.
7. لتسجيل الهاتف: فعّل Phone provider واضبط مزود SMS (مثل Twilio) وقوالب OTP. لا يكفي إدخال رقم الهاتف وحده.
8. فعّل Realtime لجدول `messages` من Database → Publications.
9. أنشئ حسابك أولاً، ثم خذ UUID الخاص به من Authentication → Users، ونفّذ ترقية المدير يدوياً من SQL Editor:
   ```sql
   insert into public.user_roles(user_id, role)
   values ('YOUR-AUTH-USER-UUID', 'admin')
   on conflict (user_id) do update set role='admin';
   ```

## 4) حدود النسخة الحالية — مهم
- الصفحات والتفاعلات الأساسية (التنقل، الثيمات، التسجيل التجريبي في البطولات، طلبات الصداقة، التحديات، النتائج، الأخبار، الإشعارات، ومحادثات المعاينة) تعمل محلياً وتحفظ في المتصفح.
- تسجيل الدخول بالبريد/Google يستعمل Supabase عند وضع مفاتيح المشروع. الهاتف يحتاج إعداد SMS وواجهة OTP إضافية قبل تفعيله.
- بقية بيانات الأقسام في هذه النسخة لا تزال تستخدم وضع المعاينة المحلي؛ وجود مخطط SQL لا يعني أن جميع العمليات متصلة تلقائياً بقاعدة البيانات. يلزم استكمال ربط CRUD وRealtime والتحقق من صلاحيات RLS قبل فتح التسجيل العام.
- قائمة أفضل 100 تعرض اللاعبين الفعليين الموجودين في بيانات المعاينة ثم صفوفاً توضيحية لإكمال شكل القائمة؛ ليست ترتيباً حقيقياً لـ100 حساب.
- لا يوجد نظام تحكيم آلي أو توليد bracket متكامل في هذه النسخة؛ جدول خروج المغلوب المعروض مثال واجهة.
- لا تضع أبداً `service_role` key في ملفات الواجهة أو في Netlify public assets. استخدم anon key فقط مع RLS، وأجرِ الإجراءات الإدارية الحساسة على خادم موثوق.
- قبل الإطلاق العام: اختبر سياسات RLS، التحقق من المدخلات، حدود التسجيل، منع النتائج المزيفة، حماية السبام، ومراجعة البلاغات.

## 5) بنية الملفات
- `index.html` — هيكل الواجهة وكل الأقسام.
- `styles.css` — التصميم المتجاوب والثيمات.
- `app.js` — التفاعلات ووضع المعاينة ومصادقة Supabase الأساسية.
- `config.js` — مفاتيح الاتصال العامة (فارغة افتراضياً).
- `supabase/schema.sql` — الجداول والعلاقات وسياسات RLS الأولية.
- `netlify.toml` — إعدادات النشر.
