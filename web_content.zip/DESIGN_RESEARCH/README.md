# OPUX design research reference set

## Included source

`OPUX_Design_Research_Reference_Book.pdf` is the design research reference supplied alongside the OPUX v1.4 project. It is retained as a separate project document, not placed in the Android runtime assets.

The document records:

- **43 design research topics** (pages 5–9), spanning Home composition, spatial interfaces, branch maps, View/Edit separation, time tracking, analytics, RDBD, motion, typography, navigation, accessibility and performance.
- **66 product/platform references** (pages 12–15), across knowledge management, health, time tracking, calendars, journaling, creative tools, finance, interactive websites and design-reference libraries.
- **12 named visual-reference entries** (pages 10–11): Apple Fitness, Structured, Obsidian, Linear, Notion, Forest, Spotify Wrapped, Notion screen library, Mobbin, Apple Design Awards, Rive and Appetite UI.
- A reference-capture template (page 17) and source register (pages 18–19).

## Evidence limitation found during inspection

The PDF's visual gallery pages are **link directories**, not embedded screenshot sheets. Each named example has a link labelled as a screenshot/interface gallery and a separate source-context link, but the PDF itself does not contain the screenshots. This project therefore does not claim that 12 screenshots were locally captured or that every listed product was hands-on inspected. Use the links in the PDF to open the original visual evidence and retain each source's attribution and terms.

The PDF is a useful research index, not proof that every listed product or interaction was verified. The app redesign uses it as design direction and preserves that distinction.

## Design principles carried into this implementation

1. Home should have a clear visual focal point, live state and secondary modules rather than equal-weight cards.
2. Branch is a spatial map with an overview, focus and a deliberate editing session.
3. View mode should be presentation-first; edit mode should expose controls only when requested and provide Save/Cancel.
4. RDBD remains a daily continuity record, with an interruptible quote sequence rather than becoming a generic quote feed.
5. Motion, depth and custom typography must support hierarchy and orientation; reduced-motion and legibility remain important.
6. Tracker totals, time records and derived statistics remain tied to stored records, not illustrative values.

## Three.js evaluation

The supplied archive identifies itself as Three.js **0.187.0** and contains the MIT license, package metadata, `build/three.module.js` and `build/three.core.js`. It does not include the examples/addons tree or a pre-bundled standalone browser script.

The current Android shell loads the app from `file:///android_asset/index.html`. The supplied HTML is a local-file WebView app and the shell does not currently use AndroidX WebKit's `WebViewAssetLoader`. Loading an ES module and its local imports from this file origin would require a deliberate WebView asset-origin strategy and device testing. Enabling broad file-URL cross-origin access just to make Three.js work would be an avoidable security trade-off.

**Decision:** Three.js was inspected but not integrated in this pass. The Branch experience uses the existing interactive SVG graph, now presented inside a layered spatial stage with camera navigation, focus, node depth cues and separate edit state. This keeps the project offline and avoids shipping an unused 2 MB library. A future Three.js integration should use a properly configured local asset origin, a measured Android performance budget and a tested static fallback.

## Custom typefaces

The app bundles Lato Regular/Bold/Heavy and DejaVu Serif for display use. Their license/copyright files are included alongside the font assets under `app/src/main/assets/fonts/`. Bangla and other unsupported glyphs fall back to Android's system font stack; the bundled Latin fonts are not represented as full-script coverage.
