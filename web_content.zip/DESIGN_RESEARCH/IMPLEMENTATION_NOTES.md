# Design implementation notes — OPUX 2.0 pass

## Implemented in this pass

- Home's live-day hero composition uses actual tracker totals, a compact spatial orb and a clear identity/status hierarchy. The Branch Library and More directory now use matching spatial/editorial layouts while preserving their existing navigation actions.
- The Branch workspace opens in View Mode. Editing is explicit; node details are read-only in View Mode. Edit Mode exposes layout, add-node and node-edit controls. Changes are held in memory until Save; Cancel restores the original branch snapshot.
- RDBD opens as a presentation-first daily page. Quote progression is automatic at seven-second intervals, supports swipe and arrow navigation, and pauses while the user interacts or the document is hidden. Entry/season management is behind Edit RDBD.
- Date display defaults to `October 30, 2026 (Fri)` style and can be changed to `30 OCT 2026` in Settings. Weekday text is computed from the date. Existing 12/24-hour time selection remains available.
- Lato and DejaVu Serif are bundled locally; the startup visual has been restyled to the dark OPUX palette.
- Design research is kept in this folder and outside Android runtime assets.

## Preserved foundation

- Original `h24v1` storage key and existing day/activity data structure.
- Existing tracker board, timer, activity calculations, statistics, history, records, branches, attachments, sound settings, themes and backup import/export code paths.
- Optional `ext` data continues to be sanitised through the existing migration path; the new date-format preference is optional and defaults safely for older backups.

## Verification performed here

- JavaScript syntax check with Node.js: passed.
- Headless Chromium test using a synthetic seeded legacy-format tracker dataset: Home, Branch View Mode, Branch Edit Mode, Branch Cancel restoration, date-format setting, RDBD presentation mode and RDBD edit entry were exercised; zero page errors and zero console errors were observed. The 7-second RDBD auto-advance was allowed to elapse and the quote changed; the timer was confirmed paused in edit mode. A render sweep across Tracker, Stats, History, Records, More, Settings, Sounds, Themes and Branch Library also completed without exceptions.
- Visual screenshots were inspected at a 390 × 844 viewport for Home, Branch and RDBD.

## Not verified

- Android Gradle compilation or APK generation. This environment does not have an Android SDK, Gradle executable or Gradle wrapper in the supplied project.
- Real-device WebView rendering, file chooser/export callbacks, haptics, tilt sensor, audio, long-branch performance, font fallback on Bangla text, low-end-device frame rate or data migration against the user's private backup.
- Three.js is not integrated; see `README.md` for the compatibility decision.
