# Electricity Service — Android source project

Package: `com.venkatesh.electricityservice`
App label: `Electricity Service`

This is Android source code, not a compiled APK. The latest provided HTML prototype is included at `app/src/main/assets/index.html`.

## Build APK
1. Open this folder in Android Studio on a computer with internet access.
2. Install Android SDK Platform 35 and the Android Gradle plugin requirements when prompted.
3. Allow Gradle sync to finish.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK location, usually `app/build/outputs/apk/debug/app-debug.apk`.

This environment did not have Android SDK/Gradle available, so no APK has been compiled or tested here. The prototype stores records locally on the device and is not connected to official electricity-board servers.
