
function toggleV44SalesPanel(){
 const box=document.getElementById('v44SalesPanel');
 const rows=document.getElementById('v44SalesRows');
 if(!box||!rows)return;
 const open=box.style.display!=='none';
 if(open){box.style.display='none';return;}
 const now=Date.now();
 const cutoff=now-24*60*60*1000;
 const sells=(S.trades||[]).filter(t=>{
   const type=String(t.type||'').toUpperCase();
   if(!(type==='SELL' || type.includes('VENDA'))) return false;
   const raw=t.time||t.ts||t.date||t.timestamp||t.createdAt;
   const tm=typeof raw==='number' ? (raw<10000000000?raw*1000:raw) : Date.parse(raw||'');
   return Number.isFinite(tm) && tm>=cutoff && tm<=now;
 }).slice().reverse();
 if(!sells.length){
   rows.innerHTML='<div class="sub">Ainda não existem moedas vendidas.</div>';
 }else{
   rows.innerHTML=sells.map(t=>{
     const coin=String(t.symbol||'').replace('USDT','');
     const p=Number(t.profit||0);
     const cls=p>=0?'good':'bad', sign=p>=0?'+':'';
     return '<div class="v44-sale-row"><b>'+esc(coin)+'</b><span class="v44-sale-profit '+cls+'">'+sign+money(p)+'</span></div>';
   }).join('');
 }
 box.style.display='block';
 box.scrollIntoView({behavior:'smooth',block:'nearest'});
}
