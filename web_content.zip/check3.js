
function toggleV44SalesPanel(){
 const box=document.getElementById('v44SalesPanel');
 const rows=document.getElementById('v44SalesRows');
 if(!box||!rows)return;
 const open=box.style.display!=='none';
 if(open){box.style.display='none';return;}
 const now=Date.now();
 const cutoff=now-24*60*60*1000;
 const sells=(S.trades||[]).filter(t=>{
   const type=String(t.type||'').toUpperCase();
   if(!(type==='SELL' || type.includes('VENDA'))) return false;
   const raw=t.time||t.ts||t.date||t.timestamp||t.createdAt;
   const tm=typeof raw==='number' ? (raw<10000000000?raw*1000:raw) : Date.parse(raw||'');
   return Number.isFinite(tm) && tm>=cutoff && tm<=now;
 }).slice().reverse();
 if(!sells.length){
   rows.innerHTML='<div class="sub">Ainda não existem moedas vendidas.</div>';
 }else{
   rows.innerHTML=sells.map(t=>{
     const coin=String(t.symbol||'').replace('USDT','');
     const p=Number(t.profit||0);
     const cls=p>=0?'good':'bad', sign=p>=0?'+':'';
     const rawTime=t.time||t.ts||t.date||t.timestamp||t.createdAt;
     const saleMs=typeof rawTime==='number' ? (rawTime<10000000000?rawTime*1000:rawTime) : Date.parse(rawTime||'');
     const saleTime=Number.isFinite(saleMs)?new Date(saleMs).toLocaleTimeString('pt-PT',{hour:'2-digit',minute:'2-digit'}):'—';
     const rawMax=t.peak??t.maxAfterBuy??t.maxPriceAfterBuy??t.maxPrice??t.highAfterBuy??t.maxHigh??t.peakPrice??t.high??t.max;
     const maxNum=Number(rawMax);
     const maxPrice=Number.isFinite(maxNum)&&maxNum>0 ? money(maxNum) : '—';
     return '<div class="v44-sale-row"><b>'+esc(coin)+'</b><span class="v44-sale-time">'+saleTime+'</span><span class="v44-sale-max">'+maxPrice+'</span><span class="v44-sale-profit '+cls+'">'+sign+money(p)+'</span></div>';
   }).join('');
 }
 box.style.display='block';
 box.scrollIntoView({behavior:'smooth',block:'nearest'});
}
