
/* Movable sticky-note stickers for note pages and mind maps. Stored independently so they survive reloads. */
(function(){
 const $=id=>document.getElementById(id), STORE='wildnotes-page-stickers-v1';
 function read(){try{return JSON.parse(localStorage.getItem(STORE)||'{}')}catch(e){return {}}}
 function write(d){try{localStorage.setItem(STORE,JSON.stringify(d))}catch(e){alert('Sticker could not be saved: browser storage is full.')}}
 function key(kind){if(kind==='note')return 'note:'+(( $('noteTitle')?.value||'Untitled note').trim())+':'+($('noteFolder')?.value||'');return 'map:'+(( $('mapTitle')?.value||$('mapName')?.value||'Mind map').trim())}
 function layer(kind){if(kind==='note')return $('notePageWrap');let c=$('mapCanvas');return c?.parentElement}
 function load(kind){let host=layer(kind);if(!host)return;let old=host.querySelectorAll('.wn-sticker');old.forEach(x=>x.remove());let d=read(),items=d[key(kind)]||[];items.forEach(item=>make(kind,item,false))}
 function save(kind){let host=layer(kind);if(!host)return;let d=read();d[key(kind)]=Array.from(host.querySelectorAll('.wn-sticker')).map(el=>({text:el.querySelector('textarea').value,left:parseFloat(el.style.left)||12,top:parseFloat(el.style.top)||12,color:el.dataset.color||'#fff2a8'}));write(d)}
 function make(kind,item={},persist=true){let host=layer(kind);if(!host)return;host.style.position='relative';let el=document.createElement('div');el.className='wn-sticker';el.dataset.color=item.color||'#fff2a8';el.style.cssText=`position:absolute;z-index:20;left:${item.left??18}px;top:${item.top??18}px;width:150px;min-height:120px;background:${el.dataset.color};box-shadow:0 3px 10px #0003;border:1px solid #d8c96c;border-radius:5px;padding:6px;touch-action:none;`;
 let bar=document.createElement('div');bar.style.cssText='display:flex;justify-content:space-between;align-items:center;cursor:move;font:12px system-ui;color:#514b2d;margin-bottom:4px';bar.innerHTML='<strong>Sticky note</strong>';
 let close=document.createElement('button');close.type='button';close.textContent='×';close.style.cssText='border:0;background:transparent;font-size:18px;padding:0 5px;color:#514b2d';bar.appendChild(close);
 let ta=document.createElement('textarea');ta.placeholder='Write a quick reminder…';ta.value=item.text||'';ta.style.cssText='width:100%;height:82px;resize:vertical;border:0;outline:0;background:transparent;color:#38352b;font:13px/1.4 system-ui;';
 let colors=document.createElement('select');colors.style.cssText='width:100%;font-size:11px;border:0;background:#ffffff80';[['#fff2a8','Butter'],['#d8f0e7','Mint'],['#dceaff','Blue'],['#f8dce8','Pink']].forEach(([v,t])=>{let o=document.createElement('option');o.value=v;o.textContent=t;if(v===el.dataset.color)o.selected=true;colors.appendChild(o)});
 el.append(bar,ta,colors);host.appendChild(el);close.addEventListener('click',()=>{el.remove();save(kind)});ta.addEventListener('input',()=>save(kind));colors.addEventListener('change',()=>{el.dataset.color=colors.value;el.style.background=colors.value;save(kind)});
 let drag=null;bar.addEventListener('pointerdown',e=>{if(e.target===close)return;drag={x:e.clientX,y:e.clientY,l:el.offsetLeft,t:el.offsetTop};bar.setPointerCapture(e.pointerId);e.preventDefault()});bar.addEventListener('pointermove',e=>{if(!drag)return;let r=host.getBoundingClientRect();el.style.left=Math.max(0,Math.min(r.width-el.offsetWidth,drag.l+e.clientX-drag.x))+'px';el.style.top=Math.max(0,Math.min(r.height-el.offsetHeight,drag.t+e.clientY-drag.y))+'px'});['pointerup','pointercancel','lostpointercapture'].forEach(ev=>bar.addEventListener(ev,()=>{if(drag){drag=null;save(kind)}}));if(persist)save(kind)
 }
 $('addNoteSticker')?.addEventListener('click',()=>{make('note');});$('addMapSticker')?.addEventListener('click',()=>{make('map')});
 $('noteTitle')?.addEventListener('change',()=>load('note'));$('noteFolder')?.addEventListener('change',()=>load('note'));
 document.querySelectorAll('.navbtn[data-page="notes"]').forEach(b=>b.addEventListener('click',()=>setTimeout(()=>load('note'),80)));
 document.querySelectorAll('.navbtn[data-page="mindmaps"]').forEach(b=>b.addEventListener('click',()=>setTimeout(()=>load('map'),100)));
 const mapPage=$('mindmaps');if(mapPage){new MutationObserver(()=>{if(mapPage.classList.contains('active'))load('map')}).observe(mapPage,{attributes:true,attributeFilter:['class']})}
 const notePage=$('notes');if(notePage){new MutationObserver(()=>{if(notePage.classList.contains('active'))load('note')}).observe(notePage,{attributes:true,attributeFilter:['class']})}
})();
