const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');

test('data files load and contain unique, usable puzzle records', () => {
  const context = { window: {} };
  vm.runInNewContext(read('js/data.js'), context);
  for (const key of ['UX_CASES', 'UX_PUZZLES']) {
    const rows = context.window[key];
    assert.ok(Array.isArray(rows) && rows.length > 0, `${key} should be populated`);
    assert.equal(new Set(rows.map(row => row.id)).size, rows.length, `${key} IDs should be unique`);
    assert.ok(rows.every(row => row.id && row.title && row.question), `${key} rows need core fields`);
  }
  assert.ok(context.window.UX_PUZZLES.length >= 5, 'Arena needs at least five puzzles');
});

test('app shell contains every navigation target and local scripts', () => {
  const html = read('index.html');
  const app = read('js/app.js');
  for (const page of ['dashboard','world','cases','puzzles','escape','city','investigation','boss','story','arena','shop','archive','creator','notes','achievements','progress','settings']) {
    assert.match(html, new RegExp(`data-page=["']${page}["']`), `missing navigation page ${page}`);
    assert.match(app, new RegExp(`${page}\\s*:`), `missing page renderer ${page}`);
  }
  for (const file of ['css/style.css','js/data.js','js/app.js','manifest.json','sw.js']) {
    assert.ok(fs.existsSync(path.join(root, file)), `missing ${file}`);
  }
});

test('arena timer formats minutes and seconds rather than showing 01:90', () => {
  const app = read('js/app.js');
  assert.match(app, /Math\.floor\(seconds\/60\)/);
  assert.match(app, /seconds%60/);
  assert.doesNotMatch(app, /01:\$\{String\(seconds\)\.padStart/);
});

test('manifest is valid and declares the app icon', () => {
  const manifest = JSON.parse(read('manifest.json'));
  assert.equal(manifest.version, '12.0.0');
  assert.ok(manifest.icons.some(icon => icon.src === 'assets/unknown-x-mark.svg'));
});

test('V7.2 backup import is available from settings and app branding is updated', () => {
  const app = read('js/app.js');
  const html = read('index.html');
  assert.match(app, /id="importBtn"/);
  assert.match(app, /id="importFile"/);
  assert.match(app, /Fisher-Yates/);
  assert.match(html, /NEON MYSTERY UNIVERSE/);
  assert.match(html, /REVOX STUDIO/);
});


test('V7.3 progress center is registered and uses existing local progress data', () => {
  const app = read('js/app.js');
  const html = read('index.html');
  assert.match(html, /data-page="progress"/);
  assert.match(app, /progress:"مركز التقدم"/);
  assert.match(app, /function progress\(\)/);
  assert.match(app, /state\.challengeRuns/);
  assert.match(app, /state\.dailyCompleted/);
});


test('V8 Living World is wired with daily events and persisted choices', () => {
  const app = read('js/app.js');
  const html = read('index.html');
  assert.match(html, /data-page="world"/);
  assert.match(app, /function world\(\)/);
  assert.match(app, /data-world-choice/);
  assert.match(app, /state\.worldChoices/);
  assert.match(app, /state\.worldRep/);
  assert.match(app, /state\.worldChoices=d\.worldChoices/);
  assert.match(app, /unknownx_v1/);
});


test('V9 Parallel Universe includes five gated worlds and local custom-world creator', () => {
  const app = read('js/app.js');
  const html = read('index.html');
  assert.match(html, /data-page="multiverse"/);
  assert.match(app, /function multiverse\(\)/);
  assert.match(app, /function openUniverse\(id\)/);
  assert.match(app, /universeVisits/);
  assert.match(app, /universeSolved/);
  assert.match(app, /customUniverses/);
  assert.match(app, /data-universe/);
  assert.match(app, /id="createUniverse"/);
  assert.match(app, /unknownx_v1/);
});


test('V10 interactive Orion city renders a clickable image map with four local missions', () => {
  const app = read('js/app.js');
  const css = read('css/style.css');
  const sw = read('sw.js');
  assert.match(app, /function city\(\)/);
  assert.match(app, /orion-city\.svg/);
  assert.match(app, /data-zone=/);
  assert.match(app, /function startCityMission\(id\)/);
  assert.match(app, /cityMissions/);
  assert.match(css, /\.city-hotspot/);
  assert.match(sw, /orion-city\.svg/);
  assert.equal(require('fs').existsSync(require('path').join(__dirname, '../assets/orion-city.svg')), true);
});


test('V11 Living City includes daily events, interactive citizens and upgradeable HQ persistence', () => {
  const app = read('js/app.js');
  assert.match(app, /cityCredits/);
  assert.match(app, /cityEventClaimed/);
  assert.match(app, /data-city-npc/);
  assert.match(app, /upgradeCity/);
  assert.match(app, /THE LIVING CITY|LIVING CITY/);
});


test('V12 daily city expeditions render three rotating contracts with persistent once-per-day rewards', () => {
  const app = read('js/app.js');
  const css = read('css/style.css');
  const sw = read('sw.js');
  assert.match(app, /cityContractBoard\(\)/);
  assert.match(app, /function startCityContract\(id\)/);
  assert.match(app, /data-city-contract/);
  assert.match(app, /cityContractClaims/);
  assert.match(app, /state\.cityCredits\+=15/);
  assert.match(app, /state\.xp\+=12/);
  assert.match(app, /claims\.includes\(id\)/);
  assert.match(css, /\.city-contract-grid/);
  assert.match(sw, /unknown-x-offline-v12\.0/);
});
