SKYCRASH APKFORGE PACKAGE - REVIEWED

Upload this ZIP using APKForge HTML ZIP option. index.html is at ZIP root.
Contains the actual SkyCrash game, not a redirect-only stub.
The game includes Firebase config, Google sign-in, UID balance listener, and latest reference-only I Have Paid deposit form.

IMPORTANT LIMITATION: APKForge WebView may not support Firebase Google OAuth. The game code detects embedded Android WebView and reports that Google sign-in requires Chrome or a Chrome Custom Tab. No HTML ZIP alone can guarantee Google login in APKForge.
For reliable Google login, use a native Android wrapper with supported external browser auth/deep-link return, or Chrome browser PWA, after testing.

Balance updates require the SAME signed-in Google UID as admin, valid Firebase RTDB rules, and a network connection.
Deposit and withdrawal requests require live Firebase permissions and must be tested end-to-end.

APKForge settings: upload ZIP; do not upload Android Studio project. Do not select an offline-only mode; permit network access.

DO NOT publish admin.html in a public game APK unless required. Admin access must be protected by Firebase security rules.
