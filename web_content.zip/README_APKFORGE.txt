MONEY TRACKER — APKForge project
=================================

This is an offline-first mobile web project intended to be wrapped into an Android APK using APKForge.

FILES
-----
index.html  Main app structure
style.css   Black/red mobile interface
app.js      App logic and local data storage

BUILD
-----
1. Keep index.html, style.css and app.js together in the same project folder.
2. In APKForge, choose the option to create an Android app from an HTML/CSS/JavaScript project or upload a ZIP project.
3. Upload this ZIP (or select index.html as the entry file if APKForge asks).
4. Set the app name to: Money Tracker
5. Set package ID if requested: com.moneytracker.personal
6. Set orientation: Portrait.
7. Enable local/offline assets and JavaScript.
8. Build and install the APK.

DATA & BACKUP
-------------
Daily records, monthly expenses, EMIs and savings goals are stored in localStorage on the device/app webview.
Use Settings > Export backup (JSON) regularly. To move data to another phone, export JSON on the old phone and import it on the new phone.
Clearing app storage or uninstalling the app may erase local data.

IMPORTANT
---------
- No bank, Swiggy, Zomato, Rapido, Uber or other platform account is connected. Entries are manual.
- "Friend repayment" is recorded as money received, not delivery earnings.
- Daily operating expenses and monthly fixed commitments are shown separately to avoid automatic double counting.
- Monthly fixed expense "paid" status and EMI paid status are tracking markers; they do not automatically subtract from daily reports.
- This project is a functional first version. Test the APK on your phone before relying on it for financial records.
