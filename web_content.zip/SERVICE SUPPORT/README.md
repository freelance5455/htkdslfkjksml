# SERVICE SUPPORT

Ready-to-build Android Studio project wrapping the supplied SERVICE SUPPORT web app in an Android WebView.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
4. APK output: `app/build/outputs/apk/debug/app-debug.apk`

Application ID: `com.servicesupport.app`
Version: 1.0
Min SDK: 23
Target SDK: 35
