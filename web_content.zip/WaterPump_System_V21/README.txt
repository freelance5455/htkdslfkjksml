Water Pump System V21

UG AUTO TIMER: uses configured interval for automatic attempts.
UG WATER SENSOR AUTO: ignores interval timer and starts when main-line pressure sensor detects water, subject to tank level and safety.
OH AUTO: overhead automatic mode.
Calibration remains browser-only on ESP32.
