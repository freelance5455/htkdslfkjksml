WATER PUMP SYSTEM V22
======================

Underground AUTO now has two independent triggers that can be used separately or together:
1) UNDERGROUND AUTO TIMER
2) WATER SENSOR AUTO
3) Both ON together = TIMER + SENSOR AUTO

If both are ON, either trigger may start the pump. If the timer is waiting or in its check cycle and the main-line pressure sensor detects water, the sensor trigger can start the pump immediately. The existing 2-wire water detector remains the timer attempt confirmation.

Overhead AUTO remains mutually exclusive with Underground AUTO because the pump/valves are common.
Calibration remains browser + PIN protected on the ESP32.
