/*
  ================================================================
  WATER PUMP SYSTEM - ESP32 DEV
  SAFETY FIRMWARE V2
  ================================================================
  Hardware assumed from the current PCB plan:

    HX710 Underground DOUT  -> GPIO 32
    HX710 Overhead DOUT     -> GPIO 33
    HX710 Main Pressure     -> GPIO 34
    HX710 shared SCK        -> GPIO 25
    2-wire Water Detector   -> GPIO 27
    Pump Relay              -> GPIO 26
    Underground Valve       -> GPIO 14
    Overhead Valve          -> GPIO 12

  Relay logic: ACTIVE LOW
  Water detector: ACTIVE LOW

  IMPORTANT:
  - Confirm every GPIO against the actual PCB before powering a real pump.
  - Test with the pump disconnected first.
  - This firmware provides software safety; it cannot detect a welded relay,
    broken valve, dry electrical contact, over-current, or over-temperature
    unless those sensors are physically installed.
  ================================================================
*/

#include <WiFi.h>
#include <WebServer.h>
#include <Preferences.h>

WebServer server(80);
Preferences prefs;

// ---------------- CALIBRATION SECURITY ----------------
// Calibration is intentionally NOT available from the mobile app.
// It can only be performed from the ESP32 browser page after PIN login.
const char* CALIBRATION_PIN = "2580"; // Change this PIN before deployment.
bool calibrationUnlocked = false;
unsigned long calibrationUnlockUntil = 0;
const unsigned long CAL_SESSION_MS = 10UL * 60UL * 1000UL;

bool calibrationSessionOK() {
  if (!calibrationUnlocked) return false;
  if ((long)(millis() - calibrationUnlockUntil) >= 0) {
    calibrationUnlocked = false;
    return false;
  }
  return true;
}

// --------------------------- PIN MAP ---------------------------
const uint8_t HX_UG_DOUT     = 32;
const uint8_t HX_OH_DOUT     = 33;
const uint8_t HX_MAIN_DOUT   = 34;
const uint8_t HX_SCK         = 25;
const uint8_t WATER_DETECT   = 27;
const uint8_t PUMP_RELAY     = 26;
const uint8_t UG_VALVE       = 14;
const uint8_t OH_VALVE       = 12;

// ------------------------ ELECTRICAL LOGIC ---------------------
const uint8_t RELAY_ON  = LOW;
const uint8_t RELAY_OFF = HIGH;
const uint8_t WATER_ACTIVE = LOW;

// ------------------------ HARD LIMITS --------------------------
const uint32_t SENSOR_TIMEOUT_MS = 250;
const uint32_t SENSOR_STALE_MS   = 3000;
const uint32_t WATER_STABLE_MS   = 1000;
const float MAIN_FULL_BAR        = 5.0f; // change if your transducer is not 0..5 bar

// ---------------------- USER SETTINGS --------------------------
float ugOn = 20.0f;
float ugOff = 100.0f;
float ugLow = 10.0f;
float ohOn = 50.0f;
float ohOff = 100.0f;
float minPressureBar = 0.50f;
uint16_t retryMin = 15;
uint16_t waterCheckSec = 30;
uint16_t manualMin = 15;
bool manualEmergencyBypass = true;

// ----------------------- CALIBRATION ---------------------------
// Tank calibration supports increasing OR decreasing HX710 raw values.
long ugCal[5] = {0, 0, 0, 0, 0}; // 0,25,50,75,100
long ohCal[5] = {0, 0, 0, 0, 0};
// Main pressure calibration: raw at 0 bar and raw at MAIN_FULL_BAR.
long mainRaw0 = 0;
long mainRawFull = 0;

// ------------------------ RUNTIME ------------------------------
enum AutoMode { AUTO_NONE, AUTO_UG_TIMER, AUTO_UG_SENSOR, AUTO_UG_BOTH, AUTO_OH };
AutoMode autoMode = AUTO_NONE;

enum ManualRoute { MANUAL_UG, MANUAL_OH };
ManualRoute manualRoute = MANUAL_UG;

bool pumpOn = false;
unsigned long manualUntil = 0;
unsigned long retryUntil = 0;
unsigned long ugTimerStart = 0;
unsigned long ugCheckStart = 0;
bool ugWaterConfirmed = false;

String lastError = "";
unsigned long lastGoodUG = 0;
unsigned long lastGoodOH = 0;
unsigned long lastGoodMain = 0;

// Cached sensor values so one slow HX710 does not freeze control logic.
float ugLevelPct = -1.0f;
float ohLevelPct = -1.0f;
float mainPressureBar = -1.0f;
bool waterDetected = false;

// ------------------------ UTILITIES ----------------------------
String activeModeText() {
  if (autoMode == AUTO_UG_BOTH) return "UNDERGROUND TIMER + SENSOR AUTO ACTIVE";
  if (autoMode == AUTO_UG_TIMER) return "UNDERGROUND AUTO TIMER ACTIVE";
  if (autoMode == AUTO_UG_SENSOR) return "UNDERGROUND WATER SENSOR AUTO ACTIVE";
  if (autoMode == AUTO_OH) return "OVERHEAD AUTO ACTIVE";
  if (pumpOn) {
    if (manualRoute == MANUAL_UG) return "UNDERGROUND MANUAL ACTIVE";
    return "OVERHEAD MANUAL ACTIVE";
  }
  return "NO MODE ACTIVE";
}

void cors() {
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.sendHeader("Access-Control-Allow-Methods", "GET,POST,OPTIONS");
  server.sendHeader("Access-Control-Allow-Headers", "Content-Type");
}

void jsonSend(int code, const String &body) {
  cors();
  server.send(code, "application/json", body);
}

bool jsonBool(const String &body, const String &key, bool def) {
  String k = "\"" + key + "\"";
  int p = body.indexOf(k);
  if (p < 0) return def;
  p = body.indexOf(':', p);
  if (p < 0) return def;
  String v = body.substring(p + 1);
  v.trim();
  if (v.startsWith("true") || v.startsWith("1")) return true;
  if (v.startsWith("false") || v.startsWith("0")) return false;
  return def;
}

float jsonFloat(const String &body, const String &key, float def) {
  String k = "\"" + key + "\"";
  int p = body.indexOf(k);
  if (p < 0) return def;
  p = body.indexOf(':', p);
  if (p < 0) return def;
  int e = p + 1;
  while (e < (int)body.length() && (body[e] == ' ' || body[e] == '\t')) e++;
  int end = e;
  while (end < (int)body.length()) {
    char c = body[end];
    if ((c >= '0' && c <= '9') || c == '-' || c == '+' || c == '.') end++;
    else break;
  }
  return body.substring(e, end).toFloat();
}

String jsonString(const String &body, const String &key, const String &def) {
  String k = "\"" + key + "\"";
  int p = body.indexOf(k);
  if (p < 0) return def;
  p = body.indexOf(':', p);
  if (p < 0) return def;
  int q1 = body.indexOf('"', p + 1);
  if (q1 < 0) return def;
  int q2 = body.indexOf('"', q1 + 1);
  if (q2 < 0) return def;
  return body.substring(q1 + 1, q2);
}

bool validPercent(float x) { return x >= 0.0f && x <= 100.0f; }

// ----------------------- HX710 READER --------------------------
// Returns false on timeout. This is critical: a missing HX710 must NEVER
// be interpreted as a valid 0% reading.
bool hxReadRaw(uint8_t dout, long &value) {
  unsigned long start = millis();
  while (digitalRead(dout) == HIGH) {
    if (millis() - start >= SENSOR_TIMEOUT_MS) return false;
    delay(1);
  }

  uint32_t raw = 0;
  noInterrupts();
  for (uint8_t i = 0; i < 24; i++) {
    digitalWrite(HX_SCK, HIGH);
    delayMicroseconds(2);
    raw = (raw << 1) | (digitalRead(dout) ? 1UL : 0UL);
    digitalWrite(HX_SCK, LOW);
    delayMicroseconds(2);
  }
  // 25th pulse: normal HX710 mode/channel selection.
  digitalWrite(HX_SCK, HIGH);
  delayMicroseconds(2);
  digitalWrite(HX_SCK, LOW);
  interrupts();

  int32_t signedRaw = (int32_t)(raw << 8) >> 8;
  value = (long)signedRaw;
  return true;
}

// Piecewise interpolation which works whether raw increases or decreases.
float interp(long raw, const long cal[5]) {
  bool allSame = true;
  for (int i = 1; i < 5; i++) if (cal[i] != cal[0]) allSame = false;
  if (allSame) return -1.0f;

  // Require calibration points to move consistently in one direction.
  bool increasing = cal[4] > cal[0];
  for (int i = 1; i < 5; i++) {
    if (increasing && cal[i] <= cal[i - 1]) return -1.0f;
    if (!increasing && cal[i] >= cal[i - 1]) return -1.0f;
  }

  // Clamp outside calibrated range; later safety checks decide if the reading
  // is acceptable. This prevents random raw values from creating unsafe logic.
  if (increasing) {
    if (raw <= cal[0]) return 0.0f;
    if (raw >= cal[4]) return 100.0f;
  } else {
    if (raw >= cal[0]) return 0.0f;
    if (raw <= cal[4]) return 100.0f;
  }

  for (int i = 0; i < 4; i++) {
    bool inside = increasing ? (raw >= cal[i] && raw <= cal[i + 1])
                             : (raw <= cal[i] && raw >= cal[i + 1]);
    if (inside) {
      float f = (raw - cal[i]) / (float)(cal[i + 1] - cal[i]);
      return i * 25.0f + f * 25.0f;
    }
  }
  return -1.0f;
}

bool calibrationReady(const long cal[5]) {
  bool inc = cal[4] > cal[0];
  if (cal[4] == cal[0]) return false;
  for (int i = 1; i < 5; i++) {
    if (inc && cal[i] <= cal[i - 1]) return false;
    if (!inc && cal[i] >= cal[i - 1]) return false;
  }
  return true;
}

bool mainCalibrationReady() {
  return mainRawFull != mainRaw0;
}

// ----------------------- SENSOR UPDATE -------------------------
void updateSensors() {
  long raw;

  if (hxReadRaw(HX_UG_DOUT, raw)) {
    float p = interp(raw, ugCal);
    if (p >= 0.0f) {
      ugLevelPct = constrain(p, 0.0f, 100.0f);
      lastGoodUG = millis();
    }
  }

  if (hxReadRaw(HX_OH_DOUT, raw)) {
    float p = interp(raw, ohCal);
    if (p >= 0.0f) {
      ohLevelPct = constrain(p, 0.0f, 100.0f);
      lastGoodOH = millis();
    }
  }

  if (hxReadRaw(HX_MAIN_DOUT, raw)) {
    if (mainCalibrationReady()) {
      float x = (raw - mainRaw0) / (float)(mainRawFull - mainRaw0);
      mainPressureBar = constrain(x * MAIN_FULL_BAR, 0.0f, MAIN_FULL_BAR);
      lastGoodMain = millis();
    }
  }

  waterDetected = (digitalRead(WATER_DETECT) == WATER_ACTIVE);
}

bool ugSensorOK() {
  return calibrationReady(ugCal) && ugLevelPct >= 0.0f && (millis() - lastGoodUG <= SENSOR_STALE_MS);
}

bool ohSensorOK() {
  return calibrationReady(ohCal) && ohLevelPct >= 0.0f && (millis() - lastGoodOH <= SENSOR_STALE_MS);
}

bool mainSensorOK() {
  return mainCalibrationReady() && mainPressureBar >= 0.0f && (millis() - lastGoodMain <= SENSOR_STALE_MS);
}

String sensorErrorText() {
  if (autoMode == AUTO_UG_TIMER || autoMode == AUTO_UG_SENSOR || autoMode == AUTO_UG_BOTH) {
    if (!calibrationReady(ugCal)) return "UG CALIBRATION NOT READY";
    if (!ugSensorOK()) return "UNDERGROUND SENSOR ERROR";
    if (!mainSensorOK()) return "MAIN PRESSURE SENSOR ERROR";
  }
  if (autoMode == AUTO_OH) {
    if (!calibrationReady(ohCal)) return "OH CALIBRATION NOT READY";
    if (!ohSensorOK()) return "OVERHEAD SENSOR ERROR";
    if (!mainSensorOK()) return "MAIN PRESSURE SENSOR ERROR";
  }
  return "";
}

// ----------------------- OUTPUT SAFETY -------------------------
void pumpOffSafe() {
  digitalWrite(PUMP_RELAY, RELAY_OFF);
  pumpOn = false;
}

void valvesOffSafe() {
  digitalWrite(UG_VALVE, RELAY_OFF);
  digitalWrite(OH_VALVE, RELAY_OFF);
}

// Route is made break-before-make. This is important for the common pump.
void setRoute(ManualRoute route) {
  valvesOffSafe();
  delay(40);
  if (route == MANUAL_UG) {
    digitalWrite(UG_VALVE, RELAY_ON);
  } else {
    digitalWrite(OH_VALVE, RELAY_ON);
  }
}

void allOutputsOff(const String &reason) {
  pumpOffSafe();
  valvesOffSafe();
  ugCheckStart = 0;
  ugWaterConfirmed = false;
  if (reason.length()) lastError = reason;
}

void stopAuto(const String &reason) {
  allOutputsOff(reason);
  autoMode = AUTO_NONE;
  retryUntil = 0;
}

// ----------------------- AUTO CONTROL --------------------------
void startAutoPump(AutoMode m) {
  // Every AUTO start must pass the relevant sensor and main pressure checks.
  if ((m == AUTO_UG_TIMER || m == AUTO_UG_SENSOR || m == AUTO_UG_BOTH) && !ugSensorOK()) { stopAuto("UNDERGROUND SENSOR ERROR"); return; }
  if (m == AUTO_OH && !ohSensorOK()) { stopAuto("OVERHEAD SENSOR ERROR"); return; }
  if (!mainSensorOK()) { stopAuto("MAIN PRESSURE SENSOR ERROR"); return; }
  if (mainPressureBar < minPressureBar) return;

  setRoute(m == AUTO_UG_TIMER || m == AUTO_UG_SENSOR || m == AUTO_UG_BOTH ? MANUAL_UG : MANUAL_OH);
  digitalWrite(PUMP_RELAY, RELAY_ON);
  pumpOn = true;
  lastError = "";

  if (m == AUTO_UG_TIMER || m == AUTO_UG_BOTH) {
    ugCheckStart = millis();
    ugWaterConfirmed = false;
  }
}

void runAuto() {
  if (autoMode == AUTO_NONE) return;

  String err = sensorErrorText();
  if (err.length()) {
    if (pumpOn) allOutputsOff(err);
    lastError = err;
    return;
  }

  // ------------------------------------------------------------
  // UNDERGROUND AUTO: TIMER, WATER-SENSOR, or BOTH
  // BOTH modes are independent triggers. If either trigger becomes valid,
  // the pump can start. If TIMER is in its water-check window and the
  // pressure sensor sees water, the sensor trigger does not wait for the
  // timer/check window; it starts the pump immediately.
  // ------------------------------------------------------------
  if (autoMode == AUTO_UG_TIMER || autoMode == AUTO_UG_SENSOR || autoMode == AUTO_UG_BOTH) {
    bool timerEnabled  = (autoMode == AUTO_UG_TIMER || autoMode == AUTO_UG_BOTH);
    bool sensorEnabled = (autoMode == AUTO_UG_SENSOR || autoMode == AUTO_UG_BOTH);

    if (ugLevelPct >= ugOff) {
      if (pumpOn) allOutputsOff("UNDERGROUND FULL - PUMP STOPPED");
      return;
    }

    if (pumpOn) {
      // If the timer started a check, the 2-wire detector confirms actual water.
      if (timerEnabled && !ugWaterConfirmed) {
        if (waterDetected) {
          ugWaterConfirmed = true;
          ugCheckStart = 0;
          lastError = "";
        } else if (millis() - ugCheckStart >= (unsigned long)waterCheckSec * 1000UL) {
          allOutputsOff("NO WATER DETECTED - TIMER WAITING");
          ugTimerStart = millis();
          return;
        }
      }

      // Once pump is running, loss of main-line pressure is a stop condition.
      if (!mainSensorOK() || mainPressureBar < minPressureBar) {
        allOutputsOff("UNDERGROUND AUTO - WATER PRESSURE LOST");
      }
      return;
    }

    // WATER SENSOR trigger: pressure can start the pump immediately.
    // This works even while the TIMER mode is still waiting for its interval.
    if (sensorEnabled && ugLevelPct <= ugOn && mainPressureBar >= minPressureBar) {
      startAutoPump(autoMode);
      return;
    }

    // TIMER trigger: interval-based attempt.
    if (timerEnabled) {
      if (ugTimerStart == 0) ugTimerStart = millis();
      unsigned long intervalMs = (unsigned long)retryMin * 60000UL;
      if (millis() - ugTimerStart >= intervalMs) {
        ugTimerStart = millis();
        if (ugLevelPct <= ugOn && mainPressureBar >= minPressureBar) {
          startAutoPump(autoMode);
        }
      }
    }
    return;
  }

  // ------------------------------------------------------------
  // OVERHEAD AUTO
  // ------------------------------------------------------------
  if (autoMode == AUTO_OH) {
    if (pumpOn) {
      if (ohLevelPct >= ohOff) {
        allOutputsOff("OVERHEAD FULL - PUMP STOPPED");
        autoMode = AUTO_OH;
      } else if (!mainSensorOK() || mainPressureBar < minPressureBar) {
        allOutputsOff("OVERHEAD AUTO - WATER PRESSURE LOST");
      }
      return;
    }

    if (ohLevelPct <= ohOn && mainPressureBar >= minPressureBar) {
      startAutoPump(AUTO_OH);
    }
  }
}

// ----------------------- MANUAL CONTROL -----------------------
void manualStart() {
  // Manual emergency bypass is intentionally the only path allowed to ignore
  // sensor/main-pressure protection. The timer is mandatory and still applies.
  if (!manualEmergencyBypass) {
    if (manualRoute == MANUAL_UG && !ugSensorOK()) {
      lastError = "MANUAL BLOCKED - UNDERGROUND SENSOR ERROR";
      return;
    }
    if (manualRoute == MANUAL_OH && !ohSensorOK()) {
      lastError = "MANUAL BLOCKED - OVERHEAD SENSOR ERROR";
      return;
    }
    if (!mainSensorOK() || mainPressureBar < minPressureBar) {
      lastError = "MANUAL BLOCKED - MAIN PRESSURE TOO LOW/ERROR";
      return;
    }
  }

  autoMode = AUTO_NONE;
  retryUntil = 0;
  ugCheckStart = 0;
  ugWaterConfirmed = false;

  setRoute(manualRoute);
  digitalWrite(PUMP_RELAY, RELAY_ON);
  pumpOn = true;
  manualUntil = millis() + (unsigned long)manualMin * 60000UL;
  lastError = manualEmergencyBypass ? "MANUAL EMERGENCY BYPASS ACTIVE" : "";
}

void manualStop() {
  manualUntil = 0;
  allOutputsOff("MANUAL PUMP OFF");
  autoMode = AUTO_NONE;
}

// ----------------------- PERSISTENCE ---------------------------
void saveSettings() {
  prefs.begin("settings", false);
  prefs.putFloat("ugOn", ugOn);
  prefs.putFloat("ugOff", ugOff);
  prefs.putFloat("ugLow", ugLow);
  prefs.putFloat("ohOn", ohOn);
  prefs.putFloat("ohOff", ohOff);
  prefs.putFloat("minP", minPressureBar);
  prefs.putUInt("retry", retryMin);
  prefs.putUInt("check", waterCheckSec);
  prefs.putUInt("manual", manualMin);
  prefs.putBool("bypass", manualEmergencyBypass);
  prefs.end();
}

void loadSettings() {
  prefs.begin("settings", true);
  ugOn = prefs.getFloat("ugOn", ugOn);
  ugOff = prefs.getFloat("ugOff", ugOff);
  ugLow = prefs.getFloat("ugLow", ugLow);
  ohOn = prefs.getFloat("ohOn", ohOn);
  ohOff = prefs.getFloat("ohOff", ohOff);
  minPressureBar = prefs.getFloat("minP", minPressureBar);
  retryMin = prefs.getUInt("retry", retryMin);
  waterCheckSec = prefs.getUInt("check", waterCheckSec);
  manualMin = prefs.getUInt("manual", manualMin);
  manualEmergencyBypass = prefs.getBool("bypass", manualEmergencyBypass);
  prefs.end();
}

void saveCalibration() {
  prefs.begin("cal", false);
  for (int i = 0; i < 5; i++) {
    prefs.putLong((String("ug") + i).c_str(), ugCal[i]);
    prefs.putLong((String("oh") + i).c_str(), ohCal[i]);
  }
  prefs.putLong("main0", mainRaw0);
  prefs.putLong("main100", mainRawFull);
  prefs.end();
}

void loadCalibration() {
  prefs.begin("cal", true);
  for (int i = 0; i < 5; i++) {
    ugCal[i] = prefs.getLong((String("ug") + i).c_str(), 0);
    ohCal[i] = prefs.getLong((String("oh") + i).c_str(), 0);
  }
  mainRaw0 = prefs.getLong("main0", 0);
  mainRawFull = prefs.getLong("main100", 0);
  prefs.end();
}

// ----------------------- WIFI ----------------------------------
IPAddress staticIP(192,168,100,50);
IPAddress gatewayIP(192,168,100,1);
IPAddress subnetIP(255,255,255,0);
IPAddress dnsIP(192,168,100,1);

void startSetupAP() {
  WiFi.mode(WIFI_AP_STA);
  WiFi.softAP("WaterPump-Setup", "12345678");
}

void connectRouter() {
  prefs.begin("wifi", true);
  String ssid = prefs.getString("ssid", "");
  String pass = prefs.getString("pass", "");
  String ip = prefs.getString("ip", "192.168.100.50");
  String gw = prefs.getString("gw", "192.168.100.1");
  String mask = prefs.getString("mask", "255.255.255.0");
  String dns = prefs.getString("dns", "192.168.100.1");
  String mode = prefs.getString("mode", "static");
  prefs.end();

  if (!ssid.length()) return;

  IPAddress i, g, m, d;
  bool addressesOK = i.fromString(ip) && g.fromString(gw) && m.fromString(mask) && d.fromString(dns);

  WiFi.mode(WIFI_STA);
  if (mode == "static" && addressesOK) WiFi.config(i, g, m, d);
  WiFi.begin(ssid.c_str(), pass.c_str());

  unsigned long start = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - start < 15000UL) {
    delay(250);
  }
}

// ----------------------- HTTP HANDLERS -------------------------
void handleOptions() { cors(); server.send(204); }

void handleRoot() {
  String page = R"rawliteral(<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>Water Pump ESP32 Setup</title><style>body{margin:0;background:#061b29;color:#fff;font-family:Arial;padding:20px}main{max-width:520px;margin:auto;background:#082e45;border:1px solid #15506a;border-radius:20px;padding:20px}input,select{width:100%;box-sizing:border-box;padding:12px;margin:5px 0 12px;border-radius:10px;border:1px solid #24566d;background:#061b29;color:#fff;font-size:16px}label{color:#b9c9d2}button{width:100%;padding:14px;border:0;border-radius:12px;background:#16d957;font-weight:900;font-size:16px}.note{color:#a8bbc5;line-height:1.5}</style></head><body><main><h1>💧 Water Pump System</h1><h2>ESP32 Wi-Fi Setup</h2><p class="note">Connect phone to <b>WaterPump-Setup</b>. Enter router details and save.</p><form method="POST" action="/wifi/save"><label>Router Wi-Fi SSID</label><input name="ssid" required><label>Router Wi-Fi Password</label><input name="password" type="password"><label>Network Mode</label><select name="mode"><option value="static">Static IP</option><option value="dhcp">DHCP</option></select><label>ESP32 IP Address</label><input name="ip" value="192.168.100.50"><label>Gateway</label><input name="gateway" value="192.168.100.1"><label>Subnet Mask</label><input name="subnet" value="255.255.255.0"><label>DNS</label><input name="dns" value="192.168.100.1"><button type="submit">SAVE & CONNECT</button></form><p class="note">After restart, connect phone to the same router and use the App CONNECT ESP32 button.</p><hr style="border-color:#15506a"><h3>🔐 Sensor Calibration</h3><p class="note">Calibration App میں نہیں ہے۔ محفوظ calibration کے لیے <b>Calibration Browser</b> کھولیں۔</p><a href="/calibration" style="display:block;text-align:center;text-decoration:none;padding:13px;border-radius:12px;background:#0b79b7;color:white;font-weight:900">OPEN CALIBRATION</a></main></body></html>)rawliteral";
  server.send(200,"text/html; charset=utf-8",page);
}
void handleStatus() {
  String j = "{";
  j += "\"online\":true,";
  j += "\"ug\":" + String(ugLevelPct, 1) + ",";
  j += "\"oh\":" + String(ohLevelPct, 1) + ",";
  j += "\"pump\":" + String(pumpOn ? "true" : "false") + ",";
  // 'water' is main pressure permission; 'waterDetect' is the 2-wire detector.
  bool pressureAvailable = mainSensorOK() && mainPressureBar >= minPressureBar;
  j += "\"water\":" + String(pressureAvailable ? "true" : "false") + ",";
  j += "\"waterDetect\":" + String(waterDetected ? "true" : "false") + ",";
  j += "\"mainPressure\":" + String(mainPressureBar, 2) + ",";
  j += "\"activeMode\":\"" + activeModeText() + "\",";
  j += "\"ugTimerAuto\":" + String((autoMode == AUTO_UG_TIMER || autoMode == AUTO_UG_BOTH) ? "true" : "false") + ",";
  j += "\"ugSensorAuto\":" + String((autoMode == AUTO_UG_SENSOR || autoMode == AUTO_UG_BOTH) ? "true" : "false") + ",";
  j += "\"ugBothAuto\":" + String(autoMode == AUTO_UG_BOTH ? "true" : "false") + ",";
  j += "\"manualRoute\":\"" + String(manualRoute == MANUAL_UG ? "ug" : "oh") + "\",";
  j += "\"manualEmergencyBypass\":" + String(manualEmergencyBypass ? "true" : "false") + ",";
  j += "\"sensorError\":\"" + lastError + "\"";
  j += "}";
  jsonSend(200, j);
}

void handleControl() {
  if (server.hasArg("auto")) {
    String a = server.arg("auto");

    // Underground TIMER and WATER SENSOR are independent switches and can
    // be enabled together. Overhead AUTO remains mutually exclusive with
    // all underground AUTO modes because the pump/valves are common.
    if (a == "ug") {
      manualUntil = 0;
      if (autoMode == AUTO_UG_SENSOR) autoMode = AUTO_UG_BOTH;
      else if (autoMode != AUTO_UG_BOTH) autoMode = AUTO_UG_TIMER;
      retryUntil = 0;
      if (ugTimerStart == 0) ugTimerStart = millis();
      allOutputsOff("");
      lastError = "";
    } else if (a == "ugsensor") {
      manualUntil = 0;
      if (autoMode == AUTO_UG_TIMER) autoMode = AUTO_UG_BOTH;
      else if (autoMode != AUTO_UG_BOTH) autoMode = AUTO_UG_SENSOR;
      retryUntil = 0;
      if (autoMode == AUTO_UG_BOTH || autoMode == AUTO_UG_TIMER) {
        if (ugTimerStart == 0) ugTimerStart = millis();
      }
      allOutputsOff("");
      lastError = "";
    } else if (a == "oh") {
      manualUntil = 0;
      retryUntil = 0;
      ugTimerStart = 0;
      autoMode = AUTO_OH;
      allOutputsOff("");
      lastError = "";
    } else if (a == "none") {
      autoMode = AUTO_NONE;
      manualUntil = 0;
      ugTimerStart = 0;
      allOutputsOff("AUTO OFF");
    }
  }

  if (server.hasArg("manualRoute")) {
    String r = server.arg("manualRoute");
    manualRoute = (r == "oh") ? MANUAL_OH : MANUAL_UG;
    if (pumpOn && autoMode == AUTO_NONE) setRoute(manualRoute);
  }

  if (server.hasArg("manual") && server.arg("manual") == "on") {
    manualStart();
  }

  if (server.hasArg("pump") && server.arg("pump") == "off") {
    manualStop();
  }

  jsonSend(200, "{\"ok\":true}");
}

void handleSettings() {
  String b = server.arg("plain");

  ugOn = constrain(jsonFloat(b, "ugOn", ugOn), 0.0f, 99.0f);
  ugOff = constrain(jsonFloat(b, "ugOff", ugOff), 1.0f, 100.0f);
  ugLow = constrain(jsonFloat(b, "ugLow", ugLow), 0.0f, 50.0f);
  ohOn = constrain(jsonFloat(b, "ohOn", ohOn), 0.0f, 99.0f);
  ohOff = constrain(jsonFloat(b, "ohOff", ohOff), 1.0f, 100.0f);
  minPressureBar = constrain(jsonFloat(b, "minPressure", minPressureBar), 0.0f, MAIN_FULL_BAR);
  retryMin = constrain((int)jsonFloat(b, "retryMin", retryMin), 15, 60);
  waterCheckSec = constrain((int)jsonFloat(b, "waterCheckSec", waterCheckSec), 30, 300);
  manualMin = constrain((int)jsonFloat(b, "manualMin", manualMin), 5, 60);
  manualEmergencyBypass = jsonBool(b, "manualEmergencyBypass", manualEmergencyBypass);

  // Prevent nonsensical thresholds.
  if (ugOff <= ugOn) ugOff = min(100.0f, ugOn + 1.0f);
  if (ohOff <= ohOn) ohOff = min(100.0f, ohOn + 1.0f);
  if (ugLow > ugOn) ugLow = ugOn;

  saveSettings();
  jsonSend(200, "{\"ok\":true}");
}

void handleCalibrationApi() {
  if (!calibrationSessionOK()) { jsonSend(401, "{\"ok\":false,\"error\":\"CALIBRATION LOCKED\"}"); return; }
  if (!server.hasArg("tank") || !server.hasArg("point")) {
    jsonSend(400, "{\"ok\":false,\"error\":\"tank and point required\"}");
    return;
  }

  String tank = server.arg("tank");
  int point = server.arg("point").toInt();
  int idx = -1;
  if (point == 0) idx = 0;
  else if (point == 25) idx = 1;
  else if (point == 50) idx = 2;
  else if (point == 75) idx = 3;
  else if (point == 100) idx = 4;
  else {
    jsonSend(400, "{\"ok\":false,\"error\":\"point must be 0,25,50,75,100\"}");
    return;
  }

  long raw = 0;
  bool ok = false;
  if (tank == "ug") ok = hxReadRaw(HX_UG_DOUT, raw);
  else if (tank == "oh") ok = hxReadRaw(HX_OH_DOUT, raw);
  else if (tank == "main") {
    ok = hxReadRaw(HX_MAIN_DOUT, raw);
    if (ok && point == 0) mainRaw0 = raw;
    if (ok && point == 100) mainRawFull = raw;
    if (ok) saveCalibration();
    if (ok) jsonSend(200, "{\"ok\":true,\"raw\":" + String(raw) + "}");
    else jsonSend(503, "{\"ok\":false,\"error\":\"MAIN HX710 NOT READY\"}");
    return;
  } else {
    jsonSend(400, "{\"ok\":false,\"error\":\"unknown tank\"}");
    return;
  }

  if (!ok) {
    jsonSend(503, "{\"ok\":false,\"error\":\"HX710 NOT READY\"}");
    return;
  }

  if (tank == "ug") ugCal[idx] = raw;
  else ohCal[idx] = raw;
  saveCalibration();

  jsonSend(200, "{\"ok\":true,\"raw\":" + String(raw) + "}");
}

void handleCalibrationValuesApi() {
  if (!calibrationSessionOK()) { jsonSend(401, "{\"ok\":false,\"error\":\"CALIBRATION LOCKED\"}"); return; }
  String j = "{";
  const char* names[10] = {"ug0","ug25","ug50","ug75","ug100","oh0","oh25","oh50","oh75","oh100"};
  for (int i = 0; i < 5; i++) {
    if (i) j += ",";
    j += "\"" + String(names[i]) + "\":" + String(ugCal[i]);
  }
  for (int i = 0; i < 5; i++) {
    j += ",\"" + String(names[i + 5]) + "\":" + String(ohCal[i]);
  }
  j += ",\"main0\":" + String(mainRaw0);
  j += ",\"main100\":" + String(mainRawFull);
  j += "}";
  jsonSend(200, j);
}

void handleCalibrationLogin() {
  String pin = server.hasArg("pin") ? server.arg("pin") : "";
  if (pin == CALIBRATION_PIN) {
    calibrationUnlocked = true;
    calibrationUnlockUntil = millis() + CAL_SESSION_MS;
    server.sendHeader("Location", "/calibration");
    server.send(303, "text/plain", "Unlocked");
    return;
  }
  server.send(401, "text/html; charset=utf-8", "<html><body style='font-family:Arial;background:#061b29;color:white;padding:25px'><h2>Wrong PIN</h2><a style='color:#29aaff' href='/calibration'>Back</a></body></html>");
}

void handleCalibrationLogout() {
  calibrationUnlocked = false;
  calibrationUnlockUntil = 0;
  server.sendHeader("Location", "/calibration");
  server.send(303, "text/plain", "Locked");
}

String calibrationPage() {
  String page = R"rawliteral(<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><meta charset="utf-8"><title>Water Pump Calibration</title>
  <style>body{margin:0;background:#061b29;color:#fff;font-family:Arial;padding:18px}main{max-width:620px;margin:auto}.card{background:#082e45;border:1px solid #15506a;border-radius:18px;padding:16px;margin:12px 0}h1{font-size:24px;margin:4px 0 8px}h2{font-size:19px;margin:0 0 8px}.note{color:#a9bdc8;line-height:1.45;font-size:13px}.grid{display:grid;grid-template-columns:repeat(5,1fr);gap:7px}.pt{background:#061b29;border:1px solid #24566d;border-radius:11px;padding:8px;text-align:center}.pt b{display:block;margin-bottom:6px}.pt button,.mainbtn,button{border:0;border-radius:10px;padding:10px;background:#0b79b7;color:#fff;font-weight:800;width:100%;font-size:13px}.value{font-size:11px;color:#8ed6ef;margin-top:6px;word-break:break-all}.lock{background:#7c1d28!important}.ok{color:#29ef78;font-weight:800}.warn{color:#ffd166;font-weight:800}@media(max-width:500px){.grid{grid-template-columns:repeat(2,1fr)}.grid .pt:last-child{grid-column:1/2}}</style></head><body><main>
  <div class="card"><h1>💧 Water Pump System</h1><h2>Protected Sensor Calibration</h2><p class="note">یہ calibration صرف ESP32 کے browser سے ہوگی۔ Mobile App میں calibration settings موجود نہیں ہیں۔ Calibration محفوظ ہونے کے بعد عام App user اسے تبدیل نہیں کر سکتا۔ Unlock session 10 منٹ بعد خود lock ہو جاتا ہے۔</p></div>
)rawliteral";
  if (!calibrationSessionOK()) {
    page += R"rawliteral(<div class="card"><h2>🔐 Calibration Locked</h2><p class="note">Calibration شروع کرنے کے لیے PIN درج کریں۔</p><form method="POST" action="/calibration/login"><input name="pin" type="password" inputmode="numeric" autocomplete="off" placeholder="Calibration PIN" style="width:100%;box-sizing:border-box;padding:13px;border-radius:10px;border:1px solid #24566d;background:#061b29;color:white;font-size:18px;margin:8px 0"><button class="mainbtn" type="submit">UNLOCK CALIBRATION</button></form></div></main></body></html>)rawliteral";
    return page;
  }
  page += R"rawliteral(<div class="card"><div class="ok">● CALIBRATION UNLOCKED</div><p class="note">ہر point پر tank کو واقعی اس level تک لے جائیں، reading stable ہونے دیں، پھر READ & SAVE دبائیں۔ ESP32 raw value خود save کرے گا۔</p><form method="POST" action="/calibration/logout"><button class="lock" type="submit">LOCK CALIBRATION</button></form></div>
  <div class="card"><h2>Underground Tank — Level Calibration</h2><p class="note">0%, 25%, 50%, 75%, 100% پانچ points لازمی مکمل کریں۔</p><div class="grid">
  <div class="pt"><b>0%</b><button onclick="cal('ug',0,'u0')">READ & SAVE</button><div id="u0" class="value">—</div></div>
  <div class="pt"><b>25%</b><button onclick="cal('ug',25,'u25')">READ & SAVE</button><div id="u25" class="value">—</div></div>
  <div class="pt"><b>50%</b><button onclick="cal('ug',50,'u50')">READ & SAVE</button><div id="u50" class="value">—</div></div>
  <div class="pt"><b>75%</b><button onclick="cal('ug',75,'u75')">READ & SAVE</button><div id="u75" class="value">—</div></div>
  <div class="pt"><b>100%</b><button onclick="cal('ug',100,'u100')">READ & SAVE</button><div id="u100" class="value">—</div></div></div></div>
  <div class="card"><h2>Overhead Tank — Level Calibration</h2><p class="note">0%, 25%, 50%, 75%, 100% پانچ points لازمی مکمل کریں۔</p><div class="grid">
  <div class="pt"><b>0%</b><button onclick="cal('oh',0,'o0')">READ & SAVE</button><div id="o0" class="value">—</div></div>
  <div class="pt"><b>25%</b><button onclick="cal('oh',25,'o25')">READ & SAVE</button><div id="o25" class="value">—</div></div>
  <div class="pt"><b>50%</b><button onclick="cal('oh',50,'o50')">READ & SAVE</button><div id="o50" class="value">—</div></div>
  <div class="pt"><b>75%</b><button onclick="cal('oh',75,'o75')">READ & SAVE</button><div id="o75" class="value">—</div></div>
  <div class="pt"><b>100%</b><button onclick="cal('oh',100,'o100')">READ & SAVE</button><div id="o100" class="value">—</div></div></div></div>
  <div class="card"><h2>Main Line Pressure Calibration</h2><p class="note">0 bar پر 0% button اور sensor کے full-scale pressure پر 5 bar button استعمال کریں۔</p><div class="grid" style="grid-template-columns:1fr 1fr"><div class="pt"><b>0 bar</b><button onclick="cal('main',0,'m0')">READ & SAVE</button><div id="m0" class="value">—</div></div><div class="pt"><b>5 bar</b><button onclick="cal('main',100,'m100')">READ & SAVE</button><div id="m100" class="value">—</div></div></div></div>
  <div class="card"><p class="warn">⚠ Calibration کو صرف actual tank level پر کریں۔ غلط calibration سے AUTO control block ہوگا، pump کو غلط level پر چلنے نہیں دیا جائے گا۔</p></div>
  <script>async function cal(t,p,id){try{let r=await fetch('/api/calibration?tank='+t+'&point='+p+'&x='+Date.now(),{cache:'no-store'});let j=await r.json();if(!r.ok||!j.ok)throw new Error(j.error||'Read failed');document.getElementById(id).textContent='RAW: '+j.raw;alert('Saved: '+j.raw)}catch(e){alert('Calibration failed: '+e.message)}}</script></main></body></html>)rawliteral";
  return page;
}

void handleCalibrationPage() {
  server.send(200, "text/html; charset=utf-8", calibrationPage());
}

void handleWifiSave() {
  String ssid, pass, mode, ip, gw, mask, dns;
  if(server.hasArg("ssid")){ssid=server.arg("ssid");pass=server.arg("password");mode=server.arg("mode");ip=server.arg("ip");gw=server.arg("gateway");mask=server.arg("subnet");dns=server.arg("dns");}
  else {String body=server.arg("plain");ssid=jsonString(body,"ssid","");pass=jsonString(body,"password","");mode=jsonString(body,"mode","static");ip=jsonString(body,"ip","192.168.100.50");gw=jsonString(body,"gateway","192.168.100.1");mask=jsonString(body,"subnet","255.255.255.0");dns=jsonString(body,"dns","192.168.100.1");}
  if(!ssid.length()){server.send(400,"text/html","<h3>SSID required</h3><a href='/'>Back</a>");return;}
  prefs.begin("wifi",false);prefs.putString("ssid",ssid);prefs.putString("pass",pass);prefs.putString("mode",mode);prefs.putString("ip",ip);prefs.putString("gw",gw);prefs.putString("mask",mask);prefs.putString("dns",dns);prefs.end();
  server.send(200,"text/html; charset=utf-8","<html><body style='font-family:Arial;background:#061b29;color:white;padding:25px'><h2>Saved successfully</h2><p>ESP32 is restarting.</p></body></html>");delay(800);ESP.restart();
}
// ----------------------- SETUP / LOOP --------------------------
void setup() {
  Serial.begin(115200);
  delay(300);

  pinMode(HX_SCK, OUTPUT);
  digitalWrite(HX_SCK, LOW);
  pinMode(HX_UG_DOUT, INPUT);
  pinMode(HX_OH_DOUT, INPUT);
  pinMode(HX_MAIN_DOUT, INPUT);
  pinMode(WATER_DETECT, INPUT_PULLUP);

  pinMode(PUMP_RELAY, OUTPUT);
  pinMode(UG_VALVE, OUTPUT);
  pinMode(OH_VALVE, OUTPUT);

  // Boot safety: everything OFF before anything else.
  digitalWrite(PUMP_RELAY, RELAY_OFF);
  digitalWrite(UG_VALVE, RELAY_OFF);
  digitalWrite(OH_VALVE, RELAY_OFF);
  pumpOn = false;
  autoMode = AUTO_NONE;

  loadSettings();
  loadCalibration();

  connectRouter();
  if (WiFi.status() != WL_CONNECTED) startSetupAP();

  server.on("/", HTTP_GET, handleRoot);
  server.on("/status", HTTP_GET, handleStatus);
  server.on("/control", HTTP_GET, handleControl);
  server.on("/settings", HTTP_POST, handleSettings);
  server.on("/wifi/save", HTTP_POST, handleWifiSave);
  server.on("/calibration", HTTP_GET, handleCalibrationPage);
  server.on("/calibration/login", HTTP_POST, handleCalibrationLogin);
  server.on("/calibration/logout", HTTP_POST, handleCalibrationLogout);
  server.on("/api/calibration", HTTP_GET, handleCalibrationApi);
  server.on("/api/calibration/values", HTTP_GET, handleCalibrationValuesApi);

  server.on("/status", HTTP_OPTIONS, handleOptions);
  server.on("/control", HTTP_OPTIONS, handleOptions);
  server.on("/settings", HTTP_OPTIONS, handleOptions);
  server.on("/wifi/save", HTTP_OPTIONS, handleOptions);
  server.on("/calibration", HTTP_OPTIONS, handleOptions);
  server.on("/calibration/login", HTTP_OPTIONS, handleOptions);
  server.on("/calibration/logout", HTTP_OPTIONS, handleOptions);
  server.on("/api/calibration", HTTP_OPTIONS, handleOptions);
  server.on("/api/calibration/values", HTTP_OPTIONS, handleOptions);

  server.begin();

  Serial.println();
  Serial.println("========================================");
  Serial.println(" WATER PUMP SYSTEM - SAFETY V2");
  Serial.println("========================================");
  Serial.print("AP IP : "); Serial.println(WiFi.softAPIP());
  Serial.print("STA IP: "); Serial.println(WiFi.localIP());
  Serial.println("Boot outputs: PUMP OFF / VALVES OFF");
}

void loop() {
  server.handleClient();

  // Manual timer is mandatory. Never allow it to run forever.
  if (manualUntil != 0 && (long)(millis() - manualUntil) >= 0) {
    manualUntil = 0;
    allOutputsOff("MANUAL TIMER FINISHED");
    autoMode = AUTO_NONE;
    ugTimerStart = 0;
  }

  // Sensor refresh. If an AUTO sensor becomes stale, runAuto() stops the pump.
  static unsigned long lastSensor = 0;
  if (millis() - lastSensor >= 500) {
    lastSensor = millis();
    updateSensors();
  }

  runAuto();
  delay(2);
}
