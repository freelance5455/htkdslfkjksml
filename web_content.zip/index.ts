// Deploy: supabase functions deploy submit-feedback
// Secrets: supabase secrets set POW_SECRET=<long random> RL_SALT=<long random>
import { createClient } from "npm:@supabase/supabase-js@2";
const sb = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "content-type, authorization, apikey, x-client-info", "Content-Type": "application/json" };
const out = (o: unknown, status = 200) => new Response(JSON.stringify(o), { status, headers: cors });
const enc = new TextEncoder();
const hex = (b: ArrayBuffer | Uint8Array) => [...new Uint8Array(b)].map((x) => x.toString(16).padStart(2, "0")).join("");
const sha = async (s: string) => new Uint8Array(await crypto.subtle.digest("SHA-256", enc.encode(s)));
const hmac = async (msg: string) => {
  const k = await crypto.subtle.importKey("raw", enc.encode(Deno.env.get("POW_SECRET")!), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return hex(await crypto.subtle.sign("HMAC", k, enc.encode(msg)));
};
const zeros = (h: Uint8Array) => { let z = 0; for (const x of h) { if (x === 0) z += 8; else { z += Math.clz32(x) - 24; break; } } return z; };
const BITS = 14; // ~16k hashes: unnoticeable once, costly in bulk
const since = (ms: number) => new Date(Date.now() - ms).toISOString();

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  const b = await req.json().catch(() => null);
  if (!b) return out({ error: "bad request" }, 400);

  // Stateless, HMAC-signed proof-of-work challenge for the desktop app.
  if (b.action === "challenge") {
    const ts = Date.now(), r = crypto.randomUUID();
    return out({ ch: `${ts}.${r}.${await hmac(`${ts}.${r}`)}`, bits: BITS });
  }
  if (typeof b.message !== "string" || !b.message.trim() || b.message.length > 1000) return out({ error: "bad request" }, 400);
  const type = ["bug", "idea", "flaw", "praise"].includes(b.type) ? b.type : "idea";

  // Server-side limits keyed on a salted hash of the caller's IP: rotating install IDs does not help an attacker.
  const ip = req.headers.get("cf-connecting-ip") || req.headers.get("x-forwarded-for")?.split(",")[0].trim() || "unknown";
  const ip_hash = hex(await sha(ip + Deno.env.get("RL_SALT")));
  const ipCount = async (ms: number) => (await sb.from("feedback").select("id", { count: "exact", head: true }).eq("ip_hash", ip_hash).gte("created_at", since(ms))).count ?? 0;

  let source = "app", install_id: string | null = null;
  { // desktop app only: proof of work + IP / install / global caps
    install_id = String(b.install_id || "");
    if (!/^[0-9a-f-]{36}$/i.test(install_id)) return out({ error: "forbidden" }, 403);
    const [ts, r, mac] = String(b.pow?.ch || "").split(".");
    if (!ts || !r || !mac || mac !== (await hmac(`${ts}.${r}`)) || Date.now() - Number(ts) > 6e5) return out({ error: "bad challenge" }, 403);
    if (zeros(await sha(`${b.pow.ch}:${b.pow.n}`)) < BITS) return out({ error: "bad proof" }, 403);
    if ((await sb.from("pow_used").insert({ r })).error) return out({ error: "replay" }, 403); // each challenge works once
    if ((await ipCount(36e5)) >= 5) return out({ error: "rate limited" }, 429);
    const inst = (await sb.from("feedback").select("id", { count: "exact", head: true }).eq("install_id", install_id).gte("created_at", since(864e5))).count ?? 0;
    if (inst >= 5) return out({ error: "rate limited" }, 429);
    const all = (await sb.from("feedback").select("id", { count: "exact", head: true }).eq("source", "app").gte("created_at", since(864e5))).count ?? 0;
    if (all >= 500) return out({ error: "busy, try later" }, 429);
  }
  const email = typeof b.email === "string" && /^[^@\s]+@[^@\s]+$/.test(b.email) ? b.email.slice(0, 200) : null;
  const { error } = await sb.from("feedback").insert({ type, message: b.message.trim(), email, version: String(b.version || "").slice(0, 20), os: String(b.os || "").slice(0, 40), install_id, source, ip_hash });
  return error ? out({ error: "save failed" }, 500) : out({ ok: true });
});
