LA CABEZA CARLOS - PROYECTO ANDROID OFFLINE

Este proyecto empaqueta el juego HTML dentro de la aplicación. La app no necesita permisos de Internet y carga el juego desde app/src/main/assets/index.html.

Para generar el APK:
1. Abre este proyecto en Android Studio (requiere un ordenador).
2. Espera a que Gradle termine la sincronización.
3. Ve a Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Android Studio mostrará la ubicación del APK generado.

No se ha generado un APK instalable en este paquete; se entrega el proyecto fuente listo para compilar. El juego incluido es el HTML proporcionado.
