package com.example

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.media.MediaPlayer
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Base64
import android.view.View
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color as ComposeColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import java.io.ByteArrayOutputStream
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {

  private var webView: WebView? = null
  private var tts: TextToSpeech? = null
  private var mediaPlayer: MediaPlayer? = null
  private var speechRecognizer: SpeechRecognizer? = null
  private lateinit var prefs: SharedPreferences

  private val requestPermissionLauncher =
      registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
        if (isGranted) {
          initSpeechRecognizer()
        }
      }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    prefs = getSharedPreferences("sidekick_prefs", Context.MODE_PRIVATE)
    tts = TextToSpeech(this, this)

    if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
        PackageManager.PERMISSION_GRANTED) {
      initSpeechRecognizer()
    } else {
      requestPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    setContent {
      Box(modifier = Modifier.fillMaxSize().background(ComposeColor.Transparent)) {
        SidekickWebViewContainer()
      }
    }
  }

  private fun initSpeechRecognizer() {
    runOnUiThread {
      if (SpeechRecognizer.isRecognitionAvailable(this)) {
        speechRecognizer =
            SpeechRecognizer.createSpeechRecognizer(this).apply {
              setRecognitionListener(
                  object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onError(error: Int) {}
                    override fun onResults(results: Bundle?) {
                      val matches =
                          results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                      val spokenText = matches?.firstOrNull() ?: ""
                      if (spokenText.isNotEmpty()) {
                        webView?.post {
                          val escaped = spokenText.replace("'", "\\'").replace("\n", " ")
                          webView?.evaluateJavascript(
                              "if (window.onNativeSpeechResult) window.onNativeSpeechResult('$escaped');",
                              null)
                        }
                      }
                    }
                    override fun onPartialResults(partialResults: Bundle?) {
                      val matches =
                          partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                      val partialText = matches?.firstOrNull() ?: ""
                      if (partialText.isNotEmpty()) {
                        webView?.post {
                          val escaped = partialText.replace("'", "\\'").replace("\n", " ")
                          webView?.evaluateJavascript(
                              "if (window.onNativeSpeechPartial) window.onNativeSpeechPartial('$escaped');",
                              null)
                        }
                      }
                    }
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                  })
            }
      }
    }
  }

  override fun onInit(status: Int) {
    if (status == TextToSpeech.SUCCESS) {
      tts?.language = Locale.US
      tts?.setPitch(0.95f)
      tts?.setSpeechRate(1.1f)
    }
  }

  @Composable
  private fun SidekickWebViewContainer() {
    val context = LocalContext.current
    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { ctx ->
          WebView(ctx).apply {
            webView = this
            layoutParams =
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            setBackgroundColor(Color.TRANSPARENT)
            setLayerType(View.LAYER_TYPE_HARDWARE, null)

            setupWebSettings(settings)

            webChromeClient =
                object : WebChromeClient() {
                  override fun onPermissionRequest(request: PermissionRequest?) {
                    runOnUiThread {
                      request?.grant(request.resources)
                    }
                  }

                  override fun onConsoleMessage(consoleMessage: android.webkit.ConsoleMessage?): Boolean {
                    android.util.Log.d(
                        "SidekickWeb",
                        "${consoleMessage?.message()} [line ${consoleMessage?.lineNumber()}]")
                    return true
                  }
                }

            webViewClient =
                object : WebViewClient() {
                  override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                  }
                }

            addJavascriptInterface(AndroidBridge(), "AndroidBridge")
            loadUrl("file:///android_asset/index.html")
          }
        },
        update = { webViewInstance -> webView = webViewInstance })
  }

  @SuppressLint("SetJavaScriptEnabled")
  private fun setupWebSettings(settings: WebSettings) {
    settings.apply {
      javaScriptEnabled = true
      domStorageEnabled = true
      databaseEnabled = true
      allowFileAccess = true
      allowContentAccess = true
      allowFileAccessFromFileURLs = true
      allowUniversalAccessFromFileURLs = true
      mediaPlaybackRequiresUserGesture = false
      mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
      cacheMode = WebSettings.LOAD_DEFAULT
      setSupportZoom(false)
      displayZoomControls = false
      useWideViewPort = true
      loadWithOverviewMode = true
    }
  }

  inner class AndroidBridge {
    @JavascriptInterface
    fun startListening() {
      runOnUiThread {
        if (ContextCompat.checkSelfPermission(
            this@MainActivity, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED) {
          val intent =
              Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(
                    RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.US.toLanguageTag())
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
              }
          speechRecognizer?.startListening(intent)
        } else {
          requestPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
      }
    }

    @JavascriptInterface
    fun stopListening() {
      runOnUiThread { speechRecognizer?.stopListening() }
    }

    @JavascriptInterface
    fun speak(text: String, pitch: Float, speed: Float) {
      runOnUiThread {
        tts?.setPitch(pitch)
        tts?.setSpeechRate(speed)
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "sidekick_utterance")
      }
    }

    @JavascriptInterface
    fun playNativeBlueprintAudio() {
      runOnUiThread {
        try {
          mediaPlayer?.release()
          val afd = assets.openFd("deadpool_voice.mp3")
          mediaPlayer =
              MediaPlayer().apply {
                setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                prepare()
                start()
                setOnCompletionListener {
                  webView?.post {
                    webView?.evaluateJavascript(
                        "if (window.onBlueprintFinished) window.onBlueprintFinished();", null)
                  }
                }
              }
        } catch (e: Exception) {
          e.printStackTrace()
        }
      }
    }

    @JavascriptInterface
    fun stopNativeBlueprintAudio() {
      runOnUiThread {
        try {
          mediaPlayer?.stop()
          mediaPlayer?.release()
          mediaPlayer = null
        } catch (e: Exception) {
          e.printStackTrace()
        }
      }
    }

    @JavascriptInterface
    fun captureScreen(): String {
      val view = webView ?: return ""
      val bitmap =
          Bitmap.createBitmap(
              view.width.coerceAtLeast(1), view.height.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
      val canvas = Canvas(bitmap)
      view.draw(canvas)
      val outputStream = ByteArrayOutputStream()
      bitmap.compress(Bitmap.CompressFormat.JPEG, 80, outputStream)
      val byteArray = outputStream.toByteArray()
      return Base64.encodeToString(byteArray, Base64.NO_WRAP)
    }

    @JavascriptInterface
    fun getStoredApiKey(): String {
      return prefs.getString("openrouter_key", "") ?: ""
    }

    @JavascriptInterface
    fun saveApiKey(key: String) {
      prefs.edit().putString("openrouter_key", key).apply()
    }
  }

  override fun onDestroy() {
    super.onDestroy()
    speechRecognizer?.destroy()
    tts?.stop()
    tts?.shutdown()
    mediaPlayer?.release()
    mediaPlayer = null
  }
}
