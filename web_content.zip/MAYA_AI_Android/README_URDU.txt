MAYA AI Android APK project — Urdu guide

اہم: یہ Android project ہے، APK فائل ابھی اس ZIP میں تیار نہیں ہے۔

موبائل سے APK بنانے کے لیے:
1) ZIP کو download کرکے Extract کریں۔
2) AndroidIDE جیسی Android Gradle IDE ایپ انسٹال کریں جو Android projects build کرتی ہو۔
3) Extract کیے گئے MAYA_AI_Android فولڈر کو AndroidIDE میں Open Project کریں۔
4) Gradle sync/build مکمل ہونے دیں؛ پہلی بار انٹرنیٹ اور کافی خالی جگہ درکار ہوگی۔
5) Build menu سے Assemble/Build APK منتخب کریں۔
6) کامیابی کے بعد app/build/outputs/apk/debug/app-debug.apk میں APK ملے گی۔ اسے کھول کر Install کریں۔ اگر پوچھے تو صرف اسی installer کے لیے “Install unknown apps” اجازت دیں۔

نوٹ:
- یہ HTML والا starter app ہے۔ موجودہ HTML میں جواب demo rules سے آتے ہیں، حقیقی AI نہیں۔
- 3D avatar کے لیے internet ضروری ہے کیونکہ Three.js CDN سے لوڈ ہوتا ہے۔
- Voice recognition ہر Android WebView پر لازمی نہیں چلتی؛ اگر mic کام نہ کرے تو Chrome میں HTML چلا کر جانچیں یا بعد میں native speech integration کریں۔
- یہ پروجیکٹ debug APK بناتا ہے؛ Play Store کے لیے signed release build الگ ہوگا۔
