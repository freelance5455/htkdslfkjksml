import { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = { appId: 'com.sayed.appleguess', appName: 'Apple Guess', webDir: 'www' };
export default config;
