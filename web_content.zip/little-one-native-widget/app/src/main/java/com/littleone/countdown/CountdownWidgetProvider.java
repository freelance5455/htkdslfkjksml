package com.littleone.countdown;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import java.util.Calendar;

public class CountdownWidgetProvider extends AppWidgetProvider {
    private static String remainingDays() {
        Calendar now = Calendar.getInstance();
        Calendar target = Calendar.getInstance();
        target.set(2026, Calendar.DECEMBER, 22, 9, 0, 0);
        target.set(Calendar.MILLISECOND, 0);
        long diff = target.getTimeInMillis() - now.getTimeInMillis();
        if (diff <= 0) return "Today is the day! ❤️";
        long days = (diff + 86_400_000L - 1) / 86_400_000L;
        return days + (days == 1 ? " DAY TO GO" : " DAYS TO GO");
    }

    static void updateOne(Context context, AppWidgetManager manager, int id) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.countdown_widget);
        views.setTextViewText(R.id.widget_count, remainingDays());
        Intent launch = new Intent(context, MainActivity.class);
        PendingIntent pending = PendingIntent.getActivity(context, 0, launch,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_root, pending);
        manager.updateAppWidget(id, views);
    }

    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) updateOne(context, manager, id);
    }

    @Override public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (AppWidgetManager.ACTION_APPWIDGET_UPDATE.equals(intent.getAction())) {
            AppWidgetManager manager = AppWidgetManager.getInstance(context);
            int[] ids = manager.getAppWidgetIds(new ComponentName(context, CountdownWidgetProvider.class));
            for (int id : ids) updateOne(context, manager, id);
        }
    }
}
