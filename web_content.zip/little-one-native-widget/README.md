# Little One — Android app + home-screen widget

This Android Studio project combines the existing Little One countdown website with a native Android home-screen widget.

## Widget features
- Pastel card design matching Little One
- Countdown to December 22, 2026 at 9:00 AM using the phone's local timezone
- Tapping the widget opens the app
- Android schedules widget refreshes no more frequently than every 30 minutes; launch/update events also refresh it

## Build
Open this folder in Android Studio (Giraffe or newer), allow Gradle sync, then choose **Build > Build App Bundle(s) / APK(s) > Build APK(s)**. The debug APK is normally written to `app/build/outputs/apk/debug/app-debug.apk`.

## Install and add widget
1. Install the built APK on the phone.
2. Long-press an empty area of the home screen.
3. Choose **Widgets**, find **Little One**, then drag the widget onto the home screen.

This source package is not itself an APK. It needs to be compiled with Android Studio / Android SDK.
