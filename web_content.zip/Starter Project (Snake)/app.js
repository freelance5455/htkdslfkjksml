/* ==========================================
   SMART HOME DASHBOARD
   Main application
========================================== */


/* ==========================================
   PROFILES
========================================== */

const profiles = {

    Mum: {
        pin: "2013",
        canSendNtfy: true
    },

    Dad: {
        pin: "6936",
        canSendNtfy: true
    },

    Jacob: {
        pin: "8525",
        canSendNtfy: false
    },

    Sister: {
        pin: "2017",
        canSendNtfy: false
    }

};


let selectedProfile = null;
let enteredPin = "";
let notifications = [];


/* ==========================================
   STARTUP
========================================== */

const startupMessages = [
    "Starting system...",
    "Loading dashboard...",
    "Checking services...",
    "Preparing your home...",
    "System ready"
];

let progress = 0;

const startupTimer = setInterval(() => {

    progress += 20;

    document.getElementById("startupProgress").style.width =
        progress + "%";

    const index = Math.min(
        Math.floor(progress / 20),
        startupMessages.length - 1
    );

    document.getElementById("startupStatus").textContent =
        startupMessages[index];

    if (progress >= 100) {

        clearInterval(startupTimer);

        setTimeout(() => {
            showScreen("profiles");
        }, 500);

    }

}, 450);


/* ==========================================
   SCREEN CONTROL
========================================== */

function showScreen(id) {

    document.querySelectorAll(".screen").forEach(screen => {
        screen.classList.remove("active");
    });

    const target = document.getElementById(id);

    if (target) {
        target.classList.add("active");
    }

}


/* ==========================================
   CLOCK
========================================== */

function updateClock() {

    const now = new Date();

    const time = now.toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit"
    });

    const date = now.toLocaleDateString([], {
        weekday: "long",
        day: "numeric",
        month: "long"
    });

    const profileClock =
        document.getElementById("profileClock");

    const mainTime =
        document.getElementById("mainTime");

    const mainDate =
        document.getElementById("mainDate");

    if (profileClock) {
        profileClock.textContent = time;
    }

    if (mainTime) {
        mainTime.textContent = time;
    }

    if (mainDate) {
        mainDate.textContent = date;
    }

}

setInterval(updateClock, 1000);
updateClock();


/* ==========================================
   PROFILE SELECTION
========================================== */

function chooseProfile(name) {

    selectedProfile = name;
    enteredPin = "";

    document.getElementById("pinName").textContent =
        name;

    const avatar =
        document.getElementById("selectedAvatar");

    avatar.textContent = name.charAt(0);

    avatar.className =
        "avatar large-avatar avatar-" +
        name.toLowerCase();

    updatePinDots();

    document.getElementById("pinError")
        .classList.remove("show");

    showScreen("pinScreen");
}


function backToProfiles() {

    selectedProfile = null;
    enteredPin = "";

    showScreen("profiles");

}


/* ==========================================
   PIN
========================================== */

function pinPress(number) {

    if (enteredPin.length >= 4) {
        return;
    }

    enteredPin += number;

    updatePinDots();

    if (enteredPin.length === 4) {

        setTimeout(checkPin, 180);

    }

}


function deletePin() {

    enteredPin =
        enteredPin.slice(0, -1);

    updatePinDots();

}


function updatePinDots() {

    const dots =
        document.querySelectorAll("#pinDots i");

    dots.forEach((dot, index) => {

        dot.classList.toggle(
            "filled",
            index < enteredPin.length
        );

    });

}


function checkPin() {

    if (
        selectedProfile &&
        profiles[selectedProfile].pin === enteredPin
    ) {

        login();

    } else {

        const pinContainer =
            document.querySelector(".pin-container");

        const error =
            document.getElementById("pinError");

        error.classList.add("show");

        pinContainer.classList.remove("shake");

        void pinContainer.offsetWidth;

        pinContainer.classList.add("shake");

        enteredPin = "";

        setTimeout(updatePinDots, 100);

    }

}


/* ==========================================
   LOGIN
========================================== */

function login() {

    const name =
        selectedProfile;

    document.getElementById("welcomeName").textContent =
        "Welcome back, " + name + ".";

    updateGreeting();

    configurePermissions();

    showScreen("dashboard");

}


/* ==========================================
   GREETING
========================================== */

function updateGreeting() {

    const hour =
        new Date().getHours();

    let greeting = "Good evening";

    if (hour < 12) {
        greeting = "Good morning";
    } else if (hour < 18) {
        greeting = "Good afternoon";
    }

    document.getElementById("greeting").textContent =
        greeting;

}


/* ==========================================
   NTFY PERMISSIONS
========================================== */

function configurePermissions() {

    const sendPanel =
        document.getElementById(
            "sendNotificationPanel"
        );

    if (
        selectedProfile &&
        profiles[selectedProfile].canSendNtfy
    ) {

        sendPanel.style.display = "block";

    } else {

        sendPanel.style.display = "none";

    }

}


/* ==========================================
   NTFY SEND
========================================== */

const messageBox =
    document.getElementById("notificationMessage");

if (messageBox) {

    messageBox.addEventListener("input", () => {

        document.getElementById(
            "characterCount"
        ).textContent =
            messageBox.value.length + " / 250";

    });

}


function sendNotification() {

    if (
        !selectedProfile ||
        !profiles[selectedProfile].canSendNtfy
    ) {

        return;

    }

    const box =
        document.getElementById(
            "notificationMessage"
        );

    const message =
        box.value.trim();

    if (!message) {

        box.focus();

        return;

    }


    const notification = {

        title:
            "From " + selectedProfile,

        message:
            message,

        time:
            new Date().toLocaleTimeString([], {
                hour: "2-digit",
                minute: "2-digit"
            })

    };


    notifications.unshift(notification);

    renderNotifications();

    box.value = "";

    document.getElementById(
        "characterCount"
    ).textContent = "0 / 250";


    /*
       FUTURE NTFY CONNECTION

       When you're ready to connect your
       real ntfy topic, the publish request
       can go here.

       Example:

       fetch("https://ntfy.sh/YOUR_TOPIC", {
           method: "POST",
           body: message
       });

    */

}


/* ==========================================
   NOTIFICATION DISPLAY
========================================== */

function renderNotifications() {

    const list =
        document.getElementById(
            "notificationList"
        );

    if (!notifications.length) {

        list.innerHTML = `
            <div class="notification-item">
                <div class="notification-item-icon">✓</div>
                <div>
                    <strong>No new notifications</strong>
                    <p>Your notification inbox is clear.</p>
                </div>
            </div>
        `;

        document.getElementById(
            "notificationCount"
        ).textContent = "0 NEW";

        return;

    }


    list.innerHTML =
        notifications.map(notification => `

            <div class="notification-item">

                <div class="notification-item-icon">
                    ♢
                </div>

                <div>
                    <strong>
                        ${escapeHtml(notification.title)}
                    </strong>

                    <p>
                        ${escapeHtml(notification.message)}
                    </p>
                </div>

                <time>
                    ${notification.time}
                </time>

            </div>

        `).join("");


    document.getElementById(
        "notificationCount"
    ).textContent =
        notifications.length + " NEW";

}


function clearNotifications() {

    notifications = [];

    renderNotifications();

}


/* ==========================================
   NOTIFICATIONS PAGE
========================================== */

function openNotifications() {

    let content = `
        <span class="eyebrow">NTFY</span>
        <h1>Notifications</h1>
        <p style="color:#9297a3">
            Messages received by Smart Home DashBoard.
        </p>
    `;


    if (!notifications.length) {

        content += `
            <div class="overlay-notification">
                ✓ No new notifications
            </div>
        `;

    } else {

        notifications.forEach(notification => {

            content += `
                <div class="overlay-notification">
                    <strong>
                        ${escapeHtml(notification.title)}
                    </strong>

                    <p>
                        ${escapeHtml(notification.message)}
                    </p>

                    <small style="color:#666b77">
                        ${notification.time}
                    </small>
                </div>
            `;

        });

    }


    showOverlay(content);

}


/* ==========================================
   SPOTIFY
========================================== */

function openSpotify() {

    /*
       :// attempts to launch
       the installed Android Spotify app.
    */

    window.location.href = "spotify://";


    /*
       If the app isn't installed,
       open Spotify web after a short delay.
    */

    setTimeout(() => {

        window.location.href =
            "https://open.spotify.com/";

    }, 1200);

}


function spotifyPrevious() {

    window.location.href =
        "spotify://";

}


function spotifyNext() {

    window.location.href =
        "spotify://";

}


/* ==========================================
   SYSTEM INFO
========================================== */

function showAbout() {

    const content = `

        <span class="eyebrow">
            SYSTEM
        </span>

        <h1>
            Smart Home DashBoard
        </h1>

        <p style="color:#9297a3">
            Personal smart-home dashboard.
        </p>

        <div class="overlay-notification">
            <strong>
                Logged in as
            </strong>

            <p>
                ${selectedProfile || "Guest"}
            </p>
        </div>

        <div class="overlay-notification">
            <strong>
                NTFY access
            </strong>

            <p>
                ${
                    selectedProfile &&
                    profiles[selectedProfile].canSendNtfy
                    ? "Send + Receive"
                    : "Receive only"
                }
            </p>
        </div>

        <div class="overlay-notification">
            <strong>
                System status
            </strong>

            <p>
                ● Online
            </p>
        </div>

    `;

    showOverlay(content);

}


/* ==========================================
   OVERLAY CONTROL
========================================== */

function showOverlay(content) {

    document.getElementById(
        "overlayContent"
    ).innerHTML = content;

    document.getElementById(
        "overlay"
    ).classList.add("show");

}


function closeOverlay() {

    document.getElementById(
        "overlay"
    ).classList.remove("show");

}


/* ==========================================
   LOGOUT
========================================== */

function logout() {

    selectedProfile = null;
    enteredPin = "";

    notifications = [];

    closeOverlay();

    showScreen("profiles");

}


/* ==========================================
   SECURITY
========================================== */

function escapeHtml(value) {

    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");

}


/* ==========================================
   KEYBOARD SUPPORT
========================================== */

document.addEventListener("keydown", event => {

    if (
        document.getElementById("pinScreen")
            .classList.contains("active")
    ) {

        if (/^[0-9]$/.test(event.key)) {

            pinPress(event.key);

        }

        if (event.key === "Backspace") {

            deletePin();

        }

    }

    if (event.key === "Escape") {

        closeOverlay();

    }

});


/* ==========================================
   INITIALISE
========================================== */

updateGreeting();
renderNotifications(); function openSpotify() {
    // Try to open the Spotify Android app
    window.location.href = "intent://#Intent;package=com.spotify.music;scheme=spotify;end";
    
    // Fallback to Spotify Web Player after a short delay
    setTimeout(() => {
        window.location.href = "https://open.spotify.com/";
    }, 1200);
}