import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.neoimmune.ai',
  appName: 'NEOEVO',
  webDir: 'www',
  bundledWebRuntime: false
};

export default config;
