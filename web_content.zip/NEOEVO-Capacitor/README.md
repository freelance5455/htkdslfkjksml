# NEOEVO — Capacitor Android Project

This project packages the uploaded NEOIMMUNE AI Lab `index.html` as a Capacitor app.

## App metadata

- App name: NEOEVO
- App ID / package name: com.neoimmune.ai
- Version: 1.0.0
- Web directory: www
- Entry file: www/index.html

## Build on a computer

Requirements:
- Node.js
- Android Studio
- Android SDK / emulator or Android device

Run:

```bash
npm install
npm install @capacitor/android
npx cap add android
npx cap sync
npx cap open android
```

Then build the APK from Android Studio.

For a later web update:

```bash
npx cap copy
npx cap sync
```

## Important

The original uploaded website is kept as the app content. Its existing educational/research disclaimer remains unchanged.

This project does not turn the simulation into a clinical or medical decision-making application.
