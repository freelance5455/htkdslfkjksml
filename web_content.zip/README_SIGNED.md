# CHALA GENERAL TRADING PLC — signed Android build

This project is configured for a signed **release APK**.

## Build on Windows
1. Install Android Studio with the Android SDK and Build Tools.
2. Open this folder in Android Studio.
3. Let Gradle sync and install any requested SDK components.
4. Run `build_release.bat`, or use **Build > Generate App Bundles or APKs > Generate APKs**.
5. The signed APK will be:
   `app/build/outputs/apk/release/app-release.apk`
6. Copy that APK to your Android phone and open it to install.

## Signing key
The project contains `coffee-trade-release.jks` and `keystore.properties` so the release build is signed automatically.

**Important:** Keep `coffee-trade-release.jks` private. Anyone who gets this key and its password can sign future updates as the same app identity. For a production/public release, replace the included development signing key with a securely stored private key.

## App identity
- Package: `com.coffeetrade.erp`
- Version: 1.0 (versionCode 1)
- Minimum Android: 6.0 (API 23)
- Target Android: API 35
