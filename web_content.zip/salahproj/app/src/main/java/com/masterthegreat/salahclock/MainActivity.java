package com.masterthegreat.salahclock;

import android.Manifest;
import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView web;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setGeolocationEnabled(true);
        web.addJavascriptInterface(new WidgetBridge(this), "SalahWidget");
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                boolean granted = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
                if (granted) callback.invoke(origin, true, false);
                else { pendingGeoOrigin = origin; pendingGeoCallback = callback; requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 741); }
            }
        });
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }
    private String pendingGeoOrigin; private GeolocationPermissions.Callback pendingGeoCallback;
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == 741 && pendingGeoCallback != null) { boolean ok = false; for (int r : results) if (r == PackageManager.PERMISSION_GRANTED) ok = true; pendingGeoCallback.invoke(pendingGeoOrigin, ok, false); pendingGeoCallback = null; pendingGeoOrigin = null; }
    }
    public static class WidgetBridge {
        private final Context c; WidgetBridge(Context context) { c = context.getApplicationContext(); }
        @JavascriptInterface public void sync(String json) {
            try {
                JSONObject o = new JSONObject(json);
                android.content.SharedPreferences.Editor e = c.getSharedPreferences("salah_widget", Context.MODE_PRIVATE).edit();
                e.putString("city", o.optString("city", "Choose city in Salah Clock"));
                String[] keys = {"fajr", "sunrise", "dhuhr", "asr", "maghrib", "isha"};
                for (String k : keys) e.putString(k, o.optString(k, "--:--"));
                e.putLong("synced_at", System.currentTimeMillis()); e.apply();
                AppWidgetManager m = AppWidgetManager.getInstance(c);
                int[] ids = m.getAppWidgetIds(new ComponentName(c, PrayerWidgetProvider.class));
                new PrayerWidgetProvider().onUpdate(c, m, ids);
            } catch (Exception ignored) { }
        }
    }
    @Override public void onBackPressed() { if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
