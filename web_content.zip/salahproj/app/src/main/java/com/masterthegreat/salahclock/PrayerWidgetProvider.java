package com.masterthegreat.salahclock;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/** Native home-screen widget. Default prayer calculation is Karachi method for Lahore, Pakistan. */
public class PrayerWidgetProvider extends AppWidgetProvider {
    private static final double LAT = 31.5497, LON = 74.3436;
    private static final String[] IDS = {"fajr", "sunrise", "dhuhr", "asr", "maghrib", "isha"};
    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) update(context, manager, id);
    }
    @Override public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        String a = intent.getAction();
        if (Intent.ACTION_TIME_CHANGED.equals(a) || Intent.ACTION_DATE_CHANGED.equals(a) || Intent.ACTION_TIMEZONE_CHANGED.equals(a) || Intent.ACTION_BOOT_COMPLETED.equals(a)) {
            AppWidgetManager m = AppWidgetManager.getInstance(context);
            for (int id : m.getAppWidgetIds(new android.content.ComponentName(context, PrayerWidgetProvider.class))) update(context, m, id);
        }
    }
    private void update(Context c, AppWidgetManager mgr, int id) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_salah_clock);
        Intent open = new Intent(c, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(c, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        v.setOnClickPendingIntent(R.id.widget_root, pi);
        android.content.SharedPreferences prefs = c.getSharedPreferences("salah_widget", 0);
        String city = prefs.getString("city", "Lahore • Pakistan");
        v.setTextViewText(R.id.widget_city, city + "  |  " + new SimpleDateFormat("EEE, d MMM", Locale.ENGLISH).format(new Date()));
        String[] keys = {"fajr", "sunrise", "dhuhr", "asr", "maghrib", "isha"};
        String[] times = new String[keys.length];
        boolean hasSynced = prefs.contains("fajr");
        for (int i=0;i<keys.length;i++) times[i] = prefs.getString(keys[i], "--:--");
        if (!hasSynced) times = prayerTimes();
        int[] viewIds = {R.id.fajr, R.id.sunrise, R.id.dhuhr, R.id.asr, R.id.maghrib, R.id.isha};
        for (int i=0; i<viewIds.length; i++) v.setTextViewText(viewIds[i], times[i]);
        mgr.updateAppWidget(id, v);
    }
    private String[] prayerTimes() {
        Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("Asia/Karachi"));
        int y=cal.get(Calendar.YEAR), m=cal.get(Calendar.MONTH)+1, d=cal.get(Calendar.DAY_OF_MONTH);
        double jd = julianDay(y,m,d), g = rad(norm(357.529 + .98560028*(jd-2451545))), q=norm(280.459 + .98564736*(jd-2451545));
        double L=rad(norm(q+1.915*Math.sin(g)+.020*Math.sin(2*g))), e=rad(23.439-.000000036*(jd-2451545));
        double ra=norm(Math.toDegrees(Math.atan2(Math.cos(e)*Math.sin(L),Math.cos(L)))/15);
        double dec=Math.asin(Math.sin(e)*Math.sin(L));
        double eq=q/15-ra; if(eq>12)eq-=24; if(eq < -12)eq+=24;
        double noon=12 + 5.0 - LON/15 - eq; // Pakistan Standard Time UTC+5
        double lat=rad(LAT);
        double[] hours = new double[6];
        hours[0]=noon-hourAngle(-18,lat,dec); // Fajr: Karachi calculation angle
        hours[1]=noon-hourAngle(-0.833,lat,dec);
        hours[2]=noon;
        double asrAlt=Math.atan(1.0/(2.0+Math.tan(Math.abs(lat-dec))));
        hours[3]=noon+Math.acos((Math.sin(asrAlt)-Math.sin(lat)*Math.sin(dec))/(Math.cos(lat)*Math.cos(dec)))*180/Math.PI/15;
        hours[4]=noon+hourAngle(-0.833,lat,dec);
        hours[5]=noon+hourAngle(-18,lat,dec); // Isha: Karachi calculation angle
        String[] out=new String[6];
        for(int i=0;i<6;i++) {
            int mins=(int)Math.round(hours[i]*60); mins=((mins%1440)+1440)%1440;
            out[i]=String.format(Locale.ENGLISH,"%02d:%02d",mins/60,mins%60);
        }
        return out;
    }
    private static double hourAngle(double altitude, double lat, double dec) {
        double x=(Math.sin(rad(altitude))-Math.sin(lat)*Math.sin(dec))/(Math.cos(lat)*Math.cos(dec));
        x=Math.max(-1,Math.min(1,x)); return Math.acos(x)*180/Math.PI/15;
    }
    private static double julianDay(int y,int m,int d) {
        if(m<=2){y--;m+=12;} int a=y/100,b=2-a+a/4;
        return Math.floor(365.25*(y+4716))+Math.floor(30.6001*(m+1))+d+b-1524.5;
    }
    private static double rad(double x){return x*Math.PI/180.0;}
    private static double norm(double x){return (x%360+360)%360;}
}
