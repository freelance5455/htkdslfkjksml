Salah Clock — Native Android Widget Project

Yeh Android Studio project hai, plain HTML-to-APK ZIP nahi. Original HTML app app/src/main/assets/index.html mein rakhi hai. Root par index.html ki copy sirf un builders ke liye hai jo ZIP root mein file expect karte hain.

Included:
- Native Android home-screen widget provider and layout.
- Live Android TextClock.
- Six prayer times synced from the app's selected city through the SalahWidget JavaScript bridge.
- WebView local storage and location permission support.
- Dark green digital clock design inspired by the supplied reference.

Build instructions:
1. Extract this ZIP.
2. Open the salahproj folder in Android Studio (not the ZIP root).
3. Allow Gradle sync and install Android SDK 35 if requested.
4. Use Build > Build APK(s).
5. Install the APK. On the launcher, long-press the home screen > Widgets > Salah Clock.

Important:
- A generic ZIP-to-APK builder will not compile the native Java widget files. Build the salahproj Android Studio project.
- Open the app once and select your city; the web app pushes current prayer times to the widget. The widget updates when the app syncs.
- Android launcher and battery policies can limit background refresh. Prayer times should be checked against your trusted local timetable before relying on them for worship.
- This is a source project, not a compiled/tested APK. No Android SDK/Gradle build environment was available here to verify a build.
