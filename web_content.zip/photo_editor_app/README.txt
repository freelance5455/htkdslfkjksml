PHOTO STUDIO — Mobile Photo Editor

Included features:
- Open photo from device
- Brightness, contrast, saturation, warmth and blur controls
- Vivid, black & white, sepia, warm, cool, vintage and dramatic filters
- Add text with color, size and placement
- Finger drawing with color and brush size
- Center crop presets: square, 4:5, 9:16, 16:9 and 3:2
- Rotate, flip, grayscale, invert and vignette
- Undo/redo history and PNG export
- Responsive layout for Android mobile browsers
- Editing runs locally in the browser; images are not uploaded to a server

HOW TO USE ON ANDROID
1. Extract the ZIP file.
2. Open index.html with Chrome or another modern browser.
3. Tap “फोटो खोलें”, choose a picture, edit, then tap “Save Photo”.

NOTE
This is a browser-based starter app, not a signed Android APK. To publish as an APK, it needs to be wrapped in an Android WebView/Capacitor project and built with Android tooling. Some advanced features (AI background removal, object eraser, cloud sync, RAW editing) require additional models/services and are not included in this offline starter.
