NOOB PARKOUR 1 — PROJETO ANDROID
Créditos do jogo: Xbolos

Este pacote contém o projeto Android que abre o jogo HTML dentro de um WebView,
em tela cheia e orientação horizontal. O código do jogo fica dentro do APK como
recurso do aplicativo; isso não é proteção forte contra engenharia reversa.

COMO GERAR O APK:
1. Instale o Android Studio em https://developer.android.com/studio
2. Extraia a pasta NoobParkour1_Android.zip.
3. No Android Studio, escolha Open e selecione a pasta NoobParkour1_Android.
4. Aguarde o Gradle sincronizar. Se solicitado, instale Android SDK Platform 35
   e aceite as licenças do SDK.
5. Vá em Build > Build Bundle(s) / APK(s) > Build APK(s).
6. O APK de teste será criado em:
   app/build/outputs/apk/debug/app-debug.apk

PARA PUBLICAR:
Use Build > Generate Signed Bundle / APK e crie uma chave de assinatura.
Guarde a chave e a senha em local seguro para futuras atualizações.

OBSERVAÇÃO:
Este ambiente não tem Android SDK/Gradle instalados, então não foi possível
compilar e testar um APK aqui. O ZIP é o projeto-fonte pronto para abrir no
Android Studio e gerar o APK.
