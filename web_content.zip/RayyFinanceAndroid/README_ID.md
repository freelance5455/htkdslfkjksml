# Rayy Finance — starter aplikasi Android

Proyek ini adalah **source project Android Studio**, belum berupa APK yang siap dipasang. Proyek membungkus UI web lokal di Android WebView, sehingga animasi dan pencatatan bisa berjalan tanpa koneksi internet.

## Cara membuat APK
1. Instal Android Studio di laptop/PC.
2. Ekstrak ZIP ini.
3. Android Studio → **Open** → pilih folder `RayyFinanceAndroid`.
4. Tunggu Gradle Sync. Jika diminta, instal Android SDK Platform 35 dan Build Tools melalui SDK Manager.
5. Untuk menguji: sambungkan HP dengan USB debugging atau gunakan emulator, lalu tekan **Run ▶**.
6. Untuk APK debug: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
7. Android Studio akan menampilkan lokasi APK setelah build selesai.

## Catatan penting
- Data disimpan lokal di browser/WebView pada perangkat; belum ada sinkronisasi cloud atau login.
- Nominal transaksi awal di aplikasi adalah data contoh untuk menguji UI. Hapus/ganti sebelum digunakan sungguhan.
- Ekspor data/backup sebaiknya ditambahkan dan diuji sebelum menyimpan catatan keuangan penting.
- Ini bukan aplikasi bank dan tidak terhubung ke rekening.
- Perlu Android Studio/Android SDK untuk menghasilkan APK; lingkungan chat ini tidak dapat mengklaim APK sudah ter-build.

## Struktur
- `app/src/main/assets/index.html`: UI dan interaksi.
- `app/src/main/java/com/rayyfinance/app/MainActivity.kt`: Android WebView wrapper.
