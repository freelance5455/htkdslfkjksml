# Smart Monetization

## Model
Smart uses a freemium model:
- Free: core supported Android actions with usage limits.
- Pro Monthly: subscription product ID `smart_pro_monthly`.
- Pro Yearly: subscription product ID `smart_pro_yearly`.
- Business: company-managed licensing can be added later through the backend/dashboard.

## Google Play setup
Create the two subscription products in Play Console using the exact product IDs above and configure their base plans/offers and prices.

The app includes Google Play Billing Library 9.1.0 and a Pro purchase screen.

## Critical production step
A purchase must be verified on a secure backend using the Google Play Developer API before Pro entitlement is granted. The included endpoint is deliberately only a pending-verification hook; it does not trust client claims.

## Revenue
Revenue is not guaranteed. Earnings depend on users installing Smart and paying for Pro or company licensing. Google Play service fees apply to digital purchases/subscriptions under the applicable Play policies.

## Important
The current Android purchase screen is an integration layer, not a complete entitlement system. Do not unlock paid features permanently based only on a client callback. Production should send the purchase token to the secure backend and verify the subscription with Google's `purchases.subscriptionsv2.get` API before granting or renewing Pro access.
