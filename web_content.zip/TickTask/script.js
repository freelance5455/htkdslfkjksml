import MainApp from './js/mainApp.js';

const appContainer = document.getElementById('app');
new MainApp(appContainer);

function toggleFullscreen(){
        if(!document.fullscreenElement){
            //full screen
            document.documentElement.requestFullscreen();
            //portrait mode only
            if (screen.orientation && screen.orientation.lock) {
                    /*screen.orientation.lock('landscape-primary').catch((error) => {
                        console.warn('Failed to lock screen orientation:', error);
                    });*/
                    //this.onResize();
                }
        }else if(document.exitFullscreen){
            document.exitFullscreen();
        }
    }
window.addEventListener('click', ()=>{ //toggleFullscreen();
})