# TickTask
a 5-in-1 utility app (scientific calculator, notes, todo, clock and stopwatch)
