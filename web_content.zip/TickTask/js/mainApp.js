// mainApp.js (updated to include CalculatorApp instead of AlarmApp)
import NotesApp from './apps/notes/NotesApp.js';
import ToDoApp from './apps/todo/ToDoApp.js';
import StopwatchApp from './apps/stopwatch/StopwatchApp.js';
import ClockApp from './apps/clock/ClockApp.js';
import CalculatorApp from './apps/calculator/CalculatorApp.js';

export default class MainApp {
    constructor(container) {
        this.container = container;

        this.container.innerHTML = `

            <div id="mainContent" style="flex:1; width:100%; height:calc(100% - 50px); overflow:auto;"></div>
            <div id="bottomBar" style="height:60px; display:flex; justify-content:space-around; align-items:center; background:#102030; color:white;">
                <button data-app="notes" class="tabBtn">📝<br>Notes</button>
                <button data-app="todo" class="tabBtn">✅<br>ToDo</button>
                <button data-app="clock" class="tabBtn">⏰<br>Clock</button>
                <button data-app="calculator" class="tabBtn">🧮<br>Calculator</button>
                <button data-app="stopwatch" class="tabBtn">⏲️<br>Stopwatch</button>
            </div>
        `;
        
        Object.assign(this.container.style, {
            display: 'flex',
            flexDirection: 'column',
            height: '100%',
        });

        this.mainContent = this.container.querySelector('#mainContent');
        this.currentApp = null;

        // Map tab keys to class constructors
        this.appsMap = {
            notes: NotesApp,
            todo: ToDoApp,
            clock: ClockApp,
            calculator: CalculatorApp,
            stopwatch: StopwatchApp
        };

        // Event listeners for bottom bar
        const buttons = this.container.querySelectorAll('#bottomBar button');
        buttons.forEach(btn => {
            btn.addEventListener('click', () => {
                const key = btn.dataset.app;
                this.loadApp(key);
            });
        });

        // Load default app (Notes)
        this.loadApp('notes');
    }

    loadApp(key) {
    // Remove active state from all buttons
    const buttons = this.container.querySelectorAll('#bottomBar .tabBtn');
    buttons.forEach(btn => btn.classList.remove('activeTab'));

    // Add active state to the clicked button
    const activeBtn = this.container.querySelector(`#bottomBar button[data-app="${key}"]`);
    if (activeBtn) activeBtn.classList.add('activeTab');

    // Clear previous app content
    this.mainContent.innerHTML = "";

    // Load new app
    const AppClass = this.appsMap[key];
    if (!AppClass) return;
    new AppClass(this.mainContent);
}
}