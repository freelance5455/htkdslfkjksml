// utils.js
export function extractHeaderAndFirstLine(text) {
    const lines = text.split("\n");
    const header = lines[0] || "";
    const firstLine = lines[1] || "";
    return { header, firstLine };
}

/**
 * Format a Date object according to given date format and time format.
 * dateFormat: "YYYY-MM-DD" | "DD-MM-YYYY" | "MM-DD-YYYY"
 * timeFormat: "24" | "12"
 */
export function getCurrentTimestamp() {
    const format = localStorage.getItem("datetimeFormat") || "YYYY-MM-DD HH:mm:ss";
    return formatTimestamp(new Date(), format);
}

export function formatTimestamp(date, format) {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, "0");
    const d = String(date.getDate()).padStart(2, "0");
    const h = String(date.getHours()).padStart(2, "0");
    const min = String(date.getMinutes()).padStart(2, "0");
    const sec = String(date.getSeconds()).padStart(2, "0");

    return format
        .replace("YYYY", y)
        .replace("MM", m)
        .replace("DD", d)
        .replace("HH", h)
        .replace("mm", min)
        .replace("ss", sec);
}

window.formatTimestamp = formatTimestamp;