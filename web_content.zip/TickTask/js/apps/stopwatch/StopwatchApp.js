export default class StopwatchApp {
    constructor(container) {
        this.container = container;

        this.container.innerHTML = `
            <div id="stopwatchContainer" style="display:flex; flex-direction:column; align-items:center; justify-content:flex-start; height:100%; width:100%; color:white; font-family:sans-serif;">
                <p id='digital'>
                    <span id='hour'>00</span>:
                    <span id='minute'>00</span>:
                    <span id='second'>00</span>:
                    <span id='millisecond'>00</span>
                </p>

                <div id='buttons' style="margin:10px; display:flex; gap:10px;">
                    <button id="start" class="tabBtn">START</button>
                    <button id="stop" class="tabBtn">STOP</button>
                    <button id="reset" class="tabBtn">RESET</button>
                </div>

                <canvas id='canvas'></canvas>
            </div>
        `;

        // Elements
        this.hourEl = this.container.querySelector('#hour');
        this.minuteEl = this.container.querySelector('#minute');
        this.secondEl = this.container.querySelector('#second');
        this.milliEl = this.container.querySelector('#millisecond');

        this.startBtn = this.container.querySelector('#start');
        this.stopBtn = this.container.querySelector('#stop');
        this.resetBtn = this.container.querySelector('#reset');

        this.canvas = this.container.querySelector('#canvas');
        this.ctx = this.canvas.getContext('2d');

        // State
        this.running = false;
        this.interval = null;

        // Setup canvas
        this.setupCanvas();

        // Bind events
        this.startBtn.addEventListener('click', () => { if(!this.running) this.start(); });
        this.stopBtn.addEventListener('click', () => this.stop());
        this.resetBtn.addEventListener('click', () => this.reset());

        // Start animation loop
        requestAnimationFrame(() => this.drawLoop());
    }

    setupCanvas() {
        this.canvas.width = this.canvas.height = 360;
        this.radius = this.canvas.width * 0.5;
        this.ctx.translate(this.radius, this.radius);

        // Dark theme styles
        this.canvas.style.backgroundColor = '#102030';
        this.canvas.style.border = '8px solid #0a1a2f';
        this.canvas.style.borderRadius = '50%';
    }

    start() {
        this.running = true;
        this.interval = setInterval(() => {
            this.milliEl.innerHTML++;
            if (this.milliEl.innerHTML > 99) {
                this.secondEl.innerHTML++;
                this.milliEl.innerHTML = 0;
            }
            if (this.secondEl.innerHTML > 59) {
                this.minuteEl.innerHTML++;
                this.secondEl.innerHTML = 0;
            }
            if (this.minuteEl.innerHTML > 59) {
                this.hourEl.innerHTML++;
                this.minuteEl.innerHTML = 0;
            }
            this.addZero();
        }, 10);
    }

    stop() {
        clearInterval(this.interval);
        this.running = false;
    }

    reset() {
        this.running = false;
        this.hourEl.innerHTML = this.minuteEl.innerHTML = this.secondEl.innerHTML = this.milliEl.innerHTML = '00';
    }

    addZero() {
        if (parseInt(this.hourEl.innerHTML) < 10) this.hourEl.innerHTML = '0' + parseInt(this.hourEl.innerHTML);
        if (parseInt(this.minuteEl.innerHTML) < 10) this.minuteEl.innerHTML = '0' + parseInt(this.minuteEl.innerHTML);
        if (parseInt(this.secondEl.innerHTML) < 10) this.secondEl.innerHTML = '0' + parseInt(this.secondEl.innerHTML);
        if (parseInt(this.milliEl.innerHTML) < 10) this.milliEl.innerHTML = '0' + parseInt(this.milliEl.innerHTML);
    }

    drawLoop() {
        const ctx = this.ctx;
        const radius = this.radius;
        ctx.clearRect(-radius, -radius, this.canvas.width, this.canvas.height);

        this.drawClockFace();
        this.drawMillisecondStrokes();
        this.drawSecondStrokes();
        this.drawNumbers();
        this.drawHands();

        requestAnimationFrame(() => this.drawLoop());
    }

    drawClockFace() {
        const ctx = this.ctx;
        const radius = this.radius;

        ctx.save();
        const grad = ctx.createRadialGradient(0, 0, radius * 0.9, 0, 0, radius);
        grad.addColorStop(0, '#102030');
        grad.addColorStop(0.5, '#0a1a2f');
        grad.addColorStop(1, '#1a2a3f');

        ctx.strokeStyle = grad;
        ctx.lineWidth = radius * 0.1;
        ctx.beginPath();
        ctx.arc(0, 0, radius * 0.9, 0, Math.PI * 2);
        ctx.stroke();
        ctx.closePath();
        ctx.restore();
    }

    drawMillisecondStrokes() {
        const ctx = this.ctx;
        const radius = this.radius;
        ctx.fillStyle = '#0af';
        for (let i = 0; i < 100; i++) {
            ctx.save();
            const angle = i * Math.PI / 50;
            ctx.rotate(angle);
            ctx.fillRect(0, -radius * 0.8, 2, 6);
            ctx.restore();
        }
    }

    drawSecondStrokes() {
        const ctx = this.ctx;
        const radius = this.radius;
        ctx.fillStyle = 'gold';
        for (let i = 0; i < 60; i += 6) {
            ctx.save();
            const angle = i * Math.PI / 30;
            ctx.rotate(angle);
            ctx.fillRect(0, -radius * 0.8, 3, 10);
            ctx.restore();
        }
    }

    drawNumbers() {
        const ctx = this.ctx;
        const radius = this.radius;
        ctx.fillStyle = 'white';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.font = `${radius * 0.1}px sans-serif`;
        for (let i = 0; i < 60; i += 6) {
            ctx.save();
            const angle = i * Math.PI / 30;
            ctx.rotate(angle);
            ctx.translate(0, -radius * 0.65);
            ctx.rotate(-angle);
            ctx.fillText(i, 0, 0);
            ctx.restore();
        }
    }

    drawHands() {
        const ctx = this.ctx;
        const radius = this.radius;

        // Millisecond hand
        ctx.save();
        ctx.strokeStyle = '#0af';
        ctx.lineWidth = 2;
        ctx.lineCap = 'round';
        ctx.rotate(parseInt(this.milliEl.innerHTML) * Math.PI / 50);
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(0, -radius * 0.8);
        ctx.stroke();
        ctx.closePath();
        ctx.restore();

        // Second hand
        ctx.save();
        ctx.strokeStyle = 'gold';
        ctx.lineWidth = 2;
        const secAngle = parseInt(this.secondEl.innerHTML) * Math.PI / 30;
        ctx.rotate((secAngle) + secAngle/360);
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(0, -radius * 0.75);
        ctx.stroke();
        ctx.closePath();
        ctx.restore();

        // Minute hand
        ctx.save();
        ctx.strokeStyle = 'orange';
        ctx.lineWidth = 6;
        ctx.rotate(parseInt(this.minuteEl.innerHTML) * Math.PI / 50);
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(0, -radius * 0.45);
        ctx.stroke();
        ctx.closePath();
        ctx.restore();

        // Centre dot
        ctx.save();
        ctx.beginPath();
        ctx.arc(0, 0, radius * 0.05, 0, Math.PI * 2);
        ctx.fillStyle = 'white';
        ctx.fill();
        ctx.closePath();
        ctx.restore();
    }
}