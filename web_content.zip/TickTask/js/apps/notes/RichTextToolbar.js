export default class RichTextToolbar {
    constructor(topBars = [], editors = []) {
        this.topBars = topBars;
        this.editors = editors;

        this.fonts = [
            "Arial", "Courier New", "Georgia", "Times New Roman", "Verdana",
            "Videotype", "Planes ValMore", "Carrington", "England",
            "Freebooter Script", "Courier Prime Code"
        ];

        // mapped to execCommand sizes 1–7 (we provide only 7 sizes as requested)
        this.sizeMap = [
            {label:"8px", cmd:1},
            {label:"10px", cmd:2},
            {label:"12px", cmd:3},
            {label:"14px", cmd:4},
            {label:"16px", cmd:5},
            {label:"18px", cmd:6},
            {label:"20px", cmd:7}
        ];

        this.createToolbar();
        this.bindToolbar();
    }

    createToolbar() {
        this.topBars.forEach(bar => {
            if (!bar) return;

            const tb = document.createElement("div");
            tb.className = "richToolbar";

            // Bold
            const boldBtn = document.createElement("button");
            boldBtn.innerHTML = "<b>B</b>";
            boldBtn.className = "rtBtn";
            boldBtn.dataset.cmd = "bold";
            tb.appendChild(boldBtn);

            // Italic
            const italicBtn = document.createElement("button");
            italicBtn.innerHTML = "<i>I</i>";
            italicBtn.className = "rtBtn";
            italicBtn.dataset.cmd = "italic";
            tb.appendChild(italicBtn);

            // Underline
            const underlineBtn = document.createElement("button");
            underlineBtn.innerHTML = "<u>U</u>";
            underlineBtn.className = "rtBtn";
            underlineBtn.dataset.cmd = "underline";
            tb.appendChild(underlineBtn);

            // Font Family select
            const fontSelect = document.createElement("select");
            fontSelect.className = "rtSelect";
            fontSelect.dataset.cmd = "fontName";
            this.fonts.forEach(f=>{
                const o = document.createElement("option");
                o.value = f;
                o.innerText = f;
                fontSelect.appendChild(o);
            });
            tb.appendChild(fontSelect);

            // Font Size select (7 choices)
            const sizeSelect = document.createElement("select");
            sizeSelect.className = "rtSelect";
            sizeSelect.dataset.cmd = "fontSize";
            this.sizeMap.forEach(s=>{
                const o = document.createElement("option");
                o.value = s.cmd;
                o.innerText = s.label;
                sizeSelect.appendChild(o);
            });
            tb.appendChild(sizeSelect);

            // Color picker
            const colorInput = document.createElement("input");
            colorInput.type = "color";
            colorInput.className = "rtColor";
            colorInput.dataset.cmd = "foreColor";
            colorInput.value = "#ffffff";
            tb.appendChild(colorInput);

            bar.appendChild(tb);
        });
    }

    bindToolbar() {
        this.topBars.forEach((bar, i) => {
            const editor = this.editors[i];
            if (!bar || !editor) return;

            // Buttons
            bar.querySelectorAll(".rtBtn").forEach(btn => {
                btn.addEventListener("click", () => {
                    document.execCommand(btn.dataset.cmd, false, null);
                    this.updateActiveButtons(bar, editor);
                    editor.focus();
                });
            });

            // Selects
            bar.querySelectorAll(".rtSelect").forEach(sel => {
                sel.addEventListener("change", () => {
                    if (sel.dataset.cmd === "fontSize") {
                        // execCommand fontSize expects 1-7; we've set values accordingly
                        document.execCommand("fontSize", false, sel.value);
                    } else if (sel.dataset.cmd === "fontName") {
                        document.execCommand("fontName", false, sel.value);
                    }
                    editor.focus();
                });
            });

            // Color
            const colorPicker = bar.querySelector(".rtColor");
            if (colorPicker) {
                colorPicker.addEventListener("input", () => {
                    document.execCommand("foreColor", false, colorPicker.value);
                    editor.focus();
                });
            }

            // Keyboard shortcuts (Ctrl/Cmd + B / I / U)
            editor.addEventListener("keydown", e => {
                if (e.ctrlKey || e.metaKey) {
                    const k = e.key.toLowerCase();
                    if (k === "b") { e.preventDefault(); document.execCommand("bold"); }
                    if (k === "i") { e.preventDefault(); document.execCommand("italic"); }
                    if (k === "u") { e.preventDefault(); document.execCommand("underline"); }
                    this.updateActiveButtons(bar, editor);
                }
            });

            // Update active formatting on selection changes
            editor.addEventListener("keyup", () => this.updateActiveButtons(bar, editor));
            editor.addEventListener("mouseup", () => this.updateActiveButtons(bar, editor));
            // Also keep initial state
            editor.addEventListener("focus", () => this.updateActiveButtons(bar, editor));
        });
    }

    updateActiveButtons(bar, editor) {
        const bold = document.queryCommandState("bold");
        const italic = document.queryCommandState("italic");
        const underline = document.queryCommandState("underline");

        bar.querySelectorAll(".rtBtn").forEach(btn => {
            if (btn.dataset.cmd === "bold") btn.classList.toggle("active", bold);
            if (btn.dataset.cmd === "italic") btn.classList.toggle("active", italic);
            if (btn.dataset.cmd === "underline") btn.classList.toggle("active", underline);
        });
    }
}