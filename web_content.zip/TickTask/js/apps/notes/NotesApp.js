import { getCurrentTimestamp } from "../../utils.js";
import RichTextToolbar from "./RichTextToolbar.js";
import NotesExport from "./NotesExport.js";

export default class NotesApp {
    constructor(container) {
        this.container = container;

        // Build UI
        this.container.innerHTML = `
            <button id="floatingAddNoteBtn">✚</button>

            <div id="topBar" class="notesTopBar">
                <div class="topLeft">
                    <div class="appTitle">Notes</div>
                </div>
                <div class="topRight">
                    <button id="viewToggleBtn" title="Toggle list / grid">🔳</button>
                    <div class="exportWrap">
                        <button id="exportBtn" title="Export">⬇️ Export</button>
                        <div id="exportMenu" class="exportMenu">
                            <button data-format="pdf">Export as PDF</button>
                            <button data-format="html">Export as HTML</button>
                            <button data-format="doc">Export as DOC</button>
                            <button data-format="txt">Export as TXT</button>
                        </div>
                    </div>
                </div>
            </div>

            <div id="addPanel" class="notePanel">
                <div class="panelTopBar">
                    <button class="backArrow" id="addBackBtn">←</button>
                    <button class="panelThemeToggle" id="addThemeToggle" title="Toggle theme">🌓</button>
                    <button class="panelExportBtn" id="addExportBtn" title="Export note">📤</button>
                    <span style="color:white;">New Note</span>
                </div>
                <div id="addContentArea" contenteditable="true" aria-label="New note editor"></div>

                <!-- per-panel export menu -->
                <div id="addPanelExportMenu" class="panelExportMenu">
                    <button data-format="pdf">PDF</button>
                    <button data-format="html">HTML</button>
                    <button data-format="doc">DOC</button>
                    <button data-format="txt">TXT</button>
                </div>
            </div>

            <div id="editPanel" class="notePanel">
                <div class="panelTopBar">
                    <button class="backArrow" id="editBackBtn">←</button>
                    <button class="panelThemeToggle" id="editThemeToggle" title="Toggle theme">🌓</button>
                    <button class="panelExportBtn" id="editExportBtn" title="Export note">📤</button>
                    <span style="color:white;">Edit Note</span>
                </div>
                <div id="editContentArea" contenteditable="true" aria-label="Edit note editor"></div>

                <!-- per-panel export menu -->
                <div id="editPanelExportMenu" class="panelExportMenu">
                    <button data-format="pdf">PDF</button>
                    <button data-format="html">HTML</button>
                    <button data-format="doc">DOC</button>
                    <button data-format="txt">TXT</button>
                </div>
            </div>

            <div id="confirmModal">
                <div id="confirmBox">
                    <div style="font-size:18px;margin-bottom:10px;">Save changes?</div>
                    <button id="confirmYes">Yes</button>
                    <button id="confirmNo">No</button>
                </div>
            </div>

            <div id="noteContainer" class="noteContainer"></div>
        `;

        /* Elements */
        this.noteContainer = container.querySelector("#noteContainer");
        this.floatingBtn = container.querySelector("#floatingAddNoteBtn");

        this.topBar = container.querySelector("#topBar");
        this.viewToggleBtn = container.querySelector("#viewToggleBtn");
        this.exportBtn = container.querySelector("#exportBtn");
        this.exportMenu = container.querySelector("#exportMenu");

        this.addPanel = container.querySelector("#addPanel");
        this.addContent = container.querySelector("#addContentArea");
        this.addBackBtn = container.querySelector("#addBackBtn");
        this.addExportBtn = container.querySelector("#addExportBtn");
        this.addPanelExportMenu = container.querySelector("#addPanelExportMenu");
        this.addThemeToggle = container.querySelector("#addThemeToggle");

        this.editPanel = container.querySelector("#editPanel");
        this.editContent = container.querySelector("#editContentArea");
        this.editBackBtn = container.querySelector("#editBackBtn");
        this.editExportBtn = container.querySelector("#editExportBtn");
        this.editPanelExportMenu = container.querySelector("#editPanelExportMenu");
        this.editThemeToggle = container.querySelector("#editThemeToggle");

        this.confirmModal = container.querySelector("#confirmModal");
        this.confirmYes = container.querySelector("#confirmYes");
        this.confirmNo = container.querySelector("#confirmNo");

        /* State */
        this.notes = [];
        this.mode = null;
        this.currentIndex = null;
        this.pendingClose = null;
        this.originalContent = "";
        this.viewMode = localStorage.getItem("notesView") || "list";

        // theme init: 'dark' or 'light'
        this.theme = localStorage.getItem("notesTheme") || "dark";
        this.applyThemeToDOM();

        // Init toolbar in panel top bars
        const topBars = [
            this.addPanel.querySelector(".panelTopBar"),
            this.editPanel.querySelector(".panelTopBar")
        ];
        this.toolbar = new RichTextToolbar(topBars, [
            this.addContent,
            this.editContent
        ]);

        this.loadNotes();
        this.setupEvents();
        this.applyViewModeToDOM();

        this.exporter = new NotesExport(this.notes);
    }

    setupEvents() {
        this.floatingBtn.addEventListener("click", ()=>this.openAdd());
        this.addBackBtn.addEventListener("click", ()=>this.smartClose("add"));
        this.editBackBtn.addEventListener("click", ()=>this.smartClose("edit"));
        this.confirmYes.addEventListener("click", ()=>this.confirmSave());
        this.confirmNo.addEventListener("click", ()=>this.confirmDiscard());

        // view toggle
        this.viewToggleBtn.addEventListener("click", ()=> {
            this.viewMode = this.viewMode === "list" ? "grid" : "list";
            localStorage.setItem("notesView", this.viewMode);
            this.applyViewModeToDOM();
            this.renderNotes();
        });

        // top export menu (batch)
        this.exportBtn.addEventListener("click", (e) => {
            e.stopPropagation();
            this.exportMenu.classList.toggle("open");
        });
        document.addEventListener("click", () => {
            this.exportMenu.classList.remove("open");
            this.addPanelExportMenu.classList.remove("open");
            this.editPanelExportMenu.classList.remove("open");
        });
        this.exportMenu.querySelectorAll("button").forEach(btn => {
            btn.addEventListener("click", (e) => {
                const fmt = btn.dataset.format;
                this.exportAllNotes(fmt);
                this.exportMenu.classList.remove("open");
            });
        });

        // per-panel export buttons -> open local panel menu
        this.addExportBtn.addEventListener("click", (e) => {
            e.stopPropagation();
            this.addPanelExportMenu.classList.toggle("open");
        });
        this.editExportBtn.addEventListener("click", (e) => {
            e.stopPropagation();
            this.editPanelExportMenu.classList.toggle("open");
        });

        // per-panel export menu actions
        this.addPanelExportMenu.querySelectorAll("button").forEach(btn => {
            btn.addEventListener("click", (e) => {
                const fmt = btn.dataset.format;
                this.exportSingleFromAdd(fmt);
                this.addPanelExportMenu.classList.remove("open");
            });
        });
        this.editPanelExportMenu.querySelectorAll("button").forEach(btn => {
            btn.addEventListener("click", (e) => {
                const fmt = btn.dataset.format;
                this.exportSingleFromEdit(fmt);
                this.editPanelExportMenu.classList.remove("open");
            });
        });

        // theme toggles in panels
        this.addThemeToggle.addEventListener("click", (e) => { e.stopPropagation(); this.toggleTheme(); });
        this.editThemeToggle.addEventListener("click", (e) => { e.stopPropagation(); this.toggleTheme(); });

        // prevent clicks inside panel menus from closing them (they are stopped above, but extra safety)
        this.addPanelExportMenu.addEventListener("click", e=> e.stopPropagation());
        this.editPanelExportMenu.addEventListener("click", e=> e.stopPropagation());
    }

    applyViewModeToDOM() {
        if(this.viewMode==="grid"){
            this.noteContainer.classList.add("gridView");
            this.noteContainer.classList.remove("listView");
            this.viewToggleBtn.textContent = "📃";
            this.viewToggleBtn.title = "Switch to list view";
        } else {
            this.noteContainer.classList.add("listView");
            this.noteContainer.classList.remove("gridView");
            this.viewToggleBtn.textContent = "🔳";
            this.viewToggleBtn.title = "Switch to grid view";
        }
    }

    // theme functions
    applyThemeToDOM() {
        if(this.theme === "light") {
            this.container.classList.add("notes-light");
            this.addThemeToggle.textContent = "🌞";
            this.editThemeToggle.textContent = "🌞";
        } else {
            this.container.classList.remove("notes-light");
            this.addThemeToggle.textContent = "🌓";
            this.editThemeToggle.textContent = "🌓";
        }
    }
    toggleTheme() {
        this.theme = this.theme === "light" ? "dark" : "light";
        localStorage.setItem("notesTheme", this.theme);
        this.applyThemeToDOM();
    }

    openAdd() {
        this.mode = "add";
        this.addContent.innerHTML = "";
        this.originalContent = "";
        this.addPanel.style.display = "flex";
        this.blurBackground(true);
        this.addContent.focus();
    }

    openEdit(index) {
        this.mode = "edit";
        this.currentIndex = index;
        const n = this.notes[index];
        this.editContent.innerHTML = n.content;
        this.originalContent = n.content;
        this.editPanel.style.display = "flex";
        this.blurBackground(true);
        this.editContent.focus();
    }

    smartClose(mode) {
        const current = mode==="add" ? this.addContent.innerHTML : this.editContent.innerHTML;
        if (current === this.originalContent) {
            mode==="add" ? this.closeAdd() : this.closeEdit();
        } else {
            this.pendingClose = mode;
            this.confirmModal.style.display = "flex";
        }
    }

    confirmSave(){
        this.confirmModal.style.display="none";
        if(this.pendingClose==="add"){ this.saveNewNote(); this.closeAdd(); }
        else { this.applyEdit(); this.closeEdit(); }
    }

    confirmDiscard(){
        this.confirmModal.style.display="none";
        this.pendingClose==="add" ? this.closeAdd() : this.closeEdit();
    }

    closeAdd(){ this.addPanel.style.display="none"; this.blurBackground(false); }
    closeEdit(){ this.editPanel.style.display="none"; this.blurBackground(false); }

    blurBackground(on){
        this.noteContainer.style.filter = on ? "blur(6px)" : "none";
        this.floatingBtn.style.filter = on ? "blur(6px)" : "none";
    }

    saveNewNote(){
        const content = this.addContent.innerHTML.trim();
        if(!content) return;
        const t = getCurrentTimestamp();
        this.notes.push({content, createdAt:t, updatedAt:t});
        this.saveNotes();
        this.renderNotes();
    }

    applyEdit(){
        const content = this.editContent.innerHTML.trim();
        const t = getCurrentTimestamp();
        const n = this.notes[this.currentIndex];
        n.content = content;
        n.updatedAt = t;
        this.saveNotes();
        this.renderNotes();
    }

    deleteNote(i){
        if(confirm("Delete this note?")){
            this.notes.splice(i,1);
            this.saveNotes();
            this.renderNotes();
        }
    }

    saveNotes(){ localStorage.setItem("notes", JSON.stringify(this.notes)); }

    loadNotes(){
        const saved = JSON.parse(localStorage.getItem("notes"));
        this.notes = Array.isArray(saved) ? saved : [];
        this.renderNotes();
    }

    notePreviewContent(html) {
        return html.replace(/<[^>]+>/g, "").trim().slice(0, 220);
    }

    createNoteCard(note,index){
        const preview = this.notePreviewContent(note.content) || "(empty)";
        const card = document.createElement("div");
        card.className = "note-card";
        card.innerHTML = `
            <div class="noteCardInner">
                <div class="note-preview-text">${preview}</div>
                <div class="note-timestamp-small">${note.updatedAt}</div>
            </div>
            <div class="note-actions">
                <button class="iconBtn deleteBtn" title="Delete">🗑</button>
            </div>
        `;

        card.addEventListener("click", e=>{
            if(!e.target.classList.contains("deleteBtn")) this.openEdit(index);
        });

        card.querySelector(".deleteBtn").addEventListener("click", e=>{
            e.stopPropagation();
            this.deleteNote(index);
        });

        return card;
    }

    renderNotes(){
        this.noteContainer.innerHTML="";
        this.notes.forEach((note,index)=>{
            const card = this.createNoteCard(note,index);
            this.noteContainer.appendChild(card);
        });
    }

    // -----------------------
    // EXPORT HELPERS
    // -----------------------
    exportAllNotes(format) {
        this.exporter.setNotes(this.notes); // refresh notes
        switch(format) {
            case "txt": this.exporter.exportTXT(); break;
            case "html": this.exporter.exportHTML(); break;
            case "doc": this.exporter.exportDOC(); break;
            case "pdf": this.exporter.exportPDF(); break;
            default: console.warn("Unknown export format:", format);
        }
    }

    // Export single note from Add panel (current editor content)
    exportSingleFromAdd(format) {
        const content = this.addContent.innerHTML.trim();
        if (!content) { alert("Nothing to export."); return; }
        this.exporter.setNotes([{ content }]); // single note wrapper
        this._callExporterSingle(format, { content });
    }

    // Export single note from Edit panel (currently loaded note)
    exportSingleFromEdit(format) {
        if (this.currentIndex == null) { alert("No note is open to export."); return; }
        const note = this.notes[this.currentIndex];
        if (!note || !note.content) { alert("Nothing to export."); return; }
        this.exporter.setNotes([note]);
        this._callExporterSingle(format, note);
    }

    // internal: call NotesExport methods for one-note arrays
    _callExporterSingle(format, note) {
        switch(format) {
            case "txt": this.exporter.exportSingleTXT(note); break;
            case "html": this.exporter.exportSingleHTML(note); break;
            case "doc": this.exporter.exportSingleDOC(note); break;
            case "pdf": this.exporter.exportSinglePDF(note); break;
            default: console.warn("Unknown single export format:", format);
        }
    }

    // legacy placeholders (kept for compatibility; not used)
    exportHTML(notes){ /* unchanged */ }
    exportDOC(notes){ /* unchanged */ }
    exportTXT(notes){ /* unchanged */ }
    exportPDF(notes){ /* unchanged */ }
    buildExportHTML(notes){ /* unchanged */ }
    downloadBlob(blob, filename){ /* unchanged */ }
    escapeHtml(str=""){ /* unchanged */ }
}