export default class NotesExport {
    constructor(notes = []) {
        this.notes = notes;
    }

    setNotes(notes) {
        this.notes = notes;
    }

    // --------------------------
    // Timestamp helper (no ms)
    // --------------------------
    buildTimestamp() {
        const d = new Date();
        const pad = (n) => String(n).padStart(2, "0");

        return (
            d.getFullYear() + "-" +
            pad(d.getMonth() + 1) + "-" +
            pad(d.getDate()) + "-" +
            pad(d.getHours()) + "-" +
            pad(d.getMinutes()) + "-" +
            pad(d.getSeconds())
        );
    }

    // --------------------------
    // Export ALL notes (existing)
    // --------------------------
    exportTXT() {
        const txtContent = this.notes
            .map(n => n.content.replace(/<[^>]+>/g, ""))
            .join("\n\n---\n\n");

        const filename = `notes-${this.buildTimestamp()}.txt`;
        this.downloadBlob(new Blob([txtContent], { type: "text/plain" }), filename);
    }

    exportHTML() {
        const html = this.buildHTMLDocument(this.notes.map(n => n.content));
        const filename = `notes-${this.buildTimestamp()}.html`;

        this.downloadBlob(new Blob([html], { type: "text/html" }), filename);
    }

    exportDOC() {
        const html = this.buildHTMLDocument(this.notes.map(n => n.content));
        const filename = `notes-${this.buildTimestamp()}.doc`;

        this.downloadBlob(new Blob([html], { type: "application/msword" }), filename);
    }

    exportPDF() {
        if (!window.jsPDF) {
            alert("jsPDF library not loaded. Include it first to export PDF.");
            return;
        }

        const filename = `notes-${this.buildTimestamp()}.pdf`;

        const doc = new jsPDF();
        let y = 10;
        const lineHeight = 8;

        this.notes.forEach((note) => {
            const text = note.content.replace(/<[^>]+>/g, "").split("\n");

            text.forEach(line => {
                doc.text(line, 10, y);
                y += lineHeight;

                if (y > 280) {
                    doc.addPage();
                    y = 10;
                }
            });

            y += lineHeight;
        });

        doc.save(filename);
    }

    // --------------------------
    // EXPORT SINGLE NOTE
    // --------------------------
    exportSingleTXT(note) {
        const content = (note.content || "").replace(/<[^>]+>/g, "");
        const filename = `note-${this.buildTimestamp()}.txt`;
        this.downloadBlob(new Blob([content], { type: "text/plain" }), filename);
    }

    exportSingleHTML(note) {
        const html = this.buildHTMLDocument([note.content || ""]);
        const filename = `note-${this.buildTimestamp()}.html`;
        this.downloadBlob(new Blob([html], { type: "text/html" }), filename);
    }

    exportSingleDOC(note) {
        const html = this.buildHTMLDocument([note.content || ""]);
        const filename = `note-${this.buildTimestamp()}.doc`;
        this.downloadBlob(new Blob([html], { type: "application/msword" }), filename);
    }

    exportSinglePDF(note) {
        const filename = `note-${this.buildTimestamp()}.pdf`;

        // prefer jsPDF if available
        if (window.jsPDF) {
            const doc = new jsPDF();
            let y = 10;
            const lineHeight = 8;
            const text = (note.content || "").replace(/<[^>]+>/g, "").split("\n");

            text.forEach(line => {
                doc.text(line, 10, y);
                y += lineHeight;
                if (y > 280) { doc.addPage(); y = 10; }
            });

            doc.save(filename);
            return;
        }

        // fallback: open printable HTML window (user can Save as PDF)
        const html = this.buildHTMLDocument([note.content || ""]);
        const win = window.open("", "_blank", "noopener");
        if (!win) {
            alert("Popup blocked — allow popups for this site to export PDF.");
            return;
        }
        win.document.write(html);
        win.document.close();
        setTimeout(() => { try { win.focus(); win.print(); } catch(e){ console.warn(e); } }, 400);
    }

    // --------------------------
    // Build HTML wrapper
    // --------------------------
    buildHTMLDocument(contents) {
        const body = contents
            .map(c => `<div style="margin-bottom:20px;">${c}</div>`)
            .join("\n");

        return `
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Exported Notes</title>
            <meta name="viewport" content="width=device-width,initial-scale=1" />
            <style> body { font-family: Arial, Helvetica, sans-serif; padding:20px; }</style>
        </head>
        <body>
            ${body}
        </body>
        </html>`;
    }

    // --------------------------
    // Download helper
    // --------------------------
    downloadBlob(blob, filename) {
        const a = document.createElement("a");
        a.href = URL.createObjectURL(blob);
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        a.remove();
        setTimeout(() => URL.revokeObjectURL(a.href), 5000);
    }
}