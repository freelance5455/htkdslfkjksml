export default class SettingsApp {
    constructor(container) {
        this.container = container;
        this.screen = this.createScreen();
        this.loadSettings();
        this.attachEvents();
    }

    createScreen() {
        const div = document.createElement("div");
        div.id = "settings-screen";
        div.style.display = "none";
        div.style.padding = "20px";
        div.style.width = "100%";
        div.style.height = "100%";
        div.style.boxSizing = "border-box";

        div.innerHTML = `
            <h2>Settings</h2>

            <label>Date Format:</label>
            <select id="date-format">
                <option value="dd-mm-yyyy">DD-MM-YYYY</option>
                <option value="mm-dd-yyyy">MM-DD-YYYY</option>
                <option value="yyyy-mm-dd">YYYY-MM-DD</option>
            </select>

            <br><br>

            <label>Time Format:</label>
            <select id="time-format">
                <option value="24h">24 Hour</option>
                <option value="12h">12 Hour (AM/PM)</option>
            </select>

            <br><br>

            <button id="settings-save-btn">Save</button>
        `;

        this.container.appendChild(div);
        return div;
    }

    loadSettings() {
        const saved = JSON.parse(localStorage.getItem("noteSettings")) || {
            dateFormat: "dd-mm-yyyy",
            timeFormat: "24h"
        };

        this.settings = saved;

        document.getElementById("date-format").value = saved.dateFormat;
        document.getElementById("time-format").value = saved.timeFormat;
    }

    attachEvents() {
        document.getElementById("settings-save-btn")
            .addEventListener("click", () => this.saveSettings());
    }

    saveSettings() {
        const newSettings = {
            dateFormat: document.getElementById("date-format").value,
            timeFormat: document.getElementById("time-format").value
        };

        localStorage.setItem("noteSettings", JSON.stringify(newSettings));
        this.settings = newSettings;

        // IMPORTANT: Notify NotesApp to refresh timestamps
        window.dispatchEvent(new Event("settings:updated"));
        alert("Settings saved!");
    }

    show() {
        this.screen.style.display = "block";
    }

    hide() {
        this.screen.style.display = "none";
    }
}