// CalculatorApp.js
// Place under js/apps/calculator/CalculatorApp.js
export default class CalculatorApp {
  constructor(container) {
    this.container = container;

    // Inject HTML (IDs namespaced with 'calc-')
    this.container.innerHTML = `
      <div class="calculator calc-root" style="width:100%;display:flex;justify-content:center;align-items:center;">
        <div class="calculator-inner">
          <div id="calc-display-container">
            <input type="text" id="calc-history" disabled>
            <input type="text" id="calc-display" disabled>
          </div>

          <div class="row">
            <button id="calc-second">2ndF</button>
            <button id="calc-hyp">HYP</button>
            <button id="calc-square">x²</button>
            <button id="calc-tenpow">10<sup>x</sup></button>
            <button id="calc-inv">x<sup>-1</sup></button>
            <button id="calc-pow">x<sup>y</sup></button>
            <button id="calc-clear">C</button>
          </div>

          <div class="row">
            <button data-value="sin(" class="calc-btn">sin</button>
            <button data-value="cos(" class="calc-btn">cos</button>
            <button data-value="tan(" class="calc-btn">tan</button>
            <button data-value="log(" class="calc-btn">log</button>
            <button data-value="ln(" class="calc-btn">ln</button>
            <button data-value="√(" class="calc-btn">√</button>
            <button id="calc-del">DEL</button>
          </div>

          <div class="row">
            <button data-value="π" class="calc-btn">π</button>
            <button data-value="e" class="calc-btn">e</button>
            <button data-value="exp(" class="calc-btn">exp</button>
            <button id="calc-fact">x!</button>
            <button data-value="nPr" class="calc-btn"><sup>n</sup>P<sub>r</sub></button>
            <button data-value="nCr" class="calc-btn"><sup>n</sup>C<sub>r</sub></button>
            <button id="calc-percent">%</button>
          </div>

          <div class="row">
            <button data-value="7" class="calc-btn">7</button>
            <button data-value="8" class="calc-btn">8</button>
            <button data-value="9" class="calc-btn">9</button>
            <button data-value="(" class="calc-btn">(</button>
            <button data-value=")" class="calc-btn">)</button>
            <button data-value="÷" class="calc-btn">÷</button>
            <button id="calc-mc">MC</button>
          </div>

          <div class="row">
            <button data-value="4" class="calc-btn">4</button>
            <button data-value="5" class="calc-btn">5</button>
            <button data-value="6" class="calc-btn">6</button>
            <button data-value="×" class="calc-btn">×</button>
            <button data-value="+" class="calc-btn">+</button>
            <button data-value="-" class="calc-btn">-</button>
            <button id="calc-mr">MR</button>
          </div>

          <div class="row">
            <button data-value="1" class="calc-btn">1</button>
            <button data-value="2" class="calc-btn">2</button>
            <button data-value="3" class="calc-btn">3</button>
            <button data-value="0" class="calc-btn">0</button>
            <button data-value="." class="calc-btn">.</button>
            <button id="calc-ans">ANS</button>
            <button id="calc-equals" class="equals">=</button>
          </div>

          <div class="row">
            <button id="calc-mplus">M+</button>
            <button id="calc-mminus">M-</button>
            <button id="calc-history-up">↑</button>
            <button id="calc-history-down">↓</button>
            <button id="calc-deg-rad">DEG</button>
            <button id="calc-rand">Rand</button>
            <button id="calc-abs">|x|</button>
          </div>
        </div>
      </div>
    `;

    // attach CSS link expectation: assume css/calculator.css loaded in index.html already,
    // otherwise you can dynamically inject a <link> here (not included to avoid duplicates).

    // Scoped selectors
    const q = (sel) => this.container.querySelector(sel);

    // Elements
    const display = q('#calc-display');
    const historyDisplay = q('#calc-history');

    // Buttons that may or may not exist
    const btnById = id => q('#' + id);
    const equalsBtn = btnById('calc-equals');
    const clearBtn  = btnById('calc-clear');
    const delBtn    = btnById('calc-del');
    const ansBtn    = btnById('calc-ans');
    const factBtn   = btnById('calc-fact');
    const powBtn    = btnById('calc-pow');
    const tenpowBtn = btnById('calc-tenpow');
    const invBtn    = btnById('calc-inv');
    const percentBtn= btnById('calc-percent');
    const secondBtn = btnById('calc-second');
    const hypBtn    = btnById('calc-hyp');
    const degRadBtn = btnById('calc-deg-rad');
    const randBtn   = btnById('calc-rand');
    const absBtn    = btnById('calc-abs');
    const squareBtn = btnById('calc-square');
    const mcBtn     = btnById('calc-mc');
    const mrBtn     = btnById('calc-mr');
    const mplusBtn  = btnById('calc-mplus');
    const mminusBtn = btnById('calc-mminus');
    const histUpBtn = btnById('calc-history-up');
    const histDnBtn = btnById('calc-history-down');

    // mapped function buttons
    const findByDataOrText = (dataVal, text) => {
      return q(`button[data-value="${dataVal}"]`)
        || Array.from(this.container.querySelectorAll("button")).find(b => b.textContent.trim().toLowerCase() === text.toLowerCase());
    };

    const sinBtn = findByDataOrText("sin(", "sin");
    const cosBtn = findByDataOrText("cos(", "cos");
    const tanBtn = findByDataOrText("tan(", "tan");
    const logBtn = findByDataOrText("log(", "log");
    const lnBtn  = findByDataOrText("ln(", "ln");
    const sqrtBtn = q('button[data-value="√("]') || Array.from(this.container.querySelectorAll("button")).find(b => ["√","∛"].includes(b.textContent.trim()));
    const nPrBtn = findByDataOrText("nPr","nPr");
    const nCrBtn = findByDataOrText("nCr","nCr");

    // State
    let lastAnswer = 0;
    let memory = 0;
    let history = [];
    let historyIndex = -1;
    let secondMode = false;
    let hypMode = false;

    // Math helpers
    function factorial(n) {
      n = Number(n);
      if (!Number.isFinite(n) || n < 0) return NaN;
      if (Math.floor(n) !== n) return NaN; // only integer factorial
      if (n <= 1) return 1;
      let r = 1;
      for (let i = 2; i <= n; i++) r *= i;
      return r;
    }
    function combination(n, r) { n = Number(n); r = Number(r); if (r<0||n<0||r>n) return NaN; return factorial(n)/(factorial(r)*factorial(n-r)); }
    function permutation(n, r) { n = Number(n); r = Number(r); if (r<0||n<0||r>n) return NaN; return factorial(n)/factorial(n-r); }

    // Tokenizer & evaluator (copied + scoped from your script.js)
    function tokenize(input) {
      const src = String(input);
      const tokens = [];
      let i = 0;
      const len = src.length;
      const numberRE = /^[0-9]+(?:\.[0-9]*)?(?:[eE][+\-]?[0-9]+)?/;
      while (i < len) {
        const ch = src[i];
        if (/\s/.test(ch)) { i++; continue; }
        const rem = src.slice(i);
        const m = rem.match(numberRE);
        if (m) { tokens.push({type:'number', value: Number(m[0])}); i += m[0].length; continue; }
        if (ch === 'π' || ch === 'π'.charAt(0)) { tokens.push({type:'const', value:'PI'}); i++; continue; }
        if (ch === 'e') { tokens.push({type:'const', value:'E'}); i++; continue; }
        if (src.slice(i, i+2) === '**') { tokens.push({type:'op', value:'**'}); i+=2; continue; }
        if (ch === '+' || ch === '-' || ch === '×' || ch === '÷' || ch === '*' || ch === '/' ||
            ch === '(' || ch === ')' || ch === '!' || ch === '^' || ch === '%' || ch === 'P' || ch === 'C') {
          if (ch === '×') tokens.push({type:'op', value:'*'});
          else if (ch === '÷') tokens.push({type:'op', value:'/'});
          else if (ch === '^') tokens.push({type:'op', value:'**'});
          else if (ch === '(' || ch === ')') tokens.push({type:'paren', value:ch});
          else tokens.push({type:'op', value:ch});
          i++; continue;
        }
        if (ch === '.') {
          const rem2 = src.slice(i);
          const m2 = rem2.match(/^\.[0-9]+(?:[eE][+\-]?[0-9]+)?/);
          if (m2) { tokens.push({type:'number', value: Number(m2[0])}); i += m2[0].length; continue; }
        }
        if (/[A-Za-zαβγδ]/.test(ch) || ch === 'π') {
          let j = i;
          while (j < len && /[A-Za-z0-9_π]/.test(src[j])) j++;
          let ident = src.slice(i,j);
          const identLower = ident.toLowerCase();
          let k = j;
          while (k < len && /\s/.test(src[k])) k++;
          if (k < len && src[k] === '(') { tokens.push({type:'func', value: identLower}); }
          else {
            if (identLower === 'pi') tokens.push({type:'const', value:'PI'});
            else if (identLower === 'e') tokens.push({type:'const', value:'E'});
            else tokens.push({type:'ident', value: identLower});
          }
          i = j;
          continue;
        }
        tokens.push({type:'unknown', value: ch});
        i++;
      }
      return tokens;
    }

    function insertImplicitMultiplication(tokens) {
      if (!tokens || tokens.length < 2) return tokens;
      const out = [];
      for (let i = 0; i < tokens.length; i++) {
        const t = tokens[i];
        out.push(t);
        if (i === tokens.length-1) break;
        const a = t;
        const b = tokens[i+1];
        const leftOk = (a.type === 'number' || a.type === 'const' || a.type === 'ident' || (a.type === 'paren' && a.value === ')') || (a.type === 'op' && (a.value === '!')) || (a.type === 'op' && (a.value === '%')));
        const rightOk = (b.type === 'number' || b.type === 'const' || b.type === 'func' || (b.type === 'paren' && b.value === '(') || b.type === 'ident');
        if (leftOk && rightOk) out.push({type:'op', value:'*'});
      }
      return out;
    }

    const OPERATORS = {
      '+': {prec:2, assoc:'left', arity:2},
      '-': {prec:2, assoc:'left', arity:2},
      '*': {prec:3, assoc:'left', arity:2},
      '/': {prec:3, assoc:'left', arity:2},
      '**': {prec:4, assoc:'right', arity:2},
      'u-': {prec:5, assoc:'right', arity:1},
      '!': {prec:6, assoc:'left', arity:1, postfix:true},
      '%': {prec:6, assoc:'left', arity:1, postfix:true},
      'P': {prec:3, assoc:'left', arity:2},
      'C': {prec:3, assoc:'left', arity:2}
    };

    function toRPN(tokens) {
      const output = []; const ops = [];
      function opInfo(v) { return OPERATORS[v] || null; }
      for (let i=0;i<tokens.length;i++) {
        const t = tokens[i];
        if (t.type === 'number' || t.type === 'const') { output.push(t); continue; }
        if (t.type === 'ident') {
          if (t.value === 'pi') output.push({type:'const', value:'PI'});
          else if (t.value === 'e') output.push({type:'const', value:'E'});
          else output.push({type:'ident', value:t.value});
          continue;
        }
        if (t.type === 'func') { ops.push(t); continue; }
        if (t.type === 'op') {
          const val = t.value;
          if (val === '-') {
            const prev = tokens[i-1];
            const prevIsValue = prev && (prev.type === 'number' || prev.type === 'const' || prev.type === 'paren' && prev.value === ')' || prev.type === 'ident');
            if (!prevIsValue) {
              const u = 'u-';
              while (ops.length) {
                const top = ops[ops.length-1];
                if (top.type === 'op') {
                  const topInfo = opInfo(top.value);
                  const curInfo = opInfo(u);
                  if (!topInfo) break;
                  if ((topInfo.prec > curInfo.prec) || (topInfo.prec === curInfo.prec && curInfo.assoc === 'left')) output.push(ops.pop());
                  else break;
                } else break;
              }
              ops.push({type:'op', value:u});
              continue;
            }
          }
          const info = opInfo(val);
          if (info && info.postfix) { output.push(t); continue; }
          while (ops.length) {
            const top = ops[ops.length-1];
            if (top.type === 'op') {
              const topInfo = opInfo(top.value);
              if (!topInfo) break;
              const curInfo = opInfo(val);
              if (!curInfo) break;
              if ((topInfo.prec > curInfo.prec) || (topInfo.prec === curInfo.prec && curInfo.assoc === 'left')) output.push(ops.pop());
              else break;
            } else if (top.type === 'func') output.push(ops.pop());
            else break;
          }
          ops.push(t);
          continue;
        }
        if (t.type === 'paren') {
          if (t.value === '(') ops.push(t);
          else {
            let foundLeft = false;
            while (ops.length) {
              const top = ops.pop();
              if (top.type === 'paren' && top.value === '(') { foundLeft = true; break; }
              output.push(top);
            }
            if (ops.length && ops[ops.length-1].type === 'func') output.push(ops.pop());
          }
          continue;
        }
        output.push(t);
      }
      while (ops.length) {
        const top = ops.pop();
        if (top.type === 'paren') continue;
        output.push(top);
      }
      return output;
    }

    function evalRPN(rpn) {
      const trig = (function() {
        const degMode = (degRadBtn && degRadBtn.textContent === "DEG");
        return {
          sin:  x => degMode ? Math.sin(x * Math.PI / 180) : Math.sin(x),
          cos:  x => degMode ? Math.cos(x * Math.PI / 180) : Math.cos(x),
          tan:  x => degMode ? Math.tan(x * Math.PI / 180) : Math.tan(x),
          asin: x => degMode ? (Math.asin(x) * 180 / Math.PI) : Math.asin(x),
          acos: x => degMode ? (Math.acos(x) * 180 / Math.PI) : Math.acos(x),
          atan: x => degMode ? (Math.atan(x) * 180 / Math.PI) : Math.atan(x),
          sinh: Math.sinh, cosh: Math.cosh, tanh: Math.tanh,
          asinh: Math.asinh, acosh: Math.acosh, atanh: Math.atanh
        };
      })();
      const stack = [];
      for (let i=0;i<rpn.length;i++) {
        const t = rpn[i];
        if (t.type === 'number') { stack.push(t.value); continue; }
        if (t.type === 'const') {
          if (t.value === 'PI') stack.push(Math.PI);
          else if (t.value === 'E') stack.push(Math.E);
          else stack.push(NaN);
          continue;
        }
        if (t.type === 'ident') {
          if (t.value === 'ans') stack.push(lastAnswer);
          else stack.push(NaN);
          continue;
        }
        if (t.type === 'func') {
          const fname = t.value.toLowerCase();
          if (fname === 'rand') { stack.push(Math.random()); continue; }
          const a = stack.pop();
          if (a === undefined) { stack.push(NaN); continue; }
          if (['sin','cos','tan','asin','acos','atan','sinh','cosh','tanh','asinh','acosh','atanh'].includes(fname)) {
            stack.push(trig[fname](a));
          } else if (fname === 'sqrt') stack.push(Math.sqrt(a));
          else if (fname === 'cbrt') stack.push(Math.cbrt(a));
          else if (fname === 'abs') stack.push(Math.abs(a));
          else if (fname === 'log') stack.push(Math.log10(a));
          else if (fname === 'ln') stack.push(Math.log(a));
          else if (fname === 'exp') stack.push(Math.exp(a));
          else stack.push(NaN);
          continue;
        }
        if (t.type === 'op') {
          const v = t.value;
          if (v === '!') { const a = stack.pop(); stack.push(factorial(a)); continue; }
          if (v === '%') { const a = stack.pop(); stack.push(a/100); continue; }
          if (v === 'u-') { const a = stack.pop(); stack.push(-a); continue; }
          const b = stack.pop(); const a = stack.pop();
          if (a === undefined || b === undefined) { stack.push(NaN); continue; }
          if (v === '+') stack.push(a + b);
          else if (v === '-') stack.push(a - b);
          else if (v === '*') stack.push(a * b);
          else if (v === '/') stack.push(a / b);
          else if (v === '**') stack.push(Math.pow(a, b));
          else if (v === 'P') stack.push(permutation(a, b));
          else if (v === 'C') stack.push(combination(a, b));
          else stack.push(NaN);
          continue;
        }
        stack.push(NaN);
      }
      return stack.length ? stack[stack.length-1] : NaN;
    }

    function balanceParens(expr) {
      if (!expr) return expr;
      let open = (expr.match(/\(/g) || []).length;
      let close = (expr.match(/\)/g) || []).length;
      if (open > close) expr = expr + ')'.repeat(open - close);
      if (close > open) {
        let excess = close - open;
        while (excess > 0 && expr.endsWith(')')) { expr = expr.slice(0, -1); excess--; }
      }
      return expr;
    }

    function evaluate() {
      try {
        let exprRaw = String(display.value || "");
        let expr = balanceParens(exprRaw);
        let tokens = tokenize(expr);
        tokens = insertImplicitMultiplication(tokens);
        const rpn = toRPN(tokens);
        const value = evalRPN(rpn);
        if (typeof value === 'number' && !Number.isFinite(value)) {
          display.value = "Error";
        } else {
          display.value = String(value);
          lastAnswer = value;
          history.push(`${expr} = ${value}`);
          historyIndex = history.length - 1;
        }
        historyDisplay.value = expr;
      } catch (err) {
        console.error("Evaluation failed:", err);
        display.value = "Error";
      }
    }

    // Expose for debugging on window (optional)
    window._calc = window._calc || {};
    window._calc.evaluate = evaluate;

    // Wiring UI buttons (scoped)
    this.container.querySelectorAll("button[data-value]").forEach(b => {
      const v = b.getAttribute("data-value");
      const skip = new Set(['sin(','cos(','tan(','log(','ln(','√(','nPr','nCr']);
      if (skip.has(v)) return;
      b.addEventListener("click", () => display.value += v);
    });

    function trigToken(base) {
      if (hypMode && secondMode) return 'a' + base + 'h';
      if (hypMode) return base + 'h';
      if (secondMode) {
        if (base === 'sin') return 'asin';
        if (base === 'cos') return 'acos';
        if (base === 'tan') return 'atan';
      }
      return base;
    }
    if (sinBtn) sinBtn.addEventListener("click", () => display.value += trigToken('sin') + '(');
    if (cosBtn) cosBtn.addEventListener("click", () => display.value += trigToken('cos') + '(');
    if (tanBtn) tanBtn.addEventListener("click", () => display.value += trigToken('tan') + '(');

    if (logBtn) logBtn.addEventListener("click", () => display.value += 'log(');
    if (lnBtn)  lnBtn.addEventListener("click", () => display.value += 'ln(');

    if (sqrtBtn) {
      sqrtBtn.addEventListener("click", () => {
        if (secondMode) display.value += 'cbrt(';
        else display.value += 'sqrt(';
      });
    }

    if (factBtn) factBtn.addEventListener("click", () => display.value += '!');
    if (nPrBtn) nPrBtn.addEventListener("click", () => display.value += 'P');
    if (nCrBtn) nCrBtn.addEventListener("click", () => display.value += 'C');

    if (powBtn) powBtn.addEventListener("click", () => display.value += '**');
    if (tenpowBtn) tenpowBtn.addEventListener("click", () => display.value += '10**');
    if (invBtn) invBtn.addEventListener("click", () => display.value = display.value ? `1/(${display.value})` : '1/(');
    if (percentBtn) percentBtn.addEventListener("click", () => display.value += '%');
    if (randBtn) randBtn.addEventListener("click", () => display.value += 'rand()');
    if (absBtn) absBtn.addEventListener("click", () => display.value += 'abs(');

    if (equalsBtn) equalsBtn.addEventListener("click", evaluate);
    if (clearBtn) clearBtn.addEventListener("click", () => { display.value = ''; historyDisplay.value = ''; });
    if (delBtn) delBtn.addEventListener("click", () => { display.value = display.value.slice(0, -1); });
    if (ansBtn) ansBtn.addEventListener("click", () => display.value += String(lastAnswer));

    if (mcBtn) mcBtn.addEventListener("click", () => memory = 0);
    if (mrBtn) mrBtn.addEventListener("click", () => display.value += String(memory));
    if (mplusBtn) mplusBtn.addEventListener("click", () => { const v = Number(display.value); if (!Number.isNaN(v)) memory += v; });
    if (mminusBtn) mminusBtn.addEventListener("click", () => { const v = Number(display.value); if (!Number.isNaN(v)) memory -= v; });

    if (histUpBtn) histUpBtn.addEventListener("click", () => {
      if (historyIndex > 0) { historyIndex--; display.value = String(history[historyIndex]).replace(/^.*=\s*/,''); }
    });
    if (histDnBtn) histDnBtn.addEventListener("click", () => {
      if (historyIndex < history.length - 1) { historyIndex++; display.value = String(history[historyIndex]).replace(/^.*=\s*/,''); }
    });

    function updateModeUI() {
      if (secondBtn) secondBtn.classList.toggle('active', secondMode);
      if (hypBtn) hypBtn.classList.toggle('active', hypMode);
      if (degRadBtn) degRadBtn.textContent = (degRadBtn.textContent === "DEG" ? "DEG" : "RAD");
      if (squareBtn) squareBtn.textContent = secondMode ? 'x³' : 'x²';
      if (sqrtBtn)  sqrtBtn.textContent  = secondMode ? '∛' : '√';
    }

    if (secondBtn) {
      secondBtn.addEventListener("click", () => {
        secondMode = !secondMode;
        if (sinBtn) sinBtn.textContent = secondMode ? "sin⁻¹" : "sin";
        if (cosBtn) cosBtn.textContent = secondMode ? "cos⁻¹" : "cos";
        if (tanBtn) tanBtn.textContent = secondMode ? "tan⁻¹" : "tan";
        if (sqrtBtn) sqrtBtn.textContent = secondMode ? "∛" : "√";
        secondBtn.classList.toggle("active", secondMode);
      });
    }

    if (hypBtn) {
      hypBtn.addEventListener("click", () => {
        hypMode = !hypMode;
        hypBtn.classList.toggle("active", hypMode);
      });
    }
    if (degRadBtn) {
      degRadBtn.addEventListener("click", () => {
        if (degRadBtn.textContent === "DEG") {
          degRadBtn.textContent = "RAD";
          degRadBtn.classList.remove("DEG");
          degRadBtn.classList.add("RAD");
        } else {
          degRadBtn.textContent = "DEG";
          degRadBtn.classList.remove("RAD");
          degRadBtn.classList.add("DEG");
        }
        updateModeUI();
      });
    }

    updateModeUI();

    // placeholder logic (history)
    function showHistoryPlaceholder() {
      if (!historyDisplay.value) {
        historyDisplay.value = "coderATP";
        historyDisplay.classList.add("placeholder");
      }
    }
    function clearHistoryPlaceholder() {
      if (historyDisplay.classList.contains("placeholder")) {
        historyDisplay.value = "";
        historyDisplay.classList.remove("placeholder");
      }
    }
    showHistoryPlaceholder();
    this.container.querySelectorAll(".calculator button").forEach(btn => btn.addEventListener("click", clearHistoryPlaceholder));
    if (clearBtn) clearBtn.addEventListener("click", () => { display.value = ""; historyDisplay.value = ""; showHistoryPlaceholder(); });

    // ensure container takes focus for keyboard input if desired (optional)
    // container.addEventListener('keydown', (e) => { ... } );
  }
}