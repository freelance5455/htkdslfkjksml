export default class ToDoList {
    constructor(container, onEdit, onDelete, onToggleComplete, onReorder) {
        this.container = container;
        this.onEdit = onEdit;
        this.onDelete = onDelete;
        this.onToggleComplete = onToggleComplete;
        this.onReorder = onReorder;

        this.draggedEl = null;
        this.fromIndex = null;

        // Auto-scroll parameters
        this.autoScrollSpeed = 8; // px per dragover event
        this.autoScrollOffset = 40; // px from top/bottom to trigger scroll

        this.container.addEventListener('dragover', (e) => {
            e.preventDefault();
            if (!this.draggedEl) return;

            const rect = this.container.getBoundingClientRect();
            if (e.clientY < rect.top + this.autoScrollOffset) {
                this.container.scrollTop -= this.autoScrollSpeed;
            } else if (e.clientY > rect.bottom - this.autoScrollOffset) {
                this.container.scrollTop += this.autoScrollSpeed;
            }
        });
    }

    renderAll(tasks) {
        this.container.innerHTML = '';
        tasks.forEach((task, index) => this.renderTask(task, index));
    }

    renderTask(task, index) {
        const taskEl = document.createElement('div');
        taskEl.className = 'task-card';
        taskEl.draggable = true;
        taskEl.dataset.index = index;
        taskEl.innerHTML = `
            <span class="dragIcon">☰</span>
            <input type="checkbox" class="taskCheckbox" ${task.completed ? 'checked' : ''}>
            <div class="taskTitle">${task.title}</div>
            <div class="taskActions">
                <button class="editBtn">✏️</button>
                <button class="deleteBtn">🗑️</button>
            </div>
        `;

        // Checkbox toggle
        taskEl.querySelector('.taskCheckbox').addEventListener('click', () => {
            task.completed = !task.completed;
            this.onToggleComplete(task);
        });

        // Edit
        taskEl.querySelector('.editBtn').addEventListener('click', () => {
            this.onEdit(task);
        });

        // Delete
        taskEl.querySelector('.deleteBtn').addEventListener('click', () => {
            this.onDelete(task, taskEl);
        });

        // Drag events
        taskEl.addEventListener('dragstart', (e) => {
            this.draggedEl = taskEl;
            this.fromIndex = index;
            taskEl.style.opacity = '0.5';
        });

        taskEl.addEventListener('dragend', (e) => {
            taskEl.style.opacity = '1';
            if (!this.draggedEl) return;
        
            const children = Array.from(this.container.children);
            const dropY = e.clientY; // Use mouse Y position
        
            let toIndex = this.fromIndex;
        
            for (let i = 0; i < children.length; i++) {
                const child = children[i];
                if (child === this.draggedEl) continue;
        
                const rect = child.getBoundingClientRect();
                if (dropY >= rect.top && dropY <= rect.bottom) {
                    toIndex = i;
                    break;
                }
            }
        
            if (toIndex !== this.fromIndex) {
                this.onReorder(this.fromIndex, toIndex);
            }
        
            this.draggedEl = null;
            this.fromIndex = null;
        }); 

        this.container.appendChild(taskEl);
    }
}