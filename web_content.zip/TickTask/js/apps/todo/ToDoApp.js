import ToDoList from './ToDoList.js';

export default class ToDoApp {
    constructor(container) {
        this.container = container;

        // Inject HTML
        this.container.innerHTML = `
            <div id="todoContainer" style="display:flex; flex-direction:column; height:100%; color:white; font-family:sans-serif; position:relative;">
                <div id="taskList" style="flex:1; margin-top:16px; overflow-y:auto;"></div>

                <!-- Floating + button -->
                <button id="floatingAddBtn" style="
                    position:absolute;
                    right:20px;
                    top:50%;
                    transform:translateY(-50%);
                    background:#1e90ff;
                    color:white;
                    border:none;
                    border-radius:50%;
                    width:50px;
                    height:50px;
                    font-size:28px;
                    cursor:pointer;
                    box-shadow:0 4px 10px rgba(0,0,0,0.3);
                    z-index:10;
                ">+</button>

                <!-- Hidden input area -->
                <div id="todoInputArea" style="
                    display:none;
                    flex-direction:column;
                    gap:10px;
                    padding:16px;
                    background:#1e1e1e;
                    border-radius:12px;
                    position:absolute;
                    left:50%;
                    top:50%;
                    transform:translate(-50%, -50%);
                    z-index:20;
                    width:250px;
                    box-shadow:0 4px 14px rgba(0,0,0,0.5);
                ">
                    <input type="text" id="taskTitle" placeholder="Task title">
                    <button id="addTaskBtn" style="
                        padding:10px;
                        border:none;
                        border-radius:8px;
                        background:#1e90ff;
                        color:white;
                        cursor:pointer;
                    ">Add Task</button>
                </div>
            </div>
        `;

        // Elements
        this.taskContainer = this.container.querySelector('#taskList');
        this.floatingBtn = this.container.querySelector('#floatingAddBtn');
        this.inputArea = this.container.querySelector('#todoInputArea');
        this.titleInput = this.container.querySelector('#taskTitle');
        this.addBtn = this.container.querySelector('#addTaskBtn');

        // State
        this.tasks = [];
        this.taskList = new ToDoList(
            this.taskContainer,
            this.editTask.bind(this),
            this.deleteTask.bind(this),
            this.toggleComplete.bind(this),
            this.reorderTask.bind(this)
        );

        this.loadTasks();

        // Event listeners
        this.floatingBtn.addEventListener('click', () => this.showInputArea());
        this.addBtn.addEventListener('click', () => this.addTask());

        // Click outside to hide input area
        document.addEventListener('click', (e) => {
            if (this.inputArea.style.display === 'flex' && !this.inputArea.contains(e.target) && e.target !== this.floatingBtn) {
                this.hideInputArea();
            }
        });
    }

    showInputArea() {
        this.inputArea.style.display = 'flex';
        this.titleInput.focus();
        this.blurOtherTasks(true);
    }

    hideInputArea() {
        this.inputArea.style.display = 'none';
        this.titleInput.value = '';
        this.blurOtherTasks(false);
    }

    blurOtherTasks(blur) {
        Array.from(this.taskContainer.children).forEach(child => {
            child.style.filter = blur ? 'blur(2px)' : 'none';
            child.style.pointerEvents = blur ? 'none' : 'auto';
        });
    }

    addTask() {
        const title = this.titleInput.value.trim();
        if (!title) return;

        const task = {
            id: Date.now(),
            title,
            completed: false
        };

        this.tasks.push(task);
        this.saveTasks();
        this.taskList.renderAll(this.tasks);

        this.hideInputArea();
    }

    editTask(task) {
        // Blur other tasks
        this.blurOtherTasks(true);

        const newTitle = prompt('Edit task title:', task.title);

        // Unblur after editing
        this.blurOtherTasks(false);

        if (newTitle !== null) {
            task.title = newTitle;
            this.saveTasks();
            this.taskList.renderAll(this.tasks);
        }
    }

    deleteTask(task, element) {
        this.tasks = this.tasks.filter(t => t.id !== task.id);
        this.saveTasks();
        this.taskContainer.removeChild(element);
    }

    toggleComplete(task) {
        this.saveTasks();
        this.taskList.renderAll(this.tasks);
    }

    reorderTask(fromIndex, toIndex) {
        if (fromIndex === toIndex) return;
        const task = this.tasks.splice(fromIndex, 1)[0];
        this.tasks.splice(toIndex, 0, task);
        this.saveTasks();
        this.taskList.renderAll(this.tasks);
    }

    saveTasks() {
        localStorage.setItem('tasks', JSON.stringify(this.tasks));
    }

    loadTasks() {
        const saved = JSON.parse(localStorage.getItem('tasks'));
        if (Array.isArray(saved)) {
            this.tasks = saved;
            this.taskList.renderAll(this.tasks);
        }
    }
}