export default class ClockApp {
    constructor(container) {
        this.container = container;

        // Inject HTML
        this.container.innerHTML = `
            <div id="clockPanel">
                <div id="digitalClock"></div>
                <div id="currentDate"></div>
                <canvas id="analogueClock"></canvas>
            </div>
        `;

        // Elements
        this.digitalClock = this.container.querySelector("#digitalClock");
        this.currentDate = this.container.querySelector("#currentDate");
        this.analogueCanvas = this.container.querySelector("#analogueClock");
        this.ctx = this.analogueCanvas.getContext("2d");

        // Responsive canvas size
        this.resizeCanvas();
        window.addEventListener("resize", () => this.resizeCanvas());

        // Start clock
        this.updateTime();
        setInterval(() => this.updateTime(), 1000);
    }

    resizeCanvas() {
        const size = Math.min(window.innerWidth, window.innerHeight) * 0.6;
        this.analogueCanvas.width = size;
        this.analogueCanvas.height = size;
        this.radius = size / 2;
        this.ctx.translate(this.radius, this.radius); // center
        this.radius *= 0.90; // shrink slightly for padding
    }

    updateTime() {
        const now = new Date();

        // Digital clock
        const hours = String(now.getHours()).padStart(2, '0');
        const minutes = String(now.getMinutes()).padStart(2, '0');
        const seconds = String(now.getSeconds()).padStart(2, '0');
        this.digitalClock.textContent = `${hours}:${minutes}:${seconds}`;

        // Date display
        const options = { weekday: 'long', year: 'numeric', month: 'short', day: 'numeric' };
        this.currentDate.textContent = now.toLocaleDateString(undefined, options);

        // Draw analogue clock
        this.drawClock(now);
    }

    drawClock(now) {
        const ctx = this.ctx;
        const radius = this.radius;
        ctx.clearRect(-radius, -radius, radius*2, radius*2);

        // Clock face
        ctx.beginPath();
        ctx.arc(0, 0, radius, 0, 2 * Math.PI);
        ctx.fillStyle = '#1e1e1e';
        ctx.fill();
        ctx.lineWidth = radius*0.05;
        ctx.strokeStyle = '#333';
        ctx.stroke();

        // Hour ticks
        for (let i = 0; i < 12; i++) {
            const angle = i * Math.PI / 6;
            const inner = radius * 0.85;
            const outer = radius;
            ctx.beginPath();
            ctx.moveTo(inner * Math.cos(angle), inner * Math.sin(angle));
            ctx.lineTo(outer * Math.cos(angle), outer * Math.sin(angle));
            ctx.strokeStyle = '#fff';
            ctx.lineWidth = 2;
            ctx.stroke();
        }

        // Hands
        const hour = now.getHours() % 12;
        const minute = now.getMinutes();
        const second = now.getSeconds();

        // Hour hand
        this.drawHand((hour + minute/60) * Math.PI/6, radius*0.5, 6, '#1e90ff');
        // Minute hand
        this.drawHand((minute + second/60) * Math.PI/30, radius*0.7, 4, '#fff');
        // Second hand
        this.drawHand(second * Math.PI/30, radius*0.8, 2, '#ff4500');

        // Center dot
        ctx.beginPath();
        ctx.arc(0,0,6,0,2*Math.PI);
        ctx.fillStyle = '#fff';
        ctx.fill();
    }

    drawHand(pos, length, width, color) {
        const ctx = this.ctx;
        ctx.beginPath();
        ctx.lineWidth = width;
        ctx.lineCap = "round";
        ctx.strokeStyle = color;
        ctx.moveTo(0,0);
        ctx.rotate(pos);
        ctx.lineTo(0, -length);
        ctx.stroke();
        ctx.rotate(-pos);
    }
}