# Smart Installment Management — Starter Source Bundle

This is a runnable starter/MVP source project for a Pakistan-based smartphone installment business. It includes a PHP 8.2+ / MySQL website, an initial schema, API examples, and an Android Kotlin/Jetpack Compose project.

## Important scope and deployment notes
- This bundle is source code, not a claim that a production system has been deployed or connected to a live Firebase project.
- The Android APK is not included because this environment does not have the Android SDK/Gradle build environment. Build instructions are in `docs/installation-guide.md`.
- Remote device restrictions and location collection are intentionally not implemented as hidden or universal controls. Integrate only a compatible, approved Android Enterprise/OEM management provider after enrollment and legal review.
- Before production use, add HTTPS, environment secrets, MFA, hardened role/permission workflows, monitoring, backups, security review, and automated tests.

## Quick start
1. Create a MySQL database and import `database/schema.sql`.
2. Copy `website/config.example.php` to `website/config.php` and set credentials.
3. Point your PHP web root at `website/` (preferably configure the server so `config.php` and private documents are not publicly served).
4. Visit `setup-admin.php` only on a private/staging installation to create the first admin, then delete that file. See installation guide.
5. Configure the Android `BASE_URL` in `ApiConfig.kt` and build using Android Studio.
