# Android app

Kotlin + Jetpack Compose starter UI. This is currently a demo UI with illustrative values; customer login, backend API integration, Firebase FCM, and real account synchronization still need implementation and configuration. No remote locking or hidden location tracking is included.

Open this directory in Android Studio, allow Gradle sync, then use Build > Build APK(s). Configure `ApiConfig.kt` before implementing the authenticated API client.
