package pk.smartinstallment.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF15233D)
private val Blue = Color(0xFF3158C8)
private val Canvas = Color(0xFFF4F6FB)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SmartInstallmentApp() }
    }
}

@Composable
fun SmartInstallmentApp() {
    var selected by remember { mutableStateOf("Overview") }
    MaterialTheme(colorScheme = lightColorScheme(primary = Blue, background = Canvas, surface = Color.White)) {
        Scaffold(containerColor = Canvas, topBar = {
            Column(Modifier.fillMaxWidth().background(Navy).padding(horizontal = 20.dp, vertical = 18.dp)) {
                Text("SMART INSTALLMENT", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("Customer account", color = Color(0xFFCBD5E8), fontSize = 12.sp)
            }
        }, bottomBar = {
            NavigationBar(containerColor = Color.White) {
                listOf("Overview", "Installments", "Payments", "Support").forEach { item ->
                    NavigationBarItem(selected = selected == item, onClick = { selected = item }, icon = {}, label = { Text(item, fontSize = 10.sp) })
                }
            }
        }) { padding ->
            LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                item {
                    Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Navy), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(20.dp)) {
                            Text("Financing overview", color = Color(0xFFCBD5E8), fontSize = 13.sp)
                            Spacer(Modifier.height(8.dp))
                            Text("PKR 70,000", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                            Text("Illustrative remaining balance", color = Color(0xFFCBD5E8), fontSize = 12.sp)
                            Spacer(Modifier.height(18.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                MiniValue("Monthly", "PKR 10,000")
                                MiniValue("Next due", "01 Nov 2026")
                            }
                        }
                    }
                }
                item { StatusBanner() }
                item {
                    when (selected) {
                        "Installments" -> InfoCard("Installment schedule", "Your verified schedule will appear here after secure backend sign-in and synchronization.")
                        "Payments" -> InfoCard("Payment history", "Verified payments and receipts will be loaded from your account backend. Do not treat a screenshot as payment verification.")
                        "Support" -> InfoCard("Customer support", "Contact your installment provider using the phone number or support channel shown in your signed financing agreement.")
                        else -> {
                            InfoCard("My financed device", "Device model and contract details will appear after the backend confirms your enrollment.")
                            InfoCard("Account synchronization", "Not connected yet. Configure the HTTPS API endpoint and implement customer authentication before using real customer data.")
                        }
                    }
                }
                item { Text("Privacy & consent", fontWeight = FontWeight.SemiBold, fontSize = 16.sp); Text("Device management and any location processing must be disclosed, authorized, and supported by the selected management provider.", color = Color(0xFF68758D), fontSize = 12.sp) }
            }
        }
    }
}

@Composable
private fun MiniValue(label: String, value: String) {
    Column { Text(label, color = Color(0xFFCBD5E8), fontSize = 12.sp); Spacer(Modifier.height(4.dp)); Text(value, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp) }
}

@Composable
private fun StatusBanner() {
    Card(shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5ED)), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("●", color = Color(0xFF198754), fontSize = 18.sp)
            Spacer(Modifier.width(10.dp))
            Column { Text("Demo preview", fontWeight = FontWeight.SemiBold, color = Color(0xFF17643A)); Text("Displayed figures are illustrative, not live account data.", fontSize = 12.sp, color = Color(0xFF376A4D)) }
        }
    }
}

@Composable
private fun InfoCard(title: String, description: String) {
    Card(shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            Spacer(Modifier.height(6.dp))
            Text(description, color = Color(0xFF68758D), fontSize = 13.sp, lineHeight = 19.sp)
        }
    }
}
