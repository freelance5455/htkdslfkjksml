package pk.smartinstallment.app

object ApiConfig {
    // Replace with your deployed HTTPS API base URL. Example: https://example.com/api/v1/
    const val BASE_URL = "https://your-domain.example/api/v1/"
}
