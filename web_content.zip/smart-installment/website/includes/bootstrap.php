<?php
declare(strict_types=1);
$configPath = __DIR__ . '/../config.php';
if (!is_file($configPath)) { http_response_code(500); exit('Setup required: copy config.example.php to config.php and configure database.'); }
$config = require $configPath;
date_default_timezone_set($config['app']['timezone'] ?? 'Asia/Karachi');
session_name($config['app']['session_name'] ?? 'smart_installment_session');
session_set_cookie_params(['httponly'=>true,'secure'=>!empty($_SERVER['HTTPS']),'samesite'=>'Lax']);
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
try {
 $db = $config['db'];
 $pdo = new PDO('mysql:host='.$db['host'].';dbname='.$db['name'].';charset='.$db['charset'], $db['user'], $db['pass'], [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES=>false]);
} catch (Throwable $e) { error_log($e->getMessage()); http_response_code(500); exit('Database connection failed. Check server logs.'); }
function e(?string $s): string { return htmlspecialchars($s ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function require_login(): void { if (empty($_SESSION['user'])) { header('Location: login.php'); exit; } }
function csrf_token(): string { if (empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
function check_csrf(): void { if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) { http_response_code(419); exit('Invalid CSRF token.'); } }
function audit(PDO $pdo, string $action, string $entity, ?string $id, string $result='success'): void { $q=$pdo->prepare('INSERT INTO audit_logs(actor_user_id,action,entity_type,entity_id,result,ip_address) VALUES(?,?,?,?,?,?)'); $q->execute([$_SESSION['user']['id'] ?? null,$action,$entity,$id,$result,substr($_SERVER['REMOTE_ADDR'] ?? '',0,45)]); }
