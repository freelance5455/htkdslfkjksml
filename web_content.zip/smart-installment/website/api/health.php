<?php
require __DIR__.'/../includes/bootstrap.php';
header('Content-Type: application/json; charset=utf-8');
try { $pdo->query('SELECT 1'); echo json_encode(['ok'=>true,'service'=>'smart-installment-api','time'=>gmdate('c')]); }
catch(Throwable $e){http_response_code(503);echo json_encode(['ok'=>false,'error'=>'unavailable']);}
