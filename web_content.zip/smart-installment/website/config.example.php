<?php
// Copy to config.php. Never commit real credentials.
declare(strict_types=1);
return [
    'db' => [
        'host' => getenv('DB_HOST') ?: '127.0.0.1',
        'name' => getenv('DB_NAME') ?: 'smart_installment',
        'user' => getenv('DB_USER') ?: 'smart_installment_app',
        'pass' => getenv('DB_PASS') ?: '',
        'charset' => 'utf8mb4',
    ],
    'app' => [
        'name' => 'Smart Installment',
        'timezone' => 'Asia/Karachi',
        'session_name' => 'smart_installment_session',
    ],
];
