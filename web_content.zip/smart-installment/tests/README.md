# Test plan

Before production, automate tests for authentication failures, CSRF rejection, role authorization, customer creation, contract schedule generation and rounding, duplicate payment references/idempotency keys, transaction rollback, pending payment behavior, overdue job idempotency, timezone boundaries, notification retries, provider failures, stale/offline device status, and backup restoration. Provider-specific restriction/restoration tests must run only on authorized staging devices. No automated test suite has been executed as part of this source generation.
