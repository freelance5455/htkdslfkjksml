CREATE DATABASE IF NOT EXISTS smart_installment CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE smart_installment;

CREATE TABLE IF NOT EXISTS users (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(120) NOT NULL,
 email VARCHAR(190) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL,
 role ENUM('super_admin','finance_manager','collection_officer','device_operator','auditor') NOT NULL DEFAULT 'auditor',
 active TINYINT(1) NOT NULL DEFAULT 1,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS customers (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 customer_number VARCHAR(40) NOT NULL UNIQUE,
 full_name VARCHAR(160) NOT NULL,
 phone VARCHAR(40) NOT NULL,
 email VARCHAR(190) NULL,
 address VARCHAR(500) NULL,
 consent_device_management TINYINT(1) NOT NULL DEFAULT 0,
 consent_location TINYINT(1) NOT NULL DEFAULT 0,
 status ENUM('active','inactive') NOT NULL DEFAULT 'active',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
 INDEX idx_customer_name(full_name), INDEX idx_customer_phone(phone)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS devices (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 customer_id BIGINT UNSIGNED NOT NULL,
 manufacturer VARCHAR(100) NOT NULL,
 model VARCHAR(120) NOT NULL,
 android_version VARCHAR(40) NULL,
 enrollment_status ENUM('pending','enrolled','failed','unenrolled') NOT NULL DEFAULT 'pending',
 management_provider VARCHAR(120) NULL,
 management_reference VARCHAR(190) NULL,
 management_status ENUM('unknown','normal','restriction_requested','restricted','restoration_requested','error') NOT NULL DEFAULT 'unknown',
 last_sync_at DATETIME NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_devices_customer FOREIGN KEY(customer_id) REFERENCES customers(id),
 INDEX idx_device_customer(customer_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS financing_contracts (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 contract_number VARCHAR(60) NOT NULL UNIQUE,
 customer_id BIGINT UNSIGNED NOT NULL,
 device_id BIGINT UNSIGNED NULL,
 retail_price DECIMAL(12,2) NOT NULL,
 initial_deposit DECIMAL(12,2) NOT NULL DEFAULT 0,
 financed_amount DECIMAL(12,2) NOT NULL,
 installment_count SMALLINT UNSIGNED NOT NULL,
 monthly_installment DECIMAL(12,2) NOT NULL,
 first_due_date DATE NOT NULL,
 grace_period_days SMALLINT UNSIGNED NOT NULL DEFAULT 7,
 status ENUM('active','completed','cancelled','disputed') NOT NULL DEFAULT 'active',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_contract_customer FOREIGN KEY(customer_id) REFERENCES customers(id),
 CONSTRAINT fk_contract_device FOREIGN KEY(device_id) REFERENCES devices(id),
 CHECK (retail_price >= 0 AND initial_deposit >= 0 AND financed_amount >= 0 AND installment_count > 0),
 INDEX idx_contract_customer(customer_id), INDEX idx_contract_status(status)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS installments (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 contract_id BIGINT UNSIGNED NOT NULL,
 installment_number SMALLINT UNSIGNED NOT NULL,
 due_date DATE NOT NULL,
 amount_due DECIMAL(12,2) NOT NULL,
 amount_paid DECIMAL(12,2) NOT NULL DEFAULT 0,
 status ENUM('unpaid','partial','paid','overdue') NOT NULL DEFAULT 'unpaid',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
 CONSTRAINT fk_installment_contract FOREIGN KEY(contract_id) REFERENCES financing_contracts(id),
 UNIQUE KEY uq_contract_installment(contract_id, installment_number),
 INDEX idx_installment_due_status(due_date,status)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS payments (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 payment_reference VARCHAR(100) NOT NULL UNIQUE,
 idempotency_key VARCHAR(100) NOT NULL UNIQUE,
 customer_id BIGINT UNSIGNED NOT NULL,
 contract_id BIGINT UNSIGNED NOT NULL,
 installment_id BIGINT UNSIGNED NULL,
 amount DECIMAL(12,2) NOT NULL,
 payment_method ENUM('cash','bank_transfer','gateway','other') NOT NULL,
 verification_status ENUM('pending_verification','confirmed','failed','reversed','refunded') NOT NULL DEFAULT 'confirmed',
 notes VARCHAR(500) NULL,
 recorded_by BIGINT UNSIGNED NULL,
 verified_at DATETIME NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_payment_customer FOREIGN KEY(customer_id) REFERENCES customers(id),
 CONSTRAINT fk_payment_contract FOREIGN KEY(contract_id) REFERENCES financing_contracts(id),
 CONSTRAINT fk_payment_installment FOREIGN KEY(installment_id) REFERENCES installments(id),
 CONSTRAINT fk_payment_user FOREIGN KEY(recorded_by) REFERENCES users(id),
 CHECK(amount > 0), INDEX idx_payment_contract(contract_id), INDEX idx_payment_created(created_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS device_management_events (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 device_id BIGINT UNSIGNED NOT NULL,
 event_type ENUM('reminder','restriction_request','restoration_request','status_update') NOT NULL,
 reason VARCHAR(500) NOT NULL,
 request_status ENUM('requested','approved','submitted','confirmed','failed','rejected') NOT NULL DEFAULT 'requested',
 provider_request_id VARCHAR(190) NULL,
 requested_by BIGINT UNSIGNED NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
 CONSTRAINT fk_event_device FOREIGN KEY(device_id) REFERENCES devices(id),
 CONSTRAINT fk_event_user FOREIGN KEY(requested_by) REFERENCES users(id), INDEX idx_event_device(device_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS consent_records (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 customer_id BIGINT UNSIGNED NOT NULL,
 contract_id BIGINT UNSIGNED NULL,
 consent_type ENUM('device_management','location_processing','privacy_policy') NOT NULL,
 policy_version VARCHAR(40) NOT NULL,
 consent_status ENUM('granted','withdrawn') NOT NULL,
 recorded_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_consent_customer FOREIGN KEY(customer_id) REFERENCES customers(id),
 CONSTRAINT fk_consent_contract FOREIGN KEY(contract_id) REFERENCES financing_contracts(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS notifications (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 customer_id BIGINT UNSIGNED NULL,
 device_id BIGINT UNSIGNED NULL,
 notification_type VARCHAR(60) NOT NULL,
 message VARCHAR(500) NOT NULL,
 delivery_status ENUM('queued','sent','failed') NOT NULL DEFAULT 'queued',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 sent_at DATETIME NULL,
 CONSTRAINT fk_notification_customer FOREIGN KEY(customer_id) REFERENCES customers(id),
 CONSTRAINT fk_notification_device FOREIGN KEY(device_id) REFERENCES devices(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS audit_logs (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 actor_user_id BIGINT UNSIGNED NULL,
 action VARCHAR(120) NOT NULL,
 entity_type VARCHAR(80) NOT NULL,
 entity_id VARCHAR(80) NULL,
 result ENUM('success','denied','failure') NOT NULL DEFAULT 'success',
 request_id VARCHAR(80) NULL,
 ip_address VARCHAR(45) NULL,
 metadata JSON NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_audit_user FOREIGN KEY(actor_user_id) REFERENCES users(id),
 INDEX idx_audit_entity(entity_type,entity_id), INDEX idx_audit_created(created_at)
) ENGINE=InnoDB;
