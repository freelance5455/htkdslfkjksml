<?php
// Run via CLI only after config is installed: php mark-overdue.php
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require __DIR__.'/../../website/includes/bootstrap.php';
// Idempotent status refresh. Restriction commands are intentionally not sent by this job.
$q=$pdo->prepare("UPDATE installments SET status='overdue' WHERE due_date < DATE_SUB(CURDATE(), INTERVAL (SELECT grace_period_days FROM financing_contracts f WHERE f.id=installments.contract_id) DAY) AND amount_paid < amount_due AND status IN ('unpaid','partial')");
$q->execute(); fwrite(STDOUT, 'Overdue installments updated: '.$q->rowCount().PHP_EOL);
