# Installation Guide

## Requirements
- PHP 8.2+ (prefer a currently supported PHP release), PDO MySQL, JSON, OpenSSL, mbstring.
- MySQL 8.0+ / 8.4 LTS.
- HTTPS-enabled web hosting and CLI cron support.
- Android Studio with a current stable Android SDK for building the Android app.

## PHP/MySQL setup
1. Create a database and least-privilege application DB user.
2. Import `database/schema.sql` into MySQL.
3. Copy `website/config.example.php` to `website/config.php` and set DB values using environment variables or a protected config file.
4. Set the website directory as the web root. Ensure secrets, private uploads, and source files are not exposed publicly.
5. On a private staging host, visit `setup-admin.php` once to create the first administrator. Use a unique password of at least 12 characters and delete `setup-admin.php` immediately.
6. Visit `login.php` and sign in. Enable HTTPS before any real customer data is entered.
7. Configure a cron job to run `php /absolute/path/to/backend/scheduled-jobs/mark-overdue.php` at a suitable interval. Validate timezone and business grace-period rules before production.

## Android build
1. Open `android-app/` in Android Studio.
2. Allow Gradle to sync and install the Android SDK versions requested by the project.
3. Edit `ApiConfig.kt` to point at your HTTPS API base URL.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Test on a staging device before production distribution.

## Firebase
1. Create your own Firebase project and register the exact Android application ID.
2. Download the matching `google-services.json` into `android-app/app/` (do not commit it if your policy treats project identifiers/config as private).
3. Configure FCM and Firestore in your Firebase project.
4. Deploy the default-deny Firestore rules first. Add rules only after defining the trusted identity mapping and testing in the Firebase Emulator Suite.
5. Keep service-account credentials only on the trusted server/secret manager. Do not embed them in Android or public PHP files.
6. This source bundle is not connected to a live Firebase project by default.

## Device management
A normal app cannot remotely lock all Android phones. Choose an approved Android Enterprise/OEM management provider, confirm eligible use cases and model/OS support, enroll authorized devices using that provider's supported process, and implement provider-specific APIs server-side. Test only on owned/authorized staging devices. Never claim success based only on a push notification.

## Production checklist
- Configure HTTPS and secure cookies.
- Delete setup-admin.php.
- Use least-privilege DB credentials and external secret storage.
- Add MFA, rate limiting, monitoring, log retention, backup encryption and restore tests.
- Configure privacy/consent notices and legal review.
- Add and execute automated tests; this starter is not yet production-certified.
