# Android Enrollment Guide

1. Identify the approved Android Enterprise or OEM management provider.
2. Confirm the device model, OS version, business use case, enrollment method, and provider terms.
3. Enroll an organization-owned staging device using the provider's documented provisioning process.
4. Associate the provider's enrollment reference with the correct financing contract through a server-side verified workflow.
5. Verify status using the provider's authoritative API; do not infer policy application from FCM delivery.
6. Test reboot, offline, payment verification, restoration, and factory-reset recovery.
7. Document supported devices and known limitations before enrolling customers.

A consumer app cannot grant itself device-owner privileges after ordinary installation. Factory reset recovery depends on supported provider and manufacturer enrollment capabilities.
