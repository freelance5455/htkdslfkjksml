# API Notes

Implemented diagnostic endpoint: `GET /api/health.php` (requires the PHP configuration and database connection).

Planned versioned API routes for the next implementation stage:
- `POST /api/v1/auth/login`
- `POST /api/v1/devices/enrollment/start`
- `POST /api/v1/devices/enrollment/complete`
- `GET /api/v1/contracts/{id}/installments`
- `GET /api/v1/contracts/{id}/balance`
- `POST /api/v1/payments`
- `GET /api/v1/customers/{id}/payments`
- `POST /api/v1/devices/{id}/restriction-requests`
- `POST /api/v1/devices/{id}/restoration-requests`
- `GET /api/v1/devices/{id}/location/latest`

These planned routes are not implemented by this starter and must not be treated as live endpoints. Implement authentication, authorization, validation, rate limiting, idempotency, and audit logging before exposing them.
