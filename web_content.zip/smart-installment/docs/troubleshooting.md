# Troubleshooting

- **Database connection failed:** check config.php, DB credentials, host permissions, PDO MySQL extension, and server logs.
- **Login fails:** verify the admin was created, password, active flag, and database connection.
- **Contract not created:** add a customer first and ensure dates/amounts are valid.
- **Duplicate payment reference:** use a genuinely unique payment reference and idempotency key; do not create a second record to work around an unknown transaction outcome.
- **Android cannot connect:** verify HTTPS certificate, API base URL, DNS, firewall, and backend availability.
- **Firebase notifications absent:** confirm app registration, google-services.json, FCM setup, token handling, and server credentials.
- **Device management status unknown:** provider integration/enrollment is not configured or has not returned an authoritative status. Do not infer success from a notification.
