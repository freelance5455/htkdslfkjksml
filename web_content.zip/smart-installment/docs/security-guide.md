# Security Guide and Known Limitations

- This is a starter/MVP, not a completed security-certified production platform.
- The web session includes HttpOnly and SameSite cookie flags. HTTPS is mandatory in production. CSRF tokens protect implemented POST forms.
- PDO prepared statements are used for database operations.
- Add MFA, robust per-role permission middleware, login throttling, CSP/security headers, centralized monitoring, secret rotation, and security tests before production.
- The initial payment screen supports manual record entry and idempotency uniqueness. Add a separate verification/approval workflow before enabling online payments. Never trust screenshots as provider verification.
- Do not use sample data or this starter on real customer records until it has been reviewed and hardened.
- No covert tracking, anti-uninstall tricks, unauthorized accessibility-service abuse, or universal device locking is implemented.
- Location data collection is not implemented until a lawful, authorized provider/application workflow is configured.
