# Daily Money Tracker - Android Studio project

This project packages the expense tracker webpage inside the Android app assets and opens it using `file:///android_asset/index.html`. It does not depend on `appassets.androidplatform.net` or a hosted website.

## Build APK
1. Install Android Studio on a computer.
2. Open this folder (`DailyMoneyTracker`) in Android Studio.
3. Allow Gradle sync and install the Android SDK platform 35 if prompted.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio creates the APK under `app/build/outputs/apk/debug/`.

## Current prototype features
- Monthly income and expense balance
- Expense categories and subcategories, including vegetables, fruits, hotel, snacks and more
- Add custom categories
- Cash, UPI, HDFC Credit Card and Tata Credit Card payment selection
- Editable HDFC/Tata billing cycle, bill generation and due-date settings
- Expense history, monthly report and local backup/restore

## Important
- This is an Android Studio source project, not a compiled APK. This environment does not have Android SDK/build tools, so a signed or installable APK could not be compiled here.
- Data is stored locally in the app's WebView storage on this device. Export backups regularly.
- Voice input depends on WebView/device speech recognition support; if unavailable, use manual entry.
- Verify card statement dates with the issuer. This app is not connected to HDFC or Tata and does not fetch official bills.
