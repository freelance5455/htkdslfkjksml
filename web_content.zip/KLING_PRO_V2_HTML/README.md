KLING PRO V2 — Projet HTML professionnel
=========================================
Ouvrir index.html dans un navigateur.

Fonctions incluses :
- Tableau de bord
- Projets / clients
- Métré surface / volume / acier
- Devis avec calcul automatique
- Suivi chantier, rapport journalier, contrôle qualité
- Planning Gantt simplifié
- Paiements et dépenses
- Sélection de documents
- Génération PDF local et partage du fichier
- Export Excel compatible (.xls)
- Sauvegarde/restauration JSON
- Logo séparé sur la page de garde conceptuelle
- Cachet séparé pour les documents
- Fonctionnement sans CDN pour les fonctions principales

Pour une conversion APK fiable :
- embarquer tout le dossier localement ;
- conserver les fichiers logo.png et cachet.png ;
- utiliser une couche Android de partage de fichiers (Web Share/Capacitor ou équivalent) ;
- ne pas dépendre d’un CDN externe.
