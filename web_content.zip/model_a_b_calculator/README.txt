MODEL A & MODEL B CALCULATOR — SOURCE ZIP

Included: index.html, manifest.webmanifest, sw.js, icon.svg.

Features:
- Separate Model A and Model B tabs.
- Decimal transaction amounts and percentage rates.
- Each transaction amount is independently editable.
- Add as many transactions as needed and remove individual rows.
- Model A formula used here: for each transaction strictly above ₹10,000, estimated profit is 0.2% of that transaction amount plus ₹20.
- Model B default rates: customer charge 3%, platform fee 1.5%, commission 0.2%. Estimated profit = customer charges - platform fees + commission - individually entered transaction costs.

IMPORTANT: These are the formulas currently set in this source. Please check them against your intended Model A and Model B rules before relying on the results.

HOW TO MAKE AN APK USING ONLY A PHONE:
1. Extract this ZIP using your Android file manager.
2. Upload the extracted folder/files to a static website host (for example, a drag-and-drop host if supported) so index.html is available at a public HTTPS URL.
3. Open PWABuilder (https://www.pwabuilder.com/) in your phone browser and enter your hosted website URL.
4. Follow its Android packaging steps. If it requires signing, follow its current instructions. A built APK is not included in this ZIP; this is the source project for packaging.

The hosting and packaging services may change their mobile workflow or requirements. Do not enter card PINs, CVVs, passwords, or real customer personal information in this calculator.
