"use strict";
/* ============ CHAPTERS ============
   To add images to a chapter: drop files in assets/<id>/ and list their names in `images`.
   A chapter becomes playable automatically once it has 2+ images. */
const LEVELS = 120;
const CHAPTERS = [
  { id: "dragon-ball", name: "Dragon Ball", a: "#ff8a00", b: "#ffd23f", images: [
    "goku-smile","goku-flying","goku-ssj","goku-ssgss","goku-blue-attack","goku-vegeta-blue","goku-ultra-instinct",
    "gohan-ultimate","gohan-beast","gohan-beast-aura","krillin-attack","krillin-kamehameha",
    "gogeta-fight","gogeta-stand","gogeta-aura","kid-buu","kid-buu-fz","fat-buu","vegeta"].map(n => n + ".webp") },
  { id: "one-piece", name: "One Piece", a: "#d62839", b: "#f4b942", images: [
    "katakuri.webp","rob-lucci.webp","zoro-portrait.webp","brook.webp","luffy-poster.webp","kaido.webp","usopp.webp","hancock.webp","blackbeard.webp","luffy-smile.webp","franky.webp","crocodile.webp","doflamingo.webp","sanji.webp","zoro-full.webp","enel.webp","big-mom.webp","akainu.webp","luffy-gear5.webp","vivi.webp"] },
  { id: "demon-slayer", name: "Demon Slayer", a: "#1b998b", b: "#7bdff2", images: [] },
  { id: "naruto", name: "Naruto", a: "#f77f00", b: "#3a86ff", images: [] },
  { id: "bleach", name: "Bleach", a: "#ff7b00", b: "#6a4c93", images: [] },
  { id: "jujutsu-kaisen", name: "Jujutsu Kaisen", a: "#5e60ce", b: "#80ffdb", images: [] },
  { id: "hunter-x-hunter", name: "Hunter x Hunter", a: "#2a9d8f", b: "#e9c46a", images: [] },
  { id: "my-hero-academia", name: "My Hero Academia", a: "#2b9348", b: "#ef233c", images: [] }
];

/* ============ LEVEL GENERATOR ============
   per = seconds per pair, delay = ms mismatched cards stay open, preview = ms of initial peek,
   shuffle = reshuffle unmatched cards every N mistakes, lives = lives as multiple of pairs */
const TIERS = [
  { from: 1,   to: 20,  name: "Easy",      per: 14,  delay: 900, preview: 2500, shuffle: 0, lives: 0 },
  { from: 21,  to: 40,  name: "Normal",    per: 11,  delay: 800, preview: 1800, shuffle: 0, lives: 0 },
  { from: 41,  to: 60,  name: "Hard",      per: 8,   delay: 700, preview: 1200, shuffle: 6, lives: 0 },
  { from: 61,  to: 80,  name: "Very Hard", per: 6.5, delay: 650, preview: 800,  shuffle: 5, lives: 0 },
  { from: 81,  to: 100, name: "Extreme",   per: 5.2, delay: 550, preview: 500,  shuffle: 4, lives: 1.6 },
  { from: 101, to: 119, name: "Insane",    per: 4.2, delay: 480, preview: 0,    shuffle: 3, lives: 1.1 },
  { from: 120, to: 120, name: "Final Master Challenge", per: 3.6, delay: 450, preview: 0, shuffle: 3, lives: 0.8 }
];
function levelConfig(L) {
  const ti = TIERS.findIndex(t => L >= t.from && L <= t.to), T = TIERS[ti];
  const pairs = Math.round(3 + (L - 1) / (LEVELS - 1) * 21); // 3 pairs -> 24 pairs
  return { L, ti, tier: T.name, pairs, time: Math.round(pairs * T.per + 6), delay: T.delay,
    preview: T.preview, shuffle: T.shuffle, lives: T.lives ? Math.ceil(pairs * T.lives) : 0 };
}

/* ============ SAVE ============ */
const $ = s => document.querySelector(s);
let save = (() => { try { return JSON.parse(localStorage.getItem("amq")) || { u: {}, b: {} }; } catch (e) { return { u: {}, b: {} }; } })();
const persist = () => { try { localStorage.setItem("amq", JSON.stringify(save)); } catch (e) {} };
const unlocked = id => save.u[id] || 1;
const ready = c => c.images.length >= 2;
const shuffle = a => { for (let i = a.length - 1; i > 0; i--) { const j = Math.random() * (i + 1) | 0; [a[i], a[j]] = [a[j], a[i]]; } return a; };

/* ============ SOUND ============ */
let AC;
function snd(type) {
  if (save.m) return;
  try {
    AC = AC || new (window.AudioContext || window.webkitAudioContext)();
    const seq = { flip: [[500, .06]], match: [[660, .09], [880, .12]], wrong: [[200, .18]],
      win: [[523, .1], [659, .1], [784, .1], [1047, .3]], lose: [[300, .15], [220, .15], [150, .35]] }[type];
    let t = AC.currentTime;
    seq.forEach(([f, d]) => {
      const o = AC.createOscillator(), g = AC.createGain();
      o.frequency.value = f; o.type = (type === "wrong" || type === "lose") ? "sawtooth" : "triangle";
      g.gain.setValueAtTime(.15, t); g.gain.exponentialRampToValueAtTime(.001, t + d);
      o.connect(g); g.connect(AC.destination); o.start(t); o.stop(t + d); t += d * .9;
    });
  } catch (e) {}
}

/* ============ NAVIGATION ============ */
let ch = CHAPTERS[0];
function theme(c) {
  const r = document.documentElement.style;
  r.setProperty("--c1", c ? c.a : "#ff8a00"); r.setProperty("--c2", c ? c.b : "#ffd23f");
}
function go(id) {
  document.querySelectorAll(".screen").forEach(s => s.classList.toggle("active", s.id === id));
  if (id === "home" || id === "chapters" || id === "progress") theme(null);
  if (id === "chapters") renderChapters();
  if (id === "progress") renderProgress();
  if (id === "settings") $("#muteBtn").textContent = "Sound: " + (save.m ? "OFF" : "ON");
}
document.querySelectorAll("[data-go]").forEach(b => b.onclick = () => go(b.dataset.go));

function renderChapters() {
  const box = $("#chapterList"); box.innerHTML = "";
  CHAPTERS.forEach(c => {
    const ok = ready(c), done = unlocked(c.id) - 1;
    const d = document.createElement("div");
    d.className = "chap" + (ok ? "" : " locked");
    d.style.setProperty("--a", c.a); d.style.setProperty("--b", c.b);
    d.innerHTML = `<span class="tag">${ok ? "PLAYABLE" : "Locked · Coming Soon"}</span><h3>${c.name}</h3>
      <p>${LEVELS}/${LEVELS} Levels</p><div class="bar"><i style="width:${done / LEVELS * 100}%"></i></div>`;
    d.onclick = () => ok && openChapter(c);
    box.appendChild(d);
  });
}
function openChapter(c) {
  ch = c; theme(c); $("#lvTitle").textContent = c.name;
  const g = $("#levelGrid"); g.innerHTML = ""; const u = unlocked(c.id);
  for (let L = 1; L <= LEVELS; L++) {
    const cfg = levelConfig(L), b = save.b[c.id + ":" + L], lock = L > u;
    const e = document.createElement("button");
    e.className = `lv t${cfg.ti}` + (lock ? " lock" : "");
    e.innerHTML = `${lock ? "🔒" : L}<small>${b ? "★".repeat(b.st) : lock ? "" : cfg.pairs * 2 + "🂠"}</small>`;
    e.title = `Level ${L} · ${cfg.tier}`;
    e.onclick = () => !lock && startLevel(L);
    g.appendChild(e);
  }
  go("levels");
}
function renderProgress() {
  const box = $("#progList"); box.innerHTML = ""; let total = 0;
  CHAPTERS.forEach(c => {
    const done = unlocked(c.id) - 1; total += done;
    const stars = Object.keys(save.b).filter(k => k.startsWith(c.id + ":")).reduce((s, k) => s + save.b[k].st, 0);
    const d = document.createElement("div"); d.className = "chap" + (ready(c) ? "" : " locked");
    d.style.setProperty("--a", c.a); d.style.setProperty("--b", c.b);
    d.innerHTML = `<h3>${c.name}</h3><p>${done}/${LEVELS} cleared · ★ ${stars}/${LEVELS * 3}</p><div class="bar"><i style="width:${done / LEVELS * 100}%"></i></div>`;
    box.appendChild(d);
  });
  const t = document.createElement("div"); t.className = "chap"; t.style.setProperty("--a", "#5e60ce"); t.style.setProperty("--b", "#c77dff");
  t.innerHTML = `<h3>Total</h3><p>${total}/${LEVELS * CHAPTERS.length} levels cleared</p><div class="bar"><i style="width:${total / (LEVELS * CHAPTERS.length) * 100}%"></i></div>`;
  box.prepend(t);
}

/* ============ GAME ============ */
let G = null;
const fmt = s => { s = Math.max(0, Math.ceil(s)); return (s / 60 | 0) + ":" + String(s % 60).padStart(2, "0"); };

function startLevel(L) {
  clearInterval(G && G.timer);
  const cfg = levelConfig(L), n = ch.images.length;
  const imgs = shuffle(ch.images.slice());
  const cards = [];
  for (let p = 0; p < cfg.pairs; p++) for (let k = 0; k < 2; k++) cards.push({ pair: p, src: `assets/${ch.id}/${imgs[p % n]}`, v: p / n | 0 });
  shuffle(cards);
  G = { cfg, cards, first: null, lock: true, moves: 0, matches: 0, score: 0, combo: 0, maxCombo: 0,
    left: cfg.time, lives: cfg.lives, mism: 0, paused: false, over: false, timer: null };
  const board = $("#board"); board.innerHTML = "";
  cards.forEach((c, i) => {
    const e = document.createElement("div"); e.className = "card"; e.style.order = i;
    e.innerHTML = `<div class="inner"><div class="face front">?</div><div class="face back"><img alt="" draggable="false" src="${c.src}" style="filter:hue-rotate(${c.v * 70}deg)"></div></div>`;
    e.onclick = () => flip(c); c.el = e; board.appendChild(e);
  });
  $("#sLevel").textContent = "Level " + L; $("#sTier").textContent = cfg.tier;
  $("#livesBox").style.display = cfg.lives ? "" : "none";
  hud(); closeModal(); go("game");
  requestAnimationFrame(() => { fit(); preview(); });
}
function preview() {
  const g = G;
  if (g.cfg.preview) {
    g.cards.forEach(c => c.el.classList.add("flip"));
    setTimeout(() => { if (G !== g) return; g.cards.forEach(c => c.el.classList.remove("flip")); run(); }, g.cfg.preview);
  } else run();
}
function run() {
  G.lock = false;
  G.timer = setInterval(() => {
    if (G.paused || G.over) return;
    G.left -= .1; $("#sTime").textContent = fmt(G.left);
    if (G.left <= 0) lose("Time's up!");
  }, 100);
}
function hud() {
  $("#sTime").textContent = fmt(G.left); $("#sMoves").textContent = G.moves; $("#sScore").textContent = G.score;
  $("#sCombo").textContent = "x" + G.combo; $("#sAcc").textContent = (G.moves ? Math.round(G.matches / G.moves * 100) : 100) + "%";
  $("#sLives").textContent = "♥" + G.lives;
}
function fit() {
  if (!G) return;
  const w = $("#boardWrap"), W = w.clientWidth, H = w.clientHeight, n = G.cards.length, gap = innerWidth < 560 ? 5 : 8;
  let best = 0, bc = 2;
  for (let c = 2; c <= n; c++) {
    const r = Math.ceil(n / c), s = Math.min((W - gap * (c - 1)) / c, (H - gap * (r - 1)) / r * .75);
    if (s > best) { best = s; bc = c; }
  }
  best = Math.min(best, 170);
  const b = $("#board"); b.style.gap = gap + "px";
  b.style.gridTemplateColumns = `repeat(${bc},${best}px)`; b.style.gridAutoRows = `${best / .75}px`;
}
addEventListener("resize", fit);

function flip(c) {
  if (!G || G.lock || G.paused || G.over || c.done || c.el.classList.contains("flip")) return;
  c.el.classList.add("flip"); snd("flip");
  if (!G.first) { G.first = c; return; }
  const a = G.first, b = c; G.first = null; G.moves++; G.lock = true;
  if (a.pair === b.pair) {
    setTimeout(() => {
      G.combo++; G.maxCombo = Math.max(G.maxCombo, G.combo); G.matches++;
      G.score += 100 + (G.combo - 1) * 50;
      [a, b].forEach(x => { x.done = true; x.el.classList.remove("flip"); x.el.classList.add("done"); burst(x.el); });
      snd("match"); G.lock = false; hud();
      if (G.matches === G.cfg.pairs) win();
    }, 350);
  } else {
    G.combo = 0; G.mism++; G.score = Math.max(0, G.score - 10);
    if (G.cfg.lives) G.lives--;
    snd("wrong"); hud();
    setTimeout(() => {
      [a, b].forEach(x => { x.el.classList.remove("flip"); x.el.classList.add("shake"); setTimeout(() => x.el.classList.remove("shake"), 400); });
      if (G.cfg.lives && G.lives <= 0) return lose("No lives left!");
      if (G.cfg.shuffle && G.mism % G.cfg.shuffle === 0) shuffleBoard();
      G.lock = false;
    }, G.cfg.delay);
  }
}
function shuffleBoard() {
  const free = G.cards.filter(c => !c.done), orders = shuffle(free.map(c => +c.el.style.order));
  free.forEach((c, i) => { c.el.style.order = orders[i]; c.el.classList.add("shake"); setTimeout(() => c.el.classList.remove("shake"), 400); });
}
function burst(el) {
  const r = el.getBoundingClientRect(), x = r.left + r.width / 2, y = r.top + r.height / 2;
  for (let i = 0; i < 10; i++) {
    const s = document.createElement("i"), an = Math.PI * 2 * i / 10, d = 40 + Math.random() * 40;
    s.className = "spark"; s.style.cssText = `left:${x}px;top:${y}px;--x:${Math.cos(an) * d}px;--y:${Math.sin(an) * d}px`;
    document.body.appendChild(s); setTimeout(() => s.remove(), 700);
  }
}

/* ============ END SCREENS ============ */
function modal(html) { $("#modal").innerHTML = html; $("#overlay").classList.add("show"); }
function closeModal() { $("#overlay").classList.remove("show"); }
const act = (id, fn) => { const e = $("#" + id); if (e) e.onclick = fn; };

function win() {
  G.over = true; clearInterval(G.timer);
  const { cfg } = G, acc = G.matches / G.moves;
  G.score += Math.round(G.left * 5);
  const stars = acc >= .7 ? 3 : acc >= .45 ? 2 : 1, used = Math.round(cfg.time - G.left), key = ch.id + ":" + cfg.L;
  const o = save.b[key] || { s: 0, t: 9e9, m: 9e9, st: 0 };
  save.b[key] = { s: Math.max(o.s, G.score), t: Math.min(o.t, used), m: Math.min(o.m, G.moves), st: Math.max(o.st, stars) };
  if (cfg.L < LEVELS) save.u[ch.id] = Math.max(unlocked(ch.id), cfg.L + 1);
  else save.u[ch.id] = LEVELS + 1;
  persist(); snd("win");
  const b = save.b[key], last = cfg.L >= LEVELS;
  modal(`<h2>${last ? "CHAPTER MASTER!" : "VICTORY!"}</h2><div class="stars">${"<b>★</b>".repeat(stars)}${"★".repeat(3 - stars)}</div>
    <div class="row"><span>Score</span><b>${G.score}</b></div><div class="row"><span>Time</span><b>${used}s</b></div>
    <div class="row"><span>Moves</span><b>${G.moves}</b></div><div class="row"><span>Best Combo</span><b>x${G.maxCombo}</b></div>
    <div class="row"><span>Best Score / Time / Moves</span><b>${b.s} / ${b.t}s / ${b.m}</b></div>
    ${last ? "" : '<button class="btn big" id="nx" style="font-size:1.2rem;padding:10px">Next Level</button>'}
    <button class="btn" id="rt">Retry</button><button class="btn" id="bk">Levels</button>`);
  act("nx", () => startLevel(cfg.L + 1)); act("rt", () => startLevel(cfg.L)); act("bk", () => openChapter(ch));
}
function lose(why) {
  if (G.over) return; G.over = true; clearInterval(G.timer); snd("lose");
  modal(`<h2>GAME OVER</h2><p>${why}</p><div class="row"><span>Pairs found</span><b>${G.matches}/${G.cfg.pairs}</b></div>
    <button class="btn big" id="rt" style="font-size:1.2rem;padding:10px">Retry</button><button class="btn" id="bk">Back To Chapters</button>`);
  act("rt", () => startLevel(G.cfg.L)); act("bk", () => go("chapters"));
}
function pause() {
  if (!G || G.over || G.paused) return; G.paused = true;
  modal(`<h2>PAUSED</h2><button class="btn big" id="rs" style="font-size:1.2rem;padding:10px">Resume</button>
    <button class="btn" id="rt">Restart</button><button class="btn" id="ex">Exit</button>`);
  act("rs", () => { G.paused = false; closeModal(); }); act("rt", () => startLevel(G.cfg.L)); act("ex", () => { G.over = true; clearInterval(G.timer); closeModal(); openChapter(ch); });
}
$("#pauseBtn").onclick = pause;
document.addEventListener("visibilitychange", () => document.hidden && $("#game").classList.contains("active") && pause());
addEventListener("keydown", e => e.key === "Escape" && pause());

/* ============ SETTINGS ============ */
$("#muteBtn").onclick = () => { save.m = !save.m; persist(); $("#muteBtn").textContent = "Sound: " + (save.m ? "OFF" : "ON"); };
$("#resetBtn").onclick = () => { if (confirm("Reset all progress?")) { save = { u: {}, b: {}, m: save.m }; persist(); } };

/* ============ BACKGROUND PARTICLES ============ */
const cv = $("#fx"), cx = cv.getContext("2d");
let P = [];
function sizeCv() { cv.width = innerWidth; cv.height = innerHeight; }
sizeCv(); addEventListener("resize", sizeCv);
for (let i = 0; i < 45; i++) P.push({ x: Math.random(), y: Math.random(), r: 1 + Math.random() * 3, v: .0004 + Math.random() * .0012 });
(function loop() {
  cx.clearRect(0, 0, cv.width, cv.height);
  cx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue("--c2") || "#ffd23f";
  P.forEach(p => { p.y -= p.v; if (p.y < 0) { p.y = 1; p.x = Math.random(); } cx.globalAlpha = .35; cx.beginPath(); cx.arc(p.x * cv.width, p.y * cv.height, p.r, 0, 6.3); cx.fill(); });
  requestAnimationFrame(loop);
})();
