# CampusOne — Fully Offline / Free Prototype

This version is designed as an offline-first student app.

Works without internet after the app has been installed/opened once:
- Home dashboard
- Attendance and attendance calculations
- Full calendar with Present/Absent/Important + date notes
- Study notes
- Study planner and Pomodoro
- Assignments
- Practical information and guide
- Expense/money tracking
- Timetable data entry
- Calculator, percentage, GPA/CGPA helper, unit converter
- Date calculator and exam countdown
- Universal search across local notes/assignments
- Checklist
- Profile/settings demo

Important offline behavior:
- No paid service or subscription is required.
- No external web fonts, CDN, API, or online database is used by this prototype.
- App data is saved locally on the device/browser.
- A service worker caches the app shell for offline launching.
- College notices, cloud backup/sync, online AI, and automatic internet-based updates cannot happen without a connection; those are intentionally not required for the offline core.

For a production Android app, the same offline-first architecture should use a local SQLite/Room database rather than browser localStorage, plus optional user-controlled export/import backup.
