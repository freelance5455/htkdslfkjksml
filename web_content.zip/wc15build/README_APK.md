# World Conquest V15 — Android APK derleme paketi

Bu paket, V15 oyun dosyalarını ve Windows üzerinde Android debug APK üretmek için gereken Capacitor yapılandırmasını içerir. **Önceden derlenmiş bir APK içermez.** APK oluşturmak için Android SDK/JDK gerektiğinden bu çalışma ortamında APK derlemesi tamamlanamadı.

## Gereksinimler
- Windows 10/11
- Node.js LTS (npm dahil)
- Android Studio ve Android SDK (SDK Platform + Build-Tools)
- JDK 17 (Android Studio'nun gömülü JDK'si kullanılabilir)
- İlk kurulumda internet bağlantısı

## APK oluşturma
1. ZIP'i normal bir klasöre çıkarın.
2. `setup_android_windows.bat` dosyasını çalıştırın. Bu, npm paketlerini kurar, Capacitor Android projesini oluşturur ve `www/` oyun dosyalarını aktarır.
3. İşlem tamamlanınca `build_debug_apk.bat` dosyasını çalıştırın.
4. APK şu konumda oluşur: `android\app\build\outputs\apk\debug\app-debug.apk`
5. APK'yı Android telefon/tablete kopyalayıp yükleyin. Gerekirse Android ayarlarından bu kaynağa uygulama yükleme izni verin.

## Hata olursa
- Android Studio'da SDK Platform ve Build-Tools kurulu olduğundan emin olun.
- JDK 17 kullanın.
- İlk derlemede internet bağlantısı açık olsun.

Uygulama kimliği: `com.worldconquest.game`.


## Google Play altın satın alma (V21)
Dükkan arayüzü ve köprü `www/v21.js` içindedir. Satın almanın gerçekten çalışması için:
1. Play Console'da 4 adet **tüketilebilir (managed/consumable) uygulama içi ürün** oluşturun; kimlikleri `v21.js` başındaki `PACKS` ile aynı olsun (`gold_50`, `gold_150`, `gold_500`, `gold_1500`). Altın miktarı/kimlik `PACKS`tan değiştirilir.
2. Projede `npm install cordova-plugin-purchase` çalıştırıp `npx cap sync android` yapın (bu plugin `CdvPurchase` global'ini sağlar). Play Console'daki imzalı AAB'yi iç test kanalına yükleyip lisans test hesabıyla deneyin; debug APK'da faturalandırma çalışmaz.
3. Makbuz doğrulaması sunucu tarafında yapılmıyor (yalnızca istemci). Ciddi dağıtımda Google Play Developer API ile sunucuda doğrulama eklenmelidir.
