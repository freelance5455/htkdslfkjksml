# World Conquest — V12 (kaynak: world-conquest-v11-apk-ready.zip)

V11'in değişiklikleri (haritada bayrak yok, yakın kamera KMIN=6, rAF'li kamera, sürükleme sonrası yanlış seçim düzeltmesi) aynen duruyor.

## V12'de yapılanlar (yalnızca performans)
- **Geometri sadeleştirme** (`app.js` `simplifyTopo`): paylaşılan arc'larda 0.03° toleransla Douglas-Peucker. Nokta sayısı 8251 → 7894 (%4). Veri zaten kaba olduğu için kazanç küçük; komşuluk (612) ve ülke sayısı (174) değişmedi.
- **Zorunlu layout okumaları kesildi** (`area()`): sürükleme/zoom sırasında panel boyutu her olayda okunmuyor, hareket başında bir kez önbelleğe alınıyor.
- **Animasyonlar kısaltıldı** (`goTo`): kamera geçişleri en fazla 150 ms (önce 300–1000 ms; her karede tüm harita yeniden çiziliyordu).
- **Hareket sırasında sadeleştirme** (`v8.css`): etiketler, işaretçiler, ışın, vurgular, ızgara ve kıyı çizgisi `display:none`; ülke geçişi/kenarlık kapalı; `touch-action:none`; `path.c` renk geçişi tamamen kapalı.

## Kontroller (headless Chromium)
- e2e_v11 20/20, smoke 6/6, bonus 84/84, resume 7/7, scroll ALL PASS, rules5 23/23. Sayfa hatası yok.
- Gerçek tıklama ülkeyi seçiyor; sürükleme seçmiyor. (Geliştirme sırasında `pointer-events:none` kuralı tıklamayı bozdu, kaldırıldı.)
- Sentetik kare süresi V11 → V12: 420px medyan 16.7 → 16.7 ms (p95 aynı), 1280px medyan 33.3 → 33.3 ms. **Headless ortamda ölçülebilir fark yok.**

## Kalan / bilinen
- Kasma gerçek telefonda ölçülmedi; V12 değişiklikleri headless'ta ölçülebilir iyileşme göstermedi. Büyük olasılıkla darboğaz, SVG'nin zoom/pan sırasında GPU'da yeniden rasterlenmesi.
- Sıradaki adım (yapılmadı): sürükleme sırasında haritayı bitmap'e alıp CSS transform ile kaydırmak (veya canvas'a geçmek).
- APK derlenmedi (Android SDK yok). `setup_android_windows.bat` / `build_debug_apk.bat` kullanıcının kendi eklediği dosyalar, korundu.

## V14 (bu oturum)
- `v5.js`: YZ turu stratejik puanlamaya geçti (aiPlan: %30 hedef değeri BASE nüfus+ekonomi, %25 kazanma olasılığı 36 zar sonucu üzerinden battle(), %20 oyuncuyu sıkıştırma [bağlantı kesme / açık sınır / oyuncunun genişleme hedefini kapma], %15 toprak birleştirme, %10 rastgelelik; üst 3 aday arasında ağırlıklı seçim; kazanma olasılığı <%20 olan hamleler elenir; aynı rakibe 2+ kez üst üste odaklanma cezası). Tur kilidi G.aiBusy + attack5 AI için yalnızca 'v5ai' fazında.
- `v13.js` / `v13.css` (yeni): hedef simgeleri (nişangâh, statik, tek seferlik 0,22 sn belirme; yalnızca ülke SEÇİLİYKEN; dış hat animasyonu kapalı) ve yeni ana menü/mod seçimi.
- `index.html`: v13.css ve v13.js eklendi.
- Zaten mevcut olan (dokunulmadı): tek oyunculuda ilk zar yok, ödül/özellik kopyalama, 5/5 → %10 otomatik bonus.
- APK derlenmedi: Android SDK yok.

## V15
- www/v15.js + v15.css: ülkeye tıklayınca detay paneli doğrudan açılır (ad, 5 özellik, Tarih Notu, KEŞİF/SALDIRI); eski üst ikon çubuğu kaldırıldı (ülke + menü baloncuğu); ayarlar menü baloncuğundan. APK derlenmedi.

## V16 (bu oturum)
- www/v16.js + v16.css: denizden savaş (kara + kıyıdan kıyıya deniz hedefleri). Ayrıntı: DEVAM_DURUMU.md. APK derlenmedi.
