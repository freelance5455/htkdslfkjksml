V7 değişiklikleri: v7.js + v7.css (index.html'e eklendi). Mevcut dosyalar korunmuştur.
- Ülkeyi oyuncu seçer (radar grafik + tarihçe cümlesi, "Bu Ülkeyle Başla / Başka Ülke Seç"); kamera Türkiye çevresinden başlar.
- Bayraklar ülke geometrisine kırpılarak harita üzerinde; fetihte eski bayrak küçülüp silinir, yeni bayrak belirir.
- Yeni savaş ekranı: kılıç çarpışması, krem zarlar, çarpan ve beş özellik karşılaştırması; yeni tazminat/özellik kopyalama ekranı.
- Yüzen "Turu Bitir" düğmesi. Testler: tests/ (node tests/rules5_test.js; python3 tests/e2e_v7_*.py, Playwright).
