# DEVAM_DURUMU — World Conquest V16 (Bölüm 1/3: Denizden savaş)

Kaynak: world-conquest-v15-apk-ready.zip. Oyun baştan yazılmadı; harita, ülkeler, savaş/zar/tur sistemi, kamera, arayüz ve kayıt aynen korundu.

## Yapılanlar
- **www/v16.js (yeni)**: denizden savaş. `index.html`'de v15.js'ten sonra yüklenir.
  - Deniz bağlantısı = iki ülkenin kıyı noktaları arası en kısa mesafe ≤ 0,085 rad (~540 km) VE bu iki nokta arasındaki büyük daire hattı üçüncü bir ülkenin karasından geçmiyor (kuş uçuşu yakınlık tek başına yetmez).
  - Her ülke için en yakın 4 deniz komşusu tutulur (çift yönlü). Karayla çevrili ülkeler (LLK listesi) deniz bağlantısı kuramaz.
  - Komşusuz adalar (NZL, FJI vb.) için genişletilmiş menzil (≤ 0,40 rad, en çok 2 hedef); ATF için son çare 1 bağlantı. Sonuç: 174 ülke tek bağlantılı grafik, ~104 deniz bağlantısı, hesap ~35 ms (ilk kullanımda, tembel).
  - `targets()` artık kara komşuları + deniz bağlantılarını birlikte döndürür (önceden kara komşusu varsa deniz hiç gelmiyordu). Kara öncelikli: hem kara hem deniz varsa etiket 'land'. Kendine / kendi ülkene saldırı yok; geçersiz hedef `TG[id]` kontrolüyle engellenir; tur başına hamle/aynı hedef kuralları rules5.js'te aynen.
  - `battleSides()` (savaş animasyonunda saldıran taraf) ve `R5.pickLoss()` (kaybedilen savaşta verilen toprak) kara komşusu yoksa deniz bağlantılı kendi ülkelerini kullanır.
  - Arayüz: panel etiketi zaten "kara / deniz" gösteriyordu (v15). Haritada deniz hedefleri mavi çerçeve/mavi nişangâh, kara hedefleri kırmızı (`www/v16.css`, `v13.js`'de tek satır: `tgi-sea` sınıfı, `v16.js`'de overlay sarmalayıcı).
- **Bu oturum eklemeleri (v16.js/v16.css)**: panel ve detay penceresindeki hedef etiketi kara için 🏔 (kırmızı), deniz için 🚢 (mavi) olarak ayrıştırıldı; `doAttack` sarmalayıcısı geçersiz hedefi (anlık hedef listesinde olmayan) toast ile reddeder ve çift tetiklemeyi 500 ms kilitler (mevcut `G.busy`, `beginAttack` ve `attack5` kontrolleri korunur). Bu oturumda kullanıcı isteğiyle test çalıştırılmadı; yalnızca statik kod incelemesi yapıldı.
- Ordu, zar, battle(), repar(), tur ve kayıt hesapları DEĞİŞMEDİ.
- Debug: `WC.seaLinks()` (id → {komşu: mesafe rad}), `WC.seaReport()`.

## Kontroller (yalnızca kısa)
- node --check v16.js/v13.js; headless Chromium'da: sayfa hatası yok, deniz bağlantıları üretildi (GBR↔FRA/BEL/NLD, JPN↔KOR/RUS, ESP↔MAR, ITA↔TUN/HRV vb.), kendine bağlantı yok, karayla çevrili ülke yok, graf tek parça.
- Mevcut tests/e2e_smoke.js çalıştırıldı: 6/6 geçti. Diğer testler (bonus/resume/scroll/rules5/e2e_v11) bu oturumda çalıştırılmadı.

## Bilinen sınırlar / yapılamayanlar
- Harita kaba (~7,9 bin nokta, 0,03° sadeleştirilmiş): kıyı-kıyı mesafesi köşe noktalarından hesaplanır, yüzlerce km'lik küçük hatalar olabilir. Üçüncü ülke geçiş kontrolü ~76 km adımla örneklenir; çok küçük ülkeler atlanabilir.
- Gerçek deniz yolu/boğaz/şelf verisi yok; eşik (0,085 rad) ve KNN=4 `v16.js` başındaki sabitlerle ayarlanır. Bazı uzak bağlantılar (ör. GBR↔DNK ~510 km, NZL↔AUS ~1500 km) oyun dengesi için bilinçli bırakıldı.
- ATF (Fransız Güney Toprakları) gibi çok uzak ülkeler tek bir uzun deniz bağlantısı alır.
- Yapay zekâ (aiPlan) `targets()` üzerinden deniz hedeflerini de görür; deniz için özel strateji/ağırlık eklenmedi.
- APK derlenmedi (Android SDK yok); mobilde gerçek cihaz testi yapılmadı.

## Sonraki bölüm için
- Kod tabanı: global (IIFE olmayan) app.js + v5…v16 yamaları; her sürüm önceki fonksiyonları (`targets`, `render`, `overlay`, `labels`…) yeniden atayarak sarar. Yeni işler v17.js/v17.css olarak index.html'in sonuna eklenmeli.
- index.html sırası: i18n, app, rules5, v5, v6, v7, v8, v13, v14, v15, **v16**.

## V17 — Politikalar (hızlı teslim; TEST EDİLMEDİ, yalnızca `node --check`)
- www/v17.js + v17.css (yeni), index.html'e eklendi. Kendi ülkene tıklayınca panelde "📜 Politikalar" düğmesi; diğer ülkelerde yok.
- 6 politika, adlar istenen gibi. "İstikrar" değeri oyunda yok → İç Cephe Güvencesi Nüfus+Ekonomi'ye %10 verir.
- Uygulamak turu harcar (onay sorar, sonra Turu Bitir). Bonus 3 oyuncu zarı sürer. İlk savaş (saldırı/savunma): kazanılırsa kalıcı (tek sefer), kaybedilirse bonus kalkar + bildirim; 3 zarda savaş yoksa SONUÇSUZ (bonus kalkar, kalıcı yok).
- Geçici bonus st() içinde okunurken hesaplanır; temel değere yazılmaz. G.pol kayıtla saklanır. Aynı politika aktifken tekrar uygulanamaz.

## V18 — Altın sistemi (TEST EDİLMEDİ, yalnızca `node --check`)
- www/v18.js + v18.css. `GOLD_CFG` (v18.js başı) tek yerden ödül ayarı: win 50, loss 0. Bakiye G.gold (mevcut kayıtla saklanır, negatif olmaz).
- Üst gösterge: #hud'un ilk çipi "🪙 Altın: N" (dar ekranda etiket gizlenir). Ödül R5.conquer/R5.pickLoss kancalarında savaş başına bir kez.
- Mağaza altyapısı: window.Gold {get, can, add, spend, onChange, shop}. Gerçek para/ödeme YOK.
- Yalnızca tek oyunculu (v5) modda aktif; 2 kişilik modda gösterilmez.

## Düzeltme: Politikalar düğmesi v15 panelinde (.v15a satırı) görünmüyordu; v17.js artık oraya ekliyor. Headless testte: düğme çıkıyor, menü açılıyor, Yıldırım Seferberliği uygulanınca Ordu 19.8 → 21.78 (temel değer değişmedi).

## V19 — Savaş sonu altın ekranı, etiket merkezi, oyuncu rengi (TEST EDİLMEDİ, yalnızca `node --check`)
- **v18.js**: ödül artık savaş SONUÇ ekranı açılırken (showBattle sarmalayıcısı) savaş başına TEK kez hesaplanır (r._goldInfo ile mükerrer koruma). Formül: kazanma = 50 + min(150, round(tazminat×3)); kaybetme = 0 (GOLD_CFG, v18.js başı). Ekranda "Savaş Sonu Kazancı: +X Altın" + "Güncel Toplam Altın: N"; fetih sonrası "Savaş Sonucu" kartında da gösterilir. Eski R5.conquer/pickLoss ödül kancaları kaldırıldı (çift ödül olmasın).
- **v19.js (yeni)**: (1) G.plCol: oyuncu rengi, diğer tüm ülke renkleri + okyanus ile Lab ΔE ≥ 24 (komşularla ≥ 32) olacak şekilde seçilir, kayıtla saklanır, fetih kesinleşince (G.pend yok/done) toprak listesi değişmişse yeniden denetlenir, çakışma varsa yeni renk seçilir. (2) Etiket: birleşik kara bileşeninde, ağırlıklı merkeze yakın ve sınırdan uzak, yalnızca ülkenin kendi karasındaki nokta; yalnızca sahipliği değişen ülkeler için yeniden hesaplanır; zoom/kamerada yeniden hesap yok. Fetih seçimi bekleyen sürede etiket dondurulur.
- index.html'e v19.js eklendi.

## V19 HOTFIX — "Ana menü yok, sadece düz harita" hatası
- Neden: v19.js içinde renk dönüştürme fonksiyonu `lab()` adlandırılmıştı; IIFE içinde global `lab` (d3 etiket katmanı) değişkenini gölgeledi. `labels()` içindeki `lab.selectAll` bu yüzden TypeError verdi, render/paint kesildi, menü ve oyun arayüzü çizilmedi.
- Çözüm: fonksiyon `toLab()` olarak yeniden adlandırıldı (7 yer). Başka değişiklik yok. Test çalıştırılmadı (kullanıcı kuralı); yalnızca `node --check` ile tüm .js dosyaları sözdizimi açısından temiz.

## V19 ayar: oyuncu rengi yumuşatıldı (düşük doygunluk, G.plColV=2 ile eski cırtlak kayıtlar yeniden seçilir); komşu ülkeler için sahip grafiği üzerinde yeniden renklendirme (v19.js rebuildDC, yalnızca sahiplik değişince); altın ödülü win 2 + min(5, tazminat×0.1), yazı küçültüldü (v18.css). Test yok, node --check temiz.

## V20 — Uyumlu renk paleti + akıllı YZ turu (TEST EDİLMEDİ, yalnızca `node --check`)
- Palet: app.js `NP` ve v19.js `PAL` yumuşak, aynı doygunluk/parlaklıkta toprak tonlarına çevrildi; okyanus koyu petrol mavisi (app.css, v19 others()); oyuncu rengi canlı vurgu tonu (v19 cands).
- v20.js/v20.css (yeni): rakip her tur zar atar, zar kadar hamle yapar. Hamle türleri: keşif (bilinmeyen ülke ±%25 tahmin, keşifle kesinleşir; G.aik), diplomasi (6 turluk saldırmazlık paktı; G.pacts), politika (+%5 istatistik), saldırı (yalnızca kazanma olasılığı ≥ %58 ve hedef ≥1,15× güçlü değilse; tek toprağı kalmışsa ≥ %72). Güçlü komşuya saldırmaz: pakt kurar veya güçlenir. Her hamlede küçük animasyon kartı.
- v5.js: v5End -> V20.run, closeBattle -> V20.after (eski aiTurn yedek olarak duruyor).

## V20 ek (TEST EDİLMEDİ, yalnızca node --check)
- Sıra: oyuncudan sonra 2 rakip ülke oynar (v20.js başı `AI_TURNS = 2`), her biri kendi zarı kadar hamle yapar, sonra sıra oyuncuya geçer.
- Oyuncu paktı: başka ülkeyi seçince panelde "Saldırmazlık Paktı — N 🪙" (bedel ≈ 5 + güç/40, 5–25 altın). 6 tur boyunca iki taraf da saldıramaz (targets sarmalayıcısı + YZ planı). G.pacts kayıtla saklanır.
- Savaş sonu paneli sadeleştirildi (v7.js finish, v18.js altın satırı, v20.css): rozetler + açılır "Ayrıntı"; altın tek satır.

## V20 ek 2 (TEST EDİLMEDİ, yalnızca node --check)
- DR Kongo etiketi: i18n.js'de TR adı "Demokratik Kongo" (uzun ad uzak kamerada sığmıyordu).
- Harita/HUD arka planı düz tek renk #0b1d33 (app.css, v7.css; v19 renk denetimi güncel).
- Büyük ülkeler (RUS, CAN, USA, CHN, BRA, AUS): kadrajın ≥%6'sını kaplıyorsa etiket görünür kısmın içinde, sınırdan uzak noktaya kayar (v20.js relabel; kamera durunca 140 ms sonra). v19.js `window.V19.inMem/clearance` dışa açıldı.
- Oyun yokken/bitmişken: Devam Et yalnızca geçerli (bitmemiş, oyuncunun toprağı olan) kayıtta; harita pointer-events kapalı (body.idle20), menü kapatılamaz ve kapanırsa kendiliğinden yeniden açılır.

## V21 (TEST EDİLMEDİ, yalnızca node --check)
- v21.js/v21.css: Dükkan (altın çipine dokun veya ana menü / yetersiz altın penceresi). Google Play köprüsü `cordova-plugin-purchase` (CdvPurchase) ile; plugin yoksa satın alma çalışmaz, bilgi verir. PACKS ve kurulum README_APK.md'de. Altın işlem kimliğiyle tek kez eklenir (wc_pending_gold_v1 / wc_iap_done_v1).
- v20.js: oynayacak 2 rakip ülke artık tamamen rastgele seçilir (yakınlık/güç önemsiz).

## V22 (TEST EDİLMEDİ, yalnızca node --check)
- v22.js: enlem/boylam ızgarası düz çizgilerle ±900° uzatıldı (equirectangular doğrusal), dünya kenarında bitmez; sürüklerken gizlenmez (app.css/v8.css'ten `.moving .grat` kaldırıldı).
- v20.js haraç: AI oyuncunun SON toprağına saldıracaksa önce haraç penceresi: tutar = max(20–80 (AI gücüne göre), bakiyenin %40'ı). Öde → altın düşer, o ülkeyle 6 turluk pakt, saldırı iptal. Reddet → normal savaş yapılır (kaybedersen oyun biter). Altın yetmezse Dükkan açılır, kapanınca haraç penceresi geri gelir (v21 closeMod -> V20.reTribute).

## V24 (TEST EDİLMEDİ — kullanıcı kuralı; yalnızca `node --check`)
- **Keşif**: tur başına 2 hak (rules5.js `MAX_SCOUTS`, `T.scouts` sayacı; `T.scouted` = hak bitti). HUD çipi kalan hakkı gösterir (2/1/✖). Casus raporu (v23.js) her keşifte değil %35 olasılıkla (`FACT_P`).
- **Pakt / ateşkes** (v24.js): güçlü devlet (toplam güç ≥ 1,35×) güçsüzle pakt yapmayı %8 ihtimalle kabul eder; güçsüz devlet, güçlü devlet ile önemli bir tehlike (güçlü devletin ≥%75 gücünde üçüncü devlet) arasında tampon ise %70. Ayarlar v24.js başında. Reddedilirse ücret alınmaz, aynı ülkeyle bu tur tekrar denenemez (`G.pactNo24`). Pakt penceresinde uyarı gösterilir. YZ↔YZ pakt (v20.js step 'dip') aynı kurala tabi; reddedilen hedef o dizide tekrar seçilmez (`SEQ.nop`).
- **Elçi ekranı** (v24.css): yatay taşma düzeltildi (`.ecard` white-space:normal, `.envx` genişlik %100, overflow-x gizli); bayraklar + üç kart + ikonlar + fiyatlar sürekli animasyonlu.
- **Savaş paneli**: mobilde ekranın %70'i (v23.css); yazılar ~%10-15 küçültüldü (v24.css). Masaüstünde (≥900px) yan panel aynen duruyor.
- **Kamera** (v24.js, v20.js nextActor): sıra rakibe geçince kamera rakibin en büyük toprağına gider (tek sefer, kilit yok); rakip savaşı kapanınca kamera oyuncuya geri çekilmez.
- **Zar At** düğmesi sağ alta alındı (v24.css).

## V25 (TEST EDİLMEDİ — yalnızca node --check)
- Ana menü + mod seçimi: Osmanlı sancağı esinli (koyu kızıl zemin, altın çift çerçeve, sekiz köşeli yıldız deseni, hilâl+yıldız arması, altın saçak, parlayan başlık). v13.js menu()/modes() HTML'i, v25.css. Kutu genişliği 540px'e çıktı.
- Oyuncu rengi koyu kırmızı #a01220 (v23.js RED, v19.js pick sabit); diğer ülke renk kuralları aynen.
- Değerlemeler (app.js genStats): nükleer güç + nüfus ordu gücüne, teknoloji liderlerine çarpan, yumuşak güç diplomasiye eklendi. Türkiye: Nüfus ×1.10, Ordu ×1.15, Ekonomi ×1.12, Teknoloji ×1.15, Diplomasi ×1.15. Yalnızca YENİ oyunlarda (eski kayıtlar eski değerleri korur).

## V26 (TEST EDİLMEDİ — yalnızca node --check)
- Elçi menüsü: emoji tarzı ikonlar yerine detaylı, gölgeli/metalik SVG illüstrasyonlar (mühürlü parşömen antlaşma, altın kenarlı çelik kalkan, çapraz kılıçlar + alev, mühürlü zarf) — v23.js `ICON`. Fiyat/ödeme metinlerinden 🪙/🎲 emojileri kaldırıldı.
- Casus raporu olasılığı %25 (v23.js `FACT_P`).
- Koruma talebi: güçlü devlet yalnızca oyuncu, onunla başka bir güçlü devlet arasında TAMPON bölge ise kabul eder (v23.js `guardOk`, v24.js `isBuffer` iki güçlü devlet arasında anlamına göre güncellendi). Tampon değilsen pencerede açıklama çıkar, ödeme düğmesi gösterilmez.

## V27 (TEST EDİLMEDİ): savaş bitince zarlar + saldıran/savunan panelleri gizlenir, bayraklar 5 özellik karşılaştırmasının üstüne iner (v7.js finish .fl7, v24.css).

## V28 (TEST EDİLMEDİ): savaş sonu bayraklar büyütüldü (84x56), Haritaya Dön düğmesi sticky (aşağı kaymaz); fethedilen bölgeye tıklayınca panel/HUD fetheden ülkeyi gösterir (v15.js).

## V29 (TEST EDİLMEDİ): keşif → 'Keşif yapıldı' bildirimi (kalan hak ile), panelde detaylı KEŞİF RAPORU (sen/rakip değerleri, fark okları, toplam güç, zafer şansı, güçlü/zayıf yan, toprak, pakt) — v24.js report(); keşifte %25 'kime saldırmayı düşünüyor' istihbaratı (v24.js v24Intent, v23.js INTENT_P); YENİ ZAR modeli: obsidyen küp + altın işlemeli gözler (v24.css), düz savaş zarı ve Zar At düğmesi aynı modele geçti.

## V30 (TEST EDİLMEDİ): keşif raporu yeniden tasarlandı (yüzde yok; sen/rakip çift çubuklar, 4 kademeli saldırı değerlendirmesi + tehdit göstergesi, çipler); aynı ülke aynı turda iki kez keşfedilemez (T.sids); saldırı niyeti her keşifte gösterilir (INTENT_P=1).
