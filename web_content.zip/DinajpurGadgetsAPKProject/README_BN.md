# দিনাজপুর গ্যাজেটস Android APK project

এই প্রজেক্টে বর্তমান HTML অ্যাপটি Android WebView-এ চালানো হয় এবং HTML-এর file input-এর জন্য Android native file chooser যোগ করা হয়েছে (`onShowFileChooser`)। ফলে অ্যাপের ছবি যোগ/পরিবর্তন বাটন থেকে Gallery/Files picker খুলতে পারার কথা।

## APK তৈরির সহজতম উপায় (GitHub Actions)
1. ZIP ফাইলটি Extract করুন।
2. GitHub-এ নতুন একটি repository তৈরি করুন।
3. Extract করা ফোল্ডারের সব ফাইল repository-তে upload করুন (root-এ `.github`, `app`, Gradle ফাইলগুলো থাকতে হবে)।
4. GitHub repository → **Actions** → **Build APK** → **Run workflow** চাপুন।
5. কাজ শেষ হলে workflow-এর নিচের **Artifacts** থেকে `Dinajpur-Gadgets-APK` ডাউনলোড করুন। ZIP-এর ভেতরে `app-debug.apk` থাকবে।
6. APK ইনস্টল করার সময় Android-এর “Install unknown apps” অনুমতি চাইলে সেটি অনুমোদন করুন।

## গুরুত্বপূর্ণ
- এই source bundle নিজে APK নয়; এখানে APK build করার project আছে।
- Build হওয়া APK debug-signed হবে, নিজের ফোনে ইনস্টল করার জন্য সাধারণত যথেষ্ট।
- App data browser/WebView-এর local storage-এ থাকে; অ্যাপ uninstall বা data clear করলে ডেটা হারাতে পারে। নিয়মিত backup/export ব্যবহার করুন।
