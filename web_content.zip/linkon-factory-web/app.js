import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import { getAuth, onAuthStateChanged, GoogleAuthProvider, signInWithPopup, signInWithRedirect, signOut } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import {
  initializeFirestore, persistentLocalCache, persistentMultipleTabManager,
  collection, doc, getDoc, setDoc, updateDoc, onSnapshot, query, orderBy, limit, where,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";
import { firebaseConfig, FIRESTORE_DATABASE_ID, BOOTSTRAP_ADMIN_EMAIL } from "./firebase-config.js";

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = initializeFirestore(app, { localCache: persistentLocalCache({ tabManager: persistentMultipleTabManager() }) }, FIRESTORE_DATABASE_ID);

/* ---------- state ---------- */
const S = { user: null, profile: null, floor: [], batches: [], prod: [], rolls: [], ot: [], users: [], logs: [], params: [], view: "dashboard", ui: {} };
let unsubs = [];
let unsubParams = null;

const NAV = [
  ["dashboard", "Dashboard", "📊"], ["floor", "Floor List", "📋"], ["batches", "Batch Cards", "🏭"],
  ["params", "Parameters", "🎛️"], ["prod", "Production", "⚙️"], ["quality", "Quality", "🧵"],
  ["overtime", "Overtime", "⏱️"], ["reports", "Reports", "📈"], ["users", "Users", "👥"]
];
const ROLE_NAMES = { MAIN_ADMIN: "Main Admin", MANAGER: "Manager", WORKER: "Worker", HELPER: "Helper", VIEWER: "Viewer" };
const SHIFTS = [["SHIFT_A", "Shift A (Morning)"], ["SHIFT_B", "Shift B (Evening)"], ["SHIFT_C", "Shift C (Night)"]];
const DEFAULTS = {
  floors: ["Floor 01", "Floor 02", "Floor 03"],
  machines: ["Stenter 01", "Stenter 02", "Compactor 01", "Compactor 02"],
  types: ["STENTER", "COMPACTING"],
  buyers: ["H&M", "ZARA", "Marks & Spencer", "Target", "Next", "GAP"],
  fabrics: ["Single Jersey", "Interlock", "1x1 Rib", "2x2 Rib", "French Terry", "Fleece", "Pique"]
};

/* ---------- helpers ---------- */
const $ = (s, r = document) => r.querySelector(s);
const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const num = (v) => { const n = parseFloat(v); return Number.isFinite(n) ? n : 0; };
const fmt = (n) => (Math.round(n * 10) / 10).toLocaleString("en-US");
const todayStr = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`; };
const role = () => S.profile?.role || "VIEWER";
const isAdmin = () => role() === "MAIN_ADMIN";
const isManager = () => isAdmin() || role() === "MANAGER";
const canOperate = () => isManager() || role() === "WORKER" || role() === "HELPER";
const uniq = (arr) => [...new Set(arr.filter(Boolean))];
const batchOfFloor = () => Object.fromEntries(S.batches.map((b) => [b.floorListId, b.batchNumber]));

function toast(msg) {
  const t = $("#toast"); t.textContent = msg; t.style.display = "block";
  clearTimeout(toast.t); toast.t = setTimeout(() => (t.style.display = "none"), 3200);
}
const friendly = (e) => (e && e.code === "permission-denied" ? "You don't have permission for this action." : (e && e.message) || "Something went wrong.");

function badge(status) {
  const map = { PLANNED: "b-info", RUNNING: "b-warn", COMPLETED: "b-ok", ON_HOLD: "b-bad", PENDING: "b-info", IN_PROGRESS: "b-warn", HOLD: "b-bad", PASS: "b-ok", REJECT: "b-bad" };
  return `<span class="badge ${map[status] || ""}">${esc(String(status).replace("_", " "))}</span>`;
}
const kpi = (t, v, s = "", cls = "") => `<div class="kpi ${cls}"><div class="t">${esc(t)}</div><div class="v">${v}</div><div class="muted">${esc(s)}</div></div>`;
const empty = (title, text) => `<div class="card empty"><b>${esc(title)}</b><div class="sub mt">${esc(text)}</div></div>`;
const snapList = (snap) => snap.docs.map((d) => ({ id: d.id, ...d.data({ serverTimestamps: "estimate" }) }));

/* ---------- activity log (fail-safe, like the Android app) ---------- */
function logActivity(action, entityType, entityId, details) {
  if (!auth.currentUser) return;
  const ref = doc(collection(db, "activityLogs"));
  setDoc(ref, { action, entityType, entityId, details: String(details).slice(0, 1000), userId: auth.currentUser.uid, userEmail: auth.currentUser.email || "user@factory.local", createdAt: serverTimestamp() }).catch(() => {});
}

/* write helper: don't block the UI waiting for the server (works offline, syncs later) */
function save(promise, okMsg, done) {
  promise.catch((e) => toast(friendly(e)));
  toast(navigator.onLine ? okMsg : okMsg + " (will sync when online)");
  if (done) done();
}

/* ---------- modal / forms ---------- */
function closeModal() { $("#modal").classList.remove("open"); $("#sheet").innerHTML = ""; }
function openModal(title, bodyHtml, onSubmit, submitLabel = "Save") {
  $("#sheet").innerHTML = `<form id="mform"><div class="row between mb"><h2>${esc(title)}</h2><button type="button" class="btn ghost sm" id="mclose">✕</button></div>${bodyHtml}<div class="row mt" style="justify-content:flex-end"><button type="button" class="btn ghost" id="mcancel">Cancel</button><button class="btn" type="submit">${esc(submitLabel)}</button></div></form>`;
  $("#modal").classList.add("open");
  $("#mclose").onclick = $("#mcancel").onclick = closeModal;
  const form = $("#mform");
  form.onsubmit = (e) => { e.preventDefault(); onSubmit(Object.fromEntries(new FormData(form).entries())); };
  const inch = form.querySelector("[name=diaInch]");
  if (inch) { const out = $("#cm"); const upd = () => (out.textContent = (Math.round(num(inch.value) * 2.54 * 10) / 10) + " cm"); inch.oninput = upd; upd(); }
}
const attr = (o) => Object.entries(o).filter(([, v]) => v !== undefined && v !== false).map(([k, v]) => (v === true ? k : `${k}="${esc(v)}"`)).join(" ");
function field(label, name, o = {}) {
  const { type = "text", value = "", list, options, req, ...rest } = o;
  if (options) return `<div class="fld"><label>${esc(label)}</label><select name="${name}" ${req ? "required" : ""}>${options.map((x) => { const [v, l] = Array.isArray(x) ? x : [x, x]; return `<option value="${esc(v)}" ${String(v) === String(value) ? "selected" : ""}>${esc(l)}</option>`; }).join("")}</select></div>`;
  if (type === "textarea") return `<div class="fld"><label>${esc(label)}</label><textarea name="${name}" rows="2" ${attr(rest)}>${esc(value)}</textarea></div>`;
  return `<div class="fld"><label>${esc(label)}</label><input name="${name}" type="${type}" value="${esc(value)}" ${list ? `list="${list}"` : ""} ${req ? "required" : ""} ${attr(rest)}></div>`;
}
const datalist = (id, items) => `<datalist id="${id}">${uniq(items).map((x) => `<option value="${esc(x)}">`).join("")}</datalist>`;

/* ---------- CSV ---------- */
const csvCell = (v) => `"${String(v ?? "").replace(/"/g, '""')}"`;
const csvRow = (...c) => c.map(csvCell).join(",") + "\n";
function downloadCsv(name, text) {
  const blob = new Blob(["\ufeff" + text], { type: "text/csv;charset=utf-8" });
  const a = document.createElement("a"); a.href = URL.createObjectURL(blob);
  a.download = `${name}_${todayStr()}.csv`; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 4000);
}

/* ---------- shift totals ---------- */
function shiftTotals(date) {
  const day = S.prod.filter((p) => p.date === date);
  return SHIFTS.map(([k, l]) => { const s = day.filter((p) => p.shift === k); return { k, l, out: s.reduce((a, p) => a + p.productionQuantity, 0), target: s.reduce((a, p) => a + p.target, 0), n: s.length }; });
}
function totalsCardHtml(date) {
  const sh = shiftTotals(date);
  const recent = Object.entries(S.prod.filter((p) => p.date).reduce((m, p) => ((m[p.date] = (m[p.date] || 0) + p.productionQuantity), m), {})).sort((a, b) => b[0].localeCompare(a[0])).slice(0, 7);
  return `<div class="card"><h3>Daily &amp; Shift Totals</h3><div class="muted mb">Output for ${esc(date)}</div>
    ${sh.map((s) => `<div class="row between" style="padding:3px 0"><span class="sub">${esc(s.l)}</span><b>${fmt(s.out)} kg <span class="muted">(${s.n} logs)</span></b></div>`).join("")}
    <div class="box"><div>Day Total</div><div style="color:var(--red)">${fmt(sh.reduce((a, s) => a + s.out, 0))} kg</div></div>
    ${recent.length ? `<div class="muted mt">Recent days</div>${recent.map(([d, q]) => `<div class="row between sub" style="padding:2px 0"><span>${esc(d)}</span><span>${fmt(q)} kg</span></div>`).join("")}` : ""}</div>`;
}

/* ======================= VIEWS ======================= */
const views = {};
const pillRow = (key, items, cur) => `<div class="pills mb">${items.map(([v, l]) => `<button class="pill ${cur === v ? "on" : ""}" data-act="setUi" data-k="${key}" data-v="${esc(v)}">${esc(l || v)}</button>`).join("")}</div>`;
const machineNames = () => uniq([...DEFAULTS.machines, ...S.floor.map((f) => f.machineName)]);

/* ---- Dashboard ---- */
views.dashboard = {
  shell: () => `<div id="c"></div>`,
  refresh() {
    const t = todayStr();
    const todays = S.prod.filter((p) => p.date === t);
    const qty = todays.reduce((a, p) => a + p.productionQuantity, 0);
    const tgtRaw = todays.reduce((a, p) => a + p.target, 0);
    const tgt = tgtRaw > 0 ? tgtRaw : 25000;
    const pct = Math.min(100, Math.round((qty / tgt) * 100));
    const running = uniq(S.floor.filter((f) => f.status === "RUNNING").map((f) => f.machineName));
    const idle = machineNames().filter((m) => !running.includes(m));
    $("#c").innerHTML = `<h1>Dashboard</h1><div class="sub mb">Live factory overview</div>
      <div class="grid g4">${kpi("Floor entries", S.floor.length)}${kpi("Batch cards", S.batches.length, "", "info")}${kpi("Running batches", S.batches.filter((b) => b.status === "IN_PROGRESS").length, "", "warn")}${kpi("Completed", S.batches.filter((b) => b.status === "COMPLETED").length, "", "ok")}</div>
      <div class="card mt"><div class="row between"><h3>Today's output</h3><b>${fmt(qty)} / ${fmt(tgt)} kg</b></div><div class="bar mt"><i style="width:${pct}%"></i></div><div class="muted mt">${pct}% of target${tgtRaw > 0 ? "" : " (default daily quota)"}</div></div>
      <div class="grid"><div class="card"><h3>Running machines</h3><div class="sub mt">${running.length ? running.map(esc).join(", ") : "None running"}</div></div><div class="card"><h3>Idle machines</h3><div class="sub mt">${idle.length ? idle.map(esc).join(", ") : "None"}</div></div></div>
      ${isManager() ? `<div class="card"><h3>Recent activity</h3>${S.logs.slice(0, 8).map((l) => `<div class="sub mt"><b style="color:var(--text)">${esc(l.action)}</b> — ${esc(l.details)}<div class="muted">${esc(l.userEmail)}</div></div>`).join("") || `<div class="sub mt">No activity yet.</div>`}</div>` : ""}`;
  }
};

/* ---- Floor list ---- */
views.floor = {
  shell: () => `<div class="row between wrap mb"><div><h1>Floor List</h1><div class="sub">Dyeing &amp; finishing floor assignments — a Batch Card is created with every entry</div></div></div>
    <input data-ui="floorQ" placeholder="Search by Batch #, Order #, Buyer, Colour, Machine..." value="${esc(S.ui.floorQ || "")}">
    <div class="mt">${pillRow("floorStatus", [["ALL"], ["PLANNED"], ["RUNNING"], ["COMPLETED"], ["ON_HOLD", "ON HOLD"]], S.ui.floorStatus || "ALL")}</div>
    <div id="sum" class="sub mb" style="font-weight:700"></div><div id="list"></div>
    ${isManager() ? `<button class="fab" data-act="newFloor" title="New floor entry">+</button>` : ""}`,
  refresh() {
    const q = (S.ui.floorQ || "").toLowerCase(), st = S.ui.floorStatus || "ALL", bm = batchOfFloor();
    const list = S.floor.filter((f) => (st === "ALL" || f.status === st) && [bm[f.id], f.orderNumber, f.buyerName, f.colour, f.machineName].some((x) => String(x || "").toLowerCase().includes(q)));
    const plannedToday = S.floor.filter((f) => f.plannedDate === todayStr()).reduce((a, f) => a + f.quantity, 0);
    $("#sum").textContent = `Planned today: ${fmt(plannedToday)} kg  •  Showing ${list.length} entries (${fmt(list.reduce((a, f) => a + f.quantity, 0))} kg)`;
    $("#list").innerHTML = list.length ? list.map((f) => `<div class="card"><div class="row between"><div><h3>${esc(f.buyerName)} • Order ${esc(f.orderNumber)}</h3><div class="sub">${esc(f.floor)} • ${esc(f.machineName)} (${esc(f.machineType)})${f.machineLocation ? " • " + esc(f.machineLocation) : ""}</div></div>${badge(f.status)}</div>
      <div class="box"><div><small>Colour</small>${esc(f.colour)}</div><div><small>Fabric</small>${esc(f.fabricType)}</div><div><small>Dia</small>${f.diaInch}" / ${f.diaCm} cm</div><div><small>GSM</small>${f.gsm}</div><div><small>Qty</small>${fmt(f.quantity)} kg</div></div>
      <div class="muted mt">Batch No: <b style="color:var(--text)">${esc(bm[f.id] || "—")}</b>${f.plannedDate ? " • Planned " + esc(f.plannedDate) : ""}${f.unloadingTime ? " • Unloading " + esc(f.unloadingTime) : ""}</div>
      ${f.remarks ? `<div class="sub mt">Notes: ${esc(f.remarks)}</div>` : ""}
      ${isManager() ? `<div class="pills mt">${["PLANNED", "RUNNING", "COMPLETED", "ON_HOLD"].map((s) => `<button class="pill ${f.status === s ? "on" : ""}" data-act="floorStatus" data-id="${f.id}" data-v="${s}">${s.replace("_", " ")}</button>`).join("")}</div>` : ""}</div>`).join("") : empty("No floor entries found", q ? "Nothing matches your search." : isManager() ? "Tap + to create the first floor entry." : "Ask a manager to add entries.");
  }
};

/* ---- Batch cards ---- */
views.batches = {
  shell: () => `<h1>Batch Cards</h1><div class="sub mb">Track every batch from the floor list</div>
    <input data-ui="batchQ" placeholder="Search by Batch #, Buyer, Order #, Colour..." value="${esc(S.ui.batchQ || "")}">
    <div class="mt">${pillRow("batchStatus", [["ALL"], ["PENDING"], ["IN_PROGRESS", "IN PROGRESS"], ["COMPLETED"], ["HOLD"]], S.ui.batchStatus || "ALL")}</div><div id="list"></div>`,
  refresh() {
    const q = (S.ui.batchQ || "").toLowerCase(), st = S.ui.batchStatus || "ALL";
    const list = S.batches.filter((b) => (st === "ALL" || b.status === st) && [b.batchNumber, b.buyer, b.orderNumber, b.colour].some((x) => String(x || "").toLowerCase().includes(q)));
    $("#list").innerHTML = list.length ? list.map((b) => `<div class="card"><div class="row between"><div><h3>${esc(b.batchNumber)}</h3><div class="sub">${esc(b.buyer)} • Order ${esc(b.orderNumber)}</div></div>${badge(b.status)}</div>
      <div class="box"><div><small>Colour</small>${esc(b.colour)}</div><div><small>Fabric</small>${esc(b.fabricType)}</div><div><small>Dia</small>${b.dia} cm</div><div><small>GSM</small>${b.gsm}</div><div><small>Qty</small>${fmt(b.quantity)} kg</div></div>
      <div class="muted mt">${esc(b.floor)} • ${esc(b.machineId)} (${esc(b.machineType)})</div>
      <div class="pills mt">${canOperate() ? ["PENDING", "IN_PROGRESS", "COMPLETED", "HOLD"].map((s) => `<button class="pill ${b.status === s ? "on" : ""}" data-act="batchStatus" data-id="${b.id}" data-v="${s}">${s.replace("_", " ")}</button>`).join("") : ""}<button class="pill" data-act="openParams" data-id="${b.id}">🎛️ Parameters</button></div></div>`).join("") : empty("No batch cards", q ? "Nothing matches your search." : "Batch cards appear automatically when a floor entry is created.");
  }
};

/* ---- Parameters ---- */
views.params = {
  shell: () => `<h1>Machine Parameters</h1><div class="sub mb">Stenter &amp; Compacting settings with version history</div>
    <div class="fld"><label>Batch</label><select data-ui="paramBatch" id="pb"><option value="">Select a batch…</option>${S.batches.map((b) => `<option value="${b.id}" ${S.ui.paramBatch === b.id ? "selected" : ""}>${esc(b.batchNumber)} — ${esc(b.buyer)} ${esc(b.colour)}</option>`).join("")}</select></div>
    <div id="list"></div>`,
  refresh() {
    const id = S.ui.paramBatch;
    if (id !== views.params._sub) { views.params._sub = id; watchParams(id); }
    if (!id) { $("#list").innerHTML = empty("Select a batch", "Choose a batch to see and add machine parameters."); return; }
    const b = S.batches.find((x) => x.id === id);
    $("#list").innerHTML = `${canOperate() ? `<button class="btn mb" data-act="newParams">+ New parameter set${b ? " for " + esc(b.batchNumber) : ""}</button>` : ""}` +
      (S.params.length ? S.params.map((p) => `<div class="card"><div class="row between"><h3>${esc(p.machineType)} • v${p.version}</h3><span class="muted">${p.createdAt?.toDate ? p.createdAt.toDate().toLocaleString() : ""}</span></div>
        <div class="box"><div><small>Speed</small>${p.speed} m/min</div><div><small>Temp</small>${p.temperature} °C</div><div><small>Width</small>${p.width}</div><div><small>Overfeed</small>${p.overfeed}%</div><div><small>Underfeed</small>${p.underfeed}%</div><div><small>Dwell</small>${p.dwellTime}s</div></div>
        ${p.customParams ? `<div class="sub mt">Custom: ${esc(p.customParams)}</div>` : ""}${p.remarks ? `<div class="sub mt">Notes: ${esc(p.remarks)}</div>` : ""}</div>`).join("") : empty("No parameters saved", "Add the first parameter set for this batch."));
  }
};
function watchParams(batchId) {
  if (unsubParams) { unsubParams(); unsubParams = null; }
  S.params = [];
  if (!batchId) return;
  unsubParams = onSnapshot(query(collection(db, "fabricParameters"), where("batchId", "==", batchId)), (s) => {
    S.params = snapList(s).sort((a, b) => b.version - a.version);
    if (S.view === "params") views.params.refresh();
  }, (e) => toast(friendly(e)));
}

/* ---- Production ---- */
views.prod = {
  shell: () => `<div class="row between wrap mb"><div><h1>Production</h1><div class="sub">Shift-based output and target performance</div></div></div><div id="kp" class="grid mb"></div>
    <details id="tot" ${S.ui.showTotals ? "open" : ""}><summary>Daily &amp; shift totals</summary><div id="totbody"></div></details><h2 class="mt mb">Shift output history</h2><div id="list"></div>
    ${canOperate() ? `<button class="fab" data-act="newProd">+</button>` : ""}`,
  refresh() {
    const t = todayStr(), todays = S.prod.filter((p) => p.date === t), q = todays.reduce((a, p) => a + p.productionQuantity, 0), tg = todays.reduce((a, p) => a + p.target, 0);
    $("#kp").innerHTML = kpi("Today's output", fmt(q) + " kg", "Total fabric finished") + kpi("Daily target", fmt(tg > 0 ? tg : 25000) + " kg", "Quota", "ok");
    $("#totbody").innerHTML = totalsCardHtml(t);
    $("#list").innerHTML = S.prod.length ? S.prod.map((p) => `<div class="card"><div class="row between"><div><h3>Batch ${esc(p.batchNumber)}</h3><div class="sub">${esc(p.machine)} • ${esc(p.floor)}</div></div>${badge(String(p.shift || "").replace("_", " "))}</div>
      <div class="box"><div><small>Output</small>${fmt(p.productionQuantity)} kg</div><div><small>Target</small>${fmt(p.target)} kg</div></div><div class="muted mt">${esc(p.date)} • Worker: ${esc(p.worker)}</div>${p.remarks ? `<div class="sub mt">Notes: ${esc(p.remarks)}</div>` : ""}</div>`).join("") : empty("No production logs yet", "Tap + to log output for a machine shift.");
  }
};

/* ---- Quality / shade rolls ---- */
views.quality = {
  shell: () => `<h1>Shade &amp; Roll Quality</h1><div class="sub mb">Roll inspection and pass / hold / reject decisions</div><div id="kp" class="grid mb"></div><div id="list"></div>${canOperate() ? `<button class="fab" data-act="newRoll">+</button>` : ""}`,
  refresh() {
    const r = S.rolls, pass = r.filter((x) => x.quality === "PASS").length, rate = r.length ? Math.round((pass / r.length) * 100) : 100;
    $("#kp").innerHTML = kpi("Pass rate", rate + "%", `${pass} / ${r.length} inspected`, "ok") + kpi("Hold / Reject", `${r.filter((x) => x.quality === "HOLD").length} / ${r.filter((x) => x.quality === "REJECT").length}`, "Needs re-dyeing", "warn");
    $("#list").innerHTML = r.length ? r.map((x) => `<div class="card"><div class="row between"><h3>Roll #${esc(x.rollNumber)}</h3>${badge(x.quality)}</div><div class="sub">Batch: ${esc(x.batchNumber)} • Shade: ${esc(x.shadeNumber)} (${esc(x.colour)})</div>
      <div class="box"><div><small>Weight</small>${x.weight} kg</div><div><small>Length</small>${x.length} m</div></div>${x.remarks ? `<div class="sub mt">Notes: ${esc(x.remarks)}</div>` : ""}</div>`).join("") : empty("No roll inspections yet", "Tap + to record weight, length and the quality verdict.");
  }
};

/* ---- Overtime ---- */
views.overtime = {
  shell: () => `<h1>Overtime</h1><div class="sub mb">Worker overtime hours by date and shift</div><div id="kp" class="grid mb"></div>
    <input data-ui="otQ" placeholder="Search worker name, ID or date" value="${esc(S.ui.otQ || "")}"><div id="list" class="mt"></div>${canOperate() ? `<button class="fab" data-act="newOt">+</button>` : ""}`,
  refresh() {
    const t = todayStr(), m = t.slice(0, 7), q = (S.ui.otQ || "").toLowerCase();
    const sum = (a) => a.reduce((s, o) => s + o.hours, 0);
    $("#kp").innerHTML = kpi("Today", fmt(sum(S.ot.filter((o) => o.date === t))) + " h", "Overtime logged") + kpi("This month", fmt(sum(S.ot.filter((o) => o.date.startsWith(m)))) + " h", S.ot.filter((o) => o.date.startsWith(m)).length + " entries", "warn");
    const list = S.ot.filter((o) => !q || [o.workerName, o.workerId, o.date].some((x) => String(x || "").toLowerCase().includes(q)));
    $("#list").innerHTML = list.length ? list.map((o) => `<div class="card"><div class="row between"><div><h3>${esc(o.workerName)}</h3><div class="sub">ID: ${esc(o.workerId || "-")} • ${esc(o.date)}${o.shift ? " • " + esc(o.shift) : ""}</div></div><b style="color:var(--red);font-size:18px">${fmt(o.hours)} h</b></div>
      ${o.reason || o.approvedBy ? `<div class="box" style="display:block">${o.reason ? `<div style="font-weight:400" class="sub">Reason: ${esc(o.reason)}</div>` : ""}${o.approvedBy ? `<div class="muted" style="font-weight:400">Approved by: ${esc(o.approvedBy)}</div>` : ""}</div>` : ""}</div>`).join("") : empty("No overtime", q ? "Nothing matches your search." : "Tap + to log overtime.");
  }
};

/* ---- Reports ---- */
views.reports = {
  shell: () => `<h1>Reports</h1><div class="sub mb">Yield, output and quality overview with CSV export</div>
    <div class="fld"><label>Machine filter</label><select data-ui="repMachine"><option value="ALL">All machines</option>${machineNames().map((m) => `<option ${S.ui.repMachine === m ? "selected" : ""}>${esc(m)}</option>`).join("")}</select></div>
    <div id="kp" class="grid g3 mb"></div><div id="mach"></div>
    <div class="card"><h3>Export CSV</h3><div class="sub mb">Files download to your device and open in Excel or Sheets.</div><div class="pills" style="flex-wrap:wrap">
      ${[["production", "Production"], ["totals", "Daily & Shift Totals"], ["rolls", "Shade Rolls"], ["floor", "Floor List"], ["batches", "Batch Cards"], ["overtime", "Overtime"], ...(isManager() ? [["activity", "Activity Log"]] : [])].map(([k, l]) => `<button class="pill" data-act="export" data-k="${k}">⬇ ${l}</button>`).join("")}</div></div>`,
  refresh() {
    const f = S.ui.repMachine || "ALL", pr = S.prod.filter((p) => f === "ALL" || p.machine === f);
    const out = pr.reduce((a, p) => a + p.productionQuantity, 0), tg = pr.reduce((a, p) => a + p.target, 0);
    const pass = S.rolls.filter((r) => r.quality === "PASS").length;
    $("#kp").innerHTML = kpi("Total output", fmt(out) + " kg", `${pr.length} logs`) + kpi("Target met", (tg > 0 ? Math.round((out / tg) * 100) : 100) + "%", `Target ${fmt(tg)} kg`, "ok") + kpi("Roll pass rate", (S.rolls.length ? Math.round((pass / S.rolls.length) * 100) : 100) + "%", `${S.rolls.length} rolls`, "info");
    const byM = pr.reduce((m, p) => ((m[p.machine] = (m[p.machine] || 0) + p.productionQuantity), m), {}), max = Math.max(1, ...Object.values(byM));
    $("#mach").innerHTML = Object.keys(byM).length ? `<div class="card"><h3>Output by machine</h3>${Object.entries(byM).sort((a, b) => b[1] - a[1]).map(([m, v]) => `<div class="mt"><div class="row between sub"><span>${esc(m)}</span><b>${fmt(v)} kg</b></div><div class="bar"><i style="width:${Math.round((v / max) * 100)}%"></i></div></div>`).join("")}</div>` : "";
  }
};

/* ---- Users (Main Admin) ---- */
views.users = {
  shell: () => `<h1>User Management</h1><div class="sub mb">Assign roles and activate or deactivate accounts. Up to 4 Managers.</div><div id="list"></div>`,
  refresh() {
    $("#list").innerHTML = S.users.length ? S.users.map((u) => { const me = u.id === S.user.uid; return `<div class="card"><div class="row between"><div><h3>${esc(u.displayName)} ${me ? '<span class="muted">(you)</span>' : ""}</h3><div class="sub">${esc(u.email)}</div></div>${badge(u.isActive ? "ACTIVE" : "INACTIVE").replace("b-info", "")}</div>
      <div class="row mt wrap"><select id="r_${u.id}" style="width:auto;flex:1" ${me ? "disabled" : ""}>${Object.entries(ROLE_NAMES).map(([k, l]) => `<option value="${k}" ${u.role === k ? "selected" : ""}>${l}</option>`).join("")}</select>
      <label class="row" style="margin:0"><input type="checkbox" id="a_${u.id}" style="width:auto" ${u.isActive ? "checked" : ""} ${me ? "disabled" : ""}> Active</label><button class="btn sm" data-act="saveUser" data-id="${u.id}" ${me ? "disabled" : ""}>Save</button></div></div>`; }).join("") : empty("No users yet", "Users appear after their first sign-in.");
  }
};

/* ======================= FORMS & ACTIONS ======================= */
const formDlg = {
  floor() {
    openModal("New Floor Entry", `${datalist("dlF", [...DEFAULTS.floors, ...S.floor.map((f) => f.floor)])}${datalist("dlM", machineNames())}${datalist("dlT", [...DEFAULTS.types, ...S.floor.map((f) => f.machineType)])}${datalist("dlB", [...DEFAULTS.buyers, ...S.floor.map((f) => f.buyerName)])}${datalist("dlFa", [...DEFAULTS.fabrics, ...S.floor.map((f) => f.fabricType)])}
      <div class="f2">${field("Floor", "floor", { list: "dlF", req: true, maxlength: 50, value: "Floor 01" })}${field("Planned date", "plannedDate", { type: "date", value: todayStr(), req: true })}</div>
      <div class="f2">${field("Machine name", "machineName", { list: "dlM", req: true, maxlength: 100 })}${field("Machine type", "machineType", { list: "dlT", req: true, maxlength: 100, value: "STENTER" })}</div>
      <div class="f2">${field("Machine location", "machineLocation", { maxlength: 100 })}${field("Unloading time", "unloadingTime", { type: "time" })}</div>
      <div class="f2">${field("Buyer", "buyerName", { list: "dlB", req: true, maxlength: 100 })}${field("Order number", "orderNumber", { req: true, maxlength: 100 })}</div>
      <div class="f2">${field("Colour", "colour", { req: true, maxlength: 50 })}${field("Fabric type", "fabricType", { list: "dlFa", req: true, maxlength: 100 })}</div>
      <div class="f2">${field("Dia (inch, 40–120)", "diaInch", { type: "number", min: 40, max: 120, step: "0.5", value: 60, req: true })}<div class="fld"><label>Dia (cm)</label><div id="cm" style="padding:10px;background:var(--dark);border-radius:8px"></div></div></div>
      <div class="f2">${field("GSM (80–500)", "gsm", { type: "number", min: 80, max: 500, step: "1", value: 180, req: true })}${field("Quantity (kg)", "quantity", { type: "number", min: 0, step: "any", req: true })}</div>
      ${field("Remarks", "remarks", { type: "textarea", maxlength: 500 })}`,
      (v) => {
        const uid = auth.currentUser.uid, inch = num(v.diaInch), cm = Math.round(inch * 2.54 * 10) / 10;
        const fRef = doc(collection(db, "floorList")), bRef = doc(db, "batchCards", "batch_" + fRef.id);
        const batchNo = "LOT-" + String(Date.now()).slice(-6), ts = serverTimestamp();
        const base = { colour: v.colour.trim(), fabricType: v.fabricType.trim(), gsm: num(v.gsm), quantity: num(v.quantity), userId: uid, createdAt: ts, updatedAt: ts };
        const p1 = setDoc(fRef, { floor: v.floor.trim(), machineName: v.machineName.trim(), machineType: v.machineType.trim(), machineLocation: (v.machineLocation || "").trim(), unloadingTime: v.unloadingTime || "", buyerName: v.buyerName.trim(), orderNumber: v.orderNumber.trim(), diaInch: inch, diaCm: cm, plannedDate: v.plannedDate, remarks: v.remarks || "", status: "PLANNED", ...base });
        const p2 = setDoc(bRef, { batchNumber: batchNo, floorListId: fRef.id, floor: v.floor.trim(), machineId: v.machineName.trim(), machineType: v.machineType.trim(), location: (v.machineLocation || "").trim(), unloadingTime: v.unloadingTime || "", buyer: v.buyerName.trim(), orderNumber: v.orderNumber.trim(), dia: cm, status: "PENDING", ...base });
        save(Promise.all([p1, p2]).then(() => logActivity("CREATE_FLOOR_AND_BATCH", "FLOOR_LIST", fRef.id, `Created floor entry for ${v.buyerName} order ${v.orderNumber}. Linked batch ${batchNo}`)), `Floor entry created • Batch ${batchNo}`, closeModal);
      }, "Save & Create Batch Card");
  },
  params() {
    const b = S.batches.find((x) => x.id === S.ui.paramBatch); if (!b) return;
    openModal(`Parameters • ${b.batchNumber}`, `${field("Machine type", "machineType", { options: ["STENTER", "COMPACTING"] })}
      <div class="f2">${field("Speed (m/min)", "speed", { type: "number", min: 0, step: "any", req: true })}${field("Temperature (°C)", "temperature", { type: "number", min: 0, step: "any", req: true })}</div>
      <div class="f2">${field("Width", "width", { type: "number", min: 0, step: "any", req: true })}${field("Dwell time (s)", "dwellTime", { type: "number", min: 0, step: "any", req: true })}</div>
      <div class="f2">${field("Overfeed %", "overfeed", { type: "number", step: "any", value: 0 })}${field("Underfeed %", "underfeed", { type: "number", step: "any", value: 0 })}</div>
      ${field("Custom parameters", "customParams", { maxlength: 1000, placeholder: "e.g. Softener 20 g/l" })}${field("Remarks", "remarks", { type: "textarea", maxlength: 500 })}`,
      (v) => {
        const version = Math.max(0, ...S.params.map((p) => p.version)) + 1, ref = doc(collection(db, "fabricParameters")), ts = serverTimestamp();
        save(setDoc(ref, { batchId: b.id, batchNumber: b.batchNumber, machineType: v.machineType, speed: num(v.speed), temperature: num(v.temperature), width: num(v.width), overfeed: num(v.overfeed), underfeed: num(v.underfeed), dwellTime: num(v.dwellTime), customParams: v.customParams || "", version, remarks: v.remarks || "", userId: auth.currentUser.uid, createdAt: ts, updatedAt: ts }).then(() => logActivity("SAVE_PARAMETERS", "MACHINE_PARAMS", ref.id, `Saved ${v.machineType} parameters v${version} for Batch ${b.batchNumber} (Speed: ${v.speed}, Temp: ${v.temperature})`)), `Parameters v${version} saved`, closeModal);
      });
  },
  prod() {
    openModal("Log Production", `${datalist("dlBn", S.batches.map((b) => b.batchNumber))}${datalist("dlF", [...DEFAULTS.floors, ...S.floor.map((f) => f.floor)])}${datalist("dlM", machineNames())}
      <div class="f2">${field("Batch number", "batchNumber", { list: "dlBn", req: true, maxlength: 100 })}${field("Date", "date", { type: "date", value: todayStr(), req: true })}</div>
      <div class="f2">${field("Floor", "floor", { list: "dlF", req: true, maxlength: 50 })}${field("Machine", "machine", { list: "dlM", req: true, maxlength: 100 })}</div>
      <div class="f2">${field("Output (kg)", "productionQuantity", { type: "number", min: 0, step: "any", req: true })}${field("Target (kg)", "target", { type: "number", min: 0, step: "any", value: 0 })}</div>
      <div class="f2">${field("Worker", "worker", { req: true, maxlength: 100, value: S.profile?.displayName || "" })}${field("Shift", "shift", { options: SHIFTS })}</div>
      ${field("Remarks", "remarks", { type: "textarea", maxlength: 500 })}`,
      (v) => {
        const ref = doc(collection(db, "production")), ts = serverTimestamp();
        save(setDoc(ref, { batchNumber: v.batchNumber.trim(), date: v.date, floor: v.floor.trim(), machine: v.machine.trim(), productionQuantity: num(v.productionQuantity), target: num(v.target), worker: v.worker.trim(), shift: v.shift, remarks: v.remarks || "", userId: auth.currentUser.uid, createdAt: ts, updatedAt: ts }).then(() => logActivity("RECORD_PRODUCTION", "PRODUCTION", ref.id, `Logged ${v.productionQuantity} kg for Batch ${v.batchNumber} on ${v.machine} (${v.shift})`)), "Production logged", closeModal);
      });
  },
  roll() {
    openModal("Roll Inspection", `${datalist("dlBn", S.batches.map((b) => b.batchNumber))}
      <div class="f2">${field("Roll number", "rollNumber", { req: true, maxlength: 100 })}${field("Batch number", "batchNumber", { list: "dlBn", req: true, maxlength: 100 })}</div>
      <div class="f2">${field("Shade number", "shadeNumber", { req: true, maxlength: 100 })}${field("Colour", "colour", { req: true, maxlength: 50 })}</div>
      <div class="f2">${field("Weight (kg)", "weight", { type: "number", min: 0, step: "any", req: true })}${field("Length (m)", "length", { type: "number", min: 0, step: "any", req: true })}</div>
      ${field("Verdict", "quality", { options: ["PASS", "HOLD", "REJECT"] })}${field("Remarks", "remarks", { type: "textarea", maxlength: 500 })}`,
      (v) => {
        const ref = doc(collection(db, "shadeRolls")), ts = serverTimestamp();
        save(setDoc(ref, { rollNumber: v.rollNumber.trim(), batchNumber: v.batchNumber.trim(), shadeNumber: v.shadeNumber.trim(), colour: v.colour.trim(), weight: num(v.weight), length: num(v.length), quality: v.quality, remarks: v.remarks || "", userId: auth.currentUser.uid, createdAt: ts, updatedAt: ts }).then(() => logActivity("RECORD_SHADE_ROLL", "SHADE_ROLL", ref.id, `Roll ${v.rollNumber} for Batch ${v.batchNumber} inspected: ${v.quality}`)), "Inspection saved", closeModal);
      });
  },
  ot() {
    openModal("Log Overtime", `<div class="f2">${field("Worker name", "workerName", { req: true, maxlength: 100 })}${field("Worker ID", "workerId", { maxlength: 100 })}</div>
      <div class="f2">${field("Date", "date", { type: "date", value: todayStr(), req: true })}${field("Hours (0–24)", "hours", { type: "number", min: 0.25, max: 24, step: "0.25", req: true })}</div>
      ${field("Shift", "shift", { options: SHIFTS })}${field("Reason", "reason", { maxlength: 500 })}${field("Approved by", "approvedBy", { maxlength: 100, value: S.profile?.displayName || "" })}`,
      (v) => {
        const ref = doc(collection(db, "overtime")), ts = serverTimestamp(), hrs = num(v.hours);
        if (!(hrs > 0 && hrs <= 24)) return toast("Hours must be more than 0 and at most 24.");
        save(setDoc(ref, { workerName: v.workerName.trim(), workerId: (v.workerId || "").trim(), date: v.date, shift: v.shift, hours: hrs, reason: v.reason || "", approvedBy: v.approvedBy || "", userId: auth.currentUser.uid, createdAt: ts, updatedAt: ts }).then(() => logActivity("RECORD_OVERTIME", "OVERTIME", ref.id, `Logged ${hrs} hrs overtime for ${v.workerName}`)), "Overtime saved", closeModal);
      });
  }
};

const EXPORTS = {
  production: () => ["production", csvRow("Date", "Batch", "Machine", "Floor", "Shift", "Output (kg)", "Target (kg)", "Worker", "Remarks") + S.prod.map((p) => csvRow(p.date, p.batchNumber, p.machine, p.floor, p.shift, p.productionQuantity, p.target, p.worker, p.remarks)).join("")],
  totals: () => ["daily_shift_totals", csvRow("Date", "Shift", "Output (kg)", "Target (kg)", "Logs") + uniq(S.prod.map((p) => p.date)).sort().reverse().map((d) => { const s = shiftTotals(d); return s.map((x) => csvRow(d, x.l, x.out, x.target, x.n)).join("") + csvRow(d, "DAY TOTAL", s.reduce((a, x) => a + x.out, 0), s.reduce((a, x) => a + x.target, 0), s.reduce((a, x) => a + x.n, 0)); }).join("")],
  rolls: () => ["shade_rolls", csvRow("Roll", "Batch", "Shade", "Colour", "Weight (kg)", "Length (m)", "Verdict", "Remarks") + S.rolls.map((r) => csvRow(r.rollNumber, r.batchNumber, r.shadeNumber, r.colour, r.weight, r.length, r.quality, r.remarks)).join("")],
  floor: () => { const bm = batchOfFloor(); return ["floor_list", csvRow("Planned date", "Batch", "Floor", "Machine", "Type", "Buyer", "Order", "Colour", "Fabric", "Dia (in)", "Dia (cm)", "GSM", "Qty (kg)", "Status", "Remarks") + S.floor.map((f) => csvRow(f.plannedDate, bm[f.id], f.floor, f.machineName, f.machineType, f.buyerName, f.orderNumber, f.colour, f.fabricType, f.diaInch, f.diaCm, f.gsm, f.quantity, f.status, f.remarks)).join("")]; },
  batches: () => ["batch_cards", csvRow("Batch", "Floor", "Machine", "Type", "Buyer", "Order", "Colour", "Fabric", "Dia (cm)", "GSM", "Qty (kg)", "Status") + S.batches.map((b) => csvRow(b.batchNumber, b.floor, b.machineId, b.machineType, b.buyer, b.orderNumber, b.colour, b.fabricType, b.dia, b.gsm, b.quantity, b.status)).join("")],
  overtime: () => ["overtime", csvRow("Date", "Worker", "Worker ID", "Shift", "Hours", "Reason", "Approved by") + S.ot.map((o) => csvRow(o.date, o.workerName, o.workerId, o.shift, o.hours, o.reason, o.approvedBy)).join("") + csvRow("", "TOTAL", "", "", S.ot.reduce((a, o) => a + o.hours, 0), "", "")],
  activity: () => ["activity_log", csvRow("Action", "Type", "Details", "User") + S.logs.map((l) => csvRow(l.action, l.entityType, l.details, l.userEmail)).join("")]
};

const touch = (col, id, data, msg, log) => save(updateDoc(doc(db, col, id), { ...data, updatedAt: serverTimestamp() }).then(() => log && logActivity(...log)), msg);
const actions = {
  nav: (d) => go(d.v),
  setUi: (d) => { S.ui[d.k] = d.v; renderView(false); },
  floorStatus: (d) => touch("floorList", d.id, { status: d.v }, "Status updated", ["UPDATE_STATUS", "FLOOR_LIST", d.id, "Status updated to " + d.v]),
  batchStatus: (d) => touch("batchCards", d.id, { status: d.v }, "Status updated", ["UPDATE_STATUS", "BATCH_CARD", d.id, "Batch status updated to " + d.v]),
  openParams: (d) => { S.ui.paramBatch = d.id; go("params"); },
  newFloor: formDlg.floor, newParams: formDlg.params, newProd: formDlg.prod, newRoll: formDlg.roll, newOt: formDlg.ot,
  export: (d) => { const [n, t] = EXPORTS[d.k](); downloadCsv(n, t); },
  saveUser: (d) => {
    const newRole = $("#r_" + d.id).value, active = $("#a_" + d.id).checked;
    if (newRole === "MANAGER" && active && S.users.filter((u) => u.role === "MANAGER" && u.isActive && u.id !== d.id).length >= 4) return toast("Maximum of 4 active Managers reached.");
    touch("users", d.id, { role: newRole, isActive: active }, "User updated", ["UPDATE_ROLE", "USER", d.id, `Updated role to ${newRole}, active: ${active}`]);
  },
  signOut: () => signOut(auth)
};
document.addEventListener("click", (e) => { const el = e.target.closest("[data-act]"); if (el) actions[el.dataset.act]?.(el.dataset, el); });
document.addEventListener("input", (e) => {
  const k = e.target.dataset && e.target.dataset.ui; if (!k) return;
  S.ui[k] = e.target.value;
  if (k === "paramBatch" || k === "repMachine") views[S.view].refresh(); else views[S.view].refresh();
});

/* ======================= LAYOUT / ROUTING ======================= */
const allowedNav = () => NAV.filter((n) => n[0] !== "users" || isAdmin());
function go(v) { S.view = v; if (location.hash !== "#" + v) history.replaceState(null, "", "#" + v); renderNav(); renderView(true); }
function renderNav() {
  $("#tabs").innerHTML = allowedNav().map(([k, l]) => `<button class="tab ${S.view === k ? "active" : ""}" data-act="nav" data-v="${k}">${l}</button>`).join("");
  const on = $("#tabs .active"); if (on && on.scrollIntoView) on.scrollIntoView({ inline: "center", block: "nearest" });
}
function renderView(scroll = true) {
  if (!$("#view")) return;
  if (!views[S.view] || !allowedNav().some((n) => n[0] === S.view)) S.view = "dashboard";
  $("#view").innerHTML = (role() === "VIEWER" ? `<div class="banner">You are signed in as a <b>Viewer</b> (read-only). Ask the Main Admin to give you a role.</div>` : "") + views[S.view].shell();
  views[S.view].refresh();
  if (scroll) window.scrollTo(0, 0);
}
function refreshView() {
  if (!$("#view") || !views[S.view]) return;
  if (S.view === "params" || S.view === "reports") renderView(false); else views[S.view].refresh();
}
const initials = (n) => String(n || "?").trim().split(/\s+/).slice(0, 2).map((w) => w[0]).join("").toUpperCase() || "?";
function renderApp() {
  $("#root").innerHTML = `<div class="offline" id="off">You are offline — changes will sync automatically</div>
    <header id="head"><div id="top"><div class="brand"><div class="logo">L</div><div><b>LINKON Factory</b><small>Management System</small></div></div>
    <div class="who"><div class="nm"><b>${esc(S.profile?.displayName || "")}</b>${esc(ROLE_NAMES[role()] || "")}</div><div class="avatar">${esc(initials(S.profile?.displayName))}</div><button class="btn ghost sm" data-act="signOut">Sign out</button></div></div>
    <nav id="tabs"></nav></header><main id="view"></main>`;
  const hv = location.hash.slice(1); if (views[hv]) S.view = hv;
  renderNav(); renderView(false); syncOffline();
}
function renderLogin(msg = "") {
  $("#root").innerHTML = `<div id="login"><img src="icons/icon-192.png" alt=""><h1>LINKON Factory<br>Management System</h1><div class="sub">Sign in with your Google account to continue</div><button class="btn" id="gbtn">Sign in with Google</button><div class="sub" style="color:#ffb4ab">${esc(msg)}</div></div>`;
  $("#gbtn").onclick = async () => {
    const p = new GoogleAuthProvider(); p.setCustomParameters({ prompt: "select_account" });
    try { await signInWithPopup(auth, p); }
    catch (e) {
      if (["auth/popup-blocked", "auth/operation-not-supported-in-this-environment"].includes(e.code)) return signInWithRedirect(auth, p);
      if (e.code !== "auth/popup-closed-by-user" && e.code !== "auth/cancelled-popup-request") renderLogin(e.message);
    }
  };
}
function renderMessage(title, text, withSignOut = true) {
  $("#root").innerHTML = `<div id="login"><img src="icons/icon-192.png" alt=""><h2>${esc(title)}</h2><div class="sub">${esc(text)}</div>${withSignOut ? `<button class="btn ghost" data-act="signOut">Sign out</button>` : ""}</div>`;
}
function syncOffline() { const o = $("#off"); if (o) o.style.display = navigator.onLine ? "none" : "block"; }
window.addEventListener("online", syncOffline); window.addEventListener("offline", syncOffline);
window.addEventListener("hashchange", () => { const v = location.hash.slice(1); if (views[v] && v !== S.view && $("#view")) go(v); });

/* ======================= DATA / AUTH ======================= */
function stopAll() { unsubs.forEach((u) => u()); unsubs = []; if (unsubParams) { unsubParams(); unsubParams = null; } }
function subscribeAll() {
  unsubs.forEach((u) => u()); unsubs = [];
  const sub = (name, q, key) => unsubs.push(onSnapshot(q, (s) => { S[key] = snapList(s); refreshView(); }, (e) => toast(`${name}: ${friendly(e)}`)));
  const byNew = (c, n) => query(collection(db, c), orderBy("createdAt", "desc"), ...(n ? [limit(n)] : []));
  sub("Floor list", byNew("floorList"), "floor"); sub("Batch cards", byNew("batchCards"), "batches"); sub("Production", byNew("production"), "prod");
  sub("Quality", byNew("shadeRolls"), "rolls"); sub("Overtime", byNew("overtime"), "ot");
  if (isManager()) { sub("Users", query(collection(db, "users"), orderBy("displayName")), "users"); sub("Activity", byNew("activityLogs", 50), "logs"); }
}
async function ensureProfile(u) {
  try {
    const ref = doc(db, "users", u.uid);
    if ((await getDoc(ref)).exists()) return;
    const boot = (u.email || "").toLowerCase() === BOOTSTRAP_ADMIN_EMAIL.toLowerCase(), r = boot ? "MAIN_ADMIN" : "VIEWER";
    await setDoc(ref, { userId: u.uid, email: u.email || "", displayName: (u.displayName || (u.email || "").split("@")[0] || "User " + u.uid.slice(0, 4)).slice(0, 100), role: r, isActive: true, createdAt: serverTimestamp(), updatedAt: serverTimestamp() });
    logActivity("REGISTER", "USER", u.uid, "User profile initialized with role " + r);
  } catch (e) { toast(friendly(e)); }
}

let profileUnsub = null, lastKey = "";
onAuthStateChanged(auth, async (user) => {
  if (profileUnsub) { profileUnsub(); profileUnsub = null; }
  stopAll(); S.user = user; S.profile = null; lastKey = "";
  if (!user) { renderLogin(); return; }
  renderMessage("Setting up your account…", "One moment.", false);
  await ensureProfile(user);
  profileUnsub = onSnapshot(doc(db, "users", user.uid), (s) => {
    if (!s.exists()) return;
    S.profile = { id: s.id, ...s.data({ serverTimestamps: "estimate" }) };
    if (S.profile.isActive === false) { stopAll(); lastKey = ""; renderMessage("Account deactivated", "Your account is not active. Please contact the Main Admin."); return; }
    const key = S.profile.role + "|" + S.profile.isActive;
    if (key !== lastKey) { lastKey = key; subscribeAll(); renderApp(); }
  }, (e) => renderMessage("Could not load your profile", friendly(e)));
});

if ("serviceWorker" in navigator) window.addEventListener("load", () => navigator.serviceWorker.register("sw.js").catch(() => {}));
