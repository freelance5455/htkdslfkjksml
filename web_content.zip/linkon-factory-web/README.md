# LINKON Factory — Website (PWA)

Same Firebase project, same login, same data and same security rules as the Android app.
Nothing in your Firebase settings or rules is changed by this site.

## Publish (one time, about 5 minutes)
1. Firebase console → Build → **Hosting** → Get started (free plan is fine).
2. Install Node.js, then in a terminal:
   npm install -g firebase-tools
   firebase login
3. Open this folder in the terminal and run:
   firebase deploy --only hosting
4. Your site: https://linkon-factory-2026.web.app

`--only hosting` is important: it publishes the website and does not touch your database rules.

## Install on a phone
Open the link in Chrome → menu (⋮) → **Add to Home screen** / **Install app**. Workers get an app icon; updates arrive automatically.

## If Google sign-in shows "unauthorized domain"
Firebase console → Authentication → Settings → Authorized domains → add the site domain.
(The *.web.app and *.firebaseapp.com domains are normally added automatically.)

## Optional
- Register a Web App in Project settings and paste its appId into firebase-config.js. Not required for login or data.

## Notes
- Works offline: entries are saved on the phone and sync when the internet returns.
- Roles follow your rules: Main Admin and Manager create Floor List entries; Worker and Helper log production, quality, parameters and overtime; Viewer is read-only.
- Menu: all screens are in the top tab bar (swipe sideways on a phone).
- The first sign-in of linkonbhai000@gmail.com becomes Main Admin; everyone else starts as Viewer until the Main Admin assigns a role (Users tab).
