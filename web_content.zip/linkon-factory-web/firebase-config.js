// Same Firebase project and Firestore database as the Android app.
// Nothing here changes any Firebase setting; it only tells the website where to connect.
export const firebaseConfig = {
  apiKey: "AIzaSyCEAzI_ksFvIC7mK5iSyobFjIbPTvwlh7o",
  authDomain: "linkon-factory-2026.firebaseapp.com",
  projectId: "linkon-factory-2026",
  storageBucket: "linkon-factory-2026.firebasestorage.app",
  messagingSenderId: "547093288352",
  // Optional: replace with your Web App ID after you register a web app in the Firebase console.
  appId: "1:547093288352:android:911bcc11dfb4ddd56000c5"
};
export const FIRESTORE_DATABASE_ID = "ai-studio-android-linkonfa-0d69a760-70cb-4528-9580-cac160bac92a";
export const BOOTSTRAP_ADMIN_EMAIL = "linkonbhai000@gmail.com";
