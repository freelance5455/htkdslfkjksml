HUNTER SYSTEM - UPDATED PROJECT

This ZIP contains the updated web app and Android Studio project.

FEATURES
- Existing login/profile retained.
- XP, level and persistent progress saving.
- Rank progression: E, D, C, B, A, S, SS, SSS, EX, MONARCH, MONARCH INFINITY.
- Deep, low-pitch rank-up announcement using device/browser text-to-speech. Actual voice quality depends on installed device voices.
- Camera pose tracking for push-ups, squats and abs/crunches using MediaPipe Pose Landmarker.
- Automatic body-not-visible pause and resume when the body is detected again.
- Manual camera pause, resume and stop controls.
- 50-100 XP per newly submitted rep-count combination; duplicate submissions of the same counts are blocked.
- Data is stored locally on the device/browser.

CAMERA / AI NOTES
- Camera use requires user permission and a secure browser context. The Android app serves the page from the Android WebView asset loader.
- MediaPipe's JavaScript runtime and pose model are downloaded from their public CDNs on first camera use, so an internet connection is required for AI camera training.
- Pose-based repetition estimation is approximate and depends on camera angle, lighting, clothing, framing and exercise form. Verify reps and exercise safety yourself.
- The camera tracker supports one person at a time. Select the correct exercise before starting. Keep relevant joints visible in frame.
- The web version should be hosted on HTTPS for camera access. Opening index.html directly from a local file manager may not allow camera access.

ANDROID BUILD
- Open SoloSystemAndroid in Android Studio.
- Allow Gradle sync and install/run the app on an Android device.
- Camera permission is requested by Android when the app starts; the app asks for web camera access when START CAMERA is tapped.

SAFETY
This app is a personal workout tracker, not a medical device or a substitute for qualified coaching. Stop if you feel pain, dizziness or unwell.
