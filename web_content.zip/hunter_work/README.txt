HUNTER SYSTEM — CAMERA + PHONE SENSOR FIX (SOURCE PROJECT)

WHAT CHANGED
- Replaced the hard-coded MediaPipe Lite model URL ending in /float16/1/ with Google's documented /float16/latest/ model URL.
- Added Lite-to-Full model fallback and jsDelivr-to-unpkg fallback for the MediaPipe JS/WASM runtime.
- Uses CPU delegate first for better compatibility with Android WebView devices.
- Requests camera permission and starts the camera preview before loading the AI model. If model loading fails, camera preview remains available and the button becomes RETRY AI DETECTION.
- Android WebView camera permission is limited to the appassets.androidplatform.net origin.
- Phone motion sensor bridge is rate-limited to about 30 updates/second and the UI checks whether a motion sensor exists.
- Sensor recalibrates when the exercise selection changes.

CAMERA REQUIREMENTS
- First AI model load requires an internet connection because MediaPipe JS/WASM and the pose model are fetched from official CDNs/Google model storage.
- Android app must be installed from a build that includes the updated source, and camera permission must be granted.
- Keep the whole body visible. Side-on camera placement is best for push-ups and squats.
- This ZIP contains source code; it is not a compiled APK.

PHONE SENSOR USE
- Uses Android TYPE_LINEAR_ACCELERATION where available; otherwise it removes estimated gravity from accelerometer readings.
- Squats: secure phone in a tight front pocket or waist belt.
- Abs/crunches: secure phone at the waist.
- Push-ups: only use a firmly secured sports armband/pouch on the upper torso/back if it is safe and cannot fall; never hold a phone in the hand while exercising.
- Hold still for 1–2 seconds after selecting an exercise so the baseline can calibrate.
- Sensor reps are motion estimates, not camera-verified form checks; they are stored separately and award less XP.

BUILD
Open SoloSystemAndroid in Android Studio and build the app. Gradle wrapper is not included in this project archive.

TEST STATUS
- JavaScript syntax check: passed.
- AndroidManifest.xml parse: passed.
- ZIP integrity: checked after packaging.
- Android compilation and physical-device camera/sensor testing: not performed in this environment.
