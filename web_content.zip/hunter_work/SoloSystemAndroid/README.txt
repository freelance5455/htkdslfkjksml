HUNTER SYSTEM Android Studio project

Open this folder in Android Studio and allow Gradle sync. Install on an Android device. The app is a WebView wrapper around the included site assets. It requests camera permission and loads the MediaPipe pose runtime/model from the internet when camera training starts.

Requirements: Android Studio with Android Gradle Plugin 8.6.1 support; internet connection for Gradle dependencies and first-time AI model download; camera permission.

Note: Pose-based rep counting is approximate. Test camera placement and exercise selection before relying on the counter. Stop if you feel pain or unwell.
