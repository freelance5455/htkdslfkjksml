HUNTER SYSTEM — FINAL UPDATE PACKAGE
====================================

This archive preserves the supplied Android project and web app structure.

Included updates
----------------
- Eight supplied MP3 rank voice packs installed under:
  app/src/main/assets/site/assets/voices/
- Rank-specific audio playback for D, C, A, S, SS, SSS, EX and MONARCH INFINITY.
- Device text-to-speech fallback for ranks without a supplied MP3 (E, B and MONARCH).
- Animated cinematic rank-up overlay.
- Custom profile-picture upload (stored locally on the device).
- AI pose-landmark tracking for push-ups, squats and abs/crunches.
- Automatic +75 XP reward after 5 camera-verified reps in EACH of the three exercise categories.
- Automatic local progress saving and daily reset.
- WhatsApp customer support feedback form for +91 9609374862.
- Android bridge to open WhatsApp directly when installed.
- Existing project icon, Android wrapper, Gradle files and overall visual design retained.

Important limitations
---------------------
- Camera-based pose estimation is required for verified reps and XP. If the camera is off,
  the app cannot reliably confirm exercise type, range of motion or form. It intentionally
  does not award camera-verified XP from unverified/manual claims.
- Place the phone securely where the full body and movement can be seen. A phone placed
  somewhere without camera view cannot verify push-ups, squats or abs.
- Pose estimation uses joint-angle and visibility checks and is not a medical-grade form
  assessment. Test camera angles and thresholds on the target phone before relying on it.
- The first AI model load requires an internet connection (MediaPipe CDN/model hosting).
- E, B and MONARCH do not have separate uploaded audio files, so they use device TTS.
- Camera pose detection is approximate; always use safe exercise technique and stop if
  uncomfortable.

Build
-----
Open SoloSystemAndroid in Android Studio and build the app using its Gradle project.
The project requires Android SDK 35 and internet access for initial pose-model loading.
For browser preview, serve hunter_work/ over HTTPS or localhost (camera permissions
usually do not work from an ordinary file:// URL).

Data
----
Profile picture, profile details, XP and workout progress are stored locally in browser
storage on the device. They are not synced to a server.
