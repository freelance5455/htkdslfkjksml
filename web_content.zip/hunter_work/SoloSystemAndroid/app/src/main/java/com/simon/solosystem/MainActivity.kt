package com.simon.solosystem

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.webkit.WebViewAssetLoader
import java.util.Locale
import java.net.URLEncoder

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var webView: WebView
    private lateinit var assetLoader: WebViewAssetLoader
    private var pageLoaded = false
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var queuedSpeech: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), 410)
        }
        createWebView()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            ttsReady = true
            tts?.language = Locale.US
            queuedSpeech?.let { speakRankAnnouncement(it, queuedPitch, queuedRate) }
            queuedSpeech = null
        }
    }

    private var queuedPitch = 1.0f
    private var queuedRate = 0.98f

    private fun speakRankAnnouncement(message: String, pitch: Float, rate: Float) {
        if (!ttsReady) {
            queuedSpeech = message
            queuedPitch = pitch.coerceIn(0.20f, 1.0f)
            queuedRate = rate.coerceIn(0.50f, 1.0f)
            return
        }
        runOnUiThread {
            tts?.setSpeechRate(rate.coerceIn(0.50f, 1.0f))
            tts?.setPitch(pitch.coerceIn(0.20f, 1.0f))
            tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "hunter-rank-up")
        }
    }

    inner class HunterVoiceBridge {
        @JavascriptInterface
        fun speak(message: String, pitch: Float, rate: Float) {
            val safeMessage = message.take(240)
            speakRankAnnouncement(safeMessage, pitch, rate)
        }

        @JavascriptInterface
        fun openWhatsApp(message: String) {
            val safeMessage = message.take(1000)
            val encoded = URLEncoder.encode(safeMessage, "UTF-8")
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/919609374862?text=$encoded"))
            runOnUiThread {
                try {
                    startActivity(intent)
                } catch (_: Exception) {
                    // The user can still copy the support number from the app.
                }
            }
        }
    }

    private fun createWebView() {
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.mediaPlaybackRequiresUserGesture = false
        webView.settings.allowFileAccess = false
        webView.settings.allowContentAccess = true
        webView.addJavascriptInterface(HunterVoiceBridge(), "HunterVoice")
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest) =
                assetLoader.shouldInterceptRequest(request.url)
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED &&
                        request.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)) {
                        request.grant(arrayOf(PermissionRequest.RESOURCE_VIDEO_CAPTURE))
                    } else {
                        request.deny()
                    }
                }
            }
        }
        setContentView(FrameLayout(this).apply { addView(webView, FrameLayout.LayoutParams(-1, -1)) })
        webView.loadUrl("https://appassets.androidplatform.net/assets/site/index.html")
        pageLoaded = true
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 410 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED && pageLoaded) {
            // The page requests camera access when the hunter taps START CAMERA.
        }
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::webView.isInitialized) webView.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
