package com.simon.solosystem

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.ValueCallback
import android.widget.FrameLayout
import androidx.webkit.WebViewAssetLoader
import java.net.URLEncoder
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener, SensorEventListener {
    private lateinit var webView: WebView
    private lateinit var assetLoader: WebViewAssetLoader
    private var pageLoaded = false
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var queuedSpeech: String? = null
    private var queuedPitch = 1.0f
    private var queuedRate = 0.98f
    private lateinit var sensorManager: SensorManager
    private var motionSensor: Sensor? = null
    private var motionEnabled = false
    private var sensorRequested = false
    private val gravityEstimate = FloatArray(3)
    private var linearAccelerationSensor = false
    private var lastSensorDispatchNs = 0L
    private var pendingWebPermission: PermissionRequest? = null
    private var filePathCallback: ValueCallback<Array<Uri>>? = null

    companion object {
        private const val CAMERA_PERMISSION_REQUEST = 410
        private const val FILE_CHOOSER_REQUEST = 411
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        motionSensor = sensorManager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION)
        linearAccelerationSensor = motionSensor?.type == Sensor.TYPE_LINEAR_ACCELERATION
        if (motionSensor == null) motionSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

        assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        createWebView()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            ttsReady = true
            tts?.language = Locale.US
            queuedSpeech?.let { speakRankAnnouncement(it, queuedPitch, queuedRate) }
            queuedSpeech = null
        }
    }

    private fun speakRankAnnouncement(message: String, pitch: Float, rate: Float) {
        if (!ttsReady) {
            queuedSpeech = message
            queuedPitch = pitch.coerceIn(0.20f, 1.0f)
            queuedRate = rate.coerceIn(0.50f, 1.0f)
            return
        }
        runOnUiThread {
            tts?.setSpeechRate(rate.coerceIn(0.50f, 1.0f))
            tts?.setPitch(pitch.coerceIn(0.20f, 1.0f))
            tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "hunter-rank-up")
        }
    }

    inner class HunterVoiceBridge {
        @JavascriptInterface
        fun speak(message: String, pitch: Float, rate: Float) {
            speakRankAnnouncement(message.take(240), pitch, rate)
        }

        @JavascriptInterface
        fun hasMotionSensor(): Boolean = motionSensor != null

        @JavascriptInterface
        fun startMotionSensors() {
            runOnUiThread {
                motionSensor?.let {
                    sensorRequested = true
                    sensorManager.registerListener(this@MainActivity, it, SensorManager.SENSOR_DELAY_GAME)
                    motionEnabled = true
                }
            }
        }

        @JavascriptInterface
        fun stopMotionSensors() {
            runOnUiThread {
                sensorManager.unregisterListener(this@MainActivity)
                motionEnabled = false
                sensorRequested = false
            }
        }

        @JavascriptInterface
        fun openWhatsApp(message: String) {
            val encoded = URLEncoder.encode(message.take(1000), "UTF-8")
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/919609374862?text=$encoded"))
            runOnUiThread {
                try { startActivity(intent) } catch (_: Exception) { }
            }
        }
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (!motionEnabled || !::webView.isInitialized) return
        // Limit bridge traffic to roughly 30 updates/second; sensor hardware can emit much faster.
        if (event.timestamp - lastSensorDispatchNs < 33_000_000L) return
        lastSensorDispatchNs = event.timestamp
        var x = event.values.getOrElse(0) { 0f }
        var y = event.values.getOrElse(1) { 0f }
        var z = event.values.getOrElse(2) { 0f }
        if (!linearAccelerationSensor) {
            val alpha = 0.82f
            for (i in 0..2) gravityEstimate[i] = alpha * gravityEstimate[i] + (1 - alpha) * event.values[i]
            x -= gravityEstimate[0]
            y -= gravityEstimate[1]
            z -= gravityEstimate[2]
        }
        val js = "window.onPhoneMotion && window.onPhoneMotion($x,$y,$z);"
        runOnUiThread { if (::webView.isInitialized) webView.evaluateJavascript(js, null) }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onPause() {
        if (::sensorManager.isInitialized) {
            sensorManager.unregisterListener(this)
            motionEnabled = false
        }
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (sensorRequested && ::sensorManager.isInitialized) {
            motionSensor?.let {
                sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
                motionEnabled = true
            }
        }
    }

    private fun createWebView() {
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.mediaPlaybackRequiresUserGesture = false
        webView.settings.allowFileAccess = false
        webView.settings.allowContentAccess = true
        webView.addJavascriptInterface(HunterVoiceBridge(), "HunterVoice")
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest) =
                assetLoader.shouldInterceptRequest(request.url)
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    if (request.origin.host != "appassets.androidplatform.net" ||
                        !request.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)) {
                        request.deny()
                    } else if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        request.grant(arrayOf(PermissionRequest.RESOURCE_VIDEO_CAPTURE))
                    } else {
                        pendingWebPermission?.deny()
                        pendingWebPermission = request
                        requestPermissions(arrayOf(Manifest.permission.CAMERA), CAMERA_PERMISSION_REQUEST)
                    }
                }
            }

            override fun onShowFileChooser(
                view: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "image/*"
                }
                return try {
                    startActivityForResult(Intent.createChooser(intent, "Choose profile picture"), FILE_CHOOSER_REQUEST)
                    true
                } catch (_: Exception) {
                    filePathCallback = null
                    callback.onReceiveValue(null)
                    false
                }
            }
        }
        setContentView(FrameLayout(this).apply {
            addView(webView, FrameLayout.LayoutParams(-1, -1))
        })
        webView.loadUrl("https://appassets.androidplatform.net/assets/site/index.html")
        pageLoaded = true
    }

    @Deprecated("Deprecated in Android API; retained for WebView file chooser compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == FILE_CHOOSER_REQUEST) {
            val result = if (resultCode == RESULT_OK) {
                data?.data?.let { arrayOf(it) }
            } else null
            filePathCallback?.onReceiveValue(result)
            filePathCallback = null
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == CAMERA_PERMISSION_REQUEST) {
            val request = pendingWebPermission
            pendingWebPermission = null
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED &&
                request != null && request.origin.host == "appassets.androidplatform.net" &&
                request.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)) {
                request.grant(arrayOf(PermissionRequest.RESOURCE_VIDEO_CAPTURE))
            } else {
                request?.deny()
            }
        }
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::sensorManager.isInitialized) sensorManager.unregisterListener(this)
        pendingWebPermission?.deny()
        filePathCallback?.onReceiveValue(null)
        if (::webView.isInitialized) webView.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
