(() => {
 const $=id=>document.getElementById(id), today=()=>new Date().toLocaleDateString('en-CA');
 const read=(key,fallback)=>{try{return JSON.parse(localStorage.getItem(key))??fallback}catch{return fallback}};
 let profile=read('levelUpProfile',null);
 let state=read('levelUpSave',{day:today(),push:0,squat:0,abs:0,verified:{push:0,squat:0,abs:0},sessionVerified:{push:0,squat:0,abs:0},xp:0,completed:{}});
 if(state.day!==today()) state={...state,day:today(),push:0,squat:0,abs:0,verified:{push:0,squat:0,abs:0},sessionVerified:{push:0,squat:0,abs:0},sensor:{push:0,squat:0,abs:0},completed:{}};
 state.verified ||= {push:0,squat:0,abs:0}; state.sessionVerified ||= {push:0,squat:0,abs:0};
 state.sensor ||= {push:0,squat:0,abs:0}; state.completed ||= {};
 // One-time migration: start the updated Hunter System at Level 0 with zero XP.
 // Keep the hunter profile (name, age and avatar), but clear old progression data.
 const levelZeroMigration='hunterLevelZeroMigrationV1';
 if(localStorage.getItem(levelZeroMigration)!=='done'){
   state={...state,day:today(),push:0,squat:0,abs:0,
     verified:{push:0,squat:0,abs:0},sessionVerified:{push:0,squat:0,abs:0},
     xp:0,completed:{}};
   localStorage.setItem(levelZeroMigration,'done');
 }
 state.sensor ||= {push:0,squat:0,abs:0};
 const save=()=>localStorage.setItem('levelUpSave',JSON.stringify(state));
 const exerciseTargets={push:10,squat:20,abs:15};
 const rankList=[['E',0],['D',3],['C',5],['B',8],['A',12],['S',16],['SS',20],['SSS',25],['EX',30],['MONARCH',40],['MONARCH INFINITY',50]];
 const getRank=level=>[...rankList].reverse().find(r=>level>=r[1])||rankList[0];
 let poseLandmarker=null,stream=null,raf=0,paused=false,bodyLost=false,lastVideoTime=-1,modelLoading=false,stage='up',lastRepAt=0,verifiedThisSession=0;
 function showLogin(){ $('login').hidden=false;$('dashboard').hidden=true;if(profile){$('nameInput').value=profile.name;$('ageInput').value=profile.age;} }
 function showDashboard(){ $('login').hidden=true;$('dashboard').hidden=false;startPhoneSensors();$('welcome').textContent=`WELCOME, ${profile.name} · AGE ${profile.age}`;if(profile.avatar)$('profileAvatar').src=profile.avatar;render(); }
 $('start').addEventListener('click',()=>{const name=$('nameInput').value.trim(),age=Number($('ageInput').value);if(!name){$('loginStatus').textContent='Please enter your name.';return;}if(!Number.isInteger(age)||age<5||age>120){$('loginStatus').textContent='Please enter a valid age.';return;}const p={...(profile||{}),name,age};localStorage.setItem('levelUpProfile',JSON.stringify(p));profile=p;showDashboard();});
 // User-supplied rank audio files are played locally. Missing ranks use device TTS.
 const rankAudioFiles = {
   'D':'assets/voices/D%20rank.mp3',
   'C':'assets/voices/C%20rank.mp3',
   'A':'assets/voices/A%20rank.mp3',
   'S':'assets/voices/S%20rank.mp3',
   'SS':'assets/voices/SS%20rank.mp3',
   'SSS':'assets/voices/SSS%20RANK.mp3',
   'EX':'assets/voices/EX%20RANK.mp3',
   'MONARCH INFINITY':'assets/voices/MONARCH%20INFINITY.mp3'
 };
 const voiceLines = {
   'E':'Rank E. Your journey begins, Hunter.','D':'Rank D. Your strength is rising.',
   'C':'Rank C. Your power is awakening.','B':'Rank B. You are becoming stronger.',
   'A':'Rank A. Your presence grows.','S':'Rank S. The battlefield knows your name.',
   'SS':'Rank double S. Your power overwhelms.','SSS':'Rank triple S. You have surpassed the elite.',
   'EX':'Rank EX. An extraordinary force has awakened.',
   'MONARCH':'Monarch. Your power commands the battlefield.',
   'MONARCH INFINITY':'Monarch Infinity. Your power has no limit.'
 };
 function speakRank(rank){
   const file=rankAudioFiles[rank];
   if(file){
     const audio=$('rankAudio');
     audio.pause();audio.currentTime=0;audio.src=file;
     audio.play().then(()=>{$('voiceStatus').textContent=`Playing your original ${rank} voice pack.`;})
       .catch(()=>fallbackRankVoice(rank));
   } else fallbackRankVoice(rank);
 }
 function fallbackRankVoice(rank){
   const line=`RANK UP. ${voiceLines[rank]||voiceLines['MONARCH INFINITY']}`;
   try{
     if(window.HunterVoice&&typeof window.HunterVoice.speak==='function'){
       window.HunterVoice.speak(line,0.72,0.78);return;
     }
   }catch(e){console.warn('Native voice unavailable',e);}
   if('speechSynthesis' in window){
     window.speechSynthesis.cancel();const msg=new SpeechSynthesisUtterance(line);
     msg.rate=.78;msg.pitch=.72;msg.volume=1;window.speechSynthesis.speak(msg);
   }else $('voiceStatus').textContent='Voice engine is unavailable on this device.';
 }
 function showRankUp(rank,gained){
   $('rankOverlayName').textContent=`${rank} RANK`;
   $('rankOverlayMessage').textContent=`You earned +${gained} XP. A new rank has been unlocked.`;
   $('rankOverlay').hidden=false;
   $('rankOverlay').classList.remove('rank-pop');void $('rankOverlay').offsetWidth;$('rankOverlay').classList.add('rank-pop');
   speakRank(rank);
 }
 function render(){const level=Math.floor(state.xp/250),inLevel=state.xp%250,rank=getRank(level);$('level').textContent=`LEVEL ${level}`;$('rank').textContent=`RANK ${rank[0]}`;$('xp').textContent=`${inLevel} / 250 XP · TOTAL ${state.xp} XP`;$('progress').style.width=`${inLevel/250*100}%`;$('rankHint').textContent=`Next rank: ${rankList.find(r=>r[1]>level)?.[0]||'MAX RANK'} · ${rankList.find(r=>r[1]>level)?.[1]*250-state.xp||0} XP to next rank`;
  ['push','squat','abs'].forEach(k=>$(`${k}Value`).textContent=`${state.verified[k]} camera · ${state.sensor[k]||0} sensor`);
  const dailyItems=[['push','dailyPush','dailyPushCount','PUSH-UPS'],['squat','dailySquat','dailySquatCount','SQUATS'],['abs','dailyAbs','dailyAbsCount','ABS / CORE']];
  let anyDailyRep=false;
  dailyItems.forEach(([key,row,count])=>{const n=Number(state.verified[key]||0);$(row).hidden=n<=0;if(n>0){anyDailyRep=true;$(count).textContent=`${n} reps`;}});
  $('dailyIntro').textContent=anyDailyRep?'Your camera-verified workout progress for today:':'Complete a camera-verified exercise to reveal camera-verified daily progress.';
  $('verifiedCount').textContent=verifiedThisSession;
  $('sessionPush').textContent=`${Math.min(exerciseTargets.push,state.sessionVerified.push||0)} / 10–15`;
  $('sessionSquat').textContent=`${Math.min(exerciseTargets.squat,state.sessionVerified.squat||0)} / 20–30`;
  $('sessionAbs').textContent=`${Math.min(exerciseTargets.abs,state.sessionVerified.abs||0)} / 15–20`;
  $('rankRoadmap').innerHTML=rankList.map(([name,l])=>`<div class="rank-item ${level>=l?'':'locked'} ${rank[0]===name?'current':''}"><strong>${name}</strong>Level ${l}${level>=l?' · UNLOCKED':' · LOCKED'}</div>`).join('');save();}
 function maybeAutoReward(){
   const sv=state.sessionVerified;
   if(sv.push<exerciseTargets.push||sv.squat<exerciseTargets.squat||sv.abs<exerciseTargets.abs)return;
   const oldRank=getRank(Math.floor(state.xp/250))[0];
   const gained=75;state.xp+=gained;
   state.sessionVerified={push:0,squat:0,abs:0};
   render();
   const newRank=getRank(Math.floor(state.xp/250))[0];
   $('status').textContent=`All three exercise targets verified. Automatic reward: +${gained} XP!`;
   if(oldRank!==newRank)showRankUp(newRank,gained);
 }
 $('rankOverlayClose').addEventListener('click',()=>$('rankOverlay').hidden=true);
 $('changePicture').addEventListener('click',()=>$('profilePictureInput').click());
 $('profilePictureInput').addEventListener('change',async e=>{
   const file=e.target.files?.[0];if(!file)return;
   if(!file.type.startsWith('image/')){$('status').textContent='Please choose an image file.';return;}
   try{
     const data=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=reject;reader.readAsDataURL(file);});
     const img=await new Promise((resolve,reject)=>{const image=new Image();image.onload=()=>resolve(image);image.onerror=reject;image.src=data;});
     const canvas=document.createElement('canvas'),max=512,scale=Math.min(1,max/Math.max(img.width,img.height));
     canvas.width=Math.round(img.width*scale);canvas.height=Math.round(img.height*scale);
     canvas.getContext('2d').drawImage(img,0,0,canvas.width,canvas.height);
     profile={...profile,avatar:canvas.toDataURL('image/jpeg',.82)};
     localStorage.setItem('levelUpProfile',JSON.stringify(profile));$('profileAvatar').src=profile.avatar;
     $('status').textContent='Profile picture updated and saved on this device.';
   }catch(err){$('status').textContent='Could not load that picture. Please try another image.';}
   e.target.value='';
 });
 $('sendSupport').addEventListener('click',()=>{
   const message=$('supportFeedback').value.trim();
   if(!message){$('supportFeedback').focus();$('status').textContent='Please write your suggestion or issue first.';return;}
   const full=`Hello Hunter System Support,\n\n${message}\n\nSent from Hunter System.`;
   const url=`https://wa.me/919609374862?text=${encodeURIComponent(full)}`;
   if(window.HunterVoice&&typeof window.HunterVoice.openWhatsApp==='function')window.HunterVoice.openWhatsApp(full);
   else window.open(url,'_blank','noopener');
 });
 $('reset').addEventListener('click',()=>{if(stream){$('status').textContent='Stop the camera before resetting reps.';return;}state.push=state.squat=state.abs=0;state.verified={push:0,squat:0,abs:0};state.sessionVerified={push:0,squat:0,abs:0};state.sensor={push:0,squat:0,abs:0};sensorReps=0;$('sensorCount').textContent='0';verifiedThisSession=0;render();$('status').textContent="Today's reps reset.";});
 $('changeProfile').addEventListener('click',()=>{stopCamera();if(window.HunterVoice?.stopMotionSensors)window.HunterVoice.stopMotionSensors();$('login').hidden=false;$('dashboard').hidden=true;$('loginStatus').textContent='Update your name and age, then start your journey again.';});
 // Phone motion sensor rep counter (Android accelerometer bridge).
 let sensorReps=0,sensorStage='up',sensorLastRep=0,sensorMagnitude=0,sensorSamples=0;
 let sensorPeak=0,sensorValley=0,sensorCalibration=[];
 function startPhoneSensors(){
   if(window.HunterVoice&&typeof window.HunterVoice.startMotionSensors==='function'&&window.HunterVoice.hasMotionSensor?.()){
     window.HunterVoice.startMotionSensors();
     $('sensorStatus').textContent='PHONE SENSOR ACTIVE · Camera not required';
     $('sensorMessage').textContent='Hold the phone still for 1–2 seconds to calibrate, then perform slow, controlled reps.';
   }else {
     $('sensorStatus').textContent=window.HunterVoice?'NO MOTION SENSOR FOUND':'ANDROID APP REQUIRED';
     $('sensorMessage').textContent='Phone sensor counting is available in the installed Android app, not a regular browser tab.';
   }
 }
 window.onPhoneMotion=function(x,y,z){
   const vals=[x,y,z].map(v=>Number(v)||0);
   const mag=Math.hypot(...vals);
   sensorMagnitude=sensorMagnitude*.78+mag*.22;
   sensorSamples++;
   // Calibrate a short quiet baseline; use movement amplitude relative to it.
   if(sensorSamples<45){sensorCalibration.push(sensorMagnitude);return;}
   if(sensorSamples===45){
     sensorCalibration.sort((a,b)=>a-b);
     sensorValley=sensorCalibration[Math.floor(sensorCalibration.length*.5)]||0;
     sensorPeak=sensorValley;
     $('sensorMessage').textContent='Sensor calibrated. Start controlled repetitions now.';
   }
   const kind=$('sensorExercise').value;
   const now=Date.now();
   const amplitude=sensorMagnitude-sensorValley;
   // Two-phase movement with hysteresis and a cooldown reduces noise-triggered reps.
   const baseThreshold=kind==='push'?1.05:kind==='squat'?0.85:0.75;
   const downThreshold=Math.max(baseThreshold, sensorValley*.85+0.55);
   const upThreshold=Math.max(.30, downThreshold*.42);
   if(amplitude>downThreshold){sensorStage='down';}
   if(amplitude<upThreshold&&sensorStage==='down'&&now-sensorLastRep>1100){
     sensorLastRep=now;sensorStage='up';sensorReps++;
     $('sensorCount').textContent=String(sensorReps);
     countRep(kind,'sensor');
     if(navigator.vibrate)navigator.vibrate(30);
   }
 };
 $('sensorExercise').addEventListener('change',()=>{
   sensorStage='up';sensorLastRep=Date.now();
   sensorSamples=0;sensorCalibration=[];sensorMagnitude=0;sensorValley=0;sensorPeak=0;sensorStage='up';$('sensorMessage').textContent='Exercise changed. Hold the phone still for 1–2 seconds to recalibrate, then move slowly.';
 });
 $('sensorReset').addEventListener('click',()=>{
   sensorReps=0;sensorStage='up';sensorSamples=0;sensorCalibration=[];
   $('sensorCount').textContent='0';
   $('sensorMessage').textContent='Session display reset. Previously earned XP and saved totals remain.';
 });
 function angle(a,b,c){const ab=[a.x-b.x,a.y-b.y],cb=[c.x-b.x,c.y-b.y];const dot=ab[0]*cb[0]+ab[1]*cb[1],mag=Math.hypot(...ab)*Math.hypot(...cb);return Math.acos(Math.max(-1,Math.min(1,dot/(mag||1))))*180/Math.PI;}
 function lmVisible(p,ids){return ids.every(i=>p[i]&&p[i].visibility>.55);}
 function countRep(kindOverride,source='camera'){
   const kind=kindOverride||$('exerciseSelect').value;
   if(source==='sensor'){
     state.sensor ||= {push:0,squat:0,abs:0};
     state.sensor[kind]=(state.sensor[kind]||0)+1;
     // Sensor reps award a smaller amount than camera-verified reps and do
     // not unlock camera-only daily completion rewards.
     const gained=2,oldRank=getRank(Math.floor(state.xp/250))[0];
     state.xp+=gained;render();
     const newRank=getRank(Math.floor(state.xp/250))[0];
     $('sensorMessage').textContent=`${kind.toUpperCase()} sensor rep +1 · +${gained} XP. Sensor estimates can be imperfect; keep the phone secure.`;
     if(oldRank!==newRank)showRankUp(newRank,gained);
   } else {
     if(kind==='push')state.push++;else if(kind==='squat')state.squat++;else state.abs++;
     state.verified[kind]++;state.sessionVerified[kind]=(state.sessionVerified[kind]||0)+1;
     verifiedThisSession++;render();maybeAutoReward();
     $('cameraMessage').textContent=`Good camera-verified rep detected! ${kind.toUpperCase()} +1. Keep your movement controlled.`;
   }
   if('vibrate'in navigator)navigator.vibrate?.(35);
 }
 function analyze(landmarks){const p=landmarks;if(!p||p.length<33){lostBody();return;}if(bodyLost){bodyLost=false;$('cameraStatus').textContent='TRACKING';$('cameraMessage').textContent='Body detected again. Counting resumed automatically.';}const kind=$('exerciseSelect').value;let value=0,ids=[];
  if(kind==='push'){ids=[11,13,15,12,14,16,23,24,27,28];if(!lmVisible(p,ids)){lostBody();return;}const left=angle(p[11],p[13],p[15]),right=angle(p[12],p[14],p[16]);const plank=(angle(p[11],p[23],p[27])+angle(p[12],p[24],p[28]))/2;if(plank<145){stage='up';$('cameraMessage').textContent='Keep your shoulders, hips and ankles aligned. Rep not counted.';return;}value=(left+right)/2;}
  else if(kind==='squat'){ids=[23,25,27,24,26,28];if(!lmVisible(p,ids)){lostBody();return;}const left=angle(p[23],p[25],p[27]),right=angle(p[24],p[26],p[28]);value=(left+right)/2;}
  else{ids=[11,23,25,12,24,26];if(!lmVisible(p,ids)){lostBody();return;}const left=angle(p[11],p[23],p[25]),right=angle(p[12],p[24],p[26]);value=(left+right)/2;}
  $('cameraStatus').textContent=`TRACKING · ${Math.round(value)}°`;
  const down=kind==='push'?value<95:kind==='squat'?value<105:value<105;
  const up=kind==='push'?value>155:kind==='squat'?value>155:value>145;
  const now=performance.now();if(down)stage='down';if(up&&stage==='down'&&now-lastRepAt>650){countRep();stage='up';lastRepAt=now;}
 }
 function lostBody(){if(!bodyLost){bodyLost=true;$('cameraStatus').textContent='PAUSED · BODY NOT VISIBLE';$('cameraMessage').textContent='Body not fully detected. Counting paused automatically. Move into view to resume.';}}
 async function loadPose(){
   if(poseLandmarker)return poseLandmarker;
   if(modelLoading)throw new Error('AI model is already loading. Please wait.');
   modelLoading=true;
   try{
     let visionApi;
     try{visionApi=await import('https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14');}
     catch(firstImportError){visionApi=await import('https://unpkg.com/@mediapipe/tasks-vision@0.10.14/vision_bundle.mjs');}
     const {FilesetResolver,PoseLandmarker}=visionApi;
     let vision;
     try{vision=await FilesetResolver.forVisionTasks('https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm');}
     catch(wasmError){vision=await FilesetResolver.forVisionTasks('https://unpkg.com/@mediapipe/tasks-vision@0.10.14/wasm');}
     const common={runningMode:'VIDEO',numPoses:1,minPoseDetectionConfidence:.55,minPosePresenceConfidence:.55,minTrackingConfidence:.55};
     const models=[
       'https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/latest/pose_landmarker_lite.task',
       'https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_full/float16/latest/pose_landmarker_full.task'
     ];
     let lastError;
     for(const modelAssetPath of models){
       try{poseLandmarker=await PoseLandmarker.createFromOptions(vision,{...common,baseOptions:{modelAssetPath,delegate:'CPU'}});break;}
       catch(modelError){lastError=modelError;}
     }
     if(!poseLandmarker)throw new Error(`Pose model could not load. Check internet and retry. ${lastError?.message||lastError||''}`);
     return poseLandmarker;
   }finally{modelLoading=false;}
 }
 async function startCamera(){
   try{
     if(!stream){
       if(!navigator.mediaDevices?.getUserMedia)throw new Error('Camera API unavailable. Install/open the Android app or use a secure HTTPS page.');
       $('cameraMessage').textContent='Requesting camera permission…';
       stream=await navigator.mediaDevices.getUserMedia({audio:false,video:{facingMode:'user',width:{ideal:640},height:{ideal:480}}});
       const video=$('camera');video.srcObject=stream;await video.play();video.dataset.live='true';
       $('cameraPlaceholder').hidden=true;$('cameraPause').disabled=false;$('cameraStop').disabled=false;
       paused=false;bodyLost=false;stage='up';lastVideoTime=-1;
     }
     $('cameraStart').disabled=true;$('cameraStatus').textContent='CAMERA LIVE · LOADING AI';
     $('cameraMessage').textContent='Camera is working. Loading the pose model (internet required for first load)…';
     await loadPose();
     $('cameraMessage').textContent='AI tracking active. Keep your full body visible and complete a controlled down-and-up movement.';
     $('cameraStatus').textContent='TRACKING';$('cameraStart').textContent='AI READY';loop();
   }catch(e){
     if(stream){$('cameraStart').disabled=false;$('cameraStart').textContent='RETRY AI DETECTION';$('cameraStop').disabled=false;$('cameraStatus').textContent='CAMERA ON · AI NOT READY';}
     else{stopCamera();$('cameraStatus').textContent='CAMERA OFF';}
     $('cameraMessage').textContent=`${e.message||e}. Allow camera permission. If the camera preview works but AI does not, check internet and tap RETRY AI DETECTION.`;
   }
 }
 function loop(){if(!stream||paused)return;const video=$('camera');if(video.readyState>=2&&video.currentTime!==lastVideoTime){lastVideoTime=video.currentTime;try{const result=poseLandmarker.detectForVideo(video,performance.now());if(result.landmarks?.length)analyze(result.landmarks[0]);else lostBody();}catch(e){$('cameraMessage').textContent='Pose tracking paused. Please restart the camera.';}}
  if(stream&&!paused)raf=requestAnimationFrame(loop);}
 function pauseCamera(){if(!stream)return;paused=true;cancelAnimationFrame(raf);$('cameraPause').textContent='RESUME';$('cameraStatus').textContent='PAUSED';$('cameraMessage').textContent='Counting paused. Resume when you are ready.';}
 function resumeCamera(){if(!stream)return;paused=false;$('cameraPause').textContent='PAUSE';$('cameraStatus').textContent='TRACKING';$('cameraMessage').textContent='Tracking resumed.';loop();}
 function stopCamera(){cancelAnimationFrame(raf);if(stream){stream.getTracks().forEach(t=>t.stop());stream=null;}const video=$('camera');video.pause();video.srcObject=null;video.dataset.live='false';$('cameraPlaceholder').hidden=false;$('cameraStart').disabled=false;$('cameraPause').disabled=true;$('cameraPause').textContent='PAUSE';$('cameraStop').disabled=true;$('cameraStatus').textContent='CAMERA OFF';paused=false;bodyLost=false;}
 $('cameraStart').addEventListener('click',startCamera);$('cameraPause').addEventListener('click',()=>paused?resumeCamera():pauseCamera());$('cameraStop').addEventListener('click',stopCamera);
 document.addEventListener('visibilitychange',()=>{if(document.hidden&&stream)pauseCamera();});window.addEventListener('pagehide',stopCamera);
 if(profile&&profile.name&&Number.isInteger(Number(profile.age))){showDashboard();}else{showLogin();}
})();
