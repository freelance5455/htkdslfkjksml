# Building an Android APK from Dingo Ledger

This project is a 100% client-side Vite + React app. After unzipping the project, build the static `dist/` folder before wrapping it into an APK.

## Option 1: HTML-to-APK / Cordova / Android WebView (`file://`)
If your APK builder loads `index.html` directly from local files (`file:///android_asset/...`), standard `<script type="module">` tags are blocked by WebView CORS. Use the APK build script instead:

```bash
npm install
npm run build:apk
```

Then point your APK builder or Cordova `www/` folder to the generated `dist/` directory.

## Option 2: Capacitor + Android Studio
`capacitor.config.json` is already configured with `webDir: "dist"`:

```bash
npm install
npm run build
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap add android
npx cap sync android
npx cap open android
```

From Android Studio, choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
