# Ridge Runner Adventure - modular source

The modular Ridge Runner project, with its JavaScript split into ES modules. The existing modular architecture
and non-Temple game systems are preserved. The Jungle Temple modules have been updated from the separately
supplied, tested `Ridge Runner Mangrove Temple Lift Latest.html`; this Temple is intentionally newer than the
older single-file comparison reference kept under `tools/equivalence/serve/orig/`.

## Run it

ES modules do not load from `file://`, so serve the folder over HTTP:

```
cd Ridge-Runner
python3 -m http.server 8000      # then open http://localhost:8000
```

(Any static server works: `npx serve`, VS Code Live Server, ...)

## Layout

```
Ridge-Runner/
  index.html          markup only; loads css/style.css and js/main.js (type="module")
  css/style.css       the original <style> block plus the hand-drawn menu styling
  js/                 45 modules (below)
  tools/equivalence/  optional: frame-by-frame comparison against the original single-file game (see its README)
```

## Modules

"Layer" is the longest import chain below the module: a module only imports from lower layers, so there are **no circular imports**.
`main.js` is the entry point.

| Module | Layer | Responsibility | Imports |
|---|---|---|---|
| `clock.js` | 0 | Animation clock: `t` (seconds of animation time, drives every wobble) and the per-frame delta. | - |
| `config.js` | 0 | Static tunables and lookup tables: Adventure tunables, booster table, difficulty modes, speed curves, on-screen hint. | - |
| `dom.js` | 0 | DOM handles shared across modules: the canvas and the HUD / card elements. | - |
| `state.js` | 0 | The shared mutable game state. Every value that more than one module reads or writes lives on the single `state` object. (Values only one module touches stay private to it; canvas metrics live in view.js, the animation clock in clock.js.) | - |
| `audio.js` | 1 | Sound effects (tiny WebAudio synth), Temple rope / pulley / creak / settle sounds, and the mute button. | `dom` |
| `menu-art.js` | 1 | Hand-drawn main-menu art: animated title scene, painted plank buttons, mode badges, best-score ribbon and the wooden panel frame. Drawn once on off-screen canvases and passed to the stylesheet as `--*` CSS image variables; `menuArtFrame()` animates the title while the menu shows. | `clock`, `dom` |
| `view.js` | 1 | Canvas, 2D context and viewport metrics (W, H, dpr, ground line G, unit scale u, runner x px, parallax layers). These are live ES-module bindings: other modules read them directly, only this module assigns them (resize() for the real screen; setContext/setMetrics for temporary off-screen drawing such as sprites and wardrobe previews). | `dom` |
| `draw-utils.js` | 2 | Small canvas drawing primitives shared by every scene: rounded rects, colour blending, parallax iteration, outlined polygons / ovals / curves, sparkles and crystals. | `clock`, `state`, `view` |
| `jungle-temple.js` | 2 | Updated Jungle Temple terrain profile (80-step descent, deep hall, shaft), trigger (`tpDue`; `tpStep` waits until the jetpack is spent and no Fly pickup is ahead), spawn blocking, camera-depth helpers, and eight-phase lift state machine. | `audio`, `config`, `state`, `view` |
| `biomes.js` | 3 | Biome palettes (Mountain / Snow / Mangrove) and the colour / ground blending between them. | `draw-utils`, `state`, `view` |
| `booster-zones.js` | 3 | Where the Normal Fly pickup may not be placed: the approach to a cave or the Temple (`FLY_REACH`) and everything underground (`flyInZone`, `flyBanned`), plus `caveStartAfterFlight` which keeps a newly scheduled cave out of reach of a running jetpack. Used by the spawn step, so the rule lives in placement, not drawing. | `jungle-temple`, `state`, `view` |
| `hand-drawn.js` | 3 | Shared hand-drawn finishing touches: sketchy double body outline with highlight, soft shading and pencil hatching, fur flicks and tufts, stitches, wood grain, quilting, veined fairy wings. Used by the outfit layers and the rides; translucent colours only, never `globalAlpha`. | `clock`, `draw-utils`, `view` |
| `obstacles.js` | 3 | Hand-drawn obstacles: snow, ice cave, meadow, cave, flyers and ponds. | `clock`, `draw-utils`, `view` |
| `outfit-parts.js` | 3 | Shared outfit drawing parts (tails, fur, bands, ribbons, gradients) and the outfit-kind registries WK / BK / MO. | `clock`, `draw-utils`, `state`, `view` |
| `backgrounds.js` | 4 | Sky and parallax scenery: sun, clouds, mountains, hills, pines, mist, snowfall, vignette. | `biomes`, `clock`, `draw-utils`, `state`, `view` |
| `outfits-base.js` | 4 | Base outfits: Classic, Astronaut, Dragon, Ninja, Robot, Knight, Wizard, Cat, Fire Spirit, Ice Spirit, Fairy, Tribal, Rock Golem, Forest Spirit, Bear. | `clock`, `draw-utils`, `hand-drawn`, `outfit-parts`, `state`, `view` |
| `outfits-winter.js` | 4 | Winter outfits: Santa, Snowman, Reindeer, Penguin, Polar Bear, Elf, Gingerbread, Yeti, Arctic Fox. | `clock`, `draw-utils`, `hand-drawn`, `outfit-parts`, `state`, `view` |
| `physics.js` | 4 | Terrain height under the runner, ride height, jump physics, world scroll, speed ramp, and Temple lift-state updates / hold. | `audio`, `biomes`, `clock`, `config`, `dom`, `jungle-temple`, `state`, `view` |
| `caves.js` | 5 | Caves: the normal cave, the ice cave and the cave mouths. | `clock`, `draw-utils`, `physics`, `state`, `view` |
| `flight.js` | 5 | Flight booster: the jetpack (Fly) - per-frame flight control, particles, flames and the jetpack. | `clock`, `draw-utils`, `physics`, `state`, `view` |
| `mangrove.js` | 5 | Mangrove biome: background, mud ground, sea, spawn table, props and every mangrove obstacle. | `biomes`, `clock`, `draw-utils`, `physics`, `state`, `view` |
| `rides.js` | 5 | Rides: horse, sleigh, the river boat and the sea boat, plus losing a ride. | `audio`, `clock`, `draw-utils`, `hand-drawn`, `physics`, `state`, `view` |
| `water-fx.js` | 5 | Splashes, ripples and the drowning overlay used by the river / sea / bog hazards. | `audio`, `clock`, `physics`, `state`, `view` |
| `temple-geo.js` | 5 | Floor and ceiling lines of the Mangrove Temple corridor (`hallFy`, `hallCy`), shared by the chase simulation and its drawing. | `jungle-temple`, `physics`, `state`, `view` |
| `adventure-mode.js` | 6 | Adventure mode logic: save/load, play clock, checkpoints and the finale. | `audio`, `clock`, `config`, `dom`, `flight`, `physics`, `state`, `view` |
| `boosters.js` | 6 | Pickups and booster visuals: charm sprites, pickup effects, coin effects, auras, the booster HUD. | `audio`, `clock`, `config`, `flight`, `physics`, `state`, `view` |
| `ground.js` | 6 | Ground surfaces (grass / snow / mangrove mud) and the river crossing. | `biomes`, `clock`, `draw-utils`, `mangrove`, `physics`, `state`, `view` |
| `jungle-temple-scene.js` | 6 | Updated Temple drawing: stone gate, naga staircase, deep underground hall, earth cross-section, vertical bamboo / rope shaft, winch and moving lift platform. | `biomes`, `caves`, `clock`, `draw-utils`, `jungle-temple`, `mangrove`, `physics`, `state`, `view` |
| `outfits-mangrove.js` | 6 | Mangrove outfits: Sundari Sprout, Bengal Tiger, Spotted Deer, Mud Crab, Mudskipper, Kingfisher, Saltwater Croc, Golpata Boatman. | `clock`, `draw-utils`, `mangrove`, `outfit-parts`, `state`, `view` |
| `spawn.js` | 6 | Spawning and scrolling of obstacles, coins and pickups. The Fly pickup is only placed outside the booster-free zones; pickups that end up inside one are dropped. | `booster-zones`, `config`, `jungle-temple`, `mangrove`, `state`, `view` |
| `temple-boulder-art.js` | 6 | Hand-drawn Temple chase art: the rolling boulder (carved coil, moss, cracks, vines), its dust, pebbles and roof flecks, the crash debris, and the stone gate that drops at the lift. Also exports `puff` and `rockChunk`. | `clock`, `draw-utils`, `state`, `temple-geo`, `view` |
| `adventure-draw.js` | 7 | Adventure mode drawing: checkpoint flags, finish gate and the biome base colours. | `boosters`, `clock`, `draw-utils`, `physics`, `state`, `view` |
| `game.js` | 7 | Game flow: reset, begin, die and the score update. | `adventure-mode`, `audio`, `dom`, `state`, `view` |
| `outfits.js` | 7 | Outfit catalogue and layer dispatch (behind / on / in front of the body) plus the always-on accessory layer; the body layer is wrapped by the shared hand-drawn shade and ink pass. | `clock`, `draw-utils`, `hand-drawn`, `outfit-parts`, `outfits-base`, `outfits-mangrove`, `outfits-winter`, `state`, `view` |
| `transitions.js` | 7 | River / sea crossings between biomes: scheduling, progress, blending and the biome switch. | `adventure-mode`, `booster-zones`, `audio`, `config`, `state`, `view` |
| `temple-trap-art.js` | 7 | Hand-drawn Temple hall traps: trapdoor, bamboo spike plate, naga fire-pot and falling roof slab (`drawTraps`), plus the trap size constants `SPK_H` / `SLAB_H`. | `clock`, `draw-utils`, `state`, `temple-boulder-art`, `temple-geo`, `view` |
| `collision.js` | 8 | Collisions: coin and pickup collection and obstacle hits (ride loss, shield break, splash, drowning, death). | `audio`, `boosters`, `clock`, `game`, `physics`, `rides`, `state`, `view`, `water-fx` |
| `input.js` | 8 | Pointer / keyboard / window input and the tap-to-jump `press` handler. | `audio`, `dom`, `game`, `physics`, `state`, `view` |
| `player.js` | 8 | Draws the runner: shadow, tail, legs, body, face, outfit layers and the ride / flight layers around them. | `boosters`, `clock`, `draw-utils`, `flight`, `outfit-parts`, `outfits`, `physics`, `rides`, `state`, `view` |
| `ui.js` | 8 | Menus and overlays: mode chips, play / customize / adventure buttons, admin panel and home button. | `adventure-mode`, `audio`, `config`, `dom`, `game`, `state` |
| `wardrobe.js` | 8 | Wardrobe grid and its live preview canvases. | `clock`, `dom`, `draw-utils`, `outfit-parts`, `outfits`, `state`, `view` |
| `temple-chase.js` | 8 | Mangrove Temple chase simulation: the boulder that rolls after the runner (staircase and deep hall), the stone gate that stops it at the lift, trap spawning / wake-up / hits (`stepTemple`, `hitTemple`) and the camera rumble (`tcShake`). | `audio`, `boosters`, `clock`, `game`, `jungle-temple`, `physics`, `rides`, `state`, `temple-geo`, `temple-trap-art`, `view` |
| `rendering.js` | 9 | The per-frame draw step, including the Temple's vertical camera-follow offset and underground scene. | `adventure-draw`, `backgrounds`, `biomes`, `boosters`, `caves`, `clock`, `draw-utils`, `ground`, `jungle-temple`, `jungle-temple-scene`, `mangrove`, `obstacles`, `physics`, `player`, `state`, `temple-boulder-art`, `temple-chase`, `temple-trap-art`, `view`, `water-fx` |
| `update.js` | 9 | The per-frame simulation step: update(dt) runs the steps of every system in a fixed order. | `adventure-mode`, `boosters`, `collision`, `flight`, `game`, `physics`, `spawn`, `state`, `temple-chase`, `transitions`, `view`, `water-fx` |
| `main.js` | 10 | Entry point: boot sequence and the animation frame loop. | `audio`, `clock`, `dom`, `input`, `menu-art`, `outfits`, `rendering`, `ui`, `update`, `view`, `wardrobe` |

## Shared state - how modules communicate

There are no globals. Three mechanisms, in order of preference:

1. **`state` (state.js)** - one object holding every gameplay value that more than one module reads or writes
   (`state.st`, `state.y`, `state.dist`, `state.fx`, `state.tr`, `state.adv`, ...). Each field is documented there.
   The field names are the original variable names, so the old code can be found with a search.
2. **Live bindings (view.js, clock.js)** - the canvas context and viewport metrics (`ctx`, `W`, `H`, `dpr`, `G`, `u`, `px`,
   `layers`, `stars`) and the animation time `t` are `export let` values. Everyone reads them directly (draw code stays short);
   only the owner module assigns them. Temporary off-screen drawing (booster sprites, wardrobe previews) goes through
   `setContext()` / `setMetrics()`.
3. **Module-private** - values only one module touches stay local: `ac` and `mute` (audio.js), `sm` (ui.js), `pvN` (wardrobe.js), `last` (clock.js).

## Frame flow

`main.js` `frame(n)`: `tick(n)` -> `update(dt)` -> `draw()` -> `menuArtFrame()` (title scene, menu only) -> wardrobe previews (when open, every other frame) -> next frame.

`update(dt)` (update.js) runs these steps in a fixed order (the order of the original function body):

1. particles (`partStep`, `fpStep`, `bfStep`), then the menu / ready / drowning early exits
2. `stepJumpBuffer` -> `stepFlight` -> `stepGravity` -> `stepScroll` (also schedules caves and the temple via `tpStep`)
3. `updateScore` -> `stepCrossing` (river / sea) -> `stepSpeed`
4. `spawnObjects` -> `scrollObjects` -> `stepTemple` (Temple boulder + traps) -> `collectPickups` -> `stepPops` -> `hitObstacles` -> `hitTemple`
5. `advStep` (Adventure mode only)

`draw()` (rendering.js) paints back to front: backdrop (sky, parallax, ground) -> cave -> temple scene -> river / sea ->
obstacles -> Temple traps and chasing boulder (`drawTraps`, `drawBoulder`) -> Adventure flags -> coins -> pickups -> pop-ups -> booster sparks -> runner (`drawRunner`, player.js) ->
water / temple front layers -> booster front + HUD -> snowfall, slow-mo tint, vignette.

## Where the named original functions went

| Original | Now |
|---|---|
| `update(dt)` | `update.js` (steps in physics / flight / game / transitions / spawn / collision) |
| `draw()` | `rendering.js` (+ `drawRunner` in player.js) |
| `frame(n)` | `main.js` |
| `reset()`, `begin()`, `die()` | `game.js` |
| `tpStep()` | `jungle-temple.js` |
| `tpScene()` | `jungle-temple-scene.js` |
| `advStep()` | `adventure-mode.js` |
| `advDraw()` | `adventure-draw.js` |

## Start-up order

The original script ran DOM / storage wiring as top-level statements. Those became `initUI`, `initAudio`, `initOutfits`,
`initWardrobe` and `initInput` (plus `initMenuArt`, right after `initUI`), called from `boot()` in `main.js`, followed by `resize()` and the first frame.

## Notes

- Outfit drawing is split into `outfits-base`, `outfits-winter` and `outfits-mangrove`; `outfits.js` dispatches to them
  (the original `wk` / `wb` / `wa` already dispatched the same way, the winter bodies are now `winterBack` / `winterBody` / `winterFront`).
- `hills()` (backgrounds.js) and `mouth()` (caves.js) are never called in the original; they are kept as they were.
- `state.tq` is written but never read in the original; kept.
- Outfit and ride art (2026-11-21): every outfit gets the shared `bodyShade` / `bodyInk` pass from `hand-drawn.js` (in `wb`), ribbons gained sheen and optional fringe, and the Fairy, Bear, Polar Bear and Arctic Fox plus the horse, sleigh and river boat were redrawn with it. Outfit indexes and `dd-out` are unchanged.
- Menu art (merged 2026-11-21): the main menu and Adventure panel use the hand-drawn look from `menu-art.js` (logo canvas `#mlogo` with an `sr`-only `<h1>`, plank buttons, ribbon, mode badges, framed panel). Markup ids and behaviour are unchanged.
- This build combines the two parallel updates: the hand-drawn outfit / ride art and the redrawn menu. They touch different files, except `README.md`, which is merged here.
- River boat (Mountain to Snow crossing): the drifting lily pads and lotus in the foreground water were removed from `rideB` in `rides.js`; the rest of the boat is unchanged. The now-unused `lilyPad` / `lotus` helpers were deleted from `hand-drawn.js`. The Mangrove bog pit is separate and keeps its own lily pads.
- localStorage keys are unchanged: `dd-best`, `dd-best-<mode>`, `dd-mode`, `dd-out`, `dd-admin`, `dd-inv`, `dd-adv`.

## Booster redesign (2026-11-21)

- **Super Fly (UFO) is gone**: no `fly2` booster, pickup, charm, HUD ring, UFO drawing, orange burst / star trail or flight height. `fx.fly2` was removed from state, physics, wardrobe, temple and Adventure code.
- **Normal Fly** is the only flying booster: 5 s (`BT.fly.d` in `config.js`, the single source), same jetpack, same flight mechanics.
- **Booster-free zones** (`booster-zones.js`, applied in `spawnObjects`): no Fly pickup within `FLY_REACH` (4200 u - a 5 s flight at 700 u/s covers at most about 3650 u including the landing) before a cave, inside a cave (plus a 300 u exit margin), within `FLY_REACH` before the Temple, or anywhere inside it. While the Temple is due, no new Fly pickup is placed, and `tpStep` waits (a few seconds at most) until the jetpack is spent and no Fly pickup is left ahead. If a biome switch schedules a cave while the jetpack is running, the cave start moves out of its reach. Other boosters, rides, caves and Temple terrain are unchanged; the first Fly of a run now comes after the first cave.

## Verification

Checked by running the original single-file game and this modular version side by side in headless Chromium (same random
seed, fake clock, scripted inputs; canvas hash and page state compared every few frames; tools/equivalence has the scripts).
All of these matched with no JavaScript errors:

- menu, modes, mute, admin unlock, Home, Customize; a normal run through death and restart; pointer and keyboard input
- a 26,000-frame run through every biome (river and sea crossings, rock and ice caves, the Jungle Temple, horse, sleigh, boats,
  all boosters of that time including the jetpack and the since-removed UFO, every obstacle type)
- all 32 outfits, in the wardrobe previews and in-game
- Adventure: new game, Snow and Mangrove checkpoints, the finale
- collisions without invincibility (death, ride loss, shield break, splash, drowning) in the Mountain, Snow and Mangrove
  biomes, and at river / sea crossings and the temple; Hard and Impossible modes; a landscape resize

Not checked: how the sound actually sounds (only that audio calls do not error), real touch devices, and browsers other than Chromium.
The Google Fonts stylesheet is requested as in the original; when offline the game falls back to the system font.


## Temple merge handover (2026-11-20)

The modular project now uses the Temple implementation from the supplied, tested
`Ridge Runner Mangrove Temple Lift Latest.html`. The modular architecture remains
intact; the single-file game was used only as the Temple source of truth.

Updated modules:
- `js/jungle-temple.js` — terrain / trigger logic, camera-depth calculations, and the complete lift state machine.
- `js/jungle-temple-scene.js` — updated exterior, 80-step staircase, underground hall, earth layers, vertical shaft, winch, and moving platform.
- `js/state.js` and `js/game.js` — lift / camera state and run reset.
- `js/physics.js` — lift update and speed hold in the existing frame order.
- `js/player.js` — stationary runner animation during lift phases.
- `js/rendering.js` — camera-follow transform and full underground rendering.
- `js/audio.js` — Temple rope, pulley, creak, and settle sounds.

The old equivalence reference at `tools/equivalence/serve/orig/index.html` is an
older single-file build and therefore does not contain the newly supplied Temple.
Temple frame-by-frame differences against that old reference are expected. The
equivalence harness remains useful for checking unrelated systems, but it is not
a correctness oracle for the updated Temple.

Verification performed for this handover:
- JavaScript syntax check for all 38 modules.
- Static check that every relative module import resolves and every named import has a matching export.
- Targeted logic tests for Temple activation, terrain / depth profile, lift activation and all lift phases.

Not verified in this environment: live Chromium gameplay, the full exit sequence rendered on-screen,
real Android touch hardware, or the original 26,000-frame equivalence marathon.

## Mangrove Temple chase and traps

- **Boulder.** Once the runner is a few steps down the Temple staircase, a boulder is released behind them (`state.tc`, created in
  `stepTemple`). It rolls down the stairs and through the deep hall at the runner's heels, closing in, lunging now and then, kicking up
  dust and pebbles and shaking the camera (`tcShake`, applied in `draw()`). It is scenery with menace and never hurts the runner.
  Near the lift a stone gate drops from the roof behind the runner; the boulder hits it, shatters, and the rubble stays until the Temple ends.
- **Traps** (`state.tt`, positions in world px so they sit still as the world scrolls). They appear only in the deep hall, wake up a fixed
  reaction time before the runner arrives, and every one can be cleared with a normal jump:
  trapdoor (hidden under floor-coloured slabs until it opens; a pit with bamboo stakes), bamboo spike plate (stakes thrust up),
  naga fire-pot (pilot flame that roars up) and falling roof slab (cracks, drops, leaves a block to jump).
  Hits follow `hitObstacles`: ghost, flight and admin invincibility pass; a ride or shield takes the blow (a trapdoor bounces the runner out);
  otherwise the run ends. Coins arc over most traps outside Adventure mode.
- `state.tc` / `state.tt` are cleared in `reset()` and whenever the Temple is not active. No new localStorage keys.
