/*
 * input.js - Pointer / keyboard / window input and the tap-to-jump `press` handler.
 */
import { A } from './audio.js';
import { $ } from './dom.js';
import { begin } from './game.js';
import { jump } from './physics.js';
import { state } from './state.js';
import { resize } from './view.js';

function press(){
  if(state.st==='menu')return;state.hold=true;A();
  if(state.st==='ready')begin();
  else if(state.st==='play'){if(state.ob){}else if(state.y>0&&state.jumps<2)jump(true);else state.buf=.12}
  else if(state.st==='over'&&performance.now()-state.overAt>450)begin();
  else if(state.st==='won'&&performance.now()-state.overAt>450)$('home').click();
}
/** Wires this module up to the DOM / storage. Called once from main.js during boot, in the original statement order. */
export function initInput(){
  addEventListener('resize',resize);
  document.addEventListener('pointerdown',e=>{e.preventDefault();press()});
  addEventListener('pointerup',()=>{state.hold=false});
  addEventListener('pointercancel',()=>{state.hold=false});
  addEventListener('keydown',e=>{if(e.target&&e.target.tagName==='INPUT')return;if([' ','ArrowUp','w','W'].includes(e.key)){e.preventDefault();if(!e.repeat)press()}});
  addEventListener('keyup',e=>{if([' ','ArrowUp','w','W'].includes(e.key))state.hold=false});
}
