/*
 * water-fx.js - Splashes, ripples and the drowning overlay used by the river / sea / bog hazards.
 */
import { snd } from './audio.js';
import { t } from './clock.js';
import { ter } from './physics.js';
import { state } from './state.js';
import { ctx, G, px, u } from './view.js';

export function front(){const o=state.dw.o,gy=G+ter(o.x+o.w/2),x=o.x,w=o.w,k=1+Math.max(0,1-state.dw.t)*2;const wg=ctx.createLinearGradient(0,gy,0,gy+22*u);wg.addColorStop(0,o.m?'rgba(104,132,78,.88)':'rgba(105,192,224,.8)');wg.addColorStop(1,o.m?'rgba(30,48,32,.95)':'rgba(29,95,134,.92)');ctx.fillStyle=wg;ctx.beginPath();ctx.moveTo(x,gy+22*u);ctx.lineTo(x,gy+4*u);for(let q=0;q<=w;q+=6*u)ctx.lineTo(x+q,gy+4*u+Math.sin(t*6+q*.09)*2*u*k);ctx.lineTo(x+w,gy+22*u);ctx.closePath();ctx.fill()}
export function dparts(){for(const r of state.rips){ctx.strokeStyle='rgba(255,255,255,'+r.a.toFixed(2)+')';ctx.lineWidth=2*u;ctx.beginPath();ctx.ellipse(r.x,r.y,r.r,r.r*.22,0,0,7);ctx.stroke()}for(const p of state.parts){ctx.fillStyle=p.c||'rgba(190,235,255,.9)';ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,7);ctx.fill()}}
export function splash(x,o,n){const gy=G+ter(o.x+o.w/2)+4*u;for(let i=0;i<n;i++)state.parts.push({x:x+(Math.random()-.5)*30*u,y:gy,gy,vx:(Math.random()-.5)*340*u,vy:-(260+Math.random()*420)*u,r:(1.5+Math.random()*2.5)*u,c:o.m?'rgba(158,176,92,.92)':0});state.rips.push({x,y:gy,r:6*u,a:.8})}
export function plunge(o){if(state.inv)return;state.st='drown';state.hold=false;state.dw={t:0,o,sk:0,vs:170*u};splash(px+17*u,o,24);snd('sp')}
export function partStep(dt){for(const p of state.parts){p.vy+=1500*u*dt;p.x+=p.vx*dt;p.y+=p.vy*dt;if(p.y>p.gy&&p.vy>0){p.dead=1;if(Math.random()<.3)state.rips.push({x:p.x,y:p.gy,r:3*u,a:.6})}}state.parts=state.parts.filter(p=>!p.dead);for(const r of state.rips){r.r+=70*u*dt;r.a-=1.1*dt}state.rips=state.rips.filter(r=>r.a>0)}
