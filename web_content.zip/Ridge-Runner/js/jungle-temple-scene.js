/*
 * jungle-temple-scene.js - Updated Temple exterior, deep underground hall, earth cross-section,
 * vertical bamboo-and-rope lift shaft, and foreground details. Visuals ported from the tested HTML.
 */
import { MV } from './biomes.js';
import { cvTorch } from './caves.js';
import { t } from './clock.js';
import { bgH, BOV, BPG, BSP, BST, par, rr, wdot, wlg, wol } from './draw-utils.js';
import { TP, tpC, tpDs, tpS, tpSm } from './jungle-temple.js';
import { mgLf, mgRt, mgTree } from './mangrove.js';
import { ter } from './physics.js';
import { state } from './state.js';
import { ctx, G, H, u, W } from './view.js';

const tpRoot=(x0,y0,cx,cy,x1,y1,w)=>mgRt(w,x0,y0,cx,cy,x1,y1,'#6a4a2c','rgba(224,172,110,.55)');
function tpVine(x,y,l,n){const sw=Math.sin(t*1.3+n)*2.4*u;BST('rgba(10,30,14,.85)',1.8,x,y,x+sw*.4,y+l*.5,x+sw,y+l);BST('#3c7a3a',1,x,y,x+sw*.4,y+l*.5,x+sw,y+l);mgLf(x+sw*.4,y+l*.5,.5,7*u,2.4*u,'#4f9a46','rgba(220,250,170,.4)');wdot(x+sw,y+l,1.7*u,'#9ccb55')}
function tpPillar(x,fy,top,w){
  const g=ctx.createLinearGradient(x-w/2,0,x+w/2,0);g.addColorStop(0,'#26352e');g.addColorStop(.55,'#728578');g.addColorStop(1,'#2b3b33');
  ctx.fillStyle=g;rr(x-w/2,top,w,fy-top,3*u);ctx.fill();wol(1.8);
  for(const a of[.2,.5,.8]){const by=top+(fy-top)*a;ctx.fillStyle='rgba(10,24,18,.4)';ctx.fillRect(x-w/2,by,w,8*u);ctx.strokeStyle='rgba(190,225,190,.32)';ctx.lineWidth=1*u;ctx.beginPath();for(let q=0;q<4;q++){const dx=x-w/2+(q+.5)*w/4;ctx.moveTo(dx-3*u,by+4*u);ctx.lineTo(dx,by+.5*u);ctx.lineTo(dx+3*u,by+4*u);ctx.lineTo(dx,by+7.5*u);ctx.closePath()}ctx.stroke()}
  ctx.fillStyle='#55675a';rr(x-w*.75,top,w*1.5,13*u,3*u);ctx.fill();wol(1.6);rr(x-w*.7,fy-11*u,w*1.4,13*u,3*u);ctx.fill();wol(1.6);
  ctx.strokeStyle='rgba(255,255,255,.2)';ctx.lineWidth=1.2*u;ctx.beginPath();ctx.moveTo(x+w*.22,top+16*u);ctx.lineTo(x+w*.22,fy-14*u);ctx.stroke();
  ctx.fillStyle='rgba(95,150,70,.78)';ctx.beginPath();ctx.ellipse(x-w*.18,fy-14*u,w*.46,4.2*u,0,0,7);ctx.fill();ctx.strokeStyle='rgba(8,34,16,.45)';ctx.lineWidth=1.2*u;ctx.stroke();
  tpRoot(x+w*.5,top+14*u,x+w*1.05,(top+fy)*.5,x+w*.4,fy-3*u,5.5);tpRoot(x-w*.5,top+30*u,x-w*.95,(top+fy)*.55,x-w*.35,fy-3*u,4)}
function tpPlaza(){
  const a=tpS(TP.A),b=tpS(TP.E+44);if(b<0||a>W)return;const x0=Math.max(0,a),x1=Math.min(W,b);
  const pth=dy=>{ctx.beginPath();for(let x=x0;x<=x1+8;x+=8){const y=G+ter(x)+dy*u;x===x0?ctx.moveTo(x,y):ctx.lineTo(x,y)}};
  ctx.lineCap='butt';pth(4.4);ctx.strokeStyle='rgba(8,14,10,.5)';ctx.lineWidth=13*u;ctx.stroke();pth(4);ctx.strokeStyle='#7f8d7c';ctx.lineWidth=10.4*u;ctx.stroke();pth(1.4);ctx.strokeStyle='rgba(235,245,225,.5)';ctx.lineWidth=1.6*u;ctx.stroke();
  ctx.strokeStyle='rgba(20,32,24,.4)';ctx.lineWidth=1.2*u;ctx.beginPath();for(let x=tpS(TP.A)-0;x<x1+40*u;x+=38*u){if(x<x0)continue;const y=G+ter(x)+4*u;ctx.moveTo(x,y-5*u);ctx.lineTo(x,y+5*u)}ctx.stroke();ctx.lineCap='round'}
function tpLion(x,y,s){
  ctx.fillStyle='rgba(0,0,0,.25)';ctx.beginPath();ctx.ellipse(x,y+1*u,22*s*u,4*u,0,0,7);ctx.fill();
  BPG('#69786d',x-18*s*u,y,x-16*s*u,y-30*s*u,x+8*s*u,y-30*s*u,x+16*s*u,y);rr(x-22*s*u,y-6*u,44*s*u,7*u,2*u);ctx.fillStyle='#55665b';ctx.fill();wol(1.4);
  BOV(x+2*s*u,y-46*s*u,15*s*u,14*s*u,'#7a8b7e');for(let q=0;q<7;q++){const a=-1.2+q*.4;BPG('#5a6b5f',x+2*s*u+Math.cos(a)*13*s*u,y-46*s*u+Math.sin(a)*12*s*u,x+2*s*u+Math.cos(a)*21*s*u,y-46*s*u+Math.sin(a)*19*s*u,x+2*s*u+Math.cos(a+.3)*13*s*u,y-46*s*u+Math.sin(a+.3)*12*s*u)}
  BOV(x-3*s*u,y-44*s*u,8*s*u,7*s*u,'#8a9b8d');wdot(x-6*s*u,y-48*s*u,2*s*u,'#ffc04a');wdot(x+3*s*u,y-48*s*u,2*s*u,'#ffc04a');BPG('#2b3a33',x-9*s*u,y-40*s*u,x-3*s*u,y-36*s*u,x+3*s*u,y-40*s*u);
  ctx.fillStyle='rgba(95,150,70,.75)';ctx.beginPath();ctx.ellipse(x+8*s*u,y-30*s*u,8*s*u,3*u,0,0,7);ctx.fill()}
function tpKala(x,y,r){
  for(let q=0;q<9;q++){const a=Math.PI+q*Math.PI/8;BPG('#4f6a48',x+Math.cos(a)*r*.9,y+Math.sin(a)*r*.9,x+Math.cos(a-.12)*r*1.45,y+Math.sin(a-.12)*r*1.45,x+Math.cos(a+.12)*r*1.45,y+Math.sin(a+.12)*r*1.45)}
  BOV(x,y,r,r*.92,'#7d8e80');ctx.fillStyle='rgba(0,0,0,.14)';ctx.beginPath();ctx.ellipse(x+r*.3,y+r*.1,r*.7,r*.8,0,0,7);ctx.fill();
  BPG('#3e4f45',x-r*.78,y-r*.32,x-r*.12,y-r*.1,x-r*.1,y-r*.34);BPG('#3e4f45',x+r*.78,y-r*.32,x+r*.12,y-r*.1,x+r*.1,y-r*.34);
  const gl=.8+.2*Math.sin(t*3);wdot(x-r*.42,y-r*.14,r*.15,'rgba(255,190,70,'+gl.toFixed(2)+')');wdot(x+r*.42,y-r*.14,r*.15,'rgba(255,190,70,'+gl.toFixed(2)+')');
  BPG('#2b3a33',x-r*.2,y+r*.1,x,y+r*.02,x+r*.2,y+r*.1,x+r*.1,y+r*.28,x-r*.1,y+r*.28);BPG('#e6efe0',x-r*.35,y+r*.44,x-r*.26,y+r*.7,x-r*.17,y+r*.44);BPG('#e6efe0',x+r*.35,y+r*.44,x+r*.26,y+r*.7,x+r*.17,y+r*.44);
  ctx.strokeStyle='rgba(20,32,26,.5)';ctx.lineWidth=1.3*u;ctx.beginPath();ctx.moveTo(x-r*.45,y+r*.42);ctx.quadraticCurveTo(x,y+r*.62,x+r*.45,y+r*.42);ctx.stroke()}
function tpFacade(){
  const X=k=>tpS(k),a=X(-60),b=X(374);if(b<-20||a>W+20)return;
  const Y=x=>G+ter(x),tiers=[[-60,40,120],[40,130,205],[130,236,305],[236,374,2000]];
  for(const[k0,k1,h]of tiers){
    const x0=X(k0),x1=X(k1);if(x1<0||x0>W)continue;const yb=G+16*u,yt=Math.max(-30,G-h*u);
    ctx.fillStyle=wlg(yt,yb,'#919c8a','#46564b');ctx.fillRect(x0,yt,x1-x0+1,yb-yt);
    ctx.strokeStyle='rgba(20,32,26,.32)';ctx.lineWidth=1.1*u;ctx.beginPath();
    for(let y=yb-22*u,r=0;y>yt;y-=22*u,r++){ctx.moveTo(x0,y);ctx.lineTo(x1,y);for(let x=x0+((r&1)*19+9)*u;x<x1;x+=38*u){ctx.moveTo(x,y);ctx.lineTo(x,y-22*u)}}ctx.stroke();
    ctx.fillStyle='rgba(8,20,14,.18)';ctx.fillRect(x1-14*u,yt,14*u,yb-yt);
    ctx.strokeStyle='rgba(0,0,0,.4)';ctx.lineWidth=1.8*u;ctx.strokeRect(x0,yt,x1-x0,yb-yt);
    if(h<2000){ctx.fillStyle='#5f7064';rr(x0-5*u,yt-9*u,x1-x0+10*u,11*u,2*u);ctx.fill();wol(1.5);BPG('#c9b25a',x0-5*u,yt-8*u,x0-2*u,yt-20*u,x0+4*u,yt-8*u);BPG('#c9b25a',x1+5*u,yt-8*u,x1+2*u,yt-20*u,x1-4*u,yt-8*u);
      ctx.strokeStyle='rgba(235,245,215,.5)';ctx.lineWidth=1.2*u;ctx.beginPath();ctx.moveTo(x0,yt+3*u);ctx.lineTo(x1,yt+3*u);ctx.stroke();
      ctx.strokeStyle='rgba(190,225,190,.28)';ctx.lineWidth=1*u;ctx.beginPath();for(let x=x0+8*u;x<x1-5*u;x+=16*u){ctx.moveTo(x-4*u,yt+18*u);ctx.lineTo(x,yt+12*u);ctx.lineTo(x+4*u,yt+18*u);ctx.lineTo(x,yt+24*u);ctx.closePath()}ctx.stroke()}}
  for(const k of[150,206]){const nx=X(k),ny=G-205*u;if(nx<-30||nx>W+30)continue;ctx.fillStyle='#13201a';ctx.beginPath();ctx.moveTo(nx-13*u,ny+34*u);ctx.lineTo(nx-13*u,ny);ctx.arc(nx,ny,13*u,Math.PI,0);ctx.lineTo(nx+13*u,ny+34*u);ctx.closePath();ctx.fill();wol(1.5);
    BOV(nx,ny+8*u,5*u,5*u,'#7d8e80');BPG('#6a7b6e',nx-9*u,ny+34*u,nx-6*u,ny+14*u,nx+6*u,ny+14*u,nx+9*u,ny+34*u);ctx.fillStyle='rgba(255,190,90,'+(.18+.06*Math.sin(t*3+k)).toFixed(2)+')';ctx.beginPath();ctx.arc(nx,ny+14*u,16*u,0,7);ctx.fill()}
  /* doorway (stepped corbel arch) */
  const dx0=X(236),dx1=X(330);
  if(dx1>0&&dx0<W){ctx.fillStyle=wlg(G-290*u,G+16*u,'#050a08','#16241c');ctx.beginPath();const pts=[[236,16],[236,-250],[246,-250],[246,-270],[258,-270],[258,-290],[308,-290],[308,-270],[320,-270],[320,-250],[330,-250],[330,16]];pts.forEach((p,i)=>{const px2=X(p[0]),py2=G+p[1]*u;i?ctx.lineTo(px2,py2):ctx.moveTo(px2,py2)});ctx.closePath();ctx.fill();wol(2);
    const gg=ctx.createRadialGradient(X(318),G-20*u,4*u,X(318),G-20*u,150*u);gg.addColorStop(0,'rgba(255,170,70,.4)');gg.addColorStop(1,'rgba(255,170,70,0)');ctx.save();ctx.clip();ctx.fillStyle=gg;ctx.fillRect(dx0,G-300*u,dx1-dx0,330*u);ctx.restore();
    ctx.strokeStyle='rgba(190,225,190,.34)';ctx.lineWidth=1.4*u;ctx.beginPath();pts.forEach((p,i)=>{const px2=X(p[0]+(p[0]<283?-3:3)),py2=G+(p[1]+(i>0&&i<11?4:0))*u;i?ctx.lineTo(px2,py2):ctx.moveTo(px2,py2)});ctx.stroke();
    ctx.fillStyle='#738679';rr(X(226),G-334*u,X(340)-X(226),40*u,4*u);ctx.fill();wol(1.8);ctx.strokeStyle='rgba(20,32,26,.45)';ctx.lineWidth=1.2*u;ctx.strokeRect(X(230),G-330*u,X(336)-X(230),32*u);
    tpKala(X(283),G-316*u,24*u)}
  tpLion(X(186),Y(X(186)),1);
  for(const[k,n]of[[168,1],[118,2],[70,3]])cvTorch(X(k),G-(k>150?90:70)*u,n);
  mgTree(X(78),G-205*u,.85,3,'#4e3720','#2f6a3e',1);mgTree(X(186),G-305*u,.8,4,'#4e3720','#2f6a3e',1);mgTree(X(-20),G-120*u,.7,5,'#4e3720','#2f6a3e',1);
  for(const[k,y0,n]of[[132,305,1],[100,205,2],[44,205,3],[236,300,4]]){const rx=X(k);tpRoot(rx,G-y0*u,rx+16*u,G-y0*u*.5,rx-6*u,Y(rx),7);tpRoot(rx+14*u,G-y0*u+6*u,rx+30*u,G-y0*u*.4,rx+12*u,Y(rx+14*u),4.5)}
  for(let q=0;q<9;q++){const k=-40+q*34,tt=k<40?120:k<130?205:k<236?305:0;if(!tt)continue;tpVine(X(k),G-tt*u+2*u,(14+bgH(q,4)*34)*u,q)}}
export function tpFront(){
  if(!state.tpOn)return;const a=tpS(196),b=tpS(374);if(b<-30||a>W+30)return;ctx.lineJoin=ctx.lineCap='round';
  for(const k of[196,330]){const x=tpS(k+20);if(x<-60||x>W+60)continue;tpPillar(x,G+ter(x)+6*u,G-312*u,40*u)}
  for(let q=0;q<6;q++){const x=tpS(240+q*17),l=(46+bgH(q,9)*70)*u;if(x<-10||x>W+10)continue;tpVine(x,G-300*u,l,q+20)}}
const tpBam=(x,y0,y1,w)=>{
  ctx.strokeStyle='rgba(20,16,4,.55)';ctx.lineWidth=(w+2.4)*u;ctx.beginPath();ctx.moveTo(x,y0);ctx.lineTo(x,y1);ctx.stroke();
  ctx.strokeStyle='#c9b25a';ctx.lineWidth=w*u;ctx.stroke();ctx.strokeStyle='rgba(255,250,200,.5)';ctx.lineWidth=.9*u;ctx.beginPath();ctx.moveTo(x-w*.22*u,y0);ctx.lineTo(x-w*.22*u,y1);ctx.stroke();
  ctx.strokeStyle='#7a6a2c';ctx.lineWidth=1.6*u;ctx.beginPath();const a=Math.max(y0,state.tpCamY-20),b=Math.min(y1,state.tpCamY+H+20),st2=66*u;for(let y=Math.ceil(a/st2)*st2;y<b;y+=st2){ctx.moveTo(x-w*.55*u,y);ctx.lineTo(x+w*.55*u,y)}ctx.stroke()};
const tpBamH=(x0,x1,y,w)=>{ctx.strokeStyle='rgba(20,16,4,.55)';ctx.lineWidth=(w+2.4)*u;ctx.beginPath();ctx.moveTo(x0,y);ctx.lineTo(x1,y);ctx.stroke();ctx.strokeStyle='#c9b25a';ctx.lineWidth=w*u;ctx.stroke();ctx.strokeStyle='rgba(255,250,200,.5)';ctx.lineWidth=.9*u;ctx.beginPath();ctx.moveTo(x0,y-w*.22*u);ctx.lineTo(x1,y-w*.22*u);ctx.stroke();wdot(x0,y,w*.62*u,'#b89a62');wdot(x1,y,w*.62*u,'#b89a62')};
const tpRope=(x0,y0,cx,cy,x1,y1,w,off)=>{BST('rgba(20,12,0,.5)',w+1.8,x0,y0,cx,cy,x1,y1);BST('#c4a86a',w,x0,y0,cx,cy,x1,y1);ctx.save();ctx.setLineDash([2.2*u,3.6*u]);ctx.lineDashOffset=-off;ctx.strokeStyle='rgba(90,60,20,.55)';ctx.lineWidth=w*u;ctx.beginPath();ctx.moveTo(x0,y0);ctx.quadraticCurveTo(cx,cy,x1,y1);ctx.stroke();ctx.restore()};
const tpWheel=(x,y,r,ang,n)=>{ctx.save();ctx.translate(x,y);ctx.rotate(ang);ctx.fillStyle='#8a5a30';ctx.beginPath();ctx.arc(0,0,r,0,7);ctx.fill();wol(1.8);ctx.fillStyle='#4a3018';ctx.beginPath();ctx.arc(0,0,r*.74,0,7);ctx.fill();ctx.strokeStyle='#c9a566';ctx.lineWidth=Math.max(1.2,r*.1);ctx.beginPath();for(let q=0;q<n;q++){const a=q*6.2832/n;ctx.moveTo(0,0);ctx.lineTo(Math.cos(a)*r*.95,Math.sin(a)*r*.95)}ctx.stroke();wdot(r*.84,0,Math.max(1.3,r*.09),'#ffd23f');ctx.restore();wdot(x,y,Math.max(1.6,r*.18),'#ffd23f')};
function tpNaga(xs,ys,xe,ye,head){
  const sl=(ye-ys)/((xe-xs)||1);ctx.lineCap='round';
  ctx.strokeStyle='rgba(0,0,0,.45)';ctx.lineWidth=12*u;ctx.beginPath();ctx.moveTo(xs,ys);ctx.lineTo(xe,ye);ctx.stroke();ctx.strokeStyle='#76897a';ctx.lineWidth=9*u;ctx.stroke();
  ctx.strokeStyle='rgba(235,245,220,.5)';ctx.lineWidth=1.6*u;ctx.beginPath();ctx.moveTo(xs,ys-3*u);ctx.lineTo(xe,ye-3*u);ctx.stroke();
  ctx.strokeStyle='rgba(20,34,26,.4)';ctx.lineWidth=1.1*u;ctx.beginPath();par(13*u,1,xs,xe,(sx,i)=>{if(sx<xs||sx>xe)return;const sy=ys+(sx-xs)*sl;ctx.moveTo(sx,sy-3.5*u);ctx.quadraticCurveTo(sx+4*u,sy,sx,sy+3.5*u)});ctx.stroke();
  par(64*u,1,xs,xe,(sx,i)=>{if(sx<xs||sx>xe)return;const sy=ys+(sx-xs)*sl,fy=G+ter(sx)+2*u;ctx.fillStyle='#5a6c5f';rr(sx-4*u,sy,8*u,Math.max(6*u,fy-sy),2*u);ctx.fill();wol(1.3)});
  if(head){BPG('#76897a',xs-4*u,ys+3*u,xs-18*u,ys-14*u,xs-14*u,ys-34*u,xs+4*u,ys-26*u,xs+8*u,ys-6*u);BPG('#8a9c8c',xs-2*u,ys-6*u,xs-8*u,ys-20*u,xs+3*u,ys-18*u);wdot(xs-10*u,ys-22*u,2.2*u,'#ffc04a');BPG('#d6454a',xs-17*u,ys-12*u,xs-26*u,ys-8*u+Math.sin(t*6)*2*u,xs-17*u,ys-8*u)}}
/* earth cross-section: strata, stones, roots, bones, ammonites, ore sparkles */
function tpEarth(){
  const x0=Math.max(0,tpS(0)),x1=Math.min(W,tpS(TP.END)+W+250*u);if(x1<=x0||state.tpCamY<1)return;
  const y0=G+12*u,y1=state.tpCamY+H+12,g=ctx.createLinearGradient(0,G-60*u,0,H);g.addColorStop(0,MV.d0);g.addColorStop(1,MV.d1);ctx.fillStyle=g;ctx.fillRect(x0,y0,x1-x0,y1-y0);
  const q0=Math.max(0,Math.floor((state.tpCamY-G)/(90*u))-1),q1=Math.floor((state.tpCamY+H-G)/(90*u))+1;ctx.lineCap='round';
  for(let q=q0;q<=q1;q++){const ly=G+(50+q*90)*u;for(let p=0;p<2;p++){ctx.strokeStyle=p?'rgba(230,180,110,.1)':'rgba(16,14,6,.34)';ctx.lineWidth=(p?1.2:3)*u;ctx.beginPath();for(let x=x0;x<=x1+24;x+=24){const y=ly+p*4*u+Math.sin((x+state.dist)/(50*u)+q*1.7)*3*u;x===x0?ctx.moveTo(x,y):ctx.lineTo(x,y)}ctx.stroke()}}
  par(150*u,1,x0,x1,(sx,i)=>{for(let q=q0;q<=q1;q++){const key=i*53+q*17;if(bgH(key,1)<.45)continue;const ty=bgH(key,2),x=sx+bgH(key,3)*130*u,y=G+(50+q*90)*u+(20+bgH(key,4)*50)*u;
    if(ty<.34){const rx=(6+bgH(key,5)*8)*u;ctx.fillStyle=q>4?'#5d5546':'#8a7a60';ctx.beginPath();ctx.ellipse(x,y,rx,rx*.58,bgH(key,6)*.6-.3,0,7);ctx.fill();ctx.strokeStyle='rgba(0,0,0,.34)';ctx.lineWidth=1.4*u;ctx.stroke();ctx.fillStyle='rgba(255,255,255,.2)';ctx.beginPath();ctx.ellipse(x-rx*.25,y-rx*.2,rx*.4,rx*.2,-.3,0,7);ctx.fill()}
    else if(ty<.62){if(q<7)tpRoot(x,y-40*u,x+10*u,y,x-4*u,y+46*u,2.6+bgH(key,7)*2)}
    else if(ty<.8){BST('rgba(0,0,0,.4)',4.4,x-10*u,y,x,y-1*u,x+10*u,y+2*u);BST('#e9e1c9',3,x-10*u,y,x,y-1*u,x+10*u,y+2*u);wdot(x-11*u,y-2*u,2.4*u,'#e9e1c9');wdot(x-11*u,y+2*u,2.4*u,'#e9e1c9');wdot(x+11*u,y,2.4*u,'#e9e1c9')}
    else if(ty<.9){ctx.strokeStyle='rgba(235,225,200,.55)';ctx.lineWidth=1.6*u;ctx.beginPath();for(let a=0;a<14;a++){const r=(1+a*.5)*u;ctx.lineTo(x+Math.cos(a*.7)*r,y+Math.sin(a*.7)*r)}ctx.stroke()}
    else if(q>3)BSP(x,y,(1+2*Math.max(0,Math.sin(t*3+key)))*u,'rgba(255,214,90,.95)')}});
}
function tpDepth(){if(state.tpCamY<1)return;const y0=G+10*u,g=ctx.createLinearGradient(0,y0,0,G+TP.D*u+H*.6);g.addColorStop(0,'rgba(0,0,0,0)');g.addColorStop(1,'rgba(0,0,0,.55)');ctx.fillStyle=g;ctx.fillRect(-10,y0,W+20,state.tpCamY+H+10-y0)}
/* staircase corridor + deep hall */
function tpCorr(){
  const xa=tpS(TP.I),xb=tpS(TP.KC-TP.CH),L=Math.max(0,xa),R=Math.min(W,xb);if(R<=L)return;
  const k0=x=>(x+state.dist)/u-state.tpU,fy=x=>G+tpDs(x+state.dist),cl=x=>(300+110*tpSm((k0(x)-(TP.S1-300))/300))*u,cy=x=>fy(x)-cl(x),fl=x=>G+ter(x);
  const xs=[];for(let x=L;x<R;x+=14)xs.push(x);xs.push(R);const cyv=xs.map(cy);
  const topPath=dy=>{ctx.beginPath();xs.forEach((x,i)=>{const y=cyv[i]+dy;i?ctx.lineTo(x,y):ctx.moveTo(x,y)})};
  /* stone slab above the corridor, mossy roof edge */
  topPath(-34*u);for(let i=xs.length-1;i>=0;i--)ctx.lineTo(xs[i],cyv[i]+2*u);ctx.closePath();ctx.fillStyle='#1b2c23';ctx.fill();
  topPath(-34*u);ctx.strokeStyle='rgba(0,0,0,.5)';ctx.lineWidth=3*u;ctx.stroke();topPath(-35.5*u);ctx.strokeStyle='rgba(120,160,80,.75)';ctx.lineWidth=1.6*u;ctx.stroke();
  ctx.strokeStyle='rgba(0,0,0,.4)';ctx.lineWidth=1.3*u;ctx.beginPath();par(150*u,1,L,R,(sx,i)=>{if(sx<L||sx>R)return;const y=cy(sx);ctx.moveTo(sx,y-34*u);ctx.lineTo(sx,y+2*u)});ctx.stroke();
  par(60*u,1,L,R,(sx,i)=>{if(sx<L||sx>R)return;const y=cy(sx)-35*u;if(y<G+6*u&&bgH(i,17)>.45)mgLf(sx,y,-1.3+bgH(i,18)*.5,(8+bgH(i,19)*8)*u,3*u,'#2f6a3e','rgba(180,230,120,.3)')});
  /* corridor interior */
  const fv=[];for(let x=L;x<R;x+=6)fv.push(x);fv.push(R);
  ctx.save();ctx.beginPath();xs.forEach((x,i)=>{i?ctx.lineTo(x,cyv[i]):ctx.moveTo(x,cyv[i])});for(let i=fv.length-1;i>=0;i--)ctx.lineTo(fv[i],fl(fv[i]));ctx.closePath();ctx.clip();
  let g=ctx.createLinearGradient(0,state.tpCamY,0,state.tpCamY+H);g.addColorStop(0,'#06100d');g.addColorStop(.5,'#16291f');g.addColorStop(1,'#08130f');ctx.fillStyle=g;ctx.fillRect(L,state.tpCamY-4,R-L,H+8);
  par(240*u,.3,L,R,(sx,i)=>{const w=118*u,y0=cy(sx)+cl(sx)*.2,yb=fy(sx)+60*u;ctx.fillStyle='rgba(4,12,9,.6)';ctx.beginPath();ctx.moveTo(sx,yb);ctx.lineTo(sx,y0+w/2);ctx.arc(sx+w/2,y0+w/2,w/2,Math.PI,0);ctx.lineTo(sx+w,yb);ctx.closePath();ctx.fill();ctx.strokeStyle='rgba(130,200,170,.14)';ctx.lineWidth=2*u;ctx.stroke();ctx.strokeStyle='rgba(130,200,170,.08)';ctx.lineWidth=1.2*u;ctx.beginPath();ctx.arc(sx+w/2,y0+w/2,w/2-7*u,Math.PI,0);ctx.stroke();
    if(i&1){ctx.fillStyle='rgba(255,190,90,'+(.1+.04*Math.sin(t*2+i)).toFixed(2)+')';ctx.beginPath();ctx.arc(sx+w/2,fy(sx)-20*u,34*u,0,7);ctx.fill()}});
  const ba=.24,bb=.42;ctx.beginPath();for(let i=0;i<xs.length;i++){const y=cyv[i]+cl(xs[i])*ba;i?ctx.lineTo(xs[i],y):ctx.moveTo(xs[i],y)}for(let i=xs.length-1;i>=0;i--)ctx.lineTo(xs[i],cyv[i]+cl(xs[i])*bb);ctx.closePath();ctx.fillStyle='rgba(74,98,84,.34)';ctx.fill();
  ctx.strokeStyle='rgba(0,0,0,.35)';ctx.lineWidth=1.6*u;ctx.beginPath();xs.forEach((x,i)=>{const y=cyv[i]+cl(x)*ba;i?ctx.lineTo(x,y):ctx.moveTo(x,y)});xs.forEach((x,i)=>{const y=cyv[i]+cl(x)*bb;i?ctx.lineTo(x,y):ctx.moveTo(x,y)});ctx.stroke();
  par(64*u,1,L,R,(sx,i)=>{const y0=cy(sx)+cl(sx)*ba,hh=cl(sx)*(bb-ba),cx=sx+30*u,c2=y0+hh/2;ctx.strokeStyle='rgba(190,225,190,.2)';ctx.lineWidth=1.2*u;ctx.beginPath();
    if(i%3===0){for(let q=0;q<16;q++){const a=q*.5,r=2+q*1.4;ctx.lineTo(cx+Math.cos(a)*r*u,c2+Math.sin(a)*r*u)}}else{ctx.moveTo(cx-14*u,c2);ctx.lineTo(cx,c2-14*u);ctx.lineTo(cx+14*u,c2);ctx.lineTo(cx,c2+14*u);ctx.closePath();ctx.moveTo(cx-6*u,c2);ctx.lineTo(cx,c2-6*u);ctx.lineTo(cx+6*u,c2);ctx.lineTo(cx,c2+6*u);ctx.closePath()}ctx.stroke()});
  par(560*u,1,L,R,(sx,i)=>{const yy=cy(sx)+cl(sx)*.68;ctx.globalAlpha=.7;tpKala(sx+60*u,yy,34*u);ctx.globalAlpha=1;ctx.fillStyle='rgba(6,16,12,.3)';ctx.beginPath();ctx.arc(sx+60*u,yy,56*u,0,7);ctx.fill()});
  par(430*u,.9,L,R,(sx,i)=>{if(i&1)return;const y0=cy(sx),gg=ctx.createLinearGradient(sx,y0,sx+120*u,fy(sx)),al=.15+.06*Math.sin(t*.7+i);gg.addColorStop(0,'rgba(220,245,160,'+al.toFixed(3)+')');gg.addColorStop(1,'rgba(220,245,160,0)');ctx.fillStyle=gg;ctx.beginPath();ctx.moveTo(sx,y0);ctx.lineTo(sx+46*u,y0);ctx.lineTo(sx+190*u,fy(sx)+40*u);ctx.lineTo(sx+60*u,fy(sx)+40*u);ctx.closePath();ctx.fill()});
  par(380*u,1,L,R,(sx,i)=>{const k=k0(sx);if(bgH(i,40)<.25||k<TP.S1+80||k>TP.KC-TP.CH-110)return;ctx.globalAlpha=.85;tpPillar(sx,fy(sx)+4*u,cy(sx),34*u);ctx.globalAlpha=1});
  par(520*u,1,L,R,(sx,i)=>{const k=k0(sx);if(k<TP.S1+60||k>TP.KC-TP.CH-90||(i&1))return;const f=fy(sx),f2=Math.sin(t*12+i)*2*u,gg=ctx.createRadialGradient(sx,f-30*u,3*u,sx,f-30*u,150*u);gg.addColorStop(0,'rgba(255,170,70,.45)');gg.addColorStop(1,'rgba(255,150,60,0)');ctx.fillStyle=gg;ctx.beginPath();ctx.arc(sx,f-30*u,150*u,0,7);ctx.fill();
    ctx.strokeStyle='rgba(0,0,0,.5)';ctx.lineWidth=4.4*u;ctx.beginPath();ctx.moveTo(sx-14*u,f);ctx.lineTo(sx-4*u,f-34*u);ctx.moveTo(sx+14*u,f);ctx.lineTo(sx+4*u,f-34*u);ctx.moveTo(sx,f);ctx.lineTo(sx,f-34*u);ctx.stroke();ctx.strokeStyle='#c9b25a';ctx.lineWidth=2.6*u;ctx.stroke();
    BPG('#3b3026',sx-12*u,f-36*u,sx+12*u,f-36*u,sx+8*u,f-27*u,sx-8*u,f-27*u);ctx.fillStyle='#ff7a1a';ctx.beginPath();ctx.moveTo(sx+f2*.4,f-62*u-f2);ctx.quadraticCurveTo(sx+9*u,f-48*u,sx+7*u,f-36*u);ctx.quadraticCurveTo(sx,f-32*u,sx-7*u,f-36*u);ctx.quadraticCurveTo(sx-9*u,f-48*u,sx+f2*.4,f-62*u-f2);ctx.fill();wol(1.2);ctx.fillStyle='#ffd27a';ctx.beginPath();ctx.ellipse(sx,f-42*u,3.6*u,7*u,0,0,7);ctx.fill();BSP(sx+Math.sin(t*3+i)*8*u,f-70*u-((t*20+i*9)%24)*u,2*u,'rgba(255,220,130,.9)')});
  par(430*u,1,L,R,(sx,i)=>{const k=k0(sx);if(k<TP.S0+60||k>TP.S1-60)return;cvTorch(sx,fy(sx)-cl(sx)*.38,i*3+1)});
  par(78*u,.9,L,R,(sx,i)=>{if(bgH(i,6)<.35)return;const y0=cy(sx),h=(14+bgH(i,5)*58)*u,sw=Math.sin(t*1.2+i)*3*u;tpRoot(sx,y0,sx+sw*.4,y0+h*.5,sx+sw,y0+h,3.4);if(bgH(i,7)>.5)mgLf(sx+sw,y0+h,1.5,9*u,3*u,'#2f6a3e','rgba(180,230,120,.3)')});
  par(240*u,.5,L,R,(sx,i)=>{ctx.fillStyle='rgba(130,210,170,'+(.08+.04*Math.sin(t*.6+i)).toFixed(3)+')';ctx.beginPath();ctx.ellipse(sx+Math.sin(t*.3+i)*20*u,fy(sx)-6*u,160*u,22*u,0,0,7);ctx.fill()});
  ctx.save();ctx.globalCompositeOperation='lighter';for(let i=0;i<14;i++){const x=((i*131+Math.sin(t*.4+i)*30*u-state.dist*(.2+i%3*.12))%W+W)%W;if(x<L||x>R)continue;const y=fy(x)-(20+(i*47)%190)*u+Math.sin(t*.9+i*2)*8*u,a=.35+.65*Math.max(0,Math.sin(t*2.2+i*1.7));ctx.fillStyle='rgba(190,255,120,'+(.14*a).toFixed(3)+')';ctx.beginPath();ctx.arc(x,y,9*u,0,7);ctx.fill();ctx.fillStyle='rgba(240,255,170,'+a.toFixed(2)+')';ctx.beginPath();ctx.arc(x,y,1.8*u,0,7);ctx.fill()}ctx.restore();
  ctx.restore();
  /* floor slab, lip, treads */
  const fvy=fv.map(fl);ctx.beginPath();fv.forEach((x,i)=>{i?ctx.lineTo(x,fvy[i]):ctx.moveTo(x,fvy[i])});for(let i=fv.length-1;i>=0;i--)ctx.lineTo(fv[i],fvy[i]+26*u);ctx.closePath();g=ctx.createLinearGradient(0,G,0,G+TP.D*u);g.addColorStop(0,'#5b6d62');g.addColorStop(1,'#26352c');ctx.fillStyle=g;ctx.fill();
  ctx.strokeStyle='rgba(0,0,0,.3)';ctx.lineWidth=1.3*u;ctx.beginPath();par(96*u,1,L,R,(sx,i)=>{if(sx<L||sx>R)return;const y=fl(sx);ctx.moveTo(sx,y+2*u);ctx.lineTo(sx,y+24*u)});ctx.stroke();
  const lip=(w,c,dy)=>{ctx.strokeStyle=c;ctx.lineWidth=w*u;ctx.beginPath();fv.forEach((x,i)=>{const y=fvy[i]+dy*u;i?ctx.lineTo(x,y):ctx.moveTo(x,y)});ctx.stroke()};lip(8,'rgba(0,0,0,.5)',3);lip(5,'#8a9a86',2);lip(1.4,'rgba(235,245,225,.55)',.2);
  par(110*u,1,L,R,(sx,i)=>{if(bgH(i,12)<.5||sx<L||sx>R)return;const y=fl(sx);ctx.fillStyle='rgba(95,150,70,.78)';ctx.beginPath();ctx.ellipse(sx+10*u,y+3*u,(10+bgH(i,13)*10)*u,3.4*u,0,0,7);ctx.fill();ctx.strokeStyle='rgba(8,34,16,.45)';ctx.lineWidth=1.1*u;ctx.stroke()});
  const sA=tpS(TP.S0),sB=tpS(TP.S1);
  if(sB>L&&sA<R){ctx.strokeStyle='rgba(235,245,225,.45)';ctx.lineWidth=1.5*u;ctx.beginPath();for(let q=0;q<TP.SN;q++){const x=tpS(TP.S0+(q+.65)*TP.SW);if(x<L-40||x>R)continue;ctx.moveTo(x,fl(x-2)+1*u);ctx.lineTo(x,fl(x+TP.SW*.35*u)+1*u)}ctx.stroke();
    const ya=x=>G-44*u+(x-sA)/(sB-sA)*TP.D*u,xa2=Math.max(sA-10*u,-40),xb2=Math.min(sB,W+40);if(xb2>xa2)tpNaga(xa2,ya(xa2),xb2,ya(xb2),sA-10*u>=-40)}
}
/* vertical shaft: bamboo guide poles, bamboo-rope lift, winch drum, top station at the surface */
function tpShaft(){
  const xp=tpS(TP.KC),x0=xp-TP.CH*u,x1=xp+TP.CH*u;if(x1<-170*u||x0>W+170*u)return;
  const fyF=G+TP.D*u,top=G-6*u,deckY=fyF-8*u-state.tpH,L=state.tpL,tn=L?L.tn:0,sp=L?L.sp:0,ang=state.tpH/(13*u)+sp*.6,off=state.tpH+sp*6*u,sag=(1-tn)*7*u,vib=Math.sin(t*38)*.6*u*tn*(1-.6*tn);
  const yA=Math.max(top,state.tpCamY-40),yB=Math.min(fyF+26*u,state.tpCamY+H+40);
  ctx.save();ctx.beginPath();ctx.rect(x0,top,x1-x0,fyF+26*u-top);ctx.clip();
  let g=ctx.createLinearGradient(0,G,0,fyF);g.addColorStop(0,'#5d7f6b');g.addColorStop(.35,'#2d4337');g.addColorStop(1,'#0b1612');ctx.fillStyle=g;ctx.fillRect(x0,top,x1-x0,fyF+26*u-top);
  ctx.strokeStyle='rgba(0,0,0,.3)';ctx.lineWidth=1.3*u;ctx.beginPath();for(let n=Math.ceil((yA-G)/(30*u));G+n*30*u<yB;n++){const y=G+n*30*u,o=((n&1)?26:8)*u;ctx.moveTo(x0,y);ctx.lineTo(x1,y);for(let x=x0+o;x<x1;x+=40*u){ctx.moveTo(x,y);ctx.lineTo(x,y+30*u)}}ctx.stroke();
  ctx.fillStyle='rgba(95,150,70,.5)';for(let n=Math.ceil((yA-G)/(120*u));G+n*120*u<yB;n++){const y=G+n*120*u+bgH(n,3)*40*u;ctx.beginPath();ctx.ellipse(x0+5*u,y,6*u,18*u,0,0,7);ctx.ellipse(x1-5*u,y+50*u,6*u,16*u,0,0,7);ctx.fill()}
  const lg=ctx.createLinearGradient(0,top,0,top+520*u);lg.addColorStop(0,'rgba(255,248,190,.3)');lg.addColorStop(1,'rgba(255,248,190,0)');ctx.fillStyle=lg;ctx.fillRect(x0,top,x1-x0,520*u);
  ctx.restore();
  ctx.fillStyle='#2b3a33';rr(x0-24*u,G-5*u,26*u,11*u,2*u);ctx.fill();wol(1.5);rr(x1-2*u,G-5*u,26*u,11*u,2*u);ctx.fill();wol(1.5);ctx.fillStyle='rgba(95,150,70,.8)';ctx.beginPath();ctx.ellipse(x0-10*u,G-5*u,12*u,3*u,0,0,7);ctx.ellipse(x1+11*u,G-5*u,12*u,3*u,0,0,7);ctx.fill();
  /* winch alcove with drum, and the haul-rope groove */
  const dx=xp+58*u,dy=fyF-34*u,topY=G-214*u;
  ctx.fillStyle='rgba(3,8,6,.75)';ctx.fillRect(x1,fyF-130*u,44*u,130*u);ctx.strokeStyle='rgba(0,0,0,.5)';ctx.lineWidth=2*u;ctx.strokeRect(x1,fyF-130*u,44*u,130*u);
  ctx.fillStyle='rgba(0,0,0,.35)';ctx.fillRect(dx-5*u,topY,10*u,fyF-34*u-topY);
  tpBam(xp-46*u,topY-2*u,fyF,5);tpBam(xp+46*u,topY-2*u,fyF,5);
  for(let n=Math.ceil((Math.max(topY,state.tpCamY-60)-G)/(150*u));G+n*150*u<Math.min(fyF-40*u,state.tpCamY+H+60);n++){const y=G+n*150*u;if(y<topY)continue;tpBamH(xp-46*u,xp+46*u,y,3.4);BST('rgba(20,16,4,.45)',3.6,xp-46*u,y,xp,y+34*u,xp+46*u,y+70*u);BST('#b89a52',2,xp-46*u,y,xp,y+34*u,xp+46*u,y+70*u);
    const lx=xp-30*u;ctx.fillStyle='rgba(255,200,90,.22)';ctx.beginPath();ctx.arc(lx,y+14*u,12*u,0,7);ctx.fill();ctx.fillStyle='#ffd27a';rr(lx-3*u,y+8*u,6*u,9*u,2*u);ctx.fill();wol(1)}
  tpWheel(dx,dy,22*u,2*ang*13/22+sp*.5,8);
  tpRope(dx,dy-22*u,dx+vib+sag*.3,(dy-22*u+topY+22*u)/2,dx,topY+22*u,2.2,2*off);
  /* top station: beam, thatch roof, top wheel, strands */
  const wx=xp+35*u,wy=topY+30*u;
  tpBamH(xp-64*u,xp+64*u,topY,4);BPG('#b89a52',xp-76*u,topY-2*u,xp,topY-40*u,xp+76*u,topY-2*u);ctx.strokeStyle='rgba(80,56,16,.5)';ctx.lineWidth=1*u;ctx.beginPath();for(let q=0;q<9;q++){const f=q/9;ctx.moveTo(xp-70*u+f*140*u,topY-3*u);ctx.lineTo(xp-36*u+f*72*u,topY-34*u+Math.abs(f-.5)*8*u)}ctx.stroke();
  BST('rgba(20,16,4,.5)',4.4,xp+24*u,topY,xp+30*u,topY+12*u,wx,wy);BST('#c9b25a',2.4,xp+24*u,topY,xp+30*u,topY+12*u,wx,wy);
  tpWheel(wx,wy,22*u,2*ang*13/22+sp*.5,8);
  for(let q=0;q<3;q++){const fw=Math.sin(t*5+q)*3*u;BPG(['#d6454a','#ffd23f','#2f9a66'][q],xp-60*u,topY-2*u+q*3*u,xp-78*u+fw,topY+2*u+q*3*u,xp-60*u,topY+5*u+q*3*u)}
  const ly=topY+18*u;ctx.fillStyle='rgba(255,200,90,.26)';ctx.beginPath();ctx.arc(xp-34*u,ly+10*u,14*u,0,7);ctx.fill();ctx.fillStyle='#ffd27a';rr(xp-37*u,ly+4*u,6*u,9*u,2*u);ctx.fill();wol(1);
  /* hoist strands: left end tied to the beam, right strand over the top wheel and down the groove to the drum */
  const py=deckY-92*u;
  tpRope(xp-13*u,py,xp-13*u+sag*Math.sin(t*1.9)+vib,(py+topY)/2,xp-13*u,topY+4*u,2.4,off);
  tpRope(xp+13*u,py,xp+13*u-sag*Math.sin(t*1.5)-vib,(py+wy)/2,xp+13*u,wy,2.4,off);
  /* the lift platform */
  const bx=xp-52*u;
  BST('rgba(20,12,0,.45)',3.6,xp-40*u,deckY,xp-26*u,py+8*u,xp-14*u,py);BST('#b89a62',2,xp-40*u,deckY,xp-26*u,py+8*u,xp-14*u,py);BST('rgba(20,12,0,.45)',3.6,xp+40*u,deckY,xp+26*u,py+8*u,xp+14*u,py);BST('#b89a62',2,xp+40*u,deckY,xp+26*u,py+8*u,xp+14*u,py);
  tpBam(xp-40*u,py+4*u,deckY,4);tpBam(xp+40*u,py+4*u,deckY,4);tpBamH(xp-42*u,xp+42*u,py+4*u,4);
  for(const dy2 of[-46,-30,-16]){const yy=deckY+dy2*u;BST('rgba(20,12,0,.45)',3,xp-40*u,yy,xp,yy+4*u,xp+40*u,yy);BST('#b89a62',1.6,xp-40*u,yy,xp,yy+4*u,xp+40*u,yy)}
  tpWheel(xp,py,13*u,ang,6);
  ctx.fillStyle='#c9b25a';rr(bx,deckY,104*u,12*u,3*u);ctx.fill();wol(1.8);ctx.strokeStyle='rgba(80,64,16,.5)';ctx.lineWidth=1*u;ctx.beginPath();for(let q=1;q<13;q++){ctx.moveTo(bx+q*8*u,deckY);ctx.lineTo(bx+q*8*u,deckY+12*u)}ctx.stroke();ctx.strokeStyle='rgba(255,250,200,.55)';ctx.beginPath();ctx.moveTo(bx+4*u,deckY+2*u);ctx.lineTo(bx+100*u,deckY+2*u);ctx.stroke();
  ctx.strokeStyle='rgba(20,16,4,.5)';ctx.lineWidth=3.6*u;ctx.beginPath();ctx.moveTo(bx+10*u,deckY+12*u);ctx.lineTo(bx+10*u,deckY+18*u);ctx.moveTo(bx+94*u,deckY+12*u);ctx.lineTo(bx+94*u,deckY+18*u);ctx.stroke();
}
export function tpScene(){
  if(!state.tpOn)return;
  if(state.tpCamY>.4){ctx.fillStyle=MV.d1;ctx.fillRect(-10,H-2,W+20,state.tpCamY+14)}
  if(tpS(TP.END)<-120*u||tpS(-60)>W+120*u)return;
  ctx.lineJoin=ctx.lineCap='round';tpPlaza();tpFacade();tpEarth();tpDepth();tpCorr();tpShaft()}
