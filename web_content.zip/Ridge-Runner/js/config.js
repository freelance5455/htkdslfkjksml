/*
 * config.js - Static tunables and lookup tables: Adventure tunables, booster table, difficulty modes, speed curves, on-screen hint.
 */
export const ADV={
  KEY:'dd-adv',                 // the only storage key Adventure uses: {b:biome, c:clock, p:total played}
  T:[300,600,1200],             // clock time (s) at which each biome ends: Mountain 5:00, Snow 10:00, Mangrove 20:00 (= the finale)
  SP:[[0,230,'Low'],[60,230,'Low'],[240,310,'Medium'],[420,310,'Medium'],[720,400,'High']], // speed waypoints [clock s, speed, label]; the last one holds, never Ultra
  RUN:380,                      // obstacle-free runway at a checkpoint start
  FLAG:170,                     // checkpoint flag distance after the transition ride ends
  GATE:1250                     // finish gate distance ahead when the finale begins
};
export const BT={ghost:{c:'#9ad7ff',r:'154,215,255',i:'👻',d:5,n:'Ghost'},shield:{c:'#7dffa8',r:'125,255,168',i:'🛡️',d:1,n:'Shield'},magnet:{c:'#ff7ad9',r:'255,122,217',i:'🧲',d:7,n:'Magnet'},x2:{c:'#ffd23f',r:'255,210,63',i:'×2',d:8,n:'Coins ×2'},slow:{c:'#b99bff',r:'185,155,255',i:'🐢',d:5,n:'Slow-mo'},fly:{c:'#6ee7ff',r:'110,231,255',i:'🚀',d:5,n:'Fly'},horse:{c:'#d9a066',r:'217,160,102',i:'🐴',d:0,n:'Horse'},sled:{c:'#ff8fa0',r:'255,143,160',i:'🛷',d:0,n:'Sleigh'}};
export const HINT='Tap to jump, tap again in the air to double jump. Collect coins for bonus points. Your ride takes one hit for you.';
const HW=[[0,230,'Low'],[25,230,'Low'],[70,310,'Medium'],[95,310,'Medium'],[150,400,'High'],[180,400,'High'],[250,500,'Ultra']];
export const MODES={easy:{n:'Easy',b:1,w:[[0,230,'Low'],[30,230,'Low'],[90,310,'Medium']]},medium:{n:'Medium',b:1,w:[[0,230,'Low'],[30,230,'Low'],[80,310,'Medium'],[110,310,'Medium'],[170,400,'High']]},hard:{n:'Hard',b:1,w:HW},imp:{n:'Impossible',b:0,w:HW}};
export const SCOL2={Low:'#8fe3a8',Medium:'#ffd23f',High:'#ff9f43',Ultra:'#ff5d73'};
