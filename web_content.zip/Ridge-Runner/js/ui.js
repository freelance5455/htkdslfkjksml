/*
 * ui.js - Menus and overlays: mode chips, play / customize / adventure buttons, admin panel and home button.
 */
import { ADV_HINT, advLoad, advN, advStart, advWrite } from './adventure-mode.js';
import { A } from './audio.js';
import { HINT, MODES } from './config.js';
import { $, bs, card, msg, ttl } from './dom.js';
import { reset } from './game.js';
import { state } from './state.js';

const me=$('modes');
function setMode(k){state.mode=k;state.best=0;try{state.best=+localStorage.getItem('dd-best-'+k)||0;localStorage.setItem('dd-mode',k)}catch(e){}bs.textContent='Best '+state.best;$('mbest').textContent='Best '+state.best;[...me.children].forEach(c=>c.classList.toggle('on',c.dataset.k===k))}
let sm='easy';
const show=(a,b)=>{$('menu').hidden=!a;$('wardrobe').hidden=!b;$('advm').hidden=true};
const adP=$('admp');
const adG=$('admg');
const adT=$('admt');
const adI=$('admc');
const adM=$('admm');
const adB=$('invb');
function admUI(){adI.hidden=adG.hidden=state.adm;adT.hidden=!state.adm;adT.textContent='Invincibility: '+(state.inv?'ON':'OFF');adT.style.background=state.inv?'#ffb347':'';adT.style.color=state.inv?'#10152e':'';adB.hidden=!state.inv;adM.style.color='';adM.textContent=state.adm?'Admin unlocked':''}
/* ---- menu wiring ---- */
const advm=$('advm');
const advc=$('advc');
function advPanel(){advLoad();advc.disabled=!state.aS;advc.textContent=state.aS?'Continue - '+advN[state.aS.b]:'Continue';$('advq').hidden=true;$('menu').hidden=true;$('wardrobe').hidden=true;advm.hidden=false}
function advGo(fresh){A();if(fresh){state.aS={b:0,c:0,p:0};advWrite()}else{advLoad();if(!state.aS)return}
  state.adv=true;reset();advStart();state.st='ready';ttl.textContent='Adventure';msg.textContent=(state.aS.b?advN[state.aS.b]+' checkpoint. ':'')+ADV_HINT;card.hidden=false;show(0,0);$('hud').hidden=true;$('home').hidden=false}
/** Wires this module up to the DOM / storage. Called once from main.js during boot, in the original statement order. */
export function initUI(){
  try{state.best=+localStorage.getItem('dd-best')||0}catch(e){}
  bs.textContent='Best '+state.best;
  $('mbest').textContent='Best '+state.best;
  for(const k in MODES){const b=document.createElement('button');b.className='chip';b.textContent=MODES[k].n;b.dataset.k=k;b.onclick=()=>setMode(k);me.appendChild(b)}
  try{sm=localStorage.getItem('dd-mode')||'easy'}catch(e){}
  setMode(MODES[sm]?sm:'easy');
  $('play').onclick=()=>{state.adv=false;A();state.st='ready';ttl.textContent='Ridge Runner';msg.textContent=MODES[state.mode].n+' mode. '+HINT;card.hidden=false;show(0,0);$('hud').hidden=false};
  $('cust').onclick=()=>show(0,1);
  try{state.adm=localStorage.getItem('dd-admin')==='1';state.inv=state.adm&&localStorage.getItem('dd-inv')!=='0'}catch(e){}
  $('adm').onclick=()=>{adP.hidden=!adP.hidden};
  adG.onclick=()=>{if(adI.value.trim().toLowerCase()==='safwanisinvincible'){state.adm=state.inv=true;try{localStorage.setItem('dd-admin','1');localStorage.setItem('dd-inv','1')}catch(e){}adI.value='';admUI()}else{adM.textContent='Wrong code';adM.style.color='#ff5d73'}};
  adT.onclick=()=>{state.inv=!state.inv;try{localStorage.setItem('dd-inv',state.inv?'1':'0')}catch(e){}admUI()};
  adI.addEventListener('keydown',e=>{e.stopPropagation();if(e.key==='Enter')adG.click()});
  admUI();
  $('done').onclick=()=>show(1,0);
  $('home').onclick=()=>{reset();state.st='menu';card.hidden=true;$('home').hidden=true;$('hud').hidden=true;$('mbest').textContent='Best '+state.best;show(1,0)};
  for(const id of['menu','wardrobe','advm','home'])$(id).addEventListener('pointerdown',e=>e.stopPropagation());
  $('adv').onclick=advPanel;
  $('advb').onclick=()=>{advm.hidden=true;$('menu').hidden=false};
  advc.onclick=()=>advGo(0);
  $('advn').onclick=()=>{advLoad();if(state.aS)$('advq').hidden=false;else advGo(1)};
  $('advy').onclick=()=>advGo(1);
  $('advx').onclick=()=>{$('advq').hidden=true};
}
