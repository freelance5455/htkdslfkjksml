/*
 * outfits-mangrove.js - Mangrove outfits: Sundari Sprout, Bengal Tiger, Spotted Deer, Mud Crab, Mudskipper, Kingfisher, Saltwater Croc, Golpata Boatman.
 */
import { t } from './clock.js';
import { BPG, BST, rr, wdot, wlg, wol } from './draw-utils.js';
import { mgLf } from './mangrove.js';
import { wtl, wtri } from './outfit-parts.js';
import { state } from './state.js';
import { ctx, px, u } from './view.js';

const moQ=(a,b,c,q)=>(1-q)*(1-q)*a+2*q*(1-q)*b+q*q*c;
function moClaw(cx,cy,sc,rot,op,col){
  ctx.save();ctx.translate(cx,cy);ctx.rotate(rot);
  for(const sg of[-1,1]){ctx.save();ctx.rotate(sg*op);ctx.fillStyle=col;ctx.beginPath();ctx.ellipse(5.4*u*sc,sg*2.2*u*sc,6*u*sc,2.8*u*sc,0,0,7);ctx.fill();wol(1.3);ctx.fillStyle='rgba(255,205,175,.45)';ctx.beginPath();ctx.ellipse(5*u*sc,sg*1.5*u*sc,3.4*u*sc,.9*u*sc,0,0,7);ctx.fill();ctx.restore()}
  wdot(0,0,3.2*u*sc,col);wol(1.2);wdot(-.8*u*sc,-.8*u*sc,1*u*sc,'rgba(255,255,255,.55)');ctx.restore();
}
/* checked gamcha tail streaming behind the boatman (same wave as the winter scarf ribbons) */
function moGam(y0,len,wd){
  const x=px+3*u,a=Math.sin(t*9)*2.6*u,d=wtl();
  const P=()=>{ctx.beginPath();ctx.moveTo(x,y0);ctx.bezierCurveTo(x-len*.35,y0-2*u+a*.5+d*.4,x-len*.7,y0+3*u+a+d*.8,x-len,y0+1*u+a*1.3+d);ctx.lineTo(x-len+1.5*u,y0+wd+1*u+a*1.3+d);ctx.bezierCurveTo(x-len*.7,y0+wd+4*u+a+d*.8,x-len*.35,y0+wd-1*u+a*.5+d*.4,x,y0+wd);ctx.closePath()};
  P();ctx.fillStyle='#d62839';ctx.fill();
  ctx.save();P();ctx.clip();
  ctx.fillStyle='rgba(120,10,25,.3)';for(let q=0;q<6;q++)ctx.fillRect(x-len*(q+1)/5.6,y0-8*u,len/11.2,wd+22*u);
  ctx.fillStyle='rgba(255,255,255,.88)';for(let q=1;q<6;q++)ctx.fillRect(x-len*q/5.6-.6*u,y0-8*u,1.2*u,wd+22*u);
  ctx.strokeStyle='rgba(255,255,255,.88)';ctx.lineWidth=1.2*u;ctx.beginPath();ctx.moveTo(x,y0+wd*.5);ctx.bezierCurveTo(x-len*.35,y0+wd*.5-1.5*u+a*.5+d*.4,x-len*.7,y0+wd*.5+3.5*u+a+d*.8,x-len,y0+wd*.5+1*u+a*1.3+d);ctx.stroke();
  ctx.restore();P();wol(1.4);
}
/* behind the body: roots, tails, fins, wings, claws, paddle */
export function moK(T,S){
  const k=state.O.k,x=px,d=wtl(),sw=Math.sin(t*8)*1.4*u;
  ctx.save();ctx.lineJoin='round';ctx.lineCap='round';
  if(k==='sundari'){
    const rt=(y0,ex,cx0,cy0,w)=>{const gx=x+ex*u,gy=T+S+.4*u,cxx=x+cx0*u,cyy=y0+cy0*u+d*.3;BST('rgba(12,6,2,.55)',w+2.2,x+1*u,y0,cxx,cyy,gx,gy);BST('#7a5230',w,x+1*u,y0,cxx,cyy,gx,gy);BST('rgba(224,172,110,.65)',w*.28,x+.4*u,y0-.6*u,cxx-.6*u,cyy-.6*u,gx-.6*u,gy)};
    rt(T+S*.4,-15,-17,-6,3.4);rt(T+S*.56,-8,-12,-3,3.4);rt(T+S*.7,-1.6,-7,-1,3);
    ctx.fillStyle='rgba(30,20,8,.5)';for(const e of[-15,-8,-1.6]){ctx.beginPath();ctx.ellipse(x+e*u,T+S+1.2*u,3*u,1*u,0,0,7);ctx.fill()}
  }else if(k==='tiger'){
    const sy=T+S*.4,w1=Math.sin(t*6)*5*u+d,w2=Math.sin(t*6+1.2)*7*u+d*1.6,x0=x+4*u,x1=x-12*u,x2=x-27*u,y0=sy,y1=sy+w1,y2=sy-4*u+w2;
    BST('rgba(0,0,0,.32)',8.6,x0,y0,x1,y1,x2,y2);BST(state.O.b,6,x0,y0,x1,y1,x2,y2);
    ctx.strokeStyle='#3a2316';ctx.lineWidth=2.4*u;ctx.beginPath();
    for(const q of[.22,.42,.62]){const qx=moQ(x0,x1,x2,q),qy=moQ(y0,y1,y2,q),tx=2*((1-q)*(x1-x0)+q*(x2-x1)),ty=2*((1-q)*(y1-y0)+q*(y2-y1)),l=Math.hypot(tx,ty)||1,nx=-ty/l*2.7*u,ny=tx/l*2.7*u;ctx.moveTo(qx-nx,qy-ny);ctx.lineTo(qx+nx,qy+ny)}ctx.stroke();
    const q0=.74;BST('#3a2316',6,moQ(x0,x1,x2,q0),moQ(y0,y1,y2,q0),(1-q0)*x1+q0*x2,(1-q0)*y1+q0*y2,x2,y2);
    BST('rgba(255,225,160,.5)',1.2,x0,y0-1.8*u,.3*x0+.7*x1,.3*y0+.7*y1-1.8*u,moQ(x0,x1,x2,.7),moQ(y0,y1,y2,.7)-1.8*u);
  }else if(k==='chital'){
    const ex=x+3*u,ey=T+7*u+Math.sin(t*3.4)*.5*u;
    ctx.fillStyle=state.O.b;ctx.beginPath();ctx.ellipse(ex,ey,8*u,3.4*u,.75,0,7);ctx.fill();wol(1.3);
    ctx.fillStyle='#f1c4a6';ctx.beginPath();ctx.ellipse(ex,ey,5.4*u,1.8*u,.75,0,7);ctx.fill();
    ctx.save();ctx.translate(x-1*u,T+S*.56);ctx.rotate(Math.sin(t*9)*.3-.12+d*.02);
    ctx.fillStyle='#a8683a';ctx.beginPath();ctx.ellipse(-2*u,-1.6*u,4.6*u,2.4*u,-.15,0,7);ctx.fill();wol(1.2);
    for(let p=0;p<2;p++)for(const[a,b,r]of[[-2,1.2,3.4],[-5,.2,3],[-3.6,2.6,2.8],[-6.4,2,2.4]]){ctx.fillStyle=p?'#fffaf0':'rgba(80,60,40,.45)';ctx.beginPath();ctx.arc(a*u,b*u+(p?0:.8*u),r*u+(p?0:1*u),0,7);ctx.fill()}
    ctx.restore();
  }else if(k==='crab'){
    for(let i=0;i<3;i++){const ly=T+S*(.52+i*.12),wv=Math.sin(t*10+i*1.6)*1.4*u;BST('rgba(0,0,0,.35)',3.6,x+2*u,ly,x-6*u-i*1.4*u,ly-3*u+wv,x-10*u-i*2*u,ly+5*u+wv);BST('#b83a22',2.2,x+2*u,ly,x-6*u-i*1.4*u,ly-3*u+wv,x-10*u-i*2*u,ly+5*u+wv)}
    const ox=Math.sin(t*5+1.5)*2*u;
    BST('rgba(0,0,0,.35)',4.8,x+3*u,T+S*.5,x-6*u,T+S*.28+ox*.5,x-10*u+ox,T+S*.2);BST('#c9452c',3.2,x+3*u,T+S*.5,x-6*u,T+S*.28+ox*.5,x-10*u+ox,T+S*.2);
    moClaw(x-11*u+ox,T+S*.16,1,-2.4+Math.sin(t*5)*.18,.34+.26*Math.sin(t*5+1),state.O.b);
  }else if(k==='mudskip'){
    const w1=Math.sin(t*8)*2.4*u+d*.6,w2=Math.sin(t*8+1)*3*u+d;
    const P=()=>{ctx.beginPath();ctx.moveTo(x+4*u,T+S*.34);ctx.quadraticCurveTo(x-8*u,T+S*.2+w1,x-24*u+w1*.4,T+S*.06+w2);ctx.quadraticCurveTo(x-20*u,T+S*.28+w2,x-29*u+w1*.4,T+S*.42+w2);ctx.quadraticCurveTo(x-22*u,T+S*.58+w2,x-25*u+w1*.4,T+S*.78+w2);ctx.quadraticCurveTo(x-10*u,T+S*.66+w1,x+4*u,T+S*.66);ctx.closePath()};
    const g=ctx.createLinearGradient(x-29*u,0,x+4*u,0);g.addColorStop(0,'#3fb3a3');g.addColorStop(1,state.O.b);
    P();ctx.fillStyle=g;ctx.fill();
    ctx.save();P();ctx.clip();
    ctx.strokeStyle='rgba(20,60,60,.3)';ctx.lineWidth=1.1*u;ctx.beginPath();for(const a of[.1,.26,.42,.58,.74]){ctx.moveTo(x+2*u,T+S*.5);ctx.lineTo(x-30*u+w1*.4,T+S*a+w2)}ctx.stroke();
    for(const[a,b,c]of[[-8,.2,'#e9fbf3'],[-14,.38,state.O.t],[-20,.22,'#e9fbf3'],[-13,.6,'#e9fbf3'],[-22,.55,state.O.t],[-7,.5,state.O.t]])wdot(x+a*u+w1*.2,T+S*b+w2*.6,1.2*u,c);
    ctx.restore();P();wol(1.4);
    const F=[[.08,10],[.21,15],[.34,17],[.47,13],[.6,8]];
    ctx.beginPath();ctx.moveTo(x+S*.02,T+5*u);F.forEach(([a,h],i)=>{ctx.lineTo(x+S*a,T-h*u+Math.sin(t*5+i)*.9*u);ctx.lineTo(x+S*(a+.065),T-1*u+(i%2)*1.5*u)});ctx.lineTo(x+S*.68,T+5*u);ctx.closePath();
    ctx.fillStyle=wlg(T-18*u,T+5*u,'#79dccb','#2f8f93');ctx.fill();wol(1.4);
    ctx.strokeStyle='rgba(235,255,250,.5)';ctx.lineWidth=.9*u;ctx.beginPath();F.forEach(([a,h],i)=>{ctx.moveTo(x+S*a,T+4*u);ctx.lineTo(x+S*a,T-h*u*.8+Math.sin(t*5+i)*.7*u)});ctx.stroke();
    F.forEach(([a,h],i)=>wdot(x+S*a,T-h*u*.45+Math.sin(t*5+i)*.5*u,1.1*u,i%2?state.O.t:'#e9fbf3'));
  }else if(k==='kingfisher'){
    const fl=Math.sin(t*(state.y>0?22:11));
    for(const[a,l,c]of[[-.45,13,'#1f86b8'],[-.2,15,state.O.b],[.05,12,state.O.t]]){ctx.save();ctx.translate(x+3*u,T+S*.62);ctx.rotate(Math.PI+a+d*.01+Math.sin(t*6+a*5)*.06);ctx.fillStyle=c;ctx.beginPath();ctx.moveTo(0,-2.2*u);ctx.quadraticCurveTo(l*.6*u,-3.2*u,l*u,-.6*u);ctx.quadraticCurveTo(l*.6*u,3.2*u,0,2.2*u);ctx.closePath();ctx.fill();wol(1.2);ctx.restore()}
    ctx.save();ctx.translate(x+S*.36,T+S*.38);ctx.rotate(-2.55+fl*.5+d*.01);
    ctx.fillStyle='#1d7fb0';ctx.beginPath();ctx.moveTo(0,-3.4*u);ctx.quadraticCurveTo(13*u,-9*u,27*u,-1*u);ctx.quadraticCurveTo(14*u,6*u,0,3.4*u);ctx.closePath();ctx.fill();wol(1.4);
    ctx.fillStyle='#2fa7d8';ctx.beginPath();ctx.ellipse(10*u,-1.6*u,9*u,2.4*u,-.12,0,7);ctx.fill();
    ctx.strokeStyle='rgba(165,228,246,.75)';ctx.lineWidth=1*u;ctx.beginPath();ctx.moveTo(4*u,-1*u);ctx.lineTo(23*u,-1*u);ctx.moveTo(4*u,1.6*u);ctx.lineTo(20*u,1*u);ctx.stroke();
    ctx.restore();
  }else if(k==='croc'){
    const w1=Math.sin(t*4.5)*6*u+d,w2=Math.sin(t*4.5+1.3)*9*u+d*1.6,x0=x+3*u,y0=T+S*.52,x1=x-14*u,y1=T+S*.48+w1,x2=x-30.5*u,y2=T+S*.56+w2,N=9,U=[],L=[];
    for(let i=0;i<=N;i++){const q=i/N,cx=moQ(x0,x1,x2,q),cy=moQ(y0,y1,y2,q),tx=2*((1-q)*(x1-x0)+q*(x2-x1)),ty=2*((1-q)*(y1-y0)+q*(y2-y1)),l=Math.hypot(tx,ty)||1,nx=-ty/l,ny=tx/l,h=(9-7.4*q)*u*.5;U.push([cx+nx*h,cy+ny*h,nx,ny]);L.push([cx-nx*h,cy-ny*h])}
    ctx.beginPath();U.forEach((p,i)=>i?ctx.lineTo(p[0],p[1]):ctx.moveTo(p[0],p[1]));for(let i=N;i>=0;i--)ctx.lineTo(L[i][0],L[i][1]);ctx.closePath();ctx.fillStyle=state.O.b;ctx.fill();wol(1.5);
    ctx.strokeStyle='rgba(30,60,25,.32)';ctx.lineWidth=1.4*u;ctx.beginPath();for(const i of[2,4,6]){ctx.moveTo(U[i][0],U[i][1]);ctx.lineTo(L[i][0],L[i][1])}ctx.stroke();
    ctx.strokeStyle=state.O.t;ctx.lineWidth=1.3*u;ctx.beginPath();L.forEach((p,i)=>i?ctx.lineTo(p[0],p[1]):ctx.moveTo(p[0],p[1]));ctx.stroke();
    for(let i=1;i<N;i++){const a=U[i],b=U[i+1],hh=(3.2*(1-i/N)+.9)*u;BPG('#3f6a32',a[0],a[1],(a[0]+b[0])/2+a[2]*hh,(a[1]+b[1])/2+a[3]*hh,b[0],b[1])}
  }else if(k==='boatman'){
    ctx.save();ctx.translate(x+S*.22,T+S*.6);ctx.rotate(-2.2+d*.01+Math.sin(t*5)*.03);
    ctx.strokeStyle='rgba(0,0,0,.35)';ctx.lineWidth=4.2*u;ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(25*u,0);ctx.stroke();
    ctx.strokeStyle='#8a5a2b';ctx.lineWidth=2.6*u;ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(25*u,0);ctx.stroke();
    ctx.strokeStyle='rgba(235,190,130,.6)';ctx.lineWidth=.8*u;ctx.beginPath();ctx.moveTo(1*u,-.8*u);ctx.lineTo(24*u,-.8*u);ctx.stroke();
    wdot(-1.2*u,0,2.1*u,'#7a4a22');wol(1.2);
    ctx.fillStyle=wlg(-5*u,5*u,'#d9a05c','#a8672f');ctx.beginPath();ctx.ellipse(31*u,0,8.6*u,4.6*u,0,0,7);ctx.fill();wol(1.4);
    ctx.strokeStyle='rgba(90,50,20,.55)';ctx.lineWidth=1*u;ctx.beginPath();ctx.moveTo(24*u,0);ctx.lineTo(39*u,0);ctx.stroke();
    ctx.fillStyle='rgba(255,230,180,.45)';ctx.beginPath();ctx.ellipse(30*u,-2*u,5*u,.9*u,0,0,7);ctx.fill();
    ctx.restore();
  }
  ctx.restore();
}
/* on the body, under the face and arm: stripes, spots, scutes, scarves */
export function moB(T,S){
  const k=state.O.k,x=px,B=T+S*.8;
  ctx.save();rr(x,T,S,S*.8,10*u);ctx.clip();ctx.lineJoin='round';ctx.lineCap='round';
  if(k==='sundari'){
    ctx.fillStyle=wlg(T,B,'rgba(255,255,255,.12)','rgba(0,60,20,.26)');ctx.fillRect(x,T,S,S*.8);
    ctx.strokeStyle='rgba(30,100,40,.38)';ctx.lineWidth=1.2*u;ctx.beginPath();for(const[a,b]of[[.14,.3],[.3,.52],[.16,.62],[.44,.7]]){const cx=x+S*a,cy=T+S*b;ctx.moveTo(cx,cy);ctx.quadraticCurveTo(cx+2.6*u,cy-3*u,cx+5*u,cy-4.4*u);ctx.moveTo(cx+2.2*u,cy-1.8*u);ctx.lineTo(cx+2.6*u,cy-5*u)}ctx.stroke();
    ctx.fillStyle='#2e7d4f';ctx.fillRect(x-2*u,T+S*.64,S+4*u,3.2*u);ctx.fillStyle='rgba(255,255,255,.22)';ctx.fillRect(x-2*u,T+S*.64,S+4*u,1*u);
  }else if(k==='tiger'){
    ctx.fillStyle='rgba(255,246,226,.55)';ctx.beginPath();ctx.ellipse(x+S*.62,B+S*.04,S*.5,S*.2,0,0,7);ctx.fill();
    ctx.fillStyle='#3a2316';
    const st=(x0,len,lean)=>{ctx.beginPath();ctx.moveTo(x0-2.2*u,T-1*u);ctx.quadraticCurveTo(x0+lean*u,T+len*.55,x0+.4*u,T+len);ctx.quadraticCurveTo(x0+lean*u+2.6*u,T+len*.5,x0+2.2*u,T-1*u);ctx.closePath();ctx.fill()};
    st(x+S*.12,S*.62,-3);st(x+S*.3,S*.74,-2.4);st(x+S*.48,S*.5,-1.6);
    ctx.beginPath();ctx.moveTo(x-2*u,T+S*.46);ctx.quadraticCurveTo(x+S*.14,T+S*.48,x+S*.3,T+S*.64);ctx.quadraticCurveTo(x+S*.14,T+S*.6,x-2*u,T+S*.56);ctx.closePath();ctx.fill();
  }else if(k==='chital'){
    ctx.fillStyle='#efd8b2';ctx.beginPath();ctx.ellipse(x+S*.62,B+2*u,S*.36,S*.27,0,0,7);ctx.fill();
    ctx.fillStyle='rgba(255,250,236,.95)';
    [[.1,.2,1.7],[.3,.1,1.5],[.5,.2,1.6],[.22,.4,1.9],[.4,.5,1.6],[.07,.55,1.5],[.62,.6,1.7],[.28,.66,1.6],[.8,.64,1.4],[.93,.48,1.3],[.5,.74,1.3],[.16,.74,1.3],[.4,.3,1.2]].forEach(([a,b,r],i)=>{ctx.beginPath();ctx.ellipse(x+S*a,T+S*b,r*u*1.15,r*u*.85,i*.7,0,7);ctx.fill()});
  }else if(k==='crab'){
    ctx.fillStyle=wlg(T,B,'rgba(255,255,255,.14)','rgba(90,10,0,.3)');ctx.fillRect(x,T,S,S*.8);
    ctx.strokeStyle='rgba(120,20,8,.45)';ctx.lineWidth=1.3*u;ctx.beginPath();ctx.moveTo(x+S*.04,T+S*.34);ctx.quadraticCurveTo(x+S*.4,T+S*.06,x+S*.76,T+S*.3);ctx.moveTo(x+S*.1,T+S*.58);ctx.quadraticCurveTo(x+S*.4,T+S*.36,x+S*.7,T+S*.54);ctx.stroke();
    ctx.fillStyle=state.O.t;[[.14,.22],[.32,.16],[.5,.28],[.24,.44],[.42,.5],[.12,.66],[.34,.7],[.58,.68]].forEach(([a,b],i)=>{ctx.beginPath();ctx.arc(x+S*a,T+S*b,(1.2+(i%2)*.5)*u,0,7);ctx.fill()});
    ctx.fillStyle='rgba(255,226,140,.5)';ctx.fillRect(x-2*u,B-4*u,S+4*u,5*u);
  }else if(k==='mudskip'){
    ctx.fillStyle=wlg(T,B,'rgba(255,255,255,.12)','rgba(30,40,10,.3)');ctx.fillRect(x,T,S,S*.8);
    ctx.fillStyle='rgba(235,226,170,.5)';ctx.beginPath();ctx.ellipse(x+S*.6,B+1*u,S*.5,S*.2,0,0,7);ctx.fill();
    ctx.fillStyle='rgba(55,70,32,.55)';[[.12,.2,1.8],[.3,.12,1.5],[.2,.42,2],[.42,.36,1.6],[.08,.62,1.6],[.34,.6,1.8],[.5,.7,1.4],[.58,.14,1.3]].forEach(([a,b,r])=>{ctx.beginPath();ctx.arc(x+S*a,T+S*b,r*u,0,7);ctx.fill()});
    ctx.fillStyle='#7fd6e0';[[.18,.3],[.36,.26],[.26,.55],[.46,.5],[.14,.74]].forEach(([a,b])=>{ctx.beginPath();ctx.arc(x+S*a,T+S*b,.9*u,0,7);ctx.fill()});
    ctx.strokeStyle='rgba(40,50,20,.45)';ctx.lineWidth=1.2*u;ctx.beginPath();ctx.moveTo(x+S*.56,T+S*.28);ctx.quadraticCurveTo(x+S*.5,T+S*.42,x+S*.55,T+S*.56);ctx.stroke();
  }else if(k==='kingfisher'){
    ctx.fillStyle=wlg(T,B,'rgba(0,40,100,.3)','rgba(255,255,255,0)');ctx.fillRect(x,T,S,S*.8);
    ctx.fillStyle=state.O.t;ctx.beginPath();ctx.ellipse(x+S*.74,B+S*.02,S*.5,S*.36,0,0,7);ctx.fill();
    ctx.strokeStyle='rgba(190,80,10,.45)';ctx.lineWidth=1*u;ctx.beginPath();for(const[a,b]of[[.52,.6],[.7,.68],[.86,.58],[.62,.76]]){const cx=x+S*a,cy=T+S*b;ctx.moveTo(cx-2*u,cy-1*u);ctx.lineTo(cx,cy+1*u);ctx.lineTo(cx+2*u,cy-1*u)}ctx.stroke();
    ctx.fillStyle='#fffaf0';ctx.beginPath();ctx.ellipse(x+S*.9,T+S*.5,4.4*u,3*u,0,0,7);ctx.fill();
    ctx.strokeStyle='rgba(160,228,246,.7)';ctx.lineWidth=1*u;ctx.beginPath();ctx.moveTo(x+S*.1,T+S*.18);ctx.lineTo(x+S*.34,T+S*.14);ctx.moveTo(x+S*.08,T+S*.32);ctx.lineTo(x+S*.3,T+S*.3);ctx.moveTo(x+S*.1,T+S*.46);ctx.lineTo(x+S*.26,T+S*.46);ctx.stroke();
  }else if(k==='croc'){
    ctx.fillStyle=state.O.t;ctx.beginPath();ctx.ellipse(x+S*.64,B+2*u,S*.42,S*.22,0,0,7);ctx.fill();
    ctx.strokeStyle='rgba(30,60,25,.3)';ctx.lineWidth=1*u;ctx.beginPath();for(let q=0;q<5;q++){const cx=x+S*(.38+q*.1);ctx.moveTo(cx-2*u,B-1*u);ctx.quadraticCurveTo(cx,B+2.6*u,cx+2*u,B-1*u)}ctx.stroke();
    ctx.strokeStyle='rgba(30,60,25,.24)';ctx.beginPath();for(const[a,b]of[[.2,.46],[.34,.52],[.12,.6],[.28,.66]]){const cx=x+S*a,cy=T+S*b;ctx.moveTo(cx-2.4*u,cy-1.6*u);ctx.quadraticCurveTo(cx,cy+1.6*u,cx+2.4*u,cy-1.6*u)}ctx.stroke();
    for(let q=0;q<5;q++){const sx=x+S*(.08+q*.1),sy=T+2.4*u+(q%2)*1.4*u;ctx.fillStyle='#3a6430';ctx.beginPath();ctx.ellipse(sx,sy,3*u,2.4*u,0,0,7);ctx.fill();wol(1);ctx.fillStyle='rgba(205,235,150,.4)';ctx.beginPath();ctx.ellipse(sx-.8*u,sy-.8*u,1.2*u,.7*u,0,0,7);ctx.fill()}
    for(let q=0;q<3;q++){const sy=T+S*(.18+q*.13),sx=x+2*u+(q%2)*1.2*u;ctx.fillStyle='#3a6430';ctx.beginPath();ctx.ellipse(sx,sy,2.4*u,2*u,0,0,7);ctx.fill();wol(1)}
  }else if(k==='boatman'){
    const y0=T+S*.6,h=6.4*u;
    ctx.fillStyle='#d62839';ctx.fillRect(x-2*u,y0,S+4*u,h);
    ctx.fillStyle='rgba(120,10,25,.3)';for(let q=-1;q<8;q++)ctx.fillRect(x+q*5.4*u,q%2?y0:y0+h*.5,5.4*u,h*.5);
    ctx.strokeStyle='rgba(255,255,255,.88)';ctx.lineWidth=1*u;ctx.beginPath();for(let q=-1;q<8;q++){ctx.moveTo(x+q*5.4*u,y0);ctx.lineTo(x+q*5.4*u,y0+h)}ctx.moveTo(x-2*u,y0+h*.5);ctx.lineTo(x+S+2*u,y0+h*.5);ctx.stroke();
    ctx.fillStyle='rgba(255,255,255,.3)';ctx.fillRect(x-2*u,y0,S+4*u,1.2*u);ctx.fillStyle='rgba(0,0,0,.22)';ctx.fillRect(x-2*u,y0+h-1.4*u,S+4*u,1.4*u);
  }
  ctx.restore();
  rr(x,T,S,S*.8,10*u);wol(2);
}
/* in front of the body and face: seedling, ears, antlers, eye-stalks, beaks, snouts, hat */
export function moA(T,S){
  const k=state.O.k,x=px,d=wtl(),sw=Math.sin(t*7)*1.4*u,bl=t%3.4<.12;
  ctx.save();ctx.lineJoin='round';ctx.lineCap='round';
  if(k==='sundari'){
    const bx=x+S*.5,by=T+3*u,sg=Math.sin(t*2.2)*.09+d*.012;
    mgLf(bx,by-3*u,-2.25+sg*1.5,9*u,3.4*u,'#4fae4f','rgba(240,255,200,.5)');mgLf(bx,by-3*u,-.9+sg*1.5,10*u,3.6*u,'#8fcf5a','rgba(240,255,200,.5)');
    const pod=(ox,a,L)=>{ctx.save();ctx.translate(bx+ox*u,by);ctx.rotate(a+sg);
      ctx.fillStyle='#6fb04a';ctx.beginPath();ctx.moveTo(0,-L*u);ctx.quadraticCurveTo(3.6*u,-L*.5*u,2*u,-3*u);ctx.lineTo(-2*u,-3*u);ctx.quadraticCurveTo(-3.6*u,-L*.5*u,0,-L*u);ctx.closePath();ctx.fill();wol(1.3);
      ctx.strokeStyle='rgba(230,255,170,.55)';ctx.lineWidth=1*u;ctx.beginPath();ctx.moveTo(-1*u,-4.6*u);ctx.quadraticCurveTo(-1.8*u,-L*.5*u,-.3*u,-L*.86*u);ctx.stroke();
      ctx.fillStyle='#7a5230';rr(-2.8*u,-4.4*u,5.6*u,4.4*u,1.4*u);ctx.fill();wol(1.2);ctx.fillStyle='rgba(224,172,110,.55)';ctx.fillRect(-2*u,-3.8*u,1.2*u,3*u);ctx.restore()};
    pod(-3.6,-.2,16);pod(3.6,.24,14);
  }else if(k==='tiger'){
    const tw=Math.sin(t*3.1)*.5*u;
    for(const[ex,sg]of[[.2,1],[.64,-1]]){const ox=x+S*ex;wdot(ox,T+1*u+tw*sg,5*u,state.O.b);wol(1.4);wdot(ox+.4*u,T+1.8*u+tw*sg,2.7*u,'#f3a1b0')}
    ctx.fillStyle='#fff6e6';ctx.beginPath();ctx.ellipse(x+S*.92,T+S*.57,5.6*u,3.8*u,0,0,7);ctx.fill();wol(1.2);
    ctx.fillStyle='#e8788c';wtri(x+S-1.4*u,T+S*.43,x+S+3.4*u,T+S*.43,x+S+1*u,T+S*.5);ctx.fill();wol(1);
    ctx.strokeStyle='rgba(60,30,20,.6)';ctx.lineWidth=1*u;ctx.beginPath();ctx.moveTo(x+S+1*u,T+S*.5);ctx.lineTo(x+S+1*u,T+S*.56);ctx.stroke();
    for(let i=0;i<3;i++){const bx=x+S*(.7+i*.075),by=T+S*.62;ctx.fillStyle='#fffaf0';wtri(bx-2.4*u,by,bx+2.4*u,by,bx+(1.4+i*.8)*u,by+(6.4-i*.8)*u);ctx.fill();wol(1.1)}
  }else if(k==='chital'){
    const ant=(bx,sc,lean)=>{const by=T+2.5*u,P=()=>{ctx.beginPath();ctx.moveTo(bx,by);ctx.quadraticCurveTo(bx+lean*u*sc+sw*.4,by-9*u*sc,bx+(lean+5)*u*sc+sw,by-20*u*sc+d);
      ctx.moveTo(bx+.8*u*sc,by-5*u*sc);ctx.lineTo(bx+8*u*sc+sw*.4,by-8.5*u*sc+d*.4);
      ctx.moveTo(bx+(lean*.5+2.2)*u*sc,by-11.5*u*sc);ctx.lineTo(bx-3.6*u*sc+sw*.6,by-16*u*sc+d*.6);
      ctx.moveTo(bx+(lean+5)*u*sc+sw,by-20*u*sc+d);ctx.lineTo(bx+(lean+10.5)*u*sc+sw,by-23.5*u*sc+d)};
      P();ctx.strokeStyle='#4a3220';ctx.lineWidth=4.4*u*sc;ctx.stroke();P();ctx.strokeStyle='#d6b07a';ctx.lineWidth=2.4*u*sc;ctx.stroke();P();ctx.strokeStyle='rgba(255,240,205,.65)';ctx.lineWidth=.9*u*sc;ctx.stroke()};
    ant(x+S*.26,.9,1.5);ant(x+S*.56,1,1.5);
    ctx.fillStyle='#f0d2a8';ctx.beginPath();ctx.ellipse(x+S*.94,T+S*.56,5.2*u,3.8*u,0,0,7);ctx.fill();wol(1.2);
    ctx.fillStyle='#3a2a20';ctx.beginPath();ctx.ellipse(x+S+1.4*u,T+S*.5,2.6*u,2*u,0,0,7);ctx.fill();wdot(x+S+.6*u,T+S*.5-.8*u,.7*u,'rgba(255,255,255,.75)');
  }else if(k==='crab'){
    [[.46,-.12,10],[.8,.14,11]].forEach(([a,lean,h],i)=>{const sx=x+S*a,sy=T+2*u,ex=sx+lean*h*u+sw*.3,ey=T-h*u+Math.sin(t*3+i*2)*.7*u,cxs=sx+lean*4*u,cys=sy-h*.5*u;
      BST('rgba(0,0,0,.35)',4,sx,sy,cxs,cys,ex,ey+2*u);BST(state.O.b,2.6,sx,sy,cxs,cys,ex,ey+2*u);
      wdot(ex,ey,3.8*u,'#fff');wol(1.3);wdot(ex+.9*u,ey+.3*u,1.9*u,'#10152e');wdot(ex+.3*u,ey-.8*u,.7*u,'#fff')});
    const ox=Math.sin(t*6)*1.4*u,oy=Math.cos(t*6)*1.8*u+d,cx2=x+S+6*u+ox,cy2=T+S*.56+oy;
    BST('#b83a22',2.2,x+S*.88,T+S*.78,x+S+4*u,T+S*.84,x+S+8*u,T+S*.98);
    BST('rgba(0,0,0,.35)',4.8,x+S*.84,T+S*.74,x+S+3*u,T+S*.9+oy*.3,cx2-2*u,cy2+3*u);BST('#c9452c',3.2,x+S*.84,T+S*.74,x+S+3*u,T+S*.9+oy*.3,cx2-2*u,cy2+3*u);
    moClaw(cx2,cy2,1,-.5,.3+.3*Math.sin(t*5),state.O.b);
  }else if(k==='mudskip'){
    for(const[ex,sg]of[[.5,0],[.8,1.4]]){const ox=x+S*ex,oy=T-1.2*u;
      wdot(ox,oy,5.6*u,state.O.b);wol(1.4);wdot(ox,oy+1*u,3.4*u,'rgba(0,0,0,.14)');
      wdot(ox,oy-.4*u,4.2*u,'#fff3b0');wol(1.1);wdot(ox+Math.sin(t*2+sg)*.6*u+.5*u,oy,2*u,'#10152e');wdot(ox-.9*u,oy-1.8*u,.9*u,'#fff')}
    if(!bl){wdot(x+S*.68,T+S*.38,3.5*u,'#ffe08a');wdot(x+S*.7,T+S*.39,1.9*u,'#10152e');wdot(x+S*.72,T+S*.33,1.1*u,'#fff')}
    ctx.strokeStyle='rgba(40,50,20,.55)';ctx.lineWidth=1.1*u;ctx.beginPath();ctx.moveTo(x+S*.8,T+S*.62);ctx.lineTo(x+S+3*u,T+S*.62);ctx.stroke();
  }else if(k==='kingfisher'){
    const cw=Math.sin(t*5)*.8*u+d*.3;
    for(const[a,h,c]of[[.28,11,state.O.b],[.4,14,'#1f86b8'],[.52,10,state.O.b]]){const bx=x+S*a;ctx.fillStyle=c;wtri(bx-3*u,T+2*u,bx-6*u+cw,T-h*u+d*.3,bx+2.4*u,T+2*u);ctx.fill();wol(1.2)}
    ctx.strokeStyle='rgba(165,228,246,.7)';ctx.lineWidth=.9*u;ctx.beginPath();ctx.moveTo(x+S*.4-1*u,T);ctx.lineTo(x+S*.4-4.4*u+cw,T-14*u+d*.3);ctx.stroke();
    const bx=x+S*.82,bt=T+S*.37,bb=T+S*.5,bm=T+S*.62;
    ctx.fillStyle='#1d2a3a';ctx.beginPath();ctx.moveTo(bx,bt);ctx.lineTo(x+S+18*u,bb-.4*u);ctx.lineTo(bx,bb);ctx.closePath();ctx.fill();wol(1.3);
    ctx.fillStyle='#ff8a3d';ctx.beginPath();ctx.moveTo(bx,bb);ctx.lineTo(x+S+16.6*u,bb);ctx.lineTo(bx,bm);ctx.closePath();ctx.fill();wol(1.3);
    ctx.strokeStyle='rgba(255,255,255,.4)';ctx.lineWidth=1*u;ctx.beginPath();ctx.moveTo(bx+2*u,bt+1.6*u);ctx.lineTo(x+S+13*u,bb-1.2*u);ctx.stroke();
    wdot(bx+4*u,bt+2.2*u,.7*u,'#fff');
  }else if(k==='croc'){
    const ex=x+S*.68,ey=T+S*.38;
    ctx.fillStyle='#4f7a3b';ctx.beginPath();ctx.ellipse(ex,T+S*.25,6.2*u,2.4*u,-.05,0,7);ctx.fill();wol(1.2);
    ctx.fillStyle=wlg(T+S*.28,T+S*.54,'#6a9a52','#4f7a3b');ctx.beginPath();ctx.moveTo(x+S*.8,T+S*.32);ctx.quadraticCurveTo(x+S+6*u,T+S*.3,x+S+19*u,T+S*.42);ctx.lineTo(x+S+19*u,T+S*.52);ctx.lineTo(x+S*.8,T+S*.52);ctx.closePath();ctx.fill();wol(1.4);
    ctx.fillStyle='#4f7a3b';ctx.beginPath();ctx.ellipse(x+S+15.4*u,T+S*.4,2.6*u,1.7*u,0,0,7);ctx.fill();wol(1);wdot(x+S+15.6*u,T+S*.4,.7*u,'#10152e');
    const jb=Math.sin(t*2.4)*.5*u;
    ctx.fillStyle=state.O.t;ctx.beginPath();ctx.moveTo(x+S*.8,T+S*.52);ctx.lineTo(x+S+18*u,T+S*.52);ctx.quadraticCurveTo(x+S+10*u,T+S*.66+jb,x+S*.8,T+S*.64+jb);ctx.closePath();ctx.fill();wol(1.3);
    ctx.strokeStyle='rgba(30,50,20,.7)';ctx.lineWidth=1.1*u;ctx.beginPath();ctx.moveTo(x+S*.8,T+S*.52);ctx.lineTo(x+S+18*u,T+S*.52);ctx.stroke();
    ctx.fillStyle='#fff';for(let i=0;i<4;i++){const tx=x+S+(1+i*4.6)*u,ty=T+S*.52;wtri(tx-1.2*u,ty,tx+1.2*u,ty,tx,ty+2.8*u);ctx.fill()}
    for(let i=0;i<3;i++){const tx=x+S+(3.2+i*4.6)*u,ty=T+S*.52;wtri(tx-1*u,ty+.4*u,tx+1*u,ty+.4*u,tx,ty-2.2*u);ctx.fill()}
    if(!bl){ctx.fillStyle='#10152e';ctx.beginPath();ctx.ellipse(ex,ey,.95*u,3.6*u,0,0,7);ctx.fill();wdot(ex+1.1*u,T+S*.31,.8*u,'#fff')}
  }else if(k==='boatman'){
    moGam(T+S*.6,26*u,6.4*u);
    const cx=x+S*.46,rx=S*.64,by=T+3*u,ay=T-15*u,ry=4.8*u;
    const H=()=>{ctx.beginPath();ctx.moveTo(cx,ay);ctx.quadraticCurveTo(cx-rx*.45,by-9*u,cx-rx,by);ctx.ellipse(cx,by,rx,ry,0,Math.PI,0,true);ctx.quadraticCurveTo(cx+rx*.45,by-9*u,cx,ay);ctx.closePath()};
    const g=ctx.createLinearGradient(cx-rx,0,cx+rx,0);g.addColorStop(0,'#f0cf82');g.addColorStop(.55,'#d9a94c');g.addColorStop(1,'#b07f30');
    H();ctx.fillStyle=g;ctx.fill();
    ctx.save();H();ctx.clip();
    ctx.strokeStyle='rgba(120,80,20,.5)';ctx.lineWidth=.9*u;ctx.beginPath();for(let q=-4;q<=4;q++){ctx.moveTo(cx,ay);ctx.lineTo(cx+q*rx*.25,by+ry)}ctx.stroke();
    ctx.beginPath();for(const r of[.32,.58,.82]){ctx.moveTo(cx+rx*r,ay+(by-ay)*r);ctx.ellipse(cx,ay+(by-ay)*r,rx*r,ry*r,0,0,Math.PI)}ctx.stroke();
    ctx.fillStyle='rgba(255,240,190,.4)';ctx.beginPath();ctx.ellipse(cx-rx*.28,by-6*u,1.6*u,6.4*u,.5,0,7);ctx.fill();
    ctx.restore();
    H();wol(1.5);
    ctx.strokeStyle='#8a5f20';ctx.lineWidth=1.5*u;ctx.beginPath();ctx.ellipse(cx,by,rx,ry,0,.08,Math.PI-.08);ctx.stroke();
    BST('#5a2a10',1.3,x+S*.98,by+2*u,x+S*.98,T+S*.5,x+S*.86,T+S*.78);wdot(x+S*.86,T+S*.78,1.3*u,'#5a2a10');
  }
  ctx.restore();
}
