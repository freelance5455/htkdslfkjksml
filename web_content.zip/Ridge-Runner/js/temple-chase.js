/*
 * temple-chase.js - Mangrove Temple chase: the boulder that rolls after the runner down the staircase and through the deep hall,
 * the stone gate that drops at the lift and stops it, and the hall traps (trapdoor, bamboo spikes, naga fire-pot, falling slab).
 * Simulation only; drawing lives in temple-boulder-art.js and temple-trap-art.js. State: state.tc (chase) and state.tt (traps).
 * The boulder is scenery with menace: it never hurts the runner. Only the traps can.
 */
import { snd, tpSn } from './audio.js';
import { shBreak } from './boosters.js';
import { t } from './clock.js';
import { die } from './game.js';
import { TP } from './jungle-temple.js';
import { rh, ter } from './physics.js';
import { lose } from './rides.js';
import { state } from './state.js';
import { hallCy } from './temple-geo.js';
import { SLAB_H, SPK_H } from './temple-trap-art.js';
import { G, px, u, W } from './view.js';

const rnd=(a,b)=>a+Math.random()*(b-a);
const KB=40;                                   // boulder is released this far (k units) into the staircase
const HALL0=TP.S1+380,HALL1=TP.KC-TP.CH-330;   // k range where hall traps may appear
const GATE_K=TP.KC-TP.CH-50,GATE_W=46;         // stone gate just short of the lift shaft
const BOULDER_R=88;

function newChase(){
  const R=BOULDER_R*u,g=600*u;
  return{ph:'roll',t:0,g,bv:0,fw:state.dist+px-g,by:0,fy:0,ang:0,R,sg:0,sc:5,sk:0,kv:0,
    gx:(state.tpU+GATE_K)*u,gw:GATE_W*u,gy:0,ga:0,gt:0,gcr:0,fl2:0,tg:0,tw:false,
    dust:[],peb:[],fl:[],ch:[],ds:0,ps:0,fs:0,sn:0};
}

/** Camera shake {x,y} in px for the current frame: a low rumble while the boulder is close, a burst when it hits the gate. */
export function tcShake(){
  const c=state.tc;if(!c||state.st!=='play')return{x:0,y:0};
  const a=(c.ph==='roll'?(.5+1.7*c.kv)*u*Math.min(1,c.t/1.2):0)+c.sk;
  return{x:Math.sin(t*61)*a*.8+Math.sin(t*37+1)*a*.5,y:Math.sin(t*53+2)*a*.7};
}

function crash(c){
  c.ph='crash';c.sk=4.8*u;c.gcr=1;c.fl2=1;c.gy=c.by;
  const R=c.R,cx=c.fw-R;
  for(let i=0;i<16;i++){
    const big=i<3,a=rnd(0,6.28),d=rnd(0,.8)*R;
    c.ch.push({x:cx+Math.cos(a)*d*.8,y:c.by+Math.sin(a)*d,vx:-rnd(30,260)*u,vy:-rnd(60,420)*u,r:(big?rnd(20,30):rnd(7,16))*u,rot:rnd(0,6.28),vr:rnd(-6,6),sd:Math.random()*90,rest:0});
  }
  for(let i=0;i<14;i++)c.dust.push({x:c.gx-rnd(0,R*1.6),y:c.by+rnd(-R,R*.9),vx:rnd(-90,40)*u,vy:-rnd(0,50)*u,r:rnd(18,40)*u,a:.62,l:1,dl:rnd(.5,.9)});
  tpSn('settle');tpSn('creak');
}

function stepBoulder(c,dt,kp){
  const R=c.R,wpx=state.dist+px;
  c.t+=dt;c.sk*=Math.exp(-5*dt);c.fl2=Math.max(0,c.fl2-dt*5);
  if(c.ph==='roll'){
    if(c.ga===2){ /* gate is down: the last stretch, straight into it */
      c.bv=Math.max(c.bv,260*u);c.fw+=c.bv*dt;
      if(c.fw>=c.gx-1){c.fw=c.gx-1;crash(c)}
    }else{
      let gt=(18+10*Math.sin(c.t*.9)+5*Math.sin(c.t*2.3))*u;
      c.sc-=dt;
      if(c.sg>0){c.sg-=dt;gt=4*u}else if(c.sc<=0){c.sg=1.1;c.sc=rnd(4.5,8)}
      if(kp>TP.KC-430)gt=Math.max(gt,64*u);   // hang back so the gate can drop first
      const g0=c.g;c.g+=(gt-c.g)*Math.min(1,dt*(c.t<2.8?1.25:3.2));
      c.bv=state.speed-(c.g-g0)/Math.max(dt,1e-3);
      c.fw=Math.min(wpx-c.g,c.gx-3*u);
    }
    c.ang+=c.bv*dt/R;
    const sxc=c.fw-R-state.dist,kb=(c.fw-R)/u-state.tpU,stairs=kb>TP.S0-40&&kb<TP.S1+40;
    c.fy=G+(ter(sxc-R*.55)+ter(sxc)+ter(sxc+R*.55))/3;
    c.by=c.fy-R-(stairs?Math.abs(Math.sin((c.fw-R)/(TP.SW*u)*Math.PI))*5*u:0)+Math.sin(c.t*43)*1.1*u;
    const cl=Math.max(0,1-(c.g-4*u)/(80*u))*Math.min(1,c.t/1.6);c.kv=cl;
    /* kicked-up dust, hopping pebbles, flecks shaken from the roof, a thump now and then */
    c.ds-=dt;if(c.ds<=0&&c.dust.length<70){c.ds=.035;c.dust.push({x:c.fw-R*rnd(.1,1.7),y:c.fy-rnd(1,8)*u,vx:rnd(-30,10)*u,vy:-rnd(10,50)*u,r:rnd(7,15)*u,a:.5,l:1,dl:rnd(.6,1.1)})}
    c.ps-=dt;if(c.ps<=0&&c.peb.length<14){c.ps=rnd(.16,.4);const r=rnd(2.4,5)*u;c.peb.push({x:c.fw+rnd(-R*.6,R*.15),y:c.fy-4*u,vx:rnd(-60,160)*u,vy:-rnd(160,340)*u,r,r0:r,rot:0,vr:rnd(-9,9),sd:Math.random()*50,l:1.3})}
    c.fs-=dt;if(c.fs<=0&&c.fl.length<40&&c.t>.8){c.fs=1/(3+14*cl);const x=state.dist+rnd(0,W);c.fl.push({x,y:hallCy(x-state.dist)+2*u,vy:0,s:rnd(1.2,2.4),l:1})}
    c.sn-=dt;if(c.sn<=0&&c.t>1.2){c.sn=.62-.2*cl;tpSn('settle')}
  }
  for(const d of c.dust){d.x+=d.vx*dt;d.y+=d.vy*dt;d.r+=14*u*dt;d.l-=dt*(d.dl||1)}
  c.dust=c.dust.filter(d=>d.l>0);
  for(const p of c.peb){
    p.vy+=1500*u*dt;p.x+=p.vx*dt;p.y+=p.vy*dt;p.rot+=p.vr*dt;p.l-=dt;p.r=p.r0*Math.min(1,p.l*3);
    const fl=G+ter(p.x-state.dist)-p.r*.4;if(p.y>fl){p.y=fl;p.vy=-p.vy*.4;p.vx*=.7}
  }
  c.peb=c.peb.filter(p=>p.l>0);
  for(const f of c.fl){f.vy+=800*u*dt;f.y+=f.vy*dt;f.l-=dt/1.3}
  c.fl=c.fl.filter(f=>f.l>0);
  for(const k of c.ch){
    if(k.rest)continue;
    k.vy+=1500*u*dt;k.x+=k.vx*dt;k.y+=k.vy*dt;k.rot+=k.vr*dt;
    const fl=G+ter(k.x-state.dist)-k.r*.55;
    if(k.y>fl){k.y=fl;if(Math.abs(k.vy)>70*u){k.vy=-k.vy*.32;k.vx*=.65;k.vr*=.6}else{k.vy=0;k.vx*=.8;k.vr*=.7;if(Math.abs(k.vx)<12*u)k.rest=1}}
    if(k.x+k.r>c.gx){k.x=c.gx-k.r;k.vx=-Math.abs(k.vx)*.4}
  }
}

function spawnTrap(c,xs,wx){
  const prev=state.tt.length?state.tt[state.tt.length-1].k:'';
  let kd='door';
  if(state.tt.length){do{const q=Math.random();kd=q<.34?'door':q<.6?'spike':q<.82?'flame':'slab'}while(kd===prev&&Math.random()<.8)}
  const w=(kd==='door'?rnd(84,104):kd==='spike'?rnd(90,112):kd==='flame'?46:58)*u;
  state.tt.push({k:kd,x:wx,w,ph:0,pt:0,a:kd==='flame'?.12:0,n:false,s:Math.random()*200});
  c.tg=state.speed*(.95+Math.random()*.75)+w+60*u;
  if(!c.tw){c.tw=true;state.pops.push({x:W*.5,y:G*.42+state.tpCamY,a:2,t:'Watch the floor!'})}
  if(!state.adv&&Math.random()<.8){const h0={door:0,spike:SPK_H,flame:70,slab:SLAB_H}[kd]*u;for(let i=0;i<4;i++)state.coins.push({x:xs+w/2+(i-1.5)*34*u,h:h0+28*u+22*u*Math.sin(Math.PI*i/3)})}
}

/** Each trap wakes up when the runner is a fixed reaction time away (so the warning is the same at every speed). */
function stepTraps(c,dt){
  const sp=state.speed,rc=px+17*u,lo=state.tt[state.tt.length-1],xs=Math.max(W+20,rc+sp*1.7),wx=state.dist+xs,k=wx/u-state.tpU;
  if(k>=HALL0&&k<=HALL1&&(!lo||lo.x+lo.w-state.dist<xs-c.tg))spawnTrap(c,xs,wx);
  for(const r of state.tt){
    r.pt+=dt;
    const ds=r.x-state.dist-rc;
    if(r.k==='door'){
      if(r.ph===0&&ds<sp*.95+60*u){r.ph=1;r.pt=0;tpSn('creak')}
      else if(r.ph===1&&r.pt>.28){r.ph=2;r.pt=0}
    }else if(r.k==='spike'){
      if(r.n)r.a=Math.max(0,r.a-dt*4);
      else if(r.ph===0&&ds<sp*.8+50*u){r.ph=1;r.pt=0;tpSn('creak')}
      else if(r.ph===1){r.a=.18*Math.min(1,r.pt/.3);if(r.pt>.3){r.ph=2;r.pt=0}}
      else if(r.ph===2)r.a=Math.min(1,.18+.82*r.pt/.12);
    }else if(r.k==='flame'){
      if(r.n&&r.ph<3){r.ph=3;r.pt=0;r.a0=r.a}
      if(r.ph===0&&ds<sp*.9+60*u){r.ph=1;r.pt=0}
      else if(r.ph===1){r.a=.12+.23*Math.min(1,r.pt/.35);if(r.pt>.35){r.ph=2;r.pt=0}}
      else if(r.ph===2){r.a=Math.min(1,.35+.65*r.pt/.12);if(r.pt>1.5){r.ph=3;r.pt=0;r.a0=r.a}}
      else if(r.ph===3){r.a=r.a0-(r.a0-.12)*Math.min(1,r.pt/.5);if(r.pt>.5){r.ph=4;r.a=.12}}
    }else{ /* slab */
      if(r.n)continue;
      if(r.ph===0&&ds<sp*1.07+60*u){r.ph=1;r.pt=0;tpSn('creak')}
      else if(r.ph===1&&r.pt>.45){r.ph=2;r.pt=0}
      else if(r.ph===2&&r.pt>.2){r.ph=3;r.pt=0;c.sk=Math.max(c.sk,2.2*u);tpSn('settle')}
    }
  }
  state.tt=state.tt.filter(r=>r.x+r.w-state.dist>-160*u);
}

/** Per-frame step; runs after the world has scrolled, before pick-ups and hits. */
export function stepTemple(dt){
  if(!state.tpOn){if(state.tc||state.tt.length){state.tc=null;state.tt=[]}return}
  const kp=(px+17*u+state.dist)/u-state.tpU;
  let c=state.tc;
  if(!c){
    if(kp<TP.S0+KB||kp>TP.KC)return;
    c=state.tc=newChase();state.pops.push({x:W*.5,y:G*.4,a:2.2,t:'The boulder is loose! Run!'});
  }
  stepBoulder(c,dt,kp);
  if(c.ph==='roll'&&c.ga===0&&state.dist+px+6*u>c.gx+c.gw+8*u){c.ga=1;c.gt=0;tpSn('creak')}
  if(c.ga===1){c.gt+=dt;if(c.gt>=.22){c.ga=2;c.gt=0;c.sk=Math.max(c.sk,2.4*u);tpSn('settle')}}
  stepTraps(c,dt);
}

/** Trap hits, same rules as hitObstacles: ghost / flight / admin invincibility pass; a ride or shield takes the blow; otherwise the run ends. */
export function hitTemple(fl){
  if(state.st!=='play'||state.inv||fl||state.fx.ghost>0||!state.tt.length)return;
  const RH=rh(),ex=state.rd&&!state.ob?14*u:0,a=px+6*u-ex,c=px+28*u+ex,mid=px+17*u,b0=state.y+6*u,b1=state.y+28*u+RH;
  for(const r of state.tt){
    if(r.n)continue;
    const x=r.x-state.dist;if(x>c+8*u||x+r.w<a-8*u)continue;
    let hit=false,pit=false;
    if(r.k==='door'){pit=true;hit=state.y<=4*u&&mid>x+6*u&&mid<x+r.w-6*u}
    else if(r.k==='spike')hit=r.ph===2&&r.a>.5&&c>x+4*u&&a<x+r.w-4*u&&b0<r.a*SPK_H*u-3*u;
    else if(r.k==='flame'){
      const cx=x+r.w/2;
      hit=(c>x+3*u&&a<x+r.w-3*u&&b0<27*u)||(r.ph===2&&r.a>.55&&c>cx-10*u&&a<cx+10*u&&b0<38*u+(7+r.a*r.a*SPK_H)*u*.85);
    }else if(r.ph>=2&&c>x+3*u&&a<x+r.w-3*u){
      const f=Math.min(1,r.pt/.2);
      hit=r.ph===3?b0<SLAB_H*u-3*u:b1>370*u*(1-f*f);
    }
    if(!hit)continue;
    if(state.rd||state.fx.shield){
      if(state.rd)lose();else{state.fx.shield=0;shBreak();state.pops.push({x:px+20*u,y:G+ter(px+17*u)-state.y-50*u,a:1.2,t:'Shield broke',c:'#7dffa8'})}
      if(pit){state.vy=860*u;state.y=1;state.jumps=1;state.air=0;state.cut=true}
      r.n=true;snd('b');
    }else die();
    break;
  }
}
