/*
 * biomes.js - Biome palettes (Mountain / Snow / Mangrove) and the colour / ground blending between them.
 */
import { h2 } from './draw-utils.js';
import { state } from './state.js';
import { u } from './view.js';

export const PM={sky:['#2a6db0','#6fb1de','#cfe6ee','#f3dfb8'],m0:'#8fb3d1',m1:'#5f8fa6',h0:'#86ad7c',h1:'#5f9261',pn:'#2d6a4f'};
export const PS={sky:['#4a76ad','#9dbfe0','#dce9f5','#f3f0ee'],m0:'#c5d8ec',m1:'#95b2cf',h0:'#e3ecf6',h1:'#c3d4e6',pn:'#2e5b57'};
const MG={d0:'#6b5a45',d1:'#3d3228',st:'rgba(30,20,12,',gr:'#4f9a56',gl:'#8ad083',dE:'rgba(40,30,22,.45)',tf:'#6fb36f',b1:'#5aa65f',b2:'#7bc47f',fl:['#ffe066','#ff8fa3','#ffffff','#b69cff']};
export const SG={d0:'#e4edf7',d1:'#7d96ba',st:'rgba(40,64,110,',gr:'#f4f8fd',gl:'#ffffff',dE:'rgba(255,255,255,.6)',tf:'#dbe8f6',b1:'#9fb6cd',b2:'#c5d5e5',fl:['#ffffff','#bfe9ff','#ffffff','#dff3ff']};
/* ---- Mangrove Forest biome: murky sky, stilt-root trees, root road, open sea and the cruise ship ---- */
export const PG={sky:['#1f5560','#438f7c','#a3c48a','#ecdca0']};
export const MV={d0:'#6b5a3c',d1:'#262a1c'};
export const GP=[MG,SG,MV];
export const l3=(a,b,c,al)=>{const A=h2(a),B=h2(b),C=h2(c),m=1-state.bw-state.bm,r=A.map((v,i)=>Math.round(v*m+B[i]*state.bw+C[i]*state.bm)).join();return al==null?'rgb('+r+')':'rgba('+r+','+al+')'};
export const gm=w=>{if(!state.tr)return state.bi===2?1:0;const s=Math.max(0,Math.min(1,(w-state.tr.re)/(240*u)));return state.tr.to===2?s:state.tr.from===2?1-s:0};
