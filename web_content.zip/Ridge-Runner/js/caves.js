/*
 * caves.js - Caves: the normal cave, the ice cave and the cave mouths.
 */
import { t } from './clock.js';
import { bgH, BOV, BPG, BSP, BST, obCry, par, rr, wdot } from './draw-utils.js';
import { ter } from './physics.js';
import { state } from './state.js';
import { ctx, G, H, px, u, W } from './view.js';

const CM={bg:['#0a0807','#2a211a','#120e0b'],f1:'rgba(50,40,32,.4)',f2:'rgba(80,64,50,.32)',ce:['#050403','#1a1410'],fl:['#5a4a3e','#15100c'],fe:'#7a6858',fog:'rgba(150,160,170,',lt:'255,226,160',mt:'255,230,150'};
const CG={bg:['#031222','#0d3a5e','#061a2e'],f1:'rgba(40,120,170,.38)',f2:'rgba(120,200,240,.26)',ce:['#04182b','#1a5f8d'],fl:['#d8f1ff','#4f90c0','#0a2742'],fe:'#effaff',fog:'rgba(150,215,255,',lt:'170,235,255',mt:'210,245,255'};
function mouth(x,s){cvMouth(x,s)}
export function cave2(){cvMain()}
/* ---- Hand-drawn caves: normal cave, ice cave, cave mouths ---- */
export function cvTorch(sx,ty,i){
  const f2=Math.sin(t*13+i)*2*u,sw=Math.sin(t*9+i)*1.2*u;
  const g2=ctx.createRadialGradient(sx,ty,2*u,sx,ty,150*u);g2.addColorStop(0,'rgba(255,175,80,.6)');g2.addColorStop(1,'rgba(255,150,60,0)');ctx.fillStyle=g2;ctx.beginPath();ctx.arc(sx,ty,150*u,0,7);ctx.fill();
  ctx.fillStyle='#2b2018';rr(sx-7*u,ty+19*u,14*u,5*u,2*u);ctx.fill();ctx.strokeStyle='rgba(0,0,0,.6)';ctx.lineWidth=1.4*u;ctx.stroke();wdot(sx-4*u,ty+21.5*u,.9*u,'#c9a566');wdot(sx+4*u,ty+21.5*u,.9*u,'#c9a566');
  ctx.fillStyle='#4a3826';rr(sx-2.2*u,ty+6*u,4.4*u,17*u,1.6*u);ctx.fill();ctx.stroke();ctx.strokeStyle='rgba(255,200,130,.35)';ctx.lineWidth=.9*u;ctx.beginPath();ctx.moveTo(sx+1*u,ty+8*u);ctx.lineTo(sx+1*u,ty+21*u);ctx.stroke();
  ctx.strokeStyle='#c9a566';ctx.lineWidth=1.4*u;ctx.beginPath();for(const yy of[10,14.5]){ctx.moveTo(sx-2.3*u,ty+(yy+1)*u);ctx.lineTo(sx+2.3*u,ty+(yy-.6)*u)}ctx.stroke();
  BPG('#2b2018',sx-6.4*u,ty+4.6*u,sx+6.4*u,ty+4.6*u,sx+4.2*u,ty+10*u,sx-4.2*u,ty+10*u);ctx.strokeStyle='rgba(255,190,110,.5)';ctx.lineWidth=1*u;ctx.beginPath();ctx.moveTo(sx-6*u,ty+4.8*u);ctx.lineTo(sx+6*u,ty+4.8*u);ctx.stroke();
  const fl=(k,c,o)=>{ctx.fillStyle=c;ctx.beginPath();ctx.moveTo(sx+sw*k*.6,ty+(5-16*k)*u-f2*k);ctx.quadraticCurveTo(sx+6*k*u,ty+(5-8*k)*u,sx+3.6*k*u,ty+5*u);ctx.quadraticCurveTo(sx,ty+(5+3*k)*u,sx-3.6*k*u,ty+5*u);ctx.quadraticCurveTo(sx-6*k*u,ty+(5-8*k)*u,sx+sw*k*.6,ty+(5-16*k)*u-f2*k);ctx.fill();if(o){ctx.strokeStyle='rgba(120,30,0,.5)';ctx.lineWidth=1.2*u;ctx.stroke()}};
  fl(1,'#ff7a1a',1);fl(.66,'#ffd27a',0);fl(.3,'#fff3c4',0);
  for(let q=0;q<3;q++){const ph=(t*1.2+q*.33+i*.17)%1,ex=sx+Math.sin(ph*6+q)*6*u,ey=ty-8*u-ph*42*u;if(q)ctx.fillStyle='rgba(255,200,100,'+(1-ph).toFixed(2)+')',ctx.beginPath(),ctx.arc(ex,ey,1.7*(1-ph)*u,0,7),ctx.fill();else BSP(ex,ey,2.8*(1-ph)*u,'rgba(255,225,140,'+(1-ph).toFixed(2)+')')}
}
function cvCrystals(sx,ty,i){
  const pu=.6+.4*Math.sin(t*2+i),vi=state.cT&&((i>>1)&1),cl=vi?'170,140,255':'110,220,255',rg=(state.cT?120:90)*u;
  const g3=ctx.createRadialGradient(sx,ty,2*u,sx,ty,rg);g3.addColorStop(0,'rgba('+cl+','+((state.cT?.4:.3)*pu).toFixed(2)+')');g3.addColorStop(1,'rgba('+cl+',0)');ctx.fillStyle=g3;ctx.beginPath();ctx.arc(sx,ty,rg,0,7);ctx.fill();
  const n=state.cT?5:3,col=vi?'#b9a4ff':'#8be8ff';
  ctx.fillStyle=state.cT?'#1d4a6e':'#2b2320';ctx.beginPath();ctx.ellipse(sx,ty+10*u,(n*5+5)*u,5*u,0,0,7);ctx.fill();ctx.strokeStyle='rgba(0,0,0,.5)';ctx.lineWidth=1.5*u;ctx.stroke();
  ctx.fillStyle='rgba(255,255,255,.12)';ctx.beginPath();ctx.ellipse(sx-4*u,ty+8*u,n*3*u,1.8*u,0,0,7);ctx.fill();
  let tip=0;for(let q=0;q<n;q++){const cx=sx+(q-(n-1)/2)*9*u,hh=(14-q%2*6+(state.cT&&q===2?10:0))*(state.cT?1.4:1)*u;obCry(cx-5*u,cx+5*u,cx,ty-hh,ty+10*u,col);if(hh>tip)tip=hh}
  BSP(sx,ty-tip-3*u,(1+2*pu)*u,'rgba(255,255,255,.9)');
}
function cvStal(sx,cy,tp,hw,i){
  const lit=state.cT?'#e6f8ff':'#4a3a2c',dk=state.cT?'#7fc4ea':'#1a1410',mid=(cy+tp)/2;
  ctx.beginPath();ctx.moveTo(sx-hw,cy-2);ctx.quadraticCurveTo(sx-hw*.55,mid,sx,tp);ctx.quadraticCurveTo(sx+hw*.6,mid,sx+hw,cy-2);ctx.closePath();
  const g=ctx.createLinearGradient(sx-hw,0,sx+hw,0);g.addColorStop(0,dk);g.addColorStop(1,lit);ctx.fillStyle=g;ctx.fill();
  ctx.strokeStyle=state.cT?'rgba(10,60,110,.55)':'rgba(0,0,0,.6)';ctx.lineWidth=1.6*u;ctx.stroke();
  ctx.strokeStyle=state.cT?'rgba(255,255,255,.4)':'rgba(255,220,170,.16)';ctx.lineWidth=1.1*u;ctx.beginPath();for(let k=1;k<3;k++){const yy=cy+(tp-cy)*k*.3,w=hw*(1-k*.3)*.9;ctx.moveTo(sx-w,yy);ctx.quadraticCurveTo(sx,yy+2*u,sx+w,yy)}ctx.moveTo(sx+hw*.4,cy+3*u);ctx.lineTo(sx+hw*.1,tp-(tp-cy)*.25);ctx.stroke();
  if(state.cT){ctx.strokeStyle='rgba(20,90,150,.35)';ctx.beginPath();ctx.moveTo(sx,tp);ctx.lineTo(sx-hw*.1,cy);ctx.stroke();
    if(!(i&1)){const k=.5+.5*Math.sin(t*4+i);ctx.strokeStyle='rgba(255,255,255,'+k.toFixed(2)+')';ctx.lineWidth=1.4*u;ctx.beginPath();ctx.moveTo(sx-4*u,tp+2*u);ctx.lineTo(sx+4*u,tp+2*u);ctx.moveTo(sx,tp-2*u);ctx.lineTo(sx,tp+6*u);ctx.stroke()}}
  if(i%3===0){const ph=((t*.9+i*.37)%1+1)%1,dy=tp+ph*ph*(G-tp-70*u);ctx.fillStyle='rgba(170,225,255,'+(1-ph).toFixed(2)+')';ctx.beginPath();ctx.moveTo(sx,dy-3.4*u);ctx.quadraticCurveTo(sx+2.2*u,dy+.6*u,sx,dy+2*u);ctx.quadraticCurveTo(sx-2.2*u,dy+.6*u,sx,dy-3.4*u);ctx.fill()}
}
function cvMain(){
  if(state.st==='menu'||state.st==='ready')return;
  const eL=px+state.cs*10*u-state.dist,eR=px+state.ce*10*u-state.dist,L=Math.max(0,eL),R=Math.min(W,eR);
  if(R<=L)return;
  const C=state.cT?CG:CM,cy=H*.2;let g;
  ctx.save();ctx.beginPath();ctx.rect(L,0,R-L,H);ctx.clip();ctx.lineJoin='round';ctx.lineCap='round';
  g=ctx.createLinearGradient(0,0,0,H);g.addColorStop(0,C.bg[0]);g.addColorStop(.5,C.bg[1]);g.addColorStop(1,C.bg[2]);ctx.fillStyle=g;ctx.fillRect(L,0,R-L,H);
  for(let l=0;l<2;l++){const sp=(l?150:210)*u;par(sp,l?.5:.3,L,R,(sx,i)=>{
    const h=((i*53+l*17)%7+7)%7,yb=H*.8,a=[sx+sp*.15,H*(.35+h*.04)],c=[sx+sp*.33,H*(.37+h*.045)],b=[sx+sp*.55,H*(.3+h*.05)],d=[sx+sp*.75,H*(.42+h*.03)],sl=[sx+sp*.06,H*(.55+h*.02)];
    ctx.fillStyle=l?C.f2:C.f1;ctx.beginPath();ctx.moveTo(sx,yb);ctx.lineTo(sl[0],sl[1]);ctx.lineTo(a[0],a[1]);ctx.lineTo(c[0],c[1]);ctx.lineTo(b[0],b[1]);ctx.lineTo(d[0],d[1]);ctx.lineTo(sx+sp*.9,yb);ctx.closePath();ctx.fill();
    ctx.strokeStyle=state.cT?'rgba(170,225,255,'+(l?.2:.14)+')':'rgba(255,225,180,'+(l?.1:.07)+')';ctx.lineWidth=1.4*u;ctx.stroke();
    ctx.fillStyle='rgba(0,0,0,.16)';ctx.beginPath();ctx.moveTo(sx,yb);ctx.lineTo(sl[0],sl[1]);ctx.lineTo(a[0],a[1]);ctx.lineTo(c[0],c[1]);ctx.lineTo(b[0],b[1]);ctx.lineTo(b[0]-sp*.04,yb);ctx.closePath();ctx.fill()})}
  if(state.cT)par(300*u,.35,L,R,(sx,i)=>{const gg=ctx.createLinearGradient(sx,0,sx+90*u,0);gg.addColorStop(0,'rgba(190,240,255,0)');gg.addColorStop(.5,'rgba(190,240,255,'+(.07+.05*Math.sin(t*.8+i)).toFixed(3)+')');gg.addColorStop(1,'rgba(190,240,255,0)');ctx.fillStyle=gg;ctx.beginPath();ctx.moveTo(sx,0);ctx.lineTo(sx+90*u,0);ctx.lineTo(sx+30*u,H);ctx.lineTo(sx-60*u,H);ctx.fill()});
  else{
    for(let q=0;q<5;q++){const yy=H*(.3+q*.1);for(let p=0;p<2;p++){ctx.strokeStyle=p?'rgba(255,225,180,.07)':'rgba(120,95,70,.2)';ctx.lineWidth=(p?1:2)*u;ctx.beginPath();for(let x=L;x<=R+16;x+=16){const y2=yy+p*3*u+Math.sin((x+state.dist*.35)/(60*u)+q*1.7)*5*u;x===L?ctx.moveTo(x,y2):ctx.lineTo(x,y2)}ctx.stroke()}}
    par(260*u,.5,L,R,(sx,i)=>{const y0=H*(.3+((i%3+3)%3)*.12);ctx.strokeStyle='rgba(0,0,0,.38)';ctx.lineWidth=1.4*u;ctx.beginPath();ctx.moveTo(sx,y0);ctx.lineTo(sx+9*u,y0+16*u);ctx.lineTo(sx+3*u,y0+30*u);ctx.lineTo(sx+12*u,y0+48*u);ctx.moveTo(sx+9*u,y0+16*u);ctx.lineTo(sx+22*u,y0+24*u);ctx.stroke();if(i&1){const k=Math.max(0,Math.sin(t*2.4+i*1.3));BSP(sx+34*u,y0+40*u,(1+2*k)*u,'rgba(255,210,120,.85)')}});
  }
  par(420*u,.6,L,R,(sx,i)=>{if(i&1)return;const gg=ctx.createLinearGradient(0,cy,0,G);gg.addColorStop(0,'rgba('+C.lt+','+(.17+.05*Math.sin(t*.7+i)).toFixed(3)+')');gg.addColorStop(1,'rgba('+C.lt+',0)');ctx.fillStyle=gg;ctx.beginPath();ctx.moveTo(sx,cy);ctx.lineTo(sx+44*u,cy);ctx.lineTo(sx-70*u,G);ctx.lineTo(sx-150*u,G);ctx.fill()});
  par(230*u,.7,L,R,(sx,i)=>{const ty=H*.4+((i*17)%4+4)%4*20*u;if(!state.cT&&(i&1))cvTorch(sx,ty,i);else cvCrystals(sx,ty,i)});
  g=ctx.createLinearGradient(0,0,0,cy+30*u);g.addColorStop(0,C.ce[0]);g.addColorStop(1,C.ce[1]);ctx.fillStyle=g;ctx.fillRect(L,0,R-L,cy);
  {const sp9=18*u,i9=Math.floor((L+state.dist*.9)/sp9)-1,pts=[];for(let i=i9;i*sp9-state.dist*.9<R+sp9;i++)pts.push([i*sp9-state.dist*.9,cy+(1+bgH(i,31)*7)*u]);
    ctx.beginPath();ctx.moveTo(pts[0][0],cy-2);for(const p of pts)ctx.lineTo(p[0],p[1]);ctx.lineTo(pts[pts.length-1][0],cy-2);ctx.closePath();ctx.fillStyle=C.ce[1];ctx.fill();
    ctx.strokeStyle='rgba(0,0,0,.5)';ctx.lineWidth=2*u;ctx.beginPath();pts.forEach((p,k)=>k?ctx.lineTo(p[0],p[1]):ctx.moveTo(p[0],p[1]));ctx.stroke();
    ctx.strokeStyle=state.cT?'rgba(190,240,255,.4)':'rgba(190,150,110,.26)';ctx.lineWidth=1.2*u;ctx.beginPath();pts.forEach((p,k)=>k?ctx.lineTo(p[0],p[1]-2.4*u):ctx.moveTo(p[0],p[1]-2.4*u));ctx.stroke()}
  par(55*u,.6,L,R,(sx,i)=>{const tp=cy+(8+((i*41)%5+5)%5*9)*u;ctx.fillStyle=state.cT?'rgba(120,200,240,.35)':'rgba(40,32,26,.7)';ctx.beginPath();ctx.moveTo(sx-6*u,cy-2);ctx.quadraticCurveTo(sx-2*u,(cy+tp)/2,sx,tp);ctx.quadraticCurveTo(sx+2*u,(cy+tp)/2,sx+6*u,cy-2);ctx.closePath();ctx.fill();ctx.strokeStyle=state.cT?'rgba(190,240,255,.3)':'rgba(0,0,0,.4)';ctx.lineWidth=1.1*u;ctx.stroke()});
  par(80*u,.9,L,R,(sx,i)=>{const lg=((i*37)%5+5)%5;cvStal(sx,cy,cy+((state.cT?30:18)+lg*(state.cT?18:14))*u,(state.cT?8:11)*u,i)});
  ctx.beginPath();ctx.moveTo(L,H);for(let x=L;x<=R+8;x+=8)ctx.lineTo(x,G+ter(x));ctx.lineTo(R+8,H);ctx.closePath();
  g=ctx.createLinearGradient(0,G-60*u,0,H);C.fl.forEach((c,k)=>g.addColorStop(k/(C.fl.length-1),c));ctx.fillStyle=g;ctx.fill();
  par(70*u,1,L,R,(sx,i)=>{for(let k=0;k<2;k++){if(k&&bgH(i,9)<.5)continue;const px2=sx+bgH(i,k+1)*46*u,py2=G+ter(px2)+(24+k*26+bgH(i,k+4)*16)*u,rx=(6+bgH(i,k+6)*7)*u;ctx.fillStyle=state.cT?'rgba(120,190,235,.45)':'rgba(30,24,20,.55)';ctx.beginPath();ctx.ellipse(px2,py2,rx,rx*.55,bgH(i,k+8)*.5-.25,0,7);ctx.fill();ctx.strokeStyle='rgba(0,0,0,.3)';ctx.lineWidth=1.3*u;ctx.stroke();ctx.fillStyle='rgba(255,255,255,.14)';ctx.beginPath();ctx.ellipse(px2-rx*.25,py2-rx*.2,rx*.4,rx*.2,-.3,0,7);ctx.fill()}});
  const edge=()=>{ctx.beginPath();for(let x=L;x<=R+8;x+=8){const yy=G+ter(x)+1.5*u;x===L?ctx.moveTo(x,yy):ctx.lineTo(x,yy)}};
  if(state.cT){ctx.strokeStyle='rgba(120,210,255,.3)';ctx.lineWidth=9*u;edge();ctx.stroke()}
  ctx.strokeStyle='rgba(0,0,0,.45)';ctx.lineWidth=6.5*u;edge();ctx.stroke();ctx.strokeStyle=C.fe;ctx.lineWidth=3*u;edge();ctx.stroke();
  ctx.strokeStyle=state.cT?'rgba(255,255,255,.7)':'rgba(255,235,200,.25)';ctx.lineWidth=1*u;ctx.beginPath();for(let x=L;x<=R+8;x+=8){const yy=G+ter(x)+.2*u;x===L?ctx.moveTo(x,yy):ctx.lineTo(x,yy)}ctx.stroke();
  par(46*u,1,L,R,(sx,i)=>{const r2=((i*29)%5+5)%5,fy=G+ter(sx),sy=fy+8*u+r2*5*u,rx=(5+r2*2)*u;
    ctx.fillStyle=state.cT?(r2%2?'#9fd4f2':'#cdeeff'):(r2%2?'#3a2f27':'#6a5a4a');ctx.beginPath();ctx.ellipse(sx,sy,rx,(2.5+r2%3)*u,0,0,7);ctx.fill();ctx.strokeStyle='rgba(0,0,0,.4)';ctx.lineWidth=1.3*u;ctx.stroke();ctx.fillStyle='rgba(255,255,255,.2)';ctx.beginPath();ctx.ellipse(sx-rx*.3,sy-1*u,rx*.4,1*u,0,0,7);ctx.fill();
    if(state.cT){if(r2===1){obCry(sx-4*u,sx+4*u,sx,fy-10*u,fy+3*u,'#bfe8ff');obCry(sx+3*u,sx+8*u,sx+5.5*u,fy-4*u,fy+3*u,'#9fd4f2')}ctx.fillStyle='rgba(255,255,255,.14)';ctx.beginPath();ctx.ellipse(sx+8*u,fy+15*u+r2*3*u,(14+r2*3)*u,1.6*u,0,0,7);ctx.fill();if(r2===4)BSP(sx,fy-5*u,(1+2*Math.max(0,Math.sin(t*3+i)))*u,'rgba(255,255,255,.9)')}
    else{
      if(r2===1){ctx.fillStyle='#3f6b3a';ctx.beginPath();ctx.ellipse(sx,fy+2*u,11*u,3.4*u,0,0,7);ctx.fill();ctx.strokeStyle='rgba(0,0,0,.4)';ctx.stroke();ctx.fillStyle='#5f9a56';ctx.beginPath();ctx.ellipse(sx,fy+1*u,8*u,1.6*u,0,0,7);ctx.fill();BST('#5fae63',1.3,sx-4*u,fy,sx-4*u,fy-3*u,sx-3*u,fy-5*u);BST('#5fae63',1.3,sx+3*u,fy,sx+4*u,fy-3*u,sx+5*u,fy-4*u)}
      if(r2===2){BOV(sx-3*u,fy-1*u,4*u,2.6*u,'#6a5a4a');BOV(sx+3*u,fy-1.4*u,3.4*u,2.4*u,'#5a4c3e');BOV(sx,fy-4*u,3*u,2*u,'#7a6858');ctx.strokeStyle='rgba(0,0,0,.4)';ctx.lineWidth=1.2*u;ctx.beginPath();ctx.ellipse(sx,fy-4*u,3*u,2*u,0,0,7);ctx.stroke()}
      if(r2===3){ctx.fillStyle='rgba(91,232,196,'+(.14+.06*Math.sin(t*2+i)).toFixed(2)+')';ctx.beginPath();ctx.arc(sx,fy-6*u,16*u,0,7);ctx.fill();ctx.fillStyle='#d9d2c0';rr(sx-1.5*u,fy-5*u,3*u,6*u,1*u);ctx.fill();ctx.strokeStyle='rgba(0,0,0,.45)';ctx.lineWidth=1.2*u;ctx.stroke();ctx.fillStyle='#5be8c4';ctx.beginPath();ctx.ellipse(sx,fy-6*u,6*u,3.6*u,0,Math.PI,0);ctx.closePath();ctx.fill();ctx.stroke();wdot(sx-2*u,fy-8*u,.8*u,'#e8fff8');wdot(sx+2*u,fy-7.4*u,.6*u,'#e8fff8')}}});
  ctx.save();ctx.globalCompositeOperation='lighter';par(230*u,.7,L,R,(sx,i)=>{const fy=G+ter(sx),tc=!state.cT&&(i&1),cl=state.cT?(((i>>1)&1)&&!(i&1)?'170,140,255':'110,220,255'):tc?'255,170,70':'110,220,255';ctx.save();ctx.translate(sx,fy+4*u);ctx.scale(1,.2);const gp=ctx.createRadialGradient(0,0,2*u,0,0,130*u);gp.addColorStop(0,'rgba('+cl+','+(tc||state.cT?.38:.2)+')');gp.addColorStop(1,'rgba('+cl+',0)');ctx.fillStyle=gp;ctx.beginPath();ctx.arc(0,0,130*u,0,7);ctx.fill();ctx.restore()});ctx.restore();
  par(240*u,.5,L,R,(sx,i)=>{ctx.fillStyle=C.fog+(.1+.05*Math.sin(t*.6+i)).toFixed(3)+')';ctx.beginPath();ctx.ellipse(sx+Math.sin(t*.3+i)*20*u,G-8*u,160*u,24*u,0,0,7);ctx.fill()});
  g=ctx.createLinearGradient(0,G-90*u,0,G+10*u);g.addColorStop(0,C.fog+'0)');g.addColorStop(1,C.fog+'.16)');ctx.fillStyle=g;ctx.fillRect(L,G-90*u,R-L,100*u);
  ctx.fillStyle='rgba('+C.mt+',.9)';for(let i=0;i<14;i++){const fx3=W+30-((i*173+state.dist*.25*(1+i%3*.2))%(W+60)),fy3=state.cT?H*.12+(i*61+t*(18+i%3*7)*u)%(H*.62):H*(.3+((i*37)%5)*.1)+Math.sin(t*1.6+i*2)*14*u;ctx.globalAlpha=.4+.4*Math.sin(t*3+i);if(state.cT)BSP(fx3,fy3,2.6*u,'rgb('+C.mt+')');else{ctx.beginPath();ctx.arc(fx3,fy3,1.8*u,0,7);ctx.fill()}}ctx.globalAlpha=1;
  if(eL>0){g=ctx.createLinearGradient(L,0,L+150*u,0);g.addColorStop(0,'rgba('+C.lt+',.22)');g.addColorStop(1,'rgba('+C.lt+',0)');ctx.fillStyle=g;ctx.fillRect(L,0,150*u,H)}
  if(eR<W){g=ctx.createLinearGradient(R,0,R-150*u,0);g.addColorStop(0,'rgba('+C.lt+',.22)');g.addColorStop(1,'rgba('+C.lt+',0)');ctx.fillStyle=g;ctx.fillRect(R-150*u,0,150*u,H)}
  ctx.restore();
  if(eL>0)cvMouth(eL,-1);if(eR<W)cvMouth(eR,1);
}
function cvMouth(x,s){
  const cy=H*.2,o=x+s*230*u,m=x+s*110*u,gc=state.cT?'170,235,255':'255,244,205',bz=a=>{const b=1-a;return[b*b*o+2*a*b*m+a*a*x,b*b*(cy-90*u)+2*a*b*(cy-10*u)+a*a*(cy+40*u)]},ed=()=>{ctx.beginPath();ctx.moveTo(o,cy-90*u);ctx.quadraticCurveTo(m,cy-10*u,x,cy+40*u)};
  ctx.lineJoin='round';ctx.lineCap='round';
  const gl=ctx.createRadialGradient(x,G-70*u,10*u,x,G-70*u,260*u);gl.addColorStop(0,'rgba('+gc+',.55)');gl.addColorStop(1,'rgba('+gc+',0)');ctx.fillStyle=gl;ctx.fillRect(x-260*u,0,520*u,H);
  const g=ctx.createLinearGradient(0,0,0,cy+60*u);if(state.cT){g.addColorStop(0,'#3f78a8');g.addColorStop(1,'#cfeaff')}else{g.addColorStop(0,'#3a322a');g.addColorStop(1,'#6b5d4e')}ctx.fillStyle=g;
  ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(o,0);ctx.lineTo(o,cy-90*u);ctx.quadraticCurveTo(m,cy-10*u,x,cy+40*u);ctx.closePath();ctx.fill();
  ctx.save();ctx.clip();const a0=Math.min(x,o)-4,a1=Math.max(x,o)+4,aw=a1-a0;
  const sg=ctx.createLinearGradient(x,0,o,0);sg.addColorStop(0,'rgba(255,240,200,.2)');sg.addColorStop(1,'rgba(0,0,0,.3)');ctx.fillStyle=sg;ctx.fillRect(a0,0,aw,cy+60*u);
  if(state.cT){ctx.strokeStyle='rgba(255,255,255,.2)';ctx.lineWidth=3*u;for(let q=0;q<5;q++){const bx=a0+(q+.5)*aw/5;ctx.beginPath();ctx.moveTo(bx,0);ctx.lineTo(bx-40*u,cy+50*u);ctx.stroke()}
    ctx.strokeStyle='rgba(20,70,130,.3)';ctx.lineWidth=1.6*u;ctx.beginPath();ctx.moveTo(a0,cy*.4);ctx.lineTo(a0+aw*.4,cy*.62);ctx.lineTo(a0+aw*.55,cy*.5);ctx.lineTo(a0+aw*.9,cy*.8);ctx.moveTo(a0+aw*.2,0);ctx.lineTo(a0+aw*.3,cy*.3);ctx.lineTo(a0+aw*.24,cy*.5);ctx.stroke();
    ctx.strokeStyle='rgba(255,255,255,.55)';ctx.lineWidth=1.2*u;ctx.beginPath();ctx.moveTo(a0+aw*.62,cy*.12);ctx.lineTo(a0+aw*.56,cy*.4);ctx.moveTo(a0+aw*.8,cy*.2);ctx.lineTo(a0+aw*.76,cy*.35);ctx.stroke();for(let q=0;q<3;q++)BSP(a0+aw*(.25+q*.25),cy*(.25+q%2*.25),(1+2*Math.max(0,Math.sin(t*3+q*2+x*.01)))*u,'rgba(255,255,255,.9)')}
  else{for(let q=0;q<6;q++){const yy=cy*(.1+q*.22);for(let p=0;p<2;p++){ctx.strokeStyle=p?'rgba(255,225,180,.08)':'rgba(0,0,0,.24)';ctx.lineWidth=(p?1:2)*u;ctx.beginPath();for(let xx=a0;xx<=a1;xx+=14){const y2=yy+p*3*u+Math.sin(xx/(38*u)+q*2.1)*4*u;xx===a0?ctx.moveTo(xx,y2):ctx.lineTo(xx,y2)}ctx.stroke()}}
    ctx.strokeStyle='rgba(0,0,0,.34)';ctx.lineWidth=1.5*u;ctx.beginPath();ctx.moveTo(a0+aw*.2,0);ctx.lineTo(a0+aw*.28,cy*.35);ctx.lineTo(a0+aw*.22,cy*.6);ctx.moveTo(a0+aw*.7,cy*.1);ctx.lineTo(a0+aw*.64,cy*.5);ctx.moveTo(a0+aw*.28,cy*.35);ctx.lineTo(a0+aw*.4,cy*.45);ctx.stroke();
    for(const[a,b2,r]of[[.45,.3,9],[.82,.55,7]]){ctx.fillStyle='rgba(30,24,20,.5)';ctx.beginPath();ctx.ellipse(a0+aw*a,cy*b2,r*u,r*.55*u,-.2,0,7);ctx.fill();ctx.strokeStyle='rgba(0,0,0,.4)';ctx.lineWidth=1.3*u;ctx.stroke();ctx.fillStyle='rgba(255,235,200,.12)';ctx.beginPath();ctx.ellipse(a0+aw*a-r*.25*u,cy*b2-r*.2*u,r*.4*u,r*.18*u,-.2,0,7);ctx.fill()}}
  ctx.restore();
  ed();ctx.strokeStyle='rgba(0,0,0,.4)';ctx.lineWidth=8.5*u;ctx.stroke();ed();ctx.strokeStyle=state.cT?'#eaf8ff':'#8b7a66';ctx.lineWidth=5*u;ctx.stroke();ctx.save();ctx.translate(0,-2.4*u);ed();ctx.strokeStyle=state.cT?'rgba(255,255,255,.75)':'rgba(255,235,200,.3)';ctx.lineWidth=1.4*u;ctx.stroke();ctx.restore();
  if(state.cT){
    ctx.fillStyle='#fff';ctx.strokeStyle='rgba(40,90,150,.35)';ctx.lineWidth=1.2*u;for(let q=0;q<16;q++){const[vx,vy]=bz(q/15);ctx.beginPath();ctx.ellipse(vx,vy-2*u,(7+q%3*3)*u,(4+q%2*2)*u,0,0,7);ctx.fill();ctx.stroke()}
    for(let q=1;q<14;q++){const[vx,vy]=bz(q/14),ln=(12+(q*17)%5*9)*u,hw=(3.5+q%3)*u;BPG('#a8dcf7',vx-hw,vy,vx,vy+ln,vx+hw,vy);ctx.fillStyle='#effbff';ctx.beginPath();ctx.moveTo(vx-hw*.2,vy);ctx.lineTo(vx,vy+ln);ctx.lineTo(vx+hw,vy);ctx.closePath();ctx.fill();ctx.strokeStyle='rgba(255,255,255,.7)';ctx.lineWidth=1*u;ctx.beginPath();ctx.moveTo(vx-hw*.4,vy+2*u);ctx.lineTo(vx-hw*.1,vy+ln*.6);ctx.stroke();if(q%4===0)BSP(vx,vy+ln,(1+2*Math.max(0,Math.sin(t*4+q)))*u,'rgba(255,255,255,.95)')}
  }else{
    for(let q=1;q<14;q+=2){const[vx,vy]=bz(q/14),ln=(12+(q*7)%3*7)*u;BPG('#3a322a',vx-5*u,vy,vx+1*u,vy+ln,vx+5*u,vy);ctx.fillStyle='#5a4d40';ctx.beginPath();ctx.moveTo(vx,vy);ctx.lineTo(vx+1*u,vy+ln);ctx.lineTo(vx+5*u,vy);ctx.closePath();ctx.fill()}
    for(let q=0;q<15;q++){const[vx,vy]=bz(q/14);ctx.fillStyle='#4f8a4a';ctx.beginPath();ctx.ellipse(vx,vy-1*u,(6+q%3*2)*u,(3.5+q%2*1.5)*u,0,0,7);ctx.fill();ctx.strokeStyle='rgba(10,40,15,.4)';ctx.lineWidth=1.3*u;ctx.stroke();ctx.fillStyle='#78bd6e';ctx.beginPath();ctx.ellipse(vx-1*u,vy-3*u,(4+q%3)*u,2*u,0,0,7);ctx.fill()}
    for(let q=1;q<7;q++){const[vx,vy]=bz(q/7),ln=(16+(q*13)%22)*u,sw=Math.sin(t*1.5+q)*3*u;BST('rgba(0,0,0,.3)',3.2,vx,vy,vx+sw*.5,vy+ln*.5,vx+sw,vy+ln);BST('#3f7a43',2,vx,vy,vx+sw*.5,vy+ln*.5,vx+sw,vy+ln);for(let k=1;k<4;k++){const lx=vx+sw*k/4+(k%2?3:-3)*u,ly=vy+ln*k/3.4;ctx.fillStyle='#5fae63';ctx.beginPath();ctx.ellipse(lx,ly,3*u,1.6*u,.6,0,7);ctx.fill();ctx.strokeStyle='rgba(10,40,15,.4)';ctx.lineWidth=1*u;ctx.stroke()}}
  }
}
