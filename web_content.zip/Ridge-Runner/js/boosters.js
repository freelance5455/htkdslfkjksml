/*
 * boosters.js - Pickups and booster visuals: charm sprites, pickup effects, coin effects, auras, the booster HUD.
 */
import { snd } from './audio.js';
import { t } from './clock.js';
import { BT } from './config.js';
import { tdrop } from './flight.js';
import { rh, ter } from './physics.js';
import { state } from './state.js';
import { ctx, dpr, G, H, px, setContext, u, W } from './view.js';

export function grab(k){if(k==='horse'||k==='sled')state.rd=k==='horse'?1:2;else if(k==='shield')state.fx.shield=1;else state.fx[k]=BT[k].d;state.pops.push({x:px+20*u,y:G+ter(px+17*u)-state.y-50*u,a:1.4,t:BT[k].n,c:BT[k].c});snd('b')}
const BINK='rgba(34,24,48,.78)';
const bsp={};
const BI={};
function bwob(r,n,a,s,N){ctx.beginPath();N=N||36;for(let i=0;i<=N;i++){const th=i/N*6.2832,k=r*(1+a*(Math.sin(th*n+s)*.6+Math.sin(th*(n+3)+s*2.3)*.4)),x=Math.cos(th)*k,y=Math.sin(th)*k;i?ctx.lineTo(x,y):ctx.moveTo(x,y)}ctx.closePath()}
const bink=(w,c)=>{ctx.lineJoin=ctx.lineCap='round';ctx.strokeStyle=c||BINK;ctx.lineWidth=w;ctx.stroke()};
const bfil=(f,w)=>{ctx.fillStyle=f;ctx.fill();bink(w||1.6)};
const blg=(x0,y0,x1,y1,a,b,m)=>{const g=ctx.createLinearGradient(x0,y0,x1,y1);g.addColorStop(0,a);if(m)g.addColorStop(.5,m);g.addColorStop(1,b);return g};
export function bstar(x,y,r,f){ctx.fillStyle=f;ctx.beginPath();ctx.moveTo(x,y-r);ctx.quadraticCurveTo(x,y,x+r,y);ctx.quadraticCurveTo(x,y,x,y+r);ctx.quadraticCurveTo(x,y,x-r,y);ctx.quadraticCurveTo(x,y,x,y-r);ctx.fill()}
function bell(x,y,rx,ry,rot,f,w){ctx.beginPath();ctx.ellipse(x,y,rx,ry,rot||0,0,7);bfil(f,w)}
/* Medallion: wobbly inked disc, stitched inner ring, painted highlight */
function bmedal(a,b){
  ctx.save();ctx.translate(1.3,2.2);bwob(19,2,.02,1.3,56);ctx.fillStyle='rgba(20,12,40,.3)';ctx.fill();ctx.restore();
  bwob(19,2,.02,1.3,56);ctx.fillStyle=blg(-12,-16,13,18,a,b);ctx.fill();
  ctx.save();ctx.setLineDash([2.4,2.8]);ctx.strokeStyle='rgba(255,255,255,.75)';ctx.lineWidth=1.1;ctx.beginPath();ctx.arc(0,0,15.4,0,7);ctx.stroke();ctx.restore();
  ctx.lineCap='round';ctx.strokeStyle='rgba(255,255,255,.8)';ctx.lineWidth=2.2;ctx.beginPath();ctx.arc(0,0,17,Math.PI*1.1,Math.PI*1.4);ctx.stroke();
  ctx.strokeStyle='rgba(30,12,50,.2)';ctx.lineWidth=2.8;ctx.beginPath();ctx.arc(0,0,16.6,Math.PI*.1,Math.PI*.6);ctx.stroke();
  bwob(19,2,.02,1.3,56);bink(2.6);
}
BI.ghost=()=>{
  bmedal('#d9efff','#6fb4ee');
  ctx.save();ctx.translate(0,-.8);
  bell(-10.2,2.4,2.8,1.7,.8,'#e4eeff',1.4);bell(10.2,.8,2.8,1.7,-.8,'#e4eeff',1.4);
  ctx.beginPath();ctx.moveTo(-8.6,9);ctx.bezierCurveTo(-10.6,-1,-9.6,-10.6,0,-10.6);ctx.bezierCurveTo(9.6,-10.6,10.6,-1,8.6,9);
  ctx.quadraticCurveTo(6,13.8,3,9.2);ctx.quadraticCurveTo(0,13.8,-3,9.2);ctx.quadraticCurveTo(-6,13.8,-8.6,9);ctx.closePath();
  bfil(blg(-6,-10,6,12,'#ffffff','#c2d9ff'),1.7);
  ctx.strokeStyle='rgba(255,255,255,.95)';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(-6,-6.6);ctx.quadraticCurveTo(-7.4,-3,-7,.6);ctx.stroke();
  ctx.fillStyle='rgba(255,120,150,.45)';ctx.beginPath();ctx.arc(-5.8,.8,1.7,0,7);ctx.arc(5.8,.8,1.7,0,7);ctx.fill();
  ctx.fillStyle='#22183a';ctx.beginPath();ctx.ellipse(-3.3,-3.4,1.5,2.2,0,0,7);ctx.ellipse(3.3,-3.4,1.5,2.2,0,0,7);ctx.fill();
  ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(-3.8,-4.2,.6,0,7);ctx.arc(2.8,-4.2,.6,0,7);ctx.fill();
  ctx.fillStyle='#22183a';ctx.beginPath();ctx.ellipse(0,1.6,1.3,1.7,0,0,7);ctx.fill();
  ctx.restore();
};
BI.shield=()=>{
  bmedal('#c9ffe0','#35c778');
  ctx.save();ctx.translate(0,.4);
  const sp=()=>{ctx.beginPath();ctx.moveTo(-9.6,-10);ctx.quadraticCurveTo(0,-7.4,9.6,-10);ctx.quadraticCurveTo(10.8,3.4,0,12.6);ctx.quadraticCurveTo(-10.8,3.4,-9.6,-10);ctx.closePath()};
  sp();bfil(blg(-8,-10,8,12,'#fff0a8','#e9a812'),1.8);
  ctx.save();ctx.translate(0,-.4);ctx.scale(.74,.74);sp();ctx.fillStyle=blg(-8,-10,8,12,'#27b27d','#0c5c42');ctx.fill();bink(1.5/.74);ctx.restore();
  ctx.strokeStyle='rgba(255,255,255,.55)';ctx.lineWidth=1.3;ctx.beginPath();ctx.moveTo(-5.4,-6.2);ctx.quadraticCurveTo(-6.2,-1,-3.8,3.6);ctx.stroke();
  ctx.beginPath();ctx.moveTo(0,-6.4);ctx.quadraticCurveTo(0,-1.8,4.6,-1.8);ctx.quadraticCurveTo(0,-1.8,0,4.8);ctx.quadraticCurveTo(0,-1.8,-4.6,-1.8);ctx.quadraticCurveTo(0,-1.8,0,-6.4);ctx.closePath();bfil('#fff8dc',1.1);
  ctx.restore();
};
BI.magnet=()=>{
  bmedal('#ffc4ee','#e85cc0');
  ctx.save();ctx.translate(0,2.2);ctx.rotate(-.32);
  const U=()=>{ctx.beginPath();ctx.moveTo(-6.4,-6);ctx.lineTo(-6.4,0);ctx.arc(0,0,6.4,Math.PI,0,true);ctx.lineTo(6.4,-6)};
  ctx.lineCap='butt';ctx.lineJoin='round';U();ctx.strokeStyle=BINK;ctx.lineWidth=11.4;ctx.stroke();
  U();ctx.strokeStyle='#e63946';ctx.lineWidth=8;ctx.stroke();
  ctx.beginPath();ctx.moveTo(-8.2,-3);ctx.lineTo(-8.2,0);ctx.arc(0,0,8.2,Math.PI,Math.PI*.64,true);ctx.strokeStyle='rgba(255,255,255,.55)';ctx.lineWidth=1.5;ctx.lineCap='round';ctx.stroke();
  ctx.beginPath();ctx.arc(0,0,4.5,Math.PI*.12,Math.PI*.88);ctx.strokeStyle='rgba(90,10,30,.32)';ctx.lineWidth=1.3;ctx.stroke();
  for(const x of[-6.4,6.4]){ctx.beginPath();ctx.rect(x-4,-8.4,8,5.4);bfil(blg(x-4,0,x+4,0,'#f4f7fc','#9aa6bf'),1.5);ctx.strokeStyle='rgba(60,70,100,.4)';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(x-4,-5.2);ctx.lineTo(x+4,-5.2);ctx.stroke()}
  ctx.save();ctx.setLineDash([1.8,2.2]);ctx.strokeStyle='#fff';ctx.lineWidth=1.4;ctx.lineCap='round';ctx.beginPath();ctx.arc(0,-8.6,6.4,Math.PI*1.08,Math.PI*1.92);ctx.stroke();ctx.restore();
  bstar(0,-13.4,2.6,'#ffe45c');
  ctx.restore();
};
BI.x2=()=>{
  bmedal('#fff0a0','#f5b301');
  const sl=f=>{ctx.lineCap=ctx.lineJoin='round';f();ctx.strokeStyle=BINK;ctx.lineWidth=5.8;ctx.stroke();f();ctx.strokeStyle='#fffbe6';ctx.lineWidth=3;ctx.stroke()};
  sl(()=>{ctx.beginPath();ctx.moveTo(-11.4,-3.4);ctx.lineTo(-5.4,3);ctx.moveTo(-5.4,-3.4);ctx.lineTo(-11.4,3)});
  sl(()=>{ctx.beginPath();ctx.moveTo(.8,-4.4);ctx.bezierCurveTo(1.4,-10,9.6,-10,9.6,-4);ctx.bezierCurveTo(9.6,.2,3.8,2.6,.4,8.4);ctx.lineTo(10.2,8.4)});
  bstar(10.6,-10,3,'#fff');bstar(-10.6,9.4,2.2,'rgba(255,255,255,.9)');
};
BI.slow=()=>{
  bmedal('#e3d7ff','#8f6be8');
  ctx.save();ctx.translate(-.8,.4);ctx.scale(1.12,1.12);
  ctx.beginPath();ctx.moveTo(-11,3.4);ctx.lineTo(-15,5.4);ctx.lineTo(-10.6,6.6);ctx.closePath();bfil('#9fc65a',1.3);
  for(const x of[-6.8,4.4]){ctx.beginPath();ctx.roundRect?ctx.roundRect(x,3.4,5,5.4,2):ctx.rect(x,3.4,5,5.4);bfil('#a9cf63',1.5)}
  bell(10.2,.6,4.4,3.7,0,'#b6d96c',1.6);
  ctx.fillStyle='#22183a';ctx.beginPath();ctx.arc(11.6,-.5,1,0,7);ctx.fill();ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(11.9,-.8,.38,0,7);ctx.fill();
  ctx.strokeStyle='#22183a';ctx.lineWidth=.9;ctx.lineCap='round';ctx.beginPath();ctx.arc(11.4,1.6,1.7,.2,Math.PI*.7);ctx.stroke();
  ctx.fillStyle='rgba(255,110,140,.5)';ctx.beginPath();ctx.arc(8.6,1.8,1.1,0,7);ctx.fill();
  const sh=()=>{ctx.beginPath();ctx.moveTo(-11.4,5.6);ctx.bezierCurveTo(-11.4,-10,11,-10,11,5.6);ctx.closePath()};
  sh();bfil(blg(-8,-8,8,6,'#7cd17f','#2e8a4f'),1.8);
  ctx.save();sh();ctx.clip();ctx.strokeStyle='rgba(20,60,30,.55)';ctx.lineWidth=1.1;ctx.lineJoin='round';
  ctx.beginPath();ctx.moveTo(-3.4,-4.6);ctx.lineTo(3.4,-4.6);ctx.lineTo(5.6,.4);ctx.lineTo(0,3.4);ctx.lineTo(-5.6,.4);ctx.closePath();
  ctx.moveTo(-3.4,-4.6);ctx.lineTo(-5,-9);ctx.moveTo(3.4,-4.6);ctx.lineTo(5,-9);ctx.moveTo(5.6,.4);ctx.lineTo(10,.2);ctx.moveTo(-5.6,.4);ctx.lineTo(-11,.2);ctx.moveTo(0,3.4);ctx.lineTo(0,7);ctx.stroke();
  ctx.restore();
  ctx.strokeStyle='rgba(255,255,255,.6)';ctx.lineWidth=1.4;ctx.beginPath();ctx.arc(0,.4,8.6,Math.PI*1.12,Math.PI*1.4);ctx.stroke();
  ctx.beginPath();ctx.moveTo(-11.4,5.6);ctx.lineTo(11,5.6);ctx.lineTo(10.2,8);ctx.lineTo(-10.6,8);ctx.closePath();bfil('#f6e6b8',1.4);
  ctx.restore();
};
BI.fly=()=>{
  bmedal('#c8f6ff','#2fb4e8');
  ctx.save();ctx.translate(0,-4.4);ctx.rotate(.14);
  for(let q=0;q<2;q++){const x=-8.6+q*9.2,w=8,h=11;
    tdrop(x+w/2,h-2.6+6.6,3.1,7,'#ff7a1a');tdrop(x+w/2,h-2.6+6.6,2.1,5,'#ffc93a');tdrop(x+w/2,h-2.6+6.6,1,3,'#fff6d6');
    ctx.beginPath();ctx.moveTo(x+1.8,h-1);ctx.lineTo(x+w-1.8,h-1);ctx.lineTo(x+w-2.8,h+3.4);ctx.lineTo(x+2.8,h+3.4);ctx.closePath();bfil('#3a3f52',1.3);
    ctx.beginPath();ctx.roundRect?ctx.roundRect(x,-6.4,w,h+.6,3.8):ctx.rect(x,-6.4,w,h+.6);bfil(blg(x,0,x+w,0,q?'#aab5ca':'#7b869e','#8d97ae',q?'#f4f7fc':'#c3cbdb'),1.5);
    ctx.beginPath();ctx.roundRect?ctx.roundRect(x,-6.4,w,6,[3.8,3.8,1,1]):ctx.rect(x,-6.4,w,6);bfil(q?'#ff5d73':'#c8374f',1.3);
    ctx.fillStyle='#6ee7ff';ctx.fillRect(x,2.6,w,2);
    ctx.fillStyle='rgba(255,255,255,.55)';ctx.fillRect(x+1.5,5.4,1.4,h-8)}
  ctx.restore();
  ctx.strokeStyle='rgba(255,255,255,.9)';ctx.lineWidth=1.3;ctx.lineCap='round';ctx.beginPath();ctx.moveTo(-13,-6);ctx.lineTo(-10.6,-6);ctx.moveTo(13,-3);ctx.lineTo(10.8,-3);ctx.moveTo(-12.6,-1);ctx.lineTo(-11,-1);ctx.stroke();
};
BI.horse=()=>{
  bmedal('#ffeab8','#dca25a');
  ctx.save();ctx.translate(.2,.4);ctx.scale(1.08,1.08);
  const hd=()=>{ctx.beginPath();ctx.moveTo(-7,12);ctx.bezierCurveTo(-9,4,-8.6,-4,-6.6,-9);ctx.lineTo(-4.4,-12.6);ctx.lineTo(-1.6,-9.4);
    ctx.bezierCurveTo(1.6,-8.6,4,-7,5.4,-4.2);ctx.bezierCurveTo(7,-1.4,9.4,1.4,10.4,3.4);ctx.bezierCurveTo(11.2,5,10.6,7.2,9,7.8);
    ctx.bezierCurveTo(7.4,8.4,5.4,7.6,4,5.4);ctx.bezierCurveTo(3,7.8,3.2,10,4,12);ctx.closePath()};
  hd();bfil(blg(-8,-10,10,10,'#cf7a35','#8f4a1c'),1.8);
  ctx.save();hd();ctx.clip();ctx.fillStyle='#fff4de';ctx.beginPath();ctx.moveTo(.2,-8);ctx.bezierCurveTo(3,-6,5.2,-2.6,7.4,.6);ctx.lineTo(9,3.4);ctx.lineTo(6.6,4.2);ctx.bezierCurveTo(5.4,1.6,3.2,-1.4,1,-4);ctx.closePath();ctx.fill();
  ctx.fillStyle='rgba(60,20,5,.2)';ctx.beginPath();ctx.ellipse(3.6,6.4,3.2,5,.3,0,7);ctx.fill();ctx.restore();
  ctx.beginPath();ctx.moveTo(-6.6,-9);ctx.bezierCurveTo(-10.4,-8,-12,-3,-10.8,-.8);ctx.bezierCurveTo(-12.6,2,-12,6,-9.8,7.6);ctx.bezierCurveTo(-10.2,9.6,-9.2,11,-7.2,12);ctx.bezierCurveTo(-8.4,6,-7.8,-3,-6.2,-8);ctx.closePath();bfil('#3b2314',1.5);
  ctx.beginPath();ctx.moveTo(-3.2,-10.2);ctx.bezierCurveTo(-.6,-9.4,1.2,-6.6,.6,-3.4);ctx.bezierCurveTo(-1.2,-5,-2.6,-7,-3.6,-9.2);ctx.closePath();bfil('#3b2314',1.3);
  ctx.fillStyle='#22183a';ctx.beginPath();ctx.arc(3.8,-1.4,1.5,0,7);ctx.fill();ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(4.3,-1.9,.55,0,7);ctx.fill();
  ctx.fillStyle='rgba(30,12,10,.7)';ctx.beginPath();ctx.ellipse(9,3.8,.7,1.2,.5,0,7);ctx.fill();
  ctx.restore();
};
BI.sled=()=>{
  bmedal('#ffd0d8','#f06a85');
  ctx.save();ctx.translate(0,-.2);ctx.scale(1.06,1.06);
  ctx.lineCap=ctx.lineJoin='round';
  for(const x of[-6.4,5.6]){ctx.beginPath();ctx.moveTo(x,9.2);ctx.lineTo(x,3.6);ctx.strokeStyle=BINK;ctx.lineWidth=3.6;ctx.stroke();ctx.strokeStyle='#d0903f';ctx.lineWidth=1.7;ctx.stroke()}
  const rn=()=>{ctx.beginPath();ctx.moveTo(-12.6,9.8);ctx.lineTo(7.6,9.8);ctx.bezierCurveTo(11.4,9.8,13.4,7.8,12.8,5.2);ctx.bezierCurveTo(12.4,3.8,11,3.6,10.4,4.6)};
  rn();ctx.strokeStyle=BINK;ctx.lineWidth=4.4;ctx.stroke();rn();ctx.strokeStyle='#e6edf6';ctx.lineWidth=2.2;ctx.stroke();
  ctx.beginPath();ctx.moveTo(-12.2,-8);ctx.bezierCurveTo(-13.6,-1,-10.6,4.4,-5.4,4.6);ctx.lineTo(6.2,4.6);ctx.bezierCurveTo(10.6,4.6,13.2,1.2,13.2,-3.8);
  ctx.bezierCurveTo(10.6,-3.4,9.2,-2.2,8.4,-.8);ctx.bezierCurveTo(4.4,-1.4,1.4,-3.6,-1,-5.2);ctx.bezierCurveTo(-4.6,-7.4,-8.4,-8.2,-12.2,-8);ctx.closePath();
  bfil(blg(-12,-8,10,6,'#ee4b5e','#a81c33'),1.8);
  ctx.strokeStyle='#ffd23f';ctx.lineWidth=1.7;ctx.beginPath();ctx.moveTo(-10.8,-6);ctx.bezierCurveTo(-4,-6,1,-3.2,8.6,.2);ctx.stroke();
  ctx.strokeStyle='rgba(255,255,255,.5)';ctx.lineWidth=1.3;ctx.beginPath();ctx.moveTo(-10.4,-1);ctx.bezierCurveTo(-9.6,2,-8,3.2,-5.6,3.2);ctx.stroke();
  bell(-3.4,-6.8,3,2.2,-.2,'#fdf6e9',1.3);
  ctx.restore();
};
/* Cached sprites: each charm is inked once per screen scale, then blitted */
function bSprite(k){
  const sc=u*dpr,key=sc.toFixed(2),e=bsp[k];
  if(e&&e.key===key)return e.c;
  const c=document.createElement('canvas'),Z=Math.ceil(52*sc);c.width=c.height=Z;
  const sv=ctx;setContext(c.getContext('2d'));ctx.setTransform(sc,0,0,sc,Z/2,Z/2);
  try{BI[k]()}finally{setContext(sv)}
  bsp[k]={key,c};return c;
}
const fe=k=>Math.max(0,Math.min(1,(BT[k].d-state.fx[k])*4,state.fx[k]*3));
function bglow(x,y,r,c,a){const g=ctx.createRadialGradient(x,y,0,x,y,r);g.addColorStop(0,'rgba('+c+','+a.toFixed(2)+')');g.addColorStop(1,'rgba('+c+',0)');ctx.fillStyle=g;ctx.fillRect(x-r,y-r,r*2,r*2)}
/* Pickup on the road: floating charm, soft halo, ground shadow, two orbiting glints */
export function drawItem(b){
  const B=BT[b.k];if(b.s==null)b.s=Math.random()*6.28;
  const gy=G+ter(b.x),bob=Math.sin(t*3.6+b.s),by=gy-38*u+bob*3.5*u,Z=52*u;
  ctx.fillStyle='rgba(20,14,36,'+(.2-.05*bob).toFixed(2)+')';ctx.beginPath();ctx.ellipse(b.x,gy+2*u,(12-1.8*bob)*u,3*u,0,0,7);ctx.fill();
  bglow(b.x,by,36*u,B.r,.55+.15*Math.sin(t*5+b.s));
  ctx.save();ctx.translate(b.x,by);ctx.rotate(Math.sin(t*2.6+b.s)*.1);ctx.drawImage(bSprite(b.k),-Z/2,-Z/2,Z,Z);ctx.restore();
  for(let q=0;q<2;q++){const a=t*2.4+q*Math.PI+b.s;bstar(b.x+Math.cos(a)*25*u,by+Math.sin(a)*13*u,(2+Math.sin(t*8+q*2+b.s)*.9)*u,'rgba(255,255,255,.92)')}
}
/* Short-lived sparks: rings, stars, glass shards */
function bfm(o){o.l0=o.l;state.bf.push(o)}
export function bfStep(dt){for(const p of state.bf){p.l-=dt;p.x+=p.vx*dt;p.y+=p.vy*dt;if(p.g)p.vy+=p.g*dt;if(p.dr){const k=Math.max(0,1-p.dr*dt);p.vx*=k;p.vy*=k}if(p.gr)p.r+=p.gr*dt}state.bf=state.bf.filter(p=>p.l>0)}
export function bfDraw(){
  for(const p of state.bf){const k=Math.max(0,p.l/p.l0),c=p.c;
    if(p.k==='ring'){ctx.strokeStyle='rgba('+c+','+(.8*k).toFixed(2)+')';ctx.lineWidth=(1+3.5*k)*u;ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,7);ctx.stroke()}
    else if(p.k==='star')bstar(p.x,p.y,p.r*Math.min(1,k*2.2)*(.8+.2*Math.sin(t*28+p.ph)),'rgba('+c+','+Math.min(1,k*2).toFixed(2)+')');
    else{ctx.save();ctx.translate(p.x,p.y);ctx.rotate(p.rot+p.vr*(p.l0-p.l));ctx.globalAlpha=Math.min(1,k*2.5);
      ctx.beginPath();ctx.moveTo(0,-p.r);ctx.lineTo(p.r*.72,p.r*.8);ctx.lineTo(-p.r*.8,p.r*.5);ctx.closePath();
      ctx.fillStyle='rgba('+c+',.7)';ctx.fill();ctx.strokeStyle='rgba(30,22,48,.6)';ctx.lineWidth=1.4*u;ctx.lineJoin='round';ctx.stroke();
      ctx.strokeStyle='rgba(255,255,255,.7)';ctx.lineWidth=1*u;ctx.beginPath();ctx.moveTo(-p.r*.2,-p.r*.2);ctx.lineTo(p.r*.2,p.r*.35);ctx.stroke();ctx.restore()}}
}
export function pickFx(b){
  const B=BT[b.k],x=b.x,y=G+ter(b.x)-38*u,R=Math.random;
  bfm({k:'ring',x,y,r:12*u,gr:230*u,l:.45,c:B.r});bfm({k:'ring',x,y,r:6*u,gr:140*u,l:.32,c:'255,255,255'});
  for(let i=0;i<12;i++){const a=i/12*6.283+R()*.4,v=(90+R()*200)*u;bfm({k:'star',x,y,vx:Math.cos(a)*v,vy:Math.sin(a)*v-40*u,g:200*u,dr:2.6,r:(2.4+R()*2.6)*u,l:.5+R()*.4,c:i%3?B.r:'255,255,255',ph:R()*6})}
}
export function shBreak(){
  const x=px+17*u,cy=G+ter(x)-state.y-17*u-rh(),R=Math.random;
  bfm({k:'ring',x,y:cy,r:26*u,gr:260*u,l:.4,c:'125,255,168'});
  for(let i=0;i<11;i++){const a=i/11*6.283+R()*.3,v=(150+R()*170)*u;bfm({k:'shard',x:x+Math.cos(a)*26*u,y:cy+Math.sin(a)*26*u,vx:Math.cos(a)*v,vy:Math.sin(a)*v-70*u,g:480*u,dr:1.1,r:(4+R()*4.4)*u,rot:R()*6,vr:(R()-.5)*16,l:.65+R()*.4,c:'125,255,168'})}
  for(let i=0;i<6;i++)bfm({k:'star',x,y:cy,vx:(R()-.5)*260*u,vy:(R()-.5)*260*u,dr:3,r:(2.4+R()*2)*u,l:.5,c:'255,255,255',ph:R()*6})
}
/* Coins: magnet streaks and x2 glints */
export function coinFx(c,cy){
  if(state.fx.magnet>0){const px2=px+17*u,py=G+ter(px2)-state.y-17*u,dx=px2-c.x,dy=py-cy,d=Math.hypot(dx,dy);
    if(d<240*u&&d>22*u){ctx.strokeStyle='rgba(255,122,217,'+(.6*(1-d/(300*u))).toFixed(2)+')';ctx.lineWidth=2.6*u;ctx.lineCap='round';ctx.beginPath();ctx.moveTo(c.x,cy);ctx.lineTo(c.x-dx/d*20*u,cy-dy/d*20*u);ctx.stroke()}}
  if(state.fx.x2>0){ctx.fillStyle='rgba(255,214,70,.28)';ctx.beginPath();ctx.arc(c.x,cy,15*u,0,7);ctx.fill();
    const ph=(t*1.5+c.x*.013)%1;if(ph<.4)bstar(c.x+8*u,cy-8*u,(1-ph/.4)*5.4*u,'#fff')}
}
/* Active boosters: auras behind the runner, then bubbles and sparkles in front */
export function bBack(top,s){
  if(state.st!=='play'||!(state.fx.ghost>0||state.fx.x2>0||state.fx.magnet>0||state.fx.slow>0))return;
  const cx=px+s/2,cy=top+s*.5;ctx.save();ctx.globalAlpha=1;
  if(state.fx.ghost>0){const e=fe('ghost')*(state.fx.ghost<1.2?(Math.sin(t*30)>0?1:.4):1);bglow(cx,cy,56*u,'160,218,255',.5*e);
    ctx.strokeStyle='rgba(200,235,255,'+(.4*e).toFixed(2)+')';ctx.lineWidth=2*u;ctx.setLineDash([5*u,7*u]);ctx.lineDashOffset=-t*26*u;ctx.save();ctx.translate(cx,cy);bwob(s*.86,3,.05,t*1.6,40);ctx.stroke();ctx.restore();ctx.setLineDash([])}
  if(state.fx.x2>0){const e=fe('x2');bglow(cx,cy,54*u,'255,206,60',.42*e*(.85+.15*Math.sin(t*6)))}
  if(state.fx.magnet>0){const e=fe('magnet');ctx.lineWidth=2*u;
    for(let q=0;q<3;q++){const ph=(t*.7+q/3)%1;ctx.strokeStyle='rgba(255,122,217,'+(.36*Math.sin(ph*Math.PI)*e).toFixed(2)+')';ctx.setLineDash([6*u,8*u]);ctx.lineDashOffset=-t*40*u*(q+1);ctx.beginPath();ctx.arc(cx,cy,(34+196*(1-ph))*u,0,7);ctx.stroke()}
    ctx.setLineDash([]);bglow(cx,cy,48*u,'255,122,217',.28*e)}
  if(state.fx.slow>0){const e=fe('slow'),R=s*1.22,tk=Math.floor(t*1.5),f=(t*1.5)%1,ang=(tk+(1-Math.pow(1-f,4)))*Math.PI/6-Math.PI/2;
    ctx.save();ctx.translate(cx,cy);ctx.globalAlpha=e;bglow(0,0,R*1.5,'185,155,255',.34);
    ctx.strokeStyle='rgba(206,186,255,.7)';ctx.lineWidth=2*u;ctx.lineCap='round';ctx.beginPath();ctx.arc(0,0,R,0,7);ctx.stroke();
    ctx.save();ctx.rotate(-t*.3);ctx.lineWidth=2.4*u;for(let i=0;i<12;i++){const a=i*Math.PI/6,l=i%3?5*u:9*u;ctx.beginPath();ctx.moveTo(Math.cos(a)*(R-3*u),Math.sin(a)*(R-3*u));ctx.lineTo(Math.cos(a)*(R-3*u-l),Math.sin(a)*(R-3*u-l));ctx.stroke()}ctx.restore();
    ctx.strokeStyle='rgba(30,16,60,.5)';ctx.lineWidth=4.6*u;ctx.beginPath();ctx.moveTo(Math.cos(ang)*s*.5,Math.sin(ang)*s*.5);ctx.lineTo(Math.cos(ang)*(R-9*u),Math.sin(ang)*(R-9*u));ctx.stroke();
    ctx.strokeStyle='#efe6ff';ctx.lineWidth=2.4*u;ctx.stroke();ctx.restore()}
  ctx.restore();
}
export function bFront(top,s){
  if(state.st!=='play')return;const cx=px+s/2,cy=top+s*.5;
  if(state.fx.ghost>0){const e=fe('ghost'),x0=cx-s*.5;ctx.save();ctx.lineCap='round';ctx.lineWidth=3.2*u;
    for(let q=0;q<3;q++){const yy=cy+(q-1)*10*u,g=ctx.createLinearGradient(x0,0,x0-52*u,0);g.addColorStop(0,'rgba(215,240,255,'+(.85*e).toFixed(2)+')');g.addColorStop(1,'rgba(215,240,255,0)');ctx.strokeStyle=g;ctx.beginPath();ctx.moveTo(x0,yy);for(let i=1;i<=7;i++)ctx.lineTo(x0-i*7.5*u,yy+Math.sin(t*6-i*.9+q*2)*(1.5+i*.9)*u);ctx.stroke()}
    for(let q=0;q<4;q++){const ph=(t*.6+q*.25)%1,a=Math.sin(ph*Math.PI)*e;ctx.fillStyle='rgba(225,244,255,'+(.85*a).toFixed(2)+')';ctx.beginPath();ctx.arc(cx+Math.sin(q*2.1+t*1.3)*s*.75,cy+s*.55-ph*s*1.8,(2.2+q%2)*u,0,7);ctx.fill()}ctx.restore()}
  if(state.fx.magnet>0){const e=fe('magnet');for(let q=0;q<6;q++){const ph=(t*.9+q/6)%1,an=t*3+q*1.047+ph*2,r=(80*(1-ph)+14)*u;bstar(cx+Math.cos(an)*r,cy+Math.sin(an)*r*.8,(1.6+2.6*ph)*u,'rgba(255,150,230,'+(Math.sin(ph*Math.PI)*e).toFixed(2)+')')}}
  if(state.fx.x2>0){const e=fe('x2');for(let q=0;q<6;q++){const ph=(t*.85+q/6)%1,a=Math.sin(ph*Math.PI)*e,r=(2.4+4*Math.sin(ph*Math.PI))*u,x=cx+Math.cos(q*2.4+1)*s*.72,yy=cy+s*.45-ph*s*1.7;bstar(x,yy,r,'rgba(255,214,60,'+a.toFixed(2)+')');bstar(x,yy,r*.45,'rgba(255,255,255,'+a.toFixed(2)+')')}}
  if(state.fx.slow>0){const e=fe('slow');for(let q=0;q<7;q++){const x=cx+Math.cos(q*1.9+t*.5)*s*1.05,yy=cy+Math.sin(q*2.7+t*.4)*s*.9,a=(.45+.4*Math.sin(t*2+q))*e;ctx.fillStyle='rgba(222,208,255,'+a.toFixed(2)+')';ctx.beginPath();ctx.arc(x,yy,1.9*u,0,7);ctx.fill();ctx.strokeStyle='rgba(255,255,255,'+(a*.8).toFixed(2)+')';ctx.lineWidth=.9*u;ctx.beginPath();ctx.moveTo(x-3.6*u,yy);ctx.lineTo(x+3.6*u,yy);ctx.moveTo(x,yy-3.6*u);ctx.lineTo(x,yy+3.6*u);ctx.stroke()}}
  if(state.fx.shield){const R=s*.95*(1+.025*Math.sin(t*5));ctx.save();ctx.translate(cx,cy);
    bwob(R,3,.03,t*1.2,48);const g=ctx.createRadialGradient(0,0,R*.3,0,0,R);g.addColorStop(0,'rgba(125,255,168,.05)');g.addColorStop(.75,'rgba(125,255,168,.16)');g.addColorStop(1,'rgba(190,255,215,.42)');ctx.fillStyle=g;ctx.fill();
    bink(4.2*u,'rgba(20,56,40,.55)');bwob(R,3,.03,t*1.2,48);ctx.strokeStyle='rgba(210,255,228,.95)';ctx.lineWidth=2*u;ctx.stroke();
    ctx.save();ctx.setLineDash([4*u,5*u]);ctx.lineDashOffset=-t*22*u;ctx.strokeStyle='rgba(255,255,255,.6)';ctx.lineWidth=1.2*u;ctx.beginPath();ctx.arc(0,0,R*.85,0,7);ctx.stroke();ctx.restore();
    ctx.lineCap='round';ctx.strokeStyle='rgba(255,255,255,.88)';ctx.lineWidth=2.8*u;ctx.beginPath();ctx.arc(0,0,R*.78,Math.PI*1.12,Math.PI*1.42);ctx.stroke();ctx.lineWidth=1.8*u;ctx.beginPath();ctx.arc(0,0,R*.78,Math.PI*1.5,Math.PI*1.56);ctx.stroke();
    bstar(-R*.62,-R*.62,(2.6+1.3*Math.sin(t*6))*u,'#fff');
    for(let q=0;q<3;q++){const a=t*1.5+q*2.094,x=Math.cos(a)*R,yy=Math.sin(a)*R;ctx.beginPath();ctx.moveTo(x,yy-4.6*u);ctx.lineTo(x+3.2*u,yy);ctx.lineTo(x,yy+4.6*u);ctx.lineTo(x-3.2*u,yy);ctx.closePath();bfil('#7dffa8',1.3*u)}
    ctx.restore()}
}
export function slowTint(){if(state.st!=='play'||!(state.fx.slow>0))return;const e=fe('slow'),m=Math.min(W,H),g=ctx.createRadialGradient(W/2,H*.5,m*.35,W/2,H*.5,Math.max(W,H)*.8);g.addColorStop(0,'rgba(150,110,235,0)');g.addColorStop(1,'rgba(150,110,235,'+(.26*e).toFixed(2)+')');ctx.fillStyle=g;ctx.fillRect(0,0,W,H)}
/* HUD: each active booster is a charm with a draining ring */
export function bHud(){
  if(state.st!=='play')return;
  const L=[];
  if(state.rd&&!state.ob)L.push([state.rd===1?'horse':'sled',1,0]);
  for(const k of['ghost','magnet','x2','slow','fly','shield']){const v=k==='shield'?state.fx.shield:state.fx[k]/BT[k].d;if(v>0)L.push([k,Math.min(1,v),k!=='shield'])}
  const R=Math.max(9,Math.min(15,(W-18-72-9*Math.max(0,L.length-1))/Math.max(1,L.length)/2-4.2)),cy=72,rr2=R+4.2,Z=52*R/19;let ax=18+rr2;
  ctx.save();ctx.lineCap='round';
  for(const[k,v,tm]of L){const B=BT[k],low=tm&&state.fx[k]<1.5&&Math.sin(t*20)>0;
    ctx.strokeStyle='rgba(20,14,40,.5)';ctx.lineWidth=5.6;ctx.beginPath();ctx.arc(ax,cy,rr2,0,7);ctx.stroke();
    ctx.globalAlpha=low?.35:1;ctx.strokeStyle=B.c;ctx.lineWidth=3.2;ctx.beginPath();ctx.arc(ax,cy,rr2,-Math.PI/2,-Math.PI/2+Math.max(.02,v)*6.2832);ctx.stroke();
    ctx.drawImage(bSprite(k),ax-Z/2,cy-Z/2,Z,Z);ctx.globalAlpha=1;ax+=rr2*2+9}
  ctx.restore();
}
