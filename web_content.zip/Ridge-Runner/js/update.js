/*
 * update.js - The per-frame simulation step: update(dt) runs the steps of every system in a fixed order.
 */
import { advStep } from './adventure-mode.js';
import { bfStep } from './boosters.js';
import { collectPickups, hitObstacles } from './collision.js';
import { fpStep, stepFlight } from './flight.js';
import { die, updateScore } from './game.js';
import { stepGravity, stepJumpBuffer, stepScroll, stepSpeed } from './physics.js';
import { scrollObjects, spawnObjects } from './spawn.js';
import { state } from './state.js';
import { hitTemple, stepTemple } from './temple-chase.js';
import { stepCrossing } from './transitions.js';
import { u } from './view.js';
import { partStep } from './water-fx.js';

function stepPops(dt){
  for(const p of state.pops){p.y-=40*u*dt;p.a-=dt*1.6}
  state.pops=state.pops.filter(p=>p.a>0);
}
export function update(dt){
  partStep(dt);fpStep(dt);bfStep(dt);if(state.st==='ready'||state.st==='menu'){if(!(state.adv&&state.st==='ready'))state.dist+=60*u*dt;return}
  if(state.st==='drown'){state.dw.t+=dt;state.dw.vs+=((26*u-state.dw.sk)*40-state.dw.vs*5)*dt;state.dw.sk+=state.dw.vs*dt;if(state.dw.t>1.6)die();return}if(state.st!=='play')return;
  stepJumpBuffer(dt);
  const fl=stepFlight(dt);
  stepGravity(dt,fl);
  stepScroll(dt);
  updateScore();
  stepCrossing(dt,fl);
  stepSpeed(dt,fl);
  spawnObjects();
  scrollObjects(dt);
  stepTemple(dt);
  collectPickups(dt,fl);
  stepPops(dt);
  hitObstacles(fl);
  hitTemple(fl);
  if(state.adv)advStep(dt);
}
