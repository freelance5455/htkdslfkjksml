/*
 * jungle-temple.js - Updated Mangrove Jungle Temple terrain, trigger, and working lift state machine.
 * Ported from the tested single-file Temple implementation; shared game values live on state.
 */
import { ADV } from './config.js';
import { tpSn } from './audio.js';
import { state } from './state.js';
import { G, px, u, W } from './view.js';

export const TP={D:640,A:60,E:330,I:360,S0:374,SN:80,SW:36,S1:3254,KC:7908,CH:54,PH:52,END:8328};
export const tpS=k=>(state.tpU+k)*u-state.dist;
export const tpC=v=>Math.max(0,Math.min(1,v));
export const tpSm=v=>{v=tpC(v);return v*v*(3-2*v)};

export function tpDs(w){
  if(!state.tpOn)return 0;
  const k=w/u-state.tpU;
  if(k<TP.S0)return 0;
  if(k<TP.S1)return(k-TP.S0)/(TP.S1-TP.S0)*TP.D*u;
  const a=TP.KC-TP.PH-22;
  if(k<a)return TP.D*u;
  if(k<a+22)return TP.D*u-8*u*tpSm((k-a)/22);
  if(k<=TP.KC+TP.PH)return TP.D*u-8*u-state.tpH;
  return 0;
}
export function tpT(w){
  if(!state.tpOn)return 0;
  const k=w/u-state.tpU;
  if(k>=TP.S0&&k<TP.S1){
    const q=(k-TP.S0)/TP.SW,i=Math.floor(q),s=tpC((q-i-.65)/.35);
    return(i+s*s*(3-2*s))*(TP.D/TP.SN)*u;
  }
  return tpDs(w);
}
export function tpIn(w){
  if(!state.tpOn)return 0;
  const k=w/u-state.tpU;
  return tpSm((k-TP.A)/(TP.E-TP.A))*tpSm((TP.END-k)/240);
}
export function tpBlk(w){return state.tpOn&&w>(state.tpU-520)*u&&w<(state.tpU+TP.END+320)*u}
export function tpFull(){return state.tpOn&&state.tpCamY>G+30*u&&state.dist>=state.tpU*u}
export const tpIdle=()=>!!state.tpL&&state.tpL.ph>=2&&state.tpL.ph<8;

/* The Temple is due: its start condition holds (tpStep may still wait for the runner to stop flying). */
export const tpDue=()=>!state.tpDone&&state.bi===2&&!state.tr&&!state.aFin&&(state.adv?(state.pt>=(ADV.T[1]+ADV.T[2])/2&&state.pt<ADV.T[2]-70):state.score>=state.nb-5000);

export function tpStep(){
  if(state.tpOn){
    if(state.dist>(state.tpU+TP.END)*u+W+300*u){state.tpOn=false;state.tpL=null}
    return;
  }
  if(state.bi!==2)state.tpDone=false;
  if(!tpDue())return;
  if(state.fx.fly>0||state.items.some(b=>b.k==='fly'))return;  // no flight into the Temple: wait until the jetpack is spent and no Fly pickup is left ahead
  {
    state.tpU=(state.dist+W+900*u)/u;
    state.tpOn=true;state.tpDone=true;state.tpH=0;state.tpL=null;state.tpLDone=false;
    state.pops.push({x:W*.5,y:G*.4,a:2.2,t:'Mangrove Temple ahead'});
  }
}

/* Lift state machine: approach, anticipation, mechanism wake, ascent, slowing, settle, resume. */
export function tpUp(dt){
  if(!state.tpOn){state.tpL=null;return}
  const wp=px+17*u+state.dist,kp=wp/u-state.tpU,Hmax=TP.D*u-8*u,tgt=(state.tpU+TP.KC)*u-px-17*u;
  if(!state.tpL){
    if(!state.tpLDone&&kp>=TP.KC-200&&kp<TP.KC+30){
      state.tpL={ph:1,t:0,tn:0,sp:0,sn:0,h0:0};
      state.tpLDone=true;state.fx.fly=0;
    }
    return;
  }
  const L=state.tpL;L.t+=dt;
  if(L.ph<8){state.buf=0;state.hold=false;state.jumps=2}
  if(L.ph===1){
    if(tgt-state.dist<.6||kp>=TP.KC){state.dist=tgt;state.speed=0;L.ph=2;L.t=0;L.sn=.25}
  }else if(L.ph===2){
    L.tn=tpSm(L.t/1.4)*.6;L.sn-=dt;
    if(L.sn<=0){tpSn('rope');L.sn=.7}
    if(L.t>=1.4){L.ph=3;L.t=0;L.sn=.5;tpSn('creak');tpSn('pulley')}
  }else if(L.ph===3){
    const f=tpC(L.t/1.1);L.tn=.6+.4*tpSm(f);L.sp+=dt*(.4+f*1.6);
    state.tpH=3.2*u*Math.sin(f*Math.PI)*(1-.25*f);L.sn-=dt;
    if(L.sn<=0){tpSn(Math.random()<.5?'rope':'creak');L.sn=.55}
    if(L.t>=1.1){L.ph=4;L.t=0;L.h0=state.tpH;L.sn=.4}
  }else if(L.ph>=4&&L.ph<7){
    const T=9.5,a=tpC(L.t/T),r=a*a*a*(a*(6*a-15)+10);
    state.tpH=L.h0+(Hmax-L.h0)*r;L.tn=1;L.sp+=dt*(1.2+5*Math.sin(r*Math.PI));
    L.ph=a<.14?4:a<.78?5:6;L.sn-=dt;
    if(L.sn<=0){const q=Math.random();tpSn(q<.4?'creak':q<.7?'rope':'pulley');L.sn=L.ph===4?.9:L.ph===5?1.2+Math.random()*.6:1.6+a*1.4}
    if(a>=1){L.ph=7;L.t=0;state.tpH=Hmax;tpSn('settle')}
  }else if(L.ph===7){
    const a=tpC(L.t/.8);state.tpH=Hmax+1.4*u*Math.exp(-5*a)*Math.sin(a*18);L.tn=1-.5*a;L.sp+=dt*(1-a)*.8;
    if(L.t>.3&&!L.cr){L.cr=1;tpSn('creak')}
    if(L.t>=.8){L.ph=8;state.tpH=Hmax;state.speed=Math.max(state.speed,40*u)}
  }
}
export function tpHold(){
  if(!state.tpL||state.tpL.ph>=8)return;
  if(state.tpL.ph===1){
    const rem=(state.tpU+TP.KC)*u-px-17*u-state.dist;
    state.speed=Math.max(0,Math.min(state.speed,rem*4.5));
  }else state.speed=0;
}
