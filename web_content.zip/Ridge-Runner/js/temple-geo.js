/*
 * temple-geo.js - Floor and ceiling lines of the Mangrove Temple corridor, shared by the chase simulation and its drawing.
 */
import { TP, tpDs, tpSm } from './jungle-temple.js';
import { ter } from './physics.js';
import { state } from './state.js';
import { G, u } from './view.js';

/** Floor line (canvas y, before the camera offset) under screen x. */
export const hallFy=sx=>G+ter(sx);
/** Ceiling line of the corridor above screen x; the same curve tpCorr draws as the roof. */
export function hallCy(sx){
  const w=sx+state.dist,k=w/u-state.tpU;
  return G+tpDs(w)-(300+110*tpSm((k-(TP.S1-300))/300))*u;
}
