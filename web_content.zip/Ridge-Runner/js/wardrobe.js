/*
 * wardrobe.js - Wardrobe grid and its live preview canvases.
 */
import { t } from './clock.js';
import { $ } from './dom.js';
import { rr } from './draw-utils.js';
import { WK } from './outfit-parts.js';
import { acc, OUT, wa, wb, wk } from './outfits.js';
import { state } from './state.js';
import { ctx, px, setContext, setMetrics, u } from './view.js';

const grid=$('grid');
const PV=[];
/* ---- Wardrobe live previews: reuse the game's own outfit drawing ---- */
let pvN=0;
const PW=64;
const PH=58;
const PU=.72;
const pvD=Math.min(window.devicePixelRatio||1,2);
function pvDraw(o){
  const sv=[ctx,state.O,px,u,state.y,state.vy,state.st,state.rd,state.ob,state.dw,state.fx.fly];
  setContext(o.pc);ctx.setTransform(pvD,0,0,pvD,0,0);ctx.clearRect(0,0,PW,PH);
  state.O=o;setMetrics(PU,24);state.y=0;state.vy=0;state.st='play';state.rd=0;state.ob=false;state.dw=null;state.fx.fly=0;
  try{
    const s=34*u,run=Math.sin(t*16),bob=Math.abs(run)*2*u,top=27-bob,sy=top+11*u;
    ctx.fillStyle='rgba(0,0,0,.25)';ctx.beginPath();ctx.ellipse(px+s/2,27+s+1*u,s*.5,4*u,0,0,7);ctx.fill();
    ctx.strokeStyle=o.t;ctx.lineWidth=5*u;ctx.lineCap='round';
    if(!WK[o.k]){ctx.beginPath();ctx.moveTo(px+4*u,sy);ctx.quadraticCurveTo(px-14*u,sy+Math.sin(t*14)*5*u,px-32*u,sy+Math.sin(t*14+1)*6*u);ctx.stroke()}
    wk(top,s);
    for(let q=0;q<2;q++){const sg=q?-1:1,lift=Math.max(0,run*sg)*4*u,lx=px+s*(.3+q*.36)+run*sg*6*u;ctx.fillStyle=o.b;rr(lx-3.5*u,top+s*.7,7*u,s*.3-lift,3*u);ctx.fill();ctx.fillStyle='rgba(0,0,0,.3)';ctx.fill();ctx.fillStyle=o.s||'#2b2433';ctx.beginPath();ctx.ellipse(lx+2*u,top+s-2*u-lift*.5,6*u,3*u,0,0,7);ctx.fill()}
    ctx.fillStyle=o.b;rr(px,top,s,s*.8,10*u);ctx.fill();
    const bg=ctx.createLinearGradient(px,top,px+s,top+s*.8);bg.addColorStop(0,'rgba(255,255,255,.3)');bg.addColorStop(.55,'rgba(255,255,255,0)');bg.addColorStop(1,'rgba(0,0,0,.25)');
    ctx.fillStyle=bg;ctx.fill();ctx.strokeStyle='rgba(0,0,0,.32)';ctx.lineWidth=2*u;ctx.stroke();wb(top,s);
    {const sw=Math.sin(t*16+Math.PI);ctx.save();ctx.translate(px+s*.42,top+s*.46);ctx.rotate(sw*.9);ctx.fillStyle=o.b;rr(-3*u,0,6*u,13*u,3*u);ctx.fill();ctx.fillStyle='rgba(0,0,0,.22)';ctx.fill();ctx.fillStyle=o.h||'#f3d5b5';ctx.beginPath();ctx.arc(0,14*u,3.2*u,0,7);ctx.fill();ctx.restore()}
    ctx.fillStyle='rgba(255,120,140,.28)';ctx.beginPath();ctx.arc(px+s*.52,top+s*.54,3.6*u,0,7);ctx.fill();
    ctx.strokeStyle='rgba(0,0,0,.5)';ctx.lineWidth=1.6*u;ctx.beginPath();ctx.arc(px+s*.74,top+s*.5,3.4*u,.15*Math.PI,.85*Math.PI);ctx.stroke();
    ctx.fillStyle='#fff';ctx.beginPath();ctx.ellipse(px+s*.68,top+s*.38,5.2*u,6*u,0,0,7);ctx.fill();
    ctx.fillStyle=o.e;ctx.beginPath();ctx.arc(px+s*.68,top+s*.38,3.5*u,0,7);ctx.fill();
    acc(top,s);wa(top,s);
  }finally{setContext(sv[0]);state.O=sv[1];setMetrics(sv[3],sv[2]);[state.y,state.vy,state.st,state.rd,state.ob,state.dw,state.fx.fly]=sv.slice(4)}
}
export function pvAll(){for(const[o]of PV)pvDraw(o)}
/** Wires this module up to the DOM / storage. Called once from main.js during boot, in the original statement order. */
export function initWardrobe(){
  OUT.forEach((o,i)=>{if(o.sec){const h=document.createElement('div');h.className='sec';h.textContent=o.sec;grid.appendChild(h)}const b=document.createElement('button');b.className='chip';b.innerHTML='<canvas class="pv"></canvas>'+o.n;PV.push([o,b.firstChild]);b.onclick=()=>{state.O=o;try{localStorage.setItem('dd-out',i)}catch(e){};[...grid.children].forEach(c=>c.classList.toggle('on',c===b))};if(o===state.O)b.classList.add('on');grid.appendChild(b)});
  for(const[o,c]of PV){c.width=PW*pvD;c.height=PH*pvD;o.pc=c.getContext('2d')}
}
/** Alternates every frame so the wardrobe previews redraw at half the frame rate, as before. */
export function previewDue(){return (pvN^=1)}
