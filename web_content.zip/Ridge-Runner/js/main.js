/*
 * main.js - Entry point: boot sequence and the animation frame loop.
 */
import { initAudio } from './audio.js';
import { tick } from './clock.js';
import { $ } from './dom.js';
import { initInput } from './input.js';
import { initMenuArt, menuArtFrame } from './menu-art.js';
import { initOutfits } from './outfits.js';
import { draw } from './rendering.js';
import { initUI } from './ui.js';
import { update } from './update.js';
import { resize } from './view.js';
import { initWardrobe, previewDue, pvAll } from './wardrobe.js';

function frame(n){
  const dt=tick(n);update(dt);draw();menuArtFrame();if(!$('wardrobe').hidden&&previewDue())pvAll();requestAnimationFrame(frame);
}

/**
 * Boot: runs the DOM / storage wiring of each module in the same order the original single script ran it,
 * sizes the canvas, then starts the animation loop.
 */
function boot(){
  initUI();        // best score, mode chips, menu + admin + Adventure buttons
  initMenuArt();   // hand-drawn menu art (needs the chips initUI just created)
  initAudio();     // mute button
  initOutfits();   // saved outfit
  initWardrobe();  // wardrobe grid + preview canvases
  initInput();     // pointer / keyboard / resize listeners
  resize();
  requestAnimationFrame(frame);
}
boot();
