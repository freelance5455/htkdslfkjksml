/*
 * game.js - Game flow: reset, begin, die and the score update.
 */
import { advOver, advReset, advStart } from './adventure-mode.js';
import { snd } from './audio.js';
import { $, bs, card, msg, sc, ttl } from './dom.js';
import { state } from './state.js';
import { u } from './view.js';

export function reset(){state.tpOn=false;state.tpDone=false;state.tpL=null;state.tpLDone=false;state.tpH=0;state.tpCamY=0;state.tc=null;state.tt=[];state.obs=[];state.coins=[];state.pops=[];state.bonus=0;state.coinN=0;state.jumps=0;state.y=0;state.vy=0;state.dist=0;state.score=0;state.speed=230*u;state.items=[];state.pt=0;state.stage=-1;state.wasFly=false;state.fcd=0;state.nextFly=10;state.nFly=0;state.parts=[];state.rips=[];state.dw=null;state.cs=450;state.ce=830;state.fx={ghost:0,magnet:0,x2:0,slow:0,shield:0,fly:0};state.rd=1;state.bi=0;state.bw=0;state.bm=0;state.tq=0;state.tr=null;state.nb=5000;state.ob=false;state.rcd=0;state.cT=0;state.rz=-1e9;state.fp=[];state.bf=[];state.fap=0;state.fty=0;state.ftl=0;state.fpt=0;state.gap=0;state.buf=0;state.cut=false;sc.textContent='0';advReset()}
export function begin(){reset();if(state.adv)advStart();state.st='play';card.hidden=true;$('home').hidden=!state.adv;state.buf=.12}
export function die(){if(state.inv)return;
  state.st='over';state.overAt=performance.now();if(state.adv){advOver();return}
  if(state.score>state.best){state.best=state.score;try{localStorage.setItem('dd-best-'+state.mode,state.best)}catch(e){}bs.textContent='Best '+state.best}
  snd('d');ttl.textContent='Game over';msg.textContent='Score '+state.score+' with '+state.coinN+' coins. Tap to run again.';card.hidden=false;$('home').hidden=false;
}
export function updateScore(){
  const dp=Math.floor(state.dist/(10*u)),s=dp+state.bonus;
  if(!state.adv&&s!==state.score){state.score=s;sc.textContent=s}
}
