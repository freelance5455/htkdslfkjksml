/*
 * adventure-draw.js - Adventure mode drawing: checkpoint flags, finish gate and the biome base colours.
 */
import { bstar } from './boosters.js';
import { t } from './clock.js';
import { obSpk, wdot, wol } from './draw-utils.js';
import { ter } from './physics.js';
import { state } from './state.js';
import { ctx, G, u, W } from './view.js';

/* ---- drawing (never sets globalAlpha) ---- */
const advRGB=(a,b,k)=>'rgb('+a.map((v,i)=>Math.round(v+(b[i]-v)*k)).join(',')+')';
const advSk=(f,w1,c1,w2,c2)=>{f();ctx.strokeStyle=c1;ctx.lineWidth=w1*u;ctx.stroke();ctx.strokeStyle=c2;ctx.lineWidth=w2*u;ctx.stroke()};
function advBase(b,x,gy,gl,gr,fr){
  const yl=gy+(gl-gy)*1.5+2*u,yr=gy+(gr-gy)*1.5+2*u,ys=dx=>dx<0?gy+(gl-gy)*Math.min(1.6,-dx/(16*u)):gy+(gr-gy)*Math.min(1.6,dx/(16*u));
  const P=(h)=>{ctx.beginPath();ctx.moveTo(x-32*u,yl);ctx.bezierCurveTo(x-26*u,yl-8*u,x-14*u,gy-h*u,x,gy-h*u);ctx.bezierCurveTo(x+14*u,gy-h*u,x+26*u,yr-8*u,x+32*u,yr)};
  if(b===0){
    const S=fr?[[-15,5.6,7,'#aab0b7'],[19,4.8,6.2,'#9298a1']]:[[-26,4,5.2,'#868d96'],[-6,7.6,9.4,'#979ea7'],[11,8,8.4,'#b6bbc1'],[27,3.8,5,'#7f868f']];
    for(const[dx,ry,rx,c]of S){const cx=x+dx*u,cy=ys(dx*u)-ry*.5*u;ctx.fillStyle=c;ctx.beginPath();ctx.ellipse(cx,cy,rx*u,ry*u,0,0,7);ctx.fill();ctx.fillStyle='rgba(255,255,255,.3)';ctx.beginPath();ctx.ellipse(cx-rx*.25*u,cy-ry*.35*u,rx*.5*u,ry*.38*u,0,0,7);ctx.fill();ctx.beginPath();ctx.ellipse(cx,cy,rx*u,ry*u,0,0,7);wol(1.3)}
    if(fr){ctx.strokeStyle='#6aa36a';ctx.lineWidth=1.5*u;for(const dx of[-24,3,24]){const q=x+dx*u,w=ys(dx*u);ctx.beginPath();ctx.moveTo(q-2*u,w+u);ctx.lineTo(q-3*u,w-6*u);ctx.moveTo(q,w+u);ctx.lineTo(q+.5*u,w-8*u);ctx.moveTo(q+2*u,w+u);ctx.lineTo(q+4*u,w-5*u);ctx.stroke()}}
  }else if(b===1){
    if(!fr){const g=ctx.createLinearGradient(0,gy-18*u,0,gy+3*u);g.addColorStop(0,'#ffffff');g.addColorStop(1,'#c9dcef');P(18);ctx.closePath();ctx.fillStyle=g;ctx.fill();P(18);ctx.strokeStyle='rgba(70,105,150,.55)';ctx.lineWidth=1.6*u;ctx.stroke();obSpk(x-12*u,gy-12*u,x*.03);obSpk(x+15*u,gy-8*u,x*.03+2)}
    else{for(const[dx,rx,ry]of[[-11,9,4.4],[13,7,3.6]]){ctx.fillStyle='#f6fbff';ctx.beginPath();ctx.ellipse(x+dx*u,ys(dx*u)-ry*.4*u,rx*u,ry*u,0,Math.PI,0);ctx.fill();ctx.beginPath();ctx.ellipse(x+dx*u,ys(dx*u)-ry*.4*u,rx*u,ry*u,0,Math.PI,0);ctx.strokeStyle='rgba(70,105,150,.5)';ctx.lineWidth=1.3*u;ctx.stroke()}}
  }else{
    if(!fr){const g=ctx.createLinearGradient(0,gy-16*u,0,gy+3*u);g.addColorStop(0,'#6e5c3f');g.addColorStop(1,'#3d3123');P(15);ctx.closePath();ctx.fillStyle=g;ctx.fill();P(15);ctx.strokeStyle='rgba(22,14,8,.65)';ctx.lineWidth=1.6*u;ctx.stroke();
      ctx.fillStyle='rgba(170,205,185,.22)';ctx.beginPath();ctx.ellipse(x-9*u,gy-7*u,7*u,2.2*u,-.2,0,7);ctx.fill();ctx.beginPath();ctx.ellipse(x+14*u,gy-5*u,5*u,1.8*u,.15,0,7);ctx.fill()}
    else{for(const[s0,cx,ex]of[[-5,-16,-31],[5,15,32],[-1,-6,-17]]){const ey=ys(ex*u)+u;
      advSk(()=>{ctx.beginPath();ctx.moveTo(x+s0*u,gy-11*u);ctx.quadraticCurveTo(x+cx*u,gy-22*u,x+ex*u,ey)},4.8,'rgba(28,18,8,.8)',2.6,'#7a5a38');
      ctx.strokeStyle='rgba(255,225,170,.3)';ctx.lineWidth=.9*u;ctx.beginPath();ctx.moveTo(x+s0*u,gy-12*u);ctx.quadraticCurveTo(x+cx*u,gy-23*u,x+ex*u*.9,ey-1.4*u);ctx.stroke()}
      for(const r of[-.7,.6]){ctx.fillStyle='#6fb36f';ctx.beginPath();ctx.ellipse(x+21*u+r*5*u,ys(21*u)-6*u,2.2*u,5*u,r,0,7);ctx.fill();wol(1.1)}}
  }
}
function advFlagDraw(f){
  const x=f.x-state.dist;if(x<-60*u||x>W+70*u)return;
  const gy=G+ter(x),gl=G+ter(x-16*u),gr=G+ter(x+16*u),hp=80*u;
  const ke=f.on?(f.t0===-9?1:Math.min(1,(t-f.t0)/.45)):0,e=1-Math.pow(1-ke,3);
  ctx.save();ctx.lineJoin=ctx.lineCap='round';
  advBase(f.b,x,gy,gl,gr,0);
  ctx.beginPath();ctx.moveTo(x-8*u,gy+1.5*u);ctx.lineTo(x-5*u,gy-13*u);ctx.quadraticCurveTo(x,gy-16*u,x+5*u,gy-13*u);ctx.lineTo(x+8*u,gy+1.5*u);ctx.closePath();
  const sg=ctx.createLinearGradient(x-8*u,0,x+8*u,0);sg.addColorStop(0,'#ffffff');sg.addColorStop(1,'#d9dde6');ctx.fillStyle=sg;ctx.fill();wol(1.4);
  advSk(()=>{ctx.beginPath();ctx.moveTo(x,gy-12*u);ctx.lineTo(x,gy-hp)},6,'rgba(0,0,0,.34)',3.6,'#fffdf4');
  ctx.strokeStyle='rgba(255,255,255,.95)';ctx.lineWidth=1.1*u;ctx.beginPath();ctx.moveTo(x-.9*u,gy-14*u);ctx.lineTo(x-.9*u,gy-hp+2*u);ctx.stroke();
  wdot(x,gy-hp-u,3.4*u,'#f2c14e');ctx.strokeStyle='rgba(0,0,0,.32)';ctx.lineWidth=1.3*u;ctx.stroke();wdot(x-u,gy-hp-2*u,1.1*u,'#fff3b0');
  const yT=gy-(32+44*e)*u,wc=(13+23*e)*u,hc=(11+13*e)*u,am=(.8+3.2*e)*u,ph=t*(1.6+4*e)+f.x*.013,N=8,A=[],B=[];
  for(let i=0;i<=N;i++){const q=i/N,wv=Math.sin(ph-q*3.4)*am*q,dr=(1-e)*q*q*6*u;A.push([x+2*u+q*wc,yT+wv+dr*.4]);B.push([x+2*u+q*wc,yT+hc*(1-.12*q*e)+wv*1.1+dr])}
  ctx.beginPath();A.forEach((p,i)=>i?ctx.lineTo(p[0],p[1]):ctx.moveTo(p[0],p[1]));
  ctx.lineTo(A[N][0]-(4+5*e)*u,(A[N][1]+B[N][1])/2);ctx.lineTo(B[N][0],B[N][1]);for(let i=N-1;i>=0;i--)ctx.lineTo(B[i][0],B[i][1]);ctx.closePath();
  const cg=ctx.createLinearGradient(x,0,x+wc+2*u,0);cg.addColorStop(0,advRGB([157,146,153],[240,74,86],e));cg.addColorStop(1,advRGB([118,108,116],[186,30,50],e));
  ctx.fillStyle=cg;ctx.fill();ctx.strokeStyle='rgba(50,10,20,.55)';ctx.lineWidth=1.5*u;ctx.stroke();
  ctx.strokeStyle='rgba(255,255,255,.25)';ctx.lineWidth=2*u;ctx.beginPath();for(let i=0;i<=N-1;i++){const m=(A[i][1]*.65+B[i][1]*.35);i?ctx.lineTo(A[i][0],m):ctx.moveTo(A[i][0],m)}ctx.stroke();
  wdot(x+1*u,yT+2*u,1.6*u,'#e8c04a');wdot(x+1*u,yT+hc-2*u,1.6*u,'#e8c04a');
  advBase(f.b,x,gy,gl,gr,1);
  if(e>=1){const p2=(t*.9+f.x*.01)%1;if(p2<.35)bstar(A[N][0],A[N][1]+hc*.3,(1-p2/.35)*4*u,'rgba(255,255,255,.95)')}
  ctx.restore();
}
function advGate(){
  const sx=state.aFin.gx-state.dist;if(sx>W+170*u||sx<-170*u)return;
  const hw=74*u,xl=sx-hw,xr=sx+hw,yl=G+ter(xl),yr=G+ter(xr),hh=128*u,ty1=yl-hh,ty2=yr-hh,yc=(ty1+ty2)/2-24*u,xa=xl-10*u,xb=xr+10*u;
  const Q=q=>[(1-q)*(1-q)*xa+2*q*(1-q)*sx+q*q*xb,(1-q)*(1-q)*ty1+2*q*(1-q)*yc+q*q*ty2];
  ctx.save();ctx.lineJoin=ctx.lineCap='round';
  for(const[x0,y0,s]of[[xl,yl,-1],[xr,yr,1]]){
    for(const k of[.9,.5])advSk(()=>{ctx.beginPath();ctx.moveTo(x0,y0-16*u*k);ctx.quadraticCurveTo(x0+s*16*u,y0-17*u*k-4*u,x0+s*(24+8*k)*u,y0+2*u)},4.6,'rgba(38,24,12,.75)',2.6,'#5a3f26');
    advSk(()=>{ctx.beginPath();ctx.moveTo(x0,y0+2*u);ctx.lineTo(x0,y0-hh)},12,'rgba(34,20,10,.7)',8.4,'#7b5636');
    ctx.strokeStyle='rgba(255,220,170,.3)';ctx.lineWidth=2*u;ctx.beginPath();ctx.moveTo(x0-2.4*u,y0-4*u);ctx.lineTo(x0-2.4*u,y0-hh+4*u);ctx.stroke();
    ctx.strokeStyle='#e3cf98';ctx.lineWidth=2.4*u;for(const k of[.25,.55,.85]){ctx.beginPath();ctx.moveTo(x0-4.8*u,y0-hh*k);ctx.lineTo(x0+4.8*u,y0-hh*k);ctx.stroke()}}
  advSk(()=>{ctx.beginPath();ctx.moveTo(xa,ty1);ctx.quadraticCurveTo(sx,yc,xb,ty2)},11,'rgba(34,20,10,.7)',8,'#8a6340');
  for(let i=0;i<8;i++){const[bx,by]=Q((i+.5)/8),a=(i%2?.5:-.5)+Math.sin(t*2+i)*.15;ctx.fillStyle=i%2?'#4f9a56':'#7bc47f';ctx.beginPath();ctx.ellipse(bx,by+5*u,3*u,7*u,a,0,7);ctx.fill();wol(1)}
  const cl=['#e63946','#ffd23f','#7bc47f','#fff3cf','#5ab0e0'];
  for(let i=0;i<9;i++){const q=(i+1)/10;if(q>.33&&q<.67)continue;const[bx,by]=Q(q),sw=Math.sin(t*3+i)*1.6*u;ctx.fillStyle=cl[i%5];ctx.beginPath();ctx.moveTo(bx-7*u,by+5*u);ctx.lineTo(bx+7*u,by+5*u);ctx.lineTo(bx+sw,by+21*u);ctx.closePath();ctx.fill();wol(1.1)}
  const[mx,my]=Q(.5),bw2=104*u,bh=26*u,b0=my+8*u,wv=q=>Math.sin(t*2.6+q*4)*1.6*u;
  ctx.strokeStyle='#e3cf98';ctx.lineWidth=2*u;for(const s of[-1,1]){ctx.beginPath();ctx.moveTo(mx+s*bw2*.45,my+3*u);ctx.lineTo(mx+s*bw2*.45,b0+wv(s>0?1:0));ctx.stroke()}
  ctx.beginPath();for(let i=0;i<=10;i++){const q=i/10;i?ctx.lineTo(mx-bw2/2+q*bw2,b0+wv(q)):ctx.moveTo(mx-bw2/2,b0+wv(0))}for(let i=10;i>=0;i--){const q=i/10;ctx.lineTo(mx-bw2/2+q*bw2,b0+bh+wv(q))}ctx.closePath();
  ctx.fillStyle='#fff3cf';ctx.fill();ctx.strokeStyle='#c1272d';ctx.lineWidth=2.4*u;ctx.stroke();wol(1);
  ctx.font='800 '+(15*u)+'px "Bricolage Grotesque",system-ui,sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillStyle='#b5222c';ctx.fillText('FINISH',mx,b0+bh/2+wv(.5));
  ctx.restore();
}
export function advDraw(){for(const f of state.aFl)advFlagDraw(f);if(state.aFin)advGate()}
