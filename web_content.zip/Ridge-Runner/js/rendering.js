/*
 * rendering.js - The per-frame draw step: draw() paints the layers back to front.
 */
import { advDraw } from './adventure-draw.js';
import { bgClouds, bgHill, bgMist, bgMtn, bgPine, bgSun, snowfall, vig } from './backgrounds.js';
import { GP, l3, PG, PM, PS } from './biomes.js';
import { bfDraw, bFront, bHud, coinFx, drawItem, slowTint } from './boosters.js';
import { cave2 } from './caves.js';
import { t } from './clock.js';
import { lc } from './draw-utils.js';
import { gnd, rv } from './ground.js';
import { tpDs, tpFull } from './jungle-temple.js';
import { tpFront, tpScene } from './jungle-temple-scene.js';
import { bgMang, obMang, sea } from './mangrove.js';
import { drone, gob, nat, pondDraw, snw } from './obstacles.js';
import { ter } from './physics.js';
import { drawRunner } from './player.js';
import { state } from './state.js';
import { tcShake } from './temple-chase.js';
import { drawBoulder } from './temple-boulder-art.js';
import { drawTraps } from './temple-trap-art.js';
import { ctx, G, H, layers, px, u, W } from './view.js';
import { dparts, front } from './water-fx.js';

/** Sky, sun, clouds, parallax layers, mangrove backdrop, haze and ground (skipped when a cave fills the whole screen). */
function drawBackdrop(){
  /* Everything below the ground line is covered by the opaque ground, so sky/hill fills stop just under it (not during river crossings, where the ground is drawn in two halves). */
  state.hb=state.tr?H:Math.min(H,G+2);
  const g=ctx.createLinearGradient(0,0,0,G);
  [0,.45,.8,1].forEach((q,i)=>g.addColorStop(q,l3(PM.sky[i],PS.sky[i],PG.sky[i])));
  ctx.fillStyle=g;ctx.fillRect(0,0,W,state.hb);
  bgSun();bgClouds();
  const sa=state.tr&&state.tr.sea,oa=sa?Math.max(0,1-state.bm/.45):1-state.bm,ma=sa?Math.max(0,(state.bm-.55)/.45):state.bm;if(oa>.01){ctx.globalAlpha=oa;layers.forEach((L,i)=>{L.col=lc(PM[L.pk],PS[L.pk],state.bw);const off=(state.dist*L.k)%L.tw;if(L.ty==='h')bgHill(L);else if(L.ty==='m')bgMtn(L,off);else bgPine(L,off);if(i===1)bgMist()});ctx.globalAlpha=1}if(ma>.01){ctx.globalAlpha=ma;bgMang();ctx.globalAlpha=1}
  const fg=ctx.createLinearGradient(0,G-140*u,0,G);fg.addColorStop(0,lc('#f3dfb8','#dfeaf6',state.bw,0));fg.addColorStop(1,lc('#f3dfb8','#dfeaf6',state.bw,.4));ctx.fillStyle=fg;ctx.fillRect(0,G-140*u,W,140*u);
  if(state.tr){const mx=(state.tr.rs+state.tr.re)/2-state.dist;ctx.save();ctx.beginPath();ctx.rect(-10,0,mx+10,H);ctx.clip();gnd(GP[state.tr.from]);ctx.restore();ctx.save();ctx.beginPath();ctx.rect(mx,0,W+10-mx,H);ctx.clip();gnd(GP[state.tr.to]);ctx.restore()}else gnd(GP[state.bi]);
}
function drawObstacles(){
  for(const o of state.obs){
    if(o.n)continue;ctx.globalAlpha=state.fx.ghost>0?.45:1;ctx.save();ctx.translate(0,ter(o.x+o.w*.5));if(o.m)obMang(o);else if(o.p)pondDraw(o);else if(o.f>0)drone(o);else{ctx.fillStyle='rgba(0,0,0,.22)';ctx.beginPath();ctx.ellipse(o.x+o.w*.5,G+2*u,o.w*.6,4*u,0,0,7);ctx.fill();o.b?(o.c?gob(o):snw(o)):nat(o)}ctx.restore();continue;
  }
}
function drawCoins(){
  for(const c of state.coins){const cy=G+ter(c.x)-c.h;coinFx(c,cy);const rw=Math.max(2*u,10*u*Math.abs(Math.cos(t*5+c.x*.02)));ctx.fillStyle='#ffd23f';ctx.beginPath();ctx.ellipse(c.x,cy,rw,10*u,0,0,7);ctx.fill();ctx.strokeStyle='#d99a00';ctx.lineWidth=2*u;ctx.stroke()}
}
function drawPopups(){
  ctx.textBaseline='alphabetic';
  ctx.font='800 '+(18*u)+'px "Bricolage Grotesque",system-ui,sans-serif';ctx.textAlign='center';
  ctx.lineJoin='round';ctx.lineWidth=5*u;for(const p of state.pops){ctx.globalAlpha=Math.max(0,Math.min(1,p.a));ctx.strokeStyle='rgba(24,18,44,.78)';ctx.strokeText(p.t,p.x,p.y);ctx.fillStyle=p.c||'#ffd23f';ctx.fillText(p.t,p.x,p.y)}
}
export function draw(){
  state.tpCamY=state.tpOn?tpDs(px+17*u+state.dist):0;
  ctx.save();if(state.tpCamY>.4)ctx.translate(0,-state.tpCamY);
  if(state.tc){const q=tcShake();ctx.translate(q.x,q.y)}
  /* A cave that spans the whole screen repaints every pixel with an opaque fill (see cvMain), so the outdoor scene behind it can never be seen: skip it. */
  const cvFull=!state.tr&&state.st!=='menu'&&state.st!=='ready'&&((px+state.cs*10*u-state.dist<=0&&px+state.ce*10*u-state.dist>=W)||tpFull());
  if(cvFull){ctx.lineJoin='round';ctx.lineCap='round'}else drawBackdrop();
  cave2();tpScene();state.tr&&state.tr.sea?sea():rv();
  drawObstacles();
  ctx.globalAlpha=1;drawTraps();drawBoulder();if(state.adv)advDraw();
  drawCoins();
  for(const b of state.items)drawItem(b);
  drawPopups();
  ctx.globalAlpha=1;bfDraw();
  const{top,s}=drawRunner();
  if(state.dw)front();dparts();ctx.globalAlpha=1;tpFront();
  bFront(top,s);
  ctx.restore();bHud();
  ctx.textBaseline='alphabetic';
  if(state.bw>.02)snowfall();slowTint();vig();
}
