/*
 * temple-trap-art.js - Hand-drawn Mangrove Temple traps: trapdoor, bamboo spike plate, naga fire-pot and falling roof slab.
 * Reads the trap list on state.tt (see temple-chase.js); nothing here changes game state.
 */
import { t } from './clock.js';
import { BOV, BPG, BSP, BST, bgH, rr, wdot, wol } from './draw-utils.js';
import { state } from './state.js';
import { hallCy, hallFy } from './temple-geo.js';
import { puff, rockChunk } from './temple-boulder-art.js';
import { ctx, u, W } from './view.js';

export const SPK_H=44,SLAB_H=62;
const ease=a=>a*a*(3-2*a);

/* ---------- trapdoor ---------- */
/** One thick stone leaf, hinged at its lower outer corner (hx,hy); dir 1 = hinge on the left, -1 = on the right. ang 0 = lying flat, ~1.5 = hanging into the pit. */
function leaf(hx,hy,dir,L,ang){
  const th=18*u;
  ctx.save();ctx.translate(hx,hy);ctx.scale(dir,1);ctx.rotate(ang);
  const g=ctx.createLinearGradient(0,-th,0,0);g.addColorStop(0,'#8a9a86');g.addColorStop(.18,'#62756a');g.addColorStop(1,'#3b4c41');
  rr(0,-th,L-1*u,th,2.5*u);ctx.fillStyle=g;ctx.fill();wol(1.6);
  ctx.strokeStyle='rgba(235,245,225,.55)';ctx.lineWidth=1.3*u;ctx.beginPath();ctx.moveTo(4*u,-th+1.4*u);ctx.lineTo(L-6*u,-th+1.4*u);ctx.stroke();
  ctx.strokeStyle='rgba(190,225,190,.3)';ctx.lineWidth=1.1*u;ctx.beginPath();const mx=L*.47,my=-th*.46;ctx.moveTo(mx-7*u,my);ctx.lineTo(mx,my-6*u);ctx.lineTo(mx+7*u,my);ctx.lineTo(mx,my+6*u);ctx.closePath();ctx.stroke();
  for(const q of[.16,.78]){const bx=L*q;ctx.fillStyle='#c9b25a';rr(bx-2.4*u,-th-1.2*u,4.8*u,th+2.4*u,1.4*u);ctx.fill();wol(1);ctx.strokeStyle='rgba(255,250,200,.55)';ctx.lineWidth=.8*u;ctx.beginPath();ctx.moveTo(bx-.9*u,-th);ctx.lineTo(bx-.9*u,-1*u);ctx.stroke()}
  ctx.strokeStyle='#3b3026';ctx.lineWidth=1.6*u;ctx.beginPath();ctx.arc(L-11*u,-th-1*u,2.8*u,Math.PI,0);ctx.stroke();
  ctx.restore();
}
function door(r,x,fy){
  const w=r.w,pd=50*u,L=w/2,a=r.ph===2?r.pt:0,o=r.ph===2?ease(Math.min(1,a/.24)):0;
  const ang=r.ph===2?1.5*ease(Math.min(1,a/.24))+(a>.24?.1*Math.exp(-7*(a-.24))*Math.sin((a-.24)*24):0):0;
  const jit=r.ph===1?Math.sin(r.pt*75)*1.1*u:0;
  /* the pit, seen in section: dark back wall of laid stone, bamboo stakes at the bottom; hidden under floor-coloured stone until the leaves open */
  ctx.save();rr(x,fy-2*u,w,pd+2*u,5*u);ctx.clip();
  let g=ctx.createLinearGradient(0,fy,0,fy+pd);g.addColorStop(0,'#04100b');g.addColorStop(1,'#0e2018');ctx.fillStyle=g;ctx.fillRect(x,fy-2*u,w,pd+2*u);
  ctx.strokeStyle='rgba(120,170,140,.13)';ctx.lineWidth=1.2*u;ctx.beginPath();
  for(let q=0;q<4;q++){const y=fy+(5+q*13)*u;ctx.moveTo(x,y);ctx.lineTo(x+w,y);for(let xx=x+((q&1)?10:22)*u;xx<x+w;xx+=24*u){ctx.moveTo(xx,y);ctx.lineTo(xx,y+13*u)}}
  ctx.stroke();
  const n=Math.max(4,Math.round(w/13)),by=fy+pd-1*u;
  for(let i=0;i<n;i++){
    const cx=x+(i+.5)*w/n+(bgH(r.s,i)-.5)*4*u,h=(17+bgH(r.s,i+9)*11)*u;
    BPG('#a8964f',cx-3.2*u,by,cx-2.2*u,by-h*.8,cx,by-h,cx+2.2*u,by-h*.8,cx+3.2*u,by);
    ctx.strokeStyle='rgba(60,40,10,.5)';ctx.lineWidth=1*u;ctx.beginPath();ctx.moveTo(cx-2.8*u,by-h*.4);ctx.lineTo(cx+2.8*u,by-h*.4);ctx.stroke();
    ctx.strokeStyle='rgba(255,250,200,.4)';ctx.lineWidth=.8*u;ctx.beginPath();ctx.moveTo(cx-1.2*u,by-2*u);ctx.lineTo(cx-.6*u,by-h*.8);ctx.stroke();
  }
  g=ctx.createLinearGradient(0,fy,0,fy+pd);g.addColorStop(0,'rgba(2,8,6,.8)');g.addColorStop(1,'rgba(2,8,6,.12)');ctx.fillStyle=g;ctx.fillRect(x,fy-2*u,w,pd+2*u);
  ctx.fillStyle='rgba(130,210,170,'+((.05+.04*Math.sin(t*1.7+r.s))*o).toFixed(3)+')';ctx.beginPath();ctx.ellipse(x+w/2,fy+8*u,w*.45,6*u,0,0,7);ctx.fill();
  if(o<1){g=ctx.createLinearGradient(0,fy,0,fy+pd);const ca=(1-o).toFixed(3);g.addColorStop(0,'rgba(38,53,44,'+ca+')');g.addColorStop(.5,'rgba(34,48,40,'+ca+')');g.addColorStop(.56,'rgba(25,28,19,'+ca+')');g.addColorStop(1,'rgba(24,26,18,'+ca+')');ctx.fillStyle=g;ctx.fillRect(x,fy-2*u,w,pd+2*u)}
  ctx.restore();
  /* the two stone leaves on their hinges */
  const hy=fy-1*u+18*u;
  leaf(x+jit,hy,1,L,ang);leaf(x+w-jit,hy,-1,L,ang);
  wdot(x,hy,2.8*u,'#3b3026');wdot(x+w,hy,2.8*u,'#3b3026');
  if(ang<.4){ /* hairline cracks and moss along the seam give the plates away */
    ctx.strokeStyle='rgba(0,0,0,.34)';ctx.lineWidth=1.1*u;ctx.beginPath();ctx.moveTo(x+L-1*u,fy-1.5*u);ctx.lineTo(x+L+2*u,fy+4*u);ctx.lineTo(x+L-2*u,fy+9*u);ctx.stroke();
    ctx.fillStyle='rgba(95,150,70,.7)';ctx.beginPath();ctx.ellipse(x+L*.55,fy-1.4*u,7*u,2*u,0,0,7);ctx.fill();
  }
  if(r.ph===1){ /* dust sifting out of the seam */
    for(let q=0;q<7;q++){const k=(r.pt*2.2+q*.17)%1;ctx.fillStyle='rgba(205,195,150,'+((1-k)*.8).toFixed(2)+')';ctx.beginPath();ctx.arc(x+L+(bgH(r.s,q)-.5)*16*u,fy+1*u+k*26*u,1.3*u,0,7);ctx.fill()}
  }
}

/* ---------- bamboo spike plate ---------- */
function stake(cx,by,h){
  if(h<1.5*u)return;
  BPG('#dcc974',cx-3.6*u,by,cx-2.5*u,by-h*.82,cx,by-h,cx+2.5*u,by-h*.82,cx+3.6*u,by);
  if(h>12*u){
    ctx.strokeStyle='rgba(80,56,14,.55)';ctx.lineWidth=1*u;ctx.beginPath();ctx.moveTo(cx-3.2*u,by-h*.3);ctx.lineTo(cx+3.2*u,by-h*.3);ctx.moveTo(cx-2.9*u,by-h*.6);ctx.lineTo(cx+2.9*u,by-h*.6);ctx.stroke();
    BPG('#8a5f24',cx-2.2*u,by-h*.84,cx,by-h,cx+2.2*u,by-h*.84,cx,by-h*.78);
    ctx.strokeStyle='rgba(255,250,200,.55)';ctx.lineWidth=.9*u;ctx.beginPath();ctx.moveTo(cx-1.6*u,by-2*u);ctx.lineTo(cx-1.1*u,by-h*.8);ctx.stroke();
  }
}
function spike(r,x,fy){
  const w=r.w,n=Math.max(5,Math.round(w/16)),sp=w/n;
  const g=ctx.createLinearGradient(0,fy-2*u,0,fy+8*u);g.addColorStop(0,'#7d8f80');g.addColorStop(1,'#4a5b50');
  rr(x-3*u,fy-2*u,w+6*u,9*u,3*u);ctx.fillStyle=g;ctx.fill();wol(1.6);
  ctx.strokeStyle='rgba(235,245,225,.5)';ctx.lineWidth=1.2*u;ctx.beginPath();ctx.moveTo(x,fy-.8*u);ctx.lineTo(x+w,fy-.8*u);ctx.stroke();
  ctx.strokeStyle='rgba(20,32,24,.4)';ctx.lineWidth=1*u;ctx.beginPath();ctx.moveTo(x+w*.5,fy+1*u);ctx.lineTo(x+w*.5,fy+6.5*u);ctx.stroke();
  for(let i=0;i<n;i++){
    const cx=x+(i+.5)*sp,h=r.a*SPK_H*u*(.84+.28*bgH(r.s,i)),jx=r.ph===1?Math.sin(r.pt*90+i*2)*.9*u:0;
    ctx.fillStyle='#050c09';rr(cx-4.4*u,fy-2.4*u,8.8*u,3.4*u,1.4*u);ctx.fill();
    stake(cx+jx,fy+.6*u,h);
    if(r.ph===1){const k=(r.pt*3+i*.31)%1;puff(cx+(bgH(r.s,i+3)-.5)*8*u,fy-3*u-k*12*u,4*u,(1-k)*.5)}
  }
  if(r.ph===2&&r.pt<.4)for(let i=0;i<n;i+=2){const k=r.pt/.4;puff(x+(i+.5)*sp,fy-4*u-k*16*u,(5+k*7)*u,(1-k)*.55)}
}

/* ---------- naga fire-pot ---------- */
function fire(cx,by,h,A,seed){
  if(h<2*u)return;
  ctx.save();ctx.globalCompositeOperation='lighter';
  const gr=46*u+h*1.1,gg=ctx.createRadialGradient(cx,by-h*.4,3*u,cx,by-h*.4,gr);gg.addColorStop(0,'rgba(255,170,70,'+(.16+.3*A).toFixed(3)+')');gg.addColorStop(1,'rgba(255,150,60,0)');
  ctx.fillStyle=gg;ctx.beginPath();ctx.arc(cx,by-h*.4,gr,0,7);ctx.fill();ctx.restore();
  const layers=[[1,'#ff6a12'],[.74,'#ffa526'],[.46,'#ffe27a'],[.24,'#fff6cf']];
  layers.forEach(([s,col],i)=>{
    const hh=h*s*(.93+.07*Math.sin(t*17+seed+i)),wb=(11*(.55+.45*A))*u*s+1.2*u,sw=Math.sin(t*13+seed+hh*.05)*3.2*u*A*s;
    ctx.fillStyle=col;ctx.beginPath();ctx.moveTo(cx-wb,by);ctx.quadraticCurveTo(cx-wb*1.2,by-hh*.45,cx+sw,by-hh);ctx.quadraticCurveTo(cx+wb*1.2,by-hh*.45,cx+wb,by);ctx.quadraticCurveTo(cx,by+3*u*s,cx-wb,by);ctx.fill();
    if(i===0)wol(1.2);
  });
  if(A>.5){const lh=h*.55;ctx.fillStyle='#ff8a1e';ctx.beginPath();ctx.moveTo(cx+7*u,by-h*.1);ctx.quadraticCurveTo(cx+15*u,by-lh*.7,cx+13*u+Math.sin(t*11+seed)*3*u,by-lh);ctx.quadraticCurveTo(cx+8*u,by-lh*.6,cx+4*u,by-h*.1);ctx.fill()}
  for(let i=0;i<5;i++){const k=((t*.9+i*.21+seed*.1)%1);BSP(cx+Math.sin(t*3+i*1.7+seed)*10*u*A,by-k*(h+30*u),(1.6+1.2*(1-k))*u,'rgba(255,220,130,'+(1-k).toFixed(2)+')')}
}
function flame(r,x,fy){
  const cx=x+r.w/2,A=r.a;
  /* two-tier pedestal */
  let g=ctx.createLinearGradient(0,fy-14*u,0,fy+2*u);g.addColorStop(0,'#728578');g.addColorStop(1,'#4a5b50');
  rr(cx-23*u,fy-13*u,46*u,15*u,3*u);ctx.fillStyle=g;ctx.fill();wol(1.6);
  ctx.strokeStyle='rgba(190,225,190,.3)';ctx.lineWidth=1.1*u;ctx.beginPath();for(let q=0;q<4;q++){const dx=cx-17*u+q*11.3*u;ctx.moveTo(dx-4*u,fy-6*u);ctx.lineTo(dx,fy-10*u);ctx.lineTo(dx+4*u,fy-6*u);ctx.lineTo(dx,fy-2.5*u);ctx.closePath()}ctx.stroke();
  g=ctx.createLinearGradient(0,fy-29*u,0,fy-12*u);g.addColorStop(0,'#7f8d7c');g.addColorStop(1,'#55675a');
  rr(cx-16*u,fy-28*u,32*u,16*u,3*u);ctx.fillStyle=g;ctx.fill();wol(1.6);
  ctx.strokeStyle='rgba(255,255,255,.22)';ctx.lineWidth=1.1*u;ctx.beginPath();ctx.moveTo(cx-12*u,fy-26*u);ctx.lineTo(cx+10*u,fy-26*u);ctx.stroke();
  /* stone naga coiled round the pot, hood leaning over the flame */
  BST('rgba(6,16,10,.75)',8,cx-17*u,fy-20*u,cx,fy-14*u,cx+17*u,fy-23*u);BST('#4d6b4a',5.6,cx-17*u,fy-20*u,cx,fy-14*u,cx+17*u,fy-23*u);
  BST('rgba(210,240,170,.35)',1.2,cx-15*u,fy-22*u,cx,fy-16*u,cx+15*u,fy-25*u);
  ctx.strokeStyle='rgba(6,16,10,.45)';ctx.lineWidth=1*u;ctx.beginPath();for(let q=0;q<6;q++){const dx=cx-13*u+q*5.4*u;ctx.moveTo(dx,fy-21*u+q*.2*u);ctx.lineTo(dx+1.5*u,fy-16.5*u)}ctx.stroke();
  BST('rgba(6,16,10,.75)',8,cx-15*u,fy-24*u,cx-26*u,fy-36*u,cx-14*u,fy-47*u);BST('#4d6b4a',5.6,cx-15*u,fy-24*u,cx-26*u,fy-36*u,cx-14*u,fy-47*u);
  BOV(cx-12*u,fy-50*u,8.4*u,10.4*u,'#4d6b4a',-.25);
  ctx.strokeStyle='rgba(6,16,10,.5)';ctx.lineWidth=1*u;for(let q=0;q<3;q++){ctx.beginPath();ctx.arc(cx-12*u,fy-50*u,(3.2+q*2.3)*u,-1.1,1.2);ctx.stroke()}
  wdot(cx-8*u,fy-52*u,2.1*u,'#ffd23f');wdot(cx-7.6*u,fy-52*u,.9*u,'#1b0f06');
  BST('#d63a3a',1.3,cx-4*u,fy-47*u,cx,fy-46*u,cx+3.5*u,fy-48.5*u);BST('#d63a3a',1.1,cx-1*u,fy-46.2*u,cx+2*u,fy-45*u,cx+4*u,fy-44*u);
  /* brazier bowl */
  BPG('#5a4a2e',cx-11*u,fy-28*u,cx+11*u,fy-28*u,cx+16*u,fy-38*u,cx-16*u,fy-38*u);
  ctx.strokeStyle='rgba(255,230,160,.4)';ctx.lineWidth=1.1*u;ctx.beginPath();ctx.moveTo(cx-9*u,fy-30*u);ctx.lineTo(cx-12.5*u,fy-36*u);ctx.stroke();
  BOV(cx,fy-38*u,16.6*u,3.4*u,'#7a6540');BOV(cx,fy-38.4*u,13*u,2.1*u,'#1b0f06');
  /* fire: a pilot flame always burns; it roars up when the runner draws near */
  const h=(7+Math.sin(t*9+r.s)*1.5+A*A*SPK_H)*u;
  fire(cx+1*u,fy-38.6*u,h,A,r.s);
}

/* ---------- falling roof slab ---------- */
function block(x,y,w,h,s){
  const c=[[x,y+3*u],[x+4*u,y],[x+w-3*u,y+1*u],[x+w,y+5*u],[x+w-1*u,y+h-4*u],[x+w-5*u,y+h],[x+3*u,y+h-1*u],[x,y+h-6*u]].map((p,i)=>[p[0]+(bgH(s,i)-.5)*2*u,p[1]+(bgH(s,i+8)-.5)*2*u]);
  const g=ctx.createLinearGradient(x,0,x+w,0);g.addColorStop(0,'#46574c');g.addColorStop(.4,'#7f9082');g.addColorStop(1,'#37473d');
  ctx.beginPath();c.forEach((p,i)=>i?ctx.lineTo(p[0],p[1]):ctx.moveTo(p[0],p[1]));ctx.closePath();ctx.fillStyle=g;ctx.fill();wol(1.9);
  ctx.save();ctx.clip();
  ctx.strokeStyle='rgba(10,24,18,.38)';ctx.lineWidth=1.5*u;ctx.beginPath();for(let q=1;q<3;q++){const yy=y+h*q/3;ctx.moveTo(x,yy+(bgH(s,q)-.5)*3*u);ctx.lineTo(x+w,yy+(bgH(s,q+4)-.5)*3*u)}ctx.stroke();
  ctx.strokeStyle='rgba(190,225,190,.3)';ctx.lineWidth=1.1*u;const mx=x+w/2,my=y+h*.5;ctx.beginPath();ctx.moveTo(mx-9*u,my);ctx.lineTo(mx,my-10*u);ctx.lineTo(mx+9*u,my);ctx.lineTo(mx,my+10*u);ctx.closePath();ctx.moveTo(mx-3.5*u,my);ctx.lineTo(mx,my-4*u);ctx.lineTo(mx+3.5*u,my);ctx.lineTo(mx,my+4*u);ctx.closePath();ctx.stroke();
  ctx.strokeStyle='rgba(255,255,255,.26)';ctx.lineWidth=1.3*u;ctx.beginPath();ctx.moveTo(x+4*u,y+5*u);ctx.lineTo(x+4*u,y+h-8*u);ctx.stroke();
  ctx.restore();
  ctx.fillStyle='rgba(95,150,70,.78)';ctx.beginPath();ctx.ellipse(x+w*.4,y+2*u,w*.36,3.2*u,0,0,7);ctx.fill();ctx.strokeStyle='rgba(8,34,16,.45)';ctx.lineWidth=1.1*u;ctx.stroke();
}
function slab(r,x,fy){
  const w=r.w,bh=SLAB_H*u,cx=x+w/2,cy=hallCy(cx),hang=cy+40*u;
  if(r.ph>=2||r.n){ /* empty socket in the roof */
    ctx.fillStyle='#050c09';ctx.fillRect(x-2*u,cy-2*u,w+4*u,9*u);ctx.fillStyle='rgba(95,150,70,.7)';ctx.beginPath();ctx.ellipse(cx,cy+7*u,w*.6,2.6*u,0,0,7);ctx.fill();
  }
  if(r.n){ /* smashed on the shield */
    for(let i=0;i<6;i++)rockChunk(cx+(i-2.5)*9*u,fy-4*u-(i%2)*3*u,(5+bgH(r.s,i)*5)*u,i*1.3,r.s+i);
    return;
  }
  let yb=hang,jx=0;
  if(r.ph===1){
    const k=Math.min(1,r.pt/.45);jx=Math.sin(r.pt*80)*1.3*u*(.4+k);
    ctx.fillStyle='rgba(0,0,0,'+(.1+.26*k).toFixed(3)+')';ctx.beginPath();ctx.ellipse(cx,fy+1.5*u,w*(.35+.3*k),4.5*u,0,0,7);ctx.fill();
    for(let q=0;q<8;q++){const f=(r.pt*1.6+q*.13)%1;ctx.fillStyle='rgba(214,206,176,'+((1-f)*.85).toFixed(2)+')';ctx.fillRect(x+bgH(r.s,q)*w,cy+8*u+f*46*u,1.6*u,2.8*u)}
  }else if(r.ph===2){
    const f=Math.min(1,r.pt/.2);yb=hang+(fy+1*u-hang)*f*f;
    ctx.fillStyle='rgba(0,0,0,.36)';ctx.beginPath();ctx.ellipse(cx,fy+1.5*u,w*.65,4.5*u,0,0,7);ctx.fill();
    ctx.strokeStyle='rgba(214,206,176,.28)';ctx.lineWidth=1.2*u;ctx.beginPath();ctx.moveTo(x+w*.25,yb-bh);ctx.lineTo(x+w*.25,yb-bh-40*u*f);ctx.moveTo(x+w*.75,yb-bh);ctx.lineTo(x+w*.75,yb-bh-40*u*f);ctx.stroke();
  }else if(r.ph===3){
    yb=fy+1*u;
    ctx.fillStyle='rgba(0,0,0,.3)';ctx.beginPath();ctx.ellipse(cx,fy+1.5*u,w*.7,4.5*u,0,0,7);ctx.fill();
  }
  block(x+jx,yb-bh,w,bh,r.s);
  if(r.ph===1){ /* cracks light up before it lets go */
    ctx.strokeStyle='rgba(236,244,206,'+(.35+.3*Math.sin(r.pt*30)).toFixed(2)+')';ctx.lineWidth=1.2*u;ctx.beginPath();ctx.moveTo(x-2*u,cy+3*u);ctx.lineTo(x+4*u,cy+9*u);ctx.lineTo(x+1*u,cy+14*u);ctx.moveTo(x+w+2*u,cy+3*u);ctx.lineTo(x+w-4*u,cy+10*u);ctx.lineTo(x+w-1*u,cy+15*u);ctx.stroke();
  }
  if(r.ph===3){
    for(let i=0;i<5;i++)rockChunk(x+(i-.5)*w/4,fy-2.5*u-(i%2)*2*u,(3+bgH(r.s,i+20)*3)*u,i*1.7,r.s+i+30);
    if(r.pt<.7){const k=r.pt/.7;puff(cx-w*.5-k*56*u,fy-7*u,(14+k*28)*u,(1-k)*.7);puff(cx+w*.5+k*56*u,fy-7*u,(14+k*28)*u,(1-k)*.7)}
  }
}

export function drawTraps(){
  if(!state.tt.length)return;
  ctx.save();ctx.lineJoin=ctx.lineCap='round';
  if(state.fx.ghost>0)ctx.globalAlpha*=.45;
  for(const r of state.tt){
    const x=r.x-state.dist;if(x>W+140*u||x+r.w<-140*u)continue;
    const fy=hallFy(x+r.w/2);
    if(r.k==='door')door(r,x,fy);else if(r.k==='spike')spike(r,x,fy);else if(r.k==='flame')flame(r,x,fy);else slab(r,x,fy);
  }
  ctx.restore();
}
