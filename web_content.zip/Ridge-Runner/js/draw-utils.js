/*
 * draw-utils.js - Small canvas drawing primitives shared by every scene: rounded rects, colour blending, parallax iteration,
 * outlined polygons / ovals / curves, sparkles and crystals.
 */
import { t } from './clock.js';
import { state } from './state.js';
import { ctx, u } from './view.js';

export const rr=(x,y,w,h,r)=>{ctx.beginPath();ctx.roundRect?ctx.roundRect(x,y,w,h,r):ctx.rect(x,y,w,h)};
export const par=(sp,k,L,R,f)=>{for(let i=Math.floor((L+state.dist*k)/sp)-1;i*sp-state.dist*k<R+sp;i++)f(i*sp-state.dist*k,i)};
const h2c={};
export const h2=h=>h2c[h]||(h2c[h]=[1,3,5].map(i=>parseInt(h.substr(i,2),16)));
const lcc={};
export const lc=(a,b,k,al)=>{const key=al==null?a+b:a+b+al,e=lcc[key];if(e&&e.k===k)return e.v;const A=h2(a),B=h2(b),c=A.map((v,i)=>Math.round(v+(B[i]-v)*k)).join(),v=al==null?'rgb('+c+')':'rgba('+c+','+al+')';if(e){e.k=k;e.v=v}else lcc[key]={k,v};return v};
export const wlg=(y0,y1,a,b)=>{const q=ctx.createLinearGradient(0,y0,0,y1);q.addColorStop(0,a);q.addColorStop(1,b);return q};
export const wol=w=>{ctx.strokeStyle='rgba(0,0,0,.32)';ctx.lineWidth=(w||1.6)*u;ctx.lineJoin='round';ctx.stroke()};
export const wdot=(x,yy,r,c)=>{ctx.fillStyle=c;ctx.beginPath();ctx.arc(x,yy,r,0,7);ctx.fill()};
export const BPG=(c,...p)=>{ctx.fillStyle=c;ctx.beginPath();ctx.moveTo(p[0],p[1]);for(let i=2;i<p.length;i+=2)ctx.lineTo(p[i],p[i+1]);ctx.closePath();ctx.fill();wol(1.3)};
export const BOV=(cx,cy,rx,ry,c,r)=>{ctx.fillStyle=c;ctx.beginPath();ctx.ellipse(cx,cy,rx,ry,r||0,0,7);ctx.fill();wol(1.2)};
export const BST=(c,w,x0,y0,cx,cy,x1,y1)=>{ctx.strokeStyle=c;ctx.lineWidth=w*u;ctx.beginPath();ctx.moveTo(x0,y0);ctx.quadraticCurveTo(cx,cy,x1,y1);ctx.stroke()};
export const BSP=(cx,cy,r,c)=>{ctx.fillStyle=c;ctx.beginPath();ctx.moveTo(cx,cy-r);ctx.quadraticCurveTo(cx,cy,cx+r,cy);ctx.quadraticCurveTo(cx,cy,cx,cy+r);ctx.quadraticCurveTo(cx,cy,cx-r,cy);ctx.quadraticCurveTo(cx,cy,cx,cy-r);ctx.fill()};
/* ---- Hand-drawn obstacles: snow, ice cave, meadow, cave, flyers, ponds ---- */
export const obCry=(x0,x1,xp,yp,b,col)=>{BPG(col,x0,b,xp,yp,x1,b);ctx.fillStyle='rgba(20,80,160,.36)';ctx.beginPath();ctx.moveTo(xp,yp);ctx.lineTo(x1,b);ctx.lineTo(xp,b);ctx.closePath();ctx.fill();ctx.strokeStyle='rgba(255,255,255,.75)';ctx.lineWidth=1.2*u;ctx.beginPath();ctx.moveTo(xp-(xp-x0)*.28,yp+(b-yp)*.28);ctx.lineTo(xp-(xp-x0)*.45,yp+(b-yp)*.7);ctx.stroke()};
export const obSpk=(x,y,s)=>{const k=Math.max(0,Math.sin(t*3+s));if(k>.05)BSP(x,y,(1+2.4*k)*u,'rgba(255,255,255,.9)')};
/* ---- Hand-drawn backgrounds: sun, clouds, mountains, hills, pines, mist, ground ---- */
export const bgH=(n,k)=>{const v=Math.sin(n*127.1+k*311.7)*43758.5453;return v-Math.floor(v)};
export const bz=(a,b,c,p,q)=>(1-p)*(1-q)*a+((1-p)*q+p*(1-q))*b+p*q*c;
