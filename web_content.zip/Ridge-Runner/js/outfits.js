/*
 * outfits.js - Outfit catalogue and layer dispatch (behind / on / in front of the body) plus the always-on accessory layer.
 */
import { t } from './clock.js';
import { rr } from './draw-utils.js';
import { bodyInk, bodyShade } from './hand-drawn.js';
import { BK, MO } from './outfit-parts.js';
import { ba, bb, bk } from './outfits-base.js';
import { moA, moB, moK } from './outfits-mangrove.js';
import { winterBack, winterBody, winterFront } from './outfits-winter.js';
import { state } from './state.js';
import { ctx, px, u } from './view.js';

export const OUT=[
  {k:'classic',n:'Classic',i:'🙂',b:'#fdf6e9',t:'#ffb347',e:'#1b2a49'},
  {k:'astro',n:'Astronaut',i:'🧑‍🚀',b:'#e8ecf5',t:'#8aa0d6',e:'#1b2a49'},
  {k:'dragon',n:'Dragon',i:'🐉',b:'#d62839',t:'#ffc233',e:'#ffe08a'},
  {k:'ninja',n:'Ninja',i:'🥷',b:'#1f2430',t:'#ff4d5e',e:'#fdf6e9'},
  {k:'robot',n:'Robot',i:'🤖',b:'#9aa6b8',t:'#6ee7ff',e:'#10152e'},
  {k:'knight',n:'Knight',i:'⚔️',b:'#b8c0cc',t:'#d62839',e:'#10152e'},
  {k:'wizard',n:'Wizard',i:'🧙',b:'#6b4fd6',t:'#ffd23f',e:'#fdf6e9'},
  {k:'cat',n:'Cat',i:'🐱',b:'#ffb86b',t:'#ff8f3a',e:'#1b2a49'},
  {k:'fire',n:'Fire Spirit',i:'🔥',b:'#ff6a1a',t:'#ffd23f',e:'#fff3b0',h:'#ffd23f',s:'#a82a0c'},
  {k:'ice',n:'Ice Spirit',i:'❄️',b:'#bfe9ff',t:'#7dd3fc',e:'#1b2a49'},
  {k:'fairy',n:'Fairy',i:'🧚',b:'#f9c6ff',t:'#ff9de6',e:'#6b4fd6'},
  {k:'tribe',n:'Tribal',i:'🪶',b:'#a8672f',t:'#2a9d8f',e:'#10152e'},
  {k:'golem',n:'Rock Golem',i:'🪨',b:'#8a8f99',t:'#6b7079',e:'#ffb347'},
  {k:'forest',n:'Forest Spirit',i:'🌿',b:'#9bd48a',t:'#4caf50',e:'#1b2a49'},
  {k:'bear',n:'Bear',i:'🐻',b:'#7a4b2a',t:'#d9a066',e:'#10152e'},
  {k:'santa',n:'Santa',i:'🎅',b:'#e03a4e',t:'#fdf6e9',e:'#10152e',h:'#f6cfb0',sec:'Winter'},
  {k:'snowman',n:'Snowman',i:'⛄',b:'#ffffff',t:'#e53950',e:'#10152e',h:'#7a4b2a'},
  {k:'reindeer',n:'Reindeer',i:'🦌',b:'#a86a3a',t:'#d62839',e:'#10152e',h:'#7a4b2a'},
  {k:'penguin',n:'Penguin',i:'🐧',b:'#1f2a44',t:'#7dd3fc',e:'#10152e',h:'#2f3d63',s:'#ff9f43'},
  {k:'polar',n:'Polar Bear',i:'🐻‍❄️',b:'#f4f8fd',t:'#4aa8e0',e:'#10152e',h:'#dbe8f6',s:'#8fa9c7'},
  {k:'elf',n:'Elf',i:'🧝',b:'#3bb273',t:'#d62839',e:'#10152e',h:'#f6cfb0',s:'#d62839'},
  {k:'ginger',n:'Gingerbread',i:'🍪',b:'#c98240',t:'#fdf6e9',e:'#3b2415',h:'#c98240',s:'#a8672f'},
  {k:'yeti',n:'Yeti',i:'🏔️',b:'#dbe8f6',t:'#7aa6d6',e:'#10152e',h:'#bcd0e6',s:'#8fa9c7'},
  {k:'fox',n:'Arctic Fox',i:'🦊',b:'#eef3f8',t:'#9ad7ff',e:'#10152e',h:'#dfe7ef',s:'#c7d3e3'},
  {k:'sundari',n:'Sundari Sprout',i:'🌱',b:'#8fd16f',t:'#2e7d4f',e:'#10152e',h:'#d7e8a8',sec:'Mangrove'},
  {k:'tiger',n:'Bengal Tiger',i:'🐅',b:'#f3a43a',t:'#fdf6e9',e:'#10152e',h:'#f3a43a',s:'#2b2433'},
  {k:'chital',n:'Spotted Deer',i:'🦌',b:'#c9854f',t:'#fdf6e9',e:'#10152e',h:'#c9854f'},
  {k:'crab',n:'Mud Crab',i:'🦀',b:'#e2573a',t:'#ffd23f',e:'#10152e',h:'#e2573a'},
  {k:'mudskip',n:'Mudskipper',i:'🐟',b:'#8a9a6a',t:'#d9b25f',e:'#fff3b0',h:'#8a9a6a'},
  {k:'kingfisher',n:'Kingfisher',i:'🐦',b:'#2fa7d8',t:'#ff8a3d',e:'#10152e',h:'#2fa7d8',s:'#ff8a3d'},
  {k:'croc',n:'Saltwater Croc',i:'🐊',b:'#5f8f4a',t:'#e9e2a8',e:'#ffd23f',h:'#5f8f4a'},
  {k:'boatman',n:'Golpata Boatman',i:'🛶',b:'#f0d9a8',t:'#d62839',e:'#10152e',h:'#a8672f'}
];
export function acc(T,S){
  const k=state.O.k,x=px,ga=ctx.globalAlpha;
  if(t%3.4<.12){ctx.fillStyle=state.O.k==='penguin'?'#f4f8fd':state.O.b;ctx.fillRect(x+S*.5,T+S*.18,S*.36,S*.38);ctx.strokeStyle='rgba(0,0,0,.55)';ctx.lineWidth=1.6*u;ctx.beginPath();ctx.moveTo(x+S*.55,T+S*.4);ctx.lineTo(x+S*.82,T+S*.4);ctx.stroke()}
  else{ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(x+S*.72,T+S*.33,1.4*u,0,7);ctx.fill()}
  if(BK[k])return;
  if(k==='astro'){ctx.fillStyle='#9aa4b5';rr(x-9*u,T+S*.3,10*u,S*.5,3*u);ctx.fill();ctx.fillStyle='#c9d1e0';rr(x+S*.2,T+S*.56,S*.34,S*.16,3*u);ctx.fill();ctx.fillStyle='#ff5d73';ctx.fillRect(x+S*.25,T+S*.61,3*u,3*u);ctx.fillStyle='#5de08a';ctx.fillRect(x+S*.38,T+S*.61,3*u,3*u)}
  else if(k==='ninja'){ctx.fillStyle='#d62839';ctx.fillRect(x,T+S*.6,S,3.5*u)}
  else if(k==='knight'){ctx.fillStyle='rgba(255,255,255,.22)';rr(x+S*.08,T+S*.5,S*.84,S*.24,4*u);ctx.fill()}
  else if(k==='fire'){ctx.fillStyle='rgba(255,215,70,.5)';ctx.beginPath();ctx.ellipse(x+S*.5,T+S*.6,S*.3,S*.18,0,0,7);ctx.fill();ctx.fillStyle='#ffd23f';for(let q=0;q<4;q++){const ph=(t*1.4+q*.25)%1;ctx.globalAlpha=ga*(1-ph);ctx.beginPath();ctx.arc(x+S*(.2+q*.2)+Math.sin(t*6+q)*3*u,T+S*.5-ph*S*1.1,2*u,0,7);ctx.fill()}ctx.globalAlpha=ga}
  else if(k==='fairy'){ctx.fillStyle='#fff3b0';for(let q=0;q<4;q++){const ph=(t*1.1+q*.25)%1;ctx.globalAlpha=ga*(1-ph);ctx.beginPath();ctx.arc(x-ph*S*.9,T+S*.5+Math.sin(t*5+q*2)*6*u+ph*10*u,1.8*u,0,7);ctx.fill()}ctx.globalAlpha=ga}
  else if(k==='ice'){ctx.fillStyle='#fff';for(let q=0;q<3;q++){ctx.globalAlpha=ga*(.4+.4*Math.sin(t*5+q*2));ctx.beginPath();ctx.arc(x+S*(.25+q*.25),T+S*(.5+q%2*.2),1.8*u,0,7);ctx.fill()}ctx.globalAlpha=ga}
  const tri=(a,b,c,d,e,g)=>{ctx.beginPath();ctx.moveTo(a,b);ctx.lineTo(c,d);ctx.lineTo(e,g);ctx.closePath();ctx.fill();ctx.strokeStyle='rgba(0,0,0,.32)';ctx.lineWidth=1.2*u;ctx.stroke()};
  if(k==='astro'){ctx.fillStyle='rgba(130,205,255,.4)';ctx.strokeStyle='#fdf6e9';ctx.lineWidth=3*u;ctx.beginPath();ctx.arc(x+S*.5,T+S*.42,S*.52,0,7);ctx.fill();ctx.stroke();ctx.fillStyle='rgba(255,255,255,.8)';ctx.fillRect(x+S*.22,T+S*.16,S*.2,3*u);ctx.fillStyle='#ff5d73';ctx.fillRect(x+S*.38,T+S*.86,S*.24,4*u)}
  else if(k==='dragon'){ctx.fillStyle='#ffc233';tri(x+S*.15,T+1,x+S*.28,T-9*u,x+S*.4,T+1);tri(x+S*.5,T+1,x+S*.62,T-9*u,x+S*.74,T+1);rr(x+S*.7,T+S*.4,S*.42,S*.3,6*u);ctx.fill();ctx.fillStyle='#ff8f3a';tri(x,T+S*.2,x-9*u,T+S*.5,x,T+S*.62);ctx.fillStyle='#8a1523';ctx.beginPath();ctx.arc(x+S*1.0,T+S*.5,1.8*u,0,7);ctx.fill();ctx.strokeStyle='#ffc233';ctx.lineWidth=2*u;ctx.beginPath();ctx.moveTo(x+S*1.05,T+S*.62);ctx.quadraticCurveTo(x+S*1.3,T+S*.75+Math.sin(t*10)*3*u,x+S*1.5,T+S*.6);ctx.stroke();for(let n=0;n<3;n++){ctx.beginPath();ctx.arc(x+S*.25+n*S*.25,T+S*.88,S*.11,Math.PI,0);ctx.stroke()}}
  else if(k==='ninja'){ctx.fillStyle='#fdf6e9';ctx.fillRect(x+S*.4,T+S*.3,S*.6,S*.16);ctx.fillStyle='#10152e';ctx.beginPath();ctx.arc(x+S*.68,T+S*.38,3.2*u,0,7);ctx.fill();ctx.fillStyle=state.O.t;ctx.fillRect(x,T+S*.12,S,6*u);tri(x,T+S*.12,x-14*u,T+S*.05+Math.sin(t*14)*4*u,x,T+S*.22)}
  else if(k==='robot'){ctx.fillStyle='#10152e';rr(x+S*.38,T+S*.24,S*.64,S*.26,4*u);ctx.fill();ctx.fillStyle='#6ee7ff';ctx.fillRect(x+S*.62,T+S*.32,S*.3,S*.1);ctx.strokeStyle='#6ee7ff';ctx.lineWidth=2*u;ctx.beginPath();ctx.moveTo(x+S*.5,T);ctx.lineTo(x+S*.5,T-10*u);ctx.stroke();ctx.fillStyle='#ff5d73';ctx.beginPath();ctx.arc(x+S*.5,T-11*u,3*u,0,7);ctx.fill()}
  else if(k==='knight'){ctx.fillStyle='#8892a0';rr(x-2*u,T-3*u,S+4*u,S*.62,9*u);ctx.fill();ctx.fillStyle='#10152e';ctx.fillRect(x+S*.35,T+S*.26,S*.68,4*u);ctx.fillStyle='#d62839';tri(x+S*.2,T-3*u,x-10*u,T-10*u+Math.sin(t*12)*3*u,x+S*.5,T-3*u)}
  else if(k==='wizard'){ctx.fillStyle='#3b2a8c';tri(x-3*u,T+4*u,x+S*.55,T-S,x+S+3*u,T+4*u);ctx.fillStyle='#ffd23f';ctx.fillRect(x+S*.12,T-2*u,S*.76,4*u);ctx.fillStyle='#3b2a8c';ctx.beginPath();ctx.ellipse(x+S*.5,T+4*u,S*.72,4*u,0,0,7);ctx.fill()}
  else if(k==='cat'){ctx.fillStyle=state.O.b;tri(x+S*.06,T+2,x+S*.1,T-9*u,x+S*.38,T+2);tri(x+S*.62,T+2,x+S*.9,T-9*u,x+S*.94,T+2);ctx.fillStyle='#ff8fa0';ctx.beginPath();ctx.arc(x+S*.9,T+S*.5,2*u,0,7);ctx.fill();ctx.strokeStyle='#10152e';ctx.lineWidth=1.5*u;ctx.beginPath();ctx.moveTo(x+S*.85,T+S*.55);ctx.lineTo(x+S*1.2,T+S*.5);ctx.moveTo(x+S*.85,T+S*.6);ctx.lineTo(x+S*1.2,T+S*.68);ctx.stroke()}
  else if(k==='fire'){ctx.fillStyle='#ffd23f';for(let q=0;q<3;q++){const f2=x+S*(.22+q*.28),fh=(14+q%2*8)*u+Math.sin(t*14+q*2)*4*u;tri(f2-6*u,T+2,f2,T-fh,f2+6*u,T+2)}ctx.fillStyle='#ff4d1a';tri(x+S*.3,T+2,x+S*.42,T-8*u+Math.sin(t*16)*3*u,x+S*.56,T+2);ctx.fillStyle='#fff3b0';ctx.beginPath();ctx.arc(x+S*.68,T+S*.38,4*u,0,7);ctx.fill()}
  else if(k==='ice'){ctx.fillStyle='#e8f7ff';tri(x+S*.12,T+2,x+S*.22,T-12*u,x+S*.34,T+2);tri(x+S*.4,T+2,x+S*.5,T-18*u,x+S*.62,T+2);tri(x+S*.66,T+2,x+S*.76,T-11*u,x+S*.88,T+2);ctx.strokeStyle='#fff';ctx.lineWidth=1.5*u;ctx.beginPath();ctx.moveTo(x+S*.3,T+S*.72);ctx.lineTo(x+S*.7,T+S*.72);ctx.moveTo(x+S*.5,T+S*.56);ctx.lineTo(x+S*.5,T+S*.88);ctx.stroke()}
  else if(k==='fairy'){const w2=Math.sin(t*20)*3*u;ctx.fillStyle='rgba(255,255,255,.7)';ctx.beginPath();ctx.ellipse(x+S*.12,T+S*.3+w2,S*.17,S*.4,-.5,0,7);ctx.fill();ctx.beginPath();ctx.ellipse(x+S*.12,T+S*.64+w2,S*.13,S*.28,.6,0,7);ctx.fill();ctx.fillStyle='#ff7ad9';for(let q=0;q<3;q++){ctx.beginPath();ctx.arc(x+S*(.25+q*.25),T+1,3.5*u,0,7);ctx.fill()}ctx.fillStyle='#fff3b0';ctx.beginPath();ctx.arc(x+S*.5,T,2.5*u,0,7);ctx.fill()}
  else if(k==='tribe'){const fc=['#d62839','#ffd23f','#2a9d8f','#ffd23f','#d62839'];for(let q=0;q<5;q++){ctx.fillStyle=fc[q];tri(x+S*(.08+q*.18),T+2,x+S*(.18+q*.18)+Math.sin(t*10+q)*2*u,T-16*u,x+S*(.28+q*.18),T+2)}ctx.fillStyle='#fdf6e9';ctx.fillRect(x+S*.2,T+S*.3,S*.18,3*u);ctx.fillRect(x+S*.5,T+S*.3,S*.34,3*u);ctx.fillStyle='#2a9d8f';ctx.fillRect(x+S*.2,T+S*.62,S*.6,3*u);ctx.fillStyle='#10152e';ctx.beginPath();ctx.arc(x+S*.68,T+S*.4,3*u,0,7);ctx.fill()}
  else if(k==='golem'){ctx.fillStyle='#6b7079';ctx.fillRect(x+S*.08,T+S*.7,S*.3,S*.18);ctx.fillRect(x+S*.5,T+S*.12,S*.4,S*.14);ctx.fillStyle='#5fae63';ctx.beginPath();ctx.ellipse(x+S*.3,T+S*.05,S*.28,5*u,0,0,7);ctx.fill();ctx.fillStyle='#ffb347';ctx.beginPath();ctx.arc(x+S*.68,T+S*.4,4*u,0,7);ctx.fill();ctx.strokeStyle='#4a4f58';ctx.lineWidth=2*u;ctx.beginPath();ctx.moveTo(x+S*.2,T+S*.3);ctx.lineTo(x+S*.35,T+S*.5);ctx.lineTo(x+S*.28,T+S*.62);ctx.stroke()}
  else if(k==='forest'){ctx.strokeStyle='#8a5a2b';ctx.lineWidth=3*u;ctx.beginPath();ctx.moveTo(x+S*.3,T);ctx.lineTo(x+S*.2,T-14*u);ctx.moveTo(x+S*.25,T-8*u);ctx.lineTo(x+S*.1,T-12*u);ctx.moveTo(x+S*.7,T);ctx.lineTo(x+S*.8,T-14*u);ctx.moveTo(x+S*.75,T-8*u);ctx.lineTo(x+S*.9,T-12*u);ctx.stroke();ctx.fillStyle='#3f9b45';for(let q=0;q<4;q++){ctx.beginPath();ctx.ellipse(x+S*(.15+q*.23),T+S*.9,4*u,7*u,q%2?.6:-.6,0,7);ctx.fill()}}
  else if(k==='bear'){ctx.fillStyle=state.O.b;ctx.beginPath();ctx.arc(x+S*.12,T+3*u,6*u,0,7);ctx.fill();ctx.beginPath();ctx.arc(x+S*.82,T+3*u,6*u,0,7);ctx.fill();ctx.fillStyle='#d9a066';ctx.beginPath();ctx.ellipse(x+S*.88,T+S*.55,S*.2,S*.16,0,0,7);ctx.fill();ctx.fillStyle='#10152e';ctx.beginPath();ctx.arc(x+S*.98,T+S*.5,2.5*u,0,7);ctx.fill()}
}
/* behind the body: ears, antlers, tails, sack */
export function wk(T,S){if(BK[state.O.k])return bk(T,S);if(MO[state.O.k])return moK(T,S);return winterBack(T,S)}
/* on the body, under the face and arm: belts, bellies, scarf bands, icing */
export function wb(T,S){bodyShade(T,S);if(BK[state.O.k])bb(T,S);else if(MO[state.O.k])moB(T,S);else winterBody(T,S);bodyInk(T,S)}
/* in front of the body and face: hats, beards, beaks, snouts, scarf tails */
export function wa(T,S){if(BK[state.O.k])return ba(T,S);if(MO[state.O.k])return moA(T,S);return winterFront(T,S)}
/** Wires this module up to the DOM / storage. Called once from main.js during boot, in the original statement order. */
export function initOutfits(){
  state.O=OUT[0];
  try{state.O=OUT[+localStorage.getItem('dd-out')||0]||OUT[0]}catch(e){}
}
