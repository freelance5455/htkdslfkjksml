/*
 * temple-boulder-art.js - Hand-drawn art for the chasing boulder, its dust and debris, and the stone gate that seals the hall.
 * Everything is read from state.tc (see temple-chase.js); nothing here changes game state.
 */
import { t } from './clock.js';
import { BST, BSP, bgH, wdot, wol } from './draw-utils.js';
import { state } from './state.js';
import { hallCy, hallFy } from './temple-geo.js';
import { ctx, u, W } from './view.js';

/** Soft round dust cloud. */
export function puff(x,y,r,a){
  const g=ctx.createRadialGradient(x,y,r*.1,x,y,r);
  g.addColorStop(0,'rgba(192,180,144,'+(a*.9).toFixed(3)+')');g.addColorStop(.6,'rgba(172,160,128,'+(a*.5).toFixed(3)+')');g.addColorStop(1,'rgba(150,140,110,0)');
  ctx.fillStyle=g;ctx.beginPath();ctx.arc(x,y,r,0,7);ctx.fill();
}
/** One chipped stone: lumpy outline, light top-left face, dark underside, sometimes a tuft of moss. */
export function rockChunk(x,y,r,rot,seed){
  const n=7,p=[];
  for(let i=0;i<n;i++){const a=rot+i/n*6.2832,k=r*(.72+.34*bgH(seed,i+1));p.push([x+Math.cos(a)*k,y+Math.sin(a)*k*.86])}
  ctx.fillStyle='#6f7a68';ctx.beginPath();p.forEach((q,i)=>i?ctx.lineTo(q[0],q[1]):ctx.moveTo(q[0],q[1]));ctx.closePath();ctx.fill();wol(1.4);
  ctx.save();ctx.clip();const g=ctx.createLinearGradient(x-r,y-r,x+r,y+r);g.addColorStop(0,'rgba(240,246,220,.36)');g.addColorStop(.5,'rgba(240,246,220,0)');g.addColorStop(1,'rgba(0,0,0,.34)');ctx.fillStyle=g;ctx.fillRect(x-r*1.4,y-r*1.4,r*2.8,r*2.8);ctx.restore();
  if(bgH(seed,9)>.55){ctx.fillStyle='rgba(95,150,70,.8)';ctx.beginPath();ctx.ellipse(x-r*.15,y-r*.5,r*.5,r*.17,-.2,0,7);ctx.fill()}
}
/** Lumpy circle outline (path only), turned by `ang` so the silhouette rolls with the boulder. */
function blob(cx,cy,R,ang,seed){
  const N=26,p=[];
  for(let i=0;i<N;i++){const a=ang+i/N*6.2832,r=R*(.955+.07*bgH(seed,i+3));p.push([cx+Math.cos(a)*r,cy+Math.sin(a)*r])}
  const m=(a,b)=>[(a[0]+b[0])/2,(a[1]+b[1])/2],s=m(p[N-1],p[0]);
  ctx.beginPath();ctx.moveTo(s[0],s[1]);
  for(let i=0;i<N;i++){const q=p[i],e=m(q,p[(i+1)%N]);ctx.quadraticCurveTo(q[0],q[1],e[0],e[1])}
  ctx.closePath();
}
/** Carvings, strata, cracks, moss and pock marks, in the boulder's own (turning) space with the origin at its centre. */
function skin(R,seed){
  for(let i=0;i<4;i++){
    const y=(-.62+i*.42)*R;ctx.strokeStyle='rgba(30,30,22,.2)';ctx.lineWidth=2.2*u;ctx.beginPath();ctx.moveTo(-R,y+bgH(seed,40+i)*10*u);ctx.bezierCurveTo(-R*.4,y-9*u,R*.3,y+11*u,R,y-4*u);ctx.stroke();
    ctx.strokeStyle='rgba(255,250,220,.1)';ctx.lineWidth=1*u;ctx.translate(0,2.4*u);ctx.stroke();ctx.translate(0,-2.4*u);
  }
  /* carved naga coil: a groove with a pale chiselled edge, inside a ring */
  const sx=-.08*R,sy=.04*R;
  const sp=(dy,col,w)=>{ctx.strokeStyle=col;ctx.lineWidth=w*u;ctx.beginPath();for(let q=0;q<=44;q++){const a=q*.34,r=(.05+q*.0158)*R,x=sx+Math.cos(a)*r,y=sy+dy+Math.sin(a)*r*.96;q?ctx.lineTo(x,y):ctx.moveTo(x,y)}ctx.stroke()};
  sp(1.7*u,'rgba(255,250,220,.24)',3.2);sp(0,'rgba(24,26,18,.62)',3.4);
  for(const [dy,col,w] of [[1.5*u,'rgba(255,250,220,.2)',2.6],[0,'rgba(24,26,18,.55)',2.8]]){ctx.strokeStyle=col;ctx.lineWidth=w*u;ctx.beginPath();ctx.arc(sx,sy+dy,R*.86,0,7);ctx.stroke()}
  ctx.strokeStyle='rgba(20,20,14,.75)';ctx.lineWidth=1.8*u;
  for(let i=0;i<4;i++){let a=bgH(seed,60+i)*6.28,r=R*(.35+.5*bgH(seed,70+i)),x=Math.cos(a)*r,y=Math.sin(a)*r;ctx.beginPath();ctx.moveTo(x,y);for(let k=0;k<4;k++){a+=(bgH(seed,80+i*5+k)-.5)*1.3;x+=Math.cos(a)*R*.11;y+=Math.sin(a)*R*.11;ctx.lineTo(x,y)}ctx.stroke()}
  for(let i=0;i<6;i++){
    const a=-2.3+(bgH(seed,90+i)-.5)*1.6,r=R*(.62+.28*bgH(seed,100+i)),x=Math.cos(a)*r,y=Math.sin(a)*r,rx=R*(.1+.08*bgH(seed,110+i));
    ctx.fillStyle='rgba(88,142,62,.82)';ctx.beginPath();ctx.ellipse(x,y,rx,rx*.62,a+1.57,0,7);ctx.fill();ctx.strokeStyle='rgba(8,34,16,.5)';ctx.lineWidth=1.2*u;ctx.stroke();
    ctx.fillStyle='rgba(190,235,120,.32)';ctx.beginPath();ctx.ellipse(x-rx*.2,y-rx*.18,rx*.5,rx*.2,a+1.57,0,7);ctx.fill();
  }
  for(let i=0;i<12;i++){
    const a=bgH(seed,120+i)*6.28,r=R*(.2+.7*bgH(seed,130+i)),x=Math.cos(a)*r,y=Math.sin(a)*r,s=(2+bgH(seed,140+i)*4)*u;
    ctx.fillStyle='rgba(20,20,14,.4)';ctx.beginPath();ctx.ellipse(x,y,s,s*.7,a,0,7);ctx.fill();ctx.fillStyle='rgba(255,250,220,.16)';ctx.beginPath();ctx.ellipse(x-s*.2,y+s*.5,s*.8,s*.25,a,0,7);ctx.fill();
  }
}
function body(c){
  const R=c.R,cx=c.fw-R-state.dist,cy=c.by;
  if(cx+R<-6||cx-R>W+30)return;
  const seed=7.3;
  /* shadow pooled on the floor */
  ctx.fillStyle='rgba(0,0,0,.34)';ctx.beginPath();ctx.ellipse(cx+R*.08,c.fy+2*u,R*.95,9*u,0,0,7);ctx.fill();
  ctx.fillStyle='rgba(0,0,0,.22)';ctx.beginPath();ctx.ellipse(cx+R*.08,c.fy+2*u,R*.6,5*u,0,0,7);ctx.fill();
  /* stone */
  const g=ctx.createRadialGradient(cx-R*.3,cy-R*.36,R*.1,cx,cy,R*1.05);g.addColorStop(0,'#aaa594');g.addColorStop(.55,'#777464');g.addColorStop(1,'#49493e');
  blob(cx,cy,R,c.ang,seed);ctx.fillStyle=g;ctx.fill();
  ctx.save();blob(cx,cy,R,c.ang,seed);ctx.clip();
  ctx.save();ctx.translate(cx,cy);ctx.rotate(c.ang);skin(R,seed);ctx.restore();
  /* fixed light from the upper left, deep shade to the lower right */
  const sh=ctx.createRadialGradient(cx-R*.38,cy-R*.42,R*.05,cx-R*.1,cy-R*.1,R*1.5);
  sh.addColorStop(0,'rgba(255,248,215,.22)');sh.addColorStop(.42,'rgba(255,248,215,0)');sh.addColorStop(.72,'rgba(0,0,0,.2)');sh.addColorStop(1,'rgba(0,0,0,.6)');
  ctx.fillStyle=sh;ctx.fillRect(cx-R*1.2,cy-R*1.2,R*2.4,R*2.4);
  ctx.restore();
  blob(cx,cy,R,c.ang,seed);wol(3.2);
  ctx.strokeStyle='rgba(255,250,220,.32)';ctx.lineWidth=1.6*u;ctx.beginPath();ctx.arc(cx,cy,R-3.5*u,3.5,4.75);ctx.stroke();
  ctx.strokeStyle='rgba(255,176,80,.36)';ctx.lineWidth=2.4*u;ctx.beginPath();ctx.arc(cx,cy,R-1.6*u,-.4,.95);ctx.stroke();
  /* vines hanging on, streaming backwards as it rolls */
  for(let i=0;i<4;i++){
    const a=c.ang+[-2.6,-1.9,-3.3,-1.2][i],x0=cx+Math.cos(a)*R*.97,y0=cy+Math.sin(a)*R*.97;
    if(x0>cx+R*.2)continue;
    const w=Math.sin(t*5+i*1.9)*4*u,l=(22+i*7)*u;
    BST('rgba(10,30,14,.85)',2.8,x0,y0,x0-l*.5,y0-8*u+w,x0-l,y0+9*u+w);BST('#3c7a3a',1.6,x0,y0,x0-l*.5,y0-8*u+w,x0-l,y0+9*u+w);
    ctx.fillStyle='#4f9a46';ctx.beginPath();ctx.ellipse(x0-l*.55,y0-5*u+w,5*u,2.3*u,-.5,0,7);ctx.fill();ctx.strokeStyle='rgba(8,34,16,.5)';ctx.lineWidth=1*u;ctx.stroke();
    wdot(x0-l,y0+9*u+w,1.8*u,'#9ccb55');
  }
}
function flecks(c){
  for(const f of c.fl){
    const x=f.x-state.dist;if(x<-10||x>W+10)continue;
    ctx.fillStyle='rgba(214,206,176,'+(Math.min(1,f.l*1.6)*.8).toFixed(2)+')';ctx.fillRect(x,f.y,f.s*u,f.s*u*1.7);
  }
}
/** The stone gate: a slot in the roof until the lift approach, then a slab that drops to the floor and later cracks under the boulder. */
function gate(c){
  const x=c.gx-state.dist,w=c.gw;if(x>W+60||x+w<-60)return;
  const fy=hallFy(x),cy=hallCy(x),full=fy-cy;
  if(c.ga===0){
    ctx.fillStyle='#050c09';ctx.fillRect(x-2*u,cy-1*u,w+4*u,6*u);
    ctx.strokeStyle='rgba(120,160,80,.6)';ctx.lineWidth=1.3*u;ctx.beginPath();ctx.moveTo(x-2*u,cy+5.5*u);ctx.lineTo(x+w+2*u,cy+5.5*u);ctx.stroke();
    return;
  }
  const f=c.ga===1?Math.min(1,c.gt/.22):1,bot=c.ga===1?cy+full*f*f:fy+1*u,top=bot-full;
  ctx.save();ctx.beginPath();ctx.rect(x-3*u,cy,w+6*u,bot-cy);ctx.clip();
  const g=ctx.createLinearGradient(x,0,x+w,0);g.addColorStop(0,'#1c2822');g.addColorStop(.45,'#5d7064');g.addColorStop(1,'#222f28');
  ctx.fillStyle=g;ctx.fillRect(x,top,w,full);
  ctx.strokeStyle='rgba(0,0,0,.5)';ctx.lineWidth=2.6*u;ctx.strokeRect(x,top,w,full);
  /* courses of stone, each with a pale lip under the dark joint */
  for(let i=1;i*52*u<full;i++){const y=top+i*52*u;ctx.fillStyle='rgba(10,24,18,.4)';ctx.fillRect(x,y,w,6*u);ctx.strokeStyle='rgba(190,225,190,.3)';ctx.lineWidth=1*u;ctx.beginPath();ctx.moveTo(x+1,y+6.5*u);ctx.lineTo(x+w-1,y+6.5*u);ctx.stroke()}
  ctx.strokeStyle='rgba(190,225,190,.3)';ctx.lineWidth=1.1*u;
  for(let i=0;i*52*u<full;i++){const cy2=top+i*52*u+30*u,cx=x+w/2;ctx.beginPath();ctx.moveTo(cx-13*u,cy2);ctx.lineTo(cx,cy2-14*u);ctx.lineTo(cx+13*u,cy2);ctx.lineTo(cx,cy2+14*u);ctx.closePath();ctx.stroke()}
  ctx.strokeStyle='rgba(255,255,255,.2)';ctx.lineWidth=1.2*u;ctx.beginPath();ctx.moveTo(x+w*.22,top+4*u);ctx.lineTo(x+w*.22,bot);ctx.stroke();
  for(const q of[.2,.8]){const y=top+full*q;ctx.fillStyle='#c9b25a';ctx.fillRect(x-1*u,y,w+2*u,7*u);ctx.strokeStyle='rgba(20,16,4,.6)';ctx.lineWidth=1.3*u;ctx.strokeRect(x-1*u,y,w+2*u,7*u);ctx.strokeStyle='rgba(255,250,200,.5)';ctx.lineWidth=.9*u;ctx.beginPath();ctx.moveTo(x,y+1.8*u);ctx.lineTo(x+w,y+1.8*u);ctx.stroke()}
  if(c.gcr>0){ /* fractures from the boulder's blow */
    ctx.strokeStyle='rgba(8,14,10,.8)';ctx.lineWidth=1.8*u;
    for(let i=0;i<5;i++){let y=bot-(40+i*58)*u,xx=x+1;ctx.beginPath();ctx.moveTo(xx,y);for(let k=0;k<4;k++){xx+=(3+bgH(i,k)*5)*u;y+=(bgH(i,k+9)-.4)*16*u;ctx.lineTo(xx,y)}ctx.stroke()}
    ctx.strokeStyle='rgba(235,245,225,.3)';ctx.lineWidth=.9*u;for(let i=0;i<5;i++){const y=bot-(40+i*58)*u;ctx.beginPath();ctx.moveTo(x+1,y+2*u);ctx.lineTo(x+6*u,y+3*u);ctx.stroke()}
  }
  ctx.restore();
  /* mossy lip along the roof and drips of moss */
  ctx.fillStyle='rgba(95,150,70,.78)';ctx.beginPath();ctx.ellipse(x+w*.45,cy+2*u,w*.62,3.6*u,0,0,7);ctx.fill();ctx.strokeStyle='rgba(8,34,16,.45)';ctx.lineWidth=1.2*u;ctx.stroke();
  ctx.fillStyle='rgba(95,150,70,.78)';ctx.beginPath();ctx.ellipse(x+w*.5,bot-1*u,w*.7,3*u,0,0,7);ctx.fill();ctx.stroke();
}
export function drawBoulder(){
  const c=state.tc;if(!c)return;
  ctx.save();ctx.lineJoin=ctx.lineCap='round';
  gate(c);flecks(c);
  if(c.ph==='roll')body(c);
  for(const k of c.ch)rockChunk(k.x-state.dist,k.y,k.r,k.rot,k.sd);
  for(const p of c.peb)rockChunk(p.x-state.dist,p.y,p.r,p.rot,p.sd);
  for(const d of c.dust){const x=d.x-state.dist;if(x<-80||x>W+80)continue;puff(x,d.y,d.r,Math.max(0,d.l)*d.a)}
  if(c.fl2>0){const x=c.gx-state.dist;ctx.save();ctx.globalCompositeOperation='lighter';const r=170*u,g=ctx.createRadialGradient(x,c.gy,4*u,x,c.gy,r);g.addColorStop(0,'rgba(255,236,190,'+(c.fl2*.6).toFixed(3)+')');g.addColorStop(1,'rgba(255,200,120,0)');ctx.fillStyle=g;ctx.beginPath();ctx.arc(x,c.gy,r,0,7);ctx.fill();ctx.restore();BSP(x,c.gy,26*u*c.fl2,'rgba(255,250,225,.9)')}
  ctx.restore();
}
