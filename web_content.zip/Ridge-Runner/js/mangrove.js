/*
 * mangrove.js - Mangrove biome: background, mud ground, sea, spawn table, props and every mangrove obstacle.
 */
import { MV } from './biomes.js';
import { t } from './clock.js';
import { bgH, BOV, BPG, BST, obSpk, par, rr, wdot, wlg, wol } from './draw-utils.js';
import { ter } from './physics.js';
import { state } from './state.js';
import { ctx, G, H, u, W } from './view.js';

export function mgTree(x,b,s,n,c1,c2,vn){
  const k=s*u,sw=Math.sin(t*1.1+n)*1.4*u;ctx.lineCap=ctx.lineJoin='round';
  for(let p=0;p<2;p++){ctx.strokeStyle=p?c1:'rgba(8,26,16,.5)';
    for(let q=-2;q<=2;q++){const sy=b-(27-Math.abs(q)*4)*k;ctx.lineWidth=(p?2.3:4)*k;ctx.beginPath();ctx.moveTo(x+q*2*k,sy);ctx.quadraticCurveTo(x+q*13*k,sy-3*k,x+q*12*k+(bgH(n,q+9)-.5)*5*k,b+1.5*u);ctx.stroke()}
    ctx.lineWidth=(p?7:9.6)*k;ctx.beginPath();ctx.moveTo(x,b-16*k);ctx.quadraticCurveTo(x+sw*.2,b-34*k,x+sw*.7,b-52*k);ctx.stroke()}
  ctx.beginPath();for(const[a,h,r]of[[-14,-57,13],[1,-66,17],[16,-56,12.5],[-3,-53,11]]){ctx.moveTo(x+sw+(a+r)*k,b+h*k);ctx.arc(x+sw+a*k,b+h*k,r*k,0,7)}
  ctx.strokeStyle='rgba(8,34,20,.4)';ctx.lineWidth=2.4*u;ctx.stroke();ctx.fillStyle=c2;ctx.fill();
  ctx.fillStyle='rgba(215,240,150,.24)';ctx.beginPath();ctx.ellipse(x+sw-3*k,b-72*k,10*k,4.4*k,-.4,0,7);ctx.fill();
  ctx.fillStyle='rgba(6,30,18,.24)';ctx.beginPath();ctx.ellipse(x+sw+6*k,b-50*k,15*k,5*k,.1,0,7);ctx.fill();
  if(vn)for(let q=0;q<5;q++){const vx=x+sw+(-20+q*10)*k,vl=(14+bgH(n,q)*18)*k,vs=Math.sin(t*1.3+n+q)*2*k;BST('rgba(24,60,28,.85)',1.3,vx,b-50*k,vx+vs*.4,b-50*k+vl*.5,vx+vs,b-50*k+vl);wdot(vx+vs,b-50*k+vl,1.5*k,'#7fae4a')}
}
export function bgMang(){
  ctx.lineJoin=ctx.lineCap='round';
  const wt=G-30*u,wg=ctx.createLinearGradient(0,wt,0,G+2*u);wg.addColorStop(0,'rgba(120,170,150,0)');wg.addColorStop(.5,'rgba(70,120,108,.8)');wg.addColorStop(1,'rgba(36,78,70,.95)');ctx.fillStyle=wg;ctx.fillRect(0,wt,W,32*u);
  ctx.strokeStyle='rgba(225,245,200,.3)';ctx.lineWidth=1.3*u;ctx.beginPath();
  par(70*u,.2,0,W,(x,i)=>{const yy=G-(4+bgH(i,5)*20)*u+Math.sin(t*1.6+i)*1.2*u;ctx.moveTo(x,yy);ctx.lineTo(x+(14+bgH(i,6)*20)*u,yy)});ctx.stroke();
  par(150*u,.1,-90*u,W+90*u,(x,i)=>mgTree(x+bgH(i,1)*60*u,G-12*u,.55,i,'#5d7a64','#7da38b'));mgShafts();mgEgrets();
  for(let q=0;q<3;q++){const mx=((q*W*.43-state.dist*.08*(1+q*.2)+t*4*u)%(W*1.4)+W*1.4)%(W*1.4)-W*.2,my=G-(26+q*16)*u;ctx.fillStyle='rgba(226,240,214,.17)';ctx.beginPath();ctx.ellipse(mx,my,(120+q*30)*u,7*u,0,0,7);ctx.fill()}
  par(210*u,.22,-90*u,W+90*u,(x,i)=>mgTree(x+bgH(i,2)*80*u,G-4*u,.9,i+9,'#6a4a2c','#3f7d4a'));
  par(380*u,.4,-120*u,W+120*u,(x,i)=>{if(bgH(i,3)<.75)mgTree(x,G+3*u,1.5,i+19,'#4e3720','#2f6a3e',1)});mgCanopy();
  ctx.save();ctx.globalCompositeOperation='lighter';
  for(let i=0;i<24;i++){const nr=i>=16,R=(nr?13:9)*u,x=((i*131+Math.sin(t*.4+i)*30*u-state.dist*(nr?.34:.15+i%3*.1))%W+W)%W,yy=G-(nr?10+(i*37)%52:34+(i*47)%100)*u+Math.sin(t*.9+i*2)*(nr?5:8)*u,a=.35+.65*Math.max(0,Math.sin(t*2.2+i*1.7)),g=ctx.createRadialGradient(x,yy,0,x,yy,R);g.addColorStop(0,'rgba(255,245,150,'+(.9*a).toFixed(2)+')');g.addColorStop(1,'rgba(255,230,90,0)');ctx.fillStyle=g;ctx.beginPath();ctx.arc(x,yy,R,0,7);ctx.fill();if(nr){ctx.fillStyle='rgba(255,252,210,'+(.95*a).toFixed(2)+')';ctx.beginPath();ctx.arc(x,yy,1.5*u,0,7);ctx.fill()}}
  ctx.restore();
}
export function gndMang(){
  const n8=Math.ceil((W+8)/8)+1,th=[];for(let i=0;i<=n8;i++)th.push(G+ter(i*8));
  const Y=x=>{const f=Math.max(0,Math.min(n8-.001,x/8)),i=f|0;return th[i]+(th[i+1]-th[i])*(f-i)};ctx.lineJoin=ctx.lineCap='round';
  ctx.beginPath();ctx.moveTo(0,H);for(let i=0;i<=n8;i++)ctx.lineTo(i*8,th[i]);ctx.lineTo(n8*8,H);ctx.closePath();
  const gg=ctx.createLinearGradient(0,G-60*u,0,H);gg.addColorStop(0,MV.d0);gg.addColorStop(1,MV.d1);ctx.fillStyle=gg;ctx.fill();
  for(let q=1;q<3;q++){ctx.strokeStyle='rgba(20,22,10,'+(.18*q).toFixed(2)+')';ctx.lineWidth=(2+q)*u;ctx.beginPath();for(let i=0;i<=n8;i++){const yy=th[i]+(14+q*20)*u+Math.sin((i*8+state.dist)/(46*u)+q)*2.6*u;i?ctx.lineTo(i*8,yy):ctx.moveTo(0,yy)}ctx.stroke()}
  const bd=(w,c,dy)=>{ctx.strokeStyle=c;ctx.lineWidth=w*u;ctx.beginPath();for(let i=0;i<=n8;i++)i?ctx.lineTo(i*8,th[i]+dy*u):ctx.moveTo(0,th[0]+dy*u);ctx.stroke()};
  bd(12,'rgba(10,22,10,.42)',4.4);bd(9.4,'#5f7d34',4);bd(5.6,'#7d9a3f',2.4);bd(1.8,'#c3d96f',.4);
  const sp=46*u,go=state.dist%sp,skip=x=>state.tr&&x+state.dist>state.tr.rs-6*u&&x+state.dist<state.tr.re+6*u;
  for(let x=-go,n=Math.floor(state.dist/sp);x<W+sp;x+=sp,n++){
    if(skip(x+sp*.5))continue;
    for(let r=0;r<2;r++){const x0=x+(r?18:2)*u+bgH(n,r+30)*8*u,x1=x0+(30+bgH(n,r+32)*14)*u,y0=Y(x0)+(4+r*9)*u,y1=Y(x1)+(4+r*9)*u,h=(7+bgH(n,r+34)*6)*u;
      for(let p=0;p<3;p++){const o=p>1?-1.4*u:0;ctx.strokeStyle=['rgba(14,8,2,.5)','#7a5230','rgba(214,160,100,.75)'][p];ctx.lineWidth=[6,3.8,1][p]*u;ctx.beginPath();ctx.moveTo(x0,y0+o);ctx.quadraticCurveTo((x0+x1)/2,Math.min(y0,y1)-h+o,x1,y1+o);ctx.stroke()}}
    for(let k=0;k<3;k++){if(bgH(n,k+43)<.35)continue;const qx=x+(8+k*15+bgH(n,k+40)*8)*u,g=Y(qx),hh=(5+bgH(n,k+46)*8)*u;BST('rgba(10,6,0,.45)',3.6,qx,g+2*u,qx+.6*u,g-hh*.5,qx,g-hh);BST('#5b4128',2.2,qx,g+2*u,qx+.6*u,g-hh*.5,qx,g-hh);wdot(qx,g-hh,1.4*u,'#8a6a42')}
    const cx=x+30*u,g=Y(cx),v=bgH(n,50);
    if(v<.28){ctx.fillStyle='rgba(8,18,10,.4)';ctx.beginPath();ctx.ellipse(cx,g+9*u,17*u,3.6*u,0,0,7);ctx.fill();ctx.fillStyle='rgba(124,196,184,.7)';ctx.beginPath();ctx.ellipse(cx,g+8.4*u,15*u,2.8*u,0,0,7);ctx.fill();ctx.strokeStyle='rgba(255,255,255,.55)';ctx.lineWidth=1*u;ctx.beginPath();ctx.moveTo(cx-8*u,g+7.8*u);ctx.lineTo(cx+2*u,g+7.8*u);ctx.stroke();const ph=(t*.6+n)%1;ctx.strokeStyle='rgba(255,255,255,'+(.5*(1-ph)).toFixed(2)+')';ctx.beginPath();ctx.ellipse(cx+4*u,g+8.6*u,ph*9*u+1,ph*1.6*u+.5,0,0,7);ctx.stroke();if(bgH(n,55)>.35){mgPad(cx-6*u,g+8.5*u,3.8*u,.1);mgPad(cx+8*u,g+8.9*u,3*u,-.2)}}
    else if(v<.5){const s2=Math.sin(t*1.5+n)*1.2*u;BST('#4f6a24',1.8,cx,g+1*u,cx+s2,g-9*u,cx+s2*1.5,g-16*u);BOV(cx+s2*1.5-3.4*u,g-15*u,3.8*u,1.8*u,'#6fb04a',-.5);BOV(cx+s2*1.5+3.4*u,g-17.5*u,3.8*u,1.8*u,'#8fcf5a',.5)}
    else if(v>.9){const c2=cx+Math.sin(t*1.5+n)*7*u,y2=g+3.6*u;BOV(c2-7*u,y2-2*u,2.6*u,2*u,'#f07a4a',-.4);BOV(c2+7*u,y2-2*u,2.6*u,2*u,'#f07a4a',.4);BOV(c2,y2,5.4*u,3.2*u,'#e0623a');wdot(c2-2*u,y2-4.6*u,1.1*u,'#1a0f08');wdot(c2+2*u,y2-4.6*u,1.1*u,'#1a0f08')}
  }
}
export function sea(){
  if(!state.tr)return;const a=state.tr.rs-state.dist,b=state.tr.re-state.dist,L=Math.max(-10,a),R=Math.min(W+10,b);if(R<=L)return;
  const wl=x=>G+ter(x)+3*u+Math.sin(t*1.6+(x+state.dist)*.02)*2*u,e=Math.min(.45,150*u/(b-a));
  for(const[y0,h,c]of[[-30,12,'96,176,196'],[-19,13,'58,142,176'],[-7,12,'30,104,150']]){const g=ctx.createLinearGradient(a,0,b,0);g.addColorStop(0,'rgba('+c+',0)');g.addColorStop(e,'rgba('+c+',.9)');g.addColorStop(1-e,'rgba('+c+',.9)');g.addColorStop(1,'rgba('+c+',0)');ctx.fillStyle=g;ctx.fillRect(L,G+y0*u,R-L,h*u+1)}
  ctx.save();ctx.beginPath();ctx.rect(L,0,R-L,H);ctx.clip();ctx.lineCap='round';
  const g=ctx.createLinearGradient(0,G-6*u,0,H);g.addColorStop(0,'#3ab3cc');g.addColorStop(.25,'#1f7eae');g.addColorStop(1,'#08305a');
  ctx.fillStyle=g;ctx.beginPath();ctx.moveTo(L,H);for(let x=L;x<=R+8;x+=8)ctx.lineTo(x,wl(x));ctx.lineTo(R+8,H);ctx.closePath();ctx.fill();
  for(let q=0;q<3;q++){ctx.fillStyle='rgba(8,48,96,'+(.16+q*.06).toFixed(2)+')';ctx.beginPath();ctx.moveTo(L,H);for(let x=L;x<=R+8;x+=8)ctx.lineTo(x,G+(12+q*18)*u+Math.sin(t*(1+q*.3)+(x+state.dist*(1+q*.1))*.012/(1+q*.2))*(4+q)*u);ctx.lineTo(R+8,H);ctx.closePath();ctx.fill()}
  for(let q=0;q<4;q++){const sp=(120+q*34)*u,f=state.dist*(1+q*.14),oy=(7+q*15)*u;ctx.strokeStyle='rgba(255,255,255,'+(.5-q*.09).toFixed(2)+')';ctx.lineWidth=(2.2-q*.3)*u;ctx.beginPath();for(let i=Math.floor((L+f)/sp)-1;i*sp-f<R+sp;i++){const x=i*sp-f+bgH(i,q)*30*u,yy=wl(x)+oy+Math.sin(t*2+q+x*.02)*2*u;ctx.moveTo(x,yy);ctx.quadraticCurveTo(x+9*u,yy-3.4*u,x+(26-q*4)*u,yy)}ctx.stroke()}
  ctx.strokeStyle='#f4f7fb';ctx.lineWidth=1.8*u;const M=W+80*u;
  for(let i=0;i<3;i++){const x=(((i*W*.41-state.dist*.1-t*22*u)%M)+M)%M-40*u,yy=G-(78+i*30)*u+Math.sin(t*1.3+i)*6*u,f=Math.sin(t*7+i*2)*4*u;ctx.beginPath();ctx.moveTo(x-9*u,yy-f);ctx.quadraticCurveTo(x-4*u,yy-5*u,x,yy);ctx.quadraticCurveTo(x+4*u,yy-5*u,x+9*u,yy-f);ctx.stroke()}
  for(let i=0;i<4;i++){const x=L+((i*97.3+state.dist*.5)%(R-L+1));obSpk(x,wl(x)+(8+i*9)*u,i*1.7)}
  ctx.restore();
  if(a>-120*u&&a<W+120*u)for(let i=0;i<3;i++){const x=a+(10+i*38)*u,yy=wl(x)+(1+i%2)*u,w=(14+i*5)*u;ctx.fillStyle='rgba(50,90,140,.35)';ctx.beginPath();ctx.ellipse(x+2*u,yy+2.4*u,w,3.4*u,0,0,7);ctx.fill();BOV(x,yy,w,3.6*u,'#eaf6ff');ctx.fillStyle='#fff';ctx.beginPath();ctx.ellipse(x-w*.2,yy-1*u,w*.5,1.2*u,0,0,7);ctx.fill()}
  if(b>-120*u&&b<W+120*u)for(let i=0;i<3;i++){const x=b-(16+i*46)*u;mgTree(x,wl(x)+2*u,.7+i*.12,i+50,'#4e3720','#2f6a3e')}
}
/* ---- Mangrove obstacles: hand-drawn knotted roots, breathing roots, stranded log, sapling, hanging root curtain and the murky bog ---- */
export function mgSpawn(){
  const q=Math.random(),a=Math.random(),c=Math.random();
  if(q<.2)return{m:'knot',w:(48+a*10)*u,h:(36+c*8)*u,f:0,p:false};
  if(q<.4)return{m:'pneu',w:(42+a*10)*u,h:(44+c*10)*u,f:0,p:false};
  if(q<.57)return{m:'log',w:(84+a*16)*u,h:(32+c*6)*u,f:0,p:false};
  if(q<.69)return{m:'sap',w:32*u,h:(62+c*8)*u,f:0,p:false};
  if(q<.85)return{m:'vine',w:(56+a*14)*u,h:G+60*u,f:44*u,p:false};
  return{m:'bog',w:(96+a*30)*u,h:0,f:0,p:true}
}
/* three-pass root stroke: dark edge, bark, warm highlight (same look as the roots on the mangrove road) */
export const mgRt=(w,x0,y0,cx,cy,x1,y1,c,hl)=>{const d=w*.18*u;BST('rgba(12,6,2,.55)',w+2.4,x0,y0,cx,cy,x1,y1);BST(c||'#7a5230',w,x0,y0,cx,cy,x1,y1);BST(hl||'rgba(224,172,110,.7)',Math.max(.8,w*.22),x0-d,y0-d,cx-d,cy-d,x1-d,y1-d)};
const mgFt=(x,y,r)=>{ctx.fillStyle='rgba(30,20,8,.55)';ctx.beginPath();ctx.ellipse(x,y+1*u,r*u,r*.42*u,0,0,7);ctx.fill();ctx.fillStyle='rgba(120,168,80,.55)';ctx.beginPath();ctx.ellipse(x-r*.25*u,y+.2*u,r*.5*u,r*.2*u,0,0,7);ctx.fill()};
export const mgLf=(x,y,a,l,wd,c1,c2)=>{ctx.save();ctx.translate(x,y);ctx.rotate(a);ctx.beginPath();ctx.moveTo(0,0);ctx.quadraticCurveTo(l*.45,-wd,l,0);ctx.quadraticCurveTo(l*.45,wd,0,0);ctx.fillStyle=c1;ctx.fill();wol(1);ctx.strokeStyle=c2;ctx.lineWidth=.9*u;ctx.beginPath();ctx.moveTo(l*.08,0);ctx.lineTo(l*.88,0);ctx.stroke();ctx.restore()};
const mgPad=(px,py,r,rot)=>{ctx.save();ctx.translate(px,py);ctx.rotate(rot||0);
  ctx.fillStyle='#4e9a46';ctx.beginPath();ctx.ellipse(0,0,r,r*.36,0,.26,6.02);ctx.lineTo(0,0);ctx.closePath();ctx.fill();wol(1);
  ctx.fillStyle='rgba(200,240,140,.45)';ctx.beginPath();ctx.ellipse(-r*.18,-r*.1,r*.5,r*.12,0,0,7);ctx.fill();
  ctx.strokeStyle='rgba(20,66,26,.5)';ctx.lineWidth=.7*u;ctx.beginPath();for(const a of[.7,1.6,2.5,3.6,4.6,5.5]){ctx.moveTo(0,0);ctx.lineTo(Math.cos(a)*r*.86,Math.sin(a)*r*.3)}ctx.stroke();ctx.restore()};
const mgMound=(x,w,hh)=>{ctx.fillStyle=wlg(G-hh,G+6*u,'#6a5532','#2e2314');ctx.beginPath();ctx.moveTo(x-4*u,G+4*u);ctx.quadraticCurveTo(x+w*.14,G-hh*1.5,x+w*.5,G-hh*1.5);ctx.quadraticCurveTo(x+w*.86,G-hh*1.5,x+w+4*u,G+4*u);ctx.closePath();ctx.fill();wol(1.4);ctx.fillStyle='rgba(206,232,184,.2)';ctx.beginPath();ctx.ellipse(x+w*.4,G-hh*.6,w*.2,1.4*u,-.05,0,7);ctx.fill()};
export function obMang(o){
  const sd=o.sd||(o.sd=Math.random()*6.28),k=o.m;ctx.lineJoin=ctx.lineCap='round';
  if(k==='bog')mgBog(o,sd);else if(k==='vine')mgVine(o,sd);
  else{ctx.fillStyle='rgba(8,18,8,.34)';ctx.beginPath();ctx.ellipse(o.x+o.w*.5,G+3*u,o.w*.62,4.2*u,0,0,7);ctx.fill();
    (k==='knot'?mgKnot:k==='pneu'?mgPneu:k==='log'?mgLog:mgSap)(o,sd)}
}
/* knotted stilt roots: a gnarled stub with arching roots tangled around it */
function mgKnot(o,sd){
  const x=o.x,w=o.w,h=o.h,b=G,cx=x+w/2,sw=Math.sin(t*1.5+sd)*.9*u,dk='#4a2e1a',dh='rgba(170,120,74,.45)';
  mgMound(x,w,7*u);
  mgRt(3.4,cx-3*u,b-h*.8,x-w*.06,b-h*1.04,x+w*.1,b+1*u,dk,dh);mgRt(3.4,cx+3*u,b-h*.8,x+w*1.06,b-h*1.04,x+w*.9,b+1*u,dk,dh);
  mgRt(3,cx-1*u,b-h*.7,cx-w*.34,b-h*.52,cx-w*.22,b+1*u,dk,dh);mgRt(3,cx+1*u,b-h*.7,cx+w*.34,b-h*.52,cx+w*.22,b+1*u,dk,dh);
  /* the stub */
  ctx.fillStyle=wlg(b-h,b-h*.3,'#8d6039','#4e3220');ctx.beginPath();ctx.moveTo(cx-w*.17,b-h*.26);ctx.quadraticCurveTo(cx-w*.2,b-h*.62,cx-w*.1+sw*.3,b-h*.96);ctx.quadraticCurveTo(cx+sw*.4,b-h*1.05,cx+w*.1+sw*.3,b-h*.95);ctx.quadraticCurveTo(cx+w*.21,b-h*.6,cx+w*.17,b-h*.26);ctx.closePath();ctx.fill();wol(1.5);
  ctx.strokeStyle='rgba(30,16,6,.5)';ctx.lineWidth=1.1*u;ctx.beginPath();for(const a of[-.07,.02,.09]){ctx.moveTo(cx+w*a,b-h*.3);ctx.quadraticCurveTo(cx+w*(a-.02),b-h*.6,cx+w*(a+.01)+sw*.3,b-h*.9)}ctx.stroke();
  ctx.strokeStyle='rgba(236,186,126,.4)';ctx.lineWidth=1.3*u;ctx.beginPath();ctx.moveTo(cx-w*.11,b-h*.4);ctx.quadraticCurveTo(cx-w*.14,b-h*.66,cx-w*.07+sw*.3,b-h*.9);ctx.stroke();
  ctx.fillStyle='#1c0f06';ctx.beginPath();ctx.ellipse(cx+w*.03,b-h*.7,2.3*u,3.3*u,.2,0,7);ctx.fill();ctx.strokeStyle='rgba(224,170,110,.45)';ctx.lineWidth=.9*u;ctx.stroke();
  /* front arches and the crossing tangle */
  mgRt(4.6,cx-w*.08,b-h*.6,x-w*.04,b-h*.72,x+w*.04,b+1*u);mgRt(4.6,cx+w*.08,b-h*.6,x+w*1.04,b-h*.72,x+w*.96,b+1*u);
  mgRt(3.6,cx-w*.04,b-h*.46,x+w*.14,b-h*.7,x+w*.32,b+1*u);mgRt(3.6,cx+w*.04,b-h*.46,x+w*.86,b-h*.7,x+w*.68,b+1*u);
  mgRt(2.6,x+w*.1,b-h*.34,cx,b-h*.88,x+w*.9,b-h*.3,'#6a4428');
  mgRt(2.4,x-2*u,b+1*u,x+w*.16,b-5*u,x+w*.3,b+1.5*u);mgRt(2.4,x+w*.7,b+1.5*u,x+w*.84,b-5*u,x+w+2*u,b+1*u);
  for(const a of[.04,.1,.3,.7,.9,.96])mgFt(x+w*a,b,3.6);
  /* moss, barnacles, a sprout on top */
  BOV(x+w*.2,b-h*.6,5*u,2.2*u,'#5f8f3a',-.4);BOV(x+w*.8,b-h*.6,5*u,2.2*u,'#5f8f3a',.4);BOV(cx-w*.06,b-h*.52,3.6*u,1.8*u,'#6f9f44',-.2);
  ctx.fillStyle='rgba(200,240,150,.4)';ctx.beginPath();ctx.ellipse(x+w*.19,b-h*.63,2.6*u,.8*u,-.4,0,7);ctx.ellipse(x+w*.79,b-h*.63,2.6*u,.8*u,.4,0,7);ctx.fill();
  for(const a of[.2,.8]){const mx=x+w*a,sy=b-h*.56;BST('rgba(120,170,76,.85)',1,mx,sy,mx+sw*.4,sy+4*u,mx+sw,sy+8*u);BST('rgba(120,170,76,.85)',1,mx+3*u,sy,mx+3*u+sw*.4,sy+3*u,mx+3*u+sw,sy+6*u)}
  for(let q=0;q<5;q++){wdot(x+w*.07+q*1.7*u,b-4*u-(q%2)*1.6*u,(.8+q%2*.3)*u,'#e6dfc6');wdot(x+w*.93-q*1.7*u,b-4*u-(q%2)*1.6*u,(.8+q%2*.3)*u,'#e6dfc6')}
  const tx=cx+sw*.3,ty=b-h*1.0;BST('#4f7a2a',1.4,tx,ty+2*u,tx+sw*.3,ty-2*u,tx+sw*.6,ty-5*u);
  mgLf(tx+sw*.6,ty-5*u,-1.1+sw*.02,10*u,3.6*u,'#6fb04a','rgba(240,255,200,.5)');mgLf(tx+sw*.6,ty-5*u,-2.1+sw*.02,9*u,3.2*u,'#8fcf5a','rgba(240,255,200,.5)');
  ctx.fillStyle='rgba(255,255,255,.3)';ctx.beginPath();ctx.ellipse(x+w*.07,b-h*.32,1.6*u,.7*u,-.9,0,7);ctx.ellipse(x+w*.93,b-h*.32,1.6*u,.7*u,.9,0,7);ctx.fill();
}
/* breathing roots: a bed of wet pencil roots standing out of the mud */
function mgPneu(o,sd){
  const x=o.x,w=o.w,h=o.h,b=G,cx=x+w/2;
  mgMound(x,w,6*u);
  const S=[[.1,.5,-2,0],[.26,.84,-3,0],[.42,1,-1,0],[.6,.9,2,0],[.78,.74,3,0],[.92,.44,3,0],[.18,.62,-1,1],[.34,.76,1,1],[.52,.66,-1.5,1],[.7,.8,2,1],[.86,.58,1,1]];
  for(const[fx,fh,ln,ly]of S){
    const sx=x+w*fx,th=h*fh,bw=(2.6+fh*1.5)*u,tx=sx+ln*u+Math.sin(t*1.2+sd+fx*6)*.3*u,ty=b-th;
    ctx.fillStyle=wlg(ty,b,ly?'#bd8f58':'#92704a','#3c2a1c');
    ctx.beginPath();ctx.moveTo(sx-bw,b+1.5*u);ctx.quadraticCurveTo(sx-bw*.45+ln*u*.3,b-th*.55,tx,ty);ctx.quadraticCurveTo(sx+bw*.45+ln*u*.3,b-th*.55,sx+bw,b+1.5*u);ctx.closePath();ctx.fill();wol(1.3);
    ctx.strokeStyle='rgba(24,14,6,.42)';ctx.lineWidth=1*u;ctx.beginPath();for(const q of[.28,.5,.7]){const yy=b-th*q,hw=bw*(1-q*.8),mx=sx+ln*u*q*.5;ctx.moveTo(mx-hw,yy);ctx.quadraticCurveTo(mx,yy+1.6*u,mx+hw,yy)}ctx.stroke();
    ctx.strokeStyle='rgba(244,204,144,.5)';ctx.lineWidth=1*u;ctx.beginPath();ctx.moveTo(sx-bw*.5,b-th*.12);ctx.quadraticCurveTo(sx-bw*.3+ln*u*.2,b-th*.5,tx-.6*u,ty+th*.12);ctx.stroke();
    wdot(tx,ty+.4*u,.9*u,'rgba(246,224,184,.92)');
    if(ly&&fx>.5&&fx<.6){const ph=(t*.8+sd)%1;wdot(tx+.4*u,ty+ph*ph*th*.5,.8*u,'rgba(180,220,200,'+(.8*(1-ph)).toFixed(2)+')')}
  }
  mgLf(x+w*.3,b+1*u,-1.0,6*u,2.2*u,'#6fb04a','rgba(240,255,200,.5)');mgLf(x+w*.3,b+1*u,-2.0,5*u,2*u,'#8fcf5a','rgba(240,255,200,.5)');mgLf(x+w*.66,b+1*u,-1.2,5.5*u,2*u,'#6fb04a','rgba(240,255,200,.5)');
  ctx.fillStyle=wlg(b-2*u,b+6*u,'#5e482a','#2a2012');ctx.beginPath();ctx.ellipse(cx,b+3*u,w*.58,4.4*u,0,0,7);ctx.fill();wol(1.2);
  ctx.fillStyle='rgba(206,232,184,.25)';ctx.beginPath();ctx.ellipse(cx-w*.12,b+1.8*u,w*.22,1.2*u,0,0,7);ctx.fill();
  ctx.fillStyle='rgba(96,150,62,.75)';for(const a of[.12,.4,.64,.88]){ctx.beginPath();ctx.ellipse(x+w*a,b+2.2*u,3.4*u,1*u,0,0,7);ctx.fill()}
}
/* a stranded log lying in a murky puddle, with moss, a bracket fungus and a fiddler crab */
function mgLog(o,sd){
  const x=o.x,w=o.w,h=o.h,b=G,cx=x+w/2,lx=x+h*.24,lw=w-h*.24-3*u,rd=h*.4,sw=Math.sin(t*1.6+sd)*1.2*u;
  ctx.fillStyle='rgba(38,66,56,.62)';ctx.beginPath();ctx.ellipse(cx,b+3.4*u,w*.58,5*u,0,0,7);ctx.fill();
  ctx.strokeStyle='rgba(196,232,204,.4)';ctx.lineWidth=1*u;ctx.beginPath();ctx.moveTo(x+w*.1,b+3.2*u);ctx.lineTo(x+w*.26,b+3.2*u);ctx.moveTo(x+w*.62,b+5.2*u);ctx.lineTo(x+w*.86,b+5.2*u);ctx.stroke();
  ctx.fillStyle=wlg(b-h,b,'#957550','#4a3322');rr(lx,b-h,lw,h,rd);ctx.fill();wol(1.6);
  ctx.save();rr(lx,b-h,lw,h,rd);ctx.clip();
  ctx.strokeStyle='rgba(36,20,8,.5)';ctx.lineWidth=1.2*u;ctx.beginPath();for(let q=1;q<4;q++){const yy=b-h*q*.25;ctx.moveTo(lx+h*.1,yy);ctx.quadraticCurveTo(lx+lw*.3,yy+2*u,lx+lw*.5,yy-1*u);ctx.quadraticCurveTo(lx+lw*.72,yy-2.4*u,lx+lw,yy+1*u)}ctx.stroke();
  ctx.fillStyle='rgba(255,226,170,.26)';ctx.beginPath();ctx.ellipse(cx,b-h*.84,lw*.4,h*.08,0,0,7);ctx.fill();
  ctx.fillStyle='rgba(84,128,60,.62)';ctx.beginPath();ctx.moveTo(lx,b+1*u);for(let q=0;q<=lw;q+=5*u)ctx.lineTo(lx+q,b-h*.2+Math.sin(q*.35+sd)*1.2*u);ctx.lineTo(lx+lw,b+1*u);ctx.closePath();ctx.fill();
  ctx.fillStyle='#24140a';ctx.beginPath();ctx.ellipse(x+w*.46,b-h*.5,2.8*u,4*u,.15,0,7);ctx.fill();ctx.strokeStyle='rgba(224,170,110,.4)';ctx.lineWidth=.9*u;ctx.stroke();
  for(let q=0;q<7;q++)wdot(lx+lw*.1+q*lw*.04+(q%2)*1.4*u,b-h*.3-(q%3)*1.8*u,(.8+q%2*.3)*u,'#e6dfc6');
  ctx.restore();
  /* weathered cut end with rings */
  BOV(lx,b-h/2,h*.21,h*.5,'#d3b07c');ctx.strokeStyle='#a77a48';ctx.lineWidth=1.1*u;for(const q of[.66,.34]){ctx.beginPath();ctx.ellipse(lx,b-h/2,h*.21*q,h*.5*q,0,0,7);ctx.stroke()}wdot(lx,b-h/2,1.1*u,'#7a5028');
  ctx.strokeStyle='rgba(90,58,26,.55)';ctx.lineWidth=.8*u;ctx.beginPath();ctx.moveTo(lx,b-h/2);ctx.lineTo(lx-h*.12,b-h*.82);ctx.moveTo(lx,b-h/2);ctx.lineTo(lx+h*.1,b-h*.2);ctx.stroke();
  /* torn root fibres at the far end */
  mgRt(2.4,x+w-5*u,b-h*.74,x+w-1*u,b-h*.98,x+w+1*u,b-h*1.04,'#6a4528');mgRt(2,x+w-4*u,b-h*.46,x+w+2*u,b-h*.54,x+w+2*u,b-h*.8,'#6a4528');mgRt(1.6,x+w-5*u,b-h*.3,x+w+1*u,b-h*.28,x+w+3*u,b-h*.12,'#5a3a22');
  /* moss with hanging strands, sprout, fungus */
  for(const[a,r]of[[.28,5],[.52,6.4],[.78,5]]){BOV(x+w*a,b-h+1*u,r*u,2.4*u,'#5f8f3a');ctx.fillStyle='rgba(200,240,150,.38)';ctx.beginPath();ctx.ellipse(x+w*a-r*.2*u,b-h-.2*u,r*.5*u,.8*u,0,0,7);ctx.fill();
    const mx=x+w*a+r*.4*u;BST('rgba(122,176,80,.85)',1.1,mx,b-h+2*u,mx+1*u+sw*.3,b-h*.72,mx+sw*.7,b-h*.55);wdot(mx+sw*.7,b-h*.55,1.1*u,'#a8d26a')}
  BST('#4f7a2a',1.3,x+w*.4,b-h,x+w*.4+1*u,b-h-3*u,x+w*.4+2*u+sw*.3,b-h-6*u);mgLf(x+w*.4+2*u+sw*.3,b-h-6*u,-1.0,7*u,2.6*u,'#6fb04a','rgba(240,255,200,.5)');mgLf(x+w*.4+2*u+sw*.3,b-h-6*u,-2.1,6*u,2.4*u,'#8fcf5a','rgba(240,255,200,.5)');
  for(const[dy,r,c]of[[0,5,'#d8c898'],[2.6,4.2,'#e9dcb4']]){const fx=x+w*.64,fy=b-h*.5+dy*u;ctx.fillStyle=c;ctx.beginPath();ctx.ellipse(fx,fy,r*u,2.2*u,.08,Math.PI,0);ctx.closePath();ctx.fill();wol(1);ctx.strokeStyle='rgba(120,84,40,.5)';ctx.lineWidth=.9*u;ctx.beginPath();ctx.ellipse(fx,fy-.4*u,r*.7*u,1.3*u,.08,Math.PI,0);ctx.stroke()}
  {const cr=Math.sin(t*4+sd)*.5,kx=x+w*.82+Math.sin(t*.7+sd)*2*u,ky=b-h-1.6*u;
    for(const sg of[-1,1])for(let q=0;q<3;q++)BST('#b8482a',1,kx+sg*2*u,ky+1*u,kx+sg*(4+q)*u,ky+2.4*u,kx+sg*(5+q*1.6)*u,ky+3.4*u);
    BST('#b8482a',1,kx-1.4*u,ky-1.4*u,kx-1.8*u,ky-3*u,kx-1.6*u,ky-4*u);BST('#b8482a',1,kx+1.4*u,ky-1.4*u,kx+1.8*u,ky-3*u,kx+1.6*u,ky-4*u);
    BOV(kx,ky,3.6*u,2.4*u,'#e0623a');BOV(kx-4.6*u,ky-1.6*u,1.4*u,1*u,'#f07a4a',.3);BOV(kx+4.4*u,ky-3.2*u-cr*2*u,2.6*u,1.8*u,'#f07a4a',.5+cr);
    wdot(kx-1.6*u,ky-4.4*u,.9*u,'#1a0f08');wdot(kx+1.6*u,ky-4.4*u,.9*u,'#1a0f08')}
  /* waterline lap in front */
  ctx.fillStyle='rgba(52,92,80,.55)';ctx.beginPath();ctx.moveTo(x+2*u,b+6*u);for(let q=0;q<=w-4*u;q+=6*u)ctx.lineTo(x+2*u+q,b-.5*u+Math.sin(t*2.4+q*.2+sd)*.9*u);ctx.lineTo(x+w-2*u,b+6*u);ctx.closePath();ctx.fill();
  ctx.strokeStyle='rgba(220,244,226,.5)';ctx.lineWidth=1*u;ctx.beginPath();for(let q=0;q<=w-4*u;q+=6*u){const yy=b-.5*u+Math.sin(t*2.4+q*.2+sd)*.9*u;q?ctx.lineTo(x+2*u+q,yy):ctx.moveTo(x+2*u,yy)}ctx.stroke();
  const ph=(t*.5+sd)%1;ctx.strokeStyle='rgba(220,244,226,'+(.5*(1-ph)).toFixed(2)+')';ctx.lineWidth=.9*u;ctx.beginPath();ctx.ellipse(x+w*.2,b+4.6*u,ph*8*u+1,ph*1.6*u+.4,0,0,7);ctx.stroke();
}
/* a young mangrove on prop roots, crowned with glossy leaves and hanging propagules */
function mgSap(o,sd){
  const x=o.x,w=o.w,h=o.h,b=G,cx=x+w/2,sw=Math.sin(t*1.5+sd)*1.6*u,tx=cx+sw*.6,ty=b-h*.78,dk='#4a2e1a',dh='rgba(170,120,74,.45)';
  mgMound(x,w,5*u);
  mgRt(2.8,cx,b-h*.34,x-w*.1,b-h*.5,x+1*u,b+1*u,dk,dh);mgRt(2.8,cx,b-h*.34,x+w*1.1,b-h*.5,x+w-1*u,b+1*u,dk,dh);
  mgRt(5,cx,b-h*.28,cx+sw*.3,b-h*.55,tx,ty);
  ctx.strokeStyle='rgba(30,16,6,.5)';ctx.lineWidth=1*u;ctx.beginPath();for(const q of[.5,.62,.74]){const yy=b-h*q,mx=cx+sw*.5*q;ctx.moveTo(mx-2*u,yy);ctx.lineTo(mx+1.6*u,yy-1*u)}ctx.stroke();
  mgRt(3.4,cx-1*u,b-h*.42,x-w*.02,b-h*.5,x+w*.26,b+1*u);mgRt(3.4,cx+1*u,b-h*.42,x+w*1.02,b-h*.5,x+w*.74,b+1*u);
  for(const a of[0,.26,.74,1])mgFt(x+w*a+(a?-1:1)*(a%1?0:1)*u,b,3.2);
  for(let q=0;q<4;q++)wdot(cx-6*u+q*3.6*u,b-h*.24-(q%2)*2*u,.9*u,'#e6dfc6');
  /* propagules hang under the crown */
  for(const[dx,l,p]of[[-4,13,0],[3,16,1.7],[7,11,3.1]]){const px2=tx+dx*u,sy2=ty+3*u,sv=Math.sin(t*1.8+sd+p)*1.4*u;
    BST('rgba(20,40,14,.5)',3.6,px2,sy2,px2+sv*.3,sy2+l*u*.5,px2+sv,sy2+l*u);BST('#86ad45',2.4,px2,sy2,px2+sv*.3,sy2+l*u*.5,px2+sv,sy2+l*u);BST('#7a5a34',2.8,px2+sv*.9,sy2+l*u*.82,px2+sv*.95,sy2+l*u*.9,px2+sv,sy2+l*u)}
  const LV=[[-2.9,13,4.4],[-2.4,16,5],[-1.95,18,5.4],[-1.57,19,5.6],[-1.2,18,5.4],[-.75,16,5],[-.3,13,4.4],[2.5,10,3.8],[.64,10,3.8]];
  LV.forEach(([a,l,wd],i)=>mgLf(tx,ty,a+sw*.012*(i%2?1:-1),l*u,wd*u,i%2?'#3f8a45':'#2f7a3f','rgba(220,250,170,.4)'));
  ctx.fillStyle='rgba(230,255,170,.3)';ctx.beginPath();ctx.ellipse(tx-3*u,ty-9*u,5*u,1.4*u,-.5,0,7);ctx.fill();
}
/* hanging root curtain: wavy tapered aerial roots, drooping fronds, moss and drips from a canopy clump, down to a low gap. Run under it; jumping into it hurts. */
function mgVine(o,sd){
  const x=o.x,w=o.w,b=G,yb=b-o.f,cx=x+w/2,y0=-ter(cx),top=y0-34*u,S=Math.sin(t*1.1+sd);
  ctx.fillStyle='rgba(8,18,8,.16)';ctx.beginPath();ctx.ellipse(cx,b+3*u,w*.55,3.6*u,0,0,7);ctx.fill();
  /* shadowed foliage behind the roots */
  const bk=ctx.createLinearGradient(0,y0,0,yb);bk.addColorStop(0,'rgba(12,32,18,.96)');bk.addColorStop(1,'rgba(24,52,28,.86)');
  ctx.fillStyle=bk;ctx.beginPath();ctx.moveTo(x+3*u,top);for(let y=top;y<yb-12*u;y+=26*u)ctx.lineTo(x+3*u+Math.sin(y*.045+sd)*1.3*u,y);ctx.lineTo(x+3*u,yb-9*u);for(let i=0;i<5;i++)ctx.quadraticCurveTo(x+3*u+(w-6*u)*(i+.5)/5,yb+(i%2?-1:2)*u,x+3*u+(w-6*u)*(i+1)/5,yb-8*u-(i%2)*3*u);ctx.lineTo(x+w-3*u,yb-9*u);for(let y=yb-12*u;y>top;y-=26*u)ctx.lineTo(x+w-3*u+Math.sin(y*.05+sd+2)*1.3*u,y);ctx.lineTo(x+w-3*u,top);ctx.closePath();ctx.fill();
  for(let yy=yb-22*u,r=0;yy>y0+36*u;yy-=44*u,r++){const sv=Math.sin(t*1.3+sd+r)*.08;
    mgLf(x+3*u,yy,2.45+sv,12*u,4.2*u,r%2?'#3a7a45':'#2f6a3e','rgba(200,240,150,.38)');mgLf(x+w-3*u,yy-14*u,.7-sv,12*u,4.2*u,r%2?'#2f6a3e':'#3a7a45','rgba(200,240,150,.38)')}
  /* tapered, swaying roots with knuckles */
  const pal=['#6b4526','#7a5230','#5b3a22','#6f4a2a'],strand=(xi,wd,ph,yt,col,amp)=>{
    const L=yt-top,N=Math.max(8,Math.ceil(L/(22*u))),P=[];
    for(let k=0;k<=N;k++){const q=k/N,y=top+L*q,xx=xi+Math.sin(y/(30*u)+ph)*amp*u+S*2.2*u*q*q*(ph>3?-1:1);let ww=wd*u*(1+.22*Math.sin(y/(26*u)+ph*2));const tp=(yt-y)/(30*u);if(tp<1)ww*=Math.max(.06,tp);P.push([xx,y,ww*.5])}
    ctx.beginPath();ctx.moveTo(P[0][0]-P[0][2],P[0][1]);for(const[a,y,r]of P)ctx.lineTo(a-r,y);for(let k=N;k>=0;k--){const[a,y,r]=P[k];ctx.lineTo(a+r,y)}ctx.closePath();ctx.fillStyle=col;ctx.fill();wol(1.1);
    ctx.strokeStyle='rgba(226,176,114,.55)';ctx.lineWidth=Math.max(.7,wd*.2)*u;ctx.beginPath();P.forEach(([a,y,r],k)=>{k?ctx.lineTo(a-r*.45,y):ctx.moveTo(a-r*.45,y)});ctx.stroke();
    ctx.strokeStyle='rgba(20,10,4,.28)';ctx.lineWidth=Math.max(.6,wd*.12)*u;ctx.beginPath();P.forEach(([a,y,r],k)=>{k?ctx.lineTo(a+r*.5,y):ctx.moveTo(a+r*.5,y)});ctx.stroke();
    return P};
  const n=8,E=[];
  for(const i of[0,7,1,6,2,5,3,4]){const f=i/(n-1),m=1-Math.abs(2*f-1),xi=x+w*(.1+.8*f)+(bgH(i,3)-.5)*2*u,yt=yb-bgH(i,5)*7*u;
    const P=strand(xi,2.4+3.4*m+(i===3||i===4?.8:0),bgH(i,4)*6.28,yt,pal[i%4],1+bgH(i,6)*1.6);E.push([P[P.length-1][0],yt])}
  mgRt(2.6,x+3*u,yb-84*u,cx+S*2*u,yb-62*u,x+w-3*u,yb-90*u,'#6b4526');mgRt(2.2,x+4*u,yb-36*u,cx-S*2*u,yb-24*u,x+w-4*u,yb-44*u,'#5b3a22');
  /* rootlets at the tips, drips falling to the road */
  E.forEach(([ex,ey],i)=>{if(i%2===0){BST('#5b3a22',1,ex,ey-16*u,ex-3*u,ey-10*u,ex-4.4*u,ey-4*u);BST('#5b3a22',1,ex,ey-12*u,ex+3*u,ey-7*u,ex+4*u,ey-2*u)}
    if(i%3===1){const ph=(t*.7+sd+i*.37)%1;wdot(ex,ey+ph*ph*(b-ey-4*u),1.1*u,'rgba(170,215,190,'+(.9*(1-ph*.5)).toFixed(2)+')')}});
  /* moss, tendrils with curled tips, leaves */
  [-112,-70,-28].forEach((dy,r)=>{const y=yb+dy*u;if(y<y0+40*u)return;for(let q=0;q<3;q++){const mx=x+w*(.2+.3*q)+(bgH(r*3+q,9)-.5)*4*u,rr2=(5.4+bgH(r*3+q,11)*2.6)*u;BOV(mx,y,rr2,2.8*u,r%2?'#4f7e34':'#5f8f3a',(bgH(r*3+q,13)-.5)*.5);ctx.fillStyle='rgba(200,240,150,.34)';ctx.beginPath();ctx.ellipse(mx-rr2*.2,y-1*u,rr2*.5,.8*u,0,0,7);ctx.fill();
      const sv=Math.sin(t*1.2+sd+r+q)*1.6*u;BST('rgba(130,184,86,.85)',1.1,mx,y+1.4*u,mx+sv*.4,y+7*u,mx+sv,y+14*u);wdot(mx+sv,y+14*u,1.2*u,'#a8d26a')}});
  for(const[a,dy,sg]of[[.3,-56,-1],[.72,-92,1]]){const y=yb+dy*u;if(y<y0+40*u)continue;const sx=x+w*a,sv=Math.sin(t*1.4+sd+a*5)*1.4*u,ex=sx+sg*9*u+sv,ey=y+24*u;
    BST('rgba(14,30,10,.5)',2,sx,y,sx+sg*9*u,y+8*u,ex,ey);BST('#5f8f3a',1.2,sx,y,sx+sg*9*u,y+8*u,ex,ey);ctx.strokeStyle='#5f8f3a';ctx.lineWidth=1.2*u;ctx.beginPath();ctx.arc(ex-sg*1.6*u,ey+1.2*u,2*u,sg>0?-1.0:4.1,sg>0?3.8:-.6,sg<0);ctx.stroke();
    mgLf(sx+sg*3*u,y+4*u,sg>0?.5:2.64,7*u,2.6*u,'#7bbd4c','rgba(240,255,200,.45)')}
  mgLf(x+4*u,yb-98*u,.55,8*u,2.8*u,'#6fb04a','rgba(240,255,200,.45)');mgLf(x+w-4*u,yb-52*u,2.6,8*u,2.8*u,'#8fcf5a','rgba(240,255,200,.45)');
  /* canopy clump the roots hang from, at the top of the screen */
  const C=[[-.46,6,13,'#1f4a2e'],[-.22,10,15,'#2a5e38'],[.05,5,17,'#245434'],[.3,11,15,'#2f6a3e'],[.5,6,12,'#1f4a2e'],[-.05,14,13,'#356b3f']];
  for(const[a,dy,r,c]of C){ctx.fillStyle=c;ctx.beginPath();ctx.arc(cx+w*a*1.1+S*.8*u,y0+dy*u-4*u,r*u,0,7);ctx.fill();wol(1.3)}
  ctx.fillStyle='rgba(190,235,130,.3)';ctx.beginPath();ctx.ellipse(cx-w*.2,y0+3*u,8*u,2.4*u,-.4,0,7);ctx.ellipse(cx+w*.28,y0+6*u,6*u,2*u,-.3,0,7);ctx.fill();
  for(let q=0;q<6;q++){const lx=cx+w*(-.42+q*.17),sv=Math.sin(t*1.5+sd+q)*.1;mgLf(lx,y0+(14+(q%2)*5)*u,1.25+q*.12+sv,(13+(q%3)*3)*u,4*u,q%2?'#2f6a3e':'#3a7a45','rgba(200,240,150,.3)')}
}
/* murky bog pit: dark green-brown water with scum, lily pads, bubbles and sometimes a lurking pair of eyes. Leap it. */
function mgBog(o,sd){
  const x=o.x,w=o.w,b=G,sy=q=>b+1.8*u+Math.sin(t*3+q*.07+x*.01)*1.2*u;
  ctx.fillStyle='#0f0d06';rr(x-3*u,b-1*u,w+6*u,24*u,6*u);ctx.fill();
  const wg=ctx.createLinearGradient(0,b,0,b+22*u);wg.addColorStop(0,'#74904f');wg.addColorStop(.4,'#4d6e46');wg.addColorStop(1,'#1f3022');
  ctx.fillStyle=wg;ctx.beginPath();ctx.moveTo(x,b+22*u);ctx.lineTo(x,sy(0));for(let q=0;q<=w;q+=6*u)ctx.lineTo(x+q,sy(q));ctx.lineTo(x+w,b+22*u);ctx.closePath();ctx.fill();
  ctx.fillStyle='rgba(12,26,16,.32)';ctx.beginPath();ctx.moveTo(x,b+22*u);ctx.lineTo(x,b+12*u);for(let q=0;q<=w;q+=8*u)ctx.lineTo(x+q,b+12*u+Math.sin(t*2+q*.1+2)*1.6*u);ctx.lineTo(x+w,b+22*u);ctx.closePath();ctx.fill();
  ctx.strokeStyle='rgba(10,20,10,.45)';ctx.lineWidth=1.4*u;ctx.beginPath();ctx.moveTo(x+w*.1,b+21*u);ctx.quadraticCurveTo(x+w*.2,b+12*u,x+w*.34,b+18*u);ctx.moveTo(x+w*.66,b+19*u);ctx.quadraticCurveTo(x+w*.8,b+11*u,x+w*.92,b+20*u);ctx.stroke();
  ctx.fillStyle='rgba(176,200,96,.4)';for(let q=0;q<4;q++){const ax=x+w*(.12+q*.24)+Math.sin(t*.4+q+sd)*4*u;ctx.beginPath();ctx.ellipse(ax,sy(ax-x)+1.2*u,(7+q%2*4)*u,1.5*u,0,0,7);ctx.fill()}
  ctx.fillStyle='rgba(150,196,84,.75)';for(let q=0;q<9;q++){const ax=x+w*((q*.113+.06+Math.sin(t*.3+q*2+sd)*.01)%1);ctx.beginPath();ctx.ellipse(ax,sy(ax-x)+.6*u,1.2*u,.6*u,0,0,7);ctx.fill()}
  ctx.strokeStyle='rgba(236,246,206,.5)';ctx.lineWidth=1.3*u;ctx.beginPath();ctx.moveTo(x+w*.2,b+9*u);ctx.lineTo(x+w*.38,b+9*u);ctx.moveTo(x+w*.56,b+13*u);ctx.lineTo(x+w*.8,b+13*u);ctx.stroke();
  ctx.strokeStyle='rgba(222,240,190,.55)';ctx.beginPath();ctx.moveTo(x,sy(0));for(let q=6*u;q<=w;q+=6*u)ctx.lineTo(x+q,sy(q));ctx.stroke();
  for(let q=0;q<3;q++){const ph=(t*.55+q*.37+sd)%1;ctx.strokeStyle='rgba(226,240,196,'+(.55*(1-ph)).toFixed(2)+')';ctx.lineWidth=.8*u;ctx.beginPath();ctx.arc(x+w*(.28+q*.22)+Math.sin(ph*7+q)*1.4*u,b+21*u-ph*17*u,(1.3+q*.4)*u,0,7);ctx.stroke()}
  for(const[a,r,rot]of[[.14,5,-.1],[.27,8,.1],[.5,10,-.12],[.74,8.4,.16],[.88,5,.05]]){const px=x+w*a,py=sy(w*a)+.8*u+Math.sin(t*1.4+a*9+sd)*.5*u;mgPad(px,py,r*u,rot);
    if(a===.5){for(let q=0;q<5;q++)BOV(px-1*u+Math.cos(q*1.2566-1.57)*2.4*u,py-3*u+Math.sin(q*1.2566-1.57)*2.2*u,1.7*u,1.1*u,'#ff8fb0',q*1.2566);wdot(px-1*u,py-3*u,1.2*u,'#ffd23f')}}
  if(sd>4.4){const ex=x+w*(.3+.4*(.5+.5*Math.sin(t*.45+sd))),ey=sy(ex-x),bl=(t+sd)%3.6<.14;
    ctx.fillStyle='rgba(14,30,16,.5)';ctx.beginPath();ctx.ellipse(ex+6*u,ey+3*u,16*u,2.6*u,0,0,7);ctx.fill();
    ctx.strokeStyle='rgba(222,240,190,.4)';ctx.lineWidth=.9*u;ctx.beginPath();ctx.moveTo(ex-9*u,ey+.6*u);ctx.lineTo(ex+10*u,ey-.2*u);ctx.moveTo(ex-4*u,ey+2.4*u);ctx.lineTo(ex+16*u,ey+2*u);ctx.stroke();
    BOV(ex-9*u,ey-.4*u,1.4*u,.9*u,'#4d6a34');BOV(ex-3*u,ey-1.4*u,2.4*u,1.8*u,'#59743a');BOV(ex+3.4*u,ey-1.4*u,2.4*u,1.8*u,'#59743a');
    if(bl){ctx.strokeStyle='#1a1208';ctx.lineWidth=1*u;ctx.beginPath();ctx.moveTo(ex-4.6*u,ey-1.8*u);ctx.lineTo(ex-1.4*u,ey-1.8*u);ctx.moveTo(ex+2*u,ey-1.8*u);ctx.lineTo(ex+5.2*u,ey-1.8*u);ctx.stroke()}
    else{wdot(ex-3*u,ey-1.8*u,1*u,'#e8c94a');wdot(ex+3.4*u,ey-1.8*u,1*u,'#e8c94a');ctx.strokeStyle='#1a1208';ctx.lineWidth=.8*u;ctx.beginPath();ctx.moveTo(ex-3*u,ey-2.8*u);ctx.lineTo(ex-3*u,ey-.8*u);ctx.moveTo(ex+3.4*u,ey-2.8*u);ctx.lineTo(ex+3.4*u,ey-.8*u);ctx.stroke()}}
  ctx.fillStyle='rgba(226,240,214,.13)';ctx.beginPath();ctx.ellipse(x+w*(.5+Math.sin(t*.3+sd)*.14),b+1*u,w*.4,2.6*u,0,0,7);ctx.fill();
  ctx.fillStyle='#6b5736';rr(x-4*u,b-2*u,13*u,5*u,3*u);ctx.fill();wol(1.2);rr(x+w-9*u,b-2*u,13*u,5*u,3*u);ctx.fill();wol(1.2);
  ctx.fillStyle='rgba(140,170,70,.8)';for(const a of[.02,.98]){ctx.beginPath();ctx.ellipse(x+w*a,b-1.4*u,5*u,1.2*u,0,0,7);ctx.fill()}
  for(const[a,r]of[[.04,1],[.1,.8],[.9,.9],[.96,1.1]]){const rx=x+w*a,sw=Math.sin(t*2+a*9+sd)*2*u,hh=(15+r*6)*u;BST('#4f7a3a',1.8,rx,b-1*u,rx+sw*.5,b-hh*.5,rx+sw,b-hh);BOV(rx+sw,b-hh-3*u,1.8*u,4.4*u,'#7a4a2a',sw*.04)}
  mgRt(3,x-3*u,b-1*u,x+w*.06,b-15*u,x+w*.14,b+5*u);mgRt(3,x+w+3*u,b-1*u,x+w*.94,b-15*u,x+w*.86,b+5*u);
}
/* ---- Mangrove scenery extras: light shafts, gliding egrets, hanging canopy fringe (all background-only, behind every obstacle) ---- */
function mgShafts(){
  ctx.save();ctx.globalCompositeOperation='lighter';
  for(let i=0;i<4;i++){
    const M=W*1.3,x0=((i*W*.31+60*u-state.dist*.05)%M+M)%M-W*.15,sh=.7+.3*Math.sin(t*.35+i*1.9),wd=(30+i%2*22)*u,len=G-10*u,sk=.34;
    const g=ctx.createLinearGradient(x0,0,x0+len*sk,len);g.addColorStop(0,'rgba(255,246,196,'+(.1*sh).toFixed(3)+')');g.addColorStop(1,'rgba(255,246,196,0)');
    ctx.fillStyle=g;ctx.beginPath();ctx.moveTo(x0,0);ctx.lineTo(x0+wd,0);ctx.lineTo(x0+wd+len*sk,len);ctx.lineTo(x0+len*sk-wd*.4,len);ctx.closePath();ctx.fill()}
  ctx.restore();
}
function mgEgrets(){
  ctx.lineCap=ctx.lineJoin='round';const M=W+160*u;
  for(let i=0;i<2;i++){
    const x=(((i*W*.55-state.dist*.06-t*(16+i*7)*u)%M)+M)%M-80*u,yy=G-(150+i*46)*u+Math.sin(t*.9+i*2)*7*u,f=Math.sin(t*5.5+i*2.4),k=1.4+i*.2;
    const wing=(col,dx)=>{const tx=x+(4+dx)*u*k,ty=yy-(9*f+1)*u*k;ctx.beginPath();ctx.moveTo(x-3*u*k,yy-1*u*k);ctx.quadraticCurveTo(x+(dx-1)*u*k,ty-3*u*k,tx,ty);ctx.quadraticCurveTo(x+(5+dx)*u*k,yy-2*u*k,x+5*u*k,yy+1*u*k);ctx.closePath();ctx.fillStyle=col;ctx.fill();ctx.strokeStyle='rgba(50,70,56,.5)';ctx.lineWidth=1*u;ctx.stroke()};
    BST('#b98a42',1,x+5*u*k,yy+1.4*u*k,x+10*u*k,yy+2.6*u*k+f*u,x+15*u*k,yy+3.4*u*k+f*1.6*u);BST('#b98a42',1,x+5*u*k,yy+.6*u*k,x+10*u*k,yy+1.2*u*k+f*u,x+14*u*k,yy+1.6*u*k+f*1.6*u);
    wing('#cdd8c8',-2);
    ctx.fillStyle='#f6f8f0';ctx.beginPath();ctx.ellipse(x,yy,6.4*u*k,2.5*u*k,-.06,0,7);ctx.fill();ctx.strokeStyle='rgba(50,70,56,.5)';ctx.lineWidth=1*u;ctx.stroke();
    BST('#f6f8f0',2,x-5*u*k,yy-.6*u*k,x-8*u*k,yy-4*u*k,x-9.4*u*k,yy-1.6*u*k);ctx.fillStyle='#f6f8f0';ctx.beginPath();ctx.arc(x-9.6*u*k,yy-1.2*u*k,1.9*u*k,0,7);ctx.fill();ctx.stroke();
    BPG('#ffb83a',x-11*u*k,yy-1.8*u*k,x-15.6*u*k,yy-.8*u*k,x-11*u*k,yy-.2*u*k);wdot(x-10*u*k,yy-1.7*u*k,.5*u,'#1a1208');
    wing('#ffffff',0)}
}
function mgCanopy(){
  const g=ctx.createLinearGradient(0,0,0,56*u);g.addColorStop(0,'rgba(8,26,16,.6)');g.addColorStop(1,'rgba(8,26,16,0)');ctx.fillStyle=g;ctx.fillRect(0,0,W,56*u);
  par(78*u,.5,-90*u,W+90*u,(x,i)=>{
    const lx=x+bgH(i,60)*30*u;
    for(let q=0;q<5;q++){const a=.95+q*.3+(bgH(i,61)-.5)*.3+Math.sin(t*1.1+i+q)*.04;mgLf(lx,-8*u,a,(20+bgH(i,62+q)*12)*u,(5+bgH(i,70+q)*2)*u,q%2?'#2f6a3e':'#245434','rgba(180,230,120,.28)')}
    for(let q=0;q<2;q++){const vx=lx+(q?15:-11)*u,vl=(34+bgH(i,80+q)*44)*u,vs=Math.sin(t*1.3+i*2+q)*2.4*u;
      BST('rgba(14,34,18,.9)',1.6,vx,-4*u,vx+vs*.4,vl*.5,vx+vs,vl);BST('#3c7a3a',.9,vx,-4*u,vx+vs*.4,vl*.5,vx+vs,vl);
      mgLf(vx+vs*.35,vl*.45,q?.5:2.6,8*u,2.8*u,'#4f9a46','rgba(220,250,170,.4)');wdot(vx+vs,vl,1.7*u,'#9ccb55')}
  });
}
