/*
 * flight.js - Flight boosters: jetpack (Fly) - per-frame flight control, particles, flames and the jetpack.
 */
import { t } from './clock.js';
import { rr } from './draw-utils.js';
import { ter } from './physics.js';
import { state } from './state.js';
import { ctx, G, px, u, W } from './view.js';

export function stepFlight(dt){
  const fl=state.fx.fly>0;
  if(fl){if(state.fty!==1){state.fty=1;state.fap=0;fpBurst('110,231,255',0)}state.fap=Math.min(1,state.fap+dt*3.2);flyEmit(dt)}else state.fap=0;
  if(fl){state.wasFly=true;state.vy=0;state.jumps=2;const fa=130*u;state.y+=(fa-state.y)*Math.min(1,dt*6);state.fcd+=state.speed*dt;if(state.fcd>64*u){state.fcd=0;if(!state.adv)state.coins.push({x:W+20,h:fa+17*u})}}else if(state.wasFly){state.wasFly=false;state.jumps=1;state.fx.ghost=Math.max(state.fx.ghost,1.5);state.fty=0;fpBurst('236,240,248',1)}
  return fl;
}
/* ---- Flight boosters: jetpack (Fly) ---- */
export function fpm(o){o.l0=o.l;state.fp.push(o)}
export function fpStep(dt){const sp=state.st==='play'?state.speed:0;for(const p of state.fp){p.l-=dt;p.x+=(p.vx||0)*dt-(p.fo?0:sp*dt);p.y+=(p.vy||0)*dt;if(p.g)p.vy+=p.g*dt;if(p.dr){const k=Math.max(0,1-p.dr*dt);p.vx*=k;p.vy*=k}if(p.gr)p.r+=p.gr*dt;if(p.x+(p.len||0)<-80*u)p.l=0}state.fp=state.fp.filter(p=>p.l>0)}
export function fpDraw(){
  for(const p of state.fp){const k=Math.max(0,p.l/p.l0),c=p.c;
    if(p.k==='ring'){ctx.strokeStyle='rgba('+c+','+(.75*k).toFixed(2)+')';ctx.lineWidth=(1+3.5*k)*u;ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,7);ctx.stroke()}
    else if(p.k==='line'){ctx.strokeStyle='rgba(255,255,255,'+(p.a*Math.min(1,k*4)).toFixed(2)+')';ctx.lineWidth=p.w*u;ctx.lineCap='round';ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(p.x+p.len,p.y);ctx.stroke()}
    else if(p.k==='star'){const r=p.r*Math.min(1,k*2.2)*(.75+.25*Math.sin(t*30+p.ph))*1.5;ctx.fillStyle='rgba('+c+','+Math.min(1,k*1.8).toFixed(2)+')';ctx.beginPath();ctx.moveTo(p.x,p.y-r);ctx.quadraticCurveTo(p.x,p.y,p.x+r,p.y);ctx.quadraticCurveTo(p.x,p.y,p.x,p.y+r);ctx.quadraticCurveTo(p.x,p.y,p.x-r,p.y);ctx.quadraticCurveTo(p.x,p.y,p.x,p.y-r);ctx.fill()}
    else{ctx.fillStyle='rgba('+c+','+((p.a||1)*k).toFixed(2)+')';ctx.beginPath();ctx.arc(p.x,p.y,Math.max(.1,p.r*(p.sh?.4+.6*k:1)),0,7);ctx.fill()}}
}
function fpBurst(c,out){
  const S=34*u,cx=px+S/2,cy=G+ter(cx)-state.y-S*.5,R=Math.random;
  fpm({k:'ring',x:cx,y:cy,r:12*u,gr:(out?200:280)*u,l:out?.35:.5,c,fo:1});
  for(let i=0;i<14;i++){const a=i/14*6.283+R()*.3,v=(110+R()*190)*u;fpm({k:'dot',x:cx,y:cy,vx:Math.cos(a)*v,vy:Math.sin(a)*v,r:(out?4:2.6)*u,gr:out?16*u:0,dr:3.2,l:.45+R()*.35,c:out?'232,236,246':c,a:out?.6:1,ph:R()*6,fo:out?0:1,sh:out?0:1})}
}
function flyEmit(dt){
  const S=34*u,cx=px+S/2,T=G+ter(cx)-state.y-S,R=Math.random;
  state.fpt+=dt;let n=0;
  while(state.fpt>=.03&&n++<3){state.fpt-=.03;
    for(let q=0;q<2;q++){const nx=px-11.5*u+q*7*u,ny=T+S*.78+5*u;
      if(R()<.7)fpm({k:'dot',x:nx+(R()-.5)*4*u,y:ny+6*u,vx:-(20+R()*60)*u,vy:(110+R()*160)*u,g:260*u,r:(1.2+R()*1.3)*u,l:.22+R()*.25,c:['255,201,58','255,122,26','255,246,214'][R()*3|0],a:1,sh:1});
      if(R()<.5)fpm({k:'dot',x:nx,y:ny+14*u,vx:-(10+R()*25)*u,vy:(10+R()*30)*u,g:-35*u,gr:15*u,r:(3+R()*1.6)*u,l:.65+R()*.35,c:'232,236,246',a:.5})}
    if(R()<.55)fpm({k:'line',x:W+30*u,y:T+S/2+(R()-.5)*170*u,vx:-state.speed*.9,vy:0,len:(50+R()*90)*u,w:1+R()*1.1,a:.12+R()*.16,l:1.6,c:'255,255,255'})}
}
export function flyBack(T,S){
  const fa=130*u;
  state.ftl=.09+Math.sin(t*2.6)*.02-Math.max(-.22,Math.min(.22,(fa-state.y)/u*.0016));
}
export function tdrop(x,y,r,L,c){ctx.fillStyle=c;ctx.beginPath();ctx.moveTo(x-r,y);ctx.quadraticCurveTo(x-r*1.05,y+L*.55,x,y+L);ctx.quadraticCurveTo(x+r*1.05,y+L*.55,x+r,y);ctx.closePath();ctx.fill()}
function jetFlame(x,y,q){
  const f=Math.sin(t*52+q*2)*.5+Math.sin(t*33+q*5)*.5,sp=state.fx.fly<1.5?(Math.sin(t*34+q)>-.2?1:.2):1,L=(27+f*6)*u*sp,r=5.8*u*(.75+.25*sp);
  if(L<2*u)return;
  const gl=ctx.createRadialGradient(x,y+L*.45,1,x,y+L*.45,L*1.5);gl.addColorStop(0,'rgba(255,170,60,.5)');gl.addColorStop(1,'rgba(255,170,60,0)');ctx.fillStyle=gl;ctx.beginPath();ctx.arc(x,y+L*.45,L*1.5,0,7);ctx.fill();
  tdrop(x,y,r,L,'#ff7a1a');tdrop(x,y,r*.68,L*.72,'#ffc93a');tdrop(x,y,r*.34,L*.45,'#fff6d6');
}
export function jetBack(T,S){
  const ke=1-Math.pow(1-state.fap,3),x0=px-18*u,y0=T+S*.06,w=13*u,h=S*.72;
  ctx.save();ctx.translate(px,T+S*.45);ctx.scale(ke,ke);ctx.translate(-px,-T-S*.45);ctx.lineJoin='round';
  for(let q=0;q<2;q++){const x=x0+q*7*u;
    jetFlame(x+w/2,y0+h+5*u,q);
    ctx.fillStyle='#3a3f52';ctx.strokeStyle='rgba(0,0,0,.32)';ctx.lineWidth=1.6*u;ctx.beginPath();ctx.moveTo(x+2*u,y0+h-1*u);ctx.lineTo(x+w-2*u,y0+h-1*u);ctx.lineTo(x+w-3.5*u,y0+h+5*u);ctx.lineTo(x+3.5*u,y0+h+5*u);ctx.closePath();ctx.fill();ctx.stroke();
    const g=ctx.createLinearGradient(x,0,x+w,0);if(q){g.addColorStop(0,'#aab5ca');g.addColorStop(.45,'#f4f7fc');g.addColorStop(1,'#8d97ae')}else{g.addColorStop(0,'#7b869e');g.addColorStop(.45,'#c3cbdb');g.addColorStop(1,'#667088')}
    ctx.fillStyle=g;rr(x,y0,w,h,5.5*u);ctx.fill();ctx.stroke();
    ctx.fillStyle=q?'#ff5d73':'#c8374f';rr(x,y0,w,9*u,[6.5*u,6.5*u,1.5*u,1.5*u]);ctx.fill();ctx.stroke();
    ctx.fillStyle='#6ee7ff';ctx.fillRect(x,y0+h*.56,w,3.4*u);
    ctx.fillStyle='rgba(255,255,255,.5)';ctx.fillRect(x+2.2*u,y0+11*u,2*u,h-19*u)}
  ctx.restore();
}
export function jetFront(T,S){
  const ke=1-Math.pow(1-state.fap,3);
  ctx.save();ctx.translate(px,T+S*.45);ctx.scale(ke,ke);ctx.translate(-px,-T-S*.45);
  ctx.fillStyle='#2b2433';ctx.fillRect(px-6*u,T+S*.3,13*u,3.4*u);ctx.fillStyle='#ffd23f';rr(px+3*u,T+S*.3-.6*u,3.4*u,4.6*u,1*u);ctx.fill();
  ctx.restore();
}
