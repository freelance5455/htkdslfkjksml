/*
 * adventure-mode.js - Adventure mode logic: save/load, play clock, checkpoints and the finale.
 */
import { snd } from './audio.js';
import { t } from './clock.js';
import { ADV } from './config.js';
import { $, card, msg, ttl } from './dom.js';
import { fpm } from './flight.js';
import { ter } from './physics.js';
import { state } from './state.js';
import { G, px, u, W } from './view.js';

const advT=s=>Math.floor(s/60)+':'+String(Math.floor(s%60)).padStart(2,'0');
export const advN=['Mountain','Snow Mountain','Mangrove Forest'];
export const ADV_HINT='Tap to jump, tap again in the air to double jump. Your ride takes one hit for you.';
function advSpd(c){const w=ADV.SP;let g=w[w.length-1][1];for(let q=1;q<w.length;q++)if(c<w[q][0]){const a=w[q-1],b=w[q];g=a[1]+(b[1]-a[1])*(c-a[0])/(b[0]-a[0]);break}return g}
export function advLoad(){let ok=false,raw=null;try{raw=localStorage.getItem(ADV.KEY);ok=true}catch(e){}
  if(ok){state.aS=null;try{const s=JSON.parse(raw);if(s&&s.b>=0&&s.b<=2&&s.c>=0&&isFinite(s.c))state.aS={b:s.b|0,c:+s.c,p:isFinite(s.p)?+s.p:+s.c}}catch(e){}}return state.aS}
export function advWrite(){try{if(state.aS)localStorage.setItem(ADV.KEY,JSON.stringify(state.aS));else localStorage.removeItem(ADV.KEY)}catch(e){}}
export function advReset(){state.aFl=[];state.aFin=null;state.aBlk=-1e9}
/* Puts the player at the start of the saved checkpoint: what a normal arrival sets, plus clock, speed, runway and the raised flag. */
export function advStart(){const s=state.aS||(state.aS={b:0,c:0,p:0});state.adv=true;state.bi=s.b;
  if(state.bi>0){state.rd=state.bi===2?0:state.bi+1;state.cs=state.bi===2?1e9:Math.ceil((state.dist+W+1500*u)/(10*u));state.ce=state.cs+420;state.cT=state.bi&1}
  state.bw=state.bi===1?1:0;state.bm=state.bi===2?1:0;state.pt=s.c;state.aTot=s.p;state.speed=advSpd(state.pt)*u;state.nextFly=state.pt+10;state.aBlk=W+20+ADV.RUN*u;
  state.aFl.push({x:px+36*u,b:state.bi,on:1,t0:-9})}
export function advFlag(re){const x=re+ADV.FLAG*u;state.aFl.push({x,b:state.bi,on:0,t0:-9});state.aBlk=Math.max(state.aBlk,x+70*u)}
function advHit(f){f.on=1;f.t0=t;state.aS={b:f.b,c:+state.pt.toFixed(1),p:+state.aTot.toFixed(1)};advWrite();
  const sx=f.x-state.dist,gy=G+ter(sx),R=Math.random;
  fpm({k:'ring',x:sx+14*u,y:gy-64*u,r:8*u,gr:170*u,l:.5,c:'255,150,160'});
  for(let i=0;i<16;i++){const a=i/16*6.283+R()*.4,v=(60+R()*140)*u;fpm({k:'star',x:sx+14*u,y:gy-64*u,vx:Math.cos(a)*v,vy:Math.sin(a)*v-30*u,g:160*u,dr:2.4,r:(2.2+R()*2.4)*u,l:.55+R()*.4,c:i%3?'255,120,140':'255,236,160',ph:R()*6})}
  state.pops.push({x:px+46*u,y:gy-100*u,a:1.9,t:'Checkpoint',c:'#ff8f9d'});snd('cp');setTimeout(()=>snd('cp2'),130)}
export function advStep(dt){if(state.st!=='play')return;state.aTot+=dt;
  for(const f of state.aFl)if(!f.on&&f.x-state.dist<px+34*u)advHit(f);
  state.aFl=state.aFl.filter(f=>f.x-state.dist>-140*u);
  if(!state.aFin&&!state.tr&&state.bi===2&&state.pt>=ADV.T[2]&&!(state.fx.fly>0)&&!state.tpOn&&state.cs*10*u>state.dist+W+900*u){
    state.aFin={gx:state.dist+W+ADV.GATE*u};state.items=[];state.pops.push({x:W/2,y:G*.4,a:2.2,t:'The end is near'})}
  if(state.aFin){const r=state.aFin.gx-(state.dist+px+17*u);state.speed=Math.min(state.speed,Math.max(0,r)*.9+8*u);
    if(r<=2*u){state.st='won';state.speed=0;state.dist=state.aFin.gx-px-17*u;state.hold=false;state.fx.ghost=0;state.overAt=performance.now();
      const gy=G+ter(px+17*u),R=Math.random,cc=['255,210,80','255,143,160','125,255,168','154,215,255'];
      const burst=()=>{for(let i=0;i<26;i++){const a=-1.57+(R()-.5)*2.6,v=(90+R()*230)*u;fpm({k:'star',x:px+17*u,y:gy-90*u,vx:Math.cos(a)*v,vy:Math.sin(a)*v,g:260*u,dr:1.4,r:(2.4+R()*2.6)*u,l:.9+R()*.7,c:cc[i%4],ph:R()*6})}};
      burst();setTimeout(()=>{if(state.st==='won')burst()},420);snd('cp');setTimeout(()=>snd('cp2'),130);
      state.aS=null;advWrite();ttl.textContent='Adventure complete';msg.textContent='Total time played '+advT(state.aTot)+'. Tap to return to the menu.';card.hidden=false;$('home').hidden=false}}}
export function advOver(){snd('d');ttl.textContent='Game over';msg.textContent='Tap to retry from the last checkpoint';card.hidden=false;$('home').hidden=false}
