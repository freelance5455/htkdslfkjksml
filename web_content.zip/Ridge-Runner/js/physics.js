/*
 * physics.js - Terrain height under the runner, ride height, the jump impulse and the runner's per-frame physics (jump buffer, gravity, world scroll, speed ramp).
 */
import { snd } from './audio.js';
import { gm } from './biomes.js';
import { t } from './clock.js';
import { ADV, MODES, SCOL2 } from './config.js';
import { spd } from './dom.js';
import { tpHold, tpIn, tpStep, tpT, tpUp } from './jungle-temple.js';
import { state } from './state.js';
import { u, W } from './view.js';

export function jump(d){state.vy=(d?800:880)*u;state.air=0;state.cut=false;state.buf=0;state.jumps=d?2:1;snd(d?'j2':'j1')}
export function stepJumpBuffer(dt){
  if(state.buf>0){state.buf-=dt;if(state.y===0&&!state.ob)jump(false)}
}
export function stepGravity(dt,fl){
  if(!fl&&(state.y>0||state.vy>0)){
    state.air+=dt;
    if(!state.hold&&!state.cut&&state.vy>0&&state.air>.07){state.vy*=.5;state.cut=true}
    state.vy-=2600*u*dt;state.y+=state.vy*dt;
    if(state.y<=0){state.y=0;state.vy=0;state.jumps=0}
  }
}
export function stepScroll(dt){
  state.dist+=state.speed*dt;if(state.dist>state.ce*10*u+W+300*u){state.cs=state.ce+900;state.ce=state.cs+420;state.cT=state.bi}tpStep();tpUp(dt);
}
export function stepSpeed(dt,fl){
  state.pt+=dt;for(const k of['ghost','magnet','x2','slow','fly'])state.fx[k]=Math.max(0,state.fx[k]-dt);const wp=state.adv?ADV.SP:MODES[state.mode].w;let tg=wp[wp.length-1][1],lb=wp[0][2];for(let q=1;q<wp.length;q++){if(state.pt<wp[q][0]){const a=wp[q-1],b=wp[q];tg=a[1]+(b[1]-a[1])*(state.pt-a[0])/(b[0]-a[0]);lb=a[2];break}lb=wp[q][2]}if(lb!==state.stage){state.stage=lb;spd.textContent=lb;spd.style.color=SCOL2[lb]}state.speed+=((fl?700:tg*(state.fx.slow>0?.6:1))*u-state.speed)*Math.min(1,dt*(fl?3:1.5));tpHold();
}
export function ter(x){const w=x+state.dist;let m=1;if(state.st==='play'||state.st==='drown'||state.st==='over'){const a=(w-state.cs*10*u)/(200*u),b=(state.ce*10*u-w)/(200*u);m=1-.7*Math.max(0,Math.min(1,a))*Math.max(0,Math.min(1,b))}if(state.tr){const a=(w-state.tr.rs+120*u)/(120*u),b=(state.tr.re+120*u-w)/(120*u);m*=1-.95*Math.max(0,Math.min(1,a))*Math.max(0,Math.min(1,b))}return -34*u*m*(1-.73*gm(w))*(1-.97*tpIn(w))*(1+.65*Math.sin(w/(230*u))+.35*Math.sin(w/(100*u)+1.7))+tpT(w)}
export const FL=()=>state.fx.fly>0;
export const rh=()=>FL()?0:state.ob?(state.tr&&state.tr.sea?19*u:6*u)+Math.sin(t*3)*1.6*u:state.rd===1?22*u:state.rd===2?12*u:0;
