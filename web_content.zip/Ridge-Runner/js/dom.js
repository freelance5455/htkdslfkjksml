/*
 * dom.js - DOM handles shared across modules: the canvas and the HUD / card elements.
 */
export const $=id=>document.getElementById(id);
export const cv=$('c');
export const sc=$('score');
export const bs=$('best');
export const spd=$('spd');
export const card=$('card');
export const ttl=$('ttl');
export const msg=$('msg');
