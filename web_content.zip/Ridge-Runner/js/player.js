/*
 * player.js - Draws the runner: shadow, tail, legs, body, face, outfit layers and the ride / flight layers around them.
 */
import { bBack } from './boosters.js';
import { t } from './clock.js';
import { rr } from './draw-utils.js';
import { flyBack, fpDraw, jetBack, jetFront } from './flight.js';
import { WK } from './outfit-parts.js';
import { acc, wa, wb, wk } from './outfits.js';
import { FL, rh, ter } from './physics.js';
import { tpIdle } from './jungle-temple.js';
import { rdr } from './rides.js';
import { state } from './state.js';
import { ctx, G, px, u } from './view.js';

export /** Draws the runner and the layers around it; returns the body position for the front effects. */
function drawRunner(){
  const s=34*u,bob=(state.y===0&&state.st==='play'&&!rh()&&!tpIdle())?Math.abs(Math.sin(t*16))*2*u:0,top=G+ter(px+s/2)-state.y-s-bob-rh()+(state.dw?state.dw.sk:0)-(FL()?Math.sin(t*4.2)*3*u*state.fap:0),sy=top+11*u;if(state.fx.ghost>0)ctx.globalAlpha=.5+.15*Math.sin(t*12);
  {const sgx=px+s/2,sgy=G+ter(sgx)+2*u;ctx.fillStyle='rgba(0,0,0,.25)';ctx.beginPath();ctx.ellipse(sgx,sgy,s*(rh()?.85:.5)*(1-Math.min(state.y/(240*u),.6)),4*u,0,0,7);ctx.fill()}
  bBack(top,s);const FY=FL();fpDraw();if(FY){flyBack(top,s);ctx.save();ctx.translate(px+s/2,top+s*.5);ctx.rotate(state.ftl);ctx.translate(-px-s/2,-top-s*.5)}
  rdr(0);ctx.strokeStyle=state.O.t;ctx.lineWidth=5*u;ctx.lineCap='round';
  const dr=state.vy*.02,tf=FY?26:14,ta=FY?1.5:1;
  if(!WK[state.O.k]){ctx.beginPath();ctx.moveTo(px+4*u,sy);
  ctx.quadraticCurveTo(px-14*u,sy+Math.sin(t*tf)*5*u*ta+dr,px-32*u,sy+Math.sin(t*tf+1)*6*u*ta+dr*1.6);ctx.stroke()}wk(top,s);if(FY)jetBack(top,s);
  {const run=state.y===0&&state.st==='play'&&!rh()&&!tpIdle()?Math.sin(t*16):0,ia=state.y>0||rh()>0;for(let q=0;q<2;q++){const sg2=q?-1:1,lift=ia?(5+(FY?Math.sin(t*7+q*3)*2.5:0))*u:Math.max(0,run*sg2)*4*u,lx=px+s*(.3+q*.36)+(ia?(q?-4:5)*u:run*sg2*6*u);ctx.fillStyle=state.O.b;rr(lx-3.5*u,top+s*.7,7*u,s*.3-lift,3*u);ctx.fill();ctx.fillStyle='rgba(0,0,0,.3)';ctx.fill();ctx.fillStyle=state.O.s||'#2b2433';ctx.beginPath();ctx.ellipse(lx+2*u,top+s-2*u-lift*.5,6*u,3*u,0,0,7);ctx.fill()}}
  ctx.fillStyle=state.O.b;rr(px,top,s,s*.8,10*u);ctx.fill();const bg=ctx.createLinearGradient(px,top,px+s,top+s*.8);bg.addColorStop(0,'rgba(255,255,255,.3)');bg.addColorStop(.55,'rgba(255,255,255,0)');bg.addColorStop(1,'rgba(0,0,0,.25)');ctx.fillStyle=bg;ctx.fill();ctx.strokeStyle='rgba(0,0,0,.32)';ctx.lineWidth=2*u;ctx.stroke();wb(top,s);
  {const sw=state.y===0&&state.st==='play'&&!rh()&&!tpIdle()?Math.sin(t*16+Math.PI):-.6;ctx.save();ctx.translate(px+s*.42,top+s*.46);ctx.rotate(sw*.9);ctx.fillStyle=state.O.b;rr(-3*u,0,6*u,13*u,3*u);ctx.fill();ctx.fillStyle='rgba(0,0,0,.22)';ctx.fill();ctx.fillStyle=state.O.h||'#f3d5b5';ctx.beginPath();ctx.arc(0,14*u,3.2*u,0,7);ctx.fill();ctx.restore()}
  ctx.fillStyle='rgba(255,120,140,.28)';ctx.beginPath();ctx.arc(px+s*.52,top+s*.54,3.6*u,0,7);ctx.fill();ctx.strokeStyle='rgba(0,0,0,.5)';ctx.lineWidth=1.6*u;ctx.beginPath();ctx.arc(px+s*.74,top+s*.5,3.4*u,.15*Math.PI,.85*Math.PI);ctx.stroke();ctx.fillStyle='#fff';ctx.beginPath();ctx.ellipse(px+s*.68,top+s*.38,5.2*u,6*u,0,0,7);ctx.fill();
  ctx.fillStyle=state.O.e;ctx.beginPath();ctx.arc(px+s*.68,top+s*.38,3.5*u,0,7);ctx.fill();acc(top,s);wa(top,s);if(FY){jetFront(top,s);ctx.restore()}rdr(1);
  return{top,s};
}
