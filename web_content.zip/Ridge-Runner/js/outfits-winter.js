/*
 * outfits-winter.js - Winter outfits: Santa, Snowman, Reindeer, Penguin, Polar Bear, Elf, Gingerbread, Yeti, Arctic Fox.
 */
import { t } from './clock.js';
import { rr, wdot, wlg, wol } from './draw-utils.js';
import { furFlicks, furTufts } from './hand-drawn.js';
import { wband, wfur, WK, wrib, wtl, wtri } from './outfit-parts.js';
import { state } from './state.js';
import { ctx, px, u } from './view.js';

function wfx(T,S){
  const x=px,c=(state.O.k==='santa'||state.O.k==='ginger'||state.O.k==='elf')?'255,236,160':'232,246,255';
  for(let q=0;q<4;q++){
    const ph=(t*.8+q*.25)%1,sx=x+S*.15-ph*S*1.15,sy=T+S*(.15+q*.2)+Math.sin(t*4+q*2)*3*u+ph*9*u,r=(1.2+(q%2))*u*(1-ph*.4)*1.7;
    ctx.fillStyle='rgba('+c+','+(.85*(1-ph)).toFixed(2)+')';ctx.beginPath();ctx.moveTo(sx,sy-r);ctx.quadraticCurveTo(sx,sy,sx+r,sy);ctx.quadraticCurveTo(sx,sy,sx,sy+r);ctx.quadraticCurveTo(sx,sy,sx-r,sy);ctx.quadraticCurveTo(sx,sy,sx,sy-r);ctx.fill();
  }
}
function what(T,S,o){
  const x=px,sw=Math.sin(t*7)*1.8*u,tl=wtl(),b0=x-.03*S,b1=x+.92*S,by=T+3.4*u,tx=x+o.tx*S+sw,ty=T+o.ty*S+sw*.6+tl;
  const g=ctx.createLinearGradient(x,0,x+S,0);g.addColorStop(0,o.c1);g.addColorStop(1,o.c2);
  ctx.fillStyle=g;ctx.beginPath();ctx.moveTo(b0,by);ctx.quadraticCurveTo(x+o.k1x*S,T+o.k1y*S+tl*.4,tx,ty);ctx.quadraticCurveTo(x+o.k2x*S,T+o.k2y*S+tl*.4,b1,by);ctx.closePath();ctx.fill();wol(1.5);
  if(o.fluffy)wfur(b0-1*u,b1+1*u,by-1*u,3.6*u,o.trim,'#c3cee4');
  else{ctx.fillStyle=o.trim;rr(b0-2*u,by-4.6*u,b1-b0+4*u,6.4*u,3*u);ctx.fill();wol(1.4)}
  if(o.pom){wdot(tx,ty+.6*u,4.6*u,'#c3cee4');wdot(tx,ty-.2*u,4.2*u,'#fff');wdot(tx-1.4*u,ty-1.6*u,1.4*u,'rgba(255,255,255,.9)')}
  if(o.bell){wdot(tx,ty+1*u,3.6*u,'#e0a400');wdot(tx-.4*u,ty+.6*u,3.2*u,'#ffd23f');wdot(tx-1.2*u,ty-.4*u,1.1*u,'#fff4c0');ctx.strokeStyle='rgba(120,70,0,.7)';ctx.lineWidth=1*u;ctx.beginPath();ctx.moveTo(tx-2.6*u,ty+2.4*u);ctx.lineTo(tx+2.4*u,ty+2.4*u);ctx.stroke()}
}
function wtop(T,S){
  const x=px;
  ctx.save();ctx.translate(x+S*.46,T+2*u);ctx.rotate(-.1+Math.sin(t*5)*.015);
  ctx.fillStyle='#22222f';rr(-S*.27,-15*u,S*.54,16*u,2.5*u);ctx.fill();wol(1.4);
  ctx.fillStyle='rgba(255,255,255,.14)';ctx.fillRect(-S*.2,-13*u,2.2*u,11*u);
  ctx.fillStyle='#e53950';ctx.fillRect(-S*.27,-6*u,S*.54,4.4*u);
  ctx.fillStyle='#3bb273';ctx.beginPath();ctx.ellipse(S*.1,-3.8*u,3*u,1.4*u,-.5,0,7);ctx.fill();ctx.beginPath();ctx.ellipse(S*.19,-3.6*u,3*u,1.4*u,.5,0,7);ctx.fill();
  wdot(S*.145,-3.1*u,1.3*u,'#ff3b4f');
  ctx.fillStyle='#22222f';ctx.beginPath();ctx.ellipse(0,1.4*u,S*.5,3.3*u,0,0,7);ctx.fill();wol(1.4);
  ctx.fillStyle='rgba(255,255,255,.12)';ctx.beginPath();ctx.ellipse(-S*.1,.4*u,S*.3,1*u,0,0,7);ctx.fill();
  ctx.restore();
}
function wbeanie(T,S){
  const x=px,cx=x+S*.46,sw=Math.sin(t*7)*1.3*u,tl=wtl()*.5;
  ctx.save();ctx.beginPath();ctx.ellipse(cx,T+4*u,S*.5,12*u,0,Math.PI,0);ctx.closePath();ctx.fillStyle='#e5384f';ctx.fill();ctx.clip();
  ctx.fillStyle='#fdf6e9';ctx.fillRect(cx-S,T-5*u,S*2,2.6*u);
  ctx.strokeStyle='rgba(0,0,0,.14)';ctx.lineWidth=1*u;ctx.beginPath();for(let q=-4;q<=4;q++){ctx.moveTo(cx+q*4*u,T-9*u);ctx.lineTo(cx+q*4.6*u,T+5*u)}ctx.stroke();
  ctx.restore();
  ctx.beginPath();ctx.ellipse(cx,T+4*u,S*.5,12*u,0,Math.PI,0);wol(1.5);
  ctx.fillStyle='#fdf6e9';rr(cx-S*.54,T-.5*u,S*1.08,6.4*u,3*u);ctx.fill();wol(1.4);
  ctx.strokeStyle='rgba(0,0,0,.12)';ctx.lineWidth=1*u;ctx.beginPath();for(let q=-4;q<=4;q++){ctx.moveTo(cx+q*4*u,T+.5*u);ctx.lineTo(cx+q*4*u,T+5*u)}ctx.stroke();
  wdot(cx+sw*.5,T-8.6*u+tl,4.6*u,'#c3cee4');wdot(cx+sw*.5,T-9.2*u+tl,4.2*u,'#fff');wdot(cx+sw*.5-1.3*u,T-10.4*u+tl,1.3*u,'rgba(255,255,255,.9)');
}
/* behind the body: ears, antlers, tails, sack */
export function winterBack(T,S){
  const k=state.O.k;if(!WK[k])return;
  const x=px,sw=Math.sin(t*8)*1.4*u,d=wtl();
  ctx.save();ctx.lineJoin='round';ctx.lineCap='round';
  if(k==='santa'){
    const bo=(state.y===0&&state.st==='play')?Math.sin(t*16)*1.2*u:d*.5,sx=x-5*u,sy2=T+S*.46+bo;
    ctx.save();ctx.translate(sx-1*u,sy2-10*u);ctx.rotate(-.3+Math.sin(t*7)*.08);ctx.fillStyle='#2e9d5a';rr(-4.5*u,-4.5*u,9*u,9*u,1.2*u);ctx.fill();wol(1.2);ctx.fillStyle='#ffd23f';ctx.fillRect(-.9*u,-4.5*u,1.8*u,9*u);ctx.fillRect(-4.5*u,-.9*u,9*u,1.8*u);ctx.restore();
    ctx.fillStyle='#b98a55';ctx.beginPath();ctx.ellipse(sx,sy2+3*u,11*u,12*u,-.15,0,7);ctx.fill();wol(1.5);
    ctx.fillStyle='rgba(80,45,10,.28)';ctx.beginPath();ctx.ellipse(sx+3*u,sy2+5*u,8*u,10*u,-.15,-1.2,1.9);ctx.fill();
    ctx.strokeStyle='rgba(80,45,10,.35)';ctx.lineWidth=1.2*u;ctx.beginPath();ctx.moveTo(sx-4*u,sy2+1*u);ctx.quadraticCurveTo(sx-2*u,sy2+6*u,sx-5*u,sy2+10*u);ctx.stroke();
    ctx.fillStyle='#d62839';ctx.beginPath();ctx.ellipse(sx,sy2-6*u,7.2*u,2.6*u,0,0,7);ctx.fill();wol(1.2);
    wdot(sx+5*u,sy2-4*u,2*u,'#ffd23f');
  }else if(k==='snowman'){
    const w=Math.sin(t*6)*2*u;
    ctx.strokeStyle='#5a3f2b';ctx.lineWidth=2.6*u;ctx.beginPath();ctx.moveTo(x+4*u,T+S*.5);ctx.quadraticCurveTo(x-8*u,T+S*.38+w*.5+d*.3,x-17*u,T+S*.16+w+d*.5);ctx.stroke();
    ctx.lineWidth=1.8*u;ctx.beginPath();ctx.moveTo(x-7*u,T+S*.35+w*.5+d*.3);ctx.lineTo(x-13*u,T+S*.2+w*.6+d*.3);ctx.moveTo(x-17*u,T+S*.16+w+d*.5);ctx.lineTo(x-21*u,T+S*.04+w+d*.5);ctx.moveTo(x-17*u,T+S*.16+w+d*.5);ctx.lineTo(x-23*u,T+S*.2+w+d*.5);ctx.stroke();
  }else if(k==='reindeer'){
    const ant=(bx,by,sc,c1,c2)=>{
      const P=()=>{ctx.beginPath();ctx.moveTo(bx,by);ctx.quadraticCurveTo(bx-4*u*sc,by-11*u*sc,bx+1*u*sc+sw,by-19*u*sc+d);ctx.moveTo(bx-1.5*u*sc,by-8*u*sc);ctx.lineTo(bx-8*u*sc,by-13*u*sc+d*.5);ctx.moveTo(bx-.5*u*sc,by-14*u*sc);ctx.lineTo(bx+7*u*sc+sw,by-17*u*sc+d);ctx.moveTo(bx+1*u*sc+sw,by-19*u*sc+d);ctx.lineTo(bx-3*u*sc+sw,by-25*u*sc+d)};
      P();ctx.strokeStyle=c1;ctx.lineWidth=4.2*u*sc;ctx.stroke();P();ctx.strokeStyle=c2;ctx.lineWidth=2*u*sc;ctx.stroke();
    };
    ant(x+S*.3,T+3*u,.85,'#3e2813','#8c6238');
    ant(x+S*.58,T+3*u,1,'#5b3a1e','#c49a62');
    ctx.fillStyle='#a86a3a';ctx.beginPath();ctx.ellipse(x+3*u,T+7*u,8*u,3.4*u,.75,0,7);ctx.fill();wol(1.3);
    ctx.fillStyle='#e8a59a';ctx.beginPath();ctx.ellipse(x+3*u,T+7*u,5.4*u,1.8*u,.75,0,7);ctx.fill();
    ctx.save();ctx.translate(x-1*u,T+S*.58);ctx.rotate(Math.sin(t*10)*.25+d*.02);ctx.fillStyle='#f3e6c8';ctx.beginPath();ctx.ellipse(-2*u,0,4.6*u,3*u,0,0,7);ctx.fill();wol(1.2);ctx.restore();
  }else if(k==='polar'){
    for(const[ex,ey]of[[.1,.02],[.6,-.02]]){wdot(x+S*ex+1*u,T+S*ey+1*u,5.6*u,'#f4f8fd');wol(1.4);wdot(x+S*ex+1*u,T+S*ey+1.6*u,2.9*u,'#f3b7c4')}
    wdot(x-1*u,T+S*.66,4.2*u,'#fff');wol(1.3);
  }else if(k==='elf'){
    ctx.fillStyle='#f6cfb0';wtri(x+4*u,T+S*.26,x-11*u+sw,T+S*.06+sw*.5+d*.4,x+4*u,T+S*.46);ctx.fill();wol(1.4);
    ctx.fillStyle='#f0a79a';wtri(x+4*u,T+S*.3,x-6*u+sw,T+S*.12+d*.3,x+4*u,T+S*.42);ctx.fill();
  }else if(k==='ginger'){
    const P=()=>{ctx.beginPath();ctx.moveTo(x+3*u,T+S*.7);ctx.lineTo(x-6*u+sw*.5,T+S*.08+d*.5);ctx.quadraticCurveTo(x-8*u+sw*.5,T-8*u+d*.5,x-1*u+sw*.5,T-8*u+d*.5)};
    P();ctx.strokeStyle='rgba(0,0,0,.3)';ctx.lineWidth=6.4*u;ctx.stroke();
    P();ctx.strokeStyle='#fff';ctx.lineWidth=4.6*u;ctx.stroke();
    P();ctx.strokeStyle='#e53950';ctx.lineWidth=4.6*u;ctx.setLineDash([3*u,3.6*u]);ctx.lineCap='butt';ctx.stroke();ctx.setLineDash([]);
  }else if(k==='yeti'){
    const spk=(a,b,c,e,f,g,col)=>{ctx.fillStyle=col;wtri(a,b,c,e,f,g);ctx.fill();ctx.beginPath();ctx.moveTo(a,b);ctx.lineTo(c,e);ctx.lineTo(f,g);wol(1.3)};
    [[.08,8],[.3,11],[.52,9],[.74,10]].forEach(([a,h],i)=>{const bx=x+S*a;spk(bx-4.4*u,T+4*u,bx+Math.sin(t*5+i)*1.2*u,T-h*u+d*.3,bx+4.4*u,T+4*u,i%2?'#c7d9ee':state.O.b)});
    [.22,.44].forEach((a,i)=>{const by=T+S*a;spk(x+3*u,by-4.4*u,x-6*u,by+Math.sin(t*5+i)*1*u,x+3*u,by+4.4*u,i%2?state.O.b:'#c7d9ee')});
    for(let q=0;q<3;q++){const by=T+S*(.5+q*.1);spk(x+3*u,by-3.6*u,x-13*u+sw+(q%2)*3*u,by+(q-1)*2*u+d*.5,x+3*u,by+3.6*u,state.O.t)}
  }else if(k==='fox'){
    const wv=Math.sin(t*6)*2.4*u+d*.6,wv2=Math.sin(t*6+1)*2.4*u+d;
    const P=()=>{ctx.beginPath();ctx.moveTo(x+4*u,T+S*.36);ctx.bezierCurveTo(x-8*u,T-S*.2+wv,x-30*u,T-S*.05+wv,x-32*u,T+S*.42+wv2);ctx.bezierCurveTo(x-28*u,T+S*.78+wv2,x-12*u,T+S*.82,x+4*u,T+S*.7);ctx.closePath()};
    const g=ctx.createLinearGradient(x-32*u,0,x+4*u,0);g.addColorStop(0,'#cfe6f7');g.addColorStop(.5,'#eef3f8');g.addColorStop(1,'#f6f9fc');
    P();ctx.fillStyle=g;ctx.fill();
    ctx.save();P();ctx.clip();ctx.fillStyle=state.O.t;ctx.beginPath();ctx.ellipse(x-35*u,T+S*.34+wv2,11*u,17*u,0,0,7);ctx.fill();furFlicks(x-34*u,T-S*.2,40*u,S*1.0,20,5*u,'rgba(110,150,195,.4)',1,2);ctx.restore();
    P();wol(1.5);
    ctx.fillStyle='#eef3f8';wtri(x+S*.08,T+3*u,x+S*.3,T+3*u,x+S*.12+sw*.3,T-12*u);ctx.fill();wol(1.4);
    ctx.fillStyle='#e8b4c4';wtri(x+S*.14,T+2*u,x+S*.25,T+2*u,x+S*.14+sw*.3,T-7*u);ctx.fill();
    ctx.fillStyle='#eef3f8';wtri(x+S*.48,T+2*u,x+S*.72,T+2*u,x+S*.66+sw*.3,T-13*u);ctx.fill();wol(1.4);
    ctx.fillStyle='#e8b4c4';wtri(x+S*.54,T+1*u,x+S*.66,T+1*u,x+S*.65+sw*.3,T-8*u);ctx.fill();
  }
  ctx.restore();
}
/* on the body, under the face and arm: belts, bellies, scarf bands, icing */
export function winterBody(T,S){
  const k=state.O.k;if(!WK[k])return;
  const x=px,B=T+S*.8;
  ctx.save();rr(x,T,S,S*.8,10*u);ctx.clip();ctx.lineJoin='round';ctx.lineCap='round';
  if(k==='santa'){
    ctx.fillStyle='#17131c';ctx.fillRect(x-2*u,T+S*.5,S+4*u,4.2*u);
    ctx.fillStyle='#ffd23f';rr(x+S*.27,T+S*.5-.8*u,6*u,5.8*u,1.2*u);ctx.fill();
    ctx.fillStyle='#17131c';rr(x+S*.27+1.8*u,T+S*.5+.8*u,2.4*u,2.6*u,.6*u);ctx.fill();
    ctx.fillStyle='rgba(255,255,255,.18)';ctx.fillRect(x-2*u,T+S*.5,S+4*u,1*u);
    wfur(x-3*u,x+S+3*u,B-1*u,3.6*u,'#fff','#c3cee4');
  }else if(k==='snowman'){
    ctx.fillStyle=wlg(T,B,'rgba(255,255,255,0)','rgba(120,160,215,.38)');ctx.fillRect(x,T,S,S*.8);
    wband('#e53950','#ffffff',T+S*.66,4.8*u);
    wdot(x+S*.2,T+S*.3,1.8*u,'#10152e');wdot(x+S*.2,T+S*.46,1.8*u,'#10152e');
  }else if(k==='reindeer'){
    ctx.fillStyle=wlg(T,B,'rgba(255,255,255,.06)','rgba(50,20,0,.3)');ctx.fillRect(x,T,S,S*.8);
    ctx.fillStyle='#efd8b2';ctx.beginPath();ctx.ellipse(x+S*.62,B+2*u,S*.36,S*.27,0,0,7);ctx.fill();
    ctx.fillStyle='rgba(255,238,205,.55)';for(const[a,b,r]of[[.14,.24,2],[.3,.13,1.6],[.2,.45,1.7],[.34,.4,1.3]]){ctx.beginPath();ctx.arc(x+S*a,T+S*b,r*u,0,7);ctx.fill()}
    ctx.fillStyle='#c4283e';ctx.fillRect(x-2*u,T+S*.56,S+4*u,3.8*u);
    ctx.fillStyle='#ffd23f';for(let q=0;q<8;q++)ctx.fillRect(x+q*4.8*u,T+S*.56+1.5*u,2.4*u,.9*u);
  }else if(k==='penguin'){
    ctx.fillStyle='#f4f8fd';ctx.beginPath();ctx.ellipse(x+S*.68,T+S*.4,S*.32,S*.28,0,0,7);ctx.fill();
    ctx.fillStyle=wlg(T+S*.45,B,'#f7fbff','#d3e0f0');ctx.beginPath();ctx.ellipse(x+S*.6,B-S*.05,S*.46,S*.3,0,0,7);ctx.fill();
    wband('#7dd3fc','#ffffff',T+S*.6,5.2*u);
  }else if(k==='polar'){
    ctx.fillStyle=wlg(T,B,'rgba(255,255,255,0)','rgba(110,160,215,.35)');ctx.fillRect(x,T,S,S*.8);
    wband('#4aa8e0','#ffffff',T+S*.62,5.4*u);furFlicks(x,T,S,S*.62,20,3.6*u,'rgba(110,150,205,.3)',.9,6);
  }else if(k==='elf'){
    ctx.fillStyle=wlg(T,B,'rgba(255,255,255,.1)','rgba(0,40,20,.32)');ctx.fillRect(x,T,S,S*.8);
    ctx.fillStyle='#d62839';for(let q=-1;q<7;q++){wtri(x+q*6.2*u,B+1*u,x+q*6.2*u+3.1*u,B-6*u,x+q*6.2*u+6.2*u,B+1*u);ctx.fill()}
    ctx.fillStyle='#5a3a20';ctx.fillRect(x-2*u,T+S*.5,S+4*u,4*u);
    ctx.fillStyle='#ffd23f';rr(x+S*.28,T+S*.5-.8*u,5.6*u,5.6*u,1*u);ctx.fill();
    ctx.fillStyle='#5a3a20';rr(x+S*.28+1.6*u,T+S*.5+.8*u,2.4*u,2.4*u,.5*u);ctx.fill();
  }else if(k==='ginger'){
    ctx.fillStyle=wlg(T,B,'rgba(255,230,170,.18)','rgba(90,40,0,.3)');ctx.fillRect(x,T,S,S*.8);
    ctx.strokeStyle='rgba(255,246,232,.85)';ctx.lineWidth=1.5*u;ctx.setLineDash([.1*u,3.4*u]);rr(x+2.4*u,T+2.4*u,S-4.8*u,S*.8-4.8*u,7.6*u);ctx.stroke();ctx.setLineDash([]);
    for(let p=0;p<2;p++){
      ctx.fillStyle=p?'#fffaf0':'rgba(110,50,10,.35)';const o2=p?0:1.4*u;
      ctx.fillRect(x-2*u,T-2*u,S+4*u,5.4*u+o2);
      for(let q=0;q<7;q++){const dx=x+S*(.06+q*.145),ln=(1.5+((q*5)%4)*1.5)*u;ctx.fillRect(dx-2.1*u,T+3*u,4.2*u,ln+o2);ctx.beginPath();ctx.arc(dx,T+3*u+ln+o2,2.1*u,0,7);ctx.fill()}
    }
    [['#e53950',.3],['#3bb273',.5],['#4aa8e0',.68]].forEach(([c,yy])=>{wdot(x+S*.2,T+S*yy,2.5*u,c);wdot(x+S*.2-.8*u,T+S*yy-.8*u,.9*u,'rgba(255,255,255,.8)')});
  }else if(k==='yeti'){
    ctx.fillStyle=wlg(T,B,'rgba(255,255,255,0)','rgba(90,130,190,.28)');ctx.fillRect(x,T,S,S*.8);
    ctx.fillStyle='#f3f8ff';ctx.beginPath();ctx.ellipse(x+S*.7,T+S*.42,S*.27,S*.26,0,0,7);ctx.fill();
    ctx.strokeStyle='rgba(90,125,175,.45)';ctx.lineWidth=1.3*u;ctx.beginPath();
    for(const[a,b]of[[.1,.3],[.22,.5],[.1,.64],[.34,.7]]){const cx=x+S*a,cy=T+S*b;ctx.moveTo(cx-2*u,cy-2*u);ctx.lineTo(cx,cy+1*u);ctx.lineTo(cx+2*u,cy-2*u)}
    ctx.stroke();
  }else if(k==='fox'){
    ctx.fillStyle=wlg(T,B,'rgba(255,255,255,0)','rgba(120,170,215,.3)');ctx.fillRect(x,T,S,S*.8);furFlicks(x,T,S,S*.8,16,3.4*u,'rgba(110,150,195,.28)',.9,7);
  }
  ctx.restore();
  rr(x,T,S,S*.8,10*u);wol(2);
}
/* in front of the body and face: hats, beards, beaks, snouts, scarf tails */
export function winterFront(T,S){
  const k=state.O.k;if(!WK[k])return;
  const x=px;
  ctx.save();ctx.lineJoin='round';ctx.lineCap='round';
  if(k==='santa'){
    for(let p=0;p<2;p++)for(const[a,b,r]of[[.5,.74,.14],[.66,.79,.15],[.83,.74,.15],[.96,.62,.12],[.58,.64,.1]]){ctx.fillStyle=p?'#fff':'#c3cee4';ctx.beginPath();ctx.arc(x+S*a,T+S*b+(p?0:1.3*u),S*r,0,7);ctx.fill()}
    wdot(x+S*.92,T+S*.5,2.4*u,'#ffb3b3');
    for(let q=0;q<2;q++){ctx.save();ctx.translate(x+S*(.77+q*.18),T+S*.61);ctx.rotate(q?.3:-.3);ctx.fillStyle='#fff';ctx.beginPath();ctx.ellipse(0,0,5.4*u,3.2*u,0,0,7);ctx.fill();ctx.strokeStyle='rgba(120,140,180,.5)';ctx.lineWidth=1*u;ctx.stroke();ctx.restore()}
    what(T,S,{c1:'#f0485c',c2:'#b01a30',trim:'#fff',fluffy:1,pom:1,tx:-.3,ty:-.03,k1x:.05,k1y:-.62,k2x:.78,k2y:-.42});
  }else if(k==='snowman'){
    wrib('#e53950','#ffffff',T+S*.66,26*u,4.8*u);
    ctx.fillStyle=state.O.b;ctx.beginPath();ctx.ellipse(x+S*.74,T+S*.578,4.4*u,1.9*u,0,0,7);ctx.fill();
    for(let q=0;q<5;q++){const an=Math.PI*(.2+q*.15);wdot(x+S*.64+Math.cos(an)*6.5*u,T+S*.44+Math.sin(an)*6.5*u,1.25*u,'#10152e')}
    const nx=x+S*.86,ny=T+S*.47;
    ctx.fillStyle='#ff8f3a';wtri(nx,ny-3.2*u,nx+15*u,ny+2.4*u+Math.sin(t*3)*.4*u,nx,ny+3.6*u);ctx.fill();wol(1.3);
    ctx.strokeStyle='#d9661a';ctx.lineWidth=1.1*u;ctx.beginPath();ctx.moveTo(nx+4*u,ny-.3*u);ctx.lineTo(nx+4*u,ny+1.8*u);ctx.moveTo(nx+8*u,ny+.3*u);ctx.lineTo(nx+8*u,ny+2.2*u);ctx.stroke();
    wtop(T,S);
  }else if(k==='reindeer'){
    ctx.fillStyle='#e2b77f';ctx.beginPath();ctx.ellipse(x+S*.97,T+S*.54,6.2*u,4.8*u,0,0,7);ctx.fill();wol(1.3);
    const nx=x+S+3*u,ny=T+S*.5,pl=.6+.4*Math.sin(t*4),rg=ctx.createRadialGradient(nx,ny,1*u,nx,ny,14*u);
    rg.addColorStop(0,'rgba(255,70,70,'+(.55*pl).toFixed(2)+')');rg.addColorStop(1,'rgba(255,70,70,0)');
    ctx.fillStyle=rg;ctx.beginPath();ctx.arc(nx,ny,14*u,0,7);ctx.fill();
    wdot(nx,ny,3.8*u,'#ff2f3f');wol(1.2);wdot(nx-1.1*u,ny-1.2*u,1.2*u,'rgba(255,255,255,.85)');
    ctx.save();ctx.translate(x+S*.6,T+S*.56+3.2*u);ctx.rotate(Math.sin(t*14)*.25*(state.y>0?.4:1));
    wdot(0,2.6*u,3.6*u,'#d99a00');wdot(-.3*u,2.3*u,3.2*u,'#ffd23f');wdot(-1.2*u,1.2*u,1.1*u,'#fff4c0');
    ctx.strokeStyle='rgba(120,70,0,.7)';ctx.lineWidth=1*u;ctx.beginPath();ctx.moveTo(-2.6*u,3.6*u);ctx.lineTo(2.4*u,3.6*u);ctx.stroke();ctx.restore();
  }else if(k==='penguin'){
    wrib('#7dd3fc','#ffffff',T+S*.6,24*u,5*u);
    ctx.fillStyle='#ff9f43';wtri(x+S*.84,T+S*.43,x+S+9*u,T+S*.52,x+S*.84,T+S*.61);ctx.fill();wol(1.3);
    ctx.fillStyle='#ffc27a';wtri(x+S*.84,T+S*.43,x+S+9*u,T+S*.52,x+S*.84,T+S*.52);ctx.fill();
    ctx.strokeStyle='rgba(120,50,0,.55)';ctx.lineWidth=1*u;ctx.beginPath();ctx.moveTo(x+S*.84,T+S*.52);ctx.lineTo(x+S+8*u,T+S*.52);ctx.stroke();
    wbeanie(T,S);
  }else if(k==='polar'){
    wrib('#4aa8e0','#ffffff',T+S*.62,26*u,5.4*u);furTufts(x+S*.3,T+1.5*u,x+S*.64,T+1.5*u,0,-1,3,5*u,2.6*u,'#f4f8fd');
    ctx.fillStyle='#e8f0fa';ctx.beginPath();ctx.ellipse(x+S*.96,T+S*.55,6.5*u,5*u,0,0,7);ctx.fill();wol(1.3);
    ctx.fillStyle='#10152e';ctx.beginPath();ctx.ellipse(x+S+3.4*u,T+S*.48,3.2*u,2.4*u,0,0,7);ctx.fill();
    wdot(x+S+2.6*u,T+S*.48-1*u,.9*u,'rgba(255,255,255,.8)');
  }else if(k==='elf'){
    what(T,S,{c1:'#34b56e',c2:'#1d7f49',trim:'#d62839',fluffy:0,pom:0,bell:1,tx:-.2,ty:-.56,k1x:-.1,k1y:-.24,k2x:.34,k2y:-.45});
  }else if(k==='ginger'){
    const bx=x+S*.7,by=T+S*.7;
    ctx.fillStyle='#e53950';wtri(bx,by,bx-7*u,by-4*u,bx-7*u,by+4*u);ctx.fill();wol(1.2);wtri(bx,by,bx+7*u,by-4*u,bx+7*u,by+4*u);ctx.fill();wol(1.2);
    wdot(bx,by,2*u,'#b32f48');wol(1);
  }else if(k==='yeti'){
    ctx.strokeStyle='#33496b';ctx.lineWidth=3.2*u;ctx.beginPath();ctx.moveTo(x+S*.46,T+S*.14);ctx.lineTo(x+S*.86,T+S*.24);ctx.stroke();
    const mx=x+S*.72,my=T+S*.64;
    ctx.fillStyle='#4a2538';ctx.beginPath();ctx.ellipse(mx,my,6.2*u,3.2*u,0,0,7);ctx.fill();
    ctx.fillStyle='#fff';wtri(mx-4*u,my-3*u,mx-1.6*u,my-3*u,mx-2.8*u,my+.8*u);ctx.fill();wtri(mx+1.6*u,my-3*u,mx+4*u,my-3*u,mx+2.8*u,my+.8*u);ctx.fill();
  }else if(k==='fox'){
    ctx.fillStyle='#f9fcff';ctx.beginPath();ctx.moveTo(x+S*.8,T+S*.36);ctx.quadraticCurveTo(x+S+6*u,T+S*.42,x+S+9*u,T+S*.54);ctx.quadraticCurveTo(x+S+4*u,T+S*.66,x+S*.8,T+S*.66);ctx.closePath();ctx.fill();wol(1.3);
    wdot(x+S+8*u,T+S*.53,2.4*u,'#10152e');wdot(x+S+7.3*u,T+S*.5,.8*u,'#fff');
    ctx.strokeStyle='rgba(60,80,110,.5)';ctx.lineWidth=1*u;ctx.beginPath();ctx.moveTo(x+S*.9,T+S*.58);ctx.lineTo(x+S+10*u,T+S*.7);ctx.moveTo(x+S*.9,T+S*.62);ctx.lineTo(x+S+8*u,T+S*.78);ctx.stroke();
  }
  wfx(T,S);
  ctx.restore();
}
