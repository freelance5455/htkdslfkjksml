/*
 * spawn.js - Spawning and scrolling of obstacles, coins and pickups.
 */
import { flyBanned, flyInZone } from './booster-zones.js';
import { MODES } from './config.js';
import { tpBlk } from './jungle-temple.js';
import { mgSpawn } from './mangrove.js';
import { state } from './state.js';
import { px, u, W } from './view.js';

export function spawnObjects(){
  const lo=state.obs[state.obs.length-1];
  const zn=Math.max(300*u,Math.min(state.speed,500*u)*1.5),sx0=state.dist+W+20,blk=(sx0<state.rz+zn&&(sx0>state.rz||(state.tr&&sx0+130*u>state.tr.rs)))||(state.adv&&(!!state.aFin||sx0<state.aBlk))||tpBlk(sx0),sb=state.tr?(sx0>=state.tr.re?state.tr.to:state.tr.from):state.bi;
  if(!blk&&(!lo||lo.x<W+20-state.gap)){
    const r=Math.random();let w=(34+Math.random()*10)*u,h=(34+Math.random()*18)*u;
    if(r>.85){w=30*u;h=64*u}else if(r>.6){w=78*u;h=36*u}
    const dr=sb!==2&&state.pt>8&&Math.random()<.22;if(dr){w=40*u;h=22*u}
    const wx=state.dist+W+20-px,ic=wx>state.cs*10*u+60*u&&wx<state.ce*10*u-60*u,pn=ic&&!dr&&Math.random()<.32;if(pn){w=(86+Math.random()*34)*u;h=0}
    const mq=sb===2?mgSpawn():null;if(mq){w=mq.w;h=mq.h}
    state.obs.push({x:W+20,w,h,f:mq?mq.f:dr?(Math.random()<.5?10:52)*u:0,c:ic,p:mq?mq.p:pn,m:mq?mq.m:0,b:sb,n:false});state.gap=state.speed*(.95+Math.random()*.8)+w;
    if(!state.adv&&!dr&&Math.random()<.75)for(let k=0;k<4;k++)state.coins.push({x:W+20+w/2+(k-1.5)*34*u,h:mq&&mq.f?15*u+4*u*Math.sin(Math.PI*k/3):h+28*u+22*u*Math.sin(Math.PI*k/3)});
    if(!state.rd&&sb!==2&&(state.adv||MODES[state.mode].b)&&Math.random()<.3)state.items.push({x:W+20+w+state.speed*.5,k:sb?'sled':'horse'});else if(!(state.adv||MODES[state.mode].b)){}else if(state.pt>=state.nextFly&&!flyBanned(W+20+w+state.speed*.5)){state.nextFly=state.pt+30;state.nFly++;state.items.push({x:W+20+w+state.speed*.5,k:'fly'})}else if(Math.random()<.25){const ks=state.adv?['ghost','shield','slow']:['ghost','shield','magnet','x2','slow'];state.items.push({x:W+20+w+state.speed*.5,k:ks[Math.random()*ks.length|0]})}
  }
}
export function scrollObjects(dt){
  state.items=state.items.filter(b=>!(b.k==='fly'&&flyInZone(b.x)));  // drop any Fly pickup that ended up inside a booster-free zone (e.g. a cave placed after it spawned)
  for(const o of state.obs)o.x-=state.speed*dt;
  while(state.obs.length&&state.obs[0].x+state.obs[0].w<-10)state.obs.shift();
  for(const c of state.coins){c.x-=state.speed*dt;const dx=px+17*u-c.x,dy=state.y+17*u-c.h;if(state.fx.magnet>0&&Math.hypot(dx,dy)<240*u){c.x+=dx*Math.min(1,dt*7);c.h+=dy*Math.min(1,dt*7)}}
}
