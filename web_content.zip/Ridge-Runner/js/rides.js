/*
 * rides.js - Rides: horse, sleigh, the river boat and the sea boat, plus losing a ride.
 */
import { snd } from './audio.js';
import { t } from './clock.js';
import { BOV, BPG, BSP, BST, bz, rr, wdot, wol } from './draw-utils.js';
import { furFlicks, grain, quilt, stitch } from './hand-drawn.js';
import { FL, rh, ter } from './physics.js';
import { state } from './state.js';
import { ctx, G, px, u } from './view.js';

export function lose(){const k=state.rd,cy=G+ter(px+17*u)-state.y;state.rd=0;state.fx.ghost=Math.max(state.fx.ghost,1.3);state.rips.push({x:px+17*u,y:cy-10*u,r:10*u,a:.9},{x:px+17*u,y:cy-22*u,r:4*u,a:.7});state.pops.push({x:px+20*u,y:cy-70*u,a:1.4,t:(k===2?'Sleigh':'Horse')+' lost'});snd('sp')}
export function rdr(f){
  if(FL()||!(state.ob||state.rd))return;
  const s=34*u,cx=px+s/2,gd=G+ter(cx),gy=gd-state.y,mv=state.y===0&&state.st==='play',ar=state.y>0;
  ctx.lineCap='round';
  if(state.ob){(state.tr&&state.tr.sea?rideC:rideB)(f,cx,gy,gd,gd+3*u+Math.sin(t*3)*1.6*u);return}
  if(state.rd===1){rideH(f,cx,gy,gd,mv,ar);return}
  rideS(f,cx,gy,gd,mv,ar);
}
/* ---- Hand-drawn horse and sleigh ---- */
function hLeg(p,w,c){ctx.lineJoin='round';ctx.lineCap='round';ctx.beginPath();ctx.moveTo(p[0],p[1]);for(let i=2;i<p.length;i+=2)ctx.lineTo(p[i],p[i+1]);ctx.strokeStyle='rgba(0,0,0,.4)';ctx.lineWidth=(w+1.8)*u;ctx.stroke();ctx.strokeStyle=c;ctx.lineWidth=w*u;ctx.stroke();ctx.beginPath();ctx.moveTo(p[0]-.9*u,p[1]);for(let i=2;i<p.length;i+=2)ctx.lineTo(p[i]-.9*u,p[i+1]);ctx.strokeStyle='rgba(255,228,185,.24)';ctx.lineWidth=1.1*u;ctx.stroke()}
function rideH(f,cx,gy,gd,mv,ar){
  const hc=cx-3*u,ph=t*16,wd=mv?1:.4;ctx.lineCap='round';ctx.lineJoin='round';
  if(f){ctx.strokeStyle='#4a2a14';ctx.lineWidth=1.6*u;ctx.beginPath();ctx.moveTo(hc+3*u,gy-38*u);ctx.lineTo(hc+3*u,gy-26*u);ctx.stroke();ctx.strokeStyle='#cfd6e4';ctx.lineWidth=1.5*u;rr(hc+.5*u,gy-26*u,5*u,4.4*u,1.4*u);ctx.stroke();ctx.strokeStyle='#7a2a1e';ctx.lineWidth=1.3*u;ctx.beginPath();ctx.moveTo(hc+8*u,gy-29*u);ctx.quadraticCurveTo(hc+28*u,gy-30*u+Math.sin(t*10)*1.2*u,hc+43*u,gy-47*u);ctx.stroke();return}
  if(mv){ctx.fillStyle='rgba(170,140,100,.42)';for(let q=0;q<3;q++){const p2=(t*3+q*.33)%1;ctx.beginPath();ctx.arc(hc-24*u-p2*26*u,gd-2*u-p2*8*u,(2+p2*4)*u,0,7);ctx.fill()}}
  for(let q=0;q<6;q++){const sw=Math.sin(t*(mv?12:3)+q*.8)*3*u*wd;BST(['#2e1a0e','#442a18','#2e1a0e'][q%3],3.4-q*.3,hc-23*u,gy-33*u,hc-33*u,gy-38*u+q*2*u+sw,hc-38*u-q*1.2*u,gy-20*u+q*3.5*u+sw*1.6);BST('rgba(200,140,100,.3)',.8,hc-23*u,gy-34*u,hc-33*u,gy-39*u+q*2*u+sw-.8*u,hc-38*u-q*1.2*u-.8*u,gy-20*u+q*3.5*u+sw*1.6-.8*u)}
  const L=[];for(let q=0;q<4;q++){const lx=hc+[-17,-9,12,20][q]*u,a=ph+(q%2)*Math.PI+(q>1?.6:0),dx=mv?Math.sin(a)*9*u:ar?(q>1?9:-9)*u:0,lf=mv?Math.max(0,Math.cos(a))*6*u:ar?(q>1?15:10)*u:0,fy=gy-lf-4*u,hx=lx+dx;L.push({q,lx,hx,fy,kx:lx+dx*.5+(q>1?3:-3)*u,ky:(gy-26*u+fy)/2-lf*.5})}
  const dl=l=>{const near=!(l.q%2);hLeg([l.lx,gy-26*u,l.kx,l.ky,l.hx,l.fy],4.6,near?'#a85a2c':'#7d4220');if(l.q===1||l.q===2)hLeg([l.kx+(l.hx-l.kx)*.45,l.ky+(l.fy-l.ky)*.45,l.hx,l.fy],4.6,'#f3e6d2');ctx.fillStyle='#2b1d12';ctx.beginPath();ctx.ellipse(l.hx+1*u,l.fy+2.4*u,3.4*u,2.4*u,0,0,7);ctx.fill();ctx.fillStyle='rgba(255,255,255,.25)';ctx.fillRect(l.hx-1*u,l.fy+1.4*u,3*u,.9*u);BST('rgba(235,215,190,.75)',1.1,l.hx-1.6*u,l.fy-1.4*u,l.hx-3.6*u,l.fy+.4*u,l.hx-2.6*u,l.fy+2.2*u)};
  L.filter(l=>l.q%2).forEach(dl);
  ctx.strokeStyle='rgba(0,0,0,.36)';ctx.lineWidth=13.4*u;ctx.beginPath();ctx.moveTo(hc+17*u,gy-34*u);ctx.lineTo(hc+30*u,gy-49*u);ctx.stroke();
  const bg=ctx.createLinearGradient(0,gy-41*u,0,gy-20*u);bg.addColorStop(0,'#c4703f');bg.addColorStop(1,'#8a4a26');ctx.fillStyle=bg;ctx.beginPath();ctx.ellipse(hc,gy-30*u,26*u,10.5*u,0,0,7);ctx.fill();ctx.strokeStyle='rgba(0,0,0,.34)';ctx.lineWidth=1.7*u;ctx.stroke();
  ctx.fillStyle='rgba(255,210,150,.2)';ctx.beginPath();ctx.ellipse(hc-13*u,gy-34*u,9*u,6*u,-.3,0,7);ctx.fill();ctx.beginPath();ctx.ellipse(hc+12*u,gy-33*u,8*u,5.5*u,.3,0,7);ctx.fill();ctx.fillStyle='rgba(60,25,8,.28)';ctx.beginPath();ctx.ellipse(hc,gy-24*u,20*u,3.4*u,0,0,7);ctx.fill();
  /* hand-drawn coat: spine shade, dapples and hair flicks inside the barrel */
  ctx.save();ctx.beginPath();ctx.ellipse(hc,gy-30*u,26*u,10.5*u,0,0,7);ctx.clip();
  ctx.fillStyle='rgba(60,25,8,.16)';ctx.beginPath();ctx.ellipse(hc,gy-39*u,24*u,3.4*u,0,0,7);ctx.fill();
  for(const[dx,dy,r]of[[-17,-29,2.4],[-10,-25,2],[8,-26,2.2],[17,-31,2.6],[-3,-33,1.8],[2,-23,1.6]]){ctx.fillStyle='rgba(70,32,12,.17)';ctx.beginPath();ctx.ellipse(hc+dx*u,gy+dy*u,r*u*1.25,r*u,.3,0,7);ctx.fill()}
  furFlicks(hc-25*u,gy-41*u,50*u,18*u,18,4.2*u,'rgba(255,214,160,.3)',.9,3);furFlicks(hc-25*u,gy-34*u,50*u,14*u,14,3.6*u,'rgba(60,25,8,.3)',.9,8);
  ctx.restore();
  L.filter(l=>!(l.q%2)).forEach(dl);
  ctx.strokeStyle='#a85a2c';ctx.lineWidth=11*u;ctx.beginPath();ctx.moveTo(hc+17*u,gy-34*u);ctx.lineTo(hc+30*u,gy-49*u);ctx.stroke();ctx.strokeStyle='rgba(255,215,160,.22)';ctx.lineWidth=3.4*u;ctx.beginPath();ctx.moveTo(hc+14*u,gy-36*u);ctx.lineTo(hc+26*u,gy-50*u);ctx.stroke();ctx.strokeStyle='rgba(60,25,8,.26)';ctx.lineWidth=2.4*u;ctx.beginPath();ctx.moveTo(hc+20.4*u,gy-31.6*u);ctx.lineTo(hc+33*u,gy-46.4*u);ctx.stroke();ctx.strokeStyle='rgba(60,25,8,.3)';ctx.lineWidth=.9*u;ctx.beginPath();for(let q=0;q<7;q++){const p=q/6,ax=hc+17.5*u+p*12*u,ay=gy-34*u-p*14*u,off=(q%2?1.8:-1.6)*u;ctx.moveTo(ax+off*.7,ay+off*.7);ctx.quadraticCurveTo(ax+off*.7-.8*u,ay+off*.7+1.2*u,ax+off*.7-2*u,ay+off*.7+2.6*u)}ctx.stroke();
  for(let i=0;i<6;i++){const s=i/5,x0=hc+13*u+14*u*s,y0=gy-40*u-15*u*s,sw=Math.sin(t*11+i)*2.6*u*wd;BST(i%2?'#4e2f1a':'#3b2415',3.2,x0,y0,x0-4*u,y0-5*u+sw*.5,x0-12*u-s*4*u,y0+4*u+sw);BST('rgba(210,150,105,.32)',.8,x0-.5*u,y0-.8*u,x0-4.4*u,y0-5.6*u+sw*.5,x0-12.4*u-s*4*u,y0+3.2*u+sw)}
  BPG('#8a4a26',hc+30*u,gy-56*u,hc+29*u,gy-65*u,hc+35*u,gy-57*u);ctx.fillStyle='#d68a6a';ctx.beginPath();ctx.moveTo(hc+30.8*u,gy-57.2*u);ctx.lineTo(hc+30.2*u,gy-63*u);ctx.lineTo(hc+33.6*u,gy-57.8*u);ctx.closePath();ctx.fill();
  ctx.save();ctx.translate(hc+38*u,gy-51*u);ctx.rotate(.55);ctx.fillStyle='#a85a2c';ctx.beginPath();ctx.ellipse(0,0,9.5*u,5.5*u,0,0,7);ctx.fill();wol(1.4);ctx.fillStyle='rgba(60,25,8,.25)';ctx.beginPath();ctx.ellipse(-1*u,2.2*u,6.5*u,3*u,0,0,7);ctx.fill();BOV(7.2*u,2.6*u,4.6*u,4*u,'#e6b987');wdot(8.8*u,1.8*u,1*u,'#5b2d18');ctx.strokeStyle='rgba(60,25,8,.6)';ctx.lineWidth=1*u;ctx.beginPath();ctx.moveTo(6*u,5*u);ctx.lineTo(9.6*u,4.4*u);ctx.stroke();ctx.strokeStyle='rgba(250,240,225,.85)';ctx.lineWidth=2*u;ctx.beginPath();ctx.moveTo(-6*u,-1.6*u);ctx.lineTo(5*u,-.6*u);ctx.stroke();ctx.restore();
  BPG('#a85a2c',hc+33*u,gy-56*u,hc+34*u,gy-66*u,hc+38*u,gy-57*u);BST('#3b2415',3,hc+33*u,gy-58*u,hc+38*u,gy-60*u,hc+40*u,gy-55*u);
  wdot(hc+39*u,gy-53*u,2*u,'#1a0f08');wdot(hc+38.3*u,gy-53.8*u,.7*u,'#fff');BST('rgba(60,25,8,.7)',1,hc+36*u,gy-55.6*u,hc+39*u,gy-56.6*u,hc+41*u,gy-54.6*u);
  BST('#2b1d12',1.2,hc+33*u,gy-55*u,hc+37*u,gy-51*u,hc+43*u,gy-46*u);BST('#ffd23f',1.5,hc+41*u,gy-52*u,hc+44.5*u,gy-50*u,hc+47*u,gy-47*u);wdot(hc+43*u,gy-46.4*u,1.3*u,'#ffd23f');
  ctx.fillStyle='#c43a52';rr(hc-12*u,gy-38*u,24*u,12*u,3.4*u);ctx.fill();wol(1.4);ctx.strokeStyle='#ffd23f';ctx.lineWidth=1.3*u;rr(hc-10.6*u,gy-36.6*u,21.2*u,9.2*u,2.6*u);ctx.stroke();for(let q=0;q<3;q++)wdot(hc-5*u+q*5*u,gy-32*u,1.1*u,'#ffd23f');
  ctx.fillStyle='#6b3a1c';rr(hc-8*u,gy-43*u,17*u,7.4*u,3.4*u);ctx.fill();wol(1.4);ctx.fillStyle='rgba(255,255,255,.18)';rr(hc-6*u,gy-42*u,12*u,2*u,1*u);ctx.fill();
  ctx.fillStyle='#5a2f16';rr(hc-9.6*u,gy-45.4*u,4.2*u,5.6*u,2*u);ctx.fill();wol(1.1);rr(hc+5.8*u,gy-45.8*u,3.8*u,5.6*u,1.9*u);ctx.fill();wol(1.1);
  stitch(hc-5*u,gy-39.2*u,hc,gy-38.2*u,hc+5*u,gy-39.2*u,7,'rgba(255,225,170,.75)',.8);
  for(let q=0;q<4;q++)BST('#ffd23f',1.1,hc-10.5*u+q*2.2*u,gy-26*u,hc-10.5*u+q*2.2*u,gy-24*u,hc-10.5*u+q*2.2*u+Math.sin(t*9+q)*.5*u,gy-21.6*u);
  if(state.bw>.25){const cb=Math.min(1,state.bw*1.4);for(let q=0;q<3;q++){const p=(t*1.2+q/3)%1;ctx.fillStyle='rgba(255,255,255,'+(.6*(1-p)*cb).toFixed(2)+')';ctx.beginPath();ctx.arc(hc+46*u+p*13*u,gy-47*u-p*7*u,(1.4+p*3.6)*u,0,7);ctx.fill()}}
}
function rideS(f,cx,gy,gd,mv,ar){
  ctx.lineCap='round';ctx.lineJoin='round';
  if(!f){
    if(mv)for(let q=0;q<4;q++){const p2=(t*3+q*.25)%1;ctx.fillStyle='rgba(255,255,255,'+(.7*(1-p2)).toFixed(2)+')';ctx.beginPath();ctx.arc(cx-34*u-p2*34*u,gd-2*u-p2*9*u,(2+p2*4)*u,0,7);ctx.fill();BSP(cx-40*u-p2*30*u,gd-8*u-p2*16*u,2.8*u*(1-p2),'rgba(255,240,170,'+(1-p2).toFixed(2)+')')}
    const P=()=>{ctx.beginPath();ctx.moveTo(cx-34*u,gy-8*u);ctx.quadraticCurveTo(cx-34*u,gy-4*u,cx-28*u,gy-4*u);ctx.lineTo(cx+26*u,gy-4*u);ctx.quadraticCurveTo(cx+42*u,gy-4*u,cx+41*u,gy-19*u);ctx.quadraticCurveTo(cx+41*u,gy-24*u,cx+36*u,gy-23*u)};
    for(const xs of[-22,2,22]){BST('#7b4a2a',3.2,cx+xs*u,gy-4*u,cx+xs*u-2*u,gy-8*u,cx+xs*u,gy-12*u);wdot(cx+xs*u,gy-4.4*u,1.2*u,'#ffd23f')}
    P();ctx.strokeStyle='rgba(0,0,0,.4)';ctx.lineWidth=5.2*u;ctx.stroke();ctx.strokeStyle='#dfe6f1';ctx.lineWidth=3.2*u;ctx.stroke();ctx.save();ctx.translate(0,-.9*u);P();ctx.strokeStyle='rgba(255,255,255,.85)';ctx.lineWidth=1*u;ctx.stroke();ctx.restore();
    ctx.fillStyle='#7a1c2f';rr(cx-27*u,gy-31*u,56*u,20*u,4*u);ctx.fill();wol(1.4);ctx.fillStyle='#b32f48';rr(cx-25*u,gy-20*u,50*u,9*u,4*u);ctx.fill();wol(1.2);quilt(cx-25*u,gy-20*u,50*u,9*u,7*u,'rgba(255,190,205,.28)',.8);for(let q=0;q<5;q++)wdot(cx-18*u+q*9*u,gy-15.4*u,1.2*u,'#ffd23f');
    const bn=mv?Math.abs(Math.sin(t*9))*1.2*u:0;
    ctx.fillStyle='#2e9d5a';rr(cx-26*u,gy-29*u-bn,10*u,9*u,1.4*u);ctx.fill();wol(1.2);ctx.fillStyle='#ffd23f';ctx.fillRect(cx-22*u,gy-29*u-bn,2*u,9*u);BOV(cx-23*u,gy-30*u-bn,2.6*u,1.6*u,'#ffd23f',-.4);
    ctx.fillStyle='#3b78e0';rr(cx-17*u,gy-26*u+bn*.4,8*u,6*u,1.2*u);ctx.fill();wol(1.2);ctx.fillStyle='#e5384f';ctx.fillRect(cx-13.8*u,gy-26*u+bn*.4,1.8*u,6*u);
    BST('rgba(0,0,0,.35)',6.8,cx-27*u,gy-12*u,cx-36*u,gy-20*u,cx-31*u,gy-33*u);BST('#c43a52',5,cx-27*u,gy-12*u,cx-36*u,gy-20*u,cx-31*u,gy-33*u);BST('#c43a52',4,cx-31*u,gy-33*u,cx-30*u,gy-39*u,cx-25*u,gy-37*u);wdot(cx-25*u,gy-37*u,2.6*u,'#ffd23f');
    BST('rgba(0,0,0,.35)',6.8,cx+26*u,gy-11*u,cx+44*u,gy-13*u,cx+40*u,gy-34*u);BST('#c43a52',5,cx+26*u,gy-11*u,cx+44*u,gy-13*u,cx+40*u,gy-34*u);wdot(cx+40*u,gy-35*u,3*u,'#ffd23f');wdot(cx+39*u,gy-36*u,1*u,'#fff4c0');
    const fl=7*u+Math.sin(t*8)*.8*u;ctx.strokeStyle='#5b3a1e';ctx.lineWidth=1*u;ctx.beginPath();ctx.moveTo(cx+41*u,gy-33*u);ctx.lineTo(cx+41*u,gy-29*u);ctx.stroke();ctx.fillStyle='rgba(255,200,90,.3)';ctx.beginPath();ctx.arc(cx+41*u,gy-26*u,fl,0,7);ctx.fill();ctx.fillStyle='#8a5a2b';rr(cx+38.5*u,gy-29*u,5*u,6.4*u,1.4*u);ctx.fill();wol(1);wdot(cx+41*u,gy-25.8*u,1.8*u,'#fff0a0');
    return}
  const wg=ctx.createLinearGradient(0,gy-24*u,0,gy-10*u);wg.addColorStop(0,'#e0455f');wg.addColorStop(1,'#9c2338');
  ctx.beginPath();ctx.moveTo(cx-29*u,gy-11*u);ctx.quadraticCurveTo(cx-31*u,gy-21*u,cx-27*u,gy-23*u);ctx.lineTo(cx+26*u,gy-23*u);ctx.quadraticCurveTo(cx+36*u,gy-24*u,cx+39*u,gy-33*u);ctx.quadraticCurveTo(cx+43*u,gy-17*u,cx+30*u,gy-11*u);ctx.closePath();ctx.fillStyle=wg;ctx.fill();wol(1.6);
  ctx.strokeStyle='#ffd23f';ctx.lineWidth=2*u;ctx.beginPath();ctx.moveTo(cx-27*u,gy-23*u);ctx.lineTo(cx+26*u,gy-23*u);ctx.quadraticCurveTo(cx+36*u,gy-24*u,cx+39*u,gy-33*u);ctx.stroke();
  ctx.strokeStyle='rgba(255,255,255,.28)';ctx.lineWidth=1.4*u;ctx.beginPath();ctx.moveTo(cx-24*u,gy-20.6*u);ctx.lineTo(cx+24*u,gy-20.6*u);ctx.stroke();grain(cx-25*u,gy-22*u,cx+25*u,gy-13*u,3,'rgba(90,10,28,.3)',.9,4);
  ctx.strokeStyle='rgba(255,210,60,.85)';ctx.lineWidth=1.6*u;ctx.beginPath();ctx.moveTo(cx-18*u,gy-14*u);ctx.bezierCurveTo(cx-10*u,gy-19*u,cx-4*u,gy-10*u,cx+4*u,gy-16*u);ctx.bezierCurveTo(cx+10*u,gy-19*u,cx+16*u,gy-12*u,cx+22*u,gy-16*u);ctx.stroke();wdot(cx-18*u,gy-14*u,1.4*u,'#ffd23f');wdot(cx+22*u,gy-16*u,1.4*u,'#ffd23f');
  for(let q=0;q<5;q++){const lx=cx-20*u+q*10*u;BOV(lx,gy-23.6*u,3.4*u,1.7*u,'#2f9a4a',q%2?.5:-.5);wdot(lx+5*u,gy-23.4*u,1.3*u,'#e5384f')}
  BOV(cx-8*u,gy-24.4*u,5*u,1.8*u,'#fff');BOV(cx+13*u,gy-24.4*u,4*u,1.6*u,'#fff');
}
/* ---- Hand-drawn boat ---- */
function rideB(f,cx,gy,gd,wy){
  const mv=state.st==='play',wx=mv?1:.4,th=1+Math.sin(t*3.4)*.25,cth=Math.cos(th),
    ox=cx-33*u,oy=wy-9.6*u,dp=29*u*cth-10.6*u,wet=Math.max(0,Math.min(1,(dp+2*u)/(10*u))),xs=ox-10.6*u*Math.tan(Math.min(th,1.2));
  ctx.lineCap='round';ctx.lineJoin='round';
  const wave=(x0,x1,y0,am,sp,k,yb,fill,foam)=>{
    const sy=x=>y0+Math.sin(t*sp+(x-cx)/u*k)*am;
    ctx.beginPath();ctx.moveTo(x0,sy(x0));
    for(let x=x0+8*u;x<x1;x+=8*u)ctx.lineTo(x,sy(x));
    ctx.lineTo(x1,sy(x1));
    if(foam){ctx.strokeStyle=foam;ctx.lineWidth=1.4*u;ctx.stroke()}
    ctx.quadraticCurveTo(x1+5*u,(y0+yb)/2,x1-8*u,yb);ctx.lineTo(x0+8*u,yb);ctx.quadraticCurveTo(x0-5*u,(y0+yb)/2,x0,sy(x0));
    ctx.fillStyle=fill;ctx.fill()};
  const hg=()=>{const g=ctx.createLinearGradient(0,wy-16*u,0,wy+8*u);g.addColorStop(0,'#c98a4b');g.addColorStop(1,'#7b4a2a');return g};
  const RV=(x,y)=>{wdot(x,y,1.5*u,'rgba(60,25,8,.5)');wdot(x-.1*u,y-.1*u,.9*u,'#ffd23f')};
  if(!f){
    const HP=()=>{ctx.beginPath();ctx.moveTo(cx-38*u,wy-15*u);ctx.quadraticCurveTo(cx-30*u,wy+7*u,cx-10*u,wy+8*u);ctx.lineTo(cx+14*u,wy+8*u);ctx.quadraticCurveTo(cx+36*u,wy+5*u,cx+44*u,wy-17*u);ctx.quadraticCurveTo(cx+38*u,wy-12*u,cx+30*u,wy-10*u);ctx.lineTo(cx-26*u,wy-10*u);ctx.closePath()};
    const SH=(k,c,w)=>{ctx.strokeStyle=c;ctx.lineWidth=w*u;ctx.lineCap='butt';ctx.beginPath();ctx.moveTo(cx-40*u,wy+(-16.5+k)*u);ctx.quadraticCurveTo(cx-30*u,wy+(-10+k)*u,cx-22*u,wy+(-10+k)*u);ctx.lineTo(cx+26*u,wy+(-10+k)*u);ctx.quadraticCurveTo(cx+38*u,wy+(-10+k)*u,cx+46*u,wy+(-18.5+k)*u);ctx.stroke();ctx.lineCap='round'};
    /* back wave layer and soft wake rings */
    wave(cx-54*u,cx+56*u,wy-1*u,1.8*u,3.2,.17,wy+12*u,'rgba(70,170,215,.4)','rgba(255,255,255,.4)');
    for(let q=0;q<4;q++){const ph=(t*1.4+q*.25)%1,x=cx-36*u-ph*50*u,a=(1-ph)*wx,rx=(4+ph*9)*u,ry=(1.6+ph*.9)*u;ctx.fillStyle='rgba(255,255,255,'+(.5*a).toFixed(2)+')';ctx.beginPath();ctx.ellipse(x,wy+2*u,rx,ry,0,0,7);ctx.fill();ctx.strokeStyle='rgba(255,255,255,'+(.4*a).toFixed(2)+')';ctx.lineWidth=1*u;ctx.beginPath();ctx.ellipse(x,wy+2*u,rx,ry,0,Math.PI*1.05,Math.PI*1.95);ctx.stroke()}
    /* stern sweep oar: pivots at the stern, blade dips and lifts */
    ctx.save();ctx.translate(ox,oy);ctx.rotate(th);
    ctx.beginPath();ctx.moveTo(0,-8*u);ctx.lineTo(0,20*u);ctx.strokeStyle='rgba(0,0,0,.38)';ctx.lineWidth=3.8*u;ctx.stroke();ctx.strokeStyle='#d9a066';ctx.lineWidth=2.2*u;ctx.stroke();
    ctx.strokeStyle='rgba(255,236,190,.55)';ctx.lineWidth=.7*u;ctx.beginPath();ctx.moveTo(-.6*u,-6*u);ctx.lineTo(-.6*u,19*u);ctx.stroke();
    wdot(0,-8.2*u,1.9*u,'#7b4a2a');
    ctx.fillStyle='#ffd23f';rr(-1.8*u,-.8*u,3.6*u,1.8*u,.8*u);ctx.fill();wol(.9);
    ctx.beginPath();ctx.moveTo(-1.4*u,18*u);ctx.bezierCurveTo(-5.4*u,20.5*u,-4.8*u,27*u,0,29*u);ctx.bezierCurveTo(4.8*u,27*u,5.4*u,20.5*u,1.4*u,18*u);ctx.closePath();ctx.fillStyle='#c98a4b';ctx.fill();wol(1.3);
    ctx.fillStyle='rgba(60,25,8,.28)';ctx.beginPath();ctx.ellipse(2.2*u,24*u,1.6*u,4*u,0,0,7);ctx.fill();
    ctx.strokeStyle='#ffd23f';ctx.lineWidth=1.1*u;ctx.beginPath();ctx.moveTo(0,19.5*u);ctx.lineTo(0,27*u);ctx.stroke();
    ctx.restore();
    /* bobbing pennant on a short mast */
    {const mx=cx+31*u,my=wy-50*u,w1=Math.sin(t*7)*1.5*u,w2=Math.sin(t*7+1.1)*2.4*u;
    ctx.beginPath();ctx.moveTo(mx,wy-12*u);ctx.lineTo(mx,my);ctx.strokeStyle='rgba(0,0,0,.35)';ctx.lineWidth=3.4*u;ctx.stroke();ctx.strokeStyle='#7b4a2a';ctx.lineWidth=1.9*u;ctx.stroke();
    wdot(mx,my-1.2*u,2.2*u,'#ffd23f');wdot(mx-.7*u,my-1.9*u,.7*u,'#fff4c0');
    ctx.beginPath();ctx.moveTo(mx,my);ctx.quadraticCurveTo(mx-12*u,my-2*u+w1,mx-23*u,my+1*u+w2);ctx.lineTo(mx-17*u,my+4.6*u+w2*.8);ctx.lineTo(mx-23*u,my+8.4*u+w2*1.1);ctx.quadraticCurveTo(mx-12*u,my+9*u+w1,mx,my+8*u);ctx.closePath();ctx.fillStyle='#d62839';ctx.fill();wol(1.3);
    BST('#ffd23f',1.3,mx-1*u,my+4*u,mx-11*u,my+3.2*u+w1,mx-17*u,my+4.6*u+w2*.8);
    BST('rgba(255,255,255,.35)',.9,mx-2*u,my+1.4*u,mx-10*u,my+.4*u+w1,mx-18*u,my+2*u+w2*.8)}
    /* stern lantern on a curved post */
    {const lx=cx-43*u+Math.sin(t*3.6)*.9*u,ly=wy-20*u,fk=Math.sin(t*11)*.6*u;
    BST('rgba(0,0,0,.35)',4.4,cx-33.5*u,wy-13*u,cx-44*u,wy-15*u,cx-43*u,wy-27*u);BST('#7b4a2a',2.8,cx-33.5*u,wy-13*u,cx-44*u,wy-15*u,cx-43*u,wy-27*u);
    ctx.strokeStyle='#5b3a1e';ctx.lineWidth=.9*u;ctx.beginPath();ctx.moveTo(cx-43*u,wy-27*u);ctx.lineTo(lx,ly-4.6*u);ctx.stroke();
    ctx.fillStyle='rgba(255,200,90,.22)';ctx.beginPath();ctx.arc(lx,ly,8*u+fk,0,7);ctx.fill();ctx.fillStyle='rgba(255,210,110,.26)';ctx.beginPath();ctx.arc(lx,ly,5*u+fk*.6,0,7);ctx.fill();
    BPG('#7b4a2a',lx-3.6*u,ly-3.6*u,lx,ly-6.2*u,lx+3.6*u,ly-3.6*u);
    ctx.fillStyle='#8a5a2b';rr(lx-3*u,ly-3.6*u,6*u,7.4*u,1.4*u);ctx.fill();wol(1);
    ctx.fillStyle='rgba(255,224,120,.95)';rr(lx-1.9*u,ly-2.4*u,3.8*u,5*u,1*u);ctx.fill();wdot(lx,ly+.4*u,1.5*u,'#fff0a0');
    ctx.fillStyle='#5b3a1e';rr(lx-3.4*u,ly+3.8*u,6.8*u,1.6*u,.8*u);ctx.fill()}
    /* swan-neck figurehead with a little scarf */
    {const hy=Math.sin(t*2.4)*.8*u,nk=()=>{ctx.beginPath();ctx.moveTo(cx+41*u,wy-12*u);ctx.bezierCurveTo(cx+52*u,wy-13*u,cx+38*u,wy-23*u,cx+47*u,wy-28.5*u+hy)};
    nk();ctx.strokeStyle='rgba(0,0,0,.4)';ctx.lineWidth=5.6*u;ctx.stroke();nk();ctx.strokeStyle='#ffd23f';ctx.lineWidth=3.6*u;ctx.stroke();
    ctx.save();ctx.translate(-.9*u,-.4*u);nk();ctx.strokeStyle='rgba(255,246,190,.7)';ctx.lineWidth=1*u;ctx.stroke();ctx.restore();
    BST('#d62839',2.4,cx+42*u,wy-21.4*u,cx+44*u,wy-20.2*u,cx+46*u,wy-21.8*u);
    BPG('#d62839',cx+42.4*u,wy-21*u,cx+39.6*u,wy-17.6*u+Math.sin(t*6)*.8*u,cx+43.2*u,wy-19.4*u);
    BOV(cx+48*u,wy-30*u+hy,4.1*u,3.2*u,'#ffd23f',-.2);
    BPG('#ff8f3a',cx+51.6*u,wy-31.6*u+hy,cx+57.5*u,wy-29.4*u+hy,cx+51.4*u,wy-28.2*u+hy);
    wdot(cx+49.6*u,wy-31*u+hy,1*u,'#1a0f08');wdot(cx+49.9*u,wy-31.4*u+hy,.35*u,'#fff');
    BSP(cx+46*u,wy-34.4*u+hy,(1.6+.5*Math.sin(t*5))*u,'#fff4c0')}
    /* planked hull, painted stripe, rivets */
    ctx.save();HP();ctx.clip();ctx.fillStyle=hg();ctx.fillRect(cx-48*u,wy-20*u,100*u,34*u);grain(cx-40*u,wy-14*u,cx+40*u,wy+4*u,5,'rgba(60,30,10,.24)',.8,6);
    SH(1.6,'rgba(255,225,170,.3)',1.1);SH(3.6,'rgba(60,30,10,.4)',1.1);
    SH(8,'#c43a52',3.2);SH(6.4,'#ffd23f',.9);SH(9.6,'#ffd23f',.9);SH(8,'rgba(255,255,255,.2)',.8);SH(12,'rgba(40,18,6,.3)',2.6);
    ctx.restore();
    HP();ctx.strokeStyle='rgba(0,0,0,.38)';ctx.lineWidth=1.8*u;ctx.stroke();
    RV(cx-34.6*u,wy-10.4*u);RV(cx-32.2*u,wy-8.2*u);
    /* carved gold scroll on the prow */
    ctx.beginPath();for(let i=0;i<=16;i++){const a=.6+i*.42,r=2.8*u*(1-i/19);ctx.lineTo(cx+37*u+Math.cos(a)*r,wy-10.3*u+Math.sin(a)*r)}
    ctx.strokeStyle='rgba(0,0,0,.4)';ctx.lineWidth=2.8*u;ctx.stroke();ctx.strokeStyle='#ffd23f';ctx.lineWidth=1.4*u;ctx.stroke();wdot(cx+37*u,wy-10.3*u,.8*u,'#fff4c0');
    /* oarlock ring on the stern plank */
    ctx.beginPath();ctx.arc(ox,oy,2.4*u,0,7);ctx.strokeStyle='rgba(0,0,0,.4)';ctx.lineWidth=2.8*u;ctx.stroke();ctx.strokeStyle='#ffd23f';ctx.lineWidth=1.3*u;ctx.stroke();
    return}
  /* ---- front pass: near wall, rope coil, layered waves, foam, spray ---- */
  const rg=ctx.createLinearGradient(0,wy-14*u,0,wy-8*u);rg.addColorStop(0,'#e0aa6c');rg.addColorStop(1,'#b9763c');
  ctx.fillStyle=hg();rr(cx-30*u,wy-8.6*u,62*u,4.4*u,1.4*u);ctx.fill();wol(1.1);
  ctx.strokeStyle='rgba(60,30,10,.4)';ctx.lineWidth=1.1*u;ctx.beginPath();ctx.moveTo(cx-29*u,wy-6.4*u);ctx.lineTo(cx+31*u,wy-6.4*u);ctx.stroke();
  for(let q=0;q<7;q++)RV(cx+(-25+q*9)*u,wy-6.4*u);
  ctx.fillStyle=rg;rr(cx-31*u,wy-14*u,64*u,6*u,3*u);ctx.fill();wol(1.5);
  ctx.strokeStyle='#ffd23f';ctx.lineWidth=2*u;ctx.beginPath();ctx.moveTo(cx-29*u,wy-14*u);ctx.lineTo(cx+31*u,wy-14*u);ctx.stroke();
  ctx.strokeStyle='rgba(255,240,200,.55)';ctx.lineWidth=.8*u;ctx.beginPath();ctx.moveTo(cx-27*u,wy-12.3*u);ctx.lineTo(cx+29*u,wy-12.3*u);ctx.stroke();
  ctx.strokeStyle='rgba(60,25,8,.3)';ctx.beginPath();ctx.moveTo(cx-27*u,wy-9.2*u);ctx.lineTo(cx+29*u,wy-9.2*u);ctx.stroke();
  /* rope coil resting on the stern rim */
  for(let q=0;q<3;q++){ctx.fillStyle=q%2?'#d9bb70':'#e8cf94';ctx.beginPath();ctx.ellipse(cx-27*u,wy-(15.2+q*2.3)*u,(5.4-q*.5)*u,2.2*u,0,0,7);ctx.fill();wol(1)}
  ctx.strokeStyle='rgba(120,80,30,.55)';ctx.lineWidth=.8*u;ctx.beginPath();for(let q=0;q<6;q++){const x=cx-31*u+q*2*u;ctx.moveTo(x,wy-13.2*u);ctx.lineTo(x+1.2*u,wy-17.6*u)}ctx.stroke();
  BST('rgba(0,0,0,.3)',3,cx-22*u,wy-16.4*u,cx-19*u,wy-11.4*u,cx-13*u,wy-11.2*u);BST('#e8cf94',1.8,cx-22*u,wy-16.4*u,cx-19*u,wy-11.4*u,cx-13*u,wy-11.2*u);
  /* layered translucent waves */
  wave(cx-50*u,cx+52*u,wy-.4*u,1.5*u,4.1,.23,wy+6*u,'rgba(130,210,240,.4)','rgba(255,255,255,.3)');
  const wg=ctx.createLinearGradient(0,wy,0,wy+16*u);wg.addColorStop(0,'rgba(60,160,205,.88)');wg.addColorStop(1,'rgba(38,125,180,.72)');
  wave(cx-64*u,cx+52*u,wy+1*u,1.6*u,5,.2,wy+16*u,wg,'rgba(255,255,255,.55)');
  /* foam hugging the waterline, glints */
  for(let q=0;q<6;q++){const hd=q<3?-43+q*5:35+(q-3)*6,x=cx+hd*u+Math.sin(t*4+q*1.7)*1.5*u,r=(2.6+q%3*.8+Math.sin(t*5+q)*.5)*u;ctx.fillStyle='rgba(255,255,255,.72)';ctx.beginPath();ctx.ellipse(x,wy+(.9+Math.sin(t*5+q*2)*.6)*u,r,r*.45,0,0,7);ctx.fill()}
  for(let q=0;q<3;q++){const s=Math.max(0,Math.sin(t*3.7+q*2.3));if(s>.05)BSP(cx+(-24+q*22)*u+Math.sin(t*.9+q)*4*u,wy+(6+q%2*4)*u,(1+2*s)*u,'rgba(255,255,255,.8)')}
  /* oar ripples and drips */
  if(wet>.02){
    for(let q=0;q<2;q++){const ph=(t*1.8+q*.5)%1;ctx.strokeStyle='rgba(255,255,255,'+(.7*(1-ph)*wet).toFixed(2)+')';ctx.lineWidth=1.2*u;ctx.beginPath();ctx.ellipse(xs,wy+1.6*u,(2+ph*11)*u,(.8+ph*2.4)*u,0,0,7);ctx.stroke()}
    for(let q=0;q<3;q++){const ph=(t*1.8+q*.17)%1;wdot(xs-(q+1)*3.2*ph*u+(q-1)*1.2*u,wy+1*u-Math.sin(ph*3.14)*(5+q*2)*u,(1.5-ph*.9)*u,'rgba(235,248,255,'+(.9*(1-ph)*wet).toFixed(2)+')')}}
  /* foam wake trailing behind */
  BST('rgba(255,255,255,'+(.45*wx).toFixed(2)+')',1.7,cx-42*u,wy+1.4*u,cx-60*u,wy+3.4*u+Math.sin(t*4)*1.2*u,cx-90*u,wy+1.2*u);
  for(let q=0;q<4;q++){const ph=(t*.9*wx+q*.25)%1,x=cx-44*u-ph*56*u,y=wy+(3+Math.sin(ph*9+q*2)*1.2)*u,r=(1.9-ph*.9)*u;ctx.fillStyle='rgba(255,255,255,'+(.55*(1-ph)*wx).toFixed(2)+')';ctx.beginPath();ctx.arc(x,y,r,0,7);ctx.fill();ctx.strokeStyle='rgba(190,230,250,'+(.6*(1-ph)*wx).toFixed(2)+')';ctx.lineWidth=.7*u;ctx.stroke()}
  /* bow wave and splash droplets */
  if(mv){
    BST('rgba(255,255,255,.7)',2,cx+39*u,wy+.8*u,cx+49*u,wy-3.6*u+Math.sin(t*6)*.8*u,cx+55*u,wy+1.2*u);
    for(let q=0;q<5;q++){const ph=(t*2.4+q*.2)%1,x=cx+42*u+ph*(9+q*3)*u,y=wy-1*u-4*ph*(1-ph)*(10+q*2.4)*u,r=(2.1-ph*1.3)*u,a=(.95*(1-ph)).toFixed(2);wdot(x,y,r,'rgba(235,248,255,'+a+')');if(!q)BSP(x+1*u,y-2*u,2.4*u*(1-ph),'rgba(255,255,255,'+a+')')}}
}
function rideC(f,cx,gy,gd,wy){
  const mv=state.st==='play',D=gd-rh()+u,wc=gd+3*u,wk=mv?1:.4;ctx.lineCap=ctx.lineJoin='round';
  const wave=(x0,x1,y0,am,sp,k,yb,fill,foam)=>{const sy=x=>y0+Math.sin(t*sp+(x-cx)/u*k)*am;ctx.beginPath();ctx.moveTo(x0,sy(x0));for(let x=x0+8*u;x<x1;x+=8*u)ctx.lineTo(x,sy(x));ctx.lineTo(x1,sy(x1));if(foam){ctx.strokeStyle=foam;ctx.lineWidth=1.4*u;ctx.stroke()}ctx.lineTo(x1,yb);ctx.lineTo(x0,yb);ctx.closePath();ctx.fillStyle=fill;ctx.fill()};
  if(!f){
    wave(cx-110*u,cx+130*u,wc-2*u,2.2*u,2.6,.14,wc+14*u,'rgba(60,150,196,.45)','rgba(255,255,255,.4)');
    const HP=()=>{ctx.beginPath();ctx.moveTo(cx-92*u,D);ctx.lineTo(cx-86*u,wc+10*u);ctx.lineTo(cx+86*u,wc+10*u);ctx.quadraticCurveTo(cx+108*u,wc+2*u,cx+118*u,D-7*u);ctx.quadraticCurveTo(cx+110*u,D-1*u,cx+100*u,D);ctx.closePath()};
    const box=(x,y,w,h,c)=>{ctx.fillStyle=c;rr(x,y,w,h,2*u);ctx.fill();ctx.fillStyle='rgba(60,90,140,.16)';rr(x+w-6*u,y+1*u,5.2*u,h-2*u,1.6*u);ctx.fill();ctx.fillStyle='rgba(255,255,255,.7)';ctx.fillRect(x+2*u,y+1*u,w-4*u,1*u);ctx.strokeStyle='rgba(60,90,140,.22)';ctx.lineWidth=.8*u;ctx.beginPath();ctx.moveTo(x+1.4*u,y+h-3*u);ctx.lineTo(x+w-1.4*u,y+h-3*u);ctx.stroke();rr(x,y,w,h,2*u);wol(1.3)},win=(x,y,w,n,c)=>{for(let i=0;i<n;i++){const wx=x+i*(w+3.4*u);ctx.fillStyle=(i*3+Math.floor(t*.7))%5===0?'#ffe39a':c;rr(wx,y,w,5*u,1.6*u);ctx.fill();wol(.8);ctx.fillStyle='rgba(255,255,255,.55)';ctx.fillRect(wx+1*u,y+.8*u,w*.5,1*u)}};
    /* tiered superstructure, funnel with drifting smoke, radar, stern flag */
    box(cx-84*u,D-17*u,68*u,17*u,'#f6f8fb');win(cx-80*u,D-12*u,6*u,6,'#6cb8dc');
    box(cx-76*u,D-32*u,52*u,15*u,'#eef2f8');win(cx-72*u,D-27*u,6*u,5,'#7cc4e4');
    box(cx-66*u,D-43*u,26*u,11*u,'#f6f8fb');ctx.fillStyle='#2c5a78';rr(cx-63*u,D-40.4*u,20*u,5*u,1.6*u);ctx.fill();wol(.9);ctx.fillStyle='rgba(255,255,255,.4)';ctx.fillRect(cx-61*u,D-39.6*u,8*u,1.2*u);
    BPG('#d62839',cx-36*u,D-32*u,cx-34*u,D-57*u,cx-24*u,D-57*u,cx-22*u,D-32*u);ctx.fillStyle='#1d2f58';ctx.fillRect(cx-34.3*u,D-57*u,10.6*u,4*u);ctx.fillStyle='#fff';ctx.fillRect(cx-34.8*u,D-47*u,11.6*u,2.4*u);
    BSP(cx-29*u,D-45.8*u,2.4*u,'#ffd23f');ctx.fillStyle='#ffd23f';ctx.fillRect(cx-34.3*u,D-57*u,10.6*u,1*u);for(let q=0;q<5;q++){const ph=(t*.45+q*.2)%1,qx=cx-29*u-ph*46*u,qy=D-60*u-ph*26*u,r=(3+ph*8)*u,a=.7*(1-ph);ctx.fillStyle='rgba(222,228,238,'+a.toFixed(2)+')';ctx.strokeStyle='rgba(90,105,130,'+(a*.5).toFixed(2)+')';ctx.lineWidth=1*u;ctx.beginPath();ctx.arc(qx,qy,r,0,7);ctx.moveTo(qx+r*1.4,qy-r*.3);ctx.arc(qx+r*.7,qy-r*.3,r*.7,0,7);ctx.fill();ctx.stroke();wdot(qx-r*.3,qy-r*.35,r*.3,'rgba(255,255,255,'+a.toFixed(2)+')')}
    BST('#5b6b7c',1.4,cx-53*u,D-43*u,cx-53*u,D-47*u,cx-53*u,D-52*u);BST('#c9d2de',1.6,cx-53*u-Math.sin(t*3)*6*u,D-52*u,cx-53*u,D-52.6*u,cx-53*u+Math.sin(t*3)*6*u,D-52*u);
    {const fx2=cx-80*u,w1=Math.sin(t*7)*1.6*u;BST('#7a6a58',1.4,fx2,D-17*u,fx2,D-27*u,fx2,D-37*u);BPG('#d62839',fx2,D-37*u,fx2-13*u,D-34*u+w1,fx2,D-30*u)}
    /* white hull: teak edge, gold line, portholes, navy waterline band */
    ctx.save();HP();ctx.clip();let g=ctx.createLinearGradient(0,D,0,wc+10*u);g.addColorStop(0,'#fbfcfe');g.addColorStop(1,'#cdd8e6');ctx.fillStyle=g;ctx.fillRect(cx-100*u,D-9*u,230*u,40*u);
    ctx.fillStyle='#1d2f58';ctx.fillRect(cx-100*u,D+12.6*u,230*u,20*u);ctx.fillStyle='#d62839';ctx.fillRect(cx-100*u,D+10.4*u,230*u,2.2*u);ctx.fillStyle='#ffd23f';ctx.fillRect(cx-100*u,D+1.6*u,230*u,1.2*u);ctx.fillStyle='#b88a52';ctx.fillRect(cx-100*u,D-.4*u,230*u,2*u);ctx.fillStyle='rgba(30,50,90,.13)';ctx.fillRect(cx-100*u,D+2.8*u,230*u,2.6*u);ctx.fillStyle='#2a9d8f';ctx.beginPath();ctx.moveTo(cx-96*u,D+16*u);ctx.quadraticCurveTo(cx+10*u,D+12.6*u,cx+112*u,D+3*u);ctx.quadraticCurveTo(cx+10*u,D+9.4*u,cx-96*u,D+14.4*u);ctx.fill();
    ctx.restore();HP();ctx.strokeStyle='rgba(0,0,0,.4)';ctx.lineWidth=1.8*u;ctx.stroke();
    for(let i=0;i<13;i++){const x=cx-72*u+i*12.6*u,y2=D+6.2*u;wdot(x,y2,2.7*u,'#35607f');wol(1.1);wdot(x-.7*u,y2-.8*u,.9*u,'rgba(255,255,255,.75)')}
    ctx.save();ctx.font='italic 800 '+4.4*u+'px "Bricolage Grotesque",system-ui,sans-serif';ctx.textAlign='left';ctx.textBaseline='alphabetic';ctx.fillStyle='#ffd23f';ctx.fillText('RIDGE QUEEN',cx+22*u,D+17.4*u);ctx.restore();
    {const ax=cx+101*u,ay=D+6.4*u;ctx.strokeStyle='#3a4256';ctx.lineWidth=1.3*u;ctx.beginPath();ctx.arc(ax,ay-3*u,1*u,0,7);ctx.moveTo(ax,ay-2*u);ctx.lineTo(ax,ay+3*u);ctx.moveTo(ax-2*u,ay-.6*u);ctx.lineTo(ax+2*u,ay-.6*u);ctx.moveTo(ax-3*u,ay+1*u);ctx.quadraticCurveTo(ax,ay+5*u,ax+3*u,ay+1*u);ctx.stroke()}
    /* bow mast with a pennant */
    {const mx=cx+92*u,my=D-30*u,w1=Math.sin(t*7)*1.5*u,w2=Math.sin(t*7+1.1)*2.4*u;BST('rgba(0,0,0,.35)',3.2,mx,D,mx,D-14*u,mx,my);BST('#8b95a5',1.8,mx,D,mx,D-14*u,mx,my);wdot(mx,my-1*u,2*u,'#ffd23f');
      ctx.beginPath();ctx.moveTo(mx,my);ctx.quadraticCurveTo(mx-10*u,my-2*u+w1,mx-20*u,my+1*u+w2);ctx.lineTo(mx-14*u,my+4*u+w2*.8);ctx.lineTo(mx-20*u,my+7*u+w2);ctx.quadraticCurveTo(mx-10*u,my+8*u+w1,mx,my+7*u);ctx.closePath();ctx.fillStyle='#ffd23f';ctx.fill();wol(1.2)}
    {const x0=cx-53*u,y0=D-52*u,x1=cx+92*u,y1=D-30*u,xm=(x0+x1)/2,ym=(y0+y1)/2+7*u,C=['#d62839','#ffd23f','#2a9d8f','#fdf6e9','#ff8f3a'];BST('rgba(0,0,0,.3)',1.8,x0,y0,xm,ym,x1,y1);BST('#5b3a1e',.9,x0,y0,xm,ym,x1,y1);for(let i=1;i<=12;i++){const p=i/13,bx=bz(x0,xm,x1,p,p),by=bz(y0,ym,y1,p,p);BPG(C[i%5],bx-2.4*u,by,bx+2.4*u,by,bx+Math.sin(t*5+i)*.8*u,by+5.4*u)}}
    box(cx+30*u,D-11*u,32*u,11*u,'#f6f8fb');win(cx+33.5*u,D-8*u,5.6*u,3,'#7cc4e4');
    for(let i=0;i<5;i++){const x=cx+28*u+i*6.4*u;ctx.fillStyle=i%2?'#fdf6e9':'#d62839';ctx.beginPath();ctx.moveTo(x,D-14*u);ctx.lineTo(x+6.4*u,D-14*u);ctx.lineTo(x+7.2*u,D-9*u);ctx.quadraticCurveTo(x+3.2*u,D-5.6*u,x-.8*u,D-9*u);ctx.closePath();ctx.fill();wol(1)}
    for(let i=0;i<2;i++){const x=cx+70*u+i*11*u;BST('rgba(0,0,0,.3)',3,x,D,x+3*u,D-6*u,x+4.6*u,D-9*u);BST('#c98a4b',1.8,x,D,x+3*u,D-6*u,x+4.6*u,D-9*u);ctx.fillStyle='#f6d58a';rr(x-1*u,D-3*u,8*u,1.8*u,.9*u);ctx.fill();wol(.8)}
    return}
  /* front pass: deck railing, waterline waves, foam, bow spray, wake */
  for(let i=0;i<=9;i++){const x=cx-34*u+i*11.5*u;BST('rgba(0,0,0,.35)',3,x,D+.4*u,x,D-4*u,x,D-9*u);BST('#fbfcfe',1.6,x,D,x,D-4.5*u,x,D-9*u);const bl=.55+.45*Math.sin(t*3+i*1.3);wdot(x,D-10.4*u,4.2*u,'rgba(255,214,120,'+(.14*bl).toFixed(2)+')');wdot(x,D-10.4*u,1.3*u,'#ffe9a8')}
  BST('rgba(0,0,0,.35)',3.2,cx-34*u,D-9*u,cx+20*u,D-9.4*u,cx+70*u,D-9*u);BST('#fbfcfe',1.9,cx-34*u,D-9*u,cx+20*u,D-9.4*u,cx+70*u,D-9*u);BST('rgba(255,255,255,.5)',1,cx-34*u,D-4.5*u,cx+20*u,D-4.9*u,cx+70*u,D-4.5*u);for(const rx of[cx+38*u,cx+56*u]){ctx.lineWidth=2.8*u;ctx.strokeStyle='rgba(0,0,0,.35)';ctx.beginPath();ctx.arc(rx,D-4.6*u,3.3*u,0,7);ctx.stroke();ctx.lineWidth=2*u;ctx.strokeStyle='#d62839';ctx.stroke();ctx.strokeStyle='#fff';ctx.setLineDash([1.8*u,3.2*u]);ctx.stroke();ctx.setLineDash([])}
  wave(cx-100*u,cx+122*u,wc-.4*u,1.7*u,4.1,.21,wc+8*u,'rgba(130,210,240,.4)','rgba(255,255,255,.35)');
  const wg=ctx.createLinearGradient(0,wc,0,wc+18*u);wg.addColorStop(0,'rgba(60,160,205,.9)');wg.addColorStop(1,'rgba(30,110,170,.75)');
  wave(cx-120*u,cx+124*u,wc+1.4*u,1.9*u,5,.18,wc+18*u,wg,'rgba(255,255,255,.6)');
  for(let q=0;q<8;q++){const x=cx-84*u+q*28*u+Math.sin(t*4+q*1.7)*2*u,r=(3+q%3*.9+Math.sin(t*5+q)*.5)*u;ctx.fillStyle='rgba(255,255,255,.72)';ctx.beginPath();ctx.ellipse(x,wc+(1+Math.sin(t*5+q*2)*.6)*u,r,r*.42,0,0,7);ctx.fill()}
  BST('rgba(255,255,255,'+(.5*wk).toFixed(2)+')',2,cx-88*u,wc+1.6*u,cx-120*u,wc+3.6*u+Math.sin(t*4)*1.2*u,cx-170*u,wc+1.4*u);
  for(let q=0;q<5;q++){const ph=(t*.9*wk+q*.2)%1,x=cx-90*u-ph*70*u,y2=wc+(3+Math.sin(ph*9+q*2)*1.2)*u;wdot(x,y2,(2-ph)*u,'rgba(255,255,255,'+(.55*(1-ph)*wk).toFixed(2)+')')}
  if(mv){BST('rgba(255,255,255,.75)',2.4,cx+104*u,wc+1*u,cx+120*u,wc-5*u+Math.sin(t*6)*.8*u,cx+130*u,wc+1.4*u);
    for(let q=0;q<5;q++){const ph=(t*2.4+q*.2)%1,x=cx+108*u+ph*(10+q*3)*u,y2=wc-1*u-4*ph*(1-ph)*(12+q*2.4)*u;wdot(x,y2,(2.2-ph*1.3)*u,'rgba(235,248,255,'+(.95*(1-ph)).toFixed(2)+')')}}
}
