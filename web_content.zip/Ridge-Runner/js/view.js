/*
 * view.js - Canvas, 2D context and viewport metrics (W, H, dpr, ground line G, unit scale u, runner x px, parallax layers).
 * These are live ES-module bindings: other modules read them directly, only this module assigns them
 * (resize() for the real screen; setContext/setMetrics for temporary off-screen drawing such as sprites and wardrobe previews).
 */
import { cv } from './dom.js';

export let ctx=cv.getContext('2d');
export let W;
export let H;
export let dpr;
export let G;
export let u;
export let px;
export let layers;
export let stars;
function mk(hMin,hMax,k,col,ty){
  const a=[];let x=0;
  while(x<W+300){const w=(ty==='m'?120+Math.random()*140:20+Math.random()*16)*u;a.push({x,w,h:(hMin+Math.random()*(hMax-hMin))*u});x+=ty==='m'?w*.65:w*.8+Math.random()*30*u}
  return{a,tw:x,k,col,ty};
}
export function resize(){
  dpr=Math.min(window.devicePixelRatio||1,2);W=cv.clientWidth;H=cv.clientHeight;
  cv.width=W*dpr;cv.height=H*dpr;ctx.setTransform(dpr,0,0,dpr,0,0);
  u=Math.max(.7,Math.min(1.4,H/640,W/360));G=Math.round(H*.78);px=W*.2;
  layers=[mk(90,210,.08,'#8fb3d1','m'),mk(60,150,.18,'#5f8fa6','m'),{a:[],tw:1,k:.22,col:'#86ad7c',ty:'h',base:70,amp:24,wl:190},{a:[],tw:1,k:.3,col:'#5f9261',ty:'h',base:44,amp:20,wl:130},mk(70,130,.4,'#2d6a4f','p')];
  layers.forEach((L,i)=>L.pk=['m0','m1','h0','h1','pn'][i]);stars=Array.from({length:6},()=>[Math.random(),Math.random()*.5,Math.random()*1.4+.5]);
}
/** Temporarily draw somewhere else (sprite sheet, wardrobe preview). Callers restore the previous context in a finally block. */
export function setContext(c){ctx=c}
/** Temporarily change the unit scale and runner x (wardrobe previews draw the runner at their own size). */
export function setMetrics(nu,npx){u=nu;px=npx}
