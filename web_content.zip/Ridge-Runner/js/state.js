/*
 * state.js - The shared mutable game state. Every value that more than one module reads or writes lives on the single `state` object.
 * (Values only one module touches stay private to it; canvas metrics live in view.js, the animation clock in clock.js.)
 */

export const state = {
  // ---- Game status & input
  st: 'menu',  // 'menu' | 'ready' | 'play' | 'over' | 'drown' | 'won'
  overAt: 0,  // performance.now() when the run ended (guards instant restart)
  hold: false,  // jump input currently held (variable jump height)
  buf: 0,  // jump-buffer timer, seconds

  // ---- Runner physics
  y: 0,  // height above the ground
  vy: 0,  // vertical velocity
  air: 0,  // seconds spent in the current jump
  cut: false,  // current jump already cut short by releasing early
  jumps: 0,  // jumps used since landing (2 = double jump spent)
  dist: 0,  // world distance scrolled
  speed: 0,  // current run speed

  // ---- Score & progress
  score: 0,
  best: 0,  // best score for the current mode
  bonus: 0,  // coin points added to the distance score
  coinN: 0,  // coins collected this run
  pt: 0,  // play time this run, seconds
  stage: -1,  // speed label currently shown in the HUD
  nb: 5000,  // score at which the next biome crossing is scheduled
  gap: 0,  // distance to leave before the next obstacle spawns

  // ---- World objects
  obs: [],  // obstacles
  coins: [],
  items: [],  // booster / ride pickups on the road
  pops: [],  // floating text pop-ups
  parts: [],  // water droplets
  rips: [],  // water ripples
  bf: [],  // booster sparks and shards
  fp: [],  // flight (jetpack) particles
  hb: 0,  // bottom edge of the sky fills; set by draw() each frame, read by the ground code

  // ---- Drowning
  dw: null,  // drowning state while st === 'drown', otherwise null

  // ---- Boosters & flight
  fx: {ghost:0,magnet:0,x2:0,slow:0,shield:0,fly:0},  // remaining seconds per booster (shield is 0 / 1)
  wasFly: false,  // was flying last frame
  lastC: 0,  // animation time of the last coin sound
  fcd: 0,  // distance counter between flight coins
  nextFly: 10,  // play time at which the next flight pickup may spawn
  nFly: 0,  // flight pickups spawned so far
  fap: 0,  // flight animation blend 0..1
  fty: 0,  // flight type: 1 jetpack (0 = not flying)
  ftl: 0,  // flight tilt
  fpt: 0,  // flight particle timer

  // ---- Biomes, rides & crossings
  bi: 0,  // current biome: 0 Mountain, 1 Snow Mountain, 2 Mangrove Forest
  bw: 0,  // snow blend 0..1
  bm: 0,  // mangrove blend 0..1
  tq: 0,  // crossing progress 0..1
  tr: null,  // active river / sea crossing {rs, re, from, to, sea}, or null
  ob: false,  // true while riding the crossing boat
  rd: 1,  // ride: 0 none, 1 horse, 2 sleigh
  rcd: 0,  // distance counter between crossing coins
  rz: -1e9,  // world position where the last crossing ended (spawn guard)
  cs: 450,  // current cave start, in 10u units
  ce: 830,  // current cave end, in 10u units
  cT: 0,  // cave style: 0 rock, 1 ice

  // ---- Jungle Temple
  tpOn: false,  // a temple is on the road
  tpDone: false,  // the temple has already appeared this run
  tpU: 0,  // temple start position, in u units
  tpL: null,  // lift state machine {ph,t,tn,sp,sn,h0,...}, or null
  tpLDone: false,  // lift activation has already started this temple
  tpH: 0,  // lift platform rise height
  tpCamY: 0,  // vertical camera offset while descending / ascending through the Temple
  tc: null,  // Temple chase {boulder, dust, debris, stone gate...} (temple-chase.js), or null
  tt: [],  // Temple hall traps: trapdoor / spikes / fire-pot / slab, positions in world px (temple-chase.js)

  // ---- Adventure mode
  adv: false,  // Adventure mode is active
  aS: null,  // saved progress {b, c, p} or null
  aFl: [],  // checkpoint flags
  aFin: null,  // finish gate, or null
  aTot: 0,  // total played seconds
  aBlk: -1e9,  // obstacle-free runway limit

  // ---- Player choices
  O: null,  // selected outfit (an entry of OUT); set by initOutfits()
  mode: 'easy',  // difficulty mode key: 'easy' | 'medium' | 'hard' | 'imp'
  inv: false,  // admin invincibility switch
  adm: false,  // admin unlocked
};
