/*
 * clock.js - Animation clock: `t` (seconds of animation time, drives every wobble) and the per-frame delta.
 */
export let t=0;
let last=0;
/** Advances the animation clock for the frame timestamp `n` (ms) and returns the clamped delta in seconds. */
export function tick(n){const dt=Math.min(.033,(n-last)/1000||0);last=n;t+=dt;return dt}
