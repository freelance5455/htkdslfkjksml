/*
 * collision.js - Collisions: coin and pickup collection and obstacle hits (ride loss, shield break, splash, drowning, death).
 */
import { snd } from './audio.js';
import { grab, pickFx, shBreak } from './boosters.js';
import { t } from './clock.js';
import { die } from './game.js';
import { rh, ter } from './physics.js';
import { lose } from './rides.js';
import { state } from './state.js';
import { G, px, u } from './view.js';
import { plunge, splash } from './water-fx.js';

export function collectPickups(dt,fl){
  const pcx=px+17*u,pcy=G+ter(px+17*u)-state.y-17*u-rh()*.6;
  for(const c of state.coins)if(!c.got&&Math.hypot(c.x-pcx,G+ter(c.x)-c.h-pcy)<26*u){c.got=true;const v=state.fx.x2>0?20:10;state.bonus+=v;state.coinN++;if(!fl)state.pops.push({x:c.x,y:G+ter(c.x)-c.h,a:1,t:'+'+v});if(t-state.lastC>.07){state.lastC=t;snd('c')}}
  state.coins=state.coins.filter(c=>!c.got&&c.x>-20);
  for(const b of state.items){b.x-=state.speed*dt;if(Math.hypot(b.x-pcx,G+ter(b.x)-38*u-pcy)<30*u){b.got=true;grab(b.k);pickFx(b)}}
  state.items=state.items.filter(b=>!b.got&&b.x>-30);
}
export function hitObstacles(fl){
  const s2=34*u,i=6*u,RH=rh(),ex=state.rd&&!state.ob&&!fl?14*u:0,a=px+i-ex,c=px+s2-i+ex,Tp=ter(px+17*u),d=G+Tp-state.y-i,b=G+Tp-state.y-s2+i-RH;
  for(const o of state.obs){
    if(o.n||state.inv)continue;if(o.p){const mid=px+17*u;if(state.y<=4*u&&!fl&&state.fx.ghost<=0&&mid>o.x+6*u&&mid<o.x+o.w-6*u){if(state.rd||state.fx.shield){if(state.rd)lose();else{state.fx.shield=0;shBreak()}state.vy=860*u;state.y=1;state.jumps=1;state.air=0;state.cut=true;splash(mid,o,10);snd('sp')}else{plunge(o);break}}continue}if(!fl&&state.fx.ghost<=0&&c>o.x+3*u&&a<o.x+o.w-3*u&&d>G+ter(o.x+o.w*.5)-(o.f||0)-o.h+3*u&&b<G+ter(o.x+o.w*.5)-(o.f||0)-3*u){if(state.rd||state.fx.shield){if(state.rd)lose();else{state.fx.shield=0;shBreak();state.pops.push({x:px+20*u,y:G+ter(px+17*u)-state.y-50*u,a:1.2,t:'Shield broke',c:'#7dffa8'})}state.obs.splice(state.obs.indexOf(o),1);snd('b')}else die();break}
  }
}
