/*
 * hand-drawn.js - Shared hand-drawn finishing touches for outfits and rides: sketchy double body outline, soft shading with
 * pencil hatching, fur flicks and tufts, stitches, wood grain, quilting, and painted fairy wings.
 * Everything draws with translucent colours only (never sets ctx.globalAlpha), so ghost transparency and biome fades still apply.
 */
import { t } from './clock.js';
import { bgH, rr, wdot, wol } from './draw-utils.js';
import { ctx, px, u } from './view.js';

const INK = '32,18,48';

/* Points around a rounded rectangle, with extra points on the long edges so the outline can wobble like a hand-drawn line. */
function rrPts(x, y, w, h, r, n) {
  const c = [], arc = (cx, cy, a0) => { for (let i = 0; i <= n; i++) { const a = a0 + i / n * Math.PI / 2; c.push([cx + Math.cos(a) * r, cy + Math.sin(a) * r]); } };
  arc(x + r, y + r, Math.PI); arc(x + w - r, y + r, Math.PI * 1.5); arc(x + w - r, y + h - r, 0); arc(x + r, y + h - r, Math.PI * .5);
  const p = [];
  for (let i = 0; i < c.length; i++) {
    const a = c[i], b = c[(i + 1) % c.length], d = Math.hypot(b[0] - a[0], b[1] - a[1]), k = Math.max(1, Math.round(d / (4 * u)));
    for (let j = 0; j < k; j++) p.push([a[0] + (b[0] - a[0]) * j / k, a[1] + (b[1] - a[1]) * j / k]);
  }
  return p;
}
/* Smooth closed or open stroke through wobbled points (quadratic curves through the midpoints). */
function trace(p, from, count) {
  const n = p.length, at = i => p[(from + i) % n], mid = (a, b) => [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2];
  const s = mid(at(0), at(1));
  ctx.beginPath(); ctx.moveTo(s[0], s[1]);
  for (let i = 1; i < count; i++) { const m = mid(at(i), at(i + 1)); ctx.quadraticCurveTo(at(i)[0], at(i)[1], m[0], m[1]); }
}

/** Soft core shadow and loose pencil hatching in the lower-right of the body, drawn under the outfit's own body layer. */
export function bodyShade(T, S) {
  const x = px, h = S * .8;
  ctx.save(); rr(x, T, S, h, 10 * u); ctx.clip();
  const g = ctx.createRadialGradient(x + S * .92, T + h * 1.04, S * .08, x + S * .92, T + h * 1.04, S * .78);
  g.addColorStop(0, 'rgba(' + INK + ',.2)'); g.addColorStop(1, 'rgba(' + INK + ',0)');
  ctx.fillStyle = g; ctx.fillRect(x, T, S, h);
  ctx.strokeStyle = 'rgba(' + INK + ',.12)'; ctx.lineWidth = 1.1 * u; ctx.lineCap = 'round';
  ctx.beginPath();
  for (let i = 0; i < 7; i++) {
    const x0 = x + S * (.3 + i * .1), y0 = T + h + 2 * u, len = S * (.16 + bgH(i, 2) * .12) * (.5 + i * .09);
    ctx.moveTo(x0, y0); ctx.quadraticCurveTo(x0 + len * .34, y0 - len * .52 - .7 * u, x0 + len * .55, y0 - len);
  }
  ctx.stroke(); ctx.restore();
}
/** Wobbly double ink outline, a glossy highlight arc and a rim light, drawn over the body edge after the outfit's body layer. */
export function bodyInk(T, S) {
  const x = px, h = S * .8, cx = x + S / 2, cy = T + h / 2, P = rrPts(x, T, S, h, 10 * u, 4);
  const J = (k, a) => P.map((q, i) => { const dx = q[0] - cx, dy = q[1] - cy, l = Math.hypot(dx, dy) || 1, o = ((bgH(i, k) - .5) * 1.1 + Math.sin(i * 1.7 + k) * .3) * a * u; return [q[0] + dx / l * o, q[1] + dy / l * o]; });
  ctx.save(); ctx.lineJoin = 'round'; ctx.lineCap = 'round';
  const A = J(5, .9); trace(A, 0, A.length); ctx.strokeStyle = 'rgba(' + INK + ',.26)'; ctx.lineWidth = 1.3 * u; ctx.stroke();
  const B = J(11, 1.4); trace(B, 7, B.length - 4); ctx.strokeStyle = 'rgba(' + INK + ',.17)'; ctx.lineWidth = .9 * u; ctx.stroke();
  ctx.strokeStyle = 'rgba(255,255,255,.5)'; ctx.lineWidth = 1.6 * u;
  ctx.beginPath(); ctx.moveTo(x + 2.6 * u, T + h * .48); ctx.quadraticCurveTo(x + 2.4 * u, T + 3.2 * u, x + S * .3, T + 2.4 * u); ctx.stroke();
  wdot(x + S * .37, T + 2.5 * u, .9 * u, 'rgba(255,255,255,.55)');
  ctx.strokeStyle = 'rgba(255,255,255,.18)'; ctx.lineWidth = 1 * u;
  ctx.beginPath(); ctx.moveTo(x + S - 2.4 * u, T + h * .3); ctx.quadraticCurveTo(x + S - 2.2 * u, T + 4 * u, x + S * .8, T + 2.4 * u); ctx.stroke();
  ctx.restore();
}

/** Short curved fur flicks in staggered, slightly jittered rows (hair lies toward the lower-left). Clip first if the shape is not a rectangle. */
export function furFlicks(x, y, w, h, n, len, col, lw, sd) {
  const cols = Math.max(2, Math.round(Math.sqrt(n * w / h))), rows = Math.max(1, Math.round(n / cols)), cw = w / cols, rh = h / rows;
  ctx.strokeStyle = col; ctx.lineWidth = lw * u; ctx.lineCap = 'round'; ctx.beginPath();
  for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
    const i = r * cols + c, bx = x + cw * (c + .5 + (r % 2 ? .5 : 0) + (bgH(i, sd) - .5) * .5), by = y + rh * (r + .5 + (bgH(i, sd + 3) - .5) * .5);
    const l = len * (.75 + .5 * bgH(i, sd + 5)), sw = Math.sin(t * 3 + i * 1.7) * .3 * u;
    ctx.moveTo(bx, by); ctx.quadraticCurveTo(bx - l * .2 + sw, by + l * .45, bx - l * .45 + sw, by + l);
  }
  ctx.stroke();
}
/** Curved, flame-shaped fur tufts standing along a line (nx, ny is the outward unit normal), filled and outlined like the rest of the art. */
export function furTufts(x0, y0, x1, y1, nx, ny, n, len, wd, fill) {
  const tx = x1 - x0, ty = y1 - y0, tl = Math.hypot(tx, ty) || 1, ux = tx / tl, uy = ty / tl;
  ctx.fillStyle = fill;
  for (let i = 0; i < n; i++) {
    const p = (i + .5) / n, bx = x0 + tx * p, by = y0 + ty * p, l = len * (.75 + .5 * bgH(i, 9)), sw = Math.sin(t * 4 + i * 1.9) * .6 * u;
    ctx.beginPath(); ctx.moveTo(bx - ux * wd, by - uy * wd);
    ctx.quadraticCurveTo(bx - ux * wd * .9 + nx * l * .75, by - uy * wd * .9 + ny * l * .75, bx + nx * l - ux * l * .4 + sw, by + ny * l - uy * l * .4);
    ctx.quadraticCurveTo(bx + ux * wd * .8 + nx * l * .35, by + uy * wd * .8 + ny * l * .35, bx + ux * wd, by + uy * wd);
    ctx.closePath(); ctx.fill(); wol(1.2);
  }
}
/** Dashed stitches along a quadratic curve. */
export function stitch(x0, y0, cx, cy, x1, y1, n, col, lw) {
  const q = p => [(1 - p) * (1 - p) * x0 + 2 * p * (1 - p) * cx + p * p * x1, (1 - p) * (1 - p) * y0 + 2 * p * (1 - p) * cy + p * p * y1];
  ctx.strokeStyle = col; ctx.lineWidth = lw * u; ctx.lineCap = 'round'; ctx.beginPath();
  for (let i = 0; i < n; i++) { const a = q((i + .12) / n), b = q((i + .62) / n); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); }
  ctx.stroke();
}
/** Loose wavy wood-grain strokes between two corners. */
export function grain(x0, y0, x1, y1, n, col, lw, sd) {
  ctx.strokeStyle = col; ctx.lineWidth = lw * u; ctx.lineCap = 'round'; ctx.beginPath();
  for (let i = 0; i < n; i++) {
    const y = y0 + (y1 - y0) * (i + .5) / n, a = x0 + (x1 - x0) * bgH(i, sd) * .35, b = x1 - (x1 - x0) * bgH(i, sd + 2) * .35;
    ctx.moveTo(a, y); ctx.quadraticCurveTo((a + b) / 2, y + (bgH(i, sd + 4) - .5) * 1.8 * u, b, y + (bgH(i, sd + 6) - .5) * .9 * u);
  }
  ctx.stroke();
}
/** Diamond quilting inside a rounded rectangle, with a small button at each crossing. */
export function quilt(x, y, w, h, gap, col, lw, btn) {
  ctx.save(); rr(x, y, w, h, 3 * u); ctx.clip();
  ctx.strokeStyle = col; ctx.lineWidth = lw * u; ctx.beginPath();
  for (let d = -h; d < w + h; d += gap) { ctx.moveTo(x + d, y); ctx.lineTo(x + d + h, y + h); ctx.moveTo(x + d + h, y); ctx.lineTo(x + d, y + h); }
  ctx.stroke();
  if (btn) for (let d = gap / 2; d < w; d += gap) wdot(x + d, y + h / 2, .9 * u, btn);
  ctx.restore();
}

/** A veined, shimmering fairy wing growing up (negative y) from the origin; the caller translates and rotates. */
export function fairyWing(len, wd, c1, c2) {
  const g = ctx.createLinearGradient(0, 0, 0, -len); g.addColorStop(0, c1); g.addColorStop(1, c2);
  const P = () => { ctx.beginPath(); ctx.moveTo(0, 0); ctx.bezierCurveTo(-wd * 1.1, -len * .3, -wd * .9, -len * .98, 0, -len); ctx.bezierCurveTo(wd * .8, -len * .86, wd * .8, -len * .3, 0, 0); ctx.closePath(); };
  P(); ctx.fillStyle = g; ctx.fill();
  ctx.save(); P(); ctx.clip();
  ctx.strokeStyle = 'rgba(255,255,255,.7)'; ctx.lineWidth = .9 * u; ctx.beginPath();
  for (const[a, b] of [[-.8, .55], [-.35, .82], [.05, .95], [.5, .72]]) { ctx.moveTo(0, 0); ctx.quadraticCurveTo(wd * a * .6, -len * b * .5, wd * a, -len * b); }
  ctx.stroke();
  ctx.strokeStyle = 'rgba(255,255,255,.5)'; ctx.lineWidth = 1.4 * u; ctx.beginPath(); ctx.moveTo(-wd * .7, -len * .3); ctx.quadraticCurveTo(-wd * .72, -len * .7, -wd * .12, -len * .93); ctx.stroke();
  ctx.restore();
  P(); wol(1.2);
  const s = Math.max(0, Math.sin(t * 5 + len)); if (s > .05) wdot(-wd * .3, -len * .62, (.8 + 1.2 * s) * u, 'rgba(255,255,255,.85)');
}
