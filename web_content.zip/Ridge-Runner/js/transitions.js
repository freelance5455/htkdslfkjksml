/*
 * transitions.js - River / sea crossings between biomes: scheduling, progress, blending and the biome switch.
 */
import { caveStartAfterFlight } from './booster-zones.js';
import { advFlag } from './adventure-mode.js';
import { snd } from './audio.js';
import { ADV } from './config.js';
import { state } from './state.js';
import { G, px, u, W } from './view.js';

export function stepCrossing(dt,fl){
  state.ob=false;
  if(!state.tr&&(state.adv?(!state.aFin&&state.bi<2&&state.pt>=ADV.T[state.bi]):state.score>=state.nb)&&!fl&&!state.tpOn&&state.cs*10*u>state.dist+W+900*u){const nx=(state.bi+1)%3,se=nx===2;state.tr={rs:state.dist+W+300*u,re:state.dist+W+(se?3200:2600)*u,from:state.bi,to:nx,sea:se};state.rz=state.tr.re;state.nb+=se?10000:5000;state.cs=1e9;state.ce=state.cs+420;state.pops.push({x:W/2,y:G*.4,a:2.2,t:se?'Sea ahead':'River ahead'})}
  if(state.tr){const eL=state.tr.rs-state.dist,eR=state.tr.re-state.dist,cx=px+17*u,k=Math.max(0,Math.min(1,(cx-eL)/(eR-eL)));state.ob=cx>eL&&cx<eR;state.tq=k;{const f=v=>(state.tr.from===v?1-k:0)+(state.tr.to===v?k:0);state.bw=f(1);state.bm=f(2)}
    const sx=state.dist+W+20;if(sx>state.tr.rs+40*u&&sx<state.tr.re-60*u){state.rcd+=state.speed*dt;if(state.rcd>84*u){state.rcd=0;if(!state.adv)state.coins.push({x:W+20,h:(26+7*Math.sin(sx*.012))*u})}}
    if(state.bi!==state.tr.to&&cx>eR){state.bi=state.tr.to;state.rd=state.bi===2?0:state.bi+1;state.cs=state.bi===2?1e9:caveStartAfterFlight(Math.ceil((state.dist+W+1500*u)/(10*u)));state.ce=state.cs+420;state.cT=state.bi&1;state.pops.push({x:W*.5,y:G*.4,a:2.2,t:['Mountain','Snow Mountain','Mangrove Forest'][state.bi]});snd('b');if(state.adv)advFlag(state.tr.re)}
    if(eR<-40*u)state.tr=null}else{state.bw=state.bi===1?1:0;state.bm=state.bi===2?1:0}
}
