/*
 * backgrounds.js - Sky and parallax scenery: sun, clouds, mountains, hills, pines, mist, snowfall, vignette.
 */
import { l3 } from './biomes.js';
import { t } from './clock.js';
import { bgH, BST, lc, obSpk, wdot } from './draw-utils.js';
import { state } from './state.js';
import { ctx, G, H, px, stars, u, W } from './view.js';

function hills(L){ctx.beginPath();ctx.moveTo(0,H);for(let x=0;x<=W+10;x+=10){const w=x+state.dist*L.k;ctx.lineTo(x,G-(L.base+L.amp*(Math.sin(w/(L.wl*u))+.5*Math.sin(w/(L.wl*.43*u)+2)))*u)}ctx.lineTo(W+10,H);ctx.closePath();ctx.fillStyle=L.col;ctx.fill();const hg=ctx.createLinearGradient(0,G-(L.base+L.amp*1.6)*u,0,G);hg.addColorStop(0,'rgba(255,255,255,.22)');hg.addColorStop(1,'rgba(255,255,255,0)');ctx.fillStyle=hg;ctx.fill()}
export function vig(){const m=Math.min(W,H),vg=ctx.createRadialGradient(W/2,H*.5,m*.5,W/2,H*.5,Math.max(W,H)*.85);vg.addColorStop(0,'rgba(0,0,0,0)');vg.addColorStop(1,'rgba(8,12,28,.3)');ctx.fillStyle=vg;ctx.fillRect(0,0,W,H)}
export function snowfall(){const eL=px+state.cs*10*u-state.dist,eR=px+state.ce*10*u-state.dist;ctx.fillStyle='#fff';for(let i=0;i<48;i++){const sp=.6+i%4*.25,x=(((i*137.5-state.dist*.14*sp+Math.sin(t*.9+i)*16)%(W+40))+(W+40))%(W+40)-20,y=(i*61.8+t*(34+i%5*14)*u)%(H+20)-10;if(x>eL&&x<eR)continue;ctx.globalAlpha=state.bw*(.45+.4*(i%2));ctx.beginPath();ctx.arc(x,y,(1+i%3*.7)*u,0,7);ctx.fill()}ctx.globalAlpha=1}
const bgPk=[[0,0],[.13,.3],[.21,.34],[.31,.54],[.4,.6],[.45,.84],[.5,1],[.55,.86],[.61,.7],[.69,.63],[.77,.5],[.85,.32],[.93,.2],[1,0]];
export function bgSun(){
  const sx=W*.74,sy=G*.5;ctx.lineJoin='round';
  const sg=ctx.createRadialGradient(sx,sy,4*u,sx,sy,150*u);sg.addColorStop(0,'rgba(255,248,210,.95)');sg.addColorStop(.25,'rgba(255,236,170,.45)');sg.addColorStop(1,'rgba(255,236,170,0)');ctx.fillStyle=sg;ctx.beginPath();ctx.arc(sx,sy,150*u,0,7);ctx.fill();
  ctx.fillStyle='rgba(255,246,210,.06)';for(let q=0;q<6;q++){const an=-.2+q*.5+Math.sin(t*.3)*.04;ctx.beginPath();ctx.moveTo(sx,sy);ctx.lineTo(sx+Math.cos(an)*W*1.3,sy+Math.sin(an)*W*1.3);ctx.lineTo(sx+Math.cos(an+.12)*W*1.3,sy+Math.sin(an+.12)*W*1.3);ctx.fill()}
  ctx.fillStyle='rgba(255,240,170,.55)';ctx.strokeStyle='rgba(255,190,90,.38)';ctx.lineWidth=1.2*u;
  for(let q=0;q<14;q++){const an=q*.4488+t*.06,len=(q%2?64:80+Math.sin(t*1.5+q)*3)*u,hw=.075;ctx.beginPath();ctx.moveTo(sx+Math.cos(an-hw)*52*u,sy+Math.sin(an-hw)*52*u);ctx.lineTo(sx+Math.cos(an)*len,sy+Math.sin(an)*len);ctx.lineTo(sx+Math.cos(an+hw)*52*u,sy+Math.sin(an+hw)*52*u);ctx.closePath();ctx.fill();ctx.stroke()}
  const dg=ctx.createRadialGradient(sx-12*u,sy-12*u,4*u,sx,sy,48*u);dg.addColorStop(0,'#ffffff');dg.addColorStop(.6,'#fff4c0');dg.addColorStop(1,'#ffe08a');ctx.fillStyle=dg;ctx.beginPath();ctx.arc(sx,sy,46*u,0,7);ctx.fill();
  ctx.strokeStyle='rgba(255,190,90,.65)';ctx.lineWidth=2.6*u;ctx.stroke();ctx.strokeStyle='rgba(255,190,90,.3)';ctx.lineWidth=1.2*u;ctx.beginPath();ctx.arc(sx+1*u,sy+1*u,49*u,.3,4.3);ctx.stroke();
  ctx.fillStyle='rgba(255,255,255,.6)';ctx.beginPath();ctx.ellipse(sx-17*u,sy-19*u,10*u,5.5*u,-.7,0,7);ctx.fill();
}
export function bgClouds(){
  const W2=W*1.4,tc=l3('#ffffff','#f4f9ff','#f6f0cc'),bc=l3('#d2deec','#bcd0e6','#c6d4a8'),oc=l3('#8aa5c6','#7f9bc0','#6f8f62',.4);ctx.lineJoin='round';ctx.globalAlpha=.9;
  const lump=[[-1.6,0,.5],[-.8,-.32,.72],[0,-.5,.9],[.85,-.34,.7],[1.65,-.02,.48]];
  for(const s of stars){
    const cx=((s[0]*W2-state.dist*.04*(.6+s[2]*.3)-t*2.5*u*(.5+s[2]*.4))%W2+W2)%W2-W*.2,cy=s[1]*H*.6+24*u,r=(24+s[2]*14)*u,z=r*.7;
    ctx.beginPath();for(const[a,b,c]of lump){const lx=cx+a*z,ly=cy+b*r,lr=c*r;ctx.moveTo(lx+lr,ly);ctx.arc(lx,ly,lr,0,7)}ctx.rect(cx-1.6*z,cy-.1*r,3.25*z,.55*r);
    ctx.strokeStyle=oc;ctx.lineWidth=3*u;ctx.stroke();
    const g=ctx.createLinearGradient(0,cy-r,0,cy+.5*r);g.addColorStop(0,tc);g.addColorStop(1,bc);ctx.fillStyle=g;ctx.fill();
    ctx.fillStyle='rgba(255,255,255,.75)';ctx.beginPath();ctx.ellipse(cx-.3*z,cy-.74*r,.34*r,.12*r,-.5,0,7);ctx.fill();
    ctx.strokeStyle='rgba(120,150,190,.2)';ctx.lineWidth=1.3*u;ctx.beginPath();ctx.moveTo(cx-1.1*z,cy+.28*r);ctx.quadraticCurveTo(cx-.6*z,cy+.12*r,cx-.1*z,cy+.3*r);ctx.moveTo(cx+.5*z,cy+.3*r);ctx.quadraticCurveTo(cx+1*z,cy+.14*r,cx+1.4*z,cy+.3*r);ctx.stroke();
  }
  ctx.globalAlpha=1;
}
export function bgMtn(L,off){
  ctx.lineJoin='round';ctx.lineCap='round';const far=L.k<.12;
  const hg=ctx.createLinearGradient(0,G-210*u,0,G);hg.addColorStop(0,'rgba(255,255,255,.3)');hg.addColorStop(.55,'rgba(255,255,255,.03)');hg.addColorStop(1,'rgba(255,255,255,.26)');
  for(const b of L.a)for(let n=0;n<2;n++){
    const bx=b.x-off+n*L.tw;if(bx>W||bx+b.w<0)continue;
    const w=b.w,h=b.h,sd=((b.w*13)|0)%7/7,P=bgPk.map((p,i)=>[bx+w*(p[0]+(i%3-1)*.012*sd),G-h*p[1]*(i&&i<13?1+Math.sin(i*5.3+sd*9)*.045:1)]),pk=P[6];
    ctx.beginPath();ctx.moveTo(P[0][0],G+2*u);for(const p of P)ctx.lineTo(p[0],p[1]);ctx.lineTo(P[13][0],G+2*u);ctx.closePath();ctx.fillStyle=L.col;ctx.fill();ctx.fillStyle=hg;ctx.fill();
    ctx.fillStyle='rgba(20,40,75,.3)';ctx.beginPath();ctx.moveTo(P[0][0],G);for(let i=1;i<=6;i++)ctx.lineTo(P[i][0],P[i][1]);ctx.lineTo(pk[0]+w*.01,G-h*.55);ctx.lineTo(pk[0]-w*.025,G-h*.3);ctx.lineTo(pk[0]+w*.02,G-h*.12);ctx.lineTo(pk[0]+w*.05,G);ctx.closePath();ctx.fill();
    ctx.lineWidth=(far?1:1.4)*u;ctx.strokeStyle='rgba(20,40,75,.2)';ctx.beginPath();for(const i of[2,4,5]){ctx.moveTo(P[i][0],P[i][1]+2*u);ctx.quadraticCurveTo(P[i][0]+w*.03,(P[i][1]+G)/2,P[i][0]+w*.02*(i-3),G-h*.06)}ctx.stroke();
    ctx.strokeStyle='rgba(255,255,255,.24)';ctx.beginPath();for(const i of[8,10,11]){ctx.moveTo(P[i][0],P[i][1]+2*u);ctx.quadraticCurveTo(P[i][0]-w*.02,(P[i][1]+G)/2,P[i][0]-w*.05,G-h*.08)}ctx.stroke();
    if(!far){ctx.strokeStyle='rgba(20,40,75,.16)';ctx.lineWidth=1*u;ctx.beginPath();for(let k=0;k<5;k++){const hx=P[3][0]+w*.02+k*w*.045,hy=G-h*(.42-k*.05);ctx.moveTo(hx,hy);ctx.lineTo(hx-w*.03,hy+h*.08)}ctx.stroke()}
    ctx.strokeStyle='rgba(15,35,70,'+(far?.22:.32)+')';ctx.lineWidth=(far?1.4:1.8)*u;ctx.beginPath();P.forEach((p,i)=>i?ctx.lineTo(p[0],p[1]):ctx.moveTo(p[0],p[1]));ctx.stroke();
    const cap=(lv,al)=>{let lx=0,ly=0,rx=0,ry=0;
      for(let i=0;i<13;i++){const a=bgPk[i][1],c=bgPk[i+1][1];if(a<lv&&c>=lv){const k=(lv-a)/(c-a);lx=P[i][0]+(P[i+1][0]-P[i][0])*k;ly=P[i][1]+(P[i+1][1]-P[i][1])*k}else if(a>=lv&&c<lv){const k=(a-lv)/(a-c);rx=P[i][0]+(P[i+1][0]-P[i][0])*k;ry=P[i][1]+(P[i+1][1]-P[i][1])*k}}
      ctx.beginPath();ctx.moveTo(lx,ly);for(let i=0;i<=13;i++)if(bgPk[i][1]>=lv)ctx.lineTo(P[i][0],P[i][1]);ctx.lineTo(rx,ry);
      for(let k=1;k<=5;k++){const f=k/5;ctx.lineTo(rx+(lx-rx)*f,ry+(ly-ry)*f+(k%2?1:-.4)*h*.07)}
      ctx.closePath();ctx.fillStyle='rgba(244,248,251,'+al+')';ctx.fill();
      ctx.fillStyle='rgba(120,150,205,'+(al*.45).toFixed(2)+')';ctx.beginPath();ctx.moveTo(pk[0],pk[1]);for(let i=5;i>=0;i--)if(bgPk[i][1]>=lv)ctx.lineTo(P[i][0],P[i][1]);ctx.lineTo(lx,ly);ctx.lineTo(lx+(rx-lx)*.42,ly+h*.05);ctx.lineTo(pk[0]+w*.02,pk[1]+(ly-pk[1])*.55);ctx.closePath();ctx.fill();
      ctx.strokeStyle='rgba(40,70,120,'+(al*.3).toFixed(2)+')';ctx.lineWidth=1.1*u;ctx.beginPath();ctx.moveTo(lx,ly);for(let k=1;k<=5;k++){const f=k/5;ctx.lineTo(lx+(rx-lx)*f,ly+(ry-ly)*f+(k%2?-.4:1)*h*.07)}ctx.stroke()};
    if(h>110*u)cap(.82,1);if(state.bw>0)cap(.58,state.bw.toFixed(2));
  }
}
export function bgHill(L){
  ctx.lineJoin='round';ctx.lineCap='round';const ys=[],wl=state.dist*L.k;
  for(let x=0;x<=W+10;x+=10){const w=x+wl;ys.push(G-(L.base+L.amp*(Math.sin(w/(L.wl*u))+.5*Math.sin(w/(L.wl*.43*u)+2)))*u)}
  const top=x=>{const f=Math.max(0,Math.min(ys.length-1.001,x/10)),i=f|0;return ys[i]+(ys[i+1]-ys[i])*(f-i)};
  ctx.beginPath();ctx.moveTo(0,state.hb);ys.forEach((y,i)=>ctx.lineTo(i*10,y));ctx.lineTo(W+10,state.hb);ctx.closePath();ctx.fillStyle=L.col;ctx.fill();
  const hg=ctx.createLinearGradient(0,G-(L.base+L.amp*1.6)*u,0,G);hg.addColorStop(0,'rgba(255,255,255,.26)');hg.addColorStop(1,'rgba(255,255,255,0)');ctx.fillStyle=hg;ctx.fill();
  ctx.strokeStyle='rgba(255,255,255,.22)';ctx.lineWidth=2.2*u;ctx.beginPath();ys.forEach((y,i)=>i?ctx.lineTo(i*10,y+3*u):ctx.moveTo(0,y+3*u));ctx.stroke();
  ctx.strokeStyle='rgba(20,50,35,.32)';ctx.lineWidth=1.8*u;ctx.beginPath();ys.forEach((y,i)=>i?ctx.lineTo(i*10,y):ctx.moveTo(0,y));ctx.stroke();
  const c=(L.base>60?64:44)*u,sc=L.k*3.4,bc=lc('#4a8a4f','#a9bfd4',state.bw),tcl=lc('#3f7f45','#cfe0ee',state.bw);
  for(let n=Math.floor(wl/c);n<=Math.floor((wl+W+c)/c)+1;n++){
    const x=n*c-wl+bgH(n,L.base)*c*.7,v=bgH(n,3+L.base);if(x<-30*u||x>W+30*u||v>.62)continue;const y=top(x)+1*u;
    if(v<.34){ctx.beginPath();for(const[a,b,r]of[[-5,-3,5],[1,-5,6.4],[6,-2.5,4.6]]){ctx.moveTo(x+(a+r)*sc*u,y+b*sc*u);ctx.arc(x+a*sc*u,y+b*sc*u,r*sc*u,0,7)}
      ctx.strokeStyle='rgba(15,40,25,.34)';ctx.lineWidth=2.6*u;ctx.stroke();ctx.fillStyle=bc;ctx.fill();
      ctx.fillStyle='rgba(255,255,255,.25)';ctx.beginPath();ctx.ellipse(x-1*sc*u,y-8*sc*u,3.2*sc*u,1.6*sc*u,-.4,0,7);ctx.fill();
      if(state.bw>0){ctx.fillStyle='rgba(255,255,255,'+(state.bw*.92).toFixed(2)+')';ctx.beginPath();ctx.ellipse(x+1*sc*u,y-9.8*sc*u,5.2*sc*u,2.2*sc*u,0,0,7);ctx.fill()}}
    else if(v<.48){const s=Math.sin(t*2+n)*.8*u;
      if(state.bw<.999){ctx.globalAlpha=1-state.bw;for(let k=0;k<4;k++){const fx=x+(k-1.5)*3.4*sc*u,fy=y-(1.5+k%2*2)*sc*u;BST('#4f9a56',1.2,fx,y,fx+s*.3,(y+fy)/2,fx+s*.5,fy);wdot(fx+s*.5,fy,1.5*sc*u,['#ffe066','#ff8fa3','#ffffff','#b69cff'][k])}ctx.globalAlpha=1}
      if(state.bw>.001){ctx.globalAlpha=state.bw;const r=sc*u,sw=Math.sin(t*1.4+n)*.5*u;ctx.lineJoin='round';ctx.lineCap='round';
        if(bgH(n,7)<.5){const T=[[-1,7],[-.4,10],[.15,11],[.65,9],[1.1,6.5]];ctx.strokeStyle='rgba(60,82,128,.8)';ctx.lineWidth=Math.max(1,1.3*sc)*u;ctx.beginPath();for(const[a,L]of T){ctx.moveTo(x,y);ctx.quadraticCurveTo(x+Math.sin(a)*L*.15*r,y-L*.6*r,x+Math.sin(a)*L*r+sw*L/10,y-Math.cos(a)*L*r)}ctx.stroke();
          ctx.fillStyle='#fff';ctx.strokeStyle='rgba(40,64,110,.34)';ctx.lineWidth=1.1*u;ctx.beginPath();for(const[a,L]of T){const ex=x+Math.sin(a)*L*r+sw*L/10,ey=y-Math.cos(a)*L*r-.8*r;ctx.moveTo(ex+2.6*r,ey);ctx.ellipse(ex,ey,2.6*r,1.9*r,0,0,7)}ctx.moveTo(x+5*r,y);ctx.ellipse(x,y,5*r,1.7*r,0,0,7);ctx.fill();ctx.stroke()}
        else{const C=[[-6,-1.5,-3.6,9],[-2.5,3.5,.5,15],[1.8,6.6,4.4,10.5]];ctx.fillStyle='#d4f0ff';ctx.strokeStyle='rgba(40,64,110,.34)';ctx.lineWidth=1.1*u;ctx.beginPath();for(const[a,b,p,h]of C){ctx.moveTo(x+a*r,y);ctx.lineTo(x+p*r,y-h*r);ctx.lineTo(x+b*r,y);ctx.closePath()}ctx.fill();ctx.stroke();
          ctx.fillStyle='rgba(40,100,180,.3)';ctx.beginPath();for(const[a,b,p,h]of C){ctx.moveTo(x+p*r,y-h*r);ctx.lineTo(x+b*r,y);ctx.lineTo(x+p*r,y)}ctx.fill();ctx.fillStyle='#fff';ctx.beginPath();ctx.moveTo(x+7*r,y);ctx.ellipse(x,y,7*r,1.7*r,0,0,7);ctx.fill();ctx.stroke();obSpk(x+.5*r,y-15.6*r,n*1.4)}
        ctx.globalAlpha=1}}
    else{const s=Math.sin(t*1.6+n)*.7*u,tr=sc*u;BST('rgba(0,0,0,.3)',3.4*sc,x,y,x,y-6*tr,x+s*.3,y-10*tr);BST('#5a3f2b',2*sc,x,y,x,y-6*tr,x+s*.3,y-10*tr);
      ctx.beginPath();ctx.moveTo(x+s+8*tr,y-14*tr);ctx.arc(x+s,y-14*tr,8*tr,0,7);ctx.moveTo(x+s+5*tr+5*tr,y-10*tr);ctx.arc(x+s+5*tr,y-10*tr,5*tr,0,7);ctx.strokeStyle='rgba(15,40,25,.34)';ctx.lineWidth=2.6*u;ctx.stroke();ctx.fillStyle=tcl;ctx.fill();
      ctx.fillStyle='rgba(255,255,255,.26)';ctx.beginPath();ctx.ellipse(x+s-2.4*tr,y-17*tr,3.4*tr,1.8*tr,-.5,0,7);ctx.fill()}
  }
}
export function bgPine(L,off){
  ctx.lineJoin='round';ctx.lineCap='round';
  for(const b of L.a)for(let n=0;n<2;n++){
    const bx=b.x-off+n*L.tw;if(bx>W||bx+b.w<0)continue;
    const hh=b.h,ww=b.w*1.25,ax=bx+b.w/2;
    ctx.fillStyle='#4a3626';ctx.fillRect(ax-ww*.06,G-hh*.2,ww*.12,hh*.22);
    for(let q=0;q<3;q++){
      const yb=G-hh*(.16+q*.26),yt=yb-hh*(.42-q*.02),hw=ww*.5*(1-q*.26);
      ctx.beginPath();ctx.moveTo(ax,yt);ctx.lineTo(ax+hw,yb);for(let s=0;s<3;s++)ctx.quadraticCurveTo(ax+hw-(s+.5)*hw*2/3,yb+hh*.07,ax+hw-(s+1)*hw*2/3,yb);ctx.closePath();
      ctx.fillStyle=L.col;ctx.fill();ctx.strokeStyle='rgba(0,28,22,.34)';ctx.lineWidth=1.4*u;ctx.stroke();
      ctx.fillStyle='rgba(0,25,20,.2)';ctx.beginPath();ctx.moveTo(ax,yt);ctx.lineTo(ax-hw,yb);ctx.lineTo(ax,yb+hh*.04);ctx.closePath();ctx.fill();
      ctx.strokeStyle='rgba(255,255,255,.16)';ctx.lineWidth=1*u;ctx.beginPath();ctx.moveTo(ax+hw*.12,yt+(yb-yt)*.25);ctx.lineTo(ax+hw*.5,yb-(yb-yt)*.12);ctx.stroke();
      if(state.bw>0){ctx.fillStyle='rgba(255,255,255,'+(state.bw*.93).toFixed(2)+')';ctx.beginPath();ctx.moveTo(ax,yt);ctx.lineTo(ax+hw*.64,yt+(yb-yt)*.64);ctx.quadraticCurveTo(ax+hw*.32,yt+(yb-yt)*.78,ax,yt+(yb-yt)*.68);ctx.quadraticCurveTo(ax-hw*.32,yt+(yb-yt)*.8,ax-hw*.64,yt+(yb-yt)*.64);ctx.closePath();ctx.fill()}
    }
  }
}
export function bgMist(){
  const M=W*1.5;
  for(let q=0;q<4;q++){const x=((q*W*.38-state.dist*.1*(1+q*.2)+t*5*u*(q%2?1:-.6))%M+M)%M-W*.25,y=G-(70+q*22)*u+Math.sin(t*.4+q)*3*u,rw=(110+q*30)*u;
    ctx.fillStyle=lc('#ffffff','#f4f9ff',state.bw,.13);ctx.beginPath();ctx.ellipse(x,y,rw,7*u,0,0,7);ctx.fill();ctx.fillStyle=lc('#ffffff','#f4f9ff',state.bw,.1);ctx.beginPath();ctx.ellipse(x+rw*.25,y-4*u,rw*.6,5*u,0,0,7);ctx.fill()}
}
