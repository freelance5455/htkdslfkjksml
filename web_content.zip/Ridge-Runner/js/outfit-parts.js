/*
 * outfit-parts.js - Shared outfit drawing parts (tails, fur, bands, ribbons, gradients) and the outfit-kind registries WK / BK / MO.
 */
import { t } from './clock.js';
import { wol } from './draw-utils.js';
import { state } from './state.js';
import { ctx, px, u } from './view.js';

/* ---- Winter outfits: hand-drawn hats, ears, antlers, scarves and tails ---- */
export const WK={santa:1,snowman:1,reindeer:1,penguin:1,polar:1,elf:1,ginger:1,yeti:1,fox:1};
export const wtri=(a,b,c,d,e,f)=>{ctx.beginPath();ctx.moveTo(a,b);ctx.lineTo(c,d);ctx.lineTo(e,f);ctx.closePath()};
export const wtl=()=>Math.max(-7*u,Math.min(8*u,state.vy*.014));
export function wfur(x0,x1,yy,r,c,sh){const n=Math.max(2,Math.round((x1-x0)/(r*1.3)));for(let p=0;p<2;p++)for(let i=0;i<=n;i++){ctx.fillStyle=p?c:sh;ctx.beginPath();ctx.arc(x0+(x1-x0)*i/n,yy+(i%2?r*.22:0)+(p?0:1.4*u),r,0,7);ctx.fill()}}
export function wband(c1,c2,y0,h){
  const x=px,S=34*u;
  ctx.fillStyle=c1;ctx.fillRect(x-2*u,y0,S+4*u,h);
  ctx.fillStyle=c2;for(let q=-1;q<7;q++){const sx=x+q*6.4*u;ctx.beginPath();ctx.moveTo(sx,y0);ctx.lineTo(sx+3*u,y0);ctx.lineTo(sx+1*u,y0+h);ctx.lineTo(sx-2*u,y0+h);ctx.closePath();ctx.fill()}
  ctx.fillStyle='rgba(255,255,255,.28)';ctx.fillRect(x-2*u,y0,S+4*u,1.3*u);
  ctx.fillStyle='rgba(0,0,0,.2)';ctx.fillRect(x-2*u,y0+h-1.5*u,S+4*u,1.5*u);
}
export function wrib(c1,c2,y0,len,wd,fr){
  const x=px+3*u,a=Math.sin(t*9)*2.6*u,d=wtl();
  const P=()=>{ctx.beginPath();ctx.moveTo(x,y0);ctx.bezierCurveTo(x-len*.35,y0-2*u+a*.5+d*.4,x-len*.7,y0+3*u+a+d*.8,x-len,y0+1*u+a*1.3+d);ctx.lineTo(x-len+1.5*u,y0+wd+1*u+a*1.3+d);ctx.bezierCurveTo(x-len*.7,y0+wd+4*u+a+d*.8,x-len*.35,y0+wd-1*u+a*.5+d*.4,x,y0+wd);ctx.closePath()};
  P();ctx.fillStyle=c1;ctx.fill();
  ctx.save();P();ctx.clip();ctx.fillStyle=c2;for(let q=1;q<4;q++)ctx.fillRect(x-len*q/3.6-1.6*u,y0-8*u,3.2*u,wd+22*u);ctx.restore();
  P();wol(1.4);
  /* hand-drawn sheen on the upper edge, fold shade underneath, optional knotted fringe */
  ctx.save();P();ctx.clip();
  const E=o=>{ctx.beginPath();ctx.moveTo(x,y0+o);ctx.bezierCurveTo(x-len*.35,y0-2*u+a*.5+d*.4+o,x-len*.7,y0+3*u+a+d*.8+o,x-len,y0+1*u+a*1.3+d+o)};
  E(1.5*u);ctx.strokeStyle='rgba(255,255,255,.4)';ctx.lineWidth=1.1*u;ctx.stroke();
  E(wd-1.7*u);ctx.strokeStyle='rgba(30,10,40,.2)';ctx.lineWidth=1.5*u;ctx.stroke();
  ctx.restore();
  if(fr){ctx.strokeStyle=fr;ctx.lineWidth=1.3*u;ctx.lineCap='round';ctx.beginPath();for(let q=0;q<4;q++){const fy=y0+1*u+wd*(q+.5)/4+a*1.3+d,sw=Math.sin(t*10+q)*.8*u;ctx.moveTo(x-len+1*u,fy);ctx.quadraticCurveTo(x-len-2*u,fy+1*u+sw,x-len-4.5*u,fy+2.2*u+sw)}ctx.stroke()}
}
/* ---- Base outfits: hand-drawn like the winter set (behind / on / in front of the body) ---- */
export const BK={classic:1,astro:1,dragon:1,ninja:1,robot:1,knight:1,wizard:1,cat:1,fire:1,ice:1,fairy:1,tribe:1,golem:1,forest:1,bear:1};
Object.assign(WK,BK);
export const BFL=(cx,by,w,h,c,s)=>{ctx.fillStyle=c;ctx.beginPath();ctx.moveTo(cx-w,by);ctx.quadraticCurveTo(cx-w*.9,by-h*.5,cx+s,by-h);ctx.quadraticCurveTo(cx+w*.9,by-h*.5,cx+w,by);ctx.closePath();ctx.fill()};
export const BGL=(x0,y0,x1,y1,a,b)=>{const g=ctx.createLinearGradient(x0,y0,x1,y1);g.addColorStop(0,a);g.addColorStop(1,b);return g};
/* ---- Mangrove outfits (Sundarbans wildlife and people). Registered in WK so the default scarf tail is skipped; drawn in three layers like the Winter set ---- */
export const MO={sundari:1,tiger:1,chital:1,crab:1,mudskip:1,kingfisher:1,croc:1,boatman:1};
Object.assign(WK,MO);
