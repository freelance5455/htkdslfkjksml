/*
 * obstacles.js - Hand-drawn obstacles: snow, ice cave, meadow, cave, flyers and ponds.
 */
import { t } from './clock.js';
import { BOV, BPG, BSP, BST, obCry, obSpk, rr, wdot, wlg, wol } from './draw-utils.js';
import { ctx, G, u } from './view.js';

export function pondDraw(o){obPond(o)}
export function gob(o){obIce(o)}
export function nat(o){obNat(o)}
export function drone(o){obFly(o)}
export function snw(o){obSnow(o)}
function obSnow(o){
  const x=o.x,w=o.w,h=o.h,b=G,cx=x+w/2;ctx.lineJoin='round';ctx.lineCap='round';
  if(w>60*u){
    const dx=cx-w*.06,dome=()=>{ctx.beginPath();ctx.ellipse(dx,b,w*.4,h,0,Math.PI,0);ctx.closePath()};
    ctx.fillStyle='#f4faff';ctx.beginPath();ctx.ellipse(cx,b,w*.52,3.2*u,0,0,7);ctx.fill();
    ctx.fillStyle=wlg(b-h,b,'#ffffff','#bcd6ee');dome();ctx.fill();
    ctx.save();dome();ctx.clip();ctx.strokeStyle='rgba(70,110,165,.42)';ctx.lineWidth=1.3*u;
    for(let r=0;r<4;r++){const yy=b-h*r*.26;if(r){ctx.beginPath();ctx.moveTo(x,yy);ctx.quadraticCurveTo(dx,yy+3*u,x+w,yy);ctx.stroke()}ctx.beginPath();for(let k=0;k<6;k++){const jx=x+w*(.1+k*.15+(r%2)*.07);ctx.moveTo(jx,yy);ctx.lineTo(jx,yy-h*.26)}ctx.stroke()}
    const sg=ctx.createLinearGradient(x,0,x+w,0);sg.addColorStop(0,'rgba(255,255,255,0)');sg.addColorStop(.55,'rgba(255,255,255,0)');sg.addColorStop(1,'rgba(70,100,160,.38)');ctx.fillStyle=sg;ctx.fillRect(x,b-h,w,h);
    ctx.fillStyle='rgba(255,255,255,.7)';ctx.beginPath();ctx.ellipse(dx-w*.16,b-h*.66,w*.1,h*.1,-.6,0,7);ctx.fill();ctx.restore();
    dome();wol(1.7);
    ctx.fillStyle=wlg(b-h*.46,b,'#f4faff','#b3cde6');rr(x+w*.6,b-h*.46,w*.38,h*.46,h*.2);ctx.fill();wol(1.5);
    const ax=x+w*.79,aw=w*.095;ctx.fillStyle='#233352';ctx.beginPath();ctx.moveTo(ax-aw,b);ctx.lineTo(ax-aw,b-h*.2);ctx.arc(ax,b-h*.2,aw,Math.PI,0);ctx.lineTo(ax+aw,b);ctx.closePath();ctx.fill();
    ctx.fillStyle='rgba(255,196,90,'+(.55+.15*Math.sin(t*5+x*.02)).toFixed(2)+')';ctx.beginPath();ctx.ellipse(ax,b-h*.08,aw*.75,h*.13,0,0,7);ctx.fill();
    obSpk(x+w*.22,b-h*.72,x*.02);return}
  if(h>58*u){
    const r1=h*.255,r2=r1*.76,r3=r1*.55,y1=b-r1,y2=y1-(r1+r2)*.78,y3=y2-(r2+r3)*.78,sw=Math.sin(t*3+x*.01);
    const ball=(cy,r)=>{const g=ctx.createRadialGradient(cx-r*.35,cy-r*.4,r*.1,cx,cy,r*1.05);g.addColorStop(0,'#ffffff');g.addColorStop(.7,'#e6f0fa');g.addColorStop(1,'#b0c8e4');ctx.fillStyle=g;ctx.beginPath();ctx.arc(cx,cy,r,0,7);ctx.fill();wol(1.5)};
    ball(y1,r1);ball(y2,r2);
    BST('rgba(0,0,0,.3)',4.4,cx-r2*.85,y2,cx-r2*1.3,y2-r2*.3,cx-r2*1.55,y2-r2*.75);BST('#5a3f2b',2.6,cx-r2*.85,y2,cx-r2*1.3,y2-r2*.3,cx-r2*1.55,y2-r2*.75);BST('#5a3f2b',1.8,cx-r2*1.3,y2-r2*.45,cx-r2*1.45,y2-r2*.45,cx-r2*1.75,y2-r2*.35);
    BST('rgba(0,0,0,.3)',4.4,cx+r2*.85,y2,cx+r2*1.3,y2-r2*.1,cx+r2*1.55,y2-r2*.5-sw*2*u);BST('#5a3f2b',2.6,cx+r2*.85,y2,cx+r2*1.3,y2-r2*.1,cx+r2*1.55,y2-r2*.5-sw*2*u);
    for(let q=0;q<2;q++)wdot(cx-r2*.1,y2-r2*.2+q*r2*.6,1.7*u,'#10152e');
    ball(y3,r3);
    ctx.fillStyle='#d62839';rr(cx-r3*.95,y3+r3*.68,r3*1.9,3.6*u,1.6*u);ctx.fill();wol(1.2);ctx.fillStyle='rgba(255,255,255,.55)';ctx.fillRect(cx-r3*.5,y3+r3*.68,1.6*u,3.6*u);ctx.fillRect(cx+r3*.2,y3+r3*.68,1.6*u,3.6*u);
    BPG('#d62839',cx+r3*.5,y3+r3*.9,cx+r3*1.3+sw*u,y3+r3*.9+8*u,cx+r3*.9,y3+r3*.9+9*u);
    ctx.fillStyle='#2b2433';rr(cx-r3*1.0,y3-r3*.85,r3*2,3*u,1.4*u);ctx.fill();wol(1.3);rr(cx-r3*.58,y3-r3*.85-11*u,r3*1.16,11*u,2*u);ctx.fill();wol(1.3);ctx.fillStyle='#d62839';ctx.fillRect(cx-r3*.58,y3-r3*.85-4.4*u,r3*1.16,3*u);ctx.fillStyle='rgba(255,255,255,.2)';ctx.fillRect(cx-r3*.4,y3-r3*.85-10*u,1.6*u,8*u);
    wdot(cx-r3*.3,y3-r3*.1,1.7*u,'#10152e');wdot(cx-r3*.75,y3-r3*.1,1.7*u,'#10152e');wdot(cx-r3*.3-.5*u,y3-r3*.1-.6*u,.6*u,'#fff');
    for(let q=0;q<3;q++)wdot(cx-r3*.95+q*r3*.34,y3+r3*.38-Math.abs(q-1)*.8*u,.9*u,'#10152e');
    ctx.fillStyle='rgba(255,120,140,.35)';ctx.beginPath();ctx.arc(cx-r3*.15,y3+r3*.25,2.4*u,0,7);ctx.fill();
    BPG('#ff8f3a',cx-r3*.5,y3+r3*.02,cx-r3*.5-11*u,y3+r3*.34,cx-r3*.5,y3+r3*.4);
    obSpk(cx+r1*.7,y1-r1*.7,x*.03);return}
  if(((w*7)|0)%2){
    ctx.fillStyle='rgba(150,230,255,'+(.16+.08*Math.sin(t*2+x*.02)).toFixed(2)+')';ctx.beginPath();ctx.arc(cx,b-h*.4,h*.7,0,7);ctx.fill();
    for(const[a,c,d,e,col]of[[.04,.4,.22,.72,'#9fe3ff'],[.58,.96,.78,.56,'#9fe3ff'],[.28,.72,.5,1,'#c8f1ff']])obCry(x+w*a,x+w*c,x+w*d,b-h*e,b,col);
    BOV(cx,b,w*.5,4*u,'#fff');obSpk(x+w*.5,b-h*.9,x*.02);return}
  ctx.fillStyle=wlg(b-h,b,'#8fb4d6','#4a6f95');ctx.beginPath();ctx.moveTo(x,b);ctx.lineTo(x+w*.1,b-h*.6);ctx.lineTo(x+w*.4,b-h);ctx.lineTo(x+w*.8,b-h*.85);ctx.lineTo(x+w,b-h*.3);ctx.lineTo(x+w,b);ctx.closePath();ctx.fill();wol(1.6);
  ctx.fillStyle='rgba(255,255,255,.2)';ctx.beginPath();ctx.moveTo(x+w*.1,b-h*.6);ctx.lineTo(x+w*.4,b-h);ctx.lineTo(x+w*.55,b-h*.5);ctx.closePath();ctx.fill();
  ctx.strokeStyle='rgba(30,50,80,.45)';ctx.lineWidth=1.2*u;ctx.beginPath();ctx.moveTo(x+w*.3,b);ctx.lineTo(x+w*.36,b-h*.3);ctx.lineTo(x+w*.3,b-h*.45);ctx.stroke();
  BPG('#f2faff',x+w*.1,b-h*.6,x+w*.4,b-h,x+w*.8,b-h*.85,x+w*.88,b-h*.68,x+w*.6,b-h*.74,x+w*.42,b-h*.64,x+w*.26,b-h*.74);
  for(const a of[.5,.64,.78])BPG('#cfeeff',x+w*a-2.2*u,b-h*.72,x+w*a,b-h*(.46+(a*10|0)%3*.04),x+w*a+2.2*u,b-h*.72);
  obSpk(x+w*.4,b-h*.95,x*.02);
}
function obIce(o){
  const x=o.x,w=o.w,h=o.h,b=G,cx=x+w/2;ctx.lineJoin='round';ctx.lineCap='round';
  if(w>60*u){
    const sl=()=>{ctx.beginPath();ctx.moveTo(x,b);ctx.lineTo(x+w*.03,b-h*.5);ctx.quadraticCurveTo(x+w*.2,b-h*.78,x+w*.45,b-h*.62);ctx.quadraticCurveTo(x+w*.75,b-h*.72,x+w*.97,b-h*.42);ctx.lineTo(x+w,b);ctx.closePath()};
    ctx.fillStyle=wlg(b-h*.8,b,'#c9efff','#3f8fc4');sl();ctx.fill();
    ctx.save();sl();ctx.clip();ctx.fillStyle='rgba(160,235,255,'+(.22+.12*Math.sin(t*2.4+x*.02)).toFixed(2)+')';ctx.beginPath();ctx.ellipse(x+w*.5,b-h*.35,w*.32,h*.22,0,0,7);ctx.fill();
    ctx.strokeStyle='rgba(255,255,255,.65)';ctx.lineWidth=1.3*u;ctx.beginPath();ctx.moveTo(x+w*.1,b-h*.1);ctx.lineTo(x+w*.25,b-h*.3);ctx.lineTo(x+w*.2,b-h*.46);ctx.moveTo(x+w*.62,b-h*.06);ctx.lineTo(x+w*.74,b-h*.28);ctx.lineTo(x+w*.82,b-h*.4);ctx.stroke();ctx.restore();
    sl();wol(1.6);
    for(const[a,c,d,e]of[[.08,.32,.18,.95],[.4,.64,.5,1],[.7,.92,.8,.82]])obCry(x+w*a,x+w*c,x+w*d,b-h*e,b-h*.42,a===.4?'#d6f3ff':'#cdeeff');
    ctx.fillStyle='rgba(255,255,255,.55)';ctx.beginPath();ctx.ellipse(x+w*.5,b-h*.6,w*.16,2*u,0,0,7);ctx.fill();obSpk(x+w*.5,b-h*1.02,x*.02);return}
  if(h>58*u){
    for(const[a,hh]of[[-.28,.4],[1.02,.32]])obCry(x+w*a-6*u,x+w*a+12*u,x+w*a+3*u,b-h*hh,b,'#8fd0f0');
    ctx.fillStyle=wlg(b-h,b,'#e3f8ff','#3f95cc');ctx.beginPath();ctx.moveTo(x,b);ctx.lineTo(x+w*.2,b-h*.55);ctx.lineTo(x+w*.5,b-h);ctx.lineTo(x+w*.8,b-h*.5);ctx.lineTo(x+w,b);ctx.closePath();ctx.fill();wol(1.7);
    ctx.fillStyle='rgba(30,100,170,.38)';ctx.beginPath();ctx.moveTo(x+w*.5,b-h);ctx.lineTo(x+w,b);ctx.lineTo(x+w*.5,b);ctx.closePath();ctx.fill();
    ctx.strokeStyle='rgba(255,255,255,.85)';ctx.lineWidth=2*u;ctx.beginPath();ctx.moveTo(x+w*.36,b-h*.62);ctx.lineTo(x+w*.46,b-h*.9);ctx.stroke();
    ctx.strokeStyle='rgba(30,100,170,.3)';ctx.lineWidth=1.1*u;ctx.beginPath();ctx.moveTo(x+w*.2,b-h*.55);ctx.lineTo(x+w*.5,b-h*.3);ctx.lineTo(x+w*.8,b-h*.5);ctx.stroke();
    const gl=.5+.5*Math.sin(t*4+x*.02);ctx.fillStyle='rgba(180,240,255,'+(.2+.2*gl).toFixed(2)+')';ctx.beginPath();ctx.arc(cx,b-h+3*u,6*u,0,7);ctx.fill();
    ctx.fillStyle='rgba(255,255,255,'+(.5+.5*gl).toFixed(2)+')';ctx.beginPath();ctx.arc(cx,b-h+2*u,2.2*u,0,7);ctx.fill();return}
  if(((w*7)|0)%2){
    ctx.fillStyle='rgba(150,230,255,'+(.18+.1*Math.sin(t*2.2+x*.02)).toFixed(2)+')';ctx.beginPath();ctx.arc(cx,b-h*.4,h*.75,0,7);ctx.fill();
    for(const[a,c,d,e,col]of[[.02,.36,.18,.7,'#9fe3ff'],[.6,.98,.8,.55,'#b9a4ff'],[.28,.74,.5,1,'#c8f1ff']])obCry(x+w*a,x+w*c,x+w*d,b-h*e,b,col);
    BOV(cx,b,w*.5,4*u,'#fff');obSpk(x+w*.5,b-h*1.02,x*.02);return}
  ctx.fillStyle=wlg(b-h,b,'#8fb4d6','#3a5f86');ctx.beginPath();ctx.moveTo(x,b);ctx.lineTo(x+w*.1,b-h*.6);ctx.lineTo(x+w*.4,b-h);ctx.lineTo(x+w*.8,b-h*.85);ctx.lineTo(x+w,b-h*.3);ctx.lineTo(x+w,b);ctx.closePath();ctx.fill();wol(1.6);
  ctx.fillStyle='rgba(255,255,255,.2)';ctx.beginPath();ctx.moveTo(x+w*.1,b-h*.6);ctx.lineTo(x+w*.4,b-h);ctx.lineTo(x+w*.55,b-h*.5);ctx.closePath();ctx.fill();
  ctx.strokeStyle='rgba(120,235,255,'+(.5+.3*Math.sin(t*3+x*.02)).toFixed(2)+')';ctx.lineWidth=1.5*u;ctx.beginPath();ctx.moveTo(x+w*.45,b);ctx.lineTo(x+w*.52,b-h*.3);ctx.lineTo(x+w*.42,b-h*.5);ctx.lineTo(x+w*.5,b-h*.72);ctx.stroke();
  BPG('#f2faff',x+w*.1,b-h*.6,x+w*.4,b-h,x+w*.8,b-h*.85,x+w*.88,b-h*.68,x+w*.6,b-h*.74,x+w*.42,b-h*.64,x+w*.26,b-h*.74);obSpk(x+w*.4,b-h*.95,x*.02);
}
function obNat(o){
  const x=o.x,w=o.w,h=o.h,b=G,cx=x+w/2,sd=o.sd||(o.sd=Math.random()*6.28);ctx.lineJoin='round';ctx.lineCap='round';
  if(o.c){
    if(w>60*u){
      ctx.fillStyle=wlg(b-h*.3,b,'#5a4e44','#2a231d');rr(x,b-h*.3,w,h*.3,4*u);ctx.fill();wol(1.5);
      for(let q=0;q<3;q++){const c0=x+w*(.2+q*.3),pl=.12+.08*Math.sin(t*2.2+q*2);ctx.fillStyle='rgba('+(q===1?'170,140,255':'110,220,255')+','+pl.toFixed(2)+')';ctx.beginPath();ctx.arc(c0,b-h*.5,h*.55,0,7);ctx.fill();obCry(c0-w*.12,c0+w*.12,c0,b-h*(1.1-q%2*.35),b-h*.15,q===1?'#b48cff':'#7ee0ff')}
      return}
    if(h>58*u){
      ctx.fillStyle=wlg(b-h,b,'#8a7765','#4a3d31');ctx.beginPath();ctx.moveTo(x,b);ctx.lineTo(x+w*.45,b-h);ctx.lineTo(x+w,b);ctx.closePath();ctx.fill();wol(1.6);
      ctx.fillStyle='rgba(30,20,12,.42)';ctx.beginPath();ctx.moveTo(x+w*.45,b-h);ctx.lineTo(x+w,b);ctx.lineTo(x+w*.5,b);ctx.closePath();ctx.fill();
      ctx.strokeStyle='rgba(40,28,18,.45)';ctx.lineWidth=1.2*u;ctx.beginPath();for(let q=1;q<4;q++){const yy=b-h*q*.22,hw=w*.5*(1-q*.22);ctx.moveTo(x+w*.45-hw,yy);ctx.quadraticCurveTo(x+w*.45,yy+3*u,x+w*.45+hw,yy)}ctx.stroke();
      ctx.strokeStyle='rgba(255,235,200,.4)';ctx.lineWidth=1.6*u;ctx.beginPath();ctx.moveTo(x+w*.36,b-h*.62);ctx.lineTo(x+w*.43,b-h*.88);ctx.stroke();
      const ph=(t*.9+sd)%1,dy=b-h-24*u+ph*ph*24*u;ctx.fillStyle='rgba(150,225,255,'+(.9-ph*.4).toFixed(2)+')';ctx.beginPath();ctx.moveTo(x+w*.45,dy-3.4*u);ctx.quadraticCurveTo(x+w*.45+2*u,dy,x+w*.45,dy+1.6*u);ctx.quadraticCurveTo(x+w*.45-2*u,dy,x+w*.45,dy-3.4*u);ctx.fill();return}
    ctx.fillStyle=wlg(b-h,b,'#6b5f52','#3a322a');ctx.beginPath();ctx.moveTo(x,b);ctx.lineTo(x+w*.12,b-h*.65);ctx.lineTo(x+w*.45,b-h);ctx.lineTo(x+w*.85,b-h*.8);ctx.lineTo(x+w,b);ctx.closePath();ctx.fill();wol(1.6);
    ctx.fillStyle='rgba(255,235,200,.16)';ctx.beginPath();ctx.moveTo(x+w*.12,b-h*.65);ctx.lineTo(x+w*.45,b-h);ctx.lineTo(x+w*.55,b-h*.5);ctx.closePath();ctx.fill();
    ctx.strokeStyle='rgba(110,225,255,'+(.4+.25*Math.sin(t*3+sd)).toFixed(2)+')';ctx.lineWidth=1.4*u;ctx.beginPath();ctx.moveTo(x+w*.6,b);ctx.lineTo(x+w*.55,b-h*.3);ctx.lineTo(x+w*.66,b-h*.5);ctx.stroke();
    for(const[a,r]of[[.28,1],[.42,.7]]){const mx=x+w*a,pl=.5+.3*Math.sin(t*2.6+a*9);ctx.fillStyle='rgba(120,230,255,'+(.18*pl).toFixed(2)+')';ctx.beginPath();ctx.arc(mx,b-h*.16*r-3*u,6*u*r,0,7);ctx.fill();BST('#cfd8e0',1.6*r,mx,b,mx-.4*u,b-2*u*r,mx,b-4*u*r);BOV(mx,b-4.6*u*r,3.2*u*r,2*u*r,'#7ee0ff');wdot(mx-1*u*r,b-5*u*r,.6*u*r,'#fff')}
    return}
  if(w>60*u){
    const lx=x+h*.28,lw=w-h*.28;
    ctx.fillStyle=wlg(b-h,b,'#b4703f','#6a3f1f');rr(lx,b-h,lw,h,h*.32);ctx.fill();wol(1.6);
    ctx.save();rr(lx,b-h,lw,h,h*.32);ctx.clip();
    ctx.strokeStyle='rgba(50,25,8,.5)';ctx.lineWidth=1.3*u;ctx.beginPath();for(let q=1;q<4;q++){const yy=b-h*q*.25;ctx.moveTo(lx+h*.2,yy);ctx.quadraticCurveTo(lx+w*.35,yy+2*u,lx+w*.55,yy-1*u);ctx.quadraticCurveTo(lx+w*.7,yy-2*u,x+w,yy+1*u)}ctx.stroke();
    ctx.fillStyle='rgba(255,220,170,.28)';ctx.beginPath();ctx.ellipse(x+w*.55,b-h*.82,w*.3,h*.09,0,0,7);ctx.fill();BOV(x+w*.66,b-h*.42,3.4*u,2.4*u,'#5a3419');ctx.restore();
    BOV(x+h*.3,b-h/2,h*.22,h*.5,'#e2b57e');ctx.strokeStyle='#a77547';ctx.lineWidth=1.1*u;for(const k of[.65,.35]){ctx.beginPath();ctx.ellipse(x+h*.3,b-h/2,h*.22*k,h*.5*k,0,0,7);ctx.stroke()}wdot(x+h*.3,b-h/2,1.2*u,'#8a5a30');
    for(const[a,r]of[[.3,5],[.58,6.5],[.82,5]])BOV(x+w*a,b-h+1*u,r*u,2.4*u,'#5aa65f');
    BST('#2f7a3f',1.4,x+w*.35,b-h,x+w*.35+1*u,b-h-3*u,x+w*.35+2*u,b-h-5*u);
    const mx=x+w*.58;BST('#f3e6d2',2.2,mx,b-h,mx,b-h-2*u,mx,b-h-4*u);BOV(mx,b-h-5*u,3.8*u,2.4*u,'#d62839');wdot(mx-1.4*u,b-h-5.4*u,.7*u,'#fff');wdot(mx+1.2*u,b-h-4.8*u,.6*u,'#fff');return}
  if(h>58*u){
    const sw=Math.sin(t*2+x*.01)*1.2*u,tg=ctx.createLinearGradient(x+w*.2,0,x+w*.8,0);tg.addColorStop(0,'#7a5a40');tg.addColorStop(1,'#4a3322');
    ctx.fillStyle=tg;ctx.beginPath();ctx.moveTo(x+w*.18,b);ctx.lineTo(x+w*.33,b-h*.5);ctx.lineTo(x+w*.36,b-h*.97);ctx.lineTo(x+w*.5,b-h);ctx.lineTo(x+w*.66,b-h*.92);ctx.lineTo(x+w*.67,b-h*.5);ctx.lineTo(x+w*.82,b);ctx.closePath();ctx.fill();wol(1.6);
    ctx.strokeStyle='rgba(30,18,10,.45)';ctx.lineWidth=1.2*u;ctx.beginPath();for(const a of[.42,.55]){ctx.moveTo(x+w*a,b-h*.1);ctx.lineTo(x+w*(a-.02),b-h*.5);ctx.lineTo(x+w*(a+.01),b-h*.85)}ctx.stroke();
    const br=(a,b1,c,d,e,f)=>{BST('rgba(0,0,0,.35)',5.2,a,b1,c,d,e,f);BST('#5a3f2b',3.4,a,b1,c,d,e,f)};
    br(x+w*.6,b-h*.66,x+w*.85,b-h*.78,x+w,b-h*.95);br(x+w*.88,b-h*.82,x+w,b-h*.8,x+w*1.1,b-h*.86);br(x+w*.38,b-h*.46,x+w*.15,b-h*.6,x,b-h*.72);br(x+w*.1,b-h*.66,x-1*u,b-h*.7,x-5*u,b-h*.64);
    for(const[lx,ly,r]of[[x+w,b-h*.95,.2],[x+w*1.1,b-h*.86,-.4],[x,b-h*.72,.5]])BOV(lx+sw,ly+1*u,3*u,1.7*u,'#e0a030',r+sw*.1);
    ctx.fillStyle='#1a0f08';ctx.beginPath();ctx.ellipse(cx,b-h*.3,3.4*u,4.6*u,0,0,7);ctx.fill();
    if((t+sd)%4>.18){wdot(cx-1.3*u,b-h*.3-1*u,.9*u,'#ffe08a');wdot(cx+1.5*u,b-h*.3-1*u,.9*u,'#ffe08a')}return}
  ctx.fillStyle=wlg(b-h,b,'#aab0ba','#5f6672');ctx.beginPath();ctx.moveTo(x,b);ctx.lineTo(x+w*.1,b-h*.6);ctx.lineTo(x+w*.4,b-h);ctx.lineTo(x+w*.8,b-h*.85);ctx.lineTo(x+w,b-h*.3);ctx.lineTo(x+w,b);ctx.closePath();ctx.fill();wol(1.6);
  ctx.fillStyle='rgba(255,255,255,.22)';ctx.beginPath();ctx.moveTo(x+w*.1,b-h*.6);ctx.lineTo(x+w*.4,b-h);ctx.lineTo(x+w*.55,b-h*.5);ctx.closePath();ctx.fill();
  ctx.strokeStyle='rgba(30,35,45,.4)';ctx.lineWidth=1.2*u;ctx.beginPath();ctx.moveTo(x+w*.62,b);ctx.lineTo(x+w*.68,b-h*.35);ctx.lineTo(x+w*.6,b-h*.55);ctx.stroke();
  ctx.fillStyle='#5fae63';ctx.beginPath();ctx.ellipse(x+w*.3,b-h*.9,w*.24,h*.1,-.2,0,7);ctx.fill();wol(1.2);
  const sw=Math.sin(t*3+x*.02)*1.2*u;for(const a of[.04,.14,.9]){BST('#4f9a56',1.5,x+w*a,b,x+w*a+sw*.4,b-3*u,x+w*a+sw,b-6*u);BST('#4f9a56',1.5,x+w*a+2*u,b,x+w*a+2*u,b-2*u,x+w*a+3*u+sw,b-4*u)}
  BST('#2f7a3f',1.2,x+w*.28,b-h*.92,x+w*.28,b-h*.92-3*u,x+w*.28+sw,b-h*.92-6*u);for(let q=0;q<5;q++){const a=q*1.2566;BOV(x+w*.28+sw+Math.cos(a)*2.2*u,b-h*.92-7*u+Math.sin(a)*2.2*u,1.5*u,1.1*u,'#fff',a)}wdot(x+w*.28+sw,b-h*.92-7*u,1.2*u,'#ffd23f');
}
function obFly(o){
  const sd=o.sd||(o.sd=Math.random()*6.28),y0=G-o.f-o.h,lo=o.f<30*u,wf=Math.sin(t*(o.c?22:18)+sd),sn=o.b;ctx.lineJoin='round';ctx.lineCap='round';
  ctx.fillStyle=lo?'rgba(0,10,25,.4)':'rgba(0,10,25,.2)';ctx.beginPath();ctx.ellipse(o.x+o.w*.5,G+2*u,o.w*(lo?.45:.3),3*u,0,0,7);ctx.fill();
  if(o.c){
    const cx=o.x+o.w*.5,cy=y0+o.h*.55,gl=sn,col=gl?'#0a1c36':'#2b2233';
    if(gl){const rg=ctx.createRadialGradient(cx,cy,2*u,cx,cy,42*u);rg.addColorStop(0,'rgba(120,240,255,.8)');rg.addColorStop(.45,'rgba(110,235,255,.28)');rg.addColorStop(1,'rgba(110,235,255,0)');ctx.fillStyle=rg;ctx.beginPath();ctx.arc(cx,cy,42*u,0,7);ctx.fill()}
    const wing=sg=>{const sx=cx+sg*o.w*.06,tx=cx+sg*o.w*.58,ty=cy-o.h*.7*wf-4*u,ex=cx+sg*o.w*.24,ey=cy+o.h*.35,px1=(tx+ex)/2,py1=(ty+ey)/2+1*u;
      ctx.beginPath();ctx.moveTo(sx,cy-1*u);ctx.lineTo(tx,ty);ctx.quadraticCurveTo((tx+px1)/2+(sx-(tx+px1)/2)*.25,(ty+py1)/2+(cy-(ty+py1)/2)*.25,px1,py1);ctx.quadraticCurveTo((px1+ex)/2+(sx-(px1+ex)/2)*.25,(py1+ey)/2+(cy-(py1+ey)/2)*.25,ex,ey);ctx.lineTo(sx,cy+1*u);ctx.closePath();
      ctx.fillStyle=col;ctx.fill();if(gl){ctx.strokeStyle='#b8fbff';ctx.lineWidth=2.4*u;ctx.stroke()}else wol(1.4);
      ctx.strokeStyle=gl?'rgba(184,251,255,.5)':'rgba(255,255,255,.16)';ctx.lineWidth=1*u;ctx.beginPath();ctx.moveTo(sx,cy);ctx.lineTo(px1,py1);ctx.moveTo(sx,cy);ctx.lineTo(ex,ey);ctx.stroke()};
    wing(-1);wing(1);
    BPG(col,cx-4.4*u,cy-o.h*.26,cx-3.6*u,cy-o.h*.26-6*u,cx-.6*u,cy-o.h*.3);BPG(col,cx+.6*u,cy-o.h*.3,cx+3.6*u,cy-o.h*.26-6*u,cx+4.4*u,cy-o.h*.26);
    ctx.fillStyle=col;ctx.beginPath();ctx.ellipse(cx,cy,o.w*.14,o.h*.3,0,0,7);ctx.fill();if(gl){ctx.strokeStyle='#b8fbff';ctx.lineWidth=2.4*u;ctx.stroke()}else wol(1.4);
    const ec=gl?'#e6fdff':'#ff5d73',pl=.5+.5*Math.sin(t*6+sd);ctx.fillStyle=gl?'rgba(184,251,255,.25)':'rgba(255,93,115,.28)';ctx.beginPath();ctx.arc(cx-2.6*u,cy-2*u,(3.4+pl)*u,0,7);ctx.arc(cx+2.6*u,cy-2*u,(3.4+pl)*u,0,7);ctx.fill();
    wdot(cx-2.6*u,cy-2*u,1.9*u,ec);wdot(cx+2.6*u,cy-2*u,1.9*u,ec);BPG('#fff',cx-2.6*u,cy+o.h*.16,cx-1.6*u,cy+o.h*.16+3.2*u,cx-.6*u,cy+o.h*.16);BPG('#fff',cx+.6*u,cy+o.h*.16,cx+1.6*u,cy+o.h*.16+3.2*u,cx+2.6*u,cy+o.h*.16);
    for(let q=0;q<3;q++){const ph=(t*1.6+q*.33+sd)%1;BSP(cx+o.w*.3+ph*20*u,cy+Math.sin(ph*6+q)*3*u,2.4*u*(1-ph),gl?'rgba(184,251,255,'+(1-ph).toFixed(2)+')':'rgba(190,150,255,'+(.8*(1-ph)).toFixed(2)+')')}
    return}
  const bx=o.x+o.w*.58,by=y0+o.h*.62,hx=o.x+o.w*.28,hy=y0+o.h*.46,hr=o.h*.3,c0=sn?'#ffffff':'#6b5648',c1=sn?'#c9dbec':'#3b2d25',wc=sn?'#aac5e0':'#6b5648',wd=sn?'#8fb0d2':'#4a3b32';
  const wing=(ph,col,dx)=>{const sx=o.x+o.w*.42+dx,sy=y0+o.h*.52,tx=o.x+o.w*.74+dx,ty=y0-9*u*ph-3*u,rx=o.x+o.w*.98+dx,ry=y0+o.h*.58;
    ctx.beginPath();ctx.moveTo(sx,sy);ctx.quadraticCurveTo(sx+o.w*.12,ty+2*u,tx,ty);for(let k=1;k<=3;k++){const a=k/3,a0=(k-.5)/3;ctx.quadraticCurveTo(tx+(rx-tx)*a0+2*u,ty+(ry-ty)*a0+4*u,tx+(rx-tx)*a,ty+(ry-ty)*a)}ctx.lineTo(sx+o.w*.1,sy+o.h*.15);ctx.closePath();ctx.fillStyle=col;ctx.fill();wol(1.4);
    ctx.strokeStyle='rgba(0,0,0,.18)';ctx.lineWidth=1*u;ctx.beginPath();for(let k=1;k<=3;k++){const a=k/3;ctx.moveTo(sx+o.w*.04,sy);ctx.lineTo(tx+(rx-tx)*a,ty+(ry-ty)*a)}ctx.stroke()};
  wing(Math.sin(t*18+sd+1.4)*.8,wd,-2*u);
  for(const[dx,dy]of[[5,-4],[6,0],[5,4]])BPG(wd,bx+o.w*.28,by,o.x+o.w+dx*u*.6,by+dy*u,bx+o.w*.3,by+(dy>=0?1.4:-1.4)*u);
  BST('#e08a3a',1.4,bx-2*u,by+o.h*.28,bx-3*u,by+o.h*.45,bx-5*u,by+o.h*.52);BST('#e08a3a',1.4,bx+3*u,by+o.h*.28,bx+2*u,by+o.h*.45,bx,by+o.h*.52);
  ctx.fillStyle=wlg(by-o.h*.32,by+o.h*.32,c0,c1);ctx.beginPath();ctx.ellipse(bx,by,o.w*.36,o.h*.32,0,0,7);ctx.fill();wol(1.5);
  ctx.fillStyle='rgba(255,255,255,.3)';ctx.beginPath();ctx.ellipse(bx-o.w*.04,by+o.h*.1,o.w*.2,o.h*.14,0,0,7);ctx.fill();
  ctx.fillStyle=wlg(hy-hr,hy+hr,c0,c1);ctx.beginPath();ctx.arc(hx,hy,hr,0,7);ctx.fill();wol(1.5);
  BPG('#ffb347',hx-hr+1*u,hy-2*u,hx-hr-8*u,hy+1.5*u,hx-hr+1*u,hy+3*u);
  wdot(hx-hr*.15,hy-hr*.15,2.8*u,'#ff5d73');wdot(hx-hr*.2,hy-hr*.12,1.3*u,'#2a0a12');wdot(hx-hr*.28,hy-hr*.24,.6*u,'#fff');BST('#2a1a14',1.6,hx+hr*.45,hy-hr*.7,hx,hy-hr*.55,hx-hr*.5,hy-hr*.3);
  wing(wf,wc,0);
  for(let q=0;q<3;q++){const ph=(t*1.6+q*.33+sd)%1;BSP(bx+o.w*.38+ph*18*u,by+Math.sin(ph*6+q)*3*u,2.2*u*(1-ph),sn?'rgba(255,255,255,'+(1-ph).toFixed(2)+')':'rgba(200,170,140,'+(.7*(1-ph)).toFixed(2)+')')}
}
function obPond(o){
  const x=o.x,w=o.w,sn=o.b,sd=o.sd||(o.sd=Math.random()*6.28),sy=q=>G+4*u+Math.sin(t*4+q*.08+o.x*.01)*1.8*u;ctx.lineJoin='round';ctx.lineCap='round';
  ctx.fillStyle=sn?'#04101c':'#0b0907';rr(x-3*u,G-1*u,w+6*u,24*u,6*u);ctx.fill();
  const wg=ctx.createLinearGradient(0,G,0,G+22*u);wg.addColorStop(0,sn?'#35b6e6':'#69c0e0');wg.addColorStop(.5,sn?'#1b7fb5':'#3a8fb8');wg.addColorStop(1,sn?'#0d4670':'#1d5f86');
  ctx.fillStyle=wg;ctx.beginPath();ctx.moveTo(x,G+22*u);ctx.lineTo(x,sy(0));for(let q=0;q<=w;q+=6*u)ctx.lineTo(x+q,sy(q));ctx.lineTo(x+w,G+22*u);ctx.closePath();ctx.fill();
  ctx.fillStyle='rgba(5,40,80,.25)';ctx.beginPath();ctx.moveTo(x,G+22*u);ctx.lineTo(x,G+12*u);for(let q=0;q<=w;q+=8*u)ctx.lineTo(x+q,G+12*u+Math.sin(t*3+q*.1+2)*1.6*u);ctx.lineTo(x+w,G+22*u);ctx.closePath();ctx.fill();
  ctx.strokeStyle='rgba(255,255,255,.55)';ctx.lineWidth=1.3*u;ctx.beginPath();ctx.moveTo(x,sy(0));for(let q=6*u;q<=w;q+=6*u)ctx.lineTo(x+q,sy(q));ctx.stroke();
  ctx.strokeStyle='rgba(255,255,255,.4)';ctx.lineWidth=1.5*u;ctx.beginPath();ctx.moveTo(x+w*.2,G+9*u);ctx.lineTo(x+w*.4,G+9*u);ctx.moveTo(x+w*.55,G+13*u);ctx.lineTo(x+w*.8,G+13*u);ctx.stroke();
  for(let q=0;q<2;q++){const ph=(t*.7+q*.5+sd)%1;ctx.strokeStyle='rgba(255,255,255,'+(.5*(1-ph)).toFixed(2)+')';ctx.lineWidth=.8*u;ctx.beginPath();ctx.arc(x+w*(.3+q*.4),G+20*u-ph*14*u,(1.2+q*.4)*u,0,7);ctx.stroke()}
  const fc=3.6,fp=((t+sd)%fc)/.9;
  if(fp<1&&w>70*u){const fx=x+w*(.3+.4*fp),fy=G+4*u-Math.sin(fp*Math.PI)*17*u,an=Math.atan2(-Math.cos(fp*Math.PI)*17*Math.PI*u,w*.4);ctx.save();ctx.translate(fx,fy);ctx.rotate(an);BPG(sn?'#7fd0ff':'#ff7a2b',-5*u,0,-10*u,-3.5*u,-10*u,3.5*u);BOV(0,0,6*u,3*u,sn?'#bfe8ff':'#ff9f43');ctx.fillStyle='rgba(255,255,255,.4)';ctx.beginPath();ctx.ellipse(-.5*u,1*u,3.6*u,1.2*u,0,0,7);ctx.fill();wdot(3*u,-.8*u,.8*u,'#1a0f08');ctx.restore()}
  if(sn){
    ctx.fillStyle='#effbff';rr(x-4*u,G-2*u,w+8*u,5*u,3*u);ctx.fill();wol(1.2);
    for(const[a,hh]of[[x-2*u,10],[x+7*u,6],[x+w-8*u,8],[x+w,12]])BPG('#bfe8ff',a-4*u,G,a,G-hh*u,a+4*u,G);
    for(const a of[.25,.5,.75])BPG('#cfeeff',x+w*a-2*u,G+3*u,x+w*a,G+9*u,x+w*a+2*u,G+3*u);
    ctx.fillStyle='rgba(240,250,255,.85)';for(let q=0;q<3;q++){const f2=x+w*(.2+q*.3)+Math.sin(t*1.3+q*2)*5*u;ctx.beginPath();ctx.ellipse(f2,G+6*u+Math.sin(t*3+q)*1.2*u,(8+q%2*3)*u,2.4*u,0,0,7);ctx.fill()}
  }else{
    ctx.fillStyle='#5aa65f';rr(x-4*u,G-2*u,w+8*u,5*u,3*u);ctx.fill();wol(1.2);
    for(const[a,r]of[[.04,1],[.1,.8],[.9,.9],[.96,1.1]]){const rx=x+w*a,sw=Math.sin(t*2+a*9+sd)*2*u,hh=(15+r*6)*u;BST('#4f8a3f',1.8,rx,G,rx+sw*.5,G-hh*.5,rx+sw,G-hh);BOV(rx+sw,G-hh-3*u,1.8*u,4.4*u,'#7a4a2a',sw*.04)}
    const lx=x+w*.5,ly=sy(w*.5)+1.4*u;BOV(lx,ly,7*u,2.3*u,'#3f9a4f');ctx.strokeStyle='rgba(20,70,30,.6)';ctx.lineWidth=1*u;ctx.beginPath();ctx.moveTo(lx,ly);ctx.lineTo(lx+6*u,ly-.8*u);ctx.stroke();BOV(lx-1.5*u,ly-1.6*u,2.6*u,1.5*u,'#ff8fa3');wdot(lx-1.5*u,ly-1.8*u,.9*u,'#ffd23f');
  }
}
