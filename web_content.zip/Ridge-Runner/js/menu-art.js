/*
 * menu-art.js - Hand-drawn art for the main menu: the animated title scene, painted plank buttons, mode badges,
 * the best-score ribbon and the wooden panel frame. Everything is drawn on small off-screen canvases (no assets) and
 * handed to the stylesheet as CSS variables, so the existing DOM buttons and their click handlers stay untouched.
 */
import { t } from './clock.js';
import { $ } from './dom.js';

const S=2,INK='#10152e',TAU=Math.PI*2;
const rnd=seed=>{let s=seed%2147483647||1;return()=>(s=s*16807%2147483647)/2147483647};
const mk=(w,h)=>{const c=document.createElement('canvas');c.width=w*S;c.height=h*S;const g=c.getContext('2d');g.scale(S,S);g.lineJoin='round';g.lineCap='round';return[c,g]};
/** Adds a smooth closed outline through the points (midpoint quadratics) to the current path. */
const bp=(g,p)=>{const n=p.length;g.moveTo((p[n-1][0]+p[0][0])/2,(p[n-1][1]+p[0][1])/2);for(let i=0;i<n;i++){const a=p[i],b=p[(i+1)%n];g.quadraticCurveTo(a[0],a[1],(a[0]+b[0])/2,(a[1]+b[1])/2)}g.closePath()};
const blob=(g,p)=>{g.beginPath();bp(g,p)};
/** Perimeter points of a rounded rectangle, each nudged by up to `amp` so the outline looks drawn by hand. */
function rrPts(x,y,w,h,r,amp,R,step=16){
  const p=[],j=()=>(R()-.5)*2*amp;
  const side=(x0,y0,x1,y1)=>{const n=Math.max(1,Math.round(Math.hypot(x1-x0,y1-y0)/step));for(let i=0;i<n;i++){const q=i/n;p.push([x0+(x1-x0)*q+j(),y0+(y1-y0)*q+j()])}};
  const cr=(cx,cy,a0)=>{for(let k=0;k<3;k++){const a=a0+k*Math.PI/6+Math.PI/12;p.push([cx+Math.cos(a)*r+j()*.5,cy+Math.sin(a)*r+j()*.5])}};
  side(x+r,y,x+w-r,y);cr(x+w-r,y+r,-Math.PI/2);side(x+w,y+r,x+w,y+h-r);cr(x+w-r,y+h-r,0);side(x+w-r,y+h,x+r,y+h);cr(x+r,y+h-r,Math.PI/2);side(x,y+h-r,x,y+r);cr(x+r,y+r,Math.PI);
  return p;
}
/** Double-stroked ink outline: one firm line plus a faint second pass, like a pen going over a pencil sketch. */
function ink(g,p,p2,w){g.strokeStyle=INK;g.lineWidth=w;blob(g,p);g.stroke();if(p2){g.strokeStyle='rgba(16,21,46,.4)';g.lineWidth=w*.45;blob(g,p2);g.stroke()}}
const url=c=>'url('+c.toDataURL()+')';
const spark=(g,x,y,r)=>{g.beginPath();g.moveTo(x,y-r);g.quadraticCurveTo(x,y,x+r,y);g.quadraticCurveTo(x,y,x,y+r);g.quadraticCurveTo(x,y,x-r,y);g.quadraticCurveTo(x,y,x,y-r);g.fill()};

/* ---------------- planks, ribbon, chip cards, panel frame ---------------- */
const PLANK={gold:['#ffd88a','#ffb347','#df8a2c'],green:['#86dcb6','#4fae8a','#2f8266'],indigo:['#4d5eb0','#2a3566','#1b2347']};
function plank(col,seed){
  const W=300,H=56,[c,g]=mk(W,H),R=rnd(seed),x=5,y=3,w=W-10,h=H-9,pts=rrPts(x,y,w,h,13,1.2,R);
  g.save();g.translate(0,3.5);g.fillStyle='rgba(0,0,0,.4)';blob(g,pts);g.fill();g.restore();
  const gr=g.createLinearGradient(0,y,0,y+h);gr.addColorStop(0,col[0]);gr.addColorStop(.5,col[1]);gr.addColorStop(1,col[2]);
  g.fillStyle=gr;blob(g,pts);g.fill();
  g.save();blob(g,pts);g.clip();
  g.strokeStyle='rgba(0,0,0,.14)';g.lineWidth=1.2;
  for(let k=0;k<4;k++){const yy=y+h*(.18+k*.22)+R()*3;g.beginPath();g.moveTo(x,yy);for(let xx=x;xx<=x+w+16;xx+=16)g.lineTo(xx,yy+Math.sin(xx*.05+k*2.1)*1.8+(R()-.5));g.stroke()}
  for(let k=0;k<2;k++){const kx=60+R()*180,ky=y+12+R()*(h-24);g.strokeStyle='rgba(0,0,0,.17)';g.lineWidth=1.1;g.beginPath();g.ellipse(kx,ky,5,2.5,0,0,TAU);g.stroke();g.beginPath();g.ellipse(kx,ky,2.2,1.1,0,0,TAU);g.stroke()}
  g.fillStyle='rgba(255,255,255,.24)';blob(g,rrPts(x+8,y+4,w-16,h*.3,6,.8,R));g.fill();
  g.fillStyle='rgba(0,0,0,.16)';g.fillRect(x,y+h*.8,w,h*.2);
  g.restore();
  ink(g,pts,rrPts(x,y,w,h,13,1.9,R),3);
  g.strokeStyle='rgba(255,255,255,.35)';g.lineWidth=1.3;blob(g,rrPts(x+4,y+4,w-8,h-8,10,.5,R));g.stroke();
  for(const rx of[x+11,x+w-11]){g.fillStyle=INK;g.beginPath();g.arc(rx,y+h/2,3.4,0,TAU);g.fill();g.fillStyle=col[0];g.beginPath();g.arc(rx-.5,y+h/2-.6,2.1,0,TAU);g.fill();g.fillStyle='rgba(255,255,255,.8)';g.beginPath();g.arc(rx-1.2,y+h/2-1.3,.8,0,TAU);g.fill()}
  return c;
}
function ribbon(){
  const W=270,H=36,[c,g]=mk(W,H),R=rnd(5);
  g.fillStyle='#7d2430';for(const m of[1,-1]){const x0=m>0?0:W;g.beginPath();g.moveTo(x0,7);g.lineTo(x0+m*22,7);g.lineTo(x0+m*22,31);g.lineTo(x0,31);g.lineTo(x0+m*8,19);g.closePath();g.fill();g.strokeStyle=INK;g.lineWidth=2.2;g.stroke()}
  const pts=rrPts(14,3,W-28,H-9,6,.9,R);
  g.save();g.translate(0,3);g.fillStyle='rgba(0,0,0,.35)';blob(g,pts);g.fill();g.restore();
  const gr=g.createLinearGradient(0,3,0,H);gr.addColorStop(0,'#e5584a');gr.addColorStop(1,'#a82f3a');g.fillStyle=gr;blob(g,pts);g.fill();
  g.fillStyle='rgba(255,255,255,.22)';blob(g,rrPts(18,5,W-36,9,3,.5,R));g.fill();
  ink(g,pts,rrPts(14,3,W-28,H-9,6,1.5,R),2.6);
  g.fillStyle='rgba(0,0,0,.28)';for(const m of[14,W-14]){g.beginPath();g.moveTo(m,3);g.lineTo(m+(m<W/2?9:-9),H-6);g.lineTo(m,H-6);g.closePath();g.fill()}
  return c;
}
function chipCard(on,seed){
  const W=66,H=70,[c,g]=mk(W,H),R=rnd(seed),pts=rrPts(3,3,W-6,H-8,11,1,R,14);
  g.save();g.translate(0,3);g.fillStyle='rgba(0,0,0,.38)';blob(g,pts);g.fill();g.restore();
  const gr=g.createLinearGradient(0,3,0,H);if(on){gr.addColorStop(0,'#ffeaa8');gr.addColorStop(1,'#ffb347')}else{gr.addColorStop(0,'#35428a');gr.addColorStop(1,'#1c2551')}
  g.fillStyle=gr;blob(g,pts);g.fill();
  g.save();blob(g,pts);g.clip();g.strokeStyle=on?'rgba(150,80,10,.18)':'rgba(255,255,255,.07)';g.lineWidth=1;for(let k=0;k<5;k++){g.beginPath();g.moveTo(0,10+k*13+R()*3);g.lineTo(W,6+k*13+R()*3);g.stroke()}g.fillStyle=on?'rgba(255,255,255,.3)':'rgba(255,255,255,.08)';g.fillRect(0,0,W,14);g.restore();
  ink(g,pts,rrPts(3,3,W-6,H-8,11,1.7,R,14),2.4);
  if(on){g.strokeStyle='rgba(255,255,255,.7)';g.lineWidth=1.2;blob(g,rrPts(6.5,6.5,W-13,H-15,8,.4,R,14));g.stroke()}
  return c;
}
function frame(){
  const N=120,B=18,[c,g]=mk(N,N),R=rnd(11),o=rrPts(1.5,1.5,N-3,N-3,12,.8,R,20),i=rrPts(B,B,N-2*B,N-2*B,4,.5,R,20);
  const gr=g.createLinearGradient(0,0,N,N);gr.addColorStop(0,'#b07a42');gr.addColorStop(.5,'#8a5a30');gr.addColorStop(1,'#68411f');
  g.beginPath();bp(g,o);bp(g,i);g.fillStyle=gr;g.fill('evenodd');
  g.save();g.beginPath();bp(g,o);bp(g,i);g.clip('evenodd');
  g.strokeStyle='rgba(40,20,5,.2)';g.lineWidth=1.1;
  for(let k=0;k<3;k++){const a=5+k*4.5;g.beginPath();g.moveTo(0,a);for(let x=0;x<=N;x+=15)g.lineTo(x,a+Math.sin(x*.07+k)*1);g.moveTo(0,N-a);for(let x=0;x<=N;x+=15)g.lineTo(x,N-a+Math.sin(x*.07+k)*1);g.moveTo(a,0);for(let y=0;y<=N;y+=15)g.lineTo(a+Math.sin(y*.07+k)*1,y);g.moveTo(N-a,0);for(let y=0;y<=N;y+=15)g.lineTo(N-a+Math.sin(y*.07+k)*1,y);g.stroke()}
  g.strokeStyle='rgba(30,14,4,.4)';g.lineWidth=1.4;g.beginPath();for(const s of[40,80]){g.moveTo(s,0);g.lineTo(s,B);g.moveTo(s,N-B);g.lineTo(s,N);g.moveTo(0,s);g.lineTo(B,s);g.moveTo(N-B,s);g.lineTo(N,s)}g.stroke();
  g.strokeStyle='rgba(255,226,170,.4)';g.lineWidth=1.4;g.beginPath();g.moveTo(14,4.5);g.lineTo(N-14,4.5);g.moveTo(4.5,14);g.lineTo(4.5,N-14);g.stroke();
  g.restore();
  ink(g,o,rrPts(1.5,1.5,N-3,N-3,12,1.4,R,20),3.2);
  g.strokeStyle='rgba(8,6,20,.7)';g.lineWidth=2.4;blob(g,i);g.stroke();g.strokeStyle='rgba(255,210,150,.25)';g.lineWidth=1;blob(g,rrPts(B-2,B-2,N-2*B+4,N-2*B+4,5,.4,R,20));g.stroke();
  for(const[cx,cy]of[[2,2],[N-16,2],[2,N-16],[N-16,N-16]]){blob(g,rrPts(cx,cy,14,14,3,.5,R,8));g.fillStyle='#565c73';g.fill();g.strokeStyle=INK;g.lineWidth=1.8;g.stroke();g.fillStyle='#aab1c9';g.beginPath();g.arc(cx+6.5,cy+6.5,2.6,0,TAU);g.fill();g.strokeStyle=INK;g.lineWidth=1;g.stroke();g.fillStyle='rgba(255,255,255,.8)';g.beginPath();g.arc(cx+5.6,cy+5.6,.9,0,TAU);g.fill()}
  return c;
}
/** Seamless painted-board speckle tile (drawn twice at the edges so it wraps). */
function board(){
  const N=64,[c,g]=mk(N,N),R=rnd(23);
  for(let k=0;k<46;k++){const x=R()*N,y=R()*N,a=R()*Math.PI,l=3+R()*9;g.strokeStyle=R()<.5?'rgba(255,255,255,.05)':'rgba(0,0,10,.1)';g.lineWidth=1+R()*1.4;
    for(const dx of[-N,0,N])for(const dy of[-N,0,N]){g.beginPath();g.moveTo(x+dx,y+dy);g.lineTo(x+dx+Math.cos(a)*l,y+dy+Math.sin(a)*l);g.stroke()}}
  g.fillStyle='rgba(255,236,190,.35)';for(let k=0;k<5;k++)spark(g,R()*N,R()*N,1+R()*1.4);
  return c;
}

/* ---------------- icons (40 x 40, outlined, hand-drawn) ---------------- */
const IC={
  play(g){g.beginPath();g.arc(20,20,15,0,TAU);g.fillStyle='#fff3d6';g.fill();g.stroke();g.fillStyle='#e8742a';g.beginPath();g.moveTo(16,12);g.lineTo(29,20);g.lineTo(16,28);g.closePath();g.fill();g.stroke();g.strokeStyle='rgba(255,255,255,.8)';g.lineWidth=1.6;g.beginPath();g.arc(20,20,11.5,Math.PI*1.1,Math.PI*1.5);g.stroke()},
  compass(g){g.beginPath();g.arc(20,20,15,0,TAU);g.fillStyle='#fff3d6';g.fill();g.stroke();g.strokeStyle='#2f7d63';g.lineWidth=1.6;g.beginPath();g.arc(20,20,10.5,0,TAU);g.stroke();g.beginPath();for(let k=0;k<4;k++){const a=k*Math.PI/2;g.moveTo(20+Math.cos(a)*10.5,20+Math.sin(a)*10.5);g.lineTo(20+Math.cos(a)*7.5,20+Math.sin(a)*7.5)}g.stroke();
    g.save();g.translate(20,20);g.rotate(.7);g.fillStyle='#e0453f';g.beginPath();g.moveTo(0,-9);g.lineTo(3.2,0);g.lineTo(-3.2,0);g.closePath();g.fill();g.strokeStyle=INK;g.lineWidth=1.6;g.stroke();g.fillStyle='#fdf6e9';g.beginPath();g.moveTo(0,9);g.lineTo(3.2,0);g.lineTo(-3.2,0);g.closePath();g.fill();g.stroke();g.restore();g.fillStyle=INK;g.beginPath();g.arc(20,20,1.6,0,TAU);g.fill()},
  shirt(g){g.beginPath();g.moveTo(13,7);g.quadraticCurveTo(20,13,27,7);g.lineTo(35,13);g.lineTo(30.5,20);g.lineTo(27,17.5);g.lineTo(27,34);g.lineTo(13,34);g.lineTo(13,17.5);g.lineTo(9.5,20);g.lineTo(5,13);g.closePath();g.fillStyle='#8aa8ff';g.fill();g.stroke();g.fillStyle='#fff3d6';g.beginPath();g.moveTo(14.5,7.6);g.quadraticCurveTo(20,14,25.5,7.6);g.quadraticCurveTo(20,10,14.5,7.6);g.fill();g.fillStyle='#ffd23f';spark(g,20,25,5);g.fillStyle='rgba(255,255,255,.35)';g.fillRect(14.6,18,2.4,11)},
  key(g){g.save();g.translate(12,15);g.rotate(Math.PI/4);g.fillStyle='#ffd23f';g.beginPath();g.rect(5,-2.6,22,5.2);g.fill();g.stroke();g.beginPath();g.rect(19,2.6,3.6,5);g.rect(24.5,2.6,3.2,4);g.fill();g.stroke();g.beginPath();g.arc(0,0,7.5,0,TAU);g.fill();g.stroke();g.fillStyle=INK;g.beginPath();g.arc(0,0,3,0,TAU);g.fill();g.restore()},
  star(g){g.beginPath();for(let k=0;k<10;k++){const a=-Math.PI/2+k*Math.PI/5,r=k%2?6.5:15;g.lineTo(20+Math.cos(a)*r,21+Math.sin(a)*r)}g.closePath();g.fillStyle='#ffd23f';g.fill();g.stroke();g.fillStyle='rgba(255,255,255,.6)';g.beginPath();g.arc(16,14,2.2,0,TAU);g.fill()},
  medal(g){g.fillStyle='#e0453f';g.beginPath();g.moveTo(11,3);g.lineTo(20,17);g.lineTo(15,19);g.lineTo(6,6);g.closePath();g.fill();g.stroke();g.fillStyle='#4a78e0';g.beginPath();g.moveTo(29,3);g.lineTo(20,17);g.lineTo(25,19);g.lineTo(34,6);g.closePath();g.fill();g.stroke();g.beginPath();g.arc(20,26,11,0,TAU);g.fillStyle='#ffd23f';g.fill();g.stroke();g.strokeStyle='#c98a1c';g.lineWidth=1.5;g.beginPath();g.arc(20,26,7.5,0,TAU);g.stroke();g.fillStyle='#fff3d6';spark(g,20,26,5)},
  sprout(g){g.fillStyle='#8a5a30';g.beginPath();g.ellipse(20,33,12,4.6,0,0,TAU);g.fill();g.stroke();g.strokeStyle='#3f8f4a';g.lineWidth=3.2;g.beginPath();g.moveTo(20,32);g.quadraticCurveTo(19,22,21,14);g.stroke();
    for(const m of[-1,1]){g.save();g.translate(20.5,m>0?18:22);g.rotate(m*-.8);g.fillStyle=m>0?'#9be37a':'#6cc25a';g.beginPath();g.ellipse(m*7,0,8,4.2,0,0,TAU);g.fill();g.strokeStyle=INK;g.lineWidth=2.2;g.stroke();g.restore()}},
  mountain(g){g.fillStyle='#ffb347';g.beginPath();g.arc(30,10,5.5,0,TAU);g.fill();g.stroke();g.fillStyle='#7d8de0';g.beginPath();g.moveTo(2,34);g.lineTo(13,16);g.lineTo(24,34);g.closePath();g.fill();g.stroke();g.fillStyle='#98a6f0';g.beginPath();g.moveTo(12,34);g.lineTo(23,8);g.lineTo(38,34);g.closePath();g.fill();g.stroke();g.fillStyle='#fdf6e9';g.beginPath();g.moveTo(23,8);g.lineTo(18,18);g.lineTo(21,16.5);g.lineTo(23,20);g.lineTo(25.5,16.5);g.lineTo(28,18.5);g.closePath();g.fill();g.stroke()},
  flame(g){g.beginPath();g.moveTo(20,4);g.bezierCurveTo(26,12,34,17,31,27);g.bezierCurveTo(29,35,11,35,9,27);g.bezierCurveTo(7,20,14,18,15,12);g.bezierCurveTo(17,15,18,10,20,4);g.closePath();g.fillStyle='#ff6a1a';g.fill();g.stroke();g.fillStyle='#ffc23a';g.beginPath();g.moveTo(20,16);g.bezierCurveTo(24,21,28,24,26,29);g.bezierCurveTo(24,34,15,34,14,29);g.bezierCurveTo(13,25,18,23,20,16);g.closePath();g.fill();g.fillStyle='#fff3c4';g.beginPath();g.ellipse(20,30,3.6,3.4,0,0,TAU);g.fill()},
  bolt(g){g.beginPath();g.moveTo(24,3);g.lineTo(9,22);g.lineTo(18.5,22);g.lineTo(15,37);g.lineTo(31,16);g.lineTo(21.5,16);g.closePath();g.fillStyle='#ffd23f';g.fill();g.strokeStyle='#ff5d73';g.lineWidth=3.2;g.stroke();g.strokeStyle=INK;g.lineWidth=1.6;g.stroke();g.strokeStyle='rgba(255,255,255,.85)';g.lineWidth=1.6;g.beginPath();g.moveTo(21,7);g.lineTo(14,18);g.stroke()}
};
function icon(name){const[c,g]=mk(40,40);g.strokeStyle=INK;g.lineWidth=2.4;IC[name](g);return c}

/* ---------------- animated title scene ---------------- */
const LW=300,LH=118,WORD='Ridge Runner';
const ridge=x=>101+Math.sin(x*.045)*3.2+Math.sin(x*.11)*1.6;
const DY=[2,-3,1,-2,2,0,-2,2,-1,1,-3,2],RT=[-.06,.04,-.03,.05,-.04,0,.05,-.04,.03,-.05,.04,-.03];
let logo=null,lay=null,tickN=0;
function peak(g,cx,base,w,h,col,shade,R,snow){
  const j=()=>(R()-.5)*3,top=[cx+j(),base-h];
  const P=[[cx-w/2,base],[cx-w*.28+j(),base-h*.52],top,[cx+w*.26+j(),base-h*.5],[cx+w/2,base]];
  g.fillStyle=col;g.beginPath();g.moveTo(...P[0]);g.quadraticCurveTo(P[1][0],P[1][1],...top);g.quadraticCurveTo(P[3][0],P[3][1],...P[4]);g.closePath();g.fill();
  g.save();g.clip();g.fillStyle=shade;g.beginPath();g.moveTo(top[0],top[1]);g.lineTo(top[0]+w*.08,base-h*.45);g.lineTo(cx+w*.02,base);g.lineTo(cx+w/2+4,base);g.lineTo(cx+w/2+4,base-h);g.closePath();g.fill();
  g.strokeStyle='rgba(16,21,46,.22)';g.lineWidth=1;g.beginPath();for(let k=0;k<5;k++){const y=base-h*(.15+k*.14),x0=cx+w*(.03+k*.012);g.moveTo(x0,y);g.lineTo(x0+w*(.2-k*.025),y-h*.07)}g.stroke();g.restore();
  g.strokeStyle=INK;g.lineWidth=2.2;g.beginPath();g.moveTo(...P[0]);g.quadraticCurveTo(P[1][0],P[1][1],...top);g.quadraticCurveTo(P[3][0],P[3][1],...P[4]);g.stroke();
  if(snow){const sy=base-h*.7,l=top[0]-w*.16,r=top[0]+w*.15;g.fillStyle='#f4f8ff';g.beginPath();g.moveTo(top[0],top[1]);g.lineTo(l,sy+3);g.lineTo(l+w*.06,sy-2);g.lineTo(top[0]-w*.03,sy+5);g.lineTo(top[0]+w*.03,sy-1);g.lineTo(top[0]+w*.09,sy+5);g.lineTo(r,sy);g.closePath();g.fill();g.fillStyle='rgba(120,140,220,.35)';g.beginPath();g.moveTo(top[0],top[1]);g.lineTo(top[0]+w*.03,sy-1);g.lineTo(top[0]+w*.09,sy+5);g.lineTo(r,sy);g.closePath();g.fill();g.strokeStyle=INK;g.lineWidth=1.8;g.stroke()}
}
function pine(g,x,base,h,col){
  g.fillStyle='#4a2c18';g.fillRect(x-1.4,base-3,2.8,4);
  for(let k=0;k<3;k++){const by=base-2-k*h*.27,w=h*(.5-k*.1);g.fillStyle=col;g.beginPath();g.moveTo(x-w,by);g.lineTo(x,by-h*.42);g.lineTo(x+w,by);g.closePath();g.fill();g.strokeStyle=INK;g.lineWidth=1.7;g.stroke();g.fillStyle='rgba(255,255,255,.75)';g.beginPath();g.moveTo(x-w*.38,by-h*.25);g.lineTo(x,by-h*.42);g.lineTo(x+w*.38,by-h*.25);g.closePath();g.fill()}
}
function buildLogo(){
  const cv=$('mlogo');if(!cv)return;
  const R=rnd(7),[back,b]=mk(LW,LH),[front,f]=mk(LW,LH),g=cv.getContext('2d');
  g.scale(S,S);g.lineJoin='round';g.lineCap='round';
  const sk=b.createLinearGradient(0,0,0,LH);sk.addColorStop(0,'#1f2f6b');sk.addColorStop(.42,'#5a5fb5');sk.addColorStop(.76,'#f59a62');sk.addColorStop(1,'#ffd58a');b.fillStyle=sk;b.fillRect(0,0,LW,LH);
  peak(f,48,104,130,60,'#5f6dc0','#4a56a0',R,1);peak(f,252,104,126,56,'#5f6dc0','#4a56a0',R,1);peak(f,140,106,150,80,'#7587d6','#5d6cba',R,1);peak(f,205,108,100,48,'#8a78c4','#6f60a6',R,1);
  const gd=f.createLinearGradient(0,92,0,LH);gd.addColorStop(0,'#26356f');gd.addColorStop(1,'#111a3d');f.fillStyle=gd;f.beginPath();f.moveTo(0,LH);for(let x=0;x<=LW;x+=4)f.lineTo(x,ridge(x));f.lineTo(LW,LH);f.closePath();f.fill();
  f.strokeStyle='rgba(225,232,255,.7)';f.lineWidth=1.8;f.beginPath();for(let x=0;x<=LW;x+=4)x?f.lineTo(x,ridge(x)):f.moveTo(x,ridge(x));f.stroke();
  f.strokeStyle=INK;f.lineWidth=1.4;f.beginPath();for(let x=0;x<=LW;x+=4)x?f.lineTo(x,ridge(x)+1.6):f.moveTo(x,ridge(x)+1.6);f.stroke();
  for(const[x,h,c]of[[12,26,'#2f7a58'],[27,19,'#276a4c'],[41,23,'#2f7a58'],[258,22,'#276a4c'],[274,28,'#2f7a58'],[289,20,'#276a4c']])pine(f,x,ridge(x)+3,h,c);
  logo={g,back,front,win:rrPts(3,3,LW-6,LH-6,14,1.2,R),win2:rrPts(6.5,6.5,LW-13,LH-13,11,1,R)};lay=null;
}
function layout(g){
  g.font='800 36px "Bricolage Grotesque",system-ui,sans-serif';
  const ws=[...WORD].map(ch=>g.measureText(ch).width),tot=ws.reduce((a,b)=>a+b,0)+1.2*(WORD.length-1);let x=(LW-tot)/2;
  return[...WORD].map((ch,i)=>{const o={ch,x:x+ws[i]/2};x+=ws[i]+1.2;return o});
}
function runner(g,x,y){
  const ph=t*13,s=Math.sin(ph);
  g.save();g.translate(x,y);
  g.strokeStyle='#ffd23f';g.lineWidth=2.2;g.beginPath();g.moveTo(-3,-15);g.quadraticCurveTo(-9,-14+Math.sin(t*9)*2,-14,-15+Math.sin(t*9+1.5)*3);g.stroke();
  for(const m of[-1,1]){g.strokeStyle=INK;g.lineWidth=3.4;g.beginPath();g.moveTo(0,-7);g.lineTo(m*s*4.5,-Math.max(0,m*Math.cos(ph))*2.4);g.stroke();g.strokeStyle='#ff9d3c';g.lineWidth=1.8;g.stroke()}
  g.fillStyle='#ff7a59';g.beginPath();g.ellipse(0,-10.5,4.4,5.2,0,0,TAU);g.fill();g.strokeStyle=INK;g.lineWidth=1.6;g.stroke();
  g.fillStyle='#ffe0b8';g.beginPath();g.arc(1,-18.5,4.4,0,TAU);g.fill();g.stroke();
  g.fillStyle='#3a2418';g.beginPath();g.arc(.6,-19.2,4.4,Math.PI*1.05,Math.PI*1.95);g.closePath();g.fill();
  g.fillStyle=INK;g.beginPath();g.arc(2.8,-18.2,.8,0,TAU);g.fill();
  g.restore();
}
function drawLogo(){
  if(!logo)buildLogo();if(!logo)return;
  const g=logo.g;if(!lay)lay=layout(g);
  g.clearRect(0,0,LW,LH);g.save();blob(g,logo.win);g.clip();
  g.drawImage(logo.back,0,0,LW,LH);
  const sx=262,sy=27,sr=10.5+Math.sin(t*1.4)*.5,gl=g.createRadialGradient(sx,sy,3,sx,sy,40);gl.addColorStop(0,'rgba(255,236,170,.8)');gl.addColorStop(1,'rgba(255,200,120,0)');g.fillStyle=gl;g.beginPath();g.arc(sx,sy,40,0,TAU);g.fill();
  g.fillStyle='rgba(255,232,150,.4)';for(let k=0;k<12;k++){const a=t*.22+k*TAU/12,l=k%2?13:19;g.beginPath();g.moveTo(sx+Math.cos(a-.09)*sr,sy+Math.sin(a-.09)*sr);g.lineTo(sx+Math.cos(a)*(sr+l),sy+Math.sin(a)*(sr+l));g.lineTo(sx+Math.cos(a+.09)*sr,sy+Math.sin(a+.09)*sr);g.fill()}
  g.fillStyle='#ffd45e';g.beginPath();g.arc(sx,sy,sr,0,TAU);g.fill();g.strokeStyle='#d27a1c';g.lineWidth=1.6;g.stroke();
  g.fillStyle='#fff6d0';for(let k=0;k<9;k++)spark(g,[20,58,92,128,170,196,228,286,40][k],[14,26,10,30,14,22,10,44,46][k],.8+.9*Math.max(0,Math.sin(t*2.2+k*1.7)));
  g.fillStyle='rgba(255,255,255,.6)';for(const[o,y,s]of[[0,24,1],[150,42,.75]]){const x=((t*5*s+o)%(LW+90))-45;g.beginPath();g.ellipse(x,y,17*s,5*s,0,0,TAU);g.ellipse(x-9*s,y+1,10*s,4*s,0,0,TAU);g.ellipse(x+10*s,y+1.5,11*s,3.6*s,0,0,TAU);g.fill()}
  g.drawImage(logo.front,0,0,LW,LH);
  runner(g,((t*17)%(LW+50))-25,0);
  g.textAlign='center';g.textBaseline='alphabetic';
  lay.forEach((o,i)=>{if(o.ch===' ')return;
    g.save();g.translate(o.x,66+DY[i]+Math.sin(t*1.8+i*.55)*1.4);g.rotate(RT[i]+Math.sin(t*1.3+i)*.012);
    g.fillStyle='rgba(0,0,0,.42)';g.fillText(o.ch,2,5);
    g.lineJoin='round';g.strokeStyle=INK;g.lineWidth=9;g.strokeText(o.ch,0,0);g.strokeStyle='#8a3a12';g.lineWidth=5.4;g.strokeText(o.ch,0,0);
    const gr=g.createLinearGradient(0,-30,0,2);gr.addColorStop(0,'#fff6c9');gr.addColorStop(.5,'#ffc857');gr.addColorStop(1,'#ff8a2b');g.fillStyle=gr;g.fillText(o.ch,0,0);
    g.save();g.beginPath();g.rect(-30,-31,60,11);g.clip();g.fillStyle='rgba(255,255,255,.5)';g.fillText(o.ch,-.8,-1.4);g.restore();
    if(o.ch==='R'){g.fillStyle='#fff';g.beginPath();g.moveTo(-8,-24);g.quadraticCurveTo(-3,-31,5.5,-27);g.lineTo(6,-23.5);g.lineTo(3,-25);g.lineTo(1,-21.5);g.lineTo(-2,-25);g.lineTo(-4.5,-22.5);g.lineTo(-7,-23);g.closePath();g.fill();g.strokeStyle=INK;g.lineWidth=1.4;g.stroke()}
    g.restore()});
  g.fillStyle='#fff';for(const[x,y,k]of[[26,40,0],[290,64,2],[150,26,4]])spark(g,x,y,1.5+2.6*Math.max(0,Math.sin(t*2.6+k)));
  g.restore();
  ink(g,logo.win,logo.win2,3.2);g.strokeStyle='rgba(255,226,170,.5)';g.lineWidth=1;blob(g,rrPts(7,7,LW-14,LH-14,10,.6,rnd(3)));g.stroke();
}

/* ---------------- wiring ---------------- */
const CHIP_ICONS=['sprout','mountain','flame','bolt'];
/** Draws every piece of art once and hands it to the stylesheet; decorates the mode chips created by ui.js. Call after initUI(). */
export function initMenuArt(){
  const root=document.documentElement.style,set=(k,c)=>root.setProperty(k,url(c));
  set('--frame',frame());set('--board',board());set('--ribbon',ribbon());set('--chip-off',chipCard(0,31));set('--chip-on',chipCard(1,37));
  set('--pk-gold',plank(PLANK.gold,41));set('--pk-green',plank(PLANK.green,43));set('--pk-indigo',plank(PLANK.indigo,47));
  for(const[k,n]of[['play','play'],['adv','compass'],['cust','shirt'],['key','key'],['star','star'],['medal','medal']])set('--i-'+k,icon(n));
  [...$('modes').children].forEach((chip,i)=>{if(chip.querySelector('canvas'))return;const c=icon(CHIP_ICONS[i]||'mountain');c.className='mi';chip.prepend(c)});
  const adT=$('admt');if(adT){const sync=()=>{adT.toggleAttribute('data-on',!!adT.style.background)};sync();new MutationObserver(sync).observe(adT,{attributes:true,attributeFilter:['style']})}
  try{document.fonts.load('800 41px "Bricolage Grotesque"').then(()=>{lay=null},()=>{})}catch(e){}
  buildLogo();drawLogo();
}
/** Animates the title scene while the main menu is showing (about 30 frames per second). Called from the frame loop. */
export function menuArtFrame(){
  if($('menu').hidden||(++tickN&1))return;
  drawLogo();
}
