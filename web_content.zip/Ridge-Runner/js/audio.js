/*
 * audio.js - Sound effects (tiny WebAudio synth) and the mute button.
 */
import { $ } from './dom.js';

let ac;
let mute=false;
export function A(){try{ac=ac||new(window.AudioContext||window.webkitAudioContext)();if(ac.state==='suspended')ac.resume()}catch(e){}return ac}
export function snd(k){
  if(mute||!A())return;
  try{
    const n=ac.currentTime,p={j1:[330,560,.12,'square',.05],j2:[520,900,.14,'square',.05],c:[880,1400,.1,'triangle',.09],d:[300,70,.4,'sawtooth',.07],b:[500,1500,.2,'sine',.1],sp:[700,90,.45,'triangle',.12],cp:[587,880,.3,'sine',.05],cp2:[880,1175,.42,'sine',.04]}[k];
    const o=ac.createOscillator(),g=ac.createGain();
    o.type=p[3];o.frequency.setValueAtTime(p[0],n);o.frequency.exponentialRampToValueAtTime(p[1],n+p[2]);
    g.gain.setValueAtTime(p[4],n);g.gain.exponentialRampToValueAtTime(.001,n+p[2]);
    o.connect(g).connect(ac.destination);o.start(n);o.stop(n+p[2]+.02);
  }catch(e){}
}
let tpNb=null;
export function tpSn(k){
  if(mute||!A())return;
  try{const n=ac.currentTime,R=Math.random;
    if(k==='creak'){const d=.32+R()*.26,f0=90+R()*70,o=ac.createOscillator(),o2=ac.createOscillator(),g=ac.createGain(),b=ac.createBiquadFilter(),lf=ac.createOscillator(),lg=ac.createGain();
      o.type=o2.type='sawtooth';o.frequency.setValueAtTime(f0,n);o.frequency.linearRampToValueAtTime(f0*(1.2+R()*.35),n+d);o2.frequency.setValueAtTime(f0*1.5,n);o2.frequency.linearRampToValueAtTime(f0*1.85,n+d);
      b.type='bandpass';b.Q.value=7;b.frequency.setValueAtTime(480,n);b.frequency.linearRampToValueAtTime(880,n+d);
      g.gain.setValueAtTime(.0001,n);g.gain.linearRampToValueAtTime(.045,n+.05);g.gain.linearRampToValueAtTime(.0001,n+d);
      lf.frequency.value=20+R()*14;lg.gain.value=.02;lf.connect(lg);lg.connect(g.gain);
      o.connect(b);o2.connect(b);b.connect(g);g.connect(ac.destination);o.start(n);o2.start(n);lf.start(n);o.stop(n+d+.03);o2.stop(n+d+.03);lf.stop(n+d+.03)}
    else if(k==='rope'){if(!tpNb){tpNb=ac.createBuffer(1,Math.floor(ac.sampleRate*.7),ac.sampleRate);const a=tpNb.getChannelData(0);for(let i=0;i<a.length;i++)a[i]=R()*2-1}
      const d=.45+R()*.3,s=ac.createBufferSource(),b=ac.createBiquadFilter(),g=ac.createGain(),lf=ac.createOscillator(),lg=ac.createGain();
      s.buffer=tpNb;b.type='bandpass';b.Q.value=3;b.frequency.setValueAtTime(1300,n);b.frequency.linearRampToValueAtTime(2100,n+d);
      g.gain.setValueAtTime(.0001,n);g.gain.linearRampToValueAtTime(.03,n+.08);g.gain.linearRampToValueAtTime(.0001,n+d);
      lf.frequency.value=15;lg.gain.value=.014;lf.connect(lg);lg.connect(g.gain);s.connect(b);b.connect(g);g.connect(ac.destination);s.start(n);lf.start(n);s.stop(n+d);lf.stop(n+d)}
    else if(k==='pulley'){const d=.26+R()*.12,o=ac.createOscillator(),g=ac.createGain(),b=ac.createBiquadFilter(),lf=ac.createOscillator(),lg=ac.createGain();
      o.type='triangle';o.frequency.setValueAtTime(820,n);o.frequency.linearRampToValueAtTime(1120+R()*120,n+d);b.type='bandpass';b.frequency.value=1100;b.Q.value=4;
      g.gain.setValueAtTime(.0001,n);g.gain.linearRampToValueAtTime(.03,n+.04);g.gain.linearRampToValueAtTime(.0001,n+d);lf.frequency.value=9;lg.gain.value=40;lf.connect(lg);lg.connect(o.frequency);
      o.connect(b);b.connect(g);g.connect(ac.destination);o.start(n);lf.start(n);o.stop(n+d+.02);lf.stop(n+d+.02)}
    else if(k==='settle'){const o=ac.createOscillator(),g=ac.createGain();o.type='sine';o.frequency.setValueAtTime(115,n);o.frequency.exponentialRampToValueAtTime(46,n+.3);g.gain.setValueAtTime(.12,n);g.gain.exponentialRampToValueAtTime(.001,n+.34);o.connect(g);g.connect(ac.destination);o.start(n);o.stop(n+.36);
      if(!tpNb){tpNb=ac.createBuffer(1,Math.floor(ac.sampleRate*.7),ac.sampleRate);const a=tpNb.getChannelData(0);for(let i=0;i<a.length;i++)a[i]=R()*2-1}
      const s=ac.createBufferSource(),b=ac.createBiquadFilter(),g2=ac.createGain();s.buffer=tpNb;b.type='lowpass';b.frequency.value=520;g2.gain.setValueAtTime(.06,n);g2.gain.exponentialRampToValueAtTime(.001,n+.14);s.connect(b);b.connect(g2);g2.connect(ac.destination);s.start(n);s.stop(n+.15)}
  }catch(e){}}

const mb=$('mute');
/** Wires this module up to the DOM / storage. Called once from main.js during boot, in the original statement order. */
export function initAudio(){
  mb.addEventListener('pointerdown',e=>{e.stopPropagation();mute=!mute;mb.textContent=mute?'🔇':'🔊'});
}
