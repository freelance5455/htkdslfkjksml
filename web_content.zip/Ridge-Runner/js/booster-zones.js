/*
 * booster-zones.js - Where the Normal Fly (jetpack) pickup may NOT be placed: the approach to a cave or the
 * Temple, and everything underground. A pickup grabbed outside these zones cannot carry the runner into them.
 * Used by spawn.js (placement), so the rule lives in the spawning logic and not in rendering.
 */
import { TP, tpDue } from './jungle-temple.js';
import { state } from './state.js';
import { px, u } from './view.js';

/* Longest distance (in u) a Fly pickup can carry the runner: 5 s at the 700 u/s flight speed is 3500 u,
   plus the glide and landing after the jetpack stops, plus a safety margin. */
export const FLY_REACH = 4200;
/* Margin (in u) past a cave's far end that is still treated as part of the cave (its exit slope). */
export const FLY_EXIT = 300;

/** Flight speed (u/s) while the jetpack is on - see stepSpeed in physics.js. */
export const FLY_SPEED = 700;

/** True when screen x lies inside a cave / Temple approach or interior (position only). */
export function flyInZone(x){
  const wc = state.dist + x - px;                  // cave space (same frame as the cave drawing and `ic` in spawn.js)
  if (wc >= state.cs*10*u - FLY_REACH*u && wc <= state.ce*10*u + FLY_EXIT*u) return true;
  if (state.tpOn){                                 // Temple space (same frame as tpBlk / tpS)
    const wt = state.dist + x;
    if (wt >= state.tpU*u - FLY_REACH*u && wt <= (state.tpU + TP.END + 320)*u) return true;
  }
  return false;
}

/** True when a Fly pickup must not be placed at screen x: inside a zone, or while the Temple is about to start. */
export const flyBanned = x => flyInZone(x) || tpDue();

/** A newly scheduled cave start (in tens of u) pushed out of reach of a jetpack that is still running. */
export function caveStartAfterFlight(cs){
  if (state.fx.fly <= 0) return cs;
  return Math.max(cs, Math.ceil((state.dist + 17*u + state.fx.fly*FLY_SPEED*u + 1000*u) / (10*u)));
}
