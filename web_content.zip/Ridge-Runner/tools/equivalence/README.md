# Equivalence tools (optional, for maintainers)

These scripts compare the modular game against the original single-file game, frame by frame, to catch regressions
when the modules are edited. They are not needed to play the game.

Requirements: Node 18+ and Playwright with a Chromium build (`npm i playwright && npx playwright install chromium`).

- `serve/orig/index.html` is the original single-file game (kept here as the reference).
- The modular project (this folder's parent) is served automatically at `/mod/`.

```
cd tools/equivalence
node compare.js              # all scenarios (the 26,000-frame run is slow; MARATHON=4000 shortens it)
node compare.js wardrobe     # only scenarios whose name contains "wardrobe"
node coverage.js             # which features a scripted run reached (modular build only)
```

How it works: both builds run with the same random seed, a fake clock and the same scripted inputs, and a hash of the
canvas plus the DOM state is compared every few frames. A mismatch means the two builds diverged.
Scenarios cover menus, normal runs, death and restart, all modes, the wardrobe and every outfit, all biomes, caves,
the Jungle Temple, rides, boosters, Adventure (new game, checkpoints, finale), collisions and resizing.
Only Chromium was used.
