// Lockstep equivalence harness: original single-file build (serve/orig/index.html) vs the modular project (served at /mod/).
// Usage: node compare.js [scenario-name-filter]   (env: MARATHON=frames, PORT=port)
const {chromium}=require('playwright');
const INIT=`(()=>{
  let s=987654321;Math.random=()=>{s|=0;s=s+0x6D2B79F5|0;let t=Math.imul(s^s>>>15,1|s);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296};
  let now=1000;performance.now=()=>now;
  let cbs=[];window.requestAnimationFrame=cb=>{cbs.push(cb);return cbs.length};
  let timers=[];window.setTimeout=(f,ms)=>{timers.push({t:now+(ms||0),f});return timers.length};
  window.__oneFrame=dtMs=>{now+=dtMs;const due=timers.filter(x=>x.t<=now);timers=timers.filter(x=>x.t>now);due.forEach(x=>x.f());const cur=cbs;cbs=[];cur.forEach(cb=>cb(now))};
  const fnv=s=>{let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}return h>>>0};
  const ids=['score','spd','best','mbest','ttl','msg','admm','admt','invb'];
  const hid=['hud','invb','home','menu','advm','wardrobe','card','admp','advq','admc','admg','admt','advc'];
  window.__dom=()=>{let r='';for(const i of ids){const e=document.getElementById(i);r+=i+'='+(e?e.textContent:'?')+'|'}for(const i of hid){const e=document.getElementById(i);r+=i+(e&&e.hidden?'H':'V')}r+=document.getElementById('spd').style.color+document.getElementById('mute').textContent+document.getElementById('advc').textContent+document.getElementById('advc').disabled;
    r+=[...document.getElementById('modes').children].map(c=>c.className).join(',')+[...document.getElementById('grid').children].map(c=>c.className).join(',');return fnv(r)};
  window.__cv=()=>fnv(document.getElementById('c').toDataURL());
  window.__pv=()=>{if(document.getElementById('wardrobe').hidden)return 0;let r='';document.querySelectorAll('canvas.pv').forEach(c=>r+=c.toDataURL().length+fnv(c.toDataURL())+',');return fnv(r)};
  let F=0;window.__resizes=0;addEventListener('resize',()=>{window.__resizes++});
  window.__run=(frames,dtMs,every,pat)=>{const out=[];
    for(let i=0;i<frames;i++,F++){
      if(pat){const k=(F+pat.phase)%pat.period;if(k===0)window.dispatchEvent(new KeyboardEvent('keydown',{key:' ',cancelable:true}));
        if(k===pat.hold)window.dispatchEvent(new KeyboardEvent('keyup',{key:' '}));}
      window.__oneFrame(dtMs);
      if(i%every===every-1||i===frames-1)out.push(window.__cv()+':'+window.__dom()+':'+window.__pv());
    }return out};
  window.__detail=()=>JSON.stringify({score:document.getElementById('score').textContent,card:document.getElementById('card').hidden,hud:document.getElementById('hud').hidden,spd:document.getElementById('spd').textContent,ttl:document.getElementById('ttl').textContent,home:document.getElementById('home').hidden,cw:document.getElementById('c').width,ch:document.getElementById('c').height,iw:innerWidth,ih:innerHeight});
  window.__click=id=>document.getElementById(id).click();
  window.__chip=(gridId,i)=>document.getElementById(gridId).querySelectorAll('.chip')[i].click();
  window.__key=(k,down)=>window.dispatchEvent(new KeyboardEvent(down?'keydown':'keyup',{key:k,cancelable:true}));
})();`;
async function main(){
  const srv=await require('./staticserver.js')(process.env.SERVE||require('path').join(__dirname,'serve'),+process.env.PORT||8124);
  const browser=await chromium.launch({args:['--no-sandbox']});
  async function open(which,viewport,pre){
    const ctx=await browser.newContext({viewport:viewport||{width:360,height:640},deviceScaleFactor:1});
    await ctx.addInitScript(INIT);if(pre)await ctx.addInitScript(pre);
    const page=await ctx.newPage();const errs=[];
    page.on('pageerror',e=>errs.push('PAGEERROR: '+e.message));
    page.on('console',m=>{if(m.type()==='error'&&!/Failed to load resource/.test(m.text()))errs.push('console.error: '+m.text())});
    await page.route('**/fonts.g*/**',r=>r.abort());
    await page.goto('http://localhost:'+(+process.env.PORT||8124)+'/'+which+'/index.html');
    await page.waitForTimeout(120);
    return {page,errs,ctx};
  }
  const results=[];let totalCmp=0;
  async function scenario(name,fn,opts={}){
    const A=await open('orig',opts.viewport,opts.pre),B=await open('mod',opts.viewport,opts.pre);
    const log={name,cmp:0,mism:[]};
    const both=async(code,arg)=>{const [a,b]=await Promise.all([A.page.evaluate(code,arg),B.page.evaluate(code,arg)]);return [a,b]};
    const click=async id=>{await both(id=>window.__click(id),id)};
    const run=async(frames,dt,every,pat,label)=>{
      const [a,b]=await both(([f,d,e,p])=>window.__run(f,d,e,p),[frames,dt,every,pat||null]);
      for(let i=0;i<Math.max(a.length,b.length);i++){log.cmp++;if(a[i]!==b[i]){log.mism.push((label||'')+' sample '+i+' (frame '+(i*every)+') '+a[i]+' vs '+b[i]);log.mism.push('ROWS A='+a.slice(0,8).map(x=>x.split(':')[0]).join(',')+' B='+b.slice(0,8).map(x=>x.split(':')[0]).join(','));break}}
      return [a,b];
    };
    const check=async(label)=>{const [a,b]=await both(()=>window.__cv()+':'+window.__dom()+':'+window.__pv());log.cmp++;if(a!==b)log.mism.push('check '+label+' '+a+' vs '+b)};
    try{await fn({both,click,run,check,A,B,log})}catch(e){log.mism.push('EXCEPTION '+e.message.slice(0,300))}
    log.errsA=A.errs;log.errsB=B.errs;
    if(log.mism.length){const [da,db]=await Promise.all([A.page.evaluate(()=>window.__detail()),B.page.evaluate(()=>window.__detail())]);log.mism.push('DETAIL orig='+da+' mod='+db);const [ra,rb]=await Promise.all([A.page.evaluate(()=>window.__resizes),B.page.evaluate(()=>window.__resizes)]);log.mism.push('(resize events orig='+ra+' mod='+rb+')')}
    if(opts.after)await opts.after(B.page,log);
    await A.ctx.close();await B.ctx.close();
    results.push(log);totalCmp+=log.cmp;
    console.log((log.mism.length||log.errsB.length?'FAIL ':'ok   ')+name.padEnd(34),'compared',String(log.cmp).padStart(5),log.mism.slice(0,6).join(' ; '),log.errsB.slice(0,2).join(' ; '),(log.errsA.length?'[orig errs:'+log.errsA.length+']':''));
  }
  const PAT={period:46,hold:9,phase:0};
  const only=process.argv[2];
  const S=(n,fn,o)=>(!only||n.includes(only))?scenario(n,fn,o):null;

  await S('boot: menu idle',async c=>{await c.check('menu');await c.run(60,16.7,10);});
  await S('classic run until death + restart',async c=>{
    await c.click('play');await c.run(5,16.7,1);await c.run(3,16.7,1,null);
    await c.both(()=>window.__key(' ',true));await c.both(()=>window.__key(' ',false));
    await c.run(1500,16.7,5,PAT,'run');
    await c.run(60,16.7,10,null,'over');
    await c.both(()=>{window.__key(' ',true);window.__key(' ',false)});
    await c.run(600,16.7,5,PAT,'restart');
  });
  await S('pointer input path',async c=>{
    await c.click('play');
    await c.both(()=>document.dispatchEvent(new PointerEvent('pointerdown',{bubbles:true,cancelable:true})));
    await c.run(20,16.7,2);
    await c.both(()=>window.dispatchEvent(new PointerEvent('pointerup',{bubbles:true})));
    await c.both(()=>document.dispatchEvent(new PointerEvent('pointerdown',{bubbles:true,cancelable:true})));
    await c.run(60,16.7,2);
  });
  await S('menu UI: modes, mute, admin, home',async c=>{
    for(let i=0;i<4;i++){await c.both(i=>window.__chip('modes',i),i);await c.check('mode'+i)}
    await c.click('mute');await c.check('mute');await c.click('mute');
    await c.click('adm');await c.check('adm panel');
    await c.both(()=>{const e=document.getElementById('admc');e.value='wrong';});await c.click('admg');await c.check('wrong code');
    await c.both(()=>{const e=document.getElementById('admc');e.value='safwanisinvincible';});await c.click('admg');await c.check('unlocked');
    await c.click('admt');await c.check('toggle inv');await c.click('admt');
    await c.click('play');await c.run(30,16.7,3);await c.click('home');await c.check('home');await c.run(20,16.7,5);
    await c.click('cust');await c.run(10,16.7,1);await c.click('done');await c.check('done');
  });
  await S('invincible marathon (all biomes)',async c=>{
    await c.click('adm');
    await c.both(()=>{document.getElementById('admc').value='safwanisinvincible'});await c.click('admg');
    await c.click('play');await c.run(2,16.7,1);
    const total=+process.env.MARATHON||26000;
    for(let k=0;k<total;k+=2000){await c.run(2000,33,10,{period:57,hold:11,phase:k%7},'seg'+k/2000);if(c.log.mism.length)break}
  },{after:async(page,log)=>{}});
  await S('modes medium/hard/impossible invincible',async c=>{
    await c.click('adm');await c.both(()=>{document.getElementById('admc').value='safwanisinvincible'});await c.click('admg');
    for(const m of [1,2,3]){await c.both(i=>window.__chip('modes',i),m);await c.click('play');await c.run(1,16.7,1);await c.run(2500,33,10,{period:51+m*3,hold:10,phase:m},'mode'+m);await c.click('home')}
  });
  await S('wardrobe: all outfits (preview+in-game)',async c=>{
    await c.click('cust');await c.run(4,16.7,1);await c.check('wardrobe open');
    for(let i=0;i<32;i++){
      await c.both(i=>window.__chip('grid',i),i);await c.run(2,16.7,1,null,'pv'+i);
      await c.click('done');await c.click('play');await c.run(1,16.7,1);
      await c.run(150,16.7,10,{period:46,hold:9,phase:0},'outfit'+i);
      await c.click('home');await c.click('cust');await c.run(2,16.7,1);
    }
  });
  const advSeed=(b,cl,p)=>`localStorage.setItem('dd-adv',JSON.stringify({b:${b},c:${cl},p:${p}}));`;
  await S('adventure: new game + 4000 frames',async c=>{
    await c.click('adv');await c.check('adv panel');await c.click('advn');await c.check('adv new');
    await c.run(3,16.7,1);await c.both(()=>{window.__key(' ',true);window.__key(' ',false)});
    await c.run(4000,33,10,{period:60,hold:12,phase:3},'adv');
  });
  for(const [b,cl,p,fr] of [[1,300,300,3000],[2,600,640,3000],[2,1100,1150,5200]]){
    await S(`adventure checkpoint b=${b} c=${cl}`,async c=>{
      await c.both(([b,cl,p])=>localStorage.setItem('dd-adv',JSON.stringify({b,c:cl,p})),[b,cl,p]);
      await c.click('adv');await c.check('panel');await c.click('advc');await c.check('continue');
      await c.run(3,16.7,1);await c.both(()=>{window.__key(' ',true);window.__key(' ',false)});
      await c.run(fr,33,10,{period:64,hold:12,phase:5},'advcp');
      await c.both(()=>{window.__key(' ',true);window.__key(' ',false)});await c.run(100,33,10,null,'after');
    });
  }
  await S('collisions: easy, no invincibility',async c=>{
    await c.click('play');await c.run(2,16.7,1);
    for(let k=0;k<12000;k+=3000){await c.run(3000,33,10,{period:43+k/3000*7,hold:8+k/3000,phase:k%5},'easy'+k);if(c.log.mism.length)break}
  });
  await S('collisions: hard + impossible',async c=>{
    for(const m of [2,3]){await c.both(i=>window.__chip('modes',i),m);await c.click('play');await c.run(2,16.7,1);await c.run(4000,33,10,{period:47+m,hold:9,phase:m},'mode'+m);await c.click('home')}
  });
  for(const [b,cl,p,fr] of [[1,300,300,9000],[2,600,600,9000]])
    await S(`collisions: adventure b=${b}, no invincibility`,async c=>{
      await c.both(([b,cl,p])=>localStorage.setItem('dd-adv',JSON.stringify({b,c:cl,p})),[b,cl,p]);
      await c.click('adv');await c.click('advc');await c.run(3,16.7,1);
      await c.both(()=>{window.__key(' ',true);window.__key(' ',false)});
      for(let k=0;k<fr;k+=3000){await c.run(3000,33,10,{period:52+b*4,hold:10,phase:b+k%3},'advnoinv'+k);if(c.log.mism.length)break}
    });
  await S('collisions: at crossings + temple',async c=>{
    await c.click('adm');await c.both(()=>{document.getElementById('admc').value='safwanisinvincible'});await c.click('admg');
    await c.click('play');await c.run(2,16.7,1);
    const probe=()=>c.B.page.evaluate(async()=>{const {state}=await import('./js/state.js');return {tr:state.tr?(state.tr.sea?'sea':'river'):null,tpOn:state.tpOn,bi:state.bi,st:state.st,score:state.score}});
    const seenTrig={river:0,sea:0,temple:0};let off=false,F=0;
    while(F<24000&&!c.log.mism.length){
      const p=await probe();
      const want=(p.tr==='river'&&seenTrig.river<2)?'river':(p.tr==='sea'&&seenTrig.sea<2)?'sea':(p.tpOn&&seenTrig.temple<2)?'temple':null;
      if(want&&!off){await c.click('admt');off=true;seenTrig[want]++;c.log.trig=(c.log.trig||'')+want+'@'+F+' ';
        await c.run(450,33,5,{period:57,hold:11,phase:F%7},'noinv-'+want+'@'+F);F+=450;
        // re-enable invincibility if the run is still alive and it is currently off
        await c.click('admt');off=false;
        // wait out the remainder of this feature with invincibility back on
        await c.run(900,33,10,{period:57,hold:11,phase:F%7},'after-'+want);F+=900;continue}
      await c.run(300,33,10,{period:57,hold:11,phase:F%7},'inv@'+F);F+=300;
      if(seenTrig.river>=2&&seenTrig.sea>=2&&seenTrig.temple>=2)break;
    }
  },{after:async(page,log)=>{console.log('   triggers:',log.trig)}});
  await S('resize to landscape tablet',async c=>{
    await c.click('play');await c.run(60,16.7,5,PAT,'first60');
    await Promise.all([c.A.page.setViewportSize({width:900,height:500}),c.B.page.setViewportSize({width:900,height:500})]);
    await Promise.all([c.A.page.waitForFunction(()=>window.__resizes>=1,null,{polling:25}),c.B.page.waitForFunction(()=>window.__resizes>=1,null,{polling:25})]);
    await c.run(2,16.7,1);await c.run(300,16.7,10,PAT,'landscape');
  });
  console.log('\nTOTAL compared samples:',totalCmp,'| scenarios failed:',results.filter(r=>r.mism.length||r.errsB.length).length,'of',results.length);
  await browser.close();srv.close();
}
main().catch(e=>{console.error(e);process.exit(1)});
