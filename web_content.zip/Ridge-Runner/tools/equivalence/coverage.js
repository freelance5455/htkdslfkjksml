// Runs ONLY the modular build and records which game features a scripted run actually exercised.
// Usage: node coverage.js   (env: FRAMES, SEED, MODE=adv, ADVSEED='{"b":1,"c":300,"p":300}', NOINV=1)
const {chromium}=require('playwright');const fs=require('fs');
const src=fs.readFileSync(require('path').join(__dirname,'compare.js'),'utf8');
const INIT=src.match(/const INIT=`([\s\S]*?)`;\nasync function main/)[1];
const SEED=+process.env.SEED||987654321;const FRAMES=+process.env.FRAMES||26000;const MODE=process.env.MODE||'';
(async()=>{
  const srv=await require('./staticserver.js')(process.env.SERVE||require('path').join(__dirname,'serve'),8127);
  const browser=await chromium.launch({args:['--no-sandbox']});
  const ctx=await browser.newContext({viewport:{width:360,height:640},deviceScaleFactor:1});
  await ctx.addInitScript(INIT.replace('let s=987654321','let s='+SEED));
  const page=await ctx.newPage();const errs=[];
  page.on('pageerror',e=>errs.push(e.message));page.on('console',m=>{if(m.type()==='error'&&!/Failed to load/.test(m.text()))errs.push(m.text())});
  await page.route('**/fonts.g*/**',r=>r.abort());
  await page.goto('http://localhost:8127/mod/index.html');
  const cov=await page.evaluate(async({frames,mode,noinv,advseed})=>{
    const {state}=await import('./js/state.js');const V=await import('./js/view.js');const T=await import('./js/jungle-temple.js');
    const ev={};let prevSt=null,prevRd=0,prevShield=0,seenPops=new Set();const seen={ev,st:{},bi:{},cross:{},cave:{},temple:{},ride:{},fx:{},fty:{},obs:{},items:{},drown:0,dwSea:0,advWon:0,maxScore:0};
    const add=(o,k)=>{o[k]=(o[k]||0)+1};
    const click=id=>document.getElementById(id).click();
    if(!noinv){click('adm');document.getElementById('admc').value='safwanisinvincible';click('admg');}
    if(mode==='adv'){if(advseed){localStorage.setItem('dd-adv',JSON.stringify(advseed));click('adv');click('advc');}else{click('adv');click('advn');}}
    else if(mode){const i={easy:0,medium:1,hard:2,imp:3}[mode];document.getElementById('modes').querySelectorAll('.chip')[i].click();click('play')}
    else click('play');
    window.__oneFrame(16.7);
    for(let i=0;i<frames;i++){
      const k=(i+3)%57;if(k===0)window.dispatchEvent(new KeyboardEvent('keydown',{key:' ',cancelable:true}));if(k===11)window.dispatchEvent(new KeyboardEvent('keyup',{key:' '}));
      window.__oneFrame(33);
      add(seen.st,state.st);add(seen.bi,state.bi);
      if(prevSt&&prevSt!==state.st)add(ev,prevSt+'->'+state.st);prevSt=state.st;
      if(prevRd&&!state.rd&&state.st==='play')add(ev,'ride lost (rd'+prevRd+')');prevRd=state.rd;
      if(prevShield&&!state.fx.shield)add(ev,'shield consumed');prevShield=state.fx.shield;
      for(const p of state.pops){if(!p._s){p._s=1;if(/lost|Shield broke/.test(p.t))add(ev,'pop: '+p.t)}}
      if(state.parts.length>20)add(ev,'splash burst');
      if(state.tr)add(seen.cross,state.tr.sea?'sea':'river');
      const u=V.u,px=V.px,W=V.W;
      if(state.st==='play'&&state.cs*10*u<1e8){const L=px+state.cs*10*u-state.dist,R=px+state.ce*10*u-state.dist;if(L<=W&&R>=0)add(seen.cave,state.cT?'ice':'rock')}
      if(state.tpOn){add(seen.temple,'on');if(T.tpFull())add(seen.temple,'underground')}
      add(seen.ride,'rd'+state.rd+(state.ob?'+boat':''));
      for(const k2 of ['ghost','magnet','x2','slow','shield','fly','fly2'])if(state.fx[k2]>0)add(seen.fx,k2);
      if(state.fty)add(seen.fty,'t'+state.fty);
      for(const o of state.obs){const key=(o.m?'mg:'+o.m:o.p?'pond':o.f>0?'flyer':o.b?(o.c?'ice-cave-gob':'snow'):'nature')+'@b'+o.b;add(seen.obs,key)}
      for(const it of state.items)add(seen.items,it.k);
      if(state.dw)seen.drown++;
      if(state.score>seen.maxScore)seen.maxScore=state.score;
    }
    return seen;
  },{frames:FRAMES,mode:MODE,noinv:!!process.env.NOINV,advseed:process.env.ADVSEED?JSON.parse(process.env.ADVSEED):null});
  console.log(JSON.stringify(cov,null,0));console.log('errors:',errs.length,errs.slice(0,3));
  await browser.close();srv.close();
})();
