// Tiny static server for the equivalence tools. `/orig/*` is served from ./serve/orig, `/mod/*` from the project root (../../).
const http=require('http'),fs=require('fs'),path=require('path');
const types={'.html':'text/html','.js':'text/javascript','.css':'text/css','.png':'image/png','.json':'application/json'};
module.exports=function start(root,port){
  const projectRoot=path.resolve(__dirname,'../..');
  return new Promise(res=>{
    const srv=http.createServer((req,rsp)=>{
      let p=decodeURIComponent(req.url.split('?')[0]);let f;
      if(p.startsWith('/mod/'))f=path.join(projectRoot,p.slice(5));else f=path.join(root,p);
      try{if(fs.statSync(f).isDirectory())f=path.join(f,'index.html');const b=fs.readFileSync(f);rsp.writeHead(200,{'content-type':types[path.extname(f)]||'application/octet-stream','cache-control':'no-store'});rsp.end(b)}
      catch(e){rsp.writeHead(404);rsp.end('not found')}
    }).listen(port,()=>res(srv));
  });
};
