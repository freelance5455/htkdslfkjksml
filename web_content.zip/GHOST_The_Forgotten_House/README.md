# GHOST: The Forgotten House — V7 Estate Expansion

A landscape-first, first-person 3D survival horror game for Android browsers. Built with HTML, CSS, JavaScript and Three.js. The environment, new room wing, props, equipment, gates and the updated ghost are generated using Three.js geometry.

## V7 highlights

- **61 mapped rooms:** the original five-room mansion core plus a connected 8 × 7 east wing containing 56 individually named rooms.
- **Hidden doors and passages:** a disguised bookcase entrance from the main house, a secret mirror-gallery passage and a concealed crypt passage. Switch on UV before interacting with a hidden panel.
- **Four escape routes:**
  1. **Front entrance:** find the brass key, note, fuse and exit key; restore power using keypad code `3142`.
  2. **Garden gate:** collect all three lost sigils in the east wing, open the garden gate, then walk outside.
  3. **Service tunnel:** find the iron key, restore power, unlock the tunnel hatch, then follow the tunnel outside.
  4. **Bell Tower forest path:** find the randomly placed Bell Tower Key, restore power, unlock the west-side gate, then follow the forest path outside.
- **Randomized object locations:** brass key, note, fuse, three sigils, iron key and Bell Tower Key change their room positions every time a new run starts. The map marks uncollected quest objects.
- **18 repositionable antiques:** porcelain dolls, urns, grandfather clocks, music boxes, cracked mirrors, trunks, busts, lanterns, gramophones, masks, keepsake boxes, candelabras, raven figurines, antique globes and Victorian telephones. Look at an antique and press USE to move it to another free display position elsewhere in the estate. Their starting rooms change on each run.
- **Updated ghost design:** The Veiled Warden, a floating Victorian caretaker in a torn mourning coat, long translucent veil, porcelain face covering, brass key chain, spectral hands and glowing eyes.
- **Ghost AI:** patrol, investigate, chase and search states, sound awareness, line-of-sight checks, pathfinding, hiding and protective ward interactions.
- **Unlimited paranormal equipment:** EMF, UV, sound lure, thermometer, spirit box, camera, protective ward and flashlight.
- **Android landscape interface:** touch joystick, touch camera-look, sprint, crouch, hide, interact, tools, map, inventory, health and pause menus.
- **Brighter room lighting:** room landmarks, ceiling lamps, reduced fog and an adjustable brightness setting.

## The 56 east-wing rooms

1. Grand Gallery
2. Portrait Chamber
3. Music Salon
4. Conservatory
5. West Study
6. East Study
7. Clock Chamber
8. Winter Room
9. Blue Drawing Room
10. Red Drawing Room
11. Candle Hall
12. Glasshouse
13. Library Annex
14. Map Room
15. Astronomy Room
16. Sewing Room
17. Servants Hall
18. Linen Room
19. Laundry
20. Pantry
21. Wine Cellar
22. Boiler Room
23. Furnace Room
24. Coal Store
25. Generator Room
26. Workshop
27. Toy Room
28. Doll Parlour
29. Nursery
30. Schoolroom
31. Old Chapel
32. Vestry
33. Bell Tower Base
34. Reliquary
35. Crypt Hall
36. Catacomb
37. Archive
38. Record Room
39. Forbidden Stacks
40. Taxidermy Room
41. Trophy Room
42. Mirror Gallery
43. Mask Room
44. Private Theatre
45. Costume Room
46. Ballroom
47. Banquet Room
48. Kitchen
49. Scullery
50. Cold Store
51. Billiards Room
52. Card Room
53. Smoking Room
54. Guest Suite
55. East Dormitory
56. Observatory

The five original core areas are the Entrance Hall, Living Room, Library, Bedroom and Basement.

## Run in Spck Editor on Android

1. Download and extract the ZIP into a new folder.
2. Open the extracted folder as a web project in Spck Editor.
3. Make sure `index.html`, `style.css`, `game.js`, `three-loader.js` and `manifest.webmanifest` are in the project root.
4. Open `index.html` using Spck Preview / its local web server. Do not use a `file://` URL; JavaScript modules need to be served over HTTP.
5. Keep an internet connection enabled because `three-loader.js` loads the pinned Three.js 0.160.0 module from jsDelivr and falls back to unpkg if the first CDN is unavailable.
6. Tap **ENTER THE HOUSE**. The project requests fullscreen and landscape orientation after the user gesture. If Spck Preview cannot lock Android's orientation, its CSS fallback rotates the game UI into a landscape layout.
7. Use Medium or Low graphics on older Android phones. High quality can be heavier because the expanded estate includes many room details and lights.

The included manifest requests landscape orientation for supported installed-web-app environments. This is a browser game project, not a compiled APK. Packaging a native APK requires a separate Android wrapper/build step.

## Android controls

- **Left joystick:** walk in any direction.
- **Right screen area:** drag to look around.
- **RUN:** hold to sprint; sprinting creates more noise.
- **CROUCH:** toggle quieter, slower movement.
- **HIDE:** enter or leave a nearby hiding spot.
- **USE:** interact with keys, notes, panels, secret doors, escape gates and antiques. Look at an object until its prompt appears.
- **LIGHT:** toggle the unlimited flashlight.
- **EMF:** display nearby ghost activity.
- **UV:** reveal marks on hidden panels; keep it on when using a secret door.
- **LURE:** repeatedly deploy a sound decoy.
- **TEMP:** read the paranormal temperature.
- **SPIRIT:** receive a contextual clue.
- **CAM:** take unlimited paranormal photographs.
- **WARD:** deploy a reusable protective field for seven seconds.
- **MAP:** view the 61-room estate, your position, secret doors, quest objects and all four escape routes. Opening the map pauses gameplay.
- **Ⅱ:** pause / resume.

## Desktop test controls

- `W A S D` or arrow keys: move.
- Drag the view: look around.
- `E`: interact.
- `Shift`: sprint; `C`: crouch; `H`: hide; `F`: flashlight.
- `M`: map; `N`: EMF; `U`: UV; `G`: sound lure; `T`: thermometer; `B`: spirit box; `P`: camera; `R`: ward.
- `Esc`: pause / resume.

## Object randomization and moving antiques

Each new game start or restart shuffles the quest objects among a set of room positions. Look for their colored markers on the map. All 18 movable antiques are also assigned new rooms on every run. Look directly at an antique and press USE to move it to a free display position elsewhere in the estate. Moving antiques is optional and does not block the escape objectives.

## Troubleshooting

- **Black screen / 3D engine did not start:** open the project from Spck Preview or a local HTTP server, enable internet access for the Three.js module, reload, and check that WebGL is enabled in the browser.
- **Landscape does not physically rotate:** some embedded previews block the orientation-lock API. Rotate the phone sideways; the game also has a CSS landscape fallback. For a native orientation lock, package/install it through a supported Android wrapper or installed web-app environment.
- **Slow performance:** choose Low or Medium graphics and close other browser tabs.
- **Touch controls do not respond:** tap ENTER THE HOUSE first; then use the left joystick and drag the right side of the screen to look.

## Project files

```text
GHOST_The_Forgotten_House/
├── index.html
├── style.css
├── game.js
├── three-loader.js
├── manifest.webmanifest
├── README.md
├── assets/
│   └── ghost-icon.svg
└── vendor/
    └── README.md
```
