# GHOST: The Forgotten House

A landscape-first, first-person 3D survival horror game for Android browsers. Built with HTML, CSS, JavaScript and Three.js. The house, props, ghost, pickups and interface are generated in code, so no external model packs are needed.

## Features

- Landscape-first layout with a rotate-device screen in portrait mode.
- Full-screen / landscape orientation request when starting (where the browser allows it).
- First-person 3D mansion with an entrance hall, living room, library, bedroom and basement.
- Touch joystick, touch-look camera, sprint, crouch, hide, interact, flashlight and pause controls.
- Keyboard controls for desktop testing.
- Ghost AI states: patrol, investigate, chase and search.
- Sound-based awareness, line-of-sight checks, simple pathfinding and difficulty settings.
- Collectible brass key, fuse and exit key; readable note; four-digit power keypad.
- Working hiding spots, flashlight battery, win / lose screens and settings.
- Procedural lighting, fog, dust particles and atmospheric ambient audio.
- PWA manifest with landscape orientation metadata.

## Run in Spck Editor (Android)

1. Extract the ZIP into a project folder.
2. Open the folder in Spck Editor as a web project.
3. Make sure these files are at the project root: `index.html`, `style.css`, `game.js` and `manifest.webmanifest`.
4. Open `index.html` using Spck's preview / local server. Do not open the file directly with a `file://` URL because JavaScript modules need an HTTP server.
5. Keep an internet connection enabled on first load because Three.js is imported from the jsDelivr CDN (version 0.160.0).
6. Rotate the phone to landscape, tap **ENTER THE HOUSE**, and allow full-screen / orientation access if the browser offers it.

The included manifest declares landscape orientation for compatible installed-web-app environments. Browser orientation locking is best-effort and depends on Android browser support; the in-game portrait overlay reminds the player to rotate the device.

## Controls

### Android touch controls

- **Left joystick:** move.
- **Drag the right side of the screen:** look around.
- **RUN:** sprint while held.
- **CROUCH:** toggle quieter, slower movement.
- **HIDE:** enter / leave a nearby wardrobe.
- **USE:** interact with the object in the centre of the view.
- **LIGHT:** toggle flashlight.
- **Ⅱ:** pause.

### Desktop test controls

- `W A S D` or arrow keys: move.
- Drag the right side of the game view: look around.
- `E`: interact.
- `Shift`: sprint.
- `C`: crouch.
- `H`: hide near a wardrobe.
- `F`: flashlight.
- `Esc`: pause.

## How to complete Chapter 1

1. Enter the house and find the **brass key** in the living room (west wing).
2. Read the note on the library table (east wing). It reveals the power code: **3142**.
3. Find the **fuse** in the bedroom (west rear room).
4. Go to the basement keypad (east rear room), interact, and enter **3142**. The fuse is consumed and the power is restored.
5. Open the basement key cabinet to collect the **exit key**.
6. Return to the entrance hall, face the front door and press **USE** to unlock it.
7. Walk through the open doorway to escape.

The ghost awakens when the brass key is collected. Use crouching to reduce noise and wardrobes to hide. Running is faster but attracts attention over a larger distance.

## Graphics / gameplay settings

- **Low:** reduced pixel ratio and shadows disabled.
- **Medium:** balanced mobile rendering.
- **High:** higher pixel ratio and flashlight shadows (device permitting).
- **Difficulty:** changes ghost movement speed and detection range.
- **Look sensitivity:** adjusts touch-look speed.
- **Sound volume:** controls the generated ambient drone and feedback sounds.

## Project files

```text
GHOST_The_Forgotten_House/
├── index.html
├── style.css
├── game.js
├── manifest.webmanifest
├── README.md
├── assets/
│   └── ghost-icon.svg
└── vendor/
    └── README.md
```

## Important notes

- This ZIP contains the complete web-game source project, not a compiled APK. An APK requires a separate Android packaging step (for example, a WebView wrapper / Capacitor project).
- Three.js is loaded from the CDN, so the first launch needs internet. The source project itself is included in the ZIP, but the third-party Three.js library is not vendored in this package.
- Performance varies by Android device and browser. Start with Low or Medium graphics on older phones.
- All game code and concept content in this project are original to this project. Third-party library use remains subject to the library's own license.
