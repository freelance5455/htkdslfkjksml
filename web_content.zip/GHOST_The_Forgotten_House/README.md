# GHOST: The Forgotten House

A landscape-first, first-person 3D survival horror game for Android browsers. Built with HTML, CSS, JavaScript and Three.js. The house, props, ghost, pickups and interface are generated in code, so no external model packs are needed.

## Features

- Landscape-first layout with an automatic CSS-rotated landscape fallback in portrait-locked browser previews.
- Full-screen / landscape orientation request when starting (where the browser allows it). If browser orientation locking is unavailable, the game rotates its own display into landscape rather than showing a blocking rotate message.
- First-person 3D mansion with an entrance hall, living room, library, bedroom and basement.
- Touch joystick, touch-look camera, sprint, crouch, hide, interact, flashlight, expanded field-equipment bar, map and pause controls.
- Keyboard controls for desktop testing.
- Ghost AI states: patrol, investigate, chase and search.
- Sound-based awareness, line-of-sight checks, simple pathfinding and difficulty settings.
- Collectible brass key, fuse and exit key; readable note; four-digit power keypad.
- Working hiding spots, flashlight battery, health/vitals display, win / lose screens and settings.
- Brighter, clearer room lighting with an entrance chandelier, frosted windows, corridor sconces, reduced fog and vignette, a stronger flashlight, and an adjustable Scene brightness setting.
- Procedural dust particles and atmospheric ambient audio; the horror mood remains without hiding room details.
- Player-facing startup help uses plain setup instructions instead of displaying raw JavaScript error traces over the game.
- PWA manifest with landscape orientation metadata.

## Run in Spck Editor (Android)

1. Extract the ZIP into a project folder.
2. Open the folder in Spck Editor as a web project.
3. Make sure these files are at the project root: `index.html`, `style.css`, `game.js` and `manifest.webmanifest`.
4. Open `index.html` using Spck's preview / local server. Do not open the file directly with a `file://` URL because JavaScript modules need an HTTP server.
5. Keep an internet connection enabled on first load because `three-loader.js` downloads the pinned Three.js 0.160.0 module from jsDelivr, with unpkg as a fallback.
6. Tap **ENTER THE HOUSE**. The game requests fullscreen and landscape orientation from that tap.
7. If the preview cannot rotate Android itself, the game rotates its own display into a landscape-shaped view. Turn the phone sideways to view that layout upright.

The included manifest declares landscape orientation for compatible installed-web-app environments. For the most reliable automatic device orientation, install the project as a web app from a supported Android browser (open the hosted project, then use the browser menu and choose **Install app** or **Add to Home screen**). Spck preview and embedded browser views may block the browser orientation-lock API; the in-game CSS fallback handles that case.

## Controls

### Android touch controls

- **Left joystick:** move.
- **Drag the right side of the screen:** look around.
- **RUN:** sprint while held.
- **CROUCH:** toggle quieter, slower movement.
- **HIDE:** enter / leave a nearby wardrobe.
- **USE:** interact with the object in the centre of the view.
- **LIGHT:** toggle flashlight.
- **EMF:** toggle the detector; the percentage rises as the ghost gets closer.
- **UV:** toggle the scanner to reveal hidden marks.
- **LURE:** deploy a reusable sound decoy to distract the ghost.
- **TEMP:** toggle the paranormal thermometer; colder readings indicate nearby activity.
- **SPIRIT:** ask the spirit box for a contextual clue about the next objective.
- **CAM:** take an unlimited photograph; clear ghost photos increase the evidence counter.
- **WARD:** deploy a reusable protective field that repels the ghost for seven seconds.
- All equipment is unlimited: no tool charges or battery depletion.
- **MAP:** open the mansion map (the game pauses while the map is open).
- **Ⅱ:** pause.

### Desktop test controls

- `W A S D` or arrow keys: move.
- Drag the right side of the game view: look around.
- `E`: interact.
- `Shift`: sprint.
- `C`: crouch.
- `H`: hide near a wardrobe.
- `F`: flashlight.
- `M`: open the mansion map.
- `N`: EMF; `U`: UV; `G`: sound lure; `T`: thermometer; `B`: spirit box; `P`: camera; `R`: protective ward.
- `Esc`: pause / resume.

## How to complete Chapter 1

1. Enter the house and find the **brass key** in the living room (west wing).
2. Read the note on the library table (east wing). It reveals the power code: **3142**.
3. Find the **fuse** in the bedroom (west rear room).
4. Go to the basement keypad (east rear room), interact, and enter **3142**. The fuse is consumed and the power is restored.
5. Open the basement key cabinet to collect the **exit key**.
6. Return to the entrance hall, face the front door and press **USE** to unlock it.
7. Walk through the open doorway to escape.

The ghost awakens when the brass key is collected. Use crouching to reduce noise and wardrobes to hide. Running is faster but attracts attention over a larger distance. The EMF detector displays nearby supernatural activity; the UV scanner reveals hidden purple marks; and a sound lure can draw the ghost toward a different part of the house. Open MAP to check room names, objectives and your position. The map pauses the game while it is open.

## Graphics / gameplay settings

- **Low:** reduced pixel ratio and shadows disabled.
- **Medium:** balanced mobile rendering.
- **High:** higher pixel ratio and flashlight shadows (device permitting).
- **Difficulty:** changes ghost movement speed and detection range.
- **Look sensitivity:** adjusts touch-look speed.
- **Sound volume:** controls the generated ambient drone and feedback sounds.
- **Scene brightness:** adjusts the 3D renderer exposure from 1.0× to 1.8×; the default is 1.38× for clearer mobile visibility.

## Project files

```text
GHOST_The_Forgotten_House/
├── index.html
├── style.css
├── game.js
├── three-loader.js
├── manifest.webmanifest
├── README.md
├── assets/
│   └── ghost-icon.svg
└── vendor/
    └── README.md
```

## Important notes

- This ZIP contains the complete web-game source project, not a compiled APK. An APK requires a separate Android packaging step (for example, a WebView wrapper / Capacitor project).
- Three.js is loaded from the CDN, so the first launch needs internet. The source project itself is included in the ZIP, but the third-party Three.js library is not vendored in this package. Keep internet access enabled so the browser can load Three.js from either CDN. If it cannot start, the game now shows a short setup message instead of raw debug text.
- Performance varies by Android device and browser. Start with Low or Medium graphics on older phones.
- All game code and concept content in this project are original to this project. Third-party library use remains subject to the library's own license.


## Version 6 upgrade — unlimited field kit

- Removed the two-use limit from the sound lure.
- Removed flashlight and UV battery depletion. The HUD now clearly shows unlimited equipment power.
- Added a paranormal thermometer with a distance-based temperature reading.
- Added a spirit box that gives contextual hints based on chapter progress.
- Added a paranormal camera with a flash effect and an evidence counter when the ghost is clearly in frame.
- Added a reusable protective ward that repels the ghost while active.
- Added an expanded seven-tool equipment bar, with horizontal scrolling on narrow screens.
- Improved pause, map and modal behaviour to clear stuck movement inputs; improved sprint pointer capture and background-tab handling.
- Optimized ghost pathfinding queue handling for mobile devices.

## Version 5 upgrade

- A more recognizable hooded ghost design with a dark face, luminous eyes, layered translucent robe, floating aura and arm animation.
- Three field tools: EMF detector, UV scanner and two-use sound lure. The EMF reads stronger as the ghost approaches; with EMF active, a nearby ghost is shown on the map. UV reveals three hidden supernatural marks. A sound lure creates a noise source that can draw the ghost away, including while the player is hidden.
- Mansion map with labeled rooms, player direction, current objective markers and a legend. Opening the map pauses gameplay.
- Improved playing-area detail: entrance chandelier, frosted side windows and corridor wall lights.
- Health/vitals bar and a more organized equipment HUD.

