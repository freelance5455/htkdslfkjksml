// Loads the pinned Three.js version from two public CDNs.
// This keeps the game source local while allowing a fallback if one CDN is unavailable.
const THREE_SOURCES = [
  'https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js',
  'https://unpkg.com/three@0.160.0/build/three.module.js'
];

let threeModule = null;
for (const source of THREE_SOURCES) {
  try {
    threeModule = await import(source);
    break;
  } catch (error) {
    console.warn('Three.js source unavailable; trying the next source.');
  }
}

if (!threeModule) {
  throw new Error('The 3D engine could not be downloaded. Check the internet connection and reload.');
}

export default threeModule;
