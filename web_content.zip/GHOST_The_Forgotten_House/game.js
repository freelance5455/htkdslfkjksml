import THREE from './three-loader.js';

// GHOST: The Forgotten House — landscape-first mobile horror prototype.
// All environments and props are generated from Three.js geometry so the
// project runs without downloading model or texture packs.

const $ = (id) => document.getElementById(id);
const canvas = $('game-canvas');
const ui = {
  hud: $('hud'), controls: $('touch-controls'), crosshair: $('crosshair'), roomName: $('room-name'),
  start: $('start-screen'), pause: $('pause-screen'), settings: $('settings-screen'),
  end: $('end-screen'), objective: $('objective-text'), inventory: $('inventory-items'),
  battery: $('battery-value'), batteryFill: $('battery-fill'), warning: $('ghost-warning'),
  prompt: $('interaction-prompt'), toast: $('toast'), damage: $('damage-flash'),
  note: $('note-screen'), keypad: $('keypad-screen'), keypadDisplay: $('keypad-display'),
  keypadMessage: $('keypad-message'), endKicker: $('end-kicker'), endTitle: $('end-title'),
  endDescription: $('end-description'), map: $('map-screen'), mapCanvas: $('map-canvas'),
  healthFill: $('health-fill'), emfLevel: $('emf-level'), mapStatus: $('map-status'),
  thermoValue: $('thermo-value'), cameraCount: $('camera-count'), cameraFlash: $('camera-flash')
};

const settings = { quality: 'medium', difficulty: 'normal', sensitivity: 1, volume: 0.6, brightness: 1.38 };
const state = {
  started: false, paused: true, ended: false, hidden: false, crouching: false,
  running: false, flashlight: true, battery: 100, elapsed: 0, ghostActive: false,
  powerOn: false, exitOpen: false, keypadInput: '', toastTimer: 0, warningTimer: 0,
  health: 1, lastNoiseAt: -999, lastNoise: new THREE.Vector3(0, 0, 0),
  inventory: new Set(), noteRead: false, panelUsed: false, ghostState: 'patrol',
  ghostStateTime: 0, lastSeenAt: -999, lastKnown: new THREE.Vector3(0, 0, 0),
  aiPathTimer: 0, ghostPath: [], hideSpot: null, damageCooldown: 0,
  emfOn: false, uvOn: false, thermoOn: false, lureActiveUntil: 0, mapOpen: false,
  cameraEvidence: 0, wardActiveUntil: 0, wardPosition: new THREE.Vector3(),
  sigilCount: 0, gardenExitOpen: false, tunnelExitOpen: false, bellExitOpen: false, currentRoom: 'Entrance Hall',
  visionTimer: 0, cachedSeesPlayer: false, haunterType: 'warden'
};

let scene, camera, renderer, clock, flashlight, flashlightTarget, uvLight, uvTarget, ghost, ghostLight, lureBeacon, wardField, wardLight;
let player = new THREE.Vector3(0, 0, 8.2);
let yaw = Math.PI, pitch = 0; // Looking toward the central hallway (-Z).
let joystick = { x: 0, y: 0, pointer: null };
let lookPointer = null, previousLook = null;
let interactables = [], colliders = [], wallMeshes = [], hideSpots = [];
let roomLights = [], dust = null, exitDoor, exitCollider = null, cabinetKey, cabinetRoot = null, cabinetCollider = null, keypadRoot;
let uvClues = [], mapDrawTimer = 0;
let currentTarget = null, audioContext = null, masterGain = null;
const raycaster = new THREE.Raycaster();
const tempForward = new THREE.Vector3();
const tempRight = new THREE.Vector3();
const tempVec = new THREE.Vector3();
const WORLD = { minX: -10.2, maxX: 81.8, minZ: -32.8, maxZ: 28.8 };
const WING = { x0: 14, z0: -24.5, cols: 8, rows: 7, size: 7 };
const roomRecords = [];
const secretDoors = [];
const escapeGates = [];
const randomizedPickups = [];
const movableProps = [];
let wingSpawnPoints = [];
let movableObjectSlots = [];
let mainSecretDoor = null;

// In Android browser previews the page may be locked to portrait. In that
// case CSS rotates the game shell; render using the matching landscape size.
function usesRotatedPortraitLayout() {
  return window.matchMedia('(orientation: portrait) and (max-width: 700px)').matches;
}
function getGameViewport() {
  return usesRotatedPortraitLayout()
    ? { width: Math.max(window.innerWidth, window.innerHeight), height: Math.min(window.innerWidth, window.innerHeight) }
    : { width: window.innerWidth, height: window.innerHeight };
}

function material(color, roughness = 0.9, extra = {}) {
  return new THREE.MeshStandardMaterial({ color, roughness, ...extra });
}
const mats = {
  floor: material(0x3b3c3d), wood: material(0x594938), woodDark: material(0x393027),
  wall: material(0x505154), wallAlt: material(0x464346), trim: material(0x292b2e),
  brass: material(0xb28b4d, 0.38, { metalness: 0.55 }), paper: material(0xcfc4a6),
  glass: new THREE.MeshStandardMaterial({ color: 0x9fc6d5, roughness: 0.18, metalness: 0.15, transparent: true, opacity: 0.38 }),
  ghost: new THREE.MeshStandardMaterial({ color: 0xd9f4f6, roughness: 0.26, metalness: 0.02, transparent: true, opacity: 0.72, emissive: 0x4a9eae, emissiveIntensity: 1.15, side: THREE.DoubleSide }),
  ghostFace: new THREE.MeshBasicMaterial({ color: 0x07121a }),
  eye: new THREE.MeshBasicMaterial({ color: 0xb9ffff }),
  ghostCoat: new THREE.MeshStandardMaterial({ color: 0x18252e, roughness: 0.62, transparent: true, opacity: 0.88, emissive: 0x10232b, emissiveIntensity: 0.42, side: THREE.DoubleSide }),
  ghostVeil: new THREE.MeshStandardMaterial({ color: 0x607b84, roughness: 0.4, transparent: true, opacity: 0.42, emissive: 0x183c48, emissiveIntensity: 0.62, side: THREE.DoubleSide }),
  ghostTrim: material(0x9a8158, 0.42, { metalness: 0.45 }),
  ghostMask: new THREE.MeshStandardMaterial({ color: 0xd7d2c1, roughness: 0.85, transparent: true, opacity: 0.86, side: THREE.DoubleSide }),
  red: material(0x662d33), metal: material(0x55565a, 0.4, { metalness: 0.65 })
};

function addBox(name, x, y, z, w, h, d, mat, { collider = false, parent = scene, cast = true, receive = true } = {}) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
  mesh.name = name;
  mesh.position.set(x, y, z);
  mesh.castShadow = cast;
  mesh.receiveShadow = receive;
  parent.add(mesh);
  if (collider) colliders.push({ x, z, hw: w / 2, hd: d / 2 });
  return mesh;
}

function addWall(x, z, w, d, height = 4.3, mat = mats.wall) {
  const mesh = addBox('wall', x, height / 2, z, w, height, d, mat, { collider: true });
  wallMeshes.push(mesh);
  // A narrow baseboard makes the room edges easier to read in low light.
  addBox('baseboard', x, 0.12, z, w, 0.24, d + 0.025, mats.trim, { cast: false });
  return mesh;
}

function addInteractable(root, action, label, range = 3.2) {
  root.userData.action = action;
  root.userData.label = label;
  root.userData.range = range;
  root.traverse((child) => {
    if (child.isMesh) {
      child.userData.action = action;
      child.userData.label = label;
      child.userData.range = range;
    }
  });
  interactables.push(root);
  return root;
}

function addFurnitureBox(x, y, z, w, h, d, mat, collision = true) {
  return addBox('furniture', x, y, z, w, h, d, mat, { collider: collision });
}

function createRoomDecor() {
  // Entrance hall: rug, console and framed portraits.
  addBox('hall rug', 0, 0.015, 7.5, 5.2, 0.025, 3.5, material(0x33272a));
  addFurnitureBox(0, 0.52, 4.25, 2.8, 1.04, 0.65, mats.woodDark);
  addBox('console top', 0, 1.08, 4.25, 3.0, 0.12, 0.78, mats.wood);
  addBox('portrait frame', -5.5, 2.4, 3.17, 1.15, 1.5, 0.12, mats.brass, false);
  addBox('portrait canvas', -5.5, 2.4, 3.095, 0.98, 1.31, 0.035, material(0x20252b), false);
  addBox('portrait frame', 5.5, 2.4, 3.17, 1.15, 1.5, 0.12, mats.brass, false);
  addBox('portrait canvas', 5.5, 2.4, 3.095, 0.98, 1.31, 0.035, material(0x252127), false);

  // Living room furniture, west side.
  addFurnitureBox(-7.7, 0.55, -1.6, 2.1, 1.1, 1.0, mats.woodDark);
  addFurnitureBox(-5.3, 0.42, -6.1, 2.0, 0.84, 1.0, mats.red);
  addFurnitureBox(-8.8, 0.65, -4.0, 0.75, 1.3, 0.75, mats.wood);
  addBox('shelf', -9.35, 1.45, -2.5, 0.35, 2.7, 2.7, mats.woodDark, { collider: true });
  for (let i = 0; i < 5; i++) addBox('book', -9.12, 0.45 + i * 0.27, -3.4 + (i % 2) * 0.18, 0.12, 0.2, 0.32, material([0x52343a,0x31404a,0x756044,0x343b31,0x594a60][i]), { cast: false });

  // Library, east side.
  addFurnitureBox(8.8, 1.35, -3.8, 0.45, 2.7, 6.6, mats.woodDark);
  addFurnitureBox(5.2, 0.55, -1.5, 2.1, 1.1, 1.0, mats.wood);
  addBox('library table top', 5.2, 1.12, -1.5, 2.4, 0.12, 1.2, mats.woodDark);
  for (let i = 0; i < 7; i++) addBox('book', 8.53, 0.58 + (i % 3) * 0.32, -6.3 + i * 0.65, 0.12, 0.25, 0.5, material([0x55403a,0x2c4148,0x66563d,0x354034][i % 4]), { cast: false });

  // Bedroom, west rear.
  addFurnitureBox(-6.4, 0.42, -10.0, 3.2, 0.84, 4.0, mats.woodDark);
  addBox('mattress', -6.4, 0.92, -10.0, 3.0, 0.3, 3.7, material(0x5c5250));
  addBox('pillow', -6.4, 1.14, -11.35, 1.2, 0.18, 0.75, material(0xb2aaa0));
  addFurnitureBox(-9.0, 0.55, -14.9, 0.65, 1.1, 0.75, mats.wood);

  // Basement, east rear.
  addFurnitureBox(8.5, 0.75, -14.2, 1.0, 1.5, 1.0, mats.metal);
  addBox('pipe', 3.0, 3.5, -13.6, 0.18, 0.18, 5.0, mats.metal, { collider: false });
  addBox('pipe', 3.0, 3.1, -10.9, 0.18, 0.18, 0.18, mats.metal, { collider: false });

  // Lamps and lights create distinct room silhouettes.
  const lampSpecs = [
    [-6.7, 2.5, -3.7, 0xb58e61], [6.5, 2.5, -3.7, 0x8f9caf],
    [-6.5, 2.5, -12.0, 0xb58e61], [6.5, 2.5, -12.0, 0x9daab5],
    [0, 3.2, 7.0, 0x9e8d72]
  ];
  for (const [x,y,z,color] of lampSpecs) {
    const bulb = new THREE.PointLight(color, 1.05, 11, 1.8);
    bulb.position.set(x, y, z); scene.add(bulb); roomLights.push(bulb);
    const shade = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.34, 0.35, 10), mats.woodDark);
    shade.position.set(x, y + 0.15, z); scene.add(shade);
  }
}

function createPlayingAreaDetails() {
  // A warm chandelier gives the entrance hall a readable landmark.
  const chandelier = new THREE.Group();
  chandelier.position.set(0, 3.55, 7.0);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(0.82, 0.055, 8, 28), mats.brass);
  ring.rotation.x = Math.PI / 2;
  chandelier.add(ring);
  const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.065, 0.65, 10), mats.brass);
  stem.position.y = 0.43;
  chandelier.add(stem);
  for (let i = 0; i < 6; i++) {
    const a = i * Math.PI / 3;
    const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.105, 10, 8), new THREE.MeshBasicMaterial({ color: 0xffd991 }));
    bulb.position.set(Math.cos(a) * 0.73, -0.16, Math.sin(a) * 0.73);
    chandelier.add(bulb);
    const light = new THREE.PointLight(0xffcf8a, 0.24, 3.2, 2);
    light.position.copy(bulb.position);
    chandelier.add(light);
  }
  scene.add(chandelier);

  // Tall frosted windows help players read the room silhouettes.
  for (const side of [-1, 1]) {
    for (const z of [-4.4, -10.4]) {
      const frame = new THREE.Group();
      frame.position.set(side * 9.76, 2.35, z);
      frame.rotation.y = side < 0 ? Math.PI / 2 : -Math.PI / 2;
      const glassMat = new THREE.MeshStandardMaterial({ color: 0x8eb6c9, emissive: 0x345466, emissiveIntensity: 0.38, transparent: true, opacity: 0.68, roughness: 0.2 });
      const pane = new THREE.Mesh(new THREE.BoxGeometry(1.55, 2.0, 0.055), glassMat);
      frame.add(pane);
      for (const x of [-0.84, 0.84]) {
        const bar = new THREE.Mesh(new THREE.BoxGeometry(0.10, 2.25, 0.12), mats.woodDark);
        bar.position.x = x; frame.add(bar);
      }
      for (const y of [-1.12, 1.12]) {
        const bar = new THREE.Mesh(new THREE.BoxGeometry(1.78, 0.10, 0.12), mats.woodDark);
        bar.position.y = y; frame.add(bar);
      }
      const crossbar = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.07, 0.10), mats.woodDark);
      frame.add(crossbar);
      scene.add(frame);
    }
  }

  // Small wall sconces make the corridor and rear rooms easier to navigate.
  const sconceSpecs = [[-1.85, 2.55, 1.1], [1.85, 2.55, 1.1], [-1.85, 2.55, -7.0], [1.85, 2.55, -7.0], [-1.85, 2.55, -13.9], [1.85, 2.55, -13.9]];
  for (const [x, y, z] of sconceSpecs) {
    const lamp = new THREE.PointLight(0xffd9a2, 0.55, 5.2, 1.8);
    lamp.position.set(x * 1.4, y, z); scene.add(lamp); roomLights.push(lamp);
    const shade = new THREE.Mesh(new THREE.SphereGeometry(0.12, 10, 8), new THREE.MeshBasicMaterial({ color: 0xffd9a2 }));
    shade.position.copy(lamp.position); scene.add(shade);
  }
}

function createUVClues() {
  const specs = [[-9.72, 2.0, -5.0, Math.PI / 2], [9.72, 2.0, -10.0, -Math.PI / 2], [0.0, 2.25, -15.72, 0]];
  for (const [x, y, z, rotationY] of specs) {
    const mark = new THREE.Group();
    mark.position.set(x, y, z); mark.rotation.y = rotationY;
    const runeMat = new THREE.MeshBasicMaterial({ color: 0x9c80ff, transparent: true, opacity: 0.94 });
    const outer = new THREE.Mesh(new THREE.TorusGeometry(0.24, 0.035, 7, 22), runeMat);
    mark.add(outer);
    const slash = new THREE.Mesh(new THREE.BoxGeometry(0.055, 0.58, 0.035), runeMat);
    slash.rotation.z = 0.45; mark.add(slash);
    const dot = new THREE.Mesh(new THREE.SphereGeometry(0.065, 8, 8), runeMat);
    dot.position.y = 0.37; mark.add(dot);
    mark.visible = false; scene.add(mark); uvClues.push(mark);
  }
}

function createWorld() {
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x394957);
  // Keep a little atmospheric depth, but avoid the nearly opaque darkness
  // that made rooms hard to read on mobile displays.
  scene.fog = new THREE.FogExp2(0x314653, 0.0085);
  const viewport = getGameViewport();
  camera = new THREE.PerspectiveCamera(74, viewport.width / viewport.height, 0.08, 75);
  camera.rotation.order = 'YXZ';
  camera.position.set(player.x, 1.62, player.z);
  try {
    renderer = new THREE.WebGLRenderer({ canvas, antialias: settings.quality !== 'low', powerPreference: 'high-performance', failIfMajorPerformanceCaveat: false });
  } catch (firstError) {
    // A non-antialiased, low-power renderer is more compatible with older phones.
    try { renderer = new THREE.WebGLRenderer({ canvas, antialias: false, powerPreference: 'low-power', failIfMajorPerformanceCaveat: false }); }
    catch (secondError) { throw new Error('WebGL is unavailable on this device or browser.'); }
  }
  renderer.setPixelRatio(Math.min(devicePixelRatio || 1, settings.quality === 'high' ? 1.5 : 1.1));
  renderer.setSize(viewport.width, viewport.height, false);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = settings.brightness;
  renderer.shadowMap.enabled = settings.quality !== 'low';
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;

  scene.add(new THREE.HemisphereLight(0xc6d8e8, 0x514b43, 0.95));
  scene.add(new THREE.AmbientLight(0xa9b8c5, 0.38));
  const moon = new THREE.DirectionalLight(0xb8cde0, 0.92);
  moon.position.set(-7, 12, 8); moon.castShadow = settings.quality === 'high';
  moon.shadow.mapSize.set(768, 768); scene.add(moon);

  // Continuous floor with dark wood strips.
  addBox('floor', 0, -0.18, -2, 20, 0.36, 28, mats.floor, { cast: false });
  for (let z = -15; z <= 10; z += 2) {
    addBox('floor plank seam', 0, 0.006, z, 19.7, 0.008, 0.025, material(0x171a1d), { cast: false });
  }
  addBox('ceiling', 0, 4.5, -2, 20, 0.25, 28, material(0x202327), { cast: false });
  addBox('exit porch', 0, -0.12, 13.3, 4.4, 0.18, 3.0, material(0x343a40), { cast: false });

  // Outer walls, leaving a two-metre gap for the front exit door.
  addWall(-10, -2, 0.4, 28.4, 4.5);
  // The east wall has a disguised secret-entry opening into the 56-room wing.
  addWall(10, 3.15, 0.4, 18.1, 4.5);
  addWall(10, -12.15, 0.4, 8.1, 4.5);
  addWall(0, -16, 20.4, 0.4, 4.5);
  addWall(-5.55, 12, 8.9, 0.4, 4.5);
  addWall(5.55, 12, 8.9, 0.4, 4.5);

  // Corridor side walls. Openings at z=-4 and z=-12 lead into four rooms.
  for (const x of [-2.15, 2.15]) {
    addWall(x, -14.55, 0.32, 2.9);
    addWall(x, -8.95, 0.32, 5.7);
    addWall(x, -1.4, 0.32, 2.8);
  }
  // Entrance hall feeds into the central corridor.
  addWall(-6.05, 3, 7.9, 0.32);
  addWall(6.05, 3, 7.9, 0.32);
  // Separate front/rear wings with door-sized openings.
  addWall(-6, -8, 8.0, 0.32);
  addWall(6, -8, 8.0, 0.32);
  // Door jambs make all room openings legible.
  for (const x of [-2.15, 2.15]) for (const z of [-4, -12]) {
    addBox('door jamb', x, 2.05, z - 1.1, 0.34, 4.1, 0.18, mats.woodDark, { collider: true });
    addBox('door jamb', x, 2.05, z + 1.1, 0.34, 4.1, 0.18, mats.woodDark, { collider: true });
  }

  // Exit door is a pivoted slab; its collider is removed after unlocking.
  exitDoor = new THREE.Group();
  exitDoor.position.set(-1.05, 0, 11.78);
  const doorSlab = new THREE.Mesh(new THREE.BoxGeometry(2.1, 3.6, 0.22), mats.woodDark);
  doorSlab.position.set(1.05, 1.8, 0); doorSlab.castShadow = true; exitDoor.add(doorSlab);
  const doorPanel = new THREE.Mesh(new THREE.BoxGeometry(1.65, 2.9, 0.05), mats.wood);
  doorPanel.position.set(1.05, 1.8, -0.13); exitDoor.add(doorPanel);
  const knob = new THREE.Mesh(new THREE.SphereGeometry(0.09, 10, 8), mats.brass);
  knob.position.set(0.3, 1.65, -0.24); exitDoor.add(knob);
  scene.add(exitDoor);
  exitCollider = { x: 0, z: 11.78, hw: 1.06, hd: 0.22, exit: true };
  colliders.push(exitCollider);
  addInteractable(exitDoor, 'exit', 'LOCKED EXIT', 3.4);

  createRoomDecor();
  createPlayingAreaDetails();
  createGrandWing();
  createMovableAntiques();
  createPickupsAndPuzzles();
  createGhost();
  createUVClues();
  createDust();
  createFlashlight();
  createEquipmentLights();
}


const WING_ROOM_NAMES = [
  'Grand Gallery','Portrait Chamber','Music Salon','Conservatory','West Study','East Study','Clock Chamber','Winter Room',
  'Blue Drawing Room','Red Drawing Room','Candle Hall','Glasshouse','Library Annex','Map Room','Astronomy Room','Sewing Room',
  'Servants Hall','Linen Room','Laundry','Pantry','Wine Cellar','Boiler Room','Furnace Room','Coal Store',
  'Generator Room','Workshop','Toy Room','Doll Parlour','Nursery','Schoolroom','Old Chapel','Vestry',
  'Bell Tower Base','Reliquary','Crypt Hall','Catacomb','Archive','Record Room','Forbidden Stacks','Taxidermy Room',
  'Trophy Room','Mirror Gallery','Mask Room','Private Theatre','Costume Room','Ballroom','Banquet Room','Kitchen',
  'Scullery','Cold Store','Billiards Room','Card Room','Smoking Room','Guest Suite','East Dormitory','Observatory'
];

function wingRoomCenter(col, row) {
  return new THREE.Vector3(WING.x0 + WING.size * (col + 0.5), 0, WING.z0 + WING.size * (row + 0.5));
}
function addVerticalWallGap(x, z, length, gap = 1.85) {
  const side = (length - gap) / 2;
  if (side > 0.08) {
    addWall(x, z - gap / 2 - side / 2, 0.24, side, 4.25, mats.wallAlt);
    addWall(x, z + gap / 2 + side / 2, 0.24, side, 4.25, mats.wallAlt);
  }
}
function addHorizontalWallGap(x, z, length, gap = 1.85) {
  const side = (length - gap) / 2;
  if (side > 0.08) {
    addWall(x - gap / 2 - side / 2, z, side, 0.24, 4.25, mats.wallAlt);
    addWall(x + gap / 2 + side / 2, z, side, 0.24, 4.25, mats.wallAlt);
  }
}
function makeRune(axis, x, z) {
  const group = new THREE.Group();
  group.position.set(axis === 'x' ? x - 0.18 : x, 2.0, axis === 'z' ? z - 0.18 : z);
  const runeMat = new THREE.MeshBasicMaterial({ color: 0xa58aff, transparent: true, opacity: 0.95 });
  const outer = new THREE.Mesh(new THREE.TorusGeometry(0.28, 0.035, 7, 22), runeMat);
  if (axis === 'x') outer.rotation.y = Math.PI / 2;
  group.add(outer);
  const slash = new THREE.Mesh(new THREE.BoxGeometry(axis === 'x' ? 0.045 : 0.58, 0.58, axis === 'x' ? 0.58 : 0.045), runeMat);
  slash.rotation.z = 0.55; group.add(slash);
  group.visible = false; scene.add(group); uvClues.push(group);
  return group;
}
function createSecretDoor(name, x, z, axis = 'x', label = 'SECRET PASSAGE') {
  const root = new THREE.Group(); root.position.set(x, 0, z); scene.add(root);
  const width = 1.82;
  const slab = new THREE.Mesh(axis === 'x'
    ? new THREE.BoxGeometry(0.20, 3.55, width)
    : new THREE.BoxGeometry(width, 3.55, 0.20), mats.woodDark);
  slab.position.y = 1.78; root.add(slab); wallMeshes.push(slab);
  const face = new THREE.Mesh(axis === 'x'
    ? new THREE.BoxGeometry(0.045, 3.20, width - 0.22)
    : new THREE.BoxGeometry(width - 0.22, 3.20, 0.045), mats.wood);
  if (axis === 'x') face.position.set(-0.13, 1.78, 0); else face.position.set(0, 1.78, -0.13);
  root.add(face);
  // Disguised book spines make the panel read as built-in shelving until UV is used.
  for (let i = 0; i < 7; i++) {
    const book = new THREE.Mesh(new THREE.BoxGeometry(axis === 'x' ? 0.10 : 0.16, 0.72 + (i % 3) * 0.12, axis === 'x' ? 0.16 : 0.10), material([0x4c3437,0x30434a,0x6c5940,0x343e35][i % 4]));
    if (axis === 'x') book.position.set(-0.18, 1.95, -0.72 + i * 0.24);
    else book.position.set(-0.72 + i * 0.24, 1.95, -0.18);
    root.add(book);
  }
  const knob = new THREE.Mesh(new THREE.SphereGeometry(0.075, 10, 8), mats.brass);
  if (axis === 'x') knob.position.set(-0.22, 1.55, 0.65); else knob.position.set(0.65, 1.55, -0.22);
  root.add(knob);
  const collider = axis === 'x'
    ? { x, z, hw: 0.24, hd: width / 2 }
    : { x, z, hw: width / 2, hd: 0.24 };
  colliders.push(collider);
  addInteractable(root, 'secretDoor', `REVEAL ${label}`, 3.8);
  root.userData.secretName = name;
  const rune = makeRune(axis, x, z);
  secretDoors.push({ root, collider, rune, slab, name, open: false });
  return root;
}
function createExitGate(name, x, z, axis, action, label) {
  const root = new THREE.Group(); root.position.set(x, 0, z); scene.add(root);
  const slab = new THREE.Mesh(axis === 'x'
    ? new THREE.BoxGeometry(0.22, 3.7, 2.12)
    : new THREE.BoxGeometry(2.12, 3.7, 0.22), mats.woodDark);
  slab.position.y = 1.85; root.add(slab); wallMeshes.push(slab);
  const trim = new THREE.Mesh(axis === 'x'
    ? new THREE.BoxGeometry(0.28, 3.85, 0.12)
    : new THREE.BoxGeometry(0.12, 3.85, 0.28), mats.ghostTrim);
  trim.position.y = 1.9; root.add(trim);
  const emblem = new THREE.Mesh(new THREE.OctahedronGeometry(0.28, 0), new THREE.MeshStandardMaterial({ color: 0x72d9d5, emissive: 0x2b8587, emissiveIntensity: 1.0, metalness: 0.3 }));
  emblem.position.y = 2.05; root.add(emblem);
  const collider = axis === 'x' ? { x, z, hw: 0.25, hd: 1.08 } : { x, z, hw: 1.08, hd: 0.25 };
  colliders.push(collider);
  addInteractable(root, action, label, 3.8);
  escapeGates.push({ root, collider, slab, name, action, open: false });
  return root;
}
function makeRoomDecor(room, index) {
  const { x, z } = room;
  // Every chamber receives distinct floor treatment and a compact landmark.
  const rug = new THREE.Mesh(new THREE.BoxGeometry(3.4, 0.035, 2.6), material(index % 3 === 0 ? 0x39444a : index % 3 === 1 ? 0x51403d : 0x41443a));
  rug.position.set(x, 0.045, z); rug.receiveShadow = true; scene.add(rug);
  const side = index % 2 ? 1 : -1;
  const cabinet = new THREE.Mesh(new THREE.BoxGeometry(1.18, 1.55, 0.62), index % 4 === 0 ? mats.metal : mats.woodDark);
  cabinet.position.set(x + side * 2.35, 0.78, z - 1.85); cabinet.castShadow = true; scene.add(cabinet);
  const tabletop = new THREE.Mesh(new THREE.BoxGeometry(1.42, 0.10, 0.78), mats.wood);
  tabletop.position.set(x + side * 2.35, 1.60, z - 1.85); scene.add(tabletop);
  const lampBulb = new THREE.Mesh(new THREE.SphereGeometry(0.09, 8, 8), new THREE.MeshBasicMaterial({ color: index % 2 ? 0xffd9a3 : 0xb7d8ed }));
  lampBulb.position.set(x, 3.75, z); scene.add(lampBulb);
  if (index % 4 === 0) {
    const lamp = new THREE.PointLight(index % 4 === 0 ? 0x9ac2d7 : 0xffd3a0, 0.34, 8.2, 1.8);
    lamp.position.set(x, 3.55, z); scene.add(lamp); roomLights.push(lamp);
  }
  if (index % 7 === 0) {
    const painting = new THREE.Mesh(new THREE.BoxGeometry(0.08, 1.1, 0.86), mats.brass);
    painting.position.set(x - side * 3.36, 2.45, z + 0.7); scene.add(painting);
    const canvasMesh = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.90, 0.66), material([0x26333c,0x3e3039,0x39443c][(index / 7) % 3]));
    canvasMesh.position.set(x - side * 3.30, 2.45, z + 0.7); scene.add(canvasMesh);
  }
}
function createGrandWing() {
  const x0 = WING.x0, z0 = WING.z0, size = WING.size;
  const x1 = x0 + WING.cols * size, z1 = z0 + WING.rows * size;
  addBox('east wing foundation', (x0+x1)/2, -0.22, (z0+z1)/2, x1-x0, 0.40, z1-z0, material(0x3f4649), { cast: false });
  for (let r = 0; r < WING.rows; r++) {
    for (let c = 0; c < WING.cols; c++) {
      const center = wingRoomCenter(c, r);
      const idx = r * WING.cols + c;
      const room = { id: `W-${String(idx+1).padStart(2,'0')}`, name: WING_ROOM_NAMES[idx], col: c, row: r, x: center.x, z: center.z };
      roomRecords.push(room);
      const floorMat = material(idx % 4 === 0 ? 0x505052 : idx % 4 === 1 ? 0x484c4d : idx % 4 === 2 ? 0x55514d : 0x4b5050);
      addBox(`floor ${room.id}`, center.x, 0.005, center.z, size - 0.08, 0.12, size - 0.08, floorMat, { cast: false });
      makeRoomDecor(room, idx);
      for (const ox of [-1.45, 1.45]) for (const oz of [-1.45, 1.45]) wingSpawnPoints.push({ x: center.x + ox, y: 0.78, z: center.z + oz, room: room.id });
      for (const [ox,oz] of [[0,-2.2],[2.2,0],[0,2.2],[-2.2,0]]) movableObjectSlots.push({ x:center.x+ox, y:0, z:center.z+oz, room:room.id });
    }
  }

  // Interior vertical partitions. Every normal doorway is open; two are disguised secret doors.
  for (let c = 0; c <= WING.cols; c++) {
    const x = x0 + c * size;
    for (let r = 0; r < WING.rows; r++) {
      const z = z0 + (r + 0.5) * size;
      const entranceOpening = c === 0 && r === 2;
      const bellGateOpening = c === 0 && r === 6;
      const gardenOpening = c === WING.cols && r === 6;
      const secretOne = c === 3 && r === 3;
      if (entranceOpening || bellGateOpening || gardenOpening) continue;
      if (secretOne) addVerticalWallGap(x, z, size, 1.9);
      else if (c === 0 || c === WING.cols) addWall(x, z, 0.24, size, 4.25, mats.wallAlt);
      else addVerticalWallGap(x, z, size, 1.9);
    }
  }
  // Interior horizontal partitions with open doorways, plus the tunnel escape opening.
  for (let r = 0; r <= WING.rows; r++) {
    const z = z0 + r * size;
    for (let c = 0; c < WING.cols; c++) {
      const x = x0 + (c + 0.5) * size;
      const tunnelOpening = r === 0 && c === 7;
      if (tunnelOpening) continue;
      if (r === 0 || r === WING.rows) addWall(x, z, size, 0.24, 4.25, mats.wallAlt);
      else addHorizontalWallGap(x, z, size, 1.9);
    }
  }

  // Narrow connector from the library-side secret panel to the 56-room east wing.
  addBox('secret wing connector floor', 12.0, -0.01, -7.0, 4.2, 0.12, 2.55, mats.floor, { cast: false });
  addWall(12.0, -8.38, 4.15, 0.22, 4.1, mats.wallAlt);
  addWall(12.0, -5.62, 4.15, 0.22, 4.1, mats.wallAlt);
  mainSecretDoor = createSecretDoor('Library bookcase entrance', 9.88, -7.0, 'x', 'EAST WING');

  // Two concealed passages inside the 56-room wing.
  createSecretDoor('Mirror Gallery passage', x0 + 3 * size, z0 + 3.5 * size, 'x', 'MIRROR PASSAGE');
  createSecretDoor('Crypt wall passage', x0 + 6.5 * size, z0 + 5 * size, 'z', 'CRYPT PASSAGE');

  // The garden escape lies beyond the east wall. It requires three wandering sigils.
  addBox('garden escape path', 74.0, -0.08, 21.0, 8.0, 0.18, 7.0, material(0x343f3e), { cast: false });
  addWall(74.0, 17.5, 8.0, 0.22, 3.9, mats.wallAlt);
  addWall(74.0, 24.5, 8.0, 0.22, 3.9, mats.wallAlt);
  createExitGate('Garden Gate', 70.0, 21.0, 'x', 'gardenExit', 'OPEN GARDEN ESCAPE');

  // A fourth route: the west forest path is sealed by the Bell Tower Gate.
  addBox('bell tower forest path', 10.0, -0.08, 21.0, 8.0, 0.18, 7.0, material(0x394641), { cast: false });
  addWall(10.0, 17.5, 8.0, 0.22, 3.9, mats.wallAlt);
  addWall(10.0, 24.5, 8.0, 0.22, 3.9, mats.wallAlt);
  createExitGate('Bell Tower Forest Gate', 14.0, 21.0, 'x', 'bellTowerExit', 'OPEN BELL TOWER ESCAPE');

  // The old service tunnel gives another concealed route out of the estate.
  addBox('service tunnel floor', 66.5, -0.08, -28.0, 7.0, 0.18, 7.0, material(0x30383d), { cast: false });
  addWall(63.0, -28.0, 0.22, 7.0, 3.8, mats.wallAlt);
  addWall(70.0, -28.0, 0.22, 7.0, 3.8, mats.wallAlt);
  createExitGate('Service Tunnel Hatch', 66.5, -24.5, 'z', 'tunnelExit', 'OPEN SERVICE TUNNEL');
}

function addPropShape(root, type) {
  const wood = mats.wood, dark = mats.woodDark, brass = mats.brass;
  if (type === 'Porcelain doll') {
    const body = new THREE.Mesh(new THREE.ConeGeometry(0.22, 0.58, 10), mats.paper); body.position.y = 0.42; root.add(body);
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.20, 12, 10), material(0xd6c5b6)); head.position.y = 0.82; root.add(head);
    for (const x of [-0.075,0.075]) { const eye = new THREE.Mesh(new THREE.SphereGeometry(0.025, 6, 6), mats.red); eye.position.set(x,0.84,-0.17); root.add(eye); }
  } else if (type === 'Antique urn') {
    const body = new THREE.Mesh(new THREE.CylinderGeometry(0.18,0.26,0.58,12), material(0x6e7777,0.35,{metalness:0.38})); body.position.y=0.34; root.add(body);
    const lid = new THREE.Mesh(new THREE.SphereGeometry(0.17,10,8), brass); lid.scale.y=0.45; lid.position.y=0.68; root.add(lid);
  } else if (type === 'Grandfather clock') {
    const box = new THREE.Mesh(new THREE.BoxGeometry(0.55,1.55,0.38), dark); box.position.y=0.78; root.add(box);
    const dial = new THREE.Mesh(new THREE.CircleGeometry(0.16,18), brass); dial.position.set(0,1.12,-0.205); root.add(dial);
    const pendulum = new THREE.Mesh(new THREE.SphereGeometry(0.075,10,8), brass); pendulum.position.set(0,0.53,-0.22); root.add(pendulum);
  } else if (type === 'Music box') {
    const box = new THREE.Mesh(new THREE.BoxGeometry(0.62,0.32,0.48), wood); box.position.y=0.18; root.add(box);
    const top = new THREE.Mesh(new THREE.BoxGeometry(0.58,0.045,0.44), brass); top.position.y=0.37; root.add(top);
    const jewel = new THREE.Mesh(new THREE.OctahedronGeometry(0.11), material(0x7ac7c9,0.28,{emissive:0x276a71,emissiveIntensity:0.4})); jewel.position.y=0.48; root.add(jewel);
  } else if (type === 'Cracked mirror') {
    const frame = new THREE.Mesh(new THREE.BoxGeometry(0.16,1.5,0.95), brass); frame.position.y=0.8; root.add(frame);
    const glass = new THREE.Mesh(new THREE.BoxGeometry(0.05,1.28,0.73), mats.glass); glass.position.set(-0.09,0.8,0); root.add(glass);
  } else if (type === 'Travel trunk') {
    const body = new THREE.Mesh(new THREE.BoxGeometry(0.95,0.55,0.58), dark); body.position.y=0.29; root.add(body);
    for (const x of [-0.28,0.28]) { const strap=new THREE.Mesh(new THREE.BoxGeometry(0.08,0.58,0.62),brass); strap.position.set(x,0.29,0); root.add(strap); }
  } else if (type === 'Stone bust') {
    const base = new THREE.Mesh(new THREE.BoxGeometry(0.48,0.35,0.42), mats.metal); base.position.y=0.18; root.add(base);
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.26,12,10), material(0x8b8c86)); head.scale.y=1.18; head.position.y=0.62; root.add(head);
  } else if (type === 'Brass lantern') {
    const body=new THREE.Mesh(new THREE.CylinderGeometry(0.18,0.18,0.42,10),mats.glass); body.position.y=0.38; root.add(body);
    const cap=new THREE.Mesh(new THREE.CylinderGeometry(0.23,0.23,0.07,10),brass); cap.position.y=0.63; root.add(cap);
    const light=new THREE.PointLight(0xffcf8a,0.18,2.5); light.position.y=0.42; root.add(light);
  } else if (type === 'Old gramophone') {
    const base=new THREE.Mesh(new THREE.BoxGeometry(0.56,0.22,0.50),dark); base.position.y=0.18; root.add(base);
    const horn=new THREE.Mesh(new THREE.ConeGeometry(0.36,0.52,12,1,true),brass); horn.rotation.x=Math.PI; horn.position.set(0.12,0.58,0); root.add(horn);
  } else if (type === 'Mask') {
    const mask=new THREE.Mesh(new THREE.SphereGeometry(0.30,14,10),mats.ghostMask); mask.scale.set(0.82,1.12,0.35); mask.position.y=0.6; root.add(mask);
    for (const x of [-0.12,0.12]) { const eye=new THREE.Mesh(new THREE.SphereGeometry(0.055,8,8),mats.ghostFace); eye.position.set(x,0.66,-0.095); root.add(eye); }
  } else if (type === 'Candelabra') {
    const stem=new THREE.Mesh(new THREE.CylinderGeometry(0.07,0.12,0.72,10),brass); stem.position.y=0.38; root.add(stem);
    for (const x of [-0.28,0,0.28]) {
      const arm=new THREE.Mesh(new THREE.CylinderGeometry(0.045,0.045,0.42,8),brass); arm.rotation.z=Math.PI/2; arm.position.set(x,0.66,0); root.add(arm);
      const candle=new THREE.Mesh(new THREE.CylinderGeometry(0.055,0.055,0.28,8),mats.paper); candle.position.set(x,0.98,0); root.add(candle);
      const flame=new THREE.Mesh(new THREE.SphereGeometry(0.055,8,8),new THREE.MeshBasicMaterial({color:0xffc56e})); flame.scale.set(0.65,1.55,0.65); flame.position.set(x,1.16,0); root.add(flame);
    }
  } else if (type === 'Raven Figurine') {
    const body=new THREE.Mesh(new THREE.SphereGeometry(0.28,12,10),dark); body.scale.set(1.35,0.8,0.8); body.position.y=0.45; root.add(body);
    const head=new THREE.Mesh(new THREE.SphereGeometry(0.16,10,8),dark); head.position.set(0.23,0.68,-0.03); root.add(head);
    const beak=new THREE.Mesh(new THREE.ConeGeometry(0.07,0.24,7),brass); beak.rotation.z=-Math.PI/2; beak.position.set(0.43,0.66,-0.03); root.add(beak);
    for (const side of [-1,1]) { const wing=new THREE.Mesh(new THREE.SphereGeometry(0.21,10,8),mats.ghostCoat); wing.scale.set(0.5,0.25,1.1); wing.position.set(0,0.49,side*0.22); root.add(wing); }
  } else if (type === 'Antique Globe') {
    const stand=new THREE.Mesh(new THREE.CylinderGeometry(0.12,0.19,0.62,10),brass); stand.position.y=0.34; root.add(stand);
    const globe=new THREE.Mesh(new THREE.SphereGeometry(0.38,16,12),material(0x547d84,0.45,{metalness:0.2})); globe.position.y=0.88; root.add(globe);
    const ring=new THREE.Mesh(new THREE.TorusGeometry(0.43,0.025,6,24),brass); ring.position.y=0.88; ring.rotation.x=0.34; root.add(ring);
  } else if (type === 'Victorian Telephone') {
    const base=new THREE.Mesh(new THREE.BoxGeometry(0.64,0.20,0.46),dark); base.position.y=0.14; root.add(base);
    const body=new THREE.Mesh(new THREE.CylinderGeometry(0.16,0.20,0.62,10),brass); body.position.y=0.52; root.add(body);
    const mouth=new THREE.Mesh(new THREE.ConeGeometry(0.20,0.22,12),mats.metal); mouth.rotation.x=Math.PI/2; mouth.position.set(0,0.63,-0.20); root.add(mouth);
    const receiver=new THREE.Mesh(new THREE.CapsuleGeometry(0.075,0.38,4,8),dark); receiver.position.set(0.37,0.68,0.02); receiver.rotation.z=-0.25; root.add(receiver);
    const cord=new THREE.Mesh(new THREE.TorusGeometry(0.12,0.018,6,18,Math.PI*1.55),brass); cord.position.set(0.23,0.36,0); root.add(cord);
  } else {
    const body=new THREE.Mesh(new THREE.BoxGeometry(0.62,0.72,0.42),wood); body.position.y=0.38; root.add(body);
    const lid=new THREE.Mesh(new THREE.BoxGeometry(0.68,0.10,0.48),brass); lid.position.y=0.78; root.add(lid);
  }
  root.traverse(o => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
}
function createMovableAntiques() {
  const types = ['Porcelain doll','Antique urn','Grandfather clock','Music box','Cracked mirror','Travel trunk','Stone bust','Brass lantern','Old gramophone','Mask','Keepsake box','Candelabra','Raven Figurine','Antique Globe','Victorian Telephone','Porcelain doll','Antique urn','Music box'];
  for (const type of types) {
    const root = new THREE.Group(); scene.add(root); addPropShape(root, type);
    addInteractable(root, 'moveProp', `REPOSITION ${type.toUpperCase()}`, 3.4);
    root.userData.propName = type; root.userData.moveIndex = 0;
    movableProps.push(root);
  }
}

function randomizePlacedObjects() {
  const shuffled = (items) => {
    const copy = items.slice();
    for (let i = copy.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [copy[i], copy[j]] = [copy[j], copy[i]]; }
    return copy;
  };
  const used = new Set();
  for (const root of randomizedPickups) {
    const spots = shuffled(root.userData.spawnPoints || wingSpawnPoints);
    const point = spots.find(p => !used.has(`${p.x.toFixed(2)}:${p.z.toFixed(2)}`)) || spots[0];
    if (point) {
      used.add(`${point.x.toFixed(2)}:${point.z.toFixed(2)}`);
      root.position.set(point.x, point.y ?? 0.78, point.z);
      root.rotation.y = Math.random() * Math.PI * 2;
      root.visible = true;
    }
  }
  const propSpots = shuffled(movableObjectSlots);
  movableProps.forEach((root, i) => {
    const point = propSpots[i % propSpots.length];
    root.position.set(point.x, point.y, point.z);
    root.rotation.y = Math.random() * Math.PI * 2;
    root.userData.moveIndex = i;
    root.visible = true;
    // Each antique can be moved to other room sockets by interacting with it again.
    root.userData.moveSlots = propSpots.slice(i + 1).concat(propSpots.slice(0, i + 1));
  });
}

function repositionAntique(root) {
  const slots = root.userData.moveSlots || movableObjectSlots;
  if (!slots.length) return;
  let point = null;
  for (let attempt=0; attempt<slots.length; attempt++) {
    root.userData.moveIndex = (root.userData.moveIndex + 1) % slots.length;
    const candidate = slots[root.userData.moveIndex];
    const occupied = movableProps.some(other => other !== root && other.position.distanceTo(new THREE.Vector3(candidate.x,candidate.y,candidate.z)) < 0.9);
    if (!occupied) { point = candidate; break; }
  }
  if (!point) { showToast('There is no free display position right now.'); return; }
  root.position.set(point.x, point.y, point.z);
  root.rotation.y = Math.random() * Math.PI * 2;
  showToast(`${root.userData.propName} moved to ${point.room}. Objects shift to new rooms each run.`);
  soundTone(430,0.08,0.035,'triangle');
}

function createPickupMesh(kind, x, y, z) {
  const group = new THREE.Group(); group.position.set(x, y, z); scene.add(group);
  if (kind === 'key') {
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.19, 0.045, 8, 18), mats.brass);
    ring.rotation.x = Math.PI / 2; group.add(ring);
    const shaft = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.42, 0.07), mats.brass); shaft.position.y = -0.25; group.add(shaft);
    const tooth = new THREE.Mesh(new THREE.BoxGeometry(0.19, 0.09, 0.07), mats.brass); tooth.position.set(0.07, -0.42, 0); group.add(tooth);
  } else if (kind === 'fuse') {
    const body = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.11, 0.5, 12), material(0xc6b9a2, 0.35, { metalness: 0.25 }));
    body.rotation.z = Math.PI / 2; group.add(body);
    for (const dx of [-0.28, 0.28]) { const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.13,0.13,0.08,10), mats.brass); cap.rotation.z = Math.PI/2; cap.position.x = dx; group.add(cap); }
  } else if (kind === 'note') {
    const paper = new THREE.Mesh(new THREE.BoxGeometry(0.58, 0.045, 0.42), mats.paper); paper.rotation.y = -0.15; group.add(paper);
    for (let i=0;i<3;i++) { const ink = new THREE.Mesh(new THREE.BoxGeometry(0.35,0.008,0.012),mats.woodDark); ink.position.set(0,0.026,-0.12+i*0.1); group.add(ink); }
  } else if (kind === 'sigil') {
    const gem = new THREE.Mesh(new THREE.OctahedronGeometry(0.24,0), new THREE.MeshStandardMaterial({color:0x9b76e8,emissive:0x56358d,emissiveIntensity:0.8,metalness:0.25,roughness:0.22})); gem.position.y=0.06; group.add(gem);
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.31,0.025,6,20),new THREE.MeshBasicMaterial({color:0xc3a7ff})); ring.rotation.x=Math.PI/2; ring.position.y=-0.12; group.add(ring);
  } else if (kind === 'ironKey') {
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.18,0.045,8,18),mats.metal); ring.rotation.x=Math.PI/2; group.add(ring);
    const shaft = new THREE.Mesh(new THREE.BoxGeometry(0.08,0.48,0.07),mats.metal); shaft.position.y=-0.25; group.add(shaft);
    const tooth = new THREE.Mesh(new THREE.BoxGeometry(0.18,0.08,0.07),mats.metal); tooth.position.set(0.07,-0.43,0); group.add(tooth);
  } else if (kind === 'exitKey' || kind === 'bellKey') {
    const keyMaterial = kind === 'bellKey' ? mats.ghostTrim : mats.brass;
    const ring = new THREE.Mesh(new THREE.TorusGeometry(kind === 'bellKey' ? 0.22 : 0.16, 0.04, 8, 16), keyMaterial); ring.rotation.x = Math.PI/2; group.add(ring);
    const shaft = new THREE.Mesh(new THREE.BoxGeometry(0.07,0.45,0.07), keyMaterial); shaft.position.y=-0.22; group.add(shaft);
    const tooth = new THREE.Mesh(new THREE.BoxGeometry(0.18,0.08,0.07), keyMaterial); tooth.position.set(0.07,-0.39,0); group.add(tooth);
    if (kind === 'bellKey') {
      const charm = new THREE.Mesh(new THREE.OctahedronGeometry(0.16,0),new THREE.MeshStandardMaterial({color:0x6ac5d0,emissive:0x28616b,emissiveIntensity:0.9,metalness:0.45})); charm.position.set(0,0.28,0); group.add(charm);
    }
  }
  group.traverse(o => { if (o.isMesh) { o.castShadow = true; o.userData.action = kind; } });
  return group;
}

function createPickupsAndPuzzles() {
  const coreSpawns = [
    {x:-6.8,y:0.78,z:-4.25},{x:-8.0,y:0.78,z:-2.1},{x:6.0,y:0.78,z:-1.5},
    {x:5.5,y:0.78,z:-5.2},{x:-6.8,y:0.78,z:-12.0},{x:6.8,y:0.78,z:-12.8},
    {x:0.0,y:0.78,z:5.3},{x:-4.0,y:0.78,z:7.6}
  ];
  const key = createPickupMesh('key', -6.8, 1.18, -4.25);
  addInteractable(key, 'brassKey', 'PICK UP BRASS KEY', 3.3);
  key.userData.spawnPoints = coreSpawns.concat(wingSpawnPoints.slice(0, 96)); randomizedPickups.push(key);
  const fuse = createPickupMesh('fuse', -6.8, 1.2, -12.0);
  addInteractable(fuse, 'fuse', 'PICK UP FUSE', 3.3);
  fuse.userData.spawnPoints = coreSpawns.slice(2).concat(wingSpawnPoints.slice(60, 180)); randomizedPickups.push(fuse);
  const note = createPickupMesh('note', 6.0, 1.2, -1.5);
  addInteractable(note, 'note', 'READ THE NOTE', 3.3);
  note.userData.spawnPoints = coreSpawns.slice(0, 4).concat(wingSpawnPoints.slice(120, 220)); randomizedPickups.push(note);

  // Three sigils are placed in different rooms on every new run; they unlock the garden route.
  for (let i = 0; i < 3; i++) {
    const sigil = createPickupMesh('sigil', 20 + i, 0.82, 10 + i);
    addInteractable(sigil, 'sigil', `COLLECT LOST SIGIL ${i+1}`, 3.4);
    sigil.userData.sigilId = i + 1;
    sigil.userData.spawnPoints = wingSpawnPoints.slice(0);
    randomizedPickups.push(sigil);
  }
  const ironKey = createPickupMesh('ironKey', 45, 0.82, -4);
  addInteractable(ironKey, 'ironKey', 'PICK UP IRON TUNNEL KEY', 3.4);
  ironKey.userData.spawnPoints = wingSpawnPoints.slice(30, 200); randomizedPickups.push(ironKey);

  const bellKey = createPickupMesh('bellKey', 52, 0.82, 14);
  addInteractable(bellKey, 'bellKey', 'PICK UP BELL TOWER KEY', 3.4);
  bellKey.userData.spawnPoints = wingSpawnPoints.slice(0); randomizedPickups.push(bellKey);

  // Hiding wardrobes (the player can use either one).
  const wardrobeA = new THREE.Group(); wardrobeA.position.set(-8.4, 0, -6.0); wardrobeA.rotation.y=-Math.PI/2; scene.add(wardrobeA);
  const bodyA = new THREE.Mesh(new THREE.BoxGeometry(1.25,2.8,0.85), mats.woodDark); bodyA.position.y=1.4; wardrobeA.add(bodyA);
  const seamA = new THREE.Mesh(new THREE.BoxGeometry(0.035,2.4,0.025), mats.brass); seamA.position.set(0,1.4,-0.44); wardrobeA.add(seamA);
  addInteractable(wardrobeA, 'hide', 'HIDE IN WARDROBE', 2.7);
  hideSpots.push({ position: new THREE.Vector3(-8.4,0,-6.0), group: wardrobeA });
  const wardrobeB = new THREE.Group(); wardrobeB.position.set(-8.8, 0, -14.5); wardrobeB.rotation.y=-Math.PI/2; scene.add(wardrobeB);
  const bodyB = new THREE.Mesh(new THREE.BoxGeometry(1.25,2.8,0.85), mats.woodDark); bodyB.position.y=1.4; wardrobeB.add(bodyB);
  const seamB = new THREE.Mesh(new THREE.BoxGeometry(0.035,2.4,0.025), mats.brass); seamB.position.set(0,1.4,-0.44); wardrobeB.add(seamB);
  addInteractable(wardrobeB, 'hide', 'HIDE IN WARDROBE', 2.7);
  hideSpots.push({ position: new THREE.Vector3(-8.8,0,-14.5), group: wardrobeB });
  colliders.push({ x:-8.4,z:-6,hw:0.65,hd:0.45 }, { x:-8.8,z:-14.5,hw:0.65,hd:0.45 });

  // Power keypad in the basement.
  keypadRoot = new THREE.Group(); keypadRoot.position.set(7.6, 1.55, -12.6); keypadRoot.rotation.y=Math.PI/2; scene.add(keypadRoot);
  const panel = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.9, 0.16), mats.metal); keypadRoot.add(panel);
  const screen = new THREE.Mesh(new THREE.BoxGeometry(0.62,0.2,0.025), material(0x18312f,0.3, { emissive:0x1a6859, emissiveIntensity:0.45 })); screen.position.set(0,0.22,-0.1); keypadRoot.add(screen);
  for (let i=0;i<9;i++) {
    const keyBtn = new THREE.Mesh(new THREE.BoxGeometry(0.13,0.09,0.035), mats.brass);
    keyBtn.position.set(-0.22+(i%3)*0.22,-0.03-Math.floor(i/3)*0.16,-0.11); keypadRoot.add(keyBtn);
  }
  addInteractable(keypadRoot, 'keypad', 'USE POWER KEYPAD', 3.4);

  // Cabinet holding the exit key; it becomes interactable when power is restored.
  const cabinet = new THREE.Group(); cabinet.position.set(4.3,0,-14.4); cabinet.rotation.y=Math.PI/2; scene.add(cabinet);
  const cabBody = new THREE.Mesh(new THREE.BoxGeometry(1.5,1.8,0.85), mats.woodDark); cabBody.position.y=0.9; cabinet.add(cabBody);
  const cabDoor = new THREE.Mesh(new THREE.BoxGeometry(1.25,1.55,0.08), mats.wood); cabDoor.position.set(0,0.9,-0.46); cabinet.add(cabDoor);
  const cabKnob = new THREE.Mesh(new THREE.SphereGeometry(0.07,10,8), mats.brass); cabKnob.position.set(0.43,0.9,-0.54); cabinet.add(cabKnob);
  cabinetKey = createPickupMesh('exitKey', 4.3, 1.18, -14.4);
  cabinetKey.visible = false;
  addInteractable(cabinet, 'cabinet', 'OPEN KEY CABINET', 3.4);
  cabinet.userData.exitKey = cabinetKey;
  cabinetRoot = cabinet;
  cabinetCollider = { x:4.3,z:-14.4,hw:0.45,hd:0.78 };
  colliders.push(cabinetCollider);
}

function createGhost() {
  ghost = new THREE.Group();
  // Original enemy archetypes: each new run selects a different horror style.
  const haunters = [
    { id:'warden', name:'THE VEILED WARDEN', color:0x18252e, glow:0x70eaff, speed:1.00 },
    { id:'matron', name:'THE ASHEN MATRON', color:0x30242b, glow:0xffb46b, speed:0.88 },
    { id:'stalker', name:'THE PALE STALKER', color:0x20242a, glow:0xff5267, speed:1.18 }
  ];
  const chosen = haunters[Math.floor(Math.random()*haunters.length)];
  state.haunterType = chosen.id;
  mats.ghostCoat.color.setHex(chosen.color);
  mats.ghostCoat.emissive.setHex(chosen.glow);
  mats.ghostVeil.emissive.setHex(chosen.glow);
  ghost.userData.haunter = chosen;
  ghost.position.set(6, 0, -13);
  scene.add(ghost);

  // THE VEILED WARDEN: an original Victorian caretaker ghost in a torn mourning coat.
  const coat = new THREE.Mesh(new THREE.CylinderGeometry(0.48, 0.90, 2.35, 24, 3, true), mats.ghostCoat);
  coat.position.y = 1.26; coat.rotation.z = 0.03; ghost.add(coat);
  const innerRobe = new THREE.Mesh(new THREE.ConeGeometry(0.76, 1.12, 20, 2, true), mats.ghostVeil);
  innerRobe.position.y = 0.68; innerRobe.rotation.x = Math.PI; ghost.add(innerRobe);
  const waistcoat = new THREE.Mesh(new THREE.CylinderGeometry(0.40,0.52,1.38,16,1,true),new THREE.MeshStandardMaterial({color:0x26353a,roughness:0.5,transparent:true,opacity:0.82,side:THREE.DoubleSide}));
  waistcoat.position.set(0,1.55,-0.05); ghost.add(waistcoat);
  const mantle = new THREE.Mesh(new THREE.SphereGeometry(0.58,18,12),mats.ghostVeil);
  mantle.scale.set(1.35,0.42,0.86); mantle.position.y=2.18; ghost.add(mantle);

  // High hood and long translucent mourning veil.
  const hood = new THREE.Mesh(new THREE.SphereGeometry(0.48,22,16),mats.ghostCoat);
  hood.scale.set(1.02,1.18,0.90); hood.position.set(0,2.78,0.02); ghost.add(hood);
  const veil = new THREE.Mesh(new THREE.ConeGeometry(0.50,1.95,18,2,true),mats.ghostVeil);
  veil.position.set(0,2.04,0.18); veil.rotation.x=0.12; ghost.add(veil);
  const face = new THREE.Mesh(new THREE.SphereGeometry(0.33,18,14),mats.ghostFace);
  face.scale.set(0.90,1.08,0.30); face.position.set(0,2.70,-0.375); ghost.add(face);
  const porcelainMask = new THREE.Mesh(new THREE.SphereGeometry(0.285,18,12),mats.ghostMask);
  porcelainMask.scale.set(0.88,0.98,0.14); porcelainMask.position.set(0,2.68,-0.43); ghost.add(porcelainMask);
  const maskLine = new THREE.Mesh(new THREE.BoxGeometry(0.025,0.72,0.018),mats.ghostTrim);
  maskLine.position.set(0,2.68,-0.455); maskLine.rotation.z=-0.18; ghost.add(maskLine);

  const eyeMat = new THREE.MeshBasicMaterial({color:0xffdf9a});
  const eyeGlowMat = new THREE.MeshBasicMaterial({color:0x9cf4ff});
  const arms=[];
  for (const side of [-1,1]) {
    const eye = new THREE.Mesh(new THREE.SphereGeometry(0.068,10,8),eyeMat);
    eye.position.set(side*0.135,2.76,-0.49); ghost.add(eye);
    const eyeGlow = new THREE.Mesh(new THREE.SphereGeometry(0.13,10,8),new THREE.MeshBasicMaterial({color:0x6cd9ed,transparent:true,opacity:0.14}));
    eyeGlow.position.copy(eye.position); ghost.add(eyeGlow);
    const glow = new THREE.PointLight(0x70eaff,0.18,1.9,2); glow.position.copy(eye.position); ghost.add(glow);
    const sleeve = new THREE.Mesh(new THREE.CapsuleGeometry(0.15,0.86,4,9),mats.ghostCoat);
    sleeve.position.set(side*0.60,1.62,-0.02); sleeve.rotation.z=side*-0.48; sleeve.rotation.x=-0.16; ghost.add(sleeve); arms.push(sleeve);
    const cuff = new THREE.Mesh(new THREE.TorusGeometry(0.16,0.035,7,14),mats.ghostTrim);
    cuff.position.set(side*0.79,1.20,-0.03); cuff.rotation.y=Math.PI/2; ghost.add(cuff);
    const hand = new THREE.Mesh(new THREE.SphereGeometry(0.14,10,8),mats.ghostMask);
    hand.position.set(side*0.82,1.12,-0.04); ghost.add(hand);
    // Three long spectral fingers on each hand.
    for (let f=0; f<3; f++) {
      const finger = new THREE.Mesh(new THREE.CapsuleGeometry(0.035,0.20,3,6),mats.ghostVeil);
      finger.position.set(side*(0.82+(f-1)*0.08),0.91,-0.06); finger.rotation.z=side*(f-1)*0.22; ghost.add(finger);
    }
  }
  // Old caretaker key-chain and a brass key medallion.
  const chain = new THREE.Mesh(new THREE.TorusGeometry(0.34,0.035,7,30),mats.ghostTrim);
  chain.position.set(0,1.92,-0.31); ghost.add(chain);
  const pendant = new THREE.Mesh(new THREE.OctahedronGeometry(0.16,0),new THREE.MeshStandardMaterial({color:0x73dce7,emissive:0x2a8492,emissiveIntensity:1.1,metalness:0.5}));
  pendant.position.set(0,1.70,-0.42); ghost.add(pendant);
  // Distinct original costume silhouettes for each randomly selected hunter.
  if (chosen.id === 'matron') {
    const bonnet = new THREE.Mesh(new THREE.TorusGeometry(0.42,0.095,8,20),mats.ghostTrim);
    bonnet.position.set(0,3.02,0.02); bonnet.rotation.x=0.18; ghost.add(bonnet);
    const shawl = new THREE.Mesh(new THREE.ConeGeometry(0.72,0.55,16,1,true),mats.ghostVeil);
    shawl.position.set(0,2.22,0.03); shawl.rotation.x=Math.PI; ghost.add(shawl);
    for (let i=0;i<3;i++){const bead=new THREE.Mesh(new THREE.SphereGeometry(0.07,8,6),mats.ghostTrim);bead.position.set((i-1)*0.16,1.84,-0.38);ghost.add(bead);}
  } else if (chosen.id === 'stalker') {
    const hair = new THREE.Mesh(new THREE.ConeGeometry(0.39,0.82,12,2),mats.ghostCoat);
    hair.position.set(0,3.02,0.1); hair.rotation.x=0.15; ghost.add(hair);
    const scarf = new THREE.Mesh(new THREE.BoxGeometry(0.62,0.18,0.18),mats.ghostVeil);
    scarf.position.set(0,2.22,-0.24); ghost.add(scarf);
    const shoulder = new THREE.Mesh(new THREE.BoxGeometry(1.18,0.22,0.42),mats.ghostCoat);
    shoulder.position.set(0,2.0,0.02); ghost.add(shoulder);
  }
  // Ragged coat tails and a drifting spectral ring.
  for (let i=0;i<5;i++) {
    const tail = new THREE.Mesh(new THREE.ConeGeometry(0.20+0.04*(i%2),1.12,8,1,true),mats.ghostVeil);
    const a=i*Math.PI*2/5; tail.position.set(Math.cos(a)*0.52,0.45,Math.sin(a)*0.43+0.18); tail.rotation.z=Math.cos(a)*0.28; tail.rotation.x=Math.sin(a)*0.22; ghost.add(tail);
  }
  const shroud = new THREE.Mesh(new THREE.TorusGeometry(0.84,0.045,8,36),new THREE.MeshBasicMaterial({color:0x77eaff,transparent:true,opacity:0.40}));
  shroud.rotation.x=Math.PI/2; shroud.position.y=0.12; ghost.add(shroud);
  const aura = new THREE.PointLight(0x89eaff,1.25,6.4,2); aura.position.set(0,2.0,0); ghost.add(aura); ghostLight=aura;
  ghost.userData.shroud=shroud; ghost.userData.arms=arms; ghost.userData.baseY=0; ghost.visible=false;
}

function createDust() {
  const count = settings.quality === 'low' ? 120 : 280;
  const positions = new Float32Array(count*3);
  for (let i=0;i<count;i++) {
    positions[i*3] = -9.3 + Math.random()*18.6;
    positions[i*3+1] = 0.4 + Math.random()*3.3;
    positions[i*3+2] = -15.3 + Math.random()*26.5;
  }
  const geo = new THREE.BufferGeometry(); geo.setAttribute('position',new THREE.BufferAttribute(positions,3));
  const points = new THREE.Points(geo,new THREE.PointsMaterial({color:0xb8b9b5,size:0.025,transparent:true,opacity:0.42,depthWrite:false}));
  scene.add(points); dust=points;
}

function createFlashlight() {
  flashlight = new THREE.SpotLight(0xe8f2ff, 5.8, 25, Math.PI/6.2, 0.42, 1.25);
  flashlight.position.copy(camera.position); flashlight.castShadow = settings.quality === 'high';
  flashlight.target.position.set(0,1.4,0); scene.add(flashlight,flashlight.target);
  flashlightTarget = flashlight.target;
}

function createEquipmentLights() {
  uvLight = new THREE.SpotLight(0x9d82ff, 0, 16, Math.PI / 5, 0.55, 1.3);
  uvLight.position.copy(camera.position); uvLight.visible = false;
  uvTarget = new THREE.Object3D(); uvTarget.position.set(0, 1, -5);
  scene.add(uvLight, uvTarget); uvLight.target = uvTarget;

  lureBeacon = new THREE.Group();
  const orb = new THREE.Mesh(new THREE.SphereGeometry(0.18, 12, 10), new THREE.MeshBasicMaterial({ color: 0xffc86c }));
  lureBeacon.add(orb);
  const glow = new THREE.PointLight(0xffa64b, 1.5, 6, 2);
  glow.position.y = 0.25; lureBeacon.add(glow);
  lureBeacon.visible = false; scene.add(lureBeacon);

  // Reusable protective ward: a glowing floor sigil that briefly repels the ghost.
  wardField = new THREE.Group();
  const wardRingMat = new THREE.MeshBasicMaterial({ color: 0x77e6d2, transparent: true, opacity: 0.78 });
  const wardRing = new THREE.Mesh(new THREE.TorusGeometry(1.75, 0.055, 8, 48), wardRingMat);
  wardRing.rotation.x = Math.PI / 2; wardRing.position.y = 0.08; wardField.add(wardRing);
  const wardInner = new THREE.Mesh(new THREE.CircleGeometry(1.5, 40), new THREE.MeshBasicMaterial({ color: 0x48a99e, transparent: true, opacity: 0.12, side: THREE.DoubleSide }));
  wardInner.rotation.x = -Math.PI / 2; wardInner.position.y = 0.035; wardField.add(wardInner);
  wardLight = new THREE.PointLight(0x69ddcc, 1.15, 5.5, 2); wardLight.position.y = 0.65; wardField.add(wardLight);
  wardField.visible = false; scene.add(wardField);
}

function setObjective(text) { ui.objective.textContent = text; }
function showToast(text, duration = 2300) {
  ui.toast.textContent = text; ui.toast.classList.remove('hidden'); state.toastTimer = duration;
}
function updateInventory() {
  ui.inventory.innerHTML = '';
  const labels = { brassKey:'BRASS KEY', fuse:'FUSE', exitKey:'EXIT KEY', ironKey:'IRON KEY', bellKey:'BELL TOWER KEY', sigil1:'SIGIL 1', sigil2:'SIGIL 2', sigil3:'SIGIL 3' };
  if (!state.inventory.size) { ui.inventory.innerHTML = '<span class="inventory-empty">Empty</span>'; return; }
  for (const item of state.inventory) {
    const chip = document.createElement('span'); chip.className = 'inventory-chip'; chip.textContent = labels[item] || item.toUpperCase(); ui.inventory.appendChild(chip);
  }
}
function hasItem(item) { return state.inventory.has(item); }
function removeCollider(tag) { colliders = colliders.filter(c => c !== tag); }

function beginAudio() {
  try {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return;
    if (!audioContext) {
      audioContext = new AudioCtx(); masterGain = audioContext.createGain(); masterGain.gain.value = settings.volume; masterGain.connect(audioContext.destination);
      const osc = audioContext.createOscillator(); const gain = audioContext.createGain();
      osc.type='sine'; osc.frequency.value=48; gain.gain.value=0.018; osc.connect(gain); gain.connect(masterGain); osc.start();
      const lfo = audioContext.createOscillator(); const lfoGain = audioContext.createGain(); lfo.frequency.value=0.12; lfoGain.gain.value=4; lfo.connect(lfoGain); lfoGain.connect(osc.frequency); lfo.start();
    }
    audioContext.resume();
  } catch (e) { /* Audio is optional on browsers with restricted autoplay. */ }
}
function soundTone(freq=440,duration=0.12,volume=0.08,type='sine') {
  if (!audioContext || !masterGain || settings.volume<=0) return;
  const osc=audioContext.createOscillator(), gain=audioContext.createGain();
  osc.type=type; osc.frequency.value=freq; gain.gain.setValueAtTime(volume,audioContext.currentTime); gain.gain.exponentialRampToValueAtTime(0.001,audioContext.currentTime+duration);
  osc.connect(gain); gain.connect(masterGain); osc.start(); osc.stop(audioContext.currentTime+duration);
}

async function requestLandscape() {
  // Orientation locking is only allowed by some Android browsers after a
  // user gesture and after fullscreen has been requested. Try that sequence.
  try {
    if (!document.fullscreenElement && document.documentElement.requestFullscreen) {
      await document.documentElement.requestFullscreen({ navigationUI: 'hide' });
    }
  } catch (error) {
    // Spck previews and some embedded browsers do not grant fullscreen.
  }
  try {
    if (screen.orientation && typeof screen.orientation.lock === 'function') {
      await screen.orientation.lock('landscape');
    }
  } catch (error) {
    // The CSS landscape fallback below keeps the game usable in portrait-locked previews.
  }
}

function startGame() {
  requestLandscape(); beginAudio();
  resetGame(); state.started=true; state.paused=false; state.ended=false;
  showGameUI();
  showToast('Explore 61 rooms, uncover secret passages and choose one of four escape routes. Objects move each run.');
  clock.start();
}
function showGameUI() {
  ui.start.classList.remove('visible'); ui.pause.classList.remove('visible'); ui.settings.classList.remove('visible'); ui.end.classList.remove('visible');
  ui.hud.classList.remove('hidden'); ui.controls.classList.remove('hidden'); ui.crosshair.classList.remove('hidden');
}
function clearMovementInputs() {
  joystick.x = 0; joystick.y = 0; state.running = false;
  keys.clear();
  $('run-button').classList.remove('active');
  const knob = $('joystick-knob'); if (knob) knob.style.transform = 'translate(0,0)';
  lookPointer = null; previousLook = null;
}
function pauseGame() {
  if (!state.started || state.ended) return;
  clearMovementInputs();
  state.paused=true; ui.pause.classList.add('visible');
}
function resumeGame() {
  state.paused=false; ui.pause.classList.remove('visible'); beginAudio();
}
function resetGame() {
  state.hidden=false; state.crouching=false; state.running=false; state.flashlight=true; state.battery=100;
  state.elapsed=0; state.ghostActive=false; state.powerOn=false; state.exitOpen=false; state.keypadInput='';
  state.health=1; state.inventory.clear(); state.noteRead=false; state.panelUsed=false; state.ghostState='patrol';
  state.ghostStateTime=0; state.lastSeenAt=-999; state.lastNoiseAt=-999; state.lastNoise.set(0,0,0);
  state.aiPathTimer=0; state.ghostPath=[]; state.hideSpot=null; state.damageCooldown=0; state.patrolIndex=0; state.noiseRadius=4.5;
  state.emfOn=false; state.uvOn=false; state.thermoOn=false; state.lureActiveUntil=0; state.mapOpen=false;
  state.cameraEvidence=0; state.wardActiveUntil=0; state.wardPosition.set(0,0,0);
  state.sigilCount=0; state.gardenExitOpen=false; state.tunnelExitOpen=false; state.bellExitOpen=false; state.visionTimer=0; state.cachedSeesPlayer=false;
  player.set(0,0,8.2); yaw=0; pitch=0; state.currentRoom='Entrance Hall'; if(ui.roomName)ui.roomName.textContent=state.currentRoom;
  for (const root of interactables) {
    if (!root) continue;
    const action = root.userData.action;
    if (['brassKey','fuse','note','sigil','ironKey','bellKey'].includes(action)) root.visible=true;
  }
  cabinetKey.visible=false;
  exitDoor.rotation.y=0;
  if (exitCollider) exitCollider.hw=1.06;
  ghost.position.set(6,0,-13); ghost.visible=false; state.patrolIndex=0;
  // Keep the selected hunter's style across a retry; choose another style on a fresh page load.
  if (ghostLight) ghostLight.intensity=0.6;
  if (cabinetRoot) {
    cabinetRoot.visible=true;
    if (cabinetRoot.children[1]) { cabinetRoot.children[1].rotation.y=0; cabinetRoot.children[1].position.set(0,0.9,-0.46); }
  }
  if (cabinetCollider && !colliders.includes(cabinetCollider)) colliders.push(cabinetCollider);
  if (exitCollider && !colliders.includes(exitCollider)) colliders.push(exitCollider);
  if (flashlight) flashlight.visible=true;
  state.flashlight=true;
  if (uvLight) uvLight.visible=false;
  if (lureBeacon) lureBeacon.visible=false;
  if (wardField) { wardField.visible=false; wardField.children[0].scale.setScalar(1); }
  ui.note.classList.remove('visible'); ui.keypad.classList.remove('visible');
  $('run-button').classList.remove('active'); $('crouch-button').classList.remove('active'); $('hide-button').classList.remove('active');
  $('flashlight-button').classList.toggle('active', true);
  for (const clue of uvClues) clue.visible=false;
  ui.map.classList.add('hidden'); ui.map.classList.remove('visible');
  ui.end.classList.remove('visible'); ui.pause.classList.remove('visible'); ui.settings.classList.remove('visible');
  state.sigilCount=0; state.gardenExitOpen=false; state.tunnelExitOpen=false; state.bellExitOpen=false; state.visionTimer=0; state.cachedSeesPlayer=false;
  for (const entry of secretDoors) { entry.open=false; entry.root.visible=true; entry.rune.visible=false; if (!colliders.includes(entry.collider)) colliders.push(entry.collider); if (!wallMeshes.includes(entry.slab)) wallMeshes.push(entry.slab); }
  for (const gate of escapeGates) { gate.open=false; gate.root.visible=true; if (!colliders.includes(gate.collider)) colliders.push(gate.collider); if (!wallMeshes.includes(gate.slab)) wallMeshes.push(gate.slab); }
  randomizedPickups.forEach(root => root.visible=true); randomizePlacedObjects();
  updateInventory(); updateBattery(); updateHealth(); updateToolUI(); setObjective('Find the brass key. Use UV on hidden panels; object locations change every run.');
  ui.warning.classList.add('hidden'); ui.prompt.classList.add('hidden');
  ui.damage.style.background='rgba(135,15,28,0)';
}

function updateBattery() {
  // Equipment is intentionally unlimited: no charges, fuel, or battery depletion.
  state.battery = 100;
  ui.battery.textContent = 'UNLIMITED';
  ui.batteryFill.style.width = '100%';
  ui.batteryFill.style.background = '#79c99c';
}
function updateHealth() {
  if (ui.healthFill) ui.healthFill.style.width = `${Math.max(0, state.health) * 100}%`;
  if (ui.healthFill) ui.healthFill.style.background = state.health < 0.35 ? '#e36d76' : '#79c99c';
}
function updateToolUI() {
  $('emf-button').classList.toggle('active', state.emfOn);
  $('uv-button').classList.toggle('active', state.uvOn);
  $('thermo-button').classList.toggle('active', state.thermoOn);
  $('lure-button').classList.toggle('active', state.elapsed < state.lureActiveUntil);
  $('ward-button').classList.toggle('active', state.elapsed < state.wardActiveUntil);
  $('lure-count').textContent = 'READY';
  $('camera-count').textContent = `${state.cameraEvidence} PHOTOS`;
  if (ui.thermoValue && !state.thermoOn) { ui.thermoValue.textContent = 'OFF'; ui.thermoValue.style.color = '#a9bac8'; }
}
function toggleEMF() {
  state.emfOn = !state.emfOn;
  updateToolUI();
  showToast(state.emfOn ? 'EMF detector active. Watch the signal level.' : 'EMF detector switched off.');
  soundTone(state.emfOn ? 720 : 360, 0.07, 0.035);
}
function toggleUV() {
  state.uvOn = !state.uvOn;
  if (uvLight) uvLight.visible = state.uvOn;
  for (const clue of uvClues) clue.visible = state.uvOn;
  updateToolUI();
  showToast(state.uvOn ? 'UV scanner active. Hidden marks are now visible.' : 'UV scanner switched off.');
  soundTone(state.uvOn ? 520 : 260, 0.08, 0.03);
}
function useSoundLure() {
  if (!state.started || state.paused || state.ended) return;
  camera.getWorldDirection(tempForward);
  const lurePosition = player.clone().add(tempForward.clone().multiplyScalar(5.0));
  lurePosition.x = THREE.MathUtils.clamp(lurePosition.x, WORLD.minX + 0.8, WORLD.maxX - 0.8);
  lurePosition.z = THREE.MathUtils.clamp(lurePosition.z, WORLD.minZ + 0.8, WORLD.maxZ - 0.8);
  if (collides(lurePosition.x, lurePosition.z, 0.25)) {
    lurePosition.copy(player).add(tempForward.clone().multiplyScalar(2.2));
  }
  lureBeacon.position.set(lurePosition.x, 0.65, lurePosition.z);
  lureBeacon.visible = true;
  state.lureActiveUntil = state.elapsed + 9;
  notifyNoise(lurePosition, 18);
  updateToolUI();
  showToast('Reusable sound lure deployed. Use it as often as you need.');
  soundTone(980, 0.18, 0.07, 'triangle');
}

function toggleThermometer() {
  state.thermoOn = !state.thermoOn;
  updateToolUI();
  showToast(state.thermoOn ? 'Paranormal thermometer active. Colder readings mean the ghost is near.' : 'Thermometer switched off.');
  soundTone(state.thermoOn ? 640 : 320, 0.07, 0.03);
}

function useSpiritBox() {
  if (!state.started || state.paused || state.ended) return;
  let reply = '...COME CLOSER...';
  if (!state.ghostActive) reply = '...WAKE THE HOUSE...';
  else if (!hasItem('brassKey')) reply = '...THE KEY HAS MOVED... SEARCH THE ROOMS...';
  else if (!state.noteRead) reply = '...PAPER REMEMBERS... FIND THE NOTE...';
  else if (!hasItem('fuse') && !state.powerOn) reply = '...A FUSE IS HIDDEN IN THE EAST WING...';
  else if (!state.powerOn) reply = '...THREE ONE FOUR TWO...';
  else if (!hasItem('exitKey')) reply = '...BASEMENT CABINET... IRON KEY... BELL TOWER KEY...';
  else reply = '...THREE SIGILS... GARDEN GATE... SERVICE TUNNEL... BELL TOWER...';
  showToast(`SPIRIT BOX: “${reply}”`, 3000);
  soundTone(180, 0.16, 0.055, 'triangle');
  soundTone(420, 0.12, 0.035, 'sawtooth');
}

function takePhoto() {
  if (!state.started || state.paused || state.ended) return;
  if (ui.cameraFlash) {
    ui.cameraFlash.classList.remove('flash');
    // Force a style recalculation so repeated taps replay the flash animation.
    void ui.cameraFlash.offsetWidth;
    ui.cameraFlash.classList.add('flash');
  }
  camera.getWorldDirection(tempForward);
  let captured = false;
  if (state.ghostActive && ghost && ghost.visible) {
    const ghostFocus = ghost.position.clone().add(new THREE.Vector3(0, 1.7, 0));
    const sight = ghostFocus.clone().sub(camera.position);
    const distance = sight.length();
    const inFrame = distance < 19 && tempForward.dot(sight.normalize()) > 0.58;
    captured = inFrame && lineOfSight(camera.position, ghostFocus);
  }
  if (captured) {
    state.cameraEvidence += 1;
    showToast(`PARANORMAL PHOTO #${state.cameraEvidence}: ghost evidence captured.`);
    soundTone(880, 0.08, 0.08, 'square');
  } else {
    showToast('Photo saved. No clear paranormal evidence in the frame.');
    soundTone(560, 0.06, 0.05, 'square');
  }
  updateToolUI();
}

function deployWard() {
  if (!state.started || state.paused || state.ended) return;
  state.wardPosition.copy(player);
  state.wardActiveUntil = state.elapsed + 7;
  if (wardField) {
    wardField.position.set(player.x, 0, player.z);
    wardField.visible = true;
  }
  showToast('PROTECTIVE WARD ACTIVE. The ghost will be pushed back for 7 seconds.');
  soundTone(260, 0.22, 0.075, 'sine');
  soundTone(520, 0.28, 0.035, 'sine');
}

function updateEquipment(dt) {
  camera.getWorldDirection(tempForward);
  if (uvLight) {
    uvLight.position.copy(camera.position).add(tempForward.clone().multiplyScalar(0.18));
    uvTarget.position.copy(camera.position).add(tempForward.clone().multiplyScalar(7));
    uvLight.visible = state.uvOn;
  }
  if (state.uvOn) { for (const clue of uvClues) clue.visible = true; }
  if (lureBeacon && state.elapsed > state.lureActiveUntil) lureBeacon.visible = false;
  $('lure-button').classList.toggle('active', state.elapsed < state.lureActiveUntil);
  $('ward-button').classList.toggle('active', state.elapsed < state.wardActiveUntil);
  if (wardField) {
    const wardActive = state.elapsed < state.wardActiveUntil;
    wardField.visible = wardActive;
    if (wardActive) {
      const pulse = 0.72 + Math.sin(state.elapsed * 7) * 0.16;
      wardField.children[0].scale.setScalar(pulse);
      wardLight.intensity = 0.9 + Math.sin(state.elapsed * 5) * 0.25;
    }
  }
  if (state.thermoOn && ui.thermoValue) {
    const distance = state.ghostActive && ghost ? player.distanceTo(ghost.position) : 20;
    const temperature = distance < 12 ? 22 - (12 - distance) * 1.12 : 22;
    ui.thermoValue.textContent = `${temperature.toFixed(1)}°C`;
    ui.thermoValue.style.color = temperature < 12 ? '#83d5ff' : temperature < 18 ? '#e9cd85' : '#c4d0da';
  }
  if (state.emfOn) {
    const distance = state.ghostActive && ghost ? player.distanceTo(ghost.position) : 20;
    const signal = state.ghostActive ? Math.round(THREE.MathUtils.clamp((12 - distance) / 12, 0, 1) * 100) : 0;
    ui.emfLevel.textContent = `${signal}%`;
    ui.emfLevel.style.color = signal > 65 ? '#ff8790' : signal > 25 ? '#f4d17d' : '#a9bac8';
  } else {
    ui.emfLevel.textContent = 'OFF';
    ui.emfLevel.style.color = '#a9bac8';
  }
}

function openMap() {
  if (!state.started || state.ended || state.paused) return;
  clearMovementInputs();
  state.paused = true; state.mapOpen = true;
  ui.map.classList.remove('hidden'); ui.map.classList.add('visible');
  drawMap();
}
function closeMap() {
  if (!state.mapOpen) return;
  state.mapOpen = false; ui.map.classList.remove('visible'); ui.map.classList.add('hidden');
  clearMovementInputs();
  if (!state.ended) state.paused = false;
}
function drawMap() {
  const canvas = ui.mapCanvas;
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const w = canvas.width, h = canvas.height;
  const pad = 18;
  const scale = Math.min((w - pad*2) / (WORLD.maxX - WORLD.minX), (h - pad*2) / (WORLD.maxZ - WORLD.minZ));
  const totalW = (WORLD.maxX - WORLD.minX) * scale, totalH = (WORLD.maxZ - WORLD.minZ) * scale;
  const offX = (w - totalW) / 2, offY = (h - totalH) / 2;
  const px = x => offX + (x - WORLD.minX) * scale;
  const py = z => offY + (z - WORLD.minZ) * scale;
  const rect = (x,z,rw,rd,color) => { ctx.fillStyle=color; ctx.fillRect(px(x),py(z),rw*scale,rd*scale); };
  ctx.clearRect(0,0,w,h); ctx.fillStyle='#101b25'; ctx.fillRect(0,0,w,h);

  // Original five-room core.
  rect(-9.6,-15.6,19.2,27.3,'#4e5a61');
  rect(-2.0,-15.6,4.0,27.3,'#858579');
  rect(-9.6,3.2,19.2,8.5,'#93836b');
  rect(-9.6,-7.8,7.4,10.8,'#77706a');
  rect(2.2,-7.8,7.4,10.8,'#6d7780');
  rect(-9.6,-15.6,7.4,7.4,'#687268');
  rect(2.2,-15.6,7.4,7.4,'#626f7a');
  ctx.strokeStyle='#d6c9aa'; ctx.lineWidth=2.4; ctx.strokeRect(px(-9.6),py(-15.6),19.2*scale,27.3*scale);
  ctx.fillStyle='#f5e7c9'; ctx.textAlign='center'; ctx.font='bold 9px system-ui';
  ctx.fillText('LIVING',px(-6),py(-3.1)); ctx.fillText('LIBRARY',px(6),py(-3.1));
  ctx.fillText('BEDROOM',px(-6),py(-12)); ctx.fillText('BASEMENT',px(6),py(-12));
  ctx.fillText('ENTRANCE',px(0),py(7));

  // The 8 x 7 east wing: 56 individually numbered rooms.
  roomRecords.forEach((room,index) => {
    const x=WING.x0+room.col*WING.size, z=WING.z0+room.row*WING.size;
    rect(x+0.06,z+0.06,WING.size-0.12,WING.size-0.12,index%2?'#586269':'#62686a');
    ctx.strokeStyle='rgba(14,21,26,.90)'; ctx.lineWidth=1.1;
    ctx.strokeRect(px(x+0.06),py(z+0.06),(WING.size-0.12)*scale,(WING.size-0.12)*scale);
    ctx.fillStyle='#e9e1cf'; ctx.font='bold 8px system-ui';
    ctx.fillText(String(index+1).padStart(2,'0'),px(room.x),py(room.z)+2.5);
  });
  // Secret entrance connector and the two outdoor escape lanes.
  rect(10.1,-8.35,3.8,2.7,'#8c8776');
  rect(70.0,17.5,8.0,7.0,'#445e53');
  rect(6.0,17.5,8.0,7.0,'#52634b');
  rect(63.0,-31.5,7.0,7.0,'#414c51');

  // Secret passage and escape-route symbols.
  const special=(x,z,color,label)=>{ctx.fillStyle=color;ctx.beginPath();ctx.arc(px(x),py(z),4.5,0,Math.PI*2);ctx.fill();ctx.fillStyle='#fff';ctx.font='7px system-ui';ctx.fillText(label,px(x),py(z)-6);};
  for (const door of secretDoors) if (door.open || state.uvOn) special(door.collider.x,door.collider.z,'#c79bff',door.open?'PASS':'?');
  for (const gate of escapeGates) if (gate.open) special(gate.collider.x,gate.collider.z,'#e6c77c',gate.action==='gardenExit'?'G':gate.action==='bellTowerExit'?'B':'T');

  const marker=(x,z,color,label)=>{ctx.fillStyle=color;ctx.beginPath();ctx.arc(px(x),py(z),4.2,0,Math.PI*2);ctx.fill();ctx.fillStyle='#fff';ctx.font='8px system-ui';ctx.fillText(label,px(x),py(z)-6);};
  for (const item of randomizedPickups) {
    if (!item.visible) continue;
    const action=item.userData.action;
    if (action === 'note' && state.noteRead) continue;
    const pos=item.position;
    const label=action==='brassKey'?'KEY':action==='fuse'?'FUSE':action==='note'?'NOTE':action==='sigil'?'SIGIL':action==='bellKey'?'BELL':'IRON';
    marker(pos.x,pos.z,action==='sigil'?'#bd91ff':action==='ironKey'?'#a9c8cd':'#e8c16e',label);
  }
  if (cabinetKey && cabinetKey.visible) marker(cabinetKey.position.x,cabinetKey.position.z,'#e8c16e','EXIT KEY');
  marker(0,11.78,'#e8c16e','FRONT');
  const ghostInEMFRange=state.ghostActive&&ghost&&ghost.visible&&state.emfOn&&player.distanceTo(ghost.position)<30;
  if(ghostInEMFRange) marker(ghost.position.x,ghost.position.z,'#ff6472','GHOST');
  const x=px(player.x),y=py(player.z); ctx.save();ctx.translate(x,y);ctx.rotate(yaw);
  ctx.fillStyle='#66f0b0';ctx.beginPath();ctx.moveTo(0,-7);ctx.lineTo(4.5,5);ctx.lineTo(0,2.5);ctx.lineTo(-4.5,5);ctx.closePath();ctx.fill();ctx.restore();
  ctx.fillStyle='#dce7ef';ctx.font='10px system-ui';ctx.textAlign='left';ctx.fillText('N ↑',10,15);
  ui.mapStatus.textContent = `${roomRecords.length+5} mapped rooms • You are in ${state.currentRoom}. Use UV to reveal hidden panels; escape markers appear after their gates are unlocked. The map pauses gameplay.`;
}

function notifyNoise(position, radius) {
  state.lastNoise.copy(position); state.lastNoiseAt=state.elapsed; state.noiseRadius=radius;
}

function collides(x,z,radius=0.34) {
  if (x < WORLD.minX || x > WORLD.maxX || z < WORLD.minZ || z > WORLD.maxZ) return true;
  for (const c of colliders) {
    if (Math.abs(x-c.x) < c.hw+radius && Math.abs(z-c.z) < c.hd+radius) return true;
  }
  return false;
}
function moveWithCollision(position, dx, dz, radius=0.34) {
  const nx=position.x+dx, nz=position.z+dz;
  if (!collides(nx,position.z,radius)) position.x=nx;
  if (!collides(position.x,nz,radius)) position.z=nz;
}

function updatePlayer(dt) {
  if (state.hidden) return;
  const joyX=joystick.x, joyY=joystick.y;
  const keyboardForward=(keys.has('KeyW')||keys.has('ArrowUp')?1:0)-(keys.has('KeyS')||keys.has('ArrowDown')?1:0);
  const keyboardSide=(keys.has('KeyD')||keys.has('ArrowRight')?1:0)-(keys.has('KeyA')||keys.has('ArrowLeft')?1:0);
  let forward=-joyY+keyboardForward, side=joyX+keyboardSide;
  const mag=Math.hypot(forward,side); if (mag>1) { forward/=mag; side/=mag; }
  const isMoving=mag>0.08;
  const speed=state.crouching?1.25:(state.running?4.55:2.55);
  const fx=-Math.sin(yaw), fz=-Math.cos(yaw);
  const rx=Math.cos(yaw), rz=-Math.sin(yaw);
  const dx=(fx*forward+rx*side)*speed*dt;
  const dz=(fz*forward+rz*side)*speed*dt;
  moveWithCollision(player,dx,dz);
  if (state.exitOpen && player.z > 13.15) { finishGame(true, 'front'); return; }
  if (state.gardenExitOpen && player.x > 76.2 && Math.abs(player.z - 21) < 4.2) { finishGame(true, 'garden'); return; }
  if (state.bellExitOpen && player.x < 6.8 && Math.abs(player.z - 21) < 4.2) { finishGame(true, 'bellTower'); return; }
  if (state.tunnelExitOpen && player.z < -31.0 && Math.abs(player.x - 66.5) < 3.8) { finishGame(true, 'tunnel'); return; }
  const activeRoom = roomRecords.find(room => Math.abs(player.x-room.x) < 3.35 && Math.abs(player.z-room.z) < 3.35);
  state.currentRoom = activeRoom ? `${activeRoom.id} • ${activeRoom.name}` : (player.x > 10 ? 'East Wing Connector' : (player.z > 3 ? 'Entrance Hall' : 'Main House'));
  if (ui.roomName) ui.roomName.textContent = state.currentRoom;
  if (isMoving) {
    const noiseRadius=state.crouching?1.2:(state.running?12:4.8);
    if (state.elapsed-state.lastNoiseAt > (state.running?0.2:0.45)) notifyNoise(player,noiseRadius);
  }
  camera.position.set(player.x,state.hidden?1.25:(state.crouching?1.05:1.62),player.z);
  camera.rotation.set(pitch,yaw,0,'YXZ');
}

const keys = new Set();
window.addEventListener('keydown', e => {
  if (e.code === 'Escape') {
    if (state.mapOpen) { closeMap(); return; }
    if (ui.note.classList.contains('visible')) { ui.note.classList.remove('visible'); state.paused = false; return; }
    if (ui.keypad.classList.contains('visible')) { ui.keypad.classList.remove('visible'); state.paused = false; return; }
    if (ui.settings.classList.contains('visible')) {
      ui.settings.classList.remove('visible');
      if (state.started) { ui.pause.classList.add('visible'); state.paused = true; }
      else ui.start.classList.add('visible');
      return;
    }
    if (state.paused && state.started && !state.ended) { resumeGame(); return; }
    if (state.started && !state.paused && !state.ended) { pauseGame(); return; }
  }
  if (state.paused || !state.started || state.ended) return;
  keys.add(e.code);
  if (['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code)) e.preventDefault();
  if (e.code==='KeyE') interact();
  if (e.code==='ShiftLeft'||e.code==='ShiftRight') state.running=true;
  if (e.code==='KeyC') toggleCrouch();
  if (e.code==='KeyF') toggleFlashlight();
  if (e.code==='KeyH') toggleHide();
  if (e.code==='KeyM' && state.started && !state.paused) openMap();
  if (e.code==='KeyN') toggleEMF();
  if (e.code==='KeyU') toggleUV();
  if (e.code==='KeyG') useSoundLure();
  if (e.code==='KeyT') toggleThermometer();
  if (e.code==='KeyB') useSpiritBox();
  if (e.code==='KeyP') takePhoto();
  if (e.code==='KeyR') deployWard();
});
window.addEventListener('keyup', e => { keys.delete(e.code); if (e.code==='ShiftLeft'||e.code==='ShiftRight') state.running=false; });

function setupControls() {
  const joy=$('joystick'), knob=$('joystick-knob');
  const updateJoy = (clientX,clientY) => {
    const rect=joy.getBoundingClientRect(), cx=rect.left+rect.width/2, cy=rect.top+rect.height/2;
    let dx=clientX-cx, dy=clientY-cy; const max=Math.min(rect.width,rect.height)*0.34;
    const len=Math.hypot(dx,dy); if(len>max){dx=dx/len*max;dy=dy/len*max;}
    // Keep movement directions aligned with the visually rotated landscape HUD.
    if (usesRotatedPortraitLayout()) { joystick.x=dy/max; joystick.y=-dx/max; }
    else { joystick.x=dx/max; joystick.y=dy/max; }
    if (usesRotatedPortraitLayout()) knob.style.transform=`translate(${dy}px,${-dx}px)`;
    else knob.style.transform=`translate(${dx}px,${dy}px)`;
  };
  joy.addEventListener('pointerdown',e=>{ e.preventDefault(); if(!state.started||state.paused||state.ended)return; joystick.pointer=e.pointerId; joy.setPointerCapture(e.pointerId); updateJoy(e.clientX,e.clientY); });
  joy.addEventListener('pointermove',e=>{ if(joystick.pointer===e.pointerId && !state.paused) updateJoy(e.clientX,e.clientY); });
  const clearJoy=e=>{ if(joystick.pointer===e.pointerId){joystick.pointer=null;joystick.x=0;joystick.y=0;knob.style.transform='translate(0,0)';} };
  joy.addEventListener('pointerup',clearJoy); joy.addEventListener('pointercancel',clearJoy);

  const lookZone=$('look-zone');
  lookZone.addEventListener('pointerdown',e=>{ if(!state.started||state.paused||state.ended) return; lookPointer=e.pointerId; previousLook={x:e.clientX,y:e.clientY}; lookZone.setPointerCapture(e.pointerId); });
  lookZone.addEventListener('pointermove',e=>{
    if(lookPointer!==e.pointerId||!previousLook) return;
    let dx=e.clientX-previousLook.x, dy=e.clientY-previousLook.y; previousLook={x:e.clientX,y:e.clientY};
    if (usesRotatedPortraitLayout()) { const screenX=dx; dx=dy; dy=-screenX; }
    yaw-=dx*0.0045*settings.sensitivity; pitch-=dy*0.0038*settings.sensitivity;
    pitch=THREE.MathUtils.clamp(pitch,-1.05,1.0); camera.rotation.set(pitch,yaw,0,'YXZ');
  });
  const endLook=e=>{if(lookPointer===e.pointerId){lookPointer=null;previousLook=null;}};
  lookZone.addEventListener('pointerup',endLook); lookZone.addEventListener('pointercancel',endLook);

  $('run-button').addEventListener('pointerdown',e=>{e.preventDefault();state.running=true;$('run-button').classList.add('active');try{$('run-button').setPointerCapture(e.pointerId);}catch(_){}});
  const stopRun=()=>{state.running=false;$('run-button').classList.remove('active');};
  $('run-button').addEventListener('pointerup',stopRun); $('run-button').addEventListener('pointercancel',stopRun); $('run-button').addEventListener('lostpointercapture',stopRun);
  $('crouch-button').addEventListener('click',toggleCrouch);
  $('hide-button').addEventListener('click',toggleHide);
  $('interact-button').addEventListener('click',interact);
  $('flashlight-button').addEventListener('click',toggleFlashlight);
  $('pause-button').addEventListener('click',pauseGame);
  $('emf-button').addEventListener('click',toggleEMF);
  $('uv-button').addEventListener('click',toggleUV);
  $('lure-button').addEventListener('click',useSoundLure);
  $('thermo-button').addEventListener('click',toggleThermometer);
  $('spirit-button').addEventListener('click',useSpiritBox);
  $('camera-button').addEventListener('click',takePhoto);
  $('ward-button').addEventListener('click',deployWard);
  $('map-button').addEventListener('click',openMap);
  $('close-map-button').addEventListener('click',closeMap);
  $('map-resume-button').addEventListener('click',closeMap);
}

function toggleCrouch() { state.crouching=!state.crouching; $('crouch-button').classList.toggle('active',state.crouching); showToast(state.crouching?'Crouching: quieter, but slower.':'You stand up.'); }
function toggleFlashlight() {
  state.flashlight=!state.flashlight; flashlight.visible=state.flashlight; $('flashlight-button').classList.toggle('active',state.flashlight);
  soundTone(state.flashlight?620:280,0.08,0.035);
}
function toggleHide() {
  if (state.hidden) {
    state.hidden=false; state.hideSpot=null; $('hide-button').classList.remove('active'); camera.position.set(player.x,1.62,player.z); showToast('You leave the hiding place.');
    notifyNoise(player,2.2); return;
  }
  let nearest=null, dist=Infinity;
  for (const spot of hideSpots) { const d=player.distanceTo(spot.position); if(d<2.2&&d<dist){nearest=spot;dist=d;} }
  if (!nearest) { showToast('Move closer to a wardrobe to hide.'); return; }
  state.hidden=true; state.hideSpot=nearest; state.crouching=false; state.running=false; $('hide-button').classList.add('active'); $('crouch-button').classList.remove('active'); $('run-button').classList.remove('active');
  camera.position.set(nearest.position.x,1.25,nearest.position.z+0.85);
  showToast('Hidden. Stay quiet until the ghost leaves.');
}

function findTarget() {
  if (state.hidden) return null;
  camera.getWorldDirection(tempForward);
  let best=null, bestScore=Infinity;
  for (const root of interactables) {
    if (!root.visible) continue;
    const action=root.userData.action;
    if (action==='cabinet' && (!state.powerOn || hasItem('exitKey'))) continue;
    if (action==='keypad' && state.powerOn) continue;
    const pos=new THREE.Vector3(); root.getWorldPosition(pos);
    if (action==='exit') pos.set(0,1.6,11.78);
    if (action==='hide') pos.y=1.45;
    if (action==='cabinet') pos.y=1.2;
    const delta=pos.clone().sub(camera.position); const distance=delta.length();
    const dot=tempForward.dot(delta.normalize());
    const range=root.userData.range||3.2;
    if(distance<=range && dot>0.48) {
      const score=distance+(1-dot)*1.8;
      if(score<bestScore){best=root;bestScore=score;}
    }
  }
  return best;
}
function updateTarget() {
  currentTarget=findTarget();
  if (currentTarget) {
    let label=currentTarget.userData.label;
    if(currentTarget.userData.action==='exit') label=state.exitOpen?'OPEN EXIT':'LOCKED EXIT';
    if(currentTarget.userData.action==='keypad' && !hasItem('fuse')) label='POWER PANEL (NEEDS FUSE)';
    if(currentTarget.userData.action==='gardenExit') label=`GARDEN GATE (${state.sigilCount}/3 SIGILS)`;
    if(currentTarget.userData.action==='tunnelExit') label='SERVICE HATCH (IRON KEY + POWER)';
    if(currentTarget.userData.action==='bellTowerExit') label='BELL TOWER GATE (BELL KEY + POWER)';
    if(currentTarget.userData.action==='secretDoor') label=state.uvOn?'OPEN HIDDEN PASSAGE':'HIDDEN PANEL — USE UV';
    ui.prompt.textContent=`✋  ${label}  •  USE`;
    ui.prompt.classList.remove('hidden');
  } else ui.prompt.classList.add('hidden');
}

function interact() {
  if (!state.started||state.paused||state.ended) return;
  if (state.hidden) { toggleHide(); return; }
  const target=findTarget(); if(!target){showToast('Nothing to interact with. Look closer at an object.');return;}
  const action=target.userData.action;
  if(action==='brassKey') {
    state.inventory.add('brassKey'); target.visible=false; updateInventory(); state.ghostActive=true; ghost.visible=true;
    setObjective('Find the scattered note and a fuse. Their locations change each run.');
    showToast('Brass key collected. Something has awakened in the mansion.'); soundTone(740,0.22,0.06);
  } else if(action==='fuse') {
    state.inventory.add('fuse'); target.visible=false; updateInventory();
    setObjective('Take the fuse to the power keypad in the basement.'); showToast('Fuse collected.'); soundTone(520,0.15,0.05);
  } else if(action==='note') {
    state.noteRead=true; clearMovementInputs(); ui.note.classList.add('visible'); state.paused=true;
    setObjective('The note reveals the power code: 3142.');
  } else if(action==='keypad') {
    if(!hasItem('fuse')) { showToast('The power panel is missing a fuse.'); return; }
    state.keypadInput=''; updateKeypad(); clearMovementInputs(); ui.keypad.classList.add('visible'); state.paused=true;
  } else if(action==='cabinet') {
    if(!state.powerOn) { showToast('The cabinet lock has no power.'); return; }
    cabinetKey.visible=false; state.inventory.add('exitKey'); updateInventory();
    if (cabinetCollider) removeCollider(cabinetCollider);
    if (cabinetRoot && cabinetRoot.children[1]) { cabinetRoot.children[1].rotation.y=-0.95; cabinetRoot.children[1].position.x=0.45; }
    setObjective('Return to the entrance and unlock the front door.');
    showToast('You found the exit key. Get out!'); soundTone(880,0.3,0.06);
  } else if(action==='sigil') {
    const sigilId = target.userData.sigilId || target.parent?.userData.sigilId || (state.sigilCount + 1);
    state.sigilCount = Math.min(3, state.sigilCount + 1);
    state.inventory.add(`sigil${sigilId}`); target.visible=false; updateInventory();
    setObjective(`Lost sigils recovered: ${state.sigilCount}/3. Find all three to open the garden escape.`);
    showToast(`LOST SIGIL RECOVERED — ${state.sigilCount}/3.`); soundTone(820,0.18,0.06,'sine');
  } else if(action==='ironKey') {
    state.inventory.add('ironKey'); target.visible=false; updateInventory();
    setObjective('The iron key can open the service tunnel hatch. Restore power first.');
    showToast('Iron service key collected.'); soundTone(620,0.16,0.05);
  } else if(action==='bellKey') {
    state.inventory.add('bellKey'); target.visible=false; updateInventory();
    setObjective('A fourth escape route is marked by the Bell Tower Gate. Find the power room and open it.');
    showToast('BELL TOWER KEY collected. The west forest route is now possible.'); soundTone(700,0.20,0.06,'triangle');
  } else if(action==='secretDoor') {
    const entry = secretDoors.find(item => item.root === target || item.root.children.includes(target));
    if (!state.uvOn) { showToast('A hidden symbol is etched into the panel. Switch on the UV scanner first.'); return; }
    if (entry && !entry.open) {
      entry.open=true; entry.root.visible=false; entry.rune.visible=false; removeCollider(entry.collider); wallMeshes=wallMeshes.filter(mesh=>mesh!==entry.slab);
      showToast(`${entry.name.toUpperCase()} REVEALED. A hidden passage is open.`); soundTone(310,0.32,0.06,'triangle');
    }
  } else if(action==='gardenExit') {
    if (state.sigilCount < 3) { showToast(`The garden gate needs three lost sigils. ${state.sigilCount}/3 found.`); return; }
    const gate=escapeGates.find(item=>item.action==='gardenExit');
    if (gate && !gate.open) { gate.open=true; gate.root.visible=false; removeCollider(gate.collider); wallMeshes=wallMeshes.filter(mesh=>mesh!==gate.slab); state.gardenExitOpen=true; showToast('GARDEN ESCAPE OPEN. Follow the lantern path outside.'); setObjective('Run through the garden gate to escape.'); soundTone(420,0.45,0.06); }
  } else if(action==='tunnelExit') {
    if (!hasItem('ironKey') || !state.powerOn) { showToast('The service hatch needs the iron key and restored power.'); return; }
    const gate=escapeGates.find(item=>item.action==='tunnelExit');
    if (gate && !gate.open) { gate.open=true; gate.root.visible=false; removeCollider(gate.collider); wallMeshes=wallMeshes.filter(mesh=>mesh!==gate.slab); state.tunnelExitOpen=true; showToast('SERVICE TUNNEL UNSEALED. Follow the tunnel to daylight.'); setObjective('Escape through the service tunnel.'); soundTone(190,0.5,0.06,'triangle'); }
  } else if(action==='bellTowerExit') {
    if (!hasItem('bellKey') || !state.powerOn) { showToast('The Bell Tower Gate needs its key and restored power.'); return; }
    const gate=escapeGates.find(item=>item.action==='bellTowerExit');
    if (gate && !gate.open) { gate.open=true; gate.root.visible=false; removeCollider(gate.collider); wallMeshes=wallMeshes.filter(mesh=>mesh!==gate.slab); state.bellExitOpen=true; showToast('BELL TOWER GATE OPEN. Follow the west forest path.'); setObjective('Escape along the west forest path.'); soundTone(350,0.48,0.06,'triangle'); }
  } else if(action==='moveProp') {
    repositionAntique(target);
  } else if(action==='hide') toggleHide();
  else if(action==='exit') {
    if(!state.exitOpen) {
      if(!hasItem('exitKey')) { showToast('The front door is locked. Find the exit key.'); return; }
      state.exitOpen=true;
      const c=colliders.find(v=>v.exit); if(c) removeCollider(c);
      exitDoor.rotation.y=-1.35;
      setObjective('The exit is open. Escape the house!'); showToast('The lock clicks. The door swings open.'); soundTone(260,0.35,0.08,'triangle');
    } else finishGame(true);
  }
}

function updateKeypad() {
  ui.keypadDisplay.textContent=(state.keypadInput.padEnd(4,'_').split('').join(' '));
  ui.keypadMessage.textContent=state.inventory.has('fuse')?'Fuse installed. Enter the four-digit code.':'The panel needs a fuse and the correct code.';
}
function keypadInput(value) {
  if(value==='clear') state.keypadInput='';
  else if(value==='enter') {
    if(!hasItem('fuse')) {ui.keypadMessage.textContent='A fuse is required.';return;}
    if(state.keypadInput==='3142') {
      state.powerOn=true; state.panelUsed=true; state.inventory.delete('fuse'); updateInventory();
      ui.keypad.classList.remove('visible'); state.paused=false;
      cabinetKey.visible=true;
      setObjective('Power restored. Open the cabinet in the basement for the exit key.');
      showToast('POWER RESTORED. Something is moving upstairs.');
      soundTone(160,0.5,0.1,'sawtooth');
    } else { ui.keypadMessage.textContent='Incorrect code. The note may contain a clue.'; state.keypadInput=''; }
  } else if(state.keypadInput.length<4) state.keypadInput+=value;
  updateKeypad();
}

function lineOfSight(from,to) {
  const dir=to.clone().sub(from); const dist=dir.length(); dir.normalize();
  raycaster.set(from,dir); raycaster.far=dist;
  const hits=raycaster.intersectObjects(wallMeshes,false);
  return hits.length===0;
}

function gridPath(start,target) {
  const sx=Math.round(start.x), sz=Math.round(start.z), tx=Math.round(target.x), tz=Math.round(target.z);
  const key=(x,z)=>`${x},${z}`;
  const heuristic=(x,z)=>Math.abs(tx-x)+Math.abs(tz-z);
  const heap=[];
  const push=(node)=>{heap.push(node);let i=heap.length-1;while(i>0){const p=(i-1)>>1;if(heap[p].f<=node.f)break;heap[i]=heap[p];i=p;}heap[i]=node;};
  const pop=()=>{if(!heap.length)return null;const top=heap[0],last=heap.pop();if(heap.length){let i=0;while(true){let l=i*2+1,r=l+1;if(l>=heap.length)break;let c=r<heap.length&&heap[r].f<heap[l].f?r:l;if(heap[c].f>=last.f)break;heap[i]=heap[c];i=c;}heap[i]=last;}return top;};
  const startKey=key(sx,sz), targetKey=key(tx,tz);
  const came=new Map(), cost=new Map([[startKey,0]]), closed=new Set();
  push({x:sx,z:sz,f:heuristic(sx,sz)}); came.set(startKey,null);
  const dirs=[[1,0],[-1,0],[0,1],[0,-1]];
  let found=false, iterations=0;
  while(heap.length && iterations++<5200){
    const node=pop(), ck=key(node.x,node.z);
    if(closed.has(ck))continue; closed.add(ck);
    if(ck===targetKey){found=true;break;}
    for(const [dx,dz] of dirs){
      const nx=node.x+dx,nz=node.z+dz,nk=key(nx,nz);
      if(nx<WORLD.minX+0.5||nx>WORLD.maxX-0.5||nz<WORLD.minZ+0.5||nz>WORLD.maxZ-0.5||closed.has(nk))continue;
      if(collides(nx,nz,0.28))continue;
      const nextCost=(cost.get(ck)??Infinity)+1;
      if(nextCost<(cost.get(nk)??Infinity)){
        cost.set(nk,nextCost);came.set(nk,[node.x,node.z]);
        push({x:nx,z:nz,f:nextCost+heuristic(nx,nz)});
      }
    }
  }
  if(!found)return [];
  const path=[];let cur=[tx,tz];
  while(cur){path.push(new THREE.Vector3(cur[0],0,cur[1]));cur=came.get(key(cur[0],cur[1]));}
  path.reverse();return path.slice(1);
}

function ghostSetState(next) {
  if(state.ghostState===next) return;
  state.ghostState=next; state.ghostStateTime=0; state.aiPathTimer=0;
  if(next==='chase') { showToast('RUN. THE GHOST HAS FOUND YOU.',1600); soundTone(95,0.55,0.08,'sawtooth'); }
}
function updateGhost(dt) {
  if(!state.ghostActive||!ghost.visible||state.ended) return;
  state.ghostStateTime+=dt; state.aiPathTimer+=dt;
  const ghostPos=ghost.position.clone(); ghostPos.y=1.0;
  const playerPos=player.clone(); playerPos.y=1.5;
  const distance=ghostPos.distanceTo(playerPos);
  const toPlayer=playerPos.clone().sub(ghostPos).normalize();
  const forward=new THREE.Vector3(-Math.sin(yaw),0,-Math.cos(yaw));
  const ghostForward=new THREE.Vector3(-Math.sin(ghost.rotation.y),0,-Math.cos(ghost.rotation.y));
  const ghostView=ghostForward.dot(toPlayer);
  state.visionTimer -= dt;
  if (state.visionTimer <= 0) {
    state.visionTimer = 0.18;
    state.cachedSeesPlayer = !state.hidden && distance <= (settings.difficulty==='easy'?7.2:settings.difficulty==='hard'?11:9) && ghostView > 0.05 && lineOfSight(ghostPos.clone().setY(2.5),playerPos.clone().setY(1.3));
  }
  const seesPlayer = state.cachedSeesPlayer && !state.hidden;
  const lureDistance = ghost.position.distanceTo(state.lastNoise);
  const hearsPlayer=(!state.hidden && state.elapsed-state.lastNoiseAt<1.1 && distance<(state.noiseRadius||4.5)) || (state.lureActiveUntil>state.elapsed && lureDistance<(state.noiseRadius||18));
  if(seesPlayer) {state.lastSeenAt=state.elapsed;state.lastKnown.copy(player);}
  if(hearsPlayer && state.elapsed-state.lastNoiseAt<0.2) state.lastKnown.copy(state.lastNoise);

  if(seesPlayer) ghostSetState('chase');
  else if(state.ghostState==='chase' && state.elapsed-state.lastSeenAt>3.5) ghostSetState('search');
  else if(hearsPlayer && state.ghostState!=='chase') ghostSetState('investigate');
  else if(state.ghostState==='search' && state.ghostStateTime>7) ghostSetState('patrol');
  else if(state.ghostState==='investigate' && state.ghostStateTime>5) ghostSetState('patrol');

  const wardRepels = state.elapsed < state.wardActiveUntil && ghost.position.distanceTo(state.wardPosition) < 4.0;
  let target;
  if (wardRepels) {
    const away = ghost.position.clone().sub(state.wardPosition); away.y = 0;
    if (away.lengthSq() < 0.01) away.set(1, 0, 0);
    target = ghost.position.clone().add(away.normalize().multiplyScalar(5.5));
  } else if(state.ghostState==='chase') target=player.clone();
  else if(state.ghostState==='investigate') target=state.lastNoise.clone();
  else if(state.ghostState==='search') target=state.lastKnown.clone();
  else {
    const patrol=[new THREE.Vector3(0,0,-4),new THREE.Vector3(6,0,-4),new THREE.Vector3(6,0,-12),new THREE.Vector3(-6,0,-12),new THREE.Vector3(-6,0,-4),new THREE.Vector3(18,0,-7),new THREE.Vector3(31.5,0,-7),new THREE.Vector3(38.5,0,0)];
    if(!state.patrolIndex || ghost.position.distanceTo(patrol[state.patrolIndex])<1.0) state.patrolIndex=((state.patrolIndex||0)+1)%patrol.length;
    target=patrol[state.patrolIndex];
  }
  if (wardRepels) { state.aiPathTimer = 1; state.ghostPath = []; }
  if(state.aiPathTimer>0.85 || !state.ghostPath.length) {
    state.ghostPath=gridPath(ghost.position,target); state.aiPathTimer=0;
  }
  let waypoint=state.ghostPath.length?state.ghostPath[0]:target;
  if(ghost.position.distanceTo(waypoint)<0.55 && state.ghostPath.length) {state.ghostPath.shift();waypoint=state.ghostPath[0]||target;}
  const speedBase=settings.difficulty==='easy'?1.45:settings.difficulty==='hard'?2.3:1.9;
  const traitSpeed = ghost.userData.haunter?.speed || 1;
  const speed=(wardRepels ? speedBase + 1.25 : state.ghostState==='chase'?speedBase+0.85:state.ghostState==='investigate'?speedBase*0.9:speedBase*0.65) * traitSpeed;
  const delta=waypoint.clone().sub(ghost.position); delta.y=0;
  if(delta.length()>0.06) {
    delta.normalize(); const nextX=ghost.position.x+delta.x*speed*dt, nextZ=ghost.position.z+delta.z*speed*dt;
    if(!collides(nextX,nextZ,0.35)){ghost.position.x=nextX;ghost.position.z=nextZ;}
    else { state.aiPathTimer=2; }
    ghost.rotation.y=Math.atan2(-delta.x,-delta.z);
  }
  ghost.position.y=Math.sin(state.elapsed*2.3)*0.16;
  if (ghost.userData.shroud) ghost.userData.shroud.rotation.z=state.elapsed*0.65;
  if (ghost.userData.arms) ghost.userData.arms.forEach((arm,i)=>{ arm.rotation.z=(i===0?-1:1)*0.48 + Math.sin(state.elapsed*1.7+i)*0.11; });
  ghostLight.intensity=0.95+Math.sin(state.elapsed*4)*0.28;
  ghost.scale.setScalar(state.ghostState==='chase'?1.04:1.0);
  ui.warning.classList.toggle('hidden',distance>8.5||state.hidden);
  const hunterName = ghost.userData.haunter?.name || 'THE VEILED WARDEN';
  if (ui.warning) ui.warning.textContent = state.ghostState === 'chase' ? hunterName + ' HAS FOUND YOU' : hunterName + ' IS NEAR';
  if(distance<1.0 && !state.hidden && !wardRepels && state.damageCooldown<=0) {
    state.damageCooldown=1.5; state.health-=0.35; updateHealth(); ui.damage.style.background='rgba(135,15,28,.48)';
    setTimeout(()=>ui.damage.style.background='rgba(135,15,28,0)',180);
    soundTone(55,0.35,0.12,'sawtooth');
    if(state.health<=0) finishGame(false);
    else { // A brief supernatural displacement gives the player another chance.
      player.set(0,0,8.2); yaw=0; showToast('The ghost caught you. You stumble back to the entrance.');
    }
  }
}

function updateFlashlight(dt) {
  if (state.flashlight) {
    // Unlimited flashlight power: it remains available for the entire session.
    flashlight.intensity = 6.4 * (0.98 + Math.sin(state.elapsed * 1.9) * 0.018);
  }
  camera.getWorldDirection(tempForward);
  flashlight.position.copy(camera.position).add(tempForward.clone().multiplyScalar(0.12));
  flashlightTarget.position.copy(camera.position).add(tempForward.clone().multiplyScalar(7));
  updateBattery();
}

function finishGame(won, route='front') {
  state.ended=true;state.paused=true; state.mapOpen=false; ui.map.classList.add('hidden'); ui.map.classList.remove('visible');
  const routeNames={front:'Front Entrance',garden:'Hidden Garden Route',tunnel:'Old Service Tunnel',bellTower:'Bell Tower Forest Route'};
  ui.endKicker.textContent=won?`ESCAPE COMPLETE • ${routeNames[route]||'SECRET ROUTE'}`:'GAME OVER';
  ui.endTitle.textContent=won?(route==='garden'?'You found the garden.':route==='tunnel'?'You reached the service road.':route==='bellTower'?'You reached the forest road.':'You escaped.'):'The house keeps its secret.';
  ui.endDescription.textContent=won?(route==='garden'?'The three sigils glow as the garden gate closes behind you. The Veiled Warden fades into the ivy.':route==='tunnel'?'The iron hatch slams shut behind you. The old tunnel finally leads to daylight.':route==='bellTower'?'The Bell Tower key turns. The west forest trail leads away from the mansion and into the dawn.':'The front door opens into the cold night. Behind you, the mansion goes quiet.'):'The Veiled Warden has caught you. The storm outside continues, and the house remains sealed.';
  ui.end.classList.add('visible');
  if(won) soundTone(660,0.7,0.08,'sine');
}

function applySettings() {
  settings.quality=$('quality-setting').value;
  settings.difficulty=$('difficulty-setting').value;
  settings.sensitivity=Number($('sensitivity-setting').value);
  settings.volume=Number($('volume-setting').value)/100;
  settings.brightness=Number($('brightness-setting').value);
  $('sensitivity-label').textContent=`${settings.sensitivity.toFixed(1)}×`;
  $('volume-label').textContent=`${Math.round(settings.volume*100)}%`;
  $('brightness-label').textContent=`${settings.brightness.toFixed(2)}×`;
  if(renderer) renderer.toneMappingExposure=settings.brightness;
  if(masterGain && audioContext) masterGain.gain.setTargetAtTime(settings.volume,audioContext.currentTime,0.08);
  if(renderer) { const viewport=getGameViewport(); renderer.setPixelRatio(Math.min(devicePixelRatio||1,settings.quality==='high'?1.5:1.1)); renderer.setSize(viewport.width,viewport.height,false); renderer.shadowMap.enabled=settings.quality!=='low'; }
  if(flashlight) flashlight.castShadow=settings.quality==='high';
  showToast('Settings updated.');
}

function animate() {
  requestAnimationFrame(animate);
  const dt=Math.min(clock.getDelta()||0,0.05);
  if(state.started&&!state.paused&&!state.ended) {
    state.elapsed+=dt;
    if(state.damageCooldown>0) state.damageCooldown-=dt;
    updatePlayer(dt); updateFlashlight(dt); updateEquipment(dt); updateGhost(dt); updateTarget();
    if (state.mapOpen) { mapDrawTimer += dt; if (mapDrawTimer > 0.3) { drawMap(); mapDrawTimer = 0; } }
    if(state.toastTimer>0){state.toastTimer-=dt*1000;if(state.toastTimer<=0)ui.toast.classList.add('hidden');}
    if(dust) dust.rotation.y=Math.sin(state.elapsed*0.12)*0.025;
  }
  renderer.render(scene,camera);
}

function bindUI() {
  $('start-button').addEventListener('click',startGame);
  $('settings-button').addEventListener('click',()=>{ui.start.classList.remove('visible');ui.settings.classList.add('visible');});
  $('pause-settings-button').addEventListener('click',()=>{ui.pause.classList.remove('visible');ui.settings.classList.add('visible');});
  $('settings-back-button').addEventListener('click',()=>{applySettings();ui.settings.classList.remove('visible');if(state.started){ui.pause.classList.add('visible');state.paused=true;}else ui.start.classList.add('visible');});
  $('resume-button').addEventListener('click',resumeGame);
  $('restart-button').addEventListener('click',()=>{resetGame();state.started=true;state.paused=false;showGameUI();});
  $('main-menu-button').addEventListener('click',()=>{state.started=false;state.paused=true;ui.pause.classList.remove('visible');ui.hud.classList.add('hidden');ui.controls.classList.add('hidden');ui.crosshair.classList.add('hidden');ui.start.classList.add('visible');});
  $('close-note-button').addEventListener('click',()=>{ui.note.classList.remove('visible');state.paused=false;});
  $('close-keypad-button').addEventListener('click',()=>{ui.keypad.classList.remove('visible');state.paused=false;});
  $('keypad-screen').querySelectorAll('[data-digit]').forEach(btn=>btn.addEventListener('click',()=>keypadInput(btn.dataset.digit)));
  $('keypad-screen').querySelectorAll('[data-action]').forEach(btn=>btn.addEventListener('click',()=>keypadInput(btn.dataset.action)));
  $('end-restart-button').addEventListener('click',()=>{ui.end.classList.remove('visible');resetGame();state.started=true;state.paused=false;showGameUI();});
  $('end-menu-button').addEventListener('click',()=>{ui.end.classList.remove('visible');state.started=false;state.paused=true;ui.hud.classList.add('hidden');ui.controls.classList.add('hidden');ui.crosshair.classList.add('hidden');ui.start.classList.add('visible');});
  $('sensitivity-setting').addEventListener('input',()=>{$('sensitivity-label').textContent=`${Number($('sensitivity-setting').value).toFixed(1)}×`;});
  $('volume-setting').addEventListener('input',()=>{$('volume-label').textContent=`${$('volume-setting').value}%`;});
  $('brightness-setting').addEventListener('input',()=>{$('brightness-label').textContent=`${Number($('brightness-setting').value).toFixed(2)}×`; if(renderer) renderer.toneMappingExposure=Number($('brightness-setting').value);});
  document.addEventListener('visibilitychange',()=>{if(document.hidden){state.running=false; $('run-button').classList.remove('active'); if(state.started&&!state.paused&&!state.ended)pauseGame();}});
  window.addEventListener('resize',()=>{if(!renderer)return;const viewport=getGameViewport();camera.aspect=viewport.width/viewport.height;camera.updateProjectionMatrix();renderer.setSize(viewport.width,viewport.height,false);});
  window.addEventListener('orientationchange',()=>{if(!renderer)return;setTimeout(()=>{const viewport=getGameViewport();camera.aspect=viewport.width/viewport.height;camera.updateProjectionMatrix();renderer.setSize(viewport.width,viewport.height,false);},180);});
}

function showStartupHelp() {
  // Never put raw JavaScript errors or stack traces over the game screen.
  let panel=document.getElementById('startup-help');
  if(panel) return;
  panel=document.createElement('section');
  panel.id='startup-help';
  panel.style.cssText='position:fixed;inset:0;z-index:9999;display:flex;align-items:center;justify-content:center;padding:22px;background:rgba(7,12,18,.96);color:#f4f6f8;font:14px/1.55 system-ui,sans-serif;text-align:center;';
  const card=document.createElement('div');
  card.style.cssText='width:min(440px,100%);padding:26px;border:1px solid rgba(213,184,122,.45);background:#18232d;';
  const heading=document.createElement('h2'); heading.textContent='GHOST could not start'; heading.style.cssText='margin:0 0 12px;color:#e5ca91;font-size:23px;';
  const message=document.createElement('p'); message.textContent='The 3D graphics engine did not start. Open this project using Spck Preview or a local web server, keep internet access enabled for the Three.js library, and make sure WebGL is supported in your browser.';
  const button=document.createElement('button'); button.type='button'; button.textContent='TRY AGAIN'; button.style.cssText='margin-top:12px;min-height:46px;width:100%;border:1px solid #e5ca91;background:#d9bd82;color:#16130d;font-weight:800;letter-spacing:.12em;';
  button.addEventListener('click',()=>window.location.reload());
  card.append(heading,message,button); panel.append(card); document.body.append(panel);
}
window.showGhostStartupHelp = showStartupHelp;

function boot() {
  try {
    createWorld();
    clock=new THREE.Clock(false);
    setupControls(); bindUI();
    updateInventory(); updateBattery(); updateHealth(); updateToolUI();
    animate();
  } catch(error) {
    console.error('GHOST startup failed:', error);
    showStartupHelp();
  }
}

boot();
