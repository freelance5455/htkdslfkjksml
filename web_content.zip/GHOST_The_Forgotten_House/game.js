import * as THREE from 'three';

// GHOST: The Forgotten House — landscape-first mobile horror prototype.
// All environments and props are generated from Three.js geometry so the
// project runs without downloading model or texture packs.

const $ = (id) => document.getElementById(id);
const canvas = $('game-canvas');
const ui = {
  hud: $('hud'), controls: $('touch-controls'), crosshair: $('crosshair'),
  start: $('start-screen'), pause: $('pause-screen'), settings: $('settings-screen'),
  end: $('end-screen'), objective: $('objective-text'), inventory: $('inventory-items'),
  battery: $('battery-value'), batteryFill: $('battery-fill'), warning: $('ghost-warning'),
  prompt: $('interaction-prompt'), toast: $('toast'), damage: $('damage-flash'),
  note: $('note-screen'), keypad: $('keypad-screen'), keypadDisplay: $('keypad-display'),
  keypadMessage: $('keypad-message'), endKicker: $('end-kicker'), endTitle: $('end-title'),
  endDescription: $('end-description')
};

const settings = { quality: 'medium', difficulty: 'normal', sensitivity: 1, volume: 0.6 };
const state = {
  started: false, paused: true, ended: false, hidden: false, crouching: false,
  running: false, flashlight: true, battery: 100, elapsed: 0, ghostActive: false,
  powerOn: false, exitOpen: false, keypadInput: '', toastTimer: 0, warningTimer: 0,
  health: 1, lastNoiseAt: -999, lastNoise: new THREE.Vector3(0, 0, 0),
  inventory: new Set(), noteRead: false, panelUsed: false, ghostState: 'patrol',
  ghostStateTime: 0, lastSeenAt: -999, lastKnown: new THREE.Vector3(0, 0, 0),
  aiPathTimer: 0, ghostPath: [], hideSpot: null, damageCooldown: 0
};

let scene, camera, renderer, clock, flashlight, flashlightTarget, ghost, ghostLight;
let player = new THREE.Vector3(0, 0, 8.2);
let yaw = Math.PI, pitch = 0; // Looking toward the central hallway (-Z).
let joystick = { x: 0, y: 0, pointer: null };
let lookPointer = null, previousLook = null;
let interactables = [], colliders = [], wallMeshes = [], hideSpots = [];
let roomLights = [], dust = null, exitDoor, exitCollider = null, cabinetKey, cabinetRoot = null, cabinetCollider = null, keypadRoot;
let currentTarget = null, audioContext = null, masterGain = null;
const raycaster = new THREE.Raycaster();
const tempForward = new THREE.Vector3();
const tempRight = new THREE.Vector3();
const tempVec = new THREE.Vector3();
const WORLD = { minX: -9.65, maxX: 9.65, minZ: -15.65, maxZ: 15.5 };

function material(color, roughness = 0.9, extra = {}) {
  return new THREE.MeshStandardMaterial({ color, roughness, ...extra });
}
const mats = {
  floor: material(0x282a2c), wood: material(0x493a2e), woodDark: material(0x29231f),
  wall: material(0x393a3b), wallAlt: material(0x302e30), trim: material(0x17191c),
  brass: material(0xb28b4d, 0.38, { metalness: 0.55 }), paper: material(0xcfc4a6),
  glass: new THREE.MeshStandardMaterial({ color: 0x9fc6d5, roughness: 0.18, metalness: 0.15, transparent: true, opacity: 0.38 }),
  ghost: new THREE.MeshStandardMaterial({ color: 0xb9d7dd, roughness: 0.28, transparent: true, opacity: 0.48, emissive: 0x1e3942, emissiveIntensity: 0.7 }),
  eye: new THREE.MeshBasicMaterial({ color: 0xe6f4f5 }),
  red: material(0x662d33), metal: material(0x55565a, 0.4, { metalness: 0.65 })
};

function addBox(name, x, y, z, w, h, d, mat, { collider = false, parent = scene, cast = true, receive = true } = {}) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
  mesh.name = name;
  mesh.position.set(x, y, z);
  mesh.castShadow = cast;
  mesh.receiveShadow = receive;
  parent.add(mesh);
  if (collider) colliders.push({ x, z, hw: w / 2, hd: d / 2 });
  return mesh;
}

function addWall(x, z, w, d, height = 4.3, mat = mats.wall) {
  const mesh = addBox('wall', x, height / 2, z, w, height, d, mat, { collider: true });
  wallMeshes.push(mesh);
  // A narrow baseboard makes the room edges easier to read in low light.
  addBox('baseboard', x, 0.12, z, w, 0.24, d + 0.025, mats.trim, { cast: false });
  return mesh;
}

function addInteractable(root, action, label, range = 3.2) {
  root.userData.action = action;
  root.userData.label = label;
  root.userData.range = range;
  root.traverse((child) => {
    if (child.isMesh) {
      child.userData.action = action;
      child.userData.label = label;
      child.userData.range = range;
    }
  });
  interactables.push(root);
  return root;
}

function addFurnitureBox(x, y, z, w, h, d, mat, collision = true) {
  return addBox('furniture', x, y, z, w, h, d, mat, { collider: collision });
}

function createRoomDecor() {
  // Entrance hall: rug, console and framed portraits.
  addBox('hall rug', 0, 0.015, 7.5, 5.2, 0.025, 3.5, material(0x33272a));
  addFurnitureBox(0, 0.52, 4.25, 2.8, 1.04, 0.65, mats.woodDark);
  addBox('console top', 0, 1.08, 4.25, 3.0, 0.12, 0.78, mats.wood);
  addBox('portrait frame', -5.5, 2.4, 3.17, 1.15, 1.5, 0.12, mats.brass, false);
  addBox('portrait canvas', -5.5, 2.4, 3.095, 0.98, 1.31, 0.035, material(0x20252b), false);
  addBox('portrait frame', 5.5, 2.4, 3.17, 1.15, 1.5, 0.12, mats.brass, false);
  addBox('portrait canvas', 5.5, 2.4, 3.095, 0.98, 1.31, 0.035, material(0x252127), false);

  // Living room furniture, west side.
  addFurnitureBox(-7.7, 0.55, -1.6, 2.1, 1.1, 1.0, mats.woodDark);
  addFurnitureBox(-5.3, 0.42, -6.1, 2.0, 0.84, 1.0, mats.red);
  addFurnitureBox(-8.8, 0.65, -4.0, 0.75, 1.3, 0.75, mats.wood);
  addBox('shelf', -9.35, 1.45, -2.5, 0.35, 2.7, 2.7, mats.woodDark, { collider: true });
  for (let i = 0; i < 5; i++) addBox('book', -9.12, 0.45 + i * 0.27, -3.4 + (i % 2) * 0.18, 0.12, 0.2, 0.32, material([0x52343a,0x31404a,0x756044,0x343b31,0x594a60][i]), { cast: false });

  // Library, east side.
  addFurnitureBox(8.8, 1.35, -3.8, 0.45, 2.7, 6.6, mats.woodDark);
  addFurnitureBox(5.2, 0.55, -1.5, 2.1, 1.1, 1.0, mats.wood);
  addBox('library table top', 5.2, 1.12, -1.5, 2.4, 0.12, 1.2, mats.woodDark);
  for (let i = 0; i < 7; i++) addBox('book', 8.53, 0.58 + (i % 3) * 0.32, -6.3 + i * 0.65, 0.12, 0.25, 0.5, material([0x55403a,0x2c4148,0x66563d,0x354034][i % 4]), { cast: false });

  // Bedroom, west rear.
  addFurnitureBox(-6.4, 0.42, -10.0, 3.2, 0.84, 4.0, mats.woodDark);
  addBox('mattress', -6.4, 0.92, -10.0, 3.0, 0.3, 3.7, material(0x5c5250));
  addBox('pillow', -6.4, 1.14, -11.35, 1.2, 0.18, 0.75, material(0xb2aaa0));
  addFurnitureBox(-9.0, 0.55, -14.9, 0.65, 1.1, 0.75, mats.wood);

  // Basement, east rear.
  addFurnitureBox(8.5, 0.75, -14.2, 1.0, 1.5, 1.0, mats.metal);
  addBox('pipe', 3.0, 3.5, -13.6, 0.18, 0.18, 5.0, mats.metal, { collider: false });
  addBox('pipe', 3.0, 3.1, -10.9, 0.18, 0.18, 0.18, mats.metal, { collider: false });

  // Lamps and lights create distinct room silhouettes.
  const lampSpecs = [
    [-6.7, 2.5, -3.7, 0xb58e61], [6.5, 2.5, -3.7, 0x8f9caf],
    [-6.5, 2.5, -12.0, 0xb58e61], [6.5, 2.5, -12.0, 0x9daab5],
    [0, 3.2, 7.0, 0x9e8d72]
  ];
  for (const [x,y,z,color] of lampSpecs) {
    const bulb = new THREE.PointLight(color, 0.55, 8, 2);
    bulb.position.set(x, y, z); scene.add(bulb); roomLights.push(bulb);
    const shade = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.34, 0.35, 10), mats.woodDark);
    shade.position.set(x, y + 0.15, z); scene.add(shade);
  }
}

function createWorld() {
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x070b12);
  scene.fog = new THREE.FogExp2(0x0b1018, 0.026);
  camera = new THREE.PerspectiveCamera(74, innerWidth / innerHeight, 0.08, 75);
  camera.rotation.order = 'YXZ';
  camera.position.set(player.x, 1.62, player.z);
  renderer = new THREE.WebGLRenderer({ canvas, antialias: settings.quality !== 'low', powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(devicePixelRatio || 1, settings.quality === 'high' ? 1.7 : 1.25));
  renderer.setSize(innerWidth, innerHeight, false);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.05;
  renderer.shadowMap.enabled = settings.quality !== 'low';
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;

  scene.add(new THREE.HemisphereLight(0x8794a8, 0x17151a, 0.42));
  const moon = new THREE.DirectionalLight(0x8da4be, 0.65);
  moon.position.set(-7, 12, 8); moon.castShadow = settings.quality === 'high';
  moon.shadow.mapSize.set(768, 768); scene.add(moon);

  // Continuous floor with dark wood strips.
  addBox('floor', 0, -0.18, -2, 20, 0.36, 28, mats.floor, { cast: false });
  for (let z = -15; z <= 10; z += 2) {
    addBox('floor plank seam', 0, 0.006, z, 19.7, 0.008, 0.025, material(0x171a1d), { cast: false });
  }
  addBox('ceiling', 0, 4.5, -2, 20, 0.25, 28, material(0x202327), { cast: false });
  addBox('exit porch', 0, -0.12, 13.3, 4.4, 0.18, 3.0, material(0x343a40), { cast: false });

  // Outer walls, leaving a two-metre gap for the front exit door.
  addWall(-10, -2, 0.4, 28.4, 4.5);
  addWall(10, -2, 0.4, 28.4, 4.5);
  addWall(0, -16, 20.4, 0.4, 4.5);
  addWall(-5.55, 12, 8.9, 0.4, 4.5);
  addWall(5.55, 12, 8.9, 0.4, 4.5);

  // Corridor side walls. Openings at z=-4 and z=-12 lead into four rooms.
  for (const x of [-2.15, 2.15]) {
    addWall(x, -14.55, 0.32, 2.9);
    addWall(x, -8.95, 0.32, 5.7);
    addWall(x, -1.4, 0.32, 2.8);
  }
  // Entrance hall feeds into the central corridor.
  addWall(-6.05, 3, 7.9, 0.32);
  addWall(6.05, 3, 7.9, 0.32);
  // Separate front/rear wings with door-sized openings.
  addWall(-6, -8, 8.0, 0.32);
  addWall(6, -8, 8.0, 0.32);
  // Door jambs make all room openings legible.
  for (const x of [-2.15, 2.15]) for (const z of [-4, -12]) {
    addBox('door jamb', x, 2.05, z - 1.1, 0.34, 4.1, 0.18, mats.woodDark, { collider: true });
    addBox('door jamb', x, 2.05, z + 1.1, 0.34, 4.1, 0.18, mats.woodDark, { collider: true });
  }

  // Exit door is a pivoted slab; its collider is removed after unlocking.
  exitDoor = new THREE.Group();
  exitDoor.position.set(-1.05, 0, 11.78);
  const doorSlab = new THREE.Mesh(new THREE.BoxGeometry(2.1, 3.6, 0.22), mats.woodDark);
  doorSlab.position.set(1.05, 1.8, 0); doorSlab.castShadow = true; exitDoor.add(doorSlab);
  const doorPanel = new THREE.Mesh(new THREE.BoxGeometry(1.65, 2.9, 0.05), mats.wood);
  doorPanel.position.set(1.05, 1.8, -0.13); exitDoor.add(doorPanel);
  const knob = new THREE.Mesh(new THREE.SphereGeometry(0.09, 10, 8), mats.brass);
  knob.position.set(0.3, 1.65, -0.24); exitDoor.add(knob);
  scene.add(exitDoor);
  exitCollider = { x: 0, z: 11.78, hw: 1.06, hd: 0.22, exit: true };
  colliders.push(exitCollider);
  addInteractable(exitDoor, 'exit', 'LOCKED EXIT', 3.4);

  createRoomDecor();
  createPickupsAndPuzzles();
  createGhost();
  createDust();
  createFlashlight();
}

function createPickupMesh(kind, x, y, z) {
  const group = new THREE.Group(); group.position.set(x, y, z); scene.add(group);
  if (kind === 'key') {
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.19, 0.045, 8, 18), mats.brass);
    ring.rotation.x = Math.PI / 2; group.add(ring);
    const shaft = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.42, 0.07), mats.brass); shaft.position.y = -0.25; group.add(shaft);
    const tooth = new THREE.Mesh(new THREE.BoxGeometry(0.19, 0.09, 0.07), mats.brass); tooth.position.set(0.07, -0.42, 0); group.add(tooth);
  } else if (kind === 'fuse') {
    const body = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.11, 0.5, 12), material(0xc6b9a2, 0.35, { metalness: 0.25 }));
    body.rotation.z = Math.PI / 2; group.add(body);
    for (const dx of [-0.28, 0.28]) { const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.13,0.13,0.08,10), mats.brass); cap.rotation.z = Math.PI/2; cap.position.x = dx; group.add(cap); }
  } else if (kind === 'note') {
    const paper = new THREE.Mesh(new THREE.BoxGeometry(0.58, 0.045, 0.42), mats.paper); paper.rotation.y = -0.15; group.add(paper);
    for (let i=0;i<3;i++) addBox('note ink', x, y + 0.026, z - 0.12 + i*0.1, 0.35, 0.008, 0.012, mats.woodDark, { cast:false });
  } else if (kind === 'exitKey') {
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.16, 0.04, 8, 16), mats.brass); ring.rotation.x = Math.PI/2; group.add(ring);
    const shaft = new THREE.Mesh(new THREE.BoxGeometry(0.07,0.45,0.07), mats.brass); shaft.position.y=-0.22; group.add(shaft);
  }
  group.traverse(o => { if (o.isMesh) { o.castShadow = true; o.userData.action = kind; } });
  return group;
}

function createPickupsAndPuzzles() {
  const key = createPickupMesh('key', -6.8, 1.18, -4.25);
  addInteractable(key, 'brassKey', 'PICK UP BRASS KEY', 3.3);
  const fuse = createPickupMesh('fuse', -6.8, 1.2, -12.0);
  addInteractable(fuse, 'fuse', 'PICK UP FUSE', 3.3);
  const note = createPickupMesh('note', 6.0, 1.2, -1.5);
  addInteractable(note, 'note', 'READ THE NOTE', 3.3);

  // Hiding wardrobes (the player can use either one).
  const wardrobeA = new THREE.Group(); wardrobeA.position.set(-8.4, 0, -6.0); wardrobeA.rotation.y=-Math.PI/2; scene.add(wardrobeA);
  const bodyA = new THREE.Mesh(new THREE.BoxGeometry(1.25,2.8,0.85), mats.woodDark); bodyA.position.y=1.4; wardrobeA.add(bodyA);
  const seamA = new THREE.Mesh(new THREE.BoxGeometry(0.035,2.4,0.025), mats.brass); seamA.position.set(0,1.4,-0.44); wardrobeA.add(seamA);
  addInteractable(wardrobeA, 'hide', 'HIDE IN WARDROBE', 2.7);
  hideSpots.push({ position: new THREE.Vector3(-8.4,0,-6.0), group: wardrobeA });
  const wardrobeB = new THREE.Group(); wardrobeB.position.set(-8.8, 0, -14.5); wardrobeB.rotation.y=-Math.PI/2; scene.add(wardrobeB);
  const bodyB = new THREE.Mesh(new THREE.BoxGeometry(1.25,2.8,0.85), mats.woodDark); bodyB.position.y=1.4; wardrobeB.add(bodyB);
  const seamB = new THREE.Mesh(new THREE.BoxGeometry(0.035,2.4,0.025), mats.brass); seamB.position.set(0,1.4,-0.44); wardrobeB.add(seamB);
  addInteractable(wardrobeB, 'hide', 'HIDE IN WARDROBE', 2.7);
  hideSpots.push({ position: new THREE.Vector3(-8.8,0,-14.5), group: wardrobeB });
  colliders.push({ x:-8.4,z:-6,hw:0.65,hd:0.45 }, { x:-8.8,z:-14.5,hw:0.65,hd:0.45 });

  // Power keypad in the basement.
  keypadRoot = new THREE.Group(); keypadRoot.position.set(7.6, 1.55, -12.6); keypadRoot.rotation.y=Math.PI/2; scene.add(keypadRoot);
  const panel = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.9, 0.16), mats.metal); keypadRoot.add(panel);
  const screen = new THREE.Mesh(new THREE.BoxGeometry(0.62,0.2,0.025), material(0x18312f,0.3, { emissive:0x1a6859, emissiveIntensity:0.45 })); screen.position.set(0,0.22,-0.1); keypadRoot.add(screen);
  for (let i=0;i<9;i++) {
    const keyBtn = new THREE.Mesh(new THREE.BoxGeometry(0.13,0.09,0.035), mats.brass);
    keyBtn.position.set(-0.22+(i%3)*0.22,-0.03-Math.floor(i/3)*0.16,-0.11); keypadRoot.add(keyBtn);
  }
  addInteractable(keypadRoot, 'keypad', 'USE POWER KEYPAD', 3.4);

  // Cabinet holding the exit key; it becomes interactable when power is restored.
  const cabinet = new THREE.Group(); cabinet.position.set(4.3,0,-14.4); cabinet.rotation.y=Math.PI/2; scene.add(cabinet);
  const cabBody = new THREE.Mesh(new THREE.BoxGeometry(1.5,1.8,0.85), mats.woodDark); cabBody.position.y=0.9; cabinet.add(cabBody);
  const cabDoor = new THREE.Mesh(new THREE.BoxGeometry(1.25,1.55,0.08), mats.wood); cabDoor.position.set(0,0.9,-0.46); cabinet.add(cabDoor);
  const cabKnob = new THREE.Mesh(new THREE.SphereGeometry(0.07,10,8), mats.brass); cabKnob.position.set(0.43,0.9,-0.54); cabinet.add(cabKnob);
  cabinetKey = createPickupMesh('exitKey', 4.3, 1.18, -14.4);
  cabinetKey.visible = false;
  addInteractable(cabinet, 'cabinet', 'OPEN KEY CABINET', 3.4);
  cabinet.userData.exitKey = cabinetKey;
  cabinetRoot = cabinet;
  cabinetCollider = { x:4.3,z:-14.4,hw:0.45,hd:0.78 };
  colliders.push(cabinetCollider);
}

function createGhost() {
  ghost = new THREE.Group(); ghost.position.set(6,0,-13); scene.add(ghost);
  const robe = new THREE.Mesh(new THREE.ConeGeometry(0.62,2.55,12,1,true), mats.ghost);
  robe.position.y=1.28; robe.rotation.x=Math.PI; ghost.add(robe);
  const torso = new THREE.Mesh(new THREE.SphereGeometry(0.48,16,12), mats.ghost); torso.scale.set(0.85,1.2,0.55); torso.position.y=2.15; ghost.add(torso);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.39,16,12), mats.ghost); head.position.y=2.95; ghost.add(head);
  const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.055,8,8), mats.eye); eyeL.position.set(-0.14,3.0,-0.33); ghost.add(eyeL);
  const eyeR = eyeL.clone(); eyeR.position.x=0.14; ghost.add(eyeR);
  const aura = new THREE.PointLight(0x9ec8d5, 0.6, 4, 2); aura.position.set(0,2,0); ghost.add(aura); ghostLight=aura;
  ghost.visible = false;
}

function createDust() {
  const count = settings.quality === 'low' ? 120 : 280;
  const positions = new Float32Array(count*3);
  for (let i=0;i<count;i++) {
    positions[i*3] = -9.3 + Math.random()*18.6;
    positions[i*3+1] = 0.4 + Math.random()*3.3;
    positions[i*3+2] = -15.3 + Math.random()*26.5;
  }
  const geo = new THREE.BufferGeometry(); geo.setAttribute('position',new THREE.BufferAttribute(positions,3));
  const points = new THREE.Points(geo,new THREE.PointsMaterial({color:0xb8b9b5,size:0.025,transparent:true,opacity:0.42,depthWrite:false}));
  scene.add(points); dust=points;
}

function createFlashlight() {
  flashlight = new THREE.SpotLight(0xdce8f5, 3.5, 18, Math.PI/7, 0.55, 1.55);
  flashlight.position.copy(camera.position); flashlight.castShadow = settings.quality === 'high';
  flashlight.target.position.set(0,1.4,0); scene.add(flashlight,flashlight.target);
  flashlightTarget = flashlight.target;
}

function setObjective(text) { ui.objective.textContent = text; }
function showToast(text, duration = 2300) {
  ui.toast.textContent = text; ui.toast.classList.remove('hidden'); state.toastTimer = duration;
}
function updateInventory() {
  ui.inventory.innerHTML = '';
  const labels = { brassKey:'BRASS KEY', fuse:'FUSE', exitKey:'EXIT KEY' };
  if (!state.inventory.size) { ui.inventory.innerHTML = '<span class="inventory-empty">Empty</span>'; return; }
  for (const item of state.inventory) {
    const chip = document.createElement('span'); chip.className = 'inventory-chip'; chip.textContent = labels[item] || item.toUpperCase(); ui.inventory.appendChild(chip);
  }
}
function hasItem(item) { return state.inventory.has(item); }
function removeCollider(tag) { colliders = colliders.filter(c => c !== tag); }

function beginAudio() {
  try {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return;
    if (!audioContext) {
      audioContext = new AudioCtx(); masterGain = audioContext.createGain(); masterGain.gain.value = settings.volume; masterGain.connect(audioContext.destination);
      const osc = audioContext.createOscillator(); const gain = audioContext.createGain();
      osc.type='sine'; osc.frequency.value=48; gain.gain.value=0.018; osc.connect(gain); gain.connect(masterGain); osc.start();
      const lfo = audioContext.createOscillator(); const lfoGain = audioContext.createGain(); lfo.frequency.value=0.12; lfoGain.gain.value=4; lfo.connect(lfoGain); lfoGain.connect(osc.frequency); lfo.start();
    }
    audioContext.resume();
  } catch (e) { /* Audio is optional on browsers with restricted autoplay. */ }
}
function soundTone(freq=440,duration=0.12,volume=0.08,type='sine') {
  if (!audioContext || !masterGain || settings.volume<=0) return;
  const osc=audioContext.createOscillator(), gain=audioContext.createGain();
  osc.type=type; osc.frequency.value=freq; gain.gain.setValueAtTime(volume,audioContext.currentTime); gain.gain.exponentialRampToValueAtTime(0.001,audioContext.currentTime+duration);
  osc.connect(gain); gain.connect(masterGain); osc.start(); osc.stop(audioContext.currentTime+duration);
}

function requestLandscape() {
  try { if (!document.fullscreenElement && document.documentElement.requestFullscreen) document.documentElement.requestFullscreen().catch(()=>{}); } catch(e){}
  try { if (screen.orientation && screen.orientation.lock) screen.orientation.lock('landscape').catch(()=>{}); } catch(e){}
}

function startGame() {
  requestLandscape(); beginAudio();
  resetGame(); state.started=true; state.paused=false; state.ended=false;
  showGameUI();
  showToast('Find the brass key in the living room.');
  clock.start();
}
function showGameUI() {
  ui.start.classList.remove('visible'); ui.pause.classList.remove('visible'); ui.settings.classList.remove('visible'); ui.end.classList.remove('visible');
  ui.hud.classList.remove('hidden'); ui.controls.classList.remove('hidden'); ui.crosshair.classList.remove('hidden');
}
function pauseGame() {
  if (!state.started || state.ended) return;
  state.paused=true; ui.pause.classList.add('visible');
}
function resumeGame() {
  state.paused=false; ui.pause.classList.remove('visible'); beginAudio();
}
function resetGame() {
  state.hidden=false; state.crouching=false; state.running=false; state.flashlight=true; state.battery=100;
  state.elapsed=0; state.ghostActive=false; state.powerOn=false; state.exitOpen=false; state.keypadInput='';
  state.health=1; state.inventory.clear(); state.noteRead=false; state.panelUsed=false; state.ghostState='patrol';
  state.ghostStateTime=0; state.lastSeenAt=-999; state.lastNoiseAt=-999; state.lastNoise.set(0,0,0);
  state.aiPathTimer=0; state.ghostPath=[]; state.hideSpot=null; state.damageCooldown=0; state.patrolIndex=0; state.noiseRadius=4.5;
  player.set(0,0,8.2); yaw=0; pitch=0;
  for (const root of interactables) {
    if (!root) continue;
    const action = root.userData.action;
    if (action==='brassKey' || action==='fuse' || action==='note') root.visible=true;
  }
  cabinetKey.visible=false;
  exitDoor.rotation.y=0;
  if (exitCollider) exitCollider.hw=1.06;
  ghost.position.set(6,0,-13); ghost.visible=false; state.patrolIndex=0;
  if (ghostLight) ghostLight.intensity=0.6;
  if (cabinetRoot) {
    cabinetRoot.visible=true;
    if (cabinetRoot.children[1]) { cabinetRoot.children[1].rotation.y=0; cabinetRoot.children[1].position.set(0,0.9,-0.46); }
  }
  if (cabinetCollider && !colliders.includes(cabinetCollider)) colliders.push(cabinetCollider);
  if (exitCollider && !colliders.includes(exitCollider)) colliders.push(exitCollider);
  if (flashlight) flashlight.visible=true;
  updateInventory(); updateBattery(); setObjective('Find a way out of the house.');
  ui.warning.classList.add('hidden'); ui.prompt.classList.add('hidden');
  ui.damage.style.background='rgba(135,15,28,0)';
}

function updateBattery() {
  ui.battery.textContent = `${Math.ceil(state.battery)}%`;
  ui.batteryFill.style.width = `${state.battery}%`;
  ui.batteryFill.style.background = state.battery < 20 ? '#b75d63' : '#d5b87a';
}
function notifyNoise(position, radius) {
  state.lastNoise.copy(position); state.lastNoiseAt=state.elapsed; state.noiseRadius=radius;
}

function collides(x,z,radius=0.34) {
  if (x < WORLD.minX || x > WORLD.maxX || z < WORLD.minZ || z > WORLD.maxZ) return true;
  for (const c of colliders) {
    if (Math.abs(x-c.x) < c.hw+radius && Math.abs(z-c.z) < c.hd+radius) return true;
  }
  return false;
}
function moveWithCollision(position, dx, dz, radius=0.34) {
  const nx=position.x+dx, nz=position.z+dz;
  if (!collides(nx,position.z,radius)) position.x=nx;
  if (!collides(position.x,nz,radius)) position.z=nz;
}

function updatePlayer(dt) {
  if (state.hidden) return;
  const joyX=joystick.x, joyY=joystick.y;
  const keyboardForward=(keys.has('KeyW')||keys.has('ArrowUp')?1:0)-(keys.has('KeyS')||keys.has('ArrowDown')?1:0);
  const keyboardSide=(keys.has('KeyD')||keys.has('ArrowRight')?1:0)-(keys.has('KeyA')||keys.has('ArrowLeft')?1:0);
  let forward=-joyY+keyboardForward, side=joyX+keyboardSide;
  const mag=Math.hypot(forward,side); if (mag>1) { forward/=mag; side/=mag; }
  const isMoving=mag>0.08;
  const speed=state.crouching?1.25:(state.running?4.55:2.55);
  const fx=-Math.sin(yaw), fz=-Math.cos(yaw);
  const rx=Math.cos(yaw), rz=-Math.sin(yaw);
  const dx=(fx*forward+rx*side)*speed*dt;
  const dz=(fz*forward+rz*side)*speed*dt;
  moveWithCollision(player,dx,dz);
  if (state.exitOpen && player.z > 13.15) { finishGame(true); return; }
  if (isMoving) {
    const noiseRadius=state.crouching?1.2:(state.running?12:4.8);
    if (state.elapsed-state.lastNoiseAt > (state.running?0.2:0.45)) notifyNoise(player,noiseRadius);
  }
  camera.position.set(player.x,state.hidden?1.25:(state.crouching?1.05:1.62),player.z);
  camera.rotation.set(pitch,yaw,0,'YXZ');
}

const keys = new Set();
window.addEventListener('keydown', e => {
  keys.add(e.code);
  if (['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code)) e.preventDefault();
  if (e.code==='Escape' && state.started && !state.paused) pauseGame();
  if (e.code==='KeyE') interact();
  if (e.code==='ShiftLeft'||e.code==='ShiftRight') state.running=true;
  if (e.code==='KeyC') toggleCrouch();
  if (e.code==='KeyF') toggleFlashlight();
  if (e.code==='KeyH') toggleHide();
});
window.addEventListener('keyup', e => { keys.delete(e.code); if (e.code==='ShiftLeft'||e.code==='ShiftRight') state.running=false; });

function setupControls() {
  const joy=$('joystick'), knob=$('joystick-knob');
  const updateJoy = (clientX,clientY) => {
    const rect=joy.getBoundingClientRect(), cx=rect.left+rect.width/2, cy=rect.top+rect.height/2;
    let dx=clientX-cx, dy=clientY-cy; const max=rect.width*0.34;
    const len=Math.hypot(dx,dy); if(len>max){dx=dx/len*max;dy=dy/len*max;}
    joystick.x=dx/max; joystick.y=dy/max;
    knob.style.transform=`translate(${dx}px,${dy}px)`;
  };
  joy.addEventListener('pointerdown',e=>{ e.preventDefault(); joystick.pointer=e.pointerId; joy.setPointerCapture(e.pointerId); updateJoy(e.clientX,e.clientY); });
  joy.addEventListener('pointermove',e=>{ if(joystick.pointer===e.pointerId) updateJoy(e.clientX,e.clientY); });
  const clearJoy=e=>{ if(joystick.pointer===e.pointerId){joystick.pointer=null;joystick.x=0;joystick.y=0;knob.style.transform='translate(0,0)';} };
  joy.addEventListener('pointerup',clearJoy); joy.addEventListener('pointercancel',clearJoy);

  const lookZone=$('look-zone');
  lookZone.addEventListener('pointerdown',e=>{ if(!state.started||state.paused||state.ended) return; lookPointer=e.pointerId; previousLook={x:e.clientX,y:e.clientY}; lookZone.setPointerCapture(e.pointerId); });
  lookZone.addEventListener('pointermove',e=>{
    if(lookPointer!==e.pointerId||!previousLook) return;
    const dx=e.clientX-previousLook.x, dy=e.clientY-previousLook.y; previousLook={x:e.clientX,y:e.clientY};
    yaw-=dx*0.0045*settings.sensitivity; pitch-=dy*0.0038*settings.sensitivity;
    pitch=THREE.MathUtils.clamp(pitch,-1.05,1.0); camera.rotation.set(pitch,yaw,0,'YXZ');
  });
  const endLook=e=>{if(lookPointer===e.pointerId){lookPointer=null;previousLook=null;}};
  lookZone.addEventListener('pointerup',endLook); lookZone.addEventListener('pointercancel',endLook);

  $('run-button').addEventListener('pointerdown',e=>{e.preventDefault();state.running=true;$('run-button').classList.add('active');});
  const stopRun=()=>{state.running=false;$('run-button').classList.remove('active');};
  $('run-button').addEventListener('pointerup',stopRun); $('run-button').addEventListener('pointercancel',stopRun); $('run-button').addEventListener('pointerleave',stopRun);
  $('crouch-button').addEventListener('click',toggleCrouch);
  $('hide-button').addEventListener('click',toggleHide);
  $('interact-button').addEventListener('click',interact);
  $('flashlight-button').addEventListener('click',toggleFlashlight);
  $('pause-button').addEventListener('click',pauseGame);
}

function toggleCrouch() { state.crouching=!state.crouching; $('crouch-button').classList.toggle('active',state.crouching); showToast(state.crouching?'Crouching: quieter, but slower.':'You stand up.'); }
function toggleFlashlight() {
  if (state.battery<=0 && !state.flashlight) { showToast('The flashlight battery is empty.'); return; }
  state.flashlight=!state.flashlight; flashlight.visible=state.flashlight; $('flashlight-button').classList.toggle('active',state.flashlight);
  soundTone(state.flashlight?620:280,0.08,0.035);
}
function toggleHide() {
  if (state.hidden) {
    state.hidden=false; state.hideSpot=null; camera.position.set(player.x,1.62,player.z); showToast('You leave the hiding place.');
    notifyNoise(player,2.2); return;
  }
  let nearest=null, dist=Infinity;
  for (const spot of hideSpots) { const d=player.distanceTo(spot.position); if(d<2.2&&d<dist){nearest=spot;dist=d;} }
  if (!nearest) { showToast('Move closer to a wardrobe to hide.'); return; }
  state.hidden=true; state.hideSpot=nearest; state.crouching=false; state.running=false;
  camera.position.set(nearest.position.x,1.25,nearest.position.z+0.85);
  showToast('Hidden. Stay quiet until the ghost leaves.');
}

function findTarget() {
  if (state.hidden) return null;
  camera.getWorldDirection(tempForward);
  let best=null, bestScore=Infinity;
  for (const root of interactables) {
    if (!root.visible) continue;
    const action=root.userData.action;
    if (action==='cabinet' && (!state.powerOn || hasItem('exitKey'))) continue;
    if (action==='keypad' && state.powerOn) continue;
    const pos=new THREE.Vector3(); root.getWorldPosition(pos);
    if (action==='exit') pos.set(0,1.6,11.78);
    if (action==='hide') pos.y=1.45;
    if (action==='cabinet') pos.y=1.2;
    const delta=pos.clone().sub(camera.position); const distance=delta.length();
    const dot=tempForward.dot(delta.normalize());
    const range=root.userData.range||3.2;
    if(distance<=range && dot>0.48) {
      const score=distance+(1-dot)*1.8;
      if(score<bestScore){best=root;bestScore=score;}
    }
  }
  return best;
}
function updateTarget() {
  currentTarget=findTarget();
  if (currentTarget) {
    let label=currentTarget.userData.label;
    if(currentTarget.userData.action==='exit') label=state.exitOpen?'OPEN EXIT':'LOCKED EXIT';
    if(currentTarget.userData.action==='keypad' && !hasItem('fuse')) label='POWER PANEL (NEEDS FUSE)';
    ui.prompt.textContent=`✋  ${label}  •  USE`;
    ui.prompt.classList.remove('hidden');
  } else ui.prompt.classList.add('hidden');
}

function interact() {
  if (!state.started||state.paused||state.ended) return;
  if (state.hidden) { toggleHide(); return; }
  const target=findTarget(); if(!target){showToast('Nothing to interact with. Look closer at an object.');return;}
  const action=target.userData.action;
  if(action==='brassKey') {
    state.inventory.add('brassKey'); target.visible=false; updateInventory(); state.ghostActive=true; ghost.visible=true;
    setObjective('Read the note in the library. Find the fuse in the bedroom.');
    showToast('Brass key collected. Something has awakened.'); soundTone(740,0.22,0.06);
  } else if(action==='fuse') {
    state.inventory.add('fuse'); target.visible=false; updateInventory();
    setObjective('Find the power keypad in the basement.'); showToast('Fuse collected.'); soundTone(520,0.15,0.05);
  } else if(action==='note') {
    state.noteRead=true; ui.note.classList.add('visible'); state.paused=true;
    setObjective('The note reveals the power code: 3142.');
  } else if(action==='keypad') {
    if(!hasItem('fuse')) { showToast('The power panel is missing a fuse.'); return; }
    state.keypadInput=''; updateKeypad(); ui.keypad.classList.add('visible'); state.paused=true;
  } else if(action==='cabinet') {
    if(!state.powerOn) { showToast('The cabinet lock has no power.'); return; }
    cabinetKey.visible=false; state.inventory.add('exitKey'); updateInventory();
    if (cabinetCollider) removeCollider(cabinetCollider);
    if (cabinetRoot && cabinetRoot.children[1]) { cabinetRoot.children[1].rotation.y=-0.95; cabinetRoot.children[1].position.x=0.45; }
    setObjective('Return to the entrance and unlock the front door.');
    showToast('You found the exit key. Get out!'); soundTone(880,0.3,0.06);
  } else if(action==='hide') toggleHide();
  else if(action==='exit') {
    if(!state.exitOpen) {
      if(!hasItem('exitKey')) { showToast('The front door is locked. Find the exit key.'); return; }
      state.exitOpen=true;
      const c=colliders.find(v=>v.exit); if(c) removeCollider(c);
      exitDoor.rotation.y=-1.35;
      setObjective('The exit is open. Escape the house!'); showToast('The lock clicks. The door swings open.'); soundTone(260,0.35,0.08,'triangle');
    } else finishGame(true);
  }
}

function updateKeypad() {
  ui.keypadDisplay.textContent=(state.keypadInput.padEnd(4,'_').split('').join(' '));
  ui.keypadMessage.textContent=state.inventory.has('fuse')?'Fuse installed. Enter the four-digit code.':'The panel needs a fuse and the correct code.';
}
function keypadInput(value) {
  if(value==='clear') state.keypadInput='';
  else if(value==='enter') {
    if(!hasItem('fuse')) {ui.keypadMessage.textContent='A fuse is required.';return;}
    if(state.keypadInput==='3142') {
      state.powerOn=true; state.panelUsed=true; state.inventory.delete('fuse'); updateInventory();
      ui.keypad.classList.remove('visible'); state.paused=false;
      cabinetKey.visible=false;
      setObjective('Power restored. Open the cabinet in the basement for the exit key.');
      showToast('POWER RESTORED. Something is moving upstairs.');
      soundTone(160,0.5,0.1,'sawtooth');
    } else { ui.keypadMessage.textContent='Incorrect code. The note may contain a clue.'; state.keypadInput=''; }
  } else if(state.keypadInput.length<4) state.keypadInput+=value;
  updateKeypad();
}

function lineOfSight(from,to) {
  const dir=to.clone().sub(from); const dist=dir.length(); dir.normalize();
  raycaster.set(from,dir); raycaster.far=dist;
  const hits=raycaster.intersectObjects(wallMeshes,false);
  return hits.length===0;
}

function gridPath(start,target) {
  const sx=Math.round(start.x), sz=Math.round(start.z), tx=Math.round(target.x), tz=Math.round(target.z);
  const key=(x,z)=>`${x},${z}`;
  const queue=[[sx,sz]], came=new Map(); came.set(key(sx,sz),null);
  const dirs=[[1,0],[-1,0],[0,1],[0,-1]];
  let found=false, iterations=0;
  while(queue.length && iterations++<1800) {
    const [x,z]=queue.shift();
    if(x===tx&&z===tz){found=true;break;}
    for(const [dx,dz] of dirs){
      const nx=x+dx,nz=z+dz,k=key(nx,nz);
      if(nx<WORLD.minX+0.5||nx>WORLD.maxX-0.5||nz<WORLD.minZ+0.5||nz>WORLD.maxZ-0.5||came.has(k)) continue;
      if(collides(nx,nz,0.28)) continue;
      came.set(k,[x,z]);queue.push([nx,nz]);
    }
  }
  if(!found) return [];
  const path=[]; let cur=[tx,tz];
  while(cur){path.push(new THREE.Vector3(cur[0],0,cur[1]));cur=came.get(key(cur[0],cur[1]));}
  path.reverse(); return path.slice(1);
}

function ghostSetState(next) {
  if(state.ghostState===next) return;
  state.ghostState=next; state.ghostStateTime=0; state.aiPathTimer=0;
  if(next==='chase') { showToast('RUN. THE GHOST HAS FOUND YOU.',1600); soundTone(95,0.55,0.08,'sawtooth'); }
}
function updateGhost(dt) {
  if(!state.ghostActive||!ghost.visible||state.ended) return;
  state.ghostStateTime+=dt; state.aiPathTimer+=dt;
  const ghostPos=ghost.position.clone(); ghostPos.y=1.0;
  const playerPos=player.clone(); playerPos.y=1.5;
  const distance=ghostPos.distanceTo(playerPos);
  const toPlayer=playerPos.clone().sub(ghostPos).normalize();
  const forward=new THREE.Vector3(-Math.sin(yaw),0,-Math.cos(yaw));
  const ghostForward=new THREE.Vector3(-Math.sin(ghost.rotation.y),0,-Math.cos(ghost.rotation.y));
  const ghostView=ghostForward.dot(toPlayer);
  const seesPlayer=!state.hidden && distance<=(settings.difficulty==='easy'?7.2:settings.difficulty==='hard'?11:9) && ghostView>0.05 && lineOfSight(ghostPos.clone().setY(2.5),playerPos.clone().setY(1.3));
  const hearsPlayer=!state.hidden && state.elapsed-state.lastNoiseAt<1.1 && distance<(state.noiseRadius||4.5);
  if(seesPlayer) {state.lastSeenAt=state.elapsed;state.lastKnown.copy(player);}
  if(hearsPlayer && state.elapsed-state.lastNoiseAt<0.2) state.lastKnown.copy(state.lastNoise);

  if(seesPlayer) ghostSetState('chase');
  else if(state.ghostState==='chase' && state.elapsed-state.lastSeenAt>3.5) ghostSetState('search');
  else if(hearsPlayer && state.ghostState!=='chase') ghostSetState('investigate');
  else if(state.ghostState==='search' && state.ghostStateTime>7) ghostSetState('patrol');
  else if(state.ghostState==='investigate' && state.ghostStateTime>5) ghostSetState('patrol');

  let target;
  if(state.ghostState==='chase') target=player.clone();
  else if(state.ghostState==='investigate') target=state.lastNoise.clone();
  else if(state.ghostState==='search') target=state.lastKnown.clone();
  else {
    const patrol=[new THREE.Vector3(0,0,-4),new THREE.Vector3(6,0,-4),new THREE.Vector3(6,0,-12),new THREE.Vector3(-6,0,-12),new THREE.Vector3(-6,0,-4)];
    if(!state.patrolIndex || ghost.position.distanceTo(patrol[state.patrolIndex])<1.0) state.patrolIndex=((state.patrolIndex||0)+1)%patrol.length;
    target=patrol[state.patrolIndex];
  }
  if(state.aiPathTimer>0.85 || !state.ghostPath.length) {
    state.ghostPath=gridPath(ghost.position,target); state.aiPathTimer=0;
  }
  let waypoint=state.ghostPath.length?state.ghostPath[0]:target;
  if(ghost.position.distanceTo(waypoint)<0.55 && state.ghostPath.length) {state.ghostPath.shift();waypoint=state.ghostPath[0]||target;}
  const speedBase=settings.difficulty==='easy'?1.45:settings.difficulty==='hard'?2.3:1.9;
  const speed=state.ghostState==='chase'?speedBase+0.85:state.ghostState==='investigate'?speedBase*0.9:speedBase*0.65;
  const delta=waypoint.clone().sub(ghost.position); delta.y=0;
  if(delta.length()>0.06) {
    delta.normalize(); const nextX=ghost.position.x+delta.x*speed*dt, nextZ=ghost.position.z+delta.z*speed*dt;
    if(!collides(nextX,nextZ,0.35)){ghost.position.x=nextX;ghost.position.z=nextZ;}
    else { state.aiPathTimer=2; }
    ghost.rotation.y=Math.atan2(-delta.x,-delta.z);
  }
  ghost.position.y=Math.sin(state.elapsed*2.3)*0.12;
  ghost.children.forEach((child,i)=>{ if(child.isMesh) child.rotation.z=Math.sin(state.elapsed*1.8+i)*0.025; });
  ghostLight.intensity=0.45+Math.sin(state.elapsed*4)*0.15;
  ui.warning.classList.toggle('hidden',distance>8.5||state.hidden);
  if(distance<1.0 && !state.hidden && state.damageCooldown<=0) {
    state.damageCooldown=1.5; state.health-=0.35; ui.damage.style.background='rgba(135,15,28,.48)';
    setTimeout(()=>ui.damage.style.background='rgba(135,15,28,0)',180);
    soundTone(55,0.35,0.12,'sawtooth');
    if(state.health<=0) finishGame(false);
    else { // A brief supernatural displacement gives the player another chance.
      player.set(0,0,8.2); yaw=0; showToast('The ghost caught you. You stumble back to the entrance.');
    }
  }
}

function updateFlashlight(dt) {
  if(state.flashlight && state.battery>0) {
    state.battery=Math.max(0,state.battery-dt*0.42);
    flashlight.intensity=3.5*(0.94+Math.sin(state.elapsed*1.9)*0.035);
    if(state.battery<=0){state.flashlight=false;flashlight.visible=false;showToast('Flashlight battery depleted.');}
  }
  camera.getWorldDirection(tempForward);
  flashlight.position.copy(camera.position).add(tempForward.clone().multiplyScalar(0.12));
  flashlightTarget.position.copy(camera.position).add(tempForward.clone().multiplyScalar(7));
  updateBattery();
}

function finishGame(won) {
  state.ended=true;state.paused=true;
  ui.endKicker.textContent=won?'CHAPTER COMPLETE':'GAME OVER';
  ui.endTitle.textContent=won?'You escaped.':'The house keeps its secret.';
  ui.endDescription.textContent=won?'The front door opens into the cold night. Behind you, the mansion goes quiet.':'The ghost has caught you. The storm outside continues, and the house remains sealed.';
  ui.end.classList.add('visible');
  if(won) soundTone(660,0.7,0.08,'sine');
}

function applySettings() {
  settings.quality=$('quality-setting').value;
  settings.difficulty=$('difficulty-setting').value;
  settings.sensitivity=Number($('sensitivity-setting').value);
  settings.volume=Number($('volume-setting').value)/100;
  $('sensitivity-label').textContent=`${settings.sensitivity.toFixed(1)}×`;
  $('volume-label').textContent=`${Math.round(settings.volume*100)}%`;
  if(masterGain && audioContext) masterGain.gain.setTargetAtTime(settings.volume,audioContext.currentTime,0.08);
  if(renderer) { renderer.setPixelRatio(Math.min(devicePixelRatio||1,settings.quality==='high'?1.7:1.25)); renderer.setSize(innerWidth,innerHeight,false); renderer.shadowMap.enabled=settings.quality!=='low'; }
  if(flashlight) flashlight.castShadow=settings.quality==='high';
  showToast('Settings updated.');
}

function animate() {
  requestAnimationFrame(animate);
  const dt=Math.min(clock.getDelta()||0,0.05);
  if(state.started&&!state.paused&&!state.ended) {
    state.elapsed+=dt;
    if(state.damageCooldown>0) state.damageCooldown-=dt;
    updatePlayer(dt); updateFlashlight(dt); updateGhost(dt); updateTarget();
    if(state.toastTimer>0){state.toastTimer-=dt*1000;if(state.toastTimer<=0)ui.toast.classList.add('hidden');}
    if(dust) dust.rotation.y=Math.sin(state.elapsed*0.12)*0.025;
  }
  renderer.render(scene,camera);
}

function bindUI() {
  $('start-button').addEventListener('click',startGame);
  $('settings-button').addEventListener('click',()=>{ui.start.classList.remove('visible');ui.settings.classList.add('visible');});
  $('pause-settings-button').addEventListener('click',()=>{ui.pause.classList.remove('visible');ui.settings.classList.add('visible');});
  $('settings-back-button').addEventListener('click',()=>{applySettings();ui.settings.classList.remove('visible');if(state.started){ui.pause.classList.add('visible');state.paused=true;}else ui.start.classList.add('visible');});
  $('resume-button').addEventListener('click',resumeGame);
  $('restart-button').addEventListener('click',()=>{resetGame();state.started=true;state.paused=false;showGameUI();});
  $('main-menu-button').addEventListener('click',()=>{state.started=false;state.paused=true;ui.pause.classList.remove('visible');ui.hud.classList.add('hidden');ui.controls.classList.add('hidden');ui.crosshair.classList.add('hidden');ui.start.classList.add('visible');});
  $('close-note-button').addEventListener('click',()=>{ui.note.classList.remove('visible');state.paused=false;});
  $('close-keypad-button').addEventListener('click',()=>{ui.keypad.classList.remove('visible');state.paused=false;});
  $('keypad-screen').querySelectorAll('[data-digit]').forEach(btn=>btn.addEventListener('click',()=>keypadInput(btn.dataset.digit)));
  $('keypad-screen').querySelectorAll('[data-action]').forEach(btn=>btn.addEventListener('click',()=>keypadInput(btn.dataset.action)));
  $('end-restart-button').addEventListener('click',()=>{ui.end.classList.remove('visible');resetGame();state.started=true;state.paused=false;showGameUI();});
  $('end-menu-button').addEventListener('click',()=>{ui.end.classList.remove('visible');state.started=false;state.paused=true;ui.hud.classList.add('hidden');ui.controls.classList.add('hidden');ui.crosshair.classList.add('hidden');ui.start.classList.add('visible');});
  $('sensitivity-setting').addEventListener('input',()=>{$('sensitivity-label').textContent=`${Number($('sensitivity-setting').value).toFixed(1)}×`;});
  $('volume-setting').addEventListener('input',()=>{$('volume-label').textContent=`${$('volume-setting').value}%`;});
  document.addEventListener('visibilitychange',()=>{if(document.hidden&&state.started&&!state.paused&&!state.ended)pauseGame();});
  window.addEventListener('resize',()=>{if(!renderer)return;camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight,false);});
}

function boot() {
  try {
    createWorld();
    clock=new THREE.Clock(false);
    setupControls(); bindUI();
    updateInventory(); updateBattery();
    renderer.setAnimationLoop(null);
    animate();
  } catch(error) {
    console.error(error);
    const panel=document.createElement('div');panel.style.cssText='position:absolute;inset:0;z-index:200;background:#090c12;color:#fff;padding:24px;font:14px system-ui;overflow:auto';
    panel.innerHTML='<h2>GHOST could not start</h2><p>Check that WebGL is enabled and that the Three.js library loaded successfully.</p><pre style="white-space:pre-wrap;color:#e5b9b9"></pre>';
    panel.querySelector('pre').textContent=error.stack||String(error);document.body.appendChild(panel);
  }
}

boot();
