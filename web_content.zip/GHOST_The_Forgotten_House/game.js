import THREE from './three-loader.js';

// GHOST: The Forgotten House — landscape-first mobile horror prototype.
// All environments and props are generated from Three.js geometry so the
// project runs without downloading model or texture packs.

const $ = (id) => document.getElementById(id);
const canvas = $('game-canvas');
const ui = {
  hud: $('hud'), controls: $('touch-controls'), crosshair: $('crosshair'),
  start: $('start-screen'), pause: $('pause-screen'), settings: $('settings-screen'),
  end: $('end-screen'), objective: $('objective-text'), inventory: $('inventory-items'),
  battery: $('battery-value'), batteryFill: $('battery-fill'), warning: $('ghost-warning'),
  prompt: $('interaction-prompt'), toast: $('toast'), damage: $('damage-flash'),
  note: $('note-screen'), keypad: $('keypad-screen'), keypadDisplay: $('keypad-display'),
  keypadMessage: $('keypad-message'), endKicker: $('end-kicker'), endTitle: $('end-title'),
  endDescription: $('end-description'), map: $('map-screen'), mapCanvas: $('map-canvas'),
  healthFill: $('health-fill'), emfLevel: $('emf-level'), mapStatus: $('map-status')
};

const settings = { quality: 'medium', difficulty: 'normal', sensitivity: 1, volume: 0.6, brightness: 1.38 };
const state = {
  started: false, paused: true, ended: false, hidden: false, crouching: false,
  running: false, flashlight: true, battery: 100, elapsed: 0, ghostActive: false,
  powerOn: false, exitOpen: false, keypadInput: '', toastTimer: 0, warningTimer: 0,
  health: 1, lastNoiseAt: -999, lastNoise: new THREE.Vector3(0, 0, 0),
  inventory: new Set(), noteRead: false, panelUsed: false, ghostState: 'patrol',
  ghostStateTime: 0, lastSeenAt: -999, lastKnown: new THREE.Vector3(0, 0, 0),
  aiPathTimer: 0, ghostPath: [], hideSpot: null, damageCooldown: 0,
  emfOn: false, uvOn: false, lureCharges: 2, lureActiveUntil: 0, mapOpen: false
};

let scene, camera, renderer, clock, flashlight, flashlightTarget, uvLight, uvTarget, ghost, ghostLight, lureBeacon;
let player = new THREE.Vector3(0, 0, 8.2);
let yaw = Math.PI, pitch = 0; // Looking toward the central hallway (-Z).
let joystick = { x: 0, y: 0, pointer: null };
let lookPointer = null, previousLook = null;
let interactables = [], colliders = [], wallMeshes = [], hideSpots = [];
let roomLights = [], dust = null, exitDoor, exitCollider = null, cabinetKey, cabinetRoot = null, cabinetCollider = null, keypadRoot;
let uvClues = [], mapDrawTimer = 0;
let currentTarget = null, audioContext = null, masterGain = null;
const raycaster = new THREE.Raycaster();
const tempForward = new THREE.Vector3();
const tempRight = new THREE.Vector3();
const tempVec = new THREE.Vector3();
const WORLD = { minX: -9.65, maxX: 9.65, minZ: -15.65, maxZ: 15.5 };

// In Android browser previews the page may be locked to portrait. In that
// case CSS rotates the game shell; render using the matching landscape size.
function usesRotatedPortraitLayout() {
  return window.matchMedia('(orientation: portrait) and (max-width: 700px)').matches;
}
function getGameViewport() {
  return usesRotatedPortraitLayout()
    ? { width: Math.max(window.innerWidth, window.innerHeight), height: Math.min(window.innerWidth, window.innerHeight) }
    : { width: window.innerWidth, height: window.innerHeight };
}

function material(color, roughness = 0.9, extra = {}) {
  return new THREE.MeshStandardMaterial({ color, roughness, ...extra });
}
const mats = {
  floor: material(0x3b3c3d), wood: material(0x594938), woodDark: material(0x393027),
  wall: material(0x505154), wallAlt: material(0x464346), trim: material(0x292b2e),
  brass: material(0xb28b4d, 0.38, { metalness: 0.55 }), paper: material(0xcfc4a6),
  glass: new THREE.MeshStandardMaterial({ color: 0x9fc6d5, roughness: 0.18, metalness: 0.15, transparent: true, opacity: 0.38 }),
  ghost: new THREE.MeshStandardMaterial({ color: 0xd9f4f6, roughness: 0.26, metalness: 0.02, transparent: true, opacity: 0.72, emissive: 0x4a9eae, emissiveIntensity: 1.15, side: THREE.DoubleSide }),
  ghostFace: new THREE.MeshBasicMaterial({ color: 0x07121a }),
  eye: new THREE.MeshBasicMaterial({ color: 0xb9ffff }),
  red: material(0x662d33), metal: material(0x55565a, 0.4, { metalness: 0.65 })
};

function addBox(name, x, y, z, w, h, d, mat, { collider = false, parent = scene, cast = true, receive = true } = {}) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
  mesh.name = name;
  mesh.position.set(x, y, z);
  mesh.castShadow = cast;
  mesh.receiveShadow = receive;
  parent.add(mesh);
  if (collider) colliders.push({ x, z, hw: w / 2, hd: d / 2 });
  return mesh;
}

function addWall(x, z, w, d, height = 4.3, mat = mats.wall) {
  const mesh = addBox('wall', x, height / 2, z, w, height, d, mat, { collider: true });
  wallMeshes.push(mesh);
  // A narrow baseboard makes the room edges easier to read in low light.
  addBox('baseboard', x, 0.12, z, w, 0.24, d + 0.025, mats.trim, { cast: false });
  return mesh;
}

function addInteractable(root, action, label, range = 3.2) {
  root.userData.action = action;
  root.userData.label = label;
  root.userData.range = range;
  root.traverse((child) => {
    if (child.isMesh) {
      child.userData.action = action;
      child.userData.label = label;
      child.userData.range = range;
    }
  });
  interactables.push(root);
  return root;
}

function addFurnitureBox(x, y, z, w, h, d, mat, collision = true) {
  return addBox('furniture', x, y, z, w, h, d, mat, { collider: collision });
}

function createRoomDecor() {
  // Entrance hall: rug, console and framed portraits.
  addBox('hall rug', 0, 0.015, 7.5, 5.2, 0.025, 3.5, material(0x33272a));
  addFurnitureBox(0, 0.52, 4.25, 2.8, 1.04, 0.65, mats.woodDark);
  addBox('console top', 0, 1.08, 4.25, 3.0, 0.12, 0.78, mats.wood);
  addBox('portrait frame', -5.5, 2.4, 3.17, 1.15, 1.5, 0.12, mats.brass, false);
  addBox('portrait canvas', -5.5, 2.4, 3.095, 0.98, 1.31, 0.035, material(0x20252b), false);
  addBox('portrait frame', 5.5, 2.4, 3.17, 1.15, 1.5, 0.12, mats.brass, false);
  addBox('portrait canvas', 5.5, 2.4, 3.095, 0.98, 1.31, 0.035, material(0x252127), false);

  // Living room furniture, west side.
  addFurnitureBox(-7.7, 0.55, -1.6, 2.1, 1.1, 1.0, mats.woodDark);
  addFurnitureBox(-5.3, 0.42, -6.1, 2.0, 0.84, 1.0, mats.red);
  addFurnitureBox(-8.8, 0.65, -4.0, 0.75, 1.3, 0.75, mats.wood);
  addBox('shelf', -9.35, 1.45, -2.5, 0.35, 2.7, 2.7, mats.woodDark, { collider: true });
  for (let i = 0; i < 5; i++) addBox('book', -9.12, 0.45 + i * 0.27, -3.4 + (i % 2) * 0.18, 0.12, 0.2, 0.32, material([0x52343a,0x31404a,0x756044,0x343b31,0x594a60][i]), { cast: false });

  // Library, east side.
  addFurnitureBox(8.8, 1.35, -3.8, 0.45, 2.7, 6.6, mats.woodDark);
  addFurnitureBox(5.2, 0.55, -1.5, 2.1, 1.1, 1.0, mats.wood);
  addBox('library table top', 5.2, 1.12, -1.5, 2.4, 0.12, 1.2, mats.woodDark);
  for (let i = 0; i < 7; i++) addBox('book', 8.53, 0.58 + (i % 3) * 0.32, -6.3 + i * 0.65, 0.12, 0.25, 0.5, material([0x55403a,0x2c4148,0x66563d,0x354034][i % 4]), { cast: false });

  // Bedroom, west rear.
  addFurnitureBox(-6.4, 0.42, -10.0, 3.2, 0.84, 4.0, mats.woodDark);
  addBox('mattress', -6.4, 0.92, -10.0, 3.0, 0.3, 3.7, material(0x5c5250));
  addBox('pillow', -6.4, 1.14, -11.35, 1.2, 0.18, 0.75, material(0xb2aaa0));
  addFurnitureBox(-9.0, 0.55, -14.9, 0.65, 1.1, 0.75, mats.wood);

  // Basement, east rear.
  addFurnitureBox(8.5, 0.75, -14.2, 1.0, 1.5, 1.0, mats.metal);
  addBox('pipe', 3.0, 3.5, -13.6, 0.18, 0.18, 5.0, mats.metal, { collider: false });
  addBox('pipe', 3.0, 3.1, -10.9, 0.18, 0.18, 0.18, mats.metal, { collider: false });

  // Lamps and lights create distinct room silhouettes.
  const lampSpecs = [
    [-6.7, 2.5, -3.7, 0xb58e61], [6.5, 2.5, -3.7, 0x8f9caf],
    [-6.5, 2.5, -12.0, 0xb58e61], [6.5, 2.5, -12.0, 0x9daab5],
    [0, 3.2, 7.0, 0x9e8d72]
  ];
  for (const [x,y,z,color] of lampSpecs) {
    const bulb = new THREE.PointLight(color, 1.05, 11, 1.8);
    bulb.position.set(x, y, z); scene.add(bulb); roomLights.push(bulb);
    const shade = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.34, 0.35, 10), mats.woodDark);
    shade.position.set(x, y + 0.15, z); scene.add(shade);
  }
}

function createPlayingAreaDetails() {
  // A warm chandelier gives the entrance hall a readable landmark.
  const chandelier = new THREE.Group();
  chandelier.position.set(0, 3.55, 7.0);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(0.82, 0.055, 8, 28), mats.brass);
  ring.rotation.x = Math.PI / 2;
  chandelier.add(ring);
  const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.065, 0.65, 10), mats.brass);
  stem.position.y = 0.43;
  chandelier.add(stem);
  for (let i = 0; i < 6; i++) {
    const a = i * Math.PI / 3;
    const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.105, 10, 8), new THREE.MeshBasicMaterial({ color: 0xffd991 }));
    bulb.position.set(Math.cos(a) * 0.73, -0.16, Math.sin(a) * 0.73);
    chandelier.add(bulb);
    const light = new THREE.PointLight(0xffcf8a, 0.24, 3.2, 2);
    light.position.copy(bulb.position);
    chandelier.add(light);
  }
  scene.add(chandelier);

  // Tall frosted windows help players read the room silhouettes.
  for (const side of [-1, 1]) {
    for (const z of [-4.4, -10.4]) {
      const frame = new THREE.Group();
      frame.position.set(side * 9.76, 2.35, z);
      frame.rotation.y = side < 0 ? Math.PI / 2 : -Math.PI / 2;
      const glassMat = new THREE.MeshStandardMaterial({ color: 0x8eb6c9, emissive: 0x345466, emissiveIntensity: 0.38, transparent: true, opacity: 0.68, roughness: 0.2 });
      const pane = new THREE.Mesh(new THREE.BoxGeometry(1.55, 2.0, 0.055), glassMat);
      frame.add(pane);
      for (const x of [-0.84, 0.84]) {
        const bar = new THREE.Mesh(new THREE.BoxGeometry(0.10, 2.25, 0.12), mats.woodDark);
        bar.position.x = x; frame.add(bar);
      }
      for (const y of [-1.12, 1.12]) {
        const bar = new THREE.Mesh(new THREE.BoxGeometry(1.78, 0.10, 0.12), mats.woodDark);
        bar.position.y = y; frame.add(bar);
      }
      const crossbar = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.07, 0.10), mats.woodDark);
      frame.add(crossbar);
      scene.add(frame);
    }
  }

  // Small wall sconces make the corridor and rear rooms easier to navigate.
  const sconceSpecs = [[-1.85, 2.55, 1.1], [1.85, 2.55, 1.1], [-1.85, 2.55, -7.0], [1.85, 2.55, -7.0], [-1.85, 2.55, -13.9], [1.85, 2.55, -13.9]];
  for (const [x, y, z] of sconceSpecs) {
    const lamp = new THREE.PointLight(0xffd9a2, 0.55, 5.2, 1.8);
    lamp.position.set(x * 1.4, y, z); scene.add(lamp); roomLights.push(lamp);
    const shade = new THREE.Mesh(new THREE.SphereGeometry(0.12, 10, 8), new THREE.MeshBasicMaterial({ color: 0xffd9a2 }));
    shade.position.copy(lamp.position); scene.add(shade);
  }
}

function createUVClues() {
  const specs = [[-9.72, 2.0, -5.0, Math.PI / 2], [9.72, 2.0, -10.0, -Math.PI / 2], [0.0, 2.25, -15.72, 0]];
  for (const [x, y, z, rotationY] of specs) {
    const mark = new THREE.Group();
    mark.position.set(x, y, z); mark.rotation.y = rotationY;
    const runeMat = new THREE.MeshBasicMaterial({ color: 0x9c80ff, transparent: true, opacity: 0.94 });
    const outer = new THREE.Mesh(new THREE.TorusGeometry(0.24, 0.035, 7, 22), runeMat);
    mark.add(outer);
    const slash = new THREE.Mesh(new THREE.BoxGeometry(0.055, 0.58, 0.035), runeMat);
    slash.rotation.z = 0.45; mark.add(slash);
    const dot = new THREE.Mesh(new THREE.SphereGeometry(0.065, 8, 8), runeMat);
    dot.position.y = 0.37; mark.add(dot);
    mark.visible = false; scene.add(mark); uvClues.push(mark);
  }
}

function createWorld() {
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x394957);
  // Keep a little atmospheric depth, but avoid the nearly opaque darkness
  // that made rooms hard to read on mobile displays.
  scene.fog = new THREE.FogExp2(0x314653, 0.0085);
  const viewport = getGameViewport();
  camera = new THREE.PerspectiveCamera(74, viewport.width / viewport.height, 0.08, 75);
  camera.rotation.order = 'YXZ';
  camera.position.set(player.x, 1.62, player.z);
  try {
    renderer = new THREE.WebGLRenderer({ canvas, antialias: settings.quality !== 'low', powerPreference: 'high-performance', failIfMajorPerformanceCaveat: false });
  } catch (firstError) {
    // A non-antialiased, low-power renderer is more compatible with older phones.
    try { renderer = new THREE.WebGLRenderer({ canvas, antialias: false, powerPreference: 'low-power', failIfMajorPerformanceCaveat: false }); }
    catch (secondError) { throw new Error('WebGL is unavailable on this device or browser.'); }
  }
  renderer.setPixelRatio(Math.min(devicePixelRatio || 1, settings.quality === 'high' ? 1.5 : 1.1));
  renderer.setSize(viewport.width, viewport.height, false);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = settings.brightness;
  renderer.shadowMap.enabled = settings.quality !== 'low';
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;

  scene.add(new THREE.HemisphereLight(0xc6d8e8, 0x514b43, 0.95));
  scene.add(new THREE.AmbientLight(0xa9b8c5, 0.38));
  const moon = new THREE.DirectionalLight(0xb8cde0, 0.92);
  moon.position.set(-7, 12, 8); moon.castShadow = settings.quality === 'high';
  moon.shadow.mapSize.set(768, 768); scene.add(moon);

  // Continuous floor with dark wood strips.
  addBox('floor', 0, -0.18, -2, 20, 0.36, 28, mats.floor, { cast: false });
  for (let z = -15; z <= 10; z += 2) {
    addBox('floor plank seam', 0, 0.006, z, 19.7, 0.008, 0.025, material(0x171a1d), { cast: false });
  }
  addBox('ceiling', 0, 4.5, -2, 20, 0.25, 28, material(0x202327), { cast: false });
  addBox('exit porch', 0, -0.12, 13.3, 4.4, 0.18, 3.0, material(0x343a40), { cast: false });

  // Outer walls, leaving a two-metre gap for the front exit door.
  addWall(-10, -2, 0.4, 28.4, 4.5);
  addWall(10, -2, 0.4, 28.4, 4.5);
  addWall(0, -16, 20.4, 0.4, 4.5);
  addWall(-5.55, 12, 8.9, 0.4, 4.5);
  addWall(5.55, 12, 8.9, 0.4, 4.5);

  // Corridor side walls. Openings at z=-4 and z=-12 lead into four rooms.
  for (const x of [-2.15, 2.15]) {
    addWall(x, -14.55, 0.32, 2.9);
    addWall(x, -8.95, 0.32, 5.7);
    addWall(x, -1.4, 0.32, 2.8);
  }
  // Entrance hall feeds into the central corridor.
  addWall(-6.05, 3, 7.9, 0.32);
  addWall(6.05, 3, 7.9, 0.32);
  // Separate front/rear wings with door-sized openings.
  addWall(-6, -8, 8.0, 0.32);
  addWall(6, -8, 8.0, 0.32);
  // Door jambs make all room openings legible.
  for (const x of [-2.15, 2.15]) for (const z of [-4, -12]) {
    addBox('door jamb', x, 2.05, z - 1.1, 0.34, 4.1, 0.18, mats.woodDark, { collider: true });
    addBox('door jamb', x, 2.05, z + 1.1, 0.34, 4.1, 0.18, mats.woodDark, { collider: true });
  }

  // Exit door is a pivoted slab; its collider is removed after unlocking.
  exitDoor = new THREE.Group();
  exitDoor.position.set(-1.05, 0, 11.78);
  const doorSlab = new THREE.Mesh(new THREE.BoxGeometry(2.1, 3.6, 0.22), mats.woodDark);
  doorSlab.position.set(1.05, 1.8, 0); doorSlab.castShadow = true; exitDoor.add(doorSlab);
  const doorPanel = new THREE.Mesh(new THREE.BoxGeometry(1.65, 2.9, 0.05), mats.wood);
  doorPanel.position.set(1.05, 1.8, -0.13); exitDoor.add(doorPanel);
  const knob = new THREE.Mesh(new THREE.SphereGeometry(0.09, 10, 8), mats.brass);
  knob.position.set(0.3, 1.65, -0.24); exitDoor.add(knob);
  scene.add(exitDoor);
  exitCollider = { x: 0, z: 11.78, hw: 1.06, hd: 0.22, exit: true };
  colliders.push(exitCollider);
  addInteractable(exitDoor, 'exit', 'LOCKED EXIT', 3.4);

  createRoomDecor();
  createPlayingAreaDetails();
  createPickupsAndPuzzles();
  createGhost();
  createUVClues();
  createDust();
  createFlashlight();
  createEquipmentLights();
}

function createPickupMesh(kind, x, y, z) {
  const group = new THREE.Group(); group.position.set(x, y, z); scene.add(group);
  if (kind === 'key') {
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.19, 0.045, 8, 18), mats.brass);
    ring.rotation.x = Math.PI / 2; group.add(ring);
    const shaft = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.42, 0.07), mats.brass); shaft.position.y = -0.25; group.add(shaft);
    const tooth = new THREE.Mesh(new THREE.BoxGeometry(0.19, 0.09, 0.07), mats.brass); tooth.position.set(0.07, -0.42, 0); group.add(tooth);
  } else if (kind === 'fuse') {
    const body = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.11, 0.5, 12), material(0xc6b9a2, 0.35, { metalness: 0.25 }));
    body.rotation.z = Math.PI / 2; group.add(body);
    for (const dx of [-0.28, 0.28]) { const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.13,0.13,0.08,10), mats.brass); cap.rotation.z = Math.PI/2; cap.position.x = dx; group.add(cap); }
  } else if (kind === 'note') {
    const paper = new THREE.Mesh(new THREE.BoxGeometry(0.58, 0.045, 0.42), mats.paper); paper.rotation.y = -0.15; group.add(paper);
    for (let i=0;i<3;i++) addBox('note ink', x, y + 0.026, z - 0.12 + i*0.1, 0.35, 0.008, 0.012, mats.woodDark, { cast:false });
  } else if (kind === 'exitKey') {
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.16, 0.04, 8, 16), mats.brass); ring.rotation.x = Math.PI/2; group.add(ring);
    const shaft = new THREE.Mesh(new THREE.BoxGeometry(0.07,0.45,0.07), mats.brass); shaft.position.y=-0.22; group.add(shaft);
  }
  group.traverse(o => { if (o.isMesh) { o.castShadow = true; o.userData.action = kind; } });
  return group;
}

function createPickupsAndPuzzles() {
  const key = createPickupMesh('key', -6.8, 1.18, -4.25);
  addInteractable(key, 'brassKey', 'PICK UP BRASS KEY', 3.3);
  const fuse = createPickupMesh('fuse', -6.8, 1.2, -12.0);
  addInteractable(fuse, 'fuse', 'PICK UP FUSE', 3.3);
  const note = createPickupMesh('note', 6.0, 1.2, -1.5);
  addInteractable(note, 'note', 'READ THE NOTE', 3.3);

  // Hiding wardrobes (the player can use either one).
  const wardrobeA = new THREE.Group(); wardrobeA.position.set(-8.4, 0, -6.0); wardrobeA.rotation.y=-Math.PI/2; scene.add(wardrobeA);
  const bodyA = new THREE.Mesh(new THREE.BoxGeometry(1.25,2.8,0.85), mats.woodDark); bodyA.position.y=1.4; wardrobeA.add(bodyA);
  const seamA = new THREE.Mesh(new THREE.BoxGeometry(0.035,2.4,0.025), mats.brass); seamA.position.set(0,1.4,-0.44); wardrobeA.add(seamA);
  addInteractable(wardrobeA, 'hide', 'HIDE IN WARDROBE', 2.7);
  hideSpots.push({ position: new THREE.Vector3(-8.4,0,-6.0), group: wardrobeA });
  const wardrobeB = new THREE.Group(); wardrobeB.position.set(-8.8, 0, -14.5); wardrobeB.rotation.y=-Math.PI/2; scene.add(wardrobeB);
  const bodyB = new THREE.Mesh(new THREE.BoxGeometry(1.25,2.8,0.85), mats.woodDark); bodyB.position.y=1.4; wardrobeB.add(bodyB);
  const seamB = new THREE.Mesh(new THREE.BoxGeometry(0.035,2.4,0.025), mats.brass); seamB.position.set(0,1.4,-0.44); wardrobeB.add(seamB);
  addInteractable(wardrobeB, 'hide', 'HIDE IN WARDROBE', 2.7);
  hideSpots.push({ position: new THREE.Vector3(-8.8,0,-14.5), group: wardrobeB });
  colliders.push({ x:-8.4,z:-6,hw:0.65,hd:0.45 }, { x:-8.8,z:-14.5,hw:0.65,hd:0.45 });

  // Power keypad in the basement.
  keypadRoot = new THREE.Group(); keypadRoot.position.set(7.6, 1.55, -12.6); keypadRoot.rotation.y=Math.PI/2; scene.add(keypadRoot);
  const panel = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.9, 0.16), mats.metal); keypadRoot.add(panel);
  const screen = new THREE.Mesh(new THREE.BoxGeometry(0.62,0.2,0.025), material(0x18312f,0.3, { emissive:0x1a6859, emissiveIntensity:0.45 })); screen.position.set(0,0.22,-0.1); keypadRoot.add(screen);
  for (let i=0;i<9;i++) {
    const keyBtn = new THREE.Mesh(new THREE.BoxGeometry(0.13,0.09,0.035), mats.brass);
    keyBtn.position.set(-0.22+(i%3)*0.22,-0.03-Math.floor(i/3)*0.16,-0.11); keypadRoot.add(keyBtn);
  }
  addInteractable(keypadRoot, 'keypad', 'USE POWER KEYPAD', 3.4);

  // Cabinet holding the exit key; it becomes interactable when power is restored.
  const cabinet = new THREE.Group(); cabinet.position.set(4.3,0,-14.4); cabinet.rotation.y=Math.PI/2; scene.add(cabinet);
  const cabBody = new THREE.Mesh(new THREE.BoxGeometry(1.5,1.8,0.85), mats.woodDark); cabBody.position.y=0.9; cabinet.add(cabBody);
  const cabDoor = new THREE.Mesh(new THREE.BoxGeometry(1.25,1.55,0.08), mats.wood); cabDoor.position.set(0,0.9,-0.46); cabinet.add(cabDoor);
  const cabKnob = new THREE.Mesh(new THREE.SphereGeometry(0.07,10,8), mats.brass); cabKnob.position.set(0.43,0.9,-0.54); cabinet.add(cabKnob);
  cabinetKey = createPickupMesh('exitKey', 4.3, 1.18, -14.4);
  cabinetKey.visible = false;
  addInteractable(cabinet, 'cabinet', 'OPEN KEY CABINET', 3.4);
  cabinet.userData.exitKey = cabinetKey;
  cabinetRoot = cabinet;
  cabinetCollider = { x:4.3,z:-14.4,hw:0.45,hd:0.78 };
  colliders.push(cabinetCollider);
}

function createGhost() {
  ghost = new THREE.Group();
  ghost.position.set(6, 0, -13);
  scene.add(ghost);

  // Floating, hooded wraith with a layered robe and a visible shadow-face.
  const robe = new THREE.Mesh(new THREE.CylinderGeometry(0.48, 0.78, 2.18, 20, 1, true), mats.ghost);
  robe.position.y = 1.18; robe.rotation.z = 0.02; ghost.add(robe);
  const lowerRobe = new THREE.Mesh(new THREE.ConeGeometry(0.78, 0.75, 20, 1, true), mats.ghost);
  lowerRobe.position.y = 0.45; lowerRobe.rotation.x = Math.PI; ghost.add(lowerRobe);
  const shoulder = new THREE.Mesh(new THREE.SphereGeometry(0.57, 18, 12), mats.ghost);
  shoulder.scale.set(1.12, 0.62, 0.7); shoulder.position.y = 2.14; ghost.add(shoulder);

  const hood = new THREE.Mesh(new THREE.SphereGeometry(0.47, 20, 16), mats.ghost);
  hood.scale.set(0.94, 1.12, 0.86); hood.position.set(0, 2.72, 0.0); ghost.add(hood);
  const face = new THREE.Mesh(new THREE.SphereGeometry(0.335, 18, 14), mats.ghostFace);
  face.scale.set(0.9, 1.05, 0.28); face.position.set(0, 2.67, -0.365); ghost.add(face);

  const eyeMat = new THREE.MeshBasicMaterial({ color: 0xbaffff });
  const eyeGlowMat = new THREE.MeshBasicMaterial({ color: 0x63e9ff });
  for (const side of [-1, 1]) {
    const eye = new THREE.Mesh(new THREE.SphereGeometry(0.066, 10, 8), eyeMat);
    eye.position.set(side * 0.135, 2.76, -0.456); ghost.add(eye);
    const glow = new THREE.PointLight(0x65eaff, 0.16, 1.7, 2);
    glow.position.copy(eye.position); ghost.add(glow);
    const arm = new THREE.Mesh(new THREE.CapsuleGeometry(0.13, 0.78, 4, 8), mats.ghost);
    arm.position.set(side * 0.57, 1.66, -0.02); arm.rotation.z = side * -0.42; arm.rotation.x = -0.15; ghost.add(arm);
    const hand = new THREE.Mesh(new THREE.SphereGeometry(0.15, 10, 8), mats.ghost);
    hand.position.set(side * 0.79, 1.16, -0.04); ghost.add(hand);
  }

  const shroud = new THREE.Mesh(new THREE.TorusGeometry(0.72, 0.045, 8, 28), new THREE.MeshBasicMaterial({ color: 0x7aeaff, transparent: true, opacity: 0.42 }));
  shroud.rotation.x = Math.PI / 2; shroud.position.y = 0.14; ghost.add(shroud);
  const aura = new THREE.PointLight(0x8feeff, 1.0, 5.8, 2); aura.position.set(0, 2.0, 0); ghost.add(aura); ghostLight = aura;
  ghost.userData.shroud = shroud;
  ghost.userData.baseY = 0;
  ghost.visible = false;
}

function createDust() {
  const count = settings.quality === 'low' ? 120 : 280;
  const positions = new Float32Array(count*3);
  for (let i=0;i<count;i++) {
    positions[i*3] = -9.3 + Math.random()*18.6;
    positions[i*3+1] = 0.4 + Math.random()*3.3;
    positions[i*3+2] = -15.3 + Math.random()*26.5;
  }
  const geo = new THREE.BufferGeometry(); geo.setAttribute('position',new THREE.BufferAttribute(positions,3));
  const points = new THREE.Points(geo,new THREE.PointsMaterial({color:0xb8b9b5,size:0.025,transparent:true,opacity:0.42,depthWrite:false}));
  scene.add(points); dust=points;
}

function createFlashlight() {
  flashlight = new THREE.SpotLight(0xe8f2ff, 5.8, 25, Math.PI/6.2, 0.42, 1.25);
  flashlight.position.copy(camera.position); flashlight.castShadow = settings.quality === 'high';
  flashlight.target.position.set(0,1.4,0); scene.add(flashlight,flashlight.target);
  flashlightTarget = flashlight.target;
}

function createEquipmentLights() {
  uvLight = new THREE.SpotLight(0x9d82ff, 0, 16, Math.PI / 5, 0.55, 1.3);
  uvLight.position.copy(camera.position); uvLight.visible = false;
  uvTarget = new THREE.Object3D(); uvTarget.position.set(0, 1, -5);
  scene.add(uvLight, uvTarget); uvLight.target = uvTarget;

  lureBeacon = new THREE.Group();
  const orb = new THREE.Mesh(new THREE.SphereGeometry(0.18, 12, 10), new THREE.MeshBasicMaterial({ color: 0xffc86c }));
  lureBeacon.add(orb);
  const glow = new THREE.PointLight(0xffa64b, 1.5, 6, 2);
  glow.position.y = 0.25; lureBeacon.add(glow);
  lureBeacon.visible = false; scene.add(lureBeacon);
}

function setObjective(text) { ui.objective.textContent = text; }
function showToast(text, duration = 2300) {
  ui.toast.textContent = text; ui.toast.classList.remove('hidden'); state.toastTimer = duration;
}
function updateInventory() {
  ui.inventory.innerHTML = '';
  const labels = { brassKey:'BRASS KEY', fuse:'FUSE', exitKey:'EXIT KEY' };
  if (!state.inventory.size) { ui.inventory.innerHTML = '<span class="inventory-empty">Empty</span>'; return; }
  for (const item of state.inventory) {
    const chip = document.createElement('span'); chip.className = 'inventory-chip'; chip.textContent = labels[item] || item.toUpperCase(); ui.inventory.appendChild(chip);
  }
}
function hasItem(item) { return state.inventory.has(item); }
function removeCollider(tag) { colliders = colliders.filter(c => c !== tag); }

function beginAudio() {
  try {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return;
    if (!audioContext) {
      audioContext = new AudioCtx(); masterGain = audioContext.createGain(); masterGain.gain.value = settings.volume; masterGain.connect(audioContext.destination);
      const osc = audioContext.createOscillator(); const gain = audioContext.createGain();
      osc.type='sine'; osc.frequency.value=48; gain.gain.value=0.018; osc.connect(gain); gain.connect(masterGain); osc.start();
      const lfo = audioContext.createOscillator(); const lfoGain = audioContext.createGain(); lfo.frequency.value=0.12; lfoGain.gain.value=4; lfo.connect(lfoGain); lfoGain.connect(osc.frequency); lfo.start();
    }
    audioContext.resume();
  } catch (e) { /* Audio is optional on browsers with restricted autoplay. */ }
}
function soundTone(freq=440,duration=0.12,volume=0.08,type='sine') {
  if (!audioContext || !masterGain || settings.volume<=0) return;
  const osc=audioContext.createOscillator(), gain=audioContext.createGain();
  osc.type=type; osc.frequency.value=freq; gain.gain.setValueAtTime(volume,audioContext.currentTime); gain.gain.exponentialRampToValueAtTime(0.001,audioContext.currentTime+duration);
  osc.connect(gain); gain.connect(masterGain); osc.start(); osc.stop(audioContext.currentTime+duration);
}

async function requestLandscape() {
  // Orientation locking is only allowed by some Android browsers after a
  // user gesture and after fullscreen has been requested. Try that sequence.
  try {
    if (!document.fullscreenElement && document.documentElement.requestFullscreen) {
      await document.documentElement.requestFullscreen({ navigationUI: 'hide' });
    }
  } catch (error) {
    // Spck previews and some embedded browsers do not grant fullscreen.
  }
  try {
    if (screen.orientation && typeof screen.orientation.lock === 'function') {
      await screen.orientation.lock('landscape');
    }
  } catch (error) {
    // The CSS landscape fallback below keeps the game usable in portrait-locked previews.
  }
}

function startGame() {
  requestLandscape(); beginAudio();
  resetGame(); state.started=true; state.paused=false; state.ended=false;
  showGameUI();
  showToast('Find the brass key in the living room.');
  clock.start();
}
function showGameUI() {
  ui.start.classList.remove('visible'); ui.pause.classList.remove('visible'); ui.settings.classList.remove('visible'); ui.end.classList.remove('visible');
  ui.hud.classList.remove('hidden'); ui.controls.classList.remove('hidden'); ui.crosshair.classList.remove('hidden');
}
function pauseGame() {
  if (!state.started || state.ended) return;
  state.paused=true; ui.pause.classList.add('visible');
}
function resumeGame() {
  state.paused=false; ui.pause.classList.remove('visible'); beginAudio();
}
function resetGame() {
  state.hidden=false; state.crouching=false; state.running=false; state.flashlight=true; state.battery=100;
  state.elapsed=0; state.ghostActive=false; state.powerOn=false; state.exitOpen=false; state.keypadInput='';
  state.health=1; state.inventory.clear(); state.noteRead=false; state.panelUsed=false; state.ghostState='patrol';
  state.ghostStateTime=0; state.lastSeenAt=-999; state.lastNoiseAt=-999; state.lastNoise.set(0,0,0);
  state.aiPathTimer=0; state.ghostPath=[]; state.hideSpot=null; state.damageCooldown=0; state.patrolIndex=0; state.noiseRadius=4.5;
  state.emfOn=false; state.uvOn=false; state.lureCharges=2; state.lureActiveUntil=0; state.mapOpen=false;
  player.set(0,0,8.2); yaw=0; pitch=0;
  for (const root of interactables) {
    if (!root) continue;
    const action = root.userData.action;
    if (action==='brassKey' || action==='fuse' || action==='note') root.visible=true;
  }
  cabinetKey.visible=false;
  exitDoor.rotation.y=0;
  if (exitCollider) exitCollider.hw=1.06;
  ghost.position.set(6,0,-13); ghost.visible=false; state.patrolIndex=0;
  if (ghostLight) ghostLight.intensity=0.6;
  if (cabinetRoot) {
    cabinetRoot.visible=true;
    if (cabinetRoot.children[1]) { cabinetRoot.children[1].rotation.y=0; cabinetRoot.children[1].position.set(0,0.9,-0.46); }
  }
  if (cabinetCollider && !colliders.includes(cabinetCollider)) colliders.push(cabinetCollider);
  if (exitCollider && !colliders.includes(exitCollider)) colliders.push(exitCollider);
  if (flashlight) flashlight.visible=true;
  if (uvLight) uvLight.visible=false;
  if (lureBeacon) lureBeacon.visible=false;
  for (const clue of uvClues) clue.visible=false;
  ui.map.classList.add('hidden'); ui.map.classList.remove('visible');
  updateInventory(); updateBattery(); updateHealth(); updateToolUI(); setObjective('Find the brass key in the living room.');
  ui.warning.classList.add('hidden'); ui.prompt.classList.add('hidden');
  ui.damage.style.background='rgba(135,15,28,0)';
}

function updateBattery() {
  ui.battery.textContent = `${Math.ceil(state.battery)}%`;
  ui.batteryFill.style.width = `${state.battery}%`;
  ui.batteryFill.style.background = state.battery < 20 ? '#b75d63' : '#d5b87a';
}
function updateHealth() {
  if (ui.healthFill) ui.healthFill.style.width = `${Math.max(0, state.health) * 100}%`;
  if (ui.healthFill) ui.healthFill.style.background = state.health < 0.35 ? '#e36d76' : '#79c99c';
}
function updateToolUI() {
  $('emf-button').classList.toggle('active', state.emfOn);
  $('uv-button').classList.toggle('active', state.uvOn);
  $('lure-count').textContent = `${state.lureCharges} LEFT`;
}
function toggleEMF() {
  state.emfOn = !state.emfOn;
  updateToolUI();
  showToast(state.emfOn ? 'EMF detector active. Watch the signal level.' : 'EMF detector switched off.');
  soundTone(state.emfOn ? 720 : 360, 0.07, 0.035);
}
function toggleUV() {
  if (!state.uvOn && state.battery <= 0) { showToast('The UV scanner battery is empty.'); return; }
  state.uvOn = !state.uvOn;
  if (uvLight) uvLight.visible = state.uvOn && state.battery > 0;
  for (const clue of uvClues) clue.visible = state.uvOn;
  updateToolUI();
  showToast(state.uvOn ? 'UV scanner active. Hidden marks are now visible.' : 'UV scanner switched off.');
  soundTone(state.uvOn ? 520 : 260, 0.08, 0.03);
}
function useSoundLure() {
  if (!state.started || state.paused || state.ended) return;
  if (state.lureCharges <= 0) { showToast('No sound lures remain.'); return; }
  camera.getWorldDirection(tempForward);
  const lurePosition = player.clone().add(tempForward.clone().multiplyScalar(5.0));
  lurePosition.x = THREE.MathUtils.clamp(lurePosition.x, WORLD.minX + 0.8, WORLD.maxX - 0.8);
  lurePosition.z = THREE.MathUtils.clamp(lurePosition.z, WORLD.minZ + 0.8, WORLD.maxZ - 0.8);
  if (collides(lurePosition.x, lurePosition.z, 0.25)) {
    lurePosition.copy(player).add(tempForward.clone().multiplyScalar(2.2));
  }
  lureBeacon.position.set(lurePosition.x, 0.65, lurePosition.z);
  lureBeacon.visible = true;
  state.lureActiveUntil = state.elapsed + 9;
  state.lureCharges -= 1;
  notifyNoise(lurePosition, 18);
  updateToolUI();
  showToast('Sound lure deployed. The ghost may investigate it.');
  soundTone(980, 0.18, 0.07, 'triangle');
}

function updateEquipment(dt) {
  camera.getWorldDirection(tempForward);
  if (uvLight) {
    uvLight.position.copy(camera.position).add(tempForward.clone().multiplyScalar(0.18));
    uvTarget.position.copy(camera.position).add(tempForward.clone().multiplyScalar(7));
    uvLight.visible = state.uvOn && state.battery > 0;
  }
  if (state.uvOn && state.battery > 0) {
    state.battery = Math.max(0, state.battery - dt * 0.22);
    if (state.battery <= 0) {
      state.uvOn = false; if (uvLight) uvLight.visible = false;
      for (const clue of uvClues) clue.visible = false;
      showToast('The UV scanner battery is empty.'); updateToolUI();
    }
  }
  if (lureBeacon && state.elapsed > state.lureActiveUntil) lureBeacon.visible = false;
  if (state.emfOn) {
    const distance = state.ghostActive && ghost ? player.distanceTo(ghost.position) : 20;
    const signal = state.ghostActive ? Math.round(THREE.MathUtils.clamp((12 - distance) / 12, 0, 1) * 100) : 0;
    ui.emfLevel.textContent = `${signal}%`;
    ui.emfLevel.style.color = signal > 65 ? '#ff8790' : signal > 25 ? '#f4d17d' : '#a9bac8';
  } else {
    ui.emfLevel.textContent = 'OFF';
    ui.emfLevel.style.color = '#a9bac8';
  }
}

function openMap() {
  if (!state.started || state.ended || state.paused) return;
  state.paused = true; state.mapOpen = true;
  ui.map.classList.remove('hidden'); ui.map.classList.add('visible');
  drawMap();
}
function closeMap() {
  if (!state.mapOpen) return;
  state.mapOpen = false; ui.map.classList.remove('visible'); ui.map.classList.add('hidden');
  if (!state.ended) state.paused = false;
}
function drawMap() {
  const canvas = ui.mapCanvas;
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const w = canvas.width, h = canvas.height;
  const px = x => ((x - WORLD.minX) / (WORLD.maxX - WORLD.minX)) * (w - 34) + 17;
  const py = z => ((z - WORLD.minZ) / (WORLD.maxZ - WORLD.minZ)) * (h - 28) + 14;
  const rect = (x, z, rw, rd, color) => {
    ctx.fillStyle = color;
    ctx.fillRect(px(x), py(z), px(x + rw) - px(x), py(z + rd) - py(z));
  };
  ctx.clearRect(0, 0, w, h);
  ctx.fillStyle = '#14212d'; ctx.fillRect(0, 0, w, h);
  rect(-9.6, -15.6, 19.2, 27.3, '#53606a');
  rect(-2.0, -15.6, 4.0, 27.3, '#8a8b80');
  rect(-9.6, 3.2, 19.2, 8.5, '#8c806c');
  rect(-9.6, -7.8, 7.4, 10.8, '#77706a');
  rect(2.2, -7.8, 7.4, 10.8, '#6c7378');
  rect(-9.6, -15.6, 7.4, 7.4, '#666d65');
  rect(2.2, -15.6, 7.4, 7.4, '#626c75');
  // Room dividers and outer boundary.
  ctx.strokeStyle = '#d4c8a8'; ctx.lineWidth = 4;
  ctx.strokeRect(px(-9.6), py(-15.6), px(9.6)-px(-9.6), py(11.7)-py(-15.6));
  ctx.lineWidth = 2; ctx.strokeStyle = 'rgba(21,28,34,.9)';
  ctx.beginPath(); ctx.moveTo(px(-2.15), py(-15)); ctx.lineTo(px(-2.15), py(2)); ctx.moveTo(px(2.15), py(-15)); ctx.lineTo(px(2.15), py(2));
  ctx.moveTo(px(-9.3), py(-8)); ctx.lineTo(px(-2.2), py(-8)); ctx.moveTo(px(2.2), py(-8)); ctx.lineTo(px(9.3), py(-8)); ctx.stroke();
  ctx.fillStyle = '#f3e4c4'; ctx.textAlign = 'center'; ctx.font = 'bold 13px system-ui';
  ctx.fillText('BEDROOM', px(-6), py(-12.0)); ctx.fillText('BASEMENT', px(6), py(-12.0));
  ctx.fillText('LIVING', px(-6), py(-3.1)); ctx.fillText('LIBRARY', px(6), py(-3.1));
  ctx.fillText('ENTRANCE HALL', px(0), py(7.2)); ctx.font = '10px system-ui'; ctx.fillStyle = '#e1d4b7'; ctx.fillText('CORRIDOR', px(0), py(-1.5));
  // Objective markers.
  const marker = (x,z,color,label) => { ctx.fillStyle=color; ctx.beginPath(); ctx.arc(px(x),py(z),6,0,Math.PI*2); ctx.fill(); ctx.fillStyle='#fff'; ctx.font='10px system-ui'; ctx.fillText(label,px(x),py(z)-11); };
  if (!hasItem('brassKey')) marker(-6.8,-4.25,'#e8c16e','KEY');
  if (!hasItem('fuse') && !state.powerOn) marker(-6.8,-12,'#83d5ff','FUSE');
  if (!state.noteRead) marker(6,-1.5,'#f4e5b5','NOTE');
  if (state.powerOn && !hasItem('exitKey')) marker(4.3,-14.4,'#e8c16e','EXIT KEY');
  const ghostInEMFRange = state.ghostActive && ghost && ghost.visible && state.emfOn && player.distanceTo(ghost.position) < 12;
  if (ghostInEMFRange) marker(ghost.position.x,ghost.position.z,'#ff6472','GHOST');
  // Player arrow points in the direction the camera faces.
  const x=px(player.x), y=py(player.z), angle=yaw;
  ctx.save(); ctx.translate(x,y); ctx.rotate(angle);
  ctx.fillStyle='#66f0b0'; ctx.beginPath(); ctx.moveTo(0,-11); ctx.lineTo(7,8); ctx.lineTo(0,4); ctx.lineTo(-7,8); ctx.closePath(); ctx.fill(); ctx.restore();
  ctx.fillStyle='#dce7ef'; ctx.font='11px system-ui'; ctx.textAlign='left'; ctx.fillText('N ↑', 12, 18);
  ui.mapStatus.textContent = state.emfOn ? (ghostInEMFRange ? 'EMF trace acquired. The red marker shows the ghost.' : 'EMF is active, but no ghost trace is close enough to locate.') : 'Map pauses the game. Switch on EMF to reveal a nearby ghost marker.';
}

function notifyNoise(position, radius) {
  state.lastNoise.copy(position); state.lastNoiseAt=state.elapsed; state.noiseRadius=radius;
}

function collides(x,z,radius=0.34) {
  if (x < WORLD.minX || x > WORLD.maxX || z < WORLD.minZ || z > WORLD.maxZ) return true;
  for (const c of colliders) {
    if (Math.abs(x-c.x) < c.hw+radius && Math.abs(z-c.z) < c.hd+radius) return true;
  }
  return false;
}
function moveWithCollision(position, dx, dz, radius=0.34) {
  const nx=position.x+dx, nz=position.z+dz;
  if (!collides(nx,position.z,radius)) position.x=nx;
  if (!collides(position.x,nz,radius)) position.z=nz;
}

function updatePlayer(dt) {
  if (state.hidden) return;
  const joyX=joystick.x, joyY=joystick.y;
  const keyboardForward=(keys.has('KeyW')||keys.has('ArrowUp')?1:0)-(keys.has('KeyS')||keys.has('ArrowDown')?1:0);
  const keyboardSide=(keys.has('KeyD')||keys.has('ArrowRight')?1:0)-(keys.has('KeyA')||keys.has('ArrowLeft')?1:0);
  let forward=-joyY+keyboardForward, side=joyX+keyboardSide;
  const mag=Math.hypot(forward,side); if (mag>1) { forward/=mag; side/=mag; }
  const isMoving=mag>0.08;
  const speed=state.crouching?1.25:(state.running?4.55:2.55);
  const fx=-Math.sin(yaw), fz=-Math.cos(yaw);
  const rx=Math.cos(yaw), rz=-Math.sin(yaw);
  const dx=(fx*forward+rx*side)*speed*dt;
  const dz=(fz*forward+rz*side)*speed*dt;
  moveWithCollision(player,dx,dz);
  if (state.exitOpen && player.z > 13.15) { finishGame(true); return; }
  if (isMoving) {
    const noiseRadius=state.crouching?1.2:(state.running?12:4.8);
    if (state.elapsed-state.lastNoiseAt > (state.running?0.2:0.45)) notifyNoise(player,noiseRadius);
  }
  camera.position.set(player.x,state.hidden?1.25:(state.crouching?1.05:1.62),player.z);
  camera.rotation.set(pitch,yaw,0,'YXZ');
}

const keys = new Set();
window.addEventListener('keydown', e => {
  keys.add(e.code);
  if (['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code)) e.preventDefault();
  if (e.code==='Escape' && state.started && !state.paused) pauseGame();
  if (e.code==='KeyE') interact();
  if (e.code==='ShiftLeft'||e.code==='ShiftRight') state.running=true;
  if (e.code==='KeyC') toggleCrouch();
  if (e.code==='KeyF') toggleFlashlight();
  if (e.code==='KeyH') toggleHide();
  if (e.code==='KeyM' && state.started && !state.paused) openMap();
});
window.addEventListener('keyup', e => { keys.delete(e.code); if (e.code==='ShiftLeft'||e.code==='ShiftRight') state.running=false; });

function setupControls() {
  const joy=$('joystick'), knob=$('joystick-knob');
  const updateJoy = (clientX,clientY) => {
    const rect=joy.getBoundingClientRect(), cx=rect.left+rect.width/2, cy=rect.top+rect.height/2;
    let dx=clientX-cx, dy=clientY-cy; const max=Math.min(rect.width,rect.height)*0.34;
    const len=Math.hypot(dx,dy); if(len>max){dx=dx/len*max;dy=dy/len*max;}
    // Keep movement directions aligned with the visually rotated landscape HUD.
    if (usesRotatedPortraitLayout()) { joystick.x=dy/max; joystick.y=-dx/max; }
    else { joystick.x=dx/max; joystick.y=dy/max; }
    if (usesRotatedPortraitLayout()) knob.style.transform=`translate(${dy}px,${-dx}px)`;
    else knob.style.transform=`translate(${dx}px,${dy}px)`;
  };
  joy.addEventListener('pointerdown',e=>{ e.preventDefault(); joystick.pointer=e.pointerId; joy.setPointerCapture(e.pointerId); updateJoy(e.clientX,e.clientY); });
  joy.addEventListener('pointermove',e=>{ if(joystick.pointer===e.pointerId) updateJoy(e.clientX,e.clientY); });
  const clearJoy=e=>{ if(joystick.pointer===e.pointerId){joystick.pointer=null;joystick.x=0;joystick.y=0;knob.style.transform='translate(0,0)';} };
  joy.addEventListener('pointerup',clearJoy); joy.addEventListener('pointercancel',clearJoy);

  const lookZone=$('look-zone');
  lookZone.addEventListener('pointerdown',e=>{ if(!state.started||state.paused||state.ended) return; lookPointer=e.pointerId; previousLook={x:e.clientX,y:e.clientY}; lookZone.setPointerCapture(e.pointerId); });
  lookZone.addEventListener('pointermove',e=>{
    if(lookPointer!==e.pointerId||!previousLook) return;
    let dx=e.clientX-previousLook.x, dy=e.clientY-previousLook.y; previousLook={x:e.clientX,y:e.clientY};
    if (usesRotatedPortraitLayout()) { const screenX=dx; dx=dy; dy=-screenX; }
    yaw-=dx*0.0045*settings.sensitivity; pitch-=dy*0.0038*settings.sensitivity;
    pitch=THREE.MathUtils.clamp(pitch,-1.05,1.0); camera.rotation.set(pitch,yaw,0,'YXZ');
  });
  const endLook=e=>{if(lookPointer===e.pointerId){lookPointer=null;previousLook=null;}};
  lookZone.addEventListener('pointerup',endLook); lookZone.addEventListener('pointercancel',endLook);

  $('run-button').addEventListener('pointerdown',e=>{e.preventDefault();state.running=true;$('run-button').classList.add('active');});
  const stopRun=()=>{state.running=false;$('run-button').classList.remove('active');};
  $('run-button').addEventListener('pointerup',stopRun); $('run-button').addEventListener('pointercancel',stopRun); $('run-button').addEventListener('pointerleave',stopRun);
  $('crouch-button').addEventListener('click',toggleCrouch);
  $('hide-button').addEventListener('click',toggleHide);
  $('interact-button').addEventListener('click',interact);
  $('flashlight-button').addEventListener('click',toggleFlashlight);
  $('pause-button').addEventListener('click',pauseGame);
  $('emf-button').addEventListener('click',toggleEMF);
  $('uv-button').addEventListener('click',toggleUV);
  $('lure-button').addEventListener('click',useSoundLure);
  $('map-button').addEventListener('click',openMap);
  $('close-map-button').addEventListener('click',closeMap);
  $('map-resume-button').addEventListener('click',closeMap);
}

function toggleCrouch() { state.crouching=!state.crouching; $('crouch-button').classList.toggle('active',state.crouching); showToast(state.crouching?'Crouching: quieter, but slower.':'You stand up.'); }
function toggleFlashlight() {
  if (state.battery<=0 && !state.flashlight) { showToast('The flashlight battery is empty.'); return; }
  state.flashlight=!state.flashlight; flashlight.visible=state.flashlight; $('flashlight-button').classList.toggle('active',state.flashlight);
  soundTone(state.flashlight?620:280,0.08,0.035);
}
function toggleHide() {
  if (state.hidden) {
    state.hidden=false; state.hideSpot=null; camera.position.set(player.x,1.62,player.z); showToast('You leave the hiding place.');
    notifyNoise(player,2.2); return;
  }
  let nearest=null, dist=Infinity;
  for (const spot of hideSpots) { const d=player.distanceTo(spot.position); if(d<2.2&&d<dist){nearest=spot;dist=d;} }
  if (!nearest) { showToast('Move closer to a wardrobe to hide.'); return; }
  state.hidden=true; state.hideSpot=nearest; state.crouching=false; state.running=false;
  camera.position.set(nearest.position.x,1.25,nearest.position.z+0.85);
  showToast('Hidden. Stay quiet until the ghost leaves.');
}

function findTarget() {
  if (state.hidden) return null;
  camera.getWorldDirection(tempForward);
  let best=null, bestScore=Infinity;
  for (const root of interactables) {
    if (!root.visible) continue;
    const action=root.userData.action;
    if (action==='cabinet' && (!state.powerOn || hasItem('exitKey'))) continue;
    if (action==='keypad' && state.powerOn) continue;
    const pos=new THREE.Vector3(); root.getWorldPosition(pos);
    if (action==='exit') pos.set(0,1.6,11.78);
    if (action==='hide') pos.y=1.45;
    if (action==='cabinet') pos.y=1.2;
    const delta=pos.clone().sub(camera.position); const distance=delta.length();
    const dot=tempForward.dot(delta.normalize());
    const range=root.userData.range||3.2;
    if(distance<=range && dot>0.48) {
      const score=distance+(1-dot)*1.8;
      if(score<bestScore){best=root;bestScore=score;}
    }
  }
  return best;
}
function updateTarget() {
  currentTarget=findTarget();
  if (currentTarget) {
    let label=currentTarget.userData.label;
    if(currentTarget.userData.action==='exit') label=state.exitOpen?'OPEN EXIT':'LOCKED EXIT';
    if(currentTarget.userData.action==='keypad' && !hasItem('fuse')) label='POWER PANEL (NEEDS FUSE)';
    ui.prompt.textContent=`✋  ${label}  •  USE`;
    ui.prompt.classList.remove('hidden');
  } else ui.prompt.classList.add('hidden');
}

function interact() {
  if (!state.started||state.paused||state.ended) return;
  if (state.hidden) { toggleHide(); return; }
  const target=findTarget(); if(!target){showToast('Nothing to interact with. Look closer at an object.');return;}
  const action=target.userData.action;
  if(action==='brassKey') {
    state.inventory.add('brassKey'); target.visible=false; updateInventory(); state.ghostActive=true; ghost.visible=true;
    setObjective('Read the note in the library. Find the fuse in the bedroom.');
    showToast('Brass key collected. Something has awakened.'); soundTone(740,0.22,0.06);
  } else if(action==='fuse') {
    state.inventory.add('fuse'); target.visible=false; updateInventory();
    setObjective('Find the power keypad in the basement.'); showToast('Fuse collected.'); soundTone(520,0.15,0.05);
  } else if(action==='note') {
    state.noteRead=true; ui.note.classList.add('visible'); state.paused=true;
    setObjective('The note reveals the power code: 3142.');
  } else if(action==='keypad') {
    if(!hasItem('fuse')) { showToast('The power panel is missing a fuse.'); return; }
    state.keypadInput=''; updateKeypad(); ui.keypad.classList.add('visible'); state.paused=true;
  } else if(action==='cabinet') {
    if(!state.powerOn) { showToast('The cabinet lock has no power.'); return; }
    cabinetKey.visible=false; state.inventory.add('exitKey'); updateInventory();
    if (cabinetCollider) removeCollider(cabinetCollider);
    if (cabinetRoot && cabinetRoot.children[1]) { cabinetRoot.children[1].rotation.y=-0.95; cabinetRoot.children[1].position.x=0.45; }
    setObjective('Return to the entrance and unlock the front door.');
    showToast('You found the exit key. Get out!'); soundTone(880,0.3,0.06);
  } else if(action==='hide') toggleHide();
  else if(action==='exit') {
    if(!state.exitOpen) {
      if(!hasItem('exitKey')) { showToast('The front door is locked. Find the exit key.'); return; }
      state.exitOpen=true;
      const c=colliders.find(v=>v.exit); if(c) removeCollider(c);
      exitDoor.rotation.y=-1.35;
      setObjective('The exit is open. Escape the house!'); showToast('The lock clicks. The door swings open.'); soundTone(260,0.35,0.08,'triangle');
    } else finishGame(true);
  }
}

function updateKeypad() {
  ui.keypadDisplay.textContent=(state.keypadInput.padEnd(4,'_').split('').join(' '));
  ui.keypadMessage.textContent=state.inventory.has('fuse')?'Fuse installed. Enter the four-digit code.':'The panel needs a fuse and the correct code.';
}
function keypadInput(value) {
  if(value==='clear') state.keypadInput='';
  else if(value==='enter') {
    if(!hasItem('fuse')) {ui.keypadMessage.textContent='A fuse is required.';return;}
    if(state.keypadInput==='3142') {
      state.powerOn=true; state.panelUsed=true; state.inventory.delete('fuse'); updateInventory();
      ui.keypad.classList.remove('visible'); state.paused=false;
      cabinetKey.visible=true;
      setObjective('Power restored. Open the cabinet in the basement for the exit key.');
      showToast('POWER RESTORED. Something is moving upstairs.');
      soundTone(160,0.5,0.1,'sawtooth');
    } else { ui.keypadMessage.textContent='Incorrect code. The note may contain a clue.'; state.keypadInput=''; }
  } else if(state.keypadInput.length<4) state.keypadInput+=value;
  updateKeypad();
}

function lineOfSight(from,to) {
  const dir=to.clone().sub(from); const dist=dir.length(); dir.normalize();
  raycaster.set(from,dir); raycaster.far=dist;
  const hits=raycaster.intersectObjects(wallMeshes,false);
  return hits.length===0;
}

function gridPath(start,target) {
  const sx=Math.round(start.x), sz=Math.round(start.z), tx=Math.round(target.x), tz=Math.round(target.z);
  const key=(x,z)=>`${x},${z}`;
  const queue=[[sx,sz]], came=new Map(); came.set(key(sx,sz),null);
  const dirs=[[1,0],[-1,0],[0,1],[0,-1]];
  let found=false, iterations=0;
  while(queue.length && iterations++<1800) {
    const [x,z]=queue.shift();
    if(x===tx&&z===tz){found=true;break;}
    for(const [dx,dz] of dirs){
      const nx=x+dx,nz=z+dz,k=key(nx,nz);
      if(nx<WORLD.minX+0.5||nx>WORLD.maxX-0.5||nz<WORLD.minZ+0.5||nz>WORLD.maxZ-0.5||came.has(k)) continue;
      if(collides(nx,nz,0.28)) continue;
      came.set(k,[x,z]);queue.push([nx,nz]);
    }
  }
  if(!found) return [];
  const path=[]; let cur=[tx,tz];
  while(cur){path.push(new THREE.Vector3(cur[0],0,cur[1]));cur=came.get(key(cur[0],cur[1]));}
  path.reverse(); return path.slice(1);
}

function ghostSetState(next) {
  if(state.ghostState===next) return;
  state.ghostState=next; state.ghostStateTime=0; state.aiPathTimer=0;
  if(next==='chase') { showToast('RUN. THE GHOST HAS FOUND YOU.',1600); soundTone(95,0.55,0.08,'sawtooth'); }
}
function updateGhost(dt) {
  if(!state.ghostActive||!ghost.visible||state.ended) return;
  state.ghostStateTime+=dt; state.aiPathTimer+=dt;
  const ghostPos=ghost.position.clone(); ghostPos.y=1.0;
  const playerPos=player.clone(); playerPos.y=1.5;
  const distance=ghostPos.distanceTo(playerPos);
  const toPlayer=playerPos.clone().sub(ghostPos).normalize();
  const forward=new THREE.Vector3(-Math.sin(yaw),0,-Math.cos(yaw));
  const ghostForward=new THREE.Vector3(-Math.sin(ghost.rotation.y),0,-Math.cos(ghost.rotation.y));
  const ghostView=ghostForward.dot(toPlayer);
  const seesPlayer=!state.hidden && distance<=(settings.difficulty==='easy'?7.2:settings.difficulty==='hard'?11:9) && ghostView>0.05 && lineOfSight(ghostPos.clone().setY(2.5),playerPos.clone().setY(1.3));
  const lureDistance = ghost.position.distanceTo(state.lastNoise);
  const hearsPlayer=(!state.hidden && state.elapsed-state.lastNoiseAt<1.1 && distance<(state.noiseRadius||4.5)) || (state.lureActiveUntil>state.elapsed && lureDistance<(state.noiseRadius||18));
  if(seesPlayer) {state.lastSeenAt=state.elapsed;state.lastKnown.copy(player);}
  if(hearsPlayer && state.elapsed-state.lastNoiseAt<0.2) state.lastKnown.copy(state.lastNoise);

  if(seesPlayer) ghostSetState('chase');
  else if(state.ghostState==='chase' && state.elapsed-state.lastSeenAt>3.5) ghostSetState('search');
  else if(hearsPlayer && state.ghostState!=='chase') ghostSetState('investigate');
  else if(state.ghostState==='search' && state.ghostStateTime>7) ghostSetState('patrol');
  else if(state.ghostState==='investigate' && state.ghostStateTime>5) ghostSetState('patrol');

  let target;
  if(state.ghostState==='chase') target=player.clone();
  else if(state.ghostState==='investigate') target=state.lastNoise.clone();
  else if(state.ghostState==='search') target=state.lastKnown.clone();
  else {
    const patrol=[new THREE.Vector3(0,0,-4),new THREE.Vector3(6,0,-4),new THREE.Vector3(6,0,-12),new THREE.Vector3(-6,0,-12),new THREE.Vector3(-6,0,-4)];
    if(!state.patrolIndex || ghost.position.distanceTo(patrol[state.patrolIndex])<1.0) state.patrolIndex=((state.patrolIndex||0)+1)%patrol.length;
    target=patrol[state.patrolIndex];
  }
  if(state.aiPathTimer>0.85 || !state.ghostPath.length) {
    state.ghostPath=gridPath(ghost.position,target); state.aiPathTimer=0;
  }
  let waypoint=state.ghostPath.length?state.ghostPath[0]:target;
  if(ghost.position.distanceTo(waypoint)<0.55 && state.ghostPath.length) {state.ghostPath.shift();waypoint=state.ghostPath[0]||target;}
  const speedBase=settings.difficulty==='easy'?1.45:settings.difficulty==='hard'?2.3:1.9;
  const speed=state.ghostState==='chase'?speedBase+0.85:state.ghostState==='investigate'?speedBase*0.9:speedBase*0.65;
  const delta=waypoint.clone().sub(ghost.position); delta.y=0;
  if(delta.length()>0.06) {
    delta.normalize(); const nextX=ghost.position.x+delta.x*speed*dt, nextZ=ghost.position.z+delta.z*speed*dt;
    if(!collides(nextX,nextZ,0.35)){ghost.position.x=nextX;ghost.position.z=nextZ;}
    else { state.aiPathTimer=2; }
    ghost.rotation.y=Math.atan2(-delta.x,-delta.z);
  }
  ghost.position.y=Math.sin(state.elapsed*2.3)*0.16;
  if (ghost.userData.shroud) ghost.userData.shroud.rotation.z=state.elapsed*0.65;
  ghost.children.forEach((child,i)=>{ if(child.isMesh && child.geometry && child.geometry.type==='CapsuleGeometry') child.rotation.z=Math.sin(state.elapsed*1.8+i)*0.08; });
  ghostLight.intensity=0.95+Math.sin(state.elapsed*4)*0.28;
  ghost.scale.setScalar(state.ghostState==='chase'?1.04:1.0);
  ui.warning.classList.toggle('hidden',distance>8.5||state.hidden);
  if(distance<1.0 && !state.hidden && state.damageCooldown<=0) {
    state.damageCooldown=1.5; state.health-=0.35; updateHealth(); ui.damage.style.background='rgba(135,15,28,.48)';
    setTimeout(()=>ui.damage.style.background='rgba(135,15,28,0)',180);
    soundTone(55,0.35,0.12,'sawtooth');
    if(state.health<=0) finishGame(false);
    else { // A brief supernatural displacement gives the player another chance.
      player.set(0,0,8.2); yaw=0; showToast('The ghost caught you. You stumble back to the entrance.');
    }
  }
}

function updateFlashlight(dt) {
  if(state.flashlight && state.battery>0) {
    state.battery=Math.max(0,state.battery-dt*0.42);
    flashlight.intensity=5.8*(0.96+Math.sin(state.elapsed*1.9)*0.025);
    if(state.battery<=0){state.flashlight=false;flashlight.visible=false;showToast('Flashlight battery depleted.');}
  }
  camera.getWorldDirection(tempForward);
  flashlight.position.copy(camera.position).add(tempForward.clone().multiplyScalar(0.12));
  flashlightTarget.position.copy(camera.position).add(tempForward.clone().multiplyScalar(7));
  updateBattery();
}

function finishGame(won) {
  state.ended=true;state.paused=true; state.mapOpen=false; ui.map.classList.add('hidden'); ui.map.classList.remove('visible');
  ui.endKicker.textContent=won?'CHAPTER COMPLETE':'GAME OVER';
  ui.endTitle.textContent=won?'You escaped.':'The house keeps its secret.';
  ui.endDescription.textContent=won?'The front door opens into the cold night. Behind you, the mansion goes quiet.':'The ghost has caught you. The storm outside continues, and the house remains sealed.';
  ui.end.classList.add('visible');
  if(won) soundTone(660,0.7,0.08,'sine');
}

function applySettings() {
  settings.quality=$('quality-setting').value;
  settings.difficulty=$('difficulty-setting').value;
  settings.sensitivity=Number($('sensitivity-setting').value);
  settings.volume=Number($('volume-setting').value)/100;
  settings.brightness=Number($('brightness-setting').value);
  $('sensitivity-label').textContent=`${settings.sensitivity.toFixed(1)}×`;
  $('volume-label').textContent=`${Math.round(settings.volume*100)}%`;
  $('brightness-label').textContent=`${settings.brightness.toFixed(2)}×`;
  if(renderer) renderer.toneMappingExposure=settings.brightness;
  if(masterGain && audioContext) masterGain.gain.setTargetAtTime(settings.volume,audioContext.currentTime,0.08);
  if(renderer) { const viewport=getGameViewport(); renderer.setPixelRatio(Math.min(devicePixelRatio||1,settings.quality==='high'?1.5:1.1)); renderer.setSize(viewport.width,viewport.height,false); renderer.shadowMap.enabled=settings.quality!=='low'; }
  if(flashlight) flashlight.castShadow=settings.quality==='high';
  showToast('Settings updated.');
}

function animate() {
  requestAnimationFrame(animate);
  const dt=Math.min(clock.getDelta()||0,0.05);
  if(state.started&&!state.paused&&!state.ended) {
    state.elapsed+=dt;
    if(state.damageCooldown>0) state.damageCooldown-=dt;
    updatePlayer(dt); updateFlashlight(dt); updateEquipment(dt); updateGhost(dt); updateTarget();
    if (state.mapOpen) { mapDrawTimer += dt; if (mapDrawTimer > 0.3) { drawMap(); mapDrawTimer = 0; } }
    if(state.toastTimer>0){state.toastTimer-=dt*1000;if(state.toastTimer<=0)ui.toast.classList.add('hidden');}
    if(dust) dust.rotation.y=Math.sin(state.elapsed*0.12)*0.025;
  }
  renderer.render(scene,camera);
}

function bindUI() {
  $('start-button').addEventListener('click',startGame);
  $('settings-button').addEventListener('click',()=>{ui.start.classList.remove('visible');ui.settings.classList.add('visible');});
  $('pause-settings-button').addEventListener('click',()=>{ui.pause.classList.remove('visible');ui.settings.classList.add('visible');});
  $('settings-back-button').addEventListener('click',()=>{applySettings();ui.settings.classList.remove('visible');if(state.started){ui.pause.classList.add('visible');state.paused=true;}else ui.start.classList.add('visible');});
  $('resume-button').addEventListener('click',resumeGame);
  $('restart-button').addEventListener('click',()=>{resetGame();state.started=true;state.paused=false;showGameUI();});
  $('main-menu-button').addEventListener('click',()=>{state.started=false;state.paused=true;ui.pause.classList.remove('visible');ui.hud.classList.add('hidden');ui.controls.classList.add('hidden');ui.crosshair.classList.add('hidden');ui.start.classList.add('visible');});
  $('close-note-button').addEventListener('click',()=>{ui.note.classList.remove('visible');state.paused=false;});
  $('close-keypad-button').addEventListener('click',()=>{ui.keypad.classList.remove('visible');state.paused=false;});
  $('keypad-screen').querySelectorAll('[data-digit]').forEach(btn=>btn.addEventListener('click',()=>keypadInput(btn.dataset.digit)));
  $('keypad-screen').querySelectorAll('[data-action]').forEach(btn=>btn.addEventListener('click',()=>keypadInput(btn.dataset.action)));
  $('end-restart-button').addEventListener('click',()=>{ui.end.classList.remove('visible');resetGame();state.started=true;state.paused=false;showGameUI();});
  $('end-menu-button').addEventListener('click',()=>{ui.end.classList.remove('visible');state.started=false;state.paused=true;ui.hud.classList.add('hidden');ui.controls.classList.add('hidden');ui.crosshair.classList.add('hidden');ui.start.classList.add('visible');});
  $('sensitivity-setting').addEventListener('input',()=>{$('sensitivity-label').textContent=`${Number($('sensitivity-setting').value).toFixed(1)}×`;});
  $('volume-setting').addEventListener('input',()=>{$('volume-label').textContent=`${$('volume-setting').value}%`;});
  $('brightness-setting').addEventListener('input',()=>{$('brightness-label').textContent=`${Number($('brightness-setting').value).toFixed(2)}×`; if(renderer) renderer.toneMappingExposure=Number($('brightness-setting').value);});
  document.addEventListener('visibilitychange',()=>{if(document.hidden&&state.started&&!state.paused&&!state.ended)pauseGame();});
  window.addEventListener('resize',()=>{if(!renderer)return;const viewport=getGameViewport();camera.aspect=viewport.width/viewport.height;camera.updateProjectionMatrix();renderer.setSize(viewport.width,viewport.height,false);});
  window.addEventListener('orientationchange',()=>{if(!renderer)return;setTimeout(()=>{const viewport=getGameViewport();camera.aspect=viewport.width/viewport.height;camera.updateProjectionMatrix();renderer.setSize(viewport.width,viewport.height,false);},180);});
}

function showStartupHelp() {
  // Never put raw JavaScript errors or stack traces over the game screen.
  let panel=document.getElementById('startup-help');
  if(panel) return;
  panel=document.createElement('section');
  panel.id='startup-help';
  panel.style.cssText='position:fixed;inset:0;z-index:9999;display:flex;align-items:center;justify-content:center;padding:22px;background:rgba(7,12,18,.96);color:#f4f6f8;font:14px/1.55 system-ui,sans-serif;text-align:center;';
  const card=document.createElement('div');
  card.style.cssText='width:min(440px,100%);padding:26px;border:1px solid rgba(213,184,122,.45);background:#18232d;';
  const heading=document.createElement('h2'); heading.textContent='GHOST could not start'; heading.style.cssText='margin:0 0 12px;color:#e5ca91;font-size:23px;';
  const message=document.createElement('p'); message.textContent='The 3D graphics engine did not start. Open this project using Spck Preview or a local web server, keep internet access enabled for the Three.js library, and make sure WebGL is supported in your browser.';
  const button=document.createElement('button'); button.type='button'; button.textContent='TRY AGAIN'; button.style.cssText='margin-top:12px;min-height:46px;width:100%;border:1px solid #e5ca91;background:#d9bd82;color:#16130d;font-weight:800;letter-spacing:.12em;';
  button.addEventListener('click',()=>window.location.reload());
  card.append(heading,message,button); panel.append(card); document.body.append(panel);
}
window.showGhostStartupHelp = showStartupHelp;

function boot() {
  try {
    createWorld();
    clock=new THREE.Clock(false);
    setupControls(); bindUI();
    updateInventory(); updateBattery(); updateHealth(); updateToolUI();
    animate();
  } catch(error) {
    console.error('GHOST startup failed:', error);
    showStartupHelp();
  }
}

boot();
