# VANTA — Android APK guide

The game is a React + Vite web app. It is already a single-page, touch-ready build, so the
fastest way to get a real `.apk` is to wrap the `dist/` folder with **Capacitor** (an official
native Android shell). No game code changes are required.

---

## 1. Prerequisites

| Tool | Version / notes |
| --- | --- |
| Node.js | 20 or newer (this project was built on Node 20) |
| JDK | **21** (required by Capacitor 7 / Android Gradle Plugin 8.7+) |
| Android Studio | Ladybug or newer, with Android SDK Platform 35 + Build-Tools |
| Android SDK env | `ANDROID_HOME` and `PATH` → `$ANDROID_HOME/platform-tools` |

Install Android Studio from <https://developer.android.com/studio>. On first launch let it
download the SDK, then check **Tools → SDK Manager → SDK Platforms → Android 15 (API 35)**.

Verify:

```bash
node -v
java -version        # must report 21.x
```

---

## 2. Install Capacitor (once)

Run these in the project root:

```bash
npm install @capacitor/core @capacitor/android
npm install -D @capacitor/cli
```

Then create the Capacitor config file `capacitor.config.ts` in the project root:

```ts
import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.vanta.night",      // change to your own reverse-domain id
  appName: "VANTA",
  webDir: "dist",
  server: {
    androidScheme: "https",      // keeps /images/... paths working
  },
  android: {
    allowMixedContent: false,
    backgroundColor: "#060705",
  },
};

export default config;
```

> `webDir` must be `dist` because that is what `npm run build` produces.
> The `https` scheme makes root-relative paths such as `/images/hero-car.jpg` resolve
> correctly inside the WebView.

Add the Android platform and sync the web build:

```bash
npm run build
npx cap add android
npx cap sync android
```

`android/` is a normal Gradle project you can open, edit and commit.

---

## 3. Build a debug APK (fastest)

Open the native project:

```bash
npx cap open android
```

In Android Studio: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
When it finishes click **locate** — or find it here:

```
android/app/build/outputs/apk/debug/app-debug.apk
```

Copy it to your phone and install (enable “Install unknown apps” for your file manager).

CLI alternative (no Android Studio UI):

```bash
cd android
./gradlew assembleDebug
```

After every change to the web code, re-run:

```bash
npm run build && npx cap sync android
```

To launch it on a connected device / emulator:

```bash
npx cap run android
```

---

## 4. Screen orientation (optional)

The game is fully responsive in both portrait and landscape. To lock landscape for a more
console-like run, edit `android/app/src/main/AndroidManifest.xml` and add to the `<activity>`:

```xml
android:screenOrientation="sensorLandscape"
```

Portrait feels more natural on phones because the game frame is `aspect-[4/5]` on small
screens, so leaving it unlocked is recommended.

---

## 5. App icon and splash

Create a source icon (1024 × 1024 PNG, background `#c9fa3c`, black V mark) plus an optional
`2732 × 2732` splash, then:

```bash
npm install -D @capacitor/assets
mkdir -p resources
# put icon.png (1024) and splash.png (2732) in resources/
npx capacitor-assets generate --android
npx cap sync android
```

---

## 6. Release APK / Play Store bundle

1. Create a keystore (keep it safe, back it up):

```bash
keytool -genkey -v -keystore vanta-release.keystore \
  -alias vanta -keyalg RSA -keysize 2048 -validity 10000
```

2. In Android Studio: **Build → Generate Signed Bundle / APK… → APK** (for direct install)
   or **Android App Bundle** (for Google Play). Select the keystore, then **release**.

Outputs:

```
android/app/build/outputs/apk/release/app-release.apk
android/app/build/outputs/bundle/release/app-release.aab
```

Never commit the keystore or `keystore.properties`.

---

## 7. What this build needs at runtime

- **Internet permission** — Capacitor's Android manifest already requests
  `android.permission.INTERNET`. It is needed because the display fonts
  (Inter Tight / Instrument Serif / JetBrains Mono) are loaded from Google Fonts
  via `@import` in `src/index.css`.
- **Offline fonts** — to make the APK work with no network, download the three font families,
  put the `.woff2` files in `src/assets/fonts/`, and replace the `@import` line with local
  `@font-face` rules. Remove `android.permission.INTERNET` afterwards.
- **Audio** — all engine and collision sounds are synthesised with the Web Audio API and start
  on the player's first tap/keypress, so there is no autoplay-blocking issue on Android.
- **Saves** — the best distance and local leaderboard use `localStorage`, which persists in the
  Android WebView across app launches.
- **Fullscreen button** — the in-game expand button uses an in-page overlay (not the browser
  Fullscreen API), so it works inside the WebView. To hide the status bar, install
  `@capacitor/status-bar` and call `StatusBar.hide()` on startup.
- **Safe areas** — add `viewport-fit=cover` in `index.html` and a small status-bar plugin setup
  if you want the canvas to bleed behind the notch.

---

## 8. Alternative: PWABuilder (no Android Studio)

If you prefer a hosted install and already have a signing key:

1. Deploy `dist/` to any HTTPS host (Netlify, Vercel, Cloudflare Pages).
2. Add `public/manifest.webmanifest` (name, icons, `display: fullscreen`,
   `background_color: #060705`, `theme_color: #060705`) and a basic service worker.
3. Go to <https://www.pwabuilder.com>, enter the URL, choose **Android**, and download the
   generated package (a Trusted Web Activity).
4. Sign and upload the `.aab` to Google Play. Direct `.apk` installs require you to keep the
   package signed with your key.

PWABuilder produces a thin native wrapper around the hosted site, so the app needs a network
connection. Capacitor bundles the game inside the APK and is the better fit for VANTA.

---

## 9. Troubleshooting

| Symptom | Fix |
| --- | --- |
| Blank screen after install | Run `npm run build && npx cap sync android`; confirm `dist/index.html` exists. |
| Images missing | Don't load `index.html` with `file://`; use Capacitor (`https://localhost`). If you must use a plain WebView/`file://`, set `base: "./"` in `vite.config.ts` and rebuild. |
| Gradle says “Unsupported class file major version” | Use JDK 21 (`java -version`). |
| “SDK location not found” | Open the `android/` folder once in Android Studio, or set `ANDROID_HOME`. |
| No sound | Tap the screen first, and check the speaker icon in the game toolbar. |
| Fonts fall back to system font offline | Self-host fonts as described in section 7. |
| App white-flashes on launch | Set a dark launch theme / splash in `res/values/styles.xml` to `#060705`. |

---

### Quick command recap

```bash
npm run build
npx cap sync android
npx cap open android      # then Build → Build APK(s)
```

That is the whole pipeline: **build → sync → build APK**.
