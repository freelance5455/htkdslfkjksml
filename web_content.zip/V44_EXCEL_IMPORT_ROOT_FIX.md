# V44 — Excel Import Root Fix

Based directly on V43. This version fixes the Excel controls at the actual WebView interaction layer.

## Changes
- **Choose File:** replaced programmatic activation of a hidden file input with a real `<label>` control containing the file input. This lets Android WebView invoke the standard native document chooser from the user's tap.
- **Android file result:** the native chooser result is parsed once by the Android bridge and then sent to the import preview. The selected URI is not handed back into a second WebView FileReader path.
- **Native XLSX parser:** runs off the UI thread to avoid blocking the Android activity.
- **Import errors:** are sent back into the import dialog so failures are visible there, not only as a toast.
- **Download Excel template:** keeps the Android native save dialog and web fallback.
- **Version:** Android versionCode 16 / versionName 2.12.
- No Supabase schema/functions were changed.
