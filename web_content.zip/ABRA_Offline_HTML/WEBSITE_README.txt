ABRA WEBSITE COPY
=================

This folder contains the static HTML website copy of the supplied project.

MAIN FILE
- index.html

IMPORTANT
- Keep the assets/ and __grok/ folders, favicon.svg, og.jpg, and x-banner.jpg together with index.html.
- Do not rename files referenced by index.html.
- For the most reliable website behavior, upload the entire folder to a static hosting service (for example GitHub Pages, Netlify, or Cloudflare Pages). Open index.html through the hosted site URL.
- Opening index.html directly from a phone's file manager may not work in every browser because the site loads JavaScript as ES modules.
- The files are bundled locally, but any functions that rely on remote APIs, sign-in, databases, or other online services will still require internet. This package has not been verified to be fully functional offline.

To test locally on a computer, serve this folder with a local static web server and open its URL in a browser.
