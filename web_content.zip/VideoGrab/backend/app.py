import os, re, shutil, tempfile
from urllib.parse import quote
from flask import Flask, request, jsonify, Response, send_from_directory
import yt_dlp

BASE = os.path.dirname(os.path.abspath(__file__))
FRONT = os.path.abspath(os.path.join(BASE, "..", "frontend"))
app = Flask(__name__, static_folder=None)


@app.get("/")
def index():
    return send_from_directory(FRONT, "index.html")


@app.get("/<path:p>")
def assets(p):
    return send_from_directory(FRONT, p)


def valid(url):
    return bool(re.match(r"^https?://", url or ""))


@app.post("/api/info")
def info():
    url = ((request.get_json(silent=True) or {}).get("url") or "").strip()
    if not valid(url):
        return jsonify(error="الرابط غير صالح. الصق رابطاً يبدأ بـ http أو https."), 400
    try:
        with yt_dlp.YoutubeDL({"quiet": True, "noplaylist": True, "skip_download": True}) as y:
            d = y.extract_info(url, download=False)
    except Exception as e:
        return jsonify(error="تعذر قراءة الرابط: " + str(e)[:180]), 400
    heights = sorted({f["height"] for f in d.get("formats", [])
                      if f.get("height") and f.get("vcodec") not in (None, "none")}, reverse=True)
    return jsonify(title=d.get("title") or "فيديو", thumbnail=d.get("thumbnail"),
                   duration=d.get("duration"), uploader=d.get("uploader"),
                   site=d.get("extractor_key"), heights=heights)


@app.get("/api/download")
def download():
    url = request.args.get("url", "")
    kind = request.args.get("kind", "video")
    height = request.args.get("height", "")
    if not valid(url):
        return jsonify(error="الرابط غير صالح"), 400
    tmp = tempfile.mkdtemp(prefix="vg_")
    opts = {"quiet": True, "noplaylist": True,
            "outtmpl": os.path.join(tmp, "%(title).80B.%(ext)s")}
    if kind == "audio":
        opts["format"] = "bestaudio/best"
        opts["postprocessors"] = [{"key": "FFmpegExtractAudio",
                                   "preferredcodec": "mp3", "preferredquality": "192"}]
    else:
        h = int(height) if height.isdigit() else 1080
        opts["format"] = f"bestvideo[height<={h}]+bestaudio/best[height<={h}]/best"
        opts["merge_output_format"] = "mp4"
    try:
        with yt_dlp.YoutubeDL(opts) as y:
            y.download([url])
        files = os.listdir(tmp)
        if not files:
            raise RuntimeError("لم يتم إنتاج ملف")
        path = os.path.join(tmp, files[0])
    except Exception as e:
        shutil.rmtree(tmp, ignore_errors=True)
        return jsonify(error="فشل التحميل: " + str(e)[:180]), 500

    def stream():
        try:
            with open(path, "rb") as f:
                while True:
                    chunk = f.read(1 << 20)
                    if not chunk:
                        break
                    yield chunk
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    name = os.path.basename(path)
    r = Response(stream(), mimetype="application/octet-stream")
    r.headers["Content-Length"] = str(os.path.getsize(path))
    r.headers["Content-Disposition"] = "attachment; filename*=UTF-8''" + quote(name)
    r.headers["Access-Control-Expose-Headers"] = "Content-Disposition, Content-Length"
    return r


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    print(f"\n  VideoGrab running: http://localhost:{port}\n")
    app.run(host="0.0.0.0", port=port, threaded=True)
