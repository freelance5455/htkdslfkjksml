(() => {
  const $ = (id) => document.getElementById(id);
  const urlEl = $("url"), msg = $("msg"), fetchBtn = $("fetch");
  let current = "";

  const say = (t, err) => { msg.textContent = t || ""; msg.className = "msg" + (err ? " err" : ""); };
  const fmt = (s) => { if (!s) return ""; const m = Math.floor(s / 60), x = Math.floor(s % 60); return m + ":" + String(x).padStart(2, "0"); };
  const label = (h) => h >= 2160 ? "4K — 2160p" : h >= 1440 ? "2K — 1440p" : h + "p";

  $("paste").onclick = async () => {
    try { urlEl.value = (await navigator.clipboard.readText()).trim(); }
    catch { say("تعذر الوصول للحافظة. الصق الرابط يدوياً.", true); }
  };

  urlEl.addEventListener("keydown", (e) => { if (e.key === "Enter") analyze(); });
  fetchBtn.onclick = analyze;

  async function analyze() {
    const url = urlEl.value.trim();
    if (!url) return say("الصق رابط الفيديو أولاً.", true);
    fetchBtn.disabled = true; $("result").hidden = true; say("جاري تحليل الرابط...");
    try {
      const r = await fetch("/api/info", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ url }) });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error || "حدث خطأ");
      current = url;
      $("thumb").src = d.thumbnail || "";
      $("title").textContent = d.title;
      $("sub").textContent = [d.site, d.uploader, fmt(d.duration)].filter(Boolean).join(" | ");
      const box = $("videos"); box.innerHTML = "";
      const hs = d.heights.length ? d.heights : [0];
      hs.forEach((h) => {
        const b = document.createElement("button");
        b.className = "opt"; b.dataset.kind = "video"; b.dataset.h = h || "";
        b.textContent = h ? "MP4 — " + label(h) : "MP4 — أفضل جودة";
        box.appendChild(b);
      });
      $("result").hidden = false; say("");
    } catch (e) { say(e.message, true); }
    fetchBtn.disabled = false;
  }

  $("result").addEventListener("click", (e) => {
    const b = e.target.closest(".opt"); if (b) save(b);
  });

  async function save(btn) {
    const all = document.querySelectorAll(".opt"), prog = $("prog"), bar = $("bar");
    all.forEach((x) => (x.disabled = true));
    prog.hidden = false; prog.className = "prog wait"; bar.style.width = "";
    say("جاري التحضير على الخادم، قد يستغرق دقيقة...");
    try {
      const q = new URLSearchParams({ url: current, kind: btn.dataset.kind, height: btn.dataset.h || "" });
      const r = await fetch("/api/download?" + q);
      if (!r.ok) { let m = "فشل التحميل"; try { m = (await r.json()).error || m; } catch {} throw new Error(m); }
      const total = +r.headers.get("Content-Length") || 0;
      const cd = r.headers.get("Content-Disposition") || "";
      const mt = /filename\*=UTF-8''([^;]+)/i.exec(cd);
      const name = mt ? decodeURIComponent(mt[1]) : "video.mp4";
      prog.className = "prog"; bar.style.width = "0";
      say("جاري تنزيل الملف...");
      const reader = r.body.getReader(), parts = []; let got = 0;
      for (;;) {
        const { done, value } = await reader.read(); if (done) break;
        parts.push(value); got += value.length;
        if (total) bar.style.width = (got / total * 100) + "%";
      }
      const a = document.createElement("a");
      a.href = URL.createObjectURL(new Blob(parts)); a.download = name;
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 60000);
      bar.style.width = "100%"; say("تم التحميل: " + name);
    } catch (e) { prog.hidden = true; say(e.message, true); }
    all.forEach((x) => (x.disabled = false));
  }
})();
