# VideoGrab

## المتطلبات
1. Python 3.9+  (https://python.org)
2. ffmpeg (لدمج الصوت والفيديو وتحويل MP3)
   - Windows: winget install ffmpeg
   - Mac: brew install ffmpeg
   - Linux: sudo apt install ffmpeg

## التشغيل
- Windows: انقر مرتين على run.bat
- Mac/Linux: ./run.sh
ثم افتح http://localhost:5000

## الهيكل
- frontend/  (HTML + CSS + JS)
- backend/   (Python + yt-dlp)

## تحديث دعم المواقع
pip install -U yt-dlp   (داخل البيئة venv)
