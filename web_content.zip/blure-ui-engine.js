/* blure UI preview v0.9.0 prototype: standard CSS + declarative UI. */
(()=>{'use strict';
const get=id=>document.getElementById(id);
function expandModules(source,files,entry){
 const loaded=new Set(), visiting=[];
 function visit(text,path){
  if(visiting.includes(path))throw Error('Module import cycle: '+[...visiting,path].join(' -> '));
  visiting.push(path);
  const output=[];
  for(const line of text.split(/\r?\n/)){
   const m=/^\s*use\.module\(([^)]+\.blu)\)\s*$/.exec(line);
   if(!m){output.push(line);continue}
   const name=m[1].trim();
   if(name.startsWith('/')||name.includes('..')||name.includes('\\'))throw Error('Invalid module path: '+name);
   if(typeof files[name]!=='string')throw Error('Missing module: '+name);
   if(!loaded.has(name)){loaded.add(name);output.push('// imported '+name,visit(files[name],name))}
  }
  visiting.pop();return output.join('\n');
 }
 return visit(source,entry);
}
function expandComponents(source){
 const definitions=new Map(),lines=source.split(/\r?\n/),body=[];
 for(let i=0;i<lines.length;i++){
  const m=/^\s*ui\.component\(([\w-]+)\)\s*$/.exec(lines[i]);
  if(!m){body.push(lines[i]);continue}
  if(definitions.has(m[1]))throw Error('Duplicate component: '+m[1]);
  const parts=[];let depth=1;
  while(++i<lines.length){const t=lines[i].trim();if(/^ui\.component\(/.test(t))depth++;if(t==='ui.end.component'){depth--;if(depth===0)break}parts.push(lines[i]);}
  if(depth!==0)throw Error('Unclosed component: '+m[1]);
  definitions.set(m[1],parts.join('\n'));
 }
 function insert(text,chain=[]){return text.split(/\r?\n/).map(line=>{
  const m=/^\s*ui\.use\(([\w-]+)\)\s*$/.exec(line);if(!m)return line;
  if(!definitions.has(m[1]))throw Error('Unknown component: '+m[1]);
  if(chain.includes(m[1]))throw Error('Recursive component: '+[...chain,m[1]].join(' -> '));
  return insert(definitions.get(m[1]),[...chain,m[1]]);
 }).join('\n')}
 return insert(body.join('\n'));
}
function render(source,files){
 const rows=expandComponents(source).split(/\r?\n/),root=document.createElement('div'),stack=[root],handlers=[],functions=new Map(),boards=new Map();
 let activeCss='';
 const fail=(n,msg)=>{throw Error('UI line '+n+': '+msg)};
 const current=()=>stack[stack.length-1];
 const appendText=(el,value)=>el.appendChild(document.createTextNode(value));
 const events=[];
 const uiNodes=new Map();
 const boardStates=new Map();
 const windows=new Map();
 const makeBoard=(id)=>{if(boards.has(id))throw Error('Duplicate board '+id);const el=document.createElement('div');el.id=id;el.className='blure-board';el.setAttribute('role','group');el.setAttribute('aria-label','Bingo board');current().appendChild(el);boards.set(id,el);const state={values:[],marked:new Set(),won:false};boardStates.set(id,state)};
 function windowAction(w,action){
  if(action==='close'){w.hidden=true;return}
  if(action==='show'||action==='restore'){w.hidden=false;w.classList.remove('blure-minimized');if(action==='restore')w.classList.remove('blure-maximized');return}
  if(action==='minimize'){w.classList.add('blure-minimized');return}
  if(action==='maximize'){w.hidden=false;w.classList.remove('blure-minimized');w.classList.toggle('blure-maximized');return}
 }
 function wireWindow(w){
  const bar=w.querySelector('.blure-window-bar');let dragging=false,sx=0,sy=0,ox=0,oy=0;
  bar.addEventListener('pointerdown',e=>{if(e.target.closest('button')||w.classList.contains('blure-maximized'))return;dragging=true;sx=e.clientX;sy=e.clientY;ox=parseFloat(w.style.left)||0;oy=parseFloat(w.style.top)||0;bar.setPointerCapture(e.pointerId)});
  bar.addEventListener('pointermove',e=>{if(!dragging)return;w.style.left=Math.max(0,ox+e.clientX-sx)+'px';w.style.top=Math.max(0,oy+e.clientY-sy)+'px'});
  bar.addEventListener('pointerup',()=>dragging=false);bar.addEventListener('pointercancel',()=>dragging=false);
  for(const btn of w.querySelectorAll('[data-window-action]'))btn.addEventListener('click',()=>windowAction(w,btn.dataset.windowAction));
  w.addEventListener('pointerdown',()=>{for(const other of windows.values())other.style.zIndex='1';w.style.zIndex='2'});
 }
 function completed(state){const lines=[];for(let r=0;r<5;r++)lines.push([0,1,2,3,4].map(c=>r*5+c));for(let c=0;c<5;c++)lines.push([0,1,2,3,4].map(r=>r*5+c));lines.push([0,6,12,18,24],[4,8,12,16,20]);return lines.filter(line=>line.every(i=>state.marked.has(state.values[i])))}
 function paint(id){const state=boardStates.get(id),el=boards.get(id);if(!state||!el)return;const lines=completed(state);el.replaceChildren();for(const [i,n] of state.values.entries()){const btn=el.ownerDocument.createElement('button');btn.type='button';btn.className='blure-tile'+(state.marked.has(n)?' marked':'')+(lines.some(line=>line.includes(i))?' completed':'');btn.textContent=String(n);btn.setAttribute('aria-label','Number '+n+(state.marked.has(n)?', marked':''));btn.setAttribute('aria-pressed',String(state.marked.has(n)));btn.disabled=state.won;btn.addEventListener('click',()=>{if(state.won)return;events.filter(e=>e.kind==='mark'&&e.id===id).forEach(e=>execute(e.fn,id,n));});el.appendChild(btn)}const progress=el.ownerDocument.getElementById(id+'-progress');if(progress)progress.textContent=state.won?'BINGO! You completed five lines!':Math.min(lines.length,5)+'/5 lines · '+state.marked.size+' marked';const letters=el.ownerDocument.getElementById(id+'-letters');if(letters){letters.replaceChildren();for(let j=0;j<5;j++){const span=el.ownerDocument.createElement('span');span.textContent='BINGO'[j];span.className=j<lines.length?'earned':'';letters.appendChild(span)}}}
 function execute(fn,id,tile){const ops=functions.get(fn);if(!ops)throw Error('Unknown UI function '+fn);for(const op of ops){let m;
 if((m=/^ui\.text\.set\(([\w-]+),\s*([\s\S]+)\)$/.exec(op))){const el=uiNodes.get(m[1]);if(!el)throw Error('Missing UI element '+m[1]);const q=/^([\"'])([\s\S]*)\1$/.exec(m[2]);if(!q)throw Error('ui.text.set requires quoted text');el.textContent=q[2];continue}
 if((m=/^ui\.class\.(add|remove|toggle)\(([\w-]+),\s*([\w-]+)\)$/.exec(op))){const el=uiNodes.get(m[2]);if(!el)throw Error('Missing UI element '+m[2]);el.classList[m[1]](m[3]);continue}
 if((m=/^ui\.(show|hide)\(([\w-]+)\)$/.exec(op))){const el=uiNodes.get(m[2]);if(!el)throw Error('Missing UI element '+m[2]);el.hidden=m[1]==='hide';continue}
 if((m=/^ui\.value\.set\(([\w-]+),\s*([\s\S]+)\)$/.exec(op))){const el=uiNodes.get(m[1]);if(!el||!('value' in el))throw Error('Missing input '+m[1]);const q=/^([\"'])([\s\S]*)\1$/.exec(m[2]);if(!q)throw Error('ui.value.set requires quoted text');el.value=q[2];continue}
if((m=/^os\.window\.(show|close|minimize|maximize|restore)\(([\w-]+)\)$/.exec(op))){const w=windows.get(m[2]);if(!w)throw Error('Missing window '+m[2]);windowAction(w,m[1]);continue}
 if((m=/^os\.window\.title\(([\w-]+),\s*([\s\S]+)\)$/.exec(op))){const w=windows.get(m[1]);if(!w)throw Error('Missing window '+m[1]);const q=/^([\"'])([\s\S]*)\1$/.exec(m[2]);if(!q)throw Error('Window title must be quoted');w.querySelector('.blure-window-title').textContent=q[2];continue}
 if((m=/^ui\.board\.shuffle\(([\w-]+)\)$/.exec(op))){const state=boardStates.get(m[1]);if(!state)throw Error('Missing board '+m[1]);state.values=Array.from({length:25},(_,i)=>i+1);for(let i=24;i>0;i--){const j=Math.floor(Math.random()*(i+1));[state.values[i],state.values[j]]=[state.values[j],state.values[i]]}state.marked.clear();state.won=false;paint(m[1]);continue}if((m=/^ui\.board\.mark\(([\w-]+)\)$/.exec(op))){const state=boardStates.get(m[1]);if(!state)throw Error('Missing board '+m[1]);if(!state.won&&Number.isInteger(tile)&&state.values.includes(tile)){state.marked.add(tile);state.won=completed(state).length>=5;paint(m[1]);}continue}throw Error('Unsupported UI function instruction: '+op)}}
 for(let i=0;i<rows.length;i++){
  const s=rows[i].trim();if(!s||s.startsWith('//')||s==='close.fn.mn'||/^start\.fn\.mn\(.*\)$/.test(s))continue;let m;
  if((m=/^start\.fn\(([\w-]+)\)$/.exec(s))){const name=m[1],ops=[];let found=false;for(i++;i<rows.length;i++){const cmd=rows[i].trim();if(cmd==='end.fn'){found=true;break}if(cmd&&!cmd.startsWith('//'))ops.push(cmd)}if(!found)fail(i+1,'Missing end.fn');functions.set(name,ops);continue}
  if((m=/^ui\.load\.css\(([\w./-]+\.css)\)$/.exec(s))){const name=m[1];if(name.includes('..')||name.startsWith('/'))fail(i+1,'Invalid CSS path');if(typeof files[name]!=='string')fail(i+1,'Missing CSS file: '+name);activeCss+=files[name]+'\n';continue}
  if((m=/^ui\.(h[1-6]|p|div|span|button|input|textarea|label|section|article|nav|header|footer|main|ul|li)(?:\(([\w-]+)\))?$/.exec(s))){const el=document.createElement(m[1]);if(m[2]){el.id=m[2];el.classList.add(m[2]);uiNodes.set(m[2],el)}current().appendChild(el);if(m[1]!=='input')stack.push(el);continue}
  if((m=/^ui\.end\.(h[1-6]|p|div|span|button|input|textarea|label|section|article|nav|header|footer|main|ul|li)$/.exec(s))){if(stack.length===1||current().tagName.toLowerCase()!==m[1])fail(i+1,'Mismatched UI closing tag');stack.pop();continue}
  if((m=/^ui\.class\(([\w-]+)\)$/.exec(s))){if(stack.length===1)fail(i+1,'ui.class requires an open element');current().classList.add(m[1]);continue}
  if((m=/^ui\.id\(([\w-]+)\)$/.exec(s))){if(stack.length===1)fail(i+1,'ui.id requires an open element');current().id=m[1];uiNodes.set(m[1],current());continue}
  if((m=/^os\.window\.create\(([\w-]+)\)$/.exec(s))){
   if(windows.has(m[1]))fail(i+1,'Duplicate window '+m[1]);
   const w=document.createElement('section');w.id=m[1];w.className='blure-os-window';w.style.left=(20+windows.size*24)+'px';w.style.top=(20+windows.size*24)+'px';
   const bar=document.createElement('div');bar.className='blure-window-bar';
   const title=document.createElement('strong');title.className='blure-window-title';title.textContent=m[1];bar.appendChild(title);
   for(const [action,label] of [['minimize','−'],['maximize','□'],['close','×']]){const btn=document.createElement('button');btn.type='button';btn.dataset.windowAction=action;btn.textContent=label;btn.setAttribute('aria-label',action+' '+m[1]);bar.appendChild(btn)}
   const content=document.createElement('div');content.className='blure-window-content';w.append(bar,content);current().appendChild(w);windows.set(m[1],w);uiNodes.set(m[1],w);stack.push(content);continue;
  }
  if(s==='os.window.end'){if(stack.length===1||!current().classList.contains('blure-window-content'))fail(i+1,'Mismatched os.window.end');stack.pop();continue}
  if((m=/^os\.window\.title\(([\w-]+),\s*([\s\S]+)\)$/.exec(s))){const w=windows.get(m[1]);if(!w)fail(i+1,'Unknown window '+m[1]);const q=/^([\"'])([\s\S]*)\1$/.exec(m[2]);if(!q)fail(i+1,'Window title must be quoted');w.querySelector('.blure-window-title').textContent=q[2];continue}
  if((m=/^os\.window\.(show|close|minimize|maximize|restore)\(([\w-]+)\)$/.exec(s))){const w=windows.get(m[2]);if(!w)fail(i+1,'Unknown window '+m[2]);windowAction(w,m[1]);continue}
  if((m=/^ui\.board\(([\w-]+)\)$/.exec(s))){makeBoard(m[1]);continue}
  if((m=/^ui\.board\.progress\(([\w-]+)\)$/.exec(s))){const el=document.createElement('p');el.id=m[1]+'-progress';el.className='board-progress';current().appendChild(el);continue}
  if((m=/^ui\.board\.letters\(([\w-]+)\)$/.exec(s))){const el=document.createElement('div');el.id=m[1]+'-letters';el.className='board-letters';current().appendChild(el);continue}
  if((m=/^show\((.*)\)$/.exec(s))){const parts=m[1].split(/\s*,\s*/);for(const part of parts){const quoted=/^(["'])([\s\S]*)\1$/.exec(part);if(!quoted)fail(i+1,'UI show supports quoted text only');appendText(current(),quoted[2].replace(/\\n/g,'\n'))}continue}
  if((m=/^ui\.on\.(click|mark|change|input)\(([\w-]+)\)$/.exec(s))){const kind=m[1],id=m[2];let fn='',end=false;for(i++;i<rows.length;i++){const line=rows[i].trim();if(line==='ui.end.'+kind){end=true;break}const call=/^run\.fn\(([\w-]+)\)$/.exec(line);if(call)fn=call[1];else if(line)fail(i+1,'Event block only supports run.fn(name)')}if(!end||!fn)fail(i+1,'Incomplete event block');events.push({kind,id,fn});continue}
  if((m=/^ui\.board\.shuffle\(([\w-]+)\)$/.exec(s))){handlers.push({fn:null,id:m[1],shuffle:true});continue}
  fail(i+1,'Unsupported UI instruction: '+s);
 }
 if(stack.length!==1)throw Error('Unclosed UI element: '+current().tagName.toLowerCase());
 const frame=document.createElement('iframe');frame.title='blure graphical preview';frame.setAttribute('sandbox','allow-same-origin');frame.style.cssText='width:100%;min-height:560px;border:0;background:white;border-radius:12px';
 const systemCss=`.blure-os-window{position:absolute;min-width:220px;width:min(390px,90%);max-width:calc(100% - 12px);background:#fff;color:#242424;border:1px solid #e74691;border-radius:14px;box-shadow:0 14px 38px #0005;overflow:hidden;z-index:1}.blure-window-bar{display:flex;align-items:center;gap:5px;padding:9px;background:#242424;color:white;cursor:grab;touch-action:none;user-select:none}.blure-window-title{flex:1;overflow:hidden;text-overflow:ellipsis}.blure-window-bar button{background:#555;color:white;border:0;border-radius:5px;min-width:28px;min-height:28px;cursor:pointer}.blure-window-content{padding:15px;max-height:70vh;overflow:auto}.blure-os-window.blure-minimized .blure-window-content{display:none}.blure-os-window.blure-maximized{position:fixed!important;inset:0!important;width:100%!important;height:100%!important;max-width:none!important;border-radius:0}.blure-os-window[hidden]{display:none!important}body{min-height:100vh}`;
 const safeCss=(systemCss+'\n'+activeCss).replace(/<\/style/gi,'<\\/style');frame.srcdoc='<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><style>'+safeCss+'</style></head><body></body></html>';
 frame.addEventListener('load',()=>{const doc=frame.contentDocument;if(!doc)return;doc.body.replaceChildren(...Array.from(root.childNodes));for(const [id,w] of windows){const actual=doc.getElementById(id);windows.set(id,actual);wireWindow(actual)}for(const [id,el] of boards)boards.set(id,doc.getElementById(id));for(const [id] of uiNodes)uiNodes.set(id,doc.getElementById(id));for(const e of events){if(e.kind!=='mark'){const target=doc.getElementById(e.id);if(!target)throw Error('Missing event target '+e.id);target.addEventListener(e.kind,()=>{try{execute(e.fn,e.id)}catch(err){get('blure-ui-message').textContent=err.message}})}}for(const h of handlers){if(h.shuffle){const state=boardStates.get(h.id);if(!state)throw Error('Missing board '+h.id);state.values=Array.from({length:25},(_,i)=>i+1);for(let i=24;i>0;i--){const j=Math.floor(Math.random()*(i+1));[state.values[i],state.values[j]]=[state.values[j],state.values[i]]}paint(h.id)}}for(const [id,state] of boardStates){if(!state.values.length){state.values=Array.from({length:25},(_,i)=>i+1);for(let i=24;i>0;i--){const j=Math.floor(Math.random()*(i+1));[state.values[i],state.values[j]]=[state.values[j],state.values[i]]}paint(id)}}});
 return frame;
}
window.BlureUI={render,expandModules};
})();
