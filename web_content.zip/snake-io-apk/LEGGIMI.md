# Snake.io: progetto per creare l'APK

Serve un computer (Windows, Mac o Linux) con Node.js 18+ e Android Studio
(oppure solo JDK 17 e Android SDK da riga di comando).

## Creare l'APK

1. Apri un terminale in questa cartella ed esegui:
   npm install
   npx cap add android
2. Per compilare:
   npm run apk
3. Il file si trova in:
   android/app/build/outputs/apk/debug/app-debug.apk

Alternativa con Android Studio: dopo "npx cap add android" esegui
"npx cap open android", poi menu Build > Build Bundle(s) / APK(s) > Build APK(s).

## Installarlo sul telefono

1. Copia app-debug.apk sul telefono (cavo USB, Drive, email).
2. Aprilo dal telefono e consenti l'installazione da "origini sconosciute" se richiesto.

## Note

- Il gioco e' in www/index.html: se lo modifichi, riesegui "npm run apk".
- L'APK "debug" va bene per uso personale. Per pubblicare sul Play Store serve
  un APK/AAB firmato (Build > Generate Signed Bundle / APK).
- Facoltativo: per bloccare lo schermo in orizzontale aggiungi
  android:screenOrientation="sensorLandscape" all'activity in
  android/app/src/main/AndroidManifest.xml.
