DEEPAK10 MATH CHALLENGE — UPDATED
==================================
फाइल: index.html

चलाने का तरीका:
1. ZIP डाउनलोड करके Extract करें।
2. index.html को मोबाइल के ब्राउज़र/HTML Viewer में खोलें।
3. सवाल का A/B/C/D उत्तर चुनें। सही उत्तर पर 10 अंक मिलेंगे।

शेयर करने योग्य वेबसाइट लिंक:
1. github.com पर लॉगिन करें और public repository deepak10-math-game बनाएं।
2. index.html अपलोड करके Commit करें।
3. Settings > Pages > Deploy from a branch चुनें।
4. Branch main और folder /(root) चुनकर Save करें।
5. कुछ मिनट बाद GitHub Pages URL देगा।

ध्यान दें:
- यह गेम ID Deepak10 को प्रोफाइल लेबल की तरह दिखाता है, असली सुरक्षित लॉगिन नहीं।
- स्कोर और बेस्ट स्कोर उसी ब्राउज़र के local storage में सेव हो सकते हैं।
- दूसरे फोन पर स्कोर अपने-आप सिंक नहीं होगा।
