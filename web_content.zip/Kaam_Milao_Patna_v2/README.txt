KAAM MILAO – PATNA MVP PROTOTYPE v2

Included:
- Responsive Hindi-first web demo
- Combined jobs/staff hiring and local service requests
- Provider profile registration
- Patna locality fields
- Demo listings and basic admin summary
- Proposed fee display: customer ₹10 + provider ₹20 (NOT final; illustrative only)
- Browser localStorage only; export/clear demo data

Important:
This is not a production marketplace and does not collect real payments or verify users.
Before public launch, implement:
1. Backend database (Firebase/Supabase or custom API) with access rules
2. OTP authentication and abuse prevention
3. Private admin authentication and moderation
4. Payment provider onboarding, payment receipts, refund/dispute policy
5. Consent, privacy policy, terms, grievance and safety workflows
6. Provider verification, reviews/reporting and phone-number privacy
7. Android app packaging (e.g. Capacitor/React Native) and production hosting

Fee proposal is a placeholder, not a payment instruction. Confirm the exact charging trigger
(e.g. successful contact unlock vs completed job) and refund rules before enabling fees.
