# CGD — Étapes 6.1 et 6.2 : écrans 01 (démarrage) et 02 (menu principal), disposition FM27

- Écran 01 : logo CGD, titre, barre de chargement et « Chargement de l'univers… » ; il passe tout seul au menu après environ 2,6 s (0,6 s si l'appareil demande moins d'animations) ou à un appui / une touche. Il ne s'affiche qu'à l'ouverture du jeu, pas à chaque retour au menu.
- Écran 02 : barre de raccourcis à gauche (Paramètres, Aide, Quitter), « MENU PRINCIPAL » avec Continuer (affiche le manager et le club de la dernière carrière, grisé sans carrière), Nouvelle carrière, Charger une sauvegarde, Paramètres, Quitter, et un damier doré en décor à droite.
- Comportements inchangés : confirmation avant de remplacer une carrière existante, chargement de l'emplacement enregistré, message de sauvegarde automatique pour Quitter.
- Fond clair (dégradé bleu-gris et cartes blanches à liseré doré), identique aux écrans 03 à 10 ; damier de décor aux couleurs du damier du match.
- Vérifié en 895 × 393 et 844 × 390, plein écran, sans défilement.
- Code : `index.html` (écran de lancement et script), styles dans le bloc `fm27-terrain`.
- Écart avec la maquette : la barre de raccourcis n'a que trois boutons réels (Paramètres, Aide, Quitter) ; la maquette montrait aussi une icône de messages, inutile avant une carrière.
