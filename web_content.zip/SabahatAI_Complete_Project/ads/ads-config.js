/* AdSense setup: fill these only after Google approves your site.
 * Never paste API keys or account passwords here. Publisher ID is not a secret,
 * but it must be your own verified ca-pub-... ID. Ad slot IDs are created in AdSense.
 */
window.SABAHAT_ADS = {
  enabled: false,
  publisherId: "",
  responsiveSlotId: ""
};
(function () {
  const cfg = window.SABAHAT_ADS;
  if (!cfg || cfg.enabled !== true || !/^ca-pub-\d+$/.test(cfg.publisherId) || !/^\d+$/.test(cfg.responsiveSlotId)) return;
  const script = document.createElement("script");
  script.async = true;
  script.crossOrigin = "anonymous";
  script.src = "https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=" + encodeURIComponent(cfg.publisherId);
  script.onload = function () {
    document.querySelectorAll("[data-sabahat-ad-slot]").forEach(function (node) {
      node.setAttribute("data-ad-client", cfg.publisherId);
      node.setAttribute("data-ad-slot", cfg.responsiveSlotId);
      node.innerHTML = "";
      node.classList.remove("ad-placeholder");
      try { (window.adsbygoogle = window.adsbygoogle || []).push({}); } catch (_) {}
    });
  };
  document.head.appendChild(script);
})();
