# Google AdSense setup (Roman Urdu)

Yeh project sirf AdSense integration ka **safe placeholder** rakhta hai. Ads default mein band hain.

1. Apni website ko apne domain par publish karein aur Google AdSense mein site add/verify karein.
2. Site review aur approval ka intezar karein. Code lagane se approval guarantee nahi hoti.
3. AdSense dashboard se apna Publisher ID (`ca-pub-...`) aur responsive ad unit ka numeric Slot ID lein.
4. `ads/ads-config.js` mein `enabled: true`, `publisherId` aur `responsiveSlotId` apni asli values se set karein.
5. `ads/ads-config.js` ko page mein include karein aur jahan ad chahiye wahan `<ins class="adsbygoogle" data-sabahat-ad-slot style="display:block" data-ad-format="auto" data-full-width-responsive="true"></ins>` rakhein.
6. Privacy policy ko apni asal data/AI/advertising practices ke mutabiq update karein. Zaroorat ke mutabiq consent-management solution bhi lagayein.
7. `ads.txt` root par publish karna ho to AdSense dashboard se exact line copy karein. `ads/ads.txt.template` sirf template hai; isay bina apni publisher details ke live `ads.txt` na banayein.

Important: AdSense website/PWA ke liye hai. Native Android app ke andar ads dikhane ke liye Google AdMob SDK aur alag setup/policy review chahiye. AdSense code APK ke andar ads chalane ka replacement nahi.
