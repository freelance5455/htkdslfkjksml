SABAHAT AI — COMPLETE PROJECT STARTER (v1.0)
==============================================

Fraz, yeh project aapki UI/UX Pro Max ZIP ke design-system principles ko follow karte hue banaya gaya hai:
- Consistent design tokens / colors, component states, typography, spacing and responsive layouts
- Branded splash screen and original SVG logo, PNG app icons
- Home, Actions, Chat, Settings tabs; keyboard/touch states; responsive mobile-first layout
- Service worker + PWA manifest for caching local files
- Offline local commands: greetings, time/date, help and supported links
- Online AI connector through a PHP backend; secret key server environment mein hi rehti hai
- Optional Python + Ollama local-model bridge for a computer/local server
- SVG assets for logo, avatar, navigation and action icons

IMPORTANT — HONEST CAPABILITY LIST
----------------------------------
Yeh ek complete SOURCE PROJECT STARTER hai, lekin compiled Android APK ya fully integrated on-device AI model nahin hai.
Offline:
- UI assets/files once cached hone ke baad khul sakte hain (HTTPS hosting ke baad).
- Basic commands (time/date/help/greetings) local JavaScript mein chalti hain.
- Online LLM response, internet ke baghair available nahin hota.
- Browser speech recognition offline hone ki guarantee nahin; speech synthesis phone/browser ki installed voices par depend karti hai.
- Full private/offline AI brain + Urdu/Punjabi speech recognition + neural expressive voice phone par chalane ke liye Android native integration aur model files chahiye. Is package mein woh models bundled nahin hain.
Online:
- Chat PHP endpoint tabhi AI reply dega jab aap apne hosting server par API key configure karenge.
- API key ko kabhi app.js, HTML, public ZIP ya GitHub repo mein mat likhein.
- API provider paid ho sakta hai. Free/paid provider ki availability, quota aur policies provider par depend karti hain.
Phone actions:
- Web/PWA browser arbitrary apps ko guaranteed open, notifications read, SMS/calls control, background wake word, alarm set ya device settings change nahin kar sakti.
- Is ke liye native Android Kotlin project, Android permissions, foreground service and notification listener required hain.
- Never grant notification/call permissions to unknown builds; review privacy and test on your own device.

FOLDER MAP
----------
index.html                     App UI
style.css                      Design system + responsive styles
app.js                         PWA logic, basic offline commands, optional online API
manifest.json                  Installable PWA metadata + icons
sw.js                          Cache strategy for offline app shell
assets/icons/sabahat.svg       Brand logo
assets/icons/icon-192.png      PWA icon
assets/icons/icon-512.png      PWA icon
assets/icons/*.svg             Individual UI icons
assets/images/sabahat-avatar.svg Original avatar illustration
backend/api/chat.php           Optional secure online AI endpoint
backend/config/.env.example    Example ONLY; no real secret included
python/app.py                  Optional local Ollama bridge (computer/local server)
docs/                          Design/build/security notes

HOW TO PREVIEW ON PHONE
-----------------------
1. Download this ZIP and extract it using your phone's file manager / ZArchiver.
2. To preview UI only, open index.html in a browser. Some browser features (PWA install, service worker, voice recognition) require HTTPS/localhost.
3. To install as a PWA and test offline caching, publish this folder to an HTTPS static host (GitHub Pages/Netlify/etc.) and open that URL in Chrome > menu > Add to Home screen.
4. PWA does NOT become a native APK. A native Android build requires Android project tooling/build process.

HOW TO ENABLE ONLINE AI (OPTIONAL)
----------------------------------
1. Host the project on HTTPS and host backend/ on a PHP server with cURL + mbstring enabled.
2. Configure environment variables in hosting dashboard from backend/config/.env.example:
   SABAHAT_API_KEY = your provider key (SERVER ONLY)
   SABAHAT_API_BASE_URL = provider's OpenAI-compatible API base URL
   SABAHAT_MODEL = model available to your provider account
   SABAHAT_ALLOWED_ORIGIN = your exact website origin, e.g. https://example.com
3. Update CONFIG.onlineEndpoint in app.js to your deployed endpoint, e.g. https://example.com/backend/api/chat.php
4. Set Settings > Assistant mode > Online AI. Do not expose keys in frontend.
5. Use HTTPS, rate limits, server logs without storing sensitive chat text, and a budget cap. Do not publish a public endpoint without abuse controls.
6. The provided PHP endpoint uses a generic OpenAI-compatible chat/completions API format. Not every provider is compatible; adapt it to your chosen provider.

OPTIONAL LOCAL AI BRIDGE (COMPUTER ONLY)
----------------------------------------
This is for testing on a computer or local server, not a standalone Android service.
1. Install Python 3.10+ and Ollama from their official sources.
2. Download a local model in Ollama, for example: ollama run qwen2.5:1.5b
   Model download needs internet/storage initially; afterwards local inference can work offline.
3. In a terminal, run: python python/app.py
4. Serve the web project on localhost port 8000 (example command from project root: python -m http.server 8000).
5. For local testing, change CONFIG.onlineEndpoint in app.js to http://127.0.0.1:8765/chat. If the browser enforces CORS, configure allowed origin in python/app.py to match the page origin.
6. A phone cannot normally access 127.0.0.1 on a separate computer as that means the phone itself. Use a trusted LAN address only on a private network and adjust CORS/firewall securely.

WHAT IS STILL REQUIRED FOR A TRUE NATIVE OFFLINE/ONLINE ANDROID APP
-------------------------------------------------------------------
- Android Studio/Gradle native Kotlin project and build/signing
- On-device inference runtime + suitable quantized GGUF model (device memory/speed tests)
- Bundled offline ASR model and Urdu/Punjabi/English accuracy tests
- Offline neural TTS voice model; emotion control only if the model supports it
- Android app-launch intents and alarm intents
- Notification listener only after explicit user-granted access
- Foreground service / battery optimization and wake-word privacy UX
- Runtime permissions, privacy policy, error handling, accessibility tests, crash testing
- Download model files separately; they are not included in this ZIP due to size/licensing/device constraints.

This package is not advertised as a finished APK. It gives you a structured, branded, usable PWA source with an online backend scaffold and an optional local model bridge. Test everything before relying on it.

NATIVE ANDROID ALPHA (NEW)
--------------------------
The `android-native/` folder now contains a Kotlin/Gradle starter for a movable floating girl logo, foreground notification, tap-to-speak, basic Android intents and spoken replies. Open this folder in Android Studio to build. This native scaffold has NOT been built or tested on a real phone in this environment. It is not a finished APK and does not include offline Urdu/Punjabi ASR, a custom emotional voice, a bundled local LLM, always-on wake word, or arbitrary AI-controlled actions. Read `android-native/README_UR.md` before testing.

ADSENSE (NEW)
-------------
`ads/ADSENSE_SETUP_UR.md` explains how to enable AdSense after site approval. Ads are OFF by default. Fill only your real publisher/ad-slot IDs after approval. AdSense is for website/PWA ads; native Android ads require AdMob SDK and a separate policy-compliant integration. Update `privacy/index.html` to reflect actual data processing before publishing.
