plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.fraz.sabahat.ai"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.fraz.sabahat.ai"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0-alpha"
    }
}
