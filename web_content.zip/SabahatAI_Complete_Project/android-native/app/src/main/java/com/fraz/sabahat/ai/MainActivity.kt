package com.fraz.sabahat.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val requestAudio = 410
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(8, 9, 20)
        window.navigationBarColor = android.graphics.Color.rgb(8, 9, 20)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(32, 42, 32, 32); setBackgroundColor(android.graphics.Color.rgb(8, 9, 20))
        }
        val logo = android.widget.ImageView(this).apply { setImageResource(R.drawable.sabahat_avatar); layoutParams = LinearLayout.LayoutParams(150,150).apply { bottomMargin = 18 } }
        val title = TextView(this).apply { text = "SABAHAT AI"; textSize = 27f; setTextColor(0xFFFFA9E6.toInt()); gravity = Gravity.CENTER }
        val info = TextView(this).apply { text = "Floating girl logo • Voice commands • Spoken replies\n\nAllow microphone only when you want to speak. Android may stop background work on some devices."; textSize = 15f; setTextColor(0xFFE8E2FF.toInt()); gravity = Gravity.CENTER; setPadding(0,20,0,24) }
        val start = Button(this).apply { text = "Enable floating logo"; setOnClickListener { enableAssistant() } }
        val stop = Button(this).apply { text = "Stop assistant"; setOnClickListener { stopService(Intent(this@MainActivity, FloatingAssistantService::class.java)); Toast.makeText(this@MainActivity,"Sabahat stopped",Toast.LENGTH_SHORT).show() } }
        root.addView(logo); root.addView(title); root.addView(info); root.addView(start, LinearLayout.LayoutParams(-1,-2)); root.addView(stop, LinearLayout.LayoutParams(-1,-2))
        setContentView(root)
    }
    private fun enableAssistant() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this,"Allow ‘Display over other apps’, then tap Enable again",Toast.LENGTH_LONG).show(); return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), requestAudio); return
        }
        startAssistantService()
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == requestAudio && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startAssistantService()
        else Toast.makeText(this,"Microphone permission is needed for voice commands",Toast.LENGTH_LONG).show()
    }
    private fun startAssistantService() {
        val i = Intent(this, FloatingAssistantService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        Toast.makeText(this,"Sabahat floating logo enabled",Toast.LENGTH_SHORT).show()
    }
}
