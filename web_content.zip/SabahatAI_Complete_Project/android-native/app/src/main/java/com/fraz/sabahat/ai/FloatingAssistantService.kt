package com.fraz.sabahat.ai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.ImageView
import android.widget.Toast
import java.util.Locale

class FloatingAssistantService : Service(), TextToSpeech.OnInitListener {
    private lateinit var wm: WindowManager
    private var bubble: ImageView? = null
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var listening = false
    private var params: WindowManager.LayoutParams? = null
    private val channelId = "sabahat_assistant"

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) startForeground(44, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(44, notification)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        tts = TextToSpeech(this, this)
        showBubble()
    }
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onInit(status: Int) { ttsReady = status == TextToSpeech.SUCCESS; if (ttsReady) tts?.language = Locale("ur", "PK") }

    private fun showBubble() {
        if (bubble != null) return
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val p = WindowManager.LayoutParams(66, 66, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 18; y = 220 }
        params = p
        val image = ImageView(this).apply { setImageResource(R.drawable.sabahat_avatar); scaleType = ImageView.ScaleType.CENTER_CROP; background = getDrawable(android.R.drawable.dialog_holo_light_frame); contentDescription = "Tap to talk to Sabahat"; setPadding(3,3,3,3) }
        var startX = 0; var startY = 0; var touchX = 0f; var touchY = 0f; var dragged = false
        image.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { startX = p.x; startY = p.y; touchX = event.rawX; touchY = event.rawY; dragged = false; true }
                MotionEvent.ACTION_MOVE -> { val dx = (event.rawX-touchX).toInt(); val dy = (event.rawY-touchY).toInt(); if (kotlin.math.abs(dx)>5 || kotlin.math.abs(dy)>5) dragged = true; p.x = startX+dx; p.y = startY+dy; try { wm.updateViewLayout(image,p) } catch (_: Exception) {}; true }
                MotionEvent.ACTION_UP -> { if (!dragged) toggleListening(); true }
                else -> true
            }
        }
        try { wm.addView(image,p); bubble = image } catch (e: Exception) { Toast.makeText(this,"Floating logo permission missing",Toast.LENGTH_LONG).show(); stopSelf() }
    }
    private fun toggleListening() { if (listening) stopListening() else startListening() }
    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { speak("Is device par speech recognition available nahi hai."); return }
        try {
            recognizer?.destroy()
            recognizer = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: android.os.Bundle?) { listening = true; bubble?.alpha = 0.65f }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { listening = false; bubble?.alpha = 1f }
                override fun onError(error: Int) { listening = false; bubble?.alpha = 1f; if (error != SpeechRecognizer.ERROR_NO_MATCH && error != SpeechRecognizer.ERROR_SPEECH_TIMEOUT) speak("Awaaz samajh nahi aayi. Dobara koshish karein.") }
                override fun onResults(results: android.os.Bundle?) { listening = false; bubble?.alpha = 1f; val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty(); if (text.isNotBlank()) handleCommand(text) }
                override fun onPartialResults(partialResults: android.os.Bundle?) {}
                override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
            })
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply { putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ur-PK"); putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ur-PK"); putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false) }
            recognizer?.startListening(i)
        } catch (_: Exception) { listening = false; speak("Voice service start nahi ho saka.") }
    }
    private fun stopListening() { try { recognizer?.cancel() } catch (_: Exception) {}; listening = false; bubble?.alpha = 1f }
    private fun handleCommand(raw: String) {
        val q = raw.lowercase(Locale.ROOT)
        when {
            q.contains("youtube") -> openPackageOrWeb("com.google.android.youtube", "https://www.youtube.com", "YouTube khol rahi hoon")
            q.contains("whatsapp") -> openPackageOrWeb("com.whatsapp", "https://www.whatsapp.com", "WhatsApp khol rahi hoon")
            q.contains("camera") || q.contains("कैमरा") -> launchIntent(Intent("android.media.action.IMAGE_CAPTURE"), "Camera kholne ki koshish kar rahi hoon")
            q.contains("alarm") || q.contains("clock") -> handleAlarmCommand(raw)
            q.contains("browser") || q.contains("google") || q.contains("internet") -> openUrl("https://www.google.com", "Browser khol rahi hoon")
            q.contains("time") || q.contains("waqt") || q.contains("kitne baj") -> speak("Abhi waqt ${java.text.SimpleDateFormat("hh:mm a", Locale.getDefault()).format(java.util.Date())} hai.")
            q.contains("stop") || q.contains("band") -> { speak("Theek hai, main sunna band kar rahi hoon."); stopListening() }
            else -> speak("Aap ne kaha: $raw. Is command ke liye AI connection ya naya action integrate karna hoga.")
        }
    }

    private fun handleAlarmCommand(raw: String) {
        val q = raw.lowercase(Locale.ROOT)
        val match = Regex("\\b(\\d{1,2})(?::(\\d{2}))?\\b").find(q)
        if (match == null) { launchIntent(Intent(android.provider.AlarmClock.ACTION_SHOW_ALARMS), "Clock khol rahi hoon"); return }
        var hour = match.groupValues[1].toIntOrNull() ?: 7
        val minute = match.groupValues.getOrNull(2)?.toIntOrNull() ?: 0
        if ((q.contains("pm") || q.contains("shaam") || q.contains("evening") || q.contains("raat")) && hour in 1..11) hour += 12
        if ((q.contains("am") || q.contains("subah") || q.contains("morning")) && hour == 12) hour = 0
        if (hour !in 0..23 || minute !in 0..59) { speak("Alarm ka waqt samajh nahi aaya. Misal ke taur par alarm 7 baje bolein."); return }
        val intent = Intent(android.provider.AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(android.provider.AlarmClock.EXTRA_HOUR, hour)
            putExtra(android.provider.AlarmClock.EXTRA_MINUTES, minute)
            putExtra(android.provider.AlarmClock.EXTRA_MESSAGE, "Sabahat AI reminder")
            putExtra(android.provider.AlarmClock.EXTRA_SKIP_UI, false)
        }
        launchIntent(intent, "Alarm ${String.format(Locale.getDefault(), "%02d:%02d", hour, minute)} ke liye set karne ka screen khol rahi hoon")
    }

    private fun openPackageOrWeb(pkg: String, url: String, reply: String) {
        speak(reply)
        val launch = packageManager.getLaunchIntentForPackage(pkg)
        if (launch != null) { launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); try { startActivity(launch) } catch (_: Exception) { openUrl(url, reply) } }
        else openUrl(url, reply)
    }
    private fun openUrl(url: String, reply: String) { speak(reply); try { startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { speak("Browser open nahi ho saka.") } }
    private fun launchIntent(i: Intent, reply: String) { speak(reply); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); try { startActivity(i) } catch (_: Exception) { speak("Yeh feature is device par available nahi.") } }
    private fun speak(text: String) { if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "sabahat-${System.currentTimeMillis()}") else Toast.makeText(this,text,Toast.LENGTH_SHORT).show() }
    private fun createNotificationChannel() { if (Build.VERSION.SDK_INT >= 26) { val channel = NotificationChannel(channelId,"Sabahat AI assistant",NotificationManager.IMPORTANCE_LOW).apply { description = "Shows when the floating voice assistant is active" }; (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel) } }
    @Suppress("DEPRECATION")
    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(this,0,Intent(this,MainActivity::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this,channelId).setContentTitle("Sabahat AI is active").setContentText("Tap the floating girl logo to speak • Tap notification to manage").setSmallIcon(R.drawable.sabahat_avatar).setContentIntent(open).setOngoing(true).build()
        else Notification.Builder(this).setContentTitle("Sabahat AI is active").setContentText("Tap the floating girl logo to speak").setSmallIcon(R.drawable.sabahat_avatar).setContentIntent(open).build()
    }
    override fun onDestroy() { stopListening(); try { bubble?.let { wm.removeView(it) } } catch (_: Exception) {}; bubble = null; recognizer?.destroy(); recognizer = null; tts?.stop(); tts?.shutdown(); super.onDestroy() }
}
