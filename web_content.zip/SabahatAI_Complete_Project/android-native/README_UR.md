# Sabahat AI Native Android — Alpha source

Yeh Kotlin/Gradle native Android scaffold hai jo PWA se alag hai. Is mein:
- Floating girl-avatar overlay, drag-and-drop positioning
- Foreground service notification while active
- Tap-to-speak using Android `SpeechRecognizer`
- Text-to-speech replies using the device's installed voice
- Basic app actions: YouTube, WhatsApp, browser, camera intent, Clock alarms screen, time
- Start/stop controls and runtime permission flow

## Build
1. Android Studio (JDK 17 compatible) mein `android-native` folder open karein.
2. Gradle sync complete hone dein.
3. Emulator ya apne Android device par run karein.
4. App open karke `Enable floating logo` tap karein, overlay permission allow karein, phir microphone permission allow karein.
5. Floating avatar ko drag karein; tap karke command bolein. `Stop assistant` service aur bubble band karta hai.

## Important limitations — alpha, not production
- Is source ka Android Studio/Gradle build abhi is environment mein run nahi hua; device test aap ke Android Studio mein zaroori hai.
- Android speech recognition provider/device par depend karti hai aur internet maang sakti hai. **Offline Urdu/Punjabi recognition bundled nahi hai.**
- TTS device ki installed voices use karti hai; custom natural/emotional Sabahat voice bundled nahi.
- Sirf listed commands implement kiye gaye hain. Arbitrary request ko AI samajhne ke liye secure backend/local model integration chahiye.
- `START_STICKY` Android ko service restart ki request deta hai, guarantee nahi. Force Stop, battery management, OS/OEM policies service ko rok sakti hain. Recent Apps clear karne par behavior device-specific hai.
- Wake-word listening always-on nahi hai. Tap-to-speak is alpha's privacy-first behavior.
- Calls/messages ko silently execute karna implement nahi hai; sensitive actions should ask confirmation and use proper intents/permissions.
- `QUERY_ALL_PACKAGES` permission intentionally use nahi ki; app visibility is limited to declared package queries.
- Before release add launcher icon resources, adaptive icon, notification icon, tests, privacy/consent UX, crash handling, accessibility checks, signed release build, and current Play policy review.

Do not claim this alpha is a fully autonomous assistant or fully offline AI. No API key is embedded.
