/* Sabahat AI PWA starter. No secret keys belong in this file. */
const $ = id => document.getElementById(id);
let active = false, recognition = null, deferredInstall = null;
const CONFIG = {
  // Set this to your deployed HTTPS backend URL, e.g. https://your-domain.com/backend/api/chat.php
  // Keep provider API keys on the server only, in environment variables.
  onlineEndpoint: "./backend/api/chat.php",
  appName: "Sabahat AI"
};
const status = t => { if ($("statusText")) $("statusText").textContent = t; };
const getMode = () => localStorage.getItem("sabahat-mode") || "auto";
const getLang = () => localStorage.getItem("sabahat-lang") || "auto";
const isOnline = () => navigator.onLine;
function updateModeUI() {
  const mode = getMode(), badge = $("modeBadge");
  if (badge) badge.innerHTML = `<b></b> ${mode === "offline" ? "OFFLINE MODE" : mode === "online" ? (isOnline() ? "ONLINE AI" : "ONLINE UNAVAILABLE") : (isOnline() ? "AUTO · ONLINE READY" : "OFFLINE READY")}`;
  if ($("modeSelect")) $("modeSelect").value = mode;
  if ($("languageSelect")) $("languageSelect").value = getLang();
}
function addBubble(text, who="bot") {
  const el = document.createElement("div"); el.className = "bubble " + who;
  const tag = document.createElement("small"); tag.textContent = who === "bot" ? "SABAHAT" : "YOU";
  el.append(tag, document.createTextNode(String(text)));
  $("chat").append(el); $("chat").scrollTop = $("chat").scrollHeight;
}
function selectedVoiceLang(text="") {
  const chosen = getLang();
  if (chosen !== "auto") return chosen;
  if (/[\u0600-\u06FF]/.test(text)) return "ur-PK";
  if (/\b(punjabi|paaji|ki haal|tusi|sat sri)\b/i.test(text)) return "pa-IN";
  return "en-US";
}
function speak(text) {
  try {
    if (!("speechSynthesis" in window)) return;
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = selectedVoiceLang(text); u.rate = .94; u.pitch = 1.08;
    const voices = speechSynthesis.getVoices();
    const match = voices.find(v => v.lang.toLowerCase() === u.lang.toLowerCase()) ||
      voices.find(v => v.lang.toLowerCase().startsWith(u.lang.split("-")[0]));
    if (match) u.voice = match;
    speechSynthesis.speak(u);
  } catch (_) {}
}
function reply(text, options={}) {
  addBubble(text, "bot");
  if (options.speak !== false) speak(text);
  if ($("hint")) $("hint").textContent = text.length > 70 ? text.slice(0,67)+"…" : text;
}
async function onlineChat(message) {
  if (!isOnline()) throw new Error("Internet available nahi. Offline mode mein basic commands chal sakti hain.");
  const res = await fetch(CONFIG.onlineEndpoint, {
    method:"POST", headers:{"Content-Type":"application/json"},
    body:JSON.stringify({message, language:getLang()})
  });
  const data = await res.json().catch(()=>({}));
  if (!res.ok) throw new Error(data.error || "Online AI server configure nahi hai.");
  if (!data.reply) throw new Error("Server se jawab nahi mila.");
  return data.reply;
}
function openLink(url, label) {
  reply(label + " khol rahi hoon.");
  const w = window.open(url, "_blank", "noopener");
  if (!w) location.href = url;
}
function localCommand(raw) {
  const q = raw.toLowerCase().trim();
  if (!q) return {handled:true, text:""};
  if (/^(hi|hello|salam|assalam|assalamu|salaam)\b/.test(q) || /السلام|سلام/.test(q))
    return {handled:true,text:"Wa alaikum assalam! Main Sabahat hoon. Aap ko kis cheez mein madad chahiye?"};
  if (/what can you do|help|madad|kya kar sakti|kya kar sakte/.test(q))
    return {handled:true,text:"Main offline time/date batati hoon, basic commands samajhti hoon aur supported links khol sakti hoon. Online AI ke liye backend endpoint aur server par API key configure honi chahiye. Phone ki notifications, calls aur alarms ke liye native Android app aur permissions chahiye."};
  if (/time|waqt|kitne baj/.test(q))
    return {handled:true,text:"Aap ke phone par abhi " + new Date().toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"}) + " hain."};
  if (/date|tareekh|today|aaj ki date/.test(q))
    return {handled:true,text:"Aaj " + new Date().toLocaleDateString("ur-PK",{weekday:"long",year:"numeric",month:"long",day:"numeric"}) + " hai."};
  if (/open youtube|youtube kholo|youtube khol/.test(q)) {openLink("https://www.youtube.com","YouTube");return {handled:true,spoken:true};}
  if (/open whatsapp|whatsapp kholo|whatsapp khol/.test(q)) {openLink("https://wa.me/","WhatsApp");return {handled:true,spoken:true};}
  if (/open browser|open google|browser kholo|internet kholo/.test(q)) {openLink("https://www.google.com","Browser");return {handled:true,spoken:true};}
  if (/open camera|camera kholo/.test(q)) return {handled:true,text:"Web app har Android phone par Camera app ko direct launch nahi kar sakti. Apne phone ka Camera icon tap karein. Native Android version mein is action ko add kiya ja sakta hai."};
  if (/alarm|remind|alarm lagao/.test(q)) {
    if (/Android/i.test(navigator.userAgent)) { location.href="intent://#Intent;action=android.intent.action.SHOW_ALARMS;end"; return {handled:true,spoken:true}; }
    return {handled:true,text:"Alarm set karne ke liye apne phone ki Clock app kholein. Browser website ko alarm set karne ki system permission nahi hoti."};
  }
  if (/stop|band karo|chup|quiet/.test(q)) {try{speechSynthesis.cancel()}catch(_){};stopListening();return {handled:true,text:"Theek hai, main ruk gayi."};}
  return {handled:false};
}
async function command(raw) {
  const q=String(raw||"").trim(); if (!q) return;
  const local=localCommand(q);
  if (local.handled) { if(local.text) reply(local.text); return; }
  const mode=getMode();
  if (mode==="offline") { reply("Offline mode mein is sawal ka local jawab available nahi. Basic commands try karein ya Settings mein Auto/Online AI select karein."); return; }
  if (!isOnline()) { reply("Internet band hai. Main abhi basic offline commands hi kar sakti hoon."); return; }
  status("ASKING ONLINE AI…");
  try { const answer=await onlineChat(q); reply(answer); }
  catch(e) { reply("Online AI abhi ready nahi: "+e.message+" Basic offline commands phir bhi chalti hain."); }
  finally { updateModeUI(); status("READY WHEN YOU ARE"); }
}
function stopListening() {
  active=false;
  try { if(recognition) recognition.stop(); } catch(_){}
  $("listening")?.classList.remove("show"); $("power")?.classList.remove("active");
  if($("powerLabel")) $("powerLabel").textContent="TAP TO TALK";
  if($("powerIcon")) $("powerIcon").textContent="▶";
  status("READY WHEN YOU ARE");
}
function startListening() {
  const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
  if(!SR){ reply("Is browser mein speech recognition available nahi. Message neeche type kar dein.");active=false;return; }
  try {
    recognition=new SR(); recognition.lang=getLang()==="auto"?"ur-PK":getLang();
    recognition.continuous=false; recognition.interimResults=false;
    recognition.onstart=()=>{$("listening")?.classList.add("show");$("listening").textContent="Sun rahi hoon… / I'm listening";status("LISTENING");$("power").classList.add("active");$("powerLabel").textContent="TAP TO STOP";$("powerIcon").textContent="■";};
    recognition.onresult=e=>{const t=e.results[0][0].transcript;addBubble(t,"user");command(t);};
    recognition.onerror=e=>{if(e.error!=="no-speech"&&e.error!=="aborted")addBubble("Voice input issue: "+e.error+". Aap message type kar sakte hain.");};
    recognition.onend=()=>{if(active)stopListening();};
    recognition.start();
  } catch(e) { active=false; reply("Voice start nahi ho saki. Browser permission check karein ya text type karein.");stopListening(); }
}
$("power")?.addEventListener("click",()=>{if(active){stopListening();return;}active=true;startListening();});
document.querySelectorAll("[data-cmd]").forEach(b=>b.addEventListener("click",()=>{const t=b.dataset.cmd;addBubble(t,"user");command(t);}));
$("sendForm")?.addEventListener("submit",e=>{e.preventDefault();const v=$("message").value.trim();if(!v)return;$("message").value="";addBubble(v,"user");command(v);});
$("clear")?.addEventListener("click",()=>{$("chat").replaceChildren();addBubble("Conversation cleared. Main yahin hoon.");});
$("settings")?.addEventListener("click",()=>{document.querySelector('[data-tab="settings"]')?.click();});
$("modeSelect")?.addEventListener("change",e=>{localStorage.setItem("sabahat-mode",e.target.value);updateModeUI();});
$("languageSelect")?.addEventListener("change",e=>{localStorage.setItem("sabahat-lang",e.target.value);updateModeUI();});
window.addEventListener("online",updateModeUI);window.addEventListener("offline",updateModeUI);updateModeUI();
if("serviceWorker" in navigator) window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredInstall=e;$("installBanner").hidden=false;});
$("installBtn")?.addEventListener("click",async()=>{if(!deferredInstall)return;deferredInstall.prompt();await deferredInstall.userChoice;deferredInstall=null;$("installBanner").hidden=true;});
