# Native Android next steps (Roman Urdu)

1. Android Studio mein Kotlin project banayein; package id `com.fraz.sabahat`.
2. PWA UI ko native WebView wrapper mein load karne se pehle offline assets local bundle karein, ya UI ko native Compose mein recreate karein.
3. Offline model: compatible Android inference runtime + quantized model; RAM, thermal throttling aur storage test karein.
4. Speech recognition: offline model aur language packs install/download; Urdu, Punjabi, English test.
5. Voice output: offline neural TTS model; voice model licensing and device compatibility verify.
6. Add app launching intents, alarm intents and optional notification listener with explicit permission education.
7. Add foreground service only with clear persistent notification and user-controlled stop.
8. Test airplane mode, no permission, low storage, app killed, battery saver, screen locked, and Android versions.
9. Build/sign APK with Gradle; never promise that PWA ZIP alone creates APK.
