# Sabahat AI UI/UX design system

## Principles adapted from the provided UI/UX Pro Max skill
- Token-based design: color primitives and semantic roles are consistently applied.
- Reusable components: action tiles, tabs, status pills, setting rows, chat bubbles.
- State variants: active tab, listening button, online/offline status, disabled/unavailable messaging.
- Mobile-first responsive spacing and touch-friendly targets.
- Branded identity: consistent S-gradient, iconography, typography, splash and app icons.
- Clear status and honest affordances; actions that require native permissions are explained.

## Color tokens
- Background: `#080914`
- Panel: `#121426`
- Raised panel: `#17182F`
- Primary accent: `#A08AFF`
- Pink accent: `#FF83CE`
- Cyan accent: `#83EAF1`
- Success: `#70EFC0`
- Text: `#F7F4FF`
- Muted: `#9998B8`

## Type and layout
- Space Grotesk for display/brand; DM Sans for interface (system fallbacks included).
- 8/10/12/16/20/24 spacing rhythm.
- 44px minimum primary interaction surfaces where practical.
- Rounded cards and focusable native controls.
- Reduced-motion preference respected.
