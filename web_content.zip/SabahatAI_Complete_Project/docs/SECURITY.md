# Security checklist
- Never ship provider secrets in browser JavaScript, HTML, a ZIP, or Git repository.
- Set API keys as server environment variables.
- Use HTTPS in production.
- Add server-side rate limiting, authentication/abuse prevention, and spending limits before public launch.
- Avoid storing private chat transcripts unless users consent.
- Review privacy policy before using speech recognition; browser providers may process audio remotely.
- Keep notification access opt-in and explain exactly what data is read.
- Do not treat the PWA as having native device permissions.
