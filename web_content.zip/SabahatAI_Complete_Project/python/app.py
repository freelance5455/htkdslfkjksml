"""
Optional local AI bridge for development/testing on a computer.
This is NOT an Android background service and does not ship a language model.
Requires Python 3.10+ and a local Ollama installation/model.
Run: pip install -r requirements.txt
Then: ollama run qwen2.5:1.5b
Then: python app.py
The PWA must be served from localhost and configured to use http://127.0.0.1:8765/chat.
"""
from http.server import BaseHTTPRequestHandler, HTTPServer
import json, urllib.request, urllib.error, os

HOST = os.environ.get("SABAHAT_LOCAL_HOST", "127.0.0.1")
PORT = int(os.environ.get("SABAHAT_LOCAL_PORT", "8765"))
OLLAMA_URL = os.environ.get("OLLAMA_URL", "http://127.0.0.1:11434/api/chat")
MODEL = os.environ.get("OLLAMA_MODEL", "qwen2.5:1.5b")

class Handler(BaseHTTPRequestHandler):
    def send_json(self, code, data):
        body = json.dumps(data, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "http://127.0.0.1:8000")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Methods", "POST, OPTIONS")
        self.end_headers()
        self.wfile.write(body)
    def do_OPTIONS(self): self.send_json(204, {})
    def do_POST(self):
        if self.path != "/chat":
            return self.send_json(404, {"error":"Use /chat"})
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length > 12000: return self.send_json(413, {"error":"Request too large"})
            data = json.loads(self.rfile.read(length) or b"{}")
            msg = str(data.get("message", "")).strip()
            lang = str(data.get("language", "auto"))
            if not msg: return self.send_json(400, {"error":"Message is required"})
            payload = json.dumps({"model":MODEL,"stream":False,"messages":[
                {"role":"system","content":f"You are Sabahat, a warm fictional assistant. Reply in the user's language ({lang}); Roman Urdu input should get Roman Urdu output. Never claim phone actions you did not perform."},
                {"role":"user","content":msg}
            ]}).encode()
            req = urllib.request.Request(OLLAMA_URL, data=payload, headers={"Content-Type":"application/json"})
            with urllib.request.urlopen(req, timeout=90) as res:
                result = json.loads(res.read())
            answer = result.get("message",{}).get("content","").strip()
            if not answer: return self.send_json(502, {"error":"Local model returned no answer"})
            return self.send_json(200, {"reply":answer})
        except urllib.error.URLError:
            return self.send_json(503, {"error":"Ollama is not running or the local model is not installed"})
        except Exception:
            return self.send_json(500, {"error":"Local bridge error; check setup instructions"})
    def log_message(self, *_): pass

if __name__ == "__main__":
    print(f"Sabahat local bridge on http://{HOST}:{PORT}/chat (model={MODEL})")
    HTTPServer((HOST, PORT), Handler).serve_forever()
