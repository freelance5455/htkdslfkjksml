<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo json_encode(['error'=>'POST only']); exit; }
$origin = getenv('SABAHAT_ALLOWED_ORIGIN') ?: '';
if ($origin !== '' && isset($_SERVER['HTTP_ORIGIN']) && $_SERVER['HTTP_ORIGIN'] !== $origin) {
  http_response_code(403); echo json_encode(['error'=>'Origin not allowed']); exit;
}
$raw = file_get_contents('php://input');
$data = json_decode($raw ?: '', true);
$message = trim((string)($data['message'] ?? ''));
$lang = trim((string)($data['language'] ?? 'auto'));
if ($message === '' || mb_strlen($message) > 4000) { http_response_code(400); echo json_encode(['error'=>'Message missing or too long (max 4000 characters).']); exit; }
$apiKey = getenv('SABAHAT_API_KEY') ?: '';
$baseUrl = rtrim(getenv('SABAHAT_API_BASE_URL') ?: 'https://api.openai.com/v1', '/');
$model = getenv('SABAHAT_MODEL') ?: 'gpt-4o-mini';
if ($apiKey === '') { http_response_code(503); echo json_encode(['error'=>'Server owner must configure SABAHAT_API_KEY. This demo does not include a paid API key.']); exit; }
$system = "You are Sabahat, a kind, respectful 18-year-old fictional female assistant. Be warm, clear, and concise. The user's preferred language is ".$lang.". If the user writes Roman Urdu, answer in natural Roman Urdu. Do not claim you performed phone actions unless the app actually did them. Explain when a request requires Android permissions or internet.";
$payload = json_encode(['model'=>$model,'messages'=>[['role'=>'system','content'=>$system],['role'=>'user','content'=>$message]],'temperature'=>0.7,'max_tokens'=>500], JSON_UNESCAPED_UNICODE);
$ch = curl_init($baseUrl.'/chat/completions');
curl_setopt_array($ch, [
 CURLOPT_POST=>true, CURLOPT_RETURNTRANSFER=>true, CURLOPT_HTTPHEADER=>['Content-Type: application/json','Authorization: Bearer '.$apiKey],
 CURLOPT_POSTFIELDS=>$payload, CURLOPT_TIMEOUT=>35
]);
$result = curl_exec($ch); $err = curl_error($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
if ($result === false) { http_response_code(502); echo json_encode(['error'=>'AI provider connection failed.']); exit; }
$decoded = json_decode($result, true);
$answer = $decoded['choices'][0]['message']['content'] ?? '';
if ($code < 200 || $code >= 300 || !is_string($answer) || trim($answer)==='') {
 http_response_code(502); echo json_encode(['error'=>'AI provider returned an error. Check server configuration and provider quota.']); exit;
}
echo json_encode(['reply'=>trim($answer)], JSON_UNESCAPED_UNICODE);
