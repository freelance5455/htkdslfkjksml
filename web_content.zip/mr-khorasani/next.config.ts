import type { NextConfig } from "next";

/**
 * برای وب و PWA: حالت عادی
 * برای Capacitor APK: BUILD_MOBILE=1 npm run build → output export به out/
 */
const isMobileBuild = process.env.BUILD_MOBILE === "1";

const nextConfig: NextConfig = {
  reactStrictMode: true,
  images: {
    remotePatterns: [],
    unoptimized: isMobileBuild,
  },
  ...(isMobileBuild
    ? {
        output: "export" as const,
        trailingSlash: true,
      }
    : {}),
};

export default nextConfig;
