import type { CapacitorConfig } from "@capacitor/cli";

/**
 * Capacitor — MR,KHORASANI Android
 *
 * مراحل ساخت APK:
 * 1. npm run build
 * 2. npx cap add android   (一次性)
 * 3. npx cap sync android
 * 4. npx cap open android  → Android Studio → Build APK / Bundle
 *
 * یا: npx cap run android
 */
const config: CapacitorConfig = {
  appId: "com.mrkhorasani.accounting",
  appName: "MR,KHORASANI",
  webDir: "out",
  server: {
    // برای توسعه با next dev می‌توان androidScheme را تنظیم کرد
    androidScheme: "https",
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 2000,
      backgroundColor: "#0f1c2e",
      showSpinner: false,
    },
    StatusBar: {
      style: "DARK",
      backgroundColor: "#0f1c2e",
    },
  },
  android: {
    allowMixedContent: true,
    backgroundColor: "#0f1c2e",
  },
};

export default config;
