# ساخت فایل نصبی APK — خودکار

## روش ۱ (پیشنهادی): یک دستور روی کامپیوتر خودتان

پیش‌نیاز: Node 18+ · JDK 17 · Android Studio یا SDK

```bash
unzip MR-KHORASANI-Final.zip
cd mr-khorasani
chmod +x scripts/build-apk-auto.sh
./scripts/build-apk-auto.sh
```

خروجی:
```
MR-KHORASANI-install.apk
```

این فایل را به گوشی منتقل کنید و نصب کنید (Allow unknown sources).

## روش ۲: Capacitor + Android Studio

```bash
npm install
npm install @capacitor/core @capacitor/cli @capacitor/android --save
BUILD_MOBILE=1 npm run build
npx cap add android
npx cap sync android
npx cap open android
```
در Android Studio: Build → Build APK(s)

## روش ۳: PWA بدون APK

1. `npm run build && npm start` روی سرور HTTPS
2. Chrome اندروید → منو → نصب اپ / افزودن به صفحه اصلی

## روش ۴: WebView ساده (android-webview/)

پروژه سبک بدون Next — فقط صفحه معرفی:
در Android Studio پوشه `android-webview` را Open کنید و Run.

## امضای انتشار

نگاه کنید به `docs/signed-apk.md` و `scripts/generate-keystore.sh`
