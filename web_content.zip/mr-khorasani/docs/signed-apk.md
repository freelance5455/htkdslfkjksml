# ساخت APK / AAB امضاشده — MR,KHORASANI

## پیش‌نیاز
- Android Studio (آخرین نسخه پایدار)
- JDK 17
- Node.js 18+
- یک‌بار: `npx cap add android`

## ۱. تولید Keystore

```bash
cd mr-khorasani
chmod +x scripts/generate-keystore.sh
bash scripts/generate-keystore.sh
```

یا دستی:
```bash
keytool -genkeypair -v -storetype PKCS12 \
  -keystore android-release.keystore \
  -alias mrkhorasani -keyalg RSA -keysize 2048 -validity 10000
```

**مهم:** فایل keystore و رمزها را در چند جای امن پشتیبان بگیرید.

## ۲. فایل `android/key.properties`

پس از `npx cap add android` در پوشه `android/`:

```properties
storePassword=رمز_استور
keyPassword=رمز_کلید
keyAlias=mrkhorasani
storeFile=../android-release.keystore
```

`android/key.properties` را به `.gitignore` اضافه کنید (هرگز در گیت commit نکنید).

## ۳. تنظیم `android/app/build.gradle`

قبل از `android {`:

```gradle
def keystorePropertiesFile = rootProject.file("key.properties")
def keystoreProperties = new Properties()
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(new FileInputStream(keystorePropertiesFile))
}
```

داخل `android {`:

```gradle
signingConfigs {
    release {
        if (keystorePropertiesFile.exists()) {
            keyAlias keystoreProperties['keyAlias']
            keyPassword keystoreProperties['keyPassword']
            storeFile file(keystoreProperties['storeFile'])
            storePassword keystoreProperties['storePassword']
        }
    }
}
buildTypes {
    release {
        signingConfig signingConfigs.release
        minifyEnabled false
    }
}
```

## ۴. Build

```bash
npm run build:mobile
npx cap sync android
npx cap open android
```

در Android Studio:
- **APK تست:** Build → Build Bundle(s) / APK(s) → Build APK(s)
- **انتشار Play:** Build → Generate Signed Bundle / APK → Android App Bundle

خروجی معمول:
- APK: `android/app/build/outputs/apk/release/app-release.apk`
- AAB: `android/app/build/outputs/bundle/release/app-release.aab`

## ۵. از خط فرمان (بدون UI)

```bash
cd android
./gradlew assembleRelease
# یا برای Play Store:
./gradlew bundleRelease
```

## ۶. بررسی امضا

```bash
jarsigner -verify -verbose -certs app-release.apk
# یا
apksigner verify --print-certs app-release.apk
```

## ۷. Application ID

در `capacitor.config.ts` و `android/app/build.gradle`:
```
com.mrkhorasani.accounting
```

برای انتشار در استور این شناسه باید یکتا و ثابت بماند.

## چک‌لیست قبل از انتشار

- [ ] Keystore پشتیبان شده
- [ ] نسخه versionCode / versionName افزایش یافته
- [ ] تست روی دستگاه واقعی Android 10+
- [ ] ثبت عملیات + بستن روز + تراز متوازن
- [ ] ProGuard در صورت minify بررسی شده
- [ ] Privacy Policy در صورت نیاز استور
EOF
