# راهنمای ساخت نسخه Android — MR,KHORASANI

## الف) نصب به‌صورت PWA (بدون Android Studio)

1. اپ را روی HTTPS یا localhost اجرا کنید: `npm run dev` یا `npm run build && npm start`
2. در Chrome موبایل Android → منو → **Add to Home screen** / نصب اپ
3. اپ مثل برنامه بومی باز می‌شود (standalone)
4. Service Worker حالت آفلاین پایه را پوشش می‌دهد

## ب) ساخت APK با Capacitor

### پیش‌نیاز
- Node.js 18+
- Android Studio (با SDK و emulator یا دستگاه واقعی)
- JDK 17

### یک‌بار اولیه
```bash
cd mr-khorasani
npm install
npm install @capacitor/core @capacitor/cli @capacitor/android --save
npx cap add android
```

### هر بار ساخت
```bash
# خروجی استاتیک برای بسته‌بندی در WebView
npm run build:mobile

# همگام‌سازی با پروژه Android
npx cap sync android

# باز کردن در Android Studio
npx cap open android
```

یا یک‌جا:
```bash
npm run android
```

### در Android Studio
1. Build → Build Bundle(s) / APK(s) → Build APK(s)
2. یا Generate Signed Bundle برای انتشار در Google Play
3. فایل خروجی معمولاً:
   `android/app/build/outputs/apk/debug/app-debug.apk`

### شناسه اپ
- **Application ID:** `com.mrkhorasani.accounting`
- **نام نمایشی:** MR,KHORASANI
- **رنگ Splash:** سرمه‌ای `#0f1c2e`

## ج) نکات Offline-First
- داده‌های فاز فعلی در Zustand (حافظه مرورگر) هستند
- برای نسخه تولید: اتصال Supabase + جدول `sync_queue` (Schema فاز ۱)
- Service Worker کش پوسته UI را نگه می‌دارد
- بنر «حالت آفلاین» هنگام قطع اینترنت نمایش داده می‌شود

## د) تست اجباری قبل از Release
- [ ] نصب PWA روی گوشی
- [ ] ثبت عملیات بدون اینترنت
- [ ] بستن روز و قفل
- [ ] تراز آزمایشی متوازن
- [ ] نصب APK روی حداقل یک دستگاه Android 10+
EOF
