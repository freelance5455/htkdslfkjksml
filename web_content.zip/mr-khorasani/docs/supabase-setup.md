# اتصال Supabase — MR,KHORASANI

## ۱. ایجاد پروژه
1. در [supabase.com](https://supabase.com) پروژه بسازید
2. SQL Editor → اجرای به ترتیب:
   - `supabase/migrations/001_initial_schema.sql`
   - `supabase/migrations/002_seed_chart_of_accounts.sql`
   - `supabase/migrations/003_seed_data.sql`

> توجه: تابع `seed_account` در migration ۲ تعریف شده و در ۳ با `company_id` واقعی صدا زده می‌شود.

## ۲. متغیرهای محیطی
فایل `.env.local`:
```
NEXT_PUBLIC_SUPABASE_URL=https://xxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJ...
```

کپی از `.env.example`

## ۳. اتصال کلاینت
`src/lib/supabase.ts` از قبل آماده است.
Storeهای Zustand را می‌توان مرحله‌به‌مرحله با Repository روی Supabase جایگزین کرد:

| Store فعلی | جدول Supabase |
|------------|----------------|
| master-data parties | parties |
| master-data products | products |
| master-data sources | financial_sources |
| operations | operations + journal_entries + journal_lines |
| day-close | financial_days + audit_logs |

## ۴. Offline + Sync
جدول `sync_queue` در Schema فاز ۱ تعریف شده.
جریان پیشنهادی:
1. ثبت محلی (IndexedDB / Zustand persist)
2. صف sync
3. هنگام online: push به Supabase با UUID یکتا

## ۵. Auth
جدول `users` و `roles` آماده است.
Supabase Auth → پس از login، ردیف users با auth_user_id پر شود.
EOF

## لایه Repository (کد آماده)

| فایل | نقش |
|------|-----|
| `src/lib/supabase.ts` | کلاینت + `isSupabaseConfigured` + تست اتصال |
| `src/lib/repositories/parties-repo.ts` | CRUD اشخاص ابری/محلی |
| `src/lib/repositories/operations-repo.ts` | Push/Pull عملیات و اسناد |
| `src/components/supabase/ConnectionPanel.tsx` | UI تست و همگام‌سازی در تنظیمات |

جریان پیشنهادی پس از ثبت عملیات:
```ts
import { pushOperationToCloud } from "@/lib/repositories/operations-repo";
// بعد از createOperation موفق:
await pushOperationToCloud(operation, journal, lines);
```
