import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/** فرمت عدد به فارسی با جداکننده هزارگان */
export function formatMoney(amount: number): string {
  return new Intl.NumberFormat("fa-IR").format(amount);
}

/** فرمت عدد انگلیسی با کاما */
export function formatNumber(amount: number): string {
  return new Intl.NumberFormat("en-US").format(amount);
}
