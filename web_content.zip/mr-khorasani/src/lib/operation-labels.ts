import type { OperationType } from "@/types/database";

export const OPERATION_TYPE_LABELS: Record<OperationType, string> = {
  receipt: "دریافت",
  payment: "پرداخت",
  transfer: "انتقال",
  sale: "فروش",
  sale_return: "برگشت از فروش",
  purchase: "خرید",
  purchase_return: "برگشت از خرید",
  expense: "هزینه",
  income: "درآمد",
  receipt_invoice: "دریافت بابت فاکتور",
  payment_invoice: "پرداخت بابت فاکتور",
  check_receive: "دریافت چک",
  check_pay: "پرداخت چک",
  check_clear: "وصول چک",
  check_bounce: "برگشت چک",
  petty_cash: "تنخواه",
  adjustment: "اصلاحی",
  manual: "سند دستی",
  opening: "افتتاحیه",
  closing: "اختتامیه",
};

export const OPERATION_TYPE_COLORS: Record<string, string> = {
  receipt: "bg-emerald-50 text-emerald-700",
  receipt_invoice: "bg-emerald-50 text-emerald-700",
  income: "bg-emerald-50 text-emerald-700",
  sale: "bg-blue-50 text-blue-700",
  payment: "bg-red-50 text-red-700",
  payment_invoice: "bg-red-50 text-red-700",
  expense: "bg-orange-50 text-orange-700",
  purchase: "bg-purple-50 text-purple-700",
  transfer: "bg-slate-100 text-slate-700",
  adjustment: "bg-gold-50 text-gold-800",
  manual: "bg-slate-100 text-slate-600",
};

/** انواع عملیات اصلی برای انتخاب سریع */
export const QUICK_OPERATION_TYPES: {
  type: OperationType;
  label: string;
  icon: string;
  desc: string;
}[] = [
  { type: "receipt", label: "دریافت", icon: "↓", desc: "دریافت از مشتری / سایر" },
  { type: "payment", label: "پرداخت", icon: "↑", desc: "پرداخت به تأمین‌کننده / سایر" },
  { type: "transfer", label: "انتقال", icon: "⇄", desc: "بین صندوق و بانک‌ها" },
  { type: "sale", label: "فروش", icon: "🛒", desc: "فاکتور فروش" },
  { type: "purchase", label: "خرید", icon: "📦", desc: "فاکتور خرید" },
  { type: "expense", label: "هزینه", icon: "💸", desc: "ثبت هزینه نقدی/بانکی" },
  { type: "income", label: "درآمد", icon: "💰", desc: "سایر درآمدها" },
  { type: "manual", label: "سند دستی", icon: "✎", desc: "ثبت مستقیم سند" },
];
