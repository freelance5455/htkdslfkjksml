/**
 * موتور گزارش‌گیری — تراز آزمایشی، دفتر روزنامه، سود و زیان تقریبی
 * فاز ۵ — MR,KHORASANI
 */

import type { JournalEntry, JournalLine, Operation, TrialBalanceRow } from "@/types/database";

/** نام حساب از روی account_id موقت */
export const ACCOUNT_LABELS: Record<string, { code: string; name: string; type: string }> = {
  "acc-1111": { code: "1111", name: "وجه نقد صندوق", type: "asset" },
  "acc-1121": { code: "1121", name: "بانک ملی ایران", type: "asset" },
  "acc-1122": { code: "1122", name: "بانک ملت", type: "asset" },
  "acc-1123": { code: "1123", name: "بانک صادرات ایران", type: "asset" },
  "acc-1124": { code: "1124", name: "بانک تجارت", type: "asset" },
  "acc-1125": { code: "1125", name: "بانک سپه", type: "asset" },
  "acc-1126": { code: "1126", name: "بانک رفاه کارگران", type: "asset" },
  "acc-1127": { code: "1127", name: "بانک کشاورزی", type: "asset" },
  "acc-1128": { code: "1128", name: "بانک مسکن", type: "asset" },
  "acc-1129": { code: "1129", name: "بانک پارسیان", type: "asset" },
  "acc-1130": { code: "1130", name: "بانک سامان", type: "asset" },
  "acc-1131": { code: "1131", name: "تنخواه گردان", type: "asset" },
  "acc-1211": { code: "1211", name: "مشتریان", type: "asset" },
  "acc-1311": { code: "1311", name: "موجودی کالا", type: "asset" },
  "acc-2111": { code: "2111", name: "تأمین‌کنندگان", type: "liability" },
  "acc-4111": { code: "4111", name: "فروش کالا", type: "revenue" },
  "acc-4131": { code: "4131", name: "تخفیفات فروش", type: "revenue" },
  "acc-4311": { code: "4311", name: "درآمد حمل", type: "revenue" },
  "acc-4391": { code: "4391", name: "سایر درآمدها", type: "revenue" },
  "acc-5111": { code: "5111", name: "بهای تمام‌شده کالای فروش‌رفته", type: "cogs" },
  "acc-5211": { code: "5211", name: "تخفیفات خرید", type: "cogs" },
  "acc-6111": { code: "6111", name: "حقوق و دستمزد", type: "expense" },
  "acc-6121": { code: "6121", name: "اجاره", type: "expense" },
  "acc-6141": { code: "6141", name: "هزینه حمل", type: "expense" },
  "acc-6991": { code: "6991", name: "سایر هزینه‌ها", type: "expense" },
};

export interface JournalBookRow {
  journalNumber: string;
  journalDate: string;
  journalDateJalali: string;
  description: string;
  accountCode: string;
  accountName: string;
  debit: number;
  credit: number;
  operationNumber?: string;
}

export interface LedgerRow {
  date: string;
  dateJalali: string;
  journalNumber: string;
  description: string;
  debit: number;
  credit: number;
  balance: number;
}

export interface PLSummary {
  sales: number;
  salesDiscount: number;
  netSales: number;
  cogs: number;
  grossProfit: number;
  expenses: number;
  otherIncome: number;
  netProfit: number;
}

export interface KPISnapshot {
  salesToday: number;
  salesMonth: number;
  receiptsToday: number;
  paymentsToday: number;
  netCashToday: number;
  totalReceivables: number;
  totalPayables: number;
  totalLiquidity: number;
  operationsCount: number;
  profitApprox: number;
}

/** ساخت تراز آزمایشی از ردیف‌های اسناد */
export function buildTrialBalance(
  journals: JournalEntry[],
  lines: JournalLine[],
  fromDate?: string,
  toDate?: string
): TrialBalanceRow[] {
  const activeJournals = journals.filter((j) => {
    if (j.status === "deleted") return false;
    if (fromDate && j.journal_date < fromDate) return false;
    if (toDate && j.journal_date > toDate) return false;
    return true;
  });
  const journalIds = new Set(activeJournals.map((j) => j.id));

  const map = new Map<
    string,
    { debit: number; credit: number }
  >();

  for (const line of lines) {
    if (!journalIds.has(line.journal_id)) continue;
    const cur = map.get(line.account_id) || { debit: 0, credit: 0 };
    cur.debit += line.debit;
    cur.credit += line.credit;
    map.set(line.account_id, cur);
  }

  const rows: TrialBalanceRow[] = [];
  for (const [accountId, totals] of map.entries()) {
    const meta = ACCOUNT_LABELS[accountId] || {
      code: accountId.replace("acc-", ""),
      name: accountId,
      type: "other",
    };
    const net = totals.debit - totals.credit;
    rows.push({
      account_id: accountId,
      code: meta.code,
      name_fa: meta.name,
      level: 4,
      opening_debit: 0,
      opening_credit: 0,
      period_debit: totals.debit,
      period_credit: totals.credit,
      closing_debit: net > 0 ? net : 0,
      closing_credit: net < 0 ? -net : 0,
    });
  }

  // مرتب‌سازی بر اساس کد
  rows.sort((a, b) => a.code.localeCompare(b.code, undefined, { numeric: true }));
  return rows;
}

export function trialBalanceTotals(rows: TrialBalanceRow[]) {
  return {
    periodDebit: rows.reduce((s, r) => s + r.period_debit, 0),
    periodCredit: rows.reduce((s, r) => s + r.period_credit, 0),
    closingDebit: rows.reduce((s, r) => s + r.closing_debit, 0),
    closingCredit: rows.reduce((s, r) => s + r.closing_credit, 0),
  };
}

/** دفتر روزنامه */
export function buildJournalBook(
  journals: JournalEntry[],
  lines: JournalLine[],
  operations: Operation[],
  fromDate?: string,
  toDate?: string
): JournalBookRow[] {
  const opMap = new Map(operations.map((o) => [o.id, o]));
  const result: JournalBookRow[] = [];

  const sorted = [...journals]
    .filter((j) => {
      if (j.status === "deleted") return false;
      if (fromDate && j.journal_date < fromDate) return false;
      if (toDate && j.journal_date > toDate) return false;
      return true;
    })
    .sort((a, b) => a.journal_date.localeCompare(b.journal_date) || a.journal_number.localeCompare(b.journal_number));

  for (const j of sorted) {
    const jLines = lines
      .filter((l) => l.journal_id === j.id)
      .sort((a, b) => a.sort_order - b.sort_order);
    const op = j.operation_id ? opMap.get(j.operation_id) : undefined;
    for (const l of jLines) {
      const meta = ACCOUNT_LABELS[l.account_id];
      result.push({
        journalNumber: j.journal_number,
        journalDate: j.journal_date,
        journalDateJalali: j.journal_date_jalali,
        description: l.description || j.description,
        accountCode: meta?.code || l.account_id.replace("acc-", ""),
        accountName: meta?.name || l.account_id,
        debit: l.debit,
        credit: l.credit,
        operationNumber: op?.operation_number,
      });
    }
  }
  return result;
}

/** گردش یک حساب (دفتر کل ساده) */
export function buildAccountLedger(
  accountId: string,
  journals: JournalEntry[],
  lines: JournalLine[],
  fromDate?: string,
  toDate?: string
): LedgerRow[] {
  const activeJournals = journals.filter((j) => {
    if (j.status === "deleted") return false;
    if (fromDate && j.journal_date < fromDate) return false;
    if (toDate && j.journal_date > toDate) return false;
    return true;
  });
  const jMap = new Map(activeJournals.map((j) => [j.id, j]));

  const relevant = lines
    .filter((l) => l.account_id === accountId && jMap.has(l.journal_id))
    .map((l) => ({ line: l, journal: jMap.get(l.journal_id)! }))
    .sort(
      (a, b) =>
        a.journal.journal_date.localeCompare(b.journal.journal_date) ||
        a.journal.journal_number.localeCompare(b.journal.journal_number)
    );

  let balance = 0;
  const meta = ACCOUNT_LABELS[accountId];
  const isCreditNature =
    meta && ["liability", "equity", "revenue"].includes(meta.type);

  return relevant.map(({ line, journal }) => {
    if (isCreditNature) {
      balance += line.credit - line.debit;
    } else {
      balance += line.debit - line.credit;
    }
    return {
      date: journal.journal_date,
      dateJalali: journal.journal_date_jalali,
      journalNumber: journal.journal_number,
      description: line.description || journal.description,
      debit: line.debit,
      credit: line.credit,
      balance,
    };
  });
}

/** سود و زیان تقریبی از اسناد */
export function buildProfitLoss(
  journals: JournalEntry[],
  lines: JournalLine[],
  fromDate?: string,
  toDate?: string
): PLSummary {
  const rows = buildTrialBalance(journals, lines, fromDate, toDate);
  const byCode = (prefix: string) =>
    rows
      .filter((r) => r.code.startsWith(prefix))
      .reduce((s, r) => s + r.period_credit - r.period_debit, 0);

  const byCodeDebit = (prefix: string) =>
    rows
      .filter((r) => r.code.startsWith(prefix))
      .reduce((s, r) => s + r.period_debit - r.period_credit, 0);

  const sales = rows
    .filter((r) => r.code.startsWith("411"))
    .reduce((s, r) => s + r.period_credit, 0);
  const salesDiscount = rows
    .filter((r) => r.code.startsWith("413"))
    .reduce((s, r) => s + r.period_debit, 0);
  const netSales = sales - salesDiscount;
  const cogs = rows
    .filter((r) => r.code.startsWith("51"))
    .reduce((s, r) => s + r.period_debit - r.period_credit, 0);
  const grossProfit = netSales - cogs;
  const expenses = rows
    .filter((r) => r.code.startsWith("6"))
    .reduce((s, r) => s + r.period_debit - r.period_credit, 0);
  const otherIncome = rows
    .filter((r) => r.code.startsWith("43"))
    .reduce((s, r) => s + r.period_credit - r.period_debit, 0);
  const netProfit = grossProfit - expenses + otherIncome;

  return {
    sales,
    salesDiscount,
    netSales,
    cogs,
    grossProfit,
    expenses,
    otherIncome,
    netProfit,
  };
}

/** KPI از عملیات و منابع */
export function buildKPI(
  operations: Operation[],
  liquidityTotal: number,
  parties: { current_balance: number; party_type: string[] }[],
  todayISO: string
): KPISnapshot {
  const active = operations.filter((o) => o.status === "posted");
  const today = active.filter((o) => o.operation_date === todayISO);
  const monthPrefix = todayISO.slice(0, 7);

  const sumType = (list: Operation[], types: string[]) =>
    list
      .filter((o) => types.includes(o.operation_type))
      .reduce((s, o) => s + o.amount, 0);

  const salesToday = sumType(today, ["sale"]);
  const salesMonth = sumType(
    active.filter((o) => o.operation_date.startsWith(monthPrefix)),
    ["sale"]
  );
  const receiptsToday = sumType(today, ["receipt", "receipt_invoice", "income", "sale"]);
  const paymentsToday = sumType(today, ["payment", "payment_invoice", "expense", "purchase"]);

  const receivables = parties
    .filter((p) => p.party_type.includes("customer") && p.current_balance > 0)
    .reduce((s, p) => s + p.current_balance, 0);
  const payables = parties
    .filter((p) => p.party_type.includes("supplier") && p.current_balance < 0)
    .reduce((s, p) => s + Math.abs(p.current_balance), 0);

  return {
    salesToday,
    salesMonth,
    receiptsToday,
    paymentsToday,
    netCashToday: receiptsToday - paymentsToday,
    totalReceivables: receivables,
    totalPayables: payables,
    totalLiquidity: liquidityTotal,
    operationsCount: today.length,
    profitApprox: salesToday - paymentsToday * 0.3, // تقریبی ساده
  };
}
