/**
 * ورود داده از CSV / الگوی اکسل‌سازگار
 * فاز تکمیلی — MR,KHORASANI
 *
 * فایل‌های اکسل را می‌توان Save As → CSV کرد و اینجا وارد نمود.
 */

export interface PartyImportRow {
  code: string;
  name: string;
  trade_name?: string;
  party_type: string; // customer,supplier,...
  mobile?: string;
  phone?: string;
  national_id?: string;
  address?: string;
  opening_balance?: number;
  description?: string;
}

export interface ProductImportRow {
  code: string;
  name: string;
  barcode?: string;
  unit?: string;
  category?: string;
  purchase_price?: number;
  sale_price?: number;
  description?: string;
}

function parseCSVLine(line: string): string[] {
  const result: string[] = [];
  let current = "";
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      inQuotes = !inQuotes;
    } else if ((ch === "," || ch === ";") && !inQuotes) {
      result.push(current.trim());
      current = "";
    } else {
      current += ch;
    }
  }
  result.push(current.trim());
  return result;
}

function normalizeHeader(h: string): string {
  return h
    .replace(/^\uFEFF/, "")
    .trim()
    .toLowerCase()
    .replace(/\s+/g, "_");
}

/** پارس CSV به آرایه آبجکت */
export function parseCSV(text: string): Record<string, string>[] {
  const lines = text
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l.length > 0);
  if (lines.length < 2) return [];

  const headers = parseCSVLine(lines[0]).map(normalizeHeader);
  const rows: Record<string, string>[] = [];

  for (let i = 1; i < lines.length; i++) {
    const cols = parseCSVLine(lines[i]);
    const obj: Record<string, string> = {};
    headers.forEach((h, idx) => {
      obj[h] = cols[idx] || "";
    });
    rows.push(obj);
  }
  return rows;
}

export function mapToPartyRows(raw: Record<string, string>[]): PartyImportRow[] {
  return raw
    .filter((r) => r.code || r.name || r["نام"] || r["کد"])
    .map((r) => ({
      code: r.code || r["کد"] || r["کد_شخص"] || "",
      name: r.name || r["نام"] || r["نام_شرکت"] || "",
      trade_name: r.trade_name || r["نام_تجاری"] || undefined,
      party_type:
        r.party_type ||
        r["نوع"] ||
        r.type ||
        "customer",
      mobile: r.mobile || r["موبایل"] || undefined,
      phone: r.phone || r["تلفن"] || undefined,
      national_id: r.national_id || r["کد_ملی"] || r["شناسه_ملی"] || undefined,
      address: r.address || r["آدرس"] || undefined,
      opening_balance: Number(r.opening_balance || r["مانده"] || 0) || 0,
      description: r.description || r["توضیحات"] || undefined,
    }))
    .filter((r) => r.code && r.name);
}

export function mapToProductRows(raw: Record<string, string>[]): ProductImportRow[] {
  return raw
    .filter((r) => r.code || r.name || r["کد"] || r["نام"])
    .map((r) => ({
      code: r.code || r["کد"] || r["کد_کالا"] || "",
      name: r.name || r["نام"] || r["نام_کالا"] || "",
      barcode: r.barcode || r["بارکد"] || undefined,
      unit: r.unit || r["واحد"] || "عدد",
      category: r.category || r["دسته"] || r["دسته‌بندی"] || undefined,
      purchase_price: Number(r.purchase_price || r["قیمت_خرید"] || 0) || 0,
      sale_price: Number(r.sale_price || r["قیمت_فروش"] || 0) || 0,
      description: r.description || r["توضیحات"] || undefined,
    }))
    .filter((r) => r.code && r.name);
}

/** دانلود الگوی CSV */
export function downloadCSVTemplate(type: "parties" | "products") {
  let content = "";
  let filename = "";
  if (type === "parties") {
    filename = "الگوی-اشخاص-MR-KHORASANI.csv";
    content =
      "code,name,trade_name,party_type,mobile,phone,national_id,address,opening_balance,description\n" +
      "C001,شرکت نمونه,نمونه,customer,09121234567,,10101234567,تهران,0,مشتری نمونه\n" +
      "S001,تأمین‌کننده پارس,,supplier,09121112233,,,,0,\n";
  } else {
    filename = "الگوی-کالا-MR-KHORASANI.csv";
    content =
      "code,name,barcode,unit,category,purchase_price,sale_price,description\n" +
      "K001,کالای نمونه,6260123456789,عدد,عمومی,100000,150000,\n";
  }

  const blob = new Blob(["\uFEFF" + content], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}
