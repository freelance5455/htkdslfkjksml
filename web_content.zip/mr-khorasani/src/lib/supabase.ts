/**
 * Supabase Client — MR,KHORASANI
 * اگر URL/KEY تنظیم نشده باشد، isSupabaseConfigured = false و اپ با Zustand محلی کار می‌کند.
 */

import { createClient, SupabaseClient } from "@supabase/supabase-js";

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || "";
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "";

export const isSupabaseConfigured =
  Boolean(supabaseUrl) &&
  Boolean(supabaseAnonKey) &&
  !supabaseUrl.includes("your-project") &&
  supabaseAnonKey !== "your-anon-key";

export const supabase: SupabaseClient = createClient(
  supabaseUrl || "https://placeholder.supabase.co",
  supabaseAnonKey || "placeholder-key",
  {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
    },
  }
);

/** تست اتصال ساده به API */
export async function testSupabaseConnection(): Promise<{
  ok: boolean;
  message: string;
  latencyMs?: number;
}> {
  if (!isSupabaseConfigured) {
    return {
      ok: false,
      message:
        "Supabase پیکربندی نشده. فایل .env.local را با URL و Anon Key پر کنید.",
    };
  }
  const t0 = Date.now();
  try {
    const { error } = await supabase.from("companies").select("id").limit(1);
    const latencyMs = Date.now() - t0;
    if (error) {
      if (error.code === "42P01" || error.message.includes("does not exist")) {
        return {
          ok: true,
          message: `اتصال برقرار است ولی جدول companies نیست — migrationها را اجرا کنید. (${latencyMs}ms)`,
          latencyMs,
        };
      }
      return { ok: false, message: error.message, latencyMs };
    }
    return { ok: true, message: `اتصال موفق (${latencyMs}ms)`, latencyMs };
  } catch (e) {
    return {
      ok: false,
      message: e instanceof Error ? e.message : "خطای شبکه",
    };
  }
}
