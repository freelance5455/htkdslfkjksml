/**
 * سناریوی نمایشی کامل: دریافت + فروش + هزینه → تراز متوازن
 * برای تست یک‌کلیکه
 */

import { useOperations } from "@/store/operations";
import { useMasterData } from "@/store/master-data";

export function runDemoScenario(): { ok: boolean; message: string } {
  const master = useMasterData.getState();
  const ops = useOperations.getState();

  // شخص نمونه اگر نبود
  let customer = master.parties.find(
    (p) => p.is_active && p.party_type.includes("customer") && !p.deleted_at
  );
  if (!customer) {
    customer = master.addParty({
      code: "DEMO-C1",
      name: "مشتری نمایشی",
      party_type: ["customer"],
      mobile: "09120000001",
      is_active: true,
    });
  }

  const sources = master.getActiveSources();
  const cash = sources.find((s) => s.source_type === "cash") || sources[0];
  if (!cash) {
    return { ok: false, message: "منبع مالی یافت نشد" };
  }

  const r1 = ops.createOperation({
    operationType: "receipt",
    amount: 5000000,
    partyId: customer.id,
    financialSourceId: cash.id,
    description: "دریافت نمایشی از مشتری",
  });
  if (!r1.success) return { ok: false, message: r1.error || "خطا دریافت" };

  const r2 = ops.createOperation({
    operationType: "expense",
    amount: 750000,
    financialSourceId: cash.id,
    description: "هزینه نمایشی اداری",
    expenseOrIncomeAccountCode: "6991",
  });
  if (!r2.success) return { ok: false, message: r2.error || "خطا هزینه" };

  const r3 = ops.createOperation({
    operationType: "sale",
    amount: 12000000,
    partyId: customer.id,
    financialSourceId: cash.id,
    description: "فروش نمایشی نقدی",
  });
  if (!r3.success) return { ok: false, message: r3.error || "خطا فروش" };

  return {
    ok: true,
    message: `۳ عملیات ثبت شد: دریافت ۵م · هزینه ۷۵۰ه · فروش ۱۲م — اسناد دوبل تولید شد. تراز را در /reports/trial-balance ببینید.`,
  };
}
