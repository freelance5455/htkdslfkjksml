/**
 * Repository اشخاص — Local (Zustand) یا Supabase
 */

import { supabase, isSupabaseConfigured } from "@/lib/supabase";
import type { Party, PartyType } from "@/types/database";
import { useMasterData } from "@/store/master-data";

const COMPANY_ID_KEY = "mrk_company_id";

export function getLocalCompanyId(): string {
  if (typeof window === "undefined") return "c1";
  return localStorage.getItem(COMPANY_ID_KEY) || "c1";
}

export function setLocalCompanyId(id: string) {
  if (typeof window !== "undefined") localStorage.setItem(COMPANY_ID_KEY, id);
}

function mapRow(row: Record<string, unknown>): Party {
  return {
    id: String(row.id),
    company_id: String(row.company_id),
    code: String(row.code),
    name: String(row.name),
    trade_name: row.trade_name ? String(row.trade_name) : undefined,
    party_type: (row.party_type as PartyType[]) || ["customer"],
    mobile: row.mobile ? String(row.mobile) : undefined,
    phone: row.phone ? String(row.phone) : undefined,
    address: row.address ? String(row.address) : undefined,
    national_id: row.national_id ? String(row.national_id) : undefined,
    economic_code: row.economic_code ? String(row.economic_code) : undefined,
    is_active: row.is_active !== false,
    opening_balance: Number(row.opening_balance) || 0,
    current_balance: Number(row.current_balance) || 0,
    description: row.description ? String(row.description) : undefined,
    deleted_at: row.deleted_at ? String(row.deleted_at) : undefined,
  };
}

export async function fetchPartiesFromCloud(): Promise<Party[]> {
  if (!isSupabaseConfigured) return useMasterData.getState().parties;

  const companyId = getLocalCompanyId();
  const { data, error } = await supabase
    .from("parties")
    .select("*")
    .eq("company_id", companyId)
    .is("deleted_at", null)
    .order("name");

  if (error) throw new Error(error.message);
  return (data || []).map((r) => mapRow(r as Record<string, unknown>));
}

export async function upsertPartyToCloud(
  party: Omit<Party, "id"> & { id?: string }
): Promise<Party> {
  if (!isSupabaseConfigured) {
    if (party.id) {
      useMasterData.getState().updateParty(party.id, party);
      return useMasterData.getState().getPartyById(party.id)!;
    }
    return useMasterData.getState().addParty({
      code: party.code,
      name: party.name,
      trade_name: party.trade_name,
      party_type: party.party_type,
      mobile: party.mobile,
      phone: party.phone,
      address: party.address,
      national_id: party.national_id,
      economic_code: party.economic_code,
      is_active: party.is_active,
      description: party.description,
      opening_balance: party.opening_balance,
    });
  }

  const payload = {
    ...(party.id ? { id: party.id } : {}),
    company_id: party.company_id || getLocalCompanyId(),
    code: party.code,
    name: party.name,
    trade_name: party.trade_name,
    party_type: party.party_type,
    mobile: party.mobile,
    phone: party.phone,
    address: party.address,
    national_id: party.national_id,
    economic_code: party.economic_code,
    is_active: party.is_active ?? true,
    opening_balance: party.opening_balance ?? 0,
    current_balance: party.current_balance ?? party.opening_balance ?? 0,
    description: party.description,
  };

  const { data, error } = await supabase
    .from("parties")
    .upsert(payload)
    .select()
    .single();

  if (error) throw new Error(error.message);
  const mapped = mapRow(data as Record<string, unknown>);
  // همگام با store محلی
  const local = useMasterData.getState();
  if (party.id) local.updateParty(mapped.id, mapped);
  else {
    useMasterData.setState((s) => ({
      parties: [mapped, ...s.parties.filter((p) => p.id !== mapped.id)],
    }));
  }
  return mapped;
}

export async function softDeletePartyCloud(id: string): Promise<void> {
  if (!isSupabaseConfigured) {
    useMasterData.getState().softDeleteParty(id);
    return;
  }
  const { error } = await supabase
    .from("parties")
    .update({ deleted_at: new Date().toISOString(), is_active: false })
    .eq("id", id);
  if (error) throw new Error(error.message);
  useMasterData.getState().softDeleteParty(id);
}

/** بارگذاری ابری و جایگزینی store محلی */
export async function syncPartiesFromCloud(): Promise<number> {
  if (!isSupabaseConfigured) return 0;
  const list = await fetchPartiesFromCloud();
  useMasterData.setState({ parties: list });
  return list.length;
}
