/**
 * Repository عملیات + اسناد — push به Supabase پس از ثبت محلی
 */

import { supabase, isSupabaseConfigured } from "@/lib/supabase";
import { getLocalCompanyId } from "@/lib/repositories/parties-repo";
import type { Operation, JournalEntry, JournalLine } from "@/types/database";
import { useOperations } from "@/store/operations";

export async function pushOperationToCloud(
  operation: Operation,
  journal: JournalEntry,
  lines: JournalLine[]
): Promise<{ ok: boolean; error?: string }> {
  if (!isSupabaseConfigured) {
    return { ok: true }; // حالت محلی — موفق فرضی
  }

  const companyId = operation.company_id || getLocalCompanyId();

  try {
    const { error: opErr } = await supabase.from("operations").upsert({
      id: operation.id,
      company_id: companyId,
      fiscal_year_id: operation.fiscal_year_id,
      operation_number: operation.operation_number,
      operation_type: operation.operation_type,
      operation_date: operation.operation_date,
      operation_date_jalali: operation.operation_date_jalali,
      party_id: operation.party_id,
      financial_source_id: operation.financial_source_id,
      amount: operation.amount,
      description: operation.description,
      reference_number: operation.reference_number,
      status: operation.status,
      is_locked: operation.is_locked,
      created_by: operation.created_by,
      version: operation.version,
      sync_status: "synced",
    });
    if (opErr) throw opErr;

    const { error: jErr } = await supabase.from("journal_entries").upsert({
      id: journal.id,
      company_id: companyId,
      fiscal_year_id: journal.fiscal_year_id,
      journal_number: journal.journal_number,
      journal_date: journal.journal_date,
      journal_date_jalali: journal.journal_date_jalali,
      description: journal.description,
      operation_id: journal.operation_id,
      journal_type: journal.journal_type,
      total_debit: journal.total_debit,
      total_credit: journal.total_credit,
      status: journal.status,
      is_locked: journal.is_locked,
      created_by: journal.created_by,
      version: journal.version,
    });
    if (jErr) throw jErr;

    if (lines.length) {
      const { error: lErr } = await supabase.from("journal_lines").upsert(
        lines.map((l) => ({
          id: l.id,
          journal_id: l.journal_id,
          account_id: l.account_id,
          party_id: l.party_id,
          financial_source_id: l.financial_source_id,
          debit: l.debit,
          credit: l.credit,
          description: l.description,
          sort_order: l.sort_order,
        }))
      );
      if (lErr) throw lErr;
    }

    // به‌روز کردن وضعیت sync محلی
    useOperations.setState((s) => ({
      operations: s.operations.map((o) =>
        o.id === operation.id ? { ...o, sync_status: "synced" as const } : o
      ),
    }));

    return { ok: true };
  } catch (e) {
    return {
      ok: false,
      error: e instanceof Error ? e.message : "خطای همگام‌سازی",
    };
  }
}

export async function pullOperationsFromCloud(fromDate?: string): Promise<number> {
  if (!isSupabaseConfigured) return 0;

  const companyId = getLocalCompanyId();
  let q = supabase
    .from("operations")
    .select("*")
    .eq("company_id", companyId)
    .neq("status", "deleted")
    .order("operation_date", { ascending: false })
    .limit(500);

  if (fromDate) q = q.gte("operation_date", fromDate);

  const { data, error } = await q;
  if (error) throw new Error(error.message);

  // ادغام ساده: فقط مواردی که محلی نیستند
  const local = useOperations.getState();
  const existing = new Set(local.operations.map((o) => o.id));
  const incoming = (data || []).filter((r) => !existing.has(String(r.id)));

  if (incoming.length) {
    useOperations.setState((s) => ({
      operations: [
        ...incoming.map((r) => ({
          id: String(r.id),
          company_id: String(r.company_id),
          fiscal_year_id: String(r.fiscal_year_id),
          operation_number: String(r.operation_number),
          operation_type: r.operation_type,
          operation_date: String(r.operation_date),
          operation_date_jalali: String(r.operation_date_jalali),
          party_id: r.party_id ? String(r.party_id) : undefined,
          financial_source_id: r.financial_source_id
            ? String(r.financial_source_id)
            : undefined,
          amount: Number(r.amount),
          description: r.description ? String(r.description) : undefined,
          reference_number: r.reference_number
            ? String(r.reference_number)
            : undefined,
          status: r.status,
          is_locked: Boolean(r.is_locked),
          created_by: String(r.created_by),
          created_at: String(r.created_at || new Date().toISOString()),
          updated_at: String(r.updated_at || new Date().toISOString()),
          version: Number(r.version) || 1,
          sync_status: "synced" as const,
        })),
        ...s.operations,
      ],
    }));
  }

  return incoming.length;
}
