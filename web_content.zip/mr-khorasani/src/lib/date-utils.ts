/**
 * ابزار تاریخ شمسی — MR,KHORASANI
 * استفاده از dayjs + jalaliday
 */

import dayjs from "dayjs";
import jalaliday from "jalaliday";

dayjs.extend(jalaliday);

export type DayjsJalali = dayjs.Dayjs;

/** تبدیل تاریخ میلادی به شمسی با فرمت ۱۴۰۵/۰۶/۳۱ */
export function toJalali(date: string | Date | dayjs.Dayjs, withTime = false): string {
  const d = dayjs(date).calendar("jalali");
  if (withTime) {
    return d.format("YYYY/MM/DD - HH:mm");
  }
  return d.format("YYYY/MM/DD");
}

/** تبدیل رشته شمسی (۱۴۰۵/۰۶/۳۱) به Date میلادی */
export function fromJalali(jalaliStr: string): Date {
  // پشتیبانی از فرمت‌های مختلف
  const cleaned = jalaliStr.replace(/[-\.]/g, "/").trim();
  const parts = cleaned.split(/[\/\s-]/);
  if (parts.length < 3) throw new Error(`فرمت تاریخ شمسی نامعتبر: ${jalaliStr}`);

  const [jy, jm, jd] = parts.map(Number);
  const d = dayjs()
    .calendar("jalali")
    .year(jy)
    .month(jm - 1)
    .date(jd)
    .hour(12)
    .minute(0)
    .second(0);
  return d.toDate();
}

/** امروز به شمسی */
export function todayJalali(): string {
  return toJalali(new Date());
}

/** امروز میلادی (canonical برای DB) */
export function todayISO(): string {
  return dayjs().format("YYYY-MM-DD");
}

/** بررسی اینکه تاریخ داخل سال مالی است */
export function isInFiscalYear(
  date: string | Date,
  start: string,
  end: string
): boolean {
  const d = dayjs(date);
  return (
    (d.isAfter(dayjs(start)) || d.isSame(dayjs(start), "day")) &&
    (d.isBefore(dayjs(end)) || d.isSame(dayjs(end), "day"))
  );
}

/** تولید شماره عملیات / سند */
export function generateNumber(
  prefix: "OP" | "JV" | "INV",
  fiscalYear: number,
  sequence: number
): string {
  return `${prefix}-${fiscalYear}-${String(sequence).padStart(6, "0")}`;
}

/** بازه‌های آماده گزارش */
export const datePresets = {
  today: () => ({ from: todayISO(), to: todayISO() }),
  yesterday: () => {
    const y = dayjs().subtract(1, "day").format("YYYY-MM-DD");
    return { from: y, to: y };
  },
  last7Days: () => ({
    from: dayjs().subtract(6, "day").format("YYYY-MM-DD"),
    to: todayISO(),
  }),
  currentMonth: () => {
    const start = dayjs().startOf("month").format("YYYY-MM-DD");
    return { from: start, to: todayISO() };
  },
  currentFiscalYear: (start: string, end: string) => ({ from: start, to: end }),
};
