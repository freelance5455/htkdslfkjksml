/**
 * Accounting Engine — موتور تولید سند دوبل
 * MR,KHORASANI
 *
 * اصل: هر عملیات → یک Journal Entry متوازن
 * منطق حسابداری در UI پراکنده نمی‌شود.
 */

import type {
  OperationType,
  JournalLine,
  Account,
  FinancialSource,
  Party,
} from "@/types/database";

export interface EngineInput {
  operationType: OperationType;
  amount: number;
  partyId?: string;
  financialSourceId?: string;
  /** حساب هزینه/درآمد در صورت نیاز */
  expenseOrIncomeAccountId?: string;
  /** برای فروش/خرید با موجودی دائمی */
  cogsAmount?: number;
  inventoryAccountId?: string;
  cogsAccountId?: string;
  /** تخفیف و حمل */
  discountAmount?: number;
  shippingCost?: number;
  description?: string;
}

export interface EngineResult {
  lines: Omit<JournalLine, "id" | "journal_id" | "created_at">[];
  description: string;
  isBalanced: boolean;
  totalDebit: number;
  totalCredit: number;
}

/** نگاشت حساب‌های پیش‌فرض بر اساس کد */
export const DEFAULT_ACCOUNT_CODES = {
  cash: "1111",
  banks: "112", // parent
  ar_customers: "1211",
  ap_suppliers: "2111",
  sales: "4111",
  sales_discount: "4131",
  cogs: "5111",
  inventory: "1311",
  purchase_discount: "5211",
  shipping_expense: "6141",
  shipping_income: "4311",
  capital: "3111",
  drawings: "3211",
} as const;

/**
 * تولید ردیف‌های سند بر اساس نوع عملیات
 * این تابع قلب سیستم است.
 */
export function generateJournalLines(
  input: EngineInput,
  resolveAccountId: (code: string) => string | undefined,
  resolveSourceAccountId: (sourceId: string) => string | undefined
): EngineResult {
  const lines: EngineResult["lines"] = [];
  let description = input.description || "";

  const add = (
    accountId: string | undefined,
    debit: number,
    credit: number,
    desc?: string,
    partyId?: string,
    sourceId?: string
  ) => {
    if (!accountId) throw new Error(`حساب یافت نشد برای عملیات ${input.operationType}`);
    if (debit === 0 && credit === 0) return;
    lines.push({
      account_id: accountId,
      party_id: partyId,
      financial_source_id: sourceId,
      debit,
      credit,
      description: desc || description,
      sort_order: lines.length + 1,
    });
  };

  const sourceAccId = input.financialSourceId
    ? resolveSourceAccountId(input.financialSourceId)
    : resolveAccountId(DEFAULT_ACCOUNT_CODES.cash);

  switch (input.operationType) {
    // ─── دریافت از مشتری ───
    case "receipt":
    case "receipt_invoice":
      description = description || "دریافت از مشتری";
      add(sourceAccId, input.amount, 0, "بدهکار منبع مالی", undefined, input.financialSourceId);
      add(
        resolveAccountId(DEFAULT_ACCOUNT_CODES.ar_customers),
        0,
        input.amount,
        "بستانکار حساب دریافتنی",
        input.partyId
      );
      break;

    // ─── پرداخت به تأمین‌کننده ───
    case "payment":
    case "payment_invoice":
      description = description || "پرداخت به تأمین‌کننده";
      add(
        resolveAccountId(DEFAULT_ACCOUNT_CODES.ap_suppliers),
        input.amount,
        0,
        "بدهکار حساب پرداختنی",
        input.partyId
      );
      add(sourceAccId, 0, input.amount, "بستانکار منبع مالی", undefined, input.financialSourceId);
      break;

    // ─── انتقال بین منابع ───
    case "transfer":
      description = description || "انتقال بین منابع مالی";
      // نیاز به دو منبع: مبدأ و مقصد — در نسخه کامل از input جداگانه گرفته می‌شود
      add(sourceAccId, input.amount, 0, "بدهکار مقصد");
      // مبدأ باید جداگانه پاس داده شود
      break;

    // ─── فروش نقدی / بانکی ───
    case "sale":
      description = description || "فروش کالا";
      // بدهکار: منبع مالی یا حساب دریافتنی
      if (input.financialSourceId) {
        add(sourceAccId, input.amount, 0, "بدهکار منبع مالی", undefined, input.financialSourceId);
      } else {
        add(
          resolveAccountId(DEFAULT_ACCOUNT_CODES.ar_customers),
          input.amount,
          0,
          "بدهکار حساب دریافتنی",
          input.partyId
        );
      }
      // بستانکار: فروش
      add(resolveAccountId(DEFAULT_ACCOUNT_CODES.sales), 0, input.amount, "بستانکار فروش");

      // تخفیف فروش
      if (input.discountAmount && input.discountAmount > 0) {
        add(
          resolveAccountId(DEFAULT_ACCOUNT_CODES.sales_discount),
          input.discountAmount,
          0,
          "تخفیف فروش"
        );
        // کاهش مبلغ دریافتنی/نقد
        // در نسخه کامل تعدیل می‌شود
      }

      // بهای تمام‌شده (اگر موجودی دائمی)
      if (input.cogsAmount && input.cogsAmount > 0) {
        add(resolveAccountId(DEFAULT_ACCOUNT_CODES.cogs), input.cogsAmount, 0, "بهای تمام‌شده");
        add(
          resolveAccountId(DEFAULT_ACCOUNT_CODES.inventory),
          0,
          input.cogsAmount,
          "کاهش موجودی"
        );
      }

      // هزینه حمل
      if (input.shippingCost && input.shippingCost > 0) {
        add(
          resolveAccountId(DEFAULT_ACCOUNT_CODES.shipping_expense),
          input.shippingCost,
          0,
          "هزینه حمل"
        );
        // طرف مقابل بسته به سیاست شرکت
      }
      break;

    // ─── خرید ───
    case "purchase":
      description = description || "خرید کالا";
      add(
        resolveAccountId(DEFAULT_ACCOUNT_CODES.inventory),
        input.amount,
        0,
        "بدهکار موجودی کالا"
      );
      if (input.financialSourceId) {
        add(sourceAccId, 0, input.amount, "بستانکار منبع مالی", undefined, input.financialSourceId);
      } else {
        add(
          resolveAccountId(DEFAULT_ACCOUNT_CODES.ap_suppliers),
          0,
          input.amount,
          "بستانکار تأمین‌کننده",
          input.partyId
        );
      }
      if (input.discountAmount && input.discountAmount > 0) {
        add(
          resolveAccountId(DEFAULT_ACCOUNT_CODES.purchase_discount),
          0,
          input.discountAmount,
          "تخفیف خرید"
        );
      }
      if (input.shippingCost && input.shippingCost > 0) {
        add(
          resolveAccountId(DEFAULT_ACCOUNT_CODES.shipping_expense),
          input.shippingCost,
          0,
          "هزینه حمل خرید"
        );
      }
      break;

    // ─── هزینه نقدی/بانکی ───
    case "expense":
      description = description || "ثبت هزینه";
      add(
        input.expenseOrIncomeAccountId || resolveAccountId("6991"),
        input.amount,
        0,
        "بدهکار هزینه"
      );
      add(sourceAccId, 0, input.amount, "بستانکار منبع مالی", undefined, input.financialSourceId);
      break;

    // ─── درآمد ───
    case "income":
      description = description || "ثبت درآمد";
      add(sourceAccId, input.amount, 0, "بدهکار منبع مالی", undefined, input.financialSourceId);
      add(
        input.expenseOrIncomeAccountId || resolveAccountId("4391"),
        0,
        input.amount,
        "بستانکار درآمد"
      );
      break;

    // ─── سند دستی / اصلاحی ───
    case "manual":
    case "adjustment":
      description = description || "سند دستی / اصلاحی";
      // خطوط باید از بیرون پاس داده شوند
      break;

    default:
      throw new Error(`نوع عملیات پشتیبانی نشده: ${input.operationType}`);
  }

  const totalDebit = lines.reduce((s, l) => s + l.debit, 0);
  const totalCredit = lines.reduce((s, l) => s + l.credit, 0);

  return {
    lines,
    description,
    isBalanced: totalDebit === totalCredit,
    totalDebit,
    totalCredit,
  };
}

/** اعتبارسنجی قبل از ثبت */
export function validateOperation(input: EngineInput): string[] {
  const errors: string[] = [];
  if (!input.amount || input.amount <= 0) {
    errors.push("مبلغ باید بزرگ‌تر از صفر باشد");
  }
  if (
    ["receipt", "payment", "receipt_invoice", "payment_invoice"].includes(
      input.operationType
    ) &&
    !input.partyId
  ) {
    errors.push("شخص مرتبط الزامی است");
  }
  if (
    ["receipt", "payment", "expense", "income"].includes(input.operationType) &&
    !input.financialSourceId
  ) {
    errors.push("منبع مالی الزامی است");
  }
  return errors;
}
