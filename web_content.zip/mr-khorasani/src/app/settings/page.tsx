"use client";

import { useState } from "react";
import { PageHeader } from "@/components/layout/PageHeader";
import { BottomNav } from "@/components/layout/BottomNav";
import Link from "next/link";
import { runDemoScenario } from "@/lib/demo-scenario";
import { ConnectionPanel } from "@/components/supabase/ConnectionPanel";

export default function SettingsPage() {
  const [demoMsg, setDemoMsg] = useState("");
  return (
    <div className="min-h-screen bg-slate-50 pb-24">
      <PageHeader title="تنظیمات و درباره" subtitle="MR,KHORASANI" backHref="/" />

      <div className="px-4 mt-4 space-y-4">
        {/* سناریوی تست */}
        <div className="bg-white rounded-xl border border-slate-100 p-4 shadow-sm space-y-2">
          <h3 className="text-sm font-semibold text-slate-800">تست سناریوی کامل</h3>
          <p className="text-xs text-slate-500">
            ثبت خودکار دریافت + هزینه + فروش با سند دوبل برای کنترل تراز
          </p>
          <button
            type="button"
            onClick={() => {
              const r = runDemoScenario();
              setDemoMsg(r.message);
            }}
            className="w-full btn-gold py-2.5 text-sm font-bold rounded-xl"
          >
            اجرای سناریوی نمایشی
          </button>
          {demoMsg && (
            <p className="text-xs text-emerald-700 bg-emerald-50 rounded-lg p-2">{demoMsg}</p>
          )}
        </div>

        <ConnectionPanel />

        {/* برند */}
        <div className="bg-navy-950 text-white rounded-2xl p-6 text-center">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-br from-gold-400 to-gold-600 flex items-center justify-center text-2xl font-bold text-navy-950 mb-3">
            K
          </div>
          <h2 className="text-lg font-bold">MR,KHORASANI</h2>
          <p className="text-gold-400 text-xs mt-1">Financial Management & Accounting</p>
          <p className="text-slate-400 text-xs mt-2">نسخه ۱.۰.۰ · فاز ۶</p>
        </div>

        {/* نصب */}
        <div className="bg-white rounded-xl border border-slate-100 p-4 shadow-sm space-y-3">
          <h3 className="text-sm font-semibold text-slate-800">نصب روی موبایل</h3>
          <div className="text-xs text-slate-600 space-y-2 leading-relaxed">
            <p>
              <strong>PWA:</strong> در Chrome اندروید از منو گزینه «افزودن به صفحه اصلی»
              یا «نصب اپ» را بزنید.
            </p>
            <p>
              <strong>APK:</strong> با Capacitor و Android Studio بسته نصب‌پذیر بسازید.
              راهنما در <code className="bg-slate-100 px-1 rounded">docs/android-build.md</code>
            </p>
          </div>
        </div>

        {/* معماری */}
        <div className="bg-white rounded-xl border border-slate-100 p-4 shadow-sm">
          <h3 className="text-sm font-semibold text-slate-800 mb-2">معماری</h3>
          <ul className="text-xs text-slate-600 space-y-1.5">
            <li>• Next.js 15 + TypeScript + Tailwind</li>
            <li>• Zustand (آماده‌سازی Supabase Offline-First)</li>
            <li>• سند دوبل اتوماتیک + بستن روز + قفل</li>
            <li>• تاریخ شمسی · کدینگ ۴سطحی · ۱۰ بانک ایرانی</li>
            <li>• PWA + Service Worker · Capacitor Android</li>
          </ul>
        </div>

        {/* لینک‌های سریع */}
        <div className="grid grid-cols-2 gap-2">
          <Link
            href="/reports"
            className="text-center py-3 rounded-xl bg-white border border-slate-100 text-sm text-navy-800 font-medium"
          >
            گزارش‌ها
          </Link>
          <Link
            href="/close-day"
            className="text-center py-3 rounded-xl bg-white border border-slate-100 text-sm text-navy-800 font-medium"
          >
            بستن روز
          </Link>
          <Link
            href="/coding"
            className="text-center py-3 rounded-xl bg-white border border-slate-100 text-sm text-navy-800 font-medium"
          >
            کدینگ
          </Link>
          <Link
            href="/operations"
            className="text-center py-3 rounded-xl bg-white border border-slate-100 text-sm text-navy-800 font-medium"
          >
            عملیات
          </Link>
        </div>

        <p className="text-center text-[10px] text-slate-400 pt-4">
          دقت · کنترل · شفافیت
        </p>
      </div>

      <BottomNav />
    </div>
  );
}
