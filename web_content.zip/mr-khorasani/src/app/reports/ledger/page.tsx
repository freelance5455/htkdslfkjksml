"use client";

import { useMemo, useState } from "react";
import { PageHeader } from "@/components/layout/PageHeader";
import { BottomNav } from "@/components/layout/BottomNav";
import { useOperations } from "@/store/operations";
import { ACCOUNT_LABELS, buildAccountLedger } from "@/lib/reports";
import { formatMoney } from "@/lib/utils";
import { todayISO } from "@/lib/date-utils";

export default function LedgerPage() {
  const { journals, journalLines } = useOperations();
  const [accountId, setAccountId] = useState("acc-1111");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState(todayISO());

  const accountOptions = Object.entries(ACCOUNT_LABELS).map(([id, meta]) => ({
    id,
    label: `${meta.code} — ${meta.name}`,
  }));

  const rows = useMemo(
    () =>
      buildAccountLedger(
        accountId,
        journals,
        journalLines,
        fromDate || undefined,
        toDate || undefined
      ),
    [accountId, journals, journalLines, fromDate, toDate]
  );

  const meta = ACCOUNT_LABELS[accountId];
  const totalDebit = rows.reduce((s, r) => s + r.debit, 0);
  const totalCredit = rows.reduce((s, r) => s + r.credit, 0);
  const finalBalance = rows.length > 0 ? rows[rows.length - 1].balance : 0;

  return (
    <div className="min-h-screen bg-slate-50 pb-24">
      <PageHeader
        title="دفتر کل"
        subtitle="گردش حساب"
        backHref="/reports"
      />

      <div className="px-4 mt-4 space-y-3">
        <div className="bg-white rounded-xl border border-slate-100 p-3 space-y-2">
          <div>
            <label className="text-[10px] text-slate-400">حساب</label>
            <select
              value={accountId}
              onChange={(e) => setAccountId(e.target.value)}
              className="w-full px-2 py-2 rounded-lg border border-slate-200 text-sm bg-white"
            >
              {accountOptions.map((o) => (
                <option key={o.id} value={o.id}>
                  {o.label}
                </option>
              ))}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-[10px] text-slate-400">از تاریخ</label>
              <input
                type="date"
                value={fromDate}
                onChange={(e) => setFromDate(e.target.value)}
                className="w-full px-2 py-1.5 rounded-lg border border-slate-200 text-sm"
              />
            </div>
            <div>
              <label className="text-[10px] text-slate-400">تا تاریخ</label>
              <input
                type="date"
                value={toDate}
                onChange={(e) => setToDate(e.target.value)}
                className="w-full px-2 py-1.5 rounded-lg border border-slate-200 text-sm"
              />
            </div>
          </div>
        </div>

        {/* خلاصه حساب */}
        <div className="bg-navy-900 text-white rounded-xl p-4">
          <div className="text-xs text-slate-300">
            {meta?.code} — {meta?.name}
          </div>
          <div className="text-xl font-bold text-gold-400 mt-1">
            {formatMoney(finalBalance)}
          </div>
          <div className="flex gap-4 mt-2 text-xs text-slate-400">
            <span>بدهکار: {formatMoney(totalDebit)}</span>
            <span>بستانکار: {formatMoney(totalCredit)}</span>
          </div>
        </div>

        <div className="space-y-2">
          {rows.length === 0 ? (
            <div className="text-center py-12 text-slate-400 text-sm">
              گردشی برای این حساب نیست
            </div>
          ) : (
            rows.map((r, i) => (
              <div
                key={i}
                className="bg-white rounded-xl border border-slate-100 p-3 shadow-sm"
              >
                <div className="flex justify-between text-xs text-slate-400 mb-1">
                  <span className="font-mono">{r.journalNumber}</span>
                  <span>{r.dateJalali}</span>
                </div>
                <div className="text-sm text-slate-700 mb-2">{r.description}</div>
                <div className="flex justify-between text-xs">
                  <span className="text-emerald-700">
                    بد: {r.debit > 0 ? formatMoney(r.debit) : "—"}
                  </span>
                  <span className="text-red-600">
                    بس: {r.credit > 0 ? formatMoney(r.credit) : "—"}
                  </span>
                  <span className="font-bold text-navy-800">
                    مانده: {formatMoney(r.balance)}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      <BottomNav />
    </div>
  );
}
