"use client";

import { useMemo } from "react";
import { PageHeader } from "@/components/layout/PageHeader";
import { BottomNav } from "@/components/layout/BottomNav";
import { useOperations } from "@/store/operations";
import { useMasterData } from "@/store/master-data";
import { buildKPI, buildProfitLoss } from "@/lib/reports";
import { formatMoney } from "@/lib/utils";
import { todayISO, todayJalali } from "@/lib/date-utils";

export default function KPIPage() {
  const { operations, journals, journalLines } = useOperations();
  const { parties, getActiveSources } = useMasterData();

  const liquidity = getActiveSources().reduce((s, src) => s + src.current_balance, 0);
  const kpi = useMemo(
    () => buildKPI(operations, liquidity, parties, todayISO()),
    [operations, liquidity, parties]
  );
  const pl = useMemo(
    () => buildProfitLoss(journals, journalLines),
    [journals, journalLines]
  );

  return (
    <div className="min-h-screen bg-slate-50 pb-24">
      <PageHeader
        title="داشبورد KPI"
        subtitle={todayJalali()}
        backHref="/reports"
      />

      <div className="px-4 mt-4 space-y-4">
        {/* ردیف اول */}
        <div className="grid grid-cols-2 gap-3">
          <KPICard
            label="فروش امروز"
            value={kpi.salesToday}
            color="blue"
          />
          <KPICard
            label="فروش ماه"
            value={kpi.salesMonth}
            color="navy"
          />
          <KPICard
            label="دریافت امروز"
            value={kpi.receiptsToday}
            color="green"
          />
          <KPICard
            label="پرداخت امروز"
            value={kpi.paymentsToday}
            color="red"
          />
        </div>

        {/* نقدینگی و خالص */}
        <div className="bg-gradient-to-br from-navy-900 to-navy-800 rounded-2xl p-5 text-white">
          <div className="text-xs text-slate-300 mb-1">جمع نقدینگی</div>
          <div className="text-2xl font-bold text-gold-400">
            {formatMoney(kpi.totalLiquidity)}
          </div>
          <div className="flex gap-6 mt-4 text-sm">
            <div>
              <div className="text-xs text-slate-400">خالص جریان امروز</div>
              <div
                className={`font-bold ${
                  kpi.netCashToday >= 0 ? "text-emerald-400" : "text-red-400"
                }`}
              >
                {formatMoney(kpi.netCashToday)}
              </div>
            </div>
            <div>
              <div className="text-xs text-slate-400">عملیات امروز</div>
              <div className="font-bold">{kpi.operationsCount}</div>
            </div>
          </div>
        </div>

        {/* مطالبات و بدهی */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-white rounded-xl border border-slate-100 p-4 shadow-sm">
            <div className="text-xs text-slate-400 mb-1">مطالبات (بدهکاران)</div>
            <div className="text-lg font-bold text-amber-600">
              {formatMoney(kpi.totalReceivables)}
            </div>
          </div>
          <div className="bg-white rounded-xl border border-slate-100 p-4 shadow-sm">
            <div className="text-xs text-slate-400 mb-1">بدهی‌ها (بستانکاران)</div>
            <div className="text-lg font-bold text-purple-600">
              {formatMoney(kpi.totalPayables)}
            </div>
          </div>
        </div>

        {/* سودآوری */}
        <div className="bg-white rounded-xl border border-slate-100 p-4 shadow-sm">
          <h3 className="text-sm font-semibold text-slate-700 mb-3">سودآوری (کل دوره)</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-slate-500">فروش خالص</span>
              <span className="font-mono">{formatMoney(pl.netSales)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">سود ناخالص</span>
              <span className="font-mono">{formatMoney(pl.grossProfit)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">هزینه‌ها</span>
              <span className="font-mono text-red-600">
                {formatMoney(pl.expenses)}
              </span>
            </div>
            <div className="flex justify-between pt-2 border-t border-slate-100 font-bold">
              <span className="text-slate-800">سود خالص تقریبی</span>
              <span
                className={`font-mono ${
                  pl.netProfit >= 0 ? "text-emerald-600" : "text-red-600"
                }`}
              >
                {formatMoney(pl.netProfit)}
              </span>
            </div>
          </div>
        </div>

        <p className="text-[10px] text-slate-400 text-center">
          KPIها به‌صورت زنده از عملیات و اسناد دوبل به‌روز می‌شوند
        </p>
      </div>

      <BottomNav />
    </div>
  );
}

function KPICard({
  label,
  value,
  color,
}: {
  label: string;
  value: number;
  color: "blue" | "navy" | "green" | "red";
}) {
  const colors = {
    blue: "text-blue-700",
    navy: "text-navy-800",
    green: "text-emerald-600",
    red: "text-red-600",
  };
  return (
    <div className="bg-white rounded-xl border border-slate-100 p-4 shadow-sm">
      <div className="text-xs text-slate-400 mb-1">{label}</div>
      <div className={`text-base font-bold ${colors[color]}`}>
        {formatMoney(value)}
      </div>
    </div>
  );
}
