"use client";

import Link from "next/link";
import { PageHeader } from "@/components/layout/PageHeader";
import { BottomNav } from "@/components/layout/BottomNav";

const REPORTS = [
  {
    href: "/reports/trial-balance",
    icon: "⚖️",
    title: "تراز آزمایشی",
    desc: "۲ / ۴ / ۶ ستونه — کنترل توازن",
  },
  {
    href: "/reports/journal",
    icon: "📒",
    title: "دفتر روزنامه",
    desc: "اسناد به ترتیب تاریخ",
  },
  {
    href: "/reports/ledger",
    icon: "📘",
    title: "دفتر کل",
    desc: "گردش هر حساب",
  },
  {
    href: "/reports/profit-loss",
    icon: "📈",
    title: "سود و زیان",
    desc: "فروش، بهای تمام‌شده، سود تقریبی",
  },
  {
    href: "/reports/kpi",
    icon: "🎯",
    title: "داشبورد KPI",
    desc: "فروش، وصول، نقدینگی، مطالبات",
  },
  {
    href: "/sources",
    icon: "💧",
    title: "نقدینگی",
    desc: "موجودی صندوق و بانک‌ها",
  },
];

export default function ReportsIndexPage() {
  return (
    <div className="min-h-screen bg-slate-50 pb-24">
      <PageHeader
        title="گزارش‌ها"
        subtitle="حسابداری · مدیریتی · KPI"
        backHref="/"
      />

      <div className="px-4 mt-4 grid grid-cols-1 gap-3">
        {REPORTS.map((r) => (
          <Link
            key={r.href}
            href={r.href}
            className="bg-white rounded-xl border border-slate-100 p-4 shadow-sm flex items-center gap-4 hover:border-navy-200 transition"
          >
            <div className="text-3xl">{r.icon}</div>
            <div className="min-w-0 flex-1">
              <div className="font-semibold text-slate-800 text-sm">{r.title}</div>
              <div className="text-xs text-slate-400 mt-0.5">{r.desc}</div>
            </div>
            <span className="text-slate-300">←</span>
          </Link>
        ))}
      </div>

      <p className="text-center text-xs text-slate-400 mt-8 px-4">
        همه گزارش‌ها از اسناد دوبل تولید می‌شوند — مسیر حسابرسی حفظ شده است
      </p>

      <BottomNav />
    </div>
  );
}
