"use client";

import { useMemo, useState } from "react";
import { PageHeader } from "@/components/layout/PageHeader";
import { BottomNav } from "@/components/layout/BottomNav";
import { useOperations } from "@/store/operations";
import {
  buildTrialBalance,
  trialBalanceTotals,
} from "@/lib/reports";
import { formatMoney } from "@/lib/utils";
import { todayISO, toJalali } from "@/lib/date-utils";

type Mode = "2" | "4" | "6";

export default function TrialBalancePage() {
  const { journals, journalLines } = useOperations();
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState(todayISO());
  const [mode, setMode] = useState<Mode>("4");

  const rows = useMemo(
    () => buildTrialBalance(journals, journalLines, fromDate || undefined, toDate || undefined),
    [journals, journalLines, fromDate, toDate]
  );
  const totals = trialBalanceTotals(rows);
  const balanced =
    totals.periodDebit === totals.periodCredit &&
    totals.closingDebit === totals.closingCredit;

  return (
    <div className="min-h-screen bg-slate-50 pb-24">
      <PageHeader
        title="تراز آزمایشی"
        subtitle="کنترل توازن حساب‌ها"
        backHref="/reports"
      />

      <div className="px-4 mt-4 space-y-3">
        {/* فیلتر */}
        <div className="bg-white rounded-xl border border-slate-100 p-3 space-y-2">
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-[10px] text-slate-400">از تاریخ</label>
              <input
                type="date"
                value={fromDate}
                onChange={(e) => setFromDate(e.target.value)}
                className="w-full px-2 py-1.5 rounded-lg border border-slate-200 text-sm"
              />
            </div>
            <div>
              <label className="text-[10px] text-slate-400">تا تاریخ</label>
              <input
                type="date"
                value={toDate}
                onChange={(e) => setToDate(e.target.value)}
                className="w-full px-2 py-1.5 rounded-lg border border-slate-200 text-sm"
              />
            </div>
          </div>
          <div className="flex gap-2">
            {(["2", "4", "6"] as Mode[]).map((m) => (
              <button
                key={m}
                onClick={() => setMode(m)}
                className={`flex-1 py-1.5 rounded-lg text-xs font-medium ${
                  mode === m
                    ? "bg-navy-800 text-white"
                    : "bg-slate-100 text-slate-600"
                }`}
              >
                {m} ستونه
              </button>
            ))}
          </div>
          {toDate && (
            <div className="text-[10px] text-slate-400">
              تا {toJalali(toDate)}
              {fromDate && ` · از ${toJalali(fromDate)}`}
            </div>
          )}
        </div>

        {/* وضعیت توازن */}
        <div
          className={`rounded-xl px-4 py-2.5 text-sm font-medium ${
            balanced
              ? "bg-emerald-50 text-emerald-700 border border-emerald-100"
              : "bg-red-50 text-red-600 border border-red-100"
          }`}
        >
          {balanced
            ? "✓ تراز متوازن است — اختلاف = ۰"
            : `⚠ اختلاف: ${formatMoney(
                Math.abs(totals.periodDebit - totals.periodCredit)
              )}`}
        </div>

        {/* جدول */}
        <div className="bg-white rounded-xl border border-slate-100 overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-navy-900 text-white">
                  <th className="text-right px-2 py-2.5 font-medium">کد</th>
                  <th className="text-right px-2 py-2.5 font-medium">نام حساب</th>
                  {(mode === "4" || mode === "6") && (
                    <>
                      <th className="text-left px-2 py-2.5 font-medium">گردش بدهکار</th>
                      <th className="text-left px-2 py-2.5 font-medium">گردش بستانکار</th>
                    </>
                  )}
                  {(mode === "2" || mode === "6") && (
                    <>
                      <th className="text-left px-2 py-2.5 font-medium">مانده بدهکار</th>
                      <th className="text-left px-2 py-2.5 font-medium">مانده بستانکار</th>
                    </>
                  )}
                  {mode === "4" && (
                    <>
                      <th className="text-left px-2 py-2.5 font-medium">مانده بدهکار</th>
                      <th className="text-left px-2 py-2.5 font-medium">مانده بستانکار</th>
                    </>
                  )}
                </tr>
              </thead>
              <tbody>
                {rows.length === 0 ? (
                  <tr>
                    <td
                      colSpan={6}
                      className="text-center py-10 text-slate-400"
                    >
                      سند ثبت‌شده‌ای در این بازه نیست
                    </td>
                  </tr>
                ) : (
                  rows.map((r) => (
                    <tr
                      key={r.account_id}
                      className="border-b border-slate-50 hover:bg-slate-50"
                    >
                      <td className="px-2 py-2 font-mono text-slate-500">
                        {r.code}
                      </td>
                      <td className="px-2 py-2 text-slate-800">{r.name_fa}</td>
                      {(mode === "4" || mode === "6") && (
                        <>
                          <td className="px-2 py-2 text-left font-mono">
                            {r.period_debit > 0 ? formatMoney(r.period_debit) : "—"}
                          </td>
                          <td className="px-2 py-2 text-left font-mono">
                            {r.period_credit > 0
                              ? formatMoney(r.period_credit)
                              : "—"}
                          </td>
                        </>
                      )}
                      {(mode === "2" || mode === "4" || mode === "6") && (
                        <>
                          <td className="px-2 py-2 text-left font-mono text-navy-800">
                            {r.closing_debit > 0
                              ? formatMoney(r.closing_debit)
                              : "—"}
                          </td>
                          <td className="px-2 py-2 text-left font-mono text-navy-800">
                            {r.closing_credit > 0
                              ? formatMoney(r.closing_credit)
                              : "—"}
                          </td>
                        </>
                      )}
                    </tr>
                  ))
                )}
              </tbody>
              {rows.length > 0 && (
                <tfoot>
                  <tr className="bg-navy-50 font-bold text-navy-900">
                    <td className="px-2 py-2.5" colSpan={2}>
                      جمع
                    </td>
                    {(mode === "4" || mode === "6") && (
                      <>
                        <td className="px-2 py-2.5 text-left font-mono">
                          {formatMoney(totals.periodDebit)}
                        </td>
                        <td className="px-2 py-2.5 text-left font-mono">
                          {formatMoney(totals.periodCredit)}
                        </td>
                      </>
                    )}
                    <td className="px-2 py-2.5 text-left font-mono">
                      {formatMoney(totals.closingDebit)}
                    </td>
                    <td className="px-2 py-2.5 text-left font-mono">
                      {formatMoney(totals.closingCredit)}
                    </td>
                  </tr>
                </tfoot>
              )}
            </table>
          </div>
        </div>

        <p className="text-[10px] text-slate-400 text-center">
          تراز از ردیف‌های اسناد دوبل ساخته شده — اختلاف باید همیشه صفر باشد
        </p>
      </div>

      <BottomNav />
    </div>
  );
}
