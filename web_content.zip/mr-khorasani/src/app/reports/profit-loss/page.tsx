"use client";

import { useMemo, useState } from "react";
import { PageHeader } from "@/components/layout/PageHeader";
import { BottomNav } from "@/components/layout/BottomNav";
import { useOperations } from "@/store/operations";
import { buildProfitLoss } from "@/lib/reports";
import { formatMoney } from "@/lib/utils";
import { todayISO, toJalali } from "@/lib/date-utils";

export default function ProfitLossPage() {
  const { journals, journalLines } = useOperations();
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState(todayISO());

  const pl = useMemo(
    () =>
      buildProfitLoss(
        journals,
        journalLines,
        fromDate || undefined,
        toDate || undefined
      ),
    [journals, journalLines, fromDate, toDate]
  );

  return (
    <div className="min-h-screen bg-slate-50 pb-24">
      <PageHeader
        title="سود و زیان"
        subtitle="گزارش مدیریتی تقریبی"
        backHref="/reports"
      />

      <div className="px-4 mt-4 space-y-3">
        <div className="bg-white rounded-xl border border-slate-100 p-3 grid grid-cols-2 gap-2">
          <div>
            <label className="text-[10px] text-slate-400">از تاریخ</label>
            <input
              type="date"
              value={fromDate}
              onChange={(e) => setFromDate(e.target.value)}
              className="w-full px-2 py-1.5 rounded-lg border border-slate-200 text-sm"
            />
          </div>
          <div>
            <label className="text-[10px] text-slate-400">تا تاریخ</label>
            <input
              type="date"
              value={toDate}
              onChange={(e) => setToDate(e.target.value)}
              className="w-full px-2 py-1.5 rounded-lg border border-slate-200 text-sm"
            />
          </div>
        </div>

        {/* نتیجه نهایی */}
        <div
          className={`rounded-2xl p-5 text-center ${
            pl.netProfit >= 0
              ? "bg-gradient-to-br from-emerald-600 to-emerald-800"
              : "bg-gradient-to-br from-red-600 to-red-800"
          } text-white`}
        >
          <div className="text-xs opacity-80 mb-1">سود / زیان خالص تقریبی</div>
          <div className="text-2xl font-bold">
            {formatMoney(Math.abs(pl.netProfit))}
            <span className="text-sm font-normal opacity-80 mr-1">ریال</span>
          </div>
          <div className="text-xs mt-1 opacity-80">
            {pl.netProfit >= 0 ? "سود" : "زیان"}
            {toDate && ` · تا ${toJalali(toDate)}`}
          </div>
        </div>

        {/* جزئیات */}
        <div className="bg-white rounded-xl border border-slate-100 divide-y divide-slate-50 overflow-hidden">
          <PLRow label="فروش" value={pl.sales} />
          <PLRow label="تخفیفات فروش" value={-pl.salesDiscount} muted />
          <PLRow label="فروش خالص" value={pl.netSales} bold />
          <PLRow label="بهای تمام‌شده" value={-pl.cogs} muted />
          <PLRow label="سود ناخالص" value={pl.grossProfit} bold />
          <PLRow label="هزینه‌ها" value={-pl.expenses} muted />
          <PLRow label="سایر درآمدها" value={pl.otherIncome} />
          <PLRow label="سود / زیان خالص" value={pl.netProfit} bold highlight />
        </div>

        <p className="text-[10px] text-slate-400 text-center px-2">
          این گزارش از گردش حساب‌های درآمد، بهای تمام‌شده و هزینه در اسناد دوبل
          محاسبه شده است. برای بهای تمام‌شده دقیق، ثبت موجودی دائمی لازم است.
        </p>
      </div>

      <BottomNav />
    </div>
  );
}

function PLRow({
  label,
  value,
  bold,
  muted,
  highlight,
}: {
  label: string;
  value: number;
  bold?: boolean;
  muted?: boolean;
  highlight?: boolean;
}) {
  return (
    <div
      className={`flex justify-between px-4 py-3 text-sm ${
        highlight ? "bg-navy-50" : ""
      }`}
    >
      <span
        className={
          bold ? "font-semibold text-slate-800" : muted ? "text-slate-500" : "text-slate-700"
        }
      >
        {label}
      </span>
      <span
        className={`font-mono ${
          bold || highlight
            ? "font-bold text-navy-900"
            : value < 0
            ? "text-red-600"
            : "text-slate-800"
        }`}
      >
        {formatMoney(value)}
      </span>
    </div>
  );
}
