"use client";

import { useMemo, useState } from "react";
import { PageHeader } from "@/components/layout/PageHeader";
import { BottomNav } from "@/components/layout/BottomNav";
import { useOperations } from "@/store/operations";
import { buildJournalBook } from "@/lib/reports";
import { formatMoney } from "@/lib/utils";
import { todayISO, toJalali } from "@/lib/date-utils";

export default function JournalBookPage() {
  const { journals, journalLines, operations } = useOperations();
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState(todayISO());

  const rows = useMemo(
    () =>
      buildJournalBook(
        journals,
        journalLines,
        operations,
        fromDate || undefined,
        toDate || undefined
      ),
    [journals, journalLines, operations, fromDate, toDate]
  );

  const totalDebit = rows.reduce((s, r) => s + r.debit, 0);
  const totalCredit = rows.reduce((s, r) => s + r.credit, 0);

  return (
    <div className="min-h-screen bg-slate-50 pb-24">
      <PageHeader
        title="دفتر روزنامه"
        subtitle="اسناد به ترتیب تاریخ"
        backHref="/reports"
      />

      <div className="px-4 mt-4 space-y-3">
        <div className="bg-white rounded-xl border border-slate-100 p-3 grid grid-cols-2 gap-2">
          <div>
            <label className="text-[10px] text-slate-400">از تاریخ</label>
            <input
              type="date"
              value={fromDate}
              onChange={(e) => setFromDate(e.target.value)}
              className="w-full px-2 py-1.5 rounded-lg border border-slate-200 text-sm"
            />
          </div>
          <div>
            <label className="text-[10px] text-slate-400">تا تاریخ</label>
            <input
              type="date"
              value={toDate}
              onChange={(e) => setToDate(e.target.value)}
              className="w-full px-2 py-1.5 rounded-lg border border-slate-200 text-sm"
            />
          </div>
        </div>

        <div className="flex justify-between text-xs text-slate-500 px-1">
          <span>{rows.length} ردیف</span>
          <span>
            بدهکار {formatMoney(totalDebit)} · بستانکار {formatMoney(totalCredit)}
          </span>
        </div>

        <div className="space-y-2">
          {rows.length === 0 ? (
            <div className="text-center py-12 text-slate-400 text-sm">
              سندی در این بازه نیست
            </div>
          ) : (
            rows.map((r, i) => (
              <div
                key={`${r.journalNumber}-${i}`}
                className="bg-white rounded-xl border border-slate-100 p-3 shadow-sm"
              >
                <div className="flex justify-between items-start gap-2">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 text-xs">
                      <span className="font-mono text-navy-700 font-medium">
                        {r.journalNumber}
                      </span>
                      <span className="text-slate-400">{r.journalDateJalali}</span>
                    </div>
                    <div className="text-sm text-slate-800 mt-1">
                      {r.accountCode} — {r.accountName}
                    </div>
                    <div className="text-xs text-slate-400 mt-0.5 truncate">
                      {r.description}
                      {r.operationNumber && ` · ${r.operationNumber}`}
                    </div>
                  </div>
                  <div className="text-left shrink-0 text-xs space-y-0.5">
                    {r.debit > 0 && (
                      <div className="text-emerald-700 font-mono">
                        بد {formatMoney(r.debit)}
                      </div>
                    )}
                    {r.credit > 0 && (
                      <div className="text-red-600 font-mono">
                        بس {formatMoney(r.credit)}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      <BottomNav />
    </div>
  );
}
