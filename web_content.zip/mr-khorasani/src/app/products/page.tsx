"use client";

import { useState } from "react";
import { PageHeader } from "@/components/layout/PageHeader";
import { BottomNav } from "@/components/layout/BottomNav";
import { useMasterData } from "@/store/master-data";
import { formatMoney } from "@/lib/utils";
import { CSVImportButton } from "@/components/import/CSVImportButton";

export default function ProductsPage() {
  const {
    products,
    searchProducts,
    softDeleteProduct,
    addProduct,
    checkProductDuplicate,
  } = useMasterData();
  const [query, setQuery] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [formError, setFormError] = useState("");
  const [form, setForm] = useState({
    code: "",
    name: "",
    barcode: "",
    unit: "عدد",
    category: "",
    purchase_price: "",
    sale_price: "",
    description: "",
  });

  const filtered = searchProducts(query);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError("");
    if (!form.code.trim() || !form.name.trim()) {
      setFormError("کد و نام کالا الزامی است");
      return;
    }
    const dup = checkProductDuplicate({
      code: form.code,
      barcode: form.barcode || undefined,
      name: form.name,
    });
    if (dup && !dup.includes("هشدار")) {
      setFormError(dup);
      return;
    }
    if (dup?.includes("هشدار") && !confirm(dup + " — ادامه می‌دهید؟")) return;

    addProduct({
      code: form.code.trim(),
      name: form.name.trim(),
      barcode: form.barcode || undefined,
      unit: form.unit || "عدد",
      category: form.category || undefined,
      purchase_price: Number(form.purchase_price) || 0,
      sale_price: Number(form.sale_price) || 0,
      description: form.description || undefined,
      is_active: true,
    });
    setShowForm(false);
    setForm({
      code: "",
      name: "",
      barcode: "",
      unit: "عدد",
      category: "",
      purchase_price: "",
      sale_price: "",
      description: "",
    });
  };

  return (
    <div className="min-h-screen bg-slate-50 pb-24">
      <PageHeader
        title="کالاها"
        subtitle={`${filtered.length} کالا`}
        backHref="/"
        action={
          <button
            onClick={() => setShowForm(true)}
            className="bg-gold-500 text-navy-950 text-xs font-bold px-3 py-1.5 rounded-lg"
          >
            + جدید
          </button>
        }
      />

      <div className="p-4 space-y-3">
        <CSVImportButton type="products" />
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="جستجو: نام، کد، بارکد..."
          className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-navy-500/30 bg-white"
        />
      </div>

      <div className="px-4 space-y-2">
        {filtered.length === 0 ? (
          <div className="text-center py-12 text-slate-400 text-sm">
            کالایی یافت نشد
          </div>
        ) : (
          filtered.map((p) => (
            <div
              key={p.id}
              className="bg-white rounded-xl border border-slate-100 p-4 shadow-sm"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-slate-800 truncate">
                      {p.name}
                    </span>
                    <span className="text-xs text-slate-400 font-mono">
                      {p.code}
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-2 mt-1.5 text-xs text-slate-500">
                    {p.category && (
                      <span className="bg-slate-100 px-2 py-0.5 rounded">
                        {p.category}
                      </span>
                    )}
                    <span>{p.unit}</span>
                    {p.barcode && (
                      <span className="font-mono dir-ltr">{p.barcode}</span>
                    )}
                  </div>
                </div>
                <div className="text-left shrink-0 space-y-1">
                  <div className="text-sm font-bold text-navy-800">
                    {formatMoney(p.sale_price)}
                  </div>
                  <div className="text-[10px] text-slate-400">
                    خرید: {formatMoney(p.purchase_price)}
                  </div>
                </div>
              </div>
              <div className="flex gap-2 mt-3 pt-2 border-t border-slate-50">
                <button
                  onClick={() => {
                    if (confirm(`حذف منطقی «${p.name}»؟`)) softDeleteProduct(p.id);
                  }}
                  className="text-xs text-red-500"
                >
                  حذف
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {showForm && (
        <div className="fixed inset-0 z-50 bg-black/40 flex items-end sm:items-center justify-center">
          <div className="bg-white w-full max-w-md rounded-t-2xl sm:rounded-2xl max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-navy-950 text-white px-4 py-3 flex items-center justify-between rounded-t-2xl">
              <h2 className="font-bold">کالای جدید</h2>
              <button onClick={() => setShowForm(false)} className="text-slate-300 text-xl">
                ×
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-4 space-y-3">
              {formError && (
                <div className="bg-red-50 text-red-600 text-sm px-3 py-2 rounded-lg">
                  {formError}
                </div>
              )}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-slate-500 mb-1 block">کد کالا *</label>
                  <input
                    required
                    value={form.code}
                    onChange={(e) => setForm({ ...form, code: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm"
                    placeholder="K001"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-500 mb-1 block">واحد</label>
                  <select
                    value={form.unit}
                    onChange={(e) => setForm({ ...form, unit: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm"
                  >
                    <option>عدد</option>
                    <option>کیلوگرم</option>
                    <option>متر</option>
                    <option>لیتر</option>
                    <option>بسته</option>
                    <option>کارتن</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="text-xs text-slate-500 mb-1 block">نام کالا *</label>
                <input
                  required
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm"
                />
              </div>
              <div>
                <label className="text-xs text-slate-500 mb-1 block">بارکد</label>
                <input
                  value={form.barcode}
                  onChange={(e) => setForm({ ...form, barcode: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm dir-ltr"
                />
              </div>
              <div>
                <label className="text-xs text-slate-500 mb-1 block">دسته‌بندی</label>
                <input
                  value={form.category}
                  onChange={(e) => setForm({ ...form, category: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm"
                  placeholder="الکترونیک، مواد غذایی..."
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-slate-500 mb-1 block">قیمت خرید</label>
                  <input
                    type="number"
                    value={form.purchase_price}
                    onChange={(e) =>
                      setForm({ ...form, purchase_price: e.target.value })
                    }
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-500 mb-1 block">قیمت فروش</label>
                  <input
                    type="number"
                    value={form.sale_price}
                    onChange={(e) =>
                      setForm({ ...form, sale_price: e.target.value })
                    }
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm"
                  />
                </div>
              </div>
              <button type="submit" className="w-full btn-primary py-3 mt-2">
                ذخیره کالا
              </button>
            </form>
          </div>
        </div>
      )}

      <BottomNav />
    </div>
  );
}
