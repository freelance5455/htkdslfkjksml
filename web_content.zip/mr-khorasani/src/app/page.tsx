"use client";

import Link from "next/link";
import { BottomNav } from "@/components/layout/BottomNav";
import { useMasterData } from "@/store/master-data";
import { formatMoney } from "@/lib/utils";

export default function HomePage() {
  const { parties, products, getActiveSources } = useMasterData();
  const sources = getActiveSources();
  const totalLiquidity = sources.reduce((s, src) => s + src.current_balance, 0);
  const activeParties = parties.filter((p) => p.is_active && !p.deleted_at).length;
  const activeProducts = products.filter((p) => p.is_active && !p.deleted_at).length;

  return (
    <div className="min-h-screen bg-slate-50 pb-24">
      {/* هدر برند */}
      <header className="bg-gradient-to-br from-navy-950 via-navy-900 to-navy-800 text-white px-5 pt-8 pb-10">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-xl font-bold tracking-tight">MR,KHORASANI</h1>
            <p className="text-gold-400 text-xs mt-0.5">
              Financial Management & Accounting
            </p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-gold-400 to-gold-600 flex items-center justify-center shadow-lg shadow-gold-500/20">
            <span className="text-lg font-bold text-navy-950">K</span>
          </div>
        </div>

        {/* کارت نقدینگی */}
        <div className="bg-white/10 backdrop-blur rounded-2xl p-4 border border-white/10">
          <div className="text-xs text-slate-300 mb-1">جمع کل نقدینگی</div>
          <div className="text-2xl font-bold text-gold-400">
            {formatMoney(totalLiquidity)}
            <span className="text-sm font-normal text-slate-300 mr-1">ریال</span>
          </div>
          <div className="flex gap-4 mt-3 text-xs text-slate-300">
            <span>{activeParties} شخص</span>
            <span>{activeProducts} کالا</span>
            <span>{sources.length} منبع مالی</span>
          </div>
        </div>
      </header>

      {/* دسترسی سریع */}
      <div className="px-4 -mt-5">
        <div className="grid grid-cols-2 gap-3">
          <Link
            href="/parties"
            className="bg-white rounded-xl p-4 shadow-sm border border-slate-100 hover:border-navy-200 transition"
          >
            <div className="text-2xl mb-2">👥</div>
            <div className="font-semibold text-slate-800 text-sm">اشخاص</div>
            <div className="text-xs text-slate-400 mt-0.5">
              مشتری، تأمین‌کننده، کارمند
            </div>
          </Link>
          <Link
            href="/products"
            className="bg-white rounded-xl p-4 shadow-sm border border-slate-100 hover:border-navy-200 transition"
          >
            <div className="text-2xl mb-2">📦</div>
            <div className="font-semibold text-slate-800 text-sm">کالاها</div>
            <div className="text-xs text-slate-400 mt-0.5">
              تعریف و جستجوی کالا
            </div>
          </Link>
          <Link
            href="/sources"
            className="bg-white rounded-xl p-4 shadow-sm border border-slate-100 hover:border-navy-200 transition"
          >
            <div className="text-2xl mb-2">🏦</div>
            <div className="font-semibold text-slate-800 text-sm">منابع مالی</div>
            <div className="text-xs text-slate-400 mt-0.5">
              صندوق + ۱۰ بانک ایرانی
            </div>
          </Link>
          <Link
            href="/coding"
            className="bg-white rounded-xl p-4 shadow-sm border border-slate-100 hover:border-navy-200 transition"
          >
            <div className="text-2xl mb-2">📊</div>
            <div className="font-semibold text-slate-800 text-sm">کدینگ</div>
            <div className="text-xs text-slate-400 mt-0.5">
              حساب‌های ۴سطحی
            </div>
          </Link>
          <Link
            href="/close-day"
            className="bg-white rounded-xl p-4 shadow-sm border border-slate-100 hover:border-navy-200 transition col-span-2"
          >
            <div className="text-2xl mb-2">🔒</div>
            <div className="font-semibold text-slate-800 text-sm">بستن روز</div>
            <div className="text-xs text-slate-400 mt-0.5">
              کنترل · قفل اسناد · Backup · اصلاحی
            </div>
          </Link>
        </div>
      </div>

      {/* وضعیت فازها */}
      <div className="px-4 mt-6">
        <h2 className="text-sm font-semibold text-slate-600 mb-3">وضعیت پروژه</h2>
        <div className="bg-white rounded-xl border border-slate-100 divide-y divide-slate-50 overflow-hidden">
          <PhaseRow num={1} title="Schema + کدینگ + Engine" status="done" />
          <PhaseRow num={2} title="Master Data (اشخاص، کالا، منابع)" status="done" />
          <PhaseRow num={3} title="عملیات روزانه + سند دوبل" status="done" />
          <PhaseRow num={4} title="بستن روز + قفل + اصلاحی" status="done" />
          <PhaseRow num={5} title="گزارش‌ها + تراز + KPI" status="done" />
          <PhaseRow num={6} title="PWA + Capacitor Android" status="done" />
        </div>
      </div>

      <div className="px-4 mt-4 grid grid-cols-2 gap-2">
        <Link
          href="/operations/new"
          className="block text-center btn-gold py-3 text-xs font-bold rounded-xl"
        >
          + عملیات
        </Link>
        <Link
          href="/reports"
          className="block text-center bg-white border border-navy-200 text-navy-800 py-3 text-xs font-bold rounded-xl"
        >
          گزارش‌ها
        </Link>
        <Link
          href="/close-day"
          className="block text-center btn-primary py-3 text-xs font-bold rounded-xl"
        >
          بستن روز
        </Link>
        <Link
          href="/settings"
          className="block text-center bg-slate-100 text-slate-700 py-3 text-xs font-bold rounded-xl"
        >
          تنظیمات / نصب
        </Link>
      </div>

      <p className="text-center text-xs text-slate-400 mt-6 mb-4">
        هر ۶ فاز تکمیل شد — سیستم آماده استفاده و بسته‌بندی Android است
      </p>

      <BottomNav />

    </div>
  );
}

function PhaseRow({
  num,
  title,
  status,
}: {
  num: number;
  title: string;
  status: "done" | "next" | "pending";
}) {
  const colors = {
    done: "bg-emerald-50 text-emerald-700",
    next: "bg-gold-50 text-gold-800",
    pending: "bg-slate-50 text-slate-400",
  };
  const labels = {
    done: "✓ انجام شد",
    next: "→ بعدی",
    pending: "در انتظار",
  };
  return (
    <div className="flex items-center justify-between px-4 py-3">
      <div className="flex items-center gap-3">
        <span className="w-6 h-6 rounded-full bg-navy-100 text-navy-800 text-xs font-bold flex items-center justify-center">
          {num}
        </span>
        <span className="text-sm text-slate-700">{title}</span>
      </div>
      <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${colors[status]}`}>
        {labels[status]}
      </span>
    </div>
  );
}
