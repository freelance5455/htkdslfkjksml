"use client";

import { useState } from "react";
import { PageHeader } from "@/components/layout/PageHeader";
import { BottomNav } from "@/components/layout/BottomNav";
import { useMasterData } from "@/store/master-data";
import { PARTY_TYPE_LABELS } from "@/lib/mock-data";
import { formatMoney } from "@/lib/utils";
import type { PartyType } from "@/types/database";
import { CSVImportButton } from "@/components/import/CSVImportButton";

const TYPE_FILTERS: { key: PartyType | "all"; label: string }[] = [
  { key: "all", label: "همه" },
  { key: "customer", label: "مشتری" },
  { key: "supplier", label: "تأمین‌کننده" },
  { key: "employee", label: "کارمند" },
  { key: "partner", label: "شریک" },
];

export default function PartiesPage() {
  const { parties, searchParties, softDeleteParty, addParty, checkPartyDuplicate } =
    useMasterData();
  const [query, setQuery] = useState("");
  const [typeFilter, setTypeFilter] = useState<PartyType | "all">("all");
  const [showForm, setShowForm] = useState(false);
  const [formError, setFormError] = useState("");
  const [form, setForm] = useState({
    code: "",
    name: "",
    trade_name: "",
    mobile: "",
    phone: "",
    address: "",
    national_id: "",
    party_type: ["customer"] as PartyType[],
    description: "",
  });

  const filtered = searchParties(
    query,
    typeFilter === "all" ? undefined : [typeFilter]
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError("");
    if (!form.code.trim() || !form.name.trim()) {
      setFormError("کد و نام الزامی است");
      return;
    }
    const dup = checkPartyDuplicate({
      mobile: form.mobile || undefined,
      national_id: form.national_id || undefined,
      name: form.name,
    });
    if (dup && !dup.includes("هشدار")) {
      setFormError(dup);
      return;
    }
    if (dup?.includes("هشدار") && !confirm(dup + " — ادامه می‌دهید؟")) return;

    addParty({
      code: form.code.trim(),
      name: form.name.trim(),
      trade_name: form.trade_name || undefined,
      mobile: form.mobile || undefined,
      phone: form.phone || undefined,
      address: form.address || undefined,
      national_id: form.national_id || undefined,
      party_type: form.party_type,
      description: form.description || undefined,
      is_active: true,
    });
    setShowForm(false);
    setForm({
      code: "",
      name: "",
      trade_name: "",
      mobile: "",
      phone: "",
      address: "",
      national_id: "",
      party_type: ["customer"],
      description: "",
    });
  };

  const toggleType = (t: PartyType) => {
    setForm((f) => {
      const exists = f.party_type.includes(t);
      if (exists && f.party_type.length === 1) return f;
      return {
        ...f,
        party_type: exists
          ? f.party_type.filter((x) => x !== t)
          : [...f.party_type, t],
      };
    });
  };

  return (
    <div className="min-h-screen bg-slate-50 pb-24">
      <PageHeader
        title="اشخاص"
        subtitle={`${filtered.length} نفر`}
        backHref="/"
        action={
          <button
            onClick={() => setShowForm(true)}
            className="bg-gold-500 text-navy-950 text-xs font-bold px-3 py-1.5 rounded-lg"
          >
            + جدید
          </button>
        }
      />

      {/* جستجو */}
      <div className="p-4 space-y-3">
        <CSVImportButton type="parties" />
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="جستجو: نام، کد، موبایل..."
          className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-navy-500/30 bg-white"
        />

        {/* فیلتر نوع */}
        <div className="flex gap-2 overflow-x-auto pb-1">
          {TYPE_FILTERS.map((f) => (
            <button
              key={f.key}
              onClick={() => setTypeFilter(f.key)}
              className={`shrink-0 px-3 py-1.5 rounded-full text-xs font-medium transition ${
                typeFilter === f.key
                  ? "bg-navy-800 text-white"
                  : "bg-white text-slate-600 border border-slate-200"
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* لیست */}
      <div className="px-4 space-y-2">
        {filtered.length === 0 ? (
          <div className="text-center py-12 text-slate-400 text-sm">
            شخصی یافت نشد
          </div>
        ) : (
          filtered.map((p) => (
            <div
              key={p.id}
              className="bg-white rounded-xl border border-slate-100 p-4 shadow-sm"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-slate-800 truncate">
                      {p.name}
                    </span>
                    <span className="text-xs text-slate-400 font-mono">
                      {p.code}
                    </span>
                  </div>
                  {p.trade_name && (
                    <div className="text-xs text-slate-500 mt-0.5">
                      {p.trade_name}
                    </div>
                  )}
                  <div className="flex flex-wrap gap-1.5 mt-2">
                    {p.party_type.map((t) => (
                      <span
                        key={t}
                        className="text-[10px] px-2 py-0.5 rounded-full bg-navy-50 text-navy-700"
                      >
                        {PARTY_TYPE_LABELS[t] || t}
                      </span>
                    ))}
                  </div>
                  {p.mobile && (
                    <div className="text-xs text-slate-500 mt-1.5 dir-ltr text-right">
                      {p.mobile}
                    </div>
                  )}
                </div>
                <div className="text-left shrink-0">
                  <div
                    className={`text-sm font-bold ${
                      p.current_balance > 0
                        ? "text-emerald-600"
                        : p.current_balance < 0
                        ? "text-red-500"
                        : "text-slate-400"
                    }`}
                  >
                    {formatMoney(Math.abs(p.current_balance))}
                  </div>
                  <div className="text-[10px] text-slate-400 mt-0.5">
                    {p.current_balance > 0
                      ? "بدهکار"
                      : p.current_balance < 0
                      ? "بستانکار"
                      : "صفر"}
                  </div>
                </div>
              </div>
              <div className="flex gap-2 mt-3 pt-2 border-t border-slate-50">
                <button
                  onClick={() => {
                    if (confirm(`حذف منطقی «${p.name}»؟`)) softDeleteParty(p.id);
                  }}
                  className="text-xs text-red-500 hover:text-red-600"
                >
                  حذف
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* فرم افزودن */}
      {showForm && (
        <div className="fixed inset-0 z-50 bg-black/40 flex items-end sm:items-center justify-center">
          <div className="bg-white w-full max-w-md rounded-t-2xl sm:rounded-2xl max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-navy-950 text-white px-4 py-3 flex items-center justify-between rounded-t-2xl">
              <h2 className="font-bold">شخص جدید</h2>
              <button onClick={() => setShowForm(false)} className="text-slate-300 text-xl">
                ×
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-4 space-y-3">
              {formError && (
                <div className="bg-red-50 text-red-600 text-sm px-3 py-2 rounded-lg">
                  {formError}
                </div>
              )}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-slate-500 mb-1 block">کد *</label>
                  <input
                    required
                    value={form.code}
                    onChange={(e) => setForm({ ...form, code: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm"
                    placeholder="C001"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-500 mb-1 block">موبایل</label>
                  <input
                    value={form.mobile}
                    onChange={(e) => setForm({ ...form, mobile: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm dir-ltr"
                    placeholder="0912..."
                  />
                </div>
              </div>
              <div>
                <label className="text-xs text-slate-500 mb-1 block">نام / نام شرکت *</label>
                <input
                  required
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm"
                />
              </div>
              <div>
                <label className="text-xs text-slate-500 mb-1 block">نام تجاری</label>
                <input
                  value={form.trade_name}
                  onChange={(e) => setForm({ ...form, trade_name: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm"
                />
              </div>
              <div>
                <label className="text-xs text-slate-500 mb-1 block">نوع شخص</label>
                <div className="flex flex-wrap gap-2">
                  {(["customer", "supplier", "employee", "partner", "other"] as PartyType[]).map(
                    (t) => (
                      <button
                        key={t}
                        type="button"
                        onClick={() => toggleType(t)}
                        className={`text-xs px-3 py-1.5 rounded-full border transition ${
                          form.party_type.includes(t)
                            ? "bg-navy-800 text-white border-navy-800"
                            : "bg-white text-slate-600 border-slate-200"
                        }`}
                      >
                        {PARTY_TYPE_LABELS[t]}
                      </button>
                    )
                  )}
                </div>
              </div>
              <div>
                <label className="text-xs text-slate-500 mb-1 block">کد ملی / شناسه ملی</label>
                <input
                  value={form.national_id}
                  onChange={(e) => setForm({ ...form, national_id: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm dir-ltr"
                />
              </div>
              <div>
                <label className="text-xs text-slate-500 mb-1 block">آدرس</label>
                <textarea
                  value={form.address}
                  onChange={(e) => setForm({ ...form, address: e.target.value })}
                  rows={2}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm"
                />
              </div>
              <button type="submit" className="w-full btn-primary py-3 mt-2">
                ذخیره شخص
              </button>
            </form>
          </div>
        </div>
      )}

      <BottomNav />
    </div>
  );
}
