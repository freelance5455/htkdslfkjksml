"use client";

import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { PageHeader } from "@/components/layout/PageHeader";
import { useOperations } from "@/store/operations";
import { useMasterData } from "@/store/master-data";
import { OPERATION_TYPE_LABELS, OPERATION_TYPE_COLORS } from "@/lib/operation-labels";
import { formatMoney } from "@/lib/utils";

/** نام حساب از روی id موقت */
const ACC_NAMES: Record<string, string> = {
  "acc-1111": "وجه نقد صندوق",
  "acc-1121": "بانک ملی ایران",
  "acc-1122": "بانک ملت",
  "acc-1123": "بانک صادرات",
  "acc-1124": "بانک تجارت",
  "acc-1125": "بانک سپه",
  "acc-1126": "بانک رفاه",
  "acc-1127": "بانک کشاورزی",
  "acc-1128": "بانک مسکن",
  "acc-1129": "بانک پارسیان",
  "acc-1130": "بانک سامان",
  "acc-1131": "تنخواه گردان",
  "acc-1211": "مشتریان (دریافتنی)",
  "acc-2111": "تأمین‌کنندگان (پرداختنی)",
  "acc-4111": "فروش کالا",
  "acc-4131": "تخفیفات فروش",
  "acc-5111": "بهای تمام‌شده",
  "acc-1311": "موجودی کالا",
  "acc-5211": "تخفیفات خرید",
  "acc-6141": "هزینه حمل",
  "acc-4311": "درآمد حمل",
  "acc-6991": "سایر هزینه‌ها",
  "acc-4391": "سایر درآمدها",
  "acc-6111": "حقوق و دستمزد",
  "acc-6121": "اجاره",
};

export default function OperationDetailPage() {
  const params = useParams();
  const router = useRouter();
  const id = params.id as string;
  const {
    getOperationById,
    getJournalByOperationId,
    getJournalLines,
    softDeleteOperation,
  } = useOperations();
  const { getPartyById, getSourceById, getProductById } = useMasterData();

  const op = getOperationById(id);
  if (!op) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center gap-4">
        <p className="text-slate-500">عملیات یافت نشد</p>
        <Link href="/operations" className="text-navy-600 text-sm">
          بازگشت
        </Link>
      </div>
    );
  }

  const journal = getJournalByOperationId(op.id);
  const lines = journal ? getJournalLines(journal.id) : [];
  const party = op.party_id ? getPartyById(op.party_id) : null;
  const source = op.financial_source_id
    ? getSourceById(op.financial_source_id)
    : null;
  const colorClass =
    OPERATION_TYPE_COLORS[op.operation_type] || "bg-slate-100 text-slate-600";

  return (
    <div className="min-h-screen bg-slate-50 pb-24">
      <PageHeader
        title="جزئیات عملیات"
        subtitle={op.operation_number}
        backHref="/operations"
      />

      <div className="px-4 mt-4 space-y-4">
        {/* کارت عملیات */}
        <div className="bg-white rounded-xl border border-slate-100 p-4 shadow-sm">
          <div className="flex items-center gap-2 mb-3">
            <span
              className={`text-xs px-2.5 py-1 rounded-full font-medium ${colorClass}`}
            >
              {OPERATION_TYPE_LABELS[op.operation_type]}
            </span>
            {op.status === "deleted" && (
              <span className="text-xs px-2 py-1 rounded-full bg-red-50 text-red-600">
                حذف‌شده
              </span>
            )}
            {op.is_locked && (
              <span className="text-xs px-2 py-1 rounded-full bg-amber-50 text-amber-700">
                🔒 قفل
              </span>
            )}
          </div>

          <div className="text-2xl font-bold text-navy-900 mb-1">
            {formatMoney(op.amount)}
            <span className="text-sm font-normal text-slate-400 mr-1">ریال</span>
          </div>

          <dl className="mt-4 space-y-2 text-sm">
            <Row label="تاریخ" value={op.operation_date_jalali} />
            <Row label="شرح" value={op.description || "—"} />
            {party && <Row label="شخص" value={`${party.name} (${party.code})`} />}
            {source && <Row label="منبع مالی" value={source.name_fa} />}
            {op.reference_number && (
              <Row label="شماره مرجع" value={op.reference_number} />
            )}
            <Row label="وضعیت" value={op.status === "posted" ? "ثبت‌شده" : op.status} />
          </dl>
        </div>

        {/* اقلام فاکتور */}
        {op.lines && op.lines.length > 0 && (
          <div className="bg-white rounded-xl border border-slate-100 p-4 shadow-sm">
            <h3 className="text-sm font-semibold text-slate-700 mb-3">اقلام</h3>
            <div className="space-y-2">
              {op.lines.map((line) => {
                const prod = line.product_id
                  ? getProductById(line.product_id)
                  : null;
                return (
                  <div
                    key={line.id}
                    className="flex justify-between text-sm border-b border-slate-50 pb-2"
                  >
                    <div>
                      <div className="font-medium">
                        {prod?.name || line.description || "—"}
                      </div>
                      <div className="text-xs text-slate-400">
                        {line.quantity} × {formatMoney(line.unit_price)}
                        {line.discount_amount > 0 &&
                          ` − تخفیف ${formatMoney(line.discount_amount)}`}
                      </div>
                    </div>
                    <div className="font-medium">{formatMoney(line.line_total)}</div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* سند حسابداری دوبل */}
        {journal && (
          <div className="bg-white rounded-xl border border-slate-100 p-4 shadow-sm">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold text-slate-700">
                سند حسابداری
              </h3>
              <span className="text-xs font-mono text-slate-400">
                {journal.journal_number}
              </span>
            </div>

            {journal.is_balanced ? (
              <div className="text-xs text-emerald-600 mb-3">
                ✓ متوازن — بدهکار = بستانکار = {formatMoney(journal.total_debit)}
              </div>
            ) : (
              <div className="text-xs text-red-600 mb-3">⚠ نامتوازن</div>
            )}

            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="text-slate-400 border-b border-slate-100">
                    <th className="text-right py-2 font-medium">حساب</th>
                    <th className="text-left py-2 font-medium">بدهکار</th>
                    <th className="text-left py-2 font-medium">بستانکار</th>
                  </tr>
                </thead>
                <tbody>
                  {lines.map((l) => (
                    <tr key={l.id} className="border-b border-slate-50">
                      <td className="py-2.5 text-slate-700">
                        {ACC_NAMES[l.account_id] || l.account_id}
                        {l.description && (
                          <div className="text-[10px] text-slate-400 mt-0.5">
                            {l.description}
                          </div>
                        )}
                      </td>
                      <td className="py-2.5 text-left font-mono text-slate-800">
                        {l.debit > 0 ? formatMoney(l.debit) : "—"}
                      </td>
                      <td className="py-2.5 text-left font-mono text-slate-800">
                        {l.credit > 0 ? formatMoney(l.credit) : "—"}
                      </td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr className="font-bold text-navy-900">
                    <td className="py-2.5">جمع</td>
                    <td className="py-2.5 text-left font-mono">
                      {formatMoney(journal.total_debit)}
                    </td>
                    <td className="py-2.5 text-left font-mono">
                      {formatMoney(journal.total_credit)}
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>

            <p className="text-[10px] text-slate-400 mt-3">
              مسیر حسابرسی: عملیات → {op.operation_number} → سند{" "}
              {journal.journal_number} → دفتر کل
            </p>
          </div>
        )}

        {/* اقدامات */}
        {!op.is_locked && op.status !== "deleted" && (
          <div className="flex gap-3">
            <button
              onClick={() => {
                if (
                  confirm(
                    "حذف منطقی این عملیات و سند مرتبط؟\n(قابل ردیابی در Audit Log)"
                  )
                ) {
                  const r = softDeleteOperation(op.id, "حذف از صفحه جزئیات");
                  if (r.success) router.push("/operations");
                  else alert(r.error);
                }
              }}
              className="flex-1 py-2.5 rounded-xl border border-red-200 text-red-600 text-sm font-medium hover:bg-red-50"
            >
              حذف منطقی
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between gap-4">
      <dt className="text-slate-400 shrink-0">{label}</dt>
      <dd className="text-slate-800 text-left">{value}</dd>
    </div>
  );
}
