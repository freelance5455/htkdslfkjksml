"use client";

import { useState } from "react";
import Link from "next/link";
import { PageHeader } from "@/components/layout/PageHeader";
import { BottomNav } from "@/components/layout/BottomNav";
import { useOperations } from "@/store/operations";
import { useMasterData } from "@/store/master-data";
import { OPERATION_TYPE_LABELS, OPERATION_TYPE_COLORS } from "@/lib/operation-labels";
import { formatMoney } from "@/lib/utils";
import { todayJalali } from "@/lib/date-utils";

export default function OperationsPage() {
  const { operations, softDeleteOperation, getJournalByOperationId } = useOperations();
  const { getPartyById, getSourceById } = useMasterData();
  const [filter, setFilter] = useState<"today" | "all">("today");

  const activeOps = operations.filter((o) => o.status !== "deleted");
  const todayStr = new Date().toISOString().slice(0, 10);
  const list =
    filter === "today"
      ? activeOps.filter((o) => o.operation_date === todayStr)
      : activeOps;

  const totalIn = list
    .filter((o) =>
      ["receipt", "receipt_invoice", "income", "sale"].includes(o.operation_type)
    )
    .reduce((s, o) => s + o.amount, 0);
  const totalOut = list
    .filter((o) =>
      ["payment", "payment_invoice", "expense", "purchase"].includes(o.operation_type)
    )
    .reduce((s, o) => s + o.amount, 0);

  return (
    <div className="min-h-screen bg-slate-50 pb-24">
      <PageHeader
        title="عملیات روزانه"
        subtitle={todayJalali()}
        backHref="/"
        action={
          <Link
            href="/operations/new"
            className="bg-gold-500 text-navy-950 text-xs font-bold px-3 py-1.5 rounded-lg"
          >
            + ثبت
          </Link>
        }
      />

      {/* خلاصه امروز */}
      <div className="mx-4 mt-4 grid grid-cols-3 gap-2">
        <div className="bg-white rounded-xl p-3 border border-slate-100 text-center">
          <div className="text-[10px] text-slate-400">ورود</div>
          <div className="text-sm font-bold text-emerald-600 mt-0.5">
            {formatMoney(totalIn)}
          </div>
        </div>
        <div className="bg-white rounded-xl p-3 border border-slate-100 text-center">
          <div className="text-[10px] text-slate-400">خروج</div>
          <div className="text-sm font-bold text-red-500 mt-0.5">
            {formatMoney(totalOut)}
          </div>
        </div>
        <div className="bg-white rounded-xl p-3 border border-slate-100 text-center">
          <div className="text-[10px] text-slate-400">خالص</div>
          <div
            className={`text-sm font-bold mt-0.5 ${
              totalIn - totalOut >= 0 ? "text-navy-800" : "text-red-500"
            }`}
          >
            {formatMoney(totalIn - totalOut)}
          </div>
        </div>
      </div>

      {/* فیلتر */}
      <div className="px-4 mt-4 flex gap-2">
        <button
          onClick={() => setFilter("today")}
          className={`px-3 py-1.5 rounded-full text-xs font-medium ${
            filter === "today"
              ? "bg-navy-800 text-white"
              : "bg-white text-slate-600 border border-slate-200"
          }`}
        >
          امروز
        </button>
        <button
          onClick={() => setFilter("all")}
          className={`px-3 py-1.5 rounded-full text-xs font-medium ${
            filter === "all"
              ? "bg-navy-800 text-white"
              : "bg-white text-slate-600 border border-slate-200"
          }`}
        >
          همه
        </button>
      </div>

      {/* لیست */}
      <div className="px-4 mt-3 space-y-2">
        {list.length === 0 ? (
          <div className="text-center py-16">
            <div className="text-4xl mb-3 opacity-40">📋</div>
            <p className="text-sm text-slate-400">هنوز عملیاتی ثبت نشده</p>
            <Link
              href="/operations/new"
              className="inline-block mt-4 btn-gold text-sm px-5 py-2"
            >
              ثبت اولین عملیات
            </Link>
          </div>
        ) : (
          list.map((op) => {
            const party = op.party_id ? getPartyById(op.party_id) : null;
            const source = op.financial_source_id
              ? getSourceById(op.financial_source_id)
              : null;
            const journal = getJournalByOperationId(op.id);
            const colorClass =
              OPERATION_TYPE_COLORS[op.operation_type] || "bg-slate-100 text-slate-600";

            return (
              <div
                key={op.id}
                className="bg-white rounded-xl border border-slate-100 p-4 shadow-sm"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span
                        className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${colorClass}`}
                      >
                        {OPERATION_TYPE_LABELS[op.operation_type] || op.operation_type}
                      </span>
                      <span className="text-xs text-slate-400 font-mono">
                        {op.operation_number}
                      </span>
                    </div>
                    <div className="mt-1.5 text-sm text-slate-800 font-medium truncate">
                      {op.description || "—"}
                    </div>
                    <div className="mt-1 flex flex-wrap gap-x-3 gap-y-0.5 text-xs text-slate-500">
                      {party && <span>{party.name}</span>}
                      {source && <span>{source.name_fa}</span>}
                      <span>{op.operation_date_jalali}</span>
                    </div>
                    {journal && (
                      <div className="mt-1 text-[10px] text-slate-400">
                        سند: {journal.journal_number}
                        {journal.is_balanced && (
                          <span className="text-emerald-600 mr-1">✓ متوازن</span>
                        )}
                      </div>
                    )}
                  </div>
                  <div className="text-left shrink-0">
                    <div className="text-sm font-bold text-navy-800">
                      {formatMoney(op.amount)}
                    </div>
                  </div>
                </div>

                {!op.is_locked && (
                  <div className="flex gap-3 mt-3 pt-2 border-t border-slate-50">
                    <Link
                      href={`/operations/${op.id}`}
                      className="text-xs text-navy-600 hover:text-navy-800"
                    >
                      جزئیات / سند
                    </Link>
                    <button
                      onClick={() => {
                        if (
                          confirm(
                            `حذف منطقی عملیات ${op.operation_number}؟\nسند مرتبط نیز حذف منطقی می‌شود.`
                          )
                        ) {
                          const r = softDeleteOperation(op.id);
                          if (!r.success) alert(r.error);
                        }
                      }}
                      className="text-xs text-red-500 hover:text-red-600"
                    >
                      حذف
                    </button>
                  </div>
                )}
                {op.is_locked && (
                  <div className="mt-2 text-[10px] text-amber-600">
                    🔒 قفل شده — فقط با سند اصلاحی قابل تغییر
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      <BottomNav />
    </div>
  );
}
