"use client";

import { useState, useMemo } from "react";
import { useRouter } from "next/navigation";
import { PageHeader } from "@/components/layout/PageHeader";
import { SmartSelect } from "@/components/ui/SmartSelect";
import { useOperations } from "@/store/operations";
import { useMasterData } from "@/store/master-data";
import { QUICK_OPERATION_TYPES, OPERATION_TYPE_LABELS } from "@/lib/operation-labels";
import { formatMoney } from "@/lib/utils";
import { todayJalali } from "@/lib/date-utils";
import type { OperationType } from "@/types/database";

type Step = "type" | "form";

export default function NewOperationPage() {
  const router = useRouter();
  const { createOperation } = useOperations();
  const {
    searchParties,
    searchProducts,
    getActiveSources,
    getProductById,
    addParty,
    addProduct,
  } = useMasterData();

  const [step, setStep] = useState<Step>("type");
  const [opType, setOpType] = useState<OperationType | null>(null);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  // فیلدهای مشترک
  const [partyId, setPartyId] = useState("");
  const [sourceId, setSourceId] = useState("");
  const [targetSourceId, setTargetSourceId] = useState("");
  const [amount, setAmount] = useState("");
  const [description, setDescription] = useState("");
  const [referenceNumber, setReferenceNumber] = useState("");

  // فاکتور
  const [invoiceLines, setInvoiceLines] = useState<
    Array<{
      productId: string;
      quantity: string;
      unitPrice: string;
      discountMode: "percent" | "amount";
      discountPercent: string;
      discountAmount: string;
    }>
  >([{ productId: "", quantity: "1", unitPrice: "", discountMode: "percent", discountPercent: "", discountAmount: "" }]);
  const [headerDiscountMode, setHeaderDiscountMode] = useState<"percent" | "amount">("percent");
  const [headerDiscountPercent, setHeaderDiscountPercent] = useState("");
  const [headerDiscountAmount, setHeaderDiscountAmount] = useState("");
  const [shippingCost, setShippingCost] = useState("");

  const sources = getActiveSources();
  const sourceOptions = sources.map((s) => ({
    id: s.id,
    label: s.name_fa,
    subLabel: formatMoney(s.current_balance),
    badge: s.source_type === "cash" ? "نقد" : s.source_type === "bank" ? "بانک" : "تنخواه",
  }));

  const partyOptions = useMemo(() => {
    const types =
      opType === "receipt" || opType === "sale" || opType === "receipt_invoice"
        ? (["customer"] as const)
        : opType === "payment" || opType === "purchase" || opType === "payment_invoice"
        ? (["supplier"] as const)
        : undefined;
    return searchParties("", types ? [...types] : undefined).map((p) => ({
      id: p.id,
      label: p.name,
      subLabel: p.code + (p.mobile ? ` · ${p.mobile}` : ""),
      badge: p.party_type.includes("customer") && p.party_type.includes("supplier")
        ? "هر دو"
        : p.party_type[0] === "customer"
        ? "مشتری"
        : p.party_type[0] === "supplier"
        ? "تأمین"
        : undefined,
    }));
  }, [opType, searchParties]);

  const productOptions = searchProducts("").map((p) => ({
    id: p.id,
    label: p.name,
    subLabel: `${p.code} · ${formatMoney(p.sale_price)}`,
  }));

  // محاسبه جمع فاکتور
  const invoiceCalc = useMemo(() => {
    let gross = 0;
    for (const line of invoiceLines) {
      const q = Number(line.quantity) || 0;
      const price = Number(line.unitPrice) || 0;
      let disc = 0;
      if (line.discountMode === "percent" && line.discountPercent) {
        disc = Math.round((q * price * Number(line.discountPercent)) / 100);
      } else {
        disc = Number(line.discountAmount) || 0;
      }
      gross += q * price - disc;
    }
    let headerDisc = 0;
    if (headerDiscountMode === "percent" && headerDiscountPercent) {
      headerDisc = Math.round((gross * Number(headerDiscountPercent)) / 100);
    } else {
      headerDisc = Number(headerDiscountAmount) || 0;
    }
    const ship = Number(shippingCost) || 0;
    const final = gross - headerDisc + ship;
    return { gross, headerDisc, ship, final };
  }, [invoiceLines, headerDiscountMode, headerDiscountPercent, headerDiscountAmount, shippingCost]);

  const needsParty = ["receipt", "payment", "sale", "purchase", "receipt_invoice", "payment_invoice"].includes(
    opType || ""
  );
  const needsSource = ["receipt", "payment", "expense", "income", "sale", "purchase", "transfer"].includes(
    opType || ""
  );
  const isInvoice = opType === "sale" || opType === "purchase";
  const isTransfer = opType === "transfer";

  const handleSelectType = (t: OperationType) => {
    setOpType(t);
    setStep("form");
    setError("");
    // پیش‌فرض شرح
    setDescription(OPERATION_TYPE_LABELS[t] || "");
  };

  const handleSave = () => {
    if (!opType) return;
    setError("");
    setSaving(true);

    let finalAmount = Number(amount) || 0;
    let lines:
      | Array<{
          productId?: string;
          quantity: number;
          unitPrice: number;
          discountMode?: "percent" | "amount";
          discountPercent?: number;
          discountAmount?: number;
        }>
      | undefined;

    if (isInvoice) {
      finalAmount = invoiceCalc.final;
      lines = invoiceLines
        .filter((l) => l.productId || Number(l.unitPrice) > 0)
        .map((l) => ({
          productId: l.productId || undefined,
          quantity: Number(l.quantity) || 1,
          unitPrice: Number(l.unitPrice) || 0,
          discountMode: l.discountMode,
          discountPercent: Number(l.discountPercent) || 0,
          discountAmount: Number(l.discountAmount) || 0,
        }));
      if (!lines.length) {
        setError("حداقل یک قلم کالا وارد کنید");
        setSaving(false);
        return;
      }
    }

    if (!isInvoice && finalAmount <= 0) {
      setError("مبلغ را وارد کنید");
      setSaving(false);
      return;
    }
    if (needsParty && !partyId) {
      setError("شخص را انتخاب کنید");
      setSaving(false);
      return;
    }
    if (needsSource && !sourceId) {
      setError("منبع مالی را انتخاب کنید");
      setSaving(false);
      return;
    }
    if (isTransfer && !targetSourceId) {
      setError("منبع مقصد را انتخاب کنید");
      setSaving(false);
      return;
    }
    if (isTransfer && sourceId === targetSourceId) {
      setError("مبدأ و مقصد نباید یکسان باشند");
      setSaving(false);
      return;
    }

    const result = createOperation({
      operationType: opType,
      amount: finalAmount,
      partyId: partyId || undefined,
      financialSourceId: sourceId || undefined,
      targetSourceId: isTransfer ? targetSourceId : undefined,
      description: description || undefined,
      referenceNumber: referenceNumber || undefined,
      lines,
      discountAmount: isInvoice ? invoiceCalc.headerDisc : undefined,
      shippingCost: isInvoice ? invoiceCalc.ship : undefined,
    });

    setSaving(false);
    if (!result.success) {
      setError(result.error || "خطا در ثبت");
      return;
    }

    router.push(`/operations/${result.operation!.id}`);
  };

  // ─── انتخاب نوع ───
  if (step === "type") {
    return (
      <div className="min-h-screen bg-slate-50 pb-8">
        <PageHeader title="ثبت عملیات" subtitle="نوع عملیات را انتخاب کنید" backHref="/operations" />
        <div className="px-4 mt-4 grid grid-cols-2 gap-3">
          {QUICK_OPERATION_TYPES.map((item) => (
            <button
              key={item.type}
              onClick={() => handleSelectType(item.type)}
              className="bg-white rounded-xl p-4 border border-slate-100 shadow-sm text-right hover:border-navy-300 hover:shadow transition active:scale-[0.98]"
            >
              <div className="text-2xl mb-2">{item.icon}</div>
              <div className="font-semibold text-slate-800 text-sm">{item.label}</div>
              <div className="text-xs text-slate-400 mt-0.5">{item.desc}</div>
            </button>
          ))}
        </div>
      </div>
    );
  }

  // ─── فرم ───
  return (
    <div className="min-h-screen bg-slate-50 pb-32">
      <PageHeader
        title={OPERATION_TYPE_LABELS[opType!] || "عملیات"}
        subtitle={todayJalali()}
        backHref="/operations/new"
        action={
          <button
            onClick={() => {
              setStep("type");
              setOpType(null);
            }}
            className="text-xs text-gold-400"
          >
            تغییر نوع
          </button>
        }
      />

      <div className="px-4 mt-4 space-y-4">
        {error && (
          <div className="bg-red-50 text-red-600 text-sm px-3 py-2.5 rounded-xl border border-red-100">
            {error}
          </div>
        )}

        {/* شخص */}
        {needsParty && (
          <div>
            <label className="text-xs text-slate-500 mb-1.5 block">شخص *</label>
            <SmartSelect
              options={partyOptions}
              value={partyId}
              onChange={(id) => setPartyId(id)}
              placeholder="جستجو و انتخاب شخص..."
              searchPlaceholder="نام، کد یا موبایل..."
              onQuickAdd={() => {
                const name = prompt("نام شخص جدید:");
                if (!name?.trim()) return;
                const code = `C${Date.now().toString().slice(-5)}`;
                const p = addParty({
                  code,
                  name: name.trim(),
                  party_type:
                    opType === "sale" || opType === "receipt"
                      ? ["customer"]
                      : ["supplier"],
                  is_active: true,
                });
                setPartyId(p.id);
              }}
              quickAddLabel="+ شخص جدید"
            />
          </div>
        )}

        {/* منبع مالی */}
        {needsSource && (
          <div>
            <label className="text-xs text-slate-500 mb-1.5 block">
              {isTransfer ? "منبع مبدأ *" : "منبع مالی *"}
            </label>
            <SmartSelect
              options={sourceOptions}
              value={sourceId}
              onChange={(id) => setSourceId(id)}
              placeholder="انتخاب منبع..."
            />
          </div>
        )}

        {/* مقصد انتقال */}
        {isTransfer && (
          <div>
            <label className="text-xs text-slate-500 mb-1.5 block">منبع مقصد *</label>
            <SmartSelect
              options={sourceOptions.filter((o) => o.id !== sourceId)}
              value={targetSourceId}
              onChange={(id) => setTargetSourceId(id)}
              placeholder="انتخاب مقصد..."
            />
          </div>
        )}

        {/* اقلام فاکتور */}
        {isInvoice && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs text-slate-500">اقلام فاکتور</label>
              <button
                type="button"
                onClick={() =>
                  setInvoiceLines([
                    ...invoiceLines,
                    {
                      productId: "",
                      quantity: "1",
                      unitPrice: "",
                      discountMode: "percent",
                      discountPercent: "",
                      discountAmount: "",
                    },
                  ])
                }
                className="text-xs text-navy-600 font-medium"
              >
                + ردیف
              </button>
            </div>

            {invoiceLines.map((line, idx) => (
              <div
                key={idx}
                className="bg-white rounded-xl border border-slate-200 p-3 space-y-2"
              >
                <SmartSelect
                  options={productOptions}
                  value={line.productId}
                  onChange={(id) => {
                    const prod = getProductById(id);
                    const next = [...invoiceLines];
                    next[idx] = {
                      ...next[idx],
                      productId: id,
                      unitPrice: prod
                        ? String(
                            opType === "sale" ? prod.sale_price : prod.purchase_price
                          )
                        : next[idx].unitPrice,
                    };
                    setInvoiceLines(next);
                  }}
                  placeholder="انتخاب کالا..."
                  onQuickAdd={() => {
                    const name = prompt("نام کالای جدید:");
                    if (!name?.trim()) return;
                    const code = `K${Date.now().toString().slice(-5)}`;
                    const p = addProduct({
                      code,
                      name: name.trim(),
                      unit: "عدد",
                      purchase_price: 0,
                      sale_price: 0,
                      is_active: true,
                    });
                    const next = [...invoiceLines];
                    next[idx] = { ...next[idx], productId: p.id };
                    setInvoiceLines(next);
                  }}
                  quickAddLabel="+ کالای جدید"
                />
                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="text-[10px] text-slate-400">تعداد</label>
                    <input
                      type="number"
                      min="0"
                      step="any"
                      value={line.quantity}
                      onChange={(e) => {
                        const next = [...invoiceLines];
                        next[idx] = { ...next[idx], quantity: e.target.value };
                        setInvoiceLines(next);
                      }}
                      className="w-full px-2 py-1.5 rounded-lg border border-slate-200 text-sm"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-slate-400">نرخ</label>
                    <input
                      type="number"
                      min="0"
                      value={line.unitPrice}
                      onChange={(e) => {
                        const next = [...invoiceLines];
                        next[idx] = { ...next[idx], unitPrice: e.target.value };
                        setInvoiceLines(next);
                      }}
                      className="w-full px-2 py-1.5 rounded-lg border border-slate-200 text-sm"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-slate-400">
                      تخفیف {line.discountMode === "percent" ? "%" : "مبلغ"}
                    </label>
                    <div className="flex gap-1">
                      <input
                        type="number"
                        min="0"
                        value={
                          line.discountMode === "percent"
                            ? line.discountPercent
                            : line.discountAmount
                        }
                        onChange={(e) => {
                          const next = [...invoiceLines];
                          if (line.discountMode === "percent") {
                            const pct = e.target.value;
                            const lineAmt =
                              (Number(line.quantity) || 0) * (Number(line.unitPrice) || 0);
                            const amt = pct
                              ? String(Math.round((lineAmt * Number(pct)) / 100))
                              : "";
                            next[idx] = {
                              ...next[idx],
                              discountPercent: pct,
                              discountAmount: amt,
                            };
                          } else {
                            const amt = e.target.value;
                            const lineAmt =
                              (Number(line.quantity) || 0) * (Number(line.unitPrice) || 0);
                            const pct =
                              lineAmt > 0 && amt
                                ? String(Math.round((Number(amt) / lineAmt) * 10000) / 100)
                                : "";
                            next[idx] = {
                              ...next[idx],
                              discountAmount: amt,
                              discountPercent: pct,
                            };
                          }
                          setInvoiceLines(next);
                        }}
                        className="w-full px-2 py-1.5 rounded-lg border border-slate-200 text-sm"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          const next = [...invoiceLines];
                          next[idx] = {
                            ...next[idx],
                            discountMode:
                              line.discountMode === "percent" ? "amount" : "percent",
                          };
                          setInvoiceLines(next);
                        }}
                        className="shrink-0 px-2 text-[10px] bg-slate-100 rounded-lg"
                      >
                        {line.discountMode === "percent" ? "٪" : "﷼"}
                      </button>
                    </div>
                  </div>
                </div>
                {invoiceLines.length > 1 && (
                  <button
                    type="button"
                    onClick={() => setInvoiceLines(invoiceLines.filter((_, i) => i !== idx))}
                    className="text-[10px] text-red-500"
                  >
                    حذف ردیف
                  </button>
                )}
              </div>
            ))}

            {/* تخفیف و حمل سطح فاکتور */}
            <div className="bg-slate-100 rounded-xl p-3 space-y-2">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] text-slate-500">
                    تخفیف کل ({headerDiscountMode === "percent" ? "درصد" : "مبلغ"})
                  </label>
                  <div className="flex gap-1">
                    <input
                      type="number"
                      min="0"
                      value={
                        headerDiscountMode === "percent"
                          ? headerDiscountPercent
                          : headerDiscountAmount
                      }
                      onChange={(e) => {
                        if (headerDiscountMode === "percent") {
                          const pct = e.target.value;
                          const amt = pct
                            ? String(
                                Math.round((invoiceCalc.gross * Number(pct)) / 100)
                              )
                            : "";
                          setHeaderDiscountPercent(pct);
                          setHeaderDiscountAmount(amt);
                        } else {
                          const amt = e.target.value;
                          const pct =
                            invoiceCalc.gross > 0 && amt
                              ? String(
                                  Math.round((Number(amt) / invoiceCalc.gross) * 10000) /
                                    100
                                )
                              : "";
                          setHeaderDiscountAmount(amt);
                          setHeaderDiscountPercent(pct);
                        }
                      }}
                      className="w-full px-2 py-1.5 rounded-lg border border-slate-200 text-sm bg-white"
                    />
                    <button
                      type="button"
                      onClick={() =>
                        setHeaderDiscountMode((m) =>
                          m === "percent" ? "amount" : "percent"
                        )
                      }
                      className="shrink-0 px-2 text-[10px] bg-white rounded-lg border border-slate-200"
                    >
                      {headerDiscountMode === "percent" ? "٪" : "﷼"}
                    </button>
                  </div>
                </div>
                <div>
                  <label className="text-[10px] text-slate-500">هزینه حمل</label>
                  <input
                    type="number"
                    min="0"
                    value={shippingCost}
                    onChange={(e) => setShippingCost(e.target.value)}
                    className="w-full px-2 py-1.5 rounded-lg border border-slate-200 text-sm bg-white"
                  />
                </div>
              </div>
              <div className="flex justify-between text-sm pt-1 border-t border-slate-200">
                <span className="text-slate-500">مبلغ نهایی</span>
                <span className="font-bold text-navy-800">
                  {formatMoney(invoiceCalc.final)}
                </span>
              </div>
            </div>
          </div>
        )}

        {/* مبلغ ساده */}
        {!isInvoice && (
          <div>
            <label className="text-xs text-slate-500 mb-1.5 block">مبلغ *</label>
            <input
              type="number"
              min="0"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0"
              className="w-full px-4 py-3 rounded-xl border border-slate-200 text-lg font-bold text-navy-900 focus:outline-none focus:ring-2 focus:ring-navy-500/30"
            />
            {amount && (
              <div className="text-xs text-slate-400 mt-1">{formatMoney(Number(amount))}</div>
            )}
          </div>
        )}

        {/* شماره مرجع */}
        <div>
          <label className="text-xs text-slate-500 mb-1.5 block">شماره مرجع / فاکتور</label>
          <input
            value={referenceNumber}
            onChange={(e) => setReferenceNumber(e.target.value)}
            className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-sm"
            placeholder="اختیاری"
          />
        </div>

        {/* شرح */}
        <div>
          <label className="text-xs text-slate-500 mb-1.5 block">شرح</label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={2}
            className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-sm"
          />
        </div>
      </div>

      {/* دکمه ثبت ثابت */}
      <div className="fixed bottom-0 inset-x-0 p-4 bg-white border-t border-slate-200 safe-area-pb">
        <button
          onClick={handleSave}
          disabled={saving}
          className="w-full btn-primary py-3.5 text-base font-bold disabled:opacity-60"
        >
          {saving ? "در حال ثبت..." : "ثبت عملیات + تولید سند دوبل"}
        </button>
      </div>
    </div>
  );
}
