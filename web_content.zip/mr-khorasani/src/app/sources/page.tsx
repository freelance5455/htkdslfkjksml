"use client";

import { PageHeader } from "@/components/layout/PageHeader";
import { BottomNav } from "@/components/layout/BottomNav";
import { useMasterData } from "@/store/master-data";
import { SOURCE_TYPE_LABELS } from "@/lib/mock-data";
import { formatMoney } from "@/lib/utils";

export default function SourcesPage() {
  const { getActiveSources } = useMasterData();
  const sources = getActiveSources();

  const totalLiquidity = sources.reduce((s, src) => s + src.current_balance, 0);

  const cashSources = sources.filter((s) => s.source_type === "cash" || s.source_type === "petty_cash");
  const bankSources = sources.filter((s) => s.source_type === "bank");

  return (
    <div className="min-h-screen bg-slate-50 pb-24">
      <PageHeader
        title="منابع مالی"
        subtitle="صندوق + بانک‌ها + تنخواه"
        backHref="/"
      />

      {/* جمع کل نقدینگی */}
      <div className="mx-4 mt-4 p-5 rounded-2xl bg-gradient-to-br from-navy-900 to-navy-800 text-white shadow-lg">
        <div className="text-xs text-slate-300 mb-1">جمع کل نقدینگی</div>
        <div className="text-2xl font-bold text-gold-400">
          {formatMoney(totalLiquidity)}
          <span className="text-sm font-normal text-slate-300 mr-1">ریال</span>
        </div>
      </div>

      {/* نقد و تنخواه */}
      <div className="px-4 mt-6">
        <h2 className="text-sm font-semibold text-slate-600 mb-2">نقد و تنخواه</h2>
        <div className="space-y-2">
          {cashSources.map((s) => (
            <div
              key={s.id}
              className="bg-white rounded-xl border border-slate-100 p-4 shadow-sm flex items-center justify-between"
            >
              <div>
                <div className="font-medium text-slate-800">{s.name_fa}</div>
                <div className="text-xs text-slate-400 mt-0.5">
                  {SOURCE_TYPE_LABELS[s.source_type]} · {s.code}
                </div>
              </div>
              <div className="text-left">
                <div className="font-bold text-navy-800">
                  {formatMoney(s.current_balance)}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* بانک‌ها */}
      <div className="px-4 mt-6">
        <h2 className="text-sm font-semibold text-slate-600 mb-2">
          بانک‌ها ({bankSources.length})
        </h2>
        <div className="space-y-2">
          {bankSources.map((s) => (
            <div
              key={s.id}
              className="bg-white rounded-xl border border-slate-100 p-4 shadow-sm"
            >
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium text-slate-800">{s.name_fa}</div>
                  <div className="text-xs text-slate-400 mt-0.5">
                    {s.branch_name || "—"} · {s.code}
                  </div>
                  {s.account_number && (
                    <div className="text-xs text-slate-400 mt-0.5 font-mono dir-ltr text-right">
                      {s.account_number}
                    </div>
                  )}
                </div>
                <div className="text-left">
                  <div
                    className={`font-bold ${
                      s.current_balance > 0 ? "text-navy-800" : "text-slate-400"
                    }`}
                  >
                    {formatMoney(s.current_balance)}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <p className="text-center text-xs text-slate-400 mt-8 px-4">
        ۱۰ بانک ایرانی به‌صورت پیش‌فرض تعریف شده‌اند و قابل ویرایش هستند
      </p>

      <BottomNav />
    </div>
  );
}
