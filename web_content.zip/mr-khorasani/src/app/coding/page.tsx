"use client";

import { useState } from "react";
import { PageHeader } from "@/components/layout/PageHeader";
import { BottomNav } from "@/components/layout/BottomNav";

/** داده‌های کدینگ استخراج‌شده از PDF */
const CODING_TREE = [
  {
    level: 1, code: "1", name: "دارایی‌ها",
    children: [
      {
        level: 2, code: "11", name: "موجودی نقد و بانک",
        children: [
          { level: 3, code: "111", name: "صندوق", children: [
            { level: 4, code: "1111", name: "وجه نقد صندوق" },
          ]},
          { level: 3, code: "112", name: "بانک‌ها", children: [
            { level: 4, code: "1121", name: "بانک ملی ایران" },
            { level: 4, code: "1122", name: "بانک ملت" },
            { level: 4, code: "1123", name: "بانک صادرات ایران" },
            { level: 4, code: "1124", name: "بانک تجارت" },
            { level: 4, code: "1125", name: "بانک سپه" },
            { level: 4, code: "1126", name: "بانک رفاه کارگران" },
            { level: 4, code: "1127", name: "بانک کشاورزی" },
            { level: 4, code: "1128", name: "بانک مسکن" },
            { level: 4, code: "1129", name: "بانک پارسیان" },
            { level: 4, code: "1130", name: "بانک سامان" },
          ]},
          { level: 3, code: "113", name: "تنخواه", children: [
            { level: 4, code: "1131", name: "تنخواه گردان" },
          ]},
        ],
      },
      {
        level: 2, code: "12", name: "حساب‌ها و اسناد دریافتنی",
        children: [
          { level: 3, code: "121", name: "حساب‌های دریافتنی", children: [
            { level: 4, code: "1211", name: "مشتریان (تفصیلی شناور)" },
          ]},
          { level: 3, code: "122", name: "اسناد دریافتنی", children: [
            { level: 4, code: "1221", name: "چک‌های دریافتنی" },
          ]},
        ],
      },
      {
        level: 2, code: "13", name: "موجودی کالا",
        children: [
          { level: 3, code: "131", name: "موجودی کالا", children: [
            { level: 4, code: "1311", name: "موجودی کالا" },
          ]},
        ],
      },
      {
        level: 2, code: "14", name: "پیش‌پرداخت‌ها و سپرده‌ها",
        children: [
          { level: 3, code: "141", name: "پیش‌پرداخت‌ها", children: [
            { level: 4, code: "1411", name: "پیش‌پرداخت تأمین‌کنندگان" },
          ]},
          { level: 3, code: "142", name: "سپرده‌ها" },
        ],
      },
      {
        level: 2, code: "15", name: "دارایی‌های ثابت",
        children: [
          { level: 3, code: "151", name: "دارایی ثابت", children: [
            { level: 4, code: "1511", name: "اثاثه و تجهیزات" },
          ]},
          { level: 3, code: "152", name: "استهلاک انباشته", children: [
            { level: 4, code: "1521", name: "استهلاک انباشته دارایی ثابت" },
          ]},
        ],
      },
    ],
  },
  {
    level: 1, code: "2", name: "بدهی‌ها",
    children: [
      {
        level: 2, code: "21", name: "حساب‌ها و اسناد پرداختنی",
        children: [
          { level: 3, code: "211", name: "حساب‌های پرداختنی", children: [
            { level: 4, code: "2111", name: "تأمین‌کنندگان (تفصیلی شناور)" },
          ]},
          { level: 3, code: "212", name: "اسناد پرداختنی", children: [
            { level: 4, code: "2121", name: "چک‌های پرداختنی" },
          ]},
        ],
      },
      {
        level: 2, code: "22", name: "مالیات، بیمه و حقوق",
        children: [
          { level: 3, code: "221", name: "مالیات پرداختنی", children: [
            { level: 4, code: "2211", name: "مالیات بر ارزش افزوده پرداختنی" },
          ]},
          { level: 3, code: "222", name: "بیمه پرداختنی", children: [
            { level: 4, code: "2221", name: "بیمه تأمین اجتماعی پرداختنی" },
          ]},
          { level: 3, code: "223", name: "حقوق پرداختنی", children: [
            { level: 4, code: "2231", name: "حقوق پرداختنی کارکنان" },
          ]},
        ],
      },
      {
        level: 2, code: "23", name: "پیش‌دریافت‌ها و سایر بدهی‌ها",
        children: [
          { level: 3, code: "231", name: "پیش‌دریافت‌ها", children: [
            { level: 4, code: "2311", name: "پیش‌دریافت از مشتریان" },
          ]},
          { level: 3, code: "239", name: "سایر بدهی‌ها" },
        ],
      },
    ],
  },
  {
    level: 1, code: "3", name: "سرمایه",
    children: [
      {
        level: 2, code: "31", name: "حقوق صاحبان سرمایه",
        children: [
          { level: 3, code: "311", name: "سرمایه", children: [
            { level: 4, code: "3111", name: "سرمایه اولیه" },
          ]},
          { level: 3, code: "321", name: "برداشت", children: [
            { level: 4, code: "3211", name: "برداشت شرکا" },
          ]},
          { level: 3, code: "331", name: "سود و زیان انباشته", children: [
            { level: 4, code: "3311", name: "سود و زیان انباشته" },
          ]},
          { level: 3, code: "341", name: "سود و زیان جاری", children: [
            { level: 4, code: "3411", name: "سود و زیان جاری" },
          ]},
        ],
      },
    ],
  },
  {
    level: 1, code: "4", name: "درآمدها",
    children: [
      {
        level: 2, code: "41", name: "درآمد عملیاتی",
        children: [
          { level: 3, code: "411", name: "فروش", children: [
            { level: 4, code: "4111", name: "فروش کالا" },
          ]},
          { level: 3, code: "412", name: "درآمد خدمات", children: [
            { level: 4, code: "4121", name: "درآمد خدمات" },
          ]},
          { level: 3, code: "413", name: "تخفیفات فروش", children: [
            { level: 4, code: "4131", name: "تخفیفات فروش" },
          ]},
        ],
      },
      {
        level: 2, code: "43", name: "سایر درآمدها",
        children: [
          { level: 3, code: "431", name: "درآمد حمل", children: [
            { level: 4, code: "4311", name: "درآمد حمل" },
          ]},
          { level: 3, code: "439", name: "سایر درآمدها", children: [
            { level: 4, code: "4391", name: "سایر درآمدها" },
          ]},
        ],
      },
    ],
  },
  {
    level: 1, code: "5", name: "بهای تمام‌شده",
    children: [
      {
        level: 2, code: "51", name: "بهای کالای فروش‌رفته",
        children: [
          { level: 3, code: "511", name: "بهای تمام‌شده کالای فروش‌رفته", children: [
            { level: 4, code: "5111", name: "بهای تمام‌شده کالای فروش‌رفته" },
          ]},
          { level: 3, code: "512", name: "بهای خدمات ارائه‌شده" },
          { level: 3, code: "521", name: "تخفیفات خرید", children: [
            { level: 4, code: "5211", name: "تخفیفات خرید" },
          ]},
        ],
      },
    ],
  },
  {
    level: 1, code: "6", name: "هزینه‌ها",
    children: [
      {
        level: 2, code: "61", name: "هزینه‌های عملیاتی",
        children: [
          { level: 3, code: "611", name: "حقوق و دستمزد", children: [{ level: 4, code: "6111", name: "حقوق و دستمزد" }] },
          { level: 3, code: "612", name: "اجاره", children: [{ level: 4, code: "6121", name: "اجاره" }] },
          { level: 3, code: "613", name: "آب و برق و گاز", children: [{ level: 4, code: "6131", name: "آب و برق و گاز" }] },
          { level: 3, code: "614", name: "حمل", children: [{ level: 4, code: "6141", name: "هزینه حمل" }] },
          { level: 3, code: "615", name: "بازاریابی", children: [{ level: 4, code: "6151", name: "بازاریابی" }] },
          { level: 3, code: "616", name: "تبلیغات", children: [{ level: 4, code: "6161", name: "تبلیغات" }] },
          { level: 3, code: "617", name: "تعمیرات", children: [{ level: 4, code: "6171", name: "تعمیرات" }] },
          { level: 3, code: "618", name: "استهلاک", children: [{ level: 4, code: "6181", name: "استهلاک" }] },
        ],
      },
      {
        level: 2, code: "69", name: "هزینه‌های مالی و سایر",
        children: [
          { level: 3, code: "691", name: "هزینه بانکی", children: [{ level: 4, code: "6911", name: "کارمزد بانکی" }] },
          { level: 3, code: "692", name: "هزینه مالی", children: [{ level: 4, code: "6921", name: "هزینه مالی" }] },
          { level: 3, code: "699", name: "سایر هزینه‌ها", children: [{ level: 4, code: "6991", name: "سایر هزینه‌ها" }] },
        ],
      },
    ],
  },
  { level: 1, code: "8", name: "حساب‌های انتظامی" },
  { level: 1, code: "9", name: "حساب‌های کنترلی" },
];

type Node = {
  level: number;
  code: string;
  name: string;
  children?: Node[];
};

function AccountRow({ node, depth = 0 }: { node: Node; depth?: number }) {
  const [open, setOpen] = useState(depth < 2);
  const hasChildren = node.children && node.children.length > 0;

  const levelColors = [
    "bg-navy-900 text-white font-bold",
    "bg-navy-100 text-navy-900 font-semibold",
    "bg-slate-50 text-slate-800",
    "bg-white text-slate-700",
  ];

  return (
    <div>
      <div
        className={`flex items-center gap-3 px-4 py-2.5 border-b border-slate-100 cursor-pointer hover:bg-gold-50/50 transition ${levelColors[node.level - 1] || ""}`}
        style={{ paddingRight: `${depth * 16 + 16}px` }}
        onClick={() => hasChildren && setOpen(!open)}
      >
        <span className="w-6 text-center text-xs opacity-70">
          {hasChildren ? (open ? "▼" : "◀") : "•"}
        </span>
        <span className="w-14 font-mono text-sm">{node.code}</span>
        <span className="flex-1 text-sm">{node.name}</span>
        <span className="text-xs opacity-50">سطح {node.level}</span>
      </div>
      {open && hasChildren && (
        <div>
          {node.children!.map((child) => (
            <AccountRow key={child.code} node={child} depth={depth + 1} />
          ))}
        </div>
      )}
    </div>
  );
}

export default function CodingPage() {
  return (
    <div className="min-h-screen bg-slate-50 pb-24">
      <PageHeader
        title="کدینگ حساب‌ها"
        subtitle="چهار سطح پویا — گروه، کل، معین، تفصیلی شناور"
        backHref="/"
      />

      <div className="mx-4 mt-4 bg-white shadow-sm rounded-xl overflow-hidden border border-slate-200">
        {CODING_TREE.map((node) => (
          <AccountRow key={node.code} node={node} />
        ))}
      </div>

      <p className="text-center text-xs text-slate-400 mt-6 mb-4">
        کدینگ استخراج‌شده از PDF دستورالعمل — MR,KHORASANI
      </p>

      <BottomNav />
    </div>
  );
}

