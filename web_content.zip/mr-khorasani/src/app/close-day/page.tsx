"use client";

import { useState, useMemo } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { PageHeader } from "@/components/layout/PageHeader";
import { BottomNav } from "@/components/layout/BottomNav";
import { useDayClose } from "@/store/day-close";
import { useOperations } from "@/store/operations";
import { formatMoney } from "@/lib/utils";
import { todayISO, todayJalali, toJalali } from "@/lib/date-utils";

export default function CloseDayPage() {
  const router = useRouter();
  const {
    runPreCloseChecks,
    closeDay,
    isDayClosed,
    getDay,
    requestAdjustment,
    getPendingAdjustments,
    closePackages,
    backups,
  } = useDayClose();
  const { getOperationsByDate } = useOperations();

  const [selectedDate, setSelectedDate] = useState(todayISO());
  const [confirmed, setConfirmed] = useState(false);
  const [closing, setClosing] = useState(false);
  const [resultPkg, setResultPkg] = useState<ReturnType<typeof closeDay>["package"] | null>(null);
  const [error, setError] = useState("");
  const [adjReason, setAdjReason] = useState("");
  const [showAdjForm, setShowAdjForm] = useState(false);

  const checks = useMemo(
    () => runPreCloseChecks(selectedDate),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [selectedDate, getOperationsByDate(selectedDate).length]
  );

  const hasErrors = checks.some((c) => c.status === "error");
  const closed = isDayClosed(selectedDate);
  const day = getDay(selectedDate);
  const dayOps = getOperationsByDate(selectedDate);
  const pendingAdjs = getPendingAdjustments().filter((r) => r.dayDate === selectedDate);

  const handleClose = () => {
    if (!confirmed) {
      setError("لطفاً تأیید نهایی را علامت بزنید");
      return;
    }
    setClosing(true);
    setError("");
    const result = closeDay(selectedDate);
    setClosing(false);
    if (!result.success) {
      setError(result.error || "خطا در بستن روز");
      return;
    }
    setResultPkg(result.package || null);
  };

  const handleRequestAdj = () => {
    if (!adjReason.trim()) {
      setError("دلیل درخواست الزامی است");
      return;
    }
    const r = requestAdjustment(selectedDate, adjReason);
    if (!r.success) {
      setError(r.error || "خطا");
      return;
    }
    setShowAdjForm(false);
    setAdjReason("");
    setError("");
    alert("درخواست اصلاح ثبت شد. منتظر تأیید مدیر مالی بمانید.");
  };

  // پس از بستن موفق — نمایش بسته روزانه
  if (resultPkg) {
    return (
      <div className="min-h-screen bg-slate-50 pb-24">
        <PageHeader title="روز بسته شد" subtitle={resultPkg.dayJalali} backHref="/" />
        <div className="px-4 mt-4 space-y-4">
          <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-5 text-center">
            <div className="text-3xl mb-2">✓</div>
            <div className="font-bold text-emerald-800">روز با موفقیت بسته شد</div>
            <div className="text-xs text-emerald-600 mt-1">
              اطلاعات این روز دیگر قابل ویرایش مستقیم نیستند
            </div>
          </div>

          <div className="bg-white rounded-xl border border-slate-100 p-4 shadow-sm space-y-3">
            <h3 className="text-sm font-semibold text-slate-700">بسته روزانه (Daily Closing Package)</h3>
            <Row label="تاریخ" value={resultPkg.dayJalali} />
            <Row label="تعداد عملیات" value={String(resultPkg.operationsCount)} />
            <Row label="تعداد اسناد" value={String(resultPkg.journalsCount)} />
            <Row label="جمع بدهکار" value={formatMoney(resultPkg.totalDebit)} />
            <Row label="جمع بستانکار" value={formatMoney(resultPkg.totalCredit)} />
            <Row label="دریافت‌ها" value={formatMoney(resultPkg.receiptsTotal)} />
            <Row label="پرداخت‌ها" value={formatMoney(resultPkg.paymentsTotal)} />
            <Row label="موجودی صندوق" value={formatMoney(resultPkg.cashBalance)} />
            <Row label="Backup" value={backups[0]?.label || "—"} />
          </div>

          <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-sm text-amber-800">
            برای اصلاح این روز فقط از مسیر «درخواست اصلاح روز بسته‌شده» و سپس سند اصلاحی استفاده کنید.
          </div>

          <Link href="/operations" className="block text-center btn-primary py-3 rounded-xl">
            بازگشت به عملیات
          </Link>
        </div>
        <BottomNav />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 pb-24">
      <PageHeader
        title="بستن روز"
        subtitle="End of Day · کنترل و قفل"
        backHref="/"
      />

      <div className="px-4 mt-4 space-y-4">
        {/* انتخاب تاریخ */}
        <div>
          <label className="text-xs text-slate-500 mb-1.5 block">تاریخ روز</label>
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => {
              setSelectedDate(e.target.value);
              setConfirmed(false);
              setError("");
              setResultPkg(null);
            }}
            className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-sm bg-white"
          />
          <div className="text-xs text-slate-400 mt-1">
            شمسی: {toJalali(selectedDate)}
            {selectedDate === todayISO() && " (امروز)"}
          </div>
        </div>

        {/* وضعیت روز */}
        {closed && (
          <div className="bg-navy-900 text-white rounded-xl p-4">
            <div className="font-bold">🔒 این روز بسته شده است</div>
            <div className="text-xs text-slate-300 mt-1">
              بسته در: {day?.closed_at ? new Date(day.closed_at).toLocaleString("fa-IR") : "—"}
            </div>
            <div className="text-xs text-slate-300">
              توسط: {day?.closed_by || "—"}
            </div>
            {day?.status === "reopened" && (
              <div className="text-xs text-gold-400 mt-1">
                وضعیت: بازگشایی‌شده برای اصلاح
              </div>
            )}
          </div>
        )}

        {/* خلاصه عملیات روز */}
        <div className="bg-white rounded-xl border border-slate-100 p-4 shadow-sm">
          <div className="text-sm font-semibold text-slate-700 mb-2">
            عملیات این روز: {dayOps.length}
          </div>
          {dayOps.length === 0 ? (
            <p className="text-xs text-slate-400">عملیاتی ثبت نشده</p>
          ) : (
            <ul className="text-xs text-slate-600 space-y-1 max-h-32 overflow-y-auto">
              {dayOps.slice(0, 8).map((o) => (
                <li key={o.id} className="flex justify-between">
                  <span className="truncate">{o.operation_number}</span>
                  <span>{formatMoney(o.amount)}</span>
                </li>
              ))}
              {dayOps.length > 8 && (
                <li className="text-slate-400">و {dayOps.length - 8} مورد دیگر...</li>
              )}
            </ul>
          )}
        </div>

        {/* چک‌لیست کنترل */}
        {!closed && (
          <>
            <div className="bg-white rounded-xl border border-slate-100 overflow-hidden shadow-sm">
              <div className="px-4 py-3 bg-navy-50 border-b border-slate-100">
                <h3 className="text-sm font-semibold text-navy-800">
                  کنترل‌های پیش از بستن
                </h3>
              </div>
              <div className="divide-y divide-slate-50">
                {checks.map((c) => (
                  <div key={c.id} className="px-4 py-3 flex items-start gap-3">
                    <span className="text-lg leading-none mt-0.5">
                      {c.status === "ok" ? "✅" : c.status === "warn" ? "⚠️" : "❌"}
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="text-sm text-slate-800">{c.label}</div>
                      {c.detail && (
                        <div className="text-xs text-slate-400 mt-0.5">{c.detail}</div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* هشدار نهایی */}
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-4">
              <label className="flex items-start gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={confirmed}
                  onChange={(e) => setConfirmed(e.target.checked)}
                  className="mt-1 rounded border-amber-400"
                />
                <span className="text-sm text-amber-900">
                  <strong>تأیید می‌کنم:</strong> پس از بستن روز، اطلاعات این روز قابل
                  ویرایش مستقیم نخواهد بود. اصلاح فقط از طریق سند اصلاحی انجام می‌شود.
                </span>
              </label>
            </div>

            {error && (
              <div className="bg-red-50 text-red-600 text-sm px-3 py-2.5 rounded-xl">
                {error}
              </div>
            )}

            <button
              onClick={handleClose}
              disabled={hasErrors || closing || !confirmed}
              className="w-full btn-primary py-3.5 font-bold disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {closing ? "در حال بستن..." : "بستن روز و قفل اسناد"}
            </button>

            {hasErrors && (
              <p className="text-xs text-center text-red-500">
                ابتدا خطاهای کنترل را برطرف کنید
              </p>
            )}
          </>
        )}

        {/* درخواست اصلاح برای روز بسته‌شده */}
        {closed && (
          <div className="space-y-3">
            {pendingAdjs.length > 0 && (
              <div className="bg-gold-50 border border-gold-200 rounded-xl p-4 text-sm text-gold-900">
                {pendingAdjs.length} درخواست اصلاح در انتظار تأیید مدیر
              </div>
            )}

            {!showAdjForm ? (
              <button
                onClick={() => setShowAdjForm(true)}
                className="w-full py-3 rounded-xl border-2 border-dashed border-navy-300 text-navy-700 text-sm font-medium hover:bg-navy-50"
              >
                درخواست اصلاح روز بسته‌شده
              </button>
            ) : (
              <div className="bg-white rounded-xl border border-slate-200 p-4 space-y-3">
                <label className="text-xs text-slate-500 block">دلیل درخواست *</label>
                <textarea
                  value={adjReason}
                  onChange={(e) => setAdjReason(e.target.value)}
                  rows={3}
                  placeholder="مثلاً: ثبت اشتباه مبلغ دریافت از مشتری..."
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm"
                />
                {error && (
                  <div className="text-xs text-red-500">{error}</div>
                )}
                <div className="flex gap-2">
                  <button
                    onClick={handleRequestAdj}
                    className="flex-1 btn-primary py-2.5 text-sm"
                  >
                    ثبت درخواست
                  </button>
                  <button
                    onClick={() => setShowAdjForm(false)}
                    className="px-4 py-2.5 text-sm text-slate-500"
                  >
                    انصراف
                  </button>
                </div>
              </div>
            )}

            <Link
              href="/close-day/admin"
              className="block text-center text-xs text-navy-600 mt-2"
            >
              پنل مدیر مالی (تأیید درخواست‌ها) →
            </Link>
          </div>
        )}

        {/* تاریخچه بستن */}
        {closePackages.length > 0 && (
          <div className="mt-6">
            <h3 className="text-sm font-semibold text-slate-600 mb-2">تاریخچه بستن روز</h3>
            <div className="space-y-2">
              {closePackages.slice(0, 5).map((pkg) => (
                <div
                  key={pkg.dayId}
                  className="bg-white rounded-lg border border-slate-100 px-3 py-2 text-xs flex justify-between"
                >
                  <span>{pkg.dayJalali}</span>
                  <span className="text-slate-400">
                    {pkg.operationsCount} عملیات · {formatMoney(pkg.totalDebit)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      <BottomNav />
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between text-sm">
      <span className="text-slate-500">{label}</span>
      <span className="text-slate-800 font-medium">{value}</span>
    </div>
  );
}
