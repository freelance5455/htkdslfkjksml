"use client";

import { useState } from "react";
import { PageHeader } from "@/components/layout/PageHeader";
import { BottomNav } from "@/components/layout/BottomNav";
import { useDayClose } from "@/store/day-close";
import { formatMoney } from "@/lib/utils";

/**
 * پنل مدیر مالی — تأیید / رد درخواست اصلاح روز بسته‌شده
 * در نسخه واقعی با Role-Based Access و احراز هویت مجدد محافظت می‌شود
 */
export default function CloseDayAdminPage() {
  const {
    adjustmentRequests,
    approveAdjustment,
    rejectAdjustment,
  } = useDayClose();
  const [note, setNote] = useState<Record<string, string>>({});
  const [message, setMessage] = useState("");

  const pending = adjustmentRequests.filter((r) => r.status === "pending");
  const history = adjustmentRequests.filter((r) => r.status !== "pending");

  const handleApprove = (id: string) => {
    if (
      !confirm(
        "با تأیید، روز به‌صورت موقت بازگشایی می‌شود تا سند اصلاحی ثبت شود.\nادامه می‌دهید؟"
      )
    )
      return;
    const r = approveAdjustment(id, note[id] || "تأیید مدیر مالی");
    setMessage(r.success ? "درخواست تأیید شد — روز برای ثبت اصلاحی باز است" : r.error || "خطا");
  };

  const handleReject = (id: string) => {
    const r = rejectAdjustment(id, note[id] || "رد توسط مدیر");
    setMessage(r.success ? "درخواست رد شد" : r.error || "خطا");
  };

  return (
    <div className="min-h-screen bg-slate-50 pb-24">
      <PageHeader
        title="پنل مدیر مالی"
        subtitle="تأیید درخواست اصلاح روز بسته‌شده"
        backHref="/close-day"
      />

      <div className="px-4 mt-4 space-y-4">
        <div className="bg-navy-900 text-white rounded-xl p-4 text-sm">
          <strong>توجه:</strong> فقط نقش مدیر مالی / Administrator مجاز به تأیید است.
          تمام اقدامات در Audit Log ثبت می‌شوند.
        </div>

        {message && (
          <div className="bg-emerald-50 text-emerald-800 text-sm px-3 py-2 rounded-xl">
            {message}
          </div>
        )}

        <h3 className="text-sm font-semibold text-slate-700">
          درخواست‌های در انتظار ({pending.length})
        </h3>

        {pending.length === 0 ? (
          <div className="text-center py-10 text-slate-400 text-sm">
            درخواست معلقی وجود ندارد
          </div>
        ) : (
          pending.map((req) => (
            <div
              key={req.id}
              className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm space-y-3"
            >
              <div className="flex justify-between text-sm">
                <span className="font-medium text-navy-800">{req.dayJalali}</span>
                <span className="text-xs text-slate-400">
                  {new Date(req.requestedAt).toLocaleString("fa-IR")}
                </span>
              </div>
              <div className="text-sm text-slate-700 bg-slate-50 rounded-lg p-3">
                {req.reason}
              </div>
              <div className="text-xs text-slate-400">
                درخواست‌کننده: {req.requestedBy}
              </div>
              <input
                value={note[req.id] || ""}
                onChange={(e) =>
                  setNote((n) => ({ ...n, [req.id]: e.target.value }))
                }
                placeholder="یادداشت مدیر (اختیاری)"
                className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm"
              />
              <div className="flex gap-2">
                <button
                  onClick={() => handleApprove(req.id)}
                  className="flex-1 btn-primary py-2.5 text-sm"
                >
                  تأیید و بازگشایی محدود
                </button>
                <button
                  onClick={() => handleReject(req.id)}
                  className="flex-1 py-2.5 rounded-lg border border-red-200 text-red-600 text-sm font-medium"
                >
                  رد
                </button>
              </div>
            </div>
          ))
        )}

        {history.length > 0 && (
          <div className="mt-6">
            <h3 className="text-sm font-semibold text-slate-600 mb-2">تاریخچه</h3>
            <div className="space-y-2">
              {history.map((req) => (
                <div
                  key={req.id}
                  className="bg-white rounded-lg border border-slate-100 px-3 py-2.5 text-xs"
                >
                  <div className="flex justify-between">
                    <span>{req.dayJalali}</span>
                    <span
                      className={
                        req.status === "approved"
                          ? "text-emerald-600"
                          : "text-red-500"
                      }
                    >
                      {req.status === "approved" ? "تأیید شده" : "رد شده"}
                    </span>
                  </div>
                  <div className="text-slate-400 mt-0.5 truncate">{req.reason}</div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      <BottomNav />
    </div>
  );
}
