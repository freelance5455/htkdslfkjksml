"use client";

import { useRef, useState } from "react";
import {
  parseCSV,
  mapToPartyRows,
  mapToProductRows,
  downloadCSVTemplate,
} from "@/lib/excel-import";
import { useMasterData } from "@/store/master-data";
import type { PartyType } from "@/types/database";

interface Props {
  type: "parties" | "products";
}

export function CSVImportButton({ type }: Props) {
  const inputRef = useRef<HTMLInputElement>(null);
  const { addParty, addProduct, checkPartyDuplicate, checkProductDuplicate } =
    useMasterData();
  const [msg, setMsg] = useState("");
  const [loading, setLoading] = useState(false);

  const handleFile = async (file: File) => {
    setLoading(true);
    setMsg("");
    try {
      const text = await file.text();
      const raw = parseCSV(text);
      let imported = 0;
      let skipped = 0;

      if (type === "parties") {
        const rows = mapToPartyRows(raw);
        for (const row of rows) {
          const types = row.party_type
            .split(",")
            .map((t) => t.trim())
            .filter(Boolean) as PartyType[];
          const dup = checkPartyDuplicate({
            mobile: row.mobile,
            national_id: row.national_id,
            name: row.name,
          });
          if (dup && !dup.includes("هشدار")) {
            skipped++;
            continue;
          }
          addParty({
            code: row.code,
            name: row.name,
            trade_name: row.trade_name,
            party_type: types.length ? types : ["customer"],
            mobile: row.mobile,
            phone: row.phone,
            national_id: row.national_id,
            address: row.address,
            description: row.description,
            is_active: true,
            opening_balance: row.opening_balance,
          });
          imported++;
        }
      } else {
        const rows = mapToProductRows(raw);
        for (const row of rows) {
          const dup = checkProductDuplicate({
            code: row.code,
            barcode: row.barcode,
            name: row.name,
          });
          if (dup && !dup.includes("هشدار")) {
            skipped++;
            continue;
          }
          addProduct({
            code: row.code,
            name: row.name,
            barcode: row.barcode,
            unit: row.unit || "عدد",
            category: row.category,
            purchase_price: row.purchase_price || 0,
            sale_price: row.sale_price || 0,
            description: row.description,
            is_active: true,
          });
          imported++;
        }
      }

      setMsg(
        `وارد شد: ${imported}${skipped ? ` · رد شد (تکراری): ${skipped}` : ""}`
      );
    } catch {
      setMsg("خطا در خواندن فایل");
    }
    setLoading(false);
    if (inputRef.current) inputRef.current.value = "";
  };

  return (
    <div className="flex flex-wrap items-center gap-2">
      <button
        type="button"
        onClick={() => downloadCSVTemplate(type)}
        className="text-xs px-3 py-1.5 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50"
      >
        دانلود الگو
      </button>
      <button
        type="button"
        onClick={() => inputRef.current?.click()}
        disabled={loading}
        className="text-xs px-3 py-1.5 rounded-lg bg-navy-800 text-white hover:bg-navy-900 disabled:opacity-50"
      >
        {loading ? "در حال ورود..." : "ورود از CSV / اکسل"}
      </button>
      <input
        ref={inputRef}
        type="file"
        accept=".csv,text/csv,.txt"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) handleFile(f);
        }}
      />
      {msg && <span className="text-xs text-emerald-600 w-full">{msg}</span>}
    </div>
  );
}
