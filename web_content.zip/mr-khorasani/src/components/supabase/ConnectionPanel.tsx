"use client";

import { useState } from "react";
import {
  isSupabaseConfigured,
  testSupabaseConnection,
} from "@/lib/supabase";
import { syncPartiesFromCloud } from "@/lib/repositories/parties-repo";
import { pullOperationsFromCloud } from "@/lib/repositories/operations-repo";

export function ConnectionPanel() {
  const [status, setStatus] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const configured = isSupabaseConfigured;

  const runTest = async () => {
    setLoading(true);
    setStatus("در حال تست...");
    const r = await testSupabaseConnection();
    setStatus(r.ok ? `✓ ${r.message}` : `✗ ${r.message}`);
    setLoading(false);
  };

  const runSync = async () => {
    setLoading(true);
    setStatus("همگام‌سازی...");
    try {
      const nParties = await syncPartiesFromCloud();
      const nOps = await pullOperationsFromCloud();
      setStatus(`✓ همگام شد: ${nParties} شخص · ${nOps} عملیات جدید از ابر`);
    } catch (e) {
      setStatus(`✗ ${e instanceof Error ? e.message : "خطا"}`);
    }
    setLoading(false);
  };

  return (
    <div className="bg-white rounded-xl border border-slate-100 p-4 shadow-sm space-y-3">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold text-slate-800">اتصال Supabase</h3>
        <span
          className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${
            configured
              ? "bg-emerald-50 text-emerald-700"
              : "bg-slate-100 text-slate-500"
          }`}
        >
          {configured ? "پیکربندی شده" : "محلی (بدون ابر)"}
        </span>
      </div>

      <p className="text-xs text-slate-500 leading-relaxed">
        {configured
          ? "کلیدهای .env.local خوانده شده‌اند. تست اتصال و همگام‌سازی را اجرا کنید."
          : "برای اتصال واقعی، در ریشه پروژه فایل .env.local بسازید و NEXT_PUBLIC_SUPABASE_URL و NEXT_PUBLIC_SUPABASE_ANON_KEY را از پنل Supabase بگذارید. سپس migrationهای SQL را اجرا کنید."}
      </p>

      <div className="flex flex-wrap gap-2">
        <button
          type="button"
          onClick={runTest}
          disabled={loading}
          className="text-xs px-3 py-2 rounded-lg bg-navy-800 text-white disabled:opacity-50"
        >
          تست اتصال
        </button>
        <button
          type="button"
          onClick={runSync}
          disabled={loading || !configured}
          className="text-xs px-3 py-2 rounded-lg border border-navy-200 text-navy-800 disabled:opacity-40"
        >
          همگام‌سازی از ابر
        </button>
      </div>

      {status && (
        <div className="text-xs bg-slate-50 rounded-lg p-2 text-slate-700 whitespace-pre-wrap">
          {status}
        </div>
      )}

      <div className="text-[10px] text-slate-400 font-mono dir-ltr text-left">
        URL: {process.env.NEXT_PUBLIC_SUPABASE_URL ? "set" : "not set"}
      </div>
    </div>
  );
}
