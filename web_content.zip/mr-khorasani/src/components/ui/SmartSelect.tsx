"use client";

import { useState, useRef, useEffect } from "react";
import { cn } from "@/lib/utils";

interface Option {
  id: string;
  label: string;
  subLabel?: string;
  badge?: string;
}

interface SmartSelectProps {
  options: Option[];
  value?: string;
  onChange: (id: string, option: Option) => void;
  placeholder?: string;
  searchPlaceholder?: string;
  emptyText?: string;
  className?: string;
  disabled?: boolean;
  onQuickAdd?: () => void;
  quickAddLabel?: string;
}

export function SmartSelect({
  options,
  value,
  onChange,
  placeholder = "جستجو و انتخاب...",
  searchPlaceholder = "نام، کد یا شماره...",
  emptyText = "موردی یافت نشد",
  className,
  disabled,
  onQuickAdd,
  quickAddLabel = "+ جدید",
}: SmartSelectProps) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const selected = options.find((o) => o.id === value);

  const filtered = query.trim()
    ? options.filter(
        (o) =>
          o.label.toLowerCase().includes(query.toLowerCase()) ||
          (o.subLabel && o.subLabel.toLowerCase().includes(query.toLowerCase()))
      )
    : options;

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
        setQuery("");
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    if (open && inputRef.current) {
      inputRef.current.focus();
    }
  }, [open]);

  return (
    <div ref={containerRef} className={cn("relative", className)}>
      <button
        type="button"
        disabled={disabled}
        onClick={() => setOpen(!open)}
        className={cn(
          "w-full flex items-center justify-between gap-2 px-3 py-2.5 rounded-lg border text-right text-sm transition",
          "bg-white border-slate-200 hover:border-navy-400 focus:outline-none focus:ring-2 focus:ring-navy-500/30",
          disabled && "opacity-50 cursor-not-allowed",
          open && "border-navy-500 ring-2 ring-navy-500/20"
        )}
      >
        <span className={selected ? "text-slate-800" : "text-slate-400"}>
          {selected ? (
            <span>
              {selected.label}
              {selected.subLabel && (
                <span className="text-slate-400 text-xs mr-2">({selected.subLabel})</span>
              )}
            </span>
          ) : (
            placeholder
          )}
        </span>
        <span className="text-slate-400 text-xs">{open ? "▲" : "▼"}</span>
      </button>

      {open && (
        <div className="absolute z-50 mt-1 w-full bg-white border border-slate-200 rounded-xl shadow-lg overflow-hidden">
          <div className="p-2 border-b border-slate-100">
            <input
              ref={inputRef}
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={searchPlaceholder}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-navy-500/30"
            />
          </div>

          <div className="max-h-56 overflow-y-auto">
            {filtered.length === 0 ? (
              <div className="px-4 py-6 text-center text-sm text-slate-400">{emptyText}</div>
            ) : (
              filtered.map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => {
                    onChange(opt.id, opt);
                    setOpen(false);
                    setQuery("");
                  }}
                  className={cn(
                    "w-full flex items-center justify-between px-4 py-2.5 text-sm text-right hover:bg-navy-50 transition",
                    value === opt.id && "bg-navy-50 text-navy-800 font-medium"
                  )}
                >
                  <div>
                    <div>{opt.label}</div>
                    {opt.subLabel && (
                      <div className="text-xs text-slate-400 mt-0.5">{opt.subLabel}</div>
                    )}
                  </div>
                  {opt.badge && (
                    <span className="text-xs bg-gold-100 text-gold-800 px-2 py-0.5 rounded-full">
                      {opt.badge}
                    </span>
                  )}
                </button>
              ))
            )}
          </div>

          {onQuickAdd && (
            <button
              type="button"
              onClick={() => {
                setOpen(false);
                onQuickAdd();
              }}
              className="w-full px-4 py-2.5 text-sm text-navy-700 font-medium border-t border-slate-100 hover:bg-gold-50 transition"
            >
              {quickAddLabel}
            </button>
          )}
        </div>
      )}
    </div>
  );
}
