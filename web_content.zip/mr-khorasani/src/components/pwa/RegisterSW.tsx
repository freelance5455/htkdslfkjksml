"use client";

import { useEffect, useState } from "react";

export function RegisterSW() {
  const [offline, setOffline] = useState(false);
  const [installPrompt, setInstallPrompt] = useState<Event | null>(null);

  useEffect(() => {
    if (typeof window === "undefined") return;

    const onOnline = () => setOffline(false);
    const onOffline = () => setOffline(true);
    setOffline(!navigator.onLine);
    window.addEventListener("online", onOnline);
    window.addEventListener("offline", onOffline);

    // Service Worker
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("/sw.js").catch(() => {
        /* ignore in dev */
      });
    }

    // Install prompt (Chrome/Android)
    const onBip = (e: Event) => {
      e.preventDefault();
      setInstallPrompt(e);
    };
    window.addEventListener("beforeinstallprompt", onBip);

    return () => {
      window.removeEventListener("online", onOnline);
      window.removeEventListener("offline", onOffline);
      window.removeEventListener("beforeinstallprompt", onBip);
    };
  }, []);

  const handleInstall = async () => {
    if (!installPrompt) return;
    // @ts-expect-error beforeinstallprompt API
    await installPrompt.prompt();
    setInstallPrompt(null);
  };

  return (
    <>
      {offline && (
        <div className="fixed top-0 inset-x-0 z-[60] bg-amber-500 text-navy-950 text-center text-xs font-medium py-1.5">
          حالت آفلاین — عملیات در دستگاه ذخیره می‌شود و پس از اتصال همگام می‌گردد
        </div>
      )}
      {installPrompt && !offline && (
        <div className="fixed bottom-20 inset-x-4 z-[60] max-w-lg mx-auto">
          <div className="bg-navy-900 text-white rounded-xl p-3 shadow-lg flex items-center justify-between gap-3">
            <div className="text-xs">
              <div className="font-bold">نصب اپلیکیشن</div>
              <div className="text-slate-300 mt-0.5">MR,KHORASANI روی صفحه اصلی</div>
            </div>
            <button
              onClick={handleInstall}
              className="shrink-0 bg-gold-500 text-navy-950 text-xs font-bold px-3 py-2 rounded-lg"
            >
              نصب
            </button>
          </div>
        </div>
      )}
    </>
  );
}
