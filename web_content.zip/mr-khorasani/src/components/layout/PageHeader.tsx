"use client";

import Link from "next/link";

interface PageHeaderProps {
  title: string;
  subtitle?: string;
  backHref?: string;
  action?: React.ReactNode;
}

export function PageHeader({ title, subtitle, backHref, action }: PageHeaderProps) {
  return (
    <header className="bg-navy-950 text-white px-4 py-3 flex items-center justify-between sticky top-0 z-20 shadow-md">
      <div className="flex items-center gap-3 min-w-0">
        {backHref && (
          <Link href={backHref} className="text-gold-400 hover:text-gold-300 shrink-0 text-lg">
            ←
          </Link>
        )}
        <div className="min-w-0">
          <h1 className="font-bold text-base truncate">{title}</h1>
          {subtitle && (
            <p className="text-xs text-slate-400 truncate">{subtitle}</p>
          )}
        </div>
      </div>
      <div className="flex items-center gap-2 shrink-0">
        {action}
        <div className="w-8 h-8 rounded-lg bg-gold-500 flex items-center justify-center text-navy-950 font-bold text-sm">
          K
        </div>
      </div>
    </header>
  );
}
