"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";

const NAV_ITEMS = [
  { href: "/", label: "داشبورد", icon: "▣" },
  { href: "/operations", label: "عملیات", icon: "₽" },
  { href: "/reports", label: "گزارش", icon: "▤" },
  { href: "/parties", label: "اشخاص", icon: "👥" },
  { href: "/sources", label: "منابع", icon: "🏦" },
];

export function BottomNav() {
  const pathname = usePathname();

  return (
    <nav className="fixed bottom-0 inset-x-0 z-40 bg-white border-t border-slate-200 safe-area-pb">
      <div className="max-w-lg mx-auto flex items-center justify-around py-2">
        {NAV_ITEMS.map((item) => {
          const active =
            item.href === "/"
              ? pathname === "/"
              : pathname.startsWith(item.href);
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex flex-col items-center gap-0.5 px-3 py-1.5 rounded-lg text-xs transition min-w-[56px]",
                active
                  ? "text-navy-800 font-semibold"
                  : "text-slate-400 hover:text-slate-600"
              )}
            >
              <span className="text-lg leading-none">{item.icon}</span>
              <span>{item.label}</span>
              {active && (
                <span className="w-1 h-1 rounded-full bg-gold-500 mt-0.5" />
              )}
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
