// ============================================================
// MR,KHORASANI — TypeScript Types (فاز ۱)
// ============================================================

export type AccountType =
  | "asset"
  | "liability"
  | "equity"
  | "revenue"
  | "cogs"
  | "expense"
  | "contra"
  | "control";

export type AccountNature = "debit" | "credit";

export type OperationType =
  | "receipt"
  | "payment"
  | "transfer"
  | "sale"
  | "sale_return"
  | "purchase"
  | "purchase_return"
  | "expense"
  | "income"
  | "receipt_invoice"
  | "payment_invoice"
  | "check_receive"
  | "check_pay"
  | "check_clear"
  | "check_bounce"
  | "petty_cash"
  | "adjustment"
  | "manual"
  | "opening"
  | "closing";

export type JournalType =
  | "auto"
  | "manual"
  | "adjustment"
  | "reversal"
  | "opening"
  | "closing";

export type DayStatus = "open" | "closed" | "reopened";
export type RecordStatus = "draft" | "posted" | "deleted" | "reversed";
export type DiscountMode = "percent" | "amount";
export type SourceType = "cash" | "bank" | "petty_cash" | "pos";
export type PartyType =
  | "customer"
  | "supplier"
  | "employee"
  | "partner"
  | "other"
  | "bank"
  | "government";

export interface Company {
  id: string;
  name: string;
  name_en: string;
  fiscal_year_start: string;
  fiscal_year_end: string;
  current_fiscal_year: number;
  created_at: string;
  updated_at: string;
}

export interface Role {
  id: string;
  code: string;
  name_fa: string;
  name_en?: string;
  permissions: Record<string, boolean>;
}

export interface User {
  id: string;
  company_id: string;
  username: string;
  mobile?: string;
  full_name: string;
  role_id: string;
  is_active: boolean;
  last_login_at?: string;
}

export interface FiscalYear {
  id: string;
  company_id: string;
  year: number;
  start_date: string;
  end_date: string;
  is_current: boolean;
  is_closed: boolean;
}

export interface Account {
  id: string;
  company_id: string;
  code: string;
  name_fa: string;
  name_en?: string;
  level: 1 | 2 | 3 | 4;
  parent_id?: string;
  account_type: AccountType;
  nature: AccountNature;
  is_leaf: boolean;
  is_active: boolean;
  is_floating_detail: boolean;
  allow_manual_entry: boolean;
  description?: string;
  children?: Account[];
}

export interface FinancialSource {
  id: string;
  company_id: string;
  account_id: string;
  code: string;
  name_fa: string;
  source_type: SourceType;
  bank_name?: string;
  branch_name?: string;
  account_number?: string;
  sheba?: string;
  card_number?: string;
  opening_balance: number;
  current_balance: number;
  is_active: boolean;
  opened_at?: string;
  description?: string;
}

export interface Party {
  id: string;
  company_id: string;
  code: string;
  name: string;
  trade_name?: string;
  party_type: PartyType[];
  mobile?: string;
  phone?: string;
  address?: string;
  national_id?: string;
  economic_code?: string;
  is_active: boolean;
  opening_balance: number;
  current_balance: number;
  description?: string;
  deleted_at?: string;
}

export interface Product {
  id: string;
  company_id: string;
  code: string;
  name: string;
  barcode?: string;
  unit: string;
  category?: string;
  subcategory?: string;
  purchase_price: number;
  sale_price: number;
  is_active: boolean;
  description?: string;
  deleted_at?: string;
}

export interface FinancialDay {
  id: string;
  company_id: string;
  fiscal_year_id: string;
  day_date: string;
  day_jalali: string;
  status: DayStatus;
  closed_by?: string;
  closed_at?: string;
  reopened_by?: string;
  reopened_at?: string;
  reopen_reason?: string;
  backup_path?: string;
}

export interface Operation {
  id: string;
  company_id: string;
  fiscal_year_id: string;
  financial_day_id?: string;
  operation_number: string;
  operation_type: OperationType;
  operation_date: string;
  operation_date_jalali: string;
  party_id?: string;
  financial_source_id?: string;
  amount: number;
  description?: string;
  reference_number?: string;
  status: RecordStatus;
  is_locked: boolean;
  created_by: string;
  created_at: string;
  updated_at: string;
  deleted_at?: string;
  deleted_by?: string;
  delete_reason?: string;
  version: number;
  sync_status: "pending" | "synced" | "conflict";
  lines?: OperationLine[];
}

export interface OperationLine {
  id: string;
  operation_id: string;
  product_id?: string;
  description?: string;
  quantity: number;
  unit_price: number;
  line_amount: number;
  discount_mode?: DiscountMode;
  discount_percent: number;
  discount_amount: number;
  shipping_cost: number;
  line_total: number;
  sort_order: number;
}

export interface JournalEntry {
  id: string;
  company_id: string;
  fiscal_year_id: string;
  financial_day_id?: string;
  journal_number: string;
  journal_date: string;
  journal_date_jalali: string;
  description: string;
  operation_id?: string;
  journal_type: JournalType;
  original_journal_id?: string;
  total_debit: number;
  total_credit: number;
  is_balanced: boolean;
  status: RecordStatus;
  is_locked: boolean;
  created_by: string;
  created_at: string;
  updated_at: string;
  deleted_at?: string;
  version: number;
  lines?: JournalLine[];
}

export interface JournalLine {
  id: string;
  journal_id: string;
  account_id: string;
  party_id?: string;
  financial_source_id?: string;
  debit: number;
  credit: number;
  description?: string;
  cost_center?: string;
  project?: string;
  sort_order: number;
  account?: Account;
  party?: Party;
}

export interface AuditLog {
  id: string;
  company_id: string;
  user_id?: string;
  username?: string;
  action: string;
  entity: string;
  entity_id?: string;
  old_value?: Record<string, unknown>;
  new_value?: Record<string, unknown>;
  reason?: string;
  device_id?: string;
  ip_address?: string;
  created_at: string;
}

export interface TrialBalanceRow {
  account_id: string;
  code: string;
  name_fa: string;
  level: number;
  opening_debit: number;
  opening_credit: number;
  period_debit: number;
  period_credit: number;
  closing_debit: number;
  closing_credit: number;
}
