/**
 * Store بستن روز + قفل + درخواست اصلاح
 * فاز ۴ — MR,KHORASANI
 *
 * اصل: پس از Closed هیچ ویرایش/حذف مستقیمی مجاز نیست.
 * فقط Adjustment / Reversal Entry.
 */

import { create } from "zustand";
import { v4 as uuidv4 } from "uuid";
import type { FinancialDay, DayStatus } from "@/types/database";
import { todayISO, toJalali } from "@/lib/date-utils";
import { useOperations } from "@/store/operations";
import { useMasterData } from "@/store/master-data";

export interface CloseCheckItem {
  id: string;
  label: string;
  status: "ok" | "warn" | "error";
  detail?: string;
}

export interface DayClosePackage {
  dayId: string;
  dayDate: string;
  dayJalali: string;
  operationsCount: number;
  journalsCount: number;
  totalDebit: number;
  totalCredit: number;
  cashBalance: number;
  bankBalances: { name: string; balance: number }[];
  receiptsTotal: number;
  paymentsTotal: number;
  closedAt: string;
  closedBy: string;
  backupId: string;
}

export interface AdjustmentRequest {
  id: string;
  dayDate: string;
  dayJalali: string;
  reason: string;
  requestedBy: string;
  requestedAt: string;
  status: "pending" | "approved" | "rejected";
  reviewedBy?: string;
  reviewedAt?: string;
  reviewNote?: string;
}

interface DayCloseState {
  days: FinancialDay[];
  closePackages: DayClosePackage[];
  adjustmentRequests: AdjustmentRequest[];
  backups: { id: string; dayDate: string; createdAt: string; label: string }[];

  /** اجرای کنترل‌های پیش از بستن */
  runPreCloseChecks: (dateISO?: string) => CloseCheckItem[];

  /** بستن روز — فقط اگر همه کنترل‌های error برطرف شده باشند */
  closeDay: (
    dateISO: string,
    userId?: string
  ) => { success: boolean; error?: string; package?: DayClosePackage };

  /** آیا روز مشخص بسته است؟ */
  isDayClosed: (dateISO: string) => boolean;

  /** درخواست اصلاح روز بسته‌شده */
  requestAdjustment: (
    dateISO: string,
    reason: string,
    userId?: string
  ) => { success: boolean; error?: string; request?: AdjustmentRequest };

  /** تأیید درخواست اصلاح توسط مدیر (بازگشایی محدود) */
  approveAdjustment: (
    requestId: string,
    note?: string,
    userId?: string
  ) => { success: boolean; error?: string };

  /** رد درخواست */
  rejectAdjustment: (
    requestId: string,
    note?: string,
    userId?: string
  ) => { success: boolean; error?: string };

  getDay: (dateISO: string) => FinancialDay | undefined;
  getTodayStatus: () => DayStatus | "none";
  getPendingAdjustments: () => AdjustmentRequest[];
}

export const useDayClose = create<DayCloseState>((set, get) => ({
  days: [],
  closePackages: [],
  adjustmentRequests: [],
  backups: [],

  runPreCloseChecks: (dateISO) => {
    const date = dateISO || todayISO();
    const ops = useOperations.getState();
    const master = useMasterData.getState();
    const dayOps = ops.operations.filter(
      (o) => o.operation_date === date && o.status === "posted"
    );
    const dayJournals = ops.journals.filter(
      (j) => j.journal_date === date && j.status === "posted"
    );

    const checks: CloseCheckItem[] = [];

    // 1. وجود عملیات
    checks.push({
      id: "has_ops",
      label: "وجود عملیات ثبت‌شده",
      status: dayOps.length > 0 ? "ok" : "warn",
      detail:
        dayOps.length > 0
          ? `${dayOps.length} عملیات`
          : "هیچ عملیاتی برای این روز ثبت نشده",
    });

    // 2. توازن همه اسناد
    const unbalanced = dayJournals.filter((j) => !j.is_balanced);
    checks.push({
      id: "balanced",
      label: "توازن اسناد (بدهکار = بستانکار)",
      status: unbalanced.length === 0 ? "ok" : "error",
      detail:
        unbalanced.length === 0
          ? `${dayJournals.length} سند متوازن`
          : `${unbalanced.length} سند نامتوازن`,
    });

    // 3. مبلغ منفی / صفر غیرمجاز
    const zeroOrNeg = dayOps.filter((o) => o.amount <= 0);
    checks.push({
      id: "amounts",
      label: "مبالغ معتبر (بزرگ‌تر از صفر)",
      status: zeroOrNeg.length === 0 ? "ok" : "error",
      detail:
        zeroOrNeg.length === 0
          ? "همه مبالغ معتبر"
          : `${zeroOrNeg.length} عملیات با مبلغ نامعتبر`,
    });

    // 4. عملیات بدون منبع مالی (برای انواع نیازمند منبع)
    const needsSource = ["receipt", "payment", "expense", "income", "sale", "purchase", "transfer"];
    const missingSource = dayOps.filter(
      (o) => needsSource.includes(o.operation_type) && !o.financial_source_id
    );
    checks.push({
      id: "sources",
      label: "منبع مالی مشخص برای دریافت/پرداخت",
      status: missingSource.length === 0 ? "ok" : "error",
      detail:
        missingSource.length === 0
          ? "همه منابع مشخص"
          : `${missingSource.length} عملیات بدون منبع`,
    });

    // 5. وضعیت صندوق و بانک
    const sources = master.getActiveSources();
    const totalCash = sources.reduce((s, src) => s + src.current_balance, 0);
    checks.push({
      id: "liquidity",
      label: "وضعیت نقدینگی قابل کنترل",
      status: "ok",
      detail: `جمع نقدینگی: ${totalCash.toLocaleString("fa-IR")} ریال`,
    });

    // 6. روز قبلاً بسته نشده باشد
    const existing = get().days.find((d) => d.day_date === date);
    checks.push({
      id: "not_closed",
      label: "روز هنوز باز است",
      status: existing?.status === "closed" ? "error" : "ok",
      detail:
        existing?.status === "closed"
          ? "این روز قبلاً بسته شده"
          : "آماده بستن",
    });

    // 7. Backup (شبیه‌سازی)
    checks.push({
      id: "backup",
      label: "آمادگی پشتیبان‌گیری",
      status: "ok",
      detail: "Backup خودکار پس از تأیید ایجاد می‌شود",
    });

    return checks;
  },

  closeDay: (dateISO, userId = "user-admin") => {
    const checks = get().runPreCloseChecks(dateISO);
    const errors = checks.filter((c) => c.status === "error");
    if (errors.length > 0) {
      return {
        success: false,
        error: `کنترل ناموفق: ${errors.map((e) => e.label).join("، ")}`,
      };
    }

    const ops = useOperations.getState();
    const master = useMasterData.getState();
    const dayOps = ops.operations.filter(
      (o) => o.operation_date === dateISO && o.status === "posted"
    );
    const dayJournals = ops.journals.filter(
      (j) => j.journal_date === dateISO && j.status === "posted"
    );

    // قفل کردن همه عملیات و اسناد آن روز
    ops.lockDay(dateISO);

    const dayId = uuidv4();
    const backupId = uuidv4();
    const dayJalali = toJalali(dateISO);
    const closedAt = new Date().toISOString();

    const sources = master.getActiveSources();
    const cashBalance =
      sources.find((s) => s.source_type === "cash")?.current_balance || 0;
    const bankBalances = sources
      .filter((s) => s.source_type === "bank")
      .map((s) => ({ name: s.name_fa, balance: s.current_balance }));

    const receiptsTotal = dayOps
      .filter((o) =>
        ["receipt", "receipt_invoice", "income", "sale"].includes(o.operation_type)
      )
      .reduce((s, o) => s + o.amount, 0);
    const paymentsTotal = dayOps
      .filter((o) =>
        ["payment", "payment_invoice", "expense", "purchase"].includes(
          o.operation_type
        )
      )
      .reduce((s, o) => s + o.amount, 0);

    const totalDebit = dayJournals.reduce((s, j) => s + j.total_debit, 0);
    const totalCredit = dayJournals.reduce((s, j) => s + j.total_credit, 0);

    const day: FinancialDay = {
      id: dayId,
      company_id: "c1",
      fiscal_year_id: "fy-1405",
      day_date: dateISO,
      day_jalali: dayJalali,
      status: "closed",
      closed_by: userId,
      closed_at: closedAt,
      backup_path: `MR-KHORASANI-Backup-${dayJalali.replace(/\//g, "-")}`,
    };

    const pkg: DayClosePackage = {
      dayId,
      dayDate: dateISO,
      dayJalali,
      operationsCount: dayOps.length,
      journalsCount: dayJournals.length,
      totalDebit,
      totalCredit,
      cashBalance,
      bankBalances,
      receiptsTotal,
      paymentsTotal,
      closedAt,
      closedBy: userId,
      backupId,
    };

    set((s) => ({
      days: [...s.days.filter((d) => d.day_date !== dateISO), day],
      closePackages: [pkg, ...s.closePackages],
      backups: [
        {
          id: backupId,
          dayDate: dateISO,
          createdAt: closedAt,
          label: `MR-KHORASANI-Backup-${dayJalali.replace(/\//g, "-")}`,
        },
        ...s.backups,
      ],
    }));

    return { success: true, package: pkg };
  },

  isDayClosed: (dateISO) => {
    const day = get().days.find((d) => d.day_date === dateISO);
    return day?.status === "closed";
  },

  requestAdjustment: (dateISO, reason, userId = "user-admin") => {
    if (!get().isDayClosed(dateISO)) {
      return {
        success: false,
        error: "این روز بسته نیست. می‌توانید مستقیماً ویرایش کنید.",
      };
    }
    if (!reason.trim()) {
      return { success: false, error: "دلیل درخواست اصلاح الزامی است" };
    }

    const req: AdjustmentRequest = {
      id: uuidv4(),
      dayDate: dateISO,
      dayJalali: toJalali(dateISO),
      reason: reason.trim(),
      requestedBy: userId,
      requestedAt: new Date().toISOString(),
      status: "pending",
    };

    set((s) => ({
      adjustmentRequests: [req, ...s.adjustmentRequests],
    }));

    return { success: true, request: req };
  },

  approveAdjustment: (requestId, note, userId = "user-admin") => {
    const req = get().adjustmentRequests.find((r) => r.id === requestId);
    if (!req || req.status !== "pending") {
      return { success: false, error: "درخواست معتبر نیست" };
    }

    // بازگشایی محدود روز برای ثبت سند اصلاحی
    useOperations.getState().unlockDay(req.dayDate);

    set((s) => ({
      days: s.days.map((d) =>
        d.day_date === req.dayDate
          ? {
              ...d,
              status: "reopened" as DayStatus,
              reopened_by: userId,
              reopened_at: new Date().toISOString(),
              reopen_reason: req.reason,
            }
          : d
      ),
      adjustmentRequests: s.adjustmentRequests.map((r) =>
        r.id === requestId
          ? {
              ...r,
              status: "approved" as const,
              reviewedBy: userId,
              reviewedAt: new Date().toISOString(),
              reviewNote: note,
            }
          : r
      ),
    }));

    return { success: true };
  },

  rejectAdjustment: (requestId, note, userId = "user-admin") => {
    const req = get().adjustmentRequests.find((r) => r.id === requestId);
    if (!req || req.status !== "pending") {
      return { success: false, error: "درخواست معتبر نیست" };
    }

    set((s) => ({
      adjustmentRequests: s.adjustmentRequests.map((r) =>
        r.id === requestId
          ? {
              ...r,
              status: "rejected" as const,
              reviewedBy: userId,
              reviewedAt: new Date().toISOString(),
              reviewNote: note,
            }
          : r
      ),
    }));

    return { success: true };
  },

  getDay: (dateISO) => get().days.find((d) => d.day_date === dateISO),

  getTodayStatus: () => {
    const day = get().days.find((d) => d.day_date === todayISO());
    return day?.status || "none";
  },

  getPendingAdjustments: () =>
    get().adjustmentRequests.filter((r) => r.status === "pending"),
}));
