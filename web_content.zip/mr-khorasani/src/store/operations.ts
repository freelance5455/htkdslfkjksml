/**
 * Zustand Store — عملیات روزانه + اسناد حسابداری
 * فاز ۳ — قبل از بستن روز قابل ویرایش و Soft Delete
 */

import { create } from "zustand";
import { v4 as uuidv4 } from "uuid";
import type {
  Operation,
  OperationLine,
  JournalEntry,
  JournalLine,
  OperationType,
  RecordStatus,
} from "@/types/database";
import {
  generateJournalLines,
  validateOperation,
  type EngineInput,
} from "@/lib/accounting-engine";
import { todayISO, todayJalali, generateNumber, toJalali } from "@/lib/date-utils";
import { useMasterData } from "@/store/master-data";

interface OperationsState {
  operations: Operation[];
  journals: JournalEntry[];
  journalLines: JournalLine[];
  opSequence: number;
  jvSequence: number;
  /** تاریخ‌های بسته‌شده — جلوگیری از ثبت عملیات جدید روی روز closed */
  closedDates: string[];

  /** ثبت عملیات جدید + تولید خودکار سند دوبل */
  createOperation: (input: CreateOperationInput) => {
    success: boolean;
    error?: string;
    operation?: Operation;
    journal?: JournalEntry;
  };

  /** ویرایش قبل از بستن روز */
  updateOperation: (
    id: string,
    input: Partial<CreateOperationInput>
  ) => { success: boolean; error?: string };

  /** حذف منطقی قبل از بستن روز */
  softDeleteOperation: (
    id: string,
    reason?: string
  ) => { success: boolean; error?: string };

  getOperationsByDate: (dateISO: string) => Operation[];
  getTodayOperations: () => Operation[];
  getOperationById: (id: string) => Operation | undefined;
  getJournalByOperationId: (operationId: string) => JournalEntry | undefined;
  getJournalLines: (journalId: string) => JournalLine[];

  /** قفل تمام عملیات و اسناد یک روز (پس از بستن روز) */
  lockDay: (dateISO: string) => void;
  /** بازگشایی محدود برای ثبت سند اصلاحی */
  unlockDay: (dateISO: string) => void;

  /** ثبت سند اصلاحی / برگشت برای روز بسته‌شده یا بازگشایی‌شده */
  createAdjustment: (input: {
    originalOperationId?: string;
    originalJournalId?: string;
    amount: number;
    description: string;
    partyId?: string;
    financialSourceId?: string;
    operationDate?: string;
  }) => { success: boolean; error?: string; operation?: Operation; journal?: JournalEntry };
}

export interface CreateOperationInput {
  operationType: OperationType;
  amount: number;
  partyId?: string;
  financialSourceId?: string;
  /** برای انتقال: منبع مقصد */
  targetSourceId?: string;
  expenseOrIncomeAccountCode?: string;
  description?: string;
  referenceNumber?: string;
  operationDate?: string; // ISO
  /** اقلام فاکتور فروش/خرید */
  lines?: Array<{
    productId?: string;
    description?: string;
    quantity: number;
    unitPrice: number;
    discountMode?: "percent" | "amount";
    discountPercent?: number;
    discountAmount?: number;
    shippingCost?: number;
  }>;
  discountAmount?: number;
  shippingCost?: number;
  cogsAmount?: number;
}

/** نگاشت کد حساب به id موقت (mock) — در اتصال واقعی از DB خوانده می‌شود */
const ACCOUNT_CODE_MAP: Record<string, string> = {
  "1111": "acc-1111",
  "1121": "acc-1121",
  "1122": "acc-1122",
  "1123": "acc-1123",
  "1124": "acc-1124",
  "1125": "acc-1125",
  "1126": "acc-1126",
  "1127": "acc-1127",
  "1128": "acc-1128",
  "1129": "acc-1129",
  "1130": "acc-1130",
  "1131": "acc-1131",
  "1211": "acc-1211",
  "2111": "acc-2111",
  "4111": "acc-4111",
  "4131": "acc-4131",
  "5111": "acc-5111",
  "1311": "acc-1311",
  "5211": "acc-5211",
  "6141": "acc-6141",
  "4311": "acc-4311",
  "6991": "acc-6991",
  "4391": "acc-4391",
  "6111": "acc-6111",
  "6121": "acc-6121",
};

function resolveAccountId(code: string): string | undefined {
  return ACCOUNT_CODE_MAP[code];
}

function resolveSourceAccountId(sourceId: string): string | undefined {
  const sources = useMasterData.getState().sources;
  const src = sources.find((s) => s.id === sourceId);
  if (!src) return undefined;
  return ACCOUNT_CODE_MAP[src.code] || `acc-${src.code}`;
}

export const useOperations = create<OperationsState>((set, get) => ({
  operations: [],
  journals: [],
  journalLines: [],
  opSequence: 1,
  jvSequence: 1,
  closedDates: [],

  createOperation: (input) => {
    const dateISO = input.operationDate || todayISO();
    const isAdjustment = input.operationType === "adjustment";

    // جلوگیری از ثبت عادی روی روز بسته (سند اصلاحی مجاز است اگر unlock شده)
    if (get().closedDates.includes(dateISO) && !isAdjustment) {
      // اگر هنوز is_locked روی عملیات آن روز true است یعنی unlock نشده
      const stillLocked = get().operations.some(
        (o) => o.operation_date === dateISO && o.is_locked
      );
      if (stillLocked) {
        return {
          success: false,
          error:
            "روز بسته شده است. امکان ثبت عملیات جدید وجود ندارد. از مسیر درخواست اصلاح و سند اصلاحی استفاده کنید.",
        };
      }
    }

    const errors = validateOperation({
      operationType: input.operationType,
      amount: input.amount,
      partyId: input.partyId,
      financialSourceId: input.financialSourceId,
    });
    if (errors.length > 0) {
      return { success: false, error: errors.join(" — ") };
    }

    // محاسبه مبلغ از اقلام در صورت وجود
    let amount = input.amount;
    let discountAmount = input.discountAmount || 0;
    let shippingCost = input.shippingCost || 0;

    if (input.lines && input.lines.length > 0) {
      let gross = 0;
      let disc = 0;
      let ship = 0;
      for (const line of input.lines) {
        const lineAmount = line.quantity * line.unitPrice;
        let lineDisc = 0;
        if (line.discountMode === "percent" && line.discountPercent) {
          lineDisc = Math.round((lineAmount * line.discountPercent) / 100);
        } else if (line.discountAmount) {
          lineDisc = line.discountAmount;
        }
        gross += lineAmount;
        disc += lineDisc;
        ship += line.shippingCost || 0;
      }
      // سطح فاکتور
      if (input.discountAmount) disc = input.discountAmount;
      if (input.shippingCost) ship = input.shippingCost;
      amount = gross - disc + ship;
      discountAmount = disc;
      shippingCost = ship;
    }

    if (amount <= 0) {
      return { success: false, error: "مبلغ نهایی باید بزرگ‌تر از صفر باشد" };
    }

    const dateISO = input.operationDate || todayISO();
    const dateJalali = toJalali(dateISO);
    const seq = get().opSequence;
    const jvSeq = get().jvSequence;
    const opNumber = generateNumber("OP", 1405, seq);
    const jvNumber = generateNumber("JV", 1405, jvSeq);
    const opId = uuidv4();
    const jvId = uuidv4();
    const userId = "user-admin";

    // تولید ردیف‌های سند
    let engineResult;
    try {
      const engineInput: EngineInput = {
        operationType: input.operationType,
        amount,
        partyId: input.partyId,
        financialSourceId: input.financialSourceId,
        discountAmount,
        shippingCost,
        cogsAmount: input.cogsAmount,
        description: input.description,
        expenseOrIncomeAccountId: input.expenseOrIncomeAccountCode
          ? resolveAccountId(input.expenseOrIncomeAccountCode)
          : undefined,
      };

      // انتقال: بدهکار مقصد، بستانکار مبدأ
      if (input.operationType === "transfer" && input.targetSourceId) {
        const destAcc = resolveSourceAccountId(input.targetSourceId);
        const srcAcc = resolveSourceAccountId(input.financialSourceId || "");
        if (!destAcc || !srcAcc) {
          return { success: false, error: "منبع مبدأ یا مقصد نامعتبر است" };
        }
        engineResult = {
          lines: [
            {
              account_id: destAcc,
              financial_source_id: input.targetSourceId,
              debit: amount,
              credit: 0,
              description: "بدهکار مقصد انتقال",
              sort_order: 1,
            },
            {
              account_id: srcAcc,
              financial_source_id: input.financialSourceId,
              debit: 0,
              credit: amount,
              description: "بستانکار مبدأ انتقال",
              sort_order: 2,
            },
          ],
          description: input.description || "انتقال بین منابع مالی",
          isBalanced: true,
          totalDebit: amount,
          totalCredit: amount,
        };
      } else {
        engineResult = generateJournalLines(
          engineInput,
          resolveAccountId,
          resolveSourceAccountId
        );
      }
    } catch (e) {
      return {
        success: false,
        error: e instanceof Error ? e.message : "خطا در تولید سند",
      };
    }

    if (!engineResult.isBalanced) {
      return {
        success: false,
        error: `سند نامتوازن: بدهکار ${engineResult.totalDebit} ≠ بستانکار ${engineResult.totalCredit}`,
      };
    }

    const operation: Operation = {
      id: opId,
      company_id: "c1",
      fiscal_year_id: "fy-1405",
      operation_number: opNumber,
      operation_type: input.operationType,
      operation_date: dateISO,
      operation_date_jalali: dateJalali,
      party_id: input.partyId,
      financial_source_id: input.financialSourceId,
      amount,
      description: input.description || engineResult.description,
      reference_number: input.referenceNumber,
      status: "posted",
      is_locked: false,
      created_by: userId,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      version: 1,
      sync_status: "pending",
    };

    const opLines: OperationLine[] = (input.lines || []).map((l, i) => {
      const lineAmount = l.quantity * l.unitPrice;
      let disc = 0;
      if (l.discountMode === "percent" && l.discountPercent) {
        disc = Math.round((lineAmount * l.discountPercent) / 100);
      } else {
        disc = l.discountAmount || 0;
      }
      const ship = l.shippingCost || 0;
      return {
        id: uuidv4(),
        operation_id: opId,
        product_id: l.productId,
        description: l.description,
        quantity: l.quantity,
        unit_price: l.unitPrice,
        line_amount: lineAmount,
        discount_mode: l.discountMode,
        discount_percent: l.discountPercent || 0,
        discount_amount: disc,
        shipping_cost: ship,
        line_total: lineAmount - disc + ship,
        sort_order: i + 1,
      };
    });

    const journal: JournalEntry = {
      id: jvId,
      company_id: "c1",
      fiscal_year_id: "fy-1405",
      journal_number: jvNumber,
      journal_date: dateISO,
      journal_date_jalali: dateJalali,
      description: engineResult.description,
      operation_id: opId,
      journal_type: "auto",
      total_debit: engineResult.totalDebit,
      total_credit: engineResult.totalCredit,
      is_balanced: true,
      status: "posted",
      is_locked: false,
      created_by: userId,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      version: 1,
    };

    const jLines: JournalLine[] = engineResult.lines.map((l, i) => ({
      id: uuidv4(),
      journal_id: jvId,
      account_id: l.account_id,
      party_id: l.party_id,
      financial_source_id: l.financial_source_id,
      debit: l.debit,
      credit: l.credit,
      description: l.description,
      sort_order: l.sort_order || i + 1,
      created_at: new Date().toISOString(),
    }));

    // به‌روزرسانی مانده منابع (mock)
    if (input.financialSourceId) {
      const master = useMasterData.getState();
      const src = master.getSourceById(input.financialSourceId);
      if (src) {
        let delta = 0;
        if (["receipt", "receipt_invoice", "income", "sale"].includes(input.operationType)) {
          delta = amount;
        } else if (["payment", "payment_invoice", "expense", "purchase"].includes(input.operationType)) {
          delta = -amount;
        } else if (input.operationType === "transfer") {
          delta = -amount;
        }
        if (delta !== 0) {
          master.updateSourceBalance(input.financialSourceId, src.current_balance + delta);
        }
      }
    }
    if (input.operationType === "transfer" && input.targetSourceId) {
      const master = useMasterData.getState();
      const dest = master.getSourceById(input.targetSourceId);
      if (dest) {
        master.updateSourceBalance(input.targetSourceId, dest.current_balance + amount);
      }
    }

    set((s) => ({
      operations: [{ ...operation, lines: opLines }, ...s.operations],
      journals: [journal, ...s.journals],
      journalLines: [...jLines, ...s.journalLines],
      opSequence: s.opSequence + 1,
      jvSequence: s.jvSequence + 1,
    }));

    return { success: true, operation, journal };
  },

  updateOperation: (id, input) => {
    const op = get().operations.find((o) => o.id === id);
    if (!op) return { success: false, error: "عملیات یافت نشد" };
    if (op.is_locked) {
      return {
        success: false,
        error: "روز بسته شده است. امکان ویرایش مستقیم وجود ندارد. از سند اصلاحی استفاده کنید.",
      };
    }
    if (op.status === "deleted") {
      return { success: false, error: "این عملیات حذف شده است" };
    }

    // برای سادگی در فاز ۳: حذف منطقی قبلی + ثبت جدید
    // در نسخه کامل: ویرایش in-place + اصلاح سند مرتبط
    get().softDeleteOperation(id, "ویرایش — جایگزینی با نسخه جدید");
    const result = get().createOperation({
      operationType: input.operationType || op.operation_type,
      amount: input.amount ?? op.amount,
      partyId: input.partyId ?? op.party_id,
      financialSourceId: input.financialSourceId ?? op.financial_source_id,
      description: input.description ?? op.description,
      referenceNumber: input.referenceNumber ?? op.reference_number,
      operationDate: input.operationDate ?? op.operation_date,
      lines: input.lines,
      discountAmount: input.discountAmount,
      shippingCost: input.shippingCost,
      targetSourceId: input.targetSourceId,
      expenseOrIncomeAccountCode: input.expenseOrIncomeAccountCode,
      cogsAmount: input.cogsAmount,
    });
    return result;
  },

  softDeleteOperation: (id, reason) => {
    const op = get().operations.find((o) => o.id === id);
    if (!op) return { success: false, error: "عملیات یافت نشد" };
    if (op.is_locked) {
      return {
        success: false,
        error: "روز بسته شده است. امکان حذف مستقیم وجود ندارد.",
      };
    }

    set((s) => ({
      operations: s.operations.map((o) =>
        o.id === id
          ? {
              ...o,
              status: "deleted" as RecordStatus,
              deleted_at: new Date().toISOString(),
              deleted_by: "user-admin",
              delete_reason: reason || "حذف توسط کاربر",
              updated_at: new Date().toISOString(),
            }
          : o
      ),
      journals: s.journals.map((j) =>
        j.operation_id === id
          ? {
              ...j,
              status: "deleted" as RecordStatus,
              deleted_at: new Date().toISOString(),
              updated_at: new Date().toISOString(),
            }
          : j
      ),
    }));

    // برگشت مانده منبع (تقریبی)
    if (op.financial_source_id && op.status === "posted") {
      const master = useMasterData.getState();
      const src = master.getSourceById(op.financial_source_id);
      if (src) {
        let delta = 0;
        if (["receipt", "receipt_invoice", "income", "sale"].includes(op.operation_type)) {
          delta = -op.amount;
        } else if (["payment", "payment_invoice", "expense", "purchase"].includes(op.operation_type)) {
          delta = op.amount;
        }
        if (delta !== 0) {
          master.updateSourceBalance(op.financial_source_id, src.current_balance + delta);
        }
      }
    }

    return { success: true };
  },

  getOperationsByDate: (dateISO) =>
    get().operations.filter(
      (o) => o.operation_date === dateISO && o.status !== "deleted"
    ),

  getTodayOperations: () => get().getOperationsByDate(todayISO()),

  getOperationById: (id) => get().operations.find((o) => o.id === id),

  getJournalByOperationId: (operationId) =>
    get().journals.find(
      (j) => j.operation_id === operationId && j.status !== "deleted"
    ),

  getJournalLines: (journalId) =>
    get().journalLines.filter((l) => l.journal_id === journalId),

  lockDay: (dateISO) => {
    set((s) => ({
      closedDates: s.closedDates.includes(dateISO)
        ? s.closedDates
        : [...s.closedDates, dateISO],
      operations: s.operations.map((o) =>
        o.operation_date === dateISO && o.status === "posted"
          ? { ...o, is_locked: true }
          : o
      ),
      journals: s.journals.map((j) =>
        j.journal_date === dateISO && j.status === "posted"
          ? { ...j, is_locked: true }
          : j
      ),
    }));
  },

  unlockDay: (dateISO) => {
    set((s) => ({
      operations: s.operations.map((o) =>
        o.operation_date === dateISO ? { ...o, is_locked: false } : o
      ),
      journals: s.journals.map((j) =>
        j.journal_date === dateISO ? { ...j, is_locked: false } : j
      ),
    }));
  },

  createAdjustment: (input) => {
    // سند اصلاحی همیشه از نوع adjustment ثبت می‌شود
    return get().createOperation({
      operationType: "adjustment",
      amount: input.amount,
      partyId: input.partyId,
      financialSourceId: input.financialSourceId,
      description:
        input.description ||
        `سند اصلاحی${input.originalOperationId ? ` — مرتبط با عملیات قبلی` : ""}`,
      operationDate: input.operationDate || todayISO(),
      referenceNumber: input.originalJournalId || input.originalOperationId,
    });
  },
}));
