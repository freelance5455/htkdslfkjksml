/**
 * Zustand Store — Master Data (اشخاص، کالا، منابع مالی)
 * فاز ۲ — آماده اتصال به Supabase
 */

import { create } from "zustand";
import { v4 as uuidv4 } from "uuid";
import type { Party, Product, FinancialSource, PartyType } from "@/types/database";
import { MOCK_PARTIES, MOCK_PRODUCTS, MOCK_SOURCES } from "@/lib/mock-data";

interface MasterDataState {
  parties: Party[];
  products: Product[];
  sources: FinancialSource[];

  // Parties
  addParty: (data: Omit<Party, "id" | "company_id" | "created_at" | "updated_at" | "opening_balance" | "current_balance"> & { opening_balance?: number }) => Party;
  updateParty: (id: string, data: Partial<Party>) => void;
  softDeleteParty: (id: string) => void;
  searchParties: (query: string, typeFilter?: PartyType[]) => Party[];
  getPartyById: (id: string) => Party | undefined;
  checkPartyDuplicate: (data: { mobile?: string; national_id?: string; name?: string; excludeId?: string }) => string | null;

  // Products
  addProduct: (data: Omit<Product, "id" | "company_id" | "created_at" | "updated_at">) => Product;
  updateProduct: (id: string, data: Partial<Product>) => void;
  softDeleteProduct: (id: string) => void;
  searchProducts: (query: string) => Product[];
  getProductById: (id: string) => Product | undefined;
  checkProductDuplicate: (data: { code?: string; barcode?: string; name?: string; excludeId?: string }) => string | null;

  // Sources
  getActiveSources: () => FinancialSource[];
  getSourceById: (id: string) => FinancialSource | undefined;
  updateSourceBalance: (id: string, newBalance: number) => void;
}

export const useMasterData = create<MasterDataState>((set, get) => ({
  parties: MOCK_PARTIES,
  products: MOCK_PRODUCTS,
  sources: MOCK_SOURCES,

  // ─── Parties ───
  addParty: (data) => {
    const party: Party = {
      id: uuidv4(),
      company_id: "c1",
      code: data.code,
      name: data.name,
      trade_name: data.trade_name,
      party_type: data.party_type || ["customer"],
      mobile: data.mobile,
      phone: data.phone,
      address: data.address,
      national_id: data.national_id,
      economic_code: data.economic_code,
      is_active: data.is_active ?? true,
      opening_balance: data.opening_balance ?? 0,
      current_balance: data.opening_balance ?? 0,
      description: data.description,
    };
    set((s) => ({ parties: [party, ...s.parties] }));
    return party;
  },

  updateParty: (id, data) => {
    set((s) => ({
      parties: s.parties.map((p) => (p.id === id ? { ...p, ...data } : p)),
    }));
  },

  softDeleteParty: (id) => {
    set((s) => ({
      parties: s.parties.map((p) =>
        p.id === id ? { ...p, is_active: false, deleted_at: new Date().toISOString() } : p
      ),
    }));
  },

  searchParties: (query, typeFilter) => {
    const q = query.trim().toLowerCase();
    return get().parties.filter((p) => {
      if (!p.is_active || p.deleted_at) return false;
      if (typeFilter && typeFilter.length > 0) {
        if (!typeFilter.some((t) => p.party_type.includes(t))) return false;
      }
      if (!q) return true;
      return (
        p.name.toLowerCase().includes(q) ||
        p.code.toLowerCase().includes(q) ||
        (p.mobile && p.mobile.includes(q)) ||
        (p.trade_name && p.trade_name.toLowerCase().includes(q)) ||
        (p.national_id && p.national_id.includes(q))
      );
    });
  },

  getPartyById: (id) => get().parties.find((p) => p.id === id),

  checkPartyDuplicate: ({ mobile, national_id, name, excludeId }) => {
    const list = get().parties.filter((p) => p.id !== excludeId && p.is_active && !p.deleted_at);
    if (mobile && list.some((p) => p.mobile === mobile)) return "شماره موبایل تکراری است";
    if (national_id && list.some((p) => p.national_id === national_id)) return "کد ملی/شناسه ملی تکراری است";
    if (name && list.some((p) => p.name.trim() === name.trim())) return "نام شخص تکراری است (هشدار)";
    return null;
  },

  // ─── Products ───
  addProduct: (data) => {
    const product: Product = {
      id: uuidv4(),
      company_id: "c1",
      code: data.code,
      name: data.name,
      barcode: data.barcode,
      unit: data.unit || "عدد",
      category: data.category,
      subcategory: data.subcategory,
      purchase_price: data.purchase_price || 0,
      sale_price: data.sale_price || 0,
      is_active: data.is_active ?? true,
      description: data.description,
    };
    set((s) => ({ products: [product, ...s.products] }));
    return product;
  },

  updateProduct: (id, data) => {
    set((s) => ({
      products: s.products.map((p) => (p.id === id ? { ...p, ...data } : p)),
    }));
  },

  softDeleteProduct: (id) => {
    set((s) => ({
      products: s.products.map((p) =>
        p.id === id ? { ...p, is_active: false, deleted_at: new Date().toISOString() } : p
      ),
    }));
  },

  searchProducts: (query) => {
    const q = query.trim().toLowerCase();
    return get().products.filter((p) => {
      if (!p.is_active || p.deleted_at) return false;
      if (!q) return true;
      return (
        p.name.toLowerCase().includes(q) ||
        p.code.toLowerCase().includes(q) ||
        (p.barcode && p.barcode.includes(q)) ||
        (p.category && p.category.toLowerCase().includes(q))
      );
    });
  },

  getProductById: (id) => get().products.find((p) => p.id === id),

  checkProductDuplicate: ({ code, barcode, name, excludeId }) => {
    const list = get().products.filter((p) => p.id !== excludeId && p.is_active && !p.deleted_at);
    if (code && list.some((p) => p.code === code)) return "کد کالا تکراری است";
    if (barcode && list.some((p) => p.barcode === barcode)) return "بارکد تکراری است";
    if (name && list.some((p) => p.name.trim() === name.trim())) return "نام کالا تکراری است (هشدار)";
    return null;
  },

  // ─── Sources ───
  getActiveSources: () => get().sources.filter((s) => s.is_active),
  getSourceById: (id) => get().sources.find((s) => s.id === id),
  updateSourceBalance: (id, newBalance) => {
    set((s) => ({
      sources: s.sources.map((src) =>
        src.id === id ? { ...src, current_balance: newBalance } : src
      ),
    }));
  },
}));
