#!/usr/bin/env bash
# ساخت خودکار APK نصبی — MR,KHORASANI
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

echo "=== MR,KHORASANI APK Auto Builder ==="

# 1) Dependencies
if [ ! -d node_modules/next ]; then
  echo "[1/5] npm install..."
  npm install
fi
npm install @capacitor/core @capacitor/cli @capacitor/android --save --no-audit --no-fund 2>/dev/null || true

# 2) Static export
echo "[2/5] Building web (static)..."
BUILD_MOBILE=1 npx next build || {
  echo "Static export failed — falling back to standard build + out copy"
  npx next build
  mkdir -p out
  cp -r .next/static out/ 2>/dev/null || true
}

# Ensure out exists for Capacitor
if [ ! -d out ]; then
  mkdir -p out
  echo '<!DOCTYPE html><html lang="fa" dir="rtl"><body><h1>MR,KHORASANI</h1><p>Build incomplete</p></body></html>' > out/index.html
fi

# 3) Capacitor android
echo "[3/5] Capacitor Android..."
if [ ! -d android ]; then
  npx cap add android
fi
npx cap sync android

# 4) Assemble
echo "[4/5] Gradle assembleDebug..."
cd android
chmod +x gradlew 2>/dev/null || true
./gradlew assembleDebug --no-daemon

# 5) Copy APK
echo "[5/5] Copy APK..."
APK=$(find app/build/outputs/apk -name "*.apk" | head -1)
DEST="$ROOT/MR-KHORASANI-install.apk"
cp "$APK" "$DEST"
echo ""
echo "✓ APK آماده است:"
echo "  $DEST"
ls -lh "$DEST"
