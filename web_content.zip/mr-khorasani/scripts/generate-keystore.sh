#!/usr/bin/env bash
# تولید Keystore برای امضای APK — MR,KHORASANI
# استفاده: bash scripts/generate-keystore.sh

set -e
DIR="$(cd "$(dirname "$0")/.." && pwd)"
KEYSTORE="$DIR/android-release.keystore"
ALIAS="mrkhorasani"

if [ -f "$KEYSTORE" ]; then
  echo "Keystore از قبل وجود دارد: $KEYSTORE"
  echo "اگر می‌خواهید دوباره بسازید، ابتدا فایل را حذف کنید."
  exit 0
fi

echo "=== تولید Keystore امضای انتشار MR,KHORASANI ==="
echo "رمزها را در جای امن نگه دارید — بدون آن‌ها به‌روزرسانی استور ممکن نیست."
echo ""

keytool -genkeypair \
  -v \
  -storetype PKCS12 \
  -keystore "$KEYSTORE" \
  -alias "$ALIAS" \
  -keyalg RSA \
  -keysize 2048 \
  -validity 10000 \
  -dname "CN=MR KHORASANI, OU=Finance, O=MrKhorasani, L=Tehran, ST=Tehran, C=IR"

echo ""
echo "✓ ساخته شد: $KEYSTORE"
echo "Alias: $ALIAS"
echo ""
echo "مرحله بعد — فایل android/key.properties (بعد از cap add android):"
echo "  storePassword=YOUR_STORE_PASSWORD"
echo "  keyPassword=YOUR_KEY_PASSWORD"
echo "  keyAlias=$ALIAS"
echo "  storeFile=../android-release.keystore"
echo ""
echo "سپس در android/app/build.gradle بخش signingConfigs را طبق docs/signed-apk.md تنظیم کنید."
