# MR,KHORASANI — سیستم حسابداری حرفه‌ای v1.0

**Financial Management & Accounting**  
آقای خراسانی · دقت · کنترل · شفافیت

## محتویات این بسته

سورس کامل اپ (بدون node_modules) شامل:

| فاز | محتوا |
|-----|--------|
| ۱ | Schema PostgreSQL + کدینگ ۴سطحی + Accounting Engine |
| ۲ | اشخاص، کالا، ۱۰ بانک ایرانی، SmartSelect |
| ۳ | عملیات روزانه + سند دوبل اتوماتیک |
| ۴ | بستن روز + قفل + درخواست اصلاح + پنل مدیر |
| ۵ | تراز آزمایشی، دفتر روزنامه/کل، سود و زیان، KPI |
| ۶ | PWA + Service Worker + Capacitor Android |
| + | ورود CSV/اکسل، سناریوی تست، راهنمای Supabase |

## نصب سریع

```bash
unzip MR-KHORASANI-Final.zip
cd mr-khorasani
npm install
npm run dev
```

باز کردن: http://localhost:3000

### تست یک‌کلیکه
تنظیمات → **اجرای سناریوی نمایشی** → سپس گزارش‌ها → تراز آزمایشی

### ورود اشخاص/کالا
صفحات اشخاص و کالا → دانلود الگو → ورود از CSV

### PWA
Chrome موبایل → افزودن به صفحه اصلی

### APK
```bash
npm install @capacitor/core @capacitor/cli @capacitor/android --save
npx cap add android
npm run android
```
جزئیات: `docs/android-build.md` و `docs/supabase-setup.md`

## ساختار مسیرها

```
/                 داشبورد
/operations       عملیات روزانه
/operations/new   ثبت عملیات
/close-day        بستن روز
/reports          تراز، روزنامه، کل، سود، KPI
/parties          اشخاص + ورود CSV
/products         کالا + ورود CSV
/sources          منابع مالی
/coding           کدینگ حساب‌ها
/settings         تنظیمات، نصب، سناریوی تست
```

## اصل حسابداری

```
عملیات کاربر → اعتبارسنجی → موتور سند → ژورنال دوبل
→ دفتر کل → تراز آزمایشی → KPI → بستن روز → قفل
```

پس از بستن روز فقط **سند اصلاحی** مجاز است (Soft Delete + Audit).

---
**MR,KHORASANI** · Professional Accounting System
