-- ============================================================
-- Seed داده‌های اولیه: شرکت، نقش‌ها، کاربر، سال مالی، منابع مالی
-- و اجرای کدینگ با company_id واقعی
-- ============================================================

DO $$
DECLARE
  v_company_id UUID;
  v_role_admin UUID;
  v_role_fm UUID;
  v_role_acc UUID;
  v_user_id UUID;
  v_fy_id UUID;
  v_acc_id UUID;
BEGIN
  -- ۱. شرکت پیش‌فرض
  INSERT INTO companies (name, name_en, fiscal_year_start, fiscal_year_end, current_fiscal_year)
  VALUES ('آقای خراسانی', 'MR,KHORASANI', '2026-03-21', '2027-03-20', 1405)
  RETURNING id INTO v_company_id;

  -- ۲. نقش‌ها
  INSERT INTO roles (code, name_fa, name_en, permissions) VALUES
    ('admin', 'مدیر سیستم', 'System Admin', '{"all": true}'),
    ('financial_manager', 'مدیر مالی', 'Financial Manager', '{"reports": true, "close_day": true, "operations": true}'),
    ('accountant', 'حسابدار', 'Accountant', '{"operations": true, "journals": true}'),
    ('cashier', 'صندوقدار', 'Cashier', '{"receipt": true, "payment": true}'),
    ('sales', 'کاربر فروش', 'Sales User', '{"sale": true}'),
    ('viewer', 'ناظر', 'Viewer', '{"view": true}')
  ON CONFLICT (code) DO NOTHING;

  SELECT id INTO v_role_admin FROM roles WHERE code = 'admin';
  SELECT id INTO v_role_fm FROM roles WHERE code = 'financial_manager';

  -- ۳. کاربر اولیه
  INSERT INTO users (company_id, username, full_name, role_id, mobile)
  VALUES (v_company_id, 'admin', 'مدیر سیستم', v_role_admin, '09120000000')
  RETURNING id INTO v_user_id;

  -- ۴. سال مالی ۱۴۰۵
  INSERT INTO fiscal_years (company_id, year, start_date, end_date, is_current)
  VALUES (v_company_id, 1405, '2026-03-21', '2027-03-20', TRUE)
  RETURNING id INTO v_fy_id;

  -- ۵. کدینگ کامل (با company_id واقعی)
  -- گروه ۱ دارایی‌ها
  PERFORM seed_account(v_company_id, '1', 'دارایی‌ها', 1, NULL, 'asset', 'debit');
  PERFORM seed_account(v_company_id, '11', 'موجودی نقد و بانک', 2, '1', 'asset', 'debit');
  PERFORM seed_account(v_company_id, '12', 'حساب‌ها و اسناد دریافتنی', 2, '1', 'asset', 'debit');
  PERFORM seed_account(v_company_id, '13', 'موجودی کالا', 2, '1', 'asset', 'debit');
  PERFORM seed_account(v_company_id, '14', 'پیش‌پرداخت‌ها و سپرده‌ها', 2, '1', 'asset', 'debit');
  PERFORM seed_account(v_company_id, '15', 'دارایی‌های ثابت', 2, '1', 'asset', 'debit');

  PERFORM seed_account(v_company_id, '111', 'صندوق', 3, '11', 'asset', 'debit');
  PERFORM seed_account(v_company_id, '1111', 'وجه نقد صندوق', 4, '111', 'asset', 'debit', TRUE);

  PERFORM seed_account(v_company_id, '112', 'بانک‌ها', 3, '11', 'asset', 'debit');
  PERFORM seed_account(v_company_id, '1121', 'بانک ملی ایران', 4, '112', 'asset', 'debit', TRUE);
  PERFORM seed_account(v_company_id, '1122', 'بانک ملت', 4, '112', 'asset', 'debit', TRUE);
  PERFORM seed_account(v_company_id, '1123', 'بانک صادرات ایران', 4, '112', 'asset', 'debit', TRUE);
  PERFORM seed_account(v_company_id, '1124', 'بانک تجارت', 4, '112', 'asset', 'debit', TRUE);
  PERFORM seed_account(v_company_id, '1125', 'بانک سپه', 4, '112', 'asset', 'debit', TRUE);
  PERFORM seed_account(v_company_id, '1126', 'بانک رفاه کارگران', 4, '112', 'asset', 'debit', TRUE);
  PERFORM seed_account(v_company_id, '1127', 'بانک کشاورزی', 4, '112', 'asset', 'debit', TRUE);
  PERFORM seed_account(v_company_id, '1128', 'بانک مسکن', 4, '112', 'asset', 'debit', TRUE);
  PERFORM seed_account(v_company_id, '1129', 'بانک پارسیان', 4, '112', 'asset', 'debit', TRUE);

  PERFORM seed_account(v_company_id, '113', 'تنخواه', 3, '11', 'asset', 'debit');
  PERFORM seed_account(v_company_id, '1130', 'بانک سامان', 4, '112', 'asset', 'debit', TRUE);
  PERFORM seed_account(v_company_id, '1131', 'تنخواه گردان', 4, '113', 'asset', 'debit', TRUE);

  PERFORM seed_account(v_company_id, '121', 'حساب‌های دریافتنی', 3, '12', 'asset', 'debit');
  PERFORM seed_account(v_company_id, '1211', 'مشتریان', 4, '121', 'asset', 'debit', TRUE, TRUE);

  PERFORM seed_account(v_company_id, '122', 'اسناد دریافتنی', 3, '12', 'asset', 'debit');
  PERFORM seed_account(v_company_id, '1221', 'چک‌های دریافتنی', 4, '122', 'asset', 'debit', TRUE);

  PERFORM seed_account(v_company_id, '131', 'موجودی کالا', 3, '13', 'asset', 'debit');
  PERFORM seed_account(v_company_id, '1311', 'موجودی کالا', 4, '131', 'asset', 'debit', TRUE);

  PERFORM seed_account(v_company_id, '141', 'پیش‌پرداخت‌ها', 3, '14', 'asset', 'debit');
  PERFORM seed_account(v_company_id, '1411', 'پیش‌پرداخت تأمین‌کنندگان', 4, '141', 'asset', 'debit', TRUE, TRUE);
  PERFORM seed_account(v_company_id, '142', 'سپرده‌ها', 3, '14', 'asset', 'debit');

  PERFORM seed_account(v_company_id, '151', 'دارایی ثابت', 3, '15', 'asset', 'debit');
  PERFORM seed_account(v_company_id, '1511', 'اثاثه و تجهیزات', 4, '151', 'asset', 'debit', TRUE);
  PERFORM seed_account(v_company_id, '152', 'استهلاک انباشته', 3, '15', 'contra', 'credit');
  PERFORM seed_account(v_company_id, '1521', 'استهلاک انباشته دارایی ثابت', 4, '152', 'contra', 'credit', TRUE);

  -- گروه ۲ بدهی‌ها
  PERFORM seed_account(v_company_id, '2', 'بدهی‌ها', 1, NULL, 'liability', 'credit');
  PERFORM seed_account(v_company_id, '21', 'حساب‌ها و اسناد پرداختنی', 2, '2', 'liability', 'credit');
  PERFORM seed_account(v_company_id, '211', 'حساب‌های پرداختنی', 3, '21', 'liability', 'credit');
  PERFORM seed_account(v_company_id, '2111', 'تأمین‌کنندگان', 4, '211', 'liability', 'credit', TRUE, TRUE);
  PERFORM seed_account(v_company_id, '212', 'اسناد پرداختنی', 3, '21', 'liability', 'credit');
  PERFORM seed_account(v_company_id, '2121', 'چک‌های پرداختنی', 4, '212', 'liability', 'credit', TRUE);

  PERFORM seed_account(v_company_id, '22', 'مالیات، بیمه و حقوق', 2, '2', 'liability', 'credit');
  PERFORM seed_account(v_company_id, '221', 'مالیات پرداختنی', 3, '22', 'liability', 'credit');
  PERFORM seed_account(v_company_id, '2211', 'مالیات بر ارزش افزوده پرداختنی', 4, '221', 'liability', 'credit', TRUE);
  PERFORM seed_account(v_company_id, '222', 'بیمه پرداختنی', 3, '22', 'liability', 'credit');
  PERFORM seed_account(v_company_id, '2221', 'بیمه تأمین اجتماعی پرداختنی', 4, '222', 'liability', 'credit', TRUE);
  PERFORM seed_account(v_company_id, '223', 'حقوق پرداختنی', 3, '22', 'liability', 'credit');
  PERFORM seed_account(v_company_id, '2231', 'حقوق پرداختنی کارکنان', 4, '223', 'liability', 'credit', TRUE);

  PERFORM seed_account(v_company_id, '23', 'پیش‌دریافت‌ها و سایر بدهی‌ها', 2, '2', 'liability', 'credit');
  PERFORM seed_account(v_company_id, '231', 'پیش‌دریافت‌ها', 3, '23', 'liability', 'credit');
  PERFORM seed_account(v_company_id, '2311', 'پیش‌دریافت از مشتریان', 4, '231', 'liability', 'credit', TRUE, TRUE);
  PERFORM seed_account(v_company_id, '239', 'سایر بدهی‌ها', 3, '23', 'liability', 'credit');

  -- گروه ۳ سرمایه
  PERFORM seed_account(v_company_id, '3', 'سرمایه', 1, NULL, 'equity', 'credit');
  PERFORM seed_account(v_company_id, '31', 'حقوق صاحبان سرمایه', 2, '3', 'equity', 'credit');
  PERFORM seed_account(v_company_id, '311', 'سرمایه', 3, '31', 'equity', 'credit');
  PERFORM seed_account(v_company_id, '3111', 'سرمایه اولیه', 4, '311', 'equity', 'credit', TRUE);
  PERFORM seed_account(v_company_id, '321', 'برداشت', 3, '31', 'equity', 'debit');
  PERFORM seed_account(v_company_id, '3211', 'برداشت شرکا', 4, '321', 'equity', 'debit', TRUE);
  PERFORM seed_account(v_company_id, '331', 'سود و زیان انباشته', 3, '31', 'equity', 'credit');
  PERFORM seed_account(v_company_id, '3311', 'سود و زیان انباشته', 4, '331', 'equity', 'credit', TRUE);
  PERFORM seed_account(v_company_id, '341', 'سود و زیان جاری', 3, '31', 'equity', 'credit');
  PERFORM seed_account(v_company_id, '3411', 'سود و زیان جاری', 4, '341', 'equity', 'credit', TRUE);

  -- گروه ۴ درآمدها
  PERFORM seed_account(v_company_id, '4', 'درآمدها', 1, NULL, 'revenue', 'credit');
  PERFORM seed_account(v_company_id, '41', 'درآمد عملیاتی', 2, '4', 'revenue', 'credit');
  PERFORM seed_account(v_company_id, '411', 'فروش', 3, '41', 'revenue', 'credit');
  PERFORM seed_account(v_company_id, '4111', 'فروش کالا', 4, '411', 'revenue', 'credit', TRUE);
  PERFORM seed_account(v_company_id, '412', 'درآمد خدمات', 3, '41', 'revenue', 'credit');
  PERFORM seed_account(v_company_id, '4121', 'درآمد خدمات', 4, '412', 'revenue', 'credit', TRUE);
  PERFORM seed_account(v_company_id, '413', 'تخفیفات فروش', 3, '41', 'revenue', 'debit');
  PERFORM seed_account(v_company_id, '4131', 'تخفیفات فروش', 4, '413', 'revenue', 'debit', TRUE);
  PERFORM seed_account(v_company_id, '43', 'سایر درآمدها', 2, '4', 'revenue', 'credit');
  PERFORM seed_account(v_company_id, '431', 'درآمد حمل', 3, '43', 'revenue', 'credit');
  PERFORM seed_account(v_company_id, '4311', 'درآمد حمل', 4, '431', 'revenue', 'credit', TRUE);
  PERFORM seed_account(v_company_id, '439', 'سایر درآمدها', 3, '43', 'revenue', 'credit');
  PERFORM seed_account(v_company_id, '4391', 'سایر درآمدها', 4, '439', 'revenue', 'credit', TRUE);

  -- گروه ۵ بهای تمام‌شده
  PERFORM seed_account(v_company_id, '5', 'بهای تمام‌شده', 1, NULL, 'cogs', 'debit');
  PERFORM seed_account(v_company_id, '51', 'بهای کالای فروش‌رفته', 2, '5', 'cogs', 'debit');
  PERFORM seed_account(v_company_id, '511', 'بهای تمام‌شده کالای فروش‌رفته', 3, '51', 'cogs', 'debit');
  PERFORM seed_account(v_company_id, '5111', 'بهای تمام‌شده کالای فروش‌رفته', 4, '511', 'cogs', 'debit', TRUE);
  PERFORM seed_account(v_company_id, '512', 'بهای خدمات ارائه‌شده', 3, '51', 'cogs', 'debit');
  PERFORM seed_account(v_company_id, '521', 'تخفیفات خرید', 3, '51', 'cogs', 'credit');
  PERFORM seed_account(v_company_id, '5211', 'تخفیفات خرید', 4, '521', 'cogs', 'credit', TRUE);

  -- گروه ۶ هزینه‌ها
  PERFORM seed_account(v_company_id, '6', 'هزینه‌ها', 1, NULL, 'expense', 'debit');
  PERFORM seed_account(v_company_id, '61', 'هزینه‌های عملیاتی', 2, '6', 'expense', 'debit');
  PERFORM seed_account(v_company_id, '611', 'حقوق و دستمزد', 3, '61', 'expense', 'debit');
  PERFORM seed_account(v_company_id, '6111', 'حقوق و دستمزد', 4, '611', 'expense', 'debit', TRUE);
  PERFORM seed_account(v_company_id, '612', 'اجاره', 3, '61', 'expense', 'debit');
  PERFORM seed_account(v_company_id, '6121', 'اجاره', 4, '612', 'expense', 'debit', TRUE);
  PERFORM seed_account(v_company_id, '613', 'آب و برق و گاز', 3, '61', 'expense', 'debit');
  PERFORM seed_account(v_company_id, '6131', 'آب و برق و گاز', 4, '613', 'expense', 'debit', TRUE);
  PERFORM seed_account(v_company_id, '614', 'حمل', 3, '61', 'expense', 'debit');
  PERFORM seed_account(v_company_id, '6141', 'هزینه حمل', 4, '614', 'expense', 'debit', TRUE);
  PERFORM seed_account(v_company_id, '615', 'بازاریابی', 3, '61', 'expense', 'debit');
  PERFORM seed_account(v_company_id, '6151', 'بازاریابی', 4, '615', 'expense', 'debit', TRUE);
  PERFORM seed_account(v_company_id, '616', 'تبلیغات', 3, '61', 'expense', 'debit');
  PERFORM seed_account(v_company_id, '6161', 'تبلیغات', 4, '616', 'expense', 'debit', TRUE);
  PERFORM seed_account(v_company_id, '617', 'تعمیرات', 3, '61', 'expense', 'debit');
  PERFORM seed_account(v_company_id, '6171', 'تعمیرات', 4, '617', 'expense', 'debit', TRUE);
  PERFORM seed_account(v_company_id, '618', 'استهلاک', 3, '61', 'expense', 'debit');
  PERFORM seed_account(v_company_id, '6181', 'استهلاک', 4, '618', 'expense', 'debit', TRUE);
  PERFORM seed_account(v_company_id, '69', 'هزینه‌های مالی و سایر', 2, '6', 'expense', 'debit');
  PERFORM seed_account(v_company_id, '691', 'هزینه بانکی', 3, '69', 'expense', 'debit');
  PERFORM seed_account(v_company_id, '6911', 'کارمزد بانکی', 4, '691', 'expense', 'debit', TRUE);
  PERFORM seed_account(v_company_id, '692', 'هزینه مالی', 3, '69', 'expense', 'debit');
  PERFORM seed_account(v_company_id, '6921', 'هزینه مالی', 4, '692', 'expense', 'debit', TRUE);
  PERFORM seed_account(v_company_id, '699', 'سایر هزینه‌ها', 3, '69', 'expense', 'debit');
  PERFORM seed_account(v_company_id, '6991', 'سایر هزینه‌ها', 4, '699', 'expense', 'debit', TRUE);

  PERFORM seed_account(v_company_id, '8', 'حساب‌های انتظامی', 1, NULL, 'control', 'debit');
  PERFORM seed_account(v_company_id, '9', 'حساب‌های کنترلی', 1, NULL, 'control', 'debit');

  -- ۶. منابع مالی پیش‌فرض (لینک به حساب‌ها)
  INSERT INTO financial_sources (company_id, account_id, code, name_fa, source_type, bank_name, current_balance)
  SELECT v_company_id, a.id, a.code, a.name_fa,
    CASE
      WHEN a.code = '1111' THEN 'cash'
      WHEN a.code = '1131' THEN 'petty_cash'
      ELSE 'bank'
    END,
    CASE WHEN a.code LIKE '112%' OR a.code = '1130' THEN a.name_fa ELSE NULL END,
    0
  FROM accounts a
  WHERE a.company_id = v_company_id
    AND a.code IN ('1111','1121','1122','1123','1124','1125','1126','1127','1128','1129','1130','1131');

  RAISE NOTICE 'Seed completed. Company ID: %', v_company_id;
END $$;
