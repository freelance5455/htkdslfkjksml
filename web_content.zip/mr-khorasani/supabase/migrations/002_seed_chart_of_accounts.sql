-- ============================================================
-- Seed کدینگ کامل بر اساس PDF اسکرین‌شات‌ها
-- چهار سطح: گروه → کل → معین → تفصیلی
-- ۱۰ بانک ایرانی + صندوق + تنخواه
-- ============================================================

-- فرض: یک شرکت پیش‌فرض وجود دارد (در seed جداگانه ساخته می‌شود)
-- این اسکریپت بعد از ایجاد company و با company_id اجرا می‌شود.

-- تابع کمکی برای درج حساب
CREATE OR REPLACE FUNCTION seed_account(
  p_company_id UUID,
  p_code TEXT,
  p_name_fa TEXT,
  p_level INT,
  p_parent_code TEXT,
  p_account_type TEXT,
  p_nature TEXT DEFAULT 'debit',
  p_is_leaf BOOLEAN DEFAULT FALSE,
  p_is_floating BOOLEAN DEFAULT FALSE
) RETURNS UUID AS $$
DECLARE
  v_parent_id UUID;
  v_id UUID;
BEGIN
  IF p_parent_code IS NOT NULL THEN
    SELECT id INTO v_parent_id FROM accounts WHERE company_id = p_company_id AND code = p_parent_code;
  END IF;

  INSERT INTO accounts (
    company_id, code, name_fa, level, parent_id,
    account_type, nature, is_leaf, is_floating_detail
  ) VALUES (
    p_company_id, p_code, p_name_fa, p_level, v_parent_id,
    p_account_type, p_nature, p_is_leaf, p_is_floating
  )
  ON CONFLICT (company_id, code) DO UPDATE SET
    name_fa = EXCLUDED.name_fa,
    level = EXCLUDED.level,
    account_type = EXCLUDED.account_type,
    nature = EXCLUDED.nature,
    is_leaf = EXCLUDED.is_leaf,
    is_floating_detail = EXCLUDED.is_floating_detail
  RETURNING id INTO v_id;

  RETURN v_id;
END;
$$ LANGUAGE plpgsql;

-- ============================================================
-- گروه ۱ — دارایی‌ها
-- ============================================================
-- سطح ۱
SELECT seed_account(NULL, '1', 'دارایی‌ها', 1, NULL, 'asset', 'debit');

-- سطح ۲
SELECT seed_account(NULL, '11', 'موجودی نقد و بانک', 2, '1', 'asset', 'debit');
SELECT seed_account(NULL, '12', 'حساب‌ها و اسناد دریافتنی', 2, '1', 'asset', 'debit');
SELECT seed_account(NULL, '13', 'موجودی کالا', 2, '1', 'asset', 'debit');
SELECT seed_account(NULL, '14', 'پیش‌پرداخت‌ها و سپرده‌ها', 2, '1', 'asset', 'debit');
SELECT seed_account(NULL, '15', 'دارایی‌های ثابت', 2, '1', 'asset', 'debit');

-- سطح ۳ و ۴ — نقد و بانک
SELECT seed_account(NULL, '111', 'صندوق', 3, '11', 'asset', 'debit');
SELECT seed_account(NULL, '1111', 'وجه نقد صندوق', 4, '111', 'asset', 'debit', TRUE);

SELECT seed_account(NULL, '112', 'بانک‌ها', 3, '11', 'asset', 'debit');
SELECT seed_account(NULL, '1121', 'بانک ملی ایران', 4, '112', 'asset', 'debit', TRUE);
SELECT seed_account(NULL, '1122', 'بانک ملت', 4, '112', 'asset', 'debit', TRUE);
SELECT seed_account(NULL, '1123', 'بانک صادرات ایران', 4, '112', 'asset', 'debit', TRUE);
SELECT seed_account(NULL, '1124', 'بانک تجارت', 4, '112', 'asset', 'debit', TRUE);
SELECT seed_account(NULL, '1125', 'بانک سپه', 4, '112', 'asset', 'debit', TRUE);
SELECT seed_account(NULL, '1126', 'بانک رفاه کارگران', 4, '112', 'asset', 'debit', TRUE);
SELECT seed_account(NULL, '1127', 'بانک کشاورزی', 4, '112', 'asset', 'debit', TRUE);
SELECT seed_account(NULL, '1128', 'بانک مسکن', 4, '112', 'asset', 'debit', TRUE);
SELECT seed_account(NULL, '1129', 'بانک پارسیان', 4, '112', 'asset', 'debit', TRUE);

SELECT seed_account(NULL, '113', 'تنخواه', 3, '11', 'asset', 'debit');
SELECT seed_account(NULL, '1130', 'بانک سامان', 4, '113', 'asset', 'debit', TRUE); -- طبق PDF
SELECT seed_account(NULL, '1131', 'تنخواه گردان', 4, '113', 'asset', 'debit', TRUE);

-- حساب‌ها و اسناد دریافتنی
SELECT seed_account(NULL, '121', 'حساب‌های دریافتنی', 3, '12', 'asset', 'debit');
SELECT seed_account(NULL, '1211', 'مشتریان', 4, '121', 'asset', 'debit', TRUE, TRUE); -- floating

SELECT seed_account(NULL, '122', 'اسناد دریافتنی', 3, '12', 'asset', 'debit');
SELECT seed_account(NULL, '1221', 'چک‌های دریافتنی', 4, '122', 'asset', 'debit', TRUE);

-- موجودی کالا
SELECT seed_account(NULL, '131', 'موجودی کالا', 3, '13', 'asset', 'debit');
SELECT seed_account(NULL, '1311', 'موجودی کالا', 4, '131', 'asset', 'debit', TRUE);

-- پیش‌پرداخت و سپرده
SELECT seed_account(NULL, '141', 'پیش‌پرداخت‌ها', 3, '14', 'asset', 'debit');
SELECT seed_account(NULL, '1411', 'پیش‌پرداخت تأمین‌کنندگان', 4, '141', 'asset', 'debit', TRUE, TRUE);

SELECT seed_account(NULL, '142', 'سپرده‌ها', 3, '14', 'asset', 'debit');

-- دارایی ثابت
SELECT seed_account(NULL, '151', 'دارایی ثابت', 3, '15', 'asset', 'debit');
SELECT seed_account(NULL, '1511', 'اثاثه و تجهیزات', 4, '151', 'asset', 'debit', TRUE);

SELECT seed_account(NULL, '152', 'استهلاک انباشته', 3, '15', 'contra', 'credit');
SELECT seed_account(NULL, '1521', 'استهلاک انباشته دارایی ثابت', 4, '152', 'contra', 'credit', TRUE);

-- ============================================================
-- گروه ۲ — بدهی‌ها
-- ============================================================
SELECT seed_account(NULL, '2', 'بدهی‌ها', 1, NULL, 'liability', 'credit');

SELECT seed_account(NULL, '21', 'حساب‌ها و اسناد پرداختنی', 2, '2', 'liability', 'credit');
SELECT seed_account(NULL, '211', 'حساب‌های پرداختنی', 3, '21', 'liability', 'credit');
SELECT seed_account(NULL, '2111', 'تأمین‌کنندگان', 4, '211', 'liability', 'credit', TRUE, TRUE);

SELECT seed_account(NULL, '212', 'اسناد پرداختنی', 3, '21', 'liability', 'credit');
SELECT seed_account(NULL, '2121', 'چک‌های پرداختنی', 4, '212', 'liability', 'credit', TRUE);

SELECT seed_account(NULL, '22', 'مالیات، بیمه و حقوق', 2, '2', 'liability', 'credit');
SELECT seed_account(NULL, '221', 'مالیات پرداختنی', 3, '22', 'liability', 'credit');
SELECT seed_account(NULL, '2211', 'مالیات بر ارزش افزوده پرداختنی', 4, '221', 'liability', 'credit', TRUE);

SELECT seed_account(NULL, '222', 'بیمه پرداختنی', 3, '22', 'liability', 'credit');
SELECT seed_account(NULL, '2221', 'بیمه تأمین اجتماعی پرداختنی', 4, '222', 'liability', 'credit', TRUE);

SELECT seed_account(NULL, '223', 'حقوق پرداختنی', 3, '22', 'liability', 'credit');
SELECT seed_account(NULL, '2231', 'حقوق پرداختنی کارکنان', 4, '223', 'liability', 'credit', TRUE);

SELECT seed_account(NULL, '23', 'پیش‌دریافت‌ها و سایر بدهی‌ها', 2, '2', 'liability', 'credit');
SELECT seed_account(NULL, '231', 'پیش‌دریافت‌ها', 3, '23', 'liability', 'credit');
SELECT seed_account(NULL, '2311', 'پیش‌دریافت از مشتریان', 4, '231', 'liability', 'credit', TRUE, TRUE);

SELECT seed_account(NULL, '239', 'سایر بدهی‌ها', 3, '23', 'liability', 'credit');

-- ============================================================
-- گروه ۳ — سرمایه
-- ============================================================
SELECT seed_account(NULL, '3', 'سرمایه', 1, NULL, 'equity', 'credit');

SELECT seed_account(NULL, '31', 'حقوق صاحبان سرمایه', 2, '3', 'equity', 'credit');
SELECT seed_account(NULL, '311', 'سرمایه', 3, '31', 'equity', 'credit');
SELECT seed_account(NULL, '3111', 'سرمایه اولیه', 4, '311', 'equity', 'credit', TRUE);

SELECT seed_account(NULL, '321', 'برداشت', 3, '31', 'equity', 'debit'); -- خلاف طبیعت سرمایه
SELECT seed_account(NULL, '3211', 'برداشت شرکا', 4, '321', 'equity', 'debit', TRUE);

SELECT seed_account(NULL, '331', 'سود و زیان انباشته', 3, '31', 'equity', 'credit');
SELECT seed_account(NULL, '3311', 'سود و زیان انباشته', 4, '331', 'equity', 'credit', TRUE);

SELECT seed_account(NULL, '341', 'سود و زیان جاری', 3, '31', 'equity', 'credit');
SELECT seed_account(NULL, '3411', 'سود و زیان جاری', 4, '341', 'equity', 'credit', TRUE);

-- ============================================================
-- گروه ۴ — درآمدها
-- ============================================================
SELECT seed_account(NULL, '4', 'درآمدها', 1, NULL, 'revenue', 'credit');

SELECT seed_account(NULL, '41', 'درآمد عملیاتی', 2, '4', 'revenue', 'credit');
SELECT seed_account(NULL, '411', 'فروش', 3, '41', 'revenue', 'credit');
SELECT seed_account(NULL, '4111', 'فروش کالا', 4, '411', 'revenue', 'credit', TRUE);

SELECT seed_account(NULL, '412', 'درآمد خدمات', 3, '41', 'revenue', 'credit');
SELECT seed_account(NULL, '4121', 'درآمد خدمات', 4, '412', 'revenue', 'credit', TRUE);

SELECT seed_account(NULL, '413', 'تخفیفات فروش', 3, '41', 'revenue', 'debit'); -- کاهنده
SELECT seed_account(NULL, '4131', 'تخفیفات فروش', 4, '413', 'revenue', 'debit', TRUE);

SELECT seed_account(NULL, '43', 'سایر درآمدها', 2, '4', 'revenue', 'credit');
SELECT seed_account(NULL, '431', 'درآمد حمل', 3, '43', 'revenue', 'credit');
SELECT seed_account(NULL, '4311', 'درآمد حمل', 4, '431', 'revenue', 'credit', TRUE);

SELECT seed_account(NULL, '439', 'سایر درآمدها', 3, '43', 'revenue', 'credit');
SELECT seed_account(NULL, '4391', 'سایر درآمدها', 4, '439', 'revenue', 'credit', TRUE);

-- ============================================================
-- گروه ۵ — بهای تمام‌شده
-- ============================================================
SELECT seed_account(NULL, '5', 'بهای تمام‌شده', 1, NULL, 'cogs', 'debit');

SELECT seed_account(NULL, '51', 'بهای کالای فروش‌رفته', 2, '5', 'cogs', 'debit');
SELECT seed_account(NULL, '511', 'بهای تمام‌شده کالای فروش‌رفته', 3, '51', 'cogs', 'debit');
SELECT seed_account(NULL, '5111', 'بهای تمام‌شده کالای فروش‌رفته', 4, '511', 'cogs', 'debit', TRUE);

SELECT seed_account(NULL, '512', 'بهای خدمات ارائه‌شده', 3, '51', 'cogs', 'debit');

SELECT seed_account(NULL, '521', 'تخفیفات خرید', 3, '51', 'cogs', 'credit'); -- کاهنده بهای تمام‌شده
SELECT seed_account(NULL, '5211', 'تخفیفات خرید', 4, '521', 'cogs', 'credit', TRUE);

-- ============================================================
-- گروه ۶ — هزینه‌ها
-- ============================================================
SELECT seed_account(NULL, '6', 'هزینه‌ها', 1, NULL, 'expense', 'debit');

SELECT seed_account(NULL, '61', 'هزینه‌های عملیاتی', 2, '6', 'expense', 'debit');

SELECT seed_account(NULL, '611', 'حقوق و دستمزد', 3, '61', 'expense', 'debit');
SELECT seed_account(NULL, '6111', 'حقوق و دستمزد', 4, '611', 'expense', 'debit', TRUE);

SELECT seed_account(NULL, '612', 'اجاره', 3, '61', 'expense', 'debit');
SELECT seed_account(NULL, '6121', 'اجاره', 4, '612', 'expense', 'debit', TRUE);

SELECT seed_account(NULL, '613', 'آب و برق و گاز', 3, '61', 'expense', 'debit');
SELECT seed_account(NULL, '6131', 'آب و برق و گاز', 4, '613', 'expense', 'debit', TRUE);

SELECT seed_account(NULL, '614', 'حمل', 3, '61', 'expense', 'debit');
SELECT seed_account(NULL, '6141', 'هزینه حمل', 4, '614', 'expense', 'debit', TRUE);

SELECT seed_account(NULL, '615', 'بازاریابی', 3, '61', 'expense', 'debit');
SELECT seed_account(NULL, '6151', 'بازاریابی', 4, '615', 'expense', 'debit', TRUE);

SELECT seed_account(NULL, '616', 'تبلیغات', 3, '61', 'expense', 'debit');
SELECT seed_account(NULL, '6161', 'تبلیغات', 4, '616', 'expense', 'debit', TRUE);

SELECT seed_account(NULL, '617', 'تعمیرات', 3, '61', 'expense', 'debit');
SELECT seed_account(NULL, '6171', 'تعمیرات', 4, '617', 'expense', 'debit', TRUE);

SELECT seed_account(NULL, '618', 'استهلاک', 3, '61', 'expense', 'debit');
SELECT seed_account(NULL, '6181', 'استهلاک', 4, '618', 'expense', 'debit', TRUE);

SELECT seed_account(NULL, '69', 'هزینه‌های مالی و سایر', 2, '6', 'expense', 'debit');
SELECT seed_account(NULL, '691', 'هزینه بانکی', 3, '69', 'expense', 'debit');
SELECT seed_account(NULL, '6911', 'کارمزد بانکی', 4, '691', 'expense', 'debit', TRUE);

SELECT seed_account(NULL, '692', 'هزینه مالی', 3, '69', 'expense', 'debit');
SELECT seed_account(NULL, '6921', 'هزینه مالی', 4, '692', 'expense', 'debit', TRUE);

SELECT seed_account(NULL, '699', 'سایر هزینه‌ها', 3, '69', 'expense', 'debit');
SELECT seed_account(NULL, '6991', 'سایر هزینه‌ها', 4, '699', 'expense', 'debit', TRUE);

-- ============================================================
-- گروه ۸ و ۹ — انتظامی و کنترلی (طبق PDF)
-- ============================================================
SELECT seed_account(NULL, '8', 'حساب‌های انتظامی', 1, NULL, 'control', 'debit');
SELECT seed_account(NULL, '9', 'حساب‌های کنترلی', 1, NULL, 'control', 'debit');

-- پاک‌سازی تابع موقت
-- DROP FUNCTION IF EXISTS seed_account;
