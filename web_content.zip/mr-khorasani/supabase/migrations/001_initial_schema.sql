-- ============================================================
-- MR,KHORASANI — Schema اولیه (فاز ۱)
-- Double-Entry Accounting + Soft Delete + Day Close Lock
-- کدینگ ۴سطحی پویا بر اساس PDF
-- ============================================================

-- Extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================================
-- 1. شرکت‌ها (Multi-tenant)
-- ============================================================
CREATE TABLE companies (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  name_en TEXT DEFAULT 'MR,KHORASANI',
  fiscal_year_start DATE NOT NULL DEFAULT '2026-03-21', -- 1405/01/01
  fiscal_year_end DATE NOT NULL DEFAULT '2027-03-20',
  current_fiscal_year INT NOT NULL DEFAULT 1405,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- 2. کاربران و نقش‌ها
-- ============================================================
CREATE TABLE roles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  code TEXT NOT NULL UNIQUE, -- admin, financial_manager, accountant, cashier, sales, viewer
  name_fa TEXT NOT NULL,
  name_en TEXT,
  permissions JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  auth_user_id UUID, -- Supabase Auth
  username TEXT NOT NULL,
  mobile TEXT,
  full_name TEXT NOT NULL,
  role_id UUID NOT NULL REFERENCES roles(id),
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  last_login_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(company_id, username)
);

-- ============================================================
-- 3. سال مالی
-- ============================================================
CREATE TABLE fiscal_years (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  year INT NOT NULL, -- 1405
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  is_current BOOLEAN NOT NULL DEFAULT FALSE,
  is_closed BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(company_id, year)
);

-- ============================================================
-- 4. کدینگ حساب‌ها (۴ سطح پویا)
-- سطح 1: گروه | 2: کل | 3: معین | 4: تفصیلی
-- ============================================================
CREATE TABLE accounts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  code TEXT NOT NULL,                  -- 1, 11, 111, 1111, 1121 ...
  name_fa TEXT NOT NULL,
  name_en TEXT,
  level INT NOT NULL CHECK (level BETWEEN 1 AND 4),
  parent_id UUID REFERENCES accounts(id),
  account_type TEXT NOT NULL,          -- asset, liability, equity, revenue, cogs, expense, contra, control
  nature TEXT NOT NULL DEFAULT 'debit', -- debit / credit
  is_leaf BOOLEAN NOT NULL DEFAULT FALSE, -- آیا قابل انتخاب در سند است
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  is_floating_detail BOOLEAN NOT NULL DEFAULT FALSE, -- تفصیلی شناور (اشخاص)
  allow_manual_entry BOOLEAN NOT NULL DEFAULT TRUE,
  description TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(company_id, code)
);

CREATE INDEX idx_accounts_parent ON accounts(parent_id);
CREATE INDEX idx_accounts_code ON accounts(company_id, code);
CREATE INDEX idx_accounts_level ON accounts(company_id, level);

-- ============================================================
-- 5. منابع مالی (صندوق + بانک‌ها)
-- ============================================================
CREATE TABLE financial_sources (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  account_id UUID NOT NULL REFERENCES accounts(id), -- لینک به کدینگ
  code TEXT NOT NULL,
  name_fa TEXT NOT NULL,
  source_type TEXT NOT NULL CHECK (source_type IN ('cash', 'bank', 'petty_cash', 'pos')),
  bank_name TEXT,           -- فقط برای بانک
  branch_name TEXT,
  account_number TEXT,
  sheba TEXT,
  card_number TEXT,
  opening_balance NUMERIC(18,0) NOT NULL DEFAULT 0,
  current_balance NUMERIC(18,0) NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  opened_at DATE,
  description TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(company_id, code)
);

-- ============================================================
-- 6. اشخاص (Master Data مرکزی)
-- ============================================================
CREATE TABLE parties (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  code TEXT NOT NULL,
  name TEXT NOT NULL,
  trade_name TEXT,
  party_type TEXT[] NOT NULL DEFAULT '{}', -- customer, supplier, employee, partner, other, bank, government
  mobile TEXT,
  phone TEXT,
  address TEXT,
  national_id TEXT,
  economic_code TEXT,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  opening_balance NUMERIC(18,0) NOT NULL DEFAULT 0,
  current_balance NUMERIC(18,0) NOT NULL DEFAULT 0,
  description TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted_at TIMESTAMPTZ, -- Soft Delete
  UNIQUE(company_id, code)
);

CREATE INDEX idx_parties_name ON parties(company_id, name);
CREATE INDEX idx_parties_mobile ON parties(company_id, mobile);
CREATE INDEX idx_parties_type ON parties USING GIN (party_type);

-- ============================================================
-- 7. کالاها (Master Data)
-- ============================================================
CREATE TABLE products (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  code TEXT NOT NULL,
  name TEXT NOT NULL,
  barcode TEXT,
  unit TEXT NOT NULL DEFAULT 'عدد',
  category TEXT,
  subcategory TEXT,
  purchase_price NUMERIC(18,0) DEFAULT 0,
  sale_price NUMERIC(18,0) DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  description TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted_at TIMESTAMPTZ,
  UNIQUE(company_id, code)
);

CREATE INDEX idx_products_name ON products(company_id, name);
CREATE INDEX idx_products_barcode ON products(company_id, barcode);

-- ============================================================
-- 8. روزهای مالی (برای بستن روز)
-- ============================================================
CREATE TABLE financial_days (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  fiscal_year_id UUID NOT NULL REFERENCES fiscal_years(id),
  day_date DATE NOT NULL, -- میلادی canonical
  day_jalali TEXT NOT NULL, -- ۱۴۰۵/۰۶/۳۱
  status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'closed', 'reopened')),
  closed_by UUID REFERENCES users(id),
  closed_at TIMESTAMPTZ,
  reopened_by UUID REFERENCES users(id),
  reopened_at TIMESTAMPTZ,
  reopen_reason TEXT,
  backup_path TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(company_id, day_date)
);

CREATE INDEX idx_financial_days_status ON financial_days(company_id, status);

-- ============================================================
-- 9. عملیات روزانه (Operational Transaction)
-- ============================================================
CREATE TABLE operations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  fiscal_year_id UUID NOT NULL REFERENCES fiscal_years(id),
  financial_day_id UUID REFERENCES financial_days(id),
  operation_number TEXT NOT NULL, -- OP-1405-000001
  operation_type TEXT NOT NULL, -- receipt, payment, transfer, sale, purchase, expense, income, check_*, adjustment, manual
  operation_date DATE NOT NULL,
  operation_date_jalali TEXT NOT NULL,
  party_id UUID REFERENCES parties(id),
  financial_source_id UUID REFERENCES financial_sources(id),
  amount NUMERIC(18,0) NOT NULL CHECK (amount >= 0),
  description TEXT,
  reference_number TEXT, -- شماره فاکتور / چک / ...
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'posted', 'deleted', 'reversed')),
  is_locked BOOLEAN NOT NULL DEFAULT FALSE, -- پس از بستن روز
  created_by UUID NOT NULL REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted_at TIMESTAMPTZ,
  deleted_by UUID REFERENCES users(id),
  delete_reason TEXT,
  version INT NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'pending' CHECK (sync_status IN ('pending', 'synced', 'conflict')),
  UNIQUE(company_id, operation_number)
);

CREATE INDEX idx_operations_date ON operations(company_id, operation_date);
CREATE INDEX idx_operations_type ON operations(company_id, operation_type);
CREATE INDEX idx_operations_status ON operations(company_id, status);
CREATE INDEX idx_operations_party ON operations(party_id);

-- ============================================================
-- 10. اقلام عملیات (برای فاکتور خرید/فروش)
-- ============================================================
CREATE TABLE operation_lines (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  operation_id UUID NOT NULL REFERENCES operations(id) ON DELETE CASCADE,
  product_id UUID REFERENCES products(id),
  description TEXT,
  quantity NUMERIC(18,3) NOT NULL DEFAULT 1,
  unit_price NUMERIC(18,0) NOT NULL DEFAULT 0,
  line_amount NUMERIC(18,0) NOT NULL DEFAULT 0, -- quantity * unit_price
  discount_mode TEXT CHECK (discount_mode IN ('percent', 'amount')),
  discount_percent NUMERIC(8,4) DEFAULT 0,
  discount_amount NUMERIC(18,0) DEFAULT 0,
  shipping_cost NUMERIC(18,0) DEFAULT 0,
  line_total NUMERIC(18,0) NOT NULL DEFAULT 0, -- line_amount - discount + shipping
  sort_order INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- 11. اسناد حسابداری (Journal Header)
-- ============================================================
CREATE TABLE journal_entries (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  fiscal_year_id UUID NOT NULL REFERENCES fiscal_years(id),
  financial_day_id UUID REFERENCES financial_days(id),
  journal_number TEXT NOT NULL, -- JV-1405-000001
  journal_date DATE NOT NULL,
  journal_date_jalali TEXT NOT NULL,
  description TEXT NOT NULL,
  operation_id UUID REFERENCES operations(id), -- لینک به عملیات مبدأ
  journal_type TEXT NOT NULL DEFAULT 'auto' CHECK (journal_type IN ('auto', 'manual', 'adjustment', 'reversal', 'opening', 'closing')),
  original_journal_id UUID REFERENCES journal_entries(id), -- برای اصلاحی/برگشت
  total_debit NUMERIC(18,0) NOT NULL DEFAULT 0,
  total_credit NUMERIC(18,0) NOT NULL DEFAULT 0,
  is_balanced BOOLEAN GENERATED ALWAYS AS (total_debit = total_credit) STORED,
  status TEXT NOT NULL DEFAULT 'posted' CHECK (status IN ('draft', 'posted', 'deleted', 'reversed')),
  is_locked BOOLEAN NOT NULL DEFAULT FALSE,
  created_by UUID NOT NULL REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted_at TIMESTAMPTZ,
  version INT NOT NULL DEFAULT 1,
  UNIQUE(company_id, journal_number)
);

CREATE INDEX idx_journals_date ON journal_entries(company_id, journal_date);
CREATE INDEX idx_journals_operation ON journal_entries(operation_id);

-- ============================================================
-- 12. ردیف‌های سند (Journal Lines) — Double Entry
-- ============================================================
CREATE TABLE journal_lines (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  journal_id UUID NOT NULL REFERENCES journal_entries(id) ON DELETE CASCADE,
  account_id UUID NOT NULL REFERENCES accounts(id),
  party_id UUID REFERENCES parties(id), -- تفصیلی شناور
  financial_source_id UUID REFERENCES financial_sources(id),
  debit NUMERIC(18,0) NOT NULL DEFAULT 0 CHECK (debit >= 0),
  credit NUMERIC(18,0) NOT NULL DEFAULT 0 CHECK (credit >= 0),
  description TEXT,
  cost_center TEXT,
  project TEXT,
  sort_order INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT chk_debit_or_credit CHECK (
    (debit > 0 AND credit = 0) OR (credit > 0 AND debit = 0) OR (debit = 0 AND credit = 0)
  )
);

CREATE INDEX idx_journal_lines_account ON journal_lines(account_id);
CREATE INDEX idx_journal_lines_party ON journal_lines(party_id);
CREATE INDEX idx_journal_lines_journal ON journal_lines(journal_id);

-- ============================================================
-- 13. Audit Log
-- ============================================================
CREATE TABLE audit_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  user_id UUID REFERENCES users(id),
  username TEXT,
  action TEXT NOT NULL, -- create, edit, delete, close_day, login, export, ...
  entity TEXT NOT NULL, -- operation, journal, party, account, ...
  entity_id UUID,
  old_value JSONB,
  new_value JSONB,
  reason TEXT,
  device_id TEXT,
  ip_address TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_audit_entity ON audit_logs(company_id, entity, entity_id);
CREATE INDEX idx_audit_user ON audit_logs(user_id);
CREATE INDEX idx_audit_created ON audit_logs(created_at);

-- ============================================================
-- 14. تنظیمات سیستم
-- ============================================================
CREATE TABLE settings (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  key TEXT NOT NULL,
  value JSONB NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(company_id, key)
);

-- ============================================================
-- 15. صف همگام‌سازی (Offline First)
-- ============================================================
CREATE TABLE sync_queue (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  entity_type TEXT NOT NULL,
  entity_id UUID NOT NULL,
  action TEXT NOT NULL, -- insert, update, delete
  payload JSONB NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'synced', 'failed')),
  attempts INT NOT NULL DEFAULT 0,
  last_error TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  synced_at TIMESTAMPTZ
);

-- ============================================================
-- توابع کمکی مهم
-- ============================================================

-- کنترل توازن سند
CREATE OR REPLACE FUNCTION check_journal_balance()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.total_debit != NEW.total_credit THEN
    RAISE EXCEPTION 'سند نامتوازن است: بدهکار % ≠ بستانکار %', NEW.total_debit, NEW.total_credit;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_journal_balance
  BEFORE INSERT OR UPDATE ON journal_entries
  FOR EACH ROW
  WHEN (NEW.status = 'posted')
  EXECUTE FUNCTION check_journal_balance();

-- جلوگیری از ویرایش سند قفل‌شده
CREATE OR REPLACE FUNCTION prevent_locked_edit()
RETURNS TRIGGER AS $$
BEGIN
  IF OLD.is_locked = TRUE AND NEW.is_locked = TRUE THEN
    RAISE EXCEPTION 'روز بسته شده است. امکان ویرایش مستقیم وجود ندارد. از سند اصلاحی استفاده کنید.';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_prevent_locked_journal
  BEFORE UPDATE ON journal_entries
  FOR EACH ROW
  EXECUTE FUNCTION prevent_locked_edit();

CREATE TRIGGER trg_prevent_locked_operation
  BEFORE UPDATE ON operations
  FOR EACH ROW
  EXECUTE FUNCTION prevent_locked_edit();

COMMENT ON TABLE accounts IS 'کدینگ ۴سطحی پویا — گروه/کل/معین/تفصیلی';
COMMENT ON TABLE operations IS 'عملیات روزانه — قبل از بستن روز قابل ویرایش و Soft Delete';
COMMENT ON TABLE journal_entries IS 'اسناد حسابداری دوبل — پس از بستن روز فقط با Adjustment قابل تغییر';
COMMENT ON COLUMN accounts.is_floating_detail IS 'تفصیلی شناور برای اشخاص (مشتری، تأمین‌کننده و ...)';
