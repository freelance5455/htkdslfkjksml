window.NativeBridge={
 isNative:!!window.hpNative,
 async saveFile(name,blob){
  if(window.hpNative?.saveFile)return window.hpNative.saveFile(name,blob);
  const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=name;a.click();
  setTimeout(()=>URL.revokeObjectURL(a.href),1000);
 },
 async bluetooth(){
  if(window.hpNative?.bluetooth)return window.hpNative.bluetooth();
  if(navigator.bluetooth)return {available:true,mode:"web/native Bluetooth capability"};
  return {available:false};
 }
};