/* Couche "vraie app" : alarmes natives si le convertisseur les fournit (Capacitor), sinon repli web. */
const NL=()=>window.Capacitor?.Plugins?.LocalNotifications;
const hash=s=>{let h=7;for(const c of s)h=(h*31+c.charCodeAt(0))%200000000;return h};
const _save=save;save=function(){_save();scheduleAll()};
async function scheduleAll(){const L=NL();if(!L)return webSched();
try{const p=await L.getPending();if(p.notifications.length)await L.cancel({notifications:p.notifications});
const now=Date.now(),list=[];
for(const t of D.tasks){if(!active(t)||!t.time)continue;const base=sdt(t)-t.remind*6e4;
for(let k=0;k<(t.persist?7:1);k++){const at=base+k*NAG*6e4;if(at>now+1500)list.push({at,n:{id:hash(t.id)*10+k,title:'🔔 '+t.title,body:k?'Toujours pas fait : réponds Fait ou Reporter':'C’est le moment · '+t.time,schedule:{at:new Date(at),allowWhileIdle:true},channelId:'alarms',actionTypeId:'TASK',extra:{id:t.id}}})}}
list.sort((a,b)=>a.at-b.at);if(list.length)await L.schedule({notifications:list.slice(0,60).map(x=>x.n)})}catch(e){}}
async function webSched(){try{if(!('Notification'in window)||Notification.permission!=='granted'||!('showTrigger'in Notification.prototype))return;
const r=await navigator.serviceWorker.getRegistration();if(!r)return;(await r.getNotifications({includeTriggered:false})).forEach(n=>n.close());
for(const t of D.tasks){if(!active(t)||!t.time)continue;const at=+sdt(t)-t.remind*6e4;if(at>Date.now())r.showNotification('🔔 '+t.title,{body:'C’est le moment · '+t.time,tag:t.id,vibrate:[300,150,300],requireInteraction:true,showTrigger:new TimestampTrigger(at)})}}catch(e){}}
async function nativeInit(){const L=NL();if(!L)return;
try{await L.requestPermissions();await L.createChannel({id:'alarms',name:'Alarmes Mon Temps',importance:5,vibration:true,visibility:1});
await L.registerActionTypes({types:[{id:'TASK',actions:[{id:'done',title:'✓ Fait'},{id:'snooze',title:'+10 min'}]}]});
L.addListener('localNotificationActionPerformed',e=>{const id=e.notification.extra?.id;if(!T(id)){check();return}if(e.actionId==='done')done(id);else if(e.actionId==='snooze')snooze(id,10);else check()})}catch(x){}scheduleAll()}
document.addEventListener('deviceready',nativeInit);window.addEventListener('load',()=>setTimeout(nativeInit,600));
/* Reporter / avancer */
function advance(id){closeA();act(()=>{const t=T(id),m=Math.ceil((nowM()+1)/5)*5;t.date=dk();t.time=hm(m);t.al=0},'Avancé : commence maintenant')}
function pickSnooze(id){closeA();const d=new Date(Date.now()+36e5);openM(`<h2>Reporter à…</h2><label>Date</label><input id="sd" type="date" value="${dk(d)}"><label>Heure</label><input id="sh2" type="time" value="${hm(d.getHours()*60+d.getMinutes())}"><div class="ac"><button class="b p" onclick="applySn('${id}')">Reporter</button>${[5,15,60].map(m=>`<button class="b" onclick="closeM();snooze('${id}',${m})">+${m<60?m+' min':'1 h'}</button>`).join('')}<button class="b" onclick="closeM();tomorrow('${id}')">Demain</button></div>`)}
function applySn(id){const d=$('sd').value,h=$('sh2').value;if(!d||!h)return;closeM();act(()=>{const t=T(id);t.date=d;t.time=h;t.al=0},'Reporté')}
function tomorrow(id){act(()=>{const t=T(id);t.date=addD(dk(),1);t.al=0},'Reporté à demain')}
/* Musique perso (jouée en boucle quand l'alerte s'affiche, app ouverte) */
const idb=(m,v)=>new Promise(r=>{const q=indexedDB.open('mt',1);q.onupgradeneeded=()=>q.result.createObjectStore('s');q.onerror=()=>r(null);q.onsuccess=()=>{const s=q.result.transaction('s',m==='get'?'readonly':'readwrite').objectStore('s'),x=m==='get'?s.get('snd'):s.put(v,'snd');x.onsuccess=()=>r(x.result);x.onerror=()=>r(null)}});
let song=null,pl=null;idb('get').then(b=>{if(b)song=URL.createObjectURL(b)});
const _beep=beep;beep=function(){if(!D.snd)return;if(song){try{pl=pl||new Audio(song);pl.loop=true;pl.currentTime=0;pl.play().catch(_beep);return}catch(e){}}_beep()};
const _closeA=closeA;closeA=function(){if(pl){pl.pause()}_closeA()};
async function setSong(i){const f=i.files[0];if(!f)return;await idb('put',f);song=URL.createObjectURL(f);pl=null;toast('Musique enregistrée')}
const _vSet=vSet;vSet=function(){_vSet();$('p-set').insertAdjacentHTML('beforeend',`<div class="c"><b>Ma musique d’alerte</b><input type="file" accept="audio/*" onchange="setSong(this)"><div class="ac"><button class="b" onclick="idb('put',null);song=null;pl=null;toast('Son par défaut')">Revenir au bip</button></div><p class="sm">Jouée en boucle jusqu’à ta réponse quand l’app est ouverte. App fermée, c’est la sonnerie de notification d’Android qui sonne.</p></div>`)};
