# CHATONE! — versi tampilan akun dan intro

## Menjalankan
1. Ekstrak ZIP.
2. Buka `index.html` atau unggah seluruh isi folder ke hosting statis.
3. Pastikan folder `assets` tetap berada di samping `index.html`.

## Pembaruan
- Tampilan awal Masuk / Daftar dengan gambar banner yang dikirim.
- Daftar akun dan login demo (password disimpan sebagai hash SHA-256 di browser lokal).
- Animasi video pembuka dengan tombol Skip.
- Lencana centang biru pada akun bernama `onezal` dan kontak resmi onezal.
- Menu titik tiga dapat dibuka dari halaman utama dan ruang chat.
- Foto galeri dapat dipakai sebagai latar belakang chat.

## Batasan penting
Ini masih prototype front-end. Akun hanya tersimpan di browser/perangkat yang dipakai untuk mendaftar; belum bisa login di HP lain. Daftar kontak, pesan, grup global, story lintas pengguna, dan centang biru resmi belum disinkronkan antar pengguna.

Untuk versi publik sungguhan, sambungkan Firebase Authentication, Cloud Firestore, dan Cloud Storage. Buat akun admin `onezal` melalui Firebase Authentication, lalu atur status verified dari data server yang hanya admin boleh ubah. Username `onezal` dicadangkan pada demo agar pengguna lain tidak bisa membuat akun palsu dengan nama tersebut. Jangan menaruh password admin di HTML/JavaScript publik atau mengirimkannya ke orang lain. Password yang pernah diketik di chat sebaiknya diganti dan jangan digunakan ulang.


## Pembaruan navigasi dan pencarian
- Tombol Kembali memakai riwayat halaman sehingga kembali ke halaman sebelumnya.
- Kolom Cari username memfilter nama akun yang terdaftar pada browser/perangkat yang sama.
- Akun yang ditemukan dapat diketuk untuk membuka ruang chat langsung.
- Daftar status demo dapat menampilkan status yang dibuat pada browser yang sama.

## Batasan sinkronisasi
Pencarian pengguna lintas HP, chat sungguhan antar orang, serta story yang otomatis terlihat oleh semua pengguna tidak dapat berjalan hanya dengan HTML/JavaScript lokal. Fitur tersebut membutuhkan backend online (Firebase Authentication, Firestore, dan Storage), konfigurasi proyek, serta aturan akses. Versi ZIP ini belum mengklaim sinkronisasi lintas perangkat.
