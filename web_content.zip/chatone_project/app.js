const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const defaultAvatar='assets/default-avatar.jpg';
const contacts=[
 {id:'global',name:'global chat',type:'grup',last:'Selamat datang di Global Chat!',time:'07.00',unread:false,avatar:defaultAvatar},
 {id:'onezal',name:'onezal',type:'person',last:'Akun resmi CHATONE!',time:'Admin',unread:false,avatar:defaultAvatar,verified:true},
 {id:'teman1',name:'@teman_chat',type:'person',last:'Sampai nanti ya',time:'Senin',unread:false,avatar:defaultAvatar}
];
let currentRoom='global', filter='all', history={}, stories=[];
const number=String(Math.floor(1000000000+Math.random()*9000000000));
$('#userNumber').textContent=number;
const savedName=localStorage.getItem('chatone_name')||'Pengguna CHATONE!';
$('#profileName').textContent=savedName;
$('#profileUsername').textContent='@'+(localStorage.getItem('chatone_user')||'onezal_user');
let pageStack=[];
function showPage(name, push=true){
  const current=$$('.page').find(p=>p.classList.contains('active'));
  const currentName=current?current.id.replace('page-',''):null;
  if(push && currentName && currentName!==name) pageStack.push(currentName);
  $$('.page').forEach(p=>p.classList.remove('active'));
  const target=$('#page-'+name);
  if(!target){console.warn('Halaman tidak ditemukan:',name);return;}
  target.classList.add('active');
  $('#bottomNav').style.display=['settings','chat-settings','devices','room'].includes(name)?'none':'flex';
  $('#popupMenu').hidden=true;
}
function goBack(fallback='chat'){
  const previous=pageStack.pop();
  showPage(previous||fallback,false);
}
function localUsers(){
  const accounts=getAccounts();
  return Object.values(accounts).filter(a=>a.username && a.username.toLowerCase()!=='onezal').map(a=>({
    id:'user_'+a.username.toLowerCase(),name:a.username,type:'person',last:'Ketuk untuk mulai chat',time:'Pengguna',unread:false,avatar:defaultAvatar,verified:false
  }));
}
function syncUserContacts(){
  const known=new Set(contacts.map(c=>c.id));
  localUsers().forEach(u=>{if(!known.has(u.id))contacts.push(u);});
}
function renderChats(){
  syncUserContacts();
  const q=$('#searchUser').value.trim().replace(/^@/,'').toLowerCase();
  let rows=contacts.filter(c=>(filter==='all'||(filter==='grup'?c.type==='grup':c.unread))&&(c.name.toLowerCase().includes(q)||c.last.toLowerCase().includes(q)));
  // During username search, show matching registered users even if they have no chat history yet.
  if(q){const matches=localUsers().filter(u=>u.name.toLowerCase().includes(q));matches.forEach(u=>{if(!rows.some(r=>r.id===u.id))rows.push(u);});}
  $('#chatCount').textContent=rows.length+' kontak/ruang';
  $('#chatList').innerHTML=rows.map(c=>`<div class="chat-row" data-room="${c.id}"><img class="avatar" src="${c.avatar}"><div class="chat-info"><div class="chat-name-line"><b>${c.name}</b>${c.verified?'<span class="verified-mark">✓</span>':''}</div><p>${c.last}</p></div><div class="chat-meta">${c.time}${c.unread?'<br><span class="unread-dot"></span>':''}</div></div>`).join('')||'<p class="muted">Username tidak ditemukan. Coba ejaan lain.</p>';
  $$('[data-room]').forEach(el=>el.onclick=()=>openRoom(el.dataset.room));
}
function openRoom(id){currentRoom=id;let c=contacts.find(x=>x.id===id);if(!c){c=localUsers().find(x=>x.id===id);if(c)contacts.push(c);}if(!c)return;c.unread=false;$('#roomTitle').textContent=c.name;$('#roomSubtitle').textContent=c.type==='grup'?'Grup · CHATONE!':'Percakapan pribadi';$('#roomAvatar').src=c.avatar;showPage('room');renderMessages();}
function renderMessages(){let msgs=history[currentRoom]||[{text:currentRoom==='global'?'Selamat datang di global chat! Semua anggota dapat bergabung setelah layanan server diaktifkan.':'Mulai percakapan dengan pengguna ini.',mine:false,time:'07.00'}];$('#messages').innerHTML=msgs.map(m=>`<div class="message ${m.mine?'mine':''}">${m.text?escapeHTML(m.text):''}${m.media?`<img src="${m.media}" alt="Lampiran">`:''}<time>${m.time}</time></div>`).join('');$('#messages').scrollTop=$('#messages').scrollHeight;}
function escapeHTML(s){return s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function send(text,media){if(!text&&!media)return;history[currentRoom]??=[];history[currentRoom].push({text,media,mine:true,time:new Date().toLocaleTimeString('id-ID',{hour:'2-digit',minute:'2-digit'})});let c=contacts.find(x=>x.id===currentRoom);if(c){c.last=text||'Foto';c.time='Baru';}$('#messageInput').value='';renderMessages();renderChats();}
$('#sendMessage').onclick=()=>send($('#messageInput').value.trim());$('#messageInput').addEventListener('keydown',e=>{if(e.key==='Enter')send($('#messageInput').value.trim());});
$('#roomBack').onclick=()=>goBack('chat');$('#attachPhoto').onclick=()=>$('#imagePicker').click();
$('#imagePicker').onchange=e=>{let f=e.target.files[0];if(!f)return;let r=new FileReader();r.onload=()=>{if($('#page-chat-settings').classList.contains('active')){document.body.style.backgroundImage=`linear-gradient(#050912aa,#050912aa),url('${r.result}')`;localStorage.setItem('chatone_wallpaper',r.result);}else send('',r.result);};r.readAsDataURL(f);e.target.value='';};
const savedWallpaper=localStorage.getItem('chatone_wallpaper');if(savedWallpaper)document.body.style.backgroundImage=`linear-gradient(#050912aa,#050912aa),url('${savedWallpaper}')`;
$$('.nav-item').forEach(b=>b.onclick=()=>{let p=b.dataset.page;$$('.nav-item').forEach(x=>x.classList.toggle('active',x===b));showPage(p);});
$$('.filter').forEach(b=>b.onclick=()=>{$$('.filter').forEach(x=>x.classList.toggle('active',x===b));filter=b.dataset.filter;renderChats();});
$('#searchUser').oninput=renderChats;
$('#topMore').onclick=()=>{$('#popupMenu').hidden=!$('#popupMenu').hidden;};
$('#roomMore').onclick=()=>{$('#popupMenu').hidden=!$('#popupMenu').hidden;};
function openModal(title,body){$('#modalTitle').textContent=title;$('#modalBody').innerHTML=body;$('#modalBackdrop').hidden=false;}
$('#modalClose').onclick=()=>$('#modalBackdrop').hidden=true;$('#modalBackdrop').onclick=e=>{if(e.target.id==='modalBackdrop')e.currentTarget.hidden=true;};
$('#goSettings').onclick=()=>{$('#popupMenu').hidden=true;showPage('settings');};
$('#goDevices').onclick=()=>{$('#popupMenu').hidden=true;showPage('devices');};
$('#goWallpaper').onclick=()=>{$('#popupMenu').hidden=true;showPage('chat-settings');};
$('#openChatSettings').onclick=()=>showPage('chat-settings');$('#linkedDevices').onclick=()=>showPage('devices');
$$('[data-back]').forEach(b=>b.onclick=()=>goBack('settings'));
$('#themePick').onclick=()=>$('#themeOptions').hidden=!$('#themeOptions').hidden;
$$('[data-theme]').forEach(b=>b.onclick=()=>{document.body.classList.remove('theme-black','theme-blur','theme-green');document.body.classList.add('theme-'+b.dataset.theme);localStorage.setItem('chatone_theme',b.dataset.theme);$('#themeOptions').hidden=true;});
const savedTheme=localStorage.getItem('chatone_theme');if(savedTheme)document.body.classList.add('theme-'+savedTheme);
$('#wallpaperPick').onclick=()=>$('#imagePicker').click();
$('#changeProfile').onclick=()=>$('#profilePicker').click();
$('#profilePicker').onchange=e=>{let f=e.target.files[0];if(!f)return;let r=new FileReader();r.onload=()=>{$('#profilePreview').src=r.result;$('.story-add img').src=r.result;};r.readAsDataURL(f);};
$('#addStory').onclick=()=>$('#storyPicker').click();
$('#storyPicker').onchange=e=>{let f=e.target.files[0];if(!f)return;let url=URL.createObjectURL(f);stories.unshift({name:localStorage.getItem('chatone_current_user')||'Status saya',url,type:f.type.startsWith('video')?'video':'image',time:'Baru saja'});renderStories();e.target.value='';};
function renderStories(){$('#storyList').innerHTML=stories.map((s,i)=>`<div class="story-row" data-story="${i}"><img src="${s.type==='image'?s.url:defaultAvatar}"><div><b>${s.name}</b><small>${s.time} · ${s.type==='video'?'Video':'Foto'}</small></div></div>`).join('')||'<p class="muted">Belum ada status teman.</p>';$$('[data-story]').forEach(el=>el.onclick=()=>{let s=stories[+el.dataset.story];openModal('Status '+s.name,s.type==='video'?`<video src="${s.url}" controls autoplay style="width:100%;border-radius:12px"></video>`:`<img src="${s.url}" style="width:100%;border-radius:12px">`);});}
$('#myViewers').onclick=()=>openModal('Dilihat oleh','<p>Belum ada yang melihat status Anda.</p>');
renderChats();renderStories();

// --- CHATONE account and welcome flow (prototype/local browser only) ---
const authScreen=$('#authScreen'), mainApp=$('#mainApp'), introScreen=$('#introScreen'), introVideo=$('#introVideo');
function authTab(which){$('#loginForm').hidden=which!=='login';$('#registerForm').hidden=which!=='register';$('#showLogin').classList.toggle('active',which==='login');$('#showRegister').classList.toggle('active',which==='register');}
$('#showLogin').onclick=()=>authTab('login');$('#showRegister').onclick=()=>authTab('register');
async function passwordHash(value){const bytes=new TextEncoder().encode(value);const digest=await crypto.subtle.digest('SHA-256',bytes);return [...new Uint8Array(digest)].map(x=>x.toString(16).padStart(2,'0')).join('');}
function getAccounts(){try{return JSON.parse(localStorage.getItem('chatone_accounts')||'{}')}catch{return {}}}
function setHint(id,msg){$(id).textContent=msg;}
$('#registerForm').onsubmit=async e=>{e.preventDefault();const username=$('#registerUsername').value.trim().replace(/^@/,'');const password=$('#registerPassword').value;if(!/^[a-zA-Z0-9_.]{3,24}$/.test(username)){setHint('#registerHint','Username: 3–24 karakter, gunakan huruf/angka/._');return;}const accounts=getAccounts();const key=username.toLowerCase();if(key==='onezal'){setHint('#registerHint','Username onezal khusus akun resmi dan harus dibuat melalui server admin.');return;}if(accounts[key]){setHint('#registerHint','Username sudah digunakan. Silakan masuk.');return;}accounts[key]={username,passwordHash:await passwordHash(password)};localStorage.setItem('chatone_accounts',JSON.stringify(accounts));setHint('#registerHint','Akun telah dibuat, silakan masuk.');renderChats();$('#loginUsername').value=username;$('#loginPassword').value='';authTab('login');};
function launchApp(username){localStorage.setItem('chatone_current_user',username);$('#profileName').textContent=username;$('#profileUsername').textContent='@'+username;$('#profileVerified').hidden=username.toLowerCase()!=='onezal';$('#profilePreview').src=defaultAvatar;authScreen.hidden=true;introScreen.hidden=false;mainApp.hidden=true;introVideo.currentTime=0;introVideo.play().catch(()=>{});introVideo.onended=finishIntro;}
function finishIntro(){introVideo.pause();introScreen.hidden=true;mainApp.hidden=false;showPage('chat');$$('.nav-item').forEach(x=>x.classList.toggle('active',x.dataset.page==='chat'));renderChats();}
$('#skipIntro').onclick=finishIntro;
$('#loginForm').onsubmit=async e=>{e.preventDefault();const username=$('#loginUsername').value.trim().replace(/^@/,'');const password=$('#loginPassword').value;const account=getAccounts()[username.toLowerCase()];if(!account||account.passwordHash!==await passwordHash(password)){setHint('#loginHint','Username atau password belum cocok.');return;}setHint('#loginHint','Berhasil masuk.');launchApp(account.username);};
const current=localStorage.getItem('chatone_current_user');if(current){launchApp(current);}else{mainApp.hidden=true;authScreen.hidden=false;introScreen.hidden=true;}

document.addEventListener('keydown',e=>{if(e.key==='Escape' && !$('#modalBackdrop').hidden){$('#modalBackdrop').hidden=true;return;}if(e.key==='Escape' && !$('#popupMenu').hidden){$('#popupMenu').hidden=true;return;}if(e.key==='Escape' && $('#page-room').classList.contains('active'))goBack('chat');});
