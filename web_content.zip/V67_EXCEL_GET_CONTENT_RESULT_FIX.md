# V67 — Excel GET_CONTENT Result Fix

Built from V66. The Excel import bridge now uses Android ACTION_GET_CONTENT instead of ACTION_OPEN_DOCUMENT, with explicit Excel/CSV/text MIME types. The Activity result handler accepts both Intent.getData() and ClipData, preserves readable URI permission when available, and reports a clear error if Android returns no URI.

Version 2.33 / versionCode 37.
