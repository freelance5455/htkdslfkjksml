# Resources Centre — Admin Guide (2.4.7)

Open **Admin Console → Resources**.

## Creative tools and tutorials

- Create a record using the editor and save it as Draft until ready.
- Edit any record using its Edit action.
- Publish or move records back to Draft individually or by selecting records and using the bulk action bar.
- Bulk delete is permanent and limited to 100 selected records per request.
- Search by name/title, slug or category and navigate 50 records per page.
- Tutorial editor retains Markdown content, steps, related resources, screenshots/GIFs, external video URLs, difficulty, reading time and publication state.

## Categories

- Add, rename, reorder, activate or deactivate categories.
- Deactivation is non-destructive and preserves assigned resources.
- A category can only be permanently deleted when no tool/tutorial records are assigned to it. Reassign or uncategorize those records first.

## Permissions and safety

- All write actions remain behind the existing admin authorization and CSRF validation.
- Provider links are URL-validated by the server.
- Resource images continue to use the existing validated media upload/storage routes.
- Administrative changes are recorded in the existing admin audit log.
