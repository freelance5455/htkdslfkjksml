# WONDER SHIFT V3 — stock et autorisations

- Administrateur/Superviseur : accès opérationnel, caisse, stock, approbation des demandes. Peut ajouter des quantités, ajuster après inventaire et créer des consommables.
- Agent : enregistre les opérations et demande suppression/correction ; pas d'accès direct à la caisse, au stock ni à l'administration. Rapports jour/semaine uniquement.
- Développeur : gestion technique complète et suppression définitive du catalogue stock.
- Les entrées stock et ajustements sont enregistrés comme mouvements et donc synchronisables.
- L'ajustement à zéro est un mouvement d'ajustement, pas un effacement de l'historique.
- Une opération supprimée approuvée désactive ses mouvements de stock et de caisse.
