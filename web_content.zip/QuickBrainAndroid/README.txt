QUICK BRAIN - Proyecto Android

Este paquete contiene tu juego HTML dentro de una app Android WebView.
Todavía NO es un APK instalado ni compilado.

Para generar el APK:
1. Instala Android Studio desde el sitio oficial de Android Developers.
2. Abre Android Studio y elige Open.
3. Selecciona la carpeta QuickBrainAndroid (la carpeta que contiene settings.gradle).
4. Espera a que termine la sincronización de Gradle e instala el SDK Android 35 si lo solicita.
5. En el menú Build, elige Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio mostrará la ubicación del APK generado. Antes de compartirlo, prueba la instalación en tu propio teléfono.

Notas:
- El juego conserva su guardado local mediante localStorage en el almacenamiento de la app.
- Se necesita internet para cargar Google Fonts, Firebase scripts y las banderas externas del juego.
- La configuración Firebase del HTML original está vacía; las funciones que dependan de una cuenta/servidor no quedan activadas por este empaquetado.
- El permiso INTERNET se incluye para esos recursos. No se solicitan permisos de cámara, contactos, ubicación ni micrófono.
- Este proyecto no garantiza que el HTML o sus servicios externos estén libres de vulnerabilidades. Revisa el código y prueba el APK antes de distribuirlo.
