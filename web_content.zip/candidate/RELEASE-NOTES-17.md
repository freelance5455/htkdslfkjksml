# MedPocket v17 — Connect foundation and account setup refinement

## Account and cloud-sync refinement
- The Supabase Project URL and public publishable key are configured in the application so ordinary users no longer need to paste connection credentials.
- The public publishable key is a browser credential; a Supabase secret/service-role key is never embedded.
- Android now includes the same `supabase-sync.js` module as the Netlify build. This repairs the missing Android script reference for the existing account and study-only sync feature.
- Study sync remains allowlist-only. Patient logbook entries, patient-identifiable clinical information, clinical case records, uploaded documents, images and local file attachments remain excluded.

## MedPocket Connect foundation
- Added an isolated Connect workspace module with account-gated identity/profile setup, username discoverability, direct conversations, group conversations, public community discovery/creation, invitation-code joining, text messaging, private attachment upload, voice-note recording, blocking and reporting UI.
- The Connect UI is deliberately locked pending application and verification of `connect-security-hardening.sql`.
- One-to-one WebRTC calling is included with STUN-only connectivity; TURN relay configuration and device testing remain. Group calls are not included.
- The existing Connect database tables and RPCs are reused; the patch does not recreate the tables or touch study-sync records.

## Security patch
- `connect-security-hardening.sql` addresses profile visibility when blocked, invitation-based membership reactivation, the ineffective community-message self-block predicate, call-signal visibility/recipient checks, public-community member-list privacy, and bounded invitation lifetimes with call-invite creator/owner authorization.
- Review and apply this patch in Supabase before enabling Connect. Do not enable the front-end gate until database changes and security tests have passed.

## Deployment status
- This is an integration work build, not a production-ready release. Do not deploy it over the live Netlify site yet.
- j-Docs files are retained unchanged. Existing MedPocket and Android project files are preserved.


## MedPocket Connect — chat experience upgrade (prepared build)
- Opened direct conversations in a dedicated, full-height chat view with a roomy scrolling message area and fixed composer.
- Displayed the other participant's saved Connect profile icon in the chat header and conversation list. Built-in MedPocket profile icons can be selected for the Connect profile and are shared with other participants.
- Retained separate outgoing and incoming bubble colours with per-account colour controls.
- Added message copy, reply, edit, forward (including attachment copying), delete-for-me, and delete-for-everyone controls.
- Added clear-conversation-for-me and delete-chat/leave-group controls.
- Existing private attachment uploads and voice notes are retained.
- Added a narrowly scoped Supabase RPC migration for message-management actions. It uses the existing `mp_connect_messages` table and does not require broad client UPDATE permissions.
- The migration previously run by the user added unused metadata columns to `mp_connect_community_messages`; those extra columns are harmless. The new migration targets direct-message actions correctly.

## Remaining release gate
- One-to-one audio/video call signalling and WebRTC controls are now included using the existing call-session and call-signal tables, with a public STUN server for initial peer connectivity. Calls have not been tested between the user's devices. A dedicated TURN relay is still required for reliable connections on mobile networks and restrictive NATs; group calls remain out of scope for this release.
- No live-device test of this chat patch has been performed in this environment. Apply the included chat migration, deploy to a preview first, and test both existing accounts before replacing the live site.
