-- MedPocket Connect security hardening patch
-- Review this migration before running it in Supabase SQL Editor.
-- It does not touch MedPocket study-sync data or patient records.

-- 1) Respect blocks when deciding whether another member's profile is visible.
create or replace function public.mp_connect_can_view_profile(p_user uuid)
returns boolean
language sql stable security definer set search_path=public
as $$
  select case
    when auth.uid() is null or p_user is null then false
    when p_user=auth.uid() then true
    when public.mp_connect_is_blocked(auth.uid(),p_user) then false
    else
      exists(select 1 from public.mp_connect_profiles p where p.user_id=p_user and p.discoverable=true)
      or exists(
        select 1
        from public.mp_connect_conversation_members a
        join public.mp_connect_conversation_members b on b.conversation_id=a.conversation_id
        where a.user_id=auth.uid() and b.user_id=p_user
          and a.status='active' and b.status='active'
      )
  end;
$$;

-- 2) Do not reactivate removed memberships with an old invitation.
-- Active and pending memberships remain unchanged; a user who voluntarily left
-- may rejoin with a still-valid invitation; a removed member needs moderator action.
create or replace function public.mp_connect_join_invite(p_code text)
returns jsonb
language plpgsql security definer set search_path=public
as $$
declare
  v_inv public.mp_connect_invites%rowtype;
  v_status text;
  v_existing_status text;
  v_conversation uuid;
  v_kind text;
begin
  if auth.uid() is null then raise exception 'Sign in is required'; end if;

  select * into v_inv
  from public.mp_connect_invites
  where code=trim(p_code)
    and revoked_at is null
    and (expires_at is null or expires_at>now())
    and uses<max_uses
  for update;
  if not found then raise exception 'Invite code is invalid, expired or full'; end if;

  if v_inv.target_type='direct' then
    if v_inv.target_id=auth.uid() or public.mp_connect_is_blocked(v_inv.target_id,auth.uid()) then
      raise exception 'This invitation is unavailable';
    end if;

    select c.id into v_conversation
    from public.mp_connect_conversations c
    where c.kind='direct'
      and exists(select 1 from public.mp_connect_conversation_members m where m.conversation_id=c.id and m.user_id=auth.uid() and m.status='active')
      and exists(select 1 from public.mp_connect_conversation_members m where m.conversation_id=c.id and m.user_id=v_inv.target_id and m.status='active')
      and (select count(*) from public.mp_connect_conversation_members m where m.conversation_id=c.id and m.status='active')=2
    order by c.created_at desc limit 1;

    if v_conversation is null then
      insert into public.mp_connect_conversations(kind,created_by)
      values('direct',auth.uid()) returning id into v_conversation;
      insert into public.mp_connect_conversation_members(conversation_id,user_id,role,status)
      values(v_conversation,auth.uid(),'owner','active'),(v_conversation,v_inv.target_id,'member','active');
    end if;
    update public.mp_connect_invites set uses=uses+1 where id=v_inv.id;
    return jsonb_build_object('target_type','conversation','target_id',v_conversation,'status','active');

  elsif v_inv.target_type='conversation' then
    select kind into v_kind from public.mp_connect_conversations where id=v_inv.target_id;
    if v_kind is distinct from 'group' then raise exception 'This group invitation is unavailable'; end if;

    if exists(
      select 1 from public.mp_connect_conversation_members m
      where m.conversation_id=v_inv.target_id and m.status='active'
        and m.user_id<>auth.uid()
        and public.mp_connect_is_blocked(m.user_id,auth.uid())
    ) then raise exception 'This invitation is unavailable'; end if;

    select status into v_existing_status
    from public.mp_connect_conversation_members
    where conversation_id=v_inv.target_id and user_id=auth.uid();
    if found then
      if v_existing_status='active' then
        return jsonb_build_object('target_type','conversation','target_id',v_inv.target_id,'status','active');
      elsif v_existing_status='pending' then
        return jsonb_build_object('target_type','conversation','target_id',v_inv.target_id,'status','pending');
      elsif v_existing_status='removed' then
        raise exception 'Your previous membership was removed. Contact a group administrator';
      elsif v_existing_status='left' then
        v_status:=case when v_inv.requires_approval then 'pending' else 'active' end;
        update public.mp_connect_conversation_members
        set status=v_status,joined_at=case when v_status='active' then now() else joined_at end
        where conversation_id=v_inv.target_id and user_id=auth.uid() and status='left';
      else
        raise exception 'This membership cannot be restored with an invitation';
      end if;
    else
      v_status:=case when v_inv.requires_approval then 'pending' else 'active' end;
      insert into public.mp_connect_conversation_members(conversation_id,user_id,status)
      values(v_inv.target_id,auth.uid(),v_status);
    end if;

  elsif v_inv.target_type='community' then
    if not exists(select 1 from public.mp_connect_communities where id=v_inv.target_id) then
      raise exception 'This community invitation is unavailable';
    end if;
    if exists(
      select 1 from public.mp_connect_community_members m
      where m.community_id=v_inv.target_id and m.status='active'
        and m.user_id<>auth.uid()
        and public.mp_connect_is_blocked(m.user_id,auth.uid())
    ) then raise exception 'This invitation is unavailable'; end if;

    select status into v_existing_status
    from public.mp_connect_community_members
    where community_id=v_inv.target_id and user_id=auth.uid();
    if found then
      if v_existing_status='active' then
        return jsonb_build_object('target_type','community','target_id',v_inv.target_id,'status','active');
      elsif v_existing_status='pending' then
        return jsonb_build_object('target_type','community','target_id',v_inv.target_id,'status','pending');
      elsif v_existing_status='removed' then
        raise exception 'Your previous membership was removed. Contact a community moderator';
      elsif v_existing_status='left' then
        v_status:=case when v_inv.requires_approval then 'pending' else 'active' end;
        update public.mp_connect_community_members
        set status=v_status,joined_at=case when v_status='active' then now() else joined_at end
        where community_id=v_inv.target_id and user_id=auth.uid() and status='left';
      else
        raise exception 'This membership cannot be restored with an invitation';
      end if;
    else
      v_status:=case when v_inv.requires_approval then 'pending' else 'active' end;
      insert into public.mp_connect_community_members(community_id,user_id,status)
      values(v_inv.target_id,auth.uid(),v_status);
    end if;
  else
    raise exception 'Invalid invitation type';
  end if;

  update public.mp_connect_invites set uses=uses+1 where id=v_inv.id;
  return jsonb_build_object('target_type',v_inv.target_type,'target_id',v_inv.target_id,'status',v_status);
end;
$$;
revoke all on function public.mp_connect_join_invite(text) from public;
grant execute on function public.mp_connect_join_invite(text) to authenticated;

-- 3) Community-message insertion must not test whether the sender blocked themselves.
drop policy if exists mp_connect_community_messages_insert on public.mp_connect_community_messages;
create policy mp_connect_community_messages_insert
on public.mp_connect_community_messages for insert to authenticated
with check (sender_id=auth.uid() and public.mp_connect_is_community_member(community_id));

-- 4) Call signals: direct signals are visible only to sender/recipient;
-- broadcast signals (recipient_id IS NULL) are visible to active conversation members.
drop policy if exists mp_connect_signals_read on public.mp_connect_call_signals;
create policy mp_connect_signals_read
on public.mp_connect_call_signals for select to authenticated
using (
  exists(
    select 1 from public.mp_connect_call_sessions c
    where c.id=call_id and public.mp_connect_is_member(c.conversation_id)
  )
  and (recipient_id is null or sender_id=auth.uid() or recipient_id=auth.uid())
  and not public.mp_connect_is_blocked(sender_id,auth.uid())
);

drop policy if exists mp_connect_signals_insert on public.mp_connect_call_signals;
create policy mp_connect_signals_insert
on public.mp_connect_call_signals for insert to authenticated
with check (
  sender_id=auth.uid()
  and exists(
    select 1 from public.mp_connect_call_sessions c
    where c.id=call_id and c.status in ('ringing','active')
      and public.mp_connect_is_member(c.conversation_id)
  )
  and (
    recipient_id is null
    or (
      exists(
        select 1 from public.mp_connect_call_sessions c
        join public.mp_connect_conversation_members m on m.conversation_id=c.conversation_id
        where c.id=call_id and m.user_id=recipient_id and m.status='active'
      )
      and not public.mp_connect_is_blocked(recipient_id,auth.uid())
    )
  )
);

-- Re-assert helper function permissions after replacing definitions.
revoke all on function public.mp_connect_can_view_profile(uuid) from public;
grant execute on function public.mp_connect_can_view_profile(uuid) to authenticated;

-- 5) A public community can be discovered without exposing its full member list
-- to every signed-in user. Members and the individual user can still see relevant rows.
drop policy if exists mp_connect_community_members_read on public.mp_connect_community_members;
create policy mp_connect_community_members_read
on public.mp_connect_community_members for select to authenticated
using (user_id=auth.uid() or public.mp_connect_is_community_member(community_id));

-- 6) Invitation codes must expire; bound their lifetime and restrict call-invite creation.
-- General conversation/community invitations: maximum 30-day lifetime.
create or replace function public.mp_connect_create_invite(
  p_target_type text,
  p_target_id uuid,
  p_requires_approval boolean,
  p_max_uses integer,
  p_expires_at timestamptz
)
returns text
language plpgsql
security definer
set search_path=public
as $$
declare
  v_code text;
  v_alphabet constant text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  v_uuid bytea;
  i integer;
begin
  if auth.uid() is null then raise exception 'Sign in is required'; end if;
  if p_max_uses is null or p_max_uses<1 or p_max_uses>500 then
    raise exception 'Maximum uses must be between 1 and 500';
  end if;
  if p_expires_at is null or p_expires_at<=now() or p_expires_at>now()+interval '30 days' then
    raise exception 'Invitation expiry must be within the next 30 days';
  end if;

  if p_target_type='direct' then
    if p_target_id<>auth.uid() then raise exception 'Invalid direct invitation target'; end if;
  elsif p_target_type='conversation' then
    if not exists(
      select 1 from public.mp_connect_conversations c
      join public.mp_connect_conversation_members m on m.conversation_id=c.id
      where c.id=p_target_id and c.kind='group'
        and m.user_id=auth.uid() and m.status='active'
    ) then raise exception 'You cannot invite people to this conversation'; end if;
  elsif p_target_type='community' then
    if not public.mp_connect_is_community_member(p_target_id) then
      raise exception 'You cannot invite people to this community';
    end if;
  else
    raise exception 'Invalid invitation type';
  end if;

  loop
    v_uuid:=uuid_send(gen_random_uuid());
    v_code:='';
    for i in 0..9 loop
      v_code:=v_code||substr(v_alphabet,(get_byte(v_uuid,i)%32)+1,1);
    end loop;
    begin
      insert into public.mp_connect_invites(
        target_type,target_id,code,created_by,requires_approval,max_uses,uses,expires_at
      ) values(
        p_target_type,p_target_id,v_code,auth.uid(),coalesce(p_requires_approval,false),p_max_uses,0,p_expires_at
      );
      return v_code;
    exception when unique_violation then
      -- Retry only if the generated code collided with an existing code.
    end;
  end loop;
end;
$$;

-- Call invitations: maximum 24-hour lifetime; only the call creator or a
-- conversation owner/admin may create a code for an active call.
create or replace function public.mp_connect_create_call_invite(
  p_call_id uuid,
  p_max_uses integer default 20,
  p_expires_at timestamptz default (now()+interval '1 hour')
)
returns text
language plpgsql
security definer
set search_path=public
as $$
declare
  v_conversation uuid;
  v_creator uuid;
  v_code text;
  v_alphabet constant text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  v_uuid bytea;
  i integer;
begin
  if auth.uid() is null then raise exception 'Sign in is required'; end if;
  if p_max_uses is null or p_max_uses<1 or p_max_uses>500 then
    raise exception 'Maximum uses must be between 1 and 500';
  end if;
  if p_expires_at is null or p_expires_at<=now() or p_expires_at>now()+interval '24 hours' then
    raise exception 'Call invitation expiry must be within the next 24 hours';
  end if;

  select c.conversation_id,c.created_by into v_conversation,v_creator
  from public.mp_connect_call_sessions c
  where c.id=p_call_id and c.status in ('ringing','active');
  if not found or not public.mp_connect_is_member(v_conversation) then
    raise exception 'Active call membership is required';
  end if;
  if v_creator<>auth.uid() and not exists(
    select 1 from public.mp_connect_conversation_members m
    where m.conversation_id=v_conversation and m.user_id=auth.uid()
      and m.status='active' and m.role in ('owner','admin')
  ) then
    raise exception 'Only the call creator or a conversation owner/admin can invite participants';
  end if;

  loop
    v_uuid:=uuid_send(gen_random_uuid());
    v_code:='';
    for i in 0..9 loop
      v_code:=v_code||substr(v_alphabet,(get_byte(v_uuid,i)%32)+1,1);
    end loop;
    begin
      insert into public.mp_connect_call_invites(call_id,code,created_by,max_uses,uses,expires_at)
      values(p_call_id,v_code,auth.uid(),p_max_uses,0,p_expires_at);
      return v_code;
    exception when unique_violation then
      -- Retry only if the generated code collided with an existing code.
    end;
  end loop;
end;
$$;

revoke all on function public.mp_connect_create_invite(text,uuid,boolean,integer,timestamptz) from public;
grant execute on function public.mp_connect_create_invite(text,uuid,boolean,integer,timestamptz) to authenticated;
revoke all on function public.mp_connect_create_call_invite(uuid,integer,timestamptz) from public;
grant execute on function public.mp_connect_create_call_invite(uuid,integer,timestamptz) to authenticated;
