# MedPocket v17 — Android + Netlify

This package contains the Android Studio project and the matching static Netlify site.

## Final completion work in this revision

### j-Docs integration and document handling
- Added j-Docs as a dedicated, isolated workspace reachable from the Reference menu and Home quick-launch tile. Its editor runs in its own iframe so its UI and JavaScript do not overwrite MedPocket's interface or state.
- Added **Open in j-Docs** to the MedPocket document reader. The selected stored file is passed as a Blob through a same-origin, type-checked message bridge; the original MedPocket file record is not moved or deleted.
- Bundled j-Docs assets locally in both Android and Netlify packages. Its editor scripts, styles, fonts, ZIP and QR libraries do not depend on the third-party injected script.
- Improved j-Docs file previews so long text is scrollable instead of being silently cut off, the fallback file-open path is awaited and reported safely, and mobile file-viewer actions remain visible instead of disappearing.
- Bumped the service-worker cache to v19 and pre-cached the j-Docs and Connect app shells plus core assets for offline use.


### Repaired navigation and support actions
- Added the missing Drug Reference and Disease Guide page renderers. Both pages support search and local add/edit/delete operations.
- Changed the rating action to save an actual local rating rather than opening an email draft.
- Improved the app-share fallback so it copies the share text/link or presents the link for manual copying.

### Eight added features
1. Universal Search across files, notes, flashcards, MCQs, drugs, conditions, protocols and references.
2. Bulk File Transfer: select multiple stored files and export/import a MedPocket package without replacing existing records.
3. Duplicate Finder: flags same-name/same-size candidate duplicates for manual review; it does not automatically delete them.
4. Storage Manager: reports local attachment storage and identifies orphaned file blobs, with a confirmation-protected cleanup.
5. Data Integrity Check: checks folder structure, duplicate identifiers, incomplete flashcards and invalid MCQ answer indexes.
6. Device Diagnostics: checks browser storage, IndexedDB, secure context, crypto, notifications, camera API and file-store access.
7. Study Report: exports a JSON summary of study organisation and saved content.
8. Quick Launcher: Ctrl/Cmd+K (or the home-screen tile) opens a searchable navigation palette.

### Four Android host capabilities
- Native multi-file document picker for HTML file inputs.
- Runtime camera/microphone permission handling for supported web features.
- Pinch-to-zoom in the Android WebView, with zoom controls hidden.
- Android Downloads handling for ordinary HTTP(S) downloads and external URL hand-off to Android apps.

## Deploy to Netlify

1. Deploy the **contents** of `netlify-site/` using Netlify's manual deploy flow, or connect the repository.
2. Use no build command and set the publish directory to `netlify-site`.
3. Use the HTTPS deployment URL. Browser-local storage and IndexedDB keep data on that device.

## Android build

Open this folder in Android Studio (it contains `settings.gradle`). The embedded web application is in `app/src/main/assets/www/`.

The Android project uses Gradle 8.7 and Android Gradle Plugin configuration in the project. A full Android build was not run in this environment because the Gradle distribution and Android SDK were not available offline.

## Important limits

- Browser storage quotas and Android device memory still constrain very large files.
- The Duplicate Finder detects likely duplicates by matching filename and file size; it does not compare file hashes.
- PPT/PPTX rendering remains dependent on the bundled web viewer's supported content and cannot guarantee full fidelity for every animation, embedded object or complex layout.
- Clinical references are educational records. Confirm clinical decisions and dosing against current authoritative sources and local protocols.
- Cloud sync uses the MedPocket Supabase project configuration embedded in the app. Only the public publishable key is included; never embed a secret/service-role key. Study sync remains allowlist-only.


## v15 update
See `RELEASE-NOTES-15.md` for the viewport and disease-guide changes.


## v17 integration work build

See `RELEASE-NOTES-17.md`. This build includes the Connect foundation and a database hardening migration. Connect remains intentionally locked until `connect-security-hardening.sql` has been reviewed, applied and verified. Audio/video calling is not yet enabled. Do not deploy this work build over the live site.
