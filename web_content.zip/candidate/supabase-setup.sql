-- Run this once in Supabase Dashboard → SQL Editor.
-- One private study-data document per authenticated user.
create table if not exists public.medpocket_study_sync (
  user_id uuid primary key references auth.users(id) on delete cascade,
  payload jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.medpocket_study_sync enable row level security;

-- Users can read only their own study data.
drop policy if exists "Users can read their own MedPocket study sync" on public.medpocket_study_sync;
create policy "Users can read their own MedPocket study sync"
  on public.medpocket_study_sync for select
  to authenticated
  using (auth.uid() = user_id);

-- Users can create only a row whose owner is their authenticated account.
drop policy if exists "Users can insert their own MedPocket study sync" on public.medpocket_study_sync;
create policy "Users can insert their own MedPocket study sync"
  on public.medpocket_study_sync for insert
  to authenticated
  with check (auth.uid() = user_id);

-- Users can update only their own row.
drop policy if exists "Users can update their own MedPocket study sync" on public.medpocket_study_sync;
create policy "Users can update their own MedPocket study sync"
  on public.medpocket_study_sync for update
  to authenticated
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

-- No anonymous access and no client-side delete policy are granted.
revoke all on public.medpocket_study_sync from anon;
grant select, insert, update on public.medpocket_study_sync to authenticated;
