# MedPocket v16 — Supabase accounts and study-only sync

This adds real email/password accounts and per-user cloud storage to the Netlify web app. The app remains offline-first: local data continues to work when the network is unavailable, and changes queue for sync after connectivity returns.

## 1. Create a free Supabase project

1. Create a project at https://supabase.com/dashboard.
2. In **Project Settings → API**, copy the **Project URL** and the **publishable key** (or legacy `anon` key).
3. Do not use or expose the `service_role` / secret key in the browser app.

## 2. Create the private sync table

1. Open **SQL Editor** in the Supabase dashboard.
2. Paste the contents of `supabase-setup.sql` from this project.
3. Run the SQL. It creates `public.medpocket_study_sync`, enables Row Level Security, and permits authenticated users to access only their own row.

## 3. Configure authentication

1. Open **Authentication → URL Configuration**.
2. Set the Site URL to your deployed Netlify URL, for example `https://your-site-name.netlify.app`.
3. Add that same URL to the Redirect URLs list. If you use a custom domain, add it too.
4. Under **Authentication → Providers → Email**, keep Email enabled. Email confirmation can remain enabled; users must confirm their address before signing in when that setting is on.

## 4. Deploy to Netlify

Deploy the **contents of `netlify-site/`** as the publish directory (or connect the repository and use `netlify.toml`). Keep `supabase-sync.js` alongside `index.html`; the service worker precaches it for offline app-shell availability. Authentication and cloud sync still require an internet connection.

## 5. Connect MedPocket

1. Open the deployed MedPocket app.
2. Open **☰ → App → Account & Cloud Sync**. The Project URL and public publishable key are already configured in this build.
3. Create an account or sign in. Confirm the email first if email confirmation is enabled.
4. Choose **Sync now** to upload or download the current study data.

## Data scope and privacy

The cloud payload is an explicit allowlist of student profile (without profile photo), study notes, flashcards, MCQs, tasks, timetable, exams, planner, study statistics, review progress, custom study/reference entries, drug and disease reference lists, and related study settings.

The following remain local and are deliberately excluded: patient logbook entries, patient-identifiable clinical information, clinical case records, uploaded documents, images, and IndexedDB attachments. Do not place identifiable patient information in study notes that are configured to sync. This technical exclusion is not a claim of regulatory compliance; assess applicable privacy, health-data and data-residency requirements before using this with real patient information.

## Free-tier notes

Supabase free-tier limits and policies can change. Free projects may pause after inactivity, and backups/uptime guarantees are limited. This setup is suitable for a zero-budget prototype or small deployment, not a guaranteed production medical-record service.

## Important sync behaviour

- Each authenticated user has one private JSONB study payload.
- Row Level Security binds the row to `auth.uid()`; users cannot read another user's row through the app's anon/publishable key.
- Changes made while signed in are automatically uploaded after a short debounce when online; use **Sync now** for an immediate sync.
- When signing in on another device, cloud arrays are merged into local arrays by record ID. For a matching ID, the cloud version wins. Back up important data before testing multiple devices.
- Uploaded files are not synced. Use MedPocket's local backup/export tools for device-specific attachments.


## Connect security hardening

The separate `connect-security-hardening.sql` file is an additive security correction for the Connect tables and functions. It does not recreate the schema and does not alter the study-sync table. Review it before running it in SQL Editor. Connect is intentionally locked in the application until this patch is applied and verified. Live audio/video calling requires additional WebRTC and TURN infrastructure and is not enabled by this migration.


### Android email redirects

The embedded Android app returns email confirmation and password-reset links to the current Netlify site (`https://delightful-bunny-5031da.netlify.app/`) because the Android WebView origin is not the public web origin. Keep that Netlify URL in Supabase Authentication → URL Configuration → Redirect URLs. If you rename the Netlify site, update the `webRedirect` value in both copies of `supabase-sync.js` and add the new URL to Supabase Redirect URLs.
