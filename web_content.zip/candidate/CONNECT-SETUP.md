# MedPocket Connect — integration status and activation checklist

Connect is integrated as an isolated MedPocket workspace and uses the same Supabase Auth account as the rest of MedPocket. The Connect tables are separate from `medpocket_study_sync`; no patient logbook or clinical case records are included in Connect or the study sync payload.

## Prepared in the application

- Persistent username-based profile with optional discoverability (off by default).
- Direct conversations and group conversations.
- Public and private community creation/discovery.
- Direct, group and community invitation-code flows, with optional approval for group/community invites.
- Text messages and Realtime refresh for conversation and community messages.
- Private conversation attachment upload and signed-link display (25 MB bucket limit).
- Voice-note recording and upload using the private Connect bucket.
- Member blocking, report submission and owner/moderator approval UI.
- Matching Netlify and Android web assets.

These flows have passed static JavaScript checks only. They have not yet been exercised against two live Supabase accounts, so they must not be described as production-tested.

## Activation status

The Supabase security-hardening migration has now been applied successfully. The four expected security functions were verified as `SECURITY DEFINER`, executable by `authenticated`, and not executable by `anon`. The invitation-table permission check also confirmed RLS is enabled and direct INSERT is denied to both `anon` and `authenticated`; invitations must be created through the RPC functions.

The Connect feature gate is therefore set to `false` in both the Netlify and Android copies of `connect.js`. This exposes the existing messaging/community workspace for controlled testing; it does **not** mean the feature is production-tested. The following checks remain before broad release:

1. Confirm the private `medpocket-connect` storage bucket and its read/insert policies exist before testing attachments and voice notes.
2. Confirm the Connect message tables are in the `supabase_realtime` publication for live refresh.
3. Test with the two separate MedPocket accounts: profile creation, direct messaging, direct invitation, group invitations, public/private community joins, approval requests, block behavior, reports, file sharing and voice notes.
4. Verify that a removed member cannot regain access with an old invitation, non-members cannot enumerate public-community member lists, and invitation expiry/use limits are enforced.

Call invitations are protected by the database RPC. One-to-one WebRTC voice/video controls are now included with STUN-only connectivity; TURN relay and device testing remain before broad release. Group calls are not included.

## Audio/video calling — initial one-to-one implementation

The database has call sessions, invitation and signalling tables, but those are not a complete calling system. Before enabling calls, MedPocket needs:

- a tested WebRTC offer/answer/ICE flow;
- a reliable STUN/TURN relay configuration (TURN credentials must not be hard-coded into a public client);
- participant state and call lifecycle handling;
- a group-call SFU or equivalent media-routing design for multi-person calls;
- permission, reconnect, network-switch and end-call tests on Android and web.

The current application exposes one-to-one call controls. They require a compatible browser/device and may fail on networks that require a TURN relay.

## Deployment caution

This is an integration work build. Do not upload it over the live Netlify site or install an Android APK until the full implementation and backend tests are complete. The existing live site and Supabase database have not been changed by this work.
