# MedPocket v15 — layout and disease-guide update

- Fixed horizontal viewport overflow and constrained content/media/tables to the available phone width.
- Removed the phone-width cap on narrow Android screens while retaining a centred desktop preview.
- Disease profiles now display expanded sections when curated content exists: pathophysiology, causes, history, features, investigations, complications, management, cure/treatment milestones, prevention and prognosis.
- Added expanded, condition-specific learning notes for malaria, pulmonary tuberculosis, HIV, cholera, typhoid, hypertension, type 2 diabetes, asthma, sickle cell disease and schistosomiasis.
- Bumped the service-worker cache to v15 and synchronised web assets with the Android packaged assets.

The 1,804-condition list remains a searchable name/category index. It is not accurate to imply that all 1,804 entries now have a complete, verified monograph; only conditions with curated profiles show those detailed sections. Continue expanding the remaining entries against current WHO and national clinical guidance. Educational use only.
