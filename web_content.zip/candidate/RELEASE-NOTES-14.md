# MedPocket 13 + j-Docs — update 14

## j-Docs immersive workspace
- Opening j-Docs now hides the MedPocket header, navigation drawer, overlay, phone-frame border and page padding.
- The editor iframe fills the available viewport; leaving j-Docs restores the normal MedPocket layout.
- Existing MedPocket-to-j-Docs document handoff is retained.

## Disease reference and search
- Preserves all 1,800 category entries from the supplied Diseases Reference List PDF.
- Builds a deduplicated index of 1,706 source names, adds 98 distinct clinically relevant conditions, and exposes 1,804 unique searchable condition names.
- Adds 38 concise educational clinical summaries with overview, causes/risk factors, features, assessment and general management principles.
- Disease names and categories are indexed in Home quick-search, Search everything and Universal Search.
- Existing user-created disease records remain separate and editable.
- The PDF is a broad reference, not an exhaustive disease taxonomy. Not every indexed entry has a full clinical summary yet.

## Daily learning and quotations
- Expands the daily medical learning bank to 420 distinct facts across 21 subject areas.
- Adds six short quotations with named attributions and source links.

## Offline and deployment
- Bundles `disease-data.js` locally and pre-caches it in service-worker cache v14.
- Keeps Android WebView and Netlify web assets identical.
- This is a source-project ZIP, not a compiled APK. Build and device testing remain necessary.
