# MedPocket v17 integration work — build status

## Source and preservation

- Source of truth: `MedPocket-v16-jdocs-enhanced.zip` supplied in the conversation.
- Work was performed on a separate extracted copy.
- j-Docs web and Android directories remain byte-for-byte identical to the supplied archive.
- The live Netlify deployment and Supabase database were not modified.

## Code prepared

- Embedded the existing Supabase Project URL and public publishable key. No secret/service-role key is included.
- Removed the requirement for ordinary users to paste Supabase connection settings.
- Added Android copies of `supabase-sync.js` and `connect.js`; the supplied Android HTML previously omitted the Supabase sync script reference.
- Added the first Connect workspace implementation and expanded the database hardening migration to cover the invitation-creation functions, expiry limits and call-invite authorization.
- Enabled the Connect workspace after the Supabase hardening migration and function/permission checks were confirmed by the user. Two-account integration testing remains outstanding.
- Added initial one-to-one WebRTC audio/video calling; TURN relay and two-account validation remain release requirements.

## Checks completed

- Node syntax checks passed for both Netlify and Android `supabase-sync.js`, `connect.js`, `sw.js`, and the inline application JavaScript.
- Android XML resources parsed successfully.
- Netlify and Android `index.html`, `supabase-sync.js`, and `connect.js` match byte-for-byte.
- Local script references resolve in both web and Android folders.
- All 31 j-Docs files in each web and Android directory match the supplied v16 archive byte-for-byte.

## Checks not completed

- No live Supabase integration test has been run with multiple accounts.
- The SQL hardening migration was applied successfully in the user's Supabase project; function configuration and invitation-table INSERT restrictions were verified. Full end-to-end policy behavior has not yet been tested with two accounts.
- Android APK assembly was attempted but could not complete because Gradle 8.7 could not be downloaded in this environment (`UnknownHostException: services.gradle.org`).
- No production deployment or device installation has been performed.

This is not yet a production-ready release package.


## Chat upgrade patch (2026-11-21)
- Updated Netlify and Android `connect.js` in lockstep.
- Added peer profile avatar/name display in direct chat headers, using the existing MedPocket built-in profile icon choices.
- Added reply, edit, copy, forward, delete-for-me, delete-for-everyone, clear-chat and delete-chat/leave-group controls.
- Added `CHAT-UPGRADE-MIGRATION.sql` with security-definer RPCs and per-user message-hide records. The app does not request broad direct-message UPDATE grants.
- Static JavaScript syntax validation passed for the updated Connect module; web and Android copies are identical.
- Existing attachment and voice-note flows were retained.
- One-to-one voice/video calling is implemented as an initial STUN-only WebRTC flow; TURN configuration and two-account device testing remain required before production use.

- Added initial one-to-one WebRTC audio/video call flow using the existing call-session/signalling tables and STUN-only connectivity; requires two-device testing and a TURN relay for reliable mobile-network support. Group calls are not included.
