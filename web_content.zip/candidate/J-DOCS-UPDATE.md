# j-Docs interaction and document-library update

This update improves the existing j-Docs implementation without replacing its editor or project format.

## Included
- Slide element movement, resizing, and rotation update the existing canvas nodes directly instead of rebuilding the complete slide on every pointer movement.
- Geometry updates are coalesced with animation frames to reduce redundant layout and rendering work.
- Touch editing handles are larger and use touch-aware pointer handling.
- A **My Documents** library stores presentations and supported exported/imported files in browser IndexedDB.
- Existing active `.jdocs` projects are migrated into the library when j-Docs starts.
- The library supports search, open, rename, duplicate, delete, adding files from the device, and downloading stored files.
- Exported files created through j-Docs' download workflow are automatically added to the library when their format is supported.
- The web and Android j-Docs assets are kept in sync. Service-worker cache versions were advanced so the new library script is available offline.

## Storage and PDF note
The library is local to the browser/app installation; it does not upload documents to Supabase. Browser print dialogs do not expose the resulting PDF bytes back to the web app, so a PDF created with **Print / Save as PDF** must be added using **My Documents → Add files** after saving it to the device. Existing `.jdocs` files remain compatible.

## Validation
- JavaScript syntax checks passed for app-owned JavaScript files in the Netlify and Android asset trees.
- The service-worker cache lists the new library script.
- Netlify and Android j-Docs folders were compared after copying and match.
- A full Android Gradle build and hands-on Android touch test were not run in this environment; those remain device/build validation steps.
