# MedPocket v16 — Startup recovery and mobile layout repair

## Critical startup repair
- Fixed a JavaScript syntax error introduced in v15: mobile-layout CSS had been inserted into the JavaScript string used to export HTML files.
- Moved the mobile layout rules into the actual application stylesheet.
- Corrected the newline in the HTML-export template so the main application script parses correctly.
- Added a bounded IndexedDB startup wait (with blocked/error/timeout handling) so a stalled local file database cannot indefinitely prevent the main interface from rendering.
- Added a recovery screen if a non-essential startup step throws an exception.

## Mobile layout
- Prevented horizontal page overflow and clipped content leaking beyond the phone viewport.
- Kept tables horizontally scrollable within the content area and constrained media and long text.
- Synchronized the web and Android copies of the application entry point and data assets.

## Offline cache
- Bumped the service-worker cache to `medpocket-v16` so clients replace the previous cached application files.

## Medical library status
- The source index contains 1,800 condition names.
- The data file contains 38 curated condition profiles. The remaining index entries are not yet complete condition-specific clinical profiles; they must not be mistaken for fully researched disease explanations.
- Existing curated profiles and the disease search/detail interface are preserved.

## Validation
- Main inline JavaScript passes `node --check`.
- Disease data JavaScript passes `node --check`.
- Android XML resources parse successfully.
- Android Gradle assembly could not be run in this environment because the Gradle 8.7 distribution could not be downloaded (network DNS unavailable).

## Supabase accounts and study-only cloud sync

- Added email/password account creation, sign-in, sign-out and password reset/update flow for the Netlify web app.
- Added per-user study cloud sync through Supabase Auth and a private Postgres JSONB row protected by Row Level Security.
- Sync is limited to an explicit study-data allowlist. Patient logbook entries, clinical case records, uploaded documents, images and local IndexedDB attachments are excluded.
- Added `supabase-setup.sql` and `SUPABASE-SETUP.md` with project configuration and deployment instructions.
- The app remains offline-first; account access and cloud sync require a network connection.
