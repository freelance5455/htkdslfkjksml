-- MedPocket Connect — safe message-management upgrade
-- Direct conversations use public.mp_connect_messages (not mp_connect_community_messages).
-- The direct-message table already has edited_at and deleted_at in the base Connect schema.
-- This migration adds per-user hide records and narrowly scoped RPCs.
-- It does not alter study-sync data, patient records, or existing conversation messages.

create table if not exists public.mp_connect_message_hides (
  user_id uuid not null references auth.users(id) on delete cascade,
  message_id uuid not null references public.mp_connect_messages(id) on delete cascade,
  hidden_at timestamptz not null default now(),
  primary key (user_id, message_id)
);

alter table public.mp_connect_message_hides enable row level security;
drop policy if exists mp_connect_message_hides_read_own on public.mp_connect_message_hides;
create policy mp_connect_message_hides_read_own
  on public.mp_connect_message_hides
  for select to authenticated
  using (user_id = auth.uid());

revoke all on public.mp_connect_message_hides from anon, authenticated;
grant select on public.mp_connect_message_hides to authenticated;

create or replace function public.mp_connect_hide_message(p_message_id uuid)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  v_conversation uuid;
begin
  if auth.uid() is null then raise exception 'Sign in is required'; end if;

  select conversation_id into v_conversation
  from public.mp_connect_messages
  where id = p_message_id and deleted_at is null;

  if not found or not public.mp_connect_is_member(v_conversation) then
    raise exception 'Message is unavailable';
  end if;

  insert into public.mp_connect_message_hides(user_id, message_id)
  values(auth.uid(), p_message_id)
  on conflict(user_id, message_id) do nothing;

  return true;
end;
$$;

create or replace function public.mp_connect_clear_conversation(p_conversation_id uuid)
returns integer
language plpgsql
security definer
set search_path = public
as $$
declare
  v_count integer;
begin
  if auth.uid() is null then raise exception 'Sign in is required'; end if;
  if not public.mp_connect_is_member(p_conversation_id) then
    raise exception 'Conversation is unavailable';
  end if;

  insert into public.mp_connect_message_hides(user_id, message_id)
  select auth.uid(), m.id
  from public.mp_connect_messages m
  where m.conversation_id = p_conversation_id and m.deleted_at is null
  on conflict(user_id, message_id) do nothing;

  get diagnostics v_count = row_count;
  return v_count;
end;
$$;

create or replace function public.mp_connect_delete_message(p_message_id uuid)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  v_conversation uuid;
  v_sender uuid;
begin
  if auth.uid() is null then raise exception 'Sign in is required'; end if;

  select conversation_id, sender_id into v_conversation, v_sender
  from public.mp_connect_messages
  where id = p_message_id and deleted_at is null;

  if not found or v_sender <> auth.uid() or not public.mp_connect_is_member(v_conversation) then
    raise exception 'You can delete only your own message in an active conversation';
  end if;

  update public.mp_connect_messages
  set deleted_at = now()
  where id = p_message_id and sender_id = auth.uid() and deleted_at is null;

  return found;
end;
$$;

create or replace function public.mp_connect_edit_message(p_message_id uuid, p_body text)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  v_conversation uuid;
  v_sender uuid;
  v_type text;
begin
  if auth.uid() is null then raise exception 'Sign in is required'; end if;
  if p_body is null or length(trim(p_body)) < 1 or length(p_body) > 12000 then
    raise exception 'Message must contain 1 to 12000 characters';
  end if;

  select conversation_id, sender_id, message_type
  into v_conversation, v_sender, v_type
  from public.mp_connect_messages
  where id = p_message_id and deleted_at is null;

  if not found or v_sender <> auth.uid() or v_type <> 'text'
     or not public.mp_connect_is_member(v_conversation) then
    raise exception 'You can edit only your own text message in an active conversation';
  end if;

  update public.mp_connect_messages
  set body = trim(p_body), edited_at = now()
  where id = p_message_id and sender_id = auth.uid() and deleted_at is null;

  return found;
end;
$$;

create or replace function public.mp_connect_leave_conversation(p_conversation_id uuid)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
begin
  if auth.uid() is null then raise exception 'Sign in is required'; end if;

  update public.mp_connect_conversation_members
  set status = 'left'
  where conversation_id = p_conversation_id
    and user_id = auth.uid()
    and status = 'active';

  if not found then raise exception 'Active conversation membership not found'; end if;
  return true;
end;
$$;

revoke all on function public.mp_connect_hide_message(uuid) from public;
revoke all on function public.mp_connect_clear_conversation(uuid) from public;
revoke all on function public.mp_connect_delete_message(uuid) from public;
revoke all on function public.mp_connect_edit_message(uuid,text) from public;
revoke all on function public.mp_connect_leave_conversation(uuid) from public;

grant execute on function public.mp_connect_hide_message(uuid) to authenticated;
grant execute on function public.mp_connect_clear_conversation(uuid) to authenticated;
grant execute on function public.mp_connect_delete_message(uuid) to authenticated;
grant execute on function public.mp_connect_edit_message(uuid,text) to authenticated;
grant execute on function public.mp_connect_leave_conversation(uuid) to authenticated;


-- Permit either active participant to update the call lifecycle through a
-- constrained RPC; direct table UPDATE remains unavailable to ordinary clients.
create or replace function public.mp_connect_set_call_status(p_call_id uuid, p_status text)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  v_conversation uuid;
begin
  if auth.uid() is null then raise exception 'Sign in is required'; end if;
  if p_status not in ('active','ended','declined','missed') then
    raise exception 'Invalid call status';
  end if;

  select conversation_id into v_conversation
  from public.mp_connect_call_sessions
  where id = p_call_id and status in ('ringing','active');

  if not found or not public.mp_connect_is_member(v_conversation) then
    raise exception 'Call is unavailable';
  end if;

  update public.mp_connect_call_sessions
  set status = p_status,
      ended_at = case when p_status in ('ended','declined','missed') then now() else ended_at end
  where id = p_call_id;

  return found;
end;
$$;

revoke all on function public.mp_connect_set_call_status(uuid,text) from public;
grant execute on function public.mp_connect_set_call_status(uuid,text) to authenticated;
