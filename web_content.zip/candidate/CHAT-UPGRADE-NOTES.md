# MedPocket Connect chat upgrade

This build refreshes the mobile conversation experience with a dedicated full-height chat view, larger scrollable message area, a compact composer, distinct incoming/outgoing bubble styling, per-account local bubble colour controls, improved conversation rows, and profile-initial avatars in chat/discovery lists.

Existing file sharing and voice-note upload flows are retained. File sharing remains limited to the existing 25 MB upload ceiling and configured private storage bucket.

## Supabase step required for message deletion

Run `CHAT-UPGRADE-MIGRATION.sql` in the Supabase SQL Editor. It adds an RLS update policy that allows an authenticated sender to soft-delete only their own message while they remain an active conversation member. The client sets `deleted_at`; the message then disappears for all participants. This migration is intentionally separate and must be run before using the new Delete for everyone action.

## Not enabled in this build

Live voice/video calling is not enabled. Although call-session and call-signal tables exist, a complete WebRTC offer/answer/ICE flow, TURN relay configuration, call UI, and two-account device testing are still required. The chat header shows disabled call controls rather than pretending calls work.

## Deployment

Deploy the contents of `netlify-site/` to the existing Netlify site. Keep the current deployed version until the new build has been tested with both of the user's accounts. The Android WebView asset copy is also updated to match the Netlify web app.
