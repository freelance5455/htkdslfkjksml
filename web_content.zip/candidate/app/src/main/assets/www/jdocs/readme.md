# j-Docs

**Beyond Imagination — one project, every surface.**  
A local-first presentation and document studio that opens almost any file, presents like PowerPoint, reads like a document, teaches like a lesson kit, and publishes like a website — from a single source.

Built as a static web app: no install, no account, no server, no telemetry. Open `index.html` and work.

---

## Why j-Docs exists

Most presentation tools optimise for one moment: the slideshow. The deck then gets copied into a PDF for handouts, pasted into Word for notes, rebuilt in a quiz tool for teaching, and re-created as a web page for people who missed the talk. Every copy drifts. Every export loses something. Every tool charges again for the same content.

j-Docs treats the deck as **structured source material**, not a flat canvas. The same project renders into four surfaces:

1. **Live presentation** — full-screen stage, presenter view, notes, timer, transitions, animations, audience engagement.
2. **Downloadable document** — continuous reading view, print-ready pages, semantic outline, accessible reading order.
3. **Teaching resource** — handouts, speaker-note pages, lesson plans, quizzes, key-term summaries.
4. **Online experience** — a standalone HTML build with embedded fonts and media that works without j-Docs.

Change one slide and every surface changes with it. Nothing drifts.

---

## Quick start

1. Open `index.html` in a modern browser (Chrome, Edge, Firefox, Safari).
2. The demo deck loads automatically. Press **Ctrl/⌘ K** to search commands or slides.
3. Press **Present** or **F5** to run the deck.
4. Drag any file onto the window to open it.

No build step, no npm install, no backend. All dependencies are vendored in `vendor/`.

---

## Feature map

### Editing
- Office-style title bar, ribbon tabs, slide rail, canvas, inspector and status bar.
- 15 layouts: title, title + content, section, two content, comparison, title only, blank, picture caption, quote, agenda, big number, stats, timeline, team, closing.
- 12 themes with coordinated palettes, gradients and font pairings.
- Text, shapes (18 types), images, tables, charts (column, bar, line, area, pie, donut), icons, media, code blocks and embeds.
- Drag, resize, rotate, snap, alignment guides, z-order, duplicate, lock, hide.
- Inline rich-text editing with bold, italic, underline, strike, lists, links, headings and code.
- Tables and charts are editable after insertion.
- SmartArt-style builders: process, cycle, list, hierarchy, pyramid and matrix.
- Ink layer with pen, highlighter and eraser.
- Comments, speaker notes, header/footer, slide numbers, dates.
- Undo/redo (60 snapshots), autosave to `localStorage`, version history snapshots.
- Outline view, sorter view, focus mode, zoom and fit.

### Universal file opener
Drag in, or choose **Open**, and j-Docs inspects the extension and magic bytes:

| Family | Formats | What happens |
|---|---|---|
| j-Docs | `.jdocs` | Full project restored |
| PowerPoint | `.pptx`, `.ppsx`, `.potx`, `.pptm` | Slides, text, images, tables, notes parsed into editable slides |
| Word | `.docx` | Headings and paragraphs converted into a structured deck |
| Excel | `.xlsx` | Sheets converted into tables across slides |
| OpenDocument | `.odp`, `.odt`, `.fodt` | Frames and text parsed |
| PDF | `.pdf` | Embedded PDF viewer with metadata |
| Text/code | `.txt`, `.md`, `.json`, `.xml`, `.js`, `.py`, `.css`, … | Syntax-aware text viewer |
| Data | `.csv`, `.tsv` | Table viewer + one-click import as a deck |
| Web | `.html`, `.htm`, `.svg` | Rendered preview |
| Images | `.png`, `.jpg`, `.gif`, `.webp`, `.bmp`, `.avif` | Image viewer |
| Media | `.mp3`, `.wav`, `.mp4`, `.webm`, `.mov` | Player |
| Fonts | `.ttf`, `.otf`, `.woff`, `.woff2` | Font specimen and metadata |
| Archives | `.zip` | Contents browser |
| Anything else | any extension | Universal binary inspector: type, size, magic bytes, text preview, hex dump |

The picker has **no `accept` filter**, so every extension is selectable.

### Outputs
- **Handouts** — 1, 2, 3, 4 or 6 slides per page, optional writing lines, header/footer, landscape.
- **Notes pages** — slide thumbnail plus speaker notes and ruled lines.
- **Slide summaries** — one-paragraph summary per slide, key terms and word counts.
- **Executive summary** — a one-page brief for decision makers.
- **Teaching kit** — objectives, key terms, discussion prompts, activities and assessment ideas.
- **Lesson plan** — timed sequence with teacher actions and learner actions.
- **Quiz builder** — multiple-choice questions generated from slide content.
- **Readability report** — word count, sentence length, reading time and grade estimate.
- **Print studio** — eight output types with live preview and A4 print CSS.
- **Document mode** — continuous reading view of the whole deck.
- **Offline package** — ZIP containing standalone viewer, project file, handout, notes, summary, teaching kit, lesson plan, quiz, fonts, media, response CSV, manifest, README and licences.
- **Export everything** — one ZIP with all formats.

### Presentation
- Full-screen stage with keyboard navigation.
- Presenter view: current slide, next slide, speaker notes, elapsed timer, wall clock and live engagement panel.
- Rehearsal mode with timer.
- Transitions: fade, dissolve, push, wipe, split, zoom, cover, uncover, morph.
- Animations: fade, fly, wipe, zoom, spin, pulse, with stagger.
- Black screen (**B**), notes overlay (**N**), presenter toggle (**P**), fullscreen (**F**).
- Progress bar and slide counter.
- Broadcast channel for multi-window control.

### Audience engagement (optional)
- Six-character session code and QR join link.
- Multiple-choice polls with live bars.
- Q&A queue with answered/reopen states.
- Word cloud sized by frequency.
- 1–5 star ratings with distribution.
- Anonymised analytics dashboard: response counts, type breakdown, poll results, average rating, top words.
- CSV export of responses.
- Cross-tab sync through `BroadcastChannel` plus `localStorage`; no server required.
- Audience view is a separate lightweight route (`#audience=CODE`) that works on phones.

### Accessibility
- Skip link and landmark structure.
- ARIA roles, labels, `aria-selected`, `aria-live` announcements.
- Full keyboard navigation and visible focus rings.
- `prefers-reduced-motion` support plus a manual reduce-motion switch.
- High-contrast mode, large-text mode and dyslexia-friendly font mode.
- Alt-text fields for images; accessible reading order in document mode.
- In-app accessibility checker with pass/warn results.
- WCAG contrast checker for theme colours.
- Semantic headings in exported HTML.
- Print styles with A4 page rules.

### Privacy and ownership
- No account, no analytics, no network calls for editing.
- Projects autosave locally in the browser.
- Engagement data stays on the device unless you export it.
- Export to open formats (`.jdocs` JSON, `.pptx`, standalone HTML, ZIP) at any time.
- No lock-in: the project file is human-readable JSON.

---

## Keyboard shortcuts

| Action | Shortcut |
|---|---|
| Command palette | `Ctrl/⌘ K` |
| Save project | `Ctrl/⌘ S` |
| Open file | `Ctrl/⌘ O` |
| New presentation | `Ctrl/⌘ N` |
| New slide | `Ctrl/⌘ M` |
| Find and replace | `Ctrl/⌘ F` |
| Undo / redo | `Ctrl/⌘ Z` / `Ctrl/⌘ Y` |
| Duplicate | `Ctrl/⌘ D` |
| Copy / paste | `Ctrl/⌘ C` / `Ctrl/⌘ V` |
| Delete | `Delete` / `Backspace` |
| Nudge selection | Arrow keys |
| Next / previous object | `Tab` / `Shift Tab` |
| Start presentation | `F5` |
| Collapse ribbon | `Ctrl/⌘ F1` |
| Present: next | `→`, `↓`, `Space`, `Enter`, `Page Down` |
| Present: previous | `←`, `↑`, `Page Up`, `Backspace` |
| Present: black screen | `B` |
| Present: notes | `N` |
| Present: presenter view | `P` |
| Present: fullscreen | `F` |
| Present: exit | `Esc` |

---

## Project structure

```
j-docs/
├── index.html              app shell and overlay roots
├── css/
│   └── app.css             design system, editor, presenter, print, a11y modes
├── js/
│   ├── icons.js            inline SVG icon set
│   ├── store.js            project model, themes, layouts, history, autosave
│   ├── render.js           slide/element renderer (editor, thumbs, present, export)
│   ├── editor.js           ribbon, canvas, selection, inspector, shortcuts
│   ├── io.js               universal opener, OOXML/ODF parsers, PPTX/HTML export
│   ├── outputs.js          handouts, notes, summaries, teaching kit, print studio
│   ├── engage.js           polls, Q&A, word cloud, ratings, analytics
│   ├── present.js          slideshow, presenter view, transitions, rehearsal
│   └── app.js              modals, menus, command palette, galleries, ink, design tools
├── fonts/
│   ├── Selawik-Regular.woff
│   └── Selawik-Bold.woff
├── vendor/
│   ├── jszip.min.js
│   └── qrcode.js
└── samples/                test files used during QA
```

### Data model

```js
project = {
  version: 1,
  id, name, type: 'slides',
  theme: 'ember',
  aspect: '16:9',
  slides: [{
    id, layout, background, notes,
    transition: { type, duration, advance },
    animation: { type, duration, delay, start },
    elements: [{
      id, type, x, y, w, h, z, rotation,
      content, style, shape, src, alt, data, chartType, name, role
    }],
    ink: [{ color, width, points }],
    comments: []
  }],
  settings: { grid, guides, snap, showNotes, proofing, language },
  meta: { subject, keywords, company, description },
  fonts: []
}
```

Geometry is percentage-based (0–100), so slides scale from thumbnail to 4K without re-layout. Text uses container query units (`1cqw = 9.6pt` at a 960-unit-wide canvas), so type stays proportional at any size.

---

## Fonts and licensing

j-Docs uses **Selawik**, Microsoft's open-source, Segoe UI metric-compatible typeface, bundled as WOFF. It is licensed under the SIL Open Font License 1.1. The UI stack is:

```css
"Segoe UI", Selawik, system-ui, -apple-system, "Helvetica Neue", Arial, sans-serif
```

On Windows this resolves to Segoe UI; elsewhere it falls back to Selawik, which preserves the same metrics and visual rhythm. No proprietary Microsoft font files are included.

Third-party libraries: JSZip (MIT), qrcode-generator (MIT). See `LICENSES.txt` in any offline package.

---

## Browser support

- Chrome / Edge 105+
- Firefox 110+
- Safari 16.4+
- Mobile browsers with container query support

Requires JavaScript. No cookies. `localStorage` is used for autosave and preferences; `BroadcastChannel` is used for live engagement when available.

---

## QA checklist

Verified in Chromium during the build:

- App boots with all nine modules and no console errors.
- Demo deck renders 20 slides; text, shapes, tables and charts visible.
- Presenter view renders current slide, next slide, notes, timer and engagement.
- Keyboard next/previous/exit works; progress and counter update.
- PPTX export produces a valid ZIP with `[Content_Types].xml`, presentation parts and slide relationships.
- Standalone HTML export opens and navigates all slides.
- Offline package builds successfully.
- PPTX, DOCX, XLSX, PDF, Markdown, CSV, SVG and unknown binary files all open.
- Every dialog (38 tested) opens without throwing.
- Handouts, notes, summaries, teaching kit, lesson plan, quiz, readability, print studio and document mode generate content.
- Analytics dashboard renders with sample poll, word, rating and Q&A data.

---

## Roadmap ideas

- Real-time co-editing with CRDTs and optional self-hosted sync.
- Native `.pptx` write-back for edits made to imported decks.
- AI-assisted layout repair and alt-text generation using an on-device model.
- LMS export (SCORM/xAPI) for teaching kits.
- Signed offline packages and verifiable timestamps.
- Plugin API for custom output generators.

---

**j-Docs** — because the deck should not be the end of the content.
