#!/usr/bin/env node
/**
 * j-Docs Relay — zero-dependency multiplayer server.
 *
 *   node server/relay.js            # http://localhost:8787
 *   PORT=9000 node server/relay.js  # custom port
 *
 * What it does
 *   1. Serves the static j-Docs app (so phones can open the same URL).
 *   2. Speaks WebSocket (RFC 6455) on /ws with no npm packages.
 *   3. Keeps rooms in memory + on disk (server/data/rooms.json).
 *   4. Relays co-editing patches, presence, cursors and audience responses.
 *
 * Protocol (JSON text frames)
 *   client -> server : hello, ping, rename, project, slide, cursor, engage, engageState
 *   server -> client : welcome, presence, project, slide, cursor, engage, engageState, pong, error
 *
 * Rooms are ephemeral collaboration spaces keyed by a 6-character code.
 * Nothing is uploaded anywhere: this process is the only server involved.
 */

'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = Number(process.env.PORT || 8787);
const ROOT = path.resolve(__dirname, '..');
const DATA_DIR = path.join(__dirname, 'data');
const DATA_FILE = path.join(DATA_DIR, 'rooms.json');
const MAX_ROOM_BYTES = 24 * 1024 * 1024; // 24 MB of project JSON per room
const MAX_PEERS_PER_ROOM = 80;
const ROOM_TTL_MS = 1000 * 60 * 60 * 12; // forget quiet rooms after 12h
const SAVE_DEBOUNCE_MS = 800;

/* ------------------------------------------------------------------ *
 * Static file serving
 * ------------------------------------------------------------------ */

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.htm': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.map': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
  '.otf': 'font/otf',
  '.txt': 'text/plain; charset=utf-8',
  '.md': 'text/markdown; charset=utf-8',
  '.csv': 'text/csv; charset=utf-8',
  '.pdf': 'application/pdf',
  '.pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  '.mp4': 'video/mp4',
  '.webm': 'video/webm',
  '.mp3': 'audio/mpeg',
  '.wav': 'audio/wav',
  '.zip': 'application/zip',
  '.apk': 'application/vnd.android.package-archive',
  '.jdocs': 'application/json; charset=utf-8'
};

function safeJoin(root, urlPath) {
  const decoded = decodeURIComponent(urlPath.split('?')[0].split('#')[0]);
  const clean = path.normalize(decoded).replace(/^(\.\.[/\\])+/, '');
  const full = path.join(root, clean);
  return full.startsWith(root) ? full : root;
}

function serveStatic(req, res) {
  let rel = decodeURIComponent(req.url.split('?')[0]);
  if (rel === '/' || rel === '') rel = '/index.html';

  let file = safeJoin(ROOT, rel);
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) {
      // SPA fallback: unknown paths get the app shell.
      file = path.join(ROOT, 'index.html');
      fs.stat(file, (e2, st2) => {
        if (e2 || !st2.isFile()) return notFound(res);
        sendFile(res, file, st2);
      });
      return;
    }
    sendFile(res, file, st);
  });
}

function sendFile(res, file, st) {
  const ext = path.extname(file).toLowerCase();
  const type = MIME[ext] || 'application/octet-stream';
  const etag = '"' + st.size.toString(16) + '-' + st.mtimeMs.toString(16) + '"';
  const headers = {
    'Content-Type': type,
    'Content-Length': st.size,
    ETag: etag,
    'Cache-Control': ext === '.html' ? 'no-cache' : 'public, max-age=300',
    'X-Content-Type-Options': 'nosniff'
  };
  res.writeHead(200, headers);
  if (res.req && res.req.method === 'HEAD') return res.end();
  fs.createReadStream(file).pipe(res);
}

function notFound(res) {
  res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
  res.end('Not found');
}

/* ------------------------------------------------------------------ *
 * Room registry
 * ------------------------------------------------------------------ */

/** @type {Map<string, Room>} */
const rooms = new Map();
let saveTimer = null;
let dirty = false;

function room(code) {
  let r = rooms.get(code);
  if (!r) {
    r = {
      code,
      project: null,
      engage: null,
      peers: new Map(),
      seq: 0,
      createdAt: Date.now(),
      savedAt: 0,
      touchedAt: Date.now()
    };
    rooms.set(code, r);
  }
  return r;
}

function totalPeers() {
  let n = 0;
  for (const r of rooms.values()) n += r.peers.size;
  return n;
}

function peerList(r) {
  const out = [];
  for (const p of r.peers.values()) {
    out.push({ id: p.id, name: p.name, color: p.color, role: p.role, slide: p.slide, at: p.at });
  }
  return out;
}

function loadRooms() {
  try {
    if (!fs.existsSync(DATA_FILE)) return;
    const raw = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
    const now = Date.now();
    for (const code of Object.keys(raw || {})) {
      const src = raw[code];
      if (!src || typeof src !== 'object') continue;
      if (src.touchedAt && now - src.touchedAt > ROOM_TTL_MS) continue;
      const r = room(code);
      r.project = src.project || null;
      r.engage = src.engage || null;
      r.seq = src.seq || 0;
      r.createdAt = src.createdAt || now;
      r.savedAt = src.savedAt || 0;
      r.touchedAt = src.touchedAt || now;
    }
    const n = rooms.size;
    if (n) log('restored ' + n + ' room' + (n === 1 ? '' : 's') + ' from disk');
  } catch (err) {
    log('could not read rooms.json: ' + err.message);
  }
}

function scheduleSave() {
  dirty = true;
  if (saveTimer) return;
  saveTimer = setTimeout(() => {
    saveTimer = null;
    flush();
  }, SAVE_DEBOUNCE_MS);
  if (saveTimer.unref) saveTimer.unref();
}

function flush() {
  if (!dirty) return;
  dirty = false;
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    const out = {};
    for (const [code, r] of rooms) {
      if (!r.project && !r.engage) continue;
      out[code] = {
        code,
        project: r.project,
        engage: r.engage,
        seq: r.seq,
        createdAt: r.createdAt,
        savedAt: Date.now(),
        touchedAt: r.touchedAt
      };
    }
    const tmp = DATA_FILE + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(out));
    fs.renameSync(tmp, DATA_FILE);
  } catch (err) {
    log('save failed: ' + err.message);
  }
}

function sweepRooms() {
  const now = Date.now();
  for (const [code, r] of rooms) {
    if (r.peers.size === 0 && now - r.touchedAt > ROOM_TTL_MS) {
      rooms.delete(code);
      dirty = true;
    }
  }
  if (dirty) scheduleSave();
}

/* ------------------------------------------------------------------ *
 * WebSocket framing (RFC 6455), hand-rolled
 * ------------------------------------------------------------------ */

const WS_GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';

function wsAccept(key) {
  return crypto.createHash('sha1').update(key + WS_GUID).digest('base64');
}

function wsFrame(opcode, payload) {
  const len = payload.length;
  let header;
  if (len < 126) {
    header = Buffer.alloc(2);
    header[0] = 0x80 | opcode;
    header[1] = len;
  } else if (len < 65536) {
    header = Buffer.alloc(4);
    header[0] = 0x80 | opcode;
    header[1] = 126;
    header.writeUInt16BE(len, 2);
  } else {
    header = Buffer.alloc(10);
    header[0] = 0x80 | opcode;
    header[1] = 127;
    header.writeBigUInt64BE(BigInt(len), 2);
  }
  return Buffer.concat([header, payload]);
}

function wsSend(peer, obj) {
  if (!peer || peer.socket.destroyed) return;
  const text = typeof obj === 'string' ? obj : JSON.stringify(obj);
  const payload = Buffer.from(text, 'utf8');
  try {
    peer.socket.write(wsFrame(0x1, payload));
  } catch (err) {
    wsClose(peer, 1011, 'write failed');
  }
}

function wsPing(peer) {
  if (!peer || peer.socket.destroyed) return;
  try {
    peer.socket.write(wsFrame(0x9, Buffer.alloc(0)));
  } catch (_) {
    /* ignore */
  }
}

function wsClose(peer, code, reason) {
  if (!peer || peer.closed) return;
  peer.closed = true;
  try {
    const body = Buffer.alloc(2 + Buffer.byteLength(reason || ''));
    body.writeUInt16BE(code || 1000, 0);
    if (reason) body.write(reason, 2);
    peer.socket.write(wsFrame(0x8, body));
  } catch (_) {
    /* ignore */
  }
  try {
    peer.socket.end();
  } catch (_) {
    /* ignore */
  }
}

/* ------------------------------------------------------------------ *
 * Peer handling
 * ------------------------------------------------------------------ */

const NAMES = ['Ada', 'Grace', 'Linus', 'Katherine', 'Alan', 'Radia', 'Dennis', 'Margaret', 'Tim', 'Barbara', 'Guido', 'Anita'];
const COLORS = ['#2f6fed', '#e8590c', '#0f9d58', '#a142f4', '#d6336c', '#0b7285', '#5f3dc4', '#b8860b'];

let peerSeq = 0;

function newPeerId() {
  peerSeq += 1;
  return 'p' + Date.now().toString(36) + peerSeq.toString(36);
}

function parseQuery(url) {
  const q = url.indexOf('?');
  const out = {};
  if (q < 0) return out;
  for (const part of url.slice(q + 1).split('&')) {
    if (!part) continue;
    const i = part.indexOf('=');
    const k = i < 0 ? part : part.slice(0, i);
    const v = i < 0 ? '' : part.slice(i + 1);
    try {
      out[decodeURIComponent(k)] = decodeURIComponent(v.replace(/\+/g, ' '));
    } catch (_) {
      out[k] = v;
    }
  }
  return out;
}

function sanitizeName(name, fallback) {
  const n = String(name || '').replace(/[\u0000-\u001f<>]/g, '').trim().slice(0, 32);
  return n || fallback;
}

/** Message types that only editors may see. Audience phones get polls, never the deck. */
const EDITOR_ONLY = new Set(['project', 'slide', 'cursor']);

function broadcast(r, obj, exceptId) {
  const editorOnly = EDITOR_ONLY.has(obj.t);
  for (const p of r.peers.values()) {
    if (p.id === exceptId) continue;
    if (editorOnly && p.role === 'audience') continue;
    wsSend(p, obj);
  }
}

function presence(r) {
  broadcast(r, { t: 'presence', peers: peerList(r) });
}

function joinRoom(peer, code) {
  const r = room(code);
  if (r.peers.size >= MAX_PEERS_PER_ROOM) {
    wsSend(peer, { t: 'error', message: 'This room is full (' + MAX_PEERS_PER_ROOM + ' people).' });
    wsClose(peer, 1013, 'room full');
    return null;
  }
  peer.room = code;
  peer.joinedAt = Date.now();
  r.peers.set(peer.id, peer);
  r.touchedAt = Date.now();

  wsSend(peer, {
    t: 'welcome',
    id: peer.id,
    room: code,
    role: peer.role,
    seq: r.seq,
    project: peer.role === 'audience' ? null : r.project,
    engage: r.engage,
    peers: peerList(r),
    serverTime: Date.now()
  });

  broadcast(r, { t: 'peer-join', peer: { id: peer.id, name: peer.name, color: peer.color, role: peer.role, slide: peer.slide } }, peer.id);
  presence(r);
  log('+' + peer.name + ' (' + peer.role + ') joined ' + code + ' — ' + r.peers.size + ' in room');
  return r;
}

function leaveRoom(peer) {
  if (!peer.room) return;
  const r = rooms.get(peer.room);
  if (!r) return;
  r.peers.delete(peer.id);
  r.touchedAt = Date.now();
  broadcast(r, { t: 'peer-leave', id: peer.id });
  presence(r);
  log('-' + peer.name + ' left ' + r.code + ' — ' + r.peers.size + ' in room');
  if (r.peers.size === 0) scheduleSave();
}

function handleMessage(peer, msg) {
  if (!msg || typeof msg !== 'object') return;
  const r = peer.room ? rooms.get(peer.room) : null;
  if (!r) return;
  r.touchedAt = Date.now();

  switch (msg.t) {
    case 'ping':
      wsSend(peer, { t: 'pong', at: Date.now(), seq: r.seq });
      break;

    case 'rename': {
      peer.name = sanitizeName(msg.name, peer.name);
      if (typeof msg.color === 'string' && /^#[0-9a-f]{3,8}$/i.test(msg.color)) peer.color = msg.color;
      presence(r);
      break;
    }

    case 'project': {
      if (peer.role === 'audience') return deny(peer, 'Audience members cannot edit the deck.');
      const json = JSON.stringify(msg.project || null);
      if (json.length > MAX_ROOM_BYTES) return deny(peer, 'Deck is too large for live sync (' + Math.round(json.length / 1048576) + ' MB).');
      r.project = msg.project || null;
      r.seq += 1;
      broadcast(r, { t: 'project', project: r.project, seq: r.seq, from: peer.id, at: Date.now() }, peer.id);
      scheduleSave();
      break;
    }

    case 'slide': {
      if (peer.role === 'audience') return deny(peer, 'Audience members cannot edit the deck.');
      const idx = Number(msg.index);
      if (!Number.isFinite(idx)) return;
      peer.slide = idx;
      broadcast(r, { t: 'slide', index: idx, from: peer.id }, peer.id);
      break;
    }

    case 'cursor': {
      if (peer.role === 'audience') return;
      const x = Number(msg.x);
      const y = Number(msg.y);
      if (!Number.isFinite(x) || !Number.isFinite(y)) return;
      peer.cursor = { x: Math.max(0, Math.min(100, x)), y: Math.max(0, Math.min(100, y)), slide: Number(msg.slide) || 0 };
      broadcast(r, { t: 'cursor', id: peer.id, name: peer.name, color: peer.color, x: peer.cursor.x, y: peer.cursor.y, slide: peer.cursor.slide }, peer.id);
      break;
    }

    case 'engage': {
      // A single audience response. Editors receive it; the room keeps it.
      const item = msg.item;
      if (!item || typeof item !== 'object') return;
      if (!r.engage) r.engage = { code: r.code, responses: [], polls: [], questions: [], words: [], ratings: [] };
      if (!Array.isArray(r.engage.responses)) r.engage.responses = [];
      const entry = Object.assign({}, item, {
        id: item.id || 'r' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
        at: item.at || Date.now(),
        from: peer.id,
        by: peer.name,
        anonymous: true
      });
      r.engage.responses.push(entry);
      if (r.engage.responses.length > 5000) r.engage.responses.splice(0, r.engage.responses.length - 5000);
      broadcast(r, { t: 'engage', item: entry }, peer.id);
      scheduleSave();
      break;
    }

    case 'engageState': {
      if (peer.role === 'audience') return deny(peer, 'Only the presenter can change polls.');
      r.engage = msg.engage || null;
      broadcast(r, { t: 'engageState', engage: r.engage, from: peer.id }, peer.id);
      scheduleSave();
      break;
    }

    case 'hello': {
      peer.name = sanitizeName(msg.name, peer.name);
      if (typeof msg.color === 'string' && /^#[0-9a-f]{3,8}$/i.test(msg.color)) peer.color = msg.color;
      presence(r);
      break;
    }

    default:
      break;
  }
}

function deny(peer, message) {
  wsSend(peer, { t: 'error', message });
}

/* ------------------------------------------------------------------ *
 * HTTP + upgrade
 * ------------------------------------------------------------------ */

const server = http.createServer((req, res) => {
  if (req.url === '/health' || req.url.startsWith('/health?')) {
    const body = JSON.stringify({
      ok: true,
      service: 'j-docs-relay',
      version: '1.0.0',
      rooms: rooms.size,
      peers: totalPeers(),
      uptime: Math.round(process.uptime()),
      now: Date.now()
    });
    res.writeHead(200, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store', 'Access-Control-Allow-Origin': '*' });
    return res.end(body);
  }

  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET,HEAD,OPTIONS',
      'Access-Control-Allow-Headers': '*'
    });
    return res.end();
  }

  if (req.method !== 'GET' && req.method !== 'HEAD') {
    res.writeHead(405, { 'Content-Type': 'text/plain' });
    return res.end('Method not allowed');
  }

  serveStatic(req, res);
});

server.on('upgrade', (req, socket) => {
  const url = req.url || '/';
  const pathname = url.split('?')[0];
  if (pathname !== '/ws' && pathname !== '/socket') {
    socket.write('HTTP/1.1 404 Not Found\r\nConnection: close\r\n\r\n');
    return socket.destroy();
  }

  const key = req.headers['sec-websocket-key'];
  const version = req.headers['sec-websocket-version'];
  if (!key || String(version) !== '13') {
    socket.write('HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n');
    return socket.destroy();
  }

  socket.write(
    'HTTP/1.1 101 Switching Protocols\r\n' +
      'Upgrade: websocket\r\n' +
      'Connection: Upgrade\r\n' +
      'Sec-WebSocket-Accept: ' + wsAccept(key) + '\r\n' +
      '\r\n'
  );
  socket.setNoDelay(true);
  socket.setKeepAlive(true, 30000);

  const q = parseQuery(url);
  const code = String(q.room || q.r || 'LOBBY').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 12) || 'LOBBY';
  const role = q.role === 'audience' ? 'audience' : 'editor';
  const idx = Number(q.index) || 0;

  const peer = {
    id: newPeerId(),
    name: sanitizeName(q.name, NAMES[Math.floor(Math.random() * NAMES.length)]),
    color: /^#[0-9a-f]{3,8}$/i.test(q.color || '') ? q.color : COLORS[Math.floor(Math.random() * COLORS.length)],
    role,
    slide: idx,
    socket,
    room: null,
    buffer: Buffer.alloc(0),
    closed: false,
    lastSeen: Date.now(),
    cursor: null
  };

  joinRoom(peer, code);

  let fragmented = null;
  let fragOpcode = 0;

  socket.on('data', (chunk) => {
    peer.buffer = Buffer.concat([peer.buffer, chunk]);
    peer.lastSeen = Date.now();

    while (peer.buffer.length >= 2) {
      const b0 = peer.buffer[0];
      const b1 = peer.buffer[1];
      const fin = (b0 & 0x80) !== 0;
      const opcode = b0 & 0x0f;
      const masked = (b1 & 0x80) !== 0;
      let len = b1 & 0x7f;
      let offset = 2;

      if (len === 126) {
        if (peer.buffer.length < offset + 2) return;
        len = peer.buffer.readUInt16BE(offset);
        offset += 2;
      } else if (len === 127) {
        if (peer.buffer.length < offset + 8) return;
        const big = peer.buffer.readBigUInt64BE(offset);
        if (big > BigInt(64 * 1024 * 1024)) {
          wsClose(peer, 1009, 'frame too large');
          return;
        }
        len = Number(big);
        offset += 8;
      }

      let mask = null;
      if (masked) {
        if (peer.buffer.length < offset + 4) return;
        mask = peer.buffer.slice(offset, offset + 4);
        offset += 4;
      }

      if (peer.buffer.length < offset + len) return;

      let payload = peer.buffer.slice(offset, offset + len);
      peer.buffer = peer.buffer.slice(offset + len);

      if (mask) {
        payload = Buffer.from(payload);
        for (let i = 0; i < payload.length; i++) payload[i] ^= mask[i & 3];
      }

      if (opcode === 0x8) {
        // close
        leaveRoom(peer);
        wsClose(peer, 1000, 'bye');
        return;
      } else if (opcode === 0x9) {
        // ping -> pong
        try {
          socket.write(wsFrame(0xa, payload));
        } catch (_) {
          /* ignore */
        }
        continue;
      } else if (opcode === 0xa) {
        // pong
        continue;
      } else if (opcode === 0x0) {
        // continuation
        if (fragmented) {
          fragmented = Buffer.concat([fragmented, payload]);
          if (fin) {
            const full = fragmented;
            fragmented = null;
            if (fragOpcode === 0x1) dispatch(peer, full);
          }
        }
        continue;
      } else if (opcode === 0x1 || opcode === 0x2) {
        if (!fin) {
          fragmented = payload;
          fragOpcode = opcode;
          continue;
        }
        if (opcode === 0x1) dispatch(peer, payload);
        continue;
      }
    }
  });

  function dispatch(p, buf) {
    let msg;
    try {
      msg = JSON.parse(buf.toString('utf8'));
    } catch (_) {
      return;
    }
    try {
      handleMessage(p, msg);
    } catch (err) {
      log('message error: ' + err.message);
    }
  }

  socket.on('error', () => {
    leaveRoom(peer);
    peer.closed = true;
  });

  socket.on('close', () => {
    leaveRoom(peer);
    peer.closed = true;
  });
});

/* Keepalive: ping every 30s, drop peers silent for 90s. */
setInterval(() => {
  const now = Date.now();
  for (const r of rooms.values()) {
    for (const p of r.peers.values()) {
      if (now - p.lastSeen > 90000) {
        leaveRoom(p);
        wsClose(p, 1001, 'timeout');
        try {
          p.socket.destroy();
        } catch (_) {
          /* ignore */
        }
        continue;
      }
      wsPing(p);
    }
  }
}, 30000).unref();

setInterval(sweepRooms, 60000).unref();

/* ------------------------------------------------------------------ *
 * Boot
 * ------------------------------------------------------------------ */

function log(msg) {
  const t = new Date().toISOString().slice(11, 19);
  console.log('[' + t + '] ' + msg);
}

loadRooms();

server.listen(PORT, () => {
  const n = rooms.size;
  console.log('');
  console.log('  j-Docs Relay  ·  multiplayer for j-Docs');
  console.log('  ------------------------------------------------');
  console.log('  App      http://localhost:' + PORT + '/');
  console.log('  Socket   ws://localhost:' + PORT + '/ws?room=CODE&role=editor');
  console.log('  Health   http://localhost:' + PORT + '/health');
  console.log('  Rooms    ' + n + ' restored  ·  data in server/data/rooms.json');
  console.log('');
  console.log('  Share the LAN address (e.g. http://192.168.x.x:' + PORT + '/)');
  console.log('  so phones on the same Wi-Fi can join a room by code.');
  console.log('');
});

process.on('SIGINT', () => {
  log('shutting down, saving rooms');
  flush();
  process.exit(0);
});
process.on('SIGTERM', () => {
  flush();
  process.exit(0);
});
