/* j-Docs outputs: handouts, notes, summaries, teaching kits, quizzes, offline packages */
(function(){
  const JD=window.JD;
  const {Store, themeById, esc, strip, words, download, today, fmtBytes} = JD;
  const $=(s,r=document)=>r.querySelector(s);
  const icon=n=>window.jIcon?window.jIcon(n,{size:16}):'';
  const R=()=>window.JDRender;

  const PRINT_CSS=`
  *{box-sizing:border-box}
  body{margin:0;background:#f3f2f1;font-family:"Segoe UI",Selawik,system-ui,sans-serif;color:#111}
  .sheet{background:#fff;margin:0 auto 14px;box-shadow:0 3px 14px rgba(0,0,0,.14);position:relative;box-sizing:border-box}
  .handout-page{padding:10mm}
  .handout-page .hp-head{display:flex;justify-content:space-between;align-items:center;font-size:7pt;color:#666;border-bottom:.5pt solid #ddd;padding-bottom:3mm;margin-bottom:4mm}
  .handout-grid{display:grid;gap:4mm}
  .handout-cell{position:relative}
  .handout-slide{width:100%;aspect-ratio:16/9;position:relative;overflow:hidden;border:.5pt solid #ddd;background:#fff;container-type:size}
  .handout-slide .slide-canvas{width:100%;height:100%;position:relative;overflow:hidden;container-type:size}
  .handout-num{position:absolute;right:1mm;bottom:1mm;font-size:6pt;color:#888}
  .handout-lines{display:flex;flex-direction:column;gap:3.2mm;margin-top:3mm}
  .handout-lines i{display:block;border-bottom:.4pt solid #d0d0d0;height:0}
  .handout-page .hp-foot{position:absolute;left:10mm;right:10mm;bottom:6mm;display:flex;justify-content:space-between;font-size:6.5pt;color:#888;border-top:.5pt solid #ddd;padding-top:2mm}
  .notes-page{padding:12mm}
  .notes-page .np-head{display:flex;justify-content:space-between;font-size:8pt;color:#666;border-bottom:.5pt solid #ccc;padding-bottom:2mm;margin-bottom:4mm}
  .notes-page .np-slide{width:62%;aspect-ratio:16/9;border:.5pt solid #ccc;overflow:hidden;margin-bottom:4mm;container-type:size;position:relative}
  .notes-page .np-notes{font-size:9pt;line-height:1.7;white-space:pre-wrap;min-height:40mm}
  .notes-page .np-lines{display:flex;flex-direction:column;gap:4mm;margin-top:4mm}
  .notes-page .np-lines i{border-bottom:.4pt solid #d0d0d0;height:0}
  .summary-doc{padding:14mm;max-width:820px;font-size:10pt;line-height:1.55}
  .summary-doc h1{font-size:20pt;margin:0 0 2mm;letter-spacing:-.5pt}
  .summary-doc h2{font-size:12pt;margin:6mm 0 2mm;color:#c43e1c;border-bottom:.5pt solid #eee;padding-bottom:1mm}
  .summary-doc h3{font-size:10pt;margin:4mm 0 1mm}
  .summary-doc p{margin:0 0 2.5mm}
  .summary-doc ul{margin:0 0 3mm 5mm;padding:0}
  .summary-doc li{margin-bottom:1.2mm}
  .summary-doc .meta{font-size:8pt;color:#777;margin-bottom:6mm}
  .summary-doc .kpis{display:flex;gap:3mm;margin:4mm 0}
  .summary-doc .kpi{flex:1;border:.5pt solid #ddd;border-radius:2mm;padding:3mm}
  .summary-doc .kpi b{display:block;font-size:16pt;color:#c43e1c}
  .summary-doc .kpi span{font-size:7pt;color:#777;text-transform:uppercase}
  .summary-doc .callout{background:#fdf2ee;border-left:3pt solid #c43e1c;padding:3mm;margin:3mm 0;font-size:9pt}
  .summary-doc table{width:100%;border-collapse:collapse;font-size:9pt;margin:3mm 0}
  .summary-doc th,.summary-doc td{border:.5pt solid #ddd;padding:1.6mm 2mm;text-align:left;vertical-align:top}
  .summary-doc th{background:#faf7f5}
  .el{position:absolute}
  .txt{width:100%;height:100%;overflow:hidden;word-wrap:break-word}
  .txt p{margin:0 0 .55em}.txt ul,.txt ol{margin:0 0 .55em;padding-left:1.2em}.txt li{margin:0 0 .25em}
  .txt h1,.txt h2,.txt h3{margin:0 0 .4em}
  table{border-collapse:collapse;width:100%;height:100%}td,th{padding:.35em .5em;border:1px solid rgba(0,0,0,.15);text-align:left}
  .media-ph{display:grid;place-items:center;height:100%;background:rgba(0,0,0,.06);font-size:12px}
  @page{size:A4;margin:0}
  @media print{body{background:#fff}.sheet{box-shadow:none;margin:0;page-break-after:always;break-after:page}.sheet:last-child{page-break-after:auto;break-after:auto}}
  `;

  function pageDoc(title,inner){
    return `<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)}</title><style>${PRINT_CSS}</style></head><body>${inner}</body></html>`;
  }
  function printInner(inner){
    const root=$('#printRoot');
    root.innerHTML=`<style>${PRINT_CSS}</style>${inner}`;
    setTimeout(()=>window.print(),60);
  }
  function toast(m,t){ window.JDApp?.toast?.(m,t); }
  function modal(opts){ return window.JDApp.modal(opts); }

  const outline=()=>Store.outline();
  const slideHTML=(s)=>R().slideToHTML(s,themeById(Store.project.theme));

  /* ---------- handouts ---------- */
  function handoutInner(o={}){
    const per=o.per||2, lines=o.lines!==false, head=o.header!==false, foot=o.footer!==false;
    const slides=Store.project.slides;
    const cols=per===1?1:per===2?1:per===3?1:per===4?2:3;
    const pages=[];
    for(let i=0;i<slides.length;i+=per) pages.push(slides.slice(i,i+per));
    return pages.map((group,pi)=>{
      const cells=group.map((s,gi)=>{
        const idx=pi*per+gi;
        return `<div class="handout-cell"><div class="handout-slide">${slideHTML(s)}<span class="handout-num">${idx+1}</span></div>${lines?`<div class="handout-lines">${'<i></i>'.repeat(o.lineCount||3)}</div>`:''}</div>`;
      }).join('');
      return `<section class="sheet handout-page" style="width:${o.landscape?'297mm':'210mm'};min-height:${o.landscape?'210mm':'297mm'}">
        ${head?`<div class="hp-head"><span>${esc(Store.project.name)}</span><span>Handout · ${per} per page</span></div>`:''}
        <div class="handout-grid" style="grid-template-columns:repeat(${cols},1fr)">${cells}</div>
        ${foot?`<div class="hp-foot"><span>j-Docs · one project, every surface</span><span>${pi+1} / ${pages.length}</span></div>`:''}
      </section>`;
    }).join('');
  }
  function handouts(){
    const state={per:2,lines:true,header:true,footer:true,landscape:false,lineCount:3};
    modal({
      title:'Handouts', sub:'Print-ready handouts with slide thumbnails, writing lines and optional speaker cues.',
      wide:true,
      body:`<div class="row wrap" style="gap:10px;margin-bottom:12px">
        <label class="field"><span>Slides per page</span><select id="ho-per">${[1,2,3,4,6].map(n=>`<option value="${n}" ${n===2?'selected':''}>${n} per page</option>`).join('')}</select></label>
        <label class="field"><span>Writing lines</span><select id="ho-lines"><option value="3" selected>3 lines</option><option value="4">4 lines</option><option value="5">5 lines</option><option value="0">None</option></select></label>
        <label class="check"><input type="checkbox" id="ho-head" checked> Header</label>
        <label class="check"><input type="checkbox" id="ho-foot" checked> Footer</label>
        <label class="check"><input type="checkbox" id="ho-land"> Landscape</label>
      </div>
      <div class="handout-preview" id="ho-preview"></div>`,
      footer:`<span class="muted" style="font-size:11px">A4 · print or save as PDF</span><div class="modal-foot-right"><button class="btn btn-ghost" id="ho-dl">${icon('download')} Download HTML</button><button class="btn btn-primary" id="ho-print">${icon('print')} Print / PDF</button></div>`,
      onMount:(el)=>{
        const render=()=>{
          state.per=Number($('#ho-per',el).value); state.lineCount=Number($('#ho-lines',el).value); state.lines=state.lineCount>0;
          state.header=$('#ho-head',el).checked; state.footer=$('#ho-foot',el).checked; state.landscape=$('#ho-land',el).checked;
          $('#ho-preview',el).innerHTML=handoutInner(state);
        };
        el.querySelectorAll('select,input').forEach(x=>x.addEventListener('change',render));
        render();
        $('#ho-print',el).addEventListener('click',()=>printInner(handoutInner(state)));
        $('#ho-dl',el).addEventListener('click',()=>download(new Blob([pageDoc(Store.project.name+' — Handout',handoutInner(state))],{type:'text/html'}),'handout-'+JDIO.safeName(Store.project.name)+'.html'));
      }
    });
  }

  /* ---------- notes pages ---------- */
  function notesInner(o={}){
    return Store.project.slides.map((s,i)=>`<section class="sheet notes-page" style="width:210mm;min-height:297mm">
      <div class="np-head"><span>${esc(Store.project.name)}</span><span>Speaker notes · Slide ${i+1} of ${Store.project.slides.length}</span></div>
      <div class="np-slide">${slideHTML(s)}</div>
      <div class="np-notes">${esc(s.notes||'No speaker notes for this slide. Add notes in the Notes panel to build a printable script.')}</div>
      ${o.lines!==false?`<div class="np-lines">${'<i></i>'.repeat(o.lineCount||6)}</div>`:''}
    </section>`).join('');
  }
  function notesPages(){
    const state={lines:true,lineCount:6};
    modal({
      title:'Notes pages', sub:'A printable script: slide image, speaker notes and ruled space for handwritten cues.',
      wide:true,
      body:`<div class="row wrap" style="gap:10px;margin-bottom:12px">
        <label class="field"><span>Ruled lines</span><select id="np-lines"><option value="4">4</option><option value="6" selected>6</option><option value="8">8</option><option value="0">None</option></select></label>
        <span class="muted" style="font-size:11px;align-self:flex-end">${Store.project.slides.length} pages</span>
      </div><div class="handout-preview" id="np-preview"></div>`,
      footer:`<span class="muted" style="font-size:11px">A4 portrait</span><div class="modal-foot-right"><button class="btn btn-ghost" id="np-dl">${icon('download')} Download HTML</button><button class="btn btn-primary" id="np-print">${icon('print')} Print / PDF</button></div>`,
      onMount:el=>{
        const render=()=>{ state.lineCount=Number($('#np-lines',el).value); state.lines=state.lineCount>0; $('#np-preview',el).innerHTML=notesInner(state); };
        $('#np-lines',el).addEventListener('change',render); render();
        $('#np-print',el).addEventListener('click',()=>printInner(notesInner(state)));
        $('#np-dl',el).addEventListener('click',()=>download(new Blob([pageDoc(Store.project.name+' — Notes',notesInner(state))],{type:'text/html'}),'notes-'+JDIO.safeName(Store.project.name)+'.html'));
      }
    });
  }

  /* ---------- summaries ---------- */
  function summaryInner(o={}){
    const rows=outline();
    const total=Store.stats();
    const body=rows.map(r=>{
      const bullets=r.points.slice(0,8).map(p=>`<li>${esc(p)}</li>`).join('');
      return `<h2>${r.index+1}. ${esc(r.title)}</h2>${bullets?`<ul>${bullets}</ul>`:'<p class="muted">No bullet points on this slide.</p>'}${r.notes&&o.notes!==false?`<p><em>Speaker note:</em> ${esc(r.notes.slice(0,400))}</p>`:''}`;
    }).join('');
    return `<section class="sheet summary-doc" style="width:210mm;min-height:297mm">
      <h1>${esc(Store.project.name)}</h1>
      <div class="meta">Slide summary · ${total.slides} slides · ${total.words} words · ${total.reading} min read · generated ${today()}</div>
      <div class="kpis"><div class="kpi"><b>${total.slides}</b><span>Slides</span></div><div class="kpi"><b>${total.words}</b><span>Words</span></div><div class="kpi"><b>${total.reading}m</b><span>Read time</span></div></div>
      ${body}
      <p style="margin-top:8mm;font-size:8pt;color:#888">Generated by j-Docs · the same project is a live presentation, a document, a teaching resource and a web experience.</p>
    </section>`;
  }
  function summaries(){
    modal({
      title:'Slide summaries', sub:'Every slide condensed into a readable outline you can share, print or paste into a brief.',
      wide:true,
      body:`<div class="handout-preview" id="sum-preview">${summaryInner()}</div>`,
      footer:`<span class="muted" style="font-size:11px">${Store.project.slides.length} slides</span><div class="modal-foot-right"><button class="btn btn-ghost" id="sum-dl">${icon('download')} Download HTML</button><button class="btn btn-primary" id="sum-print">${icon('print')} Print / PDF</button></div>`,
      onMount:el=>{
        $('#sum-print',el).addEventListener('click',()=>printInner(summaryInner()));
        $('#sum-dl',el).addEventListener('click',()=>download(new Blob([pageDoc(Store.project.name+' — Summary',summaryInner())],{type:'text/html'}),'summary-'+JDIO.safeName(Store.project.name)+'.html'));
      }
    });
  }

  /* ---------- executive summary ---------- */
  function keyPoints(){
    const rows=outline(); const pts=[];
    rows.forEach(r=>r.points.forEach(p=>{ if(p.length>18&&p.length<220) pts.push({slide:r.index+1,title:r.title,text:p}); }));
    return pts;
  }
  function kpis(){
    const out=[]; const rows=outline();
    rows.forEach(r=>{
      const s=r.slide;
      s.elements.filter(e=>e.type==='text').forEach(e=>{
        const t=strip(e.content);
        const m=t.match(/(?:^|\s)([$€£]?\d[\d,.]*\s?(?:%|k|m|bn|x)?)/i);
        if(m&&t.length<40) out.push({value:m[1].trim(),label:r.title});
      });
    });
    return out.slice(0,4);
  }
  function execInner(){
    const rows=outline(), total=Store.stats();
    const kp=keyPoints();
    const messages=kp.slice(0,6);
    const decisions=rows.filter(r=>/decision|next step|action|recommend|ask|approve|timeline/i.test(r.title+' '+r.points.join(' '))).slice(0,6);
    const questions=rows.filter(r=>/\?$/.test(r.title)).slice(0,6);
    return `<section class="sheet summary-doc" style="width:210mm;min-height:297mm">
      <h1>Executive summary</h1>
      <div class="meta">${esc(Store.project.name)} · prepared ${today()} · ${total.slides} slides</div>
      <div class="callout"><strong>The one-line version.</strong> ${esc(rows[0]?.title||Store.project.name)} — ${esc((rows[1]?.points||[])[0]||'A concise walkthrough of the idea, the evidence and the next decision.')}</div>
      <div class="kpis">${(kpis().length?kpis():[{value:total.slides,label:'Slides'},{value:total.words,label:'Words'},{value:total.reading+'m',label:'Read time'}]).map(k=>`<div class="kpi"><b>${esc(k.value)}</b><span>${esc(k.label)}</span></div>`).join('')}</div>
      <h2>Key messages</h2><ul>${messages.map(m=>`<li><strong>${esc(m.title)}:</strong> ${esc(m.text)}</li>`).join('')||'<li>Add bullet points to generate key messages.</li>'}</ul>
      <h2>Decisions & next steps</h2><ul>${decisions.map(d=>`<li><strong>${esc(d.title)}</strong> — ${esc(d.points[0]||'')}</li>`).join('')||'<li>No explicit decisions detected. Add a slide titled “Next steps” to capture them.</li>'}</ul>
      <h2>Open questions</h2><ul>${questions.map(q=>`<li>${esc(q.title)}</li>`).join('')||'<li>None detected.</li>'}</ul>
      <h2>Slide-by-slide</h2>${rows.map(r=>`<h3>${r.index+1}. ${esc(r.title)}</h3><p>${esc(r.points.slice(0,3).join(' · ')||'—')}</p>`).join('')}
    </section>`;
  }
  function execSummary(){
    modal({
      title:'Executive summary', sub:'A decision-ready brief generated from the deck: key messages, KPIs, decisions and open questions.',
      wide:true, body:`<div class="handout-preview">${execInner()}</div>`,
      footer:`<span class="muted" style="font-size:11px">Auto-generated · edit the deck to refine</span><div class="modal-foot-right"><button class="btn btn-ghost" id="ex-dl">${icon('download')} Download HTML</button><button class="btn btn-primary" id="ex-print">${icon('print')} Print / PDF</button></div>`,
      onMount:el=>{
        $('#ex-print',el).addEventListener('click',()=>printInner(execInner()));
        $('#ex-dl',el).addEventListener('click',()=>download(new Blob([pageDoc('Executive summary',execInner())],{type:'text/html'}),'exec-summary-'+JDIO.safeName(Store.project.name)+'.html'));
      }
    });
  }

  /* ---------- teaching kit ---------- */
  function teachingInner(){
    const rows=outline();
    const terms=[];
    rows.forEach(r=>{ (r.title+' '+r.points.join(' ')).split(/\s+/).forEach(w=>{ const c=w.replace(/[^A-Za-z-]/g,''); if(c.length>4&&/^[A-Z]/.test(c)&&!terms.includes(c)) terms.push(c); }); });
    const qs=rows.slice(1,7).map(r=>`How would you explain “${r.title}” to someone who has never seen this deck?`);
    return `<section class="sheet summary-doc" style="width:210mm;min-height:297mm">
      <h1>Teaching kit</h1>
      <div class="meta">${esc(Store.project.name)} · ${rows.length} slides · ${today()}</div>
      <h2>Learning objectives</h2><ul>${rows.slice(0,5).map(r=>`<li>Explain <strong>${esc(r.title)}</strong> and give one real-world example.</li>`).join('')}</ul>
      <h2>Key terms</h2><p>${terms.slice(0,18).map(t=>esc(t)).join(' · ')||'Add terminology to the deck to populate this section.'}</p>
      <h2>Lesson flow (60 minutes)</h2>
      <table><tr><th>Time</th><th>Segment</th><th>What happens</th></tr>
        <tr><td>0–5</td><td>Hook</td><td>Ask a provocative question drawn from “${esc(rows[1]?.title||rows[0]?.title||'the opening')}”.</td></tr>
        <tr><td>5–20</td><td>Teach</td><td>Walk through slides 2–${Math.min(6,rows.length)}. Pause after each for a 30-second think-pair-share.</td></tr>
        <tr><td>20–35</td><td>Practice</td><td>Teams apply the idea to a case. Use the handout as a worksheet.</td></tr>
        <tr><td>35–50</td><td>Discuss</td><td>Use the discussion questions below. Capture misconceptions on the board.</td></tr>
        <tr><td>50–60</td><td>Check</td><td>Exit ticket: one sentence answering the essential question.</td></tr>
      </table>
      <h2>Discussion questions</h2><ol>${qs.map(q=>`<li>${esc(q)}</li>`).join('')}</ol>
      <h2>Activities</h2><ul><li><strong>Think-pair-share:</strong> 2 minutes alone, 2 minutes in pairs, 1 minute whole class.</li><li><strong>Case study:</strong> give teams a scenario and ask them to apply the deck's framework.</li><li><strong>Teach-back:</strong> each team teaches one slide in 60 seconds.</li></ul>
      <h2>Assessment</h2><p>Exit ticket: “What is the main idea, and what is one question you still have?” Score 0–2 for accuracy and 0–2 for reasoning.</p>
      <h2>Differentiation</h2><ul><li>Support: provide the handout with sentence starters.</li><li>Stretch: ask students to critique the deck's strongest and weakest slide.</li><li>Accessibility: enable large text and dyslexia-friendly font in j-Docs before projecting.</li></ul>
      <h2>Homework</h2><p>Write a one-page response applying the framework to a situation you know.</p>
    </section>`;
  }
  function teachingKit(){
    modal({
      title:'Teaching kit', sub:'Turn the same deck into a lesson: objectives, key terms, timed flow, discussion questions, activities, assessment and differentiation.',
      wide:true, body:`<div class="handout-preview">${teachingInner()}</div>`,
      footer:`<span class="muted" style="font-size:11px">Teaching resource surface</span><div class="modal-foot-right"><button class="btn btn-ghost" id="tk-dl">${icon('download')} Download HTML</button><button class="btn btn-primary" id="tk-print">${icon('print')} Print / PDF</button></div>`,
      onMount:el=>{
        $('#tk-print',el).addEventListener('click',()=>printInner(teachingInner()));
        $('#tk-dl',el).addEventListener('click',()=>download(new Blob([pageDoc('Teaching kit',teachingInner())],{type:'text/html'}),'teaching-kit-'+JDIO.safeName(Store.project.name)+'.html'));
      }
    });
  }

  /* ---------- lesson plan ---------- */
  function lessonInner(){
    const rows=outline();
    const segs=[
      ['0–5','Hook & prior knowledge','Question from the opening slide','Whole class'],
      ['5–15','Direct instruction','Slides 2–4 with checks for understanding','Teacher-led'],
      ['15–30','Guided practice','Worked example using the deck framework','Pairs'],
      ['30–45','Independent practice','Handout task','Individual'],
      ['45–55','Discussion','Discussion questions from the teaching kit','Small groups'],
      ['55–60','Exit ticket','One-sentence summary','Individual']
    ];
    return `<section class="sheet summary-doc" style="width:210mm;min-height:297mm">
      <h1>Lesson plan</h1><div class="meta">${esc(Store.project.name)} · ${rows.length} slides · ${today()}</div>
      <h2>Essential question</h2><p>${esc(rows[0]?.title||Store.project.name)} — why does it matter, and how would we apply it?</p>
      <h2>Standards & objectives</h2><ul>${rows.slice(0,4).map(r=>`<li>${esc(r.title)}</li>`).join('')}</ul>
      <h2>Timed sequence</h2>
      <table><tr><th>Min</th><th>Segment</th><th>Activity</th><th>Grouping</th></tr>${segs.map(s=>`<tr><td>${s[0]}</td><td>${s[1]}</td><td>${esc(s[2])}</td><td>${s[3]}</td></tr>`).join('')}</table>
      <h2>Materials</h2><ul><li>j-Docs deck (live or printed handout)</li><li>Student handout (2 slides per page)</li><li>Exit tickets</li></ul>
      <h2>Formative checks</h2><ul><li>Cold call after slides 2 and 4.</li><li>Circulate during independent practice; note misconceptions.</li><li>Exit ticket scored 0–4.</li></ul>
      <h2>Reflection</h2><p>What worked? Which slide caused the most confusion? What will you change next time?</p>
    </section>`;
  }
  function lessonPlan(){
    modal({
      title:'Lesson plan', sub:'A timed, standards-aligned plan generated from the deck structure.',
      wide:true, body:`<div class="handout-preview">${lessonInner()}</div>`,
      footer:`<span class="muted" style="font-size:11px">Editable in any word processor after download</span><div class="modal-foot-right"><button class="btn btn-ghost" id="lp-dl">${icon('download')} Download HTML</button><button class="btn btn-primary" id="lp-print">${icon('print')} Print / PDF</button></div>`,
      onMount:el=>{
        $('#lp-print',el).addEventListener('click',()=>printInner(lessonInner()));
        $('#lp-dl',el).addEventListener('click',()=>download(new Blob([pageDoc('Lesson plan',lessonInner())],{type:'text/html'}),'lesson-plan-'+JDIO.safeName(Store.project.name)+'.html'));
      }
    });
  }

  /* ---------- quiz builder ---------- */
  function quizData(){
    const rows=outline();
    const all=[]; rows.forEach(r=>r.points.forEach(p=>{ if(p.length>12&&p.length<180) all.push({slide:r.index+1,title:r.title,text:p}); }));
    const qs=[];
    all.slice(0,10).forEach((item)=>{
      const distractors=all.filter(x=>x.text!==item.text).sort(()=>Math.random()-.5).slice(0,3).map(x=>x.text);
      if(distractors.length<3) return;
      const options=[item.text,...distractors].sort(()=>Math.random()-.5);
      qs.push({q:`Which statement best matches “${item.title}”?`,options,answer:options.indexOf(item.text),slide:item.slide});
    });
    return qs;
  }
  function quizInner(){
    const qs=quizData();
    return `<section class="sheet summary-doc" style="width:210mm;min-height:297mm">
      <h1>Quiz · ${esc(Store.project.name)}</h1><div class="meta">${qs.length} questions · auto-generated from slide content · ${today()}</div>
      <p class="muted">Choose the best answer. The answer key is on the last page.</p>
      ${qs.map((q,i)=>`<h3>${i+1}. ${esc(q.q)}</h3><ul style="list-style:none;margin-left:0">${q.options.map((o,j)=>`<li>${String.fromCharCode(65+j)}. ${esc(o)}</li>`).join('')}</ul>`).join('')}
      <h2 style="page-break-before:always">Answer key</h2>
      <table><tr><th>#</th><th>Answer</th><th>Slide</th></tr>${qs.map((q,i)=>`<tr><td>${i+1}</td><td>${String.fromCharCode(65+q.answer)}</td><td>${q.slide}</td></tr>`).join('')}</table>
    </section>`;
  }
  function quizBuilder(){
    modal({
      title:'Quiz builder', sub:'Automatically turn slide bullets into a multiple-choice quiz with an answer key.',
      wide:true, body:`<div class="handout-preview">${quizInner()}</div>`,
      footer:`<span class="muted" style="font-size:11px">Teaching resource · answer key included</span><div class="modal-foot-right"><button class="btn btn-ghost" id="qz-dl">${icon('download')} Download HTML</button><button class="btn btn-primary" id="qz-print">${icon('print')} Print / PDF</button></div>`,
      onMount:el=>{
        $('#qz-print',el).addEventListener('click',()=>printInner(quizInner()));
        $('#qz-dl',el).addEventListener('click',()=>download(new Blob([pageDoc('Quiz',quizInner())],{type:'text/html'}),'quiz-'+JDIO.safeName(Store.project.name)+'.html'));
      }
    });
  }

  /* ---------- readability ---------- */
  function syllables(word){
    word=word.toLowerCase().replace(/[^a-z]/g,''); if(!word) return 0;
    if(word.length<=3) return 1;
    word=word.replace(/(?:[^laeiouy]es|ed|[^laeiouy]e)$/,'').replace(/^y/,'');
    const m=word.match(/[aeiouy]{1,2}/g); return m?m.length:1;
  }
  function readabilityData(){
    const rows=outline();
    let wordsN=0,sentN=0,sylN=0,longW=0;
    const per=rows.map(r=>{
      const text=(r.title+'. '+r.points.join('. ')+'. '+(r.notes||'')).trim();
      const w=text.split(/\s+/).filter(Boolean);
      const sents=Math.max(1,(text.match(/[.!?]+/g)||[]).length);
      const syl=w.reduce((a,x)=>a+syllables(x),0);
      const lw=w.filter(x=>x.replace(/[^A-Za-z]/g,'').length>6).length;
      wordsN+=w.length; sentN+=sents; sylN+=syl; longW+=lw;
      const fre=206.835-1.015*(w.length/sents)-84.6*(syl/Math.max(1,w.length));
      return {slide:r.index+1,title:r.title,words:w.length,fre:Math.max(0,Math.min(100,fre))};
    });
    const fre=206.835-1.015*(wordsN/Math.max(1,sentN))-84.6*(sylN/Math.max(1,wordsN));
    const fkgl=0.39*(wordsN/Math.max(1,sentN))+11.8*(sylN/Math.max(1,wordsN))-15.59;
    return {fre:Math.max(0,Math.min(100,fre)),fkgl:Math.max(0,fkgl),words:wordsN,sentences:sentN,longWords:longW,per};
  }
  function gradeLabel(fk){ return fk<6?'Primary school':fk<9?'Middle school':fk<13?'High school':fk<16?'College':'Graduate / specialist'; }
  function readability(){
    const d=readabilityData();
    const rows=d.per.map(p=>`<tr><td>${p.slide}</td><td>${esc(p.title)}</td><td>${p.words}</td><td>${Math.round(p.fre)}</td></tr>`).join('');
    const inner=`<section class="sheet summary-doc" style="width:210mm;min-height:297mm">
      <h1>Readability report</h1><div class="meta">${esc(Store.project.name)} · ${d.words} words · ${d.sentences} sentences · ${today()}</div>
      <div class="kpis"><div class="kpi"><b>${Math.round(d.fre)}</b><span>Flesch ease</span></div><div class="kpi"><b>${d.fkgl.toFixed(1)}</b><span>Grade level</span></div><div class="kpi"><b>${d.words}</b><span>Words</span></div><div class="kpi"><b>${d.longWords}</b><span>Long words</span></div></div>
      <div class="callout"><strong>${gradeLabel(d.fkgl)} reading level.</strong> ${d.fre>=60?'Good for a general audience.':'Consider shorter sentences and simpler words for a general audience.'} Aim for a Flesch ease of 60+ for mixed audiences and 50+ for technical audiences.</div>
      <h2>Per-slide readability</h2>
      <table><tr><th>#</th><th>Slide</th><th>Words</th><th>Flesch ease</th></tr>${rows}</table>
      <h2>How to improve</h2><ul><li>Keep one idea per slide and no more than six bullets.</li><li>Replace nominalisations (“implementation”) with verbs (“build”).</li><li>Put the conclusion in the title, not just the topic.</li><li>Use the accessibility checker to catch contrast and alt-text issues.</li></ul>
    </section>`;
    modal({
      title:'Readability', sub:'Flesch Reading Ease and grade level for the whole deck and every slide.',
      wide:true, body:`<div class="handout-preview">${inner}</div>`,
      footer:`<span class="muted" style="font-size:11px">Writing intelligence</span><div class="modal-foot-right"><button class="btn btn-ghost" id="rd-dl">${icon('download')} Download HTML</button><button class="btn btn-primary" id="rd-print">${icon('print')} Print / PDF</button></div>`,
      onMount:el=>{
        $('#rd-print',el).addEventListener('click',()=>printInner(inner));
        $('#rd-dl',el).addEventListener('click',()=>download(new Blob([pageDoc('Readability report',inner)],{type:'text/html'}),'readability-'+JDIO.safeName(Store.project.name)+'.html'));
      }
    });
  }

  /* ---------- print studio ---------- */
  function printStudio(){
    const state={type:'handouts',per:2,lines:true};
    modal({
      title:'Print studio', sub:'One place to print or save PDF: handouts, notes pages, summaries, teaching kit or the full document.',
      wide:true,
      body:`<div class="row wrap" style="gap:10px;margin-bottom:12px">
        <label class="field"><span>Output</span><select id="ps-type">
          <option value="handouts">Handouts (slides + lines)</option>
          <option value="notes">Speaker notes pages</option>
          <option value="summary">Slide summaries</option>
          <option value="exec">Executive summary</option>
          <option value="teaching">Teaching kit</option>
          <option value="lesson">Lesson plan</option>
          <option value="quiz">Quiz + answer key</option>
          <option value="document">Full document (all slides)</option>
        </select></label>
        <label class="field" id="ps-per-wrap"><span>Slides per page</span><select id="ps-per"><option>1</option><option selected>2</option><option>3</option><option>4</option><option>6</option></select></label>
        <label class="check" id="ps-lines-wrap"><input type="checkbox" id="ps-lines" checked> Writing lines</label>
      </div>
      <div class="handout-preview" id="ps-preview"></div>`,
      footer:`<span class="muted" style="font-size:11px">A4 · browser print dialog → Save as PDF</span><div class="modal-foot-right"><button class="btn btn-ghost" id="ps-dl">${icon('download')} Download HTML</button><button class="btn btn-primary" id="ps-print">${icon('print')} Print / PDF</button></div>`,
      onMount:el=>{
        const build=()=>{
          state.type=$('#ps-type',el).value; state.per=Number($('#ps-per',el).value); state.lines=$('#ps-lines',el).checked;
          $('#ps-per-wrap',el).style.display=state.type==='handouts'?'':'none';
          $('#ps-lines-wrap',el).style.display=(state.type==='handouts'||state.type==='notes')?'':'none';
          if(state.type==='handouts') return handoutInner({per:state.per,lines:state.lines});
          if(state.type==='notes') return notesInner({lines:state.lines});
          if(state.type==='summary') return summaryInner();
          if(state.type==='exec') return execInner();
          if(state.type==='teaching') return teachingInner();
          if(state.type==='lesson') return lessonInner();
          if(state.type==='quiz') return quizInner();
          return documentInner();
        };
        const render=()=>{ $('#ps-preview',el).innerHTML=build(); };
        el.querySelectorAll('select,input').forEach(x=>x.addEventListener('change',render)); render();
        $('#ps-print',el).addEventListener('click',()=>printInner(build()));
        $('#ps-dl',el).addEventListener('click',()=>download(new Blob([pageDoc(Store.project.name+' — Print',build())],{type:'text/html'}),'print-'+JDIO.safeName(Store.project.name)+'.html'));
      }
    });
  }

  /* ---------- document mode ---------- */
  function documentInner(){
    return Store.project.slides.map((s,i)=>`<section class="sheet" style="width:210mm;min-height:auto;padding:8mm;margin-bottom:8mm">
      <div style="font-size:7pt;color:#888;margin-bottom:2mm">${i+1} / ${Store.project.slides.length}</div>
      <div style="width:100%;aspect-ratio:16/9;position:relative;overflow:hidden;container-type:size;border:.5pt solid #eee">${slideHTML(s)}</div>
      ${s.notes?`<p style="font-size:8.5pt;color:#555;margin:3mm 0 0"><strong>Notes:</strong> ${esc(s.notes)}</p>`:''}
    </section>`).join('');
  }
  function documentMode(){
    const inner=documentInner();
    const root=$('#fileViewerRoot');
    root.hidden=false; root.style.display='flex';
    root.innerHTML=`<div class="file-viewer" role="dialog" aria-modal="true" aria-label="Document mode">
      <div class="fv-head"><div class="fv-icon">${icon('reading')}</div><div class="fv-meta"><div class="fv-name">${esc(Store.project.name)} — document mode</div><div class="fv-sub">${Store.project.slides.length} slides · reading view · one project, every surface</div></div><button class="modal-close" data-dm-close aria-label="Close">×</button></div>
      <div class="fv-body"><div class="fv-preview" style="display:block;background:#e9e7e4"><div id="dm-doc">${inner}</div></div>
        <div class="fv-side"><h4>Reading</h4><p style="font-size:11.5px;line-height:1.6;color:var(--muted)">This is the same deck as a scrollable document. Share the link, print it, or use it as a pre-read.</p>
        <div class="fv-actions"><button class="btn btn-primary" data-dm-print>${icon('print')} Print / PDF</button><button class="btn btn-ghost" data-dm-html>${icon('html')} Export web</button><button class="btn btn-ghost" data-dm-close>${icon('close')} Close</button></div>
        <h4 style="margin-top:14px">Stats</h4><div class="fv-kv"><span>Slides</span><span>${Store.project.slides.length}</span></div><div class="fv-kv"><span>Words</span><span>${Store.stats().words}</span></div><div class="fv-kv"><span>Read time</span><span>${Store.stats().reading} min</span></div></div>
      </div></div>`;
    root.querySelectorAll('[data-dm-close]').forEach(b=>b.addEventListener('click',()=>{ root.style.display='none'; root.hidden=true; root.innerHTML=''; }));
    root.querySelector('[data-dm-print]')?.addEventListener('click',()=>printInner(inner));
    root.querySelector('[data-dm-html]')?.addEventListener('click',()=>window.JDIO?.exportHTML());
  }

  /* ---------- offline package ---------- */
  async function offlinePackage(){
    try{
      toast('Building offline package…','info');
      const zip=new JSZip();
      const name=JDIO.safeName(Store.project.name);
      const html=await window.JDIO.buildHTML();
      zip.file('index.html',html);
      zip.file('present.html',html);
      zip.file('project.jdocs',JSON.stringify(Store.project,null,2));
      zip.file('handout.html',pageDoc(Store.project.name+' — Handout',handoutInner({per:2,lines:true})));
      zip.file('notes.html',pageDoc(Store.project.name+' — Notes',notesInner({lines:true})));
      zip.file('summary.html',pageDoc(Store.project.name+' — Summary',summaryInner()));
      zip.file('teaching-kit.html',pageDoc('Teaching kit',teachingInner()));
      zip.file('lesson-plan.html',pageDoc('Lesson plan',lessonInner()));
      zip.file('quiz.html',pageDoc('Quiz',quizInner()));
      const fontFiles=[];
      for(const f of ['Selawik-Regular.woff','Selawik-Bold.woff']){
        try{ const b=await fetch('fonts/'+f).then(r=>r.arrayBuffer()); zip.file('fonts/'+f,b); fontFiles.push(f); }catch(e){}
      }
      const media=[]; let n=0;
      Store.project.slides.forEach(s=>s.elements.forEach(e=>{
        if((e.type==='image'||e.type==='media')&&e.src&&e.src.startsWith('data:')){
          const m=e.src.match(/^data:([^;]+);base64,(.*)$/); if(!m) return;
          const ext=(m[1].split('/')[1]||'bin').replace('jpeg','jpg');
          const path='media/'+(++n)+'-'+(JDIO.safeName(e.alt||e.type))+'.'+ext;
          zip.file(path,m[2],{base64:true}); media.push({path,type:m[1],element:e.type});
        }
      }));
      try{ const raw=localStorage.getItem('jdocs.engage.v1'); if(raw){ zip.file('audience-responses.csv',responsesToCSV(JSON.parse(raw))); } }catch(e){}
      const manifest={
        app:'j-Docs', version:'1.0.0', generated:new Date().toISOString(), project:Store.project.name,
        slides:Store.project.slides.length, theme:Store.project.theme,
        files:['index.html','present.html','project.jdocs','handout.html','notes.html','summary.html','teaching-kit.html','lesson-plan.html','quiz.html','manifest.json','README.txt','LICENSES.txt'],
        fonts:fontFiles.map(f=>({file:'fonts/'+f,family:'Selawik',license:'SIL Open Font License 1.1',redistributable:true,note:'Selawik is metric-compatible with Segoe UI and is licensed for embedding and redistribution.'})),
        media:media.map(m=>({file:m.path,type:m.type,license:'User-provided — verify rights before redistribution',redistributable:'unknown'})),
        licensing:{fonts:'SIL OFL 1.1 — embedding permitted',media:'Only media the author has rights to redistribute should be included. j-Docs records each asset so you can audit before sharing.',app:'j-Docs original code — MIT-style use permitted by the author.'},
        offline:true, notes:'Open index.html in any modern browser. No server, no network, no account required.'
      };
      zip.file('manifest.json',JSON.stringify(manifest,null,2));
      zip.file('README.txt',`j-Docs offline package
=====================

Project: ${Store.project.name}
Generated: ${new Date().toLocaleString()}
Slides: ${Store.project.slides.length}

Open index.html in any modern browser. It works fully offline: fonts, media and navigation are embedded.

Contents
- index.html / present.html : the deck as a self-contained web experience
- project.jdocs             : re-open and edit in j-Docs
- handout.html              : printable handout (2 slides per page)
- notes.html                : printable speaker notes
- summary.html              : slide summaries
- teaching-kit.html         : objectives, activities, assessment
- lesson-plan.html          : timed lesson plan
- quiz.html                 : multiple-choice quiz + answer key
- manifest.json             : file list, font and media licensing status
- LICENSES.txt              : licence details

Fonts
Selawik (SIL OFL 1.1) is embedded. It is metric-compatible with Segoe UI.

Media
Only media you have the right to redistribute should be shared. Check manifest.json for the licence status of every asset.
`);
      zip.file('LICENSES.txt',`j-Docs licences
===============

Selawik font
------------
Copyright (c) Microsoft Corporation. Licensed under the SIL Open Font License, Version 1.1.
The font may be embedded and redistributed with this package. Full text: https://scripts.sil.org/OFL

JSZip
-----
MIT License. Used to build offline packages and PPTX files.

qrcode-generator
----------------
MIT License. Used to render audience join codes.

j-Docs application code
-----------------------
Original work created for this project. You may use, modify and share it.

Media
-----
Media files are provided by the deck author. The author is responsible for ensuring
they have the right to redistribute each asset. See manifest.json for per-file status.
`);
      const blob=await zip.generateAsync({type:'blob',compression:'DEFLATE',compressionOptions:{level:6}});
      download(blob,name+'-offline.zip');
      toast('Offline package ready · '+fmtBytes(blob.size),'success');
    }catch(e){ console.error(e); toast('Package failed: '+e.message,'error'); }
  }

  function responsesToCSV(data){
    const rows=[['type','question','answer','timestamp']];
    (data.responses||[]).forEach(r=>rows.push([r.type||'',r.question||'',r.answer||'',r.at||'']));
    return rows.map(r=>r.map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(',')).join('\n');
  }

  /* ---------- export all ---------- */
  async function exportAll(){
    try{
      toast('Packing every surface…','info');
      const zip=new JSZip(); const name=JDIO.safeName(Store.project.name);
      zip.file('project.jdocs',JSON.stringify(Store.project,null,2));
      zip.file('index.html',await window.JDIO.buildHTML());
      zip.file('handout.html',pageDoc('Handout',handoutInner({per:2,lines:true})));
      zip.file('notes.html',pageDoc('Notes',notesInner({lines:true})));
      zip.file('summary.html',pageDoc('Summary',summaryInner()));
      zip.file('exec-summary.html',pageDoc('Executive summary',execInner()));
      zip.file('teaching-kit.html',pageDoc('Teaching kit',teachingInner()));
      zip.file('lesson-plan.html',pageDoc('Lesson plan',lessonInner()));
      zip.file('quiz.html',pageDoc('Quiz',quizInner()));
      zip.file('readability.html',pageDoc('Readability',summaryInner()));
      try{ const pptx=await window.JDIO.buildPPTXBlob(); zip.file(name+'.pptx',pptx); }catch(e){ console.warn('PPTX in bundle failed',e); }
      try{ const raw=localStorage.getItem('jdocs.engage.v1'); if(raw) zip.file('audience-responses.csv',responsesToCSV(JSON.parse(raw))); }catch(e){}
      zip.file('README.txt',`j-Docs export bundle for “${Store.project.name}”.\n\nOne project, every surface:\n- index.html — live web experience\n- handout.html / notes.html — print\n- summary.html / exec-summary.html — read\n- teaching-kit.html / lesson-plan.html / quiz.html — teach\n- project.jdocs — edit again\n- ${name}.pptx — PowerPoint-compatible\n`);
      const blob=await zip.generateAsync({type:'blob',compression:'DEFLATE'});
      download(blob,name+'-everything.zip');
      toast('Exported every surface · '+fmtBytes(blob.size),'success');
    }catch(e){ console.error(e); toast('Export failed: '+e.message,'error'); }
  }

  window.JDOutputs={handouts,notesPages,summaries,execSummary,teachingKit,lessonPlan,quizBuilder,readability,printStudio,documentMode,offlinePackage,exportAll,
    handoutInner,notesInner,summaryInner,execInner,teachingInner,lessonInner,quizInner,documentInner,readabilityData,pageDoc,PRINT_CSS};
})();
