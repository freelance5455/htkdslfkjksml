/* j-Docs renderer — one slide model, every surface */
(function(){
  const {themeById, esc, strip} = window.JD;

  function resolveColor(c, theme){
    if(c==null||c==='') return 'transparent';
    if(c==='fg') return theme.fg;
    if(c==='bg') return theme.bg;
    if(c==='accent') return theme.accent;
    if(c==='accent2') return theme.accent2;
    if(c==='muted') return theme.muted;
    if(c==='soft') return theme.soft;
    if(c==='line') return theme.dark?'rgba(255,255,255,.18)':'rgba(0,0,0,.14)';
    if(c==='transparent') return 'transparent';
    return c;
  }

  function fontFamily(f, theme){
    if(f==='head') return theme.head;
    if(f==='body') return theme.body;
    if(f==='mono') return 'var(--font-mono)';
    if(f && f!=='inherit') return '"'+f+'",Selawik,sans-serif';
    return theme.body;
  }

  function cqw(pt){ const n=Number(pt); return (isFinite(n)?n:18)/9.6; }

  function sanitize(html){
    const tpl=document.createElement('template');
    tpl.innerHTML=String(html||'');
    const allowed=new Set(['P','BR','STRONG','B','EM','I','U','S','STRIKE','UL','OL','LI','A','SPAN','H1','H2','H3','H4','BLOCKQUOTE','CODE','PRE','SUP','SUB','MARK']);
    const walk=(node)=>{
      [...node.childNodes].forEach(n=>{
        if(n.nodeType===1){
          if(!allowed.has(n.tagName)){ n.replaceWith(...n.childNodes); return; }
          [...n.attributes].forEach(a=>{
            const name=a.name.toLowerCase();
            if(name.startsWith('on')||name==='style'||(name==='href'&&/^javascript:/i.test(a.value))) n.removeAttribute(a.name);
            if(name==='href'){ n.setAttribute('target','_blank'); n.setAttribute('rel','noopener'); }
          });
          walk(n);
        }
      });
    };
    walk(tpl.content);
    return tpl.innerHTML;
  }

  function textStyle(el, theme){
    const s=el.style||{};
    const color=resolveColor(s.color||'fg',theme);
    const ff=fontFamily(s.fontFamily||'body',theme);
    const fs=cqw(s.fontSize||18);
    const pad=cqw(s.padding||0);
    return [
      'font-family:'+ff,
      'font-size:'+fs+'cqw',
      'color:'+color,
      'font-weight:'+(s.bold?700:400),
      'font-style:'+(s.italic?'italic':'normal'),
      'text-decoration:'+[s.underline?'underline':'',s.strike?'line-through':''].filter(Boolean).join(' ')||'none',
      'text-align:'+(s.align||'left'),
      'line-height:'+(s.lineHeight||1.3),
      'letter-spacing:'+(s.letterSpacing||0)+'px',
      'text-transform:'+(s.uppercase?'uppercase':'none'),
      'padding:'+pad+'cqw',
      'background:'+resolveColor(s.fill||'transparent',theme),
      'justify-content:'+(s.valign==='middle'?'center':s.valign==='bottom'?'flex-end':'flex-start')
    ].join(';');
  }

  function shapeSVG(e, theme){
    const s=e.style||{};
    const fill=resolveColor(s.fill||'accent',theme);
    const stroke=resolveColor(s.stroke||'transparent',theme);
    const sw=Number(s.strokeWidth||0);
    const shape=e.shape||'rect';
    const common='fill="'+fill+'" stroke="'+stroke+'" stroke-width="'+sw+'" vector-effect="non-scaling-stroke"';
    let body='';
    if(shape==='rect') body='<rect x="1" y="1" width="98" height="98" rx="'+(s.radius||0)+'" '+common+'/>';
    else if(shape==='roundRect') body='<rect x="1" y="1" width="98" height="98" rx="'+(s.radius||12)+'" '+common+'/>';
    else if(shape==='ellipse'||shape==='circle') body='<ellipse cx="50" cy="50" rx="49" ry="49" '+common+'/>';
    else if(shape==='triangle') body='<path d="M50 2 98 98H2Z" '+common+'/>';
    else if(shape==='diamond') body='<path d="M50 2 98 50 50 98 2 50Z" '+common+'/>';
    else if(shape==='pentagon') body='<path d="M50 2 97 37 79 95H21L3 37Z" '+common+'/>';
    else if(shape==='hexagon') body='<path d="M25 2h50l23 48-23 48H25L2 50Z" '+common+'/>';
    else if(shape==='octagon') body='<path d="M30 2h40l28 28v40L70 98H30L2 70V30Z" '+common+'/>';
    else if(shape==='star') body='<path d="M50 2 61 37 98 37 68 59 79 95 50 73 21 95 32 59 2 37 39 37Z" '+common+'/>';
    else if(shape==='arrow') body='<path d="M2 35h55V12l41 38-41 38V65H2Z" '+common+'/>';
    else if(shape==='chevron') body='<path d="M2 2h58L98 50 60 98H2l38-48Z" '+common+'/>';
    else if(shape==='callout') body='<path d="M2 2h96v70H38L14 98V72H2Z" '+common+'/>';
    else if(shape==='cloud') body='<path d="M25 80C10 80 2 68 2 56c0-12 10-21 22-21 3-14 16-24 31-24 17 0 31 12 33 28 8 2 12 9 12 17 0 13-10 24-25 24Z" '+common+'/>';
    else if(shape==='heart') body='<path d="M50 92C20 72 2 55 2 34 2 18 14 8 28 8c9 0 17 5 22 13 5-8 13-13 22-13 14 0 26 10 26 26 0 21-18 38-48 58Z" '+common+'/>';
    else if(shape==='plus') body='<path d="M38 2h24v36h36v24H62v36H38V62H2V38h36Z" '+common+'/>';
    else if(shape==='line') body='<line x1="2" y1="50" x2="98" y2="50" '+common+'/>';
    else if(shape==='arrowLine') body='<path d="M2 50h90M70 30l22 20-22 20" fill="none" stroke="'+stroke+'" stroke-width="'+Math.max(sw,2)+'" vector-effect="non-scaling-stroke"/>';
    else body='<rect x="1" y="1" width="98" height="98" '+common+'/>';
    return '<svg viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">'+body+'</svg>';
  }

  function tableHTML(e, theme){
    const s=e.style||{};
    const data=e.data||[['A','B'],['1','2']];
    const fs=cqw(s.fontSize||12);
    const hf=resolveColor(s.headerFill||'accent',theme);
    const hc=resolveColor(s.headerColor||'#fff',theme);
    const bc=resolveColor(s.color||'fg',theme);
    let html='<table style="font-size:'+fs+'cqw;color:'+bc+';text-align:'+(s.align||'left')+'">';
    data.forEach((row,ri)=>{
      html+='<tr>';
      row.forEach(cell=>{
        const isHead=e.header&&ri===0;
        const bg=isHead?hf:(s.striped&&ri%2===0?resolveColor('soft',theme):'transparent');
        html+='<td style="background:'+bg+';color:'+(isHead?hc:bc)+';font-weight:'+(isHead?700:400)+';border-color:'+resolveColor(s.border||'line',theme)+'">'+esc(cell)+'</td>';
      });
      html+='</tr>';
    });
    return html+'</table>';
  }

  function chartSVG(e, theme){
    const data=(e.data||[]).filter(d=>d&&d.label!=null);
    const s=e.style||{};
    const W=400,H=240,pad={l:42,r:18,t:24,b:38};
    const iw=W-pad.l-pad.r, ih=H-pad.t-pad.b;
    const colors=(s.colors||['accent','accent2','#2b579a','#0f7b6c','#c19a00']).map(c=>resolveColor(c,theme));
    const fg=theme.fg, muted=theme.muted, grid=theme.dark?'rgba(255,255,255,.12)':'rgba(0,0,0,.09)';
    if(!data.length) return '<svg viewBox="0 0 400 240"><text x="200" y="120" text-anchor="middle" fill="'+muted+'" font-size="13">No data</text></svg>';
    const max=Math.max(1,...data.map(d=>Number(d.value)||0));
    let g='<svg viewBox="0 0 400 240" preserveAspectRatio="xMidYMid meet" role="img" aria-label="'+esc(s.title||'Chart')+'">';
    if(s.title) g+='<text x="'+pad.l+'" y="16" fill="'+fg+'" font-size="12" font-weight="700">'+esc(s.title)+'</text>';
    const type=e.chartType||'column';
    if(type==='pie'||type==='donut'){
      const cx=200,cy=130,r=82; let a=-Math.PI/2; const total=data.reduce((n,d)=>n+(Number(d.value)||0),0)||1;
      data.forEach((d,i)=>{
        const ang=(Number(d.value)||0)/total*Math.PI*2; const a2=a+ang;
        const x1=cx+r*Math.cos(a),y1=cy+r*Math.sin(a),x2=cx+r*Math.cos(a2),y2=cy+r*Math.sin(a2);
        const large=ang>Math.PI?1:0;
        if(type==='donut'){
          const ri=r*.58; const x3=cx+ri*Math.cos(a2),y3=cy+ri*Math.sin(a2),x4=cx+ri*Math.cos(a),y4=cy+ri*Math.sin(a);
          g+='<path d="M'+x1+' '+y1+' A'+r+' '+r+' 0 '+large+' 1 '+x2+' '+y2+' L'+x3+' '+y3+' A'+ri+' '+ri+' 0 '+large+' 0 '+x4+' '+y4+'Z" fill="'+colors[i%colors.length]+'"/>';
        } else g+='<path d="M'+cx+' '+cy+' L'+x1+' '+y1+' A'+r+' '+r+' 0 '+large+' 1 '+x2+' '+y2+'Z" fill="'+colors[i%colors.length]+'"/>';
        a=a2;
      });
      if(type==='donut') g+='<text x="200" y="126" text-anchor="middle" fill="'+fg+'" font-size="20" font-weight="700">'+total+'</text><text x="200" y="142" text-anchor="middle" fill="'+muted+'" font-size="9">TOTAL</text>';
      if(s.showLegend!==false){
        data.forEach((d,i)=>{
          const y=30+i*16;
          g+='<rect x="300" y="'+(y-8)+'" width="8" height="8" rx="2" fill="'+colors[i%colors.length]+'"/><text x="313" y="'+y+'" fill="'+fg+'" font-size="9">'+esc(d.label)+'</text>';
        });
      }
      return g+'</svg>';
    }
    if(type==='line'||type==='area'){
      if(s.grid!==false){ for(let i=0;i<=4;i++){ const y=pad.t+ih*i/4; g+='<line x1="'+pad.l+'" y1="'+y+'" x2="'+(W-pad.r)+'" y2="'+y+'" stroke="'+grid+'" stroke-width="1"/>'; } }
      const pts=data.map((d,i)=>({x:pad.l+(data.length===1?iw/2:iw*i/(data.length-1)),y:pad.t+ih-(Number(d.value)||0)/max*ih}));
      if(type==='area') g+='<path d="M'+pts[0].x+' '+(pad.t+ih)+' L'+pts.map(p=>p.x+' '+p.y).join(' L')+' L'+pts[pts.length-1].x+' '+(pad.t+ih)+'Z" fill="'+colors[0]+'" opacity=".18"/>';
      g+='<path d="M'+pts.map(p=>p.x+' '+p.y).join(' L')+'" fill="none" stroke="'+colors[0]+'" stroke-width="2.5" stroke-linejoin="round"/>';
      pts.forEach((p,i)=>{ g+='<circle cx="'+p.x+'" cy="'+p.y+'" r="3.5" fill="'+colors[0]+'"/><text x="'+p.x+'" y="'+(H-18)+'" text-anchor="middle" fill="'+muted+'" font-size="8">'+esc(data[i].label)+'</text>'; if(s.showValues!==false)g+='<text x="'+p.x+'" y="'+(p.y-8)+'" text-anchor="middle" fill="'+fg+'" font-size="8" font-weight="700">'+data[i].value+'</text>'; });
      return g+'</svg>';
    }
    // column / bar
    const isBar=type==='bar';
    if(s.grid!==false){
      for(let i=0;i<=4;i++){
        if(isBar){ const x=pad.l+iw*i/4; g+='<line x1="'+x+'" y1="'+pad.t+'" x2="'+x+'" y2="'+(pad.t+ih)+'" stroke="'+grid+'"/>'; }
        else { const y=pad.t+ih*i/4; g+='<line x1="'+pad.l+'" y1="'+y+'" x2="'+(W-pad.r)+'" y2="'+y+'" stroke="'+grid+'"/>'; }
      }
    }
    const n=data.length; const band=(isBar?ih:iw)/n;
    data.forEach((d,i)=>{
      const v=Number(d.value)||0; const len=v/max*(isBar?iw:ih);
      if(isBar){
        const y=pad.t+i*band+band*.18, h=band*.64;
        g+='<rect x="'+pad.l+'" y="'+y+'" width="'+len+'" height="'+h+'" rx="3" fill="'+colors[i%colors.length]+'"/>';
        g+='<text x="'+(pad.l-6)+'" y="'+(y+h/2+3)+'" text-anchor="end" fill="'+muted+'" font-size="8">'+esc(d.label)+'</text>';
        if(s.showValues!==false)g+='<text x="'+(pad.l+len+5)+'" y="'+(y+h/2+3)+'" fill="'+fg+'" font-size="8" font-weight="700">'+d.value+'</text>';
      } else {
        const x=pad.l+i*band+band*.18, w=band*.64, h=len, y=pad.t+ih-h;
        g+='<rect x="'+x+'" y="'+y+'" width="'+w+'" height="'+h+'" rx="3" fill="'+colors[i%colors.length]+'"/>';
        g+='<text x="'+(x+w/2)+'" y="'+(H-18)+'" text-anchor="middle" fill="'+muted+'" font-size="8">'+esc(d.label)+'</text>';
        if(s.showValues!==false)g+='<text x="'+(x+w/2)+'" y="'+(y-5)+'" text-anchor="middle" fill="'+fg+'" font-size="8" font-weight="700">'+d.value+'</text>';
      }
    });
    return g+'</svg>';
  }

  function elementNode(e, theme, opts={}){
    const d=document.createElement('div');
    d.className='el '+e.type+(opts.selected?' selected':'')+(e.locked?' locked':'');
    d.dataset.id=e.id;
    d.style.left=e.x+'%'; d.style.top=e.y+'%'; d.style.width=e.w+'%'; d.style.height=e.h+'%';
    d.style.transform='rotate('+(e.rotation||0)+'deg)';
    d.style.zIndex=e.z||1;
    if(e.type==='text'){
      const txt=document.createElement('div');
      txt.className='txt'; txt.style.cssText=textStyle(e,theme);
      txt.innerHTML=sanitize(e.content||'');
      if(opts.editing){ txt.contentEditable='true'; txt.spellcheck=true; d.classList.add('editing'); }
      else txt.contentEditable='false';
      d.appendChild(txt);
      d.setAttribute('aria-label','Text: '+strip(e.content).slice(0,80));
    } else if(e.type==='shape'){
      d.innerHTML=shapeSVG(e,theme);
      if(e.style&&e.style.opacity!=null) d.style.opacity=e.style.opacity;
      if(e.style&&e.style.shadow) d.style.filter='drop-shadow(0 4px 10px rgba(0,0,0,.22))';
      d.setAttribute('aria-label','Shape: '+(e.shape||'rectangle'));
    } else if(e.type==='image'){
      if(e.src){
        const img=document.createElement('img'); img.src=e.src; img.alt=e.alt||''; img.draggable=false;
        img.style.objectFit=e.fit||'cover'; img.loading='lazy'; img.decoding='async';
        d.appendChild(img);
      } else {
        d.style.background=resolveColor('soft',theme); d.style.border='1px dashed '+resolveColor('line',theme);
        d.innerHTML='<div style="display:grid;place-items:center;height:100%;font-size:11px;color:'+theme.muted+'">Image</div>';
      }
      if(e.style&&e.style.radius) d.style.borderRadius=e.style.radius+'px';
      if(e.style&&e.style.opacity!=null) d.style.opacity=e.style.opacity;
      if(e.style&&e.style.shadow) d.style.boxShadow='0 8px 24px rgba(0,0,0,.22)';
      d.setAttribute('aria-label',e.alt?'Image: '+e.alt:'Image');
    } else if(e.type==='table'){
      d.innerHTML=tableHTML(e,theme);
      d.setAttribute('aria-label','Table with '+(e.data||[]).length+' rows');
    } else if(e.type==='chart'){
      d.innerHTML=chartSVG(e,theme);
      d.setAttribute('aria-label','Chart: '+(e.style&&e.style.title||e.chartType));
    } else if(e.type==='icon'){
      d.innerHTML=window.jIcon(e.name||'star',{size:100,stroke:1.6});
      d.style.color=resolveColor((e.style&&e.style.color)||'accent',theme);
      if(e.style&&e.style.opacity!=null) d.style.opacity=e.style.opacity;
      d.setAttribute('aria-label','Icon: '+(e.name||'star'));
    } else if(e.type==='media'){
      if(opts.thumb){ d.innerHTML='<div class="media-ph">'+window.jIcon(e.kind==='audio'?'audio':'video',{size:34})+'<span>'+(e.kind==='audio'?'Audio':'Video')+'</span></div>'; }
      else if(e.kind==='audio'){ const a=document.createElement('audio'); a.src=e.src; a.controls=e.controls!==false; a.style.width='100%'; d.appendChild(a); }
      else { const v=document.createElement('video'); v.src=e.src; v.controls=e.controls!==false; v.playsInline=true; if(e.poster)v.poster=e.poster; d.appendChild(v); }
      d.setAttribute('aria-label',e.kind==='audio'?'Audio clip':'Video clip');
    } else if(e.type==='code'){
      d.textContent=e.code||''; d.style.fontSize=cqw((e.style&&e.style.fontSize)||10)+'cqw';
      d.setAttribute('aria-label','Code block');
    } else if(e.type==='embed'){
      if(opts.thumb){ d.innerHTML='<div style="display:grid;place-items:center;height:100%;color:#fff;font-size:10px">Embedded content</div>'; }
      else { const f=document.createElement('iframe'); f.src=e.src; f.title=e.title||'Embedded content'; f.loading='lazy'; f.setAttribute('sandbox','allow-scripts allow-same-origin allow-popups allow-forms'); d.appendChild(f); }
      d.setAttribute('aria-label','Embedded content');
    }
    if(e.alt && e.type!=='image'){ const a=document.createElement('span'); a.className='el-alt'; a.textContent=e.alt; d.appendChild(a); }
    return d;
  }

  function backgroundCSS(slide, theme){
    const bg=slide.background;
    if(!bg) return theme.bg;
    if(bg==='theme:title') return theme.titleBg;
    return bg;
  }

  function renderSlide(container, slide, theme, opts={}){
    theme=theme||themeById('ember');
    container.innerHTML='';
    container.style.background=backgroundCSS(slide,theme);
    const els=(slide.elements||[]).slice().sort((a,b)=>(a.z||0)-(b.z||0));
    const frag=document.createDocumentFragment();
    els.forEach(e=>{ if(e.hidden) return; frag.appendChild(elementNode(e,theme,opts)); });
    container.appendChild(frag);
    return container;
  }

  function renderThumb(container, slide, theme){
    container.innerHTML='';
    container.style.background=backgroundCSS(slide,theme);
    const els=(slide.elements||[]).slice().sort((a,b)=>(a.z||0)-(b.z||0));
    els.forEach(e=>{
      if(e.hidden) return;
      // Skip heavy media/iframes in thumbnails; use placeholders
      const n=elementNode(e,theme,{thumb:true});
      container.appendChild(n);
    });
  }

  function slideToHTML(slide, theme, opts={}){
    const bg=backgroundCSS(slide,theme);
    const w=opts.width||960;
    let html='<div class="slide-canvas" style="background:'+bg+';width:100%;height:100%;position:relative;overflow:hidden;container-type:size">';
    (slide.elements||[]).slice().sort((a,b)=>(a.z||0)-(b.z||0)).forEach(e=>{
      const node=elementNode(e,theme,{thumb:opts.thumb});
      html+=node.outerHTML;
    });
    return html+'</div>';
  }

  window.JDRender = {resolveColor,fontFamily,cqw,sanitize,textStyle,shapeSVG,tableHTML,chartSVG,elementNode,renderSlide,renderThumb,slideToHTML,backgroundCSS};
})();
