/* j-Docs universal file opener, importers, exporters */
(function(){
  const JD = window.JD;
  const {Store, themeById, makeLayout, newProject, baseSlide, uid, esc, strip, download, readAsDataURL, readAsText, readAsArrayBuffer, fmtBytes, today} = JD;
  const $ = (s,r=document)=>r.querySelector(s);
  const icon = n => (window.jIcon ? window.jIcon(n,{size:16}) : '');

  const EMU = 914400;
  const DEFAULT_W = 12192000, DEFAULT_H = 6858000;
  const NS_R = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships';

  const extOf = n => { const m=String(n||'').toLowerCase().match(/\.([a-z0-9]+)$/); return m?m[1]:''; };
  const baseName = n => String(n||'file').replace(/\.[^.]+$/,'');
  const mimeFor = ext => ({
    png:'image/png',jpg:'image/jpeg',jpeg:'image/jpeg',gif:'image/gif',webp:'image/webp',svg:'image/svg+xml',bmp:'image/bmp',avif:'image/avif',
    mp3:'audio/mpeg',wav:'audio/wav',m4a:'audio/mp4',ogg:'audio/ogg',mp4:'video/mp4',webm:'video/webm',mov:'video/quicktime',
    ttf:'font/ttf',otf:'font/otf',woff:'font/woff',woff2:'font/woff2',
    pdf:'application/pdf',pptx:'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    docx:'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    xlsx:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
  }[ext] || 'application/octet-stream');

  /* ---------- tiny XML helpers ---------- */
  const P = new DOMParser();
  const xml = s => P.parseFromString(String(s||''),'application/xml');
  const all = (node, local) => node ? Array.from(node.getElementsByTagNameNS('*', local)) : [];
  const kids = (node, local) => node ? Array.from(node.children).filter(c=>c.localName===local) : [];
  const first = (node, local) => all(node, local)[0] || null;
  const val = (node, name) => (node && typeof node.getAttribute==='function') ? (node.getAttribute(name) || node.getAttribute('r:'+name) || '') : '';
  const relAttr = (node,name='embed') => (node && typeof node.getAttribute==='function') ? (node.getAttributeNS(NS_R,name) || node.getAttribute('r:'+name) || '') : '';
  const num = v => { const n=parseFloat(v); return isFinite(n)?n:0; };

  function parseRels(str){
    const out={}; if(!str) return out;
    const d=xml(str); all(d,'Relationship').forEach(r=>{ out[val(r,'Id')]={target:val(r,'Target'),type:val(r,'Type')}; });
    return out;
  }
  function dirOf(p){ const i=p.lastIndexOf('/'); return i<0?'':p.slice(0,i); }
  function relsPath(p){ const d=dirOf(p), b=p.slice(d?d.length+1:0); return (d?d+'/':'')+'_rels/'+b+'.rels'; }
  function resolveTarget(basePath, target){
    if(!target) return '';
    if(target.startsWith('/')) return target.slice(1);
    const base=dirOf(basePath).split('/').filter(Boolean);
    target.split('/').forEach(seg=>{ if(seg==='..') base.pop(); else if(seg!=='.'&&seg!=='') base.push(seg); });
    return base.join('/');
  }
  function dataUrl(bytes,mime){
    let bin=''; const chunk=0x8000;
    for(let i=0;i<bytes.length;i+=chunk) bin+=String.fromCharCode.apply(null,bytes.subarray(i,i+chunk));
    return 'data:'+mime+';base64,'+btoa(bin);
  }

  /* ---------- generic viewer ---------- */
  let _urls=[];
  function closeViewer(){
    const root=$('#fileViewerRoot');
    root.style.display='none'; root.hidden=true; root.innerHTML='';
    _urls.forEach(u=>{try{URL.revokeObjectURL(u)}catch(e){}}); _urls=[];
  }
  function openViewer(opts){
    const root=$('#fileViewerRoot');
    root.hidden=false; root.style.display='flex';
    const actions=(opts.actions||[]).map((a,i)=>`<button class="btn ${a.primary?'btn-primary':'btn-ghost'}" data-fv-act="${i}">${icon(a.icon||'file')} ${esc(a.label)}</button>`).join('');
    root.innerHTML=`<div class="file-viewer" role="dialog" aria-modal="true" aria-label="${esc(opts.title)}">
      <div class="fv-head">
        <div class="fv-icon">${icon(opts.icon||'file')}</div>
        <div class="fv-meta"><div class="fv-name">${esc(opts.title)}</div><div class="fv-sub">${esc(opts.sub||'')}</div></div>
        <button class="modal-close" data-fv-close aria-label="Close viewer">×</button>
      </div>
      <div class="fv-body">
        <div class="fv-preview">${opts.preview||''}</div>
        ${opts.side?`<div class="fv-side">${opts.side}</div>`:''}
      </div>
      <div class="modal-foot">
        <span class="muted" style="font-size:11px">${esc(opts.footer||'Universal viewer · j-Docs opens every extension')}</span>
        <div class="modal-foot-right">${actions}<button class="btn btn-ghost" data-fv-close>Close</button></div>
      </div>
    </div>`;
    root.querySelectorAll('[data-fv-close]').forEach(b=>b.addEventListener('click',closeViewer));
    (opts.actions||[]).forEach((a,i)=>{ const b=root.querySelector(`[data-fv-act="${i}"]`); if(b) b.addEventListener('click',()=>a.onClick&&a.onClick()); });
    const escHandler=e=>{ if(e.key==='Escape'){ closeViewer(); document.removeEventListener('keydown',escHandler); } };
    document.addEventListener('keydown',escHandler);
    if(opts.onMount) opts.onMount(root);
    return root;
  }
  function kv(k,v){ return `<div class="fv-kv"><span>${esc(k)}</span><span>${esc(v)}</span></div>`; }

  /* ---------- import: PPTX ---------- */
  async function parsePPTX(file){
    const zip=await JSZip.loadAsync(file);
    const presFile=zip.file('ppt/presentation.xml');
    if(!presFile) throw new Error('Not a PowerPoint package (missing ppt/presentation.xml)');
    const pres=xml(await presFile.async('string'));
    const sz=first(pres,'sldSz'); const W=num(val(sz,'cx'))||DEFAULT_W, H=num(val(sz,'cy'))||DEFAULT_H;
    const rels=parseRels(await zip.file('ppt/_rels/presentation.xml.rels').async('string'));
    const ids=all(pres,'sldId');
    const project=newProject(baseName(file.name),'ember');
    project.slides=[];
    let slideNo=0;
    for(const id of ids){
      const rid=relAttr(id,'id');
      const target=rels[rid]&&rels[rid].target;
      if(!target) continue;
      const path=resolveTarget('ppt/presentation.xml',target);
      const f=zip.file(path); if(!f) continue;
      const doc=xml(await f.async('string'));
      const srels=parseRels(await (zip.file(relsPath(path))?.async('string')||''));
      const slide=baseSlide('ember','blank');
      slide.id=uid('sld');
      const bg=first(doc,'bgPr'); const bgClr=bg?first(bg,'srgbClr'):null;
      if(bgClr) slide.background='#'+val(bgClr,'val');
      const tree=first(doc,'spTree');
      let z=0;
      if(tree){
        // shapes with text
        all(tree,'sp').forEach(sp=>{
          const xf=first(sp,'xfrm'); const off=xf?first(xf,'off'):null, ext=xf?first(xf,'ext'):null;
          const x=off?num(val(off,'x'))/W*100:7, y=off?num(val(off,'y'))/H*100:7;
          const w=ext?num(val(ext,'cx'))/W*100:40, h=ext?num(val(ext,'cy'))/H*100:12;
          const tx=first(sp,'txBody');
          const paras=tx?kids(tx,'p'):[];
          const textHtml=parasToHtml(paras);
          const geom=first(sp,'prstGeom'); const prst=geom?val(geom,'prst'):'rect';
          const fill=first(sp,'solidFill'); const fillClr=fill?first(fill,'srgbClr'):null;
          const line=first(sp,'ln'); const lineFill=line?first(line,'solidFill'):null; const lineClr=lineFill?first(lineFill,'srgbClr'):null;
          if(textHtml){
            const rPr=first(tx,'rPr')||first(tx,'endParaRPr');
            const szv=rPr?num(val(rPr,'sz'))/100:18;
            const color=rPr?first(rPr,'srgbClr'):null;
            const algn=paras[0]?val(first(paras[0],'pPr')||{},'algn'):'';
            const el=JD.textEl(textHtml,clamp(x),clamp(y),Math.max(2,w),Math.max(2,h),{style:{
              fontSize:szv||18, bold:val(rPr||{},'b')==='1', italic:val(rPr||{},'i')==='1', underline:val(rPr||{},'u')==='sng',
              color:color?'#'+val(color,'val'):'fg',
              align:algn==='ctr'?'center':algn==='r'?'right':algn==='just'?'justify':'left',
              fill:fillClr?'#'+val(fillClr,'val'):'transparent',
              lineHeight:1.25
            }});
            el.z=++z; slide.elements.push(el);
          } else if(fillClr||lineClr){
            const el=JD.shapeEl(shapeName(prst),clamp(x),clamp(y),Math.max(1,w),Math.max(1,h),{style:{
              fill:fillClr?'#'+val(fillClr,'val'):'transparent',
              stroke:lineClr?'#'+val(lineClr,'val'):'transparent',
              strokeWidth:line?num(val(line,'w'))/EMU*72/9.6:0
            }});
            el.z=++z; slide.elements.push(el);
          }
        });
        // pictures
        all(tree,'pic').forEach(pic=>{
          const xf=first(pic,'xfrm'); const off=xf?first(xf,'off'):null, ext=xf?first(xf,'ext'):null;
          const x=off?num(val(off,'x'))/W*100:20, y=off?num(val(off,'y'))/H*100:20;
          const w=ext?num(val(ext,'cx'))/W*100:30, h=ext?num(val(ext,'cy'))/H*100:30;
          const blip=first(pic,'blip'); const rid=relAttr(blip,'embed');
          const rel=srels[rid]; if(!rel) return;
          const media=resolveTarget(path,rel.target);
          const mf=zip.file(media); if(!mf) return;
          const extn=extOf(media);
          const el=JD.imageEl('',clamp(x),clamp(y),Math.max(2,w),Math.max(2,h),{alt:val(first(pic,'cNvPr')||{},'descr')||baseName(media)});
          el._zipPath=media; el._mime=mimeFor(extn); el.z=++z; slide.elements.push(el);
        });
        // tables
        all(tree,'tbl').forEach(tbl=>{
          const rows=all(tbl,'tr'); const data=rows.map(r=>all(r,'tc').map(tc=>all(tc,'t').map(t=>t.textContent).join('')));
          if(!data.length) return;
          const gf=first(tree,'graphicFrame');
          const xf=gf?first(gf,'xfrm'):null; const off=xf?first(xf,'off'):null, ext=xf?first(xf,'ext'):null;
          const x=off?num(val(off,'x'))/W*100:8, y=off?num(val(off,'y'))/H*100:24;
          const w=ext?num(val(ext,'cx'))/W*100:84, h=ext?num(val(ext,'cy'))/H*100:50;
          const el=JD.tableEl(data,clamp(x),clamp(y),Math.max(10,w),Math.max(8,h)); el.z=++z; slide.elements.push(el);
        });
      }
      // notes
      const noteRel=Object.values(srels).find(r=>/notesSlide$/.test(r.type));
      if(noteRel){
        const nf=zip.file(resolveTarget(path,noteRel.target));
        if(nf){ const nd=xml(await nf.async('string')); slide.notes=all(nd,'p').map(p=>all(p,'t').map(t=>t.textContent).join('')).filter(Boolean).join('\n'); }
      }
      if(!slide.elements.length){ const t=makeLayout('titleContent','ember',{title:'Slide '+(slideNo+1),body:'<p>This slide had no readable content.</p>'}); slide.elements=t.elements; }
      project.slides.push(slide); slideNo++;
    }
    if(!project.slides.length) throw new Error('No slides found in this PowerPoint file');
    // hydrate images asynchronously
    for(const s of project.slides){ for(const e of s.elements){ if(e._zipPath){ try{ const bytes=await zip.file(e._zipPath).async('uint8array'); e.src=dataUrl(bytes,e._mime); }catch(err){} delete e._zipPath; delete e._mime; } } }
    project.name=baseName(file.name);
    return project;
  }
  const clamp = v => Math.max(-5,Math.min(105,v));
  function shapeName(prst){
    const map={rect:'rect',roundRect:'roundRect',ellipse:'ellipse',triangle:'triangle',diamond:'diamond',pentagon:'pentagon',hexagon:'hexagon',octagon:'octagon',star5:'star',rightArrow:'arrow',chevron:'chevron',wedgeRoundRectCallout:'callout',cloud:'cloud',heart:'heart',plus:'plus',line:'line'};
    return map[prst]||'rect';
  }
  function parasToHtml(paras){
    if(!paras||!paras.length) return '';
    const out=[];
    paras.forEach(p=>{
      const txt=all(p,'t').map(t=>t.textContent).join('');
      if(!txt.trim()){ return; }
      const pPr=first(p,'pPr');
      const bullet=pPr&&(first(pPr,'buChar')||first(pPr,'buAutoNum'));
      const lvl=pPr?num(val(pPr,'lvl')):0;
      out.push((bullet?'<li>':'<p>')+esc(txt)+(bullet?'</li>':'</p>'));
      if(lvl>0){} // indentation handled by list nesting at render time
    });
    let html=out.join('');
    // group consecutive list items
    html=html.replace(/(?:<li>[\s\S]*?<\/li>)+/g,m=>'<ul>'+m+'</ul>');
    return html;
  }

  /* ---------- import: DOCX ---------- */
  async function parseDOCX(file){
    const zip=await JSZip.loadAsync(file);
    const f=zip.file('word/document.xml'); if(!f) throw new Error('Not a Word package');
    const doc=xml(await f.async('string'));
    const paras=all(doc,'p');
    const blocks=[];
    paras.forEach(p=>{
      const txt=all(p,'t').map(t=>t.textContent).join('').trim();
      if(!txt) return;
      const pPr=first(p,'pPr'); const st=pPr?val(first(pPr,'pStyle')||{},'val'):'';
      let type='p';
      if(/^(Title|Heading1|1)$/i.test(st)) type='h1';
      else if(/^(Heading2|2)$/i.test(st)) type='h2';
      else if(/^(Heading3|3)$/i.test(st)) type='h3';
      else if(/^List/i.test(st)) type='li';
      blocks.push({type,text:txt});
    });
    if(!blocks.length) throw new Error('No readable text in this Word file');
    return blocksToProject(baseName(file.name),blocks);
  }

  /* ---------- import: XLSX ---------- */
  async function parseXLSX(file){
    const zip=await JSZip.loadAsync(file);
    const shared=[];
    const ss=zip.file('xl/sharedStrings.xml');
    if(ss){ const d=xml(await ss.async('string')); all(d,'si').forEach(si=>shared.push(all(si,'t').map(t=>t.textContent).join(''))); }
    const wb=zip.file('xl/workbook.xml');
    const sheets=[];
    if(wb){ const d=xml(await wb.async('string')); all(d,'sheet').forEach(s=>sheets.push({name:val(s,'name')||'Sheet',rid:relAttr(s,'id')})); }
    const wbrels=parseRels(await (zip.file('xl/_rels/workbook.xml.rels')?.async('string')||''));
    if(!sheets.length) sheets.push({name:'Sheet1',rid:''});
    const project=newProject(baseName(file.name),'paper'); project.slides=[];
    project.slides.push(makeLayout('title','paper',{kicker:'SPREADSHEET',title:baseName(file.name),subtitle:sheets.length+' sheet'+(sheets.length>1?'s':'')+' imported from Excel'}));
    for(const sh of sheets.slice(0,6)){
      const target=sh.rid&&wbrels[sh.rid]?wbrels[sh.rid].target:'worksheets/sheet1.xml';
      const path=resolveTarget('xl/workbook.xml',target);
      const sf=zip.file(path); if(!sf) continue;
      const d=xml(await sf.async('string'));
      const rows=all(d,'row').map(r=>{
        const cells=[];
        all(r,'c').forEach(c=>{
          const ref=val(c,'r'); const col=colIndex(ref); const t=val(c,'t');
          let v='';
          if(t==='s'){ const idx=num(val(first(c,'v')||{},'val')); v=shared[idx]||''; }
          else if(t==='inlineStr'){ v=all(c,'t').map(x=>x.textContent).join(''); }
          else { const vn=first(c,'v'); v=vn?vn.textContent:''; }
          cells[col]=v;
        });
        return cells;
      }).filter(r=>r.some(x=>x!=null&&x!==''));
      if(!rows.length) continue;
      const cols=Math.min(8,Math.max(...rows.map(r=>r.length)));
      const data=rows.map(r=>Array.from({length:cols},(_,i)=>r[i]==null?'':String(r[i])));
      const chunks=chunk(data,14);
      chunks.forEach((chunkRows,ci)=>{
        const s=makeLayout('titleContent','paper',{title:sh.name+(chunks.length>1?' ('+(ci+1)+')':''),body:'<p></p>'});
        s.elements=s.elements.filter(e=>e.type!=='text'||!(/Add your content/.test(e.content)));
        const tbl=JD.tableEl(chunkRows,7,22,86,Math.min(66,8+chunkRows.length*4.2),{header:ci===0,style:{fontSize:10,striped:true}});
        tbl.z=9; s.elements.push(tbl); project.slides.push(s);
      });
    }
    return project;
  }
  function colIndex(ref){ const m=String(ref).match(/^([A-Z]+)/i); if(!m) return 0; let n=0; for(const ch of m[1].toUpperCase()) n=n*26+(ch.charCodeAt(0)-64); return n-1; }
  function chunk(arr,n){ const out=[]; for(let i=0;i<arr.length;i+=n) out.push(arr.slice(i,i+n)); return out; }

  /* ---------- import: ODF (ODP/ODT) ---------- */
  async function parseODF(file,isText){
    const zip=await JSZip.loadAsync(file);
    const f=zip.file('content.xml'); if(!f) throw new Error('Not an OpenDocument package');
    const doc=xml(await f.async('string'));
    const pages=all(doc,'page');
    const project=newProject(baseName(file.name),'paper'); project.slides=[];
    const PW=isText?21:28, PH=isText?29.7:15.75;
    pages.forEach((pg,pi)=>{
      const s=baseSlide('paper','blank');
      let z=0;
      const frames=all(pg,'frame');
      frames.forEach(fr=>{
        const x=len(val(fr,'x'),PW), y=len(val(fr,'y'),PH), w=len(val(fr,'width'),PW), h=len(val(fr,'height'),PH);
        const paras=all(fr,'p').map(p=>p.textContent.trim()).filter(Boolean);
        if(paras.length){
          const el=JD.textEl(paras.map(t=>'<p>'+esc(t)+'</p>').join(''),clamp(x||7),clamp(y||7),Math.max(10,w||80),Math.max(4,h||10),{style:{fontSize:pi===0?28:16,bold:pi===0}});
          el.z=++z; s.elements.push(el);
        }
      });
      if(!s.elements.length){
        const text=all(pg,'p').map(p=>p.textContent.trim()).filter(Boolean);
        if(text.length){
          const title=text[0], rest=text.slice(1);
          s.elements=makeLayout('titleContent','paper',{title,body:'<ul>'+rest.map(t=>'<li>'+esc(t)+'</li>').join('')+'</ul>'}).elements;
        }
      }
      if(s.elements.length) project.slides.push(s);
    });
    if(!project.slides.length) throw new Error('No pages found');
    return project;
  }
  function len(v,pageCm){
    const m=String(v||'').match(/^([\d.]+)\s*(cm|mm|in|pt|pc)?/); if(!m) return 0;
    let n=parseFloat(m[1])||0; const u=m[2]||'cm';
    if(u==='mm') n/=10; else if(u==='in') n*=2.54; else if(u==='pt') n*=2.54/72; else if(u==='pc') n*=2.54/6;
    return n/pageCm*100;
  }

  /* ---------- blocks → slides ---------- */
  function blocksToProject(name,blocks){
    const project=newProject(name,'paper'); project.slides=[];
    const title=blocks.find(b=>b.type==='h1')?.text||name;
    project.slides.push(makeLayout('title','paper',{kicker:'DOCUMENT',title,subtitle:'Imported into j-Docs · '+today()}));
    let curTitle='', bullets=[], used=0;
    const flush=()=>{
      if(!bullets.length&&!curTitle) return;
      const body=bullets.length?'<ul>'+bullets.map(b=>'<li>'+esc(b)+'</li>').join('')+'</ul>':'<p></p>';
      project.slides.push(makeLayout('titleContent','paper',{title:curTitle||title,body}));
      bullets=[]; used=0;
    };
    const addText=(raw)=>{
      // Keep paragraphs intact where possible, but split very long paragraphs at word boundaries.
      const words=String(raw||'').split(/\s+/).filter(Boolean); let part='';
      for(const word of words){
        const next=part?part+' '+word:word;
        if(next.length>220&&part){
          if(used+part.length>480||bullets.length>=5) flush();
          bullets.push(part); used+=part.length; part=word;
        } else part=next;
      }
      if(part){ if(used+part.length>480||bullets.length>=5) flush(); bullets.push(part); used+=part.length; }
    };
    blocks.forEach(b=>{
      const value=String(b.text||'').trim(); if(!value)return;
      if(b.type==='h1'&&value===title) return;
      if(b.type==='h1'||b.type==='h2'){
        flush(); curTitle=value;
      } else {
        if(b.type==='h3') addText('— '+value);
        else addText(value);
        if(bullets.length>=5||used>=480) flush();
      }
    });
    flush();
    if(project.slides.length<2) project.slides.push(makeLayout('titleContent','paper',{title:'Content',body:'<p>'+esc(blocks.map(b=>b.text).join(' '))+'</p>'}));
    return project;
  }

  /* ---------- text / markdown / csv / html ---------- */
  function textToBlocks(text){
    const lines=String(text).replace(/\r/g,'').split('\n');
    const blocks=[];
    lines.forEach(line=>{
      const t=line.trim();
      if(!t){ return; }
      let m;
      if(m=t.match(/^#{1,2}\s+(.*)$/)) blocks.push({type:'h1',text:m[1]});
      else if(m=t.match(/^#{3,6}\s+(.*)$/)) blocks.push({type:'h2',text:m[1]});
      else if(m=t.match(/^[-*+]\s+(.*)$/)) blocks.push({type:'li',text:m[1].replace(/\*\*/g,'')});
      else if(m=t.match(/^\d+[.)]\s+(.*)$/)) blocks.push({type:'li',text:m[1]});
      else if(/^```/.test(t)) {}
      else blocks.push({type:'p',text:t.replace(/^>\s?/,'').replace(/\*\*(.*?)\*\*/g,'$1').replace(/\*(.*?)\*/g,'$1')});
    });
    return blocks;
  }
  function csvToData(text){
    const rows=[]; let row=[], cell='', q=false;
    for(let i=0;i<text.length;i++){
      const c=text[i];
      if(q){ if(c==='"'){ if(text[i+1]==='"'){cell+='"';i++;} else q=false; } else cell+=c; }
      else { if(c==='"') q=true; else if(c===','){ row.push(cell); cell=''; } else if(c==='\n'){ row.push(cell); rows.push(row); row=[]; cell=''; } else if(c!=='\r') cell+=c; }
    }
    row.push(cell); if(row.some(x=>x!=='')) rows.push(row);
    return rows;
  }
  function csvToProject(name,text){
    const rows=csvToData(text); const project=newProject(name,'paper'); project.slides=[];
    project.slides.push(makeLayout('title','paper',{kicker:'DATA',title:name,subtitle:rows.length+' rows · '+Math.max(0,(rows[0]||[]).length)+' columns'}));
    chunk(rows,16).forEach((rs,ci)=>{
      const cols=Math.max(...rs.map(r=>r.length));
      const data=rs.map(r=>Array.from({length:cols},(_,i)=>r[i]==null?'':r[i]));
      const s=makeLayout('titleContent','paper',{title:name+(ci?' ('+(ci+1)+')':''),body:'<p></p>'});
      s.elements=s.elements.filter(e=>e.type!=='text'||!/Add your content/.test(e.content));
      const tbl=JD.tableEl(data,7,22,86,Math.min(66,8+data.length*4.2),{header:ci===0,style:{fontSize:10}}); tbl.z=9; s.elements.push(tbl);
      project.slides.push(s);
    });
    return project;
  }
  function htmlToBlocks(html){
    const doc=new DOMParser().parseFromString(html,'text/html');
    const blocks=[];
    doc.body.querySelectorAll('h1,h2,h3,p,li,blockquote,pre').forEach(el=>{
      const t=el.textContent.trim(); if(!t) return;
      const tag=el.tagName.toLowerCase();
      if(tag==='h1'||tag==='h2') blocks.push({type:'h1',text:t});
      else if(tag==='h3') blocks.push({type:'h2',text:t});
      else if(tag==='li') blocks.push({type:'li',text:t});
      else blocks.push({type:'p',text:t});
    });
    return blocks;
  }

  /* ---------- open dispatcher ---------- */
  async function openFiles(files){
    files=[...files];
    if(!files.length) return;
    if(files.length>1){ toast('Opening '+files.length+' files…','info'); }
    for(const file of files){
      try{ await openOne(file); }
      catch(err){ console.error(err); toast('Could not open '+file.name+': '+(err?.message||'Unknown error'),'error'); try{ await openUnknown(file); }catch(fallbackErr){ console.error(fallbackErr); toast('Preview unavailable for '+file.name,'error'); } }
    }
  }

  async function openOne(file){
    const ext=extOf(file.name);
    const kind=kindOf(ext);
    switch(kind){
      case 'jdocs': return openProjectFile(file);
      case 'pptx': return importPresentation(file,'pptx');
      case 'docx': return importDocument(file,'docx');
      case 'xlsx': return importSpreadsheet(file,'xlsx');
      case 'odp': return importPresentation(file,'odp');
      case 'odt': return importDocument(file,'odt');
      case 'pdf': return openPDF(file);
      case 'text': return openText(file,ext);
      case 'csv': return openCSV(file);
      case 'html': return openHTML(file);
      case 'image': return openImage(file);
      case 'media': return openMedia(file);
      case 'font': return openFont(file);
      case 'zip': return openZip(file);
      default: return openUnknown(file);
    }
  }
  function kindOf(ext){
    if(['jdocs'].includes(ext)) return 'jdocs';
    if(['pptx','ppsx','potx','pptm'].includes(ext)) return 'pptx';
    if(['docx','docm'].includes(ext)) return 'docx';
    if(['xlsx','xlsm'].includes(ext)) return 'xlsx';
    if(['odp','fodp'].includes(ext)) return 'odp';
    if(['odt','fodt','rtf'].includes(ext)) return 'odt';
    if(ext==='pdf') return 'pdf';
    if(['txt','md','markdown','json','xml','yaml','yml','js','ts','css','py','java','c','cpp','h','sh','log','ini','toml','sql','svg'].includes(ext)) return ext==='svg'?'image':'text';
    if(['csv','tsv'].includes(ext)) return 'csv';
    if(['html','htm','xhtml'].includes(ext)) return 'html';
    if(['png','jpg','jpeg','gif','webp','bmp','avif','ico','tif','tiff'].includes(ext)) return 'image';
    if(['mp3','wav','m4a','ogg','flac','aac','mp4','webm','mov','mkv','avi'].includes(ext)) return 'media';
    if(['ttf','otf','woff','woff2'].includes(ext)) return 'font';
    if(['zip','jar','apk','epub','pptx'].includes(ext)) return ext==='pptx'?'pptx':'zip';
    return 'unknown';
  }

  /* ---------- project files ---------- */
  async function openProjectFile(file){
    const text=await readAsText(file);
    let p; try{ p=JSON.parse(text); }catch(e){ throw new Error('Invalid .jdocs JSON'); }
    if(!p.slides||!Array.isArray(p.slides)) throw new Error('This JSON is not a j-Docs project');
    applyProject(p,file.name);
  }
  function applyProject(p,name){
    p.name=p.name||baseName(name);
    if(!p.theme) p.theme='ember';
    Store.setProject(p);
    window.JDEditor?.refresh();
    toast('Opened “'+p.name+'” · '+p.slides.length+' slides','success');
  }
  function importPresentation(file,kind){
    const run=async()=>{
      toast('Reading '+file.name+'…','info');
      const project=kind==='pptx'?await parsePPTX(file):await parseODF(file,false);
      project.name=baseName(file.name);
      Store.setProject(project); window.JDEditor?.refresh();
      toast('Imported '+project.slides.length+' slides from '+file.name,'success');
    };
    return run();
  }
  function importDocument(file,kind){
    const run=async()=>{
      toast('Reading '+file.name+'…','info');
      let project;
      if(kind==='docx'){ project=await parseDOCX(file); }
      else { project=await parseODF(file,true); }
      Store.setProject(project); window.JDEditor?.refresh();
      toast('Imported document · '+project.slides.length+' slides','success');
    };
    return run();
  }
  function importSpreadsheet(file){
    const run=async()=>{
      toast('Reading spreadsheet…','info');
      const project=await parseXLSX(file);
      Store.setProject(project); window.JDEditor?.refresh();
      toast('Imported spreadsheet · '+project.slides.length+' slides','success');
    };
    return run();
  }

  /* ---------- PDF ---------- */
  async function openPDF(file){
    const buf=await readAsArrayBuffer(file);
    const bytes=new Uint8Array(buf);
    let pages=0; const txt=new TextDecoder('latin1').decode(bytes);
    const m=txt.match(/\/Type\s*\/Page[^s]/g); pages=m?m.length:0;
    const url=URL.createObjectURL(new Blob([buf],{type:'application/pdf'})); _urls.push(url);
    openViewer({
      title:file.name, sub:'PDF document · '+fmtBytes(file.size)+(pages?' · ~'+pages+' pages':''), icon:'pdf',
      preview:`<iframe src="${url}" title="${esc(file.name)}" style="width:100%;height:100%"></iframe>`,
      side:`<h4>Document</h4>${kv('Type','PDF')}${kv('Size',fmtBytes(file.size))}${kv('Pages',pages?('~'+pages):'—')}${kv('Modified',new Date(file.lastModified).toLocaleString())}
        <div class="fv-actions"><button class="btn btn-primary" data-pdf-import>${icon('file')} Import pages as slides</button><button class="btn btn-ghost" data-pdf-text>${icon('doc')} Extract text</button></div>
        <p class="muted" style="font-size:10.5px;line-height:1.5;margin-top:10px">PDF pages can be attached as full-page images or turned into an editable outline when the file contains selectable text.</p>`,
      actions:[{label:'Download',icon:'download',onClick:()=>download(new Blob([buf],{type:'application/pdf'}),file.name)},{label:'Insert as page',icon:'imagePlus',primary:true,onClick:()=>insertPDFPage(buf,file.name)}],
      onMount:root=>{
        root.querySelector('[data-pdf-text]')?.addEventListener('click',()=>{ toast('This PDF has '+(pages||'an unknown number of')+' pages. Text extraction works best on text-based PDFs.','info'); });
        root.querySelector('[data-pdf-import]')?.addEventListener('click',()=>insertPDFPage(buf,file.name));
      }
    });
  }
  async function insertPDFPage(buf,name){
    // Render first page to an image via an offscreen PDF iframe is not possible without pdf.js; attach the PDF as an embed instead.
    const url=URL.createObjectURL(new Blob([buf],{type:'application/pdf'})); _urls.push(url);
    const el={id:uid('emb'),type:'embed',x:10,y:10,w:80,h:80,rotation:0,z:1,src:url,title:name};
    Store.addElement(el); window.JDEditor?.refresh(); closeViewer(); toast('PDF attached to the slide','success');
  }

  /* ---------- text-like ---------- */
  async function openText(file,ext){
    const text=await readAsText(file);
    const isCode=['js','ts','css','py','java','c','cpp','h','sh','sql','json','xml','yaml','yml','toml','ini','log'].includes(ext);
    const preview=`<pre>${esc(text)}</pre>`;
    const side=`<h4>File</h4>${kv('Type',ext.toUpperCase()||'Text')}${kv('Size',fmtBytes(file.size))}${kv('Characters',text.length.toLocaleString())}${kv('Lines',text.split('\n').length.toLocaleString())}
      <div class="fv-actions">
        <button class="btn btn-primary" data-text-open>${icon('doc')} Open as document</button>
        <button class="btn btn-ghost" data-text-insert>${icon('textPlus')} Insert into slide</button>
        <button class="btn btn-ghost" data-text-copy>${icon('copy')} Copy text</button>
      </div>`;
    openViewer({
      title:file.name, sub:(isCode?'Source file':'Text document')+' · '+fmtBytes(file.size), icon:isCode?'code':'doc',
      preview, side,
      actions:[{label:'Download',icon:'download',onClick:()=>download(new Blob([text],{type:'text/plain'}),file.name)}],
      onMount:root=>{
        root.querySelector('[data-text-open]')?.addEventListener('click',()=>{
          const blocks=ext==='md'||ext==='markdown'?textToBlocks(text):textToBlocks(text);
          const project=blocksToProject(baseName(file.name),blocks);
          Store.setProject(project); window.JDEditor?.refresh(); closeViewer(); toast('Opened as '+project.slides.length+'-slide document','success');
        });
        root.querySelector('[data-text-insert]')?.addEventListener('click',()=>{
          const el=JD.textEl('<p>'+esc(text.slice(0,1200)).replace(/\n/g,'<br>')+'</p>',10,14,80,60,{style:{fontSize:12}});
          Store.addElement(el); window.JDEditor?.refresh(); closeViewer(); toast('Text inserted','success');
        });
        root.querySelector('[data-text-copy]')?.addEventListener('click',()=>{ navigator.clipboard?.writeText(text); toast('Copied to clipboard','success'); });
      }
    });
  }
  async function openCSV(file){
    const text=await readAsText(file);
    const rows=csvToData(text);
    const cols=Math.max(...rows.map(r=>r.length));
    const preview=`<div style="width:100%;overflow:auto"><table class="fv-table">${rows.slice(0,200).map((r,i)=>'<tr>'+Array.from({length:cols},(_,j)=>`<${i===0?'th':'td'}>${esc(r[j]||'')}</${i===0?'th':'td'}>`).join('')+'</tr>').join('')}</table></div>`;
    openViewer({
      title:file.name, sub:'Tabular data · '+rows.length+' rows × '+cols+' columns', icon:'csv',
      preview,
      side:`<h4>Data</h4>${kv('Rows',rows.length)}${kv('Columns',cols)}${kv('Size',fmtBytes(file.size))}
        <div class="fv-actions"><button class="btn btn-primary" data-csv-open>${icon('table')} Open as slides</button><button class="btn btn-ghost" data-csv-insert>${icon('tablePlus')} Insert table</button></div>`,
      onMount:root=>{
        root.querySelector('[data-csv-open]')?.addEventListener('click',()=>{ const p=csvToProject(baseName(file.name),text); Store.setProject(p); window.JDEditor?.refresh(); closeViewer(); toast('Opened spreadsheet as slides','success'); });
        root.querySelector('[data-csv-insert]')?.addEventListener('click',()=>{ const data=rows.slice(0,12).map(r=>Array.from({length:Math.min(cols,8)},(_,i)=>r[i]||'')); const el=JD.tableEl(data,8,22,84,Math.min(60,10+data.length*4)); Store.addElement(el); window.JDEditor?.refresh(); closeViewer(); toast('Table inserted','success'); });
      }
    });
  }
  async function openHTML(file){
    const text=await readAsText(file);
    const url=URL.createObjectURL(new Blob([text],{type:'text/html'})); _urls.push(url);
    openViewer({
      title:file.name, sub:'HTML document · '+fmtBytes(file.size), icon:'html',
      preview:`<iframe src="${url}" sandbox="allow-scripts" title="${esc(file.name)}" style="width:100%;height:100%"></iframe>`,
      side:`<h4>Web page</h4>${kv('Type','HTML')}${kv('Size',fmtBytes(file.size))}${kv('Title',(text.match(/<title[^>]*>([^<]*)/i)||[])[1]||'—')}
        <div class="fv-actions"><button class="btn btn-primary" data-html-open>${icon('doc')} Convert to slides</button><button class="btn btn-ghost" data-html-insert>${icon('html')} Embed in slide</button></div>`,
      onMount:root=>{
        root.querySelector('[data-html-open]')?.addEventListener('click',()=>{ const p=blocksToProject(baseName(file.name),htmlToBlocks(text)); Store.setProject(p); window.JDEditor?.refresh(); closeViewer(); toast('Converted HTML to '+p.slides.length+' slides','success'); });
        root.querySelector('[data-html-insert]')?.addEventListener('click',()=>{ Store.addElement({id:uid('emb'),type:'embed',x:10,y:10,w:80,h:78,rotation:0,z:1,src:url,title:file.name}); window.JDEditor?.refresh(); closeViewer(); toast('Web page embedded','success'); });
      }
    });
  }

  /* ---------- images / media / fonts ---------- */
  async function openImage(file){
    const src=await readAsDataURL(file);
    const img=new Image(); img.src=src; await new Promise(r=>{img.onload=r;img.onerror=r});
    openViewer({
      title:file.name, sub:'Image · '+img.width+' × '+img.height+' · '+fmtBytes(file.size), icon:'image',
      preview:`<img src="${src}" alt="${esc(file.name)}">`,
      side:`<h4>Image</h4>${kv('Dimensions',img.width+' × '+img.height)}${kv('Type',file.type||extOf(file.name).toUpperCase())}${kv('Size',fmtBytes(file.size))}
        <div class="fv-actions"><button class="btn btn-primary" data-img-insert>${icon('imagePlus')} Insert into slide</button><button class="btn btn-ghost" data-img-bg>${icon('background')} Set as background</button><button class="btn btn-ghost" data-img-slide>${icon('plus')} New picture slide</button></div>`,
      onMount:root=>{
        root.querySelector('[data-img-insert]')?.addEventListener('click',()=>insertImage(src,img,file.name));
        root.querySelector('[data-img-bg]')?.addEventListener('click',()=>{ Store.setBackground('url('+src+') center/cover no-repeat'); window.JDEditor?.refresh(); closeViewer(); toast('Background set','success'); });
        root.querySelector('[data-img-slide]')?.addEventListener('click',()=>{
          const s=makeLayout('pictureCaption','ember',{title:baseName(file.name),caption:file.name});
          const pic=JD.imageEl(src,7,20,86,58,{alt:baseName(file.name),fit:'cover'});
          s.elements.push(pic); Store.project.slides.splice(Store.current+1,0,s); Store.current++; Store.markDirty(); window.JDEditor?.refresh(); closeViewer(); toast('Picture slide added','success');
        });
      }
    });
  }
  function insertImage(src,img,name){
    const ratio=img.width&&img.height?img.width/img.height:16/9;
    let w=56,h=w*16/9/ratio; if(h>64){h=64;w=h*ratio*9/16;}
    const el=JD.imageEl(src,(100-w)/2,(100-h)/2,w,h,{alt:baseName(name),fit:'cover'});
    Store.addElement(el); window.JDEditor?.refresh(); closeViewer(); toast('Image inserted','success');
  }
  async function openMedia(file){
    const src=await readAsDataURL(file);
    const isAudio=file.type.startsWith('audio')||['mp3','wav','m4a','ogg','flac','aac'].includes(extOf(file.name));
    openViewer({
      title:file.name, sub:(isAudio?'Audio':'Video')+' · '+fmtBytes(file.size), icon:isAudio?'audio':'video',
      preview:isAudio?`<div style="display:grid;place-items:center;width:100%"><audio src="${src}" controls style="width:min(520px,100%)"></audio></div>`:`<video src="${src}" controls style="max-width:100%;max-height:100%"></video>`,
      side:`<h4>Media</h4>${kv('Type',isAudio?'Audio':'Video')}${kv('Size',fmtBytes(file.size))}${kv('Format',extOf(file.name).toUpperCase())}
        <div class="fv-actions"><button class="btn btn-primary" data-med-insert>${icon('media')} Insert into slide</button><button class="btn btn-ghost" data-med-slide>${icon('plus')} New media slide</button></div>
        <p class="muted" style="font-size:10.5px;line-height:1.5;margin-top:10px">Media is embedded in offline packages when the format and licence allow it.</p>`,
      onMount:root=>{
        root.querySelector('[data-med-insert]')?.addEventListener('click',()=>{ Store.addElement(JD.mediaEl(isAudio?'audio':'video',src,18,24,64,44,{controls:true})); window.JDEditor?.refresh(); closeViewer(); toast('Media inserted','success'); });
        root.querySelector('[data-med-slide]')?.addEventListener('click',()=>{ const s=makeLayout('titleOnly','ember',{title:baseName(file.name)}); s.elements.push(JD.mediaEl(isAudio?'audio':'video',src,14,24,72,48,{controls:true})); Store.project.slides.splice(Store.current+1,0,s); Store.current++; Store.markDirty(); window.JDEditor?.refresh(); closeViewer(); toast('Media slide added','success'); });
      }
    });
  }
  async function openFont(file){
    const buf=await readAsArrayBuffer(file);
    const family=baseName(file.name).replace(/[^a-z0-9 _-]/gi,'')||'Custom Font';
    try{
      const face=new FontFace(family,buf); await face.load(); document.fonts.add(face);
      (window.JD.customFonts=window.JD.customFonts||[]).push({family,file:file.name});
      toast('Font “'+family+'” is now available','success');
    }catch(e){ toast('Could not load font: '+e.message,'error'); }
    openViewer({
      title:file.name, sub:'Font file · '+fmtBytes(file.size), icon:'font',
      preview:`<div style="width:100%;padding:24px;background:#fff;color:#111;border-radius:8px"><div style="font-family:'${esc(family)}',sans-serif;font-size:46px;line-height:1.2">Aa Bb Cc 0123</div><div style="font-family:'${esc(family)}',sans-serif;font-size:16px;margin-top:10px;line-height:1.6">The quick brown fox jumps over the lazy dog. j-Docs can embed this font in offline packages when its licence permits redistribution.</div></div>`,
      side:`<h4>Font</h4>${kv('Family',family)}${kv('Format',extOf(file.name).toUpperCase())}${kv('Size',fmtBytes(file.size))}
        <p class="muted" style="font-size:10.5px;line-height:1.5;margin-top:10px">Check the font licence before sharing packages. j-Docs records the licence status in the offline manifest.</p>`
    });
  }

  /* ---------- zip ---------- */
  async function openZip(file){
    const zip=await JSZip.loadAsync(file);
    const entries=Object.values(zip.files).filter(f=>!f.dir);
    const rows=entries.slice(0,400).map(f=>`<div class="fv-kv"><span>${esc(f.name)}</span><span>${fmtBytes(f._data?f._data.uncompressedSize:0)}</span></div>`).join('');
    openViewer({
      title:file.name, sub:'Archive · '+entries.length+' files · '+fmtBytes(file.size), icon:'zip',
      preview:`<div style="width:100%;max-width:760px">${rows||'<p class="muted">Empty archive</p>'}</div>`,
      side:`<h4>Archive</h4>${kv('Files',entries.length)}${kv('Size',fmtBytes(file.size))}
        <div class="fv-actions"><button class="btn btn-primary" data-zip-open>${icon('folder')} Browse & open first file</button></div>`,
      onMount:root=>{
        root.querySelector('[data-zip-open]')?.addEventListener('click',async()=>{
          const first=entries.find(f=>/\.(pptx|docx|xlsx|pdf|txt|md|png|jpg|jpeg|csv|json|html)$/i.test(f.name));
          if(!first){ toast('No openable file found in archive','info'); return; }
          const blob=await zip.file(first.name).async('blob');
          const f=new File([blob],first.name.split('/').pop());
          closeViewer(); openFiles([f]);
        });
      }
    });
  }

  /* ---------- unknown binary ---------- */
  async function openUnknown(file){
    const buf=await readAsArrayBuffer(file);
    const bytes=new Uint8Array(buf);
    const head=bytes.slice(0,4096);
    const text=new TextDecoder('utf-8',{fatal:false}).decode(head);
    const printable=(text.match(/[\x09\x0a\x0d\x20-\x7e]/g)||[]).length/Math.max(1,text.length);
    const hex=hexDump(bytes.slice(0,1024));
    const magic=[...bytes.slice(0,8)].map(b=>b.toString(16).padStart(2,'0')).join(' ');
    const preview=printable>0.75?`<pre>${esc(text)}</pre>`:`<div style="width:100%"><h4 style="font-size:11px;text-transform:uppercase;color:var(--muted-2);margin:0 0 6px">Hex preview</h4><div class="fv-hex">${esc(hex)}</div></div>`;
    openViewer({
      title:file.name, sub:'Binary file · '+fmtBytes(file.size)+' · '+(file.type||'unknown type'), icon:'unknown',
      preview,
      side:`<h4>Metadata</h4>${kv('Name',file.name)}${kv('Extension',extOf(file.name)||'none')}${kv('MIME',file.type||'unknown')}${kv('Size',fmtBytes(file.size))}${kv('Modified',new Date(file.lastModified).toLocaleString())}${kv('Magic',magic)}
        <div class="fv-actions"><button class="btn btn-primary" data-unk-text>${icon('doc')} Open as plain text</button><button class="btn btn-ghost" data-unk-download>${icon('download')} Download</button></div>
        <p class="muted" style="font-size:10.5px;line-height:1.5;margin-top:10px">j-Docs opens every extension. Unknown formats are shown safely with metadata, a text preview and a hex inspector.</p>`,
      onMount:root=>{
        root.querySelector('[data-unk-text]')?.addEventListener('click',()=>{ const t=new TextDecoder('utf-8',{fatal:false}).decode(bytes); const p=blocksToProject(baseName(file.name),textToBlocks(t)); Store.setProject(p); window.JDEditor?.refresh(); closeViewer(); toast('Opened as text document','success'); });
        root.querySelector('[data-unk-download]')?.addEventListener('click',()=>download(new Blob([buf]),file.name));
      }
    });
  }
  function hexDump(bytes){
    const lines=[];
    for(let i=0;i<bytes.length;i+=16){
      const row=bytes.slice(i,i+16);
      const hex=[...row].map(b=>b.toString(16).padStart(2,'0')).join(' ').padEnd(47,' ');
      const ascii=[...row].map(b=>b>=32&&b<127?String.fromCharCode(b):'.').join('');
      lines.push(i.toString(16).padStart(8,'0')+'  '+hex+'  |'+ascii+'|');
    }
    return lines.join('\n');
  }

  /* ---------- save project ---------- */
  function saveProjectFile(){
    const data=JSON.stringify(Store.project,null,2);
    download(new Blob([data],{type:'application/json'}),safeName(Store.project.name)+'.jdocs');
    toast('Saved .jdocs project file','success');
  }
  function safeName(n){ return String(n||'presentation').replace(/[^\w\- ]+/g,'').trim().replace(/\s+/g,'-').slice(0,60)||'presentation'; }

  /* ---------- PPTX export ---------- */
  const escXml = s => String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  function emu(pct,total){ return Math.round(pct/100*total); }
  function colorHex(c,theme){
    if(!c) return '201F1E';
    if(/^#([0-9a-f]{6})$/i.test(c)) return c.slice(1).toUpperCase();
    if(/^#([0-9a-f]{3})$/i.test(c)) return c.slice(1).split('').map(x=>x+x).join('').toUpperCase();
    const map={fg:theme.fg,bg:theme.bg,muted:theme.muted,accent:theme.accent,accent2:theme.accent2,soft:theme.soft,line:theme.muted};
    const v=map[c]||c;
    return /^#([0-9a-f]{6})$/i.test(v)?v.slice(1).toUpperCase():'201F1E';
  }
  function runsXml(html,style,theme){
    const tmp=document.createElement('div'); tmp.innerHTML=window.JDRender.sanitize(html||'');
    const paras=[];
    const walk=el=>{
      const tag=el.tagName?el.tagName.toLowerCase():'';
      if(tag==='ul'||tag==='ol'){
        [...el.children].forEach(li=>paras.push({text:li.textContent.trim(),bullet:true,level:0}));
      } else if(tag==='p'||tag==='div'){
        const t=el.textContent.trim(); if(t) paras.push({text:t,bullet:false,level:0});
      } else if(tag==='li'){
        paras.push({text:el.textContent.trim(),bullet:true,level:0});
      }
    };
    [...tmp.children].forEach(walk);
    if(!paras.length){ const t=tmp.textContent.trim(); if(t) paras.push({text:t,bullet:false,level:0}); }
    if(!paras.length) paras.push({text:'',bullet:false,level:0});
    const sz=Math.round((style.fontSize||18)*100);
    const col=colorHex(style.color,theme);
    const b=style.bold?' b="1"':'';
    const i=style.italic?' i="1"':'';
    const u=style.underline?' u="sng"':'';
    const algn=style.align==='center'?' algn="ctr"':style.align==='right'?' algn="r"':style.align==='justify'?' algn="just"':'';
    return paras.map(p=>{
      const bu=p.bullet?'<a:buChar char="•"/>':'<a:buNone/>';
      return `<a:p><a:pPr${algn}>${bu}</a:pPr><a:r><a:rPr lang="en-US" sz="${sz}"${b}${i}${u} dirty="0"><a:solidFill><a:srgbClr val="${col}"/></a:solidFill><a:latin typeface="Segoe UI"/></a:rPr><a:t>${escXml(p.text)}</a:t></a:r></a:p>`;
    }).join('');
  }
  function spXml(e,theme,W,H,id){
    const x=emu(e.x,W),y=emu(e.y,H),cx=emu(Math.max(1,e.w),W),cy=emu(Math.max(1,e.h),H);
    if(e.type==='text'){
      const st=e.style||{};
      const fill=st.fill&&st.fill!=='transparent'?`<a:solidFill><a:srgbClr val="${colorHex(st.fill,theme)}"/></a:solidFill>`:'<a:noFill/>';
      return `<p:sp><p:nvSpPr><p:cNvPr id="${id}" name="Text ${id}"/><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm><a:off x="${x}" y="${y}"/><a:ext cx="${cx}" cy="${cy}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom>${fill}</p:spPr><p:txBody><a:bodyPr wrap="square" lIns="0" tIns="0" rIns="0" bIns="0"/><a:lstStyle/>${runsXml(e.content,st,theme)}</p:txBody></p:sp>`;
    }
    if(e.type==='shape'){
      const st=e.style||{};
      const fill=st.fill&&st.fill!=='transparent'?`<a:solidFill><a:srgbClr val="${colorHex(st.fill,theme)}"/></a:solidFill>`:'<a:noFill/>';
      const ln=st.stroke&&st.stroke!=='transparent'?`<a:ln w="${Math.round((st.strokeWidth||1)*12700)}"><a:solidFill><a:srgbClr val="${colorHex(st.stroke,theme)}"/></a:solidFill></a:ln>`:'<a:ln><a:noFill/></a:ln>';
      const prst=e.shape==='roundRect'?'roundRect':e.shape==='ellipse'?'ellipse':e.shape==='triangle'?'triangle':e.shape==='diamond'?'diamond':e.shape==='star'?'star5':e.shape==='arrow'?'rightArrow':'rect';
      return `<p:sp><p:nvSpPr><p:cNvPr id="${id}" name="Shape ${id}"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm><a:off x="${x}" y="${y}"/><a:ext cx="${cx}" cy="${cy}"/></a:xfrm><a:prstGeom prst="${prst}"><a:avLst/></a:prstGeom>${fill}${ln}</p:spPr></p:sp>`;
    }
    if(e.type==='image'&&e.src&&e.src.startsWith('data:')){
      return `<p:pic><p:nvPicPr><p:cNvPr id="${id}" name="Picture ${id}" descr="${escXml(e.alt||'')}"/><p:cNvPicPr><a:picLocks noChangeAspect="1"/></p:cNvPicPr><p:nvPr/></p:nvPicPr><p:blipFill><a:blip r:embed="rIdImg${id}"/><a:stretch><a:fillRect/></a:stretch></p:blipFill><p:spPr><a:xfrm><a:off x="${x}" y="${y}"/><a:ext cx="${cx}" cy="${cy}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr></p:pic>`;
    }
    if(e.type==='table'&&e.data&&e.data.length){
      const rows=e.data.slice(0,20), cols=Math.max(...rows.map(r=>r.length));
      const rowH=Math.round(cy/rows.length), colW=Math.round(cx/cols);
      const trs=rows.map((r,ri)=>'<a:tr h="'+rowH+'">'+Array.from({length:cols},(_,ci)=>`<a:tc><a:txBody><a:bodyPr/><a:lstStyle/><a:p><a:r><a:rPr lang="en-US" sz="1100"${ri===0&&e.header?' b="1"':''}><a:solidFill><a:srgbClr val="${ri===0&&e.header?'FFFFFF':colorHex((e.style||{}).color||'fg',theme)}"/></a:solidFill></a:rPr><a:t>${escXml(r[ci]==null?'':r[ci])}</a:t></a:r></a:p></a:txBody><a:tcPr><a:solidFill><a:srgbClr val="${ri===0&&e.header?colorHex((e.style||{}).headerFill||'accent',theme):'FFFFFF'}"/></a:solidFill></a:tcPr></a:tc>`).join('')+'</a:tr>').join('');
      return `<p:graphicFrame><p:nvGraphicFramePr><p:cNvPr id="${id}" name="Table ${id}"/><p:cNvGraphicFramePr/><p:nvPr/></p:nvGraphicFramePr><p:xfrm><a:off x="${x}" y="${y}"/><a:ext cx="${cx}" cy="${cy}"/></p:xfrm><a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/table"><a:tbl><a:tblPr firstRow="1" bandRow="1"/><a:tblGrid>${Array.from({length:cols},()=>'<a:gridCol w="'+colW+'"/>').join('')}</a:tblGrid>${trs}</a:tbl></a:graphicData></a:graphic></p:graphicFrame>`;
    }
    // fallback: text summary
    let text='';
    if(e.type==='chart') text=(e.style&&e.style.title||e.chartType)+' chart';
    else if(e.type==='code') text=e.code||'';
    else if(e.type==='icon') text='';
    else if(e.type==='media') text=(e.kind==='audio'?'Audio':'Video')+' clip';
    if(!text) return '';
    return `<p:sp><p:nvSpPr><p:cNvPr id="${id}" name="Text ${id}"/><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm><a:off x="${x}" y="${y}"/><a:ext cx="${cx}" cy="${cy}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:noFill/></p:spPr><p:txBody><a:bodyPr wrap="square"/><a:lstStyle/><a:p><a:r><a:rPr lang="en-US" sz="1200"><a:solidFill><a:srgbClr val="201F1E"/></a:solidFill></a:rPr><a:t>${escXml(text.slice(0,500))}</a:t></a:r></a:p></p:txBody></p:sp>`;
  }
  async function buildPPTXBlob(){
    const zip=new JSZip();
    const theme=Store.theme(); const W=DEFAULT_W,H=DEFAULT_H;
    const media=[]; let mediaN=0;
    const slidesXml=[];
    Store.project.slides.forEach((s,si)=>{
      let shapes=''; let id=2;
      const rels=[];
      (s.elements||[]).slice().sort((a,b)=>(a.z||0)-(b.z||0)).forEach(e=>{
        if(e.type==='image'&&e.src&&e.src.startsWith('data:')){
          const m=e.src.match(/^data:([^;]+);base64,(.*)$/);
          if(m){
            mediaN++; const ext=(m[1].split('/')[1]||'png').replace('jpeg','jpg');
            const path='image'+mediaN+'.'+ext;
            zip.file('ppt/media/'+path,m[2],{base64:true});
            media.push(path);
            const xmlsp=spXml(e,theme,W,H,id).replace('rIdImg'+id,'rId'+(10+mediaN));
            shapes+=xmlsp;
            rels.push(`<Relationship Id="rId${10+mediaN}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="../media/${path}"/>`);
            id++; return;
          }
        }
        const x=spXml(e,theme,W,H,id); if(x){ shapes+=x; id++; }
      });
      const bg=s.background&&/^#[0-9a-f]{6}$/i.test(s.background)?`<p:bg><p:bgPr><a:solidFill><a:srgbClr val="${s.background.slice(1)}"/></a:solidFill><a:effectLst/></p:bgPr></p:bg>`:'';
      const slideXml=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<p:sld xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"><p:cSld>${bg}<p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>${shapes}</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>`;
      zip.file('ppt/slides/slide'+(si+1)+'.xml',slideXml);
      zip.file('ppt/slides/_rels/slide'+(si+1)+'.xml.rels',`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout" Target="../slideLayouts/slideLayout1.xml"/>${rels.join('')}</Relationships>`);
      slidesXml.push(slideXml);
    });
    const n=Store.project.slides.length;
    const presRels=Array.from({length:n},(_,i)=>`<Relationship Id="rId${i+2}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide" Target="slides/slide${i+1}.xml"/>`).join('');
    zip.file('ppt/presentation.xml',`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<p:presentation xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" saveSubsetFonts="1"><p:sldMasterIdLst><p:sldMasterId id="2147483648" r:id="rId1"/></p:sldMasterIdLst><p:sldIdLst>${Array.from({length:n},(_,i)=>`<p:sldId id="${256+i}" r:id="rId${i+2}"/>`).join('')}</p:sldIdLst><p:sldSz cx="${W}" cy="${H}" type="screen16x9"/><p:notesSz cx="6858000" cy="9144000"/></p:presentation>`);
    zip.file('ppt/_rels/presentation.xml.rels',`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster" Target="slideMasters/slideMaster1.xml"/>${presRels}</Relationships>`);
    zip.file('ppt/slideMasters/slideMaster1.xml',`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<p:sldMaster xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"><p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr></p:spTree></p:cSld><p:clrMap bg1="lt1" tx1="dk1" bg2="lt2" tx2="dk2" accent1="accent1" accent2="accent2" accent3="accent3" accent4="accent4" accent5="accent5" accent6="accent6" hlink="hlink" folHlink="folHlink"/><p:sldLayoutIdLst><p:sldLayoutId id="2147483649" r:id="rId1"/></p:sldLayoutIdLst><p:txStyles><p:titleStyle><a:lvl1pPr algn="l"><a:defRPr sz="4400" b="1"><a:latin typeface="Segoe UI"/></a:defRPr></a:lvl1pPr></p:titleStyle><p:bodyStyle><a:lvl1pPr><a:defRPr sz="1800"><a:latin typeface="Segoe UI"/></a:defRPr></a:lvl1pPr></p:bodyStyle><p:otherStyle><a:lvl1pPr><a:defRPr sz="1800"><a:latin typeface="Segoe UI"/></a:defRPr></a:lvl1pPr></p:otherStyle></p:txStyles></p:sldMaster>`);
    zip.file('ppt/slideMasters/_rels/slideMaster1.xml.rels',`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout" Target="../slideLayouts/slideLayout1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme" Target="../theme/theme1.xml"/></Relationships>`);
    zip.file('ppt/slideLayouts/slideLayout1.xml',`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<p:sldLayout xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" type="blank" preserve="1"><p:cSld name="Blank"><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr></p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sldLayout>`);
    zip.file('ppt/slideLayouts/_rels/slideLayout1.xml.rels',`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster" Target="../slideMasters/slideMaster1.xml"/></Relationships>`);
    const accent=colorHex(theme.accent,theme), accent2=colorHex(theme.accent2,theme);
    zip.file('ppt/theme/theme1.xml',`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<a:theme xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" name="j-Docs"><a:themeElements><a:clrScheme name="j-Docs"><a:dk1><a:srgbClr val="201F1E"/></a:dk1><a:lt1><a:srgbClr val="FFFFFF"/></a:lt1><a:dk2><a:srgbClr val="3B3A39"/></a:dk2><a:lt2><a:srgbClr val="F3F2F1"/></a:lt2><a:accent1><a:srgbClr val="${accent}"/></a:accent1><a:accent2><a:srgbClr val="${accent2}"/></a:accent2><a:accent3><a:srgbClr val="2B579A"/></a:accent3><a:accent4><a:srgbClr val="0F7B6C"/></a:accent4><a:accent5><a:srgbClr val="C19A00"/></a:accent5><a:accent6><a:srgbClr val="7C3AED"/></a:accent6><a:hlink><a:srgbClr val="0563C1"/></a:hlink><a:folHlink><a:srgbClr val="954F72"/></a:folHlink></a:clrScheme><a:fontScheme name="Segoe UI"><a:majorFont><a:latin typeface="Segoe UI Semibold"/><a:ea typeface=""/><a:cs typeface=""/></a:majorFont><a:minorFont><a:latin typeface="Segoe UI"/><a:ea typeface=""/><a:cs typeface=""/></a:minorFont></a:fontScheme><a:fmtScheme name="j-Docs"><a:fillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:fillStyleLst><a:lnStyleLst><a:ln w="6350" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln></a:lnStyleLst><a:effectStyleLst><a:effectStyle><a:effectLst/></a:effectStyle></a:effectStyleLst><a:bgFillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:bgFillStyleLst></a:fmtScheme></a:themeElements></a:theme>`);
    zip.file('[Content_Types].xml',`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Default Extension="png" ContentType="image/png"/><Default Extension="jpg" ContentType="image/jpeg"/><Default Extension="jpeg" ContentType="image/jpeg"/><Default Extension="gif" ContentType="image/gif"/><Default Extension="webp" ContentType="image/webp"/><Override PartName="/ppt/presentation.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"/><Override PartName="/ppt/slideMasters/slideMaster1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml"/><Override PartName="/ppt/slideLayouts/slideLayout1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml"/><Override PartName="/ppt/theme/theme1.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/>${Array.from({length:n},(_,i)=>`<Override PartName="/ppt/slides/slide${i+1}.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>`).join('')}<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/><Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/></Types>`);
    zip.file('_rels/.rels',`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="ppt/presentation.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>`);
    zip.file('docProps/core.xml',`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>${escXml(Store.project.name)}</dc:title><dc:creator>j-Docs</dc:creator><cp:lastModifiedBy>j-Docs</cp:lastModifiedBy><dcterms:created xsi:type="dcterms:W3CDTF">${new Date().toISOString()}</dcterms:created><dcterms:modified xsi:type="dcterms:W3CDTF">${new Date().toISOString()}</dcterms:modified></cp:coreProperties>`);
    zip.file('docProps/app.xml',`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"><Application>j-Docs</Application><PresentationFormat>On-screen Show (16:9)</PresentationFormat><Slides>${n}</Slides><Company>j-Docs</Company></Properties>`);
    return zip.generateAsync({type:'blob',compression:'DEFLATE',compressionOptions:{level:6}});
  }
  async function exportPPTX(){
    try{
      toast('Building PowerPoint file…','info');
      const blob=await buildPPTXBlob();
      download(blob,safeName(Store.project.name)+'.pptx');
      toast('Exported '+Store.project.slides.length+' slides to PPTX','success');
    }catch(e){ console.error(e); toast('PPTX export failed: '+e.message,'error'); }
  }

  /* ---------- standalone HTML export ---------- */
  async function fontCss(){
    try{
      const reg=await fetch('fonts/Selawik-Regular.woff').then(r=>r.arrayBuffer());
      const bold=await fetch('fonts/Selawik-Bold.woff').then(r=>r.arrayBuffer());
      const b64=b=>{let s='';const u=new Uint8Array(b);for(let i=0;i<u.length;i+=0x8000)s+=String.fromCharCode.apply(null,u.subarray(i,i+0x8000));return btoa(s)};
      return `@font-face{font-family:Selawik;font-weight:400;src:url(data:font/woff;base64,${b64(reg)}) format('woff');font-display:swap}@font-face{font-family:Selawik;font-weight:700;src:url(data:font/woff;base64,${b64(bold)}) format('woff');font-display:swap}`;
    }catch(e){ return ''; }
  }
  async function buildHTML(){
    const R=window.JDRender, theme=Store.theme();
    const slides=Store.project.slides;
    const body=slides.map((s,i)=>`<section class="slide" id="s${i+1}" aria-label="Slide ${i+1}">${R.slideToHTML(s,theme)}<aside class="notes" hidden>${esc(s.notes||'')}</aside></section>`).join('');
    const font=await fontCss();
    const html=`<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc(Store.project.name)} · j-Docs</title>
<style>
${font}
:root{--accent:${theme.accent};--ink:${theme.fg};--bg:${theme.bg}}
*{box-sizing:border-box}
body{margin:0;background:#141312;color:#f4f1ee;font-family:"Segoe UI",Selawik,system-ui,sans-serif}
.top{position:sticky;top:0;z-index:20;display:flex;align-items:center;gap:12px;padding:10px 16px;background:rgba(20,19,18,.9);backdrop-filter:blur(12px);border-bottom:1px solid rgba(255,255,255,.1)}
.brand{display:flex;align-items:center;gap:8px;font-weight:700;letter-spacing:-.3px}
.brand i{width:22px;height:22px;border-radius:6px;background:linear-gradient(135deg,#ff8a4c,#c43e1c);display:inline-block}
.top h1{font-size:13px;font-weight:600;margin:0;color:rgba(255,255,255,.8);flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.top button{border:1px solid rgba(255,255,255,.16);background:rgba(255,255,255,.06);color:#fff;border-radius:7px;padding:6px 10px;font-size:12px;cursor:pointer}
.top button:hover{background:rgba(255,255,255,.14)}
.deck{max-width:1180px;margin:0 auto;padding:24px 16px 80px}
.slide{position:relative;width:100%;aspect-ratio:16/9;margin:0 0 22px;background:#fff;border-radius:4px;overflow:hidden;box-shadow:0 12px 40px rgba(0,0,0,.4);container-type:size}
.slide .slide-canvas{width:100%;height:100%;position:relative;overflow:hidden;container-type:size}
.el{position:absolute}
.txt{width:100%;height:100%;overflow:hidden;word-wrap:break-word}
.txt p{margin:0 0 .55em}.txt ul,.txt ol{margin:0 0 .55em;padding-left:1.2em}.txt li{margin:0 0 .25em}
.txt h1,.txt h2,.txt h3{margin:0 0 .4em}
.txt a{color:inherit}
table{border-collapse:collapse;width:100%;height:100%}td,th{padding:.35em .5em;border:1px solid rgba(0,0,0,.15);text-align:left}
.media-ph{display:grid;place-items:center;height:100%;background:rgba(0,0,0,.06);font-size:12px}
.notes{display:none}
.nav{position:fixed;bottom:16px;left:50%;transform:translateX(-50%);display:flex;align-items:center;gap:6px;background:rgba(25,24,23,.92);border:1px solid rgba(255,255,255,.14);border-radius:99px;padding:6px 10px;z-index:30;backdrop-filter:blur(12px)}
.nav button{width:32px;height:32px;border:0;background:transparent;color:#fff;border-radius:50%;cursor:pointer;font-size:15px}
.nav button:hover{background:rgba(255,255,255,.14)}
.nav .count{font-size:11px;color:rgba(255,255,255,.7);min-width:52px;text-align:center;font-variant-numeric:tabular-nums}
.progress{position:fixed;top:0;left:0;height:3px;background:var(--accent);z-index:40;transition:width .25s}
body.present{background:#0a0908}
body.present .top,body.present .nav{display:none}
body.present .deck{padding:0;max-width:none}
body.present .slide{position:fixed;inset:0;width:100vw;height:100vh;aspect-ratio:auto;margin:0;border-radius:0;box-shadow:none;display:none}
body.present .slide.active{display:block}
body.present .slide .slide-canvas{width:100%;height:100%}
@media print{body{background:#fff}.top,.nav,.progress{display:none}.deck{padding:0;max-width:none}.slide{box-shadow:none;border:0;margin:0;page-break-after:always;break-after:page;border-radius:0}.slide:last-child{page-break-after:auto}}
</style></head>
<body>
<div class="progress" id="prog"></div>
<header class="top"><span class="brand"><i></i>j-Docs</span><h1>${esc(Store.project.name)}</h1><button id="notesBtn">Notes</button><button id="presentBtn">Present</button><button onclick="window.print()">Print / PDF</button></header>
<main class="deck" id="deck">${body}</main>
<nav class="nav" aria-label="Slide navigation"><button id="prev" aria-label="Previous slide">‹</button><span class="count" id="count">1 / ${slides.length}</span><button id="next" aria-label="Next slide">›</button></nav>
<script>
(function(){
  var slides=[].slice.call(document.querySelectorAll('.slide')),i=0,notes=false;
  function show(n){ i=Math.max(0,Math.min(slides.length-1,n)); slides.forEach(function(s,k){s.classList.toggle('active',k===i)}); document.getElementById('count').textContent=(i+1)+' / '+slides.length; document.getElementById('prog').style.width=((i+1)/slides.length*100)+'%'; if(location.hash!=='#s'+(i+1)) history.replaceState(null,'','#s'+(i+1)); }
  document.getElementById('prev').onclick=function(){show(i-1)}; document.getElementById('next').onclick=function(){show(i+1)};
  document.getElementById('notesBtn').onclick=function(){ notes=!notes; slides.forEach(function(s){var n=s.querySelector('.notes'); if(n)n.hidden=!notes;}); this.textContent=notes?'Hide notes':'Notes'; };
  document.getElementById('presentBtn').onclick=function(){ document.body.classList.add('present'); show(i); if(document.documentElement.requestFullscreen)document.documentElement.requestFullscreen().catch(function(){}); };
  document.addEventListener('keydown',function(e){
    if(e.key==='ArrowRight'||e.key==='PageDown'||e.key===' '){e.preventDefault();show(i+1)}
    else if(e.key==='ArrowLeft'||e.key==='PageUp'){e.preventDefault();show(i-1)}
    else if(e.key==='Home'){show(0)} else if(e.key==='End'){show(slides.length-1)}
    else if(e.key==='Escape'){document.body.classList.remove('present'); if(document.exitFullscreen)document.exitFullscreen().catch(function(){})}
    else if(e.key==='n'||e.key==='N'){document.getElementById('notesBtn').click()}
  });
  var m=location.hash.match(/^#s(\\d+)/); show(m?parseInt(m[1],10)-1:0);
})();
</script>
</body></html>`;
    return html;
  }
  async function exportHTML(){
    const html=await buildHTML();
    download(new Blob([html],{type:'text/html'}),safeName(Store.project.name)+'-web.html');
    toast('Exported standalone web experience','success');
  }

  function toast(msg,type){ if(window.JDApp&&window.JDApp.toast) window.JDApp.toast(msg,type); else console.log('[j-Docs]',msg); }

  /* ---------- drag & drop ---------- */
  function initDrop(){
    const ov=document.createElement('div');
    ov.className='drop-overlay';
    ov.innerHTML=`<div class="drop-card">${icon('upload')}<h3>Drop anything into j-Docs</h3><p>PPTX, DOCX, XLSX, ODP, PDF, images, audio, video, fonts, ZIP, text, code — every extension opens.</p></div>`;
    document.body.appendChild(ov);
    let depth=0;
    const hasFiles=e=>e.dataTransfer&&[...(e.dataTransfer.types||[])].includes('Files');
    window.addEventListener('dragenter',e=>{ if(!hasFiles(e))return; e.preventDefault(); depth++; ov.classList.add('show'); });
    window.addEventListener('dragover',e=>{ if(hasFiles(e)){e.preventDefault(); e.dataTransfer.dropEffect='copy';} });
    window.addEventListener('dragleave',e=>{ if(!hasFiles(e))return; depth=Math.max(0,depth-1); if(!depth)ov.classList.remove('show'); });
    window.addEventListener('drop',e=>{
      if(!hasFiles(e))return; e.preventDefault(); depth=0; ov.classList.remove('show');
      const files=[...(e.dataTransfer.files||[])];
      if(files.length) openFiles(files);
    });
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',initDrop); else initDrop();

  window.JDIO={openFiles,openOne,openViewer,closeViewer,exportPPTX,exportHTML,buildHTML,saveProjectFile,buildPPTXBlob,parsePPTX,parseDOCX,parseXLSX,parseODF,csvToData,textToBlocks,blocksToProject,safeName,kindOf};
})();
