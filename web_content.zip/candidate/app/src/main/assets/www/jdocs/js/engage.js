/* j-Docs — audience engagement: polls, Q&A, word cloud, ratings, anonymised analytics */
(function(){
  const {Store,uid,esc,clone,download,today} = window.JD;
  const $ = (s,r=document)=>r.querySelector(s);
  const $$ = (s,r=document)=>[...r.querySelectorAll(s)];
  const icon=(n,o)=>window.jIcon?window.jIcon(n,Object.assign({size:16},o||{})):'';
  const KEY='jdocs.engage.v1';
  const CH='jdocs-engage';

  function blank(){
    return {
      code:makeCode(), createdAt:Date.now(), active:null,
      polls:[], responses:[], questions:[], ratings:[], words:[],
      settings:{anonymous:true}
    };
  }
  function makeCode(){
    const A='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let s=''; for(let i=0;i<6;i++) s+=A[Math.floor(Math.random()*A.length)];
    return s;
  }
  function load(){
    try{ const raw=localStorage.getItem(KEY); if(raw){ const d=JSON.parse(raw); if(d&&d.code) return d; } }catch(e){}
    return blank();
  }
  function save(d){ try{ localStorage.setItem(KEY,JSON.stringify(d)); }catch(e){} }
  function channel(){ try{ return new BroadcastChannel(CH); }catch(e){ return null; } }
  function push(d,item){
    item.at=new Date().toISOString();
    d.responses.push(item);
    if(item.type==='poll'&&item.pollId){ const p=d.polls.find(x=>x.id===item.pollId); if(p){ p.votes=p.votes||{}; p.votes[item.answer]=(p.votes[item.answer]||0)+1; } }
    if(item.type==='rating') d.ratings.push(Number(item.answer)||0);
    if(item.type==='word'){ String(item.answer).split(/[\s,]+/).filter(Boolean).forEach(w=>{ const k=w.toLowerCase().slice(0,24); const f=d.words.find(x=>x.word===k); if(f) f.n++; else d.words.push({word:k,n:1}); }); }
    if(item.type==='question') d.questions.push({id:uid('q'),text:item.answer,at:item.at,answered:false});
    save(d);
    const ch=channel(); if(ch){ try{ ch.postMessage({type:'response',item}); ch.close(); }catch(e){} }
    window.dispatchEvent(new CustomEvent('jdocs-engage',{detail:item}));
  }

  const E = {
    data:load(), _ch:null, _audiencePoll:null,

    init(){
      this._ch=channel();
      if(this._ch) this._ch.onmessage=(ev)=>{ if(ev.data&&ev.data.type==='response'){ this.data=load(); if($('#audienceRoot')&&!$('#audienceRoot').hidden) this.renderAudience(); } };
      window.addEventListener('storage',e=>{ if(e.key===KEY){ this.data=load(); } });
      window.addEventListener('jdocs-engage',()=>{ this.data=load(); });
      const m=(location.hash||'').match(/audience=([A-Z0-9]+)/i);
      if(m){ setTimeout(()=>this.previewAudience(m[1].toUpperCase()),400); }
    },

    /* ---------------- presenter control panel ---------------- */
    open(tab='live'){
      this.data=load();
      const el=window.JDApp.modal({
        title:'Audience engagement', sub:'Polls, Q&A, word clouds and ratings — optional, anonymised, and stored only on this device.',
        wide:true, tall:true,
        tabs:[
          {id:'live',label:'Live',html:this.liveHTML(),onMount:(b)=>this.mountLive(b)},
          {id:'polls',label:'Polls',html:this.pollsHTML(),onMount:(b)=>this.mountPolls(b)},
          {id:'qa',label:'Q&A',html:this.qaHTML(),onMount:(b)=>this.mountQA(b)},
          {id:'words',label:'Word cloud',html:this.wordsHTML(),onMount:(b)=>this.mountWords(b)},
          {id:'ratings',label:'Ratings',html:this.ratingsHTML(),onMount:(b)=>this.mountRatings(b)},
          {id:'analytics',label:'Analytics',html:this.analyticsHTML(),onMount:(b)=>this.mountAnalytics(b)},
          {id:'join',label:'Join',html:this.joinHTML(),onMount:(b)=>this.mountJoin(b)}
        ]
      });
      if(tab==='analytics'){ setTimeout(()=>{ const t=el.querySelector('[data-mtab="analytics"]'); if(t) t.click(); },30); }
      return el;
    },
    liveHTML(){
      const d=this.data;
      const p=d.active?d.polls.find(x=>x.id===d.active):null;
      return `<div class="row wrap" style="gap:14px;align-items:flex-start">
        <div style="flex:1;min-width:260px">
          <div class="a11y-item" style="align-items:center;margin-bottom:10px"><div style="flex:1"><strong>Session ${esc(d.code)}</strong><div class="muted" style="font-size:10.5px">${d.responses.length} responses · ${d.questions.filter(q=>!q.answered).length} open questions</div></div><span class="aud-live"><i></i>Ready</span></div>
          ${p?`<div class="a11y-item" style="display:block"><strong>${esc(p.question)}</strong><div style="margin-top:8px">${this.pollBars(p)}</div><div class="row" style="gap:6px;margin-top:8px"><button class="btn btn-ghost" id="en-close-poll" style="font-size:10px">Close poll</button></div></div>`:'<div class="command-empty">No poll is live. Create one in the Polls tab.</div>'}
          <div class="row" style="gap:7px;margin-top:12px;flex-wrap:wrap"><button class="btn btn-primary" id="en-aud">${icon('users')} Open audience view</button><button class="btn btn-ghost" id="en-copy">${icon('copy')} Copy join link</button></div>
        </div>
        <div style="text-align:center"><div class="qr-box" id="en-qr"></div><div class="session-code" style="margin-top:8px;font-size:18px;letter-spacing:3px">${esc(d.code)}</div><div class="form-hint" style="margin-top:4px">Join code</div></div>
      </div>`;
    },
    mountLive(b){
      const d=this.data;
      try{ if(window.qrcode){ const qr=qrcode(0,'M'); qr.addData(this.joinLink()); qr.make(); $('#en-qr',b).innerHTML=qr.createImgTag(4,0); } }catch(e){}
      $('#en-aud',b).onclick=()=>{ window.JDApp.closeModal(); this.previewAudience(); };
      $('#en-copy',b).onclick=async()=>{ try{ await navigator.clipboard.writeText(this.joinLink()); window.JDApp.toast('Join link copied','success'); }catch(e){ window.JDApp.toast('Copy failed','error'); } };
      const cp=$('#en-close-poll',b); if(cp) cp.onclick=()=>{ d.active=null; save(d); window.JDApp.closeModal(); this.open('live'); };
    },
    pollsHTML(){
      const d=this.data;
      return `<div class="row wrap" style="gap:10px;margin-bottom:12px">
        <input class="form-input" id="pl-q" placeholder="Poll question…" style="flex:1;min-width:220px">
        <input class="form-input" id="pl-opts" placeholder="Options, comma separated" style="flex:1;min-width:220px" value="Yes, No, Not sure">
        <button class="btn btn-primary" id="pl-add">${icon('plus')} Create poll</button>
      </div>
      <div id="pl-list">${d.polls.length?d.polls.map(p=>`<div class="a11y-item" style="display:block;margin-bottom:8px"><div class="row" style="justify-content:space-between"><strong>${esc(p.question)}</strong><span class="muted" style="font-size:10px">${p.votes?Object.values(p.votes).reduce((a,b)=>a+b,0):0} votes</span></div><div style="margin-top:7px">${this.pollBars(p)}</div><div class="row" style="gap:6px;margin-top:7px"><button class="btn btn-ghost" data-pl-live="${p.id}" style="font-size:10px">${d.active===p.id?'Live':'Go live'}</button><button class="btn btn-ghost" data-pl-del="${p.id}" style="font-size:10px">Delete</button></div></div>`).join(''):'<div class="command-empty">No polls yet. Create one above.</div>'}</div>`;
    },
    mountPolls(b){
      const d=this.data;
      $('#pl-add',b).onclick=()=>{
        const q=$('#pl-q',b).value.trim(); const opts=$('#pl-opts',b).value.split(',').map(s=>s.trim()).filter(Boolean);
        if(!q||opts.length<2){ window.JDApp.toast('Add a question and at least two options','info'); return; }
        const p={id:uid('poll'),question:q,options:opts,votes:{}};
        d.polls.push(p); d.active=p.id; save(d); window.JDApp.closeModal(); this.open('polls'); window.JDApp.toast('Poll is live','success');
      };
      $$('[data-pl-live]',b).forEach(x=>x.onclick=()=>{ d.active=x.dataset.plLive; save(d); window.JDApp.closeModal(); this.open('polls'); });
      $$('[data-pl-del]',b).forEach(x=>x.onclick=()=>{ d.polls=d.polls.filter(p=>p.id!==x.dataset.plDel); if(d.active===x.dataset.plDel)d.active=null; save(d); window.JDApp.closeModal(); this.open('polls'); });
    },
    pollBars(p){
      const total=Object.values(p.votes||{}).reduce((a,b)=>a+b,0)||1;
      return p.options.map(o=>{ const n=(p.votes||{})[o]||0; const pct=Math.round(n/total*100); return `<div class="bar-row"><span class="bar-label">${esc(o)}</span><span class="bar-track"><span class="bar-fill" style="width:${pct}%"></span></span><span class="bar-val">${pct}%</span></div>`; }).join('');
    },
    qaHTML(){
      const d=this.data;
      return `<div class="row" style="gap:8px;margin-bottom:10px"><input class="form-input" id="qa-add" placeholder="Add a question on behalf of the room…" style="flex:1"><button class="btn btn-ghost" id="qa-add-btn">${icon('plus')} Add</button></div>
        <div id="qa-list">${d.questions.length?d.questions.slice().reverse().map(q=>`<div class="a11y-item" style="margin-bottom:6px;align-items:center"><div style="flex:1"><div>${esc(q.text)}</div><div class="muted" style="font-size:10px">${new Date(q.at).toLocaleTimeString()} · ${q.answered?'answered':'open'}</div></div><button class="btn btn-ghost" data-qa="${q.id}" style="font-size:10px">${q.answered?'Reopen':'Mark answered'}</button></div>`).join(''):'<div class="command-empty">No questions yet. Share the join link to collect them.</div>'}</div>`;
    },
    mountQA(b){
      const d=this.data;
      $('#qa-add-btn',b).onclick=()=>{ const t=$('#qa-add',b).value.trim(); if(!t)return; push(d,{type:'question',question:'Q&A',answer:t}); window.JDApp.closeModal(); this.open('qa'); };
      $$('[data-qa]',b).forEach(x=>x.onclick=()=>{ const q=d.questions.find(q=>q.id===x.dataset.qa); if(q){q.answered=!q.answered;save(d);} window.JDApp.closeModal(); this.open('qa'); });
    },
    wordsHTML(){
      const d=this.data; const max=Math.max(1,...d.words.map(w=>w.n));
      return `<div class="row" style="gap:8px;margin-bottom:10px"><input class="form-input" id="wc-prompt" placeholder="Prompt, e.g. One word for today…" value="One word for today…" style="flex:1"><button class="btn btn-ghost" id="wc-add">${icon('plus')} Add word</button></div>
        <div class="wordcloud">${d.words.length?d.words.slice().sort((a,b)=>b.n-a.n).slice(0,60).map(w=>`<span style="font-size:${12+Math.round(w.n/max*26)}px;color:${['var(--accent)','var(--jblue)','var(--jteal)','var(--jpurple)','var(--jgold)'][w.word.length%5]}">${esc(w.word)}</span>`).join(''):'<span class="muted">Words will appear here as the audience responds.</span>'}</div>
        <div class="form-hint" style="margin-top:8px">${d.words.reduce((a,w)=>a+w.n,0)} words collected · common filler words are kept so you can see the raw room voice.</div>`;
    },
    mountWords(b){
      const d=this.data;
      $('#wc-add',b).onclick=()=>{ const w=$('#wc-add',b).value.trim()||prompt('Add a word','collaboration'); if(!w)return; push(d,{type:'word',question:$('#wc-prompt',b).value,answer:w}); window.JDApp.closeModal(); this.open('words'); };
    },
    ratingsHTML(){
      const d=this.data; const n=d.ratings.length; const avg=n?(d.ratings.reduce((a,b)=>a+b,0)/n):0;
      const dist=[1,2,3,4,5].map(v=>({v,n:d.ratings.filter(r=>r===v).length}));
      return `<div class="stat-grid" style="margin-bottom:12px"><div class="stat-card"><div class="stat-value">${avg?avg.toFixed(1):'—'}</div><div class="stat-label">Average rating</div></div><div class="stat-card"><div class="stat-value">${n}</div><div class="stat-label">Responses</div></div></div>
        ${dist.map(x=>`<div class="bar-row"><span class="bar-label">${'★'.repeat(x.v)}</span><span class="bar-track"><span class="bar-fill" style="width:${n?Math.round(x.n/n*100):0}%"></span></span><span class="bar-val">${x.n}</span></div>`).join('')}
        <div class="row" style="gap:7px;margin-top:10px"><button class="btn btn-ghost" id="rt-demo">Add a sample rating</button></div>`;
    },
    mountRatings(b){
      const d=this.data;
      $('#rt-demo',b).onclick=()=>{ push(d,{type:'rating',question:'How was the session?',answer:Math.ceil(Math.random()*5)}); window.JDApp.closeModal(); this.open('ratings'); };
    },
    analyticsHTML(){
      const d=this.data;
      const byType={}; d.responses.forEach(r=>byType[r.type]=(byType[r.type]||0)+1);
      const polls=d.polls.length, votes=d.polls.reduce((a,p)=>a+Object.values(p.votes||{}).reduce((x,y)=>x+y,0),0);
      return `<div class="stat-grid" style="margin-bottom:12px">
        <div class="stat-card"><div class="stat-value">${d.responses.length}</div><div class="stat-label">Total responses</div></div>
        <div class="stat-card"><div class="stat-value">${polls}</div><div class="stat-label">Polls</div></div>
        <div class="stat-card"><div class="stat-value">${votes}</div><div class="stat-label">Poll votes</div></div>
        <div class="stat-card"><div class="stat-value">${d.questions.length}</div><div class="stat-label">Questions</div></div>
        <div class="stat-card"><div class="stat-value">${d.words.reduce((a,w)=>a+w.n,0)}</div><div class="stat-label">Words</div></div>
      </div>
      <div class="a11y-item" style="margin-bottom:10px"><div style="flex:1"><strong>Anonymised by design</strong><div style="font-size:10.5px">No names, emails, IP addresses or device identifiers are stored. Each response is a timestamp and an answer.</div></div></div>
      ${Object.keys(byType).length?Object.entries(byType).map(([k,v])=>`<div class="bar-row"><span class="bar-label">${esc(k)}</span><span class="bar-track"><span class="bar-fill" style="width:${Math.round(v/Math.max(1,d.responses.length)*100)}%"></span></span><span class="bar-val">${v}</span></div>`).join(''):'<div class="command-empty">No responses yet.</div>'}
      <div class="row" style="gap:7px;margin-top:12px"><button class="btn btn-primary" id="an-csv">${icon('download')} Export CSV</button><button class="btn btn-ghost" id="an-clear">Clear responses</button></div>`;
    },
    mountAnalytics(b){
      $('#an-csv',b).onclick=()=>this.exportResponses();
      $('#an-clear',b).onclick=()=>{ if(!confirm('Clear all audience responses on this device?'))return; this.data.responses=[]; this.data.ratings=[]; this.data.words=[]; this.data.questions=[]; this.data.polls.forEach(p=>p.votes={}); save(this.data); window.JDApp.closeModal(); this.open('analytics'); };
    },
    joinHTML(){
      const d=this.data;
      return `<div class="row wrap" style="gap:16px;align-items:flex-start"><div style="flex:1;min-width:240px"><div class="form-field"><span class="form-label">Join link</span><div class="join-link">${esc(this.joinLink())}</div></div><div class="row" style="gap:7px;margin-top:10px"><button class="btn btn-primary" id="jn-copy">${icon('copy')} Copy</button><button class="btn btn-ghost" id="jn-aud">${icon('users')} Preview audience</button></div><div class="form-hint" style="margin-top:10px">Share this link or the code <strong>${esc(d.code)}</strong>. Responses sync across tabs on this device via a local broadcast channel — no server, no account.</div></div><div style="text-align:center"><div class="qr-box" id="jn-qr"></div><div class="form-hint" style="margin-top:6px">Scan to join</div></div></div>`;
    },
    mountJoin(b){
      try{ if(window.qrcode){ const qr=qrcode(0,'M'); qr.addData(this.joinLink()); qr.make(); $('#jn-qr',b).innerHTML=qr.createImgTag(4,0); } }catch(e){}
      $('#jn-copy',b).onclick=async()=>{ try{ await navigator.clipboard.writeText(this.joinLink()); window.JDApp.toast('Join link copied','success'); }catch(e){ window.JDApp.toast('Copy failed','error'); } };
      $('#jn-aud',b).onclick=()=>{ window.JDApp.closeModal(); this.previewAudience(); };
    },
    joinLink(){ return location.href.split('#')[0]+'#audience='+this.data.code; },

    /* ---------------- audience experience ---------------- */
    previewAudience(code){
      this.data=load();
      if(code && code!==this.data.code){ this.data.code=code; save(this.data); }
      const root=$('#audienceRoot'); if(!root) return;
      root.hidden=false;
      this._audiencePoll=this.data.active?this.data.polls.find(p=>p.id===this.data.active):null;
      this.renderAudience();
    },
    renderAudience(){
      const root=$('#audienceRoot'); if(!root||root.hidden) return;
      const d=this.data; const p=this._audiencePoll||(d.active?d.polls.find(x=>x.id===d.active):null);
      const done=this._audienceDone;
      root.innerHTML=`<div class="aud-hero">
        <div class="aud-brand"><span class="brand-mark">${icon('doc',{size:18})}</span><strong>j-Docs Live</strong><span class="aud-live" style="margin-left:auto"><i></i>${esc(d.code)}</span></div>
        <div class="aud-card">
          ${done?`<div class="aud-thanks"><div class="tick">${icon('check',{size:26})}</div><h2 style="margin:0 0 6px;font-size:20px">Thank you</h2><p style="color:rgba(255,255,255,.65);font-size:13px;margin:0">Your response was recorded anonymously.</p><button class="aud-btn" id="aud-again" style="margin-top:16px">Answer another</button></div>`:`
          ${p?`<div class="aud-code">Live poll</div><h1 class="aud-q">${esc(p.question)}</h1>${p.options.map((o,i)=>`<button class="aud-opt" data-opt="${esc(o)}"><span class="letter">${String.fromCharCode(65+i)}</span>${esc(o)}</button>`).join('')}`:`
          <div class="aud-code">Session ${esc(d.code)}</div><h1 class="aud-q">You're in.</h1><p style="color:rgba(255,255,255,.65);font-size:13px;line-height:1.6;margin:0 0 16px">The presenter hasn't opened a poll yet. You can still send a question or a word to the room.</p>
          <input class="aud-input" id="aud-q" placeholder="Ask a question…">
          <button class="aud-btn" id="aud-send">Send question</button>
          <div style="height:10px"></div>
          <input class="aud-input" id="aud-w" placeholder="One word for today…">
          <button class="aud-btn" id="aud-word">Send word</button>`}
          `}
        </div>
        <div class="aud-foot">Responses are anonymous · stored only on the presenting device<br>j-Docs · one project, every surface</div>
        <div style="text-align:center;margin-top:10px"><button class="btn btn-ghost" id="aud-close" style="color:rgba(255,255,255,.6);border-color:rgba(255,255,255,.2)">Exit audience view</button></div>
      </div>`;
      $('#aud-close',root).onclick=()=>{ root.hidden=true; this._audienceDone=false; };
      $$('[data-opt]',root).forEach(b=>b.onclick=()=>{
        $$('[data-opt]',root).forEach(x=>x.classList.remove('selected')); b.classList.add('selected');
        push(d,{type:'poll',pollId:p.id,question:p.question,answer:b.dataset.opt});
        this._audienceDone=true; this.renderAudience();
      });
      const again=$('#aud-again',root); if(again) again.onclick=()=>{ this._audienceDone=false; this.renderAudience(); };
      const send=$('#aud-send',root); if(send) send.onclick=()=>{
        const t=$('#aud-q',root).value.trim(); if(!t)return;
        push(d,{type:'question',question:'Q&A',answer:t}); this._audienceDone=true; this.renderAudience();
      };
      const word=$('#aud-word',root); if(word) word.onclick=()=>{
        const t=$('#aud-w',root).value.trim(); if(!t)return;
        push(d,{type:'word',question:'One word',answer:t}); this._audienceDone=true; this.renderAudience();
      };
    },

    /* ---------------- export ---------------- */
    exportResponses(){
      const d=this.data;
      const rows=[['type','question','answer','timestamp']];
      (d.responses||[]).forEach(r=>rows.push([r.type||'',r.question||'',r.answer||'',r.at||'']));
      const csv=rows.map(r=>r.map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(',')).join('\n');
      download(new Blob([csv],{type:'text/csv'}),'jdocs-responses-'+d.code+'.csv');
      window.JDApp.toast('Responses exported as CSV','success');
    }
  };

  window.JDEngage=E;
  const boot=()=>E.init();
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',boot); else boot();
})();
