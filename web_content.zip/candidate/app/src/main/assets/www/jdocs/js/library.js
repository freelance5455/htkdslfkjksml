/* j-Docs local document library: IndexedDB keeps projects and exported files separate from the active editor. */
(function(){
  const DB='jdocs.library.v1', STORE='items'; let dbPromise=null;
  const uid=()=> 'doc_'+(crypto.randomUUID?crypto.randomUUID():Math.random().toString(36).slice(2)+Date.now().toString(36));
  const open=()=>{
    if(dbPromise)return dbPromise;
    dbPromise=new Promise((resolve,reject)=>{
      if(!('indexedDB' in window)){reject(new Error('IndexedDB is unavailable'));return;}
      const req=indexedDB.open(DB,1);
      req.onupgradeneeded=()=>{const d=req.result;if(!d.objectStoreNames.contains(STORE)){const s=d.createObjectStore(STORE,{keyPath:'id'});s.createIndex('updatedAt','updatedAt');s.createIndex('kind','kind');}};
      req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error||new Error('Could not open document library'));
    });
    return dbPromise;
  };
  const tx=(mode,fn)=>open().then(db=>new Promise((resolve,reject)=>{const t=db.transaction(STORE,mode),s=t.objectStore(STORE);let result;try{result=fn(s)}catch(e){reject(e);return;}t.oncomplete=()=>resolve(result&&typeof result==='object'&&('result' in result)?result.result:result);t.onerror=()=>reject(t.error||new Error('Library operation failed'));t.onabort=()=>reject(t.error||new Error('Library operation aborted'));}));
  const request=(req)=>new Promise((resolve,reject)=>{req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error)});
  const api={
    async init(){try{await open();return true}catch(e){console.warn('j-Docs library unavailable',e);return false;}},
    async saveProject(project){if(!project)return;project.id=project.id||uid();const now=new Date().toISOString();const existing=await tx('readonly',s=>s.get(project.id)).catch(()=>null);return tx('readwrite',s=>s.put({id:project.id,kind:'project',name:project.name||'Untitled presentation',mime:'application/x-jdocs',updatedAt:now,createdAt:existing?.createdAt||now,slideCount:(project.slides||[]).length,project:JSON.parse(JSON.stringify(project))}));},
    async saveArtifact(blob,name){if(!(blob instanceof Blob))return;const ext=(String(name).split('.').pop()||'file').toLowerCase();if(!['pdf','pptx','docx','xlsx','jdocs','html','htm','csv','txt','odt','odp','ods'].includes(ext))return;try{if(ext==='jdocs'&&typeof blob.text==='function'){const data=JSON.parse(await blob.text());if(data&&Array.isArray(data.slides)){data.id=data.id||uid();data.name=data.name||String(name).replace(/\.jdocs$/i,'');await this.saveProject(data);return;}}const id=uid(),now=new Date().toISOString();await tx('readwrite',s=>s.put({id,kind:'file',name:String(name||'Untitled.'+ext),mime:blob.type||'application/octet-stream',updatedAt:now,createdAt:now,size:blob.size,blob}));}catch(e){console.warn('Could not add export to My Documents',e);}},
    async list(){const all=await tx('readonly',s=>s.getAll());return (all||[]).sort((a,b)=>(b.updatedAt||'').localeCompare(a.updatedAt||''));},
    async get(id){return tx('readonly',s=>s.get(id));},
    async remove(id){return tx('readwrite',s=>s.delete(id));},
    async rename(id,name){const item=await this.get(id);if(!item)return;item.name=String(name||'').trim()||item.name;if(item.kind==='project'&&item.project)item.project.name=item.name;item.updatedAt=new Date().toISOString();const saved=await tx('readwrite',s=>s.put(item));if(item.kind==='project'&&window.JD?.Store?.project?.id===id){window.JD.Store.project.name=item.name;window.JD.Store.persistNow();window.JDEditor?.refresh();}return saved;},
    async duplicate(id){const item=await this.get(id);if(!item)return null;const copy={...item,id:uid(),name:(item.name||'Document').replace(/(\.[^.]+)?$/,' (copy)$1'),createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()};if(copy.project){copy.project=JSON.parse(JSON.stringify(copy.project));copy.project.id=copy.id;copy.project.name=copy.name;}await tx('readwrite',s=>s.put(copy));return copy;},
    async openProject(id){const item=await this.get(id);if(!item||item.kind!=='project')return false;const p=JSON.parse(JSON.stringify(item.project));window.JD.Store.setProject(p);window.JDEditor.refresh();window.JDApp?.setTitle();return true;},
    async download(id){const item=await this.get(id);if(!item||!item.blob)return false;const url=URL.createObjectURL(item.blob),a=document.createElement('a');a.href=url;a.download=item.name||'document';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),5000);return true;},
    async openFile(id){const item=await this.get(id);if(!item||!item.blob)return false;const file=new File([item.blob],item.name||'document',{type:item.mime||item.blob.type||'application/octet-stream'});await window.JDIO.openFiles([file]);return true;}
  };
  window.JDLibrary=api;
})();
