/* ============================================================================
   j-Docs — Presentation engine
   Live slideshow, presenter view, rehearsal, broadcast + transition previews.
   Renders the same slide model used by the editor, handouts and HTML export.
   ========================================================================== */
(function(){
  'use strict';
  const { Store, esc } = window.JD;
  const R = window.JDRender;
  const $  = (s, r=document) => r.querySelector(s);
  const $$ = (s, r=document) => Array.from(r.querySelectorAll(s));
  const CH = 'jdocs-present';

  const RATIOS = {
    '16:9': 16/9, '4:3': 4/3, '16:10': 16/10,
    'A4': 297/210, 'A4-portrait': 210/297, '1:1': 1
  };
  function ratio(){ return RATIOS[(Store.project && Store.project.aspect) || '16:9'] || 16/9; }
  function theme(){ return Store.theme ? Store.theme() : window.JD.themeById(Store.project.theme); }
  function slides(){ return (Store.project && Store.project.slides) || []; }
  function root(){ return $('#presentRoot'); }

  const P = {
    active:false, index:0, opts:{}, preview:false,
    timer:0, startedAt:0, timerInt:null, clockInt:null, ch:null,
    black:false, notes:false, _key:null, _auto:null, _advanceAt:0
  };

  /* ---------------------------------------------------------------- helpers */
  function fmt(ms){
    const s = Math.max(0, Math.floor(ms/1000));
    const h = Math.floor(s/3600), m = Math.floor((s%3600)/60), sec = s%60;
    return (h ? String(h).padStart(2,'0')+':' : '') + String(m).padStart(2,'0')+':'+String(sec).padStart(2,'0');
  }
  function clock(){
    const d = new Date();
    return d.toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'});
  }
  function icon(name, size=15){ return window.jIcon ? window.jIcon(name,{size}) : ''; }
  function titleOf(i){
    const s = slides()[i]; if(!s) return '';
    const t = (s.elements||[]).find(e=>e.type==='text' && (e.role==='title' || e.name==='Title'));
    return t ? window.JD.strip(t.html||'') : ('Slide '+(i+1));
  }

  /* --------------------------------------------------------------- shells */
  function stageShell(){
    const s = slides()[P.index] || {};
    return `
      <div class="present-stage" id="pStage">
        <div class="present-slide" id="pSlide" aria-live="polite"></div>
        <div class="present-black" id="pBlack" hidden></div>
      </div>
      <div class="present-top">
        <div class="present-title">${icon('presenter',13)} <span id="pTitle">${esc(titleOf(P.index))}</span></div>
        <div class="row" style="gap:4px">
          <button class="present-btn" data-p="presenter" title="Presenter view (P)" aria-label="Presenter view">${icon('monitor')}</button>
          <button class="present-btn" data-p="notes" title="Speaker notes (N)" aria-label="Toggle speaker notes">${icon('notes')}</button>
          <button class="present-btn" data-p="full" title="Fullscreen (F)" aria-label="Fullscreen">${icon('fullscreen')}</button>
          <button class="present-btn" data-p="exit" title="End show (Esc)" aria-label="End presentation">${icon('close')}</button>
        </div>
      </div>
      <div class="present-controls">
        <button class="present-btn" data-p="prev" title="Previous" aria-label="Previous slide">${icon('arrowLeft')}</button>
        <span class="present-counter" id="pCounter">1 / 1</span>
        <button class="present-btn" data-p="next" title="Next" aria-label="Next slide">${icon('arrowRight')}</button>
        <span style="width:1px;height:18px;background:rgba(255,255,255,.18);margin:0 3px"></span>
        <button class="present-btn" data-p="black" title="Black screen (B)" aria-label="Black screen">${icon('monitor')}</button>
        <button class="present-btn" data-p="exit" title="End show" aria-label="End presentation">${icon('close')}</button>
      </div>
      <div class="present-notes" id="pNotes"><h4>Speaker notes</h4><div id="pNotesBody"></div></div>
      <div class="present-progress" id="pProgress" style="width:0%"></div>`;
  }

  function presenterShell(){
    return `
      <div class="presenter-grid">
        <div class="presenter-main">
          <div class="present-stage" id="pStage" style="padding:0">
            <div class="present-slide" id="pSlide" aria-live="polite"></div>
            <div class="present-black" id="pBlack" hidden></div>
          </div>
          <div class="present-controls" style="position:static;transform:none;opacity:1;align-self:center">
            <button class="present-btn" data-p="prev" title="Previous" aria-label="Previous slide">${icon('arrowLeft')}</button>
            <span class="present-counter" id="pCounter">1 / 1</span>
            <button class="present-btn" data-p="next" title="Next" aria-label="Next slide">${icon('arrowRight')}</button>
            <span style="width:1px;height:18px;background:rgba(255,255,255,.18);margin:0 3px"></span>
            <button class="present-btn" data-p="black" title="Black screen (B)" aria-label="Black screen">${icon('monitor')}</button>
            <button class="present-btn" data-p="stage" title="Audience view (S)" aria-label="Audience view">${icon('fullscreen')}</button>
            <button class="present-btn" data-p="exit" title="End show" aria-label="End presentation">${icon('close')}</button>
          </div>
        </div>
        <div class="presenter-side">
          <div class="presenter-card">
            <div class="presenter-label">Next slide</div>
            <div class="presenter-next" id="pNext"></div>
          </div>
          <div class="presenter-card">
            <div class="presenter-label">Elapsed</div>
            <div class="presenter-timer" id="pTimer">00:00</div>
            <div class="presenter-clock" id="pClock"></div>
          </div>
          <div class="presenter-card" style="flex:1;min-height:120px">
            <div class="presenter-label">Speaker notes</div>
            <div class="presenter-notes" id="pNotesBody"></div>
          </div>
          <div class="presenter-card">
            <div class="presenter-label">Audience engagement</div>
            <div class="presenter-engage" id="pEngage"></div>
          </div>
        </div>
      </div>
      <div class="present-top">
        <div class="present-title">${icon('presenter',13)} Presenter view <span class="presenter-clock" id="pTopClock"></span></div>
        <div class="row" style="gap:4px">
          <button class="present-btn" data-p="notes" title="Notes" aria-label="Toggle notes">${icon('notes')}</button>
          <button class="present-btn" data-p="exit" title="End show" aria-label="End presentation">${icon('close')}</button>
        </div>
      </div>
      <div class="present-progress" id="pProgress" style="width:0%"></div>`;
  }

  /* ----------------------------------------------------------------- start */
  function start(index, opts){
    if(!Store.project || !slides().length) return;
    opts = opts || {};
    P.active = true; P.preview = false; P.opts = opts;
    P.index = Math.max(0, Math.min(Number(index)||0, slides().length-1));
    P.black = false; P.notes = !!opts.notes;

    const r = root();
    r.hidden = false;
    r.classList.add('show-ui');
    r.classList.toggle('presenter-mode', !!opts.presenter);
    r.innerHTML = opts.presenter ? presenterShell() : stageShell();
    document.body.classList.add('presenting');

    bind();
    render(true);
    startClock();
    if(opts.rehearse){ P.timer = 0; P.startedAt = Date.now(); startTimer(); }
    else { P.timer = 0; P.startedAt = Date.now(); startTimer(); }

    if(opts.broadcast){
      try{
        P.ch = new BroadcastChannel(CH);
        P.ch.postMessage({type:'start', total:slides().length, title:Store.project.name});
      }catch(e){}
    }
    if(!opts.presenter){
      try{ if(document.documentElement.requestFullscreen) document.documentElement.requestFullscreen().catch(()=>{}); }catch(e){}
    }
    setTimeout(()=>{ try{ $('#pSlide', r)?.focus(); }catch(e){} }, 30);
    toast(opts.presenter ? 'Presenter view — notes, timer and next slide' : (opts.rehearse ? 'Rehearsal started — timer is running' : 'Presenting — arrow keys to advance, Esc to exit'));
  }

  /* ---------------------------------------------------------------- render */
  function render(initial){
    const r = root(); if(!r || !P.active) return;
    const s = slides()[P.index]; if(!s) return;
    const slideEl = $('#pSlide', r); if(!slideEl) return;

    slideEl.innerHTML = R.slideToHTML(s, theme());
    slideEl.style.width = '100%'; slideEl.style.height = '100%';
    fit(slideEl);

    $('#pTitle', r) && ($('#pTitle', r).textContent = titleOf(P.index));
    const counter = $('#pCounter', r); if(counter) counter.textContent = (P.index+1)+' / '+slides().length;
    const prog = $('#pProgress', r); if(prog) prog.style.width = ((P.index+1)/slides().length*100)+'%';

    // notes
    const notesBody = $('#pNotesBody', r);
    if(notesBody) notesBody.innerHTML = s.notes ? R.sanitize(s.notes).replace(/\n/g,'<br>') : '<span class="muted">No speaker notes for this slide.</span>';
    if(P.notes){ $('#pNotes', r)?.classList.add('show'); }

    // next slide preview
    const next = $('#pNext', r);
    if(next){
      const n = slides()[P.index+1];
      next.innerHTML = n ? R.slideToHTML(n, theme(), {thumb:true}) : '<div style="display:grid;place-items:center;height:100%;color:#666;font-size:11px">End of deck</div>';
    }

    renderEngage();
    applyBlack();

    // motion
    if(!initial || s.transition && s.transition.type && s.transition.type!=='none'){
      if(!initial) runTransition(s);
    }
    if(initial || true) runAnimations(s, initial ? 0 : 0);

    // auto-advance
    clearTimeout(P._auto);
    const tr = s.transition || {};
    if(tr.advance === 'auto' && !P.preview){
      const wait = Math.max(1200, (Number(tr.duration)||.6)*1000 + (Number(tr.autoAfter)||5)*1000);
      P._auto = setTimeout(()=>{ if(P.active) next(); }, wait);
    }
  }

  function fit(el){
    const stage = el.parentElement;
    if(!stage) return;
    const rect = stage.getBoundingClientRect();
    if(!rect.width || !rect.height) return;
    const ar = ratio();
    let w = rect.width - 24, h = w/ar;
    if(h > rect.height - 24){ h = rect.height - 24; w = h*ar; }
    el.style.width = Math.max(40, Math.floor(w))+'px';
    el.style.height = Math.max(24, Math.floor(h))+'px';
  }

  /* ------------------------------------------------------------ transitions */
  const TRANSITIONS = {
    none: null,
    fade:   [{opacity:0},{opacity:1}],
    dissolve:[{opacity:0, filter:'blur(8px)'},{opacity:1, filter:'blur(0)'}],
    push:   [{transform:'translateX(100%)'},{transform:'translateX(0)'}],
    wipe:   [{clipPath:'inset(0 100% 0 0)'},{clipPath:'inset(0 0 0 0)'}],
    split:  [{clipPath:'inset(0 50% 0 50%)'},{clipPath:'inset(0 0 0 0)'}],
    zoom:   [{transform:'scale(.82)', opacity:0},{transform:'scale(1)', opacity:1}],
    cover:  [{transform:'translateY(-100%)'},{transform:'translateY(0)'}],
    uncover:[{transform:'translateY(100%)'},{transform:'translateY(0)'}],
    morph:  [{transform:'scale(1.06)', opacity:0, filter:'blur(6px)'},{transform:'scale(1)', opacity:1, filter:'blur(0)'}]
  };

  function runTransition(s){
    const el = $('#pSlide', root()); if(!el) return;
    const tr = s.transition || {};
    const kf = TRANSITIONS[tr.type] || TRANSITIONS.fade;
    if(!kf) return;
    const dur = Math.max(120, (Number(tr.duration)||.6)*1000);
    try{
      el.animate(kf, {duration:dur, easing:'cubic-bezier(.22,.61,.36,1)', fill:'both'});
    }catch(e){}
  }

  function runAnimations(s, delayBase){
    const el = $('#pSlide', root()); if(!el) return;
    const a = s.animation || {};
    const type = a.type && a.type!=='none' ? a.type : null;
    const nodes = $$('.el', el);
    if(!nodes.length) return;
    if(!type){ return; }
    const dur = Math.max(120, (Number(a.duration)||.5)*1000);
    const stagger = 70;
    nodes.forEach((n,i)=>{
      let kf;
      switch(type){
        case 'fade': kf=[{opacity:0},{opacity:1}]; break;
        case 'fly': kf=[{opacity:0, transform:'translateY(26px)'},{opacity:1, transform:'translateY(0)'}]; break;
        case 'wipe': kf=[{opacity:0, clipPath:'inset(0 100% 0 0)'},{opacity:1, clipPath:'inset(0 0 0 0)'}]; break;
        case 'zoom': kf=[{opacity:0, transform:'scale(.7)'},{opacity:1, transform:'scale(1)'}]; break;
        case 'spin': kf=[{opacity:0, transform:'rotate(-14deg) scale(.8)'},{opacity:1, transform:'rotate(0) scale(1)'}]; break;
        case 'pulse': kf=[{transform:'scale(1)'},{transform:'scale(1.06)'},{transform:'scale(1)'}]; break;
        default: kf=[{opacity:0},{opacity:1}];
      }
      try{ n.animate(kf, {duration:dur, delay:delayBase + i*stagger, easing:'cubic-bezier(.22,.61,.36,1)', fill:'both'}); }catch(e){}
    });
  }

  /* -------------------------------------------------------------- navigation */
  function go(i, opts){
    opts = opts || {};
    const total = slides().length;
    const nextIndex = Math.max(0, Math.min(i, total-1));
    if(nextIndex === P.index && !opts.force) return;
    const dir = nextIndex > P.index ? 1 : -1;
    P.index = nextIndex;
    render(false);
    if(P.ch) try{ P.ch.postMessage({type:'slide', index:P.index, total, title:titleOf(P.index)}); }catch(e){}
    if(P.index === total-1 && !P.preview) toast('Last slide — press Esc to end');
  }
  function next(){ if(P.index < slides().length-1) go(P.index+1); else if(!P.preview) toast('End of presentation'); }
  function prev(){ if(P.index > 0) go(P.index-1); else toast('First slide'); }

  /* ------------------------------------------------------------------ clock */
  function startClock(){
    clearInterval(P.clockInt);
    P.clockInt = setInterval(()=>{
      const t = clock();
      const c = $('#pClock'); if(c) c.textContent = t;
      const tc = $('#pTopClock'); if(tc) tc.textContent = '· '+t;
    }, 1000);
    const c = $('#pClock'); if(c) c.textContent = clock();
  }
  function startTimer(){
    clearInterval(P.timerInt);
    P.timerInt = setInterval(()=>{
      P.timer = Date.now() - P.startedAt;
      const t = $('#pTimer'); if(t) t.textContent = fmt(P.timer);
    }, 500);
  }

  /* -------------------------------------------------------------- engagement */
  function renderEngage(){
    const box = $('#pEngage'); if(!box) return;
    const E = window.JDEngage;
    if(!E || !E.data){
      box.innerHTML = '<div class="muted" style="font-size:11px">Engagement is off.</div>';
      return;
    }
    const d = E.data;
    const poll = d.active ? (d.polls||[]).find(p=>p.id===d.active) : null;
    let html = `<div class="row" style="justify-content:space-between;align-items:center;margin-bottom:4px">
      <span class="session-code" style="font-size:15px;letter-spacing:2px">${esc(d.code||'—')}</span>
      <span class="muted" style="font-size:10px">${(d.responses||[]).length} responses</span>
    </div>`;
    if(poll){
      const votes = poll.votes || {};
      const total = Object.values(votes).reduce((a,b)=>a+b,0) || 0;
      html += `<div style="font-size:11px;font-weight:600;margin:2px 0 5px">${esc(poll.question)}</div>`;
      (poll.options||[]).forEach((o,i)=>{
        const n = votes[i] || 0, pct = total ? Math.round(n/total*100) : 0;
        html += `<div class="presenter-poll-opt"><span style="width:14px;color:#8a8886">${String.fromCharCode(65+i)}</span>
          <div class="bar-track" style="flex:1"><div class="bar-fill" style="width:${pct}%"></div></div>
          <span style="width:34px;text-align:right;color:#a19f9d">${pct}%</span></div>`;
      });
      html += `<div class="muted" style="font-size:10px;margin-top:2px">${total} vote${total===1?'':'s'} · live</div>`;
    } else {
      html += `<div class="muted" style="font-size:11px">No live poll. Open Engagement to start one.</div>`;
    }
    html += `<div class="row" style="gap:6px;margin-top:7px">
      <button class="btn btn-ghost" data-p="audience" style="font-size:10px;padding:3px 8px">Open audience</button>
      <button class="btn btn-ghost" data-p="analytics" style="font-size:10px;padding:3px 8px">Analytics</button>
    </div>`;
    box.innerHTML = html;
  }

  /* ------------------------------------------------------------------- black */
  function applyBlack(){
    const b = $('#pBlack'); if(!b) return;
    b.hidden = !P.black;
    root()?.classList.toggle('blackout', P.black);
  }

  /* ------------------------------------------------------------------- bind */
  function bind(){
    const r = root();
    $$('[data-p]', r).forEach(b=>{
      b.onclick = (ev)=>{
        ev.stopPropagation();
        act(b.dataset.p);
      };
    });
    const stage = $('#pStage', r);
    if(stage){
      stage.onclick = (ev)=>{
        if(ev.target.closest('button')) return;
        const rect = stage.getBoundingClientRect();
        if(ev.clientX < rect.left + rect.width*0.28) prev(); else next();
      };
    }
    P._key = (ev)=>onKey(ev);
    document.addEventListener('keydown', P._key, true);
    window.addEventListener('resize', onResize);
    P._eng = ()=>renderEngage();
    window.addEventListener('jdocs-engage', P._eng);
  }

  function act(a){
    switch(a){
      case 'next': next(); break;
      case 'prev': prev(); break;
      case 'exit': exit(); break;
      case 'black': P.black = !P.black; applyBlack(); break;
      case 'notes': P.notes = !P.notes; $('#pNotes')?.classList.toggle('show', P.notes); break;
      case 'full':
        try{ document.documentElement.requestFullscreen ? document.documentElement.requestFullscreen() : null; }catch(e){}
        break;
      case 'presenter': start(P.index, {presenter:true, broadcast:P.opts.broadcast, rehearse:P.opts.rehearse}); break;
      case 'stage': start(P.index, {broadcast:P.opts.broadcast}); break;
      case 'audience':
        if(window.JDEngage) window.JDEngage.previewAudience(window.JDEngage.data.code);
        break;
      case 'analytics':
        if(window.JDEngage) window.JDEngage.open('analytics');
        break;
    }
  }

  function onKey(ev){
    if(!P.active) return;
    const tag = (ev.target && ev.target.tagName) || '';
    if(/INPUT|TEXTAREA|SELECT/.test(tag) || (ev.target && ev.target.isContentEditable)) return;
    const k = ev.key;
    if(k === 'Escape'){ ev.preventDefault(); exit(); return; }
    if(k === 'ArrowRight' || k === 'ArrowDown' || k === 'PageDown' || k === ' ' || k === 'Enter'){ ev.preventDefault(); next(); return; }
    if(k === 'ArrowLeft' || k === 'ArrowUp' || k === 'PageUp' || k === 'Backspace'){ ev.preventDefault(); prev(); return; }
    if(k === 'Home'){ ev.preventDefault(); go(0); return; }
    if(k === 'End'){ ev.preventDefault(); go(slides().length-1); return; }
    if(k === 'b' || k === 'B'){ P.black = !P.black; applyBlack(); return; }
    if(k === 'n' || k === 'N'){ P.notes = !P.notes; $('#pNotes')?.classList.toggle('show', P.notes); return; }
    if(k === 'p' || k === 'P'){ act('presenter'); return; }
    if(k === 's' || k === 'S'){ act(P.opts.presenter ? 'stage' : 'presenter'); return; }
    if(k === 'f' || k === 'F'){ act('full'); return; }
    if(k === '?' ){ toast('← → navigate · B black · N notes · P presenter · F fullscreen · Esc exit'); }
  }

  function onResize(){
    const el = $('#pSlide'); if(el) fit(el);
  }

  /* ------------------------------------------------------------------- exit */
  function exit(){
    if(!P.active && !P.preview) return;
    P.active = false; P.preview = false;
    clearTimeout(P._auto); clearInterval(P.timerInt); clearInterval(P.clockInt);
    if(P._key) document.removeEventListener('keydown', P._key, true);
    window.removeEventListener('resize', onResize);
    if(P._eng) window.removeEventListener('jdocs-engage', P._eng);
    if(P.ch){ try{ P.ch.postMessage({type:'end'}); P.ch.close(); }catch(e){} P.ch = null; }
    const r = root(); if(r){ r.hidden = true; r.innerHTML = ''; r.classList.remove('show-ui','presenter-mode','blackout'); }
    document.body.classList.remove('presenting');
    try{ if(document.fullscreenElement) document.exitFullscreen(); }catch(e){}
    setTimeout(()=>{ try{ window.JDEditor?.refresh?.(); }catch(e){} }, 20);
  }

  /* --------------------------------------------------------------- previews */
  function preview(kind){
    if(!Store.project || !slides().length) return;
    if(P.active) exit();
    P.preview = true;
    const s = slides()[Store.current] || slides()[0];
    const r = root();
    r.hidden = false; r.classList.add('previewing');
    r.innerHTML = `
      <div class="present-stage" style="padding:32px">
        <div class="present-slide" id="pPreview" style="width:min(78vw,1100px);height:auto;aspect-ratio:${ratio()}"></div>
      </div>
      <div class="present-top" style="opacity:1">
        <div class="present-title">${icon(kind==='transition'?'transition':'sparkle',13)} Preview · ${kind==='transition'?'transition':'animation'} — ${esc(s.transition?.type||'fade')} / ${esc(s.animation?.type||'none')}</div>
        <button class="present-btn" data-pv="close" aria-label="Close preview">${icon('close')}</button>
      </div>`;
    const el = $('#pPreview', r);
    el.innerHTML = R.slideToHTML(s, theme());
    r.querySelector('[data-pv="close"]').onclick = ()=>closePreview();
    P._pvKey = (ev)=>{ if(ev.key==='Escape'){ ev.preventDefault(); closePreview(); } };
    document.addEventListener('keydown', P._pvKey, true);

    const dur = Math.max(200, (Number(s.transition?.duration)||.6)*1000);
    if(kind === 'transition'){
      const kf = TRANSITIONS[s.transition?.type] || TRANSITIONS.fade;
      if(kf) try{ el.animate(kf, {duration:dur, easing:'cubic-bezier(.22,.61,.36,1)', fill:'both'}); }catch(e){}
    } else {
      const nodes = $$('.el', el);
      const a = s.animation || {}; const type = a.type && a.type!=='none' ? a.type : 'fade';
      const ad = Math.max(160, (Number(a.duration)||.5)*1000);
      nodes.forEach((n,i)=>{
        let kf = [{opacity:0},{opacity:1}];
        if(type==='fly') kf=[{opacity:0,transform:'translateY(26px)'},{opacity:1,transform:'translateY(0)'}];
        if(type==='zoom') kf=[{opacity:0,transform:'scale(.7)'},{opacity:1,transform:'scale(1)'}];
        if(type==='wipe') kf=[{opacity:0,clipPath:'inset(0 100% 0 0)'},{opacity:1,clipPath:'inset(0 0 0 0)'}];
        try{ n.animate(kf,{duration:ad,delay:i*70,easing:'cubic-bezier(.22,.61,.36,1)',fill:'both'}); }catch(e){}
      });
    }
    clearTimeout(P._pvTimer);
    P._pvTimer = setTimeout(closePreview, Math.max(2600, dur+1400));
  }
  function closePreview(){
    clearTimeout(P._pvTimer);
    if(P._pvKey) document.removeEventListener('keydown', P._pvKey, true);
    P.preview = false;
    const r = root(); if(r){ r.hidden = true; r.innerHTML = ''; r.classList.remove('previewing'); }
  }

  /* ------------------------------------------------------------------ toast */
  function toast(msg){
    if(window.JDApp && window.JDApp.toast) window.JDApp.toast(msg);
  }

  window.JDPresent = {
    start, exit,
    previewTransition: ()=>preview('transition'),
    previewAnimation: ()=>preview('animation'),
    next, prev, go,
    get active(){ return P.active; },
    get index(){ return P.index; }
  };
})();
