/* Smoke test for the j-Docs relay: two editors + one audience phone. */
const URL = process.env.RELAY || 'ws://localhost:8787/ws';
const room = 'TEST' + Math.floor(Math.random() * 900 + 100);
const log = (...a) => console.log(...a);
let got = { a: [], b: [], aud: [] };

function open(role, name) {
  const ws = new WebSocket(`${URL}?room=${room}&role=${role}&name=${name}`);
  ws.onmessage = (e) => {
    const m = JSON.parse(e.data);
    if (role === 'editor') (name === 'Ada' ? got.a : got.b).push(m);
    else got.aud.push(m);
    if (m.t === 'welcome') log(`[${name}] welcome id=${m.id} peers=${m.peers.length}`);
    if (m.t === 'project') log(`[${name}] <- project seq=${m.seq} slides=${m.project && m.project.slides.length}`);
    if (m.t === 'engage') log(`[${name}] <- engage "${m.item.answer}"`);
    if (m.t === 'presence') log(`[${name}] presence ${m.peers.map(p => p.name + ':' + p.role).join(', ')}`);
  };
  ws.onerror = (e) => log(`[${name}] error`, e.message || '');
  return ws;
}

const a = open('editor', 'Ada');
const b = open('editor', 'Grace');
const aud = open('audience', 'Phone');

setTimeout(() => {
  a.send(JSON.stringify({ t: 'project', project: { name: 'Live deck', slides: [{ id: 's1' }, { id: 's2' }] } }));
}, 400);

setTimeout(() => {
  a.send(JSON.stringify({ t: 'slide', index: 1 }));
  a.send(JSON.stringify({ t: 'cursor', x: 40, y: 60, slide: 1 }));
}, 700);

setTimeout(() => {
  aud.send(JSON.stringify({ t: 'engage', item: { type: 'poll', question: 'Ready?', answer: 'Yes' } }));
}, 1000);

setTimeout(() => {
  const pass =
    got.b.some(m => m.t === 'project' && m.project.slides.length === 2) &&
    got.b.some(m => m.t === 'cursor' && m.x === 40) &&
    got.a.some(m => m.t === 'engage' && m.item.answer === 'Yes') &&
    got.aud.every(m => m.t !== 'project'); // audience must never receive the deck
  log('\nRESULT:', pass ? 'PASS' : 'FAIL');
  if (!pass) {
    log('a:', got.a.map(m => m.t).join(','));
    log('b:', got.b.map(m => m.t).join(','));
    log('aud:', got.aud.map(m => m.t).join(','));
  }
  [a, b, aud].forEach(w => w.close());
  process.exit(pass ? 0 : 1);
}, 1600);
