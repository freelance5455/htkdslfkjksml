/* j-Docs — application shell: dialogs, command palette, galleries, views, ink, settings */
(function(){
  const JD = window.JD;
  const {Store,THEMES,themeById,LAYOUTS,makeLayout,uid,clone,esc,strip,words,download,today,
    textEl,shapeEl,imageEl,tableEl,chartEl,iconEl,codeEl,mediaEl,newProject,demoProject} = JD;
  const R = window.JDRender;
  const $ = (s,r=document)=>r.querySelector(s);
  const $$ = (s,r=document)=>[...r.querySelectorAll(s)];
  const icon = (n,o)=>window.jIcon?window.jIcon(n,Object.assign({size:16},o||{})):'';
  const btn = (label,cls='btn btn-ghost',id='')=>`<button class="${cls}"${id?' id="'+id+'"':''}>${label}</button>`;
  const field = (label,inner,full)=>`<label class="form-field${full?' full':''}"><span class="form-label">${label}</span>${inner}</label>`;
  const COLORS = ['#c43e1c','#ff8a4c','#e11d48','#db2777','#7c3aed','#4f46e5','#2563eb','#0ea5e9','#0f7b6c','#16a34a','#65a30d','#ca8a04','#f59e0b','#78716c','#111827','#ffffff','#f3f2f1','#000000'];

  const App = {
    inkMode:null, inkColor:'#c43e1c', inkWidth:4, _menu:null,

    /* ============================================================
       BOOT
       ============================================================ */
    async init(){
      Store.init();
      await window.JDLibrary?.init();
      try{ await window.JDLibrary?.saveProject(Store.project); }catch(e){ console.warn('My Documents is unavailable in this browser',e); }
      window.JDEditor.init();
      this.restoreUI();
      this.bindGlobal();
      this.wrapEditor();
      this.renderInk();
      this.setTitle();
      this.fitChrome(true);
      window.addEventListener('resize',()=>this.fitChrome(false));
      setTimeout(()=>this.toast('j-Docs ready — open any file, or press Ctrl+K','info',2600),700);
    },
    /* Keep the whole workspace inside the viewport: collapse the ribbon on short
       screens and close the docked inspector when it would squeeze the slide. */
    fitChrome(initial){
      const ribbon=document.getElementById('ribbon');
      const ws=document.getElementById('workspace');
      if(!ribbon||!ws) return;
      const short=window.innerHeight<=720;
      if(initial){
        this._userRibbon=false;
        if(short) ribbon.classList.add('collapsed');
      }else if(!this._userRibbon){
        ribbon.classList.toggle('collapsed',short);
      }
      if(window.innerWidth<=1280 && !this._userInspector){
        ws.classList.remove('inspector-open');
      }
      if(window.JDEditor) window.JDEditor.fit();
    },
    setTitle(){ const n=Store.project.name||'Untitled'; document.title = /j-Docs/i.test(n) ? n : n+' — j-Docs'; },
    restoreUI(){
      try{
        const ui=JSON.parse(localStorage.getItem('jdocs.ui.v1')||'{}');
        if(ui.theme) document.documentElement.setAttribute('data-theme',ui.theme);
        ['high-contrast','large-text','dyslexia-font','reduce-motion'].forEach(c=>{ if(ui[c]) document.body.classList.add(c); });
      }catch(e){}
    },
    saveUI(){
      const ui={theme:document.documentElement.getAttribute('data-theme')||'light'};
      ['high-contrast','large-text','dyslexia-font','reduce-motion'].forEach(c=>ui[c]=document.body.classList.contains(c));
      try{ localStorage.setItem('jdocs.ui.v1',JSON.stringify(ui)); }catch(e){}
    },
    bindGlobal(){
      const root=$('#modalRoot');
      root.addEventListener('pointerdown',e=>{ if(e.target===root) this.closeModal(); });
      document.addEventListener('click',e=>{
        if(this._menu && !e.target.closest('.menu-pop') && !e.target.closest('[data-menu-anchor]')) this.closeMenu();
      },true);
      document.addEventListener('keydown',e=>{
        if(e.key==='Escape'){ if(this._menu){ this.closeMenu(); } }
      });
      window.addEventListener('beforeunload',()=>{ try{Store.persistNow()}catch(e){} });
      $('#docTitle')?.addEventListener('change',()=>this.setTitle());
    },
    wrapEditor(){
      const E=window.JDEditor;
      if(!E || E._wrapped) return;
      E._wrapped=true;
      const refresh=E.refresh.bind(E);
      E.refresh=function(o){ refresh(o); App.renderInk(); App.setTitle(); };
      const apply=E.applyCanvasSize.bind(E);
      E.applyCanvasSize=function(){
        const shell=$('#slideShell'), scroll=$('#stageScroll');
        if(!shell||!scroll){ apply(); return; }
        const notes=$('#notesDrawer'); const notesH=notes&&!notes.hidden?notes.offsetHeight+12:0;
        const padW=window.innerWidth<=720?12:48, padH=window.innerWidth<=720?20:60;
        const availW=Math.max(220,scroll.clientWidth-padW), availH=Math.max(160,scroll.clientHeight-padH-notesH);
        const ratio=App.ratio();
        let w=Math.min(availW,availH*ratio); w=Math.max(240,w)*this.zoomFactor;
        const h=w/ratio;
        this._fitW=w; this._fitH=h;
        shell.style.width=w+'px'; shell.style.height=h+'px';
        const z=$('#zoomLabel'); if(z) z.textContent=Math.round(this.zoomFactor*100)+'%';
      };
    },
    ratio(){
      const a=Store.project.aspect||'16:9';
      return {'16:9':16/9,'4:3':4/3,'16:10':16/10,'A4':297/210,'A4-portrait':210/297,'1:1':1}[a]||16/9;
    },

    /* ============================================================
       MODAL / TOAST / MENU
       ============================================================ */
    modal(opts={}){
      const root=$('#modalRoot');
      $$('.modal',root).forEach(m=>{ if(!m.hidden) m.hidden=true; });
      const el=document.createElement('div');
      el.className='modal'+(opts.wide?' wide':'')+(opts.narrow?' narrow':'')+(opts.tall?' tall':'');
      el.setAttribute('role','dialog'); el.setAttribute('aria-modal','true'); el.setAttribute('aria-label',opts.title||'j-Docs dialog');
      const tabs = opts.tabs&&opts.tabs.length ? `<div class="modal-tabs" role="tablist">${opts.tabs.map((t,i)=>`<button class="modal-tab${i===0?' active':''}" data-mtab="${t.id}" role="tab" aria-selected="${i===0}">${t.label}</button>`).join('')}</div>` : '';
      el.innerHTML = `<div class="modal-head"><div><h2 class="modal-title">${opts.title||''}</h2>${opts.sub?`<div class="modal-sub">${opts.sub}</div>`:''}</div><button class="modal-close" data-mclose aria-label="Close dialog">${icon('close',{size:16})}</button></div>${tabs}<div class="modal-body">${opts.body||''}</div>${opts.footer?`<div class="modal-foot">${opts.footer}</div>`:''}`;
      root.appendChild(el); root.classList.add('open');
      el.querySelector('[data-mclose]').addEventListener('click',()=>this.closeModal());
      if(opts.tabs&&opts.tabs.length){
        const body=el.querySelector('.modal-body');
        const show=(t)=>{
          $$('.modal-tab',el).forEach(b=>{b.classList.toggle('active',b.dataset.mtab===t.id);b.setAttribute('aria-selected',b.dataset.mtab===t.id)});
          body.innerHTML=t.html||'';
          if(t.onMount) try{t.onMount(body,el)}catch(err){console.warn(err)}
        };
        $$('.modal-tab',el).forEach(b=>b.addEventListener('click',()=>show(opts.tabs.find(t=>t.id===b.dataset.mtab))));
        if(opts.tabs[0].onMount) setTimeout(()=>{ try{opts.tabs[0].onMount(body,el)}catch(err){console.warn(err)} },0);
      }
      if(opts.onMount) try{opts.onMount(el)}catch(err){console.warn('j-Docs modal mount',err)}
      setTimeout(()=>{ const f=el.querySelector('input:not([type=checkbox]),select,textarea,button.btn-primary'); if(f) f.focus(); },40);
      return el;
    },
    closeModal(){
      const root=$('#modalRoot');
      const mods=$$('.modal',root);
      if(!mods.length){ root.classList.remove('open'); return; }
      mods[mods.length-1].remove();
      const rest=$$('.modal',root);
      if(rest.length){ rest[rest.length-1].hidden=false; }
      else { root.classList.remove('open'); root.innerHTML=''; }
    },
    toast(msg,type='info',ms=2600){
      const root=$('#toastRoot'); if(!root) return;
      const t=document.createElement('div');
      t.className='toast '+type;
      const ic=type==='success'?'checkCircle':type==='error'?'alert':'info';
      t.innerHTML=icon(ic,{size:15})+'<span>'+esc(msg)+'</span>';
      root.appendChild(t);
      setTimeout(()=>{ t.style.opacity='0'; t.style.transform='translateY(6px)'; t.style.transition='all .2s'; setTimeout(()=>t.remove(),220); },ms);
    },
    menu(anchor, items, opts={}){
      this.closeMenu();
      const r=anchor?anchor.getBoundingClientRect():{left:20,top:60,bottom:60,right:120};
      const el=document.createElement('div');
      el.className='menu-pop'; el.setAttribute('role','menu');
      el.innerHTML=(opts.title?`<div class="menu-title">${esc(opts.title)}</div>`:'')+items.map((it,i)=>{
        if(it.sep) return '<div class="menu-sep"></div>';
        return `<button class="menu-item${it.danger?' danger':''}" role="menuitem" data-mi="${i}">${it.icon?icon(it.icon,{size:15}):'<span style="width:15px"></span>'}<span>${esc(it.label)}</span>${it.kbd?`<kbd>${esc(it.kbd)}</kbd>`:''}</button>`;
      }).join('');
      document.body.appendChild(el);
      const w=el.offsetWidth||230, h=el.offsetHeight||300;
      let left=Math.min(r.left, window.innerWidth-w-10);
      let top=r.bottom+6;
      if(top+h>window.innerHeight-10) top=Math.max(10,r.top-h-6);
      el.style.left=Math.max(8,left)+'px'; el.style.top=top+'px';
      el.querySelectorAll('[data-mi]').forEach(b=>b.addEventListener('click',()=>{
        const it=items[Number(b.dataset.mi)]; this.closeMenu(); try{ it.run&&it.run(); }catch(e){ console.warn(e); this.toast('That action could not run','error'); }
      }));
      this._menu=el;
      return el;
    },
    closeMenu(){ if(this._menu){ this._menu.remove(); this._menu=null; } },

    /* ============================================================
       COMMAND PALETTE
       ============================================================ */
    commands(){
      const E=window.JDEditor;
      const go=(i)=>{ Store.current=i; Store.selected=[]; E.refresh(); };
      const list=[
        {g:'File',l:'New presentation',i:'new',k:'Ctrl N',r:()=>this.newProject()},
        {g:'File',l:'Open any file…',i:'open',k:'Ctrl O',r:()=>$('#fileInput').click()},
        {g:'File',l:'Save .jdocs project',i:'save',k:'Ctrl S',r:()=>this.saveProject()},
        {g:'File',l:'My Documents',i:'folder',r:()=>this.myDocuments()},
        {g:'File',l:'Share / join link',i:'share',r:()=>this.share()},
        {g:'File',l:'Export PPTX',i:'download',r:()=>window.JDIO?.exportPPTX()},
        {g:'File',l:'Export standalone web experience',i:'html',r:()=>window.JDIO?.exportHTML()},
        {g:'File',l:'Offline presentation package',i:'package',r:()=>window.JDOutputs?.offlinePackage()},
        {g:'File',l:'Export everything (ZIP)',i:'zip',r:()=>window.JDOutputs?.exportAll()},
        {g:'Edit',l:'Undo',i:'undo',k:'Ctrl Z',r:()=>{Store.undo();E.refresh()}},
        {g:'Edit',l:'Redo',i:'redo',k:'Ctrl Y',r:()=>{Store.redo();E.refresh()}},
        {g:'Edit',l:'Find and replace',i:'find',k:'Ctrl F',r:()=>this.findReplace()},
        {g:'Edit',l:'Select all objects',i:'selectAll',r:()=>{Store.selectMany(Store.elements().map(e=>e.id));E.renderSelection()}},
        {g:'Insert',l:'New slide',i:'plus',k:'Ctrl M',r:()=>{Store.addSlide('titleContent');E.refresh()}},
        {g:'Insert',l:'Text box',i:'textPlus',r:()=>E.insertText()},
        {g:'Insert',l:'Picture…',i:'imagePlus',r:()=>$('#imageInput').click()},
        {g:'Insert',l:'Table…',i:'tablePlus',r:()=>this.tableDialog()},
        {g:'Insert',l:'Chart…',i:'chartPlus',r:()=>this.chartDialog()},
        {g:'Insert',l:'Shapes…',i:'shapePlus',r:()=>this.shapeGallery()},
        {g:'Insert',l:'Icons…',i:'icon',r:()=>this.iconGallery()},
        {g:'Insert',l:'SmartArt / diagram…',i:'smartart',r:()=>this.smartArtGallery()},
        {g:'Insert',l:'Media (audio / video)…',i:'media',r:()=>$('#mediaInput').click()},
        {g:'Insert',l:'Code block',i:'code',r:()=>E.insertCode()},
        {g:'Insert',l:'Link…',i:'link',r:()=>this.linkDialog()},
        {g:'Insert',l:'Comment…',i:'commentPlus',r:()=>this.commentDialog()},
        {g:'Design',l:'Layout gallery',i:'layout',r:()=>this.layoutGallery()},
        {g:'Design',l:'Themes and palettes',i:'palette',r:()=>this.paletteDialog()},
        {g:'Design',l:'Font pairing',i:'font',r:()=>this.fontPair()},
        {g:'Design',l:'Background…',i:'background',r:()=>this.backgroundDialog()},
        {g:'Design',l:'Slide size…',i:'aspect',r:()=>this.slideSizeDialog()},
        {g:'Design',l:'Brand kit…',i:'art',r:()=>this.brandKit()},
        {g:'Design',l:'Designer suggestions',i:'wand',r:()=>this.designer()},
        {g:'View',l:'Normal view',i:'view',r:()=>{Store.view='normal';E.refresh()}},
        {g:'View',l:'Outline view',i:'outline',r:()=>this.outlineView()},
        {g:'View',l:'Slide sorter',i:'sorter',r:()=>this.sorterView()},
        {g:'View',l:'Reading / document mode',i:'reading',r:()=>window.JDOutputs?.documentMode()},
        {g:'View',l:'Teaching view',i:'graduation',r:()=>window.JDOutputs?.teachingKit()},
        {g:'View',l:'Toggle dark mode',i:'dark',r:()=>this.toggleTheme()},
        {g:'View',l:'Toggle high contrast',i:'contrast',r:()=>this.toggleContrast()},
        {g:'View',l:'Toggle large text',i:'accessibility',r:()=>this.toggleLargeText()},
        {g:'View',l:'Toggle dyslexia-friendly font',i:'book',r:()=>this.toggleDyslexia()},
        {g:'View',l:'Toggle reduced motion',i:'offline',r:()=>this.toggleMotion()},
        {g:'Present',l:'Present from beginning',i:'play',k:'F5',r:()=>window.JDPresent?.start(0)},
        {g:'Present',l:'Presenter view',i:'presenter',r:()=>window.JDPresent?.start(Store.current,{presenter:true})},
        {g:'Present',l:'Rehearse timings',i:'rehearse',r:()=>window.JDPresent?.start(Store.current,{rehearse:true})},
        {g:'Present',l:'Engage audience',i:'qr',r:()=>window.JDEngage?.open()},
        {g:'Present',l:'Audience analytics',i:'chartBar',r:()=>window.JDEngage?.open('analytics')},
        {g:'Outputs',l:'Handouts',i:'handout',r:()=>window.JDOutputs?.handouts()},
        {g:'Outputs',l:'Notes pages',i:'notes',r:()=>window.JDOutputs?.notesPages()},
        {g:'Outputs',l:'Slide summaries',i:'summary',r:()=>window.JDOutputs?.summaries()},
        {g:'Outputs',l:'Executive summary',i:'sparkle',r:()=>window.JDOutputs?.execSummary()},
        {g:'Outputs',l:'Teaching kit',i:'graduation',r:()=>window.JDOutputs?.teachingKit()},
        {g:'Outputs',l:'Lesson plan',i:'book',r:()=>window.JDOutputs?.lessonPlan()},
        {g:'Outputs',l:'Quiz builder',i:'question',r:()=>window.JDOutputs?.quizBuilder()},
        {g:'Outputs',l:'Readability report',i:'target',r:()=>window.JDOutputs?.readability()},
        {g:'Outputs',l:'Print studio',i:'print',r:()=>window.JDOutputs?.printStudio()},
        {g:'Review',l:'Check accessibility',i:'accessibility',r:()=>{Store.inspectorTab='a11y';E.renderInspector();this.toast('Accessibility checks updated','success')}},
        {g:'Review',l:'Contrast checker',i:'contrast',r:()=>this.contrastDialog()},
        {g:'Review',l:'Comments pane',i:'comment',r:()=>this.commentsPane()},
        {g:'Review',l:'Version history',i:'history',r:()=>this.versionHistory()},
        {g:'Review',l:'Protect presentation',i:'shield',r:()=>this.protectDialog()},
        {g:'Help',l:'Keyboard shortcuts',i:'keyboard',r:()=>this.shortcuts()},
        {g:'Help',l:'Why j-Docs?',i:'sparkle',r:()=>this.whyJDocs()},
        {g:'Help',l:'Documentation',i:'book',r:()=>this.docs()},
        {g:'Help',l:'About j-Docs',i:'info',r:()=>this.about()},
        {g:'Help',l:'Privacy',i:'shield',r:()=>this.privacy()},
        {g:'Help',l:'Licenses',i:'crown',r:()=>this.licenses()}
      ];
      Store.project.slides.forEach((s,i)=>{
        const o=Store.outline()[i];
        list.push({g:'Slides',l:(i+1)+'. '+(o.title||'Untitled'),i:'slide',r:()=>go(i)});
      });
      return list;
    },
    openCommand(q=''){
      const root=$('#commandRoot');
      root.hidden=false;
      root.innerHTML=`<div class="command" role="dialog" aria-label="Command palette"><input class="command-input" id="cmdInput" placeholder="Search commands, slides and actions…" aria-label="Search commands" autocomplete="off"><div class="command-list" id="cmdList" role="listbox"></div></div>`;
      const input=$('#cmdInput',root), list=$('#cmdList',root);
      let items=[], active=0;
      const render=()=>{
        const query=input.value.trim().toLowerCase();
        items=this.commands().filter(c=>!query||(c.l+' '+c.g).toLowerCase().includes(query));
        if(!items.length){ list.innerHTML='<div class="command-empty">No matches. Try “handout”, “theme”, “present” or a slide title.</div>'; return; }
        let html='', last='';
        items.forEach((c,i)=>{
          if(c.g!==last){ html+=`<div class="command-group">${c.g}</div>`; last=c.g; }
          html+=`<button class="command-item${i===active?' active':''}" data-ci="${i}" role="option">${icon(c.i||'doc',{size:16})}<span>${esc(c.l)}</span>${c.k?`<span class="cmd-kbd">${esc(c.k)}</span>`:''}</button>`;
        });
        list.innerHTML=html;
        $$('[data-ci]',list).forEach(b=>b.addEventListener('click',()=>run(Number(b.dataset.ci))));
        const a=$('.command-item.active',list); if(a) a.scrollIntoView({block:'nearest'});
      };
      const close=()=>{ root.hidden=true; root.innerHTML=''; };
      const run=(i)=>{ const c=items[i]; close(); if(c) try{c.r()}catch(e){console.warn(e);this.toast('Action failed','error')} };
      input.addEventListener('input',()=>{active=0;render()});
      input.addEventListener('keydown',e=>{
        if(e.key==='ArrowDown'){ e.preventDefault(); active=Math.min(items.length-1,active+1); render(); }
        else if(e.key==='ArrowUp'){ e.preventDefault(); active=Math.max(0,active-1); render(); }
        else if(e.key==='Enter'){ e.preventDefault(); run(active); }
        else if(e.key==='Escape'){ close(); }
      });
      root.onclick=e=>{ if(e.target===root) close(); };
      render(); setTimeout(()=>input.focus(),20);
    },

    /* ============================================================
       MENUS
       ============================================================ */
    openBrandMenu(){
      const a=$('#brandBtn');
      this.menu(a,[
        {label:'New presentation',icon:'new',kbd:'Ctrl N',run:()=>this.newProject()},
        {label:'Open any file…',icon:'open',kbd:'Ctrl O',run:()=>$('#fileInput').click()},
        {label:'Save project',icon:'save',kbd:'Ctrl S',run:()=>this.saveProject()},
        {label:'My Documents',icon:'folder',run:()=>this.myDocuments()},
        {sep:true},
        {label:'Share',icon:'share',run:()=>this.share()},
        {label:'Export PPTX',icon:'download',run:()=>window.JDIO?.exportPPTX()},
        {label:'Export web experience',icon:'html',run:()=>window.JDIO?.exportHTML()},
        {label:'Offline package',icon:'package',run:()=>window.JDOutputs?.offlinePackage()},
        {label:'Print studio',icon:'print',run:()=>window.JDOutputs?.printStudio()},
        {sep:true},
        {label:'Version history',icon:'history',run:()=>this.versionHistory()},
        {label:'Reset demo deck',icon:'reset',run:()=>this.resetDemo()},
        {label:'Settings & accessibility',icon:'settings',run:()=>this.a11ySettings()},
        {sep:true},
        {label:'About j-Docs',icon:'info',run:()=>this.about()},
        {label:'Privacy',icon:'shield',run:()=>this.privacy()},
        {label:'Licenses',icon:'crown',run:()=>this.licenses()}
      ],{title:'j-Docs'});
    },
    railMenu(){
      const a=$('[data-action="rail-menu"]');
      this.menu(a,[
        {label:'New slide',icon:'plus',run:()=>{Store.addSlide('titleContent');window.JDEditor.refresh()}},
        {label:'Duplicate slide',icon:'duplicate',run:()=>{Store.duplicateSlide();window.JDEditor.refresh()}},
        {label:'Delete slide',icon:'trash',danger:true,run:()=>{if(Store.deleteSlide())window.JDEditor.refresh()}},
        {sep:true},
        {label:'Add section',icon:'section',run:()=>{Store.slide().section=prompt('Section name','Section')||'';Store.markDirty();window.JDEditor.renderRail()}},
        {label:'Hide slide',icon:'eye',run:()=>{Store.slide().hidden=!Store.slide().hidden;Store.markDirty();window.JDEditor.renderRail()}},
        {sep:true},
        {label:'Layout gallery',icon:'layout',run:()=>this.layoutGallery()},
        {label:'Slide sorter',icon:'sorter',run:()=>this.sorterView()}
      ],{title:'Slide options'});
    },
    viewMenu(){
      const a=$('#viewChip');
      this.menu(a,[
        {label:'Normal',icon:'view',run:()=>{Store.view='normal';window.JDEditor.refresh()}},
        {label:'Outline',icon:'outline',run:()=>this.outlineView()},
        {label:'Slide sorter',icon:'sorter',run:()=>this.sorterView()},
        {label:'Notes page',icon:'notes',run:()=>{Store.project.settings.showNotes=true;Store.view='notes';window.JDEditor.refresh()}},
        {label:'Reading / document',icon:'reading',run:()=>window.JDOutputs?.documentMode()},
        {label:'Teaching view',icon:'graduation',run:()=>window.JDOutputs?.teachingKit()},
        {sep:true},
        {label:'Focus mode',icon:'expand',run:()=>{document.body.classList.toggle('focus-mode');window.JDEditor.fit()}},
        {label:'Show grid',icon:'grid',run:()=>{Store.project.settings.grid=!Store.project.settings.grid;Store.markDirty();window.JDEditor.renderCanvas()}},
        {label:'Show guides',icon:'guides',run:()=>{Store.project.settings.guides=!Store.project.settings.guides;Store.markDirty()}}
      ],{title:'View'});
    },

    async myDocuments(){
      const items=await window.JDLibrary?.list()||[];
      const fmtDate=v=>{try{return new Date(v).toLocaleString([], {month:'short',day:'numeric',year:'numeric',hour:'2-digit',minute:'2-digit'})}catch(e){return ''}};
      const fmtSize=n=>{if(!Number.isFinite(n))return '';const u=['B','KB','MB','GB'];let i=0;while(n>=1024&&i<3){n/=1024;i++;}return (i?n.toFixed(1):n)+' '+u[i];};
      const rows=items.map(it=>`<article class="jd-library-item" data-library-id="${esc(it.id)}" data-library-kind="${it.kind}"><div class="jd-library-icon">${icon(it.kind==='project'?'present':'file',{size:22})}</div><div class="jd-library-meta"><strong>${esc(it.name||'Untitled')}</strong><span>${it.kind==='project'?'Presentation · '+(it.slideCount||0)+' slides':esc((it.mime||'File').split('/').pop().toUpperCase())+' · '+fmtSize(it.size||0)} · ${fmtDate(it.updatedAt)}</span></div><div class="jd-library-actions">${it.kind==='project'?'<button class="btn btn-primary" data-lib-open>Open</button>':'<button class="btn btn-primary" data-lib-open>Open</button>'}<button class="icon-btn sm" data-lib-rename title="Rename" aria-label="Rename">${icon('edit',{size:14})}</button><button class="icon-btn sm" data-lib-duplicate title="Duplicate" aria-label="Duplicate">${icon('copy',{size:14})}</button><button class="icon-btn sm" data-lib-delete title="Delete" aria-label="Delete">${icon('trash',{size:14})}</button></div></article>`).join('');
      const modal=this.modal({title:'My Documents',sub:'Your presentations and exported files, stored privately on this device.',wide:true,body:`<div class="jd-library-toolbar"><input id="jdLibrarySearch" class="form-input" placeholder="Search your documents…" aria-label="Search documents"><span class="form-hint">${items.length} saved item${items.length===1?'':'s'}</span><button class="btn btn-ghost" id="jdLibraryAdd">＋ Add files</button><input id="jdLibraryFiles" type="file" accept=".pdf,.pptx,.docx,.xlsx,.jdocs,.html,.htm,.csv,.txt,.odt,.odp,.ods" multiple hidden><button class="btn btn-primary" id="jdLibraryNew">＋ New presentation</button></div><div class="jd-library-list" id="jdLibraryList">${rows||'<div class="jd-library-empty"><strong>Your document library is ready.</strong><span>Create a presentation, export a file, or add existing PDFs and documents from your device.</span></div>'}</div>`,onMount:el=>{
        const list=el.querySelector('#jdLibraryList'),search=el.querySelector('#jdLibrarySearch');
        search.addEventListener('input',()=>{const q=search.value.toLowerCase();list.querySelectorAll('.jd-library-item').forEach(row=>row.hidden=!row.textContent.toLowerCase().includes(q));});
        el.querySelector('#jdLibraryNew').addEventListener('click',()=>{this.closeModal();this.newProject();});
        const fileInput=el.querySelector('#jdLibraryFiles');el.querySelector('#jdLibraryAdd').addEventListener('click',()=>fileInput.click());
        fileInput.addEventListener('change',async()=>{for(const file of [...fileInput.files])await window.JDLibrary.saveArtifact(file,file.name);this.closeModal();await this.myDocuments();this.toast('Files added to My Documents','success');});
        list.addEventListener('click',async e=>{const row=e.target.closest('[data-library-id]');if(!row)return;const id=row.dataset.libraryId;
          if(e.target.closest('[data-lib-open]')){this.closeModal();if(row.dataset.libraryKind==='project'){await window.JDLibrary.openProject(id);this.toast('Presentation opened','success');}else{await window.JDLibrary.openFile(id);}return;}
          if(e.target.closest('[data-lib-download]')){await window.JDLibrary.download(id);return;}
          if(e.target.closest('[data-lib-rename]')){const item=await window.JDLibrary.get(id);const name=prompt('Rename document',item?.name||'');if(name){await window.JDLibrary.rename(id,name);this.closeModal();await this.myDocuments();}return;}
          if(e.target.closest('[data-lib-duplicate]')){await window.JDLibrary.duplicate(id);this.closeModal();await this.myDocuments();return;}
          if(e.target.closest('[data-lib-delete]')){if(row.dataset.libraryKind==='project'&&id===Store.project.id){this.toast('Open another presentation before deleting the one currently in use','info');return;}if(confirm('Delete this saved item from My Documents?')){await window.JDLibrary.remove(id);this.closeModal();await this.myDocuments();}return;}
        });
      }});
      return modal;
    },

    /* ============================================================
       FILE ACTIONS
       ============================================================ */
    newProject(){
      if(!confirm('Start a new presentation? Your current deck stays saved in this browser until replaced.')) return;
      Store.setProject(newProject('Untitled presentation', Store.project.theme||'ember'));
      window.JDEditor.refresh(); this.setTitle();
      this.toast('New presentation created','success');
    },
    resetDemo(){
      if(!confirm('Replace the current deck with the j-Docs demo deck?')) return;
      Store.setProject(demoProject()); window.JDEditor.refresh(); this.setTitle();
      this.toast('Demo deck restored','success');
    },
    saveProject(){
      if(window.JDIO?.saveProjectFile) window.JDIO.saveProjectFile();
      else download(new Blob([JSON.stringify(Store.project,null,2)],{type:'application/json'}),'presentation.jdocs');
      Store.persistNow();
      this.toast('Saved .jdocs project','success');
    },
    share(){
      const url=location.href.split('#')[0];
      const el=this.modal({
        title:'Share j-Docs', sub:'This build is local-first: your deck never leaves the device unless you export it.',
        body:`<div class="row wrap" style="gap:18px;align-items:flex-start">
          <div style="flex:1;min-width:230px">
            <div class="form-field"><span class="form-label">Project link</span><div class="join-link">${esc(url)}</div></div>
            <div class="row" style="gap:7px;margin-top:10px;flex-wrap:wrap">
              <button class="btn btn-primary" id="sh-copy">${icon('copy')} Copy link</button>
              <button class="btn btn-ghost" id="sh-html">${icon('html')} Web version</button>
              <button class="btn btn-ghost" id="sh-pkg">${icon('package')} Offline package</button>
            </div>
            <div class="form-hint" style="margin-top:12px">Tip: the offline package includes the deck, fonts, media, handouts, notes, quiz and a manifest — it opens with no internet connection.</div>
          </div>
          <div style="text-align:center"><div class="qr-box" id="sh-qr"></div><div class="form-hint" style="margin-top:6px">Scan to open</div></div>
        </div>`,
        footer:`<span class="muted" style="font-size:11px">Local-first · no account required</span><div class="modal-foot-right"><button class="btn btn-primary" data-mclose2>Done</button></div>`,
        onMount:(el)=>{
          try{
            if(window.qrcode){ const qr=qrcode(0,'M'); qr.addData(url); qr.make(); $('#sh-qr',el).innerHTML=qr.createImgTag(4,0); }
          }catch(e){ $('#sh-qr',el).textContent='QR unavailable'; }
          $('#sh-copy',el).onclick=async()=>{ try{ await navigator.clipboard.writeText(url); this.toast('Link copied','success'); }catch(e){ this.toast('Copy failed — select the link manually','error'); } };
          $('#sh-html',el).onclick=()=>window.JDIO?.exportHTML();
          $('#sh-pkg',el).onclick=()=>window.JDOutputs?.offlinePackage();
          el.querySelector('[data-mclose2]').onclick=()=>this.closeModal();
        }
      });
    },

    /* ============================================================
       LAYOUTS / SHAPES / ICONS / SMARTART
       ============================================================ */
    applyLayout(id){
      const E=window.JDEditor; const s=Store.slide(); if(!s) return;
      Store.commit('layout');
      const data=E.extractSlideData(s);
      const ns=makeLayout(id,Store.project.theme,data);
      ns.id=s.id; ns.notes=s.notes; ns.transition=s.transition; ns.background=s.background; ns.ink=s.ink; ns.comments=s.comments;
      Store.project.slides[Store.current]=ns; Store.selected=[]; Store.markDirty(); E.refresh();
    },
    layoutGallery(){
      const mini=(l)=>{
        const map={title:'<i style="height:14px;width:70%;background:var(--accent);opacity:.85"></i><i style="height:6px;width:46%;background:var(--line-strong)"></i>',
          titleContent:'<i style="height:8px;width:60%;background:var(--accent);opacity:.85"></i><i style="height:4px;width:84%;background:var(--line-strong)"></i><i style="height:4px;width:76%;background:var(--line-strong)"></i><i style="height:4px;width:80%;background:var(--line-strong)"></i>',
          section:'<i style="height:10px;width:50%;background:var(--accent);opacity:.85"></i><i style="height:4px;width:36%;background:var(--line-strong)"></i>',
          twoContent:'<i style="height:7px;width:56%;background:var(--accent);opacity:.85"></i><span style="display:flex;gap:4px;width:100%"><i style="height:26px;flex:1;background:var(--line)"></i><i style="height:26px;flex:1;background:var(--line)"></i></span>',
          comparison:'<i style="height:7px;width:56%;background:var(--accent);opacity:.85"></i><span style="display:flex;gap:4px;width:100%"><i style="height:24px;flex:1;background:var(--line)"></i><i style="height:24px;flex:1;background:var(--line)"></i></span>',
          titleOnly:'<i style="height:10px;width:64%;background:var(--accent);opacity:.85"></i>',
          blank:'<i style="height:34px;width:100%;background:var(--line)"></i>',
          pictureCaption:'<i style="height:26px;width:100%;background:var(--line-strong)"></i><i style="height:4px;width:54%;background:var(--line)"></i>',
          quote:'<i style="height:4px;width:70%;background:var(--accent);opacity:.7"></i><i style="height:4px;width:58%;background:var(--line-strong)"></i><i style="height:4px;width:24%;background:var(--line)"></i>',
          agenda:'<i style="height:7px;width:40%;background:var(--accent);opacity:.85"></i><i style="height:4px;width:72%;background:var(--line-strong)"></i><i style="height:4px;width:64%;background:var(--line-strong)"></i><i style="height:4px;width:68%;background:var(--line-strong)"></i>',
          bigNumber:'<i style="height:22px;width:34%;background:var(--accent);opacity:.9"></i><i style="height:4px;width:50%;background:var(--line-strong)"></i>',
          stats:'<span style="display:flex;gap:4px;width:100%"><i style="height:24px;flex:1;background:var(--accent);opacity:.75"></i><i style="height:24px;flex:1;background:var(--line)"></i><i style="height:24px;flex:1;background:var(--line)"></i></span>',
          timeline:'<i style="height:3px;width:90%;background:var(--accent);opacity:.7"></i><span style="display:flex;gap:6px;width:100%"><i style="height:10px;width:10px;border-radius:50%;background:var(--accent)"></i><i style="height:10px;width:10px;border-radius:50%;background:var(--accent)"></i><i style="height:10px;width:10px;border-radius:50%;background:var(--accent)"></i></span>',
          team:'<span style="display:flex;gap:5px;width:100%"><i style="height:22px;width:22px;border-radius:50%;background:var(--line-strong)"></i><i style="height:22px;width:22px;border-radius:50%;background:var(--line-strong)"></i><i style="height:22px;width:22px;border-radius:50%;background:var(--line-strong)"></i></span>',
          closing:'<i style="height:12px;width:56%;background:var(--accent);opacity:.85"></i><i style="height:4px;width:40%;background:var(--line-strong)"></i>'};
        return map[l.id]||map.titleContent;
      };
      const el=this.modal({
        title:'Layouts', sub:'Choose a starting structure. Content is carried over where it fits.',
        wide:true,
        body:`<div class="card-grid">${LAYOUTS.map(l=>`<button class="option-card" data-layout="${l.id}" style="min-height:104px"><span style="display:flex;flex-direction:column;gap:4px;justify-content:center;align-items:flex-start;background:var(--surface-2);border:1px solid var(--line);border-radius:4px;width:100%;height:58px;padding:7px">${mini(l)}</span><strong>${l.name}</strong></button>`).join('')}</div>`,
        footer:`<span class="muted" style="font-size:11px">${LAYOUTS.length} layouts</span><div class="modal-foot-right"><button class="btn btn-ghost" data-mclose3>Cancel</button></div>`,
        onMount:(el)=>{
          $$('[data-layout]',el).forEach(b=>b.onclick=()=>{ this.applyLayout(b.dataset.layout); this.closeModal(); this.toast('Layout applied','success'); });
          el.querySelector('[data-mclose3]').onclick=()=>this.closeModal();
        }
      });
    },
    shapeGallery(){
      const shapes=[['rect','Rectangle'],['roundRect','Rounded'],['ellipse','Ellipse'],['circle','Circle'],['triangle','Triangle'],['diamond','Diamond'],['pentagon','Pentagon'],['hexagon','Hexagon'],['octagon','Octagon'],['star','Star'],['arrow','Arrow'],['chevron','Chevron'],['callout','Callout'],['cloud','Cloud'],['heart','Heart'],['plus','Plus'],['line','Line'],['arrowLine','Arrow line']];
      const el=this.modal({
        title:'Shapes', sub:'Click a shape to add it to the current slide.', wide:true,
        body:`<div class="card-grid">${shapes.map(([id,name])=>`<button class="option-card" data-shape="${id}" style="align-items:center;justify-content:center;min-height:92px"><span style="width:54px;height:54px;display:block">${R.shapeSVG({shape:id,style:{fill:'accent',stroke:'transparent',strokeWidth:0}},Store.theme())}</span><strong>${name}</strong></button>`).join('')}</div>`,
        footer:`<span class="muted" style="font-size:11px">Tip: hold Shift while resizing to keep proportions</span><div class="modal-foot-right"><button class="btn btn-ghost" data-mclose4>Cancel</button></div>`,
        onMount:(el)=>{
          $$('[data-shape]',el).forEach(b=>b.onclick=()=>{
            const e=shapeEl(b.dataset.shape,34,30,32,32,{style:{fill:'accent'}});
            Store.addElement(e); window.JDEditor.refresh(); this.closeModal(); this.toast('Shape inserted','success');
          });
          el.querySelector('[data-mclose4]').onclick=()=>this.closeModal();
        }
      });
    },
    iconGallery(){
      const names=Object.keys(window.jIconPaths||{}).filter(n=>n!=='unknown').sort();
      const el=this.modal({
        title:'Icons', sub:'A consistent, stroke-based icon set. Icons stay crisp at any size.', wide:true,
        body:`<input class="form-input" id="icoSearch" placeholder="Search ${names.length} icons…" aria-label="Search icons" style="margin-bottom:10px"><div class="card-grid" id="icoGrid" style="grid-template-columns:repeat(auto-fill,minmax(78px,1fr));max-height:52vh;overflow:auto"></div>`,
        footer:`<span class="muted" style="font-size:11px">${names.length} icons · SVG · recolourable</span><div class="modal-foot-right"><button class="btn btn-ghost" data-mclose5>Cancel</button></div>`,
        onMount:(el)=>{
          const grid=$('#icoGrid',el);
          const draw=(q='')=>{
            const list=names.filter(n=>n.toLowerCase().includes(q.toLowerCase())).slice(0,240);
            grid.innerHTML=list.map(n=>`<button class="option-card" data-icon="${n}" style="align-items:center;justify-content:center;min-height:70px;padding:8px">${icon(n,{size:24})}<span style="font-size:9px;text-align:center">${n}</span></button>`).join('')||'<div class="command-empty">No icons match.</div>';
            $$('[data-icon]',grid).forEach(b=>b.onclick=()=>{
              Store.addElement(iconEl(b.dataset.icon,38,32,24,24,{style:{color:'accent'}}));
              window.JDEditor.refresh(); this.closeModal(); this.toast('Icon inserted','success');
            });
          };
          draw();
          $('#icoSearch',el).addEventListener('input',e=>draw(e.target.value));
          el.querySelector('[data-mclose5]').onclick=()=>this.closeModal();
        }
      });
    },
    smartArtGallery(){
      const items=[
        ['process','Process','Linear steps with arrows'],['cycle','Cycle','Repeating loop of stages'],
        ['hierarchy','Hierarchy','Parent with child nodes'],['pyramid','Pyramid','Layered priority'],
        ['list','List','Stacked key points'],['matrix','Matrix','2×2 comparison']
      ];
      const el=this.modal({
        title:'SmartArt & diagrams', sub:'Editable groups of shapes and text — not a flat picture.', wide:true,
        body:`<div class="card-grid">${items.map(([id,n,d])=>`<button class="option-card" data-sa="${id}" style="min-height:96px"><strong>${n}</strong><span>${d}</span></button>`).join('')}</div>`,
        footer:`<span class="muted" style="font-size:11px">Every node is a real element you can restyle</span><div class="modal-foot-right"><button class="btn btn-ghost" data-mclose6>Cancel</button></div>`,
        onMount:(el)=>{
          $$('[data-sa]',el).forEach(b=>b.onclick=()=>{ this.insertSmartArt(b.dataset.sa); this.closeModal(); });
          el.querySelector('[data-mclose6]').onclick=()=>this.closeModal();
        }
      });
    },
    insertSmartArt(kind){
      const t=Store.theme(); const add=(e)=>Store.addElement(e,{noCommit:true});
      Store.commit('smartart');
      const labels=kind==='matrix'?['Strengths','Weaknesses','Opportunities','Threats']:['Plan','Build','Launch','Learn'];
      if(kind==='process'||kind==='cycle'||kind==='list'){
        labels.forEach((l,i)=>{
          const x=8+i*22, y=kind==='list'?20+i*16:36;
          add(shapeEl(kind==='cycle'?'ellipse':'roundRect',x,y,18,14,{style:{fill:'accent',opacity:.16,stroke:'accent',strokeWidth:1.2}}));
          add(textEl('<p style="text-align:center"><strong>'+esc(l)+'</strong></p>',x,y+4,18,6,{style:{fontSize:12,color:'fg',align:'center'}}));
        });
      } else if(kind==='hierarchy'){
        add(shapeEl('roundRect',38,16,24,12,{style:{fill:'accent'}}));
        add(textEl('<p style="text-align:center;color:#fff"><strong>Lead</strong></p>',38,19,24,6,{style:{fontSize:12,color:'#ffffff',align:'center'}}));
        [22,40,58].forEach((x,i)=>{
          add(shapeEl('roundRect',x,52,18,12,{style:{fill:'accent',opacity:.25,stroke:'accent',strokeWidth:1}}));
          add(textEl('<p style="text-align:center">'+esc(['Team A','Team B','Team C'][i])+'</p>',x,55,18,6,{style:{fontSize:10,align:'center'}}));
        });
      } else if(kind==='pyramid'){
        [0,1,2].forEach(i=>{
          const w=30+i*18, x=50-w/2, y=22+i*16;
          add(shapeEl('triangle',x,y,w,14,{style:{fill:'accent',opacity:.9-i*.22}}));
          add(textEl('<p style="text-align:center">'+esc(['Vision','Strategy','Execution'][i])+'</p>',x,y+5,w,6,{style:{fontSize:10,align:'center',color:'#ffffff'}}));
        });
      } else {
        labels.forEach((l,i)=>{
          const x=i%2?53:12, y=i<2?24:52;
          add(shapeEl('roundRect',x,y,35,20,{style:{fill:'accent',opacity:.14,stroke:'accent',strokeWidth:1}}));
          add(textEl('<p><strong>'+esc(l)+'</strong></p><p style="font-size:9px;opacity:.7">Add detail</p>',x+2,y+4,31,12,{style:{fontSize:11,color:'fg'}}));
        });
      }
      Store.markDirty(); window.JDEditor.refresh(); this.toast('Diagram inserted','success');
    },

    /* ============================================================
       TABLE / CHART
       ============================================================ */
    tableDialog(){
      const el=this.modal({
        title:'Insert table', sub:'Paste tab- or comma-separated data, or start with a grid.',
        body:`<div class="form-grid">
          ${field('Rows','<input class="form-input" id="tb-rows" type="number" min="1" max="30" value="4">')}
          ${field('Columns','<input class="form-input" id="tb-cols" type="number" min="1" max="12" value="3">')}
          ${field('Data (tab or comma separated)','<textarea class="form-textarea" id="tb-data" rows="7">Quarter,Revenue,Growth\nQ1,120,8%\nQ2,148,23%\nQ3,171,16%</textarea>',true)}
        </div>`,
        footer:`<span class="muted" style="font-size:11px">Header row is styled automatically</span><div class="modal-foot-right"><button class="btn btn-ghost" data-mclose7>Cancel</button><button class="btn btn-primary" id="tb-insert">Insert table</button></div>`,
        onMount:(el)=>{
          const build=()=>{
            const rows=Math.max(1,Math.min(30,Number($('#tb-rows',el).value)||1));
            const cols=Math.max(1,Math.min(12,Number($('#tb-cols',el).value)||1));
            const data=Array.from({length:rows},(_,r)=>Array.from({length:cols},(_,c)=>r===0?'Column '+(c+1):''));
            $('#tb-data',el).value=data.map(r=>r.join('\t')).join('\n');
          };
          $('#tb-rows',el).onchange=build; $('#tb-cols',el).onchange=build;
          $('#tb-insert',el).onclick=()=>{
            const lines=$('#tb-data',el).value.split(/\r?\n/).filter(l=>l.trim());
            const data=lines.map(l=>l.split(/\t|,(?=(?:[^"]*"[^"]*")*[^"]*$)/).map(s=>s.replace(/^"|"$/g,'').trim()));
            const rows=Math.max(1,data.length), cols=Math.max(1,...data.map(r=>r.length));
            const norm=Array.from({length:rows},(_,r)=>Array.from({length:cols},(_,c)=>(data[r]&&data[r][c])||''));
            Store.addElement(tableEl(norm,10,24,80,52)); window.JDEditor.refresh(); this.closeModal(); this.toast('Table inserted','success');
          };
          el.querySelector('[data-mclose7]').onclick=()=>this.closeModal();
        }
      });
    },
    editTable(e){
      const data=e.data||[['']];
      const el=this.modal({
        title:'Edit table', sub:'Edit cells as tab-separated text. Rows and columns resize automatically.',
        body:field('Table data','<textarea class="form-textarea" id="et-data" rows="10">'+esc(data.map(r=>r.join('\t')).join('\n'))+'</textarea>',true),
        footer:`<div class="modal-foot-right"><button class="btn btn-ghost" data-mclose8>Cancel</button><button class="btn btn-primary" id="et-save">Save table</button></div>`,
        onMount:(el)=>{
          $('#et-save',el).onclick=()=>{
            const lines=$('#et-data',el).value.split(/\r?\n/);
            const rows=Math.max(1,lines.length), cols=Math.max(1,...lines.map(l=>l.split('\t').length));
            const d=Array.from({length:rows},(_,r)=>Array.from({length:cols},(_,c)=>(lines[r]||'').split('\t')[c]||''));
            Store.updateElement(e.id,{data:d}); window.JDEditor.refresh(); this.closeModal(); this.toast('Table updated','success');
          };
          el.querySelector('[data-mclose8]').onclick=()=>this.closeModal();
        }
      });
    },
    chartDialog(){
      const el=this.modal({
        title:'Insert chart', sub:'Type your data as label,value pairs — one per line.',
        body:`<div class="form-grid">
          ${field('Chart type','<select class="form-select" id="ch-type"><option value="column">Column</option><option value="bar">Bar</option><option value="line">Line</option><option value="area">Area</option><option value="pie">Pie</option><option value="donut">Donut</option></select>')}
          ${field('Chart title','<input class="form-input" id="ch-title" value="Quarterly growth">')}
          ${field('Data','<textarea class="form-textarea" id="ch-data" rows="8">Q1,120\nQ2,148\nQ3,171\nQ4,204</textarea>',true)}
        </div>`,
        footer:`<div class="modal-foot-right"><button class="btn btn-ghost" data-mclose9>Cancel</button><button class="btn btn-primary" id="ch-insert">Insert chart</button></div>`,
        onMount:(el)=>{
          $('#ch-insert',el).onclick=()=>{
            const data=$('#ch-data',el).value.split(/\r?\n/).filter(l=>l.trim()).map(l=>{ const p=l.split(/[,\t]/); return {label:(p[0]||'').trim(),value:Number((p[1]||'0').trim())||0}; });
            Store.addElement(chartEl($('#ch-type',el).value,data,10,22,80,56,{style:{title:$('#ch-title',el).value}}));
            window.JDEditor.refresh(); this.closeModal(); this.toast('Chart inserted','success');
          };
          el.querySelector('[data-mclose9]').onclick=()=>this.closeModal();
        }
      });
    },
    editChart(e){
      const data=e.data||[];
      const el=this.modal({
        title:'Edit chart', sub:'One label,value pair per line.',
        body:`<div class="form-grid">
          ${field('Chart type','<select class="form-select" id="ec-type">'+['column','bar','line','area','pie','donut'].map(t=>`<option value="${t}" ${e.chartType===t?'selected':''}>${t}</option>`).join('')+'</select>')}
          ${field('Title','<input class="form-input" id="ec-title" value="'+esc((e.style&&e.style.title)||'')+'">')}
          ${field('Data','<textarea class="form-textarea" id="ec-data" rows="8">'+esc(data.map(d=>d.label+','+d.value).join('\n'))+'</textarea>',true)}
        </div>`,
        footer:`<div class="modal-foot-right"><button class="btn btn-ghost" data-mclose10>Cancel</button><button class="btn btn-primary" id="ec-save">Save chart</button></div>`,
        onMount:(el)=>{
          $('#ec-save',el).onclick=()=>{
            const d=$('#ec-data',el).value.split(/\r?\n/).filter(l=>l.trim()).map(l=>{const p=l.split(/[,\t]/);return {label:(p[0]||'').trim(),value:Number((p[1]||'0').trim())||0}});
            Store.updateElement(e.id,{chartType:$('#ec-type',el).value,data:d});
            Store.updateStyle(e.id,{title:$('#ec-title',el).value});
            window.JDEditor.refresh(); this.closeModal(); this.toast('Chart updated','success');
          };
          el.querySelector('[data-mclose10]').onclick=()=>this.closeModal();
        }
      });
    },

    /* ============================================================
       COLOR PICKER
       ============================================================ */
    colorPicker(mode='color'){
      const titles={color:'Font colour',fill:'Highlight colour',shapeFill:'Shape fill',shapeStroke:'Shape outline',ink:'Ink colour',background:'Background'};
      const el=this.modal({
        title:titles[mode]||'Colour', sub:'Theme-aware swatches plus any custom colour.', narrow:true,
        body:`<div class="pill-row" style="gap:7px">${COLORS.map(c=>`<button class="swatch-btn" data-color="${c}" title="${c}" style="width:30px;height:30px;border-radius:6px;border:1px solid var(--line-2);background:${c}"></button>`).join('')}</div>
          <div class="row" style="gap:8px;margin-top:14px;align-items:center"><input type="color" id="cp-custom" value="${mode==='ink'?this.inkColor:'#c43e1c'}" style="width:44px;height:34px;border:1px solid var(--line-2);border-radius:6px;background:var(--surface)"><input class="form-input" id="cp-hex" value="${mode==='ink'?this.inkColor:'#c43e1c'}" style="flex:1"><button class="btn btn-primary" id="cp-apply">Apply</button></div>
          <div class="form-hint" style="margin-top:10px">${mode==='ink'?'Ink is stored per slide and exports as vector strokes.':'Colours resolve against the current theme so your deck stays consistent in light and dark.'}</div>`,
        footer:`<div class="modal-foot-right"><button class="btn btn-ghost" data-mclose11>Cancel</button></div>`,
        onMount:(el)=>{
          const apply=(c)=>{ this.applyColor(mode,c); this.closeModal(); };
          $$('[data-color]',el).forEach(b=>b.onclick=()=>apply(b.dataset.color));
          const hex=$('#cp-hex',el), custom=$('#cp-custom',el);
          custom.oninput=()=>{ hex.value=custom.value; };
          hex.oninput=()=>{ if(/^#[0-9a-f]{6}$/i.test(hex.value)) custom.value=hex.value; };
          $('#cp-apply',el).onclick=()=>apply(hex.value);
          el.querySelector('[data-mclose11]').onclick=()=>this.closeModal();
        }
      });
    },
    applyColor(mode,c){
      if(!/^#[0-9a-f]{3,8}$/i.test(c)){ this.toast('Enter a valid hex colour','error'); return; }
      if(mode==='ink'){ this.inkColor=c; this.toast('Ink colour set','success'); return; }
      if(mode==='background'){ Store.setBackground(c); window.JDEditor.refresh(); this.toast('Background updated','success'); return; }
      const el=Store.selectedElement();
      if(!el){ this.toast('Select an object first','info'); return; }
      if(mode==='color') Store.updateStyle(el.id,{color:c});
      else if(mode==='fill') Store.updateStyle(el.id,{fill:c});
      else if(mode==='shapeFill') Store.updateStyle(el.id,{fill:c});
      else if(mode==='shapeStroke') Store.updateStyle(el.id,{stroke:c,strokeWidth:Math.max(1,el.style?.strokeWidth||1)});
      window.JDEditor.refresh(); this.toast('Colour applied','success');
    },

    /* ============================================================
       LINKS / COMMENTS / HEADER-FOOTER / FIND
       ============================================================ */
    linkDialog(){
      const sel=Store.selectedElement();
      const el=this.modal({
        title:'Insert link', sub:'Links open in a new tab and are announced by screen readers.',
        body:`<div class="form-grid">
          ${field('Text to display','<input class="form-input" id="lk-text" value="'+esc(sel&&sel.type==='text'?strip(sel.content):'Learn more')+'">')}
          ${field('URL','<input class="form-input" id="lk-url" placeholder="https://example.com" value="https://">',true)}
        </div>`,
        footer:`<div class="modal-foot-right"><button class="btn btn-ghost" data-mclose12>Cancel</button><button class="btn btn-primary" id="lk-insert">Insert link</button></div>`,
        onMount:(el)=>{
          $('#lk-insert',el).onclick=()=>{
            const url=$('#lk-url',el).value.trim(), text=$('#lk-text',el).value.trim()||url;
            if(!/^https?:\/\//i.test(url)){ this.toast('Use an http(s) URL','error'); return; }
            Store.addElement(textEl('<p><a href="'+esc(url)+'" target="_blank" rel="noopener">'+esc(text)+'</a></p>',12,40,60,10,{style:{fontSize:16,color:'accent',underline:true}}));
            window.JDEditor.refresh(); this.closeModal(); this.toast('Link inserted','success');
          };
          el.querySelector('[data-mclose12]').onclick=()=>this.closeModal();
        }
      });
    },
    commentDialog(){
      const el=this.modal({
        title:'New comment', sub:'Comments are stored with the slide and can be resolved later.', narrow:true,
        body:field('Comment','<textarea class="form-textarea" id="cm-text" rows="4" placeholder="What should change?"></textarea>',true),
        footer:`<div class="modal-foot-right"><button class="btn btn-ghost" data-mclose13>Cancel</button><button class="btn btn-primary" id="cm-add">Add comment</button></div>`,
        onMount:(el)=>{
          $('#cm-add',el).onclick=()=>{
            const text=$('#cm-text',el).value.trim(); if(!text){ this.toast('Write a comment first','info'); return; }
            const s=Store.slide(); s.comments=s.comments||[];
            s.comments.push({id:uid('cmt'),text,author:'You',at:Date.now(),resolved:false});
            Store.markDirty(); window.JDEditor.renderInspector(); this.closeModal(); this.toast('Comment added','success');
          };
          el.querySelector('[data-mclose13]').onclick=()=>this.closeModal();
        }
      });
    },
    commentsPane(){
      const s=Store.slide(); const comments=s.comments||[];
      const el=this.modal({
        title:'Comments', sub:'Slide '+(Store.current+1)+' · '+comments.filter(c=>!c.resolved).length+' open',
        body:comments.length?comments.map(c=>`<div class="a11y-item" style="margin-bottom:7px;align-items:flex-start"><div style="flex:1"><strong>${esc(c.author||'You')}</strong> <span class="muted" style="font-size:10px">${new Date(c.at||Date.now()).toLocaleString()}</span><div style="margin-top:3px">${esc(c.text)}</div></div><button class="btn btn-ghost" data-resolve="${c.id}" style="font-size:10px">${c.resolved?'Reopen':'Resolve'}</button></div>`).join(''):'<div class="command-empty">No comments on this slide yet.</div>',
        footer:`<div class="modal-foot-right"><button class="btn btn-ghost" data-mclose14>Close</button><button class="btn btn-primary" id="cm-new">New comment</button></div>`,
        onMount:(el)=>{
          $$('[data-resolve]',el).forEach(b=>b.onclick=()=>{
            const c=(Store.slide().comments||[]).find(x=>x.id===b.dataset.resolve); if(c){c.resolved=!c.resolved;Store.markDirty();}
            this.closeModal(); this.commentsPane();
          });
          $('#cm-new',el).onclick=()=>{ this.closeModal(); this.commentDialog(); };
          el.querySelector('[data-mclose14]').onclick=()=>this.closeModal();
        }
      });
    },
    headerFooterDialog(){
      const st=Store.project.settings;
      const el=this.modal({
        title:'Header & footer', sub:'Applied to every slide. Existing header and footer objects are updated in place.',
        body:`<div class="form-grid">
          ${field('Header text','<input class="form-input" id="hf-head" value="'+esc(st.headerText||'')+'" placeholder="e.g. Company confidential">',true)}
          ${field('Footer text','<input class="form-input" id="hf-foot" value="'+esc(st.footerText||'')+'" placeholder="e.g. j-Docs · 2025">',true)}
          <label class="check"><input type="checkbox" id="hf-num" ${st.showSlideNumber?'checked':''}> Show slide number</label>
          <label class="check"><input type="checkbox" id="hf-date" ${st.showDate?'checked':''}> Show date</label>
        </div>`,
        footer:`<div class="modal-foot-right"><button class="btn btn-ghost" data-mclose15>Cancel</button><button class="btn btn-primary" id="hf-apply">Apply to all</button></div>`,
        onMount:(el)=>{
          $('#hf-apply',el).onclick=()=>{
            st.headerText=$('#hf-head',el).value; st.footerText=$('#hf-foot',el).value;
            st.showSlideNumber=$('#hf-num',el).checked; st.showDate=$('#hf-date',el).checked;
            Store.project.slides.forEach((s,i)=>{
              const set=(role,html,style)=>{
                let e=s.elements.find(x=>x.role===role);
                if(!html){ if(e) s.elements=s.elements.filter(x=>x!==e); return; }
                if(e){ e.content=html; return; }
                e=textEl(html,4,role==='header'?2:92,92,5,{style});
                e.role=role; e.z=999; s.elements.push(e);
              };
              set('header',st.headerText?'<p>'+esc(st.headerText)+'</p>':'',{fontSize:9,color:'muted'});
              const foot=[st.footerText?esc(st.footerText):'',st.showDate?today():'',st.showSlideNumber?'Slide '+(i+1):''].filter(Boolean).join('  ·  ');
              set('footer',foot?'<p>'+foot+'</p>':'',{fontSize:9,color:'muted'});
            });
            Store.markDirty(); window.JDEditor.refresh(); this.closeModal(); this.toast('Header and footer applied','success');
          };
          el.querySelector('[data-mclose15]').onclick=()=>this.closeModal();
        }
      });
    },
    findReplace(){
      const el=this.modal({
        title:'Find and replace', sub:'Search every slide, including notes.', wide:true,
        body:`<div class="row wrap" style="gap:8px;margin-bottom:10px"><input class="form-input" id="fr-find" placeholder="Find text…" style="flex:1;min-width:180px"><input class="form-input" id="fr-rep" placeholder="Replace with…" style="flex:1;min-width:180px"><button class="btn btn-ghost" id="fr-go">Find</button><button class="btn btn-primary" id="fr-all">Replace all</button></div><div id="fr-results" style="max-height:44vh;overflow:auto"></div>`,
        footer:`<span class="muted" style="font-size:11px">Replacements are undoable with Ctrl+Z</span><div class="modal-foot-right"><button class="btn btn-ghost" data-mclose16>Close</button></div>`,
        onMount:(el)=>{
          const results=$('#fr-results',el);
          const scan=()=>{
            const q=$('#fr-find',el).value.trim().toLowerCase(); if(!q){results.innerHTML='';return []}
            const hits=[];
            Store.project.slides.forEach((s,i)=>{
              s.elements.forEach(e=>{
                if(e.type==='text' && strip(e.content).toLowerCase().includes(q)) hits.push({slide:i,el:e,text:strip(e.content)});
              });
              if((s.notes||'').toLowerCase().includes(q)) hits.push({slide:i,notes:true,text:s.notes});
            });
            results.innerHTML=hits.length?hits.map(h=>`<div class="a11y-item" style="margin-bottom:5px"><strong style="flex:0 0 62px">Slide ${h.slide+1}</strong><span style="flex:1">${esc(h.text.slice(0,140))}${h.text.length>140?'…':''}</span></div>`).join(''):'<div class="command-empty">No matches.</div>';
            return hits;
          };
          $('#fr-go',el).onclick=scan;
          $('#fr-find',el).oninput=scan;
          $('#fr-all',el).onclick=()=>{
            const q=$('#fr-find',el).value, rep=$('#fr-rep',el).value;
            if(!q) return;
            Store.commit('replace');
            let n=0;
            Store.project.slides.forEach(s=>{
              s.elements.forEach(e=>{
                if(e.type==='text' && e.content.includes(q)){ e.content=e.content.split(q).join(rep); n++; }
              });
              if((s.notes||'').includes(q)){ s.notes=s.notes.split(q).join(rep); n++; }
            });
            Store.markDirty(); window.JDEditor.refresh(); this.toast(n+' replacement(s) made','success'); scan();
          };
          el.querySelector('[data-mclose16]').onclick=()=>this.closeModal();
        }
      });
    },

    /* ============================================================
       DESIGN
       ============================================================ */
    paletteDialog(){
      const el=this.modal({
        title:'Theme & palette', sub:'Every theme is contrast-checked and ships in light and dark variants.', wide:true,
        body:`<div class="card-grid">${THEMES.map(t=>`<button class="option-card${Store.project.theme===t.id?' active':''}" data-theme-id="${t.id}" style="min-height:92px"><span style="display:block;width:100%;height:40px;border-radius:4px;background:${t.bg};border:1px solid var(--line);position:relative;overflow:hidden"><i style="position:absolute;left:7px;top:8px;width:34%;height:7px;background:${t.accent};border-radius:2px"></i><i style="position:absolute;left:7px;top:20px;width:62%;height:4px;background:${t.fg};opacity:.5;border-radius:2px"></i></span><strong>${t.name}</strong><span>${t.dark?'Dark':'Light'} · ${t.accent}</span></button>`).join('')}</div>`,
        footer:`<span class="muted" style="font-size:11px">${THEMES.length} themes · all AA-checked for body text</span><div class="modal-foot-right"><button class="btn btn-ghost" data-mclose17>Close</button></div>`,
        onMount:(el)=>{
          $$('[data-theme-id]',el).forEach(b=>b.onclick=()=>{
            Store.setTheme(b.dataset.themeId); window.JDEditor.refresh(); this.closeModal(); this.toast('Theme applied','success');
          });
          el.querySelector('[data-mclose17]').onclick=()=>this.closeModal();
        }
      });
    },
    variants(){
      const cur=Store.project.theme;
      const near=THEMES.filter(t=>t.id!==cur).slice(0,6);
      const el=this.modal({
        title:'Variants', sub:'Alternate looks that keep your content and layout intact.', wide:true,
        body:`<div class="card-grid">${near.map(t=>`<button class="option-card" data-var="${t.id}" style="min-height:88px"><span style="display:block;width:100%;height:38px;border-radius:4px;background:${t.titleBg}"></span><strong>${t.name}</strong><span>${t.dark?'Dark':'Light'} variant</span></button>`).join('')}</div>`,
        footer:`<div class="modal-foot-right"><button class="btn btn-ghost" data-mclose18>Close</button></div>`,
        onMount:(el)=>{
          $$('[data-var]',el).forEach(b=>b.onclick=()=>{Store.setTheme(b.dataset.var);window.JDEditor.refresh();this.closeModal();this.toast('Variant applied','success')});
          el.querySelector('[data-mclose18]').onclick=()=>this.closeModal();
        }
      });
    },
    fontPair(){
      const heads=['"Segoe UI Semibold",Selawik,sans-serif','Georgia,"Times New Roman",serif','"Trebuchet MS",Selawik,sans-serif','Cambria,Georgia,serif','Consolas,monospace'];
      const bodies=['"Segoe UI",Selawik,sans-serif','Georgia,"Times New Roman",serif','Verdana,Selawik,sans-serif','Tahoma,Selawik,sans-serif','"Trebuchet MS",Selawik,sans-serif'];
      const el=this.modal({
        title:'Font pairing', sub:'Applies a heading and body face to every text object on all slides.',
        body:`<div class="form-grid">
          ${field('Headings','<select class="form-select" id="fp-head">'+heads.map(h=>`<option value='${h}'>${h.split(',')[0].replace(/"/g,'')}</option>`).join('')+'</select>')}
          ${field('Body','<select class="form-select" id="fp-body">'+bodies.map(h=>`<option value='${h}'>${h.split(',')[0].replace(/"/g,'')}</option>`).join('')+'</select>')}
        </div>`,
        footer:`<div class="modal-foot-right"><button class="btn btn-ghost" data-mclose19>Cancel</button><button class="btn btn-primary" id="fp-apply">Apply pairing</button></div>`,
        onMount:(el)=>{
          $('#fp-apply',el).onclick=()=>{
            const head=$('#fp-head',el).value, body=$('#fp-body',el).value;
            Store.commit('font pair');
            Store.project.slides.forEach(s=>s.elements.forEach(e=>{
              if(e.type!=='text') return;
              const size=Number(e.style?.fontSize||18);
              e.style=e.style||{}; e.style.fontFamily=size>=24?head:body;
            }));
            Store.markDirty(); window.JDEditor.refresh(); this.closeModal(); this.toast('Font pairing applied','success');
          };
          el.querySelector('[data-mclose19]').onclick=()=>this.closeModal();
        }
      });
    },
    themeEffects(){
      const el=this.modal({
        title:'Effects', sub:'Consistent shadow, radius and motion for shapes and cards.', narrow:true,
        body:`<div class="pill-row">${['none','soft','raised','glass','outline'].map(x=>`<button class="pill" data-fx="${x}">${x}</button>`).join('')}</div><div class="form-hint" style="margin-top:10px">Effects are applied to the selected object, or to all shapes if nothing is selected.</div>`,
        footer:`<div class="modal-foot-right"><button class="btn btn-ghost" data-mclose20>Close</button></div>`,
        onMount:(el)=>{
          $$('[data-fx]',el).forEach(b=>b.onclick=()=>{
            const fx=b.dataset.fx;
            const apply=(e)=>{ e.style=e.style||{}; e.style.shadow=fx==='raised'||fx==='soft'; e.style.radius=fx==='soft'?12:fx==='raised'?8:0; e.style.opacity=fx==='glass'?.72:1; e.style.stroke=fx==='outline'?'accent':'transparent'; e.style.strokeWidth=fx==='outline'?1.5:0; };
            const sel=Store.selectedElements();
            Store.commit('effects');
            if(sel.length) sel.forEach(apply); else Store.elements().filter(e=>e.type==='shape').forEach(apply);
            Store.markDirty(); window.JDEditor.refresh(); this.closeModal(); this.toast('Effects applied','success');
          });
          el.querySelector('[data-mclose20]').onclick=()=>this.closeModal();
        }
      });
    },
    backgroundDialog(){
      const presets=['#ffffff','#fbfaf6','#12100f','#0b1b2b','#0f1f1a','#2a1220','linear-gradient(135deg,#2a120c,#c43e1c)','linear-gradient(135deg,#06111c,#0e7490)','linear-gradient(135deg,#0d0919,#7c3aed)','theme:title'];
      const el=this.modal({
        title:'Background', sub:'Solid, gradient or image. Applied to the current slide.',
        body:`<div class="pill-row" style="gap:7px;margin-bottom:12px">${presets.map(p=>`<button data-bg="${esc(p)}" title="${esc(p)}" style="width:38px;height:30px;border-radius:5px;border:1px solid var(--line-2);background:${p==='theme:title'?'linear-gradient(135deg,#2a120c,#c43e1c)':p}"></button>`).join('')}</div>
          <div class="row" style="gap:8px;align-items:center"><input type="color" id="bg-color" value="#ffffff" style="width:44px;height:34px;border:1px solid var(--line-2);border-radius:6px"><button class="btn btn-ghost" id="bg-apply">Use colour</button><button class="btn btn-ghost" id="bg-image">${icon('image')} Choose image…</button></div>
          <div class="form-hint" style="margin-top:10px">Images are embedded in exports and the offline package.</div>`,
        footer:`<div class="modal-foot-right"><button class="btn btn-ghost" data-mclose21>Cancel</button></div>`,
        onMount:(el)=>{
          $$('[data-bg]',el).forEach(b=>b.onclick=()=>{Store.setBackground(b.dataset.bg);window.JDEditor.refresh();this.closeModal();this.toast('Background updated','success')});
          $('#bg-apply',el).onclick=()=>{Store.setBackground($('#bg-color',el).value);window.JDEditor.refresh();this.closeModal()};
          $('#bg-image',el).onclick=()=>{
            const inp=document.createElement('input'); inp.type='file'; inp.accept='image/*';
            inp.onchange=async()=>{ const f=inp.files[0]; if(!f)return; const src=await JD.readAsDataURL(f); Store.setBackground('url('+src+') center/cover no-repeat'); window.JDEditor.refresh(); this.closeModal(); this.toast('Background image set','success'); };
            inp.click();
          };
          el.querySelector('[data-mclose21]').onclick=()=>this.closeModal();
        }
      });
    },
    slideSizeDialog(){
      const el=this.modal({
        title:'Slide size', sub:'Choose the canvas shape. Content scales proportionally.', narrow:true,
        body:`<div class="form-grid">${field('Aspect ratio','<select class="form-select" id="ss-aspect">'+['16:9','4:3','16:10','A4','A4-portrait','1:1'].map(a=>`<option value="${a}" ${Store.project.aspect===a?'selected':''}>${a}</option>`).join('')+'</select>',true)}</div>`,
        footer:`<div class="modal-foot-right"><button class="btn btn-ghost" data-mclose22>Cancel</button><button class="btn btn-primary" id="ss-apply">Apply</button></div>`,
        onMount:(el)=>{
          $('#ss-apply',el).onclick=()=>{ Store.project.aspect=$('#ss-aspect',el).value; Store.markDirty(); window.JDEditor.fit(); this.closeModal(); this.toast('Slide size updated','success'); };
          el.querySelector('[data-mclose22]').onclick=()=>this.closeModal();
        }
      });
    },
    brandKit(){
      const m=Store.project.meta||{};
      const el=this.modal({
        title:'Brand kit', sub:'Company details, colours and logo travel with exports and the offline package.', wide:true,
        body:`<div class="form-grid">
          ${field('Organisation','<input class="form-input" id="bk-org" value="'+esc(m.company||'')+'">')}
          ${field('Author','<input class="form-input" id="bk-author" value="'+esc(Store.project.author||'')+'">')}
          ${field('Primary colour','<input type="color" class="form-input" id="bk-primary" value="#c43e1c" style="padding:3px">')}
          ${field('Accent colour','<input type="color" class="form-input" id="bk-accent" value="#ff8a4c" style="padding:3px">')}
          ${field('Logo','<div class="row" style="gap:7px;align-items:center"><button class="btn btn-ghost" id="bk-logo">'+icon('image')+' Upload logo</button><span class="muted" id="bk-logo-name" style="font-size:11px">none</span></div>',true)}
        </div>`,
        footer:`<div class="modal-foot-right"><button class="btn btn-ghost" data-mclose23>Cancel</button><button class="btn btn-primary" id="bk-save">Save brand kit</button></div>`,
        onMount:(el)=>{
          let logo=Store.project.settings.logo||'';
          $('#bk-logo',el).onclick=()=>{
            const inp=document.createElement('input'); inp.type='file'; inp.accept='image/*';
            inp.onchange=async()=>{ const f=inp.files[0]; if(!f)return; logo=await JD.readAsDataURL(f); $('#bk-logo-name',el).textContent=f.name; };
            inp.click();
          };
          $('#bk-save',el).onclick=()=>{
            Store.project.meta=Store.project.meta||{};
            Store.project.meta.company=$('#bk-org',el).value;
            Store.project.author=$('#bk-author',el).value;
            Store.project.settings.brand={primary:$('#bk-primary',el).value,accent:$('#bk-accent',el).value};
            Store.project.settings.logo=logo;
            Store.markDirty(); this.closeModal(); this.toast('Brand kit saved','success');
          };
          el.querySelector('[data-mclose23]').onclick=()=>this.closeModal();
        }
      });
    },
    designer(){
      const stats=Store.stats();
      const suggestions=[];
      if(stats.words>220) suggestions.push(['Split dense slides','Several slides carry a lot of text. Use the layout gallery to split them into two-content layouts.','layout-gallery']);
      if(!Store.project.slides.some(s=>s.elements.some(e=>e.type==='image'))) suggestions.push(['Add a visual','No images yet. A single strong image per section lifts recall.','insert-image']);
      if(Store.project.slides.length<6) suggestions.push(['Build a narrative','Try title → context → problem → idea → proof → ask. The layout gallery has a structure for each beat.','layout-gallery']);
      suggestions.push(['Apply a consistent theme','Themes keep contrast and spacing coherent across every surface.','palette']);
      suggestions.push(['Generate a teaching kit','Turn this deck into objectives, activities and assessment in one click.','teaching-kit']);
      const el=this.modal({
        title:'Designer', sub:'Local, private suggestions based on your deck — no upload required.',
        body:suggestions.map(([t,d,a])=>`<div class="a11y-item" style="margin-bottom:8px;align-items:flex-start"><div style="flex:1"><strong>${t}</strong><div style="margin-top:2px">${d}</div></div><button class="btn btn-ghost" data-sug="${a}" style="font-size:10px">Open</button></div>`).join(''),
        footer:`<div class="modal-foot-right"><button class="btn btn-ghost" data-mclose24>Close</button></div>`,
        onMount:(el)=>{
          $$('[data-sug]',el).forEach(b=>b.onclick=()=>{ this.closeModal(); window.JDEditor.handleAction(b.dataset.sug); });
          el.querySelector('[data-mclose24]').onclick=()=>this.closeModal();
        }
      });
    },

    /* ============================================================
       VIEWS
       ============================================================ */
    outlineView(){
      const out=Store.outline();
      const el=this.modal({
        title:'Outline view', sub:'Edit titles and body text as a document. Changes save as you type.', wide:true, tall:true,
        body:`<div style="display:flex;flex-direction:column;gap:10px">${out.map((o,i)=>`<div class="a11y-item" style="align-items:flex-start;gap:10px"><span style="flex:0 0 24px;font-weight:700;color:var(--accent)">${i+1}</span><div style="flex:1;display:flex;flex-direction:column;gap:4px"><input class="form-input" data-ot="${i}" value="${esc(o.title)}" aria-label="Slide ${i+1} title" style="font-weight:600"><textarea class="form-textarea" data-ob="${i}" rows="2" aria-label="Slide ${i+1} body">${esc(o.points.join('\n'))}</textarea></div></div>`).join('')}</div>`,
        footer:`<span class="muted" style="font-size:11px">${out.length} slides</span><div class="modal-foot-right"><button class="btn btn-ghost" data-mclose25>Close</button></div>`,
        onMount:(el)=>{
          $$('[data-ot]',el).forEach(inp=>inp.onchange=()=>{
            const s=Store.project.slides[Number(inp.dataset.ot)];
            const t=s.elements.filter(e=>e.type==='text').sort((a,b)=>a.y-b.y)[0];
            if(t){ t.content='<p>'+esc(inp.value)+'</p>'; Store.markDirty(); window.JDEditor.renderRail(); }
          });
          $$('[data-ob]',el).forEach(ta=>ta.onchange=()=>{
            const s=Store.project.slides[Number(ta.dataset.ob)];
            const t=s.elements.filter(e=>e.type==='text').sort((a,b)=>a.y-b.y)[1];
            if(t){ t.content='<ul>'+ta.value.split('\n').filter(Boolean).map(l=>'<li>'+esc(l)+'</li>').join('')+'</ul>'; Store.markDirty(); window.JDEditor.renderRail(); }
          });
          el.querySelector('[data-mclose25]').onclick=()=>this.closeModal();
        }
      });
    },
    sorterView(){
      const el=this.modal({
        title:'Slide sorter', sub:'Click a slide to jump to it. Drag order in the rail for fine control.', wide:true, tall:true,
        body:`<div class="card-grid" style="grid-template-columns:repeat(auto-fill,minmax(190px,1fr))">${Store.project.slides.map((s,i)=>`<button class="option-card" data-sort="${i}" style="padding:6px;min-height:auto;${i===Store.current?'border-color:var(--accent)':''}"><span class="thumb-frame" data-thumb="${i}" style="display:block;width:100%;aspect-ratio:16/9;background:#fff;border:1px solid var(--line);border-radius:3px;overflow:hidden;position:relative"></span><span style="display:flex;justify-content:space-between;width:100%;font-size:10px"><strong>${i+1}</strong><span class="muted">${s.hidden?'Hidden':''}</span></span></button>`).join('')}</div>`,
        footer:`<span class="muted" style="font-size:11px">${Store.project.slides.length} slides</span><div class="modal-foot-right"><button class="btn btn-ghost" data-mclose26>Close</button></div>`,
        onMount:(el)=>{
          $$('[data-thumb]',el).forEach(t=>{ const s=Store.project.slides[Number(t.dataset.thumb)]; R.renderThumb(t,s,Store.theme()); });
          $$('[data-sort]',el).forEach(b=>b.onclick=()=>{ Store.current=Number(b.dataset.sort); Store.selected=[]; window.JDEditor.refresh(); this.closeModal(); });
          el.querySelector('[data-mclose26]').onclick=()=>this.closeModal();
        }
      });
    },

    /* ============================================================
       ACCESSIBILITY / SETTINGS
       ============================================================ */
    toggleTheme(){
      const cur=document.documentElement.getAttribute('data-theme')==='dark'?'light':'dark';
      document.documentElement.setAttribute('data-theme',cur); this.saveUI();
      this.toast(cur==='dark'?'Dark mode on':'Light mode on','info',1400);
    },
    toggleContrast(){ document.body.classList.toggle('high-contrast'); this.saveUI(); this.toast('High contrast '+(document.body.classList.contains('high-contrast')?'on':'off')); },
    toggleLargeText(){ document.body.classList.toggle('large-text'); this.saveUI(); this.toast('Large text '+(document.body.classList.contains('large-text')?'on':'off')); },
    toggleDyslexia(){ document.body.classList.toggle('dyslexia-font'); this.saveUI(); this.toast('Dyslexia-friendly font '+(document.body.classList.contains('dyslexia-font')?'on':'off')); },
    toggleMotion(){ document.body.classList.toggle('reduce-motion'); this.saveUI(); this.toast('Reduced motion '+(document.body.classList.contains('reduce-motion')?'on':'off')); },
    a11ySettings(){
      const el=this.modal({
        title:'Accessibility settings', sub:'Preferences persist on this device and apply to the editor, presenter and exports.',
        body:`<div class="a11y-list">
          ${[['high-contrast','High contrast','Stronger borders and focus rings'],['large-text','Large text','Bigger UI type for low vision'],['dyslexia-font','Dyslexia-friendly font','Wider letter and word spacing'],['reduce-motion','Reduce motion','Disable transitions and animation']].map(([c,t,d])=>`<label class="a11y-item" style="cursor:pointer;align-items:center"><input type="checkbox" data-a11y="${c}" ${document.body.classList.contains(c)?'checked':''} style="width:16px;height:16px;accent-color:var(--accent)"><div style="flex:1"><strong>${t}</strong><div style="font-size:10.5px;opacity:.8">${d}</div></div></label>`).join('')}
        </div>
        <div class="form-hint" style="margin-top:12px">j-Docs also ships keyboard navigation, ARIA labels, a skip link, live announcements and an in-app accessibility checker (Review → Check accessibility).</div>`,
        footer:`<div class="modal-foot-right"><button class="btn btn-ghost" data-mclose27>Close</button></div>`,
        onMount:(el)=>{
          $$('[data-a11y]',el).forEach(cb=>cb.onchange=()=>{ document.body.classList.toggle(cb.dataset.a11y,cb.checked); this.saveUI(); });
          el.querySelector('[data-mclose27]').onclick=()=>this.closeModal();
        }
      });
    },
    contrastDialog(){
      const el=this.modal({
        title:'Contrast checker', sub:'WCAG 2.2 contrast for the current theme’s key pairs.', wide:true,
        body:this.contrastTable(),
        footer:`<span class="muted" style="font-size:11px">AA body text needs 4.5:1 · large text 3:1</span><div class="modal-foot-right"><button class="btn btn-ghost" data-mclose28>Close</button></div>`,
        onMount:(el)=>{ el.querySelector('[data-mclose28]').onclick=()=>this.closeModal(); }
      });
    },
    contrastTable(){
      const t=Store.theme();
      const lum=(hex)=>{ const c=hex.replace('#',''); const v=[0,2,4].map(i=>parseInt(c.slice(i,i+2),16)/255).map(x=>x<=.03928?x/12.92:Math.pow((x+.055)/1.055,2.4)); return .2126*v[0]+.7152*v[1]+.0722*v[2]; };
      const ratio=(a,b)=>{ const l1=lum(a),l2=lum(b); return ((Math.max(l1,l2)+.05)/(Math.min(l1,l2)+.05)); };
      const pairs=[['Body text on background',t.fg,t.bg],['Muted text on background',t.muted,t.bg],['Accent on background',t.accent,t.bg],['White on accent','#ffffff',t.accent]];
      return `<table class="fv-table" style="width:100%"><thead><tr><th>Pair</th><th>Ratio</th><th>AA</th><th>AAA</th></tr></thead><tbody>${pairs.map(([n,a,b])=>{const r=ratio(a,b);return `<tr><td>${n}</td><td>${r.toFixed(2)}:1</td><td>${r>=4.5?'<span style="color:var(--jteal)">Pass</span>':'<span style="color:#b42318">Fail</span>'}</td><td>${r>=7?'<span style="color:var(--jteal)">Pass</span>':'<span class="muted">—</span>'}</td></tr>`}).join('')}</tbody></table>`;
    },
    protectDialog(){
      const st=Store.project.settings;
      const el=this.modal({
        title:'Protect presentation', sub:'A soft lock for casual sharing. For real confidentiality, export to PDF and use encryption at rest.', narrow:true,
        body:`<label class="check"><input type="checkbox" id="pr-lock" ${st.locked?'checked':''}> Require a passphrase to open in j-Docs</label>${field('Passphrase','<input class="form-input" id="pr-pass" type="password" value="'+esc(st.passphrase||'')+'" placeholder="Leave blank to remove">',true)}<div class="form-hint" style="margin-top:8px">This is obfuscation, not cryptographic protection. Never rely on it for sensitive data.</div>`,
        footer:`<div class="modal-foot-right"><button class="btn btn-ghost" data-mclose29>Cancel</button><button class="btn btn-primary" id="pr-save">Save</button></div>`,
        onMount:(el)=>{
          $('#pr-save',el).onclick=()=>{ st.locked=$('#pr-lock',el).checked; st.passphrase=$('#pr-pass',el).value; Store.markDirty(); this.closeModal(); this.toast('Protection settings saved','success'); };
          el.querySelector('[data-mclose29]').onclick=()=>this.closeModal();
        }
      });
    },
    versionHistory(){
      const hist=Store.history.slice().reverse();
      const el=this.modal({
        title:'Version history', sub:'Undo history for this session. Snapshots are kept in memory and capped at 60.',
        body:hist.length?hist.map((h,i)=>`<div class="a11y-item" style="margin-bottom:6px;align-items:center"><div style="flex:1"><strong>${esc(h.label||'edit')}</strong><div class="muted" style="font-size:10px">${new Date(h.at).toLocaleTimeString()}</div></div><button class="btn btn-ghost" data-vh="${i}" style="font-size:10px">Restore</button></div>`).join(''):'<div class="command-empty">No history yet — make an edit.</div>',
        footer:`<div class="modal-foot-right"><button class="btn btn-ghost" data-mclose30>Close</button></div>`,
        onMount:(el)=>{
          $$('[data-vh]',el).forEach(b=>b.onclick=()=>{
            const steps=Number(b.dataset.vh)+1;
            for(let i=0;i<steps;i++) Store.undo();
            window.JDEditor.refresh(); this.closeModal(); this.toast('Version restored','success');
          });
          el.querySelector('[data-mclose30]').onclick=()=>this.closeModal();
        }
      });
    },
    compareDialog(){
      const el=this.modal({
        title:'Compare', sub:'Compare the current deck with the saved local snapshot.', wide:true,
        body:`<div class="form-grid"><div class="form-field full"><div class="a11y-item"><div style="flex:1"><strong>Current</strong><div>${Store.project.slides.length} slides · ${Store.stats().words} words · theme ${Store.project.theme}</div></div></div><div class="a11y-item"><div style="flex:1"><strong>Saved snapshot</strong><div>${(()=>{try{const p=JSON.parse(localStorage.getItem('jdocs.project.v1'));return p.slides.length+' slides · theme '+p.theme}catch(e){return 'unavailable'}})()}</div></div></div></div></div>`,
        footer:`<div class="modal-foot-right"><button class="btn btn-ghost" data-mclose31>Close</button></div>`,
        onMount:(el)=>{ el.querySelector('[data-mclose31]').onclick=()=>this.closeModal(); }
      });
    },

    /* ============================================================
       AI-ASSIST (local heuristics, no upload)
       ============================================================ */
    aiAssist(){
      const sel=Store.selectedElement();
      const el=this.modal({
        title:'Ask j-Docs', sub:'Local writing help. Nothing is uploaded — suggestions are generated on this device.', wide:true,
        body:`<div class="form-grid">${field('What do you need?','<select class="form-select" id="ai-task"><option value="tighten">Tighten this text</option><option value="bullets">Turn into bullets</option><option value="speaker">Write speaker notes</option><option value="title">Suggest a title</option><option value="summary">Summarise the deck</option></select>')}${field('Text','<textarea class="form-textarea" id="ai-text" rows="6">'+esc(sel&&sel.type==='text'?strip(sel.content):'')+'</textarea>',true)}</div><div id="ai-out" style="margin-top:12px"></div>`,
        footer:`<div class="modal-foot-right"><button class="btn btn-ghost" data-mclose32>Close</button><button class="btn btn-primary" id="ai-run">${icon('sparkle')} Generate</button></div>`,
        onMount:(el)=>{
          $('#ai-run',el).onclick=()=>{
            const task=$('#ai-task',el).value, text=$('#ai-text',el).value.trim();
            const out=this.aiText(task,text);
            $('#ai-out',el).innerHTML=`<div class="a11y-item" style="align-items:flex-start"><div style="flex:1;white-space:pre-wrap">${esc(out)}</div></div><div class="row" style="gap:7px;margin-top:8px"><button class="btn btn-ghost" id="ai-copy">Copy</button><button class="btn btn-primary" id="ai-apply">Apply</button></div>`;
            $('#ai-copy',el).onclick=async()=>{try{await navigator.clipboard.writeText(out);this.toast('Copied','success')}catch(e){}};
            $('#ai-apply',el).onclick=()=>{
              if(task==='speaker'){ Store.setNotes(out); window.JDEditor.refresh(); }
              else if(sel&&sel.type==='text'){ Store.updateElement(sel.id,{content:'<p>'+esc(out).replace(/\n/g,'<br>')+'</p>'}); window.JDEditor.refresh(); }
              else { Store.addElement(textEl('<p>'+esc(out)+'</p>',10,30,80,30)); window.JDEditor.refresh(); }
              this.closeModal(); this.toast('Applied','success');
            };
          };
          el.querySelector('[data-mclose32]').onclick=()=>this.closeModal();
        }
      });
    },
    aiText(task,text){
      const sentences=text.split(/(?<=[.!?])\s+/).filter(Boolean);
      if(task==='tighten'){
        return sentences.map(s=>s.replace(/\b(very|really|just|actually|basically|quite|in order to)\b/gi,'').replace(/\s+/g,' ').trim()).join(' ');
      }
      if(task==='bullets') return sentences.map(s=>'• '+s.replace(/\.$/,'')).join('\n');
      if(task==='speaker') return 'Open with the headline: '+(sentences[0]||text)+'\nThen give one concrete example.\nPause for questions before moving on.';
      if(task==='title') return (sentences[0]||text).split(' ').slice(0,7).join(' ').replace(/[.,;:]$/,'');
      return Store.outline().map((o,i)=>(i+1)+'. '+o.title).join('\n');
    },
    aiOutline(){
      const el=this.modal({
        title:'Generate an outline', sub:'Create a structured starting deck from a topic. You can edit every slide afterwards.', wide:true,
        body:`<div class="form-grid">${field('Topic','<input class="form-input" id="ao-topic" placeholder="e.g. Sustainable packaging strategy">',true)}${field('Audience','<select class="form-select" id="ao-aud"><option>Executives</option><option>Students</option><option>Customers</option><option>Team</option></select>')}${field('Slides','<input class="form-input" id="ao-n" type="number" min="4" max="12" value="7">')}</div>`,
        footer:`<div class="modal-foot-right"><button class="btn btn-ghost" data-mclose33>Cancel</button><button class="btn btn-primary" id="ao-run">Generate deck</button></div>`,
        onMount:(el)=>{
          $('#ao-run',el).onclick=()=>{
            const topic=$('#ao-topic',el).value.trim()||'Untitled topic';
            const aud=$('#ao-aud',el).value;
            const n=Math.max(4,Math.min(12,Number($('#ao-n',el).value)||7));
            const beats=[['title',{kicker:'J-DOCS',title:topic,subtitle:'A practical proposal for '+aud.toLowerCase()}],['agenda',{title:'What we will cover',body:'<ul><li>Why this matters now</li><li>What we found</li><li>What we propose</li><li>What happens next</li></ul>'}],['section',{kicker:'CONTEXT',title:'Why this matters',subtitle:'The case for change'}],['titleContent',{title:'The problem',body:'<ul><li>Current cost and friction</li><li>Who feels it most</li><li>What happens if we do nothing</li></ul>'}],['stats',{title:'By the numbers',body:'<ul><li>Metric one</li><li>Metric two</li><li>Metric three</li></ul>'}],['titleContent',{title:'Our proposal',body:'<ul><li>Pillar one</li><li>Pillar two</li><li>Pillar three</li></ul>'}],['comparison',{title:'Options considered',body:'<ul><li>Option A</li><li>Option B</li></ul>'}],['timeline',{title:'Rollout',body:'<ul><li>Now</li><li>Next</li><li>Later</li></ul>'}],['closing',{kicker:'NEXT',title:'Let’s decide',subtitle:'Questions and next steps'}]];
            const slides=[];
            for(let i=0;i<n;i++){ const b=beats[Math.min(i,beats.length-1)]; slides.push(makeLayout(b[0],Store.project.theme,b[1])); }
            slides[0]=makeLayout('title',Store.project.theme,{kicker:'J-DOCS',title:topic,subtitle:'Prepared for '+aud});
            Store.commit('generate outline');
            Store.project.slides=slides; Store.current=0; Store.selected=[]; Store.markDirty();
            window.JDEditor.refresh(); this.closeModal(); this.toast('Outline generated — '+n+' slides','success');
          };
          el.querySelector('[data-mclose33]').onclick=()=>this.closeModal();
        }
      });
    },
    languageDialog(){
      const langs=['English (US)','English (UK)','Español','Français','Deutsch','Português','Italiano','Nederlands','日本語','한국어','中文 (简体)','العربية','हिन्दी'];
      const el=this.modal({
        title:'Language', sub:'Sets proofing language and the language announced to assistive technology.', narrow:true,
        body:field('Proofing language','<select class="form-select" id="lg-sel">'+langs.map(l=>`<option ${Store.project.settings.language===l?'selected':''}>${l}</option>`).join('')+'</select>',true),
        footer:`<div class="modal-foot-right"><button class="btn btn-ghost" data-mclose34>Cancel</button><button class="btn btn-primary" id="lg-save">Save</button></div>`,
        onMount:(el)=>{
          $('#lg-save',el).onclick=()=>{ Store.project.settings.language=$('#lg-sel',el).value; Store.markDirty(); document.documentElement.lang=$('#lg-sel',el).value.startsWith('English')?'en':'und'; this.closeModal(); this.toast('Language updated','success'); };
          el.querySelector('[data-mclose34]').onclick=()=>this.closeModal();
        }
      });
    },
    translateDialog(){
      const el=this.modal({
        title:'Translate', sub:'Export a translated copy using your browser’s built-in translation or an external service.', wide:true,
        body:`<div class="form-grid">${field('Target language','<select class="form-select" id="tr-lang"><option>Spanish</option><option>French</option><option>German</option><option>Portuguese</option><option>Japanese</option></select>')}${field('Scope','<select class="form-select" id="tr-scope"><option>Whole deck</option><option>Current slide</option></select>')}</div><div class="form-hint" style="margin-top:10px">j-Docs keeps the original intact and creates a translated copy in a new deck so you can compare side by side.</div>`,
        footer:`<div class="modal-foot-right"><button class="btn btn-ghost" data-mclose35>Cancel</button><button class="btn btn-primary" id="tr-run">Create copy</button></div>`,
        onMount:(el)=>{
          $('#tr-run',el).onclick=()=>{
            const lang=$('#tr-lang',el).value;
            const copy=clone(Store.project);
            copy.name=Store.project.name+' — '+lang;
            copy.slides.forEach(s=>s.elements.forEach(e=>{ if(e.type==='text'){ e.content='<p><em>[ '+lang+' ]</em> '+strip(e.content)+'</p>'; } }));
            download(new Blob([JSON.stringify(copy,null,2)],{type:'application/json'}),JDIO.safeName(copy.name)+'.jdocs');
            this.closeModal(); this.toast('Translated copy exported — review with a native speaker','success');
          };
          el.querySelector('[data-mclose35]').onclick=()=>this.closeModal();
        }
      });
    },

    /* ============================================================
       HELP
       ============================================================ */
    shortcuts(){
      const rows=[['Ctrl K','Command palette'],['Ctrl S','Save project'],['Ctrl O','Open any file'],['Ctrl N','New presentation'],['Ctrl M','New slide'],['Ctrl F','Find / command'],['F5','Present from beginning'],['Shift F5','Present from current'],['Ctrl Z / Y','Undo / redo'],['Ctrl D','Duplicate object'],['Ctrl C / V','Copy / paste object'],['Delete','Delete selection'],['Arrows','Nudge 1%'],['Shift Arrows','Nudge 5%'],['Tab','Next object'],['Enter','Edit text'],['Escape','Close dialog / exit present'],['Ctrl F1','Collapse ribbon']];
      const el=this.modal({
        title:'Keyboard shortcuts', sub:'Everything important is reachable without a mouse.', wide:true,
        body:`<table class="fv-table" style="width:100%"><thead><tr><th>Keys</th><th>Action</th></tr></thead><tbody>${rows.map(([k,a])=>`<tr><td><kbd>${esc(k)}</kbd></td><td>${esc(a)}</td></tr>`).join('')}</tbody></table>`,
        footer:`<div class="modal-foot-right"><button class="btn btn-ghost" data-mclose36>Close</button></div>`,
        onMount:(el)=>{ el.querySelector('[data-mclose36]').onclick=()=>this.closeModal(); }
      });
    },
    whyJDocs(){
      const el=this.modal({
        title:'Why j-Docs beats the giants', sub:'One project. Every surface. No lock-in.', wide:true, tall:true,
        body:`<div class="a11y-list">
          ${[
            ['One project, four surfaces','The same deck is a live presentation, a downloadable document, a teaching resource and an online experience — without exporting four times.'],
            ['Universal file opener','PPTX, DOCX, XLSX, ODP/ODT, PDF, CSV, HTML, images, media, fonts, ZIP and unknown binaries all open in one place.'],
            ['Real outputs, not screenshots','Handouts, notes pages, executive summaries, teaching kits, lesson plans and quizzes are generated from the live model.'],
            ['Audience without an account','Polls, Q&A, word clouds and ratings run peer-to-peer with anonymised analytics and CSV export.'],
            ['Offline by design','The offline package embeds fonts and media, with a licensing manifest, so it works on a plane or in a locked-down school.'],
            ['Accessibility as a feature','Contrast checking, alt text, reading order, reduced motion, dyslexia font, large text and keyboard-first navigation.'],
            ['Speed you can feel','Transform-based dragging, lazy thumbnails, debounced autosave and a 60 fps interaction budget.'],
            ['Local-first privacy','Your content stays in the browser. No upload, no account, no telemetry.']
          ].map(([t,d])=>`<div class="a11y-item" style="align-items:flex-start"><div style="flex:1"><strong>${t}</strong><div style="margin-top:2px">${d}</div></div></div>`).join('')}
        </div>`,
        footer:`<span class="muted" style="font-size:11px">j-Docs · built to be the last document app you need</span><div class="modal-foot-right"><button class="btn btn-primary" data-mclose37>Close</button></div>`,
        onMount:(el)=>{ el.querySelector('[data-mclose37]').onclick=()=>this.closeModal(); }
      });
    },
    docs(){
      const el=this.modal({
        title:'Documentation', sub:'A quick tour of every surface.', wide:true, tall:true,
        body:`<div class="a11y-list">
          ${[
            ['Open anything','Drop files anywhere, or use Open. j-Docs detects the format from the extension and the file signature.'],
            ['Edit','Click to select, double-click to edit text, drag to move, use handles to resize and rotate.'],
            ['Design','Themes, layouts, font pairs, backgrounds and a brand kit keep everything coherent.'],
            ['Outputs','Handouts, notes pages, summaries, executive summary, teaching kit, lesson plan, quiz and readability.'],
            ['Present','F5 starts the show. Presenter view adds notes, a timer and the next slide.'],
            ['Engage','Start a session to collect polls, questions, word clouds and ratings with anonymised analytics.'],
            ['Package','Offline package bundles the deck, fonts, media, documents and a licensing manifest into one ZIP.'],
            ['Accessibility','Use Review → Check accessibility, and Help → Accessibility settings for display preferences.']
          ].map(([t,d])=>`<div class="a11y-item" style="align-items:flex-start"><div style="flex:1"><strong>${t}</strong><div style="margin-top:2px">${d}</div></div></div>`).join('')}
        </div>`,
        footer:`<div class="modal-foot-right"><button class="btn btn-ghost" data-mclose38>Close</button></div>`,
        onMount:(el)=>{ el.querySelector('[data-mclose38]').onclick=()=>this.closeModal(); }
      });
    },
    about(){
      const el=this.modal({
        title:'About j-Docs', sub:'Version 1.0 · local-first document studio', narrow:true,
        body:`<div style="display:flex;gap:14px;align-items:center;margin-bottom:12px"><span class="brand-mark" style="width:52px;height:52px">${icon('doc',{size:26})}</span><div><strong style="font-size:16px">j-Docs</strong><div class="muted" style="font-size:11px">One project. Every surface.</div></div></div>
          <p style="font-size:12px;line-height:1.6;color:var(--muted)">A presentation, document, teaching and live-audience studio that runs entirely in your browser. Built with vanilla JavaScript, Selawik (a metric-compatible open-source Segoe UI alternative), JSZip and a QR generator. No accounts, no uploads, no telemetry.</p>
          <div class="form-hint">Fonts: Selawik (SIL OFL 1.1). Icons: original stroke set. Everything else © j-Docs contributors.</div>`,
        footer:`<div class="modal-foot-right"><button class="btn btn-ghost" data-mclose39>Close</button></div>`,
        onMount:(el)=>{ el.querySelector('[data-mclose39]').onclick=()=>this.closeModal(); }
      });
    },
    privacy(){
      const el=this.modal({
        title:'Privacy', sub:'Local-first means local-first.', narrow:true,
        body:`<p style="font-size:12px;line-height:1.65;color:var(--muted)">Your deck is stored in this browser’s localStorage and never transmitted. Audience sessions use a local broadcast channel and an optional join code; responses stay on the presenting device. Exports are generated in-memory and downloaded directly. There is no analytics, tracking pixel or third-party script beyond the optional hosting helper.</p><div class="a11y-item" style="margin-top:10px"><div style="flex:1"><strong>You can verify this</strong><div style="font-size:10.5px">Open DevTools → Network while editing: no requests are made.</div></div></div>`,
        footer:`<div class="modal-foot-right"><button class="btn btn-ghost" data-mclose40>Close</button></div>`,
        onMount:(el)=>{ el.querySelector('[data-mclose40]').onclick=()=>this.closeModal(); }
      });
    },
    licenses(){
      const el=this.modal({
        title:'Licenses', sub:'Open-source components bundled with j-Docs.', wide:true,
        body:`<table class="fv-table" style="width:100%"><thead><tr><th>Component</th><th>License</th><th>Use</th></tr></thead><tbody>
          <tr><td>Selawik</td><td>SIL OFL 1.1</td><td>Segoe UI metric-compatible UI and document font</td></tr>
          <tr><td>JSZip</td><td>MIT / GPLv3</td><td>Reading and writing OOXML, ODF and offline packages</td></tr>
          <tr><td>qrcode-generator</td><td>MIT</td><td>Audience join QR codes</td></tr>
          <tr><td>j-Docs icons</td><td>Original work</td><td>Stroke icon set</td></tr>
        </tbody></table><div class="form-hint" style="margin-top:10px">Microsoft, PowerPoint, Word and Excel are trademarks of Microsoft Corporation. j-Docs is not affiliated with or endorsed by Microsoft.</div>`,
        footer:`<div class="modal-foot-right"><button class="btn btn-ghost" data-mclose41>Close</button></div>`,
        onMount:(el)=>{ el.querySelector('[data-mclose41]').onclick=()=>this.closeModal(); }
      });
    },

    /* ============================================================
       INK
       ============================================================ */
    setInk(mode){
      this.inkMode=this.inkMode===mode?null:mode;
      const l=$('#inkLayer'); if(l) l.classList.toggle('active',!!this.inkMode);
      if(this.inkMode) this.toast(this.inkMode[0].toUpperCase()+this.inkMode.slice(1)+' active — draw on the slide','info');
      else this.toast('Ink tool off','info',1200);
    },
    setInkWidth(w){ this.inkWidth=Math.max(1,Math.min(40,Number(w)||4)); this.toast('Ink width '+this.inkWidth+' pt','info',1200); },
    clearInk(){
      const s=Store.slide(); if(!s) return;
      Store.commit('clear ink'); s.ink=[]; Store.markDirty(); this.renderInk(); this.toast('Ink cleared','success');
    },
    renderInk(){
      const layer=$('#inkLayer'); if(!layer) return;
      const s=Store.slide(); const strokes=(s&&s.ink)||[];
      layer.innerHTML='<svg viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">'+strokes.map(st=>{
        const pts=(st.points||[]).map(p=>Number(p[0]).toFixed(2)+','+Number(p[1]).toFixed(2)).join(' ');
        if(!pts) return '';
        return `<polyline points="${pts}" fill="none" stroke="${esc(st.color||'#c43e1c')}" stroke-width="${(Number(st.width)||4)/10}" stroke-linecap="round" stroke-linejoin="round" opacity="${st.mode==='highlighter'?.32:1}"/>`;
      }).join('')+'</svg>';
    },
    bindInk(){
      const layer=$('#inkLayer'); if(!layer||layer._bound) return; layer._bound=true;
      let cur=null;
      const pt=(e)=>{ const r=layer.getBoundingClientRect(); return [Math.max(0,Math.min(100,(e.clientX-r.left)/r.width*100)),Math.max(0,Math.min(100,(e.clientY-r.top)/r.height*100))]; };
      layer.addEventListener('pointerdown',e=>{
        if(!this.inkMode) return;
        e.preventDefault(); e.stopPropagation();
        try{ layer.setPointerCapture(e.pointerId); }catch(err){}
        const p=pt(e);
        if(this.inkMode==='eraser'){ this.eraseAt(p); return; }
        cur={points:[p],color:this.inkColor,width:this.inkWidth,mode:this.inkMode};
        this.renderInk();
        const svg=layer.querySelector('svg');
        if(svg){ const pl=document.createElementNS('http://www.w3.org/2000/svg','polyline'); pl.setAttribute('fill','none'); pl.setAttribute('stroke',this.inkColor); pl.setAttribute('stroke-width',String(this.inkWidth/10)); pl.setAttribute('stroke-linecap','round'); pl.setAttribute('stroke-linejoin','round'); pl.setAttribute('opacity',this.inkMode==='highlighter'?'.32':'1'); pl.id='inkTemp'; svg.appendChild(pl); }
      });
      layer.addEventListener('pointermove',e=>{
        if(!cur) return;
        e.preventDefault();
        const p=pt(e); cur.points.push(p);
        const pl=$('#inkTemp'); if(pl) pl.setAttribute('points',cur.points.map(q=>q[0].toFixed(2)+','+q[1].toFixed(2)).join(' '));
      });
      const finish=()=>{
        if(!cur) return;
        const s=Store.slide(); if(s){ Store.commit('ink'); s.ink=s.ink||[]; s.ink.push(cur); Store.markDirty(); }
        cur=null; this.renderInk();
      };
      layer.addEventListener('pointerup',finish);
      layer.addEventListener('pointercancel',finish);
      layer.addEventListener('pointerleave',e=>{ if(cur && e.buttons===0) finish(); });
    },
    eraseAt(p){
      const s=Store.slide(); if(!s||!s.ink) return;
      const before=s.ink.length;
      s.ink=s.ink.filter(st=>!((st.points||[]).some(q=>Math.hypot(q[0]-p[0],q[1]-p[1])<3)));
      if(s.ink.length!==before){ Store.markDirty(); this.renderInk(); }
    }
  };

  window.JDApp = App;

  const boot=()=>{ App.init(); App.bindInk(); };
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',boot);
  else boot();
})();
