# How j-Docs Beats the Giants

*Beyond Imagination — a competitive strategy for a document app that refuses to treat the deck as the end of the content.*

---

## 1. The problem nobody has solved

PowerPoint, Keynote, Google Slides, Canva, and the long tail of "AI deck" startups all compete on the same axis: making slides faster to produce. They have spent twenty years shaving seconds off the act of arranging rectangles. What none of them has done is ask the more important question — what is the deck *for*?

A presentation is almost never the deliverable. It is an intermediate artifact. The moment the last slide is shown, the same content has to become a handout for the people who attended, a summary for the people who did not, a set of speaker notes for the next presenter, a teaching resource for a workshop, a quiz for a class, a PDF for the legal file, an offline package for a venue with bad Wi-Fi, and a web page for the people who will never sit in the room at all. Today that means exporting, reformatting, re-typing, and re-designing — five tools, five copies, five versions that drift apart within a week.

j-Docs is built on a single organising idea: **one project, every surface**. The same source file is simultaneously the live presentation, the downloadable document, the teaching resource, and the online experience. Everything below follows from that idea, and every feature in the app exists to make the four surfaces cheaper to produce than one surface is today.

That is the strategic wedge. Not "PowerPoint but prettier." Not "Google Slides but local." A different unit of value: the *project* rather than the *slide*.

---

## 2. The seven differentiators, in order of defensibility

### 2.1 One source, four surfaces

This is the moat, because it is structural rather than cosmetic. A competitor can copy a button in an afternoon; they cannot copy a data model that was designed around multi-surface output from the first commit. In j-Docs, the project is a JSON document containing slides, elements, notes, themes, comments, ink strokes, and engagement data. Every output — PPTX, standalone HTML, handout, notes pages, summary, teaching kit, lesson plan, quiz, offline ZIP — is a *projection* of that one document, generated on demand and guaranteed to agree with it.

The practical consequence is that the content never forks. Fix a typo in the deck and the handout, the summary, the teaching kit, and the offline package all inherit the fix the next time they are generated. Add a slide and the quiz builder offers a question about it. Change the theme and every surface re-renders in the new palette. In PowerPoint the handout is a print setting; in j-Docs it is a first-class artifact with its own options, and it is always current.

The business consequence is stickier than it looks. Once a team's onboarding deck, its handout, its quiz, and its offline package all come from one file, switching tools means rebuilding four artifacts instead of one. That is a much higher switching cost than a nicer ribbon.

### 2.2 Open anything, own everything

The second differentiator is the universal opener. j-Docs accepts `.pptx`, `.ppsx`, `.potx`, `.pptm`, `.docx`, `.xlsx`, `.odp`, `.odt`, `.fodt`, `.rtf`, `.pdf`, `.csv`, `.tsv`, `.md`, `.txt`, `.json`, `.html`, `.xml`, `.svg`, images, audio, video, fonts, ZIP archives, its own `.jdocs` format, and — crucially — *anything else*, including unknown binary formats, which open in a metadata viewer with type detection, a text preview, and a hex dump rather than an error dialog.

This matters because the average knowledge worker does not live in one ecosystem. They receive a Keynote export from a designer, a DOCX from legal, a CSV from finance, a PDF from a client, and a ZIP of assets from an agency — often in the same afternoon. Every "unsupported format" dialog is a context switch into a different application, and every context switch is a place where the work stalls. A tool that opens everything becomes the default place to look, and the default place to look becomes the default place to work.

The second half of this idea is ownership. j-Docs is local-first: the project lives in the browser's storage and in a `.jdocs` file the user controls. There is no account, no upload, no server-side rendering, no telemetry. The offline package is a ZIP that contains the presentation, the handout, the notes, the summary, the teaching kit, the lesson plan, the quiz, the fonts, the media, the audience responses, a manifest, and the licences — and it runs from a USB stick with no network at all. For schools, hospitals, government, legal, and anyone with a confidentiality obligation, "your content never leaves your machine" is not a feature, it is the procurement decision.

### 2.3 The generated teaching kit

Most presentation software stops at "here are your slides." j-Docs generates the entire teaching apparatus from the deck: a handout in six layouts, printable speaker-notes pages, a slide-by-slide summary, an executive summary for people who will not read the deck, a teaching kit with objectives and discussion prompts, a timed lesson plan, a quiz with answer key, and a readability analysis that flags long sentences and dense slides.

This is where the four-surface thesis becomes concrete value. A trainer who has to deliver a two-hour workshop normally spends as long building the workbook, the quiz, and the lesson plan as building the slides — often longer, because those artifacts are less fun to make. j-Docs collapses that from days to a menu click, and because the artifacts are generated from the same source they cannot contradict the slides. The quiz asks about what is actually on the slide. The lesson plan's timings match the actual slide count. The handout's notes are the real speaker notes, not a stale copy.

No mainstream presentation tool does this. Canva has templates; PowerPoint has Designer; neither has a concept of the deck as a *curriculum*. That gap is the single most under-served need in education and corporate training, and it is a large, budget-holding market.

### 2.4 Live audience engagement without another app

j-Docs ships polls, Q&A, word clouds, and star ratings inside the presenter view, with a join code and QR code, and an anonymised analytics dashboard that exports to CSV. The audience joins from a phone browser — no app install, no account, no plugin. Responses sync across tabs and windows through `BroadcastChannel`, with a `localStorage` fallback, which means the whole thing works on a single machine, on a local network, or embedded in the offline package without a backend.

The strategic point is not "we have polls." Mentimeter, Slido, and Poll Everywhere have polls, and they are good at it. The point is that the polls live *in the same document as the slides*. The presenter does not alt-tab to a second application, does not re-type the question, does not reconcile two sets of results afterwards. The poll is a property of the slide, the results are a property of the project, and the analytics are a projection of the project like every other output. That removes the entire integration tax that makes live engagement feel like extra work, and it means the engagement data can flow into the summary and the teaching kit automatically.

The anonymisation is deliberate and visible. Responses are stored with a type, a question, an answer, and a timestamp — no identity, no device fingerprint, no IP. For classrooms and public-sector audiences that is the difference between "allowed" and "not allowed."

### 2.5 Offline packages that actually work offline

"Offline" in most tools means "the file opens without internet, if the fonts happen to be installed and the video happens to be cached." j-Docs means something stricter: a ZIP containing a self-contained HTML presentation, a standalone handout, the notes, the summary, the teaching kit, the lesson plan, the quiz, the `.jdocs` source, the bundled Selawik font files, every embedded image and media file, the audience responses as CSV, a machine-readable manifest, and a licences file that records what may legally be redistributed.

This is an operational feature with outsized political value. Conference Wi-Fi fails. School networks block external domains. Field offices have no connectivity. Regulated environments forbid cloud upload. A presenter who can hand over a single ZIP that opens on any laptop, in any browser, with the correct typography and all the media, has removed an entire category of failure from their day. And because the package includes the source project, the recipient can edit it later rather than being stuck with a PDF.

### 2.6 Accessibility as a first-class mode, not a compliance checkbox

j-Docs treats accessibility as a rendering mode rather than an afterthought. There is a skip link, full keyboard operation, visible focus rings, ARIA labelling, live regions for status changes, and a `prefers-reduced-motion` path that disables transitions and animations. Beyond the baseline there are user-facing modes: high contrast, large text, and a dyslexia-friendly font, all persisted per user. There is an accessibility inspector that scores the current slide and lists concrete problems — missing alt text, low contrast, text too small, too many words, heading order — plus a WCAG contrast checker with live ratios and pass/fail badges for AA and AAA.

The reason this is a differentiator rather than table stakes is that most tools treat accessibility as a document-level audit you run at the end, if at all. j-Docs treats it as a property of every element, checked continuously, with the same rigour as alignment. For public-sector, education, and enterprise buyers who must demonstrate WCAG conformance, that is a materially easier story to tell in a procurement review — and it is genuinely better for the people who need it.

### 2.7 No lock-in, open formats, single-file export

The project format is documented JSON. The exports are PPTX (real OOXML, validated as a zip with the correct parts), standalone HTML with inlined CSS and base64 assets, PDF via the print pipeline, CSV for data and responses, and a ZIP for offline distribution. There is no proprietary binary, no activation server, no "export requires a subscription" gate.

Lock-in is the incumbents' most reliable retention mechanism, and it is also their most resented one. A tool that makes leaving easy is paradoxically harder to leave, because the decision to adopt it is low-risk. "Try it for one deck; if you hate it, export to PPTX and walk away" is a much easier yes than "migrate your team."

---

## 3. Ideas that go beyond the brief

The user asked for better ideas than the obvious ones. These are the additional bets, roughly in order of expected impact per unit of effort.

**A command palette as the primary interface.** Every action in j-Docs is reachable from `Ctrl+K`, searchable by name, with keyboard hints. This is how power users actually want to work in 2024, and it makes a feature-rich application feel small. It also solves the discoverability problem that plagues ribbon interfaces: the ribbon teaches beginners, the palette accelerates experts, and neither has to be compromised.

**A print studio rather than a print dialog.** Handouts, notes pages, and summaries are laid out with real `@page` rules, page numbering, headers and footers, and a live preview before printing. Most tools hand you the browser's print dialog and hope. A dedicated studio means the printed artifact is designed, not accidental — and print is still how a great deal of training material is distributed.

**Readability scoring as an editing signal.** The app computes sentence length, word complexity, and words-per-slide, and surfaces them as a gentle score rather than a scold. Dense slides are the most common failure mode in presentations, and no mainstream tool measures them. A number that goes down when you cut a paragraph is a surprisingly effective behavioural nudge.

**Generated quizzes with answer keys.** The quiz builder derives questions from slide titles and body text, offers multiple-choice distractors, and prints with an answer key. It is deliberately simple and local — no model call, no hallucination, no data leaving the machine — and it turns a passive deck into an assessable lesson.

**A brand kit and design variants.** Teams can lock a palette, a font pair, and a logo, then generate layout variants that respect the kit. This is the "designer in a box" idea without the template sameness: the constraints are the brand, the variation is the layout.

**Version history and compare.** Snapshots are kept locally with timestamps, and two versions can be compared slide by slide. Undo is for the last thirty seconds; history is for "what did this deck look like before the client review."

**Protect and share.** A share sheet generates a QR code, a link, a standalone web version, and an offline package from one place. Protection is a local passphrase gate rather than DRM — honest about what it can and cannot do, which is more than most tools manage.

**Ink, highlighter, and eraser.** Freehand annotation on the slide canvas, stored as vector polylines in project coordinates so it scales with the slide and survives export. Useful for review, teaching, and markup, and cheap to implement because the canvas is already a coordinate system.

**Presenter view with next-slide preview, timer, clock, and notes.** The presenter sees what the audience sees plus everything they need; the audience sees only the slide. This is standard in the category, but doing it well — with a real next-slide render, a working timer, and engagement results in the sidebar — is not.

**Motion that is previewable.** Transitions and element animations are chosen from a gallery and previewed in place before committing. Most tools make you enter slideshow mode to find out whether the effect is any good.

**A demo deck that is also the pitch.** The app ships with a twenty-slide deck that demonstrates every feature while arguing for the product. It is the empty state, the tutorial, and the sales pitch in one artifact — and it proves the four-surface claim by being exportable to every surface.

---

## 4. Where the incumbents are weak, specifically

**PowerPoint** is enormously capable and enormously heavy. Its strengths are fidelity, enterprise integration, and ubiquity; its weaknesses are that the handout, the notes, the summary, and the web version are all afterthoughts, that collaboration requires Microsoft 365, that the web app is a reduced experience, and that accessibility is an audit rather than a mode. j-Docs does not try to beat PowerPoint at fidelity. It beats it at the moment after the slides are finished.

**Google Slides** wins on collaboration and loses on ownership, offline reliability, and output depth. Its offline mode is fragile, its print output is basic, and its engagement story is "install an add-on." j-Docs wins on local-first privacy, on real offline packages, and on generated artifacts.

**Keynote** is the most beautiful of the three and the least portable. Its exports are lossy and its web story is weak. j-Docs wins on openness and on cross-platform reach.

**Canva** wins on visual polish and loses on structure. It is a design tool that happens to make slides; it has no concept of a curriculum, a handout with speaker notes, or an accessible document. j-Docs wins on substance and on accessibility.

**Mentimeter, Slido, Poll Everywhere** win on live engagement and lose on everything else. They are a second application with a second data silo. j-Docs wins by making engagement a property of the deck.

**AI deck generators** win on speed to first draft and lose on trust, editability, and depth. They produce a deck you then have to fix. j-Docs's AI assistance is deliberately local and conservative — tighten, bulletise, suggest a title, outline a structure — because the value is in the editing loop, not the first draft.

The pattern is consistent: every incumbent is strong on one surface and weak on the other three. j-Docs is the only tool whose architecture assumes there are four.

---

## 5. Who this is for, and why they will pay

The primary segment is **trainers, educators, and enablement teams** — people who must deliver content live, distribute it afterwards, assess it, and run it again next quarter. They feel all four surfaces every single time, and they currently pay with days of reformatting. The teaching kit, the lesson plan, the quiz, and the handout are not nice-to-haves for them; they are the job.

The secondary segment is **consultants and agencies**, who produce decks as deliverables and need a branded, accessible, offline-safe package they can hand to a client without a subscription dependency.

The tertiary segment is **regulated and public-sector organisations**, for whom local-first storage, anonymised analytics, WCAG conformance, and offline operation are procurement requirements rather than preferences.

The pricing logic that follows is not per-seat SaaS. It is a free local app with paid team features — brand kits, shared templates, hosted engagement rooms, and managed offline distribution — because the free app is the distribution mechanism and the paid layer is the part that genuinely needs a server. That is the opposite of the incumbents' model, and it is much easier to defend to a buyer who has been burned by per-seat renewals.

---

## 6. What to build next

The current build is a complete, working static application: the editor, the universal opener, the outputs, the engagement layer, the presenter, the accessibility modes, and the offline package all function and have been verified in a browser. The next twelve months should deepen the moat rather than widen the surface.

**Real-time multi-user editing** over WebRTC or a small relay, with the same local-first fallback. This is the one capability whose absence is felt immediately by teams, and it is the natural paid tier.

**A proper engagement backend** for rooms larger than a single machine, with the same anonymised data model and the same CSV export. Keep the local mode free forever.

**Template and brand-kit marketplace**, curated rather than open, with accessibility and contrast validated at submission. This is a revenue line and a quality signal at once.

**Deeper import fidelity** — SmartArt, charts with real data bindings, embedded video, and theme inheritance from PPTX — so that the "open anything" promise holds for the gnarliest corporate decks.

**A native shell** (Tauri or Electron) for file-system access, OS-level fonts, and true offline install, sharing the same web codebase. This removes the last friction for enterprise deployment.

**Localisation**, starting with right-to-left layout support, because the accessibility thesis is incomplete without it.

**An audit trail** for regulated buyers: who generated which artifact, when, from which version, with a hash of the source project. Cheap to add, decisive in procurement.

---

## 7. The one-sentence version

Every other document app sells you a better way to make a slide; j-Docs sells you a better way to make everything the slide was ever going to become — and it does it locally, accessibly, and without asking permission from a server.

That is the wedge, the moat, and the reason the project exists.
