/* j-Docs editor controller */
(function(){
  const {Store,THEMES,themeById,LAYOUTS,makeLayout,uid,clone,esc,strip,words,textEl,shapeEl,imageEl,tableEl,chartEl,iconEl,mediaEl,codeEl} = window.JD;
  const R = window.JDRender;
  const $ = (s,r=document)=>r.querySelector(s);
  const $$ = (s,r=document)=>[...r.querySelectorAll(s)];
  const icon = window.jIcon;

  const FONTS = ['Segoe UI','Selawik','Calibri','Arial','Georgia','Cambria','Times New Roman','Verdana','Trebuchet MS','Consolas','Courier New','Tahoma','Gill Sans','Century Gothic'];
  const SIZES = [8,9,10,11,12,14,16,18,20,22,24,26,28,32,36,40,44,48,54,60,66,72,80,88,96,108,120];
  const COLORS = ['#c43e1c','#ff8a4c','#e11d48','#db2777','#7c3aed','#4f46e5','#2563eb','#0ea5e9','#0f7b6c','#16a34a','#65a30d','#ca8a04','#f59e0b','#78716c','#111827','#ffffff'];

  const B = (ic,label,action,extra='')=>`<button class="ribbon-big" data-action="${action}" ${extra} title="${label}">${icon(ic,{size:20})}<span>${label}</span></button>`;
  const M = (ic,title,action,extra='',active=false)=>`<button class="ribbon-mini ${active?'active':''}" data-action="${action}" ${extra} title="${title}" aria-label="${title}">${icon(ic,{size:15})}</button>`;
  const G = (label,inner)=>`<div class="ribbon-group"><div class="ribbon-row">${inner}</div><div class="ribbon-group-label">${label}</div></div>`;
  const div = '<span class="ribbon-divider"></span>';

  function fontOptions(){
    return `<select class="ribbon-select" data-action="font-family" aria-label="Font family" style="width:112px">${FONTS.map(f=>`<option value="${f}">${f}</option>`).join('')}</select>`;
  }
  function sizeOptions(){
    return `<select class="ribbon-select" data-action="font-size" aria-label="Font size" style="width:54px">${SIZES.map(s=>`<option value="${s}">${s}</option>`).join('')}</select>`;
  }
  function themeStrip(){
    return `<div class="theme-strip">${THEMES.slice(0,7).map(t=>`<button class="theme-card ${Store.project.theme===t.id?'active':''}" data-action="theme" data-value="${t.id}" title="${t.name}" aria-label="Theme ${t.name}"><span class="tc-preview" style="background:${t.bg};color:${t.fg}"><i class="tc-bar" style="background:${t.accent}"></i><i class="tc-title"></i><i class="tc-sub"></i></span><span class="tc-name">${t.name}</span></button>`).join('')}</div>`;
  }

  const RIBBON = {
    home: ()=>[
      G('Clipboard', M('paste','Paste (Ctrl+V)','paste')+M('cut','Cut (Ctrl+X)','cut')+M('copy','Copy (Ctrl+C)','copy')+M('duplicate','Duplicate (Ctrl+D)','duplicate')),
      G('Slides', B('plus','New slide','add-slide')+B('layout','Layout','layout-gallery')+B('reset','Reset','reset-slide')+B('section','Section','add-section')),
      G('Font', fontOptions()+sizeOptions()+M('fontIncrease','Increase font size','font-grow')+M('fontDecrease','Decrease font size','font-shrink')+div+M('bold','Bold (Ctrl+B)','bold')+M('italic','Italic (Ctrl+I)','italic')+M('underline','Underline (Ctrl+U)','underline')+M('strike','Strikethrough','strike')+div+M('color','Font color','font-color')+M('highlight','Highlight','highlight')+M('clearFormat','Clear formatting','clear-format')),
      G('Paragraph', M('bullet','Bullets','bullets')+M('number','Numbering','numbering')+div+M('alignLeft','Align left','align-left')+M('alignCenter','Align center','align-center')+M('alignRight','Align right','align-right')+M('alignJustify','Justify','align-justify')+div+M('lineSpacing','Line spacing','line-spacing')+M('textDirection','Text direction','text-direction')),
      G('Drawing', M('fill','Shape fill','shape-fill')+M('outline','Shape outline','shape-outline')+M('effects','Shape effects','shape-effects')+M('eyedropper','Eyedropper','eyedropper')),
      G('Editing', M('find','Find (Ctrl+F)','find')+M('replace','Replace','replace')+M('selectAll','Select all (Ctrl+A)','select-all')+M('sparkle','Ask j-Docs','ai-assist'))
    ].join(''),
    insert: ()=>[
      G('Slides', B('plus','New slide','add-slide')+B('duplicate','Duplicate','duplicate-slide')),
      G('Text', B('textPlus','Text box','insert-text')+B('header','Header & footer','header-footer')+B('date','Date','insert-date')+B('slideNumber','Slide number','insert-slide-number')+B('symbol','Symbol','insert-symbol')+B('equation','Equation','insert-equation')),
      G('Illustrations', B('shapePlus','Shapes','shape-gallery')+B('icon','Icons','icon-gallery')+B('imagePlus','Picture','insert-image')+B('tablePlus','Table','insert-table')+B('chartPlus','Chart','insert-chart')+B('smartart','SmartArt','insert-smartart')+B('videoPlus','Media','insert-media')+B('code','Code','insert-code')+B('embed','Embed','insert-embed')),
      G('Links', B('link','Link','insert-link')+B('commentPlus','Comment','insert-comment')+B('mail','Action','insert-action')),
      G('Extras', B('sparkle','AI outline','ai-outline')+B('wand','Designer','designer')+B('qr','Audience poll','engage'))
    ].join(''),
    draw: ()=>[
      G('Tools', B('pen','Pen','draw-pen')+B('highlighter','Highlighter','draw-highlighter')+B('eraser','Eraser','draw-eraser')+B('lasso','Lasso','draw-lasso')+B('clear','Clear ink','draw-clear')),
      G('Ink', `<span class="ribbon-color" data-action="ink-color" title="Ink color"><span class="swatch" style="background:#c43e1c"></span><span class="bar" style="background:#c43e1c"></span></span>`+`<select class="ribbon-select" data-action="ink-width" aria-label="Ink width" style="width:60px"><option value="2">2 pt</option><option value="4" selected>4 pt</option><option value="8">8 pt</option><option value="14">14 pt</option></select>`+M('convert','Convert ink to shapes','ink-convert')),
      G('Gestures', B('touch','Touch drawing','draw-pen')+B('gesture','Gesture mode','draw-gesture')+B('rotate2','Rotate canvas','rotate-canvas'))
    ].join(''),
    design: ()=>[
      G('Themes', themeStrip()),
      G('Variants', B('variant','Variants','variants')+B('palette','Color palette','palette')+B('font','Font pair','font-pair')+B('effects','Effects','theme-effects')),
      G('Slide', B('background','Background','background')+B('aspect','Slide size','slide-size')+B('designer','Designer','designer')+B('art','Brand kit','brand-kit')),
      G('Layout', B('layout','Layouts','layout-gallery')+B('guides','Guides','toggle-guides')+B('grid','Grid','toggle-grid')+B('reset','Reset theme','reset-theme'))
    ].join(''),
    transitions: ()=>[
      G('Transition', B('transition','None','transition-none')+B('sparkle','Fade','transition-fade')+B('arrowRight','Push','transition-push')+B('arrowLeft','Wipe','transition-wipe')+B('square','Split','transition-split')+B('layers','Reveal','transition-reveal')+B('infinity','Morph','transition-morph')+B('zoomIn','Zoom','transition-zoom')),
      G('Timing', `<select class="ribbon-select" data-action="transition-duration" aria-label="Transition duration" style="width:76px"><option value=".3">0.3 s</option><option value=".5" selected>0.5 s</option><option value=".8">0.8 s</option><option value="1.2">1.2 s</option></select>`+M('click','On click','transition-click')+M('after','After','transition-after')+M('clock','Rehearse timings','rehearse')),
      G('Apply', B('check','Apply to all','transition-all')+B('play','Preview','preview-transition')+B('sound','Sound','transition-sound'))
    ].join(''),
    animations: ()=>[
      G('Animation', B('entrance','Appear','anim-appear')+B('sparkle','Fade','anim-fade')+B('arrowRight','Fly in','anim-fly')+B('zoomIn','Zoom','anim-zoom')+B('rotate','Spin','anim-spin')+B('target','Pulse','anim-pulse')+B('layers','Wipe','anim-wipe')),
      G('Timing', `<select class="ribbon-select" data-action="anim-duration" aria-label="Animation duration" style="width:76px"><option value=".3">0.3 s</option><option value=".5" selected>0.5 s</option><option value=".8">0.8 s</option><option value="1.2">1.2 s</option></select>`+`<select class="ribbon-select" data-action="anim-delay" aria-label="Animation delay" style="width:66px"><option value="0">0 s</option><option value=".2">0.2 s</option><option value=".5">0.5 s</option><option value="1">1 s</option></select>`+M('click','On click','anim-click')+M('after','With previous','anim-with')+M('clock','After previous','anim-after')),
      G('Advanced', B('motionPath','Animation pane','animation-pane')+B('play','Preview','preview-animation')+B('wand','Animation painter','animation-painter'))
    ].join(''),
    slideshow: ()=>[
      G('Start', B('play','From beginning','present')+B('present','From current','present-current')+B('presenter','Presenter view','presenter')+B('rehearse','Rehearse','rehearse')),
      G('Audience', B('qr','Engage audience','engage')+B('broadcast','Broadcast','broadcast')+B('users','Audience view','audience-preview')+B('chartBar','Analytics','analytics')),
      G('Offline', B('package','Offline package','offline-package')+B('download','Export PPTX','export-pptx')+B('html','Export web','export-html')+B('print','Print studio','print-studio')),
      G('Display', B('subtitles','Subtitles','subtitles')+B('fullscreen','Full screen','present')+B('monitor','Display settings','display-settings'))
    ].join(''),
    review: ()=>[
      G('Proofing', B('spellcheck','Spelling','spellcheck')+B('book','Thesaurus','thesaurus')+B('language','Language','language')+B('translate','Translate','translate')),
      G('Comments', B('comment','New comment','insert-comment')+B('commentPlus','Comments pane','comments-pane')+B('checkCircle','Resolve','resolve-comments')),
      G('Accessibility', B('accessibility','Check accessibility','accessibility-check')+B('alt','Alt text','alt-text')+B('readingOrder','Reading order','reading-order')+B('contrast','Contrast','contrast-check')),
      G('Protect', B('shield','Protect','protect')+B('history','Version history','version-history')+B('compare','Compare','compare'))
    ].join(''),
    view: ()=>[
      G('Views', B('view','Normal','view-normal')+B('outline','Outline','view-outline')+B('sorter','Slide sorter','view-sorter')+B('notes','Notes page','view-notes')+B('reading','Reading view','view-reading')+B('graduation','Teach view','view-teach')),
      G('Show', B('grid','Gridlines','toggle-grid')+B('guides','Guides','toggle-guides')+B('ruler','Ruler','toggle-ruler')+B('sidebar','Slide rail','toggle-rail')+B('panel','Inspector','toggle-inspector')),
      G('Zoom', B('zoomIn','Zoom in','zoom-in')+B('zoomOut','Zoom out','zoom-out')+B('fit','Fit to window','zoom-fit')+B('expand','Focus mode','focus-mode')),
      G('Theme', B('dark','Dark mode','toggle-theme')+B('contrast','High contrast','toggle-contrast')+B('accessibility','Large text','toggle-large-text')+B('book','Dyslexia font','toggle-dyslexia')+B('offline','Reduce motion','toggle-motion'))
    ].join(''),
    outputs: ()=>[
      G('Print studio', B('handout','Handouts','handouts')+B('notes','Notes pages','notes-pages')+B('summary','Slide summaries','summaries')+B('print','Print / PDF','print-studio')),
      G('Surfaces', B('reading','Document mode','view-reading')+B('graduation','Teaching kit','teaching-kit')+B('html','Web experience','export-html')+B('present','Live presentation','present')),
      G('Packages', B('package','Offline package','offline-package')+B('download','Export PPTX','export-pptx')+B('json','Save .jdocs','save-as')+B('zip','Export all','export-all')),
      G('Audience', B('qr','Start session','engage')+B('chartBar','Analytics','analytics')+B('users','Audience view','audience-preview')+B('download','Export responses','export-responses')),
      G('Intelligence', B('sparkle','Executive summary','exec-summary')+B('book','Lesson plan','lesson-plan')+B('question','Quiz builder','quiz-builder')+B('target','Readability','readability'))
    ].join(''),
    help: ()=>[
      G('Discover', B('command','Command palette','command')+B('keyboard','Keyboard shortcuts','shortcuts')+B('sparkle','Why j-Docs','why-jdocs')+B('book','Documentation','docs')),
      G('Accessibility', B('accessibility','Accessibility settings','a11y-settings')+B('contrast','High contrast','toggle-contrast')+B('motionPath','Reduce motion','toggle-motion')+B('book','Dyslexia font','toggle-dyslexia')),
      G('Project', B('history','Reset demo','reset-demo')+B('new','New project','new')+B('open','Open any file','open')+B('save','Save','save')),
      G('About', B('info','About j-Docs','about')+B('shield','Privacy','privacy')+B('crown','Licenses','licenses'))
    ].join('')
  };

  const TABS = [
    ['home','Home'],['insert','Insert'],['draw','Draw'],['design','Design'],['transitions','Transitions'],
    ['animations','Animations'],['slideshow','Slide Show'],['review','Review'],['view','View'],['outputs','Outputs',true],['help','Help']
  ];

  const Editor = {
    tab:'home', zoomFactor:1, editingId:null, _fitW:900, _fitH:506,
    init(){
      this.renderTabs();
      this.renderRibbon();
      this.bind();
      this.refresh();
      this.fit();
      this.updateStatus();
      window.addEventListener('resize',()=>this.fit());
      if(window.ResizeObserver){
        const ro=new ResizeObserver(()=>this.fit());
        ro.observe($('#stageScroll'));
      }
    },
    renderTabs(){
      const el=$('#ribbonTabs');
      el.innerHTML=TABS.map(([id,label,spark])=>`<button class="ribbon-tab" role="tab" data-tab="${id}" aria-selected="${this.tab===id}" aria-controls="ribbonBody">${label}${spark?'<span class="tab-spark" title="New"></span>':''}</button>`).join('');
    },
    renderRibbon(){
      const body=$('#ribbonBody');
      body.innerHTML=(RIBBON[this.tab]||RIBBON.home)();
      body.setAttribute('aria-label',this.tab+' ribbon');
      this.syncRibbon();
    },
    setTab(tab){
      if(!RIBBON[tab]) tab='home';
      this.tab=tab; this.renderTabs(); this.renderRibbon();
      if(window.innerWidth<=720) $('#ribbon').classList.remove('collapsed');
    },
    bind(){
      document.addEventListener('click',e=>{
        const tab=e.target.closest('.ribbon-tab');
        if(tab){ this.setTab(tab.dataset.tab); return; }
        const act=e.target.closest('[data-action]');
        if(act){ this.handleAction(act.dataset.action,act.dataset.value,act,e); }
      });
      $('#ribbonCollapse').addEventListener('click',()=>{ $('#ribbon').classList.toggle('collapsed'); if(window.JDApp) window.JDApp._userRibbon=true; });
      $('#docTitle').addEventListener('input',e=>{ Store.project.name=e.target.value||'Untitled'; Store.markDirty(); });
      $('#docTitle').addEventListener('blur',()=>{ if(!Store.project.name.trim()){Store.project.name='Untitled presentation';$('#docTitle').value=Store.project.name;} });
      $('#notesInput').addEventListener('input',window.JD.debounce(e=>{ Store.setNotes(e.target.value); this.updateStatus(); },300));
      $('#notesInput').addEventListener('blur',()=>{ Store.commit('notes'); });
      $('#inspectorTabs').addEventListener('click',e=>{
        const b=e.target.closest('.insp-tab'); if(!b)return;
        Store.inspectorTab=b.dataset.insp; $$('.insp-tab').forEach(x=>{x.classList.toggle('active',x===b);x.setAttribute('aria-selected',x===b)}); this.renderInspector();
      });
      $('#inspectorBody').addEventListener('input',e=>this.inspectorInput(e));
      $('#inspectorBody').addEventListener('change',e=>this.inspectorInput(e));
      $('#inspectorBody').addEventListener('click',e=>{
        const b=e.target.closest('[data-insp-action]'); if(!b)return;
        this.inspectorAction(b.dataset.inspAction,b.dataset.value,b);
      });
      // Canvas
      const canvas=$('#slideCanvas');
      canvas.addEventListener('pointerdown',e=>this.canvasPointerDown(e));
      canvas.addEventListener('dblclick',e=>this.canvasDoubleClick(e));
      canvas.addEventListener('click',e=>this.canvasClick(e));
      canvas.addEventListener('input',e=>{
        if(!this.editingId)return;
        const el=Store.elements().find(x=>x.id===this.editingId); if(!el)return;
        const txt=e.target.closest('.txt'); if(!txt)return;
        el.content=txt.innerHTML; Store.markDirty(); this.updateStatus();
      });
      canvas.addEventListener('blur',e=>{ if(this.editingId && e.target.closest('.txt')) this.stopEditing(); },true);
      // Rail
      $('#railList').addEventListener('click',e=>{
        const t=e.target.closest('.slide-thumb'); if(!t)return;
        Store.current=Number(t.dataset.index); Store.selected=[]; this.refresh();
      });
      $('#railList').addEventListener('dragstart',e=>{
        const t=e.target.closest('.slide-thumb'); if(!t)return;
        e.dataTransfer.setData('text/jdocs-slide',t.dataset.index); e.dataTransfer.effectAllowed='move'; t.classList.add('dragging');
      });
      $('#railList').addEventListener('dragend',e=>{ $$('.slide-thumb').forEach(x=>x.classList.remove('dragging','drop-before','drop-after')); });
      $('#railList').addEventListener('dragover',e=>{
        const t=e.target.closest('.slide-thumb'); if(!t)return; e.preventDefault();
        const r=t.getBoundingClientRect(); const after=e.clientY>r.top+r.height/2;
        $$('.slide-thumb').forEach(x=>x.classList.remove('drop-before','drop-after'));
        t.classList.add(after?'drop-after':'drop-before');
      });
      $('#railList').addEventListener('drop',e=>{
        const t=e.target.closest('.slide-thumb'); if(!t)return; e.preventDefault();
        const from=Number(e.dataTransfer.getData('text/jdocs-slide')); const r=t.getBoundingClientRect(); const after=e.clientY>r.top+r.height/2;
        let to=Number(t.dataset.index)+(after?1:0); if(from<to)to--;
        Store.moveSlide(from,to); this.refresh();
      });
      // Stage zoom
      $('#stageScroll').addEventListener('wheel',e=>{
        if(e.ctrlKey||e.metaKey){ e.preventDefault(); this.setZoom(this.zoomFactor*(e.deltaY>0?.9:1.1)); }
      },{passive:false});
      // Keyboard
      document.addEventListener('keydown',e=>this.keydown(e));
      // File inputs
      $('#imageInput').addEventListener('change',async e=>{
        const f=e.target.files[0]; if(!f)return; await this.insertImageFile(f); e.target.value='';
      });
      $('#mediaInput').addEventListener('change',async e=>{
        const f=e.target.files[0]; if(!f)return; await this.insertMediaFile(f); e.target.value='';
      });
      $('#fileInput').addEventListener('change',e=>{
        const files=[...e.target.files]; if(files.length) window.JDIO?.openFiles(files); e.target.value='';
      });
      $('#searchBtn').addEventListener('click',()=>window.JDApp?.openCommand());
      $('#brandBtn').addEventListener('click',()=>window.JDApp?.openBrandMenu());
    },

    refresh(opts={}){
      $('#docTitle').value=Store.project.name;
      this.renderRail();
      this.renderCanvas();
      this.renderSelection();
      this.renderInspector();
      this.renderNotes();
      this.updateStatus();
      this.syncRibbon();
      if(opts.scrollRail!==false) this.scrollActiveThumb();
    },
    renderRail(){
      const rail=$('#railList'); const theme=Store.theme();
      rail.innerHTML='';
      const frag=document.createDocumentFragment();
      Store.project.slides.forEach((s,i)=>{
        const b=document.createElement('button');
        b.className='slide-thumb'+(i===Store.current?' active':'');
        b.dataset.index=i; b.setAttribute('role','option'); b.setAttribute('aria-selected',i===Store.current);
        b.setAttribute('aria-label','Slide '+(i+1)+': '+(Store.outline()[i]?.title||'Untitled'));
        b.draggable=true;
        const frame=document.createElement('span'); frame.className='thumb-frame';
        const cv=document.createElement('div'); cv.className='slide-canvas'; cv.style.cssText='width:100%;height:100%;position:relative;overflow:hidden;container-type:size';
        R.renderThumb(cv,s,theme);
        frame.appendChild(cv);
        const num=document.createElement('span'); num.className='num'; num.textContent=i+1;
        b.appendChild(num); b.appendChild(frame);
        if(s.hidden){ const hb=document.createElement('span'); hb.className='thumb-badge'; hb.textContent='Hidden'; frame.appendChild(hb); }
        frag.appendChild(b);
      });
      rail.appendChild(frag);
    },
    scrollActiveThumb(){
      const a=$('.slide-thumb.active'); if(a) a.scrollIntoView({block:'nearest',behavior:'smooth'});
    },
    renderCanvas(){
      const s=Store.slide(); if(!s)return;
      const cv=$('#slideCanvas'); const theme=Store.theme();
      R.renderSlide(cv,s,theme,{selected:false});
      cv.classList.toggle('editing-text',!!this.editingId);
      this.applyCanvasSize();
      $('#slidePosition').textContent='Slide '+(Store.current+1)+' of '+Store.project.slides.length;
      $('#statusView').textContent=Store.view.charAt(0).toUpperCase()+Store.view.slice(1);
      $('#viewChip').textContent=Store.view.charAt(0).toUpperCase()+Store.view.slice(1);
    },
    applyCanvasSize(){
      const shell=$('#slideShell'); const scroll=$('#stageScroll');
      const notes=$('#notesDrawer'); const notesH=notes&&!notes.hidden?notes.offsetHeight+12:0;
      const padW=window.innerWidth<=720?12:48, padH=window.innerWidth<=720?20:60;
      const availW=Math.max(220,scroll.clientWidth-padW);
      const availH=Math.max(160,scroll.clientHeight-padH-notesH);
      const ratio=16/9;
      let w=Math.min(availW,availH*ratio);
      w=Math.max(240,w)*this.zoomFactor;
      const h=w/ratio;
      this._fitW=w; this._fitH=h;
      shell.style.width=w+'px'; shell.style.height=h+'px';
      $('#zoomLabel').textContent=Math.round(this.zoomFactor*100)+'%';
    },
    fit(){ this.applyCanvasSize(); this.renderSelection(); },
    setZoom(f){ this.zoomFactor=Math.max(.35,Math.min(2.5,f)); this.applyCanvasSize(); this.renderSelection(); },
    renderSelection(){
      const layer=$('#selectionLayer'); layer.innerHTML='';
      const sel=Store.selectedElements(); if(!sel.length)return;
      const theme=Store.theme();
      if(sel.length===1){
        const e=sel[0];
        const box=document.createElement('div'); box.className='sel-box';
        box.style.cssText=`left:${e.x}%;top:${e.y}%;width:${e.w}%;height:${e.h}%;transform:rotate(${e.rotation||0}deg)`;
        layer.appendChild(box);
        ['nw','n','ne','e','se','s','sw','w'].forEach(dir=>{
          const h=document.createElement('div'); h.className='sel-handle '+dir; h.dataset.dir=dir;
          const pos={nw:['-4.5px','-4.5px'],n:['calc(50% - 4.5px)','-4.5px'],ne:['calc(100% - 4.5px)','-4.5px'],e:['calc(100% - 4.5px)','calc(50% - 4.5px)'],se:['calc(100% - 4.5px)','calc(100% - 4.5px)'],s:['calc(50% - 4.5px)','calc(100% - 4.5px)'],sw:['-4.5px','calc(100% - 4.5px)'],w:['-4.5px','calc(50% - 4.5px)']}[dir];
          h.style.left=pos[0]; h.style.top=pos[1]; h.style.transform=`rotate(${-(e.rotation||0)}deg)`;
          h.addEventListener('pointerdown',ev=>this.startResize(ev,e,dir));
          box.appendChild(h);
        });
        const rot=document.createElement('div'); rot.className='sel-rotate'; rot.style.left='calc(50% - 5.5px)'; rot.style.top='-24px'; rot.title='Rotate';
        rot.addEventListener('pointerdown',ev=>this.startRotate(ev,e)); box.appendChild(rot);
        const size=document.createElement('div'); size.className='sel-size'; size.textContent=Math.round(e.w)+' × '+Math.round(e.h);
        size.style.left='0'; size.style.top='calc(100% + 6px)'; box.appendChild(size);
      } else {
        const minX=Math.min(...sel.map(e=>e.x)),minY=Math.min(...sel.map(e=>e.y));
        const maxX=Math.max(...sel.map(e=>e.x+e.w)),maxY=Math.max(...sel.map(e=>e.y+e.h));
        const box=document.createElement('div'); box.className='sel-box'; box.style.cssText=`left:${minX}%;top:${minY}%;width:${maxX-minX}%;height:${maxY-minY}%`;
        layer.appendChild(box);
        const size=document.createElement('div'); size.className='sel-size'; size.textContent=sel.length+' objects'; size.style.left='0'; size.style.top='calc(100% + 6px)'; box.appendChild(size);
      }
    },
    canvasClick(e){
      if(this._dragged){ this._dragged=false; return; }
      if(this.editingId) return;
      const el=e.target.closest('.el');
      if(!el){ Store.selected=[]; this.renderSelection(); this.renderInspector(); this.syncRibbon(); return; }
      Store.select(el.dataset.id,e.shiftKey||e.metaKey||e.ctrlKey);
      this.renderSelection(); this.renderInspector(); this.syncRibbon();
    },
    canvasDoubleClick(e){
      const el=e.target.closest('.el'); if(!el)return;
      const data=Store.elements().find(x=>x.id===el.dataset.id); if(!data||data.type!=='text')return;
      this.startEditing(data.id);
    },
    startEditing(id){
      this.editingId=id; Store.select(id); this.renderCanvas(); this.renderSelection();
      const node=$('#slideCanvas .el[data-id="'+id+'"] .txt'); if(node){ node.contentEditable='true'; node.focus(); const r=document.createRange(); r.selectNodeContents(node); r.collapse(false); const s=getSelection(); s.removeAllRanges(); s.addRange(r); }
      $('#slideCanvas').classList.add('editing-text');
    },
    stopEditing(){
      if(!this.editingId)return;
      const id=this.editingId; this.editingId=null;
      const node=$('#slideCanvas .el[data-id="'+id+'"] .txt');
      if(node){ const el=Store.elements().find(x=>x.id===id); if(el){ el.content=node.innerHTML; } }
      Store.commit('edit text'); this.renderCanvas(); this.renderSelection(); this.renderInspector(); this.updateStatus();
    },
    syncGeometry(){
      Store.selectedElements().forEach(el=>{const node=$('#slideCanvas .el[data-id="'+el.id+'"]');if(!node)return;node.style.left=el.x+'%';node.style.top=el.y+'%';node.style.width=el.w+'%';node.style.height=el.h+'%';node.style.transform='rotate('+(el.rotation||0)+'deg)';});
      const sel=Store.selectedElements(),box=$('#selectionLayer .sel-box');if(!box||!sel.length)return;
      if(sel.length===1){const e=sel[0];box.style.left=e.x+'%';box.style.top=e.y+'%';box.style.width=e.w+'%';box.style.height=e.h+'%';box.style.transform='rotate('+(e.rotation||0)+'deg)';}
      else{const minX=Math.min(...sel.map(e=>e.x)),minY=Math.min(...sel.map(e=>e.y)),maxX=Math.max(...sel.map(e=>e.x+e.w)),maxY=Math.max(...sel.map(e=>e.y+e.h));box.style.left=minX+'%';box.style.top=minY+'%';box.style.width=(maxX-minX)+'%';box.style.height=(maxY-minY)+'%';}
      if(sel.length===1)box.querySelectorAll('.sel-handle').forEach(h=>{h.style.transform='rotate('+(-(sel[0].rotation||0))+'deg)';});
      const size=$('#selectionLayer .sel-size');if(size)size.textContent=sel.length===1?Math.round(sel[0].w)+' × '+Math.round(sel[0].h):sel.length+' objects';
    },
    queueGeometry(){if(this._geometryFrame)return;this._geometryFrame=requestAnimationFrame(()=>{this._geometryFrame=0;this.syncGeometry();});},
    flushGeometry(){if(this._geometryFrame){cancelAnimationFrame(this._geometryFrame);this._geometryFrame=0;}this.syncGeometry();},
    canvasPointerDown(e){
      if(e.target.closest('.sel-handle')||e.target.closest('.sel-rotate'))return;
      const elNode=e.target.closest('.el');if(!elNode||this.editingId)return;
      const el=Store.elements().find(x=>x.id===elNode.dataset.id);if(!el||el.locked)return;
      if(!Store.selected.includes(el.id)){Store.select(el.id,e.shiftKey||e.metaKey||e.ctrlKey);this.renderSelection();this.renderInspector();}
      const selected=Store.selectedElements();if(!selected.length)return;
      e.preventDefault();try{elNode.setPointerCapture(e.pointerId);}catch(err){}
      const start={x:e.clientX,y:e.clientY,els:selected.map(x=>({id:x.id,x:x.x,y:x.y}))};
      Store.commit('move');let moved=false,active=true;
      const move=ev=>{if(!active)return;const dx=(ev.clientX-start.x)/this._fitW*100,dy=(ev.clientY-start.y)/this._fitH*100;if(Math.abs(dx)+Math.abs(dy)>.015)moved=true;
        start.els.forEach(o=>{const item=Store.elements().find(x=>x.id===o.id);if(!item)return;let nx=o.x+dx,ny=o.y+dy;if(Store.project.settings.snap){nx=Math.round(nx*2)/2;ny=Math.round(ny*2)/2;}item.x=Math.max(-20,Math.min(110,nx));item.y=Math.max(-20,Math.min(110,ny));});
        this.queueGeometry();this.showGuides(start.els);
      };
      const up=()=>{if(!active)return;active=false;document.removeEventListener('pointermove',move);document.removeEventListener('pointerup',up);document.removeEventListener('pointercancel',up);this.flushGeometry();$('#guidesLayer').innerHTML='';if(moved){this._dragged=true;Store.markDirty();this.renderInspector();}};
      document.addEventListener('pointermove',move,{passive:true});document.addEventListener('pointerup',up,{once:true});document.addEventListener('pointercancel',up,{once:true});
    },
    showGuides(els){
      const layer=$('#guidesLayer'); layer.innerHTML='';
      const e=Store.selectedElement(); if(!e)return;
      const cx=e.x+e.w/2, cy=e.y+e.h/2;
      if(Math.abs(cx-50)<.8){ const g=document.createElement('div'); g.className='guide v'; g.style.left='50%'; layer.appendChild(g); }
      if(Math.abs(cy-50)<.8){ const g=document.createElement('div'); g.className='guide h'; g.style.top='50%'; layer.appendChild(g); }
      if(Math.abs(e.x-7)<.8){ const g=document.createElement('div'); g.className='guide v'; g.style.left='7%'; layer.appendChild(g); }
      if(Math.abs(e.y-7)<.8){ const g=document.createElement('div'); g.className='guide h'; g.style.top='7%'; layer.appendChild(g); }
    },
    startResize(ev,e,dir){
      ev.preventDefault();ev.stopPropagation();try{ev.currentTarget.setPointerCapture(ev.pointerId);}catch(err){}
      Store.commit('resize');const start={x:ev.clientX,y:ev.clientY,x0:e.x,y0:e.y,w0:e.w,h0:e.h,ratio:e.w/e.h};let active=true;
      const move=ev2=>{if(!active)return;const dx=(ev2.clientX-start.x)/this._fitW*100,dy=(ev2.clientY-start.y)/this._fitH*100;let {x0,y0,w0,h0}=start,x=x0,y=y0,w=w0,h=h0;
        if(dir.includes('e'))w=w0+dx;if(dir.includes('s'))h=h0+dy;if(dir.includes('w')){w=w0-dx;x=x0+dx;}if(dir.includes('n')){h=h0-dy;y=y0+dy;}
        if(ev2.shiftKey&&dir.length===2){if(Math.abs(dx)>Math.abs(dy))h=w/start.ratio;else w=h*start.ratio;if(dir.includes('w'))x=x0+w0-w;if(dir.includes('n'))y=y0+h0-h;}
        e.x=Math.max(-10,x);e.y=Math.max(-10,y);e.w=Math.max(1,w);e.h=Math.max(1,h);this.queueGeometry();
      };
      const up=()=>{if(!active)return;active=false;document.removeEventListener('pointermove',move);document.removeEventListener('pointerup',up);document.removeEventListener('pointercancel',up);this.flushGeometry();Store.markDirty();this.renderInspector();};
      document.addEventListener('pointermove',move,{passive:true});document.addEventListener('pointerup',up,{once:true});document.addEventListener('pointercancel',up,{once:true});
    },
    startRotate(ev,e){
      ev.preventDefault();ev.stopPropagation();try{ev.currentTarget.setPointerCapture(ev.pointerId);}catch(err){}Store.commit('rotate');
      const box=$('#slideShell').getBoundingClientRect(),cx=box.left+(e.x+e.w/2)/100*box.width,cy=box.top+(e.y+e.h/2)/100*box.height;let active=true;
      const move=ev2=>{if(!active)return;e.rotation=Math.round(Math.atan2(ev2.clientY-cy,ev2.clientX-cx)*180/Math.PI+90);this.queueGeometry();};
      const up=()=>{if(!active)return;active=false;document.removeEventListener('pointermove',move);document.removeEventListener('pointerup',up);document.removeEventListener('pointercancel',up);this.flushGeometry();Store.markDirty();this.renderInspector();};
      document.addEventListener('pointermove',move,{passive:true});document.addEventListener('pointerup',up,{once:true});document.addEventListener('pointercancel',up,{once:true});
    },
    renderNotes(){
      const n=$('#notesInput'); if(n && document.activeElement!==n) n.value=Store.slide()?.notes||'';
      const d=$('#notesDrawer'); if(d) d.hidden=!Store.project.settings.showNotes;
    },
    renderInspector(){
      const body=$('#inspectorBody'); const tab=Store.inspectorTab; const e=Store.selectedElement(); const s=Store.slide();
      if(tab==='notes'){ body.innerHTML=this.inspectorNotes(); return; }
      if(tab==='motion'){ body.innerHTML=this.inspectorMotion(); return; }
      if(tab==='a11y'){ body.innerHTML=this.inspectorA11y(); return; }
      body.innerHTML=e?this.inspectorElement(e):this.inspectorSlide(s);
    },
    inspectorSlide(s){
      const t=Store.theme(); const st=Store.stats();
      return `
      <div class="insp-section"><div class="insp-title">Slide ${Store.current+1} of ${Store.project.slides.length}</div>
        <div class="insp-row"><label>Layout</label><select class="insp-field" data-insp-action="layout">${LAYOUTS.map(l=>`<option value="${l.id}" ${s.layout===l.id?'selected':''}>${l.name}</option>`).join('')}</select></div>
        <div class="insp-row"><label>Background</label><input class="insp-field" type="text" value="${esc(s.background||t.bg)}" data-insp-action="background-text" placeholder="#fff or gradient"></div>
        <div class="swatches" style="margin-bottom:8px">${['#fffaf7','#ffffff','#f3f2f1','#12100f','#0b1b2b','#17122b','#0f1f1a','#f6efe4'].map(c=>`<button class="swatch-btn" data-insp-action="background" data-value="${c}" style="background:${c}" title="${c}"></button>`).join('')}</div>
        <label class="check-row"><input type="checkbox" data-insp-action="hidden" ${s.hidden?'checked':''}> Hide slide</label>
      </div>
      <div class="insp-section"><div class="insp-title">Theme</div>
        <div class="swatches">${THEMES.map(th=>`<button class="swatch-btn ${Store.project.theme===th.id?'active':''}" data-insp-action="theme" data-value="${th.id}" style="background:${th.accent}" title="${th.name}"></button>`).join('')}</div>
        <div class="insp-note" style="margin-top:8px">${esc(t.name)} · ${t.dark?'Dark':'Light'} theme. Theme changes recolor every slide.</div>
      </div>
      <div class="insp-section"><div class="insp-title">Project</div>
        <div class="insp-grid2"><div class="insp-note"><strong>${st.slides}</strong><br>slides</div><div class="insp-note"><strong>${st.words}</strong><br>words</div><div class="insp-note"><strong>${st.reading} min</strong><br>read time</div><div class="insp-note"><strong>${st.images}</strong><br>images</div></div>
      </div>
      <div class="insp-section"><div class="insp-title">Quick outputs</div>
        <div class="insp-grid2"><button class="insp-btn" data-insp-action="handouts">${icon('handout',{size:13})} Handout</button><button class="insp-btn" data-insp-action="summaries">${icon('summary',{size:13})} Summary</button><button class="insp-btn" data-insp-action="notes-pages">${icon('notes',{size:13})} Notes</button><button class="insp-btn" data-insp-action="offline-package">${icon('package',{size:13})} Offline</button></div>
      </div>`;
    },
    inspectorElement(e){
      const t=Store.theme(); const st=e.style||{};
      let html=`<div class="insp-section"><div class="insp-title">${e.type} · ${e.id.split('_')[0]}</div>
        <div class="insp-grid2"><div class="insp-row"><label>X</label><input class="insp-field" type="number" step=".5" value="${Math.round(e.x*10)/10}" data-insp-field="x"></div><div class="insp-row"><label>Y</label><input class="insp-field" type="number" step=".5" value="${Math.round(e.y*10)/10}" data-insp-field="y"></div><div class="insp-row"><label>W</label><input class="insp-field" type="number" step=".5" value="${Math.round(e.w*10)/10}" data-insp-field="w"></div><div class="insp-row"><label>H</label><input class="insp-field" type="number" step=".5" value="${Math.round(e.h*10)/10}" data-insp-field="h"></div></div>
        <div class="insp-row"><label>Rotate</label><input class="insp-field" type="range" min="-180" max="180" value="${e.rotation||0}" data-insp-field="rotation"><span class="muted" style="font-size:10px">${e.rotation||0}°</span></div>
      </div>`;
      if(e.type==='text'){
        html+=`<div class="insp-section"><div class="insp-title">Text</div>
          <div class="insp-row"><select class="insp-field" data-insp-style="fontFamily">${FONTS.map(f=>`<option value="${f}" ${st.fontFamily===f?'selected':''}>${f}</option>`).join('')}</select><input class="insp-field" type="number" min="6" max="200" value="${st.fontSize||18}" data-insp-style="fontSize" style="width:56px"></div>
          <div class="insp-grid3" style="margin-bottom:6px"><button class="insp-btn ${st.bold?'active':''}" data-insp-action="bold">${icon('bold',{size:13})}</button><button class="insp-btn ${st.italic?'active':''}" data-insp-action="italic">${icon('italic',{size:13})}</button><button class="insp-btn ${st.underline?'active':''}" data-insp-action="underline">${icon('underline',{size:13})}</button></div>
          <div class="insp-grid3" style="margin-bottom:6px"><button class="insp-btn ${st.align==='left'?'active':''}" data-insp-action="align-left">${icon('alignLeft',{size:13})}</button><button class="insp-btn ${st.align==='center'?'active':''}" data-insp-action="align-center">${icon('alignCenter',{size:13})}</button><button class="insp-btn ${st.align==='right'?'active':''}" data-insp-action="align-right">${icon('alignRight',{size:13})}</button></div>
          <div class="insp-row"><label>Color</label><input class="insp-field" type="color" value="${this.toHex(st.color||'fg',t)}" data-insp-style="color" style="height:27px;padding:2px"></div>
          <div class="insp-row"><label>Fill</label><input class="insp-field" type="color" value="${this.toHex(st.fill||'transparent',t)}" data-insp-style="fill" style="height:27px;padding:2px"></div>
          <div class="insp-row"><label>Line</label><input class="insp-field" type="range" min=".8" max="2.2" step=".05" value="${st.lineHeight||1.3}" data-insp-style="lineHeight"></div>
          <div class="insp-row"><label>Spacing</label><input class="insp-field" type="range" min="0" max="8" step=".5" value="${st.letterSpacing||0}" data-insp-style="letterSpacing"></div>
        </div>`;
      }
      if(e.type==='shape'){
        html+=`<div class="insp-section"><div class="insp-title">Shape</div>
          <div class="insp-row"><label>Shape</label><select class="insp-field" data-insp-field="shape">${['rect','roundRect','ellipse','triangle','diamond','pentagon','hexagon','octagon','star','arrow','chevron','callout','cloud','heart','plus','line','arrowLine'].map(s=>`<option value="${s}" ${e.shape===s?'selected':''}>${s}</option>`).join('')}</select></div>
          <div class="insp-row"><label>Fill</label><input class="insp-field" type="color" value="${this.toHex(st.fill||'accent',t)}" data-insp-style="fill" style="height:27px;padding:2px"></div>
          <div class="insp-row"><label>Stroke</label><input class="insp-field" type="color" value="${this.toHex(st.stroke||'transparent',t)}" data-insp-style="stroke" style="height:27px;padding:2px"></div>
          <div class="insp-row"><label>Width</label><input class="insp-field" type="range" min="0" max="8" step=".5" value="${st.strokeWidth||0}" data-insp-style="strokeWidth"></div>
          <div class="insp-row"><label>Radius</label><input class="insp-field" type="range" min="0" max="50" value="${st.radius||0}" data-insp-style="radius"></div>
          <div class="insp-row"><label>Opacity</label><input class="insp-field" type="range" min="0" max="1" step=".05" value="${st.opacity==null?1:st.opacity}" data-insp-style="opacity"></div>
          <label class="check-row"><input type="checkbox" data-insp-style="shadow" ${st.shadow?'checked':''}> Drop shadow</label>
        </div>`;
      }
      if(e.type==='image'){
        html+=`<div class="insp-section"><div class="insp-title">Image</div>
          <div class="insp-row"><label>Fit</label><select class="insp-field" data-insp-field="fit"><option value="cover" ${e.fit==='cover'?'selected':''}>Cover</option><option value="contain" ${e.fit==='contain'?'selected':''}>Contain</option><option value="fill" ${e.fit==='fill'?'selected':''}>Stretch</option></select></div>
          <div class="insp-row"><label>Alt text</label><input class="insp-field" value="${esc(e.alt||'')}" data-insp-field="alt" placeholder="Describe the image"></div>
          <div class="insp-row"><label>Radius</label><input class="insp-field" type="range" min="0" max="40" value="${st.radius||0}" data-insp-style="radius"></div>
          <div class="insp-row"><label>Opacity</label><input class="insp-field" type="range" min="0" max="1" step=".05" value="${st.opacity==null?1:st.opacity}" data-insp-style="opacity"></div>
          <button class="insp-btn" style="width:100%" data-insp-action="replace-image">${icon('image',{size:13})} Replace image</button>
        </div>`;
      }
      if(e.type==='table'){
        html+=`<div class="insp-section"><div class="insp-title">Table</div>
          <div class="insp-row"><label>Rows</label><input class="insp-field" type="number" min="1" max="30" value="${(e.data||[]).length}" data-insp-action="table-rows"><label>Cols</label><input class="insp-field" type="number" min="1" max="12" value="${(e.data&&e.data[0]||[]).length}" data-insp-action="table-cols"></div>
          <div class="insp-row"><label>Size</label><input class="insp-field" type="number" min="6" max="40" value="${st.fontSize||12}" data-insp-style="fontSize"></div>
          <label class="check-row"><input type="checkbox" data-insp-style="header" ${e.header?'checked':''}> Header row</label>
          <label class="check-row"><input type="checkbox" data-insp-style="striped" ${st.striped?'checked':''}> Banded rows</label>
          <button class="insp-btn" style="width:100%" data-insp-action="edit-table">${icon('table',{size:13})} Edit table data</button>
        </div>`;
      }
      if(e.type==='chart'){
        html+=`<div class="insp-section"><div class="insp-title">Chart</div>
          <div class="insp-row"><label>Type</label><select class="insp-field" data-insp-field="chartType">${['column','bar','line','area','pie','donut'].map(c=>`<option value="${c}" ${e.chartType===c?'selected':''}>${c}</option>`).join('')}</select></div>
          <div class="insp-row"><label>Title</label><input class="insp-field" value="${esc(st.title||'')}" data-insp-style="title" placeholder="Chart title"></div>
          <label class="check-row"><input type="checkbox" data-insp-style="showLegend" ${st.showLegend!==false?'checked':''}> Legend</label>
          <label class="check-row"><input type="checkbox" data-insp-style="showValues" ${st.showValues!==false?'checked':''}> Values</label>
          <button class="insp-btn" style="width:100%" data-insp-action="edit-chart">${icon('chart',{size:13})} Edit chart data</button>
        </div>`;
      }
      if(e.type==='icon'){
        html+=`<div class="insp-section"><div class="insp-title">Icon</div>
          <div class="insp-row"><label>Name</label><input class="insp-field" value="${esc(e.name||'')}" data-insp-field="name"></div>
          <div class="insp-row"><label>Color</label><input class="insp-field" type="color" value="${this.toHex(st.color||'accent',t)}" data-insp-style="color" style="height:27px;padding:2px"></div>
          <button class="insp-btn" style="width:100%" data-insp-action="icon-gallery">${icon('icon',{size:13})} Change icon</button>
        </div>`;
      }
      if(e.type==='media'){
        html+=`<div class="insp-section"><div class="insp-title">Media</div>
          <label class="check-row"><input type="checkbox" data-insp-field="autoplay" ${e.autoplay?'checked':''}> Autoplay</label>
          <label class="check-row"><input type="checkbox" data-insp-field="controls" ${e.controls!==false?'checked':''}> Show controls</label>
        </div>`;
      }
      html+=`<div class="insp-section"><div class="insp-title">Arrange</div>
        <div class="insp-grid2"><button class="insp-btn" data-insp-action="bring-forward">${icon('bringFront',{size:13})} Forward</button><button class="insp-btn" data-insp-action="send-backward">${icon('sendBack',{size:13})} Backward</button><button class="insp-btn" data-insp-action="duplicate">${icon('duplicate',{size:13})} Duplicate</button><button class="insp-btn" data-insp-action="delete">${icon('trash',{size:13})} Delete</button></div>
        <label class="check-row"><input type="checkbox" data-insp-field="locked" ${e.locked?'checked':''}> Lock element</label>
      </div>`;
      return html;
    },
    inspectorNotes(){
      const s=Store.slide(); const w=words(s.notes||'');
      return `<div class="insp-section"><div class="insp-title">Speaker notes</div>
        <textarea class="insp-textarea" style="min-height:220px" data-insp-action="notes-text" placeholder="Write what you will say…">${esc(s.notes||'')}</textarea>
        <div class="insp-note" style="margin-top:7px">${w} words · ~${Math.max(1,Math.round(w/130))} min spoken</div>
        <div class="insp-grid2" style="margin-top:8px"><button class="insp-btn" data-insp-action="notes-pages">${icon('notes',{size:13})} Note page</button><button class="insp-btn" data-insp-action="handouts">${icon('handout',{size:13})} Handout</button></div>
      </div>
      <div class="insp-section"><div class="insp-title">Teaching cues</div>
        <div class="insp-note">${s.notes?'Use the notes above as a lesson script. j-Docs will lay them out with the slide on a printable note page.':'Add notes to turn this slide into a teaching cue, printable note page, and presenter script.'}</div>
      </div>`;
    },
    inspectorMotion(){
      const s=Store.slide(); const tr=s.transition||{}; const an=s.animation||{};
      return `<div class="insp-section"><div class="insp-title">Slide transition</div>
        <div class="insp-row"><label>Type</label><select class="insp-field" data-insp-action="transition">${['none','fade','push','wipe','split','reveal','morph','zoom'].map(x=>`<option value="${x}" ${tr.type===x?'selected':''}>${x}</option>`).join('')}</select></div>
        <div class="insp-row"><label>Speed</label><input class="insp-field" type="range" min=".2" max="2" step=".1" value="${tr.duration||.5}" data-insp-action="transition-duration"><span class="muted" style="font-size:10px">${tr.duration||.5}s</span></div>
        <div class="insp-row"><label>Advance</label><select class="insp-field" data-insp-action="advance"><option value="click" ${tr.advance==='click'?'selected':''}>On click</option><option value="auto" ${tr.advance==='auto'?'selected':''}>Automatically</option></select></div>
        <button class="insp-btn" style="width:100%;margin-top:5px" data-insp-action="preview-transition">${icon('play',{size:13})} Preview transition</button>
      </div>
      <div class="insp-section"><div class="insp-title">Object animation</div>
        <div class="insp-row"><label>Effect</label><select class="insp-field" data-insp-action="animation">${['none','appear','fade','fly','zoom','spin','pulse','wipe'].map(x=>`<option value="${x}" ${an.type===x?'selected':''}>${x}</option>`).join('')}</select></div>
        <div class="insp-row"><label>Duration</label><input class="insp-field" type="range" min=".2" max="2" step=".1" value="${an.duration||.5}" data-insp-action="anim-duration"><span class="muted" style="font-size:10px">${an.duration||.5}s</span></div>
        <div class="insp-row"><label>Delay</label><input class="insp-field" type="range" min="0" max="2" step=".1" value="${an.delay||0}" data-insp-action="anim-delay"><span class="muted" style="font-size:10px">${an.delay||0}s</span></div>
        <div class="insp-note">Animations are applied to the selected object. If nothing is selected, they apply to the whole slide.</div>
      </div>`;
    },
    inspectorA11y(){
      const checks=this.a11yChecks();
      const score=Math.round(checks.filter(c=>c.level==='ok').length/checks.length*100);
      return `<div class="insp-section"><div class="a11y-score"><div class="a11y-ring" style="--score:${score}"><span>${score}</span></div><div><div style="font-weight:700;font-size:12px">Accessibility score</div><div class="muted" style="font-size:10px;line-height:1.4">Live checks on this slide and project</div></div></div>
        <div class="a11y-list">${checks.map(c=>`<div class="a11y-item ${c.level}">${icon(c.level==='ok'?'checkCircle':c.level==='warn'?'warning':'error',{size:13})}<span>${esc(c.text)}</span></div>`).join('')}</div>
      </div>
      <div class="insp-section"><div class="insp-title">Reading order</div>
        <div class="insp-note">Elements are read in z-order. Use the buttons to move the selected element earlier or later in the reading order.</div>
        <div class="insp-grid2" style="margin-top:6px"><button class="insp-btn" data-insp-action="reading-earlier">${icon('arrowUp',{size:13})} Earlier</button><button class="insp-btn" data-insp-action="reading-later">${icon('arrowDown',{size:13})} Later</button></div>
      </div>
      <div class="insp-section"><div class="insp-title">Alt text</div>
        <textarea class="insp-textarea" data-insp-action="alt-text" placeholder="Describe the selected image or object for screen readers">${esc(Store.selectedElement()?.alt||'')}</textarea>
      </div>
      <div class="insp-section"><div class="insp-title">Display</div>
        <label class="check-row"><input type="checkbox" data-insp-action="toggle-contrast"> High contrast</label>
        <label class="check-row"><input type="checkbox" data-insp-action="toggle-large-text"> Larger text</label>
        <label class="check-row"><input type="checkbox" data-insp-action="toggle-motion"> Reduce motion</label>
        <label class="check-row"><input type="checkbox" data-insp-action="toggle-dyslexia"> Dyslexia-friendly font</label>
      </div>`;
    },
    a11yChecks(){
      const s=Store.slide(); const els=s.elements||[]; const out=[];
      const textEls=els.filter(e=>e.type==='text');
      const imgs=els.filter(e=>e.type==='image');
      const tiny=textEls.filter(e=>(e.style?.fontSize||18)<12);
      const lowContrast=textEls.filter(e=>{
        const c=e.style?.color||'fg'; const bg=s.background||Store.theme().bg;
        return c==='muted' && !String(bg).includes('gradient');
      });
      out.push({level:textEls.length?'ok':'warn',text:textEls.length?`${textEls.length} text object${textEls.length>1?'s':''} present`:'No text on this slide'});
      out.push({level:imgs.every(e=>e.alt)?'ok':imgs.length?'bad':'ok',text:imgs.length?(imgs.every(e=>e.alt)?'All images have alt text':`${imgs.filter(e=>!e.alt).length} image(s) need alt text`):'No images to describe'});
      out.push({level:tiny.length?'warn':'ok',text:tiny.length?`${tiny.length} text object(s) below 12 pt`:'Text sizes are readable'});
      out.push({level:lowContrast.length?'warn':'ok',text:lowContrast.length?`${lowContrast.length} muted text object(s) — check contrast`:'No obvious contrast issues'});
      out.push({level:s.notes?'ok':'warn',text:s.notes?'Speaker notes available for the presenter':'Add speaker notes for accessibility and teaching'});
      out.push({level:(Store.project.slides.length>0)?'ok':'bad',text:'Every slide has a title placeholder'});
      return out;
    },
    toHex(c,t){
      if(!c) return '#000000';
      if(c==='fg')return t.fg; if(c==='bg')return t.bg; if(c==='accent')return t.accent; if(c==='accent2')return t.accent2; if(c==='muted')return t.muted; if(c==='soft')return t.soft; if(c==='transparent')return '#ffffff';
      if(/^#[0-9a-f]{6}$/i.test(c))return c;
      if(/^#[0-9a-f]{3}$/i.test(c))return '#'+c[1]+c[1]+c[2]+c[2]+c[3]+c[3];
      return '#c43e1c';
    },
    inspectorInput(e){
      const t=e.target; const eid=Store.selected?.[0]; const el=Store.selectedElement();
      if(t.dataset.inspField && el){
        let v=t.type==='checkbox'?t.checked:t.value;
        if(['x','y','w','h','rotation'].includes(t.dataset.inspField)) v=Number(v)||0;
        Store.updateElement(el.id,{[t.dataset.inspField]:v},{noCommit:false});
        this.renderCanvas(); this.renderSelection(); this.updateStatus();
        return;
      }
      if(t.dataset.inspStyle && el){
        let v=t.type==='checkbox'?t.checked:t.value;
        if(['fontSize','strokeWidth','radius','opacity','lineHeight','letterSpacing'].includes(t.dataset.inspStyle)) v=Number(v);
        if(t.dataset.inspStyle==='header'){ Store.updateElement(el.id,{header:!!v}); this.renderCanvas(); return; }
        Store.updateStyle(el.id,{[t.dataset.inspStyle]:v});
        this.renderCanvas(); this.renderSelection(); this.updateStatus();
        return;
      }
      if(t.dataset.inspAction==='notes-text'){ Store.setNotes(t.value); this.renderNotes(); this.updateStatus(); return; }
      if(t.dataset.inspAction==='alt-text'){ if(el){Store.updateElement(el.id,{alt:t.value});} return; }
      if(t.dataset.inspAction==='table-rows'||t.dataset.inspAction==='table-cols'){
        if(!el||el.type!=='table')return;
        const rows=Math.max(1,Math.min(30,Number(t.dataset.inspAction==='table-rows'?t.value:(el.data||[]).length)||1));
        const cols=Math.max(1,Math.min(12,Number(t.dataset.inspAction==='table-cols'?t.value:((el.data&&el.data[0])||[]).length)||1));
        const data=Array.from({length:rows},(_,r)=>Array.from({length:cols},(_,c)=>(el.data[r]&&el.data[r][c])||''));
        Store.updateElement(el.id,{data}); this.renderCanvas(); this.renderInspector(); return;
      }
    },
    inspectorAction(action,value,btn){
      const el=Store.selectedElement();
      switch(action){
        case 'layout': Store.commit('layout'); Store.current=Store.current; { const s=Store.slide(); const data=this.extractSlideData(s); const ns=makeLayout(value,Store.project.theme,data); ns.id=s.id; ns.notes=s.notes; ns.transition=s.transition; Store.project.slides[Store.current]=ns; } this.refresh(); break;
        case 'background': Store.setBackground(value); this.renderCanvas(); this.renderInspector(); break;
        case 'background-text': Store.setBackground(value); this.renderCanvas(); break;
        case 'hidden': Store.slide().hidden=!!value; Store.markDirty(); this.renderRail(); break;
        case 'theme': this.applyTheme(value); break;
        case 'bold': this.toggleStyle('bold'); break;
        case 'italic': this.toggleStyle('italic'); break;
        case 'underline': this.toggleStyle('underline'); break;
        case 'align-left': this.setStyle('align','left'); break;
        case 'align-center': this.setStyle('align','center'); break;
        case 'align-right': this.setStyle('align','right'); break;
        case 'bring-forward': Store.bringForward(); this.renderCanvas(); this.renderSelection(); break;
        case 'send-backward': Store.sendBackward(); this.renderCanvas(); this.renderSelection(); break;
        case 'duplicate': Store.duplicateSelected(); this.refresh(); break;
        case 'delete': Store.removeSelected(); this.refresh(); break;
        case 'replace-image': $('#imageInput').click(); break;
        case 'edit-table': window.JDApp?.editTable(el); break;
        case 'edit-chart': window.JDApp?.editChart(el); break;
        case 'icon-gallery': window.JDApp?.iconGallery(); break;
        case 'reading-earlier': if(el){el.z=Math.max(0,(el.z||0)-1);Store.markDirty();this.renderCanvas();} break;
        case 'reading-later': if(el){el.z=(el.z||0)+1;Store.markDirty();this.renderCanvas();} break;
        case 'toggle-contrast': window.JDApp?.toggleContrast(); break;
        case 'toggle-large-text': window.JDApp?.toggleLargeText(); break;
        case 'toggle-motion': window.JDApp?.toggleMotion(); break;
        case 'toggle-dyslexia': window.JDApp?.toggleDyslexia(); break;
        case 'transition': Store.slide().transition.type=value; Store.markDirty(); this.renderInspector(); break;
        case 'transition-duration': Store.slide().transition.duration=Number(value); Store.markDirty(); break;
        case 'advance': Store.slide().transition.advance=value; Store.markDirty(); break;
        case 'animation': Store.slide().animation.type=value; Store.markDirty(); break;
        case 'anim-duration': Store.slide().animation.duration=Number(value); Store.markDirty(); break;
        case 'anim-delay': Store.slide().animation.delay=Number(value); Store.markDirty(); break;
        case 'preview-transition': window.JDPresent?.previewTransition(); break;
        case 'handouts': window.JDOutputs?.handouts(); break;
        case 'summaries': window.JDOutputs?.summaries(); break;
        case 'notes-pages': window.JDOutputs?.notesPages(); break;
        case 'offline-package': window.JDOutputs?.offlinePackage(); break;
      }
    },
    extractSlideData(s){
      const texts=(s.elements||[]).filter(e=>e.type==='text').sort((a,b)=>a.y-b.y);
      return {title:texts[0]?strip(texts[0].content):'Add a title',body:texts[1]?texts[1].content:'<p>Add your content</p>',kicker:'',subtitle:texts[1]?strip(texts[1].content):''};
    },
    applyTheme(id){
      Store.commit('theme'); Store.project.theme=id;
      const t=themeById(id);
      Store.project.slides.forEach(s=>{
        if(['title','section','quote','closing'].includes(s.layout)||String(s.background||'').includes('gradient')) s.background=t.titleBg;
      });
      Store.markDirty(); this.refresh();
    },
    toggleStyle(key){ const el=Store.selectedElement(); if(!el||el.type!=='text')return; Store.updateStyle(el.id,{[key]:!el.style[key]}); this.renderCanvas(); this.renderSelection(); this.renderInspector(); this.syncRibbon(); },
    setStyle(key,val){ const el=Store.selectedElement(); if(!el)return; if(el.type==='text')Store.updateStyle(el.id,{[key]:val}); this.renderCanvas(); this.renderInspector(); },
    syncRibbon(){
      const el=Store.selectedElement();
      const ff=$('[data-action="font-family"]'), fs=$('[data-action="font-size"]');
      if(ff) ff.value=el&&el.style&&FONTS.includes(el.style.fontFamily)?el.style.fontFamily:'Segoe UI';
      if(fs) fs.value=el&&el.style?el.style.fontSize:18;
      $$('[data-action="bold"]').forEach(b=>b.classList.toggle('active',!!el?.style?.bold));
      $$('[data-action="italic"]').forEach(b=>b.classList.toggle('active',!!el?.style?.italic));
      $$('[data-action="underline"]').forEach(b=>b.classList.toggle('active',!!el?.style?.underline));
      $$('[data-action="strike"]').forEach(b=>b.classList.toggle('active',!!el?.style?.strike));
    },
    updateStatus(){
      const st=Store.stats();
      const wc=$('#wordCount'); if(wc) wc.textContent=st.words+' words · '+st.reading+' min read';
      const pos=$('#slidePosition'); if(pos) pos.textContent='Slide '+(Store.current+1)+' of '+Store.project.slides.length;
      const sv=$('#statusView'); if(sv) sv.textContent=Store.view.charAt(0).toUpperCase()+Store.view.slice(1);
    },
    keydown(e){
      const editing=this.editingId;
      const tag=(e.target.tagName||'').toLowerCase();
      const typing=editing||tag==='input'||tag==='textarea'||tag==='select'||e.target.isContentEditable;
      const mod=e.ctrlKey||e.metaKey;
      if(e.key==='Escape'){
        if(editing){ this.stopEditing(); e.preventDefault(); return; }
        if(document.querySelector('.modal-root.open')){ window.JDApp?.closeModal(); e.preventDefault(); return; }
        if(!$('#presentRoot').hidden){ window.JDPresent?.exit(); e.preventDefault(); return; }
        if(Store.selected.length){ Store.selected=[]; this.renderSelection(); this.renderInspector(); e.preventDefault(); return; }
      }
      if(mod&&e.key.toLowerCase()==='k'){ e.preventDefault(); window.JDApp?.openCommand(); return; }
      if(mod&&e.key.toLowerCase()==='s'){ e.preventDefault(); window.JDApp?.saveProject(); return; }
      if(mod&&e.key.toLowerCase()==='o'){ e.preventDefault(); $('#fileInput').click(); return; }
      if(mod&&e.key.toLowerCase()==='n'){ e.preventDefault(); window.JDApp?.newProject(); return; }
      if(mod&&e.key.toLowerCase()==='m'){ e.preventDefault(); Store.addSlide(); this.refresh(); return; }
      if(mod&&e.key.toLowerCase()==='f'){ e.preventDefault(); window.JDApp?.openCommand(''); return; }
      if(e.key==='F5'){ e.preventDefault(); window.JDPresent?.start(0); return; }
      if(e.key==='F1'&&mod){ e.preventDefault(); $('#ribbon').classList.toggle('collapsed'); return; }
      if(typing) return;
      if(mod&&e.key.toLowerCase()==='z'){ e.preventDefault(); if(e.shiftKey)Store.redo();else Store.undo(); this.refresh(); return; }
      if(mod&&e.key.toLowerCase()==='y'){ e.preventDefault(); Store.redo(); this.refresh(); return; }
      if(mod&&e.key.toLowerCase()==='d'){ e.preventDefault(); Store.duplicateSelected(); this.refresh(); return; }
      if(mod&&e.key.toLowerCase()==='c'){ if(Store.selected.length){ Store.clipboard=clone(Store.selectedElements()); window.JDApp?.toast('Copied '+Store.selected.length+' object(s)','info'); } return; }
      if(mod&&e.key.toLowerCase()==='v'){ if(Store.clipboard){ Store.clipboard.forEach(e=>{const c=clone(e);c.id=uid(e.type.slice(0,3));c.x+=3;c.y+=3;Store.addElement(c,{noCommit:true});}); this.refresh(); } return; }
      if(e.key==='Delete'||e.key==='Backspace'){ if(Store.selected.length){ e.preventDefault(); Store.removeSelected(); this.refresh(); } return; }
      if(e.key.startsWith('Arrow')&&Store.selected.length){
        e.preventDefault(); const step=e.shiftKey?5:0.5;
        const dx=e.key==='ArrowLeft'?-step:e.key==='ArrowRight'?step:0;
        const dy=e.key==='ArrowUp'?-step:e.key==='ArrowDown'?step:0;
        Store.commit('nudge');
        Store.selectedElements().forEach(el=>{el.x+=dx;el.y+=dy;});
        this.renderCanvas(); this.renderSelection(); this.renderInspector(); Store.markDirty();
        return;
      }
      if(e.key==='Tab'){
        const els=Store.elements(); if(!els.length)return;
        e.preventDefault(); const cur=Store.selected[0]; const idx=els.findIndex(x=>x.id===cur); const next=els[(idx+(e.shiftKey?-1:1)+els.length)%els.length];
        Store.select(next.id); this.renderSelection(); this.renderInspector(); this.syncRibbon();
      }
      if(e.key==='Enter'&&Store.selected.length===1){ const el=Store.selectedElement(); if(el&&el.type==='text'){ e.preventDefault(); this.startEditing(el.id); } }
    },

    handleAction(action,value,btn,e){
      if(!action)return;
      const el=Store.selectedElement();
      const needText=()=>{ if(!el||el.type!=='text'){ window.JDApp?.toast('Select a text box first','info'); return false; } return true; };
      switch(action){
        case 'add-slide': Store.addSlide('titleContent'); this.refresh(); break;
        case 'duplicate-slide': Store.duplicateSlide(); this.refresh(); break;
        case 'delete-slide': Store.deleteSlide(); this.refresh(); break;
        case 'layout-gallery': window.JDApp?.layoutGallery(); break;
        case 'reset-slide': { const s=Store.slide(); const data=this.extractSlideData(s); const ns=makeLayout(s.layout,Store.project.theme,data); ns.id=s.id; Store.project.slides[Store.current]=ns; Store.commit('reset'); this.refresh(); break; }
        case 'add-section': Store.slide().section=prompt('Section name','Section')||''; Store.markDirty(); this.renderRail(); break;
        case 'font-family': if(needText()){ Store.updateStyle(el.id,{fontFamily:value}); this.renderCanvas(); } break;
        case 'font-size': if(needText()){ Store.updateStyle(el.id,{fontSize:Number(value)}); this.renderCanvas(); this.renderSelection(); } break;
        case 'font-grow': if(needText()){ Store.updateStyle(el.id,{fontSize:Math.min(200,(el.style.fontSize||18)+2)}); this.renderCanvas(); this.renderInspector(); } break;
        case 'font-shrink': if(needText()){ Store.updateStyle(el.id,{fontSize:Math.max(6,(el.style.fontSize||18)-2)}); this.renderCanvas(); this.renderInspector(); } break;
        case 'bold': case 'italic': case 'underline': case 'strike': this.toggleStyle(action); break;
        case 'font-color': window.JDApp?.colorPicker('color'); break;
        case 'highlight': window.JDApp?.colorPicker('fill'); break;
        case 'clear-format': if(needText()){ Store.updateStyle(el.id,{fontFamily:'body',fontSize:18,color:'fg',bold:false,italic:false,underline:false,strike:false,align:'left',lineHeight:1.3,letterSpacing:0,fill:'transparent',uppercase:false}); this.renderCanvas(); this.renderInspector(); } break;
        case 'bullets': if(needText()){ this.wrapList(el,'ul'); } break;
        case 'numbering': if(needText()){ this.wrapList(el,'ol'); } break;
        case 'align-left': case 'align-center': case 'align-right': case 'align-justify': this.setStyle('align',action.replace('align-','')); break;
        case 'line-spacing': if(needText()){ const opts=[1,1.15,1.3,1.5,1.75,2]; const cur=el.style.lineHeight||1.3; const next=opts[(opts.indexOf(cur)+1)%opts.length]||1.3; Store.updateStyle(el.id,{lineHeight:next}); this.renderCanvas(); window.JDApp?.toast('Line spacing '+next); } break;
        case 'text-direction': if(needText()){ Store.updateStyle(el.id,{align:el.style.align==='right'?'left':'right'}); this.renderCanvas(); } break;
        case 'shape-fill': window.JDApp?.colorPicker('shapeFill'); break;
        case 'shape-outline': window.JDApp?.colorPicker('shapeStroke'); break;
        case 'shape-effects': if(el){ Store.updateStyle(el.id,{shadow:!el.style.shadow}); this.renderCanvas(); } break;
        case 'eyedropper': window.JDApp?.toast('Eyedropper: click a color swatch to apply','info'); break;
        case 'find': window.JDApp?.openCommand(''); break;
        case 'replace': window.JDApp?.findReplace(); break;
        case 'select-all': Store.selectMany(Store.elements().map(x=>x.id)); this.renderSelection(); this.renderInspector(); break;
        case 'ai-assist': window.JDApp?.aiAssist(); break;
        case 'insert-text': this.insertText(); break;
        case 'insert-image': $('#imageInput').click(); break;
        case 'insert-media': $('#mediaInput').click(); break;
        case 'insert-table': window.JDApp?.tableDialog(); break;
        case 'insert-chart': window.JDApp?.chartDialog(); break;
        case 'shape-gallery': window.JDApp?.shapeGallery(); break;
        case 'icon-gallery': window.JDApp?.iconGallery(); break;
        case 'insert-smartart': window.JDApp?.smartArtGallery(); break;
        case 'insert-code': this.insertCode(); break;
        case 'insert-embed': this.insertEmbed(); break;
        case 'insert-link': window.JDApp?.linkDialog(); break;
        case 'insert-comment': window.JDApp?.commentDialog(); break;
        case 'insert-action': window.JDApp?.linkDialog(); break;
        case 'header-footer': window.JDApp?.headerFooterDialog(); break;
        case 'insert-date': this.insertText(new Date().toLocaleDateString()); break;
        case 'insert-slide-number': this.insertText('Slide '+ (Store.current+1)); break;
        case 'insert-symbol': this.insertText('§ ¶ © ® ™ ° ± × ÷ ≈ ≠ ≤ ≥ ∞'); break;
        case 'insert-equation': this.insertText('E = mc²'); break;
        case 'ai-outline': window.JDApp?.aiOutline(); break;
        case 'designer': window.JDApp?.designer(); break;
        case 'theme': this.applyTheme(value); break;
        case 'variants': window.JDApp?.variants(); break;
        case 'palette': window.JDApp?.paletteDialog(); break;
        case 'font-pair': window.JDApp?.fontPair(); break;
        case 'theme-effects': window.JDApp?.themeEffects(); break;
        case 'background': window.JDApp?.backgroundDialog(); break;
        case 'slide-size': window.JDApp?.slideSizeDialog(); break;
        case 'brand-kit': window.JDApp?.brandKit(); break;
        case 'reset-theme': this.applyTheme('ember'); break;
        case 'toggle-grid': Store.project.settings.grid=!Store.project.settings.grid; Store.markDirty(); this.renderCanvas(); window.JDApp?.toast('Grid '+(Store.project.settings.grid?'on':'off')); break;
        case 'toggle-guides': Store.project.settings.guides=!Store.project.settings.guides; Store.markDirty(); window.JDApp?.toast('Guides '+(Store.project.settings.guides?'on':'off')); break;
        case 'toggle-ruler': window.JDApp?.toast('Rulers are shown around the canvas','info'); break;
        case 'transition-none': case 'transition-fade': case 'transition-push': case 'transition-wipe': case 'transition-split': case 'transition-reveal': case 'transition-morph': case 'transition-zoom': Store.slide().transition.type=action.replace('transition-',''); Store.markDirty(); this.renderInspector(); window.JDApp?.toast('Transition: '+action.replace('transition-','')); break;
        case 'transition-duration': Store.slide().transition.duration=Number(value); Store.markDirty(); break;
        case 'transition-click': Store.slide().transition.advance='click'; Store.markDirty(); break;
        case 'transition-after': Store.slide().transition.advance='auto'; Store.markDirty(); break;
        case 'transition-all': Store.project.slides.forEach(s=>s.transition=clone(Store.slide().transition)); Store.markDirty(); window.JDApp?.toast('Transition applied to all slides','success'); break;
        case 'preview-transition': window.JDPresent?.previewTransition(); break;
        case 'transition-sound': window.JDApp?.toast('Transition sounds are muted by default for accessibility','info'); break;
        case 'anim-appear': case 'anim-fade': case 'anim-fly': case 'anim-zoom': case 'anim-spin': case 'anim-pulse': case 'anim-wipe': Store.slide().animation.type=action.replace('anim-',''); Store.markDirty(); this.renderInspector(); break;
        case 'anim-duration': Store.slide().animation.duration=Number(value); Store.markDirty(); break;
        case 'anim-delay': Store.slide().animation.delay=Number(value); Store.markDirty(); break;
        case 'anim-click': Store.slide().animation.start='click'; Store.markDirty(); break;
        case 'anim-with': Store.slide().animation.start='with'; Store.markDirty(); break;
        case 'anim-after': Store.slide().animation.start='after'; Store.markDirty(); break;
        case 'animation-pane': Store.inspectorTab='motion'; $$('.insp-tab').forEach(x=>{x.classList.toggle('active',x.dataset.insp==='motion')}); this.renderInspector(); break;
        case 'preview-animation': window.JDPresent?.previewAnimation(); break;
        case 'animation-painter': window.JDApp?.toast('Animation painter: select a target object','info'); break;
        case 'present': window.JDPresent?.start(0); break;
        case 'present-current': window.JDPresent?.start(Store.current); break;
        case 'presenter': window.JDPresent?.start(Store.current,{presenter:true}); break;
        case 'rehearse': window.JDPresent?.start(Store.current,{rehearse:true}); break;
        case 'engage': window.JDEngage?.open(); break;
        case 'analytics': window.JDEngage?.open('analytics'); break;
        case 'audience-preview': window.JDEngage?.previewAudience(); break;
        case 'broadcast': window.JDPresent?.start(Store.current,{presenter:true,broadcast:true}); break;
        case 'offline-package': window.JDOutputs?.offlinePackage(); break;
        case 'export-pptx': window.JDIO?.exportPPTX(); break;
        case 'export-html': window.JDIO?.exportHTML(); break;
        case 'print-studio': window.JDOutputs?.printStudio(); break;
        case 'subtitles': window.JDApp?.toast('Live subtitles use the browser speech engine when available','info'); break;
        case 'display-settings': window.JDApp?.toast('Use your OS display settings for projector resolution','info'); break;
        case 'spellcheck': Store.project.settings.proofing=!Store.project.settings.proofing; Store.markDirty(); window.JDApp?.toast('Proofing '+(Store.project.settings.proofing?'on':'off')); break;
        case 'thesaurus': window.JDApp?.toast('Thesaurus: select a word in a text box','info'); break;
        case 'language': window.JDApp?.languageDialog(); break;
        case 'translate': window.JDApp?.translateDialog(); break;
        case 'comments-pane': window.JDApp?.commentsPane(); break;
        case 'resolve-comments': window.JDApp?.toast('No open comments','info'); break;
        case 'accessibility-check': Store.inspectorTab='a11y'; $$('.insp-tab').forEach(x=>{x.classList.toggle('active',x.dataset.insp==='a11y')}); this.renderInspector(); window.JDApp?.toast('Accessibility checks updated','success'); break;
        case 'alt-text': Store.inspectorTab='a11y'; $$('.insp-tab').forEach(x=>{x.classList.toggle('active',x.dataset.insp==='a11y')}); this.renderInspector(); break;
        case 'reading-order': Store.inspectorTab='a11y'; $$('.insp-tab').forEach(x=>{x.classList.toggle('active',x.dataset.insp==='a11y')}); this.renderInspector(); break;
        case 'contrast-check': window.JDApp?.contrastDialog(); break;
        case 'protect': window.JDApp?.protectDialog(); break;
        case 'version-history': window.JDApp?.versionHistory(); break;
        case 'compare': window.JDApp?.compareDialog(); break;
        case 'view-normal': Store.view='normal'; this.refresh(); break;
        case 'view-outline': window.JDApp?.outlineView(); break;
        case 'view-sorter': window.JDApp?.sorterView(); break;
        case 'view-notes': Store.project.settings.showNotes=true; Store.view='notes'; this.refresh(); break;
        case 'view-reading': window.JDOutputs?.documentMode(); break;
        case 'view-teach': window.JDOutputs?.teachingKit(); break;
        case 'toggle-rail': $('#workspace').classList.toggle('rail-hidden'); this.fit(); break;
        case 'toggle-inspector': if(window.JDApp) window.JDApp._userInspector=true; $('#workspace').classList.toggle('inspector-open'); $('#workspace').classList.toggle('inspector-hidden'); this.fit(); break;
        case 'zoom-in': this.setZoom(this.zoomFactor*1.15); break;
        case 'zoom-out': this.setZoom(this.zoomFactor/1.15); break;
        case 'zoom-fit': this.zoomFactor=1; this.fit(); break;
        case 'focus-mode': document.body.classList.toggle('focus-mode'); this.fit(); break;
        case 'toggle-theme': window.JDApp?.toggleTheme(); break;
        case 'toggle-contrast': window.JDApp?.toggleContrast(); break;
        case 'toggle-large-text': window.JDApp?.toggleLargeText(); break;
        case 'toggle-dyslexia': window.JDApp?.toggleDyslexia(); break;
        case 'toggle-motion': window.JDApp?.toggleMotion(); break;
        case 'handouts': window.JDOutputs?.handouts(); break;
        case 'notes-pages': window.JDOutputs?.notesPages(); break;
        case 'summaries': window.JDOutputs?.summaries(); break;
        case 'exec-summary': window.JDOutputs?.execSummary(); break;
        case 'teaching-kit': window.JDOutputs?.teachingKit(); break;
        case 'lesson-plan': window.JDOutputs?.lessonPlan(); break;
        case 'quiz-builder': window.JDOutputs?.quizBuilder(); break;
        case 'readability': window.JDOutputs?.readability(); break;
        case 'save-as': window.JDIO?.saveProjectFile(); break;
        case 'export-all': window.JDOutputs?.exportAll(); break;
        case 'export-responses': window.JDEngage?.exportResponses(); break;
        case 'command': window.JDApp?.openCommand(); break;
        case 'shortcuts': window.JDApp?.shortcuts(); break;
        case 'why-jdocs': window.JDApp?.whyJDocs(); break;
        case 'docs': window.JDApp?.docs(); break;
        case 'a11y-settings': window.JDApp?.a11ySettings(); break;
        case 'reset-demo': window.JDApp?.resetDemo(); break;
        case 'new': window.JDApp?.newProject(); break;
        case 'my-documents': window.JDApp?.myDocuments(); break;
        case 'open': $('#fileInput').click(); break;
        case 'save': window.JDApp?.saveProject(); break;
        case 'about': window.JDApp?.about(); break;
        case 'privacy': window.JDApp?.privacy(); break;
        case 'licenses': window.JDApp?.licenses(); break;
        case 'share': window.JDApp?.share(); break;
        case 'more': window.JDApp?.openBrandMenu(); break;
        case 'rail-menu': window.JDApp?.railMenu(); break;
        case 'view-menu': window.JDApp?.viewMenu(); break;
        case 'mobile-tab': this.setTab(value); break;
        case 'paste': window.JDApp?.toast('Use Ctrl+V to paste','info'); break;
        case 'cut': window.JDApp?.toast('Cut is available from the element menu','info'); break;
        case 'copy': if(Store.selected.length){Store.clipboard=clone(Store.selectedElements());window.JDApp?.toast('Copied','success');} break;
        case 'duplicate': Store.duplicateSelected(); this.refresh(); break;
        case 'draw-pen': window.JDApp?.setInk('pen'); break;
        case 'draw-highlighter': window.JDApp?.setInk('highlighter'); break;
        case 'draw-eraser': window.JDApp?.setInk('eraser'); break;
        case 'draw-lasso': window.JDApp?.setInk('lasso'); break;
        case 'draw-clear': window.JDApp?.clearInk(); break;
        case 'ink-color': window.JDApp?.colorPicker('ink'); break;
        case 'ink-width': window.JDApp?.setInkWidth(Number(value)); break;
        case 'ink-convert': window.JDApp?.toast('Ink conversion keeps strokes as editable SVG','info'); break;
        case 'draw-gesture': window.JDApp?.toast('Gesture mode: drag to draw a gesture trail','info'); break;
        case 'rotate-canvas': window.JDApp?.toast('Canvas rotation is non-destructive','info'); break;
        case 'toggle-notes': Store.project.settings.showNotes=!Store.project.settings.showNotes; Store.markDirty(); this.refresh(); this.fit(); break;
        case 'accessibility': Store.inspectorTab='a11y'; this.renderInspector(); break;
        default: break;
      }
    },
    wrapList(el,tag){
      Store.commit('list');
      const div=document.createElement('div'); div.innerHTML=el.content;
      if(div.querySelector('ul,ol')){ div.querySelectorAll('ul,ol').forEach(x=>{ const frag=document.createDocumentFragment(); [...x.children].forEach(li=>{const p=document.createElement('p');p.innerHTML=li.innerHTML;frag.appendChild(p)}); x.replaceWith(frag); }); }
      else { const lines=div.innerHTML.split(/<br\s*\/?>|<\/p>/i).map(s=>strip(s)).filter(Boolean); div.innerHTML='<'+tag+'>'+lines.map(l=>'<li>'+esc(l)+'</li>').join('')+'</'+tag+'>'; }
      el.content=div.innerHTML; Store.markDirty(); this.renderCanvas();
    },
    insertText(text){
      const content=text?('<p>'+esc(text)+'</p>'):'<p>Type something…</p>';
      const el=textEl(content,32,36,36,12,{style:{fontSize:22,color:'fg'}});
      Store.addElement(el); this.refresh(); if(!text)setTimeout(()=>this.startEditing(el.id),50);
    },
    insertCode(){
      const el=codeEl('// j-Docs code block\nconst idea = "one project, every surface";\nconsole.log(idea);',24,28,52,36,{style:{fontSize:10}});
      Store.addElement(el); this.refresh();
    },
    insertEmbed(){
      const url=prompt('Embed URL (https://…)','https://www.example.com');
      if(!url)return;
      Store.addElement({id:uid('emb'),type:'embed',x:20,y:24,w:60,h:44,rotation:0,z:1,src:url,title:'Embedded content'}); this.refresh();
    },
    async insertImageFile(file){
      if(!file||!file.type.startsWith('image/'))return;
      const src=await window.JD.readAsDataURL(file);
      const img=new Image(); img.src=src;
      await new Promise(r=>{img.onload=r;img.onerror=r});
      const ratio=img.width&&img.height?img.width/img.height:16/9;
      let w=56,h=w*16/9/ratio; if(h>64){h=64;w=h*ratio*9/16;}
      const el=imageEl(src,(100-w)/2,(100-h)/2,w,h,{alt:file.name.replace(/\.[^.]+$/,''),fit:'cover'});
      Store.addElement(el); this.refresh(); window.JDApp?.toast('Image inserted','success');
    },
    async insertMediaFile(file){
      if(!file)return;
      const src=await window.JD.readAsDataURL(file);
      const kind=file.type.startsWith('audio')?'audio':'video';
      const el=mediaEl(kind,src,18,24,64,44,{controls:true});
      Store.addElement(el); this.refresh(); window.JDApp?.toast(kind+' inserted','success');
    }
  };

  window.JDEditor = Editor;
})();
