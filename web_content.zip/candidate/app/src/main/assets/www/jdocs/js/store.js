/* j-Docs state, themes, layouts, demo deck, history */
(function(){
  const uid = (p='el') => p+'_'+Math.random().toString(36).slice(2,9)+Date.now().toString(36).slice(-3);
  const clone = o => JSON.parse(JSON.stringify(o));
  const esc = s => String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const strip = html => String(html||'').replace(/<br\s*\/?>/gi,' ').replace(/<\/(p|li|h[1-6]|div)>/gi,' ').replace(/<[^>]+>/g,' ').replace(/&nbsp;/g,' ').replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/\s+/g,' ').trim();
  const words = html => { const t=strip(html); return t?t.split(/\s+/).filter(Boolean).length:0; };
  const debounce = (fn,ms=250)=>{let t;return function(...a){clearTimeout(t);t=setTimeout(()=>fn.apply(this,a),ms)}};
  const throttle = (fn,ms=16)=>{let last=0,t;return function(...a){const n=Date.now();if(n-last>=ms){last=n;fn.apply(this,a)}else{clearTimeout(t);t=setTimeout(()=>{last=Date.now();fn.apply(this,a)},ms-(n-last))}}};
  const fmtBytes = b => { if(!b&&b!==0)return '—'; const u=['B','KB','MB','GB']; let i=0,n=b; while(n>=1024&&i<u.length-1){n/=1024;i++} return (i?n.toFixed(1):n)+' '+u[i]; };
  const download = (blob,name) => { try{ window.JDLibrary?.saveArtifact(blob,name); }catch(e){} const a=document.createElement('a'); const url=URL.createObjectURL(blob); a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),4000); };
  const readAsDataURL = file => new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(r.result);r.onerror=rej;r.readAsDataURL(file)});
  const readAsText = file => new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(r.result);r.onerror=rej;r.readAsText(file)});
  const readAsArrayBuffer = file => new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(r.result);r.onerror=rej;r.readAsArrayBuffer(file)});
  const today = () => new Date().toLocaleDateString(undefined,{year:'numeric',month:'short',day:'numeric'});

  const THEMES = [
    {id:'ember',name:'Ember',bg:'#fffaf7',fg:'#201f1e',muted:'#6b625e',accent:'#c43e1c',accent2:'#ff8a4c',soft:'#fbe9e4',head:'"Segoe UI Semibold",Selawik,sans-serif',body:'"Segoe UI",Selawik,sans-serif',titleBg:'linear-gradient(135deg,#2a120c 0%,#6d2412 55%,#c43e1c 100%)',dark:false},
    {id:'midnight',name:'Midnight',bg:'#12100f',fg:'#f7f3ef',muted:'#b9b1ab',accent:'#ff8a4c',accent2:'#ffd166',soft:'#3a2118',head:'"Segoe UI Semibold",Selawik,sans-serif',body:'"Segoe UI",Selawik,sans-serif',titleBg:'linear-gradient(135deg,#0b0a09,#2a120c 60%,#8a2d14)',dark:true},
    {id:'paper',name:'Paper',bg:'#fbfaf6',fg:'#1f2937',muted:'#667085',accent:'#2b579a',accent2:'#5b8def',soft:'#e8eef8',head:'Georgia,"Times New Roman",serif',body:'"Segoe UI",Selawik,sans-serif',titleBg:'linear-gradient(135deg,#f4f1e8,#e7e2d4)',dark:false},
    {id:'forest',name:'Forest',bg:'#0f1f1a',fg:'#e9f5ef',muted:'#9fc4b5',accent:'#2fbf8f',accent2:'#a7f3d0',soft:'#12332a',head:'"Segoe UI Semibold",Selawik,sans-serif',body:'"Segoe UI",Selawik,sans-serif',titleBg:'linear-gradient(135deg,#07130f,#0f3a2c 60%,#176b52)',dark:true},
    {id:'ocean',name:'Ocean',bg:'#0b1b2b',fg:'#eaf4ff',muted:'#9db8d2',accent:'#38bdf8',accent2:'#7dd3fc',soft:'#0f2a42',head:'"Segoe UI Semibold",Selawik,sans-serif',body:'"Segoe UI",Selawik,sans-serif',titleBg:'linear-gradient(135deg,#06111c,#0b2f4a 60%,#0e7490)',dark:true},
    {id:'sunset',name:'Sunset',bg:'#2a1220',fg:'#ffeef6',muted:'#d8a8bf',accent:'#ff5d8f',accent2:'#ffb86b',soft:'#3d1a2d',head:'"Segoe UI Semibold",Selawik,sans-serif',body:'"Segoe UI",Selawik,sans-serif',titleBg:'linear-gradient(135deg,#1a0a12,#5b1b3a 55%,#c2416b)',dark:true},
    {id:'mono',name:'Mono',bg:'#ffffff',fg:'#111111',muted:'#6b6b6b',accent:'#111111',accent2:'#555555',soft:'#f0f0f0',head:'"Segoe UI Semibold",Selawik,sans-serif',body:'"Segoe UI",Selawik,sans-serif',titleBg:'linear-gradient(135deg,#111,#333)',dark:false},
    {id:'sand',name:'Sand',bg:'#f6efe4',fg:'#2b2118',muted:'#7a6653',accent:'#b45309',accent2:'#f59e0b',soft:'#f3e3cd',head:'Georgia,"Times New Roman",serif',body:'"Segoe UI",Selawik,sans-serif',titleBg:'linear-gradient(135deg,#3b2a1a,#8a5a25 60%,#d97706)',dark:false},
    {id:'violet',name:'Violet',bg:'#17122b',fg:'#f2edff',muted:'#b9aee0',accent:'#8b5cf6',accent2:'#c4b5fd',soft:'#2a2148',head:'"Segoe UI Semibold",Selawik,sans-serif',body:'"Segoe UI",Selawik,sans-serif',titleBg:'linear-gradient(135deg,#0d0919,#3b1d7a 60%,#7c3aed)',dark:true},
    {id:'citrus',name:'Citrus',bg:'#fffdf2',fg:'#1f2a12',muted:'#66754b',accent:'#65a30d',accent2:'#bef264',soft:'#eef7d6',head:'"Segoe UI Semibold",Selawik,sans-serif',body:'"Segoe UI",Selawik,sans-serif',titleBg:'linear-gradient(135deg,#1a2a08,#3f6212 60%,#84cc16)',dark:false},
    {id:'slate',name:'Slate',bg:'#1e293b',fg:'#f8fafc',muted:'#a8b6c8',accent:'#f59e0b',accent2:'#fbbf24',soft:'#2c3b52',head:'"Segoe UI Semibold",Selawik,sans-serif',body:'"Segoe UI",Selawik,sans-serif',titleBg:'linear-gradient(135deg,#0f172a,#1e3a5f 60%,#b45309)',dark:true},
    {id:'candy',name:'Candy',bg:'#fff5fb',fg:'#3b1230',muted:'#8a5b7a',accent:'#db2777',accent2:'#f472b6',soft:'#fce7f3',head:'"Segoe UI Semibold",Selawik,sans-serif',body:'"Segoe UI",Selawik,sans-serif',titleBg:'linear-gradient(135deg,#4a0d33,#9d174d 55%,#ec4899)',dark:false}
  ];

  const themeById = id => THEMES.find(t=>t.id===id) || THEMES[0];

  function textEl(html, x,y,w,h, opts={}){
    const o = Object.assign({
      type:'text', x,y,w,h, rotation:0, z:1,
      content: html,
      style:{fontFamily:'body',fontSize:18,color:'fg',bold:false,italic:false,underline:false,strike:false,align:'left',valign:'top',lineHeight:1.3,letterSpacing:0,fill:'transparent',padding:0,uppercase:false}
    }, opts);
    o.id = o.id||uid('txt');
    o.style = Object.assign({fontFamily:'body',fontSize:18,color:'fg',bold:false,italic:false,underline:false,strike:false,align:'left',valign:'top',lineHeight:1.3,letterSpacing:0,fill:'transparent',padding:0,uppercase:false}, opts.style||{});
    return o;
  }
  function shapeEl(shape,x,y,w,h,opts={}){
    return Object.assign({id:uid('shp'),type:'shape',x,y,w,h,rotation:0,z:1,shape,
      style:{fill:'accent',stroke:'transparent',strokeWidth:0,opacity:1,shadow:false,radius:0}}, opts, {style:Object.assign({fill:'accent',stroke:'transparent',strokeWidth:0,opacity:1,shadow:false,radius:0},opts.style||{})});
  }
  function imageEl(src,x,y,w,h,opts={}){
    return Object.assign({id:uid('img'),type:'image',x,y,w,h,rotation:0,z:1,src,fit:'cover',alt:'',caption:'',style:{radius:0,opacity:1,shadow:false}},opts);
  }
  function tableEl(data,x,y,w,h,opts={}){
    return Object.assign({id:uid('tbl'),type:'table',x,y,w,h,rotation:0,z:1,data,header:true,
      style:{fontSize:12,color:'fg',headerFill:'accent',headerColor:'#ffffff',border:'rgba(0,0,0,.18)',striped:true,align:'left'}},opts);
  }
  function chartEl(chartType,data,x,y,w,h,opts={}){
    return Object.assign({id:uid('cht'),type:'chart',x,y,w,h,rotation:0,z:1,chartType,data,
      style:{colors:['accent','accent2','#2b579a','#0f7b6c','#c19a00'],showLegend:true,showValues:true,title:'',grid:true}},opts);
  }
  function iconEl(name,x,y,w,h,opts={}){
    return Object.assign({id:uid('ico'),type:'icon',x,y,w,h,rotation:0,z:1,name,style:{color:'accent',opacity:1}},opts);
  }
  function mediaEl(kind,src,x,y,w,h,opts={}){
    return Object.assign({id:uid('med'),type:'media',x,y,w,h,rotation:0,z:1,kind,src,autoplay:false,controls:true,poster:'',style:{radius:0}},opts);
  }
  function codeEl(code,x,y,w,h,opts={}){
    return Object.assign({id:uid('cod'),type:'code',x,y,w,h,rotation:0,z:1,code,language:'text',style:{fontSize:10}},opts);
  }

  function baseSlide(theme, layout, extra={}){
    return Object.assign({
      id:uid('sld'), layout, background:'', notes:'', transition:{type:'fade',duration:0.5,advance:'click'}, animation:{type:'none',duration:0.5,delay:0,start:'click'}, elements:[], hidden:false, section:''
    }, extra);
  }

  const LAYOUTS = [
    {id:'title',name:'Title slide',icon:'text'},
    {id:'titleContent',name:'Title and content',icon:'layout'},
    {id:'section',name:'Section header',icon:'section'},
    {id:'twoContent',name:'Two content',icon:'layout'},
    {id:'comparison',name:'Comparison',icon:'compare'},
    {id:'titleOnly',name:'Title only',icon:'text'},
    {id:'blank',name:'Blank',icon:'square'},
    {id:'pictureCaption',name:'Picture with caption',icon:'image'},
    {id:'quote',name:'Quote',icon:'quote'},
    {id:'agenda',name:'Agenda',icon:'list'},
    {id:'bigNumber',name:'Big number',icon:'target'},
    {id:'stats',name:'Key metrics',icon:'chartBar'},
    {id:'timeline',name:'Timeline',icon:'git'},
    {id:'team',name:'Team',icon:'users'},
    {id:'closing',name:'Closing',icon:'sparkle'}
  ];

  function makeLayout(layout, theme, data={}){
    const t = themeById(theme);
    const s = baseSlide(t.id, layout);
    const title = data.title || 'Add a title';
    const body = data.body || '<p>Add your content</p>';
    const kicker = data.kicker || '';
    const add = e => { e.z = s.elements.length+1; s.elements.push(e); return e; };
    if(layout==='title'){
      s.background = t.titleBg;
      if(kicker) add(textEl('<p>'+esc(kicker)+'</p>',7,20,80,7,{style:{fontSize:11,color:'accent2',bold:true,letterSpacing:2,uppercase:true}}));
      add(textEl('<p>'+esc(title)+'</p>',7,30,82,26,{style:{fontSize:46,color:'#ffffff',bold:true,fontFamily:'head',lineHeight:1.02}}));
      add(textEl('<p>'+esc(data.subtitle||'A j-Docs presentation')+'</p>',7,60,72,12,{style:{fontSize:17,color:'rgba(255,255,255,.78)',fontFamily:'body'}}));
      add(shapeEl('rect',7,76,10,0.6,{style:{fill:'accent2',opacity:1}}));
    } else if(layout==='titleContent'){
      add(textEl('<p>'+esc(title)+'</p>',7,6,86,13,{style:{fontSize:32,color:'fg',bold:true,fontFamily:'head',lineHeight:1.05}}));
      add(shapeEl('rect',7,20,8,0.5,{style:{fill:'accent'}}));
      add(textEl(body,7,25,86,63,{style:{fontSize:18,color:'fg',lineHeight:1.38}}));
    } else if(layout==='section'){
      s.background = t.titleBg;
      if(kicker) add(textEl('<p>'+esc(kicker)+'</p>',8,24,80,7,{style:{fontSize:11,color:'accent2',bold:true,letterSpacing:2,uppercase:true}}));
      add(textEl('<p>'+esc(title)+'</p>',8,33,80,24,{style:{fontSize:42,color:'#fff',bold:true,fontFamily:'head',lineHeight:1.05}}));
      add(textEl('<p>'+esc(data.subtitle||'')+'</p>',8,60,70,12,{style:{fontSize:16,color:'rgba(255,255,255,.72)'}}));
      add(shapeEl('rect',8,76,14,0.6,{style:{fill:'accent2'}}));
    } else if(layout==='twoContent'){
      add(textEl('<p>'+esc(title)+'</p>',7,6,86,12,{style:{fontSize:30,bold:true,fontFamily:'head'}}));
      add(textEl(data.left||body,7,24,41,64,{style:{fontSize:16,lineHeight:1.4}}));
      add(textEl(data.right||'<p>Second column</p>',52,24,41,64,{style:{fontSize:16,lineHeight:1.4}}));
      add(shapeEl('rect',49.5,24,0.3,64,{style:{fill:'line',opacity:.5}}));
    } else if(layout==='comparison'){
      add(textEl('<p>'+esc(title)+'</p>',7,6,86,12,{style:{fontSize:30,bold:true,fontFamily:'head'}}));
      add(textEl('<p>'+esc(data.leftTitle||'Option A')+'</p>',7,22,41,8,{style:{fontSize:16,bold:true,color:'accent'}}));
      add(textEl('<p>'+esc(data.rightTitle||'Option B')+'</p>',52,22,41,8,{style:{fontSize:16,bold:true,color:'accent'}}));
      add(textEl(data.left||'<ul><li>Strength</li><li>Trade-off</li></ul>',7,32,41,54,{style:{fontSize:15,lineHeight:1.45}}));
      add(textEl(data.right||'<ul><li>Strength</li><li>Trade-off</li></ul>',52,32,41,54,{style:{fontSize:15,lineHeight:1.45}}));
      add(shapeEl('rect',49.5,22,0.3,64,{style:{fill:'line',opacity:.5}}));
    } else if(layout==='titleOnly'){
      add(textEl('<p>'+esc(title)+'</p>',7,8,86,16,{style:{fontSize:34,bold:true,fontFamily:'head'}}));
    } else if(layout==='blank'){
      // intentionally empty
    } else if(layout==='pictureCaption'){
      add(textEl('<p>'+esc(title)+'</p>',7,6,86,12,{style:{fontSize:30,bold:true,fontFamily:'head'}}));
      add(shapeEl('rect',7,22,86,58,{style:{fill:'soft',stroke:'line',strokeWidth:1}}));
      add(textEl('<p style="text-align:center;opacity:.55">Drop an image here, or use Insert → Picture</p>',10,46,80,10,{style:{fontSize:13,color:'muted',align:'center'}}));
      add(textEl('<p>'+esc(data.caption||'Caption')+'</p>',7,83,86,8,{style:{fontSize:11,color:'muted',italic:true}}));
    } else if(layout==='quote'){
      s.background = t.titleBg;
      add(textEl('<p>“</p>',7,14,20,20,{style:{fontSize:80,color:'accent2',fontFamily:'head',lineHeight:.8}}));
      add(textEl('<p>'+esc(title)+'</p>',9,30,82,34,{style:{fontSize:32,color:'#fff',italic:true,fontFamily:'head',lineHeight:1.18}}));
      add(textEl('<p>'+esc(data.subtitle||'— Attribution')+'</p>',9,70,60,8,{style:{fontSize:13,color:'rgba(255,255,255,.72)',bold:true,letterSpacing:1}}));
    } else if(layout==='agenda'){
      add(textEl('<p>'+esc(title)+'</p>',7,7,86,12,{style:{fontSize:32,bold:true,fontFamily:'head'}}));
      const items = (data.items||['Context','The idea','The proof','Next steps']);
      items.forEach((it,i)=>{
        const y = 25+i*13;
        add(textEl('<p>'+String(i+1).padStart(2,'0')+'</p>',7,y,8,8,{style:{fontSize:16,bold:true,color:'accent'}}));
        add(textEl('<p>'+esc(it)+'</p>',16,y,72,8,{style:{fontSize:18,bold:false,color:'fg'}}));
        add(shapeEl('rect',7,y+9,86,0.15,{style:{fill:'line',opacity:.55}}));
      });
    } else if(layout==='bigNumber'){
      add(textEl('<p>'+esc(kicker||'THE HEADLINE')+'</p>',7,12,80,7,{style:{fontSize:11,bold:true,color:'accent',letterSpacing:2,uppercase:true}}));
      add(textEl('<p>'+esc(title)+'</p>',7,22,80,32,{style:{fontSize:92,bold:true,color:'fg',fontFamily:'head',lineHeight:.95}}));
      add(textEl('<p>'+esc(data.subtitle||'Explain the number in one sentence.')+'</p>',7,60,70,14,{style:{fontSize:18,color:'muted',lineHeight:1.35}}));
      add(shapeEl('rect',7,80,12,0.6,{style:{fill:'accent'}}));
    } else if(layout==='stats'){
      add(textEl('<p>'+esc(title)+'</p>',7,7,86,11,{style:{fontSize:30,bold:true,fontFamily:'head'}}));
      const stats = data.stats||[{v:'3×',l:'faster'},{v:'0',l:'installs'},{v:'100%',l:'offline'}];
      stats.slice(0,3).forEach((st,i)=>{
        const x=7+i*29;
        add(shapeEl('roundRect',x,27,26,42,{style:{fill:'soft',stroke:'line',strokeWidth:.6,radius:2}}));
        add(textEl('<p>'+esc(st.v)+'</p>',x+2,32,22,16,{style:{fontSize:38,bold:true,color:'accent',fontFamily:'head',align:'center'}}));
        add(textEl('<p>'+esc(st.l)+'</p>',x+2,52,22,9,{style:{fontSize:11,color:'muted',align:'center',uppercase:true,letterSpacing:1}}));
      });
    } else if(layout==='timeline'){
      add(textEl('<p>'+esc(title)+'</p>',7,7,86,11,{style:{fontSize:30,bold:true,fontFamily:'head'}}));
      add(shapeEl('rect',8,46,84,0.5,{style:{fill:'line',opacity:.7}}));
      const items = data.items||['Discover','Design','Build','Launch'];
      items.slice(0,4).forEach((it,i)=>{
        const x=8+i*21;
        add(shapeEl('ellipse',x+8,43.6,4,4,{style:{fill:'accent',stroke:'bg',strokeWidth:1.2}}));
        add(textEl('<p>'+esc(it)+'</p>',x,52,19,8,{style:{fontSize:13,bold:true,align:'center'}}));
        add(textEl('<p>'+esc((data.descs&&data.descs[i])||'Milestone '+(i+1))+'</p>',x,60,19,12,{style:{fontSize:10,color:'muted',align:'center',lineHeight:1.3}}));
      });
    } else if(layout==='team'){
      add(textEl('<p>'+esc(title)+'</p>',7,7,86,11,{style:{fontSize:30,bold:true,fontFamily:'head'}}));
      const people = data.people||[{n:'Alex Rivera',r:'Product'},{n:'Sam Chen',r:'Design'},{n:'Jordan Lee',r:'Engineering'}];
      people.slice(0,3).forEach((p,i)=>{
        const x=7+i*29;
        add(shapeEl('ellipse',x+9,26,8,8,{style:{fill:'accent'}}));
        add(textEl('<p>'+esc(p.n)+'</p>',x,38,26,6,{style:{fontSize:13,bold:true,align:'center'}}));
        add(textEl('<p>'+esc(p.r)+'</p>',x,45,26,5,{style:{fontSize:10,color:'muted',align:'center'}}));
      });
    } else if(layout==='closing'){
      s.background = t.titleBg;
      add(textEl('<p>'+esc(title||'Thank you')+'</p>',8,28,80,18,{style:{fontSize:52,color:'#fff',bold:true,fontFamily:'head'}}));
      add(textEl('<p>'+esc(data.subtitle||'Questions, ideas, next steps.')+'</p>',8,50,70,10,{style:{fontSize:18,color:'rgba(255,255,255,.78)'}}));
      add(textEl('<p>'+esc(data.footer||'j-Docs · One project. Every surface.')+'</p>',8,82,80,6,{style:{fontSize:10,color:'rgba(255,255,255,.5)',letterSpacing:1,uppercase:true}}));
    }
    return s;
  }

  function newProject(name='Untitled presentation', themeId='ember'){
    const t=themeById(themeId);
    const p = {
      version:1, id:uid('prj'), name, type:'slides', theme:themeId,
      aspect:'16:9', createdAt:new Date().toISOString(), modifiedAt:new Date().toISOString(),
      author:'j-Docs user', slides:[], meta:{subject:'',keywords:'',company:'',description:''},
      settings:{grid:false,guides:true,snap:true,showNotes:false,proofing:true,language:'en-US'},
      fonts:[{family:'Selawik',license:'SIL OFL 1.1',embedded:true},{family:'Segoe UI',license:'System font — not redistributed',embedded:false}]
    };
    p.slides.push(makeLayout('title',themeId,{kicker:'j-DOCS',title:name,subtitle:'One project. Every surface.'}));
    p.slides.push(makeLayout('titleContent',themeId,{title:'Start here',body:'<ul><li>Click any text to edit it.</li><li>Drag elements to move them; use the handles to resize.</li><li>Open the <strong>Outputs</strong> tab to make handouts, summaries and offline packages.</li><li>Press <strong>F5</strong> to present, <strong>Ctrl+K</strong> to search commands.</li></ul>'}));
    return p;
  }

  function demoProject(){
    const p = newProject('j-Docs — Beyond Imagination','ember');
    p.meta.description='A working demo of j-Docs: the local-first presentation, document, teaching and live-audience studio.';
    p.slides = [];
    const T='ember';
    const addSlide = (layout,data)=>{ const s=makeLayout(layout,T,data); p.slides.push(s); return s; };

    let s = addSlide('title',{kicker:'THE PRESENTATION STUDIO, REBUILT',title:'One project.\nEvery surface.',subtitle:'Live presentation · downloadable document · teaching resource · online experience'});
    s.notes='Welcome. j-Docs is a single source of truth for a deck that has to work everywhere: on stage, in a PDF, in a classroom, and on the web.';
    s.transition={type:'fade',duration:.6,advance:'click'};

    s = addSlide('agenda',{title:'What we will cover',items:['The problem with “presentation apps”','One project, four surfaces','Open any file. Own your data.','Handouts, summaries and teaching kits','Live audience without another app','Offline packages that actually work','Why j-Docs wins']});
    s.notes='Set expectations. This is a product walkthrough and a working demo, not a slide of claims.';

    s = addSlide('stats',{title:'The deck is trapped in one format',stats:[{v:'4',l:'surfaces needed'},{v:'0',l:'files that travel'},{v:'1',l:'place to edit'}]});
    s.notes='Today a presentation is a PPTX. A handout is a separate export. A teaching resource is another document. A web experience is another tool. Every copy drifts.';

    s = addSlide('comparison',{title:'The copy-paste tax',leftTitle:'The old way',rightTitle:'The j-Docs way',left:'<ul><li>Deck in PowerPoint</li><li>Handout exported to PDF</li><li>Notes pasted into Word</li><li>Quiz built in another tool</li><li>Web version rebuilt again</li><li>Every version drifts</li></ul>',right:'<ul><li>One project file</li><li>Live, document, teach and web views</li><li>Handouts and notes generated from source</li><li>Audience engagement built in</li><li>Offline package with fonts and media</li><li>Nothing drifts</li></ul>'});
    s.notes='The competitive advantage is not another editor. It is eliminating the copies.';

    s = addSlide('section',{kicker:'01 · THE CORE IDEA',title:'One project.\nFour surfaces.',subtitle:'The same source renders as a stage, a document, a lesson, and a website.'});
    s.notes='This is the thesis. Everything else is a consequence.';

    s = addSlide('twoContent',{title:'Surface 1 & 2 — Present and read',left:'<p><strong>Live presentation</strong></p><ul><li>Presenter view with notes, timer and next slide</li><li>Audience polls, Q&A and word clouds</li><li>Anonymised analytics after the talk</li><li>Keyboard-first, 60 fps transitions</li></ul>',right:'<p><strong>Downloadable document</strong></p><ul><li>Continuous reading view</li><li>Print-ready pages and handouts</li><li>Semantic outline and summaries</li><li>Accessible reading order</li></ul>'});
    s.notes='Most tools force a choice between a stage and a document. j-Docs gives you both from the same project.';

    s = addSlide('twoContent',{title:'Surface 3 & 4 — Teach and publish',left:'<p><strong>Teaching resource</strong></p><ul><li>Speaker notes become printable note pages</li><li>Handouts with 1, 2, 3, 4 or 6 slides per page</li><li>Slide summaries and key-term extraction</li><li>Lesson plan and discussion prompts</li></ul>',right:'<p><strong>Online experience</strong></p><ul><li>Standalone HTML export</li><li>Audience join by link or QR — no install</li><li>Offline package with embedded fonts and media</li><li>Works from a USB stick or a static host</li></ul>'});
    s.notes='The teaching kit is where most presentation tools stop. j-Docs treats the classroom as a first-class output.';

    s = addSlide('bigNumber',{kicker:'UNIVERSAL OPENER',title:'Any file.',subtitle:'PPTX, DOCX, XLSX, PDF, ODP, images, audio, video, text, code — and extensions nobody has heard of.'});
    s.notes='The universal opener is a trust feature. You should never be locked out of your own content.';

    s = addSlide('titleContent',{title:'What “open any file” actually means',body:'<ul><li><strong>Native parsing:</strong> PPTX, PPSX, POTX, DOCX, XLSX, ODP, ODT, CSV, JSON, MD, HTML, SVG.</li><li><strong>Rich previews:</strong> PDF, images, audio, video, fonts, archives.</li><li><strong>Universal viewer:</strong> unknown binaries get metadata, a text preview and a hex dump.</li><li><strong>Never destructive:</strong> the original file is untouched. Import creates a new j-Docs project.</li></ul>'});
    s.notes='We parse the formats we can and gracefully inspect the ones we cannot. No “unsupported file” dead end.';

    s = addSlide('section',{kicker:'02 · OUTPUTS',title:'The deck becomes\na teaching kit.',subtitle:'Handouts, summaries, printable notes and offline packages — generated, not recreated.'});
    s.notes='This is the part audiences ask for first.';

    s = addSlide('stats',{title:'Generated from the same source',stats:[{v:'6',l:'handout layouts'},{v:'1',l:'click to print'},{v:'0',l:'retyped notes'}]});
    s.notes='Handouts support 1, 2, 3, 4 and 6 slides per page, with optional notes lines, headers, footers and page numbers.';

    s = addSlide('titleContent',{title:'Slide summaries that respect the source',body:'<ul><li>Every slide gets a title, key points, notes excerpt and reading time.</li><li>An executive summary pulls the through-line and key terms.</li><li>Export as Markdown, HTML, or a print-ready summary document.</li><li>No invented facts: summaries are extracted from your own content.</li></ul>'});
    s.notes='We deliberately avoid hallucinated summaries. The summary is a compression of what is on the slide and in the notes.';

    s = addSlide('section',{kicker:'03 · LIVE AUDIENCE',title:'Engagement without\nanother app.',subtitle:'A join code, a QR code, and anonymised analytics.'});
    s.notes='No audience install. No account. No personal data.';

    s = addSlide('twoContent',{title:'Ask, listen, learn',left:'<p><strong>Ask</strong></p><ul><li>Multiple choice</li><li>Word cloud</li><li>1–5 rating</li><li>Open Q&A</li><li>True / false</li></ul>',right:'<p><strong>Learn</strong></p><ul><li>Live response count</li><li>Anonymised bar charts</li><li>Word cloud and rating distribution</li><li>Response timeline</li><li>CSV export for analysis</li></ul>'});
    s.notes='Responses are anonymised by design: random response IDs, no names, aggregate views, and small-group suppression.';

    s = addSlide('section',{kicker:'04 · OFFLINE',title:'The package that\nactually travels.',subtitle:'Fonts, media, viewer and source — in one ZIP.'});
    s.notes='Offline is a real requirement in classrooms, conferences, field work and secure environments.';

    s = addSlide('titleContent',{title:'Inside an offline package',body:'<ul><li><strong>viewer.html</strong> — a standalone player with keyboard controls and notes.</li><li><strong>presentation.jdocs</strong> — the editable source project.</li><li><strong>fonts/</strong> — embedded Selawik (SIL OFL) and a licensing manifest.</li><li><strong>media/</strong> — images, audio and video where format support allows.</li><li><strong>handout.html</strong>, <strong>notes.html</strong>, <strong>summary.md</strong> — the teaching kit.</li></ul>'});
    s.notes='We only embed fonts we have the right to redistribute. Other fonts are listed with a fallback.';

    s = addSlide('section',{kicker:'05 · WHY IT WINS',title:'Better than\nPowerPoint?',subtitle:'Not by copying it. By removing the seams around it.'});
    s.notes='Let us be precise about the competitive advantage.';

    s = addSlide('comparison',{title:'Where j-Docs is different',leftTitle:'Presentation apps',rightTitle:'j-Docs',left:'<ul><li>Optimised for the slide</li><li>Exports are afterthoughts</li><li>Audience tools are add-ons</li><li>Offline is a degraded mode</li><li>Lock-in by format</li><li>Accessibility is a checklist</li></ul>',right:'<ul><li>Optimised for the whole lifecycle</li><li>Outputs are first-class surfaces</li><li>Engagement is built into the source</li><li>Offline is the default</li><li>Open .jdocs + standard exports</li><li>Accessibility is a live constraint</li></ul>'});
    s.notes='The moat is the unified project model and the output pipeline, not a feature checklist.';

    s = addSlide('agenda',{title:'Seven ideas that beat the giants',items:['One source, four surfaces','Universal opener with graceful fallback','Outputs generated, never recreated','Anonymised audience intelligence','Offline packages with licensing manifests','Accessibility as a live constraint','Local-first privacy and open portability']});
    s.notes='These are the ideas in the accompanying strategy document. Each one is shippable, not a moonshot.';

    s = addSlide('closing',{title:'Let’s build the\nsurface layer.',subtitle:'j-Docs — one project, every surface.',footer:'j-Docs · local-first · open formats · accessible by design'});
    s.notes='Close with the invitation: try the universal opener, generate a handout, start an audience session, and export an offline package.';

    p.modifiedAt=new Date().toISOString();
    return p;
  }

  const Store = {
    project:null, current:0, selected:[], clipboard:null, zoom:'fit', view:'normal', inspectorTab:'format',
    history:[], future:[], dirty:false, lastSaved:null, _saveTimer:null,
    init(){
      let loaded=null;
      try{ const raw=localStorage.getItem('jdocs.project.v1'); if(raw) loaded=JSON.parse(raw); }catch(e){}
      this.project = loaded && loaded.slides ? loaded : demoProject();
      this.project.id = this.project.id || ('doc_'+Math.random().toString(36).slice(2)+Date.now().toString(36));
      /* Rename the shipped demo for anyone who already has it saved. */
      if(this.project && typeof this.project.name==='string' && this.project.name.indexOf('Beyond PowerPoint')>-1){
        this.project.name=this.project.name.replace('Beyond PowerPoint','Beyond Imagination');
      }
      this.current = Math.min(this.current||0, this.project.slides.length-1);
      this.selected=[];
      this.history=[]; this.future=[];
      this.persistNow();
      return this.project;
    },
    theme(){ return themeById(this.project.theme); },
    slide(){ return this.project.slides[this.current]; },
    slideAt(i){ return this.project.slides[i]; },
    elements(){ return this.slide() ? this.slide().elements : []; },
    selectedElements(){ const ids=new Set(this.selected); return this.elements().filter(e=>ids.has(e.id)); },
    selectedElement(){ return this.elements().find(e=>e.id===this.selected[0]) || null; },
    snapshot(){ return JSON.stringify({project:this.project,current:this.current}); },
    commit(label='edit'){
      const snap=this.snapshot();
      if(this.history.length && this.history[this.history.length-1].snap===snap) return;
      this.history.push({snap,label,at:Date.now()});
      if(this.history.length>60) this.history.shift();
      this.future=[];
      this.markDirty();
    },
    undo(){
      if(!this.history.length) return false;
      const cur=this.snapshot();
      const h=this.history.pop();
      this.future.push({snap:cur,label:h.label});
      const st=JSON.parse(h.snap);
      this.project=st.project; this.current=Math.min(st.current,this.project.slides.length-1); this.selected=[];
      this.markDirty(); this.persistSoon();
      return true;
    },
    redo(){
      if(!this.future.length) return false;
      const cur=this.snapshot();
      const f=this.future.pop();
      this.history.push({snap:cur,label:f.label});
      const st=JSON.parse(f.snap);
      this.project=st.project; this.current=Math.min(st.current,this.project.slides.length-1); this.selected=[];
      this.markDirty(); this.persistSoon();
      return true;
    },
    markDirty(){
      this.dirty=true; this.project.modifiedAt=new Date().toISOString();
      const el=document.getElementById('saveState'); if(el){el.textContent='Unsaved changes';el.classList.add('dirty')}
      this.persistSoon();
    },
    persistSoon(){ clearTimeout(this._saveTimer); this._saveTimer=setTimeout(()=>this.persistNow(),650); },
    persistNow(){
      let localOK=true;try{localStorage.setItem('jdocs.project.v1',JSON.stringify(this.project));}catch(e){localOK=false;console.warn('j-Docs: localStorage is full; using the document library',e);}
      let libraryTask=null;try{libraryTask=window.JDLibrary?.saveProject(this.project)||null;}catch(e){libraryTask=Promise.reject(e);}
      this.lastSaved=new Date();this.dirty=false;
      const el=document.getElementById('saveState');
      if(el){el.textContent='Saving…';el.classList.remove('dirty');}
      if(libraryTask&&typeof libraryTask.then==='function')libraryTask.then(()=>{if(el){el.textContent='Saved locally · '+this.lastSaved.toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'});el.classList.remove('dirty');}}).catch(e=>{console.warn('j-Docs library save failed',e);if(el){el.textContent=localOK?'Saved in this browser':'Storage full — export to keep changes';el.classList.toggle('dirty',!localOK);}});
      else if(el){el.textContent=localOK?'Saved locally · '+this.lastSaved.toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'}):'Storage full — export to keep changes';el.classList.toggle('dirty',!localOK);}
    },
    setProject(p,opts={}){
      p.id=p.id||('doc_'+Math.random().toString(36).slice(2)+Date.now().toString(36));
      this.project=p; this.current=0; this.selected=[]; this.history=[]; this.future=[];
      if(!opts.silent){ this.markDirty(); this.persistNow(); }
    },
    setTheme(id){
      this.commit('theme');
      this.project.theme=id;
      this.markDirty();
    },
    addSlide(layout='titleContent',data={},at){
      this.commit('add slide');
      const s=makeLayout(layout,this.project.theme,data);
      const idx = at==null ? this.current+1 : Math.max(0,Math.min(at,this.project.slides.length));
      this.project.slides.splice(idx,0,s);
      this.current=idx; this.selected=[]; this.markDirty();
      return s;
    },
    duplicateSlide(i=this.current){
      this.commit('duplicate slide');
      const s=clone(this.project.slides[i]); s.id=uid('sld');
      s.elements.forEach(e=>e.id=uid(e.type.slice(0,3)));
      this.project.slides.splice(i+1,0,s);
      this.current=i+1; this.selected=[]; this.markDirty();
      return s;
    },
    deleteSlide(i=this.current){
      if(this.project.slides.length<=1){ this.toast?.('A project needs at least one slide'); return false; }
      this.commit('delete slide');
      this.project.slides.splice(i,1);
      this.current=Math.max(0,Math.min(i,this.project.slides.length-1)); this.selected=[]; this.markDirty();
      return true;
    },
    moveSlide(from,to){
      if(from===to) return;
      this.commit('reorder slides');
      const [s]=this.project.slides.splice(from,1);
      this.project.slides.splice(to,0,s);
      this.current=to; this.markDirty();
    },
    select(id,additive=false){
      if(!id){ this.selected=[]; return; }
      if(additive){
        if(this.selected.includes(id)) this.selected=this.selected.filter(x=>x!==id);
        else this.selected.push(id);
      } else this.selected=[id];
    },
    selectMany(ids){ this.selected=ids.slice(); },
    addElement(el,opts={}){
      if(!opts.noCommit) this.commit('add '+el.type);
      const s=this.slide(); if(!s) return;
      el.z = Math.max(0,...s.elements.map(e=>e.z||0))+1;
      s.elements.push(el);
      this.selected=[el.id];
      this.markDirty();
      return el;
    },
    updateElement(id,patch,opts={}){
      const el=this.elements().find(e=>e.id===id); if(!el) return;
      if(!opts.noCommit) this.commit('edit '+el.type);
      Object.assign(el,patch);
      this.markDirty();
    },
    updateStyle(id,patch,opts={}){
      const el=this.elements().find(e=>e.id===id); if(!el) return;
      if(!opts.noCommit) this.commit('style');
      el.style=Object.assign({},el.style,patch);
      this.markDirty();
    },
    removeSelected(){
      if(!this.selected.length) return;
      this.commit('delete elements');
      const s=this.slide(); const ids=new Set(this.selected);
      s.elements=s.elements.filter(e=>!ids.has(e.id));
      this.selected=[]; this.markDirty();
    },
    duplicateSelected(){
      if(!this.selected.length) return;
      this.commit('duplicate elements');
      const s=this.slide(); const out=[];
      this.selectedElements().forEach(e=>{
        const c=clone(e); c.id=uid(e.type.slice(0,3)); c.x=Math.min(94,c.x+3); c.y=Math.min(94,c.y+3); c.z=Math.max(0,...s.elements.map(x=>x.z||0))+1;
        s.elements.push(c); out.push(c.id);
      });
      this.selected=out; this.markDirty();
    },
    bringForward(){ this.reorder(1); },
    sendBackward(){ this.reorder(-1); },
    reorder(dir){
      const s=this.slide(); const sel=this.selectedElements();
      if(!sel.length) return;
      this.commit('arrange');
      if(dir>0){
        const max=Math.max(...s.elements.map(e=>e.z||0));
        sel.forEach(e=>e.z=Math.min(max+1,(e.z||0)+1.5));
      } else {
        const min=Math.min(...s.elements.map(e=>e.z||0));
        sel.forEach(e=>e.z=Math.max(min-1,(e.z||0)-1.5));
      }
      s.elements.sort((a,b)=>(a.z||0)-(b.z||0));
      this.markDirty();
    },
    setBackground(value){
      this.commit('background');
      this.slide().background=value;
      this.markDirty();
    },
    setNotes(text){
      this.slide().notes=text;
      this.markDirty();
    },
    stats(){
      const slides=this.project.slides;
      let w=0, chars=0, media=0, images=0;
      slides.forEach(s=>{
        s.elements.forEach(e=>{
          if(e.type==='text'){ w+=words(e.content); chars+=strip(e.content).length; }
          if(e.type==='image') images++;
          if(e.type==='media') media++;
        });
        w+=words(s.notes);
      });
      return {slides:slides.length,words:w,chars,images,media,reading:Math.max(1,Math.round(w/220))};
    },
    outline(){
      return this.project.slides.map((s,i)=>{
        const texts=s.elements.filter(e=>e.type==='text').sort((a,b)=>a.y-b.y);
        const title=texts[0]?strip(texts[0].content):'Untitled slide';
        const points=[];
        texts.slice(1).forEach(t=>{
          const div=document.createElement('div'); div.innerHTML=t.content;
          div.querySelectorAll('li').forEach(li=>points.push(li.textContent.trim()));
          if(!div.querySelector('li')){ const tx=div.textContent.trim(); if(tx) points.push(tx); }
        });
        return {index:i,title,points,notes:s.notes,slide:s};
      });
    },
    search(q){
      q=String(q||'').toLowerCase().trim(); if(!q) return [];
      const out=[];
      this.project.slides.forEach((s,i)=>{
        s.elements.forEach(e=>{
          const txt=e.type==='text'?strip(e.content):'';
          if(txt.toLowerCase().includes(q)) out.push({slide:i,type:'text',text:txt.slice(0,120),el:e});
        });
        if((s.notes||'').toLowerCase().includes(q)) out.push({slide:i,type:'notes',text:s.notes.slice(0,120)});
      });
      return out;
    }
  };

  window.JD = window.JD || {};
  Object.assign(window.JD,{Store,THEMES,themeById,LAYOUTS,makeLayout,newProject,demoProject,uid,clone,esc,strip,words,debounce,throttle,fmtBytes,download,readAsDataURL,readAsText,readAsArrayBuffer,today,textEl,shapeEl,imageEl,tableEl,chartEl,iconEl,mediaEl,codeEl,baseSlide});
})();
