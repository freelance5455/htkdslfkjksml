/* MedPocket study-only Supabase accounts and cloud sync.
   Patient logbook, clinical case records, attachments and device files are deliberately excluded. */
(function(){
  'use strict';
  const CFG_KEY='medPocketSupabaseConfigV1';
  // Public browser configuration. Never place a Supabase secret/service-role key here.
  const DEFAULT_CONFIG={url:'https://nnheojeegwsruykbbihk.supabase.co',key:'sb_publishable_YPLGcRaPSMMZ_JmLlXIOJA_-pn9vx4a',webRedirect:'https://delightful-bunny-5031da.netlify.app/'};
  const STUDY_KEYS=['p','year','notes','cards','mcqs','tasks','tt','exams','planner','examHist','streak','stats','missed','heat','lib','custom','osceC','drugs','dis','xp','badges','review','fcExam','years'];
  let client=null, user=null, syncTimer=null, busy=false, lastSync=0, initPromise=null, recoveryMode=false;
  const $id=id=>document.getElementById(id);
  const esc2=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function config(){try{const saved=JSON.parse(localStorage.getItem(CFG_KEY)||'{}');return {url:saved.url||DEFAULT_CONFIG.url,key:saved.key||DEFAULT_CONFIG.key}}catch(e){return DEFAULT_CONFIG}}
  function saveConfig(c){localStorage.setItem(CFG_KEY,JSON.stringify(c));client=null;user=null;initPromise=null}
  function authRedirect(){return location.hostname==='appassets.androidplatform.net'?DEFAULT_CONFIG.webRedirect:(location.origin+location.pathname)}
  function studyPayload(){const out={};STUDY_KEYS.forEach(k=>{if(typeof S!=='undefined'&&S[k]!==undefined){if(k==='p'){const p=S.p||{};out.p={name:p.name||'',prog:p.prog||'',year:p.year||'',done:!!p.done,avatar:p.avatar||''}}else out[k]=S[k]}});return out}
  function mergeStudy(remote){let changed=0;if(!remote||typeof remote!=='object')return changed;
    STUDY_KEYS.forEach(k=>{if(remote[k]===undefined)return;const r=remote[k],l=S[k];
      if(Array.isArray(r)){const a=Array.isArray(l)?l.slice():[];r.forEach(item=>{if(item&&item.id!==undefined){const i=a.findIndex(x=>x&&x.id===item.id);if(i<0){a.push(item);changed++}else a[i]=item}else if(!a.some(x=>JSON.stringify(x)===JSON.stringify(item))){a.push(item);changed++}});S[k]=a;
      }else if(r&&typeof r==='object'){S[k]=Object.assign({},(l&&typeof l==='object'&&!Array.isArray(l))?l:{},r);changed++}
      else {S[k]=r;changed++}
    });
    return changed;
  }
  async function ensureClient(){if(client)return client;if(initPromise)return initPromise;
    initPromise=(async()=>{const c=config();if(!c.url||!c.key)throw new Error('Add your Supabase Project URL and publishable/anon key first.');
      if(!window.supabase?.createClient){await new Promise((resolve,reject)=>{const s=document.createElement('script');s.src='https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2';s.onload=resolve;s.onerror=()=>reject(new Error('Could not load the Supabase library. Check your internet connection.'));document.head.appendChild(s)})}
      client=window.supabase.createClient(c.url,c.key,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}});
      const {data,error}=await client.auth.getSession();if(error)throw error;user=data.session?.user||null;
      client.auth.onAuthStateChange((event,session)=>{user=session?.user||null;try{window.dispatchEvent(new CustomEvent('mp-auth-change',{detail:{event,user}}))}catch(ignore){}if(event==='PASSWORD_RECOVERY'){recoveryMode=true;renderAccountIfVisible()}else if(event==='SIGNED_OUT')renderAccountIfVisible()});
      return client;
    })();try{return await initPromise}catch(e){initPromise=null;throw e}
  }
  async function loadCloud(silent){if(!user||!client)return;try{const {data,error}=await client.from('medpocket_study_sync').select('payload,updated_at').eq('user_id',user.id).maybeSingle();if(error)throw error;if(data?.payload){mergeStudy(data.payload);lastSync=data.updated_at?Date.parse(data.updated_at):Date.now();if(typeof save==='function')save();}if(!silent)toast(data?.payload?'Study data downloaded and merged.':'No cloud copy yet. Your next sync will create one.');}catch(e){if(!silent)toast('Cloud download failed: '+e.message);}}
  async function pushCloud(silent){if(!user||!client){if(!silent)toast('Sign in to sync your study data.');return false}if(busy)return false;busy=true;try{const payload=studyPayload();const {error}=await client.from('medpocket_study_sync').upsert({user_id:user.id,payload,updated_at:new Date().toISOString()},{onConflict:'user_id'});if(error)throw error;lastSync=Date.now();if(!silent)toast('Study data synced to your account.');return true}catch(e){if(!silent)toast('Cloud upload failed: '+e.message);return false}finally{busy=false;}}
  function scheduleSync(){if(!user||!client)return;clearTimeout(syncTimer);syncTimer=setTimeout(()=>pushCloud(true),1800)}
  async function accountConnect(){try{await ensureClient();const {data,error}=await client.auth.getSession();if(error)throw error;user=data.session?.user||null;if(user)await loadCloud(true);renderAccountIfVisible();return true}catch(e){toast(e.message);return false}}
  async function signUp(){const email=$id('mp_email')?.value.trim(),password=$id('mp_password')?.value;if(!email||!password)return toast('Enter your email and a password.');if(password.length<8)return toast('Use a password with at least 8 characters.');try{await ensureClient();const {data,error}=await client.auth.signUp({email,password,options:{emailRedirectTo:authRedirect()}});if(error)throw error;user=data.session?.user||null;if(user){await loadCloud(true);await pushCloud(true);toast('Account created. Your study data is ready to sync.')}else toast('Check your email to confirm your account, then sign in.');renderAccountIfVisible()}catch(e){toast('Sign-up failed: '+e.message)}}
  async function signIn(){const email=$id('mp_email')?.value.trim(),password=$id('mp_password')?.value;if(!email||!password)return toast('Enter your email and password.');try{await ensureClient();const {data,error}=await client.auth.signInWithPassword({email,password});if(error)throw error;user=data.user;await loadCloud(true);await pushCloud(true);toast('Signed in. Study data is synchronised.');renderAccountIfVisible()}catch(e){toast('Sign-in failed: '+e.message)}}
  async function resetPassword(){const email=$id('mp_email')?.value.trim();if(!email)return toast('Enter your email address first.');try{await ensureClient();const {error}=await client.auth.resetPasswordForEmail(email,{redirectTo:authRedirect()});if(error)throw error;toast('Password reset email sent if the account exists.')}catch(e){toast('Could not send reset email: '+e.message)}}
  async function updatePassword(){const password=$id('mp_new_password')?.value;if(!password||password.length<8)return toast('Use a password with at least 8 characters.');try{const {error}=await client.auth.updateUser({password});if(error)throw error;recoveryMode=false;toast('Password updated successfully.');renderAccountIfVisible()}catch(e){toast('Could not update password: '+e.message)}}
  async function signOut(){if(!client)return;try{const {error}=await client.auth.signOut();if(error)throw error;user=null;toast('Signed out. Your local data remains on this device.');renderAccountIfVisible()}catch(e){toast('Sign-out failed: '+e.message)}}
  function configSave(){const url=$id('mp_sb_url')?.value.trim().replace(/\/$/,''),key=$id('mp_sb_key')?.value.trim();if(!url||!key)return toast('Enter both the Project URL and publishable/anon key.');if(!/^https:\/\/.+\.supabase\.co$/.test(url))return toast('Use the HTTPS Project URL shown in Supabase settings.');saveConfig({url,key});accountConnect().then(()=>{render();toast('Supabase connection settings saved on this device.')})}
  function accountHtml(){if(recoveryMode)return `<h2>Choose a new password</h2><div class="card"><label>New password</label><input class="in" id="mp_new_password" type="password" autocomplete="new-password" placeholder="At least 8 characters"><button class="btn" onclick="mpSupabaseUpdatePassword()">Update password</button></div>`;return `<h2>Account & Cloud Sync</h2><p class="mu">Use one MedPocket account to restore your study profile, notes, flashcards, MCQs, timetable, exam planner and study progress on another device.</p>
  <div class="card" style="margin-top:10px"><b>☁️ MedPocket cloud connection</b><p class="mu p">The secure connection is configured automatically. You do not need to enter a project URL or API key. Your account controls access to your own study data.</p></div>
  ${user?`<div class="card" style="margin-top:12px"><b>Signed in</b><p class="p">${esc2(user.email||'Account')}</p><p class="mu">Last sync: ${lastSync?new Date(lastSync).toLocaleString():'not yet synced'}</p><div class="row"><button class="btn" onclick="mpSupabaseSyncNow()">Sync now</button><button class="btn s" onclick="mpSupabaseSignOut()">Sign out</button></div></div>`:`<div class="card" style="margin-top:12px"><b>MedPocket account</b><label>Email</label><input class="in" id="mp_email" type="email" autocomplete="email" placeholder="you@example.com"><label>Password</label><input class="in" id="mp_password" type="password" autocomplete="current-password" placeholder="At least 8 characters"><button class="btn" style="width:100%;margin-top:8px" onclick="mpSupabaseSignIn()">Sign in</button><button class="btn s" style="width:100%;margin-top:8px" onclick="mpSupabaseSignUp()">Create account</button><button class="btn s" style="width:100%;margin-top:8px" onclick="mpSupabaseResetPassword()">Forgot password?</button></div>`}
  <div class="card" style="margin-top:12px"><b>What synchronises</b><p class="mu p">Student profile, study notes, flashcards, MCQs, tasks, timetable, exams, planner, study statistics, review progress, custom reference entries and study settings.</p><b>What stays on this device</b><p class="mu p">Patient logbook entries, patient-identifiable clinical information, clinical case records, uploaded documents, images, and local file attachments are excluded from cloud sync. Do not put identifiable patient information in study notes intended for sync.</p></div>`}
  window.mpSupabaseClient=ensureClient;window.mpSupabaseCurrentUser=()=>user;
  window.mpSupabaseSaveConfig=configSave;window.mpSupabaseSignUp=signUp;window.mpSupabaseSignIn=signIn;window.mpSupabaseResetPassword=resetPassword;window.mpSupabaseUpdatePassword=updatePassword;window.mpSupabaseSignOut=signOut;window.mpSupabaseSyncNow=()=>pushCloud(false);
  window.R=window.R||{};R.account=accountHtml;
  const menuItem=MENU.find(x=>x[0]==='App');if(menuItem&&!menuItem[1].some(x=>x[0]==='account'))menuItem[1].unshift(['account','☁️','Account & Cloud Sync']);
  window.cloudCard=()=>'';
  const oldSync=R.sync;R.sync=()=>oldSync()+`<div class="card" style="margin-top:12px"><b>Account-based cloud sync</b><p class="mu">Use Account & Cloud Sync for secure, per-user cloud storage. The file-based transfer above remains available as a manual offline transfer.</p><button class="btn" onclick="go('account')">Open account settings</button></div>`;
  // Replace the legacy JSONBin auto-sync path; no master keys or shared bins are used.
  window.cloudAuto=scheduleSync;
  const oldSave=window.save;window.save=function(){oldSave();scheduleSync()};
  function renderAccountIfVisible(){if(typeof cur!=='undefined'&&cur==='account'&&typeof render==='function')render()}
  // Attempt to restore an existing session when configuration is already present.
  window.mpSupabaseReady=navigator.onLine===false?Promise.resolve(false):accountConnect();
  window.addEventListener('online',()=>{if(!client)accountConnect()});
})();
