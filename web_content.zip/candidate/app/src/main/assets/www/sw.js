/* MedPocket service worker — offline cache + notifications */
const CACHE='medpocket-v19';
const CORE=['./','./index.html','./disease-data.js','./supabase-sync.js','./connect.js','./manifest.webmanifest','./icon.png','./icon-192.png','./icon-512.png','./icon-maskable-512.png','./icon.svg',
  './jdocs/index.html','./jdocs/css/app.css','./jdocs/js/icons.js','./jdocs/js/store.js','./jdocs/js/library.js','./jdocs/js/io.js',
  './jdocs/js/render.js','./jdocs/js/editor.js','./jdocs/js/outputs.js','./jdocs/js/engage.js',
  './jdocs/js/present.js','./jdocs/js/app.js','./jdocs/vendor/jszip.min.js','./jdocs/vendor/qrcode.js',
  './jdocs/fonts/selawik-regular.woff','./jdocs/fonts/selawik-bold.woff'];

self.addEventListener('install',e=>{self.skipWaiting();e.waitUntil(caches.open(CACHE).then(c=>c.addAll(CORE).catch(()=>{})))});
self.addEventListener('activate',e=>{e.waitUntil((async()=>{const ks=await caches.keys();await Promise.all(ks.filter(k=>k!==CACHE).map(k=>caches.delete(k)));await self.clients.claim()})())});
self.addEventListener('fetch',e=>{
  const req=e.request;
  if(req.method!=='GET')return;
  const url=new URL(req.url);
  if(url.origin!==location.origin)return;
  if(req.mode==='navigate'){
    e.respondWith((async()=>{try{const r=await fetch(req);const c=await caches.open(CACHE);c.put('./index.html',r.clone());return r}catch(x){const c=await caches.open(CACHE);return (await c.match('./index.html'))||(await c.match('./'))||Response.error()}})());
    return;
  }
  e.respondWith((async()=>{const c=await caches.open(CACHE);const m=await c.match(req);if(m)return m;try{const r=await fetch(req);if(r&&r.status===200)c.put(req,r.clone());return r}catch(x){return m||Response.error()}})());
});
self.addEventListener('message',e=>{
  const d=e.data||{};
  if(d.type==='notify'){
    self.registration.showNotification(d.title||'MedPocket',{body:d.body||'',tag:d.tag||'medpocket',icon:'icon.png',badge:'icon.png'});
  }
});
self.addEventListener('notificationclick',e=>{
  e.notification.close();
  e.waitUntil((async()=>{const cs=await self.clients.matchAll({type:'window',includeUncontrolled:true});for(const c of cs){if('focus'in c){c.focus();return}}if(self.clients.openWindow)return self.clients.openWindow('./')})());
});
