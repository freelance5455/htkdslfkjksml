#!/usr/bin/env sh
# شغّله بعد: npx cap add android  (يضيف صلاحية الصور لملف AndroidManifest)
set -eu
M="android/app/src/main/AndroidManifest.xml"
[ -f "$M" ] || { echo "AndroidManifest.xml not found. Run: npx cap add android first"; exit 1; }
add() { grep -q "$1" "$M" || sed -i "s#<application#$2\n    <application#" "$M"; }
add "READ_MEDIA_IMAGES" '    <uses-permission android:name="android.permission.READ_MEDIA_IMAGES" />'
add "READ_EXTERNAL_STORAGE" '    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />'
echo "Photo permissions added to $M"
