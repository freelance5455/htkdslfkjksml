# OLC Learning Android App

This is a separate Android client for the OLC WEB PHP/MySQL platform.

## Online mode
The app opens the existing OLC website at:
https://OLCplatform.byethost16.com/

It therefore uses the same accounts, lessons, questions, CBTs and progress as the web application.

## Offline mode
When there is no internet, the app opens its offline learning shell. Android WebView storage/cache is retained between launches. The next phase should add server-backed content synchronization for lessons/questions and a local SQLite/Room question bank if full offline CBT is required.

## Build
Open this folder in Android Studio with Android SDK 35 installed, then Build > Generate App Bundle(s) / APK(s) > Generate APK(s).
