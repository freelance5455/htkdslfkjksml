package com.olc.learning;

import android.app.Activity;
import android.os.Bundle;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.webkit.CookieManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.view.Window;
import android.view.WindowManager;
import android.content.Context;
import android.graphics.Color;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final String BASE = "https://OLCplatform.byethost16.com/";
    private WebView web;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        Window w=getWindow(); w.setStatusBarColor(Color.rgb(11,19,36));
        web=new WebView(this); setContentView(web);
        WebSettings s=web.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setSupportZoom(false); s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setCacheMode(WebSettings.LOAD_DEFAULT);
        CookieManager.getInstance().setAcceptCookie(true); CookieManager.getInstance().setAcceptThirdPartyCookies(web,true);
        web.setWebViewClient(new OLCClient());
        if (online()) web.loadUrl(BASE); else loadOffline();
    }
    private boolean online(){ ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE); Network n=cm.getActiveNetwork(); if(n==null)return false; NetworkCapabilities c=cm.getNetworkCapabilities(n); return c!=null && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET); }
    private void loadOffline(){ web.loadUrl("file:///android_asset/offline.html"); }
    @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
    private class OLCClient extends WebViewClient {
      @Override public void onReceivedError(WebView v, int errorCode, String desc, String failingUrl){ if(!online()) loadOffline(); }
      @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r){ return super.shouldInterceptRequest(v,r); }
    }
}
