# iOS 5-inspired Lock Screen (HTML + Android WebView)

The lock-screen UI is implemented in `app/src/main/assets/ios5-lockscreen.html` (HTML/CSS/JavaScript). Android's `MainActivity` loads that local asset in a fullscreen WebView.

## Build APK locally
Open this folder in Android Studio, allow Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The output is `app/build/outputs/apk/debug/app-debug.apk`.

## Cloud build
The GitHub Actions workflow at `.github/workflows/build-apk.yml` builds the APK on GitHub-hosted Ubuntu. Push this project to a GitHub repository, then open **Actions**, run **Build iOS 5 Lock Screen APK**, and download the `iOS5LockScreen-debug-apk` artifact from a successful run.

## Install
Transfer `app-debug.apk` to the Android phone and install it. Allow installation from the source app if Android prompts.

## Security limitation
This is a fullscreen lock-screen-style app/demo, not a replacement for Android/OxygenOS secure keyguard. A regular app cannot replace the secure PIN/fingerprint lock screen. Your phone's real lock security remains unchanged.
