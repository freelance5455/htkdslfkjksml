package com.example.ios5lockscreen;

import android.content.Context;
import android.graphics.*;
import android.view.MotionEvent;
import android.view.View;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class LockScreenView extends View {
    private final Paint p = new Paint(3);
    private final RectF slider = new RectF();
    private float downX, offset = 0;
    private boolean unlocked = false;
    private final float density;
    public LockScreenView(Context c) { super(c); density=getResources().getDisplayMetrics().density; setLayerType(View.LAYER_TYPE_SOFTWARE,null); }
    float d(float v){ return v*density; }
    void text(Canvas c,String s,float x,float y,float size,int color,Paint.Align a, boolean shadow){
        p.reset(); p.setAntiAlias(true); p.setColor(color); p.setTextSize(d(size)); p.setTextAlign(a);
        p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));
        if(shadow)p.setShadowLayer(d(4),0,d(2),0x99000000); c.drawText(s,x,y,p); p.clearShadowLayer();
    }
    @Override protected void onDraw(Canvas c) {
        float w=getWidth(), h=getHeight();
        // Deep blue iOS 5-inspired glossy wallpaper, drawn locally (no network image required).
        p.setShader(new LinearGradient(0,0,w,h, new int[]{0xFF071C3C,0xFF12618B,0xFF06152D},null,Shader.TileMode.CLAMP));
        c.drawRect(0,0,w,h,p); p.setShader(null);
        p.setShader(new RadialGradient(w*.5f,h*.32f,w*.72f,new int[]{0x887BD9FF,0x223AA5D8,0x00000000},null,Shader.TileMode.CLAMP));
        c.drawRect(0,0,w,h,p); p.setShader(null);
        // Subtle water-drop highlights.
        for(int i=0;i<46;i++){
            float x=(float)((i*83+31)%Math.max(1,(int)w)), y=(float)((i*137+59)%Math.max(1,(int)h));
            float r=d(2+(i%5)*1.1f);
            p.setColor(0x22FFFFFF); p.setStyle(Paint.Style.FILL); c.drawCircle(x,y,r,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(d(1)); p.setColor(0x55BDEBFF); c.drawCircle(x-r*.2f,y-r*.2f,r,p); p.setStyle(Paint.Style.FILL);
        }
        // iOS 5 style status bar
        text(c,"●●●  Carrier",d(12),d(24),12,Color.WHITE,Paint.Align.LEFT,true);
        text(c,"Wi-Fi",w-d(58),d(24),11,Color.WHITE,Paint.Align.LEFT,true);
        p.setColor(Color.WHITE); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(d(1.5f));
        c.drawRoundRect(w-d(31),d(12),w-d(9),d(23),d(3),d(3),p);
        p.setStyle(Paint.Style.FILL); c.drawRect(w-d(7),d(16),w-d(5),d(20),p); c.drawRect(w-d(28),d(15),w-d(13),d(20),p);
        String time=new SimpleDateFormat("h:mm",Locale.getDefault()).format(new Date());
        String date=new SimpleDateFormat("EEEE, MMMM d",Locale.getDefault()).format(new Date());
        text(c,time,w/2,h*.235f,76,Color.WHITE,Paint.Align.CENTER,true);
        text(c,date,w/2,h*.275f,19,Color.WHITE,Paint.Align.CENTER,true);
        // lock glyph
        p.setColor(0xCCFFFFFF); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(d(2.2f));
        c.drawArc(w/2-d(8),h*.335f,w/2+d(8),h*.365f,180,180,false,p);
        p.setStyle(Paint.Style.FILL); c.drawRoundRect(w/2-d(12),h*.352f,w/2+d(12),h*.382f,d(4),d(4),p);
        // Slider tray
        float trayW=w-d(34), trayH=d(54), trayX=d(17), trayY=h-d(105);
        p.setColor(0xAA101820); c.drawRoundRect(trayX,trayY,trayX+trayW,trayY+trayH,d(12),d(12),p);
        p.setColor(0xFFB8C6CE); p.setTextSize(d(17)); p.setTextAlign(Paint.Align.CENTER);
        c.drawText(unlocked?"Unlocked":"slide to unlock",w/2,trayY+d(34),p);
        float knobX=Math.min(trayX+trayW-d(45),Math.max(trayX+d(5),trayX+d(5)+offset));
        p.setShader(new LinearGradient(0,trayY+d(5),0,trayY+d(49),0xFFF9FFFF,0xFF8EA5B7,Shader.TileMode.CLAMP));
        c.drawRoundRect(knobX,trayY+d(5),knobX+d(42),trayY+d(49),d(9),d(9),p); p.setShader(null);
        p.setColor(0xFF456477); p.setTextSize(d(28)); c.drawText("›",knobX+d(21),trayY+d(36),p);
        if(unlocked){
            p.setColor(0x99000000); c.drawRect(0,0,w,h,p);
            text(c,"Welcome",w/2,h*.48f,34,Color.WHITE,Paint.Align.CENTER,true);
            text(c,"iOS 5-inspired lock screen demo",w/2,h*.52f,16,Color.WHITE,Paint.Align.CENTER,true);
            text(c,"Tap anywhere to return",w/2,h*.57f,14,Color.WHITE,Paint.Align.CENTER,true);
        }
    }
    @Override public boolean onTouchEvent(MotionEvent e){
        float w=getWidth(),h=getHeight(), trayY=h-d(105), trayX=d(17), trayW=w-d(34);
        if(unlocked){ if(e.getAction()==MotionEvent.ACTION_UP){unlocked=false;offset=0;invalidate();} return true; }
        switch(e.getAction()){
            case MotionEvent.ACTION_DOWN: downX=e.getX(); return true;
            case MotionEvent.ACTION_MOVE:
                if(e.getY()>trayY-d(15)){offset=Math.max(0,Math.min(trayW-d(55),e.getX()-downX));invalidate();} return true;
            case MotionEvent.ACTION_UP:
                if(offset>trayW*.55f){unlocked=true;Toast.makeText(getContext(),"Demo unlocked",Toast.LENGTH_SHORT).show();}
                offset=0;invalidate();return true;
        } return true;
    }
}
