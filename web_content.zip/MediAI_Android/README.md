# MediAI Android starter app

Native Android project built with Kotlin and Jetpack Compose.

## Included in this starter
- Offline starter library for selected medicines
- Human body and organ basics
- Science and medical science topics: cells, genetics, microbes, immune system, imaging and pharmacology
- Selected diseases and conditions
- Surgery education
- Hospital departments and services
- A reminder-note screen for schedules already provided by a clinician
- Medical safety notices

## Offline and online plan
This version's included reference entries work offline. It does not yet contain a connected AI service, live medical database updates, a complete drug catalogue, persistent reminders, or timed notifications. These need to be added and tested as separate features. Online AI should use a secure backend; never embed a private API key in the APK. The offline library should use a versioned, reviewed medical dataset that can be updated when internet is available.

## Safety
This is an educational starter, not a diagnostic or prescribing tool. It must not independently choose medicines or doses. Medicine information should be verified against reliable, current references and reviewed by qualified professionals. For emergencies, seek urgent local medical care.

## Build APK
1. Open the project in Android Studio on a computer with the Android SDK installed.
2. Allow Gradle sync and install requested SDK components.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Android Studio will show the APK output path, usually `app/build/outputs/apk/debug/app-debug.apk`.
