package com.example.mediai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF12364A)
private val Teal = Color(0xFF087F8C)
private val Pale = Color(0xFFF3F7F8)

data class Entry(val name: String, val category: String, val use: String, val notes: String)

private val medicines = listOf(
    Entry("Paracetamol (acetaminophen)", "Pain / fever", "Used to reduce fever and relieve mild to moderate pain.", "Too much can seriously harm the liver. Check labels carefully because combination cold/flu products may also contain paracetamol. Follow the package or clinician's instructions."),
    Entry("Ibuprofen", "Pain / inflammation", "A non-steroidal anti-inflammatory medicine (NSAID) used for pain, fever and inflammation.", "May not be suitable for people with stomach ulcers, kidney problems, dehydration, some asthma conditions, or certain other medicines. Ask a pharmacist or clinician before use."),
    Entry("Cetirizine", "Allergy", "An antihistamine used to relieve allergy symptoms such as sneezing, itchy eyes and a runny nose.", "Can cause sleepiness in some people. Check age suitability, other medicines and the product label with a pharmacist."),
    Entry("Amoxicillin", "Antibiotic", "A prescription antibiotic used for certain bacterial infections.", "Does not treat viral infections such as colds or flu. Use only when prescribed and follow the prescriber's directions; do not share or use leftover antibiotics."),
    Entry("Omeprazole", "Stomach acid", "Reduces stomach acid and is used for some acid-related conditions.", "The right use and duration depend on the reason for taking it. Ask a clinician or pharmacist, especially if symptoms persist.")
)

private val topics = listOf(
    Entry("Gallstones", "Condition", "Hardened deposits that form in the gallbladder.", "Some cause no symptoms; others cause abdominal pain or complications. Sudden severe pain, fever, yellow skin/eyes or persistent vomiting need urgent medical care."),
    Entry("Appendicitis", "Condition", "Inflammation of the appendix that usually needs urgent assessment.", "Worsening abdominal pain, especially with fever, vomiting or marked tenderness, needs urgent medical evaluation.")
)

private val anatomy = listOf(
    Entry("Heart", "Organ", "Pumps blood around the body, delivering oxygen and nutrients.", "Chest pain, fainting or difficulty breathing can be emergencies. Seek urgent help for concerning symptoms."),
    Entry("Lungs", "Organs", "Bring oxygen into the blood and remove carbon dioxide.", "Severe breathing difficulty, blue lips or inability to speak normally needs emergency help."),
    Entry("Liver", "Organ", "Processes nutrients, makes bile and helps break down many substances.", "Yellow skin or eyes, confusion or severe abdominal symptoms need medical assessment."),
    Entry("Kidneys", "Organs", "Filter waste and extra fluid from the blood and help regulate salts and blood pressure.", "Changes in urination or swelling should be discussed with a healthcare professional.")
)

private val science = listOf(
    Entry("Cells", "Basic biology", "Cells are the basic structural and functional units of living things.", "Different cell types have specialized roles. This is an educational overview, not a substitute for a biology textbook or clinical advice."),
    Entry("DNA and genes", "Genetics", "DNA stores inherited biological instructions; genes are sections of DNA that influence how cells function.", "Genetic traits are complex and often involve many genes and environmental factors."),
    Entry("Bacteria and viruses", "Microbiology", "Bacteria are single-celled organisms; viruses need host cells to reproduce.", "Antibiotics treat certain bacterial infections, not viral infections. A clinician decides whether treatment is needed."),
    Entry("Immune system", "Human biology", "A network of cells, tissues and organs that helps protect the body from infections and other threats.", "Immune responses can be complex. Persistent or severe symptoms should be assessed by a healthcare professional."),
    Entry("Medical imaging", "Medical technology", "X-rays, ultrasound, CT and MRI help clinicians examine structures inside the body.", "The appropriate scan depends on the clinical question; each method has different benefits and limitations."),
    Entry("Pharmacology", "Medical science", "The science of how medicines work in the body, including their effects and how the body processes them.", "Medicine choice and dose depend on individual factors and must be guided by a qualified professional.")
)

private val hospitals = listOf(
    Entry("Emergency department", "Hospital service", "Provides urgent assessment and treatment for serious or potentially life-threatening problems.", "For an emergency, contact local emergency services or go to the nearest emergency department."),
    Entry("Outpatient department (OPD)", "Hospital service", "Provides appointments, assessments and follow-up without an overnight hospital stay.", "Bring relevant reports and a current list of medicines to appointments."),
    Entry("Intensive care unit (ICU)", "Hospital service", "Provides close monitoring and advanced support for people who are critically ill.", "Care is provided by a specialist multidisciplinary team."),
    Entry("Operating theatre", "Hospital service", "A specialized area where surgical procedures are performed by trained teams.", "The surgical team explains consent, preparation, risks and recovery."),
    Entry("Laboratory", "Hospital service", "Tests blood, urine, tissue and other samples to help investigate health conditions.", "Results need interpretation alongside symptoms and clinical history."),
    Entry("Radiology department", "Hospital service", "Uses imaging such as X-ray, ultrasound, CT and MRI to help diagnose and monitor conditions.", "A clinician chooses imaging based on the person's needs.")
)

private val surgery = listOf(
    Entry("Before surgery", "Surgery guide", "The care team explains the reason for surgery, benefits, risks, alternatives and preparation.", "Only follow fasting and medicine instructions given by the surgical team. Never stop prescribed medicines without asking them."),
    Entry("Anaesthesia", "Surgery guide", "Medicines used by trained professionals to prevent pain and, in some cases, make a person unconscious during an operation.", "The anaesthesia team checks health, allergies and medicines and explains the plan."),
    Entry("Recovery", "Surgery guide", "Recovery depends on the operation and the person's health.", "Follow the discharge instructions. Seek urgent advice for trouble breathing, chest pain, heavy bleeding, fainting, high fever or rapidly worsening symptoms.")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MediAIApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MediAIApp() {
    var selected by remember { mutableStateOf("Home") }
    var query by remember { mutableStateOf("") }
    var selectedEntry by remember { mutableStateOf<Entry?>(null) }
    val tabs = listOf("Home", "Medicines", "Body", "Science", "Diseases", "Surgery", "Hospitals", "Reminders")
    MaterialTheme(
        colorScheme = lightColorScheme(primary = Teal, secondary = Navy, background = Pale, surface = Color.White)
    ) {
        Scaffold(
            containerColor = Pale,
            topBar = {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.MedicalServices, null, tint = Teal)
                            Spacer(Modifier.width(9.dp))
                            Column {
                                Text("MediAI", fontWeight = FontWeight.Bold, color = Navy)
                                Text("Medical knowledge assistant", fontSize = 11.sp, color = Color.Gray)
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    val icons = listOf(Icons.Default.Home, Icons.Default.Medication, Icons.Default.Accessibility, Icons.Default.Science, Icons.Default.HealthAndSafety, Icons.Default.MedicalInformation, Icons.Default.LocalHospital, Icons.Default.Notifications)
                    tabs.forEachIndexed { index, tab ->
                        NavigationBarItem(
                            selected = selected == tab,
                            onClick = { selected = tab; query = ""; selectedEntry = null },
                            icon = { Icon(icons[index], contentDescription = tab) },
                            label = { Text(tab, fontSize = 9.sp) }
                        )
                    }
                }
            }
        ) { padding ->
            if (selectedEntry != null) {
                EntryDetail(selectedEntry!!, Modifier.padding(padding)) { selectedEntry = null }
            } else {
                when (selected) {
                    "Home" -> HomeScreen(Modifier.padding(padding), onNavigate = { selected = it })
                    "Medicines" -> SearchScreen("Medicine encyclopedia", medicines, query, { query = it }, Modifier.padding(padding)) { selectedEntry = it }
                    "Body" -> SearchScreen("Human body", anatomy, query, { query = it }, Modifier.padding(padding)) { selectedEntry = it }
                    "Science" -> SearchScreen("Science & medical science", science, query, { query = it }, Modifier.padding(padding)) { selectedEntry = it }
                    "Diseases" -> SearchScreen("Diseases & conditions", topics, query, { query = it }, Modifier.padding(padding)) { selectedEntry = it }
                    "Hospitals" -> SearchScreen("Hospitals & departments", hospitals, query, { query = it }, Modifier.padding(padding)) { selectedEntry = it }
                    "Surgery" -> SearchScreen("Surgery guide", surgery, query, { query = it }, Modifier.padding(padding)) { selectedEntry = it }
                    "Reminders" -> ReminderScreen(Modifier.padding(padding))
                }
            }
        }
    }
}

@Composable
fun HomeScreen(modifier: Modifier, onNavigate: (String) -> Unit) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("Understand health with clear information.", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Navy)
        Spacer(Modifier.height(6.dp))
        Text("Explore the starter medical library. Search a topic to learn the basics.", color = Color.DarkGray)
        Spacer(Modifier.height(18.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Navy), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(18.dp)) {
                Text("Your health, explained.", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text("Medicine facts • Body systems • Conditions • Surgery", color = Color(0xFFD5E8ED))
                Spacer(Modifier.height(12.dp))
                Text("This starter version works offline. It is an educational library, not an AI doctor.", color = Color.White, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("Explore", fontWeight = FontWeight.Bold, color = Navy, fontSize = 18.sp)
        val items = listOf("Medicines" to "Medicine uses, cautions and side effects", "Body" to "Learn about organs and their functions", "Science" to "Biology, genetics, microbiology and medical science", "Diseases" to "Understand common health conditions", "Surgery" to "Preparation, anaesthesia and recovery", "Hospitals" to "Hospital departments, services and care teams", "Reminders" to "Create a personal reminder from clinician instructions")
        items.forEach { (name, desc) ->
            Card(Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable { onNavigate(name) }, colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.ArrowForward, null, tint = Teal)
                    Spacer(Modifier.width(12.dp))
                    Column { Text(name, fontWeight = FontWeight.SemiBold, color = Navy); Text(desc, fontSize = 12.sp, color = Color.Gray) }
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        SafetyNote()
    }
}

@Composable
fun SearchScreen(title: String, entries: List<Entry>, query: String, onQuery: (String) -> Unit, modifier: Modifier, onSelect: (Entry) -> Unit) {
    val filtered = entries.filter { (it.name + it.category + it.use).contains(query, ignoreCase = true) }
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text(title, fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Navy)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(value = query, onValueChange = onQuery, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Search...") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(filtered) { entry ->
                Card(Modifier.fillMaxWidth().clickable { onSelect(entry) }, colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.padding(15.dp)) {
                        Text(entry.name, fontWeight = FontWeight.Bold, color = Navy)
                        Text(entry.category, color = Teal, fontSize = 12.sp)
                        Text(entry.use, color = Color.DarkGray, fontSize = 13.sp, maxLines = 2)
                    }
                }
            }
            if (filtered.isEmpty()) item { Text("No matching entry in this starter library yet.", color = Color.Gray) }
        }
    }
}

@Composable
fun EntryDetail(entry: Entry, modifier: Modifier, onBack: () -> Unit) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        TextButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null); Text("Back") }
        Text(entry.name, fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Navy)
        Text(entry.category, color = Teal)
        Spacer(Modifier.height(18.dp))
        Text("What it is / what it is used for", fontWeight = FontWeight.Bold, color = Navy)
        Text(entry.use, modifier = Modifier.padding(top = 6.dp))
        Spacer(Modifier.height(18.dp))
        Text("Important notes", fontWeight = FontWeight.Bold, color = Navy)
        Text(entry.notes, modifier = Modifier.padding(top = 6.dp))
        Spacer(Modifier.height(20.dp))
        SafetyNote()
    }
}

@Composable
fun ReminderScreen(modifier: Modifier) {
    var medicine by remember { mutableStateOf("") }
    var instructions by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf(false) }
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("Medicine reminders", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Navy)
        Text("Enter only the schedule already given by your doctor or pharmacist.", color = Color.DarkGray)
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(value = medicine, onValueChange = { medicine = it; saved = false }, label = { Text("Medicine name") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = instructions, onValueChange = { instructions = it; saved = false }, label = { Text("Prescribed instructions / reminder note") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
        Spacer(Modifier.height(12.dp))
        Button(onClick = { saved = medicine.isNotBlank() && instructions.isNotBlank() }, enabled = medicine.isNotBlank() && instructions.isNotBlank()) { Text("Save reminder note") }
        if (saved) Text("Saved on this screen: $medicine — $instructions", color = Teal, modifier = Modifier.padding(top = 12.dp))
        Text("This first version does not send timed notifications or store entries after closing the app.", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(top = 16.dp))
        Spacer(Modifier.height(16.dp))
        SafetyNote()
    }
}

@Composable
fun SafetyNote() {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF4DE)), shape = RoundedCornerShape(12.dp)) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.Top) {
            Icon(Icons.Default.Warning, null, tint = Color(0xFF9A5B00))
            Spacer(Modifier.width(8.dp))
            Text("Safety: This app is for learning, not diagnosis or prescribing. Never start, stop, combine or change a medicine or dose based only on this app. Ask a qualified clinician or pharmacist. For an emergency, seek urgent local medical help.", fontSize = 12.sp, color = Color(0xFF5D451F))
        }
    }
}
