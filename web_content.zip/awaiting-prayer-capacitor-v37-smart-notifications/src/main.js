import { Capacitor } from "@capacitor/core";
import { App } from "@capacitor/app";
import { LocalNotifications } from "@capacitor/local-notifications";

// The app’s classic scripts use this explicit bridge.
window.AWPCapacitor = Capacitor;
window.AWPApp = App;
window.AWPNotifications = LocalNotifications;
window.dispatchEvent(new CustomEvent("awp:native-ready"));
