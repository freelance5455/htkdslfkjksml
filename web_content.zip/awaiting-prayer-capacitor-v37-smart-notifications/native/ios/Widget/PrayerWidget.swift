import WidgetKit
import SwiftUI

private let awpGroup = "group.com.sanastudio.waitingforprayer"
private let awpKeys = ["fajr", "dhuhr", "asr", "maghrib", "isha"]
private let awpPrayerWindow: TimeInterval = 20 * 60

struct AWPPrayerItem: Identifiable {
    let key: String
    let prayer: String
    let time: String
    let timestamp: Double
    let day: String
    var id: String { "\(day)-\(key)" }
    var date: Date { Date(timeIntervalSince1970: timestamp / 1000) }
}

struct AWPPrayerEntry: TimelineEntry {
    let date: Date
    let prayer: String
    let key: String
    let time: String
    let nextDate: Date
    let lang: String
    let prayers: [AWPPrayerItem]
    let active: Bool
}

private enum AWPData {
    static func read(at now: Date = Date()) -> AWPPrayerEntry {
        let defaults = UserDefaults(suiteName: awpGroup)
        let raw = defaults?.array(forKey: "prayers") as? [[String: Any]] ?? []
        let items: [AWPPrayerItem] = raw.compactMap { item in
            guard let name = item["prayer"] as? String,
                  let time = item["time"] as? String,
                  let ts = (item["ts"] as? NSNumber)?.doubleValue else { return nil }
            let key = item["key"] as? String ?? ""
            let day = item["day"] as? String ?? ""
            return AWPPrayerItem(key: key, prayer: name, time: time, timestamp: ts, day: day)
        }

        var candidates = items
        if let previous = defaults?.dictionary(forKey: "previousIsha"),
           let ts = (previous["ts"] as? NSNumber)?.doubleValue,
           let name = previous["prayer"] as? String,
           let time = previous["time"] as? String {
            candidates.append(AWPPrayerItem(key: "isha", prayer: name, time: time, timestamp: ts, day: previous["day"] as? String ?? ""))
        }

        let nowMs = now.timeIntervalSince1970 * 1000
        let activeItem = candidates
            .filter { $0.timestamp <= nowMs && nowMs < $0.timestamp + awpPrayerWindow * 1000 }
            .max { $0.timestamp < $1.timestamp }
        let upcomingItem = candidates
            .filter { $0.timestamp > nowMs }
            .min { $0.timestamp < $1.timestamp }
        let selected = activeItem ?? upcomingItem
        let isActive = activeItem != nil
        let selectedDay = selected?.day ?? items.first?.day ?? ""
        let selectedDayItems = items.filter { selectedDay.isEmpty || $0.day == selectedDay }
        let todayKey = defaults?.string(forKey: "todayKey") ?? ""
        let todayItems = items.filter { !todayKey.isEmpty && $0.day == todayKey }
        // If the selected prayer is yesterday's Isha around midnight, keep today's five rows visible.
        let dailyItems = selectedDayItems.isEmpty ? (todayItems.isEmpty ? items : todayItems) : selectedDayItems
        let targetDate: Date
        if let selected = selected {
            targetDate = selected.date.addingTimeInterval(isActive ? awpPrayerWindow : 0)
        } else {
            targetDate = now.addingTimeInterval(3600)
        }

        return AWPPrayerEntry(
            date: now,
            prayer: selected?.prayer ?? defaults?.string(forKey: "prayer") ?? "Open app",
            key: selected?.key ?? defaults?.string(forKey: "key") ?? "fajr",
            time: selected?.time ?? defaults?.string(forKey: "time") ?? "--:--",
            nextDate: targetDate,
            lang: defaults?.string(forKey: "lang") ?? "en",
            prayers: dailyItems,
            active: isActive
        )
    }
}

struct AWPPrayerProvider: TimelineProvider {
    func placeholder(in context: Context) -> AWPPrayerEntry {
        AWPPrayerEntry(date: Date(), prayer: "الفجر", key: "fajr", time: "05:00", nextDate: Date().addingTimeInterval(3600), lang: "ar", prayers: [], active: false)
    }
    func getSnapshot(in context: Context, completion: @escaping (AWPPrayerEntry) -> Void) { completion(AWPData.read()) }
    func getTimeline(in context: Context, completion: @escaping (Timeline<AWPPrayerEntry>) -> Void) {
        let now = Date()
        let current = AWPData.read(at: now)
        if current.nextDate > now.addingTimeInterval(1) {
            // Give WidgetKit a second entry for the prayer-start or 20-minute-window boundary.
            let transitionDate = current.nextDate.addingTimeInterval(2)
            let transition = AWPData.read(at: transitionDate)
            completion(Timeline(entries: [current, transition], policy: .after(transitionDate.addingTimeInterval(30))))
        } else {
            completion(Timeline(entries: [current], policy: .after(now.addingTimeInterval(1800))))
        }
    }
}

private func awpText(_ entry: AWPPrayerEntry, ar: String, en: String, tr: String, fr: String) -> String {
    switch entry.lang { case "ar": return ar; case "tr": return tr; case "fr": return fr; default: return en }
}

private struct AWPScenePreview: View {
    let key: String
    var body: some View {
        ZStack {
            Image("Prayer_\(key)").resizable().scaledToFill().blur(radius: 9).opacity(0.55)
            Image("Prayer_\(key)").resizable().scaledToFit().padding(3)
        }
        .background(Color(red: 0.06, green: 0.10, blue: 0.11))
        .clipShape(RoundedRectangle(cornerRadius: 9, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 9, style: .continuous).stroke(.white.opacity(0.12), lineWidth: 1))
    }
}

struct AWPPrayerWidgetView: View {
    let entry: AWPPrayerEntry
    var body: some View {
        HStack(spacing: 10) {
            VStack(alignment: .leading, spacing: 5) {
                HStack(spacing: 6) {
                    Image(systemName: "moon.stars.fill").foregroundColor(Color(red: 0.80, green: 0.92, blue: 0.55))
                    Text(awpText(entry, ar: entry.active ? "حان وقت الصلاة" : "الصلاة القادمة", en: entry.active ? "PRAYER TIME NOW" : "NEXT PRAYER", tr: entry.active ? "NAMAZ VAKTİ" : "SIRADAKİ NAMAZ", fr: entry.active ? "HEURE DE PRIÈRE" : "PROCHAINE PRIÈRE"))
                        .font(.system(size: 9, weight: .bold, design: .rounded)).foregroundColor(.white.opacity(0.78))
                }
                Text(entry.prayer).font(.system(size: 19, weight: .bold, design: .rounded)).foregroundColor(.white).lineLimit(2).minimumScaleFactor(0.72)
                Text(entry.time).font(.system(size: 25, weight: .bold, design: .rounded)).foregroundColor(Color(red: 0.82, green: 0.94, blue: 0.56)).monospacedDigit()
                HStack(spacing: 4) {
                    Text(awpText(entry, ar: entry.active ? "المتبقي من مؤقت الأداء" : "المتبقي", en: entry.active ? "PRAYER TIMER LEFT" : "LEFT", tr: entry.active ? "KALAN SÜRE" : "KALAN", fr: entry.active ? "MINUTEUR RESTANT" : "RESTANT"))
                        .font(.system(size: 8, weight: .medium)).foregroundColor(.white.opacity(0.68))
                    Text(entry.nextDate, style: .timer).font(.system(size: 11, weight: .bold, design: .rounded)).foregroundColor(Color(red: 0.82, green: 0.94, blue: 0.56)).monospacedDigit()
                }
            }
            Spacer(minLength: 0)
            AWPScenePreview(key: entry.key).frame(width: 88, height: 92)
        }
        .padding(12)
        .background(LinearGradient(colors: [Color(red: 0.09, green: 0.15, blue: 0.18), Color(red: 0.16, green: 0.27, blue: 0.25), Color(red: 0.20, green: 0.29, blue: 0.18)], startPoint: .topLeading, endPoint: .bottomTrailing))
        .widgetURL(URL(string: "awaitingprayer://prayer?key=\(entry.key)"))
    }
}

private struct AWPAllPrayersWidgetView: View {
    let entry: AWPPrayerEntry
    private let fallback = ["Fajr", "Dhuhr", "Asr", "Maghrib", "Isha"]
    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            HStack(spacing: 6) {
                Image(systemName: "moon.stars.fill").foregroundColor(Color(red: 0.80, green: 0.92, blue: 0.55))
                Text(awpText(entry, ar: entry.active ? "حان وقت الصلاة" : "مواقيت الصلوات الخمس", en: entry.active ? "PRAYER TIME NOW" : "THE FIVE DAILY PRAYERS", tr: entry.active ? "NAMAZ VAKTİ" : "BEŞ VAKİT NAMAZ", fr: entry.active ? "HEURE DE PRIÈRE" : "LES CINQ PRIÈRES"))
                    .font(.system(size: 9, weight: .bold, design: .rounded)).foregroundColor(.white.opacity(0.82))
                Spacer(minLength: 0)
                Text("SANA").font(.system(size: 8, weight: .bold, design: .rounded)).foregroundColor(.white.opacity(0.55))
            }
            HStack(spacing: 4) {
                Text(awpText(entry, ar: entry.active ? "المتبقي من مؤقت الأداء" : "المتبقي", en: entry.active ? "PRAYER TIMER LEFT" : "NEXT IN", tr: entry.active ? "KALAN SÜRE" : "KALAN", fr: entry.active ? "MINUTEUR RESTANT" : "DANS"))
                    .font(.system(size: 8, weight: .medium)).foregroundColor(.white.opacity(0.68))
                Text(entry.nextDate, style: .timer).font(.system(size: 10, weight: .bold, design: .rounded)).foregroundColor(Color(red: 0.82, green: 0.94, blue: 0.56)).monospacedDigit()
            }
            ForEach(0..<5, id: \.self) { index in
                let item = index < entry.prayers.count ? entry.prayers.first(where: { $0.key == awpKeys[index] }) : nil
                Link(destination: URL(string: "awaitingprayer://prayer?key=\(item?.key ?? awpKeys[index])")!) {
                    HStack(spacing: 8) {
                        AWPScenePreview(key: item?.key ?? awpKeys[index]).frame(width: 46, height: 36)
                        Text(item?.prayer ?? fallback[index]).font(.system(size: 11, weight: .semibold, design: .rounded)).foregroundColor(.white).lineLimit(1)
                        Spacer(minLength: 4)
                        Text(item?.time ?? "--:--").font(.system(size: 12, weight: .bold, design: .rounded)).monospacedDigit().foregroundColor(Color(red: 0.82, green: 0.94, blue: 0.56))
                    }
                    .padding(.horizontal, 5).padding(.vertical, 2)
                    .background(item?.key == entry.key ? Color(red: 0.29, green: 0.39, blue: 0.17).opacity(0.7) : Color.white.opacity(0.045))
                    .clipShape(RoundedRectangle(cornerRadius: 6, style: .continuous))
                }.buttonStyle(.plain)
            }
            Text(awpText(entry, ar: "اضغط لفتح الصلاة ومشهدها", en: "Tap to open the prayer scene", tr: "Namaz sahnesini açmak için dokunun", fr: "Touchez pour ouvrir la scène de prière"))
                .font(.system(size: 8, weight: .medium)).foregroundColor(.white.opacity(0.68)).lineLimit(1)
        }
        .padding(10)
        .background(LinearGradient(colors: [Color(red: 0.09, green: 0.15, blue: 0.18), Color(red: 0.16, green: 0.27, blue: 0.25), Color(red: 0.20, green: 0.29, blue: 0.18)], startPoint: .topLeading, endPoint: .bottomTrailing))
        .widgetURL(URL(string: "awaitingprayer://home"))
    }
}

struct AWPPrayerWidget: Widget {
    let kind = "AWPPrayerWidget"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: AWPPrayerProvider()) { entry in AWPPrayerWidgetView(entry: entry) }
            .configurationDisplayName("Next prayer")
            .description("Shows the active prayer's 20-minute focus timer or the next prayer.")
            .supportedFamilies([.systemMedium, .systemLarge])
    }
}

struct AWPAllPrayersWidget: Widget {
    let kind = "AWPAllPrayersWidget"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: AWPPrayerProvider()) { entry in AWPAllPrayersWidgetView(entry: entry) }
            .configurationDisplayName("All five prayers")
            .description("All five prayer times with the active prayer highlighted.")
            .supportedFamilies([.systemLarge])
    }
}

@main
struct AWPWidgetBundle: WidgetBundle {
    var body: some Widget {
        AWPPrayerWidget()
        AWPAllPrayersWidget()
    }
}
