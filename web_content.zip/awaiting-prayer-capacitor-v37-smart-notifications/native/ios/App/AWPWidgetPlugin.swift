import Foundation
import Capacitor
import WidgetKit

@objc(AWPWidgetPlugin)
public class AWPWidgetPlugin: CAPPlugin, CAPBridgedPlugin {
    public let identifier = "AWPWidgetPlugin"
    public let jsName = "AWPWidget"
    public let pluginMethods: [CAPPluginMethod] = [
        CAPPluginMethod(name: "update", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "requestPin", returnType: CAPPluginReturnPromise)
    ]
    private let group = "group.com.sanastudio.waitingforprayer"

    @objc func update(_ call: CAPPluginCall) {
        guard let defaults = UserDefaults(suiteName: group) else {
            call.reject("App Group is not configured for the app and widget targets")
            return
        }
        defaults.set(call.getString("prayer") ?? "", forKey: "prayer")
        defaults.set(call.getString("time") ?? "--:--", forKey: "time")
        defaults.set(call.getString("key") ?? "fajr", forKey: "key")
        defaults.set(call.getString("lang") ?? "en", forKey: "lang")
        defaults.set(call.getString("todayKey") ?? "", forKey: "todayKey")
        defaults.set(call.getArray("prayers") ?? [], forKey: "prayers")
        defaults.set(call.getBool("active") ?? false, forKey: "active")
        defaults.set(call.getDouble("activeUntil") ?? 0, forKey: "activeUntil")
        defaults.set(call.getDouble("targetTs") ?? 0, forKey: "targetTs")
        if let previousIsha = call.getObject("previousIsha") { defaults.set(previousIsha, forKey: "previousIsha") }
        else { defaults.removeObject(forKey: "previousIsha") }
        if #available(iOS 14.0, *) { WidgetCenter.shared.reloadAllTimelines() }
        call.resolve()
    }

    @objc func requestPin(_ call: CAPPluginCall) {
        call.resolve([
            "supported": false,
            "requested": false,
            "instructions": "Open the iOS widget gallery and add either “Next prayer” or “All five prayers”."
        ])
    }
}
