package com.sanastudio.waitingforprayer;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.widget.RemoteViews;

import org.json.JSONObject;

public class AWPAllPrayersWidgetProvider extends AppWidgetProvider {
    private static final String[] KEYS = {"fajr", "dhuhr", "asr", "maghrib", "isha"};
    private static final int[] ROWS = {R.id.wg_row_0, R.id.wg_row_1, R.id.wg_row_2, R.id.wg_row_3, R.id.wg_row_4};
    private static final int[] IMAGES = {R.id.wg_all_scene_0, R.id.wg_all_scene_1, R.id.wg_all_scene_2, R.id.wg_all_scene_3, R.id.wg_all_scene_4};
    private static final int[] NAMES = {R.id.wg_all_name_0, R.id.wg_all_name_1, R.id.wg_all_name_2, R.id.wg_all_name_3, R.id.wg_all_name_4};
    private static final int[] TIMES = {R.id.wg_all_time_0, R.id.wg_all_time_1, R.id.wg_all_time_2, R.id.wg_all_time_3, R.id.wg_all_time_4};

    static void updateAll(Context context, JSONObject state) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        int[] ids = manager.getAppWidgetIds(new ComponentName(context, AWPAllPrayersWidgetProvider.class));
        for (int id : ids) updateOne(context, manager, id, state);
    }

    private static void updateOne(Context context, AppWidgetManager manager, int id, JSONObject state) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.awp_widget_all);
        boolean active = state.optBoolean("active", false);
        String currentKey = state.optString("key", "");
        views.setTextViewText(R.id.wg_all_status, active ? AWPSinglePrayerWidgetProvider.label(context, "active") : AWPSinglePrayerWidgetProvider.label(context, "upcoming"));
        views.setTextViewText(R.id.wg_all_countdown_label, active ? AWPSinglePrayerWidgetProvider.label(context, "active_left") : AWPSinglePrayerWidgetProvider.label(context, "remaining"));
        AWPSinglePrayerWidgetProvider.setCountdown(views, R.id.wg_all_countdown, (long) state.optDouble("targetTs", 0));

        for (int i = 0; i < KEYS.length; i++) {
            String key = KEYS[i];
            JSONObject item = AWPWidgetData.prayerForKey(context, key, state);
            String name = item != null ? item.optString("prayer", key) : fallbackName(context, key);
            String time = item != null ? item.optString("time", "--:--") : "--:--";
            views.setTextViewText(NAMES[i], name);
            views.setTextViewText(TIMES[i], time);
            int image = context.getResources().getIdentifier("awp_prayer_" + key, "drawable", context.getPackageName());
            if (image != 0) views.setImageViewResource(IMAGES[i], image);
            views.setInt(ROWS[i], "setBackgroundResource", key.equals(currentKey) ? R.drawable.awp_widget_row_next : R.drawable.awp_widget_row);
            views.setOnClickPendingIntent(ROWS[i], AWPSinglePrayerWidgetProvider.pending(context, AWPSinglePrayerWidgetProvider.prayerIntent(context, key), 87100 + id * 10 + i));
        }
        views.setOnClickPendingIntent(R.id.wg_all_root, AWPSinglePrayerWidgetProvider.pending(context, AWPSinglePrayerWidgetProvider.prayerIntent(context, currentKey.isEmpty() ? "fajr" : currentKey), 87200 + id));
        manager.updateAppWidget(id, views);
    }

    private static String fallbackName(Context context, String key) {
        boolean ar = "ar".equals(AWPWidgetData.read(context).optString("lang", "ar"));
        String[] arNames = {"الفجر", "الظهر", "العصر", "المغرب", "العشاء"};
        String[] enNames = {"Fajr", "Dhuhr", "Asr", "Maghrib", "Isha"};
        for (int i = 0; i < KEYS.length; i++) if (KEYS[i].equals(key)) return ar ? arNames[i] : enNames[i];
        return key;
    }

    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        JSONObject state = AWPWidgetData.current(context);
        for (int id : ids) updateOne(context, manager, id, state);
        AWPWidgetData.refreshWidgets(context);
    }
}
