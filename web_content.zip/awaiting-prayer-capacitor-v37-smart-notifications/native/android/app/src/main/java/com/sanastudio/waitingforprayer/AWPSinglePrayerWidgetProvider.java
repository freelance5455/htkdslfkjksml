package com.sanastudio.waitingforprayer;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.SystemClock;
import android.widget.RemoteViews;

import org.json.JSONObject;

public class AWPSinglePrayerWidgetProvider extends AppWidgetProvider {
    static void updateAll(Context context, JSONObject state) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        int[] ids = manager.getAppWidgetIds(new ComponentName(context, AWPSinglePrayerWidgetProvider.class));
        for (int id : ids) updateOne(context, manager, id, state);
    }

    private static void updateOne(Context context, AppWidgetManager manager, int id, JSONObject state) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.awp_widget_single);
        String key = state.optString("key", "fajr");
        boolean active = state.optBoolean("active", false);
        views.setTextViewText(R.id.wg_status, active ? label(context, "active") : label(context, "upcoming"));
        views.setTextViewText(R.id.wg_prayer, state.optString("prayer", label(context, "choose")));
        views.setTextViewText(R.id.wg_time, state.optString("time", "--:--"));
        views.setTextViewText(R.id.wg_countdown_label, active ? label(context, "active_left") : label(context, "remaining"));
        long target = (long) state.optDouble("targetTs", 0);
        setCountdown(views, R.id.wg_countdown, target);
        int image = context.getResources().getIdentifier("awp_prayer_" + key, "drawable", context.getPackageName());
        if (image != 0) views.setImageViewResource(R.id.wg_scene, image);
        Intent launch = prayerIntent(context, key);
        views.setOnClickPendingIntent(R.id.wg_root, pending(context, launch, 87030 + id));
        manager.updateAppWidget(id, views);
    }

    static PendingIntent pending(Context context, Intent intent, int requestCode) {
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getActivity(context, requestCode, intent, flags);
    }

    static Intent prayerIntent(Context context, String key) {
        Intent intent = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
        if (intent == null) intent = new Intent();
        intent.setPackage(context.getPackageName());
        intent.setAction(Intent.ACTION_VIEW);
        intent.setData(Uri.parse("awaitingprayer://prayer?key=" + key));
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return intent;
    }

    static void setCountdown(RemoteViews views, int viewId, long target) {
        long remaining = target - System.currentTimeMillis();
        if (target <= 0 || remaining < 0) {
            views.setTextViewText(viewId, "--:--");
            return;
        }
        if (Build.VERSION.SDK_INT >= 24) {
            views.setChronometer(viewId, SystemClock.elapsedRealtime() + remaining, null, true);
            views.setChronometerCountDown(viewId, true);
        } else {
            long seconds = remaining / 1000L;
            views.setTextViewText(viewId, String.format(java.util.Locale.getDefault(), "%02d:%02d", seconds / 60, seconds % 60));
        }
    }

    static String label(Context context, String key) {
        String lang = AWPWidgetData.read(context).optString("lang", "ar");
        boolean ar = "ar".equals(lang);
        switch (key) {
            case "active": return ar ? "حان وقت الصلاة" : "PRAYER TIME NOW";
            case "active_left": return ar ? "المتبقي من مؤقت الأداء" : "TIME LEFT ON PRAYER TIMER";
            case "remaining": return ar ? "متبقي" : "REMAINING";
            case "choose": return ar ? "اختر المنطقة من التطبيق" : "Choose a region in the app";
            default: return ar ? "الصلاة القادمة" : "NEXT PRAYER";
        }
    }

    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        JSONObject state = AWPWidgetData.current(context);
        for (int id : ids) updateOne(context, manager, id, state);
        AWPWidgetData.refreshWidgets(context);
    }
}
