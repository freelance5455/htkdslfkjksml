package com.sanastudio.waitingforprayer;

/** Kept only for compatibility with older generated projects. */
@Deprecated
public class AWPWidgetProvider extends AWPAllPrayersWidgetProvider { }
