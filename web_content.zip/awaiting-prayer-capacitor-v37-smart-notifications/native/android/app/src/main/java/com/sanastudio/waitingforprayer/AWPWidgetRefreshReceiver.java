package com.sanastudio.waitingforprayer;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AWPWidgetRefreshReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (intent != null && (AWPWidgetData.ACTION_REFRESH.equals(intent.getAction()) || Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction()))) {
            AWPWidgetData.refreshWidgets(context);
        }
    }
}
