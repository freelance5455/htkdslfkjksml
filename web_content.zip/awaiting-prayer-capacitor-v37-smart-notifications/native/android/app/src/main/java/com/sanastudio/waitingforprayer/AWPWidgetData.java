package com.sanastudio.waitingforprayer;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/** Shared widget state and the 20-minute prayer-window selector. */
public final class AWPWidgetData {
    public static final String PREFS = "awp_prayer_widget_v1";
    public static final String ACTION_REFRESH = "com.sanastudio.waitingforprayer.WIDGET_REFRESH";
    public static final long PRAYER_WINDOW_MS = 20L * 60L * 1000L;
    private static final String TAG = "AWPWidgetData";

    private AWPWidgetData() {}

    public static void save(Context context, JSONObject payload) {
        if (payload == null) payload = new JSONObject();
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString("payload", payload.toString())
                .apply();
    }

    public static JSONObject read(Context context) {
        String raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString("payload", "{}");
        try { return new JSONObject(raw); }
        catch (JSONException error) { return new JSONObject(); }
    }

    private static JSONObject copy(JSONObject source) {
        if (source == null) return new JSONObject();
        try { return new JSONObject(source.toString()); }
        catch (JSONException error) { return new JSONObject(); }
    }

    /** Resolve the state from absolute prayer timestamps, not from a stale UI snapshot. */
    public static JSONObject current(Context context) {
        JSONObject payload = read(context);
        JSONArray prayers = payload.optJSONArray("prayers");
        JSONObject previousIsha = payload.optJSONObject("previousIsha");
        long now = System.currentTimeMillis();
        JSONObject active = null;
        JSONObject upcoming = null;
        double activeTs = -1;
        double upcomingTs = Double.MAX_VALUE;

        if (previousIsha != null) {
            double ts = previousIsha.optDouble("ts", -1);
            if (ts > 0 && ts <= now && now < ts + PRAYER_WINDOW_MS) {
                active = previousIsha;
                activeTs = ts;
            }
        }

        if (prayers != null) {
            for (int i = 0; i < prayers.length(); i++) {
                JSONObject item = prayers.optJSONObject(i);
                if (item == null) continue;
                double ts = item.optDouble("ts", -1);
                if (ts <= 0) continue;
                if (ts <= now && now < ts + PRAYER_WINDOW_MS && ts > activeTs) {
                    active = item;
                    activeTs = ts;
                }
                if (ts > now && ts < upcomingTs) {
                    upcoming = item;
                    upcomingTs = ts;
                }
            }
        }

        JSONObject selected = active != null ? active : upcoming;
        JSONObject result = copy(payload);
        if (selected != null) {
            boolean isActive = active != null;
            double ts = selected.optDouble("ts", 0);
            long end = isActive ? (long) ts + PRAYER_WINDOW_MS : 0L;
            result.remove("key"); result.remove("prayer"); result.remove("time");
            result.remove("ts"); result.remove("active"); result.remove("activeUntil"); result.remove("targetTs"); result.remove("selectedDay");
            try {
                result.put("key", selected.optString("key", "fajr"));
                result.put("prayer", selected.optString("prayer", ""));
                result.put("time", selected.optString("time", "--:--"));
                result.put("ts", ts);
                result.put("active", isActive);
                result.put("activeUntil", end);
                result.put("targetTs", isActive ? end : ts);
                result.put("selectedDay", selected.optString("day", ""));
            } catch (JSONException ignored) { }
        }
        return result;
    }

    public static JSONObject prayerForKey(Context context, String key, JSONObject state) {
        JSONObject payload = read(context);
        JSONArray prayers = payload.optJSONArray("prayers");
        String selectedDay = state == null ? "" : state.optString("selectedDay", "");
        String todayKey = payload.optString("todayKey", "");
        JSONObject firstMatch = null;
        JSONObject todayMatch = null;
        if (prayers != null) {
            for (int i = 0; i < prayers.length(); i++) {
                JSONObject item = prayers.optJSONObject(i);
                if (item == null || !key.equals(item.optString("key"))) continue;
                if (firstMatch == null) firstMatch = item;
                String day = item.optString("day", "");
                if (!selectedDay.isEmpty() && selectedDay.equals(day)) return item;
                if (!todayKey.isEmpty() && todayKey.equals(day)) todayMatch = item;
            }
        }
        // During the first 20 minutes after midnight, the active prayer can be yesterday's Isha.
        // Keep the all-prayers widget populated with today's five rows in that case.
        return todayMatch != null ? todayMatch : firstMatch;
    }

    public static void refreshWidgets(Context context) {
        Context app = context.getApplicationContext();
        JSONObject state = current(app);
        try {
            AWPSinglePrayerWidgetProvider.updateAll(app, state);
            AWPAllPrayersWidgetProvider.updateAll(app, state);
            AWPNotificationPlugin.refreshFromWidgetState(app, state);
        } catch (Exception error) {
            Log.w(TAG, "Could not update prayer widgets", error);
        }
        scheduleNextBoundary(app, state);
    }

    private static void scheduleNextBoundary(Context context, JSONObject state) {
        try {
            Intent intent = new Intent(context, AWPWidgetRefreshReceiver.class).setAction(ACTION_REFRESH);
            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
            PendingIntent pending = PendingIntent.getBroadcast(context, 87021, intent, flags);
            AlarmManager alarms = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (alarms == null) return;
            long target = (long) state.optDouble("targetTs", 0);
            if (target <= System.currentTimeMillis()) {
                alarms.cancel(pending);
                return;
            }
            // Use an inexact idle-allowed alarm: launcher widgets cannot promise exact-second refreshes.
            long triggerAt = target + 1500L;
            if (Build.VERSION.SDK_INT >= 31 && alarms.canScheduleExactAlarms()) {
                alarms.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pending);
            } else if (Build.VERSION.SDK_INT >= 23) {
                alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pending);
            } else {
                alarms.set(AlarmManager.RTC_WAKEUP, triggerAt, pending);
            }
        } catch (Exception error) {
            Log.w(TAG, "Could not schedule next widget transition", error);
        }
    }
}
