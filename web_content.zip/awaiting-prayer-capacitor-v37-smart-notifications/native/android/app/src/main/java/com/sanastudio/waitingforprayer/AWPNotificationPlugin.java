package com.sanastudio.waitingforprayer;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Build;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/** Native, silent, continuously-counting status notification for the current/next prayer. */
@CapacitorPlugin(name = "AWPNotification")
public final class AWPNotificationPlugin extends Plugin {
    private static final String CHANNEL_ID = "awp_status_v1";
    private static final String PREFS = "awp_notification_status_v1";
    private static final int NOTIFICATION_ID = 87090;

    @PluginMethod
    public void updateOngoing(PluginCall call) {
        try {
            Context context = getContext().getApplicationContext();
            NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager == null) throw new IllegalStateException("Notification service is unavailable");
            ensureChannel(context, manager);

            String title = call.getData().optString("title", "الصلاة القادمة");
            String body = call.getData().optString("body", "");
            long targetTs = call.getData().optLong("targetTs", 0L);
            long now = System.currentTimeMillis();
            boolean countdown = targetTs > now;

            Intent launch = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
            PendingIntent contentIntent = null;
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                int flags = PendingIntent.FLAG_UPDATE_CURRENT;
                if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
                contentIntent = PendingIntent.getActivity(context, 87090, launch, flags);
            }

            Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                    ? new Notification.Builder(context, CHANNEL_ID)
                    : new Notification.Builder(context).setPriority(Notification.PRIORITY_LOW).setSound(null).setVibrate(new long[]{0L});
            builder.setSmallIcon(R.drawable.ic_stat_prayer)
                    .setContentTitle(title)
                    .setContentText(body)
                    .setStyle(new Notification.BigTextStyle().bigText(body))
                    .setCategory(Notification.CATEGORY_STATUS)
                    .setVisibility(Notification.VISIBILITY_PUBLIC)
                    .setColor(Color.rgb(179, 214, 90))
                    .setOngoing(true)
                    .setAutoCancel(false)
                    .setOnlyAlertOnce(true)
                    .setShowWhen(true)
                    .setLocalOnly(true);
            Bitmap appIcon = largeAppIcon(context);
            if (appIcon != null) builder.setLargeIcon(appIcon);
            if (contentIntent != null) builder.setContentIntent(contentIntent);
            if (countdown) {
                builder.setWhen(targetTs).setUsesChronometer(true);
                if (Build.VERSION.SDK_INT >= 24) builder.setChronometerCountDown(true);
            } else {
                builder.setUsesChronometer(false).setWhen(now);
            }

            // Re-posting the same ID with setOnlyAlertOnce updates the live countdown
            // without playing another sound or vibration. The dedicated channel is silent.
            manager.notify(NOTIFICATION_ID, builder.build());
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("enabled", true).apply();
            JSObject result = new JSObject();
            result.put("displayed", true);
            result.put("countdown", countdown);
            result.put("silentUpdates", true);
            call.resolve(result);
        } catch (Exception error) {
            call.reject("Could not update the ongoing prayer notification", error);
        }
    }

    @PluginMethod
    public void clearOngoing(PluginCall call) {
        try {
            NotificationManager manager = (NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager != null) manager.cancel(NOTIFICATION_ID);
            getContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("enabled", false).apply();
            JSObject result = new JSObject();
            result.put("cleared", true);
            call.resolve(result);
        } catch (Exception error) {
            call.reject("Could not clear the ongoing prayer notification", error);
        }
    }

    /** Rebuild the same silent live notification after the widget boundary alarm or reboot. */
    public static void refreshFromWidgetState(Context context, org.json.JSONObject state) {
        if (state == null || !context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("enabled", false)) return;
        try {
            NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager == null) return;
            ensureChannel(context, manager);
            String prayer = state.optString("prayer", "");
            boolean active = state.optBoolean("active", false);
            String title = active ? "حان وقت الصلاة" + (prayer.isEmpty() ? "" : " · " + prayer)
                    : "الصلاة القادمة" + (prayer.isEmpty() ? "" : " · " + prayer);
            String time = state.optString("time", "--:--");
            String body = active ? "نافذة أداء الصلاة · الوقت المجدول " + time : "موعد الصلاة " + time;
            long targetTs = state.optLong("targetTs", 0L);
            long now = System.currentTimeMillis();
            Intent launch = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
            PendingIntent contentIntent = null;
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                int flags = PendingIntent.FLAG_UPDATE_CURRENT;
                if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
                contentIntent = PendingIntent.getActivity(context, NOTIFICATION_ID, launch, flags);
            }
            Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                    ? new Notification.Builder(context, CHANNEL_ID)
                    : new Notification.Builder(context).setPriority(Notification.PRIORITY_LOW).setSound(null).setVibrate(new long[]{0L});
            builder.setSmallIcon(R.drawable.ic_stat_prayer)
                    .setContentTitle(title)
                    .setContentText(body)
                    .setStyle(new Notification.BigTextStyle().bigText(body))
                    .setCategory(Notification.CATEGORY_STATUS)
                    .setVisibility(Notification.VISIBILITY_PUBLIC)
                    .setColor(Color.rgb(179, 214, 90))
                    .setOngoing(true).setAutoCancel(false).setOnlyAlertOnce(true)
                    .setShowWhen(true).setLocalOnly(true);
            Bitmap appIcon = largeAppIcon(context);
            if (appIcon != null) builder.setLargeIcon(appIcon);
            if (contentIntent != null) builder.setContentIntent(contentIntent);
            if (targetTs > now) {
                builder.setWhen(targetTs).setUsesChronometer(true);
                if (Build.VERSION.SDK_INT >= 24) builder.setChronometerCountDown(true);
            } else builder.setUsesChronometer(false).setWhen(now);
            manager.notify(NOTIFICATION_ID, builder.build());
        } catch (SecurityException ignored) {
            // The user may have revoked notification permission while the app was closed.
        } catch (Exception ignored) { }
    }

    private static Bitmap largeAppIcon(Context context) {
        try {
            Drawable icon = context.getPackageManager().getApplicationIcon(context.getPackageName());
            int size = Math.max(48, (int) (context.getResources().getDisplayMetrics().density * 64));
            Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            icon.setBounds(0, 0, size, size);
            icon.draw(canvas);
            return bitmap;
        } catch (Exception ignored) {
            return null;
        }
    }

    private static void ensureChannel(Context context, NotificationManager manager) {
        if (Build.VERSION.SDK_INT < 26) return;
        if (manager.getNotificationChannel(CHANNEL_ID) == null) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    context.getString(R.string.awp_status_channel_name),
                    NotificationManager.IMPORTANCE_LOW);
            channel.setDescription(context.getString(R.string.awp_status_channel_description));
            channel.setSound(null, null);
            channel.enableVibration(false);
            channel.enableLights(false);
            channel.setShowBadge(false);
            channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            manager.createNotificationChannel(channel);
        }
        final String feedbackId = "awp_feedback_v4";
        if (manager.getNotificationChannel(feedbackId) == null) {
            NotificationChannel feedback = new NotificationChannel(
                    feedbackId,
                    context.getString(R.string.awp_feedback_channel_name),
                    NotificationManager.IMPORTANCE_LOW);
            feedback.setDescription(context.getString(R.string.awp_feedback_channel_description));
            feedback.setSound(null, null);
            feedback.enableVibration(false);
            feedback.enableLights(false);
            feedback.setShowBadge(false);
            manager.createNotificationChannel(feedback);
        }
    }
}
