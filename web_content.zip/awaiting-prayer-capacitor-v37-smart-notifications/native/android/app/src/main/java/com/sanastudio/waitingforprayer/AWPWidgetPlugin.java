package com.sanastudio.waitingforprayer;

import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.os.Build;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "AWPWidget")
public class AWPWidgetPlugin extends Plugin {
    @PluginMethod
    public void update(PluginCall call) {
        try {
            AWPWidgetData.save(getContext(), call.getData());
            AWPWidgetData.refreshWidgets(getContext());
            JSObject result = new JSObject();
            result.put("updated", true);
            result.put("prayerWindowMinutes", 20);
            call.resolve(result);
        } catch (Exception error) {
            call.reject("Could not update prayer widgets", error);
        }
    }

    @PluginMethod
    public void requestPin(PluginCall call) {
        JSObject result = new JSObject();
        if (Build.VERSION.SDK_INT < 26) {
            result.put("supported", false); result.put("requested", false);
            result.put("instructions", "This Android version does not support direct widget pinning. Add the widget from the launcher widget picker.");
            call.resolve(result); return;
        }
        AppWidgetManager manager = AppWidgetManager.getInstance(getContext());
        if (!manager.isRequestPinAppWidgetSupported()) {
            result.put("supported", false); result.put("requested", false);
            result.put("instructions", "Long-press the home screen, open Widgets, then choose I’m Waiting for Prayer.");
            call.resolve(result); return;
        }
        String type = call.getString("type", "single");
        Class<?> provider = "all".equals(type) ? AWPAllPrayersWidgetProvider.class : AWPSinglePrayerWidgetProvider.class;
        boolean requested = manager.requestPinAppWidget(new ComponentName(getContext(), provider), null, null);
        result.put("supported", true); result.put("requested", requested);
        call.resolve(result);
    }
}
