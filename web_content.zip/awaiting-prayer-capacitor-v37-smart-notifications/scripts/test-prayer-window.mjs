import { readFileSync } from 'node:fs';
import vm from 'node:vm';

const html = readFileSync(new URL('../index.html', import.meta.url), 'utf8');
const match = html.match(/function nextP\(\)\{[\s\S]*?\n\}\nfunction pn\(/);
if (!match) throw new Error('Could not extract nextP() from index.html');
const source = match[0].replace(/\nfunction pn\($/, '');
const minute = 60_000;
let now = 0;
class TestDate extends Date { static now() { return now; } }
function timetable(today, previous = null, tomorrow = null) {
  return { tm1: previous ? { t: previous } : null, t0: { t: today }, t1: tomorrow ? { t: tomorrow } : null };
}
function verify(label, expectedKey, expectedActive, expectedEnd = null) {
  const scope = { V, PRAYER_WINDOW_MS: 20 * minute, Date: TestDate, adjd: value => ({ ...value }) };
  vm.createContext(scope);
  vm.runInContext(source, scope);
  const actual = scope.nextP();
  const ok = actual && actual.k === expectedKey && !!actual.active === expectedActive && (expectedEnd === null || actual.endsAt === expectedEnd);
  console.log(`${ok ? 'PASS' : 'FAIL'} ${label}`);
  if (!ok) {
    console.error('  actual:', actual);
    process.exitCode = 1;
  }
}

const fajr = Date.UTC(2026, 10, 8, 4, 0, 0);
const today = { fajr, dhuhr: fajr + 5 * 60 * minute, asr: fajr + 9 * 60 * minute, maghrib: fajr + 13 * 60 * minute, isha: fajr + 17 * 60 * minute };
const tomorrow = { fajr: fajr + 86_400_000, dhuhr: fajr + 86_400_000 + 5 * 60 * minute, asr: fajr + 86_400_000 + 9 * 60 * minute, maghrib: fajr + 86_400_000 + 13 * 60 * minute, isha: fajr + 86_400_000 + 17 * 60 * minute };
let V = timetable(today, null, tomorrow);
now = fajr - minute;
verify('one minute before Fajr shows it as upcoming', 'fajr', false);
now = fajr + 5 * minute;
verify('five minutes after Fajr keeps Fajr active with a 20-minute end', 'fajr', true, fajr + 20 * minute);
now = fajr + 20 * minute + 1_000;
verify('the next prayer appears after the 20-minute window', 'dhuhr', false);
V = timetable(today, { isha: fajr - 86_400_000 + 10 * minute }, tomorrow);
now = fajr - 86_400_000 + 15 * minute;
verify('previous-day Isha remains active across midnight', 'isha', true);
now = fajr - 86_400_000 + 30 * minute + 1_000;
verify('previous-day Isha is released after its 20-minute window', 'fajr', false);
if (process.exitCode) process.exit(process.exitCode);
