import {
  existsSync, mkdirSync, copyFileSync, readFileSync, writeFileSync,
  readdirSync,
} from 'node:fs';
import { dirname, resolve, relative } from 'node:path';

const root = process.cwd();
const androidRoot = resolve(root, 'android');
const appRoot = resolve(androidRoot, 'app');
const manifestPath = resolve(appRoot, 'src/main/AndroidManifest.xml');

const copies = [
  ['native/android/app/src/main/res/raw/awp_notification.wav', 'android/app/src/main/res/raw/awp_notification.wav'],
  ['native/android/app/src/main/res/drawable/ic_stat_prayer.xml', 'android/app/src/main/res/drawable/ic_stat_prayer.xml'],
  ['native/android/app/src/main/java/com/sanastudio/waitingforprayer/AWPWidgetPlugin.java', 'android/app/src/main/java/com/sanastudio/waitingforprayer/AWPWidgetPlugin.java'],
  ['native/android/app/src/main/java/com/sanastudio/waitingforprayer/AWPNotificationPlugin.java', 'android/app/src/main/java/com/sanastudio/waitingforprayer/AWPNotificationPlugin.java'],
  ['native/android/app/src/main/java/com/sanastudio/waitingforprayer/AWPWidgetData.java', 'android/app/src/main/java/com/sanastudio/waitingforprayer/AWPWidgetData.java'],
  ['native/android/app/src/main/java/com/sanastudio/waitingforprayer/AWPWidgetRefreshReceiver.java', 'android/app/src/main/java/com/sanastudio/waitingforprayer/AWPWidgetRefreshReceiver.java'],
  ['native/android/app/src/main/java/com/sanastudio/waitingforprayer/AWPSinglePrayerWidgetProvider.java', 'android/app/src/main/java/com/sanastudio/waitingforprayer/AWPSinglePrayerWidgetProvider.java'],
  ['native/android/app/src/main/java/com/sanastudio/waitingforprayer/AWPAllPrayersWidgetProvider.java', 'android/app/src/main/java/com/sanastudio/waitingforprayer/AWPAllPrayersWidgetProvider.java'],
  ['native/android/app/src/main/java/com/sanastudio/waitingforprayer/AWPWidgetProvider.java', 'android/app/src/main/java/com/sanastudio/waitingforprayer/AWPWidgetProvider.java'],
  ['native/android/app/src/main/res/layout/awp_widget_single.xml', 'android/app/src/main/res/layout/awp_widget_single.xml'],
  ['native/android/app/src/main/res/layout/awp_widget_all.xml', 'android/app/src/main/res/layout/awp_widget_all.xml'],
  ['native/android/app/src/main/res/drawable/awp_widget_bg.xml', 'android/app/src/main/res/drawable/awp_widget_bg.xml'],
  ['native/android/app/src/main/res/drawable/awp_widget_mark.xml', 'android/app/src/main/res/drawable/awp_widget_mark.xml'],
  ['native/android/app/src/main/res/drawable/awp_widget_row.xml', 'android/app/src/main/res/drawable/awp_widget_row.xml'],
  ['native/android/app/src/main/res/drawable/awp_widget_row_next.xml', 'android/app/src/main/res/drawable/awp_widget_row_next.xml'],
  ['native/android/app/src/main/res/xml/awp_widget_info.xml', 'android/app/src/main/res/xml/awp_widget_info.xml'],
  ['native/android/app/src/main/res/xml/awp_widget_info_single.xml', 'android/app/src/main/res/xml/awp_widget_info_single.xml'],
  ['native/android/app/src/main/res/xml/awp_widget_info_all.xml', 'android/app/src/main/res/xml/awp_widget_info_all.xml'],
  ['native/android/app/src/main/res/values/awp_widget_strings.xml', 'android/app/src/main/res/values/awp_widget_strings.xml'],
  ...['ar', 'tr', 'fr'].map(lang => [`native/android/app/src/main/res/values-${lang}/awp_widget_strings.xml`, `android/app/src/main/res/values-${lang}/awp_widget_strings.xml`]),
  ['native/android/app/src/main/res/values/awp_notification_strings.xml', 'android/app/src/main/res/values/awp_notification_strings.xml'],
  ...['ar', 'tr', 'fr'].map(lang => [`native/android/app/src/main/res/values-${lang}/awp_notification_strings.xml`, `android/app/src/main/res/values-${lang}/awp_notification_strings.xml`]),
  ...['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'].map(key => [`native/android/app/src/main/res/drawable-nodpi/awp_prayer_${key}.jpg`, `android/app/src/main/res/drawable-nodpi/awp_prayer_${key}.jpg`]),
];

if (!existsSync(appRoot)) {
  console.error('Android platform is not generated. Run `npm run android:prepare` (or `npx cap add android`) first.');
  process.exit(1);
}

for (const [source, destination] of copies) {
  const src = resolve(root, source);
  const dst = resolve(root, destination);
  if (!existsSync(src)) throw new Error(`Missing bundled resource: ${source}`);
  mkdirSync(dirname(dst), { recursive: true });
  copyFileSync(src, dst);
}
console.log(`Copied ${copies.length} Android widget, scene and notification resources.`);

if (!existsSync(manifestPath)) throw new Error(`Android manifest not found: ${relative(root, manifestPath)}`);
let manifest = readFileSync(manifestPath, 'utf8');

// Android displays this package label beside the system notification icon.
// Capacitor generates @string/app_name from capacitor.config.json's appName.
const applicationTag = manifest.match(/<application\b[^>]*>/);
if (!applicationTag) throw new Error('Could not find <application> in AndroidManifest.xml');
if (!/android:label="@string\/app_name"/.test(applicationTag[0])) {
  const labelled = /android:label="[^"]*"/.test(applicationTag[0])
    ? applicationTag[0].replace(/android:label="[^"]*"/, 'android:label="@string/app_name"')
    : applicationTag[0].replace(/>$/, ' android:label="@string/app_name">');
  manifest = manifest.replace(applicationTag[0], labelled);
}

// Add the notification permissions used by the app's native notification bridge.
const permissionLines = [
  '<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />',
  '<uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" />',
  '<uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />',
];
for (const permission of permissionLines) {
  const name = permission.match(/android:name="([^"]+)"/)[1];
  if (!manifest.includes(`android:name="${name}"`)) {
    const appTag = manifest.indexOf('<application');
    if (appTag < 0) throw new Error('Could not find <application> in AndroidManifest.xml');
    manifest = manifest.slice(0, appTag) + `    ${permission}\n    ` + manifest.slice(appTag);
  }
}

// Remove the obsolete v20 receiver; v21+ exposes two distinct widget entries.
manifest = manifest.replace(/\s*<receiver\b(?=[^>]*android:name="[^"]*\.AWPWidgetProvider")[\s\S]*?<\/receiver>/g, '');

function upsertReceiver(xml, className, label, infoName) {
  const fqcn = `com.sanastudio.waitingforprayer.${className}`;
  const block = `\n        <receiver android:name="${fqcn}" android:label="@string/${label}" android:exported="true">\n            <intent-filter>\n                <action android:name="android.appwidget.action.APPWIDGET_UPDATE" />\n            </intent-filter>\n            <meta-data android:name="android.appwidget.provider" android:resource="@xml/${infoName}" />\n        </receiver>\n`;
  const escaped = fqcn.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const re = new RegExp(`<receiver\\b(?=[^>]*android:name="${escaped}")[\\s\\S]*?<\\/receiver>`, 'g');
  const matches = [...xml.matchAll(re)];
  if (matches.length) {
    // Replace all previous declarations in one pass, then insert one canonical block.
    xml = xml.replace(re, '');
  }
  const closing = xml.lastIndexOf('</application>');
  if (closing < 0) throw new Error('Could not find </application> in AndroidManifest.xml');
  xml = xml.slice(0, closing) + block + xml.slice(closing);
  return xml;
}

manifest = upsertReceiver(manifest, 'AWPSinglePrayerWidgetProvider', 'awp_single_widget_name', 'awp_widget_info_single');
manifest = upsertReceiver(manifest, 'AWPAllPrayersWidgetProvider', 'awp_all_widget_name', 'awp_widget_info_all');

// The receiver refreshes both widgets at the start/end of a 20-minute prayer window.
const refreshReceiver = `\n        <receiver android:name="com.sanastudio.waitingforprayer.AWPWidgetRefreshReceiver" android:exported="false">\n            <intent-filter>\n                <action android:name="com.sanastudio.waitingforprayer.WIDGET_REFRESH" />\n                <action android:name="android.intent.action.BOOT_COMPLETED" />\n            </intent-filter>\n        </receiver>\n`;
if (!manifest.includes('com.sanastudio.waitingforprayer.AWPWidgetRefreshReceiver')) {
  const closing = manifest.lastIndexOf('</application>');
  if (closing < 0) throw new Error('Could not find </application> while registering widget refresh receiver.');
  manifest = manifest.slice(0, closing) + refreshReceiver + manifest.slice(closing);
}

// Locate the generated MainActivity rather than assuming a hard-coded source path.
function walk(dir) {
  if (!existsSync(dir)) return [];
  const out = [];
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    const path = resolve(dir, entry.name);
    if (entry.isDirectory()) out.push(...walk(path));
    else if (entry.isFile() && entry.name === 'MainActivity.java') out.push(path);
  }
  return out;
}
const javaRoots = [resolve(appRoot, 'src/main/java'), resolve(appRoot, 'src/main')];
const activityCandidates = [...new Set(javaRoots.flatMap(walk))];
if (activityCandidates.length !== 1) {
  throw new Error(`Expected one generated MainActivity.java, found ${activityCandidates.length}. Check android/app/src/main/java and register AWPWidgetPlugin manually if your project is customized.`);
}
const mainPath = activityCandidates[0];
let main = readFileSync(mainPath, 'utf8');
if (!main.includes('extends BridgeActivity')) {
  throw new Error('MainActivity does not extend BridgeActivity. Register AWPWidgetPlugin manually in its Capacitor bridge setup.');
}
if (!main.includes('registerPlugin(AWPWidgetPlugin.class)')) {
  const onCreateRe = /(public\s+void\s+onCreate\s*\(\s*(?:android\.os\.)?Bundle\s+\w+\s*\)\s*\{)/;
  const onCreate = main.match(onCreateRe);
  if (onCreate) {
    const start = onCreate.index + onCreate[0].length;
    const superIndex = main.indexOf('super.onCreate(', start);
    const insertion = 'registerPlugin(AWPWidgetPlugin.class);\n        ';
    if (superIndex >= 0) main = main.slice(0, superIndex) + insertion + main.slice(superIndex);
    else main = main.slice(0, start) + '\n        ' + insertion + main.slice(start);
  } else {
    const classMatch = main.match(/public\s+class\s+MainActivity\s+extends\s+BridgeActivity\s*\{/);
    if (!classMatch) throw new Error('Could not safely locate MainActivity class body to register AWPWidgetPlugin.');
    const at = classMatch.index + classMatch[0].length;
    const method = `\n    @Override\n    public void onCreate(android.os.Bundle savedInstanceState) {\n        registerPlugin(AWPWidgetPlugin.class);\n        super.onCreate(savedInstanceState);\n    }\n`;
    main = main.slice(0, at) + method + main.slice(at);
  }
  writeFileSync(mainPath, main);
  console.log(`Registered AWPWidgetPlugin in ${relative(root, mainPath)}.`);
}

if (!main.includes('registerPlugin(AWPNotificationPlugin.class)')) {
  if (main.includes('registerPlugin(AWPWidgetPlugin.class)')) {
    main = main.replace('registerPlugin(AWPWidgetPlugin.class);', 'registerPlugin(AWPWidgetPlugin.class);\n        registerPlugin(AWPNotificationPlugin.class);');
  } else {
    const onCreateMatch = main.match(/public\s+void\s+onCreate\s*\(\s*(?:android\.os\.)?Bundle\s+\w+\s*\)\s*\{/);
    if (!onCreateMatch) throw new Error('Could not safely locate MainActivity.onCreate to register AWPNotificationPlugin.');
    const start = onCreateMatch.index + onCreateMatch[0].length;
    const superIndex = main.indexOf('super.onCreate(', start);
    const insertion = 'registerPlugin(AWPNotificationPlugin.class);\n        ';
    main = superIndex >= 0 ? main.slice(0, superIndex) + insertion + main.slice(superIndex) : main.slice(0, start) + '\n        ' + insertion + main.slice(start);
  }
  writeFileSync(mainPath, main);
  console.log(`Registered AWPNotificationPlugin in ${relative(root, mainPath)}.`);
}

// Add an explicit deep link so tapping a prayer tile opens its matching in-app scene.
const activityTag = /<activity\b(?=[^>]*android:name="(?:\.MainActivity|com\.sanastudio\.waitingforprayer\.MainActivity|MainActivity)")[^>]*>/;
const activityMatch = manifest.match(activityTag);
if (!activityMatch) throw new Error('Could not locate the MainActivity manifest entry for prayer deep links.');
const activityStart = activityMatch.index;
const activityClose = manifest.indexOf('</activity>', activityStart);
if (activityClose < 0) throw new Error('Could not locate MainActivity closing tag in AndroidManifest.xml.');
const activityXml = manifest.slice(activityStart, activityClose);
if (!activityXml.includes('android:host="prayer"')) {
  const deepLink = `\n            <intent-filter>\n                <action android:name="android.intent.action.VIEW" />\n                <category android:name="android.intent.category.DEFAULT" />\n                <category android:name="android.intent.category.BROWSABLE" />\n                <data android:scheme="awaitingprayer" android:host="prayer" />\n            </intent-filter>\n        `;
  manifest = manifest.slice(0, activityClose) + deepLink + manifest.slice(activityClose);
}
writeFileSync(manifestPath, manifest);

console.log('Registered both native Android widgets, the Capacitor bridge, app permissions and prayer-scene deep links.');
