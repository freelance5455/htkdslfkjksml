import { readFileSync } from 'node:fs';

const html = readFileSync(new URL('../index.html', import.meta.url), 'utf8');
const native = readFileSync(new URL('../native/android/app/src/main/java/com/sanastudio/waitingforprayer/AWPNotificationPlugin.java', import.meta.url), 'utf8');
const data = readFileSync(new URL('../native/android/app/src/main/java/com/sanastudio/waitingforprayer/AWPWidgetData.java', import.meta.url), 'utf8');
const widget = readFileSync(new URL('../native/android/app/src/main/java/com/sanastudio/waitingforprayer/AWPWidgetPlugin.java', import.meta.url), 'utf8');
const icon = readFileSync(new URL('../native/android/app/src/main/res/drawable/ic_stat_prayer.xml', import.meta.url), 'utf8');
const checks = [];
function check(name, condition) { checks.push({ name, ok: !!condition }); }

check('Fresh notification channels use the v4 IDs', html.includes('awp_prayer_v4') && html.includes('awp_mizan_v4') && html.includes('awp_feedback_v4'));
check('Legacy v3 channels are removed on migration', html.includes('awp_prayer_v3') && html.includes('awp_mizan_v3') && html.includes('N.deleteChannel'));
check('Legacy pending schedules are cancelled once', html.includes('M.notificationPolicyV4') && html.includes('N.cancel({notifications:items.map'));
check('Android notification sound is set by channel, not duplicated per notification', html.includes('if(platform!=="android")item.sound="awp_notification.wav"'));
check('Scheduled IDs are deterministic', html.includes('var id=nid(o.key)') && html.includes('expected.every(function(id)'));
check('Mizan reminders no longer repeat every 30 minutes', !html.includes('for(var i=1;i<=8;i++)') && html.includes('var followAt=st+18e5'));
check('Mizan reminder flood default is migrated to off', html.includes('M.quietReminderMigrationV4') && html.includes('M.on=false'));
check('Android ongoing notification updates are silent and persistent', native.includes('setOnlyAlertOnce(true)') && native.includes('setOngoing(true)') && native.includes('setSound(null, null)'));
check('Android ongoing notification has a live countdown chronometer', native.includes('setUsesChronometer(true)') && native.includes('setChronometerCountDown(true)'));
check('Ongoing notification refreshes after widget alarm/boot', data.includes('AWPNotificationPlugin.refreshFromWidgetState(app, state)') && native.includes('refreshFromWidgetState'));
check('Status notification is opt-in and can be cleared', native.includes('updateOngoing') && native.includes('clearOngoing') && native.includes('putBoolean("enabled", false)'));
check('The app uses Android launcher pin confirmation for widgets', widget.includes('requestPinAppWidget') && widget.includes('isRequestPinAppWidgetSupported'));
check('Small notification icon is monochrome white', icon.includes('#FFFFFFFF'));
check('System notification includes the actual application launcher icon', native.includes('getApplicationIcon(context.getPackageName())') && native.includes('setLargeIcon(appIcon)'));
check('Feedback channel is created even when the status channel already exists', native.includes('final String feedbackId = \"awp_feedback_v4\"') && !native.includes('getNotificationChannel(CHANNEL_ID) != null) return'));

for (const item of checks) console.log(`${item.ok ? 'PASS' : 'FAIL'} ${item.name}`);
const failed = checks.filter(item => !item.ok);
console.log(`\n${checks.length - failed.length}/${checks.length} notification-policy checks passed.`);
if (failed.length) process.exit(1);
