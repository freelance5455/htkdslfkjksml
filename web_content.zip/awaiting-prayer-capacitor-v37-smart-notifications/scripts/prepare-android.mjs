import { existsSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { resolve } from 'node:path';

const root = process.cwd();
const androidApp = resolve(root, 'android/app');
const isWindows = process.platform === 'win32';
const runner = isWindows ? 'npx.cmd' : 'npx';

function run(command, args) {
  console.log(`\n> ${command} ${args.join(' ')}`);
  const result = spawnSync(command, args, { cwd: root, stdio: 'inherit', shell: isWindows });
  if (result.error) throw result.error;
  if (result.status !== 0) throw new Error(`${command} ${args.join(' ')} failed with exit code ${result.status}`);
}

if (!existsSync(resolve(root, 'node_modules/@capacitor/android'))) {
  console.error('Capacitor Android dependencies are not installed. Run `npm install` first.');
  process.exit(1);
}

run('npm', ['run', 'build']);
if (!existsSync(androidApp)) run(runner, ['cap', 'add', 'android']);
run(runner, ['cap', 'sync', 'android']);
run('node', ['scripts/install-native-resources.mjs']);
run('node', ['scripts/verify-android-widgets.mjs']);

console.log('\nAndroid widget setup is complete. Open Android Studio with `npm run open:android`, build an APK, install it, then add the widgets from the launcher Widgets picker.');
