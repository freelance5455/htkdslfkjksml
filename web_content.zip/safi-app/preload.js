const {contextBridge,ipcRenderer}=require('electron');
contextBridge.exposeInMainWorld('safi',{
  pickFolders:()=>ipcRenderer.invoke('pick'),
  scan:p=>ipcRenderer.invoke('scan',p),
  trash:p=>ipcRenderer.invoke('trash',p),
  onProgress:cb=>{ipcRenderer.removeAllListeners('progress');ipcRenderer.on('progress',(_,p)=>cb(p))}
});
