const {app,BrowserWindow,ipcMain,dialog,shell,nativeImage}=require('electron');
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const EXT={img:/\.(jpe?g|png|webp|bmp|gif)$/i,vid:/\.(mp4|mov|mkv|avi|webm|3gp)$/i,doc:/\.(pdf|docx?|xlsx?|pptx?|txt)$/i};
const typeOf=n=>EXT.img.test(n)?'img':EXT.vid.test(n)?'vid':EXT.doc.test(n)?'doc':null;

async function* walk(d){
  let es;try{es=await fs.promises.readdir(d,{withFileTypes:true})}catch{return}
  for(const e of es){
    if(e.name.startsWith('.'))continue;
    const p=path.join(d,e.name);
    if(e.isDirectory())yield*walk(p);else if(e.isFile())yield p;
  }
}
const hashFile=p=>new Promise((res,rej)=>{
  const h=crypto.createHash('sha256');
  fs.createReadStream(p).on('data',c=>h.update(c)).on('end',()=>res(h.digest('hex'))).on('error',rej);
});
// dHash 64-bit (two uint32) for visually similar images
function dhash(p){
  try{
    const im=nativeImage.createFromPath(p);if(im.isEmpty())return null;
    const b=im.resize({width:9,height:8,quality:'good'}).toBitmap();
    const g=(x,y)=>{const i=(y*9+x)*4;return b[i]*.114+b[i+1]*.587+b[i+2]*.299};
    let hi=0,lo=0;
    for(let y=0;y<8;y++)for(let x=0;x<8;x++){
      const bit=g(x,y)>g(x+1,y)?1:0,k=y*8+x;
      if(k<32)lo|=bit<<k;else hi|=bit<<(k-32);
    }
    return[hi>>>0,lo>>>0];
  }catch{return null}
}
const pop=v=>{v=v-((v>>>1)&0x55555555);v=(v&0x33333333)+((v>>>2)&0x33333333);return(((v+(v>>>4))&0x0F0F0F0F)*0x01010101)>>>24};
const ham=(a,b)=>pop((a[0]^b[0])>>>0)+pop((a[1]^b[1])>>>0);

function describe(f){
  const o={name:path.basename(f.p),path:path.dirname(f.p),full:f.p,size:f.size,ts:f.ts,
    date:new Date(f.ts).toLocaleDateString('en-GB'),ty:f.ty,res:'',th:null};
  if(f.ty==='img'){
    try{
      const im=nativeImage.createFromPath(f.p),s=im.getSize();
      o.res=s.width+'×'+s.height;
      o.th='data:image/jpeg;base64,'+im.resize({width:240}).toJPEG(70).toString('base64');
    }catch{}
  }
  return o;
}

ipcMain.handle('pick',async()=>{
  const r=await dialog.showOpenDialog({properties:['openDirectory','multiSelections']});
  return r.canceled?[]:r.filePaths;
});

ipcMain.handle('scan',async(ev,roots)=>{
  const send=(a,b)=>ev.sender.send('progress',[a,b]);
  const files=[];let total=0;
  for(const r of roots)for await(const p of walk(r)){
    const ty=typeOf(p);if(!ty)continue;
    try{const st=await fs.promises.stat(p);if(st.size>0){files.push({p,ty,size:st.size,ts:st.mtimeMs});total+=st.size}}catch{}
  }
  // 1) exact duplicates: same size first, then full SHA-256
  const bySize=new Map();
  files.forEach(f=>{if(!bySize.has(f.size))bySize.set(f.size,[]);bySize.get(f.size).push(f)});
  const cand=[...bySize.values()].filter(a=>a.length>1).flat();
  let done=files.length-cand.length;const byHash=new Map();
  for(const f of cand){
    try{const h=await hashFile(f.p);if(!byHash.has(h))byHash.set(h,[]);byHash.get(h).push(f)}catch{}
    if(++done%10===0)send(done,files.length);
  }
  const exact=[...byHash.values()].filter(a=>a.length>1);
  const inExact=new Set(exact.flat());
  // 2) similar images (resized / recompressed): dHash, Hamming distance <= 5
  const reps=exact.map(a=>({m:a.sort((x,y)=>x.ts-y.ts)}));
  files.filter(f=>f.ty==='img'&&!inExact.has(f)).forEach(f=>reps.push({m:[f]}));
  reps.forEach(r=>{if(r.m[0].ty==='img')r.d=dhash(r.m[0].p)});
  const par=reps.map((_,i)=>i),find=i=>par[i]===i?i:(par[i]=find(par[i]));
  for(let i=0;i<reps.length;i++)if(reps[i].d)for(let j=i+1;j<reps.length;j++)
    if(reps[j].d&&ham(reps[i].d,reps[j].d)<=5)par[find(j)]=find(i);
  const cl=new Map();
  reps.forEach((r,i)=>{const k=find(i);if(!cl.has(k))cl.set(k,[]);cl.get(k).push(r)});
  const groups=[];
  for(const rs of cl.values()){
    const m=rs.flatMap(r=>r.m);if(m.length<2)continue;
    const sim=rs.length>1;if(sim)m.sort((a,b)=>b.size-a.size); // keep highest quality as original
    groups.push({ty:m[0].ty,sim,f:m.map(describe)});
  }
  return{groups,total,count:files.length};
});

ipcMain.handle('trash',async(_,ps)=>{
  const ok=[];
  for(const p of ps){try{await shell.trashItem(p);ok.push(p)}catch{}}
  return ok;
});

app.whenReady().then(()=>{
  const w=new BrowserWindow({width:1000,height:820,backgroundColor:'#eef4f2',
    webPreferences:{preload:path.join(__dirname,'preload.js'),contextIsolation:true,sandbox:true}});
  w.loadFile('renderer/index.html');
});
app.on('window-all-closed',()=>app.quit());
