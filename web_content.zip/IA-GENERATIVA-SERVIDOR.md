# IA generativa real para os NPCs — Aldeia do Reino

Este ZIP inclui um servidor Node.js real que encaminha cada conversa para um modelo de linguagem compatível com a API OpenAI. O contexto enviado pelo jogo inclui nome, raça, personalidade, atributos e memórias recentes, para o modelo responder com voz consistente.

## Limite importante
O servidor está **incluído no ZIP como código**, mas não fica hospedado nem executa automaticamente dentro do APK. Um APK HTML/WebView não pode se transformar sozinho num servidor público. Para respostas generativas reais, hospede a pasta `server/` num serviço HTTPS (o arquivo `server/render.yaml` serve como referência para Render) e configure uma chave de API como variável de ambiente no painel do host. O uso do provedor de IA pode ter custo. Nunca cole a chave no `index.html`, no `game-config.json` ou no ZIP público.

## Passos pelo celular
1. Extraia o ZIP. Crie um repositório privado no GitHub e envie o conteúdo da pasta `server/` (ou o projeto todo).
2. No serviço de hospedagem Node, use a pasta raiz `server`, comando `node server.js`, e Node 18 ou mais recente.
3. Nas variáveis secretas do serviço configure `MODEL_API_KEY`, `MODEL_BASE_URL` e `MODEL_NAME`. Exemplo para um provedor compatível: base `https://api.openai.com/v1`; modelo `gpt-4o-mini`. Use apenas credenciais que você controla e confira preço/limites do provedor.
4. Após publicar, abra `https://SEU-SERVIDOR/health`. Deve aparecer `ok: true` e `configured: true`. Não compartilhe o endereço se tiver exposto informações privadas.
5. Edite `game-config.json` e substitua `narrativeEndpoint` por `https://SEU-SERVIDOR/api/narrative`. Copie o mesmo arquivo para `web/game-config.json` e `www/game-config.json`, depois reempacote e converta o ZIP atualizado para APK.
6. Teste com internet ativa. Se o servidor não responder, o jogo mantém as falas locais como alternativa.

## O que cada personagem envia
O jogo envia o contexto do NPC/monstro, diálogo livre, traços, objetivos, estado e memória recente. O servidor monta um prompt de sistema para manter a interpretação, faz a chamada ao modelo e devolve `{ text }`. Cada personagem não tem um modelo exclusivo rodando em separado: é o mesmo modelo generativo, com um contexto/persona independente por personagem, o que é muito mais leve e barato.

## Privacidade e custo
O texto digitado pelo jogador e o contexto da personagem são enviados ao provedor configurado. Não inclua dados pessoais. Cada conversa pode consumir créditos/tokens. Configure limites no provedor e não exponha sua chave no cliente. O servidor inclui limites básicos de tamanho, timeout e rota de saúde, mas é um ponto de partida, não uma plataforma de produção endurecida contra abuso.
