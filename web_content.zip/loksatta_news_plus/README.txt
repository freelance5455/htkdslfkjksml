लोकसत्ता News Plus

नवीन:
- प्रत्येक बातमीसाठी फोटो थंबनेल + शीर्षक + माहिती/सारांश कार्डवर दिसतो.
- मुख्य बातमी मोठ्या फोटोसह आणि खाली संपूर्ण माहिती.
- वर, मधे आणि खाली जाहिरात बॅनर स्लॉट.
- Admin मधून जाहिरात शीर्षक, मजकूर, बॅनर image URL, click link संपादित करता येते.
- Admin: लोकसत्ता masthead वर 5 वेळा tap करा; password 2026.
- Search, category filter, breaking ticker, saved stories, share, print/PDF, dark mode.
- बातमी जोडताना photo URL द्या. URL थेट public image असावा (jpg/png/webp); image URL नसल्यास placeholder दिसेल.

RUN: index.html browser मध्ये उघडा. PWA install/service worker साठी HTTPS hosting लागते.

IMPORTANT:
- Password 2026 client-side आहे; source inspect करून मिळू शकतो. Hidden admin entry security नाही.
- Admin content browser localStorage मध्ये आहे; इतर visitors/devices मध्ये sync होत नाही. Public production साठी Firebase/Supabase auth + database + storage rules जोडणे आवश्यक आहे.
- No live-news API or real advertising network is configured. Ad banner is a manual sponsor slot; only use authorized ad/media assets.
- This is website/PWA source, not an APK. Independent project; no claim of affiliation with official Loksatta newspaper.
