PIANO PRO — PREMIER PROTOTYPE
=============================

Ce dossier contient une première version fonctionnelle de l'application Piano Pro.

FONCTIONS INCLUSES
- Bibliothèque d'accords : majeur, mineur, 7, maj7, m7, diminué, augmenté, sus4, add9, m9, 9 et 6.
- Affichage des notes composant chaque accord.
- Renversements (rotation des notes) et écoute des accords.
- Clavier virtuel interactif avec notes sélectionnées en surbrillance.
- Suggestions de transitions Jazz, Blues, Gospel et Rock/Pop.
- Exercices de doigté et coordination avec notes et doigtés.
- Idées de voicings par couleur musicale.
- Son produit par le navigateur, sans fichier audio externe.
- Mise en cache pour utilisation hors ligne après le premier chargement sur un hébergement HTTPS.

COMMENT TESTER SUR ANDROID
1. Décompresse le fichier ZIP.
2. Pour un test rapide, ouvre index.html dans un navigateur compatible.
3. Pour que le mode hors ligne et l'installation fonctionnent correctement, héberge le dossier sur un site HTTPS (par exemple GitHub Pages), ouvre le site avec Chrome Android, puis choisis « Ajouter à l'écran d'accueil ».
4. Le premier chargement doit se faire avec Internet pour mettre les fichiers en cache. Ensuite, les fonctions principales fonctionnent hors ligne.

IMPORTANT
- Ceci est un prototype web installable (PWA), pas encore un APK Android natif.
- Le clavier et les sons sont une première base. Le contenu pédagogique et les doigtés doivent être vérifiés/complétés avec un professeur ou un musicien.
- Les accords de passage proposés sont des exemples harmoniques, pas des règles obligatoires.
- La police externe peut ne pas se charger hors ligne ; l'application utilise des polices de secours.
- Pour publier sur Play Store, il faudra ensuite emballer la PWA dans une application Android (par exemple avec Capacitor), tester sur plusieurs appareils et préparer les éléments de publication.

FICHIERS
- index.html : structure de l'application
- styles.css : design responsive
- app.js : logique musicale et interactions
- manifest.webmanifest : métadonnées installables
- sw.js : cache hors ligne
