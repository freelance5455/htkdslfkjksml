const NOTE_NAMES = ["C","C♯","D","D♯","E","F","F♯","G","G♯","A","A♯","B"];
const ROOTS = NOTE_NAMES;
const TYPES = [
  {id:"maj",label:"Majeur",suffix:"",short:"Maj",ints:[0,4,7]},
  {id:"min",label:"Mineur",suffix:"m",short:"Min",ints:[0,3,7]},
  {id:"7",label:"7e dominante",suffix:"7",short:"7",ints:[0,4,7,10]},
  {id:"maj7",label:"Majeur 7",suffix:"maj7",short:"Maj7",ints:[0,4,7,11]},
  {id:"min7",label:"Mineur 7",suffix:"m7",short:"m7",ints:[0,3,7,10]},
  {id:"dim",label:"Diminué",suffix:"dim",short:"Dim",ints:[0,3,6]},
  {id:"aug",label:"Augmenté",suffix:"aug",short:"Aug",ints:[0,4,8]},
  {id:"sus4",label:"Suspendu 4",suffix:"sus4",short:"Sus4",ints:[0,5,7]},
  {id:"add9",label:"Ajout 9",suffix:"add9",short:"Add9",ints:[0,4,7,14]},
  {id:"m9",label:"Mineur 9",suffix:"m9",short:"m9",ints:[0,3,7,10,14]},
  {id:"9",label:"Neuvième",suffix:"9",short:"9",ints:[0,4,7,10,14]},
  {id:"6",label:"Sixte",suffix:"6",short:"6",ints:[0,4,7,9]}
];
let selectedRoot=0, selectedType="maj", selectedInversion=0, selectedTab="chords", activeExercise=0, activeMood="jazz", soundOn=true;
const $=id=>document.getElementById(id);
const mod=n=>(n%12+12)%12;
const note=n=>NOTE_NAMES[mod(n)];
function fillSelect(id){$(id).innerHTML=ROOTS.map((n,i)=>`<option value="${i}">${n}</option>`).join("");}
fillSelect("rootSelect");fillSelect("keySelect");
$("rootSelect").value="0";$("keySelect").value="0";
$("rootSelect").addEventListener("change",e=>{selectedRoot=+e.target.value;renderChords();renderPiano(currentHighlight());});
$("keySelect").addEventListener("change",renderPassing);
function currentType(){return TYPES.find(t=>t.id===selectedType)||TYPES[0]}
function chordNotes(root,type){return type.ints.map(i=>mod(root+i))}
function chordLabel(root,type){return note(root)+" "+type.label}
function renderTypeFilters(){
  $("chordTypes").innerHTML=TYPES.map(t=>`<button class="chip ${t.id===selectedType?"active":""}" data-type="${t.id}">${t.short}</button>`).join("");
  $("chordTypes").querySelectorAll("button").forEach(b=>b.onclick=()=>{selectedType=b.dataset.type;selectedInversion=0;renderTypeFilters();renderChords();renderPiano(currentHighlight())});
}
function renderChords(){
  const t=currentType(), notes=chordNotes(selectedRoot,t);
  $("chordGrid").innerHTML=TYPES.map(x=>`<button class="chord-item ${x.id===selectedType?"selected":""}" data-type="${x.id}">${note(selectedRoot)}${x.suffix}<small>${x.label}</small></button>`).join("");
  $("chordGrid").querySelectorAll("button").forEach(b=>b.onclick=()=>{selectedType=b.dataset.type;selectedInversion=0;renderTypeFilters();renderChords();renderPiano(currentHighlight())});
  $("chordTitle").textContent=chordLabel(selectedRoot,t);
  $("chordNotes").textContent="Notes : "+notes.map(note).join(" – ");
  const invs=Array.from({length:notes.length},(_,i)=>i);
  $("inversions").innerHTML=invs.map(i=>`<button class="segment ${i===selectedInversion?"active":""}" data-inv="${i}">${i===0?"État fond.":i===1?"1er":i===2?"2e":"3e"}</button>`).join("");
  $("inversions").querySelectorAll("button").forEach(b=>b.onclick=()=>{selectedInversion=+b.dataset.inv;renderChords();renderPiano(currentHighlight())});
  const rotated=notes.slice(selectedInversion).concat(notes.slice(0,selectedInversion));
  $("inversionNotes").textContent="Disposition : "+rotated.map(note).join(" – ")+" (notes réorganisées pour le renversement).";
  $("playChord").onclick=()=>playNotes(rotated.map(n=>n+48));
}
function currentHighlight(){return chordNotes(selectedRoot,currentType())}
function renderPiano(highlight=[]){
  const piano=$("piano");piano.innerHTML="";
  const start=48, count=24, whiteNotes=[];
  for(let i=0;i<count;i++){let n=start+i;if(![1,3,6,8,10].includes(mod(n))){whiteNotes.push(n)}}
  whiteNotes.forEach(n=>{const b=document.createElement("button");b.className="white-key"+(highlight.includes(mod(n))?" active":"");b.textContent=note(n);b.onclick=()=>playNotes([n]);piano.appendChild(b)});
  // Place black keys relative to the white-key sequence.
  whiteNotes.forEach((n,index)=>{const next=mod(n+1);if([1,3,6,8,10].includes(next)){const b=document.createElement("button");b.className="black-key"+(highlight.includes(next)?" active":"");b.style.left=`${((index+1)/whiteNotes.length)*100}%`;b.textContent=note(next);b.onclick=()=>playNotes([n+1]);piano.appendChild(b)}});
}
let audioCtx;
function playNotes(ns){
  if(!soundOn)return;
  try{audioCtx ||= new (window.AudioContext||window.webkitAudioContext)();ns.forEach((n,i)=>{const osc=audioCtx.createOscillator(),gain=audioCtx.createGain();osc.type="triangle";osc.frequency.value=440*Math.pow(2,(n-69)/12);gain.gain.setValueAtTime(.0001,audioCtx.currentTime+i*.045);gain.gain.exponentialRampToValueAtTime(.12,audioCtx.currentTime+i*.045+.02);gain.gain.exponentialRampToValueAtTime(.0001,audioCtx.currentTime+i*.045+.8);osc.connect(gain).connect(audioCtx.destination);osc.start(audioCtx.currentTime+i*.045);osc.stop(audioCtx.currentTime+i*.045+.85)})}catch(e){console.log(e)}
}
$("soundToggle").onclick=()=>{soundOn=!soundOn;$("soundToggle").textContent=soundOn?"🔊 Son":"🔇 Muet";$("keyboardHint").textContent=soundOn?"Les notes de l'accord sont colorées.":"Son coupé."};
document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>{document.querySelectorAll(".tab,.panel").forEach(x=>x.classList.remove("active"));b.classList.add("active");$(b.dataset.tab).classList.add("active");selectedTab=b.dataset.tab;if(selectedTab==="passing")renderPassing();if(selectedTab==="exercises")renderExercise();if(selectedTab==="voicings")renderVoicings()});

const PROGS=[
 {id:"145",label:"I – IV – V",degrees:[0,5,7],names:["I (tonique)","IV (sous-dominante)","V (dominante)"]},
 {id:"1645",label:"I – vi – IV – V",degrees:[0,9,5,7],names:["I","vi","IV","V"]},
 {id:"251",label:"ii – V – I",degrees:[2,7,0],names:["ii","V","I"]},
 {id:"1564",label:"I – V – vi – IV",degrees:[0,7,9,5],names:["I","V","vi","IV"]}
];
const PASSING={
 jazz:[
  ["Approche chromatique","Cmaj7 → C♯dim7 → Dm7 → G7 → Cmaj7","Utilise l'accord diminué comme petite marche vers l'accord suivant."],
  ["ii – V – I","Dm7 → G7 → Cmaj7","La progression classique du jazz pour revenir à la tonique."],
  ["Dominante secondaire","Cmaj7 → A7 → Dm7 → G7","A7 attire l'oreille vers Dm7."]
 ],
 blues:[
  ["Dominantes 7","C7 → F7 → G7 → C7","Donne une couleur blues aux trois accords principaux."],
  ["Accord de passage diminué","C7 → C♯dim7 → Dm7 → G7","Une transition chromatique courte et expressive."],
  ["Turnaround blues","C7 → A7 → D7 → G7","Une chaîne de dominantes qui ramène vers C7."]
 ],
 gospel:[
  ["Approche par demi-ton","Cmaj7 → Bdim7 → F/A → G7","Fais glisser une voix d'un demi-ton pour créer une résolution douce."],
  ["Walk-up gospel","C → C/E → F → F♯dim7 → C/G → G7","La basse monte progressivement vers l'accord suivant."],
  ["Couleur riche","Cmaj9 → E7♭9 → Am9 → Dm9 → G13","Ajoute des 9e et 13e pour une sonorité gospel/jazz."]
 ],
 rock:[
  ["Power chords","C5 → F5 → G5 → C5","Joue les fondamentales et quintes pour un son direct."],
  ["Basse de liaison","C → G/B → Am → F","La basse descend par degrés conjoints."],
  ["Suspension","C → Csus4 → C → G","La quarte suspendue crée une tension qui se résout."]
 ]
};
function renderPassing(){
 const key=+$("keySelect").value, genre=$("genreSelect").value, prog=PROGS.find(p=>p.id===($("progressionButtons").dataset.selected||"145"));
 $("progressionButtons").innerHTML=PROGS.map(p=>`<button class="${p.id===prog.id?"active":""}" data-prog="${p.id}">${p.label}</button>`).join("");
 $("progressionButtons").dataset.selected=prog.id;
 $("progressionButtons").querySelectorAll("button").forEach(b=>b.onclick=()=>{$("progressionButtons").dataset.selected=b.dataset.prog;renderPassing()});
 $("progressionTitle").textContent=`En ${note(key)} : ${prog.label}`;
 const ideas=PASSING[genre];
 $("passingIdeas").innerHTML=ideas.map((x,i)=>`<div class="idea"><strong>${i+1}. ${x[0]}</strong><p>${transposeChordText(x[1],key)}<br>${x[2]}</p></div>`).join("");
}
function transposeChordText(text,key){if(key===0)return text;const map={"C":0,"D":2,"E":4,"F":5,"G":7,"A":9,"B":11};return text.replace(/\b([CDEFGAB])([#b]?)/g,(m,l,acc)=>{let n=mod(map[l]+(acc==="#"?1:acc==="b"?-1:0)+key);return note(n)})}

const EXERCISES=[
 {title:"Gamme de Do majeur",desc:"Do – Ré – Mi – Fa – Sol – La – Si – Do",notes:[60,62,64,65,67,69,71,72],fingers:["1","2","3","1","2","3","4","5"],tip:"Travaille lentement, doigts arrondis. Main droite : 1-2-3, passage du pouce, puis 1-2-3-4-5."},
 {title:"Indépendance des mains",desc:"Main gauche : Do – Sol. Main droite : Do – Mi – Sol.",notes:[48,55,60,64,67],fingers:["5","1","1","3","5"],tip:"Garde la basse régulière pendant que la main droite joue l'accord."},
 {title:"Accords brisés",desc:"Do – Mi – Sol – Mi, puis recommence.",notes:[60,64,67,64,60],fingers:["1","2","4","2","1"],tip:"Fais sonner chaque note de façon égale, sans accélérer."},
 {title:"Chromatisme",desc:"Do – Do♯ – Ré – Ré♯ – Mi",notes:[60,61,62,63,64],fingers:["1","2","3","4","5"],tip:"Reste détendu et garde les doigts près des touches."}
];
function renderExercise(){
 $("exerciseList").innerHTML=EXERCISES.map((e,i)=>`<button class="exercise-card ${i===activeExercise?"active":""}" data-ex="${i}"><strong>${e.title}</strong><small>${e.desc}</small></button>`).join("");
 $("exerciseList").querySelectorAll("button").forEach(b=>b.onclick=()=>{activeExercise=+b.dataset.ex;renderExercise()});
 const e=EXERCISES[activeExercise];$("exerciseTitle").textContent=e.title;$("exerciseDescription").textContent=e.desc+" — "+e.tip;
 $("fingerings").innerHTML=e.fingers.map((f,i)=>`<span class="finger">${note(e.notes[i])} · doigt ${f}</span>`).join("");
 renderPiano(e.notes.map(mod));
 $("playExercise").onclick=()=>playNotes(e.notes);
}
const MOODS=["jazz","gospel","émotionnel","blues"];
const VOICINGS={
 jazz:[["Maj9 doux","Main gauche : C – G | Main droite : B – D – E","Son ouvert, élégant, idéal pour une ballade jazz."],["ii–V–I","Dm9 : D–A / C–E–F | G13 : G–F / B–E–A | Cmaj9 : C–G / B–D–E","Garde les notes communes entre les accords pour une transition fluide."]],
 gospel:[["Gospel large","Main gauche : C – G | Main droite : E – A – D – G","Un voicing ample qui donne de l'espace au son."],["Montée expressive","Cmaj9 → E7♭9 → Am9 → Dm9 → G13","Fais ressortir la mélodie dans la note la plus aiguë."]],
 émotionnel:[["Ballade émotionnelle","Main gauche : C – G | Main droite : D – E – G – B","Les 9e et 7e apportent une couleur douce et sensible."],["Accord suspendu","Cadd9 → Fmaj7 → Am7 → Gsus4","Laisse résonner les notes communes entre les accords."]],
 blues:[["Blues dominant","Main gauche : C – G | Main droite : Bb – E – A","La 7e et la 9e donnent une couleur blues/jazz."],["Turnaround","C9 → A7♭9 → D9 → G13","Accentue le rythme et fais entendre la résolution."]]
};
function renderVoicings(){
 $("moodButtons").innerHTML=MOODS.map(m=>`<button class="chip ${m===activeMood?"active":""}" data-mood="${m}">${m[0].toUpperCase()+m.slice(1)}</button>`).join("");
 $("moodButtons").querySelectorAll("button").forEach(b=>b.onclick=()=>{activeMood=b.dataset.mood;renderVoicings()});
 $("voicingContent").innerHTML=`<p class="eyebrow">COULEUR ${activeMood.toUpperCase()}</p><h3>Idées de voicings en Do</h3>`+VOICINGS[activeMood].map(v=>`<div class="voicing-example"><strong>${v[0]}</strong><p>${v[1]}</p><p>${v[2]}</p></div>`).join("");
}
renderTypeFilters();renderChords();renderPiano(currentHighlight());renderPassing();renderExercise();renderVoicings();
if("serviceWorker" in navigator && location.protocol.startsWith("http"))navigator.serviceWorker.register("./sw.js").catch(()=>{});
