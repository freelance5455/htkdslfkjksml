# APKForge: import, rebuild, and what to test

## What this version does

- **Share as PDF**: creates `Delivery-Challan-<number>.pdf` (A4, same layout as the printed challan) and opens the phone's share sheet with the file attached. If the share sheet is not available, the PDF downloads instead.
- **Share on WhatsApp**: opens the share sheet with the challan text. WhatsApp is one of the options. Nothing is sent automatically. If the share sheet is unavailable, the message box with **Copy message** appears.
- **Print / Save PDF has been removed.** Android WebView does not show print dialogs, so the button could not work in the APK.
- The app no longer opens `wa.me` links. That is what caused the "web page not available: whatsapp://" error, because the WebView cannot open WhatsApp directly.

Logo, company details, fields, and the printed layout are unchanged.

## Why sharing depends on the APK wrapper

Opening a share sheet or saving a downloaded file are both features the WebView must support. The web page asks for them, but APKForge decides whether they work. The app is built to fall back in order:

1. Share sheet with the PDF attached.
2. Download of the PDF into the phone's Downloads folder, then share it from the Files app (Android's share sheet works for any file).
3. For text, the copy box.

If option 1 never appears and option 2 does not download either, the APKForge WebView is blocking file access. Check the APKForge settings for downloads and file access, or see the last section.

## Step-by-step: import into APKForge and rebuild

1. Unzip `Bhagyalaxmi-Challan-Mobile-Fix-v3.zip` on your computer.
2. Zip the **contents** of the folder so `index.html` sits at the top level. The `assets` folder (including `assets/vendor`) must be included.
3. In APKForge, create or open the project and upload that zip (or select the folder).
4. Set the entry point to `index.html`.
5. In the WebView settings, check these if APKForge offers them: JavaScript on; DOM / local storage on; file access on; downloads allowed; external links opened outside the app.
6. Keep the same package name when rebuilding, so saved challans are kept. Uninstalling erases them.
7. Build the APK, install it, and run the checklist below.

## Phone test checklist

1. Create a challan with recipient, vehicle, transport, and items. Press **Save challan**. It appears in Previous challans.
2. Tap it. All fields return and the status says "Loaded DC-…".
3. Press **Share as PDF**. Expected: share sheet with the PDF. Open the PDF in WhatsApp's preview or another app and check the layout and figures.
4. If no share sheet appears, expect a download. Open the PDF from Downloads and share it.
5. Press **Share on WhatsApp**. Expected: share sheet with the text. Choose WhatsApp, check the message, and do not send unless intended.
6. Press **Save challan** on an empty form. Expected: a message asking for a recipient or an item, and nothing saved.
7. Close and reopen the app. Saved challans should still be listed.

## Known limits

- Built-in PDF fonts cannot print the ₹ sign, so the PDF shows amounts as plain numbers (as the printed sheet does). The WhatsApp text does show ₹.
- Names or addresses using non-Latin scripts (for example Gujarati or Hindi) will not print correctly in the PDF. Use English text for the PDF fields.
- Tested in headless Chromium (66 automated checks, including reading the PDF text and checking a 24-item challan spans two pages). The APK, the APKForge WebView, and the phone share sheet have NOT been tested here.

## If sharing is blocked inside the APK

The web code can't add Android permissions or intents itself. If the phone test shows neither the share sheet nor a download, the wrapper needs native support. The options are to ask APKForge's support whether its WebView allows downloads and the Web Share API, or to use a different wrapper that does. Opening the same `index.html` in Chrome on the phone also supports the share sheet and PDF download directly.
