# APKForge: import, rebuild, and wrapper requirements

## What changed in this version

| File | Change |
|---|---|
| `app.js` | Rewritten with the same structure. Saved-challan clicks use one delegated handler (no duplicate listeners). Storage reads validate the data and never throw. Storage writes are guarded and report failures. Editing a saved challan updates it; a duplicate challan number from another record is refused. Empty challans (no number, or no recipient and no items) are refused. Item serial numbers stay continuous after adding and removing rows. Typing a transport name that matches a saved one (for example "porter") reuses the saved spelling instead of blanking the field. Adds the WhatsApp message builder, the WhatsApp opener with a fallback, and an honest print handler. |
| `index.html` | Adds the **Share on WhatsApp** button and the "WhatsApp message" box with **Copy message**. Nothing else in the layout or branding changed. |
| `styles.css` | Adds the green WhatsApp button colour, a `[hidden]` rule so the message box stays hidden until used, and lets the header buttons wrap into a 2-column grid on narrow phones. |
| `README.md` | Updated for WhatsApp sharing and the print limitation. |
| `tests/smoke-test.py` | New optional browser test (45 checks). |

Logo, colours, fields, print layout, and the company details are unchanged.

## Bugs found in the original code

1. **Malformed saved data crashed startup.** If the stored challan data was not a list, the history and number logic threw an error during startup. The app then rendered nothing useful, which looks like "buttons do nothing". Reproduced and fixed.
2. **Saving an empty challan** created a blank "Unnumbered" record. Now refused with a message.
3. **Transport name spelling.** Typing "porter" when "Porter" existed blanked the Transport field. Reproduced and fixed.
4. **Item numbering** skipped a number after removing a row and adding one. Reproduced and fixed.
5. **Storage writes were not guarded.** A refused write threw silently, so a failed save looked like a successful one. Now reports "NOT saved".
6. **Print** called `window.print()` and then showed a message based on a check that always ran too early to mean anything. Replaced with an honest message.

**Saved challans not opening on the phone.** In the Chromium browser test, tapping a saved challan loads all fields correctly both on a phone-sized screen and on desktop. I could not run the APK itself, so I cannot confirm the exact cause on your phone. Possible causes include bug 1 (the app failing at startup when stored data is damaged) and the three overlapping tap handlers in the original, which are now a single handler. If the problem persists on the phone, tell me what appears in the status line when you tap a challan. Loading a challan also now shows a clear "Loaded DC-0001" message and scrolls to the form, so you can see that it worked.

## Printing: what works and what does not

Android WebView, which APKForge uses, does not show a print dialog by default. Calling `window.print()` does nothing unless the wrapper implements printing. This is a limitation of the wrapper, not something the web page can fix. The app now:

- uses a native print bridge if the wrapper provides one (see below),
- otherwise calls `window.print()` and says clearly that printing depends on the app wrapper,
- and offers WhatsApp sharing as the working alternative.

No PDF file is created or attached by this app. Shared messages are text.

## Step-by-step: import into APKForge and rebuild

I could not open APKForge's own screens from here, so menu names may differ slightly. Check each setting below in your APKForge version.

1. Unzip `Bhagyalaxmi-Challan-Mobile-Fix.zip` on your computer. You should see `index.html`, `app.js`, `styles.css`, `README.md`, `APKFORGE-NOTES.md`, `tests/`, and `assets/`.
2. Zip the **contents** of the project folder so that `index.html` is at the top level of the zip (not inside an extra folder). Name it, for example, `Bhagyalaxmi-Challan.zip`.
3. In APKForge, create a new project (or open your existing one) and upload that zip, or select the project folder.
4. Set the start page / entry point to `index.html`.
5. Check these WebView settings if APKForge offers them, because the app needs them:
   - JavaScript: **on**.
   - DOM storage / local storage: **on** (saved challans depend on it).
   - Allow file access: **on** if the app loads from local files.
   - Handle external links / intents: **on**, so that `https://wa.me/` opens WhatsApp instead of loading inside the app. Without this, the WhatsApp button falls back to the copy-message box.
6. Set the app name, icon and package name as before.
7. Build / rebuild the APK and install it on the phone (allow installation from this source if prompted).
8. Test on the phone using the checklist in the next section.
9. Keep the same package name when updating, so existing saved data is kept. Uninstalling the app erases its saved challans.

## Phone test checklist

1. Create a challan with recipient, vehicle, transport, and at least one item with NOS and one with SET. Press **Save challan**. It appears under Previous challans.
2. Tap that challan. All fields come back and the status says "Loaded DC-…".
3. Change the vehicle number and save. The list still has one entry for that challan.
4. Close the app completely, reopen it, and confirm the challan is still listed.
5. Press **Share on WhatsApp**. WhatsApp opens with the message filled in. Check the company name, number, date, recipient, vehicle, transport, items, NOS/SET, amounts, and total. Do not press send unless you want to.
6. If WhatsApp did not open, press **Copy message** and paste it into WhatsApp manually.
7. Press **Save challan** on an empty form. It should show "Add a recipient or at least one item…" and not save.
8. Press **Print / Save PDF**. If no print sheet appears, that is the wrapper limitation above. Use the Chrome route in the README instead.

## Optional native bridge (only if your wrapper can run custom Java)

The web app calls two optional functions if they exist. APKForge may not allow custom code, in which case the app uses its fallbacks and nothing else is needed.

- `ChallanNative.shareWhatsApp(text)`: open WhatsApp with `text` pre-filled (for example, an `ACTION_SEND` intent with `setPackage("com.whatsapp")` and `EXTRA_TEXT`).
- `ChallanNative.printChallan()`: print the current page through the WebView's print adapter (`PrintManager` with `webView.createPrintDocumentAdapter(...)`). The page already contains print styles for A4 portrait.

Register the object with `webView.addJavascriptInterface(object, "ChallanNative")` and annotate each method with `@JavascriptInterface`. This has not been built or tested inside APKForge.

## What has been tested, and what has not

Tested here, in headless Chromium with a phone-sized and a desktop viewport (`python tests/smoke-test.py`, 45 checks passing): save, reopen, edit without duplicating, duplicate-number refusal, persistence across reload, WhatsApp message content and encoding (spaces, ₹, ampersand, line breaks), blocked-WhatsApp fallback, native bridge hook, empty and incomplete challans, malformed stored data, storage write failure, serial numbers, and transport spelling.

Not tested here: the APK itself, APKForge's settings and build, a real Android WebView, real WhatsApp hand-off on a phone, and printing in any wrapper. These need the phone checklist above.
