T.HABIBE – DIGITAL IT VAULT | VERSION RENFORCÉE AR / FR
======================================================

FONCTIONS / FONCTIONNALITÉS
- Coffre de mots de passe, adresses IP et inventaire du matériel.
- Interface arabe / français avec bouton de changement de langue.
- Chiffrement local AES-256-GCM avec PBKDF2-SHA-256 (600 000 itérations) et sel/IV aléatoires.
- Compatibilité de lecture des anciennes sauvegardes chiffrées (format précédent).
- Sauvegarde et restauration chiffrées.
- Verrouillage automatique après 5 minutes d'inactivité.
- Blocage temporaire après 5 tentatives de connexion échouées.
- Mot de passe initial obligatoirement remplacé lors de la première connexion.
- Masquage des mots de passe enregistrés et effacement du presse-papiers après 30 secondes lorsque le navigateur l'autorise.
- Fonctionnement local après installation PWA; aucune synchronisation serveur.

PREMIÈRE CONNEXION
Utilisateur : T.habibe
Mot de passe temporaire : 1997
Le mot de passe 1997 ne peut servir qu'à la première ouverture. L'application impose ensuite une phrase secrète d'au moins 12 caractères. Utilisez une phrase longue, unique et difficile à deviner.

INSTALLATION ANDROID
1. Publiez le contenu de ce dossier sur un hébergement HTTPS.
2. Ouvrez l'adresse dans Chrome Android.
3. Menu Chrome > Installer l'application / Ajouter à l'écran d'accueil.
4. Ouvrez l'application depuis son icône. Après le premier chargement, les fichiers de l'application sont mis en cache pour une utilisation hors ligne.

IMPORTANT – LIMITES DE SÉCURITÉ
- Cette application est un outil personnel local, pas un gestionnaire d'entreprise certifié ni un coffre audité professionnellement.
- Les données chiffrées sont stockées dans le stockage local du navigateur sur cet appareil. La suppression des données du navigateur ou la perte du téléphone peut entraîner une perte définitive. Exportez régulièrement une sauvegarde chiffrée.
- La sauvegarde ne peut être ouverte qu'avec le mot de passe qui l'a créée.
- Ne partagez jamais votre phrase secrète ni vos fichiers de sauvegarde. Protégez également le téléphone par un code/PIN et chiffrement du système.
- Évitez d'y enregistrer les identifiants d'infrastructures critiques ou des mots de passe administrateur à privilèges élevés sans audit indépendant.
- Utilisez uniquement HTTPS ou localhost : les API cryptographiques du navigateur exigent un contexte sécurisé.
- Le verrouillage automatique et le blocage des tentatives sont des protections applicatives, pas une protection contre un appareil déjà compromis ou un navigateur malveillant.
- Les données ne sont pas synchronisées entre le téléphone et le PC.

DEVELOPPÉ PAR / DEVELOPED BY
TIRACHE HABIBE ALLAH
