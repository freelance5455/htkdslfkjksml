import os
import sys


# ==========================================
# CRESCIA AI
# PUNTO DE INICIO PRINCIPAL
# ==========================================

DIRECTORIO_BASE = os.path.dirname(
    os.path.abspath(__file__)
)

DIRECTORIO_BACKEND = os.path.join(
    DIRECTORIO_BASE,
    "backend"
)


if DIRECTORIO_BACKEND not in sys.path:

    sys.path.insert(
        0,
        DIRECTORIO_BACKEND
    )


from servidor import app
from config import PUERTO_SERVIDOR


# ==========================================
# INICIAR APLICACIÓN
# ==========================================

if __name__ == "__main__":

    print()

    print("=" * 45)

    print("CRESCIA AI")

    print("Iniciando sistema...")

    print("=" * 45)

    print()

    print(
        "Servidor disponible en:"
    )

    print(
        "http://127.0.0.1:"
        + str(PUERTO_SERVIDOR)
    )

    print()

    app.run(

        host="127.0.0.1",

        port=PUERTO_SERVIDOR,

        debug=False,

        use_reloader=False

    )