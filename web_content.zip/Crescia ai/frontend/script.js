const chat = document.getElementById("chat");
const mensaje = document.getElementById("mensaje");
const enviar = document.getElementById("enviar");


function agregarMensaje(texto, tipo) {

    const elemento = document.createElement("div");

    elemento.className = "mensaje " + tipo;

    elemento.textContent = texto;

    chat.appendChild(elemento);

    chat.scrollTop = chat.scrollHeight;

}


function mostrarEscribiendo() {

    const elemento = document.createElement("div");

    elemento.className = "mensaje ia escribiendo";

    elemento.id = "crescia-escribiendo";

    elemento.textContent =
        "Crescia está pensando...";

    chat.appendChild(elemento);

    chat.scrollTop = chat.scrollHeight;

}


function quitarEscribiendo() {

    const elemento = document.getElementById(
        "crescia-escribiendo"
    );

    if (elemento) {

        elemento.remove();

    }

}


async function enviarMensaje() {

    const texto = mensaje.value.trim();


    if (!texto) {

        mensaje.focus();

        return;

    }


    agregarMensaje(
        texto,
        "usuario"
    );


    mensaje.value = "";


    enviar.disabled = true;


    mostrarEscribiendo();


    try {

        const respuestaServidor =
            await fetch(

                "/api/chat",

                {

                    method: "POST",

                    headers: {

                        "Content-Type":
                            "application/json"

                    },

                    body: JSON.stringify({

                        mensaje: texto

                    })

                }

            );


        const datos =
            await respuestaServidor.json();


        quitarEscribiendo();


        if (!datos.correcto) {

            agregarMensaje(

                datos.error ||
                "Ocurrió un error.",

                "ia"

            );

        } else {

            agregarMensaje(

                datos.respuesta,

                "ia"

            );

        }


    } catch (error) {

        quitarEscribiendo();


        agregarMensaje(

            "No pude conectar con el cerebro de Crescia AI.",

            "ia"

        );


        console.error(error);

    }


    enviar.disabled = false;

    mensaje.focus();

}


enviar.addEventListener(
    "click",
    enviarMensaje
);


mensaje.addEventListener(

    "keydown",

    function(evento) {

        if (
            evento.key === "Enter" &&
            !evento.shiftKey
        ) {

            evento.preventDefault();

            enviarMensaje();

        }

    }

);


async function comprobarCrescia() {

    try {

        const respuesta =
            await fetch(
                "/api/estado"
            );

        const datos =
            await respuesta.json();


        console.log(

            "Crescia AI:",

            datos

        );

    } catch (error) {

        console.error(

            "No se pudo conectar con Crescia.",

            error

        );

    }

}


comprobarCrescia();