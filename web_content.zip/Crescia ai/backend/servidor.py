import os
import sys
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS


# ==========================================
# CONFIGURACIÓN DE RUTAS
# ==========================================

DIRECTORIO_BACKEND = os.path.dirname(
    os.path.abspath(__file__)
)

DIRECTORIO_PROYECTO = os.path.dirname(
    DIRECTORIO_BACKEND
)

DIRECTORIO_FRONTEND = os.path.join(
    DIRECTORIO_PROYECTO,
    "frontend"
)


# Permite importar los módulos del backend
if DIRECTORIO_BACKEND not in sys.path:

    sys.path.insert(
        0,
        DIRECTORIO_BACKEND
    )


import crescia

from config import (
    NOMBRE_IA,
    VERSION,
    PUERTO_SERVIDOR
)


# ==========================================
# CREAR APLICACIÓN
# ==========================================

app = Flask(
    __name__,
    static_folder=DIRECTORIO_FRONTEND,
    static_url_path=""
)

CORS(app)


# ==========================================
# PREPARAR CRESCIA AI
# ==========================================

try:

    crescia.preparar_sistema()

    print(
        NOMBRE_IA
        + " preparada correctamente."
    )

except Exception as error:

    print(
        "Error preparando Crescia AI:"
    )

    print(error)


# ==========================================
# PÁGINA PRINCIPAL
# ==========================================

@app.route("/", methods=["GET"])
def inicio():

    return send_from_directory(
        DIRECTORIO_FRONTEND,
        "index.html"
    )


# ==========================================
# ARCHIVOS DEL FRONTEND
# ==========================================

@app.route("/<path:archivo>", methods=["GET"])
def archivos_frontend(archivo):

    return send_from_directory(
        DIRECTORIO_FRONTEND,
        archivo
    )


# ==========================================
# ESTADO DEL SISTEMA
# ==========================================

@app.route("/api/estado", methods=["GET"])
def estado():

    return jsonify({

        "correcto": True,

        "nombre": NOMBRE_IA,

        "version": VERSION,

        "estado": "activo"

    })


# ==========================================
# CHAT
# ==========================================

@app.route("/api/chat", methods=["POST"])
def chat():

    try:

        datos = request.get_json(
            silent=True
        )

        if not datos:

            return jsonify({

                "correcto": False,

                "error":
                "No se recibieron datos."

            }), 400


        mensaje = str(

            datos.get(
                "mensaje",
                ""
            )

        ).strip()


        if not mensaje:

            return jsonify({

                "correcto": False,

                "error":
                "El mensaje está vacío."

            }), 400


        respuesta = crescia.procesar_mensaje(
            mensaje
        )


        return jsonify({

            "correcto": True,

            "ia": NOMBRE_IA,

            "respuesta": respuesta

        })


    except Exception as error:

        print(
            "Error en el chat:"
        )

        print(error)


        return jsonify({

            "correcto": False,

            "error":
            "Ocurrió un error interno."

        }), 500


# ==========================================
# INICIAR SERVIDOR
# ==========================================

if __name__ == "__main__":

    print()

    print("=" * 50)

    print(
        NOMBRE_IA
        + " - SERVIDOR"
    )

    print(
        "Versión:",
        VERSION
    )

    print("=" * 50)

    print()

    print(
        "Frontend:"
    )

    print(
        DIRECTORIO_FRONTEND
    )

    print()

    print(
        "Servidor iniciado en:"
    )

    print(
        "http://127.0.0.1:"
        + str(PUERTO_SERVIDOR)
    )

    print()

    app.run(

        host="127.0.0.1",

        port=PUERTO_SERVIDOR,

        debug=False

    )