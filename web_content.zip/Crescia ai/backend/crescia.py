import json
import os
import re
import unicodedata
from datetime import datetime


# ==================================================
# CONFIGURACIÓN PRINCIPAL
# ==================================================

NOMBRE_IA = "Crescia AI"

ARCHIVO_MEMORIA = "memoria_crescia.json"
ARCHIVO_HISTORIAL = "historial_crescia.json"
ARCHIVO_PERFIL = "perfil_usuario.json"
ARCHIVO_CONTEXTO = "contexto_crescia.json"
ARCHIVO_FUENTES = "fuentes_crescia.json"
ARCHIVO_CONOCIMIENTO_EXTERNO = "conocimiento_externo.json"

MAX_MENSAJES_CONTEXTO = 12


# ==================================================
# UTILIDADES DE ARCHIVOS
# ==================================================

def crear_archivo_si_no_existe(nombre_archivo, contenido_inicial):

    if os.path.exists(nombre_archivo):
        return

    try:

        with open(
            nombre_archivo,
            "w",
            encoding="utf-8"
        ) as archivo:

            json.dump(
                contenido_inicial,
                archivo,
                ensure_ascii=False,
                indent=4
            )

    except Exception as error:

        print(
            "Error creando:",
            nombre_archivo
        )

        print(error)


def cargar_json(nombre_archivo, valor_predeterminado):

    crear_archivo_si_no_existe(
        nombre_archivo,
        valor_predeterminado
    )

    try:

        with open(
            nombre_archivo,
            "r",
            encoding="utf-8"
        ) as archivo:

            return json.load(archivo)

    except json.JSONDecodeError:

        print(
            "Archivo dañado:",
            nombre_archivo
        )

        guardar_json(
            nombre_archivo,
            valor_predeterminado
        )

        return valor_predeterminado

    except Exception as error:

        print(
            "Error cargando:",
            nombre_archivo
        )

        return valor_predeterminado


def guardar_json(nombre_archivo, datos):

    try:

        with open(
            nombre_archivo,
            "w",
            encoding="utf-8"
        ) as archivo:

            json.dump(
                datos,
                archivo,
                ensure_ascii=False,
                indent=4
            )

        return True

    except Exception as error:

        print(
            "Error guardando:",
            nombre_archivo
        )

        print(error)

        return False


# ==================================================
# NORMALIZACIÓN DE TEXTO
# ==================================================

def normalizar_texto(texto):

    texto = str(texto).lower().strip()

    texto = unicodedata.normalize(
        "NFD",
        texto
    )

    texto = "".join(
        caracter
        for caracter in texto
        if unicodedata.category(caracter) != "Mn"
    )

    texto = re.sub(
        r"[^a-z0-9ñ\s]",
        " ",
        texto
    )

    texto = re.sub(
        r"\s+",
        " ",
        texto
    ).strip()

    return texto


def obtener_palabras_importantes(texto):

    palabras = normalizar_texto(texto).split()

    ignoradas = {

        "el", "la", "los", "las",
        "un", "una", "unos", "unas",
        "de", "del", "y", "o",
        "a", "en", "es", "son",
        "para", "por", "con",
        "como", "que", "mi",
        "tu", "me", "te",
        "se", "lo", "le",
        "sobre", "quiero",
        "puedes", "puede",
        "dime", "cual",
        "este", "esta", "esto",
        "eso", "al", "si",
        "no", "porque"
    }

    resultado = []

    for palabra in palabras:

        if palabra in ignoradas:
            continue

        if len(palabra) < 3:
            continue

        resultado.append(
            palabra
        )

    return resultado


# ==================================================
# MEMORIA PRINCIPAL
# ==================================================

def cargar_memoria():

    return cargar_json(
        ARCHIVO_MEMORIA,
        []
    )


def guardar_memoria(memoria):

    return guardar_json(
        ARCHIVO_MEMORIA,
        memoria
    )


def aprender(
    tema,
    informacion,
    fuente="Información proporcionada por el usuario"
):

    tema = tema.strip()
    informacion = informacion.strip()

    if not tema or not informacion:

        return False, (
            "El tema y la información "
            "no pueden estar vacíos."
        )

    memoria = cargar_memoria()

    nuevo_conocimiento = {

        "id": len(memoria) + 1,

        "tema": tema,

        "informacion": informacion,

        "fuente": fuente,

        "fecha": datetime.now().strftime(
            "%Y-%m-%d %H:%M:%S"
        ),

        "veces_utilizado": 0

    }

    memoria.append(
        nuevo_conocimiento
    )

    guardar_memoria(
        memoria
    )

    return True, (
        "He guardado información sobre "
        + tema
        + "."
    )


def buscar_conocimiento(mensaje):

    memoria = cargar_memoria()

    mensaje_normalizado = normalizar_texto(
        mensaje
    )

    palabras = obtener_palabras_importantes(
        mensaje
    )

    mejor_resultado = None
    mejor_puntuacion = 0

    for conocimiento in memoria:

        tema = conocimiento.get(
            "tema",
            ""
        )

        informacion = conocimiento.get(
            "informacion",
            ""
        )

        tema_normalizado = normalizar_texto(
            tema
        )

        informacion_normalizada = normalizar_texto(
            informacion
        )

        puntuacion = 0

        if tema_normalizado in mensaje_normalizado:

            puntuacion += 20

        for palabra in palabras:

            if palabra in tema_normalizado:

                puntuacion += 8

            if palabra in informacion_normalizada:

                puntuacion += 2

        if puntuacion > mejor_puntuacion:

            mejor_puntuacion = puntuacion
            mejor_resultado = conocimiento

    if mejor_resultado:

        if mejor_puntuacion > 0:

            mejor_resultado[
                "veces_utilizado"
            ] = (
                mejor_resultado.get(
                    "veces_utilizado",
                    0
                ) + 1
            )

            guardar_memoria(
                memoria
            )

            return mejor_resultado

    return None


# ==================================================
# PERFIL DEL USUARIO
# ==================================================

def cargar_perfil():

    predeterminado = {

        "nombre": "",

        "datos": {},

        "fecha_creacion": datetime.now().strftime(
            "%Y-%m-%d %H:%M:%S"
        )

    }

    return cargar_json(
        ARCHIVO_PERFIL,
        predeterminado
    )


def guardar_perfil(perfil):

    return guardar_json(
        ARCHIVO_PERFIL,
        perfil
    )


def guardar_dato_usuario(clave, valor):

    perfil = cargar_perfil()

    clave = normalizar_texto(
        clave
    )

    valor = str(valor).strip()

    if not clave or not valor:

        return False

    perfil["datos"][clave] = valor

    guardar_perfil(
        perfil
    )

    return True


# ==================================================
# CONTEXTO RECIENTE
# ==================================================

def cargar_contexto():

    return cargar_json(
        ARCHIVO_CONTEXTO,
        []
    )


def guardar_contexto(contexto):

    return guardar_json(
        ARCHIVO_CONTEXTO,
        contexto
    )


def agregar_contexto(tipo, contenido):

    contexto = cargar_contexto()

    contexto.append({

        "tipo": tipo,

        "contenido": contenido,

        "fecha": datetime.now().strftime(
            "%Y-%m-%d %H:%M:%S"
        )

    })

    if len(contexto) > MAX_MENSAJES_CONTEXTO:

        contexto = contexto[
            -MAX_MENSAJES_CONTEXTO:
        ]

    guardar_contexto(
        contexto
    )


# ==================================================
# FUENTES CONFIABLES
# ==================================================

def fuentes_predeterminadas():

    return [

        {

            "nombre": "Wikipedia",

            "url": "https://www.wikipedia.org",

            "tipo": "Enciclopedia",

            "activa": True

        },

        {

            "nombre": "NASA",

            "url": "https://www.nasa.gov",

            "tipo": "Ciencia y espacio",

            "activa": True

        },

        {

            "nombre": "Organización Mundial de la Salud",

            "url": "https://www.who.int",

            "tipo": "Salud",

            "activa": True

        }

    ]


def cargar_fuentes():

    return cargar_json(
        ARCHIVO_FUENTES,
        fuentes_predeterminadas()
    )


def guardar_fuentes(fuentes):

    return guardar_json(
        ARCHIVO_FUENTES,
        fuentes
    )


def mostrar_fuentes():

    fuentes = cargar_fuentes()

    print("\n" + "=" * 50)

    print("FUENTES CONFIGURADAS")

    print("=" * 50)

    for numero, fuente in enumerate(
        fuentes,
        start=1
    ):

        estado = (
            "ACTIVA"
            if fuente.get("activa")
            else "INACTIVA"
        )

        print(
            "\n"
            + str(numero)
            + ". "
            + fuente.get("nombre", "")
        )

        print(
            "URL:",
            fuente.get("url", "")
        )

        print(
            "Estado:",
            estado
        )


# ==================================================
# CONOCIMIENTO EXTERNO
# ==================================================

def cargar_conocimiento_externo():

    return cargar_json(
        ARCHIVO_CONOCIMIENTO_EXTERNO,
        []
    )


def guardar_conocimiento_externo(datos):

    return guardar_json(
        ARCHIVO_CONOCIMIENTO_EXTERNO,
        datos
    )


def guardar_resultado_externo(
    consulta,
    contenido,
    fuente,
    url=""
):

    resultados = cargar_conocimiento_externo()

    nuevo_resultado = {

        "id": len(resultados) + 1,

        "consulta": consulta,

        "contenido": contenido,

        "fuente": fuente,

        "url": url,

        "fecha": datetime.now().strftime(
            "%Y-%m-%d %H:%M:%S"
        ),

        "verificado": False

    }

    resultados.append(
        nuevo_resultado
    )

    guardar_conocimiento_externo(
        resultados
    )

    return nuevo_resultado


def mostrar_resultados_externos():

    resultados = cargar_conocimiento_externo()

    print("\n" + "=" * 50)

    print(
        "RESULTADOS EXTERNOS GUARDADOS"
    )

    print("=" * 50)

    if not resultados:

        print(
            "Todavía no hay resultados externos."
        )

        return

    for resultado in resultados:

        print(
            "\nID:",
            resultado.get("id")
        )

        print(
            "Consulta:",
            resultado.get("consulta")
        )

        print(
            "Fuente:",
            resultado.get("fuente")
        )

        print(
            "Contenido:",
            resultado.get("contenido")
        )

        if resultado.get("url"):

            print(
                "URL:",
                resultado.get("url")
            )


# ==================================================
# SIMULAR RECEPCIÓN DE INFORMACIÓN EXTERNA
# ==================================================

def agregar_informacion_externa():

    print("\n" + "=" * 50)

    print(
        "AGREGAR INFORMACIÓN EXTERNA"
    )

    print("=" * 50)

    consulta = input(
        "¿Qué buscaste? "
    ).strip()

    contenido = input(
        "Información encontrada: "
    ).strip()

    fuente = input(
        "Nombre de la fuente: "
    ).strip()

    url = input(
        "URL de la fuente (opcional): "
    ).strip()

    if not consulta:

        print(
            "La consulta no puede estar vacía."
        )

        return

    if not contenido:

        print(
            "La información no puede estar vacía."
        )

        return

    if not fuente:

        fuente = "Fuente desconocida"

    resultado = guardar_resultado_externo(
        consulta,
        contenido,
        fuente,
        url
    )

    print(
        "\nInformación externa guardada."
    )

    print(
        "ID:",
        resultado["id"]
    )

    print(
        "Esta información todavía NO "
        "ha sido añadida automáticamente "
        "a la memoria principal."
    )


# ==================================================
# VERIFICAR Y APRENDER
# ==================================================

def verificar_resultado(id_resultado):

    resultados = cargar_conocimiento_externo()

    resultado_encontrado = None

    for resultado in resultados:

        if resultado.get("id") == id_resultado:

            resultado_encontrado = resultado

            break

    if not resultado_encontrado:

        return False, (
            "No encontré ese resultado."
        )

    print("\n" + "=" * 50)

    print("INFORMACIÓN PARA REVISAR")

    print("=" * 50)

    print(
        "Consulta:",
        resultado_encontrado.get(
            "consulta"
        )
    )

    print(
        "\nContenido:\n",
        resultado_encontrado.get(
            "contenido"
        )
    )

    print(
        "\nFuente:",
        resultado_encontrado.get(
            "fuente"
        )
    )

    confirmacion = input(
        "\n¿Quieres añadir esta información "
        "a la memoria? (si/no): "
    ).strip().lower()

    if confirmacion not in [
        "si",
        "sí",
        "s"
    ]:

        return False, (
            "La información no fue añadida."
        )

    resultado_encontrado[
        "verificado"
    ] = True

    guardar_conocimiento_externo(
        resultados
    )

    aprender(
        resultado_encontrado[
            "consulta"
        ],
        resultado_encontrado[
            "contenido"
        ],
        resultado_encontrado[
            "fuente"
        ]
    )

    return True, (
        "Información verificada y guardada "
        "en la memoria principal."
    )


# ==================================================
# RESPUESTAS BÁSICAS
# ==================================================

def generar_respuesta_basica(mensaje):

    texto = normalizar_texto(
        mensaje
    )

    saludos = [
        "hola",
        "buenas",
        "hey"
    ]

    for saludo in saludos:

        if saludo in texto:

            return (
                "¡Hola! Soy "
                + NOMBRE_IA
                + ". ¿En qué puedo ayudarte?"
            )

    if (
        "quien eres" in texto
        or
        "como te llamas" in texto
    ):

        return (
            "Soy "
            + NOMBRE_IA
            + ". Actualmente estoy desarrollando "
            "mi memoria y mi sistema de conocimientos."
        )

    if (
        "que puedes hacer" in texto
        or
        "que sabes hacer" in texto
    ):

        return (
            "Puedo conversar, recordar conocimientos, "
            "guardar información y organizar resultados "
            "externos para su revisión."
        )

    return None


# ==================================================
# PROCESAR MENSAJES
# ==================================================

def procesar_mensaje(mensaje):

    mensaje = mensaje.strip()

    if not mensaje:

        return (
            "No he recibido ningún mensaje."
        )

    agregar_contexto(
        "usuario",
        mensaje
    )

    respuesta_basica = generar_respuesta_basica(
        mensaje
    )

    if respuesta_basica:

        agregar_contexto(
            "crescia",
            respuesta_basica
        )

        return respuesta_basica

    conocimiento = buscar_conocimiento(
        mensaje
    )

    if conocimiento:

        respuesta = (
            "Esto es lo que recuerdo sobre "
            + conocimiento.get(
                "tema",
                ""
            )
            + ":\n\n"
            + conocimiento.get(
                "informacion",
                ""
            )
            + "\n\nFuente: "
            + conocimiento.get(
                "fuente",
                "No especificada"
            )
        )

        agregar_contexto(
            "crescia",
            respuesta
        )

        return respuesta

    respuesta = (
        "Todavía no tengo suficiente información "
        "sobre ese tema en mi memoria. "
        "En esta fase puedo almacenar y organizar "
        "información externa, pero una búsqueda web "
        "real requerirá conectar una fuente o servicio "
        "de búsqueda en una fase posterior."
    )

    agregar_contexto(
        "crescia",
        respuesta
    )

    return respuesta


# ==================================================
# MODO APRENDIZAJE
# ==================================================

def modo_aprendizaje():

    print("\n--- ENSEÑAR A CRESCIA AI ---")

    tema = input(
        "Tema: "
    ).strip()

    informacion = input(
        "Información: "
    ).strip()

    if not tema or not informacion:

        print(
            "El tema y la información "
            "son obligatorios."
        )

        return

    exito, respuesta = aprender(
        tema,
        informacion
    )

    print(
        NOMBRE_IA
        + ":",
        respuesta
    )


# ==================================================
# AYUDA
# ==================================================

def mostrar_ayuda():

    print("\n" + "=" * 50)

    print("COMANDOS DISPONIBLES")

    print("=" * 50)

    print(
        "/aprender  - Enseñar información"
    )

    print(
        "/memoria   - Ver conocimientos guardados"
    )

    print(
        "/fuentes   - Ver fuentes configuradas"
    )

    print(
        "/externo   - Agregar información externa"
    )

    print(
        "/resultados - Ver información externa"
    )

    print(
        "/verificar - Revisar un resultado externo"
    )

    print(
        "/ayuda     - Mostrar comandos"
    )

    print(
        "salir      - Cerrar Crescia AI"
    )


# ==================================================
# MOSTRAR MEMORIA
# ==================================================

def mostrar_memoria():

    memoria = cargar_memoria()

    print("\n" + "=" * 50)

    print("MEMORIA DE CRESCIA AI")

    print("=" * 50)

    if not memoria:

        print(
            "No hay conocimientos guardados."
        )

        return

    for conocimiento in memoria:

        print(
            "\nTema:",
            conocimiento.get(
                "tema"
            )
        )

        print(
            "Información:",
            conocimiento.get(
                "informacion"
            )
        )

        print(
            "Fuente:",
            conocimiento.get(
                "fuente"
            )
        )


# ==================================================
# PREPARAR SISTEMA
# ==================================================

def preparar_sistema():

    crear_archivo_si_no_existe(
        ARCHIVO_MEMORIA,
        []
    )

    crear_archivo_si_no_existe(
        ARCHIVO_HISTORIAL,
        []
    )

    crear_archivo_si_no_existe(
        ARCHIVO_PERFIL,
        {

            "nombre": "",

            "datos": {},

            "fecha_creacion": datetime.now().strftime(
                "%Y-%m-%d %H:%M:%S"
            )

        }
    )

    crear_archivo_si_no_existe(
        ARCHIVO_CONTEXTO,
        []
    )

    crear_archivo_si_no_existe(
        ARCHIVO_FUENTES,
        fuentes_predeterminadas()
    )

    crear_archivo_si_no_existe(
        ARCHIVO_CONOCIMIENTO_EXTERNO,
        []
    )


# ==================================================
# CHAT PRINCIPAL
# ==================================================

def iniciar_chat():

    print("\n" + "=" * 55)

    print(
        "CRESCIA AI — FASE 4"
    )

    print(
        "Sistema de conocimiento externo preparado."
    )

    print(
        "Escribe /ayuda para ver los comandos."
    )

    print("=" * 55)

    while True:

        try:

            mensaje = input(
                "\nTú: "
            ).strip()

        except KeyboardInterrupt:

            print(
                "\nCrescia AI se ha cerrado."
            )

            break

        if not mensaje:

            continue

        comando = mensaje.lower()

        if comando == "salir":

            print(
                "\nCrescia AI: ¡Hasta luego!"
            )

            break

        elif comando == "/ayuda":

            mostrar_ayuda()

        elif comando == "/aprender":

            modo_aprendizaje()

        elif comando == "/memoria":

            mostrar_memoria()

        elif comando == "/fuentes":

            mostrar_fuentes()

        elif comando == "/externo":

            agregar_informacion_externa()

        elif comando == "/resultados":

            mostrar_resultados_externos()

        elif comando == "/verificar":

            try:

                id_resultado = int(
                    input(
                        "ID del resultado: "
                    )
                )

                exito, respuesta = verificar_resultado(
                    id_resultado
                )

                print(
                    "\nCrescia AI:",
                    respuesta
                )

            except ValueError:

                print(
                    "Debes introducir un número."
                )

        else:

            respuesta = procesar_mensaje(
                mensaje
            )

            print(
                "\nCrescia AI:",
                respuesta
            )


# ==================================================
# INICIAR PROGRAMA
# ==================================================

if __name__ == "__main__":

    preparar_sistema()

    iniciar_chat()