import os


# ==========================================
# INFORMACIÓN DE LA APLICACIÓN
# ==========================================

NOMBRE_IA = "Crescia AI"

VERSION = "1.0.0"

PUERTO_SERVIDOR = 5000


# ==========================================
# DIRECTORIOS
# ==========================================

DIRECTORIO_BACKEND = os.path.dirname(
    os.path.abspath(__file__)
)

DIRECTORIO_PROYECTO = os.path.dirname(
    DIRECTORIO_BACKEND
)

DIRECTORIO_DATOS = os.path.join(
    DIRECTORIO_PROYECTO,
    "data"
)


# ==========================================
# CREAR CARPETA DE DATOS
# ==========================================

os.makedirs(

    DIRECTORIO_DATOS,

    exist_ok=True

)


# ==========================================
# ARCHIVOS DE MEMORIA
# ==========================================

ARCHIVO_MEMORIA = os.path.join(

    DIRECTORIO_DATOS,

    "memoria_crescia.json"

)


ARCHIVO_HISTORIAL = os.path.join(

    DIRECTORIO_DATOS,

    "historial_crescia.json"

)


ARCHIVO_PERFIL = os.path.join(

    DIRECTORIO_DATOS,

    "perfil_usuario.json"

)


ARCHIVO_CONTEXTO = os.path.join(

    DIRECTORIO_DATOS,

    "contexto_crescia.json"

)


ARCHIVO_FUENTES = os.path.join(

    DIRECTORIO_DATOS,

    "fuentes_crescia.json"

)


ARCHIVO_CONOCIMIENTO_EXTERNO = os.path.join(

    DIRECTORIO_DATOS,

    "conocimiento_externo.json"

)