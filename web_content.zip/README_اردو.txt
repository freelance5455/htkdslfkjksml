Irfan Baloch Mobile Repairing Shop — Firebase Integration

1) index.html: آپ کی اصل ایپ، تقریباً جوں کی توں؛ Cloud بٹن شامل کیا گیا ہے۔
2) cloud.html: Google Sign-In کے ذریعے مالک کا دستی JSON کلاؤڈ بیک اَپ۔
3) firestore.rules: مالک کے UID کے لیے محفوظ رولز کا نمونہ۔

اہم: یہ مکمل خودکار Cloud Sync نہیں ہے۔ ملازمین کے مشترکہ ریکارڈ، حقیقی وقت کی Sync، Google Drive اور Gmail API فی الحال شامل نہیں۔ یہ فیچرز محفوظ سرور سائیڈ اجازتوں اور Android OAuth کی اضافی ترتیب مانگتے ہیں۔

سیٹ اپ:
- cloud.html کو HTTPS پر Host کریں؛ file:// یا بعض Android WebView میں Google Sign-In نہیں چلے گا۔
- Firebase Authentication > Settings > Authorized domains میں اپنی hosting domain شامل کریں۔
- اپنے Google سے پہلی بار login کریں، cloud.html پر UID دکھائی دے گا۔
- firestore.rules میں OWNER_UID کو اپنے اصل UID سے بدلیں اور Firestore Rules میں Publish کریں۔
- اصل ایپ سے JSON Export کریں اور cloud.html میں منتخب کر کے Upload کریں۔
- Firestore کی ایک document حد تقریباً 1 MiB ہے؛ اس ڈیمو میں 750 KB سے بڑی فائل روکی جاتی ہے۔ تصاویر والا بیک اَپ بڑا ہو سکتا ہے۔
- Restore سے پہلے موجودہ ڈیٹا کا الگ بیک اَپ محفوظ کریں۔
- Google Login کو Android WebView میں چلانے کے بجائے Chrome/Custom Tab یا Native Google Sign-In کے ساتھ استعمال کریں۔
- Firebase Web API key پاس ورڈ نہیں؛ Firestore Security Rules لازمی ہیں۔
