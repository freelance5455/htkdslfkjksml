# ANONYMOUX STUDIO 2.3.2 — Tools & Tutorials Implementation Report

## Unified resource centre

A single authenticated **Tools & Tutorials** navigation item opens `resources.php`, with two tabs: Creative Tools and Tutorials & Learning. Both support database-backed search, category filtering, featured-first ordering and published-only listing. Legacy `tools.php` and `tutorials.php` URLs redirect to the relevant unified tab.

## Tools directory

Added editable tool records with name, slug, logo, short/full descriptions, category, official website, official download page, Windows/macOS/Linux links, installation instructions, compatibility information, system requirements, free/paid/freemium/unknown label, version, featured flag, publication state and provider review date.

Initial categories include AI media/responsible editing, realtime voice changers, streaming/production and creative production. Seeded provider references include OBS Studio, Voicemod, Clownfish Voice Changer, Voice.ai, VB-CABLE, NVIDIA Broadcast, Audacity, Shotcut, GIMP, HandBrake and Adobe Firefly. External software is clearly identified; downloads link to vendor pages and third-party executable installers are not hosted. Links are HTTPS URLs and can be corrected or unpublished from the admin editor. NVIDIA Broadcast adds the requested microphone-enhancement and virtual camera/microphone category coverage, with its RTX GPU requirements called out rather than implying broad device compatibility.

## Tutorials & learning

Seeded the ten requested starter guides:

1. ANONYMOUX Realtime Studio on Android/mobile.
2. OBS Studio setup for ANONYMOUX.
3. Voicemod installation and setup.
4. Clownfish installation and setup.
5. Connecting voice changers to OBS.
6. Android camera and microphone permissions.
7. AI image references in Image Studio.
8. Video generation job submission and monitoring.
9. Fish Audio Voice Studio.
10. Responsible AI face transformation.

Each tutorial has a title, slug, short/full content, ordered steps, category, estimated reading time, difficulty, featured/published state and last-updated date. Admins can add real screenshots or GIFs and external video links. No fake screenshots/GIFs or invented provider footage are seeded. Video embeds are limited to supported YouTube/Vimeo host names; external links open at the original provider.

## Administrator resource management

The existing admin page includes a Resources section. Every resource write endpoint independently calls `auth_require_admin()` and validates the existing CSRF token. Administrators can:

- Create, edit, feature, publish/unpublish and delete tools.
- Upload/replace tool logos and set official/platform links and compatibility details.
- Create, edit, feature, publish/unpublish and delete tutorials.
- Edit tutorial body content and reorder the structured steps.
- Upload multiple screenshot/GIF files (8 per submission, max 5 MB each), add captions/alt text and manage external video links.
- Assign related tools and tutorials.
- Create/edit/reorder/disable categories while preserving attached resources.

The editor accepts safe Markdown-like text, headings, lists and HTTPS links. Raw HTML is escaped; SVG uploads are rejected. Media are stored under private `storage/resources/` and delivered through `resource-media.php`, which requires a signed-in user and checks publication state; draft media are admin-only.

## Database

Nine additive tables are introduced: `tool_categories`, `tutorial_categories`, `tools`, `tutorials`, `tutorial_steps`, `tutorial_relations`, `tutorial_media`, `notifications`, and `dashboard_recent_access`. Runtime schema setup is idempotent; explicit SQLite and MySQL migration scripts are supplied under `migrations/`.

## Limits

- No screenshots or GIFs are fabricated. The media slots are ready for genuine administrator uploads.
- Vendor versions, download page layouts and system requirements can change; tool entries should be reviewed periodically by an administrator. A `source_verified_at` date is stored and displayed, but is not a promise of live vendor availability.
- No third-party binary download mirroring or executable hosting is included.
- The PHP runtime available for this build has no PDO database driver. Admin CRUD cannot be live-tested against the application DB in this environment; the SQLite SQL migration is tested separately with Python SQLite.

## Verification

PHP lint, JavaScript syntax checks and SQLite migration tests passed. Live authenticated CRUD, uploads, cross-user isolation and browser rendering remain deployment checks; see `TEST_RESULTS.md` and `SECURITY_VERIFICATION_REPORT.md`.


## Official vendor source checks

Initial website/download destinations were checked against provider-owned pages on 2026-11-11. The seeded records use the official destinations below rather than third-party installer mirrors:

- OBS Project: https://obsproject.com/download/
- Voicemod Help Center: https://support.voicemod.net/hc/en-us/articles/360018501820-Download-Voicemod
- Clownfish: https://www.clownfishvoicechanger.net/download/
- Voice.ai: https://voice.ai/platforms/pc
- VB-Audio: https://vb-audio.com/Cable/
- NVIDIA Broadcast: https://www.nvidia.com/en-us/geforce/broadcasting/broadcast-app/
- Audacity: https://www.audacityteam.org/download/
- Shotcut: https://www.shotcut.org/download/
- GIMP: https://www.gimp.org/downloads/
- HandBrake: https://handbrake.fr/downloads.php
- Adobe Firefly: https://firefly.adobe.com/

Version strings describe a point-in-time listing and should be reviewed by administrators before recommending an update. The catalogue stores provider review dates so that stale metadata can be rechecked.
