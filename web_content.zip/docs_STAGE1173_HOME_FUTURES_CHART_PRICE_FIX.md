# CryptoPulse Stage 1173 — Home Price + Spot/Futures Chart Fix

Base: Stage 1172.

## Fixes
- Home rendered-row selector corrected to use `a.home-coin-main`, so visible lower rows are prioritized for price hydration.
- Home missing-price hydration keeps LBank as the primary source and now tries the current documented LBank REST host first, then legacy aliases.
- Home immediately warms Binance/CoinCap secondary feeds on entry so symbols temporarily absent from the LBank snapshot can still display a price; CoinPaprika is warmed shortly after.
- Secondary-feed updates are persisted into the shared live cache.
- Fresh values from any provider whose source is LBank are protected from secondary overwrite.
- Spot chart: native LBank K-line REST remains primary, with a native OkHttp WebSocket one-shot K-line fallback. The LBank WebSocket callback now supports request IDs correctly.
- Spot chart draws a visible live fallback while historical candles are unavailable instead of leaving a blank canvas.
- Futures chart draws a live sampled-price fallback while native sampled candles are being accumulated; live contract price/order book remain authoritative.
- Startup remains forced to Home.

## Validation
- JavaScript syntax checked with Node `--check` for `app.js`, `spot.html`, and `futures.html` inline scripts.
- Android APK was not built here because the supplied project does not contain a Gradle wrapper and the environment has no global Gradle installation.
