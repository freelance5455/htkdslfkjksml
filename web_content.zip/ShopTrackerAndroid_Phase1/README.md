# Shop Tracker Android — Phase 1

Version 1.3 adds Phase 1 data protection plus account/session improvements:
- Manual JSON backup and restore from the app
- Backup excludes the account password
- Schema versioning and migration for future app updates
- Existing Shop Tracker data is migrated into the current data structure without intentionally discarding supported fields
- Android system file picker is used to save/open backup files
- Persistent sign-in on the same phone so the user normally enters the app without re-entering credentials
- Switch account and sign out controls for multiple local users on the same phone

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync and install the required Android SDK (compile SDK 35).
3. Select **Build > Build APK(s)**.
4. The debug APK will be under `app/build/outputs/apk/debug/`.

## Using backup
Open **Home → Backup & Restore**.
- **Export backup**: choose a location and save the `.json` file.
- **Import backup**: select a Shop Tracker backup. The app asks for confirmation before replacing the current shop data.

Keep backup files somewhere safe. They contain business records such as stock, cash, debts and movements.
