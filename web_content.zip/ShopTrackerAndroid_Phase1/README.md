# Shop Tracker 2.0 — Cloud-ready build

This build keeps the working local/offline app and adds:
- edit/delete controls across sales, stock, cash and debts
- a Cloud tab for cross-device accounts
- Firebase Email/Password authentication via the web REST API
- Cloud Firestore sync for one private shop-data document per cloud user
- local-first behavior: the app still works without internet
- automatic delayed cloud upload after local changes when a cloud account is connected

## Important: Firebase setup is required for cloud access

The app will continue to work offline with cloud disabled until `app/src/main/assets/firebase-config.js` is filled in.

1. Create a Firebase project.
2. Add a Web app to the Firebase project.
3. Enable Authentication → Sign-in method → Email/Password.
4. Create a Cloud Firestore database.
5. Put the Web app's `apiKey` and Firebase project ID in `firebase-config.js`.
6. Deploy Firestore security rules that allow each signed-in user to access only their own `/shopUsers/{uid}` document.

Do not put a Firebase service-account private key in the app.

Suggested Firestore rules shape:

```text
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /shopUsers/{uid} {
      allow read, write: if request.auth != null && request.auth.uid == uid;
    }
  }
}
```

The rule above is intentionally narrow for the current data model. Test rules before production use.

## Data behavior

- Creating a cloud account uploads the current device's shop data.
- Signing into an existing cloud account checks for cloud data and lets the user restore it or keep/upload the current phone data.
- Local changes are saved immediately. When cloud is connected, an automatic delayed sync is attempted.
- A manual Sync now button is available in the Cloud tab.

## Build

This project still requires an Android build environment (Android Studio/SDK or another Gradle-capable Android environment). No APK is included in this source archive.
