# Biztrack 3.0

This build keeps the working local/offline app and adds:
- edit/delete controls across sales, stock, cash and debts
- a Cloud tab for cross-device accounts
- Firebase Email/Password authentication via the web REST API
- Cloud Firestore sync for one private shop-data document per cloud user
- local-first behavior: the app still works without internet
- automatic delayed cloud upload after local changes when a cloud account is connected

## What changed in 3.0 (access anywhere)
- **Website version**: the `website/` folder is the same app as a website. Put your Firebase `apiKey`/`projectId` in `website/firebase-config.js` (and in `app/src/main/assets/firebase-config.js`), then host it free with Firebase Hosting (`firebase deploy --only hosting` inside `website/`) or any static host. Keep both copies of `index.html` identical (the Android one in `app/src/main/assets` is the source).
- **New phone / computer / lost phone**: the sign-in screen has "Sign in with cloud account". Enter your cloud email and password and your shop records load.
- **Save status** on Home ("Saved to the cloud at 14:05", "Waiting to upload", "Offline"). Recording sales still works offline and uploads later.
- **Forgot password** button for the cloud account (sends a Firebase reset email).
- **In-app forms** replace the pop-up boxes for editing items, sales, cash, debts and stock movements. Dates of sales, cash entries and stock movements can be corrected.
- **Older records**: search sales (item, person, date) and "Show older" for sales and cash.
- **CSV export** of sales and debts (More > Backup & Restore).
- **Restore backup** now shows what the backup contains before replacing anything.
- Renamed to **Biztrack** everywhere (old "Shop Tracker" backups still restore).

## What changed in 2.2 (customer feedback)

**Home screen**
- Redesigned with far fewer boxes: one main cash card, one profit card, a graph, then short lists.
- The Cash at hand card now shows **today's sales and today's profit** inside it.
- **Expected profit** sits directly under Cash at hand (with cost and selling value as a short note).
- New **sales graph for the last 7 days** (today highlighted).
- **Needs attention** is red and names the items that are out of stock or at/below their warning level. Overdue payments show here too.
- **Debts** show a warning sign: "Owes you" (amber), "You owe" (red) and "Overdue" (red), on Home and in the Debts tab. Overdue debts are listed first.
- Backup, cloud sync, team and account moved off Home into a new **More** tab (the old Cloud tab is now a section inside More). The bottom bar has icons.

**Employees (security)**
- Owners add employees in More > Team. Employee accounts share the owner's shop data on this phone.
- Employees only see **Sales** (record a sale, see their own sales) and **Account**. No profit, cost prices, cash, debts, stock, advice, backups or cloud.
- Employees cannot edit or delete sales. Each new sale remembers who recorded it ("by name" shows to the owner).
- Existing accounts automatically become owners.
- Note: this protects the app screens. It is not server-side security, so keep the owner password private.

**Fixes**
- Android: JavaScript confirm/prompt dialogs were silently cancelled (no WebChromeClient), so Edit and Delete buttons and backup restore did nothing. Native dialogs are now shown.
- Backups exported by the app (schema 4) are now accepted when restoring.

## What changed in 2.1 (Cloud tab only)

- The Cloud tab now has a built-in setup form: paste the Firebase `apiKey` and `projectId` in the app (no rebuild needed). Filling in `firebase-config.js` still works too.
- Sync is automatic: changes upload shortly after you make them, and the app pulls newer data from your other phones when opened.
- Signing in on a phone with no data loads the cloud copy straight away. If both sides have data, an on-screen choice appears (the old confirm pop-up never showed inside the Android WebView, which made it silently overwrite the cloud copy).
- Newer cloud data is never overwritten silently by an older phone.
- Clear, plain-language error messages (wrong password, Firestore not created, rules blocking access, no internet).
- Fixed the upload request dropping its Content-Type header.
- Android: WebView is allowed to call Firebase over HTTPS.

## Important: Firebase setup is required for cloud access

The app will continue to work offline with cloud disabled until `app/src/main/assets/firebase-config.js` is filled in.

1. Create a Firebase project.
2. Add a Web app to the Firebase project.
3. Enable Authentication → Sign-in method → Email/Password.
4. Create a Cloud Firestore database.
5. Put the Web app's `apiKey` and Firebase project ID in `firebase-config.js`.
6. Deploy Firestore security rules that allow each signed-in user to access only their own `/shopUsers/{uid}` document.

Do not put a Firebase service-account private key in the app.

Suggested Firestore rules shape:

```text
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /shopUsers/{uid} {
      allow read, write: if request.auth != null && request.auth.uid == uid;
    }
  }
}
```

The rule above is intentionally narrow for the current data model. Test rules before production use.

## Data behavior

- Creating a cloud account uploads the current device's shop data.
- Signing into an existing cloud account checks for cloud data and lets the user restore it or keep/upload the current phone data.
- Local changes are saved immediately. When cloud is connected, an automatic delayed sync is attempted.
- A manual Sync now button is available in the Cloud tab.

## Build

This project still requires an Android build environment (Android Studio/SDK or another Gradle-capable Android environment). No APK is included in this source archive.
