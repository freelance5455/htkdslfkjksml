/*
  MakoBidi cloud configuration.
  Create a Firebase project, enable Email/Password Authentication and Cloud Firestore,
  then replace the empty values below with the web app configuration from Firebase.
  Do NOT put a service-account private key here.
*/
window.SHOP_FIREBASE_CONFIG = {
  apiKey: "",
  projectId: ""
};
