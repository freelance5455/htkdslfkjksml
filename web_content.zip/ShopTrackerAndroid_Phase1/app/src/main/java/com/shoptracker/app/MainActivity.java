package com.shoptracker.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int REQUEST_CREATE_BACKUP = 1001;
    private static final int REQUEST_OPEN_BACKUP = 1002;
    private WebView webView;
    private String pendingBackup = null;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window w = getWindow();
        w.setStatusBarColor(android.graphics.Color.rgb(15,118,110));
        w.setNavigationBarColor(android.graphics.Color.rgb(15,118,110));
        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new BackupBridge(), "AndroidBackup");
        webView.loadUrl("file:///android_asset/index.html");
        setContentView(webView);
    }

    public class BackupBridge {
        @JavascriptInterface public void exportBackup(String filename, String content) {
            pendingBackup = content;
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/json");
                i.putExtra(Intent.EXTRA_TITLE, filename);
                startActivityForResult(i, REQUEST_CREATE_BACKUP);
            });
        }

        @JavascriptInterface public void importBackup() {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/json");
                i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "text/plain"});
                startActivityForResult(i, REQUEST_OPEN_BACKUP);
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            pendingBackup = null;
            return;
        }
        Uri uri = data.getData();
        try {
            if (requestCode == REQUEST_CREATE_BACKUP && pendingBackup != null) {
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new Exception("Could not open backup destination");
                    out.write(pendingBackup.getBytes(StandardCharsets.UTF_8));
                    out.flush();
                }
                pendingBackup = null;
                webView.evaluateJavascript("toast(" + quote("Backup saved successfully.") + ")", null);
            } else if (requestCode == REQUEST_OPEN_BACKUP) {
                String text;
                try (InputStream in = getContentResolver().openInputStream(uri);
                     BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                    StringBuilder b = new StringBuilder(); String line;
                    while ((line = r.readLine()) != null) b.append(line).append('\n');
                    text = b.toString();
                }
                webView.evaluateJavascript("receiveBackup(" + quote(text) + ")", null);
            }
        } catch (Exception e) {
            webView.evaluateJavascript("toast(" + quote("Could not read or save that backup file.") + ")", null);
        }
    }

    private String quote(String s) {
        return org.json.JSONObject.quote(s == null ? "" : s);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
