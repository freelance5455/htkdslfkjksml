# Deploy MakoBidi for free (Firebase Hosting, Spark plan)

One-time setup
1. Install Node.js (nodejs.org), then in a terminal: `npm install -g firebase-tools`
2. `firebase login`
3. Put your apiKey and projectId in `firebase-config.js`.
4. Inside this `website` folder: `firebase init hosting` -> choose your project, public directory `.`, single-page app: No, do NOT overwrite index.html.
5. `firebase deploy --only hosting`  -> your site is live at https://YOUR-PROJECT.web.app

Every time you add a feature
1. Edit `app/src/main/assets/index.html`, then copy it over `website/index.html`.
2. `firebase deploy --only hosting`. Users get the new version the next time they open the site.

Fully automatic (free): put the project on GitHub, run `firebase init hosting:github` once.
After that, every push to your main branch deploys by itself.

Install like an app: open the site in Chrome on the phone > menu > "Install app" / "Add to Home screen".
