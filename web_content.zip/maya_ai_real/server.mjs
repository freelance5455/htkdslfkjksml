import express from 'express';
import OpenAI from 'openai';
import 'dotenv/config';
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';

const app = express();
const port = Number(process.env.PORT || 3000);
const dataDir = process.env.DATA_DIR || './data';
const usersFile = path.join(dataDir, 'users.json');
const sessionSecret = process.env.SESSION_SECRET;
app.use(express.json({ limit: '1mb' }));
app.use(express.static('.'));

async function readUsers(){
  await fs.mkdir(dataDir,{recursive:true});
  try{return JSON.parse(await fs.readFile(usersFile,'utf8'));}
  catch(e){if(e.code==='ENOENT') return []; throw e;}
}
async function saveUsers(users){await fs.mkdir(dataDir,{recursive:true});await fs.writeFile(usersFile,JSON.stringify(users,null,2),{mode:0o600});}
function sign(value){return crypto.createHmac('sha256',sessionSecret).update(value).digest('base64url');}
function makeToken(user){const payload=Buffer.from(JSON.stringify({id:user.id,email:user.email,exp:Date.now()+7*24*60*60*1000})).toString('base64url');return payload+'.'+sign(payload);}
function getSession(req){
  const token=(req.headers.cookie||'').split(';').map(x=>x.trim()).find(x=>x.startsWith('maya_session='))?.slice('maya_session='.length);
  if(!token)return null;
  const [payload,signature]=token.split('.');if(!payload||!signature)return null;
  const expected=sign(payload);
  const a=Buffer.from(signature),b=Buffer.from(expected);
  if(a.length!==b.length||!crypto.timingSafeEqual(a,b))return null;
  try{const data=JSON.parse(Buffer.from(payload,'base64url').toString());return data.exp>Date.now()?data:null;}catch{return null;}
}
function requireAuth(req,res,next){const session=getSession(req);if(!session)return res.status(401).json({error:'Pehle apne account mein login karein.'});req.user=session;next();}
function setSession(res,user){const secure=process.env.NODE_ENV==='production'?'; Secure':'';res.setHeader('Set-Cookie',`maya_session=${makeToken(user)}; HttpOnly; SameSite=Lax; Path=/; Max-Age=604800${secure}`);}

app.post('/api/signup',async(req,res)=>{
  try{
    const email=String(req.body?.email||'').trim().toLowerCase();
    const password=String(req.body?.password||'');
    if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))return res.status(400).json({error:'Sahi email address daalein.'});
    if(password.length<8)return res.status(400).json({error:'Password kam se kam 8 characters ka hona chahiye.'});
    const users=await readUsers();if(users.some(u=>u.email===email))return res.status(409).json({error:'Is email se account pehle se bana hua hai. Login karein.'});
    const salt=crypto.randomBytes(16).toString('hex');
    const hash=crypto.scryptSync(password,salt,64).toString('hex');
    const user={id:crypto.randomUUID(),email,salt,hash,createdAt:new Date().toISOString()};
    users.push(user);await saveUsers(users);setSession(res,user);
    res.json({ok:true,user:{email}});
  }catch(e){console.error(e);res.status(500).json({error:'Account nahi ban paya. Server dobara try karein.'});}
});
app.post('/api/login',async(req,res)=>{
  try{
    const email=String(req.body?.email||'').trim().toLowerCase();const password=String(req.body?.password||'');
    const users=await readUsers();const user=users.find(u=>u.email===email);
    if(!user)return res.status(401).json({error:'Email ya password galat hai.'});
    const hash=crypto.scryptSync(password,user.salt,64).toString('hex');
    if(hash.length!==user.hash.length||!crypto.timingSafeEqual(Buffer.from(hash,'hex'),Buffer.from(user.hash,'hex')))return res.status(401).json({error:'Email ya password galat hai.'});
    setSession(res,user);res.json({ok:true,user:{email}});
  }catch(e){console.error(e);res.status(500).json({error:'Login nahi ho paya.'});}
});
app.post('/api/logout',(req,res)=>{res.setHeader('Set-Cookie','maya_session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0');res.json({ok:true});});
app.get('/api/me',(req,res)=>{const user=getSession(req);res.json({loggedIn:!!user,user:user?{email:user.email}:null});});

app.post('/api/chat',requireAuth,async(req,res)=>{
  try{
    if(!process.env.OPENAI_API_KEY)return res.status(503).json({error:'Maya AI abhi setup nahi hui hai. App ke owner ko AI service configure karni hogi.'});
    const messages=req.body?.messages;
    if(!Array.isArray(messages)||messages.length===0)return res.status(400).json({error:'Message nahi mila.'});
    const safeMessages=messages.slice(-20).map(m=>({role:m.role==='assistant'?'assistant':'user',content:String(m.content||'').slice(0,4000)}));
    const client=new OpenAI({apiKey:process.env.OPENAI_API_KEY});
    const response=await client.responses.create({model:process.env.OPENAI_MODEL||'gpt-5.5',instructions:'You are Maya, a warm, helpful AI companion. Reply naturally in the language the user uses, especially Hindi or Hinglish. Be honest that you are an AI. Do not claim to be human or to have feelings, a body, or real-world experiences. Keep replies clear and conversational.',input:safeMessages});
    res.json({reply:response.output_text||'Maaf kijiye, main abhi jawab nahi bana paayi.'});
  }catch(error){console.error('Chat API error:',error?.message||error);res.status(500).json({error:'AI service mein dikkat aayi. Server owner ko AI setup check karna hoga.'});}
});

if(!sessionSecret)console.warn('WARNING: SESSION_SECRET set nahi hai. Production mein strong secret zaroor set karein.');
app.listen(port,()=>console.log(`Maya AI running on port ${port}`));
