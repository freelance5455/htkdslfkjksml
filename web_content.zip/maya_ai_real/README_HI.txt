MAYA AI - SIGNUP / LOGIN VERSION

Ab users app ke andar email aur password se Signup ya Login kar sakte hain. Har user ko apni API key nahi deni padegi. User accounts server par password hashing ke saath store hote hain.

ZAROORI BAAT: Signup se AI service khud-ba-khud free nahi hoti. App owner/administrator ko server hosting ke Environment Variables mein OPENAI_API_KEY ek baar set karni hogi. Key user ko nahi dikhai jaati aur HTML mein nahi rakhi gayi. API provider ke usage charges lag sakte hain.

RUN:
1. ZIP extract karein.
2. Node.js 20+ install karein.
3. Folder mein terminal kholkar npm install chalayein.
4. .env.example ki copy .env naam se banayein.
5. .env mein OPENAI_API_KEY aur ek lamba random SESSION_SECRET set karein.
6. npm start chalayein aur http://localhost:3000 kholein.

HOSTING:
Node.js hosting par poora project deploy karein. Environment Variables/Secrets mein OPENAI_API_KEY, SESSION_SECRET aur zaroorat par OPENAI_MODEL set karein. Persistent storage/volume enable karein, kyunki users ka data DATA_DIR mein save hota hai. HTTPS zaroor use karein.

NOTE: Yeh starter authentication hai. Public commercial launch se pehle email verification, password reset, rate limiting, database backups aur privacy policy add karna chahiye.
