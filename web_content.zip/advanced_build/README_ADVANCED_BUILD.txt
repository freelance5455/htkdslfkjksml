AUTO TEXT COLOR — ADVANCED BUILD PACKAGE V9

এই ZIP-টি Advanced Build-এ Web/HTML content হিসেবে ব্যবহার করার জন্য সাজানো।
মূল index.html ZIP-এর root-এর ভিতরে advanced_build/index.html-এ আছে।

প্রস্তাবিত:
• App name: AUTO TEXT COLOR
• Package: com.autotextcolor.tv
• Orientation: Any
• Internet permission: প্রয়োজন নেই
• Camera/Microphone permission: প্রয়োজন নেই
• Android 7.1.2 / পুরোনো WebView লক্ষ্য করে তৈরি

TV:
• Touch support
• Remote Arrow + OK/Enter navigation
• Settings focus navigation
• বড় AUTO / SAVE / PDF / SHARE buttons

গুরুত্বপূর্ণ:
Advanced Build-এ যদি HTML/ZIP import option থাকে, এই ZIP ব্যবহার করুন।
