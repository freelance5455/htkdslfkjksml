/* Android bridge client. Matches EdoBridge.kt: invoke(id, method, jsonArgs) → __edoBridgeResult(id, ok, payload).
   Hardened: typed errors, per-method timeouts, retry ONLY for idempotent reads, capability detection, late-reply safety.
   Never retries call / openApp / requestPermissions / notify (a retry could place two calls or show two prompts). */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;
  /* v2: structured. Every method name here is implemented in EdoBridge.kt (a test enforces it). The first nine are the original protocol. */
  const METHODS = ["ping", "capabilities", "deviceInfo", "openApp", "notify", "findContact", "call", "permissions", "requestPermissions",
    "cancel", "appList", "batteryStatus", "networkStatus", "clipboardRead", "clipboardWrite", "share", "openSettings", "calendarEvents", "calendarInsert",
    "pickFile", "pickProject", "mediaControl", "scheduleReminder", "cancelReminder", "mic.state",
    "voice.status", "voice.configureWake", "voice.service", "tts.speak", "tts.stop", "tts.voices",
    /* protocol v3 (EDO.AndroidBridge): refs, images, OCR, speech recognition, saving, allowlisted app actions */
    "requestPermission", "readFile", "pickImage", "captureImage", "image.data", "ocr.extract", "speech.start", "speech.stop", "download.save", "openSupported", "ref.release"];
  const IDEMPOTENT = new Set(["ping", "capabilities", "deviceInfo", "permissions", "findContact", "appList", "batteryStatus", "networkStatus", "mic.state", "voice.status", "tts.voices", "calendarEvents", "readFile"]);
  const TIMEOUT = { ping: 2500, capabilities: 4000, deviceInfo: 4000, permissions: 4000, findContact: 8000, openApp: 8000, notify: 5000, call: 10000, requestPermissions: 60000,
    cancel: 3000, appList: 8000, batteryStatus: 3000, networkStatus: 3000, clipboardRead: 3000, clipboardWrite: 3000, share: 8000, openSettings: 5000, calendarEvents: 8000, calendarInsert: 8000,
    pickFile: 120000, pickProject: 300000, mediaControl: 3000, scheduleReminder: 5000, cancelReminder: 3000, "mic.state": 3000, "voice.status": 3000, "voice.configureWake": 8000, "voice.service": 8000, "tts.speak": 120000, "tts.stop": 3000, "tts.voices": 5000,
    requestPermission: 60000, readFile: 30000, pickImage: 120000, captureImage: 180000, "image.data": 15000, "ocr.extract": 120000, "speech.start": 150000, "speech.stop": 5000, "download.save": 120000, openSupported: 8000, "ref.release": 3000 };
  /* Never retried automatically: they change the device, show UI, or speak. */
  const ERROR_CODES = ["unavailable", "permission_denied", "unsupported", "invalid_arguments", "not_found", "timeout", "native_error", "cancelled"];
  const LONG_RUNNING = new Set(["pickFile", "pickProject", "requestPermissions", "tts.speak", "requestPermission", "pickImage", "captureImage", "ocr.extract", "speech.start", "download.save"]);
  /* v3 native codes. ERROR_CODES (the original eight) is unchanged so existing callers and tests keep working. */
  const EXTRA_CODES = ["file_too_large", "unsupported_file_type", "ocr_failed", "speech_failed", "busy"];

  /* Honest scope: this client only talks to EdoBridge.kt. None of the v2 methods have been exercised on a device or emulator in this repository's tests. */
  class BridgeError extends Error { constructor(code, message, extra) { super(message); this.name = "BridgeError"; this.code = code; Object.assign(this, extra || {}); } }
  const classifyText = (msg) => (/permission|denied|not granted|SecurityException/i.test(msg) ? "permission_denied" : /unknown method/i.test(msg) ? "unsupported" : /not found|no app|no contact/i.test(msg) ? "not_found" : "native_error");
  const classify = (msg, code) => (ERROR_CODES.includes(code) || EXTRA_CODES.includes(code) ? code : /invalid|illegal ?argument|missing argument|bad argument/i.test(msg) ? "invalid_arguments" : /cancel/i.test(msg) ? "cancelled" : classifyText(msg));
  function readMessage(payload) {
    if (payload && typeof payload === "object") return String(payload.message || JSON.stringify(payload));
    const s = String(payload == null ? "" : payload);
    try { const j = JSON.parse(s); if (j && j.message) return String(j.message); } catch (e) {}
    return s || "unknown bridge error";
  }
  function readCode(payload) {
    try { const j = typeof payload === "string" ? JSON.parse(payload) : payload; return j && typeof j.code === "string" ? j.code : null; } catch (e) { return null; }
  }
  const parse = (raw) => { if (raw && typeof raw === "object") return raw; try { const j = JSON.parse(raw); return j; } catch (e) { return { raw: String(raw) }; } };

  const Bridge = {
    _p: {}, _n: 0, _caps: null, _session: null, _listeners: {}, methods: METHODS.slice(), BridgeError, timeouts: TIMEOUT, ERROR_CODES, EXTRA_CODES,
    available() { return !!(root.EDOAndroid && typeof root.EDOAndroid.invoke === "function"); },
    /* One attempt. Rejects with BridgeError(code: unavailable | timeout | bridge_throw | permission_denied | unsupported | not_found | native_error). */
    callOnce(method, args, timeoutMs, extra) {
      if (!Bridge.available()) return Promise.reject(new BridgeError("unavailable", "Android bridge is not available in this browser."));
      const id = ++Bridge._n;
      if (extra && typeof extra.onId === "function") extra.onId(id);
      const prom = new Promise((res, rej) => {
        const to = setTimeout(() => { delete Bridge._p[id]; rej(new BridgeError("timeout", "Bridge timeout: " + method + " did not answer within " + (timeoutMs || TIMEOUT[method] || 8000) + " ms.", { method })); }, timeoutMs || TIMEOUT[method] || 8000);
        Bridge._p[id] = { res, rej, to, method, onProgress: extra && extra.onProgress };
        try { root.EDOAndroid.invoke(id, method, JSON.stringify(args || {})); }
        catch (e) { clearTimeout(to); delete Bridge._p[id]; rej(new BridgeError("bridge_throw", "Bridge call failed: " + e.message, { method })); }
      });
      return prom;
    },
    /* Cancellable call. Returns {id, promise, cancel()}. Cancelling rejects locally with code "cancelled" at once, tells the native side
       to stop (best effort), and makes any late native reply for this id harmless. A cancelled call() that already reached the
       phone may still have happened; the UI must say "cancel requested", never "undone". */
    callCancelable(method, args, opts) {
      opts = opts || {};
      let id = 0, done = false;
      const handle = { id: 0, promise: null, cancel: () => false };
      handle.promise = new Promise((resolve, reject) => {
        const finish = (fn, v) => { if (done) return; done = true; if (opts.signal) opts.signal.removeEventListener && opts.signal.removeEventListener("abort", onAbort); fn(v); };
        const onAbort = () => cancel();
        const cancel = () => {
          if (done) return false;
          const p = Bridge._p[id];
          if (p) { clearTimeout(p.to); delete Bridge._p[id]; }
          if (id) { try { if (Bridge.available()) root.EDOAndroid.invoke(++Bridge._n, "cancel", JSON.stringify({ target: id })); } catch (e) {} }
          finish(reject, new BridgeError("cancelled", "Cancelled: " + method, { method }));
          return true;
        };
        handle.cancel = cancel;
        if (opts.signal) { if (opts.signal.aborted) return void cancel(); opts.signal.addEventListener && opts.signal.addEventListener("abort", onAbort); }
        Bridge.callOnce(method, args, opts.timeoutMs, { onId: (i) => { id = i; handle.id = i; }, onProgress: opts.onProgress }).then((v) => finish(resolve, v), (e) => finish(reject, e));
      });
      return handle;
    },
    /* Events pushed by the native side: Bridge.on("voice.wake", fn) → unsubscribe function. */
    on(name, fn) { (Bridge._listeners[name] || (Bridge._listeners[name] = [])).push(fn); return () => { const a = Bridge._listeners[name] || []; const i = a.indexOf(fn); if (i >= 0) a.splice(i, 1); }; },
    _emit(name, payload) { (Bridge._listeners[name] || []).slice().concat(Bridge._listeners["*"] || []).forEach((f) => { try { f(payload, name); } catch (e) {} }); },
    supportsSync(method) { return !!(Bridge._caps && Bridge._caps.available && Bridge._caps.methods.includes(method)); },
    /* If the native session changed (activity or process recreated), calls that were in flight can never be answered: reject them as cancelled. */
    async resync() {
      const before = Bridge._session;
      const caps = await Bridge.capabilities(true);
      if (before != null && caps.session != null && caps.session !== before) Bridge._cancelAll("native session changed");
      Bridge._session = caps.session != null ? caps.session : before;
      return caps;
    },
    _cancelAll(why) { Object.keys(Bridge._p).forEach((k) => { const p = Bridge._p[k]; clearTimeout(p.to); delete Bridge._p[k]; p.rej(new BridgeError("cancelled", why || "cancelled", { method: p.method })); }); },
    /* Parsed-object view used by the voice engine and the UI. */
    typed: {
      available: () => Bridge.available(),
      supports: (m) => Bridge.supportsSync(m),
      async call(method, args, opts) { return parse(await Bridge.call(method, args, opts)); },
    },
    async call(method, args, opts) {
      opts = opts || {};
      const attempts = IDEMPOTENT.has(method) ? Math.max(1, opts.retries == null ? 2 : opts.retries + 1) : 1;
      let last;
      for (let i = 0; i < attempts; i++) {
        try { return await Bridge.callOnce(method, args, opts.timeoutMs); }
        catch (e) {
          last = e;
          if (!(e instanceof BridgeError) || !(e.code === "timeout" || e.code === "bridge_throw")) throw e; // only transport failures are retried
          if (i < attempts - 1) await new Promise((r) => setTimeout(r, 150 * (i + 1)));
        }
      }
      throw last;
    },
    /* Ask the native side what it supports; cache the answer. Returns {available, methods:[]}. Never throws. */
    async capabilities(force) {
      if (!Bridge.available()) return { available: false, methods: [], reason: "no native bridge" };
      if (Bridge._caps && !force) return Bridge._caps;
      try {
        const raw = await Bridge.call("capabilities");
        let j; try { j = JSON.parse(raw); } catch (e) { j = {}; }
        Bridge._caps = { available: true, methods: Array.isArray(j.methods) ? j.methods : [], session: j.session != null ? j.session : null, features: j.features || {}, permissions: j.permissions || {}, version: j.version || 1 };
        if (Bridge._session == null && Bridge._caps.session != null) Bridge._session = Bridge._caps.session;
      } catch (e) { return { available: true, methods: [], reason: e.message, code: e.code }; }
      return Bridge._caps;
    },
    async supports(method) { const c = await Bridge.capabilities(); return c.available && c.methods.includes(method); },
    _reset() { Object.keys(Bridge._p).forEach((k) => { clearTimeout(Bridge._p[k].to); }); Bridge._p = {}; Bridge._caps = null; Bridge._session = null; Bridge._listeners = {}; },
  };
  root.__edoBridgeResult = function (id, ok, payload) {
    const p = Bridge._p[id];
    if (!p) return; // late reply after a timeout: ignored on purpose
    clearTimeout(p.to);
    delete Bridge._p[id];
    if (ok) p.res(payload);
    else { const msg = readMessage(payload); p.rej(new BridgeError(classify(msg, readCode(payload)), msg, { method: p.method })); }
  };
  /* progress for a long-running request: native calls __edoBridgeProgress(id, json). It never settles the call. */
  root.__edoBridgeProgress = function (id, payload) { const p = Bridge._p[id]; if (p && p.onProgress) { try { p.onProgress(parse(payload)); } catch (e) {} } };
  /* push events: native calls __edoBridgeEvent(name, json). Unknown names are delivered too; consumers decide. */
  root.__edoBridgeEvent = function (name, payload) { if (typeof name !== "string" || name.length > 60) return; Bridge._emit(name, parse(payload)); };
  root.Bridge = Bridge;
})();
