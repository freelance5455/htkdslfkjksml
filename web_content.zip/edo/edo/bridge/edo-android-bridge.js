/* EDO.AndroidBridge: the documented, promise-based public API for native Android capabilities, with honest browser fallbacks.
   It sits on top of bridge/android-client.js (window.Bridge), which owns the wire protocol: invoke(id, method, json) -> __edoBridgeResult(id, ok, payload),
   per-call timeouts, cancellation, progress, session resync and late-reply safety. This module adds:
     - strict argument validation and bounded payloads BEFORE anything is sent
     - protocol version (_v) on every request, exclusive-operation protection, coalescing of read-only calls
     - structured, sanitized errors (AndroidBridgeError) with stable UPPER_CASE codes; no stack traces, paths or content:// URIs reach the UI
     - capability states: SUPPORTED | UNAVAILABLE | PERMISSION_REQUIRED | NOT_INITIALIZED | UNSUPPORTED_ENVIRONMENT
     - browser fallbacks (file input, FileReader, speech APIs, Clipboard, Web Share, Blob download) that never pretend to be native
   Files and images are addressed by opaque refs ("ref_..."): JavaScript can never hand native code a path or a content URI.
   Scope: nothing here has been run on a device or emulator in this repository; the native side is simulated in tests/androidbridge.js. Globals: EDO.AndroidBridge */
(function () {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;
  root.EDO = root.EDO || {};
  if (root.EDO.AndroidBridge && root.EDO.AndroidBridge.__version) return; // duplicate load: keep the first instance and its listeners

  const PROTOCOL = 3;
  const STATES = ["SUPPORTED", "UNAVAILABLE", "PERMISSION_REQUIRED", "NOT_INITIALIZED", "UNSUPPORTED_ENVIRONMENT"];
  const LIMITS = { clipboardChars: 100000, shareChars: 100000, downloadBytes: 10 * 1024 * 1024, readDefault: 1024 * 1024, readHard: 5 * 1024 * 1024, ocrImages: 10, pickFiles: 20, mimeTypes: 10, timeoutMin: 1000, timeoutMax: 600000, thumbMax: 2048 };
  const TEXT_EXT = ["txt", "md", "json", "csv", "xml", "html", "htm", "css", "js", "ts", "py", "java", "kt", "c", "cpp", "h", "hpp", "cs", "sql", "log", "yml", "yaml"];
  const TEXT_MIME = /^(text\/|application\/(json|xml|javascript|x-javascript|sql|x-sh|x-yaml|yaml|csv))/i;
  const SETTINGS = ["wifi", "bluetooth", "notifications", "app", "battery", "location", "display"];
  const PERMS = ["microphone", "notifications", "contacts", "calls", "location", "calendar"];
  const SAVE_MIME = ["text/plain", "text/markdown", "text/csv", "application/json", "text/html", "application/pdf", "image/png", "image/jpeg"];
  const EXCLUSIVE = new Set(["pickFile", "pickImage", "captureImage", "speech.start", "download.save", "requestPermission"]);

  /* ---------- errors ---------- */
  const CODE_MAP = { permission_denied: "PERMISSION_DENIED", unsupported: "UNSUPPORTED_CAPABILITY", unavailable: "UNSUPPORTED_CAPABILITY", invalid_arguments: "INVALID_ARGUMENT", timeout: "TIMEOUT",
    cancelled: "CANCELLED", file_too_large: "FILE_TOO_LARGE", unsupported_file_type: "UNSUPPORTED_FILE_TYPE", ocr_failed: "OCR_FAILED", speech_failed: "SPEECH_RECOGNITION_FAILED",
    native_error: "INTERNAL_ERROR", bridge_throw: "NATIVE_BRIDGE_UNAVAILABLE", not_found: "NOT_FOUND", busy: "BUSY" };
  class AndroidBridgeError extends Error {
    constructor(code, message, extra) { super(message); this.name = "AndroidBridgeError"; this.code = code; Object.assign(this, extra || {}); }
  }
  /* Messages can carry file names, URIs and exception text from native code. Keep them short and strip anything path-like. */
  function clean(msg) {
    return String(msg == null ? "" : msg).replace(/(?:content|file|android\.resource):\/\/\S+/gi, "[uri]").replace(/(?:\/(?:data|storage|sdcard|mnt|proc|system)\/[^\s"')]*)/g, "[path]")
      .replace(/\bat\s+[\w.$]+\([^)]*\)/g, "").replace(/\b(?:java|kotlin|android|androidx|com|org)\.[\w.$]{6,}/g, "[internal]").replace(/\s+/g, " ").trim().slice(0, 240);
  }
  function mapError(e, method) {
    if (e instanceof AndroidBridgeError) return e;
    const low = e && e.code, raw = e && e.message;
    let code = CODE_MAP[low] || "INTERNAL_ERROR";
    if (low === "unavailable" && root.Bridge && !root.Bridge.available()) code = "NATIVE_BRIDGE_UNAVAILABLE";
    return new AndroidBridgeError(code, clean(raw) || code, { method, nativeCode: typeof low === "string" ? low : undefined, retryable: code === "TIMEOUT" || code === "NATIVE_BRIDGE_UNAVAILABLE" || code === "BUSY" });
  }
  const fail = (code, message, extra) => Promise.reject(new AndroidBridgeError(code, message, extra));

  /* ---------- validation: strict, nothing is coerced ---------- */
  const isObj = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
  function validate(schema, input, label) {
    if (input == null) input = {};
    if (!isObj(input)) return { error: (label || "options") + " must be an object" };
    const out = {};
    for (const k of Object.keys(input)) if (!Object.prototype.hasOwnProperty.call(schema, k)) return { error: "unknown option: " + k };
    for (const k of Object.keys(schema)) {
      const s = schema[k], v = input[k];
      if (v === undefined || v === null) { if (s.required) return { error: "missing required option: " + k }; if (s.default !== undefined) out[k] = s.default; continue; }
      const t = s.type;
      if (t === "string") {
        if (typeof v !== "string") return { error: k + " must be a string" };
        if (/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(v)) return { error: k + " contains control characters" };
        if (v.length > (s.max || 2000)) return { error: k + " is too long (max " + (s.max || 2000) + ")" };
        if (s.min && v.length < s.min) return { error: k + " is too short" };
        if (s.pattern && !s.pattern.test(v)) return { error: k + " has an invalid format" };
        if (s.enum && !s.enum.includes(v)) return { error: k + " must be one of " + s.enum.join(", ") };
      } else if (t === "integer" || t === "number") {
        if (typeof v !== "number" || !isFinite(v) || (t === "integer" && !Number.isInteger(v))) return { error: k + " must be " + (t === "integer" ? "an integer" : "a number") };
        if ((s.min != null && v < s.min) || (s.max != null && v > s.max)) return { error: k + " must be between " + s.min + " and " + s.max };
      } else if (t === "boolean") { if (typeof v !== "boolean") return { error: k + " must be true or false" }; }
      else if (t === "array") {
        if (!Array.isArray(v) || v.length > (s.max || 20)) return { error: k + " must be a list of at most " + (s.max || 20) };
        if (s.item && v.some((x) => typeof x !== "string" || !s.item.test(x))) return { error: k + " has an invalid item" };
      } else if (t === "function") { if (typeof v !== "function") return { error: k + " must be a function" }; }
      else if (t === "signal") { if (!v || typeof v.aborted !== "boolean") return { error: k + " must be an AbortSignal" }; }
      out[k] = v;
    }
    return { value: out };
  }
  const REF = /^ref_[A-Za-z0-9]{8,64}$/;
  const MIME_ITEM = /^[\w.+-]+\/[\w.+*-]+$/;
  const COMMON = { timeoutMs: { type: "integer", min: LIMITS.timeoutMin, max: LIMITS.timeoutMax }, signal: { type: "signal" }, onProgress: { type: "function" } };
  const SCHEMAS = {
    requestPermission: { permission: { type: "string", required: true, enum: PERMS } },
    pickFile: { multiple: { type: "boolean", default: false }, maxFiles: { type: "integer", min: 1, max: LIMITS.pickFiles, default: 5 }, mimeTypes: { type: "array", max: LIMITS.mimeTypes, item: MIME_ITEM } },
    readFile: { ref: { type: "string", required: true, pattern: REF }, maxBytes: { type: "integer", min: 1, max: LIMITS.readHard, default: LIMITS.readDefault }, offset: { type: "integer", min: 0, max: Number.MAX_SAFE_INTEGER }, length: { type: "integer", min: 1, max: LIMITS.readHard }, allowUnknownText: { type: "boolean", default: false } },
    pickImage: { multiple: { type: "boolean", default: false }, maxImages: { type: "integer", min: 1, max: LIMITS.ocrImages, default: 4 } },
    captureImage: {},
    getImageData: { ref: { type: "string", required: true, pattern: REF }, maxDimension: { type: "integer", min: 64, max: LIMITS.thumbMax, default: 1024 }, quality: { type: "integer", min: 30, max: 95, default: 80 } },
    extractTextFromImage: { ref: { type: "string", pattern: REF }, refs: { type: "array", max: LIMITS.ocrImages, item: REF }, detail: { type: "string", enum: ["text", "lines", "full"], default: "lines" }, maxDimension: { type: "integer", min: 512, max: 4096, default: 2048 }, maxPages: { type: "integer", min: 1, max: 20, default: 5 } },
    startSpeechRecognition: { lang: { type: "string", pattern: /^[a-z]{2,3}([-_][A-Za-z0-9]{2,8})?$/, default: "en-IN" }, partial: { type: "boolean", default: true }, maxMs: { type: "integer", min: 2000, max: 120000, default: 30000 }, preferOffline: { type: "boolean", default: false } },
    speak: { text: { type: "string", required: true, min: 1, max: 4000 }, lang: { type: "string", pattern: /^[a-z]{2,3}([-_][A-Za-z0-9]{2,8})?$/, default: "en-IN" }, rate: { type: "number", min: 0.5, max: 2, default: 1 }, pitch: { type: "number", min: 0.5, max: 2, default: 1 }, voice: { type: "string", max: 100 } },
    share: { text: { type: "string", max: LIMITS.shareChars }, title: { type: "string", max: 60, default: "Share" }, ref: { type: "string", pattern: REF } },
    openSupportedApp: { action: { type: "string", required: true, enum: ["app", "maps", "web", "email", "dial"] }, name: { type: "string", max: 60 }, query: { type: "string", max: 200 }, url: { type: "string", max: 1800 }, to: { type: "string", max: 120 }, subject: { type: "string", max: 200 }, body: { type: "string", max: 2000 }, number: { type: "string", max: 20, pattern: /^\+?[\d\s().-]{3,20}$/ } },
    openSettings: { section: { type: "string", required: true, enum: SETTINGS } },
    downloadFile: { filename: { type: "string", required: true, min: 1, max: 100 }, mime: { type: "string", required: true, enum: SAVE_MIME }, text: { type: "string", max: LIMITS.downloadBytes }, base64: { type: "string", max: Math.ceil(LIMITS.downloadBytes * 4 / 3) + 8, pattern: /^[A-Za-z0-9+/]*={0,2}$/ } },
  };
  function opts(name, o) {
    const s = Object.assign({}, SCHEMAS[name], COMMON);
    const r = validate(s, o, name + " options");
    if (r.error) return { error: new AndroidBridgeError("INVALID_ARGUMENT", r.error, { method: name }) };
    if (S.handle) { r.value.handle = S.handle; S.handle = null; } // set by cancelable() for this very call
    return r;
  }

  /* ---------- state ---------- */
  const S = { handle: null, hooked: false, inited: false, caps: null, inflight: new Map(), exclusive: null, listeners: {}, unsub: [], files: new Map(), refSeq: 0, speech: null, env: null };
  const B = () => root.Bridge;
  const native = () => !!(B() && B().available());
  const environment = () => (native() ? "android-native" : typeof document !== "undefined" ? "browser" : "unknown");
  function emit(name, payload) { (S.listeners[name] || []).slice().concat(S.listeners["*"] || []).forEach((f) => { try { f(payload, name); } catch (e) {} }); }
  /* Subscribe to native events exactly once, whether the first caller is init(), on() or a speech call. */
  function hook() { if (S.hooked || !B() || typeof B().on !== "function") return; S.hooked = true; S.unsub.push(B().on("*", (p, n) => emit(n, p))); }
  function newRef() { const a = new Uint8Array(12); (root.crypto && root.crypto.getRandomValues ? root.crypto.getRandomValues(a) : a.forEach((_, i) => { a[i] = Math.floor(Math.random() * 256); })); return "ref_" + Array.from(a, (b) => b.toString(16).padStart(2, "0")).join("") + (++S.refSeq).toString(36); }
  const parseResult = (raw, method) => {
    let j = raw; if (typeof raw === "string") { try { j = JSON.parse(raw); } catch (e) { throw new AndroidBridgeError("INTERNAL_ERROR", "The native side returned something that is not valid JSON.", { method }); } }
    if (!isObj(j)) throw new AndroidBridgeError("INTERNAL_ERROR", "The native side returned an unexpected result.", { method });
    return j;
  };

  /* One native call. Returns a promise with .cancel(). Exclusive operations (pickers, speech, saves, permission prompts) cannot overlap. */
  function call(method, args, o) {
    o = o || {};
    if (!native()) return fail("NATIVE_BRIDGE_UNAVAILABLE", "The Android bridge is not available here.", { method });
    const excl = EXCLUSIVE.has(method), hd = o.handle;
    if (hd && hd.cancelled) return fail("CANCELLED", "Cancelled before it started.", { method });
    const excl0 = excl;
    if (excl && S.exclusive) return fail("BUSY", "Another interactive operation (" + S.exclusive + ") is still running.", { method, retryable: true });
    if (excl) S.exclusive = method;
    hook();
    let h;
    try { h = B().callCancelable(method, Object.assign({ _v: PROTOCOL }, args || {}), { timeoutMs: o.timeoutMs, signal: o.signal, onProgress: o.onProgress ? (p) => { try { o.onProgress(p); } catch (e) {} } : undefined }); }
    catch (e) { if (excl) S.exclusive = null; return fail("INTERNAL_ERROR", clean(e && e.message), { method }); }
    const p = h.promise.then((raw) => parseResult(raw, method), (e) => { throw mapError(e, method); });
    const done = () => { if (excl && S.exclusive === method) S.exclusive = null; };
    p.then(done, done);
    p.cancel = h.cancel; p.requestId = h.id;
    if (hd) hd.native = p;
    return p;
  }
  function shared(key, make) { if (S.inflight.has(key)) return S.inflight.get(key); const p = make(); S.inflight.set(key, p); const d = () => S.inflight.delete(key); p.then(d, d); return p; }
  const canceller = (o) => (o && o.signal && o.signal.aborted ? fail("CANCELLED", "Cancelled before it started.") : null);
  /* Public async methods return a promise that also has .cancel() and .requestId, wired to whatever native call (or browser chooser) is running. */
  function cancelable(fn) {
    return function () {
      const h = { native: null, cancelled: false, onCancel: null };
      S.handle = h;
      let p;
      try { p = fn.apply(API, arguments); } finally { S.handle = null; }
      p.cancel = () => { if (h.cancelled) return false; h.cancelled = true; if (h.native && typeof h.native.cancel === "function") return h.native.cancel(); if (h.onCancel) { h.onCancel(); return true; } return true; };
      Object.defineProperty(p, "requestId", { get() { return h.native ? h.native.requestId : undefined; }, enumerable: true });
      return p;
    };
  }

  /* ---------- capabilities ---------- */
  const NEEDS = { fileRead: ["pickFile", "readFile"], imagePick: ["pickImage"], imageCapture: ["captureImage"], ocr: ["ocr.extract"], speechRecognition: ["speech.start", "speech.stop"], textToSpeech: ["tts.speak", "tts.stop"],
    share: ["share"], clipboardWrite: ["clipboardWrite"], clipboardRead: ["clipboardRead"], appLaunch: ["openSupported", "openApp"], settings: ["openSettings"], download: ["download.save"], permissions: ["requestPermission", "permissions"] };
  const cap = (state, detail, extra) => Object.assign({ state, detail: detail || "" }, extra || {});
  function browserCaps() {
    const w = root, d = typeof document !== "undefined";
    const SR = w.SpeechRecognition || w.webkitSpeechRecognition, secure = w.isSecureContext !== false;
    const c = {
      fileRead: d && typeof w.File === "function" ? cap("SUPPORTED", "HTML file input; must be triggered by a tap. PDF and DOCX are not read in the browser.") : cap("UNSUPPORTED_ENVIRONMENT"),
      imagePick: d ? cap("SUPPORTED", "HTML file input (images).") : cap("UNSUPPORTED_ENVIRONMENT"),
      imageCapture: d ? cap("SUPPORTED", "File input with the capture hint; only mobile browsers open the camera, desktops open a file chooser.") : cap("UNSUPPORTED_ENVIRONMENT"),
      ocr: typeof w.TextDetector === "function" ? cap("SUPPORTED", "Browser Shape Detection TextDetector (experimental; text only, no confidence).") : cap("UNAVAILABLE", "No OCR in this browser."),
      speechRecognition: SR ? cap("SUPPORTED", "Browser speech recognition; the browser vendor's service may receive the audio.") : cap("UNAVAILABLE", "SpeechRecognition is not supported by this browser."),
      textToSpeech: w.speechSynthesis ? cap("SUPPORTED", "Browser speech synthesis.") : cap("UNAVAILABLE"),
      share: w.navigator && typeof w.navigator.share === "function" && secure ? cap("SUPPORTED", "Web Share API.") : cap("UNAVAILABLE", "Web Share needs HTTPS and a supporting browser."),
      clipboardWrite: w.navigator && w.navigator.clipboard && typeof w.navigator.clipboard.writeText === "function" && secure ? cap("SUPPORTED", "Async Clipboard API.") : cap("UNAVAILABLE", "Clipboard writing needs a secure context."),
      clipboardRead: cap("UNSUPPORTED_ENVIRONMENT", "EDO never reads the clipboard in a browser."),
      appLaunch: typeof w.open === "function" ? cap("SUPPORTED", "Opens https, mailto, geo-style web links only; cannot launch installed apps by name.") : cap("UNAVAILABLE"),
      settings: cap("UNSUPPORTED_ENVIRONMENT", "Browsers cannot open system settings."),
      download: d && typeof w.Blob === "function" && w.URL && w.URL.createObjectURL ? cap("SUPPORTED", "Blob download; the browser decides where it goes.") : cap("UNAVAILABLE"),
      permissions: w.navigator && w.navigator.mediaDevices ? cap("SUPPORTED", "Microphone and notifications only.") : cap("UNAVAILABLE"),
    };
    return c;
  }
  function nativeCaps(c) {
    const out = {}, reported = (c.features && c.features.caps) || {}, methods = c.methods || [], perms = c.permissions || {};
    Object.keys(NEEDS).forEach((k) => {
      const missing = NEEDS[k].filter((m) => !methods.includes(m)); const r = reported[k];
      if (r && STATES.includes(r.state)) out[k] = cap(r.state, String(r.detail || "").slice(0, 160));
      else if (missing.length) out[k] = cap("UNAVAILABLE", "This native build lacks: " + missing.join(", "));
      else out[k] = cap("SUPPORTED");
    });
    if (out.speechRecognition.state === "SUPPORTED" && perms.microphone === false) out.speechRecognition = cap("PERMISSION_REQUIRED", "Microphone permission is needed; call requestPermission('microphone').");
    return out;
  }
  function getCapabilities(force) {
    return shared("caps" + (force ? "!" : ""), async () => {
      if (S.caps && !force) return S.caps;
      let r;
      if (native()) {
        const c = await B().capabilities(!!force);
        if (!c.available || !Array.isArray(c.methods) || !c.methods.length) r = { environment: "android-native", protocol: { version: PROTOCOL, native: null }, session: null, capabilities: Object.keys(NEEDS).reduce((o, k) => { o[k] = cap("UNAVAILABLE", clean(c.reason) || "The native side did not report its capabilities."); return o; }, {}), permissions: {}, error: clean(c.reason) };
        else r = { environment: "android-native", protocol: { version: PROTOCOL, native: c.version || 2 }, session: c.session, capabilities: nativeCaps(c), permissions: c.permissions || {} };
      } else r = { environment: environment(), protocol: { version: PROTOCOL, native: null }, session: null, capabilities: browserCaps(), permissions: {} };
      S.caps = r; return r;
    });
  }
  function capabilityState(name) { return S.caps && S.caps.capabilities[name] ? S.caps.capabilities[name].state : "NOT_INITIALIZED"; }

  /* ---------- browser fallback helpers ---------- */
  function needGesture(method) {
    const ua = root.navigator && root.navigator.userActivation;
    if (ua && ua.isActive === false) return new AndroidBridgeError("PERMISSION_DENIED", "Browsers only open file or camera choosers from a tap or click. Call this from a button handler.", { method });
    return null;
  }
  function browserPick(method, accept, multiple, capture, o) {
    if (typeof document === "undefined") return fail("UNSUPPORTED_CAPABILITY", "No document available.", { method });
    const g = needGesture(method); if (g) return Promise.reject(g);
    return new Promise((resolve, reject) => {
      const inp = document.createElement("input"); inp.type = "file"; if (accept) inp.accept = accept; inp.multiple = !!multiple; if (capture) inp.setAttribute("capture", "environment");
      inp.style.display = "none"; let settled = false, to;
      const end = (fn, v) => { if (settled) return; settled = true; clearTimeout(to); if (o && o.signal && o.signal.removeEventListener) o.signal.removeEventListener("abort", onAbort); try { inp.remove(); } catch (e) {} fn(v); };
      const onAbort = () => end(reject, new AndroidBridgeError("CANCELLED", "Cancelled.", { method }));
      if (o && o.handle) o.handle.onCancel = onAbort;
      inp.addEventListener("change", () => end(resolve, Array.from(inp.files || [])));
      inp.addEventListener("cancel", () => end(reject, new AndroidBridgeError("CANCELLED", "No file was chosen.", { method })));
      to = setTimeout(() => end(reject, new AndroidBridgeError("TIMEOUT", "No file was chosen in time.", { method, retryable: true })), (o && o.timeoutMs) || 120000);
      if (o && o.signal) { if (o.signal.aborted) return onAbort(); o.signal.addEventListener && o.signal.addEventListener("abort", onAbort); }
      document.body.appendChild(inp); inp.click();
    });
  }
  const extOf = (n) => { const m = /\.([A-Za-z0-9]{1,8})$/.exec(String(n || "")); return m ? m[1].toLowerCase() : ""; };
  const isImage = (f) => /^image\/(png|jpe?g|webp|gif)$/i.test(f.type || "");
  function describe(ref, f) { return { ref, name: String(f.name || "file").slice(0, 120), size: f.size, mime: f.type || "", lastModified: f.lastModified || null }; }
  function keep(f) { const ref = newRef(); S.files.set(ref, f); while (S.files.size > 50) S.files.delete(S.files.keys().next().value); return ref; }

  /* Strict decoding. Returns {text, encoding, guessed}. A malformed UTF-8 file is never silently "repaired": it is re-read as windows-1252 and flagged. */
  function trimIncompleteUtf8(u8) {
    let i = u8.length, back = 0;
    while (i > 0 && back < 4 && (u8[i - 1] & 0xc0) === 0x80) { i--; back++; }
    if (i > 0) { const lead = u8[i - 1]; const need = lead >= 0xf0 ? 4 : lead >= 0xe0 ? 3 : lead >= 0xc0 ? 2 : 1; if (need > 1 && back + 1 < need) return u8.length - (back + 1); }
    return u8.length;
  }
  function looksBinary(u8) { const n = Math.min(u8.length, 8192); let bad = 0; for (let i = 0; i < n; i++) { const b = u8[i]; if (b === 0 || (b < 9) || (b > 13 && b < 32 && b !== 27)) bad++; } return n > 0 && bad / n > 0.01; }
  function decodeText(u8, final) {
    let off = 0, enc = "utf-8";
    if (u8.length >= 3 && u8[0] === 0xef && u8[1] === 0xbb && u8[2] === 0xbf) { off = 3; }
    else if (u8.length >= 2 && u8[0] === 0xff && u8[1] === 0xfe) return { text: new TextDecoder("utf-16le").decode(u8.subarray(2)), encoding: "utf-16le", used: u8.length };
    else if (u8.length >= 2 && u8[0] === 0xfe && u8[1] === 0xff) return { text: new TextDecoder("utf-16be").decode(u8.subarray(2)), encoding: "utf-16be", used: u8.length };
    if (looksBinary(u8)) return { binary: true };
    const used = final ? u8.length : trimIncompleteUtf8(u8);
    try { return { text: new TextDecoder("utf-8", { fatal: true }).decode(u8.subarray(off, used)), encoding: enc, used }; }
    catch (e) { return { text: new TextDecoder("windows-1252").decode(u8.subarray(off, used)), encoding: "windows-1252", guessed: true, used }; }
  }
  async function bytesOf(file, start, end) { return new Uint8Array(await file.slice(start, end).arrayBuffer()); }
  function kindOf(name, mime, head, allowUnknown) {
    const ext = extOf(name), isPdf = head.length >= 5 && String.fromCharCode(head[0], head[1], head[2], head[3], head[4]) === "%PDF-", isZip = head.length >= 4 && head[0] === 0x50 && head[1] === 0x4b && head[2] === 3 && head[3] === 4;
    if (isPdf) return "pdf"; if (isZip) return ext === "docx" || /wordprocessingml/.test(mime || "") ? "docx" : "zip";
    if (ext === "pdf" || ext === "docx") return "mismatch";
    if (TEXT_EXT.includes(ext) || TEXT_MIME.test(mime || "")) return "text";
    return allowUnknown ? "text" : "unknown";
  }
  async function browserRead(f, o) {
    const size = f.size, off = o.offset || 0, ranged = o.length != null;
    if (off > size) return fail("INVALID_ARGUMENT", "offset is beyond the end of the file.");
    const head = await bytesOf(f, 0, Math.min(size, 16)), kind = kindOf(f.name, f.type, head, o.allowUnknownText);
    if (kind === "pdf" || kind === "docx") return fail("UNSUPPORTED_FILE_TYPE", kind.toUpperCase() + " files can only be read by the Android app. This browser does not extract them.");
    if (kind === "mismatch") return fail("UNSUPPORTED_FILE_TYPE", "The file name says one type but the content is another, so it was not read.");
    if (kind !== "text") return fail("UNSUPPORTED_FILE_TYPE", "Unrecognised file type. Pass allowUnknownText:true if you know it is text.");
    if (!ranged && size - off > o.maxBytes) return fail("FILE_TOO_LARGE", "The file is " + size + " bytes; the limit is " + o.maxBytes + ". Read it in pieces with offset and length.", { details: { size, limit: o.maxBytes, hint: "offset/length" } });
    const want = ranged ? Math.min(o.length, o.maxBytes, size - off) : size - off;
    const bytes = await bytesOf(f, off, off + want), end = off + want >= size;
    if (!bytes.length) return { ref: null, name: f.name, kind: "text", mime: f.type || "", encoding: "utf-8", text: "", size, offset: off, bytesRead: 0, nextOffset: off, eof: true, partial: false, truncated: false, empty: size === 0 };
    const d = decodeText(bytes, end); if (d.binary) return fail("UNSUPPORTED_FILE_TYPE", "The content looks binary, not text.");
    const used = d.used == null ? bytes.length : d.used; const hasBom = off === 0 && bytes[0] === 0xef && bytes[1] === 0xbb && bytes[2] === 0xbf;
    return { name: f.name, kind: "text", mime: f.type || "", encoding: d.encoding, encodingGuessed: !!d.guessed, text: d.text, size, offset: off, bytesRead: used, nextOffset: off + used, eof: off + used >= size, partial: off + used < size, truncated: false, bom: hasBom, charCount: d.text.length };
  }

  /* ---------- public API ---------- */
  const API = {
    __version: PROTOCOL, PROTOCOL, LIMITS, STATES, CODES: Object.freeze(["PERMISSION_DENIED", "UNSUPPORTED_CAPABILITY", "INVALID_ARGUMENT", "TIMEOUT", "CANCELLED", "FILE_TOO_LARGE", "UNSUPPORTED_FILE_TYPE", "NATIVE_BRIDGE_UNAVAILABLE", "OCR_FAILED", "SPEECH_RECOGNITION_FAILED", "INTERNAL_ERROR", "NOT_FOUND", "BUSY"]), AndroidBridgeError,
    isAvailable() { return native(); },
    /* Idempotent. Subscribes to native events exactly once and checks for a changed native session (WebView or process recreated). */
    async init() {
      if (S.inited) return API.getCapabilities();
      S.inited = true;
      hook();
      if (native()) { try { await B().resync(); } catch (e) {} }
      return API.getCapabilities(true);
    },
    getCapabilities(force) { return getCapabilities(!!force); },
    capabilityState,
    isCancel(e) { return !!(e && e.code === "CANCELLED"); },
    on(name, fn) { hook(); if (typeof name !== "string" || typeof fn !== "function") return () => {}; const a = S.listeners[name] || (S.listeners[name] = []); if (!a.includes(fn)) a.push(fn); return () => { const i = a.indexOf(fn); if (i >= 0) a.splice(i, 1); }; },
    listenerCount(name) { return (S.listeners[name] || []).length; },
    getPlatformInfo() {
      return shared("platform", async () => {
        if (!native()) return { environment: environment(), os: "browser", language: (root.navigator && root.navigator.language) || null, online: root.navigator ? root.navigator.onLine !== false : null };
        const j = await shared("deviceInfo", () => call("deviceInfo", {})); return { environment: "android-native", os: "android", androidVersion: String(j.android || ""), sdk: j.sdk | 0, manufacturer: String(j.manufacturer || ""), model: String(j.model || ""), language: j.language ? String(j.language) : null };
      });
    },
    getAppInfo() {
      return shared("app", async () => {
        if (!native()) return { environment: environment(), name: "EDO", version: null, package: null, protocol: PROTOCOL };
        const j = await shared("deviceInfo", () => call("deviceInfo", {})); return { environment: "android-native", name: "EDO", version: j.versionName || null, versionCode: j.versionCode != null ? j.versionCode : null, package: j.package || null, protocol: PROTOCOL, nativeProtocol: S.caps ? S.caps.protocol.native : null };
      });
    },

    async requestPermission(permission, o) {
      const v = opts("requestPermission", Object.assign({}, o, { permission })); if (v.error) return Promise.reject(v.error);
      if (native()) { const j = await call("requestPermission", { permission: v.value.permission }, v.value); S.caps = null; return { permission: v.value.permission, granted: j.granted === true, hint: j.granted === true ? undefined : "If no dialog appeared, Android has stopped asking; open settings with openSettings({section:'app'})." }; }
      const p = v.value.permission, nav = root.navigator;
      if (p === "microphone" && nav && nav.mediaDevices && nav.mediaDevices.getUserMedia) { try { const st = await nav.mediaDevices.getUserMedia({ audio: true }); st.getTracks().forEach((t) => t.stop()); return { permission: p, granted: true }; } catch (e) { return { permission: p, granted: false, hint: "The browser denied microphone access." }; } }
      if (p === "notifications" && typeof root.Notification === "function") { const r = await root.Notification.requestPermission(); return { permission: p, granted: r === "granted" }; }
      return fail("UNSUPPORTED_CAPABILITY", "Permission '" + p + "' cannot be requested in a browser.", { method: "requestPermission" });
    },

    /* Opens the system picker. Resolves {files:[{ref,name,size,mime,kind}]}; the user closing the picker rejects with CANCELLED. */
    async pickFile(o) {
      const v = opts("pickFile", o); if (v.error) return Promise.reject(v.error); const c = canceller(v.value); if (c) return c;
      if (native()) { const j = await call("pickFile", { multiple: v.value.multiple, maxFiles: v.value.maxFiles, mimeTypes: v.value.mimeTypes }, v.value); return normalizeFiles(j); }
      const accept = (v.value.mimeTypes || []).join(",") || TEXT_EXT.map((e) => "." + e).join(",") + ",.pdf,.docx";
      const list = await browserPick("pickFile", accept, v.value.multiple, false, v.value);
      if (!list.length) throw new AndroidBridgeError("CANCELLED", "No file was chosen.", { method: "pickFile" });
      return { files: list.slice(0, v.value.maxFiles).map((f) => Object.assign(describe(keep(f), f), { kind: kindGuess(f) })) };
    },
    async readFile(o) {
      const v = opts("readFile", o); if (v.error) return Promise.reject(v.error); const c = canceller(v.value); if (c) return c;
      if (native()) { const j = await call("readFile", { ref: v.value.ref, maxBytes: v.value.maxBytes, offset: v.value.offset, length: v.value.length, allowUnknownText: v.value.allowUnknownText }, v.value); return normalizeRead(j, v.value.ref); }
      const f = S.files.get(v.value.ref); if (!f) return fail("NOT_FOUND", "That file reference is unknown or was released.", { method: "readFile" });
      const r = await browserRead(f, v.value); r.ref = v.value.ref; return r;
    },
    async pickImage(o) {
      const v = opts("pickImage", o); if (v.error) return Promise.reject(v.error); const c = canceller(v.value); if (c) return c;
      if (native()) return normalizeImages(await call("pickImage", { multiple: v.value.multiple, maxImages: v.value.maxImages }, v.value));
      const list = (await browserPick("pickImage", "image/*", v.value.multiple, false, v.value)).filter(isImage).slice(0, v.value.maxImages);
      if (!list.length) throw new AndroidBridgeError("UNSUPPORTED_FILE_TYPE", "No supported image (PNG, JPEG, WebP, GIF) was chosen.", { method: "pickImage" });
      return { images: list.map((f) => Object.assign(describe(keep(f), f), { width: null, height: null })) };
    },
    async captureImage(o) {
      const v = opts("captureImage", o); if (v.error) return Promise.reject(v.error); const c = canceller(v.value); if (c) return c;
      if (native()) { const r = normalizeImages(await call("captureImage", {}, v.value)); return { image: r.images[0] }; }
      const list = (await browserPick("captureImage", "image/*", false, true, v.value)).filter(isImage);
      if (!list.length) throw new AndroidBridgeError("UNSUPPORTED_FILE_TYPE", "No supported image was captured.", { method: "captureImage" });
      return { image: Object.assign(describe(keep(list[0]), list[0]), { width: null, height: null }) };
    },
    /* A downscaled JPEG as base64 for previews or an AI vision call. Nothing is sent anywhere by EDO: the caller must get the user's consent first. */
    async getImageData(o) {
      const v = opts("getImageData", o); if (v.error) return Promise.reject(v.error); const c = canceller(v.value); if (c) return c;
      if (native()) { const j = await call("image.data", { ref: v.value.ref, maxDimension: v.value.maxDimension, quality: v.value.quality }, v.value); if (typeof j.base64 !== "string" || !/^[A-Za-z0-9+/]+={0,2}$/.test(j.base64)) throw new AndroidBridgeError("INTERNAL_ERROR", "The native image data was malformed.", { method: "image.data" }); return { ref: v.value.ref, mime: "image/jpeg", width: j.width | 0, height: j.height | 0, base64: j.base64 }; }
      const f = S.files.get(v.value.ref); if (!f || !isImage(f)) return fail("NOT_FOUND", "That image reference is unknown.", { method: "image.data" });
      if (typeof root.createImageBitmap !== "function" || typeof document === "undefined") return fail("UNSUPPORTED_CAPABILITY", "This browser cannot resize images.", { method: "image.data" });
      const bmp = await root.createImageBitmap(f); const k = Math.min(1, v.value.maxDimension / Math.max(bmp.width, bmp.height)); const cv = document.createElement("canvas"); cv.width = Math.max(1, Math.round(bmp.width * k)); cv.height = Math.max(1, Math.round(bmp.height * k));
      cv.getContext("2d").drawImage(bmp, 0, 0, cv.width, cv.height); if (bmp.close) bmp.close();
      return { ref: v.value.ref, mime: "image/jpeg", width: cv.width, height: cv.height, base64: cv.toDataURL("image/jpeg", v.value.quality / 100).split(",")[1] };
    },
    async extractTextFromImage(o) {
      const v = opts("extractTextFromImage", o); if (v.error) return Promise.reject(v.error); const c = canceller(v.value);
      if (c) return c; const refs = v.value.refs || (v.value.ref ? [v.value.ref] : []);
      if (!refs.length) return fail("INVALID_ARGUMENT", "Pass ref or refs.", { method: "ocr.extract" });
      if (native()) { const j = await call("ocr.extract", { refs, detail: v.value.detail, maxDimension: v.value.maxDimension, maxPages: v.value.maxPages }, v.value); return normalizeOcr(j); }
      if (typeof root.TextDetector !== "function") return fail("UNSUPPORTED_CAPABILITY", "This browser has no text recognition. Use the Android app for OCR.", { method: "ocr.extract" });
      const det = new root.TextDetector(), results = []; const t0 = Date.now();
      for (let i = 0; i < refs.length; i++) {
        if ((v.value.signal && v.value.signal.aborted) || (v.value.handle && v.value.handle.cancelled)) throw new AndroidBridgeError("CANCELLED", "Cancelled.", { method: "ocr.extract" });
        if (v.value.onProgress) try { v.value.onProgress({ index: i, total: refs.length, stage: "recognizing" }); } catch (e) {}
        const f = S.files.get(refs[i]); if (!f) { results.push({ ref: refs[i], imageId: i, status: "failed", error: { code: "NOT_FOUND", message: "Unknown reference." }, text: "", blocks: [] }); continue; }
        try { const bmp = await root.createImageBitmap(f); const found = await det.detect(bmp); if (bmp.close) bmp.close(); const blocks = found.map((x) => ({ text: String(x.rawValue || ""), box: x.boundingBox ? { left: x.boundingBox.x, top: x.boundingBox.y, right: x.boundingBox.x + x.boundingBox.width, bottom: x.boundingBox.y + x.boundingBox.height } : null })); results.push({ ref: refs[i], imageId: i, status: blocks.length ? "ok" : "empty", text: blocks.map((b) => b.text).join("\n"), blocks }); }
        catch (e) { results.push({ ref: refs[i], imageId: i, status: "failed", error: { code: "OCR_FAILED", message: clean(e && e.message) }, text: "", blocks: [] }); }
      }
      return finishOcr(results, Date.now() - t0, "browser-shape-detection");
    },
    releaseRef(ref) { if (typeof ref !== "string" || !REF.test(ref)) return fail("INVALID_ARGUMENT", "Not a valid reference."); if (native()) return call("ref.release", { ref }).then((j) => ({ released: j.released === true })); return Promise.resolve({ released: S.files.delete(ref) }); },

    startSpeechRecognition(o) {
      const v = opts("startSpeechRecognition", o); if (v.error) return Promise.reject(v.error); const c = canceller(v.value); if (c) return c;
      if (native()) { const off = API.on("speech.partial", (p) => { if (v.value.onProgress) try { v.value.onProgress(p); } catch (e) {} }); const p = call("speech.start", { lang: v.value.lang, partial: v.value.partial, maxMs: v.value.maxMs, preferOffline: v.value.preferOffline }, Object.assign({}, v.value, { timeoutMs: v.value.timeoutMs || v.value.maxMs + 15000 })); const q = p.then((j) => ({ text: String(j.text || ""), alternatives: Array.isArray(j.alternatives) ? j.alternatives.slice(0, 5).map(String) : [], confidence: typeof j.confidence === "number" ? j.confidence : null }), (e) => { throw e; }); q.then(off, off); q.cancel = p.cancel; return q; }
      const SR = root.SpeechRecognition || root.webkitSpeechRecognition; if (!SR) return fail("UNSUPPORTED_CAPABILITY", "This browser has no speech recognition.", { method: "speech.start" });
      if (S.speech) return fail("BUSY", "Speech recognition is already running.", { method: "speech.start", retryable: true });
      const g = needGesture("speech.start"); if (g) return Promise.reject(g);
      let rec, settle;
      const prom = new Promise((resolve, reject) => {
        rec = new SR(); S.speech = rec; rec.lang = v.value.lang.replace("_", "-"); rec.interimResults = v.value.partial; rec.continuous = false; let finalText = "", alts = [];
        const to = setTimeout(() => { try { rec.stop(); } catch (e) {} }, v.value.maxMs);
        settle = (fn, val) => { clearTimeout(to); S.speech = null; emit("speech.state", { state: "idle" }); fn(val); };
        rec.onstart = () => emit("speech.state", { state: "listening" });
        rec.onresult = (e) => { let interim = ""; for (let i = e.resultIndex; i < e.results.length; i++) { const r = e.results[i]; if (r.isFinal) { finalText += r[0].transcript; alts = Array.from(r).slice(0, 3).map((x) => x.transcript); } else interim += r[0].transcript; } if (interim) emit("speech.partial", { text: interim }); };
        rec.onerror = (e) => settle(reject, new AndroidBridgeError(e.error === "not-allowed" || e.error === "service-not-allowed" ? "PERMISSION_DENIED" : e.error === "aborted" ? "CANCELLED" : "SPEECH_RECOGNITION_FAILED", "Speech recognition failed: " + clean(e.error), { method: "speech.start" }));
        rec.onend = () => settle(resolve, { text: finalText.trim(), alternatives: alts, confidence: null });
        try { rec.start(); } catch (e) { settle(reject, new AndroidBridgeError("SPEECH_RECOGNITION_FAILED", clean(e && e.message), { method: "speech.start" })); }
      });
      prom.cancel = () => { try { rec.abort(); } catch (e) {} return true; };
      if (v.value.signal) v.value.signal.addEventListener && v.value.signal.addEventListener("abort", () => prom.cancel());
      return prom;
    },
    /* Ask the recogniser to finish and deliver what it heard. To discard instead, call .cancel() on the start promise. */
    async stopSpeechRecognition() {
      if (native()) { const j = await call("speech.stop", {}); return { stopped: j.stopped === true, wasListening: j.wasListening === true }; }
      if (S.speech) { try { S.speech.stop(); } catch (e) {} return { stopped: true, wasListening: true }; }
      return { stopped: true, wasListening: false };
    },
    speak(o) {
      const v = opts("speak", o); if (v.error) return Promise.reject(v.error); const c = canceller(v.value); if (c) return c;
      if (native()) return call("tts.speak", { text: v.value.text, lang: v.value.lang, rate: v.value.rate, pitch: v.value.pitch, voice: v.value.voice }, v.value).then((j) => Object.assign({ spoken: true }, isObj(j) ? j : {}));
      const ss = root.speechSynthesis; if (!ss || typeof root.SpeechSynthesisUtterance !== "function") return fail("UNSUPPORTED_CAPABILITY", "This browser has no speech synthesis.", { method: "tts.speak" });
      return new Promise((resolve, reject) => { const u = new root.SpeechSynthesisUtterance(v.value.text); u.lang = v.value.lang.replace("_", "-"); u.rate = v.value.rate; u.pitch = v.value.pitch; u.onend = () => resolve({ spoken: true }); u.onerror = (e) => reject(new AndroidBridgeError(e && e.error === "interrupted" ? "CANCELLED" : "INTERNAL_ERROR", "Speech failed: " + clean(e && e.error), { method: "tts.speak" })); ss.speak(u); });
    },
    async stopSpeaking() { if (native()) { await call("tts.stop", {}); return { stopped: true }; } if (root.speechSynthesis) root.speechSynthesis.cancel(); return { stopped: true }; },

    async share(o) {
      const v = opts("share", o); if (v.error) return Promise.reject(v.error); const c = canceller(v.value); if (c) return c;
      if (!v.value.text && !v.value.ref) return fail("INVALID_ARGUMENT", "Share needs text or a ref.", { method: "share" });
      if (native()) { const j = await call("share", { text: v.value.text || "", title: v.value.title, ref: v.value.ref }, v.value); return { shown: j.chooserShown === true, note: "The chooser is shown; nothing is shared until the user picks a target." }; }
      const nav = root.navigator; if (!nav || typeof nav.share !== "function" || root.isSecureContext === false) return fail("UNSUPPORTED_CAPABILITY", "Web Share is not available here.", { method: "share" });
      const data = { title: v.value.title, text: v.value.text || "" }; if (v.value.ref) { const f = S.files.get(v.value.ref); if (!f) return fail("NOT_FOUND", "Unknown file reference.", { method: "share" }); data.files = [f]; if (nav.canShare && !nav.canShare(data)) return fail("UNSUPPORTED_CAPABILITY", "This browser cannot share that file.", { method: "share" }); }
      try { await nav.share(data); return { shown: true, note: "Shared through the browser's share sheet." }; } catch (e) { throw new AndroidBridgeError(e && e.name === "AbortError" ? "CANCELLED" : "INTERNAL_ERROR", e && e.name === "AbortError" ? "Share was cancelled." : clean(e && e.message), { method: "share" }); }
    },
    async copyToClipboard(text) {
      if (typeof text !== "string" || !text.length) return fail("INVALID_ARGUMENT", "Nothing to copy.", { method: "clipboardWrite" });
      if (text.length > LIMITS.clipboardChars) return fail("INVALID_ARGUMENT", "Text is too long to copy (max " + LIMITS.clipboardChars + " characters). It was not truncated.", { method: "clipboardWrite" });
      if (/\u0000/.test(text)) return fail("INVALID_ARGUMENT", "Text contains control characters.", { method: "clipboardWrite" });
      if (native()) { const j = await call("clipboardWrite", { text }); return { copied: j.copied === true }; }
      const cb = root.navigator && root.navigator.clipboard; if (!cb || typeof cb.writeText !== "function" || root.isSecureContext === false) return fail("UNSUPPORTED_CAPABILITY", "Clipboard writing needs a secure context.", { method: "clipboardWrite" });
      try { await cb.writeText(text); return { copied: true }; } catch (e) { throw new AndroidBridgeError("PERMISSION_DENIED", "The browser refused clipboard access (it needs a user gesture).", { method: "clipboardWrite" }); }
    },
    /* Allowlisted actions only: app (by label), maps, web (https), email (compose), dial (never auto-calls). */
    async openSupportedApp(o) {
      const v = opts("openSupportedApp", o); if (v.error) return Promise.reject(v.error); const c = canceller(v.value); if (c) return c; const x = v.value;
      const need = { app: ["name"], maps: ["query"], web: ["url"], email: ["to"], dial: ["number"] }[x.action]; const miss = need.find((k) => !x[k]); if (miss) return fail("INVALID_ARGUMENT", x.action + " needs " + miss + ".", { method: "openSupported" });
      if (x.action === "web") { const u = safeHttps(x.url); if (!u) return fail("INVALID_ARGUMENT", "Only https:// links without credentials are allowed.", { method: "openSupported" }); x.url = u; }
      if (x.action === "email" && !/^[^\s@<>"]+@[^\s@<>"]+\.[^\s@<>"]+$/.test(x.to)) return fail("INVALID_ARGUMENT", "That is not an email address.", { method: "openSupported" });
      if (native()) { const j = await call(x.action === "app" ? "openApp" : "openSupported", x.action === "app" ? { name: x.name } : { action: x.action, name: x.name, query: x.query, url: x.url, to: x.to, subject: x.subject, body: x.body, number: x.number }, x); return { launched: !!(j.launched || j.opened), action: x.action, target: j.opened || undefined, verified: false, note: "Android was asked to open it; EDO cannot see what happens next." }; }
      if (typeof root.open !== "function") return fail("UNSUPPORTED_CAPABILITY", "Cannot open links here.", { method: "openSupported" });
      const url = x.action === "web" ? x.url : x.action === "maps" ? "https://www.google.com/maps/search/" + encodeURIComponent(x.query) : x.action === "email" ? "mailto:" + encodeURIComponent(x.to) + "?subject=" + encodeURIComponent(x.subject || "") + "&body=" + encodeURIComponent(x.body || "") : null;
      if (!url) return fail("UNSUPPORTED_CAPABILITY", "'" + x.action + "' needs the Android app.", { method: "openSupported" });
      const w = root.open(url, "_blank", "noopener,noreferrer"); return { launched: !!w, action: x.action, verified: false, note: "Opened a web link; the browser may have blocked it." };
    },
    async openSettings(o) {
      const v = opts("openSettings", o); if (v.error) return Promise.reject(v.error); const c = canceller(v.value); if (c) return c;
      if (!native()) return fail("UNSUPPORTED_CAPABILITY", "System settings can only be opened by the Android app.", { method: "openSettings" });
      const j = await call("openSettings", { section: v.value.section }, v.value); return { opened: String(j.opened || v.value.section), note: "A Settings screen was opened. EDO changes nothing in it." };
    },
    /* Saves content where the USER chooses (system "save as" dialog). It never overwrites silently and never downloads remote URLs. */
    async downloadFile(o) {
      const v = opts("downloadFile", o); if (v.error) return Promise.reject(v.error); const c = canceller(v.value); if (c) return c; const x = v.value;
      if ((x.text == null) === (x.base64 == null)) return fail("INVALID_ARGUMENT", "Pass exactly one of text or base64.", { method: "download.save" });
      const name = safeName(x.filename); if (!name) return fail("INVALID_ARGUMENT", "That file name is not allowed.", { method: "download.save" });
      const bytes = x.text != null ? new TextEncoder().encode(x.text).length : Math.floor(x.base64.length * 3 / 4) - (x.base64.endsWith("==") ? 2 : x.base64.endsWith("=") ? 1 : 0);
      if (bytes > LIMITS.downloadBytes) return fail("FILE_TOO_LARGE", "Content is " + bytes + " bytes; the limit is " + LIMITS.downloadBytes + ".", { method: "download.save", details: { size: bytes, limit: LIMITS.downloadBytes } });
      if (bytes === 0) return fail("INVALID_ARGUMENT", "There is nothing to save.", { method: "download.save" });
      if (native()) { const j = await call("download.save", { filename: name, mime: x.mime, text: x.text, base64: x.base64 }, x); return { saved: j.saved === true, name: String(j.name || name), bytes: j.bytes | 0 }; }
      if (typeof document === "undefined" || typeof Blob !== "function" || !root.URL || !root.URL.createObjectURL) return fail("UNSUPPORTED_CAPABILITY", "Downloads are not available here.", { method: "download.save" });
      const g = needGesture("download.save"); if (g) return Promise.reject(g);
      const part = x.text != null ? x.text : Uint8Array.from(atob(x.base64), (ch) => ch.charCodeAt(0)); const url = root.URL.createObjectURL(new Blob([part], { type: x.mime })); const a = document.createElement("a"); a.href = url; a.download = name; a.style.display = "none"; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => root.URL.revokeObjectURL(url), 4000);
      return { saved: null, initiated: true, name, bytes, note: "The browser started the download; EDO cannot see where it went." };
    },
    /* Test and recovery helper: forget cached state and listeners so a reloaded page starts clean. */
    reset() { S.unsub.forEach((f) => { try { f(); } catch (e) {} }); S.unsub = []; S.hooked = false; S.inited = false; S.caps = null; S.inflight.clear(); S.exclusive = null; S.listeners = {}; S.files.clear(); S.speech = null; },
  };

  ["requestPermission", "pickFile", "readFile", "pickImage", "captureImage", "getImageData", "extractTextFromImage", "speak", "downloadFile", "share", "openSupportedApp", "openSettings"].forEach((n) => { API[n] = cancelable(API[n]); });

  function kindGuess(f) { const e = extOf(f.name); return e === "pdf" ? "pdf" : e === "docx" ? "docx" : TEXT_EXT.includes(e) || TEXT_MIME.test(f.type || "") ? "text" : "unknown"; }
  function safeHttps(u) { try { const x = new URL(u); if (x.protocol !== "https:" || x.username || x.password || x.port && x.port !== "443" || !x.hostname.includes(".")) return null; return x.href; } catch (e) { return null; } }
  function safeName(n) { const s = String(n).replace(/[\u0000-\u001f]/g, "").trim(); if (!s || s.length > 100 || /[\\/:*?"<>|]/.test(s) || s === "." || s === ".." || /^\./.test(s)) return null; return s; }
  function normalizeFiles(j) {
    const list = Array.isArray(j.files) ? j.files : (j.ref ? [j] : []);
    const files = list.filter((f) => isObj(f) && REF.test(String(f.ref))).map((f) => ({ ref: f.ref, name: String(f.name || "file").slice(0, 120), size: typeof f.size === "number" ? f.size : -1, mime: String(f.mime || ""), kind: ["text", "pdf", "docx", "unknown", "zip"].includes(f.kind) ? f.kind : "unknown" }));
    if (!files.length) throw new AndroidBridgeError("INTERNAL_ERROR", "The native picker returned no usable file.", { method: "pickFile" });
    return { files };
  }
  function normalizeImages(j) {
    const list = Array.isArray(j.images) ? j.images : [];
    const images = list.filter((f) => isObj(f) && REF.test(String(f.ref))).map((f) => ({ ref: f.ref, name: String(f.name || "image").slice(0, 120), size: typeof f.size === "number" ? f.size : -1, mime: String(f.mime || ""), width: f.width | 0 || null, height: f.height | 0 || null, orientation: typeof f.orientation === "number" ? f.orientation : null }));
    if (!images.length) throw new AndroidBridgeError("INTERNAL_ERROR", "The native side returned no usable image.", { method: "image" });
    return { images };
  }
  function normalizeRead(j, ref) {
    if (typeof j.text !== "string" && j.empty !== true) throw new AndroidBridgeError("INTERNAL_ERROR", "The native read result had no text.", { method: "readFile" });
    return { ref, name: String(j.name || ""), kind: String(j.kind || "text"), mime: String(j.mime || ""), encoding: String(j.encoding || "utf-8"), encodingGuessed: j.encodingGuessed === true, text: j.text || "", size: typeof j.size === "number" ? j.size : -1, offset: j.offset | 0, bytesRead: j.bytesRead | 0, nextOffset: typeof j.nextOffset === "number" ? j.nextOffset : null, eof: j.eof !== false, partial: j.partial === true, truncated: j.truncated === true, charCount: (j.text || "").length, note: j.note ? clean(j.note) : undefined };
  }
  function normalizeOcr(j) {
    if (!Array.isArray(j.results)) throw new AndroidBridgeError("INTERNAL_ERROR", "The OCR result was malformed.", { method: "ocr.extract" });
    const results = j.results.filter(isObj).map((r, i) => ({ ref: String(r.ref || ""), imageId: r.imageId != null ? r.imageId : i, page: r.page != null ? r.page | 0 : undefined, status: ["ok", "empty", "failed"].includes(r.status) ? r.status : "failed", text: String(r.text || ""), width: r.width | 0, height: r.height | 0, blocks: Array.isArray(r.blocks) ? r.blocks : [], durationMs: typeof r.durationMs === "number" ? r.durationMs : null, error: r.error ? { code: CODE_MAP[r.error.code] || "OCR_FAILED", message: clean(r.error.message) } : undefined }));
    return finishOcr(results, typeof j.durationMs === "number" ? j.durationMs : null, String(j.engine || "native"));
  }
  function finishOcr(results, ms, engine) {
    const ok = results.filter((r) => r.status === "ok"), failed = results.filter((r) => r.status === "failed");
    if (results.length && failed.length === results.length) throw new AndroidBridgeError("OCR_FAILED", "Text recognition failed: " + ((failed[0].error && failed[0].error.message) || "unknown reason"), { method: "ocr.extract", details: { results } });
    return { engine, status: ok.length ? "ok" : "empty", text: ok.map((r) => r.text).join("\n\n"), results, durationMs: ms, confidenceAvailable: false };
  }

  root.EDO.AndroidBridge = API;
  if (typeof module !== "undefined" && module.exports) module.exports = API;
})();
